# Same-run outer-try / foreach trace preparation v2

This is a private v2 of the unexecuted v1 preparation; v1 is preserved unchanged. It instruments the existing `Walker` in `crates/jarde-java/src/region.rs` for the exact `handled(List,List)` bytecode shape. It records named-try entry/shape, the protected-body `region_at` result and continuation, BCI 7 loop encounter/frame/prefix, visited sets, the one existing `certified_try_exit` verdict, canonical/normal-flow membership and natural-loop header/exits, and final region ownership. It adds no region rule, solver, or public behavior change.

Files:

- `trace.patch`: reviewable unified diff against the base source hash in `pins.json`.
- `region.rs.base` and `region.rs.candidate`: byte-exact source snapshots.
- `run_trace.py`: fixed root runner for one existing integration test.
- `trace-spec.md`: event fields and interpretation.
- `static-review.md`: v2 type/path review notes and remaining compile-validation boundary.
- `pins.json`: product sources, focused test/fixture, candidate, patch, runner, and reused helper hashes.

The runner uses the existing `source_manifest()` function from the pinned focused-list runner and its pinned source-closure helper. It records the complete 4,854-file source-pin map before instrumentation and after restoration/cleanup, then requires exact equality. It requires `target/` to be absent before the first command. The focused test is:

```text
cargo test --test structured_list_generic_bodies nearby_list_controls_refuse_only_unproved_generic_projections -- --exact --nocapture
```

The runner sets the focused build limits `CARGO_BUILD_JOBS=1`, `CARGO_INCREMENTAL=0`, `CARGO_PROFILE_DEV_DEBUG=0`, `CARGO_PROFILE_TEST_DEBUG=0`, and `RUST_TEST_THREADS=1`; Rust stack remains default. It also sets `JRE_PREFIX_PROBE=1`. Existing CF11 controls are exercised; the test still asserts `handled` generic projection refusal and the patch does not alter/remove the method or its input.

Before modifying the workspace, the runner verifies the exact `region.rs` base hash, candidate hash, helper hashes, and all focused source pins. It saves the original file bytes and mode, writes the candidate, and restores/byte-checks the original in `finally`. The test process runs in its own process group, sampled every second, and is terminated as a group below 5 GiB free space or at 1 GiB `target/`. The runner then issues exactly `cargo clean` after restoration, confirms `target/` is absent, and snapshots the full focused source closure again. It preserves raw test/cleanup streams and a receipt under its private `run/` output. A failure or guard stop remains a separate captured result.

Root can review the pins/patch and run:

```sh
python3 /private/tmp/jarde-outer-try-foreach-trace-prep-luna-v2/run_trace.py
```

No trace result is prefilled. The trace can distinguish a missing continuation from a normal-flow/natural-loop or ownership issue; it does not establish a fix by itself. `rawAliasEscape`'s debug-local slot/type symptom remains a separate concern.
