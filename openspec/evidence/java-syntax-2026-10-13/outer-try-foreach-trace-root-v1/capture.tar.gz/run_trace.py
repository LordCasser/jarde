#!/usr/bin/env python3
"""Root-owned, guarded one-test collector for the private outer-try/foreach trace patch."""
from __future__ import annotations
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / 'crates/jarde-java/src/region.rs'
CANDIDATE = HERE / 'region.rs.candidate'
OUT = HERE / 'run'
FOCUSED_RUNNER_PATH = Path('/private/tmp/jarde-cf11-structured-list-focused-runner-prep-luna-v6/run.py')
FOCUSED_RUNNER_SHA256 = 'b222ba19e1962ce0c9164b1e82e546740bfe7e195b9bb4388c3cbe9d630b7d65'
CLOSURE_PATH = Path('/private/tmp/jarde-iterator-assignment-full-validation-prep-luna-v2/workspace_runner.py')
CLOSURE_SHA256 = '63e52b55fe5d20d5f2ece98ac80676ccdb2de8dfd33d7199b688e075fb1e9673'
EXPECTED_SOURCE_PIN_COUNT = 4854
BASE_SHA256 = '6f10c13d37b2472b77a0a5bc1d97f9bb45d05a65a030dca4f555d0221c3a707a'
CANDIDATE_SHA256 = '850dfb654cc913251e36492613782b697b27937a4d15e3f896c12603a928eef6'
FREE_FLOOR = 5 * 1024**3
TARGET_CEILING = 1024**3
POLL_SECONDS = 1.0
TEST_ARGV = ['cargo', 'test', '--test', 'structured_list_generic_bodies',
             'nearby_list_controls_refuse_only_unproved_generic_projections', '--',
             '--exact', '--nocapture']
CLEAN_ARGV = ['cargo', 'clean']


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_source_inventory():
    if sha(FOCUSED_RUNNER_PATH.read_bytes()) != FOCUSED_RUNNER_SHA256:
        raise RuntimeError('pinned focused source_manifest helper changed')
    if not CLOSURE_PATH.is_file() or sha(CLOSURE_PATH.read_bytes()) != CLOSURE_SHA256:
        raise RuntimeError('pinned focused source-closure helper changed')
    spec = importlib.util.spec_from_file_location('jarde_focused_source_manifest_v6', FOCUSED_RUNNER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError('cannot load focused source_manifest helper')
    focused = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(focused)
    closure_spec = importlib.util.spec_from_file_location('jarde_focused_source_closure_v2', CLOSURE_PATH)
    if closure_spec is None or closure_spec.loader is None:
        raise RuntimeError('cannot load pinned focused source-closure helper')
    closure = importlib.util.module_from_spec(closure_spec)
    closure_spec.loader.exec_module(closure)
    focused.CLOSURE_MODULE = closure
    if sha(FOCUSED_RUNNER_PATH.read_bytes()) != FOCUSED_RUNNER_SHA256 or \
            sha(CLOSURE_PATH.read_bytes()) != CLOSURE_SHA256:
        raise RuntimeError('focused source-manifest helpers changed during import')
    return focused

def capture_source_pins(focused) -> dict[str, str]:
    rows = focused.source_manifest()
    pins = {row['path']: row['sha256'] for row in rows}
    if len(pins) != EXPECTED_SOURCE_PIN_COUNT or len(rows) != EXPECTED_SOURCE_PIN_COUNT:
        raise RuntimeError(f'focused source closure count changed: {len(pins)} unique / {len(rows)} rows != {EXPECTED_SOURCE_PIN_COUNT}')
    return pins

def tree_bytes(path: Path) -> int:
    if not path.exists():
        return 0
    total = 0
    stack = [path]
    while stack:
        here = stack.pop()
        try:
            with os.scandir(here) as entries:
                for entry in entries:
                    if entry.is_symlink():
                        continue
                    if entry.is_dir(follow_symlinks=False):
                        stack.append(Path(entry.path))
                    elif entry.is_file(follow_symlinks=False):
                        try:
                            total += entry.stat(follow_symlinks=False).st_size
                        except FileNotFoundError:
                            pass
        except FileNotFoundError:
            pass
    return total


def terminate_group(child: subprocess.Popen[bytes]) -> None:
    if child.poll() is not None:
        return
    try:
        os.killpg(child.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        child.wait(timeout=8)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait()


def run_guarded(argv: list[str], env: dict[str, str], stdout_path: Path,
                stderr_path: Path, *, guard: bool) -> dict:
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    before_free = shutil.disk_usage(ROOT).free
    before_target = tree_bytes(ROOT / 'target')
    if guard and before_free < FREE_FLOOR:
        return {'argv': argv, 'started_at': started, 'state': 'not_started',
                'guard_stop': 'free_space_below_5_gib_before_start',
                'free_bytes_before': before_free, 'target_bytes_before': before_target}
    if guard and before_target >= TARGET_CEILING:
        return {'argv': argv, 'started_at': started, 'state': 'not_started',
                'guard_stop': 'target_at_or_above_1_gib_before_start',
                'free_bytes_before': before_free, 'target_bytes_before': before_target}
    began = time.monotonic()
    peak = before_target
    stop = None
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr,
                                 start_new_session=True)
        try:
            while child.poll() is None:
                if guard:
                    free_now = shutil.disk_usage(ROOT).free
                    target_now = tree_bytes(ROOT / 'target')
                    peak = max(peak, target_now)
                    if free_now < FREE_FLOOR:
                        stop = 'free_space_below_5_gib'
                    elif target_now >= TARGET_CEILING:
                        stop = 'target_at_or_above_1_gib'
                    if stop:
                        terminate_group(child)
                        break
                time.sleep(POLL_SECONDS)
            exit_code = child.wait()
        except BaseException:
            terminate_group(child)
            raise
    after_free = shutil.disk_usage(ROOT).free
    after_target = tree_bytes(ROOT / 'target')
    peak = max(peak, after_target)
    return {'argv': argv, 'started_at': started,
            'duration_seconds': time.monotonic() - began, 'exit_code': exit_code,
            'state': 'guard_stopped' if stop else 'observed', 'guard_stop': stop,
            'free_bytes_before': before_free, 'free_bytes_after': after_free,
            'target_bytes_before': before_target, 'target_bytes_after': after_target,
            'peak_target_bytes': peak,
            'stdout': {'path': str(stdout_path), 'bytes': stdout_path.stat().st_size,
                       'sha256': sha(stdout_path.read_bytes())},
            'stderr': {'path': str(stderr_path), 'bytes': stderr_path.stat().st_size,
                       'sha256': sha(stderr_path.read_bytes())}}


def main() -> int:
    if len(sys.argv) != 1:
        raise SystemExit('no arguments are accepted; root reviews README and runs this fixed collector')
    if OUT.exists():
        raise SystemExit(f'refusing to overwrite prior evidence directory: {OUT}')
    if (ROOT / 'target').exists() or (ROOT / 'target').is_symlink():
        raise SystemExit('target/ must be absent before the first guarded command')
    if not SOURCE.is_file() or SOURCE.is_symlink():
        raise SystemExit('source is missing or is a symlink')
    original = SOURCE.read_bytes()
    original_mode = SOURCE.stat().st_mode & 0o777
    candidate = CANDIDATE.read_bytes()
    if sha(original) != BASE_SHA256:
        raise SystemExit('region.rs no longer matches the exact source hash pinned for this patch')
    if sha(candidate) != CANDIDATE_SHA256:
        raise SystemExit('private candidate source does not match its frozen hash')
    focused_inventory = load_source_inventory()
    source_pins_before = capture_source_pins(focused_inventory)
    OUT.mkdir(parents=True)
    (OUT / 'region.rs.original').write_bytes(original)
    env = os.environ.copy()
    for key in ('RUST_MIN_STACK', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS'):
        env.pop(key, None)
    env['JRE_PREFIX_PROBE'] = '1'
    env['CARGO_TARGET_DIR'] = str(ROOT / 'target')
    env.update({'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0',
                'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
                'RUST_TEST_THREADS': '1'})
    record = {
        'schema': 'jarde-outer-try-foreach-same-run-trace-v1',
        'status': 'running', 'workspace': str(ROOT), 'private_patch': str(HERE / 'trace.patch'),
        'source': {'path': str(SOURCE), 'base_sha256': BASE_SHA256,
                   'candidate_sha256': CANDIDATE_SHA256, 'mode': oct(original_mode)},
        'target_method_fingerprint': {'start_bci': 0, 'protected_end_bci': 47,
                                      'handler_bci': 50, 'last_instruction_bci': 59},
        'test_argv': TEST_ARGV, 'resource_guard': {'free_floor_bytes': FREE_FLOOR,
                                                   'target_ceiling_bytes': TARGET_CEILING,
                                                   'poll_seconds': POLL_SECONDS,
                                                   'process_group': True,
                                                   'rust_stack': 'default'},
        'source_manifest_helper': {'path': str(FOCUSED_RUNNER_PATH), 'sha256': FOCUSED_RUNNER_SHA256},
        'source_closure_helper': {'path': str(CLOSURE_PATH), 'sha256': CLOSURE_SHA256},
        'source_pin_count_expected': EXPECTED_SOURCE_PIN_COUNT,
        'source_pins_before': source_pins_before, 'source_pins_after': None,
        'source_pins_equal': None, 'commands': [], 'source_restore': None, 'cleanup': None,
    }
    (OUT / 'execution.json').write_text(json.dumps(record, indent=2) + '\n')
    changed = False
    try:
        changed = True
        SOURCE.write_bytes(candidate)
        if sha(SOURCE.read_bytes()) != CANDIDATE_SHA256:
            raise RuntimeError('candidate bytes did not install exactly')
        row = run_guarded(TEST_ARGV, env, OUT / 'test.stdout.raw', OUT / 'test.stderr.raw', guard=True)
        record['commands'].append(row)
        record['status'] = 'observed' if row.get('state') == 'observed' and row.get('exit_code') == 0 else 'failed_or_guard_stopped'
    except BaseException as exc:
        record['status'] = 'collector_exception'
        record['error'] = f'{type(exc).__name__}: {exc}'
    finally:
        if changed:
            try:
                SOURCE.write_bytes(original)
                os.chmod(SOURCE, original_mode)
                actual = SOURCE.read_bytes()
                record['source_restore'] = {'sha256': sha(actual), 'expected_sha256': BASE_SHA256,
                                            'byte_exact': actual == original,
                                            'mode': oct(SOURCE.stat().st_mode & 0o777)}
                if actual != original or sha(actual) != BASE_SHA256:
                    record['status'] = 'restore_failed'
            except BaseException as exc:
                record['source_restore'] = {'error': f'{type(exc).__name__}: {exc}'}
                record['status'] = 'restore_failed'
        # Cleanup is deliberately the exact command requested for this probe and runs only after
        # source restoration. It has its own raw streams and is not mixed with the test receipt.
        try:
            clean = run_guarded(CLEAN_ARGV, env, OUT / 'cargo-clean.stdout.raw',
                                OUT / 'cargo-clean.stderr.raw', guard=False)
            record['cleanup'] = clean
            record['target_absent_after_clean'] = not (ROOT / 'target').exists()
            if clean.get('exit_code') != 0 or not record['target_absent_after_clean']:
                record['status'] = 'cleanup_failed'
        except BaseException as exc:
            record['cleanup'] = {'error': f'{type(exc).__name__}: {exc}'}
            record['status'] = 'cleanup_failed'
        try:
            record['source_pins_after'] = capture_source_pins(focused_inventory)
            record['source_pins_equal'] = record['source_pins_before'] == record['source_pins_after']
            if not record['source_pins_equal']:
                record['status'] = 'source_closure_changed'
                before = record['source_pins_before']
                after = record['source_pins_after']
                record['source_pin_differences'] = {
                    path: {'before': before.get(path), 'after': after.get(path)}
                    for path in sorted(set(before) | set(after)) if before.get(path) != after.get(path)
                }
        except BaseException as exc:
            record['source_pins_after_error'] = f'{type(exc).__name__}: {exc}'
            record['status'] = 'source_pin_snapshot_failed'
        (OUT / 'execution.json').write_text(json.dumps(record, indent=2) + '\n')
    print(OUT / 'execution.json')
    return 0 if record['status'] == 'observed' and record.get('source_restore', {}).get('byte_exact') and record.get('target_absent_after_clean') and record.get('source_pins_equal') else 1

if __name__ == '__main__':
    raise SystemExit(main())
