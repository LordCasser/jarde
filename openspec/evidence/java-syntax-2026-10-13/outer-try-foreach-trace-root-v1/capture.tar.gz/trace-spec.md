# Trace contract

The detailed `OTF` events reuse the existing `JRE_PREFIX_PROBE=1` hook. The private code additionally filters by first instruction BCI 0, final instruction BCI 59, and an exception row `[0,47) -> 50`. This pins the detailed trace to the requested `handled(List,List)` control shape. The pre-existing hook also writes its `P3VISITED` and `P3LOST` summaries for other methods reached by the focused integration test. The patch changes no region decisions.

The trace records:

- `OTF graph`: same-run canonical-block membership, canonical outgoing edge kinds/targets, normal-flow node membership/outgoing targets for BCIs 0, 7, 16, 47, 50, and 59; plus header 7's natural-loop membership, latches, normal-flow exits, and irreducibility verdict.
- `OTF try.enter` / `OTF try.shape`: outer start, active frame boundary and `own_try`, protected end/join, handler site/types/parameter, and visited BCIs at entry.
- `OTF protected.begin` / `.end`: ordinary protected-body walk's start, boundary, scope, region blocks, returned continuation (`body_next`), and visited sets before/after.
- `OTF loop.encounter`: at BCI 7, prefix blocks and active frame facts. `OTF loop.result` appears only if that walk actually invokes `loop_region` with an empty prefix.
- `OTF certified_try_exit`: verdict emitted at the existing call site when that call executes. The function is called once, with no duplicate proof or budget charge.
- `OTF try.exit`: final protected-body, catch, tail, join, and visited sets after `try_level` returns.
- `OTF final.uncovered_closure` / `OTF final`: blocks the existing closure check deemed unowned at that point, then all returned region owner block sets, visited blocks, and fallback owners.

No event is synthesized if its code path does not execute. Absence of `OTF loop.result` alone does not prove refusal; correlate it with loop encounter, natural-loop facts, protected continuation, and final owners. These logs are observation only, not a fix or source proof.
