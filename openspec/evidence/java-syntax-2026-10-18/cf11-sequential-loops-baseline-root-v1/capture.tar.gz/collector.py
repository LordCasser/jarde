#!/usr/bin/env python3
"""Prepared serial baseline collector for the original TestSequentialLoops class.

Run later with python -B. This collector preserves raw command streams and does
not edit the shared workspace or any source/fixture input.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import zipfile

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
SOURCE = Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestSequentialLoops.java')
SOURCE_SHA256 = '7b9826d70fcd7444773250dbcacbc2a35e41e75c32b002fc8091322132006913'
DEPENDENCY_REFERENCE = Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018/execution.json')
DEFAULT_CLI = Path('/private/tmp/jarde-prefixed-retry-final-focused-root-v5-20261018/candidate-cli')
DEFAULT_CLI_SHA256 = '25adeaf312a7644c7d4c73191ef1264af0378cf78139d35a890377e3c86371ce'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA256 = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA256 = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
CLASS_NAME = 'jadx.tests.integration.loops.TestSequentialLoops$TestCls'
INTERNAL_CLASS = 'jadx/tests/integration/loops/TestSequentialLoops$TestCls'
OUTER_CLASS = 'jadx/tests/integration/loops/TestSequentialLoops'
EXPECTED_METHODS = {('<init>', '()V'), ('test', '(II)I')}
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
RUNTIME_BOUND = Path('/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
RUNTIME_BOUND_SHA256 = '73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
JDK_LEGS = ('javac8', 'javac23')
EVIDENCE = ('default', 'all')


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def class_method_set(facts: dict) -> set[tuple[str, str]]:
    return {(row['name'], row['descriptor']) for row in facts['methods']}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--cli', type=Path, default=DEFAULT_CLI)
    parser.add_argument('--cli-sha256', default=DEFAULT_CLI_SHA256,
                        help='exact SHA-256 pin for --cli; supply both when root selects another frozen CLI')
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()

    root = args.root.resolve(strict=True)
    out = args.out.resolve()
    cli = args.cli.resolve(strict=True)
    if out.exists():
        raise SystemExit(f'refusing existing output: {out}')
    if sha256(cli) != args.cli_sha256.lower():
        raise SystemExit(f'CLI SHA-256 differs from supplied pin: {cli}')
    if sha256(SOURCE) != SOURCE_SHA256:
        raise SystemExit('local TestSequentialLoops source changed from its static pin')
    if root != ROOT.resolve():
        raise SystemExit(f'root differs from the pinned workspace: {root}')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('refusing to start while workspace target exists')
    if sha256(JADX) != JADX_SHA256 or sha256(JADX_JAR) != JADX_JAR_SHA256:
        raise SystemExit('JADX 1.5.6 executable/JAR pin mismatch')
    if sha256(RUNTIME_BOUND) != RUNTIME_BOUND_SHA256:
        raise SystemExit('30-second runtime wrapper pin mismatch')

    compare = load(root / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py',
                   'sequential_compare')
    guard_path = root / GUARD_REL
    scanner_path = root / SCANNER_REL
    if compare.sha(guard_path) != GUARD_SHA256 or compare.sha(scanner_path) != SCANNER_SHA256:
        raise SystemExit('root guard/scanner source pin mismatch')
    guard = load(guard_path, 'sequential_guard')
    scanner = load(scanner_path, 'sequential_scanner')
    jdks, jdk_pin = compare.configured_jdks(root / JDK_MANIFEST_REL, JDK_MANIFEST_SHA256)

    reference = json.loads(DEPENDENCY_REFERENCE.read_text(encoding='utf-8'))
    classpath = reference['classpath']
    for row in [reference['harness_jar'], *reference['jar_pins']]:
        path = Path(row['path'])
        if compare.pin(path) != row:
            raise SystemExit(f'harness dependency pin mismatch: {path}')
    directory_pins = reference.get('directory_pins', reference.get('directory_pins_before'))
    if not directory_pins:
        raise SystemExit('dependency reference lacks pinned JADX build class trees')
    for folder, expected in directory_pins.items():
        actual = {p.relative_to(folder).as_posix(): compare.pin(p)
                  for p in sorted(Path(folder).rglob('*.class'))}
        if actual != expected:
            raise SystemExit(f'JADX build classpath directory pin mismatch: {folder}')
    with zipfile.ZipFile(reference['harness_jar']['path']) as jar:
        if any('TestSequentialLoops' in name for name in jar.namelist()):
            raise SystemExit('pinned integration harness already contains the target class')

    out.mkdir(parents=True)
    raw = out / 'raw'
    raw.mkdir()
    guard.ROOT = root
    guard.OUT = raw
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, stdout_bytes: None
    if shutil.disk_usage(root).free < 5 * 1024**3:
        raise SystemExit('5 GiB free-space guard failed before collection')

    source_dir = out / 'source'
    source_dir.mkdir()
    source_copy = source_dir / SOURCE.name
    shutil.copy2(SOURCE, source_copy)
    empty_sourcepath = out / 'empty-sourcepath'
    empty_sourcepath.mkdir()
    driver = out / 'driver-source/TestSequentialLoopsDriver.java'
    driver.parent.mkdir(parents=True)
    shutil.copy2(Path(__file__).with_name('driver') / driver.name, driver)
    runtime_bound = out / RUNTIME_BOUND.name
    shutil.copy2(RUNTIME_BOUND, runtime_bound)
    classpath_text = os.pathsep.join(classpath)
    source_before = compare.source_closure(root)
    rows = []
    external_inputs_before = {
        'upstream_source': compare.pin(SOURCE),
        'source_copy': compare.pin(source_copy),
        'driver_source': compare.pin(driver),
        'runtime_wrapper_source': compare.pin(RUNTIME_BOUND),
        'runtime_wrapper_copy': compare.pin(runtime_bound),
        'dependency_reference': compare.pin(DEPENDENCY_REFERENCE),
        'cli': compare.pin(cli),
        'jadx_executable': compare.pin(JADX),
        'jadx_jar': compare.pin(JADX_JAR),
        'jdk_manifest': compare.pin(root / JDK_MANIFEST_REL),
        'comparison_helper': compare.pin(root / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'),
        'guard': compare.pin(guard_path),
        'scanner': compare.pin(scanner_path),
    }
    for index, row in enumerate([reference['harness_jar'], *reference['jar_pins']]):
        external_inputs_before[f'dependency_{index}'] = compare.pin(Path(row['path']))
    for leg in JDK_LEGS:
        for tool_name, tool_path in jdks[leg]['tools'].items():
            external_inputs_before[f'{leg}_{tool_name}'] = compare.pin(tool_path)

    def external_pin_snapshot():
        result = {
            'upstream_source': compare.pin(SOURCE),
            'source_copy': compare.pin(source_copy),
            'driver_source': compare.pin(driver),
            'runtime_wrapper_source': compare.pin(RUNTIME_BOUND),
            'runtime_wrapper_copy': compare.pin(runtime_bound),
            'dependency_reference': compare.pin(DEPENDENCY_REFERENCE),
            'cli': compare.pin(cli),
            'jadx_executable': compare.pin(JADX),
            'jadx_jar': compare.pin(JADX_JAR),
            'jdk_manifest': compare.pin(root / JDK_MANIFEST_REL),
            'comparison_helper': compare.pin(root / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'),
            'guard': compare.pin(guard_path),
            'scanner': compare.pin(scanner_path),
        }
        for index, dependency in enumerate([reference['harness_jar'], *reference['jar_pins']]):
            result[f'dependency_{index}'] = compare.pin(Path(dependency['path']))
        for configured_leg in JDK_LEGS:
            for tool_name, tool_path in jdks[configured_leg]['tools'].items():
                result[f'{configured_leg}_{tool_name}'] = compare.pin(tool_path)
        return result
    report = {
        'schema': 'cf11-original-testsequentialloops-baseline-v1',
        'status': 'running', 'source': compare.pin(SOURCE),
        'source_copy': compare.pin(source_copy), 'driver': compare.pin(driver),
        'runtime_bound': compare.pin(runtime_bound),
        'dependency_reference': compare.pin(DEPENDENCY_REFERENCE),
        'classpath': classpath, 'harness_jar': reference['harness_jar'],
        'jar_pins': reference['jar_pins'], 'directory_pins': directory_pins,
        'jdk_manifest': jdk_pin, 'cli': compare.pin(cli),
        'cli_sha256_argument': args.cli_sha256.lower(),
        'jadx': compare.pin(JADX), 'jadx_jar': compare.pin(JADX_JAR),
        'guard': compare.pin(guard_path), 'scanner': compare.pin(scanner_path),
        'source_pins_before': source_before, 'external_input_pins_before': external_inputs_before,
        'commands': rows,
        'profiles': [], 'javac8_boundary': None, 'driver_classes': [],
        'original_runtime': [], 'original_oracle': None,
        'wrong_root_control': None, 'jarde_cells': [], 'jadx_cells': [],
        'method_inventory': {'expected': sorted([list(row) for row in EXPECTED_METHODS])},
        'runtime_inputs': [
            [-1, 10], [-2, 20], [-3, 20], ['Integer.MAX_VALUE', 0],
            ['Integer.MIN_VALUE+8', 0], ['Integer.MAX_VALUE', -10],
        ],
        'notes': [
            'The complete upstream TestSequentialLoops.java is copied byte-for-byte and compiled without deleting outer or nested declarations.',
            'Only the nested TestCls target is loaded by the independent driver; it invokes test(II)I six times on one instance.',
            'Runtime outputs are observations from the CodeSource-checked original target under javac8 and javac23 JVMs; no expected return values are hand-written.',
            'The javac8 full-source compile is recorded as an observed harness boundary, not assumed successful.',
            'Jarde JSON and JADX extraction are captured as evidence; this collector does not compile or execute their emitted source.',
            'No private SSA facts are exposed by these public outputs; if a refusal needs diagnosis, capture same-run canonical/SSA facts separately.',
        ],
    }
    compare.write_json(out / 'execution.json', report)

    def command(argv, label, leg='javac23'):
        if (root / 'target').exists():
            raise RuntimeError('workspace target appeared during external-command collection')
        env = compare.clean_env(dict(os.environ), jdks[leg])
        env.update(guard.ENV_VALUES)
        env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(rows) + 1, [str(value) for value in argv], env)
        row['label'] = label
        row['tool_leg'] = leg
        rows.append(row)
        compare.write_json(out / 'execution.json', report)
        if row['guard_stop'] is not None:
            raise RuntimeError(f'guard stopped command {label}: {row["guard_stop"]}')
        return row

    def artifact(row, stream='stdout'):
        return compare.command_artifact(row, stream)

    def parse_profile(target: Path, outer: Path, profile: str, compile_row: dict):
        facts = compare.parse_class(target)
        if (facts['major'] != 52 or class_method_set(facts) != EXPECTED_METHODS
                or any(method['code'] is None for method in facts['methods'])):
            raise RuntimeError(f'{profile}: target method inventory/class major mismatch')
        outer_facts = compare.parse_class(outer)
        if outer_facts['major'] != 52 or outer_facts['class_name'] != OUTER_CLASS.replace('.', '/'):
            raise RuntimeError(f'{profile}: full-source outer class identity/major mismatch')
        row = {'profile': profile, 'compile_command': compile_row['index'],
               'target': facts, 'outer': outer_facts, 'classes': str(target.parents[4])}
        report['profiles'].append(row)
        javap = command([jdks['javac23']['tools']['javap'], '-p', '-s', '-c', '-v', target],
                        'original-javap-' + profile)
        row['javap_command'] = javap['index']
        compare.write_json(out / 'execution.json', report)
        return row

    try:
        boundary_dir = out / 'javac8-boundary/classes'
        boundary_dir.mkdir(parents=True)
        boundary = command([
            jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
            '-encoding', 'UTF-8', '-proc:none', '-classpath', classpath_text,
            '-sourcepath', empty_sourcepath, '-d', boundary_dir, source_copy,
        ], 'original-javac8-harness-boundary', 'javac8')
        boundary_stderr = artifact(boundary, 'stderr')
        report['javac8_boundary'] = {
            'command': boundary['index'], 'exit_code': boundary['exit_code'],
            'class_outputs': [compare.pin(p) for p in sorted(boundary_dir.rglob('*.class'))],
            'observed_major_55_diagnostic': b'55.0' in boundary_stderr,
            'stderr': boundary_stderr.decode('utf-8', errors='replace'),
        }

        for profile, debug in (('debug', '-g'), ('no-debug', '-g:none')):
            dest = out / profile / 'classes'
            dest.mkdir(parents=True)
            compiled = command([
                jdks['javac23']['tools']['javac'], '--release', '8', debug,
                '-encoding', 'UTF-8', '-proc:none', '-classpath', classpath_text,
                '-sourcepath', empty_sourcepath, '-d', dest, source_copy,
            ], 'original-compile-' + profile)
            if compiled['exit_code'] != 0:
                raise RuntimeError(f'javac23 full-source compile failed for {profile}; raw stderr retained')
            target = dest / 'jadx/tests/integration/loops/TestSequentialLoops$TestCls.class'
            outer = dest / 'jadx/tests/integration/loops/TestSequentialLoops.class'
            class_paths = sorted(p.relative_to(dest).as_posix() for p in dest.rglob('*.class'))
            expected_paths = [
                'jadx/tests/integration/loops/TestSequentialLoops$TestCls.class',
                'jadx/tests/integration/loops/TestSequentialLoops.class',
            ]
            if class_paths != expected_paths:
                raise RuntimeError(f'{profile}: unexpected complete-source class outputs {class_paths}')
            record = parse_profile(target, outer, profile, compiled)
            record['class_files'] = [compare.pin(target), compare.pin(outer)]

        driver_classes = out / 'driver-classes'
        driver_classes.mkdir()
        driver_compile = command([
            jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
            '-encoding', 'UTF-8', '-proc:none', '-classpath', empty_sourcepath,
            '-sourcepath', empty_sourcepath, '-d', driver_classes, driver,
        ], 'compile-independent-reflection-driver', 'javac8')
        if driver_compile['exit_code'] != 0:
            raise RuntimeError('independent reflection driver did not compile; raw stderr retained')
        report['driver_classes'] = [compare.pin(p) for p in sorted(driver_classes.rglob('*.class'))]

        observations = []
        for profile in report['profiles']:
            for runtime in JDK_LEGS:
                roots = [profile['classes'], str(driver_classes)]
                run = command([
                    sys.executable, '-B', runtime_bound, '30', jdks[runtime]['tools']['java'],
                    '-Xverify:all', '-cp', os.pathsep.join(roots),
                    'TestSequentialLoopsDriver', profile['classes'],
                ], f'original-runtime-{profile["profile"]}-{runtime}', runtime)
                stdout = artifact(run)
                stderr = artifact(run, 'stderr')
                cell = {'profile': profile['profile'], 'runtime': runtime,
                        'command': run['index'], 'exit_code': run['exit_code'],
                        'classpath': roots, 'stdout_sha256': sha256(Path(run['streams']['stdout']['path'])),
                        'stderr_sha256': sha256(Path(run['streams']['stderr']['path']))}
                output_lines = stdout.decode('utf-8', errors='strict').splitlines() if run['exit_code'] == 0 else []
                expected_inputs = [(-1, 10), (-2, 20), (-3, 20), (2147483647, 0),
                                   (-2147483640, 0), (2147483647, -10)]
                parsed_rows = [re.fullmatch(r'CASE (\d+) input=(-?\d+),(-?\d+) result=(-?\d+)', line)
                               for line in output_lines]
                cell['six_rows_observed'] = len(parsed_rows) == len(expected_inputs) and all(
                    match is not None and int(match.group(1)) == index
                    and (int(match.group(2)), int(match.group(3))) == expected_inputs[index]
                    for index, match in enumerate(parsed_rows))
                report['original_runtime'].append(cell)
                if run['exit_code'] == 0 and cell['six_rows_observed']:
                    observations.append(stdout)
                compare.write_json(out / 'execution.json', report)
        if len(observations) == 4 and len(set(observations)) == 1:
            oracle = observations[0]
            oracle_path = out / 'original-oracle.stdout'
            oracle_path.write_bytes(oracle)
            report['original_oracle'] = compare.pin(oracle_path)
            report['observed_oracle_stdout'] = oracle.decode('utf-8', errors='replace')
            report['original_runtime_agreement'] = True
        else:
            report['original_runtime_agreement'] = False
            report['original_runtime_note'] = 'Oracle not accepted: all four profile/JVM runs must exit zero and agree byte-for-byte.'

        wrong_root = command([
            sys.executable, '-B', runtime_bound, '30', jdks['javac23']['tools']['java'],
            '-Xverify:all', '-cp', os.pathsep.join([
                report['profiles'][0]['classes'], str(driver_classes)]),
            'TestSequentialLoopsDriver', empty_sourcepath,
        ], 'driver-code-source-wrong-root-control')
        wrong_stderr = artifact(wrong_root, 'stderr')
        report['wrong_root_control'] = {
            'command': wrong_root['index'], 'exit_code': wrong_root['exit_code'],
            'rejected_expected_root': wrong_root['exit_code'] != 0 and b'target loaded from' in wrong_stderr,
        }
        if not report['wrong_root_control']['rejected_expected_root']:
            raise RuntimeError('CodeSource wrong-root control did not reject the incorrect expected root')

        version = command([JADX, '--version'], 'jadx-version')
        version_text = (artifact(version) + artifact(version, 'stderr')).decode('utf-8', errors='replace')
        if version['exit_code'] != 0 or '1.5.6' not in version_text:
            raise RuntimeError(f'JADX version does not match 1.5.6: {version_text!r}')
        for profile in report['profiles']:
            leg = profile['profile']
            classes = Path(profile['classes'])
            target = classes / 'jadx/tests/integration/loops/TestSequentialLoops$TestCls.class'
            bundle = out / (leg + '.jar')
            with zipfile.ZipFile(bundle, 'w') as jar:
                for path in sorted(classes.rglob('*.class')):
                    info = zipfile.ZipInfo(path.relative_to(classes).as_posix(), (1980, 1, 1, 0, 0, 0))
                    info.compress_type = zipfile.ZIP_STORED
                    jar.writestr(info, path.read_bytes())
            for form, inp, policy in (('child', target, 'single-class'), ('bundle-child', bundle, 'plain-jar')):
                for evidence in EVIDENCE:
                    argv = [cli, 'class-source', '--input', inp, '--class', INTERNAL_CLASS,
                            '--policy', policy, '--release', '8', '--format', 'json']
                    if evidence == 'all':
                        argv += ['--evidence', 'all']
                    row = command(argv, f'jarde-{leg}-{form}-{evidence}')
                    raw_json = artifact(row)
                    dest = out / 'jarde' / leg / form / evidence
                    dest.mkdir(parents=True)
                    (dest / 'report.json').write_bytes(raw_json)
                    cell = {'profile': leg, 'input_form': form, 'evidence': evidence,
                            'command': row['index'], 'input': compare.pin(inp),
                            'exit_code': row['exit_code'], 'report': compare.pin(dest / 'report.json')}
                    try:
                        doc = json.loads(raw_json)
                        (dest / 'whole-source.java').write_bytes(doc.get('text', '').encode('utf-8'))
                        methods = []
                        for method in doc.get('methods', []):
                            identity = method.get('item', {}).get('identity', {})
                            key = (bytes(identity.get('name', [])).decode('utf-8'),
                                   bytes(identity.get('descriptor', [])).decode('utf-8'))
                            outcome = method.get('outcome', {})
                            rep = outcome.get('report', {})
                            methods.append({'identity': list(key), 'outcome_kind': outcome.get('kind'),
                                            'quality': rep.get('quality'), 'fallbacks': rep.get('fallbacks'),
                                            'regions': rep.get('regions'), 'source_map': rep.get('source_map')})
                        cell.update({'methods': methods,
                                     'method_inventory_matches': {tuple(item['identity']) for item in methods} == EXPECTED_METHODS,
                                     'whole_source': compare.pin(dest / 'whole-source.java')})
                    except (ValueError, TypeError) as error:
                        cell['json_parse_error'] = str(error)
                    report['jarde_cells'].append(cell)
                    compare.write_json(out / 'execution.json', report)
            for form, inp in (('child', target), ('bundle', bundle)):
                dest = out / 'jadx' / leg / form
                row = command([JADX, '--config', 'none', '--threads-count', '1', '--no-res',
                               '--rename-flags', 'none', '-d', dest, inp], f'jadx-{leg}-{form}')
                sources = [compare.pin(path) for path in sorted(dest.rglob('*.java'))] if dest.exists() else []
                report['jadx_cells'].append({'profile': leg, 'input_form': form,
                                             'command': row['index'], 'exit_code': row['exit_code'],
                                             'sources': sources})
                compare.write_json(out / 'execution.json', report)

        external_inputs_after = external_pin_snapshot()
        report['external_input_pins_after'] = external_inputs_after
        if external_inputs_after != external_inputs_before:
            raise RuntimeError('external source/tool/dependency pins changed during collection')
        if compare.source_closure(root) != source_before:
            raise RuntimeError('workspace source changed while collecting; raw evidence retained')
        report['source_unchanged'] = True
        report['target_absent'] = not (root / 'target').exists()
        report['status'] = 'captured-pending-independent-review'
        return 0
    except BaseException as error:
        report['status'] = 'failed'
        report['error'] = str(error)
        raise
    finally:
        try:
            report['external_input_pins_after'] = external_pin_snapshot()
            report['source_pins_after'] = compare.source_closure(root)
            report['source_unchanged'] = report['source_pins_after'] == source_before
            report['target_absent'] = not (root / 'target').exists()
            if (report['external_input_pins_after'] != external_inputs_before
                    or not report['source_unchanged'] or not report['target_absent']):
                if report['status'] == 'captured-pending-independent-review':
                    report['status'] = 'failed'
                report['final_guard_error'] = 'source/tool pins changed or target exists at collector exit'
        except BaseException as post_error:
            report['final_guard_error'] = str(post_error)
            if report['status'] == 'captured-pending-independent-review':
                report['status'] = 'failed'
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out / 'execution.json', report)
        shutil.copy2(__file__, out / 'collector.py')
        print(json.dumps({'status': report['status'], 'output': str(out),
                          'commands': len(rows), 'error': report.get('error')}))


if __name__ == '__main__':
    raise SystemExit(main())
