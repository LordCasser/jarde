# TestSequentialLoops2：JADX post-decrement 构造链复核

本 v2 冻结 v1，不改写 v1。专门复核 `i--` 在 compare 中的旧值构造：**当前源码证据只定位到 arithmetic/condition 的呈现能力和通用单用内联机制；我没有找到足以证明 JVM `iload; iinc -1; ifle` 被转换成 post-decrement compare operand 的专用构造/重排规则。** 因此不能把 v1 的 renderer 描述当成实际构造证据。

未执行 JADX、JDK 或构建。这里所述算法来自静态源码；不代表该测试当前输出或 runtime 结果。

## 当前源码 pins

项目：`/Users/lordcasser/workspace/testzone/jadx`。未运行 Git，以下 SHA-256 固定本次读取内容。

| 文件 | SHA-256 |
|---|---|
| `jadx-core/src/test/java/jadx/tests/integration/loops/TestSequentialLoops2.java` | `adb34f80f7d55cd3309ed7708f0fdb46768cf32e4004dbd13d4e278530306720` |
| `jadx-core/src/main/java/jadx/core/Jadx.java` | `83e134eb2f2a3aa84d8c432a3b07565c82c71e1d105037757f76385e0706b9b7` |
| `jadx-plugins/jadx-java-input/src/main/java/jadx/plugins/input/java/data/code/JavaInsnsRegister.java` | `d04ceede75af4584d31ea5a7a848c8e2da95543e52634b4ec829248a9632d3a7` |
| `jadx-core/src/main/java/jadx/core/dex/instructions/InsnDecoder.java` | `70c3be3147d2b865314ac97e87f0044fcefe1617dff65fca1b2dc9aa350db087` |
| `jadx-core/src/main/java/jadx/core/dex/instructions/ArithNode.java` | `1b5d8b6db1349cbec43e5b9b46aa20d0cba78444d681d8535d1bf8ac24117df4` |
| `jadx-core/src/main/java/jadx/core/dex/visitors/MoveInlineVisitor.java` | `1d3d0824ed71607dd37ec6ad64163cb1756c456d4fa7f10d3934f8267634d60f` |
| `jadx-core/src/main/java/jadx/core/dex/visitors/shrink/CodeShrinkVisitor.java` | `9dc19d4a8990d1fec90ea7a43b5cc1043a00faf2063f2aea9b35c9eb168192ce` |
| `jadx-core/src/main/java/jadx/core/dex/visitors/shrink/ArgsInfo.java` | `f2b5e1aba42393201b94669688d4fd636777dca792005e4b288c760f01208a63` |
| `jadx-core/src/main/java/jadx/core/dex/regions/loops/LoopRegion.java` | `181fbf24a4228e9cbea92b3f417c329f67efd02b85bedb12776073232bfe3983` |
| `jadx-core/src/main/java/jadx/core/dex/visitors/regions/PostProcessRegions.java` | `84915484fc0505c6889d49a9d6cf410d43fecb896d8c8204fc7d19210585e853` |
| `jadx-core/src/main/java/jadx/core/dex/visitors/regions/LoopRegionVisitor.java` | `921f09e8934fda33452a00359588b293117f160813477e7068fa1ec3b71e6515` |
| `jadx-core/src/main/java/jadx/core/dex/visitors/regions/RegionMakerVisitor.java` | `628f3f12fa9ffabd7f94e6520d30c79f261dcc2265f80812352cc3f25af62ac5` |

## 已定位的输入翻译与通用内联门

Java input 将 `iinc` 注册为 `Opcode.ADD_INT_LIT`，把同一 local slot 作为 result 和 operand，并读取有符号字面量（`jadx-java-input/.../JavaInsnsRegister.java:212–215`）。`InsnDecoder` 将 `ADD_INT_LIT` 送入 `arithLit`（`InsnDecoder.java:132–133, 667–669`）；`ArithNode.buildLit` 对单个 register 的形式创建 `result=reg(slot)`、`arg0=reg(slot)`、`arg1=literal` 的 ARITH 节点（`ArithNode.java:30–41`）。这些是更新 local 的证据，**它们本身没有展示 JVM operand stack 上 `iload` 得到的旧值如何变成该更新表达式的返回值**。

已找到一个通用表达式内联入口：`Jadx.getRegionsModePasses` 在 SSA 后安排 `MoveInlineVisitor`，再进行多个处理和 `CodeShrinkVisitor`，之后才进入 regions；region 后才运行 `SimplifyVisitor`、`LoopRegionVisitor` 和最终 `PrepareForCodeGen`（`Jadx.java:142–172,177–208`）。`MoveInlineVisitor` 的职责是移除冗余 MOVE 并把其输入替换到 uses；它拒绝已进入 phi 的变量（`MoveInlineVisitor.java:33–109`）。`CodeShrinkVisitor.checkInline` 仅在没有 `DONT_INLINE` 限制、赋值/use 不被禁止、非强制内联时单个 SSA use 且非 phi、命名变量等条件允许时排队内联（`:78–146`）；同块位置由 `ArgsInfo.checkInline/canMove` 约束中间指令可重排性和寄存器依赖（`ArgsInfo.java:87–152`），跨块则 `canMoveBetweenBlocks` 检查路径上的指令 `canReorder` 与对移动操作数的赋值冲突（`CodeShrinkVisitor.java:225–276`）。提交时通用 inline 将赋值 instruction wrap 到**该 use 所引用的 SSA 赋值**（`:207–222`）。

这只能说明“某个已存在、唯一使用的 SSA 赋值可以安全移入其使用处”的通用规则。它没有证明 post-decrement 旧值就是 iinc 新赋值的单一 use；源字节码的 `iload` 栈值与随后更新 local 是两个时序事实，必须有额外旧值关系证据才能把它们组合成 `i--`。我在本轮查阅的 Java-input 注册、InsnDecoder、SSA 后 MOVE/CodeShrink 路径中未找到这种专用旧值关系/重排证明。故不把通用内联准入推广成该转换已经实现。

## loop precondition / rendering 的边界

`LoopRegion.checkPreCondition` 只验证待合并指令有结果、结果 use 数不超限并在后续 precondition/condition 中被使用；`mergePreCondition` 把 precondition 指令列表挪到 header block（`LoopRegion.java:76–134`）。`PostProcessRegions.leaveRegion` 调用它以合并循环条件（`PostProcessRegions.java:24–30`）。这些代码说明已有前置条件块合并，但没有把任意局部更新的旧值转为 compare 的后缀表达式。

`LoopRegionVisitor.checkForIndexedLoop` 则从 loop end 的末指令读取增量，并要求该赋值结果恰好进入一个二输入 phi，且条件使用 phi 结果、初始化和变量使用/赋值满足进一步限制；通过后才把 init/increment 移入 `for`（`LoopRegionVisitor.java:84–143`）。这是 counted-loop 的严格改写门，不能直接作为 `i--` 在条件中的构造证明。

v1 引用的 `PrepareForCodeGen.modifyArith`（自变量更新短写）与 `InsnGen.makeArithOneArg`（`ADD/SUB 1` 渲染为后缀 `++/--`）仍有参考价值，但只属于“若 IR 已有这种 ARITH 赋值/包裹关系，生成器如何打印”的呈现证据。该链从 IR 到源文本，不补足从 `iload;iinc` 到旧值 compare operand 的构造步骤。

## 对本目标可给出的结论

- `TestSequentialLoops2.java:18` 与 `:29` 在输入 Java 源中写作 post-decrement；`:20–27` 含嵌套条件及 break，第一循环之后直接接第二循环。黄金测试只断言生成源码出现两个 `while`、`break`、两个 `<= 127`（debug 额外断言一个 `return c`，`:38–56`），不要求输出文本含 `i--`。因此输出也可能用显式更新/临时变量保持等价行为并满足这些断言；未运行原 jar 前不能声称 JADX 恢复了 `i--` 这个表面形式。
- JADX 已有通用 SSA 单用内联与循环 precondition / counted-loop 规则，适用前提如上。
- **未定位到足够源码证明实际旧值构造**。因此对“post-decrement 留在循环测试副作用中”的准确描述是：renderer 能呈现既有 ARITH-1 表示为 `i--`；本备忘不能确认该表示如何由本测试 class 的旧栈值和 `iinc` 构造。需检查冻结原 class 的实际 IR/生成输出或对应测试运行收据，才能补此链。
- Loop/break 相邻所有权仍按 v1 所述归属 `LoopRegionMaker.process` 与 `RegionStack`；那部分源代码直接支撑普通 exit/body 的处理，但也不替代本类真实 CFG/生成结果。

这不构成对 Jarde 的差距判断。root 已指出当前 Jarde 有 `test_is_pure` → `test_expression_instruction` → `snapshot_condition_part` 支持 `iload;iinc ±1` postfix 条件及唯一消费者/条件位置/无中间观察门；本静态对照不应把本例预判成 Jarde 首拒，也不建议据此改实现。
