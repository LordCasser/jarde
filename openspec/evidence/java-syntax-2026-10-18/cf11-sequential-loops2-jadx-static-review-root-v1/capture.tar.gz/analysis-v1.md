# TestSequentialLoops2：JADX 现有算法静态接续

范围限于 JADX `TestSequentialLoops2` 的 post-decrement 条件和相邻两循环的 region 所有权。未运行 JADX、JVM 或构建；以下是源码算法说明，不是该测试当前执行结果，也不据此断言 Jarde 缺陷。

## 源码与版本固定

JADX checkout：`/Users/lordcasser/workspace/testzone/jadx`。本轮不运行 Git，因此用参与判断的当前文件 SHA-256 固定源码内容：

| 文件 | SHA-256 |
|---|---|
| `jadx-core/src/test/java/jadx/tests/integration/loops/TestSequentialLoops2.java` | `adb34f80f7d55cd3309ed7708f0fdb46768cf32e4004dbd13d4e278530306720` |
| `jadx-core/src/main/java/jadx/core/Jadx.java` | `83e134eb2f2a3aa84d8c432a3b07565c82c71e1d105037757f76385e0706b9b7` |
| `jadx-core/src/main/java/jadx/core/dex/visitors/regions/LoopRegionVisitor.java` | `921f09e8934fda33452a00359588b293117f160813477e7068fa1ec3b71e6515` |
| `jadx-core/src/main/java/jadx/core/dex/visitors/regions/maker/LoopRegionMaker.java` | `a77bedda10bdb0d36f3979c27c1fc9471da726b36f34ae14d505f6f659c6b13e` |
| `jadx-core/src/main/java/jadx/core/dex/visitors/regions/maker/IfRegionMaker.java` | `3d3d4c2238a21368e5970db5d5cffb2e63a625e411e8cf64461bd6e604d74760` |
| `jadx-core/src/main/java/jadx/core/dex/visitors/regions/maker/RegionStack.java` | `9bfa6b4ef87d569aa0020389fadcfc46a856462321861298b4855a5f96532533` |
| `jadx-core/src/main/java/jadx/core/dex/visitors/PrepareForCodeGen.java` | `51f2e498c55bcce32b26a59d60d56fedaa95bd48060c605aa6b11c757f20082b` |
| `jadx-core/src/main/java/jadx/core/codegen/ConditionGen.java` | `dee46ba02afb449f7323d4deffd18053e5585b8425ff19f69caf6699f1895e55` |
| `jadx-core/src/main/java/jadx/core/codegen/InsnGen.java` | `c6308a71dd870d7f13bb8ac7efdb58191966cd6a5254aa11e443c95af6bafed6` |
| `jadx-core/src/main/java/jadx/core/dex/regions/conditions/IfCondition.java` | `4d80dcce617f8bd799a5ef136dbaca981fd6a08c4d242410809184fdefc3af5e` |
| `jadx-core/src/main/java/jadx/core/dex/regions/loops/LoopRegion.java` | `181fbf24a4228e9cbea92b3f417c329f67efd02b85bedb12776073232bfe3983` |
| `jadx-core/src/main/java/jadx/core/dex/visitors/regions/maker/RegionMaker.java` | `f93147242c63aca4f0f27739b9de23bf93c8f83bbd25b48d12478b98a4c29b77` |

## `i--` 如何留在循环条件中

测试方法直接写了两次 `while (i-- > 0)`；第一次循环内有嵌套条件，`c1 != c2` 分支执行 `break`，然后第二次循环从更新后的 `i` 继续（原测试行 15–34；debug/no-debug 测试分别要求两处 `while` 和 `break`，行 38–56）。这是源码事实，不是我从输出反推的字节码事实。

JADX 的 region pipeline 顺序是 `RegionMakerVisitor` → `IfRegionVisitor` → `ReturnVisitor`/cleaning → `SimplifyVisitor` → `LoopRegionVisitor` → `ProcessVariables` → `PrepareForCodeGen`（`Jadx.java:177–208`）。所以循环/if region 先建立，之后才对 `LoopRegion` 尝试 indexed-loop 改写；`LoopRegionVisitor.processLoopRegion` 仅处理 condition-at-start、且有 condition 的循环，然后调用 `checkForIndexedLoop`（`LoopRegionVisitor.java:70–82`）。该判定从 `loop.getInfo().getEnd()`（跳过 synthetic predecessor）读取末条 `incrInsn`，要求 SSA 结果唯一进入一个二输入 phi、变量被条件使用、init/use 限定以及相关赋值仅在循环内（`:87–143`）。这给出实际边界：post-decrement 若是条件表达式中的副作用，不能只因“形似计数循环”就被搬成 for-loop 更新式；该 visitor 只接收满足上面的 loop-end/phi 关系。对这个具体类其 IR 关系未动态检查，因此这里是算法适用性判断，不是说已观察到某次转写。

表达式保留链路是普通条件参数渲染。`IfRegionMaker.makeIfInfo` 通过 `IfCondition.fromIfNode` 建立 `Compare`（`IfRegionMaker.java:162–168`），`ConditionGen.addCompare` 对 compare 两个操作数调用 `InsnGen.addArg`（`ConditionGen.java:101–132`）；`InsnGen.addArg` 遇到 `InsnWrapArg` 会继续生成 wrapped instruction（`InsnGen.java:111–146`）。在可识别的自更新 arithmetic 情形，`PrepareForCodeGen.modifyArith` 只将 `result` 与 lhs 相同/同 code variable、且非变量声明的运算改成 `ARITH_ONEARG`，并清空 result（`PrepareForCodeGen.java:225–248`）；`InsnGen.makeArithOneArg` 对 `ADD/SUB 1` 输出 `++/--` 后缀（`:1216–1230`）。这解释了现有表示如何让可内联的 decrement 保持在 compare 操作数处、从而维持 post-decrement 的测试值与副作用顺序。

边界同样重要：并非所有带副作用的 compare 都会被该算术短写规则接受；它要求特定 ARITH 节点、同一变量和字面量 1。若 IR 不把更新表示成 compare 的可生成 wrapped expression，或循环结构不满足 indexed-loop 的 SSA 约束，以上两处代码本身不保证恢复该源码形态。没有对本类真实 debug/no-debug class 的 BCI/IR 或生成源码做动态核验。

## 第一循环 break 到第二循环头的所有权

普通 `LoopRegionMaker.process` 为 loop 选条件/退出块，构建 `LoopRegion` 并压入 `RegionStack`；condition-at-start 分支把 `condInfo.getElseBlock()` 作为循环之后的 `out`，同时 `stack.addExit(out)`，递归构造 `condInfo.getThenBlock()` 作为 loop body，最后 pop 并把 `out` 返回外层遍历（`LoopRegionMaker.java:61–95, 131–181`）。因此 sequential loop 的边界机制有一个现成的落点：第一循环的 exit 作为第一 loop 的 region 边界；returning `out` 后，上层 `RegionMaker.traverse` 可从该 block 继续处理第二 loop（`RegionMaker.java:81–133`）。这段代码没有把后继循环吞进前一个 body。

内部 `break` 的 edge 也有现成表示。`LoopRegionMaker.insertLoopBreak` 在已识别的 loop-exit 路径上挂 `InsnType.BREAK` edge instruction，并将对应 exit 加到当前 stack frame（`LoopRegionMaker.java:652–702`）；`RegionMaker.makeRegion` 在入口 block 已属于当前 frame exits 时立即停止（`:52–58`）。对于 nested `if`，`IfRegionMaker.process` 再压一层 region，将 if 的 `outBlock` 加为局部 exit；若 else 分支本身已是 exit，则不重复递归（`IfRegionMaker.java:98–118`）。`RegionStack.push` 复制父 frame 的 exits，`addExit`/`containsExit` 管理当前边界（`RegionStack.java:38–45, 64–107`），所以 if 汇合点、loop exit 和外层边界可同时存在而不会被一个局部 if 替换掉。

对本测试的算法映射是：内层条件的 break 路径归入第一循环的退出 edge；它与第一循环正常条件退出共同到达循环后的后继位置时，该位置仍是 outer walker 的下一入口，而不是第一 loop body 的普通顺序块。上述实现支持这种普通结构，无需新 region 表示。静态阅读不能确认此 class 的真实 CFG 中两条 exit 是否落到完全相同物理 block、debug/no-debug 是否相同，也不能代替完整 class 的 API/源码重编验收。

## 可直接复用的既有入口

- post-decrement：条件 compare 中 wrapped arithmetic 的生成链及 `LoopRegionVisitor.checkForIndexedLoop` 的现有准入条件。
- break/第二循环：`LoopRegionMaker.process` 的 `out`/`stack.addExit`，`insertLoopBreak` 的 edge instruction，以及 `RegionMaker` 按 stack exits 停止/继续的遍历规则。

这些是 JADX 的现有算法落点；本备忘不提出 Jarde 实现任务，也不判断 Jarde 对此类已有或缺失支持。


## Jarde 侧范围提醒

这份 JADX 代码路径不能单独推出 Jarde 的缺口。root 已指出当前 Jarde `region.rs` 的 `test_is_pure` → `test_expression_instruction` → `snapshot_condition_part` 已有 `iload; iinc ±1` postfix 条件表示，带唯一消费者/条件位置/无中间观察等门；因此此处只把 JADX 作为现有算法参照，不把 `i--` 归为 Jarde 未支持。`statementful_loop_header` 是否会参与本用例仍需实际 Reader/首拒证据；静态读 JADX 不回答这一点。
