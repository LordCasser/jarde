#!/usr/bin/env python3
"""Independently inspect a completed eight-cell Seq1 current-CLI API replay (read only)."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
BASELINE = Path('/private/tmp/jarde-testsequentialloops-baseline-run-root-v1-20261018/execution.json')
RAW_KEYS = {'usage', 'elapsed_millis'}
MAX_TARGET = 1024**3
MIN_FREE = 5 * 1024**3

class ReviewError(Exception):
    pass

def need(ok, message):
    if not ok: raise ReviewError(message)

def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def pin(path: Path) -> dict:
    path = Path(path).resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha_bytes(data)}

def read_json(path: Path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def check_pin(record, path: Path, label: str):
    need(isinstance(record, dict) and pin(path) == record, f'{label}: file pin mismatch: {path}')

def read_raw(record, receipt_root: Path, label: str) -> bytes:
    need(isinstance(record, dict), f'{label}: raw pin missing')
    path = Path(record.get('path', ''))
    need(path.is_absolute() and not path.is_symlink(), f'{label}: raw path is not canonical/absolute')
    path = path.resolve(strict=True)
    need(path.is_relative_to(receipt_root.resolve(strict=True)), f'{label}: raw path escapes receipt directory')
    data = path.read_bytes()
    need(len(data) == record.get('bytes') and sha_bytes(data) == record.get('sha256'), f'{label}: raw digest mismatch')
    return data

def normalize(value):
    if isinstance(value, dict):
        return {k: normalize(v) for k, v in value.items() if k not in RAW_KEYS}
    if isinstance(value, list): return [normalize(v) for v in value]
    return value

def diff_values(left, right, path='$', out=None):
    if out is None: out = []
    if type(left) is not type(right):
        out.append({'path': path, 'baseline_type': type(left).__name__, 'current_type': type(right).__name__})
    elif isinstance(left, dict):
        for key in sorted(set(left) | set(right)):
            if key not in left or key not in right:
                out.append({'path': f'{path}.{key}', 'baseline_present': key in left, 'current_present': key in right})
            else: diff_values(left[key], right[key], f'{path}.{key}', out)
    elif isinstance(left, list):
        if len(left) != len(right): out.append({'path': path + '.length', 'baseline': len(left), 'current': len(right)})
        for i, (a, b) in enumerate(zip(left, right)): diff_values(a, b, f'{path}[{i}]', out)
    elif left != right:
        out.append({'path': path, 'baseline': repr(left)[:500], 'current': repr(right)[:500]})
    return out

def source_closure(root: Path) -> dict:
    candidates = [root / 'Cargo.toml', root / 'Cargo.lock']
    for rel in ('src', 'crates', 'tests', 'openspec/changes/recover-exception-only-finally-completion'):
        directory = root / rel
        if not directory.exists(): continue
        for current, dirs, files in os.walk(directory):
            dirs[:] = sorted(d for d in dirs if d not in {'.git', 'target', '__pycache__'})
            for filename in sorted(files):
                path = Path(current) / filename
                if path.is_file() and not path.is_symlink(): candidates.append(path)
    result = {}
    for path in sorted(set(candidates)):
        if path.is_file() and not path.is_symlink(): result[path.relative_to(root).as_posix()] = pin(path)
    return result

def validate(receipt_path: Path):
    receipt_path = receipt_path.resolve(strict=True)
    out = receipt_path.parent.resolve(strict=True)
    current = read_json(receipt_path)
    need(current.get('schema') == 'cf11-sequential-loops-current-api-replay-v1', 'wrong replay schema')
    need(current.get('status') == 'captured-pending-independent-review', 'replay is not a completed capture')
    need(current.get('source_unchanged') is True and current.get('cli_unchanged') is True,
         'collector did not certify source/CLI stability')
    need(current.get('target_absent') is True, 'collector did not certify target absence')
    need(not (ROOT / 'target').exists() and not (ROOT / 'target').is_symlink(), 'workspace target exists during review')
    need(re.fullmatch(r'[0-9a-f]{40}', current.get('product_revision_argument', '')) is not None,
         'product revision argument is malformed')

    baseline = read_json(BASELINE)
    need(baseline.get('schema') == 'cf11-original-testsequentialloops-baseline-v1', 'wrong frozen baseline schema')
    check_pin(current.get('baseline_receipt'), BASELINE, 'baseline receipt')
    old_cli = baseline.get('cli') or {}
    check_pin(current.get('baseline_cli'), Path(old_cli.get('path', '')), 'baseline CLI')
    need(current['baseline_cli'] == old_cli and baseline.get('cli_sha256_argument') == old_cli.get('sha256'),
         'baseline CLI binding differs from original receipt')

    cli_record = current.get('cli') or {}
    cli_path = Path(cli_record.get('path', ''))
    check_pin(cli_record, cli_path, 'candidate CLI')
    need(current.get('input_pins_before') == current.get('input_pins_after'), 'input pins changed during replay')
    live_inputs = {}
    for name, record in current['input_pins_before'].items():
        check_pin(record, Path(name), 'current input')
        live_inputs[name] = record
    need(live_inputs == current['input_pins_after'], 'live inputs differ from the recorded after pins')

    compare_record = current.get('compare_helper') or {}
    guard_record = current.get('guard') or {}
    scanner_record = current.get('scanner') or {}
    jdk_record = current.get('jdk') or {}
    check_pin(compare_record, ROOT / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py', 'compare helper')
    check_pin(guard_record, ROOT / 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py', 'root guard')
    check_pin(scanner_record, ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py', 'target scanner')
    manifest_path = ROOT / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
    check_pin({'path': jdk_record.get('path'), 'bytes': manifest_path.stat().st_size, 'sha256': jdk_record.get('sha256')}, manifest_path, 'JDK manifest')
    manifest = read_json(manifest_path)
    for leg, tools in jdk_record.get('tools', {}).items():
        item = next((x for x in manifest.get('legs', []) if x.get('leg') == leg), None)
        need(item is not None, f'JDK manifest has no leg {leg}')
        for name, tool_record in tools.items():
            tool = Path(tool_record.get('path', ''))
            listed = item.get('jdk_tools', {}).get(name, {})
            need(Path(listed.get('path', '')).resolve(strict=True) == tool.resolve(strict=True) and listed.get('sha256') == tool_record.get('sha256'),
                 f'JDK manifest tool binding differs: {leg}/{name}')
            check_pin(tool_record, tool, f'JDK tool {leg}/{name}')

    recorded_sources = current.get('source_pins_before')
    need(isinstance(recorded_sources, dict) and recorded_sources, 'source closure pin map missing')
    live_sources = source_closure(ROOT)
    need(live_sources == recorded_sources, 'live source closure differs from the replay snapshot')

    old_cells = baseline.get('jarde_cells')
    new_cells = current.get('cells')
    new_commands = current.get('commands')
    need(isinstance(old_cells, list) and len(old_cells) == 8, 'baseline does not have eight API cells')
    need(isinstance(new_cells, list) and len(new_cells) == 8, 'replay does not have eight cells')
    need(isinstance(new_commands, list) and len(new_commands) == 8, 'replay does not have eight commands')
    need([x.get('index') for x in new_commands] == list(range(1, 9)), 'current command indexes are not 1..8')
    old_by_key = {(x['profile'], x['input_form'], x['evidence']): x for x in old_cells}
    new_by_key = {(x['profile'], x['input_form'], x['evidence']): x for x in new_cells}
    need(len(old_by_key) == 8 and set(new_by_key) == set(old_by_key), 'baseline/replay cell identities differ')
    old_commands = {x.get('index'): x for x in baseline.get('commands', [])}
    need(len(old_commands) == len(baseline.get('commands', [])), 'duplicate baseline command index')
    current_outcomes = []
    old_raw_count = 0
    current_raw_count = 0
    for cell in sorted(new_cells, key=lambda x: (x['profile'], x['input_form'], x['evidence'])):
        key = (cell['profile'], cell['input_form'], cell['evidence'])
        old_cell = old_by_key[key]
        old_command = old_commands.get(old_cell.get('command'))
        need(old_command is not None and old_command.get('exit_code') == 0 and old_command.get('guard_stop') is None,
             f'{key}: original command did not complete cleanly')
        old_argv = old_command.get('argv')
        need(isinstance(old_argv, list) and old_argv, f'{key}: original argv missing')
        need(Path(old_argv[0]).resolve(strict=True) == Path(old_cli['path']).resolve(strict=True), f'{key}: old argv CLI mismatch')
        expected_argv = [cli_record['path'], *old_argv[1:]]
        current_row = next((x for x in new_commands if x.get('index') == cell.get('command')), None)
        need(current_row is not None, f'{key}: current command row missing')
        need(cell.get('baseline_command') == old_command.get('index'), f'{key}: baseline command index changed')
        need(cell.get('argv') == expected_argv and current_row.get('argv') == expected_argv,
             f'{key}: argv differs by more than replacing argv[0]')
        need(cell.get('input') == old_cell.get('input'), f'{key}: baseline input pin differs')
        input_path = Path(old_cell['input']['path'])
        check_pin(old_cell['input'], input_path, f'{key} baseline input')
        need(input_path.as_posix() == old_argv[old_argv.index('--input') + 1], f'{key}: old argv input mismatch')

        old_report_pin = old_cell.get('report')
        need(cell.get('baseline_report') == old_report_pin, f'{key}: saved baseline report pin differs')
        old_report_path = Path(old_report_pin.get('path', ''))
        check_pin(old_report_pin, old_report_path, f'{key} old report')
        old_raw = read_raw(old_command['streams']['stdout'], BASELINE.parent, f'{key} old stdout')
        read_raw(old_command['streams']['stderr'], BASELINE.parent, f'{key} old stderr')
        old_raw_count += 2
        need(old_raw == old_report_path.read_bytes(), f'{key}: old raw stdout differs from saved JSON report')

        need(current_row.get('exit_code') == cell.get('exit_code') and current_row.get('guard_stop') is None,
             f'{key}: current command/guard status mismatch')
        need(current_row.get('cwd') == str(ROOT), f'{key}: command cwd differs from workspace root')
        peak, free = current_row.get('peak_target_bytes'), current_row.get('free_bytes_after')
        need(type(peak) is int and peak <= MAX_TARGET, f'{key}: target guard missing/exceeded')
        need(type(free) is int and free >= MIN_FREE, f'{key}: free space below 5 GiB')
        env = current_row.get('env_overrides') or {}
        need('RUST_MIN_STACK' not in env and 'CARGO_TARGET_DIR' not in env, f'{key}: child stack/target override present')
        current_stdout = read_raw(current_row['streams']['stdout'], out, f'{key} current stdout')
        read_raw(current_row['streams']['stderr'], out, f'{key} current stderr')
        current_raw_count += 2
        candidate_report_pin = cell.get('candidate_report')
        candidate_report_path = Path(candidate_report_pin.get('path', ''))
        check_pin(candidate_report_pin, candidate_report_path, f'{key} candidate report')
        need(current_stdout == candidate_report_path.read_bytes(), f'{key}: current raw stdout differs from saved report')

        outcome = {'profile': key[0], 'input_form': key[1], 'evidence': key[2],
                   'exit_code': cell.get('exit_code'), 'normalized_equal': False, 'diff_count': None}
        if cell.get('exit_code') == 0:
            left, right = normalize(json.loads(old_raw)), normalize(json.loads(current_stdout))
            diffs = diff_values(left, right)
            equal = not diffs
            need(cell.get('normalized_equal') is equal and cell.get('diff_count') == len(diffs),
                 f'{key}: saved equality/diff count does not match independent JSON comparison')
            diff_file = cell.get('difference_file')
            if diffs:
                need(isinstance(diff_file, dict), f'{key}: differences not saved')
                path = Path(diff_file.get('path', ''))
                check_pin(diff_file, path, f'{key} difference file')
                saved_diff = read_json(path)
                need(saved_diff == {'differences': diffs}, f'{key}: saved difference paths/values differ')
            else:
                need(diff_file is None, f'{key}: equal cell unexpectedly records a difference file')
            outcome.update({'normalized_equal': equal, 'diff_count': len(diffs), 'differences': diffs})
        current_outcomes.append(outcome)

    need(old_raw_count == 16 and current_raw_count == 16,
         f'expected 16 baseline and 16 replay raw streams, observed {old_raw_count}/{current_raw_count}')
    need(current.get('cli_unchanged') is True and pin(cli_path) == cli_record, 'current candidate CLI changed')
    need(current.get('input_pins_before') == current.get('input_pins_after'), 'input before/after pin maps differ')
    need(not (ROOT / 'target').exists() and not (ROOT / 'target').is_symlink(), 'workspace target is not absent now')
    equality_count = sum(row['normalized_equal'] is True for row in current_outcomes)
    difference_count = sum(row['normalized_equal'] is False for row in current_outcomes)
    return {'status': 'reviewed_equal' if difference_count == 0 else 'reviewed_with_differences',
            'schema': 'cf11-sequential-loops-current-api-independent-review-v1',
            'replay_receipt': pin(receipt_path), 'baseline_receipt': pin(BASELINE),
            'cli': cli_record, 'product_revision_argument': current['product_revision_argument'],
            'cell_count': len(current_outcomes), 'normalized_equal_cells': equality_count,
            'cells_with_differences_or_nonzero_exit': difference_count,
            'baseline_raw_streams_verified': old_raw_count, 'replay_raw_streams_verified': current_raw_count,
            'source_closure_unchanged': True, 'input_pins_unchanged': True, 'cli_unchanged': True,
            'guard_stops': 0, 'target_absent': True, 'cells': current_outcomes,
            'method': 'Recompute every saved report pin and raw stream digest; bind each replay argv to the original command with argv[0] replaced; independently normalize JSON by removing only recursive usage and elapsed_millis keys, then compare all remaining values.'}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--receipt',type=Path,default=Path('/private/tmp/jarde-sequential-loops-current-api-root-v1-20261018/execution.json'))
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    try:
        result=validate(args.receipt)
        dest=args.out.resolve()
        need(not dest.exists(),'refusing to overwrite reviewer output')
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'status':result['status'],'equal':result['normalized_equal_cells'],
                          'different':result['cells_with_differences_or_nonzero_exit'],
                          'baseline_raw_streams':result['baseline_raw_streams_verified'], 'replay_raw_streams':result['replay_raw_streams_verified'],'output':str(dest)}))
        return 0
    except (ReviewError,OSError,KeyError,TypeError,ValueError) as exc:
        print(f'REVIEW FAILED: {exc}')
        return 1

if __name__=='__main__':
    raise SystemExit(main())
