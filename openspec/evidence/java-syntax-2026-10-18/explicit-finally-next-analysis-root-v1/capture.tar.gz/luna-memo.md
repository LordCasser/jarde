# CF-16 follow-up: explicit completion from `finally`

## Status in the existing ledger

CF-16 remains one of the 71 source-level units; the ledger still records 612 test files and the CF-16 milestone still lists 24 primary `trycatch` files. It does not define `finallyReturns` or `finallyThrows` as separate leaf units or a dedicated implementation task. The current `recover-exception-only-finally-completion` change records them as independent remaining red items: its scope was `tryThrowsFinallyRuns`, and its non-goals explicitly exclude a `return` or `throw` originating in `finally` (`design.md:9-11, 29-33`; `tasks.md:14-16`). The latest CF-16 milestone likewise says the complete seven-method `FinallyCompletion` class retains both compile failures and that the 71/612 totals did not change (`cf16-milestone.md:5-9`; `results/final-matrix-root-v2/README.md:3-5`).

So these completions are known CF-16 debt, but not yet a separate planned child change. They should remain red and outside the delivered `finThrow`/`nestedFin` work. Do not mark CF-16 complete or alter its denominator based on the current change.

## JADX evidence

The four `TestFinally` family sources are not tests of abrupt completion *inside* `finally`:

- `TestFinally.TestCls.test` returns inside `try`, then conditionally calls `cursor.close()` in `finally` (`jadx-core/src/test/java/jadx/tests/integration/trycatch/TestFinally.java:13-25`).
- `TestFinally2.TestCls.test` returns a constructed `Result` inside `try`; `finally` only calls `closeQuietly` (`TestFinally2.java:16-25`).
- `TestFinally3.TestCls.test` has an early `return null` in the try body, but `finally` only calls `close` (`TestFinally3.java:19-33`). The separate `test2NoDebug` is `@NotYetImplemented`, and `testSmali` is a different input profile (`:64-80`).
- `TestFinallyExtract.TestCls.test` returns `value` from the try body; `finally` conditionally updates a field (`TestFinallyExtract.java:15-27`).

Those tests explain the CF-16 family profiles and do not directly validate the two override forms. The `MarkFinallyVisitor` source is useful algorithm evidence, not an override-completion proof: `cutHandlerBlocks` only records a rethrow exit when the last instruction is `THROW` of the initial `MOVE_EXCEPTION` result (`MarkFinallyVisitor.java:236-256`). `processTryBlock` requires a recorded rethrow block before extraction (`:198-212`); `findCommonInsns` then compares matching instructions along handler/fallthrough terminus paths (`:375-438`). A handler that returns a replacement or throws a different object does not satisfy that rethrow premise. No direct `finallyReturns`/`finallyThrows` test was found in the four-file TestFinally family.

The historical four-method `FinallyCompletion.java` at `openspec/evidence/java-syntax-2026-09-22/finally-completion/FinallyCompletion.java:19-43` documents the basic precedence shapes (`return mark(4)` in `finally`; `throw FINALLY_FAILURE` after `mark(6)`). It is an older minimal companion; use the currently sealed seven-method, 907-byte input and its pinned source/runner as the authoritative next probe, not this smaller class.

## Minimum next evidence before choosing an implementation

Use the sealed seven-method source/class/runner already retained by the current change. For `finallyReturns` and `finallyThrows` individually, collect:

1. Exact class/source pins and complete method bytecode for both javac legs; preserve all seven methods. Record exception-table rows, instruction boundaries, block edges, normal/exception exits, and every may-throw instruction.
2. The `Facts` and SSA/value graph for the pending try completion, finally copy, handler entry, finally terminal, and all values consumed by `ireturn` or `athrow`. Distinguish the saved try return or primary exception from a return/throw produced by the finally body; record producer/consumer identity and any implicit or copied cleanup operations.
3. The current Jarde public-method report and exact first Guard refusal for each method, with reader/IR completeness established before treating it as a semantic rejection. Record whether Region was entered and whether Builder staged declarations, body, cleanup, or a final return; do not infer the refusal from the earlier exception-only method.
4. Original-JVM behavior cases that force precedence: try producer returns normally or throws a known object; finally producer/cleanup completes or throws `RuntimeException`/`Error`. Record return value or escaping object identity, trace order, and whether a finally abrupt completion replaces the pending try result/exception. Run the full original seven-method class, not a pruned class.

Only after these facts should the boundary be stated: one completion type may or may not cover both override forms. `finallyReturns` replaces a pending return and can also override an exception from the try; `finallyThrows` replaces a pending return/exception with an explicit throw, while an earlier finally call can itself throw. These precedence paths differ from ordinary cleanup fallthrough and from cleanup throwing while a try exception is pending.

## Existing representations to reuse first

`FinallyCompletion` currently distinguishes `SavedReturn`, `Joined`, `Void`, and `Throws` (`crates/jarde-java/src/guard.rs:592-621`). `Void` means a real normal void completion, so it cannot stand for “no normal completion.” `Throws` specifically says the protected body throws and the handler rethrows that caught value after cleanup (`:616-620`); it must not be stretched to mean that the finally clause itself throws. `SavedReturn` represents a pending try return and does not by itself describe an overriding finally return.

Reuse the existing `Shape::Finally`/`Try.finally_body` presentation, ordinary `Return`/`Throw` statement construction, SSA identities, physical BCI ownership, and the complete Builder checkpoint/rollback path. The proof will need to say which completion is pending and which abrupt completion wins. Do not choose a new enum case or general exception-arbitration mechanism until the two real method graphs and first refusals show the smallest honest representation.

No source was modified and no Git, Cargo, JDK, Jarde CLI, JADX, network, or other toolchain command was run for this memo.
