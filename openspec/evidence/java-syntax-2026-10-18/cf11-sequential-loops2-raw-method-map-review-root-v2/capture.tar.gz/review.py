#!/usr/bin/env python3
"""Independent read-only review of the captured Seq2 original baseline."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, sys
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
OUT = Path('/private/tmp/jarde-seq2-baseline-root-v1-20261018')
PREP = Path('/private/tmp/jarde-seq2-baseline-prep-root-v5-20261018')
SOURCE = Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestSequentialLoops2.java')
SOURCE_SHA = 'adb34f80f7d55cd3309ed7708f0fdb46768cf32e4004dbd13d4e278530306720'
DRIVER = PREP / 'driver/TestSequentialLoops2Driver.java'
DRIVER_SHA = '21670301815003eff605bef518c710c033be1cae644c45365a870349aafe0175'
PARSER = PREP / 'classfile_helpers.py'
PARSER_SHA = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
METHODS = {('<init>', '()V'), ('asciiToLowerCase', '(Ljava/lang/String;)Ljava/lang/String;'), ('<clinit>', '()V')}
FIELDS = {('lowercases', '[C', 10)}

def need(c, m):
    if not c: raise ValueError(m)
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(p):
    p=Path(p).resolve(strict=True); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def load_parser():
    need(sha(PARSER.read_bytes())==PARSER_SHA,'class parser pin mismatch')
    spec=importlib.util.spec_from_file_location('seq2_physical_parser',PARSER); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def check_raw(d):
    need(d.get('status')=='captured-pending-independent-review','receipt not awaiting/ready for independent review')
    cs=d['commands']; need(len(cs)==24,'expected 24 commands')
    labels=[c['label'] for c in cs]
    expected=['original-javac8-full-source-boundary','original-compile-debug','original-compile-no-debug','compile-independent-reflection-driver']
    expected += [f'original-runtime-{p}-{j}-{m}' for p in ['debug','no-debug'] for j in ['javac8','javac23'] for m in ['default','configured128']]
    expected += ['driver-code-source-wrong-root-control','jadx-version','jarde-debug-child-default','jarde-debug-child-all','jarde-debug-bundle-child-default','jarde-debug-bundle-child-all','jadx-full-bundle-debug','jarde-no-debug-child-default','jarde-no-debug-child-all','jarde-no-debug-bundle-child-default','jarde-no-debug-bundle-child-all','jadx-full-bundle-no-debug']
    need(labels==expected,'command label/order differs')
    rc=[1]+[0]*11+[1]+[0]*11
    need([c['exit_code'] for c in cs]==rc,'command exit vector differs')
    raw_count=0
    for i,c in enumerate(cs,1):
        need(c['index']==i and c.get('guard_stop') is None,'command index/guard stop mismatch '+c['label'])
        need(c.get('peak_target_bytes',0)<=1024**3 and c.get('free_bytes_after',0)>=5*1024**3,'guard resource bound mismatch '+c['label'])
        for sn in ('stdout','stderr'):
            s=c['streams'][sn]; p=Path(s['path']).resolve(strict=True); need(p.parent==(OUT/'raw').resolve(), 'raw escaped capture directory')
            b=p.read_bytes(); need(len(b)==s['bytes'] and sha(b)==s['sha256'],f'{c["label"]} {sn} raw pin mismatch'); raw_count+=1
    need(raw_count==48,'raw stream count differs')
    need(d['counts_derived_from_commands']=={'commands':24,'raw_streams':48,'original_full_source_compiles':2,'javac8_boundary_compiles':1,'driver_compiles':1,'original_runtime_runs':8,'jarde_calls':8,'jadx_calls':3},'derived command counts differ')
    return {'commands':24,'raw_streams':raw_count,'guard_stops':0,'exit_codes':rc}

def check_pins(d):
    need(d['source_unchanged'] and d['source_unchanged_finally'] and d['target_absent'] and d['target_absent_finally'],'capture source/target closure flags fail')
    need((d['source']['bytes'],d['source']['sha256'])==(d['source_copy']['bytes'],d['source_copy']['sha256']),'full upstream Java source copy differs from source pin')
    need(pin(SOURCE)==d['source'],'upstream source bytes changed or differ')
    need(pin(OUT/'source/TestSequentialLoops2.java')==d['source_copy'],'captured source copy changed')
    need(pin(DRIVER)==d['external_input_pins_before']['driver_source'],'driver source pin mismatch')
    need(pin(OUT/'driver-source/TestSequentialLoops2Driver.java')==d['external_input_pins_before']['driver_copy'],'driver copy pin mismatch')
    need(d['external_input_pins_before']==d['external_input_pins_after']==d['external_input_pins_after_finally'],'external pin closure moved during capture')
    need(d['source_pins_before']==d['source_pins_after']==d['source_pins_after_finally'],'workspace source closure changed during capture')
    for rel,row in d['source_pins_before'].items(): need(pin(ROOT/rel)==row,f'current workspace source differs from capture: {rel}')
    # Re-hash all explicit external file pins and dependency directories.
    pins=d['external_input_pins_before']
    for k,v in pins.items():
        if isinstance(v,dict) and 'path' in v and 'sha256' in v: need(pin(v['path'])==v,f'external pin changed: {k}')
        elif k in ('dependency_artifacts',):
            for row in v: need(pin(row['path'])==row,f'dependency artifact changed: {row["path"]}')
        elif k in ('dependency_directories',):
            for root, files in v.items():
                for row in files.values(): need(pin(row['path'])==row,f'dependency class changed: {row["path"]}')
        elif k=='jdk_tools':
            for row in v.values(): need(pin(row['path'])==row,f'JDK tool changed: {row["path"]}')
    need(d['cli_sha256_argument']==d['cli']['sha256'] and pin(d['cli']['path'])==d['cli'],'CLI pin mismatch')
    need(pin(d['jadx']['path'])==d['jadx'] and pin(d['jadx_jar']['path'])==d['jadx_jar'],'JADX executable/JAR pin mismatch')
    return {'source_closure_files':len(d['source_pins_before']),'external_pin_groups':len(pins),'cli_sha256':d['cli']['sha256'],'target_absent':True}

def class_facts(path, parser):
    data=Path(path).read_bytes(); f=parser.parse_class_file(data)
    return data,f

def verify_classes(d, parser):
    need(len(d['profiles'])==2,'expected debug/no-debug profiles')
    need({p['profile'] for p in d['profiles']}=={'debug','no-debug'},'profile set differs')
    driver_pin=d['driver_classes'][0]; need(pin(driver_pin['path'])==driver_pin,'compiled independent driver class pin mismatch')
    facts={}
    for prof in d['profiles']:
        label=prof['profile']; target=prof['target']; data,f=class_facts(target['path'],parser)
        need(len(data)==target['bytes'] and sha(data)==target['sha256'],'target byte pin mismatch '+label)
        need(f['major']==52 and f['minor']==0 and f['class_name']=='jadx/tests/integration/loops/TestSequentialLoops2$TestCls','class version/name mismatch '+label)
        ms={(m['name'],m['descriptor']) for m in f['methods']}; fs={(x['name'],x['descriptor'],x['access']) for x in f['fields']}
        need(ms==METHODS and fs==FIELDS,'complete method/field inventory mismatch '+label)
        outer_path=OUT/label/'classes/jadx/tests/integration/loops/TestSequentialLoops2.class'
        outer,of=class_facts(outer_path,parser)
        need(of['major']==52 and of['class_name']=='jadx/tests/integration/loops/TestSequentialLoops2','outer full source class boundary mismatch '+label)
        need({(m['name'],m['descriptor']) for m in of['methods']}=={('<init>','()V'),('test','()V'),('testNoDebug','()V')} and not of['fields'],'outer complete source method/field inventory differs '+label)
        need(all(m['code'] is not None for m in of['methods']),'outer method Code missing '+label)
        need(all(m['code'] is not None for m in f['methods']),'child Code missing '+label)
        # Validate reported physical instruction census and exception rows independently against bytes.
        for m in f['methods']:
            code=m['code']; need(code is not None,'missing Code')
            bc=parser.decode_bcis(bytes.fromhex(code['code_hex']))
            need(bc==code['bcis'] and len(bytes.fromhex(code['code_hex']))==code['code_length'],'physical BCI census mismatch')
            for row in code['rows']: need(0<=row[0]<row[1]<=code['code_length'] and row[2] in code['bcis'],'invalid exception table row')
        tree=prof['class_tree']; actual={p.relative_to(OUT/label/'classes').as_posix():pin(p) for p in (OUT/label/'classes').rglob('*.class')}
        need(set(actual)==set(tree),'complete original class tree inventory differs '+label)
        for rel,row in tree.items(): need(actual[rel]==row,'class-tree byte pin differs '+label+'/'+rel)
        need(prof['outer']=={**prof['outer'],'path':prof['outer']['path']},'outer fact record malformed')
        facts[label]={'child':f,'outer':of,'target':target,'outer_path':str(outer_path)}
    need(d['profiles'][0]['target']['sha256']!=d['profiles'][1]['target']['sha256'],'compiler profiles unexpectedly byte-identical')
    need([m['name'] for m in facts['debug']['child']['methods']]==[m['name'] for m in facts['no-debug']['child']['methods']],'profile physical method order differs')
    # javac8 must fail because framework classes are major 55; javac23 source-8 variants compile as class major 52.
    b=d['javac8_boundary']; need(b['exit_code']==1 and b['class_files']==[] and b['major_55_diagnostic_observed'],'javac8 framework boundary was not recorded')
    stderr=Path(d['commands'][0]['streams']['stderr']['path']).read_text(errors='replace')
    need('55.0' in stderr and 'IntegrationTest.class' in stderr and ('52.0' in stderr or '错误的版本' in stderr),'javac8 major-55 harness boundary absent from raw stderr')
    return facts

def semantic(row):
    return (row['mode'],row['index'],row['input_utf16'],row['outcome'],row.get('same_object'),row.get('value_utf16'),row.get('exception_type'))

def check_runtime(d):
    runs=d['original_runtime']; need(len(runs)==8,'expected 8 original JVM runs')
    bymode={}
    for r in runs:
        need(r['exit_code']==0 and r['row_count']==8 and len(r['rows'])==8,'original runtime failed or lost rows')
        need(r['application_classpath']==[str(OUT/'driver-classes')],'target classpath leaked into application classpath')
        need(r['target_root']==str(OUT/r['profile']/'classes'),'runtime target root mismatch')
        c=d['commands'][r['command']-1]; need(c['label']==f'original-runtime-{r["profile"]}-{r["runtime"]}-{r["mode"]}','runtime command binding mismatch')
        raw=Path(r['stdout']['path']).read_bytes(); need(len(raw)==r['stdout']['bytes'] and sha(raw)==r['stdout']['sha256'],'runtime output raw pin mismatch')
        text=raw.decode('utf-8'); lines=text.splitlines(); need(len(lines)==8,'runtime stdout case count mismatch')
        need([x['raw'] for x in r['rows']]==lines,'runtime parsed rows differ from actual raw stdout')
        need(all(x['message_utf16'] is not None for x in r['rows'] if x['outcome']=='throw'),'raw throw message not retained')
        bymode.setdefault(r['mode'],[]).append((r,tuple(map(semantic,r['rows']))))
    for mode, group in bymode.items():
        need(len(group)==4,'mode lacks four profile/runtime runs')
        reference=group[0][1]
        need(all(g[1]==reference for g in group[1:]),'stable runtime behavior differs across profile/JDK: '+mode)
    need(d['original_runtime_agreement'] is True and d['runtime_semantic_agreement']=={'default':True,'configured128':True},'collector runtime agreement summary disagrees')
    # wrong root control must fail and identify expected target-root protection
    wr=d['wrong_root_control']; need(wr['exit_code']==1 and wr['rejected_expected_root'],'wrong-root control did not reject')
    c=d['commands'][wr['command']-1]; raw=Path(c['streams']['stderr']['path']).read_text(errors='replace')
    need(wr['expected_wrong_root'] in c['argv'][-1] and ('CodeSource' in raw or 'code source' in raw.lower() or 'expected' in raw.lower()),'wrong-root rejection evidence absent')
    return {'runs':8,'cases':64,'modes':{k:'4 runs agree on output/identity/type' for k in bymode},'exception_messages_compared':False,'wrong_root_rejected':True}

def utf8_boundaries(text):
    b=text.encode('utf-8'); return {0,len(b),*(i for i,x in enumerate(b) if (x&0xc0)!=0x80)}
def method_rows(report): return {(bytes(m['item']['identity']['name']).decode(),bytes(m['item']['identity']['descriptor']).decode()):m for m in report['methods']}
def map_check(report, facts, source_bytes, profile, form, evidence):
    src=report['text']; raw=src.encode('utf-8'); valid=utf8_boundaries(src); parsed=method_rows(report)
    need(set(parsed)==METHODS,'report method identity inventory mismatch')
    class_digest=facts[profile]['target']['sha256']; class_len=facts[profile]['target']['bytes']
    coverage={}; qualities={}; projection={}
    physical={ (m['name'],m['descriptor']):set(m['code']['bcis']) for m in facts[profile]['child']['methods'] }
    for key,m in parsed.items():
        need(m['outcome']['kind']=='recovered','unexpected per-method outcome kind')
        r=m['outcome']['report']; need(r.get('method')==key[0]+key[1],'method report identity mismatch')
        raw=r['text'].encode('utf-8'); valid=utf8_boundaries(r['text'])
        sm=r['source_map']; segs=sm['segments']; bcis=set()
        for s in segs:
            a,z=s['start'],s['end']; need(0<=a<z<=len(raw) and a in valid and z in valid,'source-map span is not valid UTF-8 byte range')
            origin=s['origin']; origins=[origin.get('primary')]+origin.get('derived',[])
            origins=[x for x in origins if x]
            need(origins,'source-map segment has no origin')
            for o in origins:
                mi=o['method']; need(bytes(mi['name']).decode()==key[0] and bytes(mi['descriptor']).decode()==key[1],'origin identity differs from physical method')
                own=mi['owner']['class_bytes']; need(own==report['class']['class_bytes'],'source-map owner differs from report physical class identity')
                need(own['length']==class_len,'source-map owner class length differs from input class')
                bci=o['bci']; need(bci in physical[key],'source-map BCI absent from physical Code'); bcis.add(bci)
        coverage[key[0]+key[1]]={'mapped_bcis':len(bcis),'physical_bcis':len(physical[key]),'unmapped_bcis':len(physical[key]-bcis),'text_bytes':len(raw)}
        qualities[key[0]+key[1]]={'quality':r['quality'],'fallbacks':r['fallbacks'],'outcome':r['outcome']}
        projection[key]=(m['text'],r['text'],r['quality'],r['fallbacks'],segs)
    return {str(k):v for k,v in coverage.items()},qualities,projection

def check_jarde(d, facts):
    cells=d['jarde_cells']; need(len(cells)==8,'expected eight Jarde requests')
    methods_all={}; pair_checks=[]; reports=[]; class_ids={}
    for c in cells:
        need(c['exit_code']==0,'Jarde CLI request failed')
        report_path=Path(c['report']['path']); b=report_path.read_bytes(); need(len(b)==c['report']['bytes'] and sha(b)==c['report']['sha256'],'Jarde JSON report pin mismatch')
        cmd=d['commands'][c['command']-1]; stdout=Path(cmd['streams']['stdout']['path']).read_bytes(); need(stdout==b,'Jarde stdout differs from saved report')
        obj=json.loads(b); src=Path(c['whole_source']['path']).read_bytes(); need(len(src)==c['whole_source']['bytes'] and sha(src)==c['whole_source']['sha256'],'whole Java source pin mismatch')
        need(obj['text'].encode('utf-8')==src,'report text differs from captured whole source')
        need(obj.get('execution',{}).get('status')=='complete','Jarde analysis was not Complete')
        need(obj.get('class',{}).get('class_bytes',{}).get('length')==facts[c['profile']]['target']['bytes'],'report class identity length differs from physical child class')
        need(obj.get('view',{}).get('scope',{}).get('kind')=='snapshot_all','report did not analyze full snapshot scope')
        argv=cmd['argv']; need(argv[1:3]==['class-source','--input'] and argv[3]==c['input']['path'],'Jarde CLI argv/input mismatch')
        need(argv[argv.index('--class')+1]=='jadx/tests/integration/loops/TestSequentialLoops2$TestCls','Jarde target class mismatch')
        expected_policy='single-class' if c['input_form']=='child' else 'plain-jar'
        need(argv[argv.index('--policy')+1]==expected_policy,'Jarde policy/input form mismatch')
        need(('--evidence' in argv)==(c['evidence']=='all') and ('all' in argv if c['evidence']=='all' else True),'Jarde evidence mode argv mismatch')
        physical=facts[c['profile']]['child']; pr={(m['name'],m['descriptor']):m for m in physical['methods']}
        need(len(obj['methods'])==len(METHODS),'method count differs')
        for mr in c['methods']:
            # The compact receipt carries the exact method result summary; bind to JSON method by identity.
            ident=tuple(mr['identity']); need(ident in METHODS,'unexpected compact method identity')
        coverage,quality,projection=map_check(obj, facts, src, c['profile'],c['input_form'],c['evidence'])
        class_ids[(c['profile'],c['input_form'],c['evidence'])]=obj['class']['class_bytes']
        need({tuple(x['identity']) for x in c['methods']}==METHODS,'compact identity inventory differs')
        # Compare compact values against full report, not merely the collector summary.
        for m in c['methods']:
            key=tuple(m['identity']); full=method_rows(obj)[key]; rr=full['outcome']['report']
            need(m['outcome_kind']==full['outcome']['kind'] and m['quality']==rr['quality'] and m['fallbacks']==rr['fallbacks'],'compact quality/fallback differs from raw report')
            need(m['source_map']==rr['source_map'],'compact map differs from raw report')
        methods_all[f"{c['profile']}/{c['input_form']}/{c['evidence']}"]=quality
        reports.append((c,obj,src,projection,coverage))
    # Default/all parity is required per exact profile+input mode for text and method semantics/maps.
    for prof in ['debug','no-debug']:
        for form in ['child','bundle-child']:
            a=next(x for x in reports if x[0]['profile']==prof and x[0]['input_form']==form and x[0]['evidence']=='default')
            b=next(x for x in reports if x[0]['profile']==prof and x[0]['input_form']==form and x[0]['evidence']=='all')
            need(a[2]==b[2],'default/all whole Java source differs')
            need(a[3]==b[3],'default/all per-method text/quality/fallback/source-map differs')
            pair_checks.append(f'{prof}/{form}: equal')
    for prof in ['debug','no-debug']:
        for ev in ['default','all']:
            need(class_ids[(prof,'child',ev)]['digest']==class_ids[(prof,'bundle-child',ev)]['digest'],'same target class has different child/bundle BLAKE3 identity')
    return {'requests':8,'per_request_method_count':3,'child_bundle_same_physical_class_identity':True,'default_all_pairs':pair_checks,'method_quality_fallbacks':methods_all,'source_map_coverage':{f'{c[0]["profile"]}/{c[0]["input_form"]}/{c[0]["evidence"]}':c[4] for c in reports}}

def check_jadx(d):
    need(len(d['jadx_cells'])==2,'expected two JADX full-bundle captures')
    out=[]
    for c in d['jadx_cells']:
        need(c['exit_code']==0,'JADX full-bundle command failed')
        need(c['command'] in (19,24) and d['commands'][c['command']-1]['label']==f'jadx-full-bundle-{c["profile"]}','JADX capture command/profile binding differs')
        version=Path(d['commands'][13]['streams']['stdout']['path']).read_text(errors='replace').strip(); need(version=='1.5.6','unexpected pinned JADX version output')
        target=Path(c['input']['path']); need(pin(target)==c['input'],'JADX input jar pin mismatch')
        cmd=d['commands'][c['command']-1]; need(cmd['exit_code']==0,'JADX raw command failed')
        source_rows=[]
        for s in c['sources']:
            p=Path(s['path']); need(pin(p)==s,'JADX complete output source pin mismatch'); data=p.read_bytes(); need(b'class TestSequentialLoops2' in data,'JADX source is not full expected class')
            source_rows.append(s)
        need(source_rows,'JADX captured no source output')
        out.append({'profile':c['profile'],'jar':c['input'],'sources':source_rows})
    return {'full_bundle_runs':len(out),'outputs':out}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',type=Path,default=OUT); ap.add_argument('--receipt',type=Path); ap.add_argument('--write',type=Path,required=True); args=ap.parse_args()
    receipt=args.receipt or args.out/'execution.json'; d=json.loads(receipt.read_text())
    need(receipt.resolve()==(args.out/'execution.json').resolve(),'receipt is not under expected capture')
    parser=load_parser()
    result={'schema':'jarde-seq2-baseline-independent-review-v1','receipt':pin(receipt),'capture':str(args.out.resolve()),'acceptance':'reviewing','checks':{}}
    result['checks']['raw_and_guards']=check_raw(d)
    result['checks']['closure_and_tool_pins']=check_pins(d)
    facts=verify_classes(d,parser); result['checks']['classfile_inventory']={k:{'major':v['child']['major'],'methods':len(v['child']['methods']),'fields':len(v['child']['fields']),'outer_methods':len(v['outer']['methods']),'target_sha256':v['target']['sha256']} for k,v in facts.items()}
    result['checks']['original_runtime']=check_runtime(d)
    result['checks']['jarde']=check_jarde(d,facts)
    result['checks']['jadx']=check_jadx(d)
    result['acceptance']='accepted'
    args.write.parent.mkdir(parents=True,exist_ok=True); args.write.write_text(json.dumps(result,indent=2,ensure_ascii=False)+chr(10))
    print(json.dumps({'acceptance':result['acceptance'],'receipt_sha256':result['receipt']['sha256'],'commands':24,'raw_streams':48,'original_runs':8,'Jarde_requests':8,'JADX_runs':2,'review':str(args.write)},ensure_ascii=False))
if __name__=='__main__':
    try: main()
    except Exception as exc:
        print(f'REVIEW FAILED: {type(exc).__name__}: {exc}',file=sys.stderr); raise
