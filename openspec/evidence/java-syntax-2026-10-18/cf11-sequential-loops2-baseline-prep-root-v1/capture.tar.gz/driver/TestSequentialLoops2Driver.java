import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.CodeSource;

/** Uncompiled, finite oracle driver for the unchanged TestSequentialLoops2 child class. */
public final class TestSequentialLoops2Driver {
	private static final String TARGET = "jadx.tests.integration.loops.TestSequentialLoops2$TestCls";
	private static final String FIELD = "lowercases";
	private static final String METHOD = "asciiToLowerCase";

	private TestSequentialLoops2Driver() {
	}

	public static void main(String[] args) throws Exception {
		if (args.length != 3 || !(args[0].equals("default") || args[0].equals("configured128"))) {
			throw new IllegalArgumentException("usage: TestSequentialLoops2Driver <default|configured128> <target-class-root> <expected-code-source-root>");
		}
		File classRoot = new File(args[1]).getCanonicalFile();
		File expectedRoot = new File(args[2]).getCanonicalFile();
		String mode = args[0];
		String[] cases = mode.equals("default")
				? new String[] { null, "", "\u00e9", "\ud83d\ude00", "\u0000", "a", "A", "Ab" }
				: new String[] { null, "A", "abc", "\u00e9", "\ud83d\ude00", "A\u00e9", "A\u00e9B", "ABC" };
		for (int i = 0; i < cases.length; i++) {
			runCase(mode, i, cases[i], classRoot, expectedRoot);
		}
	}

	private static void runCase(String mode, int index, String input, File classRoot, File expectedRoot) throws Exception {
		URL[] urls = new URL[] { classRoot.toURI().toURL() };
		try (URLClassLoader loader = new URLClassLoader(urls, null)) {
			Class<?> target = Class.forName(TARGET, true, loader);
			verifyTarget(target, loader, expectedRoot);
			Field tableField = target.getDeclaredField(FIELD);
			tableField.setAccessible(true);
			if (mode.equals("configured128")) {
				tableField.set(null, configuredTable());
			}
			Method conversion = target.getDeclaredMethod(METHOD, String.class);
			conversion.setAccessible(true);
			try {
				Object result = conversion.invoke(null, new Object[] { input });
				String value = (String) result;
				System.out.println("CASE mode=" + mode + " index=" + index
						+ " input=" + units(input)
						+ " outcome=return same=" + (result == input)
						+ " value=" + units(value));
			} catch (InvocationTargetException e) {
				Throwable cause = e.getCause();
				System.out.println("CASE mode=" + mode + " index=" + index
						+ " input=" + units(input)
						+ " outcome=throw type=" + cause.getClass().getName()
						+ " message=" + units(cause.getMessage()));
			}
		}
	}

	private static void verifyTarget(Class<?> target, ClassLoader expectedLoader, File expectedRoot) throws Exception {
		if (!target.getName().equals(TARGET)) {
			throw new AssertionError("wrong target class: " + target.getName());
		}
		if (target.getClassLoader() != expectedLoader || expectedLoader.getParent() != null) {
			throw new AssertionError("target was not loaded by the requested parentless loader");
		}
		CodeSource source = target.getProtectionDomain().getCodeSource();
		if (source == null || source.getLocation() == null) {
			throw new AssertionError("target has no CodeSource");
		}
		File actualRoot = new File(source.getLocation().toURI()).getCanonicalFile();
		if (!actualRoot.equals(expectedRoot)) {
			throw new AssertionError("wrong CodeSource: " + actualRoot + " expected " + expectedRoot);
		}
		target.getDeclaredConstructor();
		Method conversion = target.getDeclaredMethod(METHOD, String.class);
		if (conversion.getReturnType() != String.class || target.getDeclaredMethods().length != 1) {
			throw new AssertionError("unexpected target method inventory");
		}
		Field table = target.getDeclaredField(FIELD);
		if (table.getType() != char[].class || !java.lang.reflect.Modifier.isStatic(table.getModifiers())
				|| !java.lang.reflect.Modifier.isPrivate(table.getModifiers())
				|| target.getDeclaredFields().length != 1) {
			throw new AssertionError("unexpected target field inventory");
		}
		table.setAccessible(true);
		char[] initial = (char[]) table.get(null);
		if (initial.length != 1 || initial[0] != 'a') {
			throw new AssertionError("target did not start with the original {'a'} table");
		}
	}

	private static char[] configuredTable() {
		char[] table = new char[128];
		for (int i = 0; i < table.length; i++) {
			table[i] = (char) i;
		}
		for (char c = 'A'; c <= 'Z'; c++) {
			table[c] = (char) (c + ('a' - 'A'));
		}
		return table;
	}

	private static String units(String value) {
		if (value == null) {
			return "<null>";
		}
		StringBuilder out = new StringBuilder();
		for (int i = 0; i < value.length(); i++) {
			if (i != 0) {
				out.append(',');
			}
			String hex = Integer.toHexString(value.charAt(i));
			for (int pad = hex.length(); pad < 4; pad++) {
				out.append('0');
			}
			out.append(hex);
		}
		return out.length() == 0 ? "<empty>" : out.toString();
	}
}
