// jarde: presentation of `jadx/tests/integration/loops/TestSequentialLoops2$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestSequentialLoops2$TestCls extends java.lang.Object {
    private static char[] lowercases;

    public TestSequentialLoops2$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestSequentialLoops2$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static java.lang.String asciiToLowerCase(java.lang.String s) {
        // @method asciiToLowerCase(Ljava/lang/String;)Ljava/lang/String;
        // @declaration a static method of `jadx.tests.integration.loops.TestSequentialLoops2$TestCls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        char[] c;
        int i;
        c = null;
        i = s.length();
        while (i-- > 0) {
            char c1 = s.charAt(i);
            if (c1 <= 127) {
                char c2 = jadx.tests.integration.loops.TestSequentialLoops2$TestCls.lowercases[c1];
                if (c1 != c2) {
                    c = s.toCharArray();
                    c[i] = c2;
                    break;
                }
            }
        }
        while (i-- > 0) {
            if (c[i] <= 127) {
                c[i] = jadx.tests.integration.loops.TestSequentialLoops2$TestCls.lowercases[c[i]];
            }
        }
        return c == null ? s : new java.lang.String(c);
    }

    static {
        // @method <clinit>()V
        // @declaration a static initializer of `jadx.tests.integration.loops.TestSequentialLoops2$TestCls`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        jadx.tests.integration.loops.TestSequentialLoops2$TestCls.lowercases = new char[]{'a'};
    }
}
