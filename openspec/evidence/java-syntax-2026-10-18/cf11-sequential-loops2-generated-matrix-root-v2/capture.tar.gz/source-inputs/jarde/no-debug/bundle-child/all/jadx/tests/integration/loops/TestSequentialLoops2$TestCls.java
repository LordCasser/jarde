// jarde: presentation of `jadx/tests/integration/loops/TestSequentialLoops2$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestSequentialLoops2$TestCls extends java.lang.Object {
    private static char[] lowercases;

    public TestSequentialLoops2$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestSequentialLoops2$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static java.lang.String asciiToLowerCase(java.lang.String arg0) {
        // @method asciiToLowerCase(Ljava/lang/String;)Ljava/lang/String;
        // @declaration a static method of `jadx.tests.integration.loops.TestSequentialLoops2$TestCls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        char[] local1;
        int local2;
        local1 = null;
        local2 = arg0.length();
        while (local2-- > 0) {
            char local3 = arg0.charAt(local2);
            if (local3 <= 127) {
                char local4 = jadx.tests.integration.loops.TestSequentialLoops2$TestCls.lowercases[local3];
                if (local3 != local4) {
                    local1 = arg0.toCharArray();
                    local1[local2] = local4;
                    break;
                }
            }
        }
        while (local2-- > 0) {
            if (local1[local2] <= 127) {
                local1[local2] = jadx.tests.integration.loops.TestSequentialLoops2$TestCls.lowercases[local1[local2]];
            }
        }
        return local1 == null ? arg0 : new java.lang.String(local1);
    }

    static {
        // @method <clinit>()V
        // @declaration a static initializer of `jadx.tests.integration.loops.TestSequentialLoops2$TestCls`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        jadx.tests.integration.loops.TestSequentialLoops2$TestCls.lowercases = new char[]{'a'};
    }
}
