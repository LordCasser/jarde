package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug.jar:jadx/tests/integration/loops/TestSequentialLoops2.class */
public class TestSequentialLoops2 extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug.jar:jadx/tests/integration/loops/TestSequentialLoops2$TestCls.class */
    public static class TestCls {
        private static char[] lowercases = {'a'};

        public static String asciiToLowerCase(String str) {
            char c;
            char[] charArray = null;
            int length = str.length();
            while (true) {
                int i = length;
                length--;
                if (i > 0) {
                    char cCharAt = str.charAt(length);
                    if (cCharAt <= 127 && cCharAt != (c = lowercases[cCharAt])) {
                        charArray = str.toCharArray();
                        charArray[length] = c;
                        break;
                    }
                } else {
                    break;
                }
            }
            while (true) {
                int i2 = length;
                length--;
                if (i2 <= 0) {
                    break;
                }
                if (charArray[length] <= 127) {
                    charArray[length] = lowercases[charArray[length]];
                }
            }
            return charArray == null ? str : new String(charArray);
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().countString(2, "while (").contains(new CharSequence[]{"break;"}).containsOne("return c").countString(2, "<= 127");
    }

    @Test
    public void testNoDebug() {
        noDebugInfo();
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().countString(2, "while (").contains(new CharSequence[]{"break;"}).countString(2, "<= 127");
    }
}
