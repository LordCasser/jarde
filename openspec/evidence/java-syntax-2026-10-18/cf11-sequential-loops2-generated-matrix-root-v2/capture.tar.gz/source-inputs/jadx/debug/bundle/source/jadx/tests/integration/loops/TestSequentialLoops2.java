package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug.jar:jadx/tests/integration/loops/TestSequentialLoops2.class */
public class TestSequentialLoops2 extends IntegrationTest {

    /* JADX INFO: loaded from: debug.jar:jadx/tests/integration/loops/TestSequentialLoops2$TestCls.class */
    public static class TestCls {
        private static char[] lowercases = {'a'};

        public static String asciiToLowerCase(String s) {
            char c2;
            char[] c = null;
            int i = s.length();
            while (true) {
                int i2 = i;
                i--;
                if (i2 > 0) {
                    char c1 = s.charAt(i);
                    if (c1 <= 127 && c1 != (c2 = lowercases[c1])) {
                        c = s.toCharArray();
                        c[i] = c2;
                        break;
                    }
                } else {
                    break;
                }
            }
            while (true) {
                int i3 = i;
                i--;
                if (i3 <= 0) {
                    break;
                }
                if (c[i] <= 127) {
                    c[i] = lowercases[c[i]];
                }
            }
            return c == null ? s : new String(c);
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().countString(2, "while (").contains(new CharSequence[]{"break;"}).containsOne("return c").countString(2, "<= 127");
    }

    @Test
    public void testNoDebug() {
        noDebugInfo();
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().countString(2, "while (").contains(new CharSequence[]{"break;"}).countString(2, "<= 127");
    }
}
