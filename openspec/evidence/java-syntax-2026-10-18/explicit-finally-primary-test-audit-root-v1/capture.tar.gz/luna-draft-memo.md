# CF-16 explicit `finally` completion: bounded source audit

Date: 2026-10-18. Scope is only the 24 files assigned to CF-16 in `openspec/evidence/jadx-feature-inventory-2026-09-27/control-flow.md` (inventory lines 92-96) and enumerated by `openspec/evidence/java-syntax-2026-09-28/cf16-milestone.md` (24-file table and conclusion). No build, Git, JDK, JADX, network, or shared-tree writes were used.

## Finding

A lexical scan of the actual Java source (comments and string literals excluded) found 28 `finally` bodies in 22 of these files. None contains a Java `return` or `throw` statement. This includes nested conditionals within each body. `TestTryCatchFinally10` and `TestTryCatchFinally15` have no executable Java `finally` body in their test source; their relevant tests operate on Smali fixtures with compilation disabled. Therefore this 24-file CF-16 set supplies **no positive test for an explicit return or a new explicit throw from inside `finally`**—conditional or unconditional, overriding or otherwise. This is limited to the 24 primary files; it does not claim absence elsewhere in the 612-file inventory.

The table records each actual Java `finally` method and its body line range, with nearby test assertion location. Rows saying `—` have no Java-body candidate.

| Test source | Java `finally` method / lines | Test assertion evidence |
|---|---|---|
| `TestEmptyFinally.java` | `test`, 21-23 | test 29-32 checks catch rendering and absence of finally |
| `TestTryCatchFinally.java` | `test`, 22-24 | runtime 36-37; structural test 43-49 |
| `TestTryCatchFinally2.java` | `test2`, 34-36 | 45-51 checks one finally, `out.close()`, and body loops |
| `TestTryCatchFinally3.java` | `test`, 28-30 | 36-42 checks finally/catch and cleanup rendering |
| `TestTryCatchFinally4.java` | `test`, 21-27 | 33-40 checks nested cleanup/finally text |
| `TestTryCatchFinally5.java` | `test`, 30-32 | 62-65 checks one finally and `d.close()` |
| `TestTryCatchFinally6.java` | `test`, 21-25 | 34 onward structural assertion; second test at 48-53 |
| `TestTryCatchFinally7.java` | `test`, 22-24 | runtime 37-46; structural tests 52-57 and 63 onward |
| `TestTryCatchFinally8.java` | `test`, 31-40 | 44-52; marked `@NotYetImplemented` at 45 |
| `TestTryCatchFinally9.java` | `test`, 21-25 | 31-37 checks no extraction failure/throw text and one cleanup finally |
| `TestTryCatchFinally10.java` | — | Smali-only test, `disableCompilation()` 33-40 |
| `TestTryCatchFinally11.java` | `test`, 20-24 | runtime count at 38; structural finally assertion 42-46 |
| `TestTryCatchFinally12.java` | `test1` 22-24; `test2` 34-36; `test3` 44-46 | runtime matrix 82-92; syntax count assertion 98-100 |
| `TestTryCatchFinally13.java` | `test`, 25-27 | profile + finally assertion 46-50 |
| `TestTryCatchFinally14.java` | `test`, 20-24 | profile + cleanup/finally/two null-check assertions 36-43 |
| `TestTryCatchFinally15.java` | — | Smali-only test, `disableCompilation()` 36-42 |
| `TestTryCatchFinally16.java` | `test`, 19-21 | disabled-compilation/profile text checks 33-43 |
| `TestTryCatchFinally17.java` | `test`, 21-23 | disabled-compilation/profile text checks 36-45 |
| `TestTryCatchFinally18.java` | `test3`, 23-25 | `testJ8` is marked NYI and compilation-disabled (61-67); DX/D8 text checks 47-56 |
| `TestTryCatchFinally19.java` | `test`, 25-27 | D8 test marked NYI and compilation-disabled 44-53 |
| `TestFinally.java` | `test`, 21-25 | 53-57 checks finally and source shape |
| `TestFinally2.java` | `test`, 22-24 | 53-57 checks returns/absence of result temp; no abrupt finally |
| `TestFinally3.java` | `test`, 30-32 | 57-61 checks one finally and `close(inputStream)`; noDebug NYI at 64-70 |
| `TestFinallyExtract.java` | `test`, 22-26 | runtime 35; structure 41-47 |

Exact sources are under `/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/trycatch/`. The body-line scan is lexical evidence from these checked-in source files, not a claim that every profile/classfile lowering has been compiled and dynamically tested. In particular, the inventory explicitly treats the marked/Smali profiles as weaker or separate evidence.

## Existing JADX entry and implication

At `/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/main/java/jadx/core/dex/visitors/finaly/MarkFinallyVisitor.java:198-212`, `processTryBlock` immediately declines extraction when `rethrowBlocks` is empty. At lines 215-256, `cutHandlerBlocks` accepts handler exits only when each ends in `THROW` of the exact `MOVE_EXCEPTION` result (lines 236-248), then records those exits as rethrow blocks. At lines 375-439, `findCommonInsns` traverses corresponding handler/fallthrough paths using `SameInstructionsStrategyImpl` and records common instructions.

This is a concrete existing path for the conventional duplicated-cleanup + rethrow-same-captured-exception form. It is not evidence that the visitor models an abrupt completion originating in cleanup. A finally `return` or `throw new X` can override the protected-body completion and does not satisfy the same-captured-exception exit premise. The 24 primary tests provide no positive assertion to establish such handling. Do not infer unsupported behavior solely from the visitor precondition; make an exact JVM source/classfile probe before assigning a Jarde or ledger status.

## Next bounded evidence

If selecting this as a future CF-16 slice, take one verifier-valid source/classfile for each distinct behavior actually in scope: (1) conditional return from finally, (2) unconditional return, (3) conditional new throw, and (4) unconditional new throw, with a pending protected-body return/throw so override behavior is observable. For each, freeze original full source and class, verify original runtime ordering/exception identity, capture JADX's exact output and its compilation/runtime result, then run the same artifact through Jarde and check both source compilation and behavior. Keep profiles and finally-completion variants separate; current CF-16 scan establishes a test gap, not product behavior or an implementation design.
