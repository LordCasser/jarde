# TestNestedLoops original foreach binding: static adversarial analysis

Status: analysis only. No shared files, implementation, or OpenSpec artifacts were changed. No Cargo, JDK, CLI, network, or Git mutation was used.

## Finding

The current certificates are enough to establish useful local facts, but not enough to certify a safe declaration fold end to end.

For the outer `s1`, the AST has a blank declaration and a body assignment both at BCI 25. The current `ClassSourceAstLocalDeclaration` and `ClassSourceAstLocalAssignment` both carry name and lexical `scope_anchors`; the blank declaration has the enclosing scope, while the assignment has the outer foreach statement anchor (primary BCI 13). Joining by `(name, BCI)` is ambiguous; joining by the full statement scope path separates these two AST nodes. The assignment inventory only includes `Declare` nodes with a value and assignments, so an exact declaration match with no same-name/same-BCI/same-scope assignment can also reject initialized declaration controls without adding an initializer flag. Require each such match to be unique.

For inner `s2`, its declaration is at BCI 55 under scope anchors for outer and inner foreach statements (primary BCIs 13 and 42). Those are the AST ownership anchors. `Iterator.next` BCIs 17 and 47 are separate physical instructions and must not be used as loop scope identifiers.

`SameClassBodyValueSite` records every scanned instruction's local reads/writes as `(slot, SameClassInvokeValueFact)`. It can join the unique physical write at the target assignment BCI to its slot, reject additional writes, and use SSA definitions, uses, replacements, and phis to close the value chain. The debug-local name table can add slot/range/name evidence when present, but it cannot be required: the recorded debug and no-debug variants have the same slot roles.

The remaining gap is lexical ownership of *each physical local read*. `SameClassBodyValueSite` has BCI, opcode, slot and SSA facts, but no AST scope anchors. The local declaration and assignment inventories expose scopes for statement nodes, not local-reference expressions. Thus a complete read list alone cannot prove that every read of a reused slot belongs to the loop binding rather than to a same-slot value before or after the loop. SSA use lists identify value consumers but do not attach those consumers to AST lexical scopes. This is the first real missing relation for rejecting initialized or observable-before/after controls by proof rather than by fixture-specific BCI heuristics.

## Minimal reuse path

Keep the existing declaration, assignment, foreach and body-value records as the proof inputs. Join declaration/assignment candidates by `(name, BCI, full scope_anchors)`; join the unique write at the body assignment BCI to a physical slot and require the complete method-wide write inventory for that slot to match the intended store pattern. Preserve the existing name from the AST assignment and reject any overlapping-scope declaration collision; do not infer it from the next-call BCI or slot alone.

The narrow addition needed before an implementation can close all uses is an AST local-reference inventory that pairs each local occurrence's existing primary/derived `ClassSourceAstAnchor`s and spelling with its enclosing `scope_anchors`. Reuse that anchor representation and the already complete `SameClassBodyValueSite.local_reads`; require a unique physical-read-to-AST-local join by BCI, slot and name, then require every joined occurrence's scope path to be within the target foreach body. Missing/duplicate matches, another write, an initialized declaration, a colliding visible name, or any before/after-loop occurrence should refuse only the optional fold and preserve the accepted typed foreach projection. This is a single narrow source-to-physical-use join, not a general symbol solver or global liveness pass.

The fixed fixture's raw report map independently shows the BCI collision: the `s1` declaration maps to primary BCI 25, and the assignment segment covers both BCIs 25 and 13; the inner `s2` declaration maps to 55 under foreach anchors 42 and 13. The map documents raw `RecoveryReport.text` only and cannot substitute for a projected-text map or source-use proof.

## Pins

- Prior original-binding analysis: `/private/tmp/jarde-foreach-original-bindings-root-analysis-v2-20261018/README.md`.
- Raw-map supplement: `/private/tmp/jarde-foreach-original-bindings-map-supplement-root-v3-20261018/README.md` and `analysis.json`.
- AST declaration/assignment inventories: `crates/jarde-java/src/report.rs:3510-3795`.
- Foreach inventory and scope construction: `crates/jarde-java/src/report.rs:3800-4015`.
- Physical local read/write fact shape and capture: `src/class_source.rs:2615-2638`, `src/facade.rs:19590-19650`.
- Existing List body proof joins and unique slot/store checks: `src/facade.rs:13344-13800`.
