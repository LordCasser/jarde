# JADX invocation-argument cast reference, correction v2

This note corrects one claim in v1 without changing it. V1's example that an `Integer` argument could switch `List.remove(Object)` to `remove(int)` when an `(Object)` cast is removed was likely wrong: Java overload resolution considers strict invocation conversions first, where `Integer` widens to `Object`; the unboxing conversion needed for `remove(int)` is considered later. Do not rely on that Integer example.

A safer illustrative distinction is primitive `int i`: `raw.remove((Object) i)` boxes `i` and explicitly targets `remove(Object)`, whereas `raw.remove(i)` is an exact primitive match for `remove(int)`. This is a language-level control proposal only. No compiler was run here; root should verify both expressions with the authorized Java 8 and Java 23 toolchains before treating it as evidence.

For the fixed golden itself, the source receiver types are `List<String>` and the loop argument is `String`. `TestNestedLoops` explicitly expects `l1.remove(s2)` and `s1.equals(s2)` without casts. The `String` argument selects `List.remove(Object)`; there is no need to invoke the `remove(int)` overload. Keep this claim tied to those exact static types and descriptors. Do not generalize from it into broad cast stripping.

JADX's implementation evidence is unchanged: `MethodInvokeVisitor` resolves the actual overload candidates and generic receiver mapping, tests the compiler types for a unique applicable method, and inserts protected explicit casts when needed; `SimplifyVisitor.processCast` retains `EXPLICIT_CAST`. The code generator emits wrapped arguments as represented. Nearby tests demonstrate cases where casts must stay: `TestCastInOverloadedInvoke3` disambiguates null between `call(String)` and `call(List<String>)`; `TestGenerics4` requires a generic overload cast and marks its omit-cast test `@NotYetImplemented`.

No existing `List.remove(int)` / `remove(Object)` or primitive-wrapper control test was found by searching `jadx-core/src/test/java`. The fixed `TestNestedLoops` golden and two overload tests remain the concrete test evidence; the primitive `int` contrast is an uncompiled proposed control, not a JADX test result.

Atlas was used first, but its test-scope structural search reported partial coverage and a closure-boundary gap. The source observations are narrow and file-pinned below; this is not a claim that the full JADX test corpus has no related test.

No project files were changed and no JDK, build, test, Git, JADX CLI, or network command was run.
