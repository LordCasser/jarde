# 下一固定黄金：Object 参数包装（仅静态分析）

当前祖先Iterator叶子未交付，不在本次修改。root已读取最终26eb重放第1格完整源码：equals((java.lang.Object)s2)、l1.remove((java.lang.Object)s2)仍在，l2.add(s1)已符合JADX TestNestedLoops黄金。当前read-only事实不能冒称新增运行/实现/完成CF11。

现有report.rs 5547/5612的exact reference presentation wrapper已限定真实invoke key/descriptor参数类型、presented、同primary/derived来源链，并区分物理cast与展示cast；project_class_source_generic_edits复用事务和精确removal关联，移除只取已证明child。不能新增全局去Object cast pass。

facade.rs 12943 generic_list_member_contract已有精确List.remove(Object)Z，特意排除remove(int)E。13865 prove_generic_list_parameter_body只对call_kind1(add)产生展示cast removal；kind2(remove)当前只通过member contract，不删除。既有add证明核真实元素checkcast→唯一store→同变量load→invoke的SSA链和真实loop/scope，可考虑复用这条证据。equals是元素receiver的非List调用，不应伪装为泛型E用法；需单独核实际String owner/equals(Object)物理target和参数静态源码类型。

架构约束：明确String源码变量时，String无法适用List.remove(int)，而String.equals同名重载面须以JDK8/23既有依赖/官方事实确认。不能把任意reference（例如Integer拆箱）、未知receiver/subclass、原始真实checkcast、null/重载选择变化一概擦除。remove(Object)参数也不能用于推断List<E>。优先扩充既有call contract/窄候选与removals事务，不建新IR、scope solver或通用方法解析器。

仍需JADX具体算法/重载保留反例和当前真实IR facts，决定最小可证范围后才写OpenSpec。此处是待验证设计方向，不是已经证明所有String/重载情况。Atlas先project(open)和scoped search；旧索引report行号15376实际已到17210，故最终位置与内容以直接源读取核对。Focus context q_1a14f201abc_bf60仍in_progress，无partial结果，不把它作为缺少caller的证据。
