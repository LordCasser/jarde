# JADX invocation-argument cast reference (static only)

Scope: read-only inspection of the fixed local JADX checkout at `/Users/lordcasser/workspace/testzone/jadx`, for the residual `(Object) s2` arguments on `String.equals` and `List.remove` in Jarde's `TestNestedLoops` output. No source or product files were changed; no Git, build, test, JDK, JADX CLI, or network command was run.

## Relevant JADX behavior

- `MethodInvokeVisitor.processOverloaded` first gets candidate overloads for the actual call class/method, resolves generic type variables from the receiver and invocation, and asks whether compiler argument types uniquely resolve the expected method. It tries compiler types, substitutes unknown types, then generic formal types. If ambiguity remains, it uses formal argument types as casts (lines 102–125, 256–299, 336–349).
- `applyArgsCast` marks synthesized casts `EXPLICIT_CAST`; it also protects an existing check-cast when the chosen type equals the compiler type (177–210). `SimplifyVisitor.processCast` immediately retains `EXPLICIT_CAST`; only unprotected casts reach type-necessity, duplicate-check-cast, and outer-cast checks (roughly lines 204–235; helper conditions at 249–285). So the ordinary simplifier is deliberately not a blanket invocation-cast remover.
- Invocation codegen emits the receiver/name and then arguments; `generateMethodArguments` delegates each argument to `addArg`, and wrapped casts are emitted through the wrapped instruction (InsnGen lines 850–910, 1119–1147, 138–147). This layer does not independently infer that an argument cast is redundant.

## Fixed-golden evidence and limits

`TestNestedLoops`'s source has `List<String>` receivers and nested `String` bindings; its assertions require `s1.equals(s2)`, `l2.add(s1)`, and `l1.remove(s2)` without cast text (test lines 14–22, 34–40). This is the exact upstream formatting target. The current Jarde output described by the task still has `(Object) s2` on equals/remove and no wrapper on add; this memo does not assert Jarde's cause or claim a fix.

A targeted proof could treat these calls differently only after proving the exact receiver/call descriptor and argument static type. On this golden, `String.equals` has an `Object` formal and the exact receiver is `String`; removing the upcast leaves the same overload. `List.remove` is more delicate: `List` has `remove(int)` and `remove(Object)`. A raw or weakly typed receiver with an `Integer` actual argument can select `remove(int)` by unboxing when `(Object) value` is removed, changing index-removal into value-removal. For this fixture, the receiver is `List<String>` and the argument is `String`, so the no-cast source resolves to `remove(Object)`; retaining or removing the cast must be justified against that call identity, not by a generic assignability rule.

Two nearby JADX tests expose the danger of broad cast stripping:

- `TestCastInOverloadedInvoke3` has `call(String)` and `call(List<String>)`; it requires `call((String) null)` to preserve the selected overload.
- `TestGenerics4` has overloaded generic methods and currently requires `overload((IList<? super Object>) new ObjIList())`; its `testOmitCast` is explicitly `@NotYetImplemented`. It documents a known case where an apparently assignable argument still needs a cast in emitted code.

`String` is final and this fixture's receiver is exactly `String`, so the custom-subclass overload counterexample for `equals(String)` does not apply here. For other receiver types, a class may overload `equals(String)` alongside `equals(Object)`; removing an explicit `Object` cast can change the selected method. Keep any future logic call-specific and fail closed when receiver type, owner, descriptor, or overload set is unresolved.

## Atlas coverage note

Atlas 1.6.1 opened `/Users/lordcasser/workspace/testzone/jadx/.atlas/atlas.db`. Its status showed 42 fresh structural files; the main-source scope grew from 83 to 89 files during scoped focus, while test scope search explicitly reported partial coverage and a closure-boundary gap. Exact symbol queries found `MethodInvokeVisitor`, `InsnGen.makeInvoke`, `SimplifyVisitor`, `TestNestedLoops`, and the two overload tests, but broader test searches returned partial/empty results. Therefore this is a narrow source-backed finding, not a repository-wide absence claim. Direct read-only line inspection was used to verify the cited source excerpts after Atlas located them.
