import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/** Separately compiled driver; each target is loaded parentless from a checked CodeSource. */
public final class ObjectArgumentDriver {
    private static final class TraceList extends ArrayList<Integer> {
        final List<String> events = new ArrayList<String>();
        TraceList() { super.add(Integer.valueOf(1)); super.add(Integer.valueOf(2)); }
        public Integer remove(int index) {
            events.add("remove-int:" + index);
            return super.remove(index);
        }
        public boolean remove(Object value) {
            events.add("remove-object:" + value);
            return super.remove(value);
        }
        String state() { return super.toString(); }
    }

    private static String descriptor(Method method) {
        StringBuilder out = new StringBuilder("(");
        for (Class<?> parameter : method.getParameterTypes()) out.append(typeDescriptor(parameter));
        return out.append(')').append(typeDescriptor(method.getReturnType())).toString();
    }

    private static String typeDescriptor(Class<?> type) {
        if (type.isArray()) return type.getName().replace('.', '/');
        if (!type.isPrimitive()) return "L" + type.getName().replace('.', '/') + ";";
        if (type == void.class) return "V";
        if (type == boolean.class) return "Z";
        if (type == byte.class) return "B";
        if (type == char.class) return "C";
        if (type == short.class) return "S";
        if (type == int.class) return "I";
        if (type == long.class) return "J";
        if (type == float.class) return "F";
        if (type == double.class) return "D";
        throw new AssertionError(type);
    }

    private static URL checkedTarget(String actualRoot, String expectedRoot, String className,
                                     URLClassLoader loader) throws Exception {
        Class<?> target = Class.forName(className, false, loader);
        URL code = target.getProtectionDomain().getCodeSource().getLocation();
        URL expected = Paths.get(expectedRoot).toRealPath().toUri().toURL();
        if (target.getClassLoader() != loader || !code.toURI().normalize().equals(expected.toURI().normalize()))
            throw new IllegalStateException("wrong CodeSource: " + code + " expected " + expected);
        return code;
    }

    private static Object invoke(URLClassLoader loader, String className, String methodName,
                                 Class<?>[] parameters, Object[] arguments) throws Exception {
        Class<?> target = Class.forName(className, true, loader);
        Method method = target.getMethod(methodName, parameters);
        String exception = "none";
        String returned = "unset";
        try {
            returned = String.valueOf(method.invoke(null, arguments));
        } catch (InvocationTargetException error) {
            Throwable cause = error.getCause();
            exception = cause == null ? "unknown" : cause.getClass().getName();
        }
        String state = arguments.length > 0 && arguments[0] instanceof TraceList
                ? ((TraceList) arguments[0]).state() : "-";
        String events = arguments.length > 0 && arguments[0] instanceof TraceList
                ? String.join(",", ((TraceList) arguments[0]).events) : "-";
        System.out.println("CASE class=" + className + " method=" + methodName
                + " descriptor=" + descriptor(method) + " exception=" + exception
                + " return=" + returned + " state=" + state + " events=" + events);
        return target;
    }

    private static void removal(String actualRoot, String expectedRoot, String methodName,
                                Class<?> valueType, Object value) throws Exception {
        URL actual = Paths.get(actualRoot).toRealPath().toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(new URL[] { actual }, null)) {
            checkedTarget(actualRoot, expectedRoot, "controls.RemovalCases", loader);
            TraceList list = new TraceList();
            invoke(loader, "controls.RemovalCases", methodName,
                    new Class<?>[] { List.class, valueType }, new Object[] { list, value });
        }
    }

    private static void equality(String actualRoot, String expectedRoot, String methodName)
            throws Exception {
        URL actual = Paths.get(actualRoot).toRealPath().toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(new URL[] { actual }, null)) {
            checkedTarget(actualRoot, expectedRoot, "controls.EqualityCases", loader);
            Class<?> target = Class.forName("controls.EqualityCases", true, loader);
            Class<?> receiverType = Class.forName("controls.EqualityCases$Receiver", true, loader);
            Object receiver = receiverType.getConstructor().newInstance();
            Method method = target.getMethod(methodName, receiverType, String.class);
            Object result = method.invoke(null, receiver, "needle");
            String selected = String.valueOf(receiverType.getMethod("selected").invoke(receiver));
            System.out.println("CASE class=controls.EqualityCases method=" + methodName
                    + " descriptor=" + descriptor(method) + " exception=none return=" + result
                    + " detail=" + selected);
        }
    }

    private static void explicitCast(String actualRoot, String expectedRoot, Object value,
                                    String caseName) throws Exception {
        URL actual = Paths.get(actualRoot).toRealPath().toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(new URL[] { actual }, null)) {
            checkedTarget(actualRoot, expectedRoot, "controls.ExplicitCastCases", loader);
            Class<?> target = Class.forName("controls.ExplicitCastCases", true, loader);
            Class<?> receiverType = Class.forName("controls.ExplicitCastCases$Receiver", true, loader);
            Object receiver = receiverType.getConstructor().newInstance();
            Method method = target.getMethod("equalsExplicitCast", receiverType, Object.class);
            String exception = "none";
            String returned = "unset";
            try {
                returned = String.valueOf(method.invoke(null, receiver, value));
            } catch (InvocationTargetException error) {
                Throwable cause = error.getCause();
                exception = cause == null ? "unknown" : cause.getClass().getName();
            }
            System.out.println("CASE class=controls.ExplicitCastCases method=equalsExplicitCast"
                    + " input=" + caseName + " descriptor=" + descriptor(method)
                    + " exception=" + exception + " return=" + returned);
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 6) throw new IllegalArgumentException(
                "usage: removal-root removal-expected equality-root equality-expected cast-root cast-expected");
        removal(args[0], args[1], "removeObject", int.class, Integer.valueOf(1));
        removal(args[0], args[1], "removeInt", int.class, Integer.valueOf(1));
        removal(args[0], args[1], "removeInteger", Integer.class, Integer.valueOf(1));
        equality(args[2], args[3], "equalsObject");
        equality(args[2], args[3], "equalsString");
        explicitCast(args[4], args[5], "needle", "valid-string");
        explicitCast(args[4], args[5], Integer.valueOf(1), "wrong-integer");
        explicitCast(args[4], args[5], null, "null");
    }
}
