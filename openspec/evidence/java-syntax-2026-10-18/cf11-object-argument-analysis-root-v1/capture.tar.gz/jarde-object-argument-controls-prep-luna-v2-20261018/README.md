# Object-argument controls v2 (source preparation only)

This bundle preserves v1 elsewhere and fixes its test isolation. The three target classes are separate from the unchanged `TestNestedLoops$TestCls` loop positive, so target-wide recovery output for one control cannot change another control's presentation.

`RemovalCases` uses the same runtime value (`1`) and fresh `[1, 2]` list for all rows. Its methods differ only in the static argument type and explicit source cast: `removeObject(List<Integer>, int)` calls `remove((Object) value)`, `removeInt(List<Integer>, int)` calls `remove(value)`, and `removeInteger(List<Integer>, Integer)` calls `remove(value)`. The last overload choice is intentionally unknown until the generated classfiles are inspected on both javac versions.

`EqualityCases` compares calls on one custom receiver that implements `equals(Object)` and `equals(String)`: one call passes `(Object) value`, the other passes a `String`. `ExplicitCastCases` isolates a real cast on the invocation argument, `(String) value`, and the driver observes a valid string, an Integer that should raise `ClassCastException`, and null. These rows distinguish removable presentation from overload selection and a semantic cast.

The driver is compiled separately. It loads each target through a parentless `URLClassLoader`; it calls `Class.forName(..., false, loader)` and verifies the target's loader and CodeSource before initializing or invoking it. It prints erased JVM method descriptors (computed from reflection parameter and return types), exception, return value, and list/event state where relevant. Wrong-root input should stop at the CodeSource check. No runtime result is asserted here.

The loop positive is reused from the already captured original-final matrix, not rebuilt in this preparation. Its exact source, existing driver, generated debug class bytes, and source receipt are copied into `reused-positive/` with their originating paths/hashes recorded below and in `pins.json`:

- Receipt: `/private/tmp/jarde-typed-foreach-original-final-root-v1-20261018/execution.json`, 6,329,781 bytes, SHA-256 `433b6a723137adb4aed904b2c7935079821def5b1b91f1593630c224bc73f439`.
- Java source: `/private/tmp/jarde-typed-foreach-original-final-root-v1-20261018/source/jadx/tests/integration/loops/TestNestedLoops.java`, 876 bytes, SHA-256 `4897fd18a15fce6e0abb40dc8afc6c7a3fa9f16e617f3c7e5e88072f6a37309e`.
- Driver: `/private/tmp/jarde-typed-foreach-original-final-root-v1-20261018/driver-source/TestNestedLoopsDriver.java`, 5,601 bytes, SHA-256 `4534f142ad673595898a581ebb474a0d2783cbd974b403f8c658e74792e59df0`.
- Raw copied debug class: `/private/tmp/jarde-typed-foreach-original-final-root-v1-20261018/debug/classes/jadx/tests/integration/loops/TestNestedLoops$TestCls.class`, 1,356 bytes, SHA-256 `4741538cc0ef1ba378cca4fccc8505007956a6b14520a1808c3874d7ea167e2c`.

No collector is included, and no source was compiled or executed. The overload selected for `Integer`, actual physical descriptors/opcodes, and all generated/runtime behavior remain for root's prescribed dual-JDK checks after the next specification is reviewed. No production implementation or new recovery mechanism is proposed.
