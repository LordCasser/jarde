# 下一固定黄金的范围选择（静态，未实施）

承接root-v1及JADX-static-luna-v2更正。root核当前build.rs 30148附近的arguments_with_parameter_offset：它按descriptor参数归一化，不接收owner/name/CallTarget；因此不能把String→Object可赋值当成同重载证明并全局删cast。把两个特例塞进这个descriptor-only入口会要求扩大调用上下文，当前没有必要。

优先在现有ClassSource opaque AST的generic edits/removals事务内，复用物理invoke key、精确presentation wrapper和元素cast→store→load证据，补明确标准调用契约。raw方法/物理map保持原始可靠表示，完整类/方法源码投影去掉展示包装。List.remove(Object)已经是closed member contract(kind2)，目前只有add(kind1)规划removal；equals需要精确String receiver/owner/descriptor证据，不应伪装为List<E>泛型调用。是否能复用现有全部必要facts仍待真实当前IR核验，尚无新Spec或代码。

JADX MethodInvokeVisitor重载解析失败时显式保护cast，SimplifyVisitor保留EXPLICIT_CAST；可借其先确定调用选择再简化的原则，不能只借去cast动作。Luna静态v1误称Integer去Object cast会拆箱选int，已被root审查撤回并在独立v2更正：应分严格引用扩宽与后续拆箱阶段。确切控制改为同value=1的primitive int `(Object)value`与int值路径；Integer结果待双编译器测量，不能预设错误oracle。

控制prep-v1还有不同实参、receiver cast代替argument cast、toGenericString伪称descriptor问题，root未接受为可执行控制；prep-v2分别修正为同实参、真实equals((String)value)参数CHECKCAST和erased JVM descriptor，保留v1。未来root须完整审driver/CodeSource/实际字节再执行，不能把静态准备算运行覆盖。现有完整TestNestedLoops源/driver正例复用，不新造循环形态。

本片ancestor产品ea2aaf042正在两fresh native/自身CI验收；此分析不更改其源码、证据判据或CF11/71/612计数。
