# 可选展示清理不能使已证明的泛型/foreach 降级

当前add(kind1)的用途证明是既有List<E>参数约束，缺证可拒绝其整个既有candidate。remove(kind2)已被member contract接受但没有E约束，equals也不是List<E>用法。不能简单把if call_kind==1扩为1或2然后复用所有return None：新可选清理失败会撤回原来已可靠的List泛型、typed头和绑定，这违反本目标。

后续设计应把已存在的元素物理cast→唯一store→local load→invoke证明提取到窄可复用函数（返回既有Type/Option即可，无新公共证书），原add保留原语义；对remove/equals逐site仅在完整证据存在时追加既有presentation_removals，缺证保留原包装并继续原可靠candidate，Stop仍传播，不降级普通缺证。remove的String实际类型不应用于推断接收者List<E>，例如List<Number>.remove(String)本来合法。

String.equals仅精确String源码receiver与标准equals(Object)Z；List.remove仅精确受证List源码receiver与remove(Object)Z且参数源码类型排除会改重载的转换。首片可限定物理String cast局部这一已需黄金，不建全局overload resolver。ClassSource call-target/provenance匹配及既有generic edits事务已存在；raw方法/map继续保留，其可编译性归属原始表示平面，最终class投影才作展示优化。

此为源码审查所得约束，尚未对下一片运行或实施；须在下一OpenSpec中明确，并以缺证/同名/物理cast/primitive int等控制实际验证。
