# Object-argument presentation controls (source preparation only)

This private bundle is a small follow-up test-family proposal for the next OpenSpec after the iterator-ancestor change. It keeps the established full `TestNestedLoops$TestCls` positive artifact available by exact copy from the already accepted original-final generated debug tree; its bytes are pinned below. The new controls are separate target classes so a refusal case cannot alter the whole-class presentation of the positive loop.

The three target sources cover:

- `RemovalCases`: explicit `(Object)` removal, primitive `int` removal, and an `Integer` argument passed to overloaded `List.remove`. The last case is intentionally a measurement question: no expected overload is asserted until javac 8 and 23 classfiles are inspected.
- `EqualityCases`: same receiver with `equals((Object) value)` versus `equals(value)` and distinct `equals(Object)` / `equals(String)` implementations, exposing which overload was selected.
- `ExplicitCastCases`: a real source-level `(String)` checkcast followed by dereference. It must remain semantic and must not be removed as an argument-presentation wrapper.

`ObjectArgumentDriver.java` is meant to be compiled separately from each target root. It loads each target through a parentless `URLClassLoader`, verifies the actual CodeSource against the supplied expected root, invokes by exact reflective parameter types, and prints return/exception/list-state/overload observations. Supply distinct actual/expected roots for removal, equality, and explicit-cast target builds. A wrong-root run should fail before method invocation.

No collector is included. No source was compiled or executed, and no javac overload result or decompiler output is claimed. Root should first inspect the future specification and then compile the four target classes with the prescribed JDKs and debug settings, inspect descriptors/instructions, and derive runtime oracles. These controls need no new production mechanism; they only distinguish Object-argument presentation from overload resolution and real checkcasts.
