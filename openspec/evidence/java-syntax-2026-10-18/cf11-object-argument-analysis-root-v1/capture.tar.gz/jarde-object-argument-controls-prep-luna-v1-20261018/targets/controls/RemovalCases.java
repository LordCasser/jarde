package controls;

import java.util.ArrayList;
import java.util.List;

/** Small overload controls: preserve the target's physical call descriptors. */
public final class RemovalCases {
    private RemovalCases() { }

    public static boolean removeObject(List<Integer> values) {
        return values.remove((Object) Integer.valueOf(2));
    }

    public static Integer removeInt(List<Integer> values) {
        return values.remove(0);
    }

    /** Whether javac selects remove(Object) or unboxes to remove(int) is to be measured. */
    public static boolean removeInteger(List<Integer> values, Integer index) {
        return values.remove(index);
    }

    public static List<Integer> values() {
        List<Integer> result = new ArrayList<Integer>();
        result.add(Integer.valueOf(1));
        result.add(Integer.valueOf(2));
        return result;
    }
}
