package controls;

/** Receiver overload controls distinguish an invocation cast from an explicit cast. */
public final class EqualityCases {
    private EqualityCases() { }

    public static final class Receiver {
        private String selected = "unset";
        public boolean equals(Object value) {
            selected = "Object";
            return value instanceof String && "needle".equals(value);
        }
        public boolean equals(String value) {
            selected = "String";
            return "needle".equals(value);
        }
        public String selected() { return selected; }
    }

    public static boolean equalsObject(Receiver receiver, String value) {
        return receiver.equals((Object) value);
    }

    public static boolean equalsString(Receiver receiver, String value) {
        return receiver.equals(value);
    }
}
