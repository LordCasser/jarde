package controls;

/** A physical checkcast is semantic and must not be treated as a display wrapper. */
public final class ExplicitCastCases {
    private ExplicitCastCases() { }

    public static int explicitStringCast(Object value) {
        return ((String) value).length();
    }
}
