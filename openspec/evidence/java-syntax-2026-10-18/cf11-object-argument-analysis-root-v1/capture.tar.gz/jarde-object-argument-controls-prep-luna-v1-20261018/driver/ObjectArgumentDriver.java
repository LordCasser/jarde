import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/** Driver is compiled separately and loads only target classes from the selected root. */
public final class ObjectArgumentDriver {
    private static final class TraceList extends ArrayList<Integer> {
        final List<String> events = new ArrayList<String>();
        TraceList() { super.add(Integer.valueOf(1)); super.add(Integer.valueOf(2)); }
        public Integer remove(int index) {
            events.add("remove-int:" + index);
            return super.remove(index);
        }
        public boolean remove(Object value) {
            events.add("remove-object:" + value);
            return super.remove(value);
        }
        String state() { return super.toString(); }
    }

    private static void invoke(String actualRoot, String expectedRoot, String className,
                               String methodName, Class<?>[] parameters, Object[] arguments,
                               Object receiverForState, String stateMethod) throws Exception {
        URL actual = Paths.get(actualRoot).toRealPath().toUri().toURL();
        URL expected = Paths.get(expectedRoot).toRealPath().toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(new URL[] { actual }, null)) {
            Class<?> target = Class.forName(className, true, loader);
            URL code = target.getProtectionDomain().getCodeSource().getLocation();
            if (target.getClassLoader() != loader || !code.toURI().normalize().equals(expected.toURI().normalize()))
                throw new IllegalStateException("wrong CodeSource: " + code + " expected " + expected);
            Method method = target.getMethod(methodName, parameters);
            String exception = "none";
            String returned = "unset";
            try {
                returned = String.valueOf(method.invoke(null, arguments));
            } catch (InvocationTargetException error) {
                Throwable cause = error.getCause();
                exception = cause == null ? "unknown" : cause.getClass().getName();
            }
            String state = receiverForState instanceof TraceList
                    ? ((TraceList) receiverForState).state() : "-";
            String detail = "-";
            if (receiverForState != null && stateMethod != null) {
                detail = String.valueOf(receiverForState.getClass().getMethod(stateMethod).invoke(receiverForState));
            }
            String events = receiverForState instanceof TraceList
                    ? String.join(",", ((TraceList) receiverForState).events) : "-";
            System.out.println("CASE class=" + className + " method=" + methodName
                    + " descriptor=" + method.toGenericString() + " exception=" + exception
                    + " return=" + returned + " state=" + state + " detail=" + detail
                    + " events=" + events);
        }
    }

    private static void invokeEquality(String actualRoot, String expectedRoot, String methodName)
            throws Exception {
        URL actual = Paths.get(actualRoot).toRealPath().toUri().toURL();
        URL expected = Paths.get(expectedRoot).toRealPath().toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(new URL[] { actual }, null)) {
            Class<?> target = Class.forName("controls.EqualityCases", true, loader);
            URL code = target.getProtectionDomain().getCodeSource().getLocation();
            if (target.getClassLoader() != loader || !code.toURI().normalize().equals(expected.toURI().normalize()))
                throw new IllegalStateException("wrong CodeSource: " + code + " expected " + expected);
            Class<?> receiverClass = Class.forName("controls.EqualityCases$Receiver", true, loader);
            Object receiver = receiverClass.getConstructor().newInstance();
            Method method = target.getMethod(methodName, receiverClass, String.class);
            String exception = "none";
            String returned = "unset";
            try {
                returned = String.valueOf(method.invoke(null, receiver, "needle"));
            } catch (InvocationTargetException error) {
                Throwable cause = error.getCause();
                exception = cause == null ? "unknown" : cause.getClass().getName();
            }
            String selected = String.valueOf(receiverClass.getMethod("selected").invoke(receiver));
            System.out.println("CASE class=controls.EqualityCases method=" + methodName
                    + " descriptor=" + method.toGenericString() + " exception=" + exception
                    + " return=" + returned + " state=- detail=" + selected + " events=-");
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 6) throw new IllegalArgumentException(
                "usage: removal-root removal-expected equality-root equality-expected cast-root cast-expected");
        TraceList objectList = new TraceList();
        invoke(args[0], args[1], "controls.RemovalCases", "removeObject",
                new Class<?>[] { java.util.List.class }, new Object[] { objectList }, objectList, null);
        TraceList intList = new TraceList();
        invoke(args[0], args[1], "controls.RemovalCases", "removeInt",
                new Class<?>[] { java.util.List.class }, new Object[] { intList }, intList, null);
        TraceList integerList = new TraceList();
        invoke(args[0], args[1], "controls.RemovalCases", "removeInteger",
                new Class<?>[] { java.util.List.class, Integer.class },
                new Object[] { integerList, Integer.valueOf(0) }, integerList, null);

        invokeEquality(args[2], args[3], "equalsObject");
        invokeEquality(args[2], args[3], "equalsString");

        invoke(args[4], args[5], "controls.ExplicitCastCases", "explicitStringCast",
                new Class<?>[] { Object.class }, new Object[] { Integer.valueOf(7) }, null, null);
    }
}
