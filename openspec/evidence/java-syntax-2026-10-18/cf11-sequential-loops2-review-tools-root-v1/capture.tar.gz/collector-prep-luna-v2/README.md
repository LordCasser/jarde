# Seq2 complete-source rebuild matrix preparation (v2)

This private collector prepares a fresh, read-only-source matrix for `TestSequentialLoops2`. It has **not been executed**; it runs no compiler, JVM, Jarde, JADX, Git, Cargo, or network operation during preparation. The only preparation check performed was Python AST/bytecode syntax parsing.

The pinned baseline receipt is `/private/tmp/jarde-seq2-baseline-root-v1-20261018/execution.json` (7,420,920 bytes; SHA-256 `9811af1be7efd2d5f4ce38d7ed7ae1ce426ca5f30de9b6cac8b4344553211a37`). Its source grid is eight Jarde outputs (debug/no-debug × child/bundle-child × default/all) plus two complete JADX outer-class outputs (debug/no-debug). The Jarde outputs contain one nested child class each. The JADX outputs retain the enclosing JUnit class and nested child; compiling the Jarde child source is not described as recompiling the enclosing class.

On a later root-authorized run, the script copies each saved Java source byte-for-byte into its package-correct filename and attempts 10 × 2 compiler combinations. It retains failures as compile outcomes and does not run a failed compile. For successful outputs it records every class file and independently parsed class/method/field access, every Code body and physical BCI. Runtime execution uses the frozen reflection driver with only driver classes on the application classpath; target classes are loaded from the rebuilt root by the driver's parentless URLClassLoader. Each compile output is tested under both pinned JVMs in default and configured128 modes; wrong-CodeSource expectation is checked once per successful target output. Runtime semantic comparison is tied to the same source profile, runtime and mode in the baseline: return UTF-16 and identity are checked; thrown exception type is checked; raw exception messages are retained but not required to match across runtimes.

The collector also re-reads external pins, helper/JDK pins, dependency class trees, and source closure at the end, and uses the existing 5 GiB/1 GiB/default-stack command guard and 30-second runtime wrapper. The historical baseline receipt currently says `captured-pending-independent-review`; this preparation does not upgrade that status or claim any generated compilation/runtime result.

Run only after review, with a fresh output path, using `python3 -B collect_generated_matrix.py --out /private/tmp/<fresh-output>`. Do not reuse an output directory.


## v2 review corrections

This frozen v2 adds a preflight refusal if the current workspace source closure differs from the baseline capture, and checks the frozen driver’s actual `wrong CodeSource:` diagnostic for the negative control. The v1 directory is unchanged. No collector or external tool was executed.
