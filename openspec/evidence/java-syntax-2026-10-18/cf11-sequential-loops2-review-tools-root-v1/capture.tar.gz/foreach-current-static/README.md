# TestNestedLoops foreach 当前架构核对

这是对当前源码的静态核对 memo；没有运行 CLI、构建器、JDK、Git 或网络操作，也没有编辑共享文件。源码快照 SHA-256：`crates/jarde-java/src/build.rs`，1,973,368 bytes，`e3f201df7bd01b9b0691d5f7229cbfd5efd82ce5b70fdd39f0f003170fe51b39`。

## 结论

目前没有证据要求再新增“Iterator 声明与 `iterator()` 初始化分离”的支持。当前 `iterable_for_each_candidate` 已允许候选循环前的 Iterator 初始化语句是 `Assign` 或 `Declare(Some(init))`，之后通过 `iterator_declaration_for_loop` 对同一 `LocalVariable` 的 init/test/next 位置做身份核验；该 helper 也已显式处理空声明在当前 statement list、或由 `DeclarationPlacement::Elevated`/祖先 owner 提供的情况，并要求 owner 的真实 declaration row 唯一。若 owner 行不在活动列表，则只返回祖先所有权标志，避免误删别的 statement list 的索引。位置：`build.rs:23326-23350`、`23465-23490`、`13249-13439`。

固定 TestNestedLoops 的当前永久正例已经覆盖这种分离形：`tests/p3_hoisted_iterator_foreach.rs:209` 的 `nested_iterators_project_and_preserve_the_outer_assignment_and_cast` 检查两个 foreach，并检查外层 header 后仍保留 `s1 = (java.lang.String) iteratorElement17;`。相关负控在同文件 `:416`，以及 `tests/p3_iterable_foreach.rs:172`（额外 next 消费、iterator escape）。helper 的 owner/缺失行/incomplete placement 负例在 `build.rs:38166` 起的 `iterator_declaration_gate_uses_real_local_owner_and_refuses_incomplete_facts`。

当前已知的呈现差异要与 iterator 初始化分离区分：这个正例输出 Object foreach header，并把原来的 String cast/assignment 留在 body；若目标是 `for (String s1 : l1)` 这属于 typed element/header 与 cast/目标绑定呈现，不能通过放宽 Iterator 声明或初始化所有权来解决。完整源码候选记录也明确保留 Object header + 原 cast assignment（`openspec/changes/recover-proved-iterator-assignment-foreach/design.md` 的 Decisions 1–3）。

## 历史 same-IR 记录的边界

`cf11-testnestedloops-same-ir-root-v2`/`v3` 是此前变更之前的诊断：v2 记 outer BCI 13 在首句 `Assign` 被入口拒绝；v3 记 inner BCI 42 的旧首拒 `iterator_declaration_before_init`，outer 仍被旧首句 gate 拒绝。这些准确描述当时的候选实现，不能当作当前首拒或当前缺失能力。当前代码与后续永久测试已有相应 assignment 入口和 elevated declaration helper，因此若仍观察到 `while`，需先对当前 CLI/API 重新取证，不能沿用旧 stage 名称。

## 若新观察仍有 while，先采这些当前证据

1. 固定完整输入 class、owner/method/descriptor、CLI 及原始 output/report；保存 method-local quality/fallback、完整 AST/region 和每个相关 source-map BCI。先判断差异是候选仍为 while，还是仅 foreach 元素类型/作用域呈现不同。
2. 对实际候选循环记录 test/header BCI、首 body statement 类型、`iterator()` init statement 的种类/BCI，以及 init/test/next load 的 slot 和 `reuse.variable_at` 结果；记录 Iterator `LocalVariable`、`declared`、`DeclarationPlacement`、活动 list 的准确声明行，以及 Elevated owner 的 `Declarations::at_region` 完整匹配数。
3. 记录 iterator value/phi/use、next 返回值到 binding 的唯一消费、gap 写入与 effects/handler coverage 的实际 verdict。只定位到完整 candidate proof 内的真实首拒后，才讨论补丁；一个相同 printed name 或旧入口拒绝不够。
4. 使用已有 `p3_hoisted_iterator_foreach.rs` 正例及其 cast、extra-next、escape 控制作行为边界；如确有新的合法形状，先将其作为固定完整输入/API 正例，并针对该形状增加最窄负控，不改通用声明计划。

最低限度的候选方向是继续复用当前 helper 和完整 iterator certificate；只在新证据证明某一受控 owner/list 形态仍未表达时扩展该精确所有权路径。不要新增第二个 split-initializer solver，也不要按名字或 AST 文本移动声明。当前没有证据支持任何更广的机制。
