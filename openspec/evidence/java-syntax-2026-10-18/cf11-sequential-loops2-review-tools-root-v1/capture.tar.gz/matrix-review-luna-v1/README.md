# Seq2 generated-source matrix independent reviewer

This private reviewer is prepared for the collector v3-compatible terminal receipt under the path passed with --out. It independently checks complete-source inputs, compile commands/results, class trees and physical Code/BCI facts, rebuilt runtime raw outputs against the accepted original baseline oracle, CodeSource rejection controls, source/tool pins, and resource guards. It will reject a running or failed capture. It was prepared but not run against the failed v1 capture; root is running v2.

After root confirms a terminal capture, run:

    python3 -B /private/tmp/jarde-seq2-generated-matrix-review-luna-v1-20261018/review.py --out /private/tmp/jarde-seq2-generated-matrix-root-v2-20261018 --write /private/tmp/jarde-seq2-generated-matrix-review-luna-v1-20261018/root-independent-review.json

No Java, Jarde, Cargo, Git, or network commands are invoked by this script.
