#!/usr/bin/env python3
"""Independent read-only review for a terminal generated Seq2 source matrix."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, re, sys
from pathlib import Path
sys.dont_write_bytecode = True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
BASE=Path('/private/tmp/jarde-seq2-baseline-root-v1-20261018')
BASE_SHA='9811af1be7efd2d5f4ce38d7ed7ae1ce426ca5f30de9b6cac8b4344553211a37'
BASE_REVIEW=Path('/private/tmp/jarde-seq2-baseline-review-luna-v1-20261018/root-independent-review.json')
BASE_REVIEW_SHA='141c6be88faa867f571d4166b3215119601ebb88c2d1a20446ddf4d5184f2581'
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v5-20261018/classfile_helpers.py')
PARSER_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
COMPARE=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
INTERNAL='jadx/tests/integration/loops/TestSequentialLoops2$TestCls'
OUTER='jadx/tests/integration/loops/TestSequentialLoops2'
PROFILES={'debug','no-debug'}
COMPILERS={'javac8','javac23'}
MODES={'default','configured128'}
EXPECTED_INPUTS={
'default':['<null>','<empty>','00e9','d83d,de00','0000','0061','0041','0041,0062'],
'configured128':['<null>','0041','0061,0062,0063','00e9','d83d,de00','0041,00e9','0041,00e9,0042','0041,0042,0043']}
PATTERN=re.compile(r'^CASE mode=(default|configured128) index=(\d+) input=(\S+) outcome=(return|throw) (.+)$')

def need(ok,msg):
    if not ok: raise ValueError(msg)
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(path):
    p=Path(path).resolve(strict=True); b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path); need(spec and spec.loader,'cannot import '+str(path))
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def source_semantics(rows):
    out=[]
    for r in rows:
        x={k:r[k] for k in ('mode','index','input_utf16','outcome')}
        if r['outcome']=='return': x.update(same_object=r['same_object'],value_utf16=r['value_utf16'])
        else: x['exception_type']=r['exception_type']
        out.append(x)
    return out
def parse_rows(raw,mode):
    rows=[]
    for line in raw.decode('utf-8','strict').splitlines():
        m=PATTERN.fullmatch(line); need(m is not None,'malformed runtime output '+repr(line))
        mm,ix,units,outcome,tail=m.groups(); i=int(ix)
        need(mm==mode and i==len(rows) and i<8 and units==EXPECTED_INPUTS[mode][i],'runtime input/order differs '+repr(line))
        if outcome=='return':
            q=re.fullmatch(r'same=(true|false) value=(<null>|<empty>|[0-9a-f]{4}(?:,[0-9a-f]{4})*)',tail)
            need(q is not None,'malformed return '+repr(line))
            rows.append({'mode':mode,'index':i,'input_utf16':units,'outcome':'return','same_object':q[1]=='true','value_utf16':q[2],'raw':line})
        else:
            q=re.fullmatch(r'type=([A-Za-z0-9_.$]+) message=(<null>|<empty>|[0-9a-f]{4}(?:,[0-9a-f]{4})*)',tail)
            need(q is not None,'malformed throw '+repr(line))
            rows.append({'mode':mode,'index':i,'input_utf16':units,'outcome':'throw','exception_type':q[1],'message_utf16':q[2],'raw':line})
    need(len(rows)==8,'expected 8 runtime observations'); return rows
def physical_facts(path,compare,parser):
    a=compare.parse_class(path); b=parser.parse_class_file(Path(path).read_bytes())
    need(a['class_name']==b['class_name'] and a['major']==b['major'] and a['methods']==b['methods'],'independent class parsers disagree: '+str(path))
    need(sorted(a['fields'])==sorted((f['name'],f['descriptor'],f['access']) for f in b['fields']),'field parser disagreement: '+str(path))
    for m in b['methods']:
        c=m['code']; need(c is not None,'missing Code: '+str(path))
        raw=bytes.fromhex(c['code_hex'])
        need(len(raw)==c['code_length'] and parser.decode_bcis(raw)==c['bcis'],'invalid complete BCI census: '+str(path))
        need(c['bcis'] and c['bcis'][0]==0 and c['bcis'][-1]<c['code_length'],'invalid BCI boundary: '+str(path))
        for start,end,handler,catch in c['rows']:
            need(0<=start<end<=c['code_length'] and handler in c['bcis'] and catch>=0,'invalid exception table: '+str(path))
    return b
def report_method_keys(doc):
    return {(bytes(m['item']['identity']['name']).decode(),bytes(m['item']['identity']['descriptor']).decode()):m for m in doc['methods']}
def tree_pin(compare,root):
    return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*')) if p.is_file()}
def command_raw(row,out):
    for channel in ('stdout','stderr'):
        pinrow=row['streams'][channel]; p=Path(pinrow['path']).resolve(strict=True)
        need(p.parent==(out/'raw').resolve(),'raw stream escaped matrix raw directory')
        b=p.read_bytes(); need(len(b)==pinrow['bytes'] and sha(b)==pinrow['sha256'],f'{row["label"]} {channel} pin mismatch')
def raw_bytes(row,channel):
    return Path(row['streams'][channel]['path']).read_bytes()
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',type=Path,required=True); ap.add_argument('--write',type=Path,required=True); args=ap.parse_args()
    out=args.out.resolve(strict=True); receipt=out/'execution.json'; d=json.loads(receipt.read_text())
    need(d.get('schema')=='cf11-testsequentialloops2-generated-source-matrix-v1','unexpected matrix schema')
    need(d.get('status')=='captured-pending-independent-review','matrix not terminal/pending review')
    need(Path(d['root']).resolve()==ROOT.resolve(),'workspace root mismatch')
    # Bind review to independently reviewed original runtime oracle and source build.
    basepin=pin(BASE/'execution.json'); need(basepin['sha256']==BASE_SHA and d['baseline_receipt']==basepin,'baseline receipt pin mismatch')
    br=json.loads(BASE_REVIEW.read_text()); need(pin(BASE_REVIEW)=={'path':str(BASE_REVIEW.resolve()),'bytes':BASE_REVIEW.stat().st_size,'sha256':BASE_REVIEW_SHA},'baseline independent review pin mismatch')
    need(br.get('acceptance')=='accepted' and br.get('receipt',{}).get('sha256')==BASE_SHA,'baseline review is not accepted/bound')
    baseline=json.loads((BASE/'execution.json').read_text())
    compare=load(COMPARE,'seq2_matrix_compare'); parser=load(PARSER,'seq2_matrix_physical')
    need(sha(COMPARE.read_bytes())==COMPARE_SHA and sha(PARSER.read_bytes())==PARSER_SHA,'helper source pin differs')
    need(d['helper_pins']['compare']['sha256']==COMPARE_SHA and d['helper_pins']['parser']['sha256']==PARSER_SHA,'matrix helper pins mismatch')
    need(d['source_closure_before']==baseline['source_pins_before'] and d['source_closure_after']==d['source_closure_before'],'workspace source closure not unchanged')
    for rel,row in d['source_closure_before'].items(): need(compare.pin(ROOT/rel)==row,'live workspace source pin changed '+rel)
    need(d.get('source_unchanged') is True and d.get('baseline_inputs_unchanged') is True and d.get('target_absent') is True,'matrix final closure/target flags fail')
    need(not (ROOT/'target').exists() and not (ROOT/'target').is_symlink(),'workspace target exists')
    need(d['dependency_trees_before']==d['dependency_trees_after'],'dependency class trees changed')
    need(d['source_copies_after']==[x['copy_pin'] for x in d['source_inputs']],'copied input closure differs')
    need(d['driver_classes_after']==d['driver_compile']['classes_tree'],'driver class tree changed')
    need(d['timeout_wrapper_copy_after']==d['timeout_wrapper_copy'],'runtime wrapper copy changed')
    need(d['external_inputs_before']==d['external_inputs_after'],'baseline external inputs changed')
    for row in d['external_inputs_before']: need(compare.pin(row['path'])==row,'external input pin changed: '+row['path'])
    for h,p in d['helper_pins'].items(): need(compare.pin(p['path'])==p,'helper changed: '+h)
    need(d['jdk_manifest']==d['jdk_manifest_after'],'JDK/tool manifest changed')
    for profile in PROFILES:
        need(profile in d['jdk_manifest'].get('profiles',d['jdk_manifest']).__str__(),'JDK profile manifest missing '+profile)
    commands=d['commands']; need(commands and [c['index'] for c in commands]==list(range(1,len(commands)+1)),'command index discontinuity')
    for c in commands:
        need(c.get('guard_stop') is None,'command stopped by guard: '+c['label'])
        need(c.get('peak_target_bytes',0)<=1024**3 and c.get('free_bytes_after',0)>=5*1024**3,'resource guard bound failed: '+c['label'])
        command_raw(c,out)
    byindex={c['index']:c for c in commands}; need(len(byindex)==len(commands),'duplicate command index')
    cells=d['compilation_cells']; source_inputs=d['source_inputs']
    need(len(source_inputs)==10 and len(cells)==20,'expected 10 complete sources × 2 compiler cells')
    need({(x['kind'],x['profile'],x['form'],x['evidence']) for x in source_inputs}==
         ({('jarde',p,f,e) for p in PROFILES for f in ('child','bundle-child') for e in ('default','all')} |
          {('jadx',p,'bundle','source') for p in PROFILES}),'source input grid differs')
    need({(x['kind'],x['profile'],x['form'],x['evidence'],x['compiler']) for x in cells}==
         {(x['kind'],x['profile'],x['form'],x['evidence'],cc) for x in source_inputs for cc in COMPILERS},'compile grid differs')
    source_by_key={(x['kind'],x['profile'],x['form'],x['evidence']):x for x in source_inputs}
    for item in source_inputs:
        src=Path(item['source_pin']['path']).read_bytes(); cp=Path(item['copy_pin']['path']).read_bytes()
        need(pin(item['copy_pin']['path'])==item['copy_pin'] and cp==src,'copied full source differs from frozen source artifact')
        if item['kind']=='jarde':
            basecell=next(x for x in baseline['jarde_cells'] if (x['profile'],x['input_form'],x['evidence'])==(item['profile'],item['form'],item['evidence']))
            need(item['source_pin']==basecell['whole_source'],'Jarde source not exact baseline full text')
            need(item['report_pin']==basecell['report'] and item['input_pin']==basecell['input'],'Jarde report/input pin binding mismatch')
        else:
            bx=next(x for x in baseline['jadx_cells'] if x['profile']==item['profile'])
            need(item['source_pin']==bx['sources'][0] and item['input_pin']==bx['input'],'JADX complete outer source/input pin binding mismatch')
            need(b'class TestSequentialLoops2' in src and b'TestCls' in src,'JADX source does not retain outer and child')
    # Check driver compile with byte-safe parsing (the driver contains Java UTF-16 surrogate constants).
    dc=d['driver_compile']; need(dc is not None and dc['exit_code']==0,'independent driver compilation failed')
    dcmd=byindex[dc['command']]; need(dcmd['label']=='compile-independent-reflection-driver' and dcmd['exit_code']==0,'driver compile command binding mismatch')
    dfacts=dc['class_facts']; need(dfacts is not None and dfacts['class_name']=='TestSequentialLoops2Driver','driver class binary name mismatch')
    driver_tree=dc['classes_tree']; need(set(driver_tree)=={'TestSequentialLoops2Driver.class'},'unexpected driver class-file inventory')
    need(tree_pin(compare,out/'driver-classes')==driver_tree,'driver compiled class pin differs from receipt')
    driver_source=Path(d['driver_source']['path']).read_text()
    need('new URLClassLoader' in driver_source and 'null)' in driver_source and 'getCodeSource' in driver_source,'driver does not statically show parentless CodeSource isolation')
    need(pin(d['driver_copy']['path'])==d['driver_copy'],'driver copy pin mismatch')
    # Use baseline oracle rows, but always bind each matrix observation to actual raw stdout.
    oracle={}
    for mode,groups in baseline['original_oracles'].items():
        for row in groups:
            key=(row['profile'],row['runtime'],mode)
            oracle[key]=source_semantics(row['rows'])
    observed_cells=[]; expected_global_runtimes=0; class_quality=[]
    for c in cells:
        key=(c['kind'],c['profile'],c['form'],c['evidence'],c['compiler'])
        sc=source_by_key[key[:4]]; compile_cmd=byindex[c['compile_command']]
        need(compile_cmd['exit_code']==c['compile_exit_code'],'compile exit differs from bound command '+str(key))
        need(compile_cmd['label']==f'compile-{c["kind"]}-{c["profile"]}-{c["form"]}-{c["evidence"]}-{c["compiler"]}','compile command label differs')
        argv=compile_cmd['argv']; sourcepath=str(sc['copy_pin']['path']); dest=str(c['classes_root'])
        need(argv[-1]==sourcepath and argv[argv.index('-d')+1]==dest,'compile command source/output mismatch')
        need(c['compiler'] in COMPILERS,'unknown compiler')
        if c['compiler']=='javac8': need('-source' in argv and argv[argv.index('-source')+1]=='8' and '-target' in argv and argv[argv.index('-target')+1]=='8','javac8 source-target flags mismatch')
        else: need('--release' in argv and argv[argv.index('--release')+1]=='8','javac23 release flags mismatch')
        need('-proc:none' in argv and '-encoding' in argv and argv[argv.index('-encoding')+1]=='UTF-8','compiler safety/encoding flags missing')
        need('-sourcepath' in argv and Path(argv[argv.index('-sourcepath')+1]).exists(),'isolated compiler sourcepath missing')
        need(os.pathsep.join(c['compile_classpath'])==argv[argv.index('-classpath')+1],'compile classpath differs from pinned dependency closure')
        need(not any(x.startswith('-Xss') for x in argv),'runtime/compiler explicitly overrides thread stack size')
        rt=c.get('runtime',[])
        if c['compile_exit_code']!=0:
            need(not rt and c['status'].endswith('no_runtime'),'compile failure produced runtime rows')
            err=raw_bytes(compile_cmd,'stderr')
            if c['compiler']=='javac8' and (b'55.0' in err or b'version 55' in err):
                need(c['status']=='compile_failed_javac8_major55_no_runtime','major55 failure classified inaccurately')
            observed_cells.append({'key':key,'status':c['status'],'compile_exit':c['compile_exit_code'],'runtime_count':0})
            continue
        expected_files={INTERNAL+'.class'} if c['kind']=='jarde' else {INTERNAL+'.class',OUTER+'.class'}
        tree=c['classes_tree']; need(set(tree)==expected_files and c['class_tree_matches_expected'] is True,'generated complete class tree differs '+str(key))
        class_root=Path(c['classes_root']); actual_tree=tree_pin(compare,class_root); need(actual_tree==tree,'captured generated class tree pin differs '+str(key))
        fset={}
        for rel,record in tree.items():
            facts=physical_facts(record['path'],compare,parser)
            need(facts['major']==52,'generated class is not Java 8 classfile: '+rel)
            fset[rel]=facts
        child=fset[INTERNAL+'.class']
        orig=baseline['profiles'][0 if c['profile']=='debug' else 1]['target']
        need([(m['name'],m['descriptor'],m['access']) for m in child['methods']]==[(m['name'],m['descriptor'],m['access']) for m in orig['methods']],'generated child full method identity/access differs')
        need([(f['name'],f['descriptor'],f['access']) for f in child['fields']]==[(f['name'],f['descriptor'],f['access']) for f in orig['fields']],'generated child full field inventory/access differs')
        if c['kind']=='jadx':
            outer=fset[OUTER+'.class']; orig_outer=baseline['profiles'][0 if c['profile']=='debug' else 1]['outer']
            need([(m['name'],m['descriptor'],m['access']) for m in outer['methods']]==[(m['name'],m['descriptor'],m['access']) for m in orig_outer['methods']],'JADX generated outer class method/access inventory differs')
            need([(f['name'],f['descriptor'],f['access']) for f in outer['fields']]==[(f['name'],f['descriptor'],f['access']) for f in orig_outer['fields']],'JADX generated outer fields differ')
        need(len(rt)==4,'successful compile target must have four runtime attempts')
        permode={}
        for r in rt:
            mode,vm=r['mode'],r['runtime']; need(mode in MODES and vm in COMPILERS,'unknown runtime profile')
            rc=byindex[r['command']]; expected_label=f'runtime-{c["kind"]}-{c["profile"]}-{c["form"]}-{c["evidence"]}-{c["compiler"]}-on-{vm}-{mode}'
            need(rc['label']==expected_label and rc['exit_code']==r['exit_code'],'runtime command binding mismatch')
            args=rc['argv']; cp=args[args.index('-cp')+1]
            need(Path(cp).resolve()==(out/'driver-classes').resolve(),'runtime classpath is not driver-only')
            need(args[args.index('-Xverify:all')]== '-Xverify:all','runtime skipped JVM verifier')
            need(args[-4]=='TestSequentialLoops2Driver' and args[-3]==mode and Path(args[-1]).resolve()==class_root.resolve(),'runtime class/arguments/expected-root mismatch')
            need(Path(args[-2]).resolve()==class_root.resolve(),'runtime actual CodeSource root mismatch')
            need(r['classpath']==[cp],'recorded runtime classpath differs from argv')
            stdout=raw_bytes(rc,'stdout'); stderr=raw_bytes(rc,'stderr')
            need(sha(stdout)==r['stdout_sha256'] and sha(stderr)==r['stderr_sha256'],'runtime raw summary pin mismatch')
            need(r['exit_code']==0,'rebuilt runtime did not exit successfully')
            rows=parse_rows(stdout,mode); need(r['observed_rows']==rows,'collector parsed rows differ from actual runtime stdout')
            want=oracle[(c['profile'],vm,mode)]; equal=source_semantics(rows)==want
            need(r['expected_semantic_projection']==want,'recorded expected projection differs from pinned original oracle')
            need(r['semantic_oracle_equal'] is equal and equal and r['status']=='matches_baseline_semantics','runtime does not match baseline oracle')
            permode.setdefault(mode,[]).append(source_semantics(rows)); expected_global_runtimes+=1
        for m,vals in permode.items(): need(len(vals)==2 and vals[0]==vals[1],'runtime JVMs disagree: '+str(key)+' '+m)
        after=tree_pin(compare,class_root); need(after==tree and c.get('classes_tree_after_runtime')==tree,'runtime altered generated class bytes')
        observed_cells.append({'key':key,'status':c['status'],'compile_exit':0,'runtime_count':4,'class_files':sorted(tree)})
    # Exactly one real wrong-root rejection per compiled target, none for failed cells.
    successful=[c for c in cells if c['compile_exit_code']==0 and c.get('target_class')]
    controls=d['wrong_root_controls']; need(len(controls)==len(successful),'wrong-root control count differs from successful targets')
    for w in controls:
        ckey=tuple(w['cell'][k] for k in ('kind','profile','form','evidence','compiler'))
        cell=next(c for c in cells if tuple(c[k] for k in ('kind','profile','form','evidence','compiler'))==ckey)
        cmd=byindex[w['command']]; err=raw_bytes(cmd,'stderr')
        need(cmd['label'].startswith('wrong-expected-root-') and cmd['exit_code']!=0 and w['rejected'] is True,'wrong root did not actually reject '+str(ckey))
        need(b'wrong CodeSource:' in err,'wrong-root stderr missing CodeSource rejection')
        args=cmd['argv']; need(args[args.index('-cp')+1]==str(out/'driver-classes') and Path(args[-2]).resolve()==Path(cell['classes_root']).resolve() and Path(args[-1]).resolve()==Path(w['expected_root']).resolve(),'wrong-root argv not bound to target')
    need(expected_global_runtimes==len(d['runtime_rows']),'global runtime rows count differs from successful matrix')
    need(len(commands)==1+len(cells)+expected_global_runtimes+len(controls),'command inventory does not close over driver/compile/runtime/negative-control steps')
    need(len({c['label'] for c in commands})==len(commands),'duplicate command labels')
    embedded={(tuple(c[k] for k in ('kind','profile','form','evidence','compiler')),r['runtime'],r['mode'],r['command']) for c in cells for r in c.get('runtime',[])}
    global_rows={(tuple(r['cell'][k] for k in ('kind','profile','form','evidence','compiler')),r['runtime'],r['mode'],r['command']) for r in d['runtime_rows']}
    need(embedded==global_rows,'global runtime ledger differs from per-cell runtime records')
    result={'schema':'seq2-generated-matrix-independent-review-v1','acceptance':'accepted','receipt':pin(receipt),
      'commands':len(commands),'raw_streams':2*len(commands),'source_inputs':len(source_inputs),'compile_cells':len(cells),
      'compile_outcomes':{status:sum(x['status']==status for x in observed_cells) for status in sorted({x['status'] for x in observed_cells})},
      'successful_runtime_attempts':expected_global_runtimes,'runtime_semantics':'all successful generated targets match original profile/JVM/mode oracle',
      'wrong_root_rejections':len(controls),'source_closure_file_count':len(d['source_closure_before']),
      'class_matrix':observed_cells,'limitations':['Only complete sources captured in the matrix are reviewed; failed compiles correctly have no runtime evidence.','Exception messages remain raw but are not a cross-JDK semantic comparison.']}
    args.write.parent.mkdir(parents=True,exist_ok=True); args.write.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'acceptance':'accepted','receipt_sha256':result['receipt']['sha256'],'compile_cells':len(cells),'runtime_attempts':expected_global_runtimes,'wrong_root_rejections':len(controls),'review':str(args.write)}))
if __name__=='__main__':
    try: main()
    except Exception as e:
        print(f'REVIEW FAILED: {type(e).__name__}: {e}',file=sys.stderr); raise
