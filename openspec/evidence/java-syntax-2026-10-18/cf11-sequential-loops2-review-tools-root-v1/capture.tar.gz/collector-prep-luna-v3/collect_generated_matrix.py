#!/usr/bin/env python3
"""Prepare a complete-source rebuild/runtime matrix for TestSequentialLoops2."""
from __future__ import annotations

import argparse, datetime, hashlib, importlib.util, json, os, re, shutil, sys, zipfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASE = Path('/private/tmp/jarde-seq2-baseline-root-v1-20261018')
BASE_RECEIPT = BASE / 'execution.json'
EXPECTED_BASE_SHA = '9811af1be7efd2d5f4ce38d7ed7ae1ce426ca5f30de9b6cac8b4344553211a37'
COMPARE_REL = Path('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
GUARD_REL = Path('openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py')
SCANNER_REL = Path('openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py')
PARSER = Path('/private/tmp/jarde-seq2-baseline-prep-root-v5-20261018/classfile_helpers.py')
PARSER_SHA = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
COMPARE_SHA = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
MANIFEST_REL = Path('openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json')
MANIFEST_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
MODES = ('default', 'configured128')
PROFILES = ('debug', 'no-debug')
COMPILERS = ('javac8', 'javac23')
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')
INTERNAL = 'jadx/tests/integration/loops/TestSequentialLoops2$TestCls'
OUTER = 'jadx/tests/integration/loops/TestSequentialLoops2'
TARGET_REL = Path(INTERNAL + '.class')


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def method_set(facts: dict) -> set[tuple[str, str]]:
    return {(m['name'], m['descriptor']) for m in facts['methods']}


def full_facts(compare, physical, path: Path) -> dict:
    facts = compare.parse_class(path)
    raw = path.read_bytes()
    parsed = physical.parse_class_file(raw)
    if parsed['class_name'] != facts['class_name'] or parsed['major'] != facts['major']:
        raise RuntimeError(f'class parser identity disagreement: {path}')
    if parsed['methods'] != facts['methods']:
        raise RuntimeError(f'Code/method census disagreement: {path}')
    if sorted((f['name'], f['descriptor'], f['access']) for f in parsed['fields']) != sorted(facts['fields']):
        raise RuntimeError(f'field census disagreement: {path}')
    facts['access'] = parsed['access']
    if len(method_set(facts)) != len(facts['methods']):
        raise RuntimeError(f'duplicate method identity: {path}')
    for m in facts['methods']:
        code = m.get('code')
        if code is None or not code.get('bcis') or code['bcis'][0] != 0 or code['bcis'][-1] >= code['code_length']:
            raise RuntimeError(f'incomplete/invalid physical Code: {path}:{m["name"]}{m["descriptor"]}')
    return facts


def file_tree(compare, root: Path) -> dict:
    return {p.relative_to(root).as_posix(): compare.pin(p) for p in sorted(root.rglob('*')) if p.is_file()}


def source_filename(kind: str) -> str:
    return 'TestSequentialLoops2$TestCls.java' if kind == 'jarde' else 'TestSequentialLoops2.java'


def parse_rows(raw: bytes, mode: str) -> list[dict]:
    pattern = re.compile(r'^CASE mode=(default|configured128) index=(\d+) input=(\S+) outcome=(return|throw) (.+)$')
    expected_inputs = {
        'default': ['<null>', '<empty>', '00e9', 'd83d,de00', '0000', '0061', '0041', '0041,0062'],
        'configured128': ['<null>', '0041', '0061,0062,0063', '00e9', 'd83d,de00', '0041,00e9', '0041,00e9,0042', '0041,0042,0043'],
    }[mode]
    rows = []
    for line in raw.decode('utf-8', errors='strict').splitlines():
        m = pattern.fullmatch(line)
        if m is None:
            raise ValueError(f'malformed driver observation: {line!r}')
        actual_mode, ix, units, outcome, tail = m.groups()
        i = int(ix)
        if actual_mode != mode or i != len(rows) or i >= 8 or units != expected_inputs[i]:
            raise ValueError(f'wrong case order/input: {line!r}')
        if outcome == 'return':
            result = re.fullmatch(r'same=(true|false) value=(<null>|<empty>|[0-9a-f]{4}(?:,[0-9a-f]{4})*)', tail)
            if result is None: raise ValueError(f'malformed return: {line!r}')
            rows.append({'mode': mode, 'index': i, 'input_utf16': units, 'outcome': 'return',
                         'same_object': result.group(1) == 'true', 'value_utf16': result.group(2), 'raw': line})
        else:
            result = re.fullmatch(r'type=([A-Za-z0-9_.$]+) message=(<null>|<empty>|[0-9a-f]{4}(?:,[0-9a-f]{4})*)', tail)
            if result is None: raise ValueError(f'malformed throw: {line!r}')
            rows.append({'mode': mode, 'index': i, 'input_utf16': units, 'outcome': 'throw',
                         'exception_type': result.group(1), 'message_utf16': result.group(2), 'raw': line})
    if len(rows) != 8: raise ValueError(f'expected 8 observations, got {len(rows)}')
    return rows


def projection(rows: list[dict]) -> list[dict]:
    out = []
    for row in rows:
        item = {k: row[k] for k in ('mode', 'index', 'input_utf16', 'outcome')}
        if row['outcome'] == 'return': item.update(same_object=row['same_object'], value_utf16=row['value_utf16'])
        else: item['exception_type'] = row['exception_type']
        out.append(item)
    return out


def pin_current(compare, pin: dict, label: str) -> None:
    if compare.pin(Path(pin['path'])) != pin:
        raise RuntimeError(f'{label} pin changed: {pin.get("path")}')


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    root, base, out = ROOT.resolve(strict=True), BASE.resolve(strict=True), args.out.resolve()
    if out.exists(): raise SystemExit(f'refusing existing output directory: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink(): raise SystemExit('workspace target must be absent')
    if shutil.disk_usage(root).free < 5 * 1024**3: raise SystemExit('less than 5 GiB free')
    baseline_sha = hashlib.sha256(BASE_RECEIPT.read_bytes()).hexdigest()
    if baseline_sha != EXPECTED_BASE_SHA:
        raise SystemExit('baseline receipt SHA differs from prepared pin')
    baseline = json.loads(BASE_RECEIPT.read_text(encoding='utf-8'))
    if baseline.get('schema') != 'cf11-testsequentialloops2-full-source-baseline-v1' or baseline.get('status') != 'captured-pending-independent-review':
        raise SystemExit('unexpected Seq2 baseline receipt')
    if len(baseline.get('commands', [])) != 24 or len(baseline.get('jarde_cells', [])) != 8 or len(baseline.get('jadx_cells', [])) != 2:
        raise SystemExit('baseline grids/command count are incomplete')
    if baseline.get('source_unchanged_finally') is not True or baseline.get('target_absent_finally') is not True:
        raise SystemExit('baseline does not attest stable source and absent target')
    baseline_commands={row['index']:row for row in baseline['commands']}
    if len(baseline_commands)!=24: raise SystemExit('duplicate baseline command indices')
    for row in baseline_commands.values():
        if row.get('guard_stop') is not None: raise SystemExit(f'baseline command has a guard stop: {row["index"]}')

    compare_path = root / COMPARE_REL
    guard_path, scanner_path = root / GUARD_REL, root / SCANNER_REL
    manifest_path = root / MANIFEST_REL
    for path, expected, label in ((compare_path, COMPARE_SHA, 'compare'), (guard_path, GUARD_SHA, 'guard'),
                                  (scanner_path, SCANNER_SHA, 'scanner'), (PARSER, PARSER_SHA, 'physical parser'),
                                  (manifest_path, MANIFEST_SHA, 'JDK manifest')):
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected: raise SystemExit(f'{label} pin mismatch')
    compare, physical = load(compare_path, 'seq2_generated_compare'), load(PARSER, 'seq2_generated_physical')
    guard, scanner = load(guard_path, 'seq2_generated_guard'), load(scanner_path, 'seq2_generated_scanner')
    jdks, jdk_record = compare.configured_jdks(manifest_path, MANIFEST_SHA)
    helper_pins = {k: compare.pin(p) for k, p in [('compare', compare_path), ('guard', guard_path),
                    ('scanner', scanner_path), ('parser', PARSER), ('jdk_manifest', manifest_path)]}

    # Snapshot every raw/API/class/source/dependency/tool input used by the accepted baseline.
    ext_paths = {BASE_RECEIPT}
    pins = []
    for pin in [baseline.get('source'), baseline.get('source_copy'), baseline.get('dependency_reference'),
                baseline.get('dependency_harness_jar'), baseline.get('driver_source'), baseline.get('driver_copy'),
                baseline.get('runtime_wrapper'), baseline.get('jadx'), baseline.get('jadx_jar'), baseline.get('cli')]:
        if isinstance(pin, dict) and pin.get('path'): pins.append(pin)
    for pin in baseline.get('dependency_jar_pins', []): pins.append(pin)
    for collection in ('commands',):
        for row in baseline[collection]:
            for channel in ('stdout', 'stderr'):
                item = row.get('streams', {}).get(channel)
                if item: pins.append(item)
    for collection in ('jarde_cells', 'jadx_cells'):
        for row in baseline[collection]:
            for item in (row.get('input'), row.get('report'), row.get('whole_source'), *(row.get('sources') or [])):
                if isinstance(item, dict) and item.get('path'): pins.append(item)
    for profile in baseline.get('profiles', []):
        for item in profile.get('class_files', []): pins.append(item)
    for group in baseline.get('original_oracles', {}).values():
        for item in group: pins.append(item['path'])
    for pin in pins:
        if pin.get('path'):
            path = Path(pin['path']); pin_current(compare, pin, 'baseline input')
            ext_paths.add(path)
    dep_dirs = baseline.get('dependency_directory_pins', {})
    dep_trees = {str(Path(folder)): file_tree(compare, Path(folder)) for folder in dep_dirs}
    for folder, expected in dep_dirs.items():
        if dep_trees[str(Path(folder))] != expected: raise SystemExit(f'dependency class directory changed: {folder}')
    dep_reference_path = Path(baseline['dependency_reference']['path'])
    dep_doc = json.loads(dep_reference_path.read_text(encoding='utf-8'))
    dep_dirs_reference=dep_doc.get('directory_pins',dep_doc.get('directory_pins_before'))
    if (dep_doc.get('classpath') is None or baseline['dependency_classpath'] != dep_doc['classpath']
            or baseline.get('dependency_jar_pins') != dep_doc.get('jar_pins')
            or dep_dirs_reference != dep_dirs):
        raise SystemExit('Seq2 dependency classpath/jars/class directories differ from bound reference receipt')
    classpath = list(baseline['dependency_classpath'])
    for folder in dep_trees:
        if (Path(folder) / TARGET_REL).exists() or (Path(folder) / Path(OUTER + '.class')).exists():
            raise SystemExit(f'target leaked into dependency tree: {folder}')
    for pin in (baseline['cli'], baseline['jadx'], baseline['jadx_jar']): pin_current(compare, pin, 'baseline tool')
    source_before = compare.source_closure(root)
    if source_before != baseline.get('source_pins_before'):
        raise SystemExit('current source closure differs from the Seq2 baseline capture')

    # Index and verify exact saved source inputs, without altering their contents.
    source_inputs = []
    wanted_jarde = {(p, f, e) for p in PROFILES for f in ('child', 'bundle-child') for e in ('default', 'all')}
    got_jarde = {(r['profile'], r['input_form'], r['evidence']) for r in baseline['jarde_cells']}
    if got_jarde != wanted_jarde: raise SystemExit('Jarde baseline grid is not 2×2×2')
    for cell in baseline['jarde_cells']:
        for k in ('input', 'report', 'whole_source'): pin_current(compare, cell[k], f'Jarde {k}')
        cmd = next((r for r in baseline['commands'] if r['index'] == cell['command']), None)
        if cmd is None or cmd['exit_code'] != 0: raise SystemExit('Jarde source command was unsuccessful')
        report_bytes = Path(cell['report']['path']).read_bytes()
        doc = json.loads(report_bytes.decode('utf-8', errors='strict'))
        source_bytes = Path(cell['whole_source']['path']).read_bytes()
        if doc.get('text', '').encode('utf-8') != source_bytes or compare.command_artifact(cmd, 'stdout') != report_bytes:
            raise SystemExit('Jarde saved text/report/raw do not agree')
        if len(cell.get('methods', [])) != 3 or any(m.get('quality') != 'structured' for m in cell['methods']):
            raise SystemExit('Jarde baseline no longer has three structured method reports')
        source_inputs.append({'kind':'jarde','profile':cell['profile'],'form':cell['input_form'],'evidence':cell['evidence'],
                              'source_pin':cell['whole_source'],'report_pin':cell['report'],'input_pin':cell['input'],
                              'bytes':source_bytes})
    if len(baseline['jadx_cells']) != 2: raise SystemExit('JADX baseline needs two profile cells')
    for cell in baseline['jadx_cells']:
        if cell['exit_code'] != 0 or len(cell['sources']) != 1: raise SystemExit('JADX full source missing')
        source_pin = cell['sources'][0]; pin_current(compare, source_pin, 'complete JADX source')
        source_bytes = Path(source_pin['path']).read_bytes()
        if b'class TestSequentialLoops2' not in source_bytes or b'TestCls' not in source_bytes:
            raise SystemExit('JADX artifact does not retain full outer and nested class source')
        command = next((r for r in baseline['commands'] if r['index'] == cell['command']), None)
        if command is None or command['exit_code'] != 0: raise SystemExit('JADX source command failed')
        source_inputs.append({'kind':'jadx','profile':cell['profile'],'form':'bundle','evidence':'source',
                              'source_pin':source_pin,'report_pin':None,'input_pin':compare.pin(Path(command['argv'][-1])),
                              'bytes':source_bytes})
        pins.append(source_inputs[-1]['input_pin'])
    if len(source_inputs) != 10: raise SystemExit('expected 10 full-source inputs')

    out.mkdir(parents=True)
    raw = out / 'raw'; raw.mkdir()
    guard.ROOT, guard.OUT = root, raw
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda _i, _b: None
    wrapper_source = Path(baseline['runtime_wrapper']['path'])
    wrapper_copy = out / wrapper_source.name
    shutil.copy2(wrapper_source, wrapper_copy)
    if wrapper_copy.read_bytes() != wrapper_source.read_bytes(): raise RuntimeError('timeout wrapper copy differs')
    wrapper_pin = compare.pin(wrapper_copy)
    driver_source = Path(baseline['driver_source']['path'])
    driver_copy = out / 'driver-source/TestSequentialLoops2Driver.java'; driver_copy.parent.mkdir()
    shutil.copy2(driver_source, driver_copy)
    if driver_copy.read_bytes() != driver_source.read_bytes(): raise RuntimeError('driver copy differs')
    driver_pin = compare.pin(driver_copy)
    empty = out / 'empty-sourcepath'; empty.mkdir()
    driver_classes = out / 'driver-classes'; driver_classes.mkdir()
    for item in source_inputs:
        rel = Path('jadx/tests/integration/loops') / source_filename(item['kind'])
        target = out / 'source-inputs' / item['kind'] / item['profile'] / item['form'] / item['evidence'] / rel
        target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(item['bytes'])
        item['compile_path'] = target; item['copy_pin'] = compare.pin(target); item['filename'] = target.name

    commands, cells, runtime_rows, wrong_controls = [], [], [], []
    report = {'schema':'cf11-testsequentialloops2-generated-source-matrix-v1','status':'running','root':str(root),
        'baseline_receipt':compare.pin(BASE_RECEIPT),'baseline_receipt_sha256':baseline_sha,
        'source_closure_before':source_before,'baseline_source_closure_matches_current':source_before == baseline.get('source_pins_before'),
        'jdk_manifest':jdk_record,'helper_pins':helper_pins,'dependency_reference':baseline['dependency_reference'],
        'dependency_classpath':classpath,'dependency_trees_before':dep_trees,'source_inputs':[],
        'driver_source':baseline['driver_source'],'driver_copy':driver_pin,'timeout_wrapper':baseline['runtime_wrapper'],
        'timeout_wrapper_copy':wrapper_pin,'driver_compile':None,'commands':commands,'compilation_cells':cells,
        'runtime_rows':runtime_rows,'wrong_root_controls':wrong_controls,
        'notes':['Jarde sources are each one complete child-class source. JADX source is the complete outer JUnit class and nested child; compiling Jarde child output does not claim to compile its upstream outer class.',
                 'All ten saved source artifacts are copied byte-for-byte and attempted with both pinned compilers. Compile failures remain recorded without runtime rows.',
                 'The full frozen dependency classpath is compile-only. Runtime application classpath contains only the independent driver; target classes are loaded by a parentless URLClassLoader from rebuilt output.',
                 'Runtime comparison uses the profile/JVM/mode oracle. Return value UTF-16 and object identity are compared; throws compare exception type. Raw exception messages remain retained and are not cross-runtime equivalence gates.']}
    report['source_inputs']=[{k:item[k] for k in ('kind','profile','form','evidence','source_pin','report_pin','input_pin','copy_pin','filename')}
                             for item in source_inputs]

    def save(): compare.write_json(out / 'execution.json', report)
    def run(label: str, argv: list, leg: str) -> dict:
        if (root / 'target').exists(): raise RuntimeError('workspace target appeared before external command')
        env = {k:v for k,v in os.environ.items() if k not in ENV_STRIP}
        env = compare.clean_env(env, jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(commands)+1, [str(x) for x in argv], env)
        row['label'], row['tool_leg'] = label, leg; commands.append(row); save()
        if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        return row

    def parse_tree(classes: Path) -> tuple[dict, dict]:
        tree = file_tree(compare, classes); parsed = {}
        for rel in sorted(tree):
            if not rel.endswith('.class'): continue
            parsed[rel] = full_facts(compare, physical, classes / rel)
        return tree, parsed

    # Oracle lookup is deliberately per source profile, actual runtime and input mode.
    oracle = {}
    for mode, rows in baseline['original_oracles'].items():
        for item in rows:
            pin_current(compare, item['path'], 'baseline original-runtime oracle')
            original_raw = Path(item['path']['path']).read_bytes()
            parsed_oracle = parse_rows(original_raw, mode)
            if projection(parsed_oracle) != projection(item['rows']):
                raise SystemExit('baseline oracle rows disagree with saved raw stdout')
            key=(item['profile'], item['runtime'], mode)
            original_run=next((r for r in baseline.get('original_runtime', [])
                               if (r.get('profile'),r.get('runtime'),r.get('mode'))==key),None)
            if original_run is None or original_run.get('exit_code') != 0:
                raise SystemExit(f'missing successful original runtime record: {key}')
            runtime_stdout=compare.command_artifact(next(r for r in baseline['commands'] if r['index']==original_run['command']),'stdout')
            if runtime_stdout != original_raw:
                raise SystemExit(f'original runtime raw differs from oracle artifact: {key}')
            oracle[key] = projection(parsed_oracle)
    report['external_inputs_before']=[compare.pin(Path(pin['path'])) for pin in pins]
    report['dependency_reference_receipt'] = compare.pin(dep_reference_path)

    try:
        driver_compile = run('compile-independent-reflection-driver', [jdks['javac8']['tools']['javac'], '-source','8','-target','8',
            '-g:none','-Xlint:-options','-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,
            '-d',driver_classes,driver_copy], 'javac8')
        driver_tree = file_tree(compare, driver_classes)
        driver_class_path = driver_classes / 'TestSequentialLoops2Driver.class'
        driver_facts = compare.parse_class(driver_class_path) if driver_class_path.is_file() else None
        report['driver_compile'] = {'command':driver_compile['index'],'exit_code':driver_compile['exit_code'],
                                    'classes_tree':driver_tree,'driver_class':compare.pin(driver_class_path) if driver_class_path.is_file() else None,
                                    'class_facts':driver_facts,
                                    'class_facts_scope':'compare.parse_class summary only; independent driver not a target classfile audit'}
        if driver_compile['exit_code'] != 0 or len(driver_tree) != 1 or driver_facts is None:
            raise RuntimeError('reflection driver compile failed or emitted an unexpected class tree')
        save()

        for item in source_inputs:
            for compiler in COMPILERS:
                classes = out / 'compiled' / item['kind'] / item['profile'] / item['form'] / item['evidence'] / compiler / 'classes'
                classes.mkdir(parents=True); empty_cp = classes.parent / 'empty-sourcepath'; empty_cp.mkdir()
                opts = (['-source','8','-target','8','-g:none','-Xlint:-options','-proc:none'] if compiler == 'javac8'
                        else ['--release','8','-g:none','-proc:none'])
                compile_cp = os.pathsep.join(classpath)
                comp = run(f'compile-{item["kind"]}-{item["profile"]}-{item["form"]}-{item["evidence"]}-{compiler}',
                           [jdks[compiler]['tools']['javac'],*opts,'-encoding','UTF-8','-classpath',compile_cp,
                            '-sourcepath',empty_cp,'-d',classes,item['compile_path']],compiler)
                cell = {k:item[k] for k in ('kind','profile','form','evidence','source_pin','report_pin','input_pin','copy_pin','filename')}
                cell.update(compiler=compiler,compile_command=comp['index'],compile_exit_code=comp['exit_code'],
                            compile_classpath=classpath,classes_root=str(classes),runtime=[])
                if comp['exit_code'] != 0:
                    err=compare.command_artifact(comp,'stderr')
                    cell['status']='compile_failed_javac8_major55_no_runtime' if compiler=='javac8' and (b'55.0' in err or b'version 55' in err) else 'compile_failed_no_runtime'
                    cell['compile_stderr_sha256']=hashlib.sha256(err).hexdigest()
                else:
                    tree, facts = parse_tree(classes); cell['classes_tree']=tree; cell['class_facts']=facts
                    expected = {INTERNAL+'.class'} if item['kind']=='jarde' else {INTERNAL+'.class',OUTER+'.class'}
                    cell['expected_class_files']=sorted(expected); cell['class_tree_matches_expected']=set(tree)==expected
                    target = classes / TARGET_REL
                    if not target.is_file(): cell['status']='compile_succeeded_target_missing_no_runtime'
                    else:
                        cell['status']='compiled_target_available'; cell['target_class']=compare.pin(target)
                        before_tree = tree
                        for mode in MODES:
                            for runtime in COMPILERS:
                                argv=[sys.executable,'-B',wrapper_copy,'30',jdks[runtime]['tools']['java'],'-Xverify:all',
                                      '-cp',driver_classes,'TestSequentialLoops2Driver',mode,classes,classes]
                                rr=run(f'runtime-{item["kind"]}-{item["profile"]}-{item["form"]}-{item["evidence"]}-{compiler}-on-{runtime}-{mode}',argv,runtime)
                                stdout,stderr=compare.command_artifact(rr,'stdout'),compare.command_artifact(rr,'stderr')
                                parse_error = None
                                try: obs=parse_rows(stdout,mode) if rr['exit_code']==0 else None
                                except ValueError as exc: obs=None; parse_error=str(exc)
                                want=oracle.get((item['profile'],runtime,mode))
                                equal=bool(obs is not None and want is not None and projection(obs)==want)
                                rec={'runtime':runtime,'mode':mode,'command':rr['index'],'exit_code':rr['exit_code'],
                                     'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),
                                     'observed_rows':obs,'expected_semantic_projection':want,'semantic_oracle_equal':equal,
                                     'status':'matches_baseline_semantics' if equal else ('runtime_failed' if rr['exit_code'] else 'oracle_mismatch'),
                                     'parse_error':parse_error,
                                     'classpath':[rr['argv'][rr['argv'].index('-cp')+1]]}
                                cell['runtime'].append(rec); runtime_rows.append({'cell':{k:cell[k] for k in ('kind','profile','form','evidence','compiler')},**rec}); save()
                        # Negative CodeSource check: actual root is present, expected root is empty.
                        wrong=out/'wrong-expected-code-source'/item['kind']/item['profile']/item['form']/item['evidence']/compiler
                        wrong.mkdir(parents=True); empty_wrong=wrong/'expected-empty';empty_wrong.mkdir()
                        wr=run(f'wrong-expected-root-{item["kind"]}-{item["profile"]}-{item["form"]}-{item["evidence"]}-{compiler}',
                               [sys.executable,'-B',wrapper_copy,'30',jdks['javac23']['tools']['java'],'-Xverify:all','-cp',driver_classes,
                                'TestSequentialLoops2Driver','default',classes,empty_wrong],'javac23')
                        wrong_stderr=compare.command_artifact(wr,'stderr')
                        rejected=wr['exit_code']!=0 and b'wrong CodeSource:' in wrong_stderr
                        wrong_controls.append({'cell':{k:cell[k] for k in ('kind','profile','form','evidence','compiler')},
                            'command':wr['index'],'exit_code':wr['exit_code'],'actual_root':str(classes),
                            'expected_root':str(empty_wrong),'rejected':rejected,'stderr_sha256':hashlib.sha256(wrong_stderr).hexdigest()})
                        if not rejected: raise RuntimeError('wrong CodeSource control did not reject')
                        after_tree=file_tree(compare,classes)
                        if after_tree != before_tree: raise RuntimeError('runtime modified compiled class tree')
                        cell['classes_tree_after_runtime']=after_tree
                cells.append(cell); save()

        # Re-read every external file and directory instead of trusting cached before-pins.
        for pin in pins: pin_current(compare,pin,'baseline external input after matrix')
        for item in source_inputs:
            if compare.pin(item['compile_path']) != item['copy_pin']:
                raise RuntimeError(f'copied complete Java source changed: {item["compile_path"]}')
        for folder, expected in dep_dirs.items():
            if file_tree(compare,Path(folder)) != expected: raise RuntimeError(f'dependency class tree changed: {folder}')
        if compare.pin(BASE_RECEIPT) != report['baseline_receipt']: raise RuntimeError('baseline receipt changed')
        source_after=compare.source_closure(root)
        helper_after={k:compare.pin(Path(v['path'])) for k,v in helper_pins.items()}
        jdks_after, jdk_record_after = compare.configured_jdks(manifest_path, MANIFEST_SHA)
        report['source_closure_after']=source_after; report['helper_pins_after']=helper_after
        report['jdk_manifest_after']=jdk_record_after
        report['dependency_reference_after']=compare.pin(dep_reference_path)
        report['external_inputs_after']=[compare.pin(Path(pin['path'])) for pin in pins]
        report['source_copies_after']=[compare.pin(item['compile_path']) for item in source_inputs]
        report['dependency_trees_after']={folder:file_tree(compare,Path(folder)) for folder in dep_dirs}
        report['driver_classes_after']=file_tree(compare,driver_classes); report['timeout_wrapper_copy_after']=compare.pin(wrapper_copy)
        if source_after != source_before or helper_after != helper_pins: raise RuntimeError('workspace/helper source changed during matrix')
        if jdk_record_after != jdk_record: raise RuntimeError('JDK manifest/tool pin changed during matrix')
        if report['external_inputs_after'] != report['external_inputs_before']:
            raise RuntimeError('one or more baseline raw/source/tool inputs changed during matrix')
        if report['source_copies_after'] != [item['copy_pin'] for item in source_inputs]:
            raise RuntimeError('one or more copied complete Java sources changed')
        if report['dependency_reference_after'] != report['dependency_reference_receipt']:
            raise RuntimeError('dependency reference changed during matrix')
        if report['driver_classes_after'] != driver_tree or report['timeout_wrapper_copy_after'] != wrapper_pin:
            raise RuntimeError('driver or timeout wrapper changed')
        if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError('workspace target appeared by end')
        report['source_unchanged']=True; report['baseline_inputs_unchanged']=True; report['target_absent']=True
        report['status']='captured-pending-independent-review'
    except BaseException as exc:
        report['status']='failed'; report['error']=f'{type(exc).__name__}: {exc}'; raise
    finally:
        report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out/'execution.json',report)
        shutil.copy2(__file__,out/'collector.py')
        print(json.dumps({'status':report['status'],'compile_cells':len(cells),'runtime_rows':len(runtime_rows),
                          'wrong_root_controls':len(wrong_controls),'output':str(out)}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
