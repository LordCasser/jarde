# CF-11 after Seq2: ledger successor and current evidence boundary

Date: 2026-10-18. Static, bounded review only. No compiler, Jarde/JADX CLI, Git, or shared-file edits were used.

## Ledger result

The fixed CF-11 list in `openspec/evidence/java-syntax-2026-09-27/cf11-loops/README.md` orders the four registered upstream tests as `TestNestedLoops4`, `TestNestedLoops2`, `TestSequentialLoops2`, then **`TestNestedLoops`**. Thus the next file after Seq2 is the already-named `TestNestedLoops.java`; this is a ledger lookup, not a guessed `TestNestedLoops3`.

This successor is already historically accepted as a narrow fixed shape. The current feature inventory calls out the complete `TestNestedLoops` class acceptance: four Jarde source legs, nested inner foreach plus outer while, raw `List`/`Object` iterator shape with the original `String` cast, full-class compile/runtime equivalence against the original and JADX, and retained refusal/combined/source-gap controls. It explicitly says this does not close all CF-11. The acceptance is tied to the older product/build receipt and is not a re-run against the current product; Seq2’s pending generated-source matrix is separate.

## Source and golden assertion

Pinned source: `/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestNestedLoops.java`, SHA-256 `4897fd18a15fce6e0abb40dc8afc6c7a3fa9f16e617f3c7e5e88072f6a37309e`.

`TestCls.test(List<String> l1, List<String> l2)` nests a traversal of `l2` inside a traversal of `l1`; on equal elements it either adds to `l2` when the string length is five or removes from `l1`, then after both loops clears `l1` if `l2` is nonempty. The JUnit golden assertion checks one occurrence each of the two typed foreach headers, equality `if`, `l2.add(s1)`, and `l1.remove(s2)`. It has no in-source `check()` behavior assertion. The stronger behavior evidence comes from the separately accepted external eight-case driver, which records exception type and final lists; two mutation cases exercise `ConcurrentModificationException`, three null cases exercise `NullPointerException`, and the normal path reaches the final clear.

Prior acceptance receipt: `openspec/evidence/java-syntax-2026-10-12/cf11-testnestedloops-baseline-root-v1/README.md` (SHA-256 `608098313ed8ce4049c889dde17b84f518bb4d1644370bb9a0a05b920400bdba`). It records 29 commands/58 raw artifacts and complete original/JADX/Jarde recompilation/runtime legs, but the accepted Jarde product was `02ecd63ff33270cea4413793db2f99d6927dc65c`; do not treat that receipt as current-head validation.

## Existing Jarde seam and the only useful follow-up

The current `crates/jarde-java/src/build.rs::iterable_for_each_candidate` (current file SHA-256 `e3f201df7bd01b9b0691d5f7229cbfd5efd82ce5b70fdd39f0f003170fe51b39`) is the existing projection seam: it requires an exact `Iterator.hasNext()Z` interface call, a first body binding from `next()` (including the cast form), then finds the matching `iterator()` initialization in the statement range. It preserves the binding and cast while considering the while-to-foreach projection. This is the relevant reuse point; the old acceptance’s `ordinary_generic_source_unproved` marker concerns generic source typing, not evidence that the loop itself failed.

A historical same-IR receipt (`openspec/evidence/java-syntax-2026-10-12/cf11-testnestedloops-same-ir-root-v3/README.md`, SHA-256 `be3277b2d7631517db77de6f1edfc27bae07bd06d877134132d21bde7efe1a5c`) found an outer-loop entry refusal at BCI 13 (`body_first_not_initialized_declaration`) and an inner-loop later refusal at BCI 42 (`iterator_declaration_before_init`): the iterator local is declared before the loop but assigned `l2.iterator()` inside the outer body. That diagnostic predates later loop changes. It does not establish the current first refusal or prove downstream SSA/effect/handler checks pass.

Therefore no new feature or mechanism is justified from this static review. If a fresh current-product check is wanted after Seq2’s matrix, replay this already-accepted class and inspect whether BCI 13/42 still refuse, keeping whole-class behavior and source-map evidence bound to the new receipt. If the refusal remains, follow the existing declaration-owner/local-variable representation and exact initialization site; do not conflate it with the generic-signature projection debt. This review does not nominate a further unaccepted filename because the fixed four-item ledger provides no next unclosed item after this already-accepted successor.

## Source pins

- `openspec/evidence/jadx-feature-inventory-2026-09-27/summary.md` — SHA-256 `e74f82b0a35aa6934253caf76f0b186ad73bc3389856e67100f1c42ea4b3ab47`.
- `openspec/evidence/java-syntax-2026-09-27/cf11-loops/README.md` — SHA-256 `5eeab1c8b81c3b0e099c580077dcfe4ce696b8f7430db02ed3102954ff6934e9`.
- Upstream `TestNestedLoops.java` — SHA-256 above.
- Baseline and same-IR README pins — SHA-256 above.
- Current `crates/jarde-java/src/build.rs` — SHA-256 above; working-tree source pin only, not a product/release receipt.
