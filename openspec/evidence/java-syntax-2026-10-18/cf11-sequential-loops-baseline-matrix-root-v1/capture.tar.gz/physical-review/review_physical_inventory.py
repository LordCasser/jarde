#!/usr/bin/env python3
"""Independently parse every successfully rebuilt Seq1 class tree."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

HELPER = Path('/private/tmp/jarde-testnestedloops5-parameterized-review-prep-root-v4-20261018/classfile_helpers.py')
HELPER_BYTES = 54227
HELPER_SHA256 = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
BASELINE = Path('/private/tmp/jarde-testsequentialloops-baseline-run-root-v1-20261018/execution.json')
EXPECTED_SCHEMA = 'cf11-testsequentialloops-full-source-rebuild-matrix-v1'
TARGET = 'jadx/tests/integration/loops/TestSequentialLoops$TestCls'
OUTER = 'jadx/tests/integration/loops/TestSequentialLoops'
PROFILES = {'debug', 'no-debug'}
COMPILERS = {'javac8', 'javac23'}
FORMS = {'jarde': {'child', 'bundle-child'}, 'jadx': {'child', 'bundle'}}


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def verify_pin(record: dict, label: str) -> bytes:
    need(isinstance(record, dict), f'{label}: missing pin')
    path = Path(record.get('path', ''))
    need(path.is_absolute() and path.is_file(), f'{label}: missing artifact {path}')
    data = path.read_bytes()
    need(len(data) == record.get('bytes') and sha(data) == record.get('sha256'),
         f'{label}: byte/SHA-256 pin mismatch')
    return data


def load_parser():
    data = HELPER.read_bytes()
    need(len(data) == HELPER_BYTES and sha(data) == HELPER_SHA256, 'accepted classfile parser pin mismatch')
    spec = importlib.util.spec_from_file_location('accepted_seq1_classfile_helpers', HELPER)
    need(spec is not None and spec.loader is not None, 'cannot load accepted classfile parser')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, pin(HELPER)


def class_tree(root: Path) -> dict:
    need(root.is_dir(), f'class output directory missing: {root}')
    return {p.relative_to(root).as_posix(): pin(p) for p in sorted(root.rglob('*.class'))}


def abi(parsed: dict) -> dict:
    return {
        'class_name': parsed['class_name'],
        'class_access': parsed['access'],
        'fields': [(f['name'], f['descriptor'], f['access']) for f in parsed['fields']],
        'methods': [(m['name'], m['descriptor'], m['access']) for m in parsed['methods']],
    }


def method_facts(parsed: dict) -> dict:
    methods = parsed['methods']
    need([m['index'] for m in methods] == list(range(len(methods))), 'method indices are not physical classfile order')
    result = {}
    for method in methods:
        key = method['name'], method['descriptor']
        need(key not in result, f'duplicate method identity {key}')
        code = method.get('code')
        need(isinstance(code, dict), f'method {key} has no Code attribute')
        raw = bytes.fromhex(code['code_hex'])
        need(len(raw) == code['code_length'] and code['bcis'] == sorted(set(code['bcis'])),
             f'method {key} has malformed Code/BCI facts')
        need(code['bcis'] and code['bcis'][0] == 0 and max(code['bcis']) < len(raw),
             f'method {key} has out-of-range physical BCI')
        result[key] = method
    return result


def compare_recorded_facts(parsed: dict, recorded: dict, label: str) -> None:
    need(recorded.get('class_name') == parsed['class_name'] and recorded.get('major') == parsed['major'],
         f'{label}: collector class name/major differs from bytes')
    got = {(m['name'], m['descriptor']): m for m in recorded.get('methods', [])}
    actual = method_facts(parsed)
    need(set(got) == set(actual), f'{label}: collector method inventory differs from bytes')
    for key, method in actual.items():
        row = got[key]
        need(row.get('index') == method['index'] and row.get('access') == method['access']
             and row.get('code') == method['code'], f'{label} {key}: collector method/Code facts differ from bytes')


def verify_commands(doc: dict, out: Path) -> dict:
    commands = doc.get('commands')
    need(isinstance(commands, list) and commands, 'missing command inventory')
    by_label = {}
    for row in commands:
        label, index = row.get('label'), row.get('index')
        need(isinstance(label, str) and label not in by_label, f'duplicate/invalid command label {label}')
        need(isinstance(index, int), f'{label}: invalid command index')
        need(row.get('guard_stop') is None, f'{label}: runner guard stopped')
        streams = row.get('streams')
        need(isinstance(streams, dict) and set(streams) == {'stdout', 'stderr'}, f'{label}: incomplete raw streams')
        for name, record in streams.items():
            verify_pin(record, f'{label}/{name}')
            need(Path(record['path']) == out / 'raw' / f'{index}.{name}.raw', f'{label}/{name}: unexpected raw location')
        by_label[label] = row
    return by_label


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--matrix', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    matrix_path = args.matrix.resolve(strict=True)
    out = args.out.resolve()
    need(not out.exists(), f'refusing existing review output: {out}')
    doc_bytes = matrix_path.read_bytes()
    doc = json.loads(doc_bytes.decode('utf-8', errors='strict'))
    need(doc.get('schema') == EXPECTED_SCHEMA, 'unexpected rebuild-matrix schema')
    need(doc.get('status') == 'captured-pending-independent-review', 'matrix is not a completed capture')
    parser, parser_pin = load_parser()
    baseline_bytes = BASELINE.read_bytes()
    baseline = json.loads(baseline_bytes.decode('utf-8', errors='strict'))
    profiles = {row['profile']: row for row in baseline['profiles']}
    need(set(profiles) == PROFILES, 'baseline does not have both original class profiles')
    original = {}
    baseline_pins = []
    for name, profile in profiles.items():
        target_record = {'path': profile['target']['path'], 'bytes': profile['target']['bytes'],
                         'sha256': profile['target']['sha256']}
        outer_record = {'path': profile['outer']['path'], 'bytes': profile['outer']['bytes'],
                        'sha256': profile['outer']['sha256']}
        target_data, outer_data = verify_pin(target_record, f'{name} original target'), verify_pin(outer_record, f'{name} original outer')
        target_parsed, outer_parsed = parser.parse_class_file(target_data), parser.parse_class_file(outer_data)
        for parsed_original, recorded_original, role in ((target_parsed, profile['target'], 'target'),
                                                           (outer_parsed, profile['outer'], 'outer')):
            need(parsed_original['major'] == recorded_original['major']
                 and parsed_original['minor'] == recorded_original['minor']
                 and parsed_original['class_name'] == recorded_original['class_name']
                 and parsed_original['fields'] == recorded_original['fields']
                 and parsed_original['methods'] == recorded_original['methods'],
                 f'{name}: baseline {role} recorded facts do not parse from original class bytes')
        need(target_parsed['major'] == 52 and target_parsed['class_name'] == TARGET,
             f'{name}: original target is not the expected Java 8 class')
        need(outer_parsed['major'] == 52 and outer_parsed['class_name'] == OUTER,
             f'{name}: original outer is not the expected Java 8 class')
        for class_record in profile['class_files']:
            verify_pin(class_record, f'{name} original class output')
            baseline_pins.append(class_record)
        original[name] = {'target': target_parsed, 'outer': outer_parsed}

    source_rows = doc.get('source_inputs')
    need(isinstance(source_rows, list) and len(source_rows) == 12, 'expected 12 pinned compiler source inputs')
    sources = {}
    for item in source_rows:
        key = (item.get('kind'), item.get('profile'), item.get('form'), item.get('evidence'))
        kind, profile, form, evidence = key
        need(kind in FORMS and profile in PROFILES and form in FORMS[kind], f'invalid source selector {key}')
        need((kind == 'jarde' and evidence in ('default', 'all')) or (kind == 'jadx' and evidence == 'source'),
             f'invalid source evidence selector {key}')
        need(key not in sources, f'duplicate source selector {key}')
        copied = verify_pin(item['source_copy'], f'{key} compiler source')
        original_source = verify_pin(item['original_source'], f'{key} originating source')
        need(copied == original_source, f'{key}: copied Java source changed from saved source')
        verify_pin(item['input_pin'], f'{key} original class/archive input')
        if item.get('original_report') is not None:
            verify_pin(item['original_report'], f'{key} extraction report')
        if kind == 'jarde':
            baseline_cell = next(row for row in baseline['jarde_cells']
                                 if (row['profile'], row['input_form'], row['evidence']) == (profile, form, evidence))
            need(item['input_pin'] == baseline_cell['input']
                 and item['original_source'] == baseline_cell['whole_source']
                 and item['original_report'] == baseline_cell['report'],
                 f'{key}: Jarde source/report/input is not bound to the baseline cell')
        else:
            baseline_cell = next(row for row in baseline['jadx_cells']
                                 if (row['profile'], row['input_form']) == (profile, form))
            baseline_command = next(row for row in baseline['commands'] if row['index'] == baseline_cell['command'])
            original_input = pin(Path(baseline_command['argv'][-1]))
            need(item['original_source'] == baseline_cell['sources'][0]
                 and item['input_pin'] == original_input and item['original_report'] is None,
                 f'{key}: JADX source/input is not bound to the baseline extraction')
        sources[key] = item

    by_label = verify_commands(doc, matrix_path.parent)
    cells = doc.get('compilation_cells')
    need(isinstance(cells, list) and len(cells) == 24, 'expected 24 source/compiler output cells')
    seen, inspected, skipped = set(), [], []
    tracked_trees = []
    for cell in cells:
        selector = (cell.get('kind'), cell.get('profile'), cell.get('form'), cell.get('evidence'))
        kind, profile, form, evidence = selector
        compiler = cell.get('compiler')
        key = (*selector, compiler)
        need(kind in FORMS and profile in PROFILES and form in FORMS[kind] and compiler in COMPILERS,
             f'invalid compilation selector {key}')
        need((kind == 'jarde' and evidence in ('default', 'all')) or (kind == 'jadx' and evidence == 'source'),
             f'invalid compilation evidence {key}')
        need(key not in seen, f'duplicate compilation cell {key}')
        seen.add(key)
        source = sources[selector]
        label = f'compile-{kind}-{profile}-{form}-{evidence}-{compiler}'
        command = by_label.get(label)
        need(command is not None and cell.get('compile_command') == command['index']
             and cell.get('compile_exit_code') == command.get('exit_code'), f'{key}: compiler command binding mismatch')
        need(cell.get('source') == source.get('source_copy')
             and cell.get('original_source') == source.get('original_source')
             and cell.get('original_report') == source.get('original_report'), f'{key}: compile source provenance mismatch')
        argv = command.get('argv', [])
        tools = doc.get('jdk_manifest', {}).get('tools', {}).get(compiler, {})
        need(argv and argv[0] == tools.get('javac', {}).get('path')
             and Path(argv[-1]) == Path(source['source_copy']['path']),
             f'{key}: javac argv does not bind the pinned compiler and source')
        need(command.get('exit_code') == cell.get('compile_exit_code'), f'{key}: process exit differs from compiler cell')
        if command['exit_code'] != 0:
            need(cell.get('runtime') == [] and cell.get('target_class') is None,
                 f'{key}: failed compilation must not claim parsed target or runtime')
            skipped.append({'selector': list(key), 'status': cell.get('status'), 'reason': 'compiler failed; class inventory not asserted'})
            continue
        root = Path(cell.get('target_classes_root', ''))
        need(root.is_absolute() and root.is_dir(), f'{key}: successful compile has no output tree')
        expected_paths = {TARGET + '.class'}
        if kind == 'jadx' and form == 'bundle':
            expected_paths.add(OUTER + '.class')
        tree = class_tree(root)
        need(set(tree) == expected_paths, f'{key}: emitted class tree is {sorted(tree)}, expected {sorted(expected_paths)}')
        need(cell.get('target_classes_tree') == tree, f'{key}: collector class tree pin differs from actual tree')
        tracked_trees.append((root, tree, key))
        target_path = root / (TARGET + '.class')
        target_data = verify_pin(cell.get('target_class'), f'{key} emitted target')
        need(Path(cell['target_class']['path']) == target_path and tree[TARGET + '.class'] == cell['target_class'],
             f'{key}: target class pin/path does not match output tree')
        parsed = parser.parse_class_file(target_data)
        compare_recorded_facts(parsed, cell.get('target_facts') or {}, f'{key} target')
        need(parsed['major'] == 52 and parsed['class_name'] == TARGET,
             f'{key}: rebuilt target class name/major mismatch')
        need(abi(parsed) == abi(original[profile]['target']), f'{key}: rebuilt target ABI/access differs from original profile class')
        parsed_methods = method_facts(parsed)
        need(cell.get('all_methods_have_code') is True
             and len(parsed_methods) == len(parsed['methods']),
             f'{key}: successful output has a method missing Code')
        if kind == 'jadx' and form == 'bundle':
            outer_data = verify_pin(tree[OUTER + '.class'], f'{key} emitted outer')
            outer_parsed = parser.parse_class_file(outer_data)
            outer_methods = method_facts(outer_parsed)
            need(len(outer_methods) == len(outer_parsed['methods']), f'{key}: bundle outer has a method missing Code')
            need(outer_parsed['class_name'] == OUTER and outer_parsed['major'] == 52,
                 f'{key}: rebuilt bundle outer class name/major mismatch')
            need(abi(outer_parsed) == abi(original[profile]['outer']),
                 f'{key}: rebuilt outer ABI/access differs from original profile class')
            owner_pin = cell.get('owner_class')
            need(owner_pin == tree[OUTER + '.class'], f'{key}: collector owner pin differs from emitted outer')
        else:
            need(cell.get('owner_class') is None, f'{key}: child-only compile unexpectedly emitted/recorded outer')
        inspected.append({'selector': list(key), 'class_tree': tree,
                          'target': {'class_name': parsed['class_name'], 'class_access': parsed['access'],
                                     'major': parsed['major'], 'fields': len(parsed['fields']),
                                     'methods': len(parsed['methods']),
                                     'code_methods': sum(m['code'] is not None for m in parsed['methods'])},
                          'outer_checked': kind == 'jadx' and form == 'bundle'})

    expected_keys = {(kind, profile, form, evidence, compiler)
                     for kind, forms in FORMS.items() for profile in PROFILES for form in forms
                     for evidence in (('default', 'all') if kind == 'jarde' else ('source',))
                     for compiler in COMPILERS}
    need(seen == expected_keys, 'compiler cell matrix is incomplete')
    # Recheck every output class tree, baseline class, and source/input pin at end.
    for root, before, key in tracked_trees:
        need(class_tree(root) == before, f'{key}: emitted class tree changed during review')
    for profile in profiles.values():
        for record in profile['class_files']:
            verify_pin(record, 'original class final pin')
    for key, item in sources.items():
        verify_pin(item['source_copy'], f'{key} source final pin')
        verify_pin(item['original_source'], f'{key} original source final pin')
        verify_pin(item['input_pin'], f'{key} input final pin')
        if item.get('original_report') is not None:
            verify_pin(item['original_report'], f'{key} report final pin')
    need(matrix_path.read_bytes() == doc_bytes, 'matrix receipt changed during review')
    need(BASELINE.read_bytes() == baseline_bytes, 'baseline receipt changed during review')
    parser_data = HELPER.read_bytes()
    need(len(parser_data) == HELPER_BYTES and sha(parser_data) == HELPER_SHA256,
         'accepted parser changed during review')

    result = {
        'status': 'read_only_physical_inventory_complete',
        'matrix': {'path': str(matrix_path), 'bytes': len(doc_bytes), 'sha256': sha(doc_bytes),
                   'schema': doc['schema'], 'captured_status': doc['status']},
        'baseline': {'path': str(BASELINE), 'bytes': len(baseline_bytes), 'sha256': sha(baseline_bytes),
                     'class_profiles': sorted(profiles)},
        'parser': parser_pin,
        'compile_cells': {'total': len(cells), 'successful_output_trees_independently_parsed': len(inspected),
                          'failed_compile_cells_skipped': skipped},
        'inspected': inspected,
        'checks': {'original_reparsed_from_profile_bytes': True, 'target_and_bundle_outer_abi_access_compared': True,
                   'all_successful_emitted_methods_have_code': True, 'collector_target_facts_match_emitted_bytes': True,
                   'exact_emitted_class_trees_checked': True, 'end_pins_rechecked': True},
        'limits': ['Classfile Code bytes are parsed and compared with collector facts, not required to equal original Code bytes.',
                   'This checker does not establish runtime equivalence; runtime oracles belong to the rebuild-matrix reviewer.']
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'success_trees': len(inspected),
                      'compile_failures_skipped': len(skipped), 'out': str(out)}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
