# Seq1 full-source rebuild matrix preparation

This private preparation contains a collector, an independent receipt reviewer, and a small independent classfile decoder. Nothing here has run `javac`, `java`, Jarde, JADX, Cargo, Git, or network access. The matrix is unexecuted and has no acceptance result. This v2 preserves v1 and updates the historical review binding/source comparison, copied timeout-wrapper argv binding, and dependency receipt pins.

`collect_rebuild_matrix.py` consumes the reviewed Seq1 baseline receipt and copies the exact 8 saved Jarde outputs plus 4 saved JADX Java sources. It compiles each source with javac 8 (`-source 8 -target 8`) and JDK 23 (`--release 8`), for 24 source compilation cells. The saved sources remain byte-identical and use their required public-type filenames. Compilation uses the pinned baseline harness/dependency classpath and an empty source path. It does not remove methods, rewrite Java, rerun extraction, or repair compiler output.

The collector compiles the frozen reflection driver separately. Only a successfully compiled, independently parsed target class with the expected internal name, exactly `<init>()V` and `test(II)I`, Code on both methods, and classfile major 52 receives runtime attempts. It then invokes that rebuilt target on both pinned JVMs with `-Xverify:all`, the rebuilt output root and independent driver only, through the pinned 30-second process-group wrapper. The driver checks the actual `CodeSource` and reports six fixed inputs. Runtime output is compared byte-for-byte with the four original profile/JVM oracle runs. A wrong-root CodeSource negative control runs once after the first eligible target. Compile errors, missing/invalid/wrong targets, runtime failures, and oracle mismatches remain separate results; no-runtime cases are not counted as runtime passes.

The original JDK 8 major-55 harness boundary remains attached to the baseline evidence as a separate no-result boundary. It is not treated as a generated-target runtime outcome.

After root review, the intended entrypoints are:

```text
python3 -B collect_rebuild_matrix.py --out /private/tmp/<fresh-output-directory>
python3 -B review_rebuild_matrix.py /private/tmp/<fresh-output-directory>/execution.json /private/tmp/<fresh-review.json>
```

The accepted baseline review is pinned from `/private/tmp/jarde-testsequentialloops-baseline-review-root-v1-20261018/root-review.json`. Its receipt, original-source artifacts, tool pins, and six-case oracle remain bound as historical baseline evidence. The matrix freezes the current workspace source closure at start and compares it only with the end snapshot; it records whether that closure equals the historical receipt as an informational fact, and does not claim the historical CLI is the current product.

The reviewer independently checks raw stdout/stderr pins and command inventory, exact baseline/source bindings, full compiler argv and isolated source paths, classfile methods/Code/major/output trees, classpath exclusion of the original Seq1 classes, eligible runtime commands and oracle bytes, wrong-root rejection, dependencies, source closure, and final target absence. It does not make a recovery/SSA claim or validate a field inventory. Extending the small parser to report fields is outside this patch and remains for root review; v2 makes no field-inventory assertion. It refuses to overwrite the review output.

Files and script pins are recorded in `source-pins.json`. Python `-B` AST parsing passed for all three Python files. The independent classfile decoder was read-only checked against both original baseline target classes and the reflection driver; its dependency class-directory pins and harness exclusion were read-only checked against the historical receipt. Current source closure is intentionally not compared to the historical closure after later product changes. These are static preparation checks only, not matrix execution.
