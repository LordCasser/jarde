#!/usr/bin/env python3
"""Independent read-only review of a Seq1 full-source rebuild/runtime receipt."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import zipfile

ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
BASELINE_DIR = Path('/private/tmp/jarde-testsequentialloops-baseline-run-root-v1-20261018').resolve()
BASELINE_REVIEW = Path('/private/tmp/jarde-testsequentialloops-baseline-review-root-v1-20261018/root-review.json')
PREP = Path(__file__).resolve().parent
COLLECTOR = PREP / 'collect_rebuild_matrix.py'
TARGET = 'jadx/tests/integration/loops/TestSequentialLoops$TestCls'
OWNER = 'jadx/tests/integration/loops/TestSequentialLoops'
METHODS = {('<init>', '()V'), ('test', '(II)I')}
PROFILES = ('debug', 'no-debug')
JARDE_FORMS = ('child', 'bundle-child')
JADX_FORMS = ('child', 'bundle')
EVIDENCE = ('default', 'all')
COMPILERS = ('javac8', 'javac23')


def need(ok: bool, msg: str) -> None:
    if not ok:
        raise ValueError(msg)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def verify(record: dict, label: str) -> bytes:
    need(isinstance(record, dict), f'{label}: missing pin')
    path = Path(record.get('path', ''))
    need(path.is_absolute() and path.is_file(), f'{label}: pinned path missing: {path}')
    data = path.read_bytes()
    need(record.get('bytes') == len(data) and record.get('sha256') == sha(data), f'{label}: bytes/SHA mismatch')
    return data


def load_helpers(path: Path):
    spec = importlib.util.spec_from_file_location('seq1_matrix_classfile_helpers', path)
    need(spec is not None and spec.loader is not None, f'cannot load classfile parser {path}')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def stream(row: dict, name: str, out: Path) -> bytes:
    p = row.get('streams', {}).get(name)
    need(isinstance(p, dict), f'{row.get("label")}: missing {name} receipt')
    expected = out / 'raw' / f'{row["index"]}.{name}.raw'
    need(Path(p.get('path', '')) == expected, f'{row.get("label")}: unexpected raw path')
    return verify(p, f'{row.get("label")} {name}')


def class_tree(root: Path) -> dict:
    return {p.relative_to(root).as_posix(): pin(p) for p in sorted(root.rglob('*.class'))}


def method_set(parsed: dict) -> set[tuple[str, str]]:
    return {(m['name'], m['descriptor']) for m in parsed['methods']}


def source_grid(rows: list[dict]) -> dict[tuple, dict]:
    grid = {}
    for row in rows:
        key = row['kind'], row['profile'], row['form'], row['evidence']
        need(key not in grid, f'duplicate copied source {key}')
        grid[key] = row
    expected = {(kind, p, form, evidence)
                for kind, forms in (('jarde', JARDE_FORMS), ('jadx', JADX_FORMS))
                for p in PROFILES for form in forms
                for evidence in (EVIDENCE if kind == 'jarde' else ('source',))}
    need(set(grid) == expected and len(grid) == 12, 'source grid is not exactly 8 Jarde + 4 JADX artifacts')
    return grid


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('execution_json', type=Path)
    ap.add_argument('review_json', type=Path)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    execution = args.execution_json.resolve(strict=True)
    output = args.review_json.resolve()
    root = args.root.resolve(strict=True)
    need(root == ROOT, 'unexpected workspace root')
    need(not output.exists(), f'refusing existing review output {output}')
    out = execution.parent
    baseline_path = BASELINE_DIR / 'execution.json'
    need(baseline_path.is_file(), 'frozen Seq1 baseline is missing')
    baseline_raw = baseline_path.read_bytes()
    baseline = json.loads(baseline_raw)
    baseline_review_raw = BASELINE_REVIEW.read_bytes()
    baseline_review = json.loads(baseline_review_raw)
    need(baseline.get('schema') == 'cf11-original-testsequentialloops-baseline-v1'
         and baseline.get('status') == 'captured-pending-independent-review', 'unexpected original baseline state')
    need(baseline_review.get('status') == 'read_only_baseline_review_complete'
         and baseline_review.get('input', {}).get('sha256') == sha(baseline_raw)
         and baseline_review.get('input', {}).get('path') == str(baseline_path), 'baseline reviewer does not bind exact baseline bytes')
    base_pin = pin(baseline_path)
    review_pin = pin(BASELINE_REVIEW)
    raw_execution = execution.read_bytes()
    doc = json.loads(raw_execution)
    need(doc.get('schema') == 'cf11-testsequentialloops-full-source-rebuild-matrix-v1'
         and doc.get('status') == 'captured-pending-independent-review', 'matrix receipt not terminal capture')
    need(doc.get('finished_utc') and doc.get('error') is None, 'matrix receipt reports incomplete/error state')
    need(doc.get('baseline_receipt') == base_pin and doc.get('baseline_review') == review_pin,
         'matrix receipt does not pin frozen baseline and its review')
    need(doc.get('baseline_review_input_sha256') == sha(baseline_raw), 'baseline review input SHA mismatch')
    need(doc.get('baseline_source_closure_matches_current') == (doc.get('source_before') == baseline.get('source_pins_before')),
         'historical/current source-closure comparison fact is inconsistent')
    helper_path = PREP / 'classfile_helpers.py'
    helpers = load_helpers(helper_path)
    need((out/'collector.py').is_file() and (out/'collector.py').read_bytes()==COLLECTOR.read_bytes(),
         'captured collector differs from reviewed private collector source')

    # Commands and both raw streams are individually pinned; guard stops are fatal.
    commands = doc.get('commands')
    need(isinstance(commands, list) and commands, 'missing command list')
    by_label = {}
    for row in commands:
        label = row.get('label')
        need(isinstance(label, str) and label not in by_label, f'duplicate/missing command label {label}')
        need(row.get('guard_stop') is None, f'guard stopped {label}: {row.get("guard_stop")}')
        need(Path(row.get('cwd', '')).resolve() == ROOT, f'{label}: unexpected working directory')
        need(isinstance(row.get('argv'), list) and row['argv'], f'{label}: argv missing')
        stream(row, 'stdout', out); stream(row, 'stderr', out)
        by_label[label] = row
    need([r['index'] for r in commands] == list(range(1, len(commands) + 1)), 'command IDs not sequential')

    # Baseline source/runtime oracle remains the exact authority; no hand-computed expected values.
    verify(baseline['original_oracle'], 'original six-case JVM oracle')
    oracle = Path(baseline['original_oracle']['path']).read_bytes()
    need(len(oracle.decode('utf-8', 'strict').splitlines()) == 6, 'original oracle is not six observed rows')
    need(len(baseline.get('original_runtime', [])) == 4, 'baseline does not contain four original profile/JVM runs')
    for item in baseline['original_runtime']:
        cmd = next((r for r in baseline['commands'] if r['index'] == item['command']), None)
        need(cmd is not None and item['exit_code'] == cmd['exit_code'] == 0, 'original runtime was not successful')
        need(stream(cmd, 'stdout', BASELINE_DIR) == oracle, 'original JVM output differs from saved oracle')
    boundary = baseline.get('javac8_boundary') or {}
    bcmd = next((r for r in baseline['commands'] if r['label'] == 'original-javac8-harness-boundary'), None)
    need(bcmd is not None and bcmd['exit_code'] != 0 and boundary.get('observed_major_55_diagnostic')
         and b'55.0' in stream(bcmd, 'stderr', BASELINE_DIR), 'JDK8 major-55 harness boundary not evidenced')
    wrong = baseline.get('wrong_root_control') or {}
    wcmd = next((r for r in baseline['commands'] if r['index'] == wrong.get('command')), None)
    need(wcmd is not None and wcmd['exit_code'] != 0 and b'target loaded from' in stream(wcmd, 'stderr', BASELINE_DIR),
         'original wrong-CodeSource control missing')

    # Exact inputs: frozen source/extraction output, class inputs, helper tools, dependency closure.
    source_grid_rows = source_grid(doc.get('source_inputs', []))
    base_jarde = {(r['profile'], r['input_form'], r['evidence']): r for r in baseline['jarde_cells']}
    base_jadx = {(r['profile'], r['input_form']): r for r in baseline['jadx_cells']}
    need(len(base_jarde) == 8 and len(base_jadx) == 4, 'baseline source artifact grid incomplete')
    for key, item in source_grid_rows.items():
        kind, profile, form, evidence = key
        if kind == 'jarde':
            source_row = base_jarde[(profile, form, evidence)]
            need(item.get('original_source') == source_row['whole_source']
                 and item.get('original_report') == source_row['report']
                 and item.get('input_pin') == source_row['input'], f'{key}: not bound to exact Jarde source/report/input')
            rb = verify(source_row['report'], f'{key} original report')
            source = verify(source_row['whole_source'], f'{key} original source')
            need(json.loads(rb).get('text', '').encode('utf-8') == source, f'{key}: source differs from report text')
            source_name = 'TestSequentialLoops$TestCls.java'
        else:
            source_row = base_jadx[(profile, form)]
            command = next((r for r in baseline['commands'] if r['index'] == source_row['command']), None)
            need(command is not None and len(source_row.get('sources') or []) == 1, f'{key}: JADX extraction missing')
            expected_input = pin(Path(command['argv'][-1]))
            need(item.get('original_source') == source_row['sources'][0] and item.get('input_pin') == expected_input,
                 f'{key}: not bound to exact JADX source/input')
            verify(source_row['sources'][0], f'{key} original JADX source')
            source_name = 'TestSequentialLoops.java' if form == 'bundle' else 'TestSequentialLoops$TestCls.java'
        need(item.get('source_filename') == source_name, f'{key}: incorrect javac public-type filename')
        original = verify(item['original_source'], f'{key} original source')
        copied = verify(item['source_copy'], f'{key} compiler source')
        need(copied == original, f'{key}: compiler source changed bytes')
    need(len(doc.get('compilation_cells', [])) == 24, 'expected the 12 full sources × 2 compilers')

    # Validate every compiler cell and independently parse all produced target classes.
    eligible = {}
    failures, no_runtime = [], []
    expected_keys = set()
    cells_seen = set()
    for cell in doc['compilation_cells']:
        kind, profile, form, evidence, compiler = (cell.get('kind'), cell.get('profile'), cell.get('form'),
                                                    cell.get('evidence'), cell.get('compiler'))
        key = kind, profile, form, evidence, compiler
        need(key not in cells_seen, f'duplicate compiler cell {key}')
        cells_seen.add(key)
        need(kind in ('jarde', 'jadx') and profile in PROFILES and compiler in COMPILERS,
             f'invalid compile selector {key}')
        forms = JARDE_FORMS if kind == 'jarde' else JADX_FORMS
        need(form in forms and ((kind == 'jarde' and evidence in EVIDENCE) or (kind == 'jadx' and evidence == 'source')),
             f'invalid source selector {key}')
        expected_keys.add(key)
        label = f'compile-{kind}-{profile}-{form}-{evidence}-{compiler}'
        cmd = by_label.get(label)
        need(cmd is not None and cell.get('compile_command') == cmd['index']
             and cell.get('compile_exit_code') == cmd['exit_code'], f'{key}: compile command binding mismatch')
        item = source_grid_rows[(kind, profile, form, evidence)]
        src = Path(item['source_copy']['path'])
        argv = cmd['argv']
        jdks = doc['jdk_manifest']['tools']
        opts = (['-source','8','-target','8','-g:none','-Xlint:-options','-proc:none'] if compiler == 'javac8'
                else ['--release','8','-g:none','-proc:none'])
        need(argv[0] == jdks[compiler]['javac']['path'], f'{label}: wrong javac executable')
        empty = Path(argv[argv.index('-sourcepath') + 1]); classes = Path(argv[argv.index('-d') + 1])
        expected_argv = [jdks[compiler]['javac']['path'], *opts, '-encoding','UTF-8','-classpath',
                         os.pathsep.join(doc['classpath_full_compile']), '-sourcepath',str(empty),'-d',str(classes),str(src)]
        need(argv == expected_argv and empty.is_dir() and not any(empty.iterdir()), f'{label}: argv/source isolation mismatch')
        need(Path(cell['target_class_expected']) == classes / (TARGET + '.class'), f'{label}: target path mismatch')
        exit_code = cmd['exit_code']
        if exit_code != 0:
            need(cell.get('runtime') == [] and cell.get('target_class') is None
                 and cell.get('status') in ('compile_failed_no_runtime','compile_failed_javac8_major55_no_runtime'),
                 f'{label}: compile failure conflated with runtime')
            failures.append({'selector': list(key), 'exit_code': exit_code, 'status': cell['status']})
            continue
        target_path = classes / (TARGET + '.class')
        if not target_path.is_file():
            need(cell.get('runtime') == [] and cell.get('status') == 'compile_succeeded_target_missing_no_runtime',
                 f'{label}: missing target not retained as no-runtime')
            no_runtime.append({'selector': list(key), 'status': cell['status']}); continue
        class_bytes = verify(cell['target_class'], f'{label} classfile')
        need(Path(cell['target_class']['path']) == target_path, f'{label}: target class pin path mismatch')
        try:
            parsed = helpers.parse_class_file(class_bytes)
        except (ValueError, IndexError, KeyError, UnicodeDecodeError) as parse_error:
            need(cell.get('status') == 'compiled_target_classfile_invalid_no_runtime' and cell.get('runtime') == []
                 and cell.get('target_facts') is None, f'{label}: invalid classfile was not retained as no-runtime: {parse_error}')
            need(cell.get('target_classes_tree') == class_tree(classes) and cell.get('target_classes_root') == str(classes),
                 f'{label}: invalid target output tree pin mismatch')
            no_runtime.append({'selector':list(key),'status':cell['status'],'parse_error':str(parse_error)})
            continue
        facts = cell.get('target_facts') or {}
        need(facts.get('class_name') == parsed['class_name'] and facts.get('major') == parsed['major'],
             f'{label}: collector class header differs from independent parser')
        fact_methods = {(m['name'],m['descriptor']):m for m in facts.get('methods',[])}
        parsed_methods = {(m['name'],m['descriptor']):m for m in parsed['methods']}
        need(set(fact_methods) == set(parsed_methods), f'{label}: method inventory differs from bytes')
        for mk, method in parsed_methods.items():
            recorded = fact_methods[mk]
            need(recorded.get('code') == method.get('code') and recorded.get('access') == method.get('access')
                 and recorded.get('index') == method.get('index'), f'{label} {mk}: Code/access/index differs')
        is_target = parsed['class_name'] == TARGET and method_set(parsed) == METHODS
        all_code = all(m.get('code') is not None for m in parsed['methods'])
        java8 = parsed['major'] == 52
        need(cell.get('declared_methods_match_expected') is is_target and cell.get('all_methods_have_code') is all_code
             and cell.get('classfile_major_is_java8') is java8, f'{label}: status facts not derived from class bytes')
        need(cell.get('target_classes_tree') == class_tree(classes), f'{label}: output class tree pin mismatch')
        owner = classes / (OWNER + '.class')
        if owner.exists():
            need(cell.get('owner_class') == pin(owner), f'{label}: owner class pin mismatch')
        else:
            need(cell.get('owner_class') is None, f'{label}: absent owner recorded as present')
        need(cell.get('target_classes_root') == str(classes), f'{label}: output root mismatch')
        if is_target and all_code and java8:
            need(cell.get('status') == 'compiled_target_java8_two_methods', f'{label}: eligible status mismatch')
            eligible[key] = (cell, classes)
        else:
            need(cell.get('runtime') == [] and cell.get('status') == 'compiled_target_identity_or_major_mismatch_no_runtime',
                 f'{label}: invalid target should not run')
            no_runtime.append({'selector': list(key), 'status':cell['status'],'class_name':parsed['class_name'],
                               'major':parsed['major'],'methods':sorted(map(list,method_set(parsed)))})
    expected_keys = {(kind,p,form,e,compiler) for kind,forms in (('jarde',JARDE_FORMS),('jadx',JADX_FORMS))
                     for p in PROFILES for form in forms for e in (EVIDENCE if kind=='jarde' else ('source',))
                     for compiler in COMPILERS}
    need(cells_seen == expected_keys, '24-cell full compile grid mismatch')

    # Runtime rows exist only for eligible rebuilt targets; each JVM result must equal observed original oracle.
    expected_runtime_rows = []
    runtime_failures = []
    for key, (cell, classes) in eligible.items():
        rows = cell.get('runtime')
        need(isinstance(rows,list) and len(rows) == 2, f'{key}: eligible output needs one run on each JVM')
        seen = set()
        for row in rows:
            runtime = row.get('runtime')
            need(runtime in COMPILERS and runtime not in seen, f'{key}: duplicate/invalid runtime')
            seen.add(runtime)
            label = f'runtime-{key[0]}-{key[1]}-{key[2]}-{key[3]}-{key[4]}-on-{runtime}'
            cmd = by_label.get(label)
            need(cmd is not None and cmd['index'] == row.get('command') and cmd['exit_code'] == row.get('exit_code'),
                 f'{label}: runtime row not bound to process result')
            cp = [str(classes), str(Path(doc['driver_compile']['classes'][0]['path']).parent)]
            need(row.get('classpath') == cp and cmd.get('matrix_classpath') == cp, f'{label}: runtime classpath not isolated')
            argv = cmd['argv']; wrapper = doc['timeout_wrapper_copy_pin']['path']
            need(argv == [sys.executable,'-B',wrapper,'30',doc['jdk_manifest']['tools'][runtime]['java']['path'],
                          '-Xverify:all','-cp',os.pathsep.join(cp),'TestSequentialLoopsDriver',str(classes)],
                 f'{label}: runtime command differs from strict driver contract')
            stdout, stderr = stream(cmd,'stdout',out), stream(cmd,'stderr',out)
            equal = cmd['exit_code'] == 0 and stdout == oracle
            need(row.get('oracle_equal_byte_for_byte') is equal and row.get('stdout_sha256') == sha(stdout)
                 and row.get('stderr_sha256') == sha(stderr), f'{label}: result flags/digests mismatch raw bytes')
            status = 'matches_original_jvm_oracle' if equal else ('runtime_failed' if cmd['exit_code'] != 0 else 'runtime_oracle_mismatch')
            need(row.get('status') == status and row.get('stdout_bytes') == len(stdout), f'{label}: runtime outcome misclassified')
            if not equal: runtime_failures.append({'label':label,'status':status,'exit_code':cmd['exit_code']})
            need(cmd.get('target_class_tree_before') == cmd.get('target_class_tree_after') == cell['target_classes_tree'],
                 f'{label}: target class tree changed during runtime')
            need(cmd.get('driver_class_tree_before') == cmd.get('driver_class_tree_after') == doc['driver_compile']['classes_tree'],
                 f'{label}: driver class tree changed during runtime')
            need(Path(cmd.get('expected_target_root','')).resolve() == classes.resolve(), f'{label}: CodeSource target root mismatch')
            expected_runtime_rows.append({**{k2:cell[k2] for k2 in ('kind','profile','form','evidence','compiler')}, **row})
        need(seen == set(COMPILERS), f'{key}: runtime matrix incomplete')
    need(doc.get('runtime_rows') == expected_runtime_rows, 'top-level runtime summary differs from per-cell rows')
    expected_runtime_labels = {f'runtime-{k[0]}-{k[1]}-{k[2]}-{k[3]}-{k[4]}-on-{rt}' for k in eligible for rt in COMPILERS}
    need({l for l in by_label if l.startswith('runtime-')} == expected_runtime_labels, 'missing or extra runtime commands')

    # The standalone driver and negative CodeSource control are themselves pinned.
    driver_compile = doc.get('driver_compile') or {}
    dcmd = by_label.get('compile-independent-driver-javac8')
    need(dcmd is not None and dcmd['exit_code'] == 0 and driver_compile.get('exit_code') == 0
         and dcmd['index'] == driver_compile.get('command'), 'independent reflection driver compile failed')
    driver_empty = out / 'empty-sourcepath-driver'
    driver_source_path = Path(driver_compile['source']['path'])
    driver_classes_root = Path(driver_compile['classes'][0]['path']).parent
    driver_javac = doc['jdk_manifest']['tools']['javac8']['javac']['path']
    expected_driver_argv = [driver_javac, '-source','8','-target','8','-g:none','-Xlint:-options','-encoding','UTF-8',
                            '-proc:none','-classpath',str(driver_empty),'-sourcepath',str(driver_empty),
                            '-d',str(driver_classes_root),str(driver_source_path)]
    need(dcmd['argv'] == expected_driver_argv and driver_empty.is_dir() and not any(driver_empty.iterdir()),
         'independent driver compile command/sourcepath differs')
    driver_source = verify(driver_compile['source'],'matrix driver source')
    need(driver_source == verify(baseline['driver'],'baseline driver source'), 'driver differs from frozen baseline')
    need(doc.get('driver_copy_pin') == driver_compile['source'] and doc.get('driver_source_after') == driver_compile['source'],
         'driver copy before/after pins differ')
    driver_class_pins = [verify(p,'driver class') for p in driver_compile.get('classes',[])]
    need(len(driver_class_pins) == 1 and doc.get('driver_classes_tree_after') == driver_compile.get('classes_tree')
         == class_tree(Path(driver_compile['classes'][0]['path']).parent), 'driver class tree does not match pin')
    driver_facts=helpers.parse_class_file(driver_class_pins[0])
    need(driver_facts['class_name']=='TestSequentialLoopsDriver' and driver_facts['major']==52
         and method_set(driver_facts)=={('<init>','()V'),('main','([Ljava/lang/String;)V'),('invoke','(Ljava/lang/reflect/Method;Ljava/lang/Object;II)Ljava/lang/Object;')},
         'independent reflection driver class identity/methods differ')
    wrong_rows = doc.get('wrong_root_controls')
    if eligible:
        need(isinstance(wrong_rows,list) and len(wrong_rows)==1, 'expected one matrix wrong-root control')
        wrong = wrong_rows[0]; wcmd=by_label.get('matrix-wrong-root-code-source-rejection')
        need(wcmd is not None and wcmd['index']==wrong['command'] and wcmd['exit_code'] != 0, 'wrong-root control did not reject')
        stderr=stream(wcmd,'stderr',out); first_cell=next(iter(eligible.values()))[1]
        classes=first_cell; driver_root=Path(driver_compile['classes'][0]['path']).parent
        expected_root=Path(wrong['expected_root'])
        need(wcmd['argv']==[sys.executable,'-B',doc['timeout_wrapper_copy_pin']['path'],'30',
                            doc['jdk_manifest']['tools']['javac23']['java']['path'],'-Xverify:all','-cp',
                            os.pathsep.join([str(classes),str(driver_root)]),'TestSequentialLoopsDriver',str(expected_root)],
             'wrong-root argv differs from negative control contract')
        need(wrong.get('rejected') is True and wrong.get('stderr_sha256')==sha(stderr)
             and b'target loaded from' in stderr and expected_root.is_dir(), 'wrong-root evidence missing')
    else:
        need(not wrong_rows and 'matrix-wrong-root-code-source-rejection' not in by_label,
             'wrong-root control must not be attempted without a runtime-eligible target')

    # Fully accounted labels and final source/dependency/tool pins.
    expected_labels={'compile-independent-driver-javac8'} | {f'compile-{k[0]}-{k[1]}-{k[2]}-{k[3]}-{k[4]}' for k in expected_keys} | expected_runtime_labels
    if eligible: expected_labels.add('matrix-wrong-root-code-source-rejection')
    need(set(by_label)==expected_labels, 'unaccounted/missing process commands')
    need(len(commands)==len(expected_labels), 'command inventory count differs from actual command rows')
    need(doc.get('source_before')==doc.get('source_after') and doc.get('source_unchanged') is True
         and doc.get('baseline_unchanged') is True and doc.get('target_absent') is True, 'final guard state not certified')
    need(not (ROOT/'target').exists() and not (ROOT/'target').is_symlink(), 'workspace target exists after matrix')
    compare_path=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
    compare=load_helpers(PREP/'classfile_helpers.py')
    # Pin tables from collector must exactly retain initial values and remain current.
    helper_pins=doc['source_pins']
    need(doc.get('helper_pins_after')==helper_pins, 'helper source pins changed')
    for role,record in helper_pins.items(): verify(record,f'{role} helper')
    need(doc.get('source_after')==helpers.source_closure(ROOT), 'current workspace source closure differs from matrix')
    need(doc.get('baseline_receipt_after')==base_pin and pin(baseline_path)==base_pin
         and doc.get('baseline_review_after')==review_pin and pin(BASELINE_REVIEW)==review_pin,
         'baseline receipt/review changed during matrix')
    expected_original_classes=[pin for profile in baseline['profiles'] for pin in profile['class_files']]
    need(doc.get('original_class_pins')==expected_original_classes
         and doc.get('original_classes_after')==expected_original_classes, 'original class pins changed/incomplete')
    for record in expected_original_classes: verify(record,'original classfile')
    need(doc.get('runtime_timeout_wrapper') == baseline['runtime_bound'], 'runtime wrapper differs from frozen baseline')
    verify(doc['runtime_timeout_wrapper'],'baseline timeout wrapper')
    need(doc.get('timeout_wrapper_copy_pin')==doc.get('timeout_wrapper_after'), 'copied timeout wrapper changed')
    verify(doc['timeout_wrapper_copy_pin'],'copied timeout wrapper')
    expected_after=[]
    for item in doc['source_inputs']:
        for role, pin_key in (('source_copy','source_copy'),('original_source','original_source'),
                              ('original_report','original_report'),('input_class_or_archive','input_pin')):
            if item.get(pin_key):
                expected_after.append({'selector':[item['kind'],item['profile'],item['form'],item['evidence']],
                                       'role':role,'pin':item[pin_key]})
    need(doc.get('source_inputs_after') == expected_after, 'source after-pin table is incomplete or changed')
    for item in doc['source_inputs']:
        for role in ('source_copy','original_source','original_report','input_pin'):
            record=item.get(role)
            if record: verify(record,f'{item["kind"]}/{item["profile"]}/{item["form"]} {role}')
    need(doc.get('dependencies_after',{}).get('harness')==baseline['harness_jar']
         and doc.get('dependencies_after',{}).get('jars')==baseline['jar_pins']
         and doc.get('dependencies_after',{}).get('classes')==baseline['directory_pins'], 'dependency pins differ from baseline')
    for record in [baseline['harness_jar'],*baseline['jar_pins']]: verify(record,'compile dependency')
    for folder,expected in baseline['directory_pins'].items():
        need(class_tree(Path(folder))==expected,f'dependency class tree changed: {folder}')
    need(doc.get('dependency_reference')==baseline['dependency_reference']
         and doc.get('dependency_reference_after')==baseline['dependency_reference']
         and doc.get('classpath_full_compile')==baseline['classpath'], 'compile dependency/classpath differs from pinned baseline')
    verify(baseline['dependency_reference'],'dependency reference receipt')
    with zipfile.ZipFile(baseline['harness_jar']['path']) as jar:
        need(not any('TestSequentialLoops' in name for name in jar.namelist()), 'compile harness leaks Seq1 owner/target')
    for folder in baseline['directory_pins']:
        base=Path(folder)
        need(not (base/(TARGET+'.class')).exists() and not (base/(OWNER+'.class')).exists(),
             f'compile dependency leaks original Seq1 owner/target: {folder}')
    need(doc.get('jdk_manifest')==baseline['jdk_manifest'], 'JDK manifest differs from baseline')
    need(doc.get('upstream_source')==baseline['source'], 'upstream source pin differs from baseline')
    verify(doc['upstream_source'],'original upstream source')
    need(doc.get('historical_baseline_cli')==baseline['cli'] and doc.get('jadx')==baseline['jadx']
         and doc.get('jadx_jar')==baseline['jadx_jar'], 'product/JADX pins differ from baseline')
    for name in ('historical_baseline_cli','jadx','jadx_jar'): verify(doc[name],name)
    need(doc.get('runtime_classpath_policy')=='rebuilt target/owner output root plus independent reflection driver only',
         'runtime classpath policy differs')
    need((ROOT/'target').exists() is False, 'target directory is present')

    output.parent.mkdir(parents=True,exist_ok=True)
    result={'status':'read_only_seq1_rebuild_review_complete',
            'input':{'path':str(execution),'bytes':len(raw_execution),'sha256':sha(raw_execution)},
            'baseline':{'path':str(baseline_path),'bytes':len(baseline_raw),'sha256':sha(baseline_raw)},
            'baseline_review':{'path':str(BASELINE_REVIEW),'bytes':len(baseline_review_raw),'sha256':sha(baseline_review_raw)},
            'checker':{'path':str(Path(__file__).resolve()),'bytes':Path(__file__).stat().st_size,'sha256':sha(Path(__file__).read_bytes())},
            'classfile_helper':{'path':str(helper_path),'bytes':helper_path.stat().st_size,'sha256':sha(helper_path.read_bytes())},
            'collector_copy':{'path':str(out/'collector.py'),'bytes':(out/'collector.py').stat().st_size,'sha256':sha((out/'collector.py').read_bytes()),'matches_prepared_source':True},
            'source_inputs':{'count':len(source_grid_rows),'all_byte_identical_to_frozen_artifacts':True},
            'commands':{'count':len(commands),'raw_streams':2*len(commands)},
            'compile':{'cells':len(cells_seen),'eligible':len(eligible),'compile_failures_no_runtime':failures,'other_no_runtime':no_runtime},
            'runtime':{'observations':sum(len(c.get('runtime',[])) for c,_ in eligible.values()),'failures_or_mismatches':runtime_failures,
                        'oracle_sha256':sha(oracle)},
            'wrong_root_control':bool(eligible),
            'final_guards':{'source_unchanged':True,'baseline_inputs_unchanged':True,'target_absent':True},
            'limitations':['This validates full-source rebuild and observed runtime behavior only; it makes no SSA/recovery claim.',
                           'Compile failures, invalid/missing target classes, runtime failures and oracle mismatches remain distinct and are not accepted as successes.',
                           'The JDK8 major-55 harness boundary comes from the original baseline and is not a generated-target runtime result.',
                           'The historical baseline source closure is recorded as an informational comparison only; current source stability is checked against the matrix start/end snapshots.',
                           'The classfile parser validates method/Code inventory and class tree, but this review does not claim a field-inventory check.']}
    with output.open('x',encoding='utf-8') as f: json.dump(result,f,ensure_ascii=False,indent=2,sort_keys=True); f.write('\n')
    print(json.dumps({'status':result['status'],'compile_cells':len(cells_seen),'eligible':len(eligible),
                      'runtime_rows':result['runtime']['observations'],'compile_failures':len(failures),'review':str(output)}))
    return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except (OSError,ValueError,KeyError,TypeError,json.JSONDecodeError) as exc:
        raise SystemExit(f'Seq1 rebuild review failed: {exc}')
