#!/usr/bin/env python3
"""Capture a complete-source TestSequentialLoops2 baseline without editing inputs."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, re, shutil, sys, zipfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
SOURCE = Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestSequentialLoops2.java')
SOURCE_SHA256 = 'adb34f80f7d55cd3309ed7708f0fdb46768cf32e4004dbd13d4e278530306720'
CLI = Path('/private/tmp/jarde-statementful-loop-copy-broad-gates-root-v1-20261018/candidate-cli')
CLI_SHA256 = 'aabf62fe373876d176e6001bf3ed1fd84f80d2169ff5e787c4095c5d253c63d9'
DEPENDENCY_REFERENCE = Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018/execution.json')
DEPENDENCY_REFERENCE_SHA256 = '5a7d6572e600d19dc45d78030d0b12867bc742c4b014381fb5c7b059db171d35'
SEQ1_TEMPLATE = Path('/private/tmp/jarde-seq1-original-final-pipeline-run-root-v1-20261018/baseline/collector.py')
SEQ1_TEMPLATE_SHA256 = '6ccef18d249035615b0ed640b95a02cfa60b75a8924cd81c0955362fa9ad4461'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA256 = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA256 = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
RUNTIME_BOUND = Path('/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
RUNTIME_BOUND_SHA256 = '73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
COMPARE_REL = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA256 = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
INTERNAL_CLASS = 'jadx/tests/integration/loops/TestSequentialLoops2$TestCls'
TARGET_DOT = 'jadx.tests.integration.loops.TestSequentialLoops2$TestCls'
OUTER_INTERNAL = 'jadx/tests/integration/loops/TestSequentialLoops2'
PARSER = Path(__file__).with_name('classfile_helpers.py')
PARSER_SHA256 = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
DRIVER_SHA256 = '21670301815003eff605bef518c710c033be1cae644c45365a870349aafe0175'
EXPECTED_CHILD_METHODS = {('<init>', '()V'), ('asciiToLowerCase', '(Ljava/lang/String;)Ljava/lang/String;'), ('<clinit>', '()V')}
EXPECTED_CHILD_FIELDS = {('lowercases', '[C', 0x000a)}
EXPECTED_OUTER_METHODS = {('<init>', '()V'), ('test', '()V'), ('testNoDebug', '()V')}
MODES = ('default', 'configured128')
RUNTIMES = ('javac8', 'javac23')
PROFILES = ('debug', 'no-debug')
EVIDENCE = ('default', 'all')


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def pin(compare, path: Path) -> dict:
    return compare.pin(path)


def class_method_set(facts: dict) -> set[tuple[str, str]]:
    return {(row['name'], row['descriptor']) for row in facts['methods']}


def tree_pins(compare, root: Path) -> dict:
    return {path.relative_to(root).as_posix(): pin(compare, path) for path in sorted(root.rglob('*.class'))}


def parse_driver_rows(raw: bytes, mode: str) -> list[dict]:
    text = raw.decode('utf-8', errors='strict')
    pattern = re.compile(r'^CASE mode=(default|configured128) index=(\d+) input=(\S+) outcome=(return|throw) (.+)$')
    inputs = {
        'default': ['<null>', '<empty>', '00e9', 'd83d,de00', '0000', '0061', '0041', '0041,0062'],
        'configured128': ['<null>', '0041', '0061,0062,0063', '00e9', 'd83d,de00', '0041,00e9', '0041,00e9,0042', '0041,0042,0043'],
    }[mode]
    rows = []
    for line in text.splitlines():
        match = pattern.fullmatch(line)
        if match is None:
            raise ValueError(f'{mode}: malformed observation: {line!r}')
        got_mode, index_text, input_units, outcome, tail = match.groups()
        index = int(index_text)
        if got_mode != mode or index != len(rows) or index >= len(inputs) or input_units != inputs[index]:
            raise ValueError(f'{mode}: case order/input differs at {len(rows)}: {line!r}')
        if outcome == 'return':
            returned = re.fullmatch(r'same=(true|false) value=(<null>|<empty>|[0-9a-f]{4}(?:,[0-9a-f]{4})*)', tail)
            if returned is None:
                raise ValueError(f'{mode}: malformed return row: {line!r}')
            rows.append({'mode': mode, 'index': index, 'input_utf16': input_units, 'outcome': 'return',
                         'same_object': returned.group(1) == 'true', 'value_utf16': returned.group(2), 'raw': line})
        else:
            thrown = re.fullmatch(r'type=([A-Za-z0-9_.$]+) message=(<null>|<empty>|[0-9a-f]{4}(?:,[0-9a-f]{4})*)', tail)
            if thrown is None:
                raise ValueError(f'{mode}: malformed exception row: {line!r}')
            rows.append({'mode': mode, 'index': index, 'input_utf16': input_units, 'outcome': 'throw',
                         'exception_type': thrown.group(1), 'message_utf16': thrown.group(2), 'raw': line})
    if len(rows) != 8:
        raise ValueError(f'{mode}: expected eight case observations, got {len(rows)}')
    return rows


def semantic_projection(rows: list[dict]) -> list[dict]:
    result = []
    for row in rows:
        base = {k: row[k] for k in ('mode', 'index', 'input_utf16', 'outcome')}
        if row['outcome'] == 'return':
            base.update({'same_object': row['same_object'], 'value_utf16': row['value_utf16']})
        else:
            base['exception_type'] = row['exception_type']
        result.append(base)
    return result


def full_class_facts(compare, path: Path, role: str) -> dict:
    facts = compare.parse_class(path)
    physical = full_parser.parse_class_file(path.read_bytes())
    if physical['class_name'] != facts['class_name'] or physical['major'] != facts['major'] or physical['methods'] != facts['methods']:
        raise RuntimeError(f'{role}: independent physical method/Code census differs')
    if sorted((x['name'], x['descriptor'], x['access']) for x in physical['fields']) != sorted(facts['fields']):
        raise RuntimeError(f'{role}: independent physical field census differs')
    facts['access'] = physical['access']
    methods = facts['methods']
    keys = class_method_set(facts)
    if len(keys) != len(methods) or any(m.get('code') is None for m in methods):
        raise RuntimeError(f'{role}: duplicate method or method without Code')
    for method in methods:
        code = method['code']
        if not code.get('bcis') or code['bcis'][0] != 0 or code['bcis'][-1] >= code['code_length']:
            raise RuntimeError(f'{role} {method["name"]}{method["descriptor"]}: invalid physical BCI facts')
    return facts


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    root, out = args.root.resolve(strict=True), args.out.resolve()
    if root != ROOT.resolve(): raise SystemExit(f'workspace differs from pinned root: {root}')
    if out.exists(): raise SystemExit(f'refusing existing output: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink(): raise SystemExit('target must be absent')
    if sha(SOURCE) != SOURCE_SHA256: raise SystemExit('complete upstream source pin mismatch')
    if sha(CLI) != CLI_SHA256: raise SystemExit('statementful-loop copy broad-gates CLI pin mismatch')
    if sha(DEPENDENCY_REFERENCE) != DEPENDENCY_REFERENCE_SHA256: raise SystemExit('dependency reference pin mismatch')
    if sha(SEQ1_TEMPLATE) != SEQ1_TEMPLATE_SHA256: raise SystemExit('accepted Seq1 collector template pin mismatch')
    if sha(JADX) != JADX_SHA256 or sha(JADX_JAR) != JADX_JAR_SHA256: raise SystemExit('JADX 1.5.6 pin mismatch')
    if sha(RUNTIME_BOUND) != RUNTIME_BOUND_SHA256: raise SystemExit('runtime wrapper pin mismatch')

    compare_path = root / COMPARE_REL
    guard_path, scanner_path = root / GUARD_REL, root / SCANNER_REL
    if sha(PARSER) != PARSER_SHA256: raise SystemExit('full physical parser pin mismatch')
    global full_parser
    full_parser = load(PARSER, 'seq2_full_physical_parser')
    compare = load(compare_path, 'seq2_compare')
    if compare.sha(compare_path) != COMPARE_SHA256 or compare.sha(guard_path) != GUARD_SHA256 \
            or compare.sha(scanner_path) != SCANNER_SHA256:
        raise SystemExit('compare/guard/scanner pin mismatch')
    guard, scanner = load(guard_path, 'seq2_guard'), load(scanner_path, 'seq2_scanner')
    jdks, jdk_record = compare.configured_jdks(root / JDK_MANIFEST_REL, JDK_MANIFEST_SHA256)
    dependency = json.loads(DEPENDENCY_REFERENCE.read_text(encoding='utf-8'))
    if dependency.get('schema') != 'cf11-original-nestedloops3-baseline-v1':
        raise SystemExit('dependency reference schema mismatch')
    if dependency.get('classpath') is None or not dependency.get('harness_jar'):
        raise SystemExit('dependency reference lacks accepted compile inputs')
    dep_dirs = dependency.get('directory_pins', dependency.get('directory_pins_before'))
    if not dep_dirs: raise SystemExit('dependency reference lacks pinned class directories')
    dep_rows = [dependency['harness_jar'], *dependency.get('jar_pins', [])]
    for row in dep_rows:
        if compare.pin(Path(row['path'])) != row: raise SystemExit(f'dependency artifact changed: {row["path"]}')
    for folder, expected in dep_dirs.items():
        actual = tree_pins(compare, Path(folder))
        if actual != expected: raise SystemExit(f'dependency class directory changed: {folder}')
    target_names = {INTERNAL_CLASS + '.class', OUTER_INTERNAL + '.class'}
    for row in dep_rows:
        if row['path'].endswith('.jar'):
            with zipfile.ZipFile(row['path']) as archive:
                if target_names.intersection(archive.namelist()): raise SystemExit('target class leaked into pinned dependency JAR')
    for folder in dep_dirs:
        if any((Path(folder) / name).is_file() for name in target_names):
            raise SystemExit(f'target class leaked into dependency directory: {folder}')

    out.mkdir(parents=True)
    raw_dir = out / 'raw'; raw_dir.mkdir()
    guard.ROOT = root; guard.OUT = raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, stdout_bytes: None
    if shutil.disk_usage(root).free < 5 * 1024**3: raise SystemExit('5 GiB free-space guard failed')

    source_copy = out / 'source' / SOURCE.name; source_copy.parent.mkdir(parents=True)
    shutil.copy2(SOURCE, source_copy)
    driver_source = Path(__file__).with_name('driver') / 'TestSequentialLoops2Driver.java'
    if sha(driver_source) != DRIVER_SHA256: raise SystemExit('reviewed driver pin mismatch')
    driver_copy = out / 'driver-source' / driver_source.name; driver_copy.parent.mkdir(parents=True)
    shutil.copy2(driver_source, driver_copy)
    runtime_copy = out / RUNTIME_BOUND.name; shutil.copy2(RUNTIME_BOUND, runtime_copy)
    empty = out / 'empty-classpath'; empty.mkdir()
    classpath = dependency['classpath']; classpath_text = os.pathsep.join(classpath)
    source_before = compare.source_closure(root)
    external_before = {
        'source': compare.pin(SOURCE), 'source_copy': compare.pin(source_copy),
        'driver_source': compare.pin(driver_source), 'driver_copy': compare.pin(driver_copy),
        'runtime_wrapper': compare.pin(RUNTIME_BOUND), 'runtime_copy': compare.pin(runtime_copy),
        'dependency_reference': compare.pin(DEPENDENCY_REFERENCE), 'seq1_collector_template': compare.pin(SEQ1_TEMPLATE),
        'cli': compare.pin(CLI), 'jadx': compare.pin(JADX), 'jadx_jar': compare.pin(JADX_JAR),
        'jdk_manifest': compare.pin(root / JDK_MANIFEST_REL), 'compare': compare.pin(compare_path),
        'guard': compare.pin(guard_path), 'scanner': compare.pin(scanner_path), 'physical_parser': compare.pin(PARSER),
        'dependency_artifacts': [compare.pin(Path(x['path'])) for x in dep_rows],
        'dependency_directories': {str(Path(k).resolve()): v for k, v in dep_dirs.items()},
        'jdk_tools': {f'{leg}_{name}': compare.pin(path) for leg, spec in jdks.items() for name, path in spec['tools'].items()},
    }
    def external_snapshot():
        result = {k: compare.pin(Path(v['path'])) for k, v in external_before.items() if k not in ('dependency_artifacts', 'dependency_directories', 'jdk_tools')}
        result['dependency_artifacts'] = [compare.pin(Path(x['path'])) for x in dep_rows]
        result['dependency_directories'] = {str(Path(folder).resolve()): tree_pins(compare, Path(folder)) for folder in dep_dirs}
        result['jdk_tools'] = {f'{leg}_{name}': compare.pin(path) for leg, spec in jdks.items() for name, path in spec['tools'].items()}
        return result

    report = {
        'schema': 'cf11-testsequentialloops2-full-source-baseline-v1', 'status': 'running',
        'root': str(root), 'output': str(out), 'source': compare.pin(SOURCE), 'source_copy': compare.pin(source_copy),
        'cli': compare.pin(CLI), 'cli_sha256_argument': CLI_SHA256,
        'dependency_reference': compare.pin(DEPENDENCY_REFERENCE), 'dependency_reference_sha256_expected': DEPENDENCY_REFERENCE_SHA256,
        'dependency_classpath': classpath, 'dependency_harness_jar': dependency['harness_jar'],
        'dependency_jar_pins': dependency.get('jar_pins', []), 'dependency_directory_pins': dep_dirs,
        'seq1_collector_template': compare.pin(SEQ1_TEMPLATE), 'driver_source': compare.pin(driver_source),
        'driver_copy': compare.pin(driver_copy), 'runtime_wrapper': compare.pin(runtime_copy),
        'jadx': compare.pin(JADX), 'jadx_jar': compare.pin(JADX_JAR), 'jdk_manifest': jdk_record,
        'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path), 'scanner': compare.pin(scanner_path),
        'source_pins_before': source_before, 'external_input_pins_before': external_before,
        'commands': [], 'profiles': [], 'javac8_boundary': None, 'driver_classes': [],
        'original_runtime': [], 'original_oracles': {'default': [], 'configured128': []},
        'runtime_semantic_agreement': {}, 'wrong_root_control': None,
        'jarde_cells': [], 'jadx_cells': [], 'notes': [
            'The complete upstream source is copied byte-for-byte. The outer JUnit methods remain in every javac23 compile and in both Jarde/JADX bundle inputs.',
            'JDK8 full-source compilation is recorded as a real dependency-major boundary observation; it is not replaced by a trimmed source compile.',
            'Default-state and configured128 modes are independent runtime-derived observation sets. Every test case loads a fresh target class through a parentless loader.',
            'Raw exception messages are preserved, but semantic parity across JDKs excludes message text because helpful NPE/AIOOBE wording may vary.',
            'No generated Jarde/JADX source is rebuilt in this baseline phase. No expected return, state, or exception message is hard-coded.',
        ],
    }
    compare.write_json(out / 'execution.json', report)
    rows = report['commands']

    def command(argv, label, leg='javac23'):
        if (root / 'target').exists(): raise RuntimeError('workspace target appeared during baseline collection')
        env = compare.clean_env(dict(os.environ), jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(rows) + 1, [str(x) for x in argv], env)
        row['label'] = label; row['tool_leg'] = leg; rows.append(row)
        compare.write_json(out / 'execution.json', report)
        if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        return row

    def artifact(row, channel='stdout'):
        return compare.command_artifact(row, channel)

    def class_profile(dest: Path, profile: str, compile_row: dict):
        target = dest / 'jadx/tests/integration/loops/TestSequentialLoops2$TestCls.class'
        outer = dest / 'jadx/tests/integration/loops/TestSequentialLoops2.class'
        classfiles = sorted(dest.rglob('*.class'))
        tree = [p.relative_to(dest).as_posix() for p in classfiles]
        expected_tree = ['jadx/tests/integration/loops/TestSequentialLoops2$TestCls.class',
                         'jadx/tests/integration/loops/TestSequentialLoops2.class']
        if tree != expected_tree: raise RuntimeError(f'{profile}: full-source class tree differs: {tree}')
        child_facts, outer_facts = full_class_facts(compare, target, profile + ' child'), full_class_facts(compare, outer, profile + ' outer')
        if child_facts['major'] != 52 or child_facts['class_name'] != INTERNAL_CLASS \
                or class_method_set(child_facts) != EXPECTED_CHILD_METHODS:
            raise RuntimeError(f'{profile}: nested TestCls class/member inventory mismatch')
        if {(n, d, a) for n, d, a in child_facts['fields']} != EXPECTED_CHILD_FIELDS:
            raise RuntimeError(f'{profile}: nested TestCls field inventory/access mismatch')
        if outer_facts['major'] != 52 or outer_facts['class_name'] != OUTER_INTERNAL \
                or class_method_set(outer_facts) != EXPECTED_OUTER_METHODS or outer_facts['fields']:
            raise RuntimeError(f'{profile}: full outer class inventory mismatch')
        row = {'profile': profile, 'compile_command': compile_row['index'], 'compile_exit_code': compile_row['exit_code'],
               'class_root': str(dest), 'class_tree': {p.relative_to(dest).as_posix(): compare.pin(p) for p in classfiles},
               'target': child_facts, 'outer': outer_facts,
               'target_access': child_facts['access'], 'outer_access': outer_facts['access']}
        return row

    def make_bundle(class_root: Path, profile: str) -> Path:
        dest = out / f'{profile}.jar'
        with zipfile.ZipFile(dest, 'w') as archive:
            for path in sorted(class_root.rglob('*.class')):
                entry = zipfile.ZipInfo(path.relative_to(class_root).as_posix(), (1980, 1, 1, 0, 0, 0))
                entry.compress_type = zipfile.ZIP_STORED
                archive.writestr(entry, path.read_bytes())
        return dest

    try:
        # Preserve the real JDK8/full-harness boundary separately; never trim outer methods.
        boundary_dir = out / 'javac8-boundary/classes'; boundary_dir.mkdir(parents=True)
        boundary = command([jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
                            '-encoding', 'UTF-8', '-proc:none', '-classpath', classpath_text,
                            '-sourcepath', empty, '-d', boundary_dir, source_copy],
                           'original-javac8-full-source-boundary', 'javac8')
        boundary_stderr, boundary_stdout = artifact(boundary, 'stderr'), artifact(boundary, 'stdout')
        report['javac8_boundary'] = {'command': boundary['index'], 'exit_code': boundary['exit_code'],
            'class_files': [compare.pin(p) for p in sorted(boundary_dir.rglob('*.class'))],
            'major_55_diagnostic_observed': b'55.0' in boundary_stderr or b'version 55' in boundary_stderr,
            'stdout': compare.pin(Path(boundary['streams']['stdout']['path'])),
            'stderr': compare.pin(Path(boundary['streams']['stderr']['path']))}

        for profile, debug in (('debug', '-g'), ('no-debug', '-g:none')):
            dest = out / profile / 'classes'; dest.mkdir(parents=True)
            compiled = command([jdks['javac23']['tools']['javac'], '--release', '8', debug,
                                '-encoding', 'UTF-8', '-proc:none', '-classpath', classpath_text,
                                '-sourcepath', empty, '-d', dest, source_copy], 'original-compile-' + profile)
            if compiled['exit_code'] != 0: raise RuntimeError(f'{profile}: full unchanged source compile failed; raw output retained')
            row = class_profile(dest, profile, compiled); report['profiles'].append(row)
            row['bundle'] = compare.pin(make_bundle(dest, profile))
            compare.write_json(out / 'execution.json', report)

        driver_classes = out / 'driver-classes'; driver_classes.mkdir()
        driver_compile = command([jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
                                  '-encoding', 'UTF-8', '-proc:none', '-classpath', empty,
                                  '-sourcepath', empty, '-d', driver_classes, driver_copy],
                                 'compile-independent-reflection-driver', 'javac8')
        if driver_compile['exit_code'] != 0: raise RuntimeError('oracle driver compilation failed')
        driver_class_files = sorted(driver_classes.rglob('*.class'))
        if len(driver_class_files) != 1: raise RuntimeError('driver output is not one standalone class')
        report['driver_classes'] = [compare.pin(p) for p in driver_class_files]

        # Runtime execution keeps each raw oracle profile/VM/mode separate. Only message-free semantic projections are compared.
        semantic_rows = {mode: [] for mode in MODES}
        for profile in report['profiles']:
            target_root = Path(profile['class_root']).resolve()
            for runtime in RUNTIMES:
                for mode in MODES:
                    row = command([sys.executable, '-B', runtime_copy, '30', jdks[runtime]['tools']['java'],
                                   '-Xverify:all', '-cp', driver_classes, 'TestSequentialLoops2Driver',
                                   mode, target_root, target_root],
                                  f'original-runtime-{profile["profile"]}-{runtime}-{mode}', runtime)
                    stdout, stderr = artifact(row), artifact(row, 'stderr')
                    parsed_rows = parse_driver_rows(stdout, mode) if row['exit_code'] == 0 else []
                    cell = {'profile': profile['profile'], 'runtime': runtime, 'mode': mode,
                            'command': row['index'], 'exit_code': row['exit_code'],
                            'target_root': str(target_root), 'application_classpath': [str(driver_classes)],
                            'stdout': compare.pin(Path(row['streams']['stdout']['path'])),
                            'stderr': compare.pin(Path(row['streams']['stderr']['path'])),
                            'row_count': len(parsed_rows), 'rows': parsed_rows}
                    report['original_runtime'].append(cell)
                    if row['exit_code'] == 0 and len(parsed_rows) == 8:
                        oracle_path = out / f'original-oracle-{mode}-{profile["profile"]}-{runtime}.stdout'
                        oracle_path.write_bytes(stdout)
                        oracle = {'profile': profile['profile'], 'runtime': runtime, 'mode': mode,
                                  'path': compare.pin(oracle_path), 'rows': parsed_rows}
                        report['original_oracles'][mode].append(oracle)
                        semantic_rows[mode].append(semantic_projection(parsed_rows))
                    compare.write_json(out / 'execution.json', report)
        for mode in MODES:
            projections = semantic_rows[mode]
            report['runtime_semantic_agreement'][mode] = len(projections) == 4 and all(x == projections[0] for x in projections)
        report['original_runtime_agreement'] = all(report['runtime_semantic_agreement'].values())
        compare.write_json(out / 'execution.json', report)

        # Negative control supplies a real target root but a deliberately wrong expected CodeSource root.
        wrong_profile = report['profiles'][0]
        wrong = command([sys.executable, '-B', runtime_copy, '30', jdks['javac23']['tools']['java'],
                         '-Xverify:all', '-cp', driver_classes, 'TestSequentialLoops2Driver',
                         'default', Path(wrong_profile['class_root']).resolve(), empty],
                        'driver-code-source-wrong-root-control', 'javac23')
        wrong_stderr = artifact(wrong, 'stderr')
        report['wrong_root_control'] = {'command': wrong['index'], 'exit_code': wrong['exit_code'],
            'rejected_expected_root': wrong['exit_code'] != 0 and b'wrong CodeSource:' in wrong_stderr,
            'actual_target_root': wrong_profile['class_root'], 'expected_wrong_root': str(empty)}
        if not report['wrong_root_control']['rejected_expected_root']:
            raise RuntimeError('parentless loader CodeSource negative control did not reject wrong root')

        version = command([JADX, '--version'], 'jadx-version')
        version_text = (artifact(version) + artifact(version, 'stderr')).decode('utf-8', errors='replace')
        if version['exit_code'] != 0 or '1.5.6' not in version_text: raise RuntimeError('JADX version is not pinned 1.5.6')
        for profile in report['profiles']:
            class_root = Path(profile['class_root'])
            bundle = Path(profile['bundle']['path'])
            target = class_root / (INTERNAL_CLASS + '.class')
            for form, input_path, policy in (('child', target, 'single-class'),
                                               ('bundle-child', bundle, 'plain-jar')):
                for evidence in EVIDENCE:
                    argv = [CLI, 'class-source', '--input', input_path, '--class', INTERNAL_CLASS,
                            '--policy', policy, '--release', '8', '--format', 'json']
                    if evidence == 'all': argv += ['--evidence', 'all']
                    row = command(argv, f'jarde-{profile["profile"]}-{form}-{evidence}')
                    raw_json = artifact(row)
                    dest = out / 'jarde' / profile['profile'] / form / evidence; dest.mkdir(parents=True)
                    report_path = dest / 'report.json'; report_path.write_bytes(raw_json)
                    cell = {'profile': profile['profile'], 'input_form': form, 'evidence': evidence,
                            'command': row['index'], 'input': compare.pin(input_path), 'exit_code': row['exit_code'],
                            'report': compare.pin(report_path)}
                    try:
                        api = json.loads(raw_json.decode('utf-8', errors='strict'))
                        whole = dest / 'whole-source.java'; whole.write_bytes(api.get('text', '').encode('utf-8'))
                        methods = []
                        for method in api.get('methods', []):
                            identity = method.get('item', {}).get('identity', {})
                            ident = (bytes(identity.get('name', [])).decode('utf-8'),
                                     bytes(identity.get('descriptor', [])).decode('utf-8'))
                            outcome = method.get('outcome', {}); rep = outcome.get('report', {})
                            methods.append({'identity': list(ident), 'outcome_kind': outcome.get('kind'),
                                            'quality': rep.get('quality'), 'fallbacks': rep.get('fallbacks'),
                                            'regions': rep.get('regions'), 'source_map': rep.get('source_map')})
                        cell.update({'whole_source': compare.pin(whole), 'methods': methods,
                                     'method_inventory_matches': {tuple(m['identity']) for m in methods} == EXPECTED_CHILD_METHODS})
                    except (ValueError, TypeError, UnicodeDecodeError) as exc:
                        cell['json_parse_error'] = str(exc)
                    report['jarde_cells'].append(cell); compare.write_json(out / 'execution.json', report)
            dest = out / 'jadx' / profile['profile']
            row = command([JADX, '--config', 'none', '--threads-count', '1', '--no-res', '--rename-flags', 'none',
                           '-d', dest, bundle], 'jadx-full-bundle-' + profile['profile'])
            sources = [compare.pin(p) for p in sorted(dest.rglob('*.java'))] if dest.exists() else []
            report['jadx_cells'].append({'profile': profile['profile'], 'input': compare.pin(bundle),
                                         'command': row['index'], 'exit_code': row['exit_code'], 'sources': sources})
            compare.write_json(out / 'execution.json', report)

        report['external_input_pins_after'] = external_snapshot()
        if report['external_input_pins_after'] != external_before: raise RuntimeError('external inputs changed during capture')
        report['source_pins_after'] = compare.source_closure(root)
        report['source_unchanged'] = report['source_pins_after'] == source_before
        report['target_absent'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
        if not report['source_unchanged'] or not report['target_absent']: raise RuntimeError('source changed or target appeared')
        report['counts_derived_from_commands'] = {
            'commands': len(rows), 'raw_streams': 2 * len(rows),
            'original_full_source_compiles': sum(r['label'].startswith('original-compile-') for r in rows),
            'javac8_boundary_compiles': sum(r['label'] == 'original-javac8-full-source-boundary' for r in rows),
            'driver_compiles': sum(r['label'] == 'compile-independent-reflection-driver' for r in rows),
            'original_runtime_runs': sum(r['label'].startswith('original-runtime-') for r in rows),
            'jarde_calls': sum(r['label'].startswith('jarde-') for r in rows),
            'jadx_calls': sum(r['label'].startswith('jadx-') for r in rows),
        }
        report['status'] = 'captured-pending-independent-review'
    except BaseException as error:
        report['status'] = 'failed'; report['error'] = str(error)
        raise
    finally:
        try:
            report['external_input_pins_after_finally'] = external_snapshot()
            report['source_pins_after_finally'] = compare.source_closure(root)
            report['source_unchanged_finally'] = report['source_pins_after_finally'] == source_before
            report['target_absent_finally'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
            if (report['external_input_pins_after_finally'] != external_before
                    or not report['source_unchanged_finally'] or not report['target_absent_finally']):
                report['status'] = 'failed'; report['final_guard_error'] = 'source/tool pins changed or target exists'
        except BaseException as post_error:
            report['status'] = 'failed'; report['final_guard_error'] = repr(post_error)
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out / 'execution.json', report)
        shutil.copy2(__file__, out / 'collector.py')
        print(json.dumps({'status': report['status'], 'commands': len(rows),
                          'oracle_runs': len(report['original_runtime']), 'error': report.get('error')}))

if __name__ == '__main__':
    raise SystemExit(main())
