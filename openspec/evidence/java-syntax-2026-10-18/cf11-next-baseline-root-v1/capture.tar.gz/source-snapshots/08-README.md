# TestNestedLoops3 原始输入静态准备

本目录只准备输入、driver 和验收计划；没有运行 javac/java/JADX/Jarde/CLI。原始源文件逐字节复制自 `/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestNestedLoops3.java`，副本 1061 bytes，SHA-256 `7152231b3aeb8419a6cfa5ecb9f639809386109233ce66af43143e0451b0ea72`。这份完整源包含外层 JUnit 测试和整个 `TestCls`，没有裁剪或重写原方法。

## 目标与方法覆盖

需要输入的真实目标是嵌套类 `jadx.tests.integration.loops.TestNestedLoops3$TestCls`。它有六个实例方法（含隐式构造器）：`<init>()V`、`test(I)I`、`exc()V`、`f1()V`、`f2()V`、`check()V`。外层类另有隐式构造器与 JUnit `test()V`；driver 不把它们算作目标方法，也不运行依赖 IntegrationTest 的外层方法。

原始 `check()` 固定执行 `test(1)` 并通过 AssertJ 检查 `c == 302`。反射 driver 还在新对象上独立检查 `test(1) == 3 && c == 302`，以及 `test(16) == 3 && c == 101`。前者走到 `exc()` 的正常路径与后续抛出后由 catch 接住的路径，再通过 `i != 0` 跳出外层标号循环；后者通过 `b >= 16` 提前跳出。两次都由同一原始 `test` 方法产生，不改源方法。构造器、`check/test/f1/f2/exc` 均被调用。

## 隔离与依赖

`driver/TestNestedLoops3Driver.java` 只通过反射访问目标，并要求目标 `ProtectionDomain.CodeSource` 的 canonical root 等于参数传入的预期类目录。运行时 classpath 应把该 profile 的完整 classes root 与 driver 放入显式、独立的 classpath；不得将 JADX 编译缓存中同名 target 放在前面。`check()` 调用 AssertJ，因此 runtime classpath 还需原 harness receipt 中的 AssertJ 及其依赖；编译完整原源需要原 harness jar、receipt 所列 JUnit/AssertJ/annotations 依赖和JADX harness 主类目录。

参考收据 `/private/tmp/jarde-tf3-original-inputs-root-v1-20261018/execution.json` **只为 TestFinally3**，其中记录的 harness jar 为 `/private/tmp/jarde-tf3-original-inputs-root-v1-20261018/jadx-test-harness.jar`，SHA-256 `13c2a476a474f9956378cfab9b3204aa9b3e47a5af9028ca9e776d893c610928`。它可为依赖路径和工具pin提供线索，不能证明 `TestNestedLoops3` 已被编译，也不能直接冒充目标class收据；root 必须对本目录原样源新编译并产生自己的 argv/stdout/stderr/class hash 和事实收据。不要从 JADX checkout `build/classes` 复制 `TestNestedLoops3.class`。

该 harness jar 中 `jadx/tests/api/IntegrationTest.class` 的 classfile major 是 55。JDK 8 javac 只能读取到 major 52；所以基于该 harness 编译 classpath 的“原完整 owner 源由 javac8 重编”腿不成立。需要如实记录为工具/依赖限制，不能改成 standalone 源来声称原类重编成功。JDK 23 `-source 1.8 -target 1.8` 的原样整类编译可作为候选，并应检查 nested target class major 52。之后能否在 JDK 8 下只加载并运行嵌套目标（不加载外层 IntegrationTest）尚未运行验证；driver 的 CodeSource 检查会确保它加载的是这轮实际产物。

`source/TestNestedLoops3.java` 是唯一原始输入。若另做不依赖 IntegrationTest 的 standalone 同布局转写，必须单列为 translated supplemental fixture，不能替代原始源/类或承担上游测试状态结论。

## 建议的取证顺序

1. 冻结当前原始源副本和所有classpath依赖的路径、字节数、SHA-256；记录每个JDK可执行文件的版本/哈希与完整 argv。把 javac8 对 major-55 harness 的失败单列为编译器边界，不改依赖classfile。
2. 用 receipt 指定的 JDK 23 输入参数，对完整原始源分别编译 `-g` 与 `-g:none`，保持空 sourcepath、`-proc:none`、UTF-8。保存原始输出/诊断、完整两层 classfiles、SHA-256、class major和 `javap -p -s -c -v` 结果；debug 与 no-debug 不合并。
3. 每个产物 profile 单独编译 driver，并用显式类路径执行。检查 CodeSource root，再运行 `check()` 固定 302 oracle、`test(1)` 与 `test(16)`。记录异常/退出码和 stdout/stderr；不把编译成功当运行成功。
4. 将每个真实的 nested target class 接入后续 Jarde/JADX对照时，保持原字节不改，单独存全类重编源码/结果和方法级结构事实。若额外准备 standalone 转写，另行标识其来源与限制。

`pins.json` 保存原始文件、driver、前序 harness receipt 的引用pin。前序 receipt 的 source 是 TestFinally3（不同输入），并明确标记为依赖参考而非本任务结果。
