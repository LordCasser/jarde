# 下一项排程备忘：CF-11 原始 TestNestedLoops3 完整基线

只读静态审计，2026-10-18。没有运行 Git、Cargo、JDK、JADX、CLI、网络或构建；没有改共享仓库。哈希与本地 JADX 基线 commit 见同目录 `source-pins.json`。

## 建议

首选 **CF-11 的原始 `TestNestedLoops3.TestCls.test(int)` 完整类对照**，下一步先补事实基线，不直接实现。这个选择满足“账本里有真实 JADX Java 测试、属于未关闭的大颗粒单元、固定四样本以外仍留有原始正向样本”三个条件，且避开本轮已推送的 switch-case-nonlocal-exits、finally 探索与 JSR-clone natural-loop 债务。

状态要准确表述：CF-11 账本仍是部分已测；`TestNestedLoops3` 是账本已登记的原始正向测试，但我没有找到此方法的当前原/JADX/Jarde 完整源码重编与运行收据。因而“仍未验收”有证据；“当前 Jarde 对它有语义/恢复失败”没有证据。不要把尚未取证写成具体产品回归，也不要从之前 `/private/tmp/jarde-testnestedloops3-original-prep-20261018` 的源/driver草稿说它已跑过。准备目录的说明明确其 class 原样重编与收据仍待 root 执行。

## 账本与原始测试证据

- 71/612 固定范围和分母见 `openspec/evidence/jadx-feature-inventory-2026-09-27/summary.md` 开头，以及 `README.md` 的 612 个 integration Java 文件说明。summary 的状态表仍把 CF-11 列为“部分已测”，并逐项提到已接受的 TestNestedLoops、TestNestedLoops2、TestNestedLoops4、TestSequentialLoops2 等窄片；这些窄片“不关闭整个 CF-11”。`control-flow.md:22-23` 定义单元边界及现存局限，`:89` 将 `TestNestedLoops3.java`、`TestNestedLoops5.java` 明确归入 CF-11；固定四样本行没有这两份源。
- 原始 JADX 文件 `/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestNestedLoops3.java`（文件 pins 见 JSON）在 `test(int)`（15-38）组合两层 `while(true)`、带标签的外层 break、内层 try/catch，以及 catch 后继续回到循环。`check()`（54-57）调用 `test(1)` 并断言累积副作用字段 `c == 302`；JUnit 的 `test()`（60-65）检查 catch 只呈现一次。这是有执行结果的上游正例，而非只有关键字/编译 smoke 的证据。
- `TestNestedLoops5.TestCls.testFor()`（14-27）是可选后续：嵌套计数 for、内层提前 `return 0`；`check()`断言结果7（29-31），JUnit 本身仅断言源码没有 `continue;`（34-39）。其检查强度低于 TestNestedLoops3，且两者不应在一个实现片中先验捆绑。
- 早前固定 `TestNestedLoops`、`TestNestedLoops2`、`TestNestedLoops4` 和 `TestSequentialLoops2` 已有独立交付。`recover-loop-body-try-catch` 的有限 catch/retry输入也不是本原始方法的验收替身。差别是这项原始测试在嵌套循环体内含具名 catch 和两条跳出外循环的路径；重叠能力需按此次完整源和准确字节码重新确认。

## Jarde 接缝与边界

当前 `crates/jarde-java/src/region.rs:14149-14210` 的 `loop_region` 从 `NormalFlowView::loop_entered_at(header)` 取已证明自然环，对 irreducible 形态明确拒绝，然后依次尝试既有 latch-test-chain、latch-tested、effectful-dual-exit、header-tested 分支。`loop_body_sequence`（`17075-17098`）只在所属 natural-loop block 集内沿序递归 `region_at`，遇 stop、越界或重复 block 即交回 continuation。这些是本样本取证应连接的现有入口，不足以静态判断该原始方法会走哪个拒绝或是否已成功恢复。

建议 root 的最小事实动作：以本地 pinned JADX 源冻结原完整 TestNestedLoops3 的真实 class/profile；对相同字节/身份取原/JADX/Jarde 完整类报告、default/all 物理 BCI/source map 与整类 javac + `-Xverify:all` runtime。Driver 至少逐次检查 `check()` 的 302 oracle，并分别隔离 `test(1)` 的返回值/`c`，以及 `test(16)` 的早退出路径（旧准备稿给出 `3/101` 期望，执行前应由新原始 class 结果再确认）。如 Jarde 拒绝，再从同次 Code/canonical/SSA/normal+exception edges/effects/region首拒定位最早原因，测量只到达相关现有入口的证据；若已恢复，则记录为已有能力并取消实现提案。

别把 `TestNestedLoops3` 的源码拼出字节码事实；也别用独立转写、旧缓存或缺来源的 class 代替完整上游源的重编收据。此项先验证行为与呈现质量，再决定是否需要新 OpenSpec或实现。JSR clone 方面本轮 switch 的 separate debt 是独立路径，不应因为语法都涉及 CFG 就混并。

## 候选排序

1. **CF-11 / TestNestedLoops3（首选，基线取证）**：有明确原始 JUnit + `check()` oracle，且具体文件不在早期固定四输入中。当前没有“已失败”结论；这是最短的可审查排程。
2. **CF-11 / TestNestedLoops5（后续）**：有内层 return 和 check oracle，但实际 JUnit 断言只排除 `continue`，应在 TestNestedLoops3 结果后独立评估。

本备忘不调整 71/612 分母或账本状态，不对局部闭环或 Java 特性作完成宣称。
