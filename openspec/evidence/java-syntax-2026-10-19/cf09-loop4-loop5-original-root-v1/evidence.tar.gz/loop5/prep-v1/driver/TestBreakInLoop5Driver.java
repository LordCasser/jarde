import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.Base64;

/** Parentless finite observations of the complete TestBreakInLoop5$TestCls. */
public final class TestBreakInLoop5Driver {
    private static final String TARGET = "jadx.tests.integration.loops.TestBreakInLoop5$TestCls";
    private static final String[] NAMES = {"decimal-natural-end", "lowercase-invalid-break", "m-unit", "g-unit-break", "empty-parse-failure"};
    private static final String[] INPUTS = {"1.2", "12am", "13m", "1G4", ""};
    private static String codeSource(Class<?> c) throws Exception {
        CodeSource source = c.getProtectionDomain().getCodeSource();
        if (source == null || source.getLocation() == null) throw new IllegalStateException("target has no CodeSource");
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }
    private static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static void requireEmptyCwd(String expected) throws Exception {
        String actual = Paths.get(".").toRealPath().toString();
        if (!actual.equals(expected)) throw new IllegalStateException("unexpected JVM cwd: expected=" + expected + " actual=" + actual);
        String[] entries = new java.io.File(".").list();
        if (entries == null || entries.length != 0) throw new IllegalStateException("JVM cwd is not empty");
    }
    private static String invoke(Method method, Object receiver, String input, PrintStream[] capturedOut) throws Exception {
        PrintStream previous = System.out; ByteArrayOutputStream captured = new ByteArrayOutputStream();
        PrintStream targetOut = new PrintStream(captured, true, "UTF-8"); Throwable cause = null; String result = "<not-returned>";
        try { System.setOut(targetOut); try { result = "return=" + String.valueOf(method.invoke(receiver, input)); }
              catch (InvocationTargetException e) { cause = e.getCause(); } }
        finally { targetOut.flush(); System.setOut(previous); targetOut.close(); }
        capturedOut[0] = new PrintStream(new ByteArrayOutputStream());
        return result + "\nexception=" + (cause == null ? "none" : cause.getClass().getName()) + "\nstdout=" + new String(captured.toByteArray(), StandardCharsets.UTF_8);
    }
    private static URL[] urls(String actual) throws Exception {
        String dependencyPath = System.getProperty("test.dependencies", "");
        String[] entries = dependencyPath.isEmpty() ? new String[0] : dependencyPath.split(java.util.regex.Pattern.quote(java.io.File.pathSeparator));
        URL[] urls = new URL[entries.length + 1]; urls[0] = Paths.get(actual).toUri().toURL();
        for (int i = 0; i < entries.length; i++) urls[i + 1] = Paths.get(entries[i]).toUri().toURL();
        return urls;
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 3) throw new IllegalArgumentException("usage: TestBreakInLoop5Driver actualRoot expectedRoot emptyWorkingDirectory");
        String actual = Paths.get(args[0]).toRealPath().toString(); String expected = Paths.get(args[1]).toRealPath().toString();
        String cwd = Paths.get(args[2]).toRealPath().toString(); requireEmptyCwd(cwd);
        try (URLClassLoader loader = new URLClassLoader(urls(actual), null)) {
            Class<?> target = Class.forName(TARGET, true, loader);
            if (target.getClassLoader() != loader) throw new IllegalStateException("target did not load from parentless loader");
            String origin = codeSource(target); if (!origin.equals(expected)) throw new IllegalStateException("wrong CodeSource: expected=" + expected + " actual=" + origin);
            Method test = target.getDeclaredMethod("test", String.class); Method check = target.getDeclaredMethod("check");
            Constructor<?> ctor = target.getDeclaredConstructor(); Object receiver = ctor.newInstance();
            String[] rows = new String[NAMES.length];
            for (int i = 0; i < NAMES.length; i++) {
                String input = INPUTS[i]; String outcome = invoke(test, receiver, input, new PrintStream[1]);
                String[] fields = outcome.split("\n", 3);
                rows[i] = "CASE index=" + i + " name=" + NAMES[i] + " input_b64=" + b64(input)
                    + " result_b64=" + b64(fields[0]) + " exception=" + fields[1].substring("exception=".length())
                    + " exception_message_b64=" + b64("") + " exception_stack_b64=" + b64("")
                    + " target_stdout_b64=" + b64(fields[2].substring("stdout=".length())) + " after_b64=" + b64(input);
            }
            PrintStream previous = System.out; ByteArrayOutputStream checkOut = new ByteArrayOutputStream();
            PrintStream capture = new PrintStream(checkOut, true, "UTF-8"); Throwable checkError = null;
            try { System.setOut(capture); try { check.invoke(receiver); } catch (InvocationTargetException e) { checkError = e.getCause(); } }
            finally { capture.flush(); System.setOut(previous); capture.close(); }
            String checkPayload = " check_exception=" + (checkError == null ? "none" : checkError.getClass().getName())
                + " check_stdout_b64=" + b64(new String(checkOut.toByteArray(), StandardCharsets.UTF_8));
            for (int i = 0; i < rows.length; i++) System.out.println(rows[i] + (i == rows.length - 1 ? checkPayload : ""));
            requireEmptyCwd(cwd);
        }
    }
}
