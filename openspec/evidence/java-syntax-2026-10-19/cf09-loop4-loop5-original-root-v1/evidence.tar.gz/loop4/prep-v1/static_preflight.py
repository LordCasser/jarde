#!/usr/bin/env python3
"""Read-only source/script/pin preflight. Does not execute the collector or toolchain."""
from pathlib import Path
import ast, hashlib, json, tarfile, re
BASE=Path(__file__).parent
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
SOURCE=Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestBreakInLoop4.java')
REVISION_ARCHIVE=ROOT/'openspec/evidence/java-syntax-2026-10-19/cf07-fixed-original-loops-root-v1/capture.tar.gz'
CLI=Path('/private/tmp/jarde-loop2-retry-final-focused-root-v2-20261019/candidate-cli')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,msg):
    if not ok: raise SystemExit(msg)
plan=json.loads((BASE/'caseplans.json').read_text())
pins=json.loads((BASE/'pins.json').read_text())
source=SOURCE.read_bytes(); source_text=source.decode('utf-8','strict')
need(sha(SOURCE)==pins['external_inputs']['upstream_source']['sha256'] and len(source)==pins['external_inputs']['upstream_source']['bytes'],'upstream source pin differs')
for copy in (BASE/'source/jadx/tests/integration/loops/TestBreakInLoop4.java',BASE/'source-plan-copy/TestBreakInLoop4.java',BASE/'source-plan-origin/TestBreakInLoop4.java'):
    need(copy.read_bytes()==source,f'complete source copy differs: {copy}')
need(plan['schema']=='test-break-in-loop4-source-plan-v1','plan schema differs')
need(plan['method']['binary_name']=='jadx/tests/integration/loops/TestBreakInLoop4$TestCls' and plan['method']['descriptor']=='(C)D','target method identity differs')
need([x['id'] for x in plan['cases']]==['.','a','b','c'],'case order differs')
need(plan['source']['sha256']==sha(SOURCE) and plan['source']['bytes']==len(source),'plan source pin differs')
for rel,row in pins['local_files'].items():
    path=BASE/rel
    need(path.is_file() and path.stat().st_size==row['bytes'] and sha(path)==row['sha256'] and oct(path.stat().st_mode & 0o777)==row['mode'],f'bundle file pin differs: {rel}')
need('public double test(char c)' in source_text and 'public void check()' in source_text and 'doesNotContain("while")' in source_text and source_text.count('.containsOne("for")')==2,'original complete target/check/JUnit assertions are missing')
need("assertThat(test('.')).isEqualTo(1.0)" in source_text and "assertThat(test('a')).isEqualTo(1024.0)" in source_text and "assertThat(test('b')).isEqualTo(1024.0)" in source_text and "assertThat(test('c')).isEqualTo(1.0)" in source_text,'original check() case inventory differs')
for name in ('collect_baseline.py','audit.py','runtime-bound-cwd.py'):
    ast.parse((BASE/name).read_text(),filename=name)
collector=(BASE/'collect_baseline.py').read_text(); auditor=(BASE/'audit.py').read_text(); driver=(BASE/'driver/TestBreakInLoop4Driver.java').read_text()
need("CASE_NAMES = ('.', 'a', 'b', 'c')" in collector,'collector cases differ')
need("('test', '(C)D', 0x0001)" in collector and "('check', '()V', 0x0001)" in collector,'collector target inventory differs')
need("('test','(C)D',0x0001)" in auditor and "('check','()V',0x0001)" in auditor,'auditor target inventory differs')
need('ClassLoader.getSystemClassLoader()' not in driver and 'new URLClassLoader(urls,null)' in driver,'target/dependency loader must remain isolated')
need("'-cp', driver_classes" in collector and "*dependency['classpath']" in collector,'application cp/dependency URL boundary differs')
need('wrong CodeSource:' in driver and 'CHECK result=' in driver and 'check.invoke(receiver)' in driver,'driver source/check/CodeSource controls missing')
need("lines[-1].startswith('CHECK result=')" in collector and 'check_fields = (\'check_result\', \'check_exception_type\', \'check_stdout\')' in collector and all(k in collector for k in ('\'case_match\'','\'check_match\'','\'combined_match\'')),'strict final CHECK and separated case/check comparison contract missing')
need("'-Xverify:all'" in collector and 'TestBreakInLoop4Driver.class' in collector,'verified runtime/driver-only output checks missing')
need(sha(CLI)==pins['external_inputs']['candidate_cli']['sha256'] and CLI.stat().st_size==pins['external_inputs']['candidate_cli']['bytes'],'root CLI pin differs')
need(re.search(r"COLLECTOR_SHA='([0-9a-f]+)'",auditor).group(1)==sha(BASE/'collect_baseline.py'),'auditor collector pin differs')
need(re.search(r"CASE_PLAN_SHA='([0-9a-f]+)'",auditor).group(1)==sha(BASE/'caseplans.json'),'auditor case-plan pin differs')
need(re.search(r"DRIVER_SHA='([0-9a-f]+)'",auditor).group(1)==sha(BASE/'driver/TestBreakInLoop4Driver.java'),'auditor driver pin differs')
need(re.search(r"CASE_PLAN_SHA256 = '([0-9a-f]+)'",collector).group(1)==sha(BASE/'caseplans.json'),'collector case-plan pin differs')
need(re.search(r"DRIVER_SHA256 = '([0-9a-f]+)'",collector).group(1)==sha(BASE/'driver/TestBreakInLoop4Driver.java'),'collector driver pin differs')
need(sha(REVISION_ARCHIVE)==pins['external_inputs']['jadx_revision_archive']['sha256'],'archived JADX revision evidence pin differs')
with tarfile.open(REVISION_ARCHIVE,'r:gz') as archive:
    raw=archive.extractfile('legacy/java-syntax-2026-09-27/cf07-basic-loops/baseline/jadx-revision.log').read().decode('utf-8','strict')
    need(pins['source_revision']['revision'] in raw,'archived JADX source revision differs')
for rel,expected in pins['external_inputs']['tool_inputs'].items():
    path=Path(rel); need(path.is_file() and sha(path)==expected['sha256'],f'input pin differs: {path}')
print('STATIC_PREFLIGHT_OK: complete source, runtime contracts, scripts and pinned inputs verified; no toolchain executed')
