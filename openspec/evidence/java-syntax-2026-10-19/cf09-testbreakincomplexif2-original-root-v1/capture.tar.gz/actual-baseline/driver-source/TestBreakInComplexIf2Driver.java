import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

/** Parentless finite observations of TestBreakInComplexIf2$TestCls.test(List). */
public final class TestBreakInComplexIf2Driver {
    private static final String TARGET = "jadx.tests.integration.loops.TestBreakInComplexIf2$TestCls";
    private static final String[] NAMES = {
        "source-check-main", "source-check-empty-after-prefix", "source-check-long-after-prefix",
        "empty-list", "null-list", "null-after-normal-increment", "null-after-skip-continue",
        "long-first-break", "literal-a-break-before-null", "empty-first-break",
        "skip-continues-then-literal-a-break"
    };
    private static final String[][] INPUTS = {
        {"x", "y", "skip", "z", "a"}, {"x", "skip", ""}, {"skip", "y", "12345"}, {}, null,
        {"x", null}, {"skip", null}, {"12345", "a"}, {"a", null}, {"", "x"}, {"skip", "a", "z"}
    };
    private static String codeSource(Class<?> c) throws Exception {
        CodeSource source = c.getProtectionDomain().getCodeSource();
        if (source == null || source.getLocation() == null) throw new IllegalStateException("target has no CodeSource");
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }
    private static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static void requireEmptyCwd(String expected) throws Exception {
        String actual = Paths.get(".").toRealPath().toString();
        if (!actual.equals(expected)) throw new IllegalStateException("unexpected JVM cwd: expected=" + expected + " actual=" + actual);
        String[] entries = new java.io.File(".").list();
        if (entries == null || entries.length != 0) throw new IllegalStateException("JVM cwd is not empty");
    }
    private static List<String> freshList(int index) {
        if (INPUTS[index] == null) return null;
        return new ArrayList<String>(Arrays.asList(INPUTS[index]));
    }
    private static String snapshot(List<String> list) {
        if (list == null) return "null";
        StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i != 0) b.append(',');
            String value = list.get(i);
            if (value == null) b.append("null");
            else b.append('"').append(value.replace("\\", "\\\\").replace("\"", "\\\"")).append('"');
        }
        return b.append(']').toString();
    }
    private static void observe(Method method, Constructor<?> ctor, int index, String cwd, PrintStream resultOut) throws Exception {
        requireEmptyCwd(cwd);
        Object receiver = ctor.newInstance();
        List<String> list = freshList(index);
        String input = snapshot(list);
        PrintStream previous = System.out;
        ByteArrayOutputStream captured = new ByteArrayOutputStream();
        PrintStream targetOut = new PrintStream(captured, true, "UTF-8");
        Throwable cause = null; String result = "<not-returned>";
        try {
            System.setOut(targetOut);
            try { result = "return=" + String.valueOf(method.invoke(receiver, list)); }
            catch (InvocationTargetException e) { cause = e.getCause(); }
        } finally { targetOut.flush(); System.setOut(previous); targetOut.close(); }
        String after = snapshot(list);
        requireEmptyCwd(cwd);
        String exception = cause == null ? "none" : cause.getClass().getName();
        String output = new String(captured.toByteArray(), StandardCharsets.UTF_8);
        resultOut.println("CASE index=" + index + " name=" + NAMES[index] + " input_b64=" + b64(input)
            + " result_b64=" + b64(result) + " exception=" + exception + " exception_message_b64=" + b64("")
            + " exception_stack_b64=" + b64("") + " target_stdout_b64=" + b64(output)
            + " after_b64=" + b64(after));
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 3) throw new IllegalArgumentException("usage: TestBreakInComplexIf2Driver actualRoot expectedRoot emptyWorkingDirectory");
        String actual = Paths.get(args[0]).toRealPath().toString();
        String expected = Paths.get(args[1]).toRealPath().toString();
        String cwd = Paths.get(args[2]).toRealPath().toString();
        requireEmptyCwd(cwd);
        try (URLClassLoader loader = new URLClassLoader(new URL[]{Paths.get(actual).toUri().toURL()}, null)) {
            Class<?> target = Class.forName(TARGET, true, loader);
            if (target.getClassLoader() != loader) throw new IllegalStateException("target did not load from parentless loader");
            String origin = codeSource(target);
            if (!origin.equals(expected)) throw new IllegalStateException("wrong CodeSource: expected=" + expected + " actual=" + origin);
            Method test = target.getDeclaredMethod("test", List.class); test.setAccessible(true);
            Constructor<?> ctor = target.getDeclaredConstructor(); ctor.setAccessible(true);
            PrintStream resultOut = System.out;
            for (int i = 0; i < NAMES.length; i++) observe(test, ctor, i, cwd, resultOut);
            requireEmptyCwd(cwd);
        }
    }
}
