package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInComplexIf2.class */
public class TestBreakInComplexIf2 extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInComplexIf2$TestCls.class */
    public static class TestCls {
        private int test(List<String> list) {
            int i = 0;
            for (String str : list) {
                if (str.isEmpty() || str.length() > 4) {
                    break;
                }
                if (!str.equals("skip")) {
                    if (str.equals("a")) {
                        break;
                    }
                    i++;
                }
            }
            return i;
        }

        public void check() {
            JadxAssertions.assertThat(test(Arrays.asList("x", "y", "skip", "z", "a"))).isEqualTo(3);
            JadxAssertions.assertThat(test(Arrays.asList("x", "skip", ""))).isEqualTo(1);
            JadxAssertions.assertThat(test(Arrays.asList("skip", "y", "12345"))).isEqualTo(1);
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().countString(2, "break;");
    }

    @Test
    public void testNoDebug() {
        noDebugInfo();
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().countString(2, "break;");
    }
}
