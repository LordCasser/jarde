# TestBreakInComplexIf2 full-source baseline preparation

This is a private, unexecuted collector/auditor bundle. It does not establish a Jarde result or a recovery defect. It preserves the complete 1,125-byte upstream `TestBreakInComplexIf2.java`, including the outer JUnit methods and `TestCls.check()`. The target is `jadx.tests.integration.loops.TestBreakInComplexIf2$TestCls`; its source-level target methods are constructor, private `test(List<String>): int`, and public `check()`, with no explicitly declared target fields or helper class. The capture insists on the exact outer+target original class tree and audits actual compiler output rather than assuming generated output quality.

The standalone reflection driver does not invoke outer JUnit methods or `check()`. It loads the selected target from a fresh parentless class loader, verifies its `CodeSource`, invokes only `test(List)`, captures list snapshots before and after, and records result or exception class plus target stdout. It deliberately omits exception messages and stacks from semantic comparison because those vary between JDKs. Its 11 fixed case names/order match the independently reviewed `caseplans.json`; path counts in that plan are source-math notes, not runtime counters. The wrong-root control uses the same actual class root with a distinct empty expected root.

The collector records the Java 8 compiler boundary attempt and complete Java 23 `--release 8` debug/no-debug builds of the upstream file, then runs the 11-case driver under both configured runtimes for each successful original profile. It captures eight Jarde API cells (debug/no-debug × child/plain-JAR × default/all), both complete JADX decodes from the complete original class bundles, and full-source rebuild attempts for the captured Jarde/JADX outputs with both configured compilers. Compilation/runtime failures remain raw observations; only eligible successful builds get isolated driver/CodeSource checks. No expected recovery quality or compilation outcome is baked in.

## Exact invocation (future, after root reviews this bundle)

Use a fresh output directory that does not exist. Supply the actual candidate CLI and its independently verified SHA256 explicitly:

```sh
python3 -B /private/tmp/jarde-testbreakincomplexif2-baseline-prep-luna-v2-20261019/collect_baseline.py \
  --out /private/tmp/jarde-testbreakincomplexif2-baseline-root-v1-20261019 \
  --cli /absolute/path/to/candidate-cli --cli-sha256 <64-lowercase-hex>
```

After collection, run the independent read-only auditor to a separate fresh output directory:

```sh
python3 -B /private/tmp/jarde-testbreakincomplexif2-baseline-prep-luna-v2-20261019/audit.py \
  --receipt /private/tmp/jarde-testbreakincomplexif2-baseline-root-v1-20261019/execution.json \
  --cli /absolute/path/to/candidate-cli --cli-sha256 <same-verified-64-lowercase-hex> \
  --out /private/tmp/jarde-testbreakincomplexif2-baseline-review-luna-v1-20261019
```

The inherited guard retains source/external pins, raw stdout/stderr, empty runtime cwd, driver-only application classpath, parentless loading, timeout and target-absence checks. The collector checks the existing 5 GiB free-space and 1 GiB target-size guard. This preparation itself ran only Python static parsing/math checks; no collector, Java compiler/runtime, JADX, Jarde CLI, Cargo, Git, or network command was run.

## Bundle identity

`source-plan-origin/` is the exact originally reviewed mathematical-plan bundle. `caseplans.json` is the collector copy whose only source-plan path adjustment points to the byte-identical local source copy. `pins.json` contains local input/source/plan/driver/collector/auditor hashes and the pinned external helper/tool paths. Collector and auditor are separate files. Output is intentionally not claimed complete or accepted; root must review the adapted code and then run/independently audit any requested capture.

## Exact local pins

See `pins.json` for byte counts and SHA-256 pins of the copied source, case plan, standalone driver, collector, auditor, source-plan records, and external dependencies/tooling. `adaptation.diff` records the template-to-family adaptations, and `caseplan-path-adjustment.diff` records the collector plan’s local-copy path update; the driver is a list-only observer and no Point/Map code is carried forward.
