# TestBreakInComplexIf2 finite source plan

This is a source-only finite-input plan. It does not compile or run Java, inspect a product output, or establish a recovery defect. The full upstream file is copied byte-for-byte at `source/jadx/tests/integration/loops/TestBreakInComplexIf2.java` (1,125 bytes; SHA-256 `c51ba62db7e9d9d7df86bbe04fe38f37357fe62e1dc7514edc54701af94ecc92`; source mode `0o644`). Its outer JUnit class and `TestCls.check()` remain intact. The case plan preserves the three original `check()` lists but does not invoke that method or the outer JUnit tests.

The target is `TestBreakInComplexIf2$TestCls.test(List<String>): int`, private in source. `TestCls` has no explicitly declared fields or nested helpers in the source. A future reflection driver should set the method accessible, use a fresh target instance per case, and report return value or exception type plus list snapshots before/after. The method has no source-level print.

The 11 cases cover the three existing assertion lists; empty list; null list; null element after a normal increment; null after the `skip` continue; an immediate `length() > 4` break; an `a` break before a later null; an immediate empty-string break; and `skip` continuing to a later `a` break. For each input, `caseplans.json` gives the statically derived operation-attempt counts and expected result/error. These counts are mathematical predictions from the source, not observed call counts. `String` is final, so the plan does not propose subclass instrumentation.

For a non-null item, evaluation order is `isEmpty`, then (only if nonempty) `length`, then the `> 4` guard, then `equals("skip")`; the `skip` branch continues before `equals("a")`; the literal-`a` branch breaks before increment. Thus a null element fails at `isEmpty()` when reached, while a null after an earlier break is not reached. The null-list failure occurs during enhanced-for iterator acquisition. NullPointerException message/stack are intentionally not frozen.

`manifest.json` pins the copied source and case plan. This directory contains no collector, compiler output, class files, or toolchain results.
