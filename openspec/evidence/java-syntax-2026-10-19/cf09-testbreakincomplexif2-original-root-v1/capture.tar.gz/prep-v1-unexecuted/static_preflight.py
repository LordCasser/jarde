#!/usr/bin/env python3
"""Python-only static checks for the unexecuted ComplexIf2 baseline bundle."""
from pathlib import Path
import ast, hashlib, json, re
BASE=Path(__file__).parent

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads((BASE/'caseplans.json').read_text(encoding='utf-8'))
assert plan['schema']=='test-break-in-complex-if2-source-math-v1'
assert plan['method']['binary_name']=='jadx/tests/integration/loops/TestBreakInComplexIf2$TestCls'
assert plan['method']['descriptor']=='(Ljava/util/List;)I'
assert plan['source_inventory']['explicit_target_fields']==[] and plan['source_inventory']['nested_helpers']==[]
cases=plan['cases']; names=[x['id'] for x in cases]
origin=BASE/'source-plan-origin'; manifest=json.loads((origin/'manifest.json').read_text(encoding='utf-8'))
for rel,row in manifest['files'].items():
    q=origin/rel; assert q.is_file() and q.stat().st_size==row['bytes'] and sha(q)==row['sha256'], str(q)
assert len(names)==11 and len(names)==len(set(names))
source=Path(plan['source']['path']); copy=Path(plan['source']['copy'])
assert source.read_bytes()==copy.read_bytes() and len(source.read_bytes())==1125
assert sha(source)==plan['source']['sha256']
driver=(BASE/'driver/TestBreakInComplexIf2Driver.java').read_text(encoding='utf-8')
body=re.search(r'private static final String\[\] NAMES = \{(.*?)\};',driver,re.S).group(1)
driver_names=re.findall(r'"([^"]+)"',body)
assert driver_names==names, (driver_names,names)
for rel in ('collect_baseline.py','audit.py'):
    ast.parse((BASE/rel).read_text(encoding='utf-8'))
collector=(BASE/'collect_baseline.py').read_text(encoding='utf-8')
auditor=(BASE/'audit.py').read_text(encoding='utf-8')
for text in (collector,auditor):
    assert 'TestBreakInComplexIf2$TestCls' in text and '(Ljava/util/List;)I' in text
    assert 'TestBreakInComplexIf$TestCls' not in text
    assert 'POINT_INTERNAL' not in text and 'POINT=' not in text
assert 'case_plan.get(\'cases\', [])' in collector
assert "plan['cases']" in auditor
assert 'exception_type' in collector and 'list_snapshot' in collector
assert 'semantic_rows' in auditor and "'exception_type'" in auditor
pins=json.loads((BASE/'pins.json').read_text())
for row in pins['local'].values():
    p=BASE/row['path'] if not Path(row['path']).is_absolute() else Path(row['path'])
    assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'], str(p)
for row in pins['external'].values():
    p=Path(row['path'])
    assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'], str(p)
print(json.dumps({'status':'python-static-preflight-only','cases':len(names),'case_order_matches_driver':True,
                  'source_copy_exact':True,'collector_and_auditor_ast':'ok','stale_Point_or_Map_target_contract':False},indent=2))
