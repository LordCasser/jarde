// jarde: presentation of `jadx/tests/integration/loops/TestBreakInLoop$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestBreakInLoop$TestCls extends java.lang.Object {
    public int f;

    public TestBreakInLoop$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestBreakInLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public void test(int[] arg1, int arg2) {
        // @method test([II)V
        // @declaration an instance method of `jadx.tests.integration.loops.TestBreakInLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int local3;
        for (local3 = 0; local3 < arg1.length; local3 = local3 + 1) {
            arg1[local3] += 1;
            if (local3 < arg2) {
                break;
            }
        }
        this.f++;
        return;
    }
}
