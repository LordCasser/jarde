package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop.class */
public class TestBreakInLoop extends IntegrationTest {

    /* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop$TestCls.class */
    public static class TestCls {
        public int f;

        public void test(int[] a, int b) {
            for (int i = 0; i < a.length; i++) {
                int i2 = i;
                a[i2] = a[i2] + 1;
                if (i < b) {
                    break;
                }
            }
            this.f++;
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("for (int i = 0; i < a.length; i++) {").containsOne("if (i < b) {").containsOne("break;").containsOne("this.f++;").countString(0, "else");
    }
}
