package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop.class */
public class TestBreakInLoop extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop$TestCls.class */
    public static class TestCls {
        public int f;

        public void test(int[] iArr, int i) {
            for (int i2 = 0; i2 < iArr.length; i2++) {
                int i3 = i2;
                iArr[i3] = iArr[i3] + 1;
                if (i2 < i) {
                    break;
                }
            }
            this.f++;
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("for (int i = 0; i < a.length; i++) {").containsOne("if (i < b) {").containsOne("break;").containsOne("this.f++;").countString(0, "else");
    }
}
