#!/usr/bin/env python3
"""Create and independently reopen a pinned TestBreakInLoop evidence archive."""
from __future__ import annotations
import argparse, gzip, hashlib, io, json, os, stat, tarfile
from pathlib import Path, PurePosixPath

TMP = Path('/private/tmp').resolve()
HERE = Path(__file__).resolve().parent
MAX_BYTES = 512 * 1024 * 1024
BASELINE_ROOT = TMP / 'jarde-testbreakinloop-baseline-root-v1-20261019'
AUDIT_ROOT = TMP / 'jarde-testbreakinloop-baseline-review-root-v1-20261019'
EXPECTED_RECEIPT_SHA256 = 'c5f14ddda2155b5909e7e090e3247c8bf184ae0a4a3c60eb6b712f5d07d8149a'
EXPECTED_ROOT_REVIEW_SHA256 = '6fc5e8b35aa5a2f427bfa82ad786dd326b141c60829d4089b263a5262c0fd864'
EXPECTED_AUDIT_SHA256 = 'a7e114479d677bd210b0a7287ef1ebace89bb3110e19340843f1294f6449fc7a'
EXPECTED_ACCEPTANCE_STATUS = 'root_accepted_full_original_break_in_loop_no_new_mechanism'
EXPECTED_CLI_SHA256 = '6c83ec82cd4c6caee86c08e7fefddc2fea675952f936c0e4aa3f295ed9be7fc6'
STATIC_ROOTS = (
    ('baseline-prep', TMP / 'jarde-testbreakinloop-baseline-prep-luna-v1-20261019'),
    ('caseplan', TMP / 'jarde-cf09-breakindoloop-caseplans-luna-v1-20261019'),
    ('baseline-prep-review', TMP / 'jarde-testbreakinloop-baseline-prep-review-root-v1-20261019'),
    ('caseplan-review', TMP / 'jarde-cf09-breakindoloop-caseplans-review-root-v1-20261019'),
)
LICENSES = (
    ('JADX-LICENSE', Path('/Users/lordcasser/workspace/projects/jarde/tests/fixtures/cf08-if-loop-entry/licenses/JADX-LICENSE')),
    ('JADX-NOTICE', Path('/Users/lordcasser/workspace/projects/jarde/tests/fixtures/cf08-if-loop-entry/licenses/JADX-NOTICE')),
)

def fail(message: str):
    raise SystemExit('archive refused: ' + message)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def no_symlink(path: Path) -> Path:
    p = path.absolute()
    for part in (p, *p.parents):
        if part.is_symlink(): fail(f'symlink path component: {part}')
    return p

def read_file(path: Path):
    p = no_symlink(path)
    if not p.is_file(): fail(f'missing/non-regular file: {p}')
    before = p.stat(); data = p.read_bytes(); after = p.stat()
    mode = stat.S_IMODE(after.st_mode)
    if (before.st_size, before.st_mtime_ns, before.st_mode) != (after.st_size, after.st_mtime_ns, after.st_mode) or len(data) != after.st_size:
        fail(f'file changed while reading: {p}')
    return data, mode

def tree_entries(entries, seen, label: str, root: Path):
    root = no_symlink(root)
    if not root.is_dir(): fail(f'required evidence root missing: {root}')
    def add(name, source, data, mode, is_dir=False):
        rel = PurePosixPath(name)
        if rel.is_absolute() or '..' in rel.parts or not rel.parts: fail(f'unsafe archive path: {name}')
        key = rel.as_posix()
        if key in entries or key == 'ARCHIVE_INVENTORY.json': fail(f'duplicate/reserved archive path: {key}')
        src = str(source.absolute())
        if src in seen: fail(f'duplicate source path: {src}')
        seen.add(src); entries[key] = (source, data, mode, is_dir)
    add(label + '/', root, b'', stat.S_IMODE(root.stat().st_mode), True)
    for p in sorted(root.rglob('*'), key=lambda path: path.as_posix()):
        if p.is_symlink(): fail(f'symlink in evidence tree: {p}')
        rel = p.relative_to(root); arc = f'{label}/{rel.as_posix()}'
        if p.is_dir(): add(arc + '/', p, b'', stat.S_IMODE(p.stat().st_mode), True)
        elif p.is_file():
            data, mode = read_file(p); add(arc, p, data, mode)
        else: fail(f'non-regular evidence entry: {p}')

def collect():
    baseline = no_symlink(BASELINE_ROOT.resolve(strict=True))
    receipt_path = no_symlink(baseline / 'execution.json')
    receipt_bytes, _ = read_file(receipt_path)
    if sha(receipt_bytes) != EXPECTED_RECEIPT_SHA256: fail('baseline receipt SHA differs from accepted root pin')
    try: receipt = json.loads(receipt_bytes)
    except Exception as exc: fail(f'baseline receipt JSON invalid: {exc}')
    if receipt.get('schema') != 'test-break-in-loop-full-source-baseline-v1': fail('baseline receipt schema differs')
    if receipt.get('status') != 'captured-pending-independent-review': fail('baseline receipt status differs from separate root acceptance marker')
    if Path(receipt.get('output', '')).resolve() != baseline: fail('receipt output path does not name the pinned baseline root')
    if receipt.get('cli', {}).get('sha256') != EXPECTED_CLI_SHA256: fail('candidate CLI pin differs from root marker')

    review_path = no_symlink(baseline / 'root-review.json')
    review_bytes, _ = read_file(review_path)
    if sha(review_bytes) != EXPECTED_ROOT_REVIEW_SHA256: fail('root marker SHA differs from accepted pin')
    try: review = json.loads(review_bytes)
    except Exception as exc: fail(f'root marker JSON invalid: {exc}')
    if review.get('status') != EXPECTED_ACCEPTANCE_STATUS: fail('root marker acceptance status differs')
    if review.get('execution_sha256') != EXPECTED_RECEIPT_SHA256: fail('root marker does not bind exact receipt SHA')
    cli_marker = review.get('cli', {})
    cli_receipt = receipt.get('cli', {})
    if cli_marker != {'path': cli_receipt.get('path'), 'bytes': cli_receipt.get('bytes'), 'sha256': EXPECTED_CLI_SHA256}:
        fail('root marker CLI identity differs from the baseline receipt')

    audit_root = no_symlink(AUDIT_ROOT.resolve(strict=True))
    audit_path = audit_root / 'review.json' / 'review.json'
    audit_bytes, _ = read_file(audit_path)
    if sha(audit_bytes) != EXPECTED_AUDIT_SHA256: fail('independent audit SHA differs from accepted pin')
    try: audit = json.loads(audit_bytes)
    except Exception as exc: fail(f'independent audit JSON invalid: {exc}')
    if audit.get('receipt_sha256') != EXPECTED_RECEIPT_SHA256: fail('independent audit does not bind exact baseline receipt')
    if review.get('independent_review') != {'path': str(audit_path), 'sha256': EXPECTED_AUDIT_SHA256}:
        fail('root marker does not bind the independently reviewed audit')

    expected_counts = {
        'actual_commands': len(receipt.get('commands', [])),
        'api_cells': len(receipt.get('jarde_cells', [])),
        'jarde_complete_compiles': sum(row.get('kind') == 'jarde' and row.get('exit_code') == 0 for row in receipt.get('generated_source_compilations', [])),
        'jarde_vm_runs': sum(row.get('kind') == 'jarde' for row in receipt.get('generated_runtime', [])),
        'jadx_complete_compiles': sum(row.get('kind') == 'jadx' and row.get('exit_code') == 0 for row in receipt.get('generated_source_compilations', [])),
        'jadx_vm_runs': sum(row.get('kind') == 'jadx' for row in receipt.get('generated_runtime', [])),
        'original_vm_runs': len(receipt.get('original_runtime', [])),
        'generated_wrong_root_controls': len(receipt.get('generated_wrong_root_controls', [])),
    }
    for key, actual in expected_counts.items():
        if review.get(key) != actual: fail(f'root marker derived count mismatch: {key}')

    accepted = {'receipt_path': str(receipt_path), 'receipt_sha256': sha(receipt_bytes),
                'receipt_status': receipt.get('status'), 'root_marker_path': str(review_path),
                'root_marker_sha256': sha(review_bytes), 'acceptance_status': review.get('status'),
                'independent_review_path': str(audit_path), 'independent_review_sha256': sha(audit_bytes)}
    entries = {}; seen = set()
    for label, root in STATIC_ROOTS: tree_entries(entries, seen, label, root)
    tree_entries(entries, seen, 'baseline', baseline)
    tree_entries(entries, seen, 'baseline-audit', audit_root)
    for name, path in LICENSES:
        data, mode = read_file(path); arc = 'licenses/' + name
        if arc in entries or str(path) in seen: fail('license input duplicated')
        seen.add(str(path)); entries[arc] = (path, data, mode, False)

    static_pins = json.loads((HERE / 'pins.json').read_text(encoding='utf-8'))
    for label, expected_pin in static_pins.get('preparation_tools', {}).items():
        path = HERE / expected_pin['name']; data, _ = read_file(path)
        if len(data) != expected_pin['bytes'] or sha(data) != expected_pin['sha256']:
            fail(f'preparation tool changed: {label}')
    expected = {row['path']: row for row in static_pins['static_members']}
    actual = {}
    for source, data, mode, is_dir in entries.values():
        key = str(source.absolute())
        if key == str(baseline) or key.startswith(str(baseline) + os.sep): continue
        if key == str(audit_root) or key.startswith(str(audit_root) + os.sep): continue
        actual[key] = {'path': key, 'type': 'directory' if is_dir else 'file',
                       'bytes': len(data), 'sha256': sha(data) if not is_dir else None, 'mode': mode}
    if actual != expected: fail('static preparation/caseplan/license inputs differ from frozen path/byte/mode pins')

    # Reopen every receipt payload reference without copying external toolchain binaries into the archive.
    pin_count = 0; unique_paths = set()
    def walk(value):
        nonlocal pin_count
        if isinstance(value, dict):
            if {'path', 'bytes', 'sha256'} <= value.keys():
                path = Path(value['path']).resolve(strict=True); raw, _ = read_file(path)
                if len(raw) != value['bytes'] or sha(raw) != value['sha256']: fail(f'receipt pin changed: {path}')
                pin_count += 1; unique_paths.add(str(path))
            else:
                for child in value.values(): walk(child)
        elif isinstance(value, list):
            for child in value: walk(child)
    walk(receipt)

    # Archive this packer, its explanation, its exact adaptation, and its frozen static-member pins.
    for filename in ('pack.py', 'README.md', 'pins.json', 'adaptation.diff', 'v1-v2.diff', 'v1-review-return.md'):
        path = HERE / filename; data, mode = read_file(path); arc = 'archive-preparation/' + filename
        if arc in entries or str(path) in seen: fail(f'archive preparation member duplicated: {filename}')
        seen.add(str(path)); entries[arc] = (path, data, mode, False)
    size = sum(len(item[1]) for item in entries.values())
    if size > MAX_BYTES: fail(f'payload exceeds {MAX_BYTES} bytes')
    members = []
    for name, (source, data, mode, is_dir) in sorted(entries.items()):
        members.append({'archive_path': name, 'source_path': str(source.absolute()),
                        'entry_type': 'directory' if is_dir else 'file', 'bytes': len(data),
                        'sha256': sha(data) if not is_dir else None, 'mode': mode})
    inventory = {'schema': 'test-break-in-loop-evidence-archive-v1', 'payload_member_count': len(members),
                 'payload_bytes': size, 'members': members, 'accepted_baseline': accepted,
                 'root_marker_counts': expected_counts, 'receipt_pin_records_reopened': pin_count,
                 'unique_receipt_pin_paths': len(unique_paths),
                 'notes': ['Complete prep, case-plan, baseline, baseline audit, raw streams and failed/negative outputs are retained as full trees.',
                           'The accepted root marker binds the exact receipt and independent audit SHA-256.',
                           'External JDK, candidate CLI and dependency artifacts are referenced by receipt pins, not copied.',
                           'Case-plan notes remain source-derived; the archive does not assert new behavior beyond the accepted baseline evidence.']}
    return inventory, entries

def verify(out, inventory, entries, blob):
    with tarfile.open(out, 'r:gz') as tar:
        members = tar.getmembers(); by = {member.name: member for member in members}
        expected = set(entries) | {'ARCHIVE_INVENTORY.json'}
        if len(by) != len(members) or set(by) != expected: fail('tar has duplicate, missing, or unexpected members')
        for name, (source, data, mode, is_dir) in entries.items():
            info = by[name]
            if info.mode != mode or (not info.isdir() if is_dir else not info.isfile()): fail(f'type/mode mismatch: {name}')
            if is_dir: continue
            actual = tar.extractfile(info).read()
            if actual != data or sha(actual) != sha(data): fail(f'payload mismatch: {name}')
            now, now_mode = read_file(source)
            if now != data or now_mode != mode: fail(f'source changed after snapshot: {source}')
        if tar.extractfile(by['ARCHIVE_INVENTORY.json']).read() != blob: fail('inventory bytes differ after reopen')

def pack(args):
    out = no_symlink(args.out.absolute()); sidecar = out.with_suffix(out.suffix + '.inventory.json')
    if out.exists() or sidecar.exists(): fail('archive or inventory sidecar already exists')
    if out.is_relative_to(HERE): fail('output cannot be under preparation directory')
    inventory, entries = collect(); out.parent.mkdir(parents=True, exist_ok=True)
    blob = (json.dumps(inventory, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    with out.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as gz:
            with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
                for name, (source, data, mode, is_dir) in sorted(entries.items()):
                    info = tarfile.TarInfo(name); info.mode = mode; info.mtime = 0; info.uid = info.gid = 0; info.uname = info.gname = ''
                    if is_dir: info.type = tarfile.DIRTYPE; info.size = 0; tar.addfile(info)
                    else: info.size = len(data); tar.addfile(info, io.BytesIO(data))
                info = tarfile.TarInfo('ARCHIVE_INVENTORY.json'); info.size = len(blob); info.mode = 0o644
                info.mtime = 0; info.uid = info.gid = 0; info.uname = info.gname = ''; tar.addfile(info, io.BytesIO(blob))
    verify(out, inventory, entries, blob)
    with sidecar.open('xb') as stream: stream.write(blob)
    return {'status': 'prepared-and-reopened', 'archive': str(out), 'archive_sha256': sha(out.read_bytes()),
            'inventory': str(sidecar), 'payload_member_count': len(entries)}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    return pack(args)

if __name__ == '__main__':
    print(json.dumps(main(), indent=2))
