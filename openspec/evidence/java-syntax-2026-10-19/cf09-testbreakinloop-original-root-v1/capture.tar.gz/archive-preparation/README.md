# TestBreakInLoop 证据归档准备 v2

本目录是私有归档器准备，未生成归档。相较冻结的 v1，本版只修正整类编译成功计数（需 `exit_code == 0`）并加入实际存在的 baseline-prep 与 case-plan 静态审查目录。v1 原目录和文件保持原样。

归档计划包含完整 baseline-prep、case-plan、两份静态审查树、已接受 baseline capture 树、独立 baseline audit 树，以及 JADX LICENSE/NOTICE。所有目录树保留原始文件字节、空目录和 mode。capture 中 raw streams、源码/类文件、真实失败编译格和 root marker 原样保存；review 树不替代原始证据。JDK/JADX/Jarde CLI/依赖只通过 receipt pins 复核，不复制外部工具载荷。

绑定的实际证据：execution SHA-256 `c5f14ddda2155b5909e7e090e3247c8bf184ae0a4a3c60eb6b712f5d07d8149a`，root marker SHA-256 `6fc5e8b35aa5a2f427bfa82ad786dd326b141c60829d4089b263a5262c0fd864`，独立 audit `review.json/review.json` SHA-256 `a7e114479d677bd210b0a7287ef1ebace89bb3110e19340843f1294f6449fc7a`。root 状态为 `root_accepted_full_original_break_in_loop_no_new_mechanism`。收据记录 94 命令、8 API cells、Jarde 16 次成功整类编译/32 VM/160 observations、JADX 2 次成功编译/4 VM/20 observations、原始 4 VM/20 observations及18个错根控制。另有两条 JADX JDK 8 框架编译失败，保留为失败证据且不计成功编译或 VM。BCI mapping 26/26。计数由收据实际行和 root marker 核对。

外部候选 CLI SHA-256 `6c83ec82cd4c6caee86c08e7fefddc2fea675952f936c0e4aa3f295ed9be7fc6` 仅供 pin 校验。`pins.json` 固定静态输入的 path、bytes、SHA-256、mode 及工具文件 pins。`adaptation.diff` 对照已接受 ContinueInLoop packer；`v1-v2.diff` 展示本版相对冻结 v1 的最小修正，`v1-review-return.md` 保存 root 对 v1 的退回边界。

若经 root 审查后执行，只需提供新的输出路径：

```sh
python3 -B /private/tmp/jarde-testbreakinloop-evidence-archive-prep-luna-v2-20261019/pack.py \
  --out /private/tmp/new-output/capture.tar.gz
```

此次只进行私有文件准备与静态验证；没有运行 packer/collector/reviewer、JDK/JADX/Jarde CLI、Cargo、Git 或网络操作，没有修改共享仓库。
