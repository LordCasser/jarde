#!/usr/bin/env python3
"""Pack root-accepted TestEndlessLoop baseline/generated/resume evidence with per-member hashes."""
from __future__ import annotations
import argparse, hashlib, io, json, tarfile
from pathlib import Path

PRIVATE=Path('/private/tmp').resolve()
PREP=Path(__file__).resolve().parent
RESULTS={
 'jarde-testendlessloop-baseline-root-v1-20261019':('test-endless-loop-full-source-baseline-v1','02557fcf4c577ab19c02184e65f9ef8759625742b40b6a147768c6bac8484ca1',20),
 'jarde-testendlessloop-generated-root-v1-20261019':('test-endless-loop-generated-source-matrix-v1','27be145c76230439dd449458d0bd20077c41e2968b8af25165b9e99e6439157e',24),
 'jarde-testendlessloop-generated-resume-root-v1-20261019':('test-endless-loop-generated-source-resume-v1','a1a69edf087195aed6193c986cb9bc59c6aad5d09d2ff5ade002765e93b898f9',51),
}
WRAPPERS=(
 'jarde-testendlessloop-baseline-wrapper-root-v1-20261019',
 'jarde-testendlessloop-generated-wrapper-root-v1-20261019',
 'jarde-testendlessloop-generated-wrapper-root-v2-20261019',
 'jarde-testendlessloop-resume-wrapper-root-v1-20261019',
 'jarde-testendlessloop-resume-wrapper-root-v2-20261019',
)
ROOT_AUDITS=('jarde-testendlessloop-baseline-audit-root-v1-20261019',)
HISTORY=(
 'jarde-testendlessloop-baseline-prep-luna-v1-20261019',
 'jarde-testendlessloop-final-evidence-prep-luna-v1-20261019',
 'jarde-testendlessloop-final-evidence-prep-luna-v2-20261019',
 'jarde-testendlessloop-generated-audit-luna-v1-20261019',
 'jarde-testendlessloop-generated-resume-prep-luna-v1-20261019',
 'jarde-testendlessloop-generated-resume-prep-luna-v2-20261019',
)
EXTERNAL=(
 ('upstream/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestEndlessLoop.java',Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestEndlessLoop.java'),'a8b077628d7d84d1dd69e51ae2cf0de62210b3f0753461f2c85b0fca829b5df5'),
 ('upstream/jadx/LICENSE',Path('/Users/lordcasser/workspace/testzone/jadx/LICENSE'),'b40930bbcf80744c86c46a12bc9da056641d722716c378f5659b9e555ef833e1'),
 ('upstream/jadx/NOTICE',Path('/Users/lordcasser/workspace/testzone/jadx/NOTICE'),'3f34304fa0b9da79fae989cca556d22bd3d08786d6ba171f529a00bfc880e365'),
)
EXCLUDED={'target','__pycache__','.pytest_cache','.mypy_cache','.ruff_cache','.cache','node_modules'}
ACTIVE={'running','in_progress','started','collecting'}
PREP_MEMBERS=('README.md','pins.json','pack.py','notindexed-template.diff')


def sha(data:bytes)->str:return hashlib.sha256(data).hexdigest()
def require(ok:bool,msg:str)->None:
 if not ok: raise ValueError(msg)
def pin(path:Path)->dict:
 require(not path.is_symlink(),f'refuse symlink: {path}')
 data=path.resolve(strict=True).read_bytes()
 return {'path':str(path.resolve()),'bytes':len(data),'sha256':sha(data)}
def load_json(path:Path)->dict:return json.loads(path.read_text(encoding='utf-8'))
def verify_marker(receipt_name:str,expected_sha:str)->dict:
 root=PRIVATE/receipt_name; receipt=load_json(root/'execution.json'); marker=load_json(root/'root-review.json')
 require(sha((root/'execution.json').read_bytes())==expected_sha,f'receipt changed: {receipt_name}')
 require(marker.get('receipt_sha256')==expected_sha,f'root marker binds another receipt: {receipt_name}')
 require(str(marker.get('status','')).startswith('root_accepted'),f'result not root-accepted: {receipt_name}')
 return marker
def values(value):
 if isinstance(value,dict):
  for k,v in value.items():
   yield k; yield from values(v)
 elif isinstance(value,list):
  for v in value: yield from values(v)
 else: yield value
def check_receipts(generated_audit:Path,resume_audit:Path)->dict:
 receipts={}
 for name,(schema,digest,command_count) in RESULTS.items():
  root=PRIVATE/name; path=root/'execution.json'; marker_path=root/'root-review.json'
  require(path.is_file() and marker_path.is_file(),f'missing result or canonical root marker: {name}')
  receipt=load_json(path); require(receipt.get('schema')==schema,f'schema mismatch: {name}')
  require(receipt.get('status') not in ACTIVE,f'nonterminal result: {name}')
  require(sha(path.read_bytes())==digest,f'receipt changed: {name}')
  marker=verify_marker(name,digest)
  require(len(receipt.get('commands',[]))==command_count,f'command count mismatch: {name}')
  receipts[name]=receipt
 base,generated,resume=[receipts[name] for name in RESULTS]
 require(len(base.get('original_runtime',[]))==4,'baseline must retain four finite constructor observations')
 require(len(generated.get('compilations',[]))==20 and sum(x.get('exit_code')==0 for x in generated['compilations'])==18,
         'generated matrix compilation inventory changed')
 require(len(generated.get('runtime_rows',[]))==2 and len(generated.get('wrong_root_rows',[]))==1,
         'generated first-stage observation counts changed')
 require(all(row.get('matches_original_profile_runtime') is True and row.get('exit_code')==0 for row in generated['runtime_rows']),
         'first-stage constructor observations changed')
 require(all(row.get('rejected') is True for row in generated['wrong_root_rows']),
         'first-stage wrong-root observation changed')
 require(all(row.get('failure_classification')=='harness-major-55-boundary' for row in generated['compilations'] if row.get('exit_code')!=0),
         'retained JDK8 framework boundary classification changed')
 require(resume.get('counts_derived',{}).get('combined_actual_commands')==75 and len(resume.get('reparsed_successful_compiles',[]))==18,
         'resume compile/output summary changed')
 require(len(resume.get('runtime_rows',[]))==34 and len(resume.get('wrong_root_rows',[]))==17 and len(resume.get('commands',[]))==51,
         'resume observation counts changed')
 kinds={tuple(row['cell_key']):row['kind'] for row in generated.get('source_cells',[])}
 static=resume.get('reparsed_successful_compiles',[])
 jarde=[row for row in static if kinds.get(tuple(row['cell_key']))=='jarde']
 jadx=[row for row in static if kinds.get(tuple(row['cell_key']))=='jadx']
 require(len(jarde)==16 and all(row['static_loop_code_comparison']['all_three_exact'] for row in jarde),
         'Jarde exact static-code comparison summary changed')
 require(len(jadx)==2 and all(row['static_loop_code_comparison']['methods']['test1']['exact_code_exception_rows_limits_and_access_match']
         and not row['static_loop_code_comparison']['methods']['test2']['exact_code_exception_rows_limits_and_access_match']
         and not row['static_loop_code_comparison']['methods']['test3']['exact_code_exception_rows_limits_and_access_match'] for row in jadx),
         'JADX loop-code comparison summary changed')
 require(len(base['commands'])+len(generated['commands'])+len(resume['commands'])==95,
         'the three separately captured command receipts no longer total 95')
 # Every generated/resume independent review must explicitly bind its receipt hash.
 for path,digest,label in ((generated_audit,RESULTS['jarde-testendlessloop-generated-root-v1-20261019'][1],'generated'),
                           (resume_audit,RESULTS['jarde-testendlessloop-generated-resume-root-v1-20261019'][1],'resume')):
  review_path=path/'review.json'; require(review_path.is_file(),f'missing {label} independent review')
  review=load_json(review_path); bound=set(str(x) for x in values(review))
  require(digest in bound,f'{label} independent review does not bind receipt SHA')
 # Preserve failed/repair wrapper histories; only require terminal receipts, never rewrite them as passes.
 for name in WRAPPERS:
  path=PRIVATE/name/'execution.json'; require(path.is_file(),f'missing wrapper history: {name}')
  wrapper=load_json(path); require(wrapper.get('status') not in ACTIVE,f'wrapper still active: {name}')
 # Root audit and summary are separately checked against the canonical marker.
 base_audit=load_json(PRIVATE/ROOT_AUDITS[0]/'review.json')
 require(base_audit.get('receipt_sha256')==RESULTS['jarde-testendlessloop-baseline-root-v1-20261019'][1],
         'baseline audit receipt pin mismatch')
 require((PRIVATE/ROOT_AUDITS[0]/'review.json').is_file(),'missing baseline root audit')
 require(base_audit.get('commands')==20 and base_audit.get('original_vm_runs')==4
         and base_audit.get('case_observations')==4 and base_audit.get('api_cells')==8
         and base_audit.get('api_method_rows')==32,'baseline independent review summary changed')
 require(all(row.get('matches_original_constructor_observation') is True and row.get('exit_code')==0 for row in resume['runtime_rows']),
         'resume constructor observations changed')
 require(all(row.get('rejected') is True for row in resume['wrong_root_rows']),
         'resume wrong-root observations changed')
 return {'baseline':base,'generated':generated,'resume':resume}

def gather(generated_audit:Path,resume_audit:Path)->dict[str,Path]:
 members={}
 def add(name:str,path:Path)->None:
  require(name not in members,f'duplicate archive member: {name}')
  require(path.is_file() and not path.is_symlink(),f'missing/unsafe file: {path}')
  members[name]=path.resolve(strict=True)
 roots=list(RESULTS)+list(WRAPPERS)+list(ROOT_AUDITS)+list(HISTORY)
 audit_paths=[generated_audit,resume_audit]
 for name in roots:
  root=PRIVATE/name; require(root.is_dir() and not root.is_symlink(),f'missing/unsafe evidence root: {root}')
  for path in sorted(root.rglob('*')):
   if any(part in EXCLUDED for part in path.parts): continue
   require(not path.is_symlink(),f'refuse symlink in evidence tree: {path}')
   if path.is_file(): add('private-tmp/'+path.relative_to(PRIVATE).as_posix(),path)
 seen_audits=set()
 for root in audit_paths:
  root=root.resolve(strict=True); require(root.is_dir() and root.is_relative_to(PRIVATE),f'audit root outside private tmp: {root}')
  if root in seen_audits: continue
  seen_audits.add(root)
  for path in sorted(root.rglob('*')):
   if any(part in EXCLUDED for part in path.parts): continue
   require(not path.is_symlink(),f'refuse symlink in root audit tree: {path}')
   if path.is_file(): add('private-tmp/'+path.relative_to(PRIVATE).as_posix(),path)
 for arc,path,digest in EXTERNAL:
  add(arc,path); require(sha(path.read_bytes())==digest,f'upstream source/license pin changed: {path}')
 for name in PREP_MEMBERS: add('archive-preparation/'+name,PREP/name)
 return dict(sorted(members.items()))

def verify_prep_pins(files:dict[str,Path],generated_audit:Path,resume_audit:Path)->None:
 pins=load_json(PREP/'pins.json'); expected={x['path']:x for x in pins['archive_inputs']}
 actual={name:path for name,path in files.items() if not name.startswith('archive-preparation/')}
 require(set(expected)<=set(actual),'a frozen archive input is missing')
 generated_prefix='private-tmp/'+generated_audit.relative_to(PRIVATE).as_posix()+'/'
 resume_prefix='private-tmp/'+resume_audit.relative_to(PRIVATE).as_posix()+'/'
 late_allowed={
  'private-tmp/jarde-testendlessloop-generated-root-v1-20261019/root-review.json',
  'private-tmp/jarde-testendlessloop-generated-resume-root-v1-20261019/root-review.json',
 }
 unexpected=set(actual)-set(expected)
 require(all(name in late_allowed or name.startswith(generated_prefix) or name.startswith(resume_prefix) for name in unexpected),
         'archive inputs changed outside explicitly deferred root markers/audits')
 for name,row in expected.items():
  data=actual[name].read_bytes()
  require(len(data)==row['bytes'] and sha(data)==row['sha256'],f'frozen input changed: {name}')
 for name,row in pins['preparation_files'].items():
  data=(PREP/name).read_bytes(); require(len(data)==row['bytes'] and sha(data)==row['sha256'],f'preparation file changed: {name}')

def main()->None:
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--out',type=Path,required=True,help='new archive path; must not exist')
 ap.add_argument('--generated-audit-root',type=Path,required=True,help='root-accepted generated audit directory containing review.json')
 ap.add_argument('--resume-audit-root',type=Path,required=True,help='root-accepted resume audit directory containing review.json')
 args=ap.parse_args(); out=args.out.resolve(); inv_path=out.with_suffix(out.suffix+'.inventory.json')
 require(not out.exists() and not inv_path.exists(),'refuse existing archive or inventory')
 require(not out.is_relative_to(PREP),'archive must be outside archive-preparation directory')
 generated_audit=args.generated_audit_root.resolve(strict=True); resume_audit=args.resume_audit_root.resolve(strict=True)
 receipts=check_receipts(generated_audit,resume_audit)
 files=gather(generated_audit,resume_audit); verify_prep_pins(files,generated_audit,resume_audit)
 rows=[{'path':arc,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())} for arc,path in files.items()]
 manifest={'schema':'test-endless-loop-durable-evidence-archive-v1','status':'root-accepted-inputs-verified-at-pack-time',
  'member_count':len(rows),'members':rows,'result_roots':list(RESULTS),'wrapper_roots':list(WRAPPERS),
  'root_audit_roots':[str(PRIVATE/x) for x in ROOT_AUDITS]+[str(args.generated_audit_root),str(args.resume_audit_root)],
  'history_roots':list(HISTORY),'upstream_snapshot_members':[arc for arc,_,_ in EXTERNAL],
  'captured_commands':{'baseline':20,'generated_first_stage':24,'generated_resume':51,'sum_of_separate_receipts':95},
  'scope':'TestEndlessLoop baseline and generated-source evidence. Constructor/inventory cases only; no test1/test2/test3 or JUnit invocation is claimed.',
  'static_limits':'Jarde 16 successful targets have exact loop Code/access/limits/exception-row comparisons. JADX 2 targets retain differing test2/test3 bytecode where only this-reflexive comparison/control form differs; no loop was invoked. No StackMapTable byte-equality claim.',
  'external_binary_policy':'JDK, CLI, and dependency binaries are not archived; immutable receipts retain their paths/hashes.'}
 out.parent.mkdir(parents=True,exist_ok=True)
 with tarfile.open(out,'x:gz') as tar:
  for arc,path in files.items(): tar.add(path,arcname=arc,recursive=False)
  blob=(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode(); info=tarfile.TarInfo('ARCHIVE_INVENTORY.json');info.size=len(blob);info.mode=0o644;tar.addfile(info,io.BytesIO(blob))
 with tarfile.open(out,'r:gz') as tar:
  regular={m.name:m for m in tar.getmembers() if m.isfile()}
  require(set(regular)=={x['path'] for x in rows}|{'ARCHIVE_INVENTORY.json'},'archive member set mismatch')
  for row in rows:
   data=tar.extractfile(regular[row['path']]).read();require(len(data)==row['bytes'] and sha(data)==row['sha256'],f"archive member changed: {row['path']}")
  require(json.loads(tar.extractfile(regular['ARCHIVE_INVENTORY.json']).read())==manifest,'embedded inventory mismatch')
 inv=(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
 with inv_path.open('xb') as stream:stream.write(inv)
 print(json.dumps({'status':'packed-and-reopened','archive':str(out),'archive_sha256':sha(out.read_bytes()),'inventory':str(inv_path),'inventory_sha256':sha(inv),'member_count':len(rows)},indent=2))
if __name__=='__main__':main()
