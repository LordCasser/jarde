# TestEndlessLoop resume collector v2

This version preserves the v1 collector and changes only `exact_pin`: it compares the canonical file-pin fields (`path`, `bytes`, `sha256`) while ignoring additional class-fact metadata that may be attached to a pin-shaped receipt record. This fixes the v1 preflight rejection of unchanged compiled-class files whose `class_facts` records also contain methods/access fields.

The failed v1 execution is preserved at `/private/tmp/jarde-testendlessloop-resume-wrapper-root-v1-20261019/execution.json`; it stopped during recursive pin validation before any VM command. The original first-stage matrix and baseline remain pinned at their prior accepted paths.

No collector or toolchain was run for v2. Python AST parsing passed. `v1-v2.diff` contains the one-line implementation delta; `pins.json` binds both versions and the preserved failure receipt.
