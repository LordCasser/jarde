#!/usr/bin/env python3
"""Resume missing TestEndlessLoop constructor-only VM checks from a frozen generated receipt.

This never recompiles sources and never invokes test1/test2/test3. It reopens the first-stage
receipt and all compile outputs, then runs only missing constructor/inventory and wrong-root rows.
"""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, re, shutil, sys
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
COMPARE_REL='openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD_REL='openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL='openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_REL='openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
BASELINE_PATH=Path('/private/tmp/jarde-testendlessloop-baseline-root-v1-20261019/execution.json')
BASELINE_SHA='02557fcf4c577ab19c02184e65f9ef8759625742b40b6a147768c6bac8484ca1'
MATRIX_PATH=Path('/private/tmp/jarde-testendlessloop-generated-root-v1-20261019/execution.json')
MATRIX_SHA='27be145c76230439dd449458d0bd20077c41e2968b8af25165b9e99e6439157e'
MATRIX_SCHEMA='test-endless-loop-generated-source-matrix-v1'
INTERNAL='jadx/tests/integration/loops/TestEndlessLoop$TestCls'
OUTER='jadx/tests/integration/loops/TestEndlessLoop'
DRIVER_NAME='TestEndlessLoopDriver'
DRIVER_SHA='9b272cf252f56c860a2e0e50552c068800faf2de14dae55a565b91dcbb6e07e0'
PROFILES=('debug','no-debug'); RUNTIMES=('javac8','javac23')
EXPECTED_LOOP_CODE={'test1':'2a2aa60006a7fffbb1','test2':'2a2aa5fffeb1','test3':'2a2aa5fffeb1'}
EXPECTED_METHODS={('<init>','()V'),('test1','()V'),('test2','()V'),('test3','()V')}
CASE_NAMES=('construct-and-method-inventory',)
CURRENT_CLI_SHA='96e534b0000fe91c1d34a282919479a97eb4706063501d188cdff010c4640366'
ENV_STRIP=('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','CARGO_TARGET_DIR')


def sha_file(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for chunk in iter(lambda:stream.read(1024*1024),b''): h.update(chunk)
 return h.hexdigest()
def json_normalize(value):
 if isinstance(value,dict): return {k:json_normalize(v) for k,v in value.items()}
 if isinstance(value,(list,tuple)): return [json_normalize(v) for v in value]
 return value
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path)
 if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
 module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module
def exact_pin(compare,row,label):
 if not isinstance(row,dict) or not {'path','bytes','sha256'}<=row.keys(): raise RuntimeError(f'{label}: malformed file pin')
 path=Path(row['path']).resolve(strict=True)
 if compare.pin(path)!={key:row[key] for key in ('path','bytes','sha256')}: raise RuntimeError(f'{label}: changed pin {path}')
 return path
def reopen_nested_pins(compare,value,label='receipt'):
 count=0
 if isinstance(value,dict):
  if {'path','bytes','sha256'}<=value.keys(): exact_pin(compare,value,label); return 1
  for key,item in value.items(): count+=reopen_nested_pins(compare,item,f'{label}.{key}')
 elif isinstance(value,list):
  for index,item in enumerate(value): count+=reopen_nested_pins(compare,item,f'{label}[{index}]')
 return count
def filetree(compare,root):
 return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*')) if p.is_file()}
def parse_profile_facts(compare,physical_parser,root):
 facts={}
 for path in sorted(root.rglob('*.class')):
  rel=path.relative_to(root).as_posix(); parsed=compare.parse_class(path); physical=physical_parser.parse_class_file(path.read_bytes())
  if physical['class_name']!=parsed['class_name'] or physical['major']!=parsed['major'] or physical['methods']!=parsed['methods']:
   raise RuntimeError(f'independent parser disagreement: {rel}')
  if sorted((f['name'],f['descriptor'],f['access']) for f in physical['fields'])!=sorted(parsed['fields']):
   raise RuntimeError(f'field parser disagreement: {rel}')
  parsed['access']=physical['access']
  if physical['major']!=52: raise RuntimeError(f'compiled class is not release-8 major 52: {rel}')
  methods={(m['name'],m['descriptor']) for m in parsed['methods']}
  if len(methods)!=len(parsed['methods']): raise RuntimeError(f'duplicate method identities: {rel}')
  for method in parsed['methods']:
   code=method.get('code')
   if code is None or not code.get('bcis') or code['bcis'][0]!=0 or code['bcis'][-1]>=code['code_length']:
    raise RuntimeError(f'invalid Code/BCI facts: {rel}:{method["name"]}{method["descriptor"]}')
  facts[rel]=parsed
 if INTERNAL+'.class' not in facts or facts[INTERNAL+'.class']['class_name']!=INTERNAL:
  raise RuntimeError('compiled target class is missing or has wrong identity')
 return facts
def parse_oracle(raw):
 import base64
 pattern=re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) target_stdout_b64=([^ ]*)$')
 lines=raw.decode('utf-8','strict').splitlines()
 if len(lines)!=1: raise RuntimeError(f'expected one constructor-only row, got {len(lines)}')
 def decode(value): return base64.b64decode(value,validate=True).decode('utf-8','strict')
 rows=[]
 for index,line in enumerate(lines):
  match=pattern.fullmatch(line)
  if match is None: raise RuntimeError(f'malformed runtime row {line!r}')
  idx,name,inp,result,exc,message,stack,target_stdout=match.groups()
  if int(idx)!=index or name!=CASE_NAMES[index]: raise RuntimeError('constructor-only case identity mismatch')
  rows.append({'index':index,'name':name,'input':decode(inp),'result':decode(result),'exception_type':exc,
    'exception_message':decode(message),'exception_stack':decode(stack),'target_stdout':decode(target_stdout),'raw':line})
 return rows
def projection(rows):
 return [{key:row[key] for key in ('index','name','input','result','exception_type','target_stdout')} for row in rows]
def pin_tree(compare,tree,label):
 if not isinstance(tree,dict): raise RuntimeError(f'{label}: missing class tree')
 for rel,record in tree.items(): exact_pin(compare,record,f'{label}/{rel}')
 return tree


def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--matrix',type=Path,required=True,help='frozen first-stage generated execution.json')
 ap.add_argument('--matrix-sha256',required=True,help='exact SHA-256 of first-stage receipt')
 ap.add_argument('--baseline',type=Path,required=True,help='accepted original TestEndlessLoop baseline execution.json')
 ap.add_argument('--baseline-sha256',required=True)
 ap.add_argument('--cli',type=Path,required=True,help='pinned CLI path; this stage does not execute it')
 ap.add_argument('--out',type=Path,required=True); ap.add_argument('--root',type=Path,default=ROOT)
 args=ap.parse_args(); root=args.root.resolve(strict=True); matrix_path=args.matrix.resolve(strict=True); baseline_path=args.baseline.resolve(strict=True); cli=args.cli.resolve(strict=True); out=args.out.resolve()
 if root!=ROOT.resolve(): raise SystemExit('workspace differs from frozen root')
 if matrix_path!=MATRIX_PATH.resolve() or args.matrix_sha256!=MATRIX_SHA or sha_file(matrix_path)!=MATRIX_SHA:
  raise SystemExit('first-stage matrix path/SHA mismatch')
 if baseline_path!=BASELINE_PATH.resolve() or args.baseline_sha256!=BASELINE_SHA or sha_file(baseline_path)!=BASELINE_SHA:
  raise SystemExit('original baseline path/SHA mismatch')
 if out.exists(): raise SystemExit(f'refusing existing output: {out}')
 if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('workspace target must be absent')
 if shutil.disk_usage(root).free<5*1024**3: raise SystemExit('workspace free space below 5 GiB')
 compare_path=root/COMPARE_REL; guard_path=root/GUARD_REL; scanner_path=root/SCANNER_REL; jdk_path=root/JDK_REL
 for path,digest,label in ((compare_path,'18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6','compare'),
  (guard_path,GUARD_SHA,'guard'),(scanner_path,SCANNER_SHA,'size scanner'),(jdk_path,JDK_SHA,'JDK manifest'),(PARSER,PARSER_SHA,'physical parser')):
  if sha_file(path)!=digest: raise SystemExit(f'{label} pin mismatch')
 compare=load(compare_path,'endless_resume_compare'); guard=load(guard_path,'endless_resume_guard'); scanner=load(scanner_path,'endless_resume_scanner'); physical_parser=load(PARSER,'endless_resume_physical')
 jdks,jdk_record=compare.configured_jdks(jdk_path,JDK_SHA)
 baseline=json.loads(baseline_path.read_text(encoding='utf-8')); matrix=json.loads(matrix_path.read_text(encoding='utf-8'))
 if baseline.get('schema')!='test-endless-loop-full-source-baseline-v1' or baseline.get('status')!='captured-pending-independent-review': raise SystemExit('original baseline is not the accepted captured receipt')
 if matrix.get('schema')!=MATRIX_SCHEMA or matrix.get('status')!='captured-pending-independent-review': raise SystemExit('first-stage matrix is not terminal captured data')
 if matrix.get('baseline_sha256_argument')!=BASELINE_SHA or matrix.get('baseline_receipt',{}).get('sha256')!=BASELINE_SHA: raise SystemExit('first-stage matrix is not bound to original baseline')
 baseline_cli=baseline.get('cli',{})
 if args.cli.resolve()!=Path(baseline_cli.get('path','')).resolve() or compare.pin(cli)!=baseline_cli or baseline_cli.get('sha256')!=CURRENT_CLI_SHA:
  raise SystemExit('CLI path/content is not the pinned original-baseline CLI')
 if baseline_cli not in matrix.get('external_pins_before',[]): raise SystemExit('first-stage matrix does not bind the original-baseline CLI pin')
 if any(matrix.get(key) is not True for key in ('source_unchanged','source_unchanged_finally','external_inputs_unchanged','local_copies_unchanged','generated_outputs_unchanged','generated_outputs_unchanged_finally','target_absent','target_absent_finally')):
  raise SystemExit('first-stage closure or target-absence gate failed')
 if matrix.get('source_pins_before')!=matrix.get('source_pins_after') or matrix.get('source_pins_before')!=matrix.get('source_pins_after_finally'):
  raise SystemExit('first-stage source snapshots are inconsistent')
 if matrix.get('external_pins_before')!=matrix.get('external_pins_after') or matrix.get('external_pins_before')!=matrix.get('external_pins_after_finally'):
  raise SystemExit('first-stage external snapshots are inconsistent')
 if matrix.get('generated_output_pins_before')!=matrix.get('generated_output_pins_after') or matrix.get('generated_output_pins_before')!=matrix.get('generated_output_pins_after_finally'):
  raise SystemExit('first-stage generated-output snapshots are inconsistent')
 if matrix.get('local_copies_before')!=matrix.get('local_copies_after') or matrix.get('local_copies_before')!=matrix.get('local_copies_after_finally'):
  raise SystemExit('first-stage local-copy snapshots are inconsistent')
 reopened_matrix_pins=reopen_nested_pins(compare,matrix,'first-stage')
 reopened_baseline_pins=reopen_nested_pins(compare,baseline,'original-baseline')
 # Independently reopen checkout source, prior generated sources/classes, all raw logs, and dependency class trees.
 source_before=compare.source_closure(root)
 if source_before!=matrix['source_pins_before']: raise SystemExit('current checkout differs from first-stage source snapshot')
 for record in matrix['external_pins_before']: exact_pin(compare,record,'first-stage external input')
 previous_generated=matrix['generated_output_pins_before']
 for path,pin in previous_generated['sources'].items():
  if compare.pin(Path(path))!=pin: raise SystemExit(f'first-stage generated source changed: {path}')
 for tree_root,records in previous_generated['class_trees'].items():
  actual=filetree(compare,Path(tree_root))
  if actual!=records: raise SystemExit(f'first-stage generated class tree changed: {tree_root}')
 for folder,records in matrix['dependency_directory_pins_before'].items():
  actual={str(path):compare.pin(path) for path in sorted(Path(folder).rglob('*.class'))}
  if actual!=records: raise SystemExit(f'dependency class directory changed: {folder}')
 driver_classes=[exact_pin(compare,x,'first-stage driver class') for x in matrix['driver_classes']]
 if len(driver_classes)!=1 or driver_classes[0].name!='TestEndlessLoopDriver.class': raise SystemExit('expected exactly one existing driver class')
 driver_root=driver_classes[0].parent
 if filetree(compare,driver_root)!={driver_classes[0].name:compare.pin(driver_classes[0])}: raise SystemExit('driver class directory has unexpected entries')
 # Verify original full source profiles and original finite observation rows.
 original_profiles={row['profile']:row for row in baseline['source_profiles']}
 if set(original_profiles)!=set(PROFILES): raise SystemExit('original source profiles incomplete')
 for profile,row in original_profiles.items():
  if row['exit_code']!=0 or set(row['class_tree'])!={INTERNAL+'.class',OUTER+'.class'}: raise SystemExit(f'original {profile} outer/child tree incomplete')
  class_root=Path(row['class_root']).resolve(strict=True)
  if filetree(compare,class_root)!=row['class_tree']: raise SystemExit(f'original {profile} class tree changed')
  bundle=exact_pin(compare,row['bundle'],f'original {profile} complete bundle')
  with __import__('zipfile').ZipFile(bundle) as archive:
   if sorted(n for n in archive.namelist() if not n.endswith('/'))!=sorted(row['class_tree']): raise SystemExit('original bundle tree mismatch')
   for rel,record in row['class_tree'].items():
    if archive.read(rel)!=Path(record['path']).read_bytes(): raise SystemExit('original bundle bytes differ from class tree')
# Preserve original four oracle rows as construction/inventory only.
 commands_by_id={row['index']:row for row in baseline['commands']}
 oracles={}
 for row in baseline['original_runtime']:
  cmd=commands_by_id[row['command']]
  if row['exit_code']!=0 or row['row_count']!=1 or cmd['exit_code']!=0: raise SystemExit('original constructor-only observation failed')
  parsed=parse_oracle(compare.command_artifact(cmd,'stdout'))
  if parsed!=row['rows']: raise SystemExit('original runtime row differs from captured stdout')
  oracles[(row['profile'],row['runtime'])]=projection(parsed)
 if set(oracles)!={(p,r) for p in PROFILES for r in RUNTIMES}: raise SystemExit('original runtime grid incomplete')
 # Reopen source-cell artifacts and the original v1 compilation ledger without recompiling.
 cells={tuple(row['cell_key']):row for row in matrix['source_cells']}
 if len(cells)!=10 or any(row.get('source_available') is not True for row in cells.values()): raise SystemExit('expected ten complete original source cells')
 for cell in cells.values():
  for pair in cell.get('source_copies',[]):
   original=exact_pin(compare,pair['source'],'original full source')
   copy=exact_pin(compare,pair['copy'],'first-stage source copy')
   if original.read_bytes()!=copy.read_bytes(): raise SystemExit('first-stage source copy differs from original full source')
  for rec in cell.get('source_pins',[]): exact_pin(compare,rec,'source-cell pin')
  for rec in cell.get('input_pins',[]): exact_pin(compare,rec,'source-cell input')
  if cell.get('report_pin'): exact_pin(compare,cell['report_pin'],'source report')
 compilations=matrix['compilations']
 if len(compilations)!=20: raise SystemExit('first-stage compilation ledger must contain 20 rows')
 command_map={row['index']:row for row in matrix['commands']}
 if len(command_map)!=24: raise SystemExit('first-stage command ledger must contain exactly 24 rows')
 if len(matrix['runtime_rows'])!=2 or len(matrix['wrong_root_rows'])!=1: raise SystemExit('first-stage runtime attempt counts differ from preserved v1 receipt')
 for command in command_map.values():
  compare.command_artifact(command,'stdout'); compare.command_artifact(command,'stderr')
 prior_runtime={(tuple(row['cell_key']),row['compiler'],row['runtime']):row for row in matrix['runtime_rows']}
 prior_wrong={(tuple(row['cell_key']),row['compiler']):row for row in matrix['wrong_root_rows']}
 success=[]; parsed_compiles=[]; static_results={}
 for row in compilations:
  if row['exit_code']!=0: continue
  # The first-stage collector's local `physical` name was shadowed after its first target.
  # Successful javac outputs remain valid; preserve that parser error and independently reparse disk.
  prior_parser_error={'class_facts_error':row['class_facts_error'],'target_facts_error':row['target_facts_error']}
  cell_key=tuple(row['cell_key']); cell=cells[cell_key]
  class_root=Path(row['class_root']).resolve(strict=True)
  tree=filetree(compare,class_root)
  if tree!=row['class_tree']: raise SystemExit(f'compiled class files differ from frozen ledger: {cell_key}/{row["leg"]}')
  expected_tree={INTERNAL+'.class'} if cell['kind']=='jarde' else {INTERNAL+'.class',OUTER+'.class'}
  if set(tree)!=expected_tree: raise SystemExit(f'compiled source emitted an unexpected complete class tree: {cell_key}/{row["leg"]}')
  facts=parse_profile_facts(compare,physical_parser,class_root)
  generated=facts[INTERNAL+'.class']; original=original_profiles[cell['profile']]['target_facts']
  if generated['class_name']!=INTERNAL or original['class_name']!=INTERNAL: raise SystemExit('target binary identity mismatch')
  gen_methods={(m['name'],m['descriptor']):m for m in generated['methods']}; orig_methods={(m['name'],m['descriptor']):m for m in original['methods']}
  if set(gen_methods)!=EXPECTED_METHODS or set(orig_methods)!=EXPECTED_METHODS: raise SystemExit('exact four-method target inventory mismatch')
  if sorted(generated['fields'])!=sorted(original['fields']): raise SystemExit('target field inventory changed')
  method_access_equal=all(gen_methods[key]['access']==orig_methods[key]['access'] for key in EXPECTED_METHODS)
  if not method_access_equal: raise SystemExit('target method access flags changed')
  comparisons={}
  for name,expected_hex in EXPECTED_LOOP_CODE.items():
   key=(name,'()V'); before=orig_methods[key]; after=gen_methods[key]
   before_code=before.get('code') or {}; after_code=after.get('code') or {}
   exact=(before['access']==after['access'] and before_code==after_code and before_code.get('code_hex')==expected_hex
          and before_code.get('max_stack')==2 and before_code.get('max_locals')==1
          and before_code.get('code_length')==len(bytes.fromhex(expected_hex)))
   comparisons[name]={'exact_code_exception_rows_limits_and_access_match':exact,'expected_original_code_hex':expected_hex,
    'original_method':before,'generated_method':after}
  static_results[(cell_key,row['leg'])]={'all_three_exact':all(v['exact_code_exception_rows_limits_and_access_match'] for v in comparisons.values()),'methods':comparisons}
  parsed_compiles.append({'cell_key':list(cell_key),'compiler':row['leg'],'original_compile_command':row['command'],'class_root':str(class_root),
   'class_tree':tree,'first_stage_parser_error_preserved':prior_parser_error,'target_facts':generated,'method_inventory_matches_original':True,'static_loop_code_comparison':static_results[(cell_key,row['leg'])]})
  success.append((row,cell))
 if len(success)!=18: raise SystemExit(f'expected 18 successful frozen compiles; found {len(success)}')
 if len(prior_runtime)!=2 or len(prior_wrong)!=1: raise SystemExit('first-stage successful compile observation ledger is not exact')
 # The already-observed compile has its two VM rows and wrong-root control; validate them and never rerun.
 existing_cell=('debug','child','default'); existing_leg='javac8'
 if len(prior_runtime)!=2 or {(k[0],k[1]) for k in prior_runtime}!={(existing_cell,existing_leg)}:
  raise SystemExit('unexpected first-stage runtime target identity')
 if len(prior_wrong)!=1 or (existing_cell,existing_leg) not in prior_wrong:
  raise SystemExit('first-stage wrong-root control does not cover the existing target')
 existing_profile=cells[existing_cell]['profile']
 for runtime in RUNTIMES:
  observed=prior_runtime[(existing_cell,existing_leg,runtime)]; command=command_map[observed['command']]
  if observed['exit_code']!=0 or command['exit_code']!=0:
   raise SystemExit('already-observed first-stage runtime command failed')
  parsed=parse_oracle(compare.command_artifact(command,'stdout'))
  if parsed!=observed['rows'] or projection(parsed)!=oracles[(existing_profile,runtime)]:
   raise SystemExit('already-observed first-stage runtime differs from original constructor observation')
 prior_control=prior_wrong[(existing_cell,existing_leg)]; prior_command=command_map[prior_control['command']]
 if prior_command['exit_code']!=prior_control['exit_code'] or prior_control.get('rejected') is not True:
  raise SystemExit('already-observed first-stage wrong-root control failed')
 if b'wrong CodeSource:' not in compare.command_artifact(prior_command,'stderr'):
  raise SystemExit('already-observed first-stage wrong-root diagnostic missing')
 missing=[]
 for row,cell in success:
  key=tuple(row['cell_key']); leg=row['leg']
  runtime_missing=[runtime for runtime in RUNTIMES if (key,leg,runtime) not in prior_runtime]
  wrong_missing=(key,leg) not in prior_wrong
  if runtime_missing or wrong_missing:
   if len(runtime_missing)!=2 or not wrong_missing: raise SystemExit(f'partial first-stage observations for target {key}/{leg}; refusing duplicate/ambiguous resume')
   missing.append((row,cell))
 if len(missing)!=17: raise SystemExit(f'expected exactly 17 unobserved compiled targets; found {len(missing)}')
 # Reopen every path used by the original compilation before starting any new process.
 for cell in cells.values():
  for copy in cell.get('source_copies',[]): exact_pin(compare,copy['copy'],'retained full source copy')
 for row,cell in success:
  for pin in row['class_tree'].values(): exact_pin(compare,pin,'retained compiler output')
 # Open output only after the frozen evidence is closed and all 17 target inventories are proven.
 out.mkdir(parents=True,exist_ok=False); raw=out/'raw'; raw.mkdir(); empty=out/'empty-classpath'; empty.mkdir()
 guard.ROOT=root; guard.OUT=raw; guard.target_bytes=lambda:scanner.target_bytes(root); guard.command_stream=compare.pin
 guard.expected_test_summaries=lambda index,stdout:None
 runtime_original=Path(baseline['runtime_wrapper']['path']).resolve(strict=True)
 exact_pin(compare,baseline['runtime_wrapper'],'original runtime wrapper')
 runtime_copy=out/runtime_original.name; shutil.copyfile(runtime_original,runtime_copy)
 if runtime_copy.read_bytes()!=runtime_original.read_bytes(): raise RuntimeError('runtime wrapper copy differs')
 local_before=[compare.pin(runtime_copy)]
 external_rows=[baseline_path,matrix_path,compare_path,guard_path,scanner_path,jdk_path,PARSER,runtime_original,cli,Path(__file__),
  Path(baseline['jadx']['path']),Path(baseline['jadx_jar']['path']),Path(matrix['driver_source']['path']),Path(matrix['driver_copy']['path']),driver_classes[0]]
 external_rows.extend(Path(row['path']) for row in matrix['external_pins_before'])
 for runtime_record in jdk_record['tools'].values():
  for tool_record in runtime_record.values():
   tool_path=Path(tool_record['path']).resolve(strict=True)
   if compare.pin(tool_path)!=tool_record: raise RuntimeError(f"JDK executable changed: {tool_path}")
   external_rows.append(tool_path)
 external_rows.extend(Path(row['path']) for row in baseline.get('external_input_pins_before',{}).get('files',[]))
 external_rows.extend(Path(row['path']) for row in baseline.get('external_input_pins_before',{}).get('dependency_artifacts',[]))
 for cell in cells.values():
  external_rows.extend(Path(pin['path']) for pin in cell.get('source_pins',[]))
  external_rows.extend(Path(pin['path']) for pin in cell.get('input_pins',[]))
  if cell.get('report_pin'): external_rows.append(Path(cell['report_pin']['path']))
 for row in success:
  compile_row=row[0]
  external_rows.extend(Path(p['path']) for p in compile_row['class_tree'].values())
 external_rows.extend(Path(p['path']) for p in matrix['source_pins_before'].values())
 external_rows.extend(Path(p['path']) for values in matrix['dependency_directory_pins_before'].values() for p in values.values())
 # Deduplicate exact paths while preserving a deterministic order.
 external_paths=[]; seen=set()
 for path in external_rows:
  path=Path(path).resolve(strict=True)
  if path not in seen: seen.add(path); external_paths.append(path)
 external_before=[compare.pin(path) for path in external_paths]
 source_before=compare.source_closure(root)
 if source_before!=matrix['source_pins_before']: raise RuntimeError('source changed between preflight and resume')
 report={'schema':'test-endless-loop-generated-source-resume-v1','status':'running','root':str(root),'output':str(out),
  'first_stage_receipt':compare.pin(matrix_path),'first_stage_sha256':MATRIX_SHA,'original_baseline_receipt':compare.pin(baseline_path),'original_baseline_sha256':BASELINE_SHA,
  'source_pins_before':source_before,'external_pins_before':external_before,'prior_generated_output_pins':matrix['generated_output_pins_before'],
  'prior_command_count':len(matrix['commands']),'prior_runtime_attempts_preserved':len(matrix['runtime_rows']),'prior_wrong_root_attempts_preserved':len(matrix['wrong_root_rows']),
  'runtime_wrapper_copy':compare.pin(runtime_copy),'existing_driver_class':compare.pin(driver_classes[0]),'jdk_manifest':jdk_record,
  'original_oracles':{f'{p}/{r}':rows for (p,r),rows in oracles.items()},'reparsed_successful_compiles':parsed_compiles,
  'missing_targets':[{'cell_key':list(row['cell_key']),'compiler':row['leg'],'original_compile_command':row['command'],'class_root':row['class_root'],
    'source_kind':cell['kind'],'static_loop_code_comparison':static_results[(tuple(row['cell_key']),row['leg'])]} for row,cell in missing],
  'commands':[],'runtime_rows':[],'wrong_root_rows':[],
  'notes':['This resume stage does not compile sources. All 20 original compile attempts and their raw results remain in the immutable first-stage receipt.',
   'The 18 successful output trees were re-pinned and re-parsed from disk before runtime commands were scheduled.',
   'The already-run target retains its two VM rows and wrong-CodeSource row; this stage schedules only the other 17 targets.',
   'Each runtime row constructs the target and checks method inventory only. test1/test2/test3 are never called.',
   'Static code comparison is limited to Code bytes, exception rows, max stack/locals, BCI list, and method access; it does not claim dynamic equivalence.']}
 compare.write_json(out/'execution.json',report); commands=report['commands']
 def run_command(argv,label,leg):
  if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError('workspace target appeared')
  env=compare.clean_env(dict(os.environ),jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK',None); env.pop('CARGO_TARGET_DIR',None)
  row=guard.run_command(len(commands)+1,[str(x) for x in argv],env); row['label']=label; row['tool_leg']=leg; commands.append(row)
  compare.write_json(out/'execution.json',report)
  if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
  return row
 def command_artifact(row,channel='stdout'): return compare.command_artifact(row,channel)
 try:
  for row,cell in missing:
   key=tuple(row['cell_key']); compiler=row['leg']; class_root=Path(row['class_root']).resolve(strict=True); basekey='-'.join(map(str,key));
   for runtime in RUNTIMES:
    result=run_command([sys.executable,'-B',runtime_copy,'30',jdks[runtime]['tools']['java'],'-Xverify:all','-cp',driver_root,DRIVER_NAME,class_root,class_root],
     f'resume-runtime-{basekey}-{compiler}-{runtime}',runtime)
    stdout=command_artifact(result); stderr=command_artifact(result,'stderr'); parsed=parse_oracle(stdout) if result['exit_code']==0 else []
    sem=projection(parsed) if parsed else None; expected=oracles[(cell['profile'],runtime)]
    report['runtime_rows'].append({'cell_key':list(key),'source_kind':cell['kind'],'compiler':compiler,'runtime':runtime,'original_compile_command':row['command'],
     'command':result['index'],'exit_code':result['exit_code'],'target_root':str(class_root),'application_classpath':[str(driver_root)],
     'stdout':compare.pin(Path(result['streams']['stdout']['path'])),'stderr':compare.pin(Path(result['streams']['stderr']['path'])),
     'rows':parsed,'semantic_projection':sem,'matches_original_constructor_observation':result['exit_code']==0 and sem==expected})
    compare.write_json(out/'execution.json',report)
   wrong=run_command([sys.executable,'-B',runtime_copy,'30',jdks['javac23']['tools']['java'],'-Xverify:all','-cp',driver_root,DRIVER_NAME,class_root,empty],
    f'resume-wrong-root-{basekey}-{compiler}','javac23')
   error=command_artifact(wrong,'stderr'); rejected=wrong['exit_code']==1 and b'wrong CodeSource:' in error
   report['wrong_root_rows'].append({'cell_key':list(key),'source_kind':cell['kind'],'compiler':compiler,'original_compile_command':row['command'],
    'command':wrong['index'],'exit_code':wrong['exit_code'],'actual_target_root':str(class_root),'expected_wrong_root':str(empty),'rejected':rejected,
    'stdout':compare.pin(Path(wrong['streams']['stdout']['path'])),'stderr':compare.pin(Path(wrong['streams']['stderr']['path']))})
   compare.write_json(out/'execution.json',report)
   if not rejected: raise RuntimeError(f'wrong-CodeSource control failed for {key}/{compiler}')
  # Re-open and compare prior stages and all runtime inputs after the last command.
  report['source_pins_after']=compare.source_closure(root)
  report['external_pins_after']=[compare.pin(path) for path in external_paths]
  report['prior_generated_output_pins_after']={'sources':{path:compare.pin(Path(path)) for path in matrix['generated_output_pins_before']['sources']},
   'class_trees':{tree:filetree(compare,Path(tree)) for tree in matrix['generated_output_pins_before']['class_trees']}}
  report['runtime_wrapper_copy_after']=compare.pin(runtime_copy)
  report['source_unchanged']=report['source_pins_after']==source_before
  report['external_inputs_unchanged']=report['external_pins_after']==external_before
  report['prior_generated_outputs_unchanged']=report['prior_generated_output_pins_after']==matrix['generated_output_pins_before']
  report['local_copies_unchanged']=report['runtime_wrapper_copy_after']==local_before[0]
  report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
  report['counts_derived']={'reused_compile_attempts':20,'reused_compile_successes':18,'reused_compile_failures':2,'resume_target_count':len(missing),
   'runtime_attempts':len(report['runtime_rows']),'wrong_root_attempts':len(report['wrong_root_rows']),'resume_commands':len(commands),'resume_raw_streams':2*len(commands),
   'combined_actual_commands':len(matrix['commands'])+len(commands)}
  if not all((report['source_unchanged'],report['external_inputs_unchanged'],report['prior_generated_outputs_unchanged'],report['local_copies_unchanged'],report['target_absent'])):
   raise RuntimeError('resume changed source, prior output, input, local copy, or target state')
  if len(commands)!=51 or len(report['runtime_rows'])!=34 or len(report['wrong_root_rows'])!=17:
   raise RuntimeError('resume did not produce exactly 51 missing actual command attempts')
  if not all(row['exit_code']==0 and row['matches_original_constructor_observation'] for row in report['runtime_rows']):
   raise RuntimeError('one or more constructor-only runtime observations failed or differed')
  report['status']='captured-pending-independent-review'
 except BaseException as exc:
  report['status']='failed'; report['error']=repr(exc); raise
 finally:
  try:
   report['source_pins_after_finally']=compare.source_closure(root)
   report['external_pins_after_finally']=[compare.pin(path) for path in external_paths]
   report['prior_generated_output_pins_after_finally']={'sources':{path:compare.pin(Path(path)) for path in matrix['generated_output_pins_before']['sources']},
    'class_trees':{tree:filetree(compare,Path(tree)) for tree in matrix['generated_output_pins_before']['class_trees']}}
   report['runtime_wrapper_copy_after_finally']=compare.pin(runtime_copy)
   report['source_unchanged_finally']=report['source_pins_after_finally']==source_before
   report['external_inputs_unchanged_finally']=report['external_pins_after_finally']==external_before
   report['prior_generated_outputs_unchanged_finally']=report['prior_generated_output_pins_after_finally']==matrix['generated_output_pins_before']
   report['local_copies_unchanged_finally']=report['runtime_wrapper_copy_after_finally']==local_before[0]
   report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
   if not all((report['source_unchanged_finally'],report['external_inputs_unchanged_finally'],report['prior_generated_outputs_unchanged_finally'],report['local_copies_unchanged_finally'],report['target_absent_finally'])):
    report['status']='failed'; report['final_guard_error']='final closure changed'
  except BaseException as final_exc:
   report['status']='failed'; report['final_guard_error']=repr(final_exc)
  report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  compare.write_json(out/'execution.json',report)
  shutil.copy2(__file__,out/'collect_resume.py')
  print(json.dumps({'status':report['status'],'resume_commands':len(commands),'runtime_attempts':len(report['runtime_rows']),'wrong_root_attempts':len(report['wrong_root_rows']),'error':report.get('error')}))
 return 0 if report['status']=='captured-pending-independent-review' else 1
if __name__=='__main__': raise SystemExit(main())
