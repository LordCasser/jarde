# v2 schema corrections and review notes

The v1 draft is preserved unchanged. The v2 reviewer uses the actual two-element JADX cell key `profile/bundle`, the resume field `first_stage_parser_error_preserved`, and the generated driver copy as the final javac source argument. It maps first-stage and resume command indices by phase because the ledgers restart numbering. It binds the actual API argv policy (`single-class` for child input and `plain-jar` for the full bundle) and the exact default/all evidence flags.

A Python-only run found and fixed the first-draft guard-field mismatch: the first-stage generated receipt has stable local-copy and external snapshots but omits separate `*_unchanged_finally` booleans for those fields. v2 requires the complete before/after/finally snapshots and the booleans actually present. The review then completed successfully on the terminal receipts.

Static loop interpretation is limited to the pinned upstream bodies. `test1` is an empty infinite `this == this` loop; `test2` is its do-while form; `test3` has a `while (true)` with an always-false `this != this` return guard. The generated runtime driver does not invoke any of them.
