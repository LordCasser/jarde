import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.HashSet;
import java.util.Set;
import java.util.Base64;

/** Loads/constructs TestEndlessLoop$TestCls and verifies method signatures; never invokes loop methods. */
public final class TestEndlessLoopDriver {
    private static final String TARGET = "jadx.tests.integration.loops.TestEndlessLoop$TestCls";
    private static final String CASE = "construct-and-method-inventory";
    private static final Set<String> EXPECTED = new HashSet<String>();
    static { EXPECTED.add("test1()V"); EXPECTED.add("test2()V"); EXPECTED.add("test3()V"); }

    private static String codeSource(Class<?> target) throws Exception {
        CodeSource source = target.getProtectionDomain().getCodeSource();
        if (source == null || source.getLocation() == null) throw new IllegalStateException("target has no CodeSource");
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }
    private static String b64(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("usage: TestEndlessLoopDriver actualRoot expectedRoot");
        String actual = Paths.get(args[0]).toRealPath().toString();
        String expected = Paths.get(args[1]).toRealPath().toString();
        PrintStream resultOut = System.out;
        ByteArrayOutputStream targetBytes = new ByteArrayOutputStream();
        PrintStream targetOut = new PrintStream(targetBytes, true, "UTF-8");
        String inventory;
        try (URLClassLoader loader = new URLClassLoader(new URL[] { Paths.get(actual).toUri().toURL() }, null)) {
            try {
                System.setOut(targetOut);
                Class<?> target = Class.forName(TARGET, true, loader);
                if (target.getClassLoader() != loader) throw new IllegalStateException("target did not load from parentless loader");
                String origin = codeSource(target);
                if (!origin.equals(expected)) throw new IllegalStateException("wrong CodeSource: expected=" + expected + " actual=" + origin);

                // The only target instance is constructed here. None of test1/test2/test3 is invoked.
                Constructor<?> constructor = target.getDeclaredConstructor();
                if (constructor.getParameterTypes().length != 0 || Modifier.isStatic(constructor.getModifiers()))
                    throw new IllegalStateException("unexpected target constructor");
                Object receiver = constructor.newInstance();
                if (receiver.getClass() != target) throw new IllegalStateException("constructed receiver has another class");

                Set<String> actualMethods = new HashSet<String>();
                Method[] methods = target.getDeclaredMethods();
                for (Method method : methods) {
                    if (method.getParameterTypes().length != 0 || method.getReturnType() != Void.TYPE || Modifier.isStatic(method.getModifiers()))
                        throw new IllegalStateException("unexpected target method shape: " + method);
                    actualMethods.add(method.getName() + "()V");
                }
                if (!actualMethods.equals(EXPECTED) || methods.length != EXPECTED.size())
                    throw new IllegalStateException("target declared method inventory differs: " + actualMethods);
                if (target.getDeclaredFields().length != 0)
                    throw new IllegalStateException("target declares fields unexpectedly");
                for (String name : new String[] { "test1", "test2", "test3" }) target.getDeclaredMethod(name);
                inventory = "<init>()V,test1()V,test2()V,test3()V";
            } finally {
                targetOut.flush();
                System.setOut(resultOut);
                targetOut.close();
            }
        }
        System.out.println("CASE index=0 name=" + CASE
                + " input_b64=" + b64("parentless-load;construct-noarg;loop-method-calls=none")
                + " result_b64=" + b64("constructed;" + inventory)
                + " exception=none exception_message_b64= exception_stack_b64="
                + " target_stdout_b64=" + b64(new String(targetBytes.toByteArray(), StandardCharsets.UTF_8)));
    }
}
