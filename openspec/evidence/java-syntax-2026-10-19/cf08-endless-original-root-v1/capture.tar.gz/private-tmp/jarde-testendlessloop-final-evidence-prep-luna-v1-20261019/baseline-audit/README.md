# TestEndlessLoop baseline audit preparation

This independent auditor is adapted from the accepted TestNotIndexedLoop audit-v3. It pins and reopens the completed baseline receipt, every nested file pin, the upstream/copy source, CLI/JADX/runtime tools, JDK manifest, compiled outer/child class trees and bundles, raw command streams, API reports and source maps. It checks all four fixed target methods are structured across eight API cells, compares the two independent physical parsers, verifies the four original VM observations and wrong-CodeSource rejection, and validates the ordinary 11-argument runtime wrapper.

The original observation is only `construct-and-method-inventory`: parentless load, constructor, and exact declared-method/field inventory. It never invokes `test1`, `test2`, or `test3`; the four rows do not establish loop runtime behavior. The raw physical facts are separately pinned to `test1` bytes `2a2aa60006a7fffbb1` and `test2`/`test3` bytes `2a2aa5fffeb1`, each with max stack 2 and max locals 1.

Preparation only: the auditor itself has not been run. Its Python source was parsed with `ast.parse`; the baseline receipt hash and four run shapes were read and checked statically. No compiler, CLI, JDK, Jarde, JADX, or network command was invoked. See `adaptation.diff` and the parent `pins.json`.
