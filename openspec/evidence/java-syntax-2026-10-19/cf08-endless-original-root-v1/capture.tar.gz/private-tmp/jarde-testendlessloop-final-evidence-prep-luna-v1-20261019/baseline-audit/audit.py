#!/usr/bin/env python3
"""Independent read-only audit of the completed TestEndlessLoop full-source baseline."""
import argparse, hashlib, importlib.util, json, zipfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
RECEIPT = Path('/private/tmp/jarde-testendlessloop-baseline-root-v1-20261019/execution.json')
RECEIPT_SHA = '02557fcf4c577ab19c02184e65f9ef8759625742b40b6a147768c6bac8484ca1'
SCHEMA = 'test-endless-loop-full-source-baseline-v1'
CLI_SHA = '96e534b0000fe91c1d34a282919479a97eb4706063501d188cdff010c4640366'
COMPARE = ROOT / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
PHYSICAL = Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
JDK_MANIFEST = ROOT / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
INTERNAL = 'jadx/tests/integration/loops/TestEndlessLoop$TestCls'
OUTER = 'jadx/tests/integration/loops/TestEndlessLoop'
METHODS = {('<init>', '()V'), ('test1', '()V'), ('test2', '()V'), ('test3', '()V')}
OUTER_METHODS = {('<init>', '()V'), ('test', '()V')}
CASES = ['construct-and-method-inventory']
EXPECTED_LOOP_CODE = {'test1': '2a2aa60006a7fffbb1', 'test2': '2a2aa5fffeb1', 'test3': '2a2aa5fffeb1'}
EXPECTED = [('parentless-load;construct-noarg;loop-method-calls=none', 'constructed;<init>()V,test1()V,test2()V,test3()V', 'none', '')]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def pin(row, label):
    if not isinstance(row, dict) or not {'path', 'bytes', 'sha256'} <= row.keys():
        raise AssertionError(f'{label}: malformed pin')
    p = Path(row['path']).resolve(strict=True)
    b = p.read_bytes()
    if len(b) != row['bytes'] or hashlib.sha256(b).hexdigest() != row['sha256']:
        raise AssertionError(f'{label}: pin mismatch: {p}')
    return p

def verify_nested_pins(value, label='receipt'):
    count = 0
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            pin(value, label)
            return 1
        for key, item in value.items():
            count += verify_nested_pins(item, f'{label}.{key}')
    elif isinstance(value, list):
        for i, item in enumerate(value):
            count += verify_nested_pins(item, f'{label}[{i}]')
    return count

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot import {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def parse_oracle(stdout):
    import base64, re
    lines = stdout.decode('utf-8', errors='strict').splitlines()
    if len(lines) != len(CASES):
        raise AssertionError(f'expected {len(CASES)} case rows, got {len(lines)}')
    pattern = re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) target_stdout_b64=([^ ]*)$')
    decode = lambda text: base64.b64decode(text, validate=True).decode('utf-8', errors='strict')
    result = []
    for i, line in enumerate(lines):
        m = pattern.fullmatch(line)
        if m is None:
            raise AssertionError(f'malformed runtime row: {line!r}')
        index, name, inp, value, exception, message, stack, target_stdout = m.groups()
        if int(index) != i or name != CASES[i]:
            raise AssertionError(f'case identity/order mismatch: {line!r}')
        result.append({'index': i, 'name': name, 'input': decode(inp), 'result': decode(value),
                       'exception_type': exception, 'exception_message': decode(message),
                       'exception_stack': decode(stack), 'target_stdout': decode(target_stdout), 'raw': line})
    return result

def json_norm(x):
    if isinstance(x, dict): return {k: json_norm(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)): return [json_norm(v) for v in x]
    return x

def utf8_boundaries(text):
    result = {0}
    offset = 0
    for char in text:
        offset += len(char.encode('utf-8'))
        result.add(offset)
    return result

def origins(segment):
    origin = segment.get('origin') or {}
    return [x for x in [origin.get('primary'), *origin.get('derived', [])] if isinstance(x, dict)]

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--receipt', type=Path, default=RECEIPT)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    receipt = args.receipt.resolve(strict=True)
    out = args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing existing output: {out}')
    require(digest(receipt) == RECEIPT_SHA, 'frozen baseline receipt SHA mismatch')
    d = json.loads(receipt.read_text(encoding='utf-8'))
    require = lambda ok, msg: (_ for _ in ()).throw(AssertionError(msg)) if not ok else None
    require(d.get('schema') == SCHEMA, 'receipt schema mismatch')
    require(d.get('status') == 'captured-pending-independent-review', 'receipt is not terminal captured data')
    require(Path(d['root']).resolve() == ROOT.resolve(), 'workspace root mismatch')
    commands = d['commands']
    byid = {x['index']: x for x in commands}
    require(len(commands) == 20 and set(byid) == set(range(1, 21)), 'command rows are not exactly 1..20')
    labels = [x['label'] for x in commands]
    require(len(set(labels)) == 20, 'command labels are duplicated')
    for row in commands:
        require(row.get('guard_stop') is None, f'command guard stopped: {row["label"]}')
        require(row.get('peak_target_bytes', 0) <= 1024**3, f'target exceeded 1 GiB: {row["label"]}')
        require(row.get('free_bytes_after', 0) >= 5*1024**3, f'free-space floor failed: {row["label"]}')
        for channel in ('stdout', 'stderr'):
            pin(row['streams'][channel], f'{row["label"]} {channel}')
    require(d['source_unchanged'] is True and d['source_unchanged_finally'] is True, 'source closure flags')
    require(d['target_absent'] is True and d['target_absent_finally'] is True, 'target absence flags')
    require(d['external_inputs_unchanged'] is True and d['local_copies_unchanged'] is True
            and d['local_copies_unchanged_finally'] is True, 'external/local closure flags')
    require(d['source_pins_before'] == d['source_pins_after'] == d['source_pins_after_finally'], 'source snapshots differ')
    require(d['external_input_pins_before'] == d['external_input_pins_after'] == d['external_input_pins_after_finally'], 'external snapshots differ')
    require(d['local_copy_pins_before'] == d['local_copy_pins_after'] == d['local_copy_pins_after_finally'], 'local-copy snapshots differ')
    pins_count = verify_nested_pins(d)
    unique_pin_paths = set()
    def collect_paths(value):
        if isinstance(value, dict):
            if {'path', 'bytes', 'sha256'} <= value.keys():
                unique_pin_paths.add(str(Path(value['path']).resolve()))
            else:
                for child in value.values(): collect_paths(child)
        elif isinstance(value, list):
            for child in value: collect_paths(child)
    collect_paths(d)
    require(digest(JDK_MANIFEST) == JDK_MANIFEST_SHA, 'JDK manifest pin mismatch')
    compare = load(COMPARE, 'endless_compare')
    physical = load(PHYSICAL, 'endless_physical')
    jdks, _jdk_record = compare.configured_jdks(JDK_MANIFEST, JDK_MANIFEST_SHA)
    source = pin(d['source'], 'upstream source')
    source_copy = pin(d['source_copy'], 'source copy')
    require(source.read_bytes() == source_copy.read_bytes(), 'complete upstream source copy differs')
    require(d['cli']['sha256'] == CLI_SHA and pin(d['cli'], 'CLI') == Path(d['cli']['path']).resolve(), 'CLI pin mismatch')
    require(pin(d['runtime_wrapper'], 'runtime wrapper') and pin(d['driver_source'], 'driver source')
            and pin(d['driver_copy'], 'driver copy'), 'driver/runtime pins missing')
    require(Path(d['driver_source']['path']).read_bytes() == Path(d['driver_copy']['path']).read_bytes(), 'driver source copy differs')
    require(d['api_method_inventory_expected'] == [['<init>', '()V'], ['test1', '()V'], ['test2', '()V'], ['test3', '()V']], 'target inventory contract mismatch')
    require(d['runtime_case_names'] == CASES, 'case names/order mismatch')

    profiles = {x['profile']: x for x in d['source_profiles']}
    require(set(profiles) == {'debug', 'no-debug'}, 'source profile grid mismatch')
    target_rel, outer_rel = INTERNAL + '.class', OUTER + '.class'
    classfacts, inventories = {}, {}
    for profile, row in profiles.items():
        require(row['exit_code'] == 0, f'{profile}: original full source compile failed')
        require(set(row['class_tree']) == {target_rel, outer_rel}, f'{profile}: full outer/child class tree mismatch')
        root = Path(row['class_root']).resolve(strict=True)
        actual_tree = {p.relative_to(root).as_posix(): {'path': str(p.resolve()), 'bytes': p.stat().st_size, 'sha256': digest(p)} for p in sorted(root.rglob('*.class'))}
        require(set(actual_tree) == set(row['class_tree']), f'{profile}: actual class tree inventory mismatch')
        for rel, rec in row['class_tree'].items():
            cp = pin(rec, f'{profile} class {rel}')
            require(cp.read_bytes() == (root / rel).read_bytes(), f'{profile}: class tree bytes differ {rel}')
            parsed = compare.parse_class(cp)
            independent = physical.parse_class_file(cp.read_bytes())
            require(parsed['class_name'] == independent['class_name'] and parsed['major'] == independent['major']
                    and parsed['methods'] == independent['methods'], f'{profile}/{rel}: independent method/Code parser mismatch')
            require(sorted((x['name'], x['descriptor'], x['access']) for x in independent['fields']) == sorted(parsed['fields']), f'{profile}/{rel}: independent field parser mismatch')
            require(independent['major'] == 52, f'{profile}/{rel}: expected release-8 major 52')
            classfacts[(profile, rel)] = (parsed, independent)
        target = row['target_facts']; outer = row['outer_facts']
        require(target['class_name'] == INTERNAL and outer['class_name'] == OUTER, f'{profile}: binary class identity mismatch')
        require(target['fields'] == [] and outer['fields'] == [], f'{profile}: unexpected original target/outer fields')
        require({(m['name'], m['descriptor']) for m in target['methods']} == METHODS, f'{profile}: target method inventory mismatch')
        require({(m['name'], m['descriptor']) for m in outer['methods']} == OUTER_METHODS, f'{profile}: outer method inventory mismatch')
        target_methods = {(m['name'], m['descriptor']): m for m in target['methods']}
        for name, code_hex in EXPECTED_LOOP_CODE.items():
            code = target_methods[(name, '()V')]['code']
            require(code['code_hex'] == code_hex and code['max_stack'] == 2 and code['max_locals'] == 1
                    and code['code_length'] == len(bytes.fromhex(code_hex)), f'{profile}/{name}: original loop Code bytes or frame limits differ')
            require(code['rows'] == [], f'{profile}/{name}: expected no exception-table rows in saved physical facts')
        # Compare complete method/field/access/Code facts to both independent parsers, not only identities.
        facts = compare.parse_class(root / target_rel)
        independent = physical.parse_class_file((root / target_rel).read_bytes())
        facts['access'] = independent['access']
        require(json_norm(facts) == json_norm(target), f'{profile}: complete target facts differ from live parsers')
        require(independent['access'] == target['access'], f'{profile}: target class access mismatch')
        outer_facts = compare.parse_class(root / outer_rel)
        outer_independent = physical.parse_class_file((root / outer_rel).read_bytes())
        outer_facts['access'] = outer_independent['access']
        require(json_norm(outer_facts) == json_norm(outer), f'{profile}: complete outer facts differ from live parsers')
        require(outer_independent['class_name'] == OUTER and outer_independent['major'] == 52, f'{profile}: outer parser identity/major mismatch')
        bundle = pin(row['bundle'], f'{profile} bundle')
        with zipfile.ZipFile(bundle) as zf:
            names = sorted(n for n in zf.namelist() if not n.endswith('/'))
            require(names == sorted(row['class_tree']), f'{profile}: bundle class inventory mismatch')
            for rel in names:
                require(zf.read(rel) == (root / rel).read_bytes(), f'{profile}: bundle bytes differ for {rel}')
        inventories[profile] = {rel: [(m['name'], m['descriptor'], m['access'], m.get('code')) for m in facts_[0]['methods']]
                                for (p, rel), facts_ in classfacts.items() if p == profile}

    # Preserve the real Java 8 harness-major boundary observation; it is not replaced by a trimmed compile.
    boundary = d.get('javac8_full_source_boundary')
    require(isinstance(boundary, dict) and boundary['command'] in byid, 'missing Java 8 full-source boundary attempt')
    boundary_cmd = byid[boundary['command']]
    require(boundary_cmd['label'] == 'javac8-full-upstream-source-boundary', 'wrong Java 8 boundary command')
    require(boundary['exit_code'] == boundary_cmd['exit_code'], 'Java 8 boundary command/result disagree')
    pin(boundary['stdout'], 'Java 8 boundary stdout'); pin(boundary['stderr'], 'Java 8 boundary stderr')

    # Four bounded constructor/inventory observations. No test method is invoked.
    runs = d['original_runtime']
    require(len(runs) == 4, 'original runtime grid must contain four constructor-only observations')
    grid = set(); projected = []
    for run in runs:
        profile, vm = run['profile'], run['runtime']; grid.add((profile, vm))
        require(run['exit_code'] == 0 and run['row_count'] == 1, f'{profile}/{vm}: runtime failed or case count differs')
        cmd = byid[run['command']]
        require(cmd['label'] == f'original-runtime-{profile}-{vm}' and cmd['exit_code'] == 0, f'{profile}/{vm}: runtime command mismatch')
        argv = cmd['argv']
        require(len(argv) == 11 and argv[1] == '-B' and argv[2] == d['runtime_wrapper']['path'] and argv[3] == '30'
                and Path(argv[4]).resolve() == Path(jdks[vm]['tools']['java']).resolve()
                and argv[5] == '-Xverify:all' and argv[6] == '-cp'
                and argv[8] == 'TestEndlessLoopDriver', f'{profile}/{vm}: ordinary wrapper/JVM argv mismatch')
        require(Path(argv[9]).resolve() == Path(run['target_root']).resolve() == Path(profiles[profile]['class_root']).resolve(), f'{profile}/{vm}: actual target root mismatch')
        require(Path(argv[10]).resolve() == Path(run['target_root']).resolve(), f'{profile}/{vm}: expected CodeSource root mismatch')
        require(run['application_classpath'] == [argv[7]], f'{profile}/{vm}: driver-only classpath differs')
        require(Path(argv[7]).resolve() == Path(d['driver_classes'][0]['path']).resolve().parent, f'{profile}/{vm}: application classpath is not only driver classes')
        stdout = pin(run['stdout'], f'{profile}/{vm} stdout').read_bytes()
        pin(run['stderr'], f'{profile}/{vm} stderr')
        parsed = parse_oracle(stdout)
        require(parsed == run['rows'], f'{profile}/{vm}: parsed runtime row differs from receipt')
        observed = [(r['input'], r['result'], r['exception_type'], r['target_stdout']) for r in parsed]
        require([r['name'] for r in parsed] == CASES and observed == EXPECTED, f'{profile}/{vm}: constructor-only oracle mismatch: {observed!r}')
        projected.append(observed)
    require(grid == {(p, vm) for p in profiles for vm in ('javac8', 'javac23')}, 'original runtime matrix is incomplete')
    require(all(x == projected[0] for x in projected), 'constructor observations differ across compiler/runtime legs')
    require(d.get('runtime_semantic_agreement') is True, 'collector constructor-observation agreement flag is false')

    wrong = d['wrong_root_control']; wc = byid[wrong['command']]
    require(wrong['exit_code'] == 1 and wrong['rejected'] is True and wc['exit_code'] == 1, 'wrong-CodeSource control did not reject')
    wa = wc['argv']
    require(len(wa) == 11 and wa[1] == '-B' and wa[2] == d['runtime_wrapper']['path'] and wa[3] == '30'
            and Path(wa[4]).resolve() == Path(jdks['javac23']['tools']['java']).resolve()
            and wa[5] == '-Xverify:all' and wa[6] == '-cp'
            and Path(wa[7]).resolve() == Path(d['driver_classes'][0]['path']).resolve().parent
            and wa[8] == 'TestEndlessLoopDriver', 'wrong-root ordinary wrapper/JVM argv mismatch')
    require(Path(wa[9]).resolve() == Path(wrong['actual_target_root']).resolve() == Path(profiles['debug']['class_root']).resolve(), 'wrong-root actual target mismatch')
    require(Path(wa[10]).resolve() == Path(wrong['expected_wrong_root']).resolve() == (Path(d['output']) / 'empty-classpath').resolve(), 'wrong-root expected root mismatch')
    require(b'wrong CodeSource:' in pin(wrong['stderr'], 'wrong-root stderr').read_bytes(), 'wrong-root rejection diagnostic absent')

    cells = d['jarde_cells']; require(len(cells) == 8, 'Jarde API grid must contain eight cells')
    selector_set = set(); api_results = {}; quality_counts = {}
    for cell in cells:
        sel = (cell['profile'], cell['input_form'], cell['evidence']); selector_set.add(sel)
        cmd = byid[cell['command']]
        require(cell['exit_code'] == 0 and cmd['exit_code'] == 0 and cmd['label'] == f'jarde-{sel[0]}-{sel[1]}-{sel[2]}', f'{sel}: API command failure/linkage')
        argv = cmd['argv']; profile = profiles[sel[0]]; target_path = Path(profile['class_root']) / target_rel
        expected_input = target_path if sel[1] == 'child' else Path(profile['bundle']['path'])
        expected_input = expected_input.resolve(strict=True)
        require(pin(cell['input'], f'{sel} API input') == expected_input, f'{sel}: API input pin/path mismatch')
        require(argv[0] == d['cli']['path'] and argv[1:3] == ['class-source', '--input'] and Path(argv[3]).resolve() == expected_input, f'{sel}: argv not bound to CLI/input')
        require(argv[argv.index('--class') + 1] == INTERNAL and argv[argv.index('--policy') + 1] == ('single-class' if sel[1] == 'child' else 'plain-jar'), f'{sel}: target/policy mismatch')
        require(argv[argv.index('--release') + 1] == '8' and argv[argv.index('--format') + 1] == 'json', f'{sel}: release/format mismatch')
        require(('--evidence' in argv and argv[argv.index('--evidence') + 1] == 'all') == (sel[2] == 'all'), f'{sel}: evidence selector mismatch')
        target_bytes = target_path.read_bytes() if sel[1] == 'child' else zipfile.ZipFile(expected_input).read(target_rel)
        report_path = pin(cell['report'], f'{sel} report'); report_bytes = report_path.read_bytes()
        require(report_bytes == pin(cmd['streams']['stdout'], f'{sel} raw API stdout').read_bytes(), f'{sel}: report differs from command stdout')
        doc = json.loads(report_bytes.decode('utf-8', 'strict'))
        whole = pin(cell['whole_source'], f'{sel} whole source').read_bytes()
        require(whole == doc['text'].encode('utf-8'), f'{sel}: whole source differs from raw report text')
        require(len(doc['methods']) == len(cell['methods']) == 4, f'{sel}: report/summary method counts differ')
        raw = {(m['item']['name']['escaped'], m['item']['descriptor']['escaped']): m for m in doc['methods']}
        summary = {(m['name'], m['descriptor']): m for m in cell['methods']}
        require(set(raw) == set(summary) == METHODS, f'{sel}: report/summary physical methods mismatch')
        physical_methods = {(m['name'], m['descriptor']): m for m in profile['target_facts']['methods']}
        for ident, method in summary.items():
            item = raw[ident]['item']; identity = item['identity']; outcome = raw[ident]['outcome']; body = outcome.get('report') or {}
            require(method['identity'] == identity and method['owner'] == identity['owner'], f'{sel}/{ident}: identity summary mismatch')
            require(method['outcome_kind'] == 'recovered' and method['quality'] == 'structured', f'{sel}/{ident}: expected all four fixed methods structured in accepted baseline')
            require(method['location'] == identity['owner']['location'] and method['variant'] == identity['owner']['variant'], f'{sel}/{ident}: origin metadata mismatch')
            require(identity['owner'] == doc['class'] and identity['owner']['class_bytes']['length'] == len(target_bytes), f'{sel}/{ident}: report class identity mismatch')
            require(identity['name'] == list(ident[0].encode()) and identity['descriptor'] == list(ident[1].encode()), f'{sel}/{ident}: identity bytes mismatch')
            require(method['outcome_kind'] == outcome['kind'] and method['quality'] == body.get('quality'), f'{sel}/{ident}: quality/outcome summary mismatch')
            require(method['raw_text'] == body.get('text') and method['source_map'] == body.get('source_map')
                    and method['fallbacks'] == body.get('fallbacks') and method['regions'] == body.get('regions'), f'{sel}/{ident}: raw report fields differ from summary')
            quality_counts[method['quality']] = quality_counts.get(method['quality'], 0) + 1
            phys = physical_methods[ident]; code = phys.get('code') or {}; bcis = set(code.get('bcis', []))
            sm = method.get('source_map'); audit = method['map_audit']
            require(audit['map_present'] == isinstance(sm, dict), f'{sel}/{ident}: map presence audit mismatch')
            if isinstance(sm, dict):
                require(isinstance(sm.get('segments'), list) and sm == body.get('source_map'), f'{sel}/{ident}: malformed or inconsistent map')
                text = method['raw_text'].encode('utf-8'); boundaries = utf8_boundaries(method['raw_text']); mapped = set()
                for seg in sm['segments']:
                    start, end = seg.get('start'), seg.get('end')
                    require(type(start) is int and type(end) is int and 0 <= start <= end <= len(text)
                            and start in boundaries and end in boundaries, f'{sel}/{ident}: invalid UTF-8 map span')
                    for origin in origins(seg):
                        require(origin.get('method') == identity, f'{sel}/{ident}: map origin method identity mismatch')
                        require(type(origin.get('bci')) is int and origin['bci'] in bcis, f'{sel}/{ident}: map origin BCI outside Code')
                        mapped.add(origin['bci'])
                require(set(audit['physical_bcis']) == bcis and set(audit['mapped_bcis']) == mapped, f'{sel}/{ident}: map audit physical census mismatch')
                require(audit['covers_all_physical_bcis'] == (mapped == bcis), f'{sel}/{ident}: map coverage flag disagrees with origins')
                if method['outcome_kind'] == 'recovered' and method['quality'] == 'structured':
                    require(audit['covers_all_physical_bcis'] is True and mapped == bcis and not audit['issues'], f'{sel}/{ident}: structured report lacks full Code map')
            else:
                require(method['outcome_kind'] != 'recovered' or method['quality'] != 'structured', f'{sel}/{ident}: structured method has no source map')
        api_results[sel] = (doc['text'], {k: (v['raw_text'], v['source_map'], v['quality'], v['outcome_kind']) for k, v in summary.items()})
    require(selector_set == {(p, form, evidence) for p in profiles for form in ('child', 'bundle-child') for evidence in ('default', 'all')}, 'Jarde API selectors incomplete')
    for profile in profiles:
        for form in ('child', 'bundle-child'):
            require(api_results[(profile, form, 'default')] == api_results[(profile, form, 'all')], f'{profile}/{form}: default/all report text/method maps differ')

    jadx_rows = d['jadx_outputs']; require(len(jadx_rows) == 2, 'JADX profile output count mismatch')
    jadx_sources = 0
    for item in jadx_rows:
        require(item['exit_code'] == 0 and item['display_profile'] == 'default', 'JADX decode failed/profile mismatch')
        cmd = byid[item['command']]
        require(cmd['exit_code'] == 0 and cmd['label'] == f"jadx-full-bundle-{item['compiler_profile']}-default", 'JADX command linkage mismatch')
        require(cmd['argv'][0] == d['jadx']['path'] and pin(item['input'], 'JADX input bundle') == Path(profiles[item['compiler_profile']]['bundle']['path']).resolve()
                and Path(cmd['argv'][-1]).resolve() == Path(item['input']['path']).resolve(), 'JADX binary/input bundle binding mismatch')
        source_pins = item['sources']; require(source_pins, 'JADX source tree is empty')
        for rec in source_pins: pin(rec, 'JADX generated source')
        dest = Path(cmd['argv'][cmd['argv'].index('-d') + 1]).resolve(strict=True)
        actual = {str(p.resolve()) for p in dest.rglob('*.java')}
        require(actual == {x['path'] for x in source_pins}, 'JADX captured source list is not complete output tree')
        require(any(Path(x['path']).name == 'TestEndlessLoop.java' for x in source_pins), 'JADX outer source missing')
        jadx_sources += len(source_pins)

    expected_labels = {'javac8-full-upstream-source-boundary', 'javac23-full-source-debug', 'javac23-full-source-no-debug', 'compile-independent-reflection-driver', 'original-runtime-debug-javac8', 'original-runtime-debug-javac23', 'original-runtime-no-debug-javac8', 'original-runtime-no-debug-javac23', 'driver-code-source-wrong-root-control', 'jadx-version'}
    expected_labels |= {f'jarde-{p}-{f}-{e}' for p in profiles for f in ('child', 'bundle-child') for e in ('default', 'all')}
    expected_labels |= {f'jadx-full-bundle-{p}-default' for p in profiles}
    require(set(labels) == expected_labels, 'command labels do not match the complete baseline plan')
    require(d['counts_derived_from_commands']['commands'] == 20 and d['counts_derived_from_commands']['raw_streams'] == 40, 'derived command/raw stream counts mismatch')
    # Tie each execution tool and compilation mode to its declared command, without invoking tools.
    for profile, row in profiles.items():
        compile_cmd = byid[row['command']]
        expected_debug = '-g' if profile == 'debug' else '-g:none'
        require(compile_cmd['label'] == f'javac23-full-source-{profile}'
                and Path(compile_cmd['argv'][0]).resolve() == Path(jdks['javac23']['tools']['javac']).resolve()
                and '--release' in compile_cmd['argv']
                and compile_cmd['argv'][compile_cmd['argv'].index('--release') + 1] == '8'
                and expected_debug in compile_cmd['argv'] and d['source_copy']['path'] in compile_cmd['argv'], f'{profile}: full-source javac argv mismatch')
    driver_compile = byid[d['driver_compile']['command']]
    require(driver_compile['label'] == 'compile-independent-reflection-driver'
            and Path(driver_compile['argv'][0]).resolve() == Path(jdks['javac8']['tools']['javac']).resolve()
            and d['driver_copy']['path'] in driver_compile['argv'], 'driver compile argv/source mismatch')
    require(len(d['driver_class_summaries']) == 1 and d['driver_class_summaries'][0]['class_name'] == 'TestEndlessLoopDriver', 'single driver class identity mismatch')
    driver_text = Path(d['driver_copy']['path']).read_text(encoding='utf-8')
    for token in ('new URLClassLoader(new URL[] { Paths.get(actual).toUri().toURL() }, null)', 'target.getClassLoader() != loader', 'wrong CodeSource:', 'constructor.newInstance()', 'getDeclaredMethods()', 'getDeclaredFields()'):
        require(token in driver_text, f'driver source lacks required isolation/inventory check: {token}')
    require('.invoke(' not in driver_text, 'driver appears to invoke a nonterminating loop method')
    version_cmd = next(x for x in commands if x['label'] == 'jadx-version')
    require(version_cmd['argv'][0] == d['jadx']['path'] and version_cmd['argv'][1:] == ['--version'], 'JADX version command argv mismatch')
    require(not (ROOT / 'target').exists() and not (ROOT / 'target').is_symlink(), 'workspace target exists at audit time')

    result = {
        'receipt': str(receipt), 'receipt_sha256': digest(receipt), 'schema': SCHEMA,
        'commands': len(commands), 'raw_streams': 40, 'unique_pinned_paths': len(unique_pin_paths), 'pin_records_reopened': pins_count,
        'source_profiles': sorted(profiles), 'physical_class_methods': {k: [list(x[:3]) for x in v[target_rel]] for k, v in inventories.items()},
        'original_vm_runs': 4, 'case_observations': 4, 'runtime_scope': 'constructor and method inventory only; loop methods are never invoked', 'manual_oracle_matches': True,
        'api_cells': 8, 'api_method_rows': len(cells := d['jarde_cells']) * 4,
        'api_quality_counts': quality_counts, 'default_all_text_and_raw_maps_equal': True,
        'jadx_outputs': len(jadx_rows), 'jadx_source_files': jadx_sources,
        'wrong_root_rejected': True, 'source_external_local_pins_reopened': len(unique_pin_paths), 'pin_records_reopened': pins_count,
        'scope': 'baseline integrity check and constructor-only runtime observation; never executes the three nonterminating test methods',
    }
    out.mkdir(parents=True, exist_ok=False)
    (out / 'review.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    (out / 'README.md').write_text('Private read-only TestEndlessLoop baseline audit. Runtime evidence is limited to class load, construction, and the exact declared-method inventory. It does not invoke test1/test2/test3 or claim loop-runtime equivalence. The auditor invokes no compiler, CLI, or network command.\n', encoding='utf-8')
    return result

if __name__ == '__main__':
    print(json.dumps(main(), indent=2, sort_keys=True))
