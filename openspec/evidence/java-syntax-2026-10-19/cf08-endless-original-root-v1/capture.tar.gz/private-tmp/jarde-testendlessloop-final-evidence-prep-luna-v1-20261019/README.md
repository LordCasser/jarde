# TestEndlessLoop evidence preparation

This private package prepares two independent evidence steps for the accepted full-source baseline at `/private/tmp/jarde-testendlessloop-baseline-root-v1-20261019/execution.json` (SHA-256 `02557fcf4c577ab19c02184e65f9ef8759625742b40b6a147768c6bac8484ca1`). The baseline had 20 commands/40 raw streams, 8 Jarde API cells covering four structured methods, two complete JADX output trees, and four bounded constructor/inventory observations.

`baseline-audit/audit.py` is the independent receipt auditor. `generated/collect_generated_matrix.py` is a full-source generated compiler/runtime collector that requires the accepted baseline path and digest explicitly. Both retain compiler/JADX failures as evidence and preserve source, bundle, CLI/JADX/JDK, physical Code/BCI, raw report/map, guard-stop, wrong-CodeSource, and workspace-target checks. The generated driver source is copied unchanged from the frozen baseline preparation.

The three target methods are statically nonterminating for the accepted originals; the generated driver never calls them. The only runtime observation is load/construct/method inventory. The generated collector compares loop code and control metadata from classfiles without executing those methods. This is not loop runtime equivalence.

No auditor, compiler, CLI, JDK, Jarde, JADX, or network command was run for this preparation. The two scripts passed Python AST parsing; the receipt SHA, runtime row count/argv lengths, fixed class identities, and source/driver pins were inspected. Root review and actual execution remain pending. See `pins.json` and the two `adaptation.diff` files.
