# TestEndlessLoop generated-source collector preparation

This collector adapts the accepted TestLoopCondition2 generated-source collector. It binds to the completed EndlessLoop baseline by exact path and SHA, keeps every Jarde child source and every file in each full JADX source tree byte-for-byte, and compiles the eight Jarde API source cells plus two complete JADX source profiles with the existing JDK 8 and JDK 23 Java 8-target compiler legs. Full-source compiler failures remain raw outcomes; no source is shortened or patched.

A successful generated target must have the exact original class, method, access and field inventory before it receives runtime rows. Its one row observes class loading, constructor behavior, and declared-method inventory only. The collector checks the actual source has no reflective method invocation. It never calls any of the three nonterminating loop methods and makes no runtime-equivalence claim about them.

For each eligible generated target, the collector additionally records a static classfile comparison for `test1()V`, `test2()V`, and `test3()V`: exact Code bytes, max stack/locals, method flags, and exception rows are compared with the same-profile original. The frozen original bytes are asserted as `2a2aa60006a7fffbb1`, `2a2aa5fffeb1`, and `2a2aa5fffeb1`. A mismatch is recorded per method and does not cause source alteration or a loop invocation.

The collector has not been run. Only Python AST parsing and static receipt/source inspection were done. It retains the accepted JDK, CLI, parser, size guard, source-closure, raw-stream, driver-only classpath, and wrong-CodeSource checks. See `adaptation.diff`, `driver/`, and the parent `pins.json`.
