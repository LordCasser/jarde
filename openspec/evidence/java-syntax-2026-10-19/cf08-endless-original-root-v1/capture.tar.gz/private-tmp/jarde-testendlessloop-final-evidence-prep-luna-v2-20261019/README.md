# TestEndlessLoop audit fix v2

This preserves v1 and changes only the placement of the exact receipt SHA assertion: it now follows the local `require` binding. The generated collector remains unchanged at SHA-256 `a67404e5179b668de09a44924c8dec68b0e3e1fe1a9e2185913bae93db8ad39d`.

The Python-only trial completed successfully against the frozen receipt SHA `02557fcf4c577ab19c02184e65f9ef8759625742b40b6a147768c6bac8484ca1`. It reopened 13603 pin records across 4273 unique paths and validated 20 commands/40 streams, 8 API cells/32 structured method rows, four constructor-only VM observations, both source profiles, two JADX outputs, and wrong-CodeSource rejection. The three loop methods were not invoked.

Trial output: `trial/review.json`. No compiler, JDK, CLI, Jarde, JADX, network, or Git command was run.
