package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestEndlessLoop.class */
public class TestEndlessLoop extends IntegrationTest {

    /* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestEndlessLoop$TestCls.class */
    public static class TestCls {
        void test1() {
            while (this == this) {
            }
        }

        void test2() {
            while (this == this) {
            }
        }

        void test3() {
            while (this == this) {
            }
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().contains(new CharSequence[]{"while (this == this)"});
    }
}
