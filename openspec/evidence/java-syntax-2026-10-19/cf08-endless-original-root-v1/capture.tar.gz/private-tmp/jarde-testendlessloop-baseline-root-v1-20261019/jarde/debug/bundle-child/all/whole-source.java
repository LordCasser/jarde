// jarde: presentation of `jadx/tests/integration/loops/TestEndlessLoop$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestEndlessLoop$TestCls extends java.lang.Object {
    public TestEndlessLoop$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestEndlessLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    void test1() {
        // @method test1()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestEndlessLoop$TestCls`, member flags 0x0000
        // recovered from bytecode; presentation is not claimed to compile
        while (this == this) {
        }
        return;
    }

    void test2() {
        // @method test2()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestEndlessLoop$TestCls`, member flags 0x0000
        // recovered from bytecode; presentation is not claimed to compile
        do {
        } while (this == this);
        return;
    }

    void test3() {
        // @method test3()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestEndlessLoop$TestCls`, member flags 0x0000
        // recovered from bytecode; presentation is not claimed to compile
        do {
        } while (this == this);
        return;
    }
}
