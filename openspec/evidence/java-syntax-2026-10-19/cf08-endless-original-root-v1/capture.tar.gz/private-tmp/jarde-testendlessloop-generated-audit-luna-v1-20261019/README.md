# TestEndlessLoop generated-output reviewer

This private reviewer is prepared for the frozen original, generated-matrix, and resume receipts. It is independent of the collectors and reopens every referenced pin and raw stream. It was only syntax-checked; the reviewer itself has **not** been run. Root should run it after reviewing the script.

Run from any directory with Python, using a fresh output path:

```sh
python3 -B /private/tmp/jarde-testendlessloop-generated-audit-luna-v1-20261019/review_endless.py \
  --resume /private/tmp/jarde-testendlessloop-generated-resume-root-v1-20261019/execution.json \
  --resume-sha256 a1a69edf087195aed6193c986cb9bc59c6aad5d09d2ff5ade002765e93b898f9 \
  --out /private/tmp/jarde-testendlessloop-generated-audit-root-v1-20261019
```

The reviewer binds the baseline receipt and root audit, the 24-command first-stage receipt, and the 51-command resume receipt. It requires the exact 10 source cells, 20 whole-source compile attempts, 18 successful independent physical reparses, 36 constructor/inventory-only VM rows, and 18 wrong-CodeSource controls. It retains the two JDK 8 major-55 framework failures without VM rows and checks the historical first-stage parser errors rather than erasing them. API evidence, source-copy identity, class inventories, method Code/BCIs, UTF-8 source-map spans, runtime wrapper argv, raw streams, resource guards, source/external/local-output snapshots, and target absence are all checked.

The static loop comparison is deliberately separated from runtime claims. `test1`/`test2`/`test3` are never invoked by the constructor-only driver. Jarde’s three loop Code arrays are checked against the originals; JADX’s `test2`/`test3` have the recorded 9-byte `while` shape instead of the original 6-byte `do-while` shape. The source conditions are identity comparisons with no loop-body effects, but this reviewer claims neither loop execution nor frame-attribute byte equality.

The three receipts are terminal captures, not by themselves product acceptance. This script only produces an independent audit result; it does not run JDKs, javac, Jarde, JADX, or Cargo. Pins and this script’s SHA-256 are in `pins.json`.
