#!/usr/bin/env python3
"""Independent read-only review of TestEndlessLoop generated outputs plus resume observations."""
from __future__ import annotations
import argparse, base64, hashlib, importlib.util, json, re, zipfile
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
BASELINE=Path('/private/tmp/jarde-testendlessloop-baseline-root-v1-20261019/execution.json')
BASELINE_SHA='02557fcf4c577ab19c02184e65f9ef8759625742b40b6a147768c6bac8484ca1'
BASE_SCHEMA='test-endless-loop-full-source-baseline-v1'
GENERATED=Path('/private/tmp/jarde-testendlessloop-generated-root-v1-20261019/execution.json')
GENERATED_SHA='27be145c76230439dd449458d0bd20077c41e2968b8af25165b9e99e6439157e'
GENERATED_SCHEMA='test-endless-loop-generated-source-matrix-v1'
RESUME_SCHEMA='test-endless-loop-generated-source-resume-v1'
BASE_AUDIT=Path('/private/tmp/jarde-testendlessloop-baseline-audit-root-v1-20261019/review.json')
BASE_AUDIT_SHA='982da57a6478a485a51e350e5a6c2c568508c5e04f82020cf8051559a0c45512'
COMPARE=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
PHYSICAL=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PHYSICAL_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
JDK_MANIFEST=ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
INTERNAL='jadx/tests/integration/loops/TestEndlessLoop$TestCls'
OUTER='jadx/tests/integration/loops/TestEndlessLoop'
DRIVER='TestEndlessLoopDriver'
PROFILES=('debug','no-debug'); FORMS=('child','bundle-child'); EVIDENCE=('default','all')
LEGS=('javac8','javac23'); VMS=('javac8','javac23')
METHODS={('<init>','()V'),('test1','()V'),('test2','()V'),('test3','()V')}
OUTER_METHODS={('<init>','()V'),('test','()V')}
EXPECTED_LOOP_CODE={'test1':'2a2aa60006a7fffbb1','test2':'2a2aa5fffeb1','test3':'2a2aa5fffeb1'}
JADX_LOOP_CODE={'test1':'2a2aa60006a7fffbb1','test2':'2a2aa60006a7fffbb1','test3':'2a2aa60006a7fffbb1'}
CASE='construct-and-method-inventory'
EXPECTED_OBSERVATION=('parentless-load;construct-noarg;loop-method-calls=none','constructed;<init>()V,test1()V,test2()V,test3()V','none','')
ACTIVE={'running','in_progress','started','collecting'}


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(ok,msg):
    if not ok: raise AssertionError(msg)
def norm(x):
    if isinstance(x,dict): return {k:norm(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [norm(v) for v in x]
    return x
def pin(row,label):
    require(isinstance(row,dict) and {'path','bytes','sha256'}<=row.keys(),f'{label}: malformed pin')
    path=Path(row['path']).resolve(strict=True); data=path.read_bytes()
    require(len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],f'{label}: changed pin {path}')
    return path
def all_pins(value,label='receipt'):
    count=0; unique=set()
    if isinstance(value,dict):
        if {'path','bytes','sha256'}<=value.keys():
            path=pin(value,label); return 1,{str(path)}
        for k,v in value.items():
            n,paths=all_pins(v,f'{label}.{k}'); count+=n; unique|=paths
    elif isinstance(value,list):
        for i,v in enumerate(value):
            n,paths=all_pins(v,f'{label}[{i}]'); count+=n; unique|=paths
    return count,unique
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot import {path}')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def parse_rows(raw):
    rx=re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) target_stdout_b64=([^ ]*)$')
    lines=raw.decode('utf-8','strict').splitlines(); require(len(lines)==1,'expected exactly one constructor-only output row')
    m=rx.fullmatch(lines[0]); require(m is not None,'malformed constructor-only output')
    idx,name,inp,res,exc,msg,stack,out=m.groups(); require(idx=='0' and name==CASE,'unexpected case identity')
    dec=lambda x:base64.b64decode(x,validate=True).decode('utf-8','strict')
    return [{'index':0,'name':name,'input':dec(inp),'result':dec(res),'exception_type':exc,'exception_message':dec(msg),
             'exception_stack':dec(stack),'target_stdout':dec(out),'raw':lines[0]}]
def projection(rows):
    return [{k:r[k] for k in ('index','name','input','result','exception_type','target_stdout')} for r in rows]
def parsed_class(compare,physical,path,label):
    c=compare.parse_class(path); p=physical.parse_class_file(path.read_bytes())
    require(c['class_name']==p['class_name'] and c['major']==p['major'] and c['methods']==p['methods'],f'{label}: parser method/Code disagreement')
    require(sorted((x['name'],x['descriptor'],x['access']) for x in p['fields'])==sorted(c['fields']),f'{label}: parser field disagreement')
    c['access']=p['access']; return c,p
def tree_files(compare,root):
    root=Path(root).resolve(strict=True)
    return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*.class'))}
def expected_loop_code(profile,method,code):
    if profile=='jadx': return JADX_LOOP_CODE[method]
    return EXPECTED_LOOP_CODE[method]
def check_code_facts(parsed,profile,label):
    by={(m['name'],m['descriptor']):m for m in parsed['methods']}
    require(set(by)==METHODS,f'{label}: exact target method inventory mismatch')
    require(parsed['fields']==[],f'{label}: unexpected target fields')
    report={}
    for name,oldhex in EXPECTED_LOOP_CODE.items():
        m=by[(name,'()V')]; code=m.get('code') or {}
        newhex=code.get('code_hex'); require(newhex is not None,f'{label}/{name}: missing physical Code')
        bcis=code.get('bcis',[])
        require(bcis and bcis[0]==0 and bcis==sorted(set(bcis)) and bcis[-1]<code.get('code_length',0),f'{label}/{name}: malformed generated BCI inventory')
        if profile=='jarde':
            # The primary identity is the complete physical Code tuple; frames are outside this parser contract.
            exact=(newhex==oldhex and code.get('code_length')==len(bytes.fromhex(oldhex))
                   and code.get('rows')==[] and code.get('max_stack')==2 and code.get('max_locals')==1)
            require(exact,f'{label}/{name}: Jarde source compilation changed physical loop Code/limits/handlers')
        else:
            expected=JADX_LOOP_CODE[name]
            require(newhex==expected and code.get('code_length')==9 and code.get('rows')==[]
                    and code.get('max_stack')==2 and code.get('max_locals')==1,
                    f'{label}/{name}: JADX code shape differs from the recorded static lowering')
        report[name]={'original_code_hex':oldhex,'generated_code_hex':newhex,'original_code_length':len(bytes.fromhex(oldhex)),
                      'generated_code_length':code['code_length'],'byte_identical':newhex==oldhex,
                      'method_access':m['access'],'max_stack':code['max_stack'],'max_locals':code['max_locals'],'exception_rows':code['rows']}
    if profile=='jarde': require(all(x['byte_identical'] for x in report.values()),f'{label}: Jarde loop Code must match original')
    else:
        require(not report['test2']['byte_identical'] and not report['test3']['byte_identical'],f'{label}: expected recorded JADX test2/test3 lowering differences')
    return report


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--baseline',type=Path,default=BASELINE)
    ap.add_argument('--generated',type=Path,default=GENERATED)
    ap.add_argument('--resume',type=Path,required=True,help='terminal generated-resume execution.json')
    ap.add_argument('--resume-sha256',required=True,help='SHA supplied after resume receipt freezes')
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args(); bp=args.baseline.resolve(strict=True); gp=args.generated.resolve(strict=True); rp=args.resume.resolve(strict=True); out=args.out.resolve()
    require(not out.exists(),'refuse existing review output')
    require(bp==BASELINE.resolve() and sha(bp)==BASELINE_SHA,'baseline path/SHA mismatch')
    require(gp==GENERATED.resolve() and sha(gp)==GENERATED_SHA,'generated first-stage path/SHA mismatch')
    require(sha(rp)==args.resume_sha256 and len(args.resume_sha256)==64,'resume receipt SHA argument mismatch')
    baseline=json.loads(bp.read_text(encoding='utf-8')); generated=json.loads(gp.read_text(encoding='utf-8')); resume=json.loads(rp.read_text(encoding='utf-8'))
    require(baseline.get('schema')==BASE_SCHEMA and baseline.get('status')=='captured-pending-independent-review','baseline schema/status mismatch')
    require(generated.get('schema')==GENERATED_SCHEMA and generated.get('status')=='captured-pending-independent-review','first-stage generated receipt schema/status mismatch')
    require(resume.get('schema')==RESUME_SCHEMA and resume.get('status')=='captured-pending-independent-review','resume receipt schema/status mismatch')
    require(Path(baseline['root']).resolve()==ROOT.resolve() and Path(generated['root']).resolve()==ROOT.resolve() and Path(resume['root']).resolve()==ROOT.resolve(),'workspace identity mismatch')
    require(generated.get('baseline_sha256_argument')==BASELINE_SHA and pin(generated['baseline_receipt'],'generated baseline pin')==bp,'generated receipt not bound to accepted baseline')
    require(resume.get('first_stage_sha256')==GENERATED_SHA and pin(resume['first_stage_receipt'],'resume first-stage receipt')==gp,'resume not bound to first-stage generated receipt')
    require(resume.get('original_baseline_sha256')==BASELINE_SHA and pin(resume['original_baseline_receipt'],'resume baseline receipt')==bp,'resume not bound to baseline')
    require(baseline.get('cli',{}).get('sha256')=='96e534b0000fe91c1d34a282919479a97eb4706063501d188cdff010c4640366','frozen CLI pin mismatch')
    cli_path=pin(baseline['cli'],'frozen CLI')
    require(sha(cli_path)=='96e534b0000fe91c1d34a282919479a97eb4706063501d188cdff010c4640366','frozen CLI content changed')
    require(baseline['cli'] in generated.get('external_pins_before',[]),'first-stage generated capture does not pin baseline CLI')
    require(BASE_AUDIT.is_file() and json.loads(BASE_AUDIT.read_text())['receipt_sha256']==BASELINE_SHA,'accepted baseline audit no longer binds the receipt')
    require(sha(BASE_AUDIT)==BASE_AUDIT_SHA,'accepted baseline audit pin changed')
    require(not (ROOT/'target').exists() and not (ROOT/'target').is_symlink(),'workspace target exists at review time')
    compare=load(COMPARE,'endless_generated_compare'); physical=load(PHYSICAL,'endless_generated_physical')
    require(sha(COMPARE)==COMPARE_SHA and sha(PHYSICAL)==PHYSICAL_SHA,'pinned parser/helper changed')
    require(sha(JDK_MANIFEST)==JDK_SHA,'JDK manifest pin changed')
    jdks,_=compare.configured_jdks(JDK_MANIFEST,JDK_SHA)
    # Reopen receipt pins and stable guard snapshots; the resume may alter only its own runtime evidence.
    base_pin_count,base_paths=all_pins(baseline,'baseline'); gen_pin_count,gen_paths=all_pins(generated,'first-stage'); res_pin_count,res_paths=all_pins(resume,'resume')
    for d,label,flags,snapshots in (
        (generated,'first-stage',('source_unchanged','source_unchanged_finally','external_inputs_unchanged','generated_outputs_unchanged','generated_outputs_unchanged_finally','local_copies_unchanged','local_copies_unchanged_finally','target_absent','target_absent_finally'),
         (('source_pins_before','source_pins_after','source_pins_after_finally'),('external_pins_before','external_pins_after','external_pins_after_finally'),('dependency_directory_pins_before','dependency_directory_pins_after','dependency_directory_pins_after_finally'),('generated_output_pins_before','generated_output_pins_after','generated_output_pins_after_finally'),('local_copies_before','local_copies_after','local_copies_after_finally'))),
        (resume,'resume',('source_unchanged','source_unchanged_finally','external_inputs_unchanged','external_inputs_unchanged_finally','prior_generated_outputs_unchanged','prior_generated_outputs_unchanged_finally','local_copies_unchanged','local_copies_unchanged_finally','target_absent','target_absent_finally'),
         (('source_pins_before','source_pins_after','source_pins_after_finally'),('external_pins_before','external_pins_after','external_pins_after_finally'),('prior_generated_output_pins','prior_generated_output_pins_after','prior_generated_output_pins_after_finally'),('runtime_wrapper_copy','runtime_wrapper_copy_after','runtime_wrapper_copy_after_finally')))):
        for flag in flags: require(d.get(flag) is True,f'{label}: guard flag false: {flag}')
        for keys in snapshots:
            vals=[d.get(k) for k in keys]; require(all(v is not None for v in vals) and vals[0]==vals[1]==vals[2],f'{label}: closure snapshot drift {keys}')
    require(generated['counts_derived']=={'source_cells':10,'jarde_api_cells':8,'jadx_source_cells':2,'compile_attempts':20,'compile_successes':18,'compile_failures':2,'runtime_attempts':2,'wrong_root_attempts':1,'commands':24,'raw_streams':48},'first-stage captured totals changed')
    require(resume['counts_derived'].get('resume_target_count')==17 and resume['counts_derived'].get('runtime_attempts')==34
            and resume['counts_derived'].get('wrong_root_attempts')==17 and resume['counts_derived'].get('resume_commands')==51
            and resume['counts_derived'].get('combined_actual_commands')==75,'resume derived totals differ from expected missing-target completion')

    # Check all command pins, guards, capture argv and actual raw streams for the three captured phases.
    gcmd={x['index']:x for x in generated['commands']}; rcmd={x['index']:x for x in resume['commands']}; bcmd={x['index']:x for x in baseline['commands']}
    require(len(bcmd)==20 and set(bcmd)==set(range(1,21)),'baseline command ledger incomplete')
    require(len(gcmd)==24 and set(gcmd)==set(range(1,25)),'first-stage generated command ledger incomplete')
    require(len(rcmd)==51 and set(rcmd)==set(range(1,52)),'resume command ledger incomplete')
    for commands,label in ((baseline['commands'],'baseline'),(generated['commands'],'first-stage'),(resume['commands'],'resume')):
        for row in commands:
            require(row.get('guard_stop') is None and row.get('argv') and row.get('exit_code') is not None,f'{label}/{row.get("index")}: incomplete command')
            require(isinstance(row.get('peak_target_bytes'),int) and row['peak_target_bytes']<=1024**3,f'{label}/{row["index"]}: 1GiB guard')
            require(isinstance(row.get('free_bytes_after'),int) and row['free_bytes_after']>=5*1024**3,f'{label}/{row["index"]}: 5GiB guard')
            require(row.get('env_overrides')=={'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','RUST_TEST_THREADS':'1','CARGO_TERM_COLOR':'always'},f'{label}/{row["index"]}: sanitized execution environment changed')
            require(Path(row.get('cwd','')).resolve()==ROOT.resolve(),f'{label}/{row["index"]}: command cwd changed')
            for ch in ('stdout','stderr'): pin(row['streams'][ch],f'{label}/{row["index"]}/{ch}')
    # Baseline original class/facts and source closure are accepted only under the root audit-v1 receipt binding.
    require(json.loads(BASE_AUDIT.read_text())['commands']==20 and json.loads(BASE_AUDIT.read_text())['api_cells']==8
            and json.loads(BASE_AUDIT.read_text())['api_method_rows']==32 and json.loads(BASE_AUDIT.read_text())['api_quality_counts']=={'structured':32},'baseline root audit summary mismatch')
    source=pin(baseline['source'],'upstream source'); source_copy=pin(baseline['source_copy'],'baseline source copy')
    require(source.read_bytes()==source_copy.read_bytes() and sha(source)=='a8b077628d7d84d1dd69e51ae2cf0de62210b3f0753461f2c85b0fca829b5df5','baseline complete upstream source changed')
    source_text=source.read_text(encoding='utf-8')
    compact_source=' '.join(source_text.split())
    exact_loop_sources=('void test1() { while (this == this) { } }',
                        'void test2() { do { } while (this == this); }',
                        'void test3() { while (true) { if (this != this) { return; } } }')
    require(all(fragment in compact_source for fragment in exact_loop_sources),'source identity-loop bodies/conditions changed')
    # Original full source profiles and complete class inventory, independently parsed.
    original_profiles={x['profile']:x for x in baseline['source_profiles']}; require(set(original_profiles)==set(PROFILES),'baseline source profiles incomplete')
    original_facts={}
    for profile,row in original_profiles.items():
        require(row['exit_code']==0 and set(row['class_tree'])=={INTERNAL+'.class',OUTER+'.class'},f'{profile}: original outer/child tree incomplete')
        root=Path(row['class_root']).resolve(strict=True); actual=tree_files(compare,root)
        require(actual==row['class_tree'],f'{profile}: original physical tree pins changed')
        for rel,rec in row['class_tree'].items():
            path=pin(rec,f'{profile}/{rel}'); parsed,phys=parsed_class(compare,physical,path,f'{profile}/{rel}')
            for method in parsed['methods']:
                code=method.get('code') or {}; bcis=code.get('bcis',[])
                require(code.get('code_length',0)>0 and bcis and bcis[0]==0 and bcis==sorted(set(bcis)) and bcis[-1]<code['code_length'],f'{profile}/{rel}/{method["name"]}: invalid physical Code/BCI list')
            require(phys['major']==52 and parsed['class_name']==(INTERNAL if rel==INTERNAL+'.class' else OUTER),f'{profile}/{rel}: original binary facts mismatch')
            expected_methods=METHODS if rel==INTERNAL+'.class' else OUTER_METHODS
            require({(m['name'],m['descriptor']) for m in parsed['methods']}==expected_methods,f'{profile}/{rel}: original method inventory mismatch')
            if rel==INTERNAL+'.class':
                require(parsed['fields']==[],f'{profile}: unexpected original target fields')
                for n,h in EXPECTED_LOOP_CODE.items():
                    cd=next(m['code'] for m in parsed['methods'] if m['name']==n)
                    require(cd['code_hex']==h and cd['code_length']==len(bytes.fromhex(h)) and cd['rows']==[],f'{profile}/{n}: original loop Code baseline mismatch')
                original_facts[profile]=parsed
        bundle=pin(row['bundle'],f'{profile} full source bundle')
        with zipfile.ZipFile(bundle) as z:
            names=sorted(n for n in z.namelist() if not n.endswith('/'))
            require(names==sorted(row['class_tree']),f'{profile}: original JAR class inventory mismatch')
            for rel in names: require(z.read(rel)==Path(row['class_tree'][rel]['path']).read_bytes(),f'{profile}/{rel}: bundle bytes mismatch')
    # Four finite observations only exercise load/initialization/construction and method inventory.
    oracles={}
    for row in baseline['original_runtime']:
        cmd=bcmd[row['command']]; raw=pin(row['stdout'],'baseline runtime stdout').read_bytes()
        require(row['exit_code']==cmd['exit_code']==0 and row['row_count']==1,f'{row["profile"]}/{row["runtime"]}: constructor run failed')
        parsed=parse_rows(raw); require(parsed==row['rows'],'baseline runtime stdout/row mismatch')
        got=(parsed[0]['input'],parsed[0]['result'],parsed[0]['exception_type'],parsed[0]['target_stdout'])
        require(got==EXPECTED_OBSERVATION,'baseline finite constructor oracle mismatch')
        require((parsed[0]['input'],parsed[0]['result'],parsed[0]['exception_type'],parsed[0]['target_stdout'])==EXPECTED_OBSERVATION,'loop method invocation is forbidden by the observation contract')
        oracles[(row['profile'],row['runtime'])]=projection(parsed)
    require(set(oracles)=={(p,v) for p in PROFILES for v in VMS},'original observation grid incomplete')
    baseline_wrong=baseline.get('wrong_root_control',{}); require(baseline_wrong.get('rejected') is True and baseline_wrong.get('exit_code')==1,'baseline wrong-root rejection missing')
    wrong_cmd=bcmd[baseline_wrong['command']]
    base_wrapper=pin(baseline['runtime_wrapper'],'baseline bounded runtime wrapper')
    wrong_argv=wrong_cmd['argv']
    require(wrong_cmd['exit_code']==1 and len(wrong_argv)==11 and wrong_argv[1]=='-B'
            and Path(wrong_argv[2]).resolve()==base_wrapper and wrong_argv[3]=='30'
            and Path(wrong_argv[4]).resolve()==Path(jdks['javac23']['tools']['java']).resolve()
            and wrong_argv[5:9]==['-Xverify:all','-cp',str(Path(baseline['driver_classes'][0]['path']).resolve().parent),DRIVER]
            and Path(wrong_argv[9]).resolve()==Path(baseline_wrong['actual_target_root']).resolve()
            and Path(wrong_argv[10]).resolve()==Path(baseline_wrong['expected_wrong_root']).resolve()
            and Path(baseline_wrong['expected_wrong_root']).resolve()!=Path(baseline_wrong['actual_target_root']).resolve(), 'baseline wrong-root command roots/argv mismatch')
    wrong_err=pin(baseline_wrong['stderr'],'baseline wrong-root stderr').read_bytes()
    require(wrong_err==pin(wrong_cmd['streams']['stderr'],'baseline wrong-root raw stderr').read_bytes() and b'wrong CodeSource:' in wrong_err, 'baseline wrong-root diagnostic/raw evidence mismatch')
    boundary=baseline.get('javac8_full_source_boundary',{})
    require(boundary.get('exit_code')!=0 and boundary.get('major_55_diagnostic_observed') is True,'baseline JDK8 full-source boundary absent')
    boundary_err=pin(boundary.get('stderr'),'baseline framework boundary stderr').read_bytes()
    require(b'55.0' in boundary_err and b'52.0' in boundary_err,'baseline JDK8 boundary is not the recorded major-55/52 mismatch')

    # Baseline raw API output is preserved across default/all for every selector, with maps tied to physical BCIs.
    old_cells={(x['profile'],x['input_form'],x['evidence']):x for x in baseline['jarde_cells']}
    require(len(old_cells)==8 and set(old_cells)=={(p,f,e) for p in PROFILES for f in FORMS for e in EVIDENCE},'baseline API grid incomplete')
    require(len([x for x in baseline['commands'] if x['label'].startswith('class-source-')])==8,'baseline CLI command inventory mismatch')
    api_values={}; api_method_rows=0
    for sel,cell in old_cells.items():
        cmd=bcmd[cell['command']]; report_bytes=pin(cell['report'],f'{sel} report').read_bytes()
        require(cmd['exit_code']==cell['exit_code']==0 and report_bytes==pin(cmd['streams']['stdout'],f'{sel} raw report').read_bytes(),f'{sel}: report/raw stdout mismatch')
        doc=json.loads(report_bytes.decode('utf-8','strict')); whole=pin(cell['whole_source'],f'{sel} whole source').read_bytes()
        require(whole==doc['text'].encode('utf-8'),f'{sel}: whole source differs from raw report')
        api_argv=cmd['argv']; api_input=pin(cell['input'],f'{sel} CLI input')
        require(Path(api_argv[0]).resolve()==Path(baseline['cli']['path']).resolve() and api_argv[1:3]==['class-source','--input']
                and Path(api_argv[3]).resolve()==api_input and api_argv[4:6]==['--class',INTERNAL]
                and api_argv[6:8]==['--policy','single-class' if sel[1]=='child' else 'plain-jar']
                and api_argv[8:10]==['--release','8'] and api_argv[10:12]==['--format','json'],f'{sel}: CLI argv/input policy mismatch')
        require((api_argv[12:]==[] if sel[2]=='default' else api_argv[12:]==['--evidence','all']),f'{sel}: CLI evidence argv mismatch')
        if sel[1]=='child':
            require(api_input==Path(original_profiles[sel[0]]['class_tree'][INTERNAL+'.class']['path']).resolve(),f'{sel}: CLI input is not the accepted original target class')
        else:
            require(api_input==Path(original_profiles[sel[0]]['bundle']['path']).resolve(),f'{sel}: CLI bundle input is not the accepted full original class bundle')
        raw={(m['item']['name']['escaped'],m['item']['descriptor']['escaped']):m for m in doc['methods']}
        summary={(m['name'],m['descriptor']):m for m in cell['methods']}
        require(len(raw)==len(summary)==4 and set(raw)==set(summary)==METHODS,f'{sel}: raw API method inventory mismatch')
        expected_inventory=[list(x) for x in sorted(METHODS)]
        require(cell.get('method_inventory_matches') is True and cell.get('physical_method_inventory')==expected_inventory
                and cell.get('expected_physical_method_inventory')==expected_inventory,f'{sel}: captured physical method inventory mismatch')
        class_id=doc['class']; bytecode=Path(original_profiles[sel[0]]['class_tree'][INTERNAL+'.class']['path']).read_bytes()
        require(class_id['class_bytes']['length']==len(bytecode),'API class bytes identity length mismatch')
        for ident,method in summary.items():
            body=raw[ident]['outcome']['report']; identity=raw[ident]['item']['identity']
            require(method['raw_text']==body['text'] and method['source_map']==body['source_map'] and method['quality']==body['quality'] and method['fallbacks']==body['fallbacks'],f'{sel}/{ident}: method summary/raw mismatch')
            require(method['outcome_kind']==raw[ident]['outcome']['kind']=='recovered' and method['quality']=='structured',f'{sel}/{ident}: expected structured recovered output')
            require(method['identity']==identity and identity['owner']==class_id and method['owner']==class_id,f'{sel}/{ident}: physical owner identity mismatch')
            require(method['location']==identity['owner']['location'] and method['variant']==identity['owner']['variant'],f'{sel}/{ident}: origin location mismatch')
            phys={(m['name'],m['descriptor']):m for m in original_facts[sel[0]]['methods']}[ident]
            bcis=set(phys['code']['bcis']); sm=method['source_map']; require(isinstance(sm,dict) and isinstance(sm.get('segments'),list),f'{sel}/{ident}: missing structured source map')
            text=method['raw_text'].encode('utf-8'); boundaries={0}; acc=0
            for ch in method['raw_text']: acc+=len(ch.encode('utf-8')); boundaries.add(acc)
            mapped=set()
            for seg in sm['segments']:
                start,end=seg.get('start'),seg.get('end')
                require(type(start) is int and type(end) is int and 0<=start<=end<=len(text) and start in boundaries and end in boundaries,f'{sel}/{ident}: map span not on UTF-8 boundary')
                origin=seg.get('origin') or {}
                for o in [origin.get('primary'),*origin.get('derived',[])]:
                    if not isinstance(o,dict): continue
                    require(o.get('method')==identity and type(o.get('bci')) is int and o['bci'] in bcis,f'{sel}/{ident}: map BCI/method mismatch')
                    mapped.add(o['bci'])
            audit=method['map_audit']; require(set(audit['physical_bcis'])==bcis and set(audit['mapped_bcis'])==mapped and audit['covers_all_physical_bcis'] is True and not audit['issues'],f'{sel}/{ident}: map audit/physical Code mismatch')
            api_method_rows+=1
        api_values[sel]=(doc['text'],{key:(m['raw_text'],m['source_map']) for key,m in summary.items()})
    for p in PROFILES:
        for f in FORMS: require(api_values[(p,f,'default')]==api_values[(p,f,'all')],f'{p}/{f}: default/all whole text or raw maps differ')

    # Verify source matrix, exact byte copies, both javac legs, and complete physical class facts.
    cells=generated.get('source_cells',[]); require(len(cells)==10,'generated source selector count must remain ten')
    cellmap={tuple(c['cell_key']):c for c in cells}; require(len(cellmap)==10,'generated source selector duplicate')
    expectedkeys={(p,f,e) for p in PROFILES for f in FORMS for e in EVIDENCE}|{(p,'bundle','source') for p in PROFILES}
    require(set(cellmap)==expectedkeys and all(c.get('source_available') is True for c in cells),'generated source matrix incomplete')
    for key,c in cellmap.items():
        copies=c.get('source_copies',[]); require(bool(copies),f'{key}: no source copy evidence')
        for pair in copies:
            src=pin(pair['source'],f'{key} source'); dst=pin(pair['copy'],f'{key} copy')
            require(src.read_bytes()==dst.read_bytes(),f'{key}: source copy differs byte-for-byte')
        if c['kind']=='jarde':
            old=old_cells[(key[0],key[1],key[2])]; original_whole=pin(old['whole_source'],f'{key} baseline whole source')
            require(len(copies)==1 and Path(copies[0]['source']['path']).resolve()==original_whole and pin(copies[0]['copy'],'Jarde source copy').read_bytes()==original_whole.read_bytes(),f'{key}: Jarde source was not copied from exact accepted API output')
        else:
            oldj={x['compiler_profile']:x for x in baseline['jadx_outputs']}[key[0]]
            old_sources={str(pin(x,'JADX baseline source')):Path(x['path']).read_bytes() for x in oldj['sources']}
            new_sources={str(Path(pair['source']['path']).resolve()):pin(pair['copy'],'JADX source copy').read_bytes() for pair in copies}
            require(new_sources==old_sources,f'{key}: JADX complete output source closure differs from baseline')
        source_folder='-'.join(key[:2]) if c['kind']=='jadx' else '-'.join(key)
        source_root=Path(generated['output'])/'sources'/source_folder
        actual={str(p.resolve()) for p in source_root.rglob('*.java')}
        expected={str(Path(x['copy']['path']).resolve()) for x in copies}
        require(actual==expected,f'{key}: source closure folder has missing/extra files')
    compiles=generated['compilations']; require(len(compiles)==20,'must preserve all 20 full-source compiler attempts')
    compilemap={(tuple(x['cell_key']),x['leg']):x for x in compiles}
    require(len(compilemap)==20 and set(compilemap)=={(key,leg) for key in expectedkeys for leg in LEGS},'compile matrix incomplete/duplicate')
    expected_success={(key,leg) for key in expectedkeys for leg in LEGS if not (key[1]=='bundle' and leg=='javac8')}
    expected_failure={(key,'javac8') for key in expectedkeys if key[1]=='bundle'}
    require({k for k,v in compilemap.items() if v['exit_code']==0}==expected_success,'successful compile cells differ from accepted matrix')
    require({k for k,v in compilemap.items() if v['exit_code']!=0}==expected_failure,'failed compile cells differ from two known framework boundaries')
    # First-stage parser shadowing is preserved as history, but physical facts are independently rebuilt from all 18 outputs.
    reparsed=resume.get('reparsed_successful_compiles',[]); require(len(reparsed)==18,'resume must independently reparse every successful compilation tree')
    reparsemap={(tuple(x['cell_key']),x['compiler']):x for x in reparsed}
    require(len(reparsemap)==18 and set(reparsemap)==expected_success,'reparsed compile inventory does not cover exact 18 successful cells')
    loop_comparisons={}
    for key,rec in compilemap.items():
        src=cellmap[key[0]]; cmd=gcmd[rec['command']]
        require(cmd['exit_code']==rec['exit_code'] and cmd['label']==f'compile-{"-".join(key[0])}-{key[1]}',f'{key}: compile row/command mismatch')
        argv=cmd['argv']; expected_leg=jdks[key[1]]['tools']['javac']
        require(Path(argv[0]).resolve()==Path(expected_leg).resolve(),f'{key}: compiler executable pin mismatch')
        require('-d' in argv and Path(argv[argv.index('-d')+1]).resolve()==Path(rec['class_root']).resolve(),f'{key}: compiler output root mismatch')
        require('-proc:none' in argv and '-sourcepath' in argv and Path(argv[argv.index('-sourcepath')+1]).resolve()==Path(generated['output']).resolve()/'empty-classpath',f'{key}: compiler safety/sourcepath mismatch')
        require('-classpath' in argv and argv[argv.index('-classpath')+1]==':'.join(baseline['dependency_classpath']),f'{key}: compile dependency classpath mismatch')
        require('-g' in argv if src['profile']=='debug' else '-g:none' in argv,f'{key}: debug flag mismatch')
        if key[1]=='javac8': require('-source' in argv and argv[argv.index('-source')+1]=='8' and '-target' in argv and argv[argv.index('-target')+1]=='8',f'{key}: Java 8 language target mismatch')
        else: require('--release' in argv and argv[argv.index('--release')+1]=='8',f'{key}: Java 23 release mismatch')
        for ch in ('stdout','stderr'):
            require(pin(rec[ch],f'{key}/{ch}').read_bytes()==pin(cmd['streams'][ch],f'{key}/raw {ch}').read_bytes(),f'{key}: compile raw stream mismatch')
        if key in expected_failure:
            err=pin(rec['stderr'],f'{key} JDK8 boundary stderr').read_bytes()
            require(rec.get('failure_classification')=='harness-major-55-boundary' and b'55.0' in err and b'52.0' in err,f'{key}: framework major55/target52 failure not preserved')
            require(rec.get('runtime_eligible') is False and rec.get('class_tree')=={} and rec.get('class_facts') is None,f'{key}: failed compile must have no output/VM eligibility')
            continue
        replay=reparsemap[key]; classroot=Path(rec['class_root']).resolve(strict=True)
        require(Path(replay['class_root']).resolve()==classroot,f'{key}: resume parsed another class root')
        expected_tree={INTERNAL+'.class'} if src['kind']=='jarde' else {INTERNAL+'.class',OUTER+'.class'}
        actual=tree_files(compare,classroot)
        require(set(actual)==expected_tree and replay['class_tree']==actual,f'{key}: compiled class closure differs from independent reparse evidence')
        require(rec['class_tree']==actual,f'{key}: first-stage pinned class tree changed')
        facts={}
        for rel,treepin in actual.items():
            path=pin(treepin,f'{key}/{rel}')
            fact,phys=parsed_class(compare,physical,path,f'{key}/{rel}')
            require(fact['major']==52,f'{key}/{rel}: expected Java 8 classfile major 52')
            for physical_method in fact['methods']:
                code=physical_method.get('code') or {}; bcis=code.get('bcis',[])
                require(code.get('code_length',0)>0 and bcis and bcis[0]==0 and bcis==sorted(set(bcis)) and bcis[-1]<code['code_length'],f'{key}/{rel}/{physical_method["name"]}: invalid generated Code/BCI inventory')
            saved=replay['target_facts'] if rel==INTERNAL+'.class' else replay.get('class_facts',{}).get(rel)
            # Resume collector saves target facts and exact full class-tree pins; independently parse every emitted class here.
            if saved is not None: require(norm(saved)==norm(fact),f'{key}/{rel}: resume saved facts differ from current dual parser')
            facts[rel]=fact
        target=facts[INTERNAL+'.class']; orig=original_facts[src['profile']]
        require(target['class_name']==INTERNAL and target['major']==52 and target['access']==orig['access'] and target['fields']==orig['fields'] and {(m['name'],m['descriptor']) for m in target['methods']}==METHODS,f'{key}: generated target full inventory mismatch')
        loop_comparisons[(key[0],key[1])]=check_code_facts(target,src['kind'],f'{key}')
        original_methods={(m['name'],m['descriptor']):m for m in orig['methods']}
        generated_methods={(m['name'],m['descriptor']):m for m in target['methods']}
        for method_name in EXPECTED_LOOP_CODE:
            require(generated_methods[(method_name,'()V')]['access']==original_methods[(method_name,'()V')]['access'],f'{key}/{method_name}: generated method access changed')
            old_code=original_methods[(method_name,'()V')]['code']; new_code=generated_methods[(method_name,'()V')]['code']
            if src['kind']=='jarde': require(new_code['bcis']==old_code['bcis'],f'{key}/{method_name}: Jarde BCI inventory differs from original')
            loop_comparisons[(key[0],key[1])][method_name]['original_bcis']=old_code['bcis']
            loop_comparisons[(key[0],key[1])][method_name]['generated_bcis']=new_code['bcis']
        if src['kind']=='jarde':
            require(set(facts)=={INTERNAL+'.class'},f'{key}: Jarde child compile must have one-class closure')
        else:
            require(set(facts)=={INTERNAL+'.class',OUTER+'.class'},f'{key}: JADX compile must retain complete outer/child class closure')
            outer=facts[OUTER+'.class']; original_outer=parsed_class(compare,physical,Path(original_profiles[src['profile']]['class_tree'][OUTER+'.class']['path']),f'{src["profile"]} original outer')[0]
            require(outer['class_name']==OUTER and outer['major']==52 and outer['access']==original_outer['access'] and outer['fields']==original_outer['fields'] and {(m['name'],m['descriptor']) for m in outer['methods']}==OUTER_METHODS,f'{key}: generated outer class inventory mismatch')
            outer_methods={(m['name'],m['descriptor']):m for m in outer['methods']}; old_outer_methods={(m['name'],m['descriptor']):m for m in original_outer['methods']}
            require(all(outer_methods[i]['access']==old_outer_methods[i]['access'] for i in OUTER_METHODS),f'{key}: generated outer method access changed')
        # Resume preserves the original parser-shadowing errors and a complete independent target inventory.
        first_errors=replay['first_stage_parser_error']
        require(first_errors=={'class_facts_error':rec.get('class_facts_error'),'target_facts_error':rec.get('target_facts_error')},f'{key}: first-stage parser-error history changed')
        require(replay.get('method_inventory_matches_original') is True,f'{key}: resume did not confirm original target method inventory')
        stat=replay.get('static_loop_code_comparison',{})
        require(stat.get('all_three_exact') is (src['kind']=='jarde'),f'{key}: resume static loop-code equality summary mismatch')
    require(len(loop_comparisons)==18,'complete physical loop Code comparison absent')
    # The known original-stage parser shadowing affected later class facts only; preserve it rather than calling it a product failure.
    parser_error_records=[x for x in reparsed if x.get('first_stage_parser_error',{}).get('class_facts_error')]
    require(len(parser_error_records)==17 and all('AttributeError' in x['first_stage_parser_error']['class_facts_error'] for x in parser_error_records),
            'historical first-stage parser-shadow error count/shape changed')

    # Compose the old first-stage runtime cell with 17 resume target cells; each VM observes constructor/inventory only.
    old_runtime={(tuple(x['cell_key']),x['compiler'],x['runtime']):x for x in generated['runtime_rows']}
    new_runtime={(tuple(x['cell_key']),x['compiler'],x['runtime']):x for x in resume['runtime_rows']}
    runtime={**{k:('first-stage',v) for k,v in old_runtime.items()},**{k:('resume',v) for k,v in new_runtime.items()}}
    old_wrong={(tuple(x['cell_key']),x['compiler']):x for x in generated['wrong_root_rows']}
    new_wrong={(tuple(x['cell_key']),x['compiler']):x for x in resume['wrong_root_rows']}
    wrong={**{k:('first-stage',v) for k,v in old_wrong.items()},**{k:('resume',v) for k,v in new_wrong.items()}}
    require(len(runtime)==36 and len(old_runtime)==2 and len(new_runtime)==34,'composed runtime matrix must be 36 rows (2 preserved +34 resumed)')
    require(len(wrong)==18 and len(old_wrong)==1 and len(new_wrong)==17,'composed wrong-root matrix must be 18 rows')
    expected_run_keys={(key,leg,vm) for key,leg in expected_success for vm in VMS}
    require(set(runtime)==expected_run_keys,'constructor runtime grid incomplete or duplicated')
    require(set(wrong)=={(key,leg) for key,leg in expected_success},'wrong-root grid incomplete or duplicated')
    wrapper_name=Path(baseline['runtime_wrapper']['path']).name
    wrapper_rows=[x for x in generated['local_copies_before'] if Path(x['path']).name==wrapper_name]
    require(len(wrapper_rows)==1 and wrapper_rows[0]['bytes']==baseline['runtime_wrapper']['bytes'] and wrapper_rows[0]['sha256']==baseline['runtime_wrapper']['sha256'], 'generated bounded wrapper copy differs from accepted baseline wrapper')
    generated_wrapper=pin(wrapper_rows[0],'generated bounded runtime wrapper copy')
    driver_src=pin(generated['driver_source'],'generated reflection driver source')
    driver_compile=generated.get('driver_compile',{}); driver_cmd=gcmd[driver_compile.get('command')]
    require(driver_cmd['label']=='compile-reflection-driver' and driver_cmd['exit_code']==driver_compile.get('exit_code')==0
            and Path(driver_cmd['argv'][0]).resolve()==Path(jdks['javac8']['tools']['javac']).resolve()
            and Path(driver_cmd['argv'][-1]).resolve()==driver_src
            and Path(driver_cmd['argv'][driver_cmd['argv'].index('-d')+1]).resolve()==Path(generated['driver_classes'][0]['path']).resolve().parent,
            'reflection driver compile identity/argv mismatch')
    driver_copy=pin(generated['driver_copy'],'generated reflection driver copy')
    require(driver_src.read_bytes()==driver_copy.read_bytes(),'driver source copy differs')
    driver_class=[pin(x,'driver class') for x in generated['driver_classes']]
    require(len(driver_class)==1 and driver_class[0].name==DRIVER+'.class','expected exactly one independent reflection driver class')
    require(resume['existing_driver_class']==generated['driver_classes'][0] and pin(resume['existing_driver_class'],'resume pinned existing driver class')==driver_class[0], 'resume driver class differs from first-stage driver')
    driver_root=driver_class[0].parent
    driver_text=driver_src.read_text(encoding='utf-8')
    for token in ('new URLClassLoader(new URL[] { Paths.get(actual).toUri().toURL() }, null)','target.getClassLoader() != loader','wrong CodeSource:','constructor.newInstance()','getDeclaredMethods()','getDeclaredFields()'):
        require(token in driver_text,f'driver lacks isolation or inventory check: {token}')
    require('.invoke(' not in driver_text and 'getDeclaredMethod("test1"' not in driver_text and 'getDeclaredMethod("test2"' not in driver_text and 'getDeclaredMethod("test3"' not in driver_text,'driver must never invoke nonterminating methods')
    runtime_observations=0
    for (key,compiler,vm),(phase,row) in runtime.items():
        match_flag = row.get('matches_original_constructor_observation', row.get('matches_original_profile_runtime'))
        require(row['exit_code']==0 and match_flag is True,f'{key}/{compiler}/{vm}: constructor observation failed/mismatched')
        cmd=(gcmd if phase=='first-stage' else rcmd)[row['command']]
        expected_label=('runtime-' if phase=='first-stage' else 'resume-runtime-')+'-'.join(key)+f'-{compiler}-{vm}'
        require(cmd['label']==expected_label,f'{key}: {phase} runtime label mismatch')
        require(cmd['exit_code']==0 and cmd.get('tool_leg')==vm,f'{key}/{compiler}/{vm}: command status/JVM leg mismatch')
        wrapper=generated_wrapper if phase=='first-stage' else pin(resume['runtime_wrapper_copy'],'resume runtime wrapper copy')
        argv=cmd['argv']; require(len(argv)==11 and argv[1]=='-B' and Path(argv[2]).resolve()==wrapper and argv[3]=='30'
            and Path(argv[4]).resolve()==Path(jdks[vm]['tools']['java']).resolve() and argv[5]=='-Xverify:all' and argv[6]=='-cp'
            and Path(argv[7]).resolve()==driver_root and argv[8]==DRIVER,f'{key}/{compiler}/{vm}: guarded parentless runtime argv mismatch')
        actual_root=Path(row.get('target_root',row.get('actual_target_root',''))).resolve(strict=True)
        require(Path(argv[9]).resolve()==actual_root and Path(argv[10]).resolve()==actual_root,f'{key}/{compiler}/{vm}: runtime target root binding mismatch')
        require(row.get('application_classpath')==[str(driver_root)],f'{key}/{compiler}/{vm}: classpath is not driver-only')
        stdout=pin(row['stdout'],f'{key}/{compiler}/{vm} stdout').read_bytes(); stderr=pin(row['stderr'],f'{key}/{compiler}/{vm} stderr').read_bytes()
        require(stdout==pin(cmd['streams']['stdout'],f'{key} command stdout').read_bytes() and stderr==pin(cmd['streams']['stderr'],f'{key} command stderr').read_bytes(),f'{key}: runtime raw streams mismatch')
        parsed=parse_rows(stdout); require(parsed==row['rows'] and projection(parsed)==oracles[(key[0],vm)],f'{key}: constructor oracle differs from original profile/JVM')
        require(row.get('semantic_projection')==projection(parsed),f'{key}: stored runtime semantic projection differs from raw rows')
        require(len(parsed)==1,'must report one constructor-only row; loops are not executed')
        runtime_observations+=1
    for (key,compiler),(phase,row) in wrong.items():
        require(row['exit_code']==1 and row.get('rejected') is True,f'{key}/{compiler}: wrong-root control not rejected')
        cmd=(gcmd if phase=='first-stage' else rcmd)[row['command']]
        require(cmd['label']==('wrong-root-' if phase=='first-stage' else 'resume-wrong-root-')+'-'.join(key)+f'-{compiler}',f'{key}/{compiler}: {phase} wrong-root label mismatch')
        require(cmd['exit_code']==1 and cmd.get('tool_leg')=='javac23',f'{key}/{compiler}: wrong-root command mismatch')
        wrapper=generated_wrapper if phase=='first-stage' else pin(resume['runtime_wrapper_copy'],'resume runtime wrapper copy')
        argv=cmd['argv']; require(len(argv)==11 and argv[1]=='-B' and Path(argv[2]).resolve()==wrapper and argv[3]=='30'
           and Path(argv[4]).resolve()==Path(jdks['javac23']['tools']['java']).resolve() and argv[5]=='-Xverify:all' and argv[6]=='-cp'
           and Path(argv[7]).resolve()==driver_root and argv[8]==DRIVER,f'{key}/{compiler}: wrong-root argv mismatch')
        require(Path(argv[9]).resolve()==Path(row['actual_target_root']).resolve() and Path(argv[10]).resolve()==Path(row['expected_wrong_root']).resolve()
                and Path(argv[9]).resolve()!=Path(argv[10]).resolve(),f'{key}/{compiler}: wrong-root roots not distinct/recorded')
        stderr=pin(row['stderr'],f'{key}/{compiler} wrong-root stderr').read_bytes()
        stdout=pin(row['stdout'],f'{key}/{compiler} wrong-root stdout').read_bytes()
        require(b'wrong CodeSource:' in stderr and stderr==pin(cmd['streams']['stderr'],f'{key} wrong command stderr').read_bytes()
                and stdout==pin(cmd['streams']['stdout'],f'{key} wrong command stdout').read_bytes(),f'{key}/{compiler}: wrong-root diagnostic/raw mismatch')
    require(runtime_observations==36,'36 independent constructor rows expected')
    # There are 2 actual javac8 failures (JADX full source / major55 harness); they have no generated class or VM rows.
    require(len(expected_failure)==2 and not any(k[1]=='javac8' and k[0][1]=='bundle' for k in runtime),'framework failures must not be counted as runtime')

    # Exact command inventory and completion evidence. 24 initial generated + 51 resume commands = 75 generated-stage commands.
    require(len(generated['commands'])+len(resume['commands'])==75,'generated plus resume command total mismatch')
    require(resume.get('prior_command_count')==24 and resume.get('prior_runtime_attempts_preserved')==2 and resume.get('prior_wrong_root_attempts_preserved')==1,'resume did not preserve the original 24-command ledger')
    require(resume.get('counts_derived',{}).get('reused_compile_attempts')==20 and resume['counts_derived'].get('reused_compile_successes')==18 and resume['counts_derived'].get('reused_compile_failures')==2,'resume compile history totals changed')
    # Dynamic summary separates compilation/run kinds and does not imply loop invocation.
    result={'schema':'test-endless-loop-generated-independent-review-v1','baseline_receipt_sha256':BASELINE_SHA,'baseline_root_audit_sha256':BASE_AUDIT_SHA,
      'first_stage_generated_sha256':GENERATED_SHA,'resume_receipt_sha256':sha(rp),'generated_stage_commands':75,'first_stage_commands':24,'resume_commands':51,
      'resume_raw_streams':len(resume['commands'])*2,'generated_raw_streams':(len(generated['commands'])+len(resume['commands']))*2,
      'baseline_commands':len(baseline['commands']),'baseline_raw_streams':sum(1 for c in baseline['commands'] for _ in ('stdout','stderr')),
      'original_constructor_vm_runs':len(oracles),'original_constructor_rows':sum(len(x) for x in oracles.values()),
      'source_cells':10,'compiler_attempts':20,'compiler_successes':18,'known_javac8_harness_major55_failures':2,
      'jarde_compilation_successes':sum(1 for k in expected_success if cellmap[k[0]]['kind']=='jarde'),
      'jarde_constructor_vm_runs':sum(1 for k in runtime if cellmap[k[0]]['kind']=='jarde'),'jarde_constructor_rows':sum(1 for k in runtime if cellmap[k[0]]['kind']=='jarde'),
      'jadx_compilation_successes':sum(1 for k in expected_success if cellmap[k[0]]['kind']=='jadx'),
      'jadx_constructor_vm_runs':sum(1 for k in runtime if cellmap[k[0]]['kind']=='jadx'),'jadx_constructor_rows':sum(1 for k in runtime if cellmap[k[0]]['kind']=='jadx'),
      'generated_wrong_root_controls':18,'generated_runtime_observations':36,'generated_loop_methods_invoked':False,
      'jarde_loop_code_exact_against_original':16,'jadx_test2_test3_code_nonidentical':2,
      'api_cells':8,'api_methods_structured':32,'default_all_raw_text_and_maps_equal':True,
      'all_18_success_class_trees_reparsed':True,'full_class_inventory_verified':True,'scope':'constructor/method-inventory runs only; no nonterminating loop method, check(), or JUnit assertion executed'}
    out.mkdir(parents=True,exist_ok=False)
    (out/'review.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    note=('Independent generated-output and resume review. The 30-second wrapper bounds only class load/construction. '
      'It never invokes test1/test2/test3, and therefore contributes no runtime proof for those nonterminating methods. '
      'Jarde loop Code is compared exactly at the parsed Code/exception-table/limits/access level. JADX test2/test3 compile to the recorded 9-byte while shape versus the original 6-byte do-while bytes; this is reported as non-byte-identical. Static source inspection establishes `this == this` and `this != this` identity conditions with empty/no-effect loop bodies; no loop execution or frame-attribute byte identity is claimed. '
      'The two JDK8 full-source compilation failures are the pinned major-55 harness versus release-8 major-52 boundary, and receive no VM run.')
    (out/'README.md').write_text(note+'\n',encoding='utf-8')
    return result
if __name__=='__main__': print(json.dumps(main(),indent=2,sort_keys=True))
