# Review scope adjustments

The reviewer follows the actual receipt schemas rather than assuming one common command shape across the original, first-stage, and resume runs. API argv is checked against each selector: `child` uses `single-class`, `bundle-child` uses `plain-jar`, and `all` appends the exact evidence flag. Resume runtime commands bind to the copied bounded wrapper, while first-stage commands bind to the original wrapper.

The source snapshot is compared within each capture phase; the current live checkout is not required to equal historical source closures. Generated child-only and full outer-plus-child output trees are checked against the corresponding producer kind. Every successful class tree is independently parsed, with full class/method/field identities and Code/BCI facts.

The resume receipt’s `captured-pending-independent-review` label is treated as captured data, not acceptance. A successful reviewer run is required for independent acceptance. No runtime invocation of the endless methods is present or claimed.
