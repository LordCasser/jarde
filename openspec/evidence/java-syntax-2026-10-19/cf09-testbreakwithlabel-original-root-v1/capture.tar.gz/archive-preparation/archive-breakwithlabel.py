#!/usr/bin/env python3
"""Prepare the complete CF09 TestBreakWithLabel evidence archive."""
import argparse, json
from pathlib import Path
from archive import run

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
print(json.dumps(run('breakwithlabel',args.out,None,None),indent=2))
