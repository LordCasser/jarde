#!/usr/bin/env python3
"""Prepare the accepted native and own-CI if-loop-entry evidence archive."""
import argparse, json
from pathlib import Path
from archive import run

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--final-ci-root',type=Path,required=True)
parser.add_argument('--named-review-file',type=Path,required=True)
args=parser.parse_args()
print(json.dumps(run('if-loop-entry-ci',args.out,args.final_ci_root,args.named_review_file),indent=2))
