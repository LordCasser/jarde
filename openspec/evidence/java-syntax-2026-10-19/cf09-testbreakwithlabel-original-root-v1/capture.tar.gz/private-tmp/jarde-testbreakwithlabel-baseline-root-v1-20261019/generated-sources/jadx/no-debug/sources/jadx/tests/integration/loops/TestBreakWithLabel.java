package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakWithLabel.class */
public class TestBreakWithLabel extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakWithLabel$TestCls.class */
    public static class TestCls {
        public boolean test(int[][] iArr, int i) {
            boolean z = false;
            loop0: for (int i2 = 0; i2 < iArr.length; i2++) {
                for (int i3 = 0; i3 < iArr[i2].length; i3++) {
                    if (iArr[i2][i3] == i) {
                        z = true;
                        break loop0;
                    }
                }
            }
            System.out.println("found: " + z);
            return z;
        }

        public void check() {
            int[][] iArr = {new int[]{1, 2}, new int[]{3, 4}};
            Assertions.assertThat(test(iArr, 3)).isTrue();
            Assertions.assertThat(test(iArr, 5)).isFalse();
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("loop0:").containsOne("break loop0;");
    }
}
