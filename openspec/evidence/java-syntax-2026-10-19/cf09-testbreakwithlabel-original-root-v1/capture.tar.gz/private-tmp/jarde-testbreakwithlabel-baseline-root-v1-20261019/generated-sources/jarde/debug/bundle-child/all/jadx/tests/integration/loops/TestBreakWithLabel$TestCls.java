// jarde: presentation of `jadx/tests/integration/loops/TestBreakWithLabel$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestBreakWithLabel$TestCls extends java.lang.Object {
    public TestBreakWithLabel$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestBreakWithLabel$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public boolean test(int[][] arr, int b) {
        // @method test([[II)Z
        // @declaration an instance method of `jadx.tests.integration.loops.TestBreakWithLabel$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int found;
        int i;
        found = 0;
        int j;
        loop: for (i = 0; i < arr.length; i = i + 1) {
            for (j = 0; j < arr[i].length; j = j + 1) {
                if (arr[i][j] == b) {
                    found = 1;
                    break loop;
                }
            }
        }
        // @bytecode 75 53 68
        // the `append` at BCI 69 takes `boolean`, and this layer has no evidence that the value it reads at BCI 75 is a boolean (a `0`/`1` literal, a `boolean` parameter's load, the result of a call whose callee descriptor returns `Z`, a claimed field read whose descriptor is `Z`, a local this body declared `boolean`, or a value whose own expression is already presented as a boolean): the `int` spelling this layer would write is text the overload's own conversion rejects
        return found % 2 != 0;
    }

    public void check() {
        // @method check()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestBreakWithLabel$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int[][] testArray = new int[][]{new int[]{1, 2}, new int[]{3, 4}};
        org.assertj.core.api.Assertions.assertThat(this.test(testArray, 3)).isTrue();
        org.assertj.core.api.Assertions.assertThat(this.test(testArray, 5)).isFalse();
        return;
    }
}
