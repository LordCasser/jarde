package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestBreakWithLabel.class */
public class TestBreakWithLabel extends IntegrationTest {

    /* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestBreakWithLabel$TestCls.class */
    public static class TestCls {
        public boolean test(int[][] arr, int b) {
            boolean found = false;
            loop0: for (int i = 0; i < arr.length; i++) {
                for (int j = 0; j < arr[i].length; j++) {
                    if (arr[i][j] == b) {
                        found = true;
                        break loop0;
                    }
                }
            }
            System.out.println("found: " + found);
            return found;
        }

        public void check() {
            int[][] testArray = {new int[]{1, 2}, new int[]{3, 4}};
            Assertions.assertThat(test(testArray, 3)).isTrue();
            Assertions.assertThat(test(testArray, 5)).isFalse();
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("loop0:").containsOne("break loop0;");
    }
}
