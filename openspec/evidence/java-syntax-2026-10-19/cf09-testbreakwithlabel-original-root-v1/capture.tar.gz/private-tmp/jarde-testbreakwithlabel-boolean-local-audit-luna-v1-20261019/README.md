# TestBreakWithLabel boolean-local inference audit

Status: static architecture audit only. No source edits or toolchain/CLI runs were made. The receipt is the supplied full-source capture, whose status is `captured-pending-independent-review`; this note does not upgrade its acceptance status.

## Finding

The original method declares `boolean found`, initializes it to `false`, assigns `true` on the successful match, prints it through string concatenation, and returns it. The captured class files contain the same 80-byte `test([[II)Z` Code body in both profiles. Physical decoding identifies the `found` local in slot 3: BCI 0 pushes 0 and BCI 1 stores it; BCI 36 pushes 1 and BCI 37 stores it. The two reads are BCI 68 (`iload_3`) consumed by BCI 69 `StringBuilder.append(Z)`, and BCI 78 (`iload_3`) consumed by BCI 79 `ireturn` in a method whose descriptor is `Z`. The surrounding loop has two backedges (BCIs 44 and 50), and the match path exits the outer loop from BCI 38.

The debug class has one LVT entry for `found`, descriptor `Z`, slot 3, covering `[2,80)`. The no-debug class has no LVT. Their `Code` bytes, max stack, max locals, and instruction BCIs are identical. The current Jarde whole-source output still declares the corresponding local as `int`, writes `0`/`1`, drops the `println` as a fallback, and converts the final return to `found % 2 != 0`. All eight API cells report the target method as `quality=fallback`, `representation=mixed`, with the same append-Z refusal. The constructor and `check()V` are structured. Root’s receipt records all 32 rebuilt Jarde VM observations differing from the original output. This is a concrete observable failure, not only a source-style difference.

The receipt stores physical class facts, report JSON, full recovered Java text, and runtime rows. It does **not** contain Jarde’s in-memory `SsaTable`, so the actual local-phi input graph and whole use-def closure have not been independently confirmed here. The exact Code and consumer boundaries are verified; the SSA claim must be made by an internal test against the real analysis result before implementation treats it as proved.

## Why the current proof stops

`declarations()` computes `slot_uses`, asks `short_circuit_local_booleans()` for seeds, then passes those seeds to `decide_types()` before any body statements are emitted (`build.rs:708-789`). `decide_types()` accepts a direct boolean descriptor, the bounded expression proof, or those short-circuit/conditional-store seeds (`build.rs:2524-2560`). A pushed integer 0 or 1 is explicitly `BooleanEvidence::Literal`, not an independent seed (`build.rs:510-529, 35383-35400`). That distinction is needed because the same bytes can initialize either `int` or `boolean`.

The existing single-store bridge is too narrow for this method. `proves_boolean_local_store()` requires exactly one write to the local (`build.rs:2147-2163`) and all accesses on that write’s region path; this method has two physical stores and loop-carried control flow. `short_circuit_local_booleans()` only visits bounded short-circuit-value regions and one-test `If` regions with a proved conditional store (`build.rs:1985-2108`); it has no matching loop-flag shape for these writes.

`accumulates_boolean()` is the nearest reusable discipline (`build.rs:3450-3560`). The existing tests at `tests/p3_boolean_contexts.rs:319-389` cover locals copied from proven boolean parameters/calls/locals, while its int-context controls keep 0/1 locals integer; the hand-built refusal controls at lines 711-729 and 915-947 show why raw int-shaped values cannot be generalized. They do not cover this loop-carried literal-only flag. It censuses every recorded write, accepts only 0/1 pushes or boolean bitwise production, and runs `BooleanConsumption` over every local read. It then requires at least one seeded accumulation write (`proof.has_seed()`, lines 3522-3530), which excludes this literal-only 0/1 flag. `BooleanConsumption` already accepts an `ireturn` from a `Z` method and claimed boolean field writes, but its default call handling rejects all invocation arguments (`build.rs:35534-35582`). Thus its all-reads half cannot currently admit the exact `append(Z)` read, and its existing write-seed condition cannot promote the literal-only producer set even if that read were admitted.

The call-side spelling gate is correctly narrow and should remain so. `concat_expr()` checks every `append(Z)` value with `boolean_literal`, `boolean_proven`, or an already-presented Boolean expression before spelling it as a boolean (`build.rs:32612-32645`). `boolean_local()` only accepts a local the declaration plan has decided Boolean (`build.rs:27987-27998`). Once a sound local decision exists, this existing route can supply `boolean_proven()` to the concat layer without relaxing the append rule. `debug_locals` enters `declarations()` only after `decide_types()` through `prove_debug_generic_locals()` (`build.rs:777-789`), so the debug-only `Z` LVT is not the current primitive type proof and must not become the sole basis for the no-debug profile.

## Smallest candidate to investigate

Reuse the local accumulator/consumer proof as one new admission case for a literal-only flag, rather than adding a solver, IR pass, or broad local-type heuristic. The candidate must first prove from the real SSA that one exact `LocalVariable` owns every physical slot-3 access in this body, that all physical writes to it are represented, and that every write stores only a direct 0/1 literal or a value independently proved Boolean. Then close every local-slot Phi input—including loop-carried cycles—over those writes. Any missing/unknown input, stack-Phi escape, caught value, ambiguous reuse owner, or unaccounted write refuses the whole local proof.

Use the existing `BooleanConsumption` walk for the all-reads side, with only descriptor-backed consumers as independent Boolean evidence. Its existing `ireturn`/`Z` case already covers BCI 78→79. A narrowly exact `StringBuilder.append(Z)` operand case can cover BCI 68→69; validate the invoke kind, owner, name, descriptor, receiver/argument mapping, and SSA identity of the loaded value. Do not generalize this to arbitrary call arguments. Do not count a branch test (`ifeq`/`ifne`) by itself as a seed: the same integer bytes can be tested as an integer. The consumer proof must distinguish a descriptor-backed sink from a self-referential local/phi or candidate-store edge.

A real internal test should take the original fixture’s actual analyzed `Operations`, `SsaTable`, `reuse::Plan`, and `slot_uses`, not construct a hand-written SSA graph. It should assert the complete physical local write/read inventory and explicitly inspect local-slot phis and their inputs, including loop backedges; it should also check the two descriptor consumers by identity. Run the same proof against debug and no-debug class fixtures. A public class-source/runtime test can then assert `boolean found`, both boolean assignments, the preserved println/return, default/all source agreement, compilation, and the original finite runtime rows.

## Adversarial refusal boundaries

Keep these cases outside the new admission unless the same proof independently closes them:

- A write of 2, an out-of-range constant, arithmetic update, unknown producer, or any unproved stored value.
- Another physical write to the same local in a handler/cleanup path or a slot reuse/owner ambiguity not represented by the candidate’s exact `LocalVariable` census.
- A Phi with an unknown/missing input, an unexplained external value, or a stack merge that cannot be tied to the candidate local’s writes.
- A read in integer arithmetic/comparison or an `append(I)`/`append(Object)` call, even if another read reaches a boolean sink.
- A local observed only by `ifeq`/`ifne`, or a local whose only apparent Boolean fact is an int-shaped frame.
- A wider invocation-call rule that assumes arbitrary `(Z)` arguments are safe without proving the exact parameter position and loaded SSA value.

The debug LVT `Z` can be recorded as corroborating metadata, but the same decision must be derivable from the identical Code in no-debug mode. Nothing in this audit changes the existing `append(Z)` admission rule.

## Source and Atlas evidence

The active Atlas project was opened at the Jarde checkout. Scoped searches located `proves_boolean_local_store`, `short_circuit_local_booleans`, `Builder::boolean_local`, and `Builder::concat_expr`; the source excerpts for the first two included a Focus budget-gap notice on broader call-graph resolution. I used the actual current `build.rs` bytes below for the line-level claims. Atlas results are navigation evidence, not a substitute for the live source or the missing runtime SSA dump.

Pins are in `pins.json`. The live `build.rs` SHA is `f99304f609bb86c9c962db6240c24a8f4fee9dd58a197eda35ef6dd001ebf9eb`; its line ranges cited above are from this exact file. The original Java fixture SHA is `fa38d5b302c0bec8a8424312304b260cfb036e0144f147fad1666aaa358b3a69`.
