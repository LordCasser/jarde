# CF09 TestSequentialLoops bounded case plan

Read-only planning note for `/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestSequentialLoops.java`. The source is pinned at 7b9826d70fcd7444773250dbcacbc2a35e41e75c32b002fc8091322132006913 (666 bytes) and was not modified. No JDK, Cargo, CLI, Git, network, or runtime execution was used.

The method is `TestCls.test(int a, int b)`. Both updates use Java `int` arithmetic, so the model applies signed 32-bit wrap to each `c + a` before comparing with 7. The detailed traces and exact return values are in `caseplan.json`.

| Case | `(a, b)` | First loop condition evaluations / continuations | Second loop condition evaluations / body iterations | Return |
|---|---:|---:|---:|---:|
| `positive-large-both-loops-multi` | `(1000000000, -2000000000)` | 3 / 2 | 3 / 2 | `2000000000` |
| `positive-large-first-immediate-second-multi` | `(1000000000, 7)` | 1 / 0 | 3 / 2 | `2000000007` |
| `negative-large-no-overflow` | `(-2147483640, 2147483647)` | 1 / 0 | 2 / 1 | `7` |
| `negative-min-overflow` | `(-2147483648, 2147483647)` | 2 / 1 | 2 / 1 | `2147483647` |

The matrix separates the required behaviors with at most three condition evaluations in either loop: ordinary multi-iteration behavior in both loops, immediate first-loop break with multiple assignment-condition body iterations, a large negative step without overflow, and a negative extreme that wraps during each loop. The exit-condition evaluation is counted explicitly; “body iterations” excludes the final false test and, for the first loop, the break test.

Avoid using typical small values as a runtime oracle. For example `(a=0,b=0)` never leaves the first loop, while `(a=1,b=7)` reaches the second loop and takes roughly 2.1 billion body iterations before signed wrap makes its condition false. The selected inputs have mechanically bounded traces rather than timeout-based expectations.

This plan only supplies finite inputs for a later full-class comparison. It does not assert that the current Jarde output is defective or equivalent; no original class was compiled or executed here.
