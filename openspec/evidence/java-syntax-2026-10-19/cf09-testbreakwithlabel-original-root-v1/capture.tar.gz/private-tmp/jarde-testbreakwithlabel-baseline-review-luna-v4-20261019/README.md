# TestBreakWithLabel baseline reviewer v4

Private read-only reviewer preparation, not executed against the receipt. This update adapts the v3 reviewer to the already terminal 94-command receipt without rerunning the collector or any Java/Jarde tool. The frozen v3 collector and driver are pinned in `pins.json`; the receipt was read only to understand its schema and record its pin.

V4 reads the JDK manifest as an explicit `{path, sha256}` record, reopens and hashes the manifest, then independently checks all six receipt Java executable pins against the manifest and configured JDKs. It does not treat the manifest summary object itself as a file pin.

The collector initializes `generated_class_trees` as an empty list, while the complete 20 per-compile output trees are present on each compile row and in `generated_class_trees_after`. V4 records the empty top-level field as a collector-schema observation, reconstructs the before-tree map from every compile row, and compares each complete class inventory and byte pin against the after snapshot and live files. This keeps the full class-tree check intact while documenting the missing aggregate snapshot.

Source-map review still requires UTF-8-valid spans, correct method identity, and each claimed BCI to be a physical instruction. Missing physical BCIs are recorded as findings with their exact numbers, not treated as a reason to discard the rest of the report. The `test([[II)Z` fallback omission of BCI 44/56/59/60/63/65/69/72 is therefore visible in the findings and per-method summary. The reviewer also includes each method’s raw recovered text and fallback/region metadata.

Generated runtime comparisons are recomputed against each matching original profile/runtime and include per-case differences. On the terminal receipt’s observed rows, the 16 Jarde full-source compile cells yielded 32 VM rows that differ from their original outputs; these remain findings rather than being coerced to success. The two JADX compilation failures and the four actual JADX VM rows are reported from their raw receipt entries. This captures the `found`-as-int/boolean append presentation gap and the observed runtime mismatch without assuming those cells passed.

The original v3 six-case order remains pinned: `early-hit`, `late-hit`, `miss`, `null-outer`, `null-row`, `hit-before-null-row`. The final case still expects `true`, no exception, and `found: true\n` for `{{7}, null}` with target `7`.

Python-only checks performed for v4: AST parse and a synthetic six-case parser/oracle check. The terminal receipt was not passed to the reviewer; no target, compiler, CLI, JDK, Cargo, Git, or network action was run.
