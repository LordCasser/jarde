# CF08 TestLoopRestore2 BCI 8 source-map trace

## Observed artifact

The supplied receipt is `/private/tmp/jarde-looprestore2-baseline-root-v1-20261019/execution.json` (SHA256 in `pins.json`), with receipt status `captured-pending-independent-review`. The class facts name `loops/TestLoopRestore2.test([I[I)V`; `Code` is 24 bytes and has the ten physical instruction BCIs `0,1,2,5,8,11,14,17,20,23`. The `code_hex` sequence decodes at BCI 8 as `goto +3` to BCI 11, the inner loop header. BCI 5 is the outer `ifeq` targeting BCI 20; BCI 14 is the inner `ifeq -3` back edge to BCI 11; BCI 17 is a `goto +3` to BCI 20; BCI 20 is `iinc`; BCI 23 is `return`.

The four captured API cells (commands 2, 5, 8, 11) each report `test([I[I)V` as Structured and publish byte-identical method source and source maps. Every map anchor binds to that exact method and class-byte identity. Each map has 13 segments and maps the set `[0,1,2,5,11,14,17,20,23]`; the physical set has ten BCIs, so **only BCI 8 is missing**. The stored map audit has `issues=[]` but `covers_all_method_bcis=false`. This is not a semantic-failure finding; it is a narrow origin-completeness gap in the structured artifact.

The captured Jarde full source places the inner `do { } while (!true);` in the body selected by the outer `if (false)`. BCI 8 is the physical edge that enters that loop. BCI 17, the loop exit edge, is already among mapped BCIs. Thus it would be premature to treat the missing entry `goto` as irrelevant merely because it emits no standalone Java statement.

## Static cause

- `Builder::instruction` treats `Operation::Transfer` as having no statement of its own (`crates/jarde-java/src/build.rs:27346-27359`).
- The ordinary `If` builder anchors the branch and derives origins from an empty direct `goto` arm or a nonempty arm's terminal `goto` to the `if` join (`build.rs:20551-20583`; the helper's contract and exact one-normal-edge check are `build.rs:10336-10395`). BCI 8 is neither: it is the leading transfer in a nonempty arm, and its target is the nested loop header, not the outer join. The if origin path therefore does not record it.
- `Region::Loop.gateway_origins` is explicitly the place for hidden transfers represented by a loop (`crates/jarde-java/src/region.rs:720-722`), and Builder folds each into the loop statement as a derived origin (`build.rs:21699-21702`). For an ordinary header-tested loop, region discovery currently fills the vector from the exit gateway, a narrowly proved fragmented update-transfer case, and the implicit tail latch (`region.rs:17765-17807`; chain-loop path `17375-17454`). It does not add an outside predecessor gateway into the header. The nested-arm closure check also interprets the existing vector as the latch certificate (`region.rs:7922-7935`), so adding arbitrary incoming BCIs to it without preserving that invariant would be unsafe.
- Emission records spans only for actual AST nodes with origins; the replay verifies emitted bytes and records those origins (`crates/jarde-java/src/emit.rs:607-639, 1580-1617`). A physical instruction’s presence in the region/accounting tree does not automatically create a map anchor.

The receipt's region summary lists BCI 8 in the top-level `if` subtree block inventory (the summary does not expose the exact nested owner). Therefore this is not an unscanned Code gap; the loss occurs when the transfer-only block is converted to no statement and neither enclosing emitted node inherits its origin.

## Narrow disposition

No current source-map rule found here declares every hidden control transfer to be safely unmapped. Conversely, `source_map.rs` defines the map as text spans keyed to the origins of AST nodes, and does not state a universal full-BCI coverage contract. The receipt's `issues=[]` is not a completeness guarantee: its same record explicitly says coverage is false. If full coverage is intended for this recovered shape, the minimum correction should attach `Origin::derived(8)` to one real emitted structured node after proving the exact incoming normal edge and its unique transfer-only block, while leaving the block's existing single region owner unchanged. The closest existing mechanisms are the parent `If` origin path or the loop's `gateway_origins`; a generic “map every goto” rule is not justified. If unmapped structural-only edges are instead an allowed contract, that exception should be made explicit and separately reported rather than inferred from `quality=Structured` or `issues=[]`.

Atlas was opened as requested. Scoped searches over `crates/jarde-java/src` returned partial/no-match results due incomplete local structural facts; a scoped explore of `loop_region` remained pending while building call-graph facts. Atlas results were not used as source evidence. The line references above come from direct read-only inspection of the pinned source.

## Limits

No toolchain, CLI, Git, network, or shared-file operation was performed. This review does not independently validate the full 16-command receipt, compile the result, or establish that all structured methods generally require complete physical-BCI mapping.
