# TestLoopRestore2 baseline reviewer v2

This private v2 supersedes nothing in v1; v1 remains frozen. It makes the three requested schema corrections: moves `compiles` initialization before API validation; checks API method owner against the report's `class` ClassIdentity; and reopens each live source pin in addition to comparing the before/after/finally snapshots.

It also pins every command's wrapper argv, 30-second timeout and effective argv tail; validates the exact CLI, compiler and JADX invocations, JDK legs, empty cwd/sourcepath, `-proc:none`, release-8 settings and full-source paths; requires unique complete API/compile cell grids; confirms only javac/Jarde/JADX commands occurred (no target `java` invocation); and checks full JADX/Jarde source and compiled class inventories. It keeps BCI coverage as a reported finding rather than an acceptance gate: the four maps are physically anchored but omit physical BCI 8.

Run only after root review:

```sh
python3 -B review_baseline.py --out /private/tmp/jarde-looprestore2-baseline-review-root-v2-20261019/review.json
```

The script has only been statically parsed with Python AST. It has not been run on the receipt and does not execute JDK, CLI, Jarde, JADX, Cargo, Git, or target methods.

Frozen receipt SHA256: `dbd183d84d4f3992046db3424e3419aee09c9d6a69aac5e4d5998169bc01a46f`.
Frozen collector v2 SHA256: `093118528661bf15b11e45050922ca4872be7bfdd6a4f11ff5f3c032b32b4af1`.
