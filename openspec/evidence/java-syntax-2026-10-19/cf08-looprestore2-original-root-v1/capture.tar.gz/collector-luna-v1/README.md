# TestLoopRestore2 原始 class 基线 collector（私有准备，未执行）

## 输入事实与范围

Root 已实际完成并接受 Raung 装配。collector 将要求 `--class` 与 `--jar` 的字节分别精确等于已审核输入：class 148 bytes/SHA `4fd1503499a049efa8e736a98de4339b6504973f80208987ed0774073df9c447`，jar 310 bytes/SHA `89d1f82e7a1c46db40ddf1631c750817c0e1f920a06794dd0b4f2a7d64a9ac48`；并再次要求jar仅含 `loops/TestLoopRestore2.class` 且其内容与class路径字节一致。真实装配/物理事实分别 pin 在 `assembly-evidence-pins.json`。

上游JUnit `TestLoopRestore2.test()` 调用了 `disableCompilation()`，只断言输出片段 `while (1 == 0) {`。此次基线**不调用 target method**，也不构造行为等价 oracle；新采集仅观察原输入、API/raw/SourceMap/物理BCI、完整 JADX 源和完整 generated-source 编译。

## 计划命令网格

- Jarde API：单 class 和原始 jar 两种输入，各自 `default` 与显式 `all`，共4次真实 CLI；每份 stdout/stderr/raw JSON、完整 whole-source、方法/质量/fallback/regions/map 和物理事实均记录。两 evidence 请求独立留档，不假定输出逐字相等。
- JADX：对唯一原 class 运行 `--threads-count 1 --no-res --config none`，完整捕获输出目录内所有 Java/class 文件；不裁源码。
- 生成源码编译：每个成功返回的 Jarde API whole-source（4 cell分别保留）和完整 JADX Java source tree，分别由 Corretto JDK8、OpenJDK23 `--release 8`/对应源码级别编译；全程空 classpath/sourcepath，不执行生成 target。失败原样保留；成功只做 class tree、双解析器、方法/字段/Code/BCI census。
- 命令串行经既有 guard 采集原始流，外覆已 pin 的30秒cwd wrapper；每条 argv、有效子argv、JDK/JADX/CLI/helper/工具闭包 pins、source closure before/after/finally、空cwd/sourcepath、5GiB/target1GiB与 target absent 都进 receipt。

脚本使用根传入的实际 class/jar 路径：`collect_baseline.py --class <actual-class> --jar <actual-jar> --out <fresh-out> [--cli <candidate>] [--cli-sha256 <sha>]`。当前候选 CLI 固定为root已给的 SHA `f7ea5a20173b671f94b46fe4304618cd5fcce0b3e0b327eb8c3e891fb92618ba`；如换候选须先新建版本并经root批准，而非编辑本冻结包。

## 已知限制

本 collector 尚未运行，也未通过独立 reviewer。类文件实际是 classfile 45.3，只有 `test([I[I)V` 的24字节 Code/10条指令；这些数来自 accepted physical facts，不代表运行行为。API若缺少方法文本/映射、JADX输出异常、任一编译失败或 parser 不认生成 class 均保留成实际证据，不补方法、不调整源、不将失败算成功。没有target runtime或“等价行为”结论。

Raung 离线依赖闭包来自 root 提供并审阅的 resolve v1/v2/v3 POM：`raung-asm:0.1.1` 直接依赖 `slf4j-api:2.0.11`、`raung-common:0.1.1`、`asm-util:9.6`；`raung-common` 再依赖 `slf4j-api`、`asm:9.6`、`annotations:24.1.0`；`asm-util` 依赖 `asm`、`asm-tree`、`asm-analysis`，后两者按各自 POM 继续依赖 `asm`/`asm-tree`。root 已解出8个JAR闭包，依赖文件及POM均在 `dependency-file-pins.json` pin。这个闭包只用于已装配输入的 provenance，不属于 Jarde target classpath。许可证以 root 的 `dependency-closure-review.json` 为准，不从 artifact 名称推测。
