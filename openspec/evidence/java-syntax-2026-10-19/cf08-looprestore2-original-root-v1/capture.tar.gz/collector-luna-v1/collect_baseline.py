#!/usr/bin/env python3
"""Capture TestLoopRestore2 original/JADX/Jarde API and generated-source compile baseline. Never invokes target methods."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, shutil, sys, time, zipfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
CLI_SHA256 = 'f7ea5a20173b671f94b46fe4304618cd5fcce0b3e0b327eb8c3e891fb92618ba'
CLI_DEFAULT = Path('/private/tmp/jarde-entry-split-clippy-final-build-root-v1-20261019/candidate-cli')
CLI_BUILD_REVIEW = Path('/private/tmp/jarde-entry-split-clippy-final-build-root-v1-20261019/root-review.json')
CLI_BUILD_REVIEW_SHA256 = '2721a911c61c63ae6afa57867e8b075fddeaf378f49dee36e4aaca5e4c1a8f57'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA256 = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA256 = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
COMPARE_REL = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA256 = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
PARSER = Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA256 = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
RUNTIME_WRAPPER = Path('/private/tmp/jarde-testnotindexedloop-baseline-prep-luna-v2-20261019/runtime-bound-cwd.py')
RUNTIME_WRAPPER_SHA256 = 'bc917ec08e07ed462c18958f9a0d3b064b7d5bba3adc5fa41d9db49ff6c3de46'
ASSEMBLY = Path('/private/tmp/jarde-looprestore2-assemble-root-v1-20261019')
ASSEMBLY_SHA256 = '7574e9bc667646d4d48e1b44ca21960ecb0dc51117ec55b5fc5e8de4a227c8c0'
PHYSICAL_FACTS_SHA256 = 'cef2ad2facbad8ceca79c11606c8bde19025fd84cf6b5b77dbdbad2aef985976'
DEPENDENCY_REVIEW_SHA256 = '4fd2b2eabe5080e905c3bb9487767fd7d89e5f9c9c256560ae459816f1aaf455'
CLASS_SHA256 = '4fd1503499a049efa8e736a98de4339b6504973f80208987ed0774073df9c447'
JAR_SHA256 = '89d1f82e7a1c46db40ddf1631c750817c0e1f920a06794dd0b4f2a7d64a9ac48'
INTERNAL = 'loops/TestLoopRestore2'
EXPECTED_METHODS = [('test', '([I[I)V')]
API_FORMS = (('single-class', 'class'), ('plain-jar', 'jar'))
EVIDENCE = ('default', 'all')
TOOL_DIRS = [Path('/private/tmp/jarde-raung-tool-resolve-root-v1-20261019'),
             Path('/private/tmp/jarde-raung-tool-resolve-root-v2-20261019'),
             Path('/private/tmp/jarde-raung-tool-resolve-root-v3-20261019')]


def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def load(path: Path, name: str):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def same_bytes(a: Path,b: Path) -> bool:
    return a.stat().st_size==b.stat().st_size and sha(a)==sha(b)

def class_facts(compare,physical,path:Path,role:str) -> dict:
    facts=compare.parse_class(path); actual=physical.parse_class_file(path.read_bytes())
    if actual['class_name']!=facts['class_name'] or actual['major']!=facts['major'] or actual['methods']!=facts['methods']:
        raise RuntimeError(f'{role}: independent parser method/Code mismatch')
    norm_fields=sorted((x['name'],x['descriptor'],x['access']) for x in actual['fields'])
    if norm_fields!=sorted(facts['fields']): raise RuntimeError(f'{role}: independent field inventory mismatch')
    facts['access']=actual['access']
    if len({(m['name'],m['descriptor']) for m in facts['methods']})!=len(facts['methods']):
        raise RuntimeError(f'{role}: duplicate method identity')
    for m in facts['methods']:
        c=m.get('code')
        if c is not None and (not c.get('bcis') or c['bcis'][0]!=0 or c['bcis'][-1]>=c['code_length']):
            raise RuntimeError(f'{role}: invalid physical BCI inventory')
    return facts

def utf8_boundaries(text:str)->set[int]:
    out={0}; n=0
    for ch in text: n+=len(ch.encode('utf-8')); out.add(n)
    return out

def map_audit(method,physical_method,owner):
    body=method.get('outcome',{}).get('report',{}); text=body.get('text'); sm=body.get('source_map')
    result={'map_present':isinstance(sm,dict),'issues':[]}
    if not isinstance(text,str): result['issues'].append('method text missing'); return result
    raw=text.encode('utf-8'); result['text_bytes']=len(raw)
    if not isinstance(sm,dict) or not isinstance(sm.get('segments'),list):
        result['issues'].append('source map or segments missing'); return result
    bounds=utf8_boundaries(text); valid=set((physical_method or {}).get('code',{}).get('bcis',[])); mapped=set()
    result['segment_count']=len(sm['segments'])
    for i,s in enumerate(sm['segments']):
        a,b=s.get('start'),s.get('end')
        if type(a)is not int or type(b)is not int or not(0<=a<=b<=len(raw)) or a not in bounds or b not in bounds:
            result['issues'].append(f'segment {i} invalid UTF-8 byte bounds'); continue
        origin=s.get('origin')
        if not isinstance(origin,dict) or not isinstance(origin.get('primary'),dict):
            result['issues'].append(f'segment {i} missing primary origin'); continue
        refs=[origin['primary'],*origin.get('derived',[])]
        for ref in refs:
            bci=ref.get('bci')
            if type(bci)is not int or bci not in valid: result['issues'].append(f'segment {i} nonphysical BCI {bci!r}')
            else: mapped.add(bci)
            identity=ref.get('method')
            if isinstance(identity,dict):
                try:
                    name=bytes(identity.get('name',[])).decode('utf-8','strict')
                    desc=bytes(identity.get('descriptor',[])).decode('utf-8','strict')
                except (TypeError,ValueError,UnicodeDecodeError): result['issues'].append(f'segment {i} malformed method identity')
                else:
                    if physical_method and (name,desc)!=(physical_method.get('name'),physical_method.get('descriptor')):
                        result['issues'].append(f'segment {i} maps to another method')
                    if identity.get('owner')!=owner: result['issues'].append(f'segment {i} owner differs from API method')
    result.update({'mapped_bcis':sorted(mapped),'physical_bcis':sorted(valid),
                   'covers_all_method_bcis':bool(valid) and mapped==valid})
    return result

def pin_tree(compare,root:Path):
    return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*.class'))}
def pin_sources(compare,root:Path):
    return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*.java'))}

def main()->int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--class',dest='class_path',type=Path,required=True)
    ap.add_argument('--jar',dest='jar_path',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--cli',type=Path,default=CLI_DEFAULT)
    ap.add_argument('--cli-sha256',default=CLI_SHA256)
    ap.add_argument('--root',type=Path,default=ROOT)
    a=ap.parse_args()
    root=a.root.resolve(strict=True); original=a.class_path.resolve(strict=True); jar=a.jar_path.resolve(strict=True)
    cli=a.cli.resolve(strict=True); out=a.out.resolve()
    if root!=ROOT.resolve(): raise SystemExit('workspace differs from pinned root')
    if a.cli_sha256!=CLI_SHA256 or sha(cli)!=a.cli_sha256: raise SystemExit('final CLI pin mismatch')
    if out.exists(): raise SystemExit(f'refusing existing output directory: {out}')
    if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('target must be absent before capture')
    expected={
      ASSEMBLY/'execution.json':ASSEMBLY_SHA256,
      ASSEMBLY/'physical-facts.json':PHYSICAL_FACTS_SHA256,
      ASSEMBLY/'dependency-closure-review.json':DEPENDENCY_REVIEW_SHA256,
      ASSEMBLY/'TestLoopRestore2.raung':'21857f4a38efbf49a01bb2b7c4738598f83f928e0020b8e4bcb2942dc19fd70f',
      ASSEMBLY/'ExtractLoopRestore2.java':'85fcf26b0c5cd8e3c56fccc36f619fdf95888c14a28ec7d66872678880c3e2d2',
      cli:CLI_SHA256, CLI_BUILD_REVIEW:CLI_BUILD_REVIEW_SHA256, JADX:JADX_SHA256, JADX_JAR:JADX_JAR_SHA256,
      RUNTIME_WRAPPER:RUNTIME_WRAPPER_SHA256,
    }
    for p,h in expected.items():
        if sha(p)!=h: raise SystemExit(f'pin mismatch: {p}')
    cli_review=json.loads(CLI_BUILD_REVIEW.read_text(encoding='utf-8'))
    if cli_review.get('status')!='root_accepted_exact_workflow_clippy_fmt_final_cli_and_one_line_equivalence' or cli_review.get('cli',{}).get('path')!=str(cli) or cli_review.get('cli',{}).get('sha256')!=CLI_SHA256:
        raise SystemExit('final CLI is not bound by the pinned accepted build review')
    if sha(original)!=CLASS_SHA256 or sha(jar)!=JAR_SHA256: raise SystemExit('supplied original class/JAR pins differ')
    compare_path=root/COMPARE_REL; guard_path=root/GUARD_REL; scanner_path=root/SCANNER_REL
    manifest_path=root/JDK_MANIFEST_REL
    for p,h in ((compare_path,COMPARE_SHA256),(guard_path,GUARD_SHA256),(scanner_path,SCANNER_SHA256),(manifest_path,JDK_MANIFEST_SHA256),(PARSER,PARSER_SHA256)):
        if sha(p)!=h: raise SystemExit(f'tool source pin mismatch: {p}')
    compare=load(compare_path,'looprestore2_compare'); guard=load(guard_path,'looprestore2_guard')
    scanner=load(scanner_path,'looprestore2_scanner'); physical=load(PARSER,'looprestore2_physical')
    jdks,jdk_record=compare.configured_jdks(manifest_path,JDK_MANIFEST_SHA256)
    dependency_review=json.loads((ASSEMBLY/'dependency-closure-review.json').read_text())
    if dependency_review.get('status')!='root_reopened_tool_pins_and_all_four_actual_command_streams':
        raise SystemExit('assembly/dependency closure review not accepted')
    dep_pin_file=Path(__file__).with_name('dependency-file-pins.json')
    dep_pins=json.loads(dep_pin_file.read_text())['files']
    for rec in dep_pins:
        p=Path(rec['path'])
        if not p.is_file() or p.stat().st_size!=rec['bytes'] or sha(p)!=rec['sha256']:
            raise SystemExit(f'Raung tool closure pin mismatch: {p}')
    # Independently require the supplied jar to contain exactly the bytes supplied as the class.
    with zipfile.ZipFile(jar) as z:
        class_entries=sorted(n for n in z.namelist() if n.endswith('.class'))
        if class_entries!=[INTERNAL+'.class'] or z.read(INTERNAL+'.class')!=original.read_bytes():
            raise SystemExit('supplied jar does not contain exactly the supplied original class bytes')
    original_facts=class_facts(compare,physical,original,'original Raung class')
    expected_facts=json.loads(Path(__file__).with_name('expected-original-physical-facts.json').read_text())
    # Compare the complete independent physical parser record to the accepted physical census.
    original_physical=physical.parse_class_file(original.read_bytes())
    if json.loads(json.dumps(original_physical,sort_keys=True))!=json.loads(json.dumps(expected_facts,sort_keys=True)):
        raise SystemExit('original physical facts differ from accepted assembly census')
    if original_facts.get('class_name')!=INTERNAL or {(m['name'],m['descriptor']) for m in original_facts['methods']}!=set(EXPECTED_METHODS):
        raise SystemExit('original target identity/method inventory differs')
    source_before=compare.source_closure(root)
    if shutil.disk_usage(root).free<5*1024**3: raise SystemExit('5 GiB free-space guard failed')
    out.mkdir(parents=True); raw=out/'raw'; raw.mkdir()
    original_copy=out/'input/loops/TestLoopRestore2.class'; original_copy.parent.mkdir(parents=True)
    shutil.copy2(original,original_copy)
    jar_copy=out/'input/original.jar'; shutil.copy2(jar,jar_copy)
    if not same_bytes(original,original_copy) or not same_bytes(jar,jar_copy): raise RuntimeError('local input copy differs')
    empty=out/'empty-cwd'; empty.mkdir(); empty_sourcepath=out/'empty-sourcepath'; empty_sourcepath.mkdir()
    runtime_copy=out/RUNTIME_WRAPPER.name; shutil.copy2(RUNTIME_WRAPPER,runtime_copy)
    if not same_bytes(RUNTIME_WRAPPER,runtime_copy): raise RuntimeError('runtime wrapper copy differs')
    guard.ROOT=root; guard.OUT=raw; guard.target_bytes=lambda:scanner.target_bytes(root); guard.command_stream=compare.pin
    guard.expected_test_summaries=lambda idx,data:None
    rows=[]
    local_before={'class':compare.pin(original_copy),'jar':compare.pin(jar_copy),'runtime_wrapper':compare.pin(runtime_copy)}
    tool_paths=[original,jar,cli,JADX,JADX_JAR,compare_path,guard_path,scanner_path,manifest_path,PARSER,
                RUNTIME_WRAPPER,Path(__file__).resolve(),dep_pin_file,CLI_BUILD_REVIEW,ASSEMBLY/'execution.json',
                ASSEMBLY/'physical-facts.json',ASSEMBLY/'dependency-closure-review.json',ASSEMBLY/'TestLoopRestore2.raung',ASSEMBLY/'ExtractLoopRestore2.java']
    def external_snapshot():
        return {'files':[compare.pin(p) for p in tool_paths],
                'raung_tool_files':[compare.pin(Path(x['path'])) for x in dep_pins],
                'jdk_tools':{f'{leg}_{tool}':compare.pin(path) for leg,spec in jdks.items() for tool,path in spec['tools'].items()}}
    external_before=external_snapshot()
    report={'schema':'test-looprestore2-raung-original-baseline-v1','status':'running','root':str(root),'output':str(out),
            'cli':compare.pin(cli),'cli_sha256_expected':a.cli_sha256,'accepted_cli_build_review':compare.pin(CLI_BUILD_REVIEW),'original_class':compare.pin(original),
            'original_jar':compare.pin(jar),'class_entry':INTERNAL+'.class','class_facts':original_facts,
            'accepted_assembly_receipt':compare.pin(ASSEMBLY/'execution.json'),
            'accepted_physical_facts':compare.pin(ASSEMBLY/'physical-facts.json'),
            'dependency_closure_review':compare.pin(ASSEMBLY/'dependency-closure-review.json'),
            'raung_tool_file_pins':dep_pins,'jdk':jdk_record,'compare':compare.pin(compare_path),
            'guard':compare.pin(guard_path),'scanner':compare.pin(scanner_path),'physical_parser':compare.pin(PARSER),
            'runtime_wrapper':compare.pin(runtime_copy),'runtime_wrapper_timeout_seconds':30,
            'input_copies':local_before,'source_pins_before':source_before,'external_input_pins_before':external_before,
            'commands':[],'api_cells':[],'jadx_output':None,'generated_source_compiles':[],
            'notes':['Original target methods are never invoked; the upstream test disables compilation and only asserts decompiled text.',
                     'Jarde API evidence default/all is recorded independently for the single class file and the original jar; no cross-evidence equality is presumed.',
                     'Every returned whole-source artifact is compiled unchanged on both configured JDKs. Compiler failures are preserved; successful outputs receive physical class census only.',
                     'JADX processes the complete original class input with --threads-count 1 --no-res --config none; its complete Java source tree is compiled unchanged on both JDKs.',
                     'All commands are serialized, launched under the existing 30-second cwd wrapper, and captured by the existing disk/target guard.']}
    compare.write_json(out/'execution.json',report)
    def command(argv,label,leg='javac23'):
        if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError('workspace target appeared')
        env=compare.clean_env(dict(os.environ),jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK',None)
        wrapped=[sys.executable,'-B',str(runtime_copy),'30',str(empty),*[str(x) for x in argv]]
        row=guard.run_command(len(rows)+1,wrapped,env); row['label']=label; row['tool_leg']=leg
        row['effective_argv']=[str(x) for x in argv]; rows.append(row); report['commands']=rows
        row['empty_cwd_after'] = not any(empty.iterdir())
        row['empty_sourcepath_after'] = not any(empty_sourcepath.iterdir())
        compare.write_json(out/'execution.json',report)
        if row.get('guard_stop') is not None: raise RuntimeError(f'disk/target guard stopped {label}')
        if not row['empty_cwd_after'] or not row['empty_sourcepath_after']:
            raise RuntimeError(f'command wrote into isolated cwd/sourcepath: {label}')
        return row
    def artifact(row,channel='stdout'): return compare.command_artifact(row,channel)
    def compile_source(source_root,source_files,kind,cell_key):
        for leg in ('javac8','javac23'):
            dest=out/'compile'/kind/cell_key/leg/'classes'; dest.mkdir(parents=True)
            common=['-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty_sourcepath,'-d',dest]
            if leg=='javac8': opts=['-source','8','-target','8','-g']
            else: opts=['--release','8','-g']
            row=command([jdks[leg]['tools']['javac'],*opts,*common,*source_files],f'compile-{kind}-{cell_key}-{leg}',leg)
            facts=[]; parse_errors=[]
            for cls in sorted(dest.rglob('*.class')):
                try: facts.append(class_facts(compare,physical,cls,f'{kind}/{cell_key}/{leg}'))
                except Exception as e: parse_errors.append({'path':str(cls),'error':repr(e),'pin':compare.pin(cls)})
            comp={'kind':kind,'cell_key':cell_key,'compiler':leg,'source_root':str(source_root),
                  'source_files':[compare.pin(p) for p in source_files], 'command':row['index'],'exit_code':row['exit_code'],
                  'class_root':str(dest),'class_tree':pin_tree(compare,dest),'class_facts':facts,'class_parse_errors':parse_errors,
                  'stdout':compare.pin(Path(row['streams']['stdout']['path'])),'stderr':compare.pin(Path(row['streams']['stderr']['path']))}
            report['generated_source_compiles'].append(comp); compare.write_json(out/'execution.json',report)
    try:
        ver=command([JADX,'--version'],'jadx-version')
        if ver['exit_code']!=0 or b'1.5.6' not in (artifact(ver)+artifact(ver,'stderr')): raise RuntimeError('JADX version mismatch')
        # Complete unmodified input class and jar API requests: 2 forms x default/all.
        for form,path,policy in (('class',original_copy,'single-class'),('jar',jar_copy,'plain-jar')):
            for evidence in EVIDENCE:
                argv=[cli,'class-source','--input',path,'--class',INTERNAL,'--policy',policy,'--release','8','--format','json']
                if evidence=='all': argv += ['--evidence','all']
                row=command(argv,f'jarde-{form}-{evidence}')
                raw_json=artifact(row); cell={'input_form':form,'evidence':evidence,'command':row['index'],'exit_code':row['exit_code'],
                    'input':compare.pin(path),'stdout':compare.pin(Path(row['streams']['stdout']['path'])),
                    'stderr':compare.pin(Path(row['streams']['stderr']['path']))}
                try:
                    api=json.loads(raw_json.decode('utf-8','strict')); raw_copy=out/'jarde'/form/evidence/'report.json'
                    raw_copy.parent.mkdir(parents=True); raw_copy.write_bytes(raw_json)
                    text=api.get('text'); cell['report']=compare.pin(raw_copy); cell['raw_report']=api
                    if isinstance(text,str):
                        whole=out/'jarde'/form/evidence/'source/loops/TestLoopRestore2.java'; whole.parent.mkdir(parents=True,exist_ok=True)
                        whole.write_bytes(text.encode('utf-8')); cell['whole_source']=compare.pin(whole)
                        cell['methods']=[]
                        physical_by={(m['name'],m['descriptor']):m for m in original_facts['methods']}
                        for m in api.get('methods',[]):
                            item=m.get('item',{}); name=item.get('name',{}).get('escaped'); desc=item.get('descriptor',{}).get('escaped')
                            identity=m.get('identity',{}); owner=identity.get('owner')
                            key=(name,desc); body=m.get('outcome',{}).get('report',{})
                            summary={'name':name,'descriptor':desc,'identity':identity,'owner':owner,
                                'outcome_kind':m.get('outcome',{}).get('kind'),'quality':body.get('quality'),
                                'fallbacks':body.get('fallbacks'),'regions':body.get('regions'),'raw_text':body.get('text'),
                                'source_map':body.get('source_map'),'map_audit':map_audit(m,physical_by.get(key),owner)}
                            cell['methods'].append(summary)
                        cell['method_inventory']=[(m['name'],m['descriptor']) for m in cell['methods']]
                        cell['method_inventory_matches_original']=sorted(cell['method_inventory'])==sorted(EXPECTED_METHODS)
                    else: cell['whole_source_absent']=True
                except (ValueError,UnicodeDecodeError,TypeError) as e: cell['json_parse_error']=repr(e)
                report['api_cells'].append(cell); compare.write_json(out/'execution.json',report)
                # Compile each API cell's exact returned full source; no rewriting or fallback.
                if row['exit_code']==0 and isinstance(cell.get('whole_source'),dict):
                    src=Path(cell['whole_source']['path'])
                    compile_source(src.parent,[src],'jarde',form+'-'+evidence)
        # Decode the complete original class; no outer source or other class is appended.
        jd=out/'jadx'/'classes'; jd.mkdir(parents=True)
        jr=command([JADX,'--threads-count','1','--no-res','--config','none','-d',jd,original_copy],'jadx-original-class-full')
        java_files=sorted(jd.rglob('*.java'))
        report['jadx_output']={'command':jr['index'],'exit_code':jr['exit_code'],'input':compare.pin(original_copy),
            'source_tree':pin_sources(compare,jd),'class_tree':pin_tree(compare,jd),
            'source_files':[compare.pin(p) for p in java_files]}
        compare.write_json(out/'execution.json',report)
        if jr['exit_code']==0 and java_files:
            compile_source(jd,java_files,'jadx','full-class-tree')
        report['source_pins_after']=compare.source_closure(root)
        report['source_unchanged']=report['source_pins_after']==source_before
        report['external_input_pins_after']=external_snapshot()
        report['external_inputs_unchanged']=report['external_input_pins_after']==external_before
        report['input_copies_after']={'class':compare.pin(original_copy),'jar':compare.pin(jar_copy),'runtime_wrapper':compare.pin(runtime_copy)}
        report['input_copies_unchanged']=all(report['input_copies_after'][k]['sha256']==local_before[k]['sha256'] and report['input_copies_after'][k]['bytes']==local_before[k]['bytes'] for k in local_before)
        report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
        report['counts_derived']={'commands':len(rows),'raw_streams':sum(len(r.get('streams',{})) for r in rows),
            'api_cells':len(report['api_cells']),'jarde_source_compile_attempts':sum(x['kind']=='jarde' for x in report['generated_source_compiles']),
            'jadx_source_compile_attempts':sum(x['kind']=='jadx' for x in report['generated_source_compiles']),
            'compile_successes':sum(x['exit_code']==0 for x in report['generated_source_compiles']),
            'compile_failures':sum(x['exit_code']!=0 for x in report['generated_source_compiles'])}
        if not all((report['source_unchanged'],report['external_inputs_unchanged'],report['input_copies_unchanged'],report['target_absent'])):
            raise RuntimeError('source/tool/input pins changed or target appeared')
        report['status']='captured-pending-independent-review'
    except BaseException as e:
        report['status']='failed'; report['error']=repr(e); raise
    finally:
        try:
            report['source_pins_after_finally']=compare.source_closure(root)
            report['source_unchanged_finally']=report['source_pins_after_finally']==source_before
            report['external_input_pins_after_finally']=external_snapshot()
            report['external_inputs_unchanged_finally']=report['external_input_pins_after_finally']==external_before
            report['input_copies_after_finally']={'class':compare.pin(original_copy),'jar':compare.pin(jar_copy),'runtime_wrapper':compare.pin(runtime_copy)}
            report['input_copies_unchanged_finally']=all(report['input_copies_after_finally'][k]['sha256']==local_before[k]['sha256'] and report['input_copies_after_finally'][k]['bytes']==local_before[k]['bytes'] for k in local_before)
            report['target_absent_finally']=not(root/'target').exists() and not(root/'target').is_symlink()
            if not all((report['source_unchanged_finally'],report['external_inputs_unchanged_finally'],report['input_copies_unchanged_finally'],report['target_absent_finally'])):
                report['status']='failed'; report['final_guard_error']='finally source/external/input/target check failed'
        except BaseException as e: report['status']='failed'; report['final_guard_error']=repr(e)
        report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out/'execution.json',report)
        shutil.copy2(__file__,out/'collector.py')
        print(json.dumps({'status':report['status'],'commands':len(rows),'api_cells':len(report['api_cells']),
                          'compile_attempts':len(report['generated_source_compiles']),'target_absent':report.get('target_absent_finally'),
                          'error':report.get('error')}))
    return 0

if __name__=='__main__': raise SystemExit(main())
