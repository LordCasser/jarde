#!/usr/bin/env python3
"""Pack explicit evidence trees, list named exclusions, and reopen-check every payload member."""
from __future__ import annotations
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import tarfile

ROOT = Path(__file__).resolve().parent
FORBIDDEN_PARTS = {"target", "__pycache__", ".cache", "cache", "Caches", ".pytest_cache", ".mypy_cache"}
FORBIDDEN_NAMES = {"candidate-cli"}
FORBIDDEN_SUFFIXES = {".rlib", ".rmeta", ".dylib", ".so", ".o", ".a", ".dll", ".exe"}
MAX_BYTES = 512 * 1024 * 1024


def fail(message: str) -> None:
    raise SystemExit(f"archive refused: {message}")


def no_symlink_components(path: Path) -> Path:
    absolute = path.absolute()
    for item in (absolute, *absolute.parents):
        if item.is_symlink():
            fail(f"symlink in source path: {item}")
    return absolute


def safe_source(path: Path) -> Path:
    absolute = no_symlink_components(path)
    if not absolute.exists() or not absolute.is_file():
        fail(f"missing/non-regular input file: {absolute}")
    if any(part in FORBIDDEN_PARTS for part in absolute.parts) or absolute.name in FORBIDDEN_NAMES:
        fail(f"excluded cache/build/candidate path requires explicit file exclusion: {absolute}")
    if absolute.suffix.lower() in FORBIDDEN_SUFFIXES:
        fail(f"excluded native build artifact requires explicit file exclusion: {absolute}")
    return absolute


def native_binary(data: bytes, source: Path) -> bool:
    mach_o = data.startswith((b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe",
                              b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe"))
    fat_mach_o = data.startswith(b"\xca\xfe\xba\xbe") and source.suffix.lower() != ".class"
    return data.startswith(b"\x7fELF") or mach_o or fat_mach_o or data.startswith(b"MZ")


def valid_relative_file(value: str) -> PurePosixPath:
    rel = PurePosixPath(value)
    if rel.is_absolute() or ".." in rel.parts or not rel.parts or rel.as_posix() != value:
        fail(f"unsafe/noncanonical relative file path: {value}")
    return rel


def excluded_source(root: Path, rel: PurePosixPath, reason: str) -> dict:
    if not isinstance(reason, str) or not reason.strip():
        fail(f"excluded file needs a non-empty reason: {rel}")
    source = no_symlink_components(root / Path(*rel.parts))
    if not source.exists() or not source.is_file():
        fail(f"excluded input is missing or non-regular: {source}")
    data = source.read_bytes()
    return {"source_path": str(source), "relative_path": rel.as_posix(),
            "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "mode": stat.S_IMODE(source.stat().st_mode), "reason": reason.strip()}


def collect(manifest: Path) -> tuple[dict[str, tuple[Path, bytes, int]], list[dict]]:
    spec = json.loads(manifest.read_text(encoding="utf-8"))
    if spec.get("schema") != "jarde-explicit-evidence-archive-inputs-v1":
        fail("unsupported manifest schema")
    entries = spec.get("directories")
    if not isinstance(entries, list) or not entries:
        fail("manifest must list required directories")
    members: dict[str, tuple[Path, bytes, int]] = {}
    excluded_external_inputs: list[dict] = []

    def add(archive_name: str, source: Path) -> None:
        rel = PurePosixPath(archive_name)
        if rel.is_absolute() or ".." in rel.parts or not rel.parts:
            fail(f"unsafe archive path: {archive_name}")
        name = rel.as_posix()
        if name in members or name == "ARCHIVE_INVENTORY.json":
            fail(f"duplicate/reserved archive path: {name}")
        src = safe_source(source)
        data = src.read_bytes()
        if native_binary(data, src):
            fail(f"native executable/container binary requires explicit file exclusion: {src}")
        members[name] = (src, data, stat.S_IMODE(src.stat().st_mode))

    for entry in entries:
        if not isinstance(entry, dict) or not {"path", "archive_prefix"} <= set(entry) or set(entry) - {"path", "archive_prefix", "excluded_files"}:
            fail("each directory entry needs path/archive_prefix and optional excluded_files")
        root = no_symlink_components(Path(entry["path"]))
        if not root.exists() or not root.is_dir():
            fail(f"required directory missing/non-directory/symlink: {root}")
        prefix = PurePosixPath(entry["archive_prefix"])
        if prefix.is_absolute() or ".." in prefix.parts or not prefix.parts:
            fail(f"unsafe directory archive_prefix: {prefix}")
        raw_exclusions = entry.get("excluded_files", [])
        if not isinstance(raw_exclusions, list):
            fail(f"excluded_files must be a list for {root}")
        exclusions: dict[str, dict] = {}
        for item in raw_exclusions:
            if not isinstance(item, dict) or set(item) != {"relative_path", "reason"}:
                fail("each excluded_files entry needs exactly relative_path and reason")
            rel = valid_relative_file(item["relative_path"])
            if rel.as_posix() in exclusions:
                fail(f"duplicate explicit exclusion: {rel}")
            exclusions[rel.as_posix()] = excluded_source(root, rel, item["reason"])
        excluded_external_inputs.extend(exclusions.values())
        paths = sorted(root.rglob("*"), key=lambda p: p.as_posix())
        if not paths:
            fail(f"required directory is empty: {root}")
        before = len(members)
        for path in paths:
            if path.is_symlink():
                fail(f"symlink in required tree: {path}")
            relative = path.relative_to(root).as_posix()
            if path.is_dir():
                if path.name in FORBIDDEN_PARTS:
                    descendants = [p for p in paths if p.is_file() and path in p.parents]
                    if not descendants or any(p.relative_to(root).as_posix() not in exclusions for p in descendants):
                        fail(f"cache/build directory contains non-explicitly-excluded files: {path}")
                continue
            if not path.is_file():
                fail(f"non-regular entry in required tree: {path}")
            if relative in exclusions:
                continue
            add((prefix / relative).as_posix(), path)
        if len(members) == before:
            fail(f"required directory yielded no payload files after explicit exclusions: {root}")
        found = {p.relative_to(root).as_posix() for p in paths if p.is_file() and not p.is_symlink()}
        if set(exclusions) - found:
            fail(f"explicit exclusions are not files in listed tree: {sorted(set(exclusions)-found)}")

    excluded_sources = [row["source_path"] for row in excluded_external_inputs]
    payload_sources = [str(source) for source, _, _ in members.values()]
    if len(excluded_sources) != len(set(excluded_sources)) or set(excluded_sources) & set(payload_sources):
        fail("an excluded input is duplicated or also included as payload")
    add("tooling/pack.py", Path(__file__))
    add("tooling/pack-manifest.json", manifest.absolute())
    add("tooling/README.md", ROOT / "README.md")
    total = sum(len(data) for _, data, _ in members.values()) + sum(row["bytes"] for row in excluded_external_inputs)
    if total > MAX_BYTES:
        fail(f"payload plus explicit exclusions exceeds {MAX_BYTES} bytes: {total}")
    return members, excluded_external_inputs


def inventory_for(members: dict[str, tuple[Path, bytes, int]], excluded: list[dict]) -> dict:
    rows = []
    for arc, (source, data, mode) in sorted(members.items()):
        rows.append({"archive_path": arc, "source_path": str(source),
                     "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                     "mode": mode})
    return {"schema": "jarde-evidence-archive-inventory-v2",
            "payload_member_count": len(rows), "payload_members": rows,
            "excluded_external_inputs": sorted(excluded, key=lambda row: row["source_path"])}


def pack(manifest: Path, output: Path) -> None:
    output = output.absolute()
    sidecar = output.with_suffix(output.suffix + ".inventory.json")
    if output.exists() or sidecar.exists():
        fail(f"refusing to overwrite archive or inventory: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    members, excluded = collect(manifest.absolute())
    inventory = inventory_for(members, excluded)
    inventory_bytes = (json.dumps(inventory, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()
    with output.open("xb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0, compresslevel=9) as zipped:
            with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as tar:
                for name, (source, data, mode) in sorted(members.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = mode
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    tar.addfile(info, io.BytesIO(data))
                info = tarfile.TarInfo("ARCHIVE_INVENTORY.json")
                info.size = len(inventory_bytes)
                info.mode = 0o644
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                tar.addfile(info, io.BytesIO(inventory_bytes))
    verify(output, inventory, members, excluded)
    with sidecar.open("xb") as inventory_file:
        inventory_file.write(inventory_bytes)
    print(json.dumps({"status": "packed_and_reopened", "archive": str(output),
                      "payload_member_count": len(members),
                      "excluded_external_input_count": len(excluded),
                      "inventory": str(sidecar)}, ensure_ascii=False))


def verify(output: Path, expected: dict, members: dict[str, tuple[Path, bytes, int]], excluded: list[dict]) -> None:
    with tarfile.open(output, mode="r:gz") as tar:
        rows = tar.getmembers()
        names = [row.name for row in rows]
        if len(names) != len(set(names)):
            fail("duplicate archive member")
        if set(names) != set(members) | {"ARCHIVE_INVENTORY.json"}:
            fail("archive contains missing or unexpected members")
        for row in rows:
            if not row.isfile():
                fail(f"non-file archive member: {row.name}")
            data = tar.extractfile(row).read()
            if row.name == "ARCHIVE_INVENTORY.json":
                if data != (json.dumps(expected, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode():
                    fail("embedded inventory mismatch")
                continue
            source, original, mode = members[row.name]
            if data != original or row.size != len(original) or row.mode != mode:
                fail(f"archive member differs from source: {row.name}")
            if hashlib.sha256(data).hexdigest() != hashlib.sha256(source.read_bytes()).hexdigest():
                fail(f"source changed during archive operation: {source}")
    for row in excluded:
        source = Path(row["source_path"])
        data = source.read_bytes()
        if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"] or stat.S_IMODE(source.stat().st_mode) != row["mode"]:
            fail(f"explicitly excluded input changed during archive operation: {source}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path, help="explicit JSON list of required evidence directories")
    parser.add_argument("output", type=Path, help="new archive path; existing files are never overwritten")
    args = parser.parse_args()
    pack(args.manifest, args.output)


if __name__ == "__main__":
    main()
