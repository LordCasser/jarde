# Entry-split final evidence archive tool (preparation only)

`pack.py` is a deterministic, explicit-input packer for the final entry-split evidence closeout. It does not discover evidence directories or run any build/test/CI command. The root agent should create a manifest only after every named final receipt exists and has been reviewed; a missing/empty directory, symlink, duplicate archive path, forbidden cache/build path, native executable, or existing output path makes the pack fail.

The manifest format supports a per-directory exact file exclusion list. An exclusion is a source input retained only in inventory with a required reason; it is not silently discarded:

```json
{
  "schema": "jarde-explicit-evidence-archive-inputs-v1",
  "directories": [
    {
      "path": "/private/tmp/<required-evidence-directory>",
      "archive_prefix": "evidence/<stable-name>",
      "excluded_files": [
        {"relative_path": "candidate-cli", "reason": "pinned external executable; binary intentionally excluded"}
      ]
    }
  ]
}
```

Omit `excluded_files` when the directory has no exact exclusions. Each excluded path must exist beneath that directory as a regular non-symlink file. Its absolute and relative paths, length, SHA-256, mode, and reason are written into `excluded_external_inputs` in the archive inventory. Cache/build directories remain errors unless every file beneath a specific such directory is separately enumerated by exact exclusions; any unlisted cache content still fails. An input directory must retain at least one payload file after exclusions.

List every required directory explicitly. The final plan is expected to cover the Clippy failure receipt, final build, final API rebind source and receipt, both native workspace runs and both root regression reviews, v3 CI/native preparation tools and product binding, final own-CI receipt, final architecture audit once received, and the minimal Clippy patch. Include original stdout/stderr, JSON, and official workflow ZIPs as evidence. Do not include `candidate-cli` as a payload member: declare only that exact regular file in `excluded_files`, with the reason that it is a separately pinned external executable. Cargo `target`, caches, ELF/Mach-O/PE executables, and Rust build products otherwise remain errors. JVM `.class` and source evidence are retained.

Run only after root has supplied and checked the final directory list:

```sh
python3 -B pack.py manifest.json /private/tmp/<new-final-archive>/capture.tar.gz
```

The packer records each payload source’s absolute path, archive-relative path, byte length, SHA-256, and mode in an embedded inventory and sidecar, and records each exact excluded external input with those source facts plus its reason. It uses sorted paths, normalized tar metadata, and a zero-timestamp gzip stream. It then reopens the archive and requires the exact member set with no duplicates or extras, byte-for-byte payload equality, digest/length/mode equality, and exact embedded-inventory equality. It never silently skips missing inputs. This tool has not been run on final evidence.

The v3 acceptance-prep wording correction is: the product changes **five Rust paths plus fingerprint JSON**, rather than six Rust paths. The private v3 README remains frozen; the correction is recorded here for the final archive README/handoff.
