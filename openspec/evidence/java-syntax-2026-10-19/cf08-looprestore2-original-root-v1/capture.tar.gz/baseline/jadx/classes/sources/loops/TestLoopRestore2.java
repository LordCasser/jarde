package loops;

/* JADX INFO: loaded from: TestLoopRestore2.class */
public class TestLoopRestore2 {
    public void test(int[] iArr, int[] iArr2) {
        if (0 != 0) {
            while (1 == 0) {
            }
        }
        int i = 0 + 1;
    }
}
