#!/usr/bin/env python3
"""Independent read-only audit of the frozen TestLoopRestore2 baseline receipt."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, sys
from pathlib import Path

RECEIPT = Path('/private/tmp/jarde-looprestore2-baseline-root-v1-20261019/execution.json')
RECEIPT_SHA = 'dbd183d84d4f3992046db3424e3419aee09c9d6a69aac5e4d5998169bc01a46f'
COLLECTOR = Path('/private/tmp/jarde-looprestore2-baseline-root-v1-20261019/collector.py')
COLLECTOR_SHA = '093118528661bf15b11e45050922ca4872be7bfdd6a4f11ff5f3c032b32b4af1'
EXPECTED = {
    'schema': 'test-looprestore2-raung-original-baseline-v1',
    'class_sha256': '4fd1503499a049efa8e736a98de4339b6504973f80208987ed0774073df9c447',
    'jar_sha256': '89d1f82e7a1c46db40ddf1631c750817c0e1f920a06794dd0b4f2a7d64a9ac48',
}

def sha(p: Path) -> str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def norm(x): return json.loads(json.dumps(x,sort_keys=True))
def loadmod(path,name):
    s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m

def pin(rec):
    p=Path(rec['path'])
    return p.is_file() and p.stat().st_size==rec['bytes'] and sha(p)==rec['sha256']

def reopen_nested_pins(value):
    if isinstance(value,dict):
        if {'path','bytes','sha256'} <= value.keys(): return [pin(value)]
        out=[]
        for v in value.values(): out.extend(reopen_nested_pins(v))
        return out
    if isinstance(value,list):
        out=[]
        for v in value: out.extend(reopen_nested_pins(v))
        return out
    return []

def verified_facts(compare,physical,path):
    f=compare.parse_class(path); p=physical.parse_class_file(path.read_bytes())
    if p.get('class_name')!=f.get('class_name') or p.get('major')!=f.get('major') or p.get('methods')!=f.get('methods'):
        raise ValueError('independent parser class/method facts disagree')
    if sorted((x['name'],x['descriptor'],x['access']) for x in p.get('fields',[]))!=sorted(f.get('fields',[])):
        raise ValueError('independent parser field facts disagree')
    f['access']=p['access']
    return f,p

def add(errors,condition,msg):
    if not condition: errors.append(msg)

def utf8_bounds(s):
    out={0}; n=0
    for c in s: n+=len(c.encode('utf-8')); out.add(n)
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--receipt',type=Path,default=RECEIPT)
    ap.add_argument('--out',type=Path,required=True)
    a=ap.parse_args(); errors=[]; observations={}
    raw=a.receipt.read_bytes(); z=json.loads(raw)
    add(errors,sha(a.receipt)==RECEIPT_SHA,'receipt SHA differs from frozen capture')
    add(errors,sha(COLLECTOR)==COLLECTOR_SHA,'collector SHA differs from frozen capture')
    add(errors,z.get('schema')==EXPECTED['schema'],'unexpected receipt schema')
    add(errors,z.get('status')=='captured-pending-independent-review','receipt is not captured-pending')
    add(errors,z.get('cli_sha256_expected')==z.get('cli',{}).get('sha256'),'CLI expected/actual pin mismatch')
    # Reopen all named input/tool pins and all three snapshots. Keep source and external closures separate.
    for key in ('accepted_cli_build_review','original_class','original_jar','accepted_assembly_receipt','accepted_physical_facts','dependency_closure_review','compare','guard','scanner','physical_parser','runtime_wrapper'):
        rec=z.get(key,{})
        add(errors,pin(rec),f'{key} pin does not reopen')
    add(errors,z.get('original_class',{}).get('sha256')==EXPECTED['class_sha256'],'original class is not frozen input')
    add(errors,z.get('original_jar',{}).get('sha256')==EXPECTED['jar_sha256'],'original jar is not frozen input')
    add(errors,z.get('dependency_closure_review',{}).get('sha256') is not None,'dependency closure review pin absent')
    add(errors,all(pin(x) for x in z.get('raung_tool_file_pins',[])),'one or more Raung dependency pins do not reopen')
    live_records=list(z.get('source_pins_before',{}).values())
    add(errors,all(isinstance(x,dict) and isinstance(x.get('path'),str) and type(x.get('bytes')) is int and isinstance(x.get('sha256'),str) and len(x['sha256'])==64 for x in live_records),'live source snapshot records malformed')
    add(errors,all(reopen_nested_pins(z.get('external_input_pins_before',{}))),'one or more external source/tool pins do not reopen')
    add(errors,all(reopen_nested_pins(z.get('input_copies',{}))),'one or more copied input pins do not reopen')
    add(errors,norm(z.get('source_pins_before'))==norm(z.get('source_pins_after'))==norm(z.get('source_pins_after_finally')),'live source snapshots differ')
    add(errors,z.get('source_unchanged') is True and z.get('source_unchanged_finally') is True,'source unchanged flags false')
    add(errors,norm(z.get('external_input_pins_before'))==norm(z.get('external_input_pins_after'))==norm(z.get('external_input_pins_after_finally')),'external input snapshots differ')
    add(errors,z.get('external_inputs_unchanged') is True and z.get('external_inputs_unchanged_finally') is True,'external input unchanged flags false')
    add(errors,norm(z.get('input_copies'))==norm(z.get('input_copies_after'))==norm(z.get('input_copies_after_finally')),'captured input copies differ')
    add(errors,z.get('input_copies_unchanged') is True and z.get('input_copies_unchanged_finally') is True,'input copy unchanged flags false')
    add(errors,z.get('target_absent') is True and z.get('target_absent_finally') is True,'target directory was not absent')
    add(errors, len(z.get('commands',[]))==16,'expected 16 captured commands')
    commands=z.get('commands',[]); byidx={c.get('index'):c for c in commands}
    add(errors,len(byidx)==len(commands) and sorted(byidx)==list(range(1,17)),'command indexes are incomplete or duplicate')
    expected_labels={'jadx-version','jarde-class-default','compile-jarde-class-default-javac8','compile-jarde-class-default-javac23','jarde-class-all','compile-jarde-class-all-javac8','compile-jarde-class-all-javac23','jarde-jar-default','compile-jarde-jar-default-javac8','compile-jarde-jar-default-javac23','jarde-jar-all','compile-jarde-jar-all-javac8','compile-jarde-jar-all-javac23','jadx-original-class-full','compile-jadx-full-class-tree-javac8','compile-jadx-full-class-tree-javac23'}
    add(errors,{c.get('label') for c in commands}==expected_labels,'captured command label inventory differs')
    stream_count=0
    for c in commands:
        add(errors,c.get('exit_code') is not None and c.get('guard_stop') is None,f"command {c.get('index')} lacks normal terminal result")
        add(errors,c.get('empty_cwd_after') is True and c.get('empty_sourcepath_after') is True,f"command {c.get('index')} cwd/sourcepath guard failed")
        add(errors,c.get('free_bytes_after',0)>=5*1024**3,f"command {c.get('index')} free-space guard below 5 GiB")
        add(errors,c.get('peak_target_bytes',0)<=1024**3,f"command {c.get('index')} target-size guard exceeded")
        for s in c.get('streams',{}).values():
            stream_count+=1; add(errors,pin(s),f"command {c.get('index')} raw stream pin fails")
    add(errors,stream_count==32,'raw stdout/stderr stream count differs from 32')
    observations['commands']=[{'index':c['index'],'label':c.get('label'),'exit_code':c.get('exit_code'),'argv':c.get('argv')} for c in commands]
    # Original class and JAR must still be exactly the captured one-class input.
    cp=Path(z['original_class']['path']); jp=Path(z['original_jar']['path'])
    import zipfile
    with zipfile.ZipFile(jp) as jar:
        entries=sorted(n for n in jar.namelist() if n.endswith('.class'))
        add(errors,entries==[z['class_entry']],'original jar class-entry inventory differs')
        add(errors,jar.read(z['class_entry'])==cp.read_bytes(),'class bytes in jar differ from standalone original')
    compare=loadmod(Path(z['compare']['path']),'review_compare')
    physical=loadmod(Path(z['physical_parser']['path']),'review_physical')
    facts,phy=verified_facts(compare,physical,cp)
    add(errors,norm(facts)==norm(z.get('class_facts')),'receipt original class facts differ from reopened class')
    accepted_phys=json.loads(Path(z['accepted_physical_facts']['path']).read_text())
    add(errors,norm(phy)==norm(accepted_phys),'reopened original physical facts differ from accepted assembly census')
    assembly=json.loads(Path(z['accepted_assembly_receipt']['path']).read_text())
    add(errors,assembly.get('status')=='original_class_assembled_and_physically_inspected' and assembly.get('target_absent') is True,'accepted assembly receipt status/target guard differs')
    closure=json.loads(Path(z['dependency_closure_review']['path']).read_text())
    add(errors,closure.get('status')=='root_reopened_tool_pins_and_all_four_actual_command_streams','dependency closure review is not accepted')
    expected_methods={(m['name'],m['descriptor']) for m in facts['methods']}
    add(errors,expected_methods=={('test','([I[I)V')},'original physical method inventory differs')
    observations['original_class']={'class_name':facts['class_name'],'major':facts['major'],'methods':facts['methods'],'fields':facts['fields']}
    # Raw API JSON, stdout, report file, and physical BCI map are checked independently.
    add(errors,len(z.get('api_cells',[]))==4,'API cell count differs')
    api_out=[]
    for cell in z.get('api_cells',[]):
        form,evidence=cell['input_form'],cell['evidence']; key=f'{form}-{evidence}'
        cmd=byidx.get(cell.get('command'),{}); rawbytes=Path(cell['stdout']['path']).read_bytes()
        add(errors,cell.get('exit_code')==0 and cmd.get('exit_code')==0,f'{key} API did not exit 0')
        add(errors,rawbytes==Path(cell['report']['path']).read_bytes(),f'{key} stdout/report bytes differ')
        add(errors,pin(cell['report']),f'{key} report file pin fails')
        add(errors,Path(cell['input']['path']).read_bytes()==(cp.read_bytes() if form=='class' else jp.read_bytes()),f'{key} API input bytes differ from pinned original')
        parsed=json.loads(rawbytes)
        add(errors,norm(parsed)==norm(cell['raw_report']),f'{key} embedded raw report differs from stdout')
        argv=cmd.get('effective_argv',[])
        add(errors,z['cli']['path'] in argv,f'{key} argv does not invoke pinned CLI')
        add(errors,'--input' in argv and argv[argv.index('--input')+1]==cell['input']['path'],f'{key} argv input path differs from pinned cell input')
        add(errors,'--class' in argv and argv[argv.index('--class')+1]==facts['class_name'],f'{key} argv class identity differs')
        add(errors,('--evidence' in argv)==(evidence=='all'),f'{key} evidence selector mismatch')
        add(errors,('single-class' in argv)==(form=='class'),f'{key} input form mismatch')
        add(errors,('plain-jar' in argv)==(form=='jar'),f'{key} jar/class source mismatch')
        methods=parsed.get('methods',[])
        add(errors,parsed.get('outcome')=='performed',f'{key} class report outcome differs')
        add(errors,len(methods)==1,f'{key} method count differs')
        cell_maps=[]
        for m in methods:
            ident=m.get('item',{}).get('identity',{})
            name=bytes(ident.get('name',[])).decode('utf-8','strict')
            desc=bytes(ident.get('descriptor',[])).decode('utf-8','strict')
            owner=ident.get('owner')
            owner_expected=parsed.get('class',{}).get('declaration',{}).get('item',{}).get('definition')
            pm=next((x for x in facts['methods'] if (x['name'],x['descriptor'])==(name,desc)),None)
            add(errors,pm is not None,f'{key} API method has no physical owner method')
            add(errors,owner is not None and owner==owner_expected,f'{key} API owner differs from containing class identity')
            rep=m.get('outcome',{}).get('report',{}); text=rep.get('text'); sm=rep.get('source_map')
            add(errors,m.get('outcome',{}).get('kind')=='recovered' and rep.get('quality')=='structured' and rep.get('content')=='contains_statements',f'{key} method recovery quality/status differs')
            audit={'method':name+desc,'source_map_present':isinstance(sm,dict),'issues':[]}
            if isinstance(text,str) and isinstance(sm,dict) and isinstance(sm.get('segments'),list) and pm:
                rawtext=text.encode('utf-8'); bounds=utf8_bounds(text); valid=set(pm.get('code',{}).get('bcis',[])); mapped=set()
                for i,seg in enumerate(sm['segments']):
                    x,y=seg.get('start'),seg.get('end')
                    if type(x)is not int or type(y)is not int or not(0<=x<=y<=len(rawtext)) or x not in bounds or y not in bounds:
                        audit['issues'].append(f'segment {i} invalid UTF-8 bounds'); continue
                    origin=seg.get('origin',{}); refs=[]
                    if isinstance(origin.get('primary'),dict): refs.append(origin['primary'])
                    refs.extend(r for r in origin.get('derived',[]) if isinstance(r,dict))
                    for ref in refs:
                        bci=ref.get('bci')
                        if type(bci)is not int or bci not in valid: audit['issues'].append(f'segment {i} BCI {bci!r} is not physical')
                        else: mapped.add(bci)
                        mid=ref.get('method',{}); ownerid=mid.get('owner')
                        try: mn=bytes(mid.get('name',[])).decode(); md=bytes(mid.get('descriptor',[])).decode()
                        except Exception: audit['issues'].append(f'segment {i} method identity malformed')
                        else:
                            if (mn,md)!=(name,desc): audit['issues'].append(f'segment {i} method identity differs')
                            if ownerid!=owner: audit['issues'].append(f'segment {i} owner differs')
                audit['physical_bcis']=sorted(valid); audit['mapped_bcis']=sorted(mapped)
                audit['unmapped_bcis']=sorted(valid-mapped)
                # This is intentionally an observation, not a pass condition: BCI 8 is absent.
                cell_maps.append(audit)
                add(errors,not audit['issues'],f'{key} has malformed/nonphysical source-map anchors')
            else:
                audit['issues'].append('raw method text/map missing'); cell_maps.append(audit)
                errors.append(f'{key} raw method text/map missing')
        api_out.append({'key':key,'class_text':parsed.get('text'),'method_maps':cell_maps})
    keyed={x['key']:x for x in api_out}
    for form in ('class','jar'):
        d=keyed.get(f'{form}-default'); al=keyed.get(f'{form}-all')
        add(errors,d is not None and al is not None and d.get('class_text')==al.get('class_text'),f'{form} default/all class text differs')
        if d and al and d.get('method_maps') and al.get('method_maps'):
            add(errors,d['method_maps'][0]['mapped_bcis']==al['method_maps'][0]['mapped_bcis'],f'{form} default/all physical map differs')
    # Bind each API whole source text to the corresponding untouched source file used by javac.
    for c in compiles:
        if c['kind']=='jarde':
            cell_key=c['cell_key']; api=keyed.get(cell_key)
            if api and c.get('source_files'):
                source=Path(c['source_files'][0]['path']).read_text(encoding='utf-8')
                add(errors,api.get('class_text')==source,f'{cell_key} API whole text differs from compiled full source file')
    # Reopen the full single-class JADX source tree, regardless of later compiler errors.
    jd=z.get('jadx_output',{}); add(errors,jd.get('exit_code')==0,'JADX extraction did not complete')
    add(errors,pin(jd.get('input',{})),'JADX original input pin fails')
    jadx_files=jd.get('source_tree',{})
    add(errors,bool(jadx_files) and all(pin(x) for x in jadx_files.values()),'JADX full source-tree pin is incomplete')
    observations['jadx_source_tree']=sorted(jadx_files)
    observations['api_cells']=api_out
    # Preserve all full-source compile results and check complete copied source bytes / physical class trees.
    compiles=z.get('generated_source_compiles',[]); add(errors,len(compiles)==10,'compile-cell count differs from 10')
    compile_summary=[]
    for c in compiles:
        kind,key,compiler=c['kind'],c['cell_key'],c['compiler']; summary={'kind':kind,'cell_key':key,'compiler':compiler,'exit_code':c['exit_code'],'class_tree':sorted(c.get('class_tree',{})),'errors':[]}
        add(errors,len(c.get('source_files',[]))==1,f'{kind}/{key}/{compiler} source file inventory differs')
        for src in c.get('source_files',[]): add(errors,pin(src),f'{kind}/{key}/{compiler} source pin fails')
        cc=byidx.get(c['command']); add(errors,cc is not None and cc.get('exit_code')==c['exit_code'],f'{kind}/{key}/{compiler} command result mismatch')
        for cl in c.get('class_facts',[]):
            p=Path(cl['path']); add(errors,pin(cl),f'{kind}/{key}/{compiler} compiled class pin fails')
            if p.is_file():
                cf,pf=verified_facts(compare,physical,p)
                add(errors,norm(cf)==norm(cl),f'{kind}/{key}/{compiler} recorded facts differ from class bytes')
        expected_tree={Path(cl['path']).relative_to(Path(c['class_root'])).as_posix() for cl in c.get('class_facts',[])}
        add(errors,set(c.get('class_tree',{}))==expected_tree,f'{kind}/{key}/{compiler} class-tree and facts inventories differ')
        stderr_rec=c.get('stderr') or {}
        if stderr_rec and Path(stderr_rec.get('path','')).is_file(): summary['stderr_excerpt']=Path(stderr_rec['path']).read_text(errors='replace')[:1000]
        compile_summary.append(summary)
    add(errors,sum(c['kind']=='jarde' and c['exit_code']==0 for c in compiles)==8,'Jarde compile success inventory differs')
    add(errors,sum(c['kind']=='jadx' and c['exit_code']!=0 for c in compiles)==2,'JADX compile failure inventory differs')
    observations['generated_source_compiles']=compile_summary
    # Report the known map gap without treating it as a failure of the rest of this audit.
    missing=[]
    for cell in api_out:
        for m in cell['method_maps']:
            if m.get('unmapped_bcis'): missing.append({'cell':cell['key'],'method':m['method'],'bcis':m['unmapped_bcis']})
    observations['source_map_coverage_gaps']=missing
    observations['limitations']=['No target method was run; compiler output does not prove runtime equivalence.',
        'Source maps are physically valid where present, but physical BCI 8 is unmapped in the four API cells; coverage is incomplete.']
    result={'schema':'looprestore2-independent-baseline-review-v1','receipt':str(a.receipt),'receipt_sha256':sha(a.receipt),'status':'reviewed_with_observed_gap' if not errors else 'review_errors','errors':errors,'observations':observations}
    a.out.parent.mkdir(parents=True,exist_ok=True); a.out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'status':result['status'],'errors':len(errors),'source_map_gaps':missing,'out':str(a.out)},ensure_ascii=False))
    return 0 if not errors else 1
if __name__=='__main__': raise SystemExit(main())
