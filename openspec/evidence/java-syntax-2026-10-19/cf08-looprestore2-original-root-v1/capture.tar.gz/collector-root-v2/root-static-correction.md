root读实际历史API后更正方法identity的路径：m.item.identity，而非m.identity。新增owner/name/descriptor交叉检查；v1未执行且冻结。其余collector逐字不变，未执行任何额外target方法。
