# TestLoopRestore2 Raung class extraction — private prep v3

Offline API inspection completed from the exact tool files root supplied. No Java/Gradle/JDK/JADX/Jarde/Jarde CLI/Cargo/Git/network command was run. Shared sources were not edited.

## Inputs and API

The frozen `.raung` source remains the upstream file under `upstream/`; `source-pins-v2.json` preserves its path/hash and the upstream test/API callers. The exact upstream class directive names `loops/TestLoopRestore2`. The local caller `RaungConvert` passes a temporary `Path` output and `List<Path>` input through `RaungAsm.create().output(...).inputs(...).execute()`.

The supplied `raung-asm:0.1.1` sources now confirm the exact public signatures and error contract; see `api-evidence.md` and the extracted source files. `ExtractLoopRestore2.java` uses the verified API (the actual file is `ExtractLoopRestore2.java`). The POM declares MIT and no parent. Use Maven coordinate `io.github.skylot:raung-asm:0.1.1`; the POM supplies compile dependencies `slf4j-api:2.0.11`, `raung-common:0.1.1`, and `asm-util:9.6`. Resolve transitive dependencies through their POMs; their metadata/licenses were not part of the supplied artifact trio. This tool belongs only to an isolated evidence harness, not Jarde's target dependency graph.

## Planned execution, not performed here

1. Run the harness in a private evidence directory with exactly the pinned `.raung` file and an output path ending `.jar`. A normal `execute()` return and existence of the output file indicate assembler completion; exceptions are runtime failures and must remain visible.
2. Run `python3 extract_unique_class.py <jar> <class-output> <manifest-output>`. It accepts only a JAR with exactly one `.class` entry, named `loops/TestLoopRestore2.class`, then records raw JAR/class SHA-256 and sizes. No extracted bytes or classfile census are claimed yet.
3. Reopen the emitted class with the existing physical classfile parser and record class/method/Code/BCI facts before any Jarde inspection. This is a future step, not verified in this prep.

The upstream JUnit test calls `disableCompilation()` and asserts only the source fragment `while (1 == 0) {`. It does not execute a runtime-equivalence oracle. Assembling the JVM class will establish a reproducible input only; it does not change that evidence boundary.

## Artifact hashes

See `artifact-pins.json` for SHA-256 of the exact supplied POM, binary jar, sources jar, source files, and prepared harness/scripts. The prior v1/v2 private prep remains unchanged; v2's open question about API confirmation is closed by this source inspection, but no assembler execution has occurred.
