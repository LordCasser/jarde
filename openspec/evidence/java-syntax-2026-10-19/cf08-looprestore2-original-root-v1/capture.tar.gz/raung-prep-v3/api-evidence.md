# raung-asm 0.1.1 API evidence (offline source inspection)

Source: `artifacts/raung-asm-0.1.1-sources.jar` (SHA-256 in `artifact-pins.json`). The exact public signatures are in `artifact-sources/io/github/skylot/raung/asm/api/IRaungAsm.java`:

- `RaungAsm.create()` returns `IRaungAsm`.
- `IRaungAsm.output(Path)` returns `IRaungAsm`.
- `IRaungAsm.inputs(List<Path>)` returns `IRaungAsm`.
- `IRaungAsm.execute()` returns `void`.

`RaungAsmBuilder.execute()` delegates to `RaungAsmExecutor.process(this)`. `process` runs argument validation and dispatches by output extension; `.jar` invokes jar output. Failures are thrown, not returned as a boolean: `RaungAsmException extends RuntimeException`; IO failures during jar creation are wrapped as `RaungAsmException("Process failed", cause)`, while input/argument/parser failures may throw their own `RaungAsmException`. Thus harness success is normal return plus the output-file check; exceptions must make the Java process fail. The local JADX `RaungConvert` caller independently shows the same fluent call, with `tmpJar: Path` and `raungInputs: List<Path>`.

POM coordinate: `io.github.skylot:raung-asm:0.1.1`; it has no `<parent>` and declares MIT. Direct compile dependencies are `org.slf4j:slf4j-api:2.0.11`, `io.github.skylot:raung-common:0.1.1`, and `org.ow2.asm:asm-util:9.6`. The POM's transitive dependencies must be resolved normally; their own POMs/licenses were not supplied here. No parent POM inheritance is required: depend on the exact artifact coordinate and let its POM supply dependencies. This standalone harness must not be added as a Jarde target dependency.
