import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;

import io.github.skylot.raung.asm.RaungAsm;

/** Minimal isolated assembler driver; source/API verified from raung-asm 0.1.1. */
public final class ExtractLoopRestore2 {
    private ExtractLoopRestore2() { }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            throw new IllegalArgumentException("expected input.raung output.jar");
        }
        Path input = Paths.get(args[0]).toAbsolutePath();
        Path output = Paths.get(args[1]).toAbsolutePath();
        List<Path> inputs = Collections.singletonList(input);
        RaungAsm.create()
                .output(output)
                .inputs(inputs)
                .execute();
        if (!Files.isRegularFile(output)) {
            throw new IllegalStateException("assembler returned without creating output jar: " + output);
        }
    }
}
