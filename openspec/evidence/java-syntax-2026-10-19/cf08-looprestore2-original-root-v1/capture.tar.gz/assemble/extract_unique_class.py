#!/usr/bin/env python3
"""Extract the single expected class from an already-produced Raung jar.
This performs no assembly and does not validate classfile semantics.
"""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

EXPECTED = "loops/TestLoopRestore2.class"

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("jar", type=Path)
    p.add_argument("output_class", type=Path)
    p.add_argument("manifest", type=Path)
    a = p.parse_args()
    jar = a.jar.resolve(strict=True)
    with ZipFile(jar) as zf:
        classes = sorted(n for n in zf.namelist() if n.endswith(".class"))
        if classes != [EXPECTED]:
            raise SystemExit(f"expected exactly {EXPECTED!r}; found {classes!r}")
        info = zf.getinfo(EXPECTED)
        if info.is_dir():
            raise SystemExit("expected class entry is a file")
        data = zf.read(EXPECTED)
    out = a.output_class.resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(data)
    manifest = {
        "schema": "looprestore2-raung-class-extraction-v1",
        "jar": {"path": str(jar), "bytes": jar.stat().st_size,
                "sha256": sha256(jar.read_bytes())},
        "entry": EXPECTED,
        "class": {"path": str(out), "bytes": len(data), "sha256": sha256(data)},
        "class_entries": classes,
        "assembled": True,
        "runtime_oracle": False,
    }
    a.manifest.write_text(json.dumps(manifest, indent=2) + "\n")

if __name__ == "__main__":
    main()
