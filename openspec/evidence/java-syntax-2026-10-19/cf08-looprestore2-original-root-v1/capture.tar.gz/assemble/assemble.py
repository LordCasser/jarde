from pathlib import Path
import json,hashlib,subprocess,datetime,os,importlib.util,shutil,xml.etree.ElementTree as ET
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path(__file__).parent
PREP=Path('/private/tmp/jarde-looprestore2-raung-extraction-luna-v3-20261019')
def pin(p):
 p=Path(p).resolve(strict=True);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p,name):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
cmp=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','cmp')
jdks,jdkpin=cmp.configured_jdks(ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json','ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
jdk=jdks['javac23'];env=cmp.clean_env(os.environ.copy(),jdk)
assert not (ROOT/'target').exists()
jars=[];toolmeta=[]
for ver in [1,2,3]:
 d=Path('/private/tmp/jarde-raung-tool-resolve-root-v'+str(ver)+'-20261019');rows=json.loads((d/'downloads.json').read_bytes())
 for r in rows:
  assert r['http_status']==200 and pin(r['path'])=={k:r[k] for k in ['path','bytes','sha256']}
  toolmeta.append(r)
  if r['path'].endswith('.jar') and not r['path'].endswith('-sources.jar'):jars.append(r['path'])
assert len(jars)==8
sourcepin=json.loads((PREP/'source-pins-v2.json').read_bytes());src=PREP/'upstream/TestLoopRestore2.raung'
for r in sourcepin['files']:
 b=Path(r['source']).read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
assert src.read_bytes()==Path(sourcepin['files'][0]['source']).read_bytes()
for name in ['ExtractLoopRestore2.java','extract_unique_class.py']:
 shutil.copyfile(PREP/name,OUT/name)
shutil.copyfile(src,OUT/'TestLoopRestore2.raung')
empty=OUT/'empty-cwd';empty.mkdir();classes=OUT/'tool-classes';classes.mkdir();raw=OUT/'raw';raw.mkdir()
record={'status':'running','tool_dependencies':toolmeta,'source_pins':sourcepin,'jdk':jdkpin,'harness':pin(OUT/'ExtractLoopRestore2.java'),'input':pin(OUT/'TestLoopRestore2.raung'),'commands':[],'scope':'assemble original Raung input only; no target code execution'}
def run(argv):
 i=len(record['commands']);so=raw/(str(i)+'.stdout.raw');se=raw/(str(i)+'.stderr.raw');row={'argv':list(map(str,argv)),'cwd':str(empty),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with so.open('xb') as f,se.open('xb') as e:r=subprocess.run(row['argv'],cwd=empty,env=env,stdout=f,stderr=e,timeout=30)
 row.update({'exit_code':r.returncode,'stdout':pin(so),'stderr':pin(se)});record['commands'].append(row);(OUT/'execution.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,row
try:
 run([jdk['tools']['javac'],'--release','8','-proc:none','-cp',os.pathsep.join(jars),'-sourcepath',empty,'-d',classes,OUT/'ExtractLoopRestore2.java'])
 run([jdk['tools']['java'],'-Xverify:all','-cp',os.pathsep.join([str(classes)]+jars),'ExtractLoopRestore2',OUT/'TestLoopRestore2.raung',OUT/'original.jar'])
 run(['python3','-B',OUT/'extract_unique_class.py',OUT/'original.jar',OUT/'original-classes/loops/TestLoopRestore2.class',OUT/'extraction.json'])
 parser=load(Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py'),'physical')
 facts=parser.parse_class_file((OUT/'original-classes/loops/TestLoopRestore2.class').read_bytes());(OUT/'physical-facts.json').write_text(json.dumps(facts,indent=2)+'\n')
 run([jdk['tools']['javap'],'-p','-v','-c',OUT/'original-classes/loops/TestLoopRestore2.class'])
 record.update({'status':'original_class_assembled_and_physically_inspected','original_jar':pin(OUT/'original.jar'),'original_class':pin(OUT/'original-classes/loops/TestLoopRestore2.class'),'physical_facts':pin(OUT/'physical-facts.json'),'target_absent':not (ROOT/'target').exists()})
except Exception as e:record['failure']=repr(e);record['status']='failed';raise
finally:(OUT/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':record['status'],'commands':len(record['commands']),'original_class':record.get('original_class')}))
