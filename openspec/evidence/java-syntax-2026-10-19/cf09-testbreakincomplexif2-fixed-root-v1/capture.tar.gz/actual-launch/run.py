import datetime,hashlib,json,subprocess,time
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
assert not (ROOT/'target').exists()
argv=['python3','-B','/private/tmp/jarde-testbreakincomplexif2-final-candidate-prep-luna-v1-20261019/collect_final.py','--out','/private/tmp/jarde-testbreakincomplexif2-final-candidate-root-v1-20261019','--cli','/private/tmp/jarde-loop-header-body-boundary-focused-root-v5-20261019/candidate-cli','--cli-sha256','52ff01f7794c962f2fbb9d809612c0cc371ef297de8cb32a29629323d168cbca']
start=time.monotonic();utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (OUT/'stdout.raw').open('xb') as a,(OUT/'stderr.raw').open('xb') as b: x=subprocess.run(argv,cwd=ROOT,stdout=a,stderr=b)
r={'argv':argv,'cwd':str(ROOT),'started_utc':utc,'duration_seconds':time.monotonic()-start,'exit_code':x.returncode,'stdout_sha256':hashlib.sha256((OUT/'stdout.raw').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((OUT/'stderr.raw').read_bytes()).hexdigest()}
(OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(x.returncode)
