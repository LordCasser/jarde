// jarde: presentation of `jadx/tests/integration/loops/TestBreakInComplexIf2$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestBreakInComplexIf2$TestCls extends java.lang.Object {
    public TestBreakInComplexIf2$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestBreakInComplexIf2$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    // jarde: generic Signature projection refused for `test(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    private int test(java.util.List list) {
        // @method test(Ljava/util/List;)I
        // @declaration an instance method of `jadx.tests.integration.loops.TestBreakInComplexIf2$TestCls`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        int length;
        length = 0;
        for (java.lang.Object iteratorElement19 : list) {
            java.lang.String str = (java.lang.String) iteratorElement19;
            if (!str.isEmpty()) {
                if (str.length() > 4) {
                    break;
                } else if (str.equals((java.lang.Object) "skip")) {
    } else if (str.equals((java.lang.Object) "a")) {
                    break;
    } else {
                    length = length + 1;
    }
            } else {
                break;
            }
        }
        return length;
    }

    public void check() {
        // @method check()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestBreakInComplexIf2$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat(this.test((java.util.List) java.util.Arrays.asList((java.lang.Object[]) new java.lang.String[]{"x", "y", "skip", "z", "a"}))).isEqualTo(3);
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat(this.test((java.util.List) java.util.Arrays.asList((java.lang.Object[]) new java.lang.String[]{"x", "skip", ""}))).isEqualTo(1);
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat(this.test((java.util.List) java.util.Arrays.asList((java.lang.Object[]) new java.lang.String[]{"skip", "y", "12345"}))).isEqualTo(1);
        return;
    }
}
