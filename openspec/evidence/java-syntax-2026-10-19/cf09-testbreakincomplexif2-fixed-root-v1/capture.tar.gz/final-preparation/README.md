# TestBreakInComplexIf2 最终候选对照准备

本目录是私有、未执行的最终候选采集器和只读审阅器。它复用已接受的原始基线与单格 smoke，不声称候选完整矩阵已经运行或通过。

原始基线固定为 `execution.json` SHA-256 `68cc71534940ab28b70dde3f8ccefcbd8b446dae600fb15091a82067f08d14b0`，root 接受标记 SHA-256 `19f390f3f00434e0ab6b6f7721253be576bd089f02756f593ac54b930f9dcb82`，独立审计 SHA-256 `3bb3642b413acd7b31df451114989c89dd91dc4effb03e4db873709b5df349f3`。原件包含完整 outer 与 TestCls 两种 debug profile、两个原始 JAR、4 个 VM cell 共 44 条观察、8 个 Jarde API cell 和 2 个完整 JADX source 输出。CASE_PLAN 固定 11 个有限输入。

最终候选只请求选定的 `TestBreakInComplexIf2$TestCls`，覆盖 `child`/`bundle-child`、debug/no-debug、default/all 共 8 个 API cell。每个 cell 的完整 class-source 输出原样复制为一个 Java 文件；不把原始 outer JUnit 类或原始 class 注入候选编译目录。候选源按两套 JDK 完整尝试编译，共 16 个编译格；只有通过完整 class / method / field 身份核对的产物才进入双 VM 与错误 CodeSource 对照。原始 outer/JADX 证据由已接受收据按 pin 复用，不重跑。

当前可用的单格 smoke 使用同一 CLI SHA-256 `52ff01f7794c962f2fbb9d809612c0cc371ef297de8cb32a29629323d168cbca`，只覆盖 debug child/all，并记录三个方法均为 structured、未执行目标方法。它不是完整候选验收；collector 会要求之后传入的 CLI 路径与该 smoke 指向同一文件且字节 SHA 相同。

静态预检已用 `python3 -B static_preflight.py` 通过：它重开原始 class/JAR/API/raw/map/case-plan 与 smoke pins，验证两个原始 profile、8 个 API cell、每类 3 个方法、44 条原始 VM 观察和所有方法的物理 BCI / UTF-8 map 锚点。该步骤没有调用 Jarde CLI、JDK、JADX 或 Cargo。结果见 `preflight.json`；相对模板差异见 `adaptation.diff`；固定文件和外部输入摘要见 `pins.json`。

待 root 提供执行窗口后，候选采集命令为：

```sh
python3 -B /private/tmp/jarde-testbreakincomplexif2-final-candidate-prep-luna-v1-20261019/collect_final.py \
  --out /private/tmp/jarde-testbreakincomplexif2-final-candidate-root-v1-20261019 \
  --cli /private/tmp/jarde-loop-header-body-boundary-focused-root-v5-20261019/candidate-cli \
  --cli-sha256 52ff01f7794c962f2fbb9d809612c0cc371ef297de8cb32a29629323d168cbca
```

采集成功后可独立运行：

```sh
python3 -B /private/tmp/jarde-testbreakincomplexif2-final-candidate-prep-luna-v1-20261019/review.py \
  --receipt /private/tmp/jarde-testbreakincomplexif2-final-candidate-root-v1-20261019/execution.json \
  --expected-cli-sha256 52ff01f7794c962f2fbb9d809612c0cc371ef297de8cb32a29629323d168cbca \
  --out /private/tmp/jarde-testbreakincomplexif2-final-candidate-root-v1-20261019/independent-review.json
```

README 中的执行命令仅供 root 审阅，尚未运行。
