#!/usr/bin/env python3
"""Read-only preflight for the TestBreakInComplexIf2 final-candidate bundle; no target execution."""
from __future__ import annotations
import hashlib, importlib.util, json
from pathlib import Path

BASE=Path(__file__).parent
COLLECTOR=BASE/'collect_final.py'
REVIEWER=BASE/'review.py'
COLLECTOR_SHA='2f3977336482ecb7596b2375faceaad2d78f105101c370a875188eefac642fc1'
REVIEWER_SHA='bad98ff1ce382ad00e933780aed17ee8c69a867d97750768d4958c4daeecbd25'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    if not spec or not spec.loader: raise RuntimeError(f'cannot load {path}')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def main():
    assert sha(COLLECTOR)==COLLECTOR_SHA
    assert sha(REVIEWER)==REVIEWER_SHA
    import ast
    for path in (COLLECTOR,REVIEWER,BASE/'static_preflight.py'):
        ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    c=load(COLLECTOR,'complexif2_final_collector_preflight')
    r=load(REVIEWER,'complexif2_final_reviewer_preflight')
    assert c.BASELINE_SHA256==r.BASE_SHA
    assert c.BASELINE_REVIEW_SHA256==r.BASE_REVIEW_SHA
    assert c.SOURCE_SHA256==r.UPSTREAM_SOURCE_SHA and c.DRIVER_SHA256==r.DRIVER_SHA
    assert c.CASE_NAMES==r.CASE_NAMES
    assert c.CANDIDATE_SMOKE_SHA256==r.CANDIDATE_SMOKE_SHA
    assert c.SMOKE_CLI_SHA256==r.SMOKE_CLI_SHA
    assert r.CANDIDATE_COLLECTOR_SHA==COLLECTOR_SHA
    for path,digest in ((c.SOURCE,c.SOURCE_SHA256),(c.DEPENDENCY_REFERENCE,c.DEPENDENCY_REFERENCE_SHA256),
        (c.BASELINE_INDEPENDENT_REVIEW,c.BASELINE_INDEPENDENT_REVIEW_SHA256),(c.CASE_PLAN,c.CASE_PLAN_SHA256),
        (c.RUNTIME_BOUND,c.RUNTIME_BOUND_SHA256),(c.JADX,c.JADX_SHA256),(c.JADX_JAR,c.JADX_JAR_SHA256),
        (c.PARSER,c.PARSER_SHA256),(c.ROOT/c.COMPARE_REL,c.COMPARE_SHA256),(c.ROOT/c.JDK_MANIFEST_REL,c.JDK_MANIFEST_SHA256),
        (c.ROOT/c.GUARD_REL,c.GUARD_SHA256),(c.ROOT/c.SCANNER_REL,c.SCANNER_SHA256),
        (c.BASELINE_DIR/'execution.json',c.BASELINE_SHA256),(c.BASELINE_ROOT_REVIEW,c.BASELINE_REVIEW_SHA256),
        (c.CANDIDATE_SMOKE,c.CANDIDATE_SMOKE_SHA256)):
        assert path.is_file() and sha(path)==digest, f'embedded pin mismatch: {path}'
    compare=c.load(c.ROOT/c.COMPARE_REL,'complexif2_compare_preflight')
    jdks,jdk_record=compare.configured_jdks(c.ROOT/c.JDK_MANIFEST_REL,c.JDK_MANIFEST_SHA256)
    assert set(jdks)=={'javac8','javac23'} and set(jdk_record['tools'])=={'javac8','javac23'}
    physical=c.load(c.PARSER,'complexif2_parser_preflight')
    baseline,marker=c.accepted_baseline(compare)
    assert marker['status']=='root_accepted_complete_original_complex_if2_with_explicit_loop_gap'
    plan=json.loads(c.CASE_PLAN.read_text(encoding='utf-8'))
    assert [x['id'] for x in plan['cases']]==list(c.CASE_NAMES)
    assert c.SOURCE.read_bytes()==c.CASE_PLAN_SOURCE_COPY.read_bytes()
    assert len(baseline['source_profiles'])==2 and len(baseline['original_runtime'])==4
    assert len(baseline['jarde_cells'])==8 and len(baseline['jadx_outputs'])==2
    assert baseline['runtime_case_names']==list(c.CASE_NAMES)
    profiles={x['profile']:x for x in baseline['source_profiles']}
    assert set(profiles)=={'debug','no-debug'}
    for profile,row in profiles.items():
        root=Path(row['class_root'])
        actual={p.relative_to(root).as_posix():p for p in sorted(root.rglob('*.class'))}
        expected={c.OUTER_INTERNAL+'.class',c.INTERNAL+'.class'}
        assert set(actual)==expected
        for rel,p in actual.items():
            pin=row['class_tree'][rel]
            assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256']
        facts=c.full_class_facts(compare,physical,root/(c.INTERNAL+'.class'),f'{profile} target')
        assert c.norm(facts)==c.norm(row['target_facts'])
        assert sorted((m['name'],m['descriptor']) for m in facts['methods'])==[
            ('<init>','()V'),('check','()V'),('test','(Ljava/util/List;)I')]
        assert facts['fields']==[]
    api_keys={(x['profile'],x['input_form'],x['evidence'],x['api_role']) for x in baseline['jarde_cells']}
    assert api_keys=={(p,f,e,'target') for p in c.PROFILES for f in c.FORMS for e in c.EVIDENCE}
    docs={}
    physical_profiles={x['profile']:x for x in baseline['source_profiles']}
    for cell in baseline['jarde_cells']:
        doc=json.loads(Path(cell['report']['path']).read_text(encoding='utf-8'))
        assert doc['text'].encode('utf-8')==Path(cell['whole_source']['path']).read_bytes()
        assert len(doc['methods'])==3
        physical_methods={(m['name'],m['descriptor']):m for m in physical_profiles[cell['profile']]['target_facts']['methods']}
        identities={(m['item']['name']['escaped'],m['item']['descriptor']['escaped']) for m in doc['methods']}
        assert identities==set(physical_methods)
        for method in doc['methods']:
            ident=(method['item']['name']['escaped'],method['item']['descriptor']['escaped'])
            audit=c.audit_method_map(method,physical_methods[ident])
            assert audit['map_present'] and not audit['issues'],(cell['profile'],cell['input_form'],cell['evidence'],ident,audit['issues'])
        docs[(cell['profile'],cell['input_form'],cell['evidence'])]=doc
    for p in c.PROFILES:
        for form in c.FORMS:
            d,a=docs[(p,form,'default')],docs[(p,form,'all')]
            assert d['text']==a['text']
            assert [(m['item']['identity'],m['outcome']['kind'],m['outcome']['report']['text'],m['outcome']['report']['source_map']) for m in d['methods']]==[
                (m['item']['identity'],m['outcome']['kind'],m['outcome']['report']['text'],m['outcome']['report']['source_map']) for m in a['methods']]
    smoke=json.loads(c.CANDIDATE_SMOKE.read_text(encoding='utf-8'))
    assert smoke['status']=='single_api_observation_only' and smoke['exit_code']==0 and smoke['target_execution'] is False
    assert smoke['cli_sha256']==c.SMOKE_CLI_SHA256 and sha(Path(smoke['argv'][0]))==c.SMOKE_CLI_SHA256
    assert smoke['input_sha256']==sha(Path(smoke['argv'][3]))
    assert Path(smoke['argv'][3]).resolve()==(Path(profiles['debug']['class_root'])/(c.INTERNAL+'.class')).resolve()
    assert smoke['argv'][1:]==['class-source','--input',str(Path(smoke['argv'][3]).resolve()),'--class',c.INTERNAL,'--policy','single-class','--release','8','--format','json','--evidence','all']
    assert [m['name'] for m in smoke['methods']]==['<init>','test','check']
    assert all(m['quality']=='structured' for m in smoke['methods'])
    print(json.dumps({'status':'static_preflight_ok_no_candidate_execution','baseline_receipt_sha256':c.BASELINE_SHA256,
        'source_sha256':c.SOURCE_SHA256,'driver_sha256':c.DRIVER_SHA256,'smoke_cli_sha256':c.SMOKE_CLI_SHA256,
        'original_profiles':len(profiles),'api_cells':len(api_keys),'original_vm_rows':sum(len(x['rows']) for x in baseline['original_runtime']),
        'methods_per_api':3,'generated_source_cells_expected':8,'compile_legs_expected':16,'cases_per_vm':len(c.CASE_NAMES)},sort_keys=True))
if __name__=='__main__': main()
