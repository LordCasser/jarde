"""Copy-only, read-only-input preparation for two original JADX fixtures."""
import hashlib, importlib.util, json, shutil, zipfile
from pathlib import Path
OUT=Path('/private/tmp/jarde-last-four-fixtures-prepare-luna-v1-20261019')
ROOT=OUT/'tests/fixtures'
CONFIGS={
 'recover-proved-post-test-loop-return-leaves':(Path('/private/tmp/jarde-dowhilebreak2-baseline-root-v1-20261019'),'TestDoWhileBreak2','TestDoWhileBreak2.java'),
 'recover-proved-prefixed-catch-retry-loops':(Path('/private/tmp/jarde-breakinloop3-baseline-root-v1-20261019'),'TestBreakInLoop3','TestBreakInLoop3.java'),
}
LICENSE_DIR=Path('/private/tmp/jarde-loop45-own-ci-root-v2-20261019/product-fixtures/tests/fixtures/recover-proved-loop-break-branch-bodies/licenses')
LICENSES={'JADX-LICENSE':LICENSE_DIR/'JADX-LICENSE','JADX-NOTICE':LICENSE_DIR/'JADX-NOTICE'}
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
def pin(path):
 path=Path(path); b=path.read_bytes(); return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':oct(path.stat().st_mode & 0o777)}
def norm_fields(rows): return [(x['name'],x['descriptor'],x['access']) for x in rows]
def main():
 if any((ROOT/name).exists() for name in CONFIGS): raise SystemExit('fixture root already exists; refusing to overwrite')
 parser_bytes=PARSER.read_bytes(); parser_sha=hashlib.sha256(parser_bytes).hexdigest()
 module_spec=importlib.util.spec_from_file_location('frozen_classfile_helpers',PARSER); helper=importlib.util.module_from_spec(module_spec); module_spec.loader.exec_module(helper)
 all_files=[]; install=[]; fixtures=[]
 def copy_one(fixture,dest_root,source,rel,role):
  source=Path(source); target=dest_root/rel; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(source,target)
  a,b=pin(source),pin(target)
  if a!=b: raise AssertionError(f'copy metadata mismatch: {source}')
  repo_rel=f'tests/fixtures/{fixture}/{rel.as_posix()}'
  row={'fixture':fixture,'repo_relative_path':repo_rel,'path':str(target),'role':role,**b}
  all_files.append(row); install.append({'from':str(target),'to':repo_rel,'bytes':b['bytes'],'sha256':b['sha256'],'mode':b['mode']})
  return row
 for fixture,(base,binary,source_name) in CONFIGS.items():
  receipt_path=base/'execution.json'; receipt=json.loads(receipt_path.read_text())
  if receipt.get('status')!='captured-pending-independent-review': raise AssertionError(f'baseline capture not closed: {receipt_path}')
  if receipt.get('physical_parser',{}).get('sha256')!=parser_sha: raise AssertionError('frozen class parser SHA does not match baseline receipt')
  source=Path(receipt['source_copy']['path']); source_pin=pin(source)
  if source_pin['bytes']!=receipt['source']['bytes'] or source_pin['sha256']!=receipt['source']['sha256'] or source_pin['sha256']!=receipt['source_copy']['sha256']: raise AssertionError('baseline source copy differs from fixed upstream SHA')
  case_plan=json.loads(Path(receipt['case_plan']['path']).read_text())
  plan_source=case_plan.get('upstream',case_plan.get('source',{}))
  if plan_source.get('sha256') and plan_source['sha256']!=source_pin['sha256']: raise AssertionError('case plan source SHA mismatch')
  root=ROOT/fixture; root.mkdir(parents=True,exist_ok=False)
  source_copy=copy_one(fixture,root,source,Path('source')/source_name,'full-original-source')
  profile_facts=[]
  for profile in receipt['source_profiles']:
   pname=profile['profile']; class_facts=[]
   for rel,record in sorted(profile['class_tree'].items()):
    path=Path(record['path']); pp=pin(path)
    if pp['bytes']!=record['bytes'] or pp['sha256']!=record['sha256']: raise AssertionError('baseline class pin mismatch')
    relpath=Path('original')/pname/'classes'/rel; copied=copy_one(fixture,root,path,relpath,'original-profile-class')
    facts=helper.parse_class_file(path.read_bytes())
    expected=profile['target_facts'] if '$TestCls.class' in rel else profile['outer_facts']
    if facts['class_name']!=expected['class_name'] or norm_fields(facts['fields'])!=[tuple(x) for x in expected['fields']] or [(m['name'],m['descriptor'],m['access']) for m in facts['methods']]!=[(m['name'],m['descriptor'],m['access']) for m in expected['methods']]: raise AssertionError(f'class facts differ from closed baseline: {path}')
    methods=[]
    for m in facts['methods']:
     code=m['code']; methods.append({'index':m['index'],'name':m['name'],'descriptor':m['descriptor'],'access':m['access'],'code':None if code is None else {'max_stack':code['max_stack'],'max_locals':code['max_locals'],'code_length':code['code_length'],'code_hex':code['code_hex'],'instruction_bcis':code['bcis'],'exception_handlers':code['rows']}})
    class_facts.append({'repo_relative_path':f'tests/fixtures/{fixture}/{relpath.as_posix()}','pin':copied,'class_facts':{'minor':facts['minor'],'major':facts['major'],'access':facts['access'],'class_name':facts['class_name'],'fields':facts['fields'],'methods':methods}})
   jar_record=profile['bundle']; jar_path=Path(jar_record['path']); jar_pin=pin(jar_path)
   if jar_pin['bytes']!=jar_record['bytes'] or jar_pin['sha256']!=jar_record['sha256']: raise AssertionError('baseline JAR pin mismatch')
   jar_rel=Path('original')/pname/f'{binary}-full-classes.jar'; jar_copy=copy_one(fixture,root,jar_path,jar_rel,'complete-profile-class-jar')
   with zipfile.ZipFile(jar_path) as z:
    names=set(profile['class_tree'])
    if set(z.namelist())!=names: raise AssertionError('full JAR class entry set mismatch')
    for rel,record in profile['class_tree'].items():
     if z.read(rel)!=Path(record['path']).read_bytes(): raise AssertionError('full JAR entry bytes differ from profile class')
   profile_facts.append({'profile':pname,'classes':class_facts,'full_class_jar':{'repo_relative_path':f'tests/fixtures/{fixture}/{jar_rel.as_posix()}','pin':jar_copy,'entries':sorted(names),'entries_match_profile_class_files':True}})
  license_facts=[]
  for name,path in LICENSES.items(): license_facts.append(copy_one(fixture,root,path,Path('licenses')/name,'JADX-Apache-2.0-license-or-notice'))
  fixtures.append({'name':fixture,'repo_relative_root':f'tests/fixtures/{fixture}','baseline_receipt':{'path':str(receipt_path),**pin(receipt_path)},'baseline_schema':receipt['schema'],'baseline_status':receipt['status'],'source_upstream_pin':receipt['source'],'source_copy':source_copy,'full_source_preserved':True,'case_plan':{'path':receipt['case_plan']['path'],**pin(receipt['case_plan']['path'])},'profiles':profile_facts,'license_files':license_facts})
 metadata={'schema':'loop45-last-four-fixtures-metadata-v1','status':'prepared-private-only','fixtures':fixtures,'frozen_class_parser':{'path':str(PARSER),'bytes':len(parser_bytes),'sha256':parser_sha,'inventory':'class version/name/access, fields, methods, Code bytes/instruction BCIs, and exception-handler rows'}}
 (ROOT/'fixture-metadata.json').write_text(json.dumps(metadata,indent=2,ensure_ascii=False)+'\n')
 (ROOT/'install-manifest.json').write_text(json.dumps({'schema':'repo-relative-copy-install-manifest-v1','status':'copy-only-no-code-or-tests','repo_root':'tests/fixtures','entries':install},indent=2,ensure_ascii=False)+'\n')
 (ROOT/'README.md').write_text('''# Private original fixture staging\n\nCopy-only fixture payloads; no recovery implementation or tests are included. Copy each root according to `install-manifest.json` only when its owning OpenSpec is ready.\n\nBoth roots follow the established Loop45 layout: `source/`, `original/debug/classes/`, `original/no-debug/classes/`, profile-specific full `*-full-classes.jar` files, and `licenses/JADX-LICENSE` plus `licenses/JADX-NOTICE`. The license and notice are byte-for-byte copies from the existing Loop45 license bundle.\n\n`fixture-metadata.json` records every copied source, class, JAR, license and notice file's bytes, mode and SHA-256. It also records physical class inventory from the pinned frozen Python parser: class identity/version/access, fields, methods, code bytes, instruction BCIs, and exception handlers. Every full JAR entry is checked against the corresponding profile class bytes.\n\nThe first root contains complete `TestDoWhileBreak2.java`, including the original nested `check()` and outer JUnit test. The second contains complete `TestBreakInLoop3.java`, including its catch-prefixed retry, `check()`, and original NYI annotation/comment state.\n''')
 return {'fixtures':fixtures,'copied_files':all_files,'install':install,'metadata':metadata,'parser_sha':parser_sha}
if __name__=='__main__':
 result=main(); out=OUT; root=ROOT
 def localpin(path): return {'path':str(path),**pin(path)}
 manifest={'schema':'loop45-last-four-fixtures-private-bundle-v1','status':'sealed-copy-only','bundle':str(OUT),'repo_relative_roots':[x['repo_relative_root'] for x in result['fixtures']],'file_count':len(result['copied_files']),'copied_files':result['copied_files'],'metadata_files':[localpin(root/'README.md'),localpin(root/'fixture-metadata.json'),localpin(root/'install-manifest.json')],'prepare_script':localpin(OUT/'prepare.py'),'frozen_class_parser':result['metadata']['frozen_class_parser'],'license_sources':[{'path':str(p),**pin(p)} for p in LICENSES.values()]}
 (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'status':manifest['status'],'bundle':str(OUT),'repo_relative_roots':manifest['repo_relative_roots'],'copied_files':manifest['file_count'],'profile_class_files':sum(len(p['classes']) for f in result['fixtures'] for p in f['profiles']),'metadata_files':manifest['metadata_files'],'parser_sha256':manifest['frozen_class_parser']['sha256']},ensure_ascii=False,indent=2))
