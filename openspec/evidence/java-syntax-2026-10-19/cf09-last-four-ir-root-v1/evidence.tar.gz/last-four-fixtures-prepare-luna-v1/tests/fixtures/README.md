# Private original fixture staging

Copy-only fixture payloads; no recovery implementation or tests are included. Copy each root according to `install-manifest.json` only when its owning OpenSpec is ready.

Both roots follow the established Loop45 layout: `source/`, `original/debug/classes/`, `original/no-debug/classes/`, profile-specific full `*-full-classes.jar` files, and `licenses/JADX-LICENSE` plus `licenses/JADX-NOTICE`. The license and notice are byte-for-byte copies from the existing Loop45 license bundle.

`fixture-metadata.json` records every copied source, class, JAR, license and notice file's bytes, mode and SHA-256. It also records physical class inventory from the pinned frozen Python parser: class identity/version/access, fields, methods, code bytes, instruction BCIs, and exception handlers. Every full JAR entry is checked against the corresponding profile class bytes.

The first root contains complete `TestDoWhileBreak2.java`, including the original nested `check()` and outer JUnit test. The second contains complete `TestBreakInLoop3.java`, including its catch-prefixed retry, `check()`, and original NYI annotation/comment state.
