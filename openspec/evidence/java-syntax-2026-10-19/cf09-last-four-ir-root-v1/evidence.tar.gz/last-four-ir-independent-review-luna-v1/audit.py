#!/usr/bin/env python3
"""Independent raw re-open audit of the closed last-four IR probe. Python stdlib only."""
import hashlib, json, re
from pathlib import Path

OUT = Path('/private/tmp/jarde-last-four-ir-independent-review-luna-v1-20261019')
LAUNCH = Path('/private/tmp/jarde-last-four-ir-probe-launch-root-v1-20261019/execution.json')
RUN = Path('/private/tmp/jarde-last-four-ir-probe-run-root-v1-20261019/execution.json')
PREP = Path('/private/tmp/jarde-last-four-ir-probe-prepare-root-v1-20261019')
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')

def sha(b): return hashlib.sha256(b).hexdigest()
def pin(path):
    b=Path(path).read_bytes(); return {'path':str(path),'bytes':len(b),'sha256':sha(b)}
def need(ok, msg):
    if not ok: raise SystemExit('audit failed: '+msg)
def read_json(path): return json.loads(Path(path).read_text())
def block_ids(s): return [int(x) for x in re.findall(r'CanonicalBlockId \{\s*bci: (\d+),\s*path: \[\],\s*\}', s)]

launch=read_json(LAUNCH); run=read_json(RUN)
need(launch['runner_exit_code']==0 and run['status']=='commands_passed_pending_independent_acceptance','closed runner status')
need(launch['runner_status']=='commands_passed_pending_independent_acceptance','launcher runner status')
need(launch['pins_before']==launch['pins_after'],'launcher before/after pins')
for item in launch['pins_before']:
    b=Path(item['path']).read_bytes()
    need(len(b)==item['bytes'] and sha(b)==item['sha256'],'launcher physical pin '+item['path'])
    need(Path(item['path']).stat().st_mode & 0o777 == item['mode'],'launcher file mode '+item['path'])
need(launch['inputs_and_sources_restored'] is True and launch['temporary_module_absent'] is True and launch['target_absent'] is True,'launcher cleanup flags')
need(run['default_stack'] is True and run['source_unchanged'] is True and run['source_changes']==[] and run['source_changes_accepted'] is True and run['target_absent'] is True,'runner cleanup/source flags')
need(run['source_before']==run['source_after'],'runner source pin equality')
need(len(run['commands'])==2,'command count')
need(run['commands'][0]['argv']==['cargo','test','-p','jarde-java','--lib','--locked','region::last_four_ir_probe_tests::dump_real_last_four_gap_ir','--','--exact','--nocapture'],'probe argv exact')
need(run['commands'][0]['exit_code']==0 and run['commands'][0].get('guard_stop') is None,'probe command status')
need(run['commands'][1]['argv']==['cargo','clean'] and run['commands'][1]['exit_code']==0,'cleanup command')
need(launch['runner_receipt']['path']==str(RUN) and launch['runner_receipt']['bytes']==RUN.stat().st_size and launch['runner_receipt']['sha256']==sha(RUN.read_bytes()),'launcher receipt pin')

raws={}
for c in run['commands']:
    for stream, meta in c['streams'].items():
        p=Path(meta['path']); b=p.read_bytes()
        need(len(b)==meta['bytes'] and sha(b)==meta['sha256'],f"command {c['index']} {stream} raw pin")
        raws[f"{c['index']}.{stream}"]={'path':str(p),'bytes':len(b),'sha256':sha(b)}
stdout=Path(run['commands'][0]['streams']['stdout']['path']).read_text()
need('test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 540 filtered out' in stdout,'raw focused-test summary')
trace=Path(run['commands'][0]['streams']['stderr']['path']).read_text()
need(len(trace.encode())==206780 and sha(trace.encode())=='a803a86b397635280b5164f14a535ccdaf2e0c027ac5b070ea25153982f5ad39','full IR stderr raw pin')

# Verify test definition is the actual temporary probe source pinned by the launcher.
test_src=PREP/'last_four_ir_probe_tests.rs'
need(pin(test_src)['bytes']==7790 and pin(test_src)['sha256']=='b3a3ec2dc0ac252e049ae29740ff429b7199cf7c6888c273f2645a015e8b1564','probe source pin')
need('let sites = crate::init::Sites::empty();' in test_src.read_text(),'probe recovery Sites::empty')
need('inspect("do2-debug"' in test_src.read_text() and 'inspect("do2-no-debug"' in test_src.read_text() and 'inspect("loop3-debug"' in test_src.read_text() and 'inspect("loop3-no-debug"' in test_src.read_text(),'four profile test calls')
original=PREP/'original-region.rs'
need(pin(original)['sha256']=='86a20041442a196dfaa83da539d3f301b9b4974907620b3b50da1eb46f037be5','frozen original region')
region=ROOT/'crates/jarde-java/src/region.rs'
need(pin(region)['sha256']==pin(original)['sha256'],'restored region equals frozen source')
probe_module=ROOT/'crates/jarde-java/src/region/last_four_ir_probe_tests.rs'
need(not probe_module.exists(),'temporary module absent on disk')
need(not (ROOT/'target').exists(),'repo target absent on disk')

# Raw-derived profile line partitions and topology facts.
profiles={}
for label,kind in [('do2-debug','do2'),('do2-no-debug','do2'),('loop3-debug','loop3'),('loop3-no-debug','loop3')]:
    lines=[x for x in trace.splitlines() if x.startswith(f'LAST4_PROBE {label}: ')]
    need(lines,'trace profile '+label)
    if kind=='do2':
        natural=[x for x in lines if 'natural-loop header=' in x]
        need(len(natural)==1,'one natural-loop row '+label)
        row=natural[0]
        need('header=CanonicalBlockId { bci: 0' in row and 'blocks=[CanonicalBlockId { bci: 0' in row and 'bci: 19' in row,'Do2 header/members '+label)
        need('latches=[CanonicalBlockId { bci: 19' in row and 'bci: 17' in row and 'bci: 31' in row and 'ipdom=None' in row,'Do2 latch/exits/ipdom '+label)
        need('natural-loops=none' not in '\n'.join(lines),'Do2 has natural loop '+label)
        topology={'natural_loop_header':0,'natural_loop_blocks':[0,19],'latches':[19],
                  'normal_exits':['0->17','19->31'],'immediate_postdominator':None,
                  'recovered_fallbacks':['UnmetPrecondition StatementFree block=0 at=9','UncoveredBlocks [17,19,31]']}
    else:
        need(any('natural-loops=none' in x for x in lines),'Loop3 has no natural loop '+label)
        need(not any('natural-loop header=' in x for x in lines),'Loop3 no natural-loop rows '+label)
        # The canonical normal-flow relation is taken from raw trace, distinct from exception edges.
        succ={}
        for x in lines:
            m=re.search(r'normal-successors block=CanonicalBlockId \{ bci: (\d+), path: \[\] \} successors=\[(.*)\]',x)
            if m: succ[int(m.group(1))]=[int(z) for z in re.findall(r'bci: (\d+), path: \[\]',m.group(2))]
        expected={0:[11],11:[82],82:[],31:[48,37],37:[11],48:[70,61],61:[76],70:[76],76:[82]}
        need(succ==expected,'Loop3 normal-flow topology '+label)
        rec=trace[trace.index(f'LAST4_PROBE {label}: recovered='):]
        rec=rec[:rec.find(f'LAST4_PROBE {label}: regions-in-method-order=')]
        need('OwnershipOverlap' in rec and 'block: CanonicalBlockId {\n                    bci: 11' in rec,'Loop3 recovery ownership fallback '+label)
        topology={'natural_loops':[], 'normal_edges':{str(k):v for k,v in succ.items()},
                  'exceptional_retry_edges_are_not_normal_edges':True,
                  'recovered':'single whole-method Fallback(OwnershipOverlap block 11)'}
    profiles[label]=topology

# Try-region entry and facts markers have no profile prefix; raw call order identifies two per Loop3 profile.
entries=re.findall(r'LAST4_PROBE try-entry start=CanonicalBlockId \{ bci: (\d+), path: \[\] \} retry_entry=(\w+) shape=Catches \{',trace)
facts=re.findall(r'LAST4_PROBE retry-facts start=CanonicalBlockId \{ bci: (\d+), path: \[\] \} facts=([^\n]+)',trace)
need(entries==[('11','false')]*4,'four same Try entry markers at BCI 11')
need(facts==[('11','None')]*4,'four missing retry-facts rows')

# Two pre-final Loop3 trees are independently extracted and normalized from their pretty-debug bodies.
pre=[]; start=0
while True:
    i=trace.find('LAST4_PROBE prefinal-regions=[',start)
    if i<0: break
    end=trace.find('LAST4_PROBE loop3-',i)
    need(end>i,'prefinal boundary')
    body=trace[i:end]
    if 'Try {' in body: pre.append(body)
    start=end+1
need(len(pre)==2,'two prefinal Loop3 snapshots')
normalized=[]
for body in pre:
    need(body.count('lead: (')==2 and body.count('bci: 11,')>=2 and body.count('bci: 31,')>=2,'duplicate try lead/body/handler in prefinal tree')
    need('lead: (\n            11,\n            17,\n        )' in body,'outer and nested Try lead boundary')
    need('normal_exit_bci: None' in body and 'types: Named(\n                    [\n                        32,' in body,'catch type and range row')
    need('handler: CanonicalBlockId {' in body and 'bci: 31,' in body,'handler BCI 31')
    need('join: Some(\n                        CanonicalBlockId {\n                            bci: 82' in body,'normal join 82')
    need('prefix: [\n                            CanonicalBlockId {\n                                bci: 37' in body,'retry prefix BCI 37')
    need('branch_bci: 34' in body and 'branch_bci: 58' in body,'catch branch and nested If branch')
    normalized.append({'outer_try':{'prefix':[0],'lead':[11,17],'body_straight':[11],
                                     'catch':{'handler':31,'types':[32],'if_branch_bci':34,
                                              'then_nested_try':{'prefix':[37],'lead':[11,17],
                                                                 'body_fallback':[11], 'catch_handler_fallback':[31]},
                                              'else_normal_dag':{'if_branch_bci':58,'arms':[61,70], 'join':76, 'tail':[76]},
                                              'join':82}},'normal_after_try':[82]})
need(pre[0]==pre[1],'debug/no-debug Loop3 prefinal tree text equality')
need(normalized[0]==normalized[1],'normalized debug/no-debug tree equality')

# Exception protection boundary is from raw Code handlers/region Try row; canonical block 11 is retained as observed.
need(trace.count('start=CanonicalBlockId { bci: 11, path: [] } retry_entry=false shape=Catches {')==4,'Try entries are rooted at canonical block 11')
need(trace.count('operation bci=45 opcode=0xa7 operation=Some(Transfer)')==2,'Loop3 raw bytecode operation at BCI 45 is a transfer')
need(trace.count('lead: (\n            11,\n            17,\n        )')==2,'both raw trees record lead (11,17)')
need(trace.count('start_bci: 17')==2 and trace.count('end_bci: 28')==2 and trace.count('handler_bci: 31')==2 and trace.count('catch_type_index: Some(\n            32,')==2,'both Loop3 exception tables encode [17,28)->31 type 32')

report={
 'status':'independent_raw_review_passed',
 'scope':'closed temporary IR probe only; not public API Builder acceptance',
 'receipts':{'launcher':pin(LAUNCH),'runner':pin(RUN),'probe_stderr':raws['1.stderr'],'probe_stdout':raws['1.stdout']},
 'source_pins':{'original_launcher_pins':launch['pins_before'],'postrun_launcher_pins':launch['pins_after'],'temporary_runner_sources':launch['temporary_sources'],'temporary_source_roundtrip':launch['inputs_and_sources_restored']},
 'closed_execution':{'focused_test_exit':0,'focused_test_passed':1,'focused_test_failed':0,'cargo_clean_exit':0,
                     'four_profiles':['do2-debug','do2-no-debug','loop3-debug','loop3-no-debug'],
                     'pins_before_after_equal':True,'source_restored_to_frozen_original':True,'temporary_module_absent':True,'target_absent':True,
                     'default_stack':True},
 'profiles':profiles,
 'loop3_try_probe':{'entry_markers':len(entries),'retry_facts_none':len(facts),'lead':[11,17],
                    'protected_exception_range':[17,28],'handler':31,'catch_types':[32],
                    'prefinal_snapshots':normalized[0], 'debug_no_debug_prefinal_equal':True,
                    'observed_ownership_overlap_block':11},
 'methodology_limit':'The temporary probe explicitly constructs crate::init::Sites::empty(); its recovered tree is a direct Region probe over the pinned physical class, not the public Builder/product recovery path. It cannot alone establish equivalence of nonempty initialization-site facts or explain all public baseline gaps.',
 'architecture_readout':'The pre-final region tree shows recursive re-entry into the same named Try lead (11,17): the outer try body owns canonical block 11; its catch If then-arm prefixes 37 and opens the same lead again, while it revisits catch handler 31. This is concrete evidence for retry-shaped recursive ownership in this probe. Do2 remains a separate ordinary natural loop with header 0, members 0/19, latch 19 and two normal exits; Loop3 has no natural loop in the observed NormalFlowView, so its retry edge must not be relabeled as an ordinary loop. A narrow extension to the existing exact named-retry proof could represent the nonempty lead and a closed, normal-completing catch DAG joining at 82 with canonical normal edge 37→11 (whose bytecode transfer is at BCI 45), reusing existing Try/If/Sequence/LoopContinue/Endless region constructs. Preserve exact exception boundaries, unique ownership checks and normal-vs-exceptional edge distinction; this trace does not justify a new CFG/AST or relaxing ownership/range checks.'
}
(OUT/'review.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':report['status'],'report':str(OUT/'review.json'),'raw':raws['1.stderr'],'profiles':list(profiles)},indent=2))
