# Last-four IR probe: independent raw review

This package independently reopens the already closed temporary probe receipt and every command raw stream. It does not rerun the probe, build, or product CLI. Run the audit with:

```sh
python3 -B /private/tmp/jarde-last-four-ir-independent-review-luna-v1-20261019/audit.py
```

The audit verifies the launcher and runner receipts, command raw byte lengths and SHA-256 values, the one-test result, cleanup, source pin roundtrip, and the physical `target` and temporary-module absence. It compares the restored shared `region.rs` to the frozen `original-region.rs` in the prep directory. During the runner command, `region.rs` was temporarily instrumented and the runner's before/after pins record that instrumented version; the outer launcher then restored the original version, which is what the present-day launcher pins and physical source confirm.

The full IR trace is 206,780 bytes with SHA-256 `a803a86b397635280b5164f14a535ccdaf2e0c027ac5b070ea25153982f5ad39`. It covers DoWhileBreak2 debug/no-debug and BreakInLoop3 debug/no-debug. The Do2 normal-flow view has a natural loop headed at BCI 0, members 0/19, latch 19 and normal exits 0→17 and 19→31. Loop3 has no natural loop in the captured `NormalFlowView`. Its handler row is `[17,28) → 31` with type index 32. The raw Try facts root at 11 with lead `(11,17)` and report no `RetryLoopFacts`; the pre-final tree revisits that same lead and handler inside the catch branch. The bytecode transfer at BCI 45 is observed within the canonical normal edge 37→11.

This is a direct Region probe, not public Builder acceptance. Its probe source explicitly passes `crate::init::Sites::empty()`, so it cannot establish behavior with populated initialization-site facts or prove the cause of the public baseline gap. `review.json` records the raw-derived normalized structures and this scope limit.
