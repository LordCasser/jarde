//! Temporary, read-only probe for the accepted original TestBreakInLoop2 class.
use super::*;
use jarde_jvm::engine::analyze_method_ir;
use jarde_jvm::environment::ResolutionEnvironment;
use jarde_jvm::ir::{AnalysisStage, MethodAnalysisRequest};
use jarde_reader::artifact::{ArtifactInput, ArtifactSnapshot};
use jarde_reader::budget::{Budget, Limits};
use jarde_reader::model::{
    ClassBytesId, Digest, JvmBytes, PhysicalClassLocation, PhysicalDefinitionId, PhysicalMethodId,
    PhysicalVariant,
};
use jarde_reader::view::{
    DelegationPolicy, LayoutMode, LoadDomain, LoadRoot, LoaderId, ModuleMode,
    MultiReleasePolicy, PhysicalScope, PhysicalView, RuntimeProfile, RuntimeUncertainty,
    RuntimeView,
};

const INPUT_0: &[u8] = include_bytes!("/private/tmp/jarde-dowhilebreak2-baseline-root-v1-20261019/debug/classes/jadx/tests/integration/loops/TestDoWhileBreak2$TestCls.class");
const INPUT_1: &[u8] = include_bytes!("/private/tmp/jarde-dowhilebreak2-baseline-root-v1-20261019/no-debug/classes/jadx/tests/integration/loops/TestDoWhileBreak2$TestCls.class");
const INPUT_2: &[u8] = include_bytes!("/private/tmp/jarde-breakinloop3-baseline-root-v1-20261019/debug/classes/jadx/tests/integration/loops/TestBreakInLoop3$TestCls.class");
const INPUT_3: &[u8] = include_bytes!("/private/tmp/jarde-breakinloop3-baseline-root-v1-20261019/no-debug/classes/jadx/tests/integration/loops/TestBreakInLoop3$TestCls.class");

fn probe_budget() -> Budget {
    Budget::new(Limits {
        input_bytes: 1 << 20, archive_entries: 100, entry_bytes: 1 << 20,
        read_bytes: 1 << 20, class_bytes: 1 << 20, attribute_bytes: 1 << 20,
        code_bytes: 1 << 20, result_items: 1 << 20, output_bytes: 1 << 20,
        class_headers: 100, method_bodies: 100, ir_items: 1 << 20,
        ir_edges: 1 << 20, analysis_steps: 1 << 20, normalization_clones: 1 << 20,
        nested_depth: 32, dependency_depth: 8, elapsed_millis: u64::MAX,
    })
}

fn inspect(label: &str, bytes: &[u8], name: &[u8], descriptor: &[u8]) {
    let mut budget = probe_budget();
    let snapshot = ArtifactSnapshot::open(ArtifactInput::bytes(bytes.to_vec()), &mut budget)
        .expect("pinned physical class opens");
    let definition = PhysicalDefinitionId {
        location: PhysicalClassLocation::StandaloneRoot { snapshot: snapshot.id().clone() },
        class_bytes: ClassBytesId {
            digest: Digest(blake3::hash(bytes).to_hex().to_string()),
            length: u64::try_from(bytes.len()).expect("class length fits u64"),
        },
        variant: PhysicalVariant::Base,
    };
    let domain = LoadDomain {
        loader: LoaderId("app".into()), parent_loader: None,
        delegation: DelegationPolicy::ParentFirst,
        roots: vec![LoadRoot::StandaloneClass { snapshot: snapshot.id().clone() }],
        module_mode: ModuleMode::ClassPath,
        external_override: RuntimeUncertainty::None, runtime_transformation: RuntimeUncertainty::None,
    };
    let analysis = analyze_method_ir(
        &[snapshot.clone()],
        &MethodAnalysisRequest {
            environment: ResolutionEnvironment {
                runtime: RuntimeView {
                    physical: PhysicalView { snapshot: snapshot.id().clone(), scope: PhysicalScope::SnapshotAll },
                    profile: RuntimeProfile { java_release: 8, multi_release: MultiReleasePolicy::Disabled, layout: LayoutMode::Generic },
                    load_domain: domain.clone(),
                },
                domains: vec![domain], providers: Vec::new(),
            },
            method: PhysicalMethodId {
                owner: definition, name: JvmBytes(name.to_vec()),
                descriptor: JvmBytes(descriptor.to_vec()),
            },
            stages: AnalysisStage::ALL.to_vec(),
        },
        &mut budget,
    ).expect("Reader analyzes the pinned physical method");
    let ir = analysis.ir();
    let canonical = ir.canonical().expect("canonical CFG");
    let ssa = ir.ssa().expect("same-run SSA");
    let code = ir.code().expect("complete Code facts");
    let pool = ir.constant_pool();
    let operations = Operations::of(code, pool);
    eprintln!("LAST4_PROBE {label}: decoded-code={:#?}", code.instructions);
    eprintln!("LAST4_PROBE {label}: exception-handlers={:#?}", code.exception_handlers);
    for instruction in &code.instructions {
        eprintln!("LAST4_PROBE {label}: operation bci={} opcode={:#04x} operation={:?}", instruction.bci, instruction.opcode, operations.get(instruction.bci));
    }
    let mut flow_budget = probe_budget();
    let view = NormalFlowView::build(canonical, &mut flow_budget).expect("normal-flow view");
    eprintln!("LAST4_PROBE {label}: canonical-blocks={:#?}", canonical.blocks());
    eprintln!("LAST4_PROBE {label}: canonical-edges-all-kinds={:#?}", canonical.edges());
    eprintln!("LAST4_PROBE {label}: normal-flow-ids={:#?}", view.ids());
    for id in view.ids() {
        eprintln!("LAST4_PROBE {label}: normal-successors block={id:?} successors={:?}", view.successor_ids(id));
    }
    eprintln!("LAST4_PROBE {label}: all-ssa-phis={:#?}", ssa.phis());
    for names in ssa.blocks() {
        for instruction in names.instructions() {
            eprintln!("LAST4_PROBE {label}: ssa-instruction block={:?} bci={} reads={:?} writes={:?}", names.block(), instruction.bci(), instruction.reads(), instruction.writes());
        }
    }
    let mut natural_count = 0usize;
    for node in 0..view.len() {
        let Some(natural) = view.loop_entered_at(node) else { continue };
        if natural.header() != node { continue; }
        natural_count += 1;
        let header = view.id_of(node).expect("natural-loop header");
        let members = natural.blocks().iter().filter_map(|n| view.id_of(*n).cloned()).collect::<Vec<_>>();
        let latches = natural.latches().iter().filter_map(|n| view.id_of(*n).cloned()).collect::<Vec<_>>();
        let member_nodes = natural.blocks().clone();
        let exits = canonical.edges().iter().filter(|edge| {
            matches!(edge.kind(), CanonicalEdgeKind::Normal)
                && view.index_of(edge.from()).is_some_and(|n| member_nodes.contains(&n))
                && view.index_of(edge.to()).is_some_and(|n| !member_nodes.contains(&n))
        }).collect::<Vec<_>>();
        let ipdom = view.immediate_post_dominator(node).and_then(|n| view.id_of(n)).cloned();
        eprintln!("LAST4_PROBE {label}: natural-loop header={header:?} blocks={members:?} latches={latches:?} exits={exits:?} ipdom={ipdom:?} irreducible={}", natural.is_irreducible());
    }
    if natural_count == 0 {
        eprintln!("LAST4_PROBE {label}: natural-loops=none");
    }
    let chains = crate::concat::plan(ssa, &operations, &crate::build::FieldCopies::default());
    let sites = crate::init::Sites::empty();
    let mut recovery_budget = probe_budget();
    let recovered = recover(
        canonical, &view, ssa, &operations, pool, &chains, &sites, code,
        Some(false), false, &crate::pass::JAVA_8, &mut recovery_budget,
    ).expect("existing Region recovery completes");
    eprintln!("LAST4_PROBE {label}: recovered={recovered:#?}");
    eprintln!("LAST4_PROBE {label}: regions-in-method-order={:#?}", recovered.regions);
    eprintln!("LAST4_PROBE {label}: fallbacks={:#?}", recovered.fallbacks());
}

#[test]
fn dump_real_last_four_gap_ir() {
    assert_eq!(INPUT_0.len(), 1428);
    inspect("do2-debug", INPUT_0, b"test", b"()Ljava/lang/Object;");
    assert_eq!(INPUT_1.len(), 1118);
    inspect("do2-no-debug", INPUT_1, b"test", b"()Ljava/lang/Object;");
    assert_eq!(INPUT_2.len(), 1746);
    inspect("loop3-debug", INPUT_2, b"writeMore", b"(Ljava/lang/String;)V");
    assert_eq!(INPUT_3.len(), 1242);
    inspect("loop3-no-debug", INPUT_3, b"writeMore", b"(Ljava/lang/String;)V");
}
