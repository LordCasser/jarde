# TestBreakInLoop2 same-run IR probe preparation

Status: **prepared only; no probe, compiler, target, or toolchain has been run.** The product checkout remains untouched. This directory is private preparation material for a root-owned, guarded same-run probe.

## Facts already pinned

- Main product revision in the baseline receipt: `c8af822ef6d929f8ad1221f58d02e27669c63fc7`; receipt: `/private/tmp/jarde-testbreakinloop2-baseline-root-v1-20261019/execution.json` (SHA-256 in `pins.json`). Independent review JSON is `/private/tmp/jarde-testbreakinloop2-baseline-review-root-v1-20261019` (also pinned).
- The exact source method is `test(Ljava/util/List;)V` in the original debug and no-debug `TestBreakInLoop2$TestCls.class`. Both files here are copied from the accepted baseline and pinned.
- Current `crates/jarde-java/src/region.rs` SHA-256 is pinned to `5da4d9f40e0892ac134bb42fb1508fffad090b92338a86b9403efd47b7977510`. No shared source was changed.
- Static source facts: `recover` calls `overlapping_owner` after it has built the candidate region vector. `Region::blocks()` folds selected intentional aliases inside one Region; for a non-While loop, its header is omitted from the loop's owner list when a body region owns that header. Therefore the trace preserves the full Region Debug tree and `blocks()` results with their enclosing top-level region, rather than deduplicating repeated BCIs.

## Hypothesis, not evidence

Root static review predicts that the actual walk may encounter a named catch shape and decline the narrow retry proof because the handler has two normal destinations. That could allow a later traversal through the handler continuation to re-enter the loop and produce overlapping ownership. This is only a hypothesis until this same-run trace records the actual path, shape, retry frame decision, first retry-proof refusal, and pre-overlap tree. The given baseline fallback is not itself proof of this mechanism.

## Probe contents

`testbreakinloop2_ir_probe_tests.rs` reuses the existing `Reader -> CFG/SSA -> NormalFlowView -> recover` route and existing Region APIs. For each pinned input it emits decoded operations, canonical blocks and all canonical edges (including exception edges and handler ordinals), same-run SSA facts, natural-loop blocks/latches/exits/post-dominators, and the actual returned recovery. `candidate-region.rs` adds only temporary `cfg(test)` logging: actual `region_at` entry/return, Catches shape and frame, a stable check label at each `retry_loop_facts` refusal, and the full candidate tree plus BCI 0 owner occurrences immediately before `overlapping_owner`. `retry-check-map.json` maps refusal labels to the pinned source lines and condition context.

No algorithm edit, synthetic graph, production BCI, or behavior correction is included. Direct helper/proof output is auxiliary; the actual `recover` trace is authoritative.

## Root-owned run contract

`commands.json`, `runner-spec.json`, `candidate.patch`, and `pins.json` are the handoff set. Before a root-owned run, verify every pin and require at least 5 GiB free space, target directory absent, fresh private output directories, and no existing temporary test module. Run the listed command only through the existing `run_validation.py` guard. Keep `target` under 1 GiB, preserve default stack, and require the guard/finally exact-clean behavior. Restore `region.rs` byte-for-byte and remove the temporary module in `finally`; a run counts only if the command passes and all cleanup checks pass.
