# TestBreakInLoop2 same-run IR probe preparation v2

Status: prepared only; no compilation or execution. v1 is preserved unchanged. This v2 is private and contains no product fix.

The probe reads the two baseline-pinned original `TestBreakInLoop2$TestCls.class` inputs and analyzes `test(Ljava/util/List;)V` through Reader, canonical CFG, SSA, NormalFlowView, and existing `recover`. It prints decoded Code/operations, exception-table rows, all canonical edge kinds, normal successors, SSA, natural-loop membership/latches/exits/post-dominators (or explicitly says no natural loops), and actual recovered regions/fallbacks. The test no longer runs auxiliary `ForHeader` or counter analyses.

The candidate adds only test-gated diagnostics: actual `region_at` entry/return and frame, actual `try_region` Catches shape/frame, first labeled `retry_loop_facts` refusal, and the full pre-`overlapping_owner` tree plus flattened owner occurrences. The flattened list is accompanied by the whole tree because `Region::blocks()` intentionally folds selected in-region aliases.

Facts versus hypothesis: source review shows the real overlap check runs after the candidate tree is complete, and non-While loop ownership suppresses a header from the flattened owner list when the body already owns it. Root's proposed handler-fork/retry explanation remains unproven until the trace runs.

`commands.json` contains bare Cargo argv so `run_validation.py` can validate its test summaries and binary cleanup. The root launcher must set `JRE_LOOP2_IR_PROBE=1` only on the Cargo child and record that override. Because absolute `include_bytes!` inputs are external to the runner's Rust source snapshot, the root launcher must re-open/hash both class inputs, baseline receipt, review JSON, and runner pins before and in finally. See `runner-spec.json`.

Recheck every pin and resource precondition before any future root-owned guarded run. Require >=5 GiB free, target absent and under 1 GiB, default stack, exact source restore, temporary test removal, and target absence in finally.
