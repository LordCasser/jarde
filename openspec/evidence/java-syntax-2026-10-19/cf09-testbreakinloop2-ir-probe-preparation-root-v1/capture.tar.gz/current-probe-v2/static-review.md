# v2 static format and scope review

No compilation or test execution was performed.

For candidate.patch's newly added `eprintln!` calls, positional placeholder/argument counts were reviewed individually:

- `prefinal-region-owner-path`: one positional `blocks={:?}` receives the collected BCI vector; `region_index` and `region` are named captures.
- `actual-region-at-enter`: two positional fields (`depth={}`, `visited={:?}`) receive `self.depth` and the collected visit BCIs; `start` and `frame` are named captures.
- `actual-region-at-exit`: one positional `depth={}` receives `self.depth`; `start` and `walked` are named captures. The stale extra `walked` argument is removed.
- `retry_loop_facts first-refusal`: both fields are named captures (`reason`, `start`); no positional arguments.
- both `actual-try-shape` forms: fields are named captures; no positional arguments.
- remaining prefinal/BCI 0 messages have only named captures and no positional arguments.

Debug bounds were checked in the pinned source: `Frame` and `Region` derive Debug; `Catches` derives Debug; `StopReason` and Region recovery result types derive Debug; canonical IDs/edges and `Operation` facts derive Debug.

Probe module scope is limited to physical Code, exception-handler facts, decoded operations, canonical edges, normal-flow successors, same-run SSA, natural-loop facts (with an explicit no-loops message), and actual recovery. Auxiliary ForHeader and counter-analysis code is absent.
