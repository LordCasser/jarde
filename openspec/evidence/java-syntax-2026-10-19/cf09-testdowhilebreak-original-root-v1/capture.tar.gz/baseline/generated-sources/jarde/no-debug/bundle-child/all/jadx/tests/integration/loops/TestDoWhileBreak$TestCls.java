// jarde: presentation of `jadx/tests/integration/loops/TestDoWhileBreak$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestDoWhileBreak$TestCls extends java.lang.Object {
    public TestDoWhileBreak$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestDoWhileBreak$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public int test(int arg1) throws java.lang.InterruptedException {
        // jarde: not recovered: the recovery run for `test(I)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method test(I)I
        // @declaration an instance method of `jadx.tests.integration.loops.TestDoWhileBreak$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 2 3 5 8 9 10 13 16 17 18 21 22
        // the arms of the branch in block 13 do not meet at one join
    }
}
