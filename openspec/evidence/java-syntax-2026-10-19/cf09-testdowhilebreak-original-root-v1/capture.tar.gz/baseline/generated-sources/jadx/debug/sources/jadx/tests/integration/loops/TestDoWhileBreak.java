package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestDoWhileBreak.class */
public class TestDoWhileBreak extends IntegrationTest {

    /* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestDoWhileBreak$TestCls.class */
    public static class TestCls {
        public int test(int k) throws InterruptedException {
            int i = 3;
            while (k <= 9) {
                i++;
                if (i >= 5) {
                    return i;
                }
            }
            i = 0;
            return i;
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("while (");
    }
}
