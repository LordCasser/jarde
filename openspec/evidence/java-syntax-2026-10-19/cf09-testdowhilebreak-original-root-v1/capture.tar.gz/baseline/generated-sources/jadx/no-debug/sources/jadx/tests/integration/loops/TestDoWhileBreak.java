package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestDoWhileBreak.class */
public class TestDoWhileBreak extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestDoWhileBreak$TestCls.class */
    public static class TestCls {
        public int test(int i) throws InterruptedException {
            int i2 = 3;
            while (i <= 9) {
                i2++;
                if (i2 >= 5) {
                    return i2;
                }
            }
            i2 = 0;
            return i2;
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("while (");
    }
}
