# v1 准备退回记录

保留此记录作为历史，不覆盖 v1。root 对 v1 的静态审查指出：

1. `jarde_complete_compiles` 与 `jadx_complete_compiles` 原先只数 `kind`，会把失败的编译尝试也计作成功；v2 在两项中都要求 `exit_code == 0`，marker 仍须与动态成功数精确相等。
2. v1 未纳入已存在的 `/private/tmp/jarde-testbreakinloop-baseline-prep-review-root-v1-20261019` 与 `/private/tmp/jarde-cf09-breakindoloop-caseplans-review-root-v1-20261019`。v2 将两棵完整树列入静态 inventory 并固定文件/目录 path、bytes、SHA-256、mode。

该审查要求保留 v1 历史并只作上述最小修复；没有授权执行 packer 或任何工具链。
