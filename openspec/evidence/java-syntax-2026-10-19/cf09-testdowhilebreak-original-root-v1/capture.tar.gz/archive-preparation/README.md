# TestDoWhileBreak 证据归档准备

这是私有归档器准备，尚未生成归档。归档器复用已接受的 Break v2 packer，保留原始目录树、raw streams、失败结果与文件 mode；计划生成确定性 tar/gzip 后逐成员重开校验完整路径集合、类型、mode、字节和 SHA-256。

归档将包含完整 DoWhileBreak prep 树、root 对 prep 的静态审查树、baseline capture 树、独立 baseline audit 树、审计命令的 stdout/stderr raw 文件，以及 JADX LICENSE/NOTICE。prep 内含 caseplans 与 `static-math-precheck.json`；prep-review 是 root 对该静态准备的审查。审计 raw 文件独立保留，baseline/audit 树中的原始收据与审计 JSON 也完整收录。外部 CLI、JDK、JADX 和依赖只按收据路径/SHA复核，不复制工具载荷。

固定实际证据：baseline `execution.json` SHA-256 `b5e89a48be39df7700d11d663fa02d0ebb22865b3a7ea989589854b330cd9602`；`root-review.json` SHA-256 `27b72505573b4154d8c12ff05ab0618518c9f74f1df996457aa5ae8b43a3c2bc`；独立审计 `review.json` SHA-256 `5e4281051ecefd613d3f7f01d9162f819da06feca983df8eb34b4f06be36c8c6`。root 状态为 `root_accepted_full_original_do_while_break_with_explicit_refusal_gap`，并绑定收据、审计和 CLI。

收据有 46 条命令和 8 个 API cell。原始目标为 4 VM/8 observations。Jarde 有 16 次整类编译失败、0 VM；失败保持原样。JADX 有 2 次成功整类编译、4 VM/8 observations，并有两条 JDK 8 框架编译失败（不计为成功编译，也没有对应 VM）。错根控制 2 条。目标方法物理 BCI 共 14；packer 对每个 API cell 独立要求 mapped 与 physical BCI 集合完全相等，并将此作为归档 inventory 的派生覆盖记录，不冒充 root marker 字段。这些注释映射不能当作可执行恢复。真实 Jarde 报告为 `jre_region_arms_do_not_meet`，block 13；这项证据明确保留恢复拒绝缺口，不宣称已修复该用例。

候选 CLI SHA-256 `6c83ec82cd4c6caee86c08e7fefddc2fea675952f936c0e4aa3f295ed9be7fc6` 仅作外部 receipt-pin 校验。静态准备文件、目录、审计 raw 和许可证都由 `pins.json` 固定 path、bytes、SHA-256、mode。`adaptation.diff` 记录从已接受 Break v2 packer 的适配差异；`pins.json` 也固定 collector、driver、reviewer、caseplan、静态审计与归档准备工具的身份。

root 审查后若要生成归档，只需指定新输出路径：

```sh
python3 -B /private/tmp/jarde-testdowhilebreak-evidence-archive-prep-luna-v1-20261019/pack.py \
  --out /private/tmp/new-output/capture.tar.gz
```

本次只完成私有静态准备与语法/pin 检查；没有运行 packer、collector、reviewer、JDK、JADX、Jarde CLI、Cargo、Git 或网络操作，也没有修改共享仓库。


## v2 修正

冻结的 v1 把 `mapped_target_bcis_all_cells` 放进 root marker 计数比较，但接受的 marker 没有该字段。v2 仅从 marker 比较中移除此项；每个 API cell 的 map 覆盖硬检查仍保留，派生覆盖情况另记在 archive inventory。v1 保持原样。
