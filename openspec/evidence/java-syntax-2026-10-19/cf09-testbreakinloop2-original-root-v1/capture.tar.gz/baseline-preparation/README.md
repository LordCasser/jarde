# TestBreakInLoop2 complete-source baseline preparation

This private bundle is unexecuted. It adapts the accepted `TestBreakInComplexIf2` full-source harness while retaining the complete upstream `TestBreakInLoop2.java` (989 bytes, SHA-256 `c5ba3e10ad168e2c6a0f0a6385bfc5c12d7332f33ed5a3535dc023b9925b91aa`), including the outer JUnit test and nested target. The target binary name is `jadx.tests.integration.loops.TestBreakInLoop2$TestCls`, with `<init>()V`, `test(Ljava/util/List;)V`, `funcB(Ljava/util/List;)Z`, and `funcC()Z`; it has no fields or helper classes. The JUnit `test()V` asserts exactly one `while (true) {`, exactly one of `break;` or `return;`, and one each of `throw ex;`, `data.clear();`, and `Thread.sleep(100L);`. These upstream assertions check recovered source; the standalone runtime driver does not invoke JUnit. The collector captures the actual source output rather than requiring one spelling as its only oracle.

The source-derived plan contains two finite calls: a nonempty list `[1, 2]` and `null`. The driver records only externally visible return value, exception class, list state before/after, and target stdout. It does not instrument private call counts. Source inspection predicts both calls return normally without list mutation because `funcB` returns normally without reading its argument, followed by the explicit break. Catch, `funcC`, clear, and sleep are structurally present but unreachable in this fixed concrete execution. These are source-derived expectations, not measured events. Full original/JADX/Jarde runs must establish actual behavior; this plan does not assert a Jarde defect.

The capture keeps the full-source boundary: configured JDK 8 attempts the unmodified outer+target source (retaining any framework major-55/52 boundary result), while JDK 23 `--release 8` builds debug and no-debug profiles. It captures original target observations on both runtimes, eight Jarde API cells (`class`/plain JAR × debug/no-debug × default/all), and complete outer+target JADX output. Each available complete Jarde/JADX source tree is rebuilt with both compilers; only successful identity-checked target outputs enter both-runtime and wrong-CodeSource controls. Raw argv/stdout/stderr, full outer/target source and class trees, physical method inventory, source maps, UTF-8 bounds, BCI provenance, empty cwd, parentless loading, default stack, source/tool snapshots, and cleanup are retained. API source-map checks are recomputed from current reports and physical code; no historical map payload is reopened as current evidence. Conditional command totals derive from actual compile successes.

The archived CF-07 baseline revision log records JADX source commit `2fb1b16386941660fda07e9017285aec40fcb37f`. An adjacent accepted full-source baseline pins the JADX 1.5.6 launcher/JAR. The input source is independently pinned by full path, byte count, and SHA-256; no Git command was used to query the live checkout. Root supplied candidate CLI `/private/tmp/jarde-loop-header-body-boundary-focused-root-v5-20261019/candidate-cli` at SHA-256 `52ff01f7794c962f2fbb9d809612c0cc371ef297de8cb32a29629323d168cbca`. Its product lineage is `c8af822ef`; the product own-CI is pending, so the CLI pin does not imply product acceptance.

After root review, run only with a fresh output directory and a root-supplied candidate CLI path/SHA:

```sh
python3 -B /private/tmp/jarde-testbreakinloop2-baseline-prep-luna-v1-20261019/collect_baseline.py \
  --out /private/tmp/jarde-testbreakinloop2-baseline-root-v1-20261019 \
  --cli /private/tmp/jarde-loop-header-body-boundary-focused-root-v5-20261019/candidate-cli --cli-sha256 52ff01f7794c962f2fbb9d809612c0cc371ef297de8cb32a29629323d168cbca
python3 -B /private/tmp/jarde-testbreakinloop2-baseline-prep-luna-v1-20261019/audit.py \
  --receipt /private/tmp/jarde-testbreakinloop2-baseline-root-v1-20261019/execution.json \
  --cli /private/tmp/jarde-loop-header-body-boundary-focused-root-v5-20261019/candidate-cli --cli-sha256 52ff01f7794c962f2fbb9d809612c0cc371ef297de8cb32a29629323d168cbca \
  --out /private/tmp/jarde-testbreakinloop2-baseline-review-root-v1-20261019
```

`python3 -B static_preflight.py` checks syntax and all source/plan/driver/tool pins. It does not execute the collector, reviewer, Cargo, JDK, Java, JADX, Jarde CLI, Git, or network.
