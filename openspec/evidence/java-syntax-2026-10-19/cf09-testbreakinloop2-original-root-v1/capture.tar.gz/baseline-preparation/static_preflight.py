#!/usr/bin/env python3
"""Read-only static pin/schema preflight; intentionally does not run the collector or tools."""
from pathlib import Path
import ast, hashlib, json, tarfile, re
BASE=Path(__file__).parent
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
SOURCE=Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestBreakInLoop2.java')
REVISION_ARCHIVE=ROOT/'openspec/evidence/java-syntax-2026-10-19/cf07-fixed-original-loops-root-v1/capture.tar.gz'
CLI=Path('/private/tmp/jarde-loop-header-body-boundary-focused-root-v5-20261019/candidate-cli')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,msg):
    if not ok: raise SystemExit(msg)
plan=json.loads((BASE/'caseplans.json').read_text())
need(sha(SOURCE)=='c5ba3e10ad168e2c6a0f0a6385bfc5c12d7332f33ed5a3535dc023b9925b91aa' and SOURCE.stat().st_size==989,'upstream source pin differs')
need((BASE/'source-plan-copy/TestBreakInLoop2.java').read_bytes()==SOURCE.read_bytes(),'local source-plan copy differs')
need(plan['schema']=='test-break-in-loop2-source-plan-v1','plan schema differs')
need(plan['method']['binary_name']=='jadx/tests/integration/loops/TestBreakInLoop2$TestCls' and plan['method']['descriptor']=='(Ljava/util/List;)V','target method identity differs')
need([x['id'] for x in plan['cases']]==['nonempty-list','null-list'],'case order differs')
need(plan['original_check']['assertions']==['containsOne(\"while (true) {\")','containsOneOf(\"break;\", \"return;\")','containsOne(\"throw ex;\")','containsOne(\"data.clear();\")','containsOne(\"Thread.sleep(100L);\")'],'original JUnit assertion list differs')
need(plan['source']['sha256']==sha(SOURCE) and plan['source']['bytes']==989,'plan source pin differs')
need((BASE/'source/jadx/tests/integration/loops/TestBreakInLoop2.java').read_bytes()==SOURCE.read_bytes(),'collector source copy differs')
for p in (BASE/'collect_baseline.py',BASE/'audit.py',BASE/'runtime-bound-cwd.py'):
    ast.parse(p.read_text(),filename=str(p))
need(sha(BASE/'driver/TestBreakInLoop2Driver.java')=='c34ae99c69e752e4821724fbc22f58d42b9c1ec75079b15f6b48de0e9da42554','driver pin differs')
need(sha(BASE/'caseplans.json')=='ba9c5a35a7f7687587d4390cc3217fd25e91e14ac825efcb4de8cdc0caa998af','case-plan pin differs')
need(sha(BASE/'caseplans.json')=='ba9c5a35a7f7687587d4390cc3217fd25e91e14ac825efcb4de8cdc0caa998af','case-plan SHA differs')
need(sha(CLI)=='52ff01f7794c962f2fbb9d809612c0cc371ef297de8cb32a29629323d168cbca','root-supplied candidate CLI pin differs')
need(re.search(r"COLLECTOR_SHA='([0-9a-f]+)'",(BASE/'audit.py').read_text()).group(1)==sha(BASE/'collect_baseline.py'),'auditor collector pin differs')
need(re.search(r"CASE_PLAN_SHA256 = '([0-9a-f]+)'",(BASE/'collect_baseline.py').read_text()).group(1)==sha(BASE/'caseplans.json'),'collector case-plan pin differs')
need("CASE_NAMES = ('nonempty-list', 'null-list')" in (BASE/'collect_baseline.py').read_text(),'collector case constant differs')
need("len(names)==2" in (BASE/'audit.py').read_text(),'auditor case count differs')
collector=(BASE/'collect_baseline.py').read_text(); auditor=(BASE/'audit.py').read_text()
need("('test', '(Ljava/util/List;)V', 0x0001)" in collector and "('funcB', '(Ljava/util/List;)Z', 0x0002)" in collector and "('funcC', '()Z', 0x0002)" in collector,'collector target method contract differs')
need("('test','(Ljava/util/List;)V',0x0001)" in auditor and "('funcB','(Ljava/util/List;)Z',0x0002)" in auditor and "('funcC','()Z',0x0002)" in auditor,'auditor target method contract differs')
need("len(original)==4" in auditor and "len(api_cells)==len(expected_api)" in auditor,'auditor runtime/API grid closure differs')
need("wrong CodeSource:" in (BASE/'driver/TestBreakInLoop2Driver.java').read_text() and "'-Xverify:all'" in collector,'parentless/verified runtime contract missing')
for path,expected in [
 (Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018/execution.json'),'5a7d6572e600d19dc45d78030d0b12867bc742c4b014381fb5c7b059db171d35'),
 (Path('/private/tmp/jarde-testnotindexedloop-baseline-prep-luna-v2-20261019/runtime-bound-cwd.py'),'bc917ec08e07ed462c18958f9a0d3b064b7d5bba3adc5fa41d9db49ff6c3de46'),
 (Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx'),'64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'),
 (Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar'),'966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'),
 (ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'),
 (ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py','51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'),
 (ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py','d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'),
 (ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json','ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'),
 (Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py'),'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'),
 (REVISION_ARCHIVE,'')]:
    need(path.is_file(),f'missing pinned input: {path}')
    if expected: need(sha(path)==expected,f'input pin differs: {path}')
with tarfile.open(REVISION_ARCHIVE,'r:gz') as archive:
    member='legacy/java-syntax-2026-09-27/cf07-basic-loops/baseline/jadx-revision.log'
    raw=archive.extractfile(member).read().decode('utf-8','strict')
    need('2fb1b16386941660fda07e9017285aec40fcb37f' in raw,'archived JADX source revision differs')
print('STATIC_PREFLIGHT_OK: source/plan/driver/scripts/external pins and archived JADX revision reopened; no tool was executed')
