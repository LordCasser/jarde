Source-derived finite observation plan for TestBreakInLoop2. Private calls are not observable from this driver.
