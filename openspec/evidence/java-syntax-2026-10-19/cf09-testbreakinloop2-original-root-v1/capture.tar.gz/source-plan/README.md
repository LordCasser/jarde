# TestBreakInLoop2 source plan

This is a read-only, static plan for the fixed CF-09 original. The complete source is pinned at `/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestBreakInLoop2.java`: 989 bytes, SHA-256 `c5ba3e10ad168e2c6a0f0a6385bfc5c12d7332f33ed5a3535dc023b9925b91aa`. The captured CF-07 JADX revision record says `2fb1b16386941660fda07e9017285aec40fcb37f`; the adjacent accepted baseline pins JADX 1.5.6 and its jar hash in `case-plan.json`. No Git command was used, so the commit pin is the archived checkout record rather than a live repository query.

The target is `jadx.tests.integration.loops.TestBreakInLoop2$TestCls`; the relevant methods are `<init>()V`, `test(Ljava/util/List;)V`, `funcB(Ljava/util/List;)Z`, and `funcC()Z`. The JUnit `test()V` checks five output fragments. There is no public `check()` oracle.

The two proposed finite calls exercise the only concrete reachable path: `funcB` returns normally and the loop immediately breaks. A nonempty list and `null` both remain unchanged because `funcB` does not read its argument. The catch, `funcC`, clear, and sleep are required structural output but are not reachable for this fixed implementation. Do not invent thrown exceptions or claim those branches were dynamically exercised.

The full original/JADX/Jarde comparison remains pending. In particular, source inspection alone does not establish the bytecode layout, exact exception table, recovered-source quality, or runtime agreement. `case-plan.json` lists the questions for that comparison and records that no Jarde defect is asserted. No toolchain or CLI was run.
