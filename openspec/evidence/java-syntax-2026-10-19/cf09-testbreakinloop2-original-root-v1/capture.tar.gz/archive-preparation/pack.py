import gzip,hashlib,io,json,stat,tarfile
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
TMP=Path('/private/tmp')
OUT=TMP/'jarde-breakinloop2-baseline-archive-root-v1-20261019'
roots={
 'source-plan':TMP/'jarde-testbreakinloop2-source-plan-luna-v1-20261019',
 'root-source-plan-review':TMP/'jarde-testbreakinloop2-source-plan-root-review-v1-20261019',
 'baseline-preparation':TMP/'jarde-testbreakinloop2-baseline-prep-luna-v1-20261019',
 'actual-launch':TMP/'jarde-testbreakinloop2-baseline-launch-root-v1-20261019',
 'actual-baseline':TMP/'jarde-testbreakinloop2-baseline-root-v1-20261019',
 'archive-preparation':Path(__file__).resolve().parent,
}
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not OUT.exists()
accepted=json.loads((roots['actual-baseline']/'root-review.json').read_bytes())
receipt=(roots['actual-baseline']/'execution.json').read_bytes()
assert sha(receipt)==accepted['receipt_sha256'] and accepted['source_unchanged'] and accepted['target_absent']
CLI=TMP/'jarde-loop-header-body-boundary-focused-root-v5-20261019/candidate-cli'
assert sha(CLI.read_bytes())=='52ff01f7794c962f2fbb9d809612c0cc371ef297de8cb32a29629323d168cbca'
excluded=[]
rows=[];data={}
for label,base in roots.items():
 assert base.is_dir() and not base.is_symlink()
 for p in sorted(base.rglob('*')):
  assert not p.is_symlink()
  if p.is_dir():continue
  assert p.is_file() and '__pycache__' not in p.parts
  if p==CLI:
   excluded.append(dict(path=str(p),sha256=sha(p.read_bytes()),bytes=p.stat().st_size,mode=stat.S_IMODE(p.stat().st_mode)));continue
  b=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode);name=label+'/'+str(p.relative_to(base))
  assert name not in data
  data[name]=(p,b,mode);rows.append(dict(archive_path=name,source_path=str(p),bytes=len(b),sha256=sha(b),mode=mode))
assert len(excluded)==0
manifest=dict(excluded_external_cli=excluded,schema='breakinloop2-original-full-comparison-root-v1',members=rows,payload_member_count=len(rows),accepted_probe=accepted,notes=['Accepted original full-source baseline: 46 commands; original/JADX eight observations each match. Eight Jarde target ownership refusals, sixteen full compilation failures, no Jarde runtime. No IR probe or repair claim.','Historical unexecuted preparations retained. No CLI/toolchain payload.'])
blob=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
OUT.mkdir(parents=True);archive=OUT/'capture.tar.gz'
with archive.open('xb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,(_,b,mode) in sorted(data.items()):
    m=tarfile.TarInfo(name);m.size=len(b);m.mode=mode;t.addfile(m,io.BytesIO(b))
   m=tarfile.TarInfo('ARCHIVE_INVENTORY.json');m.size=len(blob);m.mode=0o644;t.addfile(m,io.BytesIO(blob))
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(data)+1
 for name,(p,b,mode) in data.items():
  m=t.getmember(name);assert m.isfile() and m.mode==mode and t.extractfile(m).read()==b and p.read_bytes()==b and stat.S_IMODE(p.stat().st_mode)==mode
 assert t.extractfile('ARCHIVE_INVENTORY.json').read()==blob
(OUT/'capture.tar.gz.inventory.json').write_bytes(blob)
result=dict(status='root_packed_and_reopened_every_payload_bytes_modes',payload_members=len(data),archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,inventory_sha256=sha(blob))
(OUT/'root-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
