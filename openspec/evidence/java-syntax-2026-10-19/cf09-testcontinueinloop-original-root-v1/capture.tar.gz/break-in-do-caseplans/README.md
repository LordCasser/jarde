# CF09 fixed break-loop case plans

This is a source-only plan, not execution evidence and not a claim about current Jarde behavior. Both complete upstream Java files were read in place and pinned; neither source was edited or reduced. The outer JUnit test remains part of each complete file and should not be invoked by a standalone target driver. Neither file has an outer `check()` method.

`TestBreakInLoop.java` is 731 bytes, SHA256 `1d2723c3e1ab176684610fc3732e01c0007156d22f8a627114ec0ccf472c6cb0`. Its nested `TestCls` declares `public int f` and `public void test(int[] a, int b)` (`([II)V`); the compiler supplies its no-argument constructor. The fixed test asserts the for-loop header, `if (i < b)`, one `break;`, `this.f++;`, and no `else`. Five cases distinguish empty/post-loop behavior, full traversal and latch, break after mutation, reachable integer wrap, and null-array failure before the field increment.

`TestDoWhileBreak.java` is 563 bytes, SHA256 `7c8db1024a14626aaafdd977a722665e077f8e17f5751f2249bc7be6e9eba577`. Its nested `TestCls` declares `public int test(int k)` (`(I)I`) and no fields; the compiler supplies its no-argument constructor. The fixed test asserts only that a `while (` appears. Two cases at k=9 and k=10 distinguish the strict threshold, do-first execution, latch, and break-before-increment. The declared `InterruptedException` is not thrown. Integer overflow is unreachable in this method because `i` remains within 0..5.

The exact cases and mathematical projections are in `caseplans.json`. These are minimal source-derived observations, not full acceptance criteria: a future baseline still needs full-source compilation and inventory, original JDK observations, full JADX/Jarde outputs, and any generated-source recompilation/runtime checks.
