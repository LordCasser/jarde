#!/usr/bin/env python3
"""Independent read-only audit of a completed TestContinueInLoop capture."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, re, zipfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
SCHEMA = 'test-continue-in-loop-full-source-baseline-v1'
COLLECTOR_PATH = Path('/private/tmp/jarde-testcontinueinloop-baseline-prep-luna-v1-20261019/collect_baseline.py')
COLLECTOR_SHA256 = 'f89d3f41ab6a4212771b78d4b2265b75b91856934152fc3e0158f60e6bdd123d'
DRIVER_SOURCE_PATH = Path('/private/tmp/jarde-testcontinueinloop-baseline-prep-luna-v1-20261019/driver/TestContinueInLoopDriver.java')
DRIVER_SHA256 = '537debb28604cb12e12120fbaf638ec07ace8ab13225a03d74311651d171eadf'
FROZEN_CASE_NAMES = ('increment-then-break', 'decrement-then-break', 'continue-update-then-later-break', 'two-continues-run-two-updates', 'negative-bound-full-traversal-and-nonzero-f', 'empty-array-still-increments-f', 'null-array-throws-before-f-update', 'f-increment-wraps-as-java-int')
JDK_MANIFEST_PATH = Path('/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json')
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
UPSTREAM_SOURCE_SHA256 = '9013fc2ce9ac89c4e8967ddef39ead5f66dfc8c692f6529583bb75d96c38d8ec'
UPSTREAM_SOURCE_BYTES = 812
INTERNAL = 'jadx/tests/integration/loops/TestContinueInLoop$TestCls'
OUTER = 'jadx/tests/integration/loops/TestContinueInLoop'
DRIVER = 'TestContinueInLoopDriver'
CASE_PLAN_PATH = Path(__file__).with_name('case-plan.json')
CASE_PLAN_SHA256 = '14da8ab14958f9e1304d5492be79b30860c4e3f2109010d5a724db86f4b19013'
CASE_PLAN_REVIEW_PATH = Path(__file__).with_name('case-plan-root-review.json')
CASE_PLAN_REVIEW_SHA256 = '14b55d8c25bc3d1060b6b13947e9db9113b810ebe743d931b72920206e674976'
PROFILES = ('debug', 'no-debug')
FORMS = ('child', 'bundle-child')
EVIDENCE = ('default', 'all')
RUNTIMES = ('javac8', 'javac23')
METHODS = {('<init>', '()V'), ('test', '([II)V'), ('check', '()V')}
EXPECTED_FIELDS = {('f', 'I', 1)}
OUTER_METHODS = {('<init>', '()V'), ('test', '()V')}
CASE_EXPECTED = {
    'increment-then-break': ('array=[-1,9];b=2;f=3', 'array=[0,9];f=4', 'none', ''),
    'decrement-then-break': ('array=[2,7];b=1;f=-4', 'array=[1,7];f=-3', 'none', ''),
    'continue-update-then-later-break': ('array=[2,0,4];b=2;f=10', 'array=[2,1,4];f=11', 'none', ''),
    'two-continues-run-two-updates': ('array=[1,1,0];b=1;f=0', 'array=[1,1,1];f=1', 'none', ''),
    'negative-bound-full-traversal-and-nonzero-f': ('array=[-2,0];b=-1;f=41', 'array=[-1,-1];f=42', 'none', ''),
    'empty-array-still-increments-f': ('array=[];b=0;f=7', 'array=[];f=8', 'none', ''),
    'null-array-throws-before-f-update': ('array=<null>;b=0;f=9', 'array=<null>;f=9', 'java.lang.NullPointerException', ''),
    'f-increment-wraps-as-java-int': ('array=[];b=-5;f=2147483647', 'array=[];f=-2147483648', 'none', ''),
}
CASES = tuple(CASE_EXPECTED)

def require(ok, message):
    if not ok:
        raise AssertionError(message)

def validate_frozen_case_plan():
    require(sha(CASE_PLAN_PATH) == CASE_PLAN_SHA256, 'frozen source case-plan SHA mismatch')
    require(sha(CASE_PLAN_REVIEW_PATH) == CASE_PLAN_REVIEW_SHA256, 'root case-plan review SHA mismatch')
    plan = json.loads(CASE_PLAN_PATH.read_text(encoding='utf-8'))
    accepted = json.loads(CASE_PLAN_REVIEW_PATH.read_text(encoding='utf-8'))
    require(plan.get('schema') == 'cf09-testcontinueinloop-finite-case-plan-v1'
            and plan.get('status', '').startswith('mathematical plan'), 'case plan is not the frozen source-only plan')
    require(accepted.get('status') == 'root_accepted_source_mathematical_trace_only'
            and accepted.get('caseplan_sha256') == CASE_PLAN_SHA256
            and accepted.get('no_target_jvm_jadx_jarde_execution') is True,
            'root review does not accept this exact source-only case plan')
    require(plan.get('source_sha256') == UPSTREAM_SOURCE_SHA256
            and plan.get('method') == 'TestContinueInLoop.TestCls.test(int[], int):void',
            'case-plan source/method identity differs')
    planned = plan.get('cases', [])
    reviewed = accepted.get('cases', [])
    require(tuple(row.get('id') for row in planned) == FROZEN_CASE_NAMES
            and len(reviewed) == len(planned), 'case-plan case count/order differs')
    def arr(values):
        return '<null>' if values is None else '[' + ','.join(str(x) for x in values) + ']'
    for source, root in zip(planned, reviewed):
        name = source['id']
        expected = CASE_EXPECTED[name]
        projection = (f"array={arr(source['initial_array'])};b={source['b']};f={source['initial_f']}",
                      f"array={arr(source['final_array'])};f={source['final_f']}",
                      source.get('exception') or 'none', source['target_stdout'])
        require(projection == expected, f'{name}: hardcoded runtime oracle differs from the frozen case plan')
        require(root.get('id') == name and root.get('array') == source['final_array']
                and root.get('f') == source['final_f'] and root.get('exception') == source.get('exception'),
                f'{name}: root mathematical review differs from the source plan')
    return {'case_plan_sha256': CASE_PLAN_SHA256, 'root_review_sha256': CASE_PLAN_REVIEW_SHA256,
            'case_count': len(planned), 'source_math_only': True}

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def pin(row, label):
    require(isinstance(row, dict) and {'path', 'bytes', 'sha256'} <= row.keys(), f'{label}: malformed pin')
    path = Path(row['path']).resolve(strict=True)
    raw = path.read_bytes()
    require(len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'], f'{label}: pin mismatch')
    return path

def walk_pins(value, label='receipt'):
    records = 0
    paths = set()
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            path = pin(value, label)
            return 1, {str(path)}
        for key, child in value.items():
            count, found = walk_pins(child, f'{label}.{key}')
            records += count; paths |= found
    elif isinstance(value, list):
        for index, child in enumerate(value):
            count, found = walk_pins(child, f'{label}[{index}]')
            records += count; paths |= found
    return records, paths

def pin_rows(value):
    rows = []
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys(): rows.append(value)
        else:
            for child in value.values(): rows.extend(pin_rows(child))
    elif isinstance(value, list):
        for child in value: rows.extend(pin_rows(child))
    return rows

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def norm(value):
    if isinstance(value, dict): return {k: norm(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [norm(v) for v in value]
    return value

def utf8_boundaries(text):
    result = {0}; offset = 0
    for char in text:
        offset += len(char.encode('utf-8')); result.add(offset)
    return result

def parse_rows(raw, expected_names):
    import base64
    lines = raw.decode('utf-8', errors='strict').splitlines()
    require(len(lines) == len(expected_names), f'expected {len(expected_names)} runtime rows, got {len(lines)}')
    rx = re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) target_stdout_b64=([^ ]*)$')
    dec = lambda value: base64.b64decode(value, validate=True).decode('utf-8', errors='strict')
    rows = []
    for i, line in enumerate(lines):
        match = rx.fullmatch(line)
        require(match is not None, f'malformed runtime row: {line!r}')
        index, name, inp, result, exc, msg, stack, stdout = match.groups()
        require(int(index) == i and name == expected_names[i] and name in CASE_EXPECTED,
                f'case order/identity mismatch: {line!r}')
        rows.append({'index': i, 'name': name, 'input': dec(inp), 'result': dec(result),
                     'exception_type': exc, 'exception_message': dec(msg),
                     'exception_stack': dec(stack), 'target_stdout': dec(stdout), 'raw': line})
    return rows

def matches_manual_cases(rows):
    observed = {row['name']: (row['input'], row['result'], row['exception_type'], row['target_stdout']) for row in rows}
    return observed == CASE_EXPECTED

def projection(rows):
    return [(r['name'], r['input'], r['result'], r['exception_type'], r['target_stdout']) for r in rows]

def parse_class(compare, physical, path, label):
    parsed = compare.parse_class(path)
    independent = physical.parse_class_file(path.read_bytes())
    require(parsed['class_name'] == independent['class_name'] and parsed['major'] == independent['major']
            and parsed['methods'] == independent['methods'], f'{label}: independent method/Code parser mismatch')
    require(sorted((x['name'], x['descriptor'], x['access']) for x in independent['fields'])
            == sorted(parsed['fields']), f'{label}: independent field parser mismatch')
    parsed['access'] = independent['access']
    require(len({(m['name'], m['descriptor']) for m in parsed['methods']}) == len(parsed['methods']),
            f'{label}: duplicate physical method identity')
    for method in parsed['methods']:
        code = method.get('code')
        require(code is not None and code.get('bcis') and code['bcis'][0] == 0
                and code['bcis'][-1] < code['code_length'], f'{label}: invalid Code/BCI inventory')
    return parsed, independent

def class_tree(compare, root):
    return {p.relative_to(root).as_posix(): compare.pin(p) for p in sorted(root.rglob('*.class'))}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--receipt', type=Path, required=True)
    ap.add_argument('--expected-cli-sha256', required=True, help='root-supplied exact CLI pin')
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    receipt_path = args.receipt.resolve(strict=True); out = args.out.resolve()
    require(not out.exists(), f'refusing existing output {out}')
    require(len(args.expected_cli_sha256) == 64 and all(c in '0123456789abcdef' for c in args.expected_cli_sha256),
            'expected CLI hash must be 64 lowercase hex chars')
    data = json.loads(receipt_path.read_text(encoding='utf-8'))
    frozen_plan = validate_frozen_case_plan()
    require(data.get('schema') == SCHEMA, 'receipt schema mismatch')
    require(data.get('status') in ('captured-pending-independent-review', 'failed'), 'receipt is not terminal capture data')
    require(Path(data['root']).resolve() == ROOT.resolve(), 'workspace root mismatch')
    require(data.get('candidate_cli_sha256_expected') == args.expected_cli_sha256, 'root-provided CLI SHA differs from collector argument')
    records, unique = walk_pins(data)
    all_pin_rows = pin_rows(data)
    require(sha(COLLECTOR_PATH) == COLLECTOR_SHA256 and sha(DRIVER_SOURCE_PATH) == DRIVER_SHA256,
            'frozen v3 collector/driver source changed since reviewer preparation')
    require(any(Path(row['path']).resolve() == COLLECTOR_PATH.resolve() and row['sha256'] == COLLECTOR_SHA256
                for row in all_pin_rows), 'receipt does not bind the frozen v3 collector')
    require(pin(data['cli'], 'candidate CLI') and data['cli']['sha256'] == args.expected_cli_sha256, 'CLI pin mismatch')

    commands = data.get('commands', [])
    command_map = {row.get('index'): row for row in commands}
    require(len(command_map) == len(commands) and set(command_map) == set(range(1, len(commands) + 1)),
            'command indices are duplicated or noncontiguous')
    labels = [row.get('label') for row in commands]
    require(len(set(labels)) == len(labels), 'command labels are duplicated')
    for row in commands:
        require(row.get('guard_stop') is None, f'guard stopped command {row.get("label")}')
        require(isinstance(row.get('peak_target_bytes'), int) and row['peak_target_bytes'] <= 1024**3,
                f'target-size guard invalid for {row.get("label")}')
        require(isinstance(row.get('free_bytes_after'), int) and row['free_bytes_after'] >= 5 * 1024**3,
                f'5 GiB free-space guard invalid for {row.get("label")}')
        for channel in ('stdout', 'stderr'):
            pin(row['streams'][channel], f'{row.get("label")} {channel}')
        require(isinstance(row.get('argv'), list) and row['argv'], f'missing actual argv for {row.get("label")}')

    require(data.get('source_unchanged') is True and data.get('source_unchanged_finally') is True,
            'workspace source-closure guard is false')
    require(data.get('target_absent') is True and data.get('target_absent_finally') is True,
            'capture target-absence guard is false')
    require(data.get('external_inputs_unchanged') is True and data.get('local_copies_unchanged') is True
            and data.get('local_copies_unchanged_finally') is True, 'external/local guard is false')
    require(data['source_pins_before'] == data['source_pins_after'] == data['source_pins_after_finally'],
            'workspace source snapshots differ')
    require(data['external_input_pins_before'] == data['external_input_pins_after'] == data['external_input_pins_after_finally'],
            'external tool/dependency snapshots differ')
    require(data['local_copy_pins_before'] == data['local_copy_pins_after'] == data['local_copy_pins_after_finally'],
            'local copy snapshots differ')
    compare_path = pin(data['compare'], 'compare helper')
    parser_path = pin(data['physical_parser'], 'physical parser')
    manifest_record = data.get('jdk_manifest', {})
    require(Path(manifest_record.get('path', '')).resolve(strict=True) == JDK_MANIFEST_PATH.resolve()
            and manifest_record.get('sha256') == JDK_MANIFEST_SHA256,
            'JDK manifest identity differs from the frozen controls manifest')
    manifest_path = JDK_MANIFEST_PATH.resolve(strict=True)
    require(sha(manifest_path) == JDK_MANIFEST_SHA256, 'JDK manifest content SHA differs')
    jadx_path = pin(data['jadx'], 'JADX launcher')
    jadx_jar_path = pin(data['jadx_jar'], 'JADX jar')
    require(data['jadx_jar']['sha256'] == '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65',
            'JADX jar is not the pinned 1.5.6 dependency')
    compare = load(compare_path, 'continueinloop_compare')
    physical = load(parser_path, 'continueinloop_physical')
    jdks, manifest_tools = compare.configured_jdks(manifest_path, JDK_MANIFEST_SHA256)
    require(set(manifest_record.get('tools', {})) == set(RUNTIMES), 'receipt JDK tool-pin legs differ')
    for leg in RUNTIMES:
        require(set(manifest_record['tools'][leg]) == {'java', 'javac', 'javap'}, f'{leg}: receipt JDK tool set differs')
        for tool in ('java', 'javac', 'javap'):
            row = manifest_record['tools'][leg][tool]
            actual = pin(row, f'{leg} {tool} executable')
            expected = Path(jdks[leg]['tools'][tool]).resolve(strict=True)
            require(actual == expected and row['bytes'] == manifest_tools['tools'][leg][tool]['bytes']
                    and row['sha256'] == manifest_tools['tools'][leg][tool]['sha256'],
                    f'{leg} {tool}: receipt executable pin differs from the checked manifest')

    source = pin(data['source'], 'complete upstream source')
    require(data['source']['sha256'] == UPSTREAM_SOURCE_SHA256 and data['source']['bytes'] == UPSTREAM_SOURCE_BYTES,
            'upstream source differs from the frozen original TestContinueInLoop.java')
    source_copy = pin(data['source_copy'], 'upstream source copy')
    require(source.read_bytes() == source_copy.read_bytes(), 'upstream Java source was not copied byte-for-byte')
    driver_source = pin(data['driver_source'], 'driver source'); driver_copy = pin(data['driver_copy'], 'driver copy')
    require(driver_source == DRIVER_SOURCE_PATH.resolve() and data['driver_source']['sha256'] == DRIVER_SHA256
            and data['driver_source']['bytes'] == DRIVER_SOURCE_PATH.stat().st_size
            and data['driver_copy']['sha256'] == DRIVER_SHA256,
            'receipt driver source/copy does not bind the frozen v3 driver')
    runtime_wrapper = pin(data['runtime_wrapper'], 'runtime wrapper')
    require(driver_source.read_bytes() == driver_copy.read_bytes(), 'driver source copy differs')
    require(data['cli']['sha256'] == args.expected_cli_sha256, 'candidate CLI differs from supplied exact SHA')
    case_names = data['runtime_case_names']
    require(tuple(case_names) == FROZEN_CASE_NAMES and len(set(case_names)) == len(case_names)
            and set(case_names) == set(CASE_EXPECTED), 'receipt does not use the exact eight case-name order and manual cases')
    dependency_classpath = os.pathsep.join(data['dependency_classpath'])
    empty_classpath = (Path(data['output']) / 'empty-classpath').resolve(strict=True)
    require(not list(empty_classpath.iterdir()), 'captured empty classpath is not empty')

    # The raw upstream compile contract includes the nested target, its check method and the outer test.
    profiles = {x['profile']: x for x in data.get('source_profiles', [])}
    require(len(profiles) == len(data.get('source_profiles', [])) and set(profiles) == set(PROFILES),
            'original full-source compiler profile grid is incomplete')
    target_rel, outer_rel = INTERNAL + '.class', OUTER + '.class'
    original_facts = {}; profile_inventory = {}
    findings = []
    for name, row in profiles.items():
        command = command_map[row['command']]
        require(command['label'] == f'javac23-full-source-{name}' and command['exit_code'] == row['exit_code'],
                f'{name}: full-source compiler row/command mismatch')
        argv = command['argv']; debug = '-g' if name == 'debug' else '-g:none'
        require(Path(argv[0]).resolve() == Path(jdks['javac23']['tools']['javac']).resolve()
                and '--release' in argv and argv[argv.index('--release') + 1] == '8'
                and debug in argv and '-encoding' in argv and argv[argv.index('-encoding') + 1] == 'UTF-8'
                and '-proc:none' in argv and '-classpath' in argv
                and argv[argv.index('-classpath') + 1] == dependency_classpath
                and '-sourcepath' in argv and Path(argv[argv.index('-sourcepath') + 1]).resolve() == empty_classpath
                and source_copy.as_posix() in [Path(x).as_posix() for x in argv],
                f'{name}: compiler does not compile the complete copied source as Java 8')
        class_root = Path(row['class_root']).resolve()
        if row['exit_code'] != 0:
            findings.append(f'original {name} full-source compilation failed; raw diagnostics retained')
            continue
        require(set(row['class_tree']) == {target_rel, outer_rel}, f'{name}: original full class tree is incomplete')
        actual_tree = class_tree(compare, class_root)
        require(set(actual_tree) == set(row['class_tree']), f'{name}: live original class tree differs from receipt')
        for rel, recorded in row['class_tree'].items():
            path = pin(recorded, f'{name} original {rel}')
            require(path.read_bytes() == (class_root / rel).read_bytes(), f'{name}: class tree bytes mismatch {rel}')
        child, _ = parse_class(compare, physical, class_root / target_rel, f'{name} target')
        outer, _ = parse_class(compare, physical, class_root / outer_rel, f'{name} outer')
        require(child['class_name'] == INTERNAL and child['major'] == 52, f'{name}: original target identity/major mismatch')
        require(outer['class_name'] == OUTER and outer['major'] == 52, f'{name}: original outer identity/major mismatch')
        require({(m['name'], m['descriptor']) for m in child['methods']} == METHODS,
                f'{name}: target inventory including check()V differs')
        require({(m['name'], m['descriptor']) for m in outer['methods']} == OUTER_METHODS,
                f'{name}: outer test-method inventory differs')
        require(set(tuple(x) for x in child['fields']) == EXPECTED_FIELDS and not outer['fields'], f'{name}: target/outer field inventory differs')
        require(norm(child) == norm(row['target_facts']) and norm(outer) == norm(row['outer_facts']),
                f'{name}: complete parser facts differ from receipt')
        profile_inventory[name] = child
        original_facts[name] = child
        bundle = pin(row['bundle'], f'{name} full class bundle')
        with zipfile.ZipFile(bundle) as archive:
            names = sorted(n for n in archive.namelist() if not n.endswith('/'))
            require(names == sorted(row['class_tree']), f'{name}: class bundle inventory differs')
            for rel in names:
                require(archive.read(rel) == (class_root / rel).read_bytes(), f'{name}: bundle bytes mismatch {rel}')

    # Preserve, but classify honestly, the Java 8 compiler attempt against the full upstream test classpath.
    boundary = data.get('javac8_full_source_boundary')
    require(isinstance(boundary, dict) and boundary.get('command') in command_map, 'missing Java 8 boundary attempt')
    boundary_cmd = command_map[boundary['command']]
    require(boundary_cmd['label'] == 'javac8-full-upstream-source-boundary'
            and boundary_cmd['exit_code'] == boundary['exit_code'], 'Java 8 boundary row/command mismatch')
    boundary_argv = boundary_cmd['argv']
    require(Path(boundary_argv[0]).resolve() == Path(jdks['javac8']['tools']['javac']).resolve()
            and '-source' in boundary_argv and boundary_argv[boundary_argv.index('-source') + 1] == '8'
            and '-target' in boundary_argv and boundary_argv[boundary_argv.index('-target') + 1] == '8'
            and '-classpath' in boundary_argv and boundary_argv[boundary_argv.index('-classpath') + 1] == dependency_classpath
            and '-sourcepath' in boundary_argv and Path(boundary_argv[boundary_argv.index('-sourcepath') + 1]).resolve() == empty_classpath
            and source_copy.as_posix() in [Path(x).as_posix() for x in boundary_argv],
            'JDK8 boundary did not attempt the complete upstream source with the pinned tool/input')
    pin(boundary['stdout'], 'JDK8 boundary stdout'); boundary_stderr = pin(boundary['stderr'], 'JDK8 boundary stderr').read_bytes()
    if boundary['exit_code'] != 0 and b'55.0' in boundary_stderr and b'52.0' in boundary_stderr:
        boundary_classification = 'observed-major-55-versus-52-framework-boundary'
    elif boundary['exit_code'] != 0:
        boundary_classification = 'failed-for-other-or-unclassified-reason'
        findings.append('JDK8 full-source boundary failed without the expected major-version diagnostic')
    else:
        boundary_classification = 'compiled-successfully; no major-version failure observed'

    # Driver compilation, parentless target loading, and the original four-VM runtime oracle.
    driver_compile = data.get('driver_compile', {})
    driver_cmd = command_map[driver_compile.get('command')]
    driver_empty_classpath = Path(driver_cmd['argv'][driver_cmd['argv'].index('-classpath') + 1]).resolve()
    require(driver_cmd['label'] == 'compile-independent-reflection-driver'
            and Path(driver_cmd['argv'][0]).resolve() == Path(jdks['javac8']['tools']['javac']).resolve()
            and driver_copy.as_posix() in [Path(x).as_posix() for x in driver_cmd['argv']]
            and '-classpath' in driver_cmd['argv'] and driver_empty_classpath == empty_classpath
            and empty_classpath.is_dir() and not list(empty_classpath.iterdir()),
            'standalone driver compile argv/source/classpath mismatch')
    driver_classes = [pin(x, 'driver class') for x in data['driver_classes']]
    driver_root = driver_classes[0].parent
    driver_names = sorted(x.relative_to(driver_root).as_posix() for x in driver_classes)
    require(driver_names == [DRIVER + '$TypeDescriptor.class', DRIVER + '.class'], 'unexpected driver class inventory')
    driver_source_text = driver_copy.read_text(encoding='utf-8')
    names_match = re.search(r'private\s+static\s+final\s+String\[\]\s+NAMES\s*=\s*\{([^}]*)\}', driver_source_text)
    require(names_match is not None, 'driver source does not expose its ordered case-name array')
    driver_names = re.findall(r'"([A-Za-z0-9-]+)"', names_match.group(1))
    require(driver_names == case_names, 'receipt case order differs from pinned driver source')
    for required in ('new URL[]{Paths.get(actual).toUri().toURL()}, null', 'target.getClassLoader() != loader',
                     'wrong CodeSource:', 'requireEmptyCwd(cwd)', 'TestContinueInLoop$TestCls'):
        require(required in driver_source_text, f'driver source lacks isolation/case contract: {required}')
    for summary in data.get('driver_class_summaries', []):
        require(summary.get('class_name') in (DRIVER, DRIVER + '$TypeDescriptor'), 'driver class summary identity mismatch')

    runtime_grid = set(); original_projections = []; runtime_matches = []; original_manual_matches = []
    for run in data.get('original_runtime', []):
        profile, vm = run['profile'], run['runtime']; runtime_grid.add((profile, vm))
        cmd = command_map[run['command']]; argv = cmd['argv']
        require(cmd['label'] == f'original-runtime-{profile}-{vm}' and cmd['exit_code'] == run['exit_code'],
                f'{profile}/{vm}: original runtime command mismatch')
        require(len(argv) == 13 and argv[1] == '-B' and Path(argv[2]).resolve() == runtime_wrapper.resolve()
                and argv[3] == '30' and Path(argv[5]).resolve() == Path(jdks[vm]['tools']['java']).resolve()
                and argv[6] == '-Xverify:all' and argv[7] == '-cp' and Path(argv[8]).resolve() == driver_root
                and argv[9] == DRIVER, f'{profile}/{vm}: actual parentless JVM argv mismatch')
        target_root = Path(profiles[profile]['class_root']).resolve()
        require(Path(argv[10]).resolve() == Path(argv[11]).resolve() == target_root
                and Path(argv[12]).resolve() == Path(argv[4]).resolve(), f'{profile}/{vm}: actual/expected root or cwd mismatch')
        cwd = Path(argv[4]).resolve(strict=True)
        require(not list(cwd.iterdir()), f'{profile}/{vm}: runtime cwd is not empty after execution')
        stdout = pin(run['stdout'], f'{profile}/{vm} stdout').read_bytes(); pin(run['stderr'], f'{profile}/{vm} stderr')
        if run['exit_code'] != 0:
            findings.append(f'original {profile}/{vm} VM failed with exit {run["exit_code"]}')
            continue
        rows = parse_rows(stdout, case_names)
        require(rows == run['rows'], f'{profile}/{vm}: raw stdout differs from parsed receipt rows')
        manual_match = matches_manual_cases(rows)
        original_manual_matches.append(manual_match)
        if not manual_match: findings.append(f'{profile}/{vm}: eight-case manual behavior oracle differs: {projection(rows)!r}')
        original_projections.append(projection(rows)); runtime_matches.append((profile, vm))
    require(len(data.get('original_runtime', [])) == 4
            and runtime_grid == {(p, vm) for p in PROFILES for vm in RUNTIMES}, 'original runtime grid is incomplete or duplicated')
    observed_agreement = len(original_projections) == 4 and all(x == original_projections[0] for x in original_projections)
    if not observed_agreement: findings.append('original successful VM rows do not agree across all four cells')
    if data.get('runtime_semantic_agreement') is not observed_agreement:
        findings.append('collector original-runtime agreement flag differs from independently parsed rows')

    wrong = data.get('wrong_root_control')
    require(isinstance(wrong, dict) and wrong.get('command') in command_map,
            'wrong-CodeSource control record/command is missing')
    wrong_cmd = command_map[wrong['command']]; wa = wrong_cmd['argv']
    successful_original_roots = {str(Path(row['class_root']).resolve()) for row in profiles.values() if row['exit_code'] == 0}
    require(wrong_cmd['label'] == 'driver-code-source-wrong-root-control' and len(wa) == 13
            and Path(wa[5]).resolve() == Path(jdks['javac23']['tools']['java']).resolve()
            and wa[6] == '-Xverify:all' and wa[7] == '-cp' and Path(wa[8]).resolve() == driver_root
            and wa[9] == DRIVER and Path(wa[10]).resolve() == Path(wrong['actual_target_root']).resolve()
            and str(Path(wa[10]).resolve()) in successful_original_roots
            and Path(wa[11]).resolve() == Path(wrong['expected_wrong_root']).resolve() == empty_classpath
            and Path(wa[12]).resolve() == Path(wa[4]).resolve(), 'wrong-root JVM argv/root contract mismatch')
    require(not list(Path(wa[4]).resolve(strict=True).iterdir()), 'wrong-root runtime cwd is not empty')
    wrong_rejected = (wrong.get('rejected') is True and wrong.get('exit_code') == 1
                      and wrong_cmd['exit_code'] == 1
                      and b'wrong CodeSource:' in pin(wrong['stderr'], 'wrong-root stderr').read_bytes())
    if not wrong_rejected: findings.append('original wrong-CodeSource control did not reject as expected')

    # Validate the eight source API cells from their raw CLI stdout; quality is classified, not predetermined.
    api_cells = data.get('jarde_cells', []); api_results = {}; quality_counts = {}; api_keys = set()
    method_reports = []
    for cell in api_cells:
        key = (cell['profile'], cell['input_form'], cell['evidence']); api_keys.add(key)
        require(cell['profile'] in PROFILES and cell['input_form'] in FORMS and cell['evidence'] in EVIDENCE,
                f'unknown API selector {key}')
        cmd = command_map[cell['command']]
        require(cmd['label'] == f'jarde-{key[0]}-{key[1]}-{key[2]}' and cmd['exit_code'] == cell['exit_code'],
                f'{key}: API command linkage mismatch')
        if cell['exit_code'] != 0:
            pin(cmd['streams']['stdout'], f'{key} failed API stdout')
            pin(cmd['streams']['stderr'], f'{key} failed API stderr')
            findings.append(f'{key}: Jarde CLI returned exit {cell["exit_code"]}')
            continue
        report_path = pin(cell.get('report'), f'{key} raw API report')
        raw_bytes = report_path.read_bytes()
        require(raw_bytes == pin(cmd['streams']['stdout'], f'{key} API stdout').read_bytes(), f'{key}: raw report differs from command stdout')
        doc = json.loads(raw_bytes.decode('utf-8', errors='strict'))
        whole = pin(cell['whole_source'], f'{key} whole source').read_bytes()
        require(doc['text'].encode('utf-8') == whole, f'{key}: whole source bytes differ from raw report')
        profile_row = profiles[key[0]]
        target_path = Path(profile_row['class_root']) / (INTERNAL + '.class')
        if key[1] == 'child':
            expected_input = target_path.resolve(strict=True)
        else:
            expected_input = Path(profile_row['bundle']['path']).resolve(strict=True)
        require(pin(cell['input'], f'{key} API input') == expected_input, f'{key}: input not bound to full target/bundle')
        argv = cmd['argv']
        require(Path(argv[0]).resolve() == Path(data['cli']['path']).resolve()
                and argv[1:3] == ['class-source', '--input'] and Path(argv[3]).resolve() == expected_input,
                f'{key}: CLI argv/input mismatch')
        evidence_ok = (argv.count('--evidence') == 1 and argv[argv.index('--evidence') + 1] == 'all') if key[2] == 'all' else '--evidence' not in argv
        require(argv[argv.index('--class') + 1] == INTERNAL
                and argv[argv.index('--policy') + 1] == ('single-class' if key[1] == 'child' else 'plain-jar')
                and argv[argv.index('--release') + 1] == '8' and argv[argv.index('--format') + 1] == 'json'
                and evidence_ok,
                f'{key}: target/policy/release/evidence argv mismatch')
        target_bytes = target_path.read_bytes() if key[1] == 'child' else zipfile.ZipFile(expected_input).read(INTERNAL + '.class')
        raw_methods = {(m['item']['name']['escaped'], m['item']['descriptor']['escaped']): m for m in doc.get('methods', [])}
        summary = {(m['name'], m['descriptor']): m for m in cell.get('methods', [])}
        require(len(raw_methods) == len(doc.get('methods', [])) == 3 and set(raw_methods) == set(summary) == METHODS,
                f'{key}: complete physical method inventory including check()V differs')
        physical_methods = {(m['name'], m['descriptor']): m for m in profile_row['target_facts']['methods']}
        by_method = {}
        for ident, summary_row in summary.items():
            method = raw_methods[ident]; identity = method['item']['identity']; owner = identity['owner']
            body = method.get('outcome', {}).get('report') or {}
            require(summary_row['identity'] == identity and summary_row['owner'] == owner
                    and summary_row['location'] == owner['location'] and summary_row['variant'] == owner['variant'],
                    f'{key}/{ident}: summary/physical identity mismatch')
            require(owner == doc['class'] and owner['class_bytes']['length'] == len(target_bytes)
                    and identity['name'] == list(ident[0].encode()) and identity['descriptor'] == list(ident[1].encode()),
                    f'{key}/{ident}: report owner/class bytes/member identity mismatch')
            require(summary_row['outcome_kind'] == method['outcome']['kind']
                    and summary_row['quality'] == body.get('quality')
                    and summary_row['raw_text'] == body.get('text')
                    and summary_row['source_map'] == body.get('source_map')
                    and summary_row['fallbacks'] == body.get('fallbacks')
                    and summary_row['regions'] == body.get('regions'), f'{key}/{ident}: raw report and summary disagree')
            quality = summary_row['quality']; quality_counts[quality] = quality_counts.get(quality, 0) + 1
            text = summary_row['raw_text']
            sm = summary_row['source_map']; phys = physical_methods[ident]
            bcis = set((phys.get('code') or {}).get('bcis', [])); mapped = set(); map_issues = []
            if isinstance(sm, dict) and isinstance(sm.get('segments'), list):
                raw_text = text.encode('utf-8'); boundaries = utf8_boundaries(text)
                for i, segment in enumerate(sm['segments']):
                    start, end = segment.get('start'), segment.get('end')
                    if type(start) is not int or type(end) is not int or not 0 <= start <= end <= len(raw_text) or start not in boundaries or end not in boundaries:
                        map_issues.append(f'segment {i} has invalid UTF-8 byte span'); continue
                    origin = segment.get('origin') or {}; refs = [origin.get('primary'), *origin.get('derived', [])]
                    for ref in refs:
                        if not isinstance(ref, dict):
                            map_issues.append(f'segment {i} has malformed anchor'); continue
                        if ref.get('method') != identity: map_issues.append(f'segment {i} anchor identity differs')
                        bci = ref.get('bci')
                        if type(bci) is not int or bci not in bcis: map_issues.append(f'segment {i} has nonphysical BCI {bci!r}')
                        else: mapped.add(bci)
                require(not map_issues, f'{key}/{ident}: invalid map anchors/bounds: {map_issues}')
                require(summary_row['map_audit']['map_present'] is True
                        and set(summary_row['map_audit']['physical_bcis']) == bcis
                        and set(summary_row['map_audit']['mapped_bcis']) == mapped
                        and summary_row['map_audit']['covers_all_physical_bcis'] == (mapped == bcis),
                        f'{key}/{ident}: stored map audit differs from raw map')
                if mapped != bcis:
                    findings.append(f'{key}/{ident}: source map omits physical BCI(s) {sorted(bcis - mapped)}')
                if summary_row['outcome_kind'] == 'recovered' and quality == 'structured':
                    if mapped != bcis or summary_row['map_audit']['issues']:
                        findings.append(f'{key}/{ident}: structured body map has incomplete physical BCI coverage')
            else:
                require(summary_row['map_audit']['map_present'] is False, f'{key}/{ident}: map presence summary mismatch')
                if summary_row['outcome_kind'] == 'recovered' and quality == 'structured':
                    findings.append(f'{key}/{ident}: structured body has no source map')
                findings.append(f'{key}/{ident}: no source map for observed {summary_row["outcome_kind"]}/{quality}')
            by_method[ident] = (summary_row['identity'], summary_row['outcome_kind'], quality,
                                summary_row['raw_text'], summary_row['source_map'])
            method_reports.append({'selector': key, 'name': ident[0], 'descriptor': ident[1],
                                   'outcome_kind': summary_row['outcome_kind'], 'quality': quality,
                                   'raw_text': text,
                                   'map_covers_all_physical_bcis': mapped == bcis if sm else False,
                                   'missing_physical_bcis': sorted(bcis - mapped),
                                   'fallbacks': summary_row['fallbacks'], 'regions': summary_row['regions'],
                                   'representation': body.get('representation'), 'content': body.get('content'),
                                   'map_issues': map_issues})
        api_results[key] = (doc['text'], by_method)
    expected_api = {(p, f, e) for p in PROFILES for f in FORMS for e in EVIDENCE}
    require(len(api_cells) == len(api_keys) == 8 and api_keys == expected_api,
            'eight-cell API selector grid is incomplete or has duplicate cells')
    for profile in PROFILES:
        for form in FORMS:
            default_key, all_key = (profile, form, 'default'), (profile, form, 'all')
            if default_key in api_results and all_key in api_results:
                if norm(api_results[default_key]) != norm(api_results[all_key]):
                    findings.append(f'{profile}/{form}: default/all full text, identity, method text/map differs')
            else:
                findings.append(f'{profile}/{form}: default/all report equality could not be established because an API command failed')

    # Verify complete JADX output capture, but do not assume decompilation success or Java compilation success.
    jadx_outputs = {row['compiler_profile']: row for row in data.get('jadx_outputs', [])}
    require(len(jadx_outputs) == len(data.get('jadx_outputs', [])) and set(jadx_outputs) == set(PROFILES),
            'JADX profile attempts are incomplete')
    jadx_source_count = 0
    for profile, row in jadx_outputs.items():
        cmd = command_map[row['command']]; argv = cmd['argv']
        require(cmd['label'] == f'jadx-full-bundle-{profile}-default' and cmd['exit_code'] == row['exit_code'],
                f'{profile}: JADX command/result mismatch')
        require(Path(argv[0]).resolve() == jadx_path and '--threads-count' in argv and argv[argv.index('--threads-count') + 1] == '1'
                and '--no-res' in argv and argv[argv.index('--config') + 1] == 'none', f'{profile}: full JADX options mismatch')
        bundle = pin(row['input'], f'{profile} JADX input bundle')
        require(bundle == Path(profiles[profile]['bundle']['path']).resolve(strict=True)
                and Path(argv[-1]).resolve() == bundle, f'{profile}: JADX did not receive the complete source bundle')
        for source_row in row.get('sources', []):
            pin(source_row, f'{profile} full JADX source'); jadx_source_count += 1
        destination = Path(argv[argv.index('-d') + 1]).resolve()
        actual_java = {str(p.resolve()) for p in destination.rglob('*.java')} if destination.exists() else set()
        require(actual_java == {x['path'] for x in row.get('sources', [])}, f'{profile}: recorded JADX source tree is incomplete')
        if row['exit_code'] != 0:
            findings.append(f'{profile}: JADX full-bundle decode failed; no source assumed')

    # The collector independently rebuilds every available full API/JADX source cell; failures stay observations.
    source_cells = data.get('generated_source_cells', [])
    source_map = {}
    for cell in source_cells:
        if cell['kind'] == 'jarde': key = (cell['kind'], cell['profile'], cell['form'], cell['evidence'])
        elif cell['kind'] == 'jadx': key = (cell['kind'], cell['profile'], cell['form'], cell['evidence'])
        else: require(False, f'unknown generated source kind {cell.get("kind")}')
        require(key not in source_map, f'duplicate generated source cell {key}')
        source_map[key] = cell
        if not cell.get('source_available'): 
            findings.append(f'{key}: complete source unavailable ({cell.get("reason", "no detail")})')
            continue
        source_root = Path(cell['source_root']).resolve(strict=True)
        java_files = [Path(p).resolve(strict=True) for p in cell.get('java_files', [])]
        require(java_files and {str(p) for p in source_root.rglob('*.java')} == {str(p) for p in java_files},
                f'{key}: copied source tree is not complete')
        for p in java_files: pin(compare.pin(p), f'{key} generated source file')
        if cell['kind'] == 'jarde':
            selector = (cell['profile'], cell['form'], cell['evidence'])
            api = next((x for x in api_cells if (x['profile'], x['input_form'], x['evidence']) == selector), None)
            require(api is not None and pin(cell['source_pin'], f'{key} API source') == pin(api['whole_source'], f'{selector} API whole source')
                    and pin(cell['source_copy'], f'{key} compile copy').read_bytes() == pin(cell['source_pin'], f'{key} API source').read_bytes(),
                    f'{key}: Jarde compile input is not the exact whole API source')
        else:
            origin = jadx_outputs[cell['profile']]
            sources = {str(Path(x['path']).resolve()): x for x in origin.get('sources', [])}
            source_pins = cell.get('source_pins', [])
            copied = cell.get('source_copies', [])
            require(len(source_pins) == len(copied) == len(sources), f'{key}: JADX source closure copy count differs')
            copy_root = Path(cell['source_root']).resolve(strict=True)
            original_root = (Path(data['output']).resolve() / 'jadx' / cell['profile'] / 'default').resolve(strict=True)
            source_by_rel = {Path(row['path']).resolve(strict=True).relative_to(original_root).as_posix(): row
                             for row in origin['sources']}
            pinned_by_rel = {Path(row['path']).resolve(strict=True).relative_to(original_root).as_posix(): row
                             for row in source_pins}
            copy_by_rel = {Path(row['path']).resolve(strict=True).relative_to(copy_root).as_posix(): row
                           for row in copied}
            require(set(source_by_rel) == set(pinned_by_rel) == set(copy_by_rel), f'{key}: JADX source/copy relative inventory differs')
            for rel, source_row in source_by_rel.items():
                src = pin(source_row, f'{key} original JADX source {rel}')
                pinrow_path = pin(pinned_by_rel[rel], f'{key} API source pin {rel}')
                dst = pin(copy_by_rel[rel], f'{key} copied JADX source {rel}')
                require(src == pinrow_path and src.read_bytes() == dst.read_bytes(),
                        f'{key}: JADX source copy bytes changed: {rel}')
    expected_source_keys = {('jarde', p, f, e) for p in PROFILES for f in FORMS for e in EVIDENCE} | {
        ('jadx', p, 'whole-outer-child-tree', 'default') for p in PROFILES}
    require(set(source_map) == expected_source_keys, 'generated full-source cell inventory is incomplete')

    compiles = data.get('generated_source_compilations', [])
    compile_map = {}
    for row in compiles:
        key = (row['kind'], row['profile'], row.get('form'), row.get('evidence'), row['compiler'])
        require(key not in compile_map and row['compiler'] in RUNTIMES, f'duplicate/unknown generated compile cell {key}')
        compile_map[key] = row
        cmd = command_map[row['command']]
        require(cmd['exit_code'] == row['exit_code'] and pin(row['stdout'], f'{key} stdout').read_bytes()
                == pin(cmd['streams']['stdout'], f'{key} raw stdout').read_bytes()
                and pin(row['stderr'], f'{key} stderr').read_bytes() == pin(cmd['streams']['stderr'], f'{key} raw stderr').read_bytes(),
                f'{key}: compiler raw streams/exit differ')
        expected_javac = jdks[row['compiler']]['tools']['javac']
        argv = cmd['argv']; expected_debug = '-g' if row['profile'] == 'debug' else '-g:none'
        require(Path(argv[0]).resolve() == Path(expected_javac).resolve() and expected_debug in argv
                and '-proc:none' in argv and '-encoding' in argv and argv[argv.index('-encoding') + 1] == 'UTF-8'
                and '-classpath' in argv and argv[argv.index('-classpath') + 1] == dependency_classpath
                and '-sourcepath' in argv
                and Path(argv[argv.index('-sourcepath') + 1]).resolve() == empty_classpath
                and '-d' in argv and Path(argv[argv.index('-d') + 1]).resolve() == Path(row['class_root']).resolve(),
                f'{key}: compiler leg/options/output root mismatch')
        if row['compiler'] == 'javac8':
            require('-source' in argv and argv[argv.index('-source') + 1] == '8'
                    and '-target' in argv and argv[argv.index('-target') + 1] == '8', f'{key}: javac8 source/target mismatch')
        else:
            require('--release' in argv and argv[argv.index('--release') + 1] == '8', f'{key}: javac23 release mismatch')
        source_cell = source_map[key[:4]]
        compile_inputs = {str(Path(x).resolve()) for x in argv if str(x).endswith('.java')}
        copied_inputs = {str(Path(x).resolve()) for x in source_cell.get('java_files', [])}
        require(compile_inputs == copied_inputs, f'{key}: compiler did not receive exactly all copied source files')
        root = Path(row['class_root']).resolve()
        actual = class_tree(compare, root)
        require({k: {'bytes': v['bytes'], 'sha256': v['sha256']} for k, v in actual.items()}
                == {k: {'bytes': v['bytes'], 'sha256': v['sha256']} for k, v in row.get('class_tree', {}).items()},
                f'{key}: compiled class output tree differs from recorded tree')
        if row['exit_code'] != 0:
            findings.append(f'{key}: full source compilation failed; no VM row is inferred')
            require(not row.get('runtime_eligible'), f'{key}: failed compiler marked runtime-eligible')
            continue
        # A successful javac exit is not enough: independently parse every produced class.
        parsed_tree = {}
        for rel in actual:
            facts, _ = parse_class(compare, physical, root / rel, f'{key}/{rel}')
            parsed_tree[rel] = facts
        if row.get('class_facts') is None:
            findings.append(f'{key}: compiler succeeded but collector could not produce complete class facts ({row.get("class_facts_error")})')
        else:
            require(norm(parsed_tree) == norm(row['class_facts']), f'{key}: complete class facts differ from independent parsers')
            require(norm(parsed_tree.get(INTERNAL + '.class')) == norm(row.get('target_facts')),
                    f'{key}: target class facts differ from compiled tree facts')
        target = parsed_tree.get(INTERNAL + '.class')
        original = original_facts.get(row['profile'])
        eligible = bool(target and original and target['class_name'] == INTERNAL and target['major'] == 52
                        and sorted((m['name'], m['descriptor'], m['access']) for m in target['methods'])
                        == sorted((m['name'], m['descriptor'], m['access']) for m in original['methods'])
                        and sorted(tuple(f) for f in target['fields']) == sorted(tuple(f) for f in original['fields']))
        require(row.get('runtime_eligible') is eligible, f'{key}: collector runtime eligibility differs from independent facts')
        if not eligible:
            findings.append(f'{key}: compiler exited zero but target binary/inventory is not runtime-eligible')
    expected_compile_keys = set()
    for source_key, cell in source_map.items():
        if cell.get('source_available'):
            expected_compile_keys |= {(*source_key, leg) for leg in RUNTIMES}
    require(set(compile_map) == expected_compile_keys, 'available source/compiler grid has missing or extra attempts')

    # Every eligible compile gets both VMs plus one explicit wrong-root run; failures remain visible.
    compile_eligible = {key for key, row in compile_map.items() if row.get('runtime_eligible') is True and row['exit_code'] == 0}
    runtimes = data.get('generated_runtime', []); wrongs = data.get('generated_wrong_root_controls', [])
    runtime_map = {}; wrong_map = {}; runtime_comparisons = []
    original_by_key = {(row['profile'], row['runtime']): row for row in data.get('original_runtime', [])}
    require(not list(Path(wa[4]).resolve(strict=True).iterdir()), 'wrong-root runtime cwd is not empty')
    for row in runtimes:
        key = (row['kind'], row['profile'], row.get('form'), row.get('evidence'), row['compiler'])
        full = (*key, row['runtime'])
        require(full not in runtime_map and key in compile_eligible and row['runtime'] in RUNTIMES, f'unknown/duplicate generated runtime row {full}')
        runtime_map[full] = row
        cmd = command_map[row['command']]; argv = cmd['argv']
        require(cmd['exit_code'] == row['exit_code'] and len(argv) == 13 and argv[1] == '-B'
                and Path(argv[2]).resolve() == runtime_wrapper.resolve() and argv[3] == '30'
                and Path(argv[5]).resolve() == Path(jdks[row['runtime']]['tools']['java']).resolve()
                and argv[6] == '-Xverify:all' and argv[7] == '-cp' and Path(argv[8]).resolve() == driver_root
                and argv[9] == DRIVER and Path(argv[10]).resolve() == Path(row['class_root']).resolve()
                and Path(argv[11]).resolve() == Path(row['class_root']).resolve()
                and Path(argv[12]).resolve() == Path(argv[4]).resolve(), f'{full}: generated JVM argv/root mismatch')
        require(not list(Path(argv[4]).resolve(strict=True).iterdir()), f'{full}: generated runtime cwd is not empty')
        stdout = pin(row['stdout'], f'{full} stdout').read_bytes(); pin(row['stderr'], f'{full} stderr')
        if row['exit_code'] != 0:
            findings.append(f'{full}: generated VM failed with exit {row["exit_code"]}')
            require(not row.get('rows'), f'{full}: failed VM fabricated parsed rows')
            runtime_comparisons.append({'cell': full, 'exit_code': row['exit_code'], 'matches_original_oracle': False,
                                        'case_differences': []})
            continue
        rows = parse_rows(stdout, case_names)
        require(rows == row['rows'], f'{full}: runtime stdout differs from receipt rows')
        baseline = original_by_key.get((row['profile'], row['runtime']))
        match = baseline is not None and baseline.get('exit_code') == 0 and projection(rows) == projection(baseline['rows'])
        require(row.get('matches_original_oracle') == match, f'{full}: runtime comparison flag differs from raw observations')
        case_differences = []
        if baseline is not None:
            baseline_by_name = {item['name']: item for item in baseline['rows']}
            current_by_name = {item['name']: item for item in rows}
            for name in case_names:
                left, right = baseline_by_name[name], current_by_name[name]
                fields = ('input', 'result', 'exception_type', 'target_stdout')
                differences = {field: {'original': left[field], 'generated': right[field]}
                               for field in fields if left[field] != right[field]}
                if differences: case_differences.append({'case': name, 'differences': differences})
        runtime_comparisons.append({'cell': full, 'exit_code': row['exit_code'],
                                    'matches_original_oracle': match, 'case_differences': case_differences})
        if not match: findings.append(f'{full}: generated runtime differs from original bounded oracle')
    expected_runtime_keys = {(*key, runtime) for key in compile_eligible for runtime in RUNTIMES}
    require(set(runtime_map) == expected_runtime_keys, 'eligible compiler outputs do not have exactly two VM attempts')
    for row in wrongs:
        key = (row['kind'], row['profile'], row.get('form'), row.get('evidence'), row['compiler'])
        require(key not in wrong_map and key in compile_eligible, f'unknown/duplicate generated wrong-root row {key}')
        wrong_map[key] = row; cmd = command_map[row['command']]; argv = cmd['argv']
        require(cmd['exit_code'] == row['exit_code']
                and len(argv) == 13 and Path(argv[5]).resolve() == Path(jdks['javac23']['tools']['java']).resolve()
                and argv[6] == '-Xverify:all' and argv[7] == '-cp' and Path(argv[8]).resolve() == driver_root
                and argv[9] == DRIVER and Path(argv[10]).resolve() == Path(compile_map[key]['class_root']).resolve()
                and Path(argv[11]).resolve() == empty_classpath
                and Path(argv[12]).resolve() == Path(argv[4]).resolve(), f'{key}: wrong-root command did not use actual output/empty root')
        require(not list(Path(argv[4]).resolve(strict=True).iterdir()), f'{key}: generated wrong-root cwd is not empty')
        wrong_ok = (row.get('rejected') is True and row['exit_code'] == 1
                    and b'wrong CodeSource:' in pin(row['stderr'], f'{key} wrong-root stderr').read_bytes())
        if not wrong_ok: findings.append(f'{key}: generated wrong-root control did not reject')
    require(set(wrong_map) == compile_eligible, 'eligible compile outputs lack exactly one wrong-root control')

    require(data.get('generated_outputs_unchanged') is True,
            'collector did not certify generated source/class outputs unchanged')
    source_before = data.get('generated_source_output_pins_before', {})
    source_after = data.get('generated_source_output_pins_after', {})
    require(source_before.keys() == source_after.keys(), 'generated source snapshot paths differ')
    for path, before in source_before.items():
        before_path = pin(before, f'generated source before {path}')
        after_path = pin(source_after[path], f'generated source after {path}')
        require(before_path == after_path == Path(path).resolve(strict=True),
                f'generated source snapshot path mismatch: {path}')
        require(before['bytes'] == source_after[path]['bytes'] and before['sha256'] == source_after[path]['sha256'],
                f'generated source changed during capture: {path}')
    recorded_trees_before = data.get('generated_class_trees')
    if recorded_trees_before == []:
        findings.append('collector schema left top-level generated_class_trees empty; class roots are independently reconstructed from every per-compile row')
    elif recorded_trees_before:
        findings.append('collector top-level generated_class_trees has an unexpected non-empty shape; per-compile trees remain authoritative')
    trees_before = {}
    for row in compiles:
        root = str(Path(row['class_root']).resolve(strict=True))
        require(root not in trees_before, f'duplicate generated class output root: {root}')
        require(isinstance(row.get('class_tree'), dict), f'{root}: per-compile physical class tree is missing')
        trees_before[root] = row['class_tree']
    trees_after = data.get('generated_class_trees_after', {})
    require(trees_before.keys() == trees_after.keys(), 'generated class snapshot roots differ')
    for root, before_tree in trees_before.items():
        require(norm(before_tree) == norm(trees_after[root]), f'generated class snapshot changed: {root}')
        root_path = Path(root).resolve(strict=True)
        actual_tree = class_tree(compare, root_path)
        require(norm(actual_tree) == norm(before_tree), f'generated class tree no longer matches captured bytes: {root}')

    # All planned command labels must link to raw commands; total generated counts are derived from observations.
    base_labels = {'javac8-full-upstream-source-boundary', 'javac23-full-source-debug', 'javac23-full-source-no-debug',
                   'compile-independent-reflection-driver', 'original-runtime-debug-javac8', 'original-runtime-debug-javac23',
                   'original-runtime-no-debug-javac8', 'original-runtime-no-debug-javac23',
                   'driver-code-source-wrong-root-control', 'jadx-version'}
    base_labels |= {f'jarde-{p}-{f}-{e}' for p in PROFILES for f in FORMS for e in EVIDENCE}
    base_labels |= {f'jadx-full-bundle-{p}-default' for p in PROFILES}
    generated_labels = {f'rebuild-{key[0]}-{key[1]}-{key[2]}-{key[3]}-{key[4]}' for key in compile_map}
    generated_labels |= {f'runtime-{k[0]}-{k[1]}-{k[2]}-{k[3]}-{k[4]}-{k[5]}' for k in runtime_map}
    generated_labels |= {f'wrong-root-{k[0]}-{k[1]}-{k[2]}-{k[3]}-{k[4]}' for k in wrong_map}
    require(set(labels) == base_labels | generated_labels, 'raw command labels differ from all original/API/generated attempts')

    result = {
        'receipt': str(receipt_path), 'receipt_sha256': sha(receipt_path), 'schema': SCHEMA,
        'collector_status': data['status'], 'frozen_case_plan': frozen_plan, 'commands': len(commands), 'raw_streams': 2 * len(commands),
        'unique_pinned_paths': len(unique), 'pin_records_reopened': records,
        'original_profiles': sorted(profiles), 'original_runtime_rows': len(data.get('original_runtime', [])),
        'manual_original_runtime_oracle_matches': len(original_manual_matches) == 4 and all(original_manual_matches),
        'original_runtime_rows_agree': observed_agreement,
        'original_wrong_root_rejected': wrong_rejected,
        'jdk8_boundary_classification': boundary_classification,
        'api_cells': len(api_cells), 'api_quality_counts': quality_counts,
        'api_outcomes': [{'selector': m['selector'], 'name': m['name'], 'descriptor': m['descriptor'], 'outcome': m['outcome_kind'],
                          'quality': m['quality'], 'map_covers_all_physical_bcis': m['map_covers_all_physical_bcis'],
                          'missing_physical_bcis': m['missing_physical_bcis'],
                          'fallbacks': m['fallbacks'], 'regions': m['regions'],
                          'representation': m['representation'], 'content': m['content'],
                          'issues': m['map_issues'], 'raw_text': m['raw_text']} for m in method_reports],
        'default_all_exact_text_identity_raw_map_equal': all(
            (p, f, 'default') in api_results and (p, f, 'all') in api_results
            and norm(api_results[(p, f, 'default')]) == norm(api_results[(p, f, 'all')])
            for p in PROFILES for f in FORMS),
        'jadx_profiles': len(jadx_outputs), 'jadx_source_files': jadx_source_count,
        'generated_source_cells': len(source_map), 'generated_compile_attempts': len(compiles),
        'generated_compile_successes': sum(x['exit_code'] == 0 for x in compiles),
        'generated_compile_failures': sum(x['exit_code'] != 0 for x in compiles),
        'runtime_eligible_compiles': len(compile_eligible), 'generated_vm_rows': len(runtimes),
        'generated_runtime_comparisons': runtime_comparisons,
        'generated_wrong_root_rows': len(wrongs), 'observations': findings,
        'scope': 'baseline capture integrity and observations; no upstream JUnit method or check()V is invoked by this audit',
    }
    out.mkdir(parents=True, exist_ok=False)
    (out / 'review.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    (out / 'README.md').write_text('Private independent read-only baseline review. It does not run any compiler, CLI, JDK, or target code. Method quality and generated compile/runtime failures are observations, not predefined success assumptions.\n', encoding='utf-8')
    return result

if __name__ == '__main__':
    print(json.dumps(main(), indent=2, sort_keys=True))
