#!/usr/bin/env python3
"""Prepare and reopen a pinned TestContinueInLoop evidence archive; runs no evidence tools."""
from __future__ import annotations
import argparse, gzip, hashlib, io, json, os, stat, tarfile
from pathlib import Path, PurePosixPath

TMP = Path('/private/tmp').resolve()
HERE = Path(__file__).resolve().parent
MAX_BYTES = 512 * 1024 * 1024
EXPECTED_RECEIPT_SHA256 = 'd33084ce268c7d3c49a056f120619d7e1786b5f438d5bcf8b30d66911ea2c0ec'
EXPECTED_REVIEW_SHA256 = '3c53bac442e35918b04f30da789c26e06dfb3a2ab3f7d65ef24905f7214d62c1'
ROOTS = (
 ('baseline-prep-v1','jarde-testcontinueinloop-baseline-prep-luna-v1-20261019'),
 ('baseline-prep-v2','jarde-testcontinueinloop-baseline-prep-luna-v2-20261019'),
 ('baseline-prep-v3','jarde-testcontinueinloop-baseline-prep-luna-v3-20261019'),
 ('baseline-prep-v4','jarde-testcontinueinloop-baseline-prep-luna-v4-20261019'),
 ('baseline','jarde-testcontinueinloop-baseline-root-v1-20261019'),
 ('baseline-review','jarde-testcontinueinloop-baseline-review-root-v1-20261019'),
 ('baseline-prep-review','jarde-testcontinueinloop-baseline-prep-review-root-v1-20261019'),
 ('continue-caseplan','jarde-cf09-testcontinueinloop-caseplan-luna-v1-20261019'),
 ('continue-caseplan-review','jarde-cf09-testcontinueinloop-caseplan-review-root-v1-20261019'),
 ('break-in-do-caseplans','jarde-cf09-breakindoloop-caseplans-luna-v1-20261019'),
 ('break-in-do-caseplans-review','jarde-cf09-breakindoloop-caseplans-review-root-v1-20261019'),
 ('sequential-loops-caseplan','jarde-cf09-sequential-loops-caseplan-luna-v1-20261019'),
 ('sequential-loops-caseplan-review','jarde-cf09-sequential-loops-caseplan-review-root-v1-20261019'),
)
LICENSES = (
 ('JADX-LICENSE',Path('/Users/lordcasser/workspace/projects/jarde/tests/fixtures/cf08-if-loop-entry/licenses/JADX-LICENSE')),
 ('JADX-NOTICE',Path('/Users/lordcasser/workspace/projects/jarde/tests/fixtures/cf08-if-loop-entry/licenses/JADX-NOTICE')),
)
EMPTY_SHA = hashlib.sha256(b'').hexdigest()

def fail(msg): raise SystemExit('archive refused: '+msg)
def sha(data): return hashlib.sha256(data).hexdigest()
def no_symlink(path: Path) -> Path:
 p=path.absolute()
 for part in (p,*p.parents):
  if part.is_symlink(): fail(f'symlink path component: {part}')
 return p

def read_file(path: Path):
 p=no_symlink(path)
 if not p.is_file(): fail(f'missing/non-regular file: {p}')
 before=p.stat(); data=p.read_bytes(); after=p.stat()
 mode=stat.S_IMODE(after.st_mode)
 if (before.st_size,before.st_mtime_ns,before.st_mode)!=(after.st_size,after.st_mtime_ns,after.st_mode) or len(data)!=after.st_size:
  fail(f'file changed while reading: {p}')
 return data,mode

def review_gate(base: Path):
 rp=no_symlink(base/'root-review.json'); review_bytes,review_mode=read_file(rp)
 if sha(review_bytes)!=EXPECTED_REVIEW_SHA256: fail('root-review marker SHA does not match accepted pin')
 try: review=json.loads(review_bytes)
 except Exception as exc: fail(f'root-review JSON invalid: {exc}')
 receipt_path=no_symlink(base/'execution.json'); receipt_bytes,_=read_file(receipt_path)
 if sha(receipt_bytes)!=EXPECTED_RECEIPT_SHA256: fail('execution receipt SHA does not match accepted pin')
 receipt=json.loads(receipt_bytes)
 if review.get('receipt_sha256')!=EXPECTED_RECEIPT_SHA256: fail('accepted marker does not bind exact receipt SHA')
 status=review.get('status')
 if status!='root_accepted_original_baseline_with_explicit_whole_method_refusal_gap': fail('unexpected accepted marker status')
 if receipt.get('status')!='captured-pending-independent-review': fail('unexpected raw baseline receipt status; preserve root review as separate acceptance layer')
 if receipt.get('output')!=str(base): fail('receipt output path does not name baseline root')
 return {'marker_path':str(rp),'marker_bytes':len(review_bytes),'marker_sha256':sha(review_bytes),'marker_mode':review_mode,
         'receipt_path':str(receipt_path),'receipt_bytes':len(receipt_bytes),'receipt_sha256':sha(receipt_bytes),
         'acceptance_status':status}

def collect():
 base=TMP/'jarde-testcontinueinloop-baseline-root-v1-20261019'
 accepted=review_gate(base)
 entries={}; seen=set()
 def add(name,source,data,mode,is_dir=False):
  rel=PurePosixPath(name)
  if rel.is_absolute() or '..' in rel.parts or not rel.parts: fail(f'unsafe archive path: {name}')
  key=rel.as_posix()
  if key in entries or key=='ARCHIVE_INVENTORY.json': fail(f'duplicate/reserved archive path: {key}')
  src=str(source.absolute())
  if src in seen: fail(f'duplicate source path: {src}')
  seen.add(src); entries[key]=(source,data,mode,is_dir)
 for label,dirname in ROOTS:
  root=no_symlink(TMP/dirname)
  if not root.is_dir(): fail(f'required evidence root missing: {root}')
  add(label+'/',root,b'',stat.S_IMODE(root.stat().st_mode),True)
  paths=sorted(root.rglob('*'),key=lambda p:p.as_posix())
  for p in paths:
   if p.is_symlink(): fail(f'symlink in evidence tree: {p}')
   rel=p.relative_to(root); arc=f'{label}/{rel.as_posix()}'
   if p.is_dir(): add(arc+'/',p,b'',stat.S_IMODE(p.stat().st_mode),True)
   elif p.is_file():
    data,mode=read_file(p); add(arc,p,data,mode)
   else: fail(f'non-regular evidence entry: {p}')
 for name,path in LICENSES:
  data,mode=read_file(path); add(f'licenses/{name}',path,data,mode)
 pins_path=HERE/'pins.json'
 pins_bytes,_=read_file(pins_path)
 try: pins=json.loads(pins_bytes)
 except Exception as exc: fail(f'source pins JSON invalid: {exc}')
 expected={row['path']:{k:v for k,v in row.items() if k!='label'} for row in pins.get('members',[])}
 actual={}
 for source,data,mode,is_dir in entries.values():
  key=str(source.absolute())
  if is_dir: actual[key]={'path':key,'type':'directory','mode':mode}
  else: actual[key]={'path':key,'type':'file','bytes':len(data),'sha256':sha(data),'mode':mode}
 if actual!=expected: fail('evidence inputs differ from the frozen file/directory pins')
 for path in (HERE/'pack.py',HERE/'README.md',HERE/'pins.json'):
  data,mode=read_file(path); add('archive-preparation/'+path.name,path,data,mode)
 size=sum(len(x[1]) for x in entries.values())
 if size>MAX_BYTES: fail(f'payload exceeds {MAX_BYTES} bytes')
 members=[]
 for name,(source,data,mode,is_dir) in sorted(entries.items()):
  members.append({'archive_path':name,'source_path':str(source.absolute()),'entry_type':'directory' if is_dir else 'file',
                  'bytes':len(data),'sha256':sha(data),'mode':mode})
 inventory={'schema':'test-continue-in-loop-evidence-archive-v1','payload_member_count':len(members),
            'payload_bytes':size,'members':members,'accepted_baseline':accepted,
            'notes':['All required evidence and review roots are included as complete trees; empty directories and failed/negative outputs are preserved.',
                     'Only JADX-LICENSE and JADX-NOTICE are copied. External JDK, CLI, and dependency artifacts remain referenced by pinned receipts, not copied.',
                     'Case plans for ContinueInLoop, BreakInDoLoop, and SequentialLoops are planning evidence, not execution or acceptance claims.']}
 return inventory,entries

def verify(out,inventory,entries,blob):
 with tarfile.open(out,'r:gz') as tar:
  members=tar.getmembers(); by={m.name:m for m in members}; expected=set(entries)|{'ARCHIVE_INVENTORY.json'}
  if len(by)!=len(members) or set(by)!=expected: fail('tar has duplicate, missing, or unexpected members')
  for name,(source,data,mode,is_dir) in entries.items():
   info=by[name]
   if info.mode!=mode or (not info.isdir() if is_dir else not info.isfile()): fail(f'type/mode mismatch: {name}')
   if is_dir: continue
   actual=tar.extractfile(info).read()
   if actual!=data or sha(actual)!=sha(data): fail(f'payload mismatch: {name}')
   now,now_mode=read_file(source)
   if now!=data or now_mode!=mode: fail(f'source changed after snapshot: {source}')
  if tar.extractfile(by['ARCHIVE_INVENTORY.json']).read()!=blob: fail('inventory bytes differ after reopen')

def pack(out):
 out=no_symlink(out.absolute()); sidecar=out.with_suffix(out.suffix+'.inventory.json')
 if out.exists() or sidecar.exists(): fail('archive or sidecar already exists')
 if out.is_relative_to(HERE): fail('output cannot be under preparation directory')
 inventory,entries=collect(); out.parent.mkdir(parents=True,exist_ok=True)
 blob=(json.dumps(inventory,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
 with out.open('xb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as gz:
   with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
    for name,(source,data,mode,is_dir) in sorted(entries.items()):
     info=tarfile.TarInfo(name); info.mode=mode; info.mtime=0; info.uid=info.gid=0; info.uname=info.gname=''
     if is_dir: info.type=tarfile.DIRTYPE; info.size=0; tar.addfile(info)
     else: info.size=len(data); tar.addfile(info,io.BytesIO(data))
    info=tarfile.TarInfo('ARCHIVE_INVENTORY.json'); info.size=len(blob); info.mode=0o644; info.mtime=0; info.uid=info.gid=0; info.uname=info.gname=''; tar.addfile(info,io.BytesIO(blob))
 verify(out,inventory,entries,blob)
 with sidecar.open('xb') as f: f.write(blob)
 return {'status':'prepared-and-reopened','archive':str(out),'archive_sha256':sha(out.read_bytes()),'inventory':str(sidecar),'payload_member_count':len(entries)}

def main():
 ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args()
 print(json.dumps(pack(a.out),indent=2))
if __name__=='__main__': main()
