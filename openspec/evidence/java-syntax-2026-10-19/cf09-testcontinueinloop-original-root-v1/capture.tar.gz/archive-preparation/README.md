# TestContinueInLoop baseline evidence archive preparation

This private preparation reuses the deterministic tar/gzip and byte/mode reopen pattern from the accepted TestBreakWithLabel baseline packer. It does not run any evidence tools and does not create an archive unless a reviewer later invokes `pack.py` with an explicit output path.

The required source trees are explicit in `pack.py`: four Continue preparation snapshots, the complete original baseline, its independent review and prep review, the Continue case plan/review, and the BreakInDoLoop and SequentialLoops case-plan/review pairs. Missing roots, symlinks, non-regular entries, changed files, and unexpected or missing members fail closed. Empty directories are archive members. Failed captures and negative class directories remain part of the complete source trees.

Before collecting, the script checks the accepted root marker pin and its receipt binding. The raw receipt SHA-256 is `d33084ce268c7d3c49a056f120619d7e1786b5f438d5bcf8b30d66911ea2c0ec`; the marker SHA-256 is `3c53bac442e35918b04f30da789c26e06dfb3a2ab3f7d65ef24905f7214d62c1`. The marker status is `root_accepted_original_baseline_with_explicit_whole_method_refusal_gap`. The raw receipt retains its `captured-pending-independent-review` status; the separate accepted marker records the later review decision. The archive makes no claim that all methods recovered or that the CF09 math plans were executed.

Only the fixture's exact `JADX-LICENSE` and `JADX-NOTICE` are included. JDK, CLI, and external dependency payloads are not copied; their source receipts retain their pins. RAUNG licensing is unrelated to this source capture and is omitted.

A future invocation must choose a new output outside all inputs, for example:

```sh
python3 -B /private/tmp/jarde-testcontinueinloop-evidence-archive-prep-luna-v1-20261019/pack.py \
  --out /private/tmp/choose-a-new-output/capture.tar.gz
```

The script refuses an existing archive or inventory sidecar. It writes deterministic tar/gzip, reopens every payload, compares bytes and modes, checks the complete member set, and verifies the inventory before writing the sidecar. This README describes a prepared tool only; no archive has been produced or verified.

## Pins

- Accepted TestBreakWithLabel packer template: `/private/tmp/jarde-testbreakwithlabel-evidence-archive-prep-luna-v1-20261019/pack.py`, SHA-256 `27e05e69aea16590ce0daab26e37ec8e082c903c346280e2f3f5fc3ee7f5d52a`.
- Continue accepted raw receipt and marker hashes are pinned in `pins.json` and enforced by `pack.py`.
- `pins.json` lists every required source-tree file and directory, including bytes, SHA-256, and mode for regular files. The script compares this frozen inventory before archive creation.
- Exact JADX license file hashes and modes are recorded in `pins.json`.
