# CF09 TestContinueInLoop finite case plan

This is a private, read-only case plan for the fixed upstream `TestContinueInLoop.java` source. It adds no source, fixtures, OpenSpec, or runtime evidence. The exact upstream source and the archived fixed-audit receipts are pinned in `pins.json`.

The eight small cases in `caseplan.json` cover both comparison updates, equality continues, two consecutive continue/update cycles, a later `i < b` break after a continue, no-break traversal for negative `b`, empty and null arrays, a nonzero public field, and Java `int` wrap on `f++`. The longest correct source path is three body iterations and four loop-condition evaluations. Each trace records the initial and final array, `f`, exception class, and target stdout. The target itself prints nothing; a parentless driver should report its observations separately.

The critical case is `continue-update-then-later-break`: equality at index 0 must skip the later break check but still execute the `for` update; index 1 then changes and breaks, leaving index 2 untouched. If a regression skips the update on `continue`, a driver timeout may detect the faulty implementation. The original method's termination is established by its source path and bounded array length, not by the timeout.

These are hand-checkable expected traces, not JVM runs or a claim that current Jarde output has a defect.
