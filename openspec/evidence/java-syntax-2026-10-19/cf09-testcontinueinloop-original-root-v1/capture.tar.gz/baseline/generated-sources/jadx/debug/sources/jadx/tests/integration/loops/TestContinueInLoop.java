package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestContinueInLoop.class */
public class TestContinueInLoop extends IntegrationTest {

    /* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestContinueInLoop$TestCls.class */
    public static class TestCls {
        public int f;

        public void test(int[] a, int b) {
            for (int i = 0; i < a.length; i++) {
                int v = a[i];
                if (v < b) {
                    int i2 = i;
                    a[i2] = a[i2] + 1;
                } else {
                    if (v > b) {
                        int i3 = i;
                        a[i3] = a[i3] - 1;
                    } else {
                        continue;
                    }
                }
                if (i < b) {
                    break;
                }
            }
            this.f++;
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("for (int i = 0; i < a.length; i++) {").containsOne("if (i < b) {").containsOne("continue;").containsOne("break;").containsOne("this.f++;");
    }
}
