// jarde: presentation of `jadx/tests/integration/loops/TestContinueInLoop$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestContinueInLoop$TestCls extends java.lang.Object {
    public int f;

    public TestContinueInLoop$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestContinueInLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public void test(int[] arg1, int arg2) {
        // jarde: not recovered: the recovery run for `test([II)V` produced no statement (explanation only); the artifact's own comment lines are below
        // @method test([II)V
        // @declaration an instance method of `jadx.tests.integration.loops.TestContinueInLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 2 8 19 29 35 42 47 50 56
        // the quoted block at BCI 56 ends in a control-flow exit at BCI 66 (a return, a throw, or a transfer whose destination the presented structure does not own), the presented structure reaches that quote, and the body without it would still compile and silently change what the method does; the whole method is quoted
        jarde_refused_body();
    }
}
