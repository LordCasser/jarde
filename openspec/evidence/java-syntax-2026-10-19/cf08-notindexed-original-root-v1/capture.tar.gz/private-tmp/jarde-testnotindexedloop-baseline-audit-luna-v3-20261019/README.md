# TestNotIndexedLoop baseline receipt audit

Private read-only independent audit of the completed 20-command baseline receipt. The verifier preserves the CF07 paired auditor's source closure, external/local artifact re-open, target absence, full original class tree and two-parser Code/BCI inventory, complete Jarde API/default-all comparisons, complete JADX output-tree checks, four JVM rows, empty-cwd and driver-only parentless CodeSource controls.

The target inventory is the actual three-method child (`<init>`, `test(File[])`, and `check()`), plus the outer class. Each API method is classified from the raw report; the verifier checks report/summary agreement and audits mappings, but does not impose structured recovery on `check()` or any other method. The actual JUnit `test()`/`testNoDebug()` assertions and `check()` are preserved source only; the bounded driver invokes only `test(File[])`.

Manual oracle: five rows are null array → null, empty array → null, `[a,f]` → `f`, `[a]` → `h`, and a null element → `NullPointerException`; all target stdout is empty. Every invocation runs with a fresh empty cwd and verifies it remains empty. No real `f` or `h` files are created.

The script reads the terminal receipt and pinned artifacts only. It does not invoke a compiler, CLI, or network command.


Version 3 additionally binds the actual and expected runtime roots separately, binds the driver's cwd to the wrapper cwd, checks the Java executable against its declared JDK leg, compares complete outer-class facts, and reports unique pinned paths separately from pin records reopened. The independent audit was run against the terminal receipt; summary is in review/review.json.
