import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.Base64;

/** Bounded parentless observations of TestNotIndexedLoop$TestCls.test(File[]). */
public final class TestNotIndexedLoopDriver {
    private static final String TARGET = "jadx.tests.integration.loops.TestNotIndexedLoop$TestCls";
    private static final String[] NAMES = {"null-array", "empty-array", "find-f-after-prefix", "miss-sentinel-h", "null-element"};
    private static File[][] inputs() {
        return new File[][] {null, new File[0], new File[] {new File("a"), new File("f")},
                new File[] {new File("a")}, new File[] {null}};
    }
    private static String codeSource(Class<?> c) throws Exception {
        CodeSource s=c.getProtectionDomain().getCodeSource();
        if (s==null || s.getLocation()==null) throw new IllegalStateException("target has no CodeSource");
        return Paths.get(s.getLocation().toURI()).toRealPath().toString();
    }
    private static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static String describe(File[] a) {
        if (a==null) return "<null-array>"; StringBuilder b=new StringBuilder("[");
        for (int i=0;i<a.length;i++) { if (i>0) b.append(','); b.append(a[i]==null?"<null>":b64(a[i].getPath())); }
        return b.append(']').toString();
    }
    private static void requireEmptyCwd(String expected) throws Exception {
        String actual=Paths.get(".").toRealPath().toString();
        if (!actual.equals(expected)) throw new IllegalStateException("unexpected JVM cwd: expected="+expected+" actual="+actual);
        String[] entries=new File(".").list();
        if (entries==null || entries.length!=0) throw new IllegalStateException("JVM cwd is not empty");
    }
    private static void observe(Method m,Object receiver,int i,File[] input,String cwd,PrintStream resultOut) throws Exception {
        requireEmptyCwd(cwd); PrintStream old=System.out; ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        PrintStream targetOut=new PrintStream(bytes,true,"UTF-8"); Object value=null; Throwable cause=null; String stack="";
        try { System.setOut(targetOut); try { value=m.invoke(receiver,(Object)input); }
            catch (InvocationTargetException e) { cause=e.getCause(); StringWriter w=new StringWriter();
                cause.printStackTrace(new PrintWriter(w)); stack=w.toString(); }
        } finally { targetOut.flush(); System.setOut(old); targetOut.close(); }
        requireEmptyCwd(cwd); String type=cause==null?"none":cause.getClass().getName();
        String message=cause==null||cause.getMessage()==null?"":cause.getMessage();
        String result=cause==null&&value!=null?((File)value).getPath():"";
        resultOut.println("CASE index="+i+" name="+NAMES[i]+" input_b64="+b64(describe(input))
          +" result_b64="+b64(result)+" exception="+type+" exception_message_b64="+b64(message)
          +" exception_stack_b64="+b64(stack)+" target_stdout_b64="+b64(new String(bytes.toByteArray(),StandardCharsets.UTF_8)));
    }
    public static void main(String[] args) throws Exception {
        if (args.length!=3) throw new IllegalArgumentException("usage: TestNotIndexedLoopDriver actualRoot expectedRoot emptyWorkingDirectory");
        String actual=Paths.get(args[0]).toRealPath().toString(), expected=Paths.get(args[1]).toRealPath().toString();
        String cwd=Paths.get(args[2]).toRealPath().toString(); requireEmptyCwd(cwd);
        try (URLClassLoader loader=new URLClassLoader(new URL[]{Paths.get(actual).toRealPath().toUri().toURL()},null)) {
            Class<?> target=Class.forName(TARGET,true,loader);
            if (target.getClassLoader()!=loader) throw new IllegalStateException("target did not load from parentless loader");
            String origin=codeSource(target);
            if (!origin.equals(expected)) throw new IllegalStateException("wrong CodeSource: expected="+expected+" actual="+origin);
            Constructor<?> ctor=target.getDeclaredConstructor(); Object receiver=ctor.newInstance();
            Method test=target.getDeclaredMethod("test",File[].class);
            if (Modifier.isStatic(test.getModifiers())) throw new IllegalStateException("test(File[]) unexpectedly static");
            File[][] cases=inputs(); PrintStream resultOut=System.out;
            for (int i=0;i<cases.length;i++) observe(test,receiver,i,cases[i],cwd,resultOut);
            requireEmptyCwd(cwd);
        }
    }
}
