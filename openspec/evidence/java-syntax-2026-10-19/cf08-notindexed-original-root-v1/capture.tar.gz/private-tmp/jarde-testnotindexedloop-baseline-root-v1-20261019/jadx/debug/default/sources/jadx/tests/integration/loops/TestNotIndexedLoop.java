package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import java.io.File;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestNotIndexedLoop.class */
public class TestNotIndexedLoop extends IntegrationTest {

    /* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestNotIndexedLoop$TestCls.class */
    public static class TestCls {
        public File test(File[] files) {
            File file;
            int length;
            if (files == null || (length = files.length) == 0) {
                file = null;
            } else {
                int i = 0;
                while (true) {
                    if (i >= length) {
                        file = new File("h");
                        break;
                    }
                    file = files[i];
                    if (file.getName().equals("f")) {
                        break;
                    }
                    i++;
                }
            }
            if (file != null) {
                file.deleteOnExit();
            }
            return file;
        }

        public void check() {
            JadxAssertions.assertThat(test(null)).isNull();
            JadxAssertions.assertThat(test(new File[0])).isNull();
            File file = new File("f");
            JadxAssertions.assertThat(test(new File[]{new File("a"), file})).isEqualTo(file);
            JadxAssertions.assertThat(test(new File[]{new File("a")}).getName()).isEqualTo("h");
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().doesNotContain(new CharSequence[]{"for ("}).containsOne("while (true) {");
    }

    @Test
    public void testNoDebug() {
        noDebugInfo();
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().doesNotContain(new CharSequence[]{"for ("}).containsOne("while (true) {");
    }
}
