// jarde: presentation of `jadx/tests/integration/loops/TestNotIndexedLoop$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestNotIndexedLoop$TestCls extends java.lang.Object {
    public TestNotIndexedLoop$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestNotIndexedLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public java.io.File test(java.io.File[] files) {
        // @method test([Ljava/io/File;)Ljava/io/File;
        // @declaration an instance method of `jadx.tests.integration.loops.TestNotIndexedLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        java.io.File file;
        if (files != null) {
            int length = files.length;
            if (length == 0) {
                file = null;
            } else {
                int i;
                i = 0;
                while (true) {
                    if (i >= length) {
                        file = new java.io.File("h");
                        break;
                    } else {
                        file = files[i];
                        if (file.getName().equals((java.lang.Object) "f")) {
                            break;
                        } else {
                            i = i + 1;
                        }
                    }
                }
            }
        } else {
            file = null;
        }
        if (file != null) {
            file.deleteOnExit();
        }
        return file;
    }

    public void check() {
        // @method check()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestNotIndexedLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat((java.io.File) this.test((java.io.File[]) null)).isNull();
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat((java.io.File) this.test(new java.io.File[0])).isNull();
        java.io.File file = new java.io.File("f");
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat((java.io.File) this.test(new java.io.File[]{new java.io.File("a"), file})).isEqualTo((java.lang.Object) file);
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat((java.lang.String) this.test(new java.io.File[]{new java.io.File("a")}).getName()).isEqualTo("h");
        return;
    }
}
