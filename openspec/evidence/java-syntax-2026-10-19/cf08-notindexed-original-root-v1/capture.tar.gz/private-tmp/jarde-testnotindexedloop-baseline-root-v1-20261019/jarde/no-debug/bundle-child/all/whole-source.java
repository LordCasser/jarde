// jarde: presentation of `jadx/tests/integration/loops/TestNotIndexedLoop$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestNotIndexedLoop$TestCls extends java.lang.Object {
    public TestNotIndexedLoop$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestNotIndexedLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public java.io.File test(java.io.File[] arg1) {
        // @method test([Ljava/io/File;)Ljava/io/File;
        // @declaration an instance method of `jadx.tests.integration.loops.TestNotIndexedLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        java.io.File local2;
        if (arg1 != null) {
            int local3 = arg1.length;
            if (local3 == 0) {
                local2 = null;
            } else {
                int local4;
                local4 = 0;
                while (true) {
                    if (local4 >= local3) {
                        local2 = new java.io.File("h");
                        break;
                    } else {
                        local2 = arg1[local4];
                        if (local2.getName().equals((java.lang.Object) "f")) {
                            break;
                        } else {
                            local4 = local4 + 1;
                        }
                    }
                }
            }
        } else {
            local2 = null;
        }
        if (local2 != null) {
            local2.deleteOnExit();
        }
        return local2;
    }

    public void check() {
        // @method check()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestNotIndexedLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat((java.io.File) this.test((java.io.File[]) null)).isNull();
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat((java.io.File) this.test(new java.io.File[0])).isNull();
        java.io.File local1 = new java.io.File("f");
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat((java.io.File) this.test(new java.io.File[]{new java.io.File("a"), local1})).isEqualTo((java.lang.Object) local1);
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat((java.lang.String) this.test(new java.io.File[]{new java.io.File("a")}).getName()).isEqualTo("h");
        return;
    }
}
