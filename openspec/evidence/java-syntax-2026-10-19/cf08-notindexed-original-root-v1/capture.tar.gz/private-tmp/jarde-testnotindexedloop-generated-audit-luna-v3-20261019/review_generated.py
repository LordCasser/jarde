#!/usr/bin/env python3
"""Read-only independent review of the completed TestNotIndexedLoop generated-source matrix."""
import argparse, hashlib, importlib.util, json, re, zipfile
from pathlib import Path

BASELINE = Path('/private/tmp/jarde-testnotindexedloop-baseline-root-v1-20261019/execution.json')
BASELINE_SHA = '56276e1841a38d4929826cfb52440ef8ef88d07efae07149a06a6626ae10c967'
BASELINE_SCHEMA = 'test-not-indexed-loop-full-source-baseline-v1'
GENERATED_SCHEMA = 'test-not-indexed-loop-generated-source-matrix-v1'
GENERATED = Path('/private/tmp/jarde-testnotindexedloop-generated-root-v1-20261019/execution.json')
GENERATED_SHA = '8e57bf803579a692df08388e168f336fa44cb072620fbc81f1daa517e2253b4c'
CURRENT_CLI_SHA = '96e534b0000fe91c1d34a282919479a97eb4706063501d188cdff010c4640366'
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
INTERNAL = 'jadx/tests/integration/loops/TestNotIndexedLoop$TestCls'
OUTER = 'jadx/tests/integration/loops/TestNotIndexedLoop'
DRIVER = 'TestNotIndexedLoopDriver'
HELPERS = Path('/private/tmp/jarde-assignment-condition-widening-final-compare-prep-luna-v9-20261019/review_final_api.py')
HELPERS_SHA = 'ad6df2bc49a55d7542182f668276bd23a9f5bb832852523faad0a7fffae6d2cb'
COMPARE = ROOT / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
PHYSICAL = Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
JDK_MANIFEST = ROOT / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
PROFILES = ('debug', 'no-debug')
EVIDENCE = ('default', 'all')
FORMS = ('child', 'bundle-child')
LEGS = ('javac8', 'javac23')
RUNTIMES = ('javac8', 'javac23')
CASES = ('null-array', 'empty-array', 'find-f-after-prefix', 'miss-sentinel-h', 'null-element')
METHODS = {('<init>', '()V'), ('test', '([Ljava/io/File;)Ljava/io/File;'), ('check', '()V')}
OUTER_METHODS = {('<init>', '()V'), ('test', '()V'), ('testNoDebug', '()V')}
EXPECTED = [
    ('<null-array>', '', 'none', ''), ('[]', '', 'none', ''),
    ('[YQ==,Zg==]', 'f', 'none', ''), ('[YQ==]', 'h', 'none', ''),
    ('[<null>]', '', 'java.lang.NullPointerException', ''),
]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def require(ok, message):
    if not ok:
        raise AssertionError(message)

def pin(row, label):
    if not isinstance(row, dict) or not {'path', 'bytes', 'sha256'} <= row.keys():
        raise AssertionError(f'{label}: malformed pin')
    path = Path(row['path']).resolve(strict=True)
    data = path.read_bytes()
    require(len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], f'{label}: pin mismatch')
    return path

def all_pins(value, label='receipt'):
    count = 0
    unique = set()
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            p = pin(value, label); unique.add(str(p)); return 1, unique
        for key, child in value.items():
            n, paths = all_pins(child, f'{label}.{key}'); count += n; unique |= paths
    elif isinstance(value, list):
        for i, child in enumerate(value):
            n, paths = all_pins(child, f'{label}[{i}]'); count += n; unique |= paths
    return count, unique

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot import {path}')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def norm(value):
    if isinstance(value, dict): return {k: norm(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [norm(v) for v in value]
    return value

def parse_rows(raw):
    import base64
    lines = raw.decode('utf-8', errors='strict').splitlines()
    if len(lines) != len(CASES): raise AssertionError(f'expected five runtime rows, got {len(lines)}')
    rx = re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) target_stdout_b64=([^ ]*)$')
    dec = lambda s: base64.b64decode(s, validate=True).decode('utf-8', errors='strict')
    rows = []
    for i, line in enumerate(lines):
        m = rx.fullmatch(line)
        if m is None: raise AssertionError(f'malformed runtime line: {line!r}')
        idx, name, inp, result, exc, msg, stack, target_stdout = m.groups()
        require(int(idx) == i and name == CASES[i], f'case identity/order mismatch: {line!r}')
        rows.append({'index': i, 'name': name, 'input': dec(inp), 'result': dec(result), 'exception_type': exc,
                     'exception_message': dec(msg), 'exception_stack': dec(stack), 'target_stdout': dec(target_stdout), 'raw': line})
    return rows

def parsed_class(compare, physical, path, label):
    facts = compare.parse_class(path)
    raw = physical.parse_class_file(path.read_bytes())
    require(facts['class_name'] == raw['class_name'] and facts['major'] == raw['major'] and facts['methods'] == raw['methods'], f'{label}: parser method/Code disagreement')
    require(sorted((x['name'], x['descriptor'], x['access']) for x in raw['fields']) == sorted(facts['fields']), f'{label}: parser field disagreement')
    facts['access'] = raw['access']
    return facts, raw

def tree_pins(root):
    root = Path(root).resolve(strict=True)
    return {p.relative_to(root).as_posix(): {'path': str(p.resolve()), 'bytes': p.stat().st_size, 'sha256': sha(p)}
            for p in sorted(root.rglob('*.class'))}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--generated', type=Path, default=GENERATED)
    ap.add_argument('--baseline', type=Path, default=BASELINE)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    generated_path, baseline_path, out = args.generated.resolve(strict=True), args.baseline.resolve(strict=True), args.out.resolve()
    if out.exists(): raise SystemExit(f'refusing existing output: {out}')
    require(generated_path == GENERATED.resolve() and sha(generated_path) == GENERATED_SHA, 'generated receipt path/SHA mismatch')
    require(baseline_path == BASELINE.resolve() and sha(baseline_path) == BASELINE_SHA, 'baseline receipt path/SHA mismatch')
    require(sha(HELPERS) == HELPERS_SHA, 'accepted v9 helper source changed')
    require(sha(JDK_MANIFEST) == JDK_SHA, 'JDK manifest changed')
    helper = load(HELPERS, 'accepted_final_v9_helpers')
    compare = load(COMPARE, 'notindexed_generated_compare')
    physical = load(PHYSICAL, 'notindexed_generated_physical')
    jdks, _ = compare.configured_jdks(JDK_MANIFEST, JDK_SHA)
    baseline = json.loads(baseline_path.read_text(encoding='utf-8'))
    data = json.loads(generated_path.read_text(encoding='utf-8'))
    baseline_pin_records, baseline_unique_pins = all_pins(baseline)
    generated_pin_records, generated_unique_pins = all_pins(data)
    require(baseline.get('schema') == BASELINE_SCHEMA and baseline.get('status') == 'captured-pending-independent-review', 'baseline receipt schema/status mismatch')
    require(data.get('schema') == GENERATED_SCHEMA and data.get('status') == 'captured-pending-independent-review', 'generated receipt is not a completed capture')
    require(data.get('baseline_sha256_argument') == BASELINE_SHA and pin(data.get('baseline_receipt'), 'baseline receipt') == baseline_path, 'generated capture is not bound to frozen baseline')
    require(data.get('root') == str(ROOT) and Path(data['root']).resolve() == ROOT.resolve(), 'workspace root mismatch')
    cli = pin(baseline['cli'], 'baseline CLI')
    require(sha(cli) == CURRENT_CLI_SHA, 'candidate CLI pin differs from frozen source producer')
    boundary = baseline.get('javac8_full_source_boundary', {})
    require(boundary.get('major_55_diagnostic_observed') is True and boundary.get('exit_code') != 0, 'baseline JDK8 full-source boundary did not record major 55')
    pin(boundary.get('stderr'), 'baseline JDK8 boundary stderr')
    require(b'55.0' in Path(boundary['stderr']['path']).read_bytes() and b'52.0' in Path(boundary['stderr']['path']).read_bytes(), 'baseline JDK8 boundary is not 55-vs-52')

    # Reopen source, tool, output, command, and local-copy pins; preserve each guard snapshot.
    for flag in ('source_unchanged', 'source_unchanged_finally', 'external_inputs_unchanged', 'generated_outputs_unchanged',
                 'generated_outputs_unchanged_finally', 'local_copies_unchanged', 'target_absent', 'target_absent_finally'):
        require(data.get(flag) is True, f'capture guard is false: {flag}')
    for field in ('source_pins_before', 'source_pins_after', 'source_pins_after_finally'):
        require(field in data, f'missing source closure snapshot {field}')
        helper.recursive_pin_check(data[field], field)
    require(data['source_pins_before'] == data['source_pins_after'] == data['source_pins_after_finally'], 'live source closure changed')
    for field in ('external_pins_before', 'external_pins_after', 'external_pins_after_finally',
                  'dependency_directory_pins_before', 'dependency_directory_pins_after', 'dependency_directory_pins_after_finally',
                  'generated_output_pins_before', 'generated_output_pins_after', 'generated_output_pins_after_finally',
                  'local_copies_before', 'local_copies_after', 'local_copies_after_finally'):
        require(field in data, f'missing snapshot {field}')
        helper.recursive_pin_check(data[field], field)
    require(data['external_pins_before'] == data['external_pins_after'] == data['external_pins_after_finally'], 'external pins changed')
    require(data['dependency_directory_pins_before'] == data['dependency_directory_pins_after'] == data['dependency_directory_pins_after_finally'], 'dependency directory pins changed')
    require(data['generated_output_pins_before'] == data['generated_output_pins_after'] == data['generated_output_pins_after_finally'], 'generated output trees changed')
    require(data['local_copies_before'] == data['local_copies_after'] == data['local_copies_after_finally'], 'local copies changed')

    commands = data.get('commands'); require(isinstance(commands, list) and len(commands) == 51, 'command ledger must have 51 commands')
    cmdmap = {r.get('index'): r for r in commands}
    require(len(cmdmap) == 51 and set(cmdmap) == set(range(1, 52)), 'command indices are incomplete/duplicated')
    for row in commands:
        require(row.get('guard_stop') is None and row.get('argv'), f'command guard/argv invalid: {row.get("label")}')
        require(isinstance(row.get('peak_target_bytes'), int) and row['peak_target_bytes'] <= 1024**3, f'target-size guard invalid: {row.get("label")}')
        require(isinstance(row.get('free_bytes_after'), int) and row['free_bytes_after'] >= 5*1024**3, f'5 GiB guard invalid: {row.get("label")}')
        for name in ('stdout', 'stderr'): pin(row['streams'][name], f'{row["label"]} {name}')
    tool_docs = data.get('jdk_manifest', {}).get('tools')
    require(isinstance(tool_docs, dict) and set(tool_docs) == set(LEGS), 'pinned JDK legs missing')
    for leg in LEGS:
        for tool in ('javac', 'java'):
            tool_path = pin(tool_docs[leg][tool], f'{leg} {tool}')
            require(tool_path == Path(jdks[leg]['tools'][tool]).resolve(), f'{leg} {tool}: pinned manifest path mismatch')
    require(data['jdk_manifest']['sha256'] == JDK_SHA and Path(data['jdk_manifest']['path']).resolve() == JDK_MANIFEST.resolve()
            and sha(JDK_MANIFEST) == JDK_SHA, 'recorded JDK manifest mismatch')

    # Reconstruct complete ten-cell source matrix from the independently audited baseline.
    baseline_api = {(x['profile'], x['input_form'], x['evidence']): x for x in baseline['jarde_cells']}
    require(len(baseline_api) == 8, 'baseline API grid malformed')
    baseline_jadx = {x['compiler_profile']: x for x in baseline['jadx_outputs']}
    require(set(baseline_jadx) == set(PROFILES), 'baseline JADX profile grid malformed')
    source_cells = data.get('source_cells', [])
    require(len(source_cells) == 10 and all(c.get('source_available') is True for c in source_cells), 'generated source-cell grid incomplete')
    source_by_key = {}
    for c in source_cells:
        key = tuple(c['cell_key'])
        require(key not in source_by_key, f'duplicate source cell {key}')
        source_by_key[key] = c
        if c['kind'] == 'jarde':
            require(key == (c['profile'], c['form'], c['evidence']) and c['form'] in FORMS and c['evidence'] in EVIDENCE, 'Jarde source cell identity malformed')
            old = baseline_api.get(key); require(old is not None and c['source_available'], f'Jarde source cell has no baseline producer {key}')
            old_source = pin(old['whole_source'], f'{key} baseline whole source')
            copies = c['source_copies']; require(len(copies) == 1, f'{key}: expected one complete Jarde source copy')
            src, dst = pin(copies[0]['source'], f'{key} Jarde producer source'), pin(copies[0]['copy'], f'{key} Jarde compile copy')
            require(src == old_source and src.read_bytes() == old_source.read_bytes() == dst.read_bytes(), f'{key}: Jarde source is not the exact baseline API source')
            require(dst.name == 'TestNotIndexedLoop$TestCls.java' and 'void check()' in dst.read_text(encoding='utf-8'), f'{key}: copied class source lost embedded check()')
            require(c['cell_key'] == list(key), f'{key}: source-copy receipt malformed')
        elif c['kind'] == 'jadx':
            require(key == (c['profile'], 'bundle') and c['form'] == 'bundle' and c['evidence'] == 'source', 'JADX source cell identity malformed')
            old = baseline_jadx.get(c['profile']); require(old is not None, f'{key}: baseline JADX producer absent')
            old_sources = {str(Path(pin(x, 'baseline JADX source')).resolve()): x for x in old['sources']}
            copies = c['source_copies']; copied_sources = {str(Path(pin(x['source'], 'JADX source')).resolve()): x['source'] for x in copies}
            require(copied_sources == old_sources and len(copies) == len(old_sources), f'{key}: incomplete/different full JADX source closure')
            for pair in copies:
                src, dst = pin(pair['source'], f'{key} JADX source'), pin(pair['copy'], f'{key} JADX copy')
                require(src.read_bytes() == dst.read_bytes() and src.suffix == '.java' and dst.suffix == '.java', f'{key}: JADX source copy bytes/path invalid')
                require('void check()' in dst.read_text(encoding='utf-8'), f'{key}: JADX copy lost check()')
        else:
            raise AssertionError(f'unknown source producer kind: {c.get("kind")}')
    expected_source_keys = {(p, f, e) for p in PROFILES for f in FORMS for e in EVIDENCE} | {(p, 'bundle') for p in PROFILES}
    require(set(source_by_key) == expected_source_keys, 'ten-cell generated source selector grid incomplete')

    # The full compile grid is 10 source cells × 2 compiler legs. Record JDK8 failures only as the proven harness-major boundary.
    compiles = data.get('compilations', []); require(len(compiles) == 20, 'compile grid must contain all 20 attempts')
    compile_map = {}
    for rec in compiles:
        key = (tuple(rec.get('cell_key', [])), rec.get('leg'))
        require(key not in compile_map and key[0] in source_by_key and key[1] in LEGS, f'duplicate/unknown compile cell {key}')
        compile_map[key] = rec
    require(set(compile_map) == {(k, leg) for k in expected_source_keys for leg in LEGS}, 'source/compiler grid incomplete')
    baseline_profiles = {x['profile']: x for x in baseline['source_profiles']}
    dependency_jar = pin(baseline['dependency_harness_jar'], 'pinned test harness jar')
    require(dependency_jar.suffix == '.jar', 'baseline harness artifact is not a jar')
    with zipfile.ZipFile(dependency_jar) as zf:
        for binary in ('jadx/tests/api/IntegrationTest.class', 'jadx/tests/api/utils/assertj/JadxAssertions.class'):
            raw = zf.read(binary)
            facts = physical.parse_class_file(raw)
            require(facts['major'] == 55, f'pinned harness class {binary} is not major 55')
    compile_successes = 0; compile_failures = 0; success_cells = set(); failure_cells = set()
    expected_class_names = {INTERNAL + '.class', OUTER + '.class'}
    for key, rec in compile_map.items():
        source_key, leg = key; source = source_by_key[source_key]; basekey = '-'.join(source_key)
        cmd = cmdmap[rec['command']]
        require(cmd['label'] == f'compile-{basekey}-{leg}' and cmd['exit_code'] == rec['exit_code'], f'{key}: compiler row/command linkage mismatch')
        require(rec.get('leg') == leg and pin(rec['stdout'], f'{key} compile stdout').read_bytes() == pin(cmd['streams']['stdout'], f'{key} command stdout').read_bytes()
                and pin(rec['stderr'], f'{key} compile stderr').read_bytes() == pin(cmd['streams']['stderr'], f'{key} command stderr').read_bytes(), f'{key}: compiler raw stream mismatch')
        argv = cmd['argv']; java_leg = jdks[leg]['tools']['javac']
        require(cmd.get('tool_leg') == leg and Path(argv[0]).resolve() == Path(java_leg).resolve(), f'{key}: javac executable/leg does not match pin')
        require('-d' in argv and Path(argv[argv.index('-d') + 1]).resolve() == Path(rec['class_root']).resolve(), f'{key}: compiler destination mismatch')
        copied = source['source_copies']
        argv_sources = sorted(str(Path(x).resolve()) for x in argv if str(x).endswith('.java'))
        expected_sources = sorted(str(Path(x['copy']['path']).resolve()) for x in copied)
        require(argv_sources == expected_sources and rec['source_copies'] == copied, f'{key}: compiler did not consume exact full copied source set')
        require('-proc:none' in argv and '-sourcepath' in argv and Path(argv[argv.index('-sourcepath')+1]).resolve() == Path(data['output']).resolve() / 'empty-classpath'
                and '-classpath' in argv and argv[argv.index('-classpath')+1] == __import__('os').pathsep.join(baseline['dependency_classpath'])
                and '-encoding' in argv and argv[argv.index('-encoding')+1] == 'UTF-8', f'{key}: compiler classpath/sourcepath/safety/encoding options differ')
        debug = '-g' if source['profile'] == 'debug' else '-g:none'
        require(debug in argv, f'{key}: debug profile option mismatch')
        if leg == 'javac8':
            require(any(argv[i:i+2] == ['-source', '8'] for i in range(len(argv)-1)) and any(argv[i:i+2] == ['-target', '8'] for i in range(len(argv)-1)), f'{key}: javac8 source/target options missing')
        else:
            require(any(argv[i:i+2] == ['--release', '8'] for i in range(len(argv)-1)), f'{key}: javac23 release option missing')
        tree = rec.get('class_tree')
        if rec['exit_code'] == 0:
            compile_successes += 1; success_cells.add(key)
            require(rec.get('failure_classification') is None and rec.get('runtime_eligible') is True and rec.get('class_facts_error') is None and rec.get('target_facts_error') is None, f'{key}: successful compile has missing/invalid physical facts')
            expected = {INTERNAL + '.class'} if source['kind'] == 'jarde' else expected_class_names
            require(set(tree) == expected, f'{key}: generated complete class closure is wrong')
            checked_tree = helper.check_tree(tree, f'{key} generated class tree')
            facts_map = rec.get('class_facts'); require(isinstance(facts_map, dict) and set(facts_map) == expected, f'{key}: full class facts do not cover complete generated tree')
            orig = baseline_profiles[source['profile']]
            expected_facts = {INTERNAL: orig['target_facts'], OUTER: orig['outer_facts']}
            for rel, fact in facts_map.items():
                class_path = pin(fact, f'{key}/{rel} parsed class fact')
                require(class_path == pin(checked_tree[rel], f'{key}/{rel} class tree artifact'), f'{key}/{rel}: facts are not bound to class output')
                parsed, physical_facts = parsed_class(compare, physical, class_path, f'{key}/{rel}')
                require(norm(parsed) == norm(fact), f'{key}/{rel}: saved full physical facts differ from independent parser')
                baseline_class = expected_facts[INTERNAL if rel == INTERNAL + '.class' else OUTER]
                helper.check_fact_inventory(fact, baseline_class, f'{key}/{rel}')
            target = rec.get('target_facts'); require(isinstance(target, dict) and rec.get('target_facts_error') is None, f'{key}: primary target facts absent')
            target_path = pin(target, f'{key} target facts'); require(target_path == pin(checked_tree[INTERNAL + '.class'], f'{key} target class'), f'{key}: target facts/class tree mismatch')
            target_full = {k: v for k, v in facts_map[INTERNAL + '.class'].items() if k != 'access'}
            require(norm(target) == norm(target_full), f'{key}: target summary differs from full target class facts outside class access metadata')
            helper.check_fact_inventory(target, orig['target_facts'], f'{key}/target')
        else:
            compile_failures += 1; failure_cells.add(key)
            require(leg == 'javac8' and rec.get('failure_classification') == 'harness-major-55-boundary', f'{key}: unexpected compiler failure/classification')
            require(rec.get('runtime_eligible') is False and rec.get('class_facts') is None and rec.get('target_facts') is None, f'{key}: failed compile has artifacts/eligibility')
            require(tree == {}, f'{key}: framework-rejected compile unexpectedly emitted class files')
            err = pin(rec['stderr'], f'{key} major-55 stderr').read_bytes()
            require(b'55.0' in err and b'52.0' in err, f'{key}: failure is not an explicit harness-major-55 vs release-8 diagnostic')
            require(b'jadx-test-harness.jar' in err, f'{key}: failure does not identify the pinned test harness')
    require(compile_successes == 10 and compile_failures == 10, 'compile totals differ from the observed 10-success/10-framework-boundary grid')
    jarde_keys = {key for key, cell in source_by_key.items() if cell['kind'] == 'jarde'}
    jadx_keys = {key for key, cell in source_by_key.items() if cell['kind'] == 'jadx'}
    require({key for key in success_cells if key[0] in jarde_keys} == {(k, 'javac23') for k in jarde_keys}, 'all eight Jarde javac23 cells must be the successful Jarde set')
    require({key for key in failure_cells if key[0] in jarde_keys} == {(k, 'javac8') for k in jarde_keys}, 'all eight Jarde javac8 cells must be major-55 failures')
    require({key for key in success_cells if key[0] in jadx_keys} == {(k, 'javac23') for k in jadx_keys}, 'both JADX javac23 cells must be the successful JADX set')
    require({key for key in failure_cells if key[0] in jadx_keys} == {(k, 'javac8') for k in jadx_keys}, 'both JADX javac8 cells must be major-55 failures')

    # Every failed javac8 cell must be the known major-55 harness boundary; JDK23 success cells receive both VMs and one wrong-root control.
    runtime_rows = data.get('runtime_rows', []); wrong_rows = data.get('wrong_root_rows', [])
    require(len(runtime_rows) == 20 and len(wrong_rows) == 10, 'success-only runtime/wrong-root grid counts differ')
    runtime_map = {}; wrong_map = {}
    for row in runtime_rows:
        key = (tuple(row['cell_key']), row['compiler'], row['runtime'])
        require(key not in runtime_map, f'duplicate runtime cell {key}'); runtime_map[key] = row
    for row in wrong_rows:
        key = (tuple(row['cell_key']), row['compiler'])
        require(key not in wrong_map, f'duplicate wrong-root cell {key}'); wrong_map[key] = row
    expected_runtime = {(cell, leg, vm) for cell, leg in success_cells for vm in RUNTIMES}
    expected_wrong = {(cell, leg) for cell, leg in success_cells}
    require(set(runtime_map) == expected_runtime and set(wrong_map) == expected_wrong, 'runtime or wrong-root success-only selectors incomplete')
    baseline_oracles = {}
    for row in baseline['original_runtime']:
        raw_rows = parse_rows(pin(row['stdout'], 'baseline original stdout').read_bytes())
        require(raw_rows == row['rows'], 'baseline original parsed rows differ from raw stdout')
        projection = [{k: r[k] for k in ('index','name','input','result','exception_type','target_stdout')} for r in raw_rows]
        baseline_oracles[f"{row['profile']}/{row['runtime']}"] = projection
    require(data.get('original_oracles') == baseline_oracles, 'generated oracle copies differ from accepted baseline runtime observations')
    case_observations = 0
    wrapper_copy = Path(data['runtime_wrapper']['path']).resolve(strict=True) if data.get('runtime_wrapper') else None
    # For this schema the copied wrapper path is external_pins + local copies; rows carry its actual argv path.
    for key, row in runtime_map.items():
        cell_key, compiler, vm = key; basekey = '-'.join(cell_key); command = cmdmap[row['command']]
        require(row['exit_code'] == command['exit_code'] == 0 and command['label'] == f'runtime-{basekey}-{compiler}-{vm}'
                and command.get('tool_leg') == vm, f'{key}: runtime command linkage/exit/tool leg mismatch')
        require(row.get('matches_original_profile_runtime') is True and row.get('target_root'), f'{key}: runtime did not match saved original oracle')
        argv = command['argv']; driver_compile = data['driver_compile']; driver_command = cmdmap[driver_compile['command']]
        driver_root = Path(driver_command['argv'][driver_command['argv'].index('-d')+1]).resolve()
        require(len(argv) == 13 and argv[1] == '-B' and argv[3] == '30' and Path(argv[5]).resolve() == Path(jdks[vm]['tools']['java']).resolve()
                and argv[6] == '-Xverify:all' and argv[7] == '-cp' and Path(argv[8]).resolve() == driver_root and argv[9] == DRIVER,
                f'{key}: guarded parentless runtime argv mismatch')
        helper.check_runtime_wrapper_identity(data, baseline, False, Path(argv[2]).resolve(), f'{key} runtime wrapper')
        require(Path(argv[4]).resolve() == Path(argv[12]).resolve(), f'{key}: driver cwd differs from wrapper cwd')
        require(Path(argv[10]).resolve() == Path(row['target_root']).resolve() == Path(argv[11]).resolve(), f'{key}: actual/expected CodeSource roots mismatch')
        require(row['application_classpath'] == [str(driver_root)], f'{key}: runtime classpath contains something beyond driver')
        cwd = Path(argv[4]).resolve(strict=True); require(not list(cwd.iterdir()), f'{key}: isolated runtime cwd is not empty after run')
        raw = pin(row['stdout'], f'{key} runtime stdout').read_bytes(); pin(row['stderr'], f'{key} runtime stderr')
        require(raw == pin(command['streams']['stdout'], f'{key} raw command stdout').read_bytes() and pin(row['stderr'], f'{key} raw command stderr').read_bytes() == pin(command['streams']['stderr'], f'{key} command stderr').read_bytes(), f'{key}: runtime raw streams differ from command')
        rows = parse_rows(raw); require(rows == row['rows'], f'{key}: parsed rows differ from raw stdout')
        got = [(r['input'], r['result'], r['exception_type'], r['target_stdout']) for r in rows]
        require([r['name'] for r in rows] == list(CASES) and got == EXPECTED, f'{key}: five-case manual oracle mismatch')
        require(row.get('semantic_projection') == baseline_oracles[f'{cell_key[0]}/{vm}'], f'{key}: runtime projection differs from corresponding original profile/runtime')
        case_observations += len(rows)
    require(case_observations == 100, 'expected 80 Jarde + 20 JADX runtime case observations')
    for key, row in wrong_map.items():
        cell_key, compiler = key; basekey = '-'.join(cell_key); command = cmdmap[row['command']]
        require(row['exit_code'] == command['exit_code'] == 1 and row.get('rejected') is True and command['label'] == f'wrong-root-{basekey}-{compiler}'
                and command.get('tool_leg') == 'javac23', f'{key}: wrong-root outcome/command/tool leg mismatch')
        argv = command['argv']; driver_compile = data['driver_compile']; driver_command = cmdmap[driver_compile['command']]
        driver_root = Path(driver_command['argv'][driver_command['argv'].index('-d')+1]).resolve()
        require(len(argv) == 13 and argv[1] == '-B' and argv[3] == '30' and Path(argv[5]).resolve() == Path(jdks['javac23']['tools']['java']).resolve()
                and argv[6] == '-Xverify:all' and argv[7] == '-cp' and Path(argv[8]).resolve() == driver_root and argv[9] == DRIVER, f'{key}: wrong-root guarded argv mismatch')
        helper.check_runtime_wrapper_identity(data, baseline, False, Path(argv[2]).resolve(), f'{key} wrong-root wrapper')
        require(Path(argv[10]).resolve() == Path(row['actual_target_root']).resolve() and Path(argv[11]).resolve() == Path(row['expected_wrong_root']).resolve()
                and Path(argv[10]).resolve() != Path(argv[11]).resolve(), f'{key}: wrong-root roots not the recorded distinct roots')
        require(Path(argv[4]).resolve() == Path(argv[12]).resolve() and not list(Path(argv[4]).resolve().iterdir()), f'{key}: wrong-root cwd invalid')
        stderr = pin(row['stderr'], f'{key} wrong-root stderr').read_bytes()
        require(b'wrong CodeSource:' in stderr and stderr == pin(command['streams']['stderr'], f'{key} command stderr').read_bytes(), f'{key}: wrong-root rejection diagnostic/raw stream mismatch')
        require(pin(row['stdout'], f'{key} wrong-root stdout').read_bytes() == pin(command['streams']['stdout'], f'{key} command stdout').read_bytes(), f'{key}: wrong-root stdout mismatch')

    # Exact command accounting and immutable producer output closure.
    require(len(commands) == 1 + len(compiles) + len(runtime_rows) + len(wrong_rows), 'unlinked/extra command row')
    require(data['counts_derived'] == {'source_cells':10,'jarde_api_cells':8,'jadx_source_cells':2,'compile_attempts':20,'compile_successes':10,'compile_failures':10,'runtime_attempts':20,'wrong_root_attempts':10,'commands':51,'raw_streams':102}, 'collector-derived totals differ from independently rebuilt grid')
    driver_compile = data.get('driver_compile'); require(isinstance(driver_compile, dict), 'driver compile result missing')
    driver_compile_cmd = cmdmap[driver_compile['command']]
    require(driver_compile_cmd['label'] == 'compile-reflection-driver' and driver_compile_cmd.get('tool_leg') == 'javac8'
            and driver_compile_cmd['exit_code'] == driver_compile['exit_code'] == 0, 'driver compile command/leg failed')
    for channel in ('stdout','stderr'):
        require(pin(driver_compile[channel], f'driver {channel}').read_bytes() == pin(driver_compile_cmd['streams'][channel], f'driver command {channel}').read_bytes(), f'driver {channel} mismatch')
    driver_argv = driver_compile_cmd['argv']
    require(Path(driver_argv[0]).resolve() == Path(jdks['javac8']['tools']['javac']).resolve() and data['driver_copy']['path'] in driver_argv
            and '-source' in driver_argv and driver_argv[driver_argv.index('-source')+1] == '8'
            and '-target' in driver_argv and driver_argv[driver_argv.index('-target')+1] == '8'
            and '-classpath' in driver_argv and Path(driver_argv[driver_argv.index('-classpath')+1]).resolve() == Path(data['output']).resolve() / 'empty-classpath', 'driver compile argv/source/JDK mismatch')
    driver_rows = [pin(x, 'driver class') for x in data['driver_classes']]
    require(len(driver_rows) == 1 and driver_rows[0].name == DRIVER + '.class', 'driver class closure is not the expected single class')
    driver_text = pin(data['driver_source'], 'driver source').read_text(encoding='utf-8')
    require(pin(data['driver_copy'], 'driver copy').read_bytes() == Path(data['driver_source']['path']).read_bytes(), 'driver source copy mismatch')
    for token in ('new URL[]{Paths.get(actual).toRealPath().toUri().toURL()},null', 'target.getClassLoader()!=loader', 'wrong CodeSource:', 'requireEmptyCwd(cwd)'):
        require(token in driver_text, f'driver missing parentless/CodeSource/cwd check {token}')
    require(not (ROOT / 'target').exists() and not (ROOT / 'target').is_symlink(), 'workspace target exists during review')

    result = {'receipt': str(generated_path), 'receipt_sha256': sha(generated_path), 'baseline_sha256': BASELINE_SHA,
              'commands': len(commands), 'raw_streams': 102, 'source_cells': 10, 'full_source_compiles': 20,
              'baseline_pin_records_reopened': baseline_pin_records, 'baseline_unique_pinned_paths': len(baseline_unique_pins),
              'generated_pin_records_reopened': generated_pin_records, 'generated_unique_pinned_paths': len(generated_unique_pins),
              'compile_successes': 10, 'compile_failures': 10, 'confirmed_javac8_harness_major55_failures': 10,
              'jarde_javac23_successes': 8, 'jadx_javac23_successes': 2,
              'generated_runtime_rows': 20, 'generated_wrong_root_rows': 10,
              'jarde_runtime_observations': 80, 'jadx_runtime_observations': 20, 'manual_oracle_matches': True,
              'source_copy_bytes_verified': True, 'physical_class_tree_facts_verified': True,
              'scope': 'generated-source matrix integrity and runtime comparison; no upstream JUnit test assertion was executed'}
    out.mkdir(parents=True, exist_ok=False)
    (out / 'review.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    (out / 'README.md').write_text('Generated matrix reviewer uses pinned collector/helper baselines and raw receipts. The 10 javac8 failures are accepted only when each exact raw stderr reports pinned harness classfile major 55 versus requested 52; they receive no runtime rows. This is a harness compatibility boundary, not evidence of a loop recovery failure. Eight Jarde and two JADX javac23 compilations are independently parsed, then checked against the corresponding saved original profile/JVM observations. No compiler, JVM, CLI, or network process is started by this reviewer.\n', encoding='utf-8')
    return result

if __name__ == '__main__':
    print(json.dumps(main(), indent=2, sort_keys=True))
