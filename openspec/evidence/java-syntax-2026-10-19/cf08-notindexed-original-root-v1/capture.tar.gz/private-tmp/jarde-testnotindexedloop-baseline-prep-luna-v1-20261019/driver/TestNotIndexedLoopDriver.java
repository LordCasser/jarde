import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.Base64;

/** Bounded parentless observations of TestNotIndexedLoop$TestCls.test(File[]). */
public final class TestNotIndexedLoopDriver {
    private static final String TARGET =
            "jadx.tests.integration.loops.TestNotIndexedLoop$TestCls";
    private static final String[] CASE_NAMES = {
        "null-array", "empty-array", "find-f-after-prefix", "miss-sentinel-h", "null-element"
    };

    private static File[][] inputs() {
        return new File[][] {
            null,
            new File[0],
            new File[] { new File("a"), new File("f") },
            new File[] { new File("a") },
            new File[] { null }
        };
    }

    private static String codeSource(Class<?> target) throws Exception {
        CodeSource source = target.getProtectionDomain().getCodeSource();
        if (source == null || source.getLocation() == null) {
            throw new IllegalStateException("target has no CodeSource");
        }
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }

    private static String b64(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private static String describeArray(File[] input) {
        if (input == null) {
            return "<null-array>";
        }
        StringBuilder out = new StringBuilder("[");
        for (int i = 0; i < input.length; i++) {
            if (i != 0) {
                out.append(',');
            }
            out.append(input[i] == null ? "<null>" : b64(input[i].getPath()));
        }
        return out.append(']').toString();
    }

    private static void requireEmptyWorkingDirectory(String expected) throws Exception {
        String actual = Paths.get(".").toRealPath().toString();
        if (!actual.equals(expected)) {
            throw new IllegalStateException("unexpected JVM cwd: expected=" + expected + " actual=" + actual);
        }
        String[] entries = new File(".").list();
        if (entries == null || entries.length != 0) {
            throw new IllegalStateException("JVM cwd is not empty");
        }
    }

    private static void observe(Method test, Object receiver, int index, String name,
            File[] input, String expectedCwd, PrintStream resultOut) throws Exception {
        requireEmptyWorkingDirectory(expectedCwd);
        PrintStream originalOut = System.out;
        ByteArrayOutputStream targetBytes = new ByteArrayOutputStream();
        PrintStream targetOut = new PrintStream(targetBytes, true, "UTF-8");
        Object value = null;
        Throwable cause = null;
        String stack = "";
        try {
            System.setOut(targetOut);
            try {
                value = test.invoke(receiver, (Object) input);
            } catch (InvocationTargetException e) {
                cause = e.getCause();
                StringWriter trace = new StringWriter();
                cause.printStackTrace(new PrintWriter(trace));
                stack = trace.toString();
            }
        } finally {
            targetOut.flush();
            System.setOut(originalOut);
            targetOut.close();
        }
        requireEmptyWorkingDirectory(expectedCwd);
        String exceptionName = cause == null ? "none" : cause.getClass().getName();
        String exceptionMessage = cause == null || cause.getMessage() == null ? "" : cause.getMessage();
        String result = cause == null && value != null ? ((File) value).getPath() : "";
        resultOut.println("CASE index=" + index + " name=" + name
                + " input_b64=" + b64(describeArray(input))
                + " result_b64=" + b64(result)
                + " exception=" + exceptionName
                + " exception_message_b64=" + b64(exceptionMessage)
                + " exception_stack_b64=" + b64(stack)
                + " target_stdout_b64=" + b64(new String(targetBytes.toByteArray(), StandardCharsets.UTF_8)));
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 3) {
            throw new IllegalArgumentException(
                    "usage: TestNotIndexedLoopDriver actualRoot expectedRoot emptyWorkingDirectory");
        }
        String actual = Paths.get(args[0]).toRealPath().toString();
        String expected = Paths.get(args[1]).toRealPath().toString();
        String expectedCwd = Paths.get(args[2]).toRealPath().toString();
        requireEmptyWorkingDirectory(expectedCwd);
        URL url = Paths.get(actual).toRealPath().toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(new URL[] { url }, null)) {
            Class<?> target = Class.forName(TARGET, true, loader);
            if (target.getClassLoader() != loader) {
                throw new IllegalStateException("target did not load from parentless loader");
            }
            String actualCodeSource = codeSource(target);
            if (!actualCodeSource.equals(expected)) {
                throw new IllegalStateException("wrong CodeSource: expected=" + expected
                        + " actual=" + actualCodeSource);
            }
            Constructor<?> constructor = target.getDeclaredConstructor();
            Object receiver = constructor.newInstance();
            Method test = target.getDeclaredMethod("test", File[].class);
            if (Modifier.isStatic(test.getModifiers())) {
                throw new IllegalStateException("test(File[]) unexpectedly static");
            }
            PrintStream resultOut = System.out;
            File[][] cases = inputs();
            for (int index = 0; index < cases.length; index++) {
                observe(test, receiver, index, CASE_NAMES[index], cases[index], expectedCwd, resultOut);
            }
            requireEmptyWorkingDirectory(expectedCwd);
        }
    }
}
