#!/usr/bin/env python3
"""Build a durable, member-hashed TestNotIndexedLoop evidence archive after review."""
from __future__ import annotations
import argparse, hashlib, io, json, tarfile
from pathlib import Path

PRIVATE = Path('/private/tmp').resolve()
PREP = Path(__file__).resolve().parent
EXPECTED = {
 'jarde-testnotindexedloop-baseline-root-v1-20261019': '56276e1841a38d4929826cfb52440ef8ef88d07efae07149a06a6626ae10c967',
 'jarde-testnotindexedloop-generated-root-v1-20261019': '8e57bf803579a692df08388e168f336fa44cb072620fbc81f1daa517e2253b4c',
}
RESULTS = tuple(EXPECTED)
WRAPPERS = (
 'jarde-testnotindexedloop-baseline-wrapper-root-v1-20261019',
 'jarde-testnotindexedloop-generated-wrapper-root-v1-20261019',
)
ROOT_AUDITS = (
 'jarde-testnotindexedloop-baseline-audit-root-v1-20261019',
 'jarde-testnotindexedloop-generated-audit-root-v1-20261019',
)
HISTORY = (
 'jarde-testnotindexedloop-baseline-prep-luna-v1-20261019',
 'jarde-testnotindexedloop-baseline-prep-luna-v2-20261019',
 'jarde-testnotindexedloop-generated-prep-luna-v1-20261019',
 'jarde-testnotindexedloop-baseline-audit-luna-v1-20261019',
 'jarde-testnotindexedloop-baseline-audit-luna-v2-20261019',
 'jarde-testnotindexedloop-baseline-audit-luna-v3-20261019',
 'jarde-testnotindexedloop-generated-audit-luna-v1-20261019',
 'jarde-testnotindexedloop-generated-audit-luna-v2-20261019',
 'jarde-testnotindexedloop-generated-audit-luna-v3-20261019',
 'jarde-testnotindexedloop-generated-audit-luna-v4-20261019',
 'jarde-notindexedloop-equals-audit-luna-v1-20261019',
 'jarde-notindexedloop-equals-audit-luna-v2-20261019',
)
EXTERNAL = (
 ('upstream/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestNotIndexedLoop.java',
  Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestNotIndexedLoop.java'),
  'dc08e939d5d5ab12c2f4a89e11b266a7e9592ca6289e700241a5eca2f29980b5'),
 ('upstream/jadx/LICENSE', Path('/Users/lordcasser/workspace/testzone/jadx/LICENSE'),
  'b40930bbcf80744c86c46a12bc9da056641d722716c378f5659b9e555ef833e1'),
 ('upstream/jadx/NOTICE', Path('/Users/lordcasser/workspace/testzone/jadx/NOTICE'),
  '3f34304fa0b9da79fae989cca556d22bd3d08786d6ba171f529a00bfc880e365'),
)
EXCLUDED = {'target', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache', '.cache', 'node_modules'}
ACTIVE = {'running', 'in_progress', 'started', 'collecting'}
PREP_MEMBERS = ('README.md', 'pins.json', 'pack.py', 'cf07-template.diff')

def sha(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def require(ok: bool, msg: str) -> None:
    if not ok: raise ValueError(msg)
def file_pin(path: Path) -> dict:
    require(not path.is_symlink(), f'refuse symlink: {path}')
    data = path.resolve(strict=True).read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': sha(data)}
def read_json(path: Path) -> dict: return json.loads(path.read_text(encoding='utf-8'))
def check_receipts() -> None:
    for name, expected_sha in EXPECTED.items():
        root = PRIVATE / name
        receipt_path = root / 'execution.json'
        marker_path = root / 'root-review.json'
        require(root.is_dir() and receipt_path.is_file() and marker_path.is_file(), f'missing result evidence: {name}')
        receipt = read_json(receipt_path)
        require(receipt.get('status') not in ACTIVE, f'nonterminal receipt: {receipt_path}')
        require(sha(receipt_path.read_bytes()) == expected_sha, f'receipt changed: {receipt_path}')
        marker = read_json(marker_path)
        require(str(marker.get('status', '')).startswith('root_accepted'), f'root marker not accepted: {marker_path}')
        require(marker.get('receipt_sha256') == expected_sha, f'root marker binds another receipt: {marker_path}')
        if 'baseline' in name:
            audit = marker.get('audit', {})
            audit_path = PRIVATE / ROOT_AUDITS[0] / 'review.json'
            require(audit.get('path') == str(audit_path) and audit.get('bytes') == audit_path.stat().st_size
                    and audit.get('sha256') == sha(audit_path.read_bytes()), 'baseline root audit pin mismatch')
        else:
            require(marker.get('independent_review') == str(PRIVATE / ROOT_AUDITS[1] / 'review.json'),
                    'generated root audit path mismatch')
            audit = read_json(PRIVATE / ROOT_AUDITS[1] / 'review.json')
            require(audit.get('receipt_sha256') == expected_sha, 'generated root audit binds another receipt')
        expected_commands = 20 if 'baseline' in name else 51
        require(len(receipt.get('commands', [])) == expected_commands, f'command count mismatch: {receipt_path}')
    for name in WRAPPERS:
        wrapper = read_json(PRIVATE / name / 'execution.json')
        require(wrapper.get('status') not in ACTIVE, f'wrapper is still active: {name}')
        commands = wrapper.get('commands')
        if isinstance(commands, list):
            require(bool(commands) and all(row.get('exit_code') == 0 for row in commands), f'wrapper command failure: {name}')
        else:
            require(wrapper.get('exit_code') == 0, f'wrapper command failure: {name}')
    for name in ROOT_AUDITS:
        root = PRIVATE / name
        review = read_json(root / 'review.json')
        if 'baseline' in name:
            require(review.get('commands') == 20 and review.get('original_vm_runs') == 4 and review.get('case_observations') == 20,
                    f'baseline audit summary changed: {root}')
        else:
            require(review.get('commands') == 51 and review.get('compile_successes') == 10 and review.get('compile_failures') == 10,
                    f'generated audit summary changed: {root}')

def gather() -> dict[str, Path]:
    members: dict[str, Path] = {}
    def add(name: str, path: Path) -> None:
        require(name not in members, f'duplicate member: {name}')
        require(path.is_file() and not path.is_symlink(), f'missing/unsafe file: {path}')
        members[name] = path.resolve(strict=True)
    for name in RESULTS + WRAPPERS + ROOT_AUDITS + HISTORY:
        root = PRIVATE / name
        require(root.is_dir() and not root.is_symlink(), f'missing/unsafe evidence root: {root}')
        for path in root.rglob('*'):
            if any(part in EXCLUDED for part in path.parts): continue
            require(not path.is_symlink(), f'refuse symlink in selected root: {path}')
            if path.is_file(): add('private-tmp/' + path.relative_to(PRIVATE).as_posix(), path)
    for arc, path, expected_sha in EXTERNAL:
        add(arc, path)
        require(sha(path.read_bytes()) == expected_sha, f'upstream pin changed: {path}')
    for name in PREP_MEMBERS:
        add('archive-preparation/' + name, PREP / name)
    return dict(sorted(members.items()))

def verify_prep_pins(files: dict[str, Path]) -> None:
    pins = read_json(PREP / 'pins.json')
    expected = {row['path']: row for row in pins['archive_inputs']}
    actual = {name: path for name, path in files.items() if not name.startswith('archive-preparation/')}
    require(set(actual) == set(expected), 'frozen archive input member set changed')
    for name, path in actual.items():
        row = expected[name]; data = path.read_bytes()
        require(len(data) == row['bytes'] and sha(data) == row['sha256'], f'frozen input changed: {name}')
    for name, row in pins['preparation_files'].items():
        path = PREP / name; data = path.read_bytes()
        require(len(data) == row['bytes'] and sha(data) == row['sha256'], f'preparation file changed: {name}')

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True, help='new archive path; destination must not exist')
    args = ap.parse_args()
    out = args.out.resolve()
    inv_path = out.with_suffix(out.suffix + '.inventory.json')
    require(not out.exists() and not inv_path.exists(), 'refuse existing archive or inventory')
    require(not out.is_relative_to(PREP), 'archive must be outside preparation directory')
    check_receipts()
    files = gather()
    verify_prep_pins(files)
    rows = []
    for arc, path in files.items():
        data = path.read_bytes()
        rows.append({'path': arc, 'bytes': len(data), 'sha256': sha(data)})
    manifest = {
        'schema': 'test-not-indexed-loop-durable-evidence-archive-v1',
        'status': 'root-accepted-inputs-verified-at-pack-time',
        'member_count': len(rows), 'members': rows,
        'result_roots': list(RESULTS), 'wrapper_roots': list(WRAPPERS),
        'root_audit_roots': list(ROOT_AUDITS), 'history_roots': list(HISTORY),
        'upstream_snapshot_members': [arc for arc, _, _ in EXTERNAL],
        'external_binary_policy': 'JDKs, CLI binaries, and dependency installations are not copied; their pins remain in execution receipts and collector/auditor history.',
        'scope': 'NotIndexedLoop source/API and generated-source evidence only. No production source, OpenSpec change, check() invocation, or JUnit execution is claimed.'
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(out, 'x:gz') as tar:
        for arc, path in files.items(): tar.add(path, arcname=arc, recursive=False)
        blob = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
        info = tarfile.TarInfo('ARCHIVE_INVENTORY.json'); info.size = len(blob); info.mode = 0o644
        tar.addfile(info, io.BytesIO(blob))
    with tarfile.open(out, 'r:gz') as tar:
        regular = {m.name: m for m in tar.getmembers() if m.isfile()}
        require(set(regular) == {r['path'] for r in rows} | {'ARCHIVE_INVENTORY.json'}, 'archive member set mismatch')
        for row in rows:
            data = tar.extractfile(regular[row['path']]).read()
            require(len(data) == row['bytes'] and sha(data) == row['sha256'], f'archive member mismatch: {row["path"]}')
        require(json.loads(tar.extractfile(regular['ARCHIVE_INVENTORY.json']).read()) == manifest, 'embedded inventory mismatch')
    inv = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    with inv_path.open('xb') as stream: stream.write(inv)
    print(json.dumps({'status': 'packed-and-reopened', 'archive': str(out), 'archive_sha256': sha(out.read_bytes()),
                      'inventory': str(inv_path), 'inventory_sha256': sha(inv), 'member_count': len(rows)}, indent=2))
if __name__ == '__main__': main()
