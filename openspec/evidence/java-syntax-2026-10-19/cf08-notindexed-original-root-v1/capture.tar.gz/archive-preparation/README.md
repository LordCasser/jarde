# NotIndexedLoop 持久证据归档准备

此目录只准备归档器和固定输入清单。**没有运行 `pack.py`，没有创建 tar 包，也没有写入仓库。**归档器使用已存在的 root 接受收据；实际归档前由 root 审查路径和成员范围。运行时必须显式传入一个不存在的 `--out` 路径。

## 包含范围

归档将逐字复制两份完整证据结果树及其记录：

- `jarde-testnotindexedloop-baseline-root-v1-20261019` 与对应 wrapper、Luna baseline auditors v1–v3、root audit。
- `jarde-testnotindexedloop-generated-root-v1-20261019` 与对应 wrapper、Luna generated auditors v1–v4、root audit。
- baseline/generated collectors 的所有已留存 prep 版本，以及 `jarde-notindexedloop-equals-audit` v1/v2 的原始备忘、修订说明和 pins。
- 上游完整 `TestNotIndexedLoop.java`、JADX `LICENSE` 与 `NOTICE` 快照。

归档器会对每个普通成员保存原始字节长度和 SHA-256，在 tar 内写入 `ARCHIVE_INVENTORY.json`，随后重开 tar，逐项检查成员集合、长度、哈希与内嵌清单。它拒绝符号链接、重复成员、已存在输出和非终态或未 root 接受的输入。JDK、CLI 可执行文件及大体积依赖不复制；它们的路径和内容 pin 保留在收据与 collector/auditor 文件中。两阶段 CLI SHA-256 为 `96e534b0000fe91c1d34a282919479a97eb4706063501d188cdff010c4640366`，JDK 工具清单 SHA-256 为 `ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec`。

## 已接受证据摘要

数量来自已 root 接受的独立审计：

- baseline：20 条命令（collector 采集 20 条）；其中原始目标 4 次 VM 运行、20 个受限观察；另有 8 个 API 单元格、24 个结构化方法行。wrong-root 控制被拒绝。
- 总计 71 条 collector 命令：baseline 20 + generated 51；generated 阶段 51 条命令中包含完整源码提取、20 次编译尝试、VM/错根运行等。原始来源 4 次 VM/20 个观察仍单列，不与生成目标混计。
- Jarde：8 个 JDK 23 完整源码编译成功格，16 次 VM、80 个观察。
- JADX：2 个 JDK 23 完整源码编译成功格，4 次 VM、20 个观察。baseline 与 generated 两份 collector 收据合计保存 142 个原始 stdout/stderr 流（另含 wrapper 与 audit 流）。
- 另有 10 个 JDK 8 完整源码编译失败格；均由依赖框架 class major 55 与目标输出 major 52 的已核实边界导致，没有为这些格运行 VM。编译失败保留为失败，不作成功或行为一致推断。
- generated 全部 20 个源格均保留；source copies 的字节一致性已审计。API default/all 输出文本与 raw map 的相等性由 baseline 门核实。

## 明确限制

上游 `check()V` 保留在物理类与完整反编译结果中，但没有执行；JUnit 断言方法也没有运行。driver 只调用受限的 `test(File[])` 观察用例。这里不声称 JUnit/check 测试通过，也不把归档完整性当作产品验收。`String.equals(Object)` 显示 cast 是单独记录的展示质量债务，没有在本项中修改生产代码。没有新增生产代码、OpenSpec 变更或 CF08 整项验收。

## 归档器

- `pack.py`：复制指定结果/历史目录和上游源快照；生成并复开带逐成员哈希的 tar。
- `pins.json`：本准备目录和其关键冻结输入的准备时 SHA-256。
- `cf07-template.diff`：与既有 CF07 `pack_evidence.py` 的逐行 unified diff。

此准备包本身不是归档，不应被写成已打包或重新运行过矩阵。
