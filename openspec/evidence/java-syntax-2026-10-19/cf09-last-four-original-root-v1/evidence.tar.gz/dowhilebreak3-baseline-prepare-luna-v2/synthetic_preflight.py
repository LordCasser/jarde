#!/usr/bin/env python3
"""Load the actual collector and exercise its source-copy pin validator with synthetic drift."""
from pathlib import Path
import importlib.util, json, tempfile
ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source/jadx/tests/integration/loops/TestDoWhileBreak3.java'
COLLECTOR = ROOT / 'collect_baseline.py'
def load_collector():
    spec = importlib.util.spec_from_file_location('do3_collector_synthetic', COLLECTOR)
    if spec is None or spec.loader is None: raise RuntimeError('cannot load collector')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module
def rejected(mod, plan, upstream, packaged, label):
    try: mod.validate_case_plan(plan, upstream, packaged)
    except SystemExit: return
    raise AssertionError('collector accepted invalid synthetic input: '+label)
def main():
    mod = load_collector(); plan = json.loads((ROOT/'caseplans.json').read_text(encoding='utf-8'))
    mod.validate_case_plan(plan, SOURCE, SOURCE)
    checks = ['package-source-copy-equivalent']
    with tempfile.TemporaryDirectory(dir=ROOT, prefix='.synthetic-') as td:
        tmp = Path(td); copy = tmp/'copy.java'; copy.write_bytes(SOURCE.read_bytes())
        good = json.loads(json.dumps(plan)); good['source_pins']['TestDoWhileBreak3']['path'] = str(copy)
        mod.validate_case_plan(good, SOURCE, copy); checks.append('external-copy-equivalent')
        wrong_path = json.loads(json.dumps(good)); wrong_path['source_pins']['TestDoWhileBreak3']['path'] = str(SOURCE)
        rejected(mod, wrong_path, SOURCE, copy, 'wrong-copy-path'); checks.append('wrong-copy-path-rejected')
        drift = tmp/'drift.java'; drift.write_bytes(SOURCE.read_bytes()+b' ')
        wrong_bytes = json.loads(json.dumps(plan)); wrong_bytes['source_pins']['TestDoWhileBreak3']['path'] = str(drift)
        rejected(mod, wrong_bytes, SOURCE, drift, 'copy-byte-drift'); checks.append('copy-byte-drift-rejected')
        wrong_upstream = tmp/'upstream.java'; wrong_upstream.write_bytes(SOURCE.read_bytes()+b' ')
        rejected(mod, good, wrong_upstream, copy, 'upstream-copy-disagreement'); checks.append('upstream-copy-disagreement-rejected')
    print(json.dumps({'synthetic_caseplan_validation':'passed','checks':checks,'count':len(checks)},indent=2))
if __name__ == '__main__': main()
