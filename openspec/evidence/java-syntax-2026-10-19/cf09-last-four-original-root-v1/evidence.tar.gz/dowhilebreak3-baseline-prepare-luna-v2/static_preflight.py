#!/usr/bin/env python3
"""Static-only integrity checks for the prepared TestDoWhileBreak3 capture; runs no toolchain."""
from pathlib import Path
import ast, hashlib, importlib.util, json, re
ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source/jadx/tests/integration/loops/TestDoWhileBreak3.java'
DRIVER = ROOT / 'driver/TestDoWhileBreak3Driver.java'
COLLECTOR = ROOT / 'collect_baseline.py'
CASEPLAN = ROOT / 'caseplans.json'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    expected_source = '031b252df423c0db4f2198f0b75814dcda6398d83ba7c8c6dc8d2624f9cb662e'
    assert SOURCE.stat().st_size == 640 and sha(SOURCE) == expected_source
    assert (SOURCE.stat().st_mode & 0o777) == 0o644
    cp = json.loads(CASEPLAN.read_text(encoding='utf-8'))
    family = cp['case_plans']['TestDoWhileBreak3']
    expected = ('empty-break','null-first-tail','one-nonnull-exhausted','two-nonnull-exhausted','nonnull-null-tail',
                'null-iterator','hasnext-throws-first','next-throws-first','hasnext-throws-second','next-throws-second')
    assert tuple(c['id'] for c in family['cases']) == expected
    assert cp['source_pins']['TestDoWhileBreak3'] == {'path':str(SOURCE),'bytes':640,'sha256':expected_source}
    assert family['descriptor'] == '()V' and family['fields'] == [
        {'name':'it','descriptor':'Ljava/util/Iterator;','access':'package-private instance'}]
    assert family['declared_nested_methods'] == [{'name':'test','descriptor':'()V'}]
    assert family['source_assertions'] == ['containsOne("while")','containsLines(2, "while (this.it.hasNext() && this.it.next() != null) {", "}")']
    text = SOURCE.read_text(encoding='utf-8')
    assert 'check()' not in text and 'containsOne("while")' in text
    assert 'containsLines(2, "while (this.it.hasNext() && this.it.next() != null) {", "}")' in text
    driver = DRIVER.read_text(encoding='utf-8')
    for term in ('new URLClassLoader(targetUrls(actual), null)', 'getDeclaredMethod("check")',
                 'has_next_calls=', 'next_calls=', 'event_trace_b64=', 'remaining_b64=',
                 'exception_message_b64=', 'exception_stack_b64=', 'requireEmptyCwd(cwd)'):
        assert term in driver, term
    assert 'check() exists' not in driver
    c = COLLECTOR.read_text(encoding='utf-8')
    ast.parse(c)
    assert "CASE_PLAN_SHA256 = '"+sha(CASEPLAN)+"'" in c
    assert "DRIVER_SHA256 = '"+sha(DRIVER)+"'" in c
    assert 'TestDoWhileBreak3$TestCls' in c and "('it', 'Ljava/util/Iterator;', 0)" in c
    assert "('test', '()V')" in c and 'expected_calls_from_source' not in c
    assert len(expected) == 10
    spec = importlib.util.spec_from_file_location('do3_collector_static', COLLECTOR)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    module.validate_case_plan(cp, SOURCE, SOURCE)
    print(json.dumps({'status':'static-preflight-passed','source_sha256':sha(SOURCE),
      'caseplan_sha256':sha(CASEPLAN),'driver_sha256':sha(DRIVER),'collector_sha256':sha(COLLECTOR),
      'case_count':len(expected),'toolchain_executed':False},indent=2))
if __name__ == '__main__': main()
