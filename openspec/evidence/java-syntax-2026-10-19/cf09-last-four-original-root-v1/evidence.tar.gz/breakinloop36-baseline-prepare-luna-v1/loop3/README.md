# TestBreakInLoop3 complete-source baseline preparation

This package is preparation only. It has not run Java, JADX, Jarde, Cargo, or Git. The collector is adapted from the accepted Loop4 baseline collector and retains its command/raw-stream pinning, full-source compile attempts, 8-call Jarde grid, complete method maps/physical BCIs, two-runtime isolation, CodeSource negative controls, dependency URL checks, source closure checks, and target absence guards.

The source pin is 1216 bytes, SHA-256 `7426191067f7ec483c191029376a2ee5544ccfdb5f893c2cf0a21f4df219ffc4`, matching the frozen JADX commit `2fb1b16386941660fda07e9017285aec40fcb37f` per the parent’s `git show` verification. The target is `jadx.tests.integration.loops.TestBreakInLoop3$TestCls`, with `<init>()V`, `writeMore(Ljava/lang/String;)V`, private `prt(Ljava/lang/String;)V`, `check()V`, and private `builder:Ljava/lang/StringBuilder;`. The complete outer+inner class tree is compiled unchanged.

`test43()` carries `@NotYetImplemented`, but its `@Test` annotation is commented out; it is not an active JUnit test. The collection therefore does not claim that upstream JUnit executed it. The independent driver invokes the unchanged compiled target directly and observes the only planned input, the empty string, plus `check()` on a separate fresh instance. Both invocations run in an empty private cwd; builder state is read reflectively. No nonempty path or external filesystem effect is in scope.

The original compiled class is the semantic oracle. The source-derived builder trace `12135678` is recorded only as a static hypothesis. `check()` is reported separately from `writeMore`; framework/JDK check failures must remain distinct from recovered-body quality.

Run only after root chooses the candidate CLI and confirms its exact digest:

```sh
python3 -B /private/tmp/jarde-breakinloop36-baseline-prepare-luna-v1-20261019/loop3/collect_baseline.py --out /private/tmp/jarde-breakinloop3-baseline-root-v1-20261019 --cli /absolute/path/to/candidate-cli --cli-sha256 <64-lowercase-hex>
```

The script accepts only the pinned workspace, refuses pre-existing output and `target/`, binds all tool/dependency/JDK inputs, and preserves failed commands and raw stdout/stderr. The output is pending independent audit, not a product acceptance result.
