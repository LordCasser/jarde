#!/usr/bin/env python3
"""Capture full-source TestBreakInLoop3 original/JADX/Jarde observations; preparation only."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, re, shutil, sys, zipfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
SOURCE = Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestBreakInLoop3.java')
SOURCE_SHA256 = '7426191067f7ec483c191029376a2ee5544ccfdb5f893c2cf0a21f4df219ffc4'

DEPENDENCY_REFERENCE = Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018/execution.json')
DEPENDENCY_REFERENCE_SHA256 = '5a7d6572e600d19dc45d78030d0b12867bc742c4b014381fb5c7b059db171d35'
RUNTIME_BOUND = Path('/private/tmp/jarde-testnotindexedloop-baseline-prep-luna-v2-20261019/runtime-bound-cwd.py')
RUNTIME_BOUND_SHA256 = 'bc917ec08e07ed462c18958f9a0d3b064b7d5bba3adc5fa41d9db49ff6c3de46'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA256 = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA256 = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
COMPARE_REL = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA256 = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
PARSER = Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA256 = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
DRIVER_SHA256 = 'e72f73ad4773c86cdd26def1a850fdb5b0ef6f71d26263b1541a1f0fe5019315'
CASE_PLAN_PATH = Path(__file__).with_name('caseplans.json')
CASE_PLAN_SHA256 = 'e3b979ecceef0d0724cb55357ea067fddd561790a1451aa66f322083d98c2ed3'

INTERNAL = 'jadx/tests/integration/loops/TestBreakInLoop3$TestCls'
OUTER_INTERNAL = 'jadx/tests/integration/loops/TestBreakInLoop3'
TARGET_DOT = 'jadx.tests.integration.loops.TestBreakInLoop3$TestCls'
API_CLASSES = ((INTERNAL, 'target'),)
SOURCE_CLASS_TREE = (OUTER_INTERNAL + '.class', INTERNAL + '.class')
RUNTIMES = ('javac8', 'javac23')
PROFILES = ('debug', 'no-debug')
EVIDENCE = ('default', 'all')
CASE_NAMES = ('empty-path-write',)


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def same_content(compare, first: Path, second: Path) -> bool:
    left, right = compare.pin(first), compare.pin(second)
    return left.get('bytes') == right.get('bytes') and left.get('sha256') == right.get('sha256')


def inventory_metadata_differences(original: dict, generated: dict, internal: str) -> list[dict]:
    differences = []
    specs = (
        ('method', original['methods'], generated['methods'], lambda row: (row['name'], row['descriptor']), lambda row: row['access']),
        ('field', original['fields'], generated['fields'],
         lambda row: (row['name'], row['descriptor']) if isinstance(row, dict) else (row[0], row[1]),
         lambda row: row['access'] if isinstance(row, dict) else row[2]),
    )
    for kind, left, right, key_of, access_of in specs:
        left_by = {key_of(row): row for row in left}; right_by = {key_of(row): row for row in right}
        if left_by.keys() != right_by.keys():
            raise RuntimeError(f'{internal}: {kind} name/descriptor inventory differs')
        for name, descriptor in sorted(left_by):
            left_access, right_access = access_of(left_by[(name, descriptor)]), access_of(right_by[(name, descriptor)])
            if (left_access & ~0x1000) != (right_access & ~0x1000):
                raise RuntimeError(f'{internal}: source-visible {kind} access differs for {name}{descriptor}')
            if left_access != right_access:
                if (left_access ^ right_access) != 0x1000:
                    raise RuntimeError(f'{internal}: non-synthetic {kind} access differs for {name}{descriptor}')
                differences.append({'class_name': internal, 'member_kind': kind, 'name': name,
                                    'descriptor': descriptor, 'original_access': left_access,
                                    'generated_access': right_access, 'allowed_difference': 'ACC_SYNTHETIC only'})
    return differences



def full_class_facts(compare, physical, path: Path, role: str) -> dict:
    facts = compare.parse_class(path)
    actual = physical.parse_class_file(path.read_bytes())
    if actual['class_name'] != facts['class_name'] or actual['major'] != facts['major'] \
            or actual['methods'] != facts['methods']:
        raise RuntimeError(f'{role}: independent physical method/Code census differs')
    if sorted((x['name'], x['descriptor'], x['access']) for x in actual['fields']) != sorted(facts['fields']):
        raise RuntimeError(f'{role}: independent physical field census differs')
    facts['access'] = actual['access']
    if len({(m['name'], m['descriptor']) for m in facts['methods']}) != len(facts['methods']):
        raise RuntimeError(f'{role}: duplicate method identity')
    for method in facts['methods']:
        code = method.get('code')
        if code is None or not code.get('bcis') or code['bcis'][0] != 0 \
                or code['bcis'][-1] >= code['code_length']:
            raise RuntimeError(f'{role} {method["name"]}{method["descriptor"]}: invalid physical Code/BCIs')
    return facts


def class_tree(root: Path) -> dict:
    return {p.relative_to(root).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p)}
            for p in sorted(root.rglob('*.class'))}


def parse_oracle(stdout: bytes) -> list[dict]:
    import base64, re
    lines = stdout.decode('utf-8', errors='strict').splitlines()
    if len(lines) != 2 or not lines[0].startswith('CASE ') or not lines[1].startswith('CHECK '):
        raise ValueError(f'expected exactly CASE then CHECK, got {len(lines)} lines')
    def decode(value: str) -> str:
        return base64.b64decode(value, validate=True).decode('utf-8', errors='strict')
    case_re = re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) target_stdout_b64=([^ ]*) after_b64=([^ ]*) builder_before_b64=([^ ]*) builder_after_b64=([^ ]*)$')
    cm = case_re.fullmatch(lines[0])
    if cm is None: raise ValueError(f'malformed CASE: {lines[0]!r}')
    idx,name,inp,result,etype,msg,stack,out,after,before,builder_after=cm.groups()
    if idx != '0' or name != CASE_NAMES[0]: raise ValueError('case identity/order mismatch')
    check_re = re.compile(r'^CHECK result=(pass|error) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) stdout_b64=([^ ]*) builder_before_b64=([^ ]*) builder_after_b64=([^ ]*)$')
    hm = check_re.fullmatch(lines[1])
    if hm is None: raise ValueError(f'malformed CHECK: {lines[1]!r}')
    cr,ce,cmg,cstack,cout,cbefore,cafter=hm.groups()
    return [{'index':0,'name':name,'input':decode(inp),'result':decode(result),'exception_type':etype,
      'exception_message':decode(msg),'exception_stack':decode(stack),'target_stdout':decode(out),'after':decode(after),
      'builder_before':decode(before),'builder_after':decode(builder_after),'raw':lines[0],
      'check_result':cr,'check_exception_type':ce,'check_exception_message':decode(cmg),
      'check_exception_stack':decode(cstack),'check_stdout':decode(cout),
      'check_builder_before':decode(cbefore),'check_builder_after':decode(cafter)}]

def list_snapshot(value):
    return value


def validate_case_oracle(rows, planned):
    if len(rows) != len(planned): return ['case count differs']
    issues = []
    for row, case in zip(rows, planned):
        exp = case['expected']; inp = case['input']
        if row['name'] != case['id'] or row['input'] != inp or row['after'] != inp: issues.append(f"{case['id']}: identity/input differs")
        if row['result'] != f"return={exp['return']}" or row['exception_type'] != exp['exception_type']:
            issues.append(f"{case['id']}: return/exception differs from static hypothesis")
        if row['target_stdout'] != exp['stdout']: issues.append(f"{case['id']}: stdout differs from static hypothesis")
    return issues


def oracle_projection(rows: list[dict]) -> list[dict]:
    return [{key: row[key] for key in ('index', 'name', 'input', 'result', 'exception_type', 'target_stdout', 'after', 'builder_before', 'builder_after')}
            for row in rows]


def utf8_boundaries(text: str) -> set[int]:
    boundaries = {0}; offset = 0
    for char in text:
        offset += len(char.encode('utf-8'))
        boundaries.add(offset)
    return boundaries

def audit_method_map(method: dict, physical: dict) -> dict:
    outcome = method.get('outcome', {}); body = outcome.get('report', {})
    text = body.get('text')
    source_map = body.get('source_map')
    result = {'outcome_kind': outcome.get('kind'), 'quality': body.get('quality'),
              'map_present': isinstance(source_map, dict), 'issues': []}
    if not isinstance(text, str):
        result['issues'].append('raw method text missing'); return result
    raw = text.encode('utf-8'); result['text_bytes'] = len(raw)
    if not isinstance(source_map, dict) or not isinstance(source_map.get('segments'), list):
        result['issues'].append('source map/segments missing'); return result
    bounds = utf8_boundaries(text); valid_bcis = set(physical.get('code', {}).get('bcis', [])); mapped = set()
    segments = source_map['segments']; result['segment_count'] = len(segments)
    for index, segment in enumerate(segments):
        start, end = segment.get('start'), segment.get('end')
        if type(start) is not int or type(end) is not int or not (0 <= start <= end <= len(raw)) or start not in bounds or end not in bounds:
            result['issues'].append(f'segment {index} has invalid UTF-8 byte bounds'); continue
        origin = segment.get('origin')
        if not isinstance(origin, dict) or not isinstance(origin.get('primary'), dict):
            result['issues'].append(f'segment {index} has no primary origin'); continue
        derived = origin.get('derived', [])
        if not isinstance(derived, list):
            result['issues'].append(f'segment {index} has malformed derived-origin list')
            continue
        for ref in [origin['primary'], *derived]:
            if not isinstance(ref, dict):
                result['issues'].append(f'segment {index} has malformed origin reference')
                continue
            bci = ref.get('bci')
            if type(bci) is not int or bci not in valid_bcis:
                result['issues'].append(f'segment {index} references nonphysical BCI {bci!r}')
            else: mapped.add(bci)
            ref_method = ref.get('method')
            item_identity = method.get('item', {}).get('identity', {})
            expected_owner = item_identity.get('owner') if isinstance(item_identity, dict) else None
            if not isinstance(ref_method, dict):
                result['issues'].append(f'segment {index} has no origin method identity')
                continue
            if not isinstance(expected_owner, dict) or not isinstance(ref_method.get('owner'), dict):
                result['issues'].append(f'segment {index} has malformed origin owner identity')
            try:
                ref_name = bytes(ref_method.get('name', [])).decode('utf-8', errors='strict')
                ref_descriptor = bytes(ref_method.get('descriptor', [])).decode('utf-8', errors='strict')
            except (TypeError, ValueError, UnicodeDecodeError):
                result['issues'].append(f'segment {index} has malformed origin method identity')
            else:
                if ref_name != physical.get('name') or ref_descriptor != physical.get('descriptor'):
                    result['issues'].append(f'segment {index} references a different method identity')
                if ref_method.get('owner') != expected_owner:
                    result['issues'].append(f'segment {index} origin owner differs from method owner')
    result['mapped_bcis'] = sorted(mapped)
    result['physical_bcis'] = sorted(valid_bcis)
    result['unmapped_physical_bcis'] = sorted(valid_bcis - mapped)
    result['covers_all_physical_bcis'] = mapped == valid_bcis
    return result


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--cli', type=Path, required=True, help='candidate CLI; its exact SHA is supplied separately')
    ap.add_argument('--cli-sha256', required=True, help='root-supplied exact candidate CLI SHA-256')
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    root, out, cli = args.root.resolve(strict=True), args.out.resolve(), args.cli.resolve(strict=True)
    if len(args.cli_sha256) != 64 or any(ch not in '0123456789abcdef' for ch in args.cli_sha256):
        raise SystemExit('--cli-sha256 must be 64 lowercase hex characters')
    if sha(cli) != args.cli_sha256: raise SystemExit('root-supplied CLI SHA does not match the selected candidate')
    if root != ROOT.resolve(): raise SystemExit(f'workspace differs from pinned root: {root}')
    if out.exists(): raise SystemExit(f'refusing existing output: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink(): raise SystemExit('target must be absent')
    if sha(CASE_PLAN_PATH) != CASE_PLAN_SHA256: raise SystemExit('source-only case-plan pin mismatch')
    case_plan = json.loads(CASE_PLAN_PATH.read_text(encoding='utf-8'))
    planned = case_plan.get('cases', [])
    if tuple(row.get('id') for row in planned) != CASE_NAMES:
        raise SystemExit('source-only case plan differs from the frozen driver case order')
    planned_source_pin = case_plan.get('source', {})
    planned_source = Path(planned_source_pin.get('copy', '')).resolve(strict=True)
    if (planned_source_pin.get('sha256') != SOURCE_SHA256
            or planned_source_pin.get('bytes') != len(SOURCE.read_bytes())
            or sha(planned_source) != SOURCE_SHA256
            or planned_source.stat().st_size != len(SOURCE.read_bytes())
            or planned_source.read_bytes() != SOURCE.read_bytes()):
        raise SystemExit('case-plan source copy differs from the pinned original input')
    for path, expected, label in (
        (SOURCE, SOURCE_SHA256, 'complete upstream source'),
        (CASE_PLAN_PATH, CASE_PLAN_SHA256, 'source-only mathematical case plan'),
        (cli, args.cli_sha256, 'root-pinned candidate CLI'),
        (DEPENDENCY_REFERENCE, DEPENDENCY_REFERENCE_SHA256, 'accepted harness dependency reference'),
        (RUNTIME_BOUND, RUNTIME_BOUND_SHA256, 'runtime guard'),
        (JADX, JADX_SHA256, 'JADX launcher'),
        (JADX_JAR, JADX_JAR_SHA256, 'JADX jar'),
        (PARSER, PARSER_SHA256, 'physical class parser'),
    ):
        if sha(path) != expected: raise SystemExit(f'{label} pin mismatch: {path}')

    compare_path = root / COMPARE_REL
    guard_path, scanner_path = root / GUARD_REL, root / SCANNER_REL
    manifest_path = root / JDK_MANIFEST_REL
    for path, expected, label in ((compare_path, COMPARE_SHA256, 'compare'),
                                  (guard_path, GUARD_SHA256, 'guard'),
                                  (scanner_path, SCANNER_SHA256, 'scanner'),
                                  (manifest_path, JDK_MANIFEST_SHA256, 'JDK manifest')):
        if sha(path) != expected: raise SystemExit(f'{label} source pin mismatch: {path}')
    compare = load(compare_path, 'nestedloops_compare')
    guard = load(guard_path, 'nestedloops_guard')
    scanner = load(scanner_path, 'nestedloops_scanner')
    physical = load(PARSER, 'nestedloops_physical_class_parser')
    jdks, jdk_record = compare.configured_jdks(manifest_path, JDK_MANIFEST_SHA256)
    dependency = json.loads(DEPENDENCY_REFERENCE.read_text(encoding='utf-8'))
    if dependency.get('schema') != 'cf11-original-nestedloops3-baseline-v1':
        raise SystemExit('dependency reference schema mismatch')
    if not dependency.get('classpath') or not dependency.get('harness_jar'):
        raise SystemExit('dependency reference lacks accepted test harness classpath')
    dep_dirs = dependency.get('directory_pins', dependency.get('directory_pins_before'))
    if not dep_dirs: raise SystemExit('dependency reference lacks class-directory pins')
    dep_rows = [dependency['harness_jar'], *dependency.get('jar_pins', [])]
    for row in dep_rows:
        if compare.pin(Path(row['path'])) != row: raise SystemExit(f'dependency artifact changed: {row["path"]}')
    def tree_pins(base: Path):
        return {p.relative_to(base).as_posix(): compare.pin(p) for p in sorted(base.rglob('*.class'))}
    for folder, expected in dep_dirs.items():
        if tree_pins(Path(folder)) != expected: raise SystemExit(f'dependency class directory changed: {folder}')
    class_names = {INTERNAL + '.class', OUTER_INTERNAL + '.class'}
    for row in dep_rows:
        if row['path'].endswith('.jar'):
            with zipfile.ZipFile(row['path']) as archive:
                if class_names.intersection(archive.namelist()): raise SystemExit('target leaked into dependency jar')
    for folder in dep_dirs:
        if any((Path(folder) / name).is_file() for name in class_names):
            raise SystemExit(f'target leaked into dependency directory: {folder}')

    driver_source = Path(__file__).parent / 'driver' / 'TestBreakInLoop3Driver.java'
    
    if sha(driver_source) != DRIVER_SHA256: raise SystemExit('standalone driver source pin mismatch')

    out.mkdir(parents=True)
    raw_dir = out / 'raw'; raw_dir.mkdir()
    guard.ROOT = root; guard.OUT = raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, stdout_bytes: None
    if shutil.disk_usage(root).free < 5 * 1024**3: raise SystemExit('5 GiB free-space guard failed')

    source_copy = out / 'source/jadx/tests/integration/loops/TestBreakInLoop3.java'
    source_copy.parent.mkdir(parents=True)
    shutil.copy2(SOURCE, source_copy)
    if not same_content(compare, source_copy, SOURCE): raise RuntimeError('upstream source copy differs')
    driver_copy = out / 'driver-source/TestBreakInLoop3Driver.java'
    driver_copy.parent.mkdir(parents=True)
    shutil.copy2(driver_source, driver_copy)
    if not same_content(compare, driver_copy, driver_source): raise RuntimeError('driver source copy differs')
    runtime_copy = out / RUNTIME_BOUND.name; shutil.copy2(RUNTIME_BOUND, runtime_copy)
    if not same_content(compare, runtime_copy, RUNTIME_BOUND): raise RuntimeError('runtime wrapper copy differs')
    empty = out / 'empty-classpath'; empty.mkdir()
    driver_classes = out / 'driver-classes'; driver_classes.mkdir()
    classpath_text = os.pathsep.join(dependency['classpath'])
    source_before = compare.source_closure(root)
    collector_path = Path(__file__).resolve()
    tool_paths = [SOURCE, planned_source, CASE_PLAN_PATH, cli, DEPENDENCY_REFERENCE, RUNTIME_BOUND, driver_source, collector_path, JADX, JADX_JAR,
                  root / JDK_MANIFEST_REL, compare_path, guard_path, scanner_path, PARSER]
    def external_snapshot():
        return {
            'files': [compare.pin(p) for p in tool_paths],
            'dependency_artifacts': [compare.pin(Path(row['path'])) for row in dep_rows],
            'dependency_directories': {str(Path(folder).resolve()): tree_pins(Path(folder)) for folder in dep_dirs},
            'jdk_tools': {f'{leg}_{name}': compare.pin(path) for leg, spec in jdks.items()
                          for name, path in spec['tools'].items()},
        }
    external_before = external_snapshot()
    local_copies_before = {'source_copy': compare.pin(source_copy), 'driver_copy': compare.pin(driver_copy),
                           'runtime_copy': compare.pin(runtime_copy)}
    report = {
        'schema': 'test-break-in-loop4-full-source-baseline-v1', 'status': 'running',
        'root': str(root), 'output': str(out), 'source': compare.pin(SOURCE), 'case_plan': compare.pin(CASE_PLAN_PATH),
        'case_plan_source_copy': compare.pin(planned_source),
        'candidate_cli_sha256_expected': args.cli_sha256, 'runtime_case_names': list(CASE_NAMES), 'check_method_required': True,
        'source_copy': compare.pin(source_copy), 
        'cli': compare.pin(cli), 'dependency_reference': compare.pin(DEPENDENCY_REFERENCE),
        'dependency_classpath': dependency['classpath'], 'dependency_harness_jar': dependency['harness_jar'],
        'dependency_jar_pins': dependency.get('jar_pins', []), 'dependency_directory_pins': dep_dirs,
        'driver_source': compare.pin(driver_source), 'driver_copy': compare.pin(driver_copy),
        'runtime_wrapper': compare.pin(runtime_copy), 'jadx': compare.pin(JADX), 'jadx_jar': compare.pin(JADX_JAR),
        'empty_classpath': str(empty), 'jdk_manifest': jdk_record, 'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path),
        'scanner': compare.pin(scanner_path), 'physical_parser': compare.pin(PARSER),
        'external_input_pins_before': external_before, 'source_pins_before': source_before,
        'local_copy_pins_before': local_copies_before,
        'commands': [], 'source_profiles': [], 'javac8_full_source_boundary': None, 'generated_source_compilations': [], 'generated_runtime': [], 'generated_wrong_root_controls': [],
        'driver_classes': [], 'original_runtime': [],
        'runtime_semantic_agreement': None, 'wrong_root_control': None,
        'api_method_inventory_expected': {},
        'api_field_inventory_expected': {},
        'jarde_cells': [], 'jadx_outputs': [], 'generated_source_copies': [], 'generated_class_trees': [],
        'notes': [
            'The complete TestBreakInLoop3.java is compiled unchanged, retaining the outer IntegrationTest class, the nested TestCls, check(), and the inactive @NotYetImplemented test43() whose @Test annotation is commented out. The complete target inventory is captured from compiled class files.',
            'The reflection driver invokes writeMore("") and check() on separate fresh target instances. A null-parent URLClassLoader receives the target root and checked dependency URLs; the JVM application classpath contains only the driver. check() output, builder state, and exception are recorded separately.',
            'Target System.out is captured separately for writeMore and check. The sole empty-string input is passed unchanged; each row records return/exception, stdout, and reflected builder state. check() exception class/message/stdout/builder state remain separate structured observations.',
            'One bounded observation invokes the original writeMore with the empty string. The statically derived builder trace is auxiliary; the original compiled class observation is the baseline oracle.',
            'The complete original source is attempted with the configured Java 8 compiler and built as Java 8 under Java 23; outer and target outputs are retained.',
            'Runtime classpath contains only the standalone reflection driver; each target is loaded by a fresh parentless loader and checked against an independent CodeSource path. A cwd-aware timeout wrapper starts each JVM in its own empty temporary directory.',
            'No recovery result is assumed. API source/quality/regions, per-method raw maps/UTF-8/physical-BCI audits, and complete physical method inventories are captured for root to inspect.',
        ],
    }
    compare.write_json(out / 'execution.json', report)
    rows = report['commands']
    def command(argv, label, leg='javac23'):
        if (root / 'target').exists() or (root / 'target').is_symlink():
            raise RuntimeError('workspace target appeared during baseline capture')
        env = compare.clean_env(dict(os.environ), jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(rows) + 1, [str(x) for x in argv], env)
        row['label'] = label; row['tool_leg'] = leg; rows.append(row)
        compare.write_json(out / 'execution.json', report)
        if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        return row
    def artifact(row, channel='stdout'):
        return compare.command_artifact(row, channel)
    def pin_class_tree(path: Path):
        return {p.relative_to(path).as_posix(): compare.pin(p) for p in sorted(path.rglob('*.class'))}

    try:
        # Compile the complete upstream JUnit source, then derive observations with the independent reflection driver.
        boundary = out / 'javac8-boundary/classes'; boundary.mkdir(parents=True)
        boundary_row = command([jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
                                '-encoding', 'UTF-8', '-proc:none', '-classpath', classpath_text,
                                '-sourcepath', empty, '-d', boundary, source_copy],
                               'javac8-full-upstream-source-boundary', 'javac8')
        boundary_err = artifact(boundary_row, 'stderr')
        report['javac8_full_source_boundary'] = {
            'command': boundary_row['index'], 'exit_code': boundary_row['exit_code'],
            'class_tree': pin_class_tree(boundary),
            'major_55_diagnostic_observed': b'55.0' in boundary_err or b'version 55' in boundary_err,
            'stdout': compare.pin(Path(boundary_row['streams']['stdout']['path'])),
            'stderr': compare.pin(Path(boundary_row['streams']['stderr']['path'])),
        }
        for profile, debug in (('debug', '-g'), ('no-debug', '-g:none')):
            dest = out / profile / 'classes'; dest.mkdir(parents=True)
            row = command([jdks['javac23']['tools']['javac'], '--release', '8', debug,
                           '-encoding', 'UTF-8', '-proc:none', '-classpath', classpath_text,
                           '-sourcepath', empty, '-d', dest, source_copy], 'javac23-full-source-' + profile)
            profile_row = {'profile': profile, 'command': row['index'], 'exit_code': row['exit_code'],
                           'class_root': str(dest), 'class_tree': pin_class_tree(dest)}
            if row['exit_code'] == 0:
                tree = sorted(profile_row['class_tree'])
                expected = sorted(SOURCE_CLASS_TREE)
                if tree != expected: raise RuntimeError(f'{profile}: full class tree differs: {tree}')
                child = full_class_facts(compare, physical, dest / (INTERNAL + '.class'), profile + ' child')
                outer = full_class_facts(compare, physical, dest / (OUTER_INTERNAL + '.class'), profile + ' outer')
                if child['class_name'] != INTERNAL or child['major'] != 52:
                    raise RuntimeError(f'{profile}: target identity/major mismatch')
                expected_target_methods = {
                    ('<init>', '()V', 0x0001), ('writeMore', '(Ljava/lang/String;)V', 0x0001), ('prt', '(Ljava/lang/String;)V', 0x0002), ('check', '()V', 0x0001)
                }
                if {(m['name'], m['descriptor'], m['access']) for m in child['methods']} != expected_target_methods:
                    raise RuntimeError(f'{profile}: target method inventory differs')
                if sorted(tuple(f) if not isinstance(f, dict) else (f['name'], f['descriptor'], f['access']) for f in child['fields']) != [('builder', 'Ljava/lang/StringBuilder;', 0x0002)]:
                    raise RuntimeError(f'{profile}: target field inventory differs: {child["fields"]}')
                if outer['class_name'] != OUTER_INTERNAL or outer['major'] != 52:
                    raise RuntimeError(f'{profile}: outer identity/major mismatch')
                profile_row['target_facts'] = child; profile_row['outer_facts'] = outer
                report['api_method_inventory_expected'][profile] = {
                    INTERNAL: [(m['name'], m['descriptor']) for m in child['methods']],
                                    }
                report['api_field_inventory_expected'][profile] = {
                    INTERNAL: child['fields'],
                }
                jar = out / f'{profile}-full-classes.jar'
                with zipfile.ZipFile(jar, 'w') as archive:
                    for file in sorted(dest.rglob('*.class')):
                        entry = zipfile.ZipInfo(file.relative_to(dest).as_posix(), (1980, 1, 1, 0, 0, 0))
                        entry.compress_type = zipfile.ZIP_STORED
                        archive.writestr(entry, file.read_bytes())
                profile_row['bundle'] = compare.pin(jar)
            report['source_profiles'].append(profile_row)
            compare.write_json(out / 'execution.json', report)
        if len(report['source_profiles']) != len(PROFILES) or any(x['exit_code'] != 0 for x in report['source_profiles']):
            raise RuntimeError('complete Java 23 source profiles are incomplete; raw compiler outputs were retained')

        driver_row = command([jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
                              '-encoding', 'UTF-8', '-proc:none', '-classpath', empty,
                              '-sourcepath', empty, '-d', driver_classes, driver_copy],
                             'compile-independent-reflection-driver', 'javac8')
        report['driver_compile'] = {'command': driver_row['index'], 'exit_code': driver_row['exit_code'],
                                    'stdout': compare.pin(Path(driver_row['streams']['stdout']['path'])),
                                    'stderr': compare.pin(Path(driver_row['streams']['stderr']['path']))}
        if driver_row['exit_code'] != 0: raise RuntimeError('reflection driver compile failed')
        driver_files = sorted(driver_classes.rglob('*.class'))
        driver_tree = [file.relative_to(driver_classes).as_posix() for file in driver_files]
        expected_driver_tree = ['TestBreakInLoop3Driver.class']
        if driver_tree != expected_driver_tree:
            raise RuntimeError(f'driver class tree differs: {driver_tree}')
        report['driver_classes'] = [compare.pin(file) for file in driver_files]
        # Driver classfiles may contain modified-UTF8 constants. Keep byte pins and the existing
        # narrow class/Code summary; do not pass these helper classes through the strict parser.
        report['driver_class_summaries'] = [compare.parse_class(file) for file in driver_files]

        semantic_rows = []
        for profile in report['source_profiles']:
            if profile['exit_code'] != 0: continue
            target_root = Path(profile['class_root']).resolve()
            for runtime in RUNTIMES:
                work_dir = out / 'runtime-cwd' / profile['profile'] / runtime
                work_dir.mkdir(parents=True)
                if any(work_dir.iterdir()): raise RuntimeError(f'runtime cwd is not initially empty: {work_dir}')
                run = command([sys.executable, '-B', runtime_copy, '30', work_dir,
                               jdks[runtime]['tools']['java'], '-Xverify:all', '-cp', driver_classes,
                               'TestBreakInLoop3Driver', target_root, target_root, work_dir, *dependency['classpath']],
                              f'original-runtime-{profile["profile"]}-{runtime}', runtime)
                if any(work_dir.iterdir()): raise RuntimeError(f'target created a file in isolated runtime cwd: {work_dir}')
                stdout, stderr = artifact(run), artifact(run, 'stderr')
                cell = {'profile': profile['profile'], 'runtime': runtime, 'command': run['index'],
                        'exit_code': run['exit_code'], 'target_root': str(target_root),
                        'application_classpath': [str(driver_classes)],
                        'stdout': compare.pin(Path(run['streams']['stdout']['path'])),
                        'stderr': compare.pin(Path(run['streams']['stderr']['path']))}
                if run['exit_code'] == 0:
                    try:
                        rows8 = parse_oracle(stdout)
                    except (ValueError, UnicodeDecodeError) as error:
                        raise RuntimeError(f'{profile["profile"]}/{runtime}: malformed original oracle: {error}')
                    cell['rows'] = rows8; cell['row_count'] = len(rows8)
                    manual_issues = validate_case_oracle(rows8, planned)
                    cell['manual_oracle_matches'] = not manual_issues; cell['manual_oracle_issues'] = manual_issues
                    # Static expected values are a hypothesis; preserve mismatches as review evidence.
                    semantic_rows.append(oracle_projection(rows8))
                report['original_runtime'].append(cell)
                compare.write_json(out / 'execution.json', report)
        report['check_results_by_runtime'] = {f"{x['profile']}/{x['runtime']}": {key: x.get('rows',[{}])[0].get(field) for key,field in [('result','check_result'),('exception_type','check_exception_type'),('stdout','check_stdout'),('exception_message','check_exception_message')]} for x in report['original_runtime'] if x.get('rows')}
        report['check_jdk23_pass'] = len([x for x in report['original_runtime'] if x.get('runtime') == 'javac23' and x.get('rows') and x['rows'][0].get('check_result') == 'pass']) == 2
        report['runtime_semantic_agreement'] = len(semantic_rows) == 4 and len(report['original_runtime']) == 4 and bool(semantic_rows) and all(x == semantic_rows[0] for x in semantic_rows)
        report['manual_oracle_agreement'] = len(report['original_runtime']) == 4 and all(x.get('manual_oracle_matches') is True for x in report['original_runtime'])
        report['check_runtime_agreement'] = all(len({x.get('rows',[{}])[0].get('check_result') for x in report['original_runtime'] if x.get('runtime') == vm}) == 1 for vm in RUNTIMES)
        compare.write_json(out / 'execution.json', report)
        if report['runtime_semantic_agreement'] is not True:
            raise RuntimeError('original bounded oracle did not complete identically across both profiles and VMs')

        # A deliberately wrong expected CodeSource root proves that the driver checks the loaded origin.
        first_ok = next((x for x in report['source_profiles'] if x['exit_code'] == 0), None)
        if first_ok is not None:
            wrong_cwd = out / 'runtime-cwd' / 'wrong-root'
            wrong_cwd.mkdir(parents=True)
            wrong = command([sys.executable, '-B', runtime_copy, '30', wrong_cwd,
                             jdks['javac23']['tools']['java'], '-Xverify:all', '-cp', driver_classes,
                             'TestBreakInLoop3Driver', Path(first_ok['class_root']).resolve(), empty, wrong_cwd, *dependency['classpath']],
                            'driver-code-source-wrong-root-control', 'javac23')
            if any(wrong_cwd.iterdir()): raise RuntimeError('wrong-root control wrote into its isolated cwd')
            wrong_err = artifact(wrong, 'stderr'); wrong_out = artifact(wrong, 'stdout')
            report['wrong_root_control'] = {
                'command': wrong['index'], 'exit_code': wrong['exit_code'],
                'rejected': wrong['exit_code'] == 1 and b'wrong CodeSource:' in wrong_err,
                'actual_target_root': first_ok['class_root'], 'expected_wrong_root': str(empty),
                'stdout': compare.pin(Path(wrong['streams']['stdout']['path'])),
                'stderr': compare.pin(Path(wrong['streams']['stderr']['path'])),
            }
            if not report['wrong_root_control']['rejected']:
                raise RuntimeError('wrong CodeSource negative control did not reject')

        version = command([JADX, '--version'], 'jadx-version')
        version_text = artifact(version) + artifact(version, 'stderr')
        if version['exit_code'] != 0 or b'1.5.6' not in version_text:
            raise RuntimeError('JADX version mismatch')
        for profile in report['source_profiles']:
            if profile['exit_code'] != 0: continue
            dest_class = Path(profile['class_root'])
            input_jar = Path(profile['bundle']['path'])
            for api_internal, api_role in API_CLASSES:
                target_file = dest_class / (api_internal + '.class')
                for form, input_path, policy in (('child', target_file, 'single-class'),
                                                   ('bundle-child', input_jar, 'plain-jar')):
                    for evidence in EVIDENCE:
                        argv = [cli, 'class-source', '--input', input_path, '--class', api_internal,
                                '--policy', policy, '--release', '8', '--format', 'json']
                        if evidence == 'all': argv += ['--evidence', 'all']
                        row = command(argv, f'jarde-{profile["profile"]}-{api_role}-{form}-{evidence}')
                        raw = artifact(row)
                        dest = out / 'jarde' / profile['profile'] / api_role / form / evidence; dest.mkdir(parents=True)
                        report_path = dest / 'report.json'; report_path.write_bytes(raw)
                        cell = {'profile': profile['profile'], 'api_class': api_internal, 'api_role': api_role,
                                'input_form': form, 'evidence': evidence, 'command': row['index'],
                                'exit_code': row['exit_code'], 'input': compare.pin(input_path),
                                'report': compare.pin(report_path)}
                        try:
                            api = json.loads(raw.decode('utf-8', errors='strict'))
                            whole = dest / 'whole-source.java'; whole.write_bytes(api.get('text', '').encode('utf-8'))
                            summaries = []
                            profile_facts = next(x for x in report['source_profiles'] if x['profile'] == profile['profile'])
                            physical_facts = profile_facts['target_facts']
                            physical_by_key = {(m['name'], m['descriptor']): m for m in physical_facts['methods']}
                            for method in api.get('methods', []):
                                item = method.get('item', {})
                                name = item.get('name', {}).get('escaped'); descriptor = item.get('descriptor', {}).get('escaped')
                                identity = item.get('identity', {}); owner = identity.get('owner', {})
                                physical_method = physical_by_key.get((name, descriptor))
                                outcome = method.get('outcome', {}); body = outcome.get('report', {})
                                summaries.append({'name': name, 'descriptor': descriptor, 'identity': identity,
                                                  'owner': owner, 'location': owner.get('location'), 'variant': owner.get('variant'),
                                                  'outcome_kind': outcome.get('kind'), 'quality': body.get('quality'),
                                                  'fallbacks': body.get('fallbacks'), 'regions': body.get('regions'),
                                                  'raw_text': body.get('text'), 'source_map': body.get('source_map'),
                                                  'map_audit': audit_method_map(method, physical_method) if physical_method else
                                                               {'issues': ['API method does not match a physical method']}})
                            actual_inventory = [(m['name'], m['descriptor']) for m in summaries]
                            expected_inventory = sorted((m['name'], m['descriptor']) for m in physical_facts['methods'])
                            cell.update({'whole_source': compare.pin(whole), 'methods': summaries,
                                         'physical_method_inventory': actual_inventory,
                                         'expected_physical_method_inventory': expected_inventory,
                                         'method_inventory_matches': sorted(actual_inventory) == expected_inventory})
                        except (ValueError, TypeError, UnicodeDecodeError) as error:
                            cell['json_parse_error'] = str(error)
                        report['jarde_cells'].append(cell)
                        compare.write_json(out / 'execution.json', report)

        expected_api_keys = {(p, internal, form, evidence) for p in PROFILES for internal, _ in API_CLASSES
                             for form in ('child', 'bundle-child') for evidence in EVIDENCE}
        api_keys = {(x.get('profile'), x.get('api_class'), x.get('input_form'), x.get('evidence'))
                    for x in report['jarde_cells']}
        if len(report['jarde_cells']) != len(expected_api_keys) or api_keys != expected_api_keys:
            raise RuntimeError(f'expected complete target API grid of {len(expected_api_keys)} cells; got {len(report["jarde_cells"])}')
        # Decode the complete outer+target bundle once per full-source compiler profile.
        for profile in report['source_profiles']:
            if profile['exit_code'] != 0: continue
            bundle = Path(profile['bundle']['path'])
            dest = out / 'jadx' / profile['profile'] / 'default'
            jadx_row = command([JADX, '--threads-count', '1', '--no-res', '--config', 'none',
                                '-d', dest, bundle],
                               'jadx-full-bundle-' + profile['profile'] + '-default')
            sources = [compare.pin(file) for file in sorted(dest.rglob('*.java'))] if dest.exists() else []
            report['jadx_outputs'].append({'compiler_profile': profile['profile'], 'display_profile': 'default',
                                           'input': compare.pin(bundle), 'command': jadx_row['index'],
                                           'exit_code': jadx_row['exit_code'], 'sources': sources})
            compare.write_json(out / 'execution.json', report)
        if len(report['jadx_outputs']) != len(PROFILES):
            raise RuntimeError('full outer+target JADX source capture is incomplete')

        # Rebuild every complete Jarde target source cell and each whole JADX source tree with both configured JDK legs.
        generated_copy_pins = {}
        generated_class_roots = {}
        original_rows_by_key = {(x['profile'], x['runtime']): x['rows'] for x in report['original_runtime']}
        original_facts_by_profile = {x['profile']: {INTERNAL: x['target_facts']} for x in report['source_profiles'] if x.get('target_facts')}

        def copy_java_source(source_path: Path, destination_root: Path, relative_hint: Path | None = None):
            data = source_path.read_bytes()
            if relative_hint is not None:
                relative = relative_hint
            else:
                package_match = re.search(rb'(?m)^\s*package\s+([A-Za-z0-9_.]+)\s*;', data)
                class_match = re.search(rb'(?m)^\s*(?:public\s+)?(?:(?:final|abstract|strictfp)\s+)*class\s+([A-Za-z_$][A-Za-z0-9_$]*)\b', data)
                if class_match is None:
                    raise RuntimeError(f'cannot identify public top-level class in complete source: {source_path}')
                package = package_match.group(1).decode('ascii').replace('.', '/') if package_match else ''
                class_name = class_match.group(1).decode('ascii')
                relative = Path(package) / (class_name + '.java') if package else Path(class_name + '.java')
            destination = destination_root / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            if destination.exists(): raise RuntimeError(f'duplicate generated full-source path: {destination}')
            destination.write_bytes(data)
            if destination.read_bytes() != data: raise RuntimeError('generated full-source copy changed bytes')
            generated_copy_pins[str(destination)] = compare.pin(destination)
            return destination

        generated_source_cells = []
        for cell in report['jarde_cells']:
            profile, form, evidence = cell['profile'], cell['input_form'], cell['evidence']
            source_root = out / 'generated-sources' / 'jarde' / profile / form / evidence
            source_path = out / 'jarde' / profile / 'target' / form / evidence / 'whole-source.java'
            available = source_path.is_file() and bool(source_path.read_bytes().strip())
            copied = copy_java_source(source_path, source_root / 'target') if available else None
            generated_source_cells.append({'kind':'jarde','profile':profile,'form':form,'evidence':evidence,
                'api_roles':['target'],'source_available':available,'source_paths':[str(source_path) if available else None],
                'source_pins':[compare.pin(source_path)] if available else [],
                'api_java_files':[str(copied)] if copied else [],
                'source_copies':[compare.pin(copied)] if copied else [],'source_root':str(source_root),
                'java_files':[str(copied)] if copied else [],'dependency_mode':'selected-target-source',
                'reason':None if available else 'target full-source output unavailable'})
        for output_row in report['jadx_outputs']:
            profile = output_row['compiler_profile']
            original_jadx_root = out / 'jadx' / profile / 'default'
            java_paths = sorted(original_jadx_root.rglob('*.java')) if original_jadx_root.exists() else []
            source_root = out / 'generated-sources' / 'jadx' / profile
            copied = [copy_java_source(path, source_root, path.relative_to(original_jadx_root)) for path in java_paths]
            generated_source_cells.append({'kind': 'jadx', 'profile': profile, 'form': 'whole-outer-target-tree',
                                           'evidence': 'default', 'source_available': bool(copied),
                                           'source_paths': [str(x) for x in java_paths],
                                           'source_pins': [compare.pin(x) for x in java_paths],
                                           'source_copies': [compare.pin(x) for x in copied],
                                           'source_root': str(source_root), 'java_files': [str(x) for x in copied]})

        for source_cell in generated_source_cells:
            profile = source_cell['profile']
            if not source_cell['source_available']:
                continue
            for leg in RUNTIMES:
                dest = out / 'generated-classes' / source_cell['kind'] / profile / str(source_cell.get('form')) / str(source_cell.get('evidence')) / leg
                dest.mkdir(parents=True)
                if leg == 'javac8':
                    debug_arg = '-g' if profile == 'debug' else '-g:none'
                    javac_argv = [jdks[leg]['tools']['javac'], '-source', '8', '-target', '8', debug_arg,
                                  '-encoding', 'UTF-8', '-proc:none', '-classpath', classpath_text,
                                  '-sourcepath', empty, '-d', dest, *source_cell['java_files']]
                else:
                    debug_arg = '-g' if profile == 'debug' else '-g:none'
                    javac_argv = [jdks[leg]['tools']['javac'], '--release', '8', debug_arg,
                                  '-encoding', 'UTF-8', '-proc:none', '-classpath', classpath_text,
                                  '-sourcepath', empty, '-d', dest, *source_cell['java_files']]
                label = f"rebuild-{source_cell['kind']}-{profile}-{source_cell.get('form')}-{source_cell.get('evidence')}-{leg}"
                cr = command(javac_argv, label, leg)
                class_tree = pin_class_tree(dest)
                generated_class_roots[str(dest)] = class_tree
                compile_record = {'kind': source_cell['kind'], 'profile': profile,
                                  'form': source_cell.get('form'), 'evidence': source_cell.get('evidence'),
                                  'compiler': leg, 'command': cr['index'], 'exit_code': cr['exit_code'],
                                  'class_root': str(dest), 'class_tree': class_tree,
                                  'stdout': compare.pin(Path(cr['streams']['stdout']['path'])),
                                  'stderr': compare.pin(Path(cr['streams']['stderr']['path'])),
                                  'source_available': source_cell['source_available'],
                                  'source_paths': source_cell.get('java_files', []),
                                  'runtime_eligible': False, 'class_facts': None, 'class_facts_error': None}
                if cr['exit_code'] == 0:
                    try:
                        facts_by_rel = {}
                        for class_file in sorted(dest.rglob('*.class')):
                            facts_by_rel[class_file.relative_to(dest).as_posix()] = full_class_facts(
                                compare, physical, class_file, f'{source_cell["kind"]}/{profile}/{leg}')
                        compile_record['class_facts'] = facts_by_rel
                        target_facts = facts_by_rel.get(INTERNAL + '.class')
                        compile_record['target_facts'] = target_facts
                        expected_generated_tree = [INTERNAL + '.class'] if source_cell['kind'] == 'jarde' else sorted(SOURCE_CLASS_TREE)
                        if sorted(class_tree) != expected_generated_tree:
                            compile_record['class_facts_error'] = f'complete generated source closure class tree differs: {sorted(class_tree)}'
                        elif target_facts is None or target_facts.get('class_name') != INTERNAL or target_facts.get('major') != 52:
                            compile_record['class_facts_error'] = 'compiled source closure lacks exact Java 8 target binary identity'
                        else:
                            expected = original_facts_by_profile[profile][INTERNAL]
                            try: differences = inventory_metadata_differences(expected, target_facts, INTERNAL)
                            except RuntimeError as error: compile_record['class_facts_error'] = str(error)
                            else:
                                compile_record['allowed_synthetic_flag_differences'] = differences
                                compile_record['runtime_eligible'] = True
                    except Exception as error:
                        compile_record['class_facts_error'] = repr(error)
                report['generated_source_compilations'].append(compile_record)
                compare.write_json(out / 'execution.json', report)
                if cr['exit_code'] != 0 or not compile_record['runtime_eligible']:
                    continue
                for runtime in RUNTIMES:
                    cwd = out / 'generated-runtime-cwd' / source_cell['kind'] / profile / str(source_cell.get('form')) / str(source_cell.get('evidence')) / leg / runtime
                    cwd.mkdir(parents=True)
                    if any(cwd.iterdir()): raise RuntimeError(f'generated runtime cwd is not initially empty: {cwd}')
                    rr = command([sys.executable, '-B', runtime_copy, '30', cwd, jdks[runtime]['tools']['java'],
                                  '-Xverify:all', '-cp', driver_classes, 'TestBreakInLoop3Driver', dest, dest, cwd, *dependency['classpath']],
                                 f"runtime-{source_cell['kind']}-{profile}-{source_cell.get('form')}-{source_cell.get('evidence')}-{leg}-{runtime}", runtime)
                    if any(cwd.iterdir()): raise RuntimeError('generated target wrote into isolated cwd')
                    stdout, stderr = artifact(rr), artifact(rr, 'stderr')
                    rows_out = parse_oracle(stdout) if rr['exit_code'] == 0 else []
                    baseline_rows = original_rows_by_key[(profile, runtime)]
                    case_match = rr['exit_code'] == 0 and oracle_projection(rows_out) == oracle_projection(baseline_rows)
                    check_fields = ('check_result', 'check_exception_type', 'check_exception_message', 'check_stdout', 'check_builder_before', 'check_builder_after')
                    check_match = rr['exit_code'] == 0 and rows_out and baseline_rows and all(rows_out[0].get(k) == baseline_rows[0].get(k) for k in check_fields)
                    combined_match = case_match and check_match
                    runtime_rec = {'kind': source_cell['kind'], 'profile': profile, 'form': source_cell.get('form'),
                                   'evidence': source_cell.get('evidence'), 'compiler': leg, 'runtime': runtime,
                                   'command': rr['index'], 'exit_code': rr['exit_code'], 'class_root': str(dest),
                                   'application_classpath': [str(driver_classes)],
                                   'stdout': compare.pin(Path(rr['streams']['stdout']['path'])),
                                   'stderr': compare.pin(Path(rr['streams']['stderr']['path'])),
                                   'rows': rows_out, 'case_match': case_match, 'check_match': check_match, 'combined_match': combined_match, 'matches_original_oracle': combined_match}
                    report['generated_runtime'].append(runtime_rec)
                    compare.write_json(out / 'execution.json', report)
                wrong_cwd = out / 'generated-runtime-cwd' / source_cell['kind'] / profile / str(source_cell.get('form')) / str(source_cell.get('evidence')) / leg / 'wrong-root'
                wrong_cwd.mkdir(parents=True)
                wrong = command([sys.executable, '-B', runtime_copy, '30', wrong_cwd,
                                 jdks['javac23']['tools']['java'], '-Xverify:all', '-cp', driver_classes,
                                 'TestBreakInLoop3Driver', dest, empty, wrong_cwd, *dependency['classpath']],
                                f"wrong-root-{source_cell['kind']}-{profile}-{source_cell.get('form')}-{source_cell.get('evidence')}-{leg}", 'javac23')
                err = artifact(wrong, 'stderr')
                rejected = wrong['exit_code'] == 1 and b'wrong CodeSource:' in err
                if any(wrong_cwd.iterdir()): raise RuntimeError('generated wrong-root control wrote into isolated cwd')
                report['generated_wrong_root_controls'].append({'kind': source_cell['kind'], 'profile': profile,
                    'form': source_cell.get('form'), 'evidence': source_cell.get('evidence'), 'compiler': leg,
                    'command': wrong['index'], 'exit_code': wrong['exit_code'], 'rejected': rejected,
                    'stdout': compare.pin(Path(wrong['streams']['stdout']['path'])),
                    'stderr': compare.pin(Path(wrong['streams']['stderr']['path']))})
                if not rejected: raise RuntimeError('generated wrong-CodeSource control did not reject')
        report['generated_source_cells'] = generated_source_cells
        report['generated_source_copies'] = [pin for cell in generated_source_cells for pin in cell.get('source_copies', [])]
        report['generated_source_output_pins_before'] = generated_copy_pins
        report['generated_source_output_pins_after'] = {path: compare.pin(Path(path)) for path in generated_copy_pins}
        report['generated_class_trees'] = generated_class_roots
        report['generated_class_trees_after'] = {path: pin_class_tree(Path(path)) for path in generated_class_roots}
        report['generated_outputs_unchanged'] = (
            report['generated_source_output_pins_after'] == generated_copy_pins
            and report['generated_class_trees_after'] == generated_class_roots)
        if not report['generated_outputs_unchanged']:
            raise RuntimeError('generated full-source copies or compiled class trees changed after capture')
        report['generated_source_compilations_derived'] = {
            'source_cells': len(generated_source_cells),
            'compile_attempts': len(report['generated_source_compilations']),
            'compile_successes': sum(x['exit_code'] == 0 for x in report['generated_source_compilations']),
            'compile_failures': sum(x['exit_code'] != 0 for x in report['generated_source_compilations']),
            'runtime_rows': len(report['generated_runtime']),
            'wrong_root_controls': len(report['generated_wrong_root_controls']),
        }

        report['source_pins_after'] = compare.source_closure(root)
        report['source_unchanged'] = report['source_pins_after'] == source_before
        report['local_copy_pins_after'] = {'source_copy': compare.pin(source_copy),
                                           'driver_copy': compare.pin(driver_copy),
                                           'runtime_copy': compare.pin(runtime_copy)}
        report['local_copies_unchanged'] = all(
            report['local_copy_pins_after'][key].get('bytes') == local_copies_before[key].get('bytes')
            and report['local_copy_pins_after'][key].get('sha256') == local_copies_before[key].get('sha256')
            for key in local_copies_before)
        report['external_input_pins_after'] = external_snapshot()
        report['external_inputs_unchanged'] = report['external_input_pins_after'] == external_before
        report['target_absent'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
        if (not report['source_unchanged'] or not report['external_inputs_unchanged']
                or not report['local_copies_unchanged'] or not report['target_absent']):
            raise RuntimeError('source/tool inputs changed or target exists')
        report['counts_derived_from_commands'] = {
            'commands': len(rows), 'raw_streams': 2 * len(rows),
            'javac8_boundary': sum(r['label'] == 'javac8-full-upstream-source-boundary' for r in rows),
            'javac23_full_source_compiles': sum(r['label'].startswith('javac23-full-source-') for r in rows),
            'driver_compiles': sum(r['label'] == 'compile-independent-reflection-driver' for r in rows),
            'original_runtime_runs': sum(r['label'].startswith('original-runtime-') for r in rows),
            'wrong_root_runs': sum(r['label'] == 'driver-code-source-wrong-root-control' for r in rows),
            'generated_source_compiles': sum(r['label'].startswith('rebuild-') for r in rows),
            'generated_runtime_runs': sum(r['label'].startswith('runtime-') for r in rows),
            'generated_wrong_root_runs': sum(r['label'].startswith('wrong-root-') for r in rows),
            'jarde_calls': sum(r['label'].startswith('jarde-') for r in rows),
            'jadx_calls': sum(r['label'].startswith('jadx-') for r in rows),
        }
        report['status'] = 'captured-pending-independent-review'
    except BaseException as error:
        report['status'] = 'failed'; report['error'] = str(error)
        raise
    finally:
        try:
            report['external_input_pins_after_finally'] = external_snapshot()
            report['local_copy_pins_after_finally'] = {'source_copy': compare.pin(source_copy),
                                                       'driver_copy': compare.pin(driver_copy),
                                                       'runtime_copy': compare.pin(runtime_copy)}
            report['local_copies_unchanged_finally'] = all(
                report['local_copy_pins_after_finally'][key].get('bytes') == local_copies_before[key].get('bytes')
                and report['local_copy_pins_after_finally'][key].get('sha256') == local_copies_before[key].get('sha256')
                for key in local_copies_before)
            report['source_pins_after_finally'] = compare.source_closure(root)
            report['source_unchanged_finally'] = report['source_pins_after_finally'] == source_before
            report['target_absent_finally'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
            if (report['external_input_pins_after_finally'] != external_before
                    or not report['local_copies_unchanged_finally']
                    or not report['source_unchanged_finally'] or not report['target_absent_finally']):
                report['status'] = 'failed'; report['final_guard_error'] = 'source/tool pins changed or target exists'
        except BaseException as error:
            report['status'] = 'failed'; report['final_guard_error'] = repr(error)
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out / 'execution.json', report)
        shutil.copy2(__file__, out / 'collector.py')
        print(json.dumps({'status': report['status'], 'commands': len(rows),
                          'runtime_runs': len(report['original_runtime']), 'error': report.get('error')}))

if __name__ == '__main__':
    raise SystemExit(main())
