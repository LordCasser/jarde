#!/usr/bin/env python3
"""Independent, read-only audit of the closed TestDoWhileBreak3 baseline."""
import argparse, base64, hashlib, json, re, zipfile
from pathlib import Path

BASE=Path('/private/tmp/jarde-dowhilebreak3-baseline-root-v1-20261019')
RECEIPT=BASE/'execution.json'
LAUNCH=Path('/private/tmp/jarde-dowhilebreak3-baseline-launch-root-v2-20261019/execution.json')
PREP=Path('/private/tmp/jarde-dowhilebreak3-baseline-prepare-luna-v2-20261019')
EXPECTED_RECEIPT=''
EXPECTED_LAUNCH_COLLECTOR='91cd25d2ce448612570629d1c459c053ba5734e594753631532bd2997ae83063'
EXPECTED_CLI='d29b6fee723d8f59fbecd9fd8be9f15a8ec73de3a90f5a2a29b24ff91e4af607'
CASES=['empty-break','null-first-tail','one-nonnull-exhausted','two-nonnull-exhausted','nonnull-null-tail','null-iterator','hasnext-throws-first','next-throws-first','hasnext-throws-second','next-throws-second']
SEMANTIC_FIELDS=['index','name','result','exception_type','exception_message','target_stdout','has_next_calls','next_calls','event_trace','remaining']

def pin(path):
 p=Path(path); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def require(ok,msg):
 if not ok: raise AssertionError(msg)
def check_pin(rec,label):
 got=pin(rec['path']); require(got['bytes']==rec['bytes'] and got['sha256']==rec['sha256'],f'{label} pin mismatch: {rec["path"]}'); return got
def check_stream(stream,label): return check_pin(stream,label)
def decode64(v):
 return base64.b64decode(v.encode('ascii'),validate=True).decode('utf-8')
def parse_case_line(line):
 require(line.startswith('CASE '),'not a CASE protocol row')
 fields={}
 for atom in line.strip().split()[1:]:
  require('=' in atom,'malformed CASE atom')
  k,v=atom.split('=',1); require(k not in fields,'duplicate CASE key'); fields[k]=v
 required={'index','name','plan_b64','result_b64','exception','exception_message_b64','exception_stack_b64','target_stdout_b64','has_next_calls','next_calls','event_trace_b64','remaining_b64'}
 require(set(fields)==required,'CASE protocol field set changed')
 return {'index':int(fields['index']),'name':fields['name'],'plan':decode64(fields['plan_b64']),'result':decode64(fields['result_b64']),'exception_type':fields['exception'],'exception_message':decode64(fields['exception_message_b64']),'exception_stack':decode64(fields['exception_stack_b64']),'target_stdout':decode64(fields['target_stdout_b64']),'has_next_calls':int(fields['has_next_calls']),'next_calls':int(fields['next_calls']),'event_trace':decode64(fields['event_trace_b64']),'remaining':decode64(fields['remaining_b64'])}
def class_major(path):
 b=Path(path).read_bytes(); require(b[:4]==b'\xca\xfe\xba\xbe','bad class magic: '+str(path)); return int.from_bytes(b[6:8],'big')
def main(out):
 d=json.loads(RECEIPT.read_text()); launch=json.loads(LAUNCH.read_text()); plan=json.loads(Path(d['case_plan']['path']).read_text())
 require(d['schema']=='test-do-while-break3-full-source-baseline-v1','unexpected baseline schema')
 require(d['status']=='captured-pending-independent-review','receipt is not closed for review')
 require(launch['status']=='closed' and launch['exit_code']==0,'launcher not closed successfully')
 require(pin(RECEIPT)['bytes']>0 and pin(LAUNCH)['bytes']>0,'receipt missing')
 collect=check_pin(launch['collector'],'launcher collector')
 require(collect['sha256']==EXPECTED_LAUNCH_COLLECTOR,'collector pin differs from launched collector')
 require(Path(launch['argv'][2])==collect_path(launch),'launcher argv collector mismatch')
 # Frozen preparation inputs, including exact source copy, driver, plan and runtime wrapper.
 plan_pin=check_pin(d['case_plan'],'case plan'); driver_pin=check_pin(d['driver_source'],'driver source'); driver_text=Path(d['driver_source']['path']).read_text(); require('new URLClassLoader(targetUrls(actual), null)' in driver_text and 'target.getClassLoader() != loader' in driver_text and 'wrong CodeSource:' in driver_text,'driver does not enforce parentless target provenance'); source_copy=check_pin(d['source_copy'],'copied outer source')
 upstream=check_pin(d['source'],'upstream outer source')
 require(upstream['sha256']==source_copy['sha256'] and upstream['bytes']==source_copy['bytes'],'upstream source and fixed copy differ')
 require(plan['schema']=='cf09-testdowhilebreak3-source-caseplan-v1' and plan['status']=='source_only_plan_not_executed','unexpected source case plan')
 require(plan['upstream']['commit']=='2fb1b16386941660fda07e9017285aec40fcb37','upstream commit pin mismatch')
 require(plan['source_pins']['TestDoWhileBreak3']['sha256']==source_copy['sha256'] and plan['source_pins']['TestDoWhileBreak3']['bytes']==source_copy['bytes'],'source plan pin mismatch')
 outer=Path(d['source_copy']['path']).read_text()
 require('public class TestDoWhileBreak3 extends IntegrationTest' in outer and 'public static class TestCls' in outer,'outer/target source structure absent')
 require('containsOne("while")' in outer and 'while (this.it.hasNext() && this.it.next() != null) {' in outer,'outer JUnit source assertion was changed')
 require('public void check(' not in outer and 'check()' not in plan['target'].get('check_method',''),'unexpected check helper')
 require(plan['target']['check_method']=='absent','case plan no longer says check absent')
 require(len(plan['cases'])==10 and [c['id'] for c in plan['cases']]==CASES,'source plan case inventory mismatch')
 # Receipt states the source, copied products, tools and build target remained stable.
 for key in ('source_unchanged','local_copies_unchanged_finally','external_inputs_unchanged','target_absent_finally'):
  require(d.get(key) is True,f'receipt integrity flag false: {key}')
 require(d['source_pins_before']==d['source_pins_after_finally'],'source pin snapshots differ')
 require(d['local_copy_pins_before']==d['local_copy_pins_after_finally'],'private input copies changed during run')
 require(d['external_input_pins_before']==d['external_input_pins_after_finally'],'external pins changed during run')
 cli=check_pin(d['cli'],'CLI'); require(cli['sha256']==EXPECTED_CLI and cli['bytes']==64631664,'CLI identity mismatch')
 # All command streams are independent raw evidence; preserve failures and verify every digest.
 commands=d['commands']; require(len(commands)==94,'command count is not 94')
 raw_streams=[]
 for c in commands:
  require(c['index']>=1 and c['index']<=94,'command index out of range')
  for stream_name,stream in c['streams'].items():
   require(stream_name in ('stdout','stderr'),'unexpected stream name')
   raw_streams.append({'index':c['index'],'label':c['label'],'stream':stream_name,**check_stream(stream,f"command {c['index']} {stream_name}")})
 require(len(raw_streams)==188,'raw stream count is not 188')
 launch_raw=[]
 for k,v in launch['streams'].items(): launch_raw.append({'stream':k,**check_stream(v,'launcher '+k)})
 # Verify exact command families and per-API input identities.
 jarde=d['jarde_cells']; require(len(jarde)==8,'Jarde API cell count mismatch')
 require(d['api_method_inventory_expected']==[['<init>','()V'],['test','()V']],'Jarde expected method inventory changed')
 require(d['api_field_inventory_expected']==[['it','Ljava/util/Iterator;',0]],'Jarde expected tuple-shaped field inventory changed')
 expected_api={(p,f,e) for p in ('debug','no-debug') for f in ('child','bundle-child') for e in ('default','all')}
 got_api={(x['profile'],x['input_form'],x['evidence']) for x in jarde}; require(got_api==expected_api,'Jarde API profile/form/evidence matrix mismatch')
 by_label={c['label']:c for c in commands}
 require(sum(c['label'].startswith('jarde-') for c in commands)==8,'Jarde command count mismatch')
 profile_by_name={r['profile']:r for r in d['source_profiles']}
 class_target='jadx/tests/integration/loops/TestDoWhileBreak3$TestCls.class'
 outer_target='jadx/tests/integration/loops/TestDoWhileBreak3.class'
 api_facts=[]; map_methods=0
 for cell in jarde:
  cmd=commands[cell['command']-1]; argv=cmd['argv']
  require('--input' in argv and argv[argv.index('--input')+1]==cell['input']['path'] and '--class' in argv and argv[argv.index('--class')+1]=='jadx/tests/integration/loops/TestDoWhileBreak3$TestCls','Jarde command input/target argv mismatch')
  require(('--evidence' in argv) == (cell['evidence']=='all'),'Jarde default/all evidence argv mismatch')
  require('--release' in argv and argv[argv.index('--release')+1]=='8','Jarde release argv mismatch')
  policy='single-class' if cell['input_form']=='child' else 'plain-jar'
  require('--policy' in argv and argv[argv.index('--policy')+1]==policy and argv[1]=='class-source','Jarde policy/operation argv mismatch')
  require(cell['exit_code']==0 and cell['method_inventory_matches'] is True,'Jarde API failed or inventory mismatch')
  pf=profile_by_name[cell['profile']]
  expected_input=pf['target_facts'] if cell['input_form']=='child' else pf['bundle']
  require(cell['input']['path']==expected_input['path'] and cell['input']['bytes']==expected_input['bytes'] and cell['input']['sha256']==expected_input['sha256'],'Jarde input artifact identity mismatch')
  check_pin(cell['input'],'Jarde input'); check_pin(cell['report'],'Jarde report'); check_pin(cell['whole_source'],'Jarde whole source')
  require(cell['physical_method_inventory']==[['<init>','()V'],['test','()V']],'physical method inventory mismatch')
  require(cell['expected_physical_method_inventory']==[['<init>','()V'],['test','()V']],'expected method inventory mismatch')
  require([(m['name'],m['descriptor']) for m in cell['methods']]==[('<init>','()V'),('test','()V')],'per-method inventory mismatch')
  for m in cell['methods']:
   ma=m['map_audit']; require(m['outcome_kind']=='recovered' and m['quality']=='structured' and not m['fallbacks'],'Jarde method not structured')
   require(ma['map_present'] and not ma['issues'] and ma['covers_all_physical_bcis'] and not ma['unmapped_physical_bcis'],'method map did not cover physical bytecode')
   require(ma['mapped_bcis']==ma['physical_bcis'],'mapped BCI set differs from physical BCI set')
   map_methods+=1
  text=Path(cell['whole_source']['path']).read_text()
  require('public class TestDoWhileBreak3$TestCls' in text and 'public void test()' in text,'Jarde full target source absent')
  require(re.search(r'do\s*\{\s*if\s*\(!this\.it\.hasNext\(\)\)\s*\{\s*break;\s*\}\s*\}\s*while\s*\(this\.it\.next\(\)\s*!=\s*null\);',text) is not None,'Jarde source loop behavior shape absent')
  api_facts.append({'profile':cell['profile'],'form':cell['input_form'],'evidence':cell['evidence'],'input':cell['input'],'method_names':[m['name'] for m in cell['methods']],'fields_from_class_facts':pf['target_facts']['fields'],'maps_complete':True})
 require(map_methods==16,'expected all 8 APIs × 2 method maps')
 # Original and generated physical target facts. The class parser records fields as tuples/lists, not dicts.
 for pf in d['source_profiles']:
  check_pin(pf['target_facts'],'original target class'); check_pin(pf['outer_facts'],'original outer class')
  target=pf['target_facts']; require(target['class_name']=='jadx/tests/integration/loops/TestDoWhileBreak3$TestCls','original target class identity mismatch')
  require(target['fields']==[['it','Ljava/util/Iterator;',0]],'original tuple-shaped field inventory mismatch')
  require([(m['name'],m['descriptor']) for m in target['methods']]==[('<init>','()V'),('test','()V')],'original target method inventory mismatch')
  require(pf['outer_facts']['fields']==[] and [(m['name'],m['descriptor']) for m in pf['outer_facts']['methods']]==[('<init>','()V'),('test','()V')],'original outer field/method inventory mismatch')
  require(target['major']==52,'original target not classfile major 52')
  tree=pf['class_tree']; require(set(tree)=={class_target,outer_target},'original class tree is incomplete or contains extra classes')
  check_pin(tree[class_target],'original nested target'); check_pin(tree[outer_target],'original outer class')
  jar=pf['bundle']; check_pin(jar,'original full class JAR')
  with zipfile.ZipFile(jar['path']) as z:
   require(set(z.namelist())=={class_target,outer_target},'original full JAR entry set mismatch')
   require(z.read(class_target)==Path(tree[class_target]['path']).read_bytes() and z.read(outer_target)==Path(tree[outer_target]['path']).read_bytes(),'original full JAR class bytes differ from fixed profile tree')
 # Compile full upstream source: javac23 succeeds for both profiles; javac8 reports the framework boundary.
 require(d['javac8_full_source_boundary']['exit_code']==1 and d['javac8_full_source_boundary']['major_55_diagnostic_observed'],'expected JDK8 framework version boundary missing')
 bnd=d['javac8_full_source_boundary']; check_stream(bnd['stdout'],'javac8 full source stdout'); err=check_stream(bnd['stderr'],'javac8 full source stderr')
 err_text=Path(bnd['stderr']['path']).read_text(); require('版本 55.0, 应为 52.0' in err_text and 'IntegrationTest.class' in err_text,'JDK8 framework 55/52 diagnostic mismatch')
 require(bnd['class_tree']=={},'JDK8 full-source boundary emitted classes unexpectedly')
 require(len([c for c in commands if c['label'].startswith('javac23-full-source-') and c['exit_code']==0])==2,'JDK23 source compile count mismatch')
 # JUnit source-text assertion is not run; only full source is decompiled, no target spelling gap inferred.
 jadx=d['jadx_outputs']; require(len(jadx)==2 and all(x['exit_code']==0 for x in jadx),'JADX outputs incomplete')
 jadx_facts=[]
 for row in jadx:
  require(len(row['sources'])==1,'JADX output does not contain one complete outer source')
  src=row['sources'][0]; check_pin(src,'JADX complete source'); text=Path(src['path']).read_text()
  require('public class TestDoWhileBreak3 extends IntegrationTest' in text and 'public static class TestCls' in text and 'public void test()' in text,'JADX outer/target source tree absent')
  require('containsOne("while")' in text and 'while (this.it.hasNext() && this.it.next() != null) {' in text,'JADX outer test source assertion/target text changed')
  require(re.search(r'while\s*\(this\.it\.hasNext\(\)\s*&&\s*this\.it\.next\(\)\s*!=\s*null\)',text) is not None,'JADX target while-and condition absent')
  require('do {' not in text,'JADX target shape no longer reflects while-and presentation')
  jadx_facts.append({'profile':row['compiler_profile'],'source':src,'outer_and_nested_target_present':True,'target_presentation':'while (it.hasNext() && it.next() != null)','outer_test_assertion_executed':False})
 # The intended behavior is judged by runtime observations, not whether the pretty-printed loop spells do/while.
 # Reconcile all original and generated CASE lines against captured row fields and their own raw stdout.
 def check_run(run,label):
  require(run['exit_code']==0,'runtime command failed: '+label)
  require(len(run['rows'])==10 and [r['name'] for r in run['rows']]==CASES,'runtime case list/order mismatch: '+label)
  check_stream(run['stdout'],label+' stdout'); check_stream(run['stderr'],label+' stderr')
  text=Path(run['stdout']['path']).read_text(); lines=[x for x in text.splitlines() if x.startswith('CASE ')]
  require(len(lines)==10,'stdout CASE row count mismatch: '+label)
  for row,line in zip(run['rows'],lines):
   require(row['raw']==line,'captured row raw text differs from stdout: '+label)
   parsed=parse_case_line(line)
   for k,v in parsed.items(): require(row[k]==v,f'row field {k} disagrees with raw protocol: {label}/{row["name"]}')
  require(run['application_classpath']==[str(BASE/'driver-classes')],'VM application classpath is not driver-only: '+label)
  command=commands[run['command']-1]; argv=command['argv']
  require(argv[argv.index('-cp')+1]==str(BASE/'driver-classes'),'actual VM argv classpath is not driver-only: '+label)
  driver_at=argv.index('TestDoWhileBreak3Driver')
  target_root=run.get('target_root',run.get('class_root'))
  require(argv[driver_at+1]==target_root and argv[driver_at+2]==target_root,'VM actual and expected CodeSource roots differ: '+label)
  cwd_arg=Path(argv[driver_at+3]); require(cwd_arg.is_dir() and (cwd_arg.is_relative_to(BASE/'runtime-cwd') or cwd_arg.is_relative_to(BASE/'generated-runtime-cwd')) and not any(cwd_arg.iterdir()),'VM working directory is not an empty isolated runtime directory: '+label)
  return True
 orig=d['original_runtime']; require(len(orig)==4,'original VM count mismatch')
 orig_index={}
 for r in orig:
  check_run(r,'original '+r['profile']+'/'+r['runtime']); orig_index[(r['profile'],r['runtime'])]=r
 require(set(orig_index)=={(p,r) for p in ('debug','no-debug') for r in ('javac8','javac23')},'original runtime matrix mismatch')
 require(len(d['generated_runtime'])==36,'generated VM count mismatch')
 sem_mismatches=[]; observation_count=0
 for r in d['generated_runtime']:
  check_run(r,'generated '+r['kind']+'/'+r['profile']+'/'+r['form']+'/'+r['evidence']+'/'+r['compiler']+'/'+r['runtime'])
  oracle=orig_index[(r['profile'],r['runtime'])]
  for expected,actual in zip(oracle['rows'],r['rows']):
   observation_count+=1
   diffs={k:(expected[k],actual[k]) for k in SEMANTIC_FIELDS if expected[k]!=actual[k]}
   if diffs: sem_mismatches.append({'variant':{k:r[k] for k in ('kind','profile','form','evidence','compiler','runtime')},'case':actual['name'],'differences':diffs})
 require(not sem_mismatches,'generated semantic runtime observations differ from same-profile/runtime original oracle')
 require(observation_count==360,'generated runtime case observation count mismatch')
 require(d['runtime_semantic_agreement'] is True,'receipt runtime semantic agreement flag false')
 # Exception stack traces are retained and independently parsed above; source line numbers legitimately vary between emitted sources.
 # Compile each of 10 available whole source variants with both JDKs; two JADX whole-tree JDK8 failures are exact framework/version boundaries.
 src_cells=d['generated_source_cells']; compiles=d['generated_source_compilations']
 require(len(src_cells)==10 and len(compiles)==20,'source/compile matrix size mismatch')
 expected_source_cells={(k,p,f,e) for k in ('jarde',) for p in ('debug','no-debug') for f in ('child','bundle-child') for e in ('default','all')} | {('jadx',p,'whole-outer-child-tree','default') for p in ('debug','no-debug')}
 require({(x['kind'],x['profile'],x['form'],x['evidence']) for x in src_cells}==expected_source_cells,'generated source-cell matrix mismatch')
 for cell in src_cells:
  require(cell['source_available'] is True and len(cell['java_files'])==1,'generated source unavailable or unexpected Java file count')
  if cell['kind']=='jarde':
   sp=check_pin(cell['source_pin'],'generated source'); cp=check_pin(cell['source_copy'],'copied generated source')
   require(sp['sha256']==cp['sha256'] and sp['bytes']==cp['bytes'],'generated source copy differs from source')
   source_copy_path=cell['source_copy']['path']
  else:
   require(len(cell['source_pins'])==1 and len(cell['source_copies'])==1,'JADX source/copy inventory mismatch')
   sp=check_pin(cell['source_pins'][0],'JADX generated source'); cp=check_pin(cell['source_copies'][0],'copied JADX generated source')
   require(sp['sha256']==cp['sha256'] and sp['bytes']==cp['bytes'],'JADX generated source copy differs from source')
   source_copy_path=cell['source_copies'][0]['path']
  text=Path(source_copy_path).read_text(); require('public void test()' in text and 'TestDoWhileBreak3$TestCls' in text,'generated full target source missing')
  if cell['kind']=='jarde': require(re.search(r'do\s*\{\s*if\s*\(!this\.it\.hasNext\(\)\)\s*\{\s*break;',text) is not None,'Jarde source does not preserve do/body-break structure')
  else: require('public class TestDoWhileBreak3 extends IntegrationTest' in text and 'containsOne("while")' in text,'JADX whole source lacks outer class/test')
 success=fail=0; compile_map={}
 for c in compiles:
  key=(c['kind'],c['profile'],c['form'],c['evidence'],c['compiler']); require(key not in compile_map,'duplicate generated compile row'); compile_map[key]=c
  check_stream(c['stdout'],f'compile {c["command"]} stdout'); check_stream(c['stderr'],f'compile {c["command"]} stderr')
  if c['exit_code']==0:
   success+=1; require(c['class_tree'] and c['class_facts_error'] is None,'successful compile has no parsed class inventory')
   for name,fact in c['class_tree'].items():
    require(name in (class_target,outer_target),'unexpected generated class: '+name); check_pin(fact,'generated class '+name)
   facts=c['target_facts']; require(facts['class_name']=='jadx/tests/integration/loops/TestDoWhileBreak3$TestCls','generated target class identity mismatch')
   require(facts['fields']==[['it','Ljava/util/Iterator;',0]],'generated tuple-shaped target fields mismatch')
   require([(m['name'],m['descriptor']) for m in facts['methods']]==[('<init>','()V'),('test','()V')],'generated target method inventory mismatch')
   require(facts['major']==52,'generated target is not classfile major 52')
   if c['kind']=='jarde': require(set(c['class_tree'])=={class_target},'Jarde compile must emit the selected target only')
   else: require(set(c['class_tree'])=={class_target,outer_target},'JADX compile must include complete outer+target tree')
  else:
   fail+=1; require(c['kind']=='jadx' and c['compiler']=='javac8' and c['class_tree']=={},'unexpected generated compilation failure')
   et=Path(c['stderr']['path']).read_text(); require('版本 55.0, 应为 52.0' in et and 'IntegrationTest.class' in et,'JADX JDK8 failure is not the known framework major-version boundary')
 require(success==18 and fail==2,'compile success/failure totals mismatch')
 # Wrong-root runs prove eager source identity checks fire before using the target; all retain their raw errors.
 wrong=d['generated_wrong_root_controls']; require(len(wrong)==18,'generated wrong-root control count mismatch')
 for w in wrong:
  require(w['exit_code']==1 and w['rejected'] is True,'wrong-root control was not rejected')
  check_stream(w['stdout'],'wrong-root stdout'); check_stream(w['stderr'],'wrong-root stderr')
  c=commands[w['command']-1]; err=Path(w['stderr']['path']).read_text()
  require('wrong CodeSource:' in err and 'expected=' in err and 'actual=' in err,'wrong-root rejection reason mismatch')
  require(c['argv'][c['argv'].index('-cp')+1]==str(BASE/'driver-classes'),'wrong-root control application classpath not driver-only')
  at=c['argv'].index('TestDoWhileBreak3Driver')
  compile_row=next(x for x in compiles if x['kind']==w['kind'] and x['profile']==w['profile'] and x['form']==w['form'] and x['evidence']==w['evidence'] and x['compiler']==w['compiler'])
  require(c['argv'][at+1]==compile_row['class_root'] and c['argv'][at+2]==str(BASE/'empty-classpath'),'wrong-root target/expected roots mismatch')
  require('actual='+compile_row['class_root'] in err and 'expected='+str(BASE/'empty-classpath') in err,'wrong-root diagnostic does not name pinned physical roots')
 # The top-level original wrong-root control must reject the same physical-source mismatch.
 w=d['wrong_root_control']; require(w['exit_code']==1 and w['rejected'] is True,'original wrong-root control did not reject')
 check_stream(w['stdout'],'original wrong-root stdout'); check_stream(w['stderr'],'original wrong-root stderr')
 orig_err=Path(w['stderr']['path']).read_text(); require('wrong CodeSource:' in orig_err,'original wrong-root rejection reason mismatch')
 require('actual='+d['source_profiles'][0]['class_root'] in orig_err and 'expected='+str(BASE/'empty-classpath') in orig_err,'original wrong-root diagnostic does not name pinned roots')
 # Pin the static framework dependency's actual classfile major, without invoking Java.
 with zipfile.ZipFile(d['dependency_harness_jar']['path']) as z:
  integration=z.read('jadx/tests/api/IntegrationTest.class')
 require(integration[:4]==b'\xca\xfe\xba\xbe' and int.from_bytes(integration[6:8],'big')==55,'pinned IntegrationTest classfile major is not 55')
 check_pin(d['dependency_harness_jar'],'harness JAR')
 # Counts are independently derived rather than trusted as a summary alone.
 labels={c['label'] for c in commands}
 derived={'commands':len(commands),'raw_streams':len(raw_streams),'jarde_calls':sum(c['label'].startswith('jarde-') for c in commands),'jadx_calls':sum(c['label'].startswith('jadx-full-bundle-') for c in commands),'original_runtime_runs':len(orig),'wrong_root_runs':1,'generated_source_compiles':len(compiles),'generated_runtime_runs':len(d['generated_runtime']),'generated_wrong_root_runs':len(wrong),'runtime_observations':observation_count,'compile_successes':success,'compile_failures':fail}
 require(d['counts_derived_from_commands']['commands']==94 and d['counts_derived_from_commands']['raw_streams']==188,'receipt-derived count mismatch')
 report={'schema':'test-dowhilebreak3-independent-review-v1','status':'passed','receipt':pin(RECEIPT),'launcher':{'receipt':pin(LAUNCH),'collector':collect,'streams':launch_raw,'exit_code':launch['exit_code']},'preparation_inputs':{'case_plan':plan_pin,'source_copy':source_copy,'upstream_source':upstream,'driver_source':driver_pin,'runtime_wrapper':check_pin(d['runtime_wrapper'],'runtime wrapper')},'integrity':{'source_unchanged':d['source_unchanged'],'local_copies_unchanged_finally':d['local_copies_unchanged_finally'],'external_inputs_unchanged':d['external_inputs_unchanged'],'target_absent_finally':d['target_absent_finally'],'cli':cli},'command_and_raw_inventory':{'commands':len(commands),'raw_streams':len(raw_streams),'raw_pins':raw_streams,'jarde_calls':derived['jarde_calls'],'jadx_calls':derived['jadx_calls']},'original_class_facts':{'profiles':[{'profile':k['profile'],'class_tree':k['class_tree'],'target_fields_tuple_inventory':k['target_facts']['fields'],'target_methods':[(m['name'],m['descriptor']) for m in k['target_facts']['methods']]} for k in d['source_profiles']],'bundle_entry_sets_checked':True},'jarde_api_matrix':{'cells':len(api_facts),'structured_methods':map_methods,'apis':api_facts,'all_physical_maps_complete':True},'jadx_outputs':jadx_facts,'compilation':{'full_source_javac23_successes':2,'full_source_javac8_boundary':{'exit_code':bnd['exit_code'],'diagnostic':'IntegrationTest.class is major 55; javac8 expects 52','class_tree':bnd['class_tree']},'generated_compile_attempts':20,'generated_compile_successes':success,'generated_compile_failures':fail,'jdk8_jadx_failures_are_framework_boundary':True,'javac23_jadx_full_tree_successes':2},'runtime':{'original_vms':len(orig),'original_cases':40,'generated_vms':len(d['generated_runtime']),'generated_cases':observation_count,'generated_wrong_root_controls':len(wrong),'case_names':CASES,'semantic_fields_compared':SEMANTIC_FIELDS,'semantic_mismatches':sem_mismatches,'exception_stack_traces_retained_and_raw_verified':True,'driver_only_application_classpath_verified':True},'interpretation':{'Jarde':'Structured equivalent source uses do { if (!hasNext) break; } while (next() != null).','JADX':'Complete outer/target source uses while (hasNext() && next() != null); this different spelling is not treated as a semantic gap.','outer_junit':'The outer source assertion containsOne("while") plus exact while-and text; it was not executed as part of this baseline.','oracle':'Only the compiled original TestCls VM runs are treated as oracle; generated VMs were compared by return/exception/message/stdout/call sequence/counts/remaining values. Exception stacks remain separately preserved because generated source line numbers differ.','check':'No check() helper exists; none was injected or run.','boundary':'JDK8 full-source compilation is blocked by the pinned major-55 IntegrationTest framework class while javac8 supports major 52; this boundary is recorded as failure, not success.','scope':'Read-only Python audit of closed receipts and files; no toolchain execution.'},'derived_counts':derived}
 out=Path(out); out.mkdir(parents=True,exist_ok=True); (out/'review.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'status':report['status'],'review':str(out/'review.json'),'commands':len(commands),'raw':len(raw_streams),'apis':len(api_facts),'original_cases':40,'generated_cases':observation_count,'compile_successes':success,'compile_failures':fail,'wrong_root':len(wrong)},ensure_ascii=False))
def collect_path(launch):
 return Path(launch['collector']['path'])
if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--out',default='/private/tmp/jarde-dowhilebreak3-independent-review-luna-v1-20261019'); args=ap.parse_args(); main(args.out)
