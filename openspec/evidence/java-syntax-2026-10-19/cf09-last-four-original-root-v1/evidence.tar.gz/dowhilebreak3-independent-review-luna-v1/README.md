# TestDoWhileBreak3 independent baseline audit

This is a read-only audit of the closed `test-do-while-break3-full-source-baseline-v1` capture. It checks all 94 command records and 188 individual raw stream pins, the closed launcher and collector pin, fixed source/driver/case-plan copies, CLI identity, class trees, full-JAR entries, all eight Jarde API combinations, physical method and field inventories, per-method maps, complete JADX source outputs, compilation outcomes, and VM observations.

Rerun with Python's standard library only:

```sh
python3 -B /private/tmp/jarde-dowhilebreak3-independent-review-luna-v1-20261019/audit.py
```

The auditor writes `review.json` in this directory and exits nonzero if a pinned input or checked property changes. It does not launch Java, JADX, Jarde, Cargo, or Git.

The original compiled `TestCls` observations are the runtime oracle. Each of the 4 original VMs contributes 10 case rows; each of 36 successful generated VMs contributes the same 10 rows. The audit compares return/exception type and message/stdout, iterator calls and order, and remaining values. It retains and parses exception stack traces but does not compare source line numbers across generated forms.

Jarde's structured source uses `do { if (!hasNext) break; } while (next() != null)`. JADX presents the target as `while (hasNext() && next() != null)`. These spellings are not treated as a semantic discrepancy; the controlled runtime case matrix supplies the behavior comparison. The outer JUnit assertion is source text only and was not executed, and no `check()` helper exists.

JDK 8 full-source compilation failures are preserved as framework boundaries: `IntegrationTest.class` is classfile major 55 while javac8 expects major 52. The two JDK 8 JADX whole-tree failures are the same boundary, not successful compilations. The generated target class compiles with JDK 8 and JDK 23 across the eight Jarde APIs and the JDK 23 JADX full-tree cases.
