#!/usr/bin/env python3
"""Read-only independent audit for the frozen BreakInLoop6 Smali/DEX capture."""
import argparse, hashlib, json, re, struct, zipfile, zlib
from pathlib import Path

MAIN = Path('/private/tmp/jarde-breakinloop6-boundary-root-v1-20261019/execution.json')
SUPP = Path('/private/tmp/jarde-breakinloop6-inventory-supplement-root-v1-20261019/execution.json')
RUN = Path('/private/tmp/jarde-breakinloop6-boundary-tools-root-v1-20261019/run.py')
EXPECTED = {
 'main_sha256':'3affe711934956f0c38b5bb92deed4642e0ed54f62dfb1e2c367a38ab6c31664',
 'supp_sha256':'8441f09e360fcbe34f8942dbfacc1288224ff2cd9417fc4727861e559a942c41',
 'run_sha256':'1ceefe308c221789954dac0160d6eac1541b21dbcbebd608636baab27ce537f7',
 'smali':'573f2a2329cebe8ac6aec6af5ec40ecab683eb95a37515470a512bad63ea8c16',
 'outer':'6b59880e867a7b2c60437233448a65e1f12553154ce15210d606327a98ceada3',
 'dex':'9321ba1f6a9b8c09337a5c7d00a0b5036327c7f735ceed66be3ca1adf3bb60a5',
 'jar':'e59b7184464e08d73a9aea31872a64a21a244a457f0d2488d9963657f704b230',
 'jadx_smali':'ae3be0004f7bf4ca9914f704a7416a8010bf533a93c4fe140e8760b82fad913f',
 'jadx_dex':'37ff806fa80edddc21657eff54a9b81bac9babe9c138820c99ac321fd4eed393',
}

def pin(path):
 p=Path(path); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def need(ok, msg):
 if not ok: raise AssertionError(msg)
def uleb(b, off):
 value=shift=0
 while True:
  x=b[off]; off+=1; value|=(x&127)<<shift
  if not x&128: return value,off
  shift+=7
  if shift>35: raise ValueError('bad ULEB128')
def dex_summary(data):
 need(data[:8]==b'dex\n035\0','unexpected DEX magic/version')
 checksum=struct.unpack_from('<I',data,8)[0]
 file_size,header_size,endian=struct.unpack_from('<III',data,32)
 need(file_size==len(data) and header_size==0x70 and endian==0x12345678,'DEX header size/endian mismatch')
 need(checksum==zlib.adler32(data[12:])&0xffffffff,'DEX Adler-32 mismatch')
 signature=data[12:32].hex(); need(signature==hashlib.sha1(data[32:]).hexdigest(),'DEX SHA-1 signature mismatch')
 string_n,string_off=struct.unpack_from('<II',data,56)
 type_n,type_off=struct.unpack_from('<II',data,64)
 proto_n,proto_off=struct.unpack_from('<II',data,72)
 field_n,field_off=struct.unpack_from('<II',data,80)
 method_n,method_off=struct.unpack_from('<II',data,88)
 class_n,class_off=struct.unpack_from('<II',data,96)
 map_off=struct.unpack_from('<I',data,52)[0]
 def string_at(off):
  _,q=uleb(data,off); end=data.index(0,q); return data[q:end].decode('utf-8','replace')
 strings=[]
 for i in range(string_n): strings.append(string_at(struct.unpack_from('<I',data,string_off+4*i)[0]))
 types=[]
 for i in range(type_n): types.append(strings[struct.unpack_from('<I',data,type_off+4*i)[0]])
 protos=[]
 for i in range(proto_n):
  shorty,ret,params=struct.unpack_from('<III',data,proto_off+12*i)
  protos.append(types[ret])
 fields=[]
 for i in range(field_n):
  cls,typ,name=struct.unpack_from('<HHI',data,field_off+8*i); fields.append((types[cls],strings[name],types[typ]))
 methods=[]
 for i in range(method_n):
  cls,proto,name=struct.unpack_from('<HHI',data,method_off+8*i); methods.append((types[cls],strings[name],protos[proto]))
 classes=[]
 for i in range(class_n):
  cls,access,super_idx,interfaces,source,annotations,class_data,static_values=struct.unpack_from('<8I',data,class_off+32*i)
  classes.append({'descriptor':types[cls],'access':access,'super':types[super_idx] if super_idx!=0xffffffff else None,'class_data_off':class_data})
 need(len(classes)==1 and classes[0]['descriptor']=='Lloops/TestBreakInLoop6;','unexpected DEX class definitions')
 cd=classes[0]['class_data_off']; sf,inf,dm,vm=0,0,0,0
 sf,cd=uleb(data,cd); inf,cd=uleb(data,cd); dm,cd=uleb(data,cd); vm,cd=uleb(data,cd)
 for _ in range(sf+inf):
  _,cd=uleb(data,cd); _,cd=uleb(data,cd)
 encoded=[]
 for kind,count in [('direct',dm),('virtual',vm)]:
  idx=0
  for _ in range(count):
   diff,cd=uleb(data,cd); idx+=diff; access,cd=uleb(data,cd); codeoff,cd=uleb(data,cd)
   encoded.append({'kind':kind,'method_id':idx,'access':access,'code_off':codeoff})
 need(len(encoded)==1 and encoded[0]['method_id']<len(methods),'unexpected encoded method inventory')
 method=methods[encoded[0]['method_id']]
 need(method==('Lloops/TestBreakInLoop6;','test','J'),'unexpected target DEX method')
 co=encoded[0]['code_off']; regs,ins,outs,tries=struct.unpack_from('<HHHH',data,co); dbg,insns=struct.unpack_from('<II',data,co+8)
 code_units=struct.unpack_from('<'+'H'*insns,data,co+16)
 need(regs==19 and ins==1 and outs==3 and tries==0 and len(code_units)==65,'unexpected method code item shape')
 need(('Ltest/Test;','h','J') in methods and ('Ltest/Test;','f','J') in methods,'expected unresolved test.Test interface calls absent')
 need(('Ltest/Test;','j','[Ltest/Test;') in fields and ('Ltest/Test;','i','[Ltest/Test;') in fields,'expected DEX fields absent')
 return {'magic':data[:8].decode('ascii','replace'),'checksum_adler32':f'{checksum:08x}','computed_adler32':f'{zlib.adler32(data[12:])&0xffffffff:08x}','signature_sha1':signature,'computed_signature_sha1':hashlib.sha1(data[32:]).hexdigest(),'file_size':file_size,'header_size':header_size,'endian_tag':f'{endian:08x}','map_off':map_off,'counts':{'strings':string_n,'types':type_n,'protos':proto_n,'fields':field_n,'methods':method_n,'class_defs':class_n},'classes':classes,'fields':fields,'methods':methods,'target_method':{'signature':method,'access':encoded[0]['access'],'code_off':co,'registers':regs,'ins':ins,'outs':outs,'tries':tries,'debug_info_off':dbg,'instruction_code_units':insns,'instruction_units_hex':[f'{u:04x}' for u in code_units]},'unresolved_test_Test_defined_in_input_dex':False}
def main(out):
 main_doc=json.loads(MAIN.read_text()); supp=json.loads(SUPP.read_text())
 need(pin(MAIN)['sha256']==EXPECTED['main_sha256'],'main receipt pin changed')
 need(pin(SUPP)['sha256']==EXPECTED['supp_sha256'],'supplement receipt pin changed')
 need(pin(RUN)['sha256']==EXPECTED['run_sha256'],'runner script pin changed')
 need(main_doc['schema']=='cf09-original-breakinloop6-smali-dex-boundary-v1','main schema mismatch')
 need(main_doc['source_unchanged'] and main_doc['tools_unchanged'] and main_doc['target_absent'],'capture source/tool/target integrity assertions not satisfied')
 need(main_doc['source_before']==main_doc['source_after'] and main_doc['tools_before']==main_doc['tools_after'],'receipt before/after source or tool pins differ')
 checks=[]
 # Input copies are bound to the original upstream paths declared by the exact runner.
 run_txt=RUN.read_text()
 originals=[('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/smali/loops/TestBreakInLoop6.smali',main_doc['input'][0],EXPECTED['smali']),('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestBreakInLoop6.java',main_doc['input'][1],EXPECTED['outer'])]
 for orig,item,sha in originals:
  op=pin(orig); cp=pin(item['path']); mode=Path(item['path']).stat().st_mode & 0o777
  need(op['sha256']==sha and cp['sha256']==sha and op['bytes']==cp['bytes'],'original/copy content pin mismatch: '+orig)
  need(f"shutil.copy2(UPSTREAM/'{ 'smali/loops/TestBreakInLoop6.smali' if orig.endswith('.smali') else 'java/jadx/tests/integration/loops/TestBreakInLoop6.java' }'" in run_txt,'runner copy path/operation not found')
  checks.append({'original':op,'fixed_copy':cp,'copy_mode_octal':oct(mode),'contents_equal':True})
 need(len(main_doc['commands'])==10,'main command count mismatch')
 raw_pins=[]
 for c in main_doc['commands']:
  for stream in ('stdout','stderr'):
   rec=c['streams'][stream]; observed=pin(rec['path']); need(observed['bytes']==rec['bytes'] and observed['sha256']==rec['sha256'],f"raw pin mismatch {c['index']} {stream}")
   raw_pins.append({'command_index':c['index'],'label':c['label'],'stream':stream,**observed})
 for c in supp['commands']:
  for stream in ('stdout','stderr'):
   rec=c['streams'][stream]; observed=pin(rec['path']); need(observed['bytes']==rec['bytes'] and observed['sha256']==rec['sha256'],f"supplement raw pin mismatch {c.get('argv')} {stream}")
   raw_pins.append({'supplement_argv':c['argv'],'stream':stream,**observed})
 dex_pin=pin(main_doc['dex']['path']); need(dex_pin['bytes']==main_doc['dex']['bytes'] and dex_pin['sha256']==EXPECTED['dex'],'assembled DEX pin mismatch')
 dex_data=Path(dex_pin['path']).read_bytes(); dex_facts=dex_summary(dex_data)
 jar_pin=pin(main_doc['dex_only_jar']['path']); need(jar_pin['bytes']==main_doc['dex_only_jar']['bytes'] and jar_pin['sha256']==EXPECTED['jar'],'DEX-only JAR pin mismatch')
 with zipfile.ZipFile(main_doc['dex_only_jar']['path']) as z:
  names=z.namelist(); need(names==['classes.dex'],'unexpected DEX JAR members')
  jar_dex=z.read('classes.dex'); need(jar_dex==dex_data,'JAR classes.dex differs from assembled DEX')
 # JADX full-source evidence.
 jadx_facts=[]
 expected_by_input={'smali':EXPECTED['jadx_smali'],'dex':EXPECTED['jadx_dex']}
 for row in main_doc['jadx_outputs']:
  need(len(row['sources'])==1,'JADX source output not a single complete source file')
  rec=row['sources'][0]; observed=pin(rec['path']); need(observed['bytes']==rec['bytes'] and observed['sha256']==expected_by_input[row['input']],'JADX source pin mismatch')
  source=Path(rec['path']).read_text()
  breaks=len(re.findall(r'\bbreak\b',source)); continues=len(re.findall(r'\bcontinue\b',source))
  need(breaks==1 and continues==0,f"unexpected JADX break/continue count for {row['input']}")
  need('class TestBreakInLoop6' in source and 'test()' in source,'JADX output does not include complete target class/method')
  jadx_facts.append({'input':row['input'],'source':observed,'break_statement_tokens':breaks,'continue_statement_tokens':continues,'complete_target_source_present':True})
 # Four unsupported raw-artifact invocations and two valid JAR target misses.
 class_cmds=main_doc['commands'][3:9]
 codes=[]
 for i,c in enumerate(class_cmds,4):
  raw=Path(c['streams']['stderr']['path']).read_text()
  parsed=json.loads(raw)
  code=parsed['error']['code']; codes.append(code)
  if i in (4,5,6,7): need(code=='unknown_artifact_kind' and parsed['usage']['input_bytes'] in (1216,788),f'raw Smali/DEX classification mismatch at command {i}')
  else: need(code=='operation_target_not_found' and 'loops/TestBreakInLoop6' in parsed['error']['message'],f'JAR target miss mismatch at command {i}')
 need(codes.count('unknown_artifact_kind')==4 and codes.count('operation_target_not_found')==2,'unexpected product result counts')
 bad=main_doc['commands'][9]; bad_stderr=Path(bad['streams']['stderr']['path']).read_text()
 need(bad['label']=='jarde-dex-only-jar-inventory' and "unexpected argument '--policy'" in bad_stderr,'invalid inventory command/raw not preserved')
 need('--policy' in bad['argv'] and bad['exit_code']==2,'invalid inventory argv record was changed')
 need(str(supp['supersedes_only_invalid_inventory_argv']).startswith('boundary-root-v1 command 10;') and supp['target_absent'] is True,'supplement scope/integrity mismatch')
 inv=supp['commands'][1]; invout=Path(inv['streams']['stdout']['path']).read_text(); invargs=inv['argv']
 need(inv['exit_code']==0 and '--policy' not in invargs and '--release' not in invargs and '--format' not in invargs,'corrected inventory invocation still has unsupported switches')
 need('candidates = 0' in invout and 'items = []' in invout and 'unconfirmed = []' in invout,'correct inventory did not report zero candidates')
 # Static proof only: local v1 starts at 1; sole write is nested under v1 == 2 guard.
 outer_text=Path(main_doc['input'][1]['path']).read_text()
 need('disableCompilation();' in outer_text and '.code().containsOne(\"break\")' in outer_text,'outer source does not preserve the disabled-compilation break assertion')
 smali_text=Path(main_doc['input'][0]['path']).read_text()
 need('const-wide v1, 0x1L' in smali_text,'v1 initialization anchor absent')
 write='move-wide v1, v8'; need(smali_text.count(write)==1,'unexpected v1 write inventory')
 need(re.search(r'cmp-long v13, v1, v11\s+if-nez v13, :cond_4e\s+move-wide v1, v8',smali_text) is not None,'v1 write guard adjacency changed')
 need('const-wide v11, 0x2L' in smali_text,'guard constant anchor absent')
 # Constrained artifact fact: no definition of test.Test exists in the only DEX class inventory.
 need(dex_facts['unresolved_test_Test_defined_in_input_dex'] is False,'input unexpectedly defines test.Test')
 report={'schema':'breakinloop6-independent-boundary-review-v1','status':'passed','inputs':{'main_receipt':pin(MAIN),'supplement_receipt':pin(SUPP),'runner':pin(RUN)},'receipt_statuses':{'main':main_doc['status'],'supplement':supp['status'],'source_unchanged':main_doc['source_unchanged'],'tools_unchanged':main_doc['tools_unchanged'],'target_absent':main_doc['target_absent']},'fixed_inputs':checks,'raw_streams':raw_pins,'dex':{'pin':dex_pin,**dex_facts},'dex_only_jar':{'pin':jar_pin,'members':names,'classes_dex_equal':True},'jadx':jadx_facts,'jarde_results':{'unknown_artifact_kind_count':4,'operation_target_not_found_count':2,'commands_4_to_9_codes':codes,'invalid_inventory_command_10':{'argv':bad['argv'],'exit_code':bad['exit_code'],'stderr':bad_stderr.strip(),'treated_as_product_boundary':False},'corrected_inventory_supplement':{'argv':invargs,'exit_code':inv['exit_code'],'candidate_count':0,'stdout':invout.strip()}},'static_smali_reasoning':{'initialization':'v1 is initialized to 1 before the outer loop.','only_write':write,'guard':'The write is reached only after comparing v8 with 2 (the preceding if-eqz skips when equal) and comparing v1 with 2 (if-nez skips unless equal).','induction':'Assuming v1 is 1 at an outer-loop iteration, the second guard prevents the only write, so v1 remains 1; by induction v1 never becomes 2 and the nested-loop body is unreachable in this method.','scope':'Static reasoning over the supplied Smali; no VM execution was performed.','framework':'The supplied DEX defines only loops/TestBreakInLoop6 and refers to Ltest/Test; it contains no definition of test.Test. This is a limitation of this input artifact, not a claim about JVM class-file validity or compile-ability.','upstream_test':'The fixed outer JUnit source calls disableCompilation() and asserts containsOne(\"break\"); it is an output-shape assertion, and its assertion is not reported as executed by this audit.'},'acceptance_boundary':'This review audits a captured Smali/DEX artifact and CLI boundaries. It makes no claim that the Smali can compile to a JVM class, and no Dex product recovery plan is asserted.'}
 out=Path(out); out.mkdir(parents=True,exist_ok=True)
 dest=out/'review.json'; dest.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'status':report['status'],'review':str(dest),'raw_streams':len(raw_pins),'dex_method':dex_facts['target_method']['signature'],'breaks':[x['break_statement_tokens'] for x in jadx_facts],'continues':[x['continue_statement_tokens'] for x in jadx_facts]},ensure_ascii=False))
if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--out',default='/private/tmp/jarde-breakinloop6-independent-review-luna-v1-20261019'); a=ap.parse_args(); main(a.out)
