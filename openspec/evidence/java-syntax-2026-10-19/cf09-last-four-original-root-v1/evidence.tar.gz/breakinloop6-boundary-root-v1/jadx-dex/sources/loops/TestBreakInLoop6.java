package loops;

import test.Test;

/* JADX INFO: loaded from: /private/tmp/jarde-breakinloop6-boundary-root-v1-20261019/original.dex */
public class TestBreakInLoop6 {
    public long test() {
        long j = 1;
        for (Test test : ((Test) this).j) {
            long jH = test.h();
            if (jH != 2 && j == 2) {
                j = jH;
                for (Test test2 : ((Test) this).i) {
                    if (test2 == test) {
                        break;
                    }
                    if (test2.f(j) != j) {
                        throw new IllegalStateException();
                    }
                }
            }
        }
        return j;
    }
}
