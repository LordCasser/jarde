import hashlib, importlib.util, json, os, shutil, zipfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
OUT = Path('/private/tmp/jarde-breakinloop6-boundary-root-v1-20261019')
CLI = Path('/private/tmp/jarde-loop45-final-focused-root-v4-20261019/candidate-cli')
UPSTREAM = Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test')
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

compare = load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py', 'compare')
guard = load(ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py', 'guard')
scanner = load(ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py', 'scanner')
assert not OUT.exists() and not (ROOT/'target').exists()
assert compare.pin(CLI)['sha256'] == 'd29b6fee723d8f59fbecd9fd8be9f15a8ec73de3a90f5a2a29b24ff91e4af607'
OUT.mkdir(); (OUT/'raw').mkdir(); (OUT/'input').mkdir()
guard.ROOT = ROOT; guard.OUT = OUT/'raw'; guard.target_bytes = lambda: scanner.target_bytes(ROOT)
guard.command_stream = compare.pin; guard.expected_test_summaries = lambda index, data: None
jdks, jdk_record = compare.configured_jdks(ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json', 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
smali = OUT/'input/TestBreakInLoop6.smali'
outer = OUT/'input/TestBreakInLoop6.java'
shutil.copy2(UPSTREAM/'smali/loops/TestBreakInLoop6.smali', smali)
shutil.copy2(UPSTREAM/'java/jadx/tests/integration/loops/TestBreakInLoop6.java', outer)
assert compare.pin(smali)['sha256'] == '573f2a2329cebe8ac6aec6af5ec40ecab683eb95a37515470a512bad63ea8c16'
assert compare.pin(outer)['sha256'] == '6b59880e867a7b2c60437233448a65e1f12553154ce15210d606327a98ceada3'
tools = [CLI, JADX, JAR, Path(__file__), smali, outer, ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py', ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py', ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py', *jdks['javac23']['tools'].values()]
before = compare.source_closure(ROOT); pins_before = [compare.pin(p) for p in tools]
report = {'schema': 'cf09-original-breakinloop6-smali-dex-boundary-v1', 'status': 'running', 'source_before': before, 'tools_before': pins_before, 'jdk': jdk_record, 'commands': [], 'input': [compare.pin(smali), compare.pin(outer)], 'runtime': {'executed': False, 'reason': 'Original is a Smali output-shape test with disableCompilation(); no JVM class/JAR or executable oracle is substituted.'}}
def save(): compare.write_json(OUT/'execution.json', report)
def command(args, label):
    assert not (ROOT/'target').exists()
    env = compare.clean_env(dict(os.environ), jdks['javac23']); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK', None)
    row = guard.run_command(len(report['commands'])+1, list(map(str, args)), env)
    row['label'] = label; report['commands'].append(row); save()
    assert row.get('guard_stop') is None, row
    return row
save()
try:
    dex = OUT/'original.dex'
    assembled = command([jdks['javac23']['tools']['java'], '-cp', JAR, 'com.android.tools.smali.smali.Main', 'assemble', smali, '-o', dex], 'assemble-original-smali-to-dex')
    assert assembled['exit_code'] == 0 and dex.is_file()
    report['dex'] = compare.pin(dex)
    bundle = OUT/'dex-only.jar'
    with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_STORED) as z: z.write(dex, 'classes.dex')
    report['dex_only_jar'] = compare.pin(bundle)
    for name, path in [('smali', smali), ('dex', dex)]:
        dest = OUT/('jadx-'+name)
        command([JADX, '--threads-count', '1', '--no-res', '--config', 'none', '-d', dest, path], 'jadx-original-'+name)
        report.setdefault('jadx_outputs', []).append({'input': name, 'sources': [compare.pin(p) for p in sorted(dest.rglob('*.java'))]})
    for name, path, policy in [('smali', smali, 'single-class'), ('dex', dex, 'single-class'), ('dex-only-jar', bundle, 'plain-jar')]:
        for evidence in ['default', 'all']:
            args = [CLI, 'class-source', '--input', path, '--class', 'loops/TestBreakInLoop6', '--policy', policy, '--release', '8', '--format', 'json']
            if evidence == 'all': args += ['--evidence', 'all']
            command(args, 'jarde-'+name+'-'+evidence)
    command([CLI, 'list-classes', '--input', bundle, '--policy', 'plain-jar', '--release', '8', '--format', 'json'], 'jarde-dex-only-jar-inventory')
    report['status'] = 'captured_pending_boundary_review'
finally:
    report['source_after'] = compare.source_closure(ROOT)
    report['source_unchanged'] = before == report['source_after']
    report['tools_after'] = [compare.pin(p) for p in tools]
    report['tools_unchanged'] = pins_before == report['tools_after']
    report['target_absent'] = not (ROOT/'target').exists()
    save()
    assert report['source_unchanged'] and report['tools_unchanged'] and report['target_absent']
print(json.dumps({'status': report['status'], 'commands': len(report['commands']), 'output': str(OUT)}))
