import hashlib, json, subprocess, sys
from pathlib import Path

collector, destination, launch = map(Path, sys.argv[1:4])
assert not launch.exists()
launch.mkdir()
argv = [sys.executable, '-B', str(collector), '--out', str(destination), '--cli', '/private/tmp/jarde-loop45-final-focused-root-v4-20261019/candidate-cli', '--cli-sha256', 'd29b6fee723d8f59fbecd9fd8be9f15a8ec73de3a90f5a2a29b24ff91e4af607']
def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
with (launch/'stdout.raw').open('wb') as stdout, (launch/'stderr.raw').open('wb') as stderr:
    result = subprocess.run(argv, stdout=stdout, stderr=stderr)
record = {'status': 'closed', 'argv': argv, 'exit_code': result.returncode, 'collector': pin(collector), 'streams': {channel: pin(launch/(channel+'.raw')) for channel in ['stdout', 'stderr']}}
(launch/'execution.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(result.returncode)
