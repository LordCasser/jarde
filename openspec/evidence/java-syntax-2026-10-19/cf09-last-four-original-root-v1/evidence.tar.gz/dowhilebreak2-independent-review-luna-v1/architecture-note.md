# DoWhileBreak2 architecture review

## Finding

The public API result is a real missing recovery region, not a false source-tree or runtime mismatch. The exact original class executes successfully and its `check()` passes on JDK 23. In all eight class/JAR × default/all × debug/no-debug API cells, `TestCls.test()Ljava/lang/Object;` is returned as fallback with the same two diagnostics: the loop rule refuses the block at BCI 0 because BCI 9 is an effect outside the comparison value, then reports uncovered blocks `[17, 19, 31]`. The generated Jarde source fails all 16 compiler combinations because the fallback method has no return statement and because `check()` references the pinned JUnit/AssertJ harness; the latter also gives the observed Java 8 major-55 boundary.

The original full method has this bytecode sequence (from the pinned class bytes): BCI 4 invokes `Iterator.next()`, BCI 9 casts the result to `String`, BCI 12 stores local 1, BCI 14 branches on local 1; the null arm at BCI 17 returns local 1; the non-null arm enters BCI 19, calls `hasNext()`, branches back to BCI 0 or exits to BCI 31, which returns local 1. Thus BCI 17 is an early terminal return leaf, BCI 19 is the post-test latch, and BCI 31 is the ordinary loop-exit return.

## Existing proof and refusal path

In `crates/jarde-java/src/region.rs`, `loop_region` first identifies the header comparison and scans header successors. At lines 17019–17049 it calls `post_test_break_prefix_proved` for a successor outside the natural loop, using the latch's outside successor as the expected loop exit. In this target, that candidate is BCI 17, while the expected ordinary loop exit is BCI 31.

The existing prefix helper is specifically an effectful statement-bearing **goto** bridge proof. At lines 21926–21941 it requires the prefix block to contain at least two instructions and to end in `goto`/`goto_w` with `Operation::Transfer`. BCI 17 ends in `areturn`, so it is correctly not accepted as a goto-prefix bridge. That refusal changes `body_branch` to false before the do-while route is tried.

The existing return-leaf proof already covers the needed shape: `loop_terminal_returns` at lines 23557–23653 accepts only a terminal return block with no successors, one exact canonical normal predecessor from a comparison/switch in the loop, and a decoded `Operation::Return`. This exactly separates BCI 17 from the latch and the ordinary exit. `Frame::loop_body` already carries the `terminal_returns` set into the body scope (around lines 4925–4935).

There is a second ordering issue if the initial screen is relaxed: `latch_tested_loop` scans all outside successors and calls `post_test_break_prefix_proved` at lines 21615–21639, but computes `loop_terminal_returns` only afterward at line 21668. The same BCI 17 return would be rejected there as well unless the proven leaf set is available before that scan.

After the prefix screen has declined the do-while candidate, `header_tested_loop` tries the header as a pure test. The loop's BCI 9 cast/store work precedes the BCI 14 null comparison, so this is not a statement-free test and must remain a refusal. `statementful_loop_header` is a constrained alternate, but its path proof expects the body path to reach a latch whose sole successor is the header (around lines 19930–20019); this target's latch has a second successor to BCI 31, so that alternate is not the right fit.

## Minimal architectural landing

Reuse the existing `loop_terminal_returns` result as an exclusion from the goto-prefix gate, in both the early `loop_region` header-successor screen and the later `latch_tested_loop` successor scan. Compute it once for the candidate's exact natural-loop blocks and ordinary exit, then pass the same set to the do-while proof and body-frame construction. Keep `post_test_break_prefix_proved` unchanged for nonterminal prefixes: it continues to require the current statement-bearing goto and exact exit proof. The existing terminal-leaf proof remains the only way BCI 17 can bypass that goto test.

This preserves the two critical boundaries: BCI 17 is admitted only by its exact method-return edge proof, while effectful BCI 9 is still a body instruction and cannot be moved into the BCI 14 condition. The returned leaf is then available to the current loop body scope and branch writer. No new region kind, CFG rewrite, or generalized prefix relaxation is indicated by this evidence.

## Acceptance and adversarial checks for a later implementation

The positive fixture should recover the loop with the BCI 0 body instructions in bytecode order, the null branch's BCI 17 return owned as an early terminal leaf, BCI 19 as the condition/latch, and the post-loop BCI 31 return outside the loop. It should pass the original two `check()` cases when run on the supported JDK 23 framework. Compare all original/generated iterator traces, returned values, check outcome, source map, and member inventory.

Keep negative controls for a terminal block with a non-Return terminal opcode, a Return leaf with another canonical predecessor or any outgoing edge, a branch source outside the natural loop, a foreign-path leaf, a leaf equal to the loop's normal exit, and a goto prefix that fails its current exact edge/instruction proof. Include budget/late-stop rollback if the implementation must move/duplicate the proof scan; budget usage must remain charged while owner publication stays transactional. Re-run the same complete API grid and both-runtime compiled source matrix.
