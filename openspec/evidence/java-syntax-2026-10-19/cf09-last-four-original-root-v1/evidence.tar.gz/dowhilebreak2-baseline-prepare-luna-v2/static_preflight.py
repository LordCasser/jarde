#!/usr/bin/env python3
"""Read-only syntax and pin preflight; does not run collectors, JDK/JADX/Jarde, or acceptance."""
from pathlib import Path
import ast, hashlib, json, re, importlib.util
BASE=Path(__file__).parent
SOURCE=Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestDoWhileBreak2.java')
SOURCE_SHA='8b936f2645d158c4ddc8c19e3790045fe3bfd26fe49ef54c3141df41fd433666'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,msg):
    if not ok: raise SystemExit(msg)
source=SOURCE.read_text(encoding='utf-8')
plan=json.loads((BASE/'caseplans.json').read_text(encoding='utf-8'))
need(SOURCE.is_file() and sha(SOURCE)==SOURCE_SHA and SOURCE.stat().st_size==1078,'original source pin differs')
for copy in (BASE/'source/jadx/tests/integration/loops/TestDoWhileBreak2.java',BASE/'source-plan-copy/TestDoWhileBreak2.java'):
    need(copy.read_bytes()==SOURCE.read_bytes(),'complete source copy differs')
need(plan['schema']=='test-do-while-break2-source-plan-v1','case plan schema differs')
need(plan['source']['bytes']==1078 and plan['source']['sha256']==SOURCE_SHA and Path(plan['source']['copy']).read_bytes()==SOURCE.read_bytes(),'source-plan copy binding differs')
need(plan['jadx_source_revision_pin']['revision']=='2fb1b16386941660fda07e9017285aec40fcb37f' and sha(plan['jadx_source_revision_pin']['evidence_path'])==plan['jadx_source_revision_pin']['evidence_sha256'],'revision evidence pin differs')
need(plan['method']['binary_name']=='jadx/tests/integration/loops/TestDoWhileBreak2$TestCls' and plan['method']['descriptor']=='()Ljava/lang/Object;','target identity differs')
need([x['id'] for x in plan['cases']]==['two-elements','null-terminated'],'case order differs')
need('public Object test()' in source and 'public void check()' in source and 'Iterator<String> it;' in source,'target/check declaration missing')
need('assertThat(test()).isEqualTo("b")' in source and 'assertThat(test()).isEqualTo(null)' in source,'full original check assertions missing')
need('containsLine(2, "do {")' in source and 'containsLine(3, "obj = this.it.next();")' in source and 'containsLine(3, "if (obj == null) {")' in source and 'containsLine(2, "} while (this.it.hasNext());")' in source,'outer source-shape assertions changed')
need('@Disabled' not in source and 'NYI' not in source,'source disable/NYI marker unexpectedly present')
for p in (BASE/'collect_baseline.py',BASE/'audit.py',BASE/'driver/TestDoWhileBreak2Driver.java',BASE/'runtime-bound-cwd.py'):
    if p.suffix=='.py': ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
collector=(BASE/'collect_baseline.py').read_text(); audit=(BASE/'audit.py').read_text(); driver=(BASE/'driver/TestDoWhileBreak2Driver.java').read_text()
need("CASE_NAMES = ('two-elements', 'null-terminated')" in collector,'collector case order differs')
need(re.search(r"CASE_PLAN_SHA256 = '([0-9a-f]+)'",collector).group(1)==sha(BASE/'caseplans.json'),'collector case-plan SHA differs')
need(re.search(r"DRIVER_SHA256 = '([0-9a-f]+)'",collector).group(1)==sha(BASE/'driver/TestDoWhileBreak2Driver.java'),'collector driver SHA differs')
need(re.search(r"CASE_PLAN_SHA='([0-9a-f]+)'",audit).group(1)==sha(BASE/'caseplans.json') and re.search(r"DRIVER_SHA='([0-9a-f]+)'",audit).group(1)==sha(BASE/'driver/TestDoWhileBreak2Driver.java') and re.search(r"COLLECTOR_SHA='([0-9a-f]+)'",audit).group(1)==sha(BASE/'collect_baseline.py'),'auditor source pins differ')
need("('test', '()Ljava/lang/Object;', 0x0001)" in collector and "('check', '()V', 0x0001)" in collector,'complete target method census gate missing')
need("sorted(tuple(f) for f in child['fields'])" in collector and "sorted(tuple(f) for f in facts[INTERNAL]['fields'])" in audit,'target tuple-field census gate missing')
need("expected_driver_tree = ['TestDoWhileBreak2Driver$TracingIterator.class', 'TestDoWhileBreak2Driver.class']" in collector,'driver-only class tree census missing')
need('next=' in driver and 'hasNext=' in driver and 'cursor=' in driver and 'remaining=' in driver and 'stack(cause)' in driver and 'cause.getMessage()' in driver,'iterator call/state trace missing')
need('new URLClassLoader(urls, null)' in driver and 'wrong CodeSource:' in driver,'parentless exact-CodeSource driver contract missing')
need("'-Xverify:all'" in collector and "'-cp', driver_classes" in collector,'isolated verified driver-only application classpath missing')
need("*dependency['classpath']" in collector,'pinned framework dependency URLs missing from runtime controls')
need("'schema': 'test-do-while-break2-full-source-baseline-v1'" in collector and "'test-do-while-break2-full-source-baseline-v1'" in audit,'receipt schema is target-specific')
need("lines[-1].startswith('CHECK result=')" in collector and 'check_match' in collector and 'case_match' in collector and 'combined_match' in collector,'separate actual CHECK record/comparison missing')
need("len(names)==2" in audit and "len(original)==4" in audit,'audit runtime/case closure differs')
spec=importlib.util.spec_from_file_location('dowhilebreak2_collector_preflight',BASE/'collect_baseline.py')
need(spec is not None and spec.loader is not None,'collector module loader unavailable')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
synthetic_rows=[]
for i,case in enumerate(plan['cases']):
    expected=case['expected']
    synthetic_rows.append({'name':case['id'],'input':case['input'],'after':expected['after'],
        'result':'return='+expected['return'],'exception_type':expected['exception_type'],'target_stdout':expected['stdout']})
need(mod.validate_case_oracle(synthetic_rows,plan['cases'])==[],'synthetic CASE validation failed')
need(sorted(tuple(row) for row in [('it','Ljava/util/Iterator;',0)])==[('it','Ljava/util/Iterator;',0)],'synthetic tuple-field inventory failed')
print('STATIC_PREFLIGHT_READY: syntax, source pins, protocol and synthetic CASE/tuple-field checks only; no acceptance execution')
