# TestDoWhileBreak2 三方完整基线准备

本包是未执行的基线准备，不宣称 JADX 输出、编译或运行已成功。v1准备包因校验器变量名、字段表示和结果诊断问题被root拒绝；本v2在全新目录修复，v1保持原样。原始 source 固定为 JADX 提交 `2fb1b16386941660fda07e9017285aec40fcb37f` 下的 `TestDoWhileBreak2.java`；root 已核实当前 checkout 与该提交文件逐字相同。本地完整副本在 `source/jadx/tests/integration/loops/TestDoWhileBreak2.java` 和 `source-plan-copy/TestDoWhileBreak2.java`，均保留 outer `IntegrationTest`、JUnit `@Test`、完整嵌套 `TestCls` 与真实 `check()`。

目标是 `jadx.tests.integration.loops.TestDoWhileBreak2$TestCls`。源声明一个 package-private `Iterator<String> it` 字段、隐式 public 构造器、`test()Ljava/lang/Object;` 和 `check()V`；没有嵌套 helper。JUnit 外层只有一项 source-shape 检查：do/next/null分支/while尾部文本。源没有 `@Disabled` 或 NYI 标记；该静态事实不代表JUnit断言已执行。后续 collector 会保存两种 profile 的实际 JADX source；不要把源码中的 `containsLine` 文本断言记作已运行。

`caseplans.json` 有两个有限观察：`["a","b"]` 与 `["a","b",null]`。每个直接调用由跟踪 Iterator 记录 `next(value)` / `hasNext(boolean)` 的有序事件、cursor 和 remaining values，同时记录 return、异常类型、stdout。预期 trace/result 只作辅助静态假说，原始编译 class 的观察才是 oracle。驱动还单独实际调用未删减的 `check()`，以 `CHECK` 行记录断言结果、异常类型/message/stdout；它要求隔离 URLClassLoader 从 null parent 启动。

执行矩阵为 debug/no-debug × class/full class JAR × default/all，共 8 个 API 调用；原件完整 outer+target source 在 JDK8 保留完整编译边界，并由 JDK23 `--release 8` 编译两 profile。成功生成的完整 source class 再分别由 JDK8/JDK23隔离VM运行。应用 `-cp` 仅含独立 driver class目录；target loader 仅增加冻结 dependency receipt 中经过污染检查与hash检查的框架 URL，并严格核对 target 的物理 CodeSource。每个VM有独立空 cwd；wrong-root control 也带同一依赖URL以避免 eager verification 因缺框架而失败。生成源码重编、class/JAR/outer tree、fields/methods/access/flags、物理 Code/BCI、API raw report、UTF-8 source-map/BCI map 及每条 subprocess 的原 stdout/stderr 均由复用管线留存。JDK8 框架 major-55/52 边界作为真实失败原流保留。

复用 Loop4 已审查完整管线，仅更换源事实、case协议、目标方法/字段清单与私有 driver：`collect_baseline.py`、`audit.py`、`static_preflight.py`、`runtime-bound-cwd.py`。依赖来源是已接受的 `cf11-original-nestedloops3-baseline-v1` execution receipt；包括 JADX test harness、AssertJ/JUnit jars 和 class directory pins。`pins.json`记录准确输入路径与hash。JDK/JADX/Jarde CLI不在此执行，也不预设其结果。

root 串行执行命令计划（CLI 路径与SHA由root提供）：

```sh
python3 -B /private/tmp/jarde-dowhilebreak2-baseline-prepare-luna-v1-20261019/collect_baseline.py --out /private/tmp/jarde-dowhilebreak2-baseline-root-v1-20261019 --cli <root-supplied-candidate-cli> --cli-sha256 <root-supplied-sha256>
python3 -B /private/tmp/jarde-dowhilebreak2-baseline-prepare-luna-v1-20261019/audit.py --receipt /private/tmp/jarde-dowhilebreak2-baseline-root-v1-20261019/execution.json --cli <root-supplied-candidate-cli> --cli-sha256 <root-supplied-sha256> --out /private/tmp/jarde-dowhilebreak2-baseline-review-root-v1-20261019
python3 -B /private/tmp/jarde-dowhilebreak2-baseline-prepare-luna-v1-20261019/static_preflight.py
```

实际CLI当前候选 SHA（由root提供，仍须运行前核对）：`d29b6fee723d8f59fbecd9fd8be9f15a8ec73de3a90f5a2a29b24ff91e4af607`。本轮只读共享文件，以 Python `-B` 创建私有包；未运行 collector、audit、JDK/JADX/Jarde、Git、网络或 Atlas，也未写共享工程。
