import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;

/** Isolated finite observations of the complete TestDoWhileBreak2$TestCls and its original check(). */
public final class TestDoWhileBreak2Driver {
    private static final String TARGET = "jadx.tests.integration.loops.TestDoWhileBreak2$TestCls";
    private static final String[] NAMES = {"two-elements", "null-terminated"};
    private static final String[][] INPUTS = {{"a", "b"}, {"a", "b", null}};

    private static final class TracingIterator implements Iterator<String> {
        private final String[] values;
        private int cursor;
        private final List<String> events = new ArrayList<String>();
        TracingIterator(String[] values) { this.values = values; }
        @Override public boolean hasNext() {
            boolean result = cursor < values.length;
            events.add("hasNext=" + result);
            return result;
        }
        @Override public String next() {
            if (cursor >= values.length) throw new java.util.NoSuchElementException();
            String value = values[cursor++];
            events.add("next=" + String.valueOf(value));
            return value;
        }
        String input() {
            StringBuilder b = new StringBuilder("[");
            for (int i = 0; i < values.length; i++) {
                if (i != 0) b.append(',');
                if (values[i] == null) b.append("null"); else b.append('\"').append(values[i]).append('\"');
            }
            return b.append(']').toString();
        }
        String after() {
            return "cursor=" + cursor + ";remaining=" + Arrays.toString(Arrays.copyOfRange(values, cursor, values.length))
                + ";events=" + events.toString();
        }
    }
    private static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static String codeSource(Class<?> c) throws Exception {
        CodeSource source = c.getProtectionDomain().getCodeSource();
        if (source == null || source.getLocation() == null) throw new IllegalStateException("target has no CodeSource");
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }
    private static void requireEmptyCwd(String expected) throws Exception {
        String actual = Paths.get(".").toRealPath().toString();
        if (!actual.equals(expected)) throw new IllegalStateException("unexpected JVM cwd: expected=" + expected + " actual=" + actual);
        String[] entries = new java.io.File(".").list();
        if (entries == null || entries.length != 0) throw new IllegalStateException("JVM cwd is not empty");
    }
    private static void observe(Method test, Field iteratorField, Constructor<?> ctor, int index, String cwd, PrintStream resultOut) throws Exception {
        requireEmptyCwd(cwd);
        Object receiver = ctor.newInstance();
        TracingIterator input = new TracingIterator(INPUTS[index]);
        iteratorField.set(receiver, input);
        PrintStream previous = System.out;
        ByteArrayOutputStream captured = new ByteArrayOutputStream();
        PrintStream targetOut = new PrintStream(captured, true, "UTF-8");
        Throwable cause = null; String result = "<not-returned>";
        try {
            System.setOut(targetOut);
            try { result = "return=" + String.valueOf(test.invoke(receiver)); }
            catch (InvocationTargetException e) { cause = e.getCause(); }
        } finally { targetOut.flush(); System.setOut(previous); targetOut.close(); }
        String output = new String(captured.toByteArray(), StandardCharsets.UTF_8);
        resultOut.println("CASE index=" + index + " name=" + NAMES[index] + " input_b64=" + b64(input.input())
            + " result_b64=" + b64(result) + " exception=" + (cause == null ? "none" : cause.getClass().getName())
            + " exception_message_b64=" + b64("") + " exception_stack_b64=" + b64("")
            + " target_stdout_b64=" + b64(output) + " after_b64=" + b64(input.after()));
        requireEmptyCwd(cwd);
    }
    private static String observeCheck(Method check, Object receiver) throws Exception {
        PrintStream previous = System.out; ByteArrayOutputStream captured = new ByteArrayOutputStream();
        PrintStream checkOut = new PrintStream(captured, true, "UTF-8"); Throwable cause = null;
        try { System.setOut(checkOut); try { check.invoke(receiver); } catch (InvocationTargetException e) { cause = e.getCause(); } }
        finally { checkOut.flush(); System.setOut(previous); checkOut.close(); }
        String output = new String(captured.toByteArray(), StandardCharsets.UTF_8);
        return "CHECK result=" + (cause == null ? "pass" : "error") + " exception="
            + (cause == null ? "none" : cause.getClass().getName()) + " stdout_b64=" + b64(output)
            + " exception_message_b64=" + b64(cause == null ? "" : String.valueOf(cause.getMessage()));
    }
    public static void main(String[] args) throws Exception {
        if (args.length < 3) throw new IllegalArgumentException("usage: TestDoWhileBreak2Driver actualRoot expectedRoot emptyWorkingDirectory [dependencyUrl ...]");
        String actual = Paths.get(args[0]).toRealPath().toString();
        String expected = Paths.get(args[1]).toRealPath().toString();
        String cwd = Paths.get(args[2]).toRealPath().toString(); requireEmptyCwd(cwd);
        URL[] urls = new URL[args.length - 2]; urls[0] = Paths.get(actual).toUri().toURL();
        for (int i = 3; i < args.length; i++) urls[i - 2] = Paths.get(args[i]).toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(urls, null)) {
            Class<?> target = Class.forName(TARGET, true, loader);
            if (target.getClassLoader() != loader) throw new IllegalStateException("target did not load from isolated parentless loader");
            String origin = codeSource(target);
            if (!origin.equals(expected)) throw new IllegalStateException("wrong CodeSource: expected=" + expected + " actual=" + origin);
            Constructor<?> ctor = target.getDeclaredConstructor(); ctor.setAccessible(true);
            Method test = target.getDeclaredMethod("test"); test.setAccessible(true);
            Method check = target.getDeclaredMethod("check"); check.setAccessible(true);
            Field iteratorField = target.getDeclaredField("it"); iteratorField.setAccessible(true);
            PrintStream resultOut = System.out;
            for (int i = 0; i < NAMES.length; i++) observe(test, iteratorField, ctor, i, cwd, resultOut);
            String checkRow = observeCheck(check, ctor.newInstance());
            System.out.println(checkRow); requireEmptyCwd(cwd);
        }
    }
}
