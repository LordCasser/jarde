# TestBreakInComplexIf baseline capture preparation

Status: private preparation only. Neither the collector nor the Java driver has been executed. No baseline/runtime or generated-source result is claimed. Root must review both independent entry points and supply `--cli` plus its SHA-256 before running the collector.

`source/jadx/tests/integration/loops/TestBreakInComplexIf.java` is the complete upstream 1,533-byte source, including the JUnit outer class, `TestCls`, non-static `Point`, and `check()`. It is not trimmed or rewritten. The standalone reflection driver invokes only `TestCls.test(Map,int)`; it loads `Point` from the same parentless target class loader, checks both CodeSources, and does not invoke the outer JUnit methods or `check()`. The driver marks `Point` fields accessible because the declaring nested class is package-private.

The frozen plan contains nine finite cases, including the `Integer.MAX_VALUE` wrap case whose first two keys force a mismatch and bounded exit. `static_preflight.py` computes those plan expectations without Java. Its output is static arithmetic evidence only.

A prior read-only parse of the actual Java 23 debug class confirms the target class inventory: `<init>()V`, `test(Ljava/util/Map;I)I`, and `check()V`, with zero target fields. The v3 collector and reviewer enforce that exact inventory for successful original compiles. The collector attempts the original complete source with configured Java 8 and Java 23 compilers; captures the original driver runtime and wrong-CodeSource control; requests target and helper class-source reports for child/bundle-child and default/all; captures whole JADX source trees; and attempts full-source recompilation without source edits. It records all outcomes, including failures. Successful complete target/helper inventories are the only basis for generated isolated-VM rows. A generated target source which itself contains the complete nested `Point` declaration is compiled as that complete target source; otherwise the complete target and Point source outputs are compiled together. No original class is used to fill generated output. The sole permitted source-vs-generated access-flag delta is an explicitly reported `ACC_SYNTHETIC` bit difference for the same member identity; all member names, descriptors, and source-visible flags remain checked.

The collector uses a fresh empty runtime cwd, driver-only classpath, parentless loader, per-case output capture, bounded wrapper, source/tool snapshots, 5 GiB free-disk guard, 1 GiB target guard, and verifies the repository `target/` remains absent. `pins.json` records the preparation files and external input pins. The case-plan source path is intentionally the independently pinned upstream copy recorded inside the plan; the collector reopens that copy and verifies its exact 1,533 bytes equal the separately pinned original input. It does not require the two paths to be identical.

The v1 launch stopped after two commands when its stale target inventory expected `<init>()V` and `test(I)I`; the actual successful Java 23 debug parse showed three methods listed above. The v3 change updates that case-specific inventory in collector and reviewer and retains `check()V`. The original Java 8 compile failure remains a raw observation and was not rerun here. The earlier accidental private overwrite is preserved, unexecuted, at `history/collector-overwritten-audit.py`; the active `collect_baseline.py` and `audit.py` are separate files. Do not treat that history file as the collector.

Suggested later commands (not run here):

```sh
python3 -B static_preflight.py
python3 -B collect_baseline.py --out /private/tmp/<fresh-output> --cli /path/to/candidate-cli --cli-sha256 <sha256>
python3 -B audit.py --receipt /private/tmp/<fresh-output>/execution.json --cli /path/to/candidate-cli --cli-sha256 <sha256> --out /private/tmp/<fresh-review.json>
```

The independent reviewer is a draft for root inspection. No receipt exists yet, so its run has not been validated against an actual capture schema. This baseline is scoped to one fixed upstream input and makes no claim about a product defect or a new recovery capability.


The v4 reviewer compares original and generated runtime rows using only the fixed semantic projection `index, name, input, result, exception_type, target_stdout, after`. Exception type and state are still required to match. Exception messages, stack traces, and raw serialized lines remain preserved per original VM/profile in the review output as diagnostics; they are not used as cross-profile semantic equality keys.


The reviewer validates the recorded Python wrapper executable by requiring one existing absolute `python*` launcher to be used consistently by the original, generated, and wrong-root wrapper rows. The reviewer is run under a different Python installation from the collector, so it does not compare the capture launcher with its own `sys.executable`.
