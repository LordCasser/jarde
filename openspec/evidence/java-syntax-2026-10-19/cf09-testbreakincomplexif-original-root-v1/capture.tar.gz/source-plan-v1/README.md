# TestBreakInComplexIf 源码 case plan（未编译/未运行）

原始完整源码在 `upstream/TestBreakInComplexIf.java`，1,533 bytes，SHA-256 `8e31f1cbe056fee54e43bab414f1c3c5ad19803497a80844c20a1d5f50226d4f`。私有副本逐字相同。`source-plan.json` 保存完整方法/成员范围、visitor 源 pin 和有限输入 oracle。

目标是 public static `TestCls`，其中 private `test(Map<String, Point>, int):int` 从 `mapX + 1` 开始，循环条件是 `x < 100`。每轮以十进制字符串查 Map；缺失或 null `Point`、或 `y != 100` 时 break，否则递增 length。初值为 1。source `check()` 的两项已有断言分别给出返回 3 和 2。`Point` 是非静态内部类，声明 `public final int x/y`，构造器无 checked throws。`TestCls` 源中没有声明字段；字节码中的合成成员需等后续 physical census 证实。外层 JUnit `test()` / `testNoDebug()` 只校验源码文本，不应该作为 target driver 调用。

额外列出的有限 cases 覆盖 null Point 短路、首项缺失、x=99 的最后合法访问、x=100 时跳过空 map、循环体内 null map 异常、最大正常全遍历，以及 mapX 加一溢出后立即借 null value break。所有 case 最多 99 次循环；不要用会从 int 最小值遍历到 99 的 case。除 null map 的范围内访问外，不预期异常，也没有 target stdout 或 map/Point 写入。

实现参考仅记录 JADX `LoopRegionMaker` 和 `IfRegionMaker`：循环 visitor 会从 loop exit edges 寻找可插入 break 的 crossing，if visitor 会先合并/重组嵌套条件。当前只读源码不能确定此输入在 Jarde 的实际恢复质量或归因。

本次只检查源码、case 数学和 visitor 实现，并保存 pins；没有编译、运行或执行任何工具链，也没有创建 OpenSpec。