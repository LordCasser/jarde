# Case-specific assumptions checked for v3

The stopped v2 capture has two command records; its Java 8 whole-source boundary failed and the Java 23 debug full-source compile succeeded before the stale inventory check aborted. No further command ran and no target method ran.

Read-only independent reparse of the actual successful debug class files is recorded in `actual-debug-inventory.json`; both compare.py and the physical class parser agree for each class name, major, and complete method records. The target `TestBreakInComplexIf$TestCls` is major 52, has exactly `<init>()V`, `test(Ljava/util/Map;I)I`, `check()V`, and zero fields. The Point helper retains its actual outer-instance constructor and fields; the outer JUnit class remains part of the full source closure.

The only stale DoWhile assumption found was the target inventory `{<init>()V, test(I)I}` in the collector. v3 replaces it with the actual three-method target inventory and adds the same exact gate to the independent reviewer. There are no other occurrences of the stale `test(I)I` identity in either script. The reviewer’s already-correct target lookup is `test(Ljava/util/Map;I)I`. The full original outer/target/Point tree, driver target signature, finite case list, map/Point observations, and parentless CodeSource flow remain unchanged.

No new class was compiled and no runtime, collector, or reviewer was executed for this v3 preparation.
