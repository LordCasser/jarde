# TestBreakInComplexIf baseline capture preparation

Status: private preparation only. Neither the collector nor the Java driver has been executed. No baseline/runtime or generated-source result is claimed. Root must review both independent entry points and supply `--cli` plus its SHA-256 before running the collector.

`source/jadx/tests/integration/loops/TestBreakInComplexIf.java` is the complete upstream 1,533-byte source, including the JUnit outer class, `TestCls`, non-static `Point`, and `check()`. It is not trimmed or rewritten. The standalone reflection driver invokes only `TestCls.test(Map,int)`; it loads `Point` from the same parentless target class loader, checks both CodeSources, and does not invoke the outer JUnit methods or `check()`. The driver marks `Point` fields accessible because the declaring nested class is package-private.

The frozen plan contains nine finite cases, including the `Integer.MAX_VALUE` wrap case whose first two keys force a mismatch and bounded exit. `static_preflight.py` computes those plan expectations without Java. Its output is static arithmetic evidence only.

The collector attempts the original complete source with configured Java 8 and Java 23 compilers; captures the original driver runtime and wrong-CodeSource control; requests target and helper class-source reports for child/bundle-child and default/all; captures whole JADX source trees; and attempts full-source recompilation without source edits. It records all outcomes, including failures. Successful complete target/helper inventories are the only basis for generated isolated-VM rows. A generated target source which itself contains the complete nested `Point` declaration is compiled as that complete target source; otherwise the complete target and Point source outputs are compiled together. No original class is used to fill generated output. The sole permitted source-vs-generated access-flag delta is an explicitly reported `ACC_SYNTHETIC` bit difference for the same member identity; all member names, descriptors, and source-visible flags remain checked.

The collector uses a fresh empty runtime cwd, driver-only classpath, parentless loader, per-case output capture, bounded wrapper, source/tool snapshots, 5 GiB free-disk guard, 1 GiB target guard, and verifies the repository `target/` remains absent. `pins.json` records the preparation files and external input pins.

The earlier accidental private overwrite is preserved, unexecuted, at `history/collector-overwritten-audit.py`; the active `collect_baseline.py` and `audit.py` are separate files. Do not treat that history file as the collector.

Suggested later commands (not run here):

```sh
python3 -B static_preflight.py
python3 -B collect_baseline.py --out /private/tmp/<fresh-output> --cli /path/to/candidate-cli --cli-sha256 <sha256>
python3 -B audit.py --receipt /private/tmp/<fresh-output>/execution.json --out /private/tmp/<fresh-review.json>
```

The independent reviewer is a draft for root inspection. No receipt exists yet, so its run has not been validated against an actual capture schema. This baseline is scoped to one fixed upstream input and makes no claim about a product defect or a new recovery capability.
