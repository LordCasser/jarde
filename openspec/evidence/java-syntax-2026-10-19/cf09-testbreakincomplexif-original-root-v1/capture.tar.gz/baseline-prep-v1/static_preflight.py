#!/usr/bin/env python3
"""Static case-plan/driver consistency check; never invokes Java or the target."""
import base64, hashlib, json, re
from pathlib import Path
HERE=Path(__file__).resolve().parent
SOURCE=HERE/'source/jadx/tests/integration/loops/TestBreakInComplexIf.java'
DRIVER=HERE/'driver/TestBreakInComplexIfDriver.java'
PLAN=HERE/'caseplans.json'
SOURCE_SHA='8e31f1cbe056fee54e43bab414f1c3c5ad19803497a80844c20a1d5f50226d4f'

def main():
    source=SOURCE.read_bytes(); assert len(source)==1533 and hashlib.sha256(source).hexdigest()==SOURCE_SHA
    plan=json.loads(PLAN.read_text()); cases=plan['case_plans']['TestBreakInComplexIf']['cases']
    text=DRIVER.read_text()
    match=re.search(r'private static final String\[\] NAMES\s*=\s*\{([^}]*)\}',text)
    assert match
    names=re.findall(r'"([A-Za-z0-9-]+)"',match.group(1))
    assert names==[c['id'] for c in cases]
    xmatch=re.search(r'private static final int\[\] MAP_X\s*=\s*\{([^}]*)\}',text)
    assert xmatch
    values=[v.strip() for v in xmatch.group(1).split(',')]
    expect=[str(c['input']['mapX']) if c['input']['mapX'] != 2147483647 else 'Integer.MAX_VALUE' for c in cases]
    assert values==expect
    assert text.index('String inputSnapshot =') < text.index('method.invoke(receiver, map,')
    assert text.index('String afterSnapshot = snapshot(map);') > text.index('method.invoke(receiver, map,')
    assert 'new URL[]{Paths.get(actual).toUri().toURL()}, null' in text
    assert 'codeSource(target)' in text and 'codeSource(pointClass)' in text
    rows=[]; max_steps=0
    for c in cases:
        inp=c['input']; m=inp['map']; x=((inp['mapX']+1+2**31)%(2**32))-2**31; length=1; steps=0; exc='none'
        while x<100:
            steps+=1
            if steps>100: raise AssertionError(f"{c['id']} is not finitely bounded by the planned input")
            if m is None: exc='java.lang.NullPointerException'; break
            value=m.get(str(x))
            if value is None or value['y'] != 100: break
            length+=1; x=((x+1+2**31)%(2**32))-2**31
        got={'return':None if exc!='none' else length,'exception':exc,'iterations':steps}
        exp={'return':c['expected']['return'],'exception':c['expected']['exception']}
        assert got['return']==exp['return'] and got['exception']==exp['exception'], (c['id'],got,exp)
        if c['id']=='wrapped-start-breaks-immediately': assert steps==2 and length==2
        if 'expected' in c and 'iterations' in c['expected']: assert steps==c['expected']['iterations']
        max_steps=max(max_steps,steps); rows.append({'id':c['id'],**got})
    print(json.dumps({'status':'static-source-math-only','case_count':len(rows),'case_rows':rows,
                      'maximum_loop_visits':max_steps,'target_execution':False},indent=2))
if __name__=='__main__': main()
