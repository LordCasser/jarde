#!/usr/bin/env python3
"""Independent read-only integrity/oracle review for the TestBreakInComplexIf baseline."""
from __future__ import annotations
import argparse, base64, hashlib, importlib.util, json, os, re, zipfile
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
BASE=Path('/private/tmp/jarde-testbreakincomplexif-baseline-prep-luna-v1-20261019')
SOURCE=Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestBreakInComplexIf.java')
SOURCE_SHA='8e31f1cbe056fee54e43bab414f1c3c5ad19803497a80844c20a1d5f50226d4f'
INTERNAL='jadx/tests/integration/loops/TestBreakInComplexIf$TestCls'
POINT=INTERNAL+'$Point'
OUTER='jadx/tests/integration/loops/TestBreakInComplexIf'
DRIVER='TestBreakInComplexIfDriver'
CASE_PLAN=BASE/'caseplans.json'
CASE_PLAN_SHA='732d70aad23c295762314fe165692520a0eb1f54fe93dbfd1b07c158331e5ae8'
DRIVER_SOURCE=BASE/'driver/TestBreakInComplexIfDriver.java'
DRIVER_SHA='7699e539e8aae012709cb112275b09e52adeebc34161642d2731860a1d891a53'
COLLECTOR=BASE/'collect_baseline.py'
COLLECTOR_SHA='TO_FILL_COLLECTOR_SHA'
RUNTIMES=('javac8','javac23'); PROFILES=('debug','no-debug'); FORMS=('child','bundle-child'); EVIDENCE=('default','all')

class AuditError(RuntimeError): pass
def need(ok,msg):
    if not ok: raise AuditError(msg)
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def norm(x):
    if isinstance(x,dict): return {str(k):norm(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [norm(v) for v in x]
    return x
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    if not spec or not spec.loader: raise AuditError(f'cannot load helper {path}')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def pin(row,label):
    need(isinstance(row,dict) and {'path','bytes','sha256'} <= row.keys(),f'{label}: malformed pin')
    p=Path(row['path']).resolve(strict=True); b=p.read_bytes()
    need(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],f'{label}: bytes/hash mismatch {p}')
    return p
def reopen_pin_records(value,label='pin'):
    count=0
    if isinstance(value,dict):
        if {'path','bytes','sha256'} <= value.keys(): pin(value,label); return 1
        for k,v in value.items(): count+=reopen_pin_records(v,f'{label}.{k}')
    elif isinstance(value,list):
        for i,v in enumerate(value): count+=reopen_pin_records(v,f'{label}[{i}]')
    return count
def codepoints(text):
    out={0}; n=0
    for ch in text: n+=len(ch.encode('utf-8')); out.add(n)
    return out
def class_facts(compare,physical,path,label):
    a=compare.parse_class(path); b=physical.parse_class_file(Path(path).read_bytes())
    need(a['class_name']==b['class_name'] and a['major']==b['major'] and norm(a['methods'])==norm(b['methods']),f'{label}: independent class parsers differ')
    need(sorted((f['name'],f['descriptor'],f['access']) for f in b['fields'])==sorted(tuple(x) for x in a['fields']),f'{label}: field parser facts differ')
    a['access']=b['access']; return a
def tree(compare,root):
    root=Path(root); return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*.class'))}
def parse_rows(raw,names):
    lines=raw.decode('utf-8','strict').splitlines()
    need(len(lines)==len(names),f'expected {len(names)} driver rows, got {len(lines)}')
    rx=re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) target_stdout_b64=([^ ]*) after_b64=([^ ]*)$')
    dec=lambda s:base64.b64decode(s,validate=True).decode('utf-8','strict')
    rows=[]
    for i,line in enumerate(lines):
        m=rx.fullmatch(line); need(m is not None,f'malformed driver row {i}: {line!r}')
        idx,name,inp,res,exc,msg,stack,out,after=m.groups()
        need(int(idx)==i and name==names[i],f'driver row order/name mismatch {i}')
        rows.append({'index':i,'name':name,'input':dec(inp),'result':dec(res),'exception_type':exc,
                     'exception_message':dec(msg),'exception_stack':dec(stack),'target_stdout':dec(out),'after':dec(after),'raw':line})
    return rows
def snapshot(mapping):
    if mapping is None:return 'null'
    return '{'+','.join(f"{k}="+('null' if v is None else f"Point({v['x']},{v['y']})") for k,v in sorted(mapping.items()))+'}'
def oracle_check(rows,cases):
    issues=[]
    if len(rows)!=len(cases): return ['row count differs from plan']
    for row,c in zip(rows,cases):
        inp=c['input']; exp=c['expected']; state=snapshot(inp['map'])
        wantres='<not-returned>' if exp['exception']!='none' else f"return={exp['return']}"
        for key,want in [('input',f"mapX={inp['mapX']};map={state}"),('after',state),('result',wantres),('exception_type',exp['exception']),('target_stdout',exp['stdout'])]:
            if row[key]!=want: issues.append(f"{c['id']}: {key} differs")
    return issues
def source_visible_access(access):
    # Raw access flags remain in all class facts. ACC_SYNTHETIC is the sole
    # non-source flag allowed to differ between independently compiled source.
    return access & ~0x1000

def inventory_metadata_differences(original, generated, internal):
    differences=[]
    specs=(
        ('method',original['methods'],generated['methods'],lambda x:(x['name'],x['descriptor']),lambda x:x['access']),
        ('field',original['fields'],generated['fields'],
         lambda x:(x['name'],x['descriptor']) if isinstance(x,dict) else (x[0],x[1]),
         lambda x:x['access'] if isinstance(x,dict) else x[2]),
    )
    for kind,left,right,key_of,access_of in specs:
        lm={key_of(row):row for row in left}; rm={key_of(row):row for row in right}
        need(lm.keys()==rm.keys(),f'{internal}: {kind} name/descriptor inventory differs')
        for ident in sorted(lm):
            la,ra=access_of(lm[ident]),access_of(rm[ident])
            need(source_visible_access(la)==source_visible_access(ra),f'{internal}: source-visible {kind} flags differ at {ident}: {la} vs {ra}')
            if la!=ra:
                need((la^ra)==0x1000,f'{internal}: non-synthetic access flags differ at {ident}: {la} vs {ra}')
                differences.append({'class_name':internal,'member_kind':kind,'name':ident[0],
                                    'descriptor':ident[1],'original_access':la,'generated_access':ra,
                                    'allowed_difference':'ACC_SYNTHETIC only'})
    return differences

def method_map_audit(method,physical):
    issues=[]; body=method.get('outcome',{}).get('report',{}); txt=body.get('text'); sm=body.get('source_map')
    if not isinstance(txt,str): return {'issues':['raw method text absent'],'mapped_bcis':[]}
    if not isinstance(sm,dict) or not isinstance(sm.get('segments'),list): return {'issues':['raw source map/segments absent'],'mapped_bcis':[]}
    bounds=codepoints(txt); n=len(txt.encode('utf-8')); bcis=set(physical.get('code',{}).get('bcis',[])); mapped=set()
    identity=method.get('item',{}).get('identity',{}); owner=identity.get('owner')
    for i,seg in enumerate(sm['segments']):
        start,end=seg.get('start'),seg.get('end')
        if type(start)!=int or type(end)!=int or not (0<=start<=end<=n) or start not in bounds or end not in bounds:
            issues.append(f'segment {i}: invalid UTF-8 byte span'); continue
        origin=seg.get('origin')
        if not isinstance(origin,dict) or not isinstance(origin.get('primary'),dict):
            issues.append(f'segment {i}: primary origin absent'); continue
        derived=origin.get('derived',[])
        if not isinstance(derived,list): issues.append(f'segment {i}: malformed derived list'); continue
        for ref in [origin['primary'],*derived]:
            bci=ref.get('bci') if isinstance(ref,dict) else None
            if type(bci)!=int or bci not in bcis: issues.append(f'segment {i}: nonphysical BCI {bci!r}')
            else: mapped.add(bci)
            im=ref.get('method') if isinstance(ref,dict) else None
            if not isinstance(im,dict):
                issues.append(f'segment {i}: origin method identity missing'); continue
            if im.get('owner')!=owner: issues.append(f'segment {i}: method owner differs from selected method')
            try:
                ref_name=bytes(im.get('name',[])).decode('utf-8','strict')
                ref_desc=bytes(im.get('descriptor',[])).decode('utf-8','strict')
            except (TypeError,ValueError,UnicodeDecodeError):
                issues.append(f'segment {i}: malformed method identity')
            else:
                if ref_name!=physical.get('name') or ref_desc!=physical.get('descriptor'):
                    issues.append(f'segment {i}: method name/descriptor differs from physical method')
    return {'issues':issues,'mapped_bcis':sorted(mapped),'physical_bcis':sorted(bcis),
            'unmapped_bcis':sorted(bcis-mapped),'covers_all':mapped==bcis}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--receipt',type=Path,required=True); ap.add_argument('--cli',type=Path,required=True); ap.add_argument('--cli-sha256',required=True); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args()
    need(re.fullmatch('[0-9a-f]{64}',a.cli_sha256) is not None,'CLI SHA must be 64 lowercase hex')
    receipt_path=a.receipt.resolve(strict=True); data=json.loads(receipt_path.read_text()); out=a.out
    need(data.get('schema')=='test-break-in-complex-if-full-source-baseline-v1','receipt schema mismatch')
    need(data.get('root')==str(ROOT) and Path(data.get('output','')).resolve()==receipt_path.parent,'root/output identity mismatch')
    need(data.get('status') in ('captured-pending-independent-review','failed'),'unexpected capture status')
    cli=a.cli.resolve(strict=True); need(data.get('candidate_cli_sha256_expected')==a.cli_sha256 and Path(data['cli']['path']).resolve()==cli and sha(cli)==a.cli_sha256,'candidate CLI binding mismatch')
    need(sha(SOURCE)==SOURCE_SHA and len(SOURCE.read_bytes())==1533,'upstream source pin changed')
    need(sha(CASE_PLAN)==CASE_PLAN_SHA and sha(DRIVER_SOURCE)==DRIVER_SHA and sha(COLLECTOR)==COLLECTOR_SHA,'frozen source/plan/collector pins changed')
    need(sha(receipt_path.parent/'collector.py')==COLLECTOR_SHA,'captured collector copy mismatch')
    compare_path=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
    guard_path=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
    scanner_path=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
    parser=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
    compare=load(compare_path,'breakcomplex_compare'); guard=load(guard_path,'breakcomplex_guard'); physical=load(parser,'breakcomplex_physical')
    source=Path(data['source']['path']); need(source.resolve()==SOURCE.resolve() and sha(source)==SOURCE_SHA,'receipt source binding differs')
    plan=json.loads(CASE_PLAN.read_text()); cases=plan['case_plans']['TestBreakInComplexIf']['cases']; names=[x['id'] for x in cases]
    need(data['runtime_case_names']==names and len(names)==9,'case order/count differs from pinned plan')
    profile_by={p['profile']:p for p in data.get('source_profiles',[])}; findings=[]; physical_by_profile={}; pin_records=0
    need(len(profile_by)==2 and set(profile_by)==set(PROFILES),'original profile inventory incomplete')
    # Reopen all command raw streams and environmental/source/tool pin records first.
    commands=data.get('commands',[]); cmd_by={r['index']:r for r in commands}
    need(len(cmd_by)==len(commands) and sorted(cmd_by)==list(range(1,len(commands)+1)),'command indexes are not contiguous/unique')
    for row in commands:
        need(row['cwd']==str(ROOT) and row.get('guard_stop') is None,'command cwd/guard failure')
        need(row.get('peak_target_bytes',0)<=1024**3 and row.get('free_bytes_after',0)>=5*1024**3,'target/free-space guard boundary exceeded')
        need(row.get('env_overrides')==guard.ENV_VALUES,'command environment overrides differ from pinned guard')
        for channel in ('stdout','stderr'):
            stream=row.get('streams',{}).get(channel); path=pin(stream,f"command {row['index']} {channel}"); pin_records+=1
            raw_expected=Path(data['output'])/'raw'/f"{row['index']}.{channel}.raw"
            need(path==raw_expected.resolve() and path.read_bytes()==raw_expected.read_bytes(),f"command raw stream path mismatch {row['index']} {channel}")
        if row['exit_code']!=0: findings.append(f"command {row['index']} {row['label']} exited {row['exit_code']}; retained as observed")
    pin_records+=reopen_pin_records(data.get('external_input_pins_before',{}),'external before')
    pin_records+=reopen_pin_records(data.get('external_input_pins_after',{}),'external after')
    pin_records+=reopen_pin_records(data.get('external_input_pins_after_finally',{}),'external finally')
    need(data.get('external_inputs_unchanged') is True and data.get('external_input_pins_before')==data.get('external_input_pins_after')==data.get('external_input_pins_after_finally'),'external tool/source pins changed')
    pin_records+=reopen_pin_records(data.get('source_pins_before',[]),'source before')
    pin_records+=reopen_pin_records(data.get('source_pins_after',[]),'source after')
    pin_records+=reopen_pin_records(data.get('source_pins_after_finally',[]),'source finally')
    need(data.get('source_unchanged') is True and data.get('source_unchanged_finally') is True and data.get('source_pins_before')==data.get('source_pins_after')==data.get('source_pins_after_finally'),'workspace source closure changed')
    need(data.get('target_absent') is True and data.get('target_absent_finally') is True,'target directory is not absent')
    # Reopen source, driver, wrapper, and tool copies.
    for key in ('source_copy','driver_copy','runtime_wrapper'):
        pin_records+=pin(data[key],key).exists()
    for name,row in data.get('copied_tools',{}).items():
        path=pin(row,f'copied tool {name}'); pin_records+=1
        ext={'compare.py':compare_path,'guard.py':guard_path,'scanner.py':scanner_path,'classfile_helpers.py':parser}[name]
        need(path.read_bytes()==ext.read_bytes(),f'copied tool bytes differ: {name}')
    need(data.get('local_copies_unchanged') is True and data.get('local_copies_unchanged_finally') is True,'local copied source/driver/tool changed')
    # Original full-source compilation and independently parsed class/field/method inventories.
    for profile in PROFILES:
        row=profile_by[profile]; cmd=cmd_by[row['command']]
        need(cmd['label']==f'javac23-full-source-{profile}' and cmd['exit_code']==row['exit_code'],'original compiler command link mismatch')
        if row['exit_code']!=0: findings.append(f'{profile}: original full source did not compile; no original runtime expected')
        else:
            root=Path(row['class_root']).resolve(strict=True); facts={}
            need(set(row['class_tree'])=={OUTER+'.class',INTERNAL+'.class',POINT+'.class'},'original full-source class tree inventory differs')
            need(norm(tree(compare,root))==norm(row['class_tree']),f'{profile}: original class tree differs from live files')
            for rel in sorted(row['class_tree']):
                f=class_facts(compare,physical,root/rel,f'{profile}/{rel}'); need(norm(f)==norm(row['outer_facts'] if rel==OUTER+'.class' else row['target_facts'] if rel==INTERNAL+'.class' else row['point_facts']),f'{profile}/{rel}: full class facts differ from receipt')
                facts[f['class_name']]=f
            need(set(facts)=={OUTER,INTERNAL,POINT},f'{profile}: class identities incomplete')
            need(any((m['name'],m['descriptor'])==('test','(Ljava/util/Map;I)I') for m in facts[INTERNAL]['methods']),'target method missing')
            physical_by_profile[profile]=facts
            jar=pin(row['bundle'],f'{profile} class bundle'); pin_records+=1
            with zipfile.ZipFile(jar) as z:
                need(sorted(x for x in z.namelist() if not x.endswith('/'))==sorted(row['class_tree']),f'{profile} class JAR members differ')
                for rel in row['class_tree']: need(z.read(rel)==(root/rel).read_bytes(),f'{profile} JAR bytes differ {rel}')
    # Original runtime rows: parentless driver, actual/expected roots, exact case oracle, and cross-VM stability.
    original=[]
    for row in data.get('original_runtime',[]):
        cmd=cmd_by[row['command']]; argv=cmd['argv']; root=Path(row['target_root']).resolve(strict=True)
        need(len(argv)==13 and argv[6]=='-Xverify:all' and argv[7]=='-cp' and Path(argv[8]).resolve()==Path(data['driver_classes'][0]['path']).parent.resolve() and argv[9]==DRIVER,'original driver invocation isolation mismatch')
        need(Path(argv[10]).resolve()==root and Path(argv[11]).resolve()==root and Path(argv[4]).resolve()==Path(argv[12]).resolve(),'original CodeSource/cwd argv mismatch')
        cwd=Path(argv[4]).resolve(strict=True); need(not list(cwd.iterdir()),'original runtime cwd not empty after command')
        rows=parse_rows(pin(row['stdout'],'original stdout').read_bytes(),names); pin_records+=1
        issues=oracle_check(rows,cases); need(not issues,'original manual oracle mismatch: '+', '.join(issues))
        need(row['exit_code']==0 and cmd['exit_code']==0,'original runtime did not complete')
        original.append((row['profile'],row['runtime'],rows))
    need(len(original)==4 and len({(p,r) for p,r,_ in original})==4,'original runtime grid incomplete')
    baseline={(p,r):rows for p,r,rows in original}
    for p in PROFILES:
        for vm in RUNTIMES:
            matches=[rows for pp,rr,rows in original if pp==p and rr==vm]
            need(len(matches)==1,'duplicate or missing original runtime cell')
    # APIs: exact 16 cells, method inventories/maps tied to the proper physical class.
    api_cells=data.get('jarde_cells',[]); api_map={}
    expected_api={(p,internal,f,e) for p in PROFILES for internal,_ in ( (INTERNAL,'target'),(POINT,'point')) for f in FORMS for e in EVIDENCE}
    for c in api_cells:
        key=(c['profile'],c['api_class'],c['input_form'],c['evidence']); need(key not in api_map and key in expected_api,f'duplicate/unknown API cell {key}')
        api_map[key]=c; cmd=cmd_by[c['command']]; report_path=pin(c['report'],f'API report {key}'); pin_records+=1
        raw=report_path.read_bytes(); need(raw==Path(cmd['streams']['stdout']['path']).read_bytes(),f'{key}: report bytes differ from stdout')
        doc=json.loads(raw.decode('utf-8','strict')); whole=pin(c['whole_source'],f'whole source {key}'); pin_records+=1
        need(whole.read_bytes()==doc.get('text','').encode('utf-8'),f'{key}: whole source differs from API text')
        need(cmd['label']==f"jarde-{key[0]}-{'target' if key[1]==INTERNAL else 'point'}-{key[2]}-{key[3]}",'API label/selector mismatch')
        argv=cmd['argv']; policy='single-class' if key[2]=='child' else 'plain-jar'
        need((Path(argv[0]).resolve()==cli and argv[1:3]==['class-source','--input']
             and Path(argv[3]).resolve()==Path(c['input']).resolve()
             and '--class' in argv and argv[argv.index('--class')+1]==key[1]
             and '--policy' in argv and argv[argv.index('--policy')+1]==policy
             and '--release' in argv and argv[argv.index('--release')+1]=='8'
             and (('--evidence' in argv and argv[argv.index('--evidence')+1]=='all') == (key[3]=='all'))),
             f'{key}: actual CLI arguments differ from selected input/evidence')
        facts=physical_by_profile.get(key[0],{}).get(key[1]); need(facts is not None,f'{key}: no physical class facts')
        physical_methods={(m['name'],m['descriptor']):m for m in facts['methods']}; seen=[]; raw_docs={}
        for raw_method in doc.get('methods',[]):
            item=raw_method.get('item',{}); mk=(item.get('name',{}).get('escaped'),item.get('descriptor',{}).get('escaped'))
            need(mk not in raw_docs,f'{key}: duplicate raw API method {mk}')
            raw_docs[mk]=raw_method
        for m in c.get('methods',[]):
            mk=(m.get('name'),m.get('descriptor')); seen.append(mk)
            pm=physical_methods.get(mk); need(pm is not None and mk in raw_docs,f'{key}: API method not in physical class/report {mk}')
            raw_method=raw_docs[mk]; raw_identity=raw_method.get('item',{}).get('identity',{})
            raw_owner=raw_identity.get('owner')
            need(m.get('identity')==raw_identity and m.get('owner')==raw_owner
                 and m.get('location')==raw_owner.get('location') and m.get('variant')==raw_owner.get('variant'),
                 f'{key}/{mk}: summary method identity differs from raw report')
            raw_outcome=raw_method.get('outcome',{}); raw_body=raw_outcome.get('report',{})
            need(m.get('outcome_kind')==raw_outcome.get('kind') and m.get('quality')==raw_body.get('quality')
                 and m.get('fallbacks')==raw_body.get('fallbacks') and m.get('regions')==raw_body.get('regions')
                 and m.get('raw_text')==raw_body.get('text') and m.get('source_map')==raw_body.get('source_map'),
                 f'{key}/{mk}: method summary differs from full raw report')
            audit=method_map_audit(raw_method,pm)
            need(m.get('map_audit')==audit,f'{key}/{mk}: stored map audit differs from independent recomputation')
            if audit['issues']: findings.append(f'{key}/{mk}: map findings {audit["issues"]}')
            if audit['unmapped_bcis']: findings.append(f'{key}/{mk}: unmapped physical BCIs {audit["unmapped_bcis"]}')
        need(sorted(seen)==sorted(physical_methods) and set(raw_docs)==set(physical_methods),'API method inventory does not match physical class inventory')
        input_path=pin(c['input'],f'API input {key}'); pin_records+=1
        prof=profile_by[key[0]]
        if key[2]=='child': need(input_path==Path(prof['class_root'])/(key[1]+'.class'),'API child input differs from selected class')
        else: need(input_path==Path(prof['bundle']['path']),'API bundle input differs from full original JAR')
    need(set(api_map)==expected_api and len(api_cells)==len(expected_api),'full target/helper API grid is incomplete')
    stable=True
    for p in PROFILES:
        for internal,_ in ((INTERNAL,'target'),(POINT,'point')):
            for form in FORMS:
                d=api_map[(p,internal,form,'default')]; allc=api_map[(p,internal,form,'all')]
                if d.get('whole_source')!=allc.get('whole_source') or norm(d.get('methods'))!=norm(allc.get('methods')): stable=False
    if not stable: findings.append('default/all whole text or method maps differ for at least one same-input API pair')
    # Full JADX trees are recorded as obtained, and every generated source copy remains byte-identical.
    for output in data.get('jadx_outputs',[]):
        row=cmd_by[output['command']]; pin(output['input'],'JADX full-bundle input'); pin_records+=1
        for item in output.get('sources',[]): pin_records+=1; pin(item,'JADX source')
    # Generated source inventory is exact; both API source texts remain captured even
    # when the target source already contains its nested Point declaration.
    cells=data.get('generated_source_cells',[]); cell_by={}
    expected_jarde_cells={(p,f,e) for p in PROFILES for f in FORMS for e in EVIDENCE}
    expected_jadx_cells={(p,'whole-outer-child-tree','default') for p in PROFILES}
    for cell in cells:
        key=(cell.get('kind'),cell.get('profile'),cell.get('form'),cell.get('evidence'))
        need(key not in cell_by,f'duplicate generated source cell {key}'); cell_by[key]=cell
        source_paths=cell.get('source_paths',[]); source_pins=cell.get('source_pins',[]); copies=cell.get('source_copies',[])
        need(len(source_paths)==len(source_pins)==len(copies),f'{key}: source file/pin/copy inventory length differs')
        for i,(src,pin_row,copy_row) in enumerate(zip(source_paths,source_pins,copies)):
            need(src is not None,f'{key}: missing full source path at index {i}')
            sp=pin(pin_row,f'{key} source API output {i}'); cp=pin(copy_row,f'{key} copied source {i}')
            pin_records+=2
            need(sp==Path(src).resolve(strict=True) and cp.read_bytes()==sp.read_bytes(),f'{key}: source copy differs from full API output')
        if cell.get('kind')=='jarde':
            need(key[1:] in expected_jarde_cells,f'unexpected Jarde source cell {key}')
            need(len(source_paths)==2 and cell.get('api_roles')==['point','target'],f'{key}: both exact target/helper API outputs are required')
            target_bytes=Path(source_paths[0]).read_bytes()
            target_contains_point=re.search(rb'\bclass\s+Point\b',target_bytes) is not None
            mode='target-source-contains-Point' if target_contains_point else 'target-plus-Point-source'
            want_compile_count=1 if target_contains_point else 2
            need(cell.get('dependency_mode')==mode and len(cell.get('java_files',[]))==want_compile_count,
                 f'{key}: generated full-source dependency selection differs')
            need(len(cell.get('api_java_files',[]))==2,f'{key}: target/helper source copies are incomplete')
        elif cell.get('kind')=='jadx':
            need(key[1:] in expected_jadx_cells,f'unexpected JADX source cell {key}')
            need(cell.get('source_available') is True and bool(source_paths),f'{key}: complete JADX source tree unavailable')
            need(cell.get('java_files')==cell.get('api_java_files',cell.get('java_files')) or len(cell.get('java_files',[]))==len(source_paths),
                 f'{key}: full JADX source tree was not used')
        else: raise AuditError(f'unknown generated source kind {key[0]}')
    need({key for key in cell_by if key[0]=='jarde'}=={('jarde',p,f,e) for p,f,e in expected_jarde_cells},'Jarde generated source cell grid incomplete')
    need({key for key in cell_by if key[0]=='jadx'}=={('jadx',*key) for key in expected_jadx_cells},'JADX generated source profile grid incomplete')

    # Successful generated compilations are parsed from complete outputs; failures remain observations.
    eligible={}; compiles=data.get('generated_source_compilations',[]); generated_class_roots={}
    compile_keys=set()
    for c in compiles:
        key=(c['kind'],c['profile'],c.get('form'),c.get('evidence'),c['compiler']); need(key not in compile_keys,f'duplicate generated compiler cell {key}')
        compile_keys.add(key)
        cmd=cmd_by[c['command']]; need(cmd['exit_code']==c['exit_code'],'generated compile command/exit mismatch')
        for stream in ('stdout','stderr'):
            stream_path=pin(c[stream],f'{key} {stream}'); pin_records+=1
            need(stream_path==Path(cmd['streams'][stream]['path']).resolve(strict=True),f'{key}: compile {stream} not bound to command stream')
        cell_key=key[:4]; cell=cell_by.get(cell_key); need(cell is not None,f'{key}: no complete generated source cell')
        srcpaths=c.get('source_paths') or []
        need(srcpaths==cell.get('java_files') and bool(srcpaths),'generated compiler did not use the full selected source closure')
        argv=cmd['argv']; manifest_tools=data['jdk_manifest']['tools']
        need(argv[0]==manifest_tools[key[4]]['javac']['path'],f'{key}: compiler leg does not match pinned JDK tool')
        debug_arg='-g' if key[1]=='debug' else '-g:none'
        expected_prefix=[argv[0]] + (['-source','8','-target','8',debug_arg] if key[4]=='javac8' else ['--release','8',debug_arg])
        expected_suffix=['-encoding','UTF-8','-proc:none','-classpath',':'.join(data['dependency_classpath']),
                         '-sourcepath',data['empty_classpath'],'-d',c['class_root'],*srcpaths]
        need(argv==expected_prefix+expected_suffix,f'{key}: generated javac argv differs from exact full-source closure command')
        if c['exit_code']!=0: findings.append(f'{key}: full-source compile failed; no runtime inferred')
        else:
            root=Path(c['class_root']).resolve(strict=True); need(norm(tree(compare,root))==norm(c['class_tree']),f'{key}: generated class tree differs')
            generated_class_roots[str(root)]=c['class_tree']; facts={}
            for rel in c['class_tree']:
                f=class_facts(compare,physical,root/rel,f'{key}/{rel}'); facts[f['class_name']]=f
            required={INTERNAL,POINT}
            if not required.issubset(facts): findings.append(f'{key}: generated source output lacks complete TestCls+Point closure')
            else:
                good=True; differences=[]
                for internal in required:
                    expected=physical_by_profile[c['profile']][internal]; actual=facts[internal]
                    if actual['major']!=52: good=False
                    try: differences.extend(inventory_metadata_differences(expected,actual,internal))
                    except AuditError as error: findings.append(f'{key}: {error}'); good=False
                need(c.get('allowed_synthetic_flag_differences',[])==differences,
                     f'{key}: recorded synthetic-flag differences do not match raw inventories')
                if good and c.get('runtime_eligible') is True: eligible[key]=c
                else: findings.append(f'{key}: complete compiled target/helper inventory not eligible for isolated runtime')
    expected_compile_keys={(cell['kind'],cell['profile'],cell.get('form'),cell.get('evidence'),compiler)
                           for cell in cells if cell.get('source_available') is True for compiler in RUNTIMES}
    need(compile_keys==expected_compile_keys,'generated compiler grid missing/duplicated source/compiler cells')
    # Each successful eligible build has both VMs and a wrong-root attempt; compare only against accepted original rows.
    runtime_by={};
    for row in data.get('generated_runtime',[]):
        key=(row['kind'],row['profile'],row.get('form'),row.get('evidence'),row['compiler']); full=key+(row['runtime'],)
        need(full not in runtime_by and key in eligible,f'unknown/duplicate generated runtime {full}')
        runtime_by[full]=row; cmd=cmd_by[row['command']]; argv=cmd['argv']
        need(len(argv)==13 and argv[9]==DRIVER and Path(argv[8]).resolve()==Path(data['driver_classes'][0]['path']).parent.resolve(),'generated driver invocation not parentless/driver-only')
        need(Path(argv[10]).resolve()==Path(row['class_root']).resolve()==Path(eligible[key]['class_root']).resolve() and Path(argv[11]).resolve()==Path(argv[10]).resolve(),'generated actual/expected roots differ')
        rows=parse_rows(pin(row['stdout'],f'{full} stdout').read_bytes(),names); pin_records+=1
        issues=oracle_check(rows,cases); need(not issues,f'{full}: candidate runtime output does not match source oracle {issues}')
        base_rows=baseline[(row['profile'],row['runtime'])]
        if norm(rows)!=norm(base_rows): findings.append(f'{full}: generated runtime rows differ from original observations')
    expected_runs={key+(vm,) for key in eligible for vm in RUNTIMES}
    need(set(runtime_by)==expected_runs,'eligible generated compiles do not have exactly two runtime rows each')
    wrong_by={}
    for row in data.get('generated_wrong_root_controls',[]):
        key=(row['kind'],row['profile'],row.get('form'),row.get('evidence'),row['compiler']); need(key in eligible and key not in wrong_by,'unknown/duplicate generated wrong-root row')
        wrong_by[key]=row; cmd=cmd_by[row['command']]; argv=cmd['argv']
        need(len(argv)==13 and argv[9]==DRIVER and Path(argv[10]).resolve()==Path(eligible[key]['class_root']).resolve() and Path(argv[11]).resolve()==Path(data['empty_classpath']).resolve(),'wrong-root argv roots mismatch')
        err=pin(row['stderr'],f'{key} wrong-root stderr').read_bytes(); pin_records+=1
        need(row['exit_code']==1 and b'wrong CodeSource:' in err and row.get('rejected') is True,'wrong-root driver failed to reject expected root')
    need(set(wrong_by)==set(eligible),'eligible generated class roots lack exact wrong-root controls')
    # All saved generated source copies and class snapshots are reopened and compared by exact identity.
    before=data.get('generated_source_output_pins_before',{}); after=data.get('generated_source_output_pins_after',{})
    need(isinstance(before,dict) and before.keys()==after.keys(), 'generated source snapshot path inventory differs')
    for path,before_pin in before.items():
        before_path=pin(before_pin,f'generated source before {path}'); after_path=pin(after[path],f'generated source after {path}')
        pin_records+=2
        need(before_path==after_path==Path(path).resolve(strict=True)
             and before_pin['bytes']==after[path]['bytes'] and before_pin['sha256']==after[path]['sha256'],
             f'generated source copy changed {path}')
    need(data.get('generated_outputs_unchanged') is True,'collector did not verify generated output immutability')
    trees_before=data.get('generated_class_trees',{}); trees_after=data.get('generated_class_trees_after',{})
    need(isinstance(trees_before,dict) and trees_before.keys()==trees_after.keys(),'generated class snapshot path inventory differs')
    for root,before_tree in trees_before.items():
        root_path=Path(root).resolve(strict=True)
        need(norm(before_tree)==norm(trees_after[root]) and norm(tree(compare,root_path))==norm(before_tree),f'generated class snapshot changed {root}')
        for rel,pin_row in before_tree.items(): pin_records+=1; pin(pin_row,f'{root}/{rel}')
    # Reopen the accepted source tree, the copied source plan, and every generated source pair.
    for cell in data.get('generated_source_cells',[]):
        need(cell['source_available'] is True or cell['kind']=='jarde','JADX full-source tree has no usable source files')
        files=cell.get('java_files',[])
        if cell['source_available']:
            need(bool(files),f"{cell['kind']}/{cell['profile']}: no complete source copy list")
            for source_file in files:
                sp=Path(source_file).resolve(strict=True)
                copied=compare.pin(sp); pin_records+=1
                if cell['kind']=='jarde':
                    matches=[p for p in cell.get('source_pins',[]) if p['bytes']==copied['bytes'] and p['sha256']==copied['sha256']]
                    need(bool(matches),f'Jarde generated source copy has no exact original-source pin: {sp}')
    # Original wrong-CodeSource control must fail before invoking test.
    wrong=data.get('wrong_root_control'); need(isinstance(wrong,dict),'original wrong-root control absent')
    wc=cmd_by[wrong['command']]; wa=wc['argv']
    need(wc['exit_code']==wrong['exit_code'] and len(wa)==13 and wa[9]==DRIVER
         and Path(wa[10]).resolve()==Path(wrong['actual_target_root']).resolve()
         and Path(wa[11]).resolve()==Path(data['empty_classpath']).resolve()
         and Path(wa[12]).resolve()==Path(wa[4]).resolve(), 'original wrong-root argv mismatch')
    wrerr=pin(wrong['stderr'],'original wrong-root stderr').read_bytes(); pin_records+=1
    need(wrong['rejected'] is True and wrong['exit_code']==1 and b'wrong CodeSource:' in wrerr,'original wrong-root did not reject')
    need(not list(Path(wa[4]).resolve(strict=True).iterdir()),'original wrong-root cwd not empty')
    result={'status':'independent-read-only-review','receipt':str(receipt_path),'receipt_sha256':sha(receipt_path),
            'collector_status':data.get('status'),'commands':len(commands),'raw_streams':2*len(commands),
            'reopened_pin_records':pin_records,'original_profiles':sorted(profile_by),'original_vm_cells':len(original),
            'manual_oracle_cases_per_vm':len(names),'api_cells':len(api_cells),'api_keys_unique_complete':set(api_map)==expected_api,
            'default_all_text_maps_stable':stable,'generated_compile_attempts':len(compiles),
            'generated_compile_successes':sum(c['exit_code']==0 for c in compiles),
            'generated_vm_rows':len(runtime_by),'wrong_root_rows':len(wrong_by),'observations':findings,
            'scope':'baseline evidence integrity and bounded runtime observations; not product acceptance'}
    out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    return result
if __name__=='__main__':
    try: print(json.dumps(main(),indent=2,sort_keys=True))
    except Exception as e: raise SystemExit(f'audit failed: {e}')
