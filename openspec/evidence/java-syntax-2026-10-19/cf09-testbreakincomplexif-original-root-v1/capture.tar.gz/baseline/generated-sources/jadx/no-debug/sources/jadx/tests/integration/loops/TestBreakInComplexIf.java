package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInComplexIf.class */
public class TestBreakInComplexIf extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInComplexIf$TestCls.class */
    public static class TestCls {

        /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInComplexIf$TestCls$Point.class */
        class Point {
            public final int x;
            public final int y;

            Point(int i, int i2) {
                this.x = i;
                this.y = i2;
            }
        }

        private int test(Map<String, Point> map, int i) {
            Point point;
            int i2 = 1;
            for (int i3 = i + 1; i3 < 100 && (point = map.get(i3 + "")) != null && point.y == 100; i3++) {
                i2++;
            }
            return i2;
        }

        public void check() {
            HashMap map = new HashMap();
            map.put("3", new Point(100, 100));
            map.put("4", new Point(60, 100));
            JadxAssertions.assertThat(test(map, 2)).isEqualTo(3);
            HashMap map2 = new HashMap();
            map2.put("3", new Point(100, 100));
            map2.put("4", new Point(60, 0));
            map2.put("5", new Point(60, 100));
            JadxAssertions.assertThat(test(map2, 2)).isEqualTo(2);
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("if (tile == null || tile.y != 100) {").containsOne("break;");
    }

    @Test
    public void testNoDebug() {
        noDebugInfo();
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("break;");
    }
}
