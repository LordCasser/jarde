// jarde: presentation of `jadx/tests/integration/loops/TestBreakInComplexIf$TestCls$Point` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

class TestBreakInComplexIf$TestCls$Point extends java.lang.Object {
    public final int x;

    public final int y;

    final jadx.tests.integration.loops.TestBreakInComplexIf$TestCls this$0;

    TestBreakInComplexIf$TestCls$Point(jadx.tests.integration.loops.TestBreakInComplexIf$TestCls this$0, int x, int y) {
        // @method <init>(Ljadx/tests/integration/loops/TestBreakInComplexIf$TestCls;II)V
        // @declaration a constructor of `jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point`, member flags 0x0000
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.this$0 = this$0;
        this.x = x;
        this.y = y;
        return;
    }
}
