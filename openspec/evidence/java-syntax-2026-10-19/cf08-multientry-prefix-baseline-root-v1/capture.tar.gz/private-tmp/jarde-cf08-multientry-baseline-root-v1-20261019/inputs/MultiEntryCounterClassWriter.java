import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Writes a small version-52 class with one irreducible two-entry SCC. */
public final class MultiEntryCounterClassWriter {
    private MultiEntryCounterClassWriter() {}

    public static void main(String[] args) throws IOException {
        if (args.length != 1) {
            throw new IllegalArgumentException("usage: MultiEntryCounterClassWriter <class-root>");
        }
        Path root = Paths.get(args[0]);
        Path target = root.resolve("cf08/MultiEntryCounter.class");
        Files.createDirectories(target.getParent());
        Files.write(target, classBytes());
    }

    private static byte[] classBytes() throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(0xCAFEBABE);
        out.writeShort(0);       // minor
        out.writeShort(52);      // Java 8
        out.writeShort(15);      // constant_pool_count
        utf8(out, "cf08/MultiEntryCounter");           // #1
        out.writeByte(7); out.writeShort(1);            // #2 Class
        utf8(out, "java/lang/Object");                  // #3
        out.writeByte(7); out.writeShort(3);            // #4 Class
        utf8(out, "<init>");                            // #5
        utf8(out, "()V");                               // #6
        out.writeByte(12); out.writeShort(5); out.writeShort(6); // #7 NameAndType
        out.writeByte(10); out.writeShort(4); out.writeShort(7); // #8 Methodref
        utf8(out, "Code");                              // #9
        utf8(out, "StackMapTable");                     // #10
        utf8(out, "test");                              // #11
        utf8(out, "(IZI)I");                            // #12
        utf8(out, "SourceFile");                        // #13
        utf8(out, "MultiEntryCounter.java");            // #14

        out.writeShort(0x0021); // public, ACC_SUPER
        out.writeShort(2);      // this_class
        out.writeShort(4);      // super_class
        out.writeShort(0);      // interfaces_count
        out.writeShort(0);      // fields_count
        out.writeShort(2);      // methods_count

        out.writeShort(0x0001); // public <init>()V
        out.writeShort(5);
        out.writeShort(6);
        out.writeShort(1);
        writeCode(out, 1, 1, new byte[] {(byte) 0x2a, (byte) 0xb7, 0, 8, (byte) 0xb1}, null);

        out.writeShort(0x0009); // public static test(IZI)I
        out.writeShort(11);
        out.writeShort(12);
        out.writeShort(1);
        byte[] code = new byte[] {
            0x1b,                         // 0: iload_1 (skip)
            (byte) 0x9a, 0, 6,           // 1: ifne 7 (body), bypass prefix
            (byte) 0x84, 0, 3,           // 4: prefix: iinc 0, +3
            0x1c,                         // 7: body: iload_2 (steps)
            (byte) 0x99, 0, 9,           // 8: ifeq 17 (exit)
            (byte) 0x84, 2, (byte) 0xff, // 11: iinc 2, -1
            (byte) 0xa7, (byte) 0xff, (byte) 0xf6, // 14: goto 4 (prefix)
            0x1a, (byte) 0xac            // 17: exit: iload_0; ireturn
        };
        writeCode(out, 1, 3, code, new byte[] {0, 3, 4, 2, 9});

        out.writeShort(1);      // class attributes_count
        out.writeShort(13);     // SourceFile
        out.writeInt(2);
        out.writeShort(14);
        out.flush();
        return bytes.toByteArray();
    }

    private static void utf8(DataOutputStream out, String value) throws IOException {
        out.writeByte(1);
        out.writeUTF(value);
    }

    private static void writeCode(
            DataOutputStream out, int maxStack, int maxLocals, byte[] code, byte[] stackMap)
            throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream info = new DataOutputStream(bytes);
        info.writeShort(maxStack);
        info.writeShort(maxLocals);
        info.writeInt(code.length);
        info.write(code);
        info.writeShort(0); // exception_table_length
        info.writeShort(stackMap == null ? 0 : 1);
        if (stackMap != null) {
            info.writeShort(10); // StackMapTable
            info.writeInt(stackMap.length);
            info.write(stackMap);
        }
        info.flush();
        out.writeShort(9); // Code
        out.writeInt(bytes.size());
        out.write(bytes.toByteArray());
    }
}
