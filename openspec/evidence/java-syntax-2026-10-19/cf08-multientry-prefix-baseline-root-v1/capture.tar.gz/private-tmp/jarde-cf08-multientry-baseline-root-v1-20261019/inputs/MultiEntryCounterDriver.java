import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Field;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Parentless, bounded runtime oracle for the generated fixture. */
public final class MultiEntryCounterDriver {
    private MultiEntryCounterDriver() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            throw new IllegalArgumentException("usage: MultiEntryCounterDriver <actual-root> <expected-root>");
        }
        Path actualRoot = Paths.get(args[0]).toRealPath();
        Path expectedRoot = Paths.get(args[1]).toRealPath();
        URL[] urls = {actualRoot.toUri().toURL()};
        try (URLClassLoader loader = new URLClassLoader(urls, null)) {
            Class<?> target = Class.forName("cf08.MultiEntryCounter", true, loader);
            if (target.getClassLoader() != loader) {
                throw new AssertionError("target was not defined by the requested parentless loader");
            }
            Path source = Paths.get(target.getProtectionDomain().getCodeSource().getLocation().toURI())
                    .toRealPath();
            if (!source.equals(expectedRoot)) {
                throw new IllegalStateException("wrong CodeSource: " + source + " expected " + expectedRoot);
            }
            Field[] fields = target.getDeclaredFields();
            Constructor<?>[] constructors = target.getDeclaredConstructors();
            Method[] methods = target.getDeclaredMethods();
            if (fields.length != 0 || constructors.length != 1 || methods.length != 1) {
                throw new AssertionError("target inventory differs: fields=" + fields.length
                        + " constructors=" + constructors.length + " methods=" + methods.length);
            }
            Constructor<?> constructor = constructors[0];
            if (constructor.getParameterTypes().length != 0
                    || !Modifier.isPublic(constructor.getModifiers())) {
                throw new AssertionError("target constructor inventory differs");
            }
            Method test = methods[0];
            if (!test.getName().equals("test") || !Modifier.isPublic(test.getModifiers())
                    || !Modifier.isStatic(test.getModifiers()) || test.getReturnType() != int.class
                    || !java.util.Arrays.equals(test.getParameterTypes(),
                            new Class<?>[] {int.class, boolean.class, int.class})) {
                throw new AssertionError("target method inventory differs");
            }
            int index = 0;
            for (String input : new String[] {"ordinary", "overflow"}) {
                int initial = input.equals("ordinary") ? 17 : Integer.MAX_VALUE - 1;
                for (boolean skip : new boolean[] {false, true}) {
                    for (int steps = 0; steps <= 2; steps++) {
                        int actual;
                        try {
                            actual = ((Integer) test.invoke(null, initial, skip, steps)).intValue();
                        } catch (InvocationTargetException failure) {
                            Throwable cause = failure.getCause();
                            if (cause instanceof Exception) throw (Exception) cause;
                            if (cause instanceof Error) throw (Error) cause;
                            throw new AssertionError(cause);
                        }
                        int expected = oracle(initial, skip, steps);
                        String name = input + "-skip-" + skip + "-steps-" + steps;
                        System.out.println("CASE index=" + index + " name=" + name + " initial="
                                + initial + " actual=" + actual + " expected=" + expected);
                        if (actual != expected) {
                            throw new AssertionError("classfile result differs from source oracle");
                        }
                        index++;
                    }
                }
            }
        }
    }

    // Source equivalent: if (!skip) value += 3; while (steps != 0) { steps--; value += 3; }
    private static int oracle(int value, boolean skip, int steps) {
        if (!skip) value += 3;
        while (steps != 0) {
            steps--;
            value += 3;
        }
        return value;
    }
}
