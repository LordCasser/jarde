package cf08;

/* JADX INFO: loaded from: MultiEntryCounter.class */
public class MultiEntryCounter {
    public static int test(int i, boolean z, int i2) {
        if (!z) {
            i += 3;
        }
        while (i2 != 0) {
            i2--;
            i += 3;
        }
        return i;
    }
}
