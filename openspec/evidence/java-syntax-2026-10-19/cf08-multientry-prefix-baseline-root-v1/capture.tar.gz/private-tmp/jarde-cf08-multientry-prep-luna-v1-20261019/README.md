# CF08 multi-entry loop: static evidence and isolated fixture prep

Private, unexecuted preparation. No repository files were edited; no classwriter, compiler, Jarde CLI, Jadx, VM, Cargo, Git, or network command was run.

## Keep the two inputs distinct

The upstream fixed input is `jadx-core/src/test/smali/loops/TestMultiEntryLoop.smali`, with its integration assertion in `TestMultiEntryLoop.java`. It is not Java source and has a substantially different signature and graph: `test(III)Ljava/lang/String;` uses array allocation, a nullable static byte array, index updates, a split entry to `:goto_19`, a later `:cond_1e`, and a backward edge. Its test asserts that Jadx emits `while (true)`. Jadx's `FixMultiEntryLoops.process` identifies DFS back edges that fail its single-entry dominance test, then tries two block-duplication patterns (`isHeaderSuccessorEntry`, `isEndBlockEntry`); otherwise it emits an “Unsupported multi-entry loop pattern” warning. Static reading shows the intended algorithm and expected output assertion, but does not establish what a current Jarde run does or whether Jadx's fixer succeeds on every graph shape.

The prepared `cf08.MultiEntryCounter` is a separate, constructed Java-8 classfile control. It has no fields, a public default constructor, and public static `test(IZI)I`. Its bytecode is exactly 19 bytes and forms a cyclic SCC with two external entries: `ifne` enters at body BCI 7, while fallthrough enters at prefix BCI 4; the back edge from BCI 14 returns to BCI 4. The finite source oracle is `if (!skip) value += 3; while (steps != 0) { steps--; value += 3; } return value;`. The driver tests both boolean values and `steps=0..2` (six cases); it checks each result against that oracle. This probes an irreducible rejection boundary, not the original Smali fixture or general loop recovery.

## Bytecode layout independently checked

`test(IZI)I`: `iload_1`@0; `ifne`@1 -> 7; `iinc 0,+3`@4; `iload_2`@7; `ifeq`@8 -> 17; `iinc 2,-1`@11; `goto`@14 -> 4; `iload_0`@17; `ireturn`@18. Branch offsets are relative to the branch opcode address: +6, +9, and -10. The backedge target 4 and second entry 7 are separate nodes in the SCC `{4,7,8,11,14}`; exit 17 is outside it. The stack is empty at every branch target. A `StackMapTable` with three `same_frame` entries encodes frame BCIs 4, 7, and 17 using offset deltas 4, 2, and 9, hence frame bytes `00 03 04 02 09`. `max_stack=1`, `max_locals=3`, `code_length=19`, and the Code attribute length is 42. The constructor is `aload_0; invokespecial Object.<init>; return`, max stack/locals 1, code length 5. The source writer emits class version 52 and no extra classes.

`MultiEntryCounterClassWriter.java` uses only `DataOutputStream` and standard file APIs to write the target class. `MultiEntryCounterDriver.java` loads it through a fresh parentless URLClassLoader, validates exact CodeSource and method shape, and exposes a wrong-root check: passing an expected root different from the loaded root throws `wrong CodeSource:`. It does not catch an incorrect result or target exception as success.

## Jarde architecture facts and boundary

Atlas was opened on the Jarde project and scoped to `crates/jarde-java/src`. It identified `NaturalLoop` in `normal_flow.rs` and the irreducible-analysis path in `region.rs`; coverage was partial for broader `crates/jarde-java/src` searches, so the conclusions below also rely on direct source reads and pins.

The existing mechanism already recognizes the critical graph fact. `NormalFlowView::irreducible_blocks` computes cyclic SCCs and their outside entry nodes; a component is considered reducible only with exactly one entry that dominates every node. Natural-loop facts independently mark a second external entry or crossing loops irreducible. `region::recover` checks this before structural walking and returns `FallbackReason::Irreducible` via `quoted_whole` when any such block exists. Therefore the constructed fixture should exercise existing conservative fallback if the reader/normal-flow graph preserves this topology; that is the immediate reuse candidate, not a new recovery pass. No actual classfile or CLI run was done, so whether the pipeline reaches this exact report is unverified. A Jarde diagnostic or later fixture run should check CodeBCIs, the SCC's two entries, and the reported fallback together.

The irreducibility predicate excludes only specifically proved catch-join edges; no catch edges exist in this fixture. It uses canonical normal-flow edges and not Jadx's DFS special-edge/block-duplication representation. A future improvement to structure an irreducible SCC would need an explicit source transformation/ownership proof and is outside this control-preparation task; do not loosen the current early rejection based only on one observed sample.

## Files

- `MultiEntryCounterClassWriter.java`: generated version-52 classfile writer.
- `MultiEntryCounterDriver.java`: six-case parentless runtime/source oracle and CodeSource guard.
- `pins.json`: source hashes, line ranges, Atlas query facts, and bytecode-layout checks.

Root should review the writer and layout before compiling or loading it. The fixture does not claim CF08 coverage, original-Smali equivalence, or any current Jarde/Jadx execution result.
