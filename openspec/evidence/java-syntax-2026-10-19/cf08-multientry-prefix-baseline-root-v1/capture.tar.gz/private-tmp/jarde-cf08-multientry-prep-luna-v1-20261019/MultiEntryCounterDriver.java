import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Parentless, bounded runtime oracle for the generated fixture. */
public final class MultiEntryCounterDriver {
    private MultiEntryCounterDriver() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            throw new IllegalArgumentException("usage: MultiEntryCounterDriver <actual-root> <expected-root>");
        }
        Path actualRoot = Paths.get(args[0]).toRealPath();
        Path expectedRoot = Paths.get(args[1]).toRealPath();
        URL[] urls = {actualRoot.toUri().toURL()};
        try (URLClassLoader loader = new URLClassLoader(urls, null)) {
            Class<?> target = Class.forName("cf08.MultiEntryCounter", true, loader);
            Path source = Paths.get(target.getProtectionDomain().getCodeSource().getLocation().toURI())
                    .toRealPath();
            if (!source.equals(expectedRoot)) {
                throw new IllegalStateException("wrong CodeSource: " + source + " expected " + expectedRoot);
            }
            Method test = target.getMethod("test", int.class, boolean.class, int.class);
            if (!Modifier.isPublic(test.getModifiers()) || !Modifier.isStatic(test.getModifiers())
                    || test.getReturnType() != int.class) {
                throw new AssertionError("target method has the wrong access or descriptor");
            }
            for (boolean skip : new boolean[] {false, true}) {
                for (int steps = 0; steps <= 2; steps++) {
                    int initial = 17;
                    int actual;
                    try {
                        actual = ((Integer) test.invoke(null, initial, skip, steps)).intValue();
                    } catch (InvocationTargetException failure) {
                        Throwable cause = failure.getCause();
                        if (cause instanceof Exception) throw (Exception) cause;
                        if (cause instanceof Error) throw (Error) cause;
                        throw new AssertionError(cause);
                    }
                    int expected = oracle(initial, skip, steps);
                    System.out.println("skip=" + skip + " steps=" + steps
                            + " actual=" + actual + " expected=" + expected);
                    if (actual != expected) {
                        throw new AssertionError("classfile result differs from source oracle");
                    }
                }
            }
        }
    }

    // Source equivalent: if (!skip) value += 3; while (steps != 0) { steps--; value += 3; }
    private static int oracle(int value, boolean skip, int steps) {
        if (!skip) value += 3;
        while (steps != 0) {
            steps--;
            value += 3;
        }
        return value;
    }
}
