# CF08 multi-entry loop architecture review (static)

Status: static only. The current collector is still running; root's observed child/default result is a snapshot (`test(IZI)I`, fallback `jre_region_irreducible`, blocks `[4,7,11]`, source missing `return`). No Jadx comparison or final parity conclusion is included here. The fixed graph/source and current production code are pinned in `pins.json`.

## What the current architecture proves

- `region.rs:2455-2466` runs the irreducibility preflight before `Walker::region_at`. If any irreducible block remains, `recover` returns a whole-live-body quote. The ordinary Walker cannot see this candidate.
- `normal_flow.rs:346-383` finds cyclic SCCs, identifies entries (including method entry), and calls a cycle reducible only with one entry that dominates every member. It also adds natural-loop facts flagged irreducible by `loop_is_irreducible`. This is an intentional whole-body refusal, not a missing local branch heuristic.
- Existing `Region::Loop` (`region.rs:705-725`, `:1000-1038`) owns one natural loop and its ordered test/body. `Region::blocks` emits each physical owner and the final `overlapping_owner` check rejects repeated owners (`region.rs:2657`, `:26905-26944`). It folds only documented aliases within a shape; it does not describe one executable block presented in two source positions.
- `Walker::loop_region` (`region.rs:14481-14545`) starts only from `loop_entered_at`, defensively rejects an irreducible natural loop, then tries the existing latch/header/dual-exit/exceptional shapes. `prefixed_exceptional_retry_loop` is gated on handlers and a different nested retry proof; it is not a general multi-entry owner.
- `Builder::loop_region` (`build.rs:21101-21380`) renders one test and one body. `ForHeader` only proves moving one init and one update into the Java header (`region.rs:420-425`); it cannot represent the initial conditional prefix plus that same instruction at each loop tail. Existing `guard_region` checkpointing is try/finally-specific; ordinary loop handling does not create a reusable transaction for a newly added multi-entry shape.

## Smallest plausible extension

No existing region certificate was found that can express the observed topology without weakening the global gate. A narrow region-level proof is more direct than cloning the CFG or changing `CanonicalBlockId.path` (which denotes JSR clone identity). The candidate should be recognized from canonical graph edges, then represented as one *physical ownership* certificate with separate source-emission roles:

1. One external conditional preheader has exactly two in-SCC successors: a prefix and a header.
2. Prefix has exactly one normal successor, the header. The header has exactly two normal successors: the unique loop exit or the latch. Latch has exactly one normal successor, prefix. These are the only SCC entries, exits, and backedges; no exception/call edges or hidden/unaccounted instructions.
3. Record the prefix's canonical block/instructions once as the physical owner. Its statement is emitted twice: once under the preheader's prefix-taking arm, and once at the loop tail after the latch. Do not put the same `Region`/owner into two sibling regions and rely on later overlap folding.
4. Keep ordinary loop tests/condition and latch statements at their original execution positions. Require the existing operation/SSA/slot/type facts to prove one stable Java local binding for each statement, no conflicting writes or escapes, and source-order equivalence. For the bounded first case this can be limited to straight local integer assignments plus boolean/integer local tests; do not key the rule to a class, descriptor, BCI, constant, or `iinc` amount.
5. Preserve direct physical origins for the real instruction(s), and ensure both emitted uses retain the same one physical method/BCI identity. The source map may have two displayed spans for one origin; require that representation and full physical coverage rather than silently dropping or duplicating block ownership.

The likely seam is a narrowly named `Region` variant (or an equally narrow optional proof on `Loop`) recognized before the current irreducible whole-body return. `Region::blocks` must report the prefix once, include all other owners once, and keep the ordinary overlap/unaccounted checks intact. A post-hoc Builder rewrite is too late because the current preflight has already quoted the whole method. A general SCC relaxation would admit shapes for which the Walker's natural-loop assumptions do not hold.

## Stop behavior and refusal boundaries

Charge and poll while inspecting the candidate SCC's nodes/edges and each proof step, before retaining a certificate. A budget stop should return `Err(StopReason)` from `recover`; do not return a partly structured prefix plus an irreducible quote. During construction, poll/charge before each source emission; if either emission stops, discard the in-progress candidate and return the stop, never publish only the initial or only the loop-tail copy. Keep the existing builder's outer publication/rollback contract; the loop builder itself only restores `stmts`/`declared` around body walking, so a new certificate must not assume `FinallyCheckpoint` applies to ordinary loops.

Any additional SCC entry, prefix branch, multiple latch/exit, cross-edge, exception or call edge, non-local side effect, ambiguous SSA reaching value, conflicting write, type/slot mismatch, JSR clone crossing, or incomplete instruction/exception closure should keep the existing irreducible whole-body refusal. A negative fixture should change one such property at a time and verify exact fallback plus no partial AST; the constructed finite driver is only a behavioral control, not proof of general termination or a substitute for topology checks.

## Scope note

This is an architecture candidate, not a patch or test result. The finite classwriter/oracle covers only the chosen constructed JVM topology and its 12 finite cases. It is distinct from the upstream Smali test and does not establish broad irreducible-loop support.
