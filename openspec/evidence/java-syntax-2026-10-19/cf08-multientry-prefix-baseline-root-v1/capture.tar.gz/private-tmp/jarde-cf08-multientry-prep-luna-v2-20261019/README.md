# CF08 constructed multi-entry JVM control — v2 preparation

This is a private, unexecuted collection package. It makes no claim that the original CF08 Smali test is equivalent to the Java control, or that either Jarde or Jadx currently succeeds or fails on it. No compiler, JVM, Jarde CLI, Jadx, Cargo, Git, or network command was run while preparing these files. Shared repository files were not changed.

The input remains deliberately distinct from upstream `TestMultiEntryLoop.smali`. The target is a generated Java 8 classfile, `cf08/MultiEntryCounter`, with no fields, public `<init>()V`, and public static `test(IZI)I`. The classwriter and collector preserve its complete physical input. The driver checks the loaded class's defining loader and exact CodeSource, zero fields, one public no-argument constructor, and exactly one public static method with the requested descriptor. It tests 12 finite cases: ordinary and overflow starting values, both `skip` booleans, and `steps` 0 through 2. The oracle uses Java `int` arithmetic and does not instrument the target.

The target method uses the previously reviewed 19-byte Code layout: `iload_1; ifne 7; iinc 0,+3; iload_2; ifeq 17; iinc 2,-1; goto 4; iload_0; ireturn`. Its cyclic instruction SCC is `{4,7,8,11,14}`, with external entries at 4 and 7. The collector independently parses the class with the pinned full-class parser and a narrow classfile reader; it checks exact method/access/field inventory, exact Code bytes and BCI starts, Code attribute length 42, empty exception table, and StackMapTable bytes `00 03 04 02 09` (same-frame BCIs 4, 7, 17). This layout establishes the fixture being observed; it does not predict recovery.

`collect_multientry.py` requires the root to supply both `--cli` and the SHA-256 of the exact candidate executable being tested. It also requires a fresh `--out`. It uses the already-reviewed JDK manifest, comparison/pinning helpers, classfile parser, target-size scanner, guard runner, and 30-second Java runtime wrapper. It records each command's argv, exit, and raw streams. It compiles/runs the writer and isolated driver with JDK 8, runs the target with JDK 8 and 23, and includes a wrong-CodeSource control. It captures Jarde child/default+all and bundle-child/default+all JSON reports and full class projections. Each complete Jarde source is attempted with both Java 8 compiler legs; successful products are run under both JVM legs. It decodes the target with Jadx once, pins its complete emitted tree, compiles all emitted Java files together with both compiler legs, and runs every successful compilation under both JVM legs. Compiler/runtime failures and semantic mismatches are retained in the receipt instead of being repaired or presented as passes.

The collector checks the repository target directory is absent and enforces the existing runner's command guards, including bounded commands, target-size checks, and a 5 GiB free-space floor. It records source-closure, external tool/input, and copied-source pins before and after collection and writes a `captured-pending-independent-review` receipt only if the final guards hold. Collection itself is **not** performed here.

## Files

- `MultiEntryCounterClassWriter.java`: unchanged v1 standard-library classfile writer.
- `driver/MultiEntryCounterDriver.java`: v2 12-case runtime oracle with strict loader and member inventory checks.
- `collect_multientry.py`: prepared collector; Python syntax was checked with `ast.parse` only. It was not imported or run.
- `source/`: exact upstream fixer, Smali input, and integration test copies from v1.
- `upstream/`: references copied for the collector's full source-pin record.
- `baseline-diff.patch`: complete v1-to-v2 file diff.
- `pins.json`: SHA-256 pins and static layout/source scope.

The collector does not claim the constructed control covers Jadx's original Smali graph or every irreducible loop. Root should review this package before running it.
