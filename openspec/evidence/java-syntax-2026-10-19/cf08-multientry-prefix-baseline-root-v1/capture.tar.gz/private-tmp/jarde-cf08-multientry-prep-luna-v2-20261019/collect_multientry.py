#!/usr/bin/env python3
"""Capture a constructed CF08 multi-entry-loop classfile matrix; never edits Jarde."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, shutil, sys, zipfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
CLI_SHA256 = None  # Required at invocation; bind the candidate being observed.
COMPARE_REL = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA256 = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
PARSER = Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA256 = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA256 = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA256 = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
INTERNAL, TARGET_DOT = 'cf08/MultiEntryCounter', 'cf08.MultiEntryCounter'
CASES = tuple(f'{kind}-skip-{skip}-steps-{steps}' for kind in ('ordinary','overflow')
              for skip in ('false','true') for steps in range(3))
SOURCE_REFERENCES = [
    (Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/main/java/jadx/core/dex/visitors/blocks/FixMultiEntryLoops.java'), '0c2b67bbb15648632767625db7163bed579efcc66fc3a58b9466760f01eb945a'),
    (Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/smali/loops/TestMultiEntryLoop.smali'), '6bc3bd8342295941d26c924abc6b3930e3a223303a1b524cbeeb9e448250e1c5'),
    (Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestMultiEntryLoop.java'), '17b9f250a1b32e368b4c8c69b4ec660c9722cf2aee3eb8bd1a6fd63fbc866e74'),
]


def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def load(path: Path, name: str):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def parse_layout(data: bytes) -> dict:
    """Narrow independent decoder for this class's methods, Code, and StackMapTable."""
    p=0
    def u1():
        nonlocal p
        v=data[p]; p+=1; return v
    def u2():
        nonlocal p
        v=int.from_bytes(data[p:p+2],'big'); p+=2; return v
    def u4():
        nonlocal p
        v=int.from_bytes(data[p:p+4],'big'); p+=4; return v
    if u4()!=0xcafebabe: raise ValueError('bad class magic')
    minor,major=u2(),u2(); n=u2(); cp=[None]*n; i=1
    while i<n:
        tag=u1()
        if tag==1:
            size=u2(); cp[i]=('utf8',data[p:p+size].decode('utf-8')); p+=size
        elif tag in (3,4): p+=4
        elif tag in (5,6): p+=8; i+=1
        elif tag in (7,8,16,19,20): cp[i]=(tag,u2())
        elif tag in (9,10,11,12,17,18): p+=4
        elif tag==15: p+=3
        else: raise ValueError(f'unsupported cp tag {tag}')
        i+=1
    def utf(idx):
        row=cp[idx]
        if not row or row[0]!='utf8': raise ValueError('bad UTF8 index')
        return row[1]
    access=u2(); this=u2(); u2(); interfaces=u2(); p+=2*interfaces
    fields=u2()
    for _ in range(fields):
        p+=6; ac=u2()
        for __ in range(ac):
            utf(u2()); size=u4(); p+=size
    count=u2(); methods=[]
    for _ in range(count):
        ma=u2(); name= utf(u2()); desc=utf(u2()); ac=u2(); codeinfo=None
        for __ in range(ac):
            an=utf(u2()); length=u4(); end=p+length
            if an=='Code':
                ms,ml=u2(),u2(); clen=u4(); code=data[p:p+clen]; p+=clen
                exn=u2(); handlers=[]
                for ___ in range(exn): handlers.append([u2(),u2(),u2(),u2()])
                nested=u2(); frames=None
                for ____ in range(nested):
                    nn=utf(u2()); ln=u4(); payload=data[p:p+ln]; p+=ln
                    if nn=='StackMapTable': frames=payload
                codeinfo={'attribute_length':length,'max_stack':ms,'max_locals':ml,'code_length':clen,'code_hex':code.hex(),
                          'handlers':handlers,'stackmap_hex':frames.hex() if frames is not None else None}
            p=end
        methods.append((ma,name,desc,codeinfo))
    class_attrs=u2()
    for _ in range(class_attrs):
        utf(u2()); size=u4(); p+=size
    return {'minor':minor,'major':major,'access':access,'class_name':utf(cp[this][1]),
            'methods':methods,'fields':fields,'trailing_bytes':len(data)-p}


def require_target_facts(fact: dict, role: str):
    layout=fact['layout']; methods={(m[1],m[2]):m for m in layout['methods']}
    if layout['class_name']!=INTERNAL or layout['major']!=52 or layout['fields']!=0:
        raise RuntimeError(f'{role}: target class identity/major/field inventory differs')
    if set(methods)!={('<init>','()V'),('test','(IZI)I')} or methods[('<init>','()V')][0]!=0x0001 or methods[('test','(IZI)I')][0]!=0x0009:
        raise RuntimeError(f'{role}: exact method/access inventory differs')

def parse_rows(stdout: bytes):
    import re
    lines=stdout.decode('utf-8','strict').splitlines()
    if len(lines)!=12: raise ValueError(f'expected 12 rows, got {len(lines)}')
    pat=re.compile(r'^CASE index=(\d+) name=([^ ]+) initial=(-?\d+) actual=(-?\d+) expected=(-?\d+)$')
    rows=[]
    for i,line in enumerate(lines):
        m=pat.fullmatch(line)
        if not m or int(m[1])!=i or m[2]!=CASES[i] or int(m[4])!=int(m[5]):
            raise ValueError(f'bad oracle row: {line!r}')
        rows.append({'index':i,'name':m[2],'initial':int(m[3]),'actual':int(m[4]),'expected':int(m[5])})
    return rows

def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--cli',type=Path,required=True)
    ap.add_argument('--cli-sha256',required=True); ap.add_argument('--out',type=Path,required=True)
    cli_args=ap.parse_args(); runtime_argv=sys.argv[1:]
    root=ROOT.resolve(strict=True); cli=cli_args.cli.resolve(strict=True); out=cli_args.out.resolve()
    if out.exists(): raise SystemExit('output path must be new')
    if sha(cli)!=cli_args.cli_sha256: raise SystemExit('candidate CLI SHA mismatch')
    if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('target must be absent')
    cp=root/COMPARE_REL; gp=root/GUARD_REL; sp=root/SCANNER_REL; mp=root/JDK_MANIFEST_REL
    for path,digest in ((cp,COMPARE_SHA256),(gp,GUARD_SHA256),(sp,SCANNER_SHA256),(mp,JDK_MANIFEST_SHA256),
                        (PARSER,PARSER_SHA256),(JADX,JADX_SHA256),(JADX_JAR,JADX_JAR_SHA256),(RUNTIME_BOUND,RUNTIME_BOUND_SHA256)):
        if sha(path)!=digest: raise SystemExit(f'input pin mismatch: {path}')
    compare=load(cp,'multientry_compare'); guard=load(gp,'multientry_guard')
    scanner=load(sp,'multientry_scanner'); physical=load(PARSER,'multientry_physical')
    jdks,jdk_record=compare.configured_jdks(mp,JDK_MANIFEST_SHA256)
    writer=Path(__file__).parent/'MultiEntryCounterClassWriter.java'
    driver=Path(__file__).parent/'driver/MultiEntryCounterDriver.java'
    if not writer.is_file() or not driver.is_file(): raise SystemExit('prepared sources missing')
    source_before=compare.source_closure(root); out.mkdir(parents=True); rawdir=out/'raw'; rawdir.mkdir()
    guard.ROOT=root; guard.OUT=rawdir; guard.target_bytes=lambda:scanner.target_bytes(root); guard.command_stream=compare.pin
    guard.expected_test_summaries=lambda index,stdout_bytes:None
    if shutil.disk_usage(root).free<5*1024**3: raise SystemExit('5 GiB free-space guard failed')
    copydir=out/'inputs'; copydir.mkdir(); writer_copy=copydir/writer.name; driver_copy=copydir/driver.name
    shutil.copy2(writer,writer_copy); shutil.copy2(driver,driver_copy)
    if writer.read_bytes()!=writer_copy.read_bytes() or driver.read_bytes()!=driver_copy.read_bytes(): raise RuntimeError('source copy mismatch')
    source_copy_dir=out/'upstream'; copied_refs=[]
    for ref,_expected in SOURCE_REFERENCES:
        dest=source_copy_dir/ref.name; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(ref,dest)
        if ref.read_bytes()!=dest.read_bytes(): raise RuntimeError(f'upstream copy differs: {ref}')
        copied_refs.append({'source':compare.pin(ref),'copy':compare.pin(dest)})
    local_copies_before={'writer':compare.pin(writer_copy),'driver':compare.pin(driver_copy),
                         'upstream':[x['copy'] for x in copied_refs]}
    collector_path=Path(__file__).resolve()
    external=[cli,cp,gp,sp,mp,PARSER,JADX,JADX_JAR,RUNTIME_BOUND,writer,driver,collector_path,*[x[0] for x in SOURCE_REFERENCES]]
    external_before=[compare.pin(p) for p in external]
    for ref,expected in SOURCE_REFERENCES:
        if sha(ref)!=expected: raise SystemExit(f'upstream reference SHA mismatch: {ref}')
    report={'schema':'cf08-multientry-constructed-baseline-v2','status':'running','root':str(root),
            'output':str(out),'runtime_argv':runtime_argv,'cli':compare.pin(cli),'cli_expected_sha256':cli_args.cli_sha256,
            'jdk_manifest':jdk_record,'jdk_manifest_pin':compare.pin(mp),'compare':compare.pin(cp),'guard':compare.pin(gp),
            'scanner':compare.pin(sp),'physical_parser':compare.pin(PARSER),'jadx':compare.pin(JADX),'jadx_jar':compare.pin(JADX_JAR),
            'runtime_wrapper':compare.pin(RUNTIME_BOUND),
            'writer_source':compare.pin(writer),'writer_copy':compare.pin(writer_copy),
            'collector':compare.pin(collector_path),'driver_source':compare.pin(driver),'driver_copy':compare.pin(driver_copy),
            'upstream_reference_pins':[compare.pin(x[0]) for x in SOURCE_REFERENCES],
            'upstream_reference_copies':copied_refs,'local_copies_before':local_copies_before,
            'source_pins_before':source_before,'external_pins_before':external_before,'commands':[],
            'original_classes':None,'original_runtime':[],'wrong_root_control':None,'jarde_cells':[],'jarde_generated':[],'jadx_outputs':[],
            'generated_compile_runtime':[],'notes':['Constructed JVM classfile, not the upstream Smali fixture.',
            'Twelve finite cases cover ordinary and overflow values, skip true/false, and steps 0..2.',
            'No runtime or recovery outcome is assumed; compiler refusals and source mismatches remain evidence.']}
    compare.write_json(out/'execution.json',report); rows=report['commands']
    def command(argv,label,leg='javac23'):
        if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError('workspace target appeared')
        env=compare.clean_env(dict(os.environ),jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK',None)
        row=guard.run_command(len(rows)+1,[str(x) for x in argv],env); row['label']=label; row['tool_leg']=leg; rows.append(row)
        compare.write_json(out/'execution.json',report)
        if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        if row.get('exit_code') is None: raise RuntimeError(f'command lacks exit code: {label}')
        if shutil.disk_usage(root).free<5*1024**3: raise RuntimeError('free-space floor crossed')
        return row
    def stream(row,ch='stdout'): return compare.command_artifact(row,ch)
    def tree(base): return {p.relative_to(base).as_posix():compare.pin(p) for p in sorted(base.rglob('*.class'))}
    def facts(path,role):
        a=compare.parse_class(path); b=physical.parse_class_file(path.read_bytes())
        if a['class_name']!=b['class_name'] or a['major']!=b['major'] or a['methods']!=b['methods']:
            raise RuntimeError(role+': independent class parsers disagree')
        if sorted((f['name'],f['descriptor'],f['access']) for f in b['fields'])!=sorted(a['fields']):
            raise RuntimeError(role+': field parsers disagree')
        return {'summary':a,'physical':b,'layout':parse_layout(path.read_bytes())}
    try:
        empty=out/'empty-cp'; empty.mkdir(); driver_classes=out/'driver-classes'; driver_classes.mkdir()
        writer_classes=out/'writer-classes'; writer_classes.mkdir()
        generated=out/'original-classes'; generated.mkdir()
        w=command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',writer_classes,writer_copy],'compile-class-writer','javac8')
        if w['exit_code']!=0: raise RuntimeError('class writer compile failed')
        writer_class_tree=tree(writer_classes)
        if sorted(writer_class_tree)!=['MultiEntryCounterClassWriter.class']:
            raise RuntimeError('unexpected writer class inventory')
        report['writer_class_tree']=writer_class_tree
        wc=command([jdks['javac8']['tools']['java'],'-Xverify:all','-cp',writer_classes,'MultiEntryCounterClassWriter',generated],'run-class-writer','javac8')
        if wc['exit_code']!=0: raise RuntimeError('class writer failed')
        target=generated/(INTERNAL+'.class'); tf=facts(target,'constructed target'); layout=tf['layout']
        expected_code='1b9a00068400031c9900098402ffa7fff61aac'
        if layout['class_name']!=INTERNAL or layout['major']!=52 or layout['access']!=0x21 or layout['fields']!=0 or layout['trailing_bytes']!=0:
            raise RuntimeError('constructed class identity/layout header differs')
        require_target_facts(tf,'constructed target')
        methods={(m[1],m[2]):m for m in layout['methods']}
        if set(methods)!={('<init>','()V'),('test','(IZI)I')} or methods[('<init>','()V')][0]!=0x0001 or methods[('test','(IZI)I')][0]!=0x0009:
            raise RuntimeError('constructed method inventory/access differs')
        init_code=methods[('<init>','()V')][3]
        if init_code is None or init_code['code_hex']!='2ab70008b1' or init_code['code_length']!=5 or init_code['stackmap_hex'] is not None:
            raise RuntimeError('constructed constructor Code differs')
        if methods[('test','(IZI)I')][3]['code_hex']!=expected_code:
            raise RuntimeError('constructed test Code differs')
        code=methods[('test','(IZI)I')][3]
        if (code['attribute_length'],code['max_stack'],code['max_locals'],code['code_length'],code['handlers'],code['stackmap_hex'])!=(42,1,3,19,[],'0003040209'):
            raise RuntimeError('constructed Code or StackMapTable layout differs')
        physical_test=next(m for m in tf['summary']['methods'] if m['name']=='test' and m['descriptor']=='(IZI)I')
        if physical_test['code']['bcis']!=[0,1,4,7,8,11,14,17,18]:
            raise RuntimeError('independent physical Code BCI census differs')
        profile={'class_root':str(generated.resolve()),'class_tree':tree(generated),'facts':tf}
        if sorted(profile['class_tree'])!=['cf08/MultiEntryCounter.class']:
            raise RuntimeError('constructed target class tree differs')
        report['original_classes']=profile; compare.write_json(out/'execution.json',report)
        d=command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',driver_classes,driver_copy],'compile-independent-driver','javac8')
        if d['exit_code']!=0: raise RuntimeError('driver compile failed')
        report['driver_class_tree']=tree(driver_classes)
        if sorted(report['driver_class_tree'])!=['MultiEntryCounterDriver.class']:
            raise RuntimeError('unexpected driver class inventory')
        for runtime in ('javac8','javac23'):
            run=command([sys.executable,'-B',RUNTIME_BOUND,'30',jdks[runtime]['tools']['java'],'-Xverify:all','-cp',driver_classes,'MultiEntryCounterDriver',generated,generated],f'original-{runtime}',runtime)
            cell={'runtime':runtime,'command':run['index'],'exit_code':run['exit_code'],'stdout':compare.pin(Path(run['streams']['stdout']['path'])),'stderr':compare.pin(Path(run['streams']['stderr']['path']))}
            if run['exit_code']==0: cell['rows']=parse_rows(stream(run))
            report['original_runtime'].append(cell)
        if len(report['original_runtime'])!=2 or any(x.get('exit_code')!=0 or len(x.get('rows',[]))!=12 for x in report['original_runtime']):
            raise RuntimeError('original dual-runtime oracle incomplete')
        wrong=command([sys.executable,'-B',RUNTIME_BOUND,'30',jdks['javac8']['tools']['java'],'-Xverify:all','-cp',driver_classes,'MultiEntryCounterDriver',generated,empty],'wrong-root-control','javac8')
        report['wrong_root_control']={'command':wrong['index'],'exit_code':wrong['exit_code'],'rejected':wrong['exit_code']==1 and b'wrong CodeSource:' in stream(wrong,'stderr')}
        if not report['wrong_root_control']['rejected']: raise RuntimeError('wrong-root CodeSource control failed')
        jar=out/'target.jar'
        with zipfile.ZipFile(jar,'w') as z:
            for f in sorted(generated.rglob('*.class')):
                info=zipfile.ZipInfo(f.relative_to(generated).as_posix(),(1980,1,1,0,0,0)); info.compress_type=zipfile.ZIP_STORED; z.writestr(info,f.read_bytes())
        bundle=compare.pin(jar)
        report['original_classes']['bundle']=bundle
        for form,input_path,policy in (('child',target,'single-class'),('bundle-child',jar,'plain-jar')):
            for evidence in ('default','all'):
                argv=[cli,'class-source','--input',input_path,'--class',INTERNAL,'--policy',policy,'--release','8','--format','json']
                if evidence=='all': argv+=['--evidence','all']
                row=command(argv,f'jarde-{form}-{evidence}'); raw=stream(row); dest=out/'jarde'/form/evidence; dest.mkdir(parents=True)
                rp=dest/'report.json'; rp.write_bytes(raw); cell={'form':form,'evidence':evidence,'command':row['index'],'exit_code':row['exit_code'],'input':compare.pin(input_path),'report':compare.pin(rp)}
                try:
                    api=json.loads(raw.decode('utf-8','strict'))
                    cell['api']=api
                    if isinstance(api.get('text'),str):
                        whole=dest/'MultiEntryCounter.java'; whole.write_text(api['text'],encoding='utf-8')
                        cell.update({'whole_source':compare.pin(whole),'whole_source_path':str(whole)})
                    else:
                        cell['api_parse_error']='class response has no string text'
                except (ValueError,TypeError,UnicodeDecodeError) as error:
                    cell['api_parse_error']=str(error)
                report['jarde_cells'].append(cell); compare.write_json(out/'execution.json',report)
        # Compile each complete Jarde class projection under both Java 8 toolchains; keep all failures.
        for cell in report['jarde_cells']:
            if cell.get('exit_code')!=0 or 'whole_source_path' not in cell: continue
            source=Path(cell['whole_source_path'])
            for compiler in ('javac8','javac23'):
                dest=out/'jarde-compile'/cell['form']/cell['evidence']/compiler; dest.mkdir(parents=True,exist_ok=True)
                argv=[jdks[compiler]['tools']['javac'],'-source','8','-target','8','-g','-proc:none','-cp',empty,'-sourcepath',empty,'-d',dest,source] if compiler=='javac8' else [jdks[compiler]['tools']['javac'],'--release','8','-g','-proc:none','-cp',empty,'-sourcepath',empty,'-d',dest,source]
                cr=command(argv,f'jarde-source-{cell["form"]}-{cell["evidence"]}-{compiler}')
                item={'input_form':cell['form'],'evidence':cell['evidence'],'compiler':compiler,'source':compare.pin(source),
                      'command':cr['index'],'exit_code':cr['exit_code'],'class_tree':tree(dest)}
                if cr['exit_code']==0:
                    cls=dest/(INTERNAL+'.class'); fact=facts(cls,'compiled Jarde source')
                    require_target_facts(fact,'compiled Jarde source'); item['target_facts']=fact
                    item['runtime']=[]
                    for runtime in ('javac8','javac23'):
                        rr=command([sys.executable,'-B',RUNTIME_BOUND,'30',jdks[runtime]['tools']['java'],'-Xverify:all','-cp',driver_classes,'MultiEntryCounterDriver',dest,dest],
                                   f'jarde-source-runtime-{cell["form"]}-{cell["evidence"]}-{compiler}-{runtime}',runtime)
                        runtime_item={'runtime':runtime,'command':rr['index'],'exit_code':rr['exit_code'],
                                      'stdout':compare.pin(Path(rr['streams']['stdout']['path'])),'stderr':compare.pin(Path(rr['streams']['stderr']['path']))}
                        if rr['exit_code']==0:
                            runtime_item['rows']=parse_rows(stream(rr))
                            runtime_item['matches_original_oracle']=runtime_item['rows']==report['original_runtime'][0]['rows']
                        item['runtime'].append(runtime_item)
                report['jarde_generated'].append(item); compare.write_json(out/'execution.json',report)
        version=command([JADX,'--version'],'jadx-version')
        if version['exit_code']!=0 or b'1.5.6' not in stream(version)+stream(version,'stderr'): raise RuntimeError('JADX version mismatch')
        jd=out/'jadx'; row=command([JADX,'--threads-count','1','--no-res','--config','none','-d',jd,target],'jadx-full-target')
        files=sorted(jd.rglob('*.java')) if jd.exists() else []
        if row['exit_code']==0 and not files: raise RuntimeError('JADX succeeded without Java output')
        sources=[]
        for f in files: sources.append({'path':str(f),'pin':compare.pin(f),'text':f.read_text(encoding='utf-8')})
        output_tree={p.relative_to(jd).as_posix():compare.pin(p) for p in sorted(jd.rglob('*')) if p.is_file()} if jd.exists() else {}
        report['jadx_outputs']=[{'command':row['index'],'exit_code':row['exit_code'],'input':compare.pin(target),'output_tree':output_tree,'sources':sources}]
        jadx_compilers=('javac8','javac23') if row['exit_code']==0 else ()
        for compiler in jadx_compilers:
                dest=out/'jadx-compile'/compiler; dest.mkdir(parents=True,exist_ok=True)
                argv=[jdks[compiler]['tools']['javac'],'-source','8','-target','8','-g','-proc:none','-cp',empty,'-sourcepath',empty,'-d',dest,*files] if compiler=='javac8' else [jdks[compiler]['tools']['javac'],'--release','8','-g','-proc:none','-cp',empty,'-sourcepath',empty,'-d',dest,*files]
                cr=command(argv,f'jadx-source-{compiler}')
                item={'sources':[compare.pin(src) for src in files],'compiler':compiler,'command':cr['index'],'exit_code':cr['exit_code'],'class_tree':tree(dest)}
                if cr['exit_code']==0:
                    rels=sorted(item['class_tree'])
                    if rels!=['cf08/MultiEntryCounter.class']:
                        raise RuntimeError(f'JADX compiled class tree differs: {rels}')
                    gf=facts(dest/'cf08/MultiEntryCounter.class','compiled JADX source')
                    gm={(m[1],m[2]) for m in gf['layout']['methods']}
                    if gf['layout']['class_name']!=INTERNAL or gf['layout']['major']!=52 or gm!={('<init>','()V'),('test','(IZI)I')}:
                        raise RuntimeError('JADX generated target identity/method inventory differs')
                    item['compiled_facts']=gf
                    item['runtime']=[]
                    for runtime in ('javac8','javac23'):
                        rr=command([sys.executable,'-B',RUNTIME_BOUND,'30',jdks[runtime]['tools']['java'],'-Xverify:all','-cp',driver_classes,'MultiEntryCounterDriver',dest,dest],f'jadx-runtime-{compiler}-{runtime}',runtime)
                        runtime_item={'runtime':runtime,'command':rr['index'],'exit_code':rr['exit_code'],'stdout':compare.pin(Path(rr['streams']['stdout']['path'])),'stderr':compare.pin(Path(rr['streams']['stderr']['path']))}
                        if rr['exit_code']==0:
                            runtime_item['rows']=parse_rows(stream(rr))
                            runtime_item['matches_original_oracle']=runtime_item['rows']==report['original_runtime'][0]['rows']
                        item['runtime'].append(runtime_item)
                report['generated_compile_runtime'].append(item)
        compare.write_json(out/'execution.json',report)
        report['external_pins_after']=[compare.pin(p) for p in external]; report['source_pins_after']=compare.source_closure(root)
        report['local_copies_after']={'writer':compare.pin(writer_copy),'driver':compare.pin(driver_copy),
                                      'upstream':[compare.pin(Path(x['copy']['path'])) for x in copied_refs]}
        report['local_copies_unchanged']=report['local_copies_after']==local_copies_before
        report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
        if report['external_pins_after']!=external_before or report['source_pins_after']!=source_before or not report['target_absent'] or not report['local_copies_unchanged']:
            raise RuntimeError('final pin/target guard failed')
        report['counts']={'commands':len(rows),'raw_streams':2*len(rows),'original_runtime':len(report['original_runtime']),
            'jarde_api':len(report['jarde_cells']),'jarde_source_compiles':len(report['jarde_generated']),'jadx_sources':sum(len(x['sources']) for x in report['jadx_outputs']),
            'generated_compiles':len(report['generated_compile_runtime']),'generated_runtimes':sum(len(x.get('runtime',[])) for x in report['generated_compile_runtime'])}
        report['status']='captured-pending-independent-review'
    except BaseException as error:
        report['status']='failed'; report['error']=str(error); raise
    finally:
        report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        try:
            report['external_pins_after_finally']=[compare.pin(p) for p in external]
            report['local_copies_after_finally']={'writer':compare.pin(writer_copy),'driver':compare.pin(driver_copy),
                'upstream':[compare.pin(Path(x['copy']['path'])) for x in copied_refs]}
            report['local_copies_unchanged_finally']=report['local_copies_after_finally']==local_copies_before
            report['source_pins_after_finally']=compare.source_closure(root)
            report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
            if report['external_pins_after_finally']!=external_before or report['source_pins_after_finally']!=source_before or not report['target_absent_finally'] or not report['local_copies_unchanged_finally']:
                report['status']='failed'; report['final_guard_error']='final pins/target changed'
        except BaseException as error: report['status']='failed'; report['final_guard_error']=repr(error)
        compare.write_json(out/'execution.json',report)
        shutil.copy2(__file__,out/'collector.py')
        print(json.dumps({'status':report['status'],'commands':len(rows),'error':report.get('error')}))

def digest_name(path: Path) -> str:
    return hashlib.sha256(path.name.encode()).hexdigest()[:12]

if __name__=='__main__': raise SystemExit(main())
