from pathlib import Path
import json,hashlib,importlib.util,re,zipfile
R=Path('/Users/lordcasser/workspace/projects/jarde'); B=Path('/private/tmp/jarde-cf08-multientry-baseline-root-v1-20261019'); P=B/'execution.json'
assert hashlib.sha256(P.read_bytes()).hexdigest()=='da22ca92c26800ff92f7a3dfaf54007c3c315e01d9a335e58b52392dc0255f9a'
d=json.loads(P.read_text());assert d['status']=='captured-pending-independent-review' and len(d['commands'])==26
cache={}; records=0

def pin(row):
 global records
 p=Path(row['path']).resolve(strict=True)
 if p not in cache:
  b=p.read_bytes();cache[p]=(len(b),hashlib.sha256(b).hexdigest())
 assert cache[p]==(row['bytes'],row['sha256']),p
 records+=1;return p

def reopen(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys():pin(v)
  else:
   for c in v.values():reopen(c)
 elif isinstance(v,list):
  for c in v:reopen(c)
reopen(d)
for key in ('source_pins','external_pins','jdk_tool_pins','local_copies'):
 assert d[key+'_before']==d[key+'_after']==d[key+'_after_finally'],key
assert d['local_copies_unchanged'] and d['local_copies_unchanged_finally'] and d['target_absent'] and d['target_absent_finally']
assert not (R/'target').exists() and not (R/'target').is_symlink()

def load(p,name):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
comp=load(R/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','multi_comp')
phys=load('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py','multi_phys')
assert comp.source_closure(R)==d['source_pins_before']
cmd={r['index']:r for r in d['commands']};assert set(cmd)==set(range(1,27)) and len({r['label'] for r in cmd.values()})==26
for c in cmd.values():
 assert c['guard_stop'] is None and c['peak_target_bytes']<=1024**3 and c['free_bytes_after']>=5*1024**3
 for stream in ('stdout','stderr'):pin(c['streams'][stream])
jdks=d['jdk_manifest']['tools']; I='cf08/MultiEntryCounter'; expected_methods={('<init>','()V',1),('test','(IZI)I',9)}

def facts(p):
 a=comp.parse_class(p);q=phys.parse_class_file(p.read_bytes())
 assert a['major']==q['major']==52 and a['class_name']==q['class_name']==I and a['fields']==q['fields']==[]
 assert a['methods']==q['methods'] and {(m['name'],m['descriptor'],m['access']) for m in q['methods']}==expected_methods
 return a,q
origroot=Path(d['original_classes']['class_root']);assert set(d['original_classes']['class_tree'])=={I+'.class'}
p=pin(d['original_classes']['class_tree'][I+'.class']);a,q=facts(p);assert a==d['original_classes']['facts']['summary'] and q==d['original_classes']['facts']['physical']
test=next(m for m in q['methods'] if m['name']=='test')['code'];assert test=={'max_stack':1,'max_locals':3,'code_length':19,'code_hex':'1b9a00068400031c9900098402ffa7fff61aac','rows':[],'bcis':[0,1,4,7,8,11,14,17,18]}
layout=d['original_classes']['facts']['layout'];lc=next(m[3] for m in layout['methods'] if m[1]=='test');assert lc['stackmap_hex']=='0003040209' and lc['attribute_length']==42 and layout['trailing_bytes']==0
with zipfile.ZipFile(pin(d['original_classes']['bundle'])) as z:
 assert z.namelist()==[I+'.class'] and z.read(I+'.class')==p.read_bytes()
# Decode actual branch offsets independently; instruction-level SCC and external entries.
b=bytes.fromhex(test['code_hex']);assert 1+int.from_bytes(b[2:4],'big',signed=True)==7 and 8+int.from_bytes(b[9:11],'big',signed=True)==17 and 14+int.from_bytes(b[15:17],'big',signed=True)==4
edges={0:[1],1:[4,7],4:[7],7:[8],8:[11,17],11:[14],14:[4],17:[18],18:[]};scc={4,7,8,11,14}
assert {v for u,vs in edges.items() for v in vs if u not in scc and v in scc}=={4,7}
for start in scc:
 seen=set();todo=[start]
 while todo:
  u=todo.pop()
  if u in seen:continue
  seen.add(u);todo.extend(v for v in edges[u] if v in scc)
 assert seen==scc
# Raw stdout compared against an independent wrapped-int formula, rather than the driver expected column alone.
def rows(c):
 lines=pin(c['streams']['stdout']).read_text().splitlines();assert len(lines)==12
 out=[]
 for i,line in enumerate(lines):
  m=re.fullmatch(r'CASE index=(\d+) name=(ordinary|overflow)-skip-(false|true)-steps-([0-2]) initial=(-?\d+) actual=(-?\d+) expected=(-?\d+)',line);assert m,line
  idx,kind,skip,steps,initial,actual,expected=m.groups();steps=int(steps);initial=int(initial)
  assert int(idx)==i and kind==('ordinary' if i<6 else 'overflow') and skip==('false' if i%6<3 else 'true') and steps==i%3
  assert initial==(17 if kind=='ordinary' else 2147483646)
  value=(initial+3*(steps+(skip=='false'))+2**31)%2**32-2**31
  assert int(actual)==int(expected)==value
  out.append(line)
 return out
D=B/'driver-classes'; oracle=None

def runtime(c,target,vm):
 argv=c['argv'];assert c['exit_code']==0 and c['tool_leg']==vm and len(argv)==11 and argv[1]=='-B' and argv[3]=='30'
 assert Path(argv[2])==pin(d['runtime_wrapper']) and Path(argv[4])==pin(jdks[vm]['java']) and argv[5:7]==['-Xverify:all','-cp']
 assert Path(argv[7])==D and argv[8]=='MultiEntryCounterDriver' and Path(argv[9])==target and Path(argv[10])==target
 return rows(c)
assert {(r['runtime']) for r in d['original_runtime']}=={'javac8','javac23'}
for r in d['original_runtime']:
 out=runtime(cmd[r['command']],origroot,r['runtime']);assert oracle is None or oracle==out;oracle=out
wc=cmd[d['wrong_root_control']['command']];assert wc['exit_code']==1 and d['wrong_root_control']['rejected'] and b'wrong CodeSource:' in pin(wc['streams']['stderr']).read_bytes() and wc['argv'][-1]!=wc['argv'][-2]
api={}
for c in d['jarde_cells']:
 command=cmd[c['command']];assert command['exit_code']==c['exit_code']==0
 raw=pin(c['report']).read_bytes();assert raw==pin(command['streams']['stdout']).read_bytes();doc=json.loads(raw);assert doc==c['api'] and pin(c['whole_source']).read_text()==doc['text']
 assert {(m['item']['name']['escaped'],m['item']['descriptor']['escaped']) for m in doc['methods']}=={(n,s) for n,s,_ in expected_methods}
 for m in doc['methods']:
  body=m['outcome']['report'];assert m['item']['identity']['owner']==doc['class'] and doc['class']['class_bytes']['length']==p.stat().st_size
  if m['item']['name']['escaped']=='test':
   assert body['quality']=='fallback' and body['fallbacks']==['jre_region_irreducible'] and '[4, 7, 11]' in body['text']
  else:assert body['quality']=='structured' and body['fallbacks']==[]
 api[c['form'],c['evidence']]=doc
assert set(api)=={(f,e) for f in ('child','bundle-child') for e in ('default','all')}
for form in ('child','bundle-child'):
 x,y=api[form,'default'],api[form,'all'];assert x['text']==y['text']
 for mx,my in zip(x['methods'],y['methods']):
  assert mx['outcome']['report']['text']==my['outcome']['report']['text'] and mx['outcome']['report']['source_map']==my['outcome']['report']['source_map']
assert len(d['jarde_generated'])==8
for r in d['jarde_generated']:
 c=cmd[r['command']];assert c['exit_code']==r['exit_code']==1 and c['tool_leg']==r['compiler'] and Path(c['argv'][0])==pin(jdks[r['compiler']]['javac'])
 assert r['class_tree']=={} and 'runtime' not in r
 err=pin(c['streams']['stderr']).read_bytes();assert ('缺少返回语句'.encode() in err or b'missing return statement' in err)
j=d['jadx_outputs'][0];assert cmd[j['command']]['exit_code']==j['exit_code']==0 and len(j['sources'])==1
assert {str(x.resolve()) for x in (B/'jadx').rglob('*.java')}=={str(pin(s['pin'])) for s in j['sources']}
assert len(d['generated_compile_runtime'])==2
for r in d['generated_compile_runtime']:
 c=cmd[r['command']];assert c['exit_code']==r['exit_code']==0 and c['tool_leg']==r['compiler'] and Path(c['argv'][0])==pin(jdks[r['compiler']]['javac'])
 assert set(r['class_tree'])=={I+'.class'};cp=pin(r['class_tree'][I+'.class']);facts(cp);target=cp.parents[1]
 assert {v['runtime'] for v in r['runtime']}=={'javac8','javac23'}
 for v in r['runtime']:assert v['matches_original_oracle'] and runtime(cmd[v['command']],target,v['runtime'])==oracle
res={'status':'root_accepted_constructed_multientry_gap_baseline','receipt_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'commands':26,'raw_streams':52,'unique_pinned_paths':len(cache),'pin_records_reopened':records,'original_vm_runs':2,'original_observations':24,'jarde_api_cells':4,'jarde_missing_return_compile_failures':8,'jarde_vm_runs':0,'jadx_compile_successes':2,'jadx_vm_runs':4,'jadx_observations':48,'independent_wrapped_int_oracle_matches':True,'scc_external_entries':[4,7],'irreducible_basic_blocks':[4,7,11],'limitations':'Constructed JVM control; not original Smali/DEX equivalence or full CF08 coverage. Root read full writer/driver and verified class Code/frames statically; no product change.'}
(Path(__file__).parent/'review.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
