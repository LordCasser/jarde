#!/usr/bin/env python3
"""Pack the fixed CF07 original/generated loop evidence after root acceptance."""
from __future__ import annotations
import argparse, hashlib, io, json, tarfile
from pathlib import Path

PRIVATE = Path('/private/tmp').resolve()
REPO = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
PREP = Path(__file__).resolve().parent
DEST = REPO / 'openspec/evidence/java-syntax-2026-10-19/cf07-fixed-original-loops-root-v1'
ROOT_NAMES = (
 'jarde-complex-while-loop-baseline-prep-luna-v1-20261019',
 'jarde-complex-while-loop-baseline-root-v1-20261019',
 'jarde-complex-while-loop-baseline-wrapper-root-v1-20261019',
 'jarde-complex-while-loop-baseline-audit-luna-v1-20261019',
 'jarde-complex-while-loop-baseline-audit-root-v1-20261019',
 'jarde-complex-while-loop-generated-prep-luna-v2-20261019',
 'jarde-complex-while-loop-generated-root-v1-20261019',
 'jarde-complex-while-loop-generated-wrapper-root-v1-20261019',
 'jarde-complex-while-loop-generated-review-root-v1-20261019',
 'jarde-testloopcondition5-baseline-prep-luna-v2-20261019',
 'jarde-testloopcondition5-baseline-root-v1-20261019',
 'jarde-testloopcondition5-baseline-wrapper-root-v1-20261019',
 'jarde-testloopcondition5-baseline-audit-luna-v1-20261019',
 'jarde-testloopcondition5-baseline-audit-root-v1-20261019',
 'jarde-testloopcondition5-generated-prep-luna-v1-20261019',
 'jarde-testloopcondition5-generated-root-v1-20261019',
 'jarde-testloopcondition5-generated-wrapper-root-v1-20261019',
 'jarde-testloopcondition5-generated-review-root-v1-20261019',
 'jarde-loop-condition2-baseline-prep-luna-v2-20261019',
 'jarde-loop-condition2-baseline-root-v1-20261019',
 'jarde-loop-detection2-baseline-prep-luna-v2-20261019',
 'jarde-loop-detection2-baseline-root-v1-20261019',
 'jarde-cf07-condition2-detection2-baseline-wrapper-root-v1-20261019',
 'jarde-loopcondition2-detection2-baseline-audit-luna-v1-20261019',
 'jarde-loopcondition2-detection2-baseline-audit-luna-v2-20261019',
 'jarde-loop-condition2-generated-prep-luna-v1-20261019',
 'jarde-loop-condition2-generated-root-v1-20261019',
 'jarde-loop-condition2-generated-review-root-v1-20261019',
 'jarde-loop-detection2-generated-prep-luna-v1-20261019',
 'jarde-loop-detection2-generated-root-v1-20261019',
 'jarde-loop-detection2-generated-review-root-v1-20261019',
 'jarde-cf07-condition2-detection2-generated-wrapper-root-v1-20261019',
 'jarde-cf07-three-fixed-audit-luna-v1-20261019',
 'jarde-cf07-final-fixed-audit-root-v1-20261019',
 'jarde-cf07-four-fixed-architecture-root-v1-20261019',
 'jarde-assignment-condition-widening-final-compare-prep-luna-v9-20261019',
 'jarde-complex-while-loop-generated-prep-luna-v1-20261019',
 'jarde-testloopcondition5-baseline-prep-luna-v1-20261019',
 'jarde-loop-condition2-baseline-prep-luna-v1-20261019',
 'jarde-loop-detection2-baseline-prep-luna-v1-20261019',
 'jarde-complex-while-loop-architecture-luna-v1-20261019',
 'jarde-complex-while-loop-next-static-root-v1-20261019',
 'jarde-cf07-fixed-original-loops-archive-prep-luna-v1-20261019',
)
RESULT_ROOTS = (
 'jarde-complex-while-loop-baseline-root-v1-20261019',
 'jarde-complex-while-loop-generated-root-v1-20261019',
 'jarde-testloopcondition5-baseline-root-v1-20261019',
 'jarde-testloopcondition5-generated-root-v1-20261019',
 'jarde-loop-condition2-baseline-root-v1-20261019',
 'jarde-loop-detection2-baseline-root-v1-20261019',
 'jarde-loop-condition2-generated-root-v1-20261019',
 'jarde-loop-detection2-generated-root-v1-20261019',
)
WRAPPER_ROOTS = (
 'jarde-complex-while-loop-baseline-wrapper-root-v1-20261019',
 'jarde-complex-while-loop-generated-wrapper-root-v1-20261019',
 'jarde-testloopcondition5-baseline-wrapper-root-v1-20261019',
 'jarde-testloopcondition5-generated-wrapper-root-v1-20261019',
 'jarde-cf07-condition2-detection2-baseline-wrapper-root-v1-20261019',
 'jarde-cf07-condition2-detection2-generated-wrapper-root-v1-20261019',
)
EXTERNAL_FILES = (
 ('upstream/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestComplexWhileLoop.java',
  '/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestComplexWhileLoop.java'),
 ('upstream/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestLoopCondition5.java',
  '/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestLoopCondition5.java'),
 ('upstream/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestLoopCondition2.java',
  '/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestLoopCondition2.java'),
 ('upstream/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestLoopDetection2.java',
  '/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestLoopDetection2.java'),
 ('jarde/openspec/changes/recover-exception-only-finally-completion/tools/compare.py',
  '/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-exception-only-finally-completion/tools/compare.py'),
 ('helpers/classfile_helpers.py',
  '/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py'),
 ('helpers/runtime-wrapper.py',
  '/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py'),
 ('upstream/jadx/JADX-LICENSE',
  '/Users/lordcasser/workspace/projects/jarde/tests/fixtures/java8/assignment-condition-widening/JADX-LICENSE'),
 ('upstream/jadx/JADX-NOTICE',
  '/Users/lordcasser/workspace/projects/jarde/tests/fixtures/java8/assignment-condition-widening/JADX-NOTICE'),
)
EXTERNAL_TREES = (
 ('legacy/java-syntax-2026-09-27/cf07-basic-loops',
  '/Users/lordcasser/workspace/projects/jarde/openspec/evidence/java-syntax-2026-09-27/cf07-basic-loops'),
)
EXCLUDED_COMPONENTS = {'candidate-cli','target','__pycache__','.pytest_cache','.mypy_cache','.ruff_cache','.cache','node_modules'}
ACTIVE = {'running','in_progress','started','collecting'}
ACCEPTED_PREFIX = 'root_accepted'
PREP_MEMBERS = ('README.md','scope-manifest.json','review.json','pins.json','pack_evidence.py')

def need(ok: bool, message: str) -> None:
 if not ok: raise ValueError(message)
def sha(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def pin(path: Path) -> dict:
 need(not path.is_symlink(),f'refuse symlink: {path}')
 path=path.resolve(strict=True); data=path.read_bytes()
 return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
def json_file(path: Path) -> dict: return json.loads(path.read_text(encoding='utf-8'))
def check_pin_record(rec: dict, label: str) -> Path:
 need(isinstance(rec,dict) and {'path','bytes','sha256'} <= rec.keys(),f'malformed pin: {label}')
 path=Path(rec['path']); actual=pin(path)
 need(actual['bytes']==rec['bytes'] and actual['sha256']==rec['sha256'],f'pin mismatch: {label}')
 return path
def check_result_acceptance():
 for name in RESULT_ROOTS:
  root=PRIVATE/name; need(root.is_dir(),f'missing result root: {root}')
  receipt=root/'execution.json'; need(receipt.is_file(),f'missing receipt: {receipt}')
  data=json_file(receipt); status=data.get('status','')
  need(status not in ACTIVE,f'result is still active: {receipt} ({status})')
  marker=root/'root-review.json'
  need(marker.is_file(),f'missing root acceptance marker: {marker}')
  review=json_file(marker); need(str(review.get('status','')).startswith(ACCEPTED_PREFIX),f'result is not root accepted: {marker}')
  if review.get('receipt_sha256') is not None:
   need(review['receipt_sha256']==sha(receipt.read_bytes()),f'root review is bound to another receipt: {marker}')
def check_wrappers():
 for name in WRAPPER_ROOTS:
  root=PRIVATE/name; need(root.is_dir(),f'missing wrapper root: {root}')
  d=json_file(root/'execution.json'); need(d.get('status') not in ACTIVE,f'wrapper still active: {name}')
  if d.get('collector'): check_pin_record(d['collector'],f'{name}/collector')
  if d.get('baseline'): check_pin_record(d['baseline'],f'{name}/baseline receipt')
  rows=d.get('commands')
  if isinstance(rows,list):
   need(bool(rows),f'empty wrapper command list: {name}')
   for row in rows:
    need(row.get('exit_code')==0,f'wrapper command did not finish successfully: {name}/{row.get("argv",["?"])[2]}')
    if row.get('program'): check_pin_record(row['program'],f'{name}/program')
    for ch in ('stdout','stderr'):
     if ch in row: check_pin_record(row[ch],f'{name}/{ch}')
  else:
   need(d.get('exit_code')==0,f'wrapper command failed: {name}')
   for ch in ('stdout','stderr'):
    if ch in d: check_pin_record(d[ch],f'{name}/{ch}')

def collect():
 files={}
 def add(arc,path):
  need(arc not in files,f'duplicate archive member path: {arc}')
  files[arc]=Path(path).resolve()
 for name in ROOT_NAMES:
  root=PRIVATE/name; need(root.is_dir(),f'missing selected evidence root: {root}')
  for path in root.rglob('*'):
   if any(part in EXCLUDED_COMPONENTS for part in path.parts): continue
   need(not path.is_symlink(),f'refuse symlink in evidence root: {path}')
   if path.is_file(): add('private-tmp/'+path.relative_to(PRIVATE).as_posix(),path)
 for arc,raw in EXTERNAL_FILES:
  path=Path(raw); need(path.is_file() and not path.is_symlink(),f'missing external source/helper: {path}')
  add(arc,path)
 for prefix,raw in EXTERNAL_TREES:
  root=Path(raw); need(root.is_dir() and not root.is_symlink(),f'missing legacy audit tree: {root}')
  for path in root.rglob('*'):
   need(not path.is_symlink(),f'refuse symlink in external tree: {path}')
   if path.is_file(): add(prefix+'/'+path.relative_to(root).as_posix(),path)
 for name in PREP_MEMBERS:
  path=PREP/name; need(path.is_file() and not path.is_symlink(),f'missing archive preparation member: {path}')
  add('archive-preparation/'+name,path)
 need(len(files)==len(set(files)), 'duplicate archive member')
 return dict(sorted(files.items()))
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--out',type=Path,default=DEST/'capture.tar.gz',help='new capture.tar.gz; default is the requested CF07 results folder')
 args=ap.parse_args(); out=args.out.resolve(); inventory_path=out.with_suffix(out.suffix+'.inventory.json')
 need(not out.exists() and not inventory_path.exists(),'refuse existing archive/inventory')
 need(not out.is_relative_to(PREP),'archive destination must be outside this preparation package')
 for name in ROOT_NAMES:
  root=PRIVATE/name
  if root.exists(): need(not out.is_relative_to(root),'archive output inside selected root')
 check_result_acceptance(); check_wrappers(); files=collect()
 rows=[]
 for arc,path in files.items():
  data=path.read_bytes(); rows.append({'path':arc,'bytes':len(data),'sha256':sha(data)})
 manifest={'schema':'cf07-fixed-original-generated-loops-archive-v1','status':'root-accepted-inputs-verified-at-pack-time',
  'member_count':len(rows),'members':rows,'selected_private_roots':list(ROOT_NAMES),
  'required_root_accepted_result_roots':list(RESULT_ROOTS),'wrapper_roots':list(WRAPPER_ROOTS),
  'external_files':[arc for arc,_ in EXTERNAL_FILES],'external_trees':[arc for arc,_ in EXTERNAL_TREES],
  'excluded_components':sorted(EXCLUDED_COMPONENTS),
  'scope_note':'Includes accepted actual-original and generated evidence plus the explicitly named 2026-09-27 composite legacy audit. No acceptance is inferred from a pending wrapper status.'}
 out.parent.mkdir(parents=True,exist_ok=True)
 with tarfile.open(out,'x:gz') as tar:
  for arc,path in files.items(): tar.add(path,arcname=arc,recursive=False)
  blob=(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
  info=tarfile.TarInfo('ARCHIVE_INVENTORY.json'); info.size=len(blob); info.mode=0o644
  tar.addfile(info,io.BytesIO(blob))
 with tarfile.open(out,'r:gz') as tar:
  members={m.name:m for m in tar.getmembers() if m.isfile()}
  need(set(members)=={r['path'] for r in rows}|{'ARCHIVE_INVENTORY.json'},'archive member set mismatch')
  for r in rows:
   data=tar.extractfile(members[r['path']]).read()
   need(len(data)==r['bytes'] and sha(data)==r['sha256'],f'tar reopen mismatch: {r["path"]}')
  need(json.loads(tar.extractfile(members['ARCHIVE_INVENTORY.json']).read())==manifest,'embedded inventory mismatch')
 inv=(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
 with inventory_path.open('xb') as f: f.write(inv)
 print(json.dumps({'status':'packed-and-reopened','archive':str(out),'archive_sha256':sha(out.read_bytes()),
  'inventory':str(inventory_path),'inventory_sha256':sha(inv),'member_count':len(rows)},indent=2))
if __name__=='__main__': main()
