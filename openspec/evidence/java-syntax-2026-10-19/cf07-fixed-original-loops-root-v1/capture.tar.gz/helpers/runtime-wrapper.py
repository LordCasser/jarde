import subprocess,sys
argv=sys.argv[2:];seconds=float(sys.argv[1]);p=subprocess.Popen(argv)
try:sys.exit(p.wait(timeout=seconds))
except subprocess.TimeoutExpired:
 p.kill();p.wait();print('ROOT_RUNTIME_TIMEOUT_SECONDS='+str(seconds),file=sys.stderr);sys.exit(124)
