# ComplexWhileLoop generated-source matrix preparation

This private, unexecuted v2 adapts the root-accepted LoopConditionInvoke generated-matrix v5 collector (SHA-256 `1a1b14124232a40ff527159e602a96c01b36e8d3a03a675c23b0f6d8c72b6cd5`). The earlier ComplexWhileLoop v1 is retained unchanged as a rejected, unexecuted preparation; its three schema/profile issues are corrected here. It uses the completed ComplexWhileLoop baseline receipt and does not run the collector, compilers, JVMs, Jarde CLI, or JADX.

The frozen baseline receipt is `/private/tmp/jarde-complex-while-loop-baseline-root-v1-20261019/execution.json` (SHA-256 `467454387456ea34573e95b9d79b076d89b5d2c955cf14332ada98db0d2163f2`), and its observed CLI is `/private/tmp/jarde-assignment-condition-widening-broad-resume-root-v1-20261019/candidate-cli` (SHA-256 `96e534b0000fe91c1d34a282919479a97eb4706063501d188cdff010c4640366`). The collector requires both paths and hashes explicitly and rechecks them before work.

The source matrix has eight saved Jarde child-class sources (two profiles × child/bundle-child × default/all) and two complete JADX outer-class source outputs. Each Jarde source is compiled unchanged as a standalone child source; each JADX output remains the complete outer source containing the nested child. The expected generated class trees are checked exactly before a compile is runtime-eligible. A mismatch or compilation refusal remains recorded and receives no runtime rows.

Each eligible compile runs the seven frozen finite cases on both configured JVMs and checks the corresponding original profile/runtime projection. The projection includes case order, input, returned value, exception class, and target stdout; VM-specific exception message and stack are preserved in raw rows but excluded from the cross-VM semantic comparison. Wrong-CodeSource checks require exit code 1 and the driver’s explicit `wrong CodeSource:` diagnostic.

The inherited guards retain clean environment handling, command timeout/resource checks, at least 5 GiB free space, the 1 GiB target cap, absent target directory, original/raw artifact pin validation, stable inputs/source closure, and before/after/finally output checks. The original JDK8 major-55 boundary remains a recorded compile outcome, not a runtime cell.

A static Python AST parse of the prepared collector and receipt-shape checks passed. No collector, compiler, runtime, or CLI command was executed. Run only after independent review, with a fresh output path:

```sh
python3 -B /private/tmp/jarde-complex-while-loop-generated-prep-luna-v1-20261019/collect_generated_matrix.py \
  --baseline /private/tmp/jarde-complex-while-loop-baseline-root-v1-20261019/execution.json \
  --baseline-sha256 467454387456ea34573e95b9d79b076d89b5d2c955cf14332ada98db0d2163f2 \
  --cli /private/tmp/jarde-assignment-condition-widening-broad-resume-root-v1-20261019/candidate-cli \
  --out /private/tmp/jarde-complex-while-loop-generated-root-v1-20261019
```

`collector-adaptation.diff` records the exact delta from accepted LoopConditionInvoke v5. The v2 delta also applies the three v5 corrections: recursive tuple/list normalization for complete physical facts, main-scope `original_profiles` for generated inventory checks, and removal of the invalid `profile_rows` reference from runtime eligibility. `pins.json` lists the receipt, tools, driver, template, collector, and prepared output hashes.
