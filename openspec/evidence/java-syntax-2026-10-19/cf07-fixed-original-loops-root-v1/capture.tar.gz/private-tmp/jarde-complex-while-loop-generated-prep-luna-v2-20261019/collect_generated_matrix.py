#!/usr/bin/env python3
"""Rebuild complete saved TestComplexWhileLoop sources and compare bounded runtime observations.

Preparation only: invoke explicitly with a completed baseline receipt and its SHA.
This collector is intentionally not run while being prepared.
"""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, re, shutil, sys, zipfile
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
COMPARE_REL='openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD_REL='openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL='openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_REL='openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
BASELINE_PATH=Path('/private/tmp/jarde-complex-while-loop-baseline-root-v1-20261019/execution.json')
BASELINE_SHA='467454387456ea34573e95b9d79b076d89b5d2c955cf14332ada98db0d2163f2'
BASELINE_SCHEMA='test-complex-while-loop-full-source-baseline-v1'
INTERNAL='jadx/tests/integration/loops/TestComplexWhileLoop$TestCls'
OUTER='jadx/tests/integration/loops/TestComplexWhileLoop'
DRIVER_NAME='TestComplexWhileLoopDriver'
DRIVER_SHA='57e8b55c175bc077e85ffcf9a16c053985ecbc310eadc023dd0467da2f2932c5'
PROFILES=('debug','no-debug'); EVIDENCE=('default','all'); FORMS=('child','bundle-child')
LEGS=('javac8','javac23'); RUNTIMES=('javac8','javac23')
EXPECTED_METHODS={('<init>','()V'),('test','([Ljava/lang/String;)Ljava/lang/String;')}
CASE_NAMES=('null-array','empty-array','first-null','first-one-char',
            'nonmatches-then-one-char','nonmatches-then-null','single-space-trims-empty')
CURRENT_CLI_SHA='96e534b0000fe91c1d34a282919479a97eb4706063501d188cdff010c4640366'
ENV_STRIP=('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','CARGO_TARGET_DIR')

def sha_bytes(data): return hashlib.sha256(data).hexdigest()
def sha_file(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
 return h.hexdigest()
def json_normalize(value):
 if isinstance(value,dict): return {key:json_normalize(item) for key,item in value.items()}
 if isinstance(value,(list,tuple)): return [json_normalize(item) for item in value]
 return value
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path)
 if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
 mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def exact_pin(compare,row,label):
 if not isinstance(row,dict) or not {'path','bytes','sha256'}<=row.keys(): raise RuntimeError(f'{label}: invalid pin')
 p=Path(row['path']).resolve(strict=True)
 if compare.pin(p)!=row: raise RuntimeError(f'{label}: pin mismatch {p}')
 return p
def filetree(compare,root): return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*')) if p.is_file()}
def parse_profile_facts(compare,physical,root):
 files=sorted(root.rglob('*.class'))
 facts={}
 for p in files:
  rel=p.relative_to(root).as_posix(); f=compare.parse_class(p); q=physical.parse_class_file(p.read_bytes())
  if q['class_name']!=f['class_name'] or q['major']!=f['major'] or q['methods']!=f['methods']:
   raise RuntimeError(f'parser disagreement: {rel}')
  if sorted((x['name'],x['descriptor'],x['access']) for x in q['fields'])!=sorted(f['fields']):
   raise RuntimeError(f'field parser disagreement: {rel}')
  f['access']=q['access']
  keys={(m['name'],m['descriptor']) for m in f['methods']}
  if len(keys)!=len(f['methods']): raise RuntimeError(f'duplicate method: {rel}')
  for m in f['methods']:
   c=m.get('code')
   if c is None or not c.get('bcis') or c['bcis'][0]!=0 or c['bcis'][-1]>=c['code_length']:
    raise RuntimeError(f'invalid physical Code/BCI: {rel}:{m["name"]}{m["descriptor"]}')
  if f['major']!=52: raise RuntimeError(f'compiled class is not Java 8 major 52: {rel}')
  facts[rel]=f
 if INTERNAL+'.class' not in facts: raise RuntimeError('compiled tree lacks the target nested class')
 target=facts[INTERNAL+'.class']
 if target['class_name']!=INTERNAL:
  raise RuntimeError('compiled target binary name differs')
 return facts
def source_cells(baseline,compare,commands_by_id,artifact_by_command):
 cells=[]; jarde_rows=baseline.get('jarde_cells',[])
 if len(jarde_rows)!=8: raise RuntimeError(f'expected exact eight Jarde API cells, got {len(jarde_rows)}')
 profile_rows={row.get('profile'):row for row in baseline.get('source_profiles',[])}
 if set(profile_rows)!=set(PROFILES): raise RuntimeError('baseline source-profile grid is incomplete')
 expected_class_tree={INTERNAL+'.class',OUTER+'.class'}
 for profile,profile_row in profile_rows.items():
  if profile_row.get('exit_code')!=0 or set(profile_row.get('class_tree',{}))!=expected_class_tree:
   raise RuntimeError(f'original {profile} full-source class tree is incomplete')
  target=profile_row.get('target_facts',{})
  if target.get('class_name')!=INTERNAL or {(m.get('name'),m.get('descriptor')) for m in target.get('methods',[])}!=EXPECTED_METHODS:
   raise RuntimeError(f'original {profile} child physical method inventory differs')
 selectors=set()
 for row in jarde_rows:
  profile=row.get('profile'); form=row.get('input_form'); evidence=row.get('evidence')
  if profile not in PROFILES or form not in FORMS or evidence not in EVIDENCE: raise RuntimeError('unexpected Jarde selector')
  key=(profile,form,evidence)
  if key in selectors: raise RuntimeError(f'duplicate Jarde selector {key}')
  selectors.add(key)
  report_pin=row.get('report'); report_path=exact_pin(compare,report_pin,'Jarde report')
  if report_path.read_bytes()!=artifact_by_command(row['command']):
   raise RuntimeError('Jarde API report bytes differ from its raw command stdout')
  source_pin=row.get('whole_source'); src=exact_pin(compare,source_pin,'Jarde whole source') if source_pin else None
  report_doc=None; report_error=None
  try: report_doc=json.loads(report_path.read_text(encoding='utf-8'))
  except (ValueError,UnicodeDecodeError) as exc: report_error=f'Jarde report JSON unavailable: {exc}'
  if report_doc is not None:
   api_keys={(m.get('item',{}).get('name',{}).get('escaped'),m.get('item',{}).get('descriptor',{}).get('escaped'))
             for m in report_doc.get('methods',[])}
   summary_keys={(m.get('name'),m.get('descriptor')) for m in row.get('methods',[])}
   if api_keys!=summary_keys: raise RuntimeError('Jarde API method summary differs from saved raw report')
   if src is not None:
    if report_doc.get('text','').encode('utf-8')!=src.read_bytes(): raise RuntimeError('Jarde report/source text mismatch')
   elif row.get('exit_code')==0:
    report_error='successful Jarde API cell has no whole-source artifact'
  input_path=exact_pin(compare,row.get('input'),'Jarde original class input')
  profile_row=profile_rows[profile]
  expected_input=(Path(profile_row['class_root'])/(INTERNAL+'.class')) if form=='child' else Path(profile_row['bundle']['path'])
  if input_path.resolve()!=expected_input.resolve() or compare.pin(input_path)!=compare.pin(expected_input):
   raise RuntimeError(f'Jarde source cell is not bound to its matching original {profile}/{form} input')
  method_keys={(m.get('name'),m.get('descriptor')) for m in row.get('methods',[])}
  source_available=(row.get('exit_code')==0 and report_doc is not None and src is not None
                    and row.get('method_inventory_matches') is True and method_keys==EXPECTED_METHODS
                    and src.stat().st_size>0)
  reason=None if source_available else (report_error or 'Jarde source/API inventory is unavailable or incomplete')
  cells.append({'kind':'jarde','profile':profile,'form':form,'evidence':evidence,'source_pins':[source_pin] if src is not None else [],
                'report_pin':report_pin,'input_pins':[row['input']],'source_paths':[str(src)] if src else [],
                'cell_key':[profile,form,evidence],'producer_exit_code':row.get('exit_code'),
                'source_available':source_available,'source_unavailable_reason':reason})
 if selectors!={(p,f,e) for p in PROFILES for f in FORMS for e in EVIDENCE}:
  raise RuntimeError('baseline Jarde selector grid is incomplete')
 jrows=baseline.get('jadx_outputs',[])
 if len(jrows)!=2 or {(x.get('compiler_profile'),x.get('display_profile')) for x in jrows}!={(p,'default') for p in PROFILES}:
  raise RuntimeError('baseline JADX compiler/display profile grid incomplete')
 for row in jrows:
  profile=row.get('compiler_profile'); paths=[]; reason=None
  for source_pin in row.get('sources',[]): paths.append(exact_pin(compare,source_pin,'JADX full source'))
  input_path=exact_pin(compare,row.get('input'),'JADX baseline class bundle')
  expected_bundle=Path(profile_rows[profile]['bundle']['path'])
  if input_path.resolve()!=expected_bundle.resolve() or compare.pin(input_path)!=compare.pin(expected_bundle):
   raise RuntimeError(f'JADX full source is not bound to its matching original {profile} bundle')
  has_outer=any(p.name=='TestComplexWhileLoop.java' for p in paths)
  available=row.get('exit_code')==0 and bool(paths) and has_outer and all(p.suffix=='.java' for p in paths)
  if not available: reason='JADX full source tree is incomplete or its command failed'
  # The complete saved output tree is re-enumerated against the command's actual -d destination below.
  cells.append({'kind':'jadx','profile':profile,'form':'bundle','evidence':'source','source_pins':row.get('sources',[]),
                'input_pins':[row['input']],'source_paths':[str(p) for p in paths],'cell_key':[profile,'bundle'],
                'source_available':available,'source_unavailable_reason':reason,'producer_exit_code':row.get('exit_code'),'jadx_command':row.get('command')})
 if {c['profile'] for c in cells if c['kind']=='jadx'}!=set(PROFILES): raise RuntimeError('JADX profile grid is incomplete')
 return cells

def parse_oracle(raw):
 import base64
 pattern=re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) target_stdout_b64=([^ ]*)$')
 lines=raw.decode('utf-8','strict').splitlines()
 if len(lines)!=len(CASE_NAMES): raise ValueError(f'expected {len(CASE_NAMES)} rows, got {len(lines)}')
 def decode(value): return base64.b64decode(value,validate=True).decode('utf-8','strict')
 rows=[]
 for i,line in enumerate(lines):
  m=pattern.fullmatch(line)
  if not m: raise ValueError(f'malformed oracle line {line!r}')
  index,name,input_b64,result_b64,exc,message_b64,stack_b64,target_stdout_b64=m.groups()
  if int(index)!=i or name!=CASE_NAMES[i]: raise ValueError(f'oracle case identity/order mismatch: {line!r}')
  rows.append({'index':i,'name':name,'input':decode(input_b64),'result':decode(result_b64),'exception_type':exc,
               'exception_message':decode(message_b64),'exception_stack':decode(stack_b64),
               'target_stdout':decode(target_stdout_b64),'raw':line})
 return rows

def projection(rows): return [{k:r[k] for k in ('index','name','input','result','exception_type','target_stdout')} for r in rows]
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--baseline',type=Path,required=True,help='completed execution.json from the accepted current baseline')
 ap.add_argument('--baseline-sha256',required=True,help='SHA-256 of that exact completed receipt')
 ap.add_argument('--cli',type=Path,required=True,help='the pinned v2 CLI path; this stage does not execute it')
 ap.add_argument('--out',type=Path,required=True); ap.add_argument('--root',type=Path,default=ROOT)
 a=ap.parse_args(); root=a.root.resolve(strict=True); bp=a.baseline.resolve(strict=True); out=a.out.resolve(); cli=a.cli.resolve(strict=True)
 if not re.fullmatch('[0-9a-f]{64}',a.baseline_sha256): raise SystemExit('baseline SHA must be explicit 64-character lowercase hex')
 if bp!=BASELINE_PATH.resolve() or a.baseline_sha256!=BASELINE_SHA or sha_file(bp)!=BASELINE_SHA:
  raise SystemExit('baseline path or SHA differs from the frozen ComplexWhileLoop receipt')
 if root!=ROOT.resolve(): raise SystemExit('workspace differs from pinned root')
 if out.exists(): raise SystemExit(f'refusing existing output {out}')
 if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('target must be absent')
 if shutil.disk_usage(root).free<5*1024**3: raise SystemExit('workspace free space below 5 GiB')
 compare_path=root/COMPARE_REL; guard_path=root/GUARD_REL; scanner_path=root/SCANNER_REL; jdk_path=root/JDK_REL
 for p,h,n in ((compare_path,COMPARE_SHA,'compare'),(guard_path,GUARD_SHA,'guard'),(scanner_path,SCANNER_SHA,'scanner'),(jdk_path,JDK_SHA,'JDK manifest'),(PARSER,PARSER_SHA,'full physical parser')):
  if sha_file(p)!=h: raise SystemExit(f'{n} pin mismatch')
 compare=load(compare_path,'nested_current_compare'); guard=load(guard_path,'nested_current_guard'); scanner=load(scanner_path,'nested_current_scanner'); physical=load(PARSER,'nested_current_physical')
 jdks,jdk_record=compare.configured_jdks(jdk_path,JDK_SHA)
 baseline=json.loads(bp.read_text(encoding='utf-8'))
 if baseline.get('schema')!=BASELINE_SCHEMA or baseline.get('status')!='captured-pending-independent-review': raise SystemExit('baseline receipt is not the completed expected capture')
 baseline_pin=compare.pin(bp)
 if baseline_pin['sha256']!=a.baseline_sha256: raise SystemExit('normalized baseline pin differs from explicit SHA')
 if baseline.get('source_unchanged') is not True or baseline.get('source_unchanged_finally') is not True or baseline.get('target_absent') is not True or baseline.get('target_absent_finally') is not True or baseline.get('external_inputs_unchanged') is not True: raise SystemExit('baseline source/tool/target gates failed')
 external_before_doc=baseline.get('external_input_pins_before'); external_after_doc=baseline.get('external_input_pins_after_finally')
 if not isinstance(external_before_doc,dict) or external_before_doc!=external_after_doc: raise SystemExit('baseline external source/tool pins changed')
 for pin in external_before_doc.get('files',[]): exact_pin(compare,pin,'baseline external tool/source')
 for pin in external_before_doc.get('dependency_artifacts',[]): exact_pin(compare,pin,'baseline dependency artifact')
 if compare.pin(cli).get('sha256')!=CURRENT_CLI_SHA or baseline.get('cli')!=compare.pin(cli) or Path(baseline['cli']['path']).resolve()!=cli: raise SystemExit('baseline CLI path/content differs from current pinned CLI')
 commands={r['index']:r for r in baseline.get('commands',[])}
 if len(commands)!=len(baseline.get('commands',[])): raise SystemExit('duplicate baseline command ids')
 for row in commands.values():
  if row.get('guard_stop') is not None: raise SystemExit(f'baseline guard stopped: {row.get("label")}')
  compare.command_artifact(row,'stdout'); compare.command_artifact(row,'stderr')
 if len(baseline.get('original_runtime',[]))!=4: raise SystemExit('baseline must have four original profile/runtime oracle runs')
 oracles={}
 for row in baseline['original_runtime']:
  if row.get('exit_code')!=0 or row.get('profile') not in PROFILES or row.get('runtime') not in RUNTIMES: raise SystemExit('invalid original oracle row')
  cmd=commands.get(row.get('command'))
  if cmd is None or cmd.get('exit_code')!=0 or cmd.get('label')!=f"original-runtime-{row.get('profile')}-{row.get('runtime')}":
   raise SystemExit('oracle row is not linked to its successful profile/runtime command')
  rows=parse_oracle(compare.command_artifact(cmd,'stdout'))
  if row.get('rows')!=rows: raise SystemExit('saved oracle rows differ from raw stdout')
  oracles[(row['profile'],row['runtime'])]=projection(rows)
 if set(oracles)!={(p,r) for p in PROFILES for r in RUNTIMES}: raise SystemExit('oracle profile/runtime grid incomplete')
 if baseline.get('runtime_semantic_agreement') is not True: raise SystemExit('original four-cell oracle agreement is false')
 wrong=baseline.get('wrong_root_control')
 if not isinstance(wrong,dict) or wrong.get('exit_code')!=1 or wrong.get('rejected') is not True: raise SystemExit('original wrong-CodeSource control is invalid')
 original_profiles={row.get('profile'):row for row in baseline.get('source_profiles',[])}
 if set(original_profiles)!=set(PROFILES): raise SystemExit('original compiler profile grid incomplete')
 expected_original_tree={INTERNAL+'.class',OUTER+'.class'}
 for profile,row in original_profiles.items():
  if row.get('exit_code')!=0 or set(row.get('class_tree',{}))!=expected_original_tree:
   raise SystemExit(f'original {profile} outer/child class tree incomplete')
  class_root=Path(row['class_root']).resolve(strict=True)
  actual_tree={p.relative_to(class_root).as_posix():compare.pin(p) for p in sorted(class_root.rglob('*.class'))}
  expected_tree={rel:{'bytes':pin['bytes'],'sha256':pin['sha256']} for rel,pin in row['class_tree'].items()}
  actual_compact={rel:{'bytes':pin['bytes'],'sha256':pin['sha256']} for rel,pin in actual_tree.items()}
  if actual_compact!=expected_tree: raise SystemExit(f'original {profile} classfile pins differ from baseline receipt')
  facts=parse_profile_facts(compare,physical,class_root)
  if json_normalize(facts[INTERNAL+'.class'])!=json_normalize(row.get('target_facts')) or json_normalize(facts[OUTER+'.class'])!=json_normalize(row.get('outer_facts')):
   raise SystemExit(f'original {profile} full physical class/Code/BCI facts differ from baseline receipt')
  bundle=exact_pin(compare,row.get('bundle'),'original full outer/child bundle')
  with zipfile.ZipFile(bundle) as archive:
   names=sorted(name for name in archive.namelist() if not name.endswith('/'))
   if names!=sorted(expected_original_tree): raise SystemExit(f'original {profile} bundle is not the exact complete class tree')
   for rel in expected_original_tree:
    if archive.read(rel)!=(class_root/rel).read_bytes(): raise SystemExit(f'original {profile} bundle differs from class root for {rel}')
 commands_by_id={r['index']:r for r in baseline.get('commands',[])}
 if len(commands_by_id)!=len(baseline.get('commands',[])): raise SystemExit('duplicate baseline command ids')
 def artifact_by_command(index):
  row=commands_by_id.get(index)
  if row is None or row.get('label') not in {f'jarde-{p}-{f}-{e}' for p in PROFILES for f in FORMS for e in EVIDENCE}:
   raise RuntimeError(f'Jarde cell is not linked to an expected command: {index}')
  return compare.command_artifact(row,'stdout')
 for cell in baseline.get('jarde_cells',[]):
  command_row=commands_by_id.get(cell.get('command'))
  if command_row is None or command_row.get('label')!=f"jarde-{cell.get('profile')}-{cell.get('input_form')}-{cell.get('evidence')}":
   raise SystemExit('baseline Jarde cell command identity mismatch')
  if command_row.get('exit_code')!=cell.get('exit_code'): raise SystemExit('baseline Jarde cell exit differs from raw command')
  compare.command_artifact(command_row,'stdout'); compare.command_artifact(command_row,'stderr')
 for cell in baseline.get('jadx_outputs',[]):
  command_row=commands_by_id.get(cell.get('command'))
  if command_row is None or command_row.get('label')!=f"jadx-full-bundle-{cell.get('compiler_profile')}-default":
   raise SystemExit('baseline JADX output command identity mismatch')
  if command_row.get('exit_code')!=cell.get('exit_code'): raise SystemExit('baseline JADX exit differs from raw command')
  compare.command_artifact(command_row,'stdout'); compare.command_artifact(command_row,'stderr')
  argv=command_row.get('argv',[])
  if '-d' not in argv: raise SystemExit('JADX command lacks its output root')
  if command_row.get('exit_code')==0:
   jadx_root=Path(argv[argv.index('-d')+1]).resolve(strict=True)
   actual_java={p.relative_to(jadx_root).as_posix():compare.pin(p) for p in sorted(jadx_root.rglob('*.java'))}
   expected_java={Path(pin['path']).relative_to(jadx_root).as_posix():pin for pin in cell.get('sources',[])}
   if actual_java!=expected_java: raise SystemExit('JADX saved source list is not the complete actual Java source tree')
 cells=source_cells(baseline,compare,commands_by_id,artifact_by_command)
 dependency=baseline.get('dependency_reference')
 if not isinstance(dependency,dict): raise SystemExit('baseline missing dependency reference')
 dep_path=exact_pin(compare,dependency,'dependency reference')
 dep=json.loads(dep_path.read_text(encoding='utf-8'))
 if dep.get('schema')!='cf11-original-nestedloops3-baseline-v1': raise SystemExit('dependency reference schema mismatch')
 dep_rows=[dep['harness_jar'],*dep.get('jar_pins',[])]
 for rec in dep_rows: exact_pin(compare,rec,'compile dependency')
 classpath=dep.get('classpath')
 if not classpath: raise SystemExit('dependency classpath missing')
 dep_dirs=dep.get('directory_pins',dep.get('directory_pins_before',{}))
 target_names={INTERNAL+'.class',OUTER+'.class'}
 for rec in dep_rows:
  if rec['path'].endswith('.jar'):
   with zipfile.ZipFile(rec['path']) as archive:
    if target_names.intersection(archive.namelist()): raise SystemExit('target class leaked into dependency JAR')
 for folder,pins in dep_dirs.items():
  actual={str(p):compare.pin(p) for p in sorted(Path(folder).rglob('*.class'))}
  expected={str(Path(v['path'])):v for v in pins.values()} if isinstance(pins,dict) else None
  if expected is None or actual!=expected: raise SystemExit(f'dependency class directory changed: {folder}')
  if any((Path(folder)/name).is_file() for name in target_names): raise SystemExit(f'target class leaked into dependency directory: {folder}')
 source_before=compare.source_closure(root)
 if not (baseline.get('source_pins_before')==baseline.get('source_pins_after')==baseline.get('source_pins_after_finally')): raise SystemExit('baseline repository source closure was not stable within its own capture')
 driver_src=Path(__file__).with_name('driver')/'TestComplexWhileLoopDriver.java'
 if sha_file(driver_src)!=DRIVER_SHA: raise SystemExit('frozen reflection driver SHA mismatch')
 runtime_original=Path(baseline['runtime_wrapper']['path']).resolve(strict=True)
 for rec,key in ((baseline.get('runtime_wrapper'),'baseline runtime wrapper'),(baseline.get('cli'),'baseline CLI'),
                 (baseline.get('jadx'),'JADX'),(baseline.get('jadx_jar'),'JADX jar')):
  exact_pin(compare,rec,key)
 out.mkdir(parents=True); raw=out/'raw'; raw.mkdir(); empty=out/'empty-classpath'; empty.mkdir()
 guard.ROOT=root; guard.OUT=raw; guard.target_bytes=lambda:scanner.target_bytes(root); guard.command_stream=compare.pin
 guard.expected_test_summaries=lambda index,data:None
 copied_driver=out/'driver-source'/driver_src.name; copied_driver.parent.mkdir(); shutil.copyfile(driver_src,copied_driver)
 if copied_driver.read_bytes()!=driver_src.read_bytes(): raise RuntimeError('driver copy differs')
 driver_classes=out/'driver-classes'; driver_classes.mkdir()
 runtime_copy=out/runtime_original.name; shutil.copyfile(runtime_original,runtime_copy)
 if runtime_copy.read_bytes()!=runtime_original.read_bytes(): raise RuntimeError('runtime wrapper copy differs')
 external_files=[bp,compare_path,guard_path,scanner_path,jdk_path,PARSER,driver_src,Path(__file__).resolve(),runtime_original,Path(baseline['cli']['path']),Path(baseline['jadx']['path']),Path(baseline['jadx_jar']['path']),dep_path,*[Path(x['path']) for x in dep_rows],*[tool for spec in jdks.values() for tool in spec['tools'].values()],*[Path(pin['path']) for pin in external_before_doc.get('files',[])],*[Path(pin['path']) for pin in external_before_doc.get('dependency_artifacts',[])]]
 for key in ('source','source_copy','control_source','driver_source','driver_copy','collector'):
  if baseline.get(key): external_files.append(Path(baseline[key]['path']))
 for cell in cells:
  external_files.extend(Path(pin['path']) for pin in cell.get('source_pins',[]))
  external_files.extend(Path(pin['path']) for pin in cell.get('input_pins',[]))
  if cell.get('report_pin'): external_files.append(Path(cell['report_pin']['path']))
 for cmd in commands.values():
  external_files.extend(Path(cmd['streams'][channel]['path']) for channel in ('stdout','stderr'))
 for profile in baseline.get('source_profiles',[]):
  class_root=Path(profile['class_root'])
  for rel in profile.get('class_tree',{}): external_files.append(class_root/rel)
  if profile.get('bundle'): external_files.append(Path(profile['bundle']['path']))
 boundary=baseline.get('javac8_full_source_boundary') or {}
 for rel in boundary.get('class_tree',{}): external_files.append(Path(baseline['output'])/'javac8-boundary'/'classes'/rel)
 external_before=[compare.pin(p) for p in external_files]
 dep_dir_before={str(Path(folder).resolve()):{str(Path(pin['path'])):compare.pin(Path(pin['path'])) for pin in pins.values()} for folder,pins in dep_dirs.items()}
 copies_before=[compare.pin(p) for p in (copied_driver,runtime_copy)]
 generated_source_initial={}
 generated_class_initial={}
 report={'schema':'test-complex-while-loop-generated-source-matrix-v1','status':'running','root':str(root),'output':str(out),
  'baseline_receipt':baseline_pin,'baseline_sha256_argument':a.baseline_sha256,'source_pins_before':source_before,
  'external_pins_before':external_before,'dependency_directory_pins_before':dep_dir_before,'local_copies_before':copies_before,'jdk_manifest':jdk_record,
  'compare':compare.pin(compare_path),'guard':compare.pin(guard_path),'scanner':compare.pin(scanner_path),'physical_parser':compare.pin(PARSER),
  'driver_source':compare.pin(driver_src),'driver_copy':compare.pin(copied_driver),'driver_compile':None,'driver_classes':[],
  'source_cells':[],'compilations':[],'runtime_rows':[],'wrong_root_rows':[],'original_oracles':{f'{p}/{r}':v for (p,r),v in oracles.items()},
  'notes':['Each full Jarde source cell and each complete JADX source profile is compiled unchanged by both configured Java 8-target compilers.',
           'Each Jarde cell is the one target child class source; the full JADX outer source contains the nested child and every emitted Java file is retained.',
           'Only a successful compile with a parsed target binary identity and required method inventory can receive runtime rows.',
           'Runtime semantic comparison uses only the corresponding original profile/runtime observation; raw exception and position observations remain saved.',
           'The CLI is pinned and checked but is not executed by this stage-two collector.',
           'JDK 8 harness-major-55 failures and all other compiler/JADX failures remain raw outcomes and never receive runtime rows.']}
 compare.write_json(out/'execution.json',report); rows=report['commands']=[]
 def command(argv,label,leg):
  if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError('target appeared')
  env=compare.clean_env(dict(os.environ),jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK',None); env.pop('CARGO_TARGET_DIR',None)
  row=guard.run_command(len(rows)+1,[str(x) for x in argv],env); row['label']=label; row['tool_leg']=leg; rows.append(row)
  compare.write_json(out/'execution.json',report)
  if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
  return row
 def artifact(row,channel='stdout'): return compare.command_artifact(row,channel)
 def generated_snapshot():
  return {'sources':{p:compare.pin(Path(p)) for p in generated_source_initial},
          'class_trees':{root_path:filetree(compare,Path(root_path)) for root_path in generated_class_initial}}
 def generated_expected():
  return {'sources':dict(generated_source_initial),'class_trees':dict(generated_class_initial)}
 def copy_cell_source(cell,srcroot):
  copied=[]
  for src,pin in zip(cell['source_paths'],cell['source_pins']):
   p=Path(src); data=p.read_bytes(); package=''
   m=re.search(rb'^\s*package\s+([A-Za-z0-9_.]+)\s*;',data,re.M)
   if m: package=m.group(1).decode('ascii').replace('.','/')
   filename='TestComplexWhileLoop$TestCls.java' if cell['kind']=='jarde' else p.name
   dest=srcroot/package/filename if package else srcroot/filename
   dest.parent.mkdir(parents=True,exist_ok=True)
   if dest.exists(): raise RuntimeError(f'duplicate full-source basename: {dest}')
   dest.write_bytes(data)
   generated_source_initial[str(dest)]=compare.pin(dest)
   if dest.read_bytes()!=data: raise RuntimeError('source copy is not byte-identical')
   copied.append({'source':pin,'copy':compare.pin(dest)})
  if cell['kind']=='jarde':
   matches=[x for x in copied if Path(x['copy']['path']).name=='TestComplexWhileLoop$TestCls.java']
   if len(matches)!=1: raise RuntimeError('Jarde full source is not under the expected $TestCls filename')
   if Path(matches[0]['copy']['path']).relative_to(srcroot).as_posix()!='jadx/tests/integration/loops/TestComplexWhileLoop$TestCls.java':
    raise RuntimeError('Jarde complete source package/path differs from target owner')
  return copied
 try:
  driver_compile=command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',driver_classes,copied_driver],'compile-reflection-driver','javac8')
  report['driver_compile']={'command':driver_compile['index'],'exit_code':driver_compile['exit_code'],'stdout':compare.pin(Path(driver_compile['streams']['stdout']['path'])),'stderr':compare.pin(Path(driver_compile['streams']['stderr']['path']))}
  generated_class_initial[str(driver_classes)]=filetree(compare,driver_classes)
  if driver_compile['exit_code']!=0: raise RuntimeError('reflection driver failed to compile')
  dclasses=sorted(driver_classes.rglob('*.class'))
  if [p.relative_to(driver_classes).as_posix() for p in dclasses] != ['TestComplexWhileLoopDriver$Case.class','TestComplexWhileLoopDriver.class']: raise RuntimeError(f'unexpected driver class tree: {[p.name for p in dclasses]}')
  report['driver_classes']=[compare.pin(p) for p in dclasses]
  # The driver has modified-UTF8 literals. Keep the deliberately narrow compare.py summary.
  report['driver_summaries']=[compare.parse_class(p) for p in dclasses]
  for cell in cells:
   basekey='-'.join(map(str,cell['cell_key']))
   cell_record={'kind':cell['kind'],'profile':cell['profile'],'form':cell['form'],'evidence':cell['evidence'],
                'cell_key':cell['cell_key'],'source_available':cell['source_available'],
                'source_unavailable_reason':cell.get('source_unavailable_reason'),'source_copies':[],'compilations':[]}
   report['source_cells'].append(cell_record)
   if not cell['source_available']:
    compare.write_json(out/'execution.json',report); continue
   srcroot=out/'sources'/basekey; srcroot.mkdir(parents=True)
   copies=copy_cell_source(cell,srcroot); cell_record['source_copies']=copies
   compare.write_json(out/'execution.json',report)
   for leg in LEGS:
    dest=out/'compiled'/basekey/leg/'classes'; dest.mkdir(parents=True)
    if leg=='javac8':
     debug='-g' if cell['profile']=='debug' else '-g:none'
     argv=[jdks[leg]['tools']['javac'],'-source','8','-target','8',debug,'-encoding','UTF-8','-proc:none','-classpath',os.pathsep.join(classpath),'-sourcepath',empty,'-d',dest,*sorted(srcroot.rglob('*.java'))]
    else:
     debug='-g' if cell['profile']=='debug' else '-g:none'
     argv=[jdks[leg]['tools']['javac'],'--release','8',debug,'-encoding','UTF-8','-proc:none','-classpath',os.pathsep.join(classpath),'-sourcepath',empty,'-d',dest,*sorted(srcroot.rglob('*.java'))]
    cr=command(argv,f'compile-{basekey}-{leg}',leg)
    compile_stderr=artifact(cr,'stderr')
    failure_class=('harness-major-55-boundary' if leg=='javac8' and
                   (b'55.0' in compile_stderr or b'version 55' in compile_stderr or b'wrong version' in compile_stderr)
                   else ('compiler-rejected-source' if cr['exit_code']!=0 else None))
    rec={'leg':leg,'command':cr['index'],'exit_code':cr['exit_code'],'class_root':str(dest),'source_copies':copies,
         'stdout':compare.pin(Path(cr['streams']['stdout']['path'])),'stderr':compare.pin(Path(cr['streams']['stderr']['path'])),'class_tree':filetree(compare,dest),
         'failure_classification':failure_class}
    generated_class_initial[str(dest)]=rec['class_tree']
    rec['class_facts']=None; rec['class_facts_error']=None; rec['target_facts']=None
    rec['target_facts_error']=None; rec['runtime_eligible']=False
    if cr['exit_code']==0:
     target_path=dest/(INTERNAL+'.class')
     if target_path.is_file():
      try:
       rec['target_facts']=compare.parse_class(target_path)
       if rec['target_facts'].get('class_name')!=INTERNAL or rec['target_facts'].get('major')!=52:
        rec['target_facts_error']='compiled target path has a different binary identity or classfile major'
      except Exception as exc: rec['target_facts_error']=repr(exc)
     else:
      rec['target_facts_error']='compiled output has no expected target binary path'
     try:
      rec['class_facts']=parse_profile_facts(compare,physical,dest)
      expected_generated_tree=({INTERNAL+'.class'} if cell['kind']=='jarde'
                               else {INTERNAL+'.class',OUTER+'.class'})
      if set(rec['class_facts'])!=expected_generated_tree:
       rec['class_facts_error']='compiled full-source tree does not contain exactly the expected target-only or outer-plus-child classes'
       rec['class_facts']=None
     except Exception as exc:
      rec['class_facts_error']=repr(exc)
     if rec['class_facts'] is not None and rec['target_facts'] is not None and rec['target_facts_error'] is None:
      original=original_profiles[cell['profile']]['target_facts']
      generated=rec['target_facts']
      expected_methods=sorted((m.get('name'),m.get('descriptor'),m.get('access')) for m in original.get('methods',[]))
      actual_methods=sorted((m.get('name'),m.get('descriptor'),m.get('access')) for m in generated.get('methods',[]))
      expected_fields=sorted(tuple(f) for f in original.get('fields',[]))
      actual_fields=sorted(tuple(f) for f in generated.get('fields',[]))
      if generated.get('class_name')!=original.get('class_name') or actual_methods!=expected_methods or actual_fields!=expected_fields:
       rec['target_facts_error']='generated target method or field identity/access inventory differs from matching original profile'
      else:
       rec['runtime_eligible']=True
    cell_record['compilations'].append(rec); report['compilations'].append({'cell_key':cell['cell_key'],**rec})
    compare.write_json(out/'execution.json',report)
    if cr['exit_code']!=0 or not rec['runtime_eligible']: continue
    target_root=dest.resolve()
    for runtime in RUNTIMES:
     rr=command([sys.executable,'-B',runtime_copy,'30',jdks[runtime]['tools']['java'],'-Xverify:all','-cp',driver_classes,DRIVER_NAME,target_root,target_root],
                f'runtime-{basekey}-{leg}-{runtime}',runtime)
     stdout=artifact(rr); stderr=artifact(rr,'stderr'); parsed=parse_oracle(stdout) if rr['exit_code']==0 else []
     sem=projection(parsed) if parsed else None
     expected=oracles[(cell['profile'],runtime)]
     passed=rr['exit_code']==0 and sem==expected
     runtime_record={'cell_key':cell['cell_key'],'compiler':leg,'runtime':runtime,'command':rr['index'],'exit_code':rr['exit_code'],
      'target_root':str(target_root),'application_classpath':[str(driver_classes)],'stdout':compare.pin(Path(rr['streams']['stdout']['path'])),
      'stderr':compare.pin(Path(rr['streams']['stderr']['path'])),'rows':parsed,'semantic_projection':sem,'matches_original_profile_runtime':passed}
     report['runtime_rows'].append(runtime_record); compare.write_json(out/'execution.json',report)
    wr=command([sys.executable,'-B',runtime_copy,'30',jdks['javac23']['tools']['java'],'-Xverify:all','-cp',driver_classes,DRIVER_NAME,target_root,empty],
               f'wrong-root-{basekey}-{leg}','javac23')
    err=artifact(wr,'stderr'); rejected=wr['exit_code']==1 and b'wrong CodeSource:' in err
    report['wrong_root_rows'].append({'cell_key':cell['cell_key'],'compiler':leg,'command':wr['index'],'exit_code':wr['exit_code'],
      'actual_target_root':str(target_root),'expected_wrong_root':str(empty),'rejected':rejected,
      'stdout':compare.pin(Path(wr['streams']['stdout']['path'])),'stderr':compare.pin(Path(wr['streams']['stderr']['path']))})
    compare.write_json(out/'execution.json',report)
    if not rejected: raise RuntimeError('wrong CodeSource control did not reject')
  report['generated_output_pins_before']=generated_expected()
  report['generated_output_pins_after']=generated_snapshot()
  report['generated_outputs_unchanged']=report['generated_output_pins_after']==report['generated_output_pins_before']
  report['source_pins_after']=compare.source_closure(root)
  report['external_pins_after']=[compare.pin(p) for p in external_files]
  report['dependency_directory_pins_after']={str(Path(folder).resolve()):{str(Path(pin['path'])):compare.pin(Path(pin['path'])) for pin in pins.values()} for folder,pins in dep_dirs.items()}
  report['local_copies_after']=[compare.pin(p) for p in (copied_driver,runtime_copy)]
  report['source_unchanged']=report['source_pins_after']==source_before
  report['external_inputs_unchanged']=report['external_pins_after']==external_before and report['dependency_directory_pins_after']==dep_dir_before
  report['local_copies_unchanged']=report['local_copies_after']==copies_before
  report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
  if not all((report['source_unchanged'],report['external_inputs_unchanged'],report['local_copies_unchanged'],report['generated_outputs_unchanged'],report['target_absent'])):
   raise RuntimeError('source/input/target closure changed during capture')
  report['counts_derived']={'source_cells':len(cells),'jarde_api_cells':sum(c['kind']=='jarde' for c in cells),'jadx_source_cells':sum(c['kind']=='jadx' for c in cells),'compile_attempts':len(report['compilations']),
   'compile_successes':sum(x['exit_code']==0 for x in report['compilations']),'compile_failures':sum(x['exit_code']!=0 for x in report['compilations']),
   'runtime_attempts':len(report['runtime_rows']),'wrong_root_attempts':len(report['wrong_root_rows']),'commands':len(rows),'raw_streams':2*len(rows)}
  report['status']='captured-pending-independent-review'
 except BaseException as exc:
  report['status']='failed'; report['error']=repr(exc); raise
 finally:
  try:
   report['generated_output_pins_after_finally']=generated_snapshot()
   report['generated_outputs_unchanged_finally']=report['generated_output_pins_after_finally']==generated_expected()
   report['source_pins_after_finally']=compare.source_closure(root)
   report['external_pins_after_finally']=[compare.pin(p) for p in external_files]
   report['dependency_directory_pins_after_finally']={str(Path(folder).resolve()):{str(Path(pin['path'])):compare.pin(Path(pin['path'])) for pin in pins.values()} for folder,pins in dep_dirs.items()}
   report['local_copies_after_finally']=[compare.pin(p) for p in (copied_driver,runtime_copy)]
   report['source_unchanged_finally']=report['source_pins_after_finally']==source_before
   report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
   if not report['source_unchanged_finally'] or not report['target_absent_finally'] or not report['generated_outputs_unchanged_finally'] or report['external_pins_after_finally']!=external_before or report['dependency_directory_pins_after_finally']!=dep_dir_before or report['local_copies_after_finally']!=copies_before:
    report['status']='failed'; report['final_guard_error']='closure changed'
  except BaseException as final_exc:
   report['status']='failed'; report['final_guard_error']=repr(final_exc)
  report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  compare.write_json(out/'execution.json',report)
  shutil.copy2(__file__,out/'collector.py')
  print(json.dumps({'status':report['status'],'commands':len(rows),'compile_attempts':len(report['compilations']),
                    'runtime_attempts':len(report['runtime_rows']),'error':report.get('error')}))
 return 0
if __name__=='__main__': raise SystemExit(main())
