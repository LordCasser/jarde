# TestComplexWhileLoop: bounded architecture note

Status: static comparison only. No current Jarde API/CLI, compiler, or runtime result was read or run; this is not a confirmed defect and proposes no patch or OpenSpec change.

## What the fixed test establishes

The upstream test is `jadx-core/src/test/java/jadx/tests/integration/loops/TestComplexWhileLoop.java:13-35`. Its source method reads `arr.length` before the loop, evaluates `(str = arr[index]) != null` in the loop condition, returns `str.trim()` from an inner branch for one-character strings, increments and conditionally resets `index`, then prints `loop end` and returns `""` after the null sentinel. The test asserts only that JADX output does not contain one specific counted-loop spelling (`:33`); it is not a full generated-source golden.

The relevant JADX path is `LoopRegionVisitor.processLoopRegion` and `checkForIndexedLoop` (`LoopRegionVisitor.java:56-143`). That rewrite starts from the loop-end update and requires a simple single-use induction phi, an initialization, and uses confined to the loop. Its array-for-each refinement additionally requires `i = 0`, `i += 1`, `i < array.length`, and the same array in `array[i]` (`:146-243`). The source-level conditional reset does not resemble that simple update shape, and its null-checking assignment condition is not the array-for-each condition; verify the emitted Code before asserting either gate fails. The negative assertion records a guard against this particular counted-loop normalization; it does not require Jarde to reproduce JADX’s exact text.

Before that visitor, JADX’s `LoopRegionMaker` creates the loop condition and asks the region maker to recover its body (`LoopRegionMaker.java:55-168`). Inner branches and returns are part of that region structure; the later counted-loop visitor is a separate, gated presentation pass.

## Existing Jarde paths that may already suffice

The ordinary header-tested-loop path checks `test_is_pure` before constructing a `While` (`crates/jarde-java/src/region.rs:16617-16780`). The purity rule permits a condition’s array element load only when its value has one reader, and permits the proved `dup; store; test` assignment machinery (`:12471-12630`). The builder’s `local_assignment_at` ties the copy, local store, and branch consumer to the same block and requires single-use SSA values (`crates/jarde-java/src/build.rs:8122-8250`). `prove_local_assignments` accepts a decided reference local and keeps an observed loop-test assignment as an expression at its original condition position rather than moving it (`:8322-8578`). For this fixture, that is the plausible existing route: the `String` array read and assignment must remain evaluated once in each condition evaluation, with the store visible to the body.

The separate `local_reference_write_compatibility` analysis in `build.rs:2957-3245` has a narrower job: it resolves selected ordinary reference-local write cases and their actual reads. It should not be treated as the loop-condition proof. This input’s relevant evidence is the exact local assignment dance and the condition’s array-load reader count; its `String` type must still come from the existing physical/lexical type facts.

The loop walker separately accounts for terminal return leaves and includes them in the loop body’s expected ownership (`region.rs:16617-17045`, `19860-19960`). That is the plausible existing route for the `return str.trim()` branch. The latch and the `index` reset must remain body effects in bytecode order. The narrower counted-loop proof (`prove_for_header`, `:18036-18200`) only recognizes a tightly shaped latch update; a conditional reset should prevent using it, but the actual compiled Code must be checked before treating that as established for this input.

`statementful_loop_header` is a fallback only after the ordinary condition test is refused (`region.rs:16757-16763`). It is deliberately narrower: top-level/unprotected ownership, complete Code, one natural loop/latch, and a single canonical path through the non-header body (`:17056-17677`, especially `:17358-17385`). This fixture’s body has an early-return branch and a reset branch, so it does not appear to match that fallback’s body restriction. That is not evidence of a defect because the ordinary condition path already has explicit support for a single-use array read and observable assignment.

## Sufficient proof conditions to verify against the frozen class

1. The complete method Code, SSA, decoded operations, and canonical loop all name the same physical `test([Ljava/lang/String;)Ljava/lang/String;` method. The `aaload` is evaluated exactly once per test; its result has the proved `dup`/store/branch use shape, and the store’s local is the same `String` local read by the body.
2. The normal loop condition’s branch and null exit are exact. No rewrite hoists the array access, assignment, or its possible exception out of the test. The reset/update and early return remain in their original body branches and order.
3. The return leaf is owned by the conditional body branch; the natural loop’s entry, latch, exits, and all normal edges are closed. The generated loop remains a while-equivalent form unless an independently complete counted-loop proof applies.
4. On the current CLI, structured quality, complete raw method text/map, and all physical instruction BCIs are checked; then the unmodified complete source is compiled and the finite driver cases are compared with original Java on both configured JDK legs. Text alone cannot establish these control-flow and exception properties.

## If current output refuses or differs

First capture fresh default/all API results for the exact method in both original debug profiles, bound to the real class bytes and CLI pin. Preserve the refusal reason and method’s regions/BCIs. If the refusal is `StatementFree` at the condition, inspect that BCI’s decoded operation, the `arrayload` value’s reader count, and `local_assignment_at`’s exact source/store/test facts. If the method is structured but its body is incomplete, compare loop block/latch/return-leaf ownership and report which exact edge or return certificate failed. If it emits a counted loop, record the `ForHeader` proof and latch facts; do not infer that the output is wrong until the complete source compiles and its runtime observations disagree with the original. Keep diagnostics on the existing consumer; the static evidence does not justify a new loop pass or general condition-assignment mechanism.

The prepared finite cases cover null/empty input, null sentinel, and early return, plus bounded traversal to those exits. When an array contains only non-null strings of lengths other than one, the original cycles after resetting the index. No finite run in the prepared plan proves a wrap followed by termination, so the reset path remains a static Code/SSA claim rather than runtime coverage. Do not run an infinite case or add concurrency/input mutation to simulate it.

## Atlas coverage note

Atlas opened the Jarde project successfully. Scoped search for `statementful_loop` in `crates/jarde-java/src/build.rs` returned no symbols; broader `crates/jarde-java/src` coverage was partial. The conclusions above are therefore pinned to the current source excerpts and hashes, not presented as complete Atlas-index coverage.
