#!/usr/bin/env python3
"""Bind accepted TestLoopConditionInvoke collectors to a caller-pinned final CLI.

This preparation utility only copies/rebinds Python collectors and records pins. It does not
invoke collectors, JDKs, Jarde/JADX, Cargo, or network access.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
import re
import shutil
from pathlib import Path

SOURCES = {
    'primary_baseline': Path('/private/tmp/jarde-loop-condition-invoke-baseline-prep-luna-v2-20261019'),
    'primary_generated': Path('/private/tmp/jarde-loop-condition-invoke-generated-prep-luna-v5-20261019'),
    'controls_baseline': Path('/private/tmp/jarde-loop-condition-invoke-controls-baseline-prep-root-v2-20261019'),
    'controls_generated': Path('/private/tmp/jarde-loop-condition-invoke-controls-generated-prep-root-v2-20261019'),
}
FILES = {
    'primary_baseline': ('collect_baseline.py', 'driver/TestLoopConditionInvokeDriver.java'),
    'primary_generated': ('collect_generated_matrix.py', 'driver/TestLoopConditionInvokeDriver.java'),
    'controls_baseline': ('collect_controls_baseline.py', 'source/controls/LoopConditionInvokeControl.java',
                          'driver/LoopConditionInvokeControlDriver.java', 'controls.json'),
    'controls_generated': ('collect_controls_generated.py', 'LoopConditionInvokeControlDriver.java', 'controls.json'),
}
OLD_CLI = '90b30ad1132bdc904c20f1b4624347b84d37637c78f1f3e291ce2f0dea91f64c'
EXPECTED = {
    'primary_baseline': ('CLI_SHA256', OLD_CLI),
    'primary_generated': ('CURRENT_CLI_SHA', OLD_CLI),
    'controls_baseline': ('CLI_SHA', OLD_CLI),
}
COLLECTOR_SHA = {
    'primary_baseline': '4b4760c50e581b9285d5c0cc95779ab532e1b135332ae70f063c7ed054dfdb39',
    'primary_generated': '1a1b14124232a40ff527159e602a96c01b36e8d3a03a675c23b0f6d8c72b6cd5',
    'controls_baseline': '698c9aee12c1cc0db964b8a3712c7e6ace2a49fdb295cbaf8ecc5abbbf5cb990',
    'controls_generated': '6484910c28551264f67d369c9690a62457dab7f47262e08761d9aebf91e4f313',
}
RESOURCE_SHA = {
    'primary_baseline/driver/TestLoopConditionInvokeDriver.java': '3e75df6a662f0b04ff6a8c55a40491c72f4bba3013b85ca6b7c268a00b82722f',
    'primary_generated/driver/TestLoopConditionInvokeDriver.java': '3e75df6a662f0b04ff6a8c55a40491c72f4bba3013b85ca6b7c268a00b82722f',
    'controls_baseline/source/controls/LoopConditionInvokeControl.java': '9bb63f647c8a5bd519a8b9f99bb75db42a62637012034e055446faa6be6d362e',
    'controls_baseline/driver/LoopConditionInvokeControlDriver.java': 'a92a766e4189d22b0d68b9210477cdb503bcf59cd45860b5f46fb7ef3c823cd6',
    'controls_baseline/controls.json': 'c0280ff11eff365fb7b53caa85dfb450f37b15ebf2c009ecd6fde18730f2c8bf',
    'controls_generated/LoopConditionInvokeControlDriver.java': 'a92a766e4189d22b0d68b9210477cdb503bcf59cd45860b5f46fb7ef3c823cd6',
    'controls_generated/controls.json': 'c0280ff11eff365fb7b53caa85dfb450f37b15ebf2c009ecd6fde18730f2c8bf',
}


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def replace_string_constant(text: str, name: str, old: str, new: str) -> str:
    pattern = re.compile(rf"(?m)^({re.escape(name)}\s*=\s*)['\"]{re.escape(old)}['\"]\s*$")
    result, count = pattern.subn(lambda m: m.group(1) + repr(new), text)
    if count != 1:
        raise ValueError(f'{name}: expected exactly one pinned assignment, found {count}')
    return result


def pin(path: Path) -> dict:
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--cli', type=Path, required=True)
    ap.add_argument('--expected-cli-sha256', required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    cli = args.cli.resolve(strict=True)
    out = args.out.resolve()
    if not re.fullmatch(r'[0-9a-f]{64}', args.expected_cli_sha256):
        raise SystemExit('expected CLI SHA must be 64 lowercase hex characters')
    if sha(cli) != args.expected_cli_sha256:
        raise SystemExit('CLI bytes do not match caller-supplied SHA')
    if out.exists():
        raise SystemExit(f'refusing existing output directory: {out}')

    # Validate every source package before creating output, including its exact collector pin.
    src_records = {}
    for key, paths in FILES.items():
        root = SOURCES[key]
        src_records[key] = {}
        for rel in paths:
            path = root / rel
            if not path.is_file():
                raise SystemExit(f'missing accepted collector input: {path}')
            src_records[key][rel] = pin(path)
        collector_name = paths[0]
        collector_path = root / collector_name
        if sha(collector_path) != COLLECTOR_SHA[key]:
            raise SystemExit(f'{key}: accepted collector SHA mismatch')
        for rel in paths[1:]:
            expected = RESOURCE_SHA[f'{key}/{rel}']
            if sha(root / rel) != expected:
                raise SystemExit(f'{key}/{rel}: accepted resource SHA mismatch')
        source_text = collector_path.read_text(encoding='utf-8')
        ast.parse(source_text, filename=str(root / collector_name))
        if key in EXPECTED:
            name, old = EXPECTED[key]
            if not re.search(rf"(?m)^{re.escape(name)}\s*=\s*['\"]{re.escape(old)}['\"]\s*$", source_text):
                raise SystemExit(f'{key}: expected pinned CLI constant changed')

    out.mkdir(parents=True)
    destinations = {}
    for key, paths in FILES.items():
        dest_root = out / key
        dest_root.mkdir()
        src_root = SOURCES[key]
        for rel in paths:
            dest = dest_root / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src_root / rel, dest)
        collector = dest_root / paths[0]
        original = collector.read_text(encoding='utf-8')
        rebound = original
        if key in EXPECTED:
            name, old = EXPECTED[key]
            rebound = replace_string_constant(rebound, name, old, args.expected_cli_sha256)
        if key == 'controls_generated':
            # This helper exports full_class_facts used by the generated-stage inventory check.
            # Keep the accepted primary-baseline helper contract, but bind it to this package copy.
            helper = destinations['primary_baseline']
            helper_path_new = str(helper.resolve())
            m = re.search(r"(?m)^BASE_HELPERS=Path\(['\"]([^'\"]+)['\"]\)\s*$", rebound)
            if not m:
                raise SystemExit('controls generated collector BASE_HELPERS path schema changed')
            rebound, count = re.subn(r"(?m)^BASE_HELPERS=Path\(['\"][^'\"]+['\"]\)\s*$",
                                     f"BASE_HELPERS=Path({helper_path_new!r})", rebound)
            if count != 1:
                raise SystemExit(f'controls generated BASE_HELPERS path replacement count: {count}')
            helper_sha = sha(helper)
            sha_pattern = re.compile(r"(?m)^BASE_HELPERS_SHA\s*=\s*['\"][0-9a-f]{64}['\"]\s*$")
            rebound, count = sha_pattern.subn(f"BASE_HELPERS_SHA={helper_sha!r}", rebound)
            if count != 1:
                raise SystemExit(f'controls generated BASE_HELPERS_SHA replacement count: {count}')
        ast.parse(rebound, filename=str(collector))
        collector.write_text(rebound, encoding='utf-8')
        destinations[key] = collector

    # The controls generated collector imports the primary helper's full_class_facts function.
    helper = destinations['primary_baseline']
    if sha(helper) not in destinations['controls_generated'].read_text(encoding='utf-8'):
        raise SystemExit('controls generated helper digest was not rebound')
    record = {
        'schema': 'assignment-condition-widening-final-collector-bind-v1',
        'candidate_cli': pin(cli),
        'caller_expected_cli_sha256': args.expected_cli_sha256,
        'accepted_source_collectors': src_records,
        'bound_collectors': {key: pin(path) for key, path in destinations.items()},
        'bound_resources': {
            key: {rel: pin(out / key / rel) for rel in FILES[key][1:]}
            for key in FILES
        },
        'notes': [
            'This binder only prepares pinned collector copies. It runs no collector or toolchain.',
            'Collector order is primary baseline -> primary generated -> controls baseline -> controls generated.',
            'Historical receipts and tool/source pins remain the accepted references embedded in each collector.',
            'Every executing collector records its own live source closure before and after; historic closure is not required to equal the current tree.',
        ],
    }
    (out / 'bound-manifest.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps({'out': str(out), 'candidate_cli_sha256': args.expected_cli_sha256,
                      'collectors': sorted(destinations)}, sort_keys=True))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
