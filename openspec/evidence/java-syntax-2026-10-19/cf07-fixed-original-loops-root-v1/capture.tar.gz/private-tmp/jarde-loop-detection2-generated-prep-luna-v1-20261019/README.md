# TestLoopDetection2 generated-source collector preparation

Private static preparation derived from the root-accepted ComplexWhileLoop generated collector v2. The adapted collector was syntax-parsed and its constants checked; it was not run.

The baseline receipt is `/private/tmp/jarde-loop-detection2-baseline-root-v1-20261019/execution.json` (SHA-256 `9a4d47928f6621e572c4f1efe4385f09dee332bd1f267785bbde9b9d7d0df2f7`). The independent read-only baseline audit passed its recorded schema, command/raw pin, source snapshot, physical class/Code/BCI, complete source-map UTF-8 spans, parentless CodeSource rejection, and manual runtime oracle checks. Audit output: `/private/tmp/jarde-loopcondition2-detection2-baseline-audit-luna-v1-20261019/audit.json`. Derived evidence: 20 commands/40 raw streams; 4 original VM cells with 20 observed case rows; 8 structured API cells and 16 method reports; 2 full JADX outputs.

The driver uses `TestLoopDetection2$TestCls` through a parentless loader and contains only the frozen finite cases: range-1-4, range-6-9, empty-5-5, negative-range-minus2-2, reversed-4-1. Target descriptor: `test(II)I`. The adapted generated collector keeps complete Jarde child sources and full JADX outer source trees unchanged, compiles with both configured Java 8-target compiler legs, and only runs successfully parsed classes with exact target identity/inventory and the inherited CodeSource/oracle gates. It does not patch generated sources. Compiler refusals remain recorded without runtime rows.

Collector SHA-256: `d6bdbeba935409bf41139439c49f5217daafef13beb3d32bd07cb2aa98a8878b`. Driver SHA-256: `7e5c0c4782fcdfc840d691956ea92c34de4508b0a0d0cba203063217bff279ce`. Adaptation diff and audit pins are in `collector-adaptation.diff` and `pins.json`. No generated matrix was executed or accepted.

After root review and acceptance of the baseline audit, the root can run:

```sh
python3 -B /private/tmp/jarde-loop-detection2-generated-prep-luna-v1-20261019/collect_generated_matrix.py \
  --baseline /private/tmp/jarde-loop-detection2-baseline-root-v1-20261019/execution.json \
  --baseline-sha256 9a4d47928f6621e572c4f1efe4385f09dee332bd1f267785bbde9b9d7d0df2f7 \
  --cli /private/tmp/jarde-assignment-condition-widening-broad-resume-root-v1-20261019/candidate-cli \
  --out /private/tmp/jarde-loop-detection2-generated-root-v1-20261019
```
