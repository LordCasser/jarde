import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.Base64;

/** Bounded isolated observations of TestLoopDetection2$TestCls.test(int,int). */
public final class TestLoopDetection2Driver {
    private static final String TARGET = "jadx.tests.integration.loops.TestLoopDetection2$TestCls";
    private static final Case[] CASES = {
        new Case("range-1-4", 1, 4), new Case("range-6-9", 6, 9), new Case("empty-5-5", 5, 5),
        new Case("negative-range-minus2-2", -2, 2), new Case("reversed-4-1", 4, 1)
    };
    private static final class Case {
        final String name; final int a; final int b;
        Case(String name, int a, int b) { this.name = name; this.a = a; this.b = b; }
    }
    private static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static String codeSource(Class<?> target) throws Exception {
        CodeSource source = target.getProtectionDomain().getCodeSource();
        if (source == null || source.getLocation() == null) throw new IllegalStateException("target has no CodeSource");
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }
    private static void observe(Constructor<?> ctor, Method test, Case c, int index, PrintStream rows) throws Exception {
        PrintStream original = System.out; ByteArrayOutputStream targetBytes = new ByteArrayOutputStream();
        PrintStream targetOut = new PrintStream(targetBytes, true, "UTF-8"); Object value = null; Throwable cause = null; String stack = "";
        try {
            System.setOut(targetOut);
            try { value = test.invoke(ctor.newInstance(), c.a, c.b); }
            catch (InvocationTargetException e) { cause = e.getCause(); StringWriter w = new StringWriter(); cause.printStackTrace(new PrintWriter(w)); stack = w.toString(); }
        } finally { targetOut.flush(); System.setOut(original); targetOut.close(); }
        String exception = cause == null ? "none" : cause.getClass().getName();
        String message = cause == null || cause.getMessage() == null ? "" : cause.getMessage();
        String result = cause == null ? String.valueOf(value) : "";
        rows.println("CASE index=" + index + " name=" + c.name + " input_b64=" + b64(c.a + "," + c.b)
                + " result_b64=" + b64(result) + " exception=" + exception + " exception_message_b64=" + b64(message)
                + " exception_stack_b64=" + b64(stack) + " target_stdout_b64=" + b64(new String(targetBytes.toByteArray(), StandardCharsets.UTF_8)));
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("usage: TestLoopDetection2Driver actualRoot expectedRoot");
        String actual = Paths.get(args[0]).toRealPath().toString(), expected = Paths.get(args[1]).toRealPath().toString();
        try (URLClassLoader loader = new URLClassLoader(new URL[] { Paths.get(actual).toUri().toURL() }, null)) {
            Class<?> target = Class.forName(TARGET, true, loader);
            if (target.getClassLoader() != loader) throw new IllegalStateException("target did not load from parentless loader");
            String origin = codeSource(target);
            if (!origin.equals(expected)) throw new IllegalStateException("wrong CodeSource: expected=" + expected + " actual=" + origin);
            Constructor<?> ctor = target.getDeclaredConstructor(); Method test = target.getDeclaredMethod("test", int.class, int.class);
            if (Modifier.isStatic(test.getModifiers())) throw new IllegalStateException("test(int,int) unexpectedly static");
            PrintStream rows = System.out;
            for (int i = 0; i < CASES.length; i++) observe(ctor, test, CASES[i], i, rows);
        }
    }
}
