# Baseline receipt review

Read-only audit of the completed complex-while-loop baseline receipt. The audit reopened 4,274 unique pinned paths, including all 20 commands' 40 raw streams and the 3,324-entry source closure. Both debug profiles contain the expected outer and nested class at class-file major 52; all eight Jarde API selectors preserve the physical target bytes and return structured constructor/test bodies with UTF-8-bounded maps covering every physical BCI. `default` and `all` have identical whole-class text and method text/maps; `all` additionally records region summaries.

The four original VM rows agree on the seven requested observations: null array throws NPE; empty array throws AIOOBE; first-null and nonmatches-then-null print `loop end` and return empty; one-character and later `z` cases return their character; a single space trims to empty without output. The wrong-CodeSource control exits 1 with the expected rejection. Source, external-input, and local-copy snapshots remained equal, and the target was absent after cleanup.

This audits the captured baseline only. The generated-source matrix is not included, so this does not establish that the proposed recovery change works or that the complete use case is accepted.
