#!/usr/bin/env python3
import hashlib, json, sys, zipfile
from pathlib import Path

EXPECTED_CASES = {
 'null-array': ('<null-array>', '', 'java.lang.NullPointerException', ''),
 'empty-array': ('[]', '', 'java.lang.ArrayIndexOutOfBoundsException', ''),
 'first-null': ('[<null>]', '', None, 'loop end\n'),
 'first-one-char': ('[eA==]', 'x', None, ''),
 'nonmatches-then-one-char': ('[bG9uZw==,dHdv,eg==]', 'z', None, ''),
 'nonmatches-then-null': ('[bG9uZw==,dHdv,<null>]', '', None, 'loop end\n'),
 'single-space-trims-empty': ('[IA==]', '', None, ''),
}
METHODS = {('<init>', '()V'), ('test', '([Ljava/lang/String;)Ljava/lang/String;')}

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(1<<20),b''): h.update(chunk)
 return h.hexdigest()

def pin(row,label):
 if not isinstance(row,dict) or not {'path','bytes','sha256'} <= row.keys(): raise ValueError(f'{label}: malformed pin')
 p=Path(row['path']).resolve(strict=True)
 if p.stat().st_size != row['bytes'] or sha(p) != row['sha256']: raise ValueError(f'{label}: pin mismatch {p}')
 return p

def all_pins(value,label='receipt',seen=None):
 if seen is None: seen={}
 if isinstance(value,dict):
  if {'path','bytes','sha256'} <= value.keys():
   p=pin(value,label); key=str(p); val=(value['bytes'],value['sha256'])
   if key in seen and seen[key] != val: raise ValueError(f'{label}: conflicting pins for {p}')
   if key not in seen: seen[key]=val
   return seen
  for k,v in value.items(): all_pins(v,f'{label}/{k}',seen)
 elif isinstance(value,list):
  for i,v in enumerate(value): all_pins(v,f'{label}[{i}]',seen)
 return seen

def command_map(d):
 rows=d['commands']; m={r['index']:r for r in rows}
 if len(rows)!=20 or len(m)!=20 or set(m)!=set(range(1,21)): raise ValueError('expected command indices 1..20')
 for r in rows:
  if r.get('guard_stop') is not None or r.get('peak_target_bytes',0)>1024**3 or r.get('free_bytes_after',0)<5*1024**3: raise ValueError(f"command guard failed: {r.get('label')}")
  for stream in ('stdout','stderr'): pin(r['streams'][stream],f"command {r['index']} {stream}")
 return m

def method_key(m): return (m['name'],m['descriptor'])
def origin_bcis(origin):
 out=set()
 for k in ('primary',):
  x=origin.get(k)
  if isinstance(x,dict) and isinstance(x.get('bci'),int): out.add(x['bci'])
 for x in origin.get('derived',[]):
  if isinstance(x,dict) and isinstance(x.get('bci'),int): out.add(x['bci'])
 return out

def check_cell(c,cmds,profile_doc):
 if c['exit_code']!=0: raise ValueError('Jarde API call failed')
 inp=pin(c['input'],'API input'); reportp=pin(c['report'],'API report'); whole=pin(c['whole_source'],'API whole source')
 target_bytes=pin(profile_doc['target_facts'],'original target facts').read_bytes()
 if c['input_form']=='child': actual_input=inp.read_bytes()
 else:
  with zipfile.ZipFile(inp) as jar: actual_input=jar.read('jadx/tests/integration/loops/TestComplexWhileLoop$TestCls.class')
 if actual_input!=target_bytes: raise ValueError('API input target bytes differ from original physical target')
 report=json.loads(reportp.read_text()); text=report.get('text','').encode('utf-8')
 if whole.read_bytes()!=text: raise ValueError('whole-source artifact differs from report text')
 if c['physical_method_inventory']!=c['expected_physical_method_inventory'] or {tuple(x) for x in c['physical_method_inventory']}!=METHODS: raise ValueError('physical method inventory mismatch')
 raw={}
 for m in report['methods']:
  ident=(m['item']['name']['escaped'],m['item']['descriptor']['escaped'])
  if ident in raw: raise ValueError('duplicate report method')
  raw[ident]=m
 if set(raw)!=METHODS or {method_key(m) for m in c['methods']}!=METHODS: raise ValueError('API method set mismatch')
 physical={m['name']:m['code']['bcis'] for m in profile_doc['target_facts']['methods'] if m.get('code')}
 for m in c['methods']:
  ident=method_key(m); rep=raw[ident]['outcome']['report']
  if m['outcome_kind']!='recovered' or m['quality']!='structured' or m['fallbacks'] or not m['map_audit']['covers_all_physical_bcis'] or m['map_audit']['issues']: raise ValueError(f'not fully structured/map-complete: {ident}')
  if m['raw_text']!=rep['text'] or m['source_map']!=rep['source_map']: raise ValueError(f'raw report summary mismatch {ident}')
  b=m['raw_text'].encode('utf-8'); segs=m['source_map'].get('segments')
  if not isinstance(segs,list): raise ValueError(f'missing source map segments {ident}')
  mapped=set()
  for s in segs:
   a,z=s.get('start'),s.get('end')
   if not isinstance(a,int) or not isinstance(z,int) or not (0<=a<z<=len(b)): raise ValueError(f'UTF-8 map bounds invalid {ident}')
   mapped |= origin_bcis(s.get('origin',{}))
  expected=set(physical.get(ident[0],[]))
  if mapped!=expected or set(m['map_audit']['physical_bcis'])!=expected or set(m['map_audit']['mapped_bcis'])!=expected: raise ValueError(f'physical BCI coverage mismatch {ident}')
 cmd=cmds[c['command']]
 if cmd['exit_code']!=0 or pin(cmd['streams']['stdout'],'API stdout').read_bytes()!=reportp.read_bytes(): raise ValueError('API command stdout/report mismatch')
 return report,whole.read_bytes()

def main(receipt,out):
 p=Path(receipt).resolve(strict=True); d=json.loads(p.read_text()); out=Path(out)
 if d.get('schema')!='test-complex-while-loop-full-source-baseline-v1' or d.get('status')!='captured-pending-independent-review': raise ValueError('unexpected or incomplete receipt')
 pins=all_pins(d); cmds=command_map(d)
 if not (d.get('source_unchanged') and d.get('source_unchanged_finally') and d.get('target_absent') and d.get('target_absent_finally') and d.get('external_inputs_unchanged') and d.get('local_copies_unchanged') and d.get('local_copies_unchanged_finally')): raise ValueError('source/cleanup guard failed')
 if not (d['source_pins_before']==d['source_pins_after']==d['source_pins_after_finally']): raise ValueError('source closure snapshots differ')
 if not (d['external_input_pins_before']==d['external_input_pins_after']==d['external_input_pins_after_finally']): raise ValueError('external input snapshots differ')
 if not (d['local_copy_pins_before']==d['local_copy_pins_after']==d['local_copy_pins_after_finally']): raise ValueError('local copy snapshots differ')
 if pin(d['source'],'upstream source').read_bytes()!=pin(d['source_copy'],'source copy').read_bytes(): raise ValueError('source copy changed')
 profiles={x['profile']:x for x in d['source_profiles']}
 if set(profiles)!={'debug','no-debug'}: raise ValueError('profile inventory mismatch')
 for name,prof in profiles.items():
  if prof['exit_code']!=0 or prof['target_facts']['major']!=52 or prof['outer_facts']['major']!=52: raise ValueError('original class compile/facts mismatch')
  if set(prof['class_tree'])!={'jadx/tests/integration/loops/TestComplexWhileLoop$TestCls.class','jadx/tests/integration/loops/TestComplexWhileLoop.class'}: raise ValueError('incomplete outer/child class tree')
  if prof['target_facts']['class_name']!='jadx/tests/integration/loops/TestComplexWhileLoop$TestCls' or prof['outer_facts']['class_name']!='jadx/tests/integration/loops/TestComplexWhileLoop': raise ValueError('class identities mismatch')
  for method in prof['target_facts']['methods']:
   code=method.get('code')
   if code:
    if code['code_length']!=len(code['code_hex'])//2 or not code['bcis'] or len(code['bcis'])!=len(set(code['bcis'])) or any(not 0<=b<code['code_length'] for b in code['bcis']): raise ValueError('invalid physical Code/BCI facts')
 if len(d['jarde_cells'])!=8 or len(d['jadx_outputs'])!=2: raise ValueError('API/JADX grid incomplete')
 by={}
 for c in d['jarde_cells']:
  key=(c['profile'],c['input_form'],c['evidence'])
  if key in by: raise ValueError('duplicate Jarde API selector')
  by[key]=c
 if set(by)!={(p,f,e) for p in profiles for f in ('child','bundle-child') for e in ('default','all')}: raise ValueError('Jarde selector grid mismatch')
 content={}
 for key,c in by.items(): content[key]=check_cell(c,cmds,profiles[c['profile']])
 for prof in profiles:
  for form in ('child','bundle-child'):
   a=by[(prof,form,'default')]; b=by[(prof,form,'all')]
   if content[(prof,form,'default')][1]!=content[(prof,form,'all')][1]: raise ValueError('default/all whole source differs')
   ma={method_key(x):(x['raw_text'],x['source_map'],x['quality'],x['outcome_kind']) for x in a['methods']}
   mb={method_key(x):(x['raw_text'],x['source_map'],x['quality'],x['outcome_kind']) for x in b['methods']}
   if ma!=mb: raise ValueError('default/all raw method text/map/outcome differs')
 # Runtime manual oracle: assert only the requested observable semantics, repeated identically on four VM/profile cells.
 expected=[(n,*v) for n,v in EXPECTED_CASES.items()]
 if d['runtime_case_names']!=[x[0] for x in expected]: raise ValueError('runtime case order changed')
 if len(d['original_runtime'])!=4: raise ValueError('expected four original runtime cells')
 normalized=[]
 for row in d['original_runtime']:
  if row['exit_code']!=0 or len(row['rows'])!=7: raise ValueError('original VM run failed/incomplete')
  cmd=cmds[row['command']]
  if cmd['exit_code']!=0 or cmd['tool_leg']!=row['runtime'] or '-Xss' in cmd['argv']: raise ValueError('runtime command/tool/default-stack contract mismatch')
  root=Path(row['target_root']).resolve(); cp=row['application_classpath']
  driver_root=str(Path(pin(d['driver_classes'][0],'driver class').resolve().parent))
  if cp!=[driver_root] or cmd['argv'][-2:]!=[str(root),str(root)]: raise ValueError('parentless runtime classpath/root mismatch')
  stdout=pin(row['stdout'],'runtime stdout').read_text(); raw=[x['raw'] for x in row['rows']]
  if stdout.splitlines()!=raw: raise ValueError('runtime parsed rows differ from raw stdout')
  for got,(name,inp,result,exc,targetout) in zip(row['rows'],expected):
   if (got['name'],got['input'],got.get('result',''),(None if got.get('exception_type')=='none' else got.get('exception_type')),got.get('target_stdout',''))!=(name,inp,result,exc,targetout): raise ValueError(f'manual runtime oracle mismatch {row["profile"]}/{row["runtime"]}/{name}')
  normalized.append([(r['name'],r['input'],r.get('result',''),(None if r.get('exception_type')=='none' else r.get('exception_type')),r.get('target_stdout','')) for r in row['rows']])
 if any(x!=normalized[0] for x in normalized[1:]): raise ValueError('original runtime semantic outputs differ across JDK/profile')
 wrong=d['wrong_root_control']; wc=cmds[wrong['command']]
 if wrong['exit_code']!=1 or wc['exit_code']!=1 or wrong['rejected'] is not True: raise ValueError('wrong-root control did not reject')
 if b'wrong CodeSource:' not in pin(wrong['stderr'],'wrong-root stderr').read_bytes(): raise ValueError('wrong-root reason absent')
 # command-derived inventory and unchanged source ownership are checked without executing tools.
 count=d['counts_derived_from_commands']
 if count.get('commands')!=20 or count.get('raw_streams')!=40 or count.get('original_runtime_runs')!=4 or count.get('wrong_root_runs')!=1 or count.get('jarde_calls')!=8: raise ValueError('command-derived counts disagree')
 summary={'receipt_sha256':sha(p),'commands':len(cmds),'raw_streams':40,'unique_pinned_paths':len(pins),'profiles':2,'api_cells':8,'api_methods':16,'api_all_structured_and_bci_mapped':True,'default_all_presentation_and_maps_equal':True,'jadx_cells':2,'original_vm_cells':4,'runtime_case_observations':28,'manual_cases_match':7,'wrong_root_exit':wc['exit_code'],'source_snapshots_stable':True,'target_absent_after_cleanup':True}
 out.mkdir(parents=True,exist_ok=True)
 (out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
 return summary

if __name__=='__main__':
 try: print(json.dumps(main(sys.argv[1],sys.argv[2]),indent=2,sort_keys=True))
 except Exception as e: print(type(e).__name__+': '+str(e),file=sys.stderr); raise
