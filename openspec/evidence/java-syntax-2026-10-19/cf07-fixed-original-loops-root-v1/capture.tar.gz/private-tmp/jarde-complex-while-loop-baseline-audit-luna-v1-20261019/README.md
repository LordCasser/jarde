# Complex while-loop baseline receipt audit

Read-only Python audit of the completed baseline receipt. It reopens every path/bytes/SHA pin recursively, all command raw streams, class/source/API/driver artifacts, and source/external/local snapshots. It checks the exact 2-profile physical outer+child class inventory, all eight default/all Jarde API cells, UTF-8 source-map bounds and full physical BCI coverage, the four original VM rows, the seven manually specified observable cases, the wrong-CodeSource rejection, and cleanup/guard summaries.

The audit does not run the collector, CLI, compilers, or JVM. It does not assess generated-output recovery; that matrix is pending. The two compile errors/JADX data remain as captured.
