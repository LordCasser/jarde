package jadx.tests.integration.loops;

import jadx.tests.api.SmaliTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestLoopCondition5.class */
public class TestLoopCondition5 extends SmaliTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestLoopCondition5$TestCls.class */
    public static class TestCls {
        public static int lastIndexOf(int[] iArr, int i, int i2, int i3) {
            for (int i4 = i3 - 1; i4 >= i2; i4--) {
                if (iArr[i4] == i) {
                    return i4;
                }
            }
            return -1;
        }
    }

    @Test
    public void test0() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("for (").containsOne("return -1;").countString(2, "return ");
    }

    @Test
    public void test1() {
        JadxAssertions.assertThat(getClassNodeFromSmaliWithPath("loops", "TestLoopCondition5")).code().containsOneOf(new String[]{"for (", "while (true) {", "} while (iArr[i3] != i);"}).containsOne("return -1;").countString(2, "return ");
    }
}
