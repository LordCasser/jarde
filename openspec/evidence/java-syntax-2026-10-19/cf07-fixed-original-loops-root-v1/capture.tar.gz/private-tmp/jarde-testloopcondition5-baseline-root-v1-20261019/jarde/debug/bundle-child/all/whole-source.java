// jarde: presentation of `jadx/tests/integration/loops/TestLoopCondition5$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestLoopCondition5$TestCls extends java.lang.Object {
    public TestLoopCondition5$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestLoopCondition5$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static int lastIndexOf(int[] array, int target, int start, int end) {
        // @method lastIndexOf([IIII)I
        // @declaration a static method of `jadx.tests.integration.loops.TestLoopCondition5$TestCls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int i;
        for (i = end - 1; i >= start; i = i - 1) {
            if (array[i] == target) {
                return i;
            }
        }
        return -1;
    }
}
