#!/usr/bin/env python3
"""Independent read-only audit of the frozen TestLoopCondition5 baseline receipt."""
import hashlib, importlib.util, json, sys, zipfile
from pathlib import Path

RECEIPT = Path('/private/tmp/jarde-testloopcondition5-baseline-root-v1-20261019/execution.json')
RECEIPT_SHA256 = '29802c810f2f4e557d8254ac2242507a0a635ff1382653f5ce8ad78762c06672'
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
PARSER = Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
COMPARE_REL = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
INTERNAL = 'jadx/tests/integration/loops/TestLoopCondition5$TestCls'
OUTER = 'jadx/tests/integration/loops/TestLoopCondition5'
METHODS = {('<init>', '()V'), ('lastIndexOf', '([IIII)I')}
OUTER_METHODS = {('<init>', '()V'), ('test0', '()V'), ('test1', '()V')}
CASES = [
 ('duplicate-last-hit','[2,1,2];target=2;start=0;end=3','2','none',''),
 ('hit-at-start','[2,1,3];target=2;start=0;end=3','0','none',''),
 ('miss','[1,2,3];target=7;start=0;end=3','-1','none',''),
 ('exclude-tail','[2,1,2];target=2;start=0;end=2','0','none',''),
 ('empty-range','[1,2];target=1;start=1;end=1','-1','none',''),
 ('null-array-empty-range','<null-array>;target=1;start=0;end=0','-1','none',''),
 ('reversed-range','[1,2];target=1;start=2;end=1','-1','none',''),
 ('null-array-read','<null-array>;target=1;start=0;end=1','','java.lang.NullPointerException',''),
 ('negative-index','[1];target=1;start=-1;end=0','','java.lang.ArrayIndexOutOfBoundsException',''),
 ('past-end-index','[1];target=1;start=0;end=2','','java.lang.ArrayIndexOutOfBoundsException',''),
]

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pin(rec, label):
 if not isinstance(rec,dict) or not {'path','bytes','sha256'} <= rec.keys(): raise ValueError(f'{label}: malformed pin')
 p=Path(rec['path']).resolve(strict=True)
 if p.stat().st_size != rec['bytes'] or sha(p) != rec['sha256']: raise ValueError(f'{label}: pin mismatch: {p}')
 return p
def all_pins(value, seen=None, label='receipt'):
 if seen is None: seen={}
 if isinstance(value,dict):
  if {'path','bytes','sha256'} <= value.keys():
   p=pin(value,label); seen[str(p)]=(value['bytes'],value['sha256']); return seen
  for k,v in value.items(): all_pins(v,seen,f'{label}.{k}')
 elif isinstance(value,list):
  for i,v in enumerate(value): all_pins(v,seen,f'{label}[{i}]')
 return seen
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path)
 if spec is None or spec.loader is None: raise RuntimeError(f'cannot load helper {path}')
 m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
def norm(x):
 if isinstance(x,dict): return {k:norm(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)): return [norm(v) for v in x]
 return x
def origin_rows(origin):
 return [x for x in [origin.get('primary'), *origin.get('derived',[])] if isinstance(x,dict)]
def method_identity(m): return (m['name'],m['descriptor'])
def main(out):
 p=RECEIPT.resolve(strict=True)
 if sha(p)!=RECEIPT_SHA256: raise ValueError('receipt SHA mismatch')
 d=json.loads(p.read_text())
 if d.get('schema')!='test-loopcondition5-full-source-baseline-v1' or d.get('status')!='captured-pending-independent-review': raise ValueError('unexpected receipt schema/status')
 if len(d['commands'])!=20: raise ValueError('expected 20 command rows')
 commands={r['index']:r for r in d['commands']}
 if set(commands)!=set(range(1,21)): raise ValueError('command indices are not exactly 1..20')
 pins=all_pins(d)
 for r in d['commands']:
  if r.get('guard_stop') is not None or r.get('peak_target_bytes',0)>1024**3 or r.get('free_bytes_after',0)<5*1024**3: raise ValueError(f'guard failure in command {r["index"]}')
  for ch in ('stdout','stderr'): pin(r['streams'][ch],f'command {r["index"]} {ch}')
 for key in ('source_unchanged','source_unchanged_finally','target_absent','target_absent_finally','external_inputs_unchanged','local_copies_unchanged','local_copies_unchanged_finally'):
  if d.get(key) is not True: raise ValueError(f'capture guard failed: {key}')
 for a,b,c in [('source_pins_before','source_pins_after','source_pins_after_finally'),('external_input_pins_before','external_input_pins_after','external_input_pins_after_finally'),('local_copy_pins_before','local_copy_pins_after','local_copy_pins_after_finally')]:
  if not d[a]==d[b]==d[c]: raise ValueError(f'pin snapshots differ: {a}/{b}/{c}')
 if pin(d['source'],'upstream source').read_bytes()!=pin(d['source_copy'],'source copy').read_bytes(): raise ValueError('upstream source copy differs')
 compare=load(ROOT/COMPARE_REL,'condition5_compare')
 physical=load(PARSER,'condition5_physical')
 profiles={x['profile']:x for x in d['source_profiles']}
 if set(profiles)!={'debug','no-debug'}: raise ValueError('profile set mismatch')
 expected_tree={INTERNAL+'.class',OUTER+'.class'}
 physical_methods={}
 for profile,row in profiles.items():
  if row['exit_code']!=0 or set(row['class_tree'])!=expected_tree: raise ValueError(f'{profile}: original full class tree mismatch')
  for rel,rec in row['class_tree'].items():
   cls=pin(rec,f'{profile} class {rel}')
   facts=compare.parse_class(cls); independently=physical.parse_class_file(cls.read_bytes())
   if facts['class_name']!=independently['class_name'] or facts['major']!=independently['major'] or facts['methods']!=independently['methods']:
    raise ValueError(f'{profile}/{rel}: parser disagreement')
   if independently['major']!=52: raise ValueError(f'{profile}/{rel}: expected major 52')
   key=(profile,rel)
   physical_methods[key]={ (m['name'],m['descriptor']):m for m in independently['methods'] }
  target=row['target_facts']; outer=row['outer_facts']
  if target['class_name']!=INTERNAL or outer['class_name']!=OUTER: raise ValueError(f'{profile}: class identity mismatch')
  if {(m['name'],m['descriptor']) for m in target['methods']}!=METHODS: raise ValueError(f'{profile}: target inventory mismatch')
  if {(m['name'],m['descriptor']) for m in outer['methods']}!=OUTER_METHODS: raise ValueError(f'{profile}: outer inventory mismatch')
  bundle=pin(row['bundle'],f'{profile} complete bundle')
  with zipfile.ZipFile(bundle) as z:
   names=sorted(n for n in z.namelist() if not n.endswith('/'))
   if names!=sorted(expected_tree): raise ValueError(f'{profile}: bundle membership mismatch')
   for name in expected_tree:
    if z.read(name)!=Path(row['class_root'],name).read_bytes(): raise ValueError(f'{profile}: bundle content mismatch for {name}')
 if len(d['jarde_cells'])!=8 or len(d['jadx_outputs'])!=2: raise ValueError('API/JADX grid incomplete')
 cells={}
 for c in d['jarde_cells']:
  key=(c['profile'],c['input_form'],c['evidence'])
  if key in cells: raise ValueError(f'duplicate API cell {key}')
  cells[key]=c
 if set(cells)!={(p,f,e) for p in profiles for f in ('child','bundle-child') for e in ('default','all')}: raise ValueError('API selectors incomplete')
 reports={}
 for key,c in cells.items():
  if c['exit_code']!=0: raise ValueError(f'API failed {key}')
  inp=pin(c['input'],f'API input {key}'); report_path=pin(c['report'],f'API report {key}'); whole=pin(c['whole_source'],f'whole source {key}')
  target_bytes=pin(profiles[key[0]]['target_facts'],f'target facts {key[0]}').read_bytes()
  if key[1]=='child': actual=inp.read_bytes()
  else:
   with zipfile.ZipFile(inp) as z: actual=z.read(INTERNAL+'.class')
  if actual!=target_bytes: raise ValueError(f'API input is not exact original target {key}')
  report=json.loads(report_path.read_text()); report_text=report['text'].encode()
  if whole.read_bytes()!=report_text: raise ValueError(f'whole-source mismatch {key}')
  if pin(commands[c['command']]['streams']['stdout'],f'API raw stdout {key}').read_bytes()!=report_path.read_bytes(): raise ValueError(f'API report not bound to raw command stdout {key}')
  if c['physical_method_inventory']!=c['expected_physical_method_inventory'] or {tuple(x) for x in c['physical_method_inventory']}!=METHODS: raise ValueError(f'API physical inventory mismatch {key}')
  raw={}
  for rm in report['methods']:
   ident=(rm['item']['name']['escaped'],rm['item']['descriptor']['escaped'])
   if ident in raw: raise ValueError(f'duplicate report method {key}/{ident}')
   raw[ident]=rm
  if set(raw)!=METHODS or {method_identity(m) for m in c['methods']}!=METHODS: raise ValueError(f'API method identities mismatch {key}')
  target_fact={ (m['name'],m['descriptor']):m for m in profiles[key[0]]['target_facts']['methods'] }
  for m in c['methods']:
   ident=method_identity(m); rep=raw[ident]['outcome']['report']; facts=target_fact[ident]; bcis=set(facts['code']['bcis'])
   if m['outcome_kind']!='recovered' or m['quality']!='structured' or m['fallbacks'] or not m['map_audit']['covers_all_physical_bcis'] or m['map_audit']['issues']: raise ValueError(f'API method not structured/map-complete {key}/{ident}')
   if m['raw_text']!=rep['text'] or m['source_map']!=rep['source_map']: raise ValueError(f'raw report summary mismatch {key}/{ident}')
   utf8=m['raw_text'].encode('utf-8'); mapped=set()
   for seg in m['source_map'].get('segments',[]):
    a,z=seg.get('start'),seg.get('end')
    if not isinstance(a,int) or not isinstance(z,int) or not (0<=a<z<=len(utf8)): raise ValueError(f'UTF-8 map bounds invalid {key}/{ident}')
    for orig in origin_rows(seg.get('origin',{})):
     if orig.get('method') is None or (orig['method'].get('name'),orig['method'].get('descriptor'))!=(list(ident[0].encode()),list(ident[1].encode())):
      raise ValueError(f'map origin method mismatch {key}/{ident}')
     owner=orig['method'].get('owner',{}).get('class_bytes',{})
     if owner.get('digest')!=m['identity']['owner']['class_bytes']['digest']: raise ValueError(f'map origin owner mismatch {key}/{ident}')
     if not isinstance(orig.get('bci'),int) or orig['bci'] not in bcis: raise ValueError(f'map origin BCI outside Code {key}/{ident}')
     mapped.add(orig['bci'])
   if mapped!=bcis or set(m['map_audit']['physical_bcis'])!=bcis or set(m['map_audit']['mapped_bcis'])!=bcis: raise ValueError(f'map does not cover exact physical Code BCIs {key}/{ident}')
  reports[key]=(report_text,{method_identity(m):(m['raw_text'],m['source_map'],m['quality'],m['outcome_kind']) for m in c['methods']})
 for p in profiles:
  for f in ('child','bundle-child'):
   if reports[(p,f,'default')]!=reports[(p,f,'all')]: raise ValueError(f'default/all report differs {p}/{f}')
 if d['runtime_case_names']!=[x[0] for x in CASES]: raise ValueError('runtime case names/order mismatch')
 if len(d['original_runtime'])!=4: raise ValueError('expected 4 original VM runs')
 normalized=[]
 for row in d['original_runtime']:
  if row['exit_code']!=0 or len(row['rows'])!=len(CASES): raise ValueError('runtime run incomplete')
  cmd=commands[row['command']]
  if cmd['exit_code']!=0 or cmd['tool_leg']!=row['runtime'] or '-Xss' in cmd['argv']: raise ValueError('runtime command/stack mismatch')
  target=Path(row['target_root']).resolve(); driver=Path(pin(d['driver_classes'][0],'driver class').resolve().parent)
  if row['application_classpath']!=[str(driver)] or cmd['argv'][-2:]!=[str(target),str(target)]: raise ValueError('runtime classpath or actual/expected roots mismatch')
  stdout=pin(row['stdout'],'runtime stdout').read_text().splitlines()
  if stdout!=[x['raw'] for x in row['rows']]: raise ValueError('runtime parsed rows differ from stdout')
  got=[]
  for r,expected in zip(row['rows'],CASES):
   value=(r['name'],r['input'],r['result'],r['exception_type'],r['target_stdout'])
   if value!=expected: raise ValueError(f'manual oracle mismatch {row["profile"]}/{row["runtime"]}/{r["name"]}: {value!r}')
   got.append(value)
  normalized.append(got)
 if any(x!=normalized[0] for x in normalized[1:]): raise ValueError('original runtime outputs differ across profile/runtime')
 wrong=d['wrong_root_control']; wc=commands[wrong['command']]
 if wrong['exit_code']!=1 or wc['exit_code']!=1 or not wrong['rejected'] or b'wrong CodeSource:' not in pin(wrong['stderr'],'wrong-root stderr').read_bytes(): raise ValueError('wrong-CodeSource negative control failed')
 if d['counts_derived_from_commands'].get('commands')!=20 or d['counts_derived_from_commands'].get('raw_streams')!=40: raise ValueError('derived command/stream counts mismatch')
 summary={'receipt_sha256':RECEIPT_SHA256,'commands':20,'raw_streams':40,'unique_pinned_paths':len(pins),'profiles':2,'original_runtime_runs':4,'manual_cases_per_run':10,'manual_case_observations':40,'api_cells':8,'api_methods':16,'api_structured_and_full_code_mapped':True,'jadx_outputs':2,'wrong_root_rejected':True,'source_and_cleanup_snapshots_stable':True,'target_absent_finally':True,'full_generated_matrix_reviewed':False}
 out=Path(out); out.mkdir(parents=True,exist_ok=False); (out/'review.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
 return summary
if __name__=='__main__':
 print(json.dumps(main(sys.argv[1]),indent=2,sort_keys=True))
