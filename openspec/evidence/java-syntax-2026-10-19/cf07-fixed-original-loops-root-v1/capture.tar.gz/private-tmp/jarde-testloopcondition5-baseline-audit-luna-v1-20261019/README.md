# TestLoopCondition5 baseline audit

This is a read-only independent audit of `/private/tmp/jarde-testloopcondition5-baseline-root-v1-20261019/execution.json` (SHA-256 `29802c810f2f4e557d8254ac2242507a0a635ff1382653f5ce8ad78762c06672`). `audit.py` reopened every receipt pin and command stream, checked all 20 command rows and resource guards, compared source/tool/local-copy snapshots through cleanup, and confirmed the target directory stayed absent.

The audit independently parsed the full outer/child classfiles in both original profiles with `compare.py` and the physical classfile parser. It checked the exact target and outer method inventories, the complete two-class bundles, all eight Jarde input/report/whole-source artifacts, raw command stdout binding, both evidence modes, method identities and source-map UTF-8 bounds, source-map owner/method identity, and exact physical Code BCI coverage. It also checked the two complete JADX source-output trees and the wrong-CodeSource rejection.

The ten manual oracle cases match in all four original VM/profile runs. Specifically, `null-array-empty-range` returned `-1` with no exception, while `null-array-read` produced `NullPointerException`; negative and past-end indexes produced `ArrayIndexOutOfBoundsException`. The review does not claim the generated source matrix is complete. The structured review result is `review/review.json`.

The audit was run using Python only. It did not execute the collector, compilers, JVMs, JADX, Jarde CLI, Cargo, Git, or network.
