# TestLoopCondition5 full generated-source matrix preparation

Private preparation only; the collector has not been run. It is based on the accepted LoopConditionInvoke generated-matrix v5 and carries over the root-reviewed v2 fixes from the ComplexWhileLoop matrix preparation. It takes the completed TestLoopCondition5 baseline receipt and requires the explicit receipt SHA and the pinned current CLI path/hash.

Baseline receipt: `/private/tmp/jarde-testloopcondition5-baseline-root-v1-20261019/execution.json`, SHA-256 `29802c810f2f4e557d8254ac2242507a0a635ff1382653f5ce8ad78762c06672`. The original receipt has 20 commands, 4 VM/profile runs × 10 cases, 8 Jarde API cells and 2 complete JADX source outputs. The sibling private audit independently reopened its pins and raw streams, verified source/cleanup snapshots, parsed both original outer/target class trees with the two class parsers, checked all 16 API methods and full physical BCI maps, and confirmed the manual runtime rows including null-array empty-range (`-1`, no exception) separately from null-array read (NPE). That audit does not claim the generated matrix is complete.

The collector rebuilds the eight saved Jarde target-child sources independently with each configured Java 8-target compiler and compiles both complete JADX outer sources unchanged. It checks the exact expected class trees: Jarde cells must yield only `TestLoopCondition5$TestCls.class`; JADX cells must retain both outer and nested child classes. Every successful candidate class is checked against its matching original profile’s method and field identities/access. Only eligible compiles receive both VM runs and wrong-CodeSource checks. The original per-profile runtime observations remain the comparison oracle; failures stay recorded and do not get runtime rows.

The complete original upstream source includes the separate Smali-backed `test1` and remains unchanged. The source-baseline collector recorded its Java 8 full-source major-55 harness boundary; this generated-source stage preserves that history and does not trim the source. The matrix is not yet run, and no product recovery outcome is assumed.

Prepared collector: `collect_generated_matrix.py`. `collector-adaptation.diff` compares it with accepted LoopConditionInvoke v5. `pins.json` binds the receipt, CLI, driver, accepted template, collector and adaptation. The intended invocation is:

```sh
python3 -B /private/tmp/jarde-testloopcondition5-generated-prep-luna-v1-20261019/collect_generated_matrix.py \
  --baseline /private/tmp/jarde-testloopcondition5-baseline-root-v1-20261019/execution.json \
  --baseline-sha256 29802c810f2f4e557d8254ac2242507a0a635ff1382653f5ce8ad78762c06672 \
  --cli /private/tmp/jarde-assignment-condition-widening-broad-resume-root-v1-20261019/candidate-cli \
  --out /private/tmp/jarde-testloopcondition5-generated-root-v1-20261019
```

No collector, compiler, VM, CLI, Cargo, Git, or network command was run for this preparation.
