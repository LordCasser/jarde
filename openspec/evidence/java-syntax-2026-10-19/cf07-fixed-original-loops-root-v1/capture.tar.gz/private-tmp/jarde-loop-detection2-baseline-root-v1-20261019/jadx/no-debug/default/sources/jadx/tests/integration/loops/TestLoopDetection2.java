package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestLoopDetection2.class */
public class TestLoopDetection2 extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestLoopDetection2$TestCls.class */
    public static class TestCls {
        public int test(int i, int i2) {
            int i3 = i + i2;
            int i4 = i;
            while (i4 < i2) {
                i3 = i4 == 7 ? i3 + 2 : i3 * 2;
                i4++;
            }
            return i3 - 1;
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("int c = a + b;").containsOne("for (int i = a; i < b; i++) {").doesNotContain(new CharSequence[]{"c_2"});
    }
}
