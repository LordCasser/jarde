package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestLoopDetection2.class */
public class TestLoopDetection2 extends IntegrationTest {

    /* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestLoopDetection2$TestCls.class */
    public static class TestCls {
        public int test(int a, int b) {
            int c = a + b;
            for (int i = a; i < b; i++) {
                if (i == 7) {
                    c += 2;
                } else {
                    c *= 2;
                }
            }
            return c - 1;
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("int c = a + b;").containsOne("for (int i = a; i < b; i++) {").doesNotContain(new CharSequence[]{"c_2"});
    }
}
