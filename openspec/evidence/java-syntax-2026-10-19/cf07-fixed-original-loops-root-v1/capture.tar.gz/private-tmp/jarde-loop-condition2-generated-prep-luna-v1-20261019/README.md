# TestLoopCondition2 generated-source collector preparation

Private static preparation derived from the root-accepted ComplexWhileLoop generated collector v2. The adapted collector was syntax-parsed and its constants checked; it was not run.

The baseline receipt is `/private/tmp/jarde-loop-condition2-baseline-root-v1-20261019/execution.json` (SHA-256 `fb0c3166c422e3660393de201e12cd25e103ed235967bd50145355b4652ac114`). The independent read-only baseline audit passed its recorded schema, command/raw pin, source snapshot, physical class/Code/BCI, complete source-map UTF-8 spans, parentless CodeSource rejection, and manual runtime oracle checks. Audit output: `/private/tmp/jarde-loopcondition2-detection2-baseline-audit-luna-v1-20261019/audit.json`. Derived evidence: 20 commands/40 raw streams; 4 original VM cells with 8 observed case rows; 8 structured API cells and 16 method reports; 2 full JADX outputs.

The driver uses `TestLoopCondition2$TestCls` through a parentless loader and contains only the frozen finite cases: condition-false, condition-true. Target descriptor: `test(Z)I`. The adapted generated collector keeps complete Jarde child sources and full JADX outer source trees unchanged, compiles with both configured Java 8-target compiler legs, and only runs successfully parsed classes with exact target identity/inventory and the inherited CodeSource/oracle gates. It does not patch generated sources. Compiler refusals remain recorded without runtime rows.

Collector SHA-256: `26454a7f2149f3b1c454f7e4e9264c92ee989ad70aaf932143d3812379979c55`. Driver SHA-256: `3eb7224bb15b018a5b66725db090631b31f4fa98db58e9115de6726869e00ecf`. Adaptation diff and audit pins are in `collector-adaptation.diff` and `pins.json`. No generated matrix was executed or accepted.

After root review and acceptance of the baseline audit, the root can run:

```sh
python3 -B /private/tmp/jarde-loop-condition2-generated-prep-luna-v1-20261019/collect_generated_matrix.py \
  --baseline /private/tmp/jarde-loop-condition2-baseline-root-v1-20261019/execution.json \
  --baseline-sha256 fb0c3166c422e3660393de201e12cd25e103ed235967bd50145355b4652ac114 \
  --cli /private/tmp/jarde-assignment-condition-widening-broad-resume-root-v1-20261019/candidate-cli \
  --out /private/tmp/jarde-loop-condition2-generated-root-v1-20261019
```
