package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestLoopCondition2.class */
public class TestLoopCondition2 extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestLoopCondition2$TestCls.class */
    public static class TestCls {
        public int test(boolean z) {
            int i = 0;
            while (z && i < 10) {
                i++;
            }
            return i;
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("int i = 0;").containsOne("while (a && i < 10) {").containsOne("i++;").containsOne("return i;");
    }
}
