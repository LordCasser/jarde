// jarde: presentation of `jadx/tests/integration/loops/TestLoopCondition2$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestLoopCondition2$TestCls extends java.lang.Object {
    public TestLoopCondition2$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestLoopCondition2$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public int test(boolean a) {
        // @method test(Z)I
        // @declaration an instance method of `jadx.tests.integration.loops.TestLoopCondition2$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int i;
        i = 0;
        while (a && i < 10) {
            i = i + 1;
        }
        return i;
    }
}
