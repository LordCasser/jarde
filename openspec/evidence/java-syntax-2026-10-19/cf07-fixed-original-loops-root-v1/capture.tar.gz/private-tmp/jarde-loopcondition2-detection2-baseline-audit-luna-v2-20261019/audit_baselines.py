#!/usr/bin/env python3
"""Read-only integrity and semantic audit for the two completed CF07 baseline receipts."""
import hashlib, importlib.util, json, re, zipfile
from pathlib import Path

TEMPLATE=Path('/private/tmp/jarde-complex-while-loop-generated-prep-luna-v2-20261019/collect_generated_matrix.py')
TEMPLATE_SHA='9884133a1a3571e5ccdc509af1bf2fbd11052d521fe94e7708298dc5f3fc8d80'
CONFIGS={
 'condition2': {'root':Path('/private/tmp/jarde-loop-condition2-baseline-root-v1-20261019'),'outer':'TestLoopCondition2','schema':'test-loop-condition2-full-source-baseline-v1','method':'(Z)I','cases':['condition-false','condition-true'],'expected':[('false','0','none',''),('true','10','none','')]},
 'detection2': {'root':Path('/private/tmp/jarde-loop-detection2-baseline-root-v1-20261019'),'outer':'TestLoopDetection2','schema':'test-loop-detection2-full-source-baseline-v1','method':'(II)I','cases':['range-1-4','range-6-9','empty-5-5','negative-range-minus2-2','reversed-4-1'],'expected':[('1,4','39','none',''),('6,9','63','none',''),('5,5','9','none',''),('-2,2','-1','none',''),('4,1','4','none','')]}}

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):
 p=Path(p).resolve(strict=True); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def require(ok,msg):
 if not ok: raise AssertionError(msg)
def load(path,name):
 s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
def main():
 require(sha(TEMPLATE)==TEMPLATE_SHA,'accepted template pin changed')
 template=load(TEMPLATE,'accepted_complex_template_readonly')
 result=[]
 for key,cfg in CONFIGS.items():
  base=cfg['root']; receipt=base/'execution.json'; d=json.loads(receipt.read_text())
  require(d.get('schema')==cfg['schema'],key+': receipt schema mismatch')
  require(d.get('status')=='captured-pending-independent-review',key+': receipt is not captured pending review')
  require(d.get('root')=='/Users/lordcasser/workspace/projects/jarde',key+': workspace root mismatch')
  cmds=d['commands']; byid={x['index']:x for x in cmds}
  require(len(cmds)==20 and len(byid)==len(cmds),key+': command count/ids mismatch')
  for cmd in cmds:
   require(cmd.get('guard_stop') is None,key+': guard stopped '+str(cmd.get('label')))
   for channel in ('stdout','stderr'):
    stream=cmd['streams'][channel]; p=Path(stream['path']).resolve(strict=True)
    require(pin(p)==stream,key+': raw stream pin mismatch '+str(p))
  require(d.get('source_unchanged') is True and d.get('source_unchanged_finally') is True,key+': source closure flags')
  require(d.get('target_absent') is True and d.get('target_absent_finally') is True,key+': target absence flags')
  require(d.get('external_inputs_unchanged') is True and d.get('local_copies_unchanged') is True and d.get('local_copies_unchanged_finally') is True,key+': closure flags')
  require(d['source_pins_before']==d['source_pins_after']==d['source_pins_after_finally'],key+': live source snapshots differ')
  for rec in d['source_pins_before'].values(): require(pin(rec['path'])==rec,key+': live source pin mismatch '+rec['path'])
  require(d['external_input_pins_before']==d['external_input_pins_after']==d['external_input_pins_after_finally'],key+': external snapshots differ')
  require(d['local_copy_pins_before']==d['local_copy_pins_after']==d['local_copy_pins_after_finally'],key+': local copy snapshots differ')
  for rec in d['local_copy_pins_before'].values(): require(pin(rec['path'])==rec,key+': local copy pin mismatch '+rec['path'])
  for group in ('files','dependency_artifacts'):
   for rec in d['external_input_pins_before'].get(group,[]): require(pin(rec['path'])==rec,key+': external pin mismatch '+rec['path'])
  for group in d['external_input_pins_before'].get('directories',[]):
   for rec in group.values(): require(pin(rec['path'])==rec,key+': external directory pin mismatch '+rec['path'])
  require(pin(d['source']['path'])==d['source'],key+': upstream source pin mismatch')
  require(pin(d['cli']['path'])==d['cli'] and d['cli']['sha256']=='96e534b0000fe91c1d34a282919479a97eb4706063501d188cdff010c4640366',key+': CLI pin mismatch')
  require(pin(d['runtime_wrapper']['path'])==d['runtime_wrapper'],key+': runtime wrapper pin mismatch')
  require(pin(d['driver_source']['path'])==d['driver_source'] and pin(d['driver_copy']['path'])==d['driver_copy'],key+': driver source/copy pin mismatch')
  require(Path(d['driver_source']['path']).read_bytes()==Path(d['driver_copy']['path']).read_bytes(),key+': driver copy bytes differ')
  require(d['api_method_inventory_expected']==[['<init>','()V'],['test',cfg['method']]],key+': API inventory expectation mismatch')
  profiles={r['profile']:r for r in d['source_profiles']}; require(set(profiles)=={'debug','no-debug'},key+': source profile grid')
  targetname=f"jadx/tests/integration/loops/{cfg['outer']}$TestCls"
  outername=f"jadx/tests/integration/loops/{cfg['outer']}"
  inventories={}
  for profile,pr in profiles.items():
   require(pr['exit_code']==0,key+': original compiler profile failed '+profile)
   require(set(pr['class_tree'])=={targetname+'.class',outername+'.class'},key+': incomplete outer/child class tree '+profile)
   cr=Path(pr['class_root']).resolve(strict=True)
   current={p.relative_to(cr).as_posix():pin(p) for p in cr.rglob('*.class')}
   expected={k:pr['class_tree'][k] for k in pr['class_tree']}
   require(current==expected,key+': original class tree pin mismatch '+profile)
   template.INTERNAL=targetname
   facts=template.parse_profile_facts(load(Path('/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-exception-only-finally-completion/tools/compare.py'),'loop_audit_compare'),load(Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py'),'loop_audit_physical'),cr)
   norm=template.json_normalize
   require(norm(facts[targetname+'.class'])==norm(pr['target_facts']),key+': target full physical facts mismatch '+profile)
   require(norm(facts[outername+'.class'])==norm(pr['outer_facts']),key+': outer full physical facts mismatch '+profile)
   require(pr['target_facts']['class_name']==targetname,key+': target class binary name')
   methods={(m['name'],m['descriptor']) for m in pr['target_facts']['methods']}
   require(methods=={('<init>','()V'),('test',cfg['method'])},key+': physical method inventory')
   inventories[profile]=[(m['name'],m['descriptor'],m['access'],m['code']['code_length'],len(m['code']['bcis']),m['code']['bcis']) for m in pr['target_facts']['methods']]
   bundle=pr['bundle']; require(pin(bundle['path'])==bundle,key+': profile bundle pin')
   with zipfile.ZipFile(bundle['path']) as zf:
    entries=sorted(n for n in zf.namelist() if not n.endswith('/'))
    require(entries==sorted(pr['class_tree']),key+': bundle class inventory differs '+profile)
    for rel in entries: require(zf.read(rel)==(cr/rel).read_bytes(),key+': bundle class bytes differ '+profile+' '+rel)
  template.CASE_NAMES=tuple(cfg['cases'])
  rows=d['original_runtime']; require(len(rows)==4,key+': original runtime grid count')
  runtime_grid=set(); manual=[]
  for run in rows:
   profile,vm=run['profile'],run['runtime']; runtime_grid.add((profile,vm))
   require(run['exit_code']==0 and run['row_count']==len(cfg['cases']),key+': original runtime failed/incomplete')
   cmd=byid[run['command']]; require(cmd['label']==f'original-runtime-{profile}-{vm}' and cmd['exit_code']==0,key+': runtime command identity')
   argv=cmd['argv']; expected_root=Path(profiles[profile]['class_root']).resolve()
   require(len(argv)==11 and argv[2]==d['runtime_wrapper']['path'] and argv[3]=='30' and argv[4].endswith('/bin/java') and argv[5]=='-Xverify:all' and argv[6]=='-cp' and Path(argv[7]).resolve()==(base/'driver-classes').resolve() and argv[8]==cfg['outer']+'Driver' and Path(argv[9]).resolve()==expected_root and Path(argv[10]).resolve()==expected_root,key+': parentless original runtime argv/CodeSource roots mismatch')
   parsed=template.parse_oracle(Path(cmd['streams']['stdout']['path']).read_bytes())
   require(parsed==run['rows'],key+': parsed runtime differs from receipt rows')
   observed=[(r['input'],r['result'],r['exception_type'],r['target_stdout']) for r in parsed]
   require([r['name'] for r in parsed]==cfg['cases'] and observed==cfg['expected'],key+': manual runtime oracle mismatch')
   manual.append(observed)
  require(runtime_grid=={(p,v) for p in profiles for v in ('javac8','javac23')},key+': runtime profile matrix')
  require(all(x==manual[0] for x in manual),key+': cross-profile/runtime oracle mismatch')
  wrong=d['wrong_root_control']; wc=byid[wrong['command']]
  require(wrong['exit_code']==1 and wrong['rejected'] is True and wc['exit_code']==1,key+': wrong-root did not reject with exit 1')
  wa=wc['argv']; require(len(wa)==11 and wa[2]==d['runtime_wrapper']['path'] and wa[3]=='30' and wa[4].endswith('/bin/java') and wa[5]=='-Xverify:all' and wa[6]=='-cp' and Path(wa[7]).resolve()==(base/'driver-classes').resolve() and wa[8]==cfg['outer']+'Driver' and Path(wa[9]).resolve()==Path(wrong['actual_target_root']).resolve() and Path(wa[10]).resolve()==Path(wrong['expected_wrong_root']).resolve(),key+': wrong-root actual argv mismatch')
  we=Path(wc['streams']['stderr']['path']).read_bytes(); require(b'wrong CodeSource:' in we,key+': missing wrong CodeSource diagnostic')
  require(Path(wrong['actual_target_root']).resolve()==Path(profiles['debug']['class_root']).resolve(),key+': wrong-root actual target identity')
  require(Path(wrong['expected_wrong_root']).resolve()==(base/'empty-classpath').resolve(),key+': wrong-root expected identity')
  apis=d['jarde_cells']; require(len(apis)==8,key+': Jarde API cell count')
  selectors=set(); api_methods=0; mapped_bcis=0; api_outputs={}
  for cell in apis:
   sel=(cell['profile'],cell['input_form'],cell['evidence']); selectors.add(sel)
   require(cell['exit_code']==0 and cell['method_inventory_matches'] is True,key+': API command or inventory failed')
   cc=byid[cell['command']]; require(cc['label']==f"jarde-{sel[0]}-{sel[1]}-{sel[2]}" and cc['exit_code']==0,key+': API command linkage')
   argv=cc['argv']; target_class=f"{targetname}.class"; prof=profiles[sel[0]]
   expected_input=(Path(prof['class_root'])/target_class if sel[1]=='child' else Path(prof['bundle']['path'])).resolve(strict=True)
   require(cell['input']['path']==str(expected_input) and pin(expected_input)==cell['input'],key+': API input is not the exact original class or profile bundle')
   require(len(argv)>=8 and Path(argv[0]).resolve()==Path(d['cli']['path']).resolve() and argv[1]=='class-source' and argv[2]=='--input' and Path(argv[3]).resolve()==expected_input,key+': API argv is not bound to pinned CLI/input')
   require(argv[argv.index('--class')+1]==targetname and argv[argv.index('--policy')+1]==('single-class' if sel[1]=='child' else 'plain-jar'),key+': API target/policy argv mismatch')
   require(argv[argv.index('--release')+1]=='8' and argv[argv.index('--format')+1]=='json',key+': API release/format argv mismatch')
   evidence_all=('--evidence' in argv and argv[argv.index('--evidence')+1]=='all')
   require(evidence_all==(sel[2]=='all'),key+': API evidence selector argv mismatch')
   if sel[1]=='child': target_bytes=expected_input.read_bytes()
   else:
    with zipfile.ZipFile(expected_input) as zf: target_bytes=zf.read(target_class)
   target_digest=hashlib.sha256(target_bytes).hexdigest(); target_length=len(target_bytes)
   physical_rows={ (m['name'],m['descriptor']):m for m in prof['target_facts']['methods'] }
   methods=cell['methods']; require({(m['name'],m['descriptor']) for m in methods}=={('<init>','()V'),('test',cfg['method'])},key+': API method rows')
   report=Path(cell['report']['path']); require(pin(report)==cell['report'],key+': report pin')
   report_bytes=report.read_bytes(); require(report_bytes==Path(cc['streams']['stdout']['path']).read_bytes(),key+': report/raw stdout mismatch')
   doc=json.loads(report_bytes.decode('utf-8','strict')); require(doc['text'].encode('utf-8')==Path(cell['whole_source']['path']).read_bytes(),key+': report/source text mismatch')
   require(len(doc['methods'])==len(methods),key+': raw report/summary method count mismatch')
   require(isinstance(doc.get('class'),dict),key+': raw report class identity missing')
   raw_by_key={ (rm['item']['name']['escaped'],rm['item']['descriptor']['escaped']):rm for rm in doc['methods'] }
   require(set(raw_by_key)=={(m['name'],m['descriptor']) for m in methods},key+': raw report method identities differ from summary')
   for m in methods:
    api_methods+=1; method_key=(m['name'],m['descriptor']); raw=raw_by_key[method_key]; item=raw['item']; identity=item['identity']; outcome=raw['outcome']; body=outcome['report']
    require(m['identity']==identity and m['name']==item['name']['escaped'] and m['descriptor']==item['descriptor']['escaped'],key+': raw report identity/name/descriptor mismatch')
    require(m['owner']==identity['owner'] and m['location']==identity['owner']['location'] and m['variant']==identity['owner']['variant'],key+': raw report owner/location/variant mismatch')
    require(identity['owner']==doc['class'] and identity['owner']['class_bytes']['length']==target_length,key+': method owner does not match report class identity/original target length')
    require(identity['name']==list(m['name'].encode('utf-8')) and identity['descriptor']==list(m['descriptor'].encode('utf-8')),key+': API identity bytes disagree with physical method name/descriptor')
    require(m['outcome_kind']==outcome['kind']=='recovered' and m['quality']==body['quality']=='structured',key+': API method outcome/quality mismatch')
    require(m['raw_text']==body['text'] and m['source_map']==body['source_map'] and m['fallbacks']==body['fallbacks'] and m['regions']==body['regions'],key+': method summary differs from raw report body')
    require(not m['fallbacks'],key+': API method has fallback')
    require(m['map_audit']['map_present'] and m['map_audit']['covers_all_physical_bcis'] and not m['map_audit']['issues'],key+': map audit not complete')
    textbytes=m['raw_text'].encode('utf-8'); require(len(textbytes)==m['map_audit']['text_bytes'],key+': raw UTF-8 byte length')
    physical=set(m['map_audit']['physical_bcis']); mapped=set(m['map_audit']['mapped_bcis']); require(physical==mapped,key+': physical BCI mapping incomplete')
    phys=physical_rows.get(method_key); require(phys is not None and set(phys['code']['bcis'])==physical,key+': map audit BCIs do not match parsed physical Code')
    sm=m.get('source_map'); require(isinstance(sm,dict) and isinstance(sm.get('segments'),list) and sm==body['source_map'],key+': source map missing or raw/summary mismatch')
    for seg in sm['segments']:
     start,end=seg['start'],seg['end']; require(0<=start<end<=len(textbytes),key+': source map UTF-8 byte span invalid')
     try: textbytes[:start].decode('utf-8','strict'); textbytes[start:end].decode('utf-8','strict'); textbytes[:end].decode('utf-8','strict')
     except UnicodeDecodeError as exc: raise AssertionError(key+': source map boundary splits UTF-8 '+str(exc))
     for origin in [seg['origin'].get('primary'),*seg['origin'].get('derived',[])]:
      if origin:
       require(origin['bci'] in physical,key+': map references foreign BCI')
       origin_method=origin['method']; require(origin_method==identity,key+': map origin method identity differs from report/physical method')
       require(origin_method['owner']==identity['owner'] and origin_method['name']==identity['name'] and origin_method['descriptor']==identity['descriptor'],key+': map origin owner/name/descriptor mismatch')
    mapped_bcis+=len(physical)
   source=cell.get('whole_source'); require(source is not None and pin(source['path'])==source,key+': whole source pin absent')
   api_outputs[sel]= {'text':doc['text'],'raw_methods':{(m['name'],m['descriptor']):(m['raw_text'],m['source_map']) for m in methods}}
  require(selectors=={(p,f,e) for p in profiles for f in ('child','bundle-child') for e in ('default','all')},key+': Jarde API selectors incomplete')
  for profile in profiles:
   for form in ('child','bundle-child'):
    default=api_outputs[(profile,form,'default')]; all_evidence=api_outputs[(profile,form,'all')]
    require(default['text']==all_evidence['text'],key+f': default/all full class text differs for {profile}/{form}')
    require(default['raw_methods']==all_evidence['raw_methods'],key+f': default/all raw method text/map differs for {profile}/{form}')
  jrows=d['jadx_outputs']; require(len(jrows)==2,key+': JADX outputs count')
  jadx_count=0
  for jr in jrows:
   require(jr['exit_code']==0 and jr['display_profile']=='default',key+': JADX command failed or display changed')
   cmd=byid[jr['command']]; require(cmd['exit_code']==0 and cmd['label']==f"jadx-full-bundle-{jr['compiler_profile']}-default",key+': JADX command linkage')
   pins=jr['sources']; require(len(pins)>0,key+': JADX output source empty')
   for p in pins: require(pin(p['path'])==p,key+': JADX source pin')
   require(any(Path(p['path']).name==cfg['outer']+'.java' for p in pins),key+': JADX outer source missing')
   ja=cmd['argv']; require('-d' in ja,key+': JADX invocation has no output directory')
   jroot=Path(ja[ja.index('-d')+1]).resolve(strict=True)
   actual_java={str(p.resolve()) for p in jroot.rglob('*.java')}
   require(actual_java=={p['path'] for p in pins},key+': saved JADX files are not the complete emitted source tree')
   jadx_count+=len(pins)
  result.append({'family':key,'receipt_sha256':sha(receipt),'schema':d['schema'],'commands':len(cmds),'raw_streams':sum(1 for c in cmds for x in ('stdout','stderr') if c['streams'][x]),'original_runtime_rows':sum(x['row_count'] for x in rows),'runtime_cells':len(rows),'wrong_root_exit':wrong['exit_code'],'physical_methods_per_profile':inventories,'api_cells':len(apis),'api_method_rows':api_methods,'api_physical_bci_total':mapped_bcis,'jadx_outputs':len(jrows),'jadx_source_files':jadx_count,'manual_expected_matches':True})
 return result
if __name__=='__main__': print(json.dumps(main(),indent=2))
