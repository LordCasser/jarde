# CF07 baseline auditor v2

This private v2 preserves v1 and adds the missing API consistency checks. It independently reopens the two completed Condition2/Detection2 baseline receipts and requires: default/all complete class text and each method raw text/map to match; each API summary row to match the raw JSON method identity, owner/location/variant, outcome, quality, fallbacks, regions, text and source map; every map origin to name the same physical owner/name/descriptor and valid BCI; all UTF-8 span endpoints to decode on byte boundaries; and the CLI argv to bind the exact pinned child class or complete profile bundle, class identity, policy, release, format, and evidence selector.

The original receipt owner digest is checked against the report class identity and pinned physical input length. The script does not invent a mapping from the API's BLAKE3 class digest to the receipt's SHA-256 pin. Raw class bytes are independently pinned and parsed by the existing dual class-file parsers.

Run with `python3 -B audit_baselines.py`. This is a read-only Python audit only. The receipts retain `captured-pending-independent-review`; no generated collector/compiler/JVM/CLI/JADX was run. `audit.json`, `v1-to-v2.diff`, and `pins.json` contain result and provenance.
