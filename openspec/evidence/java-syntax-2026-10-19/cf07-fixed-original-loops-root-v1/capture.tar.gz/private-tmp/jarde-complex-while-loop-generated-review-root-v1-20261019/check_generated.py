def check_generated(path: Path, schema: str, control: bool, baseline: Path, cli_sha: str) -> dict:
    path = path.resolve(strict=True)
    data = json.loads(path.read_text(encoding='utf-8'))
    if data.get('schema') != schema or data.get('status') != 'captured-pending-independent-review':
        raise RuntimeError(f'{path}: generated matrix is not a complete capture')
    baseline = baseline.resolve(strict=True)
    if check_pin(data.get('baseline_receipt'), 'generated baseline receipt') != baseline or data.get('baseline_sha256_argument') != sha(baseline):
        raise RuntimeError(f'{path}: generated matrix is not bound to the final baseline receipt')
    cli_row = data.get('candidate_cli') if control else data.get('cli')
    if cli_row is None:
        # Primary generated collectors pin the candidate through their baseline receipt.
        cli_row = json.loads(baseline.read_text(encoding='utf-8')).get('cli')
    cli_path = check_pin(cli_row, 'generated candidate CLI')
    if cli_row.get('sha256') != cli_sha:
        raise RuntimeError(f'{path}: candidate CLI differs from caller-supplied SHA')
    for flag in ('source_unchanged', 'source_unchanged_finally', 'target_absent', 'target_absent_finally',
                 'external_inputs_unchanged', 'external_inputs_unchanged_finally',
                 'generated_outputs_unchanged', 'generated_outputs_unchanged_finally',
                 'local_copies_unchanged', 'local_copies_unchanged_finally'):
        # The primary schema has no external/local *_finally booleans; snapshots below supply the same gate.
        if flag in data and data.get(flag) is not True:
            raise RuntimeError(f'{path}: failed final guard {flag}')
    if not (data.get('source_pins_before') == data.get('source_pins_after') == data.get('source_pins_after_finally')):
        raise RuntimeError(f'{path}: live source closure changed during capture')
    for name in ('external_pins_before', 'external_pins_after', 'external_pins_after_finally'):
        if name not in data: raise RuntimeError(f'{path}: missing {name}')
        recursive_pin_check(data[name], name)
    if not (data['external_pins_before'] == data['external_pins_after'] == data['external_pins_after_finally']):
        raise RuntimeError(f'{path}: external tool/input pins changed')
    for name in ('source_pins_before', 'source_pins_after', 'source_pins_after_finally'):
        recursive_pin_check(data[name], name)
    before = data.get('generated_output_pins_before')
    after = data.get('generated_output_pins_after')
    final = data.get('generated_output_pins_after_finally')
    if before is not None:
        recursive_pin_check(before, 'generated outputs before')
        recursive_pin_check(after, 'generated outputs after')
        recursive_pin_check(final, 'generated outputs finally')
        if not (before == after == final): raise RuntimeError(f'{path}: generated outputs changed')
    for name in ('local_copies_before', 'local_copies_after', 'local_copies_after_finally'):
        if name in data: recursive_pin_check(data[name], name)
    if 'local_copies_after' in data and data.get('local_copies_after') != data.get('local_copies_after_finally'):
        raise RuntimeError(f'{path}: driver/runtime copies changed after capture')
    if data.get('local_copies_before') and not (data['local_copies_before'] == data.get('local_copies_after') == data.get('local_copies_after_finally')):
        raise RuntimeError(f'{path}: driver/runtime copies changed')
    if data.get('target_absent_finally') is not True:
        raise RuntimeError(f'{path}: workspace target is not absent after capture')

    # Every command and raw stream is reopened. The guard must retain the 5 GiB / 1 GiB limits.
    commands = data.get('commands')
    if not isinstance(commands, list) or not commands:
        raise RuntimeError(f'{path}: command ledger missing')
    cmdmap = {r.get('index'): r for r in commands}
    if len(cmdmap) != len(commands) or None in cmdmap:
        raise RuntimeError(f'{path}: duplicate/missing command index')
    tool_docs = data.get('jdk_manifest', {}).get('tools')
    if not isinstance(tool_docs, dict) or set(tool_docs) != {'javac8', 'javac23'}:
        raise RuntimeError(f'{path}: two pinned JDK legs missing')
    for leg, tools in tool_docs.items():
        for tool in ('javac', 'java'):
            check_pin(tools.get(tool), f'{leg} {tool}')
    manifest = data.get('jdk_manifest')
    if not isinstance(manifest, dict) or not isinstance(manifest.get('path'), str) or sha(Path(manifest['path']).resolve(strict=True)) != manifest.get('sha256'):
        raise RuntimeError(f'{path}: JDK manifest bytes differ from recorded SHA')
    if sorted(cmdmap) != list(range(1, len(commands)+1)):
        raise RuntimeError(f'{path}: command ledger indexes are not contiguous')
    for row in commands:
        if row.get('guard_stop') is not None or not isinstance(row.get('argv'), list) or not row['argv']:
            raise RuntimeError(f'{path}: command guard/argv invalid: {row.get("label")}')
        if not isinstance(row.get('peak_target_bytes'), int) or row['peak_target_bytes'] > 1024**3:
            raise RuntimeError(f'{path}: target exceeded 1 GiB or peak usage was not recorded')
        if not isinstance(row.get('free_bytes_after'), int) or row['free_bytes_after'] < 5 * 1024**3:
            raise RuntimeError(f'{path}: command did not preserve the 5 GiB free-space guard')
        for stream_name in ('stdout', 'stderr'):
            pin = row.get('streams', {}).get(stream_name)
            if pin is None: raise RuntimeError(f'{path}: missing raw {stream_name} for {row.get("label")}')
            check_pin(pin, f'{row.get("label")} {stream_name}')
        leg = row.get('tool_leg')
        if leg in tool_docs:
            exe = Path(row['argv'][0]).resolve()
            javac = Path(tool_docs[leg]['javac']['path']).resolve()
            java = Path(tool_docs[leg]['java']['path']).resolve()
            if 'compile-' in str(row.get('label')) and exe != javac:
                raise RuntimeError(f'{path}: compile command did not use its pinned javac leg')
            if str(row.get('label','')).startswith(('runtime-', 'wrong-root-')):
                if len(row['argv']) < 5 or Path(row['argv'][4]).resolve() != java:
                    raise RuntimeError(f'{path}: JVM command did not use its pinned Java leg')

    driver_compile = data.get('driver_compile')
    driver_cmd = cmdmap.get((driver_compile or {}).get('command'))
    if driver_cmd is None or driver_cmd.get('exit_code') != 0 or driver_compile.get('exit_code') != 0 or driver_cmd.get('label') not in ('compile-driver', 'compile-reflection-driver'):
        raise RuntimeError(f'{path}: independent driver compile is missing/failed')
    for stream_name in ('stdout', 'stderr'):
        if check_pin(driver_compile.get(stream_name), f'driver {stream_name}').read_bytes() != check_pin(driver_cmd['streams'][stream_name], f'driver command {stream_name}').read_bytes():
            raise RuntimeError(f'{path}: driver raw streams differ from command')
    driver_source, driver_copy = check_pin(data.get('driver_source'), 'driver source'), check_pin(data.get('driver_copy'), 'driver copy')
    if driver_source.read_bytes() != driver_copy.read_bytes(): raise RuntimeError(f'{path}: copied driver source differs from pinned source')
    driver_argv = driver_cmd.get('argv', [])
    if '-d' not in driver_argv or sorted(str(Path(x).resolve()) for x in driver_argv if str(x).endswith('.java')) != [str(driver_copy)]:
        raise RuntimeError(f'{path}: driver compiler argv does not compile the exact copied driver source')
    driver_root = Path(driver_argv[driver_argv.index('-d') + 1]).resolve()
    driver_classes = data.get('driver_classes')
    if not driver_classes: raise RuntimeError(f'{path}: driver class artifacts missing')
    driver_rows = list(driver_classes.values()) if isinstance(driver_classes, dict) else driver_classes
    driver_paths = [check_pin(pin, 'driver class artifact') for pin in driver_rows]
    expected_driver_names = {'LoopConditionInvokeControlDriver$Case.class', 'LoopConditionInvokeControlDriver.class'} if control else {'TestComplexWhileLoopDriver$Case.class', 'TestComplexWhileLoopDriver.class'}
    if {q.name for q in driver_paths} != expected_driver_names or any(q.parent != driver_root for q in driver_paths):
        raise RuntimeError(f'{path}: independent driver class inventory differs from expected pair')

    # Establish the complete source selector grid from the final API baseline.
    baseline_doc = json.loads(baseline.read_text(encoding='utf-8'))
    source_cells = data.get('source_cells')
    if not isinstance(source_cells, list) or len(source_cells) != 10:
        raise RuntimeError(f'{path}: expected complete 8-Jarde + 2-JADX source matrix')
    jarde = [c for c in source_cells if c.get('kind') == 'jarde']
    jadx = [c for c in source_cells if c.get('kind') == 'jadx']
    if len(jarde) != 8 or len(jadx) != 2 or sum(c.get('source_available') is True for c in source_cells) != 10:
        raise RuntimeError(f'{path}: source matrix has missing or duplicate producer cells')
    if control:
        old_api = baseline_doc.get('jarde_api_cells', [])
        expected_jarde = {(c.get('cell_key'), c.get('evidence')) for c in old_api}
        got_jarde = {(c.get('key'), c.get('evidence')) for c in jarde}
        expected_jadx = {('jadx-' + c.get('profile'), 'full-tree') for c in baseline_doc.get('jadx_outputs', [])}
        got_jadx = {(c.get('key'), c.get('evidence')) for c in jadx}
    else:
        old_api = baseline_doc.get('jarde_cells', [])
        expected_jarde = {(c.get('profile'), c.get('input_form'), c.get('evidence')) for c in old_api}
        got_jarde = {tuple(c.get('cell_key', [])) for c in jarde}
        expected_jadx = {(c.get('compiler_profile'), 'bundle') for c in baseline_doc.get('jadx_outputs', [])}
        got_jadx = {(c.get('profile'), c.get('form')) for c in jadx}
    if len(expected_jarde) != 8 or got_jarde != expected_jarde or len(got_jarde) != 8:
        raise RuntimeError(f'{path}: Jarde API source selectors incomplete/duplicated')
    if len(expected_jadx) != 2 or got_jadx != expected_jadx or len(got_jadx) != 2:
        raise RuntimeError(f'{path}: JADX profile source selectors incomplete/duplicated')

    # Reopen every source and copy, enforce exact byte identity, and bind Jarde copies to API output.
    old_by_key = {}
    if control:
        for c in old_api: old_by_key[(c['cell_key'], c['evidence'])] = c
    else:
        for c in old_api: old_by_key[(c['profile'], c['input_form'], c['evidence'])] = c
    copy_count = 0
    for cell in source_cells:
        copies = cell.get('source_copies')
        if not isinstance(copies, list) or not copies:
            raise RuntimeError(f'{path}: source copies missing for {cell.get("key", cell.get("cell_key"))}')
        for pair in copies:
            src = check_pin(pair.get('source'), 'generated source input')
            dst = check_pin(pair.get('copy'), 'generated source copy')
            if src.read_bytes() != dst.read_bytes(): raise RuntimeError(f'{path}: source copy differs byte-for-byte')
            copy_count += 1
        if cell.get('kind') == 'jarde':
            key = (cell.get('key'), cell.get('evidence')) if control else tuple(cell.get('cell_key', []))
            old = old_by_key[key]
            old_source_field = 'whole_class_text' if control else 'whole_source'
            source = check_pin(old.get(old_source_field), 'baseline whole-class source')
            if len(copies) != 1 or check_pin(copies[0].get('source'), 'Jarde collector source') != source:
                raise RuntimeError(f'{path}: Jarde whole source is not the exact API source artifact')
            if check_pin(copies[0]['copy'], 'Jarde compile copy').read_bytes() != source.read_bytes():
                raise RuntimeError(f'{path}: Jarde copy differs from API whole source')
        else:
            for pair in copies: check_pin(pair['source'], 'JADX full source tree member')

    compiles = data.get('compilations', [])
    if not isinstance(compiles, list) or len(compiles) != 20:
        raise RuntimeError(f'{path}: expected 20 complete-source compile attempts')
    expected_compile_keys = set()
    if control:
        for c in jarde: expected_compile_keys.add((c.get('key') + '-' + c.get('evidence'), 'javac8'))
        for c in jarde: expected_compile_keys.add((c.get('key') + '-' + c.get('evidence'), 'javac23'))
        for c in jadx:
            for leg in ('javac8','javac23'): expected_compile_keys.add((c.get('key') + '-' + c.get('evidence'), leg))
        getkey = lambda r: (r.get('cell_key'), r.get('compiler'))
    else:
        for c in source_cells:
            for leg in ('javac8','javac23'): expected_compile_keys.add((tuple(c.get('cell_key', [])), leg))
        getkey = lambda r: (norm_cell(r.get('cell_key')), r.get('leg'))
    compile_map = {getkey(r): r for r in compiles}
    if len(compile_map) != len(compiles) or set(compile_map) != expected_compile_keys:
        raise RuntimeError(f'{path}: compiler/profile/source selector matrix incomplete or duplicated')

    # Match each compilation's complete source copy list and reopen every produced class artifact.
    source_by_compile_key = {}
    for cell in source_cells:
        ident = cell.get('key') + '-' + cell.get('evidence') if control else tuple(cell.get('cell_key', []))
        source_by_compile_key[ident] = cell
    original_profiles = {x.get('profile'): x for x in baseline_doc.get('source_profiles', [])} if not control else {x.get('cell_key'): x for x in baseline_doc.get('profile_cells', [])}
    expected_case_count = 6 if control else 7
    vm_rows = data.get('runtime_rows', [])
    wrong_rows = data.get('wrong_root_rows', [])
    match_field = 'matches_original_oracle' if control else 'matches_original_profile_runtime'
    runtime_map = {}
    for row in vm_rows:
        cellid = row.get('cell_key') if control else norm_cell(row.get('cell_key'))
        k = (cellid, row.get('compiler'), row.get('runtime'))
        if k in runtime_map: raise RuntimeError(f'{path}: duplicate generated VM row {k}')
        runtime_map[k] = row
    wrong_map = {}
    for row in wrong_rows:
        cellid = row.get('cell_key') if control else norm_cell(row.get('cell_key'))
        k = (cellid, row.get('compiler'))
        if k in wrong_map: raise RuntimeError(f'{path}: duplicate wrong-root row {k}')
        wrong_map[k] = row
    expected_vm_keys, expected_wrong_keys = set(), set()
    for key, rec in compile_map.items():
        cellid, leg = key
        cell = source_by_compile_key[cellid]
        cmd = cmdmap.get(rec.get('command'))
        labelid = '-'.join(map(str, cell.get('cell_key', []))) if not control else cellid
        if cmd is None or cmd.get('label') != f'compile-{labelid}-{leg}' or cmd.get('exit_code') != rec.get('exit_code'):
            raise RuntimeError(f'{path}: compile row is not linked to matching raw command {key}')
        for stream_name in ('stdout', 'stderr'):
            if check_pin(rec.get(stream_name), f'{key} saved {stream_name}').read_bytes() != check_pin(cmd['streams'][stream_name], f'{key} command {stream_name}').read_bytes():
                raise RuntimeError(f'{path}: compile row raw stream differs from command {key}')
        argv = cmd['argv']
        if '-d' not in argv or Path(argv[argv.index('-d') + 1]).resolve() != Path(rec.get('class_root', '')).resolve():
            raise RuntimeError(f'{path}: compile command destination differs from saved class root {key}')
        copied_paths = sorted(str(Path(pair['copy']['path']).resolve()) for pair in cell['source_copies'])
        argv_sources = sorted(str(Path(x).resolve()) for x in argv if str(x).endswith('.java'))
        if argv_sources != copied_paths or '-proc:none' not in argv or '-sourcepath' not in argv:
            raise RuntimeError(f'{path}: compile command did not consume the exact copied complete source tree {key}')
        profile = cell.get('profile')
        debug_flag = '-g' if profile == 'debug' else '-g:none'
        if debug_flag not in argv or '-encoding' not in argv or argv[argv.index('-encoding') + 1] != 'UTF-8':
            raise RuntimeError(f'{path}: compile debug/encoding profile differs from source cell {key}')
        if leg == 'javac8' and not any(argv[i:i+2] == ['-source','8'] for i in range(len(argv)-1)) or leg == 'javac8' and not any(argv[i:i+2] == ['-target','8'] for i in range(len(argv)-1)):
            raise RuntimeError(f'{path}: javac8 compile lacks source/target 8 options {key}')
        if leg == 'javac23' and not any(argv[i:i+2] == ['--release','8'] for i in range(len(argv)-1)):
            raise RuntimeError(f'{path}: javac23 compile lacks release 8 option {key}')
        if rec.get('exit_code') == 0 and rec.get('failure_classification') is not None:
            raise RuntimeError(f'{path}: successful compile has a failure classification {key}')
        if rec.get('source_copies') is not None:
            if rec['source_copies'] != cell.get('source_copies'): raise RuntimeError(f'{path}: compile source list differs from copied full source {key}')
        tree = check_tree(rec.get('class_tree'), f'{path} {key} output', allow_empty=rec.get('exit_code') != 0)
        if rec.get('exit_code') == 0:
            if rec.get('runtime_eligible') is not True or 'class_facts_error' not in rec or rec.get('class_facts_error') is not None:
                raise RuntimeError(f'{path}: successful compile lacks validated class facts {key}')
            for f in tree.values(): check_pin(f, f'{key} generated class')
            facts = rec.get('all_class_facts') if control else rec.get('class_facts')
            if control:
                if not isinstance(facts, dict) or set(facts) != set(tree): raise RuntimeError(f'{path}: control full class facts do not cover class tree {key}')
                if set(tree) != {'controls/LoopConditionInvokeControl.class'}:
                    raise RuntimeError(f'{path}: controls generated class closure is incomplete {key}')
                original_key = cell.get('key') if cell.get('kind') == 'jarde' else 'javac23-' + cell.get('profile')
                original = original_profiles[original_key]['class_facts']
                for rel, fact in facts.items(): check_pin(fact, f'{key}/{rel} parser source class')
                check_fact_inventory(facts[next(iter(tree))], original, f'{key}/target')
            else:
                if not isinstance(facts, dict) or set(facts) != set(tree): raise RuntimeError(f'{path}: primary full class facts do not cover class tree {key}')
                original_profile = original_profiles[cell.get('profile')]
                for rel, fact in facts.items(): check_pin(fact, f'{key}/{rel} parser source class')
                if cell.get('kind') == 'jarde':
                    # Jarde API whole-source cells each present only the target nested class as a top-level source.
                    # The original input bundle can contain the outer class, but that outer source was not emitted.
                    expected_class_tree = {INTERNAL + '.class'}
                    original_by_name = {original_profile['target_facts']['class_name']: original_profile['target_facts']}
                else:
                    # Full JADX source trees carry both the outer and nested target classes.
                    expected_class_tree = set(original_profile.get('class_tree', {}))
                    original_by_name = {original_profile['target_facts']['class_name']: original_profile['target_facts'], original_profile['outer_facts']['class_name']: original_profile['outer_facts']}
                if set(tree) != expected_class_tree:
                    raise RuntimeError(f'{path}: primary generated class closure differs from its complete source producer inventory {key}')
                for rel, fact in facts.items():
                    expected_fact = original_by_name.get(fact.get('class_name'))
                    if expected_fact is None: raise RuntimeError(f'{path}: generated class is outside source producer closure {key}/{rel}')
                    check_fact_inventory(fact, expected_fact, f'{key}/{rel}')
                if 'target_facts_error' not in rec or rec.get('target_facts_error') is not None: raise RuntimeError(f'{path}: primary target facts invalid {key}')
                target_summary = rec.get('target_facts')
                if not isinstance(target_summary, dict) or target_summary.get('class_name') != original_profile['target_facts']['class_name']:
                    raise RuntimeError(f'{path}: primary target class summary malformed {key}')
                check_pin(target_summary, f'{key} target parser source class')
                check_fact_inventory(target_summary, original_profile['target_facts'], f'{key}/target summary')
            expected_vm_keys.update((cellid, leg, vm) for vm in ('javac8','javac23'))
            expected_wrong_keys.add((cellid, leg))
        else:
            if rec.get('runtime_eligible') is True: raise RuntimeError(f'{path}: failed compile marked runtime eligible {key}')
            # The only anticipated source failure is the frozen primary JADX/JDK8 major-55 boundary.
            if not control and cell.get('kind') == 'jadx' and leg == 'javac8':
                stderr = check_pin(rec.get('stderr'), f'{key} major boundary stderr').read_bytes()
                if rec.get('failure_classification') != 'harness-major-55-boundary' or not (b'55.0' in stderr or b'version 55' in stderr):
                    raise RuntimeError(f'{path}: primary JADX/JDK8 failure is not the exact observed major-55 boundary')
            else:
                raise RuntimeError(f'{path}: unexpected generated source compile failure {key}')
    if set(runtime_map) != expected_vm_keys or set(wrong_map) != expected_wrong_keys:
        raise RuntimeError(f'{path}: success-only runtime/wrong-root grid has missing or extra cells')
    expected_jarde_compiles = 16
    jarde_compiles = [r for r in compiles if (r.get('cell_key') if control else tuple(r.get('cell_key', []))) in ({c.get('key')+'-'+c.get('evidence') for c in jarde} if control else {tuple(c.get('cell_key', [])) for c in jarde})]
    if len(jarde_compiles) != expected_jarde_compiles or any(r.get('exit_code') != 0 or r.get('runtime_eligible') is not True for r in jarde_compiles):
        raise RuntimeError(f'{path}: all 16 Jarde compiles must succeed with complete physical facts')
    if len([r for r in vm_rows if (r.get('cell_key') if control else norm_cell(r.get('cell_key'))) in ({c.get('key')+'-'+c.get('evidence') for c in jarde} if control else {tuple(c.get('cell_key', [])) for c in jarde})]) != 32:
        raise RuntimeError(f'{path}: Jarde compiler×VM grid must contain 32 rows')
    expected_cases = 192 if control else 224
    actual_cases = sum(len(r.get('rows', [])) for r in vm_rows if (r.get('cell_key') if control else norm_cell(r.get('cell_key'))) in ({c.get('key')+'-'+c.get('evidence') for c in jarde} if control else {tuple(c.get('cell_key', [])) for c in jarde}))
    if actual_cases != expected_cases: raise RuntimeError(f'{path}: Jarde runtime observations {actual_cases} != {expected_cases}')
    for key, row in runtime_map.items():
        cellid, compiler, vm = key
        cmd = cmdmap.get(row.get('command'))
        if cmd is None or cmd.get('exit_code') != 0 or row.get('exit_code') != 0 or row.get(match_field) is not True:
            raise RuntimeError(f'{path}: generated runtime mismatch {key}')
        if not row.get('rows') or len(row['rows']) != expected_case_count: raise RuntimeError(f'{path}: runtime case inventory incomplete {key}')
        driver_compile = cmdmap.get((data.get('driver_compile') or {}).get('command'))
        if driver_compile is None or '-d' not in driver_compile.get('argv', []):
            raise RuntimeError(f'{path}: driver class output path missing')
        driver_root = str(Path(driver_compile['argv'][driver_compile['argv'].index('-d') + 1]).resolve())
        if row.get('application_classpath') != [driver_root] or '-cp' not in cmd.get('argv', []) or cmd['argv'][cmd['argv'].index('-cp') + 1] != driver_root:
            raise RuntimeError(f'{path}: runtime driver-only classpath invalid {key}')
        argv = cmd['argv']
        driver_name = argv[-3] if len(argv) >= 3 else ''
        wrapper_path = Path(argv[2]).resolve() if len(argv) >= 3 else None
        if (len(argv) < 11 or argv[1:2] != ['-B'] or argv[3] != '30' or argv[5] != '-Xverify:all' or
                Path(argv[-2]).resolve() != Path(row.get('target_root','')).resolve() or Path(argv[-1]).resolve() != Path(row.get('target_root','')).resolve() or
                driver_name not in ('TestComplexWhileLoopDriver','LoopConditionInvokeControlDriver')):
            raise RuntimeError(f'{path}: runtime timeout/CodeSource argv differs from guarded contract {key}')
        check_runtime_wrapper_identity(data, baseline_doc, control, wrapper_path, f'{path} {key}')
        expected_oracle_key = f'{source_by_compile_key[cellid].get("key")}/{vm}' if control else f'{source_by_compile_key[cellid].get("profile")}/{vm}'
        if control:
            if row.get('matches_original_oracle') is not True:
                raise RuntimeError(f'{path}: generated runtime mismatch flag false {key}')
            oracle_source_key = source_by_compile_key[cellid].get('key') if source_by_compile_key[cellid].get('kind') == 'jarde' else 'javac23-' + source_by_compile_key[cellid].get('profile')
            control_oracle_key = f'{oracle_source_key}/{vm}'
            oracle = data.get('original_oracles', {}).get(control_oracle_key)
            projection_fields = set(oracle[0]) if isinstance(oracle, list) and oracle else set()
            actual_projection = [{k:v for k,v in case.items() if k != 'raw'} for case in row['rows']]
            if not projection_fields or actual_projection != oracle:
                raise RuntimeError(f'{path}: generated control runtime differs from full saved oracle {key}')
        elif data.get('original_oracles', {}).get(expected_oracle_key) != row.get('semantic_projection'):
            raise RuntimeError(f'{path}: generated runtime differs from saved original oracle {key}')
        raw_lines = check_pin(row.get('stdout'), f'{key} runtime stdout').read_text(encoding='utf-8').splitlines()
        if raw_lines != [case.get('raw') for case in row['rows']]: raise RuntimeError(f'{path}: runtime parsed cases differ from raw stdout {key}')
        for stream_name in ('stdout', 'stderr'):
            if check_pin(row.get(stream_name), f'{key} {stream_name}').read_bytes() != check_pin(cmd['streams'][stream_name], f'{key} command {stream_name}').read_bytes():
                raise RuntimeError(f'{path}: runtime raw stream differs from linked command {key}')
    for key, row in wrong_map.items():
        cmd = cmdmap.get(row.get('command'))
        if cmd is None or cmd.get('exit_code') != 1 or row.get('exit_code') != 1 or row.get('rejected') is not True:
            raise RuntimeError(f'{path}: wrong-CodeSource cell invalid {key}')
        err = check_pin(row.get('stderr'), f'{key} wrong-root stderr').read_bytes()
        if b'wrong CodeSource:' not in err: raise RuntimeError(f'{path}: wrong-root rejection reason absent {key}')
        for stream_name in ('stdout', 'stderr'):
            if check_pin(row.get(stream_name), f'{key} wrong-root {stream_name}').read_bytes() != check_pin(cmd['streams'][stream_name], f'{key} wrong-root command {stream_name}').read_bytes():
                raise RuntimeError(f'{path}: wrong-root raw stream differs from linked command {key}')
        argv = cmd['argv']
        expected_root = Path(row.get('actual_target_root','')).resolve()
        wrong_root = Path(row.get('expected_wrong_root','')).resolve()
        driver_compile = cmdmap.get((data.get('driver_compile') or {}).get('command'))
        driver_root = str(Path(driver_compile['argv'][driver_compile['argv'].index('-d') + 1]).resolve()) if driver_compile and '-d' in driver_compile.get('argv', []) else None
        driver_name = argv[-3] if len(argv) >= 3 else ''
        wrapper_path = Path(argv[2]).resolve() if len(argv) >= 3 else None
        if (len(argv) < 11 or argv[1:2] != ['-B'] or argv[3] != '30' or argv[5] != '-Xverify:all' or
                Path(argv[-2]).resolve() != expected_root or Path(argv[-1]).resolve() != wrong_root or expected_root == wrong_root or
                '-cp' not in argv or argv[argv.index('-cp')+1] != driver_root or
                driver_name not in ('TestComplexWhileLoopDriver','LoopConditionInvokeControlDriver')):
            raise RuntimeError(f'{path}: wrong-root command does not use distinct roots and guarded driver-only argv {key}')
        check_runtime_wrapper_identity(data, baseline_doc, control, wrapper_path, f'{path} wrong-root {key}')
    if len(commands) != 1 + len(compiles) + len(vm_rows) + len(wrong_rows):
        raise RuntimeError(f'{path}: unlinked or missing command rows')
    if control:
        if len([r for r in compiles if source_by_compile_key[r['cell_key']]['kind']=='jadx']) != 4 or len(runtime_map)-32 != 8 or len(wrong_map)-16 != 4:
            raise RuntimeError(f'{path}: all four control JADX compile/runtime/wrong-root cells are required')
    else:
        jadx_rows = [r for r in compiles if source_by_compile_key[norm_cell(r['cell_key'])]['kind']=='jadx']
        if len(jadx_rows) != 4 or sum(r.get('exit_code') == 0 for r in jadx_rows) != 2:
            raise RuntimeError(f'{path}: primary JADX grid must retain two major-55 failures and two successes')
        if len(runtime_map)-32 != 4 or len(wrong_map)-16 != 2:
            raise RuntimeError(f'{path}: primary JADX successful-cell runtime/wrong-root grid incomplete')
    return {'source_cells': len(source_cells), 'jarde_compile_successes':len(jarde_compiles),
            'all_compile_attempts':len(compiles),'all_compile_successes':sum(r.get('exit_code')==0 for r in compiles),
            'jarde_vm_rows':32,'jarde_case_observations':actual_cases,'all_vm_rows':len(vm_rows),
            'wrong_root_rows':len(wrong_rows),'source_copy_count':copy_count,
            'known_primary_jadx_major55_failures': 2 if not control else 0}
