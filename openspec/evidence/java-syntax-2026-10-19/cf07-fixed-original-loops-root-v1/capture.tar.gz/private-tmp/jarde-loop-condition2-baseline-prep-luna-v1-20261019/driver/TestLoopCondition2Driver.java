import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.Base64;

/** Bounded isolated observations of TestLoopCondition2$TestCls.test(boolean). */
public final class TestLoopCondition2Driver {
    private static final String TARGET = "jadx.tests.integration.loops.TestLoopCondition2$TestCls";
    private static final Case[] CASES = { new Case("condition-false", false), new Case("condition-true", true) };
    private static final class Case {
        final String name; final boolean input;
        Case(String name, boolean input) { this.name = name; this.input = input; }
    }
    private static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static String codeSource(Class<?> target) throws Exception {
        CodeSource source = target.getProtectionDomain().getCodeSource();
        if (source == null || source.getLocation() == null) throw new IllegalStateException("target has no CodeSource");
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }
    private static void observe(Constructor<?> ctor, Method test, Case c, int index, PrintStream rows) throws Exception {
        PrintStream original = System.out; ByteArrayOutputStream targetBytes = new ByteArrayOutputStream();
        PrintStream targetOut = new PrintStream(targetBytes, true, "UTF-8"); Object value = null; Throwable cause = null; String stack = "";
        try {
            System.setOut(targetOut);
            try { value = test.invoke(ctor.newInstance(), c.input); }
            catch (InvocationTargetException e) { cause = e.getCause(); StringWriter w = new StringWriter(); cause.printStackTrace(new PrintWriter(w)); stack = w.toString(); }
        } finally { targetOut.flush(); System.setOut(original); targetOut.close(); }
        String exception = cause == null ? "none" : cause.getClass().getName();
        String message = cause == null || cause.getMessage() == null ? "" : cause.getMessage();
        String result = cause == null ? String.valueOf(value) : "";
        rows.println("CASE index=" + index + " name=" + c.name + " input_b64=" + b64(Boolean.toString(c.input))
                + " result_b64=" + b64(result) + " exception=" + exception + " exception_message_b64=" + b64(message)
                + " exception_stack_b64=" + b64(stack) + " target_stdout_b64=" + b64(new String(targetBytes.toByteArray(), StandardCharsets.UTF_8)));
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("usage: TestLoopCondition2Driver actualRoot expectedRoot");
        String actual = Paths.get(args[0]).toRealPath().toString(), expected = Paths.get(args[1]).toRealPath().toString();
        try (URLClassLoader loader = new URLClassLoader(new URL[] { Paths.get(actual).toUri().toURL() }, null)) {
            Class<?> target = Class.forName(TARGET, true, loader);
            if (target.getClassLoader() != loader) throw new IllegalStateException("target did not load from parentless loader");
            String origin = codeSource(target);
            if (!origin.equals(expected)) throw new IllegalStateException("wrong CodeSource: expected=" + expected + " actual=" + origin);
            Constructor<?> ctor = target.getDeclaredConstructor(); Method test = target.getDeclaredMethod("test", boolean.class);
            if (Modifier.isStatic(test.getModifiers())) throw new IllegalStateException("test(boolean) unexpectedly static");
            PrintStream rows = System.out;
            for (int i = 0; i < CASES.length; i++) observe(ctor, test, CASES[i], i, rows);
        }
    }
}
