import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.Base64;

/** Bounded isolated observations of TestComplexWhileLoop$TestCls.test(String[]). */
public final class TestComplexWhileLoopDriver {
    private static final String TARGET =
            "jadx.tests.integration.loops.TestComplexWhileLoop$TestCls";

    private static final class Case {
        final String name;
        final String[] input;

        Case(String name, String[] input) {
            this.name = name;
            this.input = input;
        }
    }

    private static final Case[] CASES = {
        new Case("null-array", null),
        new Case("empty-array", new String[0]),
        new Case("first-null", new String[] { null }),
        new Case("first-one-char", new String[] { "x" }),
        new Case("nonmatches-then-one-char", new String[] { "long", "two", "z" }),
        new Case("nonmatches-then-null", new String[] { "long", "two", null }),
        new Case("single-space-trims-empty", new String[] { " " })
    };

    private static String codeSource(Class<?> target) throws Exception {
        CodeSource source = target.getProtectionDomain().getCodeSource();
        if (source == null || source.getLocation() == null) {
            throw new IllegalStateException("target has no CodeSource");
        }
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }

    private static String b64(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private static String describeArray(String[] input) {
        if (input == null) {
            return "<null-array>";
        }
        StringBuilder out = new StringBuilder("[");
        for (int i = 0; i < input.length; i++) {
            if (i != 0) {
                out.append(',');
            }
            out.append(input[i] == null ? "<null>" : b64(input[i]));
        }
        return out.append(']').toString();
    }

    private static void observe(Method test, int index, Case c, PrintStream resultOut) throws Exception {
        PrintStream originalOut = System.out;
        ByteArrayOutputStream targetBytes = new ByteArrayOutputStream();
        PrintStream targetOut = new PrintStream(targetBytes, true, "UTF-8");
        Object value = null;
        Throwable cause = null;
        String stack = "";
        try {
            System.setOut(targetOut);
            try {
                value = test.invoke(null, (Object) c.input);
            } catch (InvocationTargetException e) {
                cause = e.getCause();
                StringWriter trace = new StringWriter();
                cause.printStackTrace(new PrintWriter(trace));
                stack = trace.toString();
            }
        } finally {
            targetOut.flush();
            System.setOut(originalOut);
            targetOut.close();
        }
        String exceptionName = cause == null ? "none" : cause.getClass().getName();
        String exceptionMessage = cause == null || cause.getMessage() == null ? "" : cause.getMessage();
        String result = cause == null ? (String) value : "";
        resultOut.println("CASE index=" + index + " name=" + c.name
                + " input_b64=" + b64(describeArray(c.input))
                + " result_b64=" + b64(result)
                + " exception=" + exceptionName
                + " exception_message_b64=" + b64(exceptionMessage)
                + " exception_stack_b64=" + b64(stack)
                + " target_stdout_b64=" + b64(new String(targetBytes.toByteArray(), StandardCharsets.UTF_8)));
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            throw new IllegalArgumentException(
                    "usage: TestComplexWhileLoopDriver actualRoot expectedRoot");
        }
        String actual = Paths.get(args[0]).toRealPath().toString();
        String expected = Paths.get(args[1]).toRealPath().toString();
        URL url = Paths.get(actual).toRealPath().toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(new URL[] { url }, null)) {
            Class<?> target = Class.forName(TARGET, true, loader);
            if (target.getClassLoader() != loader) {
                throw new IllegalStateException("target did not load from parentless loader");
            }
            String actualCodeSource = codeSource(target);
            if (!actualCodeSource.equals(expected)) {
                throw new IllegalStateException("wrong CodeSource: expected=" + expected
                        + " actual=" + actualCodeSource);
            }
            Method test = target.getDeclaredMethod("test", String[].class);
            if (!Modifier.isStatic(test.getModifiers())) {
                throw new IllegalStateException("test(String[]) is not static");
            }
            PrintStream resultOut = System.out;
            for (int index = 0; index < CASES.length; index++) {
                observe(test, index, CASES[index], resultOut);
            }
        }
    }
}
