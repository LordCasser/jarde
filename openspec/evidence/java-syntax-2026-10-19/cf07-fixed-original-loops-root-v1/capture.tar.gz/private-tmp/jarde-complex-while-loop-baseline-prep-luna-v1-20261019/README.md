# TestComplexWhileLoop original baseline preparation

Status: private, unexecuted preparation. The full upstream `TestComplexWhileLoop.java` is copied byte-for-byte; the JUnit test method and nested `TestCls` are not removed or rewritten. The exact source hash and root review are in `pins.json`.

`driver/TestComplexWhileLoopDriver.java` invokes the original static `test(String[])` through a fresh parentless `URLClassLoader`, verifies the independently supplied expected `CodeSource`, and uses only the driver classes on the application classpath. For each bounded array case it redirects target `System.out`, records the returned value or the `InvocationTargetException` cause (including stack trace), restores `System.out` in `finally`, then emits one Base64-safe observation row. It executes cases serially and does not alter target code.

Seven inputs cover null array, empty array, a first null, an immediate one-character return, finite nonmatches followed by a one-character return, finite nonmatches followed by null, and a one-character space that trims to empty. The original source can cycle forever if an array contains neither null nor a length-one string. No such case is run; finite cases do not claim wraparound coverage.

`collect_baseline.py` is an unexecuted adaptation of the previously accepted `TestLoopConditionInvoke` baseline collector. It reuses its guards, physical parser, source closure checks, full-source JDK 8/JDK 23 profile capture, parentless runtime launch, Jarde API matrix, and full-bundle JADX capture. It takes both `--cli` and an explicit root-supplied `--cli-sha256`; the current candidate is intentionally not assumed. Actual failures and the JDK 8 full-source framework boundary remain raw observations. The collector has not been run or independently audited for this input.

No toolchain, Jarde CLI, JADX, Cargo, network, or shared-repository write was used. Root should review the adapted collector and driver before any execution.
