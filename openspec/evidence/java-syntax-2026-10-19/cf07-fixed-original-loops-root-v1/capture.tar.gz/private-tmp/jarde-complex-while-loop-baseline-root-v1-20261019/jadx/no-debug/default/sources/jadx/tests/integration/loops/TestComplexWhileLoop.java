package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestComplexWhileLoop.class */
public class TestComplexWhileLoop extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestComplexWhileLoop$TestCls.class */
    public static class TestCls {
        public static String test(String[] strArr) {
            int i = 0;
            int length = strArr.length;
            while (true) {
                String str = strArr[i];
                if (str == null) {
                    System.out.println("loop end");
                    return "";
                }
                if (str.length() == 1) {
                    return str.trim();
                }
                i++;
                if (i >= length) {
                    i = 0;
                }
            }
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().doesNotContain(new CharSequence[]{"for (int at = 0; at < len; at = endAt) {"});
    }
}
