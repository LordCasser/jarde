package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestComplexWhileLoop.class */
public class TestComplexWhileLoop extends IntegrationTest {

    /* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestComplexWhileLoop$TestCls.class */
    public static class TestCls {
        public static String test(String[] arr) {
            int index = 0;
            int length = arr.length;
            while (true) {
                String str = arr[index];
                if (str != null) {
                    if (str.length() == 1) {
                        return str.trim();
                    }
                    index++;
                    if (index >= length) {
                        index = 0;
                    }
                } else {
                    System.out.println("loop end");
                    return "";
                }
            }
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().doesNotContain(new CharSequence[]{"for (int at = 0; at < len; at = endAt) {"});
    }
}
