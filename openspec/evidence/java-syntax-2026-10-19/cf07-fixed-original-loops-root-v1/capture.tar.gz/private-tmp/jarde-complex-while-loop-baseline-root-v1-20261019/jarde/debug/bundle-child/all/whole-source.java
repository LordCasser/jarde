// jarde: presentation of `jadx/tests/integration/loops/TestComplexWhileLoop$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestComplexWhileLoop$TestCls extends java.lang.Object {
    public TestComplexWhileLoop$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestComplexWhileLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static java.lang.String test(java.lang.String[] arr) {
        // @method test([Ljava/lang/String;)Ljava/lang/String;
        // @declaration a static method of `jadx.tests.integration.loops.TestComplexWhileLoop$TestCls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int index;
        int length;
        index = 0;
        length = arr.length;
        java.lang.String str;
        while ((str = arr[index]) != null) {
            if (str.length() == 1) {
                return str.trim();
            } else {
                index = index + 1;
                if (index >= length) {
                    index = 0;
                }
            }
        }
        java.lang.System.out.println("loop end");
        return "";
    }
}
