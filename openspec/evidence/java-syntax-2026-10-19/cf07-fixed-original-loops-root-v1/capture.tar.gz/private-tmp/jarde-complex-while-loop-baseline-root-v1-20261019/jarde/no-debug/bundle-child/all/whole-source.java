// jarde: presentation of `jadx/tests/integration/loops/TestComplexWhileLoop$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestComplexWhileLoop$TestCls extends java.lang.Object {
    public TestComplexWhileLoop$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestComplexWhileLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static java.lang.String test(java.lang.String[] arg0) {
        // @method test([Ljava/lang/String;)Ljava/lang/String;
        // @declaration a static method of `jadx.tests.integration.loops.TestComplexWhileLoop$TestCls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int local1;
        int local2;
        local1 = 0;
        local2 = arg0.length;
        java.lang.String local3;
        while ((local3 = arg0[local1]) != null) {
            if (local3.length() == 1) {
                return local3.trim();
            } else {
                local1 = local1 + 1;
                if (local1 >= local2) {
                    local1 = 0;
                }
            }
        }
        java.lang.System.out.println("loop end");
        return "";
    }
}
