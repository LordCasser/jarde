# CF07 TestLoopCondition2 and TestLoopDetection2 baseline audit

Read-only Python audit of the two completed baseline receipts. It reopens raw command streams, the original upstream Java source, compiler class trees and bundles, Jarde API reports/whole-source files/maps, JADX source files, dependency artifacts, and source/external snapshots. It independently checks full class/Code/BCI facts with the accepted compare and physical class-file parsers and checks the bounded runtime rows against the task's manual expected cases.

The results are in `audit.json`; script and output hashes are in `pins.json`. The receipts remain `captured-pending-independent-review`; this audit does not change their status or assert a generated-output result. No collector, compiler, JVM, Jarde CLI, or JADX was run here.
