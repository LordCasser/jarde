# CF-07 fixed original/generated loop evidence archive preparation

This private package prepares a deterministic tar builder for four fixed upstream loop cases: `TestComplexWhileLoop`, `TestLoopCondition5`, `TestLoopCondition2`, and `TestLoopDetection2`. It does not create the requested repository archive or modify shared files.

The four case families have accepted original/API baselines and accepted generated-source comparisons. The accepted reviews record 380 capture commands total: 20 baseline commands and 75 generated-matrix commands per case. Across the generated comparisons, Jarde completed 64 full-source compiles and 128 VM runs covering 768 case observations. The original classes have 16 VM runs/96 observations. JADX has 16 successful VM runs/96 observations; eight Java 8 full-source compilation attempts hit the known major-55/framework boundary and therefore have no runtime rows. The final fixed audit wrapper exited 0. These totals are also recorded in `review.json` from the accepted receipts/reviews.

The explicit private-root inventory includes each case’s preparation, original receipt, wrappers, generated receipt, and root review; the paired condition2/detection2 baseline and generated wrappers/audits; the three-case fidelity audit; the final four-case audit; the architecture review; and the accepted v9 `review_final_api.py` package with helper files. The archive also includes the complete historical `openspec/evidence/java-syntax-2026-09-27/cf07-basic-loops` composite as historical composite evidence, not as a substitute for per-case receipts, along with exact upstream Java source files and pinned comparison/parser/runtime helpers.

The output target is `openspec/evidence/java-syntax-2026-10-19/cf07-fixed-original-loops-root-v1/capture.tar.gz` plus a JSON sidecar inventory. The packer embeds a member-by-member SHA-256/byte manifest, reopens the tar, and verifies every member. It refuses symlinks and excludes `candidate-cli`, `target`, caches, and `node_modules`. Before packing, it requires all eight actual original/generated result roots to be terminal and to have a `root-review.json` whose status begins `root_accepted`; when the marker carries a receipt hash, it must match the receipt bytes. It separately verifies wrapper command success and raw stream/program pins; a pending wrapper status alone is not treated as acceptance.

`scope-manifest.json` preserves the preparation-time inventory/status snapshot. `review.json` records the accepted current results and their receipt/review hashes. `pins.json` records this preparation bundle’s own file hashes. The packer was only AST-parsed and statically inspected; it was not executed, and no archive was created in this preparation. No Jarde/JADX/JDK/Cargo/Git/network command was run.

After root review, the intended archive invocation is:

```sh
python3 -B /private/tmp/jarde-cf07-fixed-original-loops-archive-prep-luna-v1-20261019/pack_evidence.py
```
