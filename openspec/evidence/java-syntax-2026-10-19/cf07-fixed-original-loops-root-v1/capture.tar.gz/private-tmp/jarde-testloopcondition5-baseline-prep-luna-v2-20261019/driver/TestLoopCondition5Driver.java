import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.Base64;

/** Bounded isolated observations of TestLoopCondition5$TestCls.lastIndexOf(int[],int,int,int). */
public final class TestLoopCondition5Driver {
    private static final String TARGET =
            "jadx.tests.integration.loops.TestLoopCondition5$TestCls";

    private static final class Case {
        final String name;
        final int[] values;
        final int target;
        final int start;
        final int end;

        Case(String name, int[] values, int target, int start, int end) {
            this.name = name;
            this.values = values;
            this.target = target;
            this.start = start;
            this.end = end;
        }
    }

    private static final Case[] CASES = {
        new Case("duplicate-last-hit", new int[] { 2, 1, 2 }, 2, 0, 3),
        new Case("hit-at-start", new int[] { 2, 1, 3 }, 2, 0, 3),
        new Case("miss", new int[] { 1, 2, 3 }, 7, 0, 3),
        new Case("exclude-tail", new int[] { 2, 1, 2 }, 2, 0, 2),
        new Case("empty-range", new int[] { 1, 2 }, 1, 1, 1),
        new Case("null-array-empty-range", null, 1, 0, 0),
        new Case("reversed-range", new int[] { 1, 2 }, 1, 2, 1),
        new Case("null-array-read", null, 1, 0, 1),
        new Case("negative-index", new int[] { 1 }, 1, -1, 0),
        new Case("past-end-index", new int[] { 1 }, 1, 0, 2)
    };

    private static String codeSource(Class<?> target) throws Exception {
        CodeSource source = target.getProtectionDomain().getCodeSource();
        if (source == null || source.getLocation() == null) {
            throw new IllegalStateException("target has no CodeSource");
        }
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }

    private static String b64(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private static String describe(int[] values) {
        if (values == null) return "<null-array>";
        StringBuilder result = new StringBuilder("[");
        for (int i = 0; i < values.length; i++) {
            if (i != 0) result.append(',');
            result.append(values[i]);
        }
        return result.append(']').toString();
    }

    private static void observe(Method method, int index, Case c, PrintStream resultOut) throws Exception {
        PrintStream originalOut = System.out;
        ByteArrayOutputStream targetBytes = new ByteArrayOutputStream();
        PrintStream targetOut = new PrintStream(targetBytes, true, "UTF-8");
        Object value = null;
        Throwable cause = null;
        String stack = "";
        try {
            System.setOut(targetOut);
            try {
                value = method.invoke(null, new Object[] {
                        c.values, Integer.valueOf(c.target), Integer.valueOf(c.start), Integer.valueOf(c.end)
                });
            } catch (InvocationTargetException e) {
                cause = e.getCause();
                StringWriter trace = new StringWriter();
                cause.printStackTrace(new PrintWriter(trace));
                stack = trace.toString();
            }
        } finally {
            targetOut.flush();
            System.setOut(originalOut);
            targetOut.close();
        }
        String exceptionName = cause == null ? "none" : cause.getClass().getName();
        String exceptionMessage = cause == null || cause.getMessage() == null ? "" : cause.getMessage();
        String result = cause == null ? Integer.toString(((Integer) value).intValue()) : "";
        String input = describe(c.values) + ";target=" + c.target + ";start=" + c.start + ";end=" + c.end;
        resultOut.println("CASE index=" + index + " name=" + c.name
                + " input_b64=" + b64(input)
                + " result_b64=" + b64(result)
                + " exception=" + exceptionName
                + " exception_message_b64=" + b64(exceptionMessage)
                + " exception_stack_b64=" + b64(stack)
                + " target_stdout_b64=" + b64(new String(targetBytes.toByteArray(), StandardCharsets.UTF_8)));
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            throw new IllegalArgumentException("usage: TestLoopCondition5Driver actualRoot expectedRoot");
        }
        String actual = Paths.get(args[0]).toRealPath().toString();
        String expected = Paths.get(args[1]).toRealPath().toString();
        URL url = Paths.get(actual).toRealPath().toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(new URL[] { url }, null)) {
            Class<?> target = Class.forName(TARGET, true, loader);
            if (target.getClassLoader() != loader) {
                throw new IllegalStateException("target did not load from parentless loader");
            }
            String actualCodeSource = codeSource(target);
            if (!actualCodeSource.equals(expected)) {
                throw new IllegalStateException("wrong CodeSource: expected=" + expected
                        + " actual=" + actualCodeSource);
            }
            Method method = target.getDeclaredMethod("lastIndexOf", int[].class,
                    int.class, int.class, int.class);
            if (!Modifier.isStatic(method.getModifiers()) || method.getReturnType() != int.class) {
                throw new IllegalStateException("lastIndexOf has unexpected static/return shape");
            }
            PrintStream resultOut = System.out;
            for (int index = 0; index < CASES.length; index++) {
                observe(method, index, CASES[index], resultOut);
            }
        }
    }
}
