# CF08 scope and evidence audit

Read-only scope memo for the four CF08 targets listed in `openspec/evidence/jadx-feature-inventory-2026-09-27/control-flow.md`. Evidence and source hashes are in `pins.json`. No source, CLI, Git, network, compiler, or runtime was changed or executed.

## What the recorded tests cover

- `TestEndlessLoop`: the Java JUnit method only asserts that decompiled text contains `while (this == this)`. Its nested `test1`, `test2`, and `test3` methods do not terminate (`this == this` is always true and `this != this` is always false). Do not invent a finite return oracle or call them without an external step bound. Existing CF08 replay pins this JUnit source but does not invoke the JUnit assertion.
- `TestEndlessLoop2`: a `SmaliTest`; `disableCompilation()` precedes a textual count of two `while (true) {` fragments. The smali contains an empty self-loop. This is decompilation-shape evidence, not an execution of an original JVM class. No existing recorded driver executes it.
- `TestMultiEntryLoop`: a `SmaliTest` with a one-occurrence `while (true) {` assertion. The physical input is DEX/Smali and the tested method is private static with parameters and a static byte-array field. No existing recorded driver executes it; a future finite invocation must explicitly bound its loop and initialize its array safely. A Java rewrite is not evidence for the original Smali lowering.
- `TestNotIndexedLoop`: its JUnit source contains `test()` and `testNoDebug()` assertions forbidding `for (` and requiring one `while (true)`. The nested `TestCls.check()` has four finite cases: null array, empty array, find `f`, and exhaust to `h`. The old general replay does not compile the complete upstream test source/class. `replay.py` compiles a rewritten top-level `cf08.NotIndexedLoop` copied from `TestCls.test` plus a separate Runner. The accepted constructor-predicate evidence also builds this stand-alone fixture, then compares original/JADX/Jarde output for `null / null / f / h` and checks verifier negatives. It closes that reduced method shape, not the nested JUnit class or its actual assertion methods.

## Existing evidence to retain

The accepted `constructor-predicate-accepted` evidence already covers the stand-alone NotIndexed fixture and nine verifier-negative controls. `simple-after` already accepts the finite hand-written `EndlessInts` double-exit fixture (limits `0,1,2,3,4,8`). `effectful-after`, `nested-effectful-after`, and `two-level-if-after` are separate accepted synthetic slices. They are useful control evidence, but none runs the original `TestEndlessLoop`, `TestEndlessLoop2`, or `TestMultiEntryLoop` test assertion or complete source class. Preserve the reports and avoid repeating these delivered slices.

## Safe observation boundary

The only existing semantic driver has an explicit finite array bound: null, empty, a hit at index 1, and a one-element miss. Any rerun should use an empty temporary working directory because `test` calls `File.deleteOnExit`; do not create real `f` or `h` files. Additional NotIndexed rows may bound array length and capture exceptions, but must not replace the accepted four-row evidence.

For `TestEndlessLoop*`, a watchdog can establish only that execution did not finish within its time limit; timeout does not prove nontermination or equivalence. The three Java targets are nonterminating by separate source reasoning: `this == this` is always true and `this != this` is always false. Their intended test assertion is rendered structure, so keep them static unless a separately specified bounded harness is introduced. For the Smali targets, use an actual Smali/DEX class path to claim coverage of the original lowering, and distinguish it from a JVM-equivalent Java fixture. No current evidence establishes a finite driver oracle for `TestMultiEntryLoop`. Do not add a DEX entry point or execution pipeline for this memo; list any JVM-equivalent fixture separately.

This is a scope audit only. CF08 remains partially covered; it does not establish the four-target unit as complete.
