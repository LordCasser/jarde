# Branch throw / return / finally comparison

See `execution.json` for every guarded command, raw stream pin, compiler/runtime matrix, JADX source capture, full EX red control, and before/after source/tool pins. Expectation mode: `observed`. Overall status: `complete_pending_review`.
