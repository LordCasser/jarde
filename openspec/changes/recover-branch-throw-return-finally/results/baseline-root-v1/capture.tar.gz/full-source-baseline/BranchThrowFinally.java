// jarde: presentation of `BranchThrowFinally` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class BranchThrowFinally extends java.lang.Object {
    public BranchThrowFinally() {
        // @method <init>()V
        // @declaration a constructor of `BranchThrowFinally`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static java.lang.String finThrow(int arg0) {
        // @method finThrow(I)Ljava/lang/String;
        // @declaration a static method of `BranchThrowFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        if (arg0 < 0) {
            // @bytecode 4 7 8 10 13
            // BCI 27: the exceptional path repeats code the normal path also runs — the `finally` copy javac emits for a `finally` clause; this candidate lacks the complete straight-body, copy, range, and ownership proof needed to merge them into one `finally`
        } else {
            // @bytecode 14 16 17 20 22 25 26
            // BCI 27: the exceptional path repeats code the normal path also runs — the `finally` copy javac emits for a `finally` clause; this candidate lacks the complete straight-body, copy, range, and ownership proof needed to merge them into one `finally`
        }
        // @bytecode 27 28 31 33 36 37
        // 1 live block(s) are reachable only through edges the normal-flow view leaves out: [27]
    }
}
