// jarde: presentation of `BranchThrowFinally` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class BranchThrowFinally extends java.lang.Object {
    public BranchThrowFinally() {
        // @method <init>()V
        // @declaration a constructor of `BranchThrowFinally`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static java.lang.String finThrow(int arg0) {
        // @method finThrow(I)Ljava/lang/String;
        // @declaration a static method of `BranchThrowFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        try {
            if (arg0 < 0) {
                throw new java.lang.RuntimeException("neg");
            } else {
                java.lang.String local1 = "ok";
                return local1;
            }
        } finally {
            java.lang.System.out.println("ft");
        }
    }
}
