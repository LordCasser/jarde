// default package

/* JADX INFO: loaded from: BranchThrowFinally.class */
public class BranchThrowFinally {
    static String finThrow(int i) {
        try {
            if (i < 0) {
                throw new RuntimeException("neg");
            }
            System.out.println("ft");
            return "ok";
        } catch (Throwable th) {
            System.out.println("ft");
            throw th;
        }
    }
}
