// default package

import java.io.PrintStream;

/* JADX INFO: loaded from: EX.class */
public class EX {
    static String multi(String str) {
        try {
            return str.trim();
        } catch (IllegalStateException | NullPointerException e) {
            return "multi:" + e.getClass().getSimpleName();
        }
    }

    static int finReturn(int i) {
        if (i == 0) {
            return -1;
        }
        return i;
    }

    static String finThrow(int i) {
        try {
            if (i < 0) {
                throw new RuntimeException("neg");
            }
            System.out.println("ft");
            return "ok";
        } catch (Throwable th) {
            System.out.println("ft");
            throw th;
        }
    }

    static int nestedFin(int i) {
        try {
            int i2 = 10 / i;
            try {
                System.out.println("in");
                PrintStream printStream = System.out;
                return i2;
            } finally {
                System.out.println("out");
            }
        } catch (Throwable th) {
            try {
                System.out.println("in");
                throw th;
            } finally {
                System.out.println("out");
            }
        }
    }

    public static void main(String[] strArr) {
        System.out.println("" + multi(" x ") + "/" + finReturn(0) + "/" + finThrow(1) + "/" + nestedFin(2));
        System.out.println(multi(null));
    }
}
