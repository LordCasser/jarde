from pathlib import Path
import json,hashlib,re,stat
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');R=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');O=B/'class-view-focused-root-v1';out=O/'root-acceptance.json';assert not out.exists();d=json.loads((O/'execution.json').read_text());checks=[]
def ck(x,n):
 checks.append(n)
 assert x,n
def pin(p):
 p=Path(p);z=p.read_bytes();return {'path':str(p),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
ck(d['status']=='expected_command_outcomes_observed_pending_independent_acceptance','runner terminal');ck(len(d['commands'])==8,'8 commands');ck(d['source_manifest_before']==d['source_manifest_after'],'source before/after');ck(len(d['source_manifest_before'])==4900,'full dynamic and compiled source count')
for x in d['source_manifest_before']:
 z=(R/x['path']).read_bytes();ck(len(z)==x['bytes'] and hashlib.sha256(z).hexdigest()==x['sha256'],'current source/'+x['path'])
tot=[0,0,0];named=[];suites=0
for row in d['commands']:
 ck(row['exit_code']==0 and row['guard_stop'] is None,'exit/guard/'+row['label'])
 for k,v in row['streams'].items():
  q=pin(v['path']);ck(q['bytes']==v['bytes'] and q['sha256']==v['sha256'],'raw/'+row['label']+'/'+k)
 t=Path(row['streams']['stdout']['path']).read_text();summaries=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t)
 for s in summaries:
  ck(s[0]=='ok' and s[2]=='0','suite/'+row['label']);tot=[a+int(x) for a,x in zip(tot,s[1:])];suites+=1
 if row['label'] in ['public-selection-demand-and-binding','task-cli-public-controls']:ck(summaries and sum(int(x[1]) for x in summaries)>0,'nonzero/'+row['label'])
 named+=re.findall(r'^test (.+) \.\.\. (ok|ignored|FAILED)(?:, .*)?$',t,re.M)
ck(tot==[76,0,2] and suites==5,'76/0/2 in5suites')
for n in ['duplicate_method_identity_uses_name_ambiguity_before_body_admission','duplicate_member_identity_and_name_are_ambiguous_in_class_view_cli','a_view_decodes_every_requested_body_against_one_preparation','a_view_that_decodes_no_body_prepares_nothing','a_duplicated_member_record_binds_nothing','the_class_view_reads_one_header_one_listing_and_only_the_requested_bodies','a_body_reference_outside_this_class_is_an_input_error','a_view_with_one_stopped_body_is_not_complete_and_keeps_the_other_body','every_task_document_is_the_librarys_own']:
 ck(sum(a==n and b=='ok' for a,b in named)==1,'required named/'+n)
for n in ['3.stdout.raw','4.stdout.raw']:ck('Totals: 366 passed, 0 failed (366 items)' in (O/n).read_text(),'strict366/'+n)
q=pin(d['frozen_cli']['path']);ck(all(q[k]==d['frozen_cli'][k] for k in ['bytes','sha256']),'frozen CLI bytes');ck(stat.S_IMODE(Path(q['path']).stat().st_mode)==0o555,'frozen mode')
ck(d['commands'][-1]['argv']==['cargo','clean'],'exact clean');ck(d['target_absent'] and not (R/'target').exists(),'actual target absent');ck(d['default_stack'] and d['environment']['RUST_MIN_STACK'] is None,'default stack')
report={'status':'accepted_local_class_view_focus_only','checks':len(checks),'execution':pin(O/'execution.json'),'source_count':4900,'test_totals':{'passed':76,'failed':0,'ignored':2},'suites':5,'commands':8,'raw_streams':16,'duplicate_public_requests':27,'matrix_inference':'successful unmodified9pairs loop runs exact Name+2listedIDs; abstract-code all3requests use method_bodies0','cli_queries':3,'cli':q,'target_absent':True,'own_ci_accepted':False,'auditor':pin(__file__)}
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
