from pathlib import Path
import ast,json
b=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');s=(b/'emitter_focused_v3.py').read_text();tree=ast.parse(s);assign=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='commands' for t in n.targets));lines=s.splitlines(True);lines[assign.lineno-1:assign.end_lineno]=['        commands = json.loads(args.spec.read_text())\n'];s=''.join(lines)
s=s.replace("ap.add_argument('--out'", "ap.add_argument('--spec', type=Path, required=True)\n    ap.add_argument('--out'",1)
s=s.replace("source_paths = closure.source_paths()", "source_paths = sorted(set(closure.source_paths()) | {ROOT / x['path'] for x in json.loads((ROOT / 'tests/fixtures/corpus-fingerprint.json').read_text())['files']})")
s=s.replace("'core-integrity-emitter-focused-validation-v3'","'class-view-guarded-validation-v1'")
s=s.replace("def run(label: str, argv: list[str], *, test: bool = False)","def run(label: str, argv: list[str], *, test: bool = False, expected_exit: int = 0)")
s=s.replace("row['label'] = label\n        record", "row['label'] = label\n        row['expected_exit_code'] = expected_exit\n        record",1)
s=s.replace("if row['exit_code'] != 0 or row['guard_stop'] is not None:","if row['exit_code'] != expected_exit or row['guard_stop'] is not None:",1)
s=s.replace("if not summaries or any(x[0] != 'ok' or int(x[2]) for x in summaries):", "if not summaries or sum(int(x[1])+int(x[2]) for x in summaries)==0 or (expected_exit==0 and any(x[0] != 'ok' or int(x[2]) for x in summaries)) or (expected_exit!=0 and not any(int(x[2]) for x in summaries)):")
s=s.replace("json.dumps([argv for _label, argv, _test in commands]", "json.dumps([argv for _label, argv, _test, _expected in commands]")
s=s.replace("for label, argv, test in commands:\n            row = run(label, argv, test=test)","for label, argv, test, expected in commands:\n            row = run(label, argv, test=test, expected_exit=expected)")
a=s.index("        built = ROOT / 'target/debug/jarde-cli'");z=s.index("        record['source_manifest_after']",a);body=s[a:z];s=s[:a]+"        if any(label == 'build-cli' for label, _, _, _ in commands):\n"+''.join('    '+x+'\n' for x in body.splitlines())+s[z:]
s=s.replace("commands_passed_pending_independent_acceptance","expected_command_outcomes_observed_pending_independent_acceptance")
compile(s,str(b/'class_view_runner_v1.py'),'exec');(b/'class_view_runner_v1.py').write_text(s)
cli=['cargo','test','-p','jarde-cli','--test','task_cli','--locked','--message-format','json','--','--exact','duplicate_member_identity_and_name_are_ambiguous_in_class_view_cli','--nocapture']
repro=[['old-library-duplicate',['cargo','test','-p','jarde','--test','task_operations','--all-features','--locked','--message-format','json','--','--exact','duplicate_method_identity_uses_name_ambiguity_before_body_admission','--nocapture'],True,101],['old-cli-duplicate',cli,True,101]]
(b/'class-view-repro-command-spec-v1.json').write_text(json.dumps(repro,indent=2)+'\n')
print('prepared configurable guarded runner; dynamic corpus paths included from start')
