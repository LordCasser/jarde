from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');O=R/'openspec/changes/reject-ambiguous-class-view-body-selection/results/root-local-v1';O.mkdir(parents=True,exist_ok=False);files={}
def add(p,n):
 assert p.is_file() and n not in files,(p,n)
 files[n]=p.read_bytes()
for n in ['class-view-focused-root-v1','class-view-repro-root-v1','class-view-cli-repro-root-v2','class-view-repro-source-v1','class-view-cli-repro-source-v2','class-view-apply-context-v1']:
 for p in sorted((B/n).rglob('*')):
  if p.is_file():add(p,n+'/'+p.relative_to(B/n).as_posix())
for n in ['class_view_runner_v1.py','accept_class_view_focus_v1.py','prepare_class_view_runner_v1.py','class-view-repro-command-spec-v1.json','class-view-cli-repro-command-spec-v2.json','class-view-focused-command-spec-v1.json','class-view-old-production-root-acceptance-v1.json','class-view-old-reproduction-independent-review-v1.json','class-view-candidate-final-static-review-v1.json','class-view-candidate-final-static-review-v2.json','primary-core-delivery-final-head-v1.json','next-three-plan-adoption-root-v1.json','archive_class_view_v1.py']:
 add(B/n,'root/'+n)
for n in ['guard.py','target_scan.py','workspace_runner.py']:
 add(B.parent/'ordinary-try-list-20261014/tools-prep'/n,'tools/'+n)
for n in ['src/facade.rs','tests/task_operations.rs','crates/jarde-cli/tests/task_cli.rs']:add(R/n,'source/'+n)
manifest={'schema':'class-view-root-local-evidence-v1','base_head':'7d0a169ca21b714efab31d7a23d661fb90cd5e40','scope':'local only; own product CI not yet accepted','payloads':[{'path':n,'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()} for n,z in sorted(files.items())]};files['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();a=O/'capture.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for n,z in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(z);m.mode=0o644;m.mtime=0;t.addfile(m,io.BytesIO(z))
with tarfile.open(a,'r:gz') as t:
 assert len(t.getmembers())==len(files)
 for m in t:assert m.isfile() and t.extractfile(m).read()==files[m.name],m.name
report={'status':'accepted_local_archive_byte_integrity','payloads':len(files)-1,'all_members_reopened':len(files),'archive':{'path':'capture.tar.gz','bytes':a.stat().st_size,'sha256':hashlib.sha256(a.read_bytes()).hexdigest()},'product_ci_accepted':False};(O/'archive-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
(O/'README.md').write_text('''# class-view 根本地对照与门禁

本归档保持旧实现与修复候选各自真实源码和日志，不改历史失败。manifest逐项记录唯一相对路径、字节数与SHA；根已重新打开全部成员逐字核对。

旧生产为exact d3/main7d0：library 首abstract-code组合的Name已按预期歧义，首listed-ID随后错误执行（0通过/1失败），后八组合与第二ID未跑。CLI v1先因测试错读顶层usage得到Null/0，**排除产品反例**；仅将新测试全部usage修成实际execution.usage后，fresh CLI v2真实列举成功，首listed-ID实际exit0、期望歧义exit3（0/1），后续ID/Name未执行。两次receipt各4900来源前后恒同、guard未触发、finally exact clean成功。

修复保留foreign-owner优先级，Method与Name共用现有完整候选判定，移除首取helper。focused-v1实际76通过/0失败/2忽略，5suites、8命令/16raw，root4952checks接受。成功公共矩阵到达九组×Name+两个listed-ID共27请求；abstract-code三个请求均method_bodies=0，仍歧义且零prep/body/Code/IR。唯一abstract/native/Code、不同descriptor、同签名foreign-owner、missing/partial/stopped-body和一次读取/按需解码控制全部通过。CLI真实list→两ID及Name三请求均exit3、完整index/flags/相同IDs保留，execution.usage零body/Code/IR。

fmt、当前CI Clippy、OpenSpec1.11.0/1.14.1 strict366/0、实际build CLI及finally exact clean成功。冻结CLI59599048字节/SHA c0bc6b64e1c763ee400afdb60d328a83151091fecbd72ed8ead1e906bd170f45，不包含可执行文件本身。4900来源从本轮运行开始包含全部manifest corpus遍历输入，区别于上轮4887历史闭包的13项audit-time补充。本地focused不替代产品自身完整CI，交付2.2仍开放；另外两项proof-stop新计划仍0/23。
''')
