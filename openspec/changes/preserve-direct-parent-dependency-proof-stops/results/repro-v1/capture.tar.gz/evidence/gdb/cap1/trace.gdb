set auto-load off
set debuginfod enabled off
set pagination off
set confirm off
set breakpoint pending off
set print thread-events off
set disable-randomization off
break '<jarde_reader::budget::Budget>::exceeded'
commands
silent
printf "DT29_QUOTA_REFUSAL\n"
bt 30
continue
end
run class-source --input /home/lordcasser/.codex/worktrees/core-integrity/jarde/openspec/evidence/java-syntax-2026-09-27/dt29-same-package-parent-field-writes/outputs/input.jar --class 'dt29/SamePackageParentFamily$B' --format json --evidence essential --budget elapsed_millis=10000 --budget output_bytes=1048576 --budget class_headers=1 > /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/neighbor-proof-dt29-gdb-cap1-root-v1/inferior.stdout.raw 2> /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/neighbor-proof-dt29-gdb-cap1-root-v1/inferior.stderr.raw
printf "DT29_INFERIOR_EXIT=%d\n", $_exitcode
