from pathlib import Path
import json,hashlib
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
def pin(p):
 z=p.read_bytes();return {'path':str(p),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
def norm(v,path='',removed=None):
 if isinstance(v,dict):
  d={}
  for k,x in v.items():
   p=path+'/'+k
   if p.endswith('/usage/elapsed_millis'):removed.append(p)
   else:d[k]=norm(x,p,removed)
  return d
 if isinstance(v,list):return [norm(x,path+'/'+str(i),removed) for i,x in enumerate(v)]
 return v
rows=[]
for cap in [1,2]:
 p=B/f'neighbor-proof-dt29-gdb-cap{cap}-root-v1/execution.json';d=json.loads(p.read_text());raw=p.parent/'inferior.stdout.raw';baseline=Path(d['ordinary_case']['streams']['stdout']['path']);a=json.loads(raw.read_bytes());b=json.loads(baseline.read_bytes());removed_a=[];removed_b=[];assert a['limits']==b['limits'];assert norm(a,removed=removed_a)==norm(b,removed=removed_b);assert removed_a==removed_b;assert len(removed_a)==6 and '/limits/elapsed_millis' not in removed_a;rows.append({'cap':cap,'trace_receipt':pin(p),'inferior_raw':pin(raw),'ordinary_raw':pin(baseline),'limits_exactly_equal':a['limits'],'ignored_only_actual_usage_elapsed_paths':removed_a,'otherwise_whole_json_exact':True,'quota_hits':d['quota_refusal_markers']})
o=B/'neighbor-dt29-trace-strict-elapsed-root-acceptance-v1.json';assert not o.exists();o.write_text(json.dumps({'status':'accepted_strict_whole_json_equivalence_except_six_usage_elapsed_leaves','auditor':pin(Path(__file__)),'scope':'Original trace producer broadly removed any elapsed_millis including fixed limit. This supplemental check preserves every limits field exactly and ignores only six actual usage clock leaves. Original captures and scripts are unchanged.','cases':rows},indent=2)+'\n');print(o)
