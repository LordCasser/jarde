from pathlib import Path
import json,os,shlex,hashlib,importlib.util
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');R=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');O=B/'neighbor-proof-dt29-gdb-cap2-root-v1';assert not O.exists() and not(R/'target').exists()
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
h=load('dt29_trace_helper',B/'interface-full-source-harness-v4/run_interface_full_source_harness.py');cli=B/'jarde-cli-combined-source-proof-v5';build=B/'class-source-proof-focused-root-v5/execution.json';binding=h.verify_cli(cli,build);screen=B/'neighbor-proof-dt29-screen-harness-v1/run-v1/execution.json';d=json.loads(screen.read_text());assert d['status']=='captured_screen_pending_semantic_review' and d['inputs_identical'] and d['target_absent'];case=next(x for x in d['commands'] if x['cli_variant']=='class-source-v5' and x['name']=='headers-2');args=case['argv'];assert args[0]==str(cli) and args[-1]=='class_headers=2';baseline=Path(case['streams']['stdout']['path']);gdb=Path('/usr/bin/gdb');source=json.loads(build.read_text())['source_manifest_after']
def sourcepins():return [{'path':x['path'],'bytes':(R/x['path']).stat().st_size,'sha256':h.sha(R/x['path'])} for x in source]
assert sourcepins()==source and len(source)==4902
O.mkdir();trace=O/'trace.gdb';trace.write_text('set auto-load off\nset debuginfod enabled off\nset pagination off\nset confirm off\nset breakpoint pending off\nset print thread-events off\nset disable-randomization off\nbreak \'<jarde_reader::budget::Budget>::exceeded\'\ncommands\nsilent\nprintf "DT29_QUOTA_REFUSAL\\n"\nbt 30\ncontinue\nend\nrun '+shlex.join(args[1:])+' > '+shlex.quote(str(O/'inferior.stdout.raw'))+' 2> '+shlex.quote(str(O/'inferior.stderr.raw'))+'\nprintf "DT29_INFERIOR_EXIT=%d\\n", $_exitcode\n')
inputs=[Path(__file__),gdb,cli,build,screen,baseline,R/'openspec/evidence/java-syntax-2026-09-27/dt29-same-package-parent-field-writes/outputs/input.jar',trace,B/'combined-proof-product-source-git-binding-v1.json'];before=[h.pin(x) for x in inputs];g=load('dt29_trace_guard',h.GUARD_PATH);scan=load('dt29_trace_scan',h.SCAN_PATH);g.ROOT=R;g.OUT=O;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.target_bytes=lambda:scan.target_bytes(R);g.command_stream=lambda p:h.pin(Path(p));g.expected_test_summaries=lambda i,v:None;g.ENV_VALUES={};env={k:v for k,v in os.environ.items() if k in ['HOME','LANG','LC_ALL']};env['PATH']='/usr/bin:/bin';rows=[];record={'status':'running','scope':'observational quota backtrace only; no source changes, fabricated error, debugger return/assignment, or automatic defect classification','cli_binding':binding,'ordinary_case':case,'input_pins_before':before,'source_count':4902,'source_manifest_before':source,'commands':rows}
def save():(O/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
def norm(v,path='',removed=None):
 if isinstance(v,dict):
  out={}
  for k,x in v.items():
   if k=='elapsed_millis':removed.append(path+'/'+k)
   else:out[k]=norm(x,path+'/'+k,removed)
  return out
 if isinstance(v,list):return [norm(x,path+'/'+str(i),removed) for i,x in enumerate(v)]
 return v
save()
try:
 for i,argv in enumerate([[str(gdb),'--version'],[str(gdb),'--batch','--nx','-x',str(trace),'--args',*args]],1):
  row=g.run_command(i,argv,env);rows.append(row);save();assert row['exit_code']==0 and row['guard_stop'] is None
 output=Path(rows[-1]['streams']['stdout']['path']).read_text();record['quota_refusal_markers']=output.count('DT29_QUOTA_REFUSAL');record['inferior_exit_marker_zero']='DT29_INFERIOR_EXIT=0' in output;assert record['quota_refusal_markers']>0 and record['inferior_exit_marker_zero']
 actual=json.loads((O/'inferior.stdout.raw').read_bytes());original=json.loads(baseline.read_bytes());ignored_a=[];ignored_b=[];same=norm(actual,removed=ignored_a)==norm(original,removed=ignored_b);assert same and ignored_a==ignored_b
 record.update({'status':'observed_actual_quota_refusal_with_unchanged_public_result','normalized_inferior_equals_ordinary':same,'ignored_elapsed_paths':ignored_a,'inferior_streams':{k:h.pin(O/('inferior.'+k+'.raw')) for k in ['stdout','stderr']}})
except BaseException as e:record['status']='failed_preserved_observation';record['error']=repr(e)
finally:
 record['input_pins_after']=[h.pin(x) for x in inputs];record['source_manifest_after']=sourcepins();record['inputs_identical']=record['input_pins_after']==before;record['sources_identical']=record['source_manifest_after']==source;record['target_absent']=not(R/'target').exists();save()
assert record['status']=='observed_actual_quota_refusal_with_unchanged_public_result' and record['inputs_identical'] and record['sources_identical'] and record['target_absent'];print(json.dumps({'status':record['status'],'quota_hits':record['quota_refusal_markers'],'equal_except_elapsed':record['normalized_inferior_equals_ordinary']}))
