# DT29 neighboring public screen harness (prepared only)

`run.py --out <fresh-child-directory>` is for the main coder to invoke after the interface full-source work releases the target/CLI lane. This agent did not run the harness, either CLI, JDK, Cargo, or any repository command that changes source.

The script validates the approved input manifest, 1253-byte JAR and inventory pins; verifies each frozen CLI against its own build receipt; verifies all 4902 current source pins against the final class-source receipt; then records the nine listed class-source argv first against the old interface-v4 CLI and again against the final class-source-v5 CLI. It uses argv arrays (never shell interpolation), the existing process guard and scanner, a fresh output directory, 5 GiB free-space and 1 GiB target guards, and preserves stdout/stderr raw streams and hashes. Actual process exits are recorded; only 0 and 4 are accepted for capture. Parsed JSON is retained without asserting a schema or semantics.

The resulting status is only `captured_screen_pending_semantic_review`. Review must attribute selection/analysis/proof phase and actual budget refusal before treating any quota outcome as a defect. The fixture includes accessor, field, and later snapshot work; this harness intentionally does not assign a single cause to all rows.
