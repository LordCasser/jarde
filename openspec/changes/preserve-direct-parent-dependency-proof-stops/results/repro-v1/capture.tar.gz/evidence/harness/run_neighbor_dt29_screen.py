#!/usr/bin/env python3
"""Capture the approved DT29 public class-source screen under the existing process guard.

Prepared only. Root invokes this after the interface run is clear. No expected JSON
shape or semantic outcome is encoded; the receipt records actual exits and raw streams.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, shutil, sys
from pathlib import Path

BASE = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015').resolve()
ROOT = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde').resolve()
INPUTS = Path('/home/lordcasser/.cache/jarde-review/20261015/neighbor-proof-dt29-public-probe-inputs-v1.json')
INVENTORY = Path('/home/lordcasser/.cache/jarde-review/20261015/neighbor-proof-debt-input-inventory-v1/inventory.json')
JAR = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde/openspec/evidence/java-syntax-2026-09-27/dt29-same-package-parent-field-writes/outputs/input.jar')
OLD_CLI = BASE / 'jarde-cli-interface-proof-v4'
OLD_RECEIPT = BASE / 'interface-proof-focused-root-v4/execution.json'
FINAL_CLI = BASE / 'jarde-cli-combined-source-proof-v5'
FINAL_RECEIPT = BASE / 'class-source-proof-focused-root-v5/execution.json'
HARNESS_DIR = BASE / 'interface-full-source-harness-v4'
HARNESS = HARNESS_DIR / 'run_interface_full_source_harness.py'
GUARD_PATH = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/guard.py')
SCAN_PATH = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/target_scan.py')
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3
CLASS_NAME = 'dt29/SamePackageParentFamily$B'


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def pin(path: Path) -> dict:
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def check_pin(path: Path, expected: dict) -> dict:
    actual = pin(path)
    if actual['bytes'] != expected.get('bytes') or actual['sha256'] != expected.get('sha256'):
        raise RuntimeError(f'input pin mismatch: {path}')
    return actual

def verify_cli(harness, cli: Path, receipt: Path) -> dict:
    return harness.verify_cli(cli, receipt)

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path, required=True, help='new output directory under this harness directory')
    args = ap.parse_args()
    out = args.out.resolve()
    if not out.is_relative_to(Path(__file__).resolve().parent) or out.exists():
        raise SystemExit('output must be a fresh child of this harness directory')
    if (ROOT / 'target').exists():
        raise SystemExit('refusing to run while the worktree target exists')
    if shutil.disk_usage(ROOT).free < FREE_LIMIT:
        raise SystemExit('5 GiB free-space guard failed')
    for p in (INPUTS, INVENTORY, JAR, OLD_CLI, OLD_RECEIPT, FINAL_CLI, FINAL_RECEIPT, HARNESS, GUARD_PATH, SCAN_PATH):
        if not p.is_file():
            raise FileNotFoundError(p)

    template = json.loads(INPUTS.read_text(encoding='utf-8'))
    if template.get('status') != 'prepared_only_not_executed' or len(template.get('commands', [])) != 9:
        raise RuntimeError('input template status/command count differs from the reviewed 9-command plan')
    if template['inputs'][1]['path'] != str(JAR) or template['inputs'][1]['bytes'] != 1253 or template['inputs'][1]['sha256'] != '31ec2e5d6b4fdac4fc4c910904c3b84dc92f64d54e83a1a81b41e57b41dad5c3':
        raise RuntimeError('approved DT29 JAR identity is not the expected 1253-byte input')
    jar_pin = check_pin(JAR, template['inputs'][1])
    inventory_pin = check_pin(INVENTORY, template['inputs'][2])
    old_binding = verify_cli(load('dt29_harness_old', HARNESS), OLD_CLI, OLD_RECEIPT)
    new_harness = load('dt29_harness_final', HARNESS)
    final_binding = verify_cli(new_harness, FINAL_CLI, FINAL_RECEIPT)
    final_receipt_data = json.loads(FINAL_RECEIPT.read_text(encoding='utf-8'))
    source_before = final_receipt_data.get('source_manifest_before')
    source_after = final_receipt_data.get('source_manifest_after')
    if not isinstance(source_before, list) or source_before != source_after or final_receipt_data.get('target_absent') is not True:
        raise RuntimeError('final CLI receipt does not bind stable source pins with target absent')
    for row in source_before:
        actual = pin(ROOT / row['path'])
        if actual['bytes'] != row['bytes'] or actual['sha256'] != row['sha256']:
            raise RuntimeError(f'current source differs from final receipt: {row["path"]}')

    commands = []
    for label, cli, receipt in (('interface-v4', OLD_CLI, OLD_RECEIPT), ('class-source-v5', FINAL_CLI, FINAL_RECEIPT)):
        for item in template['commands']:
            original = list(item['argv'])
            if original[0] != str(OLD_CLI) or original[1:6] != ['class-source', '--input', str(JAR), '--class', CLASS_NAME]:
                raise RuntimeError(f'unapproved command argv in template: {item.get("name")}')
            argv = [str(cli), *original[1:]]
            commands.append({'cli_variant': label, 'build_receipt': str(receipt), 'name': item['name'], 'argv': argv})
    if len(commands) != 18:
        raise RuntimeError('expected exactly 18 actual commands')

    input_paths = [Path(__file__).resolve(), INPUTS, INVENTORY, JAR, OLD_CLI, OLD_RECEIPT, FINAL_CLI, FINAL_RECEIPT,
                   HARNESS, GUARD_PATH, SCAN_PATH]
    input_paths += [ROOT / row['path'] for row in source_before]
    input_paths = sorted(set(p.resolve() for p in input_paths))
    before = [pin(p) for p in input_paths]
    out.mkdir(parents=True, exist_ok=False)
    (out / 'source-input-manifest-before.json').write_text(json.dumps(before, indent=2)+'\n')

    guard = load('dt29_guard', GUARD_PATH)
    scanner = load('dt29_target_scan', SCAN_PATH)
    guard.ROOT = ROOT
    guard.OUT = out
    guard.FREE_LIMIT = FREE_LIMIT
    guard.TARGET_LIMIT = TARGET_LIMIT
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.expected_test_summaries = lambda _index, _data: None
    guard.command_stream = lambda path: pin(Path(path))
    guard.ENV_VALUES = {}
    env = {k: v for k, v in os.environ.items() if k in ('HOME', 'TMPDIR', 'LANG', 'LC_ALL')}
    for key in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'RUST_MIN_STACK', 'CARGO_TARGET_DIR'):
        env.pop(key, None)
    env['PATH'] = '/usr/bin:/bin'
    rows = []
    record = {
        'schema': 'neighbor-proof-dt29-screen-harness-v1',
        'status': 'running',
        'scope': '18 approved public class-source argv: original 9 caps on old interface CLI and final class-source v5 CLI; capture only, semantic review pending',
        'input_template': pin(INPUTS), 'inventory': inventory_pin, 'jar': jar_pin,
        'cli_bindings': {'interface-v4': old_binding, 'class-source-v5': final_binding},
        'source_manifest_count': len(source_before),
        'source_manifest_sha256': hashlib.sha256(json.dumps(source_before, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        'guards': {'free_bytes_minimum': FREE_LIMIT, 'target_bytes_maximum': TARGET_LIMIT},
        'environment': env, 'commands': rows,
    }
    def save():
        p = out / 'execution.json.tmp'
        p.write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
        p.replace(out / 'execution.json')
    save()
    try:
        for idx, spec in enumerate(commands, 1):
            row = guard.run_command(idx, spec['argv'], env)
            row.update({'cli_variant': spec['cli_variant'], 'build_receipt': spec['build_receipt'], 'name': spec['name'], 'argv_exact': spec['argv'], 'cwd': str(ROOT)})
            row['guard_status'] = 'stopped' if row.get('guard_stop') is not None else 'clear'
            rows.append(row); save()
            if row.get('guard_stop') is not None:
                raise RuntimeError(f'guard stopped command {idx}: {row["guard_stop"]}')
            if row.get('exit_code') not in (0, 4):
                raise RuntimeError(f'command {idx} returned an unapproved process exit {row.get("exit_code")}; raw streams retained')
            stdout_path = Path(row['streams']['stdout']['path'])
            try:
                parsed = json.loads(stdout_path.read_text(encoding='utf-8'))
                (out / f'{idx:02d}.parsed.json').write_text(json.dumps(parsed, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
                row['stdout_json_parsed'] = True
            except (UnicodeDecodeError, json.JSONDecodeError):
                row['stdout_json_parsed'] = False
            save()
        record['status'] = 'captured_screen_pending_semantic_review'
    except BaseException as exc:
        record['status'] = 'capture_failed'
        record['error'] = f'{type(exc).__name__}: {exc}'
    finally:
        after = [pin(p) for p in input_paths]
        record['source_input_manifest_after'] = after
        record['inputs_identical'] = before == after
        record['target_absent'] = not (ROOT / 'target').exists()
        record['free_bytes_after'] = shutil.disk_usage(ROOT).free
        if not record['inputs_identical'] or not record['target_absent']:
            record['status'] = 'capture_failed_integrity_or_cleanup'
        save()
    return 0 if record['status'] == 'captured_screen_pending_semantic_review' and len(rows) == 18 and record['inputs_identical'] and record['target_absent'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
