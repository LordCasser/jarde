# DT29 direct-parent wide source/runtime harness v3

This prepared revision preserves the v2 run and its failed javac raw. The v2 failure was an invalid assembly: its compile argv included the whole-root emitted source and the standalone `$A`/`$B` report sources, while the whole-root text already contains complete nested A and B declarations. The duplicate binary nested classes caused javac to reject that input set. This is a harness assembly failure, not evidence of a product failure; see `v2-failure-context.json`.

Run only after the root releases the CLI lane, using the pinned bundled Python 3.12 and blake3 module path:

```sh
PYTHONPATH=/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/pythonlib \
  /home/lordcasser/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/neighbor-direct-parent-full-source-harness-v3/run.py \
  --out /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/neighbor-direct-parent-full-source-harness-v3/run-v1
```

The three physical class-source CLI captures remain in scope. The standalone `$A` and `$B` text files are retained and identity-checked as observations; the rebuild compiles only the exact whole-root emitted Java text (which contains nested A/B) and the byte-identical original Runner. It does not trim or rewrite any source. The original Runner is still compiled against the original JAR separately. Java 23 and Java 8 each run the original and rebuilt outputs and must match the exact oracle bytes from `outputs/results.json`.

This remains a fixed wide positive reproduction, not a low-cap equivalence assertion, product CI result, or completed acceptance. No CLI/JDK/Cargo/GDB/Git was invoked while preparing v3.
