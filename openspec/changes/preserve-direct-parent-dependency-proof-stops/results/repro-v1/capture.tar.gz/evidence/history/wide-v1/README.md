# DT29 direct-parent wide source/runtime harness

Prepared only; the script has not invoked the frozen CLI, javac, Java, or any repository tool. Root can invoke it after the existing CLI lane is released:

```sh
python3 /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/neighbor-direct-parent-full-source-harness-v1/run.py \
  --out /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/neighbor-direct-parent-full-source-harness-v1/run-v1
```

The only tested input is the existing pinned 1253-byte DT29 JAR with its three physical classes. The harness binds the frozen class-source-v5 CLI to its 4902-source build receipt; captures JSON `--evidence all` reports for outer family, `$A`, and `$B`; checks the actual selected class entry and class bytes; and saves each JSON `text` field byte-for-byte as a `.java` file with the same binary basename.

It then copies the fixture Runner without changing bytes, compiles it against the original JAR, compiles all three emitted sources and the same Runner with no original-JAR classpath, and runs original and rebuilt versions on pinned Java 23 and Java 8. Each run must exit 0 and emit the exact `outputs/results.json` oracle bytes `true:true:false:false\n`. It records all nine argv commands and their 18 raw streams, source/tool/input pins before and after, output Java/class hashes, and target/free-space guards. The receipt status remains pending independent review; it does not treat low-cap fallback as runtime equivalence and makes no broader CI claim.
