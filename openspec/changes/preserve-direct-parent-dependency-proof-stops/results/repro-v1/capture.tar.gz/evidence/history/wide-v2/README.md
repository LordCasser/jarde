# DT29 direct-parent wide source/runtime harness v2

Prepared only; this version fixes v1's class identity comparison. Run it with the pinned bundled Python 3.12 runtime and the recorded blake3 module path, after root releases the CLI lane:

```sh
PYTHONPATH=/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/pythonlib \
  /home/lordcasser/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/neighbor-direct-parent-full-source-harness-v2/run.py \
  --out /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/neighbor-direct-parent-full-source-harness-v2/run-v1
```

`class-id-pins.json` records the read-only SHA-256, BLAKE3, and byte length of each of the three physical classes in the original 1253-byte JAR, along with the JAR, Python, blake3 module, and native-extension pins. At runtime the harness verifies both JAR SHA-256 and BLAKE3; it separately checks that each JSON report selects the exact expected physical entry and matches that class's byte length and BLAKE3 digest. JSON `class_bytes.digest` is BLAKE3, not SHA-256.

The fixed positive scope remains unchanged: bind the final v5 CLI to its 4902-source receipt; capture three wide `class-source --format json --evidence all` reports; save each report text exactly as a `.java` file; compile the original fixture Runner against the original JAR; compile the emitted three sources plus an identical Runner without the original JAR on the classpath; and run original/rebuilt forms on Java 23 and Java 8 against the exact `outputs/results.json` stdout oracle. The run records nine argv commands, 18 raw streams, before/after pins, generated source/class pins, and target/free-space guards. It was not executed; its receipt remains pending independent review.
