#!/usr/bin/env python3
"""Prepared, fixed-scope DT29 direct-parent class-source wide-positive runner.

This script is not executed by its preparer. It records three public CLI reports,
two javac builds and four Java runtime comparisons under the shared process guard.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, shutil, sys, zipfile
from pathlib import Path

PYTHON = Path('/home/lordcasser/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3')
PYTHONLIB = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/pythonlib')
if tuple(sys.version_info[:2]) != (3, 12) or Path(sys.executable).resolve() != PYTHON.resolve():
    raise SystemExit('use the pinned bundled Python 3.12 runtime for BLAKE3 class identity checks')
sys.path.insert(0, str(PYTHONLIB))
import blake3

BASE = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015').resolve()
ROOT = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde').resolve()
SCOPE = ROOT / 'openspec/evidence/java-syntax-2026-09-27/dt29-same-package-parent-field-writes'
JAR = SCOPE / 'outputs/input.jar'
FAMILY_SOURCE = SCOPE / 'fixtures/SamePackageParentFamily.java'
RUNNER_SOURCE = SCOPE / 'fixtures/SamePackageParentRunner.java'
RESULTS = SCOPE / 'outputs/results.json'
CLASS_ID_PINS = Path(__file__).resolve().parent / 'class-id-pins.json'
CLI = BASE / 'jarde-cli-combined-source-proof-v5'
CLI_RECEIPT = BASE / 'class-source-proof-focused-root-v5/execution.json'
HARNESS = BASE / 'interface-full-source-harness-v4/run_interface_full_source_harness.py'
GUARD_PATH = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/guard.py')
SCAN_PATH = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/target_scan.py')
JDK_MANIFEST = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jdk-manifest.json')
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3
EXPECTED_CLASS_IDENTITIES = {
    'dt29/SamePackageParentFamily': {'bytes': 262, 'sha256': '85c8f1a8ad10dd94501b281e60cbf15d25cf0fc1e745ed5b48954866689aa565', 'blake3': '76d888e07bb1b38a2253478b85fd50de4abb8546b30fa64226b9735d3daede5e'},
    'dt29/SamePackageParentFamily$A': {'bytes': 467, 'sha256': '5505a0e839775d7874668a7cccd4b2c19de42946ad393222f862076764e9c9fd', 'blake3': '1fe1977fa7055d486c2699bdda24294a32c200e33a6c81dd1ee3d9f99b588f20'},
    'dt29/SamePackageParentFamily$B': {'bytes': 467, 'sha256': '8b072630eb205ea7df76925bfce86d900087b23cf4e63e5a453b2ce52ddc34e2', 'blake3': '457daef0e946b36568e2cd608488b7f66a4bb9dc8773dc050c8a66a2ecd0def7'},
}


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def pin(path: Path) -> dict:
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def require_pin(path: Path, expected: dict) -> dict:
    actual = pin(path)
    if actual['bytes'] != expected.get('bytes') or actual['sha256'] != expected.get('sha256'):
        raise RuntimeError(f'input identity mismatch: {path}')
    return actual

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path, required=True, help='fresh output directory under this harness directory')
    args = ap.parse_args()
    out = args.out.resolve()
    if not out.is_relative_to(Path(__file__).resolve().parent) or out.exists():
        raise SystemExit('output must be a fresh child of this harness directory')
    if (ROOT / 'target').exists():
        raise SystemExit('fresh-target preflight failed: target must be absent')
    if shutil.disk_usage(ROOT).free < FREE_LIMIT:
        raise SystemExit('5 GiB free-space preflight failed')
    for p in (JAR, FAMILY_SOURCE, RUNNER_SOURCE, RESULTS, CLI, CLI_RECEIPT, HARNESS, GUARD_PATH, SCAN_PATH, JDK_MANIFEST, CLASS_ID_PINS):
        if not p.is_file():
            raise FileNotFoundError(p)

    class_id_pins = json.loads(CLASS_ID_PINS.read_text(encoding='utf-8'))
    if class_id_pins.get('classes') != [{'entry': name + '.class', **EXPECTED_CLASS_IDENTITIES[name]} for name in EXPECTED_CLASS_IDENTITIES]:
        raise RuntimeError('saved original class identity map differs from the reviewed pins')
    python_pin = pin(PYTHON)
    module_path = PYTHONLIB / 'blake3/__init__.py'
    native_path = PYTHONLIB / 'blake3/blake3.cpython-312-x86_64-linux-gnu.so'
    if pin(module_path)['sha256'] != class_id_pins['measurement']['blake3_module']['sha256'] or pin(native_path)['sha256'] != class_id_pins['measurement']['blake3_native_extension']['sha256']:
        raise RuntimeError('BLAKE3 module/native-extension pin mismatch')
    if python_pin['sha256'] != class_id_pins['measurement']['python']['sha256']:
        raise RuntimeError('bundled Python executable pin mismatch')
    results = json.loads(RESULTS.read_text(encoding='utf-8'))
    expected_stdout = results.get('expected_stdout')
    if expected_stdout != 'true:true:false:false\n':
        raise RuntimeError('pinned DT29 oracle does not contain the approved exact stdout')
    oracle = expected_stdout.encode('utf-8')
    harness_mod = load('dt29_full_source_binding', HARNESS)
    cli_binding = harness_mod.verify_cli(CLI, CLI_RECEIPT)
    receipt = json.loads(CLI_RECEIPT.read_text(encoding='utf-8'))
    source_manifest = receipt.get('source_manifest_before')
    if not isinstance(source_manifest, list) or source_manifest != receipt.get('source_manifest_after') or receipt.get('target_absent') is not True:
        raise RuntimeError('final CLI receipt lacks stable 4902 source pins and clean target')
    if len(source_manifest) != 4902:
        raise RuntimeError(f'final CLI receipt source count changed: {len(source_manifest)}')
    source_current = []
    for row in source_manifest:
        actual = pin(ROOT / row['path'])
        if actual['bytes'] != row['bytes'] or actual['sha256'] != row['sha256']:
            raise RuntimeError(f'current product source differs from frozen CLI receipt: {row["path"]}')
        source_current.append(actual)

    expected_inputs = {
        JAR: {'bytes': 1253, 'sha256': '31ec2e5d6b4fdac4fc4c910904c3b84dc92f64d54e83a1a81b41e57b41dad5c3'},
        FAMILY_SOURCE: {'bytes': 602, 'sha256': '93e484846a1db3077c8f89d71fd36be8eab367a7fa649c793b6d1e8284eaf59d'},
        RUNNER_SOURCE: {'bytes': 1453, 'sha256': '89fceed01e4dd24ff31fb676cf272bfbe86c6a2be0a5f0f91615211f0ab2cf7a'},
        RESULTS: {'bytes': 2165, 'sha256': '9e6fc588870e3a882ad515db15842e99f2228a890be5101c1520129447aeb024'},
    }
    fixture_pins = [require_pin(p, e) for p, e in expected_inputs.items()]
    manifest_pin = pin(JDK_MANIFEST)
    if manifest_pin['sha256'] != '5daeb9b6e864c3f28f62acc0b4c32bf61679546f6d7db077bd4171a6eafad6d6':
        raise RuntimeError('JDK tools manifest differs from the reviewed immutable pin')
    with zipfile.ZipFile(JAR) as jar_zip:
        physical_classes = sorted(info.filename for info in jar_zip.infolist() if info.filename.endswith('.class'))
    if physical_classes != sorted(name + '.class' for name in EXPECTED_CLASS_IDENTITIES):
        raise RuntimeError(f'DT29 input JAR physical class inventory changed: {physical_classes}')
    with zipfile.ZipFile(JAR) as jar_zip:
        for class_name, identity in EXPECTED_CLASS_IDENTITIES.items():
            class_bytes = jar_zip.read(class_name + '.class')
            measured = {'bytes': len(class_bytes), 'sha256': hashlib.sha256(class_bytes).hexdigest(), 'blake3': blake3.blake3(class_bytes).hexdigest()}
            if measured != identity:
                raise RuntimeError(f'original class byte identity mismatch for {class_name}: {measured}')
    jdk_doc = json.loads(JDK_MANIFEST.read_text(encoding='utf-8'))
    javac23 = next(row for row in jdk_doc['legs'] if row.get('leg') == 'javac23')['jdk_tools']
    jdk8 = next(row for row in jdk_doc['legs'] if row.get('leg') == 'javac8')['jdk_tools']
    tool_paths = {name: Path(javac23[name]['path']).resolve() for name in ('java', 'javac')}
    tool_paths['java8'] = Path(jdk8['java']['path']).resolve()
    tool_pins = {}
    for name, path in tool_paths.items():
        expected = javac23[name] if name in ('java', 'javac') else jdk8['java']
        tool_pins[name] = require_pin(path, expected)
    source_path = Path(__file__).resolve()
    inputs = sorted(set([source_path, JAR.resolve(), FAMILY_SOURCE.resolve(), RUNNER_SOURCE.resolve(), RESULTS.resolve(), CLASS_ID_PINS.resolve(), PYTHON.resolve(), module_path.resolve(), native_path.resolve(),
                         CLI.resolve(), CLI_RECEIPT.resolve(), HARNESS.resolve(), GUARD_PATH.resolve(), SCAN_PATH.resolve(), JDK_MANIFEST.resolve(),
                         *tool_paths.values(), *(ROOT / row['path'] for row in source_manifest)]))
    before = [pin(p) for p in inputs]

    out.mkdir(parents=True, exist_ok=False)
    src_dir = out / 'generated-java'
    original_runner_source = out / 'original-runner-source'
    original_runner_dir = out / 'original-runner-classes'
    rebuilt_dir = out / 'rebuilt-classes'
    for p in (src_dir, original_runner_source, original_runner_dir, rebuilt_dir):
        p.mkdir()
    runner_copy = original_runner_source / 'SamePackageParentRunner.java'
    shutil.copyfile(RUNNER_SOURCE, runner_copy)
    runner_copy_pin = pin(runner_copy)
    runner_original_pin = pin(RUNNER_SOURCE)
    if runner_copy_pin['bytes'] != runner_original_pin['bytes'] or runner_copy_pin['sha256'] != runner_original_pin['sha256']:
        raise RuntimeError('runner fixture copy is not byte-identical')

    guard = load('dt29_full_source_guard', GUARD_PATH)
    scanner = load('dt29_full_source_scan', SCAN_PATH)
    guard.ROOT = ROOT
    guard.OUT = out
    guard.FREE_LIMIT = FREE_LIMIT
    guard.TARGET_LIMIT = TARGET_LIMIT
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.expected_test_summaries = lambda _index, _data: None
    guard.command_stream = lambda path: pin(Path(path))
    guard.ENV_VALUES = {}
    base_env = {k: v for k, v in os.environ.items() if k in ('HOME', 'TMPDIR', 'LANG', 'LC_ALL')}
    for key in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'RUST_MIN_STACK', 'CARGO_TARGET_DIR'):
        base_env.pop(key, None)
    base_env['PATH'] = '/usr/bin:/bin'
    rows = []
    record = {
        'schema': 'neighbor-direct-parent-full-source-harness-v2',
        'status': 'running',
        'scope': 'DT29 fixed wide positive only: original three physical classes, three exact class-source reports, compile original Runner against original JAR, compile three reports plus the identical Runner without original JAR on classpath, run Java 23 and Java 8 on both outputs against the pinned oracle',
        'cli_binding': cli_binding, 'source_manifest_count': len(source_manifest),
        'source_manifest_sha256': hashlib.sha256(json.dumps(source_manifest, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        'fixture_pins': fixture_pins, 'class_identity_pins': pin(CLASS_ID_PINS), 'blake3_runtime': {'python': python_pin, 'module': pin(module_path), 'native_extension': pin(native_path), 'version': getattr(blake3, '__version__', 'unknown')}, 'original_physical_classes': physical_classes, 'oracle_stdout_utf8_hex': oracle.hex(),
        'jdk_manifest': manifest_pin, 'jdk_tool_pins': tool_pins,
        'guards': {'minimum_free_bytes': FREE_LIMIT, 'maximum_target_bytes': TARGET_LIMIT},
        'commands': rows,
    }
    def save():
        temp = out / 'execution.json.tmp'
        temp.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        temp.replace(out / 'execution.json')
    save()

    def run(index: int, label: str, argv: list[str], env: dict[str, str], expected_exit: int = 0) -> dict:
        row = guard.run_command(index, argv, env)
        row.update({'label': label, 'argv_exact': argv, 'cwd': str(ROOT), 'expected_exit': expected_exit,
                    'guard_status': 'stopped' if row.get('guard_stop') is not None else 'clear'})
        rows.append(row); save()
        if row.get('guard_stop') is not None:
            raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        if row.get('exit_code') != expected_exit:
            raise RuntimeError(f'{label} exit {row.get("exit_code")}, expected {expected_exit}; raw streams retained')
        return row

    try:
        class_names = list(EXPECTED_CLASS_IDENTITIES)
        for idx, class_name in enumerate(class_names, 1):
            argv = [str(CLI), 'class-source', '--input', str(JAR), '--class', class_name, '--format', 'json', '--evidence', 'all']
            row = run(idx, f'class-source-{class_name}', argv, base_env)
            stdout_path = Path(row['streams']['stdout']['path'])
            report_json = json.loads(stdout_path.read_text(encoding='utf-8'))
            if report_json.get('execution', {}).get('status') != 'complete':
                raise RuntimeError(f'{class_name} wide class-source is not complete')
            class_info = report_json.get('class', {})
            entry = class_info.get('location', {}).get('entry', {})
            raw_name = bytes(entry.get('raw_name', [])).decode('utf-8')
            digest = class_info.get('class_bytes', {}).get('digest')
            expected_entry = class_name + '.class'
            if raw_name != expected_entry or class_info.get('class_bytes', {}).get('length') != EXPECTED_CLASS_IDENTITIES[class_name]['bytes'] or digest != EXPECTED_CLASS_IDENTITIES[class_name]['blake3']:
                raise RuntimeError(f'{class_name} did not select the expected original physical class: {raw_name} / {digest}')
            source_text = report_json.get('text')
            if not isinstance(source_text, str):
                raise RuntimeError(f'{class_name} JSON report has no text string')
            source_path_out = src_dir / (class_name.rsplit('/', 1)[-1] + '.java')
            source_path_out.write_bytes(source_text.encode('utf-8'))
            row['report_status'] = report_json.get('outcome')
            row['selected_entry'] = raw_name
            row['selected_class_blake3'] = digest
            row['selected_class_length'] = class_info['class_bytes']['length']
            row['expected_class_sha256_verified_from_original_jar'] = EXPECTED_CLASS_IDENTITIES[class_name]['sha256']
            row['text_utf8_bytes'] = len(source_text.encode('utf-8'))
            row['saved_source_pin'] = pin(source_path_out)
            save()

        javac = tool_paths['javac']
        java23 = tool_paths['java']
        java8 = tool_paths['java8']
        row = run(4, 'javac23-release8-original-runner', [str(javac), '--release', '8', '-cp', str(JAR), '-d', str(original_runner_dir), str(runner_copy)], base_env)
        row['runner_copy_pin'] = runner_copy_pin; save()
        family_sources = [src_dir / (name.rsplit('/', 1)[-1] + '.java') for name in class_names]
        rebuilt_argv = [str(javac), '--release', '8', '-d', str(rebuilt_dir), *map(str, family_sources), str(RUNNER_SOURCE)]
        run(5, 'javac23-release8-rebuilt-family-and-runner-no-original-classpath', rebuilt_argv, base_env)
        # Runtime classpaths make the original-vs-rebuilt distinction explicit.
        original_cp = str(original_runner_dir) + os.pathsep + str(JAR)
        rebuilt_cp = str(rebuilt_dir)
        for idx, (label, java, cp) in enumerate((('java23-original', java23, original_cp), ('java23-rebuilt', java23, rebuilt_cp),
                                                  ('java8-original', java8, original_cp), ('java8-rebuilt', java8, rebuilt_cp)), 6):
            row = run(idx, label, [str(java), '-Xverify:all', '-cp', cp, 'dt29.SamePackageParentRunner'], base_env)
            stdout = Path(row['streams']['stdout']['path']).read_bytes()
            row['oracle_stdout_equal'] = stdout == oracle
            row['oracle_stdout_hex'] = stdout.hex()
            if stdout != oracle:
                raise RuntimeError(f'{label} stdout differs from pinned results.json oracle')
            if Path(row['streams']['stderr']['path']).stat().st_size != 0:
                row['stderr_empty'] = False
            else:
                row['stderr_empty'] = True
            save()
        record['status'] = 'captured_wide_positive_all_four_runtimes_match_oracle_pending_independent_review'
    except BaseException as exc:
        record['status'] = 'capture_failed'
        record['error'] = f'{type(exc).__name__}: {exc}'
    finally:
        after = [pin(p) for p in inputs]
        record['input_manifest_before'] = before
        record['input_manifest_after'] = after
        record['inputs_identical'] = before == after
        record['current_source_matches_frozen_receipt'] = all(
            pin(ROOT / row['path'])['bytes'] == row['bytes'] and pin(ROOT / row['path'])['sha256'] == row['sha256']
            for row in source_manifest)
        record['source_manifest_current_count'] = len(source_current)
        record['generated_runner_copy'] = runner_copy_pin
        record['generated_source_files'] = [pin(p) for p in sorted(src_dir.glob('*.java'))]
        class_outputs = []
        for folder in (original_runner_dir, rebuilt_dir):
            class_outputs.extend(pin(p) for p in sorted(folder.rglob('*.class')))
        record['generated_class_files'] = class_outputs
        record['target_absent'] = not (ROOT / 'target').exists()
        record['free_bytes_after'] = shutil.disk_usage(ROOT).free
        if not record['inputs_identical'] or not record['target_absent'] or not record['current_source_matches_frozen_receipt']:
            record['status'] = 'capture_failed_integrity_or_cleanup'
        save()
    return 0 if record['status'] == 'captured_wide_positive_all_four_runtimes_match_oracle_pending_independent_review' and len(rows) == 9 else 1

if __name__ == '__main__':
    raise SystemExit(main())
