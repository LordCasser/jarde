#!/usr/bin/env python3
"""Create and verify a future evidence tar from the frozen allowlist.

This script is intentionally not run during candidate preparation. It refuses to
write unless --out names a not-yet-existing file below a fresh directory.
"""
from __future__ import annotations
import argparse, hashlib, json, os, tarfile, tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ALLOW_PATH = HERE / 'allowlist.json'

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True, help='new tar path under a fresh output directory')
    ns = ap.parse_args()
    allow = json.loads(ALLOW_PATH.read_text(encoding='utf-8'))
    if allow.get('status') != 'prepared_only_package_not_created':
        raise SystemExit('allowlist status is not the expected prepared state')
    rows = allow['items']
    by_path = {r['original_path']: r for r in rows}
    if len(by_path) != len(rows):
        raise SystemExit('duplicate original paths in allowlist')
    if len({r['archive_path'] for r in rows}) != len(rows):
        raise SystemExit('duplicate archive paths in allowlist')
    # Validate every pinned source byte and ensure no source is a symlink.
    payload: dict[str, bytes] = {}
    for row in rows:
        src = Path(row['original_path'])
        if src.is_symlink() or not src.is_file():
            raise SystemExit(f'not a regular file: {src}')
        data = src.read_bytes()
        if len(data) != row['bytes'] or sha(data) != row['sha256']:
            raise SystemExit(f'allowlist pin mismatch: {src}')
        payload[row['archive_path']] = data
    # Re-open every included receipt and independently bind every .raw to a stream.
    bound: dict[str, tuple[int, str]] = {}
    for receipt_ref in allow['receipts']:
        rp = Path(receipt_ref['path'])
        rr = by_path.get(str(rp.resolve()))
        if rr is None or rr['archive_path'] != receipt_ref['archive_path']:
            raise SystemExit(f'receipt not included at pinned path: {rp}')
        obj = json.loads(rp.read_text(encoding='utf-8'))
        if obj.get('status') != receipt_ref['status'] or len(obj.get('commands', [])) != receipt_ref['commands']:
            raise SystemExit(f'receipt contract changed: {rp}')
        streams = []
        for cmd in obj['commands']:
            streams.extend(cmd.get('streams', {}).values())
        streams.extend(obj.get('inferior_streams', {}).values())
        for stream in streams:
            p = str(Path(stream['path']).resolve())
            if p in bound:
                raise SystemExit(f'duplicate receipt stream reference: {p}')
            bound[p] = (stream['bytes'], stream['sha256'])
            if p not in by_path:
                raise SystemExit(f'receipt stream missing from allowlist: {p}')
            data = Path(p).read_bytes()
            if len(data) != stream['bytes'] or sha(data) != stream['sha256']:
                raise SystemExit(f'receipt stream hash mismatch: {p}')
    raw_paths = {p for p in by_path if p.endswith('.raw')}
    if raw_paths != set(bound):
        raise SystemExit('some raw file is unbound or receipt stream is omitted')
    if len(bound) != allow['raw_file_count']:
        raise SystemExit('receipt-bound raw count differs from allowlist')
    out = Path(ns.out).expanduser().resolve()
    if out.exists() or not out.parent.is_dir():
        raise SystemExit('output must be a new file inside an existing fresh output directory')
    if not out.parent.resolve().is_relative_to(HERE.resolve()):
        raise SystemExit('output directory must be below this packager directory')
    if any(out.parent.iterdir()):
        raise SystemExit('output directory must be empty')
    manifest = {
        'schema': 'direct-parent-proof-evidence-package-v1',
        'status': 'packaged_and_reopened_verified',
        'allowlist_sha256': sha(ALLOW_PATH.read_bytes()),
        'item_count': len(rows), 'raw_receipt_bound_count': len(bound),
        'total_payload_bytes': sum(r['bytes'] for r in rows),
        'items': rows,
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    # Use deterministic tar metadata and preserve only payload bytes, never modes/executables.
    with tarfile.open(out, 'w:gz', format=tarfile.PAX_FORMAT) as tf:
        for arc, data in sorted(payload.items()):
            ti = tarfile.TarInfo(arc)
            ti.size, ti.mode, ti.mtime = len(data), 0o444, 0
            ti.uid = ti.gid = 0
            ti.uname = ti.gname = ''
            import io
            tf.addfile(ti, io.BytesIO(data))
        ti = tarfile.TarInfo('package-manifest.json')
        ti.size, ti.mode, ti.mtime = len(manifest_bytes), 0o444, 0
        ti.uid = ti.gid = 0
        ti.uname = ti.gname = ''
        import io
        tf.addfile(ti, io.BytesIO(manifest_bytes))
    # Reopen and compare each payload byte-for-byte, plus the embedded manifest.
    with tarfile.open(out, 'r:gz') as tf:
        members = {m.name: m for m in tf.getmembers() if m.isfile()}
        expected_names = set(payload) | {'package-manifest.json'}
        if set(members) != expected_names:
            raise SystemExit('archive member set mismatch')
        for arc, expected in payload.items():
            actual = tf.extractfile(members[arc]).read()
            if actual != expected or sha(actual) != next(r['sha256'] for r in rows if r['archive_path'] == arc):
                raise SystemExit(f'archive byte verification failed: {arc}')
        embedded = tf.extractfile(members['package-manifest.json']).read()
        if embedded != manifest_bytes:
            raise SystemExit('embedded package manifest mismatch')
    print(json.dumps({'status':'packaged_and_reopened_verified','archive':str(out),
                      'archive_sha256':sha(out.read_bytes()),'items':len(rows),
                      'raw_files':len(bound),'archive_bytes':out.stat().st_size},indent=2))

if __name__ == '__main__':
    main()
