import argparse,hashlib,importlib.util,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
ap=argparse.ArgumentParser();ap.add_argument('--receipt',type=Path,required=True);ap.add_argument('--cli-sha256',required=True);a=ap.parse_args();d=json.loads(a.receipt.read_text())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(p):assert pin(p['path'])==p
# Only usage accounting may differ. Limits (including elapsed_millis), statuses, diagnostics,
# identities, evidence, whole/projected/raw text, maps and all remaining JSON are exact.
def without_usage(x):
 if isinstance(x,dict):return {k:without_usage(v) for k,v in x.items() if k!='usage'}
 if isinstance(x,list):return [without_usage(v) for v in x]
 return x
assert d['status']=='captured-pending-independent-replay-review' and d['default_stack'] and d['source_unchanged'] and d['protected_unchanged'] and d['target_absent'] and not (ROOT/'target').exists() and not (ROOT/'target').is_symlink()
assert d['source_before']==d['source_after'] and d['protected_before']==d['protected_after'] and d['cli']==d['cli_after'] and d['cli']['sha256']==a.cli_sha256
for p in [d['runner'],d['cli'],*d['tools'],*d['source_after'],*d['protected_after']]:check(p)
compare=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py';s=importlib.util.spec_from_file_location('replay_review_compare',compare);cmp=importlib.util.module_from_spec(s);s.loader.exec_module(cmp);assert cmp.source_closure(ROOT)==d['source_after']
assert len(d['commands'])==len(d['cells'])==20
rows=[]
for c,row in zip(d['cells'],d['commands']):
 assert c['command']==row['index'] and row['exit_code']==0 and row['guard_stop'] is None and row['free_bytes_after']>=5*1024**3 and row['peak_target_bytes']<=2**30
 for p in [*row['streams'].values(),c['old_report'],c['report'],c['whole_source']]:check(p)
 old=json.loads(Path(c['old_report']['path']).read_text());new=json.loads(Path(c['report']['path']).read_text());assert Path(c['report']['path']).read_bytes()==Path(row['streams']['stdout']['path']).read_bytes()
 assert without_usage(old)==without_usage(new),c['selectors']
 assert old['text']==new['text']==Path(c['whole_source']['path']).read_text()
 for x,y in zip(old['methods'],new['methods']):
  assert x['text']==y['text'] and x['item']==y['item'];ar=x['outcome']['report'];br=y['outcome']['report'];assert all(ar.get(k)==br.get(k) for k in ('text','source_map','quality','fallbacks'))
 rows.append({'family':c['family'],'selectors':c['selectors'],'all_non_usage_json_exact':True,'complete_java_exact':True,'all_methods_and_raw_maps_exact':True,'method_count':len(new['methods'])})
assert sum(r['family']=='original' for r in rows)==8 and sum(r['family']=='controls' for r in rows)==12
r={'status':'root-independent-api-replay-accepted','receipt':pin(a.receipt),'cli':d['cli'],'rows':rows,'source_files':len(d['source_after']),'commands':20,'raw_streams':40,'runtime_witness_binding':'Complete unchanged Java and physical inputs bind to original final generated matrix 1d171a5a... (36 JVM/288case) and controls final dc8fd91c... (48 Jarde JVM/912case). No JDK compilation/execution rerun in this replay. Preserved old JADX compile failures and CodeSource negatives remain as recorded.'}
a.receipt.with_name('root-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(r['status'],len(rows))
