# Read-only review: hardened API replay preparation

Reviewed `/private/tmp/jarde-typed-foreach-hardened-api-replay-prep-root-v1-20261018/replay.py` without executing it.

## Blocking issue

The replay dynamically imports repository scripts at lines 11–12 with `SourceFileLoader`, but it neither sets `sys.dont_write_bytecode = True` nor invokes Python in a mode that suppresses bytecode writes. A normal run can create/update `__pycache__/*.pyc` beside `compare.py`, the guard, or scanner under the shared repository, contrary to the read-only/no-shared-writes constraint. The closure pin helper also excludes `__pycache__`, so such writes would not be caught by the before/after source comparison. Before replay, suppress bytecode generation before the first dynamic import (e.g. import `sys`, then set `sys.dont_write_bytecode = True`).

## Cleanup edge

The finalizer at line 53 records `target_absent` using only `not target.exists()`. A dangling symlink at `ROOT/target` has `exists() == False`, so it can be recorded as absent. Preflight already checks both `exists()` and `is_symlink()` at line 17. Make the final invariant symmetrical: require both false, and persist that exact result.

The intended exact replay comparator is not part of this preparation script; its stated separate role remains necessary to establish non-usage JSON and all whole/projected/raw text and source-map equality. I did not run the replay, CLI, collector, native tests, or any toolchain.
