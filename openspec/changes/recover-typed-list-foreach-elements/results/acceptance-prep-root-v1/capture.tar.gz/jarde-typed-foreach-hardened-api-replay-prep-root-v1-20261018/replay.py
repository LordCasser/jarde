import argparse,datetime,hashlib,importlib.util,json,os,shutil
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
INPUTS={
'original':(Path('/private/tmp/jarde-typed-foreach-original-final-root-v1-20261018/execution.json'),'433b6a723137adb4aed904b2c7935079821def5b1b91f1593630c224bc73f439',8),
'controls':(Path('/private/tmp/jarde-typed-foreach-controls-final-root-v1-20261018/execution.json'),'dc8fd91c60d95d1d26d630d2bf8ba57b8ab54b9f58ed6582160286a4c9b4cc3a',12)}
WITNESS=Path('/private/tmp/jarde-typed-foreach-original-generated-final-root-v1-20261018/execution.json')
COMPARE=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
GUARD=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
def module(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(p):assert pin(p['path'])==p
ap=argparse.ArgumentParser();ap.add_argument('--cli',type=Path,required=True);ap.add_argument('--cli-sha256',required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();out=a.out.resolve();cli=a.cli.resolve()
assert not out.exists() and not (ROOT/'target').exists() and not (ROOT/'target').is_symlink() and shutil.disk_usage(ROOT).free>=5*1024**3
assert pin(COMPARE)['sha256']=='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
assert pin(GUARD)['sha256']=='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
assert pin(SCANNER)['sha256']=='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
cmp=module(COMPARE,'typed_replay_compare');g=module(GUARD,'typed_replay_guard');s=module(SCANNER,'typed_replay_scanner')
protected={};inputs={}
def protect_tree(x):
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=x.keys():
   check(x);old=protected.setdefault(x['path'],x);assert old==x
  else:
   for k,v in x.items():
    if not (k.startswith('source_pins_') or k in ('source_before','source_after','source_after_finally')):protect_tree(v)
 elif isinstance(x,list):
  for v in x:protect_tree(v)
for family,(path,h,count) in INPUTS.items():
 assert pin(path)['sha256']==h;d=json.loads(path.read_text());assert len(d['jarde_cells'])==count;protect_tree(d);protected[str(path)]=pin(path);inputs[family]=d
assert pin(WITNESS)['sha256']=='1d171a5ad5a3ef83fd72bde289ae67977ae9fe0cf36a622c9b4e576dbf8d1149';protect_tree(json.loads(WITNESS.read_text()));protected[str(WITNESS)]=pin(WITNESS)
assert pin(cli)['sha256']==a.cli_sha256
out.mkdir();(out/'raw').mkdir();g.ROOT=ROOT;g.OUT=out/'raw';g.target_bytes=lambda:s.target_bytes(ROOT);g.command_stream=pin;g.expected_test_summaries=lambda i,b:None
env=cmp.clean_env({k:v for k,v in os.environ.items() if k not in ('RUST_MIN_STACK','CARGO_TARGET_DIR','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH')});env.update(g.ENV_VALUES)
r={'status':'running','runner':pin(__file__),'cli':pin(cli),'tools':[pin(p) for p in (COMPARE,GUARD,SCANNER)],'source_before':cmp.source_closure(ROOT),'protected_before':list(protected.values()),'commands':[],'cells':[],'default_stack':True,'runtime_scope':'API replay only; no JDK compilation or execution rerun. Prior complete matrix reusable only if exact generated whole/projected/raw text and all non-usage JSON remain identical.'}
def save():(out/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
try:
 for family,d in inputs.items():
  commands={c['index']:c for c in d['commands']}
  for cell in d['jarde_cells']:
   old=commands[cell['command']];argv=list(old['argv']);assert Path(argv[0]).resolve()==Path(d['cli']['path']).resolve() and argv[1]=='class-source';argv[0]=str(cli)
   row=g.run_command(len(r['commands'])+1,argv,env);r['commands'].append(row);save();assert row['exit_code']==0 and row['guard_stop'] is None
   raw=Path(row['streams']['stdout']['path']).read_bytes();doc=json.loads(raw);assert isinstance(doc.get('text'),str) and doc['execution']['status']=='complete'
   dst=out/f"{family}-{row['index']:02d}.json";dst.write_bytes(raw);src=out/f"{family}-{row['index']:02d}.java";src.write_text(doc['text'])
   r['cells'].append({'family':family,'old_command':cell['command'],'command':row['index'],'old_report':cell['report'],'report':pin(dst),'whole_source':pin(src),'selectors':{k:cell[k] for k in ('profile','evidence','input_form') if k in cell}});save()
 r['status']='captured-pending-independent-replay-review'
except BaseException as e:r.update(status='failed',error=repr(e));raise
finally:
 r['source_after']=cmp.source_closure(ROOT);r['protected_after']=[pin(x['path']) for x in protected.values()];r['cli_after']=pin(cli);r['target_absent']=not (ROOT/'target').exists();r['source_unchanged']=r['source_before']==r['source_after'];r['protected_unchanged']=r['protected_before']==r['protected_after'];r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
assert r['source_unchanged'] and r['protected_unchanged'] and r['cli']==r['cli_after'] and r['target_absent'];print(r['status'],len(r['commands']))
