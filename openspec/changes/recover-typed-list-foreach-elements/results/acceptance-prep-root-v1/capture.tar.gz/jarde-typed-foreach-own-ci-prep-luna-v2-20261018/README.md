# Typed foreach own-product CI collector and verifier prep

Prepared by adapting the accepted statementful-loop own-CI tools. No network/Git/Cargo/JDK/CLI command was run, and no repository file was changed. Root supplies the final run ID and product SHA after the product CI run exists.

Files:
- `collect-own-ci.py`: reuses the reviewed raw CI/source capture flow; requires fresh OUT_DIR, RUN_ID, PRODUCT_SHA.
- `verify-own-ci.py`: reuses the reviewed read-only acceptance logic, with matching source/fixture contract and exact typed-foreach test identities.
- `missing_step_proof.py`: copied byte-for-byte from the reviewed v3 helper. It is invoked only if an expected per-step member is actually absent from the official ZIP. The verifier's step-log summary now derives the number/names of reconstructed steps from observed proofs and correctly says none were reconstructed when all per-step members exist.
- `collector.diff`, `verifier.diff`: changes against the reviewed input scripts. `pins.json`: input/output SHA256 and exact source/fixture/gate contract.

The source pin set is the requested workflow/manifests, facade/class source, Java report/build, reader classfile parser, both public test targets and fixture corpus fingerprint. The only fixture root is `tests/fixtures/typed-list-foreach`; exactly its README, class, and Java source are required. Both scripts declare identical paths and fixture inventory.

The verifier retains the inherited 41 exact gates and adds nine typed-foreach identities: three `report::generic_call_ast_projection_tests::typed_foreach_*` unit tests, public positive + typed-only coverage, late deadline transaction, neighboring refusal, and nested-iterator positive/late budget-pre-cancel/adjacent-refusal regressions. It asserts 41 preserved gates + exactly 9 new gates = 50, and checks the new set in both workflow seed runs. The previous `CURRENT_CRITICAL_COUNT = 21` pin is removed.

This is prepared evidence tooling only, not a collection receipt or an acceptance result.
