Native typed-foreach acceptance wrapper v2 (prepared, not executed)

This is a fresh correction of v1. Three `jarde_java` gate names now use the exact full Rust test names observed in focused-v5 raw stdout. The two integration target names were checked against broad-v1 raw stdout. Across those two pinned existing raw files, each of the five intended gates occurs exactly once with status `ok`.

Evidence:
- focused-v5: `/private/tmp/jarde-typed-foreach-focused-root-v5-20261018/raw/2.stdout.raw`
- broad-v1: `/private/tmp/jarde-typed-foreach-broad-root-v1-20261018/raw/6.stdout.raw`
- verifier SHA256: `8db2bd8d5faf927dec5aa1572a55f55a8cc9d27be585e317b0847c6d93eaf993`

The wrapper delegates to the existing checker and retains its metadata-derived inventory and Running-bound per-target count checks, 385-target prior baseline comparison, source pin equality, two distinct receipt requirement, and exact gate inventory check. It has not been executed and does not constitute product acceptance.
