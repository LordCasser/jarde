# Typed foreach native-workspace acceptance preparation

This is an unexecuted, read-only wrapper around the existing statementful-loop `verify_workspace.py`. It reuses its dynamic Cargo-metadata inventory and batch reconstruction, raw stream pin checks, compiler-artifact identity mapping, stderr `Running` order, per-target harness counts, seed comparison, source/guard/JDK checks, default child stack policy, 5 GiB free-space and 1 GiB target limits, cleanup, and final target absence. It does not trust the legacy serialized table as the per-target count authority; the inherited checker separately reconstructs and reports that table.

The five exact gates are:

- `jarde_java`: `typed_foreach_projection_unwraps_only_the_binding_and_preserves_origins`
- `jarde_java`: `typed_foreach_refuses_mismatched_or_foreign_site_plans_without_mutation`
- `jarde_java`: `typed_foreach_traversal_reaches_try_and_switch_bodies_and_stops_atomically`
- `structured_list_generic_bodies`: `typed_list_foreach_element_heads_preserve_bindings_and_raw_origins`
- `structured_list_generic_bodies`: `typed_foreach_late_deadline_keeps_raw_artifact_without_partial_projection`

The three `jarde_java` unit gates cover: unwrapping only the proven element binding while preserving origins; refusing mismatched BCI/type/header/foreign-method/duplicate site plans without mutation; and traversal through try/switch bodies with budget, cancellation, and elapsed-deadline stops remaining atomic. The integration gate checks default/all/essential whole and method text agreement, typed String/Integer foreach heads and binding preservation, complete physical raw origins, and unchanged raw casts. The late-deadline gate delays the observed commit boundary, requires an elapsed-budget partial report with no strings projection, and compares its retained raw text/map against a complete report.

The checker derives target identities, target totals, test totals, and each target's counts from both receipts. It retains 385 only as the prior native target-count baseline and requires the metadata-derived count to match it; the aggregate passing-test total is not hard-coded. The tool has not been run. After both fresh receipts are terminal, use `python3 -B verify_typed_foreach.py <seed1-dir-or-execution.json> <seed2-dir-or-execution.json> --output <new-private-report.json>`.
