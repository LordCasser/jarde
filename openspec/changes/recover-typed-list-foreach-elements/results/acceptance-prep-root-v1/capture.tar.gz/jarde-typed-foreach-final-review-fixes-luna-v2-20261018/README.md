# Private v2 review fixes

Patch: `task-review-fixes-v2.patch` (baseline is the current shared candidate copied read-only into `base/`). No shared workspace files were changed; no compiler, formatter, tests, Git mutation, JDK, CLI, or network tools were run.

The patch addresses the three read-only review findings:

1. In `src/facade.rs`, reject any explicit foreign method on primary or derived origins of the first binding and cast, while retaining `None` as the unbound same-AST case. In `crates/jarde-java/src/report.rs`, enforce the same rule for the foreach header, first binding, and cast at application time. Extend the existing AST-only refusal test with foreign-derived-only cast, binding, and header mutations.
2. Before final staged-vs-recomputed plan equality, charge traversal of every expected owner identity step and poll each step. The comparison byte bound includes method name/descriptor; snapshot and root container; every step's archive-name and child-container bytes; entry raw name; class digest; Other variant label; and fixed identity structures.
3. Remove the added `program_node_count` pre-scan from the new traversal charge. Each statement in `apply_foreach_edits` now charges one AnalysisStep through `charge_class_source_metadata` (which also polls) before examining or mutating it; origin-merge work remains prepaid.

Source pins: proof and type joins `src/facade.rs:13055-13312`; staged and final revalidation `src/facade.rs:16719-17131,17231-17380`; edit transaction and visitor `crates/jarde-java/src/report.rs:3042-3474`; foreach inventory `crates/jarde-java/src/report.rs:3770-3980`; identity fields `crates/jarde-reader/src/model.rs:4-10,172-193,203-232,275-303,337-341`.
