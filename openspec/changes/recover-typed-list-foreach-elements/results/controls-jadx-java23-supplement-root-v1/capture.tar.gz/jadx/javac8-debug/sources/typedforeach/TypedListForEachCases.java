package typedforeach;

import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: javac8-debug.jar:typedforeach/TypedListForEachCases.class */
public class TypedListForEachCases {
    public static Object seen;
    public static Object after;

    public static void strings(List<String> values) {
        String current = "before";
        seen = current;
        Iterator<String> it = values.iterator();
        while (it.hasNext()) {
            current = it.next();
            seen = current;
        }
        after = current;
    }

    public static void integers(List<Integer> values) {
        Integer current = null;
        seen = null;
        Iterator<Integer> it = values.iterator();
        while (it.hasNext()) {
            current = it.next();
            seen = current;
        }
        after = current;
    }

    public static void raw(List values) {
        String current = "before";
        seen = current;
        Iterator raw = values.iterator();
        while (raw.hasNext()) {
            current = (String) raw.next();
            seen = current;
        }
        after = current;
    }

    public static void mismatch(List<String> values) {
        Integer current = null;
        seen = null;
        Iterator<String> it = values.iterator();
        while (it.hasNext()) {
            current = (Integer) it.next();
            seen = current;
        }
        after = current;
    }

    public static void declared(List<String> values) {
        for (String value : values) {
            seen = value;
        }
    }
}
