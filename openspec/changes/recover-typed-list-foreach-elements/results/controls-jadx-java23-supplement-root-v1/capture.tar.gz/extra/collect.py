import importlib.util,json,os,shutil,sys,hashlib,datetime
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
MODULE=Path('/private/tmp/jarde-typed-foreach-controls-collector-root-v3-20261018/collect_controls.py')
BASE=Path('/private/tmp/jarde-typed-foreach-controls-baseline-root-v1-20261018/execution.json')
OUT=Path(sys.argv[1]).resolve()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
if hashlib.sha256(MODULE.read_bytes()).hexdigest()!='0788e3e475d040409ba0333476bcf65b7f2ced8a1ea974fe90c0d82e032b4fd9': raise RuntimeError('module changed')
m=load(MODULE,'control');c=m.load(ROOT/m.COMPARE,'compare');g=m.load(ROOT/m.GUARD,'guard');sc=m.load(ROOT/m.SCANNER,'scanner');ph=m.load(m.PARSER,'physical')
for p,h in ((ROOT/m.COMPARE,m.CH),(ROOT/m.GUARD,m.GH),(ROOT/m.SCANNER,m.SH),(ROOT/m.MANIFEST,m.MH),(m.PARSER,m.PH)):
 if m.sha(p)!=h: raise RuntimeError('tool changed')
b=json.loads(BASE.read_text());jdks,jrec=c.configured_jdks(ROOT/m.MANIFEST,m.MH)
if b['status']!='captured-pending-review' or not b['source_unchanged_finally']: raise RuntimeError('prior capture incomplete')
if OUT.exists() or (ROOT/'target').exists() or shutil.disk_usage(ROOT).free<5*1024**3: raise RuntimeError('output/target/free guard')
OUT.mkdir();(OUT/'raw').mkdir();empty=OUT/'empty';empty.mkdir()
g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:sc.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,x:None
source=c.source_closure(ROOT);inputs=[BASE,MODULE,Path(__file__),ROOT/m.COMPARE,ROOT/m.GUARD,ROOT/m.SCANNER,ROOT/m.MANIFEST,m.PARSER]
# Pin actual JADX executable and jar through the accepted original-baseline tool reference.
old=json.loads(m.BASE.read_text());jadx=Path(old['jadx']['path']);inputs += [jadx,Path(old['jadx_jar']['path'])]
for spec in jdks.values(): inputs += [Path(x) for x in spec['tools'].values()]
for x in b['source_profiles']:
 if x['profile'].startswith('javac8'):
  inputs += [Path(p['path']) for p in x['class_tree'].values()]
for p in inputs:
 if not p.is_file(): raise RuntimeError('missing input')
pins=[c.pin(p) for p in inputs];products={};r={'schema':'typed-foreach-jadx-java23-launch-supplement-v1','status':'running','baseline':c.pin(BASE),'collector':c.pin(Path(__file__)),'source_before':source,'input_pins_before':pins,'jdk_manifest':jrec,'commands':[],'jadx_cells':[],'compiles':[],'runs':[],'wrong_root':[]}
def save(): c.write_json(OUT/'execution.json',r)
def cmd(argv,label,leg):
 env=c.clean_env(dict(os.environ),jdks[leg]);env.update(g.ENV_VALUES);env.pop('RUST_MIN_STACK',None)
 row=g.run_command(len(r['commands'])+1,list(map(str,argv)),env);row['label']=label;row['tool_leg']=leg;r['commands'].append(row);save()
 if row['guard_stop'] is not None: raise RuntimeError('guard stopped')
 return row
try:
 for x in b['source_profiles']:
  prof=x['profile']
  if not prof.startswith('javac8'): continue
  rootcls=Path(x['class_root']);jar=OUT/(prof+'.jar')
  with m.zipfile.ZipFile(jar,'w',m.zipfile.ZIP_DEFLATED) as z:
   for rel,p in x['class_tree'].items():
    if c.pin(Path(p['path']))!=p: raise RuntimeError('original class changed')
    z.write(p['path'],rel)
  dest=OUT/'jadx'/prof;row=cmd([jadx,'--threads-count','1','--no-res','--config','none','-d',dest,jar],'jadx-'+prof,'javac23')
  srcs=sorted(dest.rglob('*.java'));r['jadx_cells'].append({'profile':prof,'command':row['index'],'exit_code':row['exit_code'],'input':c.pin(jar),'sources':[c.pin(p) for p in srcs]});save()
  if row['exit_code']!=0 or not srcs: raise RuntimeError('JADX Java23 launch failed')
  for leg in m.LEGS:
   srcroot=OUT/'sources'/prof/leg;srcroot.mkdir(parents=True);copies=[]
   for p in srcs:
    data=p.read_bytes();match=m.re.search(rb'^\s*package\s+([A-Za-z0-9_.]+)\s*;',data,m.re.M);pkg=match.group(1).decode().replace('.','/') if match else ''
    q=srcroot/pkg/p.name;q.parent.mkdir(parents=True,exist_ok=True)
    if q.exists(): raise RuntimeError('duplicate source')
    q.write_bytes(data);copies.append({'source':c.pin(p),'copy':c.pin(q)})
   cls=OUT/'classes'/prof/leg;cls.mkdir(parents=True);flags=['-source','8','-target','8'] if leg=='javac8' else ['--release','8'];debug='-g:none' if prof.endswith('no-debug') else '-g'
   row=cmd([jdks[leg]['tools']['javac'],*flags,debug,'-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',cls,*sorted(srcroot.rglob('*.java'))],'compile-'+prof+'-'+leg,leg)
   cr={'profile':prof,'leg':leg,'command':row['index'],'exit_code':row['exit_code'],'source_copies':copies,'class_tree':{p.relative_to(cls).as_posix():c.pin(p) for p in cls.rglob('*.class')}};r['compiles'].append(cr);save()
   if row['exit_code']==0: raise RuntimeError('unexpected successful compile requires explicit runtime expansion')
 r['status']='captured-pending-independent-review'
except BaseException as e:
 r['status']='failed';r['error']=repr(e);raise
finally:
 products={str(p):c.pin(p) for p in OUT.rglob('*') if p.is_file() and p.name!='execution.json'}
 r['product_pins']=products;r['source_after']=c.source_closure(ROOT);r['input_pins_after']=[c.pin(p) for p in inputs];r['target_absent']=not (ROOT/'target').exists();r['closure_unchanged']=r['source_after']==source and r['input_pins_after']==pins
 if not r['closure_unchanged'] or not r['target_absent']:r['status']='failed'
 r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
