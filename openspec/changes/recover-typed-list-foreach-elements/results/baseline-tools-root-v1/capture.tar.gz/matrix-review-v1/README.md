# TestNestedLoops generated matrix independent review (preparation)

This read-only reviewer has not been executed. Invoke it with explicit `--matrix`, `--matrix-sha256`, `--baseline`, `--baseline-sha256`, and a fresh `--out`. It checks the matrix receipt is bound to exactly that baseline receipt. The completed inputs currently available are:

- matrix: `/private/tmp/jarde-testnestedloops-current-generated-matrix-root-v1-20261018/execution.json`, SHA-256 `46d5ff4f12d339d6fc2ddf9df963a256e25421b9f7c2b06eeec0cf5e08288012`
- baseline: `/private/tmp/jarde-testnestedloops-current-baseline-root-v1-20261018/execution.json`, SHA-256 `4f48e3b14738cb4d3746763290788f525bba4bb1a1a3d47aebcf0111e6f8d482`

Example invocation:

```sh
python3 -B /private/tmp/jarde-testnestedloops-current-generated-matrix-review-prep-luna-v1-20261018/review_matrix.py \
  --matrix /private/tmp/jarde-testnestedloops-current-generated-matrix-root-v1-20261018/execution.json \
  --matrix-sha256 46d5ff4f12d339d6fc2ddf9df963a256e25421b9f7c2b06eeec0cf5e08288012 \
  --baseline /private/tmp/jarde-testnestedloops-current-baseline-root-v1-20261018/execution.json \
  --baseline-sha256 4f48e3b14738cb4d3746763290788f525bba4bb1a1a3d47aebcf0111e6f8d482 \
  --out /private/tmp/jarde-testnestedloops-current-generated-matrix-review-root-v1-20261018
```

The reviewer reopens and SHA/byte-checks every command stream, reparses the four original profile/JVM oracle streams, verifies the 8 Jarde + 2 JADX source grid and byte-identical full-source copies, then independently parses all class files from every successful compile with the pinned compare parser and physical classfile parser. The driver uses modified UTF-8 literals, so its three class files are checked by byte pin plus the narrow `compare.parse_class` summary rather than the strict full parser.

For successful compiles it verifies both JVM runs against the corresponding original profile/runtime raw oracle, the driver-only application classpath and the real loaded-target/expected-CodeSource argv. For failed compiles it requires the observed Java 55-to-52 diagnostic and no runtime or wrong-root rows. It also rechecks each successful compilation's wrong-CodeSource control, all before/after/finally closure snapshots, generated Java copies, driver classes, and compiler output class trees. Reported totals are derived from traversed records rather than trusted from the collector's summary fields.

Preparation used Python `-B` and `ast.parse` only. No compiler, JVM, CLI, JADX, Cargo, Git, or network command was run. The reviewer produces a report only after all checks succeed; it does not modify the matrix receipt or its raw evidence.
