# Typed List foreach OpenSpec: focused adversarial review

Date: 2026-10-18. Static review only; no implementation or toolchain. The change is architecturally feasible within the existing generic-list transaction and opaque `ForEach` projection. I found two implementation obligations that must be explicit before calling the contract closed: the exact element type must enter the existing Signature proof, and the staged/final transaction must include the site-specific foreach edit (not merely the current per-slot type vector).

## Evidence and decision

The four new artifacts consistently keep this as a typed-header-only source overlay, preserve synthetic/header and body bindings, and disclaim broader original-name cleanup. That matches the existing path. In the current facade, `prove_generic_list_parameter_body` (`src/facade.rs:13041`; its iterator branch at `13232-13246`) proves a direct formal-backed List iterator is the source of one retained foreach, but the branch just `continue`s after matching the iterable anchor. It currently contributes no actual cast type and no foreach edit identity. The current return/staging value is `(proved_list_parameters, presentation_removals)` (`13049-13053`); it is stored at `16429-16455`/`16822` and the final closure re-runs the function and compares only `final_list_parameter_types` to `staged_list_parameter_proofs` (`16948-16965`). Thus neither the new head type nor the selected `ForEach/cast` site is currently in that equality check.

The required Signature type join can reuse the existing check rather than introduce a second parser or type solver. The existing helper records a source cast/declaration `Type`, and `ordinary_parameterized_declaration` compares nonempty per-slot actual types against the parsed exact `List<E>` spelling (`src/class_source.rs:7195-7525`). Extend the iterator/foreach branch to contribute each exactly joined body-cast type to that same per-slot actual-type evidence. Then use that `Type` for `ForEach.ty` only after `project_method_signature_with_state` succeeds on that evidence (`src/facade.rs:16747-16755`). The empty `actual_types` case now allowed for a List slot is not cast evidence; a typed edit must not use it as authorization.

This is sound only if the body cast type is joined by exact identity to the physical cast and store: the same retained method AST, foreach statement BCI, direct iterable formal read BCI, first body binding BCI, cast-value BCI, and local write BCI. The existing `iterable_for_each_candidate` already proves the Iterator shape, single consumer/store, and equal exception-handler sets, and creates the Object foreach while retaining the body binding (`crates/jarde-java/src/build.rs:23216-23856`, especially `23690-23775`). Its AST `Cast.ty` is built from the same physical `Operation::CheckCast`; the new join should require that exact AST origin and checkcast opcode rather than treating an arbitrary same-spelled cast or a `presented` type as physical evidence. The selected `List<E>` Signature is parsed/spelled by the existing ordinary Signature path. For supported signatures, compare the canonical source `Type` used there to this physical-cast `Type`; mismatch or unspellable member path refuses the optional typed projection.

## Opaque AST and text/map contract

`ClassSourceMethodAst` is an opaque `Arc<ClassSourceMethodAstSource>` sidecar (`crates/jarde-java/src/report.rs:1341-1346, 6491-6518`). The existing report API demonstrates pure clone-and-project over its `Program` (`project_class_source_invoke_argument_edits`, `3010-3238`); `emit_class_source_method_ast` emits the retained projected Program (`4001-4014`). The right seam is a narrowly scoped projection of the already-present ForEach node plus its exact first binding: change only `ForEach.ty` and remove only the cast wrapper from that direct first assignment/declaration RHS, leaving the synthetic name and every destination, statement, and lexical scope intact. Preserve the cast origin on the header/combined loop origin; keep the original store anchor on the body statement. A doc-hidden helper on the opaque sidecar is enough—no serialized evidence model or new AST node.

The class-source projection state commits emitted method text after verifying the original emission against the existing report artifact (`src/class_source.rs:730-790`). The raw `RecoveryReport.text` and its raw method map remain a separate plane. The current projection helpers clone the Program and copy the immutable physical BCI/opcode inventory; they do not rebuild a source map for the projected body. The new path must retain that contract: compare raw text only with its own raw map, verify projected body/class separately, and never present the raw method map as a map for the projected class-source text. Since this target has no call-argument edit, ensure the AST projection/emit/commit branch runs when the typed-foreach edit is the only edit; the current branch at `src/facade.rs:16757` is guarded solely by `call_casts` or `presentation_removals` and would otherwise skip it.

## Final revalidation and atomicity

The current transaction already computes Signature/body proofs twice (staging, then final incoming-use closure). To preserve that contract, make the typed edit part of the repeated proof result. The smallest in-crate plan is an internal per-site tuple/list containing the existing foreach statement BCI, iterable/formal read BCI, cast BCI, and `Type`; stage it with the current list proof and require exact equality after the final recomputation. The `Type` must be the one just checked by the parsed Signature gate. A public proof struct is unnecessary.

Alternatively, because the AST is immutable/opaque and `ClassSourceMethodAst` has structural `Eq`, re-run the pure projection from the same AST and same validated slot/type inputs in the final closure, and require projected AST equality to the initially staged projection. The current code does neither: comparing only `Vec<(slot, Vec<String>)>` cannot distinguish two same-typed loop sites, and the final pass presently validates neither a foreach edit plan nor the projected AST. The initial projected source must not be installed if that final check or the generic component closure fails. Stop must still propagate through the existing staging rollback.

The body rewrite preserves both specified shapes: the old `Assign s1` and its outer declaration remain, and the old initialized `Declare s2` remains in the loop body. The generated foreach local continues to be the source of the body copy. Therefore there is no need to recover the outer local's full read/write lifetime or resolve every same-name use; those identities and scopes are left untouched. A separate original-name folding feature would need a different proof and remains explicitly out of scope.

## Reject boundaries to preserve

Refuse a typed edit if the class/member Signature is absent, raw, wildcard/type-variable/nested-generic, ambiguous, or not closed by the ordinary Signature gate; if `E` cannot be spelled/compared as the same source type as the physical checkcast; if the foreach formal read, AST iterable, `Iterator.next`, cast, and body write do not join to one exact method/site; if the cast is not the direct first body binding; or if there is an intervening effect, different catch scope/handler set, multiple consumer/write, duplicate site, or missing physical cast. Keep the reliable old Object foreach plus body cast on proof refusal. The separate error-element and iterator exception oracle remains required by the tasks; the static equivalence is that the generated header cast happens before the preserved first body local copy and all user body effects.

## Source pins

OpenSpec SHA-256:

- `proposal.md`: `e657389e4f802013f2e3fa3110b0cd078e14b1039ee9e1d060bfe94cb750f748`
- `design.md`: `f402cc559441e991bb5a522cab6389d94dc7d8e29016e08b0b353dcd1c9ccc4d`
- `specs/java8-recovery/spec.md`: `56bc08ad61a8fb5b3662a7ef27c8fa7a05a81292545909ceb1f8c4ca45b206742`
- `tasks.md`: `29314b1d644ca39ac359212a3b817a4a184622fd362f01f29a2d73acba84c2ac`

Current source SHA-256:

- `/Users/lordcasser/workspace/projects/jarde/src/facade.rs`: `8427d6aa65b4a4dbf515bfc1b259135d1251eab692857e77324072b8f35358ef`
- `/Users/lordcasser/workspace/projects/jarde/src/class_source.rs`: `ad8e176f5ebfef4a68d563f7d22699449982d4fa0c0ad9c09a5ecacd75a4780f`
- `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/report.rs`: `93b768810f3b31fbcdb6c3ec224c9a48bf9da9bca74a195a1b6f486217500a51`
- `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/build.rs`: `e3f201df7bd01b9b0691d5f7229cbfd5efd82ce5b70fdd39f0f003170fe51b39`
