# Typed `List<T>` foreach: existing transaction seam (static review)

Date: 2026-10-18. Read-only review of the current Jarde checkout. The root-reported current CLI observation (not re-run here) is a `List<String>` parameter recovered with two `Object` foreach headers and body casts. This note identifies a local projection seam; it does not claim a new implementation or runtime result.

## Conclusion

The smallest credible implementation can stay inside the existing same-class generic-call transaction and reuse its retained `ForEach` AST node. It needs one narrowly scoped AST projection operation in `jarde-java::report` plus an exact per-loop certificate staged beside the existing list-parameter proof. It does not need a new recovery pass, public AST node, IR, or solver. Merely assigning `ForEach.ty = String` is insufficient: today’s node binds a synthetic `Object` iterator element while the first body statement performs the checked cast and declares/stores the real element local.

## Current joins and the gap

`src/facade.rs:12957-13039` (`generic_list_parameter_slots`) admits only an exact single-argument `java.util.List<ConcreteReference>` Signature whose element has no nested type arguments. `prove_generic_list_parameter_body` starts at `src/facade.rs:13041`; it reads the same-run `VoidBody` candidate, complete local declarations/assignments and foreach-site inventory, then binds a direct list-parameter receiver by slot, read BCI, formal name, physical invocation and AST receiver (`13140-13280`). For `iterator()`, it currently requires exactly one retained `ForEach` whose iterable expression BCI/name matches the parameter read and then continues (`~13220-13235`). That proves the list parameter is the foreach source, but does not return any foreach-element edit. The returned `(slot, actual body-cast types)` vector is later checked against the parsed Signature by `ordinary_parameterized_declaration` (`src/class_source.rs:7195+`, especially `7444-7525`); the `iterator()` branch can leave its actual-type vector empty.

The class-level transaction stages this proof at `src/facade.rs:16422-16455`, stores it in `staged_list_parameter_proofs` at `16822`, and recomputes/equality-checks it in the final closure at `16926-16965`. This is the right atomic boundary: a typed loop should only be staged when the complete class/member Signature transaction closes, and the final revalidation must reproduce the same loop edit plan. Add the typed-foreach plan to that local staged value and final comparison; do not mutate source text before the component is accepted.

`ClassSourceMethodAst` is intentionally opaque outside `jarde-java` and owns an `Arc<ClassSourceMethodAstSource>` (`crates/jarde-java/src/report.rs:1341-1346, 6491-6518`). The existing `project_class_source_invoke_argument_edits` demonstrates the intended pattern: validate exact anchors, clone the retained `Program`, change only selected nodes, return a new opaque sidecar (`report.rs:3010-3237`); then `emit_class_source_method_ast` emits that same AST (`4001-4014`). A targeted `project_class_source_for_each_element` helper can follow that pattern without introducing an AST type or global traversal pass. Existing `class_source_for_each_local_iterables` already exposes the unique foreach statement BCI, iterable-expression BCI, local name and lexical scope anchors (`3518-3558`), but not the header element binding/body-cast identity needed for the edit.

The existing builder already creates the exact base node and proves the bytecode shape. `iterable_for_each_candidate` in `crates/jarde-java/src/build.rs:23216-23856` accepts the Iterator `iterator`/`hasNext`/`next` pattern, checks SSA single-use through optional `checkcast` into one store (`~23690-23755`), requires matching handler sets for iterator setup/next/cast (`23756-23775`), then rewrites the `next` result to a synthetic `Object` local and keeps the original body cast/store (`23825-23852`). The emitter already prints `ForEach.ty` and `.name` directly (`crates/jarde-java/src/emit.rs:1013-1045`). Thus this is a source projection over a proved existing loop, not a new loop recognizer.

## Minimal local edit and proof data

The facade-side proof should join, for one exact formal slot and foreach statement:

- the parsed Signature’s exact `List<E>` element spelling in the same member/class type scope;
- the direct iterable receiver’s parameter-read BCI/name and unique `ForEach` site (already checked);
- the unique physical `Iterator.next():Object` result, its immediate `checkcast E`, and the single following local store, with the existing builder/SSA facts and physical BCIs;
- the retained `ForEach` header plus its first direct body declaration/assignment, bound by BCI, local name, and lexical scope anchors;
- the cast/store local’s declaration/use closure so that no second definition, alias, escaped read, or same-name declaration is accidentally rewritten.

If all match, the AST edit changes the existing header type from `Object` to the Signature’s `E`, changes its synthetic element name to the real cast/store local name, and removes only that first cast/store declaration from the loop body. The rest of the body continues to reference the real source local. Retain/merge the eliminated cast/store and `next` origins into the foreach node’s origin set (or an equivalent existing provenance carrier); otherwise source-map/BCI attribution can lose precisely the instructions this edit absorbs. The helper should require one exact node match and return `None` on duplicates or mismatch, like the invoke-argument projection.

Do not infer `E` solely from the body cast. The current `generic_list_parameter_slots` identifies eligible slots, while the final Signature gate is what spells and validates the source type; use that exact parsed element type, and join the physical cast type against it. In the iterator-only path `proved_list_parameters` can be empty, so its current “empty actual type list” acceptance is not itself evidence that a body cast equals `E`.

## Refusal boundary and semantics

Keep the edit limited to the exact concrete-reference Signature subset already admitted. Refuse raw `List`, wildcard/type-variable/nested generic elements, ambiguous formal or foreach names, non-local iterable expressions, multiple foreach candidates, multiple `next`/cast/store consumers, extra writes/aliases/reads that defeat local closure, or any AST/physical BCI disagreement.

The source rewrite is order-preserving only when `next -> checkcast -> store` is the first element-binding sequence and the cast remains before every user body effect. The existing candidate’s single-use and handler-set checks are useful prerequisites: Java’s enhanced-for still performs `Iterator.next()` and the element cast/store once per iteration before entering user statements. Preserve the exact exception boundary: require the physical cast’s handler set to match the iteration and require its AST scope to be the loop body’s direct first binding. Refuse if the cast is nested under a narrower try/catch, if a body effect/read can run before it, or if the checkcast is not physically present; moving a cast across such a boundary can change which exception is caught or whether it is thrown.

An edit also cannot widen the lifetime of a bytecode local. The element name must become the foreach-scoped binding, not an outer declaration; reject external reads/writes or name shadowing that would make the body’s existing name resolve differently. Keep the existing List source proof and `ordinary_parameterized_declaration` as the authority that the method Signature is valid, then commit the emitted body through the same staged generic projection state so Signature and body are accepted together. The existing `project_generic_call_arguments` commit is text-oriented and named for invocation edits (`src/class_source.rs:730-790`); either reuse its exact-body transaction with no argument markers or add a narrowly named sibling commit, but do not install a typed body on a refused/deferred generic component.

## Source pins

SHA-256 pins for the files read:

- `/Users/lordcasser/workspace/projects/jarde/src/facade.rs` — 8427d6aa65b4a4dbf515bfc1b259135d1251eab692857e77324072b8f35358ef
- `/Users/lordcasser/workspace/projects/jarde/src/class_source.rs` — ad8e176f5ebfef4a68d563f7d22699449982d4fa0c0ad9c09a5ecacd75a4780f
- `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/report.rs` — 93b768810f3b31fbcdb6c3ec224c9a48bf9da9bca74a195a1b6f486217500a51
- `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/ast.rs` — 641a30c693ee2e2d67d38109f508d3b17a8ad02fbb507137810f1289f6983926
- `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/emit.rs` — 80169b0bc68693734d10589831f20cd12695045eb7348fc659a55e25f9fad1d0
- `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/build.rs` — e3f201df7bd01b9b0691d5f7229cbfd5efd82ce5b70fdd39f0f003170fe51b39
