# TestNestedLoops current-baseline collector: scoped static review

This is a read-only static review of the unexecuted prep at /private/tmp/jarde-testnestedloops-current-baseline-prep-luna-v1-20261018/collect_baseline.py and its driver. I did not run the collector or any Java/JADX/Jarde/Cargo/Git/network command. This memo does not review the manifest typo, source-copy path comparison, wrong-root return-code contract, JADX profile expansion, or helper/pin ordering; root already requested those corrections.

## Driver / original behavior

The eight case names and list arguments match the frozen historical Runner.java cases, including both non-five-character list-mutation cases and the null-element case. null-element clears/replaces the initial left list with exactly one null, matching the historical runner. The other cases match their historical argument lists. The driver creates fresh left/right lists and a fresh target instance per case; catches the invoked method's actual cause; emits the actual post-call lists and exception class; and does not hard-code outcome values. Its target loads through a URLClassLoader with null parent, checks loader identity, and compares ProtectionDomain.CodeSource against a separate expected-root argument. Ordinary runtime classpath is driver-only, with target roots passed as loader arguments. The JDK8/JDK23 × debug/no-debug × eight-case plan gives four original runs and 32 observations if both full-source profiles compile.

The wrong-root branch is intentionally a control mode rather than a normal eight-case run. The current collector/driver exit contract is already called out for root's fix and is not re-audited here.

## Complete classfile facts

The collector preserves and pins the unchanged upstream outer-plus-child source, and the javac23 profiles expect exactly the outer and nested target class files. Both classes are passed through independent parsers and the complete parsed records are saved. However, full_class_facts currently checks only that the BCI list begins at zero and ends within Code; it does not decode raw code_hex and prove that the full recorded BCI sequence matches every instruction boundary. The final independent reviewer should use the accepted decode_bcis helper against every method's code bytes, and validate every exception-table range/handler boundary. It should also compare class/field/method access and identities across both profiles, while reporting any source-derived structural difference rather than assuming byte-for-byte class equality.

The driver helper classes deliberately bypass the strict parser because their constants may contain modified-UTF8 surrogate encodings. Their saved byte pins and lightweight parser summaries are appropriate; do not use that exception to weaken validation of the two product classfiles.

## Jarde source-map scope

Every full JSON report.json is saved verbatim, so method-local recovery text remains available to a later reviewer. In each api.methods[] row, outcome.report.source_map belongs to that same outcome.report.text buffer. It is not a projection onto the top-level api.text class source. The default/all comparison should separately compare the top-level whole-source text and each method's quality/fallback/source-map projection; UTF-8 byte-span bounds must be checked against the individual outcome.report.text bytes. Do not test those method-local offsets against the whole class text or translate them without a recorded projection.

The collector records complete method source_map values and owner identity in each summary, but does not retain method-local report text in the summary. That is not an evidence loss because the raw JSON is stored and pinned. The independent reviewer must parse that raw report rather than infer method-local map ranges from the separately saved whole-source.java.

## Current evidence boundary

The prep describes intended compiler/JVM/API work only. No runtime oracle, current CLI behavior, classfile validity, structured outcome, or map coverage has been independently established by this review. The requested root fixes and the physical BCI/source-map checks above remain required before accepting a future capture.
