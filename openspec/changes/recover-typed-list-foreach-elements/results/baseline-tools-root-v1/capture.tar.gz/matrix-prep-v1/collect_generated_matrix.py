#!/usr/bin/env python3
"""Rebuild complete saved TestNestedLoops sources and compare their runtime observations.

Preparation only: invoke explicitly with a completed baseline receipt and its SHA.
This collector is intentionally not run while being prepared.
"""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, re, shutil, sys, zipfile
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
COMPARE_REL='openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD_REL='openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL='openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_REL='openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
BASELINE_SCHEMA='cf11-testnestedloops-current-full-source-baseline-v1'
INTERNAL='jadx/tests/integration/loops/TestNestedLoops$TestCls'
OUTER='jadx/tests/integration/loops/TestNestedLoops'
DRIVER_NAME='TestNestedLoopsDriver'
DRIVER_SHA='4534f142ad673595898a581ebb474a0d2783cbd974b403f8c658e74792e59df0'
PROFILES=('debug','no-debug'); EVIDENCE=('default','all'); FORMS=('child','bundle-child')
LEGS=('javac8','javac23'); RUNTIMES=('javac8','javac23')
EXPECTED_METHODS={('<init>','()V'),('test','(Ljava/util/List;Ljava/util/List;)V')}
ENV_STRIP=('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','CARGO_TARGET_DIR')

def sha_bytes(data): return hashlib.sha256(data).hexdigest()
def sha_file(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
 return h.hexdigest()
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path)
 if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
 mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def exact_pin(compare,row,label):
 if not isinstance(row,dict) or not {'path','bytes','sha256'}<=row.keys(): raise RuntimeError(f'{label}: invalid pin')
 p=Path(row['path']).resolve(strict=True)
 if compare.pin(p)!=row: raise RuntimeError(f'{label}: pin mismatch {p}')
 return p
def filetree(compare,root): return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*')) if p.is_file()}
def parse_profile_facts(compare,physical,root):
 files=sorted(root.rglob('*.class'))
 facts={}
 for p in files:
  rel=p.relative_to(root).as_posix(); f=compare.parse_class(p); q=physical.parse_class_file(p.read_bytes())
  if q['class_name']!=f['class_name'] or q['major']!=f['major'] or q['methods']!=f['methods']:
   raise RuntimeError(f'parser disagreement: {rel}')
  if sorted((x['name'],x['descriptor'],x['access']) for x in q['fields'])!=sorted(f['fields']):
   raise RuntimeError(f'field parser disagreement: {rel}')
  f['access']=q['access']
  keys={(m['name'],m['descriptor']) for m in f['methods']}
  if len(keys)!=len(f['methods']): raise RuntimeError(f'duplicate method: {rel}')
  for m in f['methods']:
   c=m.get('code')
   if c is None or not c.get('bcis') or c['bcis'][0]!=0 or c['bcis'][-1]>=c['code_length']:
    raise RuntimeError(f'invalid physical Code/BCI: {rel}:{m["name"]}{m["descriptor"]}')
  if f['major']!=52: raise RuntimeError(f'compiled class is not Java 8 major 52: {rel}')
  facts[rel]=f
 if INTERNAL+'.class' not in facts: raise RuntimeError('compiled tree lacks the target nested class')
 target=facts[INTERNAL+'.class']
 if target['class_name']!=INTERNAL or not EXPECTED_METHODS.issubset({(m['name'],m['descriptor']) for m in target['methods']}):
  raise RuntimeError('compiled target identity or required method inventory differs')
 return facts
def source_cells(baseline,compare):
 cells=[]
 for row in baseline.get('jarde_cells',[]):
  if row.get('exit_code')!=0: raise RuntimeError('baseline Jarde API source cell is incomplete')
  profile=row.get('profile'); form=row.get('input_form'); evidence=row.get('evidence')
  if profile not in PROFILES or form not in FORMS or evidence not in EVIDENCE: raise RuntimeError('unexpected Jarde selector')
  report=exact_pin(compare,row.get('report'),'Jarde report')
  src=exact_pin(compare,row.get('whole_source'),'Jarde full source')
  doc=json.loads(report.read_text(encoding='utf-8'))
  if doc.get('text','').encode('utf-8')!=src.read_bytes(): raise RuntimeError('Jarde report/source text mismatch')
  if len([m for m in row.get('methods',[]) if m.get('identity')])<2: raise RuntimeError('Jarde method inventory missing')
  input_pin=exact_pin(compare,row.get('input'),'Jarde original class input')
  cells.append({'kind':'jarde','profile':profile,'form':form,'evidence':evidence,'source_pins':[row['whole_source']],
                'report_pin':row['report'],'input_pins':[row['input']],'source_paths':[str(src)],'cell_key':[profile,form,evidence]})
 if len(cells)!=8 or {(x['profile'],x['form'],x['evidence']) for x in cells}!={(p,f,e) for p in PROFILES for f in FORMS for e in EVIDENCE}:
  raise RuntimeError('baseline Jarde selector grid is incomplete')
 jrows=baseline.get('jadx_outputs',[])
 if len(jrows)!=2 or {x.get('profile') for x in jrows}!=set(PROFILES): raise RuntimeError('baseline JADX profiles incomplete')
 for row in jrows:
  if row.get('exit_code')!=0 or not row.get('sources'): raise RuntimeError('JADX whole-bundle output incomplete')
  pins=row['sources']; paths=[exact_pin(compare,p,'JADX full source') for p in pins]
  if not any(p.name=='TestNestedLoops.java' for p in paths): raise RuntimeError('JADX full outer source missing')
  input_pin=exact_pin(compare,row.get('input'),'JADX baseline class bundle')
  profile=row.get('profile',row.get('compiler_profile'))
  if profile not in PROFILES: raise RuntimeError('unexpected JADX compiler profile')
  cells.append({'kind':'jadx','profile':profile,'form':'bundle','evidence':'source','source_pins':pins,
                'input_pins':[row['input']],'source_paths':[str(p) for p in paths],'cell_key':[profile,'bundle']})
 if {c['profile'] for c in cells if c['kind']=='jadx'}!=set(PROFILES): raise RuntimeError('JADX profile grid is incomplete')
 return cells
def parse_oracle(raw):
 pattern=re.compile(r'^CASE index=(\d+) name=([^ ]+) exception=([^ ]+) l1=(.*?) l2=(.*)$')
 rows=[]
 for i,line in enumerate(raw.decode('utf-8','strict').splitlines()):
  m=pattern.fullmatch(line)
  if not m or int(m.group(1))!=i: raise ValueError(f'malformed oracle line {line!r}')
  _,name,exc,left,right=m.groups(); rows.append({'index':i,'name':name,'exception_type':exc,'left_after':left,'right_after':right,'raw':line})
 if len(rows)!=8: raise ValueError(f'expected 8 case rows, got {len(rows)}')
 return rows
def projection(rows): return [{k:r[k] for k in ('index','name','exception_type','left_after','right_after')} for r in rows]
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--baseline',type=Path,required=True,help='completed execution.json from the accepted current baseline')
 ap.add_argument('--baseline-sha256',required=True,help='SHA-256 of that exact completed receipt')
 ap.add_argument('--out',type=Path,required=True); ap.add_argument('--root',type=Path,default=ROOT)
 a=ap.parse_args(); root=a.root.resolve(strict=True); bp=a.baseline.resolve(strict=True); out=a.out.resolve()
 if not re.fullmatch('[0-9a-f]{64}',a.baseline_sha256): raise SystemExit('baseline SHA must be explicit 64-character lowercase hex')
 if sha_file(bp)!=a.baseline_sha256: raise SystemExit('baseline receipt SHA differs from explicit argument')
 if root!=ROOT.resolve(): raise SystemExit('workspace differs from pinned root')
 if out.exists(): raise SystemExit(f'refusing existing output {out}')
 if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('target must be absent')
 if shutil.disk_usage(root).free<5*1024**3: raise SystemExit('workspace free space below 5 GiB')
 compare_path=root/COMPARE_REL; guard_path=root/GUARD_REL; scanner_path=root/SCANNER_REL; jdk_path=root/JDK_REL
 for p,h,n in ((compare_path,COMPARE_SHA,'compare'),(guard_path,GUARD_SHA,'guard'),(scanner_path,SCANNER_SHA,'scanner'),(jdk_path,JDK_SHA,'JDK manifest'),(PARSER,PARSER_SHA,'full physical parser')):
  if sha_file(p)!=h: raise SystemExit(f'{n} pin mismatch')
 compare=load(compare_path,'nested_current_compare'); guard=load(guard_path,'nested_current_guard'); scanner=load(scanner_path,'nested_current_scanner'); physical=load(PARSER,'nested_current_physical')
 jdks,jdk_record=compare.configured_jdks(jdk_path,JDK_SHA)
 baseline=json.loads(bp.read_text(encoding='utf-8'))
 if baseline.get('schema')!=BASELINE_SCHEMA or baseline.get('status')!='captured-pending-independent-review': raise SystemExit('baseline receipt is not the completed expected capture')
 baseline_pin=compare.pin(bp)
 if baseline_pin['sha256']!=a.baseline_sha256: raise SystemExit('normalized baseline pin differs from explicit SHA')
 if baseline.get('source_unchanged') is not True or baseline.get('target_absent') is not True: raise SystemExit('baseline source/target gates failed')
 commands={r['index']:r for r in baseline.get('commands',[])}
 if len(commands)!=len(baseline.get('commands',[])): raise SystemExit('duplicate baseline command ids')
 for row in commands.values():
  if row.get('guard_stop') is not None: raise SystemExit(f'baseline guard stopped: {row.get("label")}')
  compare.command_artifact(row,'stdout'); compare.command_artifact(row,'stderr')
 if len(baseline.get('original_runtime',[]))!=4: raise SystemExit('baseline must have four original profile/runtime oracle runs')
 oracles={}
 for row in baseline['original_runtime']:
  if row.get('exit_code')!=0 or row.get('profile') not in PROFILES or row.get('runtime') not in RUNTIMES: raise SystemExit('invalid original oracle row')
  cmd=commands.get(row.get('command'))
  if cmd is None or cmd.get('exit_code')!=0: raise SystemExit('oracle row is not linked to successful command')
  rows=parse_oracle(compare.command_artifact(cmd,'stdout'))
  if row.get('rows')!=rows: raise SystemExit('saved oracle rows differ from raw stdout')
  oracles[(row['profile'],row['runtime'])]=projection(rows)
 if set(oracles)!={(p,r) for p in PROFILES for r in RUNTIMES}: raise SystemExit('oracle profile/runtime grid incomplete')
 cells=source_cells(baseline,compare)
 dependency=baseline.get('dependency_reference')
 if not isinstance(dependency,dict): raise SystemExit('baseline missing dependency reference')
 dep_path=exact_pin(compare,dependency,'dependency reference')
 dep=json.loads(dep_path.read_text(encoding='utf-8'))
 if dep.get('schema')!='cf11-original-nestedloops3-baseline-v1': raise SystemExit('dependency reference schema mismatch')
 dep_rows=[dep['harness_jar'],*dep.get('jar_pins',[])]
 for rec in dep_rows: exact_pin(compare,rec,'compile dependency')
 classpath=dep.get('classpath')
 if not classpath: raise SystemExit('dependency classpath missing')
 dep_dirs=dep.get('directory_pins',dep.get('directory_pins_before',{}))
 target_names={INTERNAL+'.class',OUTER+'.class'}
 for rec in dep_rows:
  if rec['path'].endswith('.jar'):
   with zipfile.ZipFile(rec['path']) as archive:
    if target_names.intersection(archive.namelist()): raise SystemExit('target class leaked into dependency JAR')
 for folder,pins in dep_dirs.items():
  actual={str(p):compare.pin(p) for p in sorted(Path(folder).rglob('*.class'))}
  expected={str(Path(v['path'])):v for v in pins.values()} if isinstance(pins,dict) else None
  if expected is None or actual!=expected: raise SystemExit(f'dependency class directory changed: {folder}')
  if any((Path(folder)/name).is_file() for name in target_names): raise SystemExit(f'target class leaked into dependency directory: {folder}')
 source_before=compare.source_closure(root)
 driver_src=Path(__file__).with_name('driver')/'TestNestedLoopsDriver.java'
 if sha_file(driver_src)!=DRIVER_SHA: raise SystemExit('frozen reflection driver SHA mismatch')
 runtime_original=Path(baseline['runtime_wrapper']['path']).resolve(strict=True)
 for rec,key in ((baseline.get('runtime_wrapper'),'baseline runtime wrapper'),(baseline.get('cli'),'baseline CLI'),
                 (baseline.get('jadx'),'JADX'),(baseline.get('jadx_jar'),'JADX jar')):
  exact_pin(compare,rec,key)
 out.mkdir(parents=True); raw=out/'raw'; raw.mkdir(); empty=out/'empty-classpath'; empty.mkdir()
 guard.ROOT=root; guard.OUT=raw; guard.target_bytes=lambda:scanner.target_bytes(root); guard.command_stream=compare.pin
 guard.expected_test_summaries=lambda index,data:None
 copied_driver=out/'driver-source'/driver_src.name; copied_driver.parent.mkdir(); shutil.copyfile(driver_src,copied_driver)
 if copied_driver.read_bytes()!=driver_src.read_bytes(): raise RuntimeError('driver copy differs')
 driver_classes=out/'driver-classes'; driver_classes.mkdir()
 runtime_copy=out/runtime_original.name; shutil.copyfile(runtime_original,runtime_copy)
 if runtime_copy.read_bytes()!=runtime_original.read_bytes(): raise RuntimeError('runtime wrapper copy differs')
 external_files=[bp,compare_path,guard_path,scanner_path,jdk_path,PARSER,driver_src,runtime_original,Path(baseline['cli']['path']),Path(baseline['jadx']['path']),Path(baseline['jadx_jar']['path']),dep_path,*[Path(x['path']) for x in dep_rows],*[tool for spec in jdks.values() for tool in spec['tools'].values()]]
 for key in ('source','source_copy','historical_runner_reference','driver_source','driver_copy'):
  if baseline.get(key): external_files.append(Path(baseline[key]['path']))
 for cell in cells:
  external_files.extend(Path(pin['path']) for pin in cell.get('source_pins',[]))
  external_files.extend(Path(pin['path']) for pin in cell.get('input_pins',[]))
  if cell.get('report_pin'): external_files.append(Path(cell['report_pin']['path']))
 for cmd in commands.values():
  external_files.extend(Path(cmd['streams'][channel]['path']) for channel in ('stdout','stderr'))
 for profile in baseline.get('source_profiles',[]):
  for pin in profile.get('class_tree',{}).values(): external_files.append(Path(pin['path']))
 external_before=[compare.pin(p) for p in external_files]
 dep_dir_before={str(Path(folder).resolve()):{str(Path(pin['path'])):compare.pin(Path(pin['path'])) for pin in pins.values()} for folder,pins in dep_dirs.items()}
 copies_before=[compare.pin(p) for p in (copied_driver,runtime_copy)]
 report={'schema':'cf11-testnestedloops-current-generated-source-matrix-v1','status':'running','root':str(root),'output':str(out),
  'baseline_receipt':baseline_pin,'baseline_sha256_argument':a.baseline_sha256,'source_pins_before':source_before,
  'external_pins_before':external_before,'dependency_directory_pins_before':dep_dir_before,'local_copies_before':copies_before,'jdk_manifest':jdk_record,
  'compare':compare.pin(compare_path),'guard':compare.pin(guard_path),'scanner':compare.pin(scanner_path),'physical_parser':compare.pin(PARSER),
  'driver_source':compare.pin(driver_src),'driver_copy':compare.pin(copied_driver),'driver_compile':None,'driver_classes':[],
  'source_cells':[],'compilations':[],'runtime_rows':[],'wrong_root_rows':[],'original_oracles':{f'{p}/{r}':v for (p,r),v in oracles.items()},
  'notes':['Each full Jarde source cell and each complete JADX source profile is compiled unchanged by both configured Java 8-target compilers.',
           'Jarde source output remains one exact class-source artifact; JADX source cell retains every emitted Java file, including the outer class.',
           'A failed compile has no runtime rows. Successful compile/runtime and wrong-CodeSource rows retain raw stdout/stderr.',
           'Runtime semantic comparison uses only the corresponding original profile/runtime observation; raw exception and list text remains saved.']}
 compare.write_json(out/'execution.json',report); rows=report['commands']=[]
 def command(argv,label,leg):
  if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError('target appeared')
  env=compare.clean_env(dict(os.environ),jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK',None)
  row=guard.run_command(len(rows)+1,[str(x) for x in argv],env); row['label']=label; row['tool_leg']=leg; rows.append(row)
  compare.write_json(out/'execution.json',report)
  if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
  return row
 def artifact(row,channel='stdout'): return compare.command_artifact(row,channel)
 def copy_cell_source(cell,srcroot):
  copied=[]
  for src,pin in zip(cell['source_paths'],cell['source_pins']):
   p=Path(src); data=p.read_bytes(); package=''
   m=re.search(rb'^\s*package\s+([A-Za-z0-9_.]+)\s*;',data,re.M)
   if m: package=m.group(1).decode('ascii').replace('.','/')
   dest=srcroot/package/p.name if package else srcroot/p.name
   dest.parent.mkdir(parents=True,exist_ok=True)
   if dest.exists(): raise RuntimeError(f'duplicate full-source basename: {dest}')
   dest.write_bytes(data)
   if dest.read_bytes()!=data: raise RuntimeError('source copy is not byte-identical')
   copied.append({'source':pin,'copy':compare.pin(dest)})
  if cell['kind']=='jarde':
   matches=[x for x in copied if Path(x['copy']['path']).name=='TestNestedLoops$TestCls.java']
   if len(matches)!=1: raise RuntimeError('Jarde full source is not under the expected $TestCls filename')
   if Path(matches[0]['copy']['path']).relative_to(srcroot).as_posix()!='jadx/tests/integration/loops/TestNestedLoops$TestCls.java':
    raise RuntimeError('Jarde complete source package/path differs from target owner')
  return copied
 try:
  driver_compile=command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',driver_classes,copied_driver],'compile-reflection-driver','javac8')
  report['driver_compile']={'command':driver_compile['index'],'exit_code':driver_compile['exit_code'],'stdout':compare.pin(Path(driver_compile['streams']['stdout']['path'])),'stderr':compare.pin(Path(driver_compile['streams']['stderr']['path']))}
  if driver_compile['exit_code']!=0: raise RuntimeError('reflection driver failed to compile')
  dclasses=sorted(driver_classes.rglob('*.class'))
  if len(dclasses)!=3: raise RuntimeError(f'unexpected driver class tree: {[p.name for p in dclasses]}')
  report['driver_classes']=[compare.pin(p) for p in dclasses]
  # The driver has modified-UTF8 literals. Keep the deliberately narrow compare.py summary.
  report['driver_summaries']=[compare.parse_class(p) for p in dclasses]
  for cell in cells:
   basekey='-'.join(map(str,cell['cell_key'])); srcroot=out/'sources'/basekey; srcroot.mkdir(parents=True)
   copies=copy_cell_source(cell,srcroot)
   cell_record={'kind':cell['kind'],'profile':cell['profile'],'form':cell['form'],'evidence':cell['evidence'],
                'cell_key':cell['cell_key'],'source_copies':copies,'compilations':[]}
   report['source_cells'].append(cell_record); compare.write_json(out/'execution.json',report)
   for leg in LEGS:
    dest=out/'compiled'/basekey/leg/'classes'; dest.mkdir(parents=True)
    if leg=='javac8':
     debug='-g' if cell['profile']=='debug' else '-g:none'
     argv=[jdks[leg]['tools']['javac'],'-source','8','-target','8',debug,'-encoding','UTF-8','-proc:none','-classpath',os.pathsep.join(classpath),'-sourcepath',empty,'-d',dest,*sorted(srcroot.rglob('*.java'))]
    else:
     debug='-g' if cell['profile']=='debug' else '-g:none'
     argv=[jdks[leg]['tools']['javac'],'--release','8',debug,'-encoding','UTF-8','-proc:none','-classpath',os.pathsep.join(classpath),'-sourcepath',empty,'-d',dest,*sorted(srcroot.rglob('*.java'))]
    cr=command(argv,f'compile-{basekey}-{leg}',leg)
    rec={'leg':leg,'command':cr['index'],'exit_code':cr['exit_code'],'class_root':str(dest),'source_copies':copies,
         'stdout':compare.pin(Path(cr['streams']['stdout']['path'])),'stderr':compare.pin(Path(cr['streams']['stderr']['path'])),'class_tree':filetree(compare,dest)}
    if cr['exit_code']==0:
     facts=parse_profile_facts(compare,physical,dest)
     rec['class_facts']=facts
    else:
     rec['class_facts']=None
    cell_record['compilations'].append(rec); report['compilations'].append({'cell_key':cell['cell_key'],**rec})
    compare.write_json(out/'execution.json',report)
    if cr['exit_code']!=0: continue
    target_root=dest.resolve()
    for runtime in RUNTIMES:
     rr=command([sys.executable,'-B',runtime_copy,'30',jdks[runtime]['tools']['java'],'-Xverify:all','-cp',driver_classes,DRIVER_NAME,target_root,target_root],
                f'runtime-{basekey}-{leg}-{runtime}',runtime)
     stdout=artifact(rr); stderr=artifact(rr,'stderr'); parsed=parse_oracle(stdout) if rr['exit_code']==0 else []
     sem=projection(parsed) if parsed else None
     expected=oracles[(cell['profile'],runtime)]
     passed=rr['exit_code']==0 and sem==expected
     runtime_record={'cell_key':cell['cell_key'],'compiler':leg,'runtime':runtime,'command':rr['index'],'exit_code':rr['exit_code'],
      'target_root':str(target_root),'application_classpath':[str(driver_classes)],'stdout':compare.pin(Path(rr['streams']['stdout']['path'])),
      'stderr':compare.pin(Path(rr['streams']['stderr']['path'])),'rows':parsed,'semantic_projection':sem,'matches_original_profile_runtime':passed}
     report['runtime_rows'].append(runtime_record); compare.write_json(out/'execution.json',report)
    wr=command([sys.executable,'-B',runtime_copy,'30',jdks['javac23']['tools']['java'],'-Xverify:all','-cp',driver_classes,DRIVER_NAME,target_root,empty],
               f'wrong-root-{basekey}-{leg}','javac23')
    err=artifact(wr,'stderr'); rejected=wr['exit_code']!=0 and b'wrong CodeSource:' in err
    report['wrong_root_rows'].append({'cell_key':cell['cell_key'],'compiler':leg,'command':wr['index'],'exit_code':wr['exit_code'],
      'actual_target_root':str(target_root),'expected_wrong_root':str(empty),'rejected':rejected,
      'stdout':compare.pin(Path(wr['streams']['stdout']['path'])),'stderr':compare.pin(Path(wr['streams']['stderr']['path']))})
    compare.write_json(out/'execution.json',report)
    if not rejected: raise RuntimeError('wrong CodeSource control did not reject')
  report['source_pins_after']=compare.source_closure(root)
  report['external_pins_after']=[compare.pin(p) for p in external_files]
  report['dependency_directory_pins_after']={str(Path(folder).resolve()):{str(Path(pin['path'])):compare.pin(Path(pin['path'])) for pin in pins.values()} for folder,pins in dep_dirs.items()}
  report['local_copies_after']=[compare.pin(p) for p in (copied_driver,runtime_copy)]
  report['source_unchanged']=report['source_pins_after']==source_before
  report['external_inputs_unchanged']=report['external_pins_after']==external_before and report['dependency_directory_pins_after']==dep_dir_before
  report['local_copies_unchanged']=report['local_copies_after']==copies_before
  report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
  if not all((report['source_unchanged'],report['external_inputs_unchanged'],report['local_copies_unchanged'],report['target_absent'])):
   raise RuntimeError('source/input/target closure changed during capture')
  report['counts_derived']={'source_cells':len(cells),'compile_attempts':len(report['compilations']),
   'compile_successes':sum(x['exit_code']==0 for x in report['compilations']),'compile_failures':sum(x['exit_code']!=0 for x in report['compilations']),
   'runtime_attempts':len(report['runtime_rows']),'wrong_root_attempts':len(report['wrong_root_rows']),'commands':len(rows),'raw_streams':2*len(rows)}
  report['status']='captured-pending-independent-review'
 except BaseException as exc:
  report['status']='failed'; report['error']=repr(exc); raise
 finally:
  try:
   report['source_pins_after_finally']=compare.source_closure(root)
   report['external_pins_after_finally']=[compare.pin(p) for p in external_files]
   report['dependency_directory_pins_after_finally']={str(Path(folder).resolve()):{str(Path(pin['path'])):compare.pin(Path(pin['path'])) for pin in pins.values()} for folder,pins in dep_dirs.items()}
   report['local_copies_after_finally']=[compare.pin(p) for p in (copied_driver,runtime_copy)]
   report['source_unchanged_finally']=report['source_pins_after_finally']==source_before
   report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
   if not report['source_unchanged_finally'] or not report['target_absent_finally'] or report['external_pins_after_finally']!=external_before or report['dependency_directory_pins_after_finally']!=dep_dir_before or report['local_copies_after_finally']!=copies_before:
    report['status']='failed'; report['final_guard_error']='closure changed'
  except BaseException as final_exc:
   report['status']='failed'; report['final_guard_error']=repr(final_exc)
  report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  compare.write_json(out/'execution.json',report)
  shutil.copy2(__file__,out/'collector.py')
  print(json.dumps({'status':report['status'],'commands':len(rows),'compile_attempts':len(report['compilations']),
                    'runtime_attempts':len(report['runtime_rows']),'error':report.get('error')}))
 return 0
if __name__=='__main__': raise SystemExit(main())
