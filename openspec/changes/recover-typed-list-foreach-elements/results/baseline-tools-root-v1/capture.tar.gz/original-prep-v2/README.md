# TestNestedLoops current baseline collector prep v2

Private, unexecuted collector and driver for root review. No compiler, Java runtime, JADX, Jarde CLI, Cargo, Git, or network command was run. v1 remains frozen; this v2 repairs only deterministic preparation issues found in root review.

The collector uses the corrected JDK-manifest pin; validates helper files before importing them; compares source/driver/runtime-wrapper copies by byte count and SHA-256 rather than full path-bearing pin records; and re-reads those local copies in the final guard. The reflection driver accepts exactly `actualRoot expectedRoot`; the wrong-root control now passes an intentionally wrong expected root and must fail through the ordinary `wrong CodeSource:` check with a nonzero process exit. Driver classfiles are byte-pinned and summarized with the existing narrow `compare.parse_class`; they are not sent through the strict-UTF8 full parser.

JADX 1.5.6 now receives each successful full-source compiler profile's complete outer+child bundle once with default flags, yielding a debug/no-debug comparison. The unused empty `original_oracle_rows` field has been removed. All other scope remains as documented in the v1 README: full upstream source, javac 8 boundary, javac 23 release-8 debug/none, two-profile × child/bundle-child × default/all CLI calls, and eight runtime-derived historical cases per profile/runtime with exception type and both post-call lists.

The full upstream source is pinned at 876 bytes / SHA-256 `4897fd18a15fce6e0abb40dc8afc6c7a3fa9f16e617f3c7e5e88072f6a37309e`. Its captured historical `Runner.java` reference is pinned at 1,348 bytes / SHA-256 `f4c99e837599440588b54df0bb2eaaac45f0ae76db1ddeddbb789c90ff527379`; the available repository copy is used only for the eight input cases. The earlier `capture.tar.gz` is not present in this checkout, and no archive was edited.

The classpath reuses the accepted NestedLoops3 harness dependency receipt. Root should check that dependency classpath against the full TestNestedLoops source before execution. Captured output would remain pending independent review and would not establish a current recovery result by itself.
