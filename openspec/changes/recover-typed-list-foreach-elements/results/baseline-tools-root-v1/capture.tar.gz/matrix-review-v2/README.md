# TestNestedLoops generated matrix reviewer v2

This is a fresh, private v2 preparation. It has not been run against the receipts. The matrix and original baseline remain `captured-pending-independent-review`; do not treat this script or its AST check as acceptance.

The v2 script preserves the v1 reviewer and adds only the requested independent checks: verify helper file pins before importing them; validate the JDK manifest by its actual path/SHA shape; decode each compiled method's physical bytecode and check exception-table bounds; compare complete generated class trees and class/member/access inventories to the original profile facts; enforce the recorded 5 GiB free-space and 1 GiB target-peak limits for baseline and matrix commands; and re-read current source closure plus `ROOT/target` state.

The expected receipts are:

- Matrix: `/private/tmp/jarde-testnestedloops-current-generated-matrix-root-v1-20261018/execution.json` (`46d5ff4f12d339d6fc2ddf9df963a256e25421b9f7c2b06eeec0cf5e08288012`)
- Original baseline: `/private/tmp/jarde-testnestedloops-current-baseline-root-v1-20261018/execution.json` (`4f48e3b14738cb4d3746763290788f525bba4bb1a1a3d47aebcf0111e6f8d482`)

Run only when root is ready to independently review, with a new output directory:

```sh
python3 -B /private/tmp/jarde-testnestedloops-current-generated-matrix-review-prep-luna-v2-20261018/review_matrix.py \
  --matrix /private/tmp/jarde-testnestedloops-current-generated-matrix-root-v1-20261018/execution.json \
  --matrix-sha256 46d5ff4f12d339d6fc2ddf9df963a256e25421b9f7c2b06eeec0cf5e08288012 \
  --baseline /private/tmp/jarde-testnestedloops-current-baseline-root-v1-20261018/execution.json \
  --baseline-sha256 4f48e3b14738cb4d3746763290788f525bba4bb1a1a3d47aebcf0111e6f8d482 \
  --out /private/tmp/jarde-testnestedloops-current-generated-matrix-review-root-v2-20261018
```

All four imported helpers (compare, guard, scanner, and physical parser) are hashed before import against the matrix receipt; their resolved paths, sizes, and hashes are recorded in `source-pins.json`, along with the physical parser pin. `review_matrix-v1-v2.diff` contains the exact delta from frozen v1. Static `ast.parse` passed; no matrix reviewer, compiler, JVM, CLI, JADX, Cargo, Git, or network command was run.
