# `TestNestedLoops` typed foreach: JADX static algorithm and Jarde seam

Scope: read-only source analysis for the original `TestNestedLoops.java` golden assertion. The checkout is the fixed ledger reference `jadx` commit `2fb1b16386941660fda07e9017285aec40fcb37f`; source hashes below were read locally. No JDK, JADX CLI, Jarde CLI, Cargo, Git, or network was used. This memo describes code, not the current binary’s rendered output and not a newly established Jarde failure.

## Direct JADX algorithm

`jadx-core/src/main/java/jadx/core/dex/visitors/regions/LoopRegionVisitor.java:70-82` visits a pre-tested loop after its `LoopRegion` exists, tries indexed-for first, then calls `checkIterableForEach`. The foreach recognizer at lines 246-340 requires one register in the loop condition, an SSA variable that is not phi-used and has exactly two uses, assigned by `iterator()`, with the two uses resolving to `Iterator.hasNext()Z` and `Iterator.next()Object`. `checkInvoke` at lines 389-401 accepts interface or virtual invocation and checks the method short id; the hasNext/next calls must name `java.util.Iterator`.

When the `next()` result is wrapped, it looks up the wrapping parent and requires that instruction’s block to be inside this loop region (277-282). If the parent is `CHECK_CAST`, the foreach element variable is the cast result (`iterVar = parentInsn.getResult()`, 284-288), not the raw `Object` result. It then tries to connect the cast’s consumer to that loop variable (289-295): when the cast is wrapped by a consumer, that consumer is rewritten to use the variable; when it has no such parent, the cast instruction is suppressed. Thus the cast that originally sat between `next()` and the element store is consumed as the loop binding, instead of left as a separate cast statement.

There is a separate wrapped-parent case for non-cast wrappers (296-307), and an unwrapped-`next()` case (312-324). The latter requires the result’s uses and assignments to remain inside the loop. These are different shapes; the check-cast branch must not be described as carrying the unwrapped branch’s explicit use-list predicates. Across both branches, it suppresses the iterator initialization and the `hasNext`/`next` uses, then constructs `ForEachLoop(iterVar, iterableArg)` (326-339).

`fixIterableType` at lines 342-384 bounds the element type:

- If `iterableArg.getType()` is generic, exactly one generic argument is required. The argument must equal the cast variable type, be a generic type (in which case the variable receives that type), be assignable to the variable type, or be a compatible `? extends` bound. Otherwise it rejects the foreach rewrite.
- If the iterable is a non-generic object register, the visitor synthesizes `IterableClass<iterVarType>` on that expression. An existing immutable type that conflicts with this synthetic type blocks the rewrite except when the element variable is `Object`.
- The method itself does not parse a class-file `Signature`; it consumes the `ArgType` already attached to the iterable expression. The existing generic `ArgType`, when present, is a compatibility constraint. The raw-object branch has its own synthesis rule; it is not evidence that any arbitrary erased receiver can safely be declared `Iterable<T>`.

The cast’s result type is the element-type candidate; an erased collection signature alone cannot recover whether the original loop variable was `String`, while the cast alone does not establish the source-level parameter type of the collection. For the requested exact header `for (String s : l)`, the loop-variable type and the source expression’s compile-time Iterable element type must agree. The original Java source declares both parameters `List<String>`, and the loop’s `next()` element is cast to `String`. Those two facts play different roles: the source generic type makes the typed header compile against `l`; the per-element cast establishes the erased bytecode check at the loop’s element-fetch point. If an implementation projects a typed header, it must retain the class/method generic source fact and prove that the cast is exactly the single element binding it consumes. Merely changing a local to `String` or deleting an arbitrary cast is insufficient.

## Type facts and pass order

In `jadx-core/src/main/java/jadx/core/Jadx.java:142-171`, SSA and inlining precede type inference and type fixes; `GenericTypesVisitor` runs before region construction. `RegionMakerVisitor` then builds regions (177-178); simplification and region checks follow. `LoopRegionVisitor` runs later at line 199, after `ClassModifier`, and before `ProcessVariables` at line 205. `LoopRegionVisitor`’s own annotation also declares `runBefore = ProcessVariables` (`LoopRegionVisitor.java:45-49`). This means it operates on inferred instruction types and a built region, and can change the loop before variable declaration is finalized.

Do not attribute iterable Signature parsing to `GenericTypesVisitor`: its current source (`GenericTypesVisitor.java:28-56`) walks constructor instructions and attaches generic constructor metadata. The foreach recognizer directly reads `iterableArg.getType()` and `iterVar.getType()`; the correct upstream origin of a particular parameter’s generic `ArgType` needs to be read from its actual type-propagation facts, not inferred from that visitor’s name.

`ForEachLoop.java:13-30` preserves the selected variable and iterable in fake region-argument instructions and marks the selected code variable declared. `RegionGen.java:199-209` emits `for (` + declaration of the selected `RegisterArg` + ` : ` + iterable expression. Therefore the variable type chosen by the recognizer directly becomes the foreach header type; it is not a later renderer guess. `ProcessVariables` follows the conversion, runs usage collection, and retains a declared variable (`ProcessVariables.java:45-69`, `ForEachLoop.java:24-26`).

## Jarde comparison

Current `crates/jarde-java/src/build.rs` SHA-256: `e3f201df7bd01b9b0691d5f7229cbfd5efd82ce5b70fdd39f0f003170fe51b39`.

The existing `iterable_for_each_candidate` at lines 23216-23247 admits Java 8+, an exact `Iterator.hasNext()Z` interface owner, and a first body binding that is either an initialized declaration or a cast of a call. Lines 23274-23413 then bind the matching `next()` and `iterator()` calls to exact owners (Iterable/List/Collection), and correlate the iterator local and loads/stores. The proof continues through lines 23695-23754: `next()` has one consumer at the cast or store; if a cast exists, its value has one consumer at the element store. It also checks the loop phi, effects/handlers, source declaration ownership, and output/source BCI origins.

But the candidate currently rewrites the call to a synthetic `Object` local and constructs `StmtKind::ForEach { ty: Object, ... }` at lines 23843-23853. When the bytecode cast remains a separate body binding, it specifically requires the first binding to be `Object`, the following declaration to cast that binding, and the corresponding local SSA value to have one use (23717-23754). That preserves the check in the body and avoids claiming an element type that this path has not proved. Its iterable input is only required to be a presented reference whose class name matches the exact platform owner (23352-23397); this candidate does not currently consume a generic element argument from the iterable Signature.

So the useful JADX precedent is not simply “move the cast into the foreach.” It is: use the exact check-cast result as the loop variable; confirm its element type against the already-known generic iterable element type (or apply the tightly scoped raw-object synthesis rule); prove the iterator/init/use graph and loop ownership; and suppress the old cast only after replacing its unique element-store consumer. In Jarde, the existing exact-call/SSA/handler/owner proof can be retained, while typed projection would need actual source generic evidence from the original class/method declaration and type compatibility at the exact foreach receiver. Do not reuse JADX’s mutable `ArgType` updates as a substitute for Jarde’s source `Signature` ownership proof, and do not project `String` from a body cast alone when the collection expression is still emitted raw.

## What remains unproved

This static comparison does not show how the current CLI renders the pinned `TestNestedLoops` class, whether its real candidate reaches the `ForEach` branch, or where a current rejection occurs. The earlier full-class receipt is historical and not a current run. The current collector remains with root; no new failure fact is claimed here. Any implementation choice should wait for that receipt and, if needed, same-input source/type/SSA diagnosis.

## Source pins

The JADX checkout pin recorded by the fixed CF-11 ledger is `2fb1b16386941660fda07e9017285aec40fcb37f`.

- `jadx-core/src/test/java/jadx/tests/integration/loops/TestNestedLoops.java` — `4897fd18a15fce6e0abb40dc8afc6c7a3fa9f16e617f3c7e5e88072f6a37309e`.
- `jadx-core/src/main/java/jadx/core/dex/visitors/regions/LoopRegionVisitor.java` — `921f09e8934fda33452a00359588b293117f160813477e7068fa1ec3b71e6515`.
- `jadx-core/src/main/java/jadx/core/dex/regions/loops/ForEachLoop.java` — `e16fba634dbc7dda08e6a69e5a0263953f0a5b1ffdae4d12272a2bab458a8321`.
- `jadx-core/src/main/java/jadx/core/Jadx.java` — `83e134eb2f2a3aa84d8c432a3b07565c82c71e1d105037757f76385e0706b9b7`.
- `jadx-core/src/main/java/jadx/core/codegen/RegionGen.java` — `8b80ef618487e38cb09a2bbd81b70de0dd096996a321a0c9dcf55e1dc011d4ee`.
- `jadx-core/src/main/java/jadx/core/dex/visitors/regions/variables/ProcessVariables.java` — `929d20895a6a4130b4a718a8b29fe0011c3a72d0d8f34951387a3e18e497ed8a`.
- `jadx-core/src/main/java/jadx/core/dex/visitors/GenericTypesVisitor.java` — `ae2521c5815ab6851999ddf16e70b134214fdd9759caae589e7e1361852f8610`.
- `jadx-core/src/main/java/jadx/core/dex/visitors/typeinference/TypeInferenceVisitor.java` — `946a0f9d556fc35fa1a6850b5aa2cb66b923d6ac83bca326f548383e2a0357ea`.
- `jadx-core/src/main/java/jadx/core/dex/visitors/typeinference/FixTypesVisitor.java` — `22cbc270e1c4480e7f00737d3c9a60a0ef14f8defd4ae738ff7bc5cbde9431d3`.
- Current Jarde `crates/jarde-java/src/build.rs` — `e3f201df7bd01b9b0691d5f7229cbfd5efd82ce5b70fdd39f0f003170fe51b39` (working-tree pin only).
