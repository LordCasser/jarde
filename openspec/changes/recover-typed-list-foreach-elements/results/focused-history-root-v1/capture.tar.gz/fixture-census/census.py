#!/usr/bin/env python3
"""Private static Code census: candidate fixture versus captured javac8-debug class."""
from __future__ import annotations
import hashlib, importlib.util, json
from pathlib import Path
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
CANDIDATE = ROOT/'tests/fixtures/typed-list-foreach/TypedListForEachCases.class'
BASELINE = Path('/private/tmp/jarde-typed-foreach-controls-baseline-root-v1-20261018/original/javac8-debug/classes/typedforeach/TypedListForEachCases.class')
PARSER = Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
OUT = Path('/private/tmp/jarde-typed-list-foreach-census-luna-v1-20261018/census.json')
def sha(b: bytes) -> str: return hashlib.sha256(b).hexdigest()
def parse(data: bytes):
    spec=importlib.util.spec_from_file_location('classfile_helpers_census',PARSER); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod.parse_class_file(data)
def code_facts(raw: bytes):
    # JVM fixed-length operand table, independently walked without helper.decode_bcis.
    fixed={0x10:2,0x11:3,0x12:2,0x13:3,0x14:3,0x15:2,0x16:2,0x17:2,0x18:2,0x19:2,
      0x36:2,0x37:2,0x38:2,0x39:2,0x3a:2,0x84:3,0xa9:2,0xbc:2,0xc5:4,
      0xb2:3,0xb3:3,0xb4:3,0xb5:3,0xb6:3,0xb7:3,0xb8:3,0xbb:3,0xbd:3,0xc0:3,0xc1:3,0xb9:5,0xba:5,0xc8:5,0xc9:5}
    fixed.update({x:3 for x in range(0x99,0xa9)}); fixed.update({0xc6:3,0xc7:3})
    bcis=[]; targets=[]; jsrs=[]; pc=0
    while pc<len(raw):
        bcis.append(pc); op=raw[pc]
        if op in range(0x99,0xa8) or op in (0xc6,0xc7):
            delta=int.from_bytes(raw[pc+1:pc+3],'big',signed=True); targets.append({'source_bci':pc,'opcode':f'0x{op:02x}','offset':delta,'destination':pc+delta}); size=3
        elif op in (0xc8,0xc9):
            delta=int.from_bytes(raw[pc+1:pc+5],'big',signed=True); targets.append({'source_bci':pc,'opcode':f'0x{op:02x}','offset':delta,'destination':pc+delta}); size=5
            if op==0xc9: jsrs.append(pc)
        elif op==0xa8: # jsr
            delta=int.from_bytes(raw[pc+1:pc+3],'big',signed=True); targets.append({'source_bci':pc,'opcode':'0xa8','offset':delta,'destination':pc+delta}); jsrs.append(pc); size=3
        elif op==0xaa:
            a=(pc+4)&~3
            if a+12>len(raw): raise ValueError(f'truncated tableswitch at {pc}')
            default=int.from_bytes(raw[a:a+4],'big',signed=True); low=int.from_bytes(raw[a+4:a+8],'big',signed=True); high=int.from_bytes(raw[a+8:a+12],'big',signed=True)
            if high<low: raise ValueError(f'invalid tableswitch at {pc}')
            vals=[('default',default)]+[(str(k),int.from_bytes(raw[a+12+4*(k-low):a+16+4*(k-low)],'big',signed=True)) for k in range(low,high+1)]
            targets.extend({'source_bci':pc,'opcode':'tableswitch','case':key,'offset':off,'destination':pc+off} for key,off in vals); size=a-pc+12+4*(high-low+1)
        elif op==0xab:
            a=(pc+4)&~3
            if a+8>len(raw): raise ValueError(f'truncated lookupswitch at {pc}')
            default=int.from_bytes(raw[a:a+4],'big',signed=True); pairs=int.from_bytes(raw[a+4:a+8],'big',signed=True)
            if pairs<0: raise ValueError(f'invalid lookupswitch at {pc}')
            vals=[('default',default)]+[(str(int.from_bytes(raw[a+8+8*i:a+12+8*i],'big',signed=True)),int.from_bytes(raw[a+12+8*i:a+16+8*i],'big',signed=True)) for i in range(pairs)]
            targets.extend({'source_bci':pc,'opcode':'lookupswitch','case':key,'offset':off,'destination':pc+off} for key,off in vals); size=a-pc+8+8*pairs
        elif op==0xc4:
            if pc+1>=len(raw): raise ValueError(f'truncated wide at {pc}')
            size=6 if raw[pc+1]==0x84 else 4
        else: size=fixed.get(op,1)
        if pc+size>len(raw): raise ValueError(f'instruction overrun at {pc}')
        pc+=size
    return bcis,targets,jsrs
def facts(path: Path):
    data=path.read_bytes(); parsed=parse(data); methods=[]; code_blobs=[]
    for m in parsed['methods']:
        c=m['code']; row={'name':m['name'],'descriptor':m['descriptor'],'access':m['access'],'has_code':c is not None}
        if c is not None:
            raw=bytes.fromhex(c['code_hex']); bcis,targets,jsrs=code_facts(raw)
            if bcis!=c['bcis']: raise ValueError(f"independent opcode offsets differ for {m['name']}{m['descriptor']}")
            if any(t['destination'] not in bcis for t in targets): raise ValueError(f"branch target is not an instruction BCI in {m['name']}{m['descriptor']}")
            if len(raw)!=c['code_length']: raise ValueError('Code length mismatch')
            row.update(max_stack=c['max_stack'],max_locals=c['max_locals'],code_length=len(raw),code_sha256=sha(raw),bcis=bcis,exception_handlers=[{'start_pc':x[0],'end_pc':x[1],'handler_pc':x[2],'catch_type_index':x[3]} for x in c['rows']],branch_target_records=targets,jsr_bcis=jsrs)
            code_blobs.append(raw)
        methods.append(row)
    return {'class_sha256':sha(data),'class_bytes':len(data),'class_name':parsed['class_name'],'major':parsed['major'],'access':parsed['access'],'fields':parsed['fields'],'methods':methods,'code_array_count':len(code_blobs),'instruction_bci_count':sum(len(m.get('bcis',[])) for m in methods),'handler_count':sum(len(m.get('exception_handlers',[])) for m in methods),'branch_target_record_count':sum(len(m.get('branch_target_records',[])) for m in methods),'jsr_instruction_count':sum(len(m.get('jsr_bcis',[])) for m in methods),'all_code_bytes_sha256':sha(b''.join(code_blobs))}
def main():
    a,b=facts(CANDIDATE),facts(BASELINE)
    result={'candidate_path':str(CANDIDATE),'baseline_path':str(BASELINE),'candidate':a,'baseline':b,'byte_identical':CANDIDATE.read_bytes()==BASELINE.read_bytes(),'delta':{'classes':1,'code_arrays':a['code_array_count'],'handlers':a['handler_count'],'branch_target_records':a['branch_target_record_count'],'jsr_instructions':a['jsr_instruction_count']},'expected_source_census_delta':{'classes':1,'code_arrays':6,'handlers':0,'branch_target_records':10,'jsr_instructions':0}}
    measured={k:a[k] for k in ('code_array_count','handler_count','branch_target_record_count','jsr_instruction_count')}
    expected={'code_array_count':6,'handler_count':0,'branch_target_record_count':10,'jsr_instruction_count':0}
    if not result['byte_identical'] or measured!=expected: raise ValueError(f'fixture census mismatch: measured={measured}, expected={expected}, bytes_equal={result["byte_identical"]}')
    OUT.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'candidate_sha256':a['class_sha256'],'baseline_sha256':b['class_sha256'],'byte_identical':result['byte_identical'],'delta':result['delta'],'expected':result['expected_source_census_delta'],'code_sha256':a['all_code_bytes_sha256'],'output':str(OUT)},indent=2))
if __name__=='__main__': main()
