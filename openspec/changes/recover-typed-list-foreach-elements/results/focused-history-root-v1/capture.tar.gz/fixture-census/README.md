# Typed List foreach fixture physical census

`census.py` compares the permanent fixture class bytes with the captured `javac8-debug` baseline class. It uses the existing independent full classfile reader for class/member/Code extraction, then independently walks every raw Code array's opcode boundaries and branch offsets; the two BCI sequences must agree. The JSON records complete member/field inventory, per-method max stack/locals, BCI sequence, Code length/SHA, exception rows, every branch/switch destination, and jsr locations, plus the SHA-256 of Code arrays concatenated in class method order.

Run with Python only: `python3 census.py`. It writes `census.json` beside this README. This is static bytecode evidence; it invokes no compiler, runtime, Rust, CLI, Git, or network. The reader census source note expects a delta of one class, six Code bodies, zero handlers, ten branch-target records, and zero jsr instructions; the script measures those values instead of assuming them.
