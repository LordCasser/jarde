# Read-only architecture review of the current typed-foreach candidate

## Result

No concrete borrow-checking or semantic defect found in the requested root corrections. This is a static source review only; no Cargo/JDK/CLI or runtime validation was performed here.

The inventory now avoids copying first-binding/cast origin sets until the charged shared ownership helper has checked their primary and derived anchors. A foreign binding drops the optional binding facts, so facade proof cannot produce a typed edit from it. The cast-origin check is short-circuited when the binding is already foreign, which is safe because neither origin set is copied and that candidate is ineligible. Clone identity work is charged only when `binding_origin_count != 0`. Header provenance stays represented by the existing primary/derived BCI inventory; facade refuses typed edits if any header origin is foreign, and the actual projector checks the complete OriginSet again.

The shared identity-work helper charges owner-chain steps before traversal and returns a bound containing variable identity bytes and fixed identity structures. OriginSet ownership checks charge the per-anchor comparison bound before iteration. Facade proof propagates Stop from the checks; final staged/final equality computes the identity bound only while visiting actual planned edits. The class-source visitor charges and polls one statement before inspecting it. The merge work is prepaid before the staged AST is changed. Projection mutates only a local cloned Program; every Stop or failed match returns before publishing a ClassSourceMethodAst.

The visitor holds a mutable borrow into `statement.kind` while changing `statement.origin`, a disjoint field; later recursive traversal occurs after those local borrows end. The source edits appear compatible with Rust field-splitting/NLL borrow rules. The For init/update containers are each wrapped with `from_mut`; Switch, Try, catches and finally remain covered.

The three derived-only foreign-origin metamorphisms exercise cast, binding and header refusal at the projection boundary. They are explicitly labeled as internal AST transformations, not legal JVM evidence. The focused success budget was raised to 100,000 analysis steps; low-budget, cancellation and deadline controls remain separate.

## Scope and limits

Reviewed `src/facade.rs` typed proof/final equality and `crates/jarde-java/src/report.rs` inventory/projector/helpers/tests, plus the current worktree diff. Did not re-audit unrelated existing `charge_class_source_ast` pre-scans. No compiler was run, so this review does not establish successful compilation. Broader and runtime gates remain the evidence for those claims.

Useful pins: facade proof `src/facade.rs:13055-13335`; final comparison `src/facade.rs:17295-17360`; inventory `crates/jarde-java/src/report.rs:3800-3970`; projection visitor `crates/jarde-java/src/report.rs:3300-3470`; identity/origin helpers `crates/jarde-java/src/report.rs:4330-4415`; AST adversarial tests and budget `crates/jarde-java/src/report.rs:17150-17410`.
