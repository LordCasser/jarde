import json,re,hashlib
from pathlib import Path
OLD=Path('/private/tmp/jarde-typed-foreach-controls-baseline-root-v1-20261018/execution.json')
NEW=Path('/private/tmp/jarde-typed-foreach-controls-final-root-v1-20261018/execution.json')
a=json.loads(OLD.read_text());b=json.loads(NEW.read_text());old={(r['profile'],r['evidence']):r for r in a['jarde_cells']};rows=[]
for r in b['jarde_cells']:
 key=(r['profile'],r['evidence']);x=json.loads(Path(old[key]['report']['path']).read_text());y=json.loads(Path(r['report']['path']).read_text())
 assert len(x['methods'])==len(y['methods'])==6
 names=[]
 for before,after in zip(x['methods'],y['methods']):
  assert before['item']['identity']==after['item']['identity']
  ar,br=before['outcome']['report'],after['outcome']['report']
  assert all(ar.get(k)==br.get(k) for k in ('text','source_map','quality','fallbacks'))
  name=bytes(after['item']['identity']['name']).decode();names.append(name)
  if name in ('strings','integers','declared'):
   ty='java.lang.Integer' if name=='integers' else 'java.lang.String'
   text=before['text'];heads=re.findall(r'for \(java\.lang\.Object ([A-Za-z0-9_]+) : ',text);assert len(heads)==1
   h=heads[0];text=text.replace('for (java.lang.Object '+h+' : ','for ('+ty+' '+h+' : ')
   anchor='('+ty+') '+h;assert text.count(anchor)==1;text=text.replace(anchor,h)
   lines=text.splitlines(True);assert lines[4].lstrip().startswith('// recovered') and lines[-1]=='    }\n'
   text=''.join(lines[:5]+[' '*12+line for line in lines[5:-1]]+lines[-1:])
   assert text==after['text'],(key,name,'only head type, first RHS cast, and existing emitter body indentation may change')
  else: assert before['text']==after['text'],(key,name,'must remain unchanged')
 rows.append({'selectors':key,'method_names':names,'three_typed_heads':True,'only_type_first_cast_and_exact_existing_renderer_12_space_body_indent_changes':True,'raw_mismatch_and_constructor_projection_exactly_unchanged':True,'raw_text_map_quality_fallbacks_exactly_unchanged':True})
r={'status':'accepted','old_receipt_sha256':hashlib.sha256(OLD.read_bytes()).hexdigest(),'new_receipt_sha256':hashlib.sha256(NEW.read_bytes()).hexdigest(),'rows':rows,'CLI':b['cli']}
Path(__file__).with_name('review.json').write_text(json.dumps(r,indent=2)+'\n');print('accepted',len(rows),'full API configurations')
