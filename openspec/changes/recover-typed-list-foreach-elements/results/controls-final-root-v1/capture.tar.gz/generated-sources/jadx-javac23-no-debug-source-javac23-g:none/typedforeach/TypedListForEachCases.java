package typedforeach;

import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.jar:typedforeach/TypedListForEachCases.class */
public class TypedListForEachCases {
    public static Object seen;
    public static Object after;

    public static void strings(List<String> list) {
        String next = "before";
        seen = next;
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            next = it.next();
            seen = next;
        }
        after = next;
    }

    public static void integers(List<Integer> list) {
        Integer next = null;
        seen = null;
        Iterator<Integer> it = list.iterator();
        while (it.hasNext()) {
            next = it.next();
            seen = next;
        }
        after = next;
    }

    public static void raw(List list) {
        String str = "before";
        seen = str;
        Iterator it = list.iterator();
        while (it.hasNext()) {
            str = (String) it.next();
            seen = str;
        }
        after = str;
    }

    public static void mismatch(List<String> list) {
        Integer num = null;
        seen = null;
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            num = (Integer) it.next();
            seen = num;
        }
        after = num;
    }

    public static void declared(List<String> list) {
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            seen = it.next();
        }
    }
}
