# Typed foreach leaf evidence archive inventory (proposal)

Prepared read-only from the OpenSpec results README and receipts under `/private/tmp`. No collector was rerun. Root owns the archive and acceptance decision.

## Suggested archive root and groups

Suggested new OpenSpec path: `openspec/changes/recover-typed-list-foreach-elements/results/typed-foreach-leaf-root-v1/`. Keep the existing `original-baseline-root-v1`, `generated-baseline-root-v1`, and `controls-baseline-root-v1` packages intact; those are already recorded in the current `results/README.md` and must not be overwritten with later captures.

1. **`focused-history/`** — retain all five focused receipts and raw streams, including failed iterations:
   - `/private/tmp/jarde-typed-foreach-focused-root-v1-20261018/`
   - `/private/tmp/jarde-typed-foreach-focused-root-v2-20261018/`
   - `/private/tmp/jarde-typed-foreach-focused-root-v3-20261018/`
   - `/private/tmp/jarde-typed-foreach-focused-root-v4-20261018/`
   - `/private/tmp/jarde-typed-foreach-focused-root-v5-20261018/`
   - Each has `execution.json` and `raw/`; v5 also has `candidate-cli` (SHA256 in its receipt: `d1304ad2c3acca940a744eb3023bea0f77f62d279afc675aff84a6c076d447c4`). Keep v1–v4 as failures, not as superseded passes.

2. **`testnestedloops-original/`** — completed original baseline and its independent acceptance:
   - Capture directory: `/private/tmp/jarde-typed-foreach-original-final-root-v1-20261018/` (receipt `execution.json`, `raw/`, original sources and class profiles, driver, Jarde outputs, complete JADX outputs).
   - Review: `/private/tmp/jarde-typed-foreach-original-final-review-root-v1-20261018/review.json` and `audit.py`.
   - Receipt SHA256 `433b6a723137adb4aed904b2c7935079821def5b1b91f1593630c224bc73f439`; review SHA256 `37cca8cd76d37a02b080192e284b32452e359258b7d0a0766cee90331bd4b42c`.
   - Review passed: 20 commands / 40 raw streams, four original runtime runs / 32 cases, eight Jarde API cells, two complete JADX output files. Preserve command 1 (`javac8-full-upstream-source-boundary`, exit 1) as the real harness-major boundary and command 9 (`driver-code-source-wrong-root-control`, exit 1) as the expected negative control; neither is a successful runtime row.

3. **`testnestedloops-generated/`** — generated-source matrix and independent review:
   - Capture: `/private/tmp/jarde-typed-foreach-original-generated-final-root-v1-20261018/` (receipt, `raw/`, complete source copies, compiled outputs, runtime rows and pins).
   - Review: `/private/tmp/jarde-typed-foreach-original-generated-final-review-root-v1-20261018/review.json`.
   - Receipt SHA256 `1d171a5ad5a3ef83fd72bde289ae67977ae9fe0cf36a622c9b4e576dbf8d1149`; review SHA256 `7ab57e87e717635b7b51e5fcc818d4f07cc8e2e60ab05f217d141f7174772c59`.
   - Review passed: 75 commands / 150 raw streams, 10 complete source cells, 20 compile attempts (18 success, two javac8 bundle-source failures), 36 generated runtime runs / 288 rows, 18 wrong-CodeSource controls. Preserve all failures and the original/generated source copies.

4. **`typed-foreach-controls-final/`** — final typed foreach control matrix and its current review state:
   - Capture: `/private/tmp/jarde-typed-foreach-controls-final-root-v1-20261018/` (receipt, `raw/`, Java inputs, driver classes, four class profiles, generated sources and compilations).
   - Review: `/private/tmp/jarde-typed-foreach-controls-final-review-root-v3-20261018/review.json` and `review.py`.
   - Final collector note: `/private/tmp/jarde-typed-foreach-controls-final-collector-root-v4-20261018/README.md` and `collect_controls.py`.
   - Receipt SHA256 `dc8fd91c60d95d1d26d630d2bf8ba57b8ab54b9f58ed6582160286a4c9b4cc3a`; review SHA256 `2a7b5fb592333dcaf02dfbd7fd8b80765fed15bcb2e1a759cf09859cd88237c0`.
   - Review receipt says `captured-pending-review` (137 commands, 274 streams): four original profiles, eight original VM runs / 152 case rows, 12 API cells, four JADX cells, 32 generated compiles (24 success, eight failure), 48 generated VM runs / 912 case rows, 24 wrong-root checks. It reports raw oracle equality and no integrity findings, but its status is not an acceptance pass; leave it pending until root records acceptance.

5. **`jadx-launch-history/`** — keep the earlier launch mistake and Java23 supplement alongside the final matrix:
   - Wrong-launch capture: `/private/tmp/jarde-typed-foreach-controls-jadx-launch-retry-root-v1-20261018/` (execution receipt, two jars, six raw streams).
   - Supplement: `/private/tmp/jarde-typed-foreach-controls-jadx-supplement-root-v1-20261018/collect.py`; the archived counterpart is already `results/controls-jadx-java23-supplement-root-v1/` with its capture and review.
   - Do not merge or overwrite these runs with the final collector. The supplement reran only the missed JADX start/compiler leg.

## Failure and boundary history to preserve verbatim

- **Focused v1:** the targeted integration test ran; 15 passed and one ignored. The existing proof-budget test failed only on the stale exact usage pin: observed 29,795 vs expected 25,299. The semantic typed foreach test passed.
- **Focused v2:** integration 16 passed / 0 failed / 1 ignored and the neighboring iterator test 3/3 passed. The subsequent `jarde-java --lib` test compile failed at `report.rs:17157` because `assert_eq!(ast, &before)` compared `ClassSourceMethodAst` with `&ClassSourceMethodAst`.
- **Focused v3:** same stale budget pin failed again, observed 29,859 vs expected 29,795; 16 other integration tests passed, one ignored. Keep the different observed count intact.
- **Focused v4:** three `jarde-java` unit tests failed while their helper budget allowed zero `OutputBytes` (`written: 0, limit: 0, at: Some(1)`). This was a test setup/budget issue; do not relabel this receipt as passing.
- **Focused v5:** receipt status is `commands_passed_pending_independent_acceptance`; fmt, `jarde-java` lib (496 passed), integration (17 passed, one ignored), iterator test (3 passed), CLI build, and clean all exit 0. Keep the receipt’s pending status unless root adds a separate acceptance record.
- **JADX typed-foreach controls:** final commands 130–137 preserve eight full-source compile failures (two original compiler profiles × debug/no-debug × javac8/javac23). The complete source infers `Iterator<String>` and later attempts an Integer cast, which javac rejects as inconvertible. Keep the full source and stderr; do not trim the mismatch method or report these as runtime coverage. The earlier wrong-JDK8 launch and no-source javac errors are distinct historical tool-launch failures. Java23 supplement and final collector preserve those history boundaries rather than converting them into successful compilation.
- Wrong-CodeSource exit-1 rows in all receipts are intentional negative controls; do not count them as product failures or successful semantic executions.

## Existing related archive references

- `openspec/changes/recover-typed-list-foreach-elements/results/README.md`
- `.../results/original-baseline-root-v1/` and `.../results/generated-baseline-root-v1/`
- `.../results/controls-baseline-root-v1/README.md` (includes the prior 19-case controls capture and its historical failure accounting)
- `.../results/controls-jadx-java23-supplement-root-v1/README.md`
- `.../results/baseline-archives-root-review-v1.json`

The new archive should cross-reference these existing packages rather than duplicate, rename, or rewrite their captured histories.
