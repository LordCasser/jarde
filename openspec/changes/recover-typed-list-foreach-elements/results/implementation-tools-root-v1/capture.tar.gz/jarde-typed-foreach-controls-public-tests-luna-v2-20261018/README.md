# Typed foreach public regression patch

Java source pin: `e38e258bc8cb57b1bf1cedbe2100a72a5ece84fc37d4bcf37d1297b25392eaf7`. Test-file patch base SHA-256: `c09a95a5c1871dc8e8451a015546ac7686d8594ff7bc36715a09c95727b1abd8`.

This patch adds one fixture constant and one test to `tests/structured_list_generic_bodies.rs`. The fixture bytes are supplied by the parent task from the original Java 8 debug class at `tests/fixtures/typed-list-foreach/TypedListForEachCases.class`; this patch does not contain that binary.

The test compares default, all, and essential-with-SourceMap output; checks each compatible typed header exactly once and verifies its preserved assignment binding, original outer declaration/initial assignment, and post-loop value; verifies raw and mismatched controls keep Object headers and casts; and checks physical checkcast opcodes, raw UTF-8/source-map identity, and complete instruction BCI coverage through existing test helpers.

Apply after the parent helper patch so `assert_all_instruction_bcis_are_mapped(bytes, class, member)` is available. This is a private frozen patch, not an applied workspace edit.
