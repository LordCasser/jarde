# Typed list foreach controls

Two standalone Java 8 source inputs for review and later compilation. `TypedListForEachCases` is the complete target class; its constructor is never invoked because every case calls a static method. Its five methods cover explicit raw-iterator casts with existing-local assignment, raw and generic mismatch refusals, and a direct typed enhanced-for projection case. `TypedListForEachDriver` creates a new parentless loader for every case, checks the loaded class's defining loader and actual `CodeSource`, resets the observable fields, invokes one method, and prints the observed exception, values, runtime types, and iterator event trace. Pass the actual class root and expected CodeSource root as the two arguments. A wrong expected root escapes as an error.

The driver cases intentionally record behavior without embedding expected outcomes; the original and generated runs can be compared by their case rows.
