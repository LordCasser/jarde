Private test-preparation packet for OpenSpec task 2.2. This is not applied to the checkout.

The checkout has no `AGENTS.md`; the task's supplied instructions were followed. Read the change design/tasks/spec and the existing public test plus the three named fixture sources. `task-2.2-public-tests.patch` extends only `tests/structured_list_generic_bodies.rs`: it reuses the existing fixed nested default/all/no-RuleDetails test, checks the two typed headers and preserved assignment/declaration copies in class and method projections, and extends the existing differently named String/Integer test. It also keeps raw Object foreach/cast assertions, checks raw UTF-8 map segments and every decoded instruction BCI, and checks that the physical cast BCIs remain attributed to their original type. It creates no fixtures and does not modify old expectations or thresholds.

The patch is a candidate only. No Cargo, javac, CLI, network, or Git commands were run; the test suite was not run. The implementation baseline was therefore not available for output validation, as requested. Inspect type/body spelling against root's accepted implementation before applying. No shared checkout file was modified.

Original SHA256:
- `tests/structured_list_generic_bodies.rs`: `c09a95a5c1871dc8e8451a015546ac7686d8594ff7bc36715a09c95727b1abd8`
- `UpstreamNestedLoops.class`: `8ece89e4d38751c20529622b57417afc8601368fc20078656ea2b24c17ed8231`
- `UpstreamNestedLoops.java`: `e81601f723b0e588e03cf177d01beea7f074af11a0f3445f5a8a96d6ea2be7d1`
- `DistinctStringFixture.class`: `6d374b3207996b70e7a137cbbe3309d808046d4335bb52c190195f80c27fe028`
- `DistinctStringFixture.java`: `d58ebc30ceb7c9f3b1d686539ec55438195320b02812a2f657f9bad69b3a9e64`
- `DistinctIntegerFixture.class`: `276f83ce80f41b44a8435ff3bc96bb2391e34fb92edb1a8371ffef1eeaa39a12`
- `DistinctIntegerFixture.java`: `4045da7d2745cb40bdbd4779c06c0916728ae8c45658a658c8abf9077a6e4949`
