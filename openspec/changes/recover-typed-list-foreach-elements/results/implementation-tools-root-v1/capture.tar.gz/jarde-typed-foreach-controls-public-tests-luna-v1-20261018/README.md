# Typed foreach public regression patch

Original Java source SHA-256: `e38e258bc8cb57b1bf1cedbe2100a72a5ece84fc37d4bcf37d1297b25392eaf7`.

This private patch adds one embedded fixture constant and one public test to `tests/structured_list_generic_bodies.rs`. It expects the exact Java 8 debug fixture bytes at `tests/fixtures/typed-list-foreach/TypedListForEachCases.class`; this preparation does not include or modify that binary.

The test compares default, all-evidence, and essential-with-SourceMap class, projected method, and raw report text; verifies String and Integer typed headers, preserved outer bindings, the direct typed-only declaration path, and raw/mismatched Object headers with casts; and checks raw report quality, UTF-8 boundaries, method identity, source-map equality, and every physical instruction BCI through existing test helpers.

Patch base file SHA-256: `c09a95a5c1871dc8e8451a015546ac7686d8594ff7bc36715a09c95727b1abd8`. Apply against that file plus the parent task's independent helper additions; this private patch is not an applied workspace edit.
