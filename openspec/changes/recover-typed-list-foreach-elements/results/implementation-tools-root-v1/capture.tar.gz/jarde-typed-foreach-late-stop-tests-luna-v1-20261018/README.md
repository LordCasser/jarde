Private prepared patch for the existing `tests/structured_list_generic_bodies.rs`.

The test targets `strings` in the checked-in typed-list-foreach fixture. It uses the existing
entry observer to find the earliest projection commit boundary, then delays exactly once at the
preceding ledger boundary so the 1-second elapsed budget expires before the projection commits.
The test compares the retained raw method text and source map to a complete run, and checks that
the complete class has two String foreach headers (from `strings` and `declared`).

Base source SHA256: `d507fb7595cf38c815e61811cc92dce9bca2b58d8a33c6f345272818d51ee464`.
This is a private patch only; it was not applied and no test or toolchain was run.
