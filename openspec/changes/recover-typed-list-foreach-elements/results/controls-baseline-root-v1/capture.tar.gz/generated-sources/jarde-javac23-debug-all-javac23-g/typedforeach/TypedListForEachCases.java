// jarde: presentation of `typedforeach/TypedListForEachCases` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package typedforeach;

public class TypedListForEachCases extends java.lang.Object {
    public static java.lang.Object seen;

    public static java.lang.Object after;

    public TypedListForEachCases() {
        // @method <init>()V
        // @declaration a constructor of `typedforeach.TypedListForEachCases`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static void strings(java.util.List<java.lang.String> values) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method strings(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.lang.String current;
        current = "before";
        typedforeach.TypedListForEachCases.seen = current;
        for (java.lang.Object iteratorElement24 : values) {
            current = (java.lang.String) iteratorElement24;
            typedforeach.TypedListForEachCases.seen = current;
        }
        typedforeach.TypedListForEachCases.after = current;
        return;
    }

    public static void integers(java.util.List<java.lang.Integer> values) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/Integer;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method integers(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        Object current;
        current = null;
        typedforeach.TypedListForEachCases.seen = current;
        for (java.lang.Object iteratorElement23 : values) {
            current = (java.lang.Integer) iteratorElement23;
            typedforeach.TypedListForEachCases.seen = current;
        }
        typedforeach.TypedListForEachCases.after = current;
        return;
    }

    public static void raw(java.util.List values) {
        // @method raw(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.lang.String current;
        current = "before";
        typedforeach.TypedListForEachCases.seen = current;
        for (java.lang.Object iteratorElement24 : values) {
            current = (java.lang.String) iteratorElement24;
            typedforeach.TypedListForEachCases.seen = current;
        }
        typedforeach.TypedListForEachCases.after = current;
        return;
    }

    public static void mismatch(java.util.List<java.lang.String> values) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method mismatch(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        Object current;
        current = null;
        typedforeach.TypedListForEachCases.seen = current;
        for (java.lang.Object iteratorElement23 : values) {
            current = (java.lang.Integer) iteratorElement23;
            typedforeach.TypedListForEachCases.seen = current;
        }
        typedforeach.TypedListForEachCases.after = current;
        return;
    }

    public static void declared(java.util.List<java.lang.String> values) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method declared(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        for (java.lang.Object iteratorElement17 : values) {
            java.lang.String value = (java.lang.String) iteratorElement17;
            typedforeach.TypedListForEachCases.seen = value;
        }
        return;
    }
}
