#!/usr/bin/env python3
"""Capture original and generated observations for typed foreach controls; review before execution."""
import argparse,datetime,hashlib,importlib.util,json,os,re,shutil,sys,zipfile
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
BASE=Path('/private/tmp/jarde-testnestedloops-current-baseline-root-v1-20261018/execution.json')
PREP=Path('/private/tmp/jarde-typed-foreach-controls-prep-luna-v1-20261018')
TARGET=PREP/'TypedListForEachCases.java'; DRIVER=PREP/'TypedListForEachDriver.java'
INTERNAL='typedforeach/TypedListForEachCases'; TARGET_DOT=INTERNAL.replace('/','.')
COMPARE='openspec/changes/recover-exception-only-finally-completion/tools/compare.py'; CH='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD='openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'; GH='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER='openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'; SH='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
MANIFEST='openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'; MH='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py'); PH='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
BASE_SHA='4f48e3b14738cb4d3746763290788f525bba4bb1a1a3d47aebcf0111e6f8d482'
PROFILES=('javac8-debug','javac8-no-debug','javac23-debug','javac23-no-debug'); LEGS=('javac8','javac23'); VMS=LEGS
EVIDENCE=('default','all','essential'); CASE_NAMES=('strings-empty','strings-normal','strings-null-element','strings-wrong-after-success','strings-null-source','integers-empty','integers-normal','integers-null-element','integers-wrong-after-success','integers-null-source','raw-string','raw-wrong-after-success','mismatch-integer-element','mismatch-string-element','declared-empty','declared-normal','trace-iterator-throws','trace-hasNext-after-one','trace-next-after-one'); ENV_STRIP=('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','CARGO_TARGET_DIR')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
def pin(c,p): return c.pin(Path(p))
def classfacts(c,ph,root):
 out={}
 for p in sorted(root.rglob('*.class')):
  a=c.parse_class(p); b=ph.parse_class_file(p.read_bytes())
  if a['class_name']!=b['class_name'] or a['major']!=b['major'] or a['major']!=52 or a['methods']!=b['methods'] or sorted((x['name'],x['descriptor'],x['access']) for x in b['fields'])!=sorted(a['fields']): raise RuntimeError('class parsers disagree: '+str(p))
  for m in b['methods']:
   z=m.get('code')
   if not z or ph.decode_bcis(bytes.fromhex(z['code_hex']))!=z['bcis']: raise RuntimeError('invalid Code/BCIs: '+str(p))
  a['access']=b['access']; out[p.relative_to(root).as_posix()]=a
 return out
def facts(c,ph,root):
 out=classfacts(c,ph,root)
 if INTERNAL+'.class' not in out or out[INTERNAL+'.class']['major']!=52: raise RuntimeError('target absent/not Java 8')
 t=out[INTERNAL+'.class']; want={('<init>','()V'),*((n,'(Ljava/util/List;)V') for n in ('strings','integers','raw','mismatch','declared'))}
 if not want.issubset({(m['name'],m['descriptor']) for m in t['methods']}) or {(f[0],f[1]) for f in t['fields']}!={('seen','Ljava/lang/Object;'),('after','Ljava/lang/Object;')}: raise RuntimeError('target member inventory differs')
 return out
def inventory(tree):
 return {p:(x['class_name'],x['major'],x['access'],tuple(sorted(tuple(f) for f in x['fields'])),tuple(sorted((m['name'],m['descriptor'],m['access']) for m in x['methods']))) for p,x in tree.items()}
def cases(raw):
 lines=raw.decode('utf-8','strict').splitlines()
 if len(lines)!=19 or [x.split(' ',2)[1].removeprefix('name=') for x in lines]!=list(CASE_NAMES): raise ValueError('expected exact 19 ordered driver case rows')
 return lines
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--cli',type=Path,required=True); ap.add_argument('--out',type=Path,required=True); cli_args=ap.parse_args()
 root=ROOT.resolve(strict=True); out=cli_args.out.resolve(); cli=cli_args.cli.resolve(strict=True)
 if out.exists(): raise SystemExit('refusing existing output '+str(out))
 if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('target must be absent')
 if shutil.disk_usage(root).free<5*1024**3: raise SystemExit('less than 5 GiB free')
 cp=root/COMPARE; gp=root/GUARD; sp=root/SCANNER; mp=root/MANIFEST
 for p,h in ((cp,CH),(gp,GH),(sp,SH),(mp,MH),(PARSER,PH)):
  if sha(p)!=h: raise SystemExit('tool pin mismatch '+str(p))
 compare=load(cp,'typed_compare'); guard=load(gp,'typed_guard'); scanner=load(sp,'typed_scanner'); physical=load(PARSER,'typed_physical')
 jdks,jdkrec=compare.configured_jdks(mp,MH); base=json.loads(BASE.read_text()); needsha=sha(BASE)
 if needsha!=BASE_SHA: raise SystemExit('baseline receipt pin mismatch')
 if base.get('status')!='captured-pending-independent-review' or base.get('schema')!='cf11-testnestedloops-current-full-source-baseline-v1': raise SystemExit('baseline not complete expected receipt')
 if base.get('source_unchanged_finally') is not True or base.get('target_absent_finally') is not True: raise SystemExit('baseline final guard failed')
 if len(base.get('original_runtime',[]))!=4 or len(base.get('source_profiles',[]))!=2: raise SystemExit('baseline original source matrix incomplete')
 for f,h in ((TARGET,'e38e258bc8cb57b1bf1cedbe2100a72a5ece84fc37d4bcf37d1297b25392eaf7'),(DRIVER,'9c40cd3b2a0938ed392174c2713de5e627ae9d8376d3804c5479131eed5beed7')):
  if sha(f)!=h: raise SystemExit('frozen input changed '+str(f))
 for k in ('cli','jadx','jadx_jar','runtime_wrapper'):
  if compare.pin(Path(base[k]['path']))!=base[k]: raise SystemExit('baseline tool changed '+k)
 runtime=Path(base['runtime_wrapper']['path']); jadx=Path(base['jadx']['path']); source_before=compare.source_closure(root)
 for spec in jdks.values():
  for tool in spec['tools'].values():
   if not Path(tool).is_file(): raise SystemExit('configured JDK tool missing '+str(tool))
 # Capture current pre-run closure; do not require it to equal an older product baseline after an authorized product change.
 out.mkdir(parents=True); (out/'raw').mkdir(); empty=out/'empty-classpath'; empty.mkdir()
 guard.ROOT=root; guard.OUT=out/'raw'; guard.target_bytes=lambda:scanner.target_bytes(root); guard.command_stream=compare.pin; guard.expected_test_summaries=lambda i,d:None
 driver_copy=out/'input/TypedListForEachDriver.java'; driver_copy.parent.mkdir(); shutil.copyfile(DRIVER,driver_copy)
 target_copy=out/'input/TypedListForEachCases.java'; shutil.copyfile(TARGET,target_copy)
 runtime_copy=out/runtime.name; shutil.copyfile(runtime,runtime_copy)
 if any(a.read_bytes()!=b.read_bytes() for a,b in ((driver_copy,DRIVER),(target_copy,TARGET),(runtime_copy,runtime))): raise RuntimeError('frozen copy mismatch')
 initial={'target':pin(compare,target_copy),'driver':pin(compare,driver_copy),'runtime':pin(compare,runtime_copy)}
 external=[BASE,cp,gp,sp,mp,PARSER,cli,jadx,Path(base['jadx_jar']['path']),runtime,TARGET,DRIVER,*[Path(t) for spec in jdks.values() for t in spec['tools'].values()]]
 protected={str(p):pin(compare,p) for p in (driver_copy,target_copy,runtime_copy)}
 report={'schema':'typed-list-foreach-controls-matrix-v1','status':'running','root':str(root),'output':str(out),'baseline':compare.pin(BASE),'cli':compare.pin(cli),'jdk_manifest':jdkrec,
  'source_pins_before':source_before,'external_pins_before':[pin(compare,p) for p in external],'local_copies_before':initial,'commands':[],'source_profiles':[],'original_runs':[],'original_wrong_root':[],'jarde_cells':[],'jadx_cells':[],'generated_compiles':[],'generated_runs':[],'generated_wrong_root':[],
  'notes':['Inputs are frozen complete Java source files. Driver constructor is not invoked. Outcomes are recorded, not hardcoded.','--evidence essential is the documented no-optional-evidence selection; this label does not claim equivalence to a no-rule-details request. Compiler/API refusal is retained as a cell result.']}
 compare.write_json(out/'execution.json',report); rows=report['commands']
 def cmd(argv,label,leg):
  if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError('target appeared')
  env=compare.clean_env(dict(os.environ),jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK',None)
  r=guard.run_command(len(rows)+1,[str(x) for x in argv],env); r['label']=label; r['tool_leg']=leg; rows.append(r)
  for ch in ('stdout','stderr'):
   rp=Path(r['streams'][ch]['path']); protected[str(rp)]=pin(compare,rp); compare.command_artifact(r,ch)
  compare.write_json(out/'execution.json',report)
  if r.get('guard_stop') is not None or r.get('free_bytes_after',0)<5*1024**3 or r.get('peak_target_bytes',0)>1<<30: raise RuntimeError('command resource guard stopped '+label)
  return r
 def stream_bytes(r,k): return compare.command_artifact(r,k)
 def streams(r): return {k:pin(compare,Path(r['streams'][k]['path'])) for k in ('stdout','stderr')}
 try:
  driver_classes=out/'driver-classes'; driver_classes.mkdir()
  dr=cmd([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',driver_classes,driver_copy],'compile-driver','javac8')
  report['driver_compile']={'command':dr['index'],'exit_code':dr['exit_code'],'streams':streams(dr),'classes':[pin(compare,p) for p in sorted(driver_classes.rglob('*.class'))],'class_facts':classfacts(compare,physical,driver_classes) if dr['exit_code']==0 else None}
  protected.update({str(p):pin(compare,p) for p in driver_classes.rglob('*.class')})
  if dr['exit_code']: raise RuntimeError('driver compilation failed')
  oracle={}
  for prof in PROFILES:
   leg='javac8' if prof.startswith('javac8') else 'javac23'; debug='-g:none' if prof.endswith('no-debug') else '-g'; dest=out/'original'/prof/'classes'; dest.mkdir(parents=True)
   javac=jdks[leg]['tools']['javac']; flags=['-source','8','-target','8'] if leg=='javac8' else ['--release','8']
   cr=cmd([javac,*flags,debug,'-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',dest,target_copy],'compile-original-'+prof,leg)
   rec={'profile':prof,'command':cr['index'],'exit_code':cr['exit_code'],'streams':streams(cr),'class_tree':{p.relative_to(dest).as_posix():pin(compare,p) for p in sorted(dest.rglob('*.class'))},'class_facts':facts(compare,physical,dest) if cr['exit_code']==0 else None,'class_root':str(dest)}
   protected.update({str(p):pin(compare,p) for p in dest.rglob('*') if p.is_file()})
   rec['class_inventory']=inventory(rec['class_facts']) if rec['class_facts'] else None
   report['source_profiles'].append(rec); compare.write_json(out/'execution.json',report)
   if cr['exit_code']: raise RuntimeError('original target must compile: '+prof)
   for vm in VMS:
    run=cmd([sys.executable,'-B',runtime_copy,'30',jdks[vm]['tools']['java'],'-Xverify:all','-cp',driver_classes,'TypedListForEachDriver',dest.resolve(),dest.resolve()],'original-'+prof+'-'+vm,vm)
    lines=cases(stream_bytes(run,'stdout')) if run['exit_code']==0 else []
    rr={'profile':prof,'vm':vm,'command':run['index'],'exit_code':run['exit_code'],'streams':streams(run),'rows':lines}; report['original_runs'].append(rr)
    if run['exit_code']: raise RuntimeError('original runtime failed')
    oracle[(prof,vm)]=lines; report['original_runs'][-1].update({'actual_root':str(dest.resolve()),'expected_root':str(dest.resolve()),'application_classpath':[str(driver_classes.resolve())]}); compare.write_json(out/'execution.json',report)
   wr=cmd([sys.executable,'-B',runtime_copy,'30',jdks['javac23']['tools']['java'],'-Xverify:all','-cp',driver_classes,'TypedListForEachDriver',dest.resolve(),empty],'original-wrong-root-'+prof,'javac23')
   rejected=wr['exit_code']==1 and b'wrong CodeSource:' in stream_bytes(wr,'stderr'); report['original_wrong_root'].append({'profile':prof,'command':wr['index'],'exit_code':wr['exit_code'],'rejected':rejected,'streams':streams(wr),'actual_root':str(dest.resolve()),'expected_root':str(empty.resolve()),'application_classpath':[str(driver_classes.resolve())]})
   if not rejected: raise RuntimeError('original wrong CodeSource not rejected')
  if len(set(tuple(v) for v in oracle.values()))!=1: raise RuntimeError('original 4x2 oracle rows differ')
  if len({json.dumps(x['class_inventory'],sort_keys=True) for x in report['source_profiles']})!=1: raise RuntimeError('original profile class/member inventories differ')
  for prof in PROFILES:
   leg='javac8' if prof.startswith('javac8') else 'javac23'; rootcls=Path(next(x for x in report['source_profiles'] if x['profile']==prof)['class_root']); target=rootcls/(INTERNAL+'.class')
   for ev in EVIDENCE:
    dst=out/'jarde'/prof/ev; dst.mkdir(parents=True); argv=[cli,'class-source','--input',target,'--class',INTERNAL,'--policy','single-class','--release','8','--format','json']
    if ev!='default': argv+=['--evidence',ev]
    r=cmd(argv,'jarde-'+prof+'-'+ev,leg); raw=stream_bytes(r,'stdout'); (dst/'report.json').write_bytes(raw); cell={'profile':prof,'evidence':ev,'command':r['index'],'exit_code':r['exit_code'],'streams':streams(r),'report':pin(compare,dst/'report.json')}
    try:
     api=json.loads(raw.decode('utf8')); text=api.get('text'); cell['method_texts']=[m.get('outcome',{}).get('report',{}).get('text') for m in api.get('methods',[])]; cell['api_status']=api.get('execution',{}).get('status'); cell['fallbacks']=[m.get('outcome',{}).get('report',{}).get('fallbacks') for m in api.get('methods',[])]
     if isinstance(text,str) and text.strip(): (dst/'whole-source.java').write_bytes(text.encode('utf8')); cell['whole_source']=pin(compare,dst/'whole-source.java'); cell['source_ready']=True
     else: cell['source_ready']=False; cell['source_error']='API text absent/empty'
    except Exception as e: cell['parse_error']=repr(e); cell['source_ready']=False
    protected.update({str(p):pin(compare,p) for p in (dst/'report.json',dst/'whole-source.java') if p.exists()})
    report['jarde_cells'].append(cell); compare.write_json(out/'execution.json',report)
   # JADX takes a complete class archive; retain the entire compiled class tree.
   jar=out/'bundles'/prof/'classes.jar'; jar.parent.mkdir(parents=True)
   with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(rootcls.rglob('*.class')): z.write(p,p.relative_to(rootcls).as_posix())
   dstd=out/'jadx'/prof; r=cmd([jadx,'--threads-count','1','--no-res','--config','none','-d',dstd,jar],'jadx-'+prof,leg)
   protected[str(jar)]=pin(compare,jar); sources=sorted(dstd.rglob('*.java')); protected.update({str(p):pin(compare,p) for p in sources}); cell={'profile':prof,'command':r['index'],'exit_code':r['exit_code'],'input':pin(compare,jar),'streams':streams(r),'sources':[pin(compare,p) for p in sources]}; report['jadx_cells'].append(cell); compare.write_json(out/'execution.json',report)
  cells=[]
  for x in report['jarde_cells']:
   if x.get('source_ready'): cells.append(('jarde',x['profile'],x['evidence'],[Path(x['whole_source']['path'])],x))
  for x in report['jadx_cells']:
   paths=[Path(p['path']) for p in x['sources']]; cells.append(('jadx',x['profile'],'source',paths,x))
  for kind,prof,variant,paths,cell in cells:
   for leg in LEGS:
    for debug in (('-g:none' if prof.endswith('no-debug') else '-g'),):
     key=f'{kind}-{prof}-{variant}-{leg}-{debug[1:]}' ; srcroot=out/'generated-sources'/key; srcroot.mkdir(parents=True)
     source_copies=[]
     if len({p.name for p in paths})!=len(paths): raise RuntimeError('duplicate full-source basename')
     for p in paths:
      data=p.read_bytes(); mat=re.search(rb'^\s*package\s+([A-Za-z0-9_.]+)\s*;',data,re.M); pkg=mat.group(1).decode().replace('.','/') if mat else ''
      fname='TypedListForEachCases.java' if kind=='jarde' else p.name
      if kind=='jarde' and (pkg!='typedforeach' or not re.search(rb'public\s+class\s+TypedListForEachCases\b',data)): raise RuntimeError('Jarde whole source is not the complete expected public class')
      dest=srcroot/pkg/fname if pkg else srcroot/fname; dest.parent.mkdir(parents=True,exist_ok=True)
      if dest.exists(): raise RuntimeError('duplicate generated source destination '+str(dest))
      dest.write_bytes(data)
      if dest.read_bytes()!=data: raise RuntimeError('generated source copy differs')
      protected[str(dest)]=pin(compare,dest); source_copies.append({'source':pin(compare,p),'copy':pin(compare,dest)})
     outcls=out/'generated-classes'/key; outcls.mkdir(parents=True); flags=['-source','8','-target','8'] if leg=='javac8' else ['--release','8']
     r=cmd([jdks[leg]['tools']['javac'],*flags,debug,'-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',outcls,*sorted(srcroot.rglob('*.java'))],'compile-'+key,leg)
     protected.update({str(p):pin(compare,p) for p in outcls.rglob('*.class')})
     crfacts=facts(compare,physical,outcls) if r['exit_code']==0 else None
     original=next(x for x in report['source_profiles'] if x['profile']==prof)
     inv_match=(inventory(crfacts)==original['class_inventory']) if crfacts is not None else None
     cr={'kind':kind,'profile':prof,'variant':variant,'leg':leg,'debug':debug,'source_copies':source_copies,'command':r['index'],'exit_code':r['exit_code'],'streams':streams(r),'class_root':str(outcls),'class_tree':{p.relative_to(outcls).as_posix():pin(compare,p) for p in sorted(outcls.rglob('*.class'))},'class_facts':crfacts,'class_inventory_matches_original':inv_match}; report['generated_compiles'].append(cr); compare.write_json(out/'execution.json',report)
     if r['exit_code']: continue
     for vm in VMS:
      actual=outcls.resolve(); rr=cmd([sys.executable,'-B',runtime_copy,'30',jdks[vm]['tools']['java'],'-Xverify:all','-cp',driver_classes,'TypedListForEachDriver',actual,actual],'generated-'+key+'-'+vm,vm)
      lines=cases(stream_bytes(rr,'stdout')) if rr['exit_code']==0 else []; match=lines==oracle[(prof,vm)] and rr['exit_code']==0
      report['generated_runs'].append({'kind':kind,'profile':prof,'variant':variant,'compiler':leg,'debug':debug,'vm':vm,'command':rr['index'],'exit_code':rr['exit_code'],'streams':streams(rr),'rows':lines,'matches_original':match,'actual_root':str(actual),'expected_root':str(actual),'application_classpath':[str(driver_classes.resolve())]}); compare.write_json(out/'execution.json',report)
     wr=cmd([sys.executable,'-B',runtime_copy,'30',jdks['javac23']['tools']['java'],'-Xverify:all','-cp',driver_classes,'TypedListForEachDriver',outcls.resolve(),empty],'generated-wrong-root-'+key,'javac23'); rejected=wr['exit_code']==1 and b'wrong CodeSource:' in stream_bytes(wr,'stderr')
     report['generated_wrong_root'].append({'kind':kind,'profile':prof,'variant':variant,'compiler':leg,'debug':debug,'command':wr['index'],'exit_code':wr['exit_code'],'rejected':rejected,'streams':streams(wr),'actual_root':str(outcls.resolve()),'expected_root':str(empty.resolve()),'application_classpath':[str(driver_classes.resolve())]}); compare.write_json(out/'execution.json',report)
  report['successful_class_inventories_match_original']=all(x['class_inventory_matches_original'] for x in report['generated_compiles'] if x['exit_code']==0)
  if not report['successful_class_inventories_match_original']: raise RuntimeError('successful generated compile changed complete class/member/field inventory')
  report['protected_products_before_final']={k:v for k,v in protected.items()}
  report['protected_products_after']= {k:pin(compare,Path(k)) for k in protected}
  report['products_unchanged']=report['protected_products_after']==protected
  report['source_pins_after']=compare.source_closure(root); report['external_pins_after']=[pin(compare,p) for p in external]; report['local_copies_after']={k:pin(compare,p) for k,p in [('target',target_copy),('driver',driver_copy),('runtime',runtime_copy)]}
  report['source_unchanged']=report['source_pins_after']==source_before; report['external_inputs_unchanged']=report['external_pins_after']==report['external_pins_before']; report['local_copies_unchanged']=report['local_copies_after']==initial; report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
  if not all((report['source_unchanged'],report['external_inputs_unchanged'],report['local_copies_unchanged'],report['products_unchanged'],report['target_absent'])): raise RuntimeError('closure guard changed')
  report['status']='captured-pending-review'
 except BaseException as e: report['status']='failed'; report['error']=repr(e); raise
 finally:
  try:
   report['protected_products_after_finally']={k:pin(compare,Path(k)) for k in protected}; report['products_unchanged_finally']=report['protected_products_after_finally']==protected
   report['source_pins_after_finally']=compare.source_closure(root); report['external_pins_after_finally']=[pin(compare,p) for p in external]; report['local_copies_after_finally']={k:pin(compare,p) for k,p in [('target',target_copy),('driver',driver_copy),('runtime',runtime_copy)]}; report['source_unchanged_finally']=report['source_pins_after_finally']==source_before; report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
   if not report['products_unchanged_finally'] or not report['source_unchanged_finally'] or not report['target_absent_finally'] or report['external_pins_after_finally']!=report['external_pins_before'] or report['local_copies_after_finally']!=initial: report['status']='failed'; report['final_guard_error']='final closure changed'
  except BaseException as e: report['status']='failed'; report['final_guard_error']=repr(e)
  report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat(); compare.write_json(out/'execution.json',report); shutil.copy2(__file__,out/'collector.py')
 return 0
if __name__=='__main__': raise SystemExit(main())
