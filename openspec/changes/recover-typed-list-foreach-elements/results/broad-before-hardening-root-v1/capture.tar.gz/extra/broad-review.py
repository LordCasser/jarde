import json,hashlib,re,subprocess
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
RECEIPT=Path('/private/tmp/jarde-typed-foreach-broad-root-v1-20261018/execution.json')
d=json.loads(RECEIPT.read_text())
def pin(p):
 b=Path(p['path']).read_bytes();assert len(b)==p['bytes'] and hashlib.sha256(b).hexdigest()==p['sha256']
for k in ('runner','spec','guard','scanner'):pin(d[k])
assert d['status']=='commands_passed_pending_independent_acceptance' and d['default_stack'] and d['target_absent'] and not (ROOT/'target').exists()
assert d['source_changes']==d['allowed_source_changes']==['tests/fixtures/corpus-fingerprint.json'] and d['source_changes_accepted']
for p in d['source_after']:pin(p)
before={p['path']:p for p in d['source_before']};after={p['path']:p for p in d['source_after']}
assert set(before)==set(after) and [str(Path(k).relative_to(ROOT)) for k in before if before[k]!=after[k]]==d['source_changes']
counts=[0,0,0]
for c in d['commands']:
 assert c['exit_code']==0
 for p in c['streams'].values():pin(p)
 if not c.get('cleanup_only'):
  assert c['guard_stop'] is None and c['peak_target_bytes']<=2**30 and c['free_bytes_after']>=5*1024**3
 if c['argv'][:2]==['cargo','test']:
  s=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',Path(c['streams']['stdout']['path']).read_text());assert s==[tuple(x) for x in c['test_summaries']] and s
  for status,passed,failed,ignored in s:
   assert status=='ok' and int(passed)>0 and int(failed)==0
   counts=[a+int(b) for a,b in zip(counts,(passed,failed,ignored))]
assert len(d['commands'])==18 and d['commands'][-1]['argv']==['cargo','clean']
pin(d['cli']);assert d['cli']['sha256']=='d1304ad2c3acca940a744eb3023bea0f77f62d279afc675aff84a6c076d447c4'
a=json.loads(subprocess.check_output(['git','show','HEAD:tests/fixtures/corpus-fingerprint.json'],cwd=ROOT));b=json.loads((ROOT/'tests/fixtures/corpus-fingerprint.json').read_text());x={v['path']:v for v in a['files']};y={v['path']:v for v in b['files']};assert all(y[k]==v for k,v in x.items());delta=sorted(y.keys()-x.keys());assert delta==['tests/fixtures/typed-list-foreach/TypedListForEachCases.class','tests/fixtures/typed-list-foreach/TypedListForEachCases.java']
r={'status':'root-accepted-broad-v1-before-architecture-hardening','receipt_sha256':hashlib.sha256(RECEIPT.read_bytes()).hexdigest(),'commands_including_clean':len(d['commands']),'test_pass_fail_ignore':counts,'source_files':len(d['source_after']),'fingerprint_before':len(x),'fingerprint_after':len(y),'fingerprint_new_only':delta,'cli':d['cli'],'scope':'actual gates pass for d130 candidate; architecture review requests additional origin/cost hardening before final native/product delivery'}
Path(__file__).with_name('review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
