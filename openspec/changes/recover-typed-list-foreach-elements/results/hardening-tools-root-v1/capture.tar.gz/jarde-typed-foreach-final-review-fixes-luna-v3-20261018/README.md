# Private v3 review-fix patch

`task-review-fixes-v3.patch` applies to the current shared-candidate copies in `base/`. It changes only `src/facade.rs` and `crates/jarde-java/src/report.rs`; shared files were not touched. No compiler, formatter, tests, Git mutation, JDK, CLI, or network command was run.

The patch addresses the requested review findings:

1. A single doc-hidden `report.rs` owner-identity work helper charges archive-step traversal and returns the complete variable-byte plus fixed-identity bound. Its paired OriginSet helper charges before examining all primary and derived anchors, permits unbound origins, and rejects any explicitly foreign method. Facade proof uses it for header, first binding, and cast; report projection repeats it on the actual header, binding, and cast. The proof also refuses any nonempty `foreign_origin_bcis` inventory. AST inventory cloning of header/binding/cast origins and facade cloning of cast origins receive identity-byte charges.
2. Final staged-versus-recomputed plan equality reuses the same identity-work helper and charges origin-count-scaled identity bytes plus the type and edit record before equality.
3. The typed projection no longer pre-scans the AST for a node count. Its recursive visitor charges one AnalysisStep through `charge_class_source_metadata` before processing each statement; prepaid origin-merge work remains.

Source pins in the base tree: typed-foreach candidate proof and Signature join `src/facade.rs:13055-13340`; staged body emission and final revalidation `src/facade.rs:16719-17360`; typed edit transaction/visitor `crates/jarde-java/src/report.rs:3046-3470`; foreach inventory `crates/jarde-java/src/report.rs:3770-3980`; physical method identity fields `crates/jarde-reader/src/model.rs:4-10,172-193,203-232,275-303,337-341`.
