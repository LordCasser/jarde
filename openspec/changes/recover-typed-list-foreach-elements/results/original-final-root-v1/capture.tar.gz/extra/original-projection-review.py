import json,re,hashlib
from pathlib import Path
OLD=Path('/private/tmp/jarde-testnestedloops-current-baseline-root-v1-20261018/execution.json')
NEW=Path('/private/tmp/jarde-typed-foreach-original-final-root-v1-20261018/execution.json')
a=json.loads(OLD.read_text());b=json.loads(NEW.read_text());old={(r['profile'],r['input_form'],r['evidence']):r for r in a['jarde_cells']};rows=[]
for r in b['jarde_cells']:
 key=(r['profile'],r['input_form'],r['evidence']);x=json.loads(Path(old[key]['report']['path']).read_text());y=json.loads(Path(r['report']['path']).read_text())
 assert len(x['methods'])==len(y['methods'])==2
 for before,after in zip(x['methods'],y['methods']):
  assert before['item']['identity']==after['item']['identity']
  ar,br=before['outcome']['report'],after['outcome']['report']
  assert all(ar[k]==br[k] for k in ('text','source_map','quality','fallbacks'))
  if bytes(after['item']['identity']['name'])==b'test':
   text=before['text'];heads=re.findall(r'for \(java\.lang\.Object ([A-Za-z0-9_]+) : ',text);assert len(heads)==2
   for name in heads:
    text=text.replace('for (java.lang.Object '+name+' : ','for (java.lang.String '+name+' : ')
    anchor='(java.lang.String) '+name;assert text.count(anchor)==1;text=text.replace(anchor,name)
   assert text==after['text'], 'only head type and first RHS cast may change, including no-debug names'
  else: assert before['text']==after['text']
 rows.append({'selectors':key,'two_typed_heads':True,'only_type_and_first_cast_changes':True,'raw_text_map_quality_fallbacks_exactly_unchanged':True})
r={'status':'accepted','old_receipt_sha256':hashlib.sha256(OLD.read_bytes()).hexdigest(),'new_receipt_sha256':hashlib.sha256(NEW.read_bytes()).hexdigest(),'rows':rows,'CLI':b['cli']}
Path(__file__).with_name('review.json').write_text(json.dumps(r,indent=2)+'\n');print('accepted',len(rows),'full API configurations')
