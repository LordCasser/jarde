// jarde: presentation of `RetryFixture` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class RetryFixture extends java.lang.Object {
    int c;

    int caught;

    int breaks;

    final int failuresBeforeSuccess;

    final int errorOnCall;

    // jarde: field Signature projection refused for `eventsLjava/util/List;`: unsupported (field_generic_body_unproved): a same-class Fieldref names this field and descriptor; same-class uses at <init>(II)V@27, test()I@15, test()I@61, exc()V@11
    final java.util.List events;

    public RetryFixture(int failuresBeforeSuccess, int errorOnCall) {
        // @method <init>(II)V
        // @declaration a constructor of `RetryFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.c = 0;
        this.caught = 0;
        this.breaks = 0;
        this.events = new java.util.ArrayList();
        this.failuresBeforeSuccess = failuresBeforeSuccess;
        this.errorOnCall = errorOnCall;
        return;
    }

    public int test() {
        // @method test()I
        // @declaration an instance method of `RetryFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        while (true) {
            try {
                this.exc();
                this.breaks += 1;
                this.events.add((java.lang.Object) new java.lang.StringBuilder().append("break:").append(this.c).toString());
                break;
            } catch (java.lang.Exception e) {
                this.caught += 1;
                this.events.add((java.lang.Object) new java.lang.StringBuilder().append("catch:").append(this.c).toString());
                continue;
            }
        }
        if (this.c == 5) {
            java.lang.System.out.println(this.c);
        }
        return 0;
    }

    private void exc() throws java.lang.Exception {
        // @method exc()V
        // @declaration an instance method of `RetryFixture`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.c += 1;
        this.events.add((java.lang.Object) new java.lang.StringBuilder().append("call:").append(this.c).toString());
        if (this.c == this.errorOnCall) {
            // @bytecode 53
            // the instruction at BCI 53 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
            // @bytecode 56
            // the instruction at BCI 56 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
            // @bytecode 82 79 76 73 66 70 69
            // the copy at BCI 56 has no proved local assignment
        } else if (this.c < this.failuresBeforeSuccess + 1) {
            throw new java.lang.Exception();
    } else {
            this.events.add((java.lang.Object) new java.lang.StringBuilder().append("success:").append(this.c).toString());
            return;
    }
    }
}
