#!/usr/bin/env python3
import json,sys,hashlib,re,importlib.util,os
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
E=Path(sys.argv[1]);D=json.loads(E.read_text());OUT=Path(sys.argv[2]);assert not OUT.exists()
def pin(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def validate(p):
    assert pin(p['path'])==p,p['path']
assert D['status']=='commands_passed_pending_independent_acceptance'
assert D['default_stack'] and D['target_absent'] and not (ROOT/'target').exists()
assert D['guard']=={'minimum_free_bytes':5*1024**3,'maximum_target_bytes':1024**3,'interval_seconds':1}
validate(D['runner']);validate(D['command_spec']);validate(D['cli'])
assert os.stat(D['cli']['path']).st_mode&0o777==0o555
assert [r['argv'][:2] for r in D['commands']]==[['cargo','fmt'],['cargo','test'],['cargo','build'],['cargo','clean']]
assert D['commands'][1]['argv']==['cargo','test','-p','jarde-java','--lib','--locked']
assert D['commands'][2]['argv']==['cargo','build','-p','jarde-cli','--locked']
assert D['commands'][3]['argv']==['cargo','clean']
for row in D['commands']:
    assert row['exit_code']==0 and row.get('guard_stop') is None
    for p in row['streams'].values():validate(p)
    assert row.get('peak_target_bytes',0)<=1024**3
raw=Path(D['commands'][1]['streams']['stdout']['path']).read_text()
raw=re.sub(r'\x1b\[[0-9;]*m','',raw)
tests=re.findall(r'^test ([^\n]+) \.\.\. (ok|FAILED|ignored)',raw,re.M)
assert len(tests)==385 and all(status=='ok' for _,status in tests)
assert re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)==[('ok','385','0','0')]
required={'build::tests::same_block_reference_load_is_presented_outside_try_for_fixed_dv_variants',
'build::tests::reference_load_does_not_borrow_stack_duplicate_values',
'build::tests::reference_load_rejects_actual_store_after_intervening_effect',
'build::tests::reference_constructor_and_static_invoke_still_require_protected_arms',
'region::finite_loop_catch_tests::retry_try_catch_ownership_is_stable_across_eight_frozen_lanes',
'region::finite_loop_catch_tests::frozen_df_loop_catch_terminal_owner_is_inside_its_row',
'region::finite_loop_catch_tests::frozen_dv_finite_terminal_owners_match_both_loop_spellings',
'region::finite_loop_catch_tests::finite_owner_proof_stops_atomically_at_budget_and_cancellation',
'region::finite_loop_catch_tests::finite_terminal_license_rejects_mutated_physical_rows'}
assert required<={name for name,_ in tests}
for p in D['source_manifest_after']:
    actual=pin(ROOT/p['path']);assert actual['bytes']==p['bytes'] and actual['sha256']==p['sha256']
paths=[p['path'] for p in D['source_manifest_after']];assert len(paths)==len(set(paths))
assert sum(p.startswith('tests/fixtures/p3-loop-catch-retry/') for p in paths)==8
def module(path, expected, name):
    assert pin(path)['sha256']==expected
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
focus=module('/private/tmp/jarde-cf11-structured-list-focused-runner-prep-luna-v7/run.py','c8b1016eaf9506912876fd92e8544d5f78e472401beb99e3fd75b549607956bc','accept_focus')
focus.CLOSURE_MODULE=module('/private/tmp/jarde-iterator-assignment-full-validation-prep-luna-v2/workspace_runner.py','63e52b55fe5d20d5f2ece98ac80676ccdb2de8dfd33d7199b688e075fb1e9673','accept_closure')
assert focus.source_manifest()==D['source_manifest_after'], 'Current source membership or bytes differ'
OUT.mkdir()
summary={'status':'accepted_focused_commands_only','execution':pin(E),'cli':D['cli'],'named_tests':len(tests),'required_new_tests':sorted(required),'source_manifest_after_count':len(paths),'target_absent':True,'full_class_runtime_accepted':False,'verifier':pin(__file__)}
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False))
