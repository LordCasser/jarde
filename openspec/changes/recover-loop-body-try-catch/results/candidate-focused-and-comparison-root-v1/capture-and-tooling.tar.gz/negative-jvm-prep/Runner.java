import reference.LoadNegatives;
public class Runner {
    public static void main(String[] args) throws Exception {
        Object marker = new Object();
        if (LoadNegatives.multi(marker) != marker) throw new AssertionError("multi");
        if (LoadNegatives.crossEffect(marker) != marker) throw new AssertionError("cross");
        java.lang.reflect.Field effects = LoadNegatives.class.getDeclaredField("effects");
        effects.setAccessible(true);
        if (effects.getInt(null) != 1) throw new AssertionError("effects");
        System.out.println("multi=true;cross=true;effects=1");
    }
}
