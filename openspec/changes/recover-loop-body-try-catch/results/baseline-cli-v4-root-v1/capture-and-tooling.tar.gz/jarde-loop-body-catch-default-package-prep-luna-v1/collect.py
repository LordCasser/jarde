#!/usr/bin/env python3
"""Run the default-package JADX Runner adaptation against frozen v4 sources."""
from __future__ import annotations
import datetime, hashlib, importlib.util, json, os, re, shutil, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
PINS = HERE / 'pins.json'
BINDING = HERE / 'source_binding.json'
BASELINES = {
    'debug': Path('/private/tmp/jarde-loop-body-catch-baseline-debug-root-v4-v1'),
    'none': Path('/private/tmp/jarde-loop-body-catch-baseline-none-root-v4-v1'),
}
CLI = Path('/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v4')
FOCUSED = Path('/private/tmp/jarde-cf11-structured-list-focused-root-v12/execution.json')
GUARD = ROOT / 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
FREE, TARGET = 5 * 1024**3, 1024**3
STRIP_ENV = ('JAVA_HOME', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH')
SCHEMA = 'jarde-loop-body-catch-default-package-supplement-v1'

def sha(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def pin(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': sha(data)}
def dump(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
def module(path: Path, expected: str, name: str):
    if pin(path)['sha256'] != expected: raise RuntimeError(name + ' pin mismatch')
    spec = importlib.util.spec_from_file_location('supplement_' + name, path)
    obj = importlib.util.module_from_spec(spec); spec.loader.exec_module(obj); return obj

def main() -> int:
    if len(sys.argv) != 2: raise SystemExit('usage: collect.py /private/tmp/FRESH_OUTPUT')
    out = Path(sys.argv[1]).resolve()
    if out.exists(): raise SystemExit('refuse non-fresh output: ' + str(out))
    pins = json.loads(PINS.read_text(encoding='utf-8'))
    binding = json.loads(BINDING.read_text(encoding='utf-8'))
    if binding.get('status') != 'root_pins_filled' or binding.get('cli') != pins.get('cli') or binding.get('focused_receipt') != pins.get('focused_receipt'):
        raise SystemExit('root CLI/focused receipt bindings disagree')
    if Path(binding['cli']['path']) != CLI or Path(binding['focused_receipt']['path']) != FOCUSED: raise SystemExit('unexpected CLI/focused receipt path')
    if pin(CLI)['sha256'] != binding['cli']['sha256'] or pin(FOCUSED)['sha256'] != binding['focused_receipt']['sha256']: raise SystemExit('CLI/focused receipt pin mismatch')
    rec = json.loads(FOCUSED.read_text(encoding='utf-8'))
    freeze = rec.get('cli_freeze', {})
    if freeze.get('path') != str(CLI) or freeze.get('sha256') != pin(CLI)['sha256'] or freeze.get('mode') != '0o555': raise SystemExit('focused receipt does not bind CLI v4')
    for row in pins['assets']:
        if pin(Path(row['path']))['sha256'] != row['sha256'] or pin(Path(row['path']))['bytes'] != row['bytes']: raise SystemExit('asset pin mismatch: ' + row['path'])
    guard = module(GUARD, GUARD_SHA, 'guard')
    scanner = module(SCANNER, SCANNER_SHA, 'scanner')
    baseline_docs = {}
    source_paths, runner_paths, reference_paths = [], [], []
    for mode, base in BASELINES.items():
        doc_path = base/'execution.json'; doc = json.loads(doc_path.read_text(encoding='utf-8'))
        if doc.get('schema') != 'jarde-loop-body-catch-baseline-v1' or doc.get('status') != 'observed' or doc.get('actual_command_count') != 24: raise SystemExit('baseline receipt not observed/24-command: ' + mode)
        baseline_pin = pins.get('baselines', {}).get(mode, {})
        if pin(doc_path)['sha256'] != baseline_pin.get('sha256') or pin(doc_path)['bytes'] != baseline_pin.get('bytes'):
            raise SystemExit('baseline receipt pin mismatch: ' + mode)
        baseline_docs[mode] = doc
        reference_paths.append(doc_path)
        original_runner = base/'inputs/Runner.java'; runner_paths.append(original_runner)
        for leg in ('javac8','javac23'):
            item = next(x for x in doc['jadx'] if x.get('jdk') == leg and x.get('profile') == 'default')
            if item.get('exit_code') != 0 or item.get('exact_whole_class_set') is not True: raise SystemExit('default JADX source set unavailable: '+mode+'/'+leg)
            src_root = base/'jadx'/leg/'default/sources/defpackage'
            for cls in ('DF','DV'):
                src = src_root/(cls+'.java')
                text = src.read_text(encoding='utf-8')
                if not re.search(r'(?m)^\s*package\s+defpackage\s*;', text): raise SystemExit('unexpected package for '+str(src))
                if not re.search(r'(?m)^\s*public\s+class\s+'+cls+r'\b', text): raise SystemExit('unexpected class identity for '+str(src))
                source_paths.append(src)
            run_row = next((c for c in doc['commands'] if c.get('label') == leg+'-original-run'), None)
            if not run_row or run_row.get('exit_code') != 0: raise SystemExit('baseline original runtime unavailable: '+mode+'/'+leg)
            reference_paths.append(Path(run_row['streams']['stdout']['path'])); reference_paths.append(Path(run_row['streams']['stderr']['path']))
    derived = b'package defpackage;\n' + runner_paths[0].read_bytes()
    # Runner fixture is shared by both receipts; require byte-for-byte equality.
    if runner_paths[0].read_bytes() != runner_paths[1].read_bytes(): raise SystemExit('debug/none baseline Runner differs')
    tracked = [Path(__file__), PINS, BINDING, CLI, FOCUSED, GUARD, SCANNER, *source_paths, *runner_paths, *reference_paths]
    before = [pin(p) for p in tracked]
    out.mkdir(parents=True)
    guard.OUT = out/'raw'; guard.ROOT = ROOT; guard.expected_test_summaries = lambda index, stdout: None; guard.ENV_VALUES = {}
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.command_stream = lambda p: {'path': str(Path(p).resolve()), 'bytes': Path(p).stat().st_size, 'sha256': sha(Path(p).read_bytes())}
    (out/'raw').mkdir(); (out/'inputs').mkdir()
    runner_out = out/'inputs/Runner.java'; runner_out.write_bytes(derived)
    result = {'schema':SCHEMA,'status':'running','bindings':{'cli':pin(CLI),'focused_receipt':pin(FOCUSED)},'baseline_receipts':{m:pin(b/'execution.json') for m,b in BASELINES.items()},'original_runner':pin(runner_paths[0]),'derived_runner':pin(runner_out),'derived_runner_rule':'exact bytes: b"package defpackage;\\n" + original Runner.java','lanes':[],'resource_guard':{'minimum_free_bytes':FREE,'maximum_target_bytes':TARGET,'sample_interval_seconds':1,'process_group_termination':True},'commands':[],'source_tool_pins_before':before}
    dump(out/'execution.json',result)
    def run(label, argv, home):
        idx=len(result['commands'])+1
        env={k:v for k,v in os.environ.items() if k not in STRIP_ENV}; env['JAVA_HOME']=str(home); env['PATH']=str(home/'bin')+os.pathsep+env.get('PATH','')
        row={'index':idx,'label':label,'argv':[str(x) for x in argv],'cwd':str(ROOT),'java_home':str(home),'state':'started','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        result['commands'].append(row); dump(out/'execution.json',result)
        observed=guard.run_command(idx,row['argv'],env); row.update(observed); row['label']=label; row['state']='guard-stopped' if observed.get('guard_stop') else 'observed'
        for stream in ('stdout','stderr'):
            meta=row['streams'][stream]; data=Path(meta['path']).read_bytes(); meta.update(bytes=len(data),sha256=sha(data))
        dump(out/'execution.json',result)
        if observed.get('guard_stop'): raise RuntimeError('resource guard stopped '+label)
        return row
    for mode, base in BASELINES.items():
        doc=baseline_docs[mode]
        for leg in ('javac8','javac23'):
            work=out/'legs'/mode/leg; classes=work/'classes'; classes.mkdir(parents=True); empty=work/'empty-paths'; empty.mkdir()
            jadx_root=base/'jadx'/leg/'default/sources/defpackage'
            sources=[jadx_root/'DF.java',jadx_root/'DV.java',runner_out]
            jdk=doc['jdk_legs'][leg]['tools']; home=Path(doc['jdk_legs'][leg]['home'])
            flags=['-source','8','-target','8','-Xlint:-options'] if leg=='javac8' else ['--release','8']
            flags += ['-proc:none',('-g' if mode=='debug' else '-g:none'),'-classpath',empty,'-sourcepath',empty,'-d',classes,*sources]
            comp=run('default-jadx-'+mode+'-'+leg+'-compile',[jdk['javac'],*flags],home)
            runtime=None
            if comp.get('exit_code') == 0:
                runtime=run('default-jadx-'+mode+'-'+leg+'-run',[jdk['java'],'-Xverify:all','-cp',classes,'defpackage.Runner'],home)
            files=sorted(classes.rglob('*.class'))
            original=next(c for c in doc['commands'] if c.get('label') == leg+'-original-run')
            stdout=Path(runtime['streams']['stdout']['path']).read_bytes() if runtime else b''
            original_stdout=Path(original['streams']['stdout']['path']).read_bytes()
            result['lanes'].append({'mode':mode,'jdk':leg,'sources':[pin(p) for p in sources],'source_class_identities':['defpackage.DF','defpackage.DV'],'runner_class_identity':'defpackage.Runner','compile':comp,'run':runtime,'runtime_state':'ran' if runtime and runtime.get('guard_stop') is None else 'no-runtime','class_paths':[p.relative_to(classes).as_posix() for p in files],'classes':[pin(p) for p in files],'stdout_comparison':{'baseline_path':original['streams']['stdout']['path'],'baseline_sha256':sha(original_stdout),'supplement_sha256':sha(stdout),'byte_identical':runtime is not None and stdout==original_stdout}})
            dump(out/'execution.json',result)
    after=[pin(p) for p in tracked]
    result['source_tool_pins_after']=after; result['source_tool_inputs_unchanged']=before==after
    result['actual_command_count']=len(result['commands']); result['status']='observed' if result['source_tool_inputs_unchanged'] and len(result['commands'])==8 else 'failed'
    if not result['source_tool_inputs_unchanged']: result['failure']={'type':'SourcePinChanged','message':'baseline/source/tool pins changed during supplement'}
    dump(out/'execution.json',result)
    return 0 if result['status']=='observed' else 1

if __name__ == '__main__': raise SystemExit(main())
