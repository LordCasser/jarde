# default JADX package 适配补充采集

本包仅补充 v4 baseline 中 default JADX 源码与原 Runner 的 package 适配编译运行。debug/none × javac8/javac23 共四腿，每腿只执行一次 javac 和一次 java，共 8 条受同一 5 GiB 可用空间、1 GiB target 上限、1 秒采样进程组 guard 保护的命令。

两个 v4 baseline 保持原样。本脚本引用其 observed/24-command receipt、default JADX 完整 DF/DV 源码、原 Runner 与原 Runner stdout/stderr。对独立 Runner 副本仅在首行添加 `package defpackage;`；不改写反编译 DF/DV。按源码声明校验 DF/DV 的实际类身份为 `defpackage.DF` 与 `defpackage.DV`，运行类名为 `defpackage.Runner`。补充 receipt 记录来源 pins、衍生 Runner pin、每条实际 argv、命令原始 stdout/stderr pin、class paths，并逐腿比较 stdout 与相同 mode/JDK 的 original Runner 字节是否一致。

fresh 输出目录上串行运行一次：

```sh
python3 -B /private/tmp/jarde-loop-body-catch-default-package-prep-luna-v1/collect.py /private/tmp/jarde-loop-body-catch-default-package-root-v1
```

`source_binding.json` 和 `pins.json` 绑定 CLI v4 及 focused v12 receipt；本补充仅静态校验这些绑定，不调用 Jarde CLI。Python 标准库静态校验已完成；此准备阶段没有运行 JDK、JADX、Jarde CLI、Cargo 或 Git。

审阅 Jarde 方法 diagnostics 时，`first_refusal_by_method` 中第一条 warning（例如 enumswitch）不代表源码恢复被阻断。需要看完整 report；foreach 的实际 local2 错误可能出现在后续 diagnostics。
