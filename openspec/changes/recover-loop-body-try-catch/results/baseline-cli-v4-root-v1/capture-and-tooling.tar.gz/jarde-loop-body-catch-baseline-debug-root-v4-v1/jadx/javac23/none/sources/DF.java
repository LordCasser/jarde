// default package

/* JADX INFO: loaded from: javac23.jar:DF.class */
public class DF {
    static int defaultFirst(int x) {
        switch (x) {
            case 1:
                return 10;
            case 2:
                return 20;
            default:
                return 0;
        }
    }

    static int defaultFallthrough(int x) {
        switch (x) {
            case 1:
                return 100;
            case 2:
            default:
                return 200;
        }
    }

    static int loopCatch(int[] xs) {
        int good = 0;
        for (int x : xs) {
            if (x < 0) {
                throw new IllegalArgumentException("neg");
            }
            try {
                good += x;
            } catch (IllegalArgumentException e) {
                good--;
            }
            good--;
        }
        return good;
    }

    static int loopFinally(int[] xs) {
        int c = 0;
        for (int x : xs) {
            if (x != 3) {
                c += x;
            }
            try {
                c += 1000;
            } catch (Throwable th) {
                int i = c + 1000;
                throw th;
            }
        }
        return c;
    }

    public static void main(String[] a) {
        System.out.println("" + defaultFirst(1) + "/" + defaultFirst(9) + "/" + defaultFallthrough(1) + "/" + defaultFallthrough(2) + "/" + defaultFallthrough(9) + "/" + loopCatch(new int[]{1, -2, 3}) + "/" + loopFinally(new int[]{3, 4}));
    }
}
