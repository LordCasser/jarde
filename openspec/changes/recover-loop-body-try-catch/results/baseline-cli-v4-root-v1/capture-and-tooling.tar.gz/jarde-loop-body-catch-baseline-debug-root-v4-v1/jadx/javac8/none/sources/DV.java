// default package

/* JADX INFO: loaded from: javac8.jar:DV.class */
public class DV {
    static int plainFor(int[] xs) {
        int g = 0;
        for (int i = 0; i < xs.length; i++) {
            try {
                if (xs[i] < 0) {
                    throw new IllegalArgumentException("n");
                }
                g += xs[i];
            } catch (IllegalArgumentException e) {
                g--;
            }
        }
        return g;
    }

    static int whileLoop(int[] xs) {
        int g = 0;
        for (int i = 0; i < xs.length; i++) {
            try {
                if (xs[i] < 0) {
                    throw new IllegalArgumentException("n");
                }
                g += xs[i];
            } catch (IllegalArgumentException e) {
                g--;
            }
        }
        return g;
    }

    static int forEach(int[] xs) {
        int g = 0;
        for (int x : xs) {
            try {
                g += x;
            } catch (Exception e) {
                g--;
            }
        }
        return g;
    }

    static int loopNoTry(int[] xs) {
        int g = 0;
        int length = xs.length;
        for (int i = 0; i < length; i++) {
            int x = xs[i];
            g = x < 0 ? g - 1 : g + x;
        }
        return g;
    }

    public static void main(String[] a) {
        System.out.println("" + plainFor(new int[]{1, -2, 3}) + "/" + whileLoop(new int[]{1, -2, 3}) + "/" + forEach(new int[]{1, 2}) + "/" + loopNoTry(new int[]{1, -2, 3}));
    }
}
