#!/usr/bin/env python3
"""Independently accept frozen observations, not a recovery implementation."""
import hashlib
import json
from pathlib import Path

TMP = Path('/private/tmp')
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
OUT = TMP / 'jarde-loop-body-catch-baseline-acceptance-root-v2'
assert not OUT.exists()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def check_pin(row):
    p = Path(row['path'])
    assert not p.is_symlink() and p.is_file(), str(p)
    raw = p.read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], str(p)
    return raw

def stream(c, name, parent):
    ref = c['streams'][name]
    assert Path(ref['path']).resolve().is_relative_to(parent.resolve())
    return check_pin(ref)

def checked_commands(doc, parent, count):
    commands = doc['commands']
    assert len(commands) == doc['actual_command_count'] == count
    assert [c['index'] for c in commands] == list(range(1, count + 1))
    assert doc['source_tool_inputs_unchanged'] is True
    assert doc['source_tool_pins_before'] == doc['source_tool_pins_after']
    for row in doc['source_tool_pins_before']:
        check_pin(row)
    for c in commands:
        assert c['cwd'] == str(ROOT) and c['state'] == 'observed'
        assert c.get('guard_stop') is None
        assert c['peak_target_bytes'] <= 1024**3
        assert c['free_bytes_after'] >= 5 * 1024**3
        for name in ('stdout', 'stderr'):
            stream(c, name, parent)
    return {c['label']: c for c in commands}

def runtime_lines(raw):
    lines = raw.decode('utf-8').splitlines()
    assert len(lines) == 18 and len(set(x.partition(' => ')[0] for x in lines)) == 18
    return dict(x.split(' => ', 1) for x in lines)

observations = []
baseline_pins = {}
oracles = {}
refusals = []
raw_count = 0
for mode, expected in (
    ('debug', 'd1c831ce3bdffe17925cd027347fdb270bd3dcf8c4bac2e04c0e99cbe43d37b9'),
    ('none', 'd321d018b0efee2ad75424ce5f1154c43a2667a52a3f809508274254cb4cb1b1'),
):
    base = TMP / ('jarde-loop-body-catch-baseline-' + mode + '-root-v4-v1')
    raw = (base / 'execution.json').read_bytes()
    assert sha(raw) == expected
    doc = json.loads(raw)
    assert doc['schema'] == 'jarde-loop-body-catch-baseline-v1' and doc['status'] == 'observed'
    assert doc['source_debug'] == mode
    commands = checked_commands(doc, base, 24)
    assert len(commands) == 24 and len(doc['jadx']) == len(doc['jarde']) == len(doc['javap']) == 4
    baseline_pins[mode] = {'path': str(base / 'execution.json'), 'sha256': expected}
    for leg in ('javac8', 'javac23'):
        orig = commands[leg + '-original-run']
        assert orig['exit_code'] == commands[leg + '-original-compile']['exit_code'] == 0
        assert stream(orig, 'stderr', base) == b''
        oracle = runtime_lines(stream(orig, 'stdout', base))
        oracles[mode, leg] = oracle
        assert oracle['DF.loopCatch input=[1, -2, 3]'] == 'value=3'
        for profile in ('default', 'none'):
            prefix = 'jadx-' + leg + '-' + profile
            assert commands[prefix]['exit_code'] == 0
            comp = commands[prefix + '-compile']
            if profile == 'default':
                assert comp['exit_code'] == 1 and prefix + '-run' not in commands
                assert '找不到符号' in stream(comp, 'stderr', base).decode()
                observations.append({'mode': mode, 'jdk': leg, 'profile': profile,
                                     'initial_harness_state': 'namespace_mismatch_no_runtime'})
            else:
                run = commands[prefix + '-run']
                assert comp['exit_code'] == run['exit_code'] == 0
                assert stream(run, 'stderr', base) == b''
                actual = runtime_lines(stream(run, 'stdout', base))
                differences = {key: {'original': oracle[key], 'jadx': actual[key]}
                               for key in oracle if actual[key] != oracle[key]}
                assert set(differences) == {'DF.loopCatch input=[1, -2, 3]'}
                observations.append({'mode': mode, 'jdk': leg, 'profile': profile,
                                     'runtime': 'ran', 'differences': differences})
        assert commands['jarde-' + leg + '-compile']['exit_code'] == 1
        assert 'jarde-' + leg + '-run' not in commands
        for cls in ('DF', 'DV'):
            c = commands[leg + '-jarde-' + cls]
            assert c['exit_code'] == 0 and stream(c, 'stderr', base) == b''
            report_raw = stream(c, 'stdout', base)
            folder = base / 'jarde' / leg / cls
            assert (folder / 'response.raw.json').read_bytes() == report_raw
            report = json.loads(report_raw)
            assert json.loads((folder / 'report.json').read_bytes()) == report
            assert (folder / (cls + '.java')).read_text() == report['text']
            cf = base / 'legs' / leg / 'original' / 'classes' / (cls + '.class')
            assert str(cf) in c['argv'] and str(TMP / 'jarde-cf11-structured-list-candidate-cli-root-v4') == c['argv'][0]
            class_ref = next(x for x in doc['original'][leg]['classes'] if x['path'] == str(cf))
            assert check_pin(class_ref) == cf.read_bytes()
            javap_ref = next(x for x in doc['javap'] if x['jdk'] == leg and x['class'] == cls)
            assert check_pin(javap_ref['pin']) == stream(commands[javap_ref['command']], 'stdout', base)
            assert commands[javap_ref['command']]['argv'][-1] == cls
            if leg == 'javac23':
                assert sha(cf.read_bytes()) in (base / 'legs' / leg / (cls + '.javap.txt')).read_text()
            for m in report['methods']:
                item = m['item']
                name = item['name']['escaped']
                assert item['identity']['name'] == item['name']['raw']
                assert item['identity']['descriptor'] == item['descriptor']['raw']
                rep = m['outcome'].get('report', {})
                if name not in ('plainFor', 'whileLoop', 'forEach', 'loopCatch', 'loopFinally', 'loopNoTry'):
                    continue
                if name in ('plainFor', 'whileLoop', 'loopCatch'):
                    assert rep['content'] == 'explanation_only'
                    cause = next(x['message'] for x in rep['diagnostics'] if x['code'] == 'jre_region_irreducible')
                elif name == 'forEach':
                    assert rep['content'] == 'explanation_only'
                    cause = 'local 2 crosses a protected region, but SSA does not prove that every path to its reads reaches a presented write'
                    assert cause in rep['text']
                    assert any(r['structured'] and r['rule']['rule'] == 'loop' for r in rep['regions'])
                else:
                    cause = 'control observation; no new recovery acceptance'
                refusals.append({'mode': mode, 'jdk': leg, 'class': cls, 'name': name,
                                 'descriptor': item['descriptor']['escaped'], 'identity': item['identity'],
                                 'input_class_sha256': sha(cf.read_bytes()), 'content': rep['content'],
                                 'compile_status': rep['compile_status'], 'syntax_status': rep['syntax_status'],
                                 'cause': cause, 'diagnostics': rep['diagnostics']})
    raw_count += 48

assert len({json.dumps(v, sort_keys=True) for v in oracles.values()}) == 1
base = TMP / 'jarde-loop-body-catch-default-package-root-v1'
raw = (base / 'execution.json').read_bytes()
doc = json.loads(raw)
assert doc['schema'] == 'jarde-loop-body-catch-default-package-supplement-v1' and doc['status'] == 'observed'
commands = checked_commands(doc, base, 8)
assert len(doc['lanes']) == 4
original_runner = check_pin(doc['original_runner'])
assert check_pin(doc['derived_runner']) == b'package defpackage;\n' + original_runner
for lane in doc['lanes']:
    mode, leg = lane['mode'], lane['jdk']
    assert lane['compile']['exit_code'] == lane['run']['exit_code'] == 0
    assert lane['run']['argv'][-1] == 'defpackage.Runner'
    assert lane['runtime_state'] == 'ran'
    for source in lane['sources']:
        check_pin(source)
    for cls in ('DF', 'DV'):
        expected_source = TMP / ('jarde-loop-body-catch-baseline-' + mode + '-root-v4-v1') / 'jadx' / leg / 'default' / 'sources' / 'defpackage' / (cls + '.java')
        assert str(expected_source) in lane['compile']['argv']
    assert stream(lane['run'], 'stderr', base) == b''
    actual = runtime_lines(stream(lane['run'], 'stdout', base))
    oracle = oracles[mode, leg]
    differences = {key: {'original': oracle[key], 'jadx': actual[key]} for key in oracle if actual[key] != oracle[key]}
    assert set(differences) == {'DF.loopCatch input=[1, -2, 3]'}
    observations.append({'mode': mode, 'jdk': leg, 'profile': 'default_namespace_adapted_runner',
                         'runtime': 'ran', 'differences': differences})

OUT.mkdir()
result = {'schema': 'loop-catch-baseline-root-acceptance-v1', 'status': 'accepted_observations_only',
          'baseline_receipts': baseline_pins, 'supplement_receipt_sha256': sha(raw),
          'external_commands': 56, 'raw_streams_checked': raw_count + 16,
          'original_runtime_legs': 4, 'jadx_runtime_legs': 8, 'jarde_failed_wholeclass_compile_legs': 4,
          'all_original_18_labels_equal': True, 'observations': observations, 'method_observations': refusals,
          'implementation_accepted': False, 'same_run_ir_gates_proven': False}
(OUT / 'summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('observations', 'method_observations')}, ensure_ascii=False))
