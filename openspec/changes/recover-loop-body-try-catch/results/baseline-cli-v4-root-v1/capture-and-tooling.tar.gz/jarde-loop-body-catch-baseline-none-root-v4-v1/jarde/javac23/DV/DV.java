// jarde: presentation of `DV` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class DV extends java.lang.Object {
    public DV() {
        // @method <init>()V
        // @declaration a constructor of `DV`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int plainFor(int[] arg0) {
        // jarde: not recovered: the recovery run for `plainFor([I)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method plainFor([I)I
        // @declaration a static method of `DV`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 2 3 4 5 6 7 10 11 12 13 16 19 20 22 25 26 27 28 29 30 31 32 35 36 39 42 45 46
        // the graph is not reducible over 4 block(s) [4, 10, 26, 39]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }

    static int whileLoop(int[] arg0) {
        // jarde: not recovered: the recovery run for `whileLoop([I)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method whileLoop([I)I
        // @declaration a static method of `DV`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 2 3 4 5 6 7 10 11 12 13 16 19 20 22 25 26 27 28 29 30 31 32 35 36 39 42 45 46
        // the graph is not reducible over 4 block(s) [4, 10, 26, 39]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }

    static int forEach(int[] arg0) {
        // jarde: not recovered: the recovery run for `forEach([I)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method forEach([I)I
        // @declaration a static method of `DV`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 10 16 30 35 41
        // local 2 crosses a protected region, but SSA does not prove that every path to its reads reaches a presented write
    }

    static int loopNoTry(int[] arg0) {
        // @method loopNoTry([I)I
        // @declaration a static method of `DV`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int local1;
        int[] local2;
        local1 = 0;
        local2 = arg0;
        for (int local5 : local2) {
            if (local5 < 0) {
                local1 = local1 - 1;
            } else {
                local1 = local1 + local5;
            }
        }
        return local1;
    }

    public static void main(java.lang.String[] arg0) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `DV`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.io.PrintStream saved0 = java.lang.System.out;
        java.lang.StringBuilder saved1 = new java.lang.StringBuilder().append("");
        java.lang.StringBuilder saved2 = saved1.append(plainFor(new int[]{1, -2, 3})).append("/");
        java.lang.StringBuilder saved3 = saved2.append(whileLoop(new int[]{1, -2, 3})).append("/");
        java.lang.StringBuilder saved4 = saved3.append(forEach(new int[]{1, 2})).append("/");
        saved0.println((java.lang.String) saved4.append(loopNoTry(new int[]{1, -2, 3})).toString());
        return;
    }
}
