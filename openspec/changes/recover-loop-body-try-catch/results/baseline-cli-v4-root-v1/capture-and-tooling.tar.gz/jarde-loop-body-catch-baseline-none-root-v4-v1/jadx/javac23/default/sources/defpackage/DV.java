package defpackage;

/* JADX INFO: loaded from: javac23.jar:DV.class */
public class DV {
    static int plainFor(int[] iArr) {
        int i = 0;
        for (int i2 = 0; i2 < iArr.length; i2++) {
            try {
                if (iArr[i2] < 0) {
                    throw new IllegalArgumentException("n");
                }
                i += iArr[i2];
            } catch (IllegalArgumentException e) {
                i--;
            }
        }
        return i;
    }

    static int whileLoop(int[] iArr) {
        int i = 0;
        for (int i2 = 0; i2 < iArr.length; i2++) {
            try {
                if (iArr[i2] < 0) {
                    throw new IllegalArgumentException("n");
                }
                i += iArr[i2];
            } catch (IllegalArgumentException e) {
                i--;
            }
        }
        return i;
    }

    static int forEach(int[] iArr) {
        int i = 0;
        for (int i2 : iArr) {
            try {
                i += i2;
            } catch (Exception e) {
                i--;
            }
        }
        return i;
    }

    static int loopNoTry(int[] iArr) {
        int i = 0;
        int length = iArr.length;
        for (int i2 = 0; i2 < length; i2++) {
            int i3 = iArr[i2];
            i = i3 < 0 ? i - 1 : i + i3;
        }
        return i;
    }

    public static void main(String[] strArr) {
        System.out.println("" + plainFor(new int[]{1, -2, 3}) + "/" + whileLoop(new int[]{1, -2, 3}) + "/" + forEach(new int[]{1, 2}) + "/" + loopNoTry(new int[]{1, -2, 3}));
    }
}
