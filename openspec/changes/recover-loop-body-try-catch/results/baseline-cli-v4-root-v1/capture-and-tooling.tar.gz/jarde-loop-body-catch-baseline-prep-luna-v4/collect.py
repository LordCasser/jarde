#!/usr/bin/env python3
"""Private loop-body-catch baseline collector. Preparation only until root pins are filled."""
from __future__ import annotations
import datetime, hashlib, importlib.util, json, os, re, shutil, sys, zipfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
HERE = Path(__file__).resolve().parent
INPUTS = HERE / 'inputs'
BINDING = HERE / 'source_binding.json'
PINS = HERE / 'pins.json'
CLI_EXPECTED = Path('/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v4')
RECEIPT_EXPECTED = Path('/private/tmp/jarde-cf11-structured-list-focused-root-v12/execution.json')
JDK_MANIFEST = ROOT / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
GUARD = ROOT / 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCHEMA = 'jarde-loop-body-catch-baseline-v1'
FREE, TARGET = 5 * 1024**3, 1024**3
STRIP_ENV = ('JAVA_HOME', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH')

def sha(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def pin(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': sha(data)}
def json_safe(value):
    if isinstance(value, Path): return str(value)
    if isinstance(value, dict): return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [json_safe(v) for v in value]
    return value
def dump(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(json_safe(value), ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
def load_pinned(path: Path, expected: str, name: str):
    if pin(path)['sha256'] != expected: raise RuntimeError(name + ' pin mismatch')
    spec = importlib.util.spec_from_file_location('loopcatch_' + name, path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def collect() -> int:
    if len(sys.argv) != 3 or sys.argv[1] not in ('debug', 'none'):
        raise SystemExit('usage: collect.py debug|none /private/tmp/FRESH_OUTPUT')
    mode, out = sys.argv[1], Path(sys.argv[2]).resolve()
    if out.exists() and not ((out/'execution.json').is_file() and json.loads((out/'execution.json').read_text(encoding='utf-8')).get('status') == 'running'):
        raise SystemExit('refuse non-fresh output: ' + str(out))
    pin_doc = json.loads(PINS.read_text(encoding='utf-8'))
    if pin_doc.get('schema') != 'jarde-loop-body-catch-preparation-pins-v1': raise SystemExit('preparation pin schema mismatch')
    for item in pin_doc.get('assets', []):
        p = Path(item['path'])
        if pin(p)['bytes'] != item['bytes'] or pin(p)['sha256'] != item['sha256']: raise SystemExit('preparation asset pin mismatch: ' + str(p))
    binding = json.loads(BINDING.read_text(encoding='utf-8'))
    if binding.get('status') != 'root_pins_filled': raise SystemExit('root must fill source_binding.json; no command run')
    cli, receipt = Path(binding['cli']['path']), Path(binding['focused_receipt']['path'])
    if cli != CLI_EXPECTED or receipt != RECEIPT_EXPECTED: raise SystemExit('root source binding paths differ; no command run')
    if pin_doc.get('cli') != binding.get('cli') or pin_doc.get('focused_receipt') != binding.get('focused_receipt'):
        raise SystemExit('root binding and preparation pins disagree; no command run')
    if not cli.is_file() or (cli.stat().st_mode & 0o777) != 0o555: raise SystemExit('CLI missing or mode is not 0555; no command run')
    if pin(cli)['bytes'] != binding['cli']['bytes'] or pin(cli)['sha256'] != binding['cli']['sha256']: raise SystemExit('CLI pin mismatch')
    if pin(receipt)['bytes'] != binding['focused_receipt']['bytes'] or pin(receipt)['sha256'] != binding['focused_receipt']['sha256']: raise SystemExit('focused receipt pin mismatch')
    rec = json.loads(receipt.read_text(encoding='utf-8'))
    freeze = rec.get('cli_freeze', {})
    if freeze.get('path') != str(cli) or freeze.get('bytes') != cli.stat().st_size or freeze.get('sha256') != pin(cli)['sha256'] or freeze.get('mode') != '0o555':
        raise SystemExit('focused receipt does not bind the pinned v4 CLI')
    tool_specs = {
        'jdk_manifest': (JDK_MANIFEST, 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'),
        'jadx': (JADX, '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'),
        'jadx_jar': (JADX_JAR, '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'),
        'guard': (GUARD, '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'),
        'scanner': (SCANNER, 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'),
    }
    tool_pins = {k: pin(p) for k, (p, _) in tool_specs.items()}
    for k, (p, h) in tool_specs.items():
        if tool_pins[k]['sha256'] != h: raise SystemExit(k + ' pin mismatch; no command run')
    guard = load_pinned(GUARD, tool_specs['guard'][1], 'guard')
    scanner = load_pinned(SCANNER, tool_specs['scanner'][1], 'scanner')
    jm = json.loads(JDK_MANIFEST.read_text(encoding='utf-8'))
    legs = {}
    for leg in jm.get('legs', []):
        tools = leg.get('jdk_tools', {})
        if {'java', 'javac', 'javap'} <= tools.keys():
            ps = {n: Path(v['path']).resolve() for n, v in tools.items()}
            if all(pin(ps[n])['sha256'] == tools[n]['sha256'] for n in ('java','javac','javap')):
                legs[leg['leg']] = {'tools': ps, 'home': ps['java'].parent.parent, 'pins': tools}
    if set(legs) != {'javac8','javac23'}: raise SystemExit('pinned JDK8/JDK23 legs missing; no command run')
    source_paths = [INPUTS/'DF.java', INPUTS/'DV.java', HERE/'Runner.java']
    manifest = json.loads((INPUTS/'manifest.json').read_text(encoding='utf-8'))
    source_by_name = {p.name: p for p in source_paths}
    if len(source_by_name) != len(source_paths): raise SystemExit('source inventory has duplicate basenames')
    for item in manifest['files']:
        name = item['path']
        p = source_by_name.get(name) if isinstance(name, str) else None
        if p is None: raise SystemExit('manifest source is outside the fixed source inventory: ' + repr(name))
        if pin(p)['bytes'] != item['bytes'] or pin(p)['sha256'] != item['sha256']: raise SystemExit('input pin mismatch: ' + str(p))
    if [p.name for p in source_paths] != ['DF.java','DV.java','Runner.java']: raise SystemExit('source inventory mismatch')
    out.mkdir(parents=True, exist_ok=True)
    for d in ('raw','legs','jadx','jarde','inputs'): (out/d).mkdir()
    guard.OUT = out/'raw'; guard.ROOT = ROOT; guard.expected_test_summaries = lambda index, stdout: None; guard.ENV_VALUES = {}
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.command_stream = lambda p: {'path': str(Path(p).resolve()), 'bytes': Path(p).stat().st_size, 'sha256': sha(Path(p).read_bytes())}
    for p in source_paths: shutil.copyfile(p, out/'inputs'/p.name)
    shutil.copyfile(INPUTS/'manifest.json', out/'inputs/manifest.json')
    tracked = [Path(__file__), PINS, BINDING, receipt, cli, JDK_MANIFEST, JADX, JADX_JAR, GUARD, SCANNER, *source_paths, *[Path(x['path']) for x in pin_doc['assets']], *[x['tools'][n] for x in legs.values() for n in ('java','javac','javap')]]
    before = [pin(p) for p in tracked]
    execution = {'schema': SCHEMA, 'status':'running', 'source_debug':mode, 'inputs':manifest, 'input_manifest':pin(INPUTS/'manifest.json'), 'cli':pin(cli), 'focused_receipt':pin(receipt), 'tool_pins':tool_pins, 'jdk_legs':legs, 'resource_guard':{'minimum_free_bytes':FREE,'maximum_target_bytes':TARGET,'sample_interval_seconds':1,'process_group_termination':True}, 'commands':[], 'javap':[], 'jadx':[], 'jarde':[], 'source_tool_pins_before':before}
    dump(out/'execution.json', execution)
    def run(label, argv, home):
        idx = len(execution['commands']) + 1
        env = {k:v for k,v in os.environ.items() if k not in STRIP_ENV}
        env['JAVA_HOME'] = str(home); env['PATH'] = str(home/'bin') + os.pathsep + env.get('PATH','')
        row = {'index':idx,'label':label,'argv':[str(x) for x in argv],'cwd':str(ROOT),'java_home':str(home),'state':'started','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        execution['commands'].append(row); dump(out/'execution.json',execution)
        result = guard.run_command(idx, row['argv'], env); row.update(result); row['label']=label; row['state']='guard-stopped' if result.get('guard_stop') else 'observed'
        for stream in ('stdout','stderr'):
            meta=row['streams'][stream]; data=Path(meta['path']).read_bytes(); meta.update(bytes=len(data),sha256=sha(data))
        dump(out/'execution.json',execution)
        if result.get('guard_stop'):
            raise RuntimeError('resource guard stopped command '+label+': '+json.dumps(json_safe(result['guard_stop']),ensure_ascii=False))
        return row, Path(row['streams']['stdout']['path']).read_bytes(), Path(row['streams']['stderr']['path']).read_bytes()
    classfiles = {}
    def compile_run(label, sources, leg_name, class_dir, oracle=False):
        leg=legs[leg_name]; class_dir.mkdir(parents=True); empty=class_dir.parent/'empty-paths'; empty.mkdir()
        flags=['-source','8','-target','8','-Xlint:-options'] if leg_name=='javac8' else ['--release','8']
        comp,_,_=run(label+'-compile',[leg['tools']['javac'],*flags,'-proc:none',('-g' if mode=='debug' else '-g:none'),'-classpath',empty,'-sourcepath',empty,'-d',class_dir,*sources],leg['home'])
        runrow=None
        if comp.get('exit_code')==0 and comp.get('guard_stop') is None:
            runrow,_,_=run(label+'-run',[leg['tools']['java'],'-Xverify:all','-cp',class_dir,'Runner'],leg['home'])
        files=sorted(class_dir.rglob('*.class'))
        return {'compile':comp,'run':runrow,'class_paths':sorted(p.relative_to(class_dir).as_posix() for p in files),'classes':[pin(p) for p in files]}
    for leg_name in ('javac8','javac23'):
        leg=legs[leg_name]; work=out/'legs'/leg_name; original=compile_run(leg_name+'-original',source_paths,leg_name,work/'original'/'classes')
        execution.setdefault('original',{})[leg_name]=original; dump(out/'execution.json',execution)
        origdir=work/'original'/'classes'
        for cls in ('DF','DV'):
            cf=origdir/(cls+'.class')
            if not cf.is_file(): continue
            row,text,err=run(leg_name+'-original-javap-'+cls,[leg['tools']['javap'],'-p','-c','-s','-v','-classpath',origdir,cls],leg['home'])
            dest=work/(cls+'.javap.txt'); dest.write_bytes(text)
            execution['javap'].append({'class':cls,'jdk':leg_name,'pin':pin(dest),'command':row['label'],'stderr_sha256':sha(err)})
            classfiles[(leg_name,cls)]=cf
        dump(out/'execution.json',execution)
    # Decompile each exact javac output pair; retain default and no-renaming profiles.
    for leg_name in ('javac8','javac23'):
        if not all((leg_name,c) in classfiles for c in ('DF','DV')): continue
        jar=out/'inputs'/(leg_name+'.jar')
        with zipfile.ZipFile(jar,'w',zipfile.ZIP_STORED) as z:
            for cls in ('DF','DV'):
                info=zipfile.ZipInfo(cls+'.class',date_time=(1980,1,1,0,0,0)); info.compress_type=zipfile.ZIP_STORED; z.writestr(info,classfiles[(leg_name,cls)].read_bytes())
        for profile in ('default','none'):
            dest=out/'jadx'/leg_name/profile
            argv=[JADX,'--no-res','--config','none','--threads-count','1']
            if profile=='none': argv += ['--rename-flags','none']
            row,_,_=run('jadx-'+leg_name+'-'+profile,[*argv,'-d',dest,jar],legs['javac23']['home'])
            sources=sorted(dest.rglob('*.java')) if dest.exists() else []
            exact=sorted(p.name for p in sources)==['DF.java','DV.java'] and all(re.search(r'(?m)^\s*public\s+class\s+'+p.stem+r'\b',p.read_text(encoding='utf-8')) for p in sources)
            item={'jdk':leg_name,'profile':profile,'command':row['label'],'exit_code':row.get('exit_code'),'exact_whole_class_set':exact,'sources':[pin(p) for p in sources]}
            if exact:
                compile_row=compile_run('jadx-'+leg_name+'-'+profile,sources+[out/'inputs/Runner.java'],leg_name,out/'legs'/leg_name/('jadx-'+profile)/'classes')
                item['compile_run']={'compile_exit':compile_row['compile'].get('exit_code'),'run_exit':compile_row['run'].get('exit_code') if compile_row['run'] else None,'runtime_state':'ran' if compile_row['run'] and compile_row['run'].get('guard_stop') is None else 'no-runtime','class_paths':compile_row['class_paths']}
            execution['jadx'].append(item); dump(out/'execution.json',execution)
    # Jarde renders each class from each exact original compiler output, then compiles both complete class sources together.
    reports={}
    for leg_name in ('javac8','javac23'):
        leg=legs[leg_name]
        for cls in ('DF','DV'):
            cf=classfiles.get((leg_name,cls))
            if not cf: continue
            folder=out/'jarde'/leg_name/cls; folder.mkdir(parents=True)
            row,raw,err=run(leg_name+'-jarde-'+cls,[cli,'class-source','--input',cf,'--class',cls,'--policy','single-class','--release','8','--format','json','--evidence','all'],leg['home'])
            item={'jdk':leg_name,'class':cls,'render_command':row['label'],'render_exit':row.get('exit_code'),'raw_stdout_sha256':sha(raw),'raw_stderr_sha256':sha(err),'first_refusal_by_method':[]}
            if row.get('exit_code')==0:
                (folder/'response.raw.json').write_bytes(raw)
                try:
                    doc=json.loads(raw.decode('utf-8')); dump(folder/'report.json',doc)
                    source=folder/(cls+'.java'); source.write_text(doc['text'],encoding='utf-8')
                    maps=[]
                    for m in doc.get('methods',[]):
                        rep=m.get('outcome',{}).get('report',{})
                        method_item=m.get('item',{})
                        identity=method_item.get('identity',{})
                        maps.append({'declaration':m.get('declaration'),'item':method_item,'identity':identity,'name':identity.get('name'),'descriptor':identity.get('descriptor'),'method_outcome_kind':m.get('outcome',{}).get('kind'),'report_outcome':rep.get('outcome'),'compile_status':rep.get('compile_status'),'syntax_status':rep.get('syntax_status'),'source_map':rep.get('source_map'),'diagnostics':rep.get('diagnostics',[])})
                        warnings=[d for d in rep.get('diagnostics',[]) if d.get('severity') in ('warning','error')]
                        if warnings: item['first_refusal_by_method'].append({'declaration':m.get('declaration'),'identity':m.get('item',{}).get('identity'),'first_non_info_diagnostic':warnings[0]})
                    dump(folder/'wholeclass-source-maps.json',{'class':doc.get('class'),'methods':maps})
                    item.update(source=pin(source),report=pin(folder/'report.json'),source_maps=pin(folder/'wholeclass-source-maps.json'),outcome=doc.get('outcome'),execution=doc.get('execution'))
                    reports[(leg_name,cls)]=source
                except (UnicodeError,ValueError,TypeError,KeyError) as exc: item['parse_error']={'type':type(exc).__name__,'message':str(exc)}
            execution['jarde'].append(item); dump(out/'execution.json',execution)
            if item.get('parse_error'): raise RuntimeError('Jarde JSON parse failed for '+leg_name+'/'+cls)
        if all((leg_name,c) in reports for c in ('DF','DV')):
            sources=[reports[(leg_name,'DF')],reports[(leg_name,'DV')],out/'inputs/Runner.java']
            result=compile_run('jarde-'+leg_name,sources,leg_name,out/'legs'/leg_name/'jarde'/'classes')
            execution.setdefault('jarde_compile_run',{})[leg_name]={'compile_exit':result['compile'].get('exit_code'),'run_exit':result['run'].get('exit_code') if result['run'] else None,'runtime_state':'ran' if result['run'] and result['run'].get('guard_stop') is None else 'no-runtime: whole-class source compile failed or execution was guard-stopped','class_paths':result['class_paths'],'classes':result['classes']}
        else:
            execution.setdefault('jarde_compile_run',{})[leg_name]={'runtime_state':'no-runtime: at least one whole-class report/source was unavailable'}
        dump(out/'execution.json',execution)
    execution['source_tool_pins_after']=[pin(p) for p in tracked]
    execution['source_tool_inputs_unchanged']=before==execution['source_tool_pins_after']
    execution['actual_command_count']=len(execution['commands'])
    execution['status']='observed' if execution['source_tool_inputs_unchanged'] else 'failed'
    if not execution['source_tool_inputs_unchanged']:
        execution['failure']={'type':'SourcePinChanged','message':'source/tool/input pins differ between collection start and finish'}
    dump(out/'execution.json',execution)
    if not execution['source_tool_inputs_unchanged']: raise RuntimeError('source/tool/input pin changed during collection')
    return 0

def preflight_paths():
    paths=[Path(__file__),PINS,BINDING,JDK_MANIFEST,JADX,JADX_JAR,GUARD,SCANNER]
    try:
        pins=json.loads(PINS.read_text(encoding='utf-8'))
        paths.extend(Path(x['path']) for x in pins.get('assets',[]))
    except Exception: pass
    try:
        binding=json.loads(BINDING.read_text(encoding='utf-8'))
        for k in ('cli','focused_receipt'):
            if isinstance(binding.get(k),dict) and isinstance(binding[k].get('path'),str): paths.append(Path(binding[k]['path']))
    except Exception: pass
    try:
        manifest=json.loads(JDK_MANIFEST.read_text(encoding='utf-8'))
        for leg in manifest.get('legs',[]):
            for row in leg.get('jdk_tools',{}).values():
                if isinstance(row,dict) and isinstance(row.get('path'),str): paths.append(Path(row['path']))
    except Exception: pass
    unique=[]; seen=set()
    for p in paths:
        key=str(p)
        if key not in seen: seen.add(key); unique.append(p)
    return unique

def pin_snapshot(paths):
    rows=[]
    for p in paths:
        try: rows.append(pin(p))
        except BaseException as exc: rows.append({'path':str(p),'pin_error':{'type':type(exc).__name__,'message':str(exc)}})
    return rows

def main() -> int:
    if len(sys.argv) != 3 or sys.argv[1] not in ('debug','none'):
        raise SystemExit('usage: collect.py debug|none /private/tmp/FRESH_OUTPUT')
    mode,out=sys.argv[1],Path(sys.argv[2]).resolve()
    if out.exists(): raise SystemExit('refuse non-fresh output: '+str(out))
    out.mkdir(parents=True)
    paths=preflight_paths(); before=pin_snapshot(paths)
    seed={'schema':SCHEMA,'status':'running','source_debug':mode,'commands':[],'source_tool_pins_before':before,'phase':'preflight'}
    dump(out/'execution.json',seed)
    try:
        code=collect()
        latest=json.loads((out/'execution.json').read_text(encoding='utf-8'))
        if code != 0 or latest.get('status') == 'running':
            raise RuntimeError('collector exited without a terminal receipt')
        return code
    except BaseException as exc:
        receipt_path=out/'execution.json'
        try: latest=json.loads(receipt_path.read_text(encoding='utf-8'))
        except BaseException as read_exc:
            latest=seed
            latest['receipt_read_error']={'type':type(read_exc).__name__,'message':str(read_exc)}
        combined=list(paths); seen_paths={str(p) for p in combined}
        for row in latest.get('source_tool_pins_before',[]):
            if isinstance(row,dict) and isinstance(row.get('path'),str) and row['path'] not in seen_paths:
                combined.append(Path(row['path'])); seen_paths.add(row['path'])
        after=pin_snapshot(combined)
        latest['source_tool_pins_after']=after
        latest['source_tool_inputs_unchanged']=before==after
        latest['status']='failed'
        commands=latest.get('commands',[])
        latest['failure']={'type':type(exc).__name__,'message':str(exc),'last_command':commands[-1].get('label') if commands and isinstance(commands[-1],dict) else None}
        latest['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        dump(receipt_path,latest)
        print('baseline collection failed; terminal receipt saved at '+str(receipt_path),file=sys.stderr)
        return 1

if __name__ == '__main__': raise SystemExit(main())
