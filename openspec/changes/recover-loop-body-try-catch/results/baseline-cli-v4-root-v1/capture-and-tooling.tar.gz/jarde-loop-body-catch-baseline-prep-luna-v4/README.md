# 循环体 try/catch 三方基线采集准备

本目录是私有 v4 准备包，依据 `recover-loop-body-try-catch` 架构侦察与固定 `DF.java`、`DV.java` 建立原/JADX/Jarde 整类对照。v2、v3 保持不变。这里仅做 stdlib JSON 序列化校验，没有运行 JDK、JADX、Jarde CLI、Cargo 或 Git，也没有改动共享项目。

`source_binding.json` 和 `pins.json` 已绑定 root 提供的 CLI `/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v4`（模式 `0555`）及 receipt `/private/tmp/jarde-cf11-structured-list-focused-root-v12/execution.json`。脚本校验两个绑定一致、receipt 对该 CLI 的精确绑定，并校验其余工具、JDK、输入和源文件 pin。不可借用 root3 CLI。

工具链空闲、root 填完绑定且下列两个输出路径仍不存在后，由 root 串行运行：

```sh
python3 -B /private/tmp/jarde-loop-body-catch-baseline-prep-luna-v4/collect.py debug /private/tmp/jarde-loop-body-catch-baseline-debug-root-v4-v1
python3 -B /private/tmp/jarde-loop-body-catch-baseline-prep-luna-v4/collect.py none /private/tmp/jarde-loop-body-catch-baseline-none-root-v4-v1
```

每条外部命令都经复用的 5 GiB 可用空间、1 GiB target 上限和 1 秒采样进程组 guard；JVM 注入环境变量会被移除。每个输出目录独立记录命令参数、退出码、stdout/stderr 原始字节与 SHA-256，并比较运行前后的 CLI、manifest、JDK、JADX、guard、scanner 和 fixture pins。

采集覆盖 Java 8、Java 23 两个编译器，分别生成带/不带调试信息的原 class；`javap -p -c -s -v` 保存 DF/DV 每个方法的物理 BCI、descriptor 与完整异常表。JADX 对每个原始 JDK 产物保留 default/none 命名配置输出及整类源码，再将 DF、DV、Runner 一起编译。Jarde 对每个 class 和 JDK 调用 class-source，保留完整原始 JSON、整类 Java、方法级 source map 和 diagnostics，再整类联合编译。只在整类编译成功且未被 guard 中止时运行；否则明确记为 `no-runtime`。

独立 Runner 对 `DV.plainFor`、`whileLoop`、`forEach`、`loopNoTry`、`DF.loopCatch`、`loopFinally` 分别尝试空数组、`{1,-2,3}` 和 `null`，逐项打印返回值或抛出异常类型。它不会改写 DF/DV 源码，也不调用任何工具链。

采集后按 `execution.json` 中的实际 class identity 和 descriptor 审阅方法结果。报告保留完整 diagnostics/source map，并列出方法 outcome、report outcome、compile/syntax 状态及第一条 warning/error 原文，方便定位首个拒绝事实而不预判拒绝原因。Q-i 需根据新鲜整类 JSON 与物理异常表逐项核实 `proved_loop_catch_joins` 条件；`forEach` 另按实际拒绝阶段判断。

manifest 的 `files[].path` 是源文件名；采集器只在固定源码清单（`inputs/DF.java`、`inputs/DV.java`、包根目录 `Runner.java`）中解析该字段，并按实际源文件校验摘要。脚本和输入的固定摘要见 `pins.json`。`source_binding.json` 与 `pins.json` 已绑定 root 提供的 CLI v4 和 focused v12 receipt；采集器依然要求 root 确认采集时机并提供两个 fresh 输出目录。
