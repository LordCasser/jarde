# Root run plan (v2; do not execute before root review)

1. Select the exact completed v4 baseline `DV.class` and `DF.class` paths for each profile from the root manifest and verify their hashes. Do not claim CLI invocation identity for the candidate's independent same-payload `report::recover` call.
2. Review `candidate-test.diff`, `candidate-build-observer.diff`, and complete candidate copies. Verify all source pins before applying only these private test-only insertions. The build observer is gated by `JARDE_LOOP_BODY_CATCH_SSA_DIAGNOSTIC=1`; it reuses the real declaration/report pipeline and must not alter the acceptance result.
3. Under the existing serialized root runner, run the test once per javac8/debug, javac8/none, javac23/debug, javac23/none profile, with `JARDE_LOOP_BODY_CATCH_DV_CLASS` and `JARDE_LOOP_BODY_CATCH_DF_CLASS`. Candidate command: `cargo test -p jarde-java --lib region::tests::loop_body_catch_same_run_ir_diagnostic -- --exact --nocapture`. Reuse the runner's >=5 GiB free-space floor, <=1 GiB target cap, default stack, one-second sampler, source-byte restoration, and final cargo cleanup.
4. Preserve stdout/stderr per profile. Require analysis `ExecutionReport::Complete`, all six stage states completed, and independently require proof/report execution complete; record usage. Parse the labelled LBC records for full exception rows, actual throw-site membership, Q-i conjuncts and individual path results; Q-ii normal SCC entries/adjacent exception edges and irreducible IDs/BCIs before/after current proof/hypothetical joins; Q-iii first refusal and local-2 SSA/protected-region predicates. The hypothetical set is evidence only and does not mutate the graph.
5. In `finally`, restore original source bytes and verify the whole `source_manifest4822`; run guarded cleanup and verify `target/` is absent. Keep stop/failure receipts separate.


## v3 lineage

Use this fresh package, not the frozen v2 directory. The observer-only repair addresses the root v1 E0277 formatting failure and one unused closure binding. All other candidate test and proof-budget content is inherited unchanged from root-frozen v2.
