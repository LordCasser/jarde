# Loop body catch same-run IR prep (private, not executed)

This package prepares Q-i/Q-ii/Q-iii collection for OpenSpec `recover-loop-body-try-catch` task 1.2. It has not run Cargo, the CLI, JDK, JADX, or a collector, and does not modify the shared workspace.

The root's v4 baseline has completed and is archived under `openspec/changes/recover-loop-body-try-catch/results/baseline-cli-v4-root-v1`; its summary is pinned in `pins.json`. Root reports four classfile profiles (javac8/23 × debug/none), 112 raw / 56 commands, JADX8 negative runtime legs escaping the original result 3, and Jarde whole-class compile failures. Those are baseline facts supplied by root; no same-run IR fact has yet been collected.

`candidate-test.rs` is a test-module insertion proposal for `region.rs`; `candidate-build-observer.diff` adds gated test-only logging around the existing build/SSA decision seam. Full private candidate source copies are in `candidate/crates/jarde-java/src/{region.rs.candidate,build.rs.candidate}`. The region test explicitly gives analysis, proof, and recovery report independent nonzero ample budgets; `Limits::default()` is all zero and is never used as an executable budget. The build observer calls the SSA certificate once, only where the old short-circuit called it, and leaves the decision predicate unchanged.

The in-memory test prints physical method identity, execution/stage completion, code and exception table, canonical CFG rows and throw sites, normal edges, loop membership/dominance, labelled Q-i conjuncts and path failures, SCC edge inventory and Q-ii irreducible block IDs/BCIs, and full SSA values/phis. It invokes `report::recover` on that same MethodIr payload, with `RecoveryFacts` synthesized from the declaration and no debug-local metadata. This correlates the same payload's report outcome; it is not the original CLI invocation. The build observer is intended to reveal the actual local-2 decision and first rejected reference-store predicate for the same report pass.

Static API audit is in `v2-api-audit.md`. Exact class paths/pins remain pending the root runner's completed manifest selection. No candidate was applied, compiled, or executed here.
