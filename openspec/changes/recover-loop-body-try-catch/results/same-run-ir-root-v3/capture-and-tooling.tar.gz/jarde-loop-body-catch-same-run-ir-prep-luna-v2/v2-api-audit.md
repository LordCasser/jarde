# Candidate v2 source API audit (read-only; no compile)

Checked directly against the current source after root review:

- `NormalFlowView::ids`, `id_of`, `index_of`, `successors`, `predecessors`, `loop_entered_at`, `dominates`, and `irreducible_blocks` are present in `crates/jarde-java/src/normal_flow.rs`.
- `NaturalLoop::{blocks,latches,is_irreducible}` are present in the same file. Thus the candidate's `lp.is_irreducible()`, `view.ids()`, and `lp.latches()` are valid API references; the earlier concern came from searching only the JVM crate instead of the Java consumer crate.
- `CanonicalCfg::{blocks,edges,throw_sites,handler_rows}`; `CanonicalBlock::{id,end_bci}`; `CanonicalBlockId::bci`; `CanonicalThrowSite::{block,handlers}`; `CanonicalHandlerRow::{handler,ordinal,protected,catch_type_index}`; and `CanonicalEdge::{from,to,kind}` are present in method_ir's exported surface / canonical source.
- `SsaTable::{blocks,values_with_ids,phis}` and `SsaInstruction::{reads,writes}` are present. `MethodIrAnalysis::{report,ir}`, `MethodAnalysisReport::{method,execution,stages}`, `StageState::Completed`, and `ExecutionReport::Complete` are present.
- `RecoveryRequest::new` and report fields `execution`, `outcome`, `fallbacks`, `diagnostics` are public in `report.rs`.
- `petgraph` is a direct `jarde-java` dependency. The candidate constructs a transient analysis-only graph from Normal/Return canonical edges for SCC entry-edge observation; it never edits `CanonicalCfg` or `NormalFlowView`.
- `plain_paths_reach_join` is private in region.rs; the candidate runs it with an ample, separate diagnostic budget and uses `expect`, so a stop cannot be rewritten as `false`. It prints actual irreducible node indices, canonical block IDs, and BCIs.

The candidate passes this source-level name/signature audit only. It has not been compiled. `RecoveryFacts` in the report call deliberately omits debug locals; this produces a recovery report from the same IR payload, but it must not be described as the exact CLI invocation or the same caller facts.
