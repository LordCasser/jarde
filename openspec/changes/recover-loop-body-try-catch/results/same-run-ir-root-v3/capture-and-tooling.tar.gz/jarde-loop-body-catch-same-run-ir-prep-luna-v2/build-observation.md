# Q-iii focused source trace (static; same-run observation still pending)

Root reports the completed baseline's first surfaced reason for `DV.forEach([I)I` as `local 2 crosses a protected region, but SSA does not prove that every path to its reads reaches a presented write`; the block tree already has a structured loop. The code path is `build.rs::declarations` around lines 983–1250, with the reason emitted at current line 1223. That narrows Q-iii to the declaration/SSA gate, not loop region recognition.

The exact short-circuit chain at the protected-crossing branch is:

1. `crosses_exception_region(variable_uses, &paths)` must be true.
2. The sequence of recognized lead/guard exceptions must all be false.
3. `store_type_is_proven = cross_exception_store_type_is_proven(plan.decided.get(variable), has_increment)` must be true; references are allowed when there is no increment.
4. The boolean/joined-value certificate must be false, so `all_reads_reach_presented_writes(...)` is invoked.
5. `all_reads_reach_presented_writes` first validates every write's stored SSA value. Non-increment writes are accepted only by `presented_int_store_value` or `presented_reference_store_value`; it then validates reads by walking SSA definitions. Entry and caught definitions are rejected in the read walk, and `PhiInput::Itself` is rejected.

For root's stated slot-2 source `aload0@2 -> astore2@3`, a direct `Load` value does not match the accepted result operations in `presented_reference_store_value`: that helper accepts same-block `<init>` calls or static calls, not a `Load` (lines 4561+). It also requires the producer to be in a try's protected child (`path.starts_with(try_path)` and child index `0`). Since BCI 2 appears to be the outer array/reference copy before the loop's try, the first expected failure is the protected-arm path predicate; after that the fallback match arm would also reject `Operation::Load`. This is only a source-level hypothesis until one same-run trace confirms the exact `RegionPath`, stored ValueId definition, and ordered first return. Do not claim direct-parameter input itself is the cause without that trace.

## Minimal private observer proposal

During the same `report::recover` call made by the candidate same-run test, add test-only, environment-gated diagnostics at two seams, with no changed return values:

- In `declarations`, immediately before the rejection branch, log the `LocalVariable`, decided type, each `SlotUse` mapped to `(bci, path, read, written, stored)`, `RegionPaths.tries/fallbacks`, owner/first write, `crosses_exception`, `has_increment`, `store_type_is_proven`, each named special-case bool, and `joined_value_certified`. Capture `all_reads_reach_presented_writes` exactly once into a local only when the original short-circuit would call it, then use that value in the same predicate; this preserves the existing evaluation order, budget charges, and return decision.
- In `all_reads_reach_presented_writes`, when both value-presentation helpers reject a store, print the exact `SlotUse`, stored value definition/type, producer operation, producer and store block paths, matching try path/arm, and whether `single_use_at_with_budget` was reached/passed. The reference helper's current combined early guard should be expanded into sequential booleans only in the private test build so the first failed clause is printed; do not call a helper twice or add proof steps.

Gate all output behind `#[cfg(test)]` plus a dedicated environment label and `slot()==2`; production builds and the certificate stay unchanged. This is a small temporary observer, not a production logger or a new pass. The current `candidate-test.diff` only includes the region-level same-run capture; a separate build.rs observer diff still needs root review before any collection.
