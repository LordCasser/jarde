#!/usr/bin/env python3
"""Root-only temporary observation; always restore product source and clean target."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
TMP = Path('/private/tmp')
PREP = TMP / 'jarde-loop-body-catch-same-run-ir-prep-luna-v3'
OUT = TMP / 'jarde-loop-body-catch-same-run-ir-root-v2'
FOCUS = TMP / 'jarde-cf11-structured-list-focused-runner-prep-luna-v7/run.py'
CLOSURE = TMP / 'jarde-iterator-assignment-full-validation-prep-luna-v2/workspace_runner.py'
GUARD = ROOT / 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SOURCES = {'region.rs': ROOT / 'crates/jarde-java/src/region.rs',
           'build.rs': ROOT / 'crates/jarde-java/src/build.rs'}
FREE = 5 * 1024**3
assert not OUT.exists(), 'output must be fresh'
assert not (ROOT / 'target').exists(), 'root must own an idle fresh target'
assert shutil.disk_usage(ROOT).free >= FREE

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def pin(p):
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': sha(raw)}

def module(p, expected, name):
    assert sha(p.read_bytes()) == expected, str(p)
    spec = importlib.util.spec_from_file_location(name, p)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

focus = module(FOCUS, 'c8b1016eaf9506912876fd92e8544d5f78e472401beb99e3fd75b549607956bc', 'loop_ir_focus')
focus.CLOSURE_MODULE = module(CLOSURE, '63e52b55fe5d20d5f2ece98ac80676ccdb2de8dfd33d7199b688e075fb1e9673', 'loop_ir_closure')
guard = module(GUARD, '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33', 'loop_ir_guard')
scanner = module(SCANNER, 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7', 'loop_ir_scanner')
manifest = focus.source_manifest()
frozen = json.loads((TMP / 'jarde-cf11-structured-list-focused-root-v12/execution.json').read_text())
assert manifest == frozen['source_manifest_before'] and len(manifest) == 4822
prep_pins = json.loads((PREP / 'pins.json').read_text())
for name, row in prep_pins['source_pins'].items():
    p = PREP / name.removeprefix('prep/') if name.startswith('prep/') else (ROOT / name if (ROOT / name).is_file() else PREP / name)
    assert pin(p)['sha256'] == row['sha256'] and pin(p)['bytes'] == row['bytes'], str(p)
original = {name: p.read_bytes() for name, p in SOURCES.items()}
candidate = {name: (PREP / 'candidate/crates/jarde-java/src' / (name + '.candidate')).read_bytes() for name in SOURCES}
OUT.mkdir()
(OUT / 'raw').mkdir()
(OUT / 'original_sources').mkdir()
for name, raw in original.items():
    (OUT / 'original_sources' / name).write_bytes(raw)
record = {'schema': 'loop-catch-same-run-ir-root-v1', 'status': 'running',
          'source_manifest_before': manifest, 'candidate_pins': {name: pin(PREP / 'candidate/crates/jarde-java/src' / (name + '.candidate')) for name in SOURCES},
          'prep_pins': pin(PREP / 'pins.json'), 'runner': pin(Path(__file__)),
          'dependencies': [pin(x) for x in (FOCUS, CLOSURE, GUARD, SCANNER)],
          'commands': [], 'lanes': [], 'rust_min_stack': None,
          'guard': {'minimum_free_bytes': FREE, 'maximum_target_bytes': 1024**3, 'sample_interval_seconds': 1}}

def save():
    (OUT / 'execution.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')

guard.OUT = OUT / 'raw'
guard.ROOT = ROOT
guard.target_bytes = lambda: scanner.target_bytes(ROOT)
guard.expected_test_summaries = lambda index, raw: None
guard.command_stream = lambda p: pin(Path(p))
base_env = {'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
            'CARGO_PROFILE_TEST_DEBUG': '0', 'RUST_TEST_THREADS': '1', 'CARGO_TERM_COLOR': 'always',
            'JARDE_LOOP_BODY_CATCH_SSA_DIAGNOSTIC': '1'}
env = {k: v for k, v in os.environ.items() if k not in ('CARGO_TARGET_DIR', 'RUST_MIN_STACK', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH')}
env.update(base_env)
armed = False
save()
try:
    armed = True
    for name, path in SOURCES.items():
        path.write_bytes(candidate[name])
    patched = focus.source_manifest()
    changed = [x['path'] for x, y in zip(patched, manifest) if x != y]
    assert len(patched) == 4822 and changed == ['crates/jarde-java/src/build.rs', 'crates/jarde-java/src/region.rs']
    record['temporary_source_manifest'] = patched
    save()
    for mode in ('debug', 'none'):
        base = TMP / ('jarde-loop-body-catch-baseline-' + mode + '-root-v4-v1')
        receipt = json.loads((base / 'execution.json').read_text())
        assert receipt['status'] == 'observed'
        for leg in ('javac8', 'javac23'):
            classes = base / 'legs' / leg / 'original' / 'classes'
            overrides = {**base_env, 'JARDE_LOOP_BODY_CATCH_DV_CLASS': str(classes / 'DV.class'),
                         'JARDE_LOOP_BODY_CATCH_DF_CLASS': str(classes / 'DF.class')}
            for cls in ('DV', 'DF'):
                ref = next(p for p in receipt['original'][leg]['classes'] if p['path'] == str(classes / (cls + '.class')))
                assert pin(Path(ref['path'])) == ref
            env.update(overrides)
            guard.ENV_VALUES = overrides
            index = len(record['commands']) + 1
            argv = ['cargo', 'test', '-p', 'jarde-java', '--lib', '--locked',
                    'region::tests::loop_body_catch_same_run_ir_diagnostic', '--', '--exact', '--nocapture']
            record['current_lane'] = [mode, leg]
            save()
            row = guard.run_command(index, argv, env)
            record['commands'].append(row)
            text = re.sub(r'\x1b\[[0-9;]*m', '', Path(row['streams']['stdout']['path']).read_text())
            assert row['exit_code'] == 0 and row.get('guard_stop') is None, 'diagnostic command failed or stopped'
            assert re.findall(r'^test (.+) \.\.\. (ok|FAILED)', text, re.M) == [('region::tests::loop_body_catch_same_run_ir_diagnostic', 'ok')]
            assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in text
            record['lanes'].append({'mode': mode, 'jdk': leg, 'baseline_receipt': pin(base / 'execution.json'),
                                    'command_index': index, 'class_pins': [pin(classes / (c + '.class')) for c in ('DV', 'DF')]})
            save()
    record['status'] = 'collected_observations_only'
except BaseException as exc:
    record['status'] = 'failed'
    record['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
finally:
    if armed:
        for name, path in SOURCES.items():
            path.write_bytes(original[name])
        record['source_manifest_after'] = focus.source_manifest()
        record['source_restored_byte_identity'] = record['source_manifest_after'] == manifest
        index = len(record['commands']) + 1
        start = time.monotonic()
        before = {'target_bytes': scanner.target_bytes(ROOT), 'free_bytes': shutil.disk_usage(ROOT).free}
        stdout, stderr = OUT / 'raw' / (str(index) + '.stdout.raw'), OUT / 'raw' / (str(index) + '.stderr.raw')
        with stdout.open('xb') as so, stderr.open('xb') as se:
            clean = subprocess.Popen(['cargo', 'clean'], cwd=ROOT, env=env, stdout=so, stderr=se, start_new_session=True)
            clean_rc = clean.wait()
        after = {'target_bytes': scanner.target_bytes(ROOT), 'free_bytes': shutil.disk_usage(ROOT).free}
        row = {'index': index, 'argv': ['cargo', 'clean'], 'cwd': str(ROOT), 'exit_code': clean_rc,
               'duration_seconds': time.monotonic() - start, 'streams': {'stdout': pin(stdout), 'stderr': pin(stderr)},
               'cleanup_only': {'exact_argv': ['cargo', 'clean'], 'space_precheck_bypassed': True,
                                'space_monitor_abort_bypassed': True, 'observed_before': before, 'observed_after': after}}
        record['commands'].append(row)
        record['target_absent'] = not (ROOT / 'target').exists()
        if not record['source_restored_byte_identity'] or not record['target_absent'] or clean_rc != 0:
            record['status'] = 'failed'
            record['restore_or_cleanup_failed'] = True
    record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({k: record.get(k) for k in ('status', 'source_restored_byte_identity', 'target_absent', 'failure')}))
sys.exit(0 if record['status'] == 'collected_observations_only' else 1)
