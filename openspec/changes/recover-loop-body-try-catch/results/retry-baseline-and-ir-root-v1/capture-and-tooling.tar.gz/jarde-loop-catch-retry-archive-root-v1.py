import hashlib
import io
import json
from pathlib import Path
import tarfile

TMP = Path('/private/tmp')
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
OUT = ROOT / 'openspec/changes/recover-loop-body-try-catch/results/retry-baseline-and-ir-root-v1'
plan = json.loads((TMP / 'jarde-loop-catch-retry-evidence-archive-prep-luna-v1/plan.json').read_text())
files = plan['files']
for row in files:
    raw = Path(row['path']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
extras = [TMP / x for x in (
    'jarde-loop-catch-retry-baseline-accept-root-v1.py',
    'jarde-loop-catch-retry-ir-accept-root-v1.py',
    'jarde-loop-catch-retry-same-run-ir-acceptance-root-v1/summary.json',
    'jarde-loop-catch-retry-archive-root-v1.py')]
for path in extras:
    raw = path.read_bytes()
    files.append({'path': str(path), 'bytes': len(raw),
                  'sha256': hashlib.sha256(raw).hexdigest(), 'archive': True,
                  'role': 'root actual independent acceptance or archival tooling'})
# Preserve the exact diagnostic base as well: small compressed text, not a checkout copy.
for row in files:
    if row['path'].endswith('/original_sources/region.rs'):
        row['archive'] = True
        row['role'] = 'exact pre-instrumentation source for independent replay'
assert len({x['path'] for x in files}) == len(files)
OUT.mkdir()
with tarfile.open(OUT / 'capture-and-tooling.tar.gz', 'w:gz') as tar:
    for row in files:
        if row['archive']:
            tar.add(row['path'], arcname=Path(row['path']).relative_to(TMP).as_posix(), recursive=False)
    raw = (json.dumps(plan, ensure_ascii=False, indent=2) + '\n').encode()
    info = tarfile.TarInfo('root-archive-manifest.json')
    info.size = len(raw)
    tar.addfile(info, io.BytesIO(raw))
# Re-open the actual package and verify every archived byte, not only the original plan.
with tarfile.open(OUT / 'capture-and-tooling.tar.gz', 'r:gz') as tar:
    for row in files:
        if row['archive']:
            raw = tar.extractfile(Path(row['path']).relative_to(TMP).as_posix()).read()
            assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
pack = (OUT / 'capture-and-tooling.tar.gz').read_bytes()
summary = {'status': 'accepted_observations_only', 'implementation_accepted': False,
           'baseline': json.loads((TMP / 'jarde-loop-catch-retry-baseline-acceptance-root-v1/summary.json').read_text()),
           'same_run_ir': json.loads((TMP / 'jarde-loop-catch-retry-same-run-ir-acceptance-root-v1/summary.json').read_text()),
           'archive': {'bytes': len(pack), 'sha256': hashlib.sha256(pack).hexdigest(),
                       'file_count': sum(x['archive'] for x in files), 'all_bytes_rechecked': True}}
(OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
(OUT / 'README.md').write_text('''# 无限重试循环：当前基线和同次 IR

root 实际执行并独立接受两组完整类基线：v2 保留动态观察文本，v3 仅将事件替换为固定文字并移除 AssertionError 消息。每组 debug/none × javac8/23 共44命令；原 class 四次运行与 JADX default/none 八次运行均同五个计数/事件 oracle。每组 Jarde 四条完整类输出编译失败，无 runtime；没有把失败删掉后拼接为成功。

v2 的 exc()V 另有 nested StringBuilder 构造参数 jre_new_shape；v3 消除该观察干扰后 exc()V 无非 info 诊断，test()I 的首拒仍为 BCI0 region ownership overlap。该构造差距独立记录，不扩大本 change。

同次 IR root 实际8测试各1/0/0，加最终 exact clean，共9命令/18raw；root 独立 checker 实际 exit0，完整4822源码恢复且 target absent。每个物理 test()I 与同 lane CLI 的 class digest/length/name/descriptor 配对，Code/canonical/normal-flow/SSA 和 recovery 全部 Complete。普通图无环；handler 普通跳回0，异常边0进入handler。所有 lane 都是同一个根 Try 的 catch 再进入嵌套同 Try，使 block0/handler 各有 owners[0,0]。证明的是当前拒绝位置，尚未实现恢复。

插桩只用最小 MethodFacts（参数槽与访问标志），不是 CLI 的完整 debug-name RecoveryFacts。源码临时变化仅 region.rs 的 cfg(test) 观察和私有测试，已全部还原。

capture-and-tooling.tar.gz 保存两个 baseline/prep、194个raw流、物理 class/javap/生成源码、baseline与IR独立checker/收据、IR prep/runner/原region源码以及逐文件SHA清单。CLI/JAR仅保存其收据身份，不复制二进制。root 已重新打开包逐字节核对全部文件。见 summary.json 中完整 root 接受结果和 archive SHA。观察接受不关闭产品任务或提高71/612完成数。
''', encoding='utf-8')
print(json.dumps(summary['archive']))
