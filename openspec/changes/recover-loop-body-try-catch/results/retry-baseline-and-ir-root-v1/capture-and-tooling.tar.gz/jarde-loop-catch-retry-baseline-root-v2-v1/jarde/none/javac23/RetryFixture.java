// jarde: presentation of `RetryFixture` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class RetryFixture extends java.lang.Object {
    int c;

    int caught;

    int breaks;

    final int failuresBeforeSuccess;

    final int errorOnCall;

    // jarde: field Signature projection refused for `eventsLjava/util/List;`: unsupported (field_generic_body_unproved): a same-class Fieldref names this field and descriptor; same-class uses at <init>(II)V@27, test()I@15, test()I@61, exc()V@11
    final java.util.List events;

    public RetryFixture(int arg1, int arg2) {
        // @method <init>(II)V
        // @declaration a constructor of `RetryFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.c = 0;
        this.caught = 0;
        this.breaks = 0;
        this.events = new java.util.ArrayList();
        this.failuresBeforeSuccess = arg1;
        this.errorOnCall = arg2;
        return;
    }

    public int test() {
        // jarde: not recovered: the recovery run for `test()I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method test()I
        // @declaration an instance method of `RetryFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 5 6 9 10 11 14 15 18 21 22 25 27 30 31 34 37 40 45 46 49 50 51 52 55 56 57 60 61 64 67 68 71 73 76 77 80 83 86 91 92 95 96 99 100 103 106 107 110 113 114
        // canonical block at BCI 0 on jsr path [] has more than one owner in the completed Region tree; the whole method is quoted
    }

    private void exc() throws java.lang.Exception {
        // @method exc()V
        // @declaration an instance method of `RetryFixture`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.c += 1;
        this.events.add((java.lang.Object) new java.lang.StringBuilder().append("call:").append(this.c).toString());
        if (this.c == this.errorOnCall) {
            // @bytecode 53
            // the instruction at BCI 53 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
            // @bytecode 56
            // the instruction at BCI 56 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
            // @bytecode 82 79 76 73 66 70 69
            // the copy at BCI 56 has no proved local assignment
        } else if (this.c < this.failuresBeforeSuccess + 1) {
            throw new java.lang.Exception();
    } else {
            this.events.add((java.lang.Object) new java.lang.StringBuilder().append("success:").append(this.c).toString());
            return;
    }
    }
}
