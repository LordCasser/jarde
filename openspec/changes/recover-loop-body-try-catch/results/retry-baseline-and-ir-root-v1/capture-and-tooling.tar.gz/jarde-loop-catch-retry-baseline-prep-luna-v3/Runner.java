public class Runner {
	private static void run(String label, int failuresBeforeSuccess, int errorOnCall) {
		RetryFixture fixture = new RetryFixture(failuresBeforeSuccess, errorOnCall);
		String outcome;
		try {
			outcome = "return:" + fixture.test();
		} catch (Throwable e) {
			outcome = "throw:" + e.getClass().getName();
		}
		fixture.events.add(outcome);
		System.out.println(label
				+ " calls=" + fixture.c
				+ " catches=" + fixture.caught
				+ " breaks=" + fixture.breaks
				+ " events=" + fixture.events);
	}

	public static void main(String[] args) {
		run("empty", 0, -1);
		run("one-failure", 1, -1);
		run("upstream-two-failures", 2, -1);
		run("three-failures", 3, -1);
		run("uncaught-error", 2, 2);
	}
}
