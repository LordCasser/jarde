# Loop catch retry v3 观测控制包

本包与 v2 并列，不覆盖 v2，也不抹掉 v2 的结果。v2 的实测 receipt 在 `pins.json` 中固定；root 已观察到 44 条命令，4 条 original 和 8 条 JADX runtime 命中全部五个 oracle，4 条 Jarde lane 在 `test()I` 的 block 0 拒绝。v2 的 `exc()V` 还报告了额外的 `jre_new_shape` ctor53 `nestedStringBuilder(arg拼接)`。v3 只降低观测插入引起的控制流外字符串构造干扰，用作并列控制样本；它不代表修复，也不预设会成功。

`RetryFixture.java` 的 `while (true) { try { exc(); ... break; } catch (Exception e) { ... } }`、失败门限和五个用例保持不变。`RetryFixture` 中各个 `events.add` 改为固定字面量 `call`/`success`/`catch`/`break`，未捕获目标改为无参 `new AssertionError()`。独立 Runner 只报告错误类，不读取 message。调用次数、捕获次数、break 次数和事件顺序仍逐项观察；上游默认情形仍为调用 3 次、catch 两次、break 一次。上游 SHA、源文件 SHA 和 v1/v2 派生 diff 都记录于 manifest/pins。

采集器沿用 v2 的完整矩阵、JDK/JADX/CLI pins、root guard 与环境过滤；只改本地 fixture 与 oracle。generated RetryFixture 产品源码保持原样。default package 若需要适配，只给独立 Runner 副本添加源码 package 行。Jarde/JADX 的失败和 diagnostics 会由 root 执行时如实留在 v3 receipt；此次准备不生成 execution receipt 或验收判断。

root 在 fresh 目录实际执行：

```sh
python3 -B /private/tmp/jarde-loop-catch-retry-baseline-prep-luna-v3/collect.py /private/tmp/jarde-loop-catch-retry-baseline-root-v3-v1
```

本准备阶段只用 Python 标准库更新/校验 manifest、diff 和 pins；未运行 JDK、JADX、Jarde CLI、Cargo 或 Git。
