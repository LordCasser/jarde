# Root execution plan

1. 选择一个从未存在的输出目录，串行执行 README 中唯一采集命令。脚本会拒绝已存在的目标。
2. 它先验证 fixture/Runner 精确 pins、CLI v4/focused v12、JDK 8/23、JADX、guard 和相关准备脚本 pins；然后为两种 debug profile 各生成 Java 8 原始 class，保存 `javap -p -c -s -v` 的原始输出和 class/method identity。
3. 对每个原始 class，JADX default 与 none 分别保留源码树、只在需要时生成 package 对齐的 Runner 副本，编译完整类并运行。Jarde 从相同物理 class 调用 class-source，保留完整原始 JSON 与 report，再编译/运行整类源码。
4. 每次编译/运行只在前序完整类编译成功且无 guard stop 时继续。查看每条 lane 的 `runtime_state`、完整 diagnostics 和 stdout comparison；不能由第一条 warning 推断阻断阶段。oracle 是 `fixture-manifest.json` 中的逐行期望，实际接纳与否由 root 独立审阅。

所有 Java、JADX 与 CLI 外部命令的 argv、启动/结束状态和原始流均留在 receipt。JADX 固定 `--no-res --config none --threads-count 1`；none profile 再加 `--rename-flags none`。Jarde 固定 `class-source --policy single-class --release 8 --format json --evidence all`。脚本每条外部命令最多运行 28 秒，超限先 TERM，等待至多 3 秒后发送 KILL，并最多再等待 1 秒。
