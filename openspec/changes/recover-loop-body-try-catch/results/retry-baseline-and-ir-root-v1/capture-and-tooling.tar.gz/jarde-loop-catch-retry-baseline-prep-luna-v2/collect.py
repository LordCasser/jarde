#!/usr/bin/env python3
"""Collect guarded original/JADX/Jarde whole-class retry-loop comparisons."""
from __future__ import annotations
import datetime, hashlib, importlib.util, json, os, re, shutil, signal, subprocess, sys, time, zipfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
HERE = Path(__file__).resolve().parent
CLI = Path('/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v4')
FOCUSED = Path('/private/tmp/jarde-cf11-structured-list-focused-root-v12/execution.json')
JDK_MANIFEST = ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
GUARD_PATH = ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER_PATH = ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_MANIFEST_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
JADX_SHA = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR_SHA = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
FREE_BYTES, TARGET_BYTES, COMMAND_TIMEOUT = 5*1024**3, 1024**3, 28
SCHEMA = 'jarde-loop-catch-retry-baseline-v2'
STRIP_ENV = ('JAVA_HOME','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH')
TOOL_PINS = {
 'cli': ('/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v4', 'd3d15d3dd875bc79410298e3ed1e56010fc39c1849e97dc893cadb49d8c65e6f'),
 'focused_receipt': ('/private/tmp/jarde-cf11-structured-list-focused-root-v12/execution.json', '74350dfc154c2fd77aa8a9636dd8d29b301eb119e167be56a0f18af011996a73'),
 'jdk_manifest': (str(JDK_MANIFEST), JDK_MANIFEST_SHA), 'jadx': (str(JADX), JADX_SHA),
 'jadx_jar': (str(JADX_JAR), JADX_JAR_SHA), 'guard': (str(GUARD_PATH), GUARD_SHA),
 'scanner': (str(SCANNER_PATH), SCANNER_SHA),
}

def sha(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def pin(path: Path) -> dict:
 data=path.read_bytes(); return {'path':str(path.resolve()),'bytes':len(data),'sha256':sha(data)}
def json_safe(value):
 if isinstance(value,Path): return str(value)
 if isinstance(value,dict): return {str(k):json_safe(v) for k,v in value.items()}
 if isinstance(value,(list,tuple)): return [json_safe(v) for v in value]
 return value
def dump(path: Path, obj) -> None:
 path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(json_safe(obj),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def load_module(path: Path, expected: str, name: str):
 if pin(path)['sha256'] != expected: raise RuntimeError(name+' pin mismatch')
 spec=importlib.util.spec_from_file_location('retry_'+name,path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def parse_package(text: str) -> str:
 m=re.search(r'(?m)^\s*package\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*;',text)
 return m.group(1) if m else ''
def public_class(text: str):
 m=re.search(r'(?m)^\s*public\s+(?:(?:final|abstract|sealed|non-sealed)\s+)*class\s+([A-Za-z_$][\w$]*)\b',text)
 return m.group(1) if m else None
def source_identity(path: Path) -> dict:
 text=path.read_text(encoding='utf-8'); return {'package':parse_package(text),'class':public_class(text),'path':str(path.resolve()),'pin':pin(path)}
def main() -> int:
 if len(sys.argv)!=2: raise SystemExit('usage: collect.py /private/tmp/FRESH_OUTPUT')
 out=Path(sys.argv[1]).resolve()
 if out.exists(): raise SystemExit('refuse non-fresh output: '+str(out))
 pins=json.loads((HERE/'pins.json').read_text(encoding='utf-8'))
 if pins.get('schema')!='jarde-loop-catch-retry-pins-v2': raise SystemExit('pins schema mismatch')
 for row in pins['assets']:
  p=Path(row['path']); actual=pin(p)
  if actual['bytes']!=row['bytes'] or actual['sha256']!=row['sha256']: raise SystemExit('asset pin mismatch: '+str(p))
 binding=json.loads((HERE/'source_binding.json').read_text(encoding='utf-8'))
 if binding.get('status')!='root_pins_filled' or binding.get('cli')!=pins['cli'] or binding.get('focused_receipt')!=pins['focused_receipt']: raise SystemExit('CLI/focused binding mismatch')
 if Path(binding['cli']['path'])!=CLI or Path(binding['focused_receipt']['path'])!=FOCUSED: raise SystemExit('CLI/focused path mismatch')
 for name,(path,h) in TOOL_PINS.items():
  if pin(Path(path))['sha256']!=h: raise SystemExit(name+' pin mismatch')
 if (CLI.stat().st_mode & 0o777)!=0o555: raise SystemExit('CLI mode is not 0555')
 frozen=json.loads(FOCUSED.read_text(encoding='utf-8')).get('cli_freeze',{})
 if frozen.get('path')!=str(CLI) or frozen.get('sha256')!=pins['cli']['sha256'] or frozen.get('mode')!='0o555': raise SystemExit('focused v12 receipt does not bind exact CLI v4')
 guard=load_module(GUARD_PATH,GUARD_SHA,'guard'); scanner=load_module(SCANNER_PATH,SCANNER_SHA,'scanner')
 guard.ROOT=ROOT; guard.OUT=out/'raw'; guard.ENV_VALUES={}
 target_bytes=guard.target_bytes
 jm=json.loads(JDK_MANIFEST.read_text(encoding='utf-8')); legs={}
 for row in jm.get('legs',[]):
  leg=row.get('leg'); tools=row.get('jdk_tools',{})
  if leg not in ('javac8','javac23'): continue
  paths={n:Path(tools[n]['path']).resolve() for n in ('java','javac','javap')}
  if any(pin(paths[n])['sha256']!=tools[n]['sha256'] for n in paths): raise SystemExit('JDK tool pin mismatch: '+str(leg))
  legs[leg]={'tools':paths,'home':paths['java'].parent.parent,'manifest_pins':tools}
 if set(legs)!={'javac8','javac23'}: raise SystemExit('pinned JDK8/JDK23 missing')
 fixture=HERE/'RetryFixture.java'; runner=HERE/'Runner.java'; fixture_manifest=json.loads((HERE/'fixture-manifest.json').read_text(encoding='utf-8'))
 expected={x['path']:x for x in fixture_manifest['files']}
 for p in (fixture,runner):
  rec=expected[p.name]; actual=pin(p)
  if rec['bytes']!=actual['bytes'] or rec['sha256']!=actual['sha256']: raise SystemExit('frozen fixture pin mismatch: '+p.name)
 out.mkdir(parents=True); (out/'raw').mkdir(); (out/'inputs').mkdir()
 shutil.copyfile(fixture,out/'inputs/RetryFixture.java'); shutil.copyfile(runner,out/'inputs/Runner.java'); shutil.copyfile(HERE/'fixture-manifest.json',out/'inputs/manifest.json')
 guard.OUT=out/'raw'; guard.ROOT=ROOT; guard.expected_test_summaries=lambda index,stdout:None; guard.ENV_VALUES={}
 guard.command_stream=lambda p:{'path':str(Path(p).resolve()),'bytes':Path(p).stat().st_size,'sha256':sha(Path(p).read_bytes())}
 input_paths=[fixture,runner,HERE/'fixture-manifest.json',HERE/'pins.json',HERE/'source_binding.json',Path(__file__),CLI,FOCUSED,JDK_MANIFEST,JADX,JADX_JAR,GUARD_PATH,SCANNER_PATH,*[Path(x['path']) for x in pins['assets']]]
 input_paths.extend(p for v in legs.values() for p in v['tools'].values())
 tracked=[]; seen=set()
 for p in input_paths:
  key=str(p.resolve())
  if key not in seen: seen.add(key); tracked.append(p)
 before=[pin(p) for p in tracked]
 doc={'schema':SCHEMA,'status':'running','fixture':pin(fixture),'runner':pin(runner),'fixture_manifest':pin(HERE/'fixture-manifest.json'),'oracle':fixture_manifest['oracle'],'cli':pin(CLI),'focused_receipt':pin(FOCUSED),'tool_pins':{k:pin(Path(v[0])) for k,v in TOOL_PINS.items()},'jdk_legs':legs,'resource_guard':{'minimum_free_bytes':FREE_BYTES,'maximum_target_bytes':TARGET_BYTES,'sample_interval_seconds':1,'command_timeout_seconds':COMMAND_TIMEOUT,'process_group_termination':True},'commands':[],'lanes':[],'source_tool_pins_before':before}
 dump(out/'execution.json',doc)
 def run(label,argv,home,java_home=None):
  index=len(doc['commands'])+1; env={k:v for k,v in os.environ.items() if k not in STRIP_ENV}
  if java_home is not None: env['JAVA_HOME']=str(java_home); env['PATH']=str(Path(java_home)/'bin')+os.pathsep+env.get('PATH','')
  env_overrides={k:env[k] for k in ('JAVA_HOME','PATH') if k in env}
  stdout=out/'raw'/f'{index}.stdout.raw'; stderr=out/'raw'/f'{index}.stderr.raw'
  row={'index':index,'label':label,'argv':[str(x) for x in argv],'cwd':str(ROOT),'java_home':str(java_home) if java_home else None,'state':'started','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':COMMAND_TIMEOUT,'env_overrides':env_overrides}
  doc['commands'].append(row); dump(out/'execution.json',doc)
  free0=shutil.disk_usage(ROOT).free; size0=target_bytes(); peak=size0; stop=None; begin=time.monotonic(); exit_code=None
  with stdout.open('xb') as so,stderr.open('xb') as se:
   if free0<FREE_BYTES or size0>TARGET_BYTES:
    stop={'reason':'pre-command-resource-guard','free_bytes':free0,'target_bytes':size0}
   else:
    child=subprocess.Popen([str(x) for x in argv],cwd=ROOT,env=env,stdout=so,stderr=se,start_new_session=True)
    while child.poll() is None:
     elapsed=time.monotonic()-begin; size=target_bytes(); free=shutil.disk_usage(ROOT).free; peak=max(peak,size)
     if elapsed>=COMMAND_TIMEOUT or size>TARGET_BYTES or free<FREE_BYTES:
      reason='timeout' if elapsed>=COMMAND_TIMEOUT else 'resource-limit'
      stop={'reason':reason,'elapsed_seconds':elapsed,'free_bytes':free,'target_bytes':size}
      try: os.killpg(child.pid,signal.SIGTERM)
      except ProcessLookupError: pass
      try: child.wait(timeout=3)
      except subprocess.TimeoutExpired:
       try: os.killpg(child.pid,signal.SIGKILL)
       except ProcessLookupError: pass
       try: child.wait(timeout=1)
       except subprocess.TimeoutExpired: stop['reap_timeout']=True
      break
     time.sleep(1)
    exit_code=child.returncode if child.poll() is not None else None
  duration=time.monotonic()-begin; freef=shutil.disk_usage(ROOT).free; sizef=target_bytes(); peak=max(peak,sizef)
  if stop is None and (freef<FREE_BYTES or sizef>TARGET_BYTES): stop={'reason':'post-command-resource-limit','free_bytes':freef,'target_bytes':sizef}
  ob=stdout.read_bytes(); eb=stderr.read_bytes()
  row.update({'duration_seconds':duration,'exit_code':exit_code,'guard_stop':stop,'peak_target_bytes':peak,'free_bytes_after':freef,'streams':{'stdout':pin(stdout),'stderr':pin(stderr)},'state':'guard-stopped' if stop else 'observed'})
  dump(out/'execution.json',doc)
  return row,ob,eb
 def compile_run(label,sources,leg_name,mode,class_dir,run_class):
  class_dir.mkdir(parents=True); empty=class_dir.parent/'empty-paths'; empty.mkdir()
  flags=['-source','8','-target','8','-Xlint:-options'] if leg_name=='javac8' else ['--release','8']
  flags += ['-proc:none','-g' if mode=='debug' else '-g:none','-classpath',empty,'-sourcepath',empty,'-d',class_dir,*sources]
  jdk=legs[leg_name]['tools']; home=legs[leg_name]['home']
  comp,_,_=run(label+'-compile',[jdk['javac'],*flags],home,home)
  runtime=None; outbytes=b''; errbytes=b''
  if comp['exit_code']==0 and comp['guard_stop'] is None: runtime,outbytes,errbytes=run(label+'-run',[jdk['java'],'-Xverify:all','-cp',class_dir,run_class],home,home)
  files=sorted(class_dir.rglob('*.class'))
  return {'compile':comp,'run':runtime,'runtime_state':'ran' if runtime and runtime['exit_code'] is not None and not runtime['guard_stop'] else 'no-runtime','class_paths':[p.relative_to(class_dir).as_posix() for p in files],'classes':[pin(p) for p in files]},outbytes,errbytes
 def runner_for(package,where):
  data=runner.read_bytes(); prefix=(('package '+package+';\n').encode() if package else b'')
  target=where/'Runner.java'; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(prefix+data)
  return target, (package+'.Runner' if package else 'Runner')
 # Original source arms: two JDKs x two debug profiles.
 originals={}; classfiles={}
 for mode in ('debug','none'):
  for leg in ('javac8','javac23'):
   lane=f'{mode}/{leg}'; work=out/'legs'/mode/leg/'original'; sources=[out/'inputs/RetryFixture.java',out/'inputs/Runner.java']
   rec,stdout,stderr=compile_run('original-'+lane,sources,leg,mode,work/'classes','Runner')
   rec.update({'family':'original','mode':mode,'jdk':leg,'class_identity':'RetryFixture','runner_identity':'Runner','stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr),'oracle_byte_match':stdout==('\n'.join(fixture_manifest['oracle_stdout'])+'\n').encode(),'expected_stdout':fixture_manifest['oracle_stdout']})
   originals[(mode,leg)]=rec; doc['lanes'].append(rec); dump(out/'execution.json',doc)
   cf=work/'classes/RetryFixture.class'
   if rec['runtime_state']=='ran' and cf.is_file(): classfiles[(mode,leg)]=cf
   if cf.is_file():
    javap,jo,je=run('javap-'+lane,[legs[leg]['tools']['javap'],'-p','-c','-s','-v','-classpath',work/'classes','RetryFixture'],legs[leg]['home'],legs[leg]['home'])
    rawpath=out/'physical'/mode/leg/'RetryFixture.javap.raw'; rawpath.parent.mkdir(parents=True,exist_ok=True); rawpath.write_bytes(jo)
    methods=[]; lines=jo.decode('utf-8',errors='replace').splitlines()
    for i,line in enumerate(lines):
     if line.strip().startswith('descriptor:'):
      descriptor=line.split(':',1)[1].strip()
      if descriptor.startswith('('):
       prior=next((lines[j].strip() for j in range(i-1,max(-1,i-5),-1) if lines[j].strip()),None)
       methods.append({'declaration':prior,'descriptor':descriptor})
    rec['physical_identity']={'class':'RetryFixture','javap_raw':pin(rawpath),'javap_command':javap,'methods':methods}
    dump(out/'execution.json',doc)
 # JADX default/none sources for each exact original class.
 for mode in ('debug','none'):
  for leg in ('javac8','javac23'):
   cf=classfiles.get((mode,leg)); lane=f'{mode}/{leg}'
   if cf is None: continue
   jar=out/'inputs'/mode/leg/'RetryFixture.jar'; jar.parent.mkdir(parents=True,exist_ok=True)
   with zipfile.ZipFile(jar,'w',zipfile.ZIP_STORED) as z:
    info=zipfile.ZipInfo('RetryFixture.class',date_time=(1980,1,1,0,0,0)); info.compress_type=zipfile.ZIP_STORED; z.writestr(info,cf.read_bytes())
   for profile in ('default','none'):
    dest=out/'jadx'/mode/leg/profile; argv=[JADX,'--no-res','--config','none','--threads-count','1']
    if profile=='none': argv += ['--rename-flags','none']
    cmd,_,_=run(f'jadx-{profile}-{lane}',[*argv,'-d',dest,jar],legs['javac23']['home'],legs['javac23']['home'])
    sources=sorted(dest.rglob('*.java')) if dest.exists() else []
    idents=[source_identity(p) for p in sources]
    main=[x for x in idents if x['class']=='RetryFixture']
    lane_rec={'family':'jadx-'+profile,'mode':mode,'jdk':leg,'decompiler_command':cmd,'sources':idents,'whole_class_source_available':len(main)==1,'runtime_state':'no-runtime','compile_run':None}
    if len(main)==1:
     package=main[0]['package']; adapted,runclass=runner_for(package,out/'inputs'/'derived-runner'/mode/leg/profile)
     # Package alignment is restricted to the independent Runner copy.
     classdir=out/'legs'/mode/leg/('jadx-'+profile)/'classes'
     compiled,ob,eb=compile_run(f'jadx-{profile}-{lane}',[Path(main[0]['path']),adapted],leg,mode,classdir,runclass)
     original_stdout=Path(originals[(mode,leg)]['run']['streams']['stdout']['path']).read_bytes() if originals[(mode,leg)]['run'] else b''
     lane_rec['compile_run']=compiled; lane_rec['runtime_state']=compiled['runtime_state']; lane_rec['derived_runner']=pin(adapted); lane_rec['runner_identity']=runclass
     lane_rec['stdout_comparison']={'original_sha256':sha(original_stdout),'variant_sha256':sha(ob),'byte_identical':compiled['runtime_state']=='ran' and ob==original_stdout}
    doc['lanes'].append(lane_rec); dump(out/'execution.json',doc)
 # Jarde: render exact physical RetryFixture.class, retain unmodified response and complete report.
 for mode in ('debug','none'):
  for leg in ('javac8','javac23'):
   cf=classfiles.get((mode,leg)); lane=f'{mode}/{leg}'
   if cf is None: continue
   folder=out/'jarde'/mode/leg; folder.mkdir(parents=True,exist_ok=True)
   argv=[CLI,'class-source','--input',cf,'--class','RetryFixture','--policy','single-class','--release','8','--format','json','--evidence','all']
   cmd,raw,err=run('jarde-'+lane,argv,legs[leg]['home'],legs[leg]['home'])
   rawfile=folder/'response.raw.json'; rawfile.write_bytes(raw)
   jr={'family':'jarde','mode':mode,'jdk':leg,'render_command':cmd,'raw_response':pin(rawfile),'class_identity':None,'methods':[],'runtime_state':'no-runtime','compile_run':None}
   if cmd['exit_code']==0 and not cmd['guard_stop']:
    try:
     jd=json.loads(raw.decode('utf-8')); report_path=folder/'report.json'; dump(report_path,jd)
     jsource=folder/'RetryFixture.java'; jsource.write_text(jd['text'],encoding='utf-8')
     jr['class_identity']=jd.get('class'); jr['source_identity']={'package':parse_package(jd['text']),'class':public_class(jd['text'])}; jr['source']=pin(jsource); jr['report']=pin(report_path); jr['outcome']=jd.get('outcome'); jr['execution']=jd.get('execution')
     for method in jd.get('methods',[]):
      it=method.get('item',{}); identity=it.get('identity',{}); rep=method.get('outcome',{}).get('report',{})
      jr['methods'].append({'declaration':method.get('declaration'),'item':it,'identity':identity,'name':identity.get('name'),'descriptor':identity.get('descriptor'),'method_outcome_kind':method.get('outcome',{}).get('kind'),'report_outcome':rep.get('outcome'),'compile_status':rep.get('compile_status'),'syntax_status':rep.get('syntax_status'),'source_map':rep.get('source_map'),'diagnostics':rep.get('diagnostics',[])})
     pkg=parse_package(jd['text']); adapted,runclass=runner_for(pkg,out/'inputs'/'derived-runner'/mode/leg/'jarde')
     classdir=out/'legs'/mode/leg/'jarde'/'classes'
     compiled,ob,eb=compile_run('jarde-'+lane,[jsource,adapted],leg,mode,classdir,runclass)
     origstdout=Path(originals[(mode,leg)]['run']['streams']['stdout']['path']).read_bytes() if originals[(mode,leg)]['run'] else b''
     jr['compile_run']=compiled; jr['runtime_state']=compiled['runtime_state']; jr['derived_runner']=pin(adapted); jr['runner_identity']=runclass
     jr['stdout_comparison']={'original_sha256':sha(origstdout),'variant_sha256':sha(ob),'byte_identical':compiled['runtime_state']=='ran' and ob==origstdout}
    except (UnicodeError,ValueError,TypeError,KeyError) as exc: jr['parse_error']={'type':type(exc).__name__,'message':str(exc)}
   doc['lanes'].append(jr); dump(out/'execution.json',doc)
 after=[pin(p) for p in tracked]; doc['source_tool_pins_after']=after; doc['source_tool_inputs_unchanged']=before==after
 doc['actual_command_count']=len(doc['commands']); doc['status']='observed' if doc['source_tool_inputs_unchanged'] else 'failed'
 if not doc['source_tool_inputs_unchanged']: doc['failure']={'type':'SourcePinChanged','message':'pinned input/tool changed during run'}
 dump(out/'execution.json',doc)
 return 0 if doc['status']=='observed' else 1
if __name__=='__main__':
 try: raise SystemExit(main())
 except SystemExit: raise
 except BaseException as exc:
  if len(sys.argv)==2:
   target=Path(sys.argv[1]).resolve()/'execution.json'
   if target.is_file():
    try:
     failed=json.loads(target.read_text(encoding='utf-8')); failed['status']='failed'; failed['failure']={'type':type(exc).__name__,'message':str(exc),'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}; dump(target,failed)
    except BaseException: pass
  raise
