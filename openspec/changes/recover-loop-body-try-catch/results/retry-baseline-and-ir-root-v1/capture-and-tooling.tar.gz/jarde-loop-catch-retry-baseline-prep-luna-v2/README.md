# Loop catch retry 双 JDK 基线采集包 v2

此包以 v1 的两个 Java 文件为固定输入，SHA 与上游派生关系见 `fixture-manifest.json`。执行脚本不会改写 `RetryFixture.java` 或任何 JADX/Jarde 生成的产品源码。唯一允许的源码派生是独立 Runner 副本：若被测源码声明了 package，就只给副本添加相同 package 行，使 default-package Runner 能引用该类。

采集矩阵为 debug/none × javac8/javac23 × original/JADX default/JADX none/Jarde。每个来源先完整编译再以 `java -Xverify:all` 运行；编译不成功或命令被 guard 中止时保留 `no-runtime` 状态。JADX 的 Java runtime 使用已固定的 Java 23 home，与先前 baseline 一致。Jarde 对每个精确原始 `RetryFixture.class` 调用 root 固定 CLI v4 的 `class-source`，保留原始 JSON、完整方法身份/diagnostics/source map 和生成的整类源，然后编译运行整类输出。

所有外部命令使用每命令 28 秒硬限时，最多 4 秒 TERM/KILL 收尾；每秒检查 5 GiB 可用空间和项目 `target` 不超过 1 GiB，超限时终止整个进程组。receipt 保留实际 argv、退出码、原始 stdout/stderr 字节文件和摘要、物理 javap class/method identity、Jarde identity、每条 lane 的 class 路径及相对 original 的 stdout 字节对比。完整 oracle 仅记录观测目标，不代替 root 审阅。

在 fresh 输出目录执行一次：

```sh
python3 -B /private/tmp/jarde-loop-catch-retry-baseline-prep-luna-v2/collect.py /private/tmp/jarde-loop-catch-retry-baseline-root-v2-v1
```

`source_binding.json` 和 `pins.json` 绑定 CLI v4 SHA `d3d15d3d…d8c65e6f` 及 focused v12 receipt SHA `74350dfc…996a73`。此次准备只运行 Python 标准库静态/序列化校验，没有运行 Java/JADX/Jarde CLI/Cargo/Git。
