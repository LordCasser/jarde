import java.util.ArrayList;
import java.util.List;

/**
 * Test fixture derived from jadx TestTryCatchInLoop.TestCls.
 * The default threshold reproduces two caught failures, then success on call 3.
 */
public class RetryFixture {
	int c = 0;
	int caught = 0;
	int breaks = 0;
	final int failuresBeforeSuccess;
	final int errorOnCall;
	final List<String> events = new ArrayList<String>();

	public RetryFixture(int failuresBeforeSuccess, int errorOnCall) {
		this.failuresBeforeSuccess = failuresBeforeSuccess;
		this.errorOnCall = errorOnCall;
	}

	public int test() {
		while (true) {
			try {
				exc();
				breaks++;
				events.add("break:" + c);
				break;
			} catch (Exception e) {
				caught++;
				events.add("catch:" + c);
			}
		}
		if (c == 5) {
			System.out.println(c);
		}
		return 0;
	}

	private void exc() throws Exception {
		c++;
		events.add("call:" + c);
		if (c == errorOnCall) {
			throw new AssertionError("uncaught-error:" + c);
		}
		if (c < failuresBeforeSuccess + 1) {
			throw new Exception();
		}
		events.add("success:" + c);
	}
}
