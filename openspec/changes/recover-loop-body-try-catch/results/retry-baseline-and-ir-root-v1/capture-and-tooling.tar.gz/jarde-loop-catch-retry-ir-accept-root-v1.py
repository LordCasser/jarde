#!/usr/bin/env python3
"""Independent root acceptance of completed observations, never product acceptance."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
TMP = Path('/private/tmp')
BASE = TMP / 'jarde-loop-catch-retry-same-run-ir-root-v1'
OUT = TMP / 'jarde-loop-catch-retry-same-run-ir-acceptance-root-v1'

def digest(path):
    raw = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def verify(pin):
    assert digest(pin['path']) == pin, pin['path']

def section(text, start, end):
    return text.split(start, 1)[1].split(end, 1)[0]

receipt = json.loads((BASE / 'execution.json').read_text())
assert receipt['status'] == 'collected_observations_only'
assert receipt['source_restored_byte_identity'] and receipt['target_absent']
assert not (ROOT / 'target').exists()
before = receipt['source_manifest_before']
assert len(before) == 4822 and before == receipt['source_manifest_after']
frozen = json.loads((TMP / 'jarde-cf11-structured-list-focused-root-v12/execution.json').read_text())
assert before == frozen['source_manifest_before']
for row in before:
    actual = digest(ROOT / row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row['path']
patched = receipt['temporary_source_manifest']
assert len(patched) == len(before)
assert [x['path'] for x, y in zip(patched, before) if x != y] == ['crates/jarde-java/src/region.rs']
verify(receipt['runner'])
verify(receipt['prep_pins'])
for row in receipt['candidate_pins'].values():
    verify(row)
for row in receipt['dependencies']:
    verify(row)
assert receipt['rust_min_stack'] is None
assert receipt['guard'] == {'minimum_free_bytes': 5 * 1024**3,
                            'maximum_target_bytes': 1024**3, 'sample_interval_seconds': 1}
commands = receipt['commands']
assert len(commands) == 9 and [x['index'] for x in commands] == list(range(1, 10))
for command in commands:
    assert command['exit_code'] == 0 and command.get('guard_stop') is None
    for pin in command['streams'].values():
        verify(pin)
assert commands[-1]['argv'] == ['cargo', 'clean']
assert commands[-1]['cleanup_only']['observed_after']['target_bytes'] == 0
expected_lanes = [(version, mode, jdk) for version in ('v2', 'v3')
                  for mode in ('debug', 'none') for jdk in ('javac8', 'javac23')]
assert len(receipt['lanes']) == 8
observations = []
for lane, expected in zip(receipt['lanes'], expected_lanes):
    assert (lane['fixture_version'], lane['mode'], lane['jdk']) == expected
    verify(lane['baseline_receipt'])
    verify(lane['class_pin'])
    cli = json.loads(Path(lane['baseline_receipt']['path']).read_text())
    cli_lane = next(x for x in cli['lanes'] if x['family'] == 'jarde'
                    and x['mode'] == lane['mode'] and x['jdk'] == lane['jdk'])
    verify(cli_lane['raw_response'])
    identity = cli_lane['class_identity']['class_bytes']
    command = commands[lane['command_index'] - 1]
    assert command['argv'] == ['cargo', 'test', '-p', 'jarde-java', '--lib', '--locked',
        'region::tests::loop_catch_retry_same_run_ir_diagnostic', '--', '--exact', '--nocapture']
    assert command['env_overrides']['JARDE_LOOP_CATCH_RETRY_CLASS'] == lane['class_pin']['path']
    stdout = Path(command['streams']['stdout']['path']).read_text()
    stdout = re.sub(r'\x1b\[[0-9;]*m', '', stdout)
    assert re.findall(r'^test (.+) \.\.\. (ok|FAILED)', stdout, re.M) == [
        ('region::tests::loop_catch_retry_same_run_ir_diagnostic', 'ok')]
    assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in stdout
    text = Path(command['streams']['stderr']['path']).read_text()
    assert text.count('LCR-BEGIN ') == 1 and text.count('LCR-END') == 1
    assert f'LCR-BEGIN class=RetryFixture method=test descriptor=()I path={lane["class_pin"]["path"]}' in text
    physical = section(text, 'LCR-IDENTITY physical=', '\n')
    assert f'digest: Digest("{identity["digest"]}")' in physical
    assert f'length: {identity["length"]}' in physical
    assert 'name: JvmBytes([116, 101, 115, 116])' in physical
    assert 'descriptor: JvmBytes([40, 41, 73])' in physical
    analysis = section(text, 'LCR-ANALYSIS ', 'LCR-CODE ')
    assert 'execution=Complete {' in analysis
    stages = re.findall(r'StageResult \{ stage: (\w+), state: (\w+) \}', analysis)
    assert stages == [(x, 'Completed') for x in
                      ('RawFacts', 'RawCfg', 'LegacyNormalization', 'CanonicalCfg', 'Frame', 'Ssa')]
    handlers = section(text, 'LCR-CODE handlers=', ' instructions=')
    rows = re.findall(r'ordinal: (\d+),\s*start_bci: (\d+),\s*end_bci: (\d+),\s*handler_bci: (\d+)', handlers)
    assert len(rows) == 1 and rows[0][0:2] == ('0', '0')
    end, handler = int(rows[0][2]), int(rows[0][3])
    normal = section(text, 'LCR-NORMAL ids=', 'LCR-SSA ')
    ids = list(map(int, re.findall(r'bci: (\d+),', normal.split('] edges=', 1)[0])))
    pairs = [(int(a), int(b)) for a, b in re.findall(
        r'from: CanonicalBlockId \{\s*bci: (\d+),\s*path: \[\],\s*\},\s*to: CanonicalBlockId \{\s*bci: (\d+),', normal)]
    assert len(ids) == 5 and len(pairs) == 5 and (handler, 0) in pairs
    assert (0, handler) not in pairs
    visiting, done = set(), set()
    def visit(node):
        assert node not in visiting, 'ordinary graph unexpectedly cyclic'
        if node in done:
            return
        visiting.add(node)
        for a, b in pairs:
            if a == node:
                visit(b)
        visiting.remove(node)
        done.add(node)
    for node in ids:
        visit(node)
    canonical = section(text, 'LCR-CANONICAL ', 'LCR-NORMAL ')
    assert re.search(r'from: CanonicalBlockId \{\s*bci: 0,.*?to: CanonicalBlockId \{\s*bci: '
                     + str(handler) + r',.*?kind: Exception', canonical, re.S)
    owners = section(text, 'LCR-REGION-PRE-OVERLAP ', ' raw_regions=')
    assert owners.startswith('first_duplicate=Some(CanonicalBlockId { bci: 0, path: [] })')
    duplicated = [(int(a), list(map(int, re.findall(r'\d+', b)))) for a, b in re.findall(
        r'CanonicalBlockId \{\s*bci: (\d+),\s*path: \[\],\s*\},\s*\[([^]]*)\]', owners)]
    assert duplicated == [(0, [0, 0]), (handler, [0, 0])]
    raw_tree = section(text, ' raw_regions=', 'LCR-REPORT ')
    assert raw_tree.count('\n    Try {') == 1
    assert raw_tree.count('body: Try {') == 1
    assert 'normal_exit_bci: None' in raw_tree and 'reason: Loop {' in raw_tree
    report = section(text, 'LCR-REPORT ', 'LCR-END')
    assert 'execution=Complete {' in report and 'content=ExplanationOnly' in report
    assert 'code: "jre_region_ownership_overlap"' in report
    observations.append({**{k: lane[k] for k in ('fixture_version', 'mode', 'jdk')},
                         'class_pin': lane['class_pin'], 'physical_class_identity': identity,
                         'handler_row': {'start': 0, 'end': end, 'handler': handler},
                         'ordinary_edges': pairs, 'ordinary_graph_acyclic': True,
                         'duplicate_owners': duplicated, 'first_overlap_bci': 0,
                         'same_root_nested_try': True,
                         'analysis_and_recovery_complete': True})
OUT.mkdir()
summary = {'status': 'accepted_same_run_observations_only', 'implementation_accepted': False,
           'execution': digest(BASE / 'execution.json'), 'checker': digest(Path(__file__)),
           'commands': 9, 'raw_streams': 18, 'physical_methods': 8,
           'source_closure_count': 4822, 'restored_exact': True, 'target_absent': True,
           'limitation': 'Minimal MethodFacts; not the CLI debug-name RecoveryFacts request.',
           'observations': observations}
(OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: summary[k] for k in ('status', 'commands', 'physical_methods', 'restored_exact')}, ensure_ascii=False))
