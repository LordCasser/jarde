// Private one-method same-run retry IR observation; insertion inside region.rs's existing tests.
#[test]
fn loop_catch_retry_same_run_ir_diagnostic() {
    use jarde_jvm::engine::analyze_method_ir;
    use jarde_jvm::environment::ResolutionEnvironment;
    use jarde_jvm::ir::{AnalysisStage, MethodAnalysisRequest, StageState};
    use jarde_reader::artifact::{ArtifactInput, ArtifactSnapshot};
    use jarde_reader::budget::{Budget, Limits};
    use jarde_reader::model::{
        ClassBytesId, Digest, JvmBytes, PhysicalClassLocation, PhysicalDefinitionId,
        PhysicalMethodId, PhysicalVariant,
    };
    use jarde_reader::view::{
        DelegationPolicy, LayoutMode, LoadDomain, LoadRoot, LoaderId, ModuleMode,
        MultiReleasePolicy, PhysicalScope, PhysicalView, RuntimeProfile, RuntimeUncertainty,
        RuntimeView,
    };

    let class_path = std::env::var("JARDE_LOOP_CATCH_RETRY_CLASS")
        .expect("root runner supplies completed RetryFixture.class path");
    let class = std::fs::read(&class_path).expect("read pinned RetryFixture.class");
    let mut budget = Budget::new(Limits {
        input_bytes: 1 << 20, archive_entries: 100, entry_bytes: 1 << 20,
        read_bytes: 1 << 20, class_bytes: 1 << 20, attribute_bytes: 1 << 20,
        code_bytes: 1 << 20, result_items: 1 << 20, output_bytes: 1 << 20,
        class_headers: 100, method_bodies: 100, ir_items: 1 << 20, ir_edges: 1 << 20,
        analysis_steps: 1 << 20, normalization_clones: 1 << 20, nested_depth: 32,
        dependency_depth: 32, elapsed_millis: u64::MAX,
    });
    let snapshot = ArtifactSnapshot::open(ArtifactInput::bytes(class.clone()), &mut budget)
        .expect("exact class opens");
    let definition = PhysicalDefinitionId {
        location: PhysicalClassLocation::StandaloneRoot { snapshot: snapshot.id().clone() },
        class_bytes: ClassBytesId {
            digest: Digest(blake3::hash(&class).to_hex().to_string()),
            length: u64::try_from(class.len()).expect("class length fits"),
        },
        variant: PhysicalVariant::Base,
    };
    let domain = LoadDomain {
        loader: LoaderId("app".to_owned()), parent_loader: None,
        delegation: DelegationPolicy::ParentFirst,
        roots: vec![LoadRoot::StandaloneClass { snapshot: snapshot.id().clone() }],
        module_mode: ModuleMode::ClassPath,
        external_override: RuntimeUncertainty::None,
        runtime_transformation: RuntimeUncertainty::None,
    };
    let analysis = analyze_method_ir(
        &[snapshot.clone()],
        &MethodAnalysisRequest {
            environment: ResolutionEnvironment {
                runtime: RuntimeView {
                    physical: PhysicalView {
                        snapshot: snapshot.id().clone(), scope: PhysicalScope::SnapshotAll,
                    },
                    profile: RuntimeProfile {
                        java_release: 8, multi_release: MultiReleasePolicy::Disabled,
                        layout: LayoutMode::Generic,
                    },
                    load_domain: domain.clone(),
                },
                domains: vec![domain], providers: Vec::new(),
            },
            method: PhysicalMethodId {
                owner: definition,
                name: JvmBytes(b"test".to_vec()),
                descriptor: JvmBytes(b"()I".to_vec()),
            },
            stages: AnalysisStage::ALL.to_vec(),
        },
        &mut budget,
    ).expect("same-run method IR analysis succeeds");
    let analysis_report = analysis.report();
    assert!(matches!(&analysis_report.execution,
        jarde_reader::model::ExecutionReport::Complete { .. }),
        "method analysis stopped: {:?}", analysis_report.execution);
    assert!(analysis_report.stages.iter().all(|stage| stage.state == StageState::Completed),
        "same-run stages incomplete: {:?}", analysis_report.stages);
    let ir = analysis.ir();
    let canonical = ir.canonical().expect("same-run canonical CFG");
    let ssa = ir.ssa().expect("same-run SSA");
    let code = ir.code().expect("same-run code facts");
    eprintln!("LCR-BEGIN class=RetryFixture method=test descriptor=()I path={class_path}");
    eprintln!("LCR-IDENTITY physical={:?}", analysis_report.method);
    eprintln!("LCR-ANALYSIS execution={:?} stages={:?} usage={:?}",
        analysis_report.execution, analysis_report.stages, budget.usage());
    eprintln!("LCR-CODE handlers={:#?} instructions={:#?}",
        code.exception_handlers, code.instructions);
    eprintln!("LCR-CANONICAL blocks={:#?} edges={:#?} throw_sites={:#?} handler_rows={:#?}",
        canonical.blocks(), canonical.edges(), canonical.throw_sites(), canonical.handler_rows());
    let normal_view = crate::normal_flow::NormalFlowView::build(canonical, &mut budget)
        .expect("same-run normal-flow projection");
    let normal_edges = canonical.edges().iter().filter(|edge|
        matches!(edge.kind(), CanonicalEdgeKind::Normal | CanonicalEdgeKind::Return { .. }))
        .collect::<Vec<_>>();
    eprintln!("LCR-NORMAL ids={:#?} edges={normal_edges:#?}", normal_view.ids());
    eprintln!("LCR-SSA blocks={:#?} values={:#?} phis={:#?}",
        ssa.blocks(), ssa.values_with_ids().collect::<Vec<_>>(), ssa.phis());

    let declaration = ir.declaration().expect("same-run method declaration");
    let facts = crate::facts::RecoveryFacts::new(
        crate::facts::MethodFacts::new("test", "()I", declaration.parameter_slots())
            .with_access_flags(declaration.access_flags()),
    );
    let mut recovery_budget = Budget::new(Limits {
        input_bytes: 1 << 20, archive_entries: 100, entry_bytes: 1 << 20,
        read_bytes: 1 << 20, class_bytes: 1 << 20, attribute_bytes: 1 << 20,
        code_bytes: 1 << 20, result_items: 1 << 20, output_bytes: 1 << 20,
        class_headers: 100, method_bodies: 100, ir_items: 1 << 20, ir_edges: 1 << 20,
        analysis_steps: 1 << 20, normalization_clones: 1 << 20, nested_depth: 32,
        dependency_depth: 32, elapsed_millis: u64::MAX,
    });
    let report = crate::report::recover(
        &crate::report::RecoveryRequest::new(ir, &facts, crate::pass::JAVA_8),
        &mut recovery_budget,
    );
    assert!(matches!(&report.execution,
        jarde_reader::model::ExecutionReport::Complete { .. }),
        "same-payload recovery report stopped: {:?}", report.execution);
    eprintln!("LCR-REPORT outcome={:?} quality={:?} content={:?} execution={:?} regions={:#?} diagnostics={:#?} usage={:?}",
        report.outcome, report.quality, report.content, report.execution,
        report.regions, report.diagnostics, recovery_budget.usage());
    eprintln!("LCR-END");
}
