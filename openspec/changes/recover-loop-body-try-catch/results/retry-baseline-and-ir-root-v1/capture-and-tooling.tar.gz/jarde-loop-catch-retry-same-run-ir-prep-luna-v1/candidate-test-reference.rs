// Candidate insertion inside `#[cfg(test)] mod tests` at the bottom of crates/jarde-java/src/region.rs.
// This is private test-only observation: no production branch or proof gate changes.
#[test]
fn loop_body_catch_same_run_ir_diagnostic() {
    use jarde_jvm::engine::analyze_method_ir;
    use jarde_jvm::environment::ResolutionEnvironment;
    use jarde_jvm::ir::{AnalysisStage, MethodAnalysisRequest, StageState};
    use jarde_reader::artifact::{ArtifactInput, ArtifactSnapshot};
    use jarde_reader::budget::{Budget, Limits};
    use jarde_reader::model::{
        ClassBytesId, Digest, JvmBytes, PhysicalClassLocation, PhysicalDefinitionId,
        PhysicalMethodId, PhysicalVariant,
    };
    use jarde_reader::view::{
        DelegationPolicy, LayoutMode, LoadDomain, LoadRoot, LoaderId, ModuleMode,
        MultiReleasePolicy, PhysicalScope, PhysicalView, RuntimeProfile, RuntimeUncertainty,
        RuntimeView,
    };

    fn one(class_path: &str, owner: &str, name: &str, descriptor: &str) {
        let class = std::fs::read(class_path).expect("root supplied terminal-baseline class path");
        let mut budget = Budget::new(Limits {
            input_bytes: 1 << 20,
            archive_entries: 100,
            entry_bytes: 1 << 20,
            read_bytes: 1 << 20,
            class_bytes: 1 << 20,
            attribute_bytes: 1 << 20,
            code_bytes: 1 << 20,
            result_items: 1 << 20,
            output_bytes: 1 << 20,
            class_headers: 100,
            method_bodies: 100,
            ir_items: 1 << 20,
            ir_edges: 1 << 20,
            analysis_steps: 1 << 20,
            normalization_clones: 1 << 20,
            nested_depth: 32,
            dependency_depth: 32,
            elapsed_millis: u64::MAX,
        });
        let snapshot = ArtifactSnapshot::open(ArtifactInput::bytes(class.clone()), &mut budget)
            .expect("exact class opens");
        let definition = PhysicalDefinitionId {
            location: PhysicalClassLocation::StandaloneRoot { snapshot: snapshot.id().clone() },
            class_bytes: ClassBytesId {
                digest: Digest(blake3::hash(&class).to_hex().to_string()),
                length: u64::try_from(class.len()).expect("class length fits"),
            },
            variant: PhysicalVariant::Base,
        };
        let domain = LoadDomain {
            loader: LoaderId("app".to_owned()),
            parent_loader: None,
            delegation: DelegationPolicy::ParentFirst,
            roots: vec![LoadRoot::StandaloneClass { snapshot: snapshot.id().clone() }],
            module_mode: ModuleMode::ClassPath,
            external_override: RuntimeUncertainty::None,
            runtime_transformation: RuntimeUncertainty::None,
        };
        let analysis = analyze_method_ir(
            &[snapshot.clone()],
            &MethodAnalysisRequest {
                environment: ResolutionEnvironment {
                    runtime: RuntimeView {
                        physical: PhysicalView {
                            snapshot: snapshot.id().clone(),
                            scope: PhysicalScope::SnapshotAll,
                        },
                        profile: RuntimeProfile {
                            java_release: 8,
                            multi_release: MultiReleasePolicy::Disabled,
                            layout: LayoutMode::Generic,
                        },
                        load_domain: domain.clone(),
                    },
                    domains: vec![domain],
                    providers: Vec::new(),
                },
                method: PhysicalMethodId {
                    owner: definition,
                    name: JvmBytes(name.as_bytes().to_vec()),
                    descriptor: JvmBytes(descriptor.as_bytes().to_vec()),
                },
                stages: AnalysisStage::ALL.to_vec(),
            },
            &mut budget,
        )
        .expect("same-run method IR analysis succeeds");
        let analysis_report = analysis.report();
        assert!(matches!(
            &analysis_report.execution,
            jarde_reader::model::ExecutionReport::Complete { .. }
        ), "method analysis must have no stop: {:?}", analysis_report.execution);
        assert!(analysis_report.stages.iter().all(|stage| stage.state == StageState::Completed),
            "all requested same-run stages must complete: {:?}", analysis_report.stages);
        let ir = analysis.ir();
        let canonical = ir.canonical().expect("same run canonical CFG");
        let ssa = ir.ssa().expect("same run SSA");
        let code = ir.code().expect("same run decoded method facts");
        let view = NormalFlowView::build(canonical, &mut budget).expect("normal-flow view");

        eprintln!("\nLBC-RUN-BEGIN class={owner} method={name} descriptor={descriptor}");
        eprintln!("LBC-IDENTITY physical={:?}", analysis_report.method);
        eprintln!("LBC-ANALYSIS execution={:?} stages={:?} usage={:?}",
            analysis_report.execution, analysis_report.stages, budget.usage());
        eprintln!("LBC-CODE exception_handlers={:#?}", code.exception_handlers);
        eprintln!("LBC-CODE instructions={:#?}", code.instructions);
        eprintln!("LBC-CANONICAL blocks={:#?}", canonical.blocks());
        eprintln!("LBC-CANONICAL edges={:#?}", canonical.edges());
        eprintln!("LBC-CANONICAL throw_sites={:#?}", canonical.throw_sites());
        eprintln!("LBC-CANONICAL handler_rows={:#?}", canonical.handler_rows());
        eprintln!("LBC-NORMAL ids={:#?}", view.ids());
        let normal_edges = canonical.edges().iter().filter(|edge|
            matches!(edge.kind(), CanonicalEdgeKind::Normal | CanonicalEdgeKind::Return { .. }))
            .collect::<Vec<_>>();
        eprintln!("LBC-NORMAL edges={normal_edges:#?}");
        let no_exemptions = BTreeSet::new();
        let irreducible = view.irreducible_blocks(&no_exemptions);
        eprintln!("LBC-QII irreducible_node_indices={irreducible:?} irreducible_block_ids={:?} irreducible_bcis={:?}",
            irreducible.iter().filter_map(|node| view.id_of(*node)).collect::<Vec<_>>(),
            irreducible.iter().filter_map(|node| view.id_of(*node).map(CanonicalBlockId::bci)).collect::<Vec<_>>());
        let mut normal_graph = petgraph::graph::DiGraph::<(), ()>::new();
        for _ in view.ids() { normal_graph.add_node(()); }
        for edge in &normal_edges {
            if let (Some(from), Some(to)) = (view.index_of(edge.from()), view.index_of(edge.to())) {
                normal_graph.add_edge(petgraph::graph::NodeIndex::new(from), petgraph::graph::NodeIndex::new(to), ());
            }
        }
        let irreducible_nodes = irreducible.iter().copied().collect::<BTreeSet<_>>();
        for component in petgraph::algo::tarjan_scc(&normal_graph) {
            let members = component.iter().map(|node| node.index()).collect::<BTreeSet<_>>();
            let cyclic = component.len() > 1 || component.first().is_some_and(|node|
                normal_graph.find_edge(*node, *node).is_some());
            if !cyclic || members.is_disjoint(&irreducible_nodes) { continue; }
            let outside_normal_entries = normal_edges.iter().filter(|edge|
                view.index_of(edge.to()).is_some_and(|to| members.contains(&to))
                    && view.index_of(edge.from()).is_some_and(|from| !members.contains(&from)))
                .map(|edge| (edge.from().clone(), edge.to().clone(), edge.kind())).collect::<Vec<_>>();
            let adjacent_exception_edges = canonical.edges().iter().filter(|edge|
                matches!(edge.kind(), CanonicalEdgeKind::Exception { .. })
                    && (view.index_of(edge.from()).is_some_and(|node| members.contains(&node))
                        || view.index_of(edge.to()).is_some_and(|node| members.contains(&node))))
                .map(|edge| (edge.from().clone(), edge.to().clone(), edge.kind())).collect::<Vec<_>>();
            eprintln!("LBC-QII irreducible_scc_block_ids={:?} outside_normal_entry_edges={outside_normal_entries:?} adjacent_exception_edges={adjacent_exception_edges:?}",
                members.iter().filter_map(|node| view.id_of(*node)).collect::<Vec<_>>());
        }
        for (node, id) in view.ids().iter().enumerate() {
            if let Some(lp) = view.loop_entered_at(node) {
                eprintln!("LBC-LOOP header={id:?} latches={:?} members={:?} irreducible={}",
                    lp.latches().iter().filter_map(|n| view.id_of(*n)).collect::<Vec<_>>(),
                    lp.blocks().iter().filter_map(|n| view.id_of(*n)).collect::<Vec<_>>(),
                    lp.is_irreducible());
            }
        }
        for edge in canonical.edges() {
            eprintln!("LBC-EDGE {:?} -> {:?} {:?}", edge.from(), edge.to(), edge.kind());
        }

        let mut proof_budget = Budget::new(Limits {
            analysis_steps: 1 << 20,
            elapsed_millis: u64::MAX,
            ..Limits::default()
        });
        let proved = proved_loop_catch_joins(canonical, &view, code, &mut proof_budget)
            .expect("existing certificate completes under ample private test budget");
        // Re-state every current certificate conjunct, without changing the certificate.
        for handler in canonical.handler_rows().iter().filter_map(|row| {
            row.handler().and_then(|id| view.index_of(id).map(|node| (id.clone(), node)))
        }).collect::<BTreeSet<_>>() {
            let (handler_id, handler_node) = handler;
            let successors = view.successors(handler_node);
            let rows = canonical.handler_rows().iter().filter(|row| {
                row.handler().and_then(|id| view.index_of(id)) == Some(handler_node)
            }).collect::<Vec<_>>();
            let declared_missing = code.exception_handlers.iter().filter(|declared| {
                declared.handler_bci == handler_id.bci()
            }).filter(|declared| !rows.iter().any(|row| row.ordinal() == declared.ordinal)).collect::<Vec<_>>();
            eprintln!("LBC-QI handler={handler_id:?} successor_ids={:?} predicate_one_normal_successor={} predicate_no_ordinary_predecessor={} rows={rows:#?} declared_unmapped_rows={declared_missing:#?}",
                successors.iter().filter_map(|node| view.id_of(*node)).collect::<Vec<_>>(),
                successors.len() == 1,
                view.predecessors(handler_node).is_empty());
            eprintln!("LBC-QI handler={handler_id:?} predicate_every_row_named_and_nonempty={}", rows.iter().all(|row|
                row.catch_type_index().is_some() && !row.protected().is_empty()));
            if let [join] = successors.as_slice() {
                for header in 0..view.len() {
                    let Some(loop_of) = view.loop_entered_at(header) else { continue; };
                    eprintln!("LBC-QI header={:?} join={:?} predicate_join_not_header={} predicate_join_in_natural_loop={} predicate_header_dominates_join={}",
                        view.id_of(header), view.id_of(*join), *join != header,
                        loop_of.blocks().contains(join), view.dominates(header, *join));
                    for row in &rows {
                        let declared = code.exception_handlers.iter().find(|d| d.ordinal == row.ordinal());
                        let table_blocks = declared.into_iter().flat_map(|d| canonical.blocks().iter().filter(move |block|
                            block.id().bci() < d.end_bci && block.end_bci() > d.start_bci)).collect::<Vec<_>>();
                        eprintln!("LBC-QI row_ordinal={} declared_row={declared:?} table_range_blocks_bci_end_header_excluded_loop_member_header_dominates={:#?}", row.ordinal(),
                            table_blocks.iter().map(|block| (block.id(), block.end_bci(),
                                block.id().bci() != view.id_of(header).map_or(u32::MAX, CanonicalBlockId::bci),
                                view.index_of(block.id()).is_some_and(|n| loop_of.blocks().contains(&n)),
                                view.index_of(block.id()).is_some_and(|n| view.dominates(header, n))))
                                .collect::<Vec<_>>());
                        for protected in row.protected() {
                            let node = view.index_of(protected);
                            eprintln!("LBC-QI row_ordinal={} protected_block={protected:?} actual_throw_sites={:?} predicate_protected_in_loop={} predicate_header_dominates_protected={} predicate_ordinary_paths_reach_join={}",
                                row.ordinal(), canonical.throw_sites().iter().filter(|site|
                                    site.block() == protected && site.handlers().contains(&row.ordinal())).collect::<Vec<_>>(),
                                node.is_some_and(|n| loop_of.blocks().contains(&n)),
                                node.is_some_and(|n| view.dominates(header, n)),
                                node.is_some_and(|n| plain_paths_reach_join(&view, n, *join, &mut proof_budget)
                                    .expect("ample path-proof budget must not stop")));
                        }
                    }
                }
            }
        }
        for site in canonical.throw_sites() {
            let node = view.index_of(site.block());
            eprintln!("LBC-QI actual_throw_site={site:#?} natural_loop_membership_headers={:?}",
                (0..view.len()).filter(|header| view.loop_entered_at(*header).is_some_and(|lp|
                    node.is_some_and(|n| lp.blocks().contains(&n))))
                    .filter_map(|header| view.id_of(header)).collect::<Vec<_>>());
        }
        eprintln!("LBC-QI proved_loop_catch_joins={proved:?} proof_usage={:?}", proof_budget.usage());
        let mut candidate_handler_joins = BTreeSet::new();
        for row in canonical.handler_rows() {
            let Some(handler) = row.handler().and_then(|id| view.index_of(id)) else { continue; };
            if view.predecessors(handler).is_empty() {
                let successors = view.successors(handler);
                if let [join] = successors.as_slice() {
                    candidate_handler_joins.insert((handler, *join));
                }
            }
        }
        let hypothetical_irreducible = view.irreducible_blocks(&candidate_handler_joins);
        eprintln!("LBC-QII hypothetical_exception_root_single_successor_joins={candidate_handler_joins:?} irreducible_node_indices={hypothetical_irreducible:?} irreducible_block_ids={:?} irreducible_bcis={:?}",
            hypothetical_irreducible.iter().filter_map(|node| view.id_of(*node)).collect::<Vec<_>>(),
            hypothetical_irreducible.iter().filter_map(|node| view.id_of(*node).map(CanonicalBlockId::bci)).collect::<Vec<_>>());
        let candidate_irreducible = view.irreducible_blocks(&proved);
        eprintln!("LBC-QII current_proved_joins={proved:?} irreducible_node_indices={candidate_irreducible:?} irreducible_block_ids={:?} irreducible_bcis={:?}",
            candidate_irreducible.iter().filter_map(|node| view.id_of(*node)).collect::<Vec<_>>(),
            candidate_irreducible.iter().filter_map(|node| view.id_of(*node).map(CanonicalBlockId::bci)).collect::<Vec<_>>());

        // Same payload through the production recovery report supplies the first refusal/fallback
        // alongside the IR dump. Populate identity and parameter slots from this payload.
        let declaration = ir.declaration().expect("same-run declaration");
        let facts = crate::facts::RecoveryFacts::new(
            crate::facts::MethodFacts::new(name, descriptor, declaration.parameter_slots())
                .with_access_flags(declaration.access_flags()),
        );
        let mut recovery_budget = Budget::new(Limits {
                input_bytes: 1 << 20,
                archive_entries: 100,
                entry_bytes: 1 << 20,
                read_bytes: 1 << 20,
                class_bytes: 1 << 20,
                attribute_bytes: 1 << 20,
                code_bytes: 1 << 20,
                result_items: 1 << 20,
                output_bytes: 1 << 20,
                class_headers: 100,
                method_bodies: 100,
                ir_items: 1 << 20,
                ir_edges: 1 << 20,
                analysis_steps: 1 << 20,
                normalization_clones: 1 << 20,
                nested_depth: 32,
                dependency_depth: 32,
                elapsed_millis: u64::MAX,
            });
        let report = crate::report::recover(
            &crate::report::RecoveryRequest::new(ir, &facts, crate::pass::JAVA_8),
            &mut recovery_budget,
        );
        assert!(matches!(&report.execution, jarde_reader::model::ExecutionReport::Complete { .. }),
            "same-payload recovery report stopped: {:?}", report.execution);
        eprintln!("LBC-RECOVERY outcome={:?} fallbacks={:?} execution={:?} diagnostics={:#?}",
            report.outcome, report.fallbacks, report.execution, report.diagnostics);
        eprintln!("LBC-RECOVERY usage={:?}", recovery_budget.usage());

        // Full same-run SSA is intentional for foreach; it lets root trace the rejected local's
        // definitions, slot reads/writes and protected-range membership without another IR pass.
        eprintln!("LBC-SSA blocks={:#?}", ssa.blocks());
        eprintln!("LBC-SSA values={:#?}", ssa.values_with_ids().collect::<Vec<_>>());
        eprintln!("LBC-SSA phis={:#?}", ssa.phis());
        eprintln!("LBC-RUN-END class={owner} method={name} descriptor={descriptor}");
    }

    let dv = std::env::var("JARDE_LOOP_BODY_CATCH_DV_CLASS").expect("DV_CLASS env");
    let df = std::env::var("JARDE_LOOP_BODY_CATCH_DF_CLASS").expect("DF_CLASS env");
    one(&dv, "DV", "plainFor", "([I)I");
    one(&dv, "DV", "whileLoop", "([I)I");
    one(&dv, "DV", "forEach", "([I)I");
    one(&df, "DF", "loopCatch", "([I)I");
}
