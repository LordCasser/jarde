// jarde: presentation of `RetryFixture` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class RetryFixture extends java.lang.Object {
    int c;

    int caught;

    int breaks;

    final int failuresBeforeSuccess;

    final int errorOnCall;

    // jarde: field Signature projection refused for `eventsLjava/util/List;`: unsupported (field_generic_body_unproved): a same-class Fieldref names this field and descriptor; same-class uses at <init>(II)V@27, test()I@15, test()I@41, exc()V@11
    final java.util.List events;

    public RetryFixture(int failuresBeforeSuccess, int errorOnCall) {
        // @method <init>(II)V
        // @declaration a constructor of `RetryFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.c = 0;
        this.caught = 0;
        this.breaks = 0;
        this.events = new java.util.ArrayList();
        this.failuresBeforeSuccess = failuresBeforeSuccess;
        this.errorOnCall = errorOnCall;
        return;
    }

    public int test() {
        // jarde: not recovered: the recovery run for `test()I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method test()I
        // @declaration an instance method of `RetryFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 5 6 9 10 11 14 15 18 20 25 26 29 30 31 32 35 36 37 40 41 44 46 51 52 55 56 59 60 63 66 67 70 73 74
        // canonical block at BCI 0 on jsr path [] has more than one owner in the completed Region tree; the whole method is quoted
    }

    private void exc() throws java.lang.Exception {
        // @method exc()V
        // @declaration an instance method of `RetryFixture`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.c += 1;
        this.events.add((java.lang.Object) "call");
        if (this.c == this.errorOnCall) {
            throw new java.lang.AssertionError();
        } else if (this.c < this.failuresBeforeSuccess + 1) {
            throw new java.lang.Exception();
    } else {
            this.events.add((java.lang.Object) "success");
            return;
    }
    }
}
