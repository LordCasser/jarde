package defpackage;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: RetryFixture.jar:RetryFixture.class */
public class RetryFixture {
    final int failuresBeforeSuccess;
    final int errorOnCall;
    int c = 0;
    int caught = 0;
    int breaks = 0;
    final List<String> events = new ArrayList();

    public RetryFixture(int failuresBeforeSuccess, int errorOnCall) {
        this.failuresBeforeSuccess = failuresBeforeSuccess;
        this.errorOnCall = errorOnCall;
    }

    public int test() {
        while (true) {
            try {
                exc();
                this.breaks++;
                this.events.add("break");
                break;
            } catch (Exception e) {
                this.caught++;
                this.events.add("catch");
            }
        }
        if (this.c == 5) {
            System.out.println(this.c);
            return 0;
        }
        return 0;
    }

    private void exc() throws Exception {
        this.c++;
        this.events.add("call");
        if (this.c == this.errorOnCall) {
            throw new AssertionError();
        }
        if (this.c < this.failuresBeforeSuccess + 1) {
            throw new Exception();
        }
        this.events.add("success");
    }
}
