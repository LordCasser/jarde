from pathlib import Path
import json,hashlib
TMP=Path('/private/tmp');OUT=TMP/'jarde-loop-catch-retry-baseline-acceptance-root-v1';assert not OUT.exists();OUT.mkdir()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check_pin(ref):
 p=Path(ref['path']);assert p.is_file() and p.stat().st_size==ref['bytes'] and sha(p)==ref['sha256'];return p
rows=[]
for version in ('v2','v3'):
 base=TMP/('jarde-loop-catch-retry-baseline-root-'+version+'-v1');ep=base/'execution.json';d=json.loads(ep.read_text())
 assert d['status']=='observed' and d['source_tool_inputs_unchanged'] is True and d['source_tool_pins_before']==d['source_tool_pins_after']
 for pin in d['source_tool_pins_after']:check_pin(pin)
 assert len(d['commands'])==44 and d['actual_command_count']==44 and len(d['lanes'])==16
 streams=[]
 for i,c in enumerate(d['commands'],1):
  assert c['index']==i and c['guard_stop'] is None and c['state']=='observed'
  for ref in c['streams'].values():streams.append(check_pin(ref))
 assert set(streams)==set((base/'raw').glob('*.raw')) and len(set(streams))==88
 expected=[]
 for label,fail,error in [('empty',0,False),('one-failure',1,False),('upstream-two-failures',2,False),('three-failures',3,False),('uncaught-error',2,True)]:
  count=2 if error else fail+1;caught=1 if error else fail;events=[]
  for n in range(1,count+1):
   events.append('call:'+str(n) if version=='v2' else 'call')
   if error and n==2:break
   if n<=fail:events.append('catch:'+str(n) if version=='v2' else 'catch')
   else:events.extend(['success:'+str(n),'break:'+str(n)] if version=='v2' else ['success','break'])
  events.append(('throw:java.lang.AssertionError:uncaught-error:2' if version=='v2' else 'throw:java.lang.AssertionError') if error else 'return:0')
  expected.append(f'{label} calls={count} catches={caught} breaks={0 if error else 1} events=['+', '.join(events)+']')
 expected_bytes=('\n'.join(expected)+'\n').encode();assert len(expected)==5
 runtime_count=0;failcount=0;refusals=[]
 for lane in d['lanes']:
  family=lane['family'];mode=lane['mode'];jdk=lane['jdk'];run=lane if family=='original' else lane['compile_run'];assert run is not None
  for pin in run['classes']:check_pin(pin)
  if family=='jarde':
   assert lane['render_command']['exit_code']==0 and lane.get('parse_error') is None
   raw=check_pin(lane['raw_response']).read_bytes();assert raw==Path(lane['render_command']['streams']['stdout']['path']).read_bytes();jd=json.loads(raw)
   assert check_pin(lane['source']).read_bytes()==jd['text'].encode()
   method=next(m for m in lane['methods'] if bytes(m['identity']['name'])==b'test' and bytes(m['identity']['descriptor'])==b'()I')
   diag=[x for x in method['diagnostics'] if x['severity']!='info'];assert diag and diag[0]['code']=='jre_region_ownership_overlap' and 'BCI 0' in diag[0]['message']
   assert run['compile']['exit_code']==1 and run['run'] is None and lane['runtime_state']=='no-runtime';failcount+=1
   exc=next(m for m in lane['methods'] if bytes(m['identity']['name'])==b'exc')
   if version=='v3':assert not any(x['severity']!='info' for x in exc['diagnostics'])
   else:assert any(x['code']=='jre_new_shape' for x in exc['diagnostics'])
   refusals.append({'mode':mode,'jdk':jdk,'physical_identity':method['identity'],'first_refusal':diag[0]})
  else:
   assert run['compile']['exit_code']==0 and run['run']['exit_code']==0 and lane['runtime_state']=='ran'
   assert Path(run['run']['streams']['stdout']['path']).read_bytes()==expected_bytes;runtime_count+=1
   if family=='original':assert lane['oracle_byte_match'] is True
   else:
    assert lane['decompiler_command']['exit_code']==0 and lane['stdout_comparison']['byte_identical'] is True
    assert len(lane['sources'])==1 and lane['sources'][0]['class']=='RetryFixture'
  if family!='original':
   runner=check_pin(lane['derived_runner']).read_bytes();original_runner=check_pin(d['runner']).read_bytes()
   package='defpackage' if family=='jadx-default' else ''
   assert runner==(('package '+package+';\n').encode() if package else b'')+original_runner
 rows.append({'version':version,'execution_sha256':sha(ep),'commands':44,'raw_streams':88,'original_runtime_legs':4,'jadx_runtime_legs':8,'runtime_oracles_per_leg':5,'jarde_compile_fail_no_runtime':failcount,'refusals':refusals})
s={'status':'accepted_observations_only','implementation_accepted':False,'versions':rows,'total_commands':88,'raw_streams':176,'scope':'Whole classes unmodified; independent Runner package prefix only. Observed infinite retry/break gap remains and is not accepted as restored.'}
(OUT/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='versions'}))
