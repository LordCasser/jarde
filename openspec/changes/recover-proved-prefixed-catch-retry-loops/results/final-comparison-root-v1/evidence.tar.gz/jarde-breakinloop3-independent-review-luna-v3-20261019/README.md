# Loop3 final independent auditor (frozen v3)

This package freezes the final parameterized Loop3 raw-stream auditor. It independently reopens command stdout/stderr, source/class snapshots, API payloads and physical maps, raw CASE/CHECK observations, compiler outputs, runtime matrices, and wrong-CodeSource controls. Generated compile, runtime, and wrong-root counts derive from the closed receipt's actual runtime-eligible compiler records.

Replay only after the root closes a new collector receipt:

```sh
python3 -B /private/tmp/jarde-breakinloop3-independent-review-luna-v3-20261019/audit.py \
  --receipt /absolute/path/to/closed/execution.json \
  --cli /absolute/path/to/candidate-cli \
  --cli-sha256 ACTUAL_CLI_SHA256 \
  --out /private/tmp/new-empty-loop3-audit-output
```

The audit does not run compilers, JVMs, Jarde, or JADX. The output directory must be new or empty.

## Package history

The v2 package was first reported sealed with auditor SHA256 `bfc2aa8aa85f70d076d37e70b28f252adc4f8003b2638aaace8d548ccbbb6c74`, then its auditor was modified before this v3 freeze; its later byte state was SHA256 `dd9f1f78d3a2d9768cfdb68dc30cfb3f98288c6af5f69b063db23f97215d3c31`. The v2 package is retained as-is and must not be used as the frozen final package. This v3 package contains that later auditor byte state.
