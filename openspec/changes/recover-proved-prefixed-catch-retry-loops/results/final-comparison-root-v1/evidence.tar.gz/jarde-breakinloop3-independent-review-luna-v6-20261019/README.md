# Loop3 final independent auditor v6

This adapter retains the exact BCI 88 mapping-debt assertion (eight `writeMore` cells; 48/49 physical BCIs mapped) and all other gates. It now compares independently parsed CASE/CHECK observations against the fields present in each receipt row, allowing collector-owned supplemental fields (`raw`, builder snapshots, CHECK facts, and row count) to coexist without requiring the parser's normalized projection to equal the larger collector record byte-for-byte. Each parsed field must still equal the recorded value.

The preceding v5 run found a receipt-shape mismatch: original/runtime rows include collector supplements, while the independent parser emits normalized raw-protocol fields. No data is discarded from the audit report.

Replay:

```sh
python3 -B /private/tmp/jarde-breakinloop3-independent-review-luna-v6-20261019/audit.py \
  --receipt /private/tmp/jarde-last-four-final-loop3-root-v1-20261019/execution.json \
  --cli /private/tmp/jarde-last-four-final-static-build-root-v2-20261019/candidate-cli \
  --cli-sha256 ed74e005c1bc97bcdf4a15f6a27da9e9d8a1ecdf7fe576836820ed2ce323222d \
  --out /private/tmp/jarde-last-four-loop3-independent-audit-luna-v6-20261019
```
