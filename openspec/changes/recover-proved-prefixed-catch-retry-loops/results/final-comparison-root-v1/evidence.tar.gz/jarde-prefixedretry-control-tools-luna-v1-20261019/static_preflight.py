#!/usr/bin/env python3
"""Static preflight for the standalone Loop3 retry control collector."""
from __future__ import annotations
import ast, base64, hashlib, importlib.util, json, re
from pathlib import Path
HERE=Path(__file__).resolve().parent
def need(ok,msg):
    if not ok: raise SystemExit(msg)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
source=HERE/'source/PrefixedRetryControl.java'; driver=HERE/'driver/PrefixedRetryControlDriver.java'
planp=HERE/'caseplans.json'; plan=json.loads(planp.read_text(encoding='utf-8'))
collector=HERE/'collect_control.py'; audit=HERE/'audit_control.py'
for path in (collector,audit,Path(__file__)):
    ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
need(plan.get('schema')=='prefixed-catch-retry-full-source-caseplan-v1','caseplan schema mismatch')
need(plan['source']['path']==str(source) and plan['source']['copy']==str(source),'case source identity mismatch')
need(plan['source']['bytes']==source.stat().st_size and plan['source']['sha256']==sha(source),'control source pin mismatch')
cs=collector.read_text(encoding='utf-8')
need(f"SOURCE_SHA256 = '{sha(source)}'" in cs and f"DRIVER_SHA256 = '{sha(driver)}'" in cs and f"CASE_PLAN_SHA256 = '{sha(planp)}'" in cs,'collector source/driver/caseplan pin constants differ')
tools=json.loads((HERE/'tool-pins.json').read_text(encoding='utf-8'))
for row in tools['inputs']:
    q=Path(row['path'])
    need(q.is_file() and q.stat().st_size==row['bytes'] and sha(q)==row['sha256'],f"external tool/source pin mismatch: {q}")
need(len(plan['cases'])==10,'expected ten bounded control cases')
need([c['id'] for c in plan['cases']]==['normal-success','retry-then-success','second-failure-left','second-failure-right','prefix-throws','retry-step-throws','left-step-throws','right-step-throws','join-step-throws','tail-step-throws'],'finite case order mismatch')
need('public void run()' in source.read_text() and 'while (true)' in source.read_text(),'control while/retry shape missing')
need(all(x not in source.read_text() for x in ('java.io.','java.nio.file','File.exists','Files.','check()')),'control must remain no-file and check-free')
need('URLClassLoader(urls,null)' in driver.read_text().replace(' ',''),'parentless class loader contract missing')
need('wrong CodeSource:' in driver.read_text() and 'exception_stack_b64=' in driver.read_text(),'CodeSource or full exception observation missing')
need('Class.forName(TARGET,true,loader)' in driver.read_text(),'eager target load/verification missing')
spec=importlib.util.spec_from_file_location('static_control_collector',collector)
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
need(module.CASE_NAMES==tuple(c['id'] for c in plan['cases']),'collector and caseplan case inventory differ')
# Exercise only the collector's Python parser with a synthetic protocol payload; no JVM runs.
rows=[]
for i,c in enumerate(plan['cases']):
    e=c['expected']; enc=lambda v:base64.b64encode(v.encode()).decode()
    rows.append(f"CASE index={i} name={c['id']} input_b64={enc(c['input'])} result_b64={enc(e['result'])} exception={e['exception_type']} exception_message_b64={enc(e['exception_message'])} exception_stack_b64={enc('synthetic stack only')} stdout_b64={enc(e['stdout'])} after_b64={enc(e['after'])}")
parsed=module.parse_oracle(('\n'.join(rows)+'\n').encode())
need(len(parsed)==10 and not module.validate_case_oracle(parsed,plan['cases']),'synthetic record/parser compatibility failed')
need('TestBreakInLoop3' not in str(plan['target']),'standalone control was confused with original TestBreakInLoop3')
print(json.dumps({'status':'static_preflight_pass','cases':len(plan['cases']),'collector_ast':'ok','auditor_ast':'ok','synthetic_parser':'ok','toolchains_executed':False},indent=2))
