#!/usr/bin/env python3
"""Independent read-only audit for a closed PrefixedRetryControl receipt."""
from __future__ import annotations
import argparse, hashlib, json
from collections import Counter
from pathlib import Path

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def pin_ok(row):
    p=Path(row['path'])
    return p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
def projection(rows):
    fields=('index','name','input','result','exception_type','exception_message','target_stdout','after')
    return [{k:r[k] for k in fields} for r in rows]
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--receipt',required=True,type=Path)
    ap.add_argument('--out',required=True,type=Path)
    a=ap.parse_args()
    if a.out.exists(): raise SystemExit(f'refusing existing audit output: {a.out}')
    x=json.loads(a.receipt.read_text(encoding='utf-8'))
    errs=[]; observations=[]
    need(x.get('schema')=='prefixed-catch-retry-control-full-source-v1','wrong receipt schema')
    collector_pins=x.get('external_input_pins_before',{}).get('files',[])
    collector_pin=next((r for r in collector_pins if Path(r.get('path','')).name=='collect_control.py'),None)
    collector_copy=a.receipt.parent/'collector.py'
    if not collector_pin or not pin_ok(collector_pin): errs.append('collector source pin missing/changed in receipt')
    elif not collector_copy.is_file() or collector_copy.is_symlink() or collector_copy.stat().st_size!=collector_pin['bytes'] or sha(collector_copy)!=collector_pin['sha256']:
        errs.append('captured collector.py does not match the collector source pin')
    commands=x.get('commands',[])
    if [c.get('index') for c in commands] != list(range(1,len(commands)+1)): errs.append('command indices are not contiguous')
    raw_paths=[]
    for c in commands:
        streams=c.get('streams',{})
        for channel in ('stdout','stderr'):
            row=streams.get(channel)
            if not isinstance(row,dict): errs.append(f"command {c.get('index')} lacks {channel} raw stream"); continue
            if not pin_ok(row): errs.append(f"command {c.get('index')} {channel} raw stream pin mismatch")
            p=Path(row['path']); raw_paths.append(str(p.resolve()) if p.exists() else str(p))
            if p.parent.name!='raw': errs.append(f"command {c.get('index')} {channel} stream is outside raw directory")
    if len(raw_paths)!=len(set(raw_paths)): errs.append('raw stdout/stderr paths are reused')
    if len(raw_paths)!=2*len(commands): errs.append('not exactly two independent raw streams per command')
    for key in ('source','case_plan','source_copy','driver_source','driver_copy','runtime_wrapper','cli','jadx','jadx_jar','compare','guard','scanner','physical_parser'):
        row=x.get(key)
        if key in ('source','case_plan','source_copy','driver_source','driver_copy','runtime_wrapper','cli','jadx','jadx_jar','compare','guard','scanner','physical_parser') and (not isinstance(row,dict) or not pin_ok(row)):
            errs.append(f'{key} input pin missing or changed')
    if x.get('dependency_classpath')!=[] or x.get('dependency_urls')!=[]: errs.append('control acquired unexpected dependency URLs')
    if x.get('check_method_required') is not False or x.get('filesystem_side_effects_allowed') is not False: errs.append('control scope flags drifted')
    originals=x.get('original_runtime',[])
    if len(originals)!=4: observations.append(f'original_runtime_cells={len(originals)}; expected complete matrix has 4')
    orig_by={(r.get('profile'),r.get('runtime')):r for r in originals}
    if set(orig_by)!={(p,r) for p in ('debug','no-debug') for r in ('javac8','javac23')}: observations.append('original runtime profile/runtime matrix incomplete')
    for r in originals:
        rows=r.get('rows',[])
        if r.get('exit_code')==0 and ([z.get('name') for z in rows]!=list(x.get('runtime_case_names',[])) or len(rows)!=10): errs.append(f"original {r.get('profile')}/{r.get('runtime')} CASE inventory mismatch")
    if originals and all(r.get('rows') for r in originals):
        projections=[projection(r['rows']) for r in originals]
        observations.append({'original_runtime_projection_count':len(projections),'cross_profile_runtime_equal':all(v==projections[0] for v in projections)})
    if len(x.get('source_profiles',[]))!=2: observations.append('JDK23 original source profile matrix incomplete')
    if len(x.get('javac8_source_profiles',[]))!=2: observations.append('JDK8 original source profile matrix incomplete')
    eight_rows=x.get('javac8_original_runtime',[])
    expected_eight={(p,r) for p in ('debug','no-debug') for r in ('javac8','javac23')
                    if next((c.get('exit_code')==0 for c in x.get('javac8_source_profiles',[]) if c.get('profile')==p),False)}
    got_eight={(r.get('profile'),r.get('runtime')) for r in eight_rows}
    if got_eight!=expected_eight: observations.append(f'JDK8-compiled original runtime matrix incomplete: {len(got_eight)}/{len(expected_eight)}')
    for r in eight_rows:
        baseline=orig_by.get((r.get('profile'),r.get('runtime')))
        if r.get('exit_code')==0 and (not r.get('rows') or baseline is None or projection(r['rows'])!=projection(baseline.get('rows',[]))):
            errs.append(f"JDK8-compiled original differs from same-VM original oracle: {r.get('profile')}/{r.get('runtime')}")
    api=x.get('jarde_cells',[])
    api_keys={(r.get('profile'),r.get('api_class'),r.get('input_form'),r.get('evidence')) for r in api}
    expected={(p,'PrefixedRetryControl',f,e) for p in ('debug','no-debug') for f in ('child','bundle-child') for e in ('default','all')}
    if len(api)!=8 or api_keys!=expected: observations.append(f'Jarde API matrix incomplete: {len(api)}/8 cells')
    if len(x.get('jadx_outputs',[]))!=2: observations.append('JADX full-source profile matrix incomplete')
    for c in api:
        rp=c.get('report')
        if isinstance(rp,dict) and not pin_ok(rp): errs.append(f"Jarde report raw copy changed for {c.get('profile')}/{c.get('input_form')}/{c.get('evidence')}")
        for m in c.get('methods',[]):
            if m.get('map_audit',{}).get('issues'): errs.append(f"method source-map audit issues: {c.get('profile')}/{m.get('name')}")
        if c.get('method_inventory_matches') is False: errs.append('Jarde API method inventory differs from physical class')
    generated=x.get('generated_runtime',[])
    for g in generated:
        if g.get('exit_code')==0 and g.get('matches_original_oracle') is not True: errs.append(f"successful generated VM does not match original: {g.get('kind')}/{g.get('profile')}/{g.get('compiler')}/{g.get('runtime')}")
        key=(g.get('profile'),g.get('runtime')); base=orig_by.get(key)
        if g.get('exit_code')==0 and (base is None or projection(g.get('rows',[]))!=projection(base.get('rows',[]))): errs.append('generated observation differs from same-profile/runtime original oracle')
    wrong=[*x.get('generated_wrong_root_controls',[])]
    if x.get('wrong_root_control'): wrong.append(x['wrong_root_control'])
    for row in wrong:
        if row.get('rejected') is not True: errs.append('wrong-root control did not prove CodeSource rejection')
    for row in x.get('generated_source_compilations',[]):
        if row.get('exit_code')==0 and not row.get('runtime_eligible'): errs.append('successful generated compile failed physical class inventory gate')
    if x.get('target_absent_finally') is not True: errs.append('workspace target directory was not absent after collection')
    if x.get('external_inputs_unchanged') is False or x.get('source_unchanged') is False: errs.append('workspace/tool source drifted during collection')
    receipt_status=x.get('status')
    # A failed collector remains failed even if all retained records are structurally auditable.
    result={'schema':'prefixed-catch-retry-control-independent-audit-v1','receipt':str(a.receipt.resolve()),
            'receipt_status':receipt_status,'status':'audit_pass' if not errs and receipt_status=='captured-pending-independent-review' else ('audit_failed' if errs else 'receipt_incomplete'),
            'command_count':len(commands),'raw_stream_count':len(raw_paths),'original_runtime_count':len(originals),
            'jarde_api_cell_count':len(api),'jadx_output_count':len(x.get('jadx_outputs',[])),
            'generated_compile_count':len(x.get('generated_source_compilations',[])),'generated_runtime_count':len(generated),
            'wrong_root_count':len(wrong),'static_hypothesis_mismatch_cells':[r.get('profile')+'/'+r.get('runtime') for r in originals if r.get('manual_oracle_matches') is False],
            'observations':observations,'errors':errs}
    a.out.parent.mkdir(parents=True,exist_ok=True); a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'receipt_status':receipt_status,'errors':len(errs),'out':str(a.out)}))
    return 0 if result['status']=='audit_pass' else 1
if __name__=='__main__': raise SystemExit(main())
