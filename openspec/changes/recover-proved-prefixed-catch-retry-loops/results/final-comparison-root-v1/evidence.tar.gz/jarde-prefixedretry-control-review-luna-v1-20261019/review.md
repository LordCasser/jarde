# PrefixedRetryControl collector independent static review

Scope: read-only review of the collector, standalone source/driver/case plan and command plan. No JDK, Jarde, JADX, or other toolchain was run. The control is explicitly supplemental and does not replace the original TestBreakInLoop3 source/runtime baseline.

## Blocking defect before execution

`full_class_facts()` calls the pinned `compare.parse_class()`, whose `fields` are tuples `(name, descriptor, access)` (compare.py lines 184–208). It leaves those tuples in `facts['fields']`. `validate_control_inventory()` then indexes each row as a mapping at collector line 118 (`f['name']`, `f['descriptor']`, `f['access']`). The first successful standalone javac8 debug compilation reaches this path and raises `TypeError`; the JDK8 no-debug and JDK23 profile paths use it too. Since this default-package source has no framework dependencies and is intended to compile under both JDKs, this is a deterministic pre-execution blocker. Make the inventory adapter accept the parser's tuple shape, consistently with `inventory_metadata_differences()` which already handles tuple-or-dict fields. The existing static preflight does not call `validate_control_inventory`, so its synthetic CASE check will not catch this.

## Bounded matrix and isolation review

No other deterministic matrix, source-copy, or argv defect was found in the inspected collector/driver/plan:

- The standalone target is intentionally default-package `PrefixedRetryControl`; its physical class tree should be exactly `PrefixedRetryControl.class`. `class_tree()` and generated-compile checks enforce that one-class closure. Source copying handles absent package declarations.
- The target inventory is four methods (`<init>`, `step`, `attempt`, `run`) and six public fields (`attemptCalls`, `exists`, `failuresRemaining`, `stepCalls`, `throwAt`, `trace`). No `check()` exists or is required for this separate no-framework control; `check_method_required` is false. The ten CASE rows carry exact exception messages and stack text, stdout, trace, counters, and input. The original compiled control is the runtime oracle; plan values are hypotheses.
- The compile matrix attempts JDK8 debug (also the explicit boundary row), JDK8 no-debug, and JDK23 debug/no-debug. The JDK23 classes run on both runtimes (four original VM runs); successful JDK8 classes also run on both runtimes (four additional rows). The Jarde matrix is 2 profiles × class/JAR × default/all = 8 calls. JADX emits one full bundled outer/target tree per Java23 profile. The collector creates eight Jarde source cells plus two JADX source cells and attempts both compilers for every available cell (up to 20 compile attempts); every eligible generated class is run on both VMs, without source-cell deduplication.
- Driver application `-cp` is exactly the driver class directory. The parentless `URLClassLoader(urls, null)` receives the target root first and any configured dependency URLs after it; for this dependency-free source the dependency list is empty. `CodeSource` must equal the resolved target root. The deliberate wrong-root run passes the actual target root but expects the empty-classpath directory, so it should fail with `wrong CodeSource:`. The runtime wrapper supplies an empty isolated cwd, which the driver checks before and after each CASE.
- The prepared source and case-plan copy are byte/SHA compared; the collector then copies the pinned source into each fresh output. The target uses neither external libraries nor filesystem APIs, so the empty compile classpath and empty runtime dependency URLs are appropriate.

The original Loop3 receipt used for contract comparison is the closed root baseline at `/private/tmp/jarde-breakinloop3-baseline-root-v1-20261019/execution.json`; its JDK8 full-source compilation failed on framework bytecode versions, while the standalone control deliberately has no such dependency. Do not treat this control's success as resolving the original source gap.

## Runtime acceptance handoff

The collector records, but does not itself fail on, a JDK8-compiled observation that exits nonzero or disagrees with the JDK23-compiled oracle (`javac8_original_runtime[].matches_javac23_compiled_oracle`). The assigned strong independent audit should require the expected original-runtime cells and exact projection agreement whenever the corresponding source profile compiled successfully. This is an audit gate, not a second collector defect, because the collector preserves those failures as raw observations and the audit is the stated acceptance stage.

No acceptance result is claimed. This package contains review evidence only.
