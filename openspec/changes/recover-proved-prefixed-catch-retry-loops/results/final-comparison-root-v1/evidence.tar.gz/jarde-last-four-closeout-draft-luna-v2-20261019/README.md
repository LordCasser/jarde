# Final source-map audit adapter v2 (private, prepared only)

This package accepts each closed `execution.json` as `--receipt LABEL=PATH`, recomputes class-file instruction BCIs from pinned class/JAR inputs, maps BCI origins from every Jarde API cell, and checks within-receipt map stability. It does not use a receipt's reported map counts as proof. Optional `--expected-json` supplies exact per-method expected physical/mapped/missing counts.

The reusable bytecode parser is copied unchanged from the closed v1 package as `audit_mappings_v1_frozen.py`. V2 does not read any new B receipt or Do2 receipt and is not an audit result. Use only after the corresponding receipts are declared closed.

Example after closure:

```sh
python3 -B audit_mappings.py \
  --receipt B=/closed/B/execution.json \
  --receipt Do2=/closed/Do2/execution.json \
  --out /private/tmp/.../review.json
```

All output remains private. Do not bind historical v1 receipts to a current product result.
