#!/usr/bin/env python3
"""Static, no-toolchain preflight for the extended DoWhileBreak2 controls."""
from pathlib import Path
import ast, hashlib, importlib.util, json, re
BASE=Path(__file__).parent
SOURCE=Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestDoWhileBreak2.java')
SOURCE_SHA='8b936f2645d158c4ddc8c19e3790045fe3bfd26fe49ef54c3141df41fd433666'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,msg):
    if not ok: raise SystemExit(msg)
plan=json.loads((BASE/'caseplans.json').read_text())
need(sha(SOURCE)==SOURCE_SHA and SOURCE.stat().st_size==1078,'upstream source pin changed')
for rel in ('source/jadx/tests/integration/loops/TestDoWhileBreak2.java','source-plan-copy/TestDoWhileBreak2.java'):
    need((BASE/rel).read_bytes()==SOURCE.read_bytes(),'complete copied source differs')
need(plan['schema']=='test-do-while-break2-extended-control-caseplan-v1','case plan schema differs')
need(Path(plan['source']['copy']).read_bytes()==SOURCE.read_bytes() and plan['source']['sha256']==SOURCE_SHA,'plan source copy binding differs')
need(len(plan['cases'])==11 and [x['id'] for x in plan['cases']]==['two-elements','null-terminated','null-first-tail','single-nonnull','empty','null-iterator','next-throws-first','next-throws-second','hasnext-throws-first','hasnext-throws-second','wrong-type-cast'],'case order/count differs')
source=SOURCE.read_text()
need('public Object test()' in source and 'public void check()' in source and 'Iterator<String> it;' in source,'complete target/check declaration missing')
need('assertThat(test()).isEqualTo("b")' in source and 'assertThat(test()).isEqualTo(null)' in source,'original check assertions missing')
for fn in ('collect_control.py','audit_control.py'):
    ast.parse((BASE/fn).read_text(),filename=fn)
driver=(BASE/'driver/TestDoWhileBreak2Driver.java').read_text()
need('new URLClassLoader(urls, null)' in driver and 'wrong CodeSource:' in driver and 'exception_stack_b64=' in driver and 'Iterator<Object>' in driver,'isolated raw-iterator trace driver contract missing')
need('new URL[args.length - 2]' in driver,'driver URL list must contain target root plus exactly supplied dependency URLs')
col=(BASE/'collect_control.py').read_text(); audit=(BASE/'audit_control.py').read_text()
need(re.search(r"CASE_PLAN_SHA256 = '([0-9a-f]+)'",col).group(1)==sha(BASE/'caseplans.json'),'collector caseplan pin differs')
need(re.search(r"DRIVER_SHA256 = '([0-9a-f]+)'",col).group(1)==sha(BASE/'driver/TestDoWhileBreak2Driver.java'),'collector driver pin differs')
need(re.search(r"CASE_PLAN_SHA='([0-9a-f]+)'",audit).group(1)==sha(BASE/'caseplans.json') and re.search(r"DRIVER_SHA='([0-9a-f]+)'",audit).group(1)==sha(BASE/'driver/TestDoWhileBreak2Driver.java') and re.search(r"COLLECTOR_SHA='([0-9a-f]+)'",audit).group(1)==sha(BASE/'collect_control.py'),'auditor source pins differ')
spec=importlib.util.spec_from_file_location('collector_preflight',BASE/'collect_control.py'); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
planned=plan['cases']; synthetic=[]
for i,c in enumerate(planned):
    e=c['expected']; synthetic.append({'index':i,'name':c['id'],'input':c['input'],'result':'return='+e['return'],'exception_type':e['exception_type'],'exception_message':'','target_stdout':e['stdout'],'after':e['after']})
need(mod.validate_case_oracle(synthetic,planned)==[],'synthetic expected-case adapter check failed')
import base64
def enc(s): return base64.b64encode(s.encode()).decode()
lines=[]
for i,c in enumerate(planned):
    e=c['expected']
    lines.append('CASE index=%d name=%s input_b64=%s result_b64=%s exception=%s exception_message_b64= exception_stack_b64= target_stdout_b64= after_b64=%s' % (i,c['id'],enc(c['input']),enc('return='+e['return']),e['exception_type'],enc(e['after'])))
lines.append('CHECK result=pass exception=none stdout_b64= exception_message_b64=')
parsed=mod.parse_oracle(('\n'.join(lines)+'\n').encode())
need([x['name'] for x in parsed]==[x['id'] for x in planned],'synthetic protocol parse/order test failed')
print('STATIC_PREFLIGHT_READY: Python syntax, fixed source-copy pins, case protocol, and synthetic adapter only; no toolchain executed')
