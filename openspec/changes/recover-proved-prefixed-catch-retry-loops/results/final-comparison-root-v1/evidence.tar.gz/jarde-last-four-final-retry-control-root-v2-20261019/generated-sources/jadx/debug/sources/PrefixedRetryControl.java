// default package

/* JADX INFO: loaded from: debug-full-classes.jar:PrefixedRetryControl.class */
public final class PrefixedRetryControl {
    public boolean exists;
    public int failuresRemaining;
    public String throwAt;
    public final StringBuilder trace = new StringBuilder();
    public int attemptCalls;
    public int stepCalls;

    private void step(String tag) {
        if (this.trace.length() != 0) {
            this.trace.append('|');
        }
        this.trace.append(tag);
        this.stepCalls++;
        if (tag.equals(this.throwAt)) {
            throw new IllegalStateException("step." + tag);
        }
    }

    private void attempt() {
        this.attemptCalls++;
        if (this.trace.length() != 0) {
            this.trace.append('|');
        }
        this.trace.append("attempt#").append(this.attemptCalls);
        if (this.failuresRemaining > 0) {
            this.failuresRemaining--;
            throw new IllegalStateException("attempt." + this.attemptCalls);
        }
    }

    public void run() {
        boolean tryMkdir = true;
        while (true) {
            step("prefix");
            try {
                attempt();
                break;
            } catch (Exception e) {
                if (tryMkdir) {
                    tryMkdir = false;
                    step("retry");
                } else {
                    step("caught");
                    if (this.exists) {
                        step("left");
                    } else {
                        step("right");
                    }
                    step("join");
                    break;
                }
            }
        }
        step("after");
        step("tail");
    }
}
