# Prefixed retry control: executable baseline and independent audit

This is a bounded supplemental control for catch/retry ordering. `PrefixedRetryControl.java` is a separate no-file class; it is not `TestBreakInLoop3` and does not exercise the original `File.exists()` branch. The original TestBreakInLoop3 full-source baseline remains the product behavior oracle for that real gap.

The control has ten finite cases: success, one retry then success, the second failure through each branch, and throws at prefix/retry/left/right/join/tail. The class has public configuration/state fields, a public no-argument constructor, two private helpers, and `public run()`. The isolated driver emits one row per case with return/exception type/message/stack, stdout, ordered trace, and state. Explicit `IllegalStateException` messages are compared exactly; stack text and all raw streams are retained.

`collect_control.py` adapts the closed DoWhileBreak2 collector while removing its framework dependency assumptions. The JVM application classpath contains driver classes only. Each run creates a fresh parentless URLClassLoader with only the selected target root, verifies the loaded CodeSource, and runs in an empty isolated directory. The wrong-root control expects the empty directory and must fail with a CodeSource mismatch.

The collector compiles original source with JDK 8 and 23 in debug/no-debug profiles, observes both original runtime VMs, sends 8 class/JAR × default/all Jarde API requests from both Java 23 compiler profiles, decodes one complete JADX source per profile, recompiles every available generated source with both compilers, and runs every eligible generated class on both VMs. Command streams are captured separately and retained even when a command fails. No failure is relabeled as success.

Run only after root selects the final CLI and SHA and reviews the command plan:

```sh
python3 -B static_preflight.py
python3 -B collect_control.py --out /private/tmp/<fresh-output> --cli /private/tmp/<selected-cli> --cli-sha256 <64-hex-sha>
python3 -B audit_control.py --receipt /private/tmp/<fresh-output>/execution.json --out /private/tmp/<fresh-audit.json>
```

The static preflight exercises the collector's Python CASE parser using synthetic text; it does not launch Java or Jarde. The independent auditor reads the closed execution receipt and verifies stream hashes, API/source inventories, maps, runtime matches and CodeSource controls. Its `audit_pass` also requires the collector receipt to have closed successfully; partial receipts remain `receipt_incomplete` or `audit_failed` with raw evidence preserved.


## JADX package identity

The full-source JADX command now includes `--rename-flags none`. The closed package probe showed this preserves the valid default package (represented as `//defaultpackage`) and prevents JADX from moving `PrefixedRetryControl` into `defpackage`, which had made otherwise successful generated classes ineligible for the exact target identity. The complete source tree and runtime driver are unchanged. Acceptance requires all 20 generated compilations to succeed and be eligible, all 40 dual-runtime observations, and all 20 wrong-CodeSource controls.
