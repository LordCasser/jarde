from pathlib import Path
import json,subprocess,hashlib,sys
root=Path('/Users/lordcasser/workspace/projects/jarde');out=Path(sys.argv[1]);assert not out.exists();out.mkdir();rows=[]
def run(argv,cwd=root,ok=0):
 r=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE);i=len(rows)+1;streams={}
 for label,b in [('stdout',r.stdout),('stderr',r.stderr)]:
  p=out/f'{i}.{label}.raw';p.write_bytes(b);streams[label]={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 rows.append({'argv':argv,'cwd':str(cwd),'exit_code':r.returncode,'streams':streams});assert r.returncode==ok,(argv,r.returncode,r.stderr);return r.stdout
head=run(['git','rev-parse','HEAD']).decode().strip();origin=run(['git','rev-parse','origin/main']).decode().strip();remote=run(['git','ls-remote','--heads','origin','main']).decode().split()[0];assert head==origin==remote
assert run(['git','branch','--show-current']).strip()==b'main';assert run(['git','for-each-ref','--format=%(refname:short)','refs/heads']).splitlines()==[b'main']
assert not run(['git','status','--porcelain=v1','--untracked-files=all'])
raw=run(['git','worktree','list','--porcelain','-z']);worktrees=[]
for entry in raw.split(b'\0\0'):
 if not entry:continue
 fields={}
 for line in entry.split(b'\0'):
  if line:
   k,_,v=line.decode().partition(' ');fields[k]=v
 path=Path(fields['worktree']);assert path.is_dir();assert not run(['git','status','--porcelain=v1','--untracked-files=all'],path);assert not(path/'target').exists() and not(path/'target').is_symlink()
 if path.resolve()!=root.resolve():
  assert 'detached' in fields and 'branch' not in fields;run(['git','merge-base','--is-ancestor',fields['HEAD'],head])
 else:assert fields.get('branch')=='refs/heads/main'
 worktrees.append(fields)
binding=json.loads(Path(sys.argv[2]).read_bytes());assert binding['product_revision']=='8ea98e2e11d64f02092ac200d2b596511dcf5e40'
tree={}
for row in run(['git','ls-tree','-rz','--full-tree',head]).split(b'\0'):
 if row:
  meta,name=row.split(b'\t',1);tree[name.decode()]=meta.split()
for b in binding['bindings']:
 p=root/b['path'];assert p.is_file() and not p.is_symlink();data=p.read_bytes();assert len(data)==b['bytes'] and hashlib.sha256(data).hexdigest()==b['sha256'];mode='100755' if p.stat().st_mode&0o111 else '100644';assert mode==b['mode'];assert tree[b['path']]==[mode.encode(),b'blob',b['git_blob'].encode()]
record={'status':'passed','head':head,'origin_main':origin,'github_main':remote,'branch':'main','only_main_branch':True,'clean':True,'worktree_count':len(worktrees),'worktrees':worktrees,'all_worktree_targets_absent':True,'product_revision':binding['product_revision'],'live_and_final_git_source_bindings':len(binding['bindings']),'commands':rows}
(out/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['commands','worktrees']}))
