import json,hashlib,collections,sys
from pathlib import Path
base=Path('/private/tmp');out=Path(sys.argv[1]);assert not out.exists();out.mkdir()
def pin(p):
 p=Path(p).resolve(strict=True);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
seen={}
def reopen(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys() and isinstance(v['bytes'],int):
   key=(v['path'],v['sha256']);got=pin(v['path']);assert all(got[k]==v[k] for k in ['bytes','sha256']),(v,got);seen[key]=got
  else:
   for x in v.values():reopen(x)
 elif isinstance(v,list):
  for x in v:reopen(x)
plans=[('do2',2,base/'jarde-last-four-final-do2-review-root-v1-20261019',70,10,20,11),('loop3',1,base/'jarde-last-four-final-loop3-review-root-v3-20261019/review.json',94,18,36,1),('do3',1,base/'jarde-last-four-final-do3-review-root-v1-20261019/review.json',94,18,36,10),('retry-control',2,base/'jarde-last-four-final-retry-control-review-root-v3-20261019.json',105,20,40,10)]
rows=[]
for name,version,review,cmdcount,compileok,vmcount,cases in plans:
 receipt=base/f'jarde-last-four-final-{name}-root-v{version}-20261019/execution.json';d=json.loads(receipt.read_bytes());a=json.loads(review.read_bytes());assert d['status']=='captured-pending-independent-review'
 assert a['status'] in ['passed','accepted_with_mapping_debt','independent-read-only-review']
 assert d['candidate_cli_sha256_expected']=='ed74e005c1bc97bcdf4a15f6a27da9e9d8a1ecdf7fe576836820ed2ce323222d'
 assert len(d['jarde_cells'])==8 and len(d['runtime_case_names'])==cases
 assert len(d['commands'])==cmdcount,(name,len(d['commands']),cmdcount)
 assert [c['index'] for c in d['commands']]==list(range(1,cmdcount+1))
 assert all(not m['fallbacks'] and m['quality']=='structured' and not m['map_audit']['issues'] for c in d['jarde_cells'] for m in c['methods'])
 assert sum(x['exit_code']==0 for x in d['generated_source_compilations'])==compileok
 assert len(d['generated_runtime'])==vmcount and all(x['exit_code']==0 and x['matches_original_oracle'] for x in d['generated_runtime'])
 assert d['source_unchanged_finally'] and d['target_absent_finally'] and d['local_copies_unchanged_finally']
 reopen(d);reopen(a);rows.append({'name':name,'receipt':pin(receipt),'review':pin(review),'commands':cmdcount,'raw_streams':cmdcount*2,'source_cases_per_vm':cases,'generated_compile_successes':compileok,'generated_vm_runs':vmcount,'generated_case_observations':vmcount*cases,'compile_counts':[{'kind':k[0],'compiler':k[1],'exit_code':k[2],'count':v} for k,v in sorted(collections.Counter((x['kind'],x['compiler'],x['exit_code']) for x in d['generated_source_compilations']).items())]})
result={'status':'accepted_with_disclosed_mapping_debts','product_revision':'8ea98e2e11d64f02092ac200d2b596511dcf5e40','cli_sha256':'ed74e005c1bc97bcdf4a15f6a27da9e9d8a1ecdf7fe576836820ed2ce323222d','matrices':rows,'reopened_unique_path_and_sha':len(seen),'mapping_debts':[{'method':'original Loop3.writeMore','mapped':48,'physical':49,'missing':[88]},{'method':'PrefixedRetryControl.run','mapped':40,'physical':41,'missing':[71]}],'boundaries':['Original Smali/Dex Loop6 remains unsupported input, actual JADX source success is distinct from JUnit enablement; no JVM oracle or Java substitution for that original.','Do2 JDK8 full generated sources fail only on the retained framework major55/52 boundary; actual check matched same runtime including this boundary.','Do3 has no target check method; no external JUnit text assertion execution claim.','Loop3 original empty-path runs do not cover File.exists true; separate finite control covers both normal completion arms without filesystem effects.','NPE/CCE diagnostic rendering and stacks preserved raw; source semantics and explicit injected exception messages compared exactly.'],'scope':'Structural/compile/bounded execution acceptance only; full native/own CI and final source binding are separate.'}
(out/'acceptance.json').write_text(json.dumps(result,indent=2)+'\n');(out/'reopened-pins.json').write_text(json.dumps(list(seen.values()),indent=2)+'\n');print(json.dumps({'status':result['status'],'matrices':[(r['name'],r['commands'],r['generated_vm_runs']) for r in rows],'pins':len(seen)}))
