import subprocess,json,sys,hashlib
from pathlib import Path
argv=json.loads(Path(sys.argv[1]).read_bytes());out=Path(sys.argv[2]);assert not out.exists();out.mkdir(parents=True)
def pin(p):
 b=p.read_bytes();return {"path":str(p.resolve()),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
with (out/"stdout.raw").open("xb") as a,(out/"stderr.raw").open("xb") as b:r=subprocess.run(argv,cwd="/Users/lordcasser/workspace/projects/jarde",stdout=a,stderr=b)
rec={"status":"closed","argv":argv,"exit_code":r.returncode,"streams":{k:pin(out/(k+".raw")) for k in ["stdout","stderr"]}}
(out/"execution.json").write_text(json.dumps(rec,indent=2)+"\n");print(json.dumps(rec));raise SystemExit(r.returncode)
