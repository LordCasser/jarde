package jadx.tests.integration.loops;

import jadx.NotYetImplemented;
import jadx.tests.api.IntegrationTest;
import java.io.File;
import java.io.FileOutputStream;
import org.assertj.core.api.Assertions;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop3.class */
public class TestBreakInLoop3 extends IntegrationTest {

    /* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop3$TestCls.class */
    public static class TestCls {
        private StringBuilder builder = new StringBuilder();

        public void writeMore(String fid) {
            boolean tryMkdir = true;
            File ff = new File(fid);
            while (true) {
                prt("1");
                try {
                    new FileOutputStream(fid).close();
                    break;
                } catch (Exception e) {
                    if (tryMkdir) {
                        tryMkdir = false;
                        prt("2");
                    } else {
                        prt("3");
                        if (ff.exists()) {
                            prt("4");
                        } else {
                            prt("5");
                        }
                        prt("6");
                        break;
                    }
                }
            }
            prt("7");
            prt("8");
        }

        private void prt(String s) {
            this.builder.append(s);
        }

        public void check() {
            writeMore("");
            Assertions.assertThat(this.builder).hasToString("12135678");
        }
    }

    @NotYetImplemented
    public void test43() throws Exception {
        getClassNode(TestCls.class);
    }
}
