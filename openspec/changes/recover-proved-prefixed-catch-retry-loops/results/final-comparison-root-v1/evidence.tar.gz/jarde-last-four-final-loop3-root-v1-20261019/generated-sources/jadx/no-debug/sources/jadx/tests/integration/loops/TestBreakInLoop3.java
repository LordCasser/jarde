package jadx.tests.integration.loops;

import jadx.NotYetImplemented;
import jadx.tests.api.IntegrationTest;
import java.io.File;
import java.io.FileOutputStream;
import org.assertj.core.api.Assertions;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop3.class */
public class TestBreakInLoop3 extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop3$TestCls.class */
    public static class TestCls {
        private StringBuilder builder = new StringBuilder();

        public void writeMore(String str) {
            boolean z = true;
            File file = new File(str);
            while (true) {
                prt("1");
                try {
                    new FileOutputStream(str).close();
                    break;
                } catch (Exception e) {
                    if (!z) {
                        prt("3");
                        if (file.exists()) {
                            prt("4");
                        } else {
                            prt("5");
                        }
                        prt("6");
                        break;
                    }
                    z = false;
                    prt("2");
                }
            }
            prt("7");
            prt("8");
        }

        private void prt(String str) {
            this.builder.append(str);
        }

        public void check() {
            writeMore("");
            Assertions.assertThat(this.builder).hasToString("12135678");
        }
    }

    @NotYetImplemented
    public void test43() throws Exception {
        getClassNode(TestCls.class);
    }
}
