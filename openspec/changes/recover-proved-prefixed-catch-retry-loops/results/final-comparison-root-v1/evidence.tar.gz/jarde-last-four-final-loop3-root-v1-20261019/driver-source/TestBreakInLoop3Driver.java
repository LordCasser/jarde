import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.Base64;
public final class TestBreakInLoop3Driver {
    private static final String TARGET = "jadx.tests.integration.loops.TestBreakInLoop3$TestCls";
    private static final String INPUT = "";
    private static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static String codeSource(Class<?> c) throws Exception {
        CodeSource source=c.getProtectionDomain().getCodeSource();
        if(source==null||source.getLocation()==null)throw new IllegalStateException("target has no CodeSource");
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }
    private static void requireEmptyCwd(String expected)throws Exception{
        String actual=Paths.get(".").toRealPath().toString();
        if(!actual.equals(expected))throw new IllegalStateException("unexpected JVM cwd: expected="+expected+" actual="+actual);
        String[] entries=new java.io.File(".").list();
        if(entries==null||entries.length!=0)throw new IllegalStateException("JVM cwd is not empty");
    }
    private static Object fresh(Constructor<?> ctor)throws Exception{return ctor.newInstance();}
    private static String builder(Field field,Object receiver)throws Exception{return String.valueOf(field.get(receiver));}
    private static String failure(Throwable t){return t==null?"none":t.getClass().getName();}
    private static String stack(Throwable t){java.io.StringWriter w=new java.io.StringWriter();t.printStackTrace(new java.io.PrintWriter(w));return w.toString();}
    private static String observeCheck(Constructor<?> ctor,Method check,Field builder,String cwd)throws Exception{
        requireEmptyCwd(cwd);Object receiver=fresh(ctor);String before=builder(builder,receiver);
        PrintStream previous=System.out;ByteArrayOutputStream captured=new ByteArrayOutputStream();PrintStream targetOut=new PrintStream(captured,true,"UTF-8");Throwable cause=null;
        try{System.setOut(targetOut);try{check.invoke(receiver);}catch(InvocationTargetException e){cause=e.getCause();}}
        finally{targetOut.flush();System.setOut(previous);targetOut.close();}
        String text=new String(captured.toByteArray(),StandardCharsets.UTF_8);
        String row="CHECK result="+(cause==null?"pass":"error")+" exception="+failure(cause)+" exception_message_b64="+b64(cause==null?"":String.valueOf(cause.getMessage()))+" exception_stack_b64="+b64(cause==null?"":stack(cause))+" stdout_b64="+b64(text)+" builder_before_b64="+b64(before)+" builder_after_b64="+b64(builder(builder,receiver));requireEmptyCwd(cwd);return row;
    }
    private static String observeWrite(Constructor<?> ctor,Method writeMore,Field builder,String cwd)throws Exception{
        requireEmptyCwd(cwd);Object receiver=fresh(ctor);String before=builder(builder,receiver);
        PrintStream previous=System.out;ByteArrayOutputStream captured=new ByteArrayOutputStream();PrintStream targetOut=new PrintStream(captured,true,"UTF-8");Throwable cause=null;String result="<not-returned>";
        try{System.setOut(targetOut);try{result="return="+String.valueOf(writeMore.invoke(receiver,INPUT));}catch(InvocationTargetException e){cause=e.getCause();}}
        finally{targetOut.flush();System.setOut(previous);targetOut.close();}
        String text=new String(captured.toByteArray(),StandardCharsets.UTF_8);
        String row="CASE index=0 name=empty-path-write input_b64="+b64(INPUT)+" result_b64="+b64(result)+" exception="+failure(cause)+" exception_message_b64="+b64(cause==null?"":String.valueOf(cause.getMessage()))+" exception_stack_b64="+b64(cause==null?"":stack(cause))+" target_stdout_b64="+b64(text)+" after_b64="+b64(INPUT)+" builder_before_b64="+b64(before)+" builder_after_b64="+b64(builder(builder,receiver));requireEmptyCwd(cwd);return row;
    }
    public static void main(String[]args)throws Exception{
        if(args.length<3)throw new IllegalArgumentException("usage: TestBreakInLoop3Driver actualRoot expectedRoot emptyWorkingDirectory [dependencyUrl ...]");
        String actual=Paths.get(args[0]).toRealPath().toString(),expected=Paths.get(args[1]).toRealPath().toString(),cwd=Paths.get(args[2]).toRealPath().toString();requireEmptyCwd(cwd);
        URL[]urls=new URL[args.length-2];urls[0]=Paths.get(actual).toUri().toURL();for(int i=3;i<args.length;i++)urls[i-2]=Paths.get(args[i]).toUri().toURL();
        try(URLClassLoader loader=new URLClassLoader(urls,null)){
            Class<?>target=Class.forName(TARGET,true,loader);if(target.getClassLoader()!=loader)throw new IllegalStateException("target did not load from isolated loader");
            String origin=codeSource(target);if(!origin.equals(expected))throw new IllegalStateException("wrong CodeSource: expected="+expected+" actual="+origin);
            Constructor<?>ctor=target.getDeclaredConstructor();ctor.setAccessible(true);Method writeMore=target.getDeclaredMethod("writeMore",String.class);writeMore.setAccessible(true);Method check=target.getDeclaredMethod("check");check.setAccessible(true);Field builder=target.getDeclaredField("builder");builder.setAccessible(true);
            String caseRow=observeWrite(ctor,writeMore,builder,cwd),checkRow=observeCheck(ctor,check,builder,cwd);System.out.println(caseRow);System.out.println(checkRow);requireEmptyCwd(cwd);
        }
    }
}