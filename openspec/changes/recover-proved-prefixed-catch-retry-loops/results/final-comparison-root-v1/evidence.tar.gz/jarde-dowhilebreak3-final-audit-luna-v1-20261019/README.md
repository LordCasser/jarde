# TestDoWhileBreak3 final receipt auditor

This is a read-only independent audit adapter for the final closed DoWhileBreak3 baseline receipt. It accepts the receipt path and the exact selected CLI path/SHA from the caller, so it does not bind to an earlier receipt or CLI build. The executed collector remains pinned to the prepared v2 collector; the audit checks that source pin and the copied collector in the receipt output.

Run the Python-only static self-test first:

```sh
python3 -B /private/tmp/jarde-dowhilebreak3-final-audit-luna-v1-20261019/static_selftest.py
```

After the root has closed a complete final baseline receipt, run the auditor with its exact selected CLI identity and a fresh output directory:

```sh
python3 -B /private/tmp/jarde-dowhilebreak3-final-audit-luna-v1-20261019/audit_baseline.py \
  --receipt /private/tmp/<closed-final-baseline>/execution.json \
  --cli /private/tmp/<selected-final-cli> \
  --cli-sha256 <exact-64-character-cli-sha256> \
  --out /private/tmp/<fresh-audit-output>
```

The audit preserves the accepted gates: source/driver/tool pins and source immutability, original outer and nested target inventory, exact default/all Jarde matrix, structured full-method results and physical UTF-8/BCI maps, full JADX outer/target source, JDK8 major-55/52 framework failure boundary, all generated source compiles and eligible dual-VM runs, ten CASE rows, same-profile/runtime semantic equality, separate raw stdout/stderr hashes, driver-only application classpath, parentless target loader and CodeSource checks, empty isolated cwd, wrong-root rejection, and output-tree immutability.

The outer JUnit assertion is read and pinned as source text; the driver does not execute it. There is no `check()` helper, and the audit does not inject one. Runtime case truth comes from the compiled original nested target. The auditor reports `passed` only after every retained gate succeeds. This package was prepared and statically self-tested without executing Java, Jarde, JADX, or Rust tooling.
