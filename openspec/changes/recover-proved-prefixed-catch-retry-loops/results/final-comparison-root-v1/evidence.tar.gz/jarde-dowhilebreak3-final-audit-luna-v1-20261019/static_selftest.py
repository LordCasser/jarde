#!/usr/bin/env python3
"""Python-only static checks for the DoWhileBreak3 receipt auditor adapter."""
import ast, base64, hashlib, importlib.util, json, subprocess, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
AUDIT=HERE/'audit_baseline.py'
COLLECTOR=Path('/private/tmp/jarde-dowhilebreak3-baseline-prepare-luna-v2-20261019/collect_baseline.py')
EXPECTED_COLLECTOR_SHA='91cd25d2ce448612570629d1c459c053ba5734e594753631532bd2997ae83063'
def need(ok,msg):
    if not ok: raise SystemExit(msg)
text=AUDIT.read_text(encoding='utf-8')
ast.parse(text,filename=str(AUDIT))
need(hashlib.sha256(COLLECTOR.read_bytes()).hexdigest()==EXPECTED_COLLECTOR_SHA,'frozen collector pin changed')
for stale_symbol in ('BASE=', 'RECEIPT=', 'LAUNCH=', 'EXPECTED_CLI=', 'EXPECTED_RECEIPT='):
    need(stale_symbol not in text,'fixed receipt or CLI pin symbol remains')
spec=importlib.util.spec_from_file_location('do3_audit_static_selftest',AUDIT)
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
encode=lambda value:base64.b64encode(value.encode('utf-8')).decode('ascii')
rows=[]
for index,name in enumerate(module.CASES):
    atoms={
        'index':str(index),'name':name,'plan_b64':encode('synthetic'),
        'result_b64':encode('return=void'),'exception':'none',
        'exception_message_b64':encode(''),'exception_stack_b64':encode(''),
        'target_stdout_b64':encode(''),'has_next_calls':'0','next_calls':'0',
        'event_trace_b64':encode(''),'remaining_b64':encode(''),
    }
    rows.append('CASE '+' '.join(f'{key}={value}' for key,value in atoms.items()))
for row in rows:
    parsed=module.parse_case_line(row)
    need(parsed['name'] in module.CASES and parsed['exception_type']=='none','synthetic CASE parser failed')
help_result=subprocess.run([sys.executable,'-B',str(AUDIT),'--help'],capture_output=True,text=True,check=True)
for option in ('--receipt','--cli','--cli-sha256','--out'):
    need(option in help_result.stdout,f'missing explicit CLI option {option}')
need('EXPECTED_CLI' not in text and 'EXPECTED_RECEIPT' not in text,'fixed legacy receipt/CLI symbol remains')
print(json.dumps({'status':'static_selftest_pass','audit_ast':'ok','synthetic_case_rows':len(rows),
                  'explicit_receipt_cli_sha_out':'ok','frozen_collector_pin':'ok','toolchains_executed':False},indent=2))
