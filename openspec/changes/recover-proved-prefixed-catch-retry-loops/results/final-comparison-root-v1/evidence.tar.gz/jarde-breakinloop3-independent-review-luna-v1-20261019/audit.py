#!/usr/bin/env python3
"""Independent raw-stream audit for the closed Loop3 baseline receipt."""
from __future__ import annotations
import base64, hashlib, importlib.util, json, re
from pathlib import Path

RECEIPT = Path('/private/tmp/jarde-breakinloop3-baseline-root-v1-20261019/execution.json')
OUT = Path(__file__).parent
EXPECTED_CLI_SHA = 'd29b6fee723d8f59fbecd9fd8be9f15a8ec73de3a90f5a2a29b24ff91e4af607'
TARGET = 'jadx/tests/integration/loops/TestBreakInLoop3$TestCls'
OUTER = 'jadx/tests/integration/loops/TestBreakInLoop3'
EXPECTED_METHODS = {('<init>', '()V', 1), ('writeMore', '(Ljava/lang/String;)V', 1),
                    ('prt', '(Ljava/lang/String;)V', 2), ('check', '()V', 1)}
EXPECTED_FIELDS = [('builder', 'Ljava/lang/StringBuilder;', 2)]
CASE_NAMES = ['empty-path-write']

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def pin(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def decode_b64(value: str) -> str:
    return base64.b64decode(value, validate=True).decode('utf-8', errors='strict')

def parse_driver(stdout: bytes) -> list[dict]:
    """Independent parse of the actual driver stdout protocol."""
    lines = stdout.decode('utf-8', errors='strict').splitlines()
    if len(lines) != 2: raise ValueError(f'expected CASE+CHECK, got {len(lines)} lines')
    cpat = re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) target_stdout_b64=([^ ]*) after_b64=([^ ]*) builder_before_b64=([^ ]*) builder_after_b64=([^ ]*)$')
    hpat = re.compile(r'^CHECK result=(pass|error) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) stdout_b64=([^ ]*) builder_before_b64=([^ ]*) builder_after_b64=([^ ]*)$')
    c = cpat.fullmatch(lines[0]); h = hpat.fullmatch(lines[1])
    if c is None or h is None: raise ValueError('malformed CASE or CHECK protocol row')
    idx,name,inp,result,etype,msg,stack,out,after,before,builder_after = c.groups()
    if idx != '0' or name != CASE_NAMES[0]: raise ValueError('CASE identity mismatch')
    cr,ce,cm,cs,co,cb,ca = h.groups()
    return [{'index':0,'name':name,'input':decode_b64(inp),'result':decode_b64(result),'exception_type':etype,
             'exception_message':decode_b64(msg),'exception_stack':decode_b64(stack),'target_stdout':decode_b64(out),
             'after':decode_b64(after),'builder_before':decode_b64(before),'builder_after':decode_b64(builder_after),
             'check_result':cr,'check_exception_type':ce,'check_exception_message':decode_b64(cm),
             'check_exception_stack':decode_b64(cs),'check_stdout':decode_b64(co),
             'check_builder_before':decode_b64(cb),'check_builder_after':decode_b64(ca)}]

def command_by_index(receipt, index):
    matches=[c for c in receipt['commands'] if c['index']==index]
    if len(matches)!=1: raise RuntimeError(f'command index {index}: count={len(matches)}')
    return matches[0]

def method_rows(payload):
    out=[]
    for m in payload['methods']:
        n=m['item']['name']['escaped']; d=m['item']['descriptor']['escaped']
        report=m.get('outcome',{}).get('report',{})
        out.append({'name':n,'descriptor':d,'outcome':m.get('outcome',{}).get('kind'),
                    'quality':report.get('quality'),'text':report.get('text'),
                    'source_map':report.get('source_map'),'row':m})
    return out

def main():
    receipt=json.loads(RECEIPT.read_text())
    assert receipt['schema']=='test-break-in-loop3-full-source-baseline-v1'
    assert receipt['status']=='captured-pending-independent-review'
    assert receipt['candidate_cli_sha256_expected']==EXPECTED_CLI_SHA
    assert len(receipt['commands'])==46
    raw_pins=[]
    for cmd in receipt['commands']:
        assert set(cmd['streams'])=={'stdout','stderr'}
        for channel,record in cmd['streams'].items():
            got=pin(Path(record['path']))
            assert got['bytes']==record['bytes'] and got['sha256']==record['sha256'],(cmd['index'],channel,got,record)
            raw_pins.append({'command':cmd['index'],'label':cmd['label'],'channel':channel,**got})
    assert len(raw_pins)==92

    # Pin all immutable source, CLI, compiler helper, and dependency inputs again.
    immutable_records=[]
    for field in ('source','case_plan','case_plan_source_copy','source_copy','cli','dependency_reference',
                  'dependency_harness_jar','driver_source','driver_copy','runtime_wrapper','jadx','jadx_jar',
                  'compare','guard','scanner','physical_parser'):
        row=receipt[field]; got=pin(Path(row['path']))
        assert got['bytes']==row['bytes'] and got['sha256']==row['sha256'],(field,got,row)
        immutable_records.append({'field':field,**got})
    assert receipt['cli']['sha256']==EXPECTED_CLI_SHA
    assert receipt['source_unchanged'] and receipt['source_unchanged_finally']
    assert receipt['external_inputs_unchanged'] and receipt['local_copies_unchanged_finally']
    assert receipt['target_absent'] and receipt['target_absent_finally']
    assert receipt['source_pins_before']==receipt['source_pins_after_finally']
    assert receipt['external_input_pins_before']==receipt['external_input_pins_after_finally']

    # Parse original physical classes independently using the pinned parser helpers.
    prep=Path('/private/tmp/jarde-breakinloop36-baseline-prepare-luna-v2-20261019/loop3/collect_baseline.py')
    collector=load(prep,'loop3_audit_helpers')
    compare=collector.load(Path(receipt['compare']['path']),'loop3_compare_audit')
    physical=collector.load(Path(receipt['physical_parser']['path']),'loop3_physical_audit')
    profile_facts={}
    for profile in receipt['source_profiles']:
        assert profile['exit_code']==0
        root=Path(profile['class_root'])
        expected={OUTER+'.class',TARGET+'.class'}
        actual={x.relative_to(root).as_posix() for x in root.rglob('*.class')}
        assert actual==expected,(profile['profile'],actual)
        target_path=root/(TARGET+'.class'); outer_path=root/(OUTER+'.class')
        tf=collector.full_class_facts(compare,physical,target_path,profile['profile']+' target audit')
        of=collector.full_class_facts(compare,physical,outer_path,profile['profile']+' outer audit')
        assert tf['class_name']==TARGET and tf['major']==52
        assert of['class_name']==OUTER and of['major']==52
        assert {(m['name'],m['descriptor'],m['access']) for m in tf['methods']}==EXPECTED_METHODS
        assert sorted(tuple(f) if not isinstance(f,dict) else (f['name'],f['descriptor'],f['access']) for f in tf['fields'])==EXPECTED_FIELDS
        profile_facts[profile['profile']]={'target':tf,'outer':of,'class_tree':{k:pin(root/k) for k in sorted(expected)}}

    # All eight actual API raw payloads, with source text, quality, identity and source maps rebuilt from stdout.
    api_summaries=[]; api_methods={}
    for cell in receipt['jarde_cells']:
        cmd=command_by_index(receipt,cell['command'])
        assert cmd['exit_code']==0 and cmd['label'].startswith('jarde-')
        raw=Path(cmd['streams']['stdout']['path']).read_bytes()
        payload=json.loads(raw.decode('utf-8'))
        input_path=Path(cell['input']['path']); input_pin=pin(input_path)
        assert input_pin['bytes']==cell['input']['bytes'] and input_pin['sha256']==cell['input']['sha256']
        class_root=Path(cell['input']['path']).parents[4] if cell['input_form']=='child' else None
        # For class identity, use the owner digest from raw report and compare with the actual selected class bytes.
        selected_class=Path(cell['input']['path']) if cell['input_form']=='child' else None
        if cell['input_form']=='bundle-child':
            # The bundle input is a JAR. Verify exact entry bytes against the class-file pin from its compiler profile.
            import zipfile
            src_profile=next(x for x in receipt['source_profiles'] if x['profile']==cell['profile'])
            class_path=Path(src_profile['class_root'])/(TARGET+'.class')
            with zipfile.ZipFile(input_path) as z:
                entry=z.read(TARGET+'.class')
            assert entry==class_path.read_bytes()
            selected_class=class_path
        selected=pin(selected_class)
        rows=method_rows(payload); assert {(m['name'],m['descriptor']) for m in rows}=={(a,b) for a,b,_ in EXPECTED_METHODS}
        assert len(rows)==4
        assert payload.get('execution',{}).get('status')=='complete'
        assert payload['class']['class_bytes']['length']==selected['bytes']
        payload_digest=payload['class']['class_bytes']['digest']
        facts=collector.full_class_facts(compare,physical,selected_class,'API '+cell['profile'])
        per_method=[]
        for method in rows:
            key=(method['name'],method['descriptor'])
            pmethod=next(m for m in facts['methods'] if (m['name'],m['descriptor'])==key)
            audit=collector.audit_method_map(method['row'],pmethod)
            assert audit['issues']==[],(cell['profile'],cell['input_form'],cell['evidence'],key,audit['issues'])
            assert audit['mapped_bcis']==sorted(audit['physical_bcis']) and audit['covers_all_physical_bcis']
            assert method['outcome']=='recovered'
            if method['name']=='writeMore':
                assert method['quality']=='fallback'
                assert 'jre_region_ownership_overlap' in method['row']['outcome']['report'].get('fallbacks',[])
                assert 'BCI 11' in method['text'] and 'more than one owner' in method['text']
            else:
                assert method['quality']=='structured'
            identity=method['row']['item']['identity']
            assert identity['owner']['class_bytes']['digest']==payload_digest
            location=identity['owner']['location']
            assert location['kind'] in ('standalone_root','archive_entry')
            if location['kind']=='standalone_root': assert location['snapshot']==payload_digest
            else: assert location['entry']['origin']['snapshot']
            per_method.append({'name':method['name'],'descriptor':method['descriptor'],'quality':method['quality'],
                               'outcome':method['outcome'],'text':method['text'],'source_map':method['source_map'],'map_audit':audit,
                               'identity':identity})
        api_methods[(cell['profile'],cell['input_form'],cell['evidence'])]=per_method
        api_summaries.append({'profile':cell['profile'],'form':cell['input_form'],'evidence':cell['evidence'],
                              'command':cell['command'],'input':selected,'methods':per_method})
    assert len(api_summaries)==8
    # Default/all are byte-identical for body text, quality, method identity and source map per same profile/form.
    stability=[]
    for profile in ('debug','no-debug'):
        for form in ('child','bundle-child'):
            a=api_methods[(profile,form,'default')]; b=api_methods[(profile,form,'all')]
            for x,y in zip(a,b):
                assert (x['name'],x['descriptor'],x['quality'],x['outcome'],x['text'],x['source_map'],x['identity']) == \
                       (y['name'],y['descriptor'],y['quality'],y['outcome'],y['text'],y['source_map'],y['identity'])
                stability.append({'profile':profile,'form':form,'method':x['name']+x['descriptor'],
                                  'body_quality_identity_default_all_equal':True,
                                  'mapped_bcis_default':x['map_audit']['mapped_bcis'],
                                  'mapped_bcis_all':y['map_audit']['mapped_bcis']})

    # Directly parse all original/generated VM stdout, not the receipt's parsed rows.
    original_by={}
    runtime_summaries=[]
    for cell in receipt['original_runtime']:
        cmd=command_by_index(receipt,cell['command']); assert cmd['exit_code']==0
        rows=parse_driver(Path(cmd['streams']['stdout']['path']).read_bytes()); assert len(rows)==1
        row=rows[0]; assert row['input']=='' and row['after']=='' and row['exception_type']=='none'
        assert row['result']=='return=null' and row['builder_before']=='' and row['builder_after']=='12135678'
        assert row['check_result']=='pass' and row['check_exception_type']=='none'
        assert row['check_builder_before']=='' and row['check_builder_after']=='12135678'
        original_by[(cell['profile'],cell['runtime'])]=row
        runtime_summaries.append({'kind':'original', 'profile':cell['profile'],'runtime':cell['runtime'],'command':cell['command'],'observation':row})
    assert len(original_by)==4
    for cell in receipt['generated_runtime']:
        cmd=command_by_index(receipt,cell['command']); assert cmd['exit_code']==0
        row=parse_driver(Path(cmd['streams']['stdout']['path']).read_bytes())[0]
        baseline=original_by[(cell['profile'],cell['runtime'])]
        assert row==baseline
        runtime_summaries.append({'kind':'generated-jadx','profile':cell['profile'],'runtime':cell['runtime'],
                                  'compiler':cell['compiler'],'command':cell['command'],'matches_original_raw':True,'observation':row})
    assert len(receipt['generated_runtime'])==4
    # Wrong-root controls are real negative tests; their raw stderr must name the mismatch.
    wrong=[]
    for cell in [receipt['wrong_root_control'],*receipt['generated_wrong_root_controls']]:
        cmd=command_by_index(receipt,cell['command']); err=Path(cmd['streams']['stderr']['path']).read_bytes()
        assert cmd['exit_code']==1 and b'wrong CodeSource:' in err
        wrong.append({'command':cell['command'],'exit_code':cmd['exit_code'],'wrong_CodeSource_rejected':True,
                      'stderr':pin(Path(cmd['streams']['stderr']['path']))})

    # Compile matrix and raw compiler diagnostics.
    compile_rows=[]
    for c in receipt['commands']:
        if c['label'].startswith('rebuild-') or c['label']=='javac8-full-upstream-source-boundary' or c['label'].startswith('javac23-full-source-'):
            stdout=Path(c['streams']['stdout']['path']).read_bytes(); stderr=Path(c['streams']['stderr']['path']).read_bytes()
            compile_rows.append({'command':c['index'],'label':c['label'],'exit_code':c['exit_code'],
                                 'stdout':pin(Path(c['streams']['stdout']['path'])),'stderr':pin(Path(c['streams']['stderr']['path']))})
    assert len(compile_rows)==23
    jarde_compile=[c for c in compile_rows if c['label'].startswith('rebuild-jarde-')]
    jadx_compile=[c for c in compile_rows if c['label'].startswith('rebuild-jadx-')]
    assert len(jarde_compile)==16 and all(c['exit_code']==1 for c in jarde_compile)
    assert len(jadx_compile)==4
    assert sum(c['exit_code']==0 for c in jadx_compile)==2 and sum(c['exit_code']==1 for c in jadx_compile)==2
    assert len(receipt['generated_runtime'])==4
    assert receipt['javac8_full_source_boundary']['exit_code']==1
    bstderr=Path(command_by_index(receipt,1)['streams']['stderr']['path']).read_bytes()
    assert b'55.0' in bstderr or b'version 55' in bstderr
    # Reopen captured full-source copies and class-tree outputs from disk, not just their summary rows.
    source_output_checks=[]
    for path_text, expected in receipt['generated_source_output_pins_before'].items():
        actual=pin(Path(path_text)); assert actual['bytes']==expected['bytes'] and actual['sha256']==expected['sha256']
        source_output_checks.append(actual)
    class_tree_checks=[]
    for root_text, expected_tree in receipt['generated_class_trees'].items():
        root=Path(root_text); actual_tree={p.relative_to(root).as_posix():pin(p) for p in sorted(root.rglob('*.class'))}
        assert actual_tree==expected_tree,(root_text, len(actual_tree),len(expected_tree))
        class_tree_checks.append({'root':root_text,'class_count':len(actual_tree),'tree':actual_tree})

    # Recompute current external pins for post-capture context; receipt before/after equality is
    # the within-run invariant, while current files may legitimately move after the closed capture.
    external_current={'files':[],'dependency_artifacts':[],'dependency_directories':{},'jdk_tools':{}}
    for row in receipt['external_input_pins_before']['files']:
        q=Path(row['path']); external_current['files'].append(pin(q) if q.exists() else {'path':str(q),'missing':True})
    for row in receipt['external_input_pins_before']['dependency_artifacts']:
        q=Path(row['path']); external_current['dependency_artifacts'].append(pin(q) if q.exists() else {'path':str(q),'missing':True})
    for folder, tree in receipt['external_input_pins_before']['dependency_directories'].items():
        root=Path(folder); actual={p.relative_to(root).as_posix():pin(p) for p in sorted(root.rglob('*.class'))} if root.exists() else None
        external_current['dependency_directories'][folder]=actual
    for label, row in receipt['external_input_pins_before']['jdk_tools'].items():
        q=Path(row['path']); external_current['jdk_tools'][label]=pin(q) if q.exists() else {'path':str(q),'missing':True}
    external_current_matches_capture=external_current==receipt['external_input_pins_before']

    # Source/tool exact final state remains the receipt's bound set.
    assert receipt['source_unchanged_finally'] and receipt['external_inputs_unchanged'] and receipt['target_absent_finally']

    review={'schema':'loop3-independent-raw-review-v1','status':'independently-reopened',
            'receipt':pin(RECEIPT),'candidate_cli_sha256':EXPECTED_CLI_SHA,
            'counts':{'commands':len(receipt['commands']),'raw_streams_rehashed':len(raw_pins),'api_calls':len(api_summaries),
                      'methods_per_api':4,'structured_methods_per_api':3,'fallback_writeMore_per_api':1,
                      'complete_source_profiles_success':len(receipt['source_profiles']),
                      'javac8_framework_full_source_boundary_failures':1,'jarde_full_source_recompile_failures':len(jarde_compile),
                      'jadx_full_source_recompile_attempts':len(jadx_compile),'jadx_full_source_recompile_successes':2,
                      'jadx_jdk8_full_source_failures':2,'original_vm_runs':4,'generated_jadx_vm_runs':4,
                      'wrong_CodeSource_controls':len(wrong)},
            'raw_stream_pins':raw_pins,'immutable_pins_reopened':immutable_records,'generated_source_output_pins_reopened':source_output_checks,'generated_class_trees_reopened':class_tree_checks,'external_inputs_currently_match_capture':external_current_matches_capture,'external_inputs_current_snapshot':external_current,
            'final_guards':{'source_unchanged':receipt['source_unchanged_finally'],'external_tools_and_dependencies_unchanged':receipt['external_inputs_unchanged'],
                            'target_absent':receipt['target_absent_finally'],'generated_outputs_unchanged':receipt['generated_outputs_unchanged']},
            'original_class_facts':profile_facts,'api_cells':api_summaries,'default_all_stability':stability,
            'runtime_observations':runtime_summaries,'wrong_root_controls':wrong,'compile_diagnostics':compile_rows,
            'primary_gap':'Across all eight API payloads, ctor/prt/check are structured while writeMore falls back whole-method with jre_region_ownership_overlap. The raw explanation identifies BCI 11 as having multiple owners in the completed Region tree. This establishes the observable gap, not its root cause.',
            'framework_boundary':'The original unchanged full source fails under configured javac8 with framework/compiler version diagnostics involving major 55/52; javac23 compiles both full-source profiles. Original check() passes on all four JVM runs, so this is not a check failure in this run.',
            'nyi_boundary':'Upstream test43 is @NotYetImplemented but has // @Test. This disabled annotation does not demonstrate an actual JADX inability: the separate actual JADX full-source recompiles succeed under javac23 and four isolated VM runs match the original.',
            'architecture_initial_draft':[
              'The repeated owner at physical BCI 11 is first a Region-tree ownership invariant failure, not evidence by itself of a malformed CFG. Inspect the canonical block identity at BCI 11 together with predecessor/successor sets and the completed Region forest; determine whether two nested/overlapping region certificates both claim the same canonical block on a shared exceptional retry path.',
              'Before introducing any new CFG or loop model, follow existing `loop_region`, `try_scope`, `RetryLoopFacts`, and `prefixed_exceptional_retry_loop` proof artifacts from discovery through ownership assignment. The retry loop already has evidence for its header, retry edge, exceptional continuation, and exit; if the evidence is sufficient, reuse that certificate to assign one owner and keep catch/continue transfer paths outside the ordinary loop body as required by existing invariants.',
              'A likely candidate is that the prefix exceptional retry proof and an enclosing loop/try-scope proof each materialize BCI 11 as a body entry or join. Verify by tracing exact owner insertion sites and certificate identity before making an implementation claim. Do not resolve this by relaxing the uniqueness invariant or inventing a second CFG representation.'
            ],
            'limitations':['Architecture notes are hypotheses for the upcoming IR probe; no implementation or root-cause claim is made.','The 16 Jarde generated-source compilations all fail and produce no runtime artifact; preserve them as source-output/buildability evidence, not VM semantics.']}
    (OUT/'review.json').write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'status':review['status'],'raw_streams':len(raw_pins),'api_calls':len(api_summaries),'jarde_compile_failures':len(jarde_compile),'jadx_compile_successes':2,'runtime_matches':len(receipt['generated_runtime'])},indent=2))

if __name__=='__main__': main()
