# Prefixed retry independent audit v5

This is a new strict auditor for the refreshed collector. It preserves v4's raw stream, API, full class inventory, source/map, class tree, isolated loader, runtime-oracle, and wrong-CodeSource checks. The only expected command-line change is the exact full-source JADX invocation, which must include `--rename-flags none`. The generated matrix is still required in full: 20 eligible generated compilation rows, 40 matching VM observations, and 20 wrong-root rejections.

The closed v4 audit rejected the previous receipt because the default JADX decode renamed the valid default-package target to `defpackage`, making four successfully compiled source rows ineligible for exact target identity. The closed package probe confirmed that `--rename-flags none` preserves `//defaultpackage`; this v5 does not relax any grid. v4 and its result remain unchanged.

Run the new collector first, then audit its closed receipt using the exact collector hash:

```sh
python3 -B /private/tmp/jarde-prefixedretry-control-audit-luna-v5-20261019/audit_control_v5.py \
  --receipt <closed-execution.json> \
  --collector /private/tmp/jarde-prefixedretry-control-tools-luna-v4-20261019/collect_control.py \
  --collector-sha256 0d57ad5dae3a8494faedb5b0711b0c7bc42d55b7014b8f3a1352a116cdd198ff \
  --out <new-independent-audit.json>
```
