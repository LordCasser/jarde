# Loop3 independent audit v9

This fresh version corrects only the printed summary and duplicate keys in the review `counts`: Jarde attempts, successes, and failures now derive from actual compile rows, and repeated JADX counts are emitted once. The acceptance checks and the review schema/status are unchanged. The v8 package remains sealed and unmodified; its printed `jarde_compile_failures` incorrectly reported 16 attempts as failures. The closed receipt has 16 successful Jarde compiles and 0 failed Jarde compiles. Across all generated-source builds there are 18 successes and 2 JADX failures; generated VM runs are 36.

Replay the exact closed receipt with the same candidate CLI binding:

```sh
python3 -B /private/tmp/jarde-breakinloop3-independent-review-luna-v9-20261019/audit.py \
  --receipt /private/tmp/jarde-last-four-final-loop3-root-v1-20261019/execution.json \
  --cli /private/tmp/jarde-last-four-final-static-build-root-v2-20261019/candidate-cli \
  --cli-sha256 ed74e005c1bc97bcdf4a15f6a27da9e9d8a1ecdf7fe576836820ed2ce323222d \
  --out /private/tmp/jarde-last-four-loop3-independent-audit-luna-v9-20261019
```
