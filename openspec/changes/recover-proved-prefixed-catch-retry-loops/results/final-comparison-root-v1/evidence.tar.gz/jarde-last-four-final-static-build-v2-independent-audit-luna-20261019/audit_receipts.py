from pathlib import Path
import hashlib,json,stat
BASE=Path('/private/tmp')
NEW=BASE/'jarde-last-four-final-static-build-root-v2-20261019'/'execution.json'
OLD=BASE/'jarde-last-four-final-focused-root-v1-20261019'/'execution.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def srcmap(d,key):return {x['path']:(x['bytes'],x['sha256']) for x in d.get(key,[])}
def reopen_stream(pin,cmd):
 p=Path(pin['path']);b=p.read_bytes();h=sha(b)
 return {'path':str(p),'bytes':len(b),'receipt_bytes':pin['bytes'],'sha256':h,'receipt_sha256':pin['sha256'],'ok':len(b)==pin['bytes'] and h==pin['sha256']}
new=load(NEW);old=load(OLD);before=srcmap(new,'source_before');after=srcmap(new,'source_after');oldsrc=srcmap(old,'source_before')
commands=[];streams=[]
for c in new['commands']:
 ss={k:reopen_stream(v,c['index']) for k,v in c.get('streams',{}).items()};streams.extend(ss.values())
 commands.append({'index':c['index'],'argv':c.get('argv'),'exit_code':c.get('exit_code'),'streams':ss})
cli_info=new['cli'];cli=Path(cli_info['path']);b=cli.read_bytes();mode=stat.S_IMODE(cli.stat().st_mode);csha=sha(b)
source_changes=sorted(p for p in before.keys()|after.keys() if before.get(p)!=after.get(p))
focus_differences=[]
for suffix in ['/tests/recover_do2_return_public.rs','/crates/jarde-java/src/region.rs','/crates/jarde-java/src/build.rs']:
 op=next(((p,v) for p,v in oldsrc.items() if p.endswith(suffix)),None);np=next(((p,v) for p,v in before.items() if p.endswith(suffix)),None)
 focus_differences.append({'suffix':suffix,'focused_v1':None if op is None else {'path':op[0],'bytes':op[1][0],'sha256':op[1][1]},'static_v2':None if np is None else {'path':np[0],'bytes':np[1][0],'sha256':np[1][1]},'same':op==np})
clippy=Path(new['commands'][0]['streams']['stderr']['path']).read_text()
fmt_out=Path(new['commands'][1]['streams']['stdout']['path']).read_bytes();fmt_err=Path(new['commands'][1]['streams']['stderr']['path']).read_bytes()
build=Path(new['commands'][2]['streams']['stderr']['path']).read_text()
checks={
 'receipt_all_four_commands_exit_zero':new.get('status')=='commands_passed_pending_independent_acceptance' and [c.get('exit_code') for c in new['commands']]==[0,0,0,0],
 'clippy_success_with_warnings_denied':'Finished `dev` profile' in clippy and 'warning:' not in clippy and 'error:' not in clippy and new['commands'][0]['argv'][0:2]==['cargo','clippy'],
 'fmt_check_passed':new['commands'][1]['exit_code']==0 and fmt_out==b'' and fmt_err==b'',
 'jarde_cli_build_passed':'Finished `dev` profile' in build and new['commands'][2]['exit_code']==0 and new['commands'][2]['argv']==['cargo','build','--offline','-p','jarde-cli','--locked'],
 'final_clean_passed':new['commands'][3]['argv']==['cargo','clean'] and new['commands'][3]['exit_code']==0 and new.get('target_absent') is True,
 'all_raw_streams_reopened_and_pinned':len(streams)==8 and all(x['ok'] for x in streams),
 'source_closure_3373_unchanged':len(before)==3373 and before==after and new.get('source_unchanged') is True and new.get('source_changes')==[],
 'candidate_cli_matches_receipt_size_hash':cli.exists() and len(b)==cli_info['bytes']==64754240 and csha==cli_info['sha256']=='ed74e005c1bc97bcdf4a15f6a27da9e9d8a1ecdf7fe576836820ed2ce323222d',
 'candidate_cli_mode_0555_readonly_executable':mode==0o555 and (cli.stat().st_mode&0o111)==0o111 and (cli.stat().st_mode&0o222)==0,
 'previous_focused_failure_preserved':old.get('status')=='failed' and old['commands'][5].get('exit_code')==101 and 'unused import: `jarde_reader::budget::Budget`' in Path(old['commands'][5]['streams']['stderr']['path']).read_text(),
 'v2_source_diff_is_test_import_only_in_relevant_pins':next(x for x in focus_differences if x['suffix'].endswith('recover_do2_return_public.rs'))['same'] is False and all(x['same'] for x in focus_differences if not x['suffix'].endswith('recover_do2_return_public.rs')),
}
report={'schema':'last-four-final-static-build-v2-independent-audit','interpretation':'All four v2 static commands passed: workspace Clippy with -D warnings, rustfmt check, jarde-cli build, and cargo clean. CLI artifact matches its receipt at 64,754,240 bytes, SHA-256 ed74e005..., mode 0555. This later result does not alter the separate focused-v1 FAILED receipt; that earlier Clippy failure is preserved and the public-test source pin differs in v2 while region.rs/build.rs pins remain equal. Four-group comparison outputs were not read.','checks':checks,'all_checks_pass':all(checks.values()),'receipt':{'path':str(NEW),'status':new.get('status'),'finished_utc':new.get('finished_utc'),'source_before_count':len(before),'source_after_count':len(after),'source_unchanged':new.get('source_unchanged'),'source_changes':new.get('source_changes'),'target_absent':new.get('target_absent'),'commands':commands,'raw_streams':streams,'candidate_cli':{'path':str(cli),'receipt_bytes':cli_info['bytes'],'actual_bytes':len(b),'receipt_sha256':cli_info['sha256'],'actual_sha256':csha,'mode_octal':oct(mode),'executable':bool(cli.stat().st_mode&0o111),'writable':bool(cli.stat().st_mode&0o222)}},'focused_v1_comparison':{'path':str(OLD),'status':old.get('status'),'source_change_differences':focus_differences,'clippy_failure':'unused import: `jarde_reader::budget::Budget` in tests/recover_do2_return_public.rs:4'}}
OUT=Path('/private/tmp/jarde-last-four-final-static-build-v2-independent-audit-luna-20261019')
(OUT/'audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print(json.dumps({'audit':str(OUT/'audit.json'),'checks':checks,'cli':report['receipt']['candidate_cli']},indent=2,ensure_ascii=False))
