# Independent audit: final static-build v2

All four commands in the closed static-build receipt exited successfully: workspace Clippy with `-D warnings`, `cargo fmt --all -- --check`, `cargo build --offline -p jarde-cli --locked`, and `cargo clean`. All eight raw streams were reopened and their byte lengths and SHA-256 hashes match the receipt. The source closure contains 3,373 entries and is identical before and after; `target_absent=true` after cleanup.

The CLI artifact at `candidate-cli` is 64,754,240 bytes, SHA-256 `ed74e005c1bc97bcdf4a15f6a27da9e9d8a1ecdf7fe576836820ed2ce323222d`, mode `0555` (executable and not writable). The Clippy output contains the successful `Finished` line and no warnings or errors; fmt has empty stdout/stderr; the CLI build ends with `Finished`.

This v2 result does not change the separate focused-v1 receipt, which remains `failed` on the unused `Budget` import. The pinned Do2 public test source changed from 10,424 bytes / SHA `f0f086...` to 10,390 bytes / SHA `f1d94d...`; `region.rs` and `build.rs` pins are identical across the two receipts. The current four-group comparison outputs were not read.

`audit.json` contains the exact command/raw pins, source snapshot comparison, candidate CLI metadata, and checks. `audit_receipts.py` reproduces the audit using Python only.
