# PrefixedRetryControl independent audit v4

This version retains v3's reference-only tool pin distinction and the exact BCI 71 mapping debt. It adapts one physical inventory detail: `compare.parse_class` represents fields as tuples, while the independent physical parser represents them as named dictionaries. The field inventory assertion now normalizes both representations to `(name, descriptor, access)` triples before exact comparison.

The v3 run reached original target inventory validation after its tool-pin gate passed, then failed with `TypeError` indexing a tuple as a dictionary. No other v3 failure was observed. v3 remains unchanged.

Replay:

```sh
python3 -B /private/tmp/jarde-prefixedretry-control-audit-luna-v4-20261019/audit_control_v4.py \
  --receipt /private/tmp/jarde-last-four-final-retry-control-root-v1-20261019/execution.json \
  --collector /private/tmp/jarde-prefixedretry-control-tools-root-v3-20261019/collect_control.py \
  --collector-sha256 90a594e426187467688eff466d99e8e90015207746e4d24a7f62312515b08768 \
  --out /private/tmp/jarde-last-four-retry-control-independent-audit-luna-v4-20261019.json
```
