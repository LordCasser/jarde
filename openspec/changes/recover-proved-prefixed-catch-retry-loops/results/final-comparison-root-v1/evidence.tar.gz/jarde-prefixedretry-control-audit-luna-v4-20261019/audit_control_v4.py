#!/usr/bin/env python3
"""Independent strict audit for a closed PrefixedRetryControl full-source receipt."""
from __future__ import annotations
import argparse, base64, hashlib, importlib.util, json, re, sys, zipfile
from collections import Counter
from pathlib import Path

SCHEMA='prefixed-catch-retry-control-full-source-v1'
REFERENCE_ONLY_LABELS={'loop2_accepted_control_collector','loop2_accepted_independent_auditor','loop2_control_source'}
INTERNAL='PrefixedRetryControl'
DRIVER='PrefixedRetryControlDriver'
PROFILES=('debug','no-debug'); RUNTIMES=('javac8','javac23')
FORMS=('child','bundle-child'); EVIDENCE=('default','all')
CASE_NAMES=('normal-success','retry-then-success','second-failure-left','second-failure-right','prefix-throws','retry-step-throws','left-step-throws','right-step-throws','join-step-throws','tail-step-throws')
PKG=Path('/private/tmp/jarde-prefixedretry-control-tools-luna-v1-20261019')
PINNED={'source':'c98853a3306cbd56844ebf98fb57c8fec427ac5bb00601b14c9b99ae7868beb9','driver':'5294154205a4c682fb8d480e624e424891f630025847cb12d48d271293767469','case_plan':'570a131e20530489601d2fddf157e92000c26b5ad79b019a3d3f6537bb81477f'}
CASE_RE=re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) stdout_b64=([^ ]*) after_b64=([^ ]*)$')
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()
def need(ok,msg):
    if not ok: raise ValueError(msg)
def pin(row,label):
    need(isinstance(row,dict) and {'path','bytes','sha256'}<=row.keys(),f'{label}: malformed pin')
    original=Path(row['path']); need(not original.is_symlink(),f'{label}: symlink pin rejected')
    p=original.resolve(strict=True)
    need(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],f'{label}: pin mismatch: {p}')
    return p
def decode(s): return base64.b64decode(s,validate=True).decode('utf-8','strict')
def parse_case_stream(raw):
    lines=raw.decode('utf-8','strict').splitlines()
    need(len(lines)==len(CASE_NAMES),f'expected exactly {len(CASE_NAMES)} CASE lines, got {len(lines)}')
    rows=[]
    for i,line in enumerate(lines):
        m=CASE_RE.fullmatch(line); need(m is not None,f'malformed CASE row {i}')
        idx,name,inp,res,exc,msg,stack,out,after=m.groups()
        need(int(idx)==i and name==CASE_NAMES[i],f'CASE identity/order mismatch at {i}')
        rows.append({'index':i,'name':name,'input':decode(inp),'result':decode(res),'exception_type':exc,
                     'exception_message':decode(msg),'exception_stack':decode(stack),'target_stdout':decode(out),'after':decode(after),'raw':line})
    return rows
def observed_projection(rows):
    keys=('index','name','input','result','exception_type','exception_message','target_stdout','after')
    return [{k:r[k] for k in keys} for r in rows]
def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path); need(spec is not None and spec.loader is not None,f'cannot import {path}')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def facts(compare,physical,path,label):
    a=compare.parse_class(path); b=physical.parse_class_file(Path(path).read_bytes())
    need(a['class_name']==b['class_name'] and a['major']==b['major'] and a['methods']==b['methods'],f'{label}: independent class parser disagreement')
    need(sorted((x['name'],x['descriptor'],x['access']) for x in b['fields'])==sorted(tuple(x) for x in a['fields']),f'{label}: independent field parser disagreement')
    a['access']=b['access']; return a
def class_tree(root,compare):
    root=Path(root).resolve(strict=True)
    return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*.class'))}
def file_tree(root,suffix):
    root=Path(root).resolve(strict=True)
    return [p.relative_to(root).as_posix() for p in sorted(root.rglob('*')) if p.is_file() and (suffix is None or p.suffix==suffix)]
def norm(v):
    if isinstance(v,dict): return {k:norm(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)): return [norm(x) for x in v]
    return v
def source_access(a): return a & ~0x1000
def check_inventory(original,generated,label):
    need(original['class_name']==generated['class_name'] and original['major']==generated['major'],'class identity/major differs '+label)
    need(source_access(original['access'])==source_access(generated['access']) and ((original['access']==generated['access']) or ((original['access']^generated['access'])==0x1000)),'class access flags differ '+label)
    for kind,key,access in [('method',lambda x:(x['name'],x['descriptor']),lambda x:x['access']),
                            ('field',lambda x:(x['name'],x['descriptor']) if isinstance(x,dict) else (x[0],x[1]),lambda x:x['access'] if isinstance(x,dict) else x[2])]:
        left={key(x):x for x in original[kind+'s']}; right={key(x):x for x in generated[kind+'s']}
        need(left.keys()==right.keys(),f'{label}: {kind} name/descriptor inventory differs')
        for ident in left:
            la,ra=access(left[ident]),access(right[ident])
            need(source_access(la)==source_access(ra),f'{label}: source-visible {kind} flags differ at {ident}')
            need((la==ra) or ((la^ra)==0x1000),f'{label}: unsupported {kind} flag difference at {ident}')
def audit_map(method,physical_method):
    body=method.get('outcome',{}).get('report',{}); text=body.get('text'); sm=body.get('source_map'); issues=[]; mapped=set()
    if not isinstance(text,str) or not isinstance(sm,dict) or not isinstance(sm.get('segments'),list): return {'issues':['missing method text/source map'],'mapped_bcis':[],'unmapped_physical_bcis':[]}
    raw=text.encode('utf-8'); bounds={0}; pos=0
    for ch in text: pos+=len(ch.encode('utf-8')); bounds.add(pos)
    physical=set((physical_method or {}).get('code',{}).get('bcis',[]))
    for i,s in enumerate(sm['segments']):
        a,b=s.get('start'),s.get('end')
        if type(a)is not int or type(b)is not int or not 0<=a<=b<=len(raw) or a not in bounds or b not in bounds:
            issues.append(f'segment {i}: invalid UTF-8 byte bounds'); continue
        o=s.get('origin'); p=o.get('primary') if isinstance(o,dict) else None; derived=o.get('derived',[]) if isinstance(o,dict) else None
        if not isinstance(p,dict) or not isinstance(derived,list): issues.append(f'segment {i}: malformed origin'); continue
        for ref in [p,*derived]:
            if not isinstance(ref,dict): issues.append(f'segment {i}: malformed origin reference'); continue
            bci=ref.get('bci')
            if type(bci)is not int or bci not in physical: issues.append(f'segment {i}: nonphysical BCI {bci!r}')
            else: mapped.add(bci)
            mid=ref.get('method'); identity=method.get('item',{}).get('identity',{})
            if not isinstance(mid,dict) or not isinstance(identity,dict): issues.append(f'segment {i}: missing method identity'); continue
            try:
                n=bytes(mid.get('name',[])).decode('utf-8','strict'); d=bytes(mid.get('descriptor',[])).decode('utf-8','strict')
            except (TypeError,ValueError,UnicodeDecodeError): issues.append(f'segment {i}: malformed method identity'); continue
            owner=identity.get('owner')
            if n!=method.get('item',{}).get('name',{}).get('escaped') or d!=method.get('item',{}).get('descriptor',{}).get('escaped') or mid.get('owner')!=owner:
                issues.append(f'segment {i}: foreign method/owner')
    return {'issues':issues,'mapped_bcis':sorted(mapped),'unmapped_physical_bcis':sorted(physical-mapped),'physical_bcis':sorted(physical)}
def cmd_map(commands):
    by={c.get('index'):c for c in commands}; need(len(by)==len(commands),'duplicate command index')
    need(set(by)==set(range(1,len(commands)+1)),'command indices are not contiguous')
    return by
def verify_raw(command,channel,label):
    row=command.get('streams',{}).get(channel); p=pin(row,f'{label}/{channel}')
    return p.read_bytes()
def runtime_rows(row,commands,label):
    c=commands[row['command']]; raw=verify_raw(c,'stdout',label)
    parsed=parse_case_stream(raw)
    recorded=row.get('rows',[])
    keys=('index','name','input','result','exception_type','exception_message','exception_stack','target_stdout','after')
    need(len(recorded)==len(parsed),f'{label}: receipt row count differs from raw CASE stream')
    for i,(r,p) in enumerate(zip(recorded,parsed)):
        need(all(r.get(k)==p[k] for k in keys),f'{label}: recorded row {i} differs from reparsed raw CASE')
    return parsed

def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--receipt',required=True,type=Path); ap.add_argument('--collector',required=True,type=Path,help='exact collector source used for this receipt'); ap.add_argument('--collector-sha256',required=True,help='root-pinned SHA256 of --collector'); ap.add_argument('--out',required=True,type=Path); a=ap.parse_args()
    need(not a.out.exists(),f'refusing existing audit output {a.out}')
    receipt_path=a.receipt.resolve(strict=True); x=json.loads(receipt_path.read_text(encoding='utf-8')); need(x.get('schema')==SCHEMA,'receipt schema mismatch')
    root=Path(x['root']).resolve(strict=True); outroot=receipt_path.parent.resolve(); errors=[]; observed=[]
    need(Path(x.get('output','')).resolve()==outroot,'receipt output path does not bind to its directory')
    for rel,digest in [('pins.json','947825b0f20b9bc664b0d2e37960b05aea2738f85a3cb760f67923751fe8f047'),('tool-pins.json','5fb3e889f54445a5e924974e59376f2adb4c3d2de4677801c75f8a8f181fcaa6')]: need(sha(PKG/rel)==digest,f'frozen B package {rel} pin mismatch')
    frozen_pins=json.loads((PKG/'tool-pins.json').read_text(encoding='utf-8')); before_files=x.get('external_input_pins_before',{}).get('files',[]); before_map={str(Path(q['path']).resolve()):(q['bytes'],q['sha256']) for q in before_files}
    reference_only_pins=[]
    for ext in frozen_pins['inputs']:
        p=Path(ext['path']); need(p.is_file() and p.stat().st_size==ext['bytes'] and sha(p)==ext['sha256'],f'frozen external tool pin changed: {p}')
        if ext.get('label') in REFERENCE_ONLY_LABELS:
            reference_only_pins.append({'label':ext['label'],'path':str(p),'bytes':ext['bytes'],'sha256':ext['sha256'],'receipt_execution_pin_required':False})
        else:
            need(before_map.get(str(p.resolve()))==(ext['bytes'],ext['sha256']),f'receipt omits/mis-pins frozen external tool: {p}')
    bylabel={r['label']:r for r in frozen_pins['inputs']}
    for field,label in [('jadx','jadx_launcher'),('jadx_jar','jadx_jar'),('compare','compare'),('guard','guard'),('scanner','target_size_scanner'),('physical_parser','physical_class_parser')]:
        need(Path(x[field]['path']).resolve()==Path(bylabel[label]['path']).resolve() and x[field]['sha256']==bylabel[label]['sha256'],f'{field} differs from frozen tool pin')
    need(Path(x['source']['path']).resolve()==(PKG/'source/PrefixedRetryControl.java').resolve() and Path(x['case_plan']['path']).resolve()==(PKG/'caseplans.json').resolve() and Path(x['driver_source']['path']).resolve()==(PKG/'driver/PrefixedRetryControlDriver.java').resolve(),'receipt inputs are not from frozen control package')
    driver_text=pin(x['driver_source'],'driver source').read_text(encoding='utf-8')
    need('newURLClassLoader(urls,null)' in driver_text.replace(' ', '') and 'Class.forName(TARGET,true,loader)' in driver_text.replace(' ','') and 'wrong CodeSource:' in driver_text,'driver does not prove eager parentless CodeSource loading')
    expected_jdk=next(r for r in frozen_pins['inputs'] if r['label']=='jdk_manifest'); need(Path(x['jdk_manifest']['path']).resolve()==Path(expected_jdk['path']).resolve() and x['jdk_manifest']['sha256']==expected_jdk['sha256'],'JDK manifest does not match frozen tool pin')
    jdk_snapshot=x.get('external_input_pins_before',{}).get('jdk_tools',{})
    for leg in RUNTIMES:
        for tool in ('java','javac','javap'):
            rec=x['jdk_manifest']['tools'][leg][tool]; snap=jdk_snapshot.get(f'{leg}_{tool}')
            need(snap is not None and Path(snap['path']).resolve()==Path(rec['path']).resolve() and snap['sha256']==rec['sha256'] and snap['bytes']==rec['bytes'],'JDK tool pin differs from configured manifest')
    need(x.get('dependency_classpath')==[] and x.get('dependency_urls')==[],'unexpected target dependencies')
    need(x.get('check_method_required') is False and x.get('filesystem_side_effects_allowed') is False,'control scope flags mismatch')
    need(x.get('runtime_case_names')==list(CASE_NAMES),'runtime case order differs from frozen A11 driver')
    # Frozen input/driver/collector pins and copied collector.
    for key in ('source','case_plan','case_plan_source_copy','source_copy','driver_source','driver_copy','runtime_wrapper','cli','jadx','jadx_jar','compare','guard','scanner','physical_parser'):
        pin(x.get(key),key)
    for key,digest in [('source',PINNED['source']),('driver_source',PINNED['driver']),('driver_copy',PINNED['driver']),('case_plan',PINNED['case_plan'])]: need(x[key]['sha256']==digest,f'frozen {key} source pin differs')
    need(x.get('candidate_cli_sha256_expected')==x['cli']['sha256'],'candidate CLI receipt digest differs from pinned executable')
    collector_source=a.collector.resolve(strict=True); need(len(a.collector_sha256)==64 and sha(collector_source)==a.collector_sha256,'provided collector path/SHA mismatch')
    collector_pin=next((p for p in x.get('external_input_pins_before',{}).get('files',[]) if Path(p.get('path','')).resolve()==collector_source),None)
    need(collector_pin is not None,'external collector pin absent or path differs from --collector'); pin(collector_pin,'external collector'); need(collector_pin['sha256']==a.collector_sha256,'receipt collector SHA differs from explicit collector pin')
    captured=outroot/'collector.py'; need(captured.is_file() and not captured.is_symlink() and captured.stat().st_size==collector_pin['bytes'] and sha(captured)==collector_pin['sha256'],'captured collector copy differs from pinned collector')
    # Reopen every raw stream separately, reject reuse and ensure exact command labels later.
    commands=x.get('commands',[]); by=cmd_map(commands); rawpaths=[]
    for c in commands:
        for channel in ('stdout','stderr'):
            b=verify_raw(c,channel,f'command {c.get("index")}'); p=Path(c['streams'][channel]['path']).resolve(); rawpaths.append(str(p)); need(p.parent.name=='raw',f'command {c["index"]} {channel} is outside raw/')
    need(len(rawpaths)==2*len(commands) and len(set(rawpaths))==len(rawpaths),'raw streams are not independent one-per-channel')
    # Import only pinned readers to independently parse target class files.
    compare=load_module(pin(x['compare'],'compare'),'audit_compare'); physical=load_module(pin(x['physical_parser'],'physical parser'),'audit_physical')
    plan_path=pin(x['case_plan'],'case plan'); plan=json.loads(plan_path.read_text(encoding='utf-8'))
    need([c.get('id') for c in plan.get('cases',[])]==list(CASE_NAMES),'case plan IDs differ')
    need(pin(x['case_plan_source_copy'],'caseplan source copy').read_bytes()==pin(x['source'],'source').read_bytes(),'caseplan source copy differs from original source')
    # Exact source compile profiles and independently derive physical API inventory.
    source_profiles=x.get('source_profiles',[]); need(len(source_profiles)==2 and {r['profile'] for r in source_profiles}==set(PROFILES),'JDK23 original profile matrix incomplete')
    source_by={r['profile']:r for r in source_profiles}; source_facts={}; source_roots={}
    for profile,row in source_by.items():
        need(row.get('exit_code')==0,f'{profile} original JDK23 source compilation failed')
        c=by[row['command']]; need(c['label']==f'javac23-full-source-{profile}',f'{profile} source command label mismatch')
        jdkrow=x['jdk_manifest']['tools']['javac23']; javac=jdkrow['javac']['path']
        argv=c['argv']; dest=Path(row['class_root']).resolve(strict=True); expected_debug='-g' if profile=='debug' else '-g:none'
        source=Path(x['source_copy']['path']).resolve(); empty=Path(x['empty_classpath']).resolve(); cliargs=[javac,'--release','8',expected_debug,'-encoding','UTF-8','-proc:none','-classpath',str(empty),'-sourcepath',str(empty),'-d',str(dest),str(source)]
        need(argv==cliargs,f'{profile} original javac23 argv mismatch')
        tree=class_tree(dest,compare); need(tree==row['class_tree'] and list(tree)==[INTERNAL+'.class'],f'{profile} original class tree/pins mismatch')
        f=facts(compare,physical,dest/(INTERNAL+'.class'),profile); source_facts[profile]=f; source_roots[profile]=dest
        need(f['class_name']==INTERNAL and f['major']==52,f'{profile} target identity/major mismatch')
        need({(m['name'],m['descriptor'],m['access']) for m in f['methods']}=={('<init>','()V',1),('step','(Ljava/lang/String;)V',2),('attempt','()V',2),('run','()V',1)},f'{profile} physical method inventory mismatch')
        need(sorted(tuple(v) if not isinstance(v,dict) else (v['name'],v['descriptor'],v['access']) for v in f['fields'])==[('attemptCalls','I',1),('exists','Z',1),('failuresRemaining','I',1),('stepCalls','I',1),('throwAt','Ljava/lang/String;',1),('trace','Ljava/lang/StringBuilder;',17)],f'{profile} physical field inventory mismatch')
    # Driver-only compilation and two original runtime profiles x VMs, parsing raw CASEs anew.
    dc=x.get('driver_compile',{}); dcmd=by[dc.get('command')]; need(dcmd['label']=='compile-independent-reflection-driver' and dcmd['exit_code']==0,'driver compilation missing/failed')
    drvsrc=pin(x['driver_source'],'driver source'); drvcopy=pin(x['driver_copy'],'driver copy'); need(drvsrc.read_bytes()==drvcopy.read_bytes(),'captured driver source differs from pinned source')
    empty=Path(x['empty_classpath']).resolve(); drvclasses=Path(x['driver_classes'][0]['path']).resolve().parent; javac8=x['jdk_manifest']['tools']['javac8']['javac']['path']; expected_driver_argv=[javac8,'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-classpath',str(empty),'-sourcepath',str(empty),'-d',str(drvclasses),str(drvcopy)]
    need(dcmd['argv']==expected_driver_argv,'driver compile argv mismatch')
    driver_classes=drvclasses; driver_tree=file_tree(driver_classes,'.class')
    need(driver_tree==['PrefixedRetryControlDriver$Case.class','PrefixedRetryControlDriver.class'],'unexpected driver helper classes')
    for pinrow in x.get('driver_classes',[]): pin(pinrow,'driver class')
    original_source=pin(x['source'],'upstream source'); source_copy=pin(x['source_copy'],'captured original source copy'); need(original_source.read_bytes()==source_copy.read_bytes(),'copied original control source differs from pinned source')
    runtime_copy=pin(x['runtime_wrapper'],'captured runtime wrapper'); runtime_external=next((q for q in x['external_input_pins_before']['files'] if Path(q['path']).name=='runtime-bound-cwd.py'),None); need(runtime_external is not None and pin(runtime_external,'external runtime wrapper').read_bytes()==runtime_copy.read_bytes(),'copied runtime wrapper differs from external pin')
    originals=x.get('original_runtime',[]); origmap={(r.get('profile'),r.get('runtime')):r for r in originals}
    need(len(originals)==4 and set(origmap)=={(p,r) for p in PROFILES for r in RUNTIMES},'original runtime grid incomplete')
    base_rows={}; expected_labels=Counter()
    for row in source_profiles: expected_labels[f'javac23-full-source-{row["profile"]}']+=1
    expected_labels['javac8-full-control-source-profile-debug']+=1; expected_labels['javac8-full-source-no-debug']+=1
    expected_labels['compile-independent-reflection-driver']+=1; expected_labels['jadx-version']+=1
    expected_labels['driver-code-source-wrong-root-control']+=1
    expected_labels.update({f'original-runtime-{p}-{r}':1 for p in PROFILES for r in RUNTIMES})
    for (profile,runtime),row in origmap.items():
        need(row.get('exit_code')==0,f'original runtime failed {profile}/{runtime}')
        c=by[row['command']]; expected_labels[c['label']]+=0
        need(c['label']==f'original-runtime-{profile}-{runtime}',f'original runtime label mismatch {profile}/{runtime}')
        argv=c['argv']; wrapper=Path(x['runtime_wrapper']['path']).resolve(); jdkrow=x['jdk_manifest']['tools'][runtime]; java=jdkrow['java']['path']
        cwd=Path(argv[4]).resolve(); target=source_roots[profile]
        need(argv[1:4]==['-B',str(wrapper),'30'] and Path(argv[5]).resolve()==Path(java).resolve() and argv[6:10]==['-Xverify:all','-cp',str(driver_classes),DRIVER],f'{profile}/{runtime} runtime launcher/application classpath mismatch')
        need(len(argv)==13 and Path(argv[10]).resolve()==target and Path(argv[11]).resolve()==target and Path(argv[12]).resolve()==cwd,f'{profile}/{runtime} runtime root/cwd args mismatch')
        need(not list(cwd.iterdir()),f'{profile}/{runtime} cwd not empty after runtime')
        rows=runtime_rows(row,by,f'original {profile}/{runtime}'); need([r['input'] for r in rows]==[q['input'] for q in plan['cases']],'original driver input observations differ from case plan'); base_rows[(profile,runtime)]=rows
        need(c['exit_code']==0,'original runtime command failed')
    canon=observed_projection(base_rows[('debug','javac23')]); need(all(observed_projection(v)==canon for v in base_rows.values()),'original runtime observations differ across profile/VM')
    # JDK8 original compile boundary and runtime matrix: preserve failures, require all expected successful source legs to be observed.
    j8profiles=x.get('javac8_source_profiles',[]); need(len(j8profiles)==2 and {r['profile'] for r in j8profiles}==set(PROFILES),'JDK8 original source profile records incomplete')
    need(all(r.get('exit_code')==0 for r in j8profiles),'JDK8 original source compile boundary failed; not a passing baseline')
    for r in j8profiles:
        p=r['profile']; c=by[r['command']]; need(c['label']==('javac8-full-control-source-profile-debug' if p=='debug' else 'javac8-full-source-no-debug'),f'JDK8 compile label mismatch {p}')
        debug='-g' if p=='debug' else '-g:none'; javac=x['jdk_manifest']['tools']['javac8']['javac']['path']; empty=Path(x['empty_classpath']).resolve(); dest=Path(r['class_root']).resolve(strict=True); src=Path(x['source_copy']['path']).resolve(); argv=c['argv']
        expected=['-source','8','-target','8',debug,'-encoding','UTF-8','-proc:none','-classpath',str(empty),'-sourcepath',str(empty),'-d',str(dest),str(src)]
        need(argv==[javac,*expected],f'JDK8 {p} original compile argv mismatch')
        actual=class_tree(dest,compare); need(actual==r['class_tree'],f'JDK8 {p} class tree/pins mismatch')
        if c['exit_code']==0:
            jf=facts(compare,physical,dest/(INTERNAL+'.class'),f'JDK8 original {p}'); need(jf['class_name']==INTERNAL and jf['major']==52,f'JDK8 {p} class identity/major mismatch'); check_inventory(source_facts[p],jf,f'JDK8 original {p}')
    j8runtime=x.get('javac8_original_runtime',[]); need(len(j8runtime)==4 and {(r['profile'],r['runtime']) for r in j8runtime}=={(p,r) for p in PROFILES for r in RUNTIMES},'JDK8-compiled original runtime matrix incomplete')
    for row in j8runtime:
        key=(row['profile'],row['runtime']); c=by[row['command']]; need(c['label']==f'javac8-original-runtime-{key[0]}-{key[1]}',f'JDK8 original runtime label mismatch {key}')
        need(row.get('exit_code')==0 and c['exit_code']==0,f'JDK8 compiled original runtime failed {key}')
        parsed=runtime_rows(row,by,f'JDK8 compiled original {key}'); need(observed_projection(parsed)==observed_projection(base_rows[key]),f'JDK8 compiled original differs from same-VM source oracle {key}')
        prof=next(p for p in j8profiles if p['profile']==key[0]); argv=c['argv']; wrapper=Path(x['runtime_wrapper']['path']).resolve(); java=x['jdk_manifest']['tools'][key[1]]['java']['path']; cwd=Path(argv[4]).resolve(); target=Path(prof['class_root']).resolve(strict=True)
        need(argv[1:4]==['-B',str(wrapper),'30'] and Path(argv[5]).resolve()==Path(java).resolve() and argv[6:10]==['-Xverify:all','-cp',str(driver_classes),DRIVER] and len(argv)==13 and Path(argv[10]).resolve()==target and Path(argv[11]).resolve()==target and Path(argv[12]).resolve()==cwd and not list(cwd.iterdir()),f'JDK8 original runtime argv/cwd mismatch {key}')
    # Exact Jarde API grid, raw JSON/output equality, independently rebuild all recorded method/map facts.
    api=x.get('jarde_cells',[]); api_expected={(p,INTERNAL,f,e) for p in PROFILES for f in FORMS for e in EVIDENCE}
    api_by={(r.get('profile'),r.get('api_class'),r.get('input_form'),r.get('evidence')):r for r in api}
    need(len(api)==8 and set(api_by)==api_expected,'Jarde API exact 8-cell grid mismatch')
    api_projection={}
    mapping_debts=[]
    for key,cell in api_by.items():
        p,klass,form,evidence=key; command=by[cell['command']]; policy='single-class' if form=='child' else 'plain-jar'; input_path=pin(cell['input'],f'{key} input').resolve(strict=True)
        expected_input=(source_roots[p]/(INTERNAL+'.class')) if form=='child' else Path(source_by[p]['bundle']['path']).resolve(strict=True)
        need(input_path==expected_input,f'{key} selected input does not match its requested class/JAR form')
        argv=[str(Path(x['cli']['path']).resolve()),'class-source','--input',str(input_path),'--class',klass,'--policy',policy,'--release','8','--format','json']
        if evidence=='all': argv+=['--evidence','all']
        need(command['label']==f'jarde-{p}-target-{form}-{evidence}' and command['argv']==argv,f'{key} API command/argv mismatch')
        need(command['exit_code']==cell['exit_code']==0,f'{key} API failed')
        raw=verify_raw(command,'stdout',f'{key} API'); reportpath=pin(cell['report'],f'{key} report'); need(reportpath.read_bytes()==raw,f'{key} report differs from raw stdout')
        doc=json.loads(raw.decode('utf-8','strict')); whole=pin(cell['whole_source'],f'{key} whole-source'); need(whole.read_bytes()==doc.get('text','').encode('utf-8'),f'{key} whole text differs from raw JSON text')
        physical=source_facts[p]; phys_methods={(m['name'],m['descriptor']):m for m in physical['methods']}; raw_methods=doc.get('methods'); need(isinstance(raw_methods,list),'API methods is not a list')
        actual_ids=[]; summaries=[]
        for method in raw_methods:
            item=method.get('item',{}); name=item.get('name',{}).get('escaped'); desc=item.get('descriptor',{}).get('escaped'); need((name,desc) in phys_methods,f'{key}: unknown API method identity {(name,desc)}'); actual_ids.append((name,desc))
            body=method.get('outcome',{}).get('report',{}); map_audit=audit_map(method,phys_methods[(name,desc)])
            need(not map_audit['issues'],f'{key} {name}{desc}: independently invalid physical map {map_audit["issues"]}')
            recorded=next((m for m in cell.get('methods',[]) if m.get('name')==name and m.get('descriptor')==desc),None); need(recorded is not None,f'{key}: method absent from receipt summary')
            for rk,rawvalue in [('identity',item.get('identity')),('owner',item.get('identity',{}).get('owner')),('location',item.get('identity',{}).get('owner',{}).get('location')),('variant',item.get('identity',{}).get('owner',{}).get('variant')),('outcome_kind',method.get('outcome',{}).get('kind')),('quality',body.get('quality')),('fallbacks',body.get('fallbacks')),('regions',body.get('regions')),('raw_text',body.get('text')),('source_map',body.get('source_map'))]: need(recorded.get(rk)==rawvalue,f'{key} {name}{desc}: receipt method {rk} differs from raw JSON')
            need(recorded.get('map_audit',{}).get('issues')==[] and recorded.get('map_audit',{}).get('mapped_bcis')==map_audit['mapped_bcis'] and recorded.get('map_audit',{}).get('unmapped_physical_bcis')==map_audit['unmapped_physical_bcis'] and recorded.get('map_audit',{}).get('physical_bcis')==map_audit['physical_bcis'] and recorded.get('map_audit',{}).get('covers_all_physical_bcis')==(map_audit['mapped_bcis']==map_audit['physical_bcis']),f'{key} {name}{desc}: stored map audit differs from independent recomputation')
            if name=='run' and desc=='()V':
                need(len(map_audit['physical_bcis'])==41 and map_audit['unmapped_physical_bcis']==[71] and map_audit['mapped_bcis']==sorted(set(map_audit['physical_bcis'])-{71}),f'{key} run()V: map debt differs from exact BCI-71/41 scope')
                mapping_debts.append({'profile':p,'form':form,'evidence':evidence,'method':'run()V','mapped_bcis':40,'physical_bcis':41,'unmapped_physical_bcis':[71]})
            else:
                need(map_audit['mapped_bcis']==map_audit['physical_bcis'],f'{key} {name}{desc}: unexpected physical BCI map gap {map_audit["unmapped_physical_bcis"]}')
            summaries.append({'identity':(name,desc),'quality':body.get('quality'),'text':body.get('text'),'source_map':body.get('source_map')})
        need(sorted(actual_ids)==sorted(phys_methods),f'{key} API method inventory differs from physical target')
        need(norm(cell.get('physical_method_inventory'))==norm(actual_ids) and norm(cell.get('expected_physical_method_inventory'))==norm(sorted(phys_methods)),f'{key} stored API inventories differ from independent census')
        api_projection[key]=(doc.get('text'),summaries)
    need(len(mapping_debts)==8 and {(r['profile'],r['form'],r['evidence']) for r in mapping_debts}=={(p,f,e) for p in PROFILES for f in FORMS for e in EVIDENCE},'mapping debt does not match exactly the eight run()V API cells')
    for p in PROFILES:
        for form in FORMS:
            need(api_projection[(p,INTERNAL,form,'default')]==api_projection[(p,INTERNAL,form,'all')],f'{p}/{form}: default/all source text, method IDs, quality, maps differ')
    # JARs must contain exactly the actual compiler output and identical physical class bytes.
    for p,row in source_by.items():
        jar=pin(row['bundle'],f'{p} class jar')
        with zipfile.ZipFile(jar) as z:
            members=sorted(n for n in z.namelist() if not n.endswith('/')); need(members==[INTERNAL+'.class'],f'{p} class JAR has unexpected members')
            need(z.read(INTERNAL+'.class')==(source_roots[p]/(INTERNAL+'.class')).read_bytes(),f'{p} class JAR target bytes differ')
    # Full JADX source cell and generated source copy closure.
    jadx=x.get('jadx_outputs',[]); need(len(jadx)==2 and {r['compiler_profile'] for r in jadx}==set(PROFILES),'JADX exact full-source profile grid incomplete')
    for row in jadx:
        p=row['compiler_profile']; c=by[row['command']]; need(row['display_profile']=='default' and c['label']==f'jadx-full-bundle-{p}-default' and c['exit_code']==row['exit_code']==0,'JADX full-source command failed/label mismatch')
        dest=receipt_path.parent/'jadx'/p/'default'; bundle=Path(source_by[p]['bundle']['path']).resolve(strict=True); need(c['argv']==[str(Path(x['jadx']['path']).resolve()),'--threads-count','1','--no-res','--config','none','-d',str(dest),str(bundle)],f'{p} JADX full-source argv mismatch')
        sources=[pin(s,f'JADX {p} source') for s in row['sources']]; actual=file_tree(receipt_path.parent/'jadx'/p/'default','.java')
        need([q.relative_to((receipt_path.parent/'jadx'/p/'default').resolve()).as_posix() for q in sources]==actual and bool(actual),'JADX source tree differs from pinned outputs')
    cells=x.get('generated_source_cells',[]); need(len(cells)==10,'expected 8 Jarde and 2 JADX generated source cells')
    expected_cells={(r['profile'],r['input_form']) for r in api}; got={(r.get('profile'),r.get('form')) for r in cells if r.get('kind')=='jarde'}
    need(got==expected_cells and sum(r.get('kind')=='jarde' for r in cells)==8 and sum(r.get('kind')=='jadx' for r in cells)==2,'generated source cell grid differs')
    copy_map={}
    for cell in cells:
        need(cell.get('source_available') is True,'generated full source unavailable')
        for srcpin in cell.get('source_pins',[]): pin(srcpin,'generated source input')
        for cp in cell.get('source_copies',[]): copy_map[cp['path']]=pin(cp,'generated source copy')
        need(len(cell.get('source_pins',[]))==len(cell.get('source_copies',[])),'source/source-copy pin counts differ')
        for sp,cp in zip(cell.get('source_pins',[]),cell.get('source_copies',[])):
            need(sp['bytes']==cp['bytes'] and sp['sha256']==cp['sha256'],'generated compiler copy differs from exact captured source bytes')
        need(len(cell.get('java_files',[]))>0 and len(cell.get('java_files',[]))==len(cell.get('source_copies',[])),'source/copy file counts differ')
        for path,pinrow in zip(cell['java_files'],cell['source_copies']): need(Path(path).resolve()==Path(pinrow['path']).resolve(),'source cell copy path mismatch')
    before=x.get('generated_source_output_pins_before',{}); after=x.get('generated_source_output_pins_after',{})
    need(set(before)==set(copy_map) and set(after)==set(copy_map),'generated source before/after pin inventory mismatch')
    for p in copy_map:
        need(pin(before[p],f'generated before {p}')==Path(p).resolve(strict=True) and pin(after[p],f'generated after {p}')==Path(p).resolve(strict=True),'generated source changed after capture')
        need(before[p]['sha256']==after[p]['sha256'] and before[p]['bytes']==after[p]['bytes'],'generated source bytes mutated')
    # Exact 20 rebuilds, independently derived from the 10 observed source cells and two compiler legs.
    compiles=x.get('generated_source_compilations',[]); expected_compile={(c['kind'],c['profile'],c.get('form'),c.get('evidence'),vm) for c in cells for vm in RUNTIMES}
    compile_by={(r.get('kind'),r.get('profile'),r.get('form'),r.get('evidence'),r.get('compiler')):r for r in compiles}
    need(len(compiles)==20 and set(compile_by)==expected_compile,'generated compilation exact 20-cell grid mismatch')
    need(all(r.get('exit_code')==0 and r.get('runtime_eligible') is True for r in compiles),'one or more of the 20 generated builds is not successful and runtime-eligible')
    expected_runtime=set(); expected_wrong=set(); class_tree_before=x.get('generated_class_trees',{}); class_tree_after=x.get('generated_class_trees_after',{})
    need(set(class_tree_before)==set(class_tree_after),'generated class before/after roots differ')
    for key,row in compile_by.items():
        kind,p,form,evidence,vm=key; c=by[row['command']]; cell=next(s for s in cells if (s['kind'],s['profile'],s.get('form'),s.get('evidence'))==key[:4]); rootpath=Path(row['class_root']).resolve(strict=True)
        need(c['label']==f'rebuild-{kind}-{p}-{form}-{evidence}-{vm}' and c['exit_code']==row['exit_code'],'rebuild label/exit differs')
        debug='-g' if p=='debug' else '-g:none'; javacrow=x['jdk_manifest']['tools'][vm]; javac=javacrow['javac']['path']
        empty=Path(x['empty_classpath']).resolve(); expected_argv=([javac,'-source','8','-target','8',debug,'-encoding','UTF-8','-proc:none','-classpath',str(empty),'-sourcepath',str(empty),'-d',str(rootpath),*cell['java_files']] if vm=='javac8' else [javac,'--release','8',debug,'-encoding','UTF-8','-proc:none','-classpath',str(empty),'-sourcepath',str(empty),'-d',str(rootpath),*cell['java_files']])
        need(c['argv']==expected_argv,f'{key} rebuild argv mismatch')
        actual=class_tree(rootpath,compare); need(actual==row['class_tree'] and class_tree_before[str(rootpath)]==actual and class_tree_after[str(rootpath)]==actual,f'{key} class-tree pins mismatch')
        if c['exit_code']==0:
            need(row.get('runtime_eligible') is True,f'{key} successful compile not eligible')
            expected_members=[INTERNAL+'.class'] if kind=='jarde' else [INTERNAL+'.class']
            need(sorted(actual)==expected_members,f'{key} generated class inventory differs')
            genfacts=facts(compare,physical,rootpath/(INTERNAL+'.class'),f'generated {key}'); check_inventory(source_facts[p],genfacts,f'generated {key}')
            need(row.get('class_facts') is not None and norm(row.get('class_facts').get(INTERNAL+'.class'))==norm(genfacts),f'{key} recorded class facts differ from parser')
            expected_runtime.update({key+(r,) for r in RUNTIMES}); expected_wrong.add(key)
        else:
            need(not actual,f'{key} failed compilation left class files')
    # Every successful source compile must have exactly two VMs and one wrong-root control.
    gen=x.get('generated_runtime',[]); gen_by={(r.get('kind'),r.get('profile'),r.get('form'),r.get('evidence'),r.get('compiler'),r.get('runtime')):r for r in gen}
    need(len(gen)==40 and len(expected_runtime)==40 and set(gen_by)==expected_runtime,'generated 20-build x dual-VM runtime matrix incomplete')
    for key,row in gen_by.items():
        build=key[:5]; base=base_rows[(key[1],key[5])]; c=by[row['command']]; need(c['label']==f'runtime-{build[0]}-{build[1]}-{build[2]}-{build[3]}-{build[4]}-{key[5]}' and c['exit_code']==row['exit_code']==0,'generated runtime label/exit mismatch')
        argv=c['argv']; wrapper=Path(x['runtime_wrapper']['path']).resolve(); java_row=x['jdk_manifest']['tools'][key[5]]; java=java_row['java']['path']; cwd=Path(argv[4]).resolve(); classroot=Path(row['class_root']).resolve(strict=True); driverclass=Path(x['driver_classes'][0]['path']).resolve().parent
        need(argv[1:4]==['-B',str(wrapper),'30'] and Path(argv[5]).resolve()==Path(java).resolve() and argv[6:10]==['-Xverify:all','-cp',str(driverclass),DRIVER] and len(argv)==13 and Path(argv[10]).resolve()==classroot and Path(argv[11]).resolve()==classroot and Path(argv[12]).resolve()==cwd,'generated runtime argv isolation/root/cwd mismatch')
        need(row.get('application_classpath')==[str(driverclass)] and not list(cwd.iterdir()),'generated runtime app classpath/cwd mismatch')
        parsed=runtime_rows(row,by,f'generated {key}'); match=observed_projection(parsed)==observed_projection(base)
        need(row.get('case_match') is match and row.get('combined_match') is match and row.get('matches_original_oracle') is match,f'generated semantic match flag differs from independent comparison {key}')
        need(match,f'generated runtime differs from original oracle {key}')
    wrong=x.get('generated_wrong_root_controls',[]); wrong_by={(r.get('kind'),r.get('profile'),r.get('form'),r.get('evidence'),r.get('compiler')):r for r in wrong}
    need(len(wrong)==20 and len(expected_wrong)==20 and set(wrong_by)==expected_wrong,'generated 20-build wrong-root matrix incomplete')
    for key,row in wrong_by.items():
        c=by[row['command']]; need(c['label']==f'wrong-root-{key[0]}-{key[1]}-{key[2]}-{key[3]}-{key[4]}' and c['exit_code']==1 and row.get('exit_code')==1,'wrong-root command label/exit mismatch')
        argv=c['argv']; cwd=Path(argv[4]).resolve(); empty=Path(x['empty_classpath']).resolve(); driverclass=Path(x['driver_classes'][0]['path']).resolve().parent; rootpath=Path(compile_by[key]['class_root']).resolve(strict=True); jdk=x['jdk_manifest']['tools']['javac23']; java=jdk['java']['path']
        need(argv[1:4]==['-B',str(Path(x['runtime_wrapper']['path']).resolve()),'30'] and Path(argv[5]).resolve()==Path(java).resolve() and argv[6:10]==['-Xverify:all','-cp',str(driverclass),DRIVER] and len(argv)==13 and Path(argv[10]).resolve()==rootpath and Path(argv[11]).resolve()==empty and Path(argv[12]).resolve()==cwd,'wrong-root argv mismatch')
        err=verify_raw(c,'stderr',f'wrong root {key}'); need(b'wrong CodeSource:' in err and row.get('rejected') is True,'wrong-root raw output does not prove CodeSource rejection')
        need(not list(cwd.iterdir()),f'wrong-root cwd not empty {key}')
    # Original wrong-root control and all labels/raw rows are independently accounted for.
    wrongrow=x.get('wrong_root_control'); need(isinstance(wrongrow,dict),'original wrong-root record missing'); c=by[wrongrow['command']]; argv=c['argv']; actual=Path(wrongrow['actual_target_root']).resolve(strict=True); empty=Path(x['empty_classpath']).resolve(); cwd=Path(argv[4]).resolve(); jdk=x['jdk_manifest']['tools']['javac23']; java=jdk['java']['path']; driverclass=Path(x['driver_classes'][0]['path']).resolve().parent
    need(c['label']=='driver-code-source-wrong-root-control' and c['exit_code']==1 and len(argv)==13 and argv[6:10]==['-Xverify:all','-cp',str(driverclass),DRIVER] and Path(argv[5]).resolve()==Path(java).resolve() and Path(argv[10]).resolve()==actual and Path(argv[11]).resolve()==empty and Path(argv[12]).resolve()==cwd,'original wrong-root argv mismatch')
    need(Path(wrongrow['actual_target_root']).resolve()==source_roots['debug'] and Path(wrongrow['expected_wrong_root']).resolve()==empty,'original wrong-root target/empty-root mismatch')
    need(b'wrong CodeSource:' in verify_raw(c,'stderr','original wrong root') and wrongrow.get('rejected') is True,'original wrong-root evidence mismatch')
    # Command label multiset is derived from the evidence grids; no unrecognized command/raw records pass silently.
    expected_labels.update({f'javac8-original-runtime-{p}-{r}':1 for p in PROFILES for r in RUNTIMES})
    expected_labels['jadx-full-bundle-debug-default']+=1; expected_labels['jadx-full-bundle-no-debug-default']+=1
    for p in PROFILES:
        for form in FORMS:
            for ev in EVIDENCE: expected_labels[f'jarde-{p}-target-{form}-{ev}']+=1
    for key in expected_compile: expected_labels[f'rebuild-{key[0]}-{key[1]}-{key[2]}-{key[3]}-{key[4]}']+=1
    for key in expected_runtime: expected_labels[f'runtime-{key[0]}-{key[1]}-{key[2]}-{key[3]}-{key[4]}-{key[5]}']+=1
    for key in expected_wrong: expected_labels[f'wrong-root-{key[0]}-{key[1]}-{key[2]}-{key[3]}-{key[4]}']+=1
    versioncmd=next((c for c in commands if c.get('label')=='jadx-version'),None); need(versioncmd is not None and versioncmd['argv']==[str(Path(x['jadx']['path']).resolve()),'--version'] and versioncmd['exit_code']==0,'JADX version command mismatch')
    versionout=verify_raw(versioncmd,'stdout','JADX version')+verify_raw(versioncmd,'stderr','JADX version stderr'); need(b'1.5.6' in versionout,'JADX version output is not pinned version')
    actual_labels=Counter(c.get('label') for c in commands)
    need(actual_labels==expected_labels,f'command label multiset differs from derived exact plan: expected {sum(expected_labels.values())}, got {sum(actual_labels.values())}')
    need(len(commands)==sum(expected_labels.values()) and len(rawpaths)==2*len(commands),'raw stream/command count derivation mismatch')
    derived_counts={'commands':len(commands),'raw_streams':len(rawpaths),'javac8_boundary':actual_labels['javac8-full-control-source-profile-debug'],'javac23_full_source_compiles':sum(n for label,n in actual_labels.items() if label.startswith('javac23-full-source-')),'driver_compiles':actual_labels['compile-independent-reflection-driver'],'original_runtime_runs':sum(n for label,n in actual_labels.items() if label.startswith('original-runtime-')),'wrong_root_runs':actual_labels['driver-code-source-wrong-root-control'],'generated_source_compiles':sum(n for label,n in actual_labels.items() if label.startswith('rebuild-')),'generated_runtime_runs':sum(n for label,n in actual_labels.items() if label.startswith('runtime-')),'generated_wrong_root_runs':sum(n for label,n in actual_labels.items() if label.startswith('wrong-root-')),'jarde_calls':sum(n for label,n in actual_labels.items() if label.startswith('jarde-')),'jadx_calls':sum(n for label,n in actual_labels.items() if label.startswith('jadx-'))}
    need(x.get('counts_derived_from_commands')==derived_counts,'collector command count summary differs from independently derived counts')
    # No class tree or source copy may mutate; check live bytes independently rather than trusting flags.
    need(x.get('target_absent_finally') is True and not (root/'target').exists() and not (root/'target').is_symlink(),'workspace target not absent')
    need(x.get('source_unchanged_finally') is True and x.get('external_inputs_unchanged') is True and x.get('local_copies_unchanged_finally') is True,'collector final immutability guard false')
    need(x.get('external_input_pins_before')==x.get('external_input_pins_after_finally'),'external input pin snapshots differ')
    need(x.get('source_pins_before')==x.get('source_pins_after_finally'),'workspace source pin snapshots differ')
    need(x.get('local_copy_pins_before')==x.get('local_copy_pins_after_finally'),'local copied tool/source snapshots differ')
    for record in x.get('external_input_pins_after_finally',{}).get('files',[]): pin(record,'external final input')
    def visit(v,label):
            if isinstance(v,dict):
                if {'path','bytes','sha256'}<=v.keys(): pin(v,label)
                else:
                    for k,z in v.items(): visit(z,label+'.'+k)
            elif isinstance(v,list):
                for i,z in enumerate(v): visit(z,f'{label}[{i}]')
    for key in ('source_pins_after_finally','local_copy_pins_after_finally','external_input_pins_after_finally'):
        value=x.get(key); need(value is not None,f'{key} missing'); visit(value,key)
    need(x.get('generated_outputs_unchanged',True) is True,'generated outputs immutability flag false')
    # Audit is passing only for a successfully closed collector; otherwise preserve failures as observations/errors.
    result={'schema':'prefixed-catch-retry-control-independent-audit-v3','status':'accepted_with_mapping_debt' if x.get('status')=='captured-pending-independent-review' and not errors else ('receipt_incomplete' if x.get('status')!='captured-pending-independent-review' else 'audit_failed'),
            'receipt':str(receipt_path),'receipt_sha256':sha(receipt_path),'collector':str(collector_source),'collector_sha256':a.collector_sha256,'collector_status':x.get('status'),'commands':len(commands),'raw_streams':len(rawpaths),
            'original_vm_cells':len(origmap),'jarde_api_cells':len(api),'generated_source_cells':len(cells),'generated_compiles':len(compiles),
            'generated_runtime_cells':len(gen),'generated_wrong_root_cells':len(wrong),'recomputed_map_count':sum(len(c.get('methods',[])) for c in api),
            'case_names':list(CASE_NAMES),'reference_only_pins':reference_only_pins,'mapping_debts':mapping_debts,'mapping_debt_scope':'Only run()V in the exact eight debug/no-debug x child/bundle-child x default/all Jarde API cells omits physical BCI 71: 40/41 mapped. All other methods require full physical coverage; all maps retain zero identity/physical issues.', 'errors':errors,'observations':observed}
    a.out.parent.mkdir(parents=True,exist_ok=True); a.out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'errors':len(errors),'commands':len(commands),'out':str(a.out)}))
    return 0 if result['status']=='accepted_with_mapping_debt' and not errors else 1
if __name__=='__main__':
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as exc:
        try:
            out=Path(sys.argv[sys.argv.index('--out')+1])
            if not out.exists():
                out.parent.mkdir(parents=True,exist_ok=True)
                out.write_text(json.dumps({'schema':'prefixed-catch-retry-control-independent-audit-v3','status':'audit_failed','error':repr(exc)},indent=2)+'\n',encoding='utf-8')
        except Exception:
            pass
        print(json.dumps({'status':'audit_failed','error':repr(exc)}),file=sys.stderr)
        raise SystemExit(1)
