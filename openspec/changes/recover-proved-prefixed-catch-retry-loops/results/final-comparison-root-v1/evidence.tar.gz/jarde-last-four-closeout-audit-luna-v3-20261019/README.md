# Final four source-map audit (independent, private)

This audit re-opened the closed Do2 v2, Do3 v1, Loop3 v1, and B-control v2 receipts, verified each physical class/JAR input pin, parsed the class-file Code instruction stream independently, and recomputed mapped BCIs from each API method's source-map origins. It checked all eight API cells per target across debug/no-debug, child/bundle-child, and default/all, and asserted mapping stability within each target.

Results are in `review.json`. Do2 maps are complete: `<init>` 3/3, `test()Ljava/lang/Object;` 15/15, `check` 45/45. Do3 maps are complete: `<init>` 3/3, `test` 10/10. Loop3 `writeMore` is 48/49, missing BCI 88; B `PrefixedRetryControl.run()` is 40/41, missing BCI 71. `focus-goto-review.json` independently reparses both instructions in all eight cells and confirms both are physical three-byte `goto` instructions (opcode `0xa7`), absent from the maps. These are source-map coverage debts, not semantic-failure conclusions.

The older B v1 32-VM audit remains in its original package and is not overwritten or treated as a full tri-party result. B v2 receipt path and all receipt/output hashes are recorded in `manifest.json`.
