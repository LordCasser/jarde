#!/usr/bin/env python3
"""Independent source-map vs physical class-file BCI audit; Python stdlib only."""
from pathlib import Path
import hashlib, json, struct, zipfile, io

RECEIPTS = {
    "loop3": Path("/private/tmp/jarde-last-four-final-loop3-root-v1-20261019/execution.json"),
    "do3": Path("/private/tmp/jarde-last-four-final-do3-root-v1-20261019/execution.json"),
    "B": Path("/private/tmp/jarde-last-four-final-retry-control-root-v1-20261019/execution.json"),
}

class Reader:
    def __init__(self, b): self.b, self.i = b, 0
    def take(self, n):
        if n < 0 or self.i+n > len(self.b): raise ValueError(f"truncated class at {self.i}, need {n}")
        x=self.b[self.i:self.i+n]; self.i+=n; return x
    def u1(self): return self.take(1)[0]
    def u2(self): return struct.unpack(">H",self.take(2))[0]
    def u4(self): return struct.unpack(">I",self.take(4))[0]

def class_methods(b):
    r=Reader(b)
    if r.u4()!=0xcafebabe: raise ValueError("bad class magic")
    r.u2(); r.u2(); n=r.u2(); cp=[None]*n; i=1
    while i<n:
        tag=r.u1()
        if tag==1:
            size=r.u2(); cp[i]=r.take(size).decode("utf-8");
        elif tag in (3,4): r.take(4)
        elif tag in (5,6): r.take(8); i+=1
        elif tag in (7,8,16,19,20): cp[i]=r.u2()
        elif tag in (9,10,11,12,17,18): r.take(4)
        elif tag==15: r.take(3)
        else: raise ValueError(f"unknown CP tag {tag}")
        i+=1
    r.take(6)
    for _ in range(r.u2()): r.u2()
    def skip_members():
        for _ in range(r.u2()):
            r.take(6)
            for _ in range(r.u2()): r.u2(); r.take(r.u4())
    skip_members()
    methods=[]
    for _ in range(r.u2()):
        access=r.u2(); name=cp[r.u2()]; desc=cp[r.u2()]; code=None
        for _ in range(r.u2()):
            attr=cp[r.u2()]; nbytes=r.u4(); data=r.take(nbytes)
            if attr=="Code":
                q=Reader(data); q.u2(); q.u2(); code=q.take(q.u4())
        ins=decode_instructions(code) if code is not None else None
        methods.append({"name":name,"descriptor":desc,"access_flags":access,"bci":[x["bci"] for x in ins] if ins is not None else None,"instructions":ins})
    return methods

OP_NAMES = {
  0x00:"nop",0x01:"aconst_null",0x02:"iconst_m1",0x03:"iconst_0",0x04:"iconst_1",0x05:"iconst_2",0x06:"iconst_3",0x07:"iconst_4",0x08:"iconst_5",
  0x09:"lconst_0",0x0a:"lconst_1",0x0b:"fconst_0",0x0c:"fconst_1",0x0d:"fconst_2",0x0e:"dconst_0",0x0f:"dconst_1",0x10:"bipush",0x11:"sipush",0x12:"ldc",0x13:"ldc_w",0x14:"ldc2_w",
  0x15:"iload",0x16:"lload",0x17:"fload",0x18:"dload",0x19:"aload",
  0x36:"istore",0x37:"lstore",0x38:"fstore",0x39:"dstore",0x3a:"astore",0x84:"iinc",
  0x99:"ifeq",0x9a:"ifne",0x9b:"iflt",0x9c:"ifge",0x9d:"ifgt",0x9e:"ifle",0x9f:"if_icmpeq",0xa0:"if_icmpne",0xa1:"if_icmplt",0xa2:"if_icmpge",0xa3:"if_icmpgt",0xa4:"if_icmple",0xa5:"if_acmpeq",0xa6:"if_acmpne",0xa7:"goto",0xa8:"jsr",0xa9:"ret",0xaa:"tableswitch",0xab:"lookupswitch",0xac:"ireturn",0xad:"lreturn",0xae:"freturn",0xaf:"dreturn",0xb0:"areturn",0xb1:"return",
  0xb2:"getstatic",0xb3:"putstatic",0xb4:"getfield",0xb5:"putfield",0xb6:"invokevirtual",0xb7:"invokespecial",0xb8:"invokestatic",0xb9:"invokeinterface",0xba:"invokedynamic",0xbb:"new",0xbc:"newarray",0xbd:"anewarray",0xbe:"arraylength",0xbf:"athrow",0xc0:"checkcast",0xc1:"instanceof",0xc2:"monitorenter",0xc3:"monitorexit",0xc4:"wide",0xc5:"multianewarray",0xc6:"ifnull",0xc7:"ifnonnull",0xc8:"goto_w",0xc9:"jsr_w"
}
for _base,_name in [(0x1a,"iload"),(0x1e,"lload"),(0x22,"fload"),(0x26,"dload"),(0x2a,"aload"),(0x3b,"istore"),(0x3f,"lstore"),(0x43,"fstore"),(0x47,"dstore"),(0x4b,"astore")]:
    for _i in range(4): OP_NAMES[_base+_i]=f"{_name}_{_i}"

def decode_instructions(code):
    if code is None: return []
    out=[]; pc=0; n=len(code)
    fixed={
      0x10:2,0x11:3,0x12:2,0x13:3,0x14:3,
      **{op:2 for op in range(0x15,0x1a)}, **{op:2 for op in range(0x36,0x3b)},
      0x84:3,0xa9:2, **{op:3 for op in range(0x99,0xa9)},
      **{op:3 for op in range(0xb2,0xb9)},0xb9:5,0xba:5,
      0xbb:3,0xbc:2,0xbd:3,0xc0:3,0xc1:3,0xc5:4,0xc6:3,0xc7:3,0xc8:5,0xc9:5,
    }
    while pc<n:
        start=pc; op=code[pc]; pc+=1
        if op==0xaa:
            pc += (4-(pc%4))%4
            if pc+12>n: raise ValueError("truncated tableswitch header")
            low=struct.unpack_from(">i",code,pc+4)[0]; high=struct.unpack_from(">i",code,pc+8)[0]
            if high<low: raise ValueError("invalid tableswitch range")
            pc += 12+4*(high-low+1)
        elif op==0xab:
            pc += (4-(pc%4))%4
            if pc+8>n: raise ValueError("truncated lookupswitch header")
            pairs=struct.unpack_from(">i",code,pc+4)[0]
            if pairs<0: raise ValueError("invalid lookupswitch count")
            pc += 8+8*pairs
        elif op==0xc4:
            if pc>=n: raise ValueError("truncated wide")
            nested=code[pc]; pc += 5 if nested==0x84 else 3
        else: pc += fixed.get(op,1)-1
        if pc>n: raise ValueError(f"instruction at {start} overruns Code length {n}")
        out.append({"bci":start,"opcode":op,"opcode_hex":f"0x{op:02x}","mnemonic":OP_NAMES.get(op,f"opcode_{op:02x}"),"length":pc-start})
    if pc!=n: raise ValueError("Code not ended at an instruction boundary")
    return out

def map_bcis(method):
    result=set()
    sm=method.get("source_map") or {}
    for seg in sm.get("segments",[]):
        origin=seg.get("origin") or {}
        primary=origin.get("primary") or {}
        bci=primary.get("bci")
        if isinstance(bci,int): result.add(bci)
        for derived in origin.get("derived",[]):
            bci=derived.get("bci")
            if isinstance(bci,int): result.add(bci)
    return sorted(result)

def sha(b): return hashlib.sha256(b).hexdigest()

def main():
    report={"schema":"last-four-independent-physical-source-map-audit-v1","receipts":{},"targets":{},"status":"passed"}
    for label,path in RECEIPTS.items():
        raw=path.read_bytes(); d=json.loads(raw)
        if not d.get("target_absent_finally", d.get("target_absent", False)): raise AssertionError(f"{label}: target cleanup not confirmed")
        report["receipts"][label]={"path":str(path),"bytes":len(raw),"sha256":sha(raw),"status":d.get("status"),"cell_count":len(d.get("jarde_cells",[]))}
        rows=[]
        for cell in d.get("jarde_cells",[]):
            inp=cell.get("input") or {}
            cp=Path(inp["path"]); artifact=cp.read_bytes()
            if len(artifact)!=inp["bytes"] or sha(artifact)!=inp["sha256"]: raise AssertionError(f"{label}: input artifact pin mismatch: {cp}")
            wanted={(m["name"],m["descriptor"]) for m in cell.get("methods",[])}
            if artifact[:4]==b"\xca\xfe\xba\xbe":
                data=artifact; class_entry=None
            else:
                candidates=[]
                first_method=(cell.get("methods") or [None])[0]
                location=(((first_method or {}).get("identity") or {}).get("owner") or {}).get("location") or {}
                entry_meta=location.get("entry") or {}
                raw_name=entry_meta.get("raw_name")
                wanted_entry=bytes(raw_name).decode("utf-8") if raw_name is not None else None
                with zipfile.ZipFile(io.BytesIO(artifact)) as z:
                    for entry in z.namelist():
                        if not entry.endswith(".class") or (wanted_entry is not None and entry!=wanted_entry): continue
                        candidate=z.read(entry)
                        try: methods=class_methods(candidate)
                        except Exception: continue
                        available={(x['name'],x['descriptor']) for x in methods}
                        if wanted.issubset(available): candidates.append((entry,candidate,methods))
                if len(candidates)!=1: raise AssertionError(f"{label}: expected one identity-bound class in bundle, got {[x[0] for x in candidates]}; wanted entry {wanted_entry!r}")
                class_entry,data,physical=candidates[0]
            if artifact[:4]==b"\xca\xfe\xba\xbe": physical=class_methods(data)
            inv={(m["name"],m["descriptor"]):m["bci"] for m in physical}
            for m in cell.get("methods",[]):
                key=(m["name"],m["descriptor"])
                if key not in inv: raise AssertionError(f"{label}: method absent from parsed class: {key}")
                phys=inv[key]; mapped=map_bcis(m)
                focus_bcis=(88,) if label=="loop3" and key==("writeMore","(Ljava/lang/String;)V") else ((71,) if label=="B" and key==("run","()V") else ())
                instruction_by_bci={x["bci"]:x for x in physical[[(x['name'],x['descriptor']) for x in physical].index(key)]["instructions"]}
                focus=[instruction_by_bci[bci] for bci in focus_bcis if bci in instruction_by_bci]
                rows.append({"profile":cell.get("profile"),"form":cell.get("input_form"),"evidence":cell.get("evidence"),"input":str(cp),"input_sha256":sha(artifact),"class_entry":class_entry,"class_sha256":sha(data),"method":m["name"],"descriptor":m["descriptor"],"physical_bcis":phys,"mapped_bcis":mapped,"unmapped_bcis":sorted(set(phys)-set(mapped)),"foreign_map_bcis":sorted(set(mapped)-set(phys)),"focus_physical_instructions":focus,"count_physical":len(phys),"count_mapped_physical":len(set(phys)&set(mapped)),"quality":m.get("quality"),"outcome":m.get("outcome_kind")})
        report["targets"][label]=rows
    expected={
      "loop3": {("writeMore","(Ljava/lang/String;)V"): [88]},
      "do3": {},
      "B": {("run","()V"): [71]},
    }
    for label, rows in report["targets"].items():
        for row in rows:
            key=(row["method"],row["descriptor"])
            missing=expected[label].get(key)
            if missing is not None and row["unmapped_bcis"]!=missing: raise AssertionError(f"{label} {key}: expected missing {missing}, got {row['unmapped_bcis']}")
            if row["foreign_map_bcis"]: raise AssertionError(f"{label} {key}: map invents physical BCIs {row['foreign_map_bcis']}")
    def summarize(label, method):
        rows=[r for r in report["targets"][label] if r["method"]==method]
        if not rows: return None
        inventory={(tuple(r['physical_bcis']),tuple(r['mapped_bcis']),tuple(r['unmapped_bcis'])) for r in rows}
        if len(inventory)!=1: raise AssertionError(f"{label} {method}: output maps vary across API cells")
        r=rows[0]
        return {"cells":len(rows),"physical":r['count_physical'],"mapped":r['count_mapped_physical'],"missing":r['unmapped_bcis'],"profiles":sorted({x['profile'] for x in rows}),"forms":sorted({x['form'] for x in rows}),"evidence":sorted({x['evidence'] for x in rows})}
    report["summary"]={
      "loop3": {name:summarize("loop3",name) for name in ["<init>","writeMore","prt","check"]},
      "do3": {name:summarize("do3",name) for name in ["<init>","test"]},
      "B": {name:summarize("B",name) for name in ["<init>","step","attempt","run"]},
    }
    expected_summary={
      "loop3":{"<init>":(8,8,[]),"writeMore":(49,48,[88]),"prt":(6,6,[]),"check":(10,10,[])},
      "do3":{"<init>":(3,3,[]),"test":(10,10,[])},
      "B":{"<init>":(8,8,[]),"step":(38,38,[]),"attempt":(46,46,[]),"run":(41,40,[71])},
    }
    for label,meths in expected_summary.items():
        for method,(physical,mapped,missing) in meths.items():
            got=report['summary'][label][method]
            if got is None or (got['physical'],got['mapped'],got['missing'])!=(physical,mapped,missing):
                raise AssertionError(f"{label} {method}: actual summary {got}")
    return report

if __name__=="__main__":
    import sys
    result=main()
    Path(sys.argv[1]).write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    print(json.dumps(result["summary"],indent=2,sort_keys=True))
