#!/usr/bin/env python3
"""Parameterized independent physical class-file/source-map audit; stdlib only."""
import argparse, importlib.util, json
from pathlib import Path

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("frozen_parser",HERE/"audit_mappings_v1_frozen.py")
parser=importlib.util.module_from_spec(spec); spec.loader.exec_module(parser)

def audit_one(label,path,expected=None):
    raw=path.read_bytes(); d=json.loads(raw)
    if not d.get("target_absent_finally",d.get("target_absent",False)):
        raise AssertionError(f"{label}: final target cleanup not confirmed")
    cells=d.get("jarde_cells")
    if not isinstance(cells,list) or not cells: raise AssertionError(f"{label}: no jarde_cells")
    receipt={"path":str(path),"bytes":len(raw),"sha256":parser.sha(raw),"status":d.get("status"),"cells":len(cells)}
    rows=[]
    for ci,cell in enumerate(cells):
        inp=cell.get("input") or {}; cp=Path(inp["path"]); artifact=cp.read_bytes()
        if len(artifact)!=inp["bytes"] or parser.sha(artifact)!=inp["sha256"]:
            raise AssertionError(f"{label}: cell {ci} input pin mismatch {cp}")
        methods=cell.get("methods") or []
        if not methods: raise AssertionError(f"{label}: cell {ci} has no methods")
        wanted={(m["name"],m["descriptor"]) for m in methods}
        class_entry=None
        if artifact[:4]==b"\xca\xfe\xba\xbe": data=artifact
        else:
            first=methods[0]
            owner=(((first.get("identity") or {}).get("owner") or {}).get("location") or {})
            raw_name=((owner.get("entry") or {}).get("raw_name"))
            wanted_entry=bytes(raw_name).decode("utf-8") if raw_name is not None else None
            candidates=[]
            import io,zipfile
            with zipfile.ZipFile(io.BytesIO(artifact)) as z:
                for entry in z.namelist():
                    if not entry.endswith(".class") or (wanted_entry and entry!=wanted_entry): continue
                    candidate=z.read(entry)
                    try: phys=parser.class_methods(candidate)
                    except Exception: continue
                    if wanted.issubset({(m['name'],m['descriptor']) for m in phys}):
                        candidates.append((entry,candidate,phys))
            if len(candidates)!=1: raise AssertionError(f"{label}: cell {ci} expected one identity-bound class, got {[x[0] for x in candidates]}")
            class_entry,data,physical=candidates[0]
        if artifact[:4]==b"\xca\xfe\xba\xbe": physical=parser.class_methods(data)
        pmap={(m['name'],m['descriptor']):m for m in physical}
        for method in methods:
            key=(method['name'],method['descriptor'])
            if key not in pmap: raise AssertionError(f"{label}: physical method missing {key}")
            phys=pmap[key]['bci']; mapped=parser.map_bcis(method)
            missing=sorted(set(phys)-set(mapped)); foreign=sorted(set(mapped)-set(phys))
            if foreign: raise AssertionError(f"{label} {key}: mapped non-physical BCIs {foreign}")
            rows.append({"cell":ci,"profile":cell.get("profile"),"form":cell.get("input_form"),"evidence":cell.get("evidence"),"input":str(cp),"input_sha256":parser.sha(artifact),"class_entry":class_entry,"class_sha256":parser.sha(data),"method":key[0],"descriptor":key[1],"physical_bcis":phys,"mapped_bcis":mapped,"missing_bcis":missing,"physical_count":len(phys),"mapped_physical_count":len(set(phys)&set(mapped)),"quality":method.get("quality"),"outcome":method.get("outcome_kind")})
    grouped={}
    for row in rows:
        key=(row['method'],row['descriptor']); grouped.setdefault(key,[]).append(row)
    summary={}
    for key,rs in sorted(grouped.items()):
        fingerprints={(tuple(x['physical_bcis']),tuple(x['mapped_bcis']),tuple(x['missing_bcis'])) for x in rs}
        if len(fingerprints)!=1: raise AssertionError(f"{label} {key}: mapping varies across cells")
        r=rs[0]
        summary[f"{key[0]}{key[1]}"]={"cells":len(rs),"physical":r['physical_count'],"mapped":r['mapped_physical_count'],"missing_bcis":r['missing_bcis'],"profiles":sorted({x['profile'] for x in rs}),"forms":sorted({x['form'] for x in rs}),"evidence":sorted({x['evidence'] for x in rs})}
    if expected is not None:
        for method_key,want in expected.items():
            got=summary.get(method_key)
            if got is None or got['physical']!=want['physical'] or got['mapped']!=want['mapped'] or got['missing_bcis']!=want['missing_bcis']:
                raise AssertionError(f"{label} {method_key}: expected {want}, got {got}")
    return receipt,rows,summary

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--receipt',action='append',required=True,help='LABEL=/absolute/path/execution.json; repeatable')
    ap.add_argument('--expected-json',help='optional JSON object mapping labels to method-key summary assertions')
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    expected=json.loads(Path(args.expected_json).read_text()) if args.expected_json else {}
    result={'schema':'parameterized-independent-physical-source-map-audit-v2','status':'passed','receipts':{},'summary':{},'rows':{}}
    labels=set()
    for pair in args.receipt:
        if '=' not in pair: ap.error('--receipt must be LABEL=PATH')
        label,path=pair.split('=',1)
        if label in labels: ap.error(f'duplicate label {label}')
        labels.add(label)
        receipt,rows,summary=audit_one(label,Path(path),expected.get(label))
        result['receipts'][label]=receipt; result['summary'][label]=summary; result['rows'][label]=rows
    Path(args.out).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result['summary'],indent=2,sort_keys=True))

if __name__=='__main__': main()
