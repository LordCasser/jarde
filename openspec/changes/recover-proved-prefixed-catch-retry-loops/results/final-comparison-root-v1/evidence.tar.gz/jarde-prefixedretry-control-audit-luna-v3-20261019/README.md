# PrefixedRetryControl independent audit v3

This is a new, frozen adapter for the closed root-v3 receipt; v2 remains unchanged and its failure remains in the history below.

Changes preserve strict verification while matching the captured schema: the three Loop2 provenance inputs are independently rehashed against the frozen tool pins but are not required to appear in this run’s execution-time external input list, because this collector did not use them as run tools. The actual B collector is still required to match the caller-supplied `--collector` path/SHA, the receipt external input pin, and the archived `collector.py` copy. All remaining frozen runtime tools still must appear in the execution-time input snapshot.

The raw map audit confirms a bounded existing debt: exactly the eight `run()V` API cells have BCI 71 as the sole missing physical map entry (40/41); every other method must map every physical BCI, and all methods retain strict zero-issue identity/physical checks. The report status is `accepted_with_mapping_debt`.

Replay against the already-closed receipt:

```sh
python3 -B /private/tmp/jarde-prefixedretry-control-audit-luna-v3-20261019/audit_control_v3.py \
  --receipt /private/tmp/jarde-last-four-final-retry-control-root-v1-20261019/execution.json \
  --collector /private/tmp/jarde-prefixedretry-control-tools-root-v3-20261019/collect_control.py \
  --collector-sha256 90a594e426187467688eff466d99e8e90015207746e4d24a7f62312515b08768 \
  --out /private/tmp/jarde-last-four-retry-control-independent-audit-luna-v3-20261019.json
```

## Preserved v2 failure

The frozen v2 auditor stopped because it required the three Loop2 provenance-only tool pins to also occur in this receipt’s external input snapshot. It did not reach a conclusion on the B control run. This v3 records those provenance pins independently and distinguishes them from actual run dependencies.
