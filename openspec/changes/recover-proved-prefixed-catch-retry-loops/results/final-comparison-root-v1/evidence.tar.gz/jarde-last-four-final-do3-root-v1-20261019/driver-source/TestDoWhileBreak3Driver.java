import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.StringWriter;
import java.io.PrintWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/** Bounded observations of complete TestDoWhileBreak3$TestCls; JUnit outer test is not invoked. */
public final class TestDoWhileBreak3Driver {
    private static final String TARGET = "jadx.tests.integration.loops.TestDoWhileBreak3$TestCls";
    private static final String[] NAMES = {
        "empty-break", "null-first-tail", "one-nonnull-exhausted", "two-nonnull-exhausted",
        "nonnull-null-tail", "null-iterator", "hasnext-throws-first", "next-throws-first",
        "hasnext-throws-second", "next-throws-second"
    };
    private static final String[] PLANS = {
        "values=[]", "values=[null,tail]", "values=[alpha]", "values=[alpha,beta]",
        "values=[alpha,null,tail]", "iterator=null", "throw=hasNext#1", "throw=next#1",
        "values=[alpha,tail];throw=hasNext#2", "values=[alpha,beta];throw=next#2"
    };

    private static String b64(String text) {
        return Base64.getEncoder().encodeToString(text.getBytes(StandardCharsets.UTF_8));
    }
    private static String value(String v) { return v == null ? "<NULL>" : v; }
    private static String stack(Throwable t) {
        StringWriter w = new StringWriter(); t.printStackTrace(new PrintWriter(w)); return w.toString();
    }
    private static void requireEmptyCwd(String expected) throws Exception {
        String actual = Paths.get(".").toRealPath().toString();
        if (!actual.equals(expected)) throw new IllegalStateException("unexpected JVM cwd: expected=" + expected + " actual=" + actual);
        String[] entries = new java.io.File(".").list();
        if (entries == null || entries.length != 0) throw new IllegalStateException("JVM cwd is not empty");
    }
    private static final class ProbeIterator implements Iterator<String> {
        private final String[] values;
        private final int failHasNextAt;
        private final int failNextAt;
        private final List<String> events = new ArrayList<String>();
        private int cursor;
        private int hasNextCalls;
        private int nextCalls;
        ProbeIterator(String[] values, int failHasNextAt, int failNextAt) {
            this.values = values; this.failHasNextAt = failHasNextAt; this.failNextAt = failNextAt;
        }
        public boolean hasNext() {
            hasNextCalls++;
            if (hasNextCalls == failHasNextAt) { events.add("hasNext#" + hasNextCalls + "=throw"); throw new IllegalStateException("probe.hasNext." + hasNextCalls); }
            boolean result = cursor < values.length;
            events.add("hasNext#" + hasNextCalls + "=" + result);
            return result;
        }
        public String next() {
            nextCalls++;
            if (nextCalls == failNextAt) { events.add("next#" + nextCalls + "=throw"); throw new IllegalStateException("probe.next." + nextCalls); }
            if (cursor >= values.length) { events.add("next#" + nextCalls + "=throw-no-such-element"); throw new java.util.NoSuchElementException(); }
            String result = values[cursor++];
            events.add("next#" + nextCalls + "=" + value(result));
            return result;
        }
        String eventTrace() { return join(events); }
        String remaining() {
            List<String> rest = new ArrayList<String>();
            for (int i = cursor; i < values.length; i++) rest.add(value(values[i]));
            return join(rest);
        }
        static String join(List<String> items) {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < items.size(); i++) { if (i > 0) b.append('|'); b.append(items.get(i)); }
            return b.toString();
        }
    }
    private static ProbeIterator iteratorFor(int index) {
        switch (index) {
            case 0: return new ProbeIterator(new String[0], 0, 0);
            case 1: return new ProbeIterator(new String[] {null, "tail"}, 0, 0);
            case 2: return new ProbeIterator(new String[] {"alpha"}, 0, 0);
            case 3: return new ProbeIterator(new String[] {"alpha", "beta"}, 0, 0);
            case 4: return new ProbeIterator(new String[] {"alpha", null, "tail"}, 0, 0);
            case 5: return null;
            case 6: return new ProbeIterator(new String[] {"alpha"}, 1, 0);
            case 7: return new ProbeIterator(new String[] {"alpha"}, 0, 1);
            case 8: return new ProbeIterator(new String[] {"alpha", "tail"}, 2, 0);
            case 9: return new ProbeIterator(new String[] {"alpha", "beta"}, 0, 2);
            default: throw new IllegalArgumentException("bad case index " + index);
        }
    }
    private static URL[] targetUrls(String actual) throws Exception {
        return new URL[] {Paths.get(actual).toUri().toURL()};
    }
    private static String codesource(Class<?> type) throws Exception {
        CodeSource source = type.getProtectionDomain().getCodeSource();
        if (source == null || source.getLocation() == null) throw new IllegalStateException("target has no CodeSource");
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }
    private static void requireInventory(Class<?> target) throws Exception {
        if (!Modifier.isPublic(target.getModifiers())) throw new IllegalStateException("target class is not public");
        Set<String> methods = new TreeSet<String>();
        for (Method m : target.getDeclaredMethods()) methods.add(m.getName() + ":" + m.getParameterTypes().length + ":" + m.getReturnType().getName());
        if (!methods.equals(java.util.Collections.singleton("test:0:void"))) throw new IllegalStateException("target method inventory differs: " + methods);
        Set<String> fields = new TreeSet<String>();
        for (Field f : target.getDeclaredFields()) fields.add(f.getName() + ":" + f.getType().getName() + ":" + Modifier.toString(f.getModifiers()));
        if (!fields.equals(java.util.Collections.singleton("it:java.util.Iterator:"))) throw new IllegalStateException("target field inventory differs: " + fields);
        Constructor<?> ctor = target.getDeclaredConstructor();
        if (!Modifier.isPublic(ctor.getModifiers())) throw new IllegalStateException("target constructor is not public");
        try { target.getDeclaredMethod("check"); throw new IllegalStateException("unexpected check() method in target"); }
        catch (NoSuchMethodException expected) { /* Source has no target check(). */ }
    }
    private static void observe(Class<?> target, Object receiver, Field field, Method test, int index) throws Exception {
        ProbeIterator probe = iteratorFor(index); field.set(receiver, probe);
        PrintStream previous = System.out; ByteArrayOutputStream captured = new ByteArrayOutputStream();
        PrintStream targetOut = new PrintStream(captured, true, "UTF-8"); Throwable cause = null; String result = "<not-returned>";
        try {
            System.setOut(targetOut);
            try { test.invoke(receiver); result = "return=void"; }
            catch (InvocationTargetException e) { cause = e.getCause(); }
        } finally { targetOut.flush(); System.setOut(previous); targetOut.close(); }
        String trace = probe == null ? "" : probe.eventTrace();
        String remaining = probe == null ? "" : probe.remaining();
        int hasNext = probe == null ? 0 : probe.hasNextCalls;
        int next = probe == null ? 0 : probe.nextCalls;
        System.out.println("CASE index=" + index + " name=" + NAMES[index] + " plan_b64=" + b64(PLANS[index])
            + " result_b64=" + b64(result) + " exception=" + (cause == null ? "none" : cause.getClass().getName())
            + " exception_message_b64=" + b64(cause == null || cause.getMessage() == null ? "" : cause.getMessage())
            + " exception_stack_b64=" + b64(cause == null ? "" : stack(cause))
            + " target_stdout_b64=" + b64(new String(captured.toByteArray(), StandardCharsets.UTF_8))
            + " has_next_calls=" + hasNext + " next_calls=" + next
            + " event_trace_b64=" + b64(trace) + " remaining_b64=" + b64(remaining));
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 3) throw new IllegalArgumentException("usage: TestDoWhileBreak3Driver actualRoot expectedRoot emptyWorkingDirectory");
        String actual = Paths.get(args[0]).toRealPath().toString();
        String expected = Paths.get(args[1]).toRealPath().toString();
        String cwd = Paths.get(args[2]).toRealPath().toString(); requireEmptyCwd(cwd);
        try (URLClassLoader loader = new URLClassLoader(targetUrls(actual), null)) {
            Class<?> target = Class.forName(TARGET, true, loader);
            if (target.getClassLoader() != loader) throw new IllegalStateException("target did not load from parentless loader");
            String origin = codesource(target);
            if (!origin.equals(expected)) throw new IllegalStateException("wrong CodeSource: expected=" + expected + " actual=" + origin);
            requireInventory(target);
            Object receiver = target.getDeclaredConstructor().newInstance();
            Field it = target.getDeclaredField("it"); it.setAccessible(true);
            if (it.getType() != Iterator.class) throw new IllegalStateException("it is not java.util.Iterator");
            Method test = target.getDeclaredMethod("test");
            if (!Modifier.isPublic(test.getModifiers()) || Modifier.isStatic(test.getModifiers()) || test.getReturnType() != void.class)
                throw new IllegalStateException("test() does not have expected public instance void shape");
            for (int i = 0; i < NAMES.length; i++) observe(target, receiver, it, test, i);
            requireEmptyCwd(cwd);
        }
    }
}
