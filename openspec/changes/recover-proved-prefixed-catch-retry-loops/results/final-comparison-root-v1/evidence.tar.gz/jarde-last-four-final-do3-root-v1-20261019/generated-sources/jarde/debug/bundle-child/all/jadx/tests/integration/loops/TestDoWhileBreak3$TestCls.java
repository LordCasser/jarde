// jarde: presentation of `jadx/tests/integration/loops/TestDoWhileBreak3$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestDoWhileBreak3$TestCls extends java.lang.Object {
    // jarde: field Signature projection refused for `itLjava/util/Iterator;`: unsupported (field_generic_source_unproved): field name, flags, descriptor, or type-use annotation path cannot be preserved
    java.util.Iterator it;

    public TestDoWhileBreak3$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestDoWhileBreak3$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public void test() {
        // @method test()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestDoWhileBreak3$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        do {
            if (!this.it.hasNext()) {
                break;
            }
        } while (this.it.next() != null);
        return;
    }
}
