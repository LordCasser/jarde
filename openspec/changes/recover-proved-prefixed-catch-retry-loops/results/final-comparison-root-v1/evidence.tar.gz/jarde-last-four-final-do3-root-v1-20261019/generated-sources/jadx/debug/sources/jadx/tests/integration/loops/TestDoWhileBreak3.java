package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import java.util.Iterator;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestDoWhileBreak3.class */
public class TestDoWhileBreak3 extends IntegrationTest {

    /* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestDoWhileBreak3$TestCls.class */
    public static class TestCls {
        Iterator<String> it;

        public void test() {
            while (this.it.hasNext() && this.it.next() != null) {
            }
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("while").containsLines(2, new String[]{"while (this.it.hasNext() && this.it.next() != null) {", "}"});
    }
}
