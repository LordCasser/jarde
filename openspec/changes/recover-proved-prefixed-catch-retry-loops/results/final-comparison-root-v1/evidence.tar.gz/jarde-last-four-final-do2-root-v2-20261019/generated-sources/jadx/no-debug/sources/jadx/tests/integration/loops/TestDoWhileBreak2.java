package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import java.util.Arrays;
import java.util.Iterator;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestDoWhileBreak2.class */
public class TestDoWhileBreak2 extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestDoWhileBreak2$TestCls.class */
    public static class TestCls {
        Iterator<String> it;

        public Object test() {
            String next;
            do {
                next = this.it.next();
                if (next == null) {
                    return next;
                }
            } while (this.it.hasNext());
            return next;
        }

        public void check() {
            this.it = Arrays.asList("a", "b").iterator();
            JadxAssertions.assertThat(test()).isEqualTo("b");
            this.it = Arrays.asList("a", "b", null).iterator();
            JadxAssertions.assertThat(test()).isEqualTo((Object) null);
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsLine(2, "do {").containsLine(3, "obj = this.it.next();").containsLine(3, "if (obj == null) {").containsLine(2, "} while (this.it.hasNext());");
    }
}
