# Loop3 independent auditor v7

This version fixes a local adapter omission: the compile summary now derives `upstream_compile` from the closed receipt before checking the unchanged 3-row original source compiler matrix (one Java 8 framework boundary and two Java 23 profile compiles). The exact BCI 88 mapping-debt scope and CASE/CHECK projection checks remain unchanged.

Prior v6 reached compiler-matrix processing after passing raw stream, class/API, explicit mapping-debt, CASE/CHECK, and runtime checks, then raised `NameError` because that local list had not been initialized.

Replay:

```sh
python3 -B /private/tmp/jarde-breakinloop3-independent-review-luna-v7-20261019/audit.py \
  --receipt /private/tmp/jarde-last-four-final-loop3-root-v1-20261019/execution.json \
  --cli /private/tmp/jarde-last-four-final-static-build-root-v2-20261019/candidate-cli \
  --cli-sha256 ed74e005c1bc97bcdf4a15f6a27da9e9d8a1ecdf7fe576836820ed2ce323222d \
  --out /private/tmp/jarde-last-four-loop3-independent-audit-luna-v7-20261019
```
