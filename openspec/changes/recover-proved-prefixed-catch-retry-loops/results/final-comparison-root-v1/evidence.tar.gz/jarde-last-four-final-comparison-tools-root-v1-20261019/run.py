from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,sys
cli=Path(sys.argv[1]).resolve(strict=True);digest=sys.argv[2]
assert hashlib.sha256(cli.read_bytes()).hexdigest()==digest
root=Path('/Users/lordcasser/workspace/projects/jarde');assert not(root/'target').exists()
base=Path(__file__).resolve().parent;assert not(base/'execution.json').exists()
launcher=Path('/private/tmp/jarde-last-four-final-launch-tools-root-v1-20261019/launch.py')
plans=[
 ('do2','/private/tmp/jarde-do2-final-controls-tools-root-v2-20261019/collect_control.py'),
 ('loop3','/private/tmp/jarde-breakinloop36-baseline-prepare-luna-v2-20261019/loop3/collect_baseline.py'),
 ('do3','/private/tmp/jarde-dowhilebreak3-baseline-prepare-luna-v2-20261019/collect_baseline.py'),
 ('retry-control','/private/tmp/jarde-prefixedretry-control-tools-root-v3-20261019/collect_control.py')]
rows=[]
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def run(plan):
 label,col=plan;out=Path('/private/tmp/jarde-last-four-final-'+label+'-root-v1-20261019');launch=Path(str(out)+'-launch');assert not out.exists() and not launch.exists()
 argv=[sys.executable,'-B',str(launcher),col,str(out),str(launch),str(cli),digest]
 with (base/(label+'.stdout.raw')).open('xb') as a,(base/(label+'.stderr.raw')).open('xb') as b:r=subprocess.run(argv,cwd=root,stdout=a,stderr=b)
 return {'label':label,'argv':argv,'exit_code':r.returncode,'streams':{ch:pin(base/(label+'.'+ch+'.raw')) for ch in ['stdout','stderr']},'launch_receipt':pin(launch/'execution.json')}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for future in concurrent.futures.as_completed([pool.submit(run,p) for p in plans]):
  row=future.result();rows.append(row);print(json.dumps({'closed':row['label'],'exit_code':row['exit_code']}),flush=True)
record={'status':'closed','parallel_read_only_collectors':4,'cli':pin(cli),'commands':rows,'target_absent':not(root/'target').exists()}
(base/'execution.json').write_text(json.dumps(record,indent=2)+'\n');raise SystemExit(0 if all(r['exit_code']==0 for r in rows) and record['target_absent'] else 1)
