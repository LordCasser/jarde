# Loop3 final independent audit adapter

This package adapts the closed Loop3 raw-stream auditor to an explicitly selected final receipt and candidate CLI. It independently reopens every recorded stdout/stderr stream, the complete source/class snapshots, API payloads and physical maps, CASE/CHECK observations, compiler outputs, runtime roots and CodeSource negative controls. Generated compile and VM totals are derived from the receipt’s actual compile eligibility; no old candidate’s fixed failure count is assumed.

Replay after the root has closed a new collector run:

```sh
python3 -B /private/tmp/jarde-breakinloop3-independent-review-luna-v2-20261019/audit.py \
  --receipt /absolute/path/to/closed/execution.json \
  --cli /absolute/path/to/candidate-cli \
  --cli-sha256 ACTUAL_CLI_SHA256 \
  --out /private/tmp/new-empty-loop3-audit-output
```

The output directory must be new or empty. The audit does not run compilers, JVMs, Jarde, or JADX. A closed receipt is required before replay.
