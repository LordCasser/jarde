import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.Base64;

/** Isolated finite executor for PrefixedRetryControl; no files are created. */
public final class PrefixedRetryControlDriver {
    private static final String TARGET = "PrefixedRetryControl";
    private static final class Case {
        final String name; final int failures; final boolean exists; final String throwAt;
        Case(String n, int f, boolean e, String t) { name=n; failures=f; exists=e; throwAt=t; }
    }
    private static final Case[] CASES = {
        new Case("normal-success", 0, false, ""),
        new Case("retry-then-success", 1, false, ""),
        new Case("second-failure-left", 2, true, ""),
        new Case("second-failure-right", 2, false, ""),
        new Case("prefix-throws", 0, false, "prefix"),
        new Case("retry-step-throws", 1, false, "retry"),
        new Case("left-step-throws", 2, true, "left"),
        new Case("right-step-throws", 2, false, "right"),
        new Case("join-step-throws", 2, false, "join"),
        new Case("tail-step-throws", 0, false, "tail")
    };
    private static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static String stack(Throwable t) { StringWriter s=new StringWriter(); t.printStackTrace(new PrintWriter(s)); return s.toString(); }
    private static String origin(Class<?> c) throws Exception {
        CodeSource s=c.getProtectionDomain().getCodeSource();
        if(s==null||s.getLocation()==null) throw new IllegalStateException("missing CodeSource");
        return Paths.get(s.getLocation().toURI()).toRealPath().toString();
    }
    private static void emptyCwd(String expected) throws Exception {
        String actual=Paths.get(".").toRealPath().toString();
        if(!actual.equals(expected)) throw new IllegalStateException("cwd mismatch: "+actual);
        String[] entries=new java.io.File(".").list();
        if(entries==null||entries.length!=0) throw new IllegalStateException("cwd not empty");
    }
    private static void runOne(Case c,int i,Constructor<?> ctor,Method run,Field failures,Field exists,Field throwAt,Field trace,Field attempts,Field steps,String cwd,PrintStream out) throws Exception {
        emptyCwd(cwd); Object o=ctor.newInstance(); failures.setInt(o,c.failures); exists.setBoolean(o,c.exists); throwAt.set(o,c.throwAt);
        PrintStream old=System.out; ByteArrayOutputStream bytes=new ByteArrayOutputStream(); PrintStream capture=new PrintStream(bytes,true,"UTF-8"); Throwable cause=null;
        try { System.setOut(capture); try { run.invoke(o); } catch(InvocationTargetException e) { cause=e.getCause(); } }
        finally { capture.flush(); System.setOut(old); capture.close(); }
        String stdout=new String(bytes.toByteArray(),StandardCharsets.UTF_8); String traceValue=trace.get(o).toString();
        String events="trace="+traceValue+";attemptCalls="+attempts.getInt(o)+";stepCalls="+steps.getInt(o)+";failuresRemaining="+failures.getInt(o)+";exists="+exists.getBoolean(o);
        out.println("CASE index="+i+" name="+c.name+" input_b64="+b64(c.failures+","+c.exists+","+c.throwAt)+" result_b64="+b64(cause==null?"return=void":"<not-returned>")
          +" exception="+(cause==null?"none":cause.getClass().getName())+" exception_message_b64="+b64(cause==null?"":String.valueOf(cause.getMessage()))
          +" exception_stack_b64="+b64(cause==null?"":stack(cause))+" stdout_b64="+b64(stdout)+" after_b64="+b64(events));
        emptyCwd(cwd);
    }
    public static void main(String[] args) throws Exception {
        if(args.length<3) throw new IllegalArgumentException("usage: driver actualRoot expectedRoot emptyCwd [dependencyUrl ...]");
        String actual=Paths.get(args[0]).toRealPath().toString(), expected=Paths.get(args[1]).toRealPath().toString(), cwd=Paths.get(args[2]).toRealPath().toString(); emptyCwd(cwd);
        URL[] urls=new URL[args.length-2]; urls[0]=Paths.get(actual).toUri().toURL();
        for(int i=3;i<args.length;i++) urls[i-2]=Paths.get(args[i]).toUri().toURL();
        try(URLClassLoader loader=new URLClassLoader(urls,null)) {
            Class<?> target=Class.forName(TARGET,true,loader); if(target.getClassLoader()!=loader) throw new IllegalStateException("target loader mismatch");
            String actualOrigin=origin(target); if(!actualOrigin.equals(expected)) throw new IllegalStateException("wrong CodeSource: expected="+expected+" actual="+actualOrigin);
            Constructor<?> ctor=target.getDeclaredConstructor(); Method run=target.getDeclaredMethod("run");
            Field failures=target.getDeclaredField("failuresRemaining"), exists=target.getDeclaredField("exists"), throwAt=target.getDeclaredField("throwAt"), trace=target.getDeclaredField("trace"), attempts=target.getDeclaredField("attemptCalls"), steps=target.getDeclaredField("stepCalls");
            for(Field f:new Field[]{failures,exists,throwAt,trace,attempts,steps}) f.setAccessible(true); ctor.setAccessible(true); run.setAccessible(true);
            for(int i=0;i<CASES.length;i++) runOne(CASES[i],i,ctor,run,failures,exists,throwAt,trace,attempts,steps,cwd,System.out);
        }
    }
}
