/** Finite no-file control for prefixed retry and catch-completion behavior. */
public final class PrefixedRetryControl {
    public boolean exists;
    public int failuresRemaining;
    public String throwAt;
    public final StringBuilder trace = new StringBuilder();
    public int attemptCalls;
    public int stepCalls;

    public PrefixedRetryControl() { }

    private void step(String tag) {
        if (trace.length() != 0) trace.append('|');
        trace.append(tag);
        stepCalls++;
        if (tag.equals(throwAt)) throw new IllegalStateException("step." + tag);
    }

    private void attempt() {
        attemptCalls++;
        if (trace.length() != 0) trace.append('|');
        trace.append("attempt#").append(attemptCalls);
        if (failuresRemaining > 0) {
            failuresRemaining--;
            throw new IllegalStateException("attempt." + attemptCalls);
        }
    }

    public void run() {
        boolean tryMkdir = true;
        while (true) {
            step("prefix");
            try {
                attempt();
            } catch (Exception ex) {
                if (tryMkdir) {
                    tryMkdir = false;
                    step("retry");
                    continue;
                }
                step("caught");
                if (exists) {
                    step("left");
                } else {
                    step("right");
                }
                step("join");
            }
            step("after");
            break;
        }
        step("tail");
    }
}
