#!/usr/bin/env python3
"""Collect own-CI evidence with the frozen collector and added Loop4/5 source pins."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import common


def pair(spec: str):
    target, sep, test = spec.partition('=')
    if not sep or not target or not test or any(ch.isspace() for ch in target + test):
        raise argparse.ArgumentTypeError('expected TARGET=FULL_TEST_NAME without whitespace')
    return target, test


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence_dir')
    parser.add_argument('run_id')
    parser.add_argument('product_sha')
    parser.add_argument('cli_sha256')
    parser.add_argument('--source-file', action='append', default=[])
    parser.add_argument('--fixture-root', action='append', default=[])
    parser.add_argument('--supplemental-gate', action='append', default=[], type=lambda s: pair(s))
    args = parser.parse_args()
    old = common.load_pinned('collect-own-ci.py', 'loop45_frozen_ci_collector')
    inventory = common.extend_ci_inventory(old, args.source_file, args.fixture_root)
    if Path(args.evidence_dir).exists():
        raise SystemExit('evidence directory must be fresh; frozen collector creates it')
    sidecar = Path(args.evidence_dir) / 'final-adapter-inputs.json'
    if sidecar.exists(): raise SystemExit('refusing existing final-adapter-inputs.json')
    sys.argv = [str(common.BASE / 'collect-own-ci.py'), args.evidence_dir,
                args.run_id, args.product_sha, args.cli_sha256]
    status = int(old.main())
    if status != 0: return status
    sidecar.write_text(json.dumps({'schema':'jarde-final-ci-adapter-inputs-v1','run_id':args.run_id,'product_sha':args.product_sha,'cli_sha256':args.cli_sha256,'source_files':inventory['supplemental_source_files'],'fixture_roots':inventory['supplemental_fixture_roots'],'supplemental_gates':[{'target':t,'test':n} for t,n in args.supplemental_gate]},indent=2)+'\n',encoding='utf-8')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
