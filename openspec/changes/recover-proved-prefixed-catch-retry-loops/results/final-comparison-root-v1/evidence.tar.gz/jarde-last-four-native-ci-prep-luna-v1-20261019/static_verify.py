#!/usr/bin/env python3
"""Static-only closure and adapter checks; never runs product tools."""
from __future__ import annotations
import ast, hashlib, importlib.util, json, sys
from collections import Counter
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def need(ok, message):
    if not ok: raise SystemExit(message)
for name in ('common.py','verify-native-loop45.py','collect-own-ci-loop45.py','verify-own-ci-loop45.py','static_verify.py'):
    ast.parse((HERE/name).read_text(encoding='utf-8'), filename=name)
closure=json.loads((HERE/'source-tool-closure.json').read_text(encoding='utf-8'))
for row in closure['artifacts']:
    path=Path(row['path'])
    need(path.is_file() and not path.is_symlink(), f"missing/unsafe closure artifact: {path}")
    need(path.stat().st_size==row['bytes'] and sha(path)==row['sha256'], f"closure pin mismatch: {path}")
sys.path.insert(0,str(HERE))
import common
for rel,digest in common.BASE_PINS.items():
    path=common.BASE/rel
    need(path.is_file() and sha(path)==digest, f'frozen base pin mismatch: {rel}')
need(len(common.REGION_GATES)==11 and len(common.PUBLIC_GATES)==4 and len(common.DEFERRED_BUILDER_GATES)==3,
     'fixed Loop45 supplemental gate inventory changed')
old_native=common.load_pinned('verify-native.py','static_native')
need(len(old_native.CURRENT_GATES)==14, 'frozen inherited explicit native gate inventory is not 14')
review=json.loads(Path('/private/tmp/jarde-loop45-native-review-root-v1-20261019/review.json').read_text(encoding='utf-8'))
need(review.get('status')=='passed' and review.get('critical_gate_count')==96 and len(review.get('current_exact_gates',[]))==32, 'accepted Loop45 native baseline gate accounting changed')
argv=json.loads((common.BASE/'acceptance-argv.json').read_text(encoding='utf-8'))
extras=[argv['verify_ci'][i+1] for i,t in enumerate(argv['verify_ci'][:-1]) if t=='--extra-critical']
need(len(extras)==13, 'accepted inherited CI extra-critical inventory is not 13')
for rel in ('command-plan.json','acceptance-argv.json'):
    json.loads((HERE/rel).read_text(encoding='utf-8'))
plan=json.loads((HERE/'command-plan.json').read_text(encoding='utf-8'))
need(plan['preserved_gate_contract']['native_historical_accepted_critical_gate_count']==96,'native fixed count drift')
need(plan['preserved_gate_contract']['own_ci_historical_accepted_critical_gate_count']==141,'CI fixed count drift')
need('execution.json' in plan['product_binding']['native_input'], 'binder does not use execution.json')
need('review.json' in plan['product_binding']['prohibited_native_input'], 'binder review exclusion missing')
need(plan['product_binding']['command_template'][plan['product_binding']['command_template'].index('--native')+1] == plan['product_binding']['native_input'], 'binder does not bind runner receipt')
need('--native-review' not in plan['product_binding']['command_template'], 'invalid binder flag introduced')
verify_ci=(HERE/'verify-own-ci-loop45.py').read_text(encoding='utf-8')
for needle in ('Counter(triples)','compare_seed_counters','job_count','expanded_api_step_count'):
    need(needle in verify_ci, f'full-counter/API invariant missing: {needle}')
need("ci.get('job_count') != 4" in verify_ci and "ci.get('expanded_api_step_count') != 52" in verify_ci,
     'official API cardinality gate missing')
need('observed_counts' not in (HERE/'verify-native-loop45.py').read_text(encoding='utf-8'),
     'native adapter must not select from historical observed_counts')
spec=importlib.util.spec_from_file_location('static_ci_adapter',HERE/'verify-own-ci-loop45.py')
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
left=Counter({('jarde_java','a::passes','ok'):1,('jarde_java','b::ignored','ignored'):1})
right=Counter(left)
module.compare_seed_counters(left,right)
right[('jarde_java','c::fails','FAILED')]=1
try: module.compare_seed_counters(left,right)
except ValueError: pass
else: raise SystemExit('synthetic Counter mismatch was accepted')
print(json.dumps({'status':'static_pass','checked_closure_artifacts':len(closure['artifacts']),
                  'frozen_native_explicit_gates':len(old_native.CURRENT_GATES),'accepted_native_critical_total':review['critical_gate_count'],'accepted_native_explicit_total':len(review['current_exact_gates']),'fixed_ci_extra_gates':len(extras),
                  'loop45_added_gates':18,'preserved_native_total':96,'preserved_own_ci_total':141,
                  'synthetic_counter_equal_and_mismatch':'passed'},indent=2))
