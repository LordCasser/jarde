# Loop3 final independent auditor (frozen v4)

This version fixes the command-index origin check to match the collector's one-based command numbering. It otherwise preserves the frozen v3 audit gates and does not change any product, source, inventory, raw protocol, compiler, VM, map, wrong-root, or source-closure checks.

Replay the already closed receipt with:

```sh
python3 -B /private/tmp/jarde-breakinloop3-independent-review-luna-v4-20261019/audit.py \
  --receipt /private/tmp/jarde-last-four-final-loop3-root-v1-20261019/execution.json \
  --cli /private/tmp/jarde-last-four-final-static-build-root-v2-20261019/candidate-cli \
  --cli-sha256 ed74e005c1bc97bcdf4a15f6a27da9e9d8a1ecdf7fe576836820ed2ce323222d \
  --out /private/tmp/jarde-last-four-loop3-independent-audit-luna-v4-20261019
```

The v3 package remains immutable; this package is the corrected adapter for the closed final receipt.
