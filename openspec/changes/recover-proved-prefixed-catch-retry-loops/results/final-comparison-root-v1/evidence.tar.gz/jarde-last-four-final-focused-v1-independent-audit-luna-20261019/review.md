# Independent audit: final focused v1 and constructor probe

All 20 raw streams were reopened and their byte counts and SHA-256 pins matched: 14 streams from the seven-command final-focused receipt, two probe-wrapper streams, and four streams from the probe candidate run.

The final-focused receipt is **FAILED only at Clippy**. Its tests passed: 552 Java library tests, 9 CF12 tests, 1 Do2 public test, 2 Loop3 public tests, and 4 Loop4/5 public tests. Both Loop3 constructor-store unit tests and the older character-widening regression passed. Clippy reports one error: unused `jarde_reader::budget::Budget` at `tests/recover_do2_return_public.rs:4`. The 3,373-entry source closure is identical before and after, with no source changes; target cleanup succeeded.

The constructor-probe wrapper is `closed`, exited 0, reports `source_restored=true`, and confirms `target_absent=true`. Restored `build.rs` exactly matches `original-build.rs` (2,089,472 bytes, SHA-256 `81c2a0b7b0c24f6ca0f1b6803f0abb421c07d5f06284abd1eb43b9be592cc331`). The temporary instrumented candidate removes the protected-arm condition around the constructor single-use check and adds a test-only trace. Its nested run passes the two Loop3 public tests and cleans target; the run's source snapshot remains unchanged. This is diagnostic evidence, not acceptance of the permanent implementation.

`audit.json` contains command summaries, source/cleanup facts, all stream pins, and the resulting checks. The active v2 build was not inspected.
