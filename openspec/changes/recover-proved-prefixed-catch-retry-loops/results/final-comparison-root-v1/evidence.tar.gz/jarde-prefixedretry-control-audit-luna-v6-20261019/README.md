# Prefixed retry independent audit v6

This fresh adapter preserves v5's exact checks, including the required JADX `--rename-flags none` argv and full 20-build/40-VM/20-wrong-root matrices. It fixes a local-name collision: the API loop used `physical` for a method facts dictionary, shadowing the imported independent class parser module later used to reparse generated `.class` files. v5's failed execution remains recorded at the path in `pins.json`; no acceptance was claimed from it.

v6 attempt 1 reached the final live-workspace guard and failed because the concurrent native run recreated `target/`. The closed receipt itself reports `target_absent_finally=true`. The exact failure output and its context are pinned in `pins.json`. The auditor was not changed to bypass the current-workspace cleanliness gate. After native cleanup, rerun this same sealed auditor to a fresh output path:

```sh
python3 -B /private/tmp/jarde-prefixedretry-control-audit-luna-v6-20261019/audit_control_v6.py \
  --receipt /private/tmp/jarde-last-four-final-retry-control-root-v2-20261019/execution.json \
  --collector /private/tmp/jarde-prefixedretry-control-tools-luna-v4-20261019/collect_control.py \
  --collector-sha256 0d57ad5dae3a8494faedb5b0711b0c7bc42d55b7014b8f3a1352a116cdd198ff \
  --out <fresh-independent-audit-output.json>
```
