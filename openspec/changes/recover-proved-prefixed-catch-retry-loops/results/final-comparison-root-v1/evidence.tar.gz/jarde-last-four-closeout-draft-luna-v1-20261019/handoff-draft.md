# Final handoff draft — last four fixed originals

**Status: pending final comparison and final static/CI receipts.** The last four comparison executions were reported as running; they were not read here. This file is a fillable draft, not an acceptance statement.

## What the closed evidence already establishes

Loop4 and Loop5 have a durable accepted comparison and product CI for product `412245d514896b1d0eb9a8fe24388f6a70668637`, CLI SHA-256 `d29b6fee723d8f59fbecd9fd8be9f15a8ec73de3a90f5a2a29b24ff91e4af607`. Their saved native/CI audit records 394 targets, 3,841 pass, 0 fail, 98 pre-existing ignored; product CI records 4 jobs, 52 official steps, two seeds, 3,939 named outcomes per seed and equal full outcome Counters. The historical source maps are Loop4 23/23 and Loop5 59/60 (BCI 103 absent). Do not reuse these product pins as the final pin for the new Do2/Loop3 work.

The Loop3 original baseline is independently closed: source is 1,216 bytes; eight APIs report all three physical methods (`<init>`, `writeMore`, `check`) structured, while the body has `jre_region_ownership_overlap` at BCI 11. Full Jarde source recompilations were 0/16; JADX full outer+target source compiled with JDK 23 in both debug profiles, and four isolated VM runs matched the original builder `12135678` and actual `check()`. The JDK 8 full-source failures are pinned framework major 55/52 boundary results; they are not source semantic failures. The upstream `@NotYetImplemented`/disabled test status does not imply JADX fails: the actual complete JADX outputs compiled and ran successfully. The body’s new public recovery and constructor-placement gap has focused implementation evidence, but final overall acceptance still depends on the currently running final checks.

Do3 is a compatibility regression, not a proposed source feature. Its closed baseline independently records 94 commands/188 raw streams, 8 API cells, 18/20 generated compile successes (two JDK 8 framework-major failures), four original VM runs and 36 generated VM runs across the ten planned cases. The compiled original and generated sources had no semantic mismatches. No synthetic `check()` was added; the actual class has no `check` method. The field `it` has class-file Signature `Ljava/util/Iterator<Ljava/lang/String;>;`, but Jarde reports `field_generic_source_unproved` and emits raw `java.util.Iterator it;`; keep this as a separate generic-field projection debt. Keep that field typing as a separate debt. The current-product Do3 regression must still be filled below before using it to support 12/13 status.

Loop6 remains an explicit input support boundary. The exact original Smali input (1,216 bytes) was preserved; the installed JADX assembler produced a 788-byte Dex and JADX decoded both original Smali and Dex to the complete one-break source. Jarde rejected raw Smali and raw Dex as `unknown_artifact_kind`; a Dex-only ZIP was rejected for class-source with `operation_target_not_found`, and `list-classes` found zero candidates. This evidence does not authorize treating Java controls as the original input or claim Android Dex support. Keep the result as a documented boundary.

The independent source-map audit in this package adds separate debt rows: Loop3 `writeMore` 48/49 (missing physical BCI 88, `goto`), and B control `PrefixedRetryControl.run` 40/41 (missing physical BCI 71, `goto`). They are not collapsed into Loop5’s BCI 103 mapping gap, and none is described as a semantic behavior failure. Do3 `test` and `<init>` are 10/10 and 3/3.

## Final evidence to fill

| Gate | Receipt and review | Required accepted observation | Status |
|---|---|---|---|
| Do2 focused fix and original comparison | `[closed receipt]`; `[independent raw review]` | `[source, full API, cases, compile/runtime, wrong-root, maps, target cleanup]` | pending |
| Loop3 focused fix and original comparison | `[closed receipt]`; `[independent raw review]` | `[8 APIs, 20 compile attempts, successful VM/check cases, wrong-root, maps, profiles, raw pins]` | pending |
| Do3 current-product regression | `[closed receipt]`; `[independent raw review]` | `[exact cases and actual original/JADX/Jarde outcomes; preserve JDK8 framework boundary]` | pending |
| Loop6 input-boundary closeout | `[existing receipts/review]` | `[Smali/Dex/JADX/Jarde exact outcomes and no source conversion]` | closed baseline; final scope acknowledgment pending |
| Current full workspace/native | `[receipt path+SHA]`; `[verifier path+SHA]` | `[targets/batches/pass/fail/ignored; named critical gates; source pins; guard/default stack/cleanup]` | pending |
| Current product own CI | `[run id/URL]`; `[own-CI raw review]` | `[jobs/official steps/two seeds/full Counter and source binding]` | pending |
| Final source and CLI | product `[commit]`; CLI `[path, bytes, mode, SHA]` | `[full source binding, strict OpenSpec, clean main, remote equality, target absent]` | pending |

**Do not declare the 12 accepted + 1 boundary transition until all rows above have closed evidence.** Current final product `[SHA]`; current CLI `[SHA]`; own-CI run `[ID/URL]`; final comparison review `[path/SHA]`; final source-map set `[review path/SHA]`.

## Architecture and scope kept separate

Do2 repairs the proved branch-body ownership path; Loop3 repairs the prefixed named-catch retry topology and allows the already-verified pre-try constructor/store through the existing full SSA reaching-write contract. Neither path weakens final owner closure, rewrites exception edges as normal flow, or uses a fixture name/BCI as production recognition. The Do3 row exists to ensure the new control-flow work did not regress an already supported do-while transfer shape. Loop6 remains a front-end input boundary.

The unresolved generic `Iterator` field, the three source-map holes (Loop5 103, Loop3 88, B 71), and native receipt `observed_counts` misattribution are recorded separately. The native runner metadata associated 316 target items across 95 batches incorrectly; the running-bound verifier’s target/test/status results are authoritative. Do not merge the wrong embedded labels into actual test results or erase the archival raw.

Keep CF09 and the 71-unit / 612-file aggregate inventories `partial`; the native target inventory is not a success denominator. This closeout changes only the four fixed-original rows and does not claim general Smali/Dex support.
