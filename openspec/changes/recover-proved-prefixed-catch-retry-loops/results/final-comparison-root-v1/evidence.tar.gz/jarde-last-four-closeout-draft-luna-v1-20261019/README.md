# Last-four closeout draft (private, pending final receipts)

This package contains a private handoff/ledger draft and a read-only independent physical BCI audit. It does not modify OpenSpec or shared workspace files. The current final comparison receipts were deliberately not opened. Do not use this draft to mark the four remaining fixed-original outcomes complete.

## Independent source-map result

`audit_mappings.py` reparses the class-file Code attributes and instruction boundaries, then recomputes mapped BCIs from each `source_map` segment's primary and derived origins. It binds JAR inputs to the class named by the API's exact physical entry identity. It reopens all eight API cells for each closed receipt, checks profile/form/evidence consistency and verifies class/input pins. It reports three separate remaining mapping gaps:

- Loop3 `writeMore(Ljava/lang/String;)V`: 48/49 mapped, physical BCI 88 is absent from the map. The class parser decodes BCI 88 as `goto` (`0xa7`, length 3).
- `PrefixedRetryControl.run()V` (B control): 40/41 mapped, physical BCI 71 is absent from the map. The class parser decodes BCI 71 as `goto` (`0xa7`, length 3).
- Loop5 `test(Ljava/lang/String;)J`: existing archived comparison reports 59/60, BCI 103 absent. This is not shown to share a cause with either new gap.

The closed Do3 maps have no gap in this audit: `<init>()V` 3/3 and `test()V` 10/10 across eight cells. Loop3 `<init>` 8/8, `prt` 6/6, and `check` 10/10. B control `<init>` 8/8, `step` 38/38, and `attempt` 46/46. These are mapping facts only; do not infer that every later run or source-map cleanup is accepted. Full per-cell rows, input pins and parser output are in `mapping-review.json`.

## Handoff wording draft

Use `handoff-draft.md` only after filling the final matrix, product/CLI pins, independent audit paths, full workspace and own-CI run. It explicitly separates closed baseline facts and already-run focused gates from final acceptance.

## Ledger wording draft

`fixed-originals-ledger-draft.md` gives a conditional transition from 9/13 to 12 accepted + 1 input-boundary only if Do2, Loop3, and Do3 regression evidence all close. Loop6 remains an explicit Smali/Dex support boundary, not a Java surrogate or successful source recovery. It records three separate map gaps and the runner `observed_counts` binding debt.

## Sources read

- Loop4 and Loop5 durable OpenSpec result entry points under `openspec/changes/recover-proved-loop-break-branch-bodies/results/README.md` and `openspec/changes/recover-named-catch-loop-return-tails/results/README.md`; archived captures and historical acceptance remain intact.
- Loop3 closed baseline receipt and independent review: `/private/tmp/jarde-last-four-final-loop3-root-v1-20261019/execution.json`, `/private/tmp/jarde-breakinloop3-independent-review-luna-v1-20261019/review.json`; its exact original IR probe is archived under `/private/tmp/jarde-last-four-ir-independent-review-luna-v1-20261019/`.
- Do3 closed baseline receipt and independent review: `/private/tmp/jarde-last-four-final-do3-root-v1-20261019/execution.json`, `/private/tmp/jarde-last-four-final-do3-review-root-v1-20261019/review.json`.
- B control closed receipt: `/private/tmp/jarde-last-four-final-retry-control-root-v1-20261019/execution.json`.
- Loop6 closed boundary receipt and independent review: `/private/tmp/jarde-breakinloop6-boundary-root-v1-20261019/execution.json`, `/private/tmp/jarde-breakinloop6-independent-review-luna-v1-20261019/review.json`, plus inventory supplement.
- Last accepted Loop4/5 product acceptance is a historical baseline only: `/private/tmp/jarde-loop45-final-acceptance-root-v1-20261019/acceptance.json`. Its 9/13 count, product SHA and CI belong to that accepted product and must not be transferred to a later final product without fresh binding evidence.
