# Fixed-original ledger transition draft (not applied)

Current historical accepted state from the accepted Loop4/5 archive is **9/13**. No ledger edit is proposed before current final receipts are closed.

| Fixed original | Proposed status after evidence closes | Required evidence |
|---|---|---|
| Do2 | accepted | Current CLI full comparison + independent raw review; source binding; final regression set |
| Loop3 / TestBreakInLoop3 | accepted | Current CLI full comparison + independent raw review; actual `check()`; constructor placement; final regression set |
| Do3 / TestDoWhileBreak3 | accepted as a regression-compatible original | Current CLI comparison; all ten planned cases against original/JADX/Jarde; no mismatch; retain raw Iterator field note |
| Loop6 / TestBreakInLoop6 | input-boundary, not supported source recovery | Existing exact Smali/Dex receipt/review proves current Jarde rejects these inputs and JADX can decode; ledger must name the limitation, not mark a Java substitute as accepted source recovery |

If and only if the first three rows close, record **12 accepted / 13 fixed originals**, and the remaining row as **1 documented input boundary**. Do not increment 71 unit tests or 612 file inventory from this ledger change. Keep the aggregate CF09, 71-unit and 612-file scopes partial.

## Independent evidence debts retained

- Loop5 `test(String)J`: source-map 59/60, physical BCI 103 missing.
- Loop3 `writeMore(String)V`: source-map 48/49, physical BCI 88 (`goto`) missing.
- `PrefixedRetryControl.run()V`: source-map 40/41, physical BCI 71 (`goto`) missing.
- Do3 field `it` has class-file Signature `Ljava/util/Iterator<Ljava/lang/String;>;`, but Jarde emits raw `java.util.Iterator it;` with `field_generic_source_unproved`; preserve this as a separate projection debt.
- Native capture contains embedded `observed_counts` association errors for 316 target items in 95 batches. Retain those raw facts, but use the independently target-bound execution verifier for status counts.

These are separate ledger notes. Do not infer a shared source-map cause or let metadata misattribution change pass/fail totals.
