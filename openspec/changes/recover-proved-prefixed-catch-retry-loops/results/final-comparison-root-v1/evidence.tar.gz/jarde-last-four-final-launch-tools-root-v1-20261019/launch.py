import hashlib,json,subprocess,sys
from pathlib import Path
collector,destination,launch,cli=map(Path,sys.argv[1:5]);expected=sys.argv[5]
assert not launch.exists() and not destination.exists()
assert hashlib.sha256(cli.read_bytes()).hexdigest()==expected
launch.mkdir()
argv=[sys.executable,'-B',str(collector),'--out',str(destination),'--cli',str(cli),'--cli-sha256',expected]
def pin(p):
 b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
with (launch/'stdout.raw').open('xb') as a,(launch/'stderr.raw').open('xb') as b:r=subprocess.run(argv,stdout=a,stderr=b)
record={'status':'closed','argv':argv,'exit_code':r.returncode,'collector':pin(collector),'cli':pin(cli),'streams':{ch:pin(launch/(ch+'.raw')) for ch in ['stdout','stderr']}}
(launch/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));raise SystemExit(r.returncode)
