import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;

/** Finite observations of the unmodified TestDoWhileBreak2$TestCls. */
public final class TestDoWhileBreak2Driver {
    private static final String TARGET = "jadx.tests.integration.loops.TestDoWhileBreak2$TestCls";

    private static final class Case {
        final String name;
        final Object[] values;
        final boolean nullIterator;
        final int throwNextAt;
        final int throwHasNextAt;
        Case(String name, Object[] values, boolean nullIterator, int throwNextAt, int throwHasNextAt) {
            this.name = name; this.values = values; this.nullIterator = nullIterator;
            this.throwNextAt = throwNextAt; this.throwHasNextAt = throwHasNextAt;
        }
        String input() {
            if (nullIterator) return "null-iterator";
            StringBuilder b = new StringBuilder("[");
            for (int i = 0; i < values.length; i++) {
                if (i != 0) b.append(',');
                if (values[i] == null) b.append("null"); else if (values[i] instanceof String) b.append('"').append(values[i]).append('"'); else b.append(values[i]);
            }
            return b.append(']').toString();
        }
    }
    private static final Case[] CASES = {
        new Case("two-elements", new String[]{"a", "b"}, false, 0, 0),
        new Case("null-terminated", new String[]{"a", "b", null}, false, 0, 0),
        new Case("null-first-tail", new String[]{null, "tail"}, false, 0, 0),
        new Case("single-nonnull", new String[]{"alpha"}, false, 0, 0),
        new Case("empty", new String[]{}, false, 0, 0),
        new Case("null-iterator", new String[]{}, true, 0, 0),
        new Case("next-throws-first", new String[]{"alpha"}, false, 1, 0),
        new Case("next-throws-second", new String[]{"alpha", "beta"}, false, 2, 0),
        new Case("hasnext-throws-first", new String[]{"alpha"}, false, 0, 1),
        new Case("hasnext-throws-second", new Object[]{"alpha", "beta", "tail"}, false, 0, 2),
        new Case("wrong-type-cast", new Object[]{Integer.valueOf(42)}, false, 0, 0)
    };

    private static final class TracingIterator implements Iterator<Object> {
        final Object[] values;
        final int throwNextAt;
        final int throwHasNextAt;
        final List<String> events = new ArrayList<String>();
        int cursor;
        int nextCalls;
        int hasNextCalls;
        TracingIterator(Case c) { values = c.values; throwNextAt = c.throwNextAt; throwHasNextAt = c.throwHasNextAt; }
        @Override public boolean hasNext() {
            int call = ++hasNextCalls;
            if (call == throwHasNextAt) { events.add("hasNext#" + call + " throws"); throw new IllegalStateException("probe.hasNext." + call); }
            boolean result = cursor < values.length;
            events.add("hasNext=" + result);
            return result;
        }
        @Override public Object next() {
            int call = ++nextCalls;
            if (call == throwNextAt) { events.add("next#" + call + " throws"); throw new IllegalStateException("probe.next." + call); }
            if (cursor >= values.length) { events.add("next#" + call + " throws NoSuchElementException"); throw new java.util.NoSuchElementException(); }
            Object value = values[cursor++];
            events.add("next=" + String.valueOf(value));
            return value;
        }
        String remaining() { return cursor < 0 ? "<no-iterator>" : Arrays.toString(Arrays.copyOfRange(values, cursor, values.length)); }
        String after() {
            return "hasNextCalls=" + hasNextCalls + ";nextCalls=" + nextCalls + ";cursor=" + cursor
                + ";remaining=" + remaining() + ";events=" + events.toString();
        }
    }

    private static String b64(String value) { return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8)); }
    private static String stack(Throwable t) {
        StringWriter out = new StringWriter(); t.printStackTrace(new PrintWriter(out)); return out.toString();
    }
    private static String codeSource(Class<?> type) throws Exception {
        CodeSource source = type.getProtectionDomain().getCodeSource();
        if (source == null || source.getLocation() == null) throw new IllegalStateException("target has no CodeSource");
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }
    private static void requireEmptyCwd(String expected) throws Exception {
        String actual = Paths.get(".").toRealPath().toString();
        if (!actual.equals(expected)) throw new IllegalStateException("unexpected JVM cwd: expected=" + expected + " actual=" + actual);
        String[] entries = new java.io.File(".").list();
        if (entries == null || entries.length != 0) throw new IllegalStateException("JVM cwd is not empty");
    }
    private static void observe(Method test, Field iteratorField, Constructor<?> ctor, Case c, int index, String cwd, PrintStream resultOut) throws Exception {
        requireEmptyCwd(cwd);
        Object receiver = ctor.newInstance();
        TracingIterator input = c.nullIterator ? null : new TracingIterator(c);
        iteratorField.set(receiver, input);
        PrintStream previous = System.out;
        ByteArrayOutputStream captured = new ByteArrayOutputStream();
        PrintStream targetOut = new PrintStream(captured, true, "UTF-8");
        Throwable cause = null; String result = "<not-returned>";
        try {
            System.setOut(targetOut);
            try { result = "return=" + String.valueOf(test.invoke(receiver)); }
            catch (InvocationTargetException e) { cause = e.getCause(); }
        } finally { targetOut.flush(); System.setOut(previous); targetOut.close(); }
        String stdout = new String(captured.toByteArray(), StandardCharsets.UTF_8);
        int nextCalls = input == null ? 0 : input.nextCalls;
        int hasNextCalls = input == null ? 0 : input.hasNextCalls;
        int cursor = input == null ? -1 : input.cursor;
        String after = input == null ? "hasNextCalls=0;nextCalls=0;cursor=-1;remaining=<no-iterator>;events=[]" : input.after();
        String exception = cause == null ? "none" : cause.getClass().getName();
        resultOut.println("CASE index=" + index + " name=" + c.name + " input_b64=" + b64(c.input())
            + " result_b64=" + b64(result) + " exception=" + exception
            + " exception_message_b64=" + b64(cause == null ? "" : String.valueOf(cause.getMessage()))
            + " exception_stack_b64=" + b64(cause == null ? "" : stack(cause))
            + " target_stdout_b64=" + b64(stdout) + " after_b64=" + b64(after));
        if (input != null && (input.nextCalls != nextCalls || input.hasNextCalls != hasNextCalls || input.cursor != cursor))
            throw new IllegalStateException("iterator observation changed while serializing");
        requireEmptyCwd(cwd);
    }
    private static String observeCheck(Method check, Constructor<?> ctor, String cwd) throws Exception {
        requireEmptyCwd(cwd); Object receiver = ctor.newInstance();
        PrintStream previous = System.out; ByteArrayOutputStream captured = new ByteArrayOutputStream();
        PrintStream checkOut = new PrintStream(captured, true, "UTF-8"); Throwable cause = null;
        try { System.setOut(checkOut); try { check.invoke(receiver); } catch (InvocationTargetException e) { cause = e.getCause(); } }
        finally { checkOut.flush(); System.setOut(previous); checkOut.close(); }
        String stdout = new String(captured.toByteArray(), StandardCharsets.UTF_8);
        String row = "CHECK result=" + (cause == null ? "pass" : "error") + " exception="
            + (cause == null ? "none" : cause.getClass().getName()) + " stdout_b64=" + b64(stdout)
            + " exception_message_b64=" + b64(cause == null ? "" : String.valueOf(cause.getMessage()));
        requireEmptyCwd(cwd); return row;
    }
    public static void main(String[] args) throws Exception {
        if (args.length < 3) throw new IllegalArgumentException("usage: TestDoWhileBreak2Driver actualRoot expectedRoot emptyWorkingDirectory [dependencyUrl ...]");
        String actual = Paths.get(args[0]).toRealPath().toString();
        String expected = Paths.get(args[1]).toRealPath().toString();
        String cwd = Paths.get(args[2]).toRealPath().toString(); requireEmptyCwd(cwd);
        URL[] urls = new URL[args.length - 2]; urls[0] = Paths.get(actual).toUri().toURL();
        for (int i = 3; i < args.length; i++) urls[i - 2] = Paths.get(args[i]).toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(urls, null)) {
            Class<?> target = Class.forName(TARGET, true, loader);
            if (target.getClassLoader() != loader) throw new IllegalStateException("target did not load from isolated parentless loader");
            String origin = codeSource(target);
            if (!origin.equals(expected)) throw new IllegalStateException("wrong CodeSource: expected=" + expected + " actual=" + origin);
            Constructor<?> ctor = target.getDeclaredConstructor(); ctor.setAccessible(true);
            Method test = target.getDeclaredMethod("test"); test.setAccessible(true);
            Method check = target.getDeclaredMethod("check"); check.setAccessible(true);
            Field iteratorField = target.getDeclaredField("it"); iteratorField.setAccessible(true);
            PrintStream resultOut = System.out;
            for (int i = 0; i < CASES.length; i++) observe(test, iteratorField, ctor, CASES[i], i, cwd, resultOut);
            System.out.println(observeCheck(check, ctor, cwd)); requireEmptyCwd(cwd);
        }
    }
}
