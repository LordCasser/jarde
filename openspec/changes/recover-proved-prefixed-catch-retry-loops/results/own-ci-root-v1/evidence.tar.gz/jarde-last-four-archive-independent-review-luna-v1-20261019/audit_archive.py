#!/usr/bin/env python3
"""Independent tar/member and four-receipt audit. Read-only, Python stdlib."""
import hashlib, json, os, stat, tarfile
from pathlib import Path

ARCHIVE=Path('/private/tmp/jarde-last-four-comparison-archive-root-v1-20261019/evidence.tar.gz')
ROOT=ARCHIVE.parent
ACCEPT=Path('/private/tmp/jarde-last-four-comparison-acceptance-root-v1-20261019/acceptance.json')
INVENTORY=ROOT/'inventory.json'; CAPTURE=ROOT/'capture.json'
OUT=Path('/private/tmp/jarde-last-four-archive-independent-review-luna-v1-20261019/review.json')

def sha(b): return hashlib.sha256(b).hexdigest()
def read_member(t, name):
    f=t.extractfile(name)
    if f is None: raise AssertionError(f'not a regular file: {name}')
    return f.read()

accept=json.loads(ACCEPT.read_text()); inventory=json.loads(INVENTORY.read_text()); capture=json.loads(CAPTURE.read_text())
inv=inventory['payloads']; excl=inventory['excluded']
with tarfile.open(ARCHIVE,'r:gz') as t:
    members=t.getmembers(); regular={m.name:m for m in members if m.isfile()}
    if len(members)!=len(regular): raise AssertionError('tar has non-regular or duplicate members')
    if len(regular)!=len(members): raise AssertionError('duplicate tar member path')
    if len(inv)!=len(regular): raise AssertionError(f'inventory/tar count mismatch {len(inv)} vs {len(regular)}')
    by_name={x['member']:x for x in inv}
    if len(by_name)!=len(inv): raise AssertionError('duplicate inventory member names')
    if set(by_name)!=set(regular): raise AssertionError('inventory names differ from archive member names')
    total=0; checked=[]; payload_data={}
    for name,member in regular.items():
        row=by_name[name]; b=read_member(t,name); total+=len(b)
        mode=stat.S_IMODE(member.mode)
        if len(b)!=row['bytes'] or sha(b)!=row['sha256'] or mode!=row['mode']:
            raise AssertionError(f'member mismatch {name}: got {len(b)}/{sha(b)}/{mode:o}, expected {row}')
        if name.endswith('.json') or name.endswith('.json.json') or name.endswith('attempt-1-live-target-gate.json'):
            payload_data[name]=b
        checked.append({'member':name,'bytes':len(b),'sha256':sha(b),'mode':mode})
    if total!=capture['payload_bytes']: raise AssertionError(f'payload byte sum {total} != capture {capture["payload_bytes"]}')
    if len(regular)!=capture['payload_count']: raise AssertionError('payload count differs from capture')
    tar_bytes=ARCHIVE.read_bytes()
    archive_sha=sha(tar_bytes)
    if len(tar_bytes)!=capture['archive']['bytes'] or archive_sha!=capture['archive']['sha256']:
        raise AssertionError('archive file pin differs from capture')
    if capture.get('status')!='all_members_reopened_and_matched': raise AssertionError('capture status not complete')
    orig_index={x['original_path']:x for x in inv}
    if len(orig_index)!=len(inv): raise AssertionError('duplicate original path in archive inventory')
    excluded_checks=[]
    tar_originals={x['original_path'] for x in inv}
    for x in excl:
        if x['member'] in regular or x['original_path'] in tar_originals: raise AssertionError('excluded payload unexpectedly archived')
        path=Path(x['original_path'])
        if not path.is_file(): raise AssertionError(f'excluded file missing for pin check: {path}')
        b=path.read_bytes(); mode=stat.S_IMODE(path.stat().st_mode)
        if len(b)!=x['bytes'] or sha(b)!=x['sha256'] or mode!=x['mode']: raise AssertionError(f'excluded file pin mismatch: {path}')
        excluded_checks.append({'path':str(path),'bytes':len(b),'sha256':sha(b),'mode':mode})

    def member_by_original(path):
        row=orig_index.get(path)
        if row is None: raise AssertionError(f'original path absent from archive inventory: {path}')
        return row
    def json_by_original(path):
        row=member_by_original(path)
        return json.loads(payload_data[row['member']])

    pins_name='jarde-last-four-comparison-acceptance-root-v1-20261019/reopened-pins.json'
    reopened=json.loads(payload_data[pins_name])
    keys={(x['path'],x['sha256']) for x in reopened}
    if len(reopened)!=5341 or len(keys)!=5341 or accept['reopened_unique_path_and_sha']!=5341:
        raise AssertionError(f'reopened unique pin count mismatch: list={len(reopened)}, unique={len(keys)}')

    matrix_results=[]
    for mat in accept['matrices']:
        label=mat['name']; rp=mat['receipt']['path']; receipt=json_by_original(rp)
        rrow=member_by_original(rp)
        if rrow['bytes']!=mat['receipt']['bytes'] or rrow['sha256']!=mat['receipt']['sha256']:
            raise AssertionError(f'{label}: acceptance receipt pin mismatch')
        commands=receipt.get('commands',[])
        stream_refs=[]
        for c in commands:
            streams=c.get('streams') or {}
            for stream_name in ('stdout','stderr'):
                s=streams.get(stream_name)
                if not isinstance(s,dict): raise AssertionError(f'{label}: command {c.get("index")} lacks {stream_name}')
                row=member_by_original(s['path'])
                if row['bytes']!=s['bytes'] or row['sha256']!=s['sha256']:
                    raise AssertionError(f'{label}: raw stream mismatch {s["path"]}')
                stream_refs.append(s['path'])
        comp=receipt.get('generated_source_compilations',[])
        runtimes=receipt.get('generated_runtime',[])
        wrong=receipt.get('generated_wrong_root_controls',[])
        original=receipt.get('original_runtime',[])
        apis=receipt.get('jarde_cells',[])
        cases=sum(len(x.get('rows',[])) for x in runtimes)
        compcounts={}
        for x in comp:
            k=(x.get('kind'),x.get('compiler'),x.get('exit_code'))
            compcounts[k]=compcounts.get(k,0)+1
        comp_success=sum(x.get('exit_code')==0 for x in comp)
        eligible=sum(x.get('runtime_eligible') is True for x in comp)
        for x in wrong:
            if not x.get('rejected') or x.get('exit_code')==0: raise AssertionError(f'{label}: wrong-root control not rejected')
        for c in commands:
            if c.get('guard_stop'): raise AssertionError(f'{label}: guarded command stop in accepted receipt')
        if not receipt.get('target_absent_finally',receipt.get('target_absent',False)):
            raise AssertionError(f'{label}: final target cleanup missing')
        if len(commands)!=mat['commands'] or len(stream_refs)!=mat['raw_streams']:
            raise AssertionError(f'{label}: command/raw count differs')
        if len(comp)!=mat['generated_compile_successes']+sum(x.get('exit_code')!=0 for x in comp):
            raise AssertionError(f'{label}: compile list count mismatch')
        if comp_success!=mat['generated_compile_successes'] or len(runtimes)!=mat['generated_vm_runs'] or cases!=mat['generated_case_observations']:
            raise AssertionError(f'{label}: generated execution count differs from acceptance')
        if len(apis)!=8 or len(wrong)!=mat.get('generated_wrong_root_cells',len(wrong)):
            # The top-level acceptance schema predates wrong-root counts; check reported field only when present.
            if len(apis)!=8: raise AssertionError(f'{label}: expected 8 API cells, got {len(apis)}')
        compile_groups=[{'kind':k[0],'compiler':k[1],'exit_code':k[2],'count':n} for k,n in sorted(compcounts.items())]
        if compile_groups!=mat['compile_counts']: raise AssertionError(f'{label}: compile groups mismatch {compile_groups}')
        matrix_results.append({'name':label,'receipt_path':rp,'receipt_sha256':rrow['sha256'],'commands':len(commands),'raw_streams':len(stream_refs),'api_cells':len(apis),'compiled':len(comp),'compile_successes':comp_success,'runtime_eligible':eligible,'generated_vm_runs':len(runtimes),'generated_case_observations':cases,'wrong_root_controls':len(wrong),'original_vm_runs':len(original),'final_target_absent':True,'compile_counts':compile_groups})

    b=next(x for x in matrix_results if x['name']=='retry-control')
    if (b['generated_vm_runs'],b['runtime_eligible'],b['wrong_root_controls'])!=(40,20,20):
        raise AssertionError(f'B v2 matrix mismatch: {b}')
    # Reopen the archived final B independent review and the exact v6 attempt record.
    b_review_name='jarde-last-four-final-retry-control-review-root-v3-20261019.json/jarde-last-four-final-retry-control-review-root-v3-20261019.json'
    b_review=json.loads(payload_data[b_review_name])
    if b_review.get('status')!='accepted_with_mapping_debt' or b_review.get('errors'):
        raise AssertionError('final root B review not accepted or has errors')
    v6name='jarde-prefixedretry-control-audit-luna-v6-20261019/attempt-1-live-target-gate.json'
    v6=json.loads(payload_data[v6name])
    # Preserve this fact accurately: the archived Luna v6 attempt was blocked by its live target gate;
    # the separate root v3 review is the final accepted B review.
    v6_facts={'archived_attempt_status':v6.get('status'),'error':v6.get('error'),'receipt_target_absent_finally':v6.get('receipt_target_absent_finally'),'live_workspace_target_observed_during_audit':v6.get('live_workspace_target_observed_during_audit'),'root_v3_review_status':b_review.get('status')}

    # Historical B v1 is not promoted to final evidence: capture its smaller runtime matrix/status separately.
    old_receipt_path='/private/tmp/jarde-last-four-final-retry-control-root-v1-20261019/execution.json'
    old_receipt=json_by_original(old_receipt_path)
    old={'receipt_status':old_receipt.get('status'),'generated_vm_runs':len(old_receipt.get('generated_runtime',[])),'commands':len(old_receipt.get('commands',[]))}
    old_review_name='jarde-last-four-final-retry-control-review-root-v1-20261019.json/jarde-last-four-final-retry-control-review-root-v1-20261019.json'
    old_review=json.loads(payload_data[old_review_name]) if old_review_name in payload_data else None
    if old_review: old['review_status']=old_review.get('status')

result={'schema':'last-four-archive-independent-review-v1','status':'passed_with_v6_attempt_discrepancy_recorded','acceptance_status':accept.get('status'),'product_revision':accept.get('product_revision'),'cli_sha256':accept.get('cli_sha256'),'archive':{'path':str(ARCHIVE),'bytes':len(tar_bytes),'sha256':archive_sha,'payload_count':len(checked),'payload_bytes':total,'inventory_count':len(inv),'excluded_count':len(excl),'capture':capture,'excluded_file_checks':excluded_checks},'reopened_pin_manifest':{'count':len(reopened),'unique_path_sha_count':len(keys)},'matrices':matrix_results,'B_final_review':{'status':b_review.get('status'),'raw_streams':b_review.get('raw_streams'),'generated_compiles':b_review.get('generated_compiles'),'generated_runtime_cells':b_review.get('generated_runtime_cells'),'generated_wrong_root_cells':b_review.get('generated_wrong_root_cells'),'mapping_debt':b_review.get('mapping_debt_scope')},'B_v6_audit_record':v6_facts,'historical_B_v1_not_promoted':old,'mapping_debts':accept.get('mapping_debts'),'boundaries':accept.get('boundaries'),'scope':accept.get('scope'),'member_inventory':checked}
OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('member_inventory','boundaries','mapping_debts')},indent=2,sort_keys=True))
