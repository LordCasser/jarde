# Independent final comparison archive audit

Status: all archive payload members, inventory fields, capture fields, four closed comparison receipts, and captured raw streams reopened and matched. This is a private audit; it does not modify the workspace or read the active CI watch.

The archive has 1,522 regular payload members totaling 72,910,550 bytes. Every member's content length, SHA-256, and mode matched `inventory.json`; the archive SHA-256 is `b197c34f9a4291d1af3a7288bede6a5c8d0e9f8064912ecb06cf9fed17722b7f`. The single excluded CLI was separately rehashed at 64,754,240 bytes, mode 0555, SHA `ed74e005c1bc97bcdf4a15f6a27da9e9d8a1ecdf7fe576836820ed2ce323222d`. The archived reopened-pin list contains 5,341 unique `(path, SHA-256)` pairs.

| Group | Commands / raw | Full-source compiles successful | Generated VMs / case observations | Wrong-root controls |
|---|---:|---:|---:|---:|
| Do2 | 70 / 140 | 10 of 20 | 20 / 220 | 10 |
| Loop3 | 94 / 188 | 18 of 20 | 36 / 36 | 18 |
| Do3 | 94 / 188 | 18 of 20 | 36 / 360 | 18 |
| Retry control B v2 | 105 / 210 | 20 of 20 | 40 / 400 | 20 |

For Do2, Loop3 and Do3, every failed generated compile is JDK 8 and its raw diagnostic identifies framework class major 55.0 versus expected 52.0. B v2 has no generated compile failure; all 20 compilations were runtime-eligible, and all 40 VMs and 20 wrong-root controls are represented in the closed receipt and accepted root review. Default/all and profile/form review qualifiers are retained in `review.json`.

The older B v1 receipt is separately identified as a 32-VM captured run with an `audit_failed` review; it is not promoted. The archived root B v3 review accepts the B v2 receipt with the disclosed BCI 71 mapping debt. The requested Luna v6 artifact is **not a passing audit**: archived `attempt-1-live-target-gate.json` and its output report `audit_failed` because the concurrent live workspace had `target/`. Its receipt itself says target was absent after completion. This v6 failure is distinct from the accepted root v3 review; no passing Luna v6 rerun appears in the archive.

Detailed evidence and per-member records are in `review.json`; `audit_archive.py` is the read-only auditor.
