#!/usr/bin/env python3
"""Independently reopen archived final reviews and compile-boundary stderr."""
import hashlib,json,tarfile
from pathlib import Path
BASE=Path('/private/tmp/jarde-last-four-archive-independent-review-luna-v1-20261019')
ARCHIVE=Path('/private/tmp/jarde-last-four-comparison-archive-root-v1-20261019/evidence.tar.gz')
INVENTORY=json.loads((ARCHIVE.parent/'inventory.json').read_text())['payloads']
BY_ORIGINAL={x['original_path']:x['member'] for x in INVENTORY}
RECEIPTS={'do2':'/private/tmp/jarde-last-four-final-do2-root-v2-20261019/execution.json','loop3':'/private/tmp/jarde-last-four-final-loop3-root-v1-20261019/execution.json','do3':'/private/tmp/jarde-last-four-final-do3-root-v1-20261019/execution.json','retry-control':'/private/tmp/jarde-last-four-final-retry-control-root-v2-20261019/execution.json'}
REVIEWS={'do2':'jarde-last-four-final-do2-review-root-v1-20261019/jarde-last-four-final-do2-review-root-v1-20261019','loop3':'jarde-last-four-final-loop3-review-root-v3-20261019/review.json','do3':'jarde-last-four-final-do3-review-root-v1-20261019/review.json','retry-control':'jarde-last-four-final-retry-control-review-root-v3-20261019.json/jarde-last-four-final-retry-control-review-root-v3-20261019.json'}
report=json.loads((BASE/'review.json').read_text()); review_facts={}; boundaries={}
with tarfile.open(ARCHIVE) as t:
    for label,member in REVIEWS.items():
        d=json.loads(t.extractfile(member).read())
        if label=='do2':
            assert (d['commands'],d['raw_streams'],d['generated_compile_attempts'],d['generated_compile_successes'],d['wrong_root_rows'],d['manual_oracle_cases_per_vm'])==(70,140,20,10,10,11)
            assert d['api_keys_unique_complete'] and d['default_all_text_maps_stable']
            review_facts[label]={'status':d['status'],'commands':d['commands'],'raw_streams':d['raw_streams'],'api_cells':d['api_cells'],'compile_attempts':d['generated_compile_attempts'],'compile_successes':d['generated_compile_successes'],'generated_vm_rows':d['generated_vm_rows'],'wrong_root_rows':d['wrong_root_rows'],'cases_per_vm':d['manual_oracle_cases_per_vm'],'default_all_text_maps_stable':d['default_all_text_maps_stable']}
        elif label=='loop3':
            c=d['counts']; stable=d['default_all_stability']; assert d['status']=='accepted_with_mapping_debt'
            assert (c['commands'],c['raw_streams_rehashed'],c['jarde_full_source_recompile_successes'],c['jadx_full_source_recompile_successes'],c['generated_vm_runs'],c['wrong_CodeSource_controls'])==(94,188,16,2,36,19)
            assert len(stable)==16 and all(x['body_quality_identity_default_all_equal'] and x['mapped_bcis_default']==x['mapped_bcis_all'] for x in stable)
            review_facts[label]={'status':d['status'],'counts':c,'default_all_stability_rows':len(stable),'default_all_stability_passed':True,'mapping_debt_scope':d['mapping_debt_scope'],'framework_boundary':d.get('framework_boundary'),'nyi_boundary':d.get('nyi_boundary')}
        elif label=='do3':
            c=d['derived_counts']; assert d['status']=='passed'
            assert (c['commands'],c['raw_streams'],c['compile_successes'],c['generated_runtime_runs'],c['runtime_observations'])==(94,188,18,36,360)
            review_facts[label]={'status':d['status'],'derived_counts':c,'integrity':d.get('integrity'),'interpretation':d.get('interpretation')}
        else:
            assert d['status']=='accepted_with_mapping_debt' and not d['errors']
            assert (d['commands'],d['raw_streams'],d['generated_compiles'],d['generated_runtime_cells'],d['generated_wrong_root_cells'])==(105,210,20,40,20)
            review_facts[label]={'status':d['status'],'commands':d['commands'],'raw_streams':d['raw_streams'],'original_vm_cells':d['original_vm_cells'],'api_cells':d['jarde_api_cells'],'generated_source_cells':d['generated_source_cells'],'generated_compiles':d['generated_compiles'],'generated_runtime_cells':d['generated_runtime_cells'],'generated_wrong_root_cells':d['generated_wrong_root_cells'],'mapping_debt_scope':d['mapping_debt_scope']}
    for label,path in RECEIPTS.items():
        r=json.loads(t.extractfile(BY_ORIGINAL[path]).read()); failures=[]
        for c in r.get('generated_source_compilations',[]):
            if c.get('exit_code')==0: continue
            s=c['stderr']; raw=t.extractfile(BY_ORIGINAL[s['path']]).read(); text=raw.decode('utf-8','replace')
            ok='55.0' in text and '52.0' in text
            failures.append({'kind':c['kind'],'compiler':c['compiler'],'command':c.get('command'),'stderr_path':s['path'],'stderr_sha256':hashlib.sha256(raw).hexdigest(),'framework_major_55_vs_52':ok})
        if label in ('do2','loop3','do3'): assert failures and all(x['compiler']=='javac8' and x['framework_major_55_vs_52'] for x in failures)
        else: assert not failures
        boundaries[label]={'compile_failures':len(failures),'framework_major_55_vs_52_failures':sum(x['framework_major_55_vs_52'] for x in failures),'failure_records':failures}
report['independent_review_qualifiers']=review_facts
report['independent_compile_boundary_diagnostics']=boundaries
(BASE/'review.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'reviews':{k:v['status'] for k,v in review_facts.items()},'framework_compile_failures':{k:(v['compile_failures'],v['framework_major_55_vs_52_failures']) for k,v in boundaries.items()}},indent=2))
