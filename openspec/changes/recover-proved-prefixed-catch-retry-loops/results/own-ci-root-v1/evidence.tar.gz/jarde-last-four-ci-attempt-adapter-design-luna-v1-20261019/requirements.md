# CI run-attempt endpoint fallback design (requirements only)

Status: design note only. No collector/verifier changes and no API calls were made here. Root observed HTTP 502 from the run-level jobs endpoint, and the live run is still in progress; those facts do not establish a product failure or a complete CI result.

## Why the existing adapter cannot be patched by changing one URL

The frozen collector first executes `gh run view ... --json jobs,...`; that command itself requests the run-level jobs endpoint which is returning 502. It then separately calls `/actions/runs/{run_id}/jobs?per_page=100`. Replacing only the explicit second URL leaves the first failing path intact. Also, while the run is active, the successful attempt-specific job list and individual job response contain incomplete step states. They cannot support the frozen 52-step acceptance gate.

## Minimal official-source fallback, if the run-level endpoint remains unavailable after completion

Keep every response in its original API schema and each subprocess stdout/stderr in separate immutable raw files. Do not synthesize a `gh run view`-shaped document or relabel derived data as raw API output.

1. Capture `GET /repos/{owner}/{repo}/actions/runs/{run_id}` as its own command and raw JSON. Require the returned `id` to equal the requested run ID, `run_attempt == 1`, `head_sha` to equal the pinned product SHA, and run `status == completed` / `conclusion == success`.
2. Capture `GET /repos/{owner}/{repo}/actions/runs/{run_id}/attempts/1/jobs?per_page=100` as a separate command and raw JSON. Require `total_count == 4`, exactly four unique job IDs, and the exact existing job-name inventory. This response is the source for job identity only; do not count its empty or partial `steps` as the 52-step evidence.
3. For each job ID, capture `GET /repos/{owner}/{repo}/actions/jobs/{job_id}` independently to a distinct raw JSON/stdout+stderr pair. Require the exact run ID, attempt 1 where the response exposes it, matching job ID/name, and completed/success status. Require the full steps array to have only completed/success steps and to agree with the fixed workflow order and the matching step-log ZIP records. Any `in_progress`, `pending`, missing `Complete job`, duplicate, or count/order mismatch is a hard rejection.
4. Compare each individual job record against its corresponding attempt-list entry (ID, name, status, conclusion). Preserve both original responses. If the attempt listing omits step detail but the per-job endpoint supplies it, only the per-job response is authoritative for that job's steps; this distinction must be explicit in the verifier report.
5. Keep the existing source/fixture pins, source before/after checks, target-absence checks, fixed CI gate Counter checks, official run ZIP validation (all 52 steps), product/CLI hashes, and all existing gate counts unchanged. Adapt only how run/job API evidence is acquired and independently checked.
6. Validate every command argv against the exact official endpoint, run ID, attempt, and job ID. Reopen every raw stdout/stderr pin and ensure byte length/hash match the command receipt. Compute expected command inventory from four per-job detail calls plus the run and attempt-list calls; do not deduplicate commands or streams.
7. Only use the attempt-specific fallback if the ordinary run-level jobs endpoint remains unavailable after the run is complete and a fresh post-completion probe confirms the attempt-specific and per-job APIs are complete. Preserve all failed HTTP 502 and incomplete-run raw streams; do not rewrite or repurpose them.

## Current observation and stop condition

Root's closed probe `/private/tmp/jarde-last-four-ci-one-job-root-v1-20261019/stdout.raw` showed one job in `completed/success` with `run_attempt=1` and the expected head, but only five step records: setup completed, checkout in progress, later steps pending, and no `Complete job`. The run itself was still `in_progress`. This is an expected incomplete state and must not be treated as an acceptance result. Wait for workflow completion, then retry the ordinary endpoint once under the existing raw-preserving retry policy before deciding whether the fallback is needed.
