from __future__ import annotations
import hashlib, importlib.util, json, sys, zipfile
from pathlib import Path
ROOT=Path('/private/tmp/jarde-last-four-own-ci-root-v4-20261020')
TOOLS=Path('/private/tmp/jarde-last-four-ci-attempt-fallback-prep-luna-v3-20261020')
OUT=Path(__file__).resolve().parent/'audit.json'
def sha(b): return hashlib.sha256(b).hexdigest()
def load(path,name):
 s=importlib.util.spec_from_file_location(name,path)
 if s is None or s.loader is None: raise RuntimeError(path)
 m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
common=load(TOOLS/'common.py','review_common');sys.modules['common']=common;old=load(TOOLS/'verify-own-ci-attempt1.py','review_verifier');adapter=load(TOOLS/'verify-own-ci-loop45-attempt1.py','review_adapter')
c=json.loads((ROOT/'collection.json').read_text());run=json.loads((ROOT/'run.json').read_text());api=json.loads((ROOT/'jobs-api.json').read_text());pins=json.loads((ROOT/'source-pins.json').read_text());inputs=json.loads((ROOT/'final-adapter-inputs.json').read_text())
assert run['databaseId']==int(c['run_id']) and run['headSha']==c['product_sha']==pins['product_sha']==inputs['product_sha']
assert run['status']=='completed' and run['conclusion']=='success' and run['workflowName']=='CI'
assert c['status']=='raw collection complete; independent acceptance pending' and c['source_before_after_equal'] and c['target_absent_after']
rows=api['jobs'];assert api['total_count']==len(rows)==4 and sum(len(j['steps']) for j in rows)==52
assert all(j['run_id']==int(c['run_id']) and j['run_attempt']==1 and j['head_sha']==c['product_sha'] and j['status']=='completed' and j['conclusion']=='success' for j in rows)
assert all(s['status']=='completed' and s['conclusion']=='success' for j in rows for s in j['steps'])
filenames={'stable / test and specification':'stable.log','MSRV 1.88.0':'msrv.log','supply chain':'supply-chain.log','fuzz smoke':'fuzz-smoke.log'};logs={}
for name,fn in filenames.items():
 j=next(x for x in rows if x['name']==name)
 cmd=next(x for x in c['commands'] if x.get('argv')==['gh','run','view',str(c['run_id']),'--repo','LordCasser/jarde','--job',str(j['id']),'--log'])
 raw=(ROOT/fn).read_bytes();stream=cmd['streams']['stdout']
 assert cmd['exit_code']==0 and stream['path']==str(ROOT/fn) and stream['bytes']==len(raw) and stream['sha256']==sha(raw)
 assert cmd['transport_attempts'][0]['streams']['stdout']['sha256']==sha(raw) and raw==(ROOT/(fn+'.transport-attempt-1')).read_bytes()
 logs[name]=raw.decode('utf-8-sig')
zraw=(ROOT/'run-logs.zip').read_bytes(); assert zraw==(ROOT/'official-zip-attempt-1.zip').read_bytes() and sha(zraw)=='a8bfc7520db8b337c67219b8b8d8f4979ca23d26dd4b4d407cb4d73029b6b25e'
z=zipfile.ZipFile(ROOT/'run-logs.zip');znames=set(z.namelist());assert len(znames)==44==len(z.namelist())
missing=[];present=0
for job in rows:
 folder=job['name'].replace('/','_')
 for st in job['steps']:
  member=f"{folder}/{st['number']}_{st['name'].replace('/','_')}.txt"
  if member in znames:present+=1
  else:missing.append({'job':job['name'],'job_id':job['id'],'step_number':st['number'],'step_name':st['name'],'expected_member':member})
assert (present,len(missing))==(38,14)
# Validate every source and fixture copy against the exact commit-bound source-pins manifest.
for table,base in ((pins['source_files'],ROOT/'product-source'),(pins['fixture_files'],ROOT/'product-fixtures')):
 for rel,row in table.items():
  b=(base/rel).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],rel
assert len(pins['source_files'])==40 and len(pins['fixture_files'])==166 and pins['fixture_file_count']==166
# Reconstruct the frozen 156 critical gate identities in memory and count actual logs.
acc=json.loads((common.BASE/'acceptance-argv.json').read_text())
extra=[acc['verify_ci'][i+1] for i,t in enumerate(acc['verify_ci'][:-1]) if t=='--extra-critical']
for i,spec in enumerate(extra,1):t,n=spec.split('=',1);old.CRITICAL_TESTS[f'Frozen extra {i}']=(n,t)
assert len(old.CRITICAL_TESTS)==123
supp=[(x['target'],x['test']) for x in inputs['supplemental_gates']]
gates=list(common.REGION_GATES)+list(common.PUBLIC_GATES)+list(common.DEFERRED_BUILDER_GATES)+supp
assert len(gates)==33 and len(set(gates))==33
for i,(t,n) in enumerate(gates,1):old.CRITICAL_TESTS[f'Loop45 supplemental {i}: {t}::{n}']=(n,t)
assert len(old.CRITICAL_TESTS)==156
stable=logs['stable / test and specification'];groups=old.workspace_groups(stable);_,workflow,seeds=old.workflow_contract(common.ROOT/'.github/workflows/ci.yml');assert len(groups)==2
reports=[];counters=[]
for g,seed in zip(groups,seeds):
 r=old.parse_workspace_group(g,seed);ctr=adapter.named_outcome_counter(old,g);counters.append(ctr)
 assert r['named_test_outcomes']==3954 and len(ctr)==sum(ctr.values())==3954 and len(set(r['critical_tests_passed']))==156
 reports.append({'seed':seed,'named_test_outcomes':3954,'counter_entries':len(ctr),'critical_gates_passed':156})
adapter.compare_seed_counters(*counters)
raw_inventory={}
for name in ['run.json','jobs-api.json','collection.json','source-pins.json','final-adapter-inputs.json','run-logs.zip','official-zip-attempt-1.zip',*filenames.values()]:
 b=(ROOT/name).read_bytes();raw_inventory[name]={'bytes':len(b),'sha256':sha(b)}
report={'schema':'jarde-last-four-ci-zip-boundary-review-v1','status':'reviewed-with-evidence-boundary',
 'run':{'id':run['databaseId'],'product_sha':run['headSha'],'status':run['status'],'conclusion':run['conclusion'],'workflow':run['workflowName'],'job_count':4,'api_step_count':52,'all_api_steps_successful':True},
 'archive':{'sha256':sha(zraw),'retry_byte_identical':True,'entries':44,'matched_independent_step_members':present,'missing_independent_step_members':len(missing),'missing':missing,'direct_job_aggregate_logs':4},
 'direct_job_logs':{name:{'file':fn,'bytes':len(logs[name].encode()),'sha256':sha(logs[name].encode())} for name,fn in filenames.items()},
 'workspace_seed_reports':reports,'source_binding':{'source_files':40,'fixture_files':166,'all_copies_match_git_show_pins':True,'source_before_after_equal':True,'target_absent_after':True},'raw_file_pins':raw_inventory,
 'contract_assessment':{'3_3_explicit_requirements':['CI for this product commit','named outcomes','actual exit codes','Git source binding'],'task_explicitly_requires_52_independent_step_zip_members':False,'strict_per_step_export_gate_passes':False,'full_job_logs_and_API_support_task_scope_without_claiming_missing_members':True,'limitations':['Do not claim all 52 API steps have unique ZIP members: exactly 38 match API step number/name; 14 do not.','The official archive was pulled twice and is byte-identical; the fan-out deficit is present in both copies.','Any segmentation of aggregate job text is derived evidence, not an original independent ZIP member.']}}
OUT.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'run':report['run'],'archive':{k:v for k,v in report['archive'].items() if k!='missing'},'workspace_seed_reports':reports,'source_binding':report['source_binding']},indent=2))
