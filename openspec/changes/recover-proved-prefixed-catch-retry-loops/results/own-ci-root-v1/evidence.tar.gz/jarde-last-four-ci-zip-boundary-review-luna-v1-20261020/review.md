# CI ZIP completeness review

## Decision

The missing per-step ZIP members are an archive fan-out gap for this run, not evidence that the steps failed or were not run. The original attempt-1 run ZIP was fetched twice, and both files are byte-identical. The official API reports four jobs and all 52 reported steps as completed/success. Four successful, job-ID-specific `gh run view --job ... --log` captures preserve complete raw job logs. The stable log independently contains both fixed-seed workspace runs and their exact named outcomes.

That evidence can satisfy the *stated scope* of the two relevant task 3.3 items if the acceptance record explicitly uses API step statuses plus the four complete job logs and named-test counter, while recording the ZIP limitation. It cannot satisfy a stronger rule requiring a distinct ZIP member for every API step. Keep that stronger verifier result failed; do not rewrite the ZIP, synthesize per-step members, or report 52-member coverage.

## Frozen task contract

`recover-proved-post-test-loop-return-leaves/tasks.md` 3.3 requires old loop gates, fmt/Clippy, full workspace and the product CI, with named results, actual status/exit evidence, and Git-source binding. `recover-proved-prefixed-catch-retry-loops/tasks.md` 3.3 likewise requires old Loop2/4/5/finally gates, fmt/Clippy, full workspace, the product CI, named results and Git-source binding. Neither task requires 52 independently split ZIP members. The later `recover-named-catch-loop-return-tails` 3.2/3.3 requires complete-workspace named outcomes, source binding, strict spec sync and closeout; it also does not define a per-step ZIP-member count.

## Reopened facts

- Run `39278336384` is workflow `CI`, status `completed`, conclusion `success`, and head SHA `8ea98e2e11d64f02092ac200d2b596511dcf5e40`. The attempt-1 jobs API binds all four rows to that run, attempt 1 and head SHA.
- The four API rows contain 52 step records total; every row and every step is completed/success. The two job inventories and the run view agree on the four jobs and step counts: stable 26, MSRV 6, supply chain 8, fuzz smoke 12.
- `run-logs.zip` and `official-zip-attempt-1.zip` have the same 794,203 bytes and SHA256 `a8bfc7520db8b337c67219b8b8d8f4979ca23d26dd4b4d407cb4d73029b6b25e`.
- The ZIP has 44 entries: 38 entries match an API step exactly by job folder, step number and name; 14 expected per-step identities have no such member; four root entries are whole-job aggregate logs and two are `system.txt` entries. The four aggregates do not count as independent step members.
- Missing exact member identities are stable steps 2, 3, 4, 5 and 7; and fuzz steps 2, 3, 4, 6, 7, 9, 10, 20 and 21. In particular, the fuzz archive has no member named for API step 21 `Complete job`; no differently numbered member is credited to it.
- The collector separately captured all four job logs with successful, job-ID-specific commands. Each stdout and its transport-attempt copy match recorded byte counts and SHA256 values. These are full raw job streams, not reconstructed per-step files.
- The stable raw log yields the two workflow seeds `5350648285461741569` and `5350648285461741570`. Each has 3,954 named test outcomes, all 156 exact critical identities pass, and the complete per-target `(target, test, status)` counters are equal across seeds.
- The run/product SHA agree with the source-pin and adapter manifests. The 40 copied source files and 166 fixture files match the pinned `git show <product-sha>:<path>` bytes. The collection receipt also records source-before/after equality and target absent after execution.

The archived whole-job text visibly includes workflow log groups for the omitted stable setup/toolchain/Clippy steps and fuzz setup/query/method/finalization steps. Its content can be inspected as part of the matching full-job log, but it remains aggregate evidence. A parser may retain byte ranges and API time windows as *derived* associations; those do not create original per-step ZIP members and must be labeled accordingly.

## Evidence boundary

**Proven:** the workflow reached the recorded successful conclusion; all 52 official API step rows report success; the four complete job logs were retrieved successfully for exact job IDs; both workspace seed runs emit full equal Counters with 3,954 outcomes and all 156 gates; the run and copied source/fixture inventory bind to the pinned product SHA.

**Not proven by the ZIP:** 52 unique per-step ZIP bodies, 14 missing independent members, or a separately addressable ZIP body for each missing member. The archive itself must remain byte-for-byte original.

The GitHub API has step `status`/`conclusion`, not an integer process-exit-code field. Raw Cargo summaries and the successful API conclusions support successful test execution; the raw records must not be described as API-recorded numeric exit codes. If a local task's literal process exit code is a separate required gate, attach that existing local execution receipt rather than inferring a number from this ZIP.

## Recommendation

Keep the strict per-step archive audit as a failure/limitation. Add a separate acceptance record for the task 3.3 contract that names the official API rows, all four raw job-log hashes, the 38/14 ZIP accounting, both seed Counters, all 156 gates and product-source pins. This is an honest acceptance path because task 3.3 requires CI results and source binding, not per-step archive fan-out. If the project's frozen policy independently mandates a per-step member for every API step, do not mark that policy satisfied; report the export limitation and leave that stricter gate open. Any future aggregate-body splitter must preserve the source log hash plus byte offsets and label the result derived, never pass it off as an original API ZIP member.
