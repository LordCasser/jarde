from pathlib import Path
import subprocess,json,hashlib,time,datetime,sys
out=Path(sys.argv[1]);assert not out.exists();out.mkdir();rows=[];last=None
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
for i in range(60):
 argv=['gh','run','view','39278336384','--json','status,conclusion,headSha,url'];stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(out/f'{i}.stdout.raw').open('xb') as a,(out/f'{i}.stderr.raw').open('xb') as b:r=subprocess.run(argv,stdout=a,stderr=b)
 row={'argv':argv,'exit_code':r.returncode,'started_utc':stamp,'streams':{k:pin(out/f'{i}.{k}.raw') for k in ['stdout','stderr']}};rows.append(row)
 if r.returncode==0:
  d=json.loads((out/f'{i}.stdout.raw').read_bytes());assert d['headSha']=='8ea98e2e11d64f02092ac200d2b596511dcf5e40';state=(d['status'],d['conclusion'])
  if state!=last:print(json.dumps({'observation':d,'attempt':i}),flush=True);last=state
  if d['status']=='completed':break
 time.sleep(30)
rec={'status':'closed_status_observations_not_CI_acceptance','attempts':rows,'last_status':last};(out/'execution.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({'closed':True,'last_status':last,'attempts':len(rows)}));raise SystemExit(0 if last==('completed','success') else 1)
