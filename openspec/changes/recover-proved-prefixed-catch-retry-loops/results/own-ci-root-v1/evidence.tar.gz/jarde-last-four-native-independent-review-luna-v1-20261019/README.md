# Native full-workspace independent audit

This package independently reopens the closed native receipt and all 214 raw stdout/stderr streams. It reconstructs each target from Cargo's actual `Running` executable line, binds it to the fresh `compiler-artifact` record, then binds each stdout harness block and named result to that target. It checks the 111 exact gates listed by the closed review against the raw `ok` lines, including the 18 inherited gates, and rechecks the 5,326 live workspace source pins, default-stack child environment, guard limits, format/metadata commands, final `cargo clean`, and absent `target/` state through the pinned raw workspace verifier.

The command is read-only and uses Python bytecode suppression:

```sh
python3 -B /private/tmp/jarde-last-four-native-independent-review-luna-v1-20261019/audit_native.py \
  --receipt /private/tmp/jarde-last-four-native-root-v1-20261019/execution.json \
  --review /private/tmp/jarde-last-four-native-root-v1-20261019/review.json \
  --out /private/tmp/jarde-last-four-native-independent-review-luna-v1-20261019/replay-review.json
```

The verified normalized native result Counter is the same shape used by the own-CI verifier: rows `[target executable prefix without Cargo's 16-hex suffix, full test name, status, multiplicity]`, sorted and hashed as compact UTF-8 JSON. Its 3,954 rows have SHA-256 `6bc624d48ecbba140da74106a7123758b3e387c4baa2a3ea2ff337ddf8cba966`.

The collector's persisted `observed_counts` were not used for accepted attribution. Raw reconstruction found 93 artifact-order versus actual-Running-order differences; the erroneous aggregate attribution affects 314 target identities. The report retains both numbers and the exact per-target discrepancy list.

The audit reports 396 targets across 104 batches: 3856 passed, 0 failed, and 98 ignored. This is one fixed-seed native run; it does not substitute for comparing the complete Counter across the two independent own-CI seeds.
