#!/usr/bin/env python3
"""Independent raw-stream audit of one closed full-workspace native run."""
from __future__ import annotations
import argparse, collections, hashlib, importlib.util, json, re, sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
CHECKER = Path('/private/tmp/jarde-loop2-retry-native-ci-prep-luna-v2-20261019/verify_workspace.py')
CHECKER_SHA = '8321198c09133aad60d8591b1d3e8f4c849420c4b3a37c1bc4c4aa12129d9830'
REVIEW_SCHEMA = 'single-seed-post-test-loop-workspace-review-v2'
CATEGORY_FIELDS = (
    'historical_object_argument_gates', 'current_exact_gates', 'entry_split_exact_gates',
    'if_loop_entry_exact_gates', 'literal_boolean_exact_gates', 'continue_ladder_exact_gates',
    'array_subtract_exact_gates', 'post_test_loop_break_exact_gates',
    'complex_if_body_boundary_exact_gates', 'loop2_retry_exact_gates', 'loop2_retry_edge_exact_gates')
ANSI_RE = re.compile(rb'\x1b\[[0-?]*[ -/]*[@-~]')
EXE_RE = re.compile(r'^(.*)-([0-9a-f]{16})$')

class AuditError(Exception): pass
def need(ok, message):
    if not ok: raise AuditError(message)
def sha(b: bytes): return hashlib.sha256(b).hexdigest()
def load_module(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def readjson(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def stream_bytes(rec): return Path(rec['path']).read_bytes()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--receipt',required=True,type=Path)
    ap.add_argument('--review',required=True,type=Path)
    ap.add_argument('--out',required=True,type=Path)
    a=ap.parse_args()
    need(not a.out.exists(),'refusing to overwrite audit output')
    need(sha(CHECKER.read_bytes())==CHECKER_SHA,'pinned raw workspace checker changed')
    checker=load_module('pinned_native_workspace_checker',CHECKER)
    receipt_path=a.receipt/'execution.json' if a.receipt.is_dir() else a.receipt
    receipt_path=receipt_path.resolve(strict=True); outdir=receipt_path.parent
    receipt=readjson(receipt_path); review=readjson(a.review)
    need(review.get('schema')==REVIEW_SCHEMA and review.get('status')=='passed','root review is not the expected terminal pass')
    declared=[]
    for field in CATEGORY_FIELDS:
        rows=review.get(field)
        need(isinstance(rows,list),f'review missing category {field}')
        for item in rows:
            need(isinstance(item,dict) and isinstance(item.get('target'),str) and isinstance(item.get('test'),str),f'malformed gate declaration in {field}')
            declared.append((item['target'],item['test']))
    need(len(declared)==93 and len(set(declared))==93,'review category lists do not define 93 unique supplemental exact gates')
    ws_decl=review.get('workspace',{}).get('critical_gates')
    need(isinstance(ws_decl,list) and len(ws_decl)==111,'review workspace does not define all 111 exact gates')
    full_decl=[(item['target'][1],item['test']) for item in ws_decl]
    need(len(set(full_decl))==111 and set(declared)<=set(full_decl),'review workspace exact-gate identities mismatch')
    inherited=[pair for pair in full_decl if pair not in set(declared)]
    need(len(inherited)==18 and review.get('inherited_gate_count')==18,'inherited exact-gate remainder is not 18')
    # Use the closed full exact-gate inventory as identities; the pinned checker below
    # still independently validates each occurrence against raw harness results.
    checker.GATES=full_decl
    expected_receipt={'path':str(receipt_path),'bytes':receipt_path.stat().st_size,'sha256':sha(receipt_path.read_bytes())}
    need(review.get('native_receipt')==expected_receipt,'review does not bind this exact native receipt')
    # This checker reopens all raw streams, maps stderr Cargo Running executables to fresh
    # compiler-artifacts, verifies metadata-derived batches, environment/guard/source pins,
    # format/metadata/clean receipts, complete harness outcomes, and then validates named gates.
    reconstructed=checker.validate_one(receipt_path)
    need(reconstructed['target_count']==review['target_count'] and reconstructed['batch_count']==review['batch_count']
         and reconstructed['workspace_totals']==review['workspace_totals']
         and reconstructed['source_pin_count']==review['source_pin_count'],
         'independent reconstruction disagrees with root summary')
    need(reconstructed['source_pins_sha256']==review['source_pins_sha256'],'live workspace source-pin digest differs from review')
    need(reconstructed['critical_gate_count']==review['critical_gate_count']==111,
         'checker critical-gate inventory and root full gate inventory count differ')

    # Independently reconstruct the full (target executable prefix, test name, status)
    # Counter from actual Running headers and Cargo harness stdout, including ignored tests.
    inventory={tuple(row) for row in receipt['target_inventory']}
    running_counter=collections.Counter(); named_by_identity=collections.defaultdict(list)
    raw_stream_count=0; raw_stream_bytes=0; raw_streams=[]
    for rec in [receipt['format_command'],receipt['metadata_command'],receipt['clean_command']]:
        for kind in ('stdout','stderr'):
            raw_stream_count+=1; raw_stream_bytes+=rec['streams'][kind]['bytes']; raw_streams.append(rec['streams'][kind])
    all_counts={}
    for row in receipt['commands']:
        stdout=stream_bytes(row['streams']['stdout']); stderr=stream_bytes(row['streams']['stderr'])
        raw_stream_count+=2; raw_stream_bytes+=len(stdout)+len(stderr)
        raw_streams.extend([row['streams']['stdout'],row['streams']['stderr']])
        where=f"command {row['index']}"
        artifacts=checker.artifacts_from_stdout(stdout,where)
        launches=checker.running_targets(stderr,artifacts,set(tuple(x) for x in row['planned_targets']),where)
        blocks=checker.harness_blocks(stdout,where)
        need(len(launches)==len(blocks),f'{where}: actual Running launch/block cardinality differs')
        for launch,block in zip(launches,blocks):
            identity=tuple(launch['target']); need(identity in inventory,f'{where}: unknown running target {identity}')
            need(identity not in all_counts,f'target ran more than once: {identity}')
            all_counts[identity]=tuple(block['summary'])
            exe=Path(launch['executable']).name
            m=EXE_RE.fullmatch(exe)
            need(m is not None,f'{where}: Running executable has unexpected un-hashed basename {exe!r}')
            prefix=m.group(1)
            for name,status in block['tests']:
                need(status in ('ok','FAILED','ignored'),f'{where}: unrecognized status {status!r}')
                running_counter[(prefix,name,status)]+=1
                named_by_identity[identity].append((name,status))
    need(set(all_counts)==inventory and len(all_counts)==396,'actual Running identities do not exactly cover the native inventory')
    need(sum(v[0] for v in all_counts.values())==3856 and sum(v[1] for v in all_counts.values())==0
         and sum(v[2] for v in all_counts.values())==98,'actual Running-bound workspace totals differ from 3856/0/98')
    counter_rows=[[t,n,s,c] for (t,n,s),c in sorted(running_counter.items())]
    counter_sha=sha(json.dumps(counter_rows,ensure_ascii=False,separators=(',',':')).encode('utf-8'))
    need(counter_sha and len(counter_rows)>0,'empty normalized test outcome Counter')

    # Validate all 111 named exact gates from the closed review inventory against those raw
    # outcome lines; the review supplies names only, never outcome evidence.
    gate_specs=[]
    for field in CATEGORY_FIELDS:
        rows=review.get(field)
        need(isinstance(rows,list),f'review missing category {field}')
        for item in rows:
            need(isinstance(item,dict) and isinstance(item.get('target'),str) and isinstance(item.get('test'),str),
                 f'malformed gate declaration in {field}')
            gate_specs.append((item['target'],item['test'],field))
    ws_gates=review['workspace'].get('critical_gates')
    need(isinstance(ws_gates,list) and len(ws_gates)==111,'workspace review gate records incomplete')
    recorded_pairs={(g['target'][1],g['test']) for g in ws_gates}
    supplemental_pairs={(t,n) for t,n,_ in gate_specs}
    need(recorded_pairs==set(full_decl) and supplemental_pairs<=recorded_pairs,'root full gate list differs from declared categories')
    gate_specs.extend((target,name,'inherited_gate_wrapper') for target,name in inherited)
    need(len(gate_specs)==111 and len({(t,n) for t,n,_ in gate_specs})==111,
         'review plus inherited identities are not exactly 111 unique named gates')
    gate_out=[]
    for target,name,category in gate_specs:
        hits=[]
        for identity, tests in named_by_identity.items():
            if identity[1]==target:
                hits.extend(status for test,status in tests if test==name)
        need(hits==['ok'],f'exact gate {target}::{name} outcome was {hits!r}')
        gate_out.append({'target':target,'test':name,'category':category,'status':'ok','occurrences':1})

    # Keep the known collector binding defect visible and quantify its impact, while basing
    # every accepted result above on the correct raw Running binding.
    actual_by_target=collections.defaultdict(lambda:[0,0,0])
    for identity,counts in all_counts.items():
        for i in range(3): actual_by_target[identity][i]+=counts[i]
    recorded_by_target=collections.defaultdict(lambda:[0,0,0]); persisted_records=0
    for row in receipt['commands']:
        for item in row.get('observed_counts',[]):
            persisted_records+=1
            for i in range(3): recorded_by_target[tuple(item['target'])][i]+=item['counts'][i]
    affected_targets=sorted(k for k in set(actual_by_target)|set(recorded_by_target)
                            if actual_by_target[k]!=recorded_by_target[k])
    differences=reconstructed['collector_binding_differences']
    need(len(differences)==93,'raw reconstruction expected a dynamically observed 93 order-binding differences')
    # 107 receipts each have two raw streams: format, metadata, 104 builds, clean.
    for rec in [receipt['format_command'],receipt['metadata_command'],*receipt['commands'],receipt['clean_command']]:
        for kind in ('stdout','stderr'):
            p=Path(rec['streams'][kind]['path']); need(p.is_relative_to(outdir),f'raw stream escaped output tree: {p}')
    need(receipt.get('target_absent_before') is True and receipt.get('target_absent_after_clean') is True
         and not (ROOT/'target').exists() and not (ROOT/'target').is_symlink(),
         'target directory was not absent at the recorded and live final states')

    report={
      'schema':'independent-native-workspace-raw-audit-v1','status':'passed',
      'receipt':expected_receipt,
      'root_review':{'path':str(a.review.resolve()),'bytes':a.review.stat().st_size,'sha256':sha(a.review.read_bytes())},
      'native':{'seed':receipt['seed'],'target_count':reconstructed['target_count'],'batch_count':reconstructed['batch_count'],
                'workspace_totals':reconstructed['workspace_totals'],'source_pin_count':reconstructed['source_pin_count'],
                'source_pins_sha256':reconstructed['source_pins_sha256'],'raw_stream_count':raw_stream_count,
                'raw_stream_bytes':raw_stream_bytes,'raw_stream_pins_sha256':sha(json.dumps(sorted(raw_streams,key=lambda x:x['path']),sort_keys=True,separators=(',',':')).encode()),
                'default_stack_environment_verified':True,'guard_limits':receipt['guard_limits'],
                'format_metadata_and_clean_commands_verified':True,'target_absent_before_and_after':True},
      'running_bound_results':{'target_counts':[{'target':list(k),'counts':list(v)} for k,v in sorted(all_counts.items())],
                'normalized_counter_rows':counter_rows,'normalized_counter_sha256':counter_sha,
                'counter_shape':'[[target executable basename without 16-hex Cargo hash, full test name, status, multiplicity], ...]'},
      'critical_gates':{'count':len(gate_out),'each_once_and_ok':True,'groups':{
                field:{'count':sum(x['category']==field for x in gate_out),'gates':[x for x in gate_out if x['category']==field]}
                for field in CATEGORY_FIELDS}},
      'collector_binding_defect':{'raw_binding_differences_batches':len(differences),
                'persisted_observed_count_records':persisted_records,'targets_with_wrong_aggregate_attribution':len(affected_targets),
                'affected_target_names':[{'target':list(k),'actual_counts':list(actual_by_target[k]),
                                          'persisted_attribution':list(recorded_by_target[k])}
                                         for k in affected_targets],
                'accepted_authority':'Raw stdout harness results bound to stderr Cargo Running executable identity; receipt observed_counts ignored for attribution.'},
      'reconstruction':reconstructed,
      'limitations':['The raw native run is one fixed-seed full-workspace execution; this audit does not replace the separate two-seed own-CI comparison.']}
    a.out.parent.mkdir(parents=True,exist_ok=True); a.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'passed','targets':report['native']['target_count'],'batches':report['native']['batch_count'],
                      'totals':report['native']['workspace_totals'],'gates':len(gate_out),'binding_difference_batches':len(differences),
                      'affected_targets':len(affected_targets),'counter_sha256':counter_sha,'output':str(a.out)},ensure_ascii=False))
    return 0
if __name__=='__main__':
    try: raise SystemExit(main())
    except (AuditError,OSError,KeyError,TypeError,ValueError) as exc:
        print(f'INDEPENDENT NATIVE AUDIT FAILED: {exc}',file=sys.stderr); raise SystemExit(1)
