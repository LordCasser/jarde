# Attempt-1 CI fallback review

This is a read-only review of the prepared fallback package. The fallback package was not modified, and no network, Git, or toolchain command was run. `reproduce_zip_escape.py` is a Python-B-only offline proof of the blocking ZIP-to-log parsing defect.

Primary finding: `verify-own-ci-attempt1.py:449-450` emits literal backslash separators instead of actual tab/newline characters. Consequently, `workspace_groups()` sees both workspace-run markers in one physical line and rejects the expected two runs. Correct those Python string escapes before this fallback can produce an accepted 2-seed Counter.

Secondary acceptance input gap: the package requires exactly 15 caller-supplied supplemental gates but does not contain their expected identities. Supply and separately bind the authoritative 15-pair list before treating 156 as a complete fixed gate inventory.

See `review.json` for API/run/job/step/ZIP/source-fixture checks and exact evidence paths. The included offline protocol test passed, but it does not exercise ZIP-derived workspace log parsing.
