#!/usr/bin/env python3
"""Offline reproduction of fallback verifier's escaped newline regression."""
import importlib.util
from pathlib import Path
p=Path('/private/tmp/jarde-last-four-ci-attempt-fallback-prep-luna-v1-20261020/verify-own-ci-attempt1.py')
s=importlib.util.spec_from_file_location('fallback_verifier_repro',p)
m=importlib.util.module_from_spec(s); s.loader.exec_module(m)
# These are the runtime values produced by verifier source lines 449-450.
a=f"stable / test and specification\\tStable step\\t##[group]Run {m.WORKSPACE_COMMAND}\\nPROPTEST_RNG_SEED: 111"
b=f"stable / test and specification\\tStable step\\t##[group]Run {m.WORKSPACE_COMMAND}\\nPROPTEST_RNG_SEED: 222"
raw='\\n'.join([a,b])+'\\n'
print('actual_lines_after_splitlines',len(raw.splitlines()))
print('group_markers',raw.count('##[group]Run '+m.WORKSPACE_COMMAND))
try:
    m.workspace_groups(raw)
except Exception as exc:
    print(type(exc).__name__,str(exc))
else:
    raise SystemExit('unexpectedly accepted malformed escaped line protocol')
