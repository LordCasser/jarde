from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, stat, sys, zipfile
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode = True
EVIDENCE_DEFAULT = Path('/private/tmp/jarde-last-four-own-ci-root-v4-20261020')
REPO = Path('/Users/lordcasser/workspace/projects/jarde')
COMMON_PATH = Path('/private/tmp/jarde-last-four-native-ci-prep-luna-v1-20261019/common.py')
ADAPTER_PATH = Path('/private/tmp/jarde-last-four-native-ci-prep-luna-v1-20261019/verify-own-ci-loop45.py')
BASE_PATH = Path('/private/tmp/jarde-loop2-retry-native-ci-prep-luna-v2-20261019/verify-own-ci.py')
COLLECT_ARGV = Path('/private/tmp/jarde-last-four-closeout-tools-root-v1-20261019/ci-collect-v4-argv.json')
VERIFY_ARGV = Path('/private/tmp/jarde-last-four-closeout-tools-root-v1-20261019/ci-verify-v4-argv.json')
FIXED_CLI = Path('/private/tmp/jarde-last-four-final-static-build-root-v2-20261019/candidate-cli')
PINS = {
 'common.py':'1520d0ace42e09f82d6c463186da728206e3adb9a8a66401eb4dddbdd646ecc3',
 'verify-own-ci.py':'d45ac260085595f0d15402fc0baf5ee504d48b02c139e7950fd80f4e77d1d8b5',
 'verify-own-ci-loop45.py':'ba746d3a6c371569efb6d76b88d687b3a964f0ae36f929e50f92fae20f34ea37',
 'ci-collect-v4-argv.json':'8fb2b38c55e5c19cea238b99ef4fea7ccaa02345013c4158c9edde008619d0d0',
 'ci-verify-v4-argv.json':'a195f036f80e420b6e722185db4db24e83d460c063a74620038aeea8b5525f50',
 'acceptance-argv.json':'c324c6b205e7a2eda920613a48ca7891e82f1218f5829c716e5c56b464662741',
}
PRODUCT='8ea98e2e11d64f02092ac200d2b596511dcf5e40'
CLI_SHA='ed74e005c1bc97bcdf4a15f6a27da9e9d8a1ecdf7fe576836820ed2ce323222d'
CLI_BYTES=64754240
RUN_ID='39278336384'
EXPECTED_MISSING_FIRST='stable _ test and specification/2_Run actions_checkout@v4.txt'

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p): return sha_bytes(Path(p).read_bytes())
def need(ok,msg):
 if not ok: raise ValueError(msg)
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path)
 need(spec is not None and spec.loader is not None, f'cannot load module {path}')
 mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
def raw_pin(path):
 p=Path(path); b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha_bytes(b)}
def argv_values(argv, flag):
 out=[]
 for i,x in enumerate(argv[:-1]):
  if x==flag: out.append(argv[i+1])
 return out
def verify_argv_docs():
 docs={}
 for name,path in [('ci-collect-v4-argv.json',COLLECT_ARGV),('ci-verify-v4-argv.json',VERIFY_ARGV)]:
  b=path.read_bytes();need(sha_bytes(b)==PINS[name],f'{name} pin mismatch')
  a=json.loads(b);need(isinstance(a,list) and all(isinstance(x,str) for x in a),f'{name} schema')
  need(PRODUCT in a and CLI_SHA in a,f'{name} missing product/CLI pin')
  docs[name]=a
 c,v=docs['ci-collect-v4-argv.json'],docs['ci-verify-v4-argv.json']
 cs=argv_values(c,'--source-file');vs=argv_values(v,'--source-file')
 cf=argv_values(c,'--fixture-root');vf=argv_values(v,'--fixture-root')
 cg=argv_values(c,'--supplemental-gate');vg=argv_values(v,'--supplemental-gate')
 need(cs==vs and len(cs)==11,'collector/verifier source-file argv inventory mismatch')
 need(cf==vf and len(cf)==2,'collector/verifier fixture-root argv inventory mismatch')
 need(cg==vg and len(cg)==15,'collector/verifier supplemental-gate argv inventory mismatch')
 need(c[0]=='python3' and v[0]=='python3','frozen argv executable mismatch')
 return {'source_files':cs,'fixture_roots':cf,'supplemental_gates':cg,'collector_argv':c,'verifier_argv':v}
def cli_binding():
 p=FIXED_CLI
 need(p.is_file() and not p.is_symlink(),'fixed candidate CLI missing/unsafe')
 b=p.read_bytes(); mode=stat.S_IMODE(p.stat().st_mode)
 need(len(b)==CLI_BYTES and sha_bytes(b)==CLI_SHA and mode==0o555,'fixed candidate CLI pin mismatch')
 return {'path':str(p),'bytes':len(b),'sha256':sha_bytes(b),'mode':format(mode,'04o'),'checked_without_execution':True}
def zip_audit(e,api):
 zpath=e/'run-logs.zip'; copy=e/'official-zip-attempt-1.zip'
 zraw=zpath.read_bytes();need(zraw==copy.read_bytes(),'official ZIP retry is not byte-identical')
 supp=json.loads((e/'step-log-supplement.json').read_text())
 coll=(e/'collection.json').read_bytes();run=(e/'run.json').read_bytes()
 need(supp['argv']==['gh','api',f'repos/LordCasser/jarde/actions/runs/{RUN_ID}/logs'] and supp['exit_code']==0,'ZIP supplement command mismatch')
 need(supp['run_id']==RUN_ID and supp['product_sha']==PRODUCT,'ZIP supplement identity mismatch')
 need(supp['collection_json_sha256']==sha_bytes(coll) and supp['run_json_sha256']==sha_bytes(run),'ZIP supplement receipt binding mismatch')
 for ch in ('stdout','stderr'):
  row=supp['streams'][ch];p=Path(row['path']);b=p.read_bytes()
  need(p.parent==e and len(b)==row['bytes'] and sha_bytes(b)==row['sha256'],'ZIP supplement stream pin mismatch')
  need(supp['transport_attempts'][0][ch]['sha256']==row['sha256'],'ZIP transport raw pin mismatch')
 with zipfile.ZipFile(zpath) as z:
  names=z.namelist();need(len(names)==len(set(names))==44,'ZIP entry inventory differs')
  found=[];missing=[]
  for j in api['jobs']:
   folder=j['name'].replace('/','_')
   for s in j['steps']:
    member=f"{folder}/{s['number']}_{s['name'].replace('/','_')}.txt"
    (found if member in names else missing).append({'job':j['name'],'job_id':j['id'],'step_number':s['number'],'step_name':s['name'],'member':member})
 need((len(found),len(missing))==(38,14),'ZIP per-step member coverage differs from frozen observed boundary')
 need(len([n for n in names if n.endswith('.txt')])==44,'ZIP member inventory differs')
 return {'bytes':len(zraw),'sha256':sha_bytes(zraw),'retry_byte_identical':True,'entries':len(names),'exact_step_members_present':len(found),'exact_step_members_missing':len(missing),'missing':missing,'strict_validator_status':'failed','strict_validator_reason':'official ZIP lacks independent per-step member: '+missing[0]['member'],'whole_job_aggregate_logs':4,'system_entries':2}
def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--evidence',type=Path,default=EVIDENCE_DEFAULT)
 ap.add_argument('--out',type=Path,required=True)
 args=ap.parse_args();e=args.evidence.resolve();out=args.out
 need(e.is_dir() and not e.is_symlink(),'evidence directory missing/unsafe')
 need(not out.exists(),'refusing to overwrite report')
 argv=verify_argv_docs(); cli=cli_binding()
 c=json.loads((e/'collection.json').read_text());run=json.loads((e/'run.json').read_text());api=json.loads((e/'jobs-api.json').read_text());inputs=json.loads((e/'final-adapter-inputs.json').read_text());pins=json.loads((e/'source-pins.json').read_text())
 need(c['run_id']==RUN_ID and c['product_sha']==PRODUCT and c['cli_sha256']==CLI_SHA,'collector receipt identity mismatch')
 need(inputs['run_id']==RUN_ID and inputs['product_sha']==PRODUCT and inputs['cli_sha256']==CLI_SHA,'adapter inputs identity mismatch')
 need(inputs['source_files']==argv['source_files'] and inputs['fixture_roots']==argv['fixture_roots'],'actual supplemental argv differs from frozen inputs')
 need(inputs['supplemental_gates']==[dict(target=x.split('=',1)[0],test=x.split('=',1)[1]) for x in argv['supplemental_gates']],'supplemental gates differ from frozen argv')
 common=load(COMMON_PATH,'contract_common');sys.modules['common']=common
 old=common.load_pinned('verify-own-ci.py','contract_frozen_verifier')
 adapter=load(ADAPTER_PATH,'contract_loop45_adapter')
 need(sha_file(BASE_PATH)==PINS['verify-own-ci.py'] and sha_file(ADAPTER_PATH)==PINS['verify-own-ci-loop45.py'],'frozen verifier module changed')
 # Extend the frozen verifier's complete source and fixture census with the exact closeout argv inventory.
 extension=common.extend_ci_inventory(old,source_files=argv['source_files'],fixture_roots=argv['fixture_roots'])
 need(extension['supplemental_source_files']==argv['source_files'] and extension['supplemental_fixture_roots']==argv['fixture_roots'],'common extension did not load frozen inventory')
 collection_validation=old.validate_collection(e,PRODUCT,common.ROOT)
 need(len(pins['source_files'])==40 and len(pins['fixture_files'])==166 and pins['fixture_file_count']==166,'complete source/fixture pin counts differ')
 # Frozen original verifier's strict API+ZIP acceptance is run unmodified and must fail only on exact missing member evidence.
 workflow,workflow_jobs,seeds=old.workflow_contract(common.ROOT/'.github/workflows/ci.yml')
 strict_error=None
 try:
  old.validate_ci(e,PRODUCT,workflow_jobs)
 except ValueError as exc:
  strict_error=str(exc)
 need(strict_error is not None and strict_error.startswith('official ZIP lacks independent per-step member: '),'frozen strict validator failure was not the expected ZIP member boundary')
 # Independent task-contract check of API/job/step rows; this reads original responses as captured.
 need(run.get('databaseId')==int(RUN_ID) and run.get('headSha')==PRODUCT and run.get('status')=='completed' and run.get('conclusion')=='success' and run.get('workflowName')=='CI','run response identity/status mismatch')
 jobs=api.get('jobs');need(api.get('total_count')==4 and isinstance(jobs,list) and len(jobs)==4,'jobs API has wrong job count')
 need(set(j['name'] for j in jobs)==set(old.EXPECTED_JOBS.values()),'jobs API names differ')
 by_name={j['name']:j for j in jobs}; run_by_name={j['name']:j for j in run['jobs']}
 need(set(run_by_name)==set(by_name),'run jobs and API job names differ')
 api_steps_total=0; job_reports=[]
 for job_id,display in old.EXPECTED_JOBS.items():
  j=by_name[display]; rj=run_by_name[display]
  need(j['id']==rj['databaseId'] and j['run_id']==int(RUN_ID) and j['run_attempt']==1 and j['head_sha']==PRODUCT,'job run/head/attempt identity mismatch: '+display)
  need(j['status']==rj['status']=='completed' and j['conclusion']==rj['conclusion']=='success','job completion mismatch: '+display)
  left,right=rj['steps'],j['steps'];need(len(left)==len(right) and left,'run/API step counts differ: '+display)
  for a,b in zip(left,right):
   need(a['name']==b['name'],'run/API step order/name differs: '+display)
   need(a['status']==b['status']=='completed' and a['conclusion']==b['conclusion']=='success','non-success API step: '+display+'/'+b['name'])
  names=[s['name'] for s in right]; expected=workflow_jobs[job_id]['api_steps']
  observed=[n for n in names if n not in ('Set up job','Complete job') and not n.startswith('Post ')]
  need(observed==expected and names[0]=='Set up job' and names[-1]=='Complete job','workflow API sequence/lifecycle differs: '+display)
  need(len(names)==len(expected)+sum(n.startswith('Post ') for n in names)+2 and len(names)==len(set(names)),'unexpected API step/post inventory: '+display)
  api_steps_total+=len(right);job_reports.append({'id':j['id'],'name':display,'steps':len(right),'all_completed_success':True})
 need(api_steps_total==52,'API step count is not 52')
 # Reopen and bind all four direct raw job logs to the official CLI requests and transport copies.
 log_files={'stable / test and specification':'stable.log','MSRV 1.88.0':'msrv.log','supply chain':'supply-chain.log','fuzz smoke':'fuzz-smoke.log'}
 logs={}
 commands=c['commands']
 for name,filename in log_files.items():
  j=by_name[name]; row=next((x for x in commands if x.get('argv')==['gh','run','view',RUN_ID,'--repo','LordCasser/jarde','--job',str(j['id']),'--log']),None)
  need(row is not None and row['exit_code']==0,'missing successful exact job-log command: '+name)
  p=e/filename;b=p.read_bytes();stream=row['streams']['stdout']
  need(stream['path']==str(p) and stream['bytes']==len(b) and stream['sha256']==sha_bytes(b),'job raw log receipt pin mismatch: '+name)
  need(row['transport_attempts'][0]['streams']['stdout']['sha256']==sha_bytes(b) and (e/(filename+'.transport-attempt-1')).read_bytes()==b,'job transport raw does not match: '+name)
  need((e/(filename+'.stderr.raw')).read_bytes()==b'','job command stderr nonempty: '+name)
  logs[name]=b.decode('utf-8-sig')
 # Reconstruct exact 156 gates, parse both complete seed groups, and compare full triple counters.
 acceptance=json.loads((common.BASE/'acceptance-argv.json').read_text())
 extra=argv_values(acceptance['verify_ci'],'--extra-critical')
 need(len(extra)==13,'frozen base critical-gate supplement count differs')
 for i,item in enumerate(extra,1):
  t,n=item.split('=',1);old.CRITICAL_TESTS[f'Frozen extra {i}']=(n,t)
 need(len(old.CRITICAL_TESTS)==123,'base verifier gate inventory differs')
 supplemental=[(g['target'],g['test']) for g in inputs['supplemental_gates']]
 all_loop45=list(common.REGION_GATES)+list(common.PUBLIC_GATES)+list(common.DEFERRED_BUILDER_GATES)+supplemental
 need(len(all_loop45)==33 and len(set(all_loop45))==33,'Loop45 supplemental gate inventory differs')
 for i,(t,n) in enumerate(all_loop45,1):old.CRITICAL_TESTS[f'Loop45 supplemental {i}: {t}::{n}']=(n,t)
 need(len(old.CRITICAL_TESTS)==156,'combined exact gate count differs')
 groups=old.workspace_groups(logs['stable / test and specification']);need(len(groups)==2 and len(seeds)==2,'expected two workflow seed groups')
 reports=[]; counters=[]
 for group,seed in zip(groups,seeds):
  parsed=old.parse_workspace_group(group,seed);ctr=adapter.named_outcome_counter(old,group);counters.append(ctr)
  need(parsed['named_test_outcomes']==3954 and sum(ctr.values())==3954 and len(ctr)==3954,'seed complete outcome count differs')
  need(parsed['target_count']==396 and parsed['workspace_totals']=={'passed':3856,'failed':0,'ignored':98,'measured':0,'filtered':0},'seed target/totals differ')
  need(len(parsed['critical_tests_passed'])==156,'not all exact gates passed under seed '+seed)
  reports.append({'seed':seed,'target_binaries':parsed['target_count'],'named_outcomes':parsed['named_test_outcomes'],'workspace_totals':parsed['workspace_totals'],'critical_exact_gates_passed':len(parsed['critical_tests_passed']),'counter_entries':len(ctr)})
 adapter.compare_seed_counters(*counters)
 archive=zip_audit(e,api)
 need(archive['strict_validator_reason']==strict_error,'strict validator/archive boundary mismatch')
 report={
  'schema':'jarde-last-four-ci-task-contract-acceptance-v2',
  'status':'accepted_for_task_contract_with_official_export_gap',
  'strict_per_step_zip_status':'failed',
  'run':{'id':RUN_ID,'product_sha':PRODUCT,'status':run['status'],'conclusion':run['conclusion'],'workflow':run['workflowName'],'run_attempt':1,'jobs':job_reports,'api_steps':api_steps_total,'all_api_steps_completed_success':True,'numeric_per_step_exit_codes_claimed':False},
  'direct_job_logs':{n:raw_pin(e/fn) for n,fn in log_files.items()},
  'captured_receipts':{n:raw_pin(e/n) for n in ('collection.json','run.json','jobs-api.json','source-pins.json','final-adapter-inputs.json','step-log-supplement.json','run-logs.zip','official-zip-attempt-1.zip')},
  'seed_runs':reports,
  'seed_counters_identical':True,
  'source_binding':{'source_count':len(pins['source_files']),'fixture_file_count':len(pins['fixture_files']),'old_validate_collection':'passed','source_before_after_equal':c['source_before_after_equal'],'target_absent_after':c['target_absent_after'],'extension_inventory':extension},
  'archive':archive,
  'product_and_cli':{'product_sha':PRODUCT,'cli':cli},
  'strict_validator':{'status':'failed','validator':'frozen validate_ci, unmodified','failure':strict_error},
  'frozen_inputs':{'common':raw_pin(COMMON_PATH),'base_verifier':raw_pin(BASE_PATH),'loop45_adapter':raw_pin(ADAPTER_PATH),'collect_argv':raw_pin(COLLECT_ARGV),'verify_argv':raw_pin(VERIFY_ARGV),'acceptance_argv':raw_pin(common.BASE/'acceptance-argv.json')},
  'limitations':['The official API reports each workflow step as completed/success; this report does not claim numeric exit codes for individual steps.','The official ZIP contains 38 exact independent step members and omits 14. Aggregate job log text is not relabeled as independent step members.']
 }
 out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'status':report['status'],'strict_per_step_zip_status':report['strict_per_step_zip_status'],'api_steps':api_steps_total,'archive':{k:archive[k] for k in ('entries','exact_step_members_present','exact_step_members_missing')},'seed_runs':reports,'report':str(out)},indent=2))
if __name__=='__main__':
 main()
