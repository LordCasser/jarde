#!/usr/bin/env python3
from __future__ import annotations
import collections, hashlib, importlib.util, json, pathlib, sys, zipfile

PROBE = pathlib.Path('/private/tmp/jarde-last-four-ci-run-logs-probe-root-v2-20261020')
CI = pathlib.Path('/private/tmp/jarde-last-four-own-ci-root-v3-20261020')
NATIVE_REVIEW = pathlib.Path('/private/tmp/jarde-last-four-native-root-v1-20261019/review.json')
FALLBACK = pathlib.Path('/private/tmp/jarde-last-four-ci-attempt-fallback-prep-luna-v2-20261020')
ACCEPTANCE = pathlib.Path('/private/tmp/jarde-loop2-retry-native-ci-prep-luna-v2-20261019/acceptance-argv.json')
WORKFLOW = pathlib.Path('/Users/lordcasser/workspace/projects/jarde/.github/workflows/ci.yml')
EXPECTED_ZIP_SHA = 'a8bfc7520db8b337c67219b8b8d8f4979ca23d26dd4b4d407cb4d73029b6b25e'
EXPECTED_COUNTER_SHA = '6bc624d48ecbba140da74106a7123758b3e387c4baa2a3ea2ff337ddf8cba966'
EXPECTED_RUN_ID = 39278336384
EXPECTED_HEAD = '8ea98e2e11d64f02092ac200d2b596511dcf5e40'
EXPECTED_PRODUCT = '8ea98e2e11d64f02092ac200d2b596511dcf5e40'
EXPECTED_CLI = 'ed74e005c1bc97bcdf4a15f6a27da9e9d8a1ecdf7fe576836820ed2ce323222d'

def sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load_module(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    if not spec or not spec.loader: raise AssertionError(f'cannot load {path}')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def main():
    execution=json.loads((PROBE/'execution.json').read_text())
    streams=execution['streams']
    zip_path=pathlib.Path(streams['stdout']['path'])
    zip_sha=sha(zip_path)
    assert execution['status']=='closed' and execution['exit_code']==0
    assert execution['argv']==['gh','api',f'repos/LordCasser/jarde/actions/runs/{EXPECTED_RUN_ID}/logs']
    assert streams['stdout']['bytes']==794203 and zip_sha==EXPECTED_ZIP_SHA
    assert streams['stderr']['bytes']==0
    coll=json.loads((CI/'collection.json').read_text())
    assert coll['run_id']==EXPECTED_RUN_ID and coll['product_sha']==EXPECTED_PRODUCT and coll['cli_sha256']==EXPECTED_CLI
    assert coll['status']=='collection failed; no CI accepted'
    assert 'stable / test and specification' in coll['failure']
    command_pins={}
    for cmd in coll['commands']:
        row=cmd['streams']['stdout']; p=pathlib.Path(row['path'])
        assert cmd['exit_code']==0 and p.is_file()
        assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
        command_pins[cmd['argv'][0]+' '+cmd['argv'][1]]=row['sha256']
        attempt=cmd['transport_attempts'][0]['streams']['stdout']
        ap=pathlib.Path(attempt['path'])
        assert ap.stat().st_size==attempt['bytes'] and sha(ap)==attempt['sha256']==row['sha256']
    run=json.loads((CI/'run.json').read_text())
    api=json.loads((CI/'jobs-api.json').read_text())
    assert run['databaseId']==EXPECTED_RUN_ID and run['headSha']==EXPECTED_HEAD
    assert run['status']=='completed' and run['conclusion']=='success'
    assert api['total_count']==4 and len(api['jobs'])==4
    jobs=api['jobs']
    assert all(j.get('run_id')==EXPECTED_RUN_ID and j.get('head_sha')==EXPECTED_HEAD and j.get('run_attempt')==1 for j in jobs)
    job_by_name={j['name']:j for j in jobs}
    assert len(job_by_name)==4
    assert job_by_name['stable / test and specification']['status']=='in_progress'
    assert job_by_name['stable / test and specification']['conclusion'] is None
    z=zipfile.ZipFile(zip_path)
    assert z.testzip() is None
    names=z.namelist()
    assert len(names)==len(set(names))==44
    actual=set(names)
    expected_step=set()
    expected_aggregate=set()
    for index,job in enumerate(jobs):
        display=job['name'].replace('/','_')
        expected_aggregate.add(f'{index}_{display}.txt')
        for step in job['steps']:
            safe=step['name'].replace('/','_')
            expected_step.add(f'{display}/{step["number"]}_{safe}.txt')
    present_api=expected_step & actual
    missing_api=sorted(expected_step-actual)
    system={n for n in actual if n.endswith('/system.txt')}
    assert actual==present_api|expected_aggregate|system
    assert len(expected_step)==52 and len(present_api)==38 and len(missing_api)==14
    assert len(expected_aggregate)==4 and expected_aggregate<=actual and len(system)==2
    stable_missing=[n for n in missing_api if n.startswith('stable _ test and specification/')]
    fuzz_missing=[n for n in missing_api if n.startswith('fuzz smoke/')]
    assert len(stable_missing)==5 and len(fuzz_missing)==9 and len(missing_api)==14
    # The missing members are documented by exact API-derived paths; aggregates are not substituted.
    present_names=sorted(present_api)
    _,_,seeds=load_module('old_ci',FALLBACK/'verify-own-ci-attempt1.py').workflow_contract(WORKFLOW)
    # Load exact frozen parser and counter projection used by this workflow's 156-gate verifier.
    common=load_module('loop45_common',FALLBACK/'common.py')
    sys.modules['common']=common
    l45=load_module('loop45_verifier',FALLBACK/'verify-own-ci-loop45-attempt1.py')
    old=l45.load_local(FALLBACK/'verify-own-ci-attempt1.py','old_ci_parser')
    acceptance=json.loads(ACCEPTANCE.read_text())['verify_ci']
    extra=[acceptance[i+1] for i,t in enumerate(acceptance[:-1]) if t=='--extra-critical']
    argv=json.loads((FALLBACK/'ci-verify-argv.json').read_text())
    explicit=[argv[i+1] for i,t in enumerate(argv[:-1]) if t=='--supplemental-gate']
    supplemental=explicit+[f'{target}={test}' for group in (common.REGION_GATES,common.PUBLIC_GATES,common.DEFERRED_BUILDER_GATES) for target,test in group]
    assert len(extra)==13 and len(explicit)==15 and len(supplemental)==33
    for label,items in [('acceptance',extra),('supplemental',supplemental)]:
        for i,item in enumerate(items):
            target,test=item.split('=',1)
            old.CRITICAL_TESTS[f'{label} {i+1}']=(test,target)
    assert len(old.CRITICAL_TESTS)==156 and len(set(old.CRITICAL_TESTS.values()))==156
    stable=job_by_name['stable / test and specification']
    log_by_number={s['number']:f'stable _ test and specification/{s["number"]}_{s["name"].replace("/","_")}.txt' for s in stable['steps']}
    # Parse only independent step 8/9 members. No aggregate job log is used to fill absent members.
    raw='\n'.join(z.read(log_by_number[n]).decode('utf-8-sig') for n in (8,9))
    groups=old.workspace_groups(raw)
    assert len(groups)==2
    projections=[]; counters=[]; seed_summaries=[]
    for seed,group in zip(seeds,groups):
        parsed=old.parse_workspace_group(group,seed)
        passed=parsed['critical_tests_passed']
        assert len(passed)==156 and set(passed)==set(old.CRITICAL_TESTS)
        assert parsed['target_count']==396
        assert parsed['workspace_totals']=={'passed':3856,'failed':0,'ignored':98,'measured':0,'filtered':0}
        counter=l45.named_outcome_counter(old,group)
        rows=l45.counter_rows(counter)
        digest=l45.counter_sha256(counter)
        assert len(counter)==3954 and sum(counter.values())==3954
        assert all(count==1 for count in counter.values())
        projections.append(parsed)
        counters.append(counter)
        seed_summaries.append({'seed':seed,'target_count':parsed['target_count'],'workspace_totals':parsed['workspace_totals'],'critical_gate_count':len(passed),'critical_gates_passed':True,'counter_count':sum(counter.values()),'counter_unique_triples':len(counter),'counter_sha256':digest,'counter_rows':rows})
    assert counters[0]==counters[1]
    native=json.loads(NATIVE_REVIEW.read_text())
    assert native['status']=='passed'
    native_totals=native['workspace']['workspace_totals']
    report={
      'schema':'closed-ci-run-logs-partial-independent-review-v1',
      'status':'partial_evidence_only',
      'ci_acceptance':'not_accepted: run view is completed/success, but jobs API stable job remains in_progress with null conclusion',
      'run':{'id':EXPECTED_RUN_ID,'head_sha':EXPECTED_HEAD,'product_sha':coll['product_sha'],'cli_sha256':coll['cli_sha256'],'run_status':run['status'],'run_conclusion':run['conclusion'],'attempt':1,'jobs_api_total_count':api['total_count']},
      'input_pins':{'logs_execution_sha256':sha(PROBE/'execution.json'),'zip_stdout_sha256':zip_sha,'zip_stdout_bytes':zip_path.stat().st_size,'collection_sha256':sha(CI/'collection.json'),'run_json_sha256':sha(CI/'run.json'),'jobs_api_sha256':sha(CI/'jobs-api.json'),'native_review_sha256':sha(NATIVE_REVIEW)},
      'zip_inventory':{'members_total':len(names),'aggregate_job_logs':sorted(expected_aggregate),'api_steps_expected':len(expected_step),'api_step_members_present':len(present_api),'api_step_members_missing':missing_api,'synthetic_system_members':sorted(system),'crc_check':'passed','unlisted_members':[]},
      'step_log_comparison':{'stable_missing_count':len(stable_missing),'fuzz_missing_count':len(fuzz_missing),'missing_steps_filled_from_aggregate':False,'independent_seed_members':[log_by_number[8],log_by_number[9]],'seeds':seed_summaries,'counter_equal_across_seeds':True,'native_expected_counter_sha256':EXPECTED_COUNTER_SHA,'ci_counter_sha256':seed_summaries[0]['counter_sha256'],'counter_matches_native_expected':seed_summaries[0]['counter_sha256']==EXPECTED_COUNTER_SHA,'native_workspace_totals':native_totals},
      'interpretation':'All 156 exact gate identities are present and pass in both independent fixed-seed step logs. Both seed logs have 3,954 named (target,test,status) observations and their counters match each other. The requested native-counter SHA differs from the exact frozen CI-verifier projection; cross-source Counter equality is therefore not established. Missing ZIP step members remain missing; the stable job has no terminal conclusion in the captured jobs API. This report is not full CI acceptance.'
    }
    out=pathlib.Path(__file__).resolve().parent/'review.json'
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    return report

if __name__=='__main__':
    r=main()
    print(json.dumps({k:r[k] for k in ('status','ci_acceptance','zip_inventory','step_log_comparison')},ensure_ascii=False,indent=2))
