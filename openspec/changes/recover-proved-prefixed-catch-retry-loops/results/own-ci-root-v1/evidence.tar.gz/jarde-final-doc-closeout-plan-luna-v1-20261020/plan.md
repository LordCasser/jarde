# 最终文档收口建议（私有只读检查点，2026-10-20）

CI `39278336384` 仍在运行；本计划没有读取 run/watch，不写任何“自身 CI 已通过”。全部建议只有在该 run 和最终交付检查确实成功后执行。当前产品本机验收已在 main，native 与最终三方结果已闭合。

## 最小闭环顺序

1. 先保存本产品 CI 的独立结果页（建议放在 prefixed change 的 `results/own-ci-root-v1/README.md`），只在 GitHub 官方四 jobs/全部 step ZIP 原流、双 seed 完整 `(target,test,status)` Counter、source binding 与最终 CLI SHA 都按实际通过后写接受。不要把 run-level HTTP 502 的早期观察或本机结果拼成 CI 通过。
2. CI 与最终 main/远端/clean/target 检查均通过后，两份 `tasks.md` 只将3.3和3.4从`[ ]`改为`[x]`，变为8/8；保存实际失败历史，不重写既有 raw JSON/收据。若最终文档 commit 后需要实时交付检查，应在 handoff 说明该检查实际针对哪个 HEAD。
3. 两项 result README 补本产品 own-CI 链接及准确信息，再将 change 归档到约定目录：
   - `recover-proved-post-test-loop-return-leaves` → `archive/2026-10-20-recover-proved-post-test-loop-return-leaves`
   - `recover-proved-prefixed-catch-retry-loops` → `archive/2026-10-20-recover-proved-prefixed-catch-retry-loops`
4. 更新最上方“当前状态”段：`handoff.md`、JADX `summary.md`、`control-flow.md`。结论区分 **固定原件账本 12 accepted + 1 明确 Smali/Dex 输入边界** 与 **CF09、71 unit、612 Java files 仍 partial**；不要把这次交付写成 CF09 / 71 / 612 已关闭。

## 精确 Markdown 链接迁移

下面只改 Markdown link destination。JSON、raw、pin、tar 的历史 `original_path` 保持原样。

| 文件位置 | 归档后的目的地 |
|---|---|
| `handoff.md` task link: `openspec/changes/recover-proved-post-test-loop-return-leaves/tasks.md` | `openspec/changes/archive/2026-10-20-recover-proved-post-test-loop-return-leaves/tasks.md` |
| `handoff.md` task link: `openspec/changes/recover-proved-prefixed-catch-retry-loops/tasks.md` | `openspec/changes/archive/2026-10-20-recover-proved-prefixed-catch-retry-loops/tasks.md` |
| `handoff.md` final-comparison link | `openspec/changes/archive/2026-10-20-recover-proved-prefixed-catch-retry-loops/results/final-comparison-root-v1/README.md` |
| `handoff.md` native link | `openspec/changes/archive/2026-10-20-recover-proved-prefixed-catch-retry-loops/results/native-accepted-root-v1/README.md` |
| `control-flow.md` links above | same destinations with `../../changes/archive/2026-10-20-...` prefix |
| post-test `results/README.md` link to prefixed final-comparison/native | `../../2026-10-20-recover-proved-prefixed-catch-retry-loops/results/{final-comparison-root-v1,native-accepted-root-v1}/README.md` |

`summary.md` links only to `control-flow.md` for this current-status paragraph; that link remains valid. Search confirmed these are the Markdown files linking to either active change name.

## 文件级改动建议

- `handoff.md`: 当前首段从“CI待闭合 / 各6/8”切换到实测完成态，链接改归档位置；加 GitHub run URL、实际 job/step 与 Counter 摘要、own-CI evidence link。保持源码产品 revision、CLI SHA 和最终文档 HEAD 的含义分开，不能把 docs-only commit 当成被测产品 revision。保留 v6 事实的精确措辞：Luna首轮attempt失败，root清理后用原v6 auditor重跑exit0并接受。保留 `observed_counts` 错配说明、Loop3 88 / retry-control 71 与旧 Loop5 103 三项分离、Do3 Iterator 字段债务、NYI≠JADX失败、Loop6真实Smali/Dex输入边界。
- `summary.md`: 只更新文件顶部的2026-10-19当前状态段为新日期、两项8/8、CI实际结果、固定原件12+1边界；保留71单元/612文件口径和所有历史小节原样。
- `control-flow.md`: 更新顶部当前项的状态/证据链接/计数，转为12+1；现有“以下为历史”之后的9接受、4待基线等旧快照保留不改。
- post-test `results/README.md`: 删除“CI与最终交付待关闭、6/8”，简短指向最终comparison、native与own-CI结果；两条同 change 间的相对链接迁移到归档兄弟目录。
- prefixed `results/final-comparison-root-v1/README.md`: 原三方事实和 v6 两次执行区别保留；将“自身CI与最终交付另行闭合”改为指向新own-CI结果页。不要改封存 tar/raw 或将Luna旧失败改写为通过。
- prefixed `results/native-accepted-root-v1/README.md`: 最末“CI尚需”改为 CI 已接受及 `../own-ci-root-v1/README.md` 链接。
- 两个 `tasks.md`: 仅在 CI、本产品完整门、规格同步/strict、持久归档及交付检查全部实际通过时勾 3.3、3.4；不要提前按预期CI更新。
- 两个 `design.md`: migration plan 是已执行的历史步骤；不改架构决策，只在计划尾加一行指向归档验收，避免把整段过程改写成另一份结果报告。proposal scope 不需要改。

## 归档内容和审阅风险

主 spec delta、proposal/design/tasks/results 一起移入各自 archive change；spec sync 发生在归档前后都需验证主 spec 中两个新 requirement/scenario仍存在且 strict OpenSpec通过。归档后运行 Markdown 相对链接检查，尤其是 post-test `results/README.md` 指向 prefixed sibling archive 的相对路径。不要因为两份 change 均8/8就更改 CF09/71/612 总账，不要将 `@NotYetImplemented`/JUnit disabled 注释解释为当前JADX产物失败；Do3没有target check，外层JUnit断言未运行。mapping 缺口88和71是独立物理 goto 缺口，与Loop5 103不推断共同根因。

准确接受数应写作“固定13个原件中12个接受；Loop6保留为已证明的Smali/Dex输入支持边界”，不要把它叫作12/13完全覆盖、CF09完成或总测试数增加。
