# Final Markdown closeout patch

`docs-closeout.patch` is a unified diff against the current active paths in the Jarde checkout. It changes only ten Markdown files in the private preview; no shared file was written.

Apply it only after both changes are moved to their dated archive directories, the post-archive `openspec validate --all --strict` run and final path checks are recorded, and the own-CI results page at `recover-proved-prefixed-catch-retry-loops/results/own-ci-root-v1/README.md` has been created. The task checkboxes express that final state; this preparation does not claim the archive or post-archive checks have happened.

The text distinguishes OpenSpec strict validation (currently 390 passing, 0 failing; rerun after archive) from the private CI ZIP-member strict gate (failed: 38 of 52 members present). It also records that CI contract auditor v3 was rerun and accepted the task contract from API evidence, job-ID-collected raw streams, the original ZIP aggregate, successful status for 52 official steps, stable full counters for both seeds, and source binding. It does not claim complete fuzz CLI raw logs or fabricate missing ZIP members. Counter equivalence is source-bound and accounts for the `should_panic` suffix and one GitHub-masked name; literal raw-name equality is not claimed.

The patch preserves the old failed Luna v6 attempt and the root's later successful rerun distinction, keeps Loop3 BCI 88 and control BCI 71 separate from old Loop5 BCI 103, records 12 accepted originals plus the Loop6 Smali/Dex input boundary, and leaves CF09/71/612 and the Iterator / `observed_counts` debts open.

`manifest.json` pins the before/preview hashes for every file and the patch. `preview/` contains the proposed post-edit Markdown only.
