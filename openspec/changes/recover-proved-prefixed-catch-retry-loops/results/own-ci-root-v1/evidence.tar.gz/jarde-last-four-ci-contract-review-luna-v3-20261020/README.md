# Last-four CI contract audit, v3

`contract_accept_ci.py` is an offline acceptance adapter for the closed v4 collection. It loads the frozen base verifier and Loop45 common/adapter files by pinned SHA, extends the original complete source and fixture census with the exact frozen closeout argv inventory, and invokes the original `validate_collection` and unmodified `validate_ci` functions.

Before importing `common.py` or reading `acceptance-argv.json`, the script checks both fixed SHA-256 pins. It also preserves the original post-action checks (unique `Post ` names, each tied to a workflow step), and stores both parsed seed reports while requiring complete target inventories and target summaries to match.

The task-contract report is accepted while preserving the independent export gap: official API reports 52 successful completed steps; the official ZIP has 44 entries, including 38 exact step members and 14 missing step members. The original strict validator remains recorded as failed at the first missing member. No aggregate log is reclassified as a step member and no numeric per-step exit code is claimed. Both direct seed logs are parsed as full 3,954-entry outcome Counters with 156 exact gates and compared byte-observation-wise by `(target, test, status)`.

The candidate CLI is only read to verify its fixed byte length, mode, and SHA. No network, Git, Rust, Java, CLI, or workspace mutation is performed.

For an independent rerun, provide a new output path because the script refuses to overwrite:

```sh
python3 -B /private/tmp/jarde-last-four-ci-contract-review-luna-v3-20261020/contract_accept_ci.py \
  --evidence /private/tmp/jarde-last-four-own-ci-root-v4-20261020 \
  --out /private/tmp/jarde-last-four-ci-contract-review-root-rerun-v3-20261020/contract-report.json
```

The generated report is `contract-report.json`; `pins.json` binds this script, the report, and the frozen external inputs.
