# B v6 auditor rerun clarification (private, independent)

The root executed the Luna-authored v6 audit script again after resolving the live `target/` gate. I independently reopened the closed root-v2 launcher record, stdout/stderr, the exact script, v6 pins, and the root-v3 review. The launcher argv names `audit_control_v6.py`, its SHA-256 matches both `pins.json` and the archived script bytes, exit status is 0, stdout reports `accepted_with_mapping_debt`, zero errors and 105 commands, and stderr is empty. The root review binds the B v2 receipt and records 105 commands, 210 raw streams, 20 compiles, 40 generated runtime cells, 20 wrong-root controls, with the BCI 71 mapping debt.

The earlier Luna v6 attempt in `attempt-1-live-target-gate.json` still says `audit_failed`: it saw a concurrent live workspace `target/` although the closed B receipt itself had `target_absent_finally=true`. This clarification records two distinct executions. It does not rewrite the failed attempt. The root's later rerun of the same v6 auditor passed and produced the accepted root review.

See `v6-rerun-review.json` for exact paths, hashes and assertions. Run `python3 -B verify_v6_root_rerun.py` to repeat the checks. The sealed v1 archive audit package is unchanged.
