#!/usr/bin/env python3
"""Reopen and verify root's accepted rerun of the Luna v6 auditor."""
import hashlib,json,tarfile
from pathlib import Path
BASE=Path('/private/tmp/jarde-last-four-archive-independent-review-luna-v2-20261019')
LAUNCH=Path('/private/tmp/jarde-last-four-final-retry-audit-launch-root-v2-20261019')
AUDITOR=Path('/private/tmp/jarde-prefixedretry-control-audit-luna-v6-20261019/audit_control_v6.py')
PINS=Path('/private/tmp/jarde-prefixedretry-control-audit-luna-v6-20261019/pins.json')
RECEIPT=Path('/private/tmp/jarde-last-four-final-retry-control-root-v2-20261019/execution.json')
REVIEW=Path('/private/tmp/jarde-last-four-final-retry-control-review-root-v3-20261019.json')
ARCHIVE=Path('/private/tmp/jarde-last-four-comparison-archive-root-v1-20261019/evidence.tar.gz')
def sha(b): return hashlib.sha256(b).hexdigest()
execution=json.loads((LAUNCH/'execution.json').read_text()); stdout=(LAUNCH/'stdout.raw').read_bytes(); stderr=(LAUNCH/'stderr.raw').read_bytes()
script=AUDITOR.read_bytes(); pins=json.loads(PINS.read_text()); receipt=RECEIPT.read_bytes(); review=json.loads(REVIEW.read_text()); review_bytes=REVIEW.read_bytes()
argv=['python3','-B',str(AUDITOR),'--receipt',str(RECEIPT),'--collector','/private/tmp/jarde-prefixedretry-control-tools-luna-v4-20261019/collect_control.py','--collector-sha256','0d57ad5dae3a8494faedb5b0711b0c7bc42d55b7014b8f3a1352a116cdd198ff','--out',str(REVIEW)]
assert execution['status']=='closed' and execution['exit_code']==0 and execution['argv']==argv
assert execution['streams']['stdout']=={'path':str(LAUNCH/'stdout.raw'),'bytes':len(stdout),'sha256':sha(stdout)}
assert execution['streams']['stderr']=={'path':str(LAUNCH/'stderr.raw'),'bytes':len(stderr),'sha256':sha(stderr)} and not stderr
assert sha(script)==pins['auditor_sha256']
with tarfile.open(ARCHIVE) as t:
    archived=t.extractfile('jarde-prefixedretry-control-audit-luna-v6-20261019/audit_control_v6.py').read()
assert archived==script
expected={'status':'accepted_with_mapping_debt','errors':0,'commands':105,'out':str(REVIEW)}
assert json.loads(stdout)==expected
assert review['status']=='accepted_with_mapping_debt' and review['errors']==[]
assert review['receipt']==str(RECEIPT) and review['receipt_sha256']==sha(receipt)
assert (review['commands'],review['raw_streams'],review['generated_compiles'],review['generated_runtime_cells'],review['generated_wrong_root_cells'])==(105,210,20,40,20)
failed=json.loads(Path('/private/tmp/jarde-prefixedretry-control-audit-luna-v6-20261019/attempt-1-live-target-gate.json').read_text())
assert failed['status']=='audit_failed' and failed['live_workspace_target_observed_during_audit'] and failed['receipt_target_absent_finally']
result={'schema':'luna-v6-root-rerun-clarification-v1','status':'verified_root_rerun_accepted','root_launch':{'directory':str(LAUNCH),'execution_sha256':sha((LAUNCH/'execution.json').read_bytes()),'status':execution['status'],'exit_code':execution['exit_code'],'argv':argv,'stdout':{'bytes':len(stdout),'sha256':sha(stdout),'text':stdout.decode()},'stderr':{'bytes':len(stderr),'sha256':sha(stderr),'empty':not stderr}},'auditor':{'path':str(AUDITOR),'sha256':sha(script),'matches_v6_pins':True,'matches_archived_script_bytes':True},'root_review':{'path':str(REVIEW),'bytes':len(review_bytes),'sha256':sha(review_bytes),'status':review['status'],'errors':len(review['errors']),'receipt':review['receipt'],'receipt_sha256':review['receipt_sha256'],'commands':review['commands'],'raw_streams':review['raw_streams'],'generated_compiles':review['generated_compiles'],'generated_runtime_cells':review['generated_runtime_cells'],'generated_wrong_root_cells':review['generated_wrong_root_cells'],'mapping_debt_scope':review['mapping_debt_scope']},'earlier_luna_attempt':{'path':'/private/tmp/jarde-prefixedretry-control-audit-luna-v6-20261019/attempt-1-live-target-gate.json','status':failed['status'],'error':failed['error'],'live_workspace_target_observed_during_audit':failed['live_workspace_target_observed_during_audit'],'receipt_target_absent_finally':failed['receipt_target_absent_finally']},'interpretation':'Root reran the Luna-authored v6 auditor after resolving the live target gate and received exit 0 plus an accepted root review. The earlier Luna attempt remains failed and is not retroactively changed.'}
(BASE/'v6-rerun-review.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':result['status'],'exit_code':execution['exit_code'],'stderr_bytes':len(stderr),'review_status':review['status'],'prior_luna_status':failed['status'],'auditor_sha256':sha(script)},indent=2))
