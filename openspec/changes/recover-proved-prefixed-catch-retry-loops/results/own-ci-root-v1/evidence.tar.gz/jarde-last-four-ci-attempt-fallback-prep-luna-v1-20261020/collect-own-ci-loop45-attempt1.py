#!/usr/bin/env python3
"""Collect raw CI evidence using native run/attempt/job REST responses (fallback protocol)."""
from __future__ import annotations
import argparse, importlib.util, json, sys
from pathlib import Path
sys.dont_write_bytecode = True
import common
HERE = Path(__file__).resolve().parent
COLLECTOR = HERE / 'collect-own-ci-attempt1.py'
def load_local(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot load local protocol tool: {path}')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module
def pair(spec: str):
    target, sep, test = spec.partition('=')
    if not sep or not target or not test or any(ch.isspace() for ch in target + test):
        raise argparse.ArgumentTypeError('expected TARGET=FULL_TEST_NAME without whitespace')
    return target, test
def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence_dir'); parser.add_argument('run_id'); parser.add_argument('product_sha'); parser.add_argument('cli_sha256')
    parser.add_argument('--source-file', action='append', default=[]); parser.add_argument('--fixture-root', action='append', default=[])
    parser.add_argument('--supplemental-gate', action='append', default=[], type=pair)
    args = parser.parse_args()
    module = load_local(COLLECTOR, 'loop45_attempt1_collector')
    inventory = common.extend_ci_inventory(module, args.source_file, args.fixture_root)
    if Path(args.evidence_dir).exists(): raise SystemExit('evidence directory must be fresh; protocol collector creates it')
    sys.argv = [str(COLLECTOR), args.evidence_dir, args.run_id, args.product_sha, args.cli_sha256]
    status = int(module.main())
    if status != 0: return status
    sidecar = Path(args.evidence_dir) / 'final-adapter-inputs.json'
    if sidecar.exists(): raise SystemExit('refusing existing final-adapter-inputs.json')
    sidecar.write_text(json.dumps({'schema':'jarde-final-ci-adapter-inputs-v2-attempt1','run_id':args.run_id,
       'product_sha':args.product_sha,'cli_sha256':args.cli_sha256,'source_files':inventory['supplemental_source_files'],
       'fixture_roots':inventory['supplemental_fixture_roots'],
       'supplemental_gates':[{'target':t,'test':n} for t,n in args.supplemental_gate],
       'protocol':'native-run-rest+attempt-1-jobs+individual-job-details'},indent=2)+'\n',encoding='utf-8')
    return 0
if __name__ == '__main__': raise SystemExit(main())
