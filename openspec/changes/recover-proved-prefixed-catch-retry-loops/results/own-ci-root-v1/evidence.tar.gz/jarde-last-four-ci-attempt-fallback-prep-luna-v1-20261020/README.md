# Loop45 CI attempt-1 fallback collector (prepared only)

This package is an opt-in fallback. It does not modify the frozen standard collector/verifier or their base dependencies. It makes official gh api calls and preserves their stdout/stderr bytes as raw command artifacts. It never synthesizes run.json or jobs-api.json and never rewrites an API response into another API schema.

The collection records three native response classes separately: run-rest.json from /actions/runs/{id}, attempt1-jobs-api.json from /actions/runs/{id}/attempts/1/jobs?per_page=100, and one job-details/{id}.json from /actions/jobs/{job_id}. The latter responses provide the 52 successful step records and are joined to attempt-list IDs by exact ID/name/status/conclusion. The attempt list is not treated as step evidence. Job logs are fetched independently from each /actions/jobs/{job_id}/logs endpoint. The existing official run ZIP is collected by the included adapted helper and independently checked against the individual job step inventories.

The copied verifier retains the frozen verifier's source/fixture pins, workflow contract, ZIP member checks, full two-seed target/test/status Counter (exactly 3,954 named outcomes per seed), and inherited test gates. The Loop45 wrapper retains the frozen 13 fixed extra-critical gates and common.py's 11 region + 4 public + 3 deferred gates; root supplies the same 15 final supplemental identities when running this plan, for exactly 156 final exact gates (enforced). It requires exactly four jobs, 52 successful API steps and full official ZIP coverage. Run and every job are required to bind attempt 1. Missing, pending, failed, duplicate, mismatched, or incomplete evidence is rejected.

## Root execution sequence (only after the full CI run is complete)

Use the exact product/CLI pins and all --source-file, --fixture-root, and --supplemental-gate arguments from the already frozen Loop45 plan. Use a fresh evidence directory. Run collector:

python3 -B collect-own-ci-loop45-attempt1.py EVIDENCE_DIR 39278336384 PRODUCT_SHA CLI_SHA256 [the frozen repeated inventory/gate arguments]

Then collect official run ZIP:

python3 -B collect-official-logs-attempt1.py EVIDENCE_DIR

Then run independent verifier:

python3 -B verify-own-ci-loop45-attempt1.py EVIDENCE_DIR --product-sha PRODUCT_SHA --cli-sha256 CLI_SHA256 --out REPORT [the same frozen repeated inventory/gate arguments]

This is only a prepared plan. No network/API, gh, JDK, Cargo, CLI, or Git mutation was run here. A live/incomplete run is not acceptable; do not retry until the run REST state is completed and all jobs have completed successfully.
