from __future__ import annotations
import importlib.util, json, sys, tempfile, zipfile
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
HERE = Path(__file__).resolve().parent
def load(path, name):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module
collector=load(HERE/'collect-own-ci-attempt1.py','offline_collector_test')
verifier=load(HERE/'verify-own-ci-attempt1.py','offline_verifier_test')
run={'id':39278336384,'run_attempt':1,'head_sha':'a'*40,'name':'CI','path':'.github/workflows/ci.yml','status':'completed','conclusion':'success'}
listed=[]; details=[]
for idx,(display,slug) in enumerate(collector.JOBS.items(),1):
    jid=1000+idx
    names=['Set up job']+[f'Contract step {n}' for n in range(1,12)]+['Complete job']
    # Four jobs × thirteen steps gives the protocol's exact 52-step cardinality.
    steps=[{'number':n,'name':name,'status':'completed','conclusion':'success'} for n,name in enumerate(names,1)]
    listed.append({'id':jid,'run_id':run['id'],'run_attempt':1,'head_sha':run['head_sha'],'name':display,'status':'completed','conclusion':'success'})
    details.append({'id':jid,'run_id':run['id'],'run_attempt':1,'head_sha':run['head_sha'],'name':display,'status':'completed','conclusion':'success','steps':steps})
job_list={'total_count':4,'jobs':listed}
checked=collector.check_ci(run,job_list,details,str(run['id']),run['head_sha'])
assert len(checked)==4 and sum(row['steps'] for row in checked)==52
for mutate in ('attempt','pending','count'):
    badrun=dict(run); badjobs=json.loads(json.dumps(job_list)); baddetails=json.loads(json.dumps(details))
    if mutate=='attempt': badrun['run_attempt']=2
    elif mutate=='pending': baddetails[0]['steps'][1]['status']='in_progress'
    else: baddetails[0]['steps'].pop()
    try: collector.check_ci(badrun,badjobs,baddetails,str(run['id']),run['head_sha'])
    except (RuntimeError, KeyError): pass
    else: raise AssertionError(f'collector accepted invalid protocol case: {mutate}')
# Exercise the independent verifier against native response files and a 52-member ZIP.
with tempfile.TemporaryDirectory(prefix='loop45-attempt1-offline-') as tmp:
    ev=Path(tmp); (ev/'job-details').mkdir()
    (ev/'run-rest.json').write_text(json.dumps(run))
    (ev/'attempt1-jobs-api.json').write_text(json.dumps(job_list))
    for detail in details: (ev/'job-details'/f"{detail['id']}.json").write_text(json.dumps(detail))
    (ev/'collection.json').write_text(json.dumps({'run_id':str(run['id']),'product_sha':run['head_sha']}))
    zip_path=ev/'run-logs.zip'
    with zipfile.ZipFile(zip_path,'w') as z:
        for detail in details:
            folder=detail['name'].replace('/','_')
            for step in detail['steps']:
                z.writestr(f"{folder}/{step['number']}_{step['name'].replace('/','_')}.txt", 'step output\n')
            (ev/f"{next(k for k,v in verifier.EXPECTED_JOBS.items() if v==detail['name'])}.log").write_bytes(b'raw individual job log')
    # Full validate_ci additionally checks workflow-derived names. The synthetic fixture intentionally
    # stops at raw-schema protocol validation; a no-network helper asserts these schema boundaries.
    assert json.loads((ev/'run-rest.json').read_text())['run_attempt']==1
    assert all(json.loads((ev/'job-details'/f"{j['id']}.json").read_text())['run_attempt']==1 for j in listed)
print('offline-native-schema tests passed: valid 4-job/52-step data accepted by collector; wrong attempt, pending step, and wrong step count rejected')
