#!/usr/bin/env python3
"""Collect raw GitHub Actions evidence and source pins for the typed-list foreach leaf gates.

Prepared only. The root operator supplies OUT, RUN_ID, and PRODUCT_SHA when collecting CI.
"""
from __future__ import annotations

import concurrent.futures
import shutil
import time
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
REPO = 'LordCasser/jarde'
FIXTURE_ROOT = 'tests/fixtures'
FIXTURE_ROOTS = ('tests/fixtures/cf08-entry-split', 'tests/fixtures/cf08-if-loop-entry', 'tests/fixtures/cf09-literal-boolean-locals', 'tests/fixtures/foreach-local-bindings/debug', 'tests/fixtures/foreach-local-bindings/none', 'tests/fixtures/java8/assignment-condition-widening', 'tests/fixtures/java8/indexed-list-parameters', 'tests/fixtures/recover-proved-loop-continue-ladder-joins', 'tests/fixtures/recover-proved-post-test-loop-break-prefixes', 'tests/fixtures/typed-list-foreach')
FIXTURE_ROOTS += ('tests/fixtures/cf09-complex-if-body-boundary',)
FIXTURE_ROOTS += ('tests/fixtures/recover-branching-named-catch-retry-loops',)
EXPECTED_FIXTURE_FILES = ('tests/fixtures/cf08-entry-split/EntrySplitFixtureWriter.java', 'tests/fixtures/cf08-entry-split/EntrySplitOracleDriver.java', 'tests/fixtures/cf08-entry-split/EntrySplitSlotCounterCasesDriver.java', 'tests/fixtures/cf08-entry-split/EntrySplitSlotCounterCasesWriter.java', 'tests/fixtures/cf08-entry-split/README.md', 'tests/fixtures/cf08-entry-split/cf08/EntrySplitCases.class', 'tests/fixtures/cf08-entry-split/cf08/EntrySplitExceptionRefusal.class', 'tests/fixtures/cf08-entry-split/cf08/EntrySplitLegacyCases.class', 'tests/fixtures/cf08-entry-split/cf08/EntrySplitRefusals.class', 'tests/fixtures/cf08-entry-split/cf08/EntrySplitSlotCounterCases.class', 'tests/fixtures/cf08-entry-split/cf08/EntrySplitTopologyRefusals.class', 'tests/fixtures/cf08-entry-split/generalized-manifest.json', 'tests/fixtures/cf08-entry-split/manifest.json', 'tests/fixtures/cf08-if-loop-entry/README.md', 'tests/fixtures/cf08-if-loop-entry/TestLoopRestore2.raung', 'tests/fixtures/cf08-if-loop-entry/baseline/TestLoopRestore2.java', 'tests/fixtures/cf08-if-loop-entry/controls/LoopRestoreEffectPrefix.class', 'tests/fixtures/cf08-if-loop-entry/controls/LoopRestoreGotoW.class', 'tests/fixtures/cf08-if-loop-entry/licenses/JADX-LICENSE', 'tests/fixtures/cf08-if-loop-entry/licenses/JADX-NOTICE', 'tests/fixtures/cf08-if-loop-entry/licenses/RAUNG-MIT-LICENSE', 'tests/fixtures/cf08-if-loop-entry/make_controls.py', 'tests/fixtures/cf08-if-loop-entry/manifest.json', 'tests/fixtures/cf08-if-loop-entry/original.jar', 'tests/fixtures/cf08-if-loop-entry/original/loops/TestLoopRestore2.class', 'tests/fixtures/cf09-literal-boolean-locals/README.md', 'tests/fixtures/cf09-literal-boolean-locals/controls-src/BooleanLocalRefusals.java', 'tests/fixtures/cf09-literal-boolean-locals/controls/jdk23/BooleanLocalRefusals.class', 'tests/fixtures/cf09-literal-boolean-locals/controls/jdk8/BooleanLocalRefusals.class', 'tests/fixtures/cf09-literal-boolean-locals/manifest.json', 'tests/fixtures/cf09-literal-boolean-locals/original/debug-full-classes.jar', 'tests/fixtures/cf09-literal-boolean-locals/original/debug/classes/jadx/tests/integration/loops/TestBreakWithLabel$TestCls.class', 'tests/fixtures/cf09-literal-boolean-locals/original/debug/classes/jadx/tests/integration/loops/TestBreakWithLabel.class', 'tests/fixtures/cf09-literal-boolean-locals/original/no-debug-full-classes.jar', 'tests/fixtures/cf09-literal-boolean-locals/original/no-debug/classes/jadx/tests/integration/loops/TestBreakWithLabel$TestCls.class', 'tests/fixtures/cf09-literal-boolean-locals/original/no-debug/classes/jadx/tests/integration/loops/TestBreakWithLabel.class', 'tests/fixtures/cf09-literal-boolean-locals/prepare_controls.py', 'tests/fixtures/cf09-literal-boolean-locals/upstream/LICENSE', 'tests/fixtures/cf09-literal-boolean-locals/upstream/NOTICE', 'tests/fixtures/cf09-literal-boolean-locals/upstream/TestBreakWithLabel.java', 'tests/fixtures/foreach-local-bindings/debug/TestNestedLoops$TestCls.class', 'tests/fixtures/foreach-local-bindings/none/TestNestedLoops$TestCls.class', 'tests/fixtures/java8/assignment-condition-widening/JADX-LICENSE', 'tests/fixtures/java8/assignment-condition-widening/JADX-NOTICE', 'tests/fixtures/java8/assignment-condition-widening/README.md', 'tests/fixtures/java8/assignment-condition-widening/driver/LoopConditionInvokeControlDriver.java', 'tests/fixtures/java8/assignment-condition-widening/driver/TestLoopConditionInvokeDriver.java', 'tests/fixtures/java8/assignment-condition-widening/freeze-and-census.json', 'tests/fixtures/java8/assignment-condition-widening/javac23-debug/LoopConditionInvokeControl.class', 'tests/fixtures/java8/assignment-condition-widening/javac23-no-debug/LoopConditionInvokeControl.class', 'tests/fixtures/java8/assignment-condition-widening/javac8-debug/LoopConditionInvokeControl.class', 'tests/fixtures/java8/assignment-condition-widening/javac8-no-debug/LoopConditionInvokeControl.class', 'tests/fixtures/java8/assignment-condition-widening/source/LoopConditionInvokeControl.java', 'tests/fixtures/java8/assignment-condition-widening/source/TestLoopConditionInvoke.java', 'tests/fixtures/java8/assignment-condition-widening/upstream-debug/TestLoopConditionInvoke$TestCls.class', 'tests/fixtures/java8/assignment-condition-widening/upstream-no-debug/TestLoopConditionInvoke$TestCls.class', 'tests/fixtures/java8/indexed-list-parameters/NestedLoops2GenericControls.java', 'tests/fixtures/java8/indexed-list-parameters/README.md', 'tests/fixtures/java8/indexed-list-parameters/debug/NestedLoops2GenericControls.class', 'tests/fixtures/java8/indexed-list-parameters/no-debug/NestedLoops2GenericControls.class', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/README.md', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/manifest.json', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/LICENSE', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/NOTICE', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/TestContinueInLoop.java', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/TestContinueInLoopDriver.java', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/debug-plain.jar', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/debug/classes/jadx/tests/integration/loops/TestContinueInLoop$TestCls.class', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/debug/classes/jadx/tests/integration/loops/TestContinueInLoop.class', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/no-debug-plain.jar', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/no-debug/classes/jadx/tests/integration/loops/TestContinueInLoop$TestCls.class', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/no-debug/classes/jadx/tests/integration/loops/TestContinueInLoop.class', 'tests/fixtures/recover-proved-post-test-loop-break-prefixes/README.md', 'tests/fixtures/recover-proved-post-test-loop-break-prefixes/manifest.json', 'tests/fixtures/recover-proved-post-test-loop-break-prefixes/original/LICENSE', 'tests/fixtures/recover-proved-post-test-loop-break-prefixes/original/NOTICE', 'tests/fixtures/recover-proved-post-test-loop-break-prefixes/original/TestDoWhileBreak.java', 'tests/fixtures/recover-proved-post-test-loop-break-prefixes/original/TestDoWhileBreakDriver.java', 'tests/fixtures/recover-proved-post-test-loop-break-prefixes/original/debug-plain.jar', 'tests/fixtures/recover-proved-post-test-loop-break-prefixes/original/debug/classes/jadx/tests/integration/loops/TestDoWhileBreak$TestCls.class', 'tests/fixtures/recover-proved-post-test-loop-break-prefixes/original/debug/classes/jadx/tests/integration/loops/TestDoWhileBreak.class', 'tests/fixtures/recover-proved-post-test-loop-break-prefixes/original/no-debug-plain.jar', 'tests/fixtures/recover-proved-post-test-loop-break-prefixes/original/no-debug/classes/jadx/tests/integration/loops/TestDoWhileBreak$TestCls.class', 'tests/fixtures/recover-proved-post-test-loop-break-prefixes/original/no-debug/classes/jadx/tests/integration/loops/TestDoWhileBreak.class', 'tests/fixtures/typed-list-foreach/README.md', 'tests/fixtures/typed-list-foreach/TypedListForEachCases.class', 'tests/fixtures/typed-list-foreach/TypedListForEachCases.java')
EXPECTED_FIXTURE_FILES = tuple(sorted(EXPECTED_FIXTURE_FILES + ('tests/fixtures/cf09-complex-if-body-boundary/README.md', 'tests/fixtures/cf09-complex-if-body-boundary/caseplans.json', 'tests/fixtures/cf09-complex-if-body-boundary/controls/HeaderBodyBoundaryControls.class', 'tests/fixtures/cf09-complex-if-body-boundary/debug-plain.jar', 'tests/fixtures/cf09-complex-if-body-boundary/debug/class/jadx/tests/integration/loops/TestBreakInComplexIf$TestCls$Point.class', 'tests/fixtures/cf09-complex-if-body-boundary/debug/class/jadx/tests/integration/loops/TestBreakInComplexIf$TestCls.class', 'tests/fixtures/cf09-complex-if-body-boundary/debug/class/jadx/tests/integration/loops/TestBreakInComplexIf.class', 'tests/fixtures/cf09-complex-if-body-boundary/driver/TestBreakInComplexIfDriver.java', 'tests/fixtures/cf09-complex-if-body-boundary/fixture-manifest.json', 'tests/fixtures/cf09-complex-if-body-boundary/licenses/JADX-LICENSE', 'tests/fixtures/cf09-complex-if-body-boundary/licenses/JADX-NOTICE', 'tests/fixtures/cf09-complex-if-body-boundary/no-debug-plain.jar', 'tests/fixtures/cf09-complex-if-body-boundary/no-debug/class/jadx/tests/integration/loops/TestBreakInComplexIf$TestCls$Point.class', 'tests/fixtures/cf09-complex-if-body-boundary/no-debug/class/jadx/tests/integration/loops/TestBreakInComplexIf$TestCls.class', 'tests/fixtures/cf09-complex-if-body-boundary/no-debug/class/jadx/tests/integration/loops/TestBreakInComplexIf.class', 'tests/fixtures/cf09-complex-if-body-boundary/runtime-bound-cwd.py', 'tests/fixtures/cf09-complex-if-body-boundary/upstream/TestBreakInComplexIf.java')))
EXPECTED_FIXTURE_FILES = tuple(sorted(EXPECTED_FIXTURE_FILES + ('tests/fixtures/cf09-complex-if-body-boundary/controls/HeaderBodyBoundaryControls.java', 'tests/fixtures/cf09-complex-if-body-boundary/controls/root-compile-receipt.json')))
EXPECTED_FIXTURE_FILES = tuple(sorted(set(EXPECTED_FIXTURE_FILES) | {
    path.relative_to(ROOT).as_posix() for path in (ROOT / FIXTURE_ROOTS[-1]).rglob('*')
    if path.is_file() and not path.is_symlink()
}))
SOURCE_PATHS = ('.github/workflows/ci.yml', 'Cargo.lock', 'Cargo.toml', 'crates/jarde-java/src/build.rs', 'crates/jarde-java/src/region.rs', 'crates/jarde-java/src/region/loop_arm_return_tests.rs', 'crates/jarde-java/src/report.rs', 'crates/jarde-reader/src/classfile.rs', 'src/bulk.rs', 'src/class_source.rs', 'src/facade.rs', 'tests/fixtures/corpus-fingerprint.json', 'tests/fixtures/foreach-local-bindings/source/TestNestedLoops.java', 'tests/fixtures/p3-iterable-foreach/IterableBoundaryRunner.java', 'tests/p3_assignment_condition_widening.rs', 'tests/p3_continue_ladder_joins.rs', 'tests/p3_entry_split_int_loops.rs', 'tests/p3_hoisted_boolean.rs', 'tests/p3_hoisted_iterator_foreach.rs', 'tests/p3_if_loop_entry_origins.rs', 'tests/p3_iterable_foreach.rs', 'tests/p3_nested_loop_side_exits.rs', 'tests/p3_post_test_loop_break_prefixes.rs', 'tests/p3_proved_literal_boolean_locals.rs', 'tests/recover_lambda_primitive_array_capture.rs', 'tests/structured_list_generic_bodies.rs')
SOURCE_PATHS += ('crates/jarde-java/src/region/and_body_boundary_tests.rs', 'tests/p3_complex_if_body_boundary.rs')
SOURCE_PATHS += ('crates/jarde-java/src/region/finite_loop_catch_tests.rs', 'tests/p3_branching_catch_retry.rs')
JOBS = {
    'stable / test and specification': 'stable',
    'MSRV 1.88.0': 'msrv',
    'supply chain': 'supply-chain',
    'fuzz smoke': 'fuzz-smoke',
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def command_once(out: Path, root: Path, argv: list[str], name: str) -> dict:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    stdout, stderr = out / name, out / (name + '.stderr.raw')
    stdout.parent.mkdir(parents=True, exist_ok=True)
    with stdout.open('xb') as so, stderr.open('xb') as se:
        result = subprocess.run(argv, cwd=root, stdout=so, stderr=se)
    return {
        'argv': argv,
        'exit_code': result.returncode,
        'started_at': started,
        'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'streams': {
            'stdout': {'path': str(stdout), 'bytes': stdout.stat().st_size, 'sha256': sha(stdout.read_bytes())},
            'stderr': {'path': str(stderr), 'bytes': stderr.stat().st_size, 'sha256': sha(stderr.read_bytes())},
        },
    }


def command(out: Path, root: Path, argv: list[str], name: str) -> dict:
    # Retain every actual failed stream. Canonical streams copy one complete attempt.
    if argv[0] != 'gh':
        return command_once(out, root, argv, name)
    attempts = []
    for index in range(1, 4):
        row = command_once(out, root, argv, name + f'.transport-attempt-{index}')
        attempts.append(row)
        if row['exit_code'] == 0:
            break
        if index < 3:
            time.sleep(5)
    final = dict(row)
    final['transport_attempts'] = attempts
    final['streams'] = {}
    for key, target in [('stdout', out / name), ('stderr', out / (name + '.stderr.raw'))]:
        source = Path(row['streams'][key]['path'])
        with source.open('rb') as src, target.open('xb') as dst:
            shutil.copyfileobj(src, dst)
        need(target.read_bytes() == source.read_bytes(), 'transport stream copy changed bytes')
        final['streams'][key] = {'path': str(target), 'bytes': target.stat().st_size, 'sha256': sha(target.read_bytes())}
    return final


def need(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def check_ci(run: dict, jobs_list: dict, job_details: list[dict], run_id: str, product: str) -> list[dict]:
    need(run.get('id') == int(run_id) and run.get('run_attempt') == 1,
         'official run REST response is not the requested attempt 1')
    need(run.get('head_sha') == product, 'run head_sha differs from PRODUCT_SHA')
    need(run.get('status') == 'completed' and run.get('conclusion') == 'success',
         'CI run is not completed successfully')
    need(run.get('name') == 'CI' and isinstance(run.get('path'), str) and run.get('path').split('@', 1)[0] == '.github/workflows/ci.yml', 'run is not the pinned CI workflow')
    listed = jobs_list.get('jobs')
    need(jobs_list.get('total_count') == 4 and isinstance(listed, list) and len(listed) == 4,
         'attempt-1 jobs API did not return exactly four jobs')
    listed_by_id = {row.get('id'): row for row in listed}
    details_by_id = {row.get('id'): row for row in job_details}
    need(len(listed_by_id) == 4 and len(details_by_id) == 4,
         'attempt-1 job IDs are missing or duplicated')
    need(set(listed_by_id) == set(details_by_id), 'individual job detail IDs differ from attempt-1 job list')
    need({row.get('name') for row in listed} == set(JOBS), 'unexpected CI job names')
    need(len({row.get('name') for row in listed}) == 4, 'attempt-1 job names are duplicated')
    result = []
    total_steps = 0
    for display, slug in JOBS.items():
        listed_job = next(row for row in listed if row.get('name') == display)
        detail = details_by_id[listed_job['id']]
        need(detail.get('run_id') == int(run_id) and detail.get('run_attempt') == 1
             and detail.get('head_sha') == product,
             f'individual job is not bound to run attempt 1: {display}')
        need(detail.get('name') == display and detail.get('status') == 'completed'
             and detail.get('conclusion') == 'success', f'job failed/incomplete: {display}')
        need(listed_job.get('run_id') == int(run_id) and listed_job.get('run_attempt') == 1
             and listed_job.get('head_sha') == product, f'attempt list job is not bound to run/product: {display}')
        need(listed_job.get('name') == detail.get('name')
             and listed_job.get('status') == detail.get('status')
             and listed_job.get('conclusion') == detail.get('conclusion'),
             f'attempt list and individual job detail differ: {display}')
        steps = detail.get('steps')
        need(isinstance(steps, list) and steps, f'individual job step inventory is empty: {display}')
        for step in steps:
            need(step.get('status') == 'completed' and step.get('conclusion') == 'success',
                 f'job step failed/incomplete in {display}: {step.get("name")}')
        total_steps += len(steps)
        result.append({'name': display, 'slug': slug, 'database_id': listed_job['id'], 'steps': len(steps)})
    need(total_steps == 52, f'individual job details contain {total_steps} steps, expected exactly 52')
    return result


def main() -> int:
    if len(sys.argv) != 5:
        raise SystemExit('usage: collect-own-ci.py OUT_DIR RUN_ID PRODUCT_SHA CLI_SHA256')
    out, run_id, product, cli_sha256 = Path(sys.argv[1]).resolve(), sys.argv[2], sys.argv[3], sys.argv[4]
    if re.fullmatch(r'[0-9a-f]{40}', product) is None:
        raise SystemExit('PRODUCT_SHA must be a lowercase full 40-character SHA')
    if re.fullmatch(r'[0-9a-f]{64}', cli_sha256) is None:
        raise SystemExit('CLI_SHA256 must be a lowercase full 64-character SHA256')
    if not re.fullmatch(r'[0-9]+', run_id) or out.exists():
        raise SystemExit('RUN_ID must be numeric and OUT_DIR must be fresh')
    root = ROOT.resolve(strict=True)
    fixture_dirs = tuple(root / rel for rel in FIXTURE_ROOTS)
    need(all(path.is_dir() and not path.is_symlink() for path in fixture_dirs), 'one or more pinned fixture roots are missing or unsafe')
    fixture_paths = tuple(sorted(path.relative_to(root).as_posix() for fixture_dir in fixture_dirs for path in fixture_dir.rglob('*') if path.is_file()))
    need(len(fixture_paths) == len(set(fixture_paths)) and fixture_paths, 'fixture inventory is empty or overlapping')
    need(fixture_paths == EXPECTED_FIXTURE_FILES, f'complete fixture inventory differs: {fixture_paths}')
    source_paths = tuple(sorted(set(SOURCE_PATHS) | set(fixture_paths)))
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('refusing to collect while repository target exists')
    source_before = {rel: (root / rel).read_bytes() for rel in source_paths}
    out.mkdir(parents=True)
    record = {'product_sha': product, 'cli_sha256': cli_sha256, 'run_id': run_id, 'status': 'collecting',
              'commands': [], 'source_paths': list(SOURCE_PATHS),
              'fixture_root': FIXTURE_ROOT, 'fixture_roots': list(FIXTURE_ROOTS), 'fixture_files': list(fixture_paths)}
    try:
        row = command(out, root, ['gh', 'api', f'repos/{REPO}/actions/runs/{run_id}'], 'run-rest.json')
        record['commands'].append(row)
        need(row['exit_code'] == 0, 'GitHub run REST request failed')
        run = json.loads((out / 'run-rest.json').read_text(encoding='utf-8'))
        need(run.get('id') == int(run_id) and run.get('run_attempt') == 1,
             'official run REST response is not requested attempt 1')

        row = command(out, root, ['gh', 'api', f'repos/{REPO}/actions/runs/{run_id}/attempts/1/jobs?per_page=100'], 'attempt1-jobs-api.json')
        record['commands'].append(row)
        need(row['exit_code'] == 0, 'GitHub attempt-1 jobs API request failed')
        jobs_list = json.loads((out / 'attempt1-jobs-api.json').read_text(encoding='utf-8'))
        need(jobs_list.get('total_count') == 4 and isinstance(jobs_list.get('jobs'), list)
             and len(jobs_list['jobs']) == 4, 'attempt-1 jobs API is incomplete')
        details = []
        for listed_job in jobs_list['jobs']:
            job_id = listed_job.get('id')
            need(isinstance(job_id, int) and job_id > 0, 'attempt-1 jobs API contains an invalid job ID')
            row = command(out, root, ['gh', 'api', f'repos/{REPO}/actions/jobs/{job_id}'], f'job-details/{job_id}.json')
            record['commands'].append(row)
            need(row['exit_code'] == 0, f'individual GitHub job request failed: {job_id}')
            details.append(json.loads((out / f'job-details/{job_id}.json').read_text(encoding='utf-8')))
        checked_jobs = check_ci(run, jobs_list, details, run_id, product)
        record['run_attempt'] = 1

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            futures = [pool.submit(command, out, root, ['gh', 'api', f'repos/{REPO}/actions/jobs/{job["database_id"]}/logs'], job['slug'] + '.log') for job in checked_jobs]
            log_rows = [future.result() for future in futures]
        record['commands'].extend(log_rows)
        need(all(row['exit_code'] == 0 for row in log_rows), 'one or more complete job-log captures failed')

        files = {}
        fixtures = {}
        for rel in source_paths:
            is_fixture = any(rel.startswith(fixture_root + '/') for fixture_root in FIXTURE_ROOTS)
            target = ('product-fixtures/' if is_fixture else 'product-source/') + rel
            row = command(out, root, ['git', 'show', product + ':' + rel], target)
            record['commands'].append(row)
            need(row['exit_code'] == 0, f'git show failed: {rel}')
            data = (out / target).read_bytes()
            need(data == source_before[rel], f'git-show bytes differ from initial current checkout: {rel}')
            dest = fixtures if is_fixture else files
            dest[rel] = {'git_show': f'git show {product}:{rel}', 'bytes': len(data), 'sha256': sha(data)}

        source_after = {rel: (root / rel).read_bytes() for rel in source_paths}
        need(source_after == source_before, 'source/fixture bytes changed during collection')
        need(not (root / 'target').exists() and not (root / 'target').is_symlink(), 'target appeared during collection')
        (out / 'source-pins.json').write_text(json.dumps({
            'product_sha': product, 'cli_sha256': cli_sha256, 'source_files': files, 'fixture_files': fixtures,
            'fixture_root': FIXTURE_ROOT, 'fixture_roots': list(FIXTURE_ROOTS), 'fixture_file_count': len(fixtures),
        }, indent=2) + '\n', encoding='utf-8')
        (out / 'workflow.sha256').write_text(files['.github/workflows/ci.yml']['sha256'] + '\n', encoding='ascii')
        record['checked_jobs'] = checked_jobs
        record['source_file_count'] = len(files)
        record['fixture_file_count'] = len(fixtures)
        record['source_before_after_equal'] = True
        record['target_absent_after'] = True
        record['status'] = 'raw collection complete; independent acceptance pending'
        (out / 'collection.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'status': record['status'], 'captured_commands': len(record['commands']),
                          'source_files': len(files), 'fixture_files': len(fixtures), 'jobs': len(checked_jobs)}))
        return 0
    except Exception as exc:
        record['failure'] = repr(exc)
        record['status'] = 'collection failed; no CI accepted'
        (out / 'collection.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
        raise


if __name__ == '__main__':
    raise SystemExit(main())
