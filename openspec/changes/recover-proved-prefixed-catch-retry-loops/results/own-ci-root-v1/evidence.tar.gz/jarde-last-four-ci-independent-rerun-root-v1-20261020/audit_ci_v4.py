#!/usr/bin/env python3
from __future__ import annotations
import collections, hashlib, importlib.util, json, pathlib, re, sys, zipfile

ROOT = pathlib.Path('/Users/lordcasser/workspace/projects/jarde')
CI = pathlib.Path('/private/tmp/jarde-last-four-own-ci-root-v4-20261020')
NATIVE = pathlib.Path('/private/tmp/jarde-last-four-native-root-v1-20261019')
NATIVE_REVIEW = pathlib.Path('/private/tmp/jarde-last-four-native-independent-review-luna-v1-20261019/review.json')
FALLBACK = pathlib.Path('/private/tmp/jarde-last-four-ci-attempt-fallback-prep-luna-v2-20261020')
ACCEPTANCE = pathlib.Path('/private/tmp/jarde-loop2-retry-native-ci-prep-luna-v2-20261019/acceptance-argv.json')
OUT = pathlib.Path(__file__).resolve().parent
EXPECTED_RUN = '39278336384'
EXPECTED_HEAD = '8ea98e2e11d64f02092ac200d2b596511dcf5e40'
EXPECTED_CLI = 'ed74e005c1bc97bcdf4a15f6a27da9e9d8a1ecdf7fe576836820ed2ce323222d'
EXPECTED_NATIVE_COUNTER = '6bc624d48ecbba140da74106a7123758b3e387c4baa2a3ea2ff337ddf8cba966'
EXPECTED_ZIP = 'a8bfc7520db8b337c67219b8b8d8f4979ca23d26dd4b4d407cb4d73029b6b25e'
EMPTY_SHA = hashlib.sha256(b'').hexdigest()

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p): return sha_bytes(p.read_bytes())
def load_json(p): return json.loads(p.read_text(encoding='utf-8'))
def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise AssertionError(f'cannot load helper {path}')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def pin_stream(pin, *, must_be_file=True):
    p=pathlib.Path(pin['path'])
    assert p.is_file() and (not p.is_symlink())
    b=p.read_bytes()
    assert len(b)==pin['bytes'] and sha_bytes(b)==pin['sha256']
    if must_be_file: return p,b
    return p,b

def raw_ci_counter(old, group):
    # Independent triple parser retaining the optional should-panic display decoration.
    lines=[old.clean_line(line) for line in group.splitlines()]
    headers=[]; blocks=[]
    for line in lines:
        ht=old.RUN_TARGET.fullmatch(line)
        if ht:
            exe=ht.group('path').rsplit('/',1)[-1]
            hm=old.HASHED_EXE.fullmatch(exe)
            old.need(hm is not None, f'unrecognized executable in Running header: {exe!r}')
            headers.append(hm.group('target'))
    i=0
    while i<len(lines):
        rm=old.RUNNING.fullmatch(lines[i])
        if not rm: i+=1; continue
        declared=int(rm.group(1)); named=[]; i+=1
        while i<len(lines):
            sm=old.SUMMARY.fullmatch(lines[i])
            if sm:
                counts=tuple(int(sm.group(k)) for k in range(2,5))
                observed=(sum(s=='ok' for _,s in named),sum(s=='FAILED' for _,s in named),sum(s=='ignored' for _,s in named))
                old.need(declared==len(named) and counts==observed, 'named outcomes differ from step summary')
                blocks.append(named); i+=1; break
            om=old.OUTCOME.fullmatch(lines[i])
            if om:
                status='ignored' if om.group(2).startswith('ignored') else om.group(2)
                label=om.group(1)
                if re.search(r' - should panic \.\.\. ', lines[i]): label += ' - should panic'
                named.append((label,status))
            elif lines[i].startswith('test result:') or lines[i].startswith('test '):
                raise AssertionError(f'unparsed test output: {lines[i]!r}')
            i+=1
        else: raise AssertionError('unterminated test target block')
    old.need(len(headers)==len(blocks) and len(headers)>0, 'Cargo executable headers and test blocks differ')
    out=collections.Counter()
    for target, block in zip(headers,blocks):
        for test,status in block: out[(target,test,status)]+=1
    return out

def rows_from_counter(c):
    return [[t,n,s,count] for (t,n,s),count in sorted(c.items())]
def counter_hash(c):
    raw=json.dumps(rows_from_counter(c),ensure_ascii=False,separators=(',',':')).encode('utf-8')
    return sha_bytes(raw)

def main():
    fallback_pins=load_json(FALLBACK/'pins.json')
    helper_hashes={name:digest for name,digest in fallback_pins['package_sha256'].items() if name in ('common.py','verify-own-ci-attempt1.py','verify-own-ci-loop45-attempt1.py','ci-verify-argv.json')}
    for name,digest in helper_hashes.items(): assert sha_file(FALLBACK/name)==digest
    coll=load_json(CI/'collection.json')
    assert coll['run_id']==EXPECTED_RUN and coll['product_sha']==EXPECTED_HEAD and coll['cli_sha256']==EXPECTED_CLI
    assert coll['status']=='raw collection complete; independent acceptance pending'
    assert coll['source_before_after_equal'] is True and coll['target_absent_after'] is True
    assert len(coll['commands'])==212
    command_details=[]
    for c in coll['commands']:
        assert c['exit_code']==0
        for channel,pin in c['streams'].items():
            p,b=pin_stream(pin)
            command_details.append({'channel':channel,'argv':c['argv'],'path':str(p),'bytes':len(b),'sha256':sha_bytes(b)})
        for attempt in c.get('transport_attempts',[]):
            assert attempt['argv']==c['argv'] and attempt['exit_code']==0
            for channel,pin in attempt['streams'].items(): pin_stream(pin)
    source_pins=load_json(CI/'source-pins.json')
    inputs=load_json(CI/'final-adapter-inputs.json')
    assert source_pins['product_sha']==EXPECTED_HEAD and source_pins['cli_sha256']==EXPECTED_CLI
    assert inputs['run_id']==EXPECTED_RUN and inputs['product_sha']==EXPECTED_HEAD and inputs['cli_sha256']==EXPECTED_CLI
    assert len(source_pins['source_files'])==40 and len(source_pins['fixture_files'])==166
    source_file_checks=[]
    for rel,item in source_pins['source_files'].items():
        cmd=next(c for c in coll['commands'] if c['argv']==['git','show',f'{EXPECTED_HEAD}:{rel}'])
        op=pathlib.Path(cmd['streams']['stdout']['path'])
        dest=CI/'product-source'/rel
        assert dest.is_file() and sha_file(dest)==item['sha256']==sha_file(op)
        assert dest.stat().st_size==item['bytes']==op.stat().st_size
        source_file_checks.append({'path':rel,'bytes':item['bytes'],'sha256':item['sha256']})
    fixture_file_checks=[]
    for rel,item in source_pins['fixture_files'].items():
        cmd=next(c for c in coll['commands'] if c['argv']==['git','show',f'{EXPECTED_HEAD}:{rel}'])
        op=pathlib.Path(cmd['streams']['stdout']['path'])
        dest=CI/'product-fixtures'/rel
        assert dest.is_file() and sha_file(dest)==item['sha256']==sha_file(op)
        assert dest.stat().st_size==item['bytes']==op.stat().st_size
        fixture_file_checks.append({'path':rel,'bytes':item['bytes'],'sha256':item['sha256']})
    workflow_pin=source_pins['source_files']['.github/workflows/ci.yml']
    assert sha_file(CI/'workflow.sha256')==sha_bytes((workflow_pin['sha256']+'\n').encode())
    # Native source pin for the exact unique test candidate used to bind the one GitHub-masked name.
    native_exec=load_json(NATIVE/'execution.json')
    source_file=ROOT/'tests/bulk_recovery_backpressure.rs'
    native_source_pin=native_exec['source_pins'].get('tests/bulk_recovery_backpressure.rs')
    assert native_source_pin and sha_file(source_file)==native_source_pin
    source_text=source_file.read_text(encoding='utf-8')
    exact_source_name='a_result_weighs_what_it_owns_and_not_the_length_it_writes'
    source_lines=[i for i,line in enumerate(source_text.splitlines(),1) if f'fn {exact_source_name}(' in line]
    assert source_lines==[613]
    run=load_json(CI/'run.json'); api=load_json(CI/'jobs-api.json')
    assert run['databaseId']==int(EXPECTED_RUN) and run['headSha']==EXPECTED_HEAD and run['status']=='completed' and run['conclusion']=='success'
    assert api['total_count']==4 and len(api['jobs'])==4
    jobs=api['jobs']; assert all(j['run_id']==int(EXPECTED_RUN) and j['head_sha']==EXPECTED_HEAD and j['run_attempt']==1 for j in jobs)
    assert all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
    assert all(step['status']=='completed' and step['conclusion']=='success' for j in jobs for step in j['steps'])
    step_total=sum(len(j['steps']) for j in jobs); assert step_total==52
    run_jobs={j['name']:j for j in run['jobs']}
    assert len(run_jobs)==4
    for j in jobs:
        rj=run_jobs[j['name']]
        assert rj['databaseId']==j['id'] and rj['status']==j['status'] and rj['conclusion']==j['conclusion']
    # Bind each raw GH response/transport attempt from the receipt to its preserved file.
    for c in coll['commands']:
        if c['argv'][:3]==['gh','run','view'] or c['argv'][:2]==['gh','api']:
            assert c['exit_code']==0
    supplement=load_json(CI/'step-log-supplement.json')
    assert supplement['run_id']==EXPECTED_RUN and supplement['product_sha']==EXPECTED_HEAD
    assert supplement['argv']==['gh','api',f'repos/LordCasser/jarde/actions/runs/{EXPECTED_RUN}/logs'] and supplement['exit_code']==0
    assert supplement['collection_json_sha256']==sha_file(CI/'collection.json')
    assert supplement['run_json_sha256']==sha_file(CI/'run.json')
    for attempt in supplement['transport_attempts']:
        assert attempt['argv']==supplement['argv'] and attempt['exit_code']==0
        for pin in attempt.values():
            if isinstance(pin,dict) and {'path','bytes','sha256'}<=set(pin): pin_stream(pin)
    for pin in supplement['streams'].values(): pin_stream(pin)
    zip_path=CI/'run-logs.zip'; zip_sha=sha_file(zip_path)
    assert zip_sha==EXPECTED_ZIP and zip_path.stat().st_size==794203
    assert sha_file(CI/'official-zip-attempt-1.zip')==zip_sha
    z=zipfile.ZipFile(zip_path); assert z.testzip() is None
    names=z.namelist(); assert len(names)==len(set(names))==44
    actual=set(names); expected_steps=set(); aggregates=set()
    api_job_names=[]
    for j in jobs:
        display=j['name'].replace('/','_'); api_job_names.append(display)
        for s in j['steps']:
            expected_steps.add(f'{display}/{s["number"]}_{s["name"].replace("/","_")}.txt')
    for name in api_job_names:
        aggregates.update(n for n in actual if '/' not in n and n.endswith('_'+name+'.txt'))
    system={n for n in actual if n.endswith('/system.txt')}
    present=expected_steps & actual; missing=sorted(expected_steps-actual)
    assert len(expected_steps)==52 and len(present)==38 and len(missing)==14
    assert len(aggregates)==4 and len(system)==2 and actual==present|aggregates|system
    assert sum(len(j['steps']) for j in jobs if j['name']=='stable / test and specification')==26
    stable_missing=[n for n in missing if n.startswith('stable _ test and specification/')]
    fuzz_missing=[n for n in missing if n.startswith('fuzz smoke/')]
    assert len(stable_missing)==5 and len(fuzz_missing)==9
    aggregate_for={
      'stable / test and specification':next(x for x in aggregates if x.startswith('1_')),
      'fuzz smoke':next(x for x in aggregates if x.startswith('0_')),
      'MSRV 1.88.0':next(x for x in aggregates if x.startswith('2_')),
      'supply chain':next(x for x in aggregates if x.startswith('3_')),
    }
    # One concrete payload-marker per missing step; marker means body exists in the raw aggregate.
    body_markers={
      ('stable / test and specification',2):'Run actions/checkout@v7.0.1',
      ('stable / test and specification',3):'Run dtolnay/rust-toolchain@stable',
      ('stable / test and specification',4):'Run actions/setup-java@v6.0.1',
      ('stable / test and specification',5):'Run actions/setup-node@v7.0.0',
      ('stable / test and specification',7):'Run cargo clippy --workspace --all-targets',
      ('fuzz smoke',2):'Run actions/checkout@v7.0.1',
      ('fuzz smoke',3):'Run dtolnay/rust-toolchain@master',
      ('fuzz smoke',4):'cargo install cargo-fuzz --version 0.13.2 --locked',
      ('fuzz smoke',6):'cargo +nightly-2026-07-20 test --manifest-path fuzz/Cargo.toml --locked',
      ('fuzz smoke',7):'fuzz run query',
      ('fuzz smoke',9):'fuzz run method_analysis',
      ('fuzz smoke',10):'git diff --exit-code',
      ('fuzz smoke',20):None,
      ('fuzz smoke',21):None,
    }
    raw_paths={'stable / test and specification':CI/'stable.log','fuzz smoke':CI/'fuzz-smoke.log','MSRV 1.88.0':CI/'msrv.log','supply chain':CI/'supply-chain.log'}
    raw_api={}
    for c in coll['commands']:
        argv=c['argv']
        if argv[:3]==['gh','run','view'] and '--job' in argv and '--log' in argv:
            idx=argv.index('--job'); jid=int(argv[idx+1]); job=next(j for j in jobs if j['id']==jid)
            raw_api[job['name']]=pathlib.Path(c['streams']['stdout']['path'])
    assert set(raw_api)==set(raw_paths)
    missing_step_evidence=[]
    for j in jobs:
        display=j['name'].replace('/','_'); agg=z.read(aggregate_for[j['name']]).decode('utf-8','replace')
        raw=raw_paths[j['name']].read_text(encoding='utf-8',errors='replace')
        for step in j['steps']:
            p=f'{display}/{step["number"]}_{step["name"].replace("/","_")}.txt'
            if p not in missing: continue
            marker=body_markers[(j['name'],step['number'])]
            aggregate_body=bool(marker and marker.lower() in agg.lower())
            raw_body=bool(marker and marker.lower() in raw.lower())
            missing_step_evidence.append({'job':j['name'],'step_number':step['number'],'step_name':step['name'],'zip_member':p,'individual_member_present':False,'aggregate_body_marker':marker,'aggregate_body_present':aggregate_body,'standard_job_raw_body_present':raw_body,'api_terminal_status':step['status'],'api_terminal_conclusion':step['conclusion'],'note':'API records terminal success; no unique body marker for this lifecycle step' if marker is None else None})
    assert len(missing_step_evidence)==14
    for item in missing_step_evidence:
        if item['step_number'] not in (20,21): assert item['aggregate_body_present']
        else: assert not item['aggregate_body_present']
    # Parse both complete fixed-seed groups from the closed stable job raw output, not from aggregate or missing members.
    common=load_module('fallback_common',FALLBACK/'common.py'); sys.modules['common']=common
    l45=load_module('fallback_loop45',FALLBACK/'verify-own-ci-loop45-attempt1.py')
    old=l45.load_local(FALLBACK/'verify-own-ci-attempt1.py','old_ci_parser')
    acceptance=load_json(pathlib.Path('/private/tmp/jarde-loop2-retry-native-ci-prep-luna-v2-20261019/acceptance-argv.json'))['verify_ci']
    old_extra=[acceptance[i+1] for i,t in enumerate(acceptance[:-1]) if t=='--extra-critical']
    ci_argv=load_json(FALLBACK/'ci-verify-argv.json')
    explicit=[ci_argv[i+1] for i,t in enumerate(ci_argv[:-1]) if t=='--supplemental-gate']
    supplemental=explicit+[f'{t}={n}' for group in (common.REGION_GATES,common.PUBLIC_GATES,common.DEFERRED_BUILDER_GATES) for t,n in group]
    assert (len(old.CRITICAL_TESTS),len(old_extra),len(explicit),len(supplemental))==(110,13,15,33)
    for prefix,items in [('acceptance extra',old_extra),('loop45 exact gate',supplemental)]:
        for index,item in enumerate(items,1):
            target,test=item.split('=',1); old.CRITICAL_TESTS[f'{prefix} {index}']=(test,target)
    assert len(old.CRITICAL_TESTS)==156 and len(set(old.CRITICAL_TESTS.values()))==156
    _,_,seeds=old.workflow_contract(CI/'product-source'/'.github'/'workflows'/'ci.yml')
    stable_raw=(CI/'stable.log').read_text(encoding='utf-8',errors='replace')
    groups=old.workspace_groups(stable_raw); assert len(groups)==2
    ci_counters=[]; seed_reports=[]
    for seed,group in zip(seeds,groups):
        parsed=old.parse_workspace_group(group,seed)
        assert parsed['target_count']==396 and parsed['workspace_totals']=={'passed':3856,'failed':0,'ignored':98,'measured':0,'filtered':0}
        gate_results=parsed['critical_tests_passed']
        assert len(gate_results)==156 and set(gate_results)==set(old.CRITICAL_TESTS)
        assert all(gate_results[label]==old.CRITICAL_TESTS[label][0] for label in old.CRITICAL_TESTS)
        ci_counter=raw_ci_counter(old,group)
        assert sum(ci_counter.values())==3954 and len(ci_counter)==3954
        ci_counters.append(ci_counter)
        seed_reports.append({'seed':seed,'target_count':parsed['target_count'],'workspace_totals':parsed['workspace_totals'],'exact_gate_count':156,'exact_gates_passed':True,'named_test_tuple_count':sum(ci_counter.values()),'unique_named_test_tuples':len(ci_counter),'raw_counter_sha256_preserving_should_panic':counter_hash(ci_counter),'ci_helper_counter_sha256_drops_should_panic':l45.counter_sha256(l45.named_outcome_counter(old,group))})
    assert ci_counters[0]==ci_counters[1]
    native_review=load_json(NATIVE_REVIEW)
    native_rows=native_review['running_bound_results']['normalized_counter_rows']
    native_sha=native_review['running_bound_results']['normalized_counter_sha256']
    assert len(native_rows)==3954 and native_sha==EXPECTED_NATIVE_COUNTER
    native_bytes=json.dumps(native_rows,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    assert sha_bytes(native_bytes)==native_sha
    native_counter=collections.Counter()
    for row in native_rows:
        assert len(row)==4 and row[3]>=1
        native_counter[tuple(row[:3])]+=row[3]
    assert sum(native_counter.values())==3954
    literal_diff_native=collections.Counter(native_counter-ci_counters[0])
    literal_diff_ci=collections.Counter(ci_counters[0]-native_counter)
    assert sum(literal_diff_native.values())==1 and sum(literal_diff_ci.values())==1
    masked=[(key,count) for key,count in native_counter.items() if key[0]=='bulk_recovery_backpressure' and key[1].startswith('a_result_wei')]
    assert len(masked)==1
    full_key,full_count=masked[0]
    assert full_key[1]==exact_source_name and full_key[2]=='ok' and full_count==1
    assert (full_key[0], 'a_result_wei***', full_key[2]) in ci_counters[0]
    assert ci_counters[0][(full_key[0],'a_result_wei***',full_key[2])]==1
    # Bind masked name to the unique full source/native candidate; normalize only this exact known redaction.
    def canonical(counter):
        result=collections.Counter()
        for (target,name,status),count in counter.items():
            if name=='a_result_wei***':
                assert target==full_key[0] and status==full_key[2] and count==full_count
                name=full_key[1]
            if name.endswith(' - should panic'): name=name[:-len(' - should panic')]
            result[(target,name,status)]+=count
        return result
    native_canonical=canonical(native_counter); ci_canonical=canonical(ci_counters[0])
    assert native_canonical==ci_canonical
    canonical_rows=rows_from_counter(native_canonical)
    canonical_sha=counter_hash(native_canonical)
    # The exact gate set does not contain the masked test, so source matching cannot satisfy a named gate.
    assert all(test!=exact_source_name for test,target in old.CRITICAL_TESTS.values())
    missing_json={'native_only':rows_from_counter(literal_diff_native),'ci_only':rows_from_counter(literal_diff_ci)}
    # Auditable text-origin proof for the two representation differences.
    stable_lines=stable_raw.splitlines()
    redacted_lines=[i+1 for i,line in enumerate(stable_lines) if 'a_result_wei***' in old.clean_line(line)]
    panic_lines=[i+1 for i,line in enumerate(stable_lines) if 'a_requirement_a_rule_never_declared_cannot_be_refused_under - should panic' in old.clean_line(line)]
    assert len(redacted_lines)==2 and len(panic_lines)==2
    report={
      'schema':'last-four-own-ci-independent-review-v2',
      'status':'verified_terminal_run_with_official_zip_step_member_gap',
      'run':{'id':EXPECTED_RUN,'attempt':1,'head_sha':EXPECTED_HEAD,'product_sha':coll['product_sha'],'cli_sha256':coll['cli_sha256'],'run_status':run['status'],'run_conclusion':run['conclusion'],'jobs_total':len(jobs),'api_step_total':step_total,'all_jobs_and_steps_completed_success':True},
      'receipt':{'collection_status':coll['status'],'collection_sha256':sha_file(CI/'collection.json'),'command_count':len(coll['commands']),'stdout_stderr_stream_count':len(command_details),'command_streams_rehashed':True,'source_before_after_equal':coll['source_before_after_equal'],'target_absent_after':coll['target_absent_after'],'source_file_count':len(source_file_checks),'fixture_file_count':len(fixture_file_checks),'source_file_git_show_pins_rehashed':True,'fixture_git_show_pins_rehashed':True,'source_paths_sha256':sha_file(CI/'source-pins.json'),'adapter_inputs_sha256':sha_file(CI/'final-adapter-inputs.json')},
      'zip':{'path':str(zip_path),'bytes':zip_path.stat().st_size,'sha256':zip_sha,'crc':'passed','member_total':len(names),'api_steps_expected':52,'individual_api_step_members_present':len(present),'individual_api_step_members_missing':missing,'aggregate_job_logs':sorted(aggregates),'synthetic_system_members':sorted(system),'unlisted_members':[],'missing_member_body_evidence':missing_step_evidence,'strict_official_zip_verifier':'not_passed: verifier requires per-step member stable _ test and specification/2_Run actions_checkout@v7.0.1.txt'},
      'seed_runs':seed_reports,
      'counter_comparison':{'native_sha256_from_review':native_sha,'ci_raw_counter_sha256_preserving_should_panic':counter_hash(ci_counters[0]),'ci_helper_counter_sha256_dropping_should_panic':seed_reports[0]['ci_helper_counter_sha256_drops_should_panic'],'literal_tuple_equality':False,'literal_native_only':missing_json['native_only'],'literal_ci_only':missing_json['ci_only'],'source_backed_mask_match':{'target':full_key[0],'full_test_name':full_key[1],'source':'tests/bulk_recovery_backpressure.rs','source_sha256':native_source_pin,'definition_line':source_lines[0],'masked_ci_label':'a_result_wei***','same_status':'ok','same_multiplicity':1,'unique_native_candidate_count':1,'masked_raw_line_numbers':redacted_lines},'should_panic_rendering':{'native_name_has_suffix':True,'ci_helper_drops_suffix':True,'raw_ci_lines_preserve_suffix':panic_lines,'canonical_rule':'remove the display-only ` - should panic` suffix; preserve test identity/status/count'},'canonical_projection':{'rule':'replace only the unique source-backed a_result_wei*** alias with its pinned full name; strip only the Rust should-panic display suffix; do not alter target/status/count','tuple_equality':True,'tuple_count':3954,'sha256':canonical_sha},'masked_test_is_exact_gate':False},
      'interpretation':'GitHub reports the workflow and all 4 jobs / 52 API steps completed successfully, and both fixed-seed workspace logs contain all 156 exact gates passing. The official ZIP is CRC-valid and has 44 entries, but only 38 of 52 API step members; it lacks 14 individual entries. The full stable aggregate contains the 5 stable missing step bodies; the full fuzz aggregate contains 7 of 9 missing fuzz step bodies, while the post-checkout and Complete job steps have no independently identifiable output body. The separate standard fuzz job-log raw is incomplete, so it is not substituted for the full ZIP aggregate. The strict repository verifier did not pass because the required stable step-2 ZIP member is absent. CI/native literal Counter rows differ only by one GitHub-masked test label and one should-panic display suffix; the pinned test definition uniquely resolves the mask, and the normalized full Counter equals. This independent evidence does not claim the strict ZIP verifier passed.'
    }
    (OUT/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (OUT/'raw-command-pins.json').write_text(json.dumps(coll['commands'],ensure_ascii=False,indent=2)+'\n')
    (OUT/'source-fixture-pins-rechecked.json').write_text(json.dumps({'source_files':source_file_checks,'fixture_files':fixture_file_checks},ensure_ascii=False,indent=2)+'\n')
    (OUT/'helper-pins.json').write_text(json.dumps({'fallback_pins_sha256':sha_file(FALLBACK/'pins.json'),'verified_helpers':helper_hashes,'acceptance_argv_sha256':sha_file(ACCEPTANCE)},ensure_ascii=False,indent=2)+'\n')
    (OUT/'canonical-counter-rows.json').write_text(json.dumps(canonical_rows,ensure_ascii=False,indent=2)+'\n')
    (OUT/'native-only-tuples.json').write_text(json.dumps(missing_json['native_only'],ensure_ascii=False,indent=2)+'\n')
    (OUT/'ci-only-tuples.json').write_text(json.dumps(missing_json['ci_only'],ensure_ascii=False,indent=2)+'\n')
    return report

if __name__=='__main__':
    r=main()
    print(json.dumps({'status':r['status'],'run':r['run'],'zip':r['zip'],'counter_comparison':r['counter_comparison']},ensure_ascii=False,indent=2))
