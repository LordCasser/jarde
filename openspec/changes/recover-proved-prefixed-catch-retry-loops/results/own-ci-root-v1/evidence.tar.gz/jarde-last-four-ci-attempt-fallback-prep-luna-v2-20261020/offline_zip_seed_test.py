from __future__ import annotations
import hashlib, importlib.util, json, sys, tempfile, zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module
common = load(HERE/'common.py', 'fallback_common_test')
sys.modules['common'] = common
verify = load(HERE/'verify-own-ci-attempt1.py', 'fallback_api_verifier_test')
adapter = load(HERE/'verify-own-ci-loop45-attempt1.py', 'fallback_loop45_verifier_test')
collector_wrapper = load(HERE/'collect-own-ci-loop45-attempt1.py', 'fallback_loop45_collector_test')
def sha(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def values(argv, option): return [argv[i+1] for i,t in enumerate(argv[:-1]) if t==option]

collect_argv=json.loads((HERE/'ci-collect-argv.json').read_text())
verify_argv=json.loads((HERE/'ci-verify-argv.json').read_text())
assert values(collect_argv,'--supplemental-gate') == values(verify_argv,'--supplemental-gate')
expected_gates=values(verify_argv,'--supplemental-gate')
assert len(expected_gates)==15 and len(set(expected_gates))==15
assert [collector_wrapper.pair(value) for value in expected_gates] == [adapter.parse_pair(value) for value in expected_gates]
assert [adapter.parse_pair(value) for value in expected_gates] == [
    (target, test) for target, test in (spec.split('=',1) for spec in expected_gates)]
assert values(collect_argv,'--source-file') == values(verify_argv,'--source-file')
assert values(collect_argv,'--fixture-root') == values(verify_argv,'--fixture-root')
acceptance_path=common.BASE/'acceptance-argv.json'
assert common.sha(acceptance_path)==common.BASE_PINS['acceptance-argv.json']
for i,spec in enumerate(values(json.loads(acceptance_path.read_text())['verify_ci'],'--extra-critical'),1):
    target,name=spec.split('=',1)
    verify.CRITICAL_TESTS[f'offline frozen extra {i}']=(name,target)
all_gates=list(common.REGION_GATES)+list(common.PUBLIC_GATES)+list(common.DEFERRED_BUILDER_GATES)
for i,(target,name) in enumerate(all_gates,1):
    verify.CRITICAL_TESTS[f'offline Loop45 gate {i}']=(name,target)
for i,spec in enumerate(expected_gates,1):
    target,name=spec.split('=',1)
    verify.CRITICAL_TESTS[f'offline frozen supplemental gate {i}']=(name,target)
identities=list(verify.CRITICAL_TESTS.values())
assert len(identities)==156 and len(set(identities))==156, (len(identities),len(set(identities)))
per_target={}
for name,target in identities: per_target.setdefault(target,[]).append(name)
filler_count=3954-len(identities)
assert filler_count>0
per_target.setdefault('jarde_java',[]).extend(f'offline_filler_{i:04d}' for i in range(filler_count))
def cargo_output(seed: str) -> bytes:
    lines=[f'##[group]Run {verify.WORKSPACE_COMMAND}',f'PROPTEST_RNG_SEED: {seed}']
    for target,names in sorted(per_target.items()):
        lines.append(f'Running unittests src/lib.rs (target/debug/deps/{target}-0123456789abcdef)')
        lines.append(f'running {len(names)} tests')
        lines.extend(f'test {name} ... ok' for name in names)
        lines.append(f'test result: ok. {len(names)} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out')
    return ('\n'.join('2026-10-20T00:00:00Z '+line for line in lines)+'\n').encode()
seeds=verify.workflow_contract(common.ROOT/'.github/workflows/ci.yml')[2]
payloads=[cargo_output(seed) for seed in seeds]
with tempfile.TemporaryDirectory(prefix='loop45-attempt1-zip-seeds-') as temp:
    evidence=Path(temp); (evidence/'job-details').mkdir()
    run_id='39278336384'; product='8ea98e2e11d64f02092ac200d2b596511dcf5e40'
    jobs=[]; detail_rows=[]; next_id=10001
    stable=verify.EXPECTED_JOBS['stable']
    for slug,display in verify.EXPECTED_JOBS.items():
        job_id=next_id; next_id+=1
        if slug=='stable':
            steps=[
                {'number':1,'name':'Run workspace tests with two fixed independent seeds (pass 1)','status':'completed','conclusion':'success','content':payloads[0]},
                {'number':2,'name':'Run workspace tests with two fixed independent seeds (pass 2)','status':'completed','conclusion':'success','content':payloads[1]},
            ]
        else:
            steps=[{'number':1,'name':'Synthetic completed job step','status':'completed','conclusion':'success','content':b'2026-10-20T00:00:00Z completed\n'}]
        for step in steps:
            zip_member=f"{display.replace('/','_')}/{step['number']}_{step['name'].replace('/','_')}.txt"
            step['zip_member']=zip_member
        jobs.append({'id':job_id,'run_id':int(run_id),'run_attempt':1,'head_sha':product,'name':display,'status':'completed','conclusion':'success'})
        detail={'id':job_id,'run_id':int(run_id),'run_attempt':1,'head_sha':product,'name':display,'status':'completed','conclusion':'success',
                'steps':[{k:v for k,v in step.items() if k not in ('content','zip_member')} for step in steps]}
        detail_rows.append((detail,steps))
        (evidence/'job-details'/f'{job_id}.json').write_text(json.dumps(detail))
    (evidence/'collection.json').write_text(json.dumps({'run_id':run_id,'product_sha':product}))
    (evidence/'run-rest.json').write_text(json.dumps({'id':int(run_id),'run_attempt':1,'head_sha':product}))
    (evidence/'attempt1-jobs-api.json').write_text(json.dumps({'total_count':4,'jobs':jobs}))
    zip_path=evidence/'run-logs.zip'
    with zipfile.ZipFile(zip_path,'w') as z:
        for detail,steps in detail_rows:
            for step in steps: z.writestr(step['zip_member'],step['content'])
    raw=zip_path.read_bytes(); stderr_path=evidence/'run-logs.stderr.raw'; stderr_path.write_bytes(b'')
    run_raw=(evidence/'run-rest.json').read_bytes(); collection_raw=(evidence/'collection.json').read_bytes()
    supplement={'argv':['gh','api',f'repos/{verify.REPO}/actions/runs/{run_id}/logs'],'exit_code':0,'run_id':run_id,
                'product_sha':product,'collection_json_sha256':sha(collection_raw),'run_rest_json_sha256':sha(run_raw),
                'streams':{'stdout':{'path':str(zip_path),'bytes':len(raw),'sha256':sha(raw)},
                           'stderr':{'path':str(stderr_path),'bytes':0,'sha256':sha(b'')}}}
    (evidence/'step-log-supplement.json').write_text(json.dumps(supplement))
    logs=verify.official_step_logs(evidence)
    groups=verify.workspace_groups(logs[stable])
    assert len(groups)==2, f'ZIP-derived groups={len(groups)}'
    parsed=[verify.parse_workspace_group(group,seed) for group,seed in zip(groups,seeds)]
    assert [row['named_test_outcomes'] for row in parsed]==[3954,3954]
    assert [row['seed'] for row in parsed]==list(seeds)
    assert all(len(row['critical_tests_passed'])==156 for row in parsed)
    counters=[adapter.named_outcome_counter(verify,group) for group in groups]
    adapter.compare_seed_counters(counters[0],counters[1])
    assert [sum(counter.values()) for counter in counters]==[3954,3954]
    print('offline ZIP-derived two-seed parsing and frozen gate binding passed: 3,954 named outcomes and all 156 exact identities per seed')
