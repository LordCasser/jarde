#!/usr/bin/env python3
"""Reuse accepted CI/source/log verification and add exact Loop4/5/future gates."""
from __future__ import annotations
import argparse
import importlib.util
import contextlib
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import common
HERE = Path(__file__).resolve().parent
COLLECT_ARGV = HERE / 'ci-collect-argv.json'
VERIFY_ARGV = HERE / 'ci-verify-argv.json'
COLLECT_ARGV_SHA256 = 'c3deca219e38a18525ca7dc495267f2ca5742c7df3879c000996385e4a3537ba'
VERIFY_ARGV_SHA256 = '6edcabbd2e1b02940e81831f02e78cafe1cea04f2b0ed6c316b7e89ef39f169d'
def frozen_args(path: Path, expected: str):
    if common.sha(path) != expected: raise RuntimeError(f'frozen closeout argv changed: {path.name}')
    return json.loads(path.read_text(encoding='utf-8'))
def option_values(argv, option):
    return [argv[i + 1] for i, token in enumerate(argv[:-1]) if token == option]
def load_local(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot load local protocol tool: {path}')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module


def parse_pair(spec: str) -> tuple[str, str]:
    target, sep, test = spec.partition('=')
    if not sep or not target or not test or any(ch.isspace() for ch in target + test):
        raise argparse.ArgumentTypeError('expected TARGET=FULL_TEST_NAME without whitespace')
    return target, test


def named_outcome_counter(old, group: str) -> Counter:
    """Read every complete (Cargo target, test name, status) tuple from one seed log."""
    lines = [old.clean_line(line) for line in group.splitlines()]
    headers = [line for line in lines if line.startswith('Running ')]
    blocks = []
    i = 0
    while i < len(lines):
        running = old.RUNNING.fullmatch(lines[i])
        if not running:
            i += 1
            continue
        declared = int(running.group(1))
        named = []
        j = i + 1
        while j < len(lines):
            summary = old.SUMMARY.fullmatch(lines[j])
            if summary:
                counts = tuple(int(summary.group(n)) for n in range(2, 5))
                old.need(declared == len(named), 'target test count differs from named outcomes in Counter pass')
                seen = (sum(state == 'ok' for _, state in named),
                        sum(state == 'FAILED' for _, state in named),
                        sum(state == 'ignored' for _, state in named))
                old.need(seen == counts and counts[1] == 0,
                         'target outcome statuses differ from Cargo summary in Counter pass')
                blocks.append(named)
                i = j + 1
                break
            outcome = old.OUTCOME.fullmatch(lines[j])
            if outcome:
                state = 'ignored' if outcome.group(2).startswith('ignored') else outcome.group(2)
                named.append((outcome.group(1), state))
            elif lines[j].startswith('test result:') or lines[j].startswith('test '):
                raise ValueError(f'unparsed Cargo output in full Counter pass: {lines[j]}')
            j += 1
        else:
            raise ValueError(f'incomplete Cargo target block in Counter pass: {lines[i]}')
    old.need(bool(blocks) and len(headers) == len(blocks),
             'Cargo target headers and named outcome blocks differ in Counter pass')
    triples = []
    for named, header in zip(blocks, headers):
        target_header = old.RUN_TARGET.fullmatch(header)
        old.need(target_header is not None, f'unparsed target header in Counter pass: {header!r}')
        executable = target_header.group('path').rsplit('/', 1)[-1]
        target_match = old.HASHED_EXE.fullmatch(executable)
        old.need(target_match is not None, f'unrecognized Cargo target executable in Counter pass: {executable!r}')
        target = target_match.group('target')
        triples.extend((target, test_name, status) for test_name, status in named)
    return Counter(triples)

def counter_rows(counter: Counter) -> list[list[object]]:
    return [[target, name, status, count]
            for (target, name, status), count in sorted(counter.items())]

def counter_sha256(counter: Counter) -> str:
    payload = json.dumps(counter_rows(counter), ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(payload).hexdigest()

def compare_seed_counters(left: Counter, right: Counter) -> None:
    if left != right:
        raise ValueError('complete (target, testname, status) Counter differs between fixed seeds')

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence_dir', type=Path)
    parser.add_argument('--product-sha', required=True)
    parser.add_argument('--cli-sha256', required=True)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--supplemental-gate', action='append', default=[], type=parse_pair,
                        metavar='TARGET=FULL_TEST_NAME',
                        help='additional exact gate after its Region test name is finalized')
    parser.add_argument('--source-file', action='append', default=[])
    parser.add_argument('--fixture-root', action='append', default=[])
    args = parser.parse_args()
    frozen = frozen_args(VERIFY_ARGV, VERIFY_ARGV_SHA256)
    collect = frozen_args(COLLECT_ARGV, COLLECT_ARGV_SHA256)
    expected_gate_specs = option_values(frozen, '--supplemental-gate')
    expected_gates = [parse_pair(value) for value in expected_gate_specs]
    expected_sources = option_values(frozen, '--source-file')
    expected_roots = option_values(frozen, '--fixture-root')
    if args.product_sha != frozen[frozen.index('--product-sha') + 1] or args.cli_sha256 != frozen[frozen.index('--cli-sha256') + 1]:
        raise RuntimeError('product/CLI pins differ from frozen verification argv')
    if args.supplemental_gate != expected_gates or args.source_file != expected_sources or args.fixture_root != expected_roots:
        raise RuntimeError('verifier inputs differ from the frozen exact gate/source/fixture argv')
    if option_values(collect, '--supplemental-gate') != expected_gate_specs or option_values(collect, '--source-file') != expected_sources or option_values(collect, '--fixture-root') != expected_roots:
        raise RuntimeError('frozen collector and verifier argv inventories differ')
    collection_doc = json.loads((args.evidence_dir / 'collection.json').read_text(encoding='utf-8'))
    if str(collection_doc.get('run_id')) != str(collect[4]):
        raise RuntimeError('collected run ID differs from the frozen closeout run')
    if str(collection_doc.get('product_sha')) != str(args.product_sha) or str(collection_doc.get('cli_sha256')) != str(args.cli_sha256):
        raise RuntimeError('collected product/CLI pins differ from frozen verifier inputs')
    if args.out.exists():
        raise FileExistsError(f'refusing to overwrite {args.out}')
    old = load_local(HERE / 'verify-own-ci-attempt1.py', 'loop45_attempt1_ci_verifier')
    inventory = common.extend_ci_inventory(old, args.source_file, args.fixture_root)
    sidecar_path = args.evidence_dir / 'final-adapter-inputs.json'
    sidecar = json.loads(sidecar_path.read_text(encoding='utf-8'))
    expected_sidecar = {'schema':'jarde-final-ci-adapter-inputs-v2-attempt1','run_id':str(json.loads((args.evidence_dir/'collection.json').read_text())['run_id']),'product_sha':str(args.product_sha),'cli_sha256':str(args.cli_sha256),'source_files':inventory['supplemental_source_files'],'fixture_roots':inventory['supplemental_fixture_roots'],'supplemental_gates':[{'target':t,'test':n} for t,n in args.supplemental_gate],'protocol':'native-run-rest+attempt-1-jobs+individual-job-details'}
    if sidecar != expected_sidecar:
        raise RuntimeError('CI verifier inputs differ from the frozen collector adapter sidecar')
    base_argv_pin = common.BASE / 'acceptance-argv.json'
    if common.sha(base_argv_pin) != common.BASE_PINS['acceptance-argv.json']:
        raise RuntimeError('frozen accepted CI argument inventory changed')
    acceptance_argv = json.loads(base_argv_pin.read_text(encoding='utf-8'))
    args_vector = acceptance_argv['verify_ci']
    fixed_extra = [args_vector[i + 1] for i, token in enumerate(args_vector[:-1]) if token == '--extra-critical']
    if len(fixed_extra) != 13:
        raise RuntimeError('accepted 13 --extra-critical identities are not intact')
    base_sys_argv = [str(HERE / 'verify-own-ci-attempt1.py'), str(args.evidence_dir),
                     '--product-sha', args.product_sha, '--cli-sha256', args.cli_sha256,
                     '--repo', str(common.ROOT)]
    for spec in fixed_extra:
        base_sys_argv.extend(['--extra-critical', spec])
    saved_argv = sys.argv
    stdout = io.StringIO()
    try:
        sys.argv = base_sys_argv
        with contextlib.redirect_stdout(stdout):
            status = old.main()
    finally:
        sys.argv = saved_argv
    if status not in (None, 0):
        return int(status)
    base_report = json.loads(stdout.getvalue())
    if base_report.get('status') != 'accepted' or base_report.get('critical_gate_count') != 123:
        raise RuntimeError('frozen CI verifier did not accept all 123 inherited gates')
    ci = base_report.get('ci', {})
    if ci.get('job_count') != 4 or ci.get('expanded_api_step_count') != 52:
        raise RuntimeError('official API evidence must bind exactly four jobs and 52 steps')

    gates = list(common.REGION_GATES) + list(common.PUBLIC_GATES) + list(common.DEFERRED_BUILDER_GATES) + list(args.supplemental_gate)
    if len(common.REGION_GATES) != 11 or len(common.PUBLIC_GATES) != 4 or len(common.DEFERRED_BUILDER_GATES) != 3:
        raise SystemExit('frozen Loop45 supplemental gate inventory changed')
    if len(gates) != 33 or len(gates) != len(set(gates)):
        raise SystemExit('duplicate supplemental CI exact gate identity')
    known = set(old.CRITICAL_TESTS.values())
    if any((test, target) in known for target, test in gates):
        raise SystemExit('supplemental gate duplicates an inherited exact identity')
    for index, (target, test) in enumerate(gates, start=1):
        old.CRITICAL_TESTS[f'Loop45 supplemental {index}: {target}::{test}'] = (test, target)

    logs = old.official_step_logs(args.evidence_dir.resolve(strict=True))
    stable = logs[old.EXPECTED_JOBS['stable']]
    _, _, seeds = old.workflow_contract(common.ROOT / '.github/workflows/ci.yml')
    groups = old.workspace_groups(stable)
    if len(groups) != 2:
        raise RuntimeError('official stable step log does not contain both fixed-seed runs')
    seed_reports = [old.parse_workspace_group(group, seed) for group, seed in zip(groups, seeds)]
    if [row['seed'] for row in seed_reports] != list(seeds):
        raise RuntimeError('official workspace run seeds differ from workflow order')
    if (seed_reports[0]['target_inventory'] != seed_reports[1]['target_inventory']
            or seed_reports[0]['target_summaries'] != seed_reports[1]['target_summaries']):
        raise RuntimeError('complete per-target summaries differ between fixed seeds')
    outcome_counters = [named_outcome_counter(old, group) for group in groups]
    try:
        compare_seed_counters(outcome_counters[0], outcome_counters[1])
    except ValueError as error:
        raise RuntimeError(str(error)) from error
    if any(sum(counter.values()) != row['named_test_outcomes']
           for counter, row in zip(outcome_counters, seed_reports)):
        raise RuntimeError('full outcome Counter size differs from parsed named-test count')
    if any(sum(counter.values()) != 3954 for counter in outcome_counters):
        raise RuntimeError('complete named-test Counter must contain exactly 3,954 outcomes per seed')
    if len(args.supplemental_gate) != 15:
        raise RuntimeError('the frozen final CI inventory requires exactly 15 supplemental gates')
    labels = [f'Loop45 supplemental {index}: {target}::{test}'
              for index, (target, test) in enumerate(gates, start=1)]
    for index, seed_report in enumerate(seed_reports):
        passed = seed_report['critical_tests_passed']
        if not set(labels).issubset(passed):
            raise RuntimeError(f'supplemental exact gate outcomes absent in seed {seeds[index]}')

    report = {
        'schema': 'loop45-own-ci-supplemental-review-v1',
        'status': 'accepted',
        'product': base_report['product'],
        'base_acceptance': base_report,
        'base_exact_gate_count': 123,
        'loop45_region_gate_count': len(common.REGION_GATES),
        'loop45_public_gate_count': len(common.PUBLIC_GATES),
        'deferred_extra_critical_count': len(common.DEFERRED_BUILDER_GATES) + len(args.supplemental_gate),
        'preserved_exact_gate_count': 141,
        'final_exact_gate_count': 156,
        'supplemental_gate_count': len(args.supplemental_gate),
        'supplemental_exact_gates': [
            {'target': target, 'test': test, 'runs': [seeds[0], seeds[1]], 'once_per_seed_passed': True}
            for target, test in gates
        ],
        'complete_target_summaries_equal_between_seeds': True,
        'complete_target_testname_status_counter_equal_between_seeds': True,
        'full_named_outcome_count_per_seed': [sum(c.values()) for c in outcome_counters],
        'distinct_target_testname_status_counter_entries': len(outcome_counters[0]),
        'full_counter_sha256': counter_sha256(outcome_counters[0]),
        'fixed_seeds': list(seeds),
        'source_and_fixture_inventory': {
            'source_paths': list(old.SOURCE_PATHS),
            'fixture_roots': list(old.FIXTURE_ROOTS),
            'fixture_file_count': len(old.EXPECTED_FIXTURE_FILES),
        },
        'official_step_zip_and_live_source_binding': 'validated by pinned frozen base CI verifier/collector',
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'base_gates': 123,
                      'supplemental_gates': len(gates), 'output': str(args.out)}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
