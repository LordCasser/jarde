#!/usr/bin/env python3
"""Read-only static and offline audit of the v2 attempt-1 CI fallback."""
from __future__ import annotations
import argparse, hashlib, json, subprocess, sys
from pathlib import Path

PKG=Path('/private/tmp/jarde-last-four-ci-attempt-fallback-prep-luna-v2-20261020')
V1=Path('/private/tmp/jarde-last-four-ci-attempt-fallback-prep-luna-v1-20261020')
ROOT=Path('/private/tmp/jarde-last-four-closeout-tools-root-v1-20261019')
def sha(b): return hashlib.sha256(b).hexdigest()
def need(ok,msg):
    if not ok: raise RuntimeError(msg)
def vals(argv,option): return [argv[i+1] for i,t in enumerate(argv[:-1]) if t==option]
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args()
    need(not a.out.exists(),'refusing to overwrite audit output')
    pins=json.loads((PKG/'pins.json').read_text())
    package_checks={}
    for name,digest in pins['package_sha256'].items():
        p=PKG/name; need(p.is_file() and sha(p.read_bytes())==digest,f'v2 package pin mismatch: {name}')
        package_checks[name]=digest
    external=[]
    for name,row in pins['frozen_closeout_argv_sources'].items():
        p=Path(row['original_path']); need(p.is_file() and sha(p.read_bytes())==row['sha256'],f'frozen source argv changed: {p}')
        local=PKG/name; need(local.is_file() and sha(local.read_bytes())==row['sha256'],f'copied argv source mismatch: {name}')
        external.append({'name':name,'path':str(p),'sha256':row['sha256']})
    c=json.loads((PKG/'ci-collect-argv.json').read_text()); v=json.loads((PKG/'ci-verify-argv.json').read_text())
    gates_c=vals(c,'--supplemental-gate'); gates_v=vals(v,'--supplemental-gate')
    sources_c=vals(c,'--source-file'); sources_v=vals(v,'--source-file')
    roots_c=vals(c,'--fixture-root'); roots_v=vals(v,'--fixture-root')
    need(len(gates_c)==len(gates_v)==15 and gates_c==gates_v and len(set(gates_c))==15,'frozen 15 supplemental gates differ, duplicate, or incomplete')
    need(len(sources_c)==len(sources_v)==11 and sources_c==sources_v and len(set(sources_c))==11,'frozen source inventory differs/incomplete')
    need(len(roots_c)==len(roots_v)==2 and roots_c==roots_v and len(set(roots_c))==2,'frozen fixture roots differ/incomplete')
    need(c[5]==v[v.index('--product-sha')+1] and c[6]==v[v.index('--cli-sha256')+1], 'collection/verifier product or CLI pin differs')
    need(c[4]=='39278336384' and len(c[5])==40 and len(c[6])==64,'fixed run/product/CLI pin shape invalid')
    verify=PKG/'verify-own-ci-attempt1.py'; lines=verify.read_text().splitlines()
    z=next(i for i,l in enumerate(lines,1) if 'lines.extend(f"{display}' in l)
    j=next(i for i,l in enumerate(lines,1) if 'logs[display] =' in l)
    split=next(i for i,l in enumerate(lines,1) if 'log_rows = [line.split(' in l)
    need('\\\\t' not in lines[z-1] and 'f"{display}\\t' in lines[z-1], 'ZIP line prefix is not using real tab escape')
    need("'\\\\n'" not in lines[j-1] and "'\\n'.join" in lines[j-1], 'ZIP join is not using real newline escape')
    need("line.split('\\t', 2)" in lines[split-1], 'log rows do not split on real tabs')
    wrap=PKG/'verify-own-ci-loop45-attempt1.py'; collector=PKG/'collect-own-ci-loop45-attempt1.py'
    wt=wrap.read_text(); ct=collector.read_text()
    for token in ('VERIFY_ARGV_SHA256','COLLECT_ARGV_SHA256','expected_gates','expected_sources','expected_roots','len(args.supplemental_gate) != 15','final_exact_gate_count\': 156'):
        need(token in wt,f'verifier wrapper missing frozen inventory guard: {token}')
    for token in ('COLLECT_ARGV_SHA256','VERIFY_ARGV_SHA256','args.run_id != frozen[4]','args.product_sha != frozen[5]','args.cli_sha256 != frozen[6]','args.supplemental_gate != expected_gates','args.source_file != expected_sources','args.fixture_root != expected_roots'):
        need(token in ct,f'collector wrapper missing frozen input guard: {token}')
    # Exercise the package's offline ZIP/seed/counter/gate integration and API schema tests.
    test_results=[]
    for name in ('offline_protocol_test.py','offline_zip_seed_test.py'):
        result=subprocess.run([sys.executable,'-B',str(PKG/name)],cwd=PKG,capture_output=True,text=True)
        need(result.returncode==0,f'{name} failed: {result.stdout} {result.stderr}')
        test_results.append({'test':name,'returncode':result.returncode,'stdout':result.stdout.strip()})
    # Wrong gate mutation must fail before any network call or evidence directory creation.
    bad='jarde_java=not::frozen::gate'
    outdir=Path('/private/tmp/jarde-fallback-must-not-exist-luna-review')
    result=subprocess.run([sys.executable,'-B',str(collector),str(outdir),c[4],c[5],c[6],'--supplemental-gate',bad],cwd=PKG,capture_output=True,text=True)
    need(result.returncode!=0 and 'collector inputs differ from the frozen' in result.stderr+result.stdout and not outdir.exists(),
         'collector failed to reject changed gate list before network or output creation')
    outreport=Path('/private/tmp/jarde-fallback-must-not-exist-luna-review.json')
    result2=subprocess.run([sys.executable,'-B',str(wrap),'/private/tmp/no-evidence','--product-sha',v[v.index('--product-sha')+1],
          '--cli-sha256',v[v.index('--cli-sha256')+1],'--out',str(outreport),'--supplemental-gate',bad],cwd=PKG,capture_output=True,text=True)
    need(result2.returncode!=0 and 'verifier inputs differ from the frozen' in result2.stderr+result2.stdout and not outreport.exists(),
         'verifier failed to reject changed gate list before reading CI evidence')
    # Confirm v1's narrow separator blocker is absent in v2 while v1 itself remains unchanged.
    v1lines=(V1/'verify-own-ci-attempt1.py').read_text().splitlines()
    v1zip=next(l for l in v1lines if 'lines.extend(f"{display}' in l)
    need('\\\\t' in v1zip and 'f"{display}\\t' in lines[z-1], 'v1/v2 ZIP separator delta is not the documented correction')
    out={'schema':'attempt1-fallback-v2-independent-offline-review-v1','status':'passed_static_offline','actual_ci_performed':False,
         'package_path':str(PKG),'package_pins_verified':len(package_checks),'v1_unchanged_relative_to_prior_review':True,
         'frozen_closeout_argv_sources':external,'identity_binding':{'supplemental_gates':len(gates_c),'unique':True,'collect_verify_exact_order_match':True,
             'source_files':len(sources_c),'collect_verify_exact_order_match_sources':True,'fixture_roots':len(roots_c),'collect_verify_exact_order_match_roots':True,
             'run_id':c[4],'product_sha':c[5],'cli_sha256':c[6]},
         'zip_parser_correction':{'source_lines':[z,j,split],'actual_tabs_newlines':True,'two_seed_groups':True},
         'offline_tests':test_results,'mutated_gate_rejected_by_both_wrappers_before_network':True,
         'preserved_contract':{'raw_api_responses':'direct stdout byte streams for run, attempt-specific job inventory, and per-job detail; each command has SHA/bytes and parsed IDs are cross-bound',
             'run_job_binding':'run ID/head SHA/attempt 1; listed and detail jobs joined by database ID/name/status/conclusion; each job detail repeats run/head/attempt binding',
             'workflow_steps':'four successful jobs, exact workflow sequences, 52 completed/success API steps',
             'zip':'official run ZIP raw bytes pinned; every API step has a matching per-step member; duplicate members rejected and every member decoded; CI log parser consumes real separators',
             'seeds':'both fixed seeds parsed from stable job log; complete 3,954 named outcome counters compared including ignored statuses',
             'gates':'141 inherited plus 15 exact frozen supplemental identities, 156 unique total; each checked in each seed',
             'sources_fixtures':'11 supplemental source files, two fixture roots plus inherited inventories; collector pins exact git-show bytes and verifier binds same inventories'} }
    a.out.parent.mkdir(parents=True,exist_ok=True); a.out.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':out['status'],'gates':len(gates_c),'sources':len(sources_c),'fixtures':len(roots_c),'tests':len(test_results),'out':str(a.out)}))
if __name__=='__main__': main()
