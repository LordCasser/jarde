# CI attempt-1 fallback v2 review

Independent static and offline review of the v2 prepared fallback. No live CI receipt was consumed, and no network, Git, or product toolchain was run.

The v1 ZIP-log escaping blocker is fixed: source lines 449-450 now use actual tab/newline escapes, and the parser splits records on a real tab. Both local offline suites pass. The ZIP-derived synthetic stable log yields two seed groups, parses 3,954 named outcomes per seed, compares complete Counters, and checks all 156 frozen exact identities in each seed.

The v2 wrappers bind all 15 supplemental gate identities, 11 source paths, two fixture roots, run ID, product SHA and CLI SHA to the copied frozen closeout argv files. Those source argv files match their pinned originals. A wrong-gate mutation is rejected by both collector and verifier before network access or evidence reading.

API response bodies remain direct captured stdout with SHA/byte records; run/job IDs, head SHA and attempt 1 are cross-checked. Four successful jobs and 52 successful API steps are required. The ZIP verifier reads every expected API step member and rejects duplicate names, consistent with the frozen verifier's completeness rule.

Actual CI is still pending. This review establishes only that the prepared protocol and its offline path are internally consistent; the final receipt still requires an independent real-CI audit.

Re-run with `python3 -B audit_v2.py --out review.json` only in a fresh copy of this review directory.
