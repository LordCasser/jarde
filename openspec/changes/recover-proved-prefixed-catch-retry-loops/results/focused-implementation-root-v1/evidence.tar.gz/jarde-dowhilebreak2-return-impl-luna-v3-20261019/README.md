# DoWhileBreak2 whole-class public API acceptance

This is a separate v3 test-only package following the repository’s established `Engine::class_source` pattern in `tests/recover_loop45_original_public.rs`. It covers frozen debug/no-debug class and full-JAR inputs through `SingleClass`/`PlainJar`, each with default and all evidence. The acceptance checks the exact field and constructor/test/check inventories, each method’s structured recovered report, physical source-map anchors, and default/all parity. The raw `Iterator` generic display diagnostic is allowed.

No Rust toolchain or CLI was run. The test source and four fixture input pins are in `manifest.json`; `candidate.patch` adds only `tests/recover_do2_return_public.rs`. Root command: `cargo test -p jarde --test recover_do2_return_public original_dowhilebreak2_debug_no_debug_class_and_full_jar_default_all_are_structured -- --exact --nocapture`.
