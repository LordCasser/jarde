# Loop3 test-only correction v5

Status: private, uncompiled, and unexecuted. This package changes only the v4 test file. Production code is unchanged.

The wrong-boundary case still checks refusal at a boundary different from the proved loop exit. The wrong-active-target case now keeps the real outer LoopBreak route to header 11 and adds an unrelated nested target as the last frame target. It verifies refusal of that actual LoopBreak; it no longer mistakes the old valid Straight-only tail produced by an altered break destination for a negative case.

Base test SHA-256: `40c3d8fe2dc3a1c59fa22c20d2dd0b370f8821aa6a5a1f0aae5058d46217de6b`. The patch and candidate hashes are pinned in `manifest.json`.
