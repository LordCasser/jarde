from pathlib import Path
import hashlib, json, re
BASE=Path('/private/tmp')
ROOT=Path('/private/tmp/jarde-last-four-focused-v4-independent-audit-luna-v1-20261019')
SOURCES={"combined_v4":"jarde-last-four-combined-focused-root-v4-20261019","do2_public_first":"jarde-do2-first-public-root-v1-20261019","cf12_closed":"jarde-last-four-cf12-root-v1-20261019","fixture_loop3":"jarde-last-four-fixture-validation-root-v1-20261019","fixture_loop45":"jarde-loop45-fixture-validation-root-v1-20261019"}
def sha(b): return hashlib.sha256(b).hexdigest()
def audit(label, folder):
    p=BASE/folder/'execution.json'; d=json.loads(p.read_text()); raw=[]; commands=[]; before={x['path']:(x['bytes'],x['sha256']) for x in d['source_before']}; after={x['path']:(x['bytes'],x['sha256']) for x in d['source_after']}; changes=sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k))
    for c in d['commands']:
        streams={}
        for kind,pin in c.get('streams',{}).items():
            fp=Path(pin['path']); b=fp.read_bytes(); item={'command_index':c['index'],'stream':kind,'path':str(fp),'bytes':len(b),'sha256':sha(b),'pin_ok':len(b)==pin['bytes'] and sha(b)==pin['sha256']}; raw.append(item); streams[kind]=item|{'text':b.decode('utf-8','replace')}
        commands.append({'index':c['index'],'argv':c.get('argv'),'exit_code':c.get('exit_code'),'test_summaries':c.get('test_summaries'),'streams':streams})
    expected_changes=d.get('source_changes') or []
    changed_rel=[str(Path(k).relative_to('/Users/lordcasser/workspace/projects/jarde')) if k.startswith('/Users/lordcasser/workspace/projects/jarde/') else k for k in changes]
    source_ok=(not changes and d.get('source_unchanged') is True) or (changed_rel==expected_changes and d.get('source_changes_accepted') is True and sorted(expected_changes)==['tests/fixtures/corpus-fingerprint.json'])
    target_ok=d.get('target_absent') is True
    for path, val in before.items():
        if path.endswith(('/crates/jarde-java/src/region.rs','/tests/recover_do2_return_public.rs','/tests/recover_prefixed_retry_public.rs')):
            raw.append({'kind':'source_pin','path':path,'bytes':val[0],'sha256':val[1],'unchanged':after.get(path)==val})
    return {'receipt':str(p),'status':d.get('status'),'source_unchanged':d.get('source_unchanged'),'source_changes':expected_changes,'source_changes_accepted':d.get('source_changes_accepted'),'source_before_count':len(before),'source_after_count':len(after),'source_changed_paths':changed_rel,'source_closure_ok':source_ok,'target_absent':d.get('target_absent'),'cleanup_ok':target_ok,'commands':commands,'raw_pins':raw,'raw_stream_count':sum(len(c['streams']) for c in commands),'raw_streams_pinned':all(x.get('pin_ok',True) for x in raw if 'stream' in x)}
receipts={k:audit(k,v) for k,v in SOURCES.items()}
def command(label,n): return receipts[label]['commands'][n-1]
def output(label,n,stream='stdout'): return command(label,n)['streams'][stream]['text']
lib=output('combined_v4',1); cf=output('combined_v4',2); public=output('combined_v4',3); err=output('combined_v4',4,'stderr')
cf_tests=re.findall(r'^test (.*?) \.\.\. ok$',cf,re.M)
checks={
 'combined_v4_failed':receipts['combined_v4']['status']=='failed',
 'java_lib_550_pass':command('combined_v4',1)['test_summaries']==[['ok','550','0','0']],
 'cf12_9_pass':command('combined_v4',2)['test_summaries']==[['ok','9','0','0']] and len(cf_tests)==9,
 'do2_public_one_pass':command('combined_v4',3)['test_summaries']==[['ok','1','0','0']] and 'original_dowhilebreak2_debug_no_debug_class_and_full_jar_default_all_are_structured ... ok' in public,
 'loop3_public_failure_two_vec_borrows':command('combined_v4',4)['exit_code']==101 and err.count('error[E0308]: mismatched types')==2 and err.count('expected `&[u8]`, found `Vec<u8>`')==2,
 'old_char_regression_pass': 'build::tests::proved_loop_assignment_consumes_real_char_and_only_known_widenings ... ok' in lib,
 'do2_late_stop_pass':'region::do_while_break2_return_tests::do_while_break2_late_budget_stop_restores_new_return_candidate_state ... ok' in lib,
 'do2_reader_and_extra_entry_pass':all(x in lib for x in ['do_while_break2_reader_claims_the_proved_return_leaf_and_latch_once ... ok','do_while_break2_real_extra_normal_entry_refuses_terminal_return_leaf ... ok']),
 'loop5_named_scope_proof_pass':'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_named_break_body_proof_binds_one_row_and_rejects_scope_drift ... ok' in lib,
 'all_raw_streams_pinned':all(r['raw_streams_pinned'] for r in receipts.values()),
 'all_source_closures_accepted':all(r['source_closure_ok'] for r in receipts.values()),
 'all_cleanup_confirmed':all(r['cleanup_ok'] for r in receipts.values()),
 'combined_3372_snapshot_unchanged':receipts['combined_v4']['source_before_count']==3372 and receipts['combined_v4']['source_changed_paths']==[] and receipts['combined_v4']['source_unchanged'] is True,
 'independent_do2_public_pass':command('do2_public_first',1)['test_summaries']==[['ok','1','0','0']],
 'independent_cf12_pass':command('cf12_closed',1)['test_summaries']==[['ok','9','0','0']],
 'fixture_validation_expected_mutation_only':all(receipts[x]['source_changed_paths']==['tests/fixtures/corpus-fingerprint.json'] and receipts[x]['source_changes_accepted'] is True for x in ['fixture_loop3','fixture_loop45']),
}
report={'schema':'independent-focused-v4-receipt-audit-v1','interpretation':'Core gates pass: 550 Java lib tests, 9 CF12 tests, and one Do2 public test. Combined v4 is FAILED because recover_prefixed_retry_public failed to compile on two Vec<u8> borrow errors. Do not treat the aggregate as accepted. The later test-only fix and its active build were not inspected.','checks':checks,'receipts':receipts,'raw_stream_count':sum(r['raw_stream_count'] for r in receipts.values()),'raw_stream_pins':[x for r in receipts.values() for x in r['raw_pins'] if 'stream' in x],'all_checks_pass':all(checks.values())}
(ROOT/'audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print(json.dumps({'audit':str(ROOT/'audit.json'),'checks':checks,'raw_stream_count':report['raw_stream_count'],'all_checks_pass':report['all_checks_pass']},indent=2,ensure_ascii=False))
