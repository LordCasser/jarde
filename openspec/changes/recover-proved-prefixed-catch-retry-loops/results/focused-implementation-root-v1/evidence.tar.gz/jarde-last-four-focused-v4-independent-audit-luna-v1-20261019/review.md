# Independent audit of combined focused v4

I reopened only these closed receipts and their raw streams:

- `/private/tmp/jarde-last-four-combined-focused-root-v4-20261019/execution.json`
- `/private/tmp/jarde-do2-first-public-root-v1-20261019/execution.json`
- `/private/tmp/jarde-last-four-cf12-root-v1-20261019/execution.json`
- `/private/tmp/jarde-last-four-fixture-validation-root-v1-20261019/execution.json`
- `/private/tmp/jarde-loop45-fixture-validation-root-v1-20261019/execution.json`

The combined v4 receipt is **FAILED**. Its `jarde-java --lib` command passed 550 tests; the CF12 integration command passed 9; and `recover_do2_return_public` passed its one named test, `original_dowhilebreak2_debug_no_debug_class_and_full_jar_default_all_are_structured`. The 550-test output also contains passing lines for the new Do2 return-leaf late-stop rollback test, the extra-normal-entry refusal test, the Loop5 named-scope proof test, and the existing character-widening regression. The second, standalone receipts independently show the Do2 public test and all nine CF12 tests passing.

The aggregate fails at `recover_prefixed_retry_public` compile time: two E0308 errors at lines 127 and 129 pass `Vec<u8>` into `std::str::from_utf8`, which expects `&[u8]`. Therefore v4 is not an accepted combined pass. The later test-only borrow fix and its running build are outside this audit; I did not inspect that active output. Clippy and CLI gates are absent from the closed v4 command list and remain outstanding.

All 34 stdout/stderr streams across the five receipts were reopened and matched the receipts’ byte counts and SHA-256 pins. The combined receipt’s full source closure has 3,372 entries before and after, with no changes; `target_absent=true` confirms cleanup. Its `region.rs` source pin is 1,421,611 bytes, SHA-256 `9826b181dca829d9b311500114c9d0caf0e149c5661a0b01ac2cbc94709a1ab3`. The Do2 public integration source pin is `f0f086c0af0a0ac30059ab53d4c0d6e802e8acdd93754d4ed6515568e5f601dd`; the Loop4/5 public integration source pin is `4e21a1a640981fe0bd7e4ec2cb31291faca82df7cf0eabc0370f1cb16bfceff4`. Because the entire combined source snapshot is unchanged, the older char/365@29/130@1 implementation and tests were not changed in this receipt.

The two fixture-validation receipts each record exactly the accepted `tests/fixtures/corpus-fingerprint.json` update and then clean `target`; they are not source-unchanged receipts. `audit.json` stores the five receipt states, per-command argv and summaries, all raw pins, source-closure checks, and semantic gate results. `audit_receipts.py` can recreate it using Python only and reads no workspace source. All audit checks pass, while preserving the combined receipt’s failed status.
