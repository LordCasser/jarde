//! Reader-backed ownership checks for the narrowly proved prefixed named-catch retry shape.
use super::*;
use jarde_jvm::engine::analyze_method_ir;
use jarde_jvm::environment::ResolutionEnvironment;
use jarde_jvm::ir::{AnalysisStage, MethodAnalysisRequest};
use jarde_reader::artifact::{ArtifactInput, ArtifactSnapshot};
use jarde_reader::model::{
    ClassBytesId, Digest, JvmBytes, PhysicalClassLocation, PhysicalDefinitionId, PhysicalMethodId,
    PhysicalVariant,
};
use jarde_reader::view::{
    DelegationPolicy, LayoutMode, LoadDomain, LoadRoot, LoaderId, ModuleMode, MultiReleasePolicy,
    PhysicalScope, PhysicalView, RuntimeProfile, RuntimeUncertainty, RuntimeView,
};

const DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-proved-prefixed-catch-retry-loops/original/debug/classes/jadx/tests/integration/loops/TestBreakInLoop3$TestCls.class"
);
const NO_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-proved-prefixed-catch-retry-loops/original/no-debug/classes/jadx/tests/integration/loops/TestBreakInLoop3$TestCls.class"
);

fn limits() -> Budget {
    Budget::new(jarde_reader::budget::Limits {
        input_bytes: 1 << 20,
        archive_entries: 100,
        entry_bytes: 1 << 20,
        read_bytes: 1 << 20,
        class_bytes: 1 << 20,
        attribute_bytes: 1 << 20,
        code_bytes: 1 << 20,
        result_items: 1 << 20,
        output_bytes: 1 << 20,
        class_headers: 100,
        method_bodies: 100,
        ir_items: 1 << 20,
        ir_edges: 1 << 20,
        analysis_steps: 1 << 20,
        normalization_clones: 1 << 20,
        nested_depth: 32,
        dependency_depth: 32,
        elapsed_millis: u64::MAX,
    })
}

fn with_recovered(
    class_bytes: &[u8],
    method: &[u8],
    descriptor: &[u8],
    java_release: u16,
    check: impl FnOnce(&CanonicalCfg, &Recovered),
) {
    let mut reader_budget = limits();
    let snapshot = ArtifactSnapshot::open(ArtifactInput::bytes(class_bytes.to_vec()), &mut reader_budget)
        .expect("frozen original class opens");
    let definition = PhysicalDefinitionId {
        location: PhysicalClassLocation::StandaloneRoot { snapshot: snapshot.id().clone() },
        class_bytes: ClassBytesId {
            digest: Digest(blake3::hash(class_bytes).to_hex().to_string()),
            length: class_bytes.len() as u64,
        },
        variant: PhysicalVariant::Base,
    };
    let domain = LoadDomain {
        loader: LoaderId("app".to_owned()),
        parent_loader: None,
        delegation: DelegationPolicy::ParentFirst,
        roots: vec![LoadRoot::StandaloneClass { snapshot: snapshot.id().clone() }],
        module_mode: ModuleMode::ClassPath,
        external_override: RuntimeUncertainty::None,
        runtime_transformation: RuntimeUncertainty::None,
    };
    let recovery_profile = RuntimeProfile {
        java_release,
        multi_release: MultiReleasePolicy::Disabled,
        layout: LayoutMode::Generic,
    };
    let analysis = analyze_method_ir(
        &[snapshot.clone()],
        &MethodAnalysisRequest {
            environment: ResolutionEnvironment {
                runtime: RuntimeView {
                    physical: PhysicalView {
                        snapshot: snapshot.id().clone(),
                        scope: PhysicalScope::SnapshotAll,
                    },
                    profile: recovery_profile.clone(),
                    load_domain: domain.clone(),
                },
                domains: vec![domain],
                providers: Vec::new(),
            },
            method: PhysicalMethodId {
                owner: definition,
                name: JvmBytes(method.to_vec()),
                descriptor: JvmBytes(descriptor.to_vec()),
            },
            stages: AnalysisStage::ALL.to_vec(),
        },
        &mut reader_budget,
    )
    .expect("reader analyzes frozen method");
    let ir = analysis.ir();
    let canonical = ir.canonical().expect("canonical CFG exists");
    let ssa = ir.ssa().expect("SSA exists");
    let code = ir.code().expect("decoded method facts exist");
    let operations = Operations::of(code, ir.constant_pool());
    let chains = crate::concat::plan_four_conditional_strings(
        ssa,
        canonical,
        &operations,
        &crate::build::FieldCopies::default(),
        &mut reader_budget,
    )
    .expect("existing concat planning completes");
    let view = NormalFlowView::build(canonical, &mut reader_budget)
        .expect("normal-flow projection exists");
    let mut recovery_budget = limits();
    let recovered = recover(
        canonical,
        &view,
        ssa,
        &operations,
        ir.constant_pool(),
        &chains,
        &crate::init::Sites::empty(),
        code,
        Some(false),
        false,
        &recovery_profile,
        &mut recovery_budget,
    )
    .expect("recovery completes");
    check(canonical, &recovered);
}

fn find_retry_loop<'a>(region: &'a Region, found: &mut Vec<&'a Region>) {
    match region {
        Region::Loop { header, body, .. } => {
            if header.bci() == 11 {
                found.push(region);
            }
            for child in body {
                find_retry_loop(child, found);
            }
        }
        Region::Sequence { regions } => regions.iter().for_each(|child| find_retry_loop(child, found)),
        Region::If { then_arm, else_arm, .. } | Region::CompoundIf { then_arm, else_arm, .. } => {
            find_retry_loop(then_arm, found);
            find_retry_loop(else_arm, found);
        }
        Region::Try { body, catches, .. } => {
            find_retry_loop(body, found);
            for clause in catches {
                find_retry_loop(clause.body(), found);
            }
        }
        _ => {}
    }
}

fn assert_prefixed_retry(canonical: &CanonicalCfg, recovered: &Recovered) {
    assert!(recovered.is_structured(), "{:#?}", recovered.regions);
    assert!(recovered.fallbacks().is_empty(), "{:#?}", recovered.regions);
    assert_eq!(recovered.claimed.len(), canonical.blocks().len());

    let mut loops = Vec::new();
    for region in &recovered.regions {
        find_retry_loop(region, &mut loops);
    }
    let [Region::Loop { exit, body, .. }] = loops.as_slice() else {
        panic!("expected one proved retry loop: {:#?}", recovered.regions);
    };
    assert_eq!(exit.as_ref().map(CanonicalBlockId::bci), Some(82));
    assert_eq!(body.len(), 1);
    let Region::Try { prefix, lead, body: protected, catches, .. } = &body[0] else {
        panic!("retry loop body must retain the named Try: {:#?}", body);
    };
    assert!(prefix.is_empty(), "initial file setup must stay outside the retry loop");
    assert_eq!(*lead, (11, 17));
    assert_eq!(catches.len(), 1);
    assert!(protected.is_structured());

    let all: Vec<_> = recovered.regions.iter().flat_map(Region::blocks).collect();
    for bci in [0, 82] {
        assert_eq!(all.iter().filter(|block| block.bci() == bci).count(), 1, "owner BCI {bci}");
    }
    let loop_blocks: Vec<_> = loops[0].blocks();
    assert!(!loop_blocks.iter().any(|block| matches!(block.bci(), 0 | 82)));
}

#[test]
fn debug_and_no_debug_retry_ownership_is_stable_for_java8_and_23_profiles() {
    for bytes in [DEBUG, NO_DEBUG] {
        for release in [8, 23] {
            with_recovered(bytes, b"writeMore", b"(Ljava/lang/String;)V", release, |canonical, recovered| {
                assert_prefixed_retry(canonical, recovered);
            });
        }
    }
}

#[test]
fn other_original_methods_remain_structured_in_both_metadata_variants() {
    for bytes in [DEBUG, NO_DEBUG] {
        for (method, descriptor) in [
            (b"<init>".as_slice(), b"()V".as_slice()),
            (b"prt".as_slice(), b"(Ljava/lang/String;)V".as_slice()),
            (b"check".as_slice(), b"()V".as_slice()),
        ] {
            with_recovered(bytes, method, descriptor, 8, |canonical, recovered| {
                assert!(recovered.is_structured(), "{method:?}: {:#?}", recovered.regions);
                assert!(recovered.fallbacks().is_empty(), "{method:?}: {:#?}", recovered.regions);
                assert_eq!(recovered.claimed.len(), canonical.blocks().len());
            });
        }
    }
}
