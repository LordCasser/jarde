# Loop3 prefixed named-catch retry candidate

Status: prepared for root review; not compiled or executed. This package contains only private candidate files. Shared source and the OpenSpec task checklist are unchanged.

## Architecture

The source has no ordinary natural loop. The candidate extends the existing named retry certificate with one separately proved branch shape: the handler either transfers to the exact retry header or completes through a closed, acyclic normal DAG to the Try join. The existing `RetryLoopFacts` and `Frame` continue/break machinery present that proof; the new `RetryOrNormal` variant records the additional normal arm and its exact owners. The existing throw-or-retry branch remains intact for Loop2.

The prefix is a distinct statement scope. Its already-walked entry blocks are emitted as a `Straight` region before the synthetic retry loop, while the per-attempt lead remains on the `Try` inside the loop. The exact Try join is also the synthetic loop exit; it is parsed after the loop, so the canonical owner at BCI 82 (which physically contains BCIs 82 and 91) is emitted once. No canonical block 91 is invented. The handler's normal arm must match the exact branch join and normal-owner set; its only loop transfer is a `LoopBreak` to this proved loop's exit. The retry arm's own-header `LoopContinue` is enabled only by the exact exception-row/handler/source proof carried in the frame. Existing final all-owner checking and failure rollback remain in place.

The proof requires one physical named row, one canonical protected owner, matching exception type and handler identity, exact throw-site range, a nonempty linear prefix into the header, a decoded retry transfer back to the header, and a closed normal-completion DAG with one exact join. It rejects foreign entries/exits, duplicate owners, cycles, and exception/call/return edges in the completion DAG. No natural-loop proof is fabricated for the input.

## Files

- `region.patch`: patch against the frozen `region.rs` source.
- `tests.patch`: new internal Reader-backed ownership and adversarial proof tests; it uses the exact frozen debug and no-debug class files, each under the Java 8 and Java 23 reader profiles. Both original class files are major version 52, as the pinned source files state; the two runtime profiles do not imply extra compilation variants.
- `public-test.patch`: new public class-source tests covering the original debug/no-debug class and full-JAR inputs, default/all evidence, exact four-method/one-field inventory, structured quality, map-to-physical-BCI validity, and pre-cancellation. The class inputs are the actual frozen `original/{debug,no-debug}/classes/.../TestBreakInLoop3$TestCls.class` artifacts pinned in `manifest.json`; the JAR tests use the corresponding frozen `TestBreakInLoop3-full-classes.jar` files.
- `candidate-region.rs`, `prefixed_catch_retry_tests.rs`, `recover_prefixed_retry_public.rs`: direct review copies.
- `manifest.json`: byte-length and SHA-256 pins.

## Validation boundary

No Rust formatter, Cargo, JDK, Jarde CLI, Git, or network operation was run. The candidate has not been tested. The new tests are intended for root integration and actual execution. Full runtime behavior, including first-failure retry and repeated-failure completion, remains for the separate finite-control acceptance task.

Suggested root checks after integration:

```text
cargo test -p jarde-java prefixed_catch_retry -- --nocapture
cargo test -p jarde --test recover_prefixed_retry_public -- --nocapture
cargo fmt --check
cargo clippy -p jarde-java --tests -- -D warnings
```

The candidate derives from `/private/tmp/jarde-last-four-ir-probe-prepare-root-v1-20261019/original-region.rs`, SHA-256 `86a20041442a196dfaa83da539d3f301b9b4974907620b3b50da1eb46f037be5`. Its source fixture is the staged frozen `TestBreakInLoop3.java` and original debug/no-debug artifacts listed in `manifest.json`.
