# Loop3 constructor-backed local store proof

Private candidate only; no shared files were changed and no Rust tools were run.

Base is the restored `build.rs` snapshot from the guarded construction experiment, SHA-256 `81c2a0b7b0c24f6ca0f1b6803f0abb421c07d5f06284abd1eb43b9be592cc331`. The production change removes only the constructor arm's `in_protected_arm` condition. It keeps the exact verified `Sites` lookup, same-block constructor expression equality, immediate store interval, and single-use proof. The static-call arm keeps its protected-arm restriction. Downstream `all_reads_reach_presented_writes` and SSA checks are unchanged.

A private unit module uses the actual frozen Loop3 debug class. It proves the pre-retry `File(String)` site can feed its exact store, refuses missing Sites and an enlarged constructor/store interval, and checks budget and pre-cancellation propagation. Root's separate guarded public experiment already showed the exact constructor-only guard removal passes the Loop3 class/JAR default/all cells with the full downstream proof. These files are prepared, not independently compiled or run.
