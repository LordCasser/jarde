from pathlib import Path
import subprocess,hashlib,json,sys
p=Path(__file__).resolve().parent;root=Path('/Users/lordcasser/workspace/projects/jarde');region=root/'crates/jarde-java/src/build.rs'
def pin(x):
 b=x.read_bytes();return {'path':str(x),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
argv=[sys.executable,'-B',str(root/'openspec/changes/recover-branch-throw-return-finally/tools/run_validation.py'),str(p/'run'),str(p/'commands.json')]
try:
 with (p/'stdout.raw').open('xb') as a,(p/'stderr.raw').open('xb') as b:r=subprocess.run(argv,cwd=root,stdout=a,stderr=b)
finally:
 region.write_bytes((p/'original-build.rs').read_bytes())
record={'status':'closed','argv':argv,'exit_code':r.returncode,'source_restored':region.read_bytes()==(p/'original-build.rs').read_bytes(),'target_absent':not(root/'target').exists(),'streams':{ch:pin(p/(ch+'.raw')) for ch in ['stdout','stderr']},'restored_source':pin(region)}
(p/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));raise SystemExit(r.returncode)
