# Loop3 prefixed named-catch retry candidate (v2)

Status: prepared for root review; not compiled or executed. This private package contains the candidate source, tests, and patches only. Shared source and OpenSpec tasks are unchanged.

## Architecture

The original has no normal-flow natural loop. The candidate extends the existing named retry certificate with one separately proved handler shape: an exact transfer back to the retry header or a finite, closed normal DAG to the Try join. `RetryLoopFacts` retains the existing loop machinery, while `RetryHandlerBranchFacts::RetryOrNormal` records the additional normal-completion owners. The existing Loop2 throw-or-retry branch keeps its prior ownership contract and rollback path.

The initial entry prefix is already claimed by the outer walk, so the proof requires those exact prefix owners to be visited and disjoint from all newly proved loop/handler owners. It emits the prefix once before the synthetic retry loop; the per-attempt Try lead remains inside the loop. The exact Try join is the synthetic loop exit and is parsed afterward; canonical BCI 82 physically includes BCI 91, so no separate block 91 is invented. The handler's normal arm must match its exact branch entry and join, with all direct join predecessors derived from normal-flow edges. `try_level` accepts a continuation at that join only for `RetryOrNormal`; the legacy throw-or-retry proof still requires no handler continuation. The branch-region checker then confirms the exact If join and normal-owner set. Own-header `LoopContinue` is enabled only by the exact row/handler/terminal-source proof.

A prefixed attempt now snapshots and restores the full existing `LoopBodyTrialState` on stop or incomplete ownership after child claims. The legacy retry branch retains its existing narrower checkpoint and costs. Final all-owner checking remains authoritative. The proof rejects foreign owners/edges, cycles, duplicate owners, and exception/call/return crossings in the completion DAG.

## v2 corrections

The frozen v1 was not modified. This v2 fixes its invalid dereference of the proved join node, derives only actual direct normal predecessors of the join, requires the previsited prefix while keeping proved owners unvisited, removes an unused local, and restores full walker state for speculative prefixed branches. It also exercises late-stop rollback through `try_region`, not only proof scanning. These are static candidate corrections; they have not been compiled or tested.

## Files

- `region.patch`: patch against the pinned frozen `region.rs`.
- `tests.patch`: Reader-backed tests with adversarial row, owner, entry, exit, cycle, non-normal-edge, budget, cancellation, and late-stop rollback checks. It uses the actual original debug/no-debug class bytes with Java 8 and Java 23 reader profiles; these are two byte variants under two runtime profiles, not four compiler outputs.
- `public-test.patch`: public class/JAR integration tests for debug/no-debug fixtures, default/all output, structured methods, exact inventory, identity, physical BCI/UTF-8 maps, and precancellation.
- `candidate-region.rs`, `prefixed_catch_retry_tests.rs`, `recover_prefixed_retry_public.rs`: direct review copies.
- `manifest.json`: byte-length and SHA-256 pins for base, candidate files, and exact staged source/class/JAR fixtures.

## Validation boundary

No Rust formatter, Cargo, JDK, Jarde CLI, Git, or network operation was run. The candidate has not been tested. Runtime acceptance, including first-failure retry and repeated-failure normal completion, remains for root's separate finite-control checks.

The source fixture is `tests/fixtures/recover-proved-prefixed-catch-retry-loops/source/TestBreakInLoop3.java`; the public test reads the pinned original class/JAR artifacts. The frozen base is `/private/tmp/jarde-last-four-ir-probe-prepare-root-v1-20261019/original-region.rs`.
