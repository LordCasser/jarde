# DoWhileBreak2 proved return-leaf implementation candidate

This private package contains the requested task 2.1/2.2 candidate against the frozen shared base. No Rust, Java, Jarde, JADX, or OpenSpec CLI was run here; preparation used file reads and Python `-B` only.

## Scope

The candidate lazily reuses `loop_terminal_returns` for a narrowly prefiltered terminal-return leaf. The same set is passed from `loop_region` through `latch_tested_loop` into the existing `Frame::loop_body` scope. `post_test_break_prefix_proved` itself is unchanged and continues to certify goto-only bridges.

Before an early certificate scan, the gate rejects the loop's normal exit, in-loop/visited nodes, parent-frame boundaries, non-leaves, non-return terminals, and sources outside the existing comparison/switch branch shape. Exact canonical entry and decoded-target checks remain in `loop_terminal_returns`. If no early return candidate needs the proof, the existing latch path still performs its one original scan at the original point; if the early gate already computed a proof, that result is reused and not charged again.

Only a nonempty terminal-return candidate takes the existing `loop_body_trial_state` checkpoint before body walking. A later Stop or incomplete ownership restores visited, catch joins/owners, fragmented state, excluded edge nodes, monitor state and depth; budget usage remains charged. Ordinary loops retain existing checkpoint and budget costs.

The new Reader submodule checks both frozen class profiles, the actual natural loop `(0, 19)`, latch `19`, exclusive return leaf `17`, normal exit `31`, bytecode evaluation order, complete fallback-free recovery and unique physical ownership. Negative gates check wrong-exit and parent-scope rejection, exact normal-predecessor filtering for foreign/non-normal entries, and continued refusal by the unchanged goto-only proof. A same-input late-budget test derives its limit from the successful direct candidate and checks checkpoint restoration; a pre-cancel test checks no ownership publication.

## Changed files

- `crates/jarde-java/src/region.rs`
- `crates/jarde-java/src/region/finite_loop_catch_tests.rs` (makes the existing frozen Reader helper visible to its sibling test module)
- `crates/jarde-java/src/region/do_while_break2_return_tests.rs`

The exact patch is `candidate.patch`. Pinned copies of the already-installed original class/JAR fixtures are included for review and match shared fixture bytes exactly; they are not patch changes.

## Suggested root gates

Run the three new Reader tests serially first, using the commands in `commands.json`. Then run existing goto-prefix and return-leaf regression gates, the public debug/no-debug × class/full-JAR × default/all acceptance, Do3 control, formatting/clippy, and the full sequence in OpenSpec. The public class gate should allow the known raw `Iterator` generic display diagnostic while still checking exact field/method inventory, target structure, source compilation, VM observations and maps.

No test or toolchain result is claimed here. OpenSpec tasks remain unchanged.

## Pins

`pins.json` binds the shared base, candidate source, fixture bytes and OpenSpec context. `candidate.patch` SHA-256: `3b5088c4872d9f64da32f45afa9064c4282f79ef3a26a87cc1a42684856c379b`.
