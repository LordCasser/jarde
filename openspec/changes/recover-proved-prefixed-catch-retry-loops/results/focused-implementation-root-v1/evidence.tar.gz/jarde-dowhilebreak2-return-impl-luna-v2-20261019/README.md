# DoWhileBreak2 proved return-leaf implementation candidate v2

This private package contains the requested task 2.1/2.2 candidate against the frozen shared base. No Rust, Java, Jarde, JADX, or OpenSpec CLI was run here; preparation used file reads and Python `-B` only.

## Scope

The candidate lazily reuses `loop_terminal_returns` for a narrowly prefiltered terminal-return leaf. The same set is passed from `loop_region` through `latch_tested_loop` into the existing `Frame::loop_body` scope. `post_test_break_prefix_proved` itself is unchanged and continues to certify goto-only bridges.

Before an early certificate scan, the gate rejects the loop's normal exit, in-loop/visited nodes, parent-frame boundaries, non-leaves, non-return terminals, and sources outside the existing comparison/switch branch shape. Exact canonical entry and decoded-target checks remain in `loop_terminal_returns`. If no early return candidate needs the proof, the existing latch path still performs its one original scan at the original point; if the early gate already computed a proof, that result is reused and not charged again.

Only a terminal-return certificate actually obtained by the pre-body candidate path (`terminal_returns_checked && !terminal_returns.is_empty()`) takes the existing `loop_body_trial_state` checkpoint before body walking. The legacy tail scan does not flip this gate, so ordinary legacy candidates keep their prior checkpoint and budget cost. A later Stop or incomplete ownership restores visited, catch joins/owners, fragmented state, excluded edge nodes, monitor state and depth; budget usage remains charged. Ordinary loops retain existing checkpoint and budget costs.

The new Reader submodule checks both frozen class profiles, the actual natural loop `(0, 19)`, latch `19`, exclusive return leaf `17`, normal exit `31`, bytecode evaluation order, complete fallback-free recovery and unique physical ownership. Negative gates check wrong-exit and parent-scope rejection, plus a real mutated-class proof with a second normal entry into the return leaf. Exact normal-predecessor helper checks also reject foreign/non-normal edge lists; this package does not claim a mutated canonical exception/call-edge test. The unchanged goto-only proof still refuses the return leaf. The late-budget test derives its threshold from a successful run with the same preseeded visited exit and unclosed tail, then checks the limit-minus-one Stop point and rollback; a pre-cancel test checks no ownership publication. The separate public API integration test opens the frozen class and full JAR inputs for both profiles, checks exact field/method inventories, structured method output, default/all parity, and source-map coverage. The known raw `Iterator` generic display warning is allowed.

## Changed files

- `crates/jarde-java/src/region.rs`
- `crates/jarde-java/src/region/finite_loop_catch_tests.rs` (makes the existing frozen Reader helper visible to its sibling test module)
- `crates/jarde-java/src/region/do_while_break2_return_tests.rs`

The exact patch is `candidate.patch`. Pinned copies of the already-installed original class/JAR fixtures are included for review and match shared fixture bytes exactly; they are not patch changes.

## Suggested root gates

Run the three new Reader tests serially first, using the commands in `commands.json`. Then run existing goto-prefix and return-leaf regression gates, the public debug/no-debug × class/full-JAR × default/all acceptance, Do3 control, formatting/clippy, and the full sequence in OpenSpec. The public class gate should allow the known raw `Iterator` generic display diagnostic while still checking exact field/method inventory, target structure, source compilation, VM observations and maps.

No test or toolchain result is claimed here. OpenSpec tasks remain unchanged.

## Pins

`pins.json` binds the shared base, candidate source, fixture bytes and OpenSpec context. `candidate.patch` SHA-256 is pinned in `pins.json`.
