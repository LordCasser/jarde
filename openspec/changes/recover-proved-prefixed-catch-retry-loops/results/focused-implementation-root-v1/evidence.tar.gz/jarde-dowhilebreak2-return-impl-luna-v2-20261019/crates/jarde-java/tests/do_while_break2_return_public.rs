//! Public Reader/Recovery API acceptance for the frozen DoWhileBreak2 target.
use jarde_java::{DeclaringClass, MethodFacts, RecoveryEvidenceRequest, RecoveryFacts, RecoveryRequest, pass::JAVA_8, recover};
use jarde_jvm::engine::analyze_method_ir;
use jarde_jvm::environment::ResolutionEnvironment;
use jarde_jvm::ir::{AnalysisStage, MethodAnalysisRequest, Quality};
use jarde_reader::artifact::{ArtifactInput, ArtifactSnapshot};
use jarde_reader::budget::{Budget, Limits};
use jarde_reader::model::{ClassBytesId, Digest, JvmBytes, PhysicalClassLocation, PhysicalDefinitionId, PhysicalMethodId, PhysicalVariant};
use jarde_reader::view::{DelegationPolicy, LayoutMode, LoadDomain, LoadRoot, LoaderId, ModuleMode, MultiReleasePolicy, PhysicalScope, PhysicalView, RuntimeProfile, RuntimeUncertainty, RuntimeView};

const DEBUG_CLASS: &[u8] = include_bytes!("../../../tests/fixtures/recover-proved-post-test-loop-return-leaves/original/debug/classes/jadx/tests/integration/loops/TestDoWhileBreak2$TestCls.class");
const NO_DEBUG_CLASS: &[u8] = include_bytes!("../../../tests/fixtures/recover-proved-post-test-loop-return-leaves/original/no-debug/classes/jadx/tests/integration/loops/TestDoWhileBreak2$TestCls.class");
const DEBUG_JAR: &[u8] = include_bytes!("../../../tests/fixtures/recover-proved-post-test-loop-return-leaves/original/debug/TestDoWhileBreak2-full-classes.jar");
const NO_DEBUG_JAR: &[u8] = include_bytes!("../../../tests/fixtures/recover-proved-post-test-loop-return-leaves/original/no-debug/TestDoWhileBreak2-full-classes.jar");
const OWNER: &str = "jadx/tests/integration/loops/TestDoWhileBreak2$TestCls";
const METHOD: &str = "test";
const DESCRIPTOR: &str = "()Ljava/lang/Object;";
const METHODS: &[(&str, &str)] = &[("<init>", "()V"), ("test", "()Ljava/lang/Object;"), ("check", "()V")];
const FIELDS: &[(&str, &str, u16)] = &[("it", "Ljava/util/Iterator;", 0)];

fn limits() -> Limits {
    Limits { input_bytes: 1<<20, archive_entries: 100, entry_bytes: 1<<20, read_bytes: 1<<20, class_bytes: 1<<20, attribute_bytes: 1<<20, code_bytes: 1<<20, result_items: 1<<20, output_bytes: 1<<20, class_headers: 100, method_bodies: 100, ir_items: 1<<20, ir_edges: 1<<20, analysis_steps: 1<<20, normalization_clones: 1<<20, nested_depth: 32, dependency_depth: 8, elapsed_millis: u64::MAX }
}

fn selected_class(input: &[u8], archive: bool) -> (ArtifactSnapshot, Vec<u8>, PhysicalClassLocation) {
    let mut budget = Budget::new(limits());
    let snapshot = ArtifactSnapshot::open(ArtifactInput::bytes(input.to_vec()), &mut budget).expect("fixture opens");
    if !archive {
        assert_eq!(snapshot.kind(), jarde_reader::artifact::ArtifactKind::StandaloneClass);
        return (snapshot.clone(), input.to_vec(), PhysicalClassLocation::StandaloneRoot { snapshot: snapshot.id().clone() });
    }
    let listing = snapshot.enumerate(&mut budget).expect("full fixture JAR enumerates");
    let entry = listing.entries.iter().find(|entry| entry.id.raw_name.0 == b"jadx/tests/integration/loops/TestDoWhileBreak2$TestCls.class").expect("target entry exists");
    let class = snapshot.read_entry_for_analysis(entry, &mut budget).expect("target class reads from JAR");
    (snapshot, class.bytes, PhysicalClassLocation::ArchiveEntry { entry: entry.id.clone() })
}

fn recover_target(input: &[u8], archive: bool, all: bool) -> (jarde_java::RecoveryReport, Vec<(String,String,u16)>, Vec<(String,String)>) {
    let (snapshot, class_bytes, location) = selected_class(input, archive);
    let mut budget = Budget::new(limits());
    let owner = PhysicalDefinitionId {
        location: location.clone(),
        class_bytes: ClassBytesId { digest: Digest(blake3::hash(&class_bytes).to_hex().to_string()), length: class_bytes.len() as u64 },
        variant: PhysicalVariant::Base,
    };
    let root = match location {
        PhysicalClassLocation::StandaloneRoot { snapshot } => LoadRoot::StandaloneClass { snapshot },
        PhysicalClassLocation::ArchiveEntry { ref entry } => LoadRoot::Container { origin: entry.origin.clone(), prefix: jarde_reader::model::ArchiveNameBytes(Vec::new()) },
    };
    let domain = LoadDomain { loader: LoaderId("app".into()), parent_loader: None, delegation: DelegationPolicy::ParentFirst, roots: vec![root], module_mode: ModuleMode::ClassPath, external_override: RuntimeUncertainty::None, runtime_transformation: RuntimeUncertainty::None };
    let method = PhysicalMethodId { owner, name: JvmBytes(METHOD.as_bytes().to_vec()), descriptor: JvmBytes(DESCRIPTOR.as_bytes().to_vec()) };
    let analysis = analyze_method_ir(&[snapshot.clone()], &MethodAnalysisRequest {
        environment: ResolutionEnvironment {
            runtime: RuntimeView { physical: PhysicalView { snapshot: snapshot.id().clone(), scope: PhysicalScope::SnapshotAll }, profile: RuntimeProfile { java_release: 8, multi_release: MultiReleasePolicy::Disabled, layout: LayoutMode::Generic }, load_domain: domain.clone() },
            domains: vec![domain], providers: Vec::new(),
        }, method, stages: AnalysisStage::ALL.to_vec(),
    }, &mut budget).expect("target method analysis completes");
    let ir = analysis.ir();
    let declaration = ir.declaration().expect("target declaration");
    assert_eq!(String::from_utf8_lossy(&declaration.class_name().0), OWNER);
    assert_eq!(declaration.name().0, METHOD.as_bytes());
    assert_eq!(declaration.descriptor().0, DESCRIPTOR.as_bytes());
    let fields = ir.class_fields().expect("complete class field inventory").iter().map(|h| (String::from_utf8_lossy(&h.name().0).into_owned(), String::from_utf8_lossy(&h.descriptor().0).into_owned(), h.access_flags())).collect::<Vec<_>>();
    let methods = ir.class_methods().expect("complete class method inventory").iter().map(|h| (String::from_utf8_lossy(&h.name().0).into_owned(), String::from_utf8_lossy(&h.descriptor().0).into_owned())).collect::<Vec<_>>();
    let facts = RecoveryFacts::new(MethodFacts::new(METHOD, DESCRIPTOR, declaration.parameter_slots()).with_access_flags(declaration.access_flags()).with_declaring_class(DeclaringClass::new(OWNER, declaration.class_access_flags())));
    let request = if all { RecoveryRequest::new(ir, &facts, JAVA_8).with_evidence(RecoveryEvidenceRequest::all()) } else { RecoveryRequest::new(ir, &facts, JAVA_8) };
    let report = recover(&request, &mut budget);
    (report, fields, methods)
}

#[test]
fn frozen_dowhilebreak2_public_api_class_and_jar_default_all_matrix() {
    for (profile, class, jar) in [("debug", DEBUG_CLASS, DEBUG_JAR), ("no-debug", NO_DEBUG_CLASS, NO_DEBUG_JAR)] {
        for (container, input, archive) in [("class", class, false), ("jar", jar, true)] {
            let (default, fields, methods) = recover_target(input, archive, false);
            let (all, all_fields, all_methods) = recover_target(input, archive, true);
            assert_eq!(fields, FIELDS, "{profile}/{container} field inventory");
            assert_eq!(all_fields, FIELDS, "{profile}/{container} all field inventory");
            assert_eq!(methods, METHODS, "{profile}/{container} method inventory");
            assert_eq!(all_methods, METHODS, "{profile}/{container} all method inventory");
            assert_eq!(default.outcome, all.outcome, "{profile}/{container}");
            assert!(default.outcome.produced(), "{profile}/{container}: {:?}", default.outcome);
            assert_eq!(default.quality, Quality::Structured, "{profile}/{container}: {}", default.text);
            assert_eq!(default.text, all.text, "{profile}/{container}");
            assert_eq!(default.source_map, all.source_map, "{profile}/{container}");
            assert!(!all.source_map.is_empty(), "{profile}/{container} source map");
            for bci in [0, 17, 19] { assert!(!all.source_map.of_bci(bci).is_empty(), "{profile}/{container} BCI {bci}: {}", all.text); }
            assert_eq!(all.text.matches("return local").count(), 2, "normal and early return remain distinct: {profile}/{container}: {}", all.text);
            assert!(!all.text.contains("@bytecode"), "{profile}/{container}: {}", all.text);
            // The known raw Iterator generic-display diagnostic is an independent presentation limitation.
        }
    }
}
