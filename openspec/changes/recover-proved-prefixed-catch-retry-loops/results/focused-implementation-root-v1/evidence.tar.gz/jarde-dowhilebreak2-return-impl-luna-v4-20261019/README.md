# DoWhileBreak2 v4 minimal follow-up

This private candidate is based on the root-integrated, rustfmt-formatted Do2 v2 product pinned in `pins.json`. It changes only the loop recognition source and its focused Reader tests.

The new early terminal-return admission requires the source to be the loop header, its exact two successors to be the candidate return prefix and natural latch, and the prefix to end in a decoded return. It is admitted only when the existing header expression fails `test_is_pure(..., true)` (`StatementFree`). A pure header therefore stays on the established header-tested path, preserving the assignment-condition regression. The older goto-prefix proof is unchanged.

The test corrections reflect actual ownership and alternate return behavior: latch BCI 19 belongs to `Loop.tests`; using BCI 17 as the queried normal exit still permits the alternate terminal return BCI 31; and successful preseeded recovery claims all canonical owners. The limit-minus-one attempt keeps that same preseed and verifies state restoration after Stop.

Only static source inspection and Python pin/diff checks were performed. No Rust/Cargo/toolchain tests ran. Use the serial root commands in `commands.json`, then run the complete `jarde-java` library suite.
