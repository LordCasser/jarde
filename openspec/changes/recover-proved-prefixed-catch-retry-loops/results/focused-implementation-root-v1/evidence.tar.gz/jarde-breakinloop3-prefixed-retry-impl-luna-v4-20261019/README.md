# Loop3 inner-join transfer-tail candidate (v4)

Status: private and uncompiled. This package is based on the restored shared snapshot, with a one-method production patch and Reader-backed tests. It does not modify shared files.

## Narrow behavior change

`continue_inner_join_arm` keeps accepting the existing straight tail unchanged. It additionally accepts exactly `[Straight(blocks), LoopBreak]` when the tail ends the walk, the transfer source is the last straight block's terminal BCI, the transfer names the active loop header, and the active target's `break_target` equals the frame boundary. The existing validation then proves each straight owner has the expected incoming sources, one physical normal successor to the unchanged frame boundary, remains in scope, and is claimed exactly once before the tail is appended. No new proof field or carrier is added; the active `LoopTarget` and already-classified `LoopBreak` provide the authority.

The branch-convergence gate is unchanged. The completion boundary remains `frame.boundary`; it is not replaced with a target-supplied break destination. This case does not permit arbitrary extra regions, a wrong header, wrong source, exception edges, or another exit. The old straight-only path follows the same checks and adds no work.

## Regression tests

`candidate-prefixed_catch_retry_tests.rs` includes the test-only v3 fixes separately and a new actual-Loop3 Reader-backed continuation test. It derives the proof from frozen `writeMore` IR, constructs the same loop target from that proof, then checks the real inner join at BCI 76 and the physical `LoopBreak` from BCI 79 to the target with header 11. It asserts the tail preserves precisely the proof's normal owners, and rejects mismatched active break destination and frame boundary cases. These fixture BCIs are test evidence only; production behavior is shape- and edge-based.

`v3-tests.patch` contains only the test-walker/late-stop fixes. `tail-test.patch` contains only the additional continuation test. `all-tests.patch` combines both. `region.patch` is the single production helper change.

## Validation boundary

No formatter, Cargo, JDK, Jarde CLI, Git, or network command was run. This candidate is not compiled or tested. `manifest.json` records the frozen base source/test bytes and generated patches.
