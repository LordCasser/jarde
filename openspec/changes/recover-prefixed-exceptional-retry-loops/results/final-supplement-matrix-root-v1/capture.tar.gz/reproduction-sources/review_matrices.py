#!/usr/bin/env python3
"""Read-only independent audit for the final NL3 and retry-supplement rebuild receipts."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, sys
from collections import Counter, defaultdict
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
COMPARE_REL = Path('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
COMPARE_SHA = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
BASELINE_NL3 = Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018/execution.json')
BASELINE_RETRY = Path('/private/tmp/jarde-prefixed-retry-originals-root-v2-20261018/execution.json')


def need(ok, message):
    if not ok:
        raise AssertionError(message)


def pin(path: Path):
    path = Path(path).resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def load_compare(root: Path):
    path = root / COMPARE_REL
    need(hashlib.sha256(path.read_bytes()).hexdigest() == COMPARE_SHA, 'compare.py pin mismatch')
    spec = importlib.util.spec_from_file_location('nl3_final_independent_compare', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def fact_methods(facts):
    return {(m['name'], m['descriptor'], m['access']) for m in facts['methods']}


def key(row, family):
    if family == 'nl3':
        return (row.get('kind'), row.get('profile'), row.get('form'), row.get('evidence'))
    return (row.get('kind'), row.get('name'), row.get('input_compiler', row.get('compiler')), row.get('profile'), row.get('evidence'))


def compile_key(row, family):
    return key(row, family) + (row.get('compiler'),)


def runtime_key(row, family):
    return compile_key(row, family) + (row.get('runtime'),)


def class_tree(root, compare):
    root = Path(root)
    return {p.relative_to(root).as_posix(): compare.pin(p)
            for p in sorted(root.rglob('*')) if p.is_file()}


def read_artifact(compare, command, which):
    data = compare.command_artifact(command, which)
    stream = command['streams'][which]
    need(pin(Path(stream['path'])) == stream, f"command {command.get('index')} {which} stream pin mismatch")
    need(len(data) == stream['bytes'] and hashlib.sha256(data).hexdigest() == stream['sha256'],
         f"command {command.get('index')} {which} stream bytes/hash mismatch")
    return data


def validate_original_capture(baseline, family, compare):
    commands = baseline.get('commands', [])
    cby = {row['index']: row for row in commands}
    need(len(cby) == len(commands), f'{family}: original capture has duplicate command indexes')
    for row in commands:
        need(row.get('guard_stop') is None, f"{family}: original capture guard-stopped command {row['index']}")
        read_artifact(compare, row, 'stdout')
        read_artifact(compare, row, 'stderr')
    if family == 'nl3':
        need(len(commands) == 24, 'NL3 original capture does not retain the 24-command source/oracle baseline')
        oracle_pin = baseline['oracle']
        need(pin(Path(oracle_pin['path'])) == oracle_pin, 'NL3 original oracle pin changed')
        oracle = Path(oracle_pin['path']).read_bytes()
        need(len(oracle.splitlines()) == 7, 'NL3 original runtime oracle is not seven rows')
        expected_runs = 4
        wrong_message = b'target loaded from'
    else:
        expected_runs = 16
        need(set(baseline.get('oracles', {})) == {'PrefixRetryAlpha', 'RetryPrefixBeta'},
             'retry supplement original capture lacks both fixed class oracles')
        for name, oracle_pin in baseline['oracles'].items():
            need(pin(Path(oracle_pin['path'])) == oracle_pin and len(Path(oracle_pin['path']).read_bytes().splitlines()) == 10,
                 f'{name}: original oracle pin/line count changed')
        wrong_message = b'target loaded from'
    runs = baseline.get('original_runtime', [])
    need(len(runs) == expected_runs, f'{family}: original capture runtime count differs')
    for run in runs:
        command = cby.get(run.get('command'))
        need(command is not None and command.get('exit_code') == 0,
             f'{family}: original JVM run failed')
        output = read_artifact(compare, command, 'stdout')
        if family == 'nl3':
            need(output == oracle and run.get('oracle_sha256') == hashlib.sha256(oracle).hexdigest(),
                 'NL3 original JVM output differs from the fixed oracle')
        else:
            oracle = Path(baseline['oracles'][run['name']]['path']).read_bytes()
            need(output == oracle and run.get('oracle_equal') is True,
                 f"{run['name']}: original JVM output differs from its fixed oracle")
    wrong = cby.get(baseline.get('wrong_root_control_command'))
    need(wrong is not None and wrong.get('exit_code') != 0 and wrong_message in read_artifact(compare, wrong, 'stderr'),
         f'{family}: original CodeSource wrong-root control did not reject')
    need(baseline.get('target_absent') is True and baseline.get('source_unchanged') is True,
         f'{family}: original capture lacks target/source closure receipt')


def validate_sources(matrix, family, baseline, compare):
    rows = matrix.get('source_inputs')
    need(isinstance(rows, list), f'{family}: source_inputs missing')
    expected_sources = 12 if family == 'nl3' else 24
    # Each compile source appears once in the input manifest; profiles/forms/evidence expand only by compiler.
    need(len(rows) == expected_sources, f'{family}: expected {expected_sources} pinned source inputs, got {len(rows)}')
    by_key = {}
    for item in rows:
        k = key(item, family)
        need(k not in by_key, f'{family}: duplicate source input {k}')
        by_key[k] = item
        src = item.get('compile_source')
        need(isinstance(src, dict) and pin(Path(src['path'])) == src, f'{family}/{k}: copied source pin mismatch')
        raw = Path(src['path']).read_bytes()
        if family == 'nl3':
            orig = item['original_source_pin']
            need(pin(Path(orig['path'])) == orig and raw == Path(orig['path']).read_bytes(),
                 f'{family}/{k}: compile copy differs from selected original source')
            report_pin = item.get('original_report_pin')
            if item['kind'] == 'jarde':
                need(report_pin is not None and pin(Path(report_pin['path'])) == report_pin,
                     f'{family}/{k}: Jarde report pin mismatch')
                doc = json.loads(Path(report_pin['path']).read_text(encoding='utf-8'))
                need(doc.get('text', '').encode('utf-8') == raw, f'{family}/{k}: compile text differs from report text')
            else:
                need(report_pin is None, f'{family}/{k}: unexpected JADX report')
        else:
            orig = item.get('source_pin')
            need(isinstance(orig, dict) and pin(Path(orig['path'])) == orig and raw == Path(orig['path']).read_bytes(),
                 f'{family}/{k}: compile copy differs from immutable API/JADX source')
            if item['kind'] == 'jarde':
                report_pin = item.get('report')
                need(report_pin is not None and pin(Path(report_pin['path'])) == report_pin,
                     f'{family}/{k}: Jarde report pin mismatch')
                doc = json.loads(Path(report_pin['path']).read_text(encoding='utf-8'))
                need(doc.get('text', '').encode('utf-8') == raw, f'{family}/{k}: compile text differs from report text')
    need(sum(1 for x in rows if x['kind'] == 'jarde') == (8 if family == 'nl3' else 16),
         f'{family}: wrong Jarde source input count')
    need(sum(1 for x in rows if x['kind'] == 'jadx') == (4 if family == 'nl3' else 8),
         f'{family}: wrong JADX source input count')
    if family == 'nl3':
        expected_artifacts = []
        for item in rows:
            for role, source_pin in (('original_source', item['original_source_pin']),
                                     ('original_report', item.get('original_report_pin')),
                                     ('compile_source_copy', item['compile_source'])):
                if source_pin is not None:
                    expected_artifacts.append({'kind': item['kind'], 'profile': item['profile'],
                                               'form': item['form'], 'evidence': item['evidence'],
                                               'role': role, 'pin': pin(Path(source_pin['path']))})
        before, after = matrix.get('source_artifacts_before'), matrix.get('source_artifacts_after')
        need(before == expected_artifacts and after == expected_artifacts,
             f'{family}: original source/report/compile-copy closure differs from actual pins')
    else:
        expected_copies = [{'original': pin(Path(item['source_pin']['path'])),
                            'copy': pin(Path(item['compile_source']['path']))} for item in rows]
        before, after = matrix.get('source_input_pins_before'), matrix.get('source_input_pins_after')
        need(before == expected_copies and after == expected_copies,
             f'{family}: original source/compile-copy closure differs from actual pins')
    return by_key


def validate_api_binding(matrix, family, compare):
    api_pin = matrix.get('api_capture')
    if not api_pin:
        # A matrix can omit replay when the API report was embedded directly in the source receipt.
        return None
    need(pin(Path(api_pin['path'])) == api_pin, f'{family}: API capture pin changed')
    api = json.loads(Path(api_pin['path']).read_text(encoding='utf-8'))
    need(api.get('family') == ('original' if family == 'nl3' else 'supplement'),
         f'{family}: matrix refers to the wrong API replay family')
    need(api.get('status') in ('captured_pending_independent_api_acceptance',
                               'captured_with_incomplete_api_response'), f'{family}: bad API capture status')
    acceptance_pin = matrix.get('api_acceptance')
    if acceptance_pin is None:
        derived = Path(api_pin['path']).parent.parent / 'acceptance-review.json'
        need(derived.is_file(), f'{family}: API acceptance review is missing beside replay root')
        acceptance_pin = pin(derived)
    need(pin(Path(acceptance_pin['path'])) == acceptance_pin, f'{family}: API acceptance pin changed')
    acceptance = json.loads(Path(acceptance_pin['path']).read_text(encoding='utf-8'))
    need(acceptance.get('status') == 'independent_read_only_api_review_passed', f'{family}: API acceptance not passed')
    accepted = acceptance.get('families', {}).get(api['family'], {})
    need(accepted.get('receipt') == api_pin, f'{family}: acceptance does not bind this API receipt')
    expected_input = pin(BASELINE_NL3 if family == 'nl3' else BASELINE_RETRY)
    need(api.get('input_capture') == expected_input, f'{family}: API replay is not bound to its exact original capture')
    need(len(api.get('jarde_cells', [])) == (8 if family == 'nl3' else 16), f'{family}: API replay cell count changed')
    return api


def validate_family(receipt: Path, family: str, baseline_path: Path, compare, root: Path):
    receipt = receipt.resolve(strict=True)
    matrix = json.loads(receipt.read_text(encoding='utf-8'))
    baseline_path = baseline_path.resolve(strict=True)
    baseline = json.loads(baseline_path.read_text(encoding='utf-8'))
    validate_original_capture(baseline, family, compare)
    need(pin(baseline_path) == (matrix.get('baseline_receipt') if family == 'nl3' else matrix.get('original_capture')),
         f'{family}: wrong full original baseline receipt pin')
    need(matrix.get('status') == 'captured; compile/runtime outcomes require independent review'
         if family == 'nl3' else matrix.get('status') == 'captured_pending_independent_rebuild_review',
         f'{family}: matrix is not terminal captured')
    need(matrix.get('target_absent') is True, f'{family}: target absence not confirmed')
    need(matrix.get('source_unchanged') is True, f'{family}: workspace source closure not confirmed')
    need(matrix.get('source_before') == matrix.get('source_after'), f'{family}: source closure changed')
    need(not (root / 'target').exists(), f'{family}: current workspace target exists')
    base_jarde_rows = baseline.get('jarde_cells', [])
    base_jadx_rows = baseline.get('jadx_cells', [])
    for source_row in [*base_jarde_rows, *base_jadx_rows]:
        need(pin(Path(source_row['input']['path'])) == source_row['input'],
             f'{family}: original physical input class pin changed')
    if family == 'nl3':
        dep_receipt = baseline
    else:
        ref_pin = baseline['baseline_reference']
        need(pin(Path(ref_pin['path'])) == ref_pin, 'supplement baseline dependency reference changed')
        dep_receipt = json.loads(Path(ref_pin['path']).read_text(encoding='utf-8'))
    dependency_rows = [dep_receipt['harness_jar'], *dep_receipt.get('jar_pins', [])]
    for dependency in dependency_rows:
        need(pin(Path(dependency['path'])) == dependency, f'{family}: pinned compile/runtime dependency changed')
    for folder, expected_tree in dep_receipt.get('directory_pins_before', {}).items():
        actual_tree = {p.relative_to(Path(folder)).as_posix(): pin(p)
                       for p in sorted(Path(folder).rglob('*.class')) if p.is_file()}
        need(actual_tree == expected_tree, f'{family}: pinned external JADX classpath directory changed: {folder}')

    # Verify every captured command's raw streams, and reject stop/error records before interpreting counts.
    commands = matrix.get('commands', [])
    cby = {row['index']: row for row in commands}
    need(len(commands) == len(cby), f'{family}: duplicate command indexes')
    for row in commands:
        need(row.get('guard_stop') is None, f"{family}: guard stopped command {row['index']}")
        read_artifact(compare, row, 'stdout')
        read_artifact(compare, row, 'stderr')
    srcs = validate_sources(matrix, family, baseline, compare)
    api = validate_api_binding(matrix, family, compare)
    if api and matrix.get('cli') is not None:
        need(matrix['cli'] == api.get('cli') and pin(Path(matrix['cli']['path'])) == matrix['cli'],
             f'{family}: matrix CLI is not the exact accepted API replay CLI')
    if family == 'nl3':
        driver_copy = matrix['driver_source_copy']
        original_driver = baseline['driver']
        need(matrix.get('driver_source') == original_driver, 'NL3 driver source identity differs from baseline pin')
        need(pin(Path(driver_copy['path'])) == driver_copy and driver_copy['sha256'] == original_driver['sha256'],
             'NL3 independent driver copy differs from frozen original driver')
        driver_bytes = Path(driver_copy['path']).read_text(encoding='utf-8')
        driver_command = cby.get(matrix['driver_compile']['command'])
        need(driver_command is not None and driver_command.get('exit_code') == 0 and driver_copy['path'] in driver_command['argv'],
             'NL3 driver compile command did not compile its pinned isolated copy')
    else:
        driver_copy = matrix['driver_source']
        original_driver = baseline['driver_source']
        need(pin(Path(driver_copy['path'])) == driver_copy and driver_copy['sha256'] == original_driver['sha256'],
             'supplement independent driver copy differs from frozen original driver')
        driver_bytes = Path(driver_copy['path']).read_text(encoding='utf-8')
        driver_cmds = [x for x in commands if x.get('label') == 'compile-independent-driver']
        need(len(driver_cmds) == 1 and driver_cmds[0].get('exit_code') == 0 and driver_copy['path'] in driver_cmds[0]['argv'],
             'supplement driver compile command did not compile its pinned isolated copy')
    need('getProtectionDomain()' in driver_bytes and 'getCodeSource()' in driver_bytes and 'expectedRoot' in driver_bytes,
         f'{family}: pinned driver lacks the runtime CodeSource isolation check')
    jdk_record = matrix.get('jdk_manifest') if family == 'nl3' else matrix.get('jdk')
    need(isinstance(jdk_record, dict) and isinstance(jdk_record.get('tools'), dict), f'{family}: JDK manifest/tool pins absent')
    manifest_path = Path(jdk_record['path'])
    manifest_bytes = manifest_path.read_bytes()
    need(hashlib.sha256(manifest_bytes).hexdigest() == jdk_record['sha256'], f'{family}: JDK manifest changed')
    for leg in ('javac8', 'javac23'):
        for tool_name in ('javac', 'java'):
            tool_pin = jdk_record['tools'][leg][tool_name]
            need(pin(Path(tool_pin['path'])) == tool_pin, f'{family}: pinned {leg} {tool_name} changed')
    # Bind every immutable source/class selection back to its exact original capture cell.
    if family == 'nl3':
        base_jarde = {(x['profile'], x['form'], x['evidence']): x for x in baseline['jarde_cells']}
        base_jadx = {(x['profile'], x['form'], 'source'): x for x in baseline['jadx_cells']}
        api_cells = {(x['profile'], x['form'], x['evidence']): x for x in api['jarde_cells']} if api else {}
        for sk, item in srcs.items():
            _, profile, form, evidence = sk
            if item['kind'] == 'jarde':
                base = base_jarde[(profile, form, evidence)]
                reviewed = api_cells[(profile, form, evidence)]
                need(reviewed['input'] == base['input'], f'{family}/{sk}: API replay changed original class input')
                need(item['original_source_pin'] == reviewed['source'] and item['original_report_pin'] == reviewed['report'],
                     f'{family}/{sk}: matrix source is not the accepted API cell source/report')
            else:
                base = base_jadx[(profile, form, 'source')]
                need(item['original_source_pin'] == base['sources'][0], f'{family}/{sk}: JADX source differs from original capture pin')
                need(item['original_source_pin'] is not None, f'{family}/{sk}: missing immutable JADX source pin')
    else:
        base_by_key = {(x['name'], x['compiler'], x['profile']): x for x in baseline['classes']}
        base_jadx = {(x['name'], x['compiler'], x['profile']): x for x in baseline['jadx_cells']}
        api_cells = {(x['name'], x['compiler'], x['profile'], x['evidence']): x for x in api['jarde_cells']} if api else {}
        for sk, item in srcs.items():
            _, name, input_compiler, profile, evidence = sk
            original = base_by_key[(name, input_compiler, profile)]
            need(item['input'] == original['class'], f'{family}/{sk}: input class differs from original capture pin')
            if item['kind'] == 'jarde':
                reviewed = api_cells[(name, input_compiler, profile, evidence)]
                need(reviewed['input'] == original['class'], f'{family}/{sk}: API replay changed original class input')
                need(item['source_pin'] == reviewed['source'] and item['report'] == reviewed['report'],
                     f'{family}/{sk}: matrix source is not the accepted API cell source/report')
            else:
                old = base_jadx[(name, input_compiler, profile)]
                need(item['source_pin'] == old['sources'][0], f'{family}/{sk}: JADX source differs from original capture pin')

    if family == 'nl3':
        compile_rows = matrix.get('compilation_cells', [])
        runtime_rows = matrix.get('runtime_rows', [])
        expected_jarde = 16
        expected_jadx_compile = 8
        expected_target = ('test', '(I)I')
        expected_methods_by_profile = {
            row['profile']: {(m['name'], m['descriptor'], m['access']) for m in row['target']['methods']}
            for row in baseline['profiles']
        }
        oracle_pin = baseline['oracle']
        need(pin(Path(oracle_pin['path'])) == oracle_pin, 'NL3 baseline oracle pin changed')
        oracle_by_kind = {'nl3': Path(oracle_pin['path']).read_bytes()}
        expected_cell_status = None
        expected_api_count = 8
    else:
        compile_rows = matrix.get('compile_cells', [])
        runtime_rows = matrix.get('runtime_cells', [])
        expected_jarde = 32
        expected_jadx_compile = 16
        expected_target = ('execute', '(III)I')
        expected_methods = None
        oracle_by_kind = {}
        for name, oracle_pin in baseline['oracles'].items():
            need(pin(Path(oracle_pin['path'])) == oracle_pin, f'{name}: original oracle pin changed')
            oracle_by_kind[name] = Path(oracle_pin['path']).read_bytes()
        expected_cell_status = None
        expected_api_count = 16

    need(len(compile_rows) == expected_jarde + expected_jadx_compile,
         f'{family}: expected {expected_jarde + expected_jadx_compile} freshly compiled cells, got {len(compile_rows)}')
    cell_by_key = {}
    source_key_to_input = {}
    for sk, item in srcs.items():
        source_key_to_input[sk] = item
    for cell in compile_rows:
        ck = compile_key(cell, family)
        need(ck not in cell_by_key, f'{family}: duplicate compile cell {ck}')
        cell_by_key[ck] = cell
        sk = ck[:-1]
        need(sk in source_key_to_input, f'{family}/{ck}: no source input row')
        item = source_key_to_input[sk]
        need(cell.get('source') == item['compile_source'] if family == 'nl3' else cell.get('source') == item['compile_source'],
             f'{family}/{ck}: compiled source pin differs from immutable input copy')
        cmd = cby.get(cell.get('command'))
        need(cmd is not None, f'{family}/{ck}: compile command missing')
        need(cmd.get('exit_code') == cell.get('exit_code'), f'{family}/{ck}: compile exit mismatch')
        argv = cmd['argv']
        need(Path(argv[0]).resolve() == Path(jdk_record['tools'][cell['compiler']]['javac']['path']).resolve(),
             f'{family}/{ck}: compile command used an unpinned javac')
        need(str(item['compile_source']['path']) in argv, f'{family}/{ck}: javac did not compile the recorded source copy')
        for flag in ('-encoding', 'UTF-8', '-proc:none', '-sourcepath'):
            need(flag in argv, f'{family}/{ck}: javac omitted required isolated-source flag {flag}')
        sourcepath_index = argv.index('-sourcepath')
        need(Path(argv[sourcepath_index + 1]).name.startswith('empty-sourcepath'),
             f'{family}/{ck}: javac sourcepath is not the recorded empty directory')
        cp_index_compile = argv.index('-classpath') if '-classpath' in argv else argv.index('-cp')
        if family == 'nl3':
            expected_compile_cp = item['class_path']
            need(cell.get('classpath') == expected_compile_cp, f'{family}/{ck}: compile classpath differs from pinned source policy')
            expected_compile_cp_string = __import__('os').pathsep.join(map(str, expected_compile_cp))
            need(argv[cp_index_compile + 1] == expected_compile_cp_string, f'{family}/{ck}: raw javac classpath differs')
        else:
            need(Path(argv[cp_index_compile + 1]).name.startswith('empty-sourcepath'),
                 f'{family}/{ck}: supplement javac classpath is not isolated/empty')
        if cell['kind'] == 'jarde':
            need(cell.get('exit_code') == 0, f'{family}/{ck}: required Jarde full-source compilation failed')
            need(cell.get('status') in ('compiled_target_present', 'compile_succeeded'),
                 f'{family}/{ck}: Jarde target not classified as present')
        if cell.get('exit_code') == 0:
            target_pin = cell.get('target_class') if family == 'nl3' else cell.get('target')
            need(isinstance(target_pin, dict) and pin(Path(target_pin['path'])) == target_pin,
                 f'{family}/{ck}: successfully compiled cell lacks a pinned target class')
            facts = cell.get('target_facts') if family == 'nl3' else cell.get('facts')
            need(isinstance(facts, dict), f'{family}/{ck}: target class facts missing')
            need(facts.get('major') == 52, f'{family}/{ck}: target class is not Java 8 major 52')
            expected_class_name = ('jadx/tests/integration/loops/TestNestedLoops3$TestCls'
                                   if family == 'nl3' else cell['name'])
            need(facts.get('class_name') == expected_class_name, f'{family}/{ck}: target binary class identity changed')
            methods = fact_methods(facts)
            if family == 'nl3':
                need(methods == expected_methods_by_profile[cell['profile']], f'{family}/{ck}: class method inventory differs from original complete class')
                need(cell.get('declared_methods_match_expected') is True and cell.get('classfile_major_is_java8') is True,
                     f"{family}/{ck}: collector class inventory/major checks failed")
            else:
                input_class = item['input']
                need(pin(Path(input_class['path'])) == input_class, f'{family}/{ck}: original input class pin changed')
                expected_for_input = None
                for source_class in baseline['classes']:
                    if (source_class['name'], source_class['compiler'], source_class['profile']) == (cell['name'], cell['input_compiler'], cell['profile']):
                        expected_for_input = {(m['name'], m['descriptor'], m['access']) for m in source_class['facts']['methods']}
                        break
                need(expected_for_input is not None and methods == expected_for_input,
                     f'{family}/{ck}: rebuilt method inventory differs from pinned original class')
                need(cell.get('complete_method_inventory') is True and cell.get('major52') is True,
                     f"{family}/{ck}: collector complete method/major checks failed")
            need(expected_target in {(m['name'], m['descriptor']) for m in facts['methods']},
                 f'{family}/{ck}: target method absent')
            root_classes = Path(cell.get('target_classes_root') or cell.get('classes_root'))
            need(target_pin['path'].startswith(str(root_classes) + '/'), f'{family}/{ck}: target class escaped fresh output root')
            before_tree = cell.get('target_classes_tree_before_runtime') or cell.get('classes_after_compile')
            need(before_tree == class_tree(root_classes, compare), f'{family}/{ck}: class output tree pin changed')
        else:
            need(not cell.get('runtime'), f'{family}/{ck}: compile failure has runtime rows')

    expected_compile_keys = {tuple(sk) + (compiler,) for sk in srcs for compiler in ('javac8', 'javac23')}
    need(set(cell_by_key) == expected_compile_keys, f'{family}: compile matrix is not exactly two compiler legs per immutable source')
    expected_jarde_cells = [x for x in compile_rows if x['kind'] == 'jarde']
    expected_jadx_cells = [x for x in compile_rows if x['kind'] == 'jadx']
    need(len(expected_jarde_cells) == expected_jarde, f'{family}: wrong Jarde compile count')
    need(len(expected_jadx_cells) == expected_jadx_compile, f'{family}: wrong JADX compile count')
    need(all(x.get('exit_code') == 0 for x in expected_jarde_cells), f'{family}: not all Jarde source cells compiled')

    # Every successful compile gets two fresh JVM runs; failures stay compile-only. Verify exact roots/driver/oracle.
    runtime_by_key = {}
    for row in runtime_rows:
        rk = runtime_key(row, family)
        need(rk not in runtime_by_key, f'{family}: duplicate runtime observation {rk}')
        runtime_by_key[rk] = row
        ck = rk[:-1]
        cell = cell_by_key.get(ck)
        need(cell is not None and cell.get('exit_code') == 0, f'{family}/{rk}: runtime has no successful compile cell')
        need(row.get('exit_code') == 0, f'{family}/{rk}: runtime command failed')
        cmd = cby.get(row.get('command'))
        need(cmd is not None and cmd.get('exit_code') == 0, f'{family}/{rk}: runtime raw command failed')
        stdout = read_artifact(compare, cmd, 'stdout')
        name = 'nl3' if family == 'nl3' else row['name']
        need(name in oracle_by_kind and stdout == oracle_by_kind[name], f'{family}/{rk}: output differs from original JVM oracle')
        need(row.get('oracle_equal_byte_for_byte', row.get('oracle_equal')) is True,
             f'{family}/{rk}: collector did not record byte-exact oracle equality')
        target_root = Path(cell.get('target_classes_root') or cell.get('classes_root')).resolve()
        driver_root_value = matrix.get('driver_classes_root')
        driver_root = Path(driver_root_value) if isinstance(driver_root_value, str) else Path(receipt).parent / 'driver-classes'
        if family == 'nl3':
            cp_record = row.get('classpath_order')
            expected_cp = [str(target_root), str(driver_root), *matrix['classpath_child_and_jarde']]
            need(cp_record == expected_cp, f'{family}/{rk}: recorded classpath order differs')
            target_arg = row.get('expected_root_argument')
        else:
            cp_record = row.get('runtime_classpath')
            expected_cp = [str(target_root), str(driver_root)]
            need(cp_record == expected_cp, f'{family}/{rk}: recorded classpath order differs')
            target_arg = str(target_root)
        need(str(target_arg) == str(target_root), f'{family}/{rk}: driver target-root argument differs')
        argv = cmd['argv']
        # Commands are timeout wrappers; unwrap the final Java argv and enforce exact CP + driver target root.
        java_pin = jdk_record['tools'][row['runtime']]['java']
        java_arg = str(Path(java_pin['path']).resolve())
        java_positions = [i for i, arg in enumerate(argv) if Path(arg).exists() and str(Path(arg).resolve()) == java_arg]
        need(len(java_positions) == 1, f'{family}/{rk}: runtime did not use exactly its pinned JVM')
        need('-Xverify:all' in argv, f'{family}/{rk}: runtime omitted full verifier')
        need(str(target_root) in argv, f'{family}/{rk}: runtime argv lacks exact target root')
        if family == 'nl3':
            wrapper_pin = matrix['runtime_timeout_wrapper']
        else:
            ref_pin = baseline['baseline_reference']
            need(pin(Path(ref_pin['path'])) == ref_pin, 'supplement baseline dependency receipt changed')
            ref = json.loads(Path(ref_pin['path']).read_text(encoding='utf-8'))
            wrapper_pin = ref['runtime_bound']
        need(pin(Path(wrapper_pin['path'])) == wrapper_pin and wrapper_pin['path'] in argv,
             f'{family}/{rk}: runtime timeout wrapper path/pin mismatch')
        java_at = java_positions[0]
        need(java_at >= 4 and argv[1:4] == ['-B', wrapper_pin['path'], '30'],
             f'{family}/{rk}: runtime timeout guard arguments differ from the pinned protocol')
        expected_main = 'TestNestedLoops3Driver' if family == 'nl3' else 'RetryFixtureDriver'
        need(argv[java_at + 1:java_at + 3] == ['-Xverify:all', '-cp'],
             f'{family}/{rk}: runtime JVM verification/classpath flags are out of order')
        cp_index = argv.index('-cp') if '-cp' in argv else (argv.index('-classpath') if '-classpath' in argv else -1)
        main_index = cp_index + 2
        need(argv[main_index] == expected_main, f'{family}/{rk}: wrong isolated reflection driver')
        if family == 'nl3':
            need(argv[main_index + 1] == str(target_root), f'{family}/{rk}: wrong NL3 driver root argument')
        else:
            need(argv[main_index + 1:main_index + 3] == [row['name'], str(target_root)],
                 f'{family}/{rk}: wrong supplement target name/root arguments')
        need(cp_index >= 0 and argv[cp_index + 1] == __import__('os').pathsep.join(expected_cp),
             f'{family}/{rk}: raw runtime classpath differs from recorded isolated roots')
        need(str(target_root) in argv[cp_index + 1].split(__import__('os').pathsep), f'{family}/{rk}: target is not first classpath element')
        # Target and driver output trees must be unchanged through execution.
        if family == 'nl3':
            need(row.get('status') == 'matches_original_oracle', f'{family}/{rk}: nonmatching runtime status')
        else:
            need(row.get('oracle_equal') is True, f'{family}/{rk}: nonmatching runtime status')
    expected_runtime_n = sum(2 for x in compile_rows if x.get('exit_code') == 0 and (x.get('target_class') or x.get('target')))
    need(len(runtime_rows) == expected_runtime_n, f'{family}: runtime count does not equal two per successful class compile')
    expected_jarde_runtime = 32 if family == 'nl3' else 64
    jarde_runtime_rows = [x for x in runtime_rows if x['kind'] == 'jarde']
    need(len(jarde_runtime_rows) == expected_jarde_runtime and
         all(x.get('oracle_equal_byte_for_byte', x.get('oracle_equal')) is True for x in jarde_runtime_rows),
         f'{family}: Jarde runtime count/oracle parity is not {expected_jarde_runtime} successful comparisons')
    need(len(runtime_by_key) == expected_runtime_n, f'{family}: missing runtime leg for a successful class compile')
    for cell in compile_rows:
        if cell.get('exit_code') == 0 and (cell.get('target_class') or cell.get('target')):
            for vm in ('javac8', 'javac23'):
                need(runtime_key({**cell, 'runtime': vm}, family) in runtime_by_key,
                     f'{family}/{compile_key(cell, family)}: missing {vm} runtime')
    expected_command_indexes = {matrix['driver_compile']['command']} if family == 'nl3' else {driver_cmds[0]['index']}
    expected_command_indexes.update(x['command'] for x in compile_rows)
    expected_command_indexes.update(x['command'] for x in runtime_rows)
    need(set(cby) == expected_command_indexes, f'{family}: unaccounted or missing raw commands in the matrix receipt')

    # Source, driver, compiler inputs, toolchain pins and output trees must retain their recorded closure.
    source_copy_after = matrix.get('driver_source_copy_after') if family == 'nl3' else matrix.get('driver_source')
    if family == 'nl3':
        need(source_copy_after == matrix.get('driver_source_copy'), f'{family}: independent driver source copy changed')
        driver_tree_after = matrix.get('driver_classes_tree_after_matrix')
        need(driver_tree_after == class_tree(Path(receipt).parent / 'driver-classes', compare), f'{family}: driver classes changed after runs')
        for cell in compile_rows:
            if cell.get('exit_code') == 0 and cell.get('target_classes_tree_after_runtimes') is not None:
                need(cell['target_classes_tree_after_runtimes'] == cell.get('target_classes_tree_before_runtime'),
                     f'{family}/{compile_key(cell, family)}: target tree changed after runtime')
        need(matrix.get('inputs_after') is not None, f'{family}: final input closure missing')
    else:
        need(pin(Path(matrix['driver_source']['path'])) == matrix['driver_source'], f'{family}: driver source pin changed')
        need(matrix.get('driver_classes') == class_tree(Path(receipt).parent / 'driver-classes', compare),
             f'{family}: driver class tree pin changed')
        for cell in compile_rows:
            if cell.get('exit_code') == 0:
                need(cell.get('classes_after_runtime') == cell.get('classes_after_compile'),
                     f'{family}/{compile_key(cell, family)}: output class tree changed after runtime')
    return {
        'family': family, 'receipt': pin(receipt), 'baseline': pin(baseline_path),
        'commands': len(commands), 'compile_cells': len(compile_rows),
        'jarde_compile_ok': sum(x['kind'] == 'jarde' and x.get('exit_code') == 0 for x in compile_rows),
        'jadx_compile_ok': sum(x['kind'] == 'jadx' and x.get('exit_code') == 0 for x in compile_rows),
        'jadx_compile_failures': [
            {'key': compile_key(x, family), 'exit_code': x.get('exit_code'),
             'stderr_sha256': hashlib.sha256(read_artifact(compare, cby[x['command']], 'stderr')).hexdigest()}
            for x in compile_rows if x['kind'] == 'jadx' and x.get('exit_code') != 0],
        'runtime_rows': len(runtime_rows),
        'runtime_all_oracle_equal': all((x.get('oracle_equal_byte_for_byte', x.get('oracle_equal')) is True) for x in runtime_rows),
        'api_capture': matrix.get('api_capture'),
        'api_acceptance': matrix.get('api_acceptance'),
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--nl3', type=Path, required=True, help='terminal original-source NL3 matrix execution.json')
    ap.add_argument('--supplement', type=Path, required=True, help='terminal retry-supplement matrix execution.json')
    ap.add_argument('--nl3-baseline', type=Path, default=BASELINE_NL3)
    ap.add_argument('--supplement-baseline', type=Path, default=BASELINE_RETRY)
    ap.add_argument('--root', type=Path, default=ROOT)
    ap.add_argument('--out', type=Path, required=True, help='new private review JSON path')
    args = ap.parse_args()
    root = args.root.resolve(strict=True)
    compare = load_compare(root)
    nl3 = validate_family(args.nl3, 'nl3', args.nl3_baseline, compare, root)
    supplement = validate_family(args.supplement, 'supplement', args.supplement_baseline, compare, root)
    result = {
        'status': 'independent_read_only_rebuild_review_passed',
        'limitations': [
            'This checker validates recorded command streams, classfile facts, source pins and JVM output receipts; it does not execute a compiler or JVM.',
            'It proves each successful rebuilt runtime used the class root recorded by the matrix and matched the original oracle. The driver source pin is inherited from the immutable baseline receipt.',
            'JADX compile failures, if any, are preserved and summarized as observed matrix outcomes; they are not interpreted as Jarde semantic failures.'
        ],
        'nl3': nl3,
        'supplement': supplement,
    }
    out = args.out.resolve()
    need(not out.exists(), f'refusing to overwrite {out}')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: {n: v[n] for n in ('commands','compile_cells','jarde_compile_ok','jadx_compile_ok','runtime_rows','runtime_all_oracle_equal')}
                      for k,v in (('nl3',nl3),('supplement',supplement))}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
