// jarde: presentation of `PrefixRetryAlpha` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class PrefixRetryAlpha extends java.lang.Object {
    public int trace;

    public int outerPrefixCalls;

    public int retryPrefixCalls;

    public int protectedCalls;

    public int catchCalls;

    public int outerIterations;

    public java.lang.RuntimeException lastCaught;

    public java.lang.String lastCaughtMessage;

    public final java.lang.IllegalArgumentException prefixEscape;

    public final java.lang.AssertionError protectedEscape;

    public final java.lang.AssertionError catchEscape;

    private int failuresRemaining;

    public PrefixRetryAlpha() {
        // @method <init>()V
        // @declaration a constructor of `PrefixRetryAlpha`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.prefixEscape = new java.lang.IllegalArgumentException("alpha-prefix");
        this.protectedEscape = new java.lang.AssertionError((java.lang.Object) "alpha-protected-error");
        this.catchEscape = new java.lang.AssertionError((java.lang.Object) "alpha-catch-effect");
        return;
    }

    public int execute(int arg1, int arg2, int arg3) {
        // @method execute(III)I
        // @declaration an instance method of `PrefixRetryAlpha`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int local4;
        this.failuresRemaining = bounded(arg1, 0, 1);
        local4 = bounded(arg2, 1, 2);
        int local5;
        loop: while (true) {
            this.f1(arg3);
            this.outerIterations += 1;
            local5 = 0;
            while (true) {
                this.f2(arg3);
                if (local5 != 0) {
                    break loop;
                } else {
                    local5 = local5 + 3;
                    if (this.outerIterations > local4) {
                        break loop;
                    } else {
                        try {
                            this.protectedStep(arg3);
                        } catch (java.lang.IllegalArgumentException local6) {
                            this.catchCalls += 1;
                            this.recordCatch(local6, arg3);
                            continue;
                        }
                        break;
                    }
                }
            }
            continue;
        }
        this.record(5);
        return this.trace;
    }

    private void f1(int arg1) {
        // @method f1(I)V
        // @declaration an instance method of `PrefixRetryAlpha`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.outerPrefixCalls += 1;
        this.record(1);
        if ((arg1 & 1) != 0) {
            throw this.prefixEscape;
        } else {
            return;
        }
    }

    private void f2(int arg1) {
        // @method f2(I)V
        // @declaration an instance method of `PrefixRetryAlpha`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.retryPrefixCalls += 1;
        this.record(2);
        if ((arg1 & 2) != 0) {
            throw this.prefixEscape;
        } else {
            return;
        }
    }

    private void protectedStep(int arg1) {
        // @method protectedStep(I)V
        // @declaration an instance method of `PrefixRetryAlpha`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.protectedCalls += 1;
        this.record(3);
        if (this.failuresRemaining > 0) {
            this.failuresRemaining -= 1;
            throw new java.lang.IllegalArgumentException("alpha-retry");
        } else if ((arg1 & 4) != 0) {
            throw this.protectedEscape;
    } else {
            return;
    }
    }

    private void recordCatch(java.lang.IllegalArgumentException arg1, int arg2) {
        // @method recordCatch(Ljava/lang/IllegalArgumentException;I)V
        // @declaration an instance method of `PrefixRetryAlpha`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.lastCaught = arg1;
        this.lastCaughtMessage = arg1.getMessage();
        this.record(4);
        if ((arg2 & 8) != 0) {
            throw this.catchEscape;
        } else {
            return;
        }
    }

    private void record(int arg1) {
        // @method record(I)V
        // @declaration an instance method of `PrefixRetryAlpha`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.trace = this.trace * 10 + arg1;
        return;
    }

    private static int bounded(int arg0, int arg1, int arg2) {
        // @method bounded(III)I
        // @declaration a static method of `PrefixRetryAlpha`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        return java.lang.Math.max(arg1, java.lang.Math.min(arg0, arg2));
    }
}
