// jarde: presentation of `RetryPrefixBeta` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class RetryPrefixBeta extends java.lang.Object {
    public int trace;

    public int outerPrefixCalls;

    public int retryPrefixCalls;

    public int protectedCalls;

    public int catchCalls;

    public int outerIterations;

    public java.lang.RuntimeException lastCaught;

    public java.lang.String lastCaughtMessage;

    public final java.lang.IllegalStateException prefixEscape;

    public final java.lang.AssertionError protectedEscape;

    public final java.lang.AssertionError catchEscape;

    private int injectedFailures;

    public RetryPrefixBeta() {
        // @method <init>()V
        // @declaration a constructor of `RetryPrefixBeta`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.prefixEscape = new java.lang.IllegalStateException("beta-prefix");
        this.protectedEscape = new java.lang.AssertionError((java.lang.Object) "beta-protected-error");
        this.catchEscape = new java.lang.AssertionError((java.lang.Object) "beta-catch-effect");
        return;
    }

    public int execute(int arg1, int arg2, int arg3) {
        // @method execute(III)I
        // @declaration an instance method of `RetryPrefixBeta`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int local4;
        this.injectedFailures = cap(arg1, 0, 1);
        local4 = cap(arg2, 1, 2);
        int local5;
        loop: while (true) {
            this.beginOuter(arg3);
            this.outerIterations += 1;
            local5 = 0;
            while (true) {
                this.beginRetry(arg3);
                if (local5 != 0) {
                    break loop;
                } else {
                    local5 = local5 + 7;
                    if (this.outerIterations > local4) {
                        break loop;
                    } else {
                        try {
                            this.performProtected(arg3);
                        } catch (java.lang.IllegalStateException local6) {
                            this.catchCalls += 1;
                            this.rememberCatch(local6, arg3);
                            continue;
                        }
                        break;
                    }
                }
            }
            continue;
        }
        this.append(5);
        return this.trace;
    }

    private void beginOuter(int arg1) {
        // @method beginOuter(I)V
        // @declaration an instance method of `RetryPrefixBeta`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.outerPrefixCalls += 1;
        this.append(2);
        if ((arg1 & 1) != 0) {
            throw this.prefixEscape;
        } else {
            return;
        }
    }

    private void beginRetry(int arg1) {
        // @method beginRetry(I)V
        // @declaration an instance method of `RetryPrefixBeta`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.retryPrefixCalls += 1;
        this.append(1);
        if ((arg1 & 2) != 0) {
            throw this.prefixEscape;
        } else {
            return;
        }
    }

    private void performProtected(int arg1) {
        // @method performProtected(I)V
        // @declaration an instance method of `RetryPrefixBeta`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.protectedCalls += 1;
        this.append(4);
        if (this.injectedFailures != 0) {
            this.injectedFailures -= 1;
            throw new java.lang.IllegalStateException("beta-again");
        } else if ((arg1 & 4) != 0) {
            throw this.protectedEscape;
    } else {
            return;
    }
    }

    private void rememberCatch(java.lang.IllegalStateException arg1, int arg2) {
        // @method rememberCatch(Ljava/lang/IllegalStateException;I)V
        // @declaration an instance method of `RetryPrefixBeta`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.lastCaught = arg1;
        this.lastCaughtMessage = arg1.getMessage();
        this.append(3);
        if ((arg2 & 8) != 0) {
            throw this.catchEscape;
        } else {
            return;
        }
    }

    private void append(int arg1) {
        // @method append(I)V
        // @declaration an instance method of `RetryPrefixBeta`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.trace = this.trace * 10 + arg1;
        return;
    }

    private static int cap(int arg0, int arg1, int arg2) {
        // @method cap(III)I
        // @declaration a static method of `RetryPrefixBeta`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        return java.lang.Math.max(arg1, java.lang.Math.min(arg0, arg2));
    }
}
