# Prefixed exceptional retry edge-closure helper v4 (private candidate)

This is an unexecuted private patch against the current shared snapshot. No shared file was changed and no Rust/toolchain command was run.

## Source pins

- `crates/jarde-java/src/region.rs` base SHA-256: `fd573dd52e25daef08f82721569b67594cf4d530cec1820f08d9536c8963ea17`
- `crates/jarde-java/src/region/protected_prefix_loop_tests.rs` base SHA-256: `6ff82c13b4e561312c581ac8cca200636cd3257025c16d60ab0a94290b3c3ee7`
- `region.rs` candidate SHA-256: `3d1d6f9a26bff0ec98d91ae03ce9aefa4c2ed36366aa64440b5aff7e04017f2d`
- `protected_prefix_loop_tests.rs` candidate SHA-256: `3447da12661678afc20c5ce9434c74d86f6a48fb0b57610914e8e1f6c3629d93`
- `v4.patch` SHA-256: `c905e266f233f8a46b08e4642630d8a5c6dab921bdb81c96ee4a93570caf7a15`

The patch is `v4.patch`. Complete candidate files are alongside it. The test-file diff contains only the v4 closure-policy test appended to the already-integrated v3 baseline.

## Change

The current inline owner-edge closure loop is factored into private `retry_owner_edges_closed`. Production supplies rows lazily from the current `CanonicalCfg`, including normal-flow indices, edge kind, clone-path facts, and source BCI. The helper preserves the current rules: owner-to-owner normal edges are allowed; owner exits are recorded only at the exact outer exit; only already-visited external predecessors may enter the outer header; exactly the protected-to-handler exception with the certified row ordinal is allowed; clone identities or every other incident edge refuse. The wrapper still compares discovered exit gateways with the set proved earlier, so the helper does not replace the enclosing proof.

The existing aggregate work reservation used a four-edge-pass bound. This candidate lowers it to three because there are exactly two other full canonical-edge passes in this facts gate (protected-row edge census and outer-header incoming census); the extracted closure helper now charges one analysis step per row itself. Thus the accounted edge scans remain four passes. No analysis budget dimension or stop behavior is removed.

## Direct policy test

`retry_owner_edge_closure_rejects_each_unowned_edge_class` first proves `PrefixedExceptionalRetryFacts::Some` from the same original class analysis, then passes its same-run canonical rows to the extracted helper and requires the real closure to succeed with the exact discovered gateway set. Four one-at-a-time row mutations must return ordinary `None`: an external edge into the inner owner, an owner edge to an unrelated outside node, an edge marked as having a clone endpoint, and the protected exception with a mismatched ordinal.

The clone case is deliberately a helper-input mutation, not a claimed JVM-valid class or a canonical graph produced by the reader. This fixture has no established clone-bearing input receipt in this task. It tests the exact clone-path predicate the production adapter derives from `CanonicalBlockId::is_clone()`. The entry/exit/ordinal cases have the same metamorphic-policy scope.

Existing integrated tests remain responsible for physical row start/end/handler/ordinal mismatches and pre-cancel/deadline checkpoint restoration. This patch does not duplicate them.

## Not verified

No compile, format, test, fixture regeneration, CLI, or runtime validation was performed. Root must review and run focused unit/API checks before integration. In particular, Rust borrow/type compatibility and exact accounting should be verified by the existing guarded build and analysis-budget tests.
