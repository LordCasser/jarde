from pathlib import Path
import difflib, hashlib

root = Path('/private/tmp/jarde-prefixed-exceptional-retry-loops-impl-luna-v2-20261018')
s = (root / 'region.rs.base').read_text()

needle = '''        if !body_branch
            && let Some(region) =
                self.latch_tested_loop(header, header_node, &blocks, frame, false)?
        {
            return Ok(region);
        }
        let reason = FallbackReason::LoopShape {
'''
insert = '''        if !body_branch
            && let Some(region) =
                self.latch_tested_loop(header, header_node, &blocks, frame, false)?
        {
            return Ok(region);
        }
        if let Some(region) =
            self.prefixed_exceptional_retry_loop(header, header_node, &loop_of, frame)?
        {
            return Ok(region);
        }
        let reason = FallbackReason::LoopShape {
'''
if s.count(needle) != 1:
    raise SystemExit(f'loop insertion point count {s.count(needle)}')
s = s.replace(needle, insert, 1)

marker = '''    /// Only the two-break shape whose header's losing arm writes a local through one call.
'''
method = r'''    /// The bounded exceptional retry form has two distinct loop entries: a natural outer
    /// loop and a source-level inner retry loop whose handler returns to its own header. The
    /// exception-table row proves the Try; this method proves the enclosing owner and then lets
    /// the existing region walk build both loops and the catch body.
    fn prefixed_exceptional_retry_loop(
        &mut self,
        outer_header: &CanonicalBlockId,
        outer_header_node: usize,
        outer_loop: &crate::normal_flow::NaturalLoop,
        frame: &Frame,
    ) -> Result<Option<Run>, StopReason> {
        if frame.boundary.is_some()
            || frame.if_arm.is_some()
            || frame.shared_tail.is_some()
            || frame.scope.is_some()
            || frame.case_entries.is_some()
            || !frame.loop_targets.is_empty()
            || frame.own_loop.is_some()
            || frame.own_try.is_some()
            || frame.own_finally.is_some()
            || frame.segmented_finally_rows.is_some()
            || frame.multi_return_finally_rows.is_some()
            || frame.nested_finally_row.is_some()
            || frame.void_loop_finally
            || frame.lock_guard_finally
            || self.fragmented.is_some()
            || self.own_monitor.is_some()
            || self.handlers.len() != 1
            || outer_loop.is_irreducible()
        {
            return Ok(None);
        }
        let Some(facts) = self.prefixed_exceptional_retry_facts(
            outer_header,
            outer_header_node,
            outer_loop,
        )? else {
            return Ok(None);
        };
        let owner_count = facts
            .outer_nodes
            .len()
            .saturating_add(facts.inner_nodes.len())
            .saturating_add(facts.prefix_nodes.len())
            .saturating_add(8);
        charge(
            self.budget,
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(owner_count.saturating_mul(2)).unwrap_or(u64::MAX),
            Some(outer_header.bci()),
        )?;
        poll(self.budget, Some(outer_header.bci()))?;

        // The entire candidate walk is transactional. Budget work remains charged, while all
        // ownership and proof state is restored on refusal or Stop.
        let saved_visited = self.visited.clone();
        let saved_unclosed_tail = self.unclosed_tail_at;
        let saved_catch_joins = self.catch_joins.clone();
        let saved_loop_catch_terminal_owners = self.loop_catch_terminal_owners.clone();
        let saved_fragmented = self.fragmented.clone();
        let saved_own_monitor = self.own_monitor.clone();
        let saved_depth = self.depth;
        macro_rules! restore_candidate {
            () => {{
                self.visited = saved_visited.clone();
                self.unclosed_tail_at = saved_unclosed_tail;
                self.catch_joins = saved_catch_joins.clone();
                self.loop_catch_terminal_owners = saved_loop_catch_terminal_owners.clone();
                self.fragmented = saved_fragmented.clone();
                self.own_monitor = saved_own_monitor.clone();
                self.depth = saved_depth;
            }};
        }

        let attempt: Result<Option<Run>, StopReason> = (|| {
            if facts
                .outer_nodes
                .iter()
                .any(|node| saved_visited.contains(node))
            {
                return Ok(None);
            }
            let outer_exit = facts.outer_exit.clone();
            let outer_exit_node = facts.outer_exit_node;
            let outer_scope = facts.outer_nodes.clone();
            let outer_exits = BTreeSet::from([outer_exit_node]);
            let outer_transfer_sources = self.loop_transfer_sources(&outer_exits);
            let mut outer_frame = frame.loop_body(
                &outer_scope,
                outer_header_node,
                outer_header_node,
                outer_header_node,
                Some(outer_exit_node),
                Some(outer_exit_node),
                outer_exits,
                &outer_transfer_sources,
                &BTreeSet::new(),
                &BTreeSet::new(),
            );
            outer_frame.allow_own_loop_entry = true;

            // Walk the already-proved straight prefix through the existing reader. The inner
            // retry header is the boundary; every prefix block remains an ordinary owner.
            let mut prefix_frame = outer_frame.clone();
            prefix_frame.boundary = Some(facts.inner_header_node);
            let (prefix, prefix_next) = self.region_at(outer_header, &prefix_frame)?;
            if prefix_next.as_ref() != Some(&facts.inner_header)
                || prefix.iter().any(|region| !region.is_structured())
            {
                return Ok(None);
            }
            let prefix_blocks: Vec<_> = prefix.iter().flat_map(Region::blocks).cloned().collect();
            let prefix_nodes: BTreeSet<_> = prefix_blocks
                .iter()
                .filter_map(|block| self.view.index_of(block))
                .collect();
            if prefix_nodes != facts.prefix_nodes || prefix_blocks.len() != prefix_nodes.len() {
                return Ok(None);
            }

            // The child loop is deliberately constructed from the checked row/header facts rather
            // than NaturalLoop: the handler edge makes the source-level retry cycle non-natural in
            // NormalFlowView. Frame::loop_body preserves the outer scope intersection and gives
            // ordinary If/Try walks the exact break and continue identities.
            let inner_exit_node = facts.normal_join_node;
            let inner_exit = facts.normal_join.clone();
            let inner_exits = BTreeSet::from([inner_exit_node]);
            let inner_transfer_sources = self.loop_transfer_sources(&inner_exits);
            let mut inner_frame = outer_frame.loop_body(
                &facts.inner_nodes,
                inner_exit_node,
                facts.inner_header_node,
                facts.inner_header_node,
                Some(inner_exit_node),
                Some(inner_exit_node),
                inner_exits,
                &inner_transfer_sources,
                &BTreeSet::new(),
                &BTreeSet::new(),
            );
            inner_frame.allow_own_loop_entry = true;
            // The handler is a row-owned body, not an ordinary natural-loop successor. Make its
            // already-proved owner visible to that clause walk even when normal-flow omitted it
            // from the outer natural set.
            if let Some(scope) = inner_frame.scope.as_mut() {
                scope.insert(facts.handler_node);
                if facts.normal_join != facts.outer_header {
                    scope.insert(facts.normal_join_node);
                }
            }
            let (inner_body, inner_next) = self.region_at(&facts.inner_header, &inner_frame)?;
            if inner_next.as_ref() != Some(&facts.normal_join)
                || inner_body.is_empty()
                || inner_body.iter().any(|region| !region.is_structured())
                || !contains_try_with_handler(&inner_body, &facts.handler)
            {
                return Ok(None);
            }
            let inner_loop = Region::Loop {
                header: facts.inner_header.clone(),
                tests: Vec::new(),
                test_operator: None,
                form: LoopForm::Endless,
                for_header: None,
                body: inner_body,
                exit: Some(facts.normal_join.clone()),
                gateway_origins: Vec::new(),
            };

            let mut outer_body = prefix;
            outer_body.push(inner_loop);
            if facts.normal_join != facts.outer_header {
                // The single pure normal-join bridge belongs after the inner loop. Preserve its
                // physical transfer both as a statement origin and as its canonical block owner.
                let source_bci = self
                    .terminal_bci(&facts.normal_join)
                    .ok_or(StopReason::Interrupted {
                        code: crate::stop::INTERNAL_INVARIANT_CODE,
                        at: Some(facts.normal_join.bci()),
                    })?;
                self.visited.insert(facts.normal_join_node);
                outer_body.push(Region::Sequence {
                    regions: vec![
                        Region::Straight {
                            blocks: vec![facts.normal_join.clone()],
                        },
                        Region::LoopContinue {
                            source_bci,
                            loop_header: facts.outer_header.clone(),
                        },
                    ],
                });
            }

            let mut added = BTreeSet::new();
            let work = self.visited.len().saturating_add(saved_visited.len());
            charge(
                self.budget,
                CountedBudgetDimension::AnalysisSteps,
                u64::try_from(work).unwrap_or(u64::MAX),
                Some(outer_header.bci()),
            )?;
            for node in &self.visited {
                if let Some(block) = self.canonical.blocks().get(*node) {
                    poll(self.budget, Some(block.id().bci()))?;
                }
                if !saved_visited.contains(node) {
                    added.insert(*node);
                }
            }
            if added != facts.outer_nodes {
                return Ok(None);
            }
            let physical: Vec<_> = outer_body
                .iter()
                .flat_map(Region::blocks)
                .cloned()
                .collect();
            let physical_nodes: BTreeSet<_> = physical
                .iter()
                .filter_map(|block| self.view.index_of(block))
                .collect();
            if physical.len() != physical_nodes.len()
                || physical_nodes != facts.outer_nodes
                || outer_body.iter().any(|region| !region.is_structured())
            {
                return Ok(None);
            }
            Ok(Some((
                vec![Region::Loop {
                    header: outer_header.clone(),
                    tests: Vec::new(),
                    test_operator: None,
                    form: LoopForm::Endless,
                    for_header: None,
                    body: outer_body,
                    exit: Some(outer_exit.clone()),
                    gateway_origins: Vec::new(),
                }],
                Some(outer_exit),
            )))
        })();
        match attempt {
            Ok(Some(run)) => Ok(Some(run)),
            Ok(None) => {
                restore_candidate!();
                Ok(None)
            }
            Err(stop) => {
                restore_candidate!();
                Err(stop)
            }
        }
    }

    /// Proves the one-row, one-protected-block retry owner inside a natural outer endless loop.
    /// Role fields are intentionally independent: only the normal-join may alias the outer header,
    /// or be one pure bridge that is itself the outer latch.
    fn prefixed_exceptional_retry_facts(
        &mut self,
        outer_header: &CanonicalBlockId,
        outer_header_node: usize,
        outer_loop: &crate::normal_flow::NaturalLoop,
    ) -> Result<Option<PrefixedExceptionalRetryFacts>, StopReason> {
        let outer_nodes = outer_loop.blocks().clone();
        if !outer_nodes.contains(&outer_header_node) {
            return Ok(None);
        }
        let latches: Vec<_> = outer_loop.latches().iter().copied().collect();
        let [outer_latch_node] = latches.as_slice() else {
            return Ok(None);
        };
        let Some(outer_latch) = self.view.id_of(*outer_latch_node).cloned() else {
            return Ok(None);
        };
        if self.view.successors(*outer_latch_node) != [outer_header_node]
            || !self
                .terminal_bci(&outer_latch)
                .is_some_and(|bci| matches!(self.operations.get(bci), Some(Operation::Transfer)))
        {
            return Ok(None);
        }
        let outer_exits = self.loop_exit_nodes(&outer_nodes);
        let [outer_exit_node] = outer_exits.iter().copied().collect::<Vec<_>>().as_slice() else {
            return Ok(None);
        };
        let Some(outer_exit) = self.view.id_of(*outer_exit_node).cloned() else {
            return Ok(None);
        };

        // Find the exact named physical row through its canonical row, then ask the existing
        // CatchSite reader to prove parameter binding and the ordinary Try shape.
        let mut rows = Vec::new();
        charge(
            self.budget,
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(self.canonical.handler_rows().len())
                .unwrap_or(u64::MAX),
            Some(outer_header.bci()),
        )?;
        for canonical_row in self.canonical.handler_rows() {
            poll(self.budget, Some(canonical_row.handler_bci()))?;
            if canonical_row.catch_type_index().is_some()
                && canonical_row.protected().len() == 1
                && canonical_row.protected()[0].path().is_empty()
                && canonical_row.protected()[0].bci()
                    == self.handlers[0].start_bci
                && canonical_row.handler().is_some()
                && canonical_row.handler().is_some_and(|handler| handler.path().is_empty())
            {
                rows.push(canonical_row);
            }
        }
        let [canonical_row] = rows.as_slice() else {
            return Ok(None);
        };
        let physical_row = &self.handlers[0];
        let Some(protected) = canonical_row.protected().first().cloned() else {
            return Ok(None);
        };
        let Some(handler) = canonical_row.handler().cloned() else {
            return Ok(None);
        };
        let (Some(protected_node), Some(handler_node)) =
            (self.view.index_of(&protected), self.view.index_of(&handler))
        else {
            return Ok(None);
        };
        if !protected.path().is_empty()
            || !handler.path().is_empty()
            || protected.bci() != physical_row.start_bci
            || canonical_row.ordinal() != physical_row.ordinal
            || canonical_row.handler_bci() != physical_row.handler_bci
            || canonical_row.catch_type_index() != physical_row.catch_type_index
            || physical_row.catch_type_index.is_none()
            || !outer_nodes.contains(&protected_node)
        {
            return Ok(None);
        }
        let Some(shape) = crate::guard::catches(
            self.canonical,
            self.view,
            self.ssa,
            self.operations,
            self.handlers,
            self.fragmented.as_ref(),
            None,
            self.profile,
            &protected,
            self.budget,
        )? else {
            return Ok(None);
        };
        if shape.inner.is_some()
            || shape.transparent.is_some()
            || shape.lead != (protected.bci(), protected.bci())
            || shape.sites.len() != 1
            || shape.sites[0].handler != handler
            || shape.sites[0].types
                != crate::guard::CatchTypes::Named(vec![physical_row.catch_type_index.unwrap()])
        {
            return Ok(None);
        }
        let Some(normal_join) = shape.join.clone() else {
            return Ok(None);
        };
        let Some(normal_join_node) = self.view.index_of(&normal_join) else {
            return Ok(None);
        };
        let Some(inner_header_node) = self.view.successors(handler_node).as_slice().first().copied()
        else {
            return Ok(None);
        };
        let Some(inner_header) = self.view.id_of(inner_header_node).cloned() else {
            return Ok(None);
        };
        if self.view.predecessors(handler_node).len() != 0
            || self.view.successors(handler_node).len() != 1
            || inner_header_node == outer_header_node
            || !outer_nodes.contains(&inner_header_node)
            || !outer_nodes.contains(&protected_node)
            || inner_header == protected
            || inner_header == handler
            || normal_join == protected
        {
            return Ok(None);
        }

        // Only this row owns the protected exceptional edge; every protected throw site must name
        // exactly it. The ordinary handler remains outside that row, so failures in handler calls
        // escape as they did in the JVM.
        let mut protected_exception = false;
        let mut throw_sites = 0usize;
        let mut edge_work = 0usize;
        for edge in self.canonical.edges() {
            if edge.from() == &protected || edge.to() == &protected || edge.from() == &handler {
                edge_work = edge_work.saturating_add(1);
            }
        }
        charge(
            self.budget,
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(edge_work.saturating_add(self.canonical.throw_sites().len()))
                .unwrap_or(u64::MAX),
            Some(protected.bci()),
        )?;
        for edge in self.canonical.edges() {
            poll(self.budget, Some(edge.from().bci()))?;
            if edge.from() == &handler && edge.kind() != CanonicalEdgeKind::Normal {
                return Ok(None);
            }
            if edge.from() != &protected {
                continue;
            }
            match edge.kind() {
                CanonicalEdgeKind::Normal if edge.to() == &normal_join => {}
                CanonicalEdgeKind::Exception { handler_ordinal }
                    if handler_ordinal == physical_row.ordinal && edge.to() == &handler =>
                {
                    protected_exception = true;
                }
                _ => return Ok(None),
            }
        }
        for site in self.canonical.throw_sites() {
            poll(self.budget, Some(site.bci()))?;
            if site.block() == &protected {
                if site.handlers() != [physical_row.ordinal] {
                    return Ok(None);
                }
                throw_sites += 1;
            }
        }
        if !protected_exception
            || throw_sites == 0
            || self.view.successors(protected_node) != [normal_join_node]
            || self.view.successors(handler_node) != [inner_header_node]
        {
            return Ok(None);
        }

        // The sole outer latch is the protected normal transfer for the direct form, or the one
        // pure normal-join bridge for the effectful-handler form.
        if normal_join == *outer_header {
            if *outer_latch_node != protected_node {
                return Ok(None);
            }
        } else if normal_join_node != *outer_latch_node
            || self.view.predecessors(normal_join_node) != [protected_node]
        {
            return Ok(None);
        }
        if normal_join != *outer_header {
            let Some(join_block) = self
                .canonical
                .blocks()
                .iter()
                .find(|block| block.id() == &normal_join)
            else {
                return Ok(None);
            };
            let Some(instructions) = self.ssa.block(&normal_join).map(|block| block.instructions())
            else {
                return Ok(None);
            };
            let [only] = instructions else {
                return Ok(None);
            };
            if join_block.end_bci()
                != self
                    .code
                    .instructions
                    .iter()
                    .find(|instruction| instruction.bci == only.bci())
                    .map(|instruction| instruction.bci + u32::from(instruction.width))
                    .unwrap_or(0)
                || !matches!(self.operations.get(only.bci()), Some(Operation::Transfer))
                || !only.reads().is_empty()
                || !only.writes().is_empty()
                || self.view.successors(normal_join_node) != [outer_header_node]
            {
                return Ok(None);
            }
        }

        // The retry body begins at the handler's sole normal successor and is a bounded region of
        // this natural outer loop. Its only normal exits are the proved Try join and the same outer
        // break destination. This rejects a second entry, a clone, and any hidden alternate tail.
        let mut prefix_nodes = BTreeSet::new();
        let mut prefix_cursor = outer_header_node;
        for _ in 0..=outer_nodes.len() {
            poll(self.budget, self.view.id_of(prefix_cursor).map(CanonicalBlockId::bci))?;
            if prefix_cursor == inner_header_node {
                break;
            }
            if !outer_nodes.contains(&prefix_cursor)
                || prefix_cursor == handler_node
                || prefix_cursor == protected_node
                || prefix_cursor == normal_join_node
                || !prefix_nodes.insert(prefix_cursor)
            {
                return Ok(None);
            }
            let successors = self.view.successors(prefix_cursor);
            let [next] = successors.as_slice() else {
                return Ok(None);
            };
            prefix_cursor = *next;
        }
        if prefix_cursor != inner_header_node {
            return Ok(None);
        }
        let mut prefix_incoming_ok = true;
        let mut external_entries = 0usize;
        for edge in self.canonical.edges() {
            poll(self.budget, Some(edge.from().bci()))?;
            if self.view.index_of(edge.to()) == Some(outer_header_node)
                && !outer_nodes.contains(&self.view.index_of(edge.from()).unwrap_or(usize::MAX))
            {
                if edge.kind() != CanonicalEdgeKind::Normal || !self.visited.contains(&self.view.index_of(edge.from()).unwrap_or(usize::MAX)) {
                    prefix_incoming_ok = false;
                }
                external_entries += 1;
            }
        }
        if external_entries > 1 || !prefix_incoming_ok {
            return Ok(None);
        }

        let mut inner_nodes = BTreeSet::new();
        let mut pending = vec![inner_header_node];
        while let Some(node) = pending.pop() {
            poll(self.budget, self.view.id_of(node).map(CanonicalBlockId::bci))?;
            if node == normal_join_node || node == outer_header_node || node == outer_exit_node {
                continue;
            }
            if node == handler_node || !outer_nodes.contains(&node) || !inner_nodes.insert(node) {
                if node == handler_node || !outer_nodes.contains(&node) {
                    return Ok(None);
                }
                continue;
            }
            for successor in self.view.successors(node) {
                if successor == normal_join_node || successor == outer_header_node || successor == outer_exit_node {
                    continue;
                }
                if !outer_nodes.contains(&successor) || successor == handler_node {
                    return Ok(None);
                }
                pending.push(successor);
            }
        }
        if !inner_nodes.contains(&inner_header_node) || !inner_nodes.contains(&protected_node) {
            return Ok(None);
        }
        let mut outer_owners = outer_nodes.clone();
        outer_owners.insert(handler_node);
        let mut expected = prefix_nodes.clone();
        expected.extend(inner_nodes.iter().copied());
        expected.insert(handler_node);
        if normal_join != *outer_header {
            expected.insert(normal_join_node);
        }
        if expected != outer_owners {
            return Ok(None);
        }

        // Close every owner edge, including exceptional edges and clone identities. Only one
        // already-walked preheader may enter the outer header; the catch row alone enters its
        // handler; exits from the natural loop all reach the same proved outer exit.
        let mut exit_gateways = BTreeSet::new();
        let mut closure_ok = true;
        for edge in self.canonical.edges() {
            let from = self.view.index_of(edge.from()).unwrap_or(usize::MAX);
            let to = self.view.index_of(edge.to()).unwrap_or(usize::MAX);
            let from_owned = outer_owners.contains(&from);
            let to_owned = outer_owners.contains(&to);
            if !from_owned && !to_owned {
                continue;
            }
            if !edge.from().path().is_empty() || !edge.to().path().is_empty() {
                closure_ok = false;
                break;
            }
            match edge.kind() {
                CanonicalEdgeKind::Normal if from_owned && to_owned => {
                    // Every normal edge stays in the finite proved owner set.
                }
                CanonicalEdgeKind::Normal if from_owned && to == outer_exit_node => {
                    exit_gateways.insert(from);
                }
                CanonicalEdgeKind::Normal if !from_owned && to == outer_header_node => {
                    if !self.visited.contains(&from) {
                        closure_ok = false;
                        break;
                    }
                }
                CanonicalEdgeKind::Exception { handler_ordinal }
                    if from == protected_node
                        && to == handler_node
                        && handler_ordinal == physical_row.ordinal => {}
                _ => {
                    closure_ok = false;
                    break;
                }
            }
        }
        if !closure_ok || exit_gateways.is_empty() {
            return Ok(None);
        }
        for source in &exit_gateways {
            poll(self.budget, self.view.id_of(*source).map(CanonicalBlockId::bci))?;
            let Some(source_id) = self.view.id_of(*source) else {
                return Ok(None);
            };
            let Some(test_bci) = self.terminal_bci(source_id) else {
                return Ok(None);
            };
            match self.operations.get(test_bci) {
                Some(Operation::Comparison { .. }) if self.view.successors(*source).len() == 2 => {
                    if self.test_is_pure(source_id, test_bci, false).is_err()
                        || self.view.successors(*source).iter().any(|successor| {
                            *successor != outer_exit_node && !outer_nodes.contains(successor)
                        })
                    {
                        return Ok(None);
                    }
                }
                Some(Operation::Transfer) if self.view.successors(*source) == [outer_exit_node] => {}
                _ => return Ok(None),
            }
        }

        let mut prefix_ids = Vec::with_capacity(prefix_nodes.len());
        let mut cursor = outer_header_node;
        while cursor != inner_header_node {
            let Some(id) = self.view.id_of(cursor).cloned() else {
                return Ok(None);
            };
            prefix_ids.push(id);
            let [next] = self.view.successors(cursor).as_slice() else {
                return Ok(None);
            };
            cursor = *next;
        }
        let mut inner_ids = BTreeSet::new();
        for node in &inner_nodes {
            let Some(id) = self.view.id_of(*node) else {
                return Ok(None);
            };
            inner_ids.insert(id.clone());
        }
        let mut edge_check_work = self.canonical.edges().len();
        edge_check_work = edge_check_work
            .saturating_add(self.canonical.throw_sites().len())
            .saturating_add(self.canonical.blocks().len());
        charge(
            self.budget,
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(edge_check_work).unwrap_or(u64::MAX),
            Some(outer_header.bci()),
        )?;
        Ok(Some(PrefixedExceptionalRetryFacts {
            outer_header: outer_header.clone(),
            outer_header_node,
            inner_header,
            inner_header_node,
            protected,
            protected_node,
            handler,
            handler_node,
            normal_join,
            normal_join_node,
            outer_exit,
            outer_exit_node,
            row_ordinal: physical_row.ordinal,
            outer_nodes: outer_owners,
            inner_nodes,
            prefix_nodes,
            prefix_ids,
        }))
    }

'''
if s.count(marker) != 1:
    raise SystemExit(f'method marker count {s.count(marker)}')
s = s.replace(marker, method + marker, 1)

# Add proof roles near the existing retry fact. Keep this internal and local to Region.
needle = '''#[derive(Clone, Debug)]
struct RetryLoopFacts {
'''
struct = '''#[derive(Clone, Debug)]
struct PrefixedExceptionalRetryFacts {
    outer_header: CanonicalBlockId,
    outer_header_node: usize,
    inner_header: CanonicalBlockId,
    inner_header_node: usize,
    protected: CanonicalBlockId,
    protected_node: usize,
    handler: CanonicalBlockId,
    handler_node: usize,
    normal_join: CanonicalBlockId,
    normal_join_node: usize,
    outer_exit: CanonicalBlockId,
    outer_exit_node: usize,
    row_ordinal: u32,
    outer_nodes: BTreeSet<usize>,
    inner_nodes: BTreeSet<usize>,
    prefix_nodes: BTreeSet<usize>,
    prefix_ids: Vec<CanonicalBlockId>,
}

#[derive(Clone, Debug)]
struct RetryLoopFacts {
'''
if s.count(needle) != 1:
    raise SystemExit(f'struct marker count {s.count(needle)}')
s = s.replace(needle, struct, 1)

# Add a tiny tree predicate beside other module helpers.
marker = '''fn candidate_region_blocks(
'''
predicate = '''fn contains_try_with_handler(regions: &[Region], handler: &CanonicalBlockId) -> bool {
    fn contains(region: &Region, handler: &CanonicalBlockId) -> bool {
        match region {
            Region::Try { catches, body, .. } => {
                catches.iter().any(|clause| {
                    clause.handler == *handler && clause.body.is_structured()
                }) || contains(body, handler)
            }
            Region::Sequence { regions } | Region::Loop { body: regions, .. } => {
                regions.iter().any(|region| contains(region, handler))
            }
            Region::If { then_arm, else_arm, .. } => {
                contains(then_arm, handler) || contains(else_arm, handler)
            }
            Region::CompoundIf { then_arm, else_arm, .. } => {
                contains(then_arm, handler) || contains(else_arm, handler)
            }
            Region::Switch { groups, .. } | Region::StringSwitch { groups, .. } => {
                groups.iter().any(|group| contains(&group.arm, handler))
            }
            _ => false,
        }
    }
    regions.iter().any(|region| contains(region, handler))
}

'''
if s.count(marker) != 1:
    raise SystemExit(f'helper marker count {s.count(marker)}')
s = s.replace(marker, predicate + marker, 1)

# Inject finite variant fields if this base differs (the candidate uses no Frame state, so only facts needed).
out = root / 'region.rs'
out.write_text(s)
patch = ''.join(difflib.unified_diff((root/'region.rs.base').read_text().splitlines(True), s.splitlines(True), fromfile='a/crates/jarde-java/src/region.rs', tofile='b/crates/jarde-java/src/region.rs'))
(root/'region-private.patch').write_text(patch)
print(f'candidate bytes={len(s)} lines={s.count(chr(10))} sha256={hashlib.sha256(s.encode()).hexdigest()} patch={len(patch)}')
