from pathlib import Path
import re, difflib, hashlib
base=Path('/private/tmp/jarde-prefixed-exceptional-retry-loops-impl-luna-v2-20261018/region.rs.base')
out=base.parent/'region.rs'
s=base.read_text()

def replace_once(old,new,label):
 global s
 n=s.count(old)
 if n!=1: raise SystemExit(f'{label}: expected 1 match, got {n}')
 s=s.replace(old,new,1)

# Add explicit handler continuation fact and composite certificate.
replace_once('''#[derive(Clone, Debug)]
struct LoopTarget {
    header: usize,
    exits: BTreeSet<usize>,
    break_target: Option<usize>,
    continue_target: usize,
    /// Return leaves certified for this loop body. Keeping the proof on its owner lets nested
    /// switch classification distinguish a decoded return from an arbitrary terminal block.
    terminal_returns: Arc<BTreeSet<usize>>,
}
''','''#[derive(Clone, Debug)]
struct RetryHandlerFacts {
    /// The protected statement start. It is intentionally independent of `retry_header`.
    protected: CanonicalBlockId,
    protected_node: usize,
    /// The enclosing loop resumed by this exact handler transfer.
    retry_header: CanonicalBlockId,
    retry_header_node: usize,
    handler: CanonicalBlockId,
    handler_node: usize,
    row_ordinal: u32,
    continue_source_bci: u32,
}

#[derive(Clone, Debug)]
struct PrefixedExceptionalRetryFacts {
    outer_header: CanonicalBlockId,
    outer_header_node: usize,
    inner_header: CanonicalBlockId,
    inner_header_node: usize,
    protected: CanonicalBlockId,
    protected_node: usize,
    handler: CanonicalBlockId,
    handler_node: usize,
    outer_exit: CanonicalBlockId,
    outer_exit_node: usize,
    row_ordinal: u32,
    continue_source_bci: u32,
    outer_owners: BTreeSet<usize>,
    inner_owners: BTreeSet<usize>,
    entry_predecessor: Option<usize>,
}

#[derive(Clone, Debug)]
struct LoopTarget {
    header: usize,
    exits: BTreeSet<usize>,
    break_target: Option<usize>,
    continue_target: usize,
    /// Return leaves certified for this loop body. Keeping the proof on its owner lets nested
    /// switch classification distinguish a decoded return from an arbitrary terminal block.
    terminal_returns: Arc<BTreeSet<usize>>,
    /// A named catch that may append this loop's exact handler continue leaf. This does not
    /// claim that the protected statement is itself a loop.
    retry_handler: Option<Arc<RetryHandlerFacts>>,
}
''','structs')

# Keep standalone retry proof identity as-is, but remember the row ordinal for handler projection.
replace_once('''    continue_source_bci: u32,
    owners: BTreeSet<usize>,
    transfer_sources: BTreeSet<usize>,
}
''','''    continue_source_bci: u32,
    row_ordinal: u32,
    owners: BTreeSet<usize>,
    transfer_sources: BTreeSet<usize>,
}
''','retry facts')
replace_once('''                    continue_target,
                    terminal_returns: Arc::new(terminal_returns.clone()),
                });''','''                    continue_target,
                    terminal_returns: Arc::new(terminal_returns.clone()),
                    retry_handler: None,
                });''','loop_body target')
# Unit-test literals
s=s.replace('''                terminal_returns: Arc::new(BTreeSet::new()),
            }],''','''                terminal_returns: Arc::new(BTreeSet::new()),
                retry_handler: None,
            }],''')
s=s.replace('''            terminal_returns: Arc::new(BTreeSet::new()),
        });''','''            terminal_returns: Arc::new(BTreeSet::new()),
            retry_handler: None,
        });''')

# Keep the exact row identity in the old retry fact.
replace_once('''            handler_node,
            continue_source_bci,
            owners,
            transfer_sources,
        }))''','''            handler_node,
            continue_source_bci,
            row_ordinal: row.ordinal,
            owners,
            transfer_sources,
        }))''','retry fact construction')

# Insert fact selection in try_region and pass it into try_level.
needle='''        let previous =
            (shape.transparent.is_some() || retry.is_some()).then(|| self.visited.clone());'''
insert='''        let mut standalone_handler = retry.as_ref().map(|proof| RetryHandlerFacts {
            protected: start.clone(),
            protected_node: node,
            retry_header: proof.header.clone(),
            retry_header_node: proof.header_node,
            handler: proof.handler.clone(),
            handler_node: proof.handler_node,
            row_ordinal: proof.row_ordinal,
            continue_source_bci: proof.continue_source_bci,
        });
        let loop_handler = frame
            .loop_targets
            .last()
            .and_then(|target| target.retry_handler.as_deref())
            .filter(|proof| {
                proof.protected == *start
                    && proof.protected_node == node
                    && frame.loop_targets.last().is_some_and(|target| {
                        target.header == proof.retry_header_node
                            && target.continue_target == proof.retry_header_node
                    })
            });
        if let Some(proof) = loop_handler {
            let Some(rows) = named_catch_rows_for_shape(
                self.canonical,
                self.handlers,
                &shape,
                self.budget,
            )? else {
                return Ok(None);
            };
            if rows.as_ref() != &BTreeSet::from([proof.row_ordinal])
                || shape.sites.len() != 1
                || shape.sites[0].handler != proof.handler
                || proof.handler_node != self.view.index_of(&proof.handler).unwrap_or(usize::MAX)
                || shape.inner.is_some()
                || shape.transparent.is_some()
            {
                return Ok(None);
            }
        }
        let handler_retry = loop_handler.or(standalone_handler.as_ref());
        let previous =
            (shape.transparent.is_some() || retry.is_some()).then(|| self.visited.clone());'''
replace_once(needle,insert,'try_region handler context')
replace_once('''            match self.try_level(start, node, walk_frame, &shape, retry.as_ref()) {''','''            match self.try_level(start, node, walk_frame, &shape, retry.as_ref(), handler_retry) {''','try_level call')

# Extend try_level signature and its nested recursive call.
replace_once('''        shape: &crate::guard::Catches,
        retry: Option<&RetryLoopFacts>,
    ) -> Result<''','''        shape: &crate::guard::Catches,
        retry: Option<&RetryLoopFacts>,
        handler_retry: Option<&RetryHandlerFacts>,
    ) -> Result<''','try_level signature')
replace_once('''                    self.try_level(start, node, &outer_frame, inner, None)?;''','''                    self.try_level(start, node, &outer_frame, inner, None, None)?;''','nested try_level call')

# Use exact handler fact for the clause boundary and transfer leaf; keep RetryLoopFacts wrapper unchanged.
replace_once('''            let handler_boundary = retry
                .and_then(|proof| self.view.index_of(&proof.header))
                .or(boundary_node);''','''            let handler_boundary = handler_retry
                .map(|proof| proof.retry_header_node)
                .or(boundary_node);''','handler boundary')
replace_once('''            if let Some(proof) = retry {
                if site.handler != proof.handler
                    || handler_next
                        .as_ref()
                        .is_some_and(|next| next != &proof.header)
                {
                    return Ok((
                        sequence_region(Vec::new()),
                        Vec::new(),
                        None,
                        Vec::new(),
                        None,
                    ));
                }
                let handler_blocks: Vec<_> =
                    handler.iter().flat_map(Region::blocks).cloned().collect();
                charge(
                    self.budget,
                    CountedBudgetDimension::AnalysisSteps,
                    u64::try_from(handler_blocks.len()).unwrap_or(u64::MAX),
                    Some(proof.handler.bci()),
                )?;
                for block in &handler_blocks {
                    poll(self.budget, Some(block.bci()))?;
                }
                if handler_blocks.iter().cloned().collect::<BTreeSet<_>>()
                    != BTreeSet::from([proof.handler.clone()])
                {
                    return Ok((
                        sequence_region(Vec::new()),
                        Vec::new(),
                        None,
                        Vec::new(),
                        None,
                    ));
                }
                handler.push(Region::LoopContinue {
                    source_bci: proof.continue_source_bci,
                    loop_header: proof.header.clone(),
                });
            }
            let handler = if certified || retry.is_some() {''','''            if let Some(proof) = handler_retry.filter(|proof| {
                proof.protected == *start
                    && proof.row_ordinal != u32::MAX
                    && proof.handler == site.handler
            }) {
                if handler_next
                    .as_ref()
                    .is_some_and(|next| next != &proof.retry_header)
                    || self.view.index_of(&proof.handler) != Some(proof.handler_node)
                    || self.terminal_bci(&proof.handler) != Some(proof.continue_source_bci)
                    || !matches!(
                        self.operations.get(proof.continue_source_bci),
                        Some(Operation::Transfer)
                    )
                    || self.view.successors(proof.handler_node) != [proof.retry_header_node]
                {
                    return Ok((
                        sequence_region(Vec::new()),
                        Vec::new(),
                        None,
                        Vec::new(),
                        None,
                    ));
                }
                let handler_blocks: Vec<_> =
                    handler.iter().flat_map(Region::blocks).cloned().collect();
                charge(
                    self.budget,
                    CountedBudgetDimension::AnalysisSteps,
                    u64::try_from(handler_blocks.len()).unwrap_or(u64::MAX),
                    Some(proof.handler.bci()),
                )?;
                for block in &handler_blocks {
                    poll(self.budget, Some(block.bci()))?;
                }
                if handler_blocks.as_slice() != [proof.handler.clone()] {
                    return Ok((
                        sequence_region(Vec::new()),
                        Vec::new(),
                        None,
                        Vec::new(),
                        None,
                    ));
                }
                handler.push(Region::LoopContinue {
                    source_bci: proof.continue_source_bci,
                    loop_header: proof.retry_header.clone(),
                });
            }
            let handler = if certified || retry.is_some() || handler_retry.is_some() {''','try_level handler block')

# Current try_level call inside try_region is now updated; no other call sites expected.

out.write_text(s)
print('wrote',out,'bytes',out.stat().st_size)
