# Prefixed exceptional retry-loop candidate (static draft)

This is a private, uncompiled candidate for OpenSpec task 2.1. It is based on the exact shared `region.rs` bytes whose SHA-256 is `70ab9673905cdbd81c928474b399188563bce095f045f6e0c3d7a7ddba2cef8d`; the tests file base is `d0ce40eb9fc8a62140821e90326d75f3cbe1bb1bccdf1088f0dd1a42df1f1159`. `region-private.patch` applies only to those source bytes. No shared file or toolchain was changed or run.

## Candidate implementation

- `loop_region` tries the new bounded reader only after the existing loop recognizers refuse. The caller is top-level and requires the exact one-row case, an irreducible-free natural outer loop, and no enclosing ownership frame.
- `prefixed_exceptional_retry_facts` keeps role identities separate. It reads a unique physical/canonical named row, asks `guard::catches` for the real catch-parameter proof, validates the whole protected span and its range-end `goto`, checks row/throw-site ownership, and proves handler-to-retry-header and protected-to-normal-join edges independently.
- The outer natural loop's immediate outside successors are treated as exit gateways. All must be one-instruction effect-free `goto`s to one terminal exit; the gateways are added to the composite owner set and admitted into the inner bounded DAG. The optional normal-join bridge remains a separate pure `goto` to the outer header and must be the natural latch with the protected block as sole predecessor.
- The actual outer prefix is constrained to the outer header's single successor, which must be the retry header. The prefix walk expects `region_at`'s existing boundary contract: a straight run ending at the boundary returns `next=None`.
- `RetryHandlerContinuation` is stored on the exact inner `LoopTarget`. `try_level` consumes it only when start, physical row ordinal/range/type, handler, and current loop identity match; the rendered catch gets the real handler `goto` as `LoopContinue`. The old `RetryLoopFacts` predicate remains unchanged for its original protected-start-equals-retry-header case.
- The complete outer attempt snapshots every Reader field the child walk changes (`visited`, unclosed tail, catch joins, loop-catch owners, fragmented proof, monitor owner, recursion depth). A refusal or Stop restores that state; budget usage stays charged.
- When a pure normal-join bridge exists, its source BCI is carried in outer `Loop.gateway_origins` while the bridge block is owned once in the outer body. The protected range-end and handler edges remain represented by the existing `LoopBreak`/`LoopContinue` machinery.

## Private unit candidates

The patch appends focused tests to `protected_prefix_loop_tests.rs`:

- The frozen original `TestNestedLoops3$TestCls.test(I)I` checks the complete candidate walk and distinct transfer identities `(14→0 break, 26→0 break, 33→6 break, 37→6 continue)`.
- A reference-cost minus one test requires an `AnalysisSteps` Stop after the candidate walk starts and compares the full Reader checkpoint before/after.
- Two JVM-verified legal neighboring classes call the new facts gate directly: `PrefixRetryEffectfulLatch` must refuse its effectful normal-join block; `PrefixRetryCatchOuter` must refuse a handler that returns to the outer header. Their source/class manifests are in the shared fixture tree. These assertions concern only this bounded facts gate, not a claim about whole-method fallback.

Fixture pins used by those unit tests:

- Original debug class: 1323 bytes, SHA-256 `f8bf155376ec438208ab538ce89b74fc36d0c56b3fcbe9f2f9b849b48742c6df`.
- Original no-debug class: 890 bytes, SHA-256 `eac91ecea7c9f3db3ce044cdb8f1f95068e926e15ffb23821484609541ad376a` (the public API matrix uses both; this private unit test uses debug).
- Effectful-latch rejection, javac8/debug: 2542 bytes, SHA-256 `6361e1b19196804a3289a7e1b40169d3f1db1e5e35c2d1120a4959032115e114`.
- Catch-to-outer rejection, javac8/debug: 2520 bytes, SHA-256 `f7b0c9f8de68d4fe61e72da17b26c992b32ef4eb5d47d0fbbfc9cf6c6a0378a4`.

The supplement classes have real javac8/javac23, debug/no-debug and JVM run receipts; they exercise the pure bridge at BCI 94 and an effectful bridge at the same semantic boundary. Constant-pool indexes are deliberately not encoded in the candidate.

## Static risks for root's first guarded build

1. Rust compilation and clippy have not been run. The `control_flow_targets` type and all `LoopTarget` literals were statically checked; Rust compilation, borrow checking, and clippy remain unrun.
2. The full candidate needs real Reader/API execution on original and supplement fixtures. `region_at` may return the enclosing outer exit (40/97) as a residual join when the source-level inner header has no natural-loop entry. The candidate currently accepts only `inner_next == normal_join`; do not relax this until a real run shows the returned join and the consumed owner/transfer leaves prove the exact normal join, both outer breaks, and handler continue. This is the main known structural risk for the first probe.
3. Validate the branch-gateway `visited` delta against `Region::blocks()` on the actual API path. The intended exact set is natural outer nodes + immediate exit gateways + the row-owned handler, with a pure bridge already in the natural set.
4. The direct original has no bridge origin; the supplemental bridge form should publish BCI 94 through `gateway_origins` and own its block once. Verify map source preservation and default/all parity.
5. The cost-minus-one unit test assumes deterministic candidate costs and a final budget charge after child construction. If it stops earlier, keep it labeled as the actual observed point or move the proof-stage stop to the smallest charge that demonstrably follows the inner child walk; do not call an early public stop an internal proof stop.

Generated private diff SHA-256: `f51f1780632a84ed8e1936fde99423dbed9a479463a498858797a72a379aa3a1`.

Candidate file pins after the final static repair: `region.rs` SHA-256 `d278f1aca838cf110f724abca40ed71d87f82e1de6607462be8d0a522e439136`; `protected_prefix_loop_tests.rs` SHA-256 `28124d589431e2cdf57fb63ebdcae971d06b7579242f2bcfff57b13bec9e93fb`.
