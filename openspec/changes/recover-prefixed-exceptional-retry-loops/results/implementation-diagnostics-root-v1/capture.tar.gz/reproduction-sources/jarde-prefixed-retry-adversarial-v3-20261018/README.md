# Prefixed exceptional retry: private adversarial test supplement v3

This patch is based on the read-only shared test file as read for this pass. Base SHA-256: `481cd2dacde7a3e37a5091e8bade01c7f49b86bea449e09558c1ca29bb1e55df`. The candidate only adds tests/helpers in `protected_prefix_loop_tests.rs`; it does not alter shared files or production code. Patch SHA-256: `37036691dc0cd0dfee14297b9e3dadebe556c14ee77e1f976f86ccbca0836479`.

## Added direct-gate checks

- A positive control calls `prefixed_exceptional_retry_facts` on the original same-run canonical/code/SSA and requires `Some`.
- Four physical-row mutations (ordinal, start, end, handler BCI) pass the altered `ExceptionHandlerFact` slice into a freshly constructed `Walker`, then call that same facts gate directly and require an ordinary `None`. This tests agreement between the canonical row and the physical row presented to the gate; it is not claimed to be a modified JVM class.
- Pre-cancelled and zero-millisecond deadline budgets call the facts gate directly, assert the exact stop kind, zero analysis steps for cancellation, and equality with the full initial Reader checkpoint. The existing candidate test still covers late `AnalysisSteps` refusal and full checkpoint restoration after `prefixed_exceptional_retry_loop` begins its transactional candidate attempt.

## Explicit gaps and boundary

This v3 does not claim coverage for extra canonical entry/exit edges or a jsr clone. The reader-published `CanonicalCfg` and `NormalFlowView` are immutable through the public API available in this crate; there is no legitimate way for this test module to inject those graph rows. The available complete negative fixtures cover an effectful normal-join bridge and a catch returning to the outer loop, not extra entry/exit or clone. As requested, the next private v4 should extract only the existing edge-closure predicate into a private budgeted row-policy helper used by production, then test true original canonical rows plus one-at-a-time extra entry, extra exit, clone identity, and wrong exception ordinal. Those metamorphisms must be described as policy tests over same-run rows, never as valid whole-class or JVM inputs.

No Rust test, compiler, or toolchain was run. The reader construction helper and added test code remain uncompiled.
