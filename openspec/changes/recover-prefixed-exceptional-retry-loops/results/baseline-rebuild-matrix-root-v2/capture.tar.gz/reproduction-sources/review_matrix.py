#!/usr/bin/env python3
"""Independent read-only acceptance audit for the TestNestedLoops3 rebuild matrix."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
EXPECTED_COMPARE_SHA = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
EXPECTED_METHODS = {
    ('<init>', '()V'), ('test', '(I)I'), ('exc', '()V'),
    ('f1', '()V'), ('f2', '()V'), ('check', '()V'),
}
EXPECTED_CLASS = 'jadx/tests/integration/loops/TestNestedLoops3$TestCls'


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def tree_pin(root: Path) -> dict:
    return {p.relative_to(root).as_posix(): pin(p)
            for p in sorted(root.rglob('*')) if p.is_file()}


def artifact_bytes(row: dict, stream: str) -> bytes:
    item = row['streams'][stream]
    path = Path(item['path'])
    data = path.read_bytes()
    if len(data) != item['bytes'] or sha(path) != item['sha256']:
        raise AssertionError(f"raw {stream} pin mismatch for command {row.get('index')}: {path}")
    return data


def load_compare(root: Path):
    path = root / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
    if sha(path) != EXPECTED_COMPARE_SHA:
        raise AssertionError('pinned classfile reader changed')
    spec = importlib.util.spec_from_file_location('nestedloops3_review_compare', path)
    if spec is None or spec.loader is None:
        raise AssertionError(f'cannot load pinned classfile reader: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, pin(path)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--execution', type=Path, default=Path('/private/tmp/jarde-nestedloops3-rebuild-matrix-root-v2-20261018/execution.json'))
    ap.add_argument('--baseline', type=Path, default=Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018/execution.json'))
    ap.add_argument('--root', type=Path, default=Path('/Users/lordcasser/workspace/projects/jarde'))
    ap.add_argument('--out', type=Path, default=Path('/private/tmp/jarde-nestedloops3-rebuild-matrix-review-luna-v1-20261018/review.json'))
    args = ap.parse_args()
    execution_path, baseline_path, root = args.execution.resolve(), args.baseline.resolve(), args.root.resolve()
    d = json.loads(execution_path.read_text(encoding='utf-8'))
    baseline = json.loads(baseline_path.read_text(encoding='utf-8'))
    out_root = execution_path.parent
    checks = []
    failure_rows = []
    successes = []
    compare, compare_pin = load_compare(root)

    def check(condition: bool, label: str, details=None):
        if not condition:
            raise AssertionError(f'{label}: {details!r}')
        checks.append(label)

    check(d.get('schema') == 'cf11-nestedloops3-complete-source-rebuild-matrix-v2', 'v2 schema')
    check(d.get('status') == 'captured; compile/runtime outcomes require independent review', 'terminal collector state', d.get('status'))
    check(d.get('target_absent') is True, 'collector target-absent receipt')
    check(not (root / 'target').exists(), 'repository target remains absent')
    check(d.get('source_before') == d.get('source_after') and d.get('source_unchanged') is True,
          'source closure unchanged during capture')
    # The source tree may be under a separately reported temporary probe now; only the
    # collector's own before/after equality is used here, not present-day workspace bytes.
    check(d.get('reference_inputs_unchanged') is True, 'reference inputs unchanged receipt')
    check(d.get('compare_helper') == compare_pin, 'compare helper pin')

    baseline_pin = pin(baseline_path)
    check(d.get('baseline_receipt') == baseline_pin, 'baseline receipt pin')
    check(baseline.get('schema') == 'cf11-original-nestedloops3-baseline-v1', 'baseline schema')
    oracle_pin = d['baseline_oracle']
    oracle_path = Path(oracle_pin['path'])
    check(pin(oracle_path) == oracle_pin, 'seven-row original oracle pin')
    oracle = oracle_path.read_bytes()
    check(len(oracle.splitlines()) == 7 and hashlib.sha256(oracle).hexdigest() == d['baseline_oracle_sha256'],
          'oracle shape and digest')
    check(d['driver_source'] == baseline['driver'], 'driver source is bound to baseline')
    driver_source = Path(d['driver_source']['path'])
    check(pin(driver_source) == d['driver_source'], 'original driver source pin')
    driver_text = driver_source.read_text(encoding='utf-8')
    check('getProtectionDomain()' in driver_text and 'getCodeSource()' in driver_text and
          'expectedRoot' in driver_text and 'target loaded from' in driver_text,
          'driver enforces target CodeSource')
    check(d.get('driver_source_copy') is not None and pin(Path(d['driver_source_copy']['path'])) == d['driver_source_copy'],
          'isolated driver source copy pin')
    check(d.get('driver_source_copy_after') == d.get('driver_source_copy'), 'driver source copy unchanged')

    runtime_bound = d['runtime_timeout_wrapper']
    runtime_bound_path = Path(runtime_bound['path'])
    check(pin(runtime_bound_path) == runtime_bound, 'receipt-path runtime wrapper pin')
    internal_wrapper = d['runtime_timeout_wrapper_internal_copy']
    check(Path(internal_wrapper['path']).read_bytes() == runtime_bound_path.read_bytes(),
          'internal runtime wrapper byte-identical to receipt path')
    check(internal_wrapper['bytes'] == runtime_bound['bytes'] and internal_wrapper['sha256'] == runtime_bound['sha256'],
          'runtime wrapper internal copy digest parity')

    command_rows = d.get('commands', [])
    check(len(command_rows) == 37, '37 total guarded commands', len(command_rows))
    commands = {row['index']: row for row in command_rows}
    check(len(commands) == len(command_rows) and sorted(commands) == list(range(1, 38)), 'unique sequential command indexes')
    for row in command_rows:
        check(row.get('guard_stop') is None, f"command {row['index']} did not hit root guard")
        for stream in ('stdout', 'stderr'):
            raw = artifact_bytes(row, stream)
            raw_path = Path(row['streams'][stream]['path']).resolve()
            check(raw_path.is_relative_to((out_root / 'raw').resolve()),
                  f"command {row['index']} {stream} retained under this receipt", str(raw_path))
        check(row.get('exit_code') is not None, f"command {row['index']} has exit status")

    # Source/report/compile-copy inventory: 8 Jarde + 4 JADX inputs and 8 Jarde reports.
    source_inputs = d.get('source_inputs', [])
    check(len(source_inputs) == 12, '12 complete source cells')
    check(sum(x['kind'] == 'jarde' for x in source_inputs) == 8, 'eight Jarde source cells')
    check(sum(x['kind'] == 'jadx' for x in source_inputs) == 4, 'four JADX source cells')
    check(sum(x.get('original_report_pin') is not None for x in source_inputs) == 8, 'eight Jarde reports')
    for label in ('source_artifacts_before', 'source_artifacts_after'):
        inventory = d.get(label, [])
        check(len(inventory) == 32, f'{label}: 12 source + 8 report + 12 compile-copy pins', len(inventory))
        for entry in inventory:
            check(pin(Path(entry['pin']['path'])) == entry['pin'], f"{label} actual pin {entry['role']} {entry['form']}")
    check(d['source_artifacts_before'] == d['source_artifacts_after'], 'all source/report/copy pins stable')
    for item in source_inputs:
        src = item['original_source_pin']
        compile_copy = item['compile_source']
        check(pin(Path(src['path'])) == src, f"original source pin {src['path']}")
        check(pin(Path(compile_copy['path'])) == compile_copy, f"compile copy pin {compile_copy['path']}")
        check(Path(src['path']).read_bytes() == Path(compile_copy['path']).read_bytes(),
              f"source copied verbatim {item['kind']}/{item['profile']}/{item['form']}/{item['evidence']}")
        report = item.get('original_report_pin')
        if report:
            check(pin(Path(report['path'])) == report, f"Jarde report pin {report['path']}")
            check(json.loads(Path(report['path']).read_text(encoding='utf-8'))['text'] == Path(src['path']).read_text(encoding='utf-8'),
                  f"Jarde source/report text parity {item['profile']}/{item['form']}/{item['evidence']}")

    expected = set()
    for profile in ('debug', 'no-debug'):
        for form in ('child', 'bundle-child'):
            for evidence in ('default', 'all'):
                for compiler in ('javac8', 'javac23'):
                    expected.add(('jarde', profile, form, evidence, compiler))
        for form in ('child', 'bundle'):
            for compiler in ('javac8', 'javac23'):
                expected.add(('jadx', profile, form, 'source', compiler))
    cells = d.get('compilation_cells', [])
    got = {(c['kind'], c['profile'], c['form'], c['evidence'], c['compiler']) for c in cells}
    check(len(cells) == 24 and got == expected, 'exact 24 compiler/profile/source cells', sorted(got ^ expected))
    check(len(got) == 24, 'no duplicate compiler cells')
    check(d.get('driver_compile', {}).get('exit_code') == 0, 'independent Java 8 driver compiled')
    driver_command = commands[d['driver_compile']['command']]
    check(driver_command['label'] == 'compile-independent-driver-javac8' and driver_command['tool_leg'] == 'javac8',
          'driver compile command binding')
    driver_tree = d['driver_compile']['classes_tree_after_compile']
    driver_classes = Path(d['driver_compile']['classes'][0]['path']).parent
    check(tree_pin(driver_classes) == driver_tree, 'driver classes tree after compile')
    check(d.get('driver_classes_tree_after_matrix') == driver_tree, 'driver classes tree unchanged after all runtimes')

    for cell in cells:
        key = (cell['kind'], cell['profile'], cell['form'], cell['evidence'], cell['compiler'])
        compile_command = commands[cell['command']]
        expected_label = f"compile-{cell['kind']}-{cell['profile']}-{cell['form']}-{cell['evidence']}-{cell['compiler']}"
        check(compile_command['label'] == expected_label and compile_command['tool_leg'] == cell['compiler'],
              f'compile command binding {key}')
        check(compile_command['exit_code'] == cell['exit_code'], f'compile exit parity {key}')
        stderr = artifact_bytes(compile_command, 'stderr')
        target_path = Path(cell['target_class_expected'])
        if cell['status'] == 'compile_failed_no_runtime':
            check(cell['exit_code'] != 0 and cell.get('target_class') is None and not cell['runtime'],
                  f'failed compile has no target/runtime {key}')
            check(not target_path.exists(), f'failed compile target absent {key}')
            failure_class = 'other_compile_failure'
            if cell['kind'] == 'jarde' and ('缺少返回语句'.encode('utf-8') in stderr or b'missing return statement' in stderr):
                failure_class = 'expected_jarde_missing_return'
            elif (cell['kind'], cell['form'], cell['compiler']) == ('jadx', 'bundle', 'javac8') and b'55.0' in stderr and b'52.0' in stderr:
                failure_class = 'javac8_major55_harness_boundary'
            failure_rows.append({'cell': list(key), 'command': cell['command'], 'class': failure_class,
                                 'stderr': compile_command['streams']['stderr']})
        elif cell['status'] == 'compiled_target_present':
            check(cell['exit_code'] == 0 and target_path.is_file(), f'compiled target exists {key}')
            check(cell.get('target_class') == pin(target_path), f'target class file pin {key}')
            actual_facts = compare.parse_class(target_path)
            check(json.loads(json.dumps(actual_facts)) == cell['target_facts'],
                  f'actual parsed target facts equal receipt {key}')
            check(actual_facts['class_name'] == EXPECTED_CLASS, f'target binary name {key}')
            check(actual_facts['major'] == 52 and cell.get('classfile_major_is_java8') is True, f'target class major 52 {key}')
            methods = {(m['name'], m['descriptor']) for m in actual_facts['methods']}
            check(methods == EXPECTED_METHODS and cell.get('declared_methods_match_expected') is True,
                  f'complete six-method target shape {key}', sorted(methods ^ EXPECTED_METHODS))
            before_tree = cell.get('target_classes_tree_before_runtime')
            classes_root = Path(cell['target_classes_root'])
            check(before_tree is not None and tree_pin(classes_root) == before_tree,
                  f'classes tree pin before runtimes {key}')
            after_tree = cell.get('target_classes_tree_after_runtimes')
            check(after_tree == before_tree and tree_pin(classes_root) == after_tree,
                  f'classes tree pin after all runtimes {key}')
            successes.append(cell)
        else:
            raise AssertionError(f'unrecognized compilation state for {key}: {cell["status"]}')

    expected_jarde_failures = 16
    check(sum(x['class'] == 'expected_jarde_missing_return' for x in failure_rows) == expected_jarde_failures,
          'all 16 Jarde source compiles retain missing-return failure')
    check(sum(x['class'] == 'javac8_major55_harness_boundary' for x in failure_rows) == 2,
          'two JADX bundle javac8 failures classified as major-55 tool boundary')
    check(len(failure_rows) == 18 and all(x['class'] != 'other_compile_failure' for x in failure_rows),
          'all 18 compile failures explained by source or compiler boundary', failure_rows)
    check(len(successes) == 6, 'six rebuilt target classes succeeded')

    expected_runtime_keys = set()
    for c in successes:
        for runtime in ('javac8', 'javac23'):
            expected_runtime_keys.add((c['kind'], c['profile'], c['form'], c['evidence'], c['compiler'], runtime))
    runtime_rows = d.get('runtime_rows', [])
    runtime_keys = {(x['kind'], x['profile'], x['form'], x['evidence'], x['compiler'], x['runtime']) for x in runtime_rows}
    check(len(runtime_rows) == 12 and runtime_keys == expected_runtime_keys, 'exact 12 runtime observations for successful targets')
    check(len(commands) == 1 + 24 + len(runtime_rows), '37 commands = driver compile + 24 source compiles + successful runtimes')
    for cell in successes:
        runtime_by_name = {r['runtime']: r for r in cell['runtime']}
        check(set(runtime_by_name) == {'javac8', 'javac23'}, f'both runtime legs for {cell["target_class_expected"]}')
        for runtime, rr in runtime_by_name.items():
            command = commands[rr['command']]
            check(command['label'].endswith(f"-{cell['compiler']}-on-{runtime}") and command['tool_leg'] == runtime,
                  f'runtime command bound to compiler/runtime {cell["form"]}/{cell["compiler"]}/{runtime}')
            check(command['exit_code'] == 0 and rr['exit_code'] == 0, f'runtime exit status {cell["form"]}/{runtime}')
            stdout = artifact_bytes(command, 'stdout')
            check(stdout == oracle and rr.get('oracle_equal_byte_for_byte') is True,
                  f'7-row raw runtime output equals original oracle {cell["form"]}/{runtime}')
            check(rr.get('stdout_sha256') == hashlib.sha256(oracle).hexdigest() and
                  rr.get('stdout') == oracle.decode('utf-8'), f'runtime row stdout/digest matches raw oracle {cell["form"]}/{runtime}')
            target_root = str(Path(cell['target_classes_root']))
            cp = rr['classpath_order']
            check(cp == [target_root, str(driver_classes), d['classpath_child_and_jarde'][0]],
                  f'exact three-root runtime classpath {cell["form"]}/{runtime}', cp)
            argv = command['argv']
            check('-Xverify:all' in argv and '-cp' in argv and argv[argv.index('-cp') + 1] == __import__('os').pathsep.join(cp),
                  f'JVM verification and runtime classpath argv {cell["form"]}/{runtime}')
            check(argv[-2:] == ['TestNestedLoops3Driver', target_root], f'isolated driver and target-root argv {cell["form"]}/{runtime}')
            check(rr.get('expected_root_argument') == target_root, f'CodeSource expected-root argument {cell["form"]}/{runtime}')
            # The pinned driver only prints rows after its explicit canonical CodeSource equality check.
            check('actualRoot.equals(expectedRoot)' in driver_text and 'throw new AssertionError("target loaded from "' in driver_text,
                  f'CodeSource assertion precedes observable rows {cell["form"]}/{runtime}')
            check(command.get('target_classes_tree_before_runtime') == cell['target_classes_tree_before_runtime'] and
                  command.get('target_classes_tree_after_runtime') == cell['target_classes_tree_before_runtime'],
                  f'target classes tree unchanged across this runtime {cell["form"]}/{runtime}')
            check(command.get('driver_classes_tree_before_runtime') == driver_tree and
                  command.get('driver_classes_tree_after_runtime') == driver_tree,
                  f'driver classes unchanged across this runtime {cell["form"]}/{runtime}')

    # Verify all major receipt/source/tool pins, while respecting that the workspace
    # may have a later temporary probe after this collection was captured.
    check(pin(Path(d['runner']['path'])) == d['runner'], 'collector source pin')
    check(pin(Path(d['cli']['path'])) == d['cli'], 'CLI pin')
    check(pin(Path(d['jadx']['path'])) == d['jadx'], 'JADX executable pin')
    check(pin(Path(d['jadx_jar']['path'])) == d['jadx_jar'], 'JADX jar pin')
    manifest = d['jdk_manifest']
    manifest_path = Path(manifest['path'])
    check(sha(manifest_path) == manifest['sha256'], 'JDK manifest source pin')
    for leg, tools in manifest['tools'].items():
        for name, row in tools.items():
            check(pin(Path(row['path'])) == row, f'JDK tool pin {leg}/{name}')
    inputs_after = d['inputs_after']
    check(inputs_after['baseline_receipt'] == baseline_pin, 'baseline receipt final pin')
    check(inputs_after['oracle'] == oracle_pin, 'oracle final pin')
    for key in ('cli', 'jadx', 'jadx_jar'):
        check(inputs_after[key] == d[key], f'{key} final pin')
    check(pin(Path(inputs_after['harness_jar']['path'])) == inputs_after['harness_jar'], 'harness jar final pin')
    for row in inputs_after['jar_pins']:
        check(pin(Path(row['path'])) == row, f'dependency jar final pin {row["path"]}')
    for folder, expected_pin in inputs_after['directory_pins'].items():
        actual = {p.relative_to(folder).as_posix(): pin(p)
                  for p in sorted(Path(folder).rglob('*.class')) if p.is_file()}
        check(actual == expected_pin, f'JADX dependency class directory final pin {folder}')

    review = {
        'schema': 'cf11-nestedloops3-rebuild-matrix-independent-review-v1',
        'status': 'accepted' if len(checks) > 0 else 'failed',
        'execution': pin(execution_path), 'baseline': baseline_pin,
        'counts': {'checks': len(checks), 'commands': len(commands), 'raw_streams': 2 * len(commands),
                   'source_cells': len(source_inputs), 'source_reports': 8, 'compile_cells': len(cells),
                   'successful_targets': len(successes), 'runtime_rows': len(runtime_rows),
                   'successful_runtime_cases': sum(len(r['stdout'].splitlines()) for r in runtime_rows)},
        'outcomes': {'jarde_missing_return_failures': sum(x['class'] == 'expected_jarde_missing_return' for x in failure_rows),
                     'javac8_major55_bundle_boundaries': sum(x['class'] == 'javac8_major55_harness_boundary' for x in failure_rows),
                     'other_compile_failures': sum(x['class'] == 'other_compile_failure' for x in failure_rows),
                     'all_successful_runtime_rows_match_original_oracle': True},
        'compile_failures': failure_rows,
        'successful_cells': [{k: c[k] for k in ('kind','profile','form','evidence','compiler','target_class','target_facts','target_classes_tree_before_runtime','target_classes_tree_after_runtimes','runtime')} for c in successes],
        'checks': checks,
        'limitations': [
            'This audit verifies runtime results and pins; it does not establish source-map or BCI provenance.',
            'The repository source closure is compared only between the collector’s own before/after snapshots. The current workspace may contain a later temporary probe and is not compared against the historical snapshot.',
            'CodeSource success is evidenced by the pinned driver’s canonical-root assertion and by its rows appearing in successful raw output; JVM execution itself is represented by the guarded command receipt.'
        ]
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': review['status'], 'counts': review['counts'], 'out': str(args.out)}, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
