#!/usr/bin/env python3
"""Root-run candidate: compile extracted complete TestNestedLoops3 sources without repairing them."""
from __future__ import annotations
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASELINE_DEFAULT = Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018')
OUT_DEFAULT = Path('/private/tmp/jarde-nestedloops3-rebuild-matrix-root-v2-20261018')
COMPARE_REL = Path('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
EXPECTED_COMPARE_SHA = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
EXPECTED_BASELINE_SCHEMA = 'cf11-original-nestedloops3-baseline-v1'
EXPECTED_METHODS = {('<init>', '()V'), ('test', '(I)I'), ('exc', '()V'),
                    ('f1', '()V'), ('f2', '()V'), ('check', '()V')}
EXPECTED_TARGET_REL = Path('jadx/tests/integration/loops/TestNestedLoops3$TestCls.class')
TARGET_BINARY = 'jadx.tests.integration.loops.TestNestedLoops3$TestCls'
JDK_LEGS = ('javac8', 'javac23')
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def directory_pin(root: Path, compare_module) -> dict:
    return {p.relative_to(root).as_posix(): compare_module.pin(p)
            for p in sorted(root.rglob('*.class')) if p.is_file()}


def file_tree_pin(root: Path, compare_module) -> dict:
    """Pin every regular file in an output tree, including non-class side products."""
    return {p.relative_to(root).as_posix(): compare_module.pin(p)
            for p in sorted(root.rglob('*')) if p.is_file()}


def source_artifact_pins(source_inputs: list[dict], compare_module) -> list[dict]:
    pins = []
    for item in source_inputs:
        for role, pin in (('original_source', item['original_source_pin']),
                          ('original_report', item.get('original_report_pin')),
                          ('compile_source_copy', item['compile_source'])):
            if pin is not None:
                pins.append({'kind': item['kind'], 'profile': item['profile'],
                             'form': item['form'], 'evidence': item['evidence'],
                             'role': role, 'pin': compare_module.pin(Path(pin['path']))})
    return pins


def source_filename(form: str) -> str:
    if form in ('child', 'bundle-child'):
        return 'TestNestedLoops3$TestCls.java'
    if form == 'bundle':
        return 'TestNestedLoops3.java'
    raise RuntimeError(f'unexpected source form {form!r}')


def source_output_path(root: Path, filename: str) -> Path:
    return root / 'jadx/tests/integration/loops' / filename


def target_path(classes: Path) -> Path:
    return classes / EXPECTED_TARGET_REL


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=ROOT)
    ap.add_argument('--baseline', type=Path, default=BASELINE_DEFAULT)
    ap.add_argument('--out', type=Path, default=OUT_DEFAULT)
    args = ap.parse_args()
    root, baseline, out = args.root.resolve(), args.baseline.resolve(), args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing existing output directory: {out}')
    out.mkdir(parents=True)
    (out / 'raw').mkdir()
    compare_path = root / COMPARE_REL
    import hashlib
    if hashlib.sha256(compare_path.read_bytes()).hexdigest() != EXPECTED_COMPARE_SHA:
        raise SystemExit('compare.py pin mismatch')
    COMPARE = load_module(compare_path, 'nestedloops3_matrix_compare')
    guard_path = root / COMPARE.GUARD_REL
    scanner_path = root / COMPARE.SCANNER_REL
    GUARD = load_module(guard_path, 'nestedloops3_matrix_guard')
    SCANNER = load_module(scanner_path, 'nestedloops3_matrix_scanner')
    if COMPARE.sha(guard_path) != COMPARE.GUARD_SHA256 or COMPARE.sha(scanner_path) != COMPARE.SCANNER_SHA256:
        raise SystemExit('root guard/scanner source pin mismatch')
    GUARD.ROOT = root
    GUARD.OUT = out / 'raw'
    GUARD.target_bytes = lambda: SCANNER.target_bytes(root)
    GUARD.command_stream = COMPARE.pin
    GUARD.expected_test_summaries = lambda index, b: None
    jdks, jdk_record = COMPARE.configured_jdks(
        root / COMPARE.DEFAULT_JDK_MANIFEST_REL, COMPARE.DEFAULT_JDK_MANIFEST_SHA256)
    baseline_receipt_path = baseline / 'execution.json'
    baseline_receipt = json.loads(baseline_receipt_path.read_text(encoding='utf-8'))
    if baseline_receipt.get('schema') != EXPECTED_BASELINE_SCHEMA:
        raise SystemExit(f'unexpected baseline schema {baseline_receipt.get("schema")!r}')
    if baseline_receipt.get('status') != 'captured pending independent whole-source rebuild review':
        raise SystemExit(f'unexpected baseline status {baseline_receipt.get("status")!r}')
    if baseline_receipt.get('target_absent') is not True:
        raise SystemExit('baseline receipt does not confirm target absent')
    if len(baseline_receipt.get('commands', [])) != 24:
        raise SystemExit('baseline receipt does not contain the expected 24 original-source/oracle commands')
    baseline_commands = {row['index']: row for row in baseline_receipt['commands']}
    if len(baseline_commands) != len(baseline_receipt['commands']):
        raise SystemExit('baseline receipt has duplicate command indexes')
    for row in baseline_commands.values():
        if row.get('guard_stop') is not None:
            raise SystemExit(f"baseline command {row['index']} has a root guard stop")
        COMPARE.command_artifact(row, 'stdout')
        COMPARE.command_artifact(row, 'stderr')
    boundary = baseline_receipt.get('javac8_boundary') or {}
    if boundary.get('exit_code') == 0:
        raise SystemExit('baseline javac8/harness-major boundary did not record its expected failure')
    boundary_command = baseline_commands.get(boundary.get('command'))
    if boundary_command is None or b'55.0' not in COMPARE.command_artifact(boundary_command, 'stderr'):
        raise SystemExit('baseline javac8 boundary stderr does not identify classfile major 55')
    if (root / 'target').exists():
        raise SystemExit('repository target exists before run')
    if shutil.disk_usage(root).free < 5 * 1024**3:
        raise SystemExit('root free-space guard below 5 GiB')

    # Pin all inputs against the already-completed baseline receipt; the TF3 receipt is dependency-only.
    baseline_pin = COMPARE.pin(baseline_receipt_path)
    source_pin = baseline_receipt['source']
    source_copy_pin = baseline_receipt['source_copy']
    driver_pin = baseline_receipt['driver']
    oracle_pin = baseline_receipt['oracle']
    source_path = Path(source_pin['path'])
    source_copy_path = Path(source_copy_pin['path'])
    driver_source_path = Path(driver_pin['path'])
    oracle_path = Path(oracle_pin['path'])
    if COMPARE.pin(source_path) != source_pin or COMPARE.pin(source_copy_path) != source_copy_pin:
        raise SystemExit('original or frozen source differs from its baseline pin')
    if COMPARE.pin(driver_source_path) != driver_pin or COMPARE.pin(oracle_path) != oracle_pin:
        raise SystemExit('driver or original oracle differs from its baseline pin')
    oracle_bytes = oracle_path.read_bytes()
    if len(oracle_bytes.splitlines()) != 7:
        raise SystemExit('baseline oracle is not the recorded seven-row output')
    oracle_sha = hashlib.sha256(oracle_bytes).hexdigest()
    original_runtime = baseline_receipt.get('original_runtime', [])
    if len(original_runtime) != 4:
        raise SystemExit('baseline does not contain the four original JVM observations')
    for runtime_row in original_runtime:
        command = baseline_commands.get(runtime_row.get('command'))
        if command is None or runtime_row.get('exit_code') != 0 or command.get('exit_code') != 0:
            raise SystemExit('an original JVM oracle command did not complete successfully')
        output = COMPARE.command_artifact(command, 'stdout')
        if output != oracle_bytes or runtime_row.get('oracle_sha256') != oracle_sha:
            raise SystemExit('the four original JVM observations do not all match the frozen oracle')
    wrong_root = baseline_commands.get(baseline_receipt.get('wrong_root_control_command'))
    if wrong_root is None or wrong_root.get('exit_code') == 0 or b'target loaded from' not in COMPARE.command_artifact(wrong_root, 'stderr'):
        raise SystemExit('baseline wrong-root control did not demonstrate target CodeSource rejection')
    ref_path = Path(baseline_receipt['dependency_reference']['path'])
    tf3_ref = json.loads(ref_path.read_text(encoding='utf-8'))
    if tf3_ref.get('source', {}).get('path', '').endswith('TestNestedLoops3.java'):
        raise SystemExit('TF3 dependency receipt unexpectedly claims this source')
    if COMPARE.pin(ref_path) != baseline_receipt['dependency_reference']:
        raise SystemExit('TF3 dependency receipt pin changed')
    for row in [baseline_receipt['harness_jar'], *baseline_receipt['jar_pins']]:
        if COMPARE.pin(Path(row['path'])) != row:
            raise SystemExit(f'classpath jar pin changed: {row["path"]}')
    for folder, expected in baseline_receipt['directory_pins_before'].items():
        if directory_pin(Path(folder), COMPARE) != expected:
            raise SystemExit(f'JADX dependency directory pin changed: {folder}')
    cli_pin = baseline_receipt.get('cli')
    jadx_pin = baseline_receipt.get('jadx')
    jadx_jar_pin = baseline_receipt.get('jadx_jar')
    for label, row in (('CLI', cli_pin), ('JADX executable', jadx_pin), ('JADX jar', jadx_jar_pin)):
        if not isinstance(row, dict) or COMPARE.pin(Path(row['path'])) != row:
            raise SystemExit(f'{label} input differs from baseline pin')
    compile_cp_full = list(baseline_receipt['classpath'])
    assertj = next(Path(p) for p in compile_cp_full if Path(p).name.startswith('assertj-core-'))
    runtime_cp_extra = [str(assertj)]
    target_resource = 'jadx/tests/integration/loops/TestNestedLoops3$TestCls.class'
    owner_resource = 'jadx/tests/integration/loops/TestNestedLoops3.class'
    harness_jar = Path(baseline_receipt['harness_jar']['path'])
    with zipfile.ZipFile(harness_jar) as archive:
        if any(name in archive.namelist() for name in (target_resource, owner_resource)):
            raise SystemExit('harness jar already contains this original target/owner')
    for folder in baseline_receipt['directory_pins_before']:
        base = Path(folder)
        if (base / target_resource).exists() or (base / owner_resource).exists():
            raise SystemExit(f'JADX classpath directory contains this target/owner: {base}')

    source_before = COMPARE.source_closure(root)
    runner_pin = COMPARE.pin(Path(__file__))
    runtime_bound_pin = baseline_receipt.get('runtime_bound')
    if not isinstance(runtime_bound_pin, dict) or not isinstance(runtime_bound_pin.get('path'), str):
        raise SystemExit('baseline receipt has no pinned runtime timeout wrapper path')
    runtime_bound = Path(runtime_bound_pin['path'])
    if COMPARE.pin(runtime_bound) != runtime_bound_pin:
        raise SystemExit('runtime timeout wrapper at the receipt path differs from its pin')
    runtime_bound_copy = baseline / 'jarde-nestedloops3-runtime-bound-root-v1-20261018.py'
    if not runtime_bound_copy.is_file():
        raise SystemExit('baseline internal timeout-wrapper copy is missing')
    internal_wrapper_pin = COMPARE.pin(runtime_bound_copy)
    if (internal_wrapper_pin['bytes'] != runtime_bound_pin['bytes'] or
            internal_wrapper_pin['sha256'] != runtime_bound_pin['sha256']):
        raise SystemExit('baseline internal timeout-wrapper copy bytes differ from receipt wrapper')
    original_cells = []
    for row in baseline_receipt.get('jarde_cells', []):
        need_source(row, 'jarde')
        original_cells.append({**row, 'kind': 'jarde'})
    for row in baseline_receipt.get('jadx_cells', []):
        need_source(row, 'jadx')
        original_cells.append({**row, 'kind': 'jadx'})
    if len([c for c in original_cells if c['kind'] == 'jarde']) != 8:
        raise SystemExit('baseline does not contain exactly eight Jarde presentation cells')
    if len([c for c in original_cells if c['kind'] == 'jadx']) != 4:
        raise SystemExit('baseline does not contain exactly four JADX source cells')

    source_inputs = []
    for cell in original_cells:
        profile = cell['profile']
        form = cell['form']
        evidence = cell.get('evidence') if cell['kind'] == 'jarde' else 'source'
        filename = source_filename(form)
        report_pin = None
        if cell['kind'] == 'jarde':
            if cell.get('exit_code') != 0 or not cell.get('source'):
                raise SystemExit(f'Jarde source report missing for {profile}/{form}/{evidence}')
            src_pin = cell['source']
            source_file = Path(src_pin['path'])
            if COMPARE.pin(source_file) != src_pin:
                raise SystemExit(f'Jarde complete source pin changed: {source_file}')
            report_pin = cell.get('report')
            if not report_pin or COMPARE.pin(Path(report_pin['path'])) != report_pin:
                raise SystemExit(f'Jarde report pin missing or changed: {profile}/{form}/{evidence}')
            doc = json.loads(Path(report_pin['path']).read_text(encoding='utf-8'))
            if doc.get('text') != source_file.read_text(encoding='utf-8'):
                raise SystemExit(f'Jarde saved source does not match exact report text: {profile}/{form}/{evidence}')
        else:
            rows = cell.get('sources') or []
            if len(rows) != 1:
                raise SystemExit(f'expected one complete JADX source file, got {len(rows)} for {profile}/{form}')
            src_pin = rows[0]
            source_file = Path(src_pin['path'])
            if COMPARE.pin(source_file) != src_pin:
                raise SystemExit(f'JADX source pin changed: {source_file}')
        source_bytes = source_file.read_bytes()
        cell_root = out / 'input-sources' / cell['kind'] / profile / form / str(evidence)
        compile_source = source_output_path(cell_root, filename)
        compile_source.parent.mkdir(parents=True, exist_ok=True)
        compile_source.write_bytes(source_bytes)
        source_inputs.append({
            'kind': cell['kind'], 'profile': profile, 'form': form, 'evidence': evidence,
            'original_source_pin': src_pin, 'original_report_pin': report_pin,
            'compile_source': COMPARE.pin(compile_source),
            'source_file_name_preserved_for_public_type': filename,
            'class_path': [str(assertj)] if cell['kind'] == 'jarde' or form in ('child', 'bundle-child') else compile_cp_full,
        })

    # Fresh independent driver output; no source/classes from a baseline target are reused.
    driver_copy = out / 'driver-source' / 'TestNestedLoops3Driver.java'
    driver_copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(driver_source_path, driver_copy)
    if COMPARE.pin(driver_copy)['sha256'] != driver_pin['sha256']:
        raise SystemExit('independent driver copy differs from baseline source')
    driver_copy_pin = COMPARE.pin(driver_copy)
    driver_classes = out / 'driver-classes'
    driver_classes.mkdir()
    empty_driver = out / 'empty-sourcepath-driver'
    empty_driver.mkdir()

    inputs_before = source_artifact_pins(source_inputs, COMPARE)
    rows = []
    report = {
        'schema': 'cf11-nestedloops3-complete-source-rebuild-matrix-v2', 'status': 'running',
        'root': str(root), 'baseline_receipt': baseline_pin,
        'compare_helper': COMPARE.pin(compare_path), 'cli': cli_pin, 'jadx': jadx_pin, 'jadx_jar': jadx_jar_pin,
        'runner': runner_pin,
        'baseline_oracle': oracle_pin, 'baseline_oracle_sha256': oracle_sha,
        'original_source': source_pin,
        'driver_source': driver_pin, 'runtime_timeout_wrapper': runtime_bound_pin,
        'jdk_manifest': jdk_record, 'guard': COMPARE.pin(guard_path), 'scanner': COMPARE.pin(scanner_path),
        'classpath_full_bundle': compile_cp_full,
        'classpath_child_and_jarde': runtime_cp_extra,
        'source_before': source_before, 'source_inputs': source_inputs,
        'source_artifacts_before': inputs_before,
        'driver_source_copy': driver_copy_pin,
        'runtime_timeout_wrapper_internal_copy': internal_wrapper_pin,
        'commands': rows, 'driver_compile': None, 'compilation_cells': [], 'runtime_rows': [],
        'notes': [
            'Jarde inputs are the exact eight CLI source texts: 2 profiles × child/bundle-child × default/all. Each is independently compiled with javac8 and javac23; no presentation marker or missing body is repaired.',
            'JADX inputs are the exact four complete source files: 2 profiles × child/bundle. Each is independently compiled with javac8 and javac23.',
            'The original runtime oracle is the seven-line output from the complete original source and independent driver receipt; it is byte-compared only after successful compilation.',
            'Bundle javac8 failures caused by classfile-major-55 harness dependencies are retained as observed compile failures; no runtime row is created for failed compilation.',
            'No default/all source-map or non-target stability conclusion is made by this compiler/runtime collector; those remain separate acceptance checks.'
        ]
    }

    def save():
        COMPARE.write_json(out / 'execution.json', report)

    def run_cmd(label, argv, leg):
        if (root / 'target').exists():
            raise RuntimeError('repository target appeared before command')
        env = {k: v for k, v in os.environ.items() if k not in ENV_STRIP}
        env = COMPARE.clean_env(env, jdks[leg])
        env.update(GUARD.ENV_VALUES)
        env.pop('RUST_MIN_STACK', None)
        row = GUARD.run_command(len(rows) + 1, [str(x) for x in argv], env)
        row['label'] = label
        row['tool_leg'] = leg
        rows.append(row)
        save()
        if row.get('guard_stop') is not None:
            raise RuntimeError(f'root guard stopped {label}: {row["guard_stop"]}')
        return row

    driver_classes_after_compile = None
    active_target_tree_pin = None

    def run_runtime(label, target_classes, runtime):
        target_before = file_tree_pin(target_classes, COMPARE)
        driver_before = file_tree_pin(driver_classes, COMPARE)
        if target_before != active_target_tree_pin:
            raise RuntimeError(f'target classes changed before runtime: {target_classes}')
        if driver_before != driver_classes_after_compile:
            raise RuntimeError('independent driver classes changed before runtime')
        cp = os.pathsep.join([str(target_classes), str(driver_classes), *runtime_cp_extra])
        java = jdks[runtime]['tools']['java']
        argv = [sys.executable, '-B', str(runtime_bound), '30', str(java), '-Xverify:all',
                '-cp', cp, 'TestNestedLoops3Driver', str(target_classes)]
        row = run_cmd(label, argv, runtime)
        target_after = file_tree_pin(target_classes, COMPARE)
        driver_after = file_tree_pin(driver_classes, COMPARE)
        row['target_classes_tree_before_runtime'] = target_before
        row['target_classes_tree_after_runtime'] = target_after
        row['driver_classes_tree_before_runtime'] = driver_before
        row['driver_classes_tree_after_runtime'] = driver_after
        if target_after != active_target_tree_pin:
            raise RuntimeError(f'target classes changed during runtime: {target_classes}')
        if driver_after != driver_classes_after_compile:
            raise RuntimeError('independent driver classes changed during runtime')
        save()
        return row, [str(target_classes), str(driver_classes), *runtime_cp_extra]

    try:
        save()
        driver_compile = run_cmd('compile-independent-driver-javac8', [
            jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g:none',
            '-Xlint:-options', '-encoding', 'UTF-8', '-proc:none', '-classpath', str(empty_driver),
            '-sourcepath', str(empty_driver), '-d', str(driver_classes), str(driver_copy)
        ], 'javac8')
        report['driver_compile'] = {'command': driver_compile['index'], 'exit_code': driver_compile['exit_code'],
                                    'source': COMPARE.pin(driver_copy),
                                    'classes': [COMPARE.pin(p) for p in sorted(driver_classes.rglob('*.class'))]}
        if driver_compile['exit_code'] != 0:
            raise RuntimeError('independent driver compile failed; no source matrix can run')
        driver_classes_after_compile = file_tree_pin(driver_classes, COMPARE)
        report['driver_compile']['classes_tree_after_compile'] = driver_classes_after_compile
        save()

        compile_legs = []
        for item in source_inputs:
            cp = item['class_path']
            for leg in JDK_LEGS:
                out_classes = out / 'compiled' / item['kind'] / item['profile'] / item['form'] / str(item['evidence']) / leg / 'classes'
                out_classes.mkdir(parents=True)
                empty = out_classes.parent / 'empty-sourcepath'
                empty.mkdir()
                flags = (['-source', '8', '-target', '8', '-g:none', '-Xlint:-options', '-proc:none']
                         if leg == 'javac8' else ['--release', '8', '-g:none', '-proc:none'])
                compile_cp = os.pathsep.join(str(x) for x in cp)
                label = f"compile-{item['kind']}-{item['profile']}-{item['form']}-{item['evidence']}-{leg}"
                row = run_cmd(label, [jdks[leg]['tools']['javac'], *flags, '-encoding', 'UTF-8',
                                      '-classpath', compile_cp, '-sourcepath', str(empty), '-d', str(out_classes),
                                      item['compile_source']['path']], leg)
                status = 'compile_failed_no_runtime' if row['exit_code'] != 0 else 'compile_succeeded'
                target_class = target_path(out_classes)
                cell = {
                    'kind': item['kind'], 'profile': item['profile'], 'form': item['form'], 'evidence': item['evidence'],
                    'compiler': leg, 'source': item['compile_source'], 'classpath': cp,
                    'command': row['index'], 'exit_code': row['exit_code'], 'status': status,
                    'target_class_expected': str(target_class), 'target_class': None, 'target_facts': None,
                    'target_classes_root': str(out_classes), 'target_classes_tree_before_runtime': None,
                    'runtime': []
                }
                if row['exit_code'] == 0:
                    if not target_class.is_file():
                        cell['status'] = 'compile_succeeded_target_missing'
                    else:
                        facts = COMPARE.parse_class(target_class)
                        active_target_tree_pin = file_tree_pin(out_classes, COMPARE)
                        cell['target_class'] = COMPARE.pin(target_class)
                        cell['target_classes_tree_before_runtime'] = active_target_tree_pin
                        cell['target_facts'] = facts
                        method_set = {(m['name'], m['descriptor']) for m in facts['methods']}
                        cell['declared_methods_match_expected'] = method_set == EXPECTED_METHODS
                        cell['classfile_major_is_java8'] = facts['major'] == 52
                        cell['status'] = 'compiled_target_present'
                        for runtime in JDK_LEGS:
                            runtime_row, runtime_cp = run_runtime(
                                f"runtime-{item['kind']}-{item['profile']}-{item['form']}-{item['evidence']}-{leg}-on-{runtime}",
                                out_classes, runtime)
                            output = COMPARE.command_artifact(runtime_row, 'stdout')
                            matched = runtime_row['exit_code'] == 0 and output == oracle_bytes
                            runtime_cell = {
                                'runtime': runtime, 'command': runtime_row['index'],
                                'exit_code': runtime_row['exit_code'], 'classpath_order': runtime_cp,
                                'expected_root_argument': str(out_classes),
                                'stdout': COMPARE.command_artifact(runtime_row, 'stdout').decode('utf-8', errors='replace'),
                                'stdout_sha256': hashlib.sha256(output).hexdigest(),
                                'oracle_equal_byte_for_byte': matched,
                                'status': 'matches_original_oracle' if matched else ('runtime_failed' if runtime_row['exit_code'] != 0 else 'oracle_mismatch')
                            }
                            cell['runtime'].append(runtime_cell)
                            report['runtime_rows'].append({
                                'kind': item['kind'], 'profile': item['profile'], 'form': item['form'],
                                'evidence': item['evidence'], 'compiler': leg, **runtime_cell
                            })
                            save()
                compile_legs.append(cell)
                report['compilation_cells'] = compile_legs
                save()
        report['source_after'] = COMPARE.source_closure(root)
        report['source_artifacts_after'] = source_artifact_pins(source_inputs, COMPARE)
        report['driver_source_copy_after'] = COMPARE.pin(driver_copy)
        report['driver_classes_tree_after_matrix'] = file_tree_pin(driver_classes, COMPARE)
        for cell in report['compilation_cells']:
            if cell.get('target_classes_tree_before_runtime') is not None:
                after_tree = file_tree_pin(Path(cell['target_classes_root']), COMPARE)
                cell['target_classes_tree_after_runtimes'] = after_tree
                if after_tree != cell['target_classes_tree_before_runtime']:
                    raise RuntimeError(f"target classes changed after runtime matrix: {cell['target_classes_root']}")
        report['inputs_after'] = {
            'baseline_receipt': COMPARE.pin(baseline_receipt_path),
            'oracle': COMPARE.pin(oracle_path), 'source': COMPARE.pin(source_path),
            'source_copy': COMPARE.pin(source_copy_path), 'driver': COMPARE.pin(driver_source_path),
            'cli': COMPARE.pin(Path(cli_pin['path'])), 'jadx': COMPARE.pin(Path(jadx_pin['path'])),
            'jadx_jar': COMPARE.pin(Path(jadx_jar_pin['path'])),
            'harness_jar': COMPARE.pin(Path(baseline_receipt['harness_jar']['path'])),
            'jar_pins': [COMPARE.pin(Path(row['path'])) for row in baseline_receipt['jar_pins']],
            'directory_pins': {folder: directory_pin(Path(folder), COMPARE) for folder in baseline_receipt['directory_pins_before']}
        }
        if report['source_after'] != source_before:
            raise RuntimeError('Jarde shared source closure changed during private matrix collection')
        if report['source_artifacts_after'] != inputs_before:
            raise RuntimeError('one or more original sources, reports, or compile copies changed during collection')
        if report['driver_source_copy_after'] != driver_copy_pin:
            raise RuntimeError('independent driver source copy changed during collection')
        if file_tree_pin(driver_classes, COMPARE) != driver_classes_after_compile:
            raise RuntimeError('independent driver classes changed after compilation/runtime matrix')
        if report['inputs_after']['baseline_receipt'] != baseline_pin:
            raise RuntimeError('baseline receipt changed while matrix was collected')
        if COMPARE.pin(Path(__file__)) != runner_pin:
            raise RuntimeError('collector source changed during matrix collection')
        if report['inputs_after']['oracle'] != oracle_pin or report['inputs_after']['source'] != source_pin:
            raise RuntimeError('source/oracle input pin changed while matrix was collected')
        if report['inputs_after']['source_copy'] != source_copy_pin or report['inputs_after']['driver'] != driver_pin:
            raise RuntimeError('source copy/driver pin changed while matrix was collected')
        if report['inputs_after']['cli'] != cli_pin or report['inputs_after']['jadx'] != jadx_pin or report['inputs_after']['jadx_jar'] != jadx_jar_pin:
            raise RuntimeError('CLI/JADX executable pin changed while matrix was collected')
        if COMPARE.pin(runtime_bound) != runtime_bound_pin:
            raise RuntimeError('runtime timeout wrapper changed while matrix was collected')
        internal_after = COMPARE.pin(runtime_bound_copy)
        if (internal_after['bytes'] != runtime_bound_pin['bytes'] or
                internal_after['sha256'] != runtime_bound_pin['sha256']):
            raise RuntimeError('baseline internal timeout-wrapper copy changed or diverged')
        for row in [baseline_receipt['harness_jar'], *baseline_receipt['jar_pins']]:
            if COMPARE.pin(Path(row['path'])) != row:
                raise RuntimeError(f'dependency pin changed after run: {row["path"]}')
        for folder, expected in baseline_receipt['directory_pins_before'].items():
            if directory_pin(Path(folder), COMPARE) != expected:
                raise RuntimeError(f'JADX dependency directory changed after run: {folder}')
        report['source_unchanged'] = True
        report['reference_inputs_unchanged'] = True
        report['target_absent'] = not (root / 'target').exists()
        if not report['target_absent']:
            raise RuntimeError('repository target exists after matrix collection')
        report['status'] = 'captured; compile/runtime outcomes require independent review'
    except BaseException as exc:
        report['status'] = 'failed'
        report['error'] = f'{type(exc).__name__}: {exc}'
        raise
    finally:
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
    print(json.dumps({'status': report['status'], 'compile_cells': len(report['compilation_cells']),
                      'runtime_rows': len(report['runtime_rows']), 'output': str(out)}, sort_keys=True))
    return 0


def need_source(row: dict, kind: str) -> None:
    if kind == 'jarde' and row.get('kind') not in (None, 'jarde'):
        raise SystemExit(f'invalid Jarde cell kind {row.get("kind")!r}')
    if kind == 'jadx' and row.get('kind') not in (None, 'jadx'):
        raise SystemExit(f'invalid JADX cell kind {row.get("kind")!r}')


if __name__ == '__main__':
    raise SystemExit(main())
