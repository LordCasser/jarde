import argparse,datetime,hashlib,importlib.util,json,os,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('/Users/lordcasser/workspace/projects/jarde');B=Path('/private/tmp/jarde-prefixed-retry-originals-root-v2-20261018')
ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--api',type=Path);args=ap.parse_args();O=args.out.resolve();assert not O.exists() and not(R/'target').exists();O.mkdir();(O/'raw').mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(R/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','matrix_compare');g=load(R/c.GUARD_REL,'matrix_guard');s=load(R/c.SCANNER_REL,'matrix_scanner');assert c.sha(R/c.GUARD_REL)==c.GUARD_SHA256 and c.sha(R/c.SCANNER_REL)==c.SCANNER_SHA256
g.ROOT=R;g.OUT=O/'raw';g.target_bytes=lambda:s.target_bytes(R);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
base=json.loads((B/'execution.json').read_text());assert base['status']=='captured_pending_root_originals_and_api_review'
api_path=args.api.resolve() if args.api else B/'execution.json';api=json.loads(api_path.read_text());jdks,jdk=c.configured_jdks(R/c.DEFAULT_JDK_MANIFEST_REL,c.DEFAULT_JDK_MANIFEST_SHA256)
items=[]
for row in api['jarde_cells']:
 assert c.pin(Path(row['source']['path']))==row['source'] and c.pin(Path(row['report']['path']))==row['report'];d=json.loads(Path(row['report']['path']).read_text());assert d['text'].encode()==Path(row['source']['path']).read_bytes();items.append({'kind':'jarde',**row,'source_pin':row['source']})
for row in base['jadx_cells']:
 assert len(row['sources'])==1 and c.pin(Path(row['sources'][0]['path']))==row['sources'][0];items.append({'kind':'jadx',**row,'evidence':'source','source_pin':row['sources'][0]})
assert len(items)==24 and len(api['jarde_cells'])==16 and len(base['jadx_cells'])==8
base_inputs={(x['name'],x['compiler'],x['profile']):x for x in base['classes']}
for item in items:assert item['input']==base_inputs[(item['name'],item['compiler'],item['profile'])]['class']
expected_methods={x['name']:{(m['name'],m['descriptor'],m['access']) for m in x['facts']['methods']} for x in base['classes']}
oracles={name:Path(row['path']).read_bytes() for name,row in base['oracles'].items()}
for name,row in base['oracles'].items():assert c.pin(Path(row['path']))==row and len(oracles[name].splitlines())==10
assert c.pin(Path(base['driver_source']['path']))==base['driver_source'];driver_source=O/'driver-source/RetryFixtureDriver.java';driver_source.parent.mkdir();shutil.copyfile(base['driver_source']['path'],driver_source)
original_baseline=json.loads(Path(base['baseline_reference']['path']).read_text());wrapper=Path(original_baseline['runtime_bound']['path']);assert c.pin(wrapper)==original_baseline['runtime_bound']
classes_driver=O/'driver-classes';classes_driver.mkdir();empty=O/'empty-sourcepath';empty.mkdir()
def tree(p):return {str(x.relative_to(p)):c.pin(x) for x in sorted(p.rglob('*')) if x.is_file()}
for i,item in enumerate(items):
 src=O/'source-inputs'/str(i)/(item['name']+'.java');src.parent.mkdir(parents=True);src.write_bytes(Path(item['source_pin']['path']).read_bytes());item['compile_source']=c.pin(src)
source_inputs_before=[{'original':c.pin(Path(x['source_pin']['path'])),'copy':c.pin(Path(x['compile_source']['path']))} for x in items]
rows=[];before=c.source_closure(R);r={'schema':'prefixed-retry-supplement-whole-source-matrix-v1','status':'running','original_capture':c.pin(B/'execution.json'),'api_capture':c.pin(api_path),'runner':c.pin(Path(__file__)),'guard':c.pin(R/c.GUARD_REL),'scanner':c.pin(R/c.SCANNER_REL),'jdk':jdk,'driver_source':c.pin(driver_source),'source_before':before,'source_inputs':items,'source_input_pins_before':source_inputs_before,'commands':rows,'compile_cells':[],'runtime_cells':[],'notes':['All complete emitted sources are compiled without repair or deleting any method.','JADX text is reused by exact pin from the original capture for the same immutable input classes; no new JADX extraction is claimed.','Only rebuilt class root and independent driver root are on runtime classpath. Runtime output is byte-compared to original class oracle.']}
def save():c.write_json(O/'execution.json',r)
def run(label,argv,leg):
 env=c.clean_env(dict(os.environ),jdks[leg]);env.pop('RUST_MIN_STACK',None);env.update(g.ENV_VALUES);a=g.run_command(len(rows)+1,list(map(str,argv)),env);a['label']=label;rows.append(a);save();assert a['guard_stop'] is None;return a
try:
 a=run('compile-independent-driver',[jdks['javac8']['tools']['javac'],'-source','8','-target','8','-Xlint:-options','-g:none','-proc:none','-encoding','UTF-8','-classpath',empty,'-sourcepath',empty,'-d',classes_driver,driver_source],'javac8');assert a['exit_code']==0;r['driver_classes']=tree(classes_driver)
 for i,item in enumerate(items):
  for compiler in ('javac8','javac23'):
   classes=O/'rebuilt'/str(i)/compiler;classes.mkdir(parents=True);flags=['-source','8','-target','8','-Xlint:-options'] if compiler=='javac8' else ['--release','8'];label=f"{item['kind']}-{item['name']}-{item['compiler']}-{item['profile']}-{item['evidence']}-{compiler}"
   a=run('compile-'+label,[jdks[compiler]['tools']['javac'],*flags,'-g:none','-proc:none','-encoding','UTF-8','-classpath',empty,'-sourcepath',empty,'-d',classes,item['compile_source']['path']],compiler)
   cell={'kind':item['kind'],'name':item['name'],'input_compiler':item['compiler'],'profile':item['profile'],'evidence':item['evidence'],'compiler':compiler,'source':item['compile_source'],'command':a['index'],'exit_code':a['exit_code'],'classes_root':str(classes),'classes_after_compile':tree(classes),'runtime':[]};r['compile_cells'].append(cell);save()
   target=classes/(item['name']+'.class')
   if a['exit_code']!=0:cell['status']='compile_failed_no_runtime';continue
   if not target.is_file():cell['status']='compiled_target_missing';continue
   facts=c.parse_class(target);cell['target']=c.pin(target);cell['facts']=facts;cell['complete_method_inventory']= {(m['name'],m['descriptor'],m['access']) for m in facts['methods']}==expected_methods[item['name']];cell['major52']=facts['major']==52;cell['status']='compiled_target_present';save()
   for vm in ('javac8','javac23'):
    assert tree(classes)==cell['classes_after_compile'] and tree(classes_driver)==r['driver_classes']
    cp=os.pathsep.join(map(str,[classes,classes_driver]));a=run('runtime-'+label+'-'+vm,[sys.executable,'-B',wrapper,'30',jdks[vm]['tools']['java'],'-Xverify:all','-cp',cp,'RetryFixtureDriver',item['name'],classes],vm);output=c.command_artifact(a,'stdout')
    rr={'kind':item['kind'],'name':item['name'],'input_compiler':item['compiler'],'profile':item['profile'],'evidence':item['evidence'],'compiler':compiler,'runtime':vm,'command':a['index'],'exit_code':a['exit_code'],'runtime_classpath':[str(classes),str(classes_driver)],'oracle_equal':a['exit_code']==0 and output==oracles[item['name']],'stdout_lines':len(output.splitlines()),'stdout_sha256':hashlib.sha256(output).hexdigest()};cell['runtime'].append(rr);r['runtime_cells'].append(rr)
    assert tree(classes)==cell['classes_after_compile'] and tree(classes_driver)==r['driver_classes'];save()
   cell['classes_after_runtime']=tree(classes)
 r['source_after']=c.source_closure(R);assert r['source_after']==before
 r['source_input_pins_after']=[{'original':c.pin(Path(x['source_pin']['path'])),'copy':c.pin(Path(x['compile_source']['path']))} for x in items];assert r['source_input_pins_after']==source_inputs_before
 for item in items:
  if item['kind']=='jarde':assert c.pin(Path(item['report']['path']))==item['report']
 for cell in r['compile_cells']:assert tree(Path(cell['classes_root']))==cell['classes_after_compile']
 assert c.pin(driver_source)==r['driver_source'] and tree(classes_driver)==r['driver_classes'] and c.pin(api_path)==r['api_capture'] and c.pin(B/'execution.json')==r['original_capture'] and c.pin(Path(__file__))==r['runner']
 for name,p in base['oracles'].items():assert c.pin(Path(p['path']))==p
 assert c.pin(wrapper)==original_baseline['runtime_bound'];r['target_absent']=not(R/'target').exists();assert r['target_absent'];r['source_unchanged']=True;r['status']='captured_pending_independent_rebuild_review'
except BaseException as e:r['status']='failed';r['error']=repr(e);raise
finally:r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({'status':r['status'],'commands':len(rows),'compiles':len(r['compile_cells']),'runtime':len(r['runtime_cells']),'all_runtime_equal':all(x['oracle_equal'] for x in r['runtime_cells'])}))
