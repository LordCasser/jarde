#!/usr/bin/env python3
import hashlib, importlib.util, json, os, re, sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
CAP=Path('/private/tmp/jarde-prefixed-retry-supplement-baseline-matrix-root-v1-20261018')
ORIG=Path('/private/tmp/jarde-prefixed-retry-originals-root-v2-20261018')
BASELINE=Path('/private/tmp/jarde-prefixed-retry-originals-root-v1-20261018')
COMPARE=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
EXPECTED={
 'PrefixRetryAlpha':{('<init>','()V',1),('execute','(III)I',1),('f1','(I)V',2),('f2','(I)V',2),('protectedStep','(I)V',2),('recordCatch','(Ljava/lang/IllegalArgumentException;I)V',2),('record','(I)V',2),('bounded','(III)I',10)},
 'RetryPrefixBeta':{('<init>','()V',1),('execute','(III)I',1),('beginOuter','(I)V',2),('beginRetry','(I)V',2),('performProtected','(I)V',2),('rememberCatch','(Ljava/lang/IllegalStateException;I)V',2),('append','(I)V',2),('cap','(III)I',10)},
}
ORACLE_NAMES=['PrefixRetryAlpha','RetryPrefixBeta']

def sha(b): return hashlib.sha256(b).hexdigest()
def pin(path):
 p=Path(path); b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':sha(b)}
def need(ok,msg):
 if not ok: raise AssertionError(msg)
def load_compare():
 spec=importlib.util.spec_from_file_location('supplement_matrix_compare',COMPARE)
 mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def main():
 c=load_compare(); rec=json.loads((CAP/'execution.json').read_text())
 need(rec['schema']=='prefixed-retry-supplement-whole-source-matrix-v1','unexpected matrix schema')
 need(rec['status']=='captured_pending_independent_rebuild_review','matrix not terminal')
 need(rec['target_absent'] is True and rec['source_unchanged'] is True,'source/target invariant missing')
 need(rec['source_before']==rec['source_after'],'workspace source closure changed during matrix')
 need(c.pin(CAP/'execution.json')['path']==str((CAP/'execution.json').resolve()),'receipt path invalid')
 need(rec['original_capture']==pin(ORIG/'execution.json'),'original-source capture pin mismatch')
 need(rec['api_capture']==rec['original_capture'],'API and baseline input captures differ')
 need(rec['runner']==pin(Path(rec['runner']['path'])),'runner pin changed')
 need(rec['guard']==pin(rec['guard']['path']) and rec['scanner']==pin(rec['scanner']['path']),'guard/scanner pin mismatch')
 need(pin(rec['jdk']['path'])['sha256']==rec['jdk']['sha256'],'JDK manifest pin changed')
 for leg,tools in rec['jdk']['tools'].items():
  need(leg in ('javac8','javac23'),'unexpected JDK leg')
  for tool,entry in tools.items(): need(pin(entry['path'])['bytes']==entry['bytes'] and pin(entry['path'])['sha256']==entry['sha256'],f'JDK tool pin changed: {leg}/{tool}')
 base_receipt=json.loads((ORIG/'execution.json').read_text())
 need(base_receipt['baseline_reference']==pin(base_receipt['baseline_reference']['path']),'original runtime wrapper reference changed')
 nested=json.loads(Path(base_receipt['baseline_reference']['path']).read_text())
 wrapper=Path(nested['runtime_bound']['path']);need(pin(wrapper)==nested['runtime_bound'],'runtime guard wrapper pin mismatch')
 need(rec['source_before'].get('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')==pin(COMPARE),'pinned parser changed from captured workspace source')
 need(rec['guard']==pin(rec['guard']['path']) and rec['scanner']==pin(rec['scanner']['path']),'guard/scanner pin mismatch')
 for row in rec['commands']:
  need(row['guard_stop'] is None,f"guard stop at command {row['index']}")
  for channel,stream in row['streams'].items():
   data=Path(stream['path']).read_bytes()
   need(len(data)==stream['bytes'] and sha(data)==stream['sha256'],f'raw stream pin mismatch {row["index"]}/{channel}')
 need(pin(rec['driver_source']['path'])==rec['driver_source'],'driver source pin mismatch')
 driver_root=CAP/'driver-classes'; driver_tree={str(p.relative_to(driver_root)):pin(p) for p in sorted(driver_root.rglob('*')) if p.is_file()}
 need(driver_tree==rec['driver_classes'],'driver classes changed')
 need(set(driver_tree)=={'RetryFixtureDriver.class','RetryFixtureDriver$Observation.class'},'unexpected/incomplete isolated driver classes')
 # All 24 compilation sources are immutable copies of the exact captured class-source/JADX text.
 items=rec['source_inputs'];need(len(items)==24,'expected sixteen Jarde plus eight JADX source inputs')
 jarde=[x for x in items if x['kind']=='jarde'];jadx=[x for x in items if x['kind']=='jadx']
 need(len(jarde)==16 and len(jadx)==8,'source family matrix mismatch')
 original=json.loads((ORIG/'execution.json').read_text())
 oracles={name:Path(row['path']).read_bytes() for name,row in original['oracles'].items()}
 need(original['status']=='captured_pending_root_originals_and_api_review','original baseline was not terminal')
 original_jarde={(x['name'],x['compiler'],x['profile'],x['evidence']):x for x in original['jarde_cells']}
 original_jadx={(x['name'],x['compiler'],x['profile']):x for x in original['jadx_cells']}
 for item in items:
  source=Path(item['source_pin']['path']);copy=Path(item['compile_source']['path'])
  need(pin(source)==item['source_pin'] and pin(copy)==item['compile_source'],'source input/copy changed')
  need(source.read_bytes()==copy.read_bytes(),'compiled copy bytes differ from pinned full source')
  if item['kind']=='jarde':
   key=(item['name'],item['compiler'],item['profile'],item['evidence']); base=original_jarde[key]
   need(item['input']==base['input'] and item['source_pin']==base['source'],'Jarde source/input not from original complete report')
   need(item['report']==base['report'] and pin(item['report']['path'])==item['report'],'Jarde report/source capture pin mismatch')
   d=json.loads(Path(item['report']['path']).read_text());need(d['text'].encode('utf-8')==source.read_bytes(),'Jarde source not byte-identical to saved API report text')
  else:
   key=(item['name'],item['compiler'],item['profile']); base=original_jadx[key]
   need(item['input']==base['input'] and item['source_pin']==base['sources'][0],'JADX source/input not from original extraction')
  need(item['name'] in EXPECTED,'unexpected fixture class name')
 before=rec['source_input_pins_before']
 need(len(before)==24,'source pin ledger missing cells')
 for ix,item in enumerate(items):
  q=before[ix];need(q['original']==item['source_pin'] and q['copy']==item['compile_source'],'source before pins differ from cells')
 need(rec.get('source_input_pins_after')==before,'source input/copy pins changed after compile')
 # Compile matrix is 24 complete emitted sources by javac8/javac23, no source repair.
 cells=rec['compile_cells'];need(len(cells)==48,'expected 48 compile cells')
 labels=[x['label'] for x in rec['commands']]
 need(len(rec['commands'])==1+48+len(rec['runtime_cells']),'command count does not equal driver + compile + gated runtimes')
 need(labels.count('compile-independent-driver')==1 and sum(x.startswith('compile-') and x!='compile-independent-driver' for x in labels)==48,'compile command set mismatch')
 need(sum(x.startswith('runtime-') for x in labels)==len(rec['runtime_cells']),'runtime command set mismatch')
 need(sum(len(x['streams']) for x in rec['commands'])==162,'expected 162 captured raw streams')
 expected_keys={(i,x) for i in range(24) for x in ('javac8','javac23')}
 item_index={(x['kind'],x['name'],x['compiler'],x['profile'],x['evidence']):i for i,x in enumerate(items)}
 compiled_by_key={};failed=[];successful=[]
 command_by={x['index']:x for x in rec['commands']}
 for cell in cells:
  ik=(cell['kind'],cell['name'],cell['input_compiler'],cell['profile'],cell['evidence']);need(ik in item_index,'compile cell points to unknown source')
  ix=item_index[ik]; key=(ix,cell['compiler']);need(key in expected_keys and key not in compiled_by_key,'duplicate/missing compile lane')
  compiled_by_key[key]=cell
  src=items[ix];need(cell['source']==src['compile_source'],'compile source pin differs from selected source')
  cmd=command_by[cell['command']];argv=cmd['argv']
  label=f"compile-{src['kind']}-{src['name']}-{src['compiler']}-{src['profile']}-{src['evidence']}-{cell['compiler']}"
  need(cmd['label']==label and cmd['exit_code']==cell['exit_code'],'compile command label/status mismatch')
  need(Path(argv[0])==Path(rec['jdk']['tools'][cell['compiler']]['javac']['path']),'wrong javac executable for compiler lane')
  target_root=Path(cell['classes_root']);need(argv[argv.index('-d')+1]==str(target_root) and argv[-1]==str(src['compile_source']['path']),'compile output/source path mismatch')
  need('-proc:none' in argv and '-encoding' in argv and argv[argv.index('-encoding')+1]=='UTF-8' and '-g:none' in argv,'compile source isolation/debug flags mismatch')
  if cell['compiler']=='javac8':need(argv[1:3]==['-source','8'] and argv[3:5]==['-target','8'],'javac8 compile flags mismatch')
  else:need(argv[1:3]==['--release','8'],'javac23 compile flags mismatch')
  root_tree={str(p.relative_to(target_root)):pin(p) for p in sorted(target_root.rglob('*')) if p.is_file()}
  need(root_tree==cell['classes_after_compile'],'compile output tree changed')
  if cell['status']=='compile_failed_no_runtime':
   need(cell['exit_code']!=0 and 'target' not in cell,'failed compile published target/ran runtime')
   need(not any((x['kind'],x['name'],x['input_compiler'],x['profile'],x['evidence'],x['compiler'])==(cell['kind'],cell['name'],cell['input_compiler'],cell['profile'],cell['evidence'],cell['compiler']) for x in rec['runtime_cells']),'compile-failed source has a runtime')
   failed.append(cell)
  elif cell['status']=='compiled_target_present':
   need(cell['exit_code']==0 and 'target' in cell,'successful compile target/status mismatch')
   target=Path(cell['target']['path']);need(pin(target)==cell['target'],'rebuilt target pin mismatch')
   facts=c.parse_class(target);need(facts['major']==52 and cell['major52'],'rebuilt target is not major 52')
   method_inventory={(m['name'],m['descriptor'],m['access']) for m in facts['methods']}
   need(method_inventory==EXPECTED[src['name']] and cell['complete_method_inventory'],'rebuilt class method inventory is incomplete/changed')
   need(facts['sha256']==cell['facts']['sha256'] and facts['methods']==cell['facts']['methods'],'rebuilt class BCI/method facts differ from captured facts')
   need(cell.get('classes_after_runtime')==cell['classes_after_compile'],'runtime modified rebuilt target class tree')
   successful.append(cell)
  else:
   need(False,f"unexpected compile status {cell['status']}")
 need(compiled_by_key.keys()==expected_keys,'not all 24×2 compiler cells accounted for')
 need(len(successful)+len(failed)==48,'compile cell totals mismatch')
 # Every successful target must have both strict JVM runs; failed/missing target must have none.
 runtime=rec['runtime_cells'];need(len(runtime)==2*len(successful),'runtime count is not exactly two per compiled target')
 expected_runtime={(cell['command'],vm) for cell in successful for vm in ('javac8','javac23')}
 actual_runtime={(x.get('compile_command'),x['runtime']) for x in runtime}
 # Receipt schema does not copy compile_command onto the runtime row; bind via its unique source/compiler lane.
 runtime_by_key={}
 for rr in runtime:
  key=(rr['kind'],rr['name'],rr['input_compiler'],rr['profile'],rr['evidence'],rr['compiler'],rr['runtime'])
  need(key not in runtime_by_key,'duplicate runtime cell');runtime_by_key[key]=rr
  cell=next(x for x in successful if (x['kind'],x['name'],x['input_compiler'],x['profile'],x['evidence'],x['compiler'])==key[:6])
  cmd=command_by[rr['command']];argv=cmd['argv'];classes=Path(cell['classes_root'])
  need(Path(argv[2])==wrapper,'runtime did not use the pinned bounded wrapper')
  need(cmd['label']==f"runtime-{cell['kind']}-{cell['name']}-{cell['input_compiler']}-{cell['profile']}-{cell['evidence']}-{cell['compiler']}-{rr['runtime']}",'runtime command label mismatch')
  need(Path(argv[4])==Path(rec['jdk']['tools'][rr['runtime']]['java']['path']) and '-Xverify:all' in argv,'runtime not bound to strict pinned JVM')
  cp=argv[argv.index('-cp')+1].split(os.pathsep)
  need(cp==[str(classes),str(driver_root)] and rr['runtime_classpath']==[str(classes),str(driver_root)],'runtime classpath has ambient roots')
  need(argv[-3:]==['RetryFixtureDriver',cell['name'],str(classes)],'driver target/CodeSource argv mismatch')
  out=c.command_artifact(cmd,'stdout');need(len(out)==cmd['streams']['stdout']['bytes'],'runtime stdout capture invalid')
  need(rr['stdout_lines']==len(out.decode('utf-8','strict').splitlines()) and rr['stdout_sha256']==sha(out),'runtime output metadata mismatch')
  oracle=oracles[cell['name']]
  need(pin(original['oracles'][cell['name']]['path'])==original['oracles'][cell['name']],'original oracle pin changed')
  eq=(cmd['exit_code']==0 and out==oracle)
  need(rr['exit_code']==cmd['exit_code'] and rr['oracle_equal']==eq,'runtime outcome metadata mismatch')
  if eq: need(rr['stdout_lines']==10,'oracle-equal output is not ten complete cases')
 need(len(runtime_by_key)==2*len(successful),'successful target missing runtime configuration')
 for cell in failed:
  need(not any((x['kind'],x['name'],x['input_compiler'],x['profile'],x['evidence'],x['compiler'])==(cell['kind'],cell['name'],cell['input_compiler'],cell['profile'],cell['evidence'],cell['compiler']) for x in runtime),'compile failure improperly ran')
 # Recheck end pins and report the real failures/differences without inventing pass criteria.
 need(rec['source_after']==rec['source_before'] and rec['target_absent'] is True,'end-of-run workspace invariant failed')
 need(pin(rec['driver_source']['path'])==rec['driver_source'] and pin(CAP/'execution.json')['path']==str((CAP/'execution.json').resolve()),'final source/receipt pin mismatch')
 need(pin(rec['original_capture']['path'])==rec['original_capture'],'original capture changed')
 need(pin(ORIG/'execution.json')==rec['original_capture'],'original receipt no longer matches')
 for name,row in original['oracles'].items():need(pin(row['path'])==row,'original oracle pin changed')
 for cell in cells:
  need({str(p.relative_to(Path(cell['classes_root']))):pin(p) for p in sorted(Path(cell['classes_root']).rglob('*')) if p.is_file()}==cell['classes_after_compile'],'final compile-tree pin changed')
 for row in rec['commands']:
  need(row['guard_stop'] is None,'guard stopped during collector')
 # Summarize exact compile and runtime outcomes; preserve raw stderr/stdout as evidence.
 failure_summary=[]
 for cell in failed:
  cmd=command_by[cell['command']];stderr=c.command_artifact(cmd,'stderr').decode('utf-8','replace')
  failure_summary.append({'kind':cell['kind'],'name':cell['name'],'input_compiler':cell['input_compiler'],'profile':cell['profile'],'evidence':cell['evidence'],'rebuilt_with':cell['compiler'],'exit_code':cell['exit_code'],'stderr_sha256':sha(stderr.encode()),'stderr':stderr[:4000]})
 mismatches=[]
 for rr in runtime:
  if not rr['oracle_equal']:
   cmd=command_by[rr['command']]
   mismatches.append({'kind':rr['kind'],'name':rr['name'],'input_compiler':rr['input_compiler'],'profile':rr['profile'],'evidence':rr['evidence'],'rebuilt_with':rr['compiler'],'runtime':rr['runtime'],'exit_code':rr['exit_code'],'stdout':c.command_artifact(cmd,'stdout').decode('utf-8','replace')[:4000],'stderr':c.command_artifact(cmd,'stderr').decode('utf-8','replace')[:4000]})
 result={'status':'independent_read_only_review_passed_with_captured_failures' if failed or mismatches else 'independent_read_only_review_passed','receipt':pin(CAP/'execution.json'),'counts':{'commands':len(rec['commands']),'complete_sources':len(items),'compile_cells':len(cells),'compiled_targets':len(successful),'compile_failures_without_runtime':len(failed),'runtime_cells':len(runtime),'runtime_oracle_equal':sum(x['oracle_equal'] for x in runtime),'runtime_mismatches_or_failures':len(mismatches)},'compile_failures':failure_summary,'runtime_mismatches':mismatches,'pins':{'all_raw_streams_valid':True,'source_inputs_unchanged':True,'source_closure_unchanged_during_capture':True,'original_capture_and_oracles_unchanged':True,'target_absent':True},'limits':['This matrix compiles complete Jarde/JADX output sources only; it does not modify methods or repair source.','Only successfully compiled targets are run, and each runtime uses the isolated rebuilt class root plus the separate driver root.','A successful compile that fails strict JVM verification or differs from the original oracle is reported as a real baseline failure, not counted as a pass.']}
 path=Path(__file__).with_name('review.json');path.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps(result,indent=2,ensure_ascii=False))
if __name__=='__main__':main()
