#!/usr/bin/env python3
"""Independently accept the two final API replay receipts; performs no commands."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, re, sys, zipfile
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
INPUTS = {
    'original': Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018/execution.json'),
    'supplement': Path('/private/tmp/jarde-prefixed-retry-originals-root-v2-20261018/execution.json'),
}
COMPARE_REL = Path('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
EXPECTED_COMPARE_SHA = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'


def sha(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def pin(path: Path) -> dict:
    path=Path(path).resolve(strict=True); b=path.read_bytes(); return {'path':str(path),'bytes':len(b),'sha256':sha(b)}
def need(ok, msg):
    if not ok: raise AssertionError(msg)
def load_compare():
    p=ROOT/COMPARE_REL
    need(sha(p.read_bytes())==EXPECTED_COMPARE_SHA,'compare.py source pin changed')
    spec=importlib.util.spec_from_file_location('prefixed_retry_api_accept_compare',p)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def utf8(raw): return bytes(raw).decode('utf-8','strict')
def collect_refs(node,out):
    if isinstance(node,dict):
        if 'bci' in node and 'method' in node: out.append(node)
        for v in node.values(): collect_refs(v,out)
    elif isinstance(node,list):
        for v in node: collect_refs(v,out)
def method_key(m):
    i=m['item']['identity']; return utf8(i['name']),utf8(i['descriptor'])
def projection(m):
    r=m['outcome']['report']
    return {k:r.get(k) for k in ('text','quality','fallbacks','source_map')}
def evidence_projection(m):
    r=m['outcome']['report']
    return {k:r.get(k) for k in ('text','quality','fallbacks','source_map','syntax_status','verification','representation','content','compile_status')}
def cell_key(c,family):
    return (c['profile'],c['form'],c['evidence']) if family=='original' else (c['name'],c['compiler'],c['profile'],c['evidence'])
def target_key(family): return ('test','(I)I') if family=='original' else ('execute','(III)I')


def review_family(c, family, receipt_path):
    rec=json.loads(receipt_path.read_text(encoding='utf-8'))
    need(rec.get('family')==family and rec.get('status') in ('captured_pending_independent_api_acceptance','captured_with_incomplete_api_response'),f'{family}: wrong receipt status')
    need(rec.get('source_before')==rec.get('source_after'),f'{family}: workspace source closure changed')
    need(rec.get('input_capture')==pin(INPUTS[family]),f'{family}: wrong original input capture pin')
    need(rec.get('input_captures_after')=={n:pin(p) for n,p in INPUTS.items()},f'{family}: input receipt pins changed')
    need(rec.get('candidate_cli_after')==pin(Path(rec['cli']['path']))==rec.get('cli'),f'{family}: candidate CLI pin changed')
    need(rec.get('candidate_cli_after')==rec.get('cli'),f'{family}: candidate CLI changed')
    cells=rec['jarde_cells']; need(len(cells)==(8 if family=='original' else 16),f'{family}: wrong cell count')
    command_by={x['index']:x for x in rec['commands']}; need(len(command_by)==len(rec['commands']),'duplicate replay command index')
    need(len(command_by)==len(cells),f'{family}: replay did not execute exactly one API command per cell')
    need(pin(Path(rec['input_capture']['path']))==rec['input_capture'],f'{family}: source input receipt changed')
    base=rec['source_context']; base_commands={x['index']:x for x in base['commands']}
    need(base['jarde_cells'] and base['status'].startswith('captured'),f'{family}: source context is not a captured receipt')
    baseline_cells={cell_key(x,family):x for x in base['jarde_cells']}
    need(len(baseline_cells)==len(base['jarde_cells']),'duplicate baseline API keys')
    seen=set(); method_rows=[]; raw_count=0; map_refs=0
    for cell in cells:
        ck=cell_key(cell,family); need(ck not in seen,f'{family}: duplicate API cell {ck}');seen.add(ck)
        old=baseline_cells[ck]
        need(cell['input']==old['input'],f'{family}/{ck}: input class differs from original receipt')
        need(pin(Path(cell['input']['path']))==cell['input'],f'{family}/{ck}: original class pin changed')
        old_cmd=base_commands[cell['command'] if cell.get('replayed_from_command') is None else cell['replayed_from_command']]
        new_cmd=command_by[cell['command']]
        need(new_cmd.get('guard_stop') is None and new_cmd.get('exit_code')==0,f'{family}/{ck}: replay command failed/stopped')
        need(len(new_cmd['argv'])==len(old_cmd['argv']) and new_cmd['argv'][1:]==old_cmd['argv'][1:],f'{family}/{ck}: request args changed beyond CLI path')
        need(Path(new_cmd['argv'][0]).resolve()==Path(rec['cli']['path']).resolve(),f'{family}/{ck}: wrong replay CLI')
        for channel,stream in new_cmd['streams'].items():
            data=Path(stream['path']).read_bytes(); need(len(data)==stream['bytes'] and sha(data)==stream['sha256'],f'{family}/{ck}: raw {channel} pin invalid'); raw_count+=1
        stdout=c.command_artifact(new_cmd,'stdout')
        need(pin(Path(cell['report']['path']))==cell['report'] and Path(cell['report']['path']).read_bytes()==stdout,f'{family}/{ck}: report does not match raw stdout')
        doc=json.loads(stdout.decode('utf-8','strict'))
        source=Path(cell['source']['path']).read_bytes()
        need(pin(Path(cell['source']['path']))==cell['source'] and source==doc['text'].encode('utf-8'),f'{family}/{ck}: class source is not exact JSON text')
        old_doc=json.loads(Path(old['report']['path']).read_text(encoding='utf-8'))
        need(doc['class']==old_doc['class'],f'{family}/{ck}: physical class identity changed')
        target=target_key(family)
        need(doc['execution']['status']=='complete',f'{family}/{ck}: class analysis incomplete')
        need(len(doc['methods'])==len(old_doc['methods']),f'{family}/{ck}: full method list missing')
        class_path=Path(cell['input']['path'])
        if family=='original' and cell['form']=='bundle-child':
            target_facts=next(p['target'] for p in base['profiles'] if p['profile']==cell['profile'])
            target_path=Path(target_facts['path'])
            need(pin(target_path)=={k:target_facts[k] for k in ('path','bytes','sha256')},'physical original class pin changed')
            with zipfile.ZipFile(class_path) as archive:
                need(archive.read('jadx/tests/integration/loops/TestNestedLoops3$TestCls.class')==target_path.read_bytes(),'bundle target differs from physical original class')
            facts=c.parse_class(target_path)
        else:
            facts=c.parse_class(class_path)
        need(facts['major']==52,f'{family}/{ck}: input class is not Java 8 major 52')
        method_facts={(m['name'],m['descriptor']):m for m in facts['methods']}
        identities=[method_key(m) for m in doc['methods']]
        need(identities==[(m['name'],m['descriptor']) for m in facts['methods']],f'{family}/{ck}: method order/identity differs from physical class')
        old_identities=[method_key(m) for m in old_doc['methods']]
        need(identities==old_identities,f'{family}/{ck}: method identity/order changed from baseline API')
        by_key={method_key(m):m for m in doc['methods']}; old_by_key={method_key(m):m for m in old_doc['methods']}
        need(target in by_key,f'{family}/{ck}: target method absent')
        for index,method in enumerate(doc['methods']):
            key=method_key(method); fact=method_facts[key]; item=method['item']; identity=item['identity']; body=method['outcome']['report']
            need(item==old_by_key[key]['item'],f'{family}/{ck}/{key}: physical declaration item changed')
            need(item['index']==index and item['access_flags']==fact['access'],f'{family}/{ck}/{key}: physical index/access mismatch')
            need(identity['owner']==doc['class'] and identity['name']==item['name']['raw'] and identity['descriptor']==item['descriptor']['raw'],f'{family}/{ck}/{key}: method identity is not bound to reported class')
            need(body['artifact']['binding']['method']==identity,f'{family}/{ck}/{key}: body artifact owner differs')
            need(body['artifact']['binding']['member_ordinal']==index and body['artifact']['binding']['text_bytes']==len(body['text'].encode('utf-8')),f'{family}/{ck}/{key}: body binding ordinal/text byte count differs')
            need(body['execution']['status']=='complete' and body['outcome']=='produced' and body['representation']=='java',f'{family}/{ck}/{key}: body is not complete produced Java')
            need(method['outcome']['analysis']['execution']['status']=='complete',f'{family}/{ck}/{key}: method analysis incomplete')
            need(body['quality']=='structured' and body['content']=='contains_statements' and body['fallbacks']==[],f'{family}/{ck}/{key}: method not structured/fallback-free')
            segments=body['source_map']['segments']; need(segments,f'{family}/{ck}/{key}: source map absent')
            text_bytes=body['text'].encode('utf-8')
            for seg in segments:
                start,end=seg.get('start'),seg.get('end')
                need(isinstance(start,int) and isinstance(end,int) and 0<=start<=end<=len(text_bytes),f'{family}/{ck}/{key}: map segment outside UTF-8 source')
                need(start==len(text_bytes) or text_bytes[start]&0xc0 != 0x80,f'{family}/{ck}/{key}: source map start splits UTF-8')
                need(end==len(text_bytes) or text_bytes[end]&0xc0 != 0x80,f'{family}/{ck}/{key}: source map end splits UTF-8')
            refs=[];collect_refs(body['source_map'],refs);need(refs,f'{family}/{ck}/{key}: no physical BCI map origins')
            mapped=set()
            for ref in refs:
                ref_method=ref['method']; ref_key=(utf8(ref_method['name']),utf8(ref_method['descriptor']))
                need(ref_key==key and ref_method==identity,f'{family}/{ck}/{key}: source map origin crosses method/owner')
                need(ref['bci'] in fact['code']['bcis'],f'{family}/{ck}/{key}: map BCI is not an instruction start')
                mapped.add(ref['bci']); map_refs+=1
            need(set(fact['code']['bcis'])<=mapped,f'{family}/{ck}/{key}: source map omits physical instruction BCIs')
            if key!=target:
                need(projection(method)==projection(old_by_key[key]),f'{family}/{ck}/{key}: non-target body/quality/fallback/source-map changed from baseline')
            method_rows.append({'family':family,'cell':list(ck),'method':key,'quality':body['quality'],'physical_instruction_count':len(fact['code']['bcis']),'mapped_bci_count':len(mapped)})
        need(doc['text'].encode('utf-8')==source,f'{family}/{ck}: class text/source mismatch')
    need(len(seen)==len(baseline_cells),f'{family}: API cell matrix incomplete')
    expected_receipt = pin(receipt_path)
    index=json.loads((receipt_path.parent.parent/'index.json').read_text(encoding='utf-8'))
    need(index.get('output_receipts',{}).get(family)==expected_receipt,f'{family}: index does not pin final family receipt')
    # The default/all requests for the same physical class must render the same bodies and maps.
    groups={}
    for cell in cells:
        key=(cell.get('name'),cell.get('compiler'),cell['profile'],cell.get('form'))
        groups.setdefault(key,{})[cell['evidence']]=json.loads(Path(cell['report']['path']).read_text(encoding='utf-8'))
    for key, pair in groups.items():
        need(set(pair)=={'default','all'},f'{family}/{key}: default/all pair missing')
        a,b=pair['default'],pair['all']
        need(a['text']==b['text'],f'{family}/{key}: default/all class text differs')
        need([evidence_projection(m) for m in a['methods']]==[evidence_projection(m) for m in b['methods']],f'{family}/{key}: default/all method body/map projection differs')
    return {'cells':len(cells),'commands':len(rec['commands']),'raw_streams':raw_count,'structured_methods':len(method_rows),'map_origins':map_refs,'method_rows':method_rows,'receipt':pin(receipt_path)}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--root',type=Path,default=ROOT);args=ap.parse_args()
    root=args.root.resolve(strict=True);out=args.out.resolve(strict=True);c=load_compare()
    index=json.loads((out/'index.json').read_text(encoding='utf-8'))
    need(index.get('status')=='captured_pending_independent_api_acceptance','API replay index not terminal')
    need(index.get('source_before')==index.get('source_after') and index.get('target_absent') is True,'replay index source/target invariant failed')
    result={'status':'independent_read_only_api_review_passed','out':str(out),'index':pin(out/'index.json'),'families':{},'limitations':['Class owner BLAKE3 is checked by unchanged full physical identity and public Rust tests; this Python checker does not independently recompute BLAKE3.']}
    for family in ('original','supplement'):
        receipt=out/family/'execution.json';result['families'][family]=review_family(c,family,receipt)
    (out/'acceptance-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:{'cells':v['cells'],'commands':v['commands'],'structured_methods':v['structured_methods'],'map_origins':v['map_origins']} for k,v in result['families'].items()},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
