#!/usr/bin/env python3
"""Replay the pinned original and supplement Jarde class-source API cells on a supplied CLI."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, shutil, sys
from pathlib import Path

ROOT_DEFAULT = Path('/Users/lordcasser/workspace/projects/jarde')
INPUTS = {
    'original': Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018/execution.json'),
    'supplement': Path('/private/tmp/jarde-prefixed-retry-originals-root-v2-20261018/execution.json'),
}
COMPARE_REL = Path('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
GUARD_REL = Path('openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py')
SCANNER_REL = Path('openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py')
EXPECTED_COMPARE_SHA = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot import helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temp.replace(path)


def cell_key(cell: dict, family: str) -> tuple:
    if family == 'original':
        return (cell['profile'], cell['form'], cell['evidence'])
    return (cell['name'], cell['compiler'], cell['profile'], cell['evidence'])


def command_label(cell: dict, family: str) -> str:
    if family == 'original':
        return f"jarde-{cell['profile']}-{cell['form']}-{cell['evidence']}"
    return f"jarde-{cell['name']}-{cell['compiler']}-{cell['profile']}-{cell['evidence']}"


def api_command(original_command: dict, old_cli: Path, candidate_cli: Path) -> list[str]:
    argv = list(original_command['argv'])
    if not argv or Path(argv[0]).resolve() != old_cli.resolve():
        raise RuntimeError(f"command {original_command.get('index')} does not use the receipt CLI")
    if len(argv) < 2 or argv[1] != 'class-source':
        raise RuntimeError(f"command {original_command.get('index')} is not class-source")
    # Preserve every original request flag and input path. The collector output is stored separately.
    argv[0] = str(candidate_cli)
    return argv


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--cli', type=Path, required=True, help='candidate CLI binary to replay')
    ap.add_argument('--out', type=Path, required=True, help='new output root; contains original/ and supplement/')
    ap.add_argument('--root', type=Path, default=ROOT_DEFAULT)
    args = ap.parse_args()
    root = args.root.resolve(strict=True)
    cli = args.cli.resolve(strict=True)
    out = args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing existing output directory: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('repository target must be absent before API replay')

    compare_path = root / COMPARE_REL
    if sha(compare_path.read_bytes()) != EXPECTED_COMPARE_SHA:
        raise SystemExit('compare.py pin mismatch')
    compare = load_module(compare_path, 'prefixed_retry_api_replay_compare')
    guard_path, scanner_path = root / GUARD_REL, root / SCANNER_REL
    if compare.sha(guard_path) != compare.GUARD_SHA256 or compare.sha(scanner_path) != compare.SCANNER_SHA256:
        raise SystemExit('root guard/scanner pin mismatch')
    guard = load_module(guard_path, 'prefixed_retry_api_replay_guard')
    scanner = load_module(scanner_path, 'prefixed_retry_api_replay_scanner')
    if compare.pin(cli)['path'] != str(cli):
        raise SystemExit('candidate CLI could not be pinned')

    input_docs = {family: json.loads(path.read_text(encoding='utf-8')) for family, path in INPUTS.items()}
    expected = {'original': 8, 'supplement': 16}
    for family, doc in input_docs.items():
        if len(doc.get('jarde_cells', [])) != expected[family]:
            raise SystemExit(f'{family} input receipt does not contain {expected[family]} Jarde cells')
        commands = {row['index']: row for row in doc.get('commands', [])}
        if len(commands) != len(doc.get('commands', [])):
            raise SystemExit(f'{family} input receipt has duplicate command indexes')
        old_cli = doc.get('cli')
        if not isinstance(old_cli, dict) or compare.pin(Path(old_cli['path'])) != old_cli:
            raise SystemExit(f'{family} input CLI pin is invalid')
        keys = set()
        for cell in doc['jarde_cells']:
            key = cell_key(cell, family)
            if key in keys:
                raise SystemExit(f'{family} has a duplicate API cell: {key}')
            keys.add(key)
            command = commands.get(cell.get('command'))
            if command is None or command.get('exit_code') != 0 or command.get('guard_stop') is not None:
                raise SystemExit(f'{family}/{key}: original API command is not a successful pinned input')
            if compare.pin(Path(cell['input']['path'])) != cell['input']:
                raise SystemExit(f'{family}/{key}: original input class pin changed')
            if compare.pin(Path(cell['source']['path'])) != cell['source']:
                raise SystemExit(f'{family}/{key}: original API source pin changed')
            if compare.pin(Path(cell['report']['path'])) != cell['report']:
                raise SystemExit(f'{family}/{key}: original API report pin changed')
            old_doc = json.loads(Path(cell['report']['path']).read_text(encoding='utf-8'))
            if old_doc.get('text', '').encode('utf-8') != Path(cell['source']['path']).read_bytes():
                raise SystemExit(f'{family}/{key}: original report text/source mismatch')
            if json.loads(compare.command_artifact(command, 'stdout')) != old_doc:
                raise SystemExit(f'{family}/{key}: saved old API report differs from captured stdout')

    before = compare.source_closure(root)
    cli_pin = compare.pin(cli)
    input_pins = {family: compare.pin(path) for family, path in INPUTS.items()}
    out.mkdir(parents=True)
    guard.ROOT = root
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, stdout: None

    env = {k: v for k, v in os.environ.items() if k not in ENV_STRIP}
    env = compare.clean_env(env)
    env.pop('RUST_MIN_STACK', None)
    env.update(guard.ENV_VALUES)
    outputs = {}
    for family, source_receipt in input_docs.items():
        family_out = out / family
        family_out.mkdir()
        raw_dir = family_out / 'raw'
        raw_dir.mkdir()
        guard.OUT = raw_dir
        commands = {row['index']: row for row in source_receipt['commands']}
        original_cell_inputs = []
        for old_cell in source_receipt['jarde_cells']:
            original_cell_inputs.append({
                'key': list(cell_key(old_cell, family)),
                'input_class': compare.pin(Path(old_cell['input']['path'])),
                'source': compare.pin(Path(old_cell['source']['path'])),
                'report': compare.pin(Path(old_cell['report']['path'])),
            })
        result = {
            'schema': f"{source_receipt['schema']}-api-replay-v1",
            'runner': compare.pin(Path(__file__)),
            'cli': cli_pin,
            'status': 'running', 'family': family,
            'input_capture': compare.pin(INPUTS[family]),
            'candidate_cli': cli_pin, 'source_before': before,
            'compare_helper': compare.pin(compare_path), 'guard': compare.pin(guard_path),
            'scanner': compare.pin(scanner_path),
            # Preserve the original full class records, oracle and driver metadata when present.
            'source_context': source_receipt,
            'original_cell_inputs_before': original_cell_inputs,
            'commands': [], 'jarde_cells': [], 'source_artifacts': [],
        }
        receipt_path = family_out / 'execution.json'
        write_json(receipt_path, result)
        for old_cell in source_receipt['jarde_cells']:
            label = command_label(old_cell, family)
            old_command = commands[old_cell['command']]
            argv = api_command(old_command, Path(source_receipt['cli']['path']), cli)
            row = guard.run_command(len(result['commands']) + 1, argv, env)
            row.update({'label': f'replay-{family}-{label}', 'phase': 'candidate-class-source-api-replay',
                        'replayed_from_command': old_command['index']})
            result['commands'].append(row)
            new_cell = dict(old_cell)
            new_cell['command'] = row['index']
            new_cell['exit_code'] = row.get('exit_code')
            new_cell['replayed_from_command'] = old_command['index']
            stdout = compare.command_artifact(row, 'stdout')
            stderr = compare.command_artifact(row, 'stderr')
            raw_row = {'command': row['index'], 'stdout': row['streams']['stdout'], 'stderr': row['streams']['stderr']}
            result['raw_streams'] = result.get('raw_streams', []) + [raw_row]
            if row.get('guard_stop') is not None:
                new_cell['capture_error'] = f"root guard stopped: {row['guard_stop']}"
                new_cell['report'] = None
                new_cell['source'] = None
            else:
                try:
                    doc = json.loads(stdout.decode('utf-8', 'strict'))
                    if not isinstance(doc, dict) or not isinstance(doc.get('methods'), list) or not isinstance(doc.get('text'), str):
                        raise ValueError('JSON lacks complete class text/methods')
                    report_path = family_out / 'reports' / f"{row['index']:02d}-{label}.json"
                    source_path = family_out / 'sources' / f"{row['index']:02d}-{label}.java"
                    report_path.parent.mkdir(parents=True, exist_ok=True)
                    source_path.parent.mkdir(parents=True, exist_ok=True)
                    report_path.write_bytes(stdout)
                    source_path.write_bytes(doc['text'].encode('utf-8'))
                    new_cell['report'] = compare.pin(report_path)
                    new_cell['source'] = compare.pin(source_path)
                    new_cell['capture_error'] = None
                    result['source_artifacts'].append({'report': new_cell['report'], 'source': new_cell['source']})
                except (UnicodeDecodeError, json.JSONDecodeError, ValueError, KeyError) as exc:
                    new_cell['capture_error'] = f'{type(exc).__name__}: {exc}'
                    new_cell['report'] = None
                    new_cell['source'] = None
            result['jarde_cells'].append(new_cell)
            write_json(receipt_path, result)
        result['source_after'] = compare.source_closure(root)
        result['candidate_cli_after'] = compare.pin(cli)
        result['input_captures_after'] = {name: compare.pin(path) for name, path in INPUTS.items()}
        original_cell_inputs_after = []
        for old_cell in source_receipt['jarde_cells']:
            original_cell_inputs_after.append({
                'key': list(cell_key(old_cell, family)),
                'input_class': compare.pin(Path(old_cell['input']['path'])),
                'source': compare.pin(Path(old_cell['source']['path'])),
                'report': compare.pin(Path(old_cell['report']['path'])),
            })
        result['original_cell_inputs_after'] = original_cell_inputs_after
        result['status'] = 'captured_pending_independent_api_acceptance'
        if (result['source_after'] != before or result['candidate_cli_after'] != cli_pin
                or result['input_captures_after'] != input_pins
                or original_cell_inputs_after != original_cell_inputs):
            result['status'] = 'failed_input_closure_changed'
            write_json(receipt_path, result)
            raise RuntimeError(f'{family} source/CLI/original receipt changed during replay')
        for cell in result['jarde_cells']:
            if cell['report'] is None or cell['source'] is None:
                result['status'] = 'captured_with_incomplete_api_response'
        outputs[family] = compare.pin(receipt_path)
        write_json(receipt_path, result)
    summary = {'status': 'captured_pending_independent_api_acceptance', 'cli': cli_pin,
               'source_before': before, 'source_after': compare.source_closure(root),
               'input_receipts_before': input_pins,
               'output_receipts': outputs, 'target_absent': not (root / 'target').exists()}
    write_json(out / 'index.json', summary)
    if summary['source_before'] != summary['source_after'] or not summary['target_absent']:
        raise RuntimeError('source closure changed or target appeared during replay')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0

if __name__ == '__main__':
    sys.dont_write_bytecode = True
    raise SystemExit(main())
