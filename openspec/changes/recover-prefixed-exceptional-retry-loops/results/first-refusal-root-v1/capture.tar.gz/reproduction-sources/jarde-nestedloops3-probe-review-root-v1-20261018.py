import hashlib,json
from pathlib import Path
R=Path('/Users/lordcasser/workspace/projects/jarde'); O=Path('/private/tmp/jarde-nestedloops3-first-refusal-root-v1-20261018');B=Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def verify(row): assert pin(row['path'])==row
j=json.loads((O/'execution.json').read_text()); b=json.loads((B/'execution.json').read_text()); build=json.loads((O/'build/execution.json').read_text())
assert j['status']=='probe_captured_pending_architect_review';assert j['source_restored'] and j['closure_restored'] and j['target_absent'];assert not (R/'target').exists()
for k in ('patch','runner','baseline','probe_cli'):verify(j[k])
for rel,row in j['source_after'].items():verify(row);assert (O/'original-source'/Path(rel).name).read_bytes()==(R/rel).read_bytes()
assert build['status']=='commands_passed_pending_independent_acceptance' and build['source_unchanged'] and build['target_absent']
assert len(build['commands'])==2 and build['commands'][0]['argv']==['cargo','build','-p','jarde-cli','--all-features'] and build['commands'][1]['argv']==['cargo','clean']
for row in build['commands']:
 assert row['exit_code']==0 and not row.get('guard_stop')
 for p in row['streams'].values():verify(p)
assert len(j['cells'])==8
api=[r for r in j['commands'] if 'streams' in r];assert len(api)==8
def norm(v):
 if isinstance(v,dict):return {k:norm(x) for k,x in v.items() if k!='usage'}
 if isinstance(v,list):return [norm(x) for x in v]
 return v
observations=[]
for c,r,old in zip(j['cells'],api,b['jarde_cells']):
 assert all(c[k]==old[k] for k in ('profile','form','evidence'))
 assert r['exit_code']==0 and not r['guard_stop']
 for p in r['streams'].values():verify(p)
 verify(old['report']);assert norm(json.loads(Path(r['streams']['stdout']['path']).read_text()))==norm(json.loads(Path(old['report']['path']).read_text()))
 s=Path(r['streams']['stderr']['path']).read_text()
 for marker in ('stage=latch_test_chain result=None','stage=effectful_dual_exit result=None','stage=header_tested result=None','stage=latch_tested result=None','stage=all_candidates_refused final_reason=LoopShape { block_bci: 0 }','irreducible_nodes=[]','header_successors=[1] body_branch=false'):
  assert marker in s,marker
 assert 'NESTEDLOOPS3_PROBE try_candidate' not in s and 'NESTEDLOOPS3_PROBE body_sequence' not in s
 observations.append({k:c[k] for k in ('profile','form','evidence','stderr')})
payload={'status':'accepted_first_refusal_observation_only','execution':pin(O/'execution.json'),'build':pin(O/'build/execution.json'),'checker':pin(__file__),'api_requests':8,'non_usage_json_unchanged':True,'source_restored':True,'target_absent':True,'first_refusal':'Outer natural-loop header BCI0; latch_chain/effectful_dual_exit/header_tested/latch_tested return None; no child body or catch reader entered.','ids_bci_order':[0,6,14,17,40,26,29,36],'natural_loop_bcis':[0,6,17,29,36],'natural_latch_bci':29,'proved_catch_join_bcis':[36,6],'observations':observations,'limits':['No production fix was applied; diagnostic is stderr only.','NormalFlowView includes handler36 in the reverse-predecessor natural-loop set even though its exception edge remains excluded. Do not reuse earlier four-block hypothesis.','This is not a runtime acceptance of generated Jarde output.']}
(O/'root-review.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps({k:payload[k] for k in ('status','api_requests','first_refusal','source_restored','target_absent')}))
