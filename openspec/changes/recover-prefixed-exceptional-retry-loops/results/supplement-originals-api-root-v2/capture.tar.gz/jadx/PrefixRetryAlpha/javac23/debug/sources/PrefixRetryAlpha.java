// default package

/* JADX INFO: loaded from: PrefixRetryAlpha.class */
public final class PrefixRetryAlpha {
    public int trace;
    public int outerPrefixCalls;
    public int retryPrefixCalls;
    public int protectedCalls;
    public int catchCalls;
    public int outerIterations;
    public RuntimeException lastCaught;
    public String lastCaughtMessage;
    public final IllegalArgumentException prefixEscape = new IllegalArgumentException("alpha-prefix");
    public final AssertionError protectedEscape = new AssertionError("alpha-protected-error");
    public final AssertionError catchEscape = new AssertionError("alpha-catch-effect");
    private int failuresRemaining;

    public int execute(int failures, int outerLimit, int mode) {
        this.failuresRemaining = bounded(failures, 0, 1);
        int limit = bounded(outerLimit, 1, 2);
        loop0: while (true) {
            f1(mode);
            this.outerIterations++;
            int stage = 0;
            while (true) {
                f2(mode);
                if (stage != 0) {
                    break loop0;
                }
                stage += 3;
                if (this.outerIterations > limit) {
                    break loop0;
                }
                try {
                    protectedStep(mode);
                    break;
                } catch (IllegalArgumentException failure) {
                    this.catchCalls++;
                    recordCatch(failure, mode);
                }
            }
        }
        record(5);
        return this.trace;
    }

    private void f1(int mode) {
        this.outerPrefixCalls++;
        record(1);
        if ((mode & 1) != 0) {
            throw this.prefixEscape;
        }
    }

    private void f2(int mode) {
        this.retryPrefixCalls++;
        record(2);
        if ((mode & 2) != 0) {
            throw this.prefixEscape;
        }
    }

    private void protectedStep(int mode) {
        this.protectedCalls++;
        record(3);
        if (this.failuresRemaining > 0) {
            this.failuresRemaining--;
            throw new IllegalArgumentException("alpha-retry");
        }
        if ((mode & 4) != 0) {
            throw this.protectedEscape;
        }
    }

    private void recordCatch(IllegalArgumentException failure, int mode) {
        this.lastCaught = failure;
        this.lastCaughtMessage = failure.getMessage();
        record(4);
        if ((mode & 8) != 0) {
            throw this.catchEscape;
        }
    }

    private void record(int event) {
        this.trace = (this.trace * 10) + event;
    }

    private static int bounded(int value, int min, int max) {
        return Math.max(min, Math.min(value, max));
    }
}
