// default package

/* JADX INFO: loaded from: PrefixRetryAlpha.class */
public final class PrefixRetryAlpha {
    public int trace;
    public int outerPrefixCalls;
    public int retryPrefixCalls;
    public int protectedCalls;
    public int catchCalls;
    public int outerIterations;
    public RuntimeException lastCaught;
    public String lastCaughtMessage;
    public final IllegalArgumentException prefixEscape = new IllegalArgumentException("alpha-prefix");
    public final AssertionError protectedEscape = new AssertionError("alpha-protected-error");
    public final AssertionError catchEscape = new AssertionError("alpha-catch-effect");
    private int failuresRemaining;

    public int execute(int i, int i2, int i3) {
        this.failuresRemaining = bounded(i, 0, 1);
        int iBounded = bounded(i2, 1, 2);
        loop0: while (true) {
            f1(i3);
            this.outerIterations++;
            int i4 = 0;
            while (true) {
                f2(i3);
                if (i4 != 0) {
                    break loop0;
                }
                i4 += 3;
                if (this.outerIterations > iBounded) {
                    break loop0;
                }
                try {
                    protectedStep(i3);
                    break;
                } catch (IllegalArgumentException e) {
                    this.catchCalls++;
                    recordCatch(e, i3);
                }
            }
        }
        record(5);
        return this.trace;
    }

    private void f1(int i) {
        this.outerPrefixCalls++;
        record(1);
        if ((i & 1) != 0) {
            throw this.prefixEscape;
        }
    }

    private void f2(int i) {
        this.retryPrefixCalls++;
        record(2);
        if ((i & 2) != 0) {
            throw this.prefixEscape;
        }
    }

    private void protectedStep(int i) {
        this.protectedCalls++;
        record(3);
        if (this.failuresRemaining > 0) {
            this.failuresRemaining--;
            throw new IllegalArgumentException("alpha-retry");
        }
        if ((i & 4) != 0) {
            throw this.protectedEscape;
        }
    }

    private void recordCatch(IllegalArgumentException illegalArgumentException, int i) {
        this.lastCaught = illegalArgumentException;
        this.lastCaughtMessage = illegalArgumentException.getMessage();
        record(4);
        if ((i & 8) != 0) {
            throw this.catchEscape;
        }
    }

    private void record(int i) {
        this.trace = (this.trace * 10) + i;
    }

    private static int bounded(int i, int i2, int i3) {
        return Math.max(i2, Math.min(i, i3));
    }
}
