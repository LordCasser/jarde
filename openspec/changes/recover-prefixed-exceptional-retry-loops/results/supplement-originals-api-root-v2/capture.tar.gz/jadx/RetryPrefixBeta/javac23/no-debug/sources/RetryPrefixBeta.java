// default package

/* JADX INFO: loaded from: RetryPrefixBeta.class */
public final class RetryPrefixBeta {
    public int trace;
    public int outerPrefixCalls;
    public int retryPrefixCalls;
    public int protectedCalls;
    public int catchCalls;
    public int outerIterations;
    public RuntimeException lastCaught;
    public String lastCaughtMessage;
    public final IllegalStateException prefixEscape = new IllegalStateException("beta-prefix");
    public final AssertionError protectedEscape = new AssertionError("beta-protected-error");
    public final AssertionError catchEscape = new AssertionError("beta-catch-effect");
    private int injectedFailures;

    public int execute(int i, int i2, int i3) {
        this.injectedFailures = cap(i, 0, 1);
        int iCap = cap(i2, 1, 2);
        loop0: while (true) {
            beginOuter(i3);
            this.outerIterations++;
            int i4 = 0;
            while (true) {
                beginRetry(i3);
                if (i4 != 0) {
                    break loop0;
                }
                i4 += 7;
                if (this.outerIterations > iCap) {
                    break loop0;
                }
                try {
                    performProtected(i3);
                    break;
                } catch (IllegalStateException e) {
                    this.catchCalls++;
                    rememberCatch(e, i3);
                }
            }
        }
        append(5);
        return this.trace;
    }

    private void beginOuter(int i) {
        this.outerPrefixCalls++;
        append(2);
        if ((i & 1) != 0) {
            throw this.prefixEscape;
        }
    }

    private void beginRetry(int i) {
        this.retryPrefixCalls++;
        append(1);
        if ((i & 2) != 0) {
            throw this.prefixEscape;
        }
    }

    private void performProtected(int i) {
        this.protectedCalls++;
        append(4);
        if (this.injectedFailures != 0) {
            this.injectedFailures--;
            throw new IllegalStateException("beta-again");
        }
        if ((i & 4) != 0) {
            throw this.protectedEscape;
        }
    }

    private void rememberCatch(IllegalStateException illegalStateException, int i) {
        this.lastCaught = illegalStateException;
        this.lastCaughtMessage = illegalStateException.getMessage();
        append(3);
        if ((i & 8) != 0) {
            throw this.catchEscape;
        }
    }

    private void append(int i) {
        this.trace = (this.trace * 10) + i;
    }

    private static int cap(int i, int i2, int i3) {
        return Math.max(i2, Math.min(i, i3));
    }
}
