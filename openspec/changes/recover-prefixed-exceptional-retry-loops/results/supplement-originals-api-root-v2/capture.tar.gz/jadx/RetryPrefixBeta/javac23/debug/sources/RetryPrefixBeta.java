// default package

/* JADX INFO: loaded from: RetryPrefixBeta.class */
public final class RetryPrefixBeta {
    public int trace;
    public int outerPrefixCalls;
    public int retryPrefixCalls;
    public int protectedCalls;
    public int catchCalls;
    public int outerIterations;
    public RuntimeException lastCaught;
    public String lastCaughtMessage;
    public final IllegalStateException prefixEscape = new IllegalStateException("beta-prefix");
    public final AssertionError protectedEscape = new AssertionError("beta-protected-error");
    public final AssertionError catchEscape = new AssertionError("beta-catch-effect");
    private int injectedFailures;

    public int execute(int failures, int outerLimit, int mode) {
        this.injectedFailures = cap(failures, 0, 1);
        int limit = cap(outerLimit, 1, 2);
        loop0: while (true) {
            beginOuter(mode);
            this.outerIterations++;
            int stage = 0;
            while (true) {
                beginRetry(mode);
                if (stage != 0) {
                    break loop0;
                }
                stage += 7;
                if (this.outerIterations > limit) {
                    break loop0;
                }
                try {
                    performProtected(mode);
                    break;
                } catch (IllegalStateException caught) {
                    this.catchCalls++;
                    rememberCatch(caught, mode);
                }
            }
        }
        append(5);
        return this.trace;
    }

    private void beginOuter(int mode) {
        this.outerPrefixCalls++;
        append(2);
        if ((mode & 1) != 0) {
            throw this.prefixEscape;
        }
    }

    private void beginRetry(int mode) {
        this.retryPrefixCalls++;
        append(1);
        if ((mode & 2) != 0) {
            throw this.prefixEscape;
        }
    }

    private void performProtected(int mode) {
        this.protectedCalls++;
        append(4);
        if (this.injectedFailures != 0) {
            this.injectedFailures--;
            throw new IllegalStateException("beta-again");
        }
        if ((mode & 4) != 0) {
            throw this.protectedEscape;
        }
    }

    private void rememberCatch(IllegalStateException caught, int mode) {
        this.lastCaught = caught;
        this.lastCaughtMessage = caught.getMessage();
        append(3);
        if ((mode & 8) != 0) {
            throw this.catchEscape;
        }
    }

    private void append(int event) {
        this.trace = (this.trace * 10) + event;
    }

    private static int cap(int value, int lower, int upper) {
        return Math.max(lower, Math.min(value, upper));
    }
}
