#!/usr/bin/env python3
import hashlib, importlib.util, json, re, sys
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
OUT = Path('/private/tmp/jarde-prefixed-retry-originals-root-v2-20261018')
FIX = Path('/private/tmp/jarde-prefixed-retry-fixtures-luna-v2-20261018')
BASE = Path('/private/tmp/jarde-prefixed-retry-originals-root-v1-20261018')
COMPARE = ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
EXPECT = {
 'PrefixRetryAlpha': [('<init>','()V'),('execute','(III)I'),('f1','(I)V'),('f2','(I)V'),('protectedStep','(I)V'),('recordCatch','(Ljava/lang/IllegalArgumentException;I)V'),('record','(I)V'),('bounded','(III)I')],
 'RetryPrefixBeta': [('<init>','()V'),('execute','(III)I'),('beginOuter','(I)V'),('beginRetry','(I)V'),('performProtected','(I)V'),('rememberCatch','(Ljava/lang/IllegalStateException;I)V'),('append','(I)V'),('cap','(III)I')],
}
CASE_NAMES = ['direct-success','caught-then-inner-gateway-exit-limit1','caught-then-inner-gateway-exit-limit2','normal-success-then-second-outer-prefix','unmatched-error-escapes','f1-throws-outside-row','f2-throws-outside-row','catch-effect-throws','same-instance-first','same-instance-second']

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def pin(path):
 p=Path(path); b=p.read_bytes(); return {'path':str(p.resolve()),'bytes':len(b),'sha256':sha_bytes(b)}
def need(ok, msg):
 if not ok: raise AssertionError(msg)
def load_compare():
 spec=importlib.util.spec_from_file_location('prefixed_retry_compare',COMPARE)
 mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def owner_key(owner):
 return (owner['class_bytes']['digest'],owner['class_bytes']['length'],owner['location']['kind'],owner['location'].get('snapshot'),owner['variant']['kind'])
def utf8(raw): return bytes(raw).decode('utf-8','strict')
def collect_map_refs(node, out):
 if isinstance(node,dict):
  if 'bci' in node and 'method' in node: out.append(node)
  for value in node.values(): collect_map_refs(value,out)
 elif isinstance(node,list):
  for value in node: collect_map_refs(value,out)

def catch_type_name(class_path, cp_index):
 data=Path(class_path).read_bytes(); pos=8
 count=int.from_bytes(data[pos:pos+2],'big'); pos+=2; cp=[None]*count; i=1
 while i<count:
  tag=data[pos];pos+=1
  if tag==1:
   n=int.from_bytes(data[pos:pos+2],'big');pos+=2;cp[i]=('utf',data[pos:pos+n].decode('utf-8','strict'));pos+=n
  elif tag in (3,4): pos+=4
  elif tag in (5,6): pos+=8;i+=1
  elif tag==7: cp[i]=('class',int.from_bytes(data[pos:pos+2],'big'));pos+=2
  elif tag in (8,16,19,20): pos+=2
  elif tag in (9,10,11,12,17,18): pos+=4
  elif tag==15: pos+=3
  else: raise AssertionError(f'unknown constant pool tag {tag}')
  need(pos<=len(data),'constant pool truncated');i+=1
 need(0<cp_index<count and cp[cp_index] and cp[cp_index][0]=='class','exception row catch_type is not Class')
 ni=cp[cp_index][1];need(cp[ni] and cp[ni][0]=='utf','exception catch class name is not UTF8')
 return cp[ni][1]

def bci_decode(code_hex):
 code=bytes.fromhex(code_hex); bcis=[]; pc=0
 while pc<len(code):
  bcis.append(pc); op=code[pc]
  if op in (0x99,0x9a,0x9b,0x9c,0x9d,0x9e,0x9f,0xa0,0xa1,0xa2,0xa3,0xa4,0xa5,0xa6,0xa7,0xa8,0xc6,0xc7): size=3
  elif op in (0xb2,0xb3,0xb4,0xb5,0xb6,0xb7,0xb8,0xbb,0xbd,0xc0,0xc1): size=3
  elif op in (0x15,0x16,0x17,0x18,0x19,0x36,0x37,0x38,0x39,0x3a,0x10,0x12): size=2
  elif op==0x84: size=3
  elif op in (0xb9,0xba): size=5
  elif op in (0xc8,0xc9): size=5
  else: size=1
  need(pc+size<=len(code),f'invalid instruction at {pc}')
  pc+=size
 need(pc==len(code),'instruction stream does not end at Code length')
 return code,bcis

def branch_target(code,pc): return pc+int.from_bytes(code[pc+1:pc+3],'big',signed=True)

def main():
 c=load_compare()
 run=json.loads((OUT/'execution.json').read_text())
 need(run['schema']=='prefixed-retry-supplemental-originals-v2','unexpected receipt schema')
 need(run['status']=='captured_pending_root_originals_and_api_review','receipt is not terminal-captured')
 need(len(run['commands'])==51,'expected 51 commands')
 need(run['target_absent'] is True and run['source_unchanged'] is True,'source/target invariants not certified')
 need(run['source_before']==run['source_after'],'workspace source closure changed')
 need(run['source_before'].get('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')==pin(COMPARE),'compare parser differs from captured source closure')
 need(run['runner']==pin('/private/tmp/jarde-prefixed-retry-originals-collector-root-v2-20261018.py'),'collector pin differs from recorded runner')
 need(pin(OUT/'execution.json')['path']==str((OUT/'execution.json').resolve()),'receipt path invalid')
 # Verify every captured stream from disk and every guarded command status.
 for row in run['commands']:
  need(row['guard_stop'] is None,f"guard stopped at command {row['index']}")
  for stream,rec in row['streams'].items():
   data=Path(rec['path']).read_bytes()
   need(len(data)==rec['bytes'] and sha_bytes(data)==rec['sha256'],f"raw {row['index']}/{stream} pin mismatch")
 # Freeze the three source inputs and their private copies on both sides.
 source_rows=[FIX/'alpha/PrefixRetryAlpha.java',FIX/'beta/RetryPrefixBeta.java',FIX/'driver/RetryFixtureDriver.java']
 expected_before={str(p):pin(p) for p in source_rows}
 need(run['sources_before']==expected_before,'source manifest inputs differ')
 need(run['sources_after']==expected_before,'source inputs changed during collection')
 expected_copies={str(OUT/'source'/p.relative_to(FIX)):pin(OUT/'source'/p.relative_to(FIX)) for p in source_rows}
 need(run['source_copies_before']==expected_copies and run['source_copies_after']==expected_copies,'private source copies changed')
 manifest=json.loads((FIX/'source-manifest.json').read_text())
 need(run['source_manifest']==pin(FIX/'source-manifest.json'),'source manifest pin changed')
 need(len(manifest['files'])==5 and manifest['status']=='source-only; not compiled or run','fixture manifest does not match source-only handoff')
 for entry in manifest['files']:
  q=FIX/entry['path']; need(pin(q)['bytes']==entry['bytes'] and pin(q)['sha256']==entry['sha256'],f'fixture manifest file pin changed: {entry["path"]}')
 for key in ('cli','jadx','jadx_jar','guard','scanner'):
  need(pin(run[key]['path'])==run[key],f'{key} executable/source pin changed')
 need(pin(run['jdk']['path'])['sha256']==run['jdk']['sha256'],'JDK manifest pin changed')
 for leg,tools in run['jdk']['tools'].items():
  need(leg in ('javac8','javac23'),f'unexpected JDK leg {leg}')
  for tool,rec in tools.items(): need(pin(rec['path'])['bytes']==rec['bytes'] and pin(rec['path'])['sha256']==rec['sha256'],f'JDK tool pin changed {leg}/{tool}')
 # Exact command matrix and allowed exit codes.
 labels=[x['label'] for x in run['commands']]
 command_by={x['index']:x for x in run['commands']}
 need(sum(x.startswith('compile-') for x in labels)==8,'expected eight original class compiles')
 need(sum(x.startswith('original-runtime-') for x in labels)==16,'expected sixteen original JVM runs')
 need(sum(x.startswith('jarde-') for x in labels)==16,'expected sixteen Jarde API requests')
 need(sum(x.startswith('jadx-') and x!='jadx-version' for x in labels)==8,'expected eight JADX extraction requests')
 need(labels[0]=='independent-driver-compile' and labels[1]=='jadx-version' and labels[-1]=='wrong-codesource-root-negative','command order/control mismatch')
 for row in run['commands'][:-1]: need(row['exit_code']==0,f"unexpected nonzero command {row['index']} {row['label']}")
 wrong=run['commands'][-1]
 need(wrong['exit_code']==1,'wrong CodeSource negative control did not fail as expected')
 need(b'target loaded from' in c.command_artifact(wrong,'stderr'),'wrong CodeSource control failed for another reason')
 need(run['wrong_root_control_command']==wrong['index'],'wrong-root command receipt mismatch')
 # Source/compiler lane and complete method identity checks.
 need(len(run['classes'])==8,'expected eight class artifacts')
 class_by=(lambda x:(x['name'],x['compiler'],x['profile']))
 class_table={class_by(x):x for x in run['classes']}
 need(len(class_table)==8,'duplicate/missing class lane')
 method_rows={}
 for item in run['classes']:
  name,compiler,profile=item['name'],item['compiler'],item['profile']
  need(name in EXPECT and compiler in ('javac8','javac23') and profile in ('debug','no-debug'),'unexpected class lane')
  p=Path(item['class']['path']); need(pin(p)==item['class'],'target class pin mismatch')
  compile_cmd=command_by[item['command']]; av=compile_cmd['argv']; source_path=Path(item['source']['path']); target_root=p.parent
  need(compile_cmd['label']==f'compile-{name}-{compiler}-{profile}' and compile_cmd['exit_code']==0,'compile command label/status mismatch')
  need(Path(av[0])==Path(run['jdk']['tools'][compiler]['javac']['path']),'class compiler differs from pinned JDK leg')
  need(str(source_path)==av[-1] and source_path==OUT/'source'/('alpha' if name=='PrefixRetryAlpha' else 'beta')/(name+'.java'),'class compile source path mismatch')
  need(av[av.index('-d')+1]==str(target_root) and '-proc:none' in av and '-encoding' in av and av[av.index('-encoding')+1]=='UTF-8','class compile isolation/encoding flags mismatch')
  if compiler=='javac8': need(av[1:3]==['-source','8'] and av[3:5]==['-target','8'],'javac8 source/target flags mismatch')
  else: need(av[1:3]==['--release','8'],'javac23 release flag mismatch')
  need(('-g' if profile=='debug' else '-g:none') in av,'debug profile flag mismatch')
  facts=c.parse_class(p)
  need(facts['major']==52 and facts['class_name']==name,'original classfile version/name mismatch')
  keys=[(m['name'],m['descriptor']) for m in facts['methods']]
  need(keys==EXPECT[name],f'{name} methods incomplete or reordered: {keys}')
  need(all(m['code'] is not None for m in facts['methods']),'method without code in complete fixture')
  need(item['facts']['sha256']==facts['sha256'] and item['facts']['methods']==facts['methods'],'stored method/BCI facts mismatch class bytes')
  need(item['classes_before']==item['classes_after'],'class output directory changed')
  need(item['classes_before']=={str(x.relative_to(p.parent)):pin(x) for x in sorted(p.parent.rglob('*')) if x.is_file()},'class directory pin mismatch')
  method_rows[(name,compiler,profile)]={ (m['name'],m['descriptor']):m for m in facts['methods'] }
  # The bytecode body is layout-stable across compiler and debug profiles; CP operands may differ.
  execute=next(m for m in facts['methods'] if m['name']=='execute' and m['descriptor']=='(III)I')['code']
  code,bcis=bci_decode(execute['code_hex'])
  need(execute['code_length']==107 and len(bcis)==57,'unexpected execute bytecode layout')
  need(execute['rows'][0][:3]==[64,69,72],'protected row boundaries/handler mismatch')
  caught='java/lang/IllegalArgumentException' if name=='PrefixRetryAlpha' else 'java/lang/IllegalStateException'
  need(catch_type_name(p,execute['rows'][0][3])==caught,'exception row catch type does not match the fixture source')
  branches={pc:(code[pc],branch_target(code,pc)) for pc in bcis if code[pc] in tuple(range(0x99,0xa9))}
  need(branches=={43:(0x99,49),46:(0xa7,97),58:(0xa4,64),61:(0xa7,97),69:(0xa7,94),91:(0xa7,36),94:(0xa7,18)},f'execute branch/loop shape mismatch: {branches}')
  need([pc for pc,target in ((pc,t) for pc,(_,t) in branches.items()) if target<=pc]==[91,94],'expected one backedge per inner/outer loop')
  need(23 in bcis and not any(code[pc] in tuple(range(0x99,0xa9)) for pc in (18,19,20)),'outer header does not have its straight-line single normal successor')
  need(branches[46][1]==branches[61][1]==97 and code[97]==0x2a and code[106]==0xac,'outer exits do not share the expected completion target')
  need(code[18]==0x2a and code[20]==0xb7 and code[36]==0x2a and code[38]==0xb7,'outer/inner prefix call placement mismatch')
  need(code[49]==0x84 and code[49+1]==5 and code[49+2]==(3 if name=='PrefixRetryAlpha' else 7),'stage discriminator mismatch')
  need(code[64]==0x2a and code[66]==0xb7 and code[72]==0x3a,'protected call/handler entry mismatch')
  need(bcis==facts['methods'][1]['code']['bcis'],'instruction starts differ from recorded parser')
 # Java runtime oracle: 8 class inputs x 2 runtime VMs, ten fixed observation rows each.
 runs=run['original_runtime'];need(len(runs)==16,'runtime cardinality mismatch')
 expected_keys={(name,compiler,profile,vm) for name in EXPECT for compiler in ('javac8','javac23') for profile in ('debug','no-debug') for vm in ('javac8','javac23')}
 actual_keys={(x['name'],x['compiler'],x['profile'],x['runtime']) for x in runs}
 need(actual_keys==expected_keys,'original runtime lane matrix incomplete/duplicated')
 oracle_lines={}
 for name,receipt in run['oracles'].items():
  need(name in EXPECT and pin(receipt['path'])==receipt,'oracle pin changed')
  data=Path(receipt['path']).read_bytes(); lines=data.decode('utf-8','strict').splitlines()
  need(len(lines)==10,'oracle must contain ten driver cases')
  observed=[re.search(r' name=([^ ]+)',line).group(1) for line in lines]
  need(observed==CASE_NAMES,f'{name} oracle case sequence changed')
  need(all(line.startswith('CASE class='+name+' ') for line in lines),f'{name} oracle contains another class')
  oracle_lines[name]=data
 need(set(run['oracles'])==set(EXPECT),'two distinct class oracles missing')
 command_by={x['index']:x for x in run['commands']}
 for x in runs:
  cmd=command_by[x['command']]
  argv=cmd['argv']; name=x['name']; classes=Path(class_table[(name,x['compiler'],x['profile'])]['class']['path']).parent
  need(cmd['label']==f'original-runtime-{name}-{x["compiler"]}-{x["profile"]}-{x["runtime"]}' and Path(argv[4])==Path(run['jdk']['tools'][x['runtime']]['java']['path']),'runtime command/JDK binding mismatch')
  need(argv[argv.index('-Xverify:all')]=='-Xverify:all','runtime omitted strict verifier')
  cp=argv[argv.index('-cp')+1].split(':')
  need(cp==[str(classes),str(OUT/'driver-classes')],'runtime classpath not isolated to target and driver roots')
  need(argv[-3:]==['RetryFixtureDriver',name,str(classes)],'runtime CodeSource argv mismatch')
  need(x['runtime_classpath']==[str(classes),str(OUT/'driver-classes')],'recorded runtime classpath mismatch')
  data=c.command_artifact(cmd,'stdout')
  need(data==oracle_lines[name],f'{name}/{x["compiler"]}/{x["profile"]}/{x["runtime"]} differs from original oracle')
  x['_lines']=len(data.decode('utf-8').splitlines())
  need(x['oracle_equal'] is True,'runtime record not marked equal')
 need(sum(x['_lines'] for x in runs)==160,'runtime observation total is not 160')
 # All sixteen API reports are complete; seven helper methods are structured, execute is real fallback.
 cells=run['jarde_cells'];need(len(cells)==16,'Jarde API request count mismatch')
 cell_keys={(x['name'],x['compiler'],x['profile'],x['evidence']) for x in cells}
 expected_cells={(n,c,p,e) for n in EXPECT for c in ('javac8','javac23') for p in ('debug','no-debug') for e in ('default','all')}
 need(cell_keys==expected_cells,'Jarde input/evidence matrix incomplete')
 structured_count=0; structured_full_bci_methods=0; execute_fallbacks=[]; map_ref_total=0
 for cell in cells:
  name,compiler,profile,evidence=cell['name'],cell['compiler'],cell['profile'],cell['evidence']
  target=Path(class_table[(name,compiler,profile)]['class']['path'])
  need(cell['input']==pin(target),'Jarde input class pin mismatch')
  cmd=command_by[cell['command']]; av=cmd['argv']
  need(cmd['label']==f'jarde-{name}-{compiler}-{profile}-{evidence}' and av[:2]==[run['cli']['path'],'class-source'],'Jarde command label/entrypoint mismatch')
  need(av[av.index('--input')+1]==str(target) and av[av.index('--class')+1]==name and av[av.index('--policy')+1]=='single-class' and av[av.index('--release')+1]=='8','Jarde command input/class/policy mismatch')
  need(('--evidence' not in av) if evidence=='default' else av[av.index('--evidence')+1]=='all','Jarde evidence request mismatch')
  report_path=Path(cell['report']['path']); need(pin(report_path)==cell['report'],'Jarde JSON report pin mismatch')
  source_path=Path(cell['source']['path']); need(pin(source_path)==cell['source'],'Jarde source text pin mismatch')
  report=json.loads(report_path.read_text())
  need(report==json.loads(c.command_artifact(cmd,'stdout')),'saved report differs from actual API stdout')
  need(report['execution']['status']=='complete','Jarde whole request analysis incomplete')
  need(len(report['methods'])==8,'Jarde report missing full-class methods')
  digest=report['class']['class_bytes']['digest']; ownerlen=report['class']['class_bytes']['length']
  need(ownerlen==target.stat().st_size,'Jarde class owner length differs from input')
  exact_keys=[]
  for method_index,method in enumerate(report['methods']):
   item=method['item']; nm=utf8(item['name']['raw']); desc=utf8(item['descriptor']['raw']); key=(nm,desc);exact_keys.append(key)
   need(key in EXPECT[name],'Jarde report method identity not in physical class')
   fact=method_rows[(name,compiler,profile)][key]
   need(item['index']==method_index and item['access_flags']==fact['access'],'physical method index/access differs')
   need(item['identity']['owner']==report['class'],'method complete owner differs from report class')
   need(item['identity']['name']==item['name']['raw'] and item['identity']['descriptor']==item['descriptor']['raw'],'method identity raw bytes differ')
   need(method['outcome']['report']['artifact']['binding']['method']==item['identity'],'body artifact identity differs')
   need(item['identity']['owner']['class_bytes']['digest']==digest and item['identity']['owner']['class_bytes']['length']==ownerlen,'method owner is not the reported input class')
   need(item['identity']['owner']['location']['snapshot']==digest and item['identity']['owner']['location']['kind']=='standalone_root','method location/snapshot not bound to class')
   need(method['outcome']['analysis']['execution']['status']=='complete','method analysis not complete')
   body=method['outcome']['report']; refs=[];collect_map_refs(body['source_map'],refs)
   need(body['source_map']['segments'],'method source map absent')
   text_bytes=len(body['text'].encode('utf-8'))
   for seg in body['source_map']['segments']:
    need(0<=seg['start']<=seg['end']<=text_bytes,'source-map text span outside emitted text')
    rawtext=body['text'].encode('utf-8')
    need(seg['start']==len(rawtext) or rawtext[seg['start']] & 0xc0 != 0x80,'source-map start splits UTF8')
    need(seg['end']==len(rawtext) or rawtext[seg['end']] & 0xc0 != 0x80,'source-map end splits UTF8')
   for ref in refs:
    map_ref_total+=1
    refm=ref['method']; rn=utf8(refm['name']); rd=utf8(refm['descriptor'])
    need((rn,rd)==key,'source-map origin points to another method')
    need(refm==item['identity'],'full source-map physical method differs from method identity')
    need(ref['bci'] in fact['code']['bcis'],f'source-map BCI {ref["bci"]} is not an instruction start in {key}')
   need(bool(refs),'source map has no physical BCI references')
   if key[0]=='execute':
    need(body['content']=='explanation_only' and body['syntax_status']=='not_java' and body['compile_status']=='not_attempted','execute is not a genuine non-Java fallback')
    codes=list(body['fallbacks'])
    need(codes==['jre_region_loop_shape','jre_region_uncovered_blocks'],f'execute fallback codes changed: {codes}')
    diagnostics=body['diagnostics'];uncovered=next((x['message'] for x in diagnostics if x['code']=='jre_region_uncovered_blocks'),None)
    match=re.search(r'\[([^\]]+)\]',uncovered or '')
    need(match is not None,'execute uncovered-block diagnostic has no concrete BCI list')
    blocks=[int(v.strip()) for v in match.group(1).split(',')]
    need(len(blocks)==8 and all(v in fact['code']['bcis'] for v in blocks),'execute fallback lost real block BCI evidence')
    mapped={ref['bci'] for ref in refs}
    need(set(blocks)<=mapped,'reported uncovered blocks are not represented in fallback map origins')
    execute_fallbacks.append({'name':name,'compiler':compiler,'profile':profile,'evidence':evidence,'codes':codes,'uncovered_block_bcis':blocks,'map_bcis':sorted(mapped),'physical_instruction_bcis':len(fact['code']['bcis'])})
   else:
    need(body['content']=='contains_statements' and body['quality']=='structured' and body['fallbacks']==[],'non-target method not structured without fallback')
    need(set(fact['code']['bcis']) <= {ref['bci'] for ref in refs},f'structured method map omits instruction starts for {key}')
    structured_full_bci_methods+=1
    structured_count+=1
  need(exact_keys==EXPECT[name],'Jarde method identity list/order differs from complete physical class')
  text=report['text']
  need(text==source_path.read_text(),'saved Jarde source differs from report text')
 need(structured_count==112,'expected 112 structured non-target method/config rows')
 need(len(execute_fallbacks)==16,'expected execute fallback evidence in all 16 report/evidence cells')
 # JADX is extraction only; no javac or runtime command is counted as its rebuild.
 need(len(run['jadx_cells'])==8,'expected eight JADX source extraction cells')
 need(not any('compile' in x['label'].lower() and x['label'].startswith(('jadx-','jarde-')) for x in run['commands']),'JADX/Jarde recompile falsely present')
 for cell in run['jadx_cells']:
  cmd=command_by[cell['command']]; av=cmd['argv']
  need(cmd['label']==f'jadx-{cell["name"]}-{cell["compiler"]}-{cell["profile"]}' and Path(av[0])==Path(run['jadx']['path']),'JADX extraction command mismatch')
  target=Path(class_table[(cell['name'],cell['compiler'],cell['profile'])]['class']['path'])
  need(av[-1]==str(target) and '-d' in av,'JADX target input/output mismatch')
  need(len(cell['sources'])==1,'JADX output did not contain one source file')
  for src in cell['sources']: need(pin(src['path'])==src,'JADX source pin changed')
 need(set(run['driver_classes'])=={'RetryFixtureDriver.class','RetryFixtureDriver$Observation.class'},'driver class output is incomplete or has unexpected classes')
 for rel,rec in run['driver_classes'].items(): need(pin(OUT/'driver-classes'/rel)==rec,'driver class pin mismatch')
 review={
  'status':'independent_read_only_review_passed_with_scope_limits',
  'receipt':pin(OUT/'execution.json'),
  'collector':run['runner'],
  'counts':{'commands':len(run['commands']),'original_class_inputs':len(run['classes']),'original_jvm_runs':len(runs),'original_observation_rows':160,'jarde_reports':len(cells),'structured_non_execute_method_configs':structured_count,'structured_full_bci_methods':structured_full_bci_methods,'execute_fallback_configs':len(execute_fallbacks),'validated_source_map_origins':map_ref_total,'jadx_extractions':len(run['jadx_cells'])},
  'runtime_oracles':{name:{'sha256':sha_bytes(data),'bytes':len(data),'rows':10} for name,data in oracle_lines.items()},
  'wrong_codesource_control':{'command':wrong['index'],'exit_code':wrong['exit_code'],'expected_failure_text':True},
  'execute_code_shape':{'all_8_class_lanes_match':True,'outer_header_bci':18,'decoded_outer_prefix_instruction_span':[18,36],'decoded_outer_prefix_next_entry_bci':36,'shape_note':'18 to23 is only sequential instruction flow after invoke; it is not a canonical successor. Actual supplemental normal-flow view was not separately traced.','backedges':['91 -> 36','94 -> 18'],'inner_retry_header_bci':36,'catch_handler_bci':72,'catch_continuation_branch':'91 -> 36','normal_completion_bridge':'69 -> 94 -> 18','normal_inner_exit':'69 -> 94 -> 18','outer_exit_gateways':['46 -> 97','61 -> 97'],'exception_row':[64,69,72],'stage_increment':{'PrefixRetryAlpha':3,'RetryPrefixBeta':7}},
  'execute_fallbacks':execute_fallbacks,
  'source_map_and_method_identity':{'structured_method_configs':structured_count,'all_instruction_starts_covered_for_structured_methods':structured_full_bci_methods==112,'all_refs_resolve_to_instruction_start':True,'all_refs_bound_to_exact_class_method_owner':True,'all_utf8_segment_boundaries_checked':True},
  'pins':{'workspace_source_closure_unchanged':True,'fixture_sources_unchanged':True,'fixture_source_copies_unchanged':True,'source_manifest_unchanged':True,'CLI_JADX_JADXjar_pins_unchanged':True,'target_absent':True},
  'limits':['Owner BLAKE3 digests were not independently recomputed; SHA256 input pins and complete same-input physical identities are checked without mixing algorithms.','The catch handler falls through to inner header 36, then stage != 0 exits through the outer gateway; this concrete fixture does not retry the protected call after catching.','JADX source was extracted in eight cells only; it was not recompiled or run.','Jarde source was not recompiled or run; execute remains explanation_only with compile_status not_attempted.','BCI map references are valid instruction-start references, not complete coverage of every physical instruction; execute fallback diagnostics identify eight uncovered canonical block-start BCIs.','Report execution.status=complete means analysis completed; quality/syntax fields remain unchecked/unproven for structured helper methods.']
 }
 out=Path(__file__).with_name('review.json');out.write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps(review,indent=2,ensure_ascii=False))
if __name__=='__main__': main()
