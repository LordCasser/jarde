import datetime,hashlib,importlib.util,json,os,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('/Users/lordcasser/workspace/projects/jarde');S=Path('/private/tmp/jarde-prefixed-retry-fixtures-luna-v2-20261018');O=Path('/private/tmp/jarde-prefixed-retry-originals-root-v2-20261018');B=Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018')
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(R/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','supp_compare');g=load(R/c.GUARD_REL,'supp_guard');s=load(R/c.SCANNER_REL,'supp_scan')
assert c.sha(R/c.GUARD_REL)==c.GUARD_SHA256 and c.sha(R/c.SCANNER_REL)==c.SCANNER_SHA256
assert S.is_dir() and not O.exists() and not (R/'target').exists();O.mkdir();(O/'raw').mkdir()
g.ROOT=R;g.OUT=O/'raw';g.target_bytes=lambda:s.target_bytes(R);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
jdks,jdk=c.configured_jdks(R/c.DEFAULT_JDK_MANIFEST_REL,c.DEFAULT_JDK_MANIFEST_SHA256);before=c.source_closure(R)
base=json.loads((B/'execution.json').read_text());cli=base['cli'];jadx=base['jadx'];jadxjar=base['jadx_jar']
for p in (cli,jadx,jadxjar):assert c.pin(Path(p['path']))==p
sources=[S/'alpha/PrefixRetryAlpha.java',S/'beta/RetryPrefixBeta.java',S/'driver/RetryFixtureDriver.java'];initial={str(p):c.pin(p) for p in sources};assert len(initial)==3
for p in sources:
 q=O/'source'/p.relative_to(S);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
wrapper=Path(base['runtime_bound']['path']);assert c.pin(wrapper)==base['runtime_bound']
for p in [Path(__file__),wrapper]:shutil.copyfile(p,O/p.name)
source_copies={str(O/'source'/p.relative_to(S)):c.pin(O/'source'/p.relative_to(S)) for p in sources}
manifest=S/'source-manifest.json';shutil.copyfile(manifest,O/manifest.name)
rows=[];r={'schema':'prefixed-retry-supplemental-originals-v2','status':'running','runner':c.pin(Path(__file__)),'source_manifest':c.pin(manifest),'sources_before':initial,'source_copies_before':source_copies,'baseline_reference':c.pin(B/'execution.json'),'cli':cli,'jadx':jadx,'jadx_jar':jadxjar,'jdk':jdk,'guard':c.pin(R/c.GUARD_REL),'scanner':c.pin(R/c.SCANNER_REL),'source_before':before,'commands':rows,'classes':[],'original_runtime':[],'jarde_cells':[],'jadx_cells':[]}
def save():c.write_json(O/'execution.json',r)
def run(label,argv,leg='javac23'):
 env=c.clean_env(dict(os.environ),jdks[leg]);env.pop('RUST_MIN_STACK',None);env.update(g.ENV_VALUES)
 a=g.run_command(len(rows)+1,list(map(str,argv)),env);a['label']=label;rows.append(a);save();assert not a['guard_stop'],a;return a
def tree(p):return {str(x.relative_to(p)):c.pin(x) for x in sorted(p.rglob('*')) if x.is_file()}
try:
 driver=O/'driver-classes';driver.mkdir();empty=O/'empty-sourcepath';empty.mkdir()
 a=run('independent-driver-compile',[jdks['javac8']['tools']['javac'],'-source','8','-target','8','-Xlint:-options','-g:none','-proc:none','-encoding','UTF-8','-classpath',empty,'-sourcepath',empty,'-d',driver,O/'source/driver/RetryFixtureDriver.java'],'javac8');assert a['exit_code']==0
 driverpin=tree(driver);r['driver_classes']=driverpin;r['driver_source']=c.pin(O/'source/driver/RetryFixtureDriver.java');r['oracles']={}
 a=run('jadx-version',[jadx['path'],'--version']);assert a['exit_code']==0
 first=None
 for name,rel in [('PrefixRetryAlpha','alpha'),('RetryPrefixBeta','beta')]:
  for leg in ('javac8','javac23'):
   for profile,debug in [('debug','-g'),('no-debug','-g:none')]:
    classes=O/'classes'/name/leg/profile;classes.mkdir(parents=True);src=O/'source'/rel/(name+'.java')
    flags=['-source','8','-target','8','-Xlint:-options'] if leg=='javac8' else ['--release','8']
    a=run('compile-'+name+'-'+leg+'-'+profile,[jdks[leg]['tools']['javac'],*flags,debug,'-proc:none','-encoding','UTF-8','-classpath',empty,'-sourcepath',empty,'-d',classes,src],leg);assert a['exit_code']==0
    target=classes/(name+'.class');facts=c.parse_class(target);assert facts['major']==52 and any(m['name']=='execute' and m['descriptor']=='(III)I' for m in facts['methods']);classpin=tree(classes)
    item={'name':name,'compiler':leg,'profile':profile,'command':a['index'],'source':c.pin(src),'class':c.pin(target),'classes_before':classpin,'facts':facts};r['classes'].append(item);save()
    for runtime in ('javac8','javac23'):
     cp=os.pathsep.join(map(str,[classes,driver]));a=run('original-runtime-'+name+'-'+leg+'-'+profile+'-'+runtime,[sys.executable,'-B',wrapper,'30',jdks[runtime]['tools']['java'],'-Xverify:all','-cp',cp,'RetryFixtureDriver',name,classes],runtime);assert a['exit_code']==0
     output=c.command_artifact(a,'stdout');assert len(output.splitlines())==10
     if name not in r['oracles']:
      oracle=O/(name+'.oracle.stdout');oracle.write_bytes(output);r['oracles'][name]=c.pin(oracle)
     assert output==Path(r['oracles'][name]['path']).read_bytes();assert tree(classes)==classpin and tree(driver)==driverpin
     r['original_runtime'].append({'name':name,'compiler':leg,'profile':profile,'runtime':runtime,'command':a['index'],'oracle_equal':True,'runtime_classpath':[str(classes),str(driver)]});save()
    if first is None:first=(name,classes)
    for evidence in ('default','all'):
     a=run('jarde-'+name+'-'+leg+'-'+profile+'-'+evidence,[cli['path'],'class-source','--input',target,'--class',name,'--policy','single-class','--release','8','--format','json']+(['--evidence','all'] if evidence=='all' else []));assert a['exit_code'] in (0,4)
     d=json.loads(c.command_artifact(a,'stdout'));out=O/'jarde'/name/leg/profile/evidence;out.mkdir(parents=True);report=out/'report.json';c.write_json(report,d);source=out/(name+'.java');source.write_text(d['text'],encoding='UTF-8')
     r['jarde_cells'].append({'name':name,'compiler':leg,'profile':profile,'evidence':evidence,'input':c.pin(target),'exit_code':a['exit_code'],'command':a['index'],'report':c.pin(report),'source':c.pin(source)});save()
    out=O/'jadx'/name/leg/profile;a=run('jadx-'+name+'-'+leg+'-'+profile,[jadx['path'],'--config','none','--threads-count','1','--no-res','--rename-flags','none','-d',out,target]);assert a['exit_code']==0
    jsrc=list((out/'sources').rglob('*.java'));assert len(jsrc)==1
    r['jadx_cells'].append({'name':name,'compiler':leg,'profile':profile,'input':c.pin(target),'command':a['index'],'sources':[c.pin(p) for p in jsrc]});item['classes_after']=tree(classes);assert item['classes_after']==classpin;save()
 name,classes=first;a=run('wrong-codesource-root-negative',[sys.executable,'-B',wrapper,'30',jdks['javac8']['tools']['java'],'-Xverify:all','-cp',os.pathsep.join(map(str,[classes,driver])),'RetryFixtureDriver',name,O/'wrong-root'],'javac8');assert a['exit_code']!=0 and b'target loaded from' in c.command_artifact(a,'stderr');r['wrong_root_control_command']=a['index']
 r['sources_after']={str(p):c.pin(p) for p in sources};assert r['sources_after']==initial
 r['source_copies_after']={p:c.pin(Path(p)) for p in source_copies};assert r['source_copies_after']==source_copies
 for item in r['classes']:
  assert c.pin(Path(item['class']['path']))==item['class'] and tree(Path(item['class']['path']).parent)==item['classes_before']
 r['source_after']=c.source_closure(R);assert r['source_after']==before
 for p in (cli,jadx,jadxjar):assert c.pin(Path(p['path']))==p
 assert c.pin(Path(__file__))==r['runner'] and c.pin(manifest)==r['source_manifest'] and c.pin(wrapper)==base['runtime_bound'];assert tree(driver)==driverpin
 r['target_absent']=not (R/'target').exists();assert r['target_absent'];r['source_unchanged']=True;r['status']='captured_pending_root_originals_and_api_review'
except BaseException as e:r['status']='failed';r['error']=repr(e);raise
finally:r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({'status':r['status'],'commands':len(rows),'original_runtime':len(r['original_runtime']),'jarde':len(r['jarde_cells']),'jadx':len(r['jadx_cells'])}))
