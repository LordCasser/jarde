// jarde: presentation of `PrefixRetryAlpha` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class PrefixRetryAlpha extends java.lang.Object {
    public int trace;

    public int outerPrefixCalls;

    public int retryPrefixCalls;

    public int protectedCalls;

    public int catchCalls;

    public int outerIterations;

    public java.lang.RuntimeException lastCaught;

    public java.lang.String lastCaughtMessage;

    public final java.lang.IllegalArgumentException prefixEscape;

    public final java.lang.AssertionError protectedEscape;

    public final java.lang.AssertionError catchEscape;

    private int failuresRemaining;

    public PrefixRetryAlpha() {
        // @method <init>()V
        // @declaration a constructor of `PrefixRetryAlpha`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.prefixEscape = new java.lang.IllegalArgumentException("alpha-prefix");
        this.protectedEscape = new java.lang.AssertionError((java.lang.Object) "alpha-protected-error");
        this.catchEscape = new java.lang.AssertionError((java.lang.Object) "alpha-catch-effect");
        return;
    }

    public int execute(int arg1, int arg2, int arg3) {
        // jarde: not recovered: the recovery run for `execute(III)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method execute(III)I
        // @declaration an instance method of `PrefixRetryAlpha`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 18 36 46 49 61 64 72 94 97
        // local 4 crosses a quoted fallback region; its assignments and consumers cannot be presented as one lexically bound definition-use slice
    }

    private void f1(int arg1) {
        // @method f1(I)V
        // @declaration an instance method of `PrefixRetryAlpha`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.outerPrefixCalls += 1;
        this.record(1);
        if ((arg1 & 1) != 0) {
            throw this.prefixEscape;
        } else {
            return;
        }
    }

    private void f2(int arg1) {
        // @method f2(I)V
        // @declaration an instance method of `PrefixRetryAlpha`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.retryPrefixCalls += 1;
        this.record(2);
        if ((arg1 & 2) != 0) {
            throw this.prefixEscape;
        } else {
            return;
        }
    }

    private void protectedStep(int arg1) {
        // @method protectedStep(I)V
        // @declaration an instance method of `PrefixRetryAlpha`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.protectedCalls += 1;
        this.record(3);
        if (this.failuresRemaining > 0) {
            this.failuresRemaining -= 1;
            throw new java.lang.IllegalArgumentException("alpha-retry");
        } else if ((arg1 & 4) != 0) {
            throw this.protectedEscape;
    } else {
            return;
    }
    }

    private void recordCatch(java.lang.IllegalArgumentException arg1, int arg2) {
        // @method recordCatch(Ljava/lang/IllegalArgumentException;I)V
        // @declaration an instance method of `PrefixRetryAlpha`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.lastCaught = arg1;
        this.lastCaughtMessage = arg1.getMessage();
        this.record(4);
        if ((arg2 & 8) != 0) {
            throw this.catchEscape;
        } else {
            return;
        }
    }

    private void record(int arg1) {
        // @method record(I)V
        // @declaration an instance method of `PrefixRetryAlpha`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.trace = this.trace * 10 + arg1;
        return;
    }

    private static int bounded(int arg0, int arg1, int arg2) {
        // @method bounded(III)I
        // @declaration a static method of `PrefixRetryAlpha`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        return java.lang.Math.max(arg1, java.lang.Math.min(arg0, arg2));
    }
}
