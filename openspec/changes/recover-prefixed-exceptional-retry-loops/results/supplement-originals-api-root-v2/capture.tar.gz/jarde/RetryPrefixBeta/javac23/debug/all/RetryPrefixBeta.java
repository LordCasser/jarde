// jarde: presentation of `RetryPrefixBeta` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class RetryPrefixBeta extends java.lang.Object {
    public int trace;

    public int outerPrefixCalls;

    public int retryPrefixCalls;

    public int protectedCalls;

    public int catchCalls;

    public int outerIterations;

    public java.lang.RuntimeException lastCaught;

    public java.lang.String lastCaughtMessage;

    public final java.lang.IllegalStateException prefixEscape;

    public final java.lang.AssertionError protectedEscape;

    public final java.lang.AssertionError catchEscape;

    private int injectedFailures;

    public RetryPrefixBeta() {
        // @method <init>()V
        // @declaration a constructor of `RetryPrefixBeta`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.prefixEscape = new java.lang.IllegalStateException("beta-prefix");
        this.protectedEscape = new java.lang.AssertionError((java.lang.Object) "beta-protected-error");
        this.catchEscape = new java.lang.AssertionError((java.lang.Object) "beta-catch-effect");
        return;
    }

    public int execute(int failures, int outerLimit, int mode) {
        // jarde: not recovered: the recovery run for `execute(III)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method execute(III)I
        // @declaration an instance method of `RetryPrefixBeta`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 18 36 46 49 61 64 72 94 97
        // local 4 crosses a quoted fallback region; its assignments and consumers cannot be presented as one lexically bound definition-use slice
    }

    private void beginOuter(int mode) {
        // @method beginOuter(I)V
        // @declaration an instance method of `RetryPrefixBeta`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.outerPrefixCalls += 1;
        this.append(2);
        if ((mode & 1) != 0) {
            throw this.prefixEscape;
        } else {
            return;
        }
    }

    private void beginRetry(int mode) {
        // @method beginRetry(I)V
        // @declaration an instance method of `RetryPrefixBeta`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.retryPrefixCalls += 1;
        this.append(1);
        if ((mode & 2) != 0) {
            throw this.prefixEscape;
        } else {
            return;
        }
    }

    private void performProtected(int mode) {
        // @method performProtected(I)V
        // @declaration an instance method of `RetryPrefixBeta`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.protectedCalls += 1;
        this.append(4);
        if (this.injectedFailures != 0) {
            this.injectedFailures -= 1;
            throw new java.lang.IllegalStateException("beta-again");
        } else if ((mode & 4) != 0) {
            throw this.protectedEscape;
    } else {
            return;
    }
    }

    private void rememberCatch(java.lang.IllegalStateException caught, int mode) {
        // @method rememberCatch(Ljava/lang/IllegalStateException;I)V
        // @declaration an instance method of `RetryPrefixBeta`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.lastCaught = caught;
        this.lastCaughtMessage = caught.getMessage();
        this.append(3);
        if ((mode & 8) != 0) {
            throw this.catchEscape;
        } else {
            return;
        }
    }

    private void append(int event) {
        // @method append(I)V
        // @declaration an instance method of `RetryPrefixBeta`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.trace = this.trace * 10 + event;
        return;
    }

    private static int cap(int value, int lower, int upper) {
        // @method cap(III)I
        // @declaration a static method of `RetryPrefixBeta`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        return java.lang.Math.max(lower, java.lang.Math.min(value, upper));
    }
}
