# Private two-seed switch/retry workspace audit

`verify_workspace.py` accepts two completed `execution.json` files or their containing seed directories and writes a private JSON receipt. It does not invoke Cargo, Git, the JDK, or the network. Example:

```sh
python3 -B /private/tmp/jarde-switch-retry-workspace-review-luna-v1-20261018/verify_workspace.py \
  /path/to/seed1 /path/to/seed2 \
  --output /private/tmp/jarde-switch-retry-workspace-review-luna-v1-20261018/acceptance.json
```

The checker reconstructs the target inventory and batch plan from archived raw `cargo metadata`, binds test harness summaries to stderr `Running` order and compiler-artifact identities, checks every raw stream pin and every command’s terminal status/resource guard, confirms the pinned source maps and guard/JDK/runner configuration, checks cleanup and final target absence, and requires all 19 named switch/retry tests exactly once and `ok` per seed. It compares dynamic target identities and per-target count triples across seeds; target totals are not hard-coded.

This draft has only been statically parsed and checked for the 19 gate entries. It has not been run against the pending new workspace receipts. The older workspace receipt used to inspect field shapes predates these gates and cannot establish the new run’s acceptance.
