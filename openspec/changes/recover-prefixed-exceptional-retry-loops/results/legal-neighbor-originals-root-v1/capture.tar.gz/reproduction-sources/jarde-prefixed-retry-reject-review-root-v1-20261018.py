import json,hashlib
from pathlib import Path
O=Path('/private/tmp/jarde-prefixed-retry-reject-originals-root-v1-20261018')
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def methodref(path,index):
 data=Path(path).read_bytes();n=int.from_bytes(data[8:10],'big');pos=10;cp={};i=1
 while i<n:
  tag=data[pos];pos+=1
  if tag==1:
   size=int.from_bytes(data[pos:pos+2],'big');pos+=2;value=data[pos:pos+size].decode('utf-8');pos+=size
  elif tag in (7,8,16,19,20):value=int.from_bytes(data[pos:pos+2],'big');pos+=2
  elif tag in (9,10,11,12,17,18):value=(int.from_bytes(data[pos:pos+2],'big'),int.from_bytes(data[pos+2:pos+4],'big'));pos+=4
  elif tag in (3,4):value=None;pos+=4
  elif tag in (5,6):value=None;pos+=8;i+=1
  elif tag==15:value=None;pos+=3
  else:raise AssertionError(tag)
  cp[i]=(tag,value);i+=1
 tag,(cl,nt)=cp[index];assert tag==10;assert cp[cl][0]==7 and cp[nt][0]==12
 name,desc=cp[nt][1];return(cp[cp[cl][1]][1],cp[name][1],cp[desc][1])
j=json.loads((O/'execution.json').read_text());assert j['status']=='captured_pending_root_legal_neighbor_review' and j['source_unchanged'] and j['target_absent'] and j['source_before']==j['source_after'];assert len(j['commands'])==26 and len(j['classes'])==8 and len(j['original_runtime'])==16 and not j['jarde_cells'] and not j['jadx_cells'];cs={r['index']:r for r in j['commands']};assert sorted(cs)==list(range(1,27))
for r in j['commands']:
 assert r['guard_stop'] is None and r['peak_target_bytes']==0
 for p in r['streams'].values():assert pin(p['path'])==p
 if r['index']!=26:assert r['exit_code']==0
 else:assert r['exit_code']!=0 and b'target loaded from' in Path(r['streams']['stderr']['path']).read_bytes()
observations=[]
for item in j['classes']:
 assert item['facts']['major']==52 and len(item['facts']['methods'])==8 and item['classes_before']==item['classes_after'];p=Path(item['class']['path']);assert pin(p)==item['class'];a=cs[item['command']]['argv'];assert a[-1]==item['source']['path'] and a[a.index('-d')+1]==str(p.parent)
 code=next(m['code'] for m in item['facts']['methods'] if m['name']=='execute');raw=bytes.fromhex(code['code_hex']);branches={b:b+int.from_bytes(raw[b+1:b+3],'big',signed=True) for b in code['bcis'] if raw[b]==0xa7};assert code['rows'][0][:3]==[64,69,72]
 if item['name']=='PrefixRetryEffectfulLatch':
  assert branches[69]==94 and raw[94:98]==bytes.fromhex('2a1009b7') and branches[100]==18 and branches[91]==36
  assert methodref(p,int.from_bytes(raw[98:100],'big'))==(item['name'],'record','(I)V')
 else:assert branches[69]==94 and branches[91]==18 and branches[94]==18
 observations.append({'name':item['name'],'compiler':item['compiler'],'profile':item['profile'],'code_length':code['code_length'],'branches':branches,'rows':code['rows']})
keys={(x['name'],x['compiler'],x['profile'],x['runtime']) for x in j['original_runtime']};assert len(keys)==16
for r in j['original_runtime']:
 cmd=cs[r['command']];out=Path(cmd['streams']['stdout']['path']).read_bytes();oracle=Path(j['oracles'][r['name']]['path']).read_bytes();assert out==oracle and len(out.splitlines())==10 and r['oracle_equal'];a=cmd['argv'];assert '-Xverify:all' in a and a[-3:]==['RetryFixtureDriver',r['name'],r['runtime_classpath'][0]] and a[a.index('-cp')+1]==':'.join(r['runtime_classpath']) and len(r['runtime_classpath'])==2
 for key in ('sources_before','source_copies_before'):
  for p,row in j[key].items():assert pin(p)==row
assert j['sources_before']==j['sources_after'] and j['source_copies_before']==j['source_copies_after']
(O/'root-review.json').write_text(json.dumps({'status':'accepted_legal_original_neighbors_only','checker':pin(__file__),'execution':pin(O/'execution.json'),'commands':26,'raw_streams':52,'whole_original_class_compiles':8,'methods_per_class':8,'strict_original_jvm_runs':16,'original_cases_observed':160,'code_shapes':observations,'corrected_static_check':'Initial ad hoc verifier overmatched javac8 CP20; javac23 uses CP64 for the same symbolic record(I)V. This verifier resolves the actual CP method reference, no target source or collector output changed.','limits':['No production proof refusal or global fallback is yet asserted.','No Jarde/JADX source or rebuilt runtime was collected here.']},indent=2)+'\n');print('accepted8 valid classcompiles/16 strict JVM runs160case; actual effectful record call and wrong catch target verified')
