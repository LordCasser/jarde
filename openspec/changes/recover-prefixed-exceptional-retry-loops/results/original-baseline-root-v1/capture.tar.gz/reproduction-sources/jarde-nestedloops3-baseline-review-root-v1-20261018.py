#!/usr/bin/env python3
"""Read-only verifier for the captured TestNestedLoops3 8-cell Jarde baseline."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys

EXPECTED_CELLS = {
    (profile, form, evidence)
    for profile in ("debug", "no-debug")
    for form in ("child", "bundle-child")
    for evidence in ("default", "all")
}
TARGET_IDENTITY = ("test", "(I)I")
EXPECTED_METHODS = [
    ("<init>", "()V", 1),
    ("test", "(I)I", 1),
    ("exc", "()V", 2),
    ("f1", "()V", 2),
    ("f2", "()V", 2),
    ("check", "()V", 1),
]
CONTROL_METHODS = {"<init>", "exc", "f1", "f2", "check"}


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(record: dict, label: str) -> bytes:
    path = Path(record["path"])
    need(path.is_absolute() and path.is_file(), f"{label}: missing absolute artifact: {path}")
    data = path.read_bytes()
    need(len(data) == record.get("bytes") and sha(data) == record.get("sha256"),
         f"{label}: bytes/SHA-256 do not match receipt")
    return data


def byte_boundaries(data: bytes) -> set[int]:
    return {0, len(data), *(i for i, byte in enumerate(data) if byte & 0xC0 != 0x80)}


def utf8_projection_and_bcIs(method: dict, facts_method: dict, class_owner: dict) -> tuple[dict, set[int]]:
    body = method["outcome"]["report"]
    text = body["text"].encode("utf-8")
    boundaries = byte_boundaries(text)
    expected_bcIs = set(facts_method["code"]["bcis"])
    mapped: set[int] = set()
    projected_segments = []
    source_map = body["source_map"]
    need(isinstance(source_map, dict) and isinstance(source_map.get("segments"), list),
         f"{method['declaration']}: missing source-map segments")
    for segment in source_map["segments"]:
        start, end = segment.get("start"), segment.get("end")
        need(isinstance(start, int) and isinstance(end, int) and 0 <= start <= end <= len(text),
             f"{method['declaration']}: source-map byte range is outside UTF-8 text: {start}:{end}/{len(text)}")
        need(start in boundaries and end in boundaries,
             f"{method['declaration']}: source-map endpoint splits a UTF-8 code point: {start}:{end}")
        origin = segment.get("origin")
        need(isinstance(origin, dict) and isinstance(origin.get("primary"), dict),
             f"{method['declaration']}: source-map segment has no primary origin")
        origins = [origin["primary"], *origin.get("derived", [])]
        origin_projection = []
        for item in origins:
            bci = item.get("bci")
            need(isinstance(bci, int) and bci in expected_bcIs,
                 f"{method['declaration']}: source-map origin BCI is absent from target Code facts: {bci}")
            origin_method = item.get("method")
            need(isinstance(origin_method, dict), f"{method['declaration']}: origin has no method identity")
            owner = origin_method.get("owner")
            need(owner == class_owner,
                 f"{method['declaration']}: origin owner is not this report's same-class input owner")
            need(origin_method.get("name") == method["item"]["identity"]["name"]
                 and origin_method.get("descriptor") == method["item"]["identity"]["descriptor"],
                 f"{method['declaration']}: origin belongs to a different physical method")
            mapped.add(bci)
            origin_projection.append({
                "bci": bci,
                "cp": item.get("cp"),
                "provenance": item.get("provenance"),
                "method_name": origin_method["name"],
                "method_descriptor": origin_method["descriptor"],
            })
        projected_segments.append({"start": start, "end": end, "origins": origin_projection})
    projection = {"segments": projected_segments}
    return projection, mapped


def main() -> int:
    if len(sys.argv) != 3:
        raise SystemExit("usage: review-baseline.py EXECUTION_JSON NEW_REVIEW_JSON")
    execution_path, output_path = map(Path, sys.argv[1:])
    execution_raw = execution_path.read_bytes()
    execution = json.loads(execution_raw)
    need(not output_path.exists(), f"refusing to overwrite review: {output_path}")
    need(execution.get("schema") == "cf11-original-nestedloops3-baseline-v1",
         "unexpected baseline execution schema")
    need(execution.get("source_unchanged") is True and execution.get("dependencies_unchanged") is True,
         "baseline source/dependencies changed during capture")
    need(execution.get("target_absent") is True, "baseline receipt does not confirm target absence")

    command_rows = execution.get("commands")
    need(isinstance(command_rows, list) and len(command_rows) == 24,
         "expected the captured 24-command baseline")
    commands = {row["index"]: row for row in command_rows}
    need(len(commands) == len(command_rows), "duplicate command index")
    raw_streams = 0
    for row in command_rows:
        need(row.get("index") in commands and isinstance(row.get("streams"), dict),
             "malformed command/raw stream row")
        need(set(row["streams"]) == {"stdout", "stderr"},
             f"command {row['index']}: expected stdout and stderr raw pins")
        for stream_name, record in row["streams"].items():
            pin(record, f"command {row['index']} {stream_name}")
            raw_streams += 1
    need(raw_streams == 48, f"expected 48 command raw pins, observed {raw_streams}")

    oracle = pin(execution["oracle"], "original seven-line oracle").decode("utf-8", errors="strict")
    oracle_lines = oracle.splitlines()
    need(len(oracle_lines) == 7, f"original runtime oracle is not seven lines: {len(oracle_lines)}")
    runtime_rows = execution.get("original_runtime", [])
    need(len(runtime_rows) == 4, f"expected four original runtime invocations, got {len(runtime_rows)}")
    for runtime in runtime_rows:
        command = commands[runtime["command"]]
        stdout = pin(command["streams"]["stdout"], f"original runtime {runtime['command']} stdout")
        need(runtime.get("exit_code") == 0 and command.get("exit_code") == 0,
             f"original runtime command {runtime['command']} did not succeed")
        need(stdout == oracle.encode("utf-8") and sha(stdout) == runtime.get("oracle_sha256"),
             f"original runtime {runtime['command']} differs from the exact seven-line oracle")

    profile_rows = {row["profile"]: row for row in execution.get("profiles", [])}
    need(set(profile_rows) == {"debug", "no-debug"}, "debug/no-debug target facts are incomplete")
    jar_pins = {Path(row["path"]): row for row in execution.get("jar_pins", [])}
    cells = execution.get("jarde_cells", [])
    observed_cells = {(c.get("profile"), c.get("form"), c.get("evidence")) for c in cells}
    need(len(cells) == 8 and observed_cells == EXPECTED_CELLS, "Jarde cells are not the required exact 8-cell matrix")
    facts_by_profile = {}
    target_test_facts = {}
    for profile, profile_row in profile_rows.items():
        facts = profile_row["target"].get("methods", [])
        observed = [(m["name"], m["descriptor"], m["access"]) for m in facts]
        need(observed == EXPECTED_METHODS,
             f"{profile}: target Code facts do not contain the six expected physical methods in order")
        facts_by_profile[profile] = facts
        test_fact = next(row for row in facts if (row["name"], row["descriptor"]) == TARGET_IDENTITY)
        target_test_facts[profile] = test_fact["code"]
        pin(profile_row["target"], f"{profile} target class")
    debug_code = target_test_facts["debug"]
    no_debug_code = target_test_facts["no-debug"]
    need(debug_code == no_debug_code,
         "debug/no-debug target test(I)I Code facts differ")
    need(debug_code.get("code_length") == 42 and len(debug_code.get("bcis", [])) == 21
         and debug_code.get("rows") == [[29, 33, 36, 22]],
         "target test(I)I is not the pinned 42-byte, 21-instruction, one-row Code shape")

    cell_docs = {}
    report_pins = []
    method_inventory = None
    coverage = []
    for cell in cells:
        key = (cell["profile"], cell["form"], cell["evidence"])
        profile_row = profile_rows[cell["profile"]]
        input_record = cell["input"]
        input_data = pin(input_record, f"{key} input")
        if cell["form"] == "child":
            need(input_record["sha256"] == profile_row["target"]["sha256"],
                 f"{key}: standalone input does not match this profile's target class")
        else:
            need(Path(input_record["path"]).suffix == ".jar",
                 f"{key}: bundle-child input is not a jar file")
        command = commands[cell["command"]]
        need(cell.get("exit_code") == 0 and command.get("exit_code") == 0,
             f"{key}: Jarde request failed")
        report_bytes = pin(cell["report"], f"{key} report")
        need(report_bytes == pin(command["streams"]["stdout"], f"{key} report stdout"),
             f"{key}: command stdout differs from pinned JSON report")
        source_bytes = pin(cell["source"], f"{key} source output")
        report = json.loads(report_bytes.decode("utf-8", errors="strict"))
        need(report.get("text", "").encode("utf-8") == source_bytes,
             f"{key}: source output bytes differ from report text")
        report_pins.append({
            "profile": key[0], "form": key[1], "evidence": key[2],
            "input": {"bytes": len(input_data), "sha256": sha(input_data)},
            "command": cell["command"],
            "report": {"bytes": len(report_bytes), "sha256": sha(report_bytes)},
            "source": {"bytes": len(source_bytes), "sha256": sha(source_bytes)},
        })

        class_row = report["class"]
        class_bytes = class_row["class_bytes"]
        need(isinstance(class_bytes.get("digest"), str) and len(class_bytes["digest"]) == 64
             and class_bytes.get("length") == profile_row["target"]["bytes"],
             f"{key}: report owner has a malformed BLAKE3 class pin or wrong class length")
        location_kind = class_row["location"].get("kind")
        expected_location = "standalone_root" if key[1] == "child" else "archive_entry"
        need(location_kind == expected_location,
             f"{key}: owner binding kind {location_kind!r} differs from input form {expected_location!r}")
        if key[1] == "child":
            need(class_row["location"].get("snapshot") == class_bytes["digest"],
                 f"{key}: standalone snapshot and class BLAKE3 identity differ")
        else:
            entry = class_row["location"].get("entry", {})
            need(isinstance(entry.get("origin", {}).get("snapshot"), str)
                 and len(entry["origin"]["snapshot"]) == 64,
                 f"{key}: archive owner has no BLAKE3 root snapshot identity")
            raw_name = bytes(entry.get("raw_name", [])).decode("utf-8", errors="strict")
            need(raw_name == "jadx/tests/integration/loops/TestNestedLoops3$TestCls.class",
                 f"{key}: archive owner raw class path differs: {raw_name!r}")

        methods = report.get("methods", [])
        need(len(methods) == 6, f"{key}: expected all six physical methods")
        profile_facts = facts_by_profile[key[0]]
        identity_rows = []
        method_projection = {}
        for index, (method, fact) in enumerate(zip(methods, profile_facts)):
            item = method["item"]
            name = item["name"]["escaped"]
            descriptor = item["descriptor"]["escaped"]
            identity = item["identity"]
            expected_name, expected_descriptor, expected_access = EXPECTED_METHODS[index]
            need((name, descriptor, item["access_flags"], item["index"]) ==
                 (expected_name, expected_descriptor, expected_access, index),
                 f"{key}: physical method order/name/descriptor/access differs at index {index}")
            need(identity["name"] == item["name"]["raw"]
                 and identity["descriptor"] == item["descriptor"]["raw"],
                 f"{key}: identity bytes differ from the declared physical method")
            owner = identity["owner"]
            need(owner == class_row,
                 f"{key}: method {name}{descriptor} owner is not this report's class identity")
            body = method["outcome"]["report"]
            artifact_method = body.get("artifact", {}).get("binding", {}).get("method", {})
            need(artifact_method == identity,
                 f"{key}: body artifact identity differs from the method's same-class owner")
            need(body.get("method") == name + descriptor,
                 f"{key}: nested body report does not match physical method {name}{descriptor}")
            facts_row = (fact["name"], fact["descriptor"], fact["access"])
            need(facts_row == (name, descriptor, item["access_flags"]),
                 f"{key}: report method differs from the same-profile canonical Code facts")
            map_projection, mapped = utf8_projection_and_bcIs(method, fact, class_row)
            all_bcIs = set(fact["code"]["bcis"])
            missing = sorted(all_bcIs - mapped)
            unexpected = sorted(mapped - all_bcIs)
            quality = body.get("quality")
            need(quality in ("structured", "fallback"),
                 f"{key}: method-level body quality is missing or unknown for {name}{descriptor}")
            if quality == "structured":
                need(not missing and not unexpected,
                     f"{key}: structured method {name}{descriptor} lacks complete physical BCI coverage: {missing}")
            coverage.append({
                "cell": {"profile": key[0], "form": key[1], "evidence": key[2]},
                "method": name + descriptor,
                "quality": quality,
                "fact_bcis": sorted(all_bcIs),
                "mapped_bcis": sorted(mapped),
                "missing_bcis": missing,
                "unexpected_bcis": unexpected,
            })
            normalized_map = map_projection
            identity_rows.append({
                "index": index, "name": name, "descriptor": descriptor,
                "access_flags": item["access_flags"],
                "identity": identity,
                "owner_binding_kind": location_kind,
            })
            method_projection[name + descriptor] = {
                "declaration": method.get("declaration"),
                "class_source_text": method.get("text"),
                "quality": quality,
                "content": body.get("content"),
                "fallbacks": body.get("fallbacks"),
                "body_text": body.get("text"),
                "source_map": normalized_map,
            }
        if method_inventory is None:
            method_inventory = [{k: row[k] for k in ("index", "name", "descriptor", "access_flags")} for row in identity_rows]
        else:
            need([(row["index"], row["name"], row["descriptor"], row["access_flags"]) for row in identity_rows]
                 == [(row["index"], row["name"], row["descriptor"], row["access_flags"]) for row in method_inventory],
                 f"{key}: physical method inventory changed across inputs")
        cell_docs[key] = {"report": report, "source_bytes": source_bytes,
                          "projection": method_projection, "owner_kind": location_kind,
                          "class_identity": class_row, "method_identities": identity_rows}

    # Default/all is an evidence-mode comparison on the same input; declarations, rendered text,
    # quality, fallback reasons and full source-map projection must remain stable.
    default_all_checks = []
    for profile in ("debug", "no-debug"):
        for form in ("child", "bundle-child"):
            low = cell_docs[(profile, form, "default")]
            full = cell_docs[(profile, form, "all")]
            stable = low["report"].get("text") == full["report"].get("text") and low["projection"] == full["projection"]
            need(stable, f"{profile}/{form}: default/all text or method declaration/quality/fallback/map changed")
            default_all_checks.append({"profile": profile, "form": form, "equal": stable})

    # The five controls are stable in this eight-cell baseline only. Owner provenance is kept in
    # identity_rows above, but the semantic projection deliberately does not equate standalone and
    # archive entry identities across separate inputs.
    control_stability = {}
    for name in sorted(CONTROL_METHODS):
        key_name = next(row["name"] + row["descriptor"] for row in method_inventory if row["name"] == name)
        projections = [cell_docs[key]["projection"][key_name] for key in sorted(cell_docs)]
        stable = all(value == projections[0] for value in projections[1:])
        need(stable, f"control method {key_name} differs across the current eight configurations")
        control_stability[key_name] = "stable across these eight captured configurations"

    child_bundle_source = {}
    for profile in ("debug", "no-debug"):
        for evidence in ("default", "all"):
            child = cell_docs[(profile, "child", evidence)]["source_bytes"]
            bundle = cell_docs[(profile, "bundle-child", evidence)]["source_bytes"]
            child_bundle_source[f"{profile}/{evidence}"] = {
                "equal": child == bundle,
                "child_sha256": sha(child), "bundle_child_sha256": sha(bundle),
            }

    test_method = TARGET_IDENTITY[0] + TARGET_IDENTITY[1]
    test_rows = []
    for key, cell_doc in sorted(cell_docs.items()):
        method_projection = cell_doc["projection"][test_method]
        body_quality = method_projection["quality"]
        need(body_quality == "fallback", f"{key}: test(I)I unexpectedly is not fallback in this baseline")
        fallback_codes = method_projection["fallbacks"] or []
        need("jre_region_loop_shape" in fallback_codes and "jre_region_uncovered_blocks" in fallback_codes,
             f"{key}: expected loop-shape then uncovered-block fallback evidence is absent")
        body_text = method_projection["body_text"]
        need("local 2 crosses a quoted fallback region" in body_text,
             f"{key}: later local2 presentation gate explanation is missing")
        test_rows.append({
            "cell": {"profile": key[0], "form": key[1], "evidence": key[2]},
            "quality": body_quality,
            "content": method_projection["content"],
            "fallbacks": fallback_codes,
            "regions": cell_doc["report"]["methods"][1]["outcome"]["report"]["regions"],
            "interpretation": "The outward recovery record reports LoopShape at BCI 0; the exact classifier refusal still requires the separately executed IR diagnostic. The local 2 quoted-region note is a later presentation/definition-use gate.",
        })

    review = {
        "status": "read_only_baseline_review_complete",
        "input": {"path": str(execution_path), "bytes": len(execution_raw), "sha256": sha(execution_raw)},
        "checker": {"path": str(Path(__file__).resolve()), "bytes": Path(__file__).stat().st_size,
                    "sha256": sha(Path(__file__).read_bytes())},
        "matrix": {"cell_count": len(cells), "cells": [list(key) for key in sorted(cell_docs)]},
        "raw": {"command_count": len(command_rows), "stdout_stderr_pin_count": raw_streams,
                "jarde_cell_report_pins": len(report_pins), "report_pins": report_pins},
        "runtime_oracle": {"line_count": len(oracle_lines), "bytes": len(oracle.encode("utf-8")),
                           "sha256": sha(oracle.encode("utf-8")), "matching_runtime_invocations": len(runtime_rows),
                           "all_four_exact": True},
        "physical_methods": {"count": len(method_inventory), "inventory": method_inventory,
                             "sameclass_owner_checked_per_input": True,
                             "identities_by_cell": [
                                 {"cell": {"profile": key[0], "form": key[1], "evidence": key[2]},
                                  "owner_binding_kind": cell_docs[key]["owner_kind"],
                                  "methods": cell_docs[key]["method_identities"]}
                                 for key in sorted(cell_docs)]},
        "canonical_target_facts": {
            "test(I)I": {"debug_no_debug_Code_identical": True,
                         "code_length": debug_code["code_length"],
                         "instruction_count": len(debug_code["bcis"]),
                         "instruction_bcis": debug_code["bcis"],
                         "exception_table_rows": debug_code["rows"],
                         "note": "This is the method Code length and BCI list; do not confuse it with analysis-wide usage.code_bytes.",
                         "analysis_usage_code_bytes_are_not_method_code_length": [
                             cell_docs[key]["report"]["usage"]["code_bytes"] for key in sorted(cell_docs)]},
        },
        "default_all": default_all_checks,
        "child_bundle_source": child_bundle_source,
        "five_control_methods": control_stability,
        "test_method": {"identity": "test(I)I", "baseline_cells": test_rows,
                        "structured_complete_coverage_claim": False},
        "coverage_by_method": coverage,
        "limitations": [
            "This review describes only the captured baseline's eight Jarde requests and current source bytes; it is not a comparison with an older Jarde CLI.",
            "Fallback source maps retain only emitted explanation origins. Missing test(I)I BCIs are reported as coverage gaps, not as complete structured coverage.",
            "Original class and driver runtime agreement is checked against the captured seven-line oracle; whole-class rebuilt source execution remains for the separate final collector.",
        ],
        "capture_source_unchanged": execution.get("source_unchanged"),
        "capture_dependencies_unchanged": execution.get("dependencies_unchanged"),
        "capture_target_absent": execution.get("target_absent"),
        "digest_note": "Execution receipt input pins are SHA-256; Jarde report owner class_bytes.digest and snapshot are BLAKE3. The checker does not compare these digest algorithms or recompute BLAKE3; it checks owner identity consistency within each report, class length against the SHA-pinned canonical facts, and method/BCI facts against that profile.",
    }
    payload = json.dumps(review, indent=2, sort_keys=True) + "\n"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("x", encoding="utf-8") as handle:
        handle.write(payload)
    print(f"review complete: {len(cells)} Jarde cells, {raw_streams} raw streams; wrote {output_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
        raise SystemExit(f"baseline review failed: {error}")
