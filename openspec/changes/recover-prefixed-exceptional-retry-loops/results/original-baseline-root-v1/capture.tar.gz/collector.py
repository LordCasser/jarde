from pathlib import Path
import json,os,shutil,zipfile,importlib.util,sys,datetime
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018');OUT.mkdir();(OUT/'raw').mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','nl3_compare');g=load(ROOT/c.GUARD_REL,'nl3_guard');scan=load(ROOT/c.SCANNER_REL,'nl3_scan');assert c.sha(ROOT/c.GUARD_REL)==c.GUARD_SHA256 and c.sha(ROOT/c.SCANNER_REL)==c.SCANNER_SHA256
g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:scan.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
jdks,jdkpin=c.configured_jdks(ROOT/c.DEFAULT_JDK_MANIFEST_REL,c.DEFAULT_JDK_MANIFEST_SHA256)
assert not (ROOT/'target').exists() and shutil.disk_usage(ROOT).free>=5*1024**3
ref_path=Path('/private/tmp/jarde-tf3-original-inputs-root-v1-20261018/execution.json');ref=json.loads(ref_path.read_text());assert ref['source']['path'].endswith('TestFinally3.java')
for row in [ref['harness_jar'],*ref['jar_pins']]:assert c.pin(Path(row['path']))==row
for folder,expected in ref['directory_pins'].items():assert {p.relative_to(folder).as_posix():c.pin(p) for p in sorted(Path(folder).rglob('*.class'))}==expected
source=Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestNestedLoops3.java');assert c.sha(source)=='7152231b3aeb8419a6cfa5ecb9f639809386109233ce66af43143e0451b0ea72'
(OUT/'source').mkdir();copy=OUT/'source'/source.name;shutil.copy2(source,copy);(OUT/'empty-sourcepath').mkdir()
prep=Path('/private/tmp/jarde-testnestedloops3-original-prep-luna-v2-20261018');driver=OUT/'driver-source/TestNestedLoops3Driver.java';driver.parent.mkdir();shutil.copy2(prep/'driver/TestNestedLoops3Driver.java',driver)
bound=Path('/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py');shutil.copy2(bound,OUT/bound.name)
cli=Path('/private/tmp/jarde-switch-final-focused-root-v5-20261018/candidate-cli');assert c.sha(cli)=='10a73d1ee30a3820a018a2461cc3c3b3028b02bf658588bc74c4ec3ba2eb1620'
jadx=Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx');assert c.sha(jadx)=='64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
assertj=next(Path(p) for p in ref['classpath'] if Path(p).name.startswith('assertj-core-'));cp=ref['classpath'];cp_string=os.pathsep.join(cp)
with zipfile.ZipFile(ref['harness_jar']['path']) as z:assert not any('TestNestedLoops3' in name for name in z.namelist())
rows=[];report={'schema':'cf11-original-nestedloops3-baseline-v1','status':'running','source':c.pin(source),'source_copy':c.pin(copy),'dependency_reference':c.pin(ref_path),'dependency_reference_input':'TestFinally3; dependency pins only, not target execution evidence','classpath':cp,'harness_jar':ref['harness_jar'],'directory_pins_before':ref['directory_pins'],'jar_pins':ref['jar_pins'],'jdk':jdkpin,'cli':c.pin(cli),'jadx':c.pin(jadx),'jadx_jar':c.pin(Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')),'source_before':c.source_closure(ROOT),'driver':c.pin(driver),'runtime_bound':c.pin(bound),'commands':rows,'profiles':[],'original_runtime':[],'jarde_cells':[],'jadx_cells':[],'notes':['Complete upstream outer source and whole nested target are unchanged.','Original source compilation uses javac23 --release8; javac8/harness-major55 boundary is a separate attempted failure.','Each runtime has exactly target root, independently compiled driver root and the pinned AssertJ jar; no original target cache is on the rebuild classpath.']}
def save():c.write_json(OUT/'execution.json',report)
def cmd(argv,label,leg='javac23'):
 assert not (ROOT/'target').exists();env=c.clean_env(dict(os.environ),jdks[leg]);env.update(g.ENV_VALUES);env.pop('RUST_MIN_STACK',None);r=g.run_command(len(rows)+1,[str(x) for x in argv],env);r['label']=label;r['tool_leg']=leg;rows.append(r);save();assert r['guard_stop'] is None;return r
save()
try:
 dest=OUT/'javac8-boundary/classes';dest.mkdir(parents=True)
 r=cmd([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-classpath',cp_string,'-sourcepath',OUT/'empty-sourcepath','-d',dest,copy],'original-javac8-harness-boundary','javac8');report['javac8_boundary']={'command':r['index'],'exit_code':r['exit_code'],'class_outputs':[c.pin(p) for p in dest.rglob('*.class')]};assert r['exit_code']!=0 and b'55.0' in c.command_artifact(r,'stderr')
 for profile,flag in [('debug','-g'),('no-debug','-g:none')]:
  dest=OUT/profile/'classes';dest.mkdir(parents=True);r=cmd([jdks['javac23']['tools']['javac'],'--release','8',flag,'-encoding','UTF-8','-proc:none','-classpath',cp_string,'-sourcepath',OUT/'empty-sourcepath','-d',dest,copy],'original-compile-'+profile);assert r['exit_code']==0
  target=dest/'jadx/tests/integration/loops/TestNestedLoops3$TestCls.class';outer=dest/'jadx/tests/integration/loops/TestNestedLoops3.class';assert sorted(p.name for p in dest.rglob('*.class'))==['TestNestedLoops3$TestCls.class','TestNestedLoops3.class']
  facts=c.parse_class(target);assert facts['major']==52 and {(m['name'],m['descriptor']) for m in facts['methods']}=={('<init>','()V'),('test','(I)I'),('exc','()V'),('f1','()V'),('f2','()V'),('check','()V')}
  rec={'profile':profile,'compile_command':r['index'],'target':facts,'outer':c.parse_class(outer),'classes':str(dest)};report['profiles'].append(rec);r=cmd([jdks['javac23']['tools']['javap'],'-p','-s','-c','-v',target],'original-javap-'+profile);assert r['exit_code']==0;rec['javap_command']=r['index'];save()
 driver_classes=OUT/'driver-classes';driver_classes.mkdir();r=cmd([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-classpath',OUT/'empty-sourcepath','-sourcepath',OUT/'empty-sourcepath','-d',driver_classes,driver],'compile-independent-driver','javac8');assert r['exit_code']==0;report['driver_classes']=[c.pin(p) for p in driver_classes.rglob('*.class')]
 oracles=[]
 for rec in report['profiles']:
  for leg in ['javac8','javac23']:
   roots=[rec['classes'],str(driver_classes),str(assertj)];argv=[sys.executable,'-B',bound,'30',jdks[leg]['tools']['java'],'-Xverify:all','-cp',os.pathsep.join(roots),'TestNestedLoops3Driver',rec['classes']];r=cmd(argv,'original-runtime-'+rec['profile']+'-'+leg,leg)
   cell={'profile':rec['profile'],'runtime':leg,'command':r['index'],'exit_code':r['exit_code'],'classpath':roots};report['original_runtime'].append(cell);assert r['exit_code']==0
   b=c.command_artifact(r,'stdout');assert len(b.splitlines())==7;oracles.append(b);cell['oracle_sha256']=c.sha(Path(r['streams']['stdout']['path']));save()
 assert len(set(oracles))==1;(OUT/'original-oracle.stdout').write_bytes(oracles[0]);report['oracle']=c.pin(OUT/'original-oracle.stdout')
 r=cmd([sys.executable,'-B',bound,'30',jdks['javac23']['tools']['java'],'-Xverify:all','-cp',os.pathsep.join([report['profiles'][0]['classes'],str(driver_classes),str(assertj)]),'TestNestedLoops3Driver',OUT/'empty-sourcepath'],'driver-wrong-root-control');assert r['exit_code']!=0 and b'target loaded from' in c.command_artifact(r,'stderr');report['wrong_root_control_command']=r['index']
 r=cmd([jadx,'--version'],'jadx-version');assert r['exit_code']==0
 for rec in report['profiles']:
  profile=rec['profile'];classes=Path(rec['classes']);target=Path(rec['target']['path']);bundle=OUT/(profile+'.jar')
  with zipfile.ZipFile(bundle,'w') as z:
   for p in sorted(classes.rglob('*.class')):z.writestr(zipfile.ZipInfo(p.relative_to(classes).as_posix(),(1980,1,1,0,0,0)),p.read_bytes())
  for form,inp,policy in [('child',target,'single-class'),('bundle-child',bundle,'plain-jar')]:
   for evidence in ['default','all']:
    argv=[cli,'class-source','--input',inp,'--policy',policy,'--release','8','--class','jadx/tests/integration/loops/TestNestedLoops3$TestCls','--format','json'];argv+=['--evidence','all'] if evidence=='all' else []
    r=cmd(argv,'jarde-'+profile+'-'+form+'-'+evidence);raw=c.command_artifact(r,'stdout');doc=json.loads(raw);dest=OUT/'jarde'/profile/form/evidence;dest.mkdir(parents=True);(dest/'report.json').write_bytes(raw)
    if isinstance(doc.get('text'),str):(dest/'source.java').write_text(doc['text'])
    report['jarde_cells'].append({'profile':profile,'form':form,'evidence':evidence,'command':r['index'],'input':c.pin(inp),'exit_code':r['exit_code'],'report':c.pin(dest/'report.json'),'source':c.pin(dest/'source.java') if (dest/'source.java').exists() else None});save()
  for form,inp in [('child',target),('bundle',bundle)]:
   dest=OUT/'jadx'/profile/form;r=cmd([jadx,'--config','none','--threads-count','1','--no-res','--rename-flags','none','-d',dest,inp],'jadx-'+profile+'-'+form);report['jadx_cells'].append({'profile':profile,'form':form,'command':r['index'],'input':c.pin(inp),'exit_code':r['exit_code'],'sources':[c.pin(p) for p in sorted(dest.rglob('*.java'))]});save()
 report['source_after']=c.source_closure(ROOT);assert report['source_after']==report['source_before'];assert c.pin(source)==report['source'] and c.pin(copy)==report['source_copy']
 for row in [ref['harness_jar'],*ref['jar_pins']]:assert c.pin(Path(row['path']))==row
 for folder,expected in ref['directory_pins'].items():assert {p.relative_to(folder).as_posix():c.pin(p) for p in sorted(Path(folder).rglob('*.class'))}==expected
 report['source_unchanged']=True;report['dependencies_unchanged']=True;report['target_absent']=not (ROOT/'target').exists();assert report['target_absent'];report['status']='captured pending independent whole-source rebuild review'
except BaseException as e:report['status']='failed';report['error']=str(e);raise
finally:
 report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();shutil.copy2(__file__,OUT/'collector.py');print(json.dumps({k:report.get(k) for k in ['status','error','source_unchanged','target_absent']}))
