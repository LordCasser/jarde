#!/usr/bin/env python3
"""Independently verify one prefixed-retry product's complete CI receipt (read only)."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
REPO = 'LordCasser/jarde'
FIXTURE_ROOT = 'tests/fixtures/recover-prefixed-exceptional-retry-loops'
FIXTURE_FILE_COUNT = 34
SOURCE_PATHS = (
    '.github/workflows/ci.yml', 'Cargo.toml', 'Cargo.lock',
    'crates/jarde-java/src/region.rs',
    'crates/jarde-java/src/region/protected_prefix_loop_tests.rs',
    'crates/jarde-java/tests/p3_prefixed_exceptional_retry_loops.rs',
    'crates/jarde-reader/src/classfile.rs', 'crates/jarde-java/src/build.rs',
    'crates/jarde-java/src/guard.rs', 'crates/jarde-java/src/normal_flow.rs',
    'tests/fixtures/corpus-fingerprint.json',
)
EXPECTED_JOBS = {
    'stable': 'stable / test and specification',
    'msrv': 'MSRV 1.88.0',
    'supply-chain': 'supply chain',
    'fuzz-smoke': 'fuzz smoke',
}
WORKSPACE_COMMAND = 'cargo test --workspace --all-targets --all-features --locked'
CRITICAL_TESTS = {
    'prefixed retry library proof': ('prefixed_exceptional_retry_uses_distinct_protected_and_handler_loop_edges', 'jarde_java'),
    'prefixed retry budget transaction': ('prefixed_exceptional_retry_late_budget_stop_restores_the_candidate_state', 'jarde_java'),
    'effectful bridge refusal': ('effectful_normal_join_bridge_is_refused_by_the_retry_certificate', 'jarde_java'),
    'outer-header catch refusal': ('catch_returning_to_the_outer_header_is_not_a_retry_continue', 'jarde_java'),
    'canonical row identity': ('retry_facts_require_the_physical_row_to_match_the_same_canonical_row', 'jarde_java'),
    'reader checkpoint stop': ('retry_facts_preserve_the_full_reader_checkpoint_on_cancel_and_deadline', 'jarde_java'),
    'owner edge closure': ('retry_owner_edge_closure_rejects_each_unowned_edge_class', 'jarde_java'),
    'original class-source matrix': ('prefixed_exceptional_retry_loop_is_structured_for_debug_and_no_debug_inputs', 'p3_prefixed_exceptional_retry_loops'),
    'public recovery late stop': ('prefixed_exceptional_retry_late_recovery_budget_publishes_no_source_or_map', 'p3_prefixed_exceptional_retry_loops'),
    'supplemental compiler/profile matrix': ('supplemental_pure_latch_bridges_keep_every_physical_source_origin', 'p3_prefixed_exceptional_retry_loops'),
}

CRITICAL_TESTS = {label: (('region::protected_prefix_loop_tests::' + name) if target == 'jarde_java' else name, target) for label, (name, target) in CRITICAL_TESTS.items()}

ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
SUMMARY = re.compile(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out(?:; finished in .*)?$')
NAME_FRAGMENT = r'(?:[A-Za-z0-9_]|(?<!\*)\*\*\*(?!\*))+'
OUTCOME = re.compile(rf'^test ((?:{NAME_FRAGMENT})(?:::(?:{NAME_FRAGMENT}))*)(?: - should panic)? \.\.\. (ok|FAILED|ignored(?:, .*)?)$')
RUNNING = re.compile(r'^running (\d+) tests?$', re.IGNORECASE)
RUN_TARGET = re.compile(r'^Running .+ \((?P<path>[^()]+)\)$')
HASHED_EXE = re.compile(r'(?P<target>[^/]+)-(?P<hash>[0-9a-f]{16})')


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def clean_line(line: str) -> str:
    line = ANSI.sub('', line).strip()
    line = re.sub(r'\^\[\[[0-?]*[ -/]*[@-~]', '', line)
    line = re.sub(r'^[^\t\n]+\t[^\t\n]+\t(?=\d{4}-\d\d-\d\dT)', '', line)
    line = re.sub(r'^\d{4}-\d\d-\d\d[T ][^ ]+Z\s+', '', line)
    return line.strip()


def workflow_contract(path: Path):
    text = path.read_text(encoding='utf-8')
    lines = text.splitlines()
    jobs = {}
    i = next((n for n, line in enumerate(lines) if line == 'jobs:'), None)
    need(i is not None, 'CI workflow has no jobs section')
    i += 1
    while i < len(lines):
        m = re.match(r'^  ([a-z][a-z0-9-]*):\s*$', lines[i])
        if m:
            job_id = m.group(1)
            block = []
            i += 1
            while i < len(lines) and not re.match(r'^  [a-z][a-z0-9-]*:\s*$', lines[i]) and not re.match(r'^[^ ]', lines[i]):
                block.append(lines[i])
                i += 1
            display_match = next((re.match(r'^    name:\s*(.*?)\s*$', row) for row in block if re.match(r'^    name:', row)), None)
            display = display_match.group(1).strip('\"\'') if display_match else None
            api_steps = []
            run_steps = []
            j = 0
            while j < len(block):
                step = re.match(r'^      - (name|uses):\s*(.*?)\s*$', block[j])
                if not step:
                    j += 1
                    continue
                kind, value = step.group(1), step.group(2).strip('\"\'')
                k = j + 1
                has_run = bool(re.match(r'^        run:', block[j]))
                while k < len(block) and not re.match(r'^      - (?:name|uses):', block[k]):
                    has_run |= bool(re.match(r'^        run:', block[k]))
                    k += 1
                if kind == 'name':
                    api_steps.append(value)
                    if has_run:
                        run_steps.append(value)
                else:
                    api_steps.append(f'Run {value}')
                j = k
            jobs[job_id] = {'display': display, 'api_steps': api_steps, 'run_steps': run_steps}
        else:
            i += 1
    need(set(jobs) == set(EXPECTED_JOBS), f'CI job IDs differ from reviewed contract: {sorted(jobs)}')
    for job_id, display in EXPECTED_JOBS.items():
        need(jobs[job_id]['display'] == display, f'CI job display name changed: {job_id}')
        need(jobs[job_id]['api_steps'] and jobs[job_id]['run_steps'], f'CI workflow has incomplete steps: {job_id}')
    required_run_steps = {
        'stable': {
            'Install stable Rust with lint components', 'Install Temurin 25.0.4+7', 'Run Clippy',
            'Run workspace tests with two fixed independent seeds (pass 1)',
            'Run workspace tests with two fixed independent seeds (pass 2)',
            'Run ignored JDK 25 instruction-boundary oracle',
            'Run the ignored P3 Java 8 compile-and-execute comparison',
            'Run the functional-constructor full-class comparison',
            'Run the BigDecimal Number full-class comparisons',
            'Run the nested int array full-class comparisons',
            'Run the returned int array full-class comparison',
        },
        'msrv': {'Install Rust 1.88.0', 'Check workspace on MSRV'},
        'supply-chain': {
            'Install cargo-deny 0.20.2',
            'Check root workspace advisories, licenses, bans, and sources',
            'Check fuzz workspace advisories, licenses, bans, and sources',
        },
        'fuzz-smoke': {
            'Install nightly-2026-07-20', 'Install cargo-fuzz 0.13.2',
            'Check the committed corpus against the targets', 'Run the bounded query smoke',
            'Run the bounded artifact-tree smoke', 'Run the bounded method-analysis smoke',
        },
    }
    for job_id, required in required_run_steps.items():
        need(required.issubset(set(jobs[job_id]['api_steps'])),
             f'required platform/JDK/MSRV/Clippy/extra gate missing in {job_id}: {sorted(required - set(jobs[job_id]["api_steps"]))}')

    seeds = []
    for name in ('Run workspace tests with two fixed independent seeds (pass 1)',
                 'Run workspace tests with two fixed independent seeds (pass 2)'):
        match = re.search(r'(?ms)^      - name: ' + re.escape(name) + r'\n(.*?)(?=^      - (?:name|uses):|^  [a-z][a-z0-9-]*:|\Z)', text)
        need(match is not None, f'CI workflow is missing workspace run step {name}')
        block = match.group(1)
        cmd = re.search(r'(?m)^        run:\s*(.*?)\s*$', block)
        seed = re.search(r'(?m)^          PROPTEST_RNG_SEED:\s*["\']?(\d+)', block)
        need(cmd and cmd.group(1).strip('\"\'') == WORKSPACE_COMMAND, f'workspace command changed: {name}')
        need(seed is not None, f'workspace seed is absent: {name}')
        seeds.append(seed.group(1))
    need(len(set(seeds)) == 2, f'workspace seeds must be distinct: {seeds}')
    return text, jobs, tuple(seeds)


def validate_collection(evidence: Path, product: str, repo: Path):
    receipt = read_json(evidence / 'collection.json')
    need(receipt.get('status') == 'raw collection complete; independent acceptance pending', 'collector did not finish raw collection')
    need(receipt.get('product_sha') == product, 'collector receipt product SHA mismatch')
    need(receipt.get('source_before_after_equal') is True and receipt.get('target_absent_after') is True,
         'collector did not confirm unchanged source and absent target')
    fixture_paths = sorted(p.relative_to(repo).as_posix() for p in (repo / FIXTURE_ROOT).rglob('*') if p.is_file())
    need(len(fixture_paths) == FIXTURE_FILE_COUNT, f'current fixture inventory is not {FIXTURE_FILE_COUNT} files')
    need(receipt.get('fixture_files') == fixture_paths, 'collector fixture inventory differs from complete current inventory')
    sources = sorted(set(SOURCE_PATHS) | set(fixture_paths))
    need(receipt.get('source_paths') == list(SOURCE_PATHS), 'collector source path inventory changed')
    need(receipt.get('fixture_file_count') == FIXTURE_FILE_COUNT and receipt.get('source_file_count') == len(SOURCE_PATHS),
         'collector source counts are inconsistent')
    commands = receipt.get('commands')
    need(isinstance(commands, list) and commands, 'collector has no commands')
    for row in commands:
        need(row.get('exit_code') == 0, f'collector command failed: {row.get("argv")}')
        for channel in ('stdout', 'stderr'):
            pin = row.get('streams', {}).get(channel, {})
            path = Path(pin.get('path', ''))
            need(path.is_absolute() and path.is_file(), f'raw command {channel} is absent')
            data = path.read_bytes()
            need(pin.get('bytes') == len(data) and pin.get('sha256') == sha(data), f'raw command {channel} pin mismatch: {path}')
    pin_doc = read_json(evidence / 'source-pins.json')
    need(pin_doc.get('product_sha') == product and pin_doc.get('fixture_root') == FIXTURE_ROOT, 'source-pins product/fixture root mismatch')
    source_rows, fixture_rows = pin_doc.get('source_files'), pin_doc.get('fixture_files')
    need(isinstance(source_rows, dict) and set(source_rows) == set(SOURCE_PATHS), 'source pin inventory differs')
    need(isinstance(fixture_rows, dict) and set(fixture_rows) == set(fixture_paths), 'fixture pin inventory differs')
    for rel in sources:
        is_fixture = rel.startswith(FIXTURE_ROOT + '/')
        path = evidence / ('product-fixtures' if is_fixture else 'product-source') / rel
        pinned = path.read_bytes()
        current = (repo / rel).read_bytes()
        row = fixture_rows[rel] if is_fixture else source_rows[rel]
        need(pinned == current, f'product git-show differs from current file: {rel}')
        need(row.get('git_show') == f'git show {product}:{rel}' and row.get('bytes') == len(pinned) and row.get('sha256') == sha(pinned),
             f'product source pin mismatch: {rel}')
    workflow_pin = source_rows['.github/workflows/ci.yml']['sha256']
    need((evidence / 'workflow.sha256').read_text(encoding='ascii').strip() == workflow_pin, 'workflow pin file mismatch')
    expected_commands = 2 + len(EXPECTED_JOBS) + len(sources)
    need(len(commands) == expected_commands, f'collector command count mismatch: {len(commands)} != {expected_commands}')
    by_stdout = {}
    for row in commands:
        path = Path(row['streams']['stdout']['path']).resolve()
        need(path.is_relative_to(evidence), f'command output escapes evidence directory: {path}')
        rel = path.relative_to(evidence).as_posix()
        need(rel not in by_stdout, f'duplicate command output path: {rel}')
        by_stdout[rel] = row
        need(Path(row['streams']['stderr']['path']).resolve() == Path(str(path) + '.stderr.raw'),
             f'stderr path does not pair with stdout artifact: {rel}')
    run_id = str(receipt.get('run_id'))
    expected_args = {
        'run.json': ['gh', 'run', 'view', run_id, '--repo', REPO,
                     '--json', 'jobs,headSha,status,conclusion,url,databaseId,workflowName'],
        'jobs-api.json': ['gh', 'api', f'repos/{REPO}/actions/runs/{run_id}/jobs?per_page=100'],
    }
    run_doc = read_json(evidence / 'run.json')
    run_jobs = run_doc.get('jobs', [])
    jobs_by_name = {job.get('name'): job for job in run_jobs}
    need(set(jobs_by_name) == set(EXPECTED_JOBS.values()), 'run.json job names differ while verifying command arguments')
    for slug, display in EXPECTED_JOBS.items():
        expected_args[slug + '.log'] = ['gh', 'run', 'view', run_id, '--repo', REPO,
                                        '--job', str(jobs_by_name[display].get('databaseId')), '--log']
    for rel in sources:
        out_rel = ('product-fixtures/' if rel.startswith(FIXTURE_ROOT + '/') else 'product-source/') + rel
        expected_args[out_rel] = ['git', 'show', product + ':' + rel]
    need(set(by_stdout) == set(expected_args), 'raw command output inventory differs from expected gh/git-show requests')
    for rel, argv in expected_args.items():
        need(by_stdout[rel].get('argv') == argv and by_stdout[rel].get('exit_code') == 0,
             f'raw command arguments/result differ from requested evidence operation: {rel}')
    return receipt, pin_doc


def official_step_logs(evidence: Path):
    supplement = read_json(evidence / 'step-log-supplement.json')
    need(supplement['argv'] == ['gh', 'api', f'repos/{REPO}/actions/runs/{receipt_run_id(evidence)}/logs'] and supplement['exit_code'] == 0, 'official step archive request mismatch')
    for channel in ('stdout', 'stderr'):
        pin = supplement['streams'][channel]
        path = Path(pin['path'])
        need(path.parent == evidence and path.is_file(), 'official archive stream path mismatch')
        data = path.read_bytes()
        need(len(data) == pin['bytes'] and sha(data) == pin['sha256'], 'official archive stream pin mismatch')
    need(Path(supplement['streams']['stdout']['path']) == evidence / 'run-logs.zip', 'official archive path mismatch')
    api = read_json(evidence / 'jobs-api.json')
    logs = {}
    with zipfile.ZipFile(evidence / 'run-logs.zip') as archive:
        names = archive.namelist()
        need(len(names) == len(set(names)), 'duplicate official archive entry')
        for job in api['jobs']:
            display = job['name']
            folder = display.replace('/', '_')
            lines = []
            for step in job['steps']:
                name = f"{folder}/{step['number']}_{step['name'].replace('/', '_')}.txt"
                need(name in names, f'official archive omits API step: {name}')
                raw = archive.read(name)
                lines.extend(f"{display}\t{step['name']}\t{line}" for line in raw.decode('utf-8-sig').splitlines())
            logs[display] = '\n'.join(lines) + '\n'
    return logs


def validate_ci(evidence: Path, product: str, workflow_jobs: dict):
    run = read_json(evidence / 'run.json')
    api = read_json(evidence / 'jobs-api.json')
    need(run.get('headSha') == product and run.get('status') == 'completed' and run.get('conclusion') == 'success', 'CI run head/status/conclusion failed')
    need(run.get('workflowName') == 'CI', 'CI workflow identity mismatch')
    need(api.get('total_count') == 4 and isinstance(api.get('jobs'), list) and len(api['jobs']) == 4, 'GitHub jobs API is incomplete')
    run_jobs = run.get('jobs')
    need(isinstance(run_jobs, list) and len(run_jobs) == 4, 'gh run view job inventory incomplete')
    by_name = {row.get('name'): row for row in run_jobs}
    api_by_id = {row.get('id'): row for row in api['jobs']}
    need(len(by_name) == 4 and set(by_name) == set(EXPECTED_JOBS.values()) and len(api_by_id) == 4, 'CI job inventory differs')
    report, total_steps = {}, 0
    official = official_step_logs(evidence)
    for job_id, display in EXPECTED_JOBS.items():
        run_job = by_name[display]
        api_job = api_by_id.get(run_job.get('databaseId'))
        need(api_job is not None and api_job.get('name') == display, f'jobs API omitted or renamed {display}')
        need(run_job.get('status') == 'completed' and run_job.get('conclusion') == 'success'
             and api_job.get('status') == 'completed' and api_job.get('conclusion') == 'success', f'job failed or incomplete: {display}')
        run_steps, api_steps = run_job.get('steps'), api_job.get('steps')
        need(isinstance(run_steps, list) and isinstance(api_steps, list) and len(run_steps) == len(api_steps) and run_steps,
             f'job step inventory incomplete: {display}')
        for left, right in zip(run_steps, api_steps):
            need(left.get('name') == right.get('name'), f'run view and jobs API step order mismatch: {display}')
            need(left.get('status') == 'completed' and left.get('conclusion') == 'success'
                 and right.get('status') == 'completed' and right.get('conclusion') == 'success',
                 f'non-success workflow step in {display}: {left.get("name")}')
        names = [step.get('name') for step in api_steps]
        need(all(isinstance(name, str) and name for name in names), f'unnamed API step in {display}')
        expected = workflow_jobs[job_id]['api_steps']
        observed = [name for name in names if name not in ('Set up job', 'Complete job') and not name.startswith('Post ')]
        need(observed == expected, f'actual step sequence differs from workflow for {display}')
        posts = [name[5:] for name in names if name.startswith('Post ')]
        need(len(posts) == len(set(posts)) and all(name in expected for name in posts), f'unknown/duplicate post-action in {display}')
        need(names and names[0] == 'Set up job' and names[-1] == 'Complete job', f'job lifecycle steps invalid: {display}')
        need(len(names) == len(expected) + len(posts) + 2 and len(names) == len(set(names)), f'extra/duplicate API step in {display}')
        total_steps += len(names)
        report[job_id] = {'display_name': display, 'steps': len(names), 'successful_steps': len(names),
                          'workflow_steps': len(expected), 'run_steps': len(workflow_jobs[job_id]['run_steps'])}
        log = evidence / (job_id + '.log')
        need(log.is_file() and log.stat().st_size > 0, f'complete raw job log is absent: {job_id}')
        log_rows = [line.split('\t', 2) for line in official[display].splitlines()]
        labels = {row[1] for row in log_rows if len(row) == 3 and row[0] == display}
        need(labels, f'raw job log has no records for {display}')
        need({row[0] for row in log_rows if len(row) == 3} == {display}, f'raw log mixes job identities: {display}')
        need(set(workflow_jobs[job_id]['run_steps']).issubset(labels), f'raw job log omits named run-step output: {display}')
    need(str(receipt_run_id(evidence)) == str(run.get('databaseId')), 'run ID differs between receipt and captured CI run')
    return run, report, total_steps


def receipt_run_id(evidence: Path):
    return read_json(evidence / 'collection.json').get('run_id')


def workspace_groups(raw: str):
    lines = raw.splitlines()
    starts = [i for i, line in enumerate(lines) if '##[group]Run ' + WORKSPACE_COMMAND in clean_line(line)]
    need(len(starts) == 2, f'stable log must contain exactly two complete workspace runs, found {len(starts)}')
    groups = []
    for p, start in enumerate(starts):
        end = starts[p + 1] if p + 1 < len(starts) else len(lines)
        for n in range(start + 1, end):
            if '##[group]' in clean_line(lines[n]):
                end = n
                break
        groups.append('\n'.join(lines[start:end]))
    return groups


def parse_workspace_group(group: str, seed: str):
    lines = [clean_line(line) for line in group.splitlines()]
    env = [re.fullmatch(r'PROPTEST_RNG_SEED:\s*["\']?(\d+)["\']?', line) for line in lines if 'PROPTEST_RNG_SEED:' in line]
    need(len(env) == 1 and env[0] is not None and env[0].group(1) == seed, f'workspace log seed differs from workflow: {seed}')
    headers = [line for line in lines if line.startswith('Running ')]
    outcomes, rows = [], []
    i = 0
    while i < len(lines):
        m = RUNNING.fullmatch(lines[i])
        if not m:
            if lines[i].startswith('test result:'):
                raise ValueError(f'test summary without running block: {lines[i]}')
            i += 1
            continue
        declared, named = int(m.group(1)), []
        j = i + 1
        while j < len(lines):
            summary = SUMMARY.fullmatch(lines[j])
            if summary:
                counts = tuple(int(summary.group(n)) for n in range(2, 5))
                measured, filtered = int(summary.group(5)), int(summary.group(6))
                need((summary.group(1) == 'ok') == (counts[1] == 0), f'summary status/count mismatch: {lines[j]}')
                need(declared == len(named), f'running count differs from named outcomes: {declared} != {len(named)}')
                seen = (sum(state == 'ok' for _, state in named), sum(state == 'FAILED' for _, state in named), sum(state == 'ignored' for _, state in named))
                need(seen == counts, f'named test results do not reconstruct summary: {seen} != {counts}')
                need(counts[1] == 0 and filtered == 0, f'target failed or filtered tests: {lines[j]}')
                rows.append({'named_tests': declared, 'passed': counts[0], 'failed': counts[1], 'ignored': counts[2],
                             'measured': measured, 'filtered': filtered, '_named': named})
                i = j + 1
                break
            result = OUTCOME.fullmatch(lines[j])
            if result:
                raw_state = result.group(2)
                named.append((result.group(1), 'ignored' if raw_state.startswith('ignored') else raw_state))
            elif lines[j].startswith('test result:') or lines[j].startswith('test '):
                raise ValueError(f'unparsed cargo test output: {lines[j]}')
            j += 1
        else:
            raise ValueError(f'running block has no complete summary: {lines[i]}')
    need(rows and len(headers) == len(rows), 'workspace target headers and summaries are incomplete')
    for row, header in zip(rows, headers):
        match = RUN_TARGET.fullmatch(header)
        need(match is not None, f'unparsed Cargo Running header: {header!r}')
        executable = match.group('path').rsplit('/', 1)[-1]
        executable_match = HASHED_EXE.fullmatch(executable)
        need(executable_match is not None, f'unrecognized Cargo executable: {executable!r}')
        row['target_header'], row['target_executable'] = header, executable
        row['target_name'] = executable_match.group('target')
        outcomes.extend((name, state, row['target_name']) for name, state in row.pop('_named'))
    need(sum(row['named_tests'] for row in rows) == len(outcomes), 'not every observed test result is accounted for')
    inventory = [row['target_header'] for row in rows]
    need(len(inventory) == len(set(inventory)), 'duplicate cargo target header')
    checks = {}
    for label, (name, target) in CRITICAL_TESTS.items():
        matches = [(state, target_name) for seen, state, target_name in outcomes
                   if seen == name and target_name == target]
        need(len(matches) == 1 and matches[0][0] == 'ok', f'critical test missing/duplicated/failing under exact target: {label}')
        checks[label] = name
    totals = {key: sum(row[key] for row in rows) for key in ('passed', 'failed', 'ignored', 'measured', 'filtered')}
    need(totals['failed'] == 0 and totals['filtered'] == 0, 'workspace run has failed or filtered tests')
    return {'seed': seed, 'target_count': len(rows), 'target_inventory': inventory,
            'target_summaries': rows, 'named_test_outcomes': len(outcomes),
            'workspace_totals': totals, 'critical_tests_passed': checks}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence_dir', type=Path)
    parser.add_argument('--product-sha', required=True)
    parser.add_argument('--repo', type=Path, default=ROOT)
    args = parser.parse_args()
    need(re.fullmatch(r'[0-9a-f]{40}', args.product_sha) is not None, 'PRODUCT_SHA must be lowercase full SHA')
    evidence, repo = args.evidence_dir.resolve(strict=True), args.repo.resolve(strict=True)
    receipt, pins = validate_collection(evidence, args.product_sha, repo)
    workflow, jobs_contract, seeds = workflow_contract(repo / '.github/workflows/ci.yml')
    need(pins['source_files']['.github/workflows/ci.yml']['sha256'] == sha(workflow.encode()), 'captured workflow differs from current source')
    run, jobs, total_steps = validate_ci(evidence, args.product_sha, jobs_contract)
    log = official_step_logs(evidence)[EXPECTED_JOBS['stable']]
    seed_runs = [parse_workspace_group(group, seed) for group, seed in zip(workspace_groups(log), seeds)]
    need(seed_runs[0]['seed'] == seeds[0] and seed_runs[1]['seed'] == seeds[1], 'seed order differs from current workflow')
    need(seed_runs[0]['target_summaries'] == seed_runs[1]['target_summaries'], 'complete per-target summaries differ across the two seeds')
    need(seed_runs[0]['target_inventory'] == seed_runs[1]['target_inventory'], 'target inventory differs across seeds')
    need(len(seed_runs[0]['critical_tests_passed']) == len(CRITICAL_TESTS) == 10, 'critical gate inventory changed')
    report = {
        'status': 'accepted', 'step_log_authority': 'GitHub official run-logs.zip per-step members bound to all API step numbers and names; original gh raw logs preserved (stable UNKNOWN STEP display limitation)', 'supplemental_log_command_count': 1, 'product': {'head_sha': run['headSha'], 'expected_sha': args.product_sha},
        'collection': {'run_id': receipt['run_id'], 'command_count': len(receipt['commands']),
                       'source_file_count': receipt['source_file_count'], 'fixture_file_count': receipt['fixture_file_count']},
        'workflow': {'path': str(repo / '.github/workflows/ci.yml'), 'sha256': sha(workflow.encode()),
                     'job_api_steps': {key: len(value['api_steps']) for key, value in jobs_contract.items()},
                     'job_run_steps': {key: len(value['run_steps']) for key, value in jobs_contract.items()}},
        'ci': {'job_count': len(jobs), 'expanded_api_step_count': total_steps, 'jobs': jobs},
        'workspace_seed_runs': seed_runs,
        'raw_job_log_sha256': {slug + '.log': sha((evidence / (slug + '.log')).read_bytes()) for slug in EXPECTED_JOBS},
        'gates': {'workspace_tests': 'both fixed seeds; complete named outcomes and per-target summaries parsed',
                  'new_prefixed_retry_tests': '7 exact jarde_java tests and 3 exact integration-target tests passed once per seed',
                  'platform_jdk_msrv_clippy_ignored_extras': 'every declared CI API job step completed successfully'},
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print(f'CI verification failed: {exc}', file=sys.stderr)
        raise SystemExit(1)
