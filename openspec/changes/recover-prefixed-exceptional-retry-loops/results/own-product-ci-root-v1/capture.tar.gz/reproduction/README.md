# Prefixed exceptional retry CI receipt preparation

This directory contains a prepared collector and an independent read-only checker for the current prefixed-exceptional-retry product. Neither script has been run against GitHub or a CI run.

The collector interface is:

```text
collect-own-ci.py OUT_DIR RUN_ID PRODUCT_SHA
```

It captures `gh run view` JSON, the GitHub Actions jobs API response, all four complete job logs, and `git show PRODUCT_SHA:path` bytes for the reviewed source set and all 34 files under `tests/fixtures/recover-prefixed-exceptional-retry-loops`. It pins stdout and stderr for every command, compares captured bytes to the current checkout, and requires `target/` to remain absent. The requested commit and run must be supplied by the root operator.

The checker interface is:

```text
verify-own-ci.py EVIDENCE_DIR --product-sha PRODUCT_SHA [--repo CHECKOUT]
```

It independently checks the raw command pins, source and fixture inventories, exact run SHA, successful status of all four jobs and every API step, workflow/API step agreement, and raw stable-job logs. It parses both fixed-seed workspace runs, reconstructs every target's named outcomes and summary counts, requires full per-target summary equality across seeds, and verifies each of the seven library and three public regression tests exactly once under its expected Cargo target. Target totals/counts are derived from the actual logs; no anticipated workspace total is frozen.

The collector/checker source passed Python `ast.parse`. A read-only schema smoke check parsed the current four-job workflow and its two seed values, found all ten named regression tests at their expected source locations, and confirmed the fixture inventory contains 34 files. This is preparation validation only; it does not establish that the product CI run exists, succeeded, or was accepted. No network, Git, Cargo, Rust, JDK, or CLI command was run for this preparation.
