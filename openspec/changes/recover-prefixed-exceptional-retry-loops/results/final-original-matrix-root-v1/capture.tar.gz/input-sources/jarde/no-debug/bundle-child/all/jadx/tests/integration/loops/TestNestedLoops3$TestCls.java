// jarde: presentation of `jadx/tests/integration/loops/TestNestedLoops3$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestNestedLoops3$TestCls extends java.lang.Object {
    int c;

    public TestNestedLoops3$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestNestedLoops3$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.c = 0;
        return;
    }

    public int test(int arg1) {
        // @method test(I)I
        // @declaration an instance method of `jadx.tests.integration.loops.TestNestedLoops3$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int local2;
        loop: while (true) {
            this.f1();
            local2 = 0;
            while (true) {
                this.f2();
                if (local2 != 0) {
                    break loop;
                } else {
                    local2 = local2 + 3;
                    if (arg1 >= 16) {
                        break loop;
                    } else {
                        try {
                            this.exc();
                        } catch (java.lang.Exception local3) {
                            continue;
                        }
                        break;
                    }
                }
            }
        }
        return local2;
    }

    private void exc() throws java.lang.Exception {
        // @method exc()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestNestedLoops3$TestCls`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        if (this.c > 200) {
            throw new java.lang.Exception();
        } else {
            return;
        }
    }

    private void f1() {
        // @method f1()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestNestedLoops3$TestCls`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.c++;
        return;
    }

    private void f2() {
        // @method f2()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestNestedLoops3$TestCls`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.c += 100;
        return;
    }

    public void check() {
        // @method check()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestNestedLoops3$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        this.test(1);
        org.assertj.core.api.Assertions.assertThat(this.c).isEqualTo(302);
        return;
    }
}
