package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug.jar:jadx/tests/integration/loops/TestNestedLoops3.class */
public class TestNestedLoops3 extends IntegrationTest {

    /* JADX INFO: loaded from: debug.jar:jadx/tests/integration/loops/TestNestedLoops3$TestCls.class */
    public static class TestCls {
        int c = 0;

        public int test(int b) {
            int i;
            loop0: while (true) {
                f1();
                i = 0;
                while (true) {
                    f2();
                    if (i != 0) {
                        break loop0;
                    }
                    i += 3;
                    if (b >= 16) {
                        break loop0;
                    }
                    try {
                        exc();
                        break;
                    } catch (Exception e) {
                    }
                }
            }
            return i;
        }

        private void exc() throws Exception {
            if (this.c > 200) {
                throw new Exception();
            }
        }

        private void f1() {
            this.c++;
        }

        private void f2() {
            this.c += 100;
        }

        public void check() {
            test(1);
            Assertions.assertThat(this.c).isEqualTo(302);
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("} catch (Exception e) {");
    }
}
