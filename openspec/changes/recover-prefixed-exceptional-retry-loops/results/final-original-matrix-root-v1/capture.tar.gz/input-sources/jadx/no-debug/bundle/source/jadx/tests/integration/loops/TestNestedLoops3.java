package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug.jar:jadx/tests/integration/loops/TestNestedLoops3.class */
public class TestNestedLoops3 extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug.jar:jadx/tests/integration/loops/TestNestedLoops3$TestCls.class */
    public static class TestCls {
        int c = 0;

        public int test(int i) {
            int i2;
            loop0: while (true) {
                f1();
                i2 = 0;
                while (true) {
                    f2();
                    if (i2 != 0) {
                        break loop0;
                    }
                    i2 += 3;
                    if (i >= 16) {
                        break loop0;
                    }
                    try {
                        exc();
                        break;
                    } catch (Exception e) {
                    }
                }
            }
            return i2;
        }

        private void exc() throws Exception {
            if (this.c > 200) {
                throw new Exception();
            }
        }

        private void f1() {
            this.c++;
        }

        private void f2() {
            this.c += 100;
        }

        public void check() {
            test(1);
            Assertions.assertThat(this.c).isEqualTo(302);
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("} catch (Exception e) {");
    }
}
