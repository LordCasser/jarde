package jadx.tests.integration.loops;

import org.assertj.core.api.Assertions;

/* JADX INFO: loaded from: TestNestedLoops3$TestCls.class */
public class TestNestedLoops3$TestCls {
    int c = 0;

    public int test(int b) {
        int i;
        loop0: while (true) {
            f1();
            i = 0;
            while (true) {
                f2();
                if (i != 0) {
                    break loop0;
                }
                i += 3;
                if (b >= 16) {
                    break loop0;
                }
                try {
                    exc();
                    break;
                } catch (Exception e) {
                }
            }
        }
        return i;
    }

    private void exc() throws Exception {
        if (this.c > 200) {
            throw new Exception();
        }
    }

    private void f1() {
        this.c++;
    }

    private void f2() {
        this.c += 100;
    }

    public void check() {
        test(1);
        Assertions.assertThat(this.c).isEqualTo(302);
    }
}
