import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URI;
import java.security.CodeSource;

public final class TestNestedLoops3Driver {
    private static final String TARGET = "jadx.tests.integration.loops.TestNestedLoops3$TestCls";

    private TestNestedLoops3Driver() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            throw new IllegalArgumentException("usage: TestNestedLoops3Driver <expected-class-root>");
        }
        Class<?> target = Class.forName(TARGET);
        CodeSource codeSource = target.getProtectionDomain().getCodeSource();
        if (codeSource == null || codeSource.getLocation() == null) {
            throw new AssertionError("target has no CodeSource: " + TARGET);
        }
        File actualRoot = new File(new URI(codeSource.getLocation().toString())).getCanonicalFile();
        File expectedRoot = new File(args[0]).getCanonicalFile();
        if (!actualRoot.equals(expectedRoot)) {
            throw new AssertionError("target loaded from " + actualRoot + ", expected " + expectedRoot);
        }

        Constructor<?> constructor = target.getDeclaredConstructor();
        Method check = target.getMethod("check");
        Method test = target.getMethod("test", Integer.TYPE);
        Field counter = target.getDeclaredField("c");
        counter.setAccessible(true);
        // Confirm the complete nested target still has all five declared methods plus its ctor.
        target.getDeclaredMethod("exc");
        target.getDeclaredMethod("f1");
        target.getDeclaredMethod("f2");

        Object checked = constructor.newInstance();
        invoke(check, checked);
        row("check", "void", counter.getInt(checked));

        Object belowThreshold = constructor.newInstance();
        Object belowResult = invoke(test, belowThreshold, Integer.valueOf(15));
        row("arg15", belowResult, counter.getInt(belowThreshold));

        Object atThreshold = constructor.newInstance();
        Object atResult = invoke(test, atThreshold, Integer.valueOf(16));
        row("arg16", atResult, counter.getInt(atThreshold));

        Object repeated = constructor.newInstance();
        Object firstResult = invoke(test, repeated, Integer.valueOf(15));
        row("same-first-arg15", firstResult, counter.getInt(repeated));
        Object secondResult = invoke(test, repeated, Integer.valueOf(15));
        row("same-second-arg15", secondResult, counter.getInt(repeated));
        Object thirdResult = invoke(test, repeated, Integer.valueOf(16));
        row("same-third-arg16", thirdResult, counter.getInt(repeated));

        Object preset = constructor.newInstance();
        counter.setInt(preset, 200);
        Object presetResult = invoke(test, preset, Integer.valueOf(15));
        row("preset-c200-arg15", presetResult, counter.getInt(preset));
    }

    private static Object invoke(Method method, Object receiver, Object... args) throws Exception {
        try {
            return method.invoke(receiver, args);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof Exception) {
                throw (Exception) cause;
            }
            if (cause instanceof Error) {
                throw (Error) cause;
            }
            throw new AssertionError("unexpected invocation throwable", cause);
        }
    }

    private static void row(String label, Object result, int c) {
        System.out.println("CASE " + label + " result=" + result + " c=" + c);
    }
}
