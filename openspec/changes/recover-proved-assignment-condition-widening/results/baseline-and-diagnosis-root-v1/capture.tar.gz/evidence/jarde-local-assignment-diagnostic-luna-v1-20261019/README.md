# Temporary local-assignment diagnostic patch

Base `crates/jarde-java/src/build.rs` SHA-256 (also the rollback fingerprint): `d22ee8f1c40d0a98a174e759904a6a97313b85728bb3056d4aeba18ca8704df9`.

The single private hunk is immediately after the existing `published_local_assignments` call in the final unconsumed-assignment closure. It is gated by `JARDE_LOCAL_ASSIGNMENT_DIAGNOSTIC`; without that environment variable, it writes nothing and does not alter the proof result. With the variable set it prints the existing ragged flag, published BCI counts, existing assignment presentation counts, each candidate's duplicate/slot/store/test/source and value IDs/name/type spelling/presentation/publication count, and the full existing statement tree with fallback details. It reuses `published` and performs no additional scan or mutation.

Root can apply the diff temporarily, run the guarded diagnostic CLI, then restore the original file by the base fingerprint above. This private patch itself does not modify the shared source. No Cargo, JDK, CLI, Git mutation, or network command was run here.

Edited file SHA-256: `e43c8dc5847e246a9284eea60d6752d3f6258208c16d732641a0f46458021b11`.
Patch SHA-256: `0d66070322024bf64234dcafe2a556f1ff5fdfc27b44198a0c9f397fcf3f8c76`.
