# TestLoopConditionInvoke assignment-type audit (v3)

## Finding

The diagnostic now identifies a narrow, real refusal: both debug and no-debug forms of the current `TestLoopConditionInvoke` input reach the same local-assignment proof (`dup` BCI 9, `store` BCI 10, `test` BCI 11; source value id 9; slot 3). The assignment plan expects Java `int`; the rendered RHS is `Some(Char)`, a call `this.next()` whose method descriptor returns `char`. The assignment is consequently rejected by an exact type-equality gate and leaves the method ragged with no published local assignments. This diagnostic was supplied by root; its API receipt is pinned here, but the JSON itself does not contain the temporary diagnostic fields (`rhs_presented`, `ragged`, etc.). The shared source has since been restored to the frozen original build source.

This is a legal Java assignment conversion: a `char` value assigned to an `int` variable undergoes widening primitive conversion. Since the operation is already a local assignment expression, Java performs the widening at that assignment position. The source RHS should remain `this.next()`; adding `(int)` would be unnecessary source text and would alter the renderer's existing value presentation.

## Existing architecture and minimal reuse

In the frozen `build.rs`, `duplicate_expression` renders the saved source once and then requires `rhs.presented == Some(assignment.ty)` before constructing the existing `ExprKind::LocalAssign`. That check is the immediate refusal point (lines 28741–28766). `assignment.ty` is from the proved local plan; `prove_local_assignments` admits only `int` or reference targets here (lines 8484–8504). The origin of the resulting assignment is already exact: direct at store BCI 10 and derived at duplicate BCI 9. Keep that provenance and `assignment_presentations` accounting unchanged.

A nearby conversion helper already models the needed Java rule. `meeting_position` accepts a known primitive widening via `conversion`/`widens`, and with `Widening::Position` returns the original expression without a cast or origin change (lines 33568–33616 and 33675–33706). Its existing unit tests explicitly cover `char -> int`, `byte -> int`, and `short -> int`, including preservation of kind, origin, and the RHS's own presented type (lines 42889–43008). This corresponds to assignment-position widening, not a call-argument cast.

The consumer needs a strict precondition before reusing that helper. `meeting_position` intentionally accepts an unknown `presented` type unchanged and treats any reference-side mismatch as `Conversion::Same`; it also handles constant narrowing. Those broad semantics are valid for its existing clients but should not silently expand the local-assignment proof. For this consumer, preserve exact equality as today; for a mismatch accept only a known primitive pair for which `widens(rhs_type, assignment.ty)` is true, then use `meeting_position(..., Widening::Position)` (or its equivalent) to keep the RHS unchanged. Given this proof's `int`/reference target filter, that admits `byte`, `short`, or `char` to `int`; it does not infer types from the JVM verifier's `I` category.

Keep refusing unknown RHS types, boolean, reference-to-primitive, primitive-to-reference, narrowing, and any pair not established by the existing Java widening table. The current `next()` case is proven `Char` by the observed expression presentation and its method descriptor; a frame stack category alone would be insufficient because boolean shares the JVM int-shaped category.

## Evaluation, publication, and limits

The RHS must remain rendered once at the existing test position. Do not hoist it, clone it for a second check, or add a cast. The existing `LocalAssign` remains in the loop condition, preserving one `next()` call at the bytecode evaluation point on each test. Preserve direct-store/derived-dup origins and the existing publication counter so BCI 9 remains accounted exactly once. Existing method-level fallback/rollback remains the failure path if any other statement is unproved; no new traversal, AST node, pass, or solver is needed for this narrow type check.

The pinned API receipt has status `diagnostic_captured_source_and_product_restored`; it is not a test-pass receipt. No implementation, build, CLI run, or test was performed for this memo. The source pin is the frozen original `build.rs`, not the temporary diagnostic edit. The current conclusion is about the exact diagnosed Char-to-int mismatch only; it does not establish any wider type-conversion change.
