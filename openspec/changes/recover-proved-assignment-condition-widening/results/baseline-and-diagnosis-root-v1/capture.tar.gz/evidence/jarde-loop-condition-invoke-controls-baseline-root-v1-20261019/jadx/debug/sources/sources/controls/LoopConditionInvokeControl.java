package controls;

/* JADX INFO: loaded from: javac23-debug.jar:controls/LoopConditionInvokeControl.class */
public final class LoopConditionInvokeControl {
    private static final char STOP_CHAR = 0;
    private final char[] input;
    private int pos;
    private int calls;
    private int events;

    public LoopConditionInvokeControl(char[] input, int startingPos) {
        this.input = input;
        this.pos = startingPos;
    }

    public boolean test(char lastChar) {
        int ch;
        int startPos = this.pos;
        do {
            ch = next();
            if (ch == 0) {
                this.pos = startPos;
                return false;
            }
        } while (ch != lastChar);
        return true;
    }

    private char next() {
        this.calls++;
        int index = this.pos;
        this.pos = index + 1;
        this.events = (this.events * 10) + index + 1;
        return this.input[index];
    }

    public int getPos() {
        return this.pos;
    }

    public int getCalls() {
        return this.calls;
    }

    public int getEvents() {
        return this.events;
    }
}
