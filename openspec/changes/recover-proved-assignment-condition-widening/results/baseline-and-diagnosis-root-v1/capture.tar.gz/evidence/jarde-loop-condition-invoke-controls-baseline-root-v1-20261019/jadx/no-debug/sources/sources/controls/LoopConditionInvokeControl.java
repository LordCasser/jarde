package controls;

/* JADX INFO: loaded from: javac23-no-debug.jar:controls/LoopConditionInvokeControl.class */
public final class LoopConditionInvokeControl {
    private static final char STOP_CHAR = 0;
    private final char[] input;
    private int pos;
    private int calls;
    private int events;

    public LoopConditionInvokeControl(char[] cArr, int i) {
        this.input = cArr;
        this.pos = i;
    }

    public boolean test(char c) {
        char next;
        int i = this.pos;
        do {
            next = next();
            if (next == 0) {
                this.pos = i;
                return false;
            }
        } while (next != c);
        return true;
    }

    private char next() {
        this.calls++;
        int i = this.pos;
        this.pos = i + 1;
        this.events = (this.events * 10) + i + 1;
        return this.input[i];
    }

    public int getPos() {
        return this.pos;
    }

    public int getCalls() {
        return this.calls;
    }

    public int getEvents() {
        return this.events;
    }
}
