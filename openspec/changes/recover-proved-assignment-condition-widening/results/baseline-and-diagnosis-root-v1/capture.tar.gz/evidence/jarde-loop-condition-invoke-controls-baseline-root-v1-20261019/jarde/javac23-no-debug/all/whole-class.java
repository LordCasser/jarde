// jarde: presentation of `controls/LoopConditionInvokeControl` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package controls;

public final class LoopConditionInvokeControl extends java.lang.Object {
    private static final char STOP_CHAR = '\u0000';

    private final char[] input;

    private int pos;

    private int calls;

    private int events;

    public LoopConditionInvokeControl(char[] arg1, int arg2) {
        // @method <init>([CI)V
        // @declaration a constructor of `controls.LoopConditionInvokeControl`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.input = arg1;
        this.pos = arg2;
        return;
    }

    public boolean test(char arg1) {
        // jarde: not recovered: the recovery run for `test(C)Z` produced no statement (explanation only); the artifact's own comment lines are below
        // @method test(C)Z
        // @declaration an instance method of `controls.LoopConditionInvokeControl`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 5 6 9 10 11 14 15 16 19 20 21 22 23 26 27
        // the local assignment condition was not completely proved
    }

    private char next() {
        // @method next()C
        // @declaration an instance method of `controls.LoopConditionInvokeControl`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.calls += 1;
        int local1 = this.pos++;
        this.events = this.events * 10 + local1 + 1;
        return this.input[local1];
    }

    public int getPos() {
        // @method getPos()I
        // @declaration an instance method of `controls.LoopConditionInvokeControl`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        return this.pos;
    }

    public int getCalls() {
        // @method getCalls()I
        // @declaration an instance method of `controls.LoopConditionInvokeControl`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        return this.calls;
    }

    public int getEvents() {
        // @method getEvents()I
        // @declaration an instance method of `controls.LoopConditionInvokeControl`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        return this.events;
    }
}
