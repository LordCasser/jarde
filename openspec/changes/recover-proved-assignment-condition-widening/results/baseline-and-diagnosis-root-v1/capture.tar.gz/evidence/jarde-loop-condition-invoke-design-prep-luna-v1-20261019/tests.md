# Draft test plan (not executed)

## Existing seams to reuse

- `tests/recover_loop_test_copy_store.rs::the_same_form_loop_presents_on_every_leg` already exercises the in-place loop-test form on Java 23 `--release 8` and real Java 8, checks the exact assignment occurs once, and has an ignored full-source compile/run replay. It is the closest existing test module for the integration; its private helpers already open a class, inspect method text, strip report comments for replay, compile, and execute.
- `tests/recover_dup_store_conditional.rs::the_loop_test_presents_and_the_short_circuit_chain_keeps_its_refusal` pins the loop-test assignment and preserves the short-circuit refusal. Keep it byte-identical as a regression.
- `tests/p3_required_conversions.rs::a_write_states_the_written_types_own_type` establishes that a declaration/assignment position does not add a cast for a char value. `a_return_states_the_members_own_type` and `an_argument_states_the_callees_parameter_type` distinguish assignment/return implicit widening from invocation arguments that require an explicit cast. These tests are useful supporting evidence, not substitutes for a loop-test consumer test.
- `crates/jarde-java/src/build.rs::tests::compound_test_builder` (around line 43588 in the inspected source) creates the real Builder from canonical CFG, SSA, decoded Code, operations, region and local plans. If a valid consumer-specific refusal/stop control needs a lower-level path, extend an existing builder test through this fixture-derived helper and its state/checkpoint assertions; do not add a production helper just to unit-test `widens`.

## Required positive integration

Use the pinned original source/class family for `jadx.tests.integration.loops.TestLoopConditionInvoke$TestCls`, compiled without trimming. In both debug and no-debug Java 8 class profiles:

1. Assert `test(C)Z` is fully recovered, has no fallback, and contains the one saved call/assignment in the loop test. The text must not add `(int)` and must not evaluate `next()` twice.
2. Request default and all evidence. Require whole and method text equality; for mapped output verify exact physical owner/method, UTF-8 boundaries, and complete relevant Code-BCI coverage including the call, `dup`, store, comparison and loop edge.
3. Compile complete original, fixed JADX and Jarde class sources with supported Java 8/23 compiler legs as the existing acceptance harness allows; classify any compiler refusal explicitly rather than removing source lines. Run the full classes from isolated expected CodeSource roots against identical inputs and compare observable outputs.

The frozen fixed source's `next()` returns constant `0`. The existing four-case driver therefore reaches only the false loop-exit/reset path; varying `lastChar` does not exercise the true arm or prove call count. The current baseline README explicitly notes this boundary. Add a small companion control with a driver-controlled `char` sequence and a call counter, or another verifier-valid fixed-source variant that reaches both a matching character and the stop character. Compare original vs full Jarde output/state/call count for (a) a match before stop and (b) no match before stop. Do not change the pinned upstream source to manufacture the claimed original baseline.

## Refusal and rollback coverage

- Preserve existing exact-type positive coverage (`NEG.liveLine`, `Probe.readAll`) and all existing extra-reader/parameter/short-circuit/guard refusals unchanged.
- Through a real Builder consumer fixture, check that an RHS with unknown presentation, a Boolean/non-Boolean mismatch, or a narrowing pair is not admitted merely because the JVM stack type is int-shaped. Exact boolean equality must still pass its existing path.
- Include one real budget/stop boundary at the Builder or public report entry: the method falls back/stops atomically, has no partial `LocalAssign` source-map span, and reports the actual stop. Reuse existing state/checkpoint machinery and the public report's real consumer; do not only unit-test the `widens` table.

## Open information before implementation

- Identify the exact new Rust integration-test home and fixture ownership after root decides whether to extend `recover_loop_test_copy_store.rs` or add a focused file. The upstream class is from JADX's test tree; the current Jarde fixture set does not include it.
- The constant-zero baseline has no true loop-body observation. The dynamic sequence control must be added and captured before claiming both outcomes and call count are tested.
- Pick a verifier-valid way to test Boolean mismatch and unknown presentation through the same `duplicate_expression` consumer; Java source alone cannot express assignment of `boolean` to an `int`. If no current fixture provides that bytecode, leave that exact negative as a documented gap instead of hand-waving a malformed input through the pipeline.
- Rebind the new source/class and current product CLI pins in a fresh full baseline/current run. The existing diagnostic receipt is not final acceptance and does not include full JVM execution evidence.
