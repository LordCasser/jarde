# Private preparation: loop-test char-to-int assignment widening

This folder is an OpenSpec-style draft only. It does not create or edit a shared OpenSpec change and makes no implementation or pass claim. The current product's exact mismatch is based on the root-supplied diagnostic: `assignment_ty=int`, RHS `Some(Char)` from `this.next()`, at the proved dup/store/test sequence. The pinned API receipt is not a complete runtime acceptance receipt.

The design follows root's reviewed seam: preserve exact equality, then accept only a known pair accepted by existing `widens`; do not call `meeting_position` unnecessarily and do not change target type or source text. The fixed upstream source is also pinned locally under the adjacent test project. Its helper `next()` always returns zero, so existing runtime cases do not cover the loop's true arm; the test plan explicitly requires a separate dynamic control before asserting both paths/call counts.

Atlas was opened on the Jarde project and queried within `build.rs` for `duplicate_expression` and `compound_test_builder`; the latter resolved at line 43588. Test-file symbol search coverage was incomplete, so test seams were verified by direct reads of the named files. No Cargo/JDK/JADX/Jarde CLI/network/Git command was run.

See `proposal.md`, `design.md`, and `tests.md`. `source-pins.json` records the exact inputs read.
