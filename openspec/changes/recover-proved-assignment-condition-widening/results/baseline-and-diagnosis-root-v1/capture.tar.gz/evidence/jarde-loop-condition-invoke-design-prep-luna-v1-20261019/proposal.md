# Draft proposal: widen a proved char result in a loop-test local assignment

## Problem

The fixed upstream `TestLoopConditionInvoke$TestCls.test(char): boolean` contains `int startPos = pos; char ch; while ((ch = next()) != STOP_CHAR) { ... }`. Its bytecode has one `dup; istore; if_icmp*` loop-test assignment. The current proved local-assignment consumer decides the target as `int`, while the RHS is a descriptor-backed `char` result from `next()`. Exact-type equality rejects this legal Java widening assignment and causes the method to fall back.

## Scope

Keep the already-proved single-consumer loop-test local assignment. Extend its existing final type check only for a known Java primitive widening accepted by the existing `widens` relation. Keep the target-type plan and physical/SSA proof unchanged. This draft is limited to the actual mismatch `char` RHS into an `int` target; any broader pair the existing helper naturally supports must still be justified and tested through this same consumer.

## Non-goals

No new conversion IR, solver, inference from JVM stack category, rewrite of general calls/returns/writes, local type refinement, `char`-local restoration, loop-region redesign, or recovery of unsupported/unknown consumers. Do not add casts for implicit assignment conversion.
