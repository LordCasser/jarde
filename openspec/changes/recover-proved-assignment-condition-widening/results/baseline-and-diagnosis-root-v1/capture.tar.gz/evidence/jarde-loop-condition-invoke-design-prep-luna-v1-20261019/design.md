# Draft design

## Intended behavior

The saved source value for a proved loop-test assignment may have a different Java type from the already-decided local only when the existing `widens(source, target)` table proves a legal widening primitive conversion. Preserve the existing exact-type path verbatim. For the fixed case, retain the RHS call `this.next()` with its own `char` presentation and keep the `LocalAssign` target type `int`; Java assignment context performs `char`-to-`int` widening. Emit no redundant `(int)` cast.

The production seam is the existing equality check in `Builder::duplicate_expression` for `LocalAssignmentPresentation::Expression`, after the proved source has been rendered and before the existing `ExprKind::LocalAssign` is constructed. The target remains the plan's one `assignment.ty`; no type is re-decided and no conversion helper or AST node is added. Root's architecture review selects direct reuse of `widens` after the exact equality check, not `meeting_position`: the latter is a no-op once this proof has prevalidated a widening. Preserve the existing target filter (`int` or reference) and all proof/region admission.

## Invariants

- The existing exact equality behavior remains unchanged, including exact `boolean`-to-`boolean` and same-reference assignments.
- A mismatch is accepted only when both `rhs.presented` and the target are known and the existing `widens(rhs_type, target_type)` says true. A JVM `I` stack category is not source-type evidence.
- Boolean-to-nonboolean and nonboolean-to-boolean mismatches remain refused. References are not accepted by a primitive-widening rule; unknown `presented=None`, narrowing and every unlisted pair remain refused.
- Render the RHS once at the existing loop-test position. Keep its call order, exception timing, and source value; do not hoist, duplicate, or wrap it in a source cast.
- Keep the same `LocalAssign` node, `assignment.ty`, direct store origin and derived duplicate origin; account for the duplicate exactly once. Preserve the existing whole-method fallback/rollback on any other unproved work.
- No additional scan/IR item/normalization clone or budget dimension is introduced by the type relation check. Existing stop/cancel behavior remains authoritative; stop must not publish partial method text or map.

## Adversarial boundary cases

- Exact same-type `int` and reference assignments still follow the old equality path.
- `char -> int` is the positive mismatch; a dynamic control must exercise both loop continuation and termination and observe the call count/order.
- `int -> char` is narrowing and must refuse.
- Boolean paired with a different primitive type must refuse even though both can use verifier int-shaped stack values; exact `boolean -> boolean` must remain on the equality path.
- Unknown RHS type must refuse; do not convert absence of type evidence into equality or widening.
- An extra copy consumer, wrong local, exceptional/short-circuit boundary, or an assignment not owned by the loop's own test remains governed by existing proofs and refusals.

## Evidence and constraints

The frozen product source places the current rejection in `duplicate_expression`; the existing `recover-proved-local-assignments-in-conditions` design already states the target type comes from the local plan and the RHS is evaluated once. The existing `make-required-conversions-explicit` and `p3_required_conversions` tests establish that assignment positions perform widening without inserting casts, while calls may need an explicit cast to preserve overload resolution. Do not route this through a call-argument path.
