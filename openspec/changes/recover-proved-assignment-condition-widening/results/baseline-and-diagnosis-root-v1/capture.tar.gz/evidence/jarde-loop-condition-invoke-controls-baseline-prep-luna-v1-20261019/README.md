# TestLoopConditionInvoke dynamic controls baseline collector (private preparation)

Status: **unexecuted**. This collector was prepared but not run. It uses the fixed six-row control source/driver in this directory and reuses the accepted baseline collector’s `full_class_facts` and `audit_method_map` helpers, plus the established compare, JDK manifest, command guard, target scanner, and 30-second runtime wrapper. No Java, compiler, CLI, Cargo, Git mutation, or network command was invoked.

The planned original control matrix compiles the one complete control class with javac8/source-target-8 and javac23/release-8, each with debug and no-debug: four actual compile cells. Successful class roots run on both JVMs using only the separate driver classpath and the parentless target loader; each target root also gets a wrong-CodeSource attempt. Six control cases per VM cell would yield 48 observations if all eight VM cells execute; the collector derives counts from actual results. The original upstream target stays represented only by its existing four VM cells/16 observations.

For each successful original class profile, the collector requests Jarde `class-source` default and all evidence, records the full class projection, enumerates all physical methods, and audits each raw method text/map against the exact compiled method Code/BCIs and UTF-8 byte boundaries. This is eight API calls when all four profiles compile. It then runs JADX on the complete javac23 debug/no-debug class bundles and pins the complete emitted Java source trees. No generated sources are edited. API/compile/runtime failures remain raw and are not converted into success.

The next generated-source stage can compile the full Jarde class-source text and each full JADX source tree with both compiler legs, preserving genuine failures. Do not reuse original-target runtime rows as generated-target evidence.

Exact run shape after review:

```sh
python3 -B collect_controls_baseline.py --out /private/tmp/jarde-loop-condition-invoke-controls-baseline-root-v1-20261019
```

The candidate CLI is pinned to SHA-256 `90b30ad1132bdc904c20f1b4624347b84d37637c78f1f3e291ce2f0dea91f64c`; source, driver, helper scripts, JDK manifest/tools, JADX, runtime wrapper, and historical receipts are pinned in `pins.json`.
