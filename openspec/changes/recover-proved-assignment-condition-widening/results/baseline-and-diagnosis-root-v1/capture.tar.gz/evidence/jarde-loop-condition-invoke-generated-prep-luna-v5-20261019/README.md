# TestLoopConditionInvoke generated-source comparison collector (private v5)

Status: **unexecuted preparation only**. This is not a baseline, product test, or acceptance result. No JDK, JADX, Jarde CLI, Cargo, Git mutation, or network command was run.

The stage consumes the completed baseline receipt and its SHA, and checks the exact pinned CLI from that receipt (SHA-256 `90b30ad1132bdc904c20f1b4624347b84d37637c78f1f3e291ce2f0dea91f64c`). It reopens all raw streams, checks the four original profile/runtime observations, wrong-CodeSource rejection, complete physical outer/child inventories, and exact bundles. Static Python validation against the completed receipt found exactly eight successful Jarde API cells (debug/no-debug × child/bundle-child × default/all) and two complete successful JADX source trees. `source_cells` resolved all ten available inputs against their saved report/command/source pins. This was a Python schema check only; no generated source was compiled or run.

The baseline repository source closure is checked for internal before/after/finally equality. The current repository closure is captured independently and guarded unchanged during stage two; it is not required to equal the historical baseline closure. This avoids treating a later implementation source tree as though it were the tree from which the pinned baseline CLI was captured. The CLI itself remains byte-pinned, and the stage never executes it.

Every available Jarde source artifact and every complete JADX source tree is copied byte-for-byte and compiled unchanged with both configured Java 8-target compiler legs, matching debug/no-debug. No source is cropped, rewritten, or repaired. Compile failures and compiler diagnostics remain recorded, including any genuine missing-return or JDK8 framework-boundary failure. Only successful compile outputs whose entire class tree passes both parsers, whose expected target has major 52, and whose target method `(name, descriptor, access)` and field `(name, descriptor, access)` inventories exactly match the corresponding original profile receive parentless-driver runtime attempts on both VMs. Inventory or class-fact errors remain recorded and receive no runtime row. Generated target roots are the only application target roots; the original target is never substituted. A compile failure receives no runtime row.

Each compiled class tree is scanned with the two pinned classfile parsers, recording fields, methods, descriptors, access, Code, and BCIs. Runtime comparisons use the corresponding original profile/runtime observations and retain raw exception/position state. A separate wrong-CodeSource check is required for each eligible target root.

The fixed `next()` returns zero. The four observations cover only the false path and position preservation; they do not exercise a true branch or count calls.

The collector retains the existing guard: no Java environment overrides, no `CARGO_TARGET_DIR`, default stack, 30-second command wrapper, at least 5 GiB free space, target capped at 1 GiB and absent before/after, source/tool/input pins, raw streams, and generated copy/output stability.

Example invocation for root review (not executed):

```sh
python3 -B collect_generated_matrix.py --baseline /private/tmp/jarde-loop-condition-invoke-baseline-root-v1-20261019/execution.json --baseline-sha256 7725015c3643581cb4c35d5f334c016f6f035540634e8c58183be3c7a177b3b4 --cli /private/tmp/jarde-indexed-list-signatures-reader-and-remainder-root-v1-20261019/candidate-cli --out /private/tmp/jarde-loop-condition-invoke-generated-root-v1-20261019
```

The baseline receipt SHA shown above is pinned in `pins.json`. `collector-adaptation.diff` records the change from v1, and `SHA256SUMS` pins this private package.
