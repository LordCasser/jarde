// jarde: presentation of `jadx/tests/integration/loops/TestLoopConditionInvoke$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestLoopConditionInvoke$TestCls extends java.lang.Object {
    private static final char STOP_CHAR = '\u0000';

    private int pos;

    public TestLoopConditionInvoke$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestLoopConditionInvoke$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public boolean test(char lastChar) {
        // jarde: not recovered: the recovery run for `test(C)Z` produced no statement (explanation only); the artifact's own comment lines are below
        // @method test(C)Z
        // @declaration an instance method of `jadx.tests.integration.loops.TestLoopConditionInvoke$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 5 6 9 10 11 14 15 16 19 20 21 22 23 26 27
        // the local assignment condition was not completely proved
    }

    private char next() {
        // @method next()C
        // @declaration an instance method of `jadx.tests.integration.loops.TestLoopConditionInvoke$TestCls`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        return '\u0000';
    }
}
