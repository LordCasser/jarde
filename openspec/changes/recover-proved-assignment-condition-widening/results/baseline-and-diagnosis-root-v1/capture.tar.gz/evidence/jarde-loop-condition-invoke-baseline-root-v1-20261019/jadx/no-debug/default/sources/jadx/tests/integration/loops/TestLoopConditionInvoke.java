package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestLoopConditionInvoke.class */
public class TestLoopConditionInvoke extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestLoopConditionInvoke$TestCls.class */
    public static class TestCls {
        private static final char STOP_CHAR = 0;
        private int pos;

        public boolean test(char c) {
            char next;
            int i = this.pos;
            do {
                next = next();
                if (next == 0) {
                    this.pos = i;
                    return false;
                }
            } while (next != c);
            return true;
        }

        private char next() {
            return (char) 0;
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("do {").containsOne("if (ch == 0) {").containsOne("this.pos = startPos;").containsOne("return false;").containsOne("} while (ch != lastChar);").containsOne("return true;");
    }
}
