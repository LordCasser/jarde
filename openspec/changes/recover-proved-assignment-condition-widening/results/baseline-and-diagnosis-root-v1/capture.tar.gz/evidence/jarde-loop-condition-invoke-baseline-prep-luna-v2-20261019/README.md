# TestLoopConditionInvoke baseline collector (private v2)

Status is **unexecuted preparation**. The code is ready for review and root execution. No JDK, JADX, Jarde CLI, Cargo, Git mutation, or network command was run.

`collect_baseline.py` is adapted from the previously reviewed full-source NL2 baseline collector. It accepts the candidate CLI path as `--cli` and refuses it unless its SHA-256 matches the supplied current CLI pin in `pins.json`. Source, driver, dependency/harness, manifest, JDK tool binaries, compare/guard/scanner/parser, JADX launcher and jar are all pinned and checked before output creation. The JDK manifest and helper paths were confirmed to exist locally; the candidate CLI path is intentionally an argument and must be supplied by root.

The collector preserves the full upstream outer class plus nested class source and performs a real Java 8 full-source compile attempt (including the JUnit test source); it records any major-55 harness failure without substituting a trimmed compile. It then compiles the full source with JDK 23 `--release 8`, debug and no-debug, and requires the complete class tree to contain exactly the outer and child classes. Both classfiles are independently parsed and the child method inventory is bound to `<init>()V`, `next()C`, and `test(C)Z`, with concrete Code and physical BCI inventory. Each successful profile is packed into a deterministic outer+child bundle.

The independent driver compiles with Java 8 and loads each target from only its target root using a parentless loader. It checks CodeSource and captures the four `lastChar`/initial-position cases, recording result, exception, and position before/after. A wrong expected-root control must exit 1 with `wrong CodeSource:`. Because `next()` is a fixed zero return, these cases only observe false-result and position behavior; they do not exercise the true branch or count calls.

For each successful profile the collector makes 8 CLI calls: child class or full bundle × default/all evidence. It preserves raw JSON and whole-class text, method identity/outcome/quality/fallback/regions/raw text/source map, expected physical method inventory comparison, and a per-method map audit for UTF-8 byte boundaries and references against that method's physical Code BCIs. It records missing or malformed map facts instead of assuming successful recovery. It also decodes the complete bundle with pinned JADX and saves all emitted sources. This baseline collector does not compile or run emitted Jarde/JADX sources.

The existing timeout/abort guard supplies raw argv, stdout, stderr and exit pins. The collector keeps the default stack, removes the four Java environment overrides, requires 5 GiB free, caps `target` at 1 GiB, and checks workspace source closure and `target` absence before and after. Every compile, runtime, CLI and JADX outcome is kept in `execution.json`; a captured receipt would still require independent review.

Run only after review, with the final CLI path supplied explicitly:

```sh
python3 -B collect_baseline.py --cli /absolute/path/to/candidate-cli --out /private/tmp/jarde-loop-condition-invoke-baseline-run-root-v1-20261019
```

`collector-adaptation.diff` records the changes from the reviewed NL2 collector template. The v1 command plan remains in the separately frozen v1 directory; v2 uses this runnable collector and `pins.json` as its authoritative inventory.
