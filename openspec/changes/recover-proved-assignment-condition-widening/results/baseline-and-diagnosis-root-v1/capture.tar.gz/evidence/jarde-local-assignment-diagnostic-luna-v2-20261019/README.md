# Temporary local-assignment diagnostic patch v2

Base `crates/jarde-java/src/build.rs` SHA-256 (rollback fingerprint): `d22ee8f1c40d0a98a174e759904a6a97313b85728bb3056d4aeba18ca8704df9`.

This patch applies to the original file and includes the v1 environment-gated report at the final `published_local_assignments` closure, plus one additional environment-gated line group in the existing `LocalAssignmentPresentation::Expression` branch immediately after `let rhs = source(self, at)?`. It prints that candidate's duplicate/store/source, expected type spelling, `rhs.presented`, and `rhs.kind`. It uses only the already-rendered RHS; no new scan or proof/result mutation is added. With `JARDE_LOCAL_ASSIGNMENT_DIAGNOSTIC` unset, there is no diagnostic output.

Root may apply this temporarily, run the guarded diagnostic command, and restore the original file using the base fingerprint. No shared source was changed here. No Cargo, JDK, CLI, Git mutation, or network command was run.

Edited file SHA-256: `7fc796dc0078dcf30b60b3e5bf731579dec3d1e10c285de5ff9624778fc02f1e`.
Patch SHA-256: `5c84536e82089ff2f31ac4a1092b81a638df9bf348527cfb4cd545dcda378b86`.
