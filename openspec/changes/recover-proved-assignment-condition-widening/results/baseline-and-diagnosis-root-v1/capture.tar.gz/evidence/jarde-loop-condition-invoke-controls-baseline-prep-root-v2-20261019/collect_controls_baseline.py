#!/usr/bin/env python3
"""Capture independent TestLoopConditionInvoke dynamic controls; preparation only."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, re, shutil, sys, zipfile
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
CLI_SHA='90b30ad1132bdc904c20f1b4624347b84d37637c78f1f3e291ce2f0dea91f64c'
CLI_DEFAULT=Path('/private/tmp/jarde-indexed-list-signatures-reader-and-remainder-root-v1-20261019/candidate-cli')
BASELINE_COLLECTOR=Path('/private/tmp/jarde-loop-condition-invoke-baseline-prep-luna-v2-20261019/collect_baseline.py')
BASELINE_COLLECTOR_SHA='4b4760c50e581b9285d5c0cc95779ab532e1b135332ae70f063c7ed054dfdb39'
COMPARE_REL='openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD_REL='openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL='openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_MANIFEST_REL='openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
RUNTIME_BOUND=Path('/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
RUNTIME_BOUND_SHA='73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
JADX=Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA='64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR=Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA='966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
BASELINE_PATH=Path('/private/tmp/jarde-loop-condition-invoke-baseline-root-v1-20261019/execution.json')
BASELINE_SHA='7725015c3643581cb4c35d5f334c016f6f035540634e8c58183be3c7a177b3b4'
GENERATED_PATH=Path('/private/tmp/jarde-loop-condition-invoke-generated-root-v1-20261019/execution.json')
GENERATED_SHA='b30c92057b7a366bfbd8e1bcbfb647a611efb7211c0f71068c014e730416b11d'
API_DIAG_PATH=Path('/private/tmp/jarde-loop-condition-invoke-diagnostic-api-root-v2-20261019/execution.json')
API_DIAG_SHA='2ac27a71d8570c45c323e50fe748729f428c1c34ae1c641cf50ae5396d016b29'
BUILD_DIAG_PATH=Path('/private/tmp/jarde-loop-condition-invoke-diagnostic-build-root-v2-20261019/execution.json')
BUILD_DIAG_SHA='90d82b89c9fd893591c441fbc74b851db84d10c6e8e366ff5f99ae713bf1bdcc'
TARGET_INTERNAL='controls/LoopConditionInvokeControl'
TARGET_DOT='controls.LoopConditionInvokeControl'
DRIVER_MAIN='LoopConditionInvokeControlDriver'
SOURCE_REL='source/controls/LoopConditionInvokeControl.java'
DRIVER_REL='driver/LoopConditionInvokeControlDriver.java'
PROFILES=('javac8-debug','javac8-no-debug','javac23-debug','javac23-no-debug')
LEGS=('javac8','javac23'); RUNTIMES=('javac8','javac23'); EVIDENCE=('default','all')
CASE_NAMES=('hit-first','nonmatch-then-hit','nonzero-start-stop-restores','stop-precedes-equal-target','missing-stop-bounds-failure','maximum-char-hit')
EXPECTED_METHODS={('<init>','([CI)V'),('test','(C)Z'),('next','()C'),('getPos','()I'),('getCalls','()I'),('getEvents','()I')}
ENV_STRIP=('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','CARGO_TARGET_DIR')

def sha_file(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
 return h.hexdigest()
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path)
 if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
 mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def exact_pin(compare,row,label):
 if not isinstance(row,dict) or not {'path','bytes','sha256'}<=row.keys(): raise RuntimeError(f'{label}: invalid pin')
 p=Path(row['path']).resolve(strict=True)
 if compare.pin(p)!=row: raise RuntimeError(f'{label}: pin mismatch {p}')
 return p
def parse_rows(raw,expected):
 pat=re.compile(r'^CASE index=(\d+) name=([^ ]+) lastChar=(\d+) result=(true|false|<none>) exception=([^ ]+) posBefore=(-?\d+) posAfter=(-?\d+) calls=(\d+) events=(\d+)$')
 rows=[]
 for i,line in enumerate(raw.decode('utf-8','strict').splitlines()):
  m=pat.fullmatch(line)
  if not m: raise ValueError(f'malformed control row {line!r}')
  ix,name,last,result,exc,before,after,calls,events=m.groups()
  if int(ix)!=i or i>=len(expected) or name!=expected[i]['name']: raise ValueError(f'control identity/order mismatch {line!r}')
  row={'index':i,'name':name,'lastChar':int(last),'result':result,'exception':exc,'posBefore':int(before),'posAfter':int(after),'calls':int(calls),'events':int(events),'raw':line}
  rows.append(row)
 if len(rows)!=len(expected): raise ValueError(f'expected {len(expected)} rows, got {len(rows)}')
 return rows
def semantic(row): return {k:row[k] for k in ('index','name','lastChar','result','exception','posBefore','posAfter','calls','events')}
def fullfacts(base,compare,physical,path,label): return base.full_class_facts(compare,physical,path,label)
def make_bundle(compare,root,dest):
 with zipfile.ZipFile(dest,'w') as archive:
  for file in sorted(root.rglob('*.class')):
   entry=zipfile.ZipInfo(file.relative_to(root).as_posix(),(1980,1,1,0,0,0)); entry.compress_type=zipfile.ZIP_STORED
   archive.writestr(entry,file.read_bytes())
 return compare.pin(dest)
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--out',type=Path,required=True); ap.add_argument('--cli',type=Path,default=CLI_DEFAULT); ap.add_argument('--root',type=Path,default=ROOT)
 a=ap.parse_args(); root=a.root.resolve(strict=True); out=a.out.resolve(); cli=a.cli.resolve(strict=True)
 if root!=ROOT.resolve(): raise SystemExit(f'workspace differs from pinned root: {root}')
 if out.exists(): raise SystemExit(f'refusing existing output {out}')
 if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('target must be absent before run')
 if shutil.disk_usage(root).free<5*1024**3: raise SystemExit('less than 5 GiB free')
 source=Path(__file__).parent/SOURCE_REL; driver=Path(__file__).parent/DRIVER_REL; manifest_path=Path(__file__).parent/'controls.json'
 doc=json.loads(manifest_path.read_text(encoding='utf-8'))
 if doc.get('schema')!='test-loop-condition-invoke-dynamic-controls-v2': raise SystemExit('control source manifest schema mismatch')
 for file,record,name in ((source,doc['source'],'control source'),(driver,doc['driver'],'control driver')):
  if file.stat().st_size!=record['bytes'] or sha_file(file)!=record['sha256']: raise SystemExit(f'{name} pin mismatch')
 if sha_file(cli)!=CLI_SHA: raise SystemExit('CLI SHA differs from current candidate pin')
 if sha_file(BASELINE_COLLECTOR)!=BASELINE_COLLECTOR_SHA: raise SystemExit('baseline helper collector pin mismatch')
 for path,expected,label in ((BASELINE_PATH,BASELINE_SHA,'original baseline receipt'),(GENERATED_PATH,GENERATED_SHA,'generated baseline receipt'),(API_DIAG_PATH,API_DIAG_SHA,'diagnostic API receipt'),(BUILD_DIAG_PATH,BUILD_DIAG_SHA,'diagnostic build receipt')):
  if sha_file(path)!=expected: raise SystemExit(f'{label} changed')
 compare_path=root/COMPARE_REL; guard_path=root/GUARD_REL; scanner_path=root/SCANNER_REL; jdk_path=root/JDK_MANIFEST_REL
 for path,expected,label in ((compare_path,COMPARE_SHA,'compare'),(guard_path,GUARD_SHA,'guard'),(scanner_path,SCANNER_SHA,'scanner'),(jdk_path,JDK_MANIFEST_SHA,'JDK manifest'),(PARSER,PARSER_SHA,'physical parser'),(RUNTIME_BOUND,RUNTIME_BOUND_SHA,'runtime wrapper'),(JADX,JADX_SHA,'JADX launcher'),(JADX_JAR,JADX_JAR_SHA,'JADX jar')):
  if sha_file(path)!=expected: raise SystemExit(f'{label} pin mismatch: {path}')
 compare=load(compare_path,'control_compare'); guard=load(guard_path,'control_guard'); scanner=load(scanner_path,'control_scanner'); physical=load(PARSER,'control_physical')
 baseline_helpers=load(BASELINE_COLLECTOR,'control_baseline_helpers')
 jdks,jdk_record=compare.configured_jdks(jdk_path,JDK_MANIFEST_SHA)
 if baseline_helpers.sha(BASELINE_PATH)!=BASELINE_SHA: raise SystemExit('baseline helper receipt pin mismatch')
 source_before=compare.source_closure(root)
 external_paths=[cli,BASELINE_COLLECTOR,compare_path,guard_path,scanner_path,jdk_path,PARSER,RUNTIME_BOUND,JADX,JADX_JAR,
                 BASELINE_PATH,GENERATED_PATH,API_DIAG_PATH,BUILD_DIAG_PATH,manifest_path,source,driver,
                 *[Path(t) for spec in jdks.values() for t in spec['tools'].values()]]
 external_before=[compare.pin(Path(q)) for q in external_paths]
 out.mkdir(parents=True); raw=out/'raw'; raw.mkdir(); empty=out/'empty-classpath'; empty.mkdir()
 control_source=out/SOURCE_REL; control_source.parent.mkdir(parents=True); shutil.copyfile(source,control_source)
 control_driver=out/DRIVER_REL; control_driver.parent.mkdir(parents=True); shutil.copyfile(driver,control_driver)
 driver_classes=out/'driver-classes'; driver_classes.mkdir()
 runtime_copy=out/RUNTIME_BOUND.name; shutil.copyfile(RUNTIME_BOUND,runtime_copy)
 report={'schema':'test-loop-condition-invoke-controls-baseline-v1','status':'running','root':str(root),'output':str(out),
  'candidate_cli':compare.pin(cli),'candidate_cli_sha256_expected':CLI_SHA,'source_closure_before':source_before,
  'source':compare.pin(source),'source_copy':compare.pin(control_source),'driver':compare.pin(driver),'driver_copy':compare.pin(control_driver),
  'controls_manifest':compare.pin(manifest_path),'baseline_collector_helpers':compare.pin(BASELINE_COLLECTOR),
  'baseline_receipts':{'original':compare.pin(BASELINE_PATH),'generated':compare.pin(GENERATED_PATH),'diagnostic_api':compare.pin(API_DIAG_PATH),'diagnostic_build':compare.pin(BUILD_DIAG_PATH)},
  'compare':compare.pin(compare_path),'guard':compare.pin(guard_path),'scanner':compare.pin(scanner_path),'jdk_manifest':jdk_record,
  'physical_parser':compare.pin(PARSER),'runtime_wrapper':compare.pin(runtime_copy),'jadx':compare.pin(JADX),'jadx_jar':compare.pin(JADX_JAR),
  'external_pins_before':external_before,'commands':[],'driver_compile':None,'profile_cells':[],'runtime_cells':[],'wrong_root_cells':[],'jarde_api_cells':[],'jadx_outputs':[],
  'notes':['The independent six-row control results are kept separate from the original four-row false-only target evidence.','Every successful original control compile is run on both VMs with only the separate driver classpath and parentless target loader.','Jarde class-source default/all cells preserve complete class text and each physical method report; raw method maps are checked against the exact compiled Code arrays.','JADX output is enumerated as a complete Java source tree; no generated source is edited.']}
 compare.write_json(out/'execution.json',report); rows=report['commands']
 guard.ROOT=root; guard.OUT=raw; guard.target_bytes=lambda:scanner.target_bytes(root); guard.command_stream=compare.pin; guard.expected_test_summaries=lambda index,data:None
 def command(argv,label,leg):
  if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError('workspace target appeared')
  env=compare.clean_env(dict(os.environ),jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK',None); env.pop('CARGO_TARGET_DIR',None)
  row=guard.run_command(len(rows)+1,[str(x) for x in argv],env); row['label']=label; row['tool_leg']=leg; rows.append(row); compare.write_json(out/'execution.json',report)
  if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
  return row
 def artifact(row,channel='stdout'): return compare.command_artifact(row,channel)
 def class_tree(path): return {p.relative_to(path).as_posix():compare.pin(p) for p in sorted(path.rglob('*.class'))}
 try:
  driver_compile=command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',driver_classes,control_driver],'compile-independent-control-driver','javac8')
  report['driver_compile']={'command':driver_compile['index'],'exit_code':driver_compile['exit_code'],'stdout':compare.pin(Path(driver_compile['streams']['stdout']['path'])),'stderr':compare.pin(Path(driver_compile['streams']['stderr']['path']))}
  if driver_compile['exit_code']!=0: raise RuntimeError('control driver compilation failed')
  driver_files=sorted(driver_classes.rglob('*.class'))
  driver_tree=[f.relative_to(driver_classes).as_posix() for f in driver_files]
  expected_driver_tree=['LoopConditionInvokeControlDriver$Case.class','LoopConditionInvokeControlDriver.class']
  if driver_tree!=expected_driver_tree: raise RuntimeError(f'unexpected driver class tree: {driver_tree}')
  report['driver_classes']=[compare.pin(p) for p in driver_files]
  for leg in LEGS:
   for profile,debug in (('debug','-g'),('no-debug','-g:none')):
    key=leg+'-'+profile; dest=out/'original'/key/'classes'; dest.mkdir(parents=True)
    if leg=='javac8': argv=[jdks[leg]['tools']['javac'],'-source','8','-target','8',debug,'-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',dest,control_source]
    else: argv=[jdks[leg]['tools']['javac'],'--release','8',debug,'-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',dest,control_source]
    cr=command(argv,'compile-original-'+key,leg)
    cell={'compiler':leg,'profile':profile,'cell_key':key,'command':cr['index'],'exit_code':cr['exit_code'],'class_root':str(dest),'stdout':compare.pin(Path(cr['streams']['stdout']['path'])),'stderr':compare.pin(Path(cr['streams']['stderr']['path'])),'class_tree':class_tree(dest),'class_facts':None,'class_facts_error':None}
    if cr['exit_code']==0:
     classfile=dest/(TARGET_INTERNAL+'.class')
     if not classfile.is_file(): cell['class_facts_error']='compiled output lacks expected target binary path'
     else:
      try:
       cell['class_facts']=fullfacts(baseline_helpers,compare,physical,classfile,'original '+key)
       if cell['class_facts']['class_name']!=TARGET_INTERNAL or cell['class_facts']['major']!=52: raise RuntimeError('target binary name/major mismatch')
       inventory={(m['name'],m['descriptor']) for m in cell['class_facts']['methods']}
       if inventory!=EXPECTED_METHODS: raise RuntimeError(f'physical method inventory differs: {sorted(inventory)}')
       if set(cell['class_tree'])!={TARGET_INTERNAL+'.class'}: raise RuntimeError(f'unexpected target class tree: {sorted(cell["class_tree"])}')
       bundle=out/'bundles'/(key+'.jar'); bundle.parent.mkdir(parents=True,exist_ok=True); cell['bundle']=make_bundle(compare,dest,bundle)
      except Exception as exc: cell['class_facts_error']=repr(exc)
    report['profile_cells'].append(cell); compare.write_json(out/'execution.json',report)
  driver_root=driver_classes.resolve(); expected_rows=doc['cases']
  for cell in report['profile_cells']:
   if cell['exit_code']!=0 or cell.get('class_facts') is None or cell.get('class_facts_error') is not None: continue
   target_root=Path(cell['class_root']).resolve()
   for runtime in RUNTIMES:
    rr=command([sys.executable,'-B',runtime_copy,'30',jdks[runtime]['tools']['java'],'-Xverify:all','-cp',driver_root,DRIVER_MAIN,target_root,target_root],f'original-runtime-{cell["cell_key"]}-{runtime}',runtime)
    parsed=[]; parse_error=None
    if rr['exit_code']==0:
     try: parsed=parse_rows(artifact(rr),expected_rows)
     except Exception as exc: parse_error=repr(exc)
    matches=(rr['exit_code']==0 and parse_error is None
             and artifact(rr)==doc['expected_stdout'].encode('utf-8')
             and [semantic(x) for x in parsed]==[semantic(x) for x in expected_rows])
    row={'cell_key':cell['cell_key'],'compiler':cell['compiler'],'profile':cell['profile'],'runtime':runtime,'command':rr['index'],'exit_code':rr['exit_code'],'parse_error':parse_error,'matches_control_manifest':matches,'rows':parsed,'target_root':str(target_root),'application_classpath':[str(driver_root)],'stdout':compare.pin(Path(rr['streams']['stdout']['path'])),'stderr':compare.pin(Path(rr['streams']['stderr']['path']))}
    report['runtime_cells'].append(row); compare.write_json(out/'execution.json',report)
   wr=command([sys.executable,'-B',runtime_copy,'30',jdks['javac23']['tools']['java'],'-Xverify:all','-cp',driver_root,DRIVER_MAIN,target_root,empty],f'wrong-root-{cell["cell_key"]}','javac23')
   err=artifact(wr,'stderr'); report['wrong_root_cells'].append({'cell_key':cell['cell_key'],'command':wr['index'],'exit_code':wr['exit_code'],'rejected':wr['exit_code']==1 and b'wrong CodeSource:' in err,'actual_target_root':str(target_root),'expected_wrong_root':str(empty),'stdout':compare.pin(Path(wr['streams']['stdout']['path'])),'stderr':compare.pin(Path(wr['streams']['stderr']['path']))}); compare.write_json(out/'execution.json',report)
  for cell in report['profile_cells']:
   if cell['exit_code']!=0 or cell.get('class_facts') is None or cell.get('class_facts_error') is not None: continue
   for evidence in EVIDENCE:
    argv=[cli,'class-source','--input',Path(cell['class_root'])/(TARGET_INTERNAL+'.class'),'--class',TARGET_INTERNAL,'--policy','single-class','--release','8','--format','json']
    if evidence=='all': argv += ['--evidence','all']
    ar=command(argv,f'jarde-{cell["cell_key"]}-{evidence}',cell['compiler'])
    raw=artifact(ar); api_dest=out/'jarde'/cell['cell_key']/evidence; api_dest.mkdir(parents=True)
    jsonfile=api_dest/'class-source.json'; jsonfile.write_bytes(raw)
    summary={'cell_key':cell['cell_key'],'compiler':cell['compiler'],'profile':cell['profile'],'evidence':evidence,'command':ar['index'],'exit_code':ar['exit_code'],'input':compare.pin(Path(cell['class_root'])/(TARGET_INTERNAL+'.class')),'report':compare.pin(jsonfile),'whole_class_text':None,'methods':[],'physical_method_inventory':[],'method_inventory_matches':False}
    try:
     api=json.loads(raw.decode('utf-8','strict')); text=api.get('text')
     if isinstance(text,str):
      txt=api_dest/'whole-class.java'; txt.write_bytes(text.encode('utf-8')); summary['whole_class_text']=compare.pin(txt)
     methods=api.get('methods',[]); physical_by_key={(m['name'],m['descriptor']):m for m in cell['class_facts']['methods']}
     for method in methods:
      item=method.get('item',{}); name=item.get('name',{}).get('escaped'); desc=item.get('descriptor',{}).get('escaped'); phys=physical_by_key.get((name,desc)); outcome=method.get('outcome',{}); body=outcome.get('report',{})
      summary['methods'].append({'name':name,'descriptor':desc,'identity':item.get('identity'),'outcome_kind':outcome.get('kind'),'quality':body.get('quality'),'fallbacks':body.get('fallbacks'),'diagnostics':body.get('diagnostics'),'raw_text':body.get('text'),'source_map':body.get('source_map'),'map_audit':baseline_helpers.audit_method_map(method,phys) if phys is not None else {'issues':['no matching physical method']}})
     summary['physical_method_inventory']=[(m.get('name'),m.get('descriptor')) for m in summary['methods']]
     summary['method_inventory_matches']=sorted(summary['physical_method_inventory'])==sorted(EXPECTED_METHODS)
     summary['declared_class_name']=api.get('class_name')
    except Exception as exc: summary['json_parse_error']=repr(exc)
    report['jarde_api_cells'].append(summary); compare.write_json(out/'execution.json',report)
  jadx_version=command([JADX,'--version'],'jadx-version','javac23')
  report['jadx_version']={'command':jadx_version['index'],'exit_code':jadx_version['exit_code'],'stdout':compare.pin(Path(jadx_version['streams']['stdout']['path'])),'stderr':compare.pin(Path(jadx_version['streams']['stderr']['path']))}
  for cell in report['profile_cells']:
   if cell['compiler']!='javac23' or cell['exit_code']!=0 or cell.get('class_facts') is None or cell.get('class_facts_error') is not None or not cell.get('bundle'): continue
   dest=out/'jadx'/cell['profile']/'sources'
   jr=command([JADX,'--threads-count','1','--no-res','--config','none','-d',dest,cell['bundle']['path']],f'jadx-full-class-{cell["profile"]}','javac23')
   java_files=sorted(dest.rglob('*.java')) if dest.exists() else []
   sources=[compare.pin(f) for f in java_files]
   actual_tree={f.relative_to(dest).as_posix():compare.pin(f) for f in java_files} if dest.exists() else {}
   expected_tree={Path(x['path']).relative_to(dest).as_posix():x for x in sources}
   complete=(jr['exit_code']==0 and bool(sources) and actual_tree==expected_tree
             and all(Path(x['path']).suffix=='.java' for x in sources))
   report['jadx_outputs'].append({'profile':cell['profile'],'input':cell['bundle'],'command':jr['index'],'exit_code':jr['exit_code'],'source_root':str(dest),'sources':sources,'source_tree_complete':complete})
   compare.write_json(out/'execution.json',report)
  report['source_closure_after']=compare.source_closure(root)
  report['source_unchanged']=report['source_closure_after']==source_before
  report['external_pins_after']=[compare.pin(Path(q)) for q in external_paths]
  report['external_inputs_unchanged']=report['external_pins_after']==external_before
  report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
  report['local_copies_after']=[compare.pin(control_source),compare.pin(control_driver),compare.pin(runtime_copy)]
  report['local_copies_unchanged']=[(x['bytes'],x['sha256']) for x in report['local_copies_after']]==[(compare.pin(p)['bytes'],compare.pin(p)['sha256']) for p in (source,driver,RUNTIME_BOUND)]
  report['counts_derived']={'commands':len(rows),'raw_streams':2*len(rows),'original_compile_cells':len(report['profile_cells']),'original_successful_compiles':sum(x['exit_code']==0 and x.get('class_facts') is not None for x in report['profile_cells']),'original_vm_cells':len(report['runtime_cells']),'control_case_observations':sum(len(x['rows']) for x in report['runtime_cells']),'wrong_root_cells':len(report['wrong_root_cells']),'jarde_api_cells':len(report['jarde_api_cells']),'jadx_source_profiles':len(report['jadx_outputs'])}
  if not report['source_unchanged'] or not report['external_inputs_unchanged'] or not report['target_absent'] or not report['local_copies_unchanged']: raise RuntimeError('source/external-input/target/local-copy guard failed')
  report['status']='captured-pending-independent-review'
 except BaseException as exc:
  report['status']='failed'; report['error']=repr(exc); raise
 finally:
  try:
   report['source_closure_after_finally']=compare.source_closure(root)
   report['source_unchanged_finally']=report['source_closure_after_finally']==source_before
   report['external_pins_after_finally']=[compare.pin(Path(q)) for q in external_paths]
   report['external_inputs_unchanged_finally']=report['external_pins_after_finally']==external_before
   report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
   if not report['source_unchanged_finally'] or not report['external_inputs_unchanged_finally'] or not report['target_absent_finally']:
    report['status']='failed'; report['final_guard_error']='source closure changed or target appeared'
  except BaseException as exc:
   report['status']='failed'; report['final_guard_error']=repr(exc)
  report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  compare.write_json(out/'execution.json',report)
  shutil.copy2(__file__,out/'collector.py')
 print(json.dumps({'status':report['status'],'commands':len(rows),'original_vm_cells':len(report['runtime_cells']),'control_observations':report.get('counts_derived',{}).get('control_case_observations'),'error':report.get('error')}))
 return 0
if __name__=='__main__': raise SystemExit(main())
