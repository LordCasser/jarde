#!/usr/bin/env python3
"""Compare a saved controls-driver stdout byte-for-byte with controls.json."""
import argparse, hashlib, json, sys
from pathlib import Path

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--stdout', type=Path, required=True)
    args = parser.parse_args()
    doc = json.loads(args.manifest.read_text(encoding='utf-8'))
    if doc.get('schema') != 'test-loop-condition-invoke-dynamic-controls-v1':
        raise SystemExit('unexpected controls manifest schema')
    raw = args.stdout.read_bytes()
    expected = doc.get('expected_stdout', '').encode('utf-8')
    if raw != expected:
        raise SystemExit('control runtime stdout differs from the exact five-row oracle')
    print(json.dumps({'matched_control_rows': len(doc['cases']), 'stdout_sha256': hashlib.sha256(raw).hexdigest(), 'status': 'matches-control-manifest'}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
