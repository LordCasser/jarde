package controls;

/** Dynamic independent control for TestLoopConditionInvoke's loop-condition semantics. */
public final class LoopConditionInvokeControl {
    private static final char STOP_CHAR = 0;

    private int pos;
    private int calls;
    private final char[] input;
    private final int throwAtCall;
    private final StringBuilder trace = new StringBuilder();

    public LoopConditionInvokeControl(char[] input, int startingPos, int throwAtCall) {
        this.input = input.clone();
        this.pos = startingPos;
        this.throwAtCall = throwAtCall;
    }

    public boolean test(char lastChar) {
        int startPos = pos;
        int ch;
        while ((ch = next()) != STOP_CHAR) {
            if (ch == lastChar) {
                return true;
            }
        }
        pos = startPos;
        return false;
    }

    private char next() {
        int call = calls++;
        trace.append(call).append('@').append(pos).append('=');
        if (call == throwAtCall) {
            trace.append("throw;");
            pos++;
            throw new ProbeFailure("next call " + call);
        }
        if (pos < 0 || pos >= input.length) {
            trace.append("eof;");
            throw new IllegalStateException("control input exhausted at " + pos);
        }
        char value = input[pos++];
        trace.append((int) value).append(';');
        return value;
    }

    public int getPos() {
        return pos;
    }

    public int getCalls() {
        return calls;
    }

    public String getTrace() {
        return trace.toString();
    }

    public static final class ProbeFailure extends RuntimeException {
        private static final long serialVersionUID = 1L;

        ProbeFailure(String message) {
            super(message);
        }
    }
}
