//! A proved `char` assignment in a loop condition widens to its existing `int` local.
use jarde::*;
use jarde_jvm::ir::Representation;
use jarde_reader::budget::{Budget, CancellationToken};
use jarde_reader::model::ExecutionReport;
use std::collections::BTreeSet;
use std::slice;

const UPSTREAM_DEBUG: &[u8] = include_bytes!(
    "fixtures/java8/assignment-condition-widening/upstream-debug/TestLoopConditionInvoke$TestCls.class"
);
const UPSTREAM_NODEBUG: &[u8] = include_bytes!(
    "fixtures/java8/assignment-condition-widening/upstream-no-debug/TestLoopConditionInvoke$TestCls.class"
);
const CONTROL_JAVAC8_DEBUG: &[u8] = include_bytes!(
    "fixtures/java8/assignment-condition-widening/javac8-debug/LoopConditionInvokeControl.class"
);
const CONTROL_JAVAC8_NODEBUG: &[u8] = include_bytes!(
    "fixtures/java8/assignment-condition-widening/javac8-no-debug/LoopConditionInvokeControl.class"
);
const CONTROL_JAVAC23_DEBUG: &[u8] = include_bytes!(
    "fixtures/java8/assignment-condition-widening/javac23-debug/LoopConditionInvokeControl.class"
);
const CONTROL_JAVAC23_NODEBUG: &[u8] = include_bytes!(
    "fixtures/java8/assignment-condition-widening/javac23-no-debug/LoopConditionInvokeControl.class"
);

const TEST_BCIS: &[u32] = &[0, 1, 4, 5, 6, 9, 10, 11, 14, 15, 16, 19, 20, 21, 22, 23, 26, 27];
const UPSTREAM_METHODS: &[&str] = &["<init>", "test", "next"];
const CONTROL_METHODS: &[&str] = &["<init>", "test", "next", "getPos", "getCalls", "getEvents"];

struct Fixture {
    label: &'static str,
    bytes: &'static [u8],
    class: &'static str,
    methods: &'static [&'static str],
}

const FIXTURES: &[Fixture] = &[
    Fixture { label: "upstream debug", bytes: UPSTREAM_DEBUG, class: "jadx/tests/integration/loops/TestLoopConditionInvoke$TestCls", methods: UPSTREAM_METHODS },
    Fixture { label: "upstream no-debug", bytes: UPSTREAM_NODEBUG, class: "jadx/tests/integration/loops/TestLoopConditionInvoke$TestCls", methods: UPSTREAM_METHODS },
    Fixture { label: "control javac8 debug", bytes: CONTROL_JAVAC8_DEBUG, class: "controls/LoopConditionInvokeControl", methods: CONTROL_METHODS },
    Fixture { label: "control javac8 no-debug", bytes: CONTROL_JAVAC8_NODEBUG, class: "controls/LoopConditionInvokeControl", methods: CONTROL_METHODS },
    Fixture { label: "control javac23 debug", bytes: CONTROL_JAVAC23_DEBUG, class: "controls/LoopConditionInvokeControl", methods: CONTROL_METHODS },
    Fixture { label: "control javac23 no-debug", bytes: CONTROL_JAVAC23_NODEBUG, class: "controls/LoopConditionInvokeControl", methods: CONTROL_METHODS },
];

fn open(bytes: &[u8]) -> ArtifactSnapshot {
    Engine::new()
        .open(ArtifactInput::bytes(bytes.to_vec()), &mut task_budget(&[]).unwrap())
        .expect("the frozen standalone class opens")
}

fn report(snapshot: &ArtifactSnapshot, class: &str, evidence: RecoveryEvidenceRequest) -> ClassSourceReport {
    let request = ClassSourceRequest {
        class: ClassRef::Name { class: ClassNameQuery::internal(class) },
        environment: EnvironmentRequest {
            snapshot: snapshot.id().clone(),
            scope: PhysicalScope::SnapshotAll,
            policy: EnvironmentPolicy::SingleClass,
            profile: RuntimeProfile {
                java_release: 8,
                multi_release: MultiReleasePolicy::Disabled,
                layout: LayoutMode::Generic,
            },
            loader: LoaderId("app".to_owned()),
        },
    };
    match Engine::new().class_source_with_evidence(
        slice::from_ref(snapshot),
        &request,
        &evidence,
        &mut task_budget(&[]).unwrap(),
    ).expect("the class-source request answers") {
        OperationOutcome::Performed(report) => report,
        other => panic!("{} should have a complete class-source answer: {other:?}", class),
    }
}

fn member<'a>(report: &'a ClassSourceReport, name: &str) -> &'a ClassSourceMethod {
    report.methods.iter()
        .find(|method| method.item.name.raw().0 == name.as_bytes())
        .unwrap_or_else(|| panic!("missing member {name}"))
}

fn recovered<'a>(report: &'a ClassSourceReport, name: &str) -> &'a RecoveryReport {
    match &member(report, name).outcome {
        ClassSourceOutcome::Recovered { report, .. } => report,
        other => panic!("{name} was not recovered: {other:?}"),
    }
}

fn assert_structured(report: &ClassSourceReport, fixture: &Fixture) {
    assert_eq!(report.methods.len(), fixture.methods.len(), "{} method inventory", fixture.label);
    for name in fixture.methods {
        let method = recovered(report, name);
        assert!(method.produced(), "{}.{} produced no body", fixture.label, name);
        assert_eq!(method.representation, Representation::Java, "{}.{}", fixture.label, name);
        assert_eq!(method.quality, Quality::Structured, "{}.{}: {}", fixture.label, name, method.text);
        assert_eq!(method.content, RecoveryContent::ContainsStatements, "{}.{}", fixture.label, name);
        assert!(!method.text.contains("@bytecode"), "{}.{} remains quoted:\n{}", fixture.label, name, method.text);
    }
}

fn assert_test_code_map(report: &ClassSourceReport, label: &str) {
    let method = member(report, "test");
    let body = recovered(report, "test");
    assert_eq!(body.evidence.state(RecoveryEvidenceKind::SourceMap), EvidenceState::Complete, "{label}");
    let mut mapped = BTreeSet::new();
    for segment in body.source_map.segments() {
        let origin = segment.origin();
        for anchor in std::iter::once(origin.primary()).chain(origin.derived()) {
            if anchor.method() == Some(&method.item.identity) {
                mapped.insert(anchor.bci());
            }
        }
    }
    assert_eq!(mapped, TEST_BCIS.iter().copied().collect(), "{label} must map every physical test(C)Z instruction to this same method");
}

fn assert_widened_condition(report: &ClassSourceReport, label: &str) {
    let body = recovered(report, "test");
    assert_test_code_map(report, label);
    assert!(body.text.contains("while ("), "{label}: {}", body.text);
    assert_eq!(body.text.matches("next()").count(), 1, "the assigned RHS is evaluated once: {label}: {}", body.text);
    assert!(body.text.contains("return true"), "{label}: {}", body.text);
    assert!(body.text.contains("return false"), "{label}: {}", body.text);
    assert!(!body.text.contains("(int)"), "widening must not add a cast: {label}: {}", body.text);
}

fn assert_same_publication(left: &ClassSourceReport, right: &ClassSourceReport, fixture: &Fixture) {
    assert_eq!(left.text, right.text, "{} whole class changed with evidence selection", fixture.label);
    for name in fixture.methods {
        let a = recovered(left, name);
        let b = recovered(right, name);
        assert_eq!(member(left, name).text, member(right, name).text, "{}.{} member text", fixture.label, name);
        assert_eq!(a.text, b.text, "{}.{} raw method text", fixture.label, name);
        assert_eq!(a.source_map, b.source_map, "{}.{} raw method map", fixture.label, name);
        assert_eq!((a.quality, a.representation, a.content), (b.quality, b.representation, b.content), "{}.{} result decision", fixture.label, name);
    }
}

#[test]
fn fixed_upstream_and_dynamic_controls_recover_the_widened_loop_condition() {
    for fixture in FIXTURES {
        let snapshot = open(fixture.bytes);
        let essential = report(&snapshot, fixture.class, RecoveryEvidenceRequest::essential());
        let all = report(&snapshot, fixture.class, RecoveryEvidenceRequest::all());
        assert_structured(&essential, fixture);
        assert_structured(&all, fixture);
        assert_same_publication(&essential, &all, fixture);
        assert_widened_condition(&all, fixture.label);
    }
}

#[test]
fn cancellation_does_not_publish_a_partial_condition_body() {
    let fixture = &FIXTURES[0];
    let snapshot = open(fixture.bytes);
    let request = ClassSourceRequest {
        class: ClassRef::Name { class: ClassNameQuery::internal(fixture.class) },
        environment: EnvironmentRequest {
            snapshot: snapshot.id().clone(),
            scope: PhysicalScope::SnapshotAll,
            policy: EnvironmentPolicy::SingleClass,
            profile: RuntimeProfile { java_release: 8, multi_release: MultiReleasePolicy::Disabled, layout: LayoutMode::Generic },
            loader: LoaderId("app".to_owned()),
        },
    };
    let token = CancellationToken::new();
    token.cancel();
    let mut budget = Budget::with_cancellation_token(task_budget(&[]).unwrap().limits().clone(), token);
    let outcome = Engine::new().class_source_with_evidence(
        slice::from_ref(&snapshot), &request, &RecoveryEvidenceRequest::all(), &mut budget,
    ).expect("cancellation is reported through the public class-source entry");
    match outcome {
        OperationOutcome::Incomplete(report) => assert!(matches!(report.execution, ExecutionReport::Cancelled { .. })),
        OperationOutcome::Performed(report) => {
            assert!(matches!(report.execution, ExecutionReport::Cancelled { .. }));
            assert!(report.text.is_empty(), "cancelled class source published text");
        }
        other => panic!("unexpected cancelled result: {other:?}"),
    }
}
