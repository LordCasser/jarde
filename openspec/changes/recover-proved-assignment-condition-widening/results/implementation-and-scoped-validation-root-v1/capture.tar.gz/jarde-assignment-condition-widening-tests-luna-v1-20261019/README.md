# Assignment-condition widening public regression patch

This private, unapplied patch adds `tests/p3_assignment_condition_widening.rs`. It uses the six exact class-file profiles from the accepted original and dynamic-control receipts: the upstream nested class in debug/no-debug form, plus the six-method control built by javac 8 and javac 23 with and without debug attributes.

The test exercises the ordinary class-source entry with essential and all evidence. It requires every physical method to remain structured and unquoted, compares complete class text and each raw method text/map across evidence selections, and checks that `test(C)Z` evaluates `next()` once in a `while`, preserves both boolean returns, adds no `(int)` cast, and maps all 18 physical Code BCIs to the same method identity. It deliberately does not compare usage or optional region detail. The second test checks that cancellation through the public class-source API cannot publish a partial class artifact.

Fixture paths are the six paths specified by root for the freeze; they are not yet present in this shared checkout. The test and its fixture references have not been compiled or run. This patch does not test the control's generated source compilation/runtime; those are covered by the root-owned complete matrix. In particular, the upstream helper returns zero, so its runtime cases do not exercise the true loop branch.

`pins.json` records the OpenSpec/test/API source files and the exact receipts/class artifacts used for the inventory and Code-BCI constants. No shared repository files were changed.
