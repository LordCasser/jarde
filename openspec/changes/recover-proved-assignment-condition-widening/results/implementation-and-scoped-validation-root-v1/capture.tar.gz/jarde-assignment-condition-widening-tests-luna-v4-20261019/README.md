# Public-test borrow fix (v4)

This private patch changes only the two result-comparison tuples in `tests/p3_assignment_condition_widening.rs`: it borrows `RecoveryContent` with `&d.content`, `&e.content`, and `&a.content` instead of attempting to move those non-`Copy` values out of shared report references. No assertion meaning or production code changes.

The raw compiler stderr is preserved and pinned in `pins.json`. A static pass over the current test source found no other tuple construction that moves non-`Copy` report fields: remaining comparisons use `assert_eq!` expressions, which borrow their operands, and the source-map access remains by reference. This patch is prepared against the current shared test file's SHA in `pins.json`; it was not applied, compiled, or run.
