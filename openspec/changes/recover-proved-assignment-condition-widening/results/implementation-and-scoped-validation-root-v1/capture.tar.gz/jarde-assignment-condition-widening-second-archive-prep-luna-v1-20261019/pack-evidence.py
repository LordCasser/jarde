#!/usr/bin/env python3
"""Pack the explicitly selected assignment-condition evidence trees, with byte-level reopen checks."""
from __future__ import annotations
import argparse, hashlib, json, os, tarfile, tempfile
from pathlib import Path

PRIVATE = Path('/private/tmp').resolve()
SCOPE_ROOT_NAMES = ('jarde-loop-condition-invoke-controls-generated-root-v2-20261019', 'jarde-loop-condition-invoke-controls-generated-first-wrapper-error-root-v1-20261019', 'jarde-loop-condition-invoke-controls-generated-root-v1-20261019', 'jarde-assignment-condition-widening-luna-v1-20261019', 'jarde-assignment-condition-widening-luna-v2-20261019', 'jarde-assignment-condition-widening-luna-v3-20261019', 'jarde-assignment-condition-widening-luna-v4-20261019', 'jarde-assignment-condition-widening-tests-luna-v1-20261019', 'jarde-assignment-condition-widening-tests-luna-v2-20261019', 'jarde-assignment-condition-widening-tests-luna-v3-20261019', 'jarde-assignment-condition-widening-tests-luna-v4-20261019', 'jarde-assignment-condition-widening-tests-luna-v5-20261019', 'jarde-assignment-condition-widening-focused-root-v1-20261019', 'jarde-assignment-condition-widening-focused-root-v2-20261019', 'jarde-assignment-condition-widening-focused-root-v3-20261019', 'jarde-assignment-condition-widening-public-root-v1-20261019', 'jarde-assignment-condition-widening-public-root-v2-20261019', 'jarde-assignment-condition-widening-broad-root-v1-20261019', 'jarde-assignment-condition-widening-broad-resume-root-v1-20261019', 'jarde-assignment-condition-widening-focused-prep-root-v1-20261019', 'jarde-assignment-condition-widening-focused-prep-root-v2-20261019', 'jarde-assignment-condition-widening-public-prep-root-v1-20261019', 'jarde-assignment-condition-widening-broad-prep-root-v1-20261019', 'jarde-assignment-condition-widening-broad-resume-prep-root-v1-20261019', 'jarde-assignment-condition-widening-final-compare-prep-luna-v1-20261019', 'jarde-assignment-condition-widening-final-compare-prep-luna-v2-20261019', 'jarde-assignment-condition-widening-final-acceptance-prep-luna-v1-20261019', 'jarde-assignment-condition-widening-final-collectors-root-v1-20261019')
EXPLICIT_FILE_NAMES = ('jarde-loop-condition-invoke-controls-generated-root-v1-20261019.stdout.raw', 'jarde-loop-condition-invoke-controls-generated-root-v1-20261019.stderr.raw')
PREP_NAMES = ('README.md', 'scope-manifest.json', 'pins.json', 'pack-evidence.py')
EXCLUDED_COMPONENTS = {'candidate-cli', 'target', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache', '.cache', 'node_modules'}
ACTIVE_STATUSES = {'running', 'in_progress', 'started', 'collecting'}
PENDING_STATUSES = {'captured-pending-independent-review', 'commands_passed_pending_independent_acceptance'}

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def checked_receipts(roots):
    for root in roots:
        receipt = root / 'execution.json'
        if not receipt.is_file():
            continue
        row = json.loads(receipt.read_text(encoding='utf-8'))
        status = row.get('status')
        if status in ACTIVE_STATUSES:
            raise RuntimeError(f'refusing to archive nonterminal receipt: {receipt} ({status})')
        if status in PENDING_STATUSES:
            review = root / 'root-review.json'
            if not review.is_file() or not str(json.loads(review.read_text(encoding='utf-8')).get('status', '')).startswith('root_accepted'):
                raise RuntimeError(f'refusing to archive unaccepted pending receipt: {receipt}')

def ordinary(path: Path) -> bool:
    return path.is_file() and not path.is_symlink()

def collect_files(roots, explicit, prep):
    selected = {}
    for root in roots:
        for path in root.rglob('*'):
            if any(part in EXCLUDED_COMPONENTS for part in path.parts):
                continue
            if path.is_symlink():
                raise RuntimeError(f'refusing symlink in selected evidence tree: {path}')
            if path.is_file():
                selected[path.resolve()] = path.resolve()
    for path in explicit + prep:
        if not ordinary(path):
            raise RuntimeError(f'missing/non-regular selected file: {path}')
        selected[path.resolve()] = path.resolve()
    return sorted(selected.values(), key=lambda p: p.relative_to(PRIVATE).as_posix())

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True, help='new tar.gz path outside all selected evidence roots')
    args=ap.parse_args()
    out=args.out.resolve()
    inventory_path=out.with_suffix(out.suffix+'.inventory.json')
    if out.exists() or inventory_path.exists():
        raise FileExistsError('refusing to overwrite archive or inventory')
    if out.is_relative_to(Path(__file__).resolve().parent):
        raise RuntimeError('archive output must be outside the preparation directory')
    roots=[PRIVATE/name for name in SCOPE_ROOT_NAMES]
    missing=[str(p) for p in roots if not p.is_dir()]
    if missing: raise RuntimeError(f'missing explicit evidence roots: {missing}')
    for root in roots:
        if out.is_relative_to(root): raise RuntimeError(f'archive path is inside selected root: {out}')
    checked_receipts(roots)
    explicit=[PRIVATE/name for name in EXPLICIT_FILE_NAMES]
    prep=[Path(__file__).resolve().parent/name for name in PREP_NAMES]
    files=collect_files(roots, explicit, prep)
    rows=[]
    for path in files:
        raw=path.read_bytes()
        rows.append({'path':path.relative_to(PRIVATE).as_posix(),'bytes':len(raw),'sha256':sha(raw)})
    manifest={'schema':'assignment-condition-second-persistent-archive-v1','status':'prepared_inputs_verified_at_pack_time',
              'member_count':len(rows),'members':rows,'selected_roots':list(SCOPE_ROOT_NAMES),
              'excluded_components':sorted(EXCLUDED_COMPONENTS)}
    out.parent.mkdir(parents=True,exist_ok=True)
    with tarfile.open(out,'x:gz') as tar:
        for path in files:
            tar.add(path, arcname=path.relative_to(PRIVATE).as_posix(), recursive=False)
        blob=(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
        info=tarfile.TarInfo('ARCHIVE_INVENTORY.json');info.size=len(blob);info.mode=0o644
        import io
        tar.addfile(info,io.BytesIO(blob))
    with tarfile.open(out,'r:gz') as tar:
        members={m.name:m for m in tar.getmembers() if m.isfile()}
        if set(members)!={r['path'] for r in rows}|{'ARCHIVE_INVENTORY.json'}:
            raise RuntimeError('archive member inventory changed during write')
        for row in rows:
            data=tar.extractfile(members[row['path']]).read()
            if len(data)!=row['bytes'] or sha(data)!=row['sha256']:
                raise RuntimeError(f'tar reopen mismatch: {row["path"]}')
        stored=json.loads(tar.extractfile(members['ARCHIVE_INVENTORY.json']).read())
        if stored!=manifest: raise RuntimeError('embedded inventory differs after reopen')
    inv_raw=(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
    with inventory_path.open('xb') as f: f.write(inv_raw)
    print(json.dumps({'status':'packed_and_reopened','archive':str(out),'archive_sha256':sha(out.read_bytes()),
                      'inventory':str(inventory_path),'inventory_sha256':sha(inv_raw),'member_count':len(rows)},indent=2))
if __name__=='__main__': main()
