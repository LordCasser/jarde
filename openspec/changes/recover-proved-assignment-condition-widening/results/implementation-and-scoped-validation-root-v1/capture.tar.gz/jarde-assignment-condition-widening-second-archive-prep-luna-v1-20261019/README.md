# Assignment-condition second archive preparation

This private package prepares a reproducible tar and reopen verifier for the leaf evidence. It covers the accepted generated-controls root-v2 receipt and first-wrapper failure, implementation Luna v1-v4, public-test Luna v1-v5, focused root v1-v3, public root v1-v2, broad root v1 and resume root v1, plus the final comparison, collectors, and acceptance-preparation bundles. The initial controls baseline archive is intentionally omitted.

The exact selected roots, external wrapper stdout/stderr files, and current per-file SHA-256 inventory are recorded in `scope-manifest.json`. `pack-evidence.py` enumerates only those fixed roots; it does not scan all of `/private/tmp`. It excludes `candidate-cli`, build targets, caches, and `__pycache__`. At pack time it rejects any receipt still marked active and requires root acceptance for pending receipts. The resume receipt is complete but is still pending independent root acceptance, so the script will refuse to pack until that review is present.

The script writes a gzip tar, embeds a SHA-256 inventory, reopens the tar, verifies every member byte count and hash, and writes a sidecar inventory. It was not run. No archive was created.
