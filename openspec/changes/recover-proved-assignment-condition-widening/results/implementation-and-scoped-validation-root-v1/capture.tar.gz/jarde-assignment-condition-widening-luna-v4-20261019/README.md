# Assignment-condition test seam correction (private v4)

This patch fixes the test builder's declaring-class spelling to use the binary internal name (`/` separators), which is required by `declares_private` to match `CallTarget::owner()`. It also retains the detailed refusal and stop payloads in the two test panic arms. Production logic is unchanged.

Static path: `call_expr` routes a non-constructor `invokespecial` through `special_receiver`; `special_receiver` preserves the rendered receiver only when `declares_private(target)` succeeds. That predicate compares `self.declaring_class` directly with `target.owner()`, so the previous dotted spelling could not match the internal owner.

No Cargo, JDK, CLI, Git, or network commands were run. SHA-256 pins are in `source-pins.json`.
