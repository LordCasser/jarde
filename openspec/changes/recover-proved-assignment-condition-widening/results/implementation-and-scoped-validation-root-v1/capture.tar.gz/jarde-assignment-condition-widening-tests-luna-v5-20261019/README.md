# Class-source evidence-map expectation correction (v5)

This minimal private patch is based on the current shared test source. It keeps the default/all map equality assertion, and changes only the explicit-essential expectation: its map must be empty and its `SourceMap` evidence state must be `NotRequested`. The test continues to compare all three text and result-decision outputs and keeps the exact method ownership, dynamic physical BCI coverage, anchor validation, UTF-8 span checks, and cancellation test.

This follows the public API contract: `Engine::class_source` requests `essential()` plus `SourceMap`, while an explicit `RecoveryEvidenceRequest::essential()` does not request that category. The focused failure stdout and source base are pinned in `pins.json`. No shared file was edited and this patch was not applied or run.
