# Private implementation snapshot: proved assignment condition widening

This snapshot is based on the current shared `crates/jarde-java/src/build.rs` at SHA-256 `d22ee8f1c40d0a98a174e759904a6a97313b85728bb3056d4aeba18ca8704df9`. The result is a private copy only. It changes the `duplicate_expression` Expression gate to accept a known RHS type when it is exactly the declared target or the existing `widens(presented, target)` predicate proves conversion. The assignment target, RHS rendering call count/location, error text, LocalAssign AST and origin construction are unchanged. Existing candidate admission still limits target types to `int` or a reference, so the only new primitive source/target pairs are byte/short/char to int.

The added consumer test uses the accepted original debug class for `TestLoopConditionInvoke$TestCls`, already frozen in the root's fixture-preparation package at the same relative fixture path. It builds a real Builder from the class's actual IR/SSA/region and reaches `duplicate_expression` using the real `render_value` call for `next()`, which presents `char`. The test also injects Byte/Short/Int consumer presentations only through the existing `conditional_values` test seam after rendering that real call; comments explicitly limit those cases to consumer-relation evidence rather than new JVM fixture claims. Negative cases cover missing type, boolean/reference incompatibility, narrowing targets and mismatched tested value/BCI.

Files:

- `changes.patch`: source-only patch for `build.rs`.
- `repo/crates/jarde-java/src/build.rs`: complete private result file.
- `repo/tests/fixtures/java8/assignment-condition-widening/upstream-debug/TestLoopConditionInvoke$TestCls.class`: private copy of the already frozen 836-byte class; root prepared fixture is byte-identical.
- `source-pins.json`: base/result/patch/fixture hashes.

No Cargo, rustfmt, JDK, Jarde/JADX CLI, network or Git command was run. No tests are claimed. Root must first accept the full controls generated baseline before integrating any candidate. The test exercises the existing Builder consumer; broader value/render, budget, cancellation, full-class and generated-control gates remain for root's actual focused and acceptance runs.
