# Assignment-condition test diagnostics (private v3)

This patch changes only the two new test assertions to preserve the detailed `ValueRenderFailure::Refusal(reason)` and `Stop(stop)` payloads in panic messages. It does not change production code, enum derives, or other test behavior.

No Cargo, JDK, CLI, Git, or network commands were run.

SHA-256 pins are in `source-pins.json`.
