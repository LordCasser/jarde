#!/usr/bin/env python3
"""Compile complete saved controls sources and compare bounded JVM observations.

Preparation only: caller supplies a completed and independently accepted controls
baseline receipt, its SHA-256, and the candidate CLI used by that baseline.
"""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, re, shutil, sys
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
BASELINE_SCHEMA='test-loop-condition-invoke-controls-baseline-v1'
COMPARE_REL='openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD_REL='openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL='openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_REL='openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
BASE_HELPERS=Path('/private/tmp/jarde-assignment-condition-widening-final-collectors-root-v1-20261019/primary_baseline/collect_baseline.py')
BASE_HELPERS_SHA='74f30a7b9d66812544d1092ec59ac6026326ad6a78ea7bef875725395c97b556'
DRIVER='LoopConditionInvokeControlDriver'; INTERNAL='controls/LoopConditionInvokeControl'
METHODS={('<init>','([CI)V'),('test','(C)Z'),('next','()C'),('getPos','()I'),('getCalls','()I'),('getEvents','()I')}
FIELDS={('STOP_CHAR','C',26),('input','[C',18),('pos','I',2),('calls','I',2),('events','I',2)}
PROFILES=('javac8-debug','javac8-no-debug','javac23-debug','javac23-no-debug')
LEGS=('javac8','javac23'); VMS=('javac8','javac23')
CASE_NAMES=('hit-first','nonmatch-then-hit','nonzero-start-stop-restores','stop-precedes-equal-target','missing-stop-bounds-failure','maximum-char-hit')
ENV_STRIP=('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','CARGO_TARGET_DIR')

def sha_file(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
 return h.hexdigest()
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path)
 if spec is None or spec.loader is None: raise RuntimeError(f'cannot import {path}')
 mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def exact_pin(compare,rec,label):
 if not isinstance(rec,dict) or not {'path','bytes','sha256'}<=rec.keys(): raise RuntimeError(f'{label}: invalid pin')
 p=Path(rec['path']).resolve(strict=True)
 if compare.pin(p)!=rec: raise RuntimeError(f'{label}: pin mismatch {p}')
 return p
def norm(x):
 if isinstance(x,dict): return {k:norm(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)): return [norm(v) for v in x]
 return x
def tree(compare,root,suffix=None):
 return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*')) if p.is_file() and (suffix is None or p.suffix==suffix)}
def parse_rows(raw,manifest):
 pat=re.compile(r'^CASE index=(\d+) name=([^ ]+) lastChar=(\d+) result=(true|false|<none>) exception=([^ ]+) posBefore=(-?\d+) posAfter=(-?\d+) calls=(\d+) events=(-?\d+)$')
 rows=[]
 for i,line in enumerate(raw.decode('utf-8','strict').splitlines()):
  m=pat.fullmatch(line)
  if not m: raise ValueError(f'malformed case row: {line!r}')
  n=int(m.group(1))
  if n!=i or i>=len(manifest) or m.group(2)!=manifest[i]['name']: raise ValueError(f'case identity/order mismatch: {line!r}')
  rows.append({'index':n,'name':m.group(2),'lastChar':int(m.group(3)),'result':m.group(4),'exception':m.group(5),'posBefore':int(m.group(6)),'posAfter':int(m.group(7)),'calls':int(m.group(8)),'events':int(m.group(9)),'raw':line})
 if len(rows)!=len(CASE_NAMES) or tuple(r['name'] for r in rows)!=CASE_NAMES: raise ValueError('six-case controls inventory differs')
 return rows
def sem(rows):
 return [{k:r[k] for k in ('index','name','lastChar','result','exception','posBefore','posAfter','calls','events')} for r in rows]
def validate_source_map(text, source_map, label):
 if not isinstance(source_map,dict) or not isinstance(source_map.get('segments'),list): raise RuntimeError(f'{label}: missing segment map')
 raw=text.encode('utf-8')
 for seg in source_map['segments']:
  start,end=seg.get('start'),seg.get('end')
  if not isinstance(start,int) or not isinstance(end,int) or start<0 or start>=end or end>len(raw): raise RuntimeError(f'{label}: invalid UTF-8 byte coordinates')
  raw[:start].decode('utf-8','strict'); raw[:end].decode('utf-8','strict')
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--baseline',type=Path,required=True); ap.add_argument('--baseline-sha256',required=True)
 ap.add_argument('--cli',type=Path,required=True); ap.add_argument('--out',type=Path,required=True)
 ap.add_argument('--root',type=Path,default=ROOT); args=ap.parse_args()
 root=args.root.resolve(strict=True); bp=args.baseline.resolve(strict=True); cli=args.cli.resolve(strict=True); out=args.out.resolve()
 if root!=ROOT.resolve(): raise SystemExit('workspace path differs from pinned root')
 if not re.fullmatch('[0-9a-f]{64}',args.baseline_sha256) or sha_file(bp)!=args.baseline_sha256: raise SystemExit('baseline receipt SHA mismatch')
 if out.exists(): raise SystemExit(f'refusing existing output {out}')
 if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('workspace target must be absent')
 if shutil.disk_usage(root).free<5*1024**3: raise SystemExit('less than 5 GiB free')
 compare_path=root/COMPARE_REL; guard_path=root/GUARD_REL; scanner_path=root/SCANNER_REL; jdk_path=root/JDK_REL
 for p,h,label in ((compare_path,COMPARE_SHA,'compare'),(guard_path,GUARD_SHA,'guard'),(scanner_path,SCANNER_SHA,'scanner'),(jdk_path,JDK_SHA,'JDK manifest'),(PARSER,PARSER_SHA,'physical parser'),(BASE_HELPERS,BASE_HELPERS_SHA,'baseline helper')):
  if sha_file(p)!=h: raise SystemExit(f'{label} pin mismatch')
 compare=load(compare_path,'controls_generated_compare'); guard=load(guard_path,'controls_generated_guard'); scanner=load(scanner_path,'controls_generated_scanner'); physical=load(PARSER,'controls_generated_physical'); helpers=load(BASE_HELPERS,'controls_generated_helpers')
 jdks,jdk_doc=compare.configured_jdks(jdk_path,JDK_SHA)
 baseline=json.loads(bp.read_text(encoding='utf-8'))
 if baseline.get('schema')!=BASELINE_SCHEMA or baseline.get('status')!='captured-pending-independent-review': raise SystemExit('baseline is not a completed controls capture')
 if helpers.sha(bp)!=args.baseline_sha256: raise SystemExit('baseline helper SHA disagrees')
 baseline_cli=exact_pin(compare,baseline.get('candidate_cli'),'baseline CLI')
 if baseline_cli!=cli or baseline_cli.stat().st_size==0: raise SystemExit('provided CLI is not the baseline-pinned CLI')
 if baseline.get('source_unchanged') is not True or baseline.get('source_unchanged_finally') is not True or baseline.get('target_absent') is not True or baseline.get('target_absent_finally') is not True or baseline.get('external_inputs_unchanged') is not True or baseline.get('external_inputs_unchanged_finally') is not True or baseline.get('local_copies_unchanged') is not True: raise SystemExit('baseline closure/cleanup gates are false')
 if baseline['source_closure_before']!=baseline['source_closure_after'] or baseline['source_closure_before']!=baseline['source_closure_after_finally']: raise SystemExit('baseline source closure changed')
 if baseline['external_pins_before']!=baseline['external_pins_after'] or baseline['external_pins_before']!=baseline['external_pins_after_finally']: raise SystemExit('baseline external pins changed')
 for row in baseline['external_pins_before']: exact_pin(compare,row,'baseline external input')
 commands={r['index']:r for r in baseline.get('commands',[])}
 if len(commands)!=len(baseline.get('commands',[])): raise SystemExit('duplicate baseline command ids')
 for row in commands.values():
  if row.get('guard_stop') is not None: raise SystemExit(f'baseline guard stopped {row.get("label")}')
  for ch in ('stdout','stderr'): compare.command_artifact(row,ch)
 source_before=compare.source_closure(root)
 # Every original compiler/profile cell is reopened and fully parsed, including every method Code array.
 originals={}
 for cell in baseline.get('profile_cells',[]):
  key=cell.get('cell_key'); command=commands.get(cell.get('command'))
  if key not in PROFILES or command is None or command.get('label')!=f'compile-original-{key}' or command.get('exit_code')!=cell.get('exit_code'): raise SystemExit('original profile cell identity mismatch')
  if cell.get('exit_code')!=0: raise SystemExit(f'original control compile failed: {key}')
  class_root=Path(cell['class_root']).resolve(strict=True); target=class_root/(INTERNAL+'.class')
  if set(cell['class_tree'])!={INTERNAL+'.class'} or not target.is_file(): raise SystemExit(f'original class tree incomplete: {key}')
  if compare.pin(target)!=cell['class_tree'][INTERNAL+'.class']: raise SystemExit(f'original class pin mismatch: {key}')
  facts=helpers.full_class_facts(compare,physical,target,'original '+key)
  if norm(facts)!=norm(cell.get('class_facts')): raise SystemExit(f'original physical inventory/Code/BCIs differ from saved facts: {key}')
  if facts.get('class_name')!=INTERNAL or facts.get('major')!=52: raise SystemExit(f'original target binary identity/major differs: {key}')
  if {(m['name'],m['descriptor']) for m in facts['methods']}!=METHODS or {tuple(f) for f in facts['fields']}!=FIELDS: raise SystemExit(f'original method/field inventory differs: {key}')
  originals[key]={'cell':cell,'facts':facts,'root':class_root}
 if len(baseline.get('profile_cells',[]))!=4 or set(originals)!=set(PROFILES): raise SystemExit('original compile grid incomplete or duplicated')
 # Reconstruct all six-row oracles from raw driver streams, retaining compiler/runtime coordinates.
 manifest=json.loads((Path(__file__).parent/'controls.json').read_text(encoding='utf-8'))
 if manifest.get('schema')!='test-loop-condition-invoke-dynamic-controls-v2' or tuple(x['name'] for x in manifest.get('cases',[]))!=CASE_NAMES: raise SystemExit('frozen six-case manifest mismatch')
 driver_source=Path(__file__).parent/'LoopConditionInvokeControlDriver.java'
 if driver_source.stat().st_size!=manifest['driver']['bytes'] or sha_file(driver_source)!=manifest['driver']['sha256']: raise SystemExit('frozen driver source hash mismatch')
 oracles={}; oracle_stdout={}
 for row in baseline.get('runtime_cells',[]):
  key=row.get('cell_key'); vm=row.get('runtime'); command=commands.get(row.get('command'))
  if key not in originals or vm not in VMS or command is None or command.get('exit_code')!=0 or row.get('exit_code')!=0: raise SystemExit('original runtime cell invalid')
  if command.get('label')!=f'original-runtime-{key}-{vm}': raise SystemExit('original runtime command label mismatch')
  argv=command.get('argv',[]); driver_cp=Path(row['application_classpath'][0]).resolve()
  if '-cp' not in argv or Path(argv[argv.index('-cp')+1]).resolve()!=driver_cp or str(driver_cp)==str(Path(row['target_root']).resolve()): raise SystemExit('original runtime is not parentless driver-only classpath')
  if argv[-2:]!=[row['target_root'],row['target_root']]: raise SystemExit('original runtime target-root arguments mismatch')
  oracle_bytes=compare.command_artifact(command,'stdout'); parsed=parse_rows(oracle_bytes,manifest['cases'])
  if oracle_bytes!=manifest['expected_stdout'].encode('utf-8') or parsed!=row.get('rows') or row.get('matches_control_manifest') is not True: raise SystemExit(f'original oracle disagrees with raw/manifest: {key}/{vm}')
  oracles[(key,vm)]=sem(parsed); oracle_stdout[(key,vm)]=oracle_bytes
 if len(baseline.get('runtime_cells',[]))!=8 or set(oracles)!={(p,v) for p in PROFILES for v in VMS}: raise SystemExit('original runtime oracle grid incomplete or duplicated')
 wrong={(r.get('cell_key'),r.get('exit_code'),r.get('rejected')) for r in baseline.get('wrong_root_cells',[])}
 if len(baseline.get('wrong_root_cells',[]))!=4 or wrong!={(p,1,True) for p in PROFILES}: raise SystemExit('baseline wrong-CodeSource controls incomplete or duplicated')
 for row in baseline['wrong_root_cells']:
  command=commands.get(row.get('command')); expected_root=Path(row.get('expected_wrong_root','')).resolve(); target_root=Path(row.get('actual_target_root','')).resolve()
  if command is None or command.get('label')!=f"wrong-root-{row['cell_key']}" or command.get('exit_code')!=1: raise SystemExit('wrong-root command identity/exit mismatch')
  argv=command.get('argv',[]); driver_cp=Path(baseline['runtime_cells'][0]['application_classpath'][0]).resolve()
  original_root=originals[row['cell_key']]['root'].resolve()
  if target_root!=original_root or expected_root!=Path(baseline['output'],'empty-classpath').resolve(): raise SystemExit('wrong-root receipt roots do not bind to original class and empty root')
  if argv[-2:]!=[str(target_root),str(expected_root)] or '-cp' not in argv or Path(argv[argv.index('-cp')+1]).resolve()!=driver_cp: raise SystemExit('wrong-root argv roots/classpath mismatch')
  if compare.command_artifact(command,'stdout') or b'wrong CodeSource:' not in compare.command_artifact(command,'stderr'): raise SystemExit('wrong-root raw output does not prove rejection')
 api_cells=baseline.get('jarde_api_cells',[])
 if len(api_cells)!=8 or {(x.get('cell_key'),x.get('evidence')) for x in api_cells}!={(p,e) for p in PROFILES for e in ('default','all')}: raise SystemExit('baseline class-source API grid incomplete')
 # Preserve full reports, whole class text and raw method/map evidence, and require default/all identity.
 api_sources=[]; api_docs={}
 for cell in api_cells:
  command=commands.get(cell.get('command')); key=cell['cell_key']; evidence=cell['evidence']
  if command is None or command.get('exit_code')!=cell.get('exit_code') or cell.get('exit_code')!=0 or command.get('label')!=f'jarde-{key}-{evidence}': raise SystemExit(f'class-source command failed or misbound: {key}/{evidence}')
  input_pin=exact_pin(compare,cell['input'],'API target class input')
  original_input=originals[key]['root']/(INTERNAL+'.class')
  if input_pin.resolve()!=original_input.resolve() or compare.pin(input_pin)!=compare.pin(original_input): raise SystemExit(f'API input differs from original profile target: {key}')
  argv=command.get('argv',[])
  if not argv or Path(argv[0]).resolve()!=cli or '--input' not in argv or Path(argv[argv.index('--input')+1]).resolve()!=input_pin: raise SystemExit('API command argv not bound to pinned class/CLI')
  if evidence=='all' and ('--evidence' not in argv or argv[argv.index('--evidence')+1]!='all'): raise SystemExit('all-evidence API command selector mismatch')
  if evidence=='default' and '--evidence' in argv: raise SystemExit('default API command unexpectedly requested extra evidence')
  report=exact_pin(compare,cell['report'],'API report'); raw=compare.command_artifact(command,'stdout')
  if report.read_bytes()!=raw: raise SystemExit(f'API report differs from raw stdout: {key}/{evidence}')
  doc=json.loads(raw.decode('utf-8','strict')); api_docs[(cell['cell_key'],evidence)]=doc; whole=exact_pin(compare,cell['whole_class_text'],'whole class text')
  if whole.read_bytes()!=doc.get('text','').encode('utf-8'): raise SystemExit('whole class source artifact mismatch')
  if cell.get('method_inventory_matches') is not True or {(m['name'],m['descriptor']) for m in cell.get('methods',[])}!=METHODS: raise SystemExit('API method inventory differs from physical target')
  bymethod={(m['name'],m['descriptor']):m for m in cell['methods']}
  api_method_rows={(m.get('item',{}).get('name',{}).get('escaped'),m.get('item',{}).get('descriptor',{}).get('escaped')):m for m in doc.get('methods',[])}
  if len(doc.get('methods',[]))!=len(METHODS) or set(api_method_rows)!=METHODS: raise SystemExit('raw report method identities differ from physical target')
  for method in bymethod.values():
   if method.get('quality') not in ('structured','fallback') or method.get('outcome_kind')!='recovered' or not isinstance(method.get('source_map'),dict): raise SystemExit(f"API method lacks recovered body/map: {key}/{method.get('name')}")
   raw_method=api_method_rows[(method['name'],method['descriptor'])].get('outcome',{}).get('report',{})
   raw_outcome=api_method_rows[(method['name'],method['descriptor'])].get('outcome',{})
   if raw_outcome.get('kind')!=method.get('outcome_kind') or raw_method.get('quality')!=method.get('quality') or raw_method.get('fallbacks')!=method.get('fallbacks') or raw_method.get('diagnostics')!=method.get('diagnostics') or raw_method.get('text')!=method.get('raw_text') or raw_method.get('source_map')!=method.get('source_map'): raise SystemExit(f"API summary differs from raw method outcome: {key}/{method.get('name')}")
   if method.get('map_audit',{}).get('issues'): raise SystemExit(f"API map fails physical BCI audit: {key}/{method.get('name')}")
   physical_method=next(m for m in originals[key]['facts']['methods'] if m['name']==method['name'] and m['descriptor']==method['descriptor'])
   audit=helpers.audit_method_map(api_method_rows[(method['name'],method['descriptor'])],physical_method)
   if audit.get('issues') or norm(audit)!=norm(method['map_audit']): raise SystemExit(f"independent raw map audit differs: {key}/{method.get('name')}")
   validate_source_map(method.get('raw_text',''),method.get('source_map'),f"{key}/{method.get('name')}")
  api_sources.append({'kind':'jarde','key':key,'profile':key.split('-',1)[1],'evidence':evidence,'source_paths':[str(whole)],'source_pins':[cell['whole_class_text']],'report_pin':cell['report'],'method_outcomes':{f"{m['name']}{m['descriptor']}":{'outcome_kind':m['outcome_kind'],'quality':m['quality'],'fallbacks':m['fallbacks'],'diagnostics':m['diagnostics']} for m in bymethod.values()},'method_map_audits':{f"{m['name']}{m['descriptor']}":m['map_audit'] for m in bymethod.values()},'source_text':whole.read_bytes(),'api_doc':doc,'methods':bymethod,'original_facts':originals[key]['facts']})
 for key in PROFILES:
  dflt=next(x for x in api_sources if x['kind']=='jarde' and x['key']==key and x['evidence']=='default')
  allrow=next(x for x in api_sources if x['kind']=='jarde' and x['key']==key and x['evidence']=='all')
  if dflt['source_text']!=allrow['source_text'] or api_docs[(key,'default')].get('text')!=api_docs[(key,'all')].get('text'): raise SystemExit(f'default/all whole class text differs: {key}')
  for ident in METHODS:
   a=dflt['methods'][ident]; z=allrow['methods'][ident]
   if (a['outcome_kind'],a['quality'],a['fallbacks'],a['diagnostics'],a['raw_text'],a['source_map'])!=(z['outcome_kind'],z['quality'],z['fallbacks'],z['diagnostics'],z['raw_text'],z['source_map']): raise SystemExit(f'default/all method outcome/text/map differs: {key}/{ident}')
 # The complete two JADX emitted trees remain unchanged inputs; failed/missing trees abort before compilation.
 jadx_cells=baseline.get('jadx_outputs',[])
 if len(jadx_cells)!=2 or {x.get('profile') for x in jadx_cells}!={'debug','no-debug'}: raise SystemExit('JADX full-source profile grid incomplete')
 for cell in jadx_cells:
  command=commands.get(cell.get('command'))
  if command is None or command.get('label')!=f'jadx-full-class-{cell.get("profile")}' or command.get('exit_code')!=0 or cell.get('exit_code')!=0 or cell.get('source_tree_complete') is not True: raise SystemExit(f"JADX full source unavailable: {cell.get('profile')}")
  root_j=Path(cell['source_root']).resolve(strict=True); pins=cell['sources']
  argv=command.get('argv',[])
  if '-d' not in argv or Path(argv[argv.index('-d')+1]).resolve()!=root_j: raise SystemExit('JADX output root differs from argv')
  original_bundle=Path(originals['javac23-'+cell['profile']]['cell']['bundle']['path']).resolve(strict=True)
  if Path(argv[-1]).resolve()!=original_bundle: raise SystemExit('JADX input bundle differs from original profile bundle')
  actual=tree(compare,root_j,'.java'); expected={Path(x['path']).relative_to(root_j).as_posix():x for x in pins}
  if actual!=expected or not pins: raise SystemExit(f'JADX source tree differs from actual complete tree: {cell["profile"]}')
  for pin in pins:
   exact_pin(compare,pin,'JADX source')
   if Path(pin['path']).suffix!='.java': raise SystemExit('JADX output tree contains a non-Java source entry')
  target=next((Path(x['path']) for x in pins if Path(x['path']).name=='LoopConditionInvokeControl.java'),None)
  if target is None: raise SystemExit('JADX source tree has no target class')
  api_sources.append({'kind':'jadx','key':'jadx-'+cell['profile'],'profile':cell['profile'],'evidence':'full-tree','source_paths':[str(Path(x['path'])) for x in pins],'source_root':str(root_j),'source_pins':pins,'source_text':None,'target_source':str(target),'original_facts':originals['javac23-'+cell['profile']]['facts']})
 if compare.source_closure(root)!=source_before: raise SystemExit('repository source closure changed during preflight')
 # Check baseline command raw stream pins and collect every immutable source/tool input for the final guard.
 external=[bp,compare_path,guard_path,scanner_path,jdk_path,PARSER,BASE_HELPERS,cli,
           Path(baseline['runtime_wrapper']['path']),Path(baseline['jadx']['path']),Path(baseline['jadx_jar']['path']),
           Path(__file__).resolve(),Path(__file__).parent/'controls.json',Path(__file__).parent/'LoopConditionInvokeControlDriver.java',
           *[Path(t) for spec in jdks.values() for t in spec['tools'].values()],
           *[Path(pin['path']) for pin in baseline['external_pins_before']],
           *[Path(x['path']) for cmd in baseline['commands'] for x in cmd['streams'].values()],
           *[Path(x['path']) for cell in baseline['profile_cells'] for x in cell['class_tree'].values()],
           *[Path(cell['bundle']['path']) for cell in baseline['profile_cells'] if cell.get('bundle')],
           *[Path(x['path']) for cell in baseline['jadx_outputs'] for x in cell['sources']],
           *[Path(x['path']) for cell in api_cells for x in (cell['report'],cell['whole_class_text'])]]
 external=list(dict.fromkeys(external)); external_before=[compare.pin(p) for p in external]
 local_manifest=compare.pin(Path(__file__).parent/'controls.json'); local_driver=compare.pin(Path(__file__).parent/'LoopConditionInvokeControlDriver.java')
 if any(local_manifest.get(k)!=baseline.get('controls_manifest',{}).get(k) for k in ('bytes','sha256')): raise SystemExit('local control manifest bytes differ from baseline receipt')
 if any(local_driver.get(k)!=baseline.get('driver',{}).get(k) for k in ('bytes','sha256')): raise SystemExit('local driver bytes differ from baseline receipt')
 out.mkdir(parents=True); rawdir=out/'raw'; rawdir.mkdir(); empty=out/'empty-classpath'; empty.mkdir()
 driver_src=Path(__file__).parent/'LoopConditionInvokeControlDriver.java'; driver_copy=out/'driver/LoopConditionInvokeControlDriver.java'; driver_copy.parent.mkdir(); shutil.copyfile(driver_src,driver_copy)
 runtime_src=Path(baseline['runtime_wrapper']['path']).resolve(strict=True); runtime_copy=out/runtime_src.name; shutil.copyfile(runtime_src,runtime_copy)
 driver_classes=out/'driver-classes'; driver_classes.mkdir()
 report={'schema':'test-loop-condition-invoke-controls-generated-v1','status':'running','root':str(root),'output':str(out),
  'baseline_receipt':compare.pin(bp),'baseline_sha256_argument':args.baseline_sha256,'candidate_cli':compare.pin(cli),'source_pins_before':source_before,
  'external_pins_before':external_before,'jdk_manifest':jdk_doc,'compare':compare.pin(compare_path),'guard':compare.pin(guard_path),'scanner':compare.pin(scanner_path),'physical_parser':compare.pin(PARSER),'baseline_helpers':compare.pin(BASE_HELPERS),'runtime_wrapper':compare.pin(runtime_src),'driver_source':compare.pin(driver_src),'driver_copy':compare.pin(driver_copy),
  'commands':[],'driver_compile':None,'source_cells':[],'compilations':[],'runtime_rows':[],'wrong_root_rows':[],'original_oracles':{f'{k}/{v}':value for (k,v),value in oracles.items()},'original_oracle_stdout':{f'{k}/{v}':compare.pin(Path(next(c for c in baseline['commands'] if c['index']==r['command'])['streams']['stdout']['path'])) for r in baseline['runtime_cells'] for k,v in [(r['cell_key'],r['runtime'])]},
  'notes':['All available Jarde whole-class text and both complete JADX trees are compiled byte-for-byte as saved; no generated source is edited.','Compiler failures are retained as failures and receive no runtime rows.','A generated target receives runtime rows only after full class parsing and exact original-profile target method/field identity and access matching.','Each eligible generated target runs only with the independent driver directory on the application classpath; target is loaded from its exact root and wrong-root control uses an empty root.']}
 compare.write_json(out/'execution.json',report); commands=report['commands']
 guard.ROOT=root; guard.OUT=rawdir; guard.target_bytes=lambda:scanner.target_bytes(root); guard.command_stream=compare.pin; guard.expected_test_summaries=lambda index,data:None
 def command(argv,label,leg):
  if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError('workspace target appeared')
  env=compare.clean_env(dict(os.environ),jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK',None); env.pop('CARGO_TARGET_DIR',None)
  row=guard.run_command(len(commands)+1,[str(x) for x in argv],env); row['label']=label; row['tool_leg']=leg; commands.append(row); compare.write_json(out/'execution.json',report)
  if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
  return row
 def artifact(row,ch='stdout'): return compare.command_artifact(row,ch)
 generated={}; generated_sources={}
 copies_before=[compare.pin(driver_copy),compare.pin(runtime_copy)]
 try:
  driver_compile=command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',driver_classes,driver_copy],'compile-driver','javac8')
  report['driver_compile']={'command':driver_compile['index'],'exit_code':driver_compile['exit_code'],'stdout':compare.pin(Path(driver_compile['streams']['stdout']['path'])),'stderr':compare.pin(Path(driver_compile['streams']['stderr']['path']))}
  if driver_compile['exit_code']!=0: raise RuntimeError('independent driver compilation failed')
  driver_tree=tree(compare,driver_classes,'.class')
  expected_driver={'LoopConditionInvokeControlDriver$Case.class','LoopConditionInvokeControlDriver.class'}
  if set(driver_tree)!=expected_driver: raise RuntimeError(f'unexpected driver class tree: {sorted(driver_tree)}')
  report['driver_classes']=driver_tree; generated[str(driver_classes)]=driver_tree
  for source_cell in api_sources:
   cell_id=source_cell['key']+'-'+source_cell['evidence']
   cellrec={'kind':source_cell['kind'],'key':source_cell['key'],'profile':source_cell['profile'],'evidence':source_cell['evidence'],'source_pins':source_cell['source_pins'],'report_pin':source_cell.get('report_pin'),'method_outcomes':source_cell.get('method_outcomes'),'method_map_audits':source_cell.get('method_map_audits'),'source_copies':[],'source_available':True,'compilations':[]}
   report['source_cells'].append(cellrec)
   srcroot=out/'source-copies'/cell_id; srcroot.mkdir(parents=True)
   if source_cell['kind']=='jarde':
    src=Path(source_cell['source_paths'][0]); data=src.read_bytes(); dest=srcroot/'controls'/'LoopConditionInvokeControl.java'; dest.parent.mkdir(parents=True); dest.write_bytes(data)
    if dest.read_bytes()!=data: raise RuntimeError('Jarde source copy differs from complete API whole-class bytes')
    cellrec['source_copies']=[{'source':source_cell['source_pins'][0],'copy':compare.pin(dest)}]
    compile_root=srcroot
   else:
    for src_pin in source_cell['source_pins']:
     src=Path(src_pin['path'])
     # Full tree copy preserves every emitted Java file; relative paths are rooted at the saved JADX source root.
     source_root=Path(source_cell['source_root'])
     rel=src.relative_to(source_root); dest=srcroot/rel
     if dest.exists(): raise RuntimeError(f'duplicate source path in complete JADX tree: {rel}')
     dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(src.read_bytes())
     if dest.read_bytes()!=src.read_bytes(): raise RuntimeError('JADX source copy differs')
     cellrec['source_copies'].append({'source':src_pin,'copy':compare.pin(dest)}); generated_sources[str(dest)]=compare.pin(dest)
    compile_root=srcroot
   for leg in LEGS:
    dest=out/'compiled'/cell_id/leg/'classes'; dest.mkdir(parents=True)
    debug='-g' if source_cell['profile']=='debug' else '-g:none'
    files=sorted(compile_root.rglob('*.java'))
    if not files: raise RuntimeError(f'empty source cell {cell_id}')
    if leg=='javac8': argv=[jdks[leg]['tools']['javac'],'-source','8','-target','8',debug,'-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',dest,*files]
    else: argv=[jdks[leg]['tools']['javac'],'--release','8',debug,'-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',dest,*files]
    cr=command(argv,f'compile-{cell_id}-{leg}',leg); facts=None; fact_error=None; eligible=False
    generated_tree=tree(compare,dest,'.class')
    generated_all_facts={}
    if cr['exit_code']==0:
     try:
      for rel,pin in generated_tree.items():
       class_facts=helpers.full_class_facts(compare,physical,Path(pin['path']),'generated '+cell_id+' '+leg+' '+rel)
       if class_facts.get('major')!=52: raise RuntimeError(f'non-Java-8 classfile major: {rel}')
       generated_all_facts[rel]=class_facts
      if set(generated_tree)!={INTERNAL+'.class'}: raise RuntimeError(f'compiled class closure differs from original target closure: {sorted(generated_tree)}')
      facts=generated_all_facts[INTERNAL+'.class']
      expected=source_cell['original_facts']
      if facts.get('class_name')!=INTERNAL or facts.get('major')!=52: raise RuntimeError('target name/major mismatch')
      if {(m['name'],m['descriptor'],m['access']) for m in facts['methods']}!={(m['name'],m['descriptor'],m['access']) for m in expected['methods']}: raise RuntimeError('full target method identity/access differs from original')
      if {tuple(x) for x in facts['fields']}!={tuple(x) for x in expected['fields']}: raise RuntimeError('full target field identity/access differs from original')
      if not all(m.get('code') and m['code'].get('code_length',0)>0 and m['code'].get('bcis') for m in facts['methods']): raise RuntimeError('target physical Code/BCI inventory incomplete')
      eligible=True
     except Exception as exc: fact_error=repr(exc)
    rec={'compiler':leg,'command':cr['index'],'exit_code':cr['exit_code'],'class_root':str(dest),'class_tree':generated_tree,'stdout':compare.pin(Path(cr['streams']['stdout']['path'])),'stderr':compare.pin(Path(cr['streams']['stderr']['path'])),'class_facts':facts,'all_class_facts':generated_all_facts,'class_facts_error':fact_error,'runtime_eligible':eligible,'failure_classification':None if cr['exit_code']==0 else 'compiler-rejected-complete-source'}
    cellrec['compilations'].append(rec); report['compilations'].append({'cell_key':cell_id,**rec}); generated[str(dest)]=generated_tree; compare.write_json(out/'execution.json',report)
    if not eligible: continue
    target_root=dest.resolve()
    for vm in VMS:
     rr=command([sys.executable,'-B',runtime_copy,'30',jdks[vm]['tools']['java'],'-Xverify:all','-cp',driver_classes,DRIVER,target_root,target_root],f'runtime-{cell_id}-{leg}-{vm}',vm)
     rows=parse_rows(artifact(rr),manifest['cases']) if rr['exit_code']==0 else []
     oracle_key=source_cell['key'] if source_cell['kind']=='jarde' else 'javac23-'+source_cell['profile']
     matches=rr['exit_code']==0 and sem(rows)==oracles[(oracle_key,vm)] and artifact(rr)==oracle_stdout[(oracle_key,vm)]
     report['runtime_rows'].append({'cell_key':cell_id,'compiler':leg,'runtime':vm,'command':rr['index'],'exit_code':rr['exit_code'],'target_root':str(target_root),'application_classpath':[str(driver_classes)],'rows':rows,'matches_original_oracle':matches,'stdout':compare.pin(Path(rr['streams']['stdout']['path'])),'stderr':compare.pin(Path(rr['streams']['stderr']['path']))})
     compare.write_json(out/'execution.json',report)
    wr=command([sys.executable,'-B',runtime_copy,'30',jdks['javac23']['tools']['java'],'-Xverify:all','-cp',driver_classes,DRIVER,target_root,empty],f'wrong-root-{cell_id}-{leg}','javac23')
    err=artifact(wr,'stderr'); rejected=wr['exit_code']==1 and b'wrong CodeSource:' in err
    report['wrong_root_rows'].append({'cell_key':cell_id,'compiler':leg,'command':wr['index'],'exit_code':wr['exit_code'],'actual_target_root':str(target_root),'expected_wrong_root':str(empty),'rejected':rejected,'stdout':compare.pin(Path(wr['streams']['stdout']['path'])),'stderr':compare.pin(Path(wr['streams']['stderr']['path']))})
    compare.write_json(out/'execution.json',report)
  report['source_pins_after']=compare.source_closure(root); report['external_pins_after']=[compare.pin(p) for p in external]
  report['generated_outputs_unchanged']=all(tree(compare,Path(k),'.class')==v for k,v in generated.items()) and all(compare.pin(Path(k))==v for k,v in generated_sources.items())
  report['local_copies_after']=[compare.pin(driver_copy),compare.pin(runtime_copy)]; report['local_copies_unchanged']=report['local_copies_after']==copies_before
  report['source_unchanged']=report['source_pins_after']==source_before
  report['external_inputs_unchanged']=report['external_pins_after']==external_before
  report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
  if not all((report['generated_outputs_unchanged'],report['source_unchanged'],report['external_inputs_unchanged'],report['local_copies_unchanged'],report['target_absent'])): raise RuntimeError('source/tool/generated/target closure changed')
  report['counts_derived']={'source_cells':len(api_sources),'jarde_sources':sum(x['kind']=='jarde' for x in api_sources),'jadx_trees':sum(x['kind']=='jadx' for x in api_sources),'compile_attempts':len(report['compilations']),'compile_successes':sum(x['exit_code']==0 for x in report['compilations']),'runtime_attempts':len(report['runtime_rows']),'runtime_case_observations':sum(len(x['rows']) for x in report['runtime_rows']),'wrong_root_attempts':len(report['wrong_root_rows']),'commands':len(commands),'raw_streams':2*len(commands)}
  report['status']='captured-pending-independent-review'
 except BaseException as exc:
  report['status']='failed'; report['error']=repr(exc); raise
 finally:
  report['source_pins_after_finally']=compare.source_closure(root); report['external_pins_after_finally']=[compare.pin(p) for p in external]
  report['generated_outputs_unchanged_finally']=all(tree(compare,Path(k),'.class')==v for k,v in generated.items()) and all(compare.pin(Path(k))==v for k,v in generated_sources.items())
  if 'driver_copy' in locals() and 'runtime_copy' in locals(): report['local_copies_after_finally']=[compare.pin(driver_copy),compare.pin(runtime_copy)]; report['local_copies_unchanged_finally']=report['local_copies_after_finally']==copies_before if 'copies_before' in locals() else False
  report['source_unchanged_finally']=report['source_pins_after_finally']==source_before if 'source_before' in locals() else False
  report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
  report['external_inputs_unchanged_finally']=report['external_pins_after_finally']==external_before if 'external_before' in locals() else False
  if not report['source_unchanged_finally'] or not report['target_absent_finally'] or not report['external_inputs_unchanged_finally'] or not report.get('local_copies_unchanged_finally',False) or not report['generated_outputs_unchanged_finally']: report['status']='failed'; report['final_guard_error']='final closure changed'
  report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat(); compare.write_json(out/'execution.json',report)
  shutil.copy2(__file__,out/'collector.py')
  print(json.dumps({'status':report['status'],'commands':len(commands),'compile_attempts':len(report['compilations']),'runtime_attempts':len(report['runtime_rows']),'runtime_case_observations':sum(len(x['rows']) for x in report['runtime_rows']),'error':report.get('error')}))
 return 0
if __name__=='__main__': raise SystemExit(main())
