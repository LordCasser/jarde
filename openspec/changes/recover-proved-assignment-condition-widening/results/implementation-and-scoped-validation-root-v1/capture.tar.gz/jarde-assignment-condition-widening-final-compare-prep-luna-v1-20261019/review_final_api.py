#!/usr/bin/env python3
"""Independent read-only comparison of accepted and final TestLoopConditionInvoke captures."""
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path

OLD_PRIMARY = Path('/private/tmp/jarde-loop-condition-invoke-baseline-root-v1-20261019/execution.json')
OLD_PRIMARY_SHA = '7725015c3643581cb4c35d5f334c016f6f035540634e8c58183be3c7a177b3b4'
OLD_CONTROL = Path('/private/tmp/jarde-loop-condition-invoke-controls-baseline-root-v1-20261019/execution.json')
OLD_CONTROL_SHA = 'dc4d8322f24eb7a3f536c4da6d61a2c4f9e95aca92a1551d7a6a17e66eeeec0b'
OLD_PRIMARY_GENERATED = Path('/private/tmp/jarde-loop-condition-invoke-generated-root-v1-20261019/execution.json')
OLD_PRIMARY_GENERATED_SHA = 'b30c92057b7a366bfbd8e1bcbfb647a611efb7211c0f71068c014e730416b11d'
OLD_CONTROL_GENERATED = Path('/private/tmp/jarde-loop-condition-invoke-controls-generated-root-v2-20261019/execution.json')
OLD_CONTROL_GENERATED_SHA = '7c2c79812372902243dee48770109bdd7808fdf95d4ac167d3af6ae01f05fdce'
PRIMARY_METHODS = {('<init>', '()V'), ('next', '()C'), ('test', '(C)Z')}
CONTROL_METHODS = {('<init>', '([CI)V'), ('test', '(C)Z'), ('next', '()C'),
                   ('getPos', '()I'), ('getCalls', '()I'), ('getEvents', '()I')}


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def check_pin(row: dict, label: str) -> Path:
    if not isinstance(row, dict) or not {'path', 'bytes', 'sha256'} <= row.keys():
        raise RuntimeError(f'{label}: malformed pin')
    path = Path(row['path']).resolve(strict=True)
    if path.stat().st_size != row['bytes'] or sha(path) != row['sha256']:
        raise RuntimeError(f'{label}: pin differs from bytes on disk')
    return path


def read_receipt(path: Path, expected_sha: str | None, schema: str) -> tuple[dict, Path]:
    path = path.resolve(strict=True)
    if expected_sha and sha(path) != expected_sha:
        raise RuntimeError(f'{path}: receipt SHA differs from pinned accepted baseline')
    data = json.loads(path.read_text(encoding='utf-8'))
    if data.get('schema') != schema or data.get('status') != 'captured-pending-independent-review':
        raise RuntimeError(f'{path}: wrong schema or incomplete capture')
    return data, path


def method_rows(cell: dict, control: bool) -> dict:
    expected = CONTROL_METHODS if control else PRIMARY_METHODS
    rows = cell.get('methods')
    if not isinstance(rows, list):
        raise RuntimeError('method summary list missing')
    out = {(m.get('name'), m.get('descriptor')): m for m in rows}
    if len(out) != len(rows) or set(out) != expected:
        raise RuntimeError(f'physical method inventory mismatch: {sorted(out)}')
    if cell.get('method_inventory_matches') is not True:
        raise RuntimeError('recorded method inventory does not match physical class')
    return out


def raw_methods(report: dict) -> dict:
    out = {}
    for m in report.get('methods', []):
        item = m.get('item', {})
        key = (item.get('name', {}).get('escaped'), item.get('descriptor', {}).get('escaped'))
        outcome = m.get('outcome', {})
        body = outcome.get('report', {})
        if key in out or not isinstance(body.get('text'), str) or not isinstance(body.get('source_map'), dict):
            raise RuntimeError(f'malformed or duplicate raw method body {key}')
        out[key] = {'outcome_kind': outcome.get('kind'), 'quality': body.get('quality'),
                    'fallbacks': body.get('fallbacks'), 'diagnostics': body.get('diagnostics'),
                    'raw_text': body.get('text'), 'source_map': body.get('source_map')}
    return out


def stable_method(m: dict) -> tuple:
    return (m.get('outcome_kind'), m.get('quality'), m.get('fallbacks'), m.get('diagnostics'),
            m.get('raw_text'), m.get('source_map'))


def cell_key(cell: dict, control: bool) -> tuple:
    if control:
        return (cell.get('cell_key'), cell.get('evidence'))
    return (cell.get('profile'), cell.get('input_form'), cell.get('evidence'))


def audit_family(old: dict, new: dict, control: bool) -> dict:
    old_rows = old.get('jarde_api_cells' if control else 'jarde_cells', [])
    new_rows = new.get('jarde_api_cells' if control else 'jarde_cells', [])
    if len(old_rows) != 8 or len(new_rows) != 8:
        raise RuntimeError('expected exactly eight accepted and eight final API cells')
    old_map = {cell_key(c, control): c for c in old_rows}
    new_map = {cell_key(c, control): c for c in new_rows}
    if len(old_map) != 8 or len(new_map) != 8 or set(old_map) != set(new_map):
        raise RuntimeError('API selectors are incomplete, duplicated, or changed')
    summaries = []
    group_key = (lambda k: k[0]) if control else (lambda k: (k[0], k[1]))
    for selector in sorted(old_map):
        before, after = old_map[selector], new_map[selector]
        if before.get('exit_code') != 0 or after.get('exit_code') != 0:
            raise RuntimeError(f'API command failed for {selector}')
        before_input = check_pin(before['input'], f'old input {selector}')
        after_input = check_pin(after['input'], f'final input {selector}')
        if before_input.read_bytes() != after_input.read_bytes():
            raise RuntimeError(f'physical API input bytes changed for {selector}')
        inv_field = 'physical_method_inventory'
        if before.get(inv_field) != after.get(inv_field) or before.get('expected_physical_method_inventory') != after.get('expected_physical_method_inventory'):
            raise RuntimeError(f'physical method inventory changed for {selector}')
        old_report_path = check_pin(before['report'], f'old report {selector}')
        new_report_path = check_pin(after['report'], f'final report {selector}')
        old_raw = json.loads(old_report_path.read_text(encoding='utf-8'))
        new_raw = json.loads(new_report_path.read_text(encoding='utf-8'))
        if old_raw.get('text', '').encode('utf-8') != check_pin(before.get('whole_source', before.get('whole_class_text')), f'old whole source {selector}').read_bytes():
            raise RuntimeError(f'old whole source does not match raw report {selector}')
        if new_raw.get('text', '').encode('utf-8') != check_pin(after.get('whole_source', after.get('whole_class_text')), f'final whole source {selector}').read_bytes():
            raise RuntimeError(f'final whole source does not match raw report {selector}')
        old_doc_methods, new_doc_methods = raw_methods(old_raw), raw_methods(new_raw)
        old_sum, new_sum = method_rows(before, control), method_rows(after, control)
        for receipt, cell, report_path in ((old, before, old_report_path), (new, after, new_report_path)):
            commands = {row.get('index'): row for row in receipt.get('commands', [])}
            command = commands.get(cell.get('command'))
            if command is None or command.get('exit_code') != 0:
                raise RuntimeError(f'API command missing/failed for {selector}')
            stream = command.get('streams', {}).get('stdout', {})
            stream_path = check_pin(stream, f'API stdout {selector}')
            if stream_path.read_bytes() != report_path.read_bytes():
                raise RuntimeError(f'raw API report differs from command stdout for {selector}')
        if set(old_doc_methods) != set(old_sum) or set(new_doc_methods) != set(new_sum):
            raise RuntimeError(f'raw report method inventory differs from summary {selector}')
        for ident in old_sum:
            fields = ('outcome_kind', 'quality', 'fallbacks', 'raw_text', 'source_map')
            if control:
                fields += ('diagnostics',)
            for field in fields:
                if old_sum[ident].get(field) != old_doc_methods[ident].get(field):
                    raise RuntimeError(f'old raw method differs from summary {selector}/{ident}/{field}')
                if new_sum[ident].get(field) != new_doc_methods[ident].get(field):
                    raise RuntimeError(f'final raw method differs from summary {selector}/{ident}/{field}')
            audit = new_sum[ident].get('map_audit', {})
            if (not audit.get('map_present') or audit.get('issues')
                    or not audit.get('covers_all_physical_bcis')
                    or audit.get('unmapped_physical_bcis')):
                raise RuntimeError(f'final physical BCI/source-map audit failed {selector}/{ident}')
            if ident != ('test', '(C)Z') and stable_method(old_doc_methods[ident]) != stable_method(new_doc_methods[ident]):
                raise RuntimeError(f'non-target raw method changed {selector}/{ident}')
        old_test = old_doc_methods[('test', '(C)Z')]
        new_test = new_doc_methods[('test', '(C)Z')]
        if old_test.get('quality') != 'fallback' or new_test.get('quality') != 'structured':
            raise RuntimeError(f'target method did not transition fallback→structured in {selector}')
        if new_test.get('outcome_kind') != 'recovered' or not new_test.get('raw_text'):
            raise RuntimeError(f'final target method lacks recovered raw body in {selector}')
        summaries.append({'selector': selector, 'target_old_quality': old_test['quality'],
                          'target_final_quality': new_test['quality'], 'methods': len(new_sum)})

    # Evidence variants must preserve the full class/method representation for each input profile.
    grouped: dict[tuple, dict[str, dict]] = {}
    for key, cell in new_map.items():
        g = group_key(key)
        grouped.setdefault(g, {})[cell.get('evidence')] = cell
    for group, variants in grouped.items():
        if set(variants) != {'default', 'all'}:
            raise RuntimeError(f'default/all evidence pair missing for {group}')
        a, b = variants['default'], variants['all']
        ap = check_pin(a.get('whole_source', a.get('whole_class_text')), f'default source {group}')
        bp = check_pin(b.get('whole_source', b.get('whole_class_text')), f'all source {group}')
        if ap.read_bytes() != bp.read_bytes():
            raise RuntimeError(f'default/all whole class source differs for {group}')
        am = raw_methods(json.loads(check_pin(a.get('report'), f'default report {group}').read_text(encoding='utf-8')))
        bm = raw_methods(json.loads(check_pin(b.get('report'), f'all report {group}').read_text(encoding='utf-8')))
        if {k: stable_method(v) for k, v in am.items()} != {k: stable_method(v) for k, v in bm.items()}:
            raise RuntimeError(f'default/all raw method text/map/evidence differs for {group}')
    return {'cells': len(summaries), 'target_transitions': summaries}




def audit_originals(old: dict, new: dict, control: bool) -> dict:
    if control:
        old_classes = {r['cell_key']: r for r in old.get('profile_cells', [])}
        new_classes = {r['cell_key']: r for r in new.get('profile_cells', [])}
        if set(old_classes) != set(new_classes) or len(old_classes) != 4:
            raise RuntimeError('control compiler/profile class grid changed')
        for key in old_classes:
            def class_tree_bytes(row):
                tree = row.get('class_tree', {})
                return {name: (pin.get('bytes'), pin.get('sha256')) for name, pin in tree.items()}
            if class_tree_bytes(old_classes[key]) != class_tree_bytes(new_classes[key]):
                raise RuntimeError(f'control original class/outer bytes changed for {key}')
        old_runs, new_runs = old.get('runtime_cells', []), new.get('runtime_cells', [])
        selector = lambda r: (r.get('cell_key'), r.get('runtime'))
    else:
        old_classes = {r['profile']: r for r in old.get('source_profiles', [])}
        new_classes = {r['profile']: r for r in new.get('source_profiles', [])}
        if set(old_classes) != set(new_classes) or len(old_classes) != 2:
            raise RuntimeError('primary compiler/profile class grid changed')
        for key in old_classes:
            def class_tree_bytes(row):
                tree = row.get('class_tree', {})
                return {name: (pin.get('bytes'), pin.get('sha256')) for name, pin in tree.items()}
            if class_tree_bytes(old_classes[key]) != class_tree_bytes(new_classes[key]):
                raise RuntimeError(f'primary original class/outer bytes changed for {key}')
        old_runs, new_runs = old.get('original_runtime', []), new.get('original_runtime', [])
        selector = lambda r: (r.get('profile'), r.get('runtime'))
    old_map = {selector(r): r for r in old_runs}
    new_map = {selector(r): r for r in new_runs}
    expected_count = 8 if control else 4
    if len(old_map) != expected_count or len(new_map) != expected_count or set(old_map) != set(new_map):
        raise RuntimeError('original runtime oracle grid changed or duplicated')
    for key, before in old_map.items():
        after = new_map[key]
        if before.get('exit_code') != 0 or after.get('exit_code') != 0:
            raise RuntimeError(f'original parentless runtime failed for {key}')
        if control and (before.get('matches_control_manifest') is not True or after.get('matches_control_manifest') is not True):
            raise RuntimeError(f'control original runtime differs from frozen driver oracle for {key}')
        if before.get('rows') != after.get('rows'):
            raise RuntimeError(f'original runtime rows changed for {key}')
        if check_pin(before.get('stdout'), f'old oracle stdout {key}').read_bytes() != check_pin(after.get('stdout'), f'final oracle stdout {key}').read_bytes():
            raise RuntimeError(f'original parentless raw stdout changed for {key}')
    if not control:
        if new.get('runtime_semantic_agreement') is not True or new.get('wrong_root_control', {}).get('exit_code') != 1 or new.get('wrong_root_control', {}).get('rejected') is not True:
            raise RuntimeError('primary original oracle agreement or wrong-root control failed')
    else:
        wrong = new.get('wrong_root_cells', [])
        if len(wrong) != 4 or any(r.get('exit_code') != 1 or r.get('rejected') is not True for r in wrong):
            raise RuntimeError('control original wrong-CodeSource grid failed')
    return {'original_class_cells': len(old_classes), 'original_vm_cells': len(old_map)}

def check_generated(path: Path, schema: str, control: bool, baseline: Path, cli_sha: str) -> dict:
    data = json.loads(path.resolve(strict=True).read_text(encoding='utf-8'))
    if data.get('schema') != schema or data.get('status') != 'captured-pending-independent-review':
        raise RuntimeError(f'{path}: generated matrix is incomplete')
    recorded_baseline = check_pin(data.get('baseline_receipt'), f'{path}: baseline receipt')
    if recorded_baseline != baseline.resolve(strict=True):
        raise RuntimeError(f'{path}: generated matrix is not bound to its final API capture')
    if data.get('baseline_sha256_argument') != sha(recorded_baseline):
        raise RuntimeError(f'{path}: generated matrix baseline SHA argument mismatch')
    if control:
        if check_pin(data.get('candidate_cli'), f'{path}: candidate CLI').stat().st_size == 0 or data['candidate_cli'].get('sha256') != cli_sha:
            raise RuntimeError(f'{path}: generated controls CLI differs from final baseline')
    for flag in ('source_unchanged_finally', 'target_absent_finally', 'external_inputs_unchanged_finally'):
        if data.get(flag) is not True:
            raise RuntimeError(f'{path}: guard failed: {flag}')
    if data.get('local_copies_unchanged_finally') is not True:
        raise RuntimeError(f'{path}: local source/driver copies changed')
    cells = data.get('source_cells', [])
    if len(cells) != 10 or sum(c.get('kind') == 'jarde' for c in cells) != 8 or sum(c.get('kind') == 'jadx' for c in cells) != 2:
        raise RuntimeError(f'{path}: expected eight Jarde sources and two complete JADX trees')
    compiles = data.get('compilations', [])
    if len(compiles) != 20:
        raise RuntimeError(f'{path}: expected two compiler attempts for every full source cell')
    runtimes = data.get('runtime_rows', []) if control else data.get('runtime_rows', [])
    wrong = data.get('wrong_root_rows', [])
    match_field = 'matches_original_oracle' if control else 'matches_original_profile_runtime'
    for row in runtimes:
        if row.get('exit_code') != 0 or row.get(match_field) is not True:
            raise RuntimeError(f'{path}: generated target runtime did not match original oracle')
    for row in wrong:
        if row.get('exit_code') != 1 or row.get('rejected') is not True:
            raise RuntimeError(f'{path}: generated wrong-CodeSource check failed')
    return {'source_cells': len(cells), 'compile_attempts': len(compiles),
            'compile_successes': sum(c.get('exit_code') == 0 for c in compiles),
            'generated_vm_cells': len(runtimes), 'wrong_root_cells': len(wrong)}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--cli', type=Path, required=True)
    ap.add_argument('--expected-cli-sha256', required=True)
    ap.add_argument('--primary-final', type=Path, required=True)
    ap.add_argument('--controls-final', type=Path, required=True)
    ap.add_argument('--primary-generated-final', type=Path, required=True)
    ap.add_argument('--controls-generated-final', type=Path, required=True)
    args = ap.parse_args()
    if not re.fullmatch(r'[0-9a-f]{64}', args.expected_cli_sha256):
        raise SystemExit('expected CLI SHA must be 64 lowercase hex characters')
    cli = args.cli.resolve(strict=True)
    if sha(cli) != args.expected_cli_sha256:
        raise SystemExit('candidate CLI differs from caller-supplied SHA')
    old_primary, _ = read_receipt(OLD_PRIMARY, OLD_PRIMARY_SHA, 'test-loop-condition-invoke-full-source-baseline-v1')
    old_control, _ = read_receipt(OLD_CONTROL, OLD_CONTROL_SHA, 'test-loop-condition-invoke-controls-baseline-v1')
    for accepted in (OLD_PRIMARY_GENERATED, OLD_CONTROL_GENERATED):
        if not accepted.is_file(): raise SystemExit(f'missing accepted generated matrix {accepted}')
    if sha(OLD_PRIMARY_GENERATED) != OLD_PRIMARY_GENERATED_SHA or sha(OLD_CONTROL_GENERATED) != OLD_CONTROL_GENERATED_SHA:
        raise SystemExit('accepted generated matrix receipt changed')
    primary_path, control_path = args.primary_final.resolve(strict=True), args.controls_final.resolve(strict=True)
    primary = json.loads(primary_path.read_text(encoding='utf-8'))
    control = json.loads(control_path.read_text(encoding='utf-8'))
    if primary.get('schema') != 'test-loop-condition-invoke-full-source-baseline-v1' or control.get('schema') != 'test-loop-condition-invoke-controls-baseline-v1':
        raise SystemExit('final baseline schema mismatch')
    for data, receipt_path, control_flag in ((primary, primary_path, False), (control, control_path, True)):
        if data.get('status') != 'captured-pending-independent-review': raise SystemExit('final baseline is not complete')
        cli_pin = data.get('candidate_cli') if control_flag else data.get('cli')
        if check_pin(cli_pin, 'final CLI') != cli or cli_pin.get('sha256') != args.expected_cli_sha256:
            raise SystemExit('final baseline not bound to caller CLI path/SHA')
        if data.get('source_unchanged_finally') is not True or data.get('target_absent_finally') is not True or data.get('external_inputs_unchanged_finally') is not True:
            raise SystemExit(f'{receipt_path}: final baseline source/tool/target guard failed')
    if primary.get('runtime_semantic_agreement') is not True or primary.get('wrong_root_control', {}).get('rejected') is not True:
        raise SystemExit('final primary original-runtime or wrong-root oracle failed')
    po = audit_originals(old_primary, primary, False)
    co = audit_originals(old_control, control, True)
    p = audit_family(old_primary, primary, False)
    c = audit_family(old_control, control, True)
    pg = check_generated(args.primary_generated_final, 'test-loop-condition-invoke-generated-source-matrix-v1', False, primary_path, args.expected_cli_sha256)
    cg = check_generated(args.controls_generated_final, 'test-loop-condition-invoke-controls-generated-v1', True, control_path, args.expected_cli_sha256)
    print(json.dumps({'candidate_cli_sha256': args.expected_cli_sha256, 'primary_original': po,
                      'controls_original': co, 'primary_api': p, 'controls_api': c,
                      'primary_generated': pg, 'controls_generated': cg,
                      'note': 'This checker compares captured artifacts only; it does not rerun CLI, JVM, or compiler commands.'},
                     indent=2, sort_keys=True))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
