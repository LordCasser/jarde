# Final-candidate comparison preparation

This private package prepares the already-reviewed TestLoopConditionInvoke collectors against a CLI path and SHA supplied by root at execution time. It does not contain a candidate CLI pin or run collectors/toolchains.

`bind_final_collectors.py` validates the four accepted collector hashes and adjacent driver/source/manifest hashes before creating its output. It copies those files, then changes only each collector's expected CLI digest. For the controls-generated collector it rebinds `BASE_HELPERS` to the copied primary-baseline helper, which exports `full_class_facts`, and pins that exact modified helper. The CLI path/SHA are caller inputs. The copied collector syntax is parsed before the package is written.

After root supplies the built CLI and SHA, run `bind_final_collectors.py --cli PATH --expected-cli-sha256 HEX --out NEW_PRIVATE_DIR`. Root can then run the bound collectors in this order:

1. `primary_baseline/collect_baseline.py --cli PATH --out PRIMARY_BASELINE`
2. `primary_generated/collect_generated_matrix.py --baseline PRIMARY_BASELINE/execution.json --baseline-sha256 RECEIPT_SHA --cli PATH --out PRIMARY_GENERATED`
3. `controls_baseline/collect_controls_baseline.py --cli PATH --out CONTROLS_BASELINE`
4. `controls_generated/collect_controls_generated.py --baseline CONTROLS_BASELINE/execution.json --baseline-sha256 RECEIPT_SHA --cli PATH --out CONTROLS_GENERATED`

The primary API grid is eight cells (two original compiler profiles × child/bundle-child × default/all). The controls API grid is eight cells (four compiler/profile class roots × default/all). The generated stages consume each matching complete Jarde whole-class source and full JADX source tree; they do not splice, truncate, or repair source. They compile complete sources with both pinned Java compilers and run only successful, fully parsed target trees on both VMs, plus the wrong-CodeSource check. Actual failures remain captured as failures.

The accepted baseline collectors also re-open/compile original classes, run their bounded parentless drivers, and decode full JADX bundles. That repeats some previously accepted work, but it avoids synthesizing or rewriting receipt schemas. The resulting receipts independently record the class bytes, complete physical inventories, driver oracles, source/tool pins, and raw streams. Each run checks its own live source closure before/after; the historical closure remains a pinned input and is not required to equal the changed current tree.

Accepted references: primary baseline `7725015c…`, primary generated `b30c9205…`, controls baseline `dc4d8322…`, controls generated `7c2c7981…`. Accepted collector and resource hashes are in `pins.json` and embedded in the binder.

No CLI SHA is hardcoded here. Preparation only; no commands above have been executed. This is not product acceptance.

`review_final_api.py` is a read-only post-capture checker for the old accepted baseline receipts and the four new receipts. It requires the full eight-cell API selectors in each family, identical old/new physical input bytes and method inventories, raw report bytes bound to each command stdout, whole-source text bound to raw JSON, complete map audits, exact unchanged non-target method reports, and the intended target `test(C)Z` fallback-to-structured transition. It also checks default/all representations, final source/target guards, CLI binding, original oracle agreement, and that every recorded successful generated runtime matches its original oracle. This checker validates receipts only and never runs a compiler or VM.
