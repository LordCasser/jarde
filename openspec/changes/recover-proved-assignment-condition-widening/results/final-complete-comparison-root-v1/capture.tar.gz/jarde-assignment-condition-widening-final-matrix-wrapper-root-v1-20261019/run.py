import datetime,hashlib,json,subprocess,sys,time
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
HERE=Path(__file__).resolve().parent
BASE=Path('/private/tmp/jarde-assignment-condition-widening-final-collectors-root-v1-20261019')
CLI=Path('/private/tmp/jarde-assignment-condition-widening-public-root-v2-20261019/candidate-cli')
SHA='96e534b0000fe91c1d34a282919479a97eb4706063501d188cdff010c4640366'
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert pin(CLI)['sha256']==SHA and not (ROOT/'target').exists()
manifest=json.loads((BASE/'bound-manifest.json').read_text())
for p in manifest['bound_collectors'].values(): assert pin(p['path'])==p
outbase='/private/tmp/jarde-assignment-condition-widening-final-'
plan=[('primary-baseline','primary_baseline/collect_baseline.py',None),('primary-generated','primary_generated/collect_generated_matrix.py','primary-baseline'),('controls-baseline','controls_baseline/collect_controls_baseline.py',None),('controls-generated','controls_generated/collect_controls_generated.py','controls-baseline')]
r={'status':'running','runner':pin(__file__),'binding':pin(BASE/'bound-manifest.json'),'cli':pin(CLI),'commands':[]}
def save(): (HERE/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for name,rel,baseline in plan:
  out=Path(outbase+name+'-root-v1-20261019');assert not out.exists()
  argv=[sys.executable,'-B',str(BASE/rel),'--cli',str(CLI),'--out',str(out)]
  if baseline:
   b=Path(outbase+baseline+'-root-v1-20261019')/'execution.json';d=json.loads(b.read_text());assert d['status']=='captured-pending-independent-review'
   argv+=['--baseline',str(b),'--baseline-sha256',pin(b)['sha256']]
  row={'name':name,'argv':argv,'collector':pin(BASE/rel),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};t=time.monotonic()
  so=HERE/(name+'.stdout.raw');se=HERE/(name+'.stderr.raw')
  with so.open('xb') as a,se.open('xb') as b: row['exit_code']=subprocess.run(argv,cwd=ROOT,stdout=a,stderr=b).returncode
  row.update(stdout=pin(so),stderr=pin(se),duration_seconds=time.monotonic()-t)
  receipt=out/'execution.json'
  if receipt.exists(): row['receipt']=pin(receipt);row['capture_status']=json.loads(receipt.read_text()).get('status')
  r['commands'].append(row);save();print(name,row['exit_code'],row.get('capture_status'),flush=True)
  assert row['exit_code']==0 and row.get('capture_status')=='captured-pending-independent-review'
  assert not (ROOT/'target').exists() and pin(CLI)['sha256']==SHA
 r['status']='captured_pending_independent_acceptance'
except BaseException as e: r.update(status='failed',error=repr(e))
finally:
 r['target_absent']=not (ROOT/'target').exists();r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(r['status'],flush=True)
sys.exit(0 if r['status']=='captured_pending_independent_acceptance' else 1)
