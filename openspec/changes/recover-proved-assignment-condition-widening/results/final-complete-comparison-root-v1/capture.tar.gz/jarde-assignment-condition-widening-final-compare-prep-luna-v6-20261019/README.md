# Final CLI comparison preparation, v2

This private bundle retains the v1 binder and the four accepted collector pins. The binder remains byte-identical to v1. The v2 reviewer hardens generated-source acceptance; it does not run the CLI, Java compilers, or JVMs. Root must supply the final CLI SHA and four fresh receipts when the complete run is available.

`review_final_api.py` keeps v1's baseline/API/source-map checks, then requires a complete generated grid. Each family has eight Jarde whole-class source cells and two JADX full-source profiles, with both pinned compiler legs represented exactly once per source cell. Every one of the 16 Jarde compiles must exit 0, be runtime-eligible, contain full parser facts without errors, and match the corresponding original class's full method/field identity and access inventory. Each such compiler target must have exactly two VM rows and one distinct-root CodeSource rejection. This yields 32 Jarde VM cells and exactly 128 primary or 192 controls case observations. Duplicate, missing, or unexpected selectors fail.

The reviewer reopens and byte-compares each copied source against its source pin, binds Jarde copies to the corresponding whole-class API source, checks complete JADX source inventories against their accepted baseline trees, and reopens every generated class, parser fact, tool, CLI, command stdout/stderr, source-closure pin, and local driver/runtime copy. It verifies command indices, argv/leg identity, 5 GiB free-space and 1 GiB target guards, raw-row linkage, per-command exits, source closure before/after/finally, output pins, and final target absence. Historical baseline source closure is not compared with the current tree; each fresh receipt must be stable within its own run.

The only permitted primary JADX failure is the already observed `javac8` full-bundle major-55 boundary for both profiles, with its recorded exact classification and raw stderr naming version 55. It receives no runtime row. The two `javac23` JADX cells must complete the full two-VM and wrong-root grid. The controls JADX cells must all complete their full grid. All other compile failures fail the final reviewer; they are never counted as runtime successes.

A Python-only schema self-check used the frozen old generated receipts after normalizing their historical source-closure snapshots in memory to current file pins. Both were rejected at their actual failed Jarde compile cells, confirming the v2 reviewer cannot pass the earlier zero-Jarde-runtime receipts. No receipt was edited and no toolchain ran. This is a checker-preparation result, not product acceptance.

Run the same CLI and receipt arguments documented in v1 only after the new captures are complete. The reviewer is read-only. `pins.json` records bundle hashes and the unchanged accepted receipt/collector references. `reviewer-v1-to-v2.diff` is the narrow reviewer delta.

## v3 schema correction

The controls generated collector identifies JADX cells as `jadx-{profile}`, while the accepted original physical profile inventory is stored at `javac23-{profile}`. The v2 reviewer indexed those facts by the generated cell key and would reject valid controls JADX output. V3 maps only this known producer key to the original javac23 profile facts; it keeps full method/field/access/Code/BCI comparisons. A Python-only check against the frozen successful primary and controls JADX captures confirmed their class-fact inventories and compile argv match the reviewer’s expected fields. The frozen old matrix receipts still contain failed Jarde builds, so they are not acceptance evidence for the newly required Jarde success matrix.

The v3 reviewer also validates the copied reflection-driver source and its two exact driver class outputs against the compile command, and requires the primary JDK 8 boundary stderr to explicitly identify major 55 (not merely say a version is wrong).

## v4 generated-source closure correction

The primary API artifacts for both `child` and `bundle-child` are the same standalone target nested-class source. The original profile's bundle includes a separate outer class, but the API did not emit that outer source. V4 therefore requires exactly the target class for primary Jarde whole-source compiles, and still requires the full original outer-plus-child class tree for primary JADX full-tree compiles. The control Jarde source also remains constrained to its one target class. This preserves complete physical inventory checks per actual compiler input.

## v5 successful-primary receipt fix

The v4 primary Jarde closure check referenced `INTERNAL` without defining it. V5 defines the exact internal class name from the accepted fixture; no grid, inventory, or success criteria changed. The successful primary generated receipt was checked with `check_generated` using only Python; no collector or toolchain was run.

## v6 runtime wrapper pin schema correction

The successful primary receipt stores the runtime wrapper in `local_copies_before`, not `external_pins_before`. V6 accepts a wrapper only when its path appears in either already-pinned snapshot; those snapshots are independently reopened and required stable. This applies to runtime and wrong-root wrapper checks. No runtime, case, command, or compile criteria changed.
