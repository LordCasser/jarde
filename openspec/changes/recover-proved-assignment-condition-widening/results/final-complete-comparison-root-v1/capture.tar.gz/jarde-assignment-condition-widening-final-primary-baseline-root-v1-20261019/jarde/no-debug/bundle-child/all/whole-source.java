// jarde: presentation of `jadx/tests/integration/loops/TestLoopConditionInvoke$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestLoopConditionInvoke$TestCls extends java.lang.Object {
    private static final char STOP_CHAR = '\u0000';

    private int pos;

    public TestLoopConditionInvoke$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestLoopConditionInvoke$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public boolean test(char arg1) {
        // @method test(C)Z
        // @declaration an instance method of `jadx.tests.integration.loops.TestLoopConditionInvoke$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int local2;
        local2 = this.pos;
        int local3;
        while ((local3 = this.next()) != 0) {
            if (local3 == arg1) {
                return true;
            }
        }
        this.pos = local2;
        return false;
    }

    private char next() {
        // @method next()C
        // @declaration an instance method of `jadx.tests.integration.loops.TestLoopConditionInvoke$TestCls`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        return '\u0000';
    }
}
