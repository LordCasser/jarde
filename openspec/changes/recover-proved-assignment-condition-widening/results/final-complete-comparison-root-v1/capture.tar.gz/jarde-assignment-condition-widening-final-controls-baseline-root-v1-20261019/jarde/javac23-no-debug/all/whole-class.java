// jarde: presentation of `controls/LoopConditionInvokeControl` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package controls;

public final class LoopConditionInvokeControl extends java.lang.Object {
    private static final char STOP_CHAR = '\u0000';

    private final char[] input;

    private int pos;

    private int calls;

    private int events;

    public LoopConditionInvokeControl(char[] arg1, int arg2) {
        // @method <init>([CI)V
        // @declaration a constructor of `controls.LoopConditionInvokeControl`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.input = arg1;
        this.pos = arg2;
        return;
    }

    public boolean test(char arg1) {
        // @method test(C)Z
        // @declaration an instance method of `controls.LoopConditionInvokeControl`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int local2;
        local2 = this.pos;
        int local3;
        while ((local3 = this.next()) != 0) {
            if (local3 == arg1) {
                return true;
            }
        }
        this.pos = local2;
        return false;
    }

    private char next() {
        // @method next()C
        // @declaration an instance method of `controls.LoopConditionInvokeControl`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.calls += 1;
        int local1 = this.pos++;
        this.events = this.events * 10 + local1 + 1;
        return this.input[local1];
    }

    public int getPos() {
        // @method getPos()I
        // @declaration an instance method of `controls.LoopConditionInvokeControl`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        return this.pos;
    }

    public int getCalls() {
        // @method getCalls()I
        // @declaration an instance method of `controls.LoopConditionInvokeControl`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        return this.calls;
    }

    public int getEvents() {
        // @method getEvents()I
        // @declaration an instance method of `controls.LoopConditionInvokeControl`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        return this.events;
    }
}
