def parse_workspace_group(group: str, seed: str):
    lines = [clean_line(line) for line in group.splitlines()]
    env = [re.fullmatch(r'PROPTEST_RNG_SEED:\s*["\']?(\d+)["\']?', line) for line in lines if 'PROPTEST_RNG_SEED:' in line]
    need(len(env) == 1 and env[0] is not None and env[0].group(1) == seed, f'workspace log seed differs from workflow: {seed}')
    headers = [line for line in lines if line.startswith('Running ')]
    outcomes, rows = [], []
    i = 0
    while i < len(lines):
        m = RUNNING.fullmatch(lines[i])
        if not m:
            if lines[i].startswith('test result:'):
                raise ValueError(f'test summary without running block: {lines[i]}')
            i += 1
            continue
        declared, named = int(m.group(1)), []
        j = i + 1
        while j < len(lines):
            summary = SUMMARY.fullmatch(lines[j])
            if summary:
                counts = tuple(int(summary.group(n)) for n in range(2, 5))
                measured, filtered = int(summary.group(5)), int(summary.group(6))
                need((summary.group(1) == 'ok') == (counts[1] == 0), f'summary status/count mismatch: {lines[j]}')
                need(declared == len(named), f'running count differs from named outcomes: {declared} != {len(named)}')
                seen = (sum(state == 'ok' for _, state in named), sum(state == 'FAILED' for _, state in named), sum(state == 'ignored' for _, state in named))
                need(seen == counts, f'named test results do not reconstruct summary: {seen} != {counts}')
                need(counts[1] == 0 and filtered == 0, f'target failed or filtered tests: {lines[j]}')
                rows.append({'named_tests': declared, 'passed': counts[0], 'failed': counts[1], 'ignored': counts[2],
                             'measured': measured, 'filtered': filtered, '_named': named})
                i = j + 1
                break
            result = OUTCOME.fullmatch(lines[j])
            if result:
                raw_state = result.group(2)
                named.append((result.group(1), 'ignored' if raw_state.startswith('ignored') else raw_state))
            elif lines[j].startswith('test result:') or lines[j].startswith('test '):
                raise ValueError(f'unparsed cargo test output: {lines[j]}')
            j += 1
        else:
            raise ValueError(f'running block has no complete summary: {lines[i]}')
    need(rows and len(headers) == len(rows), 'workspace target headers and summaries are incomplete')
    named_by_header = {}
    for row, header in zip(rows, headers):
        match = RUN_TARGET.fullmatch(header)
        need(match is not None, f'unparsed Cargo Running header: {header!r}')
        executable = match.group('path').rsplit('/', 1)[-1]
        executable_match = HASHED_EXE.fullmatch(executable)
        need(executable_match is not None, f'unrecognized Cargo executable: {executable!r}')
        row['target_header'], row['target_executable'] = header, executable
        row['target_name'] = executable_match.group('target')
        named_by_header[header] = sorted(row['_named'])
        outcomes.extend((name, state, row['target_name']) for name, state in row.pop('_named'))
    need(sum(row['named_tests'] for row in rows) == len(outcomes), 'not every observed test result is accounted for')
    inventory = [row['target_header'] for row in rows]
    need(len(inventory) == len(set(inventory)), 'duplicate cargo target header')
    checks = {}
    for label, (name, target) in CRITICAL_TESTS.items():
        matches = [(state, target_name) for seen, state, target_name in outcomes
                   if seen == name and target_name == target]
        need(len(matches) == 1 and matches[0][0] == 'ok', f'critical test missing/duplicated/failing under exact target: {label}')
        checks[label] = name
    totals = {key: sum(row[key] for row in rows) for key in ('passed', 'failed', 'ignored', 'measured', 'filtered')}
    need(totals['failed'] == 0 and totals['filtered'] == 0, 'workspace run has failed or filtered tests')
    return {'all_named_by_header': named_by_header, 'seed': seed, 'target_count': len(rows), 'target_inventory': inventory,
            'target_summaries': rows, 'named_test_outcomes': len(outcomes),
            'workspace_totals': totals, 'critical_tests_passed': checks}
