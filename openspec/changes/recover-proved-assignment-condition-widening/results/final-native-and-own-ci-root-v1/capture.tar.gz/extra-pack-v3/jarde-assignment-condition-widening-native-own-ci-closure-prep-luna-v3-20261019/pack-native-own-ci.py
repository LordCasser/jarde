#!/usr/bin/env python3
"""Pack accepted native and own-CI closure evidence, then reopen and verify every tar member."""
from __future__ import annotations
import argparse, hashlib, io, json, tarfile, zipfile
from pathlib import Path

PRIVATE = Path('/private/tmp').resolve()
EXCLUDED_COMPONENTS = {'candidate-cli', 'target', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache', '.cache', 'node_modules'}
EXPECTED_NATIVE = {'targets': 386, 'batches': 101, 'source_pins': 5166, 'gates': 34}
EXPECTED_CI_GATES = 79
REQUIRED_CI_FILES = ('collection.json', 'run.json', 'jobs-api.json', 'source-pins.json', 'workflow.sha256', 'run-logs.zip', 'step-log-supplement.json')
ASSIGNMENT_GATES = {
 ('jarde_java', 'build::tests::proved_loop_assignment_consumes_real_char_and_only_known_widenings'),
 ('p3_assignment_condition_widening', 'fixed_upstream_and_dynamic_controls_recover_the_widened_loop_condition'),
 ('p3_assignment_condition_widening', 'cancellation_does_not_publish_a_partial_condition_body'),
}

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def need(ok: bool, message: str) -> None:
    if not ok: raise RuntimeError(message)

def read_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))

def checked_file(path: Path) -> Path:
    path=Path(path)
    need(not path.is_symlink(), f'refusing symlink file: {path}')
    path=path.resolve(strict=True)
    need(path.is_file(), f'expected regular file: {path}')
    return path

def checked_dir(path: Path) -> Path:
    path=Path(path)
    need(not path.is_symlink(), f'refusing symlink directory: {path}')
    path=path.resolve(strict=True)
    need(path.is_dir(), f'expected regular directory: {path}')
    return path

def require_under_private(path: Path, label: str) -> None:
    need(path.is_relative_to(PRIVATE), f'{label} must be under /private/tmp: {path}')

def validate_native(execution_dir: Path, acceptance_dir: Path):
    execution_file=checked_file(execution_dir/'execution.json')
    review_file=checked_file(acceptance_dir/'review.json')
    binding_file=checked_file(acceptance_dir/'product-binding.json')
    run=read_json(execution_file); review=read_json(review_file); binding=read_json(binding_file)
    need(run.get('status')=='passed' and run.get('target_absent_after_clean') is True and run.get('pins_unchanged') is True,
         'native workspace receipt is not completed and clean')
    need(run.get('expected_batch_count')==EXPECTED_NATIVE['batches'] and len(run.get('batch_plan',[]))==EXPECTED_NATIVE['batches']
         and len(run.get('commands',[]))==EXPECTED_NATIVE['batches'] and run.get('workspace_summary_count')==EXPECTED_NATIVE['targets'],
         'native receipt does not contain the complete 101-batch matrix')
    need(len(run.get('target_inventory',[]))==EXPECTED_NATIVE['targets'] and len(run.get('source_pins',{}))==EXPECTED_NATIVE['source_pins'],
         'native target/source-pin inventory differs from accepted matrix')
    for row in run['commands']:
        need(row.get('exit_code')==0 and row.get('guard_stop') is None and len(row.get('streams',{}))==2,
             f'native batch failed or lacks two raw streams: {row.get("index")}')
        for stream in row['streams'].values():
            f=checked_file(Path(stream['path']))
            need(f.is_relative_to(execution_dir), f'native raw stream escapes execution directory: {f}')
            data=f.read_bytes()
            need(len(data)==stream.get('bytes') and sha(data)==stream.get('sha256'), f'native raw stream pin mismatch: {f}')
    need(review.get('status')=='passed' and review.get('batch_count')==EXPECTED_NATIVE['batches']
         and review.get('target_count')==EXPECTED_NATIVE['targets'] and review.get('source_pin_count')==EXPECTED_NATIVE['source_pins']
         and review.get('critical_gate_count')==EXPECTED_NATIVE['gates'], 'native acceptance review counts/status mismatch')
    need(review.get('native_receipt',{}).get('path')==str(execution_file)
         and review['native_receipt'].get('sha256')==sha(execution_file.read_bytes()), 'native acceptance does not bind exact execution receipt')
    gate_rows=review.get('current_exact_gates',[])
    gates={(row.get('target'),row.get('test')) for row in gate_rows}
    need(ASSIGNMENT_GATES <= gates, 'native review omits one or more assignment-condition gates')
    need(binding.get('status')=='accepted_single_native_and_build_bound_to_product', 'native product binding is not accepted')
    need(binding.get('native',{}).get('path')==str(execution_file)
         and binding['native'].get('sha256')==sha(execution_file.read_bytes()), 'product binding does not bind the selected native receipt')
    need(binding.get('acceptance',{}).get('path')==str(review_file)
         and binding['acceptance'].get('sha256')==sha(review_file.read_bytes()), 'product binding does not bind the selected native review')
    return {'execution':execution_file,'review':review_file,'binding':binding_file,'receipt':run,'review_doc':review,'binding_doc':binding}

def validate_ci(collection_dir: Path, acceptance_dir: Path, product_sha: str, cli_sha: str):
    collection_file=checked_file(collection_dir/'collection.json')
    review_file=checked_file(acceptance_dir/'review.json')
    collection=read_json(collection_file); review=read_json(review_file)
    need(collection.get('status')=='raw collection complete; independent acceptance pending', 'own-CI collection is not complete')
    need(collection.get('product_sha')==product_sha, 'own-CI collection product differs from native product binding')
    for rel in REQUIRED_CI_FILES:
        checked_file(collection_dir/rel)
    zip_path=checked_file(collection_dir/'run-logs.zip')
    need(zipfile.is_zipfile(zip_path), 'official GitHub run-log ZIP is missing or invalid')
    with zipfile.ZipFile(zip_path) as zf:
        bad=zf.testzip()
        need(bad is None, f'official run-log ZIP fails CRC: {bad}')
    need(review.get('status')=='accepted' and review.get('critical_gate_count')==EXPECTED_CI_GATES,
         'own-CI verifier receipt is not accepted with all 79 exact gates')
    product=review.get('product',{})
    need(product.get('expected_sha')==product_sha and product.get('head_sha')==product_sha,
         'own-CI acceptance is not bound to the native product SHA')
    need(product.get('cli_sha256')==cli_sha, 'own-CI CLI pin differs from native product binding')
    need(review.get('collection',{}).get('run_id')==collection.get('run_id'), 'own-CI verifier refers to a different CI run')
    need(review.get('collection',{}).get('source_file_count')==collection.get('source_file_count')
         and review.get('collection',{}).get('fixture_file_count')==collection.get('fixture_file_count'),
         'own-CI verifier and collection source inventories differ')
    seed_runs=review.get('workspace_seed_runs',[])
    need(len(seed_runs)==2 and all(len(row.get('critical_tests_passed',{}))==EXPECTED_CI_GATES for row in seed_runs),
         'own-CI receipts do not show all 79 exact gates in both workspace seeds')
    return {'collection_file':collection_file,'review_file':review_file,'collection':collection,'review':review}

def list_regular_files(root: Path):
    found=[]
    for path in root.rglob('*'):
        if any(part in EXCLUDED_COMPONENTS for part in path.parts): continue
        if path.is_symlink(): raise RuntimeError(f'refusing symlink in evidence input: {path}')
        if path.is_file(): found.append(path.resolve())
    return sorted(found)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--native-execution-dir',type=Path,required=True)
    ap.add_argument('--native-acceptance-dir',type=Path,required=True)
    ap.add_argument('--ci-collection-dir',type=Path,required=True)
    ap.add_argument('--ci-acceptance-dir',type=Path,required=True)
    ap.add_argument('--tooling-dir',type=Path,required=True,help='accepted own-CI/native acceptance scripts and gate inventory')
    ap.add_argument('--extra-dir',action='append',default=[],metavar='LABEL=PATH',help='additional explicit tooling directory; repeat, labels must be unique')
    ap.add_argument('--results-readme',type=Path,required=True,help='final updated OpenSpec results README')
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args()
    native_exec=checked_dir(args.native_execution_dir); native_accept=checked_dir(args.native_acceptance_dir)
    ci_collection=checked_dir(args.ci_collection_dir); ci_accept=checked_dir(args.ci_acceptance_dir)
    tooling=checked_dir(args.tooling_dir); readme=checked_file(args.results_readme)
    extras=[]; extra_labels=set()
    for spec in args.extra_dir:
        label,sep,raw_path=spec.partition('=')
        need(bool(sep and label and raw_path and label not in extra_labels), f'invalid/duplicate --extra-dir: {spec}')
        need(label.replace('_','').replace('-','').isalnum(), f'unsafe --extra-dir label: {label}')
        path=checked_dir(Path(raw_path))
        require_under_private(path,f'extra directory {label}')
        need(path not in [row[1] for row in extras], f'duplicate --extra-dir path: {path}')
        extra_labels.add(label); extras.append((label,path))
    for label,path in [('native execution',native_exec),('native acceptance',native_accept),('CI collection',ci_collection),('CI acceptance',ci_accept),('tooling',tooling),*((f'extra directory {label}',path) for label,path in extras)]:
        require_under_private(path,label)
    binding=read_json(checked_file(native_accept/'product-binding.json'))
    native=validate_native(native_exec,native_accept)
    product_sha=binding.get('product_revision'); cli_sha=binding.get('cli',{}).get('sha256')
    need(isinstance(product_sha,str) and len(product_sha)==40, 'accepted native binding lacks product SHA')
    need(isinstance(cli_sha,str) and len(cli_sha)==64, 'accepted native binding lacks CLI SHA256')
    ci=validate_ci(ci_collection,ci_accept,product_sha,cli_sha)
    out=args.out.resolve(); inventory_path=out.with_suffix(out.suffix+'.inventory.json')
    if out.exists() or inventory_path.exists(): raise FileExistsError('refusing to overwrite archive or inventory')
    input_roots=(native_exec,native_accept,ci_collection,ci_accept,tooling,*(path for _,path in extras))
    if any(out.is_relative_to(root) or inventory_path.is_relative_to(root) for root in input_roots):
        raise RuntimeError('archive and inventory outputs must be outside all evidence/tooling inputs')
    input_groups=[('native-execution',native_exec),('native-acceptance',native_accept),('ci-collection',ci_collection),('ci-acceptance',ci_accept),('tooling',tooling)]+[(f'extra-{label}',path) for label,path in extras]
    sources=[]
    for label,root in input_groups:
        for path in list_regular_files(root):
            sources.append((f'{label}/{root.name}/{path.relative_to(root).as_posix()}',path))
    sources.append((f'results/{readme.name}',readme))
    arc_names=[name for name,_ in sources]
    if len(arc_names)!=len(set(arc_names)): raise RuntimeError('duplicate archive member names')
    rows=[]
    for name,path in sources:
        data=path.read_bytes(); rows.append({'path':name,'bytes':len(data),'sha256':sha(data)})
    manifest={'schema':'jarde-assignment-condition-native-own-ci-closure-v1','status':'accepted_native_and_own_ci',
              'product_sha':product_sha,'cli_sha256':cli_sha,'native':{'target_count':EXPECTED_NATIVE['targets'],'batch_count':EXPECTED_NATIVE['batches'],'source_pin_count':EXPECTED_NATIVE['source_pins'],'critical_gate_count':EXPECTED_NATIVE['gates']},
              'own_ci':{'run_id':ci['collection'].get('run_id'),'critical_gate_count':EXPECTED_CI_GATES,'official_zip':'run-logs.zip'},
              'member_count':len(rows),'members':rows,'excluded_components':sorted(EXCLUDED_COMPONENTS)}
    out.parent.mkdir(parents=True,exist_ok=True)
    with tarfile.open(out,'x:gz') as tar:
        for (name,path),row in zip(sources,rows):
            info=tar.gettarinfo(str(path),arcname=name)
            with path.open('rb') as f: tar.addfile(info,f)
        blob=(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
        info=tarfile.TarInfo('ARCHIVE_INVENTORY.json');info.size=len(blob);info.mode=0o644
        tar.addfile(info,io.BytesIO(blob))
    with tarfile.open(out,'r:gz') as tar:
        members={m.name:m for m in tar.getmembers() if m.isfile()}
        need(set(members)==set(arc_names)|{'ARCHIVE_INVENTORY.json'}, 'tar member list differs from explicit inventory')
        for row in rows:
            data=tar.extractfile(members[row['path']]).read()
            need(len(data)==row['bytes'] and sha(data)==row['sha256'],f'tar reopen mismatch: {row["path"]}')
        stored=json.loads(tar.extractfile(members['ARCHIVE_INVENTORY.json']).read())
        need(stored==manifest,'embedded inventory differs after reopen')
    inv=(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
    with inventory_path.open('xb') as f:f.write(inv)
    print(json.dumps({'status':'packed_and_reopened','archive':str(out),'archive_sha256':sha(out.read_bytes()),
                      'inventory':str(inventory_path),'inventory_sha256':sha(inv),'members':len(rows),
                      'native_batches':101,'native_gates':34,'own_ci_gates':79},indent=2))
if __name__=='__main__': main()
