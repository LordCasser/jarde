# Assignment-condition widening acceptance preparation

This is a static-only continuation of the indexed-list acceptance bundle. It inherits all 31 native gates and all 76 CI gates, then adds these three exact checks to both lanes:

- `jarde_java`: `build::tests::proved_loop_assignment_consumes_real_char_and_only_known_widenings`
- `p3_assignment_condition_widening`: `fixed_upstream_and_dynamic_controls_recover_the_widened_loop_condition`
- `p3_assignment_condition_widening`: `cancellation_does_not_publish_a_partial_condition_body`

The resulting inventories are 34 native gates and 79 CI gates. The source inventory grows from 17 to 18 paths by adding `tests/p3_assignment_condition_widening.rs`. The fixture inventory grows from 9 to 23 files by adding the complete 14-file `tests/fixtures/java8/assignment-condition-widening` root. Both collector and verifier use sorted, exact fixture and source tuples.

`verify_workspace.py` is copied byte-for-byte from accepted native v8 (SHA-256 `8321198c09133aad60d8591b1d3e8f4c849420c4b3a37c1bc4c4aa12129d9830`), preserving the `jarde_reader` library classification. The CI collector and verifier retain the official per-step ZIP and exact command checks. Product SHA, final CLI SHA, CI run ID, and native receipt paths remain runtime inputs; no future product values are guessed here.

This package was not run. Python files were syntax-parsed only; no Cargo, CI, native receipt, JDK, CLI, Git, or network action was executed.

See `inheritance-comparison.json` for the derived counts and `pins.json` for source SHA-256 values.
