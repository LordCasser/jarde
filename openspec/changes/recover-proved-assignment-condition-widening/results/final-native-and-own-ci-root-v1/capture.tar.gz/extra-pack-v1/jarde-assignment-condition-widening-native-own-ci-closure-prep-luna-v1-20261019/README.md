# Native and own-CI closure archive preparation

This private script follows the indexed-list archive convention: it packages only explicitly supplied completed evidence directories, writes an inventory with SHA-256 and byte counts, reopens the tar, and verifies every included file byte-for-byte. It excludes candidate CLI binaries, caches, `target`, and `__pycache__`.

At execution time, root supplies the accepted native execution directory (101 batches), native acceptance directory (34 gates and product binding), completed own-CI collection directory (including official `run-logs.zip`), accepted own-CI verifier directory (79 gates), tooling directory, and final results README. No future CI outcome is stored here. The packer refuses until the own-CI collection is complete and the verifier receipt is accepted with all 79 gates in both workspace seeds. It also checks the native receipts and binding, verifies all 202 native raw streams against the execution metadata, checks the official ZIP CRC, and requires the CI product and CLI pins to match the accepted native binding.

The native acceptance received is available at `/private/tmp/jarde-assignment-condition-widening-native-acceptance-root-v1-20261019`; native execution at `/private/tmp/jarde-assignment-condition-widening-workspace-seed1-root-v1-20261019`. CI was still running at preparation time, so no CI result or archive is embedded here. The invocation template contains placeholders only.

`indexed-list-pack-evidence.py.base` is the reused prior packer and `reuse-convention.diff` shows the change for this closure bundle. The new script was syntax-parsed only; it was not run.
