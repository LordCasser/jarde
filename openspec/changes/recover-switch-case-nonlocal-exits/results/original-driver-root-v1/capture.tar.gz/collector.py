#!/usr/bin/env python3
"""Root-run, guarded original-only runtime oracle for SN/SM/SL/LD."""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode = True

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
FIXTURE = ROOT / 'openspec/evidence/java-syntax-2026-10-05/switch-nonlocal-exit-patrol/fixture'
SOURCES = {
    'SN': ('5393e68866c8746d18b4556f0cca3d085f6c80600a7b4195ba00107b147fa5cc', 930),
    'SM': ('9020a135b245181039594535982c734a3c9fd04be948ede35c7fd61f468a6b95', 1186),
    'SL': ('05fd8992b322149e06d4912aa9572ca1e4ab3e73102fdb0a5e293b61ef54e41a', 1205),
    'LD': ('d8e267aba242cd1b4ab33e19dd034b1fce599ec1df25f245eb517ff45cc8b80d', 223),
}
DRIVER_DIR = Path('/private/tmp/jarde-switch-nonlocal-runtime-driver-luna-v1-20261018')
DRIVER_SOURCE = DRIVER_DIR / 'SwitchNonlocalRuntimeDriver.java'
EXPECTED = {name: DRIVER_DIR / f'expected-{name}.txt' for name in SOURCES}
COMPARE = ROOT / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_MANIFEST = ROOT / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
JDK_LEGS = ('javac8', 'javac23')
DEFAULT_OUT = Path('/private/tmp/jarde-switch-driver-original-root-v1-20261018')
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def write_json(path: Path, value) -> None:
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()

    root = ROOT.resolve(strict=True)
    out = args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing existing output directory: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('repository target must be absent before run')
    if shutil.disk_usage(root).free < FREE_LIMIT:
        raise SystemExit('5 GiB free-space guard failed before run')

    compare = load(COMPARE, 'switch_driver_compare_helpers')
    guard_path = root / GUARD_REL
    scanner_path = root / SCANNER_REL
    if sha(guard_path) != GUARD_SHA or sha(scanner_path) != SCANNER_SHA:
        raise SystemExit('pinned run guard/scanner source mismatch')
    jdks, jdk_record = compare.configured_jdks(JDK_MANIFEST, JDK_MANIFEST_SHA)
    source_paths = {name: FIXTURE / f'{name}.java' for name in SOURCES}
    for name, path in source_paths.items():
        actual = pin(path)
        expected_sha, expected_bytes = SOURCES[name]
        if actual['sha256'] != expected_sha or actual['bytes'] != expected_bytes:
            raise SystemExit(f'frozen original source pin mismatch: {path}')

    for path in [DRIVER_SOURCE, *EXPECTED.values()]:
        pin(path)
    expected_bytes = {name: path.read_bytes() for name, path in EXPECTED.items()}
    expected_rows = {name: len(data.decode('utf-8', errors='strict').splitlines())
                     for name, data in expected_bytes.items()}
    if any(not data.endswith(b'\n') for data in expected_bytes.values()):
        raise SystemExit('expected output files must end with one newline')
    total_cases = sum(expected_rows.values()) * len(JDK_LEGS) * len(JDK_LEGS)

    source_before = compare.source_closure(root)
    pinned_assets = {
        'runner': pin(Path(__file__)),
        'driver_source': pin(DRIVER_SOURCE),
        'case_table': pin(DRIVER_DIR / 'case-table.md'),
        'expected_outputs': {name: pin(path) for name, path in EXPECTED.items()},
        'original_sources': {name: pin(path) for name, path in source_paths.items()},
        'compare': pin(COMPARE),
        'guard': pin(guard_path),
        'scanner': pin(scanner_path),
        'jdk_manifest': pin(JDK_MANIFEST),
        'jdk_tools': {leg: {tool: pin(path) for tool, path in row['tools'].items()}
                      for leg, row in jdks.items()},
    }

    out.mkdir(parents=True)
    raw_dir = out / 'raw'
    raw_dir.mkdir()
    guard = load(guard_path, 'switch_driver_root_guard')
    scanner = load(scanner_path, 'switch_driver_root_scanner')
    guard.ROOT = root
    guard.OUT = raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = lambda path: compare.pin(path)
    guard.expected_test_summaries = lambda index, stdout: None

    result = {
        'schema': 'switch-nonlocal-original-driver-v1',
        'status': 'running',
        'root': str(root),
        'output': str(out),
        'inputs_before': pinned_assets,
        'source_pins_before': source_before,
        'jdk_manifest_record': jdk_record,
        'matrix': {
            'classes': list(SOURCES),
            'original_input_compilers': list(JDK_LEGS),
            'runtime_jvms': list(JDK_LEGS),
            'driver_compiler': 'javac8',
            'driver_source_bytes': pinned_assets['driver_source']['bytes'],
            'expected_rows_per_class': expected_rows,
            'expected_total_rows_per_runtime_leg': sum(expected_rows.values()) * len(JDK_LEGS),
            'runtime_commands': len(SOURCES) * len(JDK_LEGS) * len(JDK_LEGS),
            'total_commands_expected': 1 + len(SOURCES) * len(JDK_LEGS) + len(SOURCES) * len(JDK_LEGS) * len(JDK_LEGS),
            'total_runtime_case_invocations': total_cases,
        },
        'commands': [],
        'original_classes': [],
        'runtime_results': [],
    }
    write_json(out / 'execution.json', result)
    try:
        env_base = compare.clean_env(dict(os.environ))
        env_base.pop('RUST_MIN_STACK', None)
        env_base.update(guard.ENV_VALUES)

        def command(label: str, argv: list[str], leg: str) -> dict:
            if (root / 'target').exists() or (root / 'target').is_symlink():
                raise RuntimeError(f'target directory appeared before {label}')
            if shutil.disk_usage(root).free < FREE_LIMIT:
                raise RuntimeError(f'5 GiB free-space guard failed before {label}')
            env = compare.clean_env(env_base, jdks[leg])
            row = guard.run_command(len(result['commands']) + 1, argv, env)
            row['label'] = label
            row['compiler_or_runtime_leg'] = leg
            result['commands'].append(row)
            write_json(out / 'execution.json', result)
            if row.get('guard_stop') is not None:
                raise RuntimeError(f'guard stopped immediately at {label}: {row["guard_stop"]}')
            return row

        def compile_one(source: Path, class_name: str, leg: str, out_dir: Path, label: str) -> tuple[dict, Path]:
            if out_dir.exists():
                raise RuntimeError(f'refusing existing class output {out_dir}')
            out_dir.mkdir(parents=True)
            empty_classpath = out_dir.parent / (out_dir.name + '-empty-classpath')
            empty_sourcepath = out_dir.parent / (out_dir.name + '-empty-sourcepath')
            empty_classpath.mkdir()
            empty_sourcepath.mkdir()
            flags = ['-source', '8', '-target', '8', '-g', '-encoding', 'UTF-8',
                     '-Xlint:-options', '-proc:none', '-classpath', str(empty_classpath),
                     '-sourcepath', str(empty_sourcepath), '-d', str(out_dir)]
            row = command(label, [str(jdks[leg]['tools']['javac']), *flags, str(source)], leg)
            class_file = out_dir / f'{class_name}.class'
            if row['exit_code'] != 0 or not class_file.is_file():
                raise RuntimeError(f'class compilation failed: {label}')
            return row, class_file

        driver_classes = out / 'driver-classes'
        driver_compile, driver_class = compile_one(DRIVER_SOURCE, 'SwitchNonlocalRuntimeDriver',
                                                   'javac8', driver_classes, 'driver-javac8')
        driver_class_pins = {path.name: pin(path) for path in sorted(driver_classes.glob('*.class'))}
        if 'SwitchNonlocalRuntimeDriver.class' not in driver_class_pins:
            raise RuntimeError('driver compilation did not produce its entry class')
        driver_pin = driver_class_pins['SwitchNonlocalRuntimeDriver.class']
        result['driver_class'] = {'compile_command': driver_compile['index'], 'classes': driver_class_pins}
        write_json(out / 'execution.json', result)

        originals = {}
        for name, source in source_paths.items():
            for leg in JDK_LEGS:
                class_dir = out / 'original-classes' / name / leg
                class_dir.parent.mkdir(parents=True, exist_ok=True)
                compile_row, class_file = compile_one(source, name, leg, class_dir,
                                                      f'original-{name}-{leg}-compile')
                class_pin = pin(class_file)
                result['original_classes'].append({
                    'class_name': name,
                    'compiler': leg,
                    'source': pin(source),
                    'compile_command': compile_row['index'],
                    'class': class_pin,
                })
                originals[(name, leg)] = (class_dir.resolve(strict=True), class_file, class_pin)
                write_json(out / 'execution.json', result)

        for name in SOURCES:
            for input_compiler in JDK_LEGS:
                class_root, class_file, initial_class_pin = originals[(name, input_compiler)]
                for runtime_leg in JDK_LEGS:
                    if pin(class_file) != initial_class_pin or {path.name: pin(path) for path in sorted(driver_classes.glob('*.class'))} != driver_class_pins:
                        raise RuntimeError(f'class pin changed before runtime: {name}/{input_compiler}/{runtime_leg}')
                    classpath = os.pathsep.join((str(class_root), str(driver_classes.resolve(strict=True))))
                    argv = [str(jdks[runtime_leg]['tools']['java']), '-Xverify:all',
                            '-cp', classpath, 'SwitchNonlocalRuntimeDriver', name, str(class_root)]
                    row = command(f'original-{name}-{input_compiler}-{runtime_leg}', argv, runtime_leg)
                    stdout = compare.command_artifact(row, 'stdout')
                    compare.command_artifact(row, 'stderr')
                    if row['exit_code'] != 0:
                        raise RuntimeError(f'original driver failed: {name}/{input_compiler}/{runtime_leg}')
                    if stdout != expected_bytes[name]:
                        raise RuntimeError(f'fixed stdout oracle mismatch: {name}/{input_compiler}/{runtime_leg}')
                    if pin(class_file) != initial_class_pin or {path.name: pin(path) for path in sorted(driver_classes.glob('*.class'))} != driver_class_pins:
                        raise RuntimeError(f'class pin changed after runtime: {name}/{input_compiler}/{runtime_leg}')
                    result['runtime_results'].append({
                        'class_name': name,
                        'input_compiler': input_compiler,
                        'runtime_jvm': runtime_leg,
                        'command': row['index'],
                        'exit_code': row['exit_code'],
                        'target_class': initial_class_pin,
                        'driver_class': driver_class_pins,
                        'stdout_bytes': len(stdout),
                        'stdout_sha256': row['streams']['stdout']['sha256'],
                        'stderr_sha256': row['streams']['stderr']['sha256'],
                        'matches_fixed_expected': True,
                        'case_lines': len(stdout.decode('utf-8', errors='strict').splitlines()),
                        'expected_case_lines': expected_rows[name],
                    })
                    write_json(out / 'execution.json', result)

        result['status'] = 'complete_pending_independent_review'
        result['source_pins_after'] = compare.source_closure(root)
        result['source_pins_unchanged'] = result['source_pins_after'] == source_before
        result['inputs_after'] = {
            'runner': pin(Path(__file__)),
            'driver_source': pin(DRIVER_SOURCE),
            'case_table': pin(DRIVER_DIR / 'case-table.md'),
            'expected_outputs': {name: pin(path) for name, path in EXPECTED.items()},
            'original_sources': {name: pin(path) for name, path in source_paths.items()},
            'compare': pin(COMPARE),
            'guard': pin(guard_path),
            'scanner': pin(scanner_path),
            'jdk_manifest': pin(JDK_MANIFEST),
            'jdk_tools': {leg: {tool: pin(path) for tool, path in row['tools'].items()}
                          for leg, row in jdks.items()},
        }
        result['inputs_unchanged'] = result['inputs_after'] == pinned_assets
        result['repository_target_absent_after'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
        result['command_count'] = len(result['commands'])
        result['runtime_command_count'] = len(result['runtime_results'])
        result['total_runtime_case_invocations'] = sum(item['case_lines'] for item in result['runtime_results'])
        result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        if (not result['source_pins_unchanged'] or not result['inputs_unchanged']
                or not result['repository_target_absent_after']
                or result['total_runtime_case_invocations'] != total_cases):
            result['status'] = 'interrupted'
            result['failure'] = 'source/input pins, target absence, or runtime case-count check failed'
        write_json(out / 'execution.json', result)
        if result['status'] != 'complete_pending_independent_review':
            raise RuntimeError(result.get('failure', 'final guard failed'))
        return 0
    except BaseException as exc:
        result['status'] = 'interrupted'
        result['failure'] = f'{type(exc).__name__}: {exc}'
        try:
            result['source_pins_after_failure'] = compare.source_closure(root)
            result['source_pins_unchanged_at_failure'] = result['source_pins_after_failure'] == source_before
            result['inputs_after_failure'] = {
                'runner': pin(Path(__file__)),
                'driver_source': pin(DRIVER_SOURCE),
                'case_table': pin(DRIVER_DIR / 'case-table.md'),
                'expected_outputs': {name: pin(path) for name, path in EXPECTED.items()},
                'original_sources': {name: pin(path) for name, path in source_paths.items()},
                'compare': pin(COMPARE),
                'guard': pin(guard_path),
                'scanner': pin(scanner_path),
                'jdk_manifest': pin(JDK_MANIFEST),
                'jdk_tools': {leg: {tool: pin(path) for tool, path in row['tools'].items()}
                              for leg, row in jdks.items()},
            }
            result['inputs_unchanged_at_failure'] = result['inputs_after_failure'] == pinned_assets
            result['repository_target_absent_at_failure'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
        except BaseException as audit_exc:
            result['failure_audit_error'] = f'{type(audit_exc).__name__}: {audit_exc}'
        result['command_count'] = len(result['commands'])
        result['runtime_command_count'] = len(result['runtime_results'])
        result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write_json(out / 'execution.json', result)
        raise



if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        raise SystemExit(f'original runtime driver collector failed: {type(exc).__name__}: {exc}')
