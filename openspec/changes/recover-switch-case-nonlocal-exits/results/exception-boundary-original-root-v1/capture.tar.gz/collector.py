import json, pathlib, importlib.util, os, shutil, hashlib
ROOT=pathlib.Path('/Users/lordcasser/workspace/projects/jarde')
OUT=pathlib.Path('/private/tmp/jarde-switch-exception-original-root-v1-20261018')
SOURCE=pathlib.Path('/private/tmp/jarde-switch-exception-clone-control-luna-v2-20261018/SwitchLoopExceptionBoundary.java')
def load(path,name):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','compare')
manifest=ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
jdks,jdk_record=c.configured_jdks(manifest,'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
assert not OUT.exists() and not (ROOT/'target').exists()
OUT.mkdir();(OUT/'raw').mkdir()
g=load(ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py','guard')
s=load(ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py','scanner')
assert c.pin(pathlib.Path(g.__file__))['sha256']=='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
assert c.pin(pathlib.Path(s.__file__))['sha256']=='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:s.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
expected=b'empty=0\nnormal=7\ncase-return=2\ncaught=-7\nnull=-7\n'
(OUT/'expected.txt').write_bytes(expected)
source=OUT/SOURCE.name;shutil.copy2(SOURCE,source)
assert c.pin(SOURCE)['sha256']=='641cddf39b3123cf61a3ee2e33cbe7233b553e64fa5dbf4db114128899d461b4'
inputs={'source':c.pin(SOURCE),'copy':c.pin(source),'runner':c.pin(pathlib.Path(__file__)),
        'jdk_tools':{leg:{name:c.pin(path) for name,path in x['tools'].items()} for leg,x in jdks.items()}}
r={'status':'running','inputs_before':inputs,'source_before':c.source_closure(ROOT),'commands':[],'classes':[], 'runs':[], 'expected':c.pin(OUT/'expected.txt')}
def save():(OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
def command(argv,leg):
    env=c.clean_env(dict(os.environ),jdks[leg]);env.pop('RUST_MIN_STACK',None);env.pop('CARGO_TARGET_DIR',None)
    env.update(g.ENV_VALUES)
    row=g.run_command(len(r['commands'])+1,argv,env);r['commands'].append(row);save()
    assert row['exit_code']==0 and row['guard_stop'] is None
    return row
save()
try:
    for leg in ['javac8','javac23']:
        target=OUT/'classes'/leg;target.mkdir(parents=True)
        cp=OUT/('empty-cp-'+leg);sp=OUT/('empty-sp-'+leg);cp.mkdir();sp.mkdir()
        flags=['-source','8','-target','8'] if leg=='javac8' else ['--release','8']
        command([str(jdks[leg]['tools']['javac']),*flags,'-g','-encoding','UTF-8','-Xlint:-options','-proc:none','-classpath',str(cp),'-sourcepath',str(sp),'-d',str(target),str(source)],leg)
        cls=target/'SwitchLoopExceptionBoundary.class';record={'compiler':leg,'class':c.pin(cls),'facts':c.parse_class(cls)}
        r['classes'].append(record);save()
        for runtime in ['javac8','javac23']:
            row=command([str(jdks[runtime]['tools']['java']),'-Xverify:all','-cp',str(target),'SwitchLoopExceptionBoundary'],runtime)
            actual=c.command_artifact(row,'stdout');assert actual==expected
            assert c.pin(cls)==record['class']
            r['runs'].append({'compiler':leg,'runtime':runtime,'command':row['index'],'exact_oracle':True});save()
    r['status']='complete_pending_root_review'
finally:
    r['source_after']=c.source_closure(ROOT);r['source_unchanged']=r['source_before']==r['source_after']
    r['inputs_after']={'source':c.pin(SOURCE),'copy':c.pin(source),'runner':c.pin(pathlib.Path(__file__)),
        'jdk_tools':{leg:{name:c.pin(path) for name,path in x['tools'].items()} for leg,x in jdks.items()}}
    r['inputs_unchanged']=r['inputs_after']==inputs;r['target_absent']=not (ROOT/'target').exists();save()
assert r['source_unchanged'] and r['inputs_unchanged'] and r['target_absent']
print(json.dumps({'status':r['status'],'commands':len(r['commands']),'original_runs':len(r['runs']),'target_absent':r['target_absent']}))
