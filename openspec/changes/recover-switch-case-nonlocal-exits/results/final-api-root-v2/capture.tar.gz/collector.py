#!/usr/bin/env python3
"""Capture the 16 API-only Jarde switch-return replay cells for root review."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, tarfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
FOCUSED_RECEIPT = Path('/private/tmp/jarde-switch-return-focused-root-v1-20261018/execution.json')
BASELINE_ARCHIVE = Path('/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-switch-case-nonlocal-exits/results/baseline-root-v1/capture.tar.gz')
COMPARE = ROOT / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
BASELINE_OLD_CLI_SHA = '605fdd1b2b0cc077bb9440a02b7f995ca33dded37b7527cc306f65a77bdf4c0c'
CLASSES = ('SN', 'SM', 'SL', 'LD')
LEGS = ('javac8', 'javac23')
EVIDENCE = ('default', 'all')
SN_RETURN_METHODS = ('retInSwitchNoTail', 'retInSwitchTail')
SM_CONTROLS = ('onlyBreak', 'onlyContinue', 'breakNoTail', 'ifVersion', 'noTailMix')
DEFAULT_OUT = Path('/private/tmp/jarde-switch-return-api-replay-root-v1-20261018')
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')
REPORT_STABLE_FIELDS = ('quality', 'fallbacks', 'source_map', 'regions', 'rules', 'semantic_validation',
                        'syntax_status', 'verification', 'representation', 'content', 'outcome', 'text',
                        'diagnostics', 'method', 'compile_status', 'evidence')


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha_bytes(data)}


def write_json(path: Path, doc) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    tmp.replace(path)


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper {path}')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def method_projection(method: dict) -> dict:
    identity = method['item']['identity']
    report = method.get('outcome', {}).get('report', {})
    return {
        'identity': identity,
        'index': method['item'].get('index'),
        'declaration': method.get('declaration'),
        'no_body_kind': method.get('no_body_kind'),
        'outcome_kind': method.get('outcome', {}).get('kind'),
        'text': method.get('text'),
        'report': {key: report.get(key) for key in REPORT_STABLE_FIELDS if key in report},
    }


def method_names(doc) -> list[tuple[str, str]]:
    return [(bytes(m['item']['identity']['name']).decode('utf-8'),
             bytes(m['item']['identity']['descriptor']).decode('utf-8'))
            for m in doc.get('methods', [])]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, default=DEFAULT_OUT)
    ap.add_argument('--focused-receipt', type=Path, default=FOCUSED_RECEIPT)
    ap.add_argument('--baseline-archive', type=Path, default=BASELINE_ARCHIVE)
    args = ap.parse_args()
    root = ROOT.resolve(strict=True)
    out = args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing existing output directory: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('repository target must be absent before API replay')

    compare = load(COMPARE, 'switch_return_api_compare_helpers')
    guard_path = root / GUARD_REL
    scanner_path = root / SCANNER_REL
    if sha_bytes(guard_path.read_bytes()) != GUARD_SHA or sha_bytes(scanner_path.read_bytes()) != SCANNER_SHA:
        raise SystemExit('pinned run guard/scanner source mismatch')
    focused = json.loads(args.focused_receipt.read_text(encoding='utf-8'))
    if focused.get('status') != 'commands_passed_pending_independent_acceptance':
        raise SystemExit('focused build receipt is not in the expected pending-review state')
    cli_record = focused.get('cli')
    if not isinstance(cli_record, dict) or not {'path', 'bytes', 'sha256'} <= cli_record.keys():
        raise SystemExit('focused receipt has no complete CLI pin')
    cli = Path(cli_record['path']).resolve(strict=True)
    if pin(cli) != {'path': str(cli), 'bytes': cli_record['bytes'], 'sha256': cli_record['sha256']}:
        raise SystemExit('focused receipt CLI pin does not match the current executable')

    archive_pin = pin(args.baseline_archive)
    baseline_review = args.baseline_archive.parent / 'capture-review.json'
    baseline_review_doc = json.loads(baseline_review.read_text(encoding='utf-8'))
    if baseline_review_doc.get('archive_sha256') != archive_pin['sha256']:
        raise SystemExit('baseline archive SHA does not match adjacent capture-review.json')
    if baseline_review_doc.get('archive_bytes') != archive_pin['bytes']:
        raise SystemExit('baseline archive byte count does not match adjacent capture-review.json')
    out.mkdir(parents=True)
    raw_dir = out / 'raw'
    raw_dir.mkdir()
    guard = load(guard_path, 'switch_return_api_root_guard')
    scanner = load(scanner_path, 'switch_return_api_root_scanner')
    guard.ROOT = root
    guard.OUT = raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = lambda p: compare.pin(p)
    guard.expected_test_summaries = lambda index, stdout: None

    source_before = compare.source_closure(root)
    inputs_before = {
        'focused_receipt': pin(args.focused_receipt),
        'focused_cli': pin(cli),
        'baseline_archive': archive_pin,
        'baseline_capture_review': pin(baseline_review),
        'compare_helpers': pin(COMPARE),
        'runner': pin(Path(__file__)),
        'guard': pin(guard_path),
        'scanner': pin(scanner_path),
    }
    result = {
        'schema': 'switch-return-api-replay-v1',
        'status': 'running',
        'root': str(root),
        'output': str(out),
        'inputs_before': inputs_before,
        'source_pins_before': source_before,
        'focused_cli_from_receipt': cli_record,
        'baseline_archive': archive_pin,
        'matrix': {'classes': list(CLASSES), 'input_legs': list(LEGS), 'evidence': list(EVIDENCE),
                   'api_commands': len(CLASSES) * len(LEGS) * len(EVIDENCE)},
        'commands': [],
        'cells': [],
        'comparisons': [],
        'assertions': [],
        'notes': [
            'API-only replay: uses the eight original full class files from the pinned baseline capture; no compiler, runtime, JADX, or Cargo command is run.',
            'Exit 4 is retained as a capturable partial response; stdout/stderr and the complete stdout JSON bytes are preserved for every command.',
            'Method stable projection compares text, identity/order, quality, fallback, source map, regions, rules, and related semantic report fields; execution usage/timing is excluded.',
            'SL and LD outcomes are recorded without assuming that this return-only MVP recovers them.',
        ],
    }
    write_json(out / 'execution.json', result)

    env = compare.clean_env(dict(os.environ))
    env.pop('RUST_MIN_STACK', None)
    env.update(guard.ENV_VALUES)
    commands = result['commands']
    baseline_docs = {}
    current_docs = {}
    class_inputs = {}
    copied_class_pins_before = {}
    old_receipt = None
    try:
        with tarfile.open(args.baseline_archive, 'r:gz') as tf:
            old_receipt = json.load(tf.extractfile('execution.json'))
            if old_receipt.get('status') != 'complete_pending_independent_review':
                raise RuntimeError('archived baseline execution receipt is not complete')
            old_cli = old_receipt.get('inputs_before', {}).get('cli', {})
            if old_cli.get('sha256') != BASELINE_OLD_CLI_SHA:
                raise RuntimeError('archived baseline is not the pinned 605 CLI capture')
            class_records = {(x['class_name'], x['compiler']): x for x in old_receipt['original_classes']}
            for class_name in CLASSES:
                for leg in LEGS:
                    record = class_records[(class_name, leg)]['class']
                    member = f'original-classes/{class_name}/{leg}/{class_name}.class'
                    data = tf.extractfile(member).read()
                    if len(data) != record['bytes'] or sha_bytes(data) != record['sha256']:
                        raise RuntimeError(f'baseline class member pin mismatch: {member}')
                    dest = out / 'inputs' / member
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(data)
                    class_inputs[(class_name, leg)] = dest
                    copied_class_pins_before[f'{class_name}/{leg}'] = pin(dest)
                    for evidence in EVIDENCE:
                        json_member = f'jarde-json/{class_name}/{leg}/{evidence}.json'
                        baseline_docs[(class_name, leg, evidence)] = json.load(tf.extractfile(json_member))
        result['inputs_before']['copied_classes'] = copied_class_pins_before
        write_json(out / 'execution.json', result)

        for class_name in CLASSES:
            for leg in LEGS:
                class_path = class_inputs[(class_name, leg)]
                expected_class = class_records[(class_name, leg)]['class']
                if pin(class_path)['sha256'] != expected_class['sha256']:
                    raise RuntimeError(f'copied class changed: {class_name}/{leg}')
                for evidence in EVIDENCE:
                    argv = [str(cli), 'class-source', '--input', str(class_path), '--class', class_name,
                            '--policy', 'single-class', '--release', '8', '--format', 'json']
                    if evidence == 'all':
                        argv.extend(['--evidence', 'all'])
                    command = guard.run_command(len(commands) + 1, argv, env)
                    label = f'jarde-{class_name}-{leg}-{evidence}'
                    command.update({'label': label, 'phase': 'jarde-class-source-api-only', 'input_leg': leg})
                    commands.append(command)
                    write_json(out / 'execution.json', result)
                    if command.get('guard_stop') is not None:
                        raise RuntimeError(f'guard stopped {label}: {command["guard_stop"]}')
                    stdout = compare.command_artifact(command, 'stdout')
                    stderr = compare.command_artifact(command, 'stderr')
                    for channel, data in (('stdout', stdout), ('stderr', stderr)):
                        rp = out / 'raw' / f'{command["index"]:02d}-{label}.{channel}.raw'
                        rp.write_bytes(data)
                        command[f'{channel}_raw'] = pin(rp)
                    jp = out / 'json' / class_name / leg / f'{evidence}.json'
                    jp.parent.mkdir(parents=True, exist_ok=True)
                    jp.write_bytes(stdout)
                    cell = {
                        'class_name': class_name, 'input_leg': leg, 'evidence': evidence,
                        'input_class': pin(class_path), 'input_class_facts': compare.parse_class(class_path),
                        'command': command['index'], 'argv': argv, 'exit_code': command.get('exit_code'),
                        'exit_classification': 'exit-4-capturable' if command.get('exit_code') == 4 else ('success' if command.get('exit_code') == 0 else 'other-exit-captured'),
                        'stdout_raw': command['stdout_raw'], 'stderr_raw': command['stderr_raw'],
                        'json_artifact': pin(jp), 'method_identities': [], 'capture_error': None,
                    }
                    if command.get('exit_code') not in (0, 4):
                        raise RuntimeError(f'{label}: unexpected CLI exit {command.get("exit_code")}')
                    try:
                        doc = json.loads(stdout.decode('utf-8'))
                    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                        cell['capture_error'] = f'{type(exc).__name__}: {exc}'
                        raise RuntimeError(f'{label}: stdout is not complete UTF-8 JSON') from exc
                    if not isinstance(doc, dict) or not isinstance(doc.get('methods'), list):
                        raise RuntimeError(f'{label}: JSON has no methods array')
                    current_docs[(class_name, leg, evidence)] = doc
                    cell['top_outcome'] = doc.get('outcome')
                    full_text = doc.get('text')
                    if isinstance(full_text, str):
                        text_path = out / 'class-text' / class_name / leg / f'{evidence}.java.txt'
                        text_path.parent.mkdir(parents=True, exist_ok=True)
                        text_bytes = full_text.encode('utf-8')
                        text_path.write_bytes(text_bytes)
                        cell['full_class_text'] = pin(text_path)
                        cell['full_class_text_matches_json_utf8'] = text_path.read_bytes() == text_bytes
                    else:
                        cell['full_class_text'] = None
                        cell['full_class_text_matches_json_utf8'] = False
                    cell['top_text_sha256'] = sha_bytes(doc.get('text', '').encode('utf-8')) if isinstance(doc.get('text'), str) else None
                    cell['method_identities'] = [{'name': n, 'descriptor': d} for n, d in method_names(doc)]
                    cell['methods'] = []
                    baseline_doc = baseline_docs[(class_name, leg, evidence)]
                    if method_names(doc) != method_names(baseline_doc):
                        raise RuntimeError(f'{label}: method identity/order differs from old 605 baseline')
                    for old_method, new_method in zip(baseline_doc['methods'], doc['methods']):
                        old_proj = method_projection(old_method)
                        new_proj = method_projection(new_method)
                        changed_fields = [k for k in old_proj if old_proj[k] != new_proj[k]]
                        old_id = compare.method_key(old_method)
                        summary = {
                            'identity': {'name': old_id[0], 'descriptor': old_id[1]},
                            'old_quality': old_proj['report'].get('quality'),
                            'new_quality': new_proj['report'].get('quality'),
                            'old_fallbacks': old_proj['report'].get('fallbacks'),
                            'new_fallbacks': new_proj['report'].get('fallbacks'),
                            'old_text_sha256': sha_bytes((old_proj['text'] or '').encode('utf-8')),
                            'new_text_sha256': sha_bytes((new_proj['text'] or '').encode('utf-8')),
                            'old_source_map': old_proj['report'].get('source_map'),
                            'new_source_map': new_proj['report'].get('source_map'),
                            'changed_projection_fields': changed_fields,
                            'projection_equal': not changed_fields,
                        }
                        cell['methods'].append(summary)
                        result['comparisons'].append({'class_name': class_name, 'input_leg': leg, 'evidence': evidence,
                                                      **summary})
                    result['cells'].append(cell)
                    write_json(out / 'execution.json', result)

        def find_method(doc, name):
            hits = [m for m in doc['methods'] if compare.method_key(m)[0] == name]
            if len(hits) != 1:
                raise RuntimeError(f'expected one method {name}, found {len(hits)}')
            return hits[0]

        assertions = result['assertions']
        for leg in LEGS:
            for class_name in CLASSES:
                default = current_docs[(class_name, leg, 'default')]
                all_doc = current_docs[(class_name, leg, 'all')]
                equal = default.get('text') == all_doc.get('text') and method_names(default) == method_names(all_doc)
                for dm, am in zip(default['methods'], all_doc['methods']):
                    dp, ap = method_projection(dm), method_projection(am)
                    equal = equal and dp['text'] == ap['text'] and dp['report'].get('source_map') == ap['report'].get('source_map')
                assertions.append({'id': 'default-all-text-map-parity', 'class_name': class_name, 'input_leg': leg, 'passed': bool(equal)})
                if not equal:
                    raise RuntimeError(f'default/all text or source-map mismatch: {class_name}/{leg}')
            for name in SN_RETURN_METHODS:
                m = find_method(current_docs[('SN', leg, 'all')], name)
                p = method_projection(m)
                report = p['report']
                structured = report.get('quality') == 'structured' and report.get('fallbacks') == [] and 'jarde: not recovered' not in (p.get('text') or '')
                assertions.append({'id': 'SN-switch-return-is-structured', 'input_leg': leg, 'method': name, 'passed': structured,
                                   'quality': report.get('quality'), 'fallbacks': report.get('fallbacks')})
                if not structured:
                    raise RuntimeError(f'SN expected structured return method {name} for {leg}')
            for name in SM_CONTROLS:
                old = find_method(baseline_docs[('SM', leg, 'all')], name)
                new = find_method(current_docs[('SM', leg, 'all')], name)
                same_text = old.get('text') == new.get('text')
                assertions.append({'id': 'SM-control-text-unchanged', 'input_leg': leg, 'method': name, 'passed': same_text})
                if not same_text:
                    raise RuntimeError(f'SM control method text changed: {leg}/{name}')

        result['status'] = 'complete_pending_independent_review'
    except Exception as exc:
        result['status'] = 'interrupted'
        result['failure'] = f'{type(exc).__name__}: {exc}'
        raise
    finally:
        result['source_pins_after'] = compare.source_closure(root)
        result['source_pins_unchanged'] = result['source_pins_after'] == result['source_pins_before']
        result['inputs_after'] = {
            'focused_receipt': pin(args.focused_receipt),
            'focused_cli': pin(cli),
            'baseline_archive': pin(args.baseline_archive),
            'baseline_capture_review': pin(baseline_review),
            'compare_helpers': pin(COMPARE),
            'copied_classes': {f'{c}/{l}': pin(p) for (c, l), p in class_inputs.items() if p.is_file()},
            'runner': pin(Path(__file__)),
            'guard': pin(guard_path),
            'scanner': pin(scanner_path),
        }
        copied_class_inputs_missing = [f'{c}/{l}' for (c, l), p in class_inputs.items() if not p.is_file()]
        result['copied_class_inputs_missing'] = copied_class_inputs_missing
        result['copied_class_inputs_before'] = copied_class_pins_before
        result['copied_class_inputs_after'] = result['inputs_after']['copied_classes']
        result['copied_class_inputs_unchanged'] = (not copied_class_inputs_missing and
            copied_class_pins_before == result['inputs_after']['copied_classes'])
        result['inputs_unchanged'] = (result['inputs_after'] == result['inputs_before'] and
            result['copied_class_inputs_unchanged'])
        result['repository_target_absent_after'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
        result['command_count'] = len(commands)
        result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        if not result['source_pins_unchanged'] or not result['inputs_unchanged'] or not result['repository_target_absent_after']:
            result['status'] = 'interrupted'
            result.setdefault('failure', 'source/input pins changed or repository target appeared')
        write_json(out / 'execution.json', result)
    if result['status'] != 'complete_pending_independent_review':
        raise RuntimeError('final source/target check failed')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        raise SystemExit(f'switch return API replay failed: {type(exc).__name__}: {exc}')
