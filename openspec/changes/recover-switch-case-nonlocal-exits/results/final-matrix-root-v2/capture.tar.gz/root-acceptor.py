from pathlib import Path
import json, hashlib, shutil, collections, tarfile

p=Path('/private/tmp/jarde-switch-final-matrix-root-v2-20261018')
d=json.loads((p/'execution.json').read_text())
def pincheck(x):
    if isinstance(x,dict):
        if {'path','bytes','sha256'}<=x.keys():
            b=Path(x['path']).read_bytes()
            assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'],x['path']
        else:
            for v in x.values():pincheck(v)
    elif isinstance(x,list):
        for v in x:pincheck(v)
def raw(x):
    pincheck(x);return Path(x['path']).read_bytes()
assert d['status']=='complete_pending_independent_review'
for k in ['inputs_unchanged','source_pins_unchanged','source_artifacts_unchanged',
          'driver_classes_unchanged','driver_source_copy_unchanged','repository_target_absent_after']:
    assert d[k],k
assert len(d['commands'])==d['command_count']==225
assert len(d['rebuilds'])==d['target_source_compile_count']==48
assert d['driver_source_compile_count']==1
pincheck(d['inputs_before']);pincheck(d['inputs_after']);pincheck(d['source_artifacts_after'])
for c in d['commands']:
    assert c.get('guard_stop') is None
    pincheck(c['streams'])
api=json.loads(Path(d['inputs_before']['api_receipt']['path']).read_text())
for src in d['source_artifacts']:
    data=raw(src['path'])
    if src['kind']=='jarde':
        cell=next(c for c in api['cells'] if (c['class_name'],c['input_leg'],c['evidence']) ==
                  (src['class_name'],src['input_leg'],src['evidence']))
        doc=json.loads(raw(cell['json_artifact']))
        assert data==doc['text'].encode()==raw(cell['full_class_text'])
    else:
        with tarfile.open(d['inputs_before']['baseline_archive']['path']) as tf:
            assert data==tf.extractfile(src['origin']['archive_member']).read()
assert len(d['source_artifacts'])==24
counts=collections.Counter();case_calls=0
for x in d['rebuilds']:
    kind=x['kind'];name=x['class_name'];counts[(kind,x['compile_classification'])]+=1
    assert x['classes_before_runtime']==x['classes_after_runtime']
    assert x['source']==x['source_after_runtime']
    c=d['commands'][x['compile_command']-1]
    assert c['argv'][-1]==x['source']['path']
    if x['build_leg']=='javac23':
        assert c['argv'][1:3]==['--release','8'] and '-target' not in c['argv']
    else:
        assert c['argv'][1:5]==['-source','8','-target','8']
    assert Path(x['source']['path']).name==name+'.java'
    if x['compile_classification']=='compiled':
        assert c['exit_code']==0 and len(x['driver_runs'])==len(x['main_runs'])==2
    else:
        assert kind=='jadx' and name=='SL' and c['exit_code']!=0
        assert not x['driver_runs'] and not x['main_runs']
        assert any(t in raw(c['streams']['stderr']) for t in (b'unreachable statement', '无法访问的语句'.encode()))
    for r in x['driver_runs']:
        rr=d['commands'][r['command']-1]
        cp=rr['argv'][rr['argv'].index('-cp')+1].split(':')
        assert len(cp)==2 and cp[0]!=cp[1] and cp[1]==str(p/'driver-classes')
        assert rr['argv'][-2:]==[name,cp[0]] and '-Xverify:all' in rr['argv']
        expected=Path(d['inputs_before']['driver_assets']['expected_outputs'][name]['path']).read_bytes()
        stdout=raw(r['stdout']);stderr=raw(r['stderr'])
        if kind=='jarde' or name=='SM':
            assert r['classification']=='exact_match' and rr['exit_code']==0
            assert stdout==expected
            if kind=='jarde':case_calls+=len(expected.splitlines())
        else:
            assert name in ('SN','LD') and rr['exit_code']!=0 and r['classification']=='runtime_failure'
            assert b'ledgerBreak returned unexpected value' in stderr
            assert expected.startswith(stdout), 'failed driver must preserve exact completed prefix'
    for r in x['main_runs']:
        rr=d['commands'][r['command']-1];assert rr['exit_code']==0
        assert rr['argv'][-1]==name and '-Xverify:all' in rr['argv']
        if kind=='jadx' and name=='LD':
            assert r['classification']=='jadx_ld_main_wrong_code' and raw(r['stdout'])==b'9\n'
        else:
            assert r['classification']=='exact_match' and r['matches_original_main_oracle']
        assert hashlib.sha256(raw(r['stdout'])).hexdigest()==r['original_main_oracle_sha256'] or (kind=='jadx' and name=='LD')
assert counts=={('jarde','compiled'):32,('jadx','compiled'):12,('jadx','compile_failure'):4}
assert case_calls==1744
report={'status':'accepted final whole-source matrix stage','commands':225,'raw_streams':450,
        'jarde_whole_source_compiles_passed':32,'jarde_isolated_driver_runs_passed':64,
        'jarde_driver_case_invocations_passed':1744,'jarde_main_runs_passed':64,
        'jarde_source_bytes_exact_api_text':True,'jadx_source_bytes_exact_baseline':True,
        'jadx_SL_compile_failures_preserved':4,'jadx_SN_driver_ledgerBreak_failures':8,
        'jadx_LD_driver_ledgerBreak_failures':8,'jadx_LD_main_wrong_9_instead_of_10':8,
        'jadx_SM_driver_runs_passed':8,'actual_all_driver_output_lines':d['observed_driver_output_lines'],
        'original_driver_oracle_stage':'436 case invocations in original-driver-root-v1',
        'source_and_inputs_stable_at_collection':True,'target_absent':True,
        'limitations':['JADX driver stops at its first wrong ledgerBreak input; later cases are not claimed executed.',
                       'Final production and boundary/stop tests are pinned in final-focused-root-v5; only corpus-fingerprint regeneration remains permitted in later gates.',
                       'Final Clippy/MSRV/P5/workspace and exact-product CI remain pending.']}
(p/'root-review.json').write_text(json.dumps(report,indent=2)+'\n')
shutil.copy2(__file__,p/'root-acceptor.py')
shutil.copy2('/private/tmp/jarde-switch-final-matrix-collector-root-v4-20261018.py',p/'collector.py')
asset=p/'driver-inputs';asset.mkdir(exist_ok=True)
for src in Path('/private/tmp/jarde-switch-nonlocal-runtime-driver-luna-v1-20261018').iterdir():
    if src.is_file():shutil.copy2(src,asset/src.name)
print(json.dumps(report))
