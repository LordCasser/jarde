#!/usr/bin/env python3
"""Root-run Jarde/JADX exact-source rebuild and isolated runtime matrix."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, shutil, sys, tarfile
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
COMPARE = ROOT / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_MANIFEST = ROOT / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
BASELINE_ARCHIVE = Path('/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-switch-case-nonlocal-exits/results/baseline-root-v1/capture.tar.gz')
BASELINE_REVIEW = BASELINE_ARCHIVE.parent / 'capture-review.json'
BASELINE_OUTPUT = Path('/private/tmp/jarde-switch-case-nonlocal-baseline-root-v1-20261018')
API_RECEIPT = Path('/private/tmp/jarde-switch-return-api-replay-root-v1-20261018/execution.json')
CLI_RECEIPT = Path('/private/tmp/jarde-switch-return-focused-root-v1-20261018/execution.json')
DRIVER_RECEIPT = Path('/private/tmp/jarde-switch-driver-original-root-v1-20261018/execution.json')
DRIVER_DIR = Path('/private/tmp/jarde-switch-nonlocal-runtime-driver-luna-v1-20261018')
DRIVER_SOURCE = DRIVER_DIR / 'SwitchNonlocalRuntimeDriver.java'
CLASSES = ('SN', 'SM', 'SL', 'LD')
LEGS = ('javac8', 'javac23')
EVIDENCE = ('default', 'all')
EXPECTED = {name: DRIVER_DIR / f'expected-{name}.txt' for name in CLASSES}
FREE_LIMIT = 5 * 1024**3
DEFAULT_OUT = Path('/private/tmp/jarde-switch-return-final-matrix-root-v1-20261018')
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha_bytes(data)}


def write_json(path: Path, doc) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    tmp.replace(path)


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def fresh_dir(path: Path) -> None:
    if path.exists():
        raise RuntimeError(f'refusing existing directory: {path}')
    path.mkdir(parents=True)


def tree_pins(root: Path) -> dict:
    return {p.relative_to(root).as_posix(): pin(p) for p in sorted(root.rglob('*')) if p.is_file()}


def method_order(doc: dict) -> list[tuple[str, str]]:
    return [(bytes(m['item']['identity']['name']).decode('utf-8'),
             bytes(m['item']['identity']['descriptor']).decode('utf-8')) for m in doc['methods']]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, default=DEFAULT_OUT)
    ap.add_argument('--cli-receipt', type=Path, default=CLI_RECEIPT)
    ap.add_argument('--api-replay', type=Path, default=API_RECEIPT)
    ap.add_argument('--baseline-archive', type=Path, default=BASELINE_ARCHIVE)
    ap.add_argument('--original-driver-receipt', type=Path, default=DRIVER_RECEIPT)
    args = ap.parse_args()
    root = ROOT.resolve(strict=True)
    out = args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing existing output directory: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('repository target must be absent before final rebuild matrix')
    if shutil.disk_usage(root).free < FREE_LIMIT:
        raise SystemExit('5 GiB free-space guard failed before run')

    compare = load(COMPARE, 'switch_final_matrix_compare_helpers')
    guard_path = root / GUARD_REL
    scanner_path = root / SCANNER_REL
    if sha_bytes(guard_path.read_bytes()) != GUARD_SHA or sha_bytes(scanner_path.read_bytes()) != SCANNER_SHA:
        raise SystemExit('pinned run guard/scanner source mismatch')
    if pin(JDK_MANIFEST)['sha256'] != JDK_MANIFEST_SHA:
        raise SystemExit('JDK manifest pin mismatch')
    jdks, jdk_record = compare.configured_jdks(JDK_MANIFEST, JDK_MANIFEST_SHA)

    cli_doc = json.loads(args.cli_receipt.read_text(encoding='utf-8'))
    if cli_doc.get('status') != 'commands_passed_pending_independent_acceptance' or not cli_doc.get('source_unchanged') or not cli_doc.get('target_absent'):
        raise SystemExit('final CLI build receipt failed source/target checks or is not complete')
    cli_pin = cli_doc.get('cli')
    if not isinstance(cli_pin, dict) or not {'path', 'bytes', 'sha256'} <= cli_pin.keys():
        raise SystemExit('CLI receipt has no complete executable pin')
    cli = Path(cli_pin['path']).resolve(strict=True)
    if pin(cli) != {'path': str(cli), 'bytes': cli_pin['bytes'], 'sha256': cli_pin['sha256']}:
        raise SystemExit('CLI receipt pin does not match executable')

    api_doc = json.loads(args.api_replay.read_text(encoding='utf-8'))
    if api_doc.get('schema') != 'switch-return-api-replay-v1' or api_doc.get('status') != 'complete_pending_independent_review':
        raise SystemExit('API replay receipt is not a complete captured 16-cell matrix')
    if api_doc.get('command_count') != 16 or len(api_doc.get('cells', [])) != 16:
        raise SystemExit('API replay does not contain exactly 16 cells/commands')
    api_cli = api_doc.get('focused_cli_from_receipt')
    if not isinstance(api_cli, dict) or (api_cli.get('path'), api_cli.get('bytes'), api_cli.get('sha256')) != (cli_pin.get('path'), cli_pin.get('bytes'), cli_pin.get('sha256')):
        raise SystemExit('API replay CLI pin differs from final CLI receipt')
    if not api_doc.get('inputs_unchanged') or not api_doc.get('source_pins_unchanged') or not api_doc.get('repository_target_absent_after'):
        raise SystemExit('API replay receipt has failed integrity/target checks')
    if len(api_doc.get('assertions', [])) != 22 or any(not x.get('passed') for x in api_doc.get('assertions', [])):
        raise SystemExit('API replay receipt did not pass all 22 method/parity assertions')
    api_cells = {(x['class_name'], x['input_leg'], x['evidence']): x for x in api_doc['cells']}
    expected_api_keys = {(c, leg, ev) for c in CLASSES for leg in LEGS for ev in EVIDENCE}
    if set(api_cells) != expected_api_keys:
        raise SystemExit('API replay cell identities are incomplete or duplicated')

    baseline_pin = pin(args.baseline_archive)
    review_path = args.baseline_archive.parent / 'capture-review.json'
    review_doc = json.loads(review_path.read_text(encoding='utf-8'))
    if (review_doc.get('archive_sha256'), review_doc.get('archive_bytes')) != (baseline_pin['sha256'], baseline_pin['bytes']):
        raise SystemExit('baseline archive does not match adjacent capture-review pin')
    driver_doc = json.loads(args.original_driver_receipt.read_text(encoding='utf-8'))
    if driver_doc.get('schema') != 'switch-nonlocal-original-driver-v1' or driver_doc.get('status') != 'complete_pending_independent_review':
        raise SystemExit('original 109-case driver receipt is not complete')
    if not driver_doc.get('source_pins_unchanged') or not driver_doc.get('inputs_unchanged') or not driver_doc.get('repository_target_absent_after'):
        raise SystemExit('original driver receipt failed its integrity/target checks')
    if driver_doc.get('total_runtime_case_invocations') != 436 or len(driver_doc.get('runtime_results', [])) != 16:
        raise SystemExit('original driver receipt does not establish the complete 109-case oracle')
    expected_bytes = {name: path.read_bytes() for name, path in EXPECTED.items()}
    expected_rows = {name: len(b.decode('utf-8', errors='strict').splitlines()) for name, b in expected_bytes.items()}
    driver_inputs = driver_doc.get('inputs_before', {})
    if driver_inputs.get('driver_source') != pin(DRIVER_SOURCE):
        raise SystemExit('fixed driver source differs from the original-driver receipt')
    for name, path in EXPECTED.items():
        if driver_inputs.get('expected_outputs', {}).get(name) != pin(path):
            raise SystemExit(f'fixed expected-output pin differs from the original-driver receipt: {name}')
    if driver_doc.get('matrix', {}).get('expected_rows_per_class') != expected_rows:
        raise SystemExit('fixed case counts differ from the original-driver receipt')
    expected_driver_keys = {(c, input_leg, runtime) for c in CLASSES for input_leg in LEGS for runtime in LEGS}
    actual_driver_keys = {(x['class_name'], x['input_compiler'], x['runtime_jvm']) for x in driver_doc['runtime_results']}
    if len(driver_doc['runtime_results']) != 16 or actual_driver_keys != expected_driver_keys:
        raise SystemExit('original driver receipt does not cover all class/input/runtime cells')
    if sum(expected_rows.values()) != 109:
        raise SystemExit('fixed case outputs do not define the 109-line oracle')
    driver_oracle_pins = {}
    for item in driver_doc['runtime_results']:
        if not item.get('matches_fixed_expected'):
            raise SystemExit('original driver receipt contains a mismatching oracle run')
        driver_command = driver_doc['commands'][item['command'] - 1]
        if driver_command.get('exit_code') != 0 or driver_command.get('guard_stop') is not None:
            raise SystemExit(f'original driver command failed: {item["class_name"]}/{item["input_compiler"]}/{item["runtime_jvm"]}')
        raw_path = Path(driver_command['streams']['stdout']['path'])
        raw = raw_path.read_bytes()
        driver_oracle_pins[f'{item["class_name"]}/{item["input_compiler"]}/{item["runtime_jvm"]}'] = pin(raw_path)
        if sha_bytes(raw) != item['stdout_sha256'] or raw != expected_bytes[item['class_name']]:
            raise SystemExit(f'original driver raw output pin/oracle mismatch: {item["class_name"]}')

    out.mkdir(parents=True)
    raw_dir = out / 'raw'
    raw_dir.mkdir()
    guard = load(guard_path, 'switch_final_matrix_root_guard')
    scanner = load(scanner_path, 'switch_final_matrix_root_scanner')
    guard.ROOT = root
    guard.OUT = raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = lambda p: compare.pin(p)
    guard.expected_test_summaries = lambda index, stdout: None

    source_before = compare.source_closure(root)
    driver_assets = {'driver_source': pin(DRIVER_SOURCE), 'case_table': pin(DRIVER_DIR / 'case-table.md'),
                     'expected_outputs': {n: pin(p) for n, p in EXPECTED.items()}}
    external_before = {
        'cli_receipt': pin(args.cli_receipt), 'cli': pin(cli), 'api_receipt': pin(args.api_replay),
        'baseline_archive': baseline_pin, 'baseline_capture_review': pin(review_path),
        'original_driver_receipt': pin(args.original_driver_receipt), 'driver_assets': driver_assets,
        'original_driver_oracle_outputs': driver_oracle_pins,
        'compare': pin(COMPARE), 'runner': pin(Path(__file__)), 'guard': pin(guard_path), 'scanner': pin(scanner_path),
        'jdk_manifest': pin(JDK_MANIFEST),
        'jdk_tools': {leg: {tool: pin(path) for tool, path in row['tools'].items()} for leg, row in jdks.items()},
    }
    result = {
        'schema': 'switch-return-three-party-rebuild-matrix-v1', 'status': 'running',
        'root': str(root), 'output': str(out), 'inputs_before': dict(external_before),
        'source_pins_before': source_before, 'jdk_manifest_record': jdk_record,
        'matrix': {
            'jarde_sources': 16, 'jadx_sources': 8, 'candidate_source_compiles': 48,
            'driver_compiles': 1, 'driver_runtime_commands_expected_if_all_compile': 96,
            'main_runtime_commands_expected_if_all_compile': 96,
            'class_case_rows_per_full_driver_run': expected_rows, 'case_rows_per_all_class_run': 109,
            'driver_case_invocations_expected_if_all_compile': 2616,
            'original_main_oracle': 'exact stdout bytes from the pinned complete baseline capture',
            'driver_case_oracle': 'exact expected-SN/SM/SL/LD bytes already exercised by the original-driver receipt',
        },
        'commands': [], 'source_artifacts': [], 'original_class_inputs': [], 'rebuilds': [],
        'runtime_results': [], 'notes': [
            'No source is truncated, edited, reformatted, or repaired. Jarde sources are exact complete class text from the 16-cell API replay; JADX sources are exact full source files from the baseline capture.',
            'All Jarde (4 classes x 2 original compiler inputs x 2 evidence settings) and JADX (4 x 2 original inputs) sources are compiled intact by both configured javac legs.',
            'Each successful rebuilt class is run on both configured JVMs with a separate target-independent driver root and exactly target-root plus driver-root on the driver classpath; each class main is also run on both JVMs.',
            'Compilation failures, runtime failures, and semantic mismatches are recorded as distinct outcomes with raw process streams; they do not erase later independent matrix cells.',
            'JADX wrong-code results, including LD, remain classified from exact driver output rather than being treated as collector failure.',
        ],
    }
    write_json(out / 'execution.json', result)
    commands = result['commands']
    source_paths = {}
    source_pins_before = {}
    input_class_paths = {}
    input_class_pins_before = {}
    baseline_original_oracles = {}
    baseline_class_records = {}
    jadx_records = {}
    source_specs = []
    api_source_inputs_before = {}

    env_base = compare.clean_env(dict(os.environ))
    env_base.pop('RUST_MIN_STACK', None)
    env_base.update(guard.ENV_VALUES)

    def command(label: str, argv: list[str], leg: str, phase: str) -> dict:
        if (root / 'target').exists() or (root / 'target').is_symlink():
            raise RuntimeError(f'repository target appeared before {label}')
        if shutil.disk_usage(root).free < FREE_LIMIT:
            raise RuntimeError(f'5 GiB free-space guard failed before {label}')
        env = compare.clean_env(env_base, jdks[leg])
        row = guard.run_command(len(commands) + 1, argv, env)
        row.update({'label': label, 'phase': phase, 'tool_leg': leg})
        commands.append(row)
        write_json(out / 'execution.json', result)
        if row.get('guard_stop') is not None:
            raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        return row

    def raw(row: dict, channel: str) -> bytes:
        return compare.command_artifact(row, channel)

    def compile_java(source: Path, class_name: str, leg: str, class_dir: Path, label: str,
                     phase: str = 'javac-full-source') -> dict:
        class_dir.parent.mkdir(parents=True, exist_ok=True)
        fresh_dir(class_dir)
        empty_cp = class_dir.parent / (class_dir.name + '-empty-classpath')
        empty_sp = class_dir.parent / (class_dir.name + '-empty-sourcepath')
        fresh_dir(empty_cp)
        fresh_dir(empty_sp)
        profile = ['-source', '8', '-target', '8'] if leg == 'javac8' else ['--release', '8']
        flags = [*profile, '-g', '-encoding', 'UTF-8', '-Xlint:-options', '-proc:none',
                 '-classpath', str(empty_cp), '-sourcepath', str(empty_sp), '-d', str(class_dir)]
        return command(label, [str(jdks[leg]['tools']['javac']), *flags, str(source)], leg, phase)

    def save_source(kind: str, class_name: str, input_leg: str, evidence: str, source_bytes: bytes, origin: dict) -> dict:
        path = out / 'sources' / kind / class_name / input_leg / evidence / f'{class_name}.java'
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(source_bytes)
        if path.read_bytes() != source_bytes:
            raise RuntimeError(f'source bytes changed while saving {kind}/{class_name}/{input_leg}/{evidence}')
        record = {'kind': kind, 'class_name': class_name, 'input_leg': input_leg, 'evidence': evidence,
                  'path': pin(path), 'origin': origin}
        source_paths[(kind, class_name, input_leg, evidence)] = path
        source_pins_before[f'{kind}/{class_name}/{input_leg}/{evidence}'] = record['path']
        result['source_artifacts'].append(record)
        return record

    def copy_baseline_inputs() -> None:
        with tarfile.open(args.baseline_archive, 'r:gz') as tf:
            baseline = json.load(tf.extractfile('execution.json'))
            if baseline.get('schema') != 'switch-case-nonlocal-baseline-v1' or baseline.get('status') != 'complete_pending_independent_review':
                raise RuntimeError('baseline archive has no complete original/JADX receipt')
            if not baseline.get('source_pins_unchanged') or not baseline.get('inputs_unchanged') or not baseline.get('repository_target_absent_after'):
                raise RuntimeError('baseline original/JADX receipt failed its integrity/target checks')
            if len(baseline.get('original_oracles', [])) != 16 or len(baseline.get('jadx_cells', [])) != 8:
                raise RuntimeError('baseline archive is missing original main/JADX matrix cells')
            expected_main_keys = {(c, input_leg, runtime) for c in CLASSES for input_leg in LEGS for runtime in LEGS}
            actual_main_keys = {(x['class_name'], x['input_compiler'], x['runtime']) for x in baseline['original_oracles']}
            if actual_main_keys != expected_main_keys:
                raise RuntimeError('baseline original main oracles do not cover all class/input/runtime cells')
            expected_class_keys = {(c, leg) for c in CLASSES for leg in LEGS}
            if len(baseline.get('original_classes', [])) != 8 or {(x['class_name'], x['compiler']) for x in baseline['original_classes']} != expected_class_keys:
                raise RuntimeError('baseline original class inputs do not cover all eight class/compiler cells')
            if {(x['class_name'], x['input_compiler']) for x in baseline['jadx_cells']} != expected_class_keys:
                raise RuntimeError('baseline JADX source cells do not cover all eight class/compiler cells')
            baseline_class_records.update({(x['class_name'], x['compiler']): x for x in baseline['original_classes']})
            for row in baseline['original_oracles']:
                key = (row['class_name'], row['input_compiler'], row['runtime'])
                member = f'raw/{row["command"]}.stdout.raw'
                command_row = baseline['commands'][row['command'] - 1]
                if command_row.get('exit_code') != 0 or command_row.get('guard_stop') is not None:
                    raise RuntimeError(f'original main oracle command failed: {key}')
                data = tf.extractfile(member).read()
                if len(data) != row['stdout_bytes'] or sha_bytes(data) != row['stdout_sha256']:
                    raise RuntimeError(f'original main oracle raw pin mismatch: {key}')
                baseline_original_oracles[key] = data
            for class_name in CLASSES:
                for leg in LEGS:
                    rec = baseline_class_records[(class_name, leg)]['class']
                    member = f'original-classes/{class_name}/{leg}/{class_name}.class'
                    data = tf.extractfile(member).read()
                    if len(data) != rec['bytes'] or sha_bytes(data) != rec['sha256']:
                        raise RuntimeError(f'baseline original class pin mismatch: {member}')
                    path = out / 'inputs' / member
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_bytes(data)
                    input_class_paths[(class_name, leg)] = path
                    input_class_pins_before[f'{class_name}/{leg}'] = pin(path)
            outroot = Path(baseline['output'])
            for item in baseline['jadx_cells']:
                name, leg = item['class_name'], item['input_compiler']
                source_rec = item.get('source')
                if not source_rec:
                    raise RuntimeError(f'baseline JADX text missing: {name}/{leg}')
                source_path = Path(source_rec['path'])
                member = source_path.relative_to(outroot).as_posix()
                data = tf.extractfile(member).read()
                if len(data) != source_rec['bytes'] or sha_bytes(data) != source_rec['sha256']:
                    raise RuntimeError(f'baseline JADX text pin mismatch: {member}')
                jadx_records[(name, leg)] = {'bytes': data, 'member': member, 'source_record': source_rec,
                                             'cell': item}
        for key, cell in api_cells.items():
            if not cell.get('full_class_text_matches_json_utf8') or not cell.get('full_class_text'):
                raise RuntimeError(f'API cell lacks an exact full-class text artifact: {key}')
            source_pin = cell['full_class_text']
            source_path = Path(source_pin['path'])
            data = source_path.read_bytes()
            json_path = Path(cell['json_artifact']['path'])
            actual_text_pin = pin(source_path)
            actual_json_pin = pin(json_path)
            if actual_text_pin != source_pin:
                raise RuntimeError(f'API full-source artifact pin differs from receipt: {key}')
            if actual_json_pin != cell['json_artifact']:
                raise RuntimeError(f'API JSON artifact pin differs from receipt: {key}')
            api_source_inputs_before[f'{key[0]}/{key[1]}/{key[2]}'] = {
                'full_class_text': actual_text_pin, 'json': actual_json_pin}
            doc = json.loads(json_path.read_text(encoding='utf-8'))
            text = doc.get('text')
            if not isinstance(text, str) or text.encode('utf-8') != data:
                raise RuntimeError(f'API full source text does not match its JSON: {key}')
            if len(data) != source_pin['bytes'] or sha_bytes(data) != source_pin['sha256']:
                raise RuntimeError(f'API full source text pin mismatch: {key}')
            class_key = (key[0], key[1])
            original_class = baseline_class_records[class_key]['class']
            if (cell['input_class']['bytes'], cell['input_class']['sha256']) != (original_class['bytes'], original_class['sha256']):
                raise RuntimeError(f'API input class is not the frozen original byte sequence: {key}')
            source_specs.append(('jarde', key[0], key[1], key[2], data,
                                 {'api_command': cell['command'], 'api_exit_code': cell['exit_code'],
                                  'api_text_pin': source_pin, 'json_pin': cell['json_artifact'],
                                  'input_class': cell['input_class']}))
        for (name, leg), rec in sorted(jadx_records.items()):
            source_specs.append(('jadx', name, leg, 'full', rec['bytes'],
                                 {'archive_member': rec['member'], 'source_record': rec['source_record'],
                                  'baseline_exit_code': rec['cell']['exit_code']}))
        if len(source_specs) != 24:
            raise RuntimeError(f'expected 24 complete source inputs, got {len(source_specs)}')
        for kind, name, leg, evidence, data, origin in source_specs:
            save_source(kind, name, leg, evidence, data, origin)
        result['original_class_inputs'] = [
            {'class_name': c, 'input_leg': leg, 'pin': input_class_pins_before[f'{c}/{leg}'],
             'class_facts': compare.parse_class(input_class_paths[(c, leg)])}
            for c in CLASSES for leg in LEGS]
        external_before['api_source_artifacts'] = api_source_inputs_before
        result['inputs_before']['original_classes'] = input_class_pins_before
        result['inputs_before']['api_source_artifacts'] = api_source_inputs_before
        result['source_artifacts_before'] = source_pins_before
        write_json(out / 'execution.json', result)
        return baseline

    def classify_runtime(row: dict, stdout: bytes, expected: bytes) -> str:
        if row.get('exit_code') != 0:
            return 'runtime_failure'
        if stdout != expected:
            return 'semantic_mismatch'
        return 'exact_match'

    def run_rebuilds() -> None:
        # Compile the target-independent driver separately from every target class root.
        driver_dir = out / 'driver-classes'
        driver_src = out / 'driver-source' / DRIVER_SOURCE.name
        driver_src.parent.mkdir(parents=True, exist_ok=True)
        driver_bytes = DRIVER_SOURCE.read_bytes()
        driver_src.write_bytes(driver_bytes)
        if driver_src.read_bytes() != driver_bytes:
            raise RuntimeError('driver source copy changed')
        driver_compile = compile_java(driver_src, 'SwitchNonlocalRuntimeDriver', 'javac8', driver_dir,
                                      'driver-compile-javac8', phase='driver-source-compile')
        driver_class_before = tree_pins(driver_dir)
        if driver_compile.get('exit_code') != 0 or 'SwitchNonlocalRuntimeDriver.class' not in driver_class_before:
            raise RuntimeError('fixed 109-case driver did not compile')
        result['driver'] = {'source': pin(driver_src), 'compile_command': driver_compile['index'],
                            'classes_before_runtime': driver_class_before}
        write_json(out / 'execution.json', result)
        runtime_case_rows = 0
        for kind, class_name, input_leg, evidence, _data, _origin in source_specs:
            source_path = source_paths[(kind, class_name, input_leg, evidence)]
            source_pin_before = pin(source_path)
            class_dir = out / 'rebuilt-classes' / kind / class_name / input_leg / evidence
            for build_leg in LEGS:
                label = f'{kind}-{class_name}-{input_leg}-{evidence}-{build_leg}'
                compile_row = compile_java(source_path, class_name, build_leg, class_dir / build_leg,
                                           f'{label}-compile')
                classes_before = tree_pins(class_dir / build_leg) if (class_dir / build_leg).is_dir() else {}
                class_file = class_dir / build_leg / f'{class_name}.class'
                compile_exit = compile_row.get('exit_code')
                compile_classification = ('compiled' if compile_exit == 0 and class_file.is_file()
                                          else ('missing_expected_class' if compile_exit == 0 else 'compile_failure'))
                rebuild = {'kind': kind, 'class_name': class_name, 'input_leg': input_leg,
                           'evidence': evidence, 'build_leg': build_leg,
                           'source': source_pin_before, 'compile_command': compile_row['index'],
                           'compile_exit_code': compile_exit, 'compile_classification': compile_classification,
                           'compiler_stdout_sha256': compile_row['streams']['stdout']['sha256'],
                           'compiler_stderr_sha256': compile_row['streams']['stderr']['sha256'],
                           'classes_before_runtime': classes_before, 'driver_runs': [], 'main_runs': []}
                if compile_classification == 'compiled':
                    target_root = (class_dir / build_leg).resolve(strict=True)
                    driver_root = driver_dir.resolve(strict=True)
                    classpath = os.pathsep.join((str(target_root), str(driver_root)))
                    for runtime_leg in LEGS:
                        before_target = tree_pins(target_root)
                        before_driver = tree_pins(driver_root)
                        dr = command(f'{label}-{runtime_leg}-driver',
                                     [str(jdks[runtime_leg]['tools']['java']), '-Xverify:all', '-cp', classpath,
                                      'SwitchNonlocalRuntimeDriver', class_name, str(target_root)],
                                     runtime_leg, 'rebuilt-only-109-case-driver')
                        driver_stdout = raw(dr, 'stdout')
                        raw(dr, 'stderr')
                        status = classify_runtime(dr, driver_stdout, expected_bytes[class_name])
                        if kind == 'jadx' and class_name == 'LD' and status == 'semantic_mismatch':
                            status = 'jadx_ld_wrong_code'
                        lines = len(driver_stdout.decode('utf-8', errors='replace').splitlines())
                        runtime_case_rows += lines
                        after_target = tree_pins(target_root)
                        after_driver = tree_pins(driver_root)
                        driver_unchanged = before_target == after_target and before_driver == after_driver
                        if not driver_unchanged:
                            raise RuntimeError(f'compiled class/driver changed during runtime: {label}/{runtime_leg}')
                        rebuild['driver_runs'].append({
                            'runtime_leg': runtime_leg, 'command': dr['index'], 'exit_code': dr.get('exit_code'),
                            'classification': status, 'stdout': dr['streams']['stdout'], 'stderr': dr['streams']['stderr'],
                            'expected_case_lines': expected_rows[class_name], 'actual_case_lines': lines,
                            'matches_109_case_class_oracle': status == 'exact_match',
                            'target_class_pins_before_after': {'before': before_target, 'after': after_target},
                            'driver_class_pins_before_after': {'before': before_driver, 'after': after_driver},
                        })
                        before_main_target = tree_pins(target_root)
                        mr = command(f'{label}-{runtime_leg}-main',
                                     [str(jdks[runtime_leg]['tools']['java']), '-Xverify:all', '-cp', str(target_root), class_name],
                                     runtime_leg, 'rebuilt-class-main')
                        main_stdout = raw(mr, 'stdout')
                        raw(mr, 'stderr')
                        after_main_target = tree_pins(target_root)
                        if before_main_target != after_main_target:
                            raise RuntimeError(f'compiled class changed during main run: {label}/{runtime_leg}')
                        expected_main = baseline_original_oracles[(class_name, input_leg, runtime_leg)]
                        main_status = classify_runtime(mr, main_stdout, expected_main)
                        if kind == 'jadx' and class_name == 'LD' and main_status == 'semantic_mismatch':
                            main_status = 'jadx_ld_main_wrong_code'
                        rebuild['main_runs'].append({
                            'runtime_leg': runtime_leg, 'command': mr['index'], 'exit_code': mr.get('exit_code'),
                            'classification': main_status, 'stdout': mr['streams']['stdout'], 'stderr': mr['streams']['stderr'],
                            'original_main_oracle_sha256': sha_bytes(expected_main),
                            'matches_original_main_oracle': main_status == 'exact_match',
                            'target_class_pins_before_after': {'before': before_main_target, 'after': after_main_target},
                        })
                        if pin(source_path) != source_pin_before:
                            raise RuntimeError(f'generated source changed during runtime: {label}/{runtime_leg}')
                rebuild['classes_after_runtime'] = tree_pins(class_dir / build_leg) if (class_dir / build_leg).is_dir() else {}
                rebuild['source_after_runtime'] = pin(source_path)
                if rebuild['classes_after_runtime'] != classes_before or rebuild['source_after_runtime'] != source_pin_before:
                    raise RuntimeError(f'class/source pin changed for {label}')
                result['rebuilds'].append(rebuild)
                write_json(out / 'execution.json', result)
        result['observed_driver_output_lines'] = runtime_case_rows

    baseline = None
    try:
        baseline = copy_baseline_inputs()
        run_rebuilds()
        result['status'] = 'complete_pending_independent_review'
    except BaseException as exc:
        result['status'] = 'interrupted'
        result['failure'] = f'{type(exc).__name__}: {exc}'
        raise
    finally:
        result['source_pins_after'] = compare.source_closure(root)
        result['source_pins_unchanged'] = result['source_pins_after'] == result['source_pins_before']
        api_source_inputs_after = {}
        for key, pair in api_source_inputs_before.items():
            api_source_inputs_after[key] = {
                'full_class_text': pin(Path(pair['full_class_text']['path'])) if Path(pair['full_class_text']['path']).is_file() else None,
                'json': pin(Path(pair['json']['path'])) if Path(pair['json']['path']).is_file() else None,
            }
        result['external_inputs_after'] = {
            'cli_receipt': pin(args.cli_receipt), 'cli': pin(cli), 'api_receipt': pin(args.api_replay),
            'baseline_archive': pin(args.baseline_archive), 'baseline_capture_review': pin(review_path),
            'original_driver_receipt': pin(args.original_driver_receipt),
            'original_driver_oracle_outputs': {k: pin(Path(v['path'])) for k, v in driver_oracle_pins.items()},
            'api_source_artifacts': api_source_inputs_after,
            'driver_assets': {'driver_source': pin(DRIVER_SOURCE), 'case_table': pin(DRIVER_DIR / 'case-table.md'),
                              'expected_outputs': {n: pin(p) for n, p in EXPECTED.items()}},
            'compare': pin(COMPARE), 'runner': pin(Path(__file__)), 'guard': pin(guard_path), 'scanner': pin(scanner_path),
            'jdk_manifest': pin(JDK_MANIFEST),
            'jdk_tools': {leg: {tool: pin(path) for tool, path in row['tools'].items()} for leg, row in jdks.items()},
        }
        result['inputs_after'] = dict(result['external_inputs_after'])
        result['inputs_after']['original_classes'] = {f'{c}/{leg}': pin(p) for (c, leg), p in input_class_paths.items() if p.is_file()}
        missing_class_inputs = [f'{c}/{l}' for (c, l), p in input_class_paths.items() if not p.is_file()]
        result['original_class_inputs_missing'] = missing_class_inputs
        source_after = {f'{kind}/{c}/{leg}/{evidence}': pin(p)
                        for (kind, c, leg, evidence), p in source_paths.items() if p.is_file()}
        missing_sources = [f'{kind}/{c}/{leg}/{evidence}'
                           for (kind, c, leg, evidence), p in source_paths.items() if not p.is_file()]
        result['source_artifacts_after'] = source_after
        result['source_artifacts_missing'] = missing_sources
        result['source_artifacts_unchanged'] = not missing_sources and source_after == source_pins_before
        result['inputs_unchanged'] = (result['external_inputs_after'] == external_before
                                      and result['inputs_after']['original_classes'] == input_class_pins_before
                                      and not missing_class_inputs)
        driver_source_copy = out / 'driver-source' / DRIVER_SOURCE.name
        result['driver_source_copy_after'] = pin(driver_source_copy) if driver_source_copy.is_file() else None
        result['driver_source_copy_unchanged'] = ('driver' in result and
            result['driver_source_copy_after'] == result['driver'].get('source'))
        result['driver_classes_after'] = tree_pins(out / 'driver-classes') if (out / 'driver-classes').is_dir() else {}
        if 'driver' in result:
            result['driver_classes_unchanged'] = result['driver_classes_after'] == result['driver']['classes_before_runtime']
        else:
            result['driver_classes_unchanged'] = False
        result['repository_target_absent_after'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
        result['source_pins_after'] = compare.source_closure(root)
        result['source_pins_unchanged'] = result['source_pins_after'] == result['source_pins_before']
        result['command_count'] = len(commands)
        result['target_source_compile_count'] = sum(1 for c in commands if c.get('phase') == 'javac-full-source')
        result['driver_source_compile_count'] = sum(1 for c in commands if c.get('phase') == 'driver-source-compile')
        result['driver_runtime_count'] = sum(len(x['driver_runs']) for x in result['rebuilds'])
        result['main_runtime_count'] = sum(len(x['main_runs']) for x in result['rebuilds'])
        result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        failures = []
        if not result['source_pins_unchanged']: failures.append('repository source pins changed')
        if not result['inputs_unchanged']: failures.append('external or original-class input pins changed')
        if not result['source_artifacts_unchanged']: failures.append('generated source pins changed or missing')
        if not result['driver_classes_unchanged']: failures.append('driver class pins changed or missing')
        if not result['driver_source_copy_unchanged']: failures.append('copied driver source changed or missing')
        if missing_class_inputs: failures.append('original class input is missing')
        if not result['repository_target_absent_after']: failures.append('repository target is present after run')
        if failures:
            result['status'] = 'interrupted'
            result['integrity_failures'] = failures
        write_json(out / 'execution.json', result)
    if result['status'] != 'complete_pending_independent_review':
        raise RuntimeError(result.get('failure', 'final integrity audit failed'))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        raise SystemExit(f'final rebuild matrix collector failed: {type(exc).__name__}: {exc}')
