# Fixed runtime cases

The Java driver enforces these values and prints one stable row per method/input. Null rows compare only the exception class.

| Fixture | Method | Case | Input | Expected |
|---|---|---|---|---|
| SN | retInSwitchNoTail | empty | [] | returns 0 |
| SN | retInSwitchNoTail | null | null | throws java.lang.NullPointerException |
| SN | retInSwitchNoTail | case1 | [1] | returns 1 |
| SN | retInSwitchNoTail | case2 | [2] | returns 2 |
| SN | retInSwitchNoTail | case3 | [3] | returns 100 |
| SN | retInSwitchNoTail | case4 | [4] | returns 4 |
| SN | retInSwitchNoTail | case5 | [5] | returns 5 |
| SN | retInSwitchNoTail | prefixReturn | [1, 2, 3, 4] | returns 103 |
| SN | retInSwitchNoTail | prefixDefault | [1, 2] | returns 3 |
| SN | retInSwitchTail | empty | [] | returns 0 |
| SN | retInSwitchTail | null | null | throws java.lang.NullPointerException |
| SN | retInSwitchTail | case1 | [1] | returns 11 |
| SN | retInSwitchTail | case2 | [2] | returns 12 |
| SN | retInSwitchTail | case3 | [3] | returns 100 |
| SN | retInSwitchTail | case4 | [4] | returns 14 |
| SN | retInSwitchTail | case5 | [5] | returns 15 |
| SN | retInSwitchTail | prefixReturn | [1, 2, 3, 4] | returns 123 |
| SN | retInSwitchTail | prefixDefault | [1, 2, 4] | returns 37 |
| SN | retAfterTail | empty | [] | returns 0 |
| SN | retAfterTail | null | null | throws java.lang.NullPointerException |
| SN | retAfterTail | case1 | [1] | returns 11 |
| SN | retAfterTail | case2 | [2] | returns 12 |
| SN | retAfterTail | case3 | [3] | returns 100 |
| SN | retAfterTail | case4 | [4] | returns 14 |
| SN | retAfterTail | case5 | [5] | returns 15 |
| SN | retAfterTail | prefixReturn | [1, 2, 3, 4] | returns 123 |
| SN | retAfterTail | prefixDefault | [1, 2, 4] | returns 37 |
| SN | labBreak | empty | [] | returns 0 |
| SN | labBreak | null | null | throws java.lang.NullPointerException |
| SN | labBreak | case1 | [1] | returns 1 |
| SN | labBreak | case2 | [2] | returns 2 |
| SN | labBreak | case3 | [3] | returns 3 |
| SN | labBreak | case4 | [4] | returns 4 |
| SN | labBreak | case5 | [5] | returns 0 |
| SN | labBreak | ledgerBreak | [9, 1, 5] | returns 10 |
| SN | labBreak | prefixBreak | [9, 1, 5, 7] | returns 10 |
| SN | labBreak | prefixDefault | [1, 2, 4] | returns 7 |
| SM | onlyBreak | empty | [] | returns 0 |
| SM | onlyBreak | null | null | throws java.lang.NullPointerException |
| SM | onlyBreak | case1 | [1] | returns 10 |
| SM | onlyBreak | case2 | [2] | returns 12 |
| SM | onlyBreak | case3 | [3] | returns 13 |
| SM | onlyBreak | case4 | [4] | returns 14 |
| SM | onlyBreak | case5 | [5] | returns 15 |
| SM | onlyBreak | prefixTail | [4, 1, 2] | returns 36 |
| SM | onlyContinue | empty | [] | returns 0 |
| SM | onlyContinue | null | null | throws java.lang.NullPointerException |
| SM | onlyContinue | case1 | [1] | returns 1 |
| SM | onlyContinue | case2 | [2] | returns 0 |
| SM | onlyContinue | case3 | [3] | returns 3 |
| SM | onlyContinue | case4 | [4] | returns 4 |
| SM | onlyContinue | case5 | [5] | returns 5 |
| SM | onlyContinue | prefixContinue | [4, 1, 2] | returns 5 |
| SM | onlyContinue | prefixMixed | [1, 2, 4] | returns 5 |
| SM | breakNoTail | empty | [] | returns 0 |
| SM | breakNoTail | null | null | throws java.lang.NullPointerException |
| SM | breakNoTail | case1 | [1] | returns 0 |
| SM | breakNoTail | case2 | [2] | returns 2 |
| SM | breakNoTail | case3 | [3] | returns 3 |
| SM | breakNoTail | case4 | [4] | returns 4 |
| SM | breakNoTail | case5 | [5] | returns 5 |
| SM | breakNoTail | prefixTail | [4, 1, 2] | returns 6 |
| SM | ifVersion | empty | [] | returns 0 |
| SM | ifVersion | null | null | throws java.lang.NullPointerException |
| SM | ifVersion | case1 | [1] | returns 10 |
| SM | ifVersion | case2 | [2] | returns 12 |
| SM | ifVersion | case3 | [3] | returns 13 |
| SM | ifVersion | case4 | [4] | returns 14 |
| SM | ifVersion | case5 | [5] | returns 15 |
| SM | ifVersion | prefixTail | [4, 1, 2] | returns 36 |
| SM | noTailMix | empty | [] | returns 0 |
| SM | noTailMix | null | null | throws java.lang.NullPointerException |
| SM | noTailMix | case1 | [1] | returns 0 |
| SM | noTailMix | case2 | [2] | returns 0 |
| SM | noTailMix | case3 | [3] | returns 3 |
| SM | noTailMix | case4 | [4] | returns 4 |
| SM | noTailMix | case5 | [5] | returns 5 |
| SM | noTailMix | prefixMixed | [4, 1, 2] | returns 4 |
| SM | noTailMix | prefixMixed2 | [1, 2, 4] | returns 4 |
| SL | mixed | empty | [] | returns 0 |
| SL | mixed | null | null | throws java.lang.NullPointerException |
| SL | mixed | case1 | [1] | returns 10 |
| SL | mixed | case2 | [2] | returns 0 |
| SL | mixed | case3 | [3] | returns 100 |
| SL | mixed | case4 | [4] | returns 14 |
| SL | mixed | case5 | [5] | returns 15 |
| SL | mixed | prefixReturn | [1, 2, 4, 3] | returns 124 |
| SL | mixed | prefixNoReturn | [1, 4, 2] | returns 24 |
| SL | mixed | prefixReturn2 | [4, 3] | returns 114 |
| SL | labeledBreak | empty | [] | returns 0 |
| SL | labeledBreak | null | null | throws java.lang.NullPointerException |
| SL | labeledBreak | case1 | [1] | returns 1 |
| SL | labeledBreak | case2 | [2] | returns 2 |
| SL | labeledBreak | case3 | [3] | returns 3 |
| SL | labeledBreak | case4 | [4] | returns 4 |
| SL | labeledBreak | case5 | [5] | returns 0 |
| SL | labeledBreak | ledgerBreak | [9, 1, 5] | returns 10 |
| SL | labeledBreak | prefixBreak | [9, 1, 5, 7] | returns 10 |
| SL | labeledBreak | prefixNoBreak | [9, 1, 2] | returns 12 |
| LD | lab | empty | [] | returns 0 |
| LD | lab | null | null | throws java.lang.NullPointerException |
| LD | lab | case1 | [1] | returns 1 |
| LD | lab | case2 | [2] | returns 2 |
| LD | lab | case3 | [3] | returns 3 |
| LD | lab | case4 | [4] | returns 4 |
| LD | lab | case5 | [5] | returns 0 |
| LD | lab | ledgerBreak | [9, 1, 5] | returns 10 |
| LD | lab | prefixBreak | [9, 1, 5, 7] | returns 10 |
| LD | lab | prefixNoBreak | [9, 1, 2] | returns 12 |
