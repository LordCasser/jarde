# Switch non-local exit runtime driver

SwitchNonlocalRuntimeDriver.java is an external, Java 8-compatible reflection harness for the SN, SM, SL, and LD fixture classes. It does not import or compile against target classes. It accepts exactly two arguments: the target binary class name (SN, SM, SL, or LD) and the canonical directory containing that class file.

At startup it resolves the target class without initialization, verifies its ProtectionDomain CodeSource against the supplied canonical root, confirms the driver is loaded from a different root, and requires the runtime classpath to contain exactly those two roots. This catches accidental loading from an old fixture or ambient class directory. Keep the driver classes in their own directory.

The fixed input/result matrix is in case-table.md; expected-SN.txt, expected-SM.txt, expected-SL.txt, and expected-LD.txt are byte-for-byte stdout oracles. The null-input row checks only java.lang.NullPointerException; its message is deliberately ignored because compilers may include different local-variable names.

Compile only the driver into an empty directory (for example, with a Java 8 compiler, or a newer compiler using Java 8 source/target settings). Do not put target roots on the driver compilation classpath. For each original and rebuilt class root, run with exactly the target root and driver root on the classpath:

    java -cp "$CLASS_ROOT:$DRIVER_ROOT" SwitchNonlocalRuntimeDriver SN "$CLASS_ROOT" > actual-SN.txt
    diff -u expected-SN.txt actual-SN.txt

Repeat for SM, SL, and LD, and for each original/rebuilt root. Compare each rebuilt output to its original output line by line as well as to the corresponding expected file. In particular, the oracle fixes SL.mixed prefixReturn to 124 for input [1, 2, 4, 3] and LD.lab prefixBreak to 10 for [9, 1, 5, 7]. The driver performs no target transformation and does not delete or rewrite fixture methods.
