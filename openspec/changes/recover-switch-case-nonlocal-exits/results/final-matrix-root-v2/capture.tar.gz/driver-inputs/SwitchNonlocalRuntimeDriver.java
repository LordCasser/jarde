import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URI;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Java 8 compatible, target-independent runtime oracle for switch non-local exits. */
public final class SwitchNonlocalRuntimeDriver {
    private static final class TestCase {
        final String name;
        final int[] input;
        final Integer expectedValue;
        final String expectedException;

        TestCase(String name, int[] input, Integer expectedValue, String expectedException) {
            this.name = name;
            this.input = input;
            this.expectedValue = expectedValue;
            this.expectedException = expectedException;
        }
    }

    private static TestCase value(String name, int expected, int... input) {
        return new TestCase(name, input, Integer.valueOf(expected), null);
    }

    private static TestCase nullArray() {
        return new TestCase("null", null, null, "java.lang.NullPointerException");
    }

    private static TestCase[] cases(TestCase... values) {
        return values;
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            throw new IllegalArgumentException("usage: SwitchNonlocalRuntimeDriver <SN|SM|SL|LD> <canonical-class-root>");
        }
        String className = args[0];
        if (!("SN".equals(className) || "SM".equals(className) || "SL".equals(className) || "LD".equals(className))) {
            throw new IllegalArgumentException("unsupported fixture class: " + className);
        }
        Path expectedRoot = Paths.get(args[1]).toRealPath();
        Path driverRoot = codeSourceRoot(SwitchNonlocalRuntimeDriver.class);
        if (expectedRoot.equals(driverRoot)) {
            throw new IllegalStateException("target and driver must use separate class roots");
        }
        verifyClasspath(expectedRoot, driverRoot);

        Class<?> target = Class.forName(className, false, ClassLoader.getSystemClassLoader());
        Path actualRoot = codeSourceRoot(target);
        if (!expectedRoot.equals(actualRoot)) {
            throw new IllegalStateException("target CodeSource mismatch: expected " + expectedRoot + " but got " + actualRoot);
        }
        runFixture(className, target);
    }

    private static Path codeSourceRoot(Class<?> type) throws Exception {
        CodeSource source = type.getProtectionDomain().getCodeSource();
        if (source == null || source.getLocation() == null) {
            throw new IllegalStateException("missing CodeSource for " + type.getName());
        }
        URI uri = source.getLocation().toURI();
        return Paths.get(uri).toRealPath();
    }

    private static void verifyClasspath(Path targetRoot, Path driverRoot) throws Exception {
        String value = System.getProperty("java.class.path");
        String[] entries = value.split(Pattern.quote(File.pathSeparator), -1);
        if (entries.length != 2) {
            throw new IllegalStateException("classpath must contain exactly target-root and driver-root");
        }
        List<Path> roots = new ArrayList<Path>();
        for (String entry : entries) {
            roots.add(Paths.get(entry).toRealPath());
        }
        if (!roots.contains(targetRoot) || !roots.contains(driverRoot)) {
            throw new IllegalStateException("classpath roots do not match target and driver CodeSources");
        }
    }

    private static void runFixture(String className, Class<?> target) throws Exception {
        switch (className) {
            case "SN":
                runMethod(className, target, "retInSwitchNoTail", cases(
                    value("empty", 0),
                    nullArray(),
                    value("case1", 1, 1),
                    value("case2", 2, 2),
                    value("case3", 100, 3),
                    value("case4", 4, 4),
                    value("case5", 5, 5),
                    value("prefixReturn", 103, 1, 2, 3, 4),
                    value("prefixDefault", 3, 1, 2)
                ));
                runMethod(className, target, "retInSwitchTail", cases(
                    value("empty", 0),
                    nullArray(),
                    value("case1", 11, 1),
                    value("case2", 12, 2),
                    value("case3", 100, 3),
                    value("case4", 14, 4),
                    value("case5", 15, 5),
                    value("prefixReturn", 123, 1, 2, 3, 4),
                    value("prefixDefault", 37, 1, 2, 4)
                ));
                runMethod(className, target, "retAfterTail", cases(
                    value("empty", 0),
                    nullArray(),
                    value("case1", 11, 1),
                    value("case2", 12, 2),
                    value("case3", 100, 3),
                    value("case4", 14, 4),
                    value("case5", 15, 5),
                    value("prefixReturn", 123, 1, 2, 3, 4),
                    value("prefixDefault", 37, 1, 2, 4)
                ));
                runMethod(className, target, "labBreak", cases(
                    value("empty", 0),
                    nullArray(),
                    value("case1", 1, 1),
                    value("case2", 2, 2),
                    value("case3", 3, 3),
                    value("case4", 4, 4),
                    value("case5", 0, 5),
                    value("ledgerBreak", 10, 9, 1, 5),
                    value("prefixBreak", 10, 9, 1, 5, 7),
                    value("prefixDefault", 7, 1, 2, 4)
                ));
                break;
            case "SM":
                runMethod(className, target, "onlyBreak", cases(
                    value("empty", 0),
                    nullArray(),
                    value("case1", 10, 1),
                    value("case2", 12, 2),
                    value("case3", 13, 3),
                    value("case4", 14, 4),
                    value("case5", 15, 5),
                    value("prefixTail", 36, 4, 1, 2)
                ));
                runMethod(className, target, "onlyContinue", cases(
                    value("empty", 0),
                    nullArray(),
                    value("case1", 1, 1),
                    value("case2", 0, 2),
                    value("case3", 3, 3),
                    value("case4", 4, 4),
                    value("case5", 5, 5),
                    value("prefixContinue", 5, 4, 1, 2),
                    value("prefixMixed", 5, 1, 2, 4)
                ));
                runMethod(className, target, "breakNoTail", cases(
                    value("empty", 0),
                    nullArray(),
                    value("case1", 0, 1),
                    value("case2", 2, 2),
                    value("case3", 3, 3),
                    value("case4", 4, 4),
                    value("case5", 5, 5),
                    value("prefixTail", 6, 4, 1, 2)
                ));
                runMethod(className, target, "ifVersion", cases(
                    value("empty", 0),
                    nullArray(),
                    value("case1", 10, 1),
                    value("case2", 12, 2),
                    value("case3", 13, 3),
                    value("case4", 14, 4),
                    value("case5", 15, 5),
                    value("prefixTail", 36, 4, 1, 2)
                ));
                runMethod(className, target, "noTailMix", cases(
                    value("empty", 0),
                    nullArray(),
                    value("case1", 0, 1),
                    value("case2", 0, 2),
                    value("case3", 3, 3),
                    value("case4", 4, 4),
                    value("case5", 5, 5),
                    value("prefixMixed", 4, 4, 1, 2),
                    value("prefixMixed2", 4, 1, 2, 4)
                ));
                break;
            case "SL":
                runMethod(className, target, "mixed", cases(
                    value("empty", 0),
                    nullArray(),
                    value("case1", 10, 1),
                    value("case2", 0, 2),
                    value("case3", 100, 3),
                    value("case4", 14, 4),
                    value("case5", 15, 5),
                    value("prefixReturn", 124, 1, 2, 4, 3),
                    value("prefixNoReturn", 24, 1, 4, 2),
                    value("prefixReturn2", 114, 4, 3)
                ));
                runMethod(className, target, "labeledBreak", cases(
                    value("empty", 0),
                    nullArray(),
                    value("case1", 1, 1),
                    value("case2", 2, 2),
                    value("case3", 3, 3),
                    value("case4", 4, 4),
                    value("case5", 0, 5),
                    value("ledgerBreak", 10, 9, 1, 5),
                    value("prefixBreak", 10, 9, 1, 5, 7),
                    value("prefixNoBreak", 12, 9, 1, 2)
                ));
                break;
            case "LD":
                runMethod(className, target, "lab", cases(
                    value("empty", 0),
                    nullArray(),
                    value("case1", 1, 1),
                    value("case2", 2, 2),
                    value("case3", 3, 3),
                    value("case4", 4, 4),
                    value("case5", 0, 5),
                    value("ledgerBreak", 10, 9, 1, 5),
                    value("prefixBreak", 10, 9, 1, 5, 7),
                    value("prefixNoBreak", 12, 9, 1, 2)
                ));
                break;
            default:
                throw new AssertionError(className);
        }
    }

    private static void runMethod(String className, Class<?> target, String methodName, TestCase... tests) throws Exception {
        Method method = target.getDeclaredMethod(methodName, int[].class);
        if (!Modifier.isStatic(method.getModifiers()) || method.getReturnType() != Integer.TYPE) {
            throw new IllegalStateException("unexpected target signature: " + method);
        }
        method.setAccessible(true);
        for (TestCase test : tests) {
            try {
                Object result = method.invoke(null, new Object[] { test.input });
                if (test.expectedException != null) {
                    throw new AssertionError(methodName + "|" + test.name + " expected " + test.expectedException);
                }
                if (!(result instanceof Integer) || ((Integer) result).intValue() != test.expectedValue.intValue()) {
                    throw new AssertionError(methodName + "|" + test.name + " returned unexpected value");
                }
                System.out.println(className + "." + methodName + "|" + test.name + "|return|" + result);
            } catch (InvocationTargetException wrapped) {
                Throwable cause = wrapped.getCause();
                String actualException = cause == null ? "null" : cause.getClass().getName();
                if (test.expectedException == null || !test.expectedException.equals(actualException)) {
                    throw new AssertionError(methodName + "|" + test.name + " threw " + actualException);
                }
                // Exception messages can contain compiler-dependent local-variable names.
                System.out.println(className + "." + methodName + "|" + test.name + "|throws|" + actualException);
            }
        }
    }
}
