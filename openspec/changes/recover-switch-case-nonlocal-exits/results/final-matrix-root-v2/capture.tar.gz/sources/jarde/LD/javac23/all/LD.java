// jarde: presentation of `LD` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class LD extends java.lang.Object {
    public LD() {
        // @method <init>()V
        // @declaration a constructor of `LD`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int lab(int[] xs) {
        // @method lab([I)I
        // @declaration a static method of `LD`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int s;
        int[] local2;
        int local3;
        int local4;
        s = 0;
        local2 = xs;
        local3 = local2.length;
        local4 = 0;
        loop: while (local4 < local3) {
            int x = local2[local4];
            switch (x) {
                case 5:
                    break loop;
                default:
                    s = s + x;
                    local4 = local4 + 1;
                    continue;
            }
        }
        return s;
    }

    public static void main(java.lang.String[] a) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `LD`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.io.PrintStream saved0 = java.lang.System.out;
        saved0.println(lab(new int[]{9, 1, 5}));
        return;
    }
}
