// jarde: presentation of `SL` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class SL extends java.lang.Object {
    public SL() {
        // @method <init>()V
        // @declaration a constructor of `SL`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int mixed(int[] xs) {
        // @method mixed([I)I
        // @declaration a static method of `SL`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int sum;
        int[] local2;
        sum = 0;
        local2 = xs;
        for (int x : local2) {
            switch (x) {
                case 1:
                    break;
                case 2:
                    continue;
                case 3:
                    return sum + 100;
                default:
                    sum = sum + x;
                    break;
            }
            sum = sum + 10;
        }
        return sum;
    }

    static int labeledBreak(int[] xs) {
        // @method labeledBreak([I)I
        // @declaration a static method of `SL`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int sum;
        int[] local2;
        int local3;
        int local4;
        sum = 0;
        local2 = xs;
        local3 = local2.length;
        local4 = 0;
        loop: while (local4 < local3) {
            int x = local2[local4];
            switch (x) {
                case 5:
                    break loop;
                default:
                    sum = sum + x;
                    local4 = local4 + 1;
                    continue;
            }
        }
        return sum;
    }

    public static void main(java.lang.String[] a) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `SL`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.io.PrintStream saved0 = java.lang.System.out;
        java.lang.StringBuilder saved1 = new java.lang.StringBuilder().append("");
        java.lang.StringBuilder saved2 = saved1.append(mixed(new int[]{1, 2, 4})).append("/");
        java.lang.StringBuilder saved3 = saved2.append(mixed(new int[]{1, 4})).append("/");
        saved0.println((java.lang.String) saved3.append(labeledBreak(new int[]{1, 5, 9})).toString());
        return;
    }
}
