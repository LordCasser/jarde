import json,pathlib,importlib.util,os,shutil,sys
ROOT=pathlib.Path('/Users/lordcasser/workspace/projects/jarde')
OUT=pathlib.Path('/private/tmp/jarde-switch-jsr-original-root-v1-20261018')
PREP=pathlib.Path('/private/tmp/jarde-switch-exception-clone-control-luna-v2-20261018')
GEN=pathlib.Path('/private/tmp/jarde-switch-jsr-generator-root-v1-20261018.py')
def load(path,name):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','compare')
manifest=ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
jdks,jdk_record=c.configured_jdks(manifest,'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
assert not OUT.exists() and not (ROOT/'target').exists()
OUT.mkdir();(OUT/'raw').mkdir();(OUT/'target-classes').mkdir();(OUT/'driver-classes').mkdir();(OUT/'empty').mkdir()
g=load(ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py','guard')
s=load(ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py','scanner')
assert c.pin(pathlib.Path(g.__file__))['sha256']=='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
assert c.pin(pathlib.Path(s.__file__))['sha256']=='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:s.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
source=OUT/'SwitchLoopJsrCloneDriver.java';shutil.copy2(PREP/source.name,source)
expected=b'run(0)=0\nrun(3)=12\n';(OUT/'expected.txt').write_bytes(expected)
def tree(p):return {str(x.relative_to(p)):c.pin(x) for x in p.rglob('*') if x.is_file()}
def inputs():return {'generator':c.pin(GEN),'driver_source':c.pin(source),'collector':c.pin(pathlib.Path(__file__)),
    'jdk_tools':{leg:{name:c.pin(path) for name,path in x['tools'].items()} for leg,x in jdks.items()}}
r={'status':'running','inputs_before':inputs(),'source_before':c.source_closure(ROOT),'commands':[], 'runs':[]}
def save():(OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
def command(argv,leg):
    env=c.clean_env(dict(os.environ),jdks[leg]);env.pop('RUST_MIN_STACK',None);env.pop('CARGO_TARGET_DIR',None);env.update(g.ENV_VALUES)
    row=g.run_command(len(r['commands'])+1,argv,env);r['commands'].append(row);save();assert row['exit_code']==0 and row['guard_stop'] is None;return row
save()
try:
    cls=OUT/'target-classes/SwitchLoopJsrClone.class'
    command([sys.executable,'-B',str(GEN),str(cls)],'javac8')
    r['class']=c.pin(cls);r['facts']=c.parse_class(cls);save()
    command([str(jdks['javac8']['tools']['javac']),'-source','8','-target','8','-g','-encoding','UTF-8','-Xlint:-options','-proc:none','-classpath',str(OUT/'empty'),'-sourcepath',str(OUT/'empty'),'-d',str(OUT/'driver-classes'),str(source)],'javac8')
    r['classes_before']={'target':tree(OUT/'target-classes'),'driver':tree(OUT/'driver-classes')};save()
    for leg in ['javac8','javac23']:
        row=command([str(jdks[leg]['tools']['java']),'-Xverify:all','-cp',str(OUT/'driver-classes'),'SwitchLoopJsrCloneDriver',str(OUT/'target-classes')],leg)
        assert c.command_artifact(row,'stdout')==expected
        r['runs'].append({'runtime':leg,'command':row['index'],'exact_oracle':True});save()
    r['classes_after']={'target':tree(OUT/'target-classes'),'driver':tree(OUT/'driver-classes')};assert r['classes_before']==r['classes_after']
    r['status']='complete_pending_root_review'
finally:
    r['inputs_after']=inputs();r['inputs_unchanged']=r['inputs_after']==r['inputs_before']
    r['source_after']=c.source_closure(ROOT);r['source_unchanged']=r['source_after']==r['source_before'];r['target_absent']=not (ROOT/'target').exists();save()
assert r['inputs_unchanged'] and r['source_unchanged'] and r['target_absent']
shutil.copy2(GEN,OUT/'generator.py');shutil.copy2(__file__,OUT/'collector.py')
print(json.dumps({'status':r['status'],'commands':len(r['commands']),'runtime_runs':len(r['runs']),'class':r['class']}))
