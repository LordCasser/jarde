#!/usr/bin/env python3
"""Read-only verifier for the completed switch-case nonlocal baseline receipt."""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path

DEFAULT_RUN = Path('/private/tmp/jarde-switch-case-nonlocal-baseline-root-v1-20261018')
EXPECTED = {
    'SN': b'101/111/111/1\n',
    'SM': b'24/4/4/24/4\n',
    'SL': b'24/24/1\n',
    'LD': b'10\n',
}
COMPILERS = ('javac8', 'javac23')
EVIDENCE = ('default', 'all')

class Review:
    def __init__(self, run: Path):
        self.run_dir = run.resolve(strict=True)
        self.doc = json.loads((self.run_dir / 'execution.json').read_text(encoding='utf-8'))
        self.errors = []
        self.warnings = []
        self.commands = {}
        self.raw = {}
        self.report = {
            'schema': 'switch-case-baseline-independent-review-v1',
            'run_dir': str(self.run_dir),
            'receipt_status': self.doc.get('status'),
            'accepted_for_review': False,
            'errors': self.errors,
            'warnings': self.warnings,
            'observations': {},
        }

    def need(self, ok, message):
        if not ok:
            self.errors.append(message)

    @staticmethod
    def digest(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    def pinned_bytes(self, pin, label):
        if not isinstance(pin, dict) or not isinstance(pin.get('path'), str):
            self.errors.append(f'{label}: malformed artifact pin')
            return None
        p = Path(pin['path'])
        try:
            data = p.read_bytes()
        except Exception as e:
            self.errors.append(f'{label}: cannot reopen {p}: {type(e).__name__}: {e}')
            return None
        self.need(len(data) == pin.get('bytes'), f'{label}: byte length differs from receipt')
        self.need(self.digest(data) == pin.get('sha256'), f'{label}: SHA-256 differs from receipt')
        return data

    def command(self, index, label=None):
        row = self.commands.get(index)
        self.need(row is not None, f'command {index}: absent')
        if row is None:
            return None
        if label is not None:
            self.need(row.get('label') == label, f'command {index}: expected label {label}, got {row.get("label")}')
        return row

    def command_bytes(self, index, channel):
        key = (index, channel)
        if key in self.raw:
            return self.raw[key]
        row = self.command(index)
        if row is None:
            return None
        stream = row.get('streams', {}).get(channel)
        data = self.pinned_bytes(stream, f'command {index} {channel}')
        self.raw[key] = data
        return data

    def verify_commands(self):
        rows = self.doc.get('commands')
        self.need(isinstance(rows, list), 'commands is not a list')
        if not isinstance(rows, list):
            return
        expected = list(range(1, len(rows) + 1))
        actual = [r.get('index') for r in rows if isinstance(r, dict)]
        self.need(actual == expected, f'command indices are not contiguous: {actual[:8]}...')
        for row in rows:
            idx = row.get('index')
            self.need(isinstance(idx, int), f'command row has invalid index: {idx!r}')
            if not isinstance(idx, int):
                continue
            self.commands[idx] = row
            self.need(isinstance(row.get('argv'), list) and bool(row['argv']), f'command {idx}: argv missing')
            self.need(row.get('exit_code') is not None, f'command {idx}: no exit code')
            self.need('guard_stop' in row, f'command {idx}: guard_stop field missing')
            for ch in ('stdout', 'stderr'):
                data = self.command_bytes(idx, ch)
                self.need(data is not None, f'command {idx}: {ch} was not preserved')
        self.report['observations']['command_count'] = len(rows)
        self.report['observations']['command_failures'] = [
            {'index': r['index'], 'label': r.get('label'), 'exit_code': r.get('exit_code'),
             'guard_stop': r.get('guard_stop'),
             'stderr_sha256': r.get('streams', {}).get('stderr', {}).get('sha256')}
            for r in rows if r.get('exit_code') != 0 or r.get('guard_stop') is not None
        ]
        self.report['observations']['guard_stops'] = [
            {'index': r['index'], 'label': r.get('label'), 'guard_stop': r.get('guard_stop')}
            for r in rows if r.get('guard_stop') is not None
        ]

    def verify_integrity(self):
        self.need(self.doc.get('schema') == 'switch-case-nonlocal-baseline-v1', 'unexpected receipt schema')
        self.need(self.doc.get('status') == 'complete_pending_independent_review',
                  f"receipt is not complete; current status={self.doc.get('status')!r}; review remains pending")
        self.need(self.doc.get('matrix', {}).get('sources') == list(EXPECTED), 'source matrix differs')
        self.need(self.doc.get('matrix', {}).get('input_compilers') == list(COMPILERS), 'compiler matrix differs')
        self.need(self.doc.get('matrix', {}).get('runtime_jvms') == list(COMPILERS), 'runtime matrix differs')
        self.need(self.doc.get('matrix', {}).get('evidence') == list(EVIDENCE), 'evidence matrix differs')
        self.need(self.doc.get('matrix', {}).get('jarde_cells') == 16, 'Jarde matrix cell count differs')
        self.need(self.doc.get('matrix', {}).get('jadx_inputs') == 8, 'JADX input count differs')
        self.need(self.doc.get('source_pins_unchanged') is True, 'collector reports source pins changed')
        self.need(self.doc.get('inputs_unchanged') is True, 'collector reports pinned inputs changed')
        self.need(self.doc.get('repository_target_absent_after') is True, 'repository target is present after collection')
        self.need(self.doc.get('source_pins_after') == self.doc.get('source_pins_before'), 'before/after source pins differ')
        self.need(self.doc.get('inputs_after') == self.doc.get('inputs_before'), 'before/after tool/input pins differ')
        self.verify_commands()
        self.report['observations']['source_pins_unchanged'] = self.doc.get('source_pins_unchanged')
        self.report['observations']['inputs_unchanged'] = self.doc.get('inputs_unchanged')
        self.report['observations']['repository_target_absent_after'] = self.doc.get('repository_target_absent_after')

    def verify_originals(self):
        classes = self.doc.get('original_classes', [])
        self.need(len(classes) == 8, f'expected eight original compiler outputs, got {len(classes)}')
        by_key = {}
        for row in classes:
            key = (row.get('class_name'), row.get('compiler'))
            self.need(key not in by_key, f'duplicate original class record {key}')
            by_key[key] = row
            name, leg = key
            if name not in EXPECTED or leg not in COMPILERS:
                self.errors.append(f'unexpected original class identity {key}')
                continue
            srcpin = self.doc.get('inputs_before', {}).get('fixture_sources', {}).get(name)
            self.need(row.get('source') == srcpin, f'{name}/{leg}: original source pin mismatch')
            self.need(row.get('class_facts', {}).get('class_name') == name, f'{name}/{leg}: class facts name mismatch')
            self.need(row.get('class_facts', {}).get('major') == 52, f'{name}/{leg}: expected Java 8 major 52')
            self.need(row.get('class') is not None, f'{name}/{leg}: class pin missing')
            if row.get('class'):
                self.pinned_bytes(row['class'], f'original class {name}/{leg}')
            compile_row = self.command(row.get('compile_command'), f'original-{name}-{leg}-compile')
            if compile_row:
                self.need(compile_row.get('exit_code') == 0, f'{name}/{leg}: original source compilation failed')
                argv = compile_row.get('argv', [])
                self.need(str(self.doc.get('inputs_before', {}).get('fixture_sources', {}).get(name, {}).get('path')) in argv,
                          f'{name}/{leg}: compile argv did not use pinned whole source')
                self.need('-g' in argv, f'{name}/{leg}: original compile missing debug info')
                self.need(['-source','8','-target','8','-g','-encoding','UTF-8','-proc:none'] == [x for x in argv if x in ('-source','-target','-g','-encoding','-proc:none') or x in ('8','UTF-8')],
                          f'{name}/{leg}: original compiler flags differ from frozen whole-source Java 8 profile')
        self.need(len(by_key) == 8, 'original class matrix has missing entries')
        for name in EXPECTED:
            for leg in COMPILERS:
                self.need((name, leg) in by_key, f'missing original class {name}/{leg}')
        oracles = self.doc.get('original_oracles', [])
        self.need(len(oracles) == 16, f'expected 16 original oracle runs, got {len(oracles)}')
        seen = set()
        for row in oracles:
            name, build, runtime = row.get('class_name'), row.get('input_compiler'), row.get('runtime')
            key = (name, build, runtime)
            self.need(key not in seen, f'duplicate oracle run {key}')
            seen.add(key)
            if name not in EXPECTED or build not in COMPILERS or runtime not in COMPILERS:
                self.errors.append(f'unexpected oracle identity {key}')
                continue
            cmd = self.command(row.get('command'), f'original-{name}-{build}-{runtime}')
            stdout = self.command_bytes(row.get('command'), 'stdout')
            stderr = self.command_bytes(row.get('command'), 'stderr')
            self.need(cmd is not None and cmd.get('exit_code') == 0, f'{key}: original runtime failed')
            self.need(stdout == EXPECTED[name], f'{key}: stdout differs from fixed original oracle: {stdout!r}')
            self.need(stderr == b'', f'{key}: stderr is not empty: {stderr!r}')
            self.need(row.get('stdout_bytes') == len(EXPECTED[name]), f'{key}: stdout byte count mismatch')
            self.need(row.get('stdout_sha256') == self.digest(EXPECTED[name]), f'{key}: stdout digest mismatch')
            self.need(row.get('stderr_sha256') == self.digest(b''), f'{key}: stderr digest mismatch')
        self.need(len(seen) == 16, 'oracle matrix has missing rows')
        self.report['observations']['oracle_values'] = {k: v.decode('ascii').rstrip('\n') for k, v in EXPECTED.items()}
        self.report['observations']['oracle_runs'] = len(seen)
        self.report['observations']['original_method_facts'] = {
            f"{r.get('class_name')}/{r.get('compiler')}": [
                {'name': m.get('name'), 'descriptor': m.get('descriptor'),
                 'code_length': (m.get('code') or {}).get('code_length'),
                 'bcis': (m.get('code') or {}).get('bcis', [])}
                for m in r.get('class_facts', {}).get('methods', [])]
            for r in classes
        }
        return by_key

    @staticmethod
    def escaped(value):
        return value if isinstance(value, str) else None

    @staticmethod
    def byte_chars(value):
        if isinstance(value, list) and all(isinstance(x, int) and 0 <= x <= 0x10ffff for x in value):
            try: return ''.join(chr(x) for x in value)
            except ValueError: return None
        if isinstance(value, str): return value
        return None

    @staticmethod
    def strip_usage(value):
        if isinstance(value, dict):
            return {k: Review.strip_usage(v) for k, v in value.items() if k != 'usage'}
        if isinstance(value, list): return [Review.strip_usage(v) for v in value]
        return value

    @staticmethod
    def diff_paths(a, b, path='$', limit=48):
        changes=[]
        def rec(x,y,p):
            if len(changes) >= limit: return
            if type(x) is not type(y):
                changes.append(p); return
            if isinstance(x, dict):
                for k in sorted(set(x)|set(y)):
                    if len(changes) >= limit: return
                    if k not in x or k not in y: changes.append(p+'.'+k)
                    else: rec(x[k],y[k],p+'.'+k)
            elif isinstance(x,list):
                if len(x) != len(y): changes.append(p+f'.length({len(x)}!={len(y)})')
                for i,(xx,yy) in enumerate(zip(x,y)):
                    if len(changes) >= limit: return
                    rec(xx,yy,p+f'[{i}]')
            elif x != y:
                changes.append(p)
        rec(a,b,path)
        return changes

    def class_fact_method_map(self, row):
        facts = row.get('class_facts', {})
        result = {}
        for m in facts.get('methods', []):
            if m.get('code') is None: continue
            result[(m.get('name'), m.get('descriptor'))] = set(m['code'].get('bcis', []))
        return result

    def validate_source_map(self, report, method_key, method_bcis, class_digest, label):
        text = report.get('text')
        sm = report.get('source_map')
        categories = (report.get('evidence') or {}).get('categories', [])
        sm_state = next((c.get('state', {}).get('state') for c in categories if c.get('kind') == 'source_map'), None)
        self.need(sm_state == 'complete', f'{label}: source_map evidence is {sm_state!r}, expected complete')
        self.need(isinstance(text, str), f'{label}: report.text missing')
        self.need(isinstance(sm, dict) and isinstance(sm.get('segments'), list), f'{label}: source_map.segments missing')
        if not isinstance(text, str) or not isinstance(sm, dict) or not isinstance(sm.get('segments'), list):
            return {'segment_count': None, 'validated_origins': 0, 'unmatched_origins': 0}
        text_bytes = len(text.encode('utf-8'))
        validated=0;unmatched=0
        for i,seg in enumerate(sm['segments']):
            start,end=seg.get('start'),seg.get('end')
            self.need(isinstance(start,int) and isinstance(end,int) and 0 <= start < end <= text_bytes,
                      f'{label}: source-map segment {i} range {start}:{end} outside {text_bytes} UTF-8 bytes')
            origin=seg.get('origin')
            if not isinstance(origin,dict):
                self.errors.append(f'{label}: segment {i} origin missing'); continue
            origins=[]
            if isinstance(origin.get('primary'),dict): origins.append(origin['primary'])
            if isinstance(origin.get('derived'),list): origins.extend(x for x in origin['derived'] if isinstance(x,dict))
            for item in origins:
                bci=item.get('bci'); method=item.get('method')
                if not isinstance(bci,int) or not isinstance(method,dict): continue
                owner=((method.get('owner') or {}).get('class_bytes') or {}).get('digest')
                if owner != class_digest:
                    unmatched += 1
                    continue
                name=self.byte_chars(method.get('name')); desc=self.byte_chars(method.get('descriptor'))
                known=method_bcis.get((name,desc))
                self.need(known is not None, f'{label}: source-map origin references unknown same-class method {name}{desc}')
                if known is not None:
                    self.need(bci in known, f'{label}: BCI {bci} absent from original {name}{desc} Code')
                    validated += 1
        return {'segment_count':len(sm['segments']),'validated_origins':validated,'external_or_unmatched_origins':unmatched}

    def verify_json_doc(self, cell, orig_by_key):
        name, leg, evidence = cell['class_name'], cell['input_compiler'], cell['evidence']
        key=f'{name}/{leg}/{evidence}'
        raw_json=self.command_bytes(cell['command'],'stdout')
        self.need(cell.get('input_class') == orig_by_key[(name,leg)].get('class'), f'{key}: input class pin mismatch')
        self.pinned_bytes(cell.get('json_artifact'), f'{key} captured JSON')
        if raw_json is None: return None
        self.need(raw_json == Path(cell['json_artifact']['path']).read_bytes(), f'{key}: JSON artifact differs from command stdout')
        try: doc=json.loads(raw_json.decode('utf-8'))
        except Exception as e:
            self.need(cell.get('json_capture_error') is not None, f'{key}: malformed JSON not preserved as capture error')
            return None
        self.need(isinstance(doc,dict), f'{key}: JSON root is not object')
        if not isinstance(doc,dict): return None
        self.need(cell.get('outcome') == doc.get('outcome'), f'{key}: receipt outcome differs from JSON')
        self.need(cell.get('view') == doc.get('view'), f'{key}: receipt view differs from JSON')
        text=doc.get('text')
        if isinstance(text,str):
            pin=cell.get('source_artifact')
            self.need(pin is not None, f'{key}: JSON has full text but source artifact is missing')
            if pin:
                data=self.pinned_bytes(pin,f'{key} Jarde source')
                self.need(data == text.encode('utf-8'), f'{key}: generated source is not byte-for-byte JSON text')
            self.need(cell.get('source_exact_json_text') is True, f'{key}: exact JSON-text flag missing')
        else:
            self.need(cell.get('source_artifact') is None, f'{key}: source artifact exists without JSON text')
        methods=doc.get('methods')
        self.need(isinstance(methods,list), f'{key}: methods array missing')
        original=orig_by_key[(name,leg)].get('class_facts',{})
        expected_methods=[(m.get('name'),m.get('descriptor')) for m in original.get('methods',[])]
        method_rows=[];map_facts=self.class_fact_method_map(orig_by_key[(name,leg)])
        class_digest=(doc.get('class',{}).get('class_bytes') or {}).get('digest')
        seen=set()
        for mi,m in enumerate(methods if isinstance(methods,list) else []):
            item=m.get('item') or {}
            ident=(self.byte_chars((item.get('name') or {}).get('raw')),self.byte_chars((item.get('descriptor') or {}).get('raw')))
            self.need(ident not in seen, f'{key}: duplicate method identity {ident}')
            seen.add(ident)
            self.need(mi < len(expected_methods) and ident == expected_methods[mi], f'{key}: method {mi} identity/order mismatch: {ident}')
            outcome=m.get('outcome') or {}
            rep=outcome.get('report') or {}
            quality=rep.get('quality')
            fallback=rep.get('fallbacks')
            self.need(isinstance(quality,str), f'{key}/{ident}: report quality missing')
            self.need(isinstance(fallback,list), f'{key}/{ident}: report fallbacks missing')
            if isinstance(quality,str) and isinstance(fallback,list):
                method_rows.append({'identity':ident,'quality':quality,'fallbacks':fallback,
                    'outcome':rep.get('outcome'),'semantic_validation':rep.get('semantic_validation'),
                    'text':rep.get('text'),'source_map':rep.get('source_map')})
            if rep:
                mfacts=map_facts.get(ident)
                self.need(mfacts is not None, f'{key}/{ident}: no matching original Code facts')
                if mfacts is not None:
                    sm=self.validate_source_map(rep,ident,map_facts,class_digest,f'{key}/{ident}')
                    method_rows[-1]['source_map_facts']=sm
        self.need(seen == set(expected_methods), f'{key}: report method identities differ from full class')
        self.need(len(method_rows) == len(expected_methods), f'{key}: missing method quality/fallback row')
        return {'doc':doc,'method_rows':method_rows,'non_usage':self.strip_usage(doc.get('methods',[]))}

    def verify_rebuilds(self, kind, cell, oracle_by_runtime, class_name):
        rows=cell.get('rebuilds',[])
        self.need(len(rows) == 2, f'{kind} {class_name}: expected two full-source compiler rows')
        by_leg={}
        for row in rows:
            leg=row.get('compiler'); self.need(leg in COMPILERS, f'{kind} {class_name}: unknown build compiler {leg}')
            self.need(leg not in by_leg, f'{kind} {class_name}: duplicate compiler row {leg}')
            by_leg[leg]=row
            prefix=f'{kind}-{class_name}-{cell.get("input_compiler", "")}' + (f'-{cell.get("evidence")}' if kind=='jarde' else '')
            cmd=self.command(row.get('compile_command'),f'{prefix}-{leg}-compile')
            # The collector labels use cell labels, supplied separately through captured row labels.
            if cmd is None or (cmd.get('label') is not None and 'compile' not in cmd.get('label','')):
                self.errors.append(f'{kind} {class_name}/{leg}: compile command label mismatch')
                continue
            argv=cmd.get('argv', [])
            source_pin=cell.get('source_artifact') if kind=='jarde' else cell.get('source')
            self.need(source_pin is not None and source_pin.get('path') in argv,
                      f'{kind} {class_name}/{leg}: compile argv does not name the captured full source')
            self.need(['-source','8','-target','8','-g','-encoding','UTF-8','-proc:none'] == [x for x in argv if x in ('-source','-target','-g','-encoding','-proc:none') or x in ('8','UTF-8')],
                      f'{kind} {class_name}/{leg}: compiler flags differ from frozen whole-source Java 8 profile')
            self.need(cmd.get('exit_code') == row.get('compile_exit_code'), f'{kind} {class_name}/{leg}: compile exit differs from command')
            cls=row.get('compiled_class')
            if cmd.get('exit_code') == 0:
                self.need(cls is not None, f'{kind} {class_name}/{leg}: successful compile has no class pin')
                if cls:
                    self.pinned_bytes(cls,f'{kind} {class_name}/{leg} compiled class')
                    facts=row.get('class_facts')
                    self.need(isinstance(facts,dict), f'{kind} {class_name}/{leg}: compiled class facts missing')
                    self.need(facts.get('class_name') == class_name, f'{kind} {class_name}/{leg}: compiled class name mismatch')
                runtime_rows=row.get('runtime_runs',[])
                self.need(len(runtime_rows)==2, f'{kind} {class_name}/{leg}: successful compile requires both JVM runs')
                seen_runtime=set()
                for rr in runtime_rows:
                    runtime=rr.get('runtime'); self.need(runtime in COMPILERS, f'{kind} {class_name}/{leg}: unknown runtime')
                    self.need(runtime not in seen_runtime, f'{kind} {class_name}/{leg}: duplicate runtime {runtime}')
                    seen_runtime.add(runtime)
                    rc=self.command(rr.get('command'),f'{prefix}-{leg}-{runtime}-runtime')
                    if rc:
                        if cls:
                            facts=row.get('class_facts') or {}
                            class_root=Path(cls['path']).resolve().parent
                            for _ in str(facts.get('class_name','')).split('/')[:-1]: class_root=class_root.parent
                            fqn=str(facts.get('class_name','')).replace('/','.')
                            argv=rc.get('argv',[])
                            self.need('-cp' in argv and str(class_root) in argv,
                                      f'{kind} {class_name}/{leg}/{runtime}: runtime classpath is not the compiled class root')
                            self.need(fqn in argv and '-Xverify:all' in argv,
                                      f'{kind} {class_name}/{leg}/{runtime}: runtime main/verification flags mismatch')
                        actual=self.command_bytes(rr.get('command'),'stdout')
                        actual_err=self.command_bytes(rr.get('command'),'stderr')
                        self.need(rr.get('exit_code') == rc.get('exit_code'), f'{kind} {class_name}/{leg}/{runtime}: runtime exit mismatch')
                        self.need(rr.get('stdout_sha256') == rc.get('streams',{}).get('stdout',{}).get('sha256'), f'{kind} {class_name}/{leg}/{runtime}: stdout digest mismatch')
                        self.need(rr.get('stderr_sha256') == rc.get('streams',{}).get('stderr',{}).get('sha256'), f'{kind} {class_name}/{leg}/{runtime}: stderr digest mismatch')
                        oracle=oracle_by_runtime.get(runtime)
                        matched=rc.get('exit_code')==0 and actual==oracle and actual_err==b''
                        self.need(rr.get('matches_original_oracle') is matched, f'{kind} {class_name}/{leg}/{runtime}: match flag differs from raw bytes')
            else:
                self.need(cls is None, f'{kind} {class_name}/{leg}: failed compile has a compiled class pin')
                self.need(row.get('runtime_runs') == [], f'{kind} {class_name}/{leg}: runtime present despite failed compile')
        self.need(set(by_leg)==set(COMPILERS), f'{kind} {class_name}: missing compiler leg')
        return by_leg

    def verify_jarde(self, originals):
        cells=self.doc.get('jarde_cells',[])
        self.need(len(cells)==16, f'expected 16 Jarde cells, got {len(cells)}')
        seen={}; extracted={}; rebuild_observations=[]
        for cell in cells:
            name,leg,evidence=cell.get('class_name'),cell.get('input_compiler'),cell.get('evidence')
            key=(name,leg,evidence)
            self.need(key not in seen, f'duplicate Jarde cell {key}')
            seen[key]=cell
            if name not in EXPECTED or leg not in COMPILERS or evidence not in EVIDENCE: continue
            c=self.command(cell.get('command'),f'jarde-{name}-{leg}-{evidence}')
            if c:
                self.need(c.get('exit_code')==cell.get('exit_code'), f'Jarde {key}: CLI exit differs from command')
                self.need(cell.get('exit_classification') in ('success','exit-4-capturable','other-exit-captured'), f'Jarde {key}: exit classification missing')
                argv=c.get('argv',[]); class_pin=cell.get('input_class') or {}
                for pair in (('--input',class_pin.get('path')),('--class',name),('--policy','single-class'),('--release','8'),('--format','json')):
                    self.need(pair[0] in argv and argv[argv.index(pair[0])+1] == pair[1], f'Jarde {key}: argv does not bind {pair[0]}={pair[1]}')
                self.need(('--evidence' in argv) == (evidence=='all'), f'Jarde {key}: evidence flag differs from cell')
            checked=self.verify_json_doc(cell,originals)
            if checked is not None: extracted[key]=checked
            oracle={runtime:EXPECTED[name] for runtime in COMPILERS}
            rows=self.verify_rebuilds('jarde',cell,oracle,name)
            rebuild_observations.append({'cell':key,'builds':{leg:{'compile_exit_code':r.get('compile_exit_code'),'runtime_matches':{rr.get('runtime'):rr.get('matches_original_oracle') for rr in r.get('runtime_runs',[])}} for leg,r in rows.items()}})
        expected={(n,l,e) for n in EXPECTED for l in COMPILERS for e in EVIDENCE}
        self.need(set(seen)==expected, f'Jarde cell matrix incomplete: missing={sorted(expected-set(seen))}')
        pairs=[];quality_rows=[]
        for name in EXPECTED:
            for leg in COMPILERS:
                a=extracted.get((name,leg,'default')); b=extracted.get((name,leg,'all'))
                if not a or not b: continue
                self.need(a['doc'].get('text')==b['doc'].get('text'), f'{name}/{leg}: default/all full class text differs')
                self.need([(m['identity'],m['text']) for m in a['method_rows']]==[(m['identity'],m['text']) for m in b['method_rows']], f'{name}/{leg}: default/all full method bodies differ')
                stable=lambda rows:[{k:m.get(k) for k in ('identity','quality','fallbacks','outcome','semantic_validation','text','source_map')} for m in rows]
                self.need(stable(a['method_rows'])==stable(b['method_rows']), f'{name}/{leg}: default/all method quality/fallback/source-map facts differ')
                diffs=self.diff_paths(a['non_usage'],b['non_usage'])
                pairs.append({'class_name':name,'input_compiler':leg,'whole_text_equal':True,
                    'method_quality_fallback_map_equal':True,'non_usage_report_diff_paths_sample':diffs,
                    'non_usage_report_diff_truncated_at_48':len(diffs)>=48})
                for m in a['method_rows']:
                    quality_rows.append({'class_name':name,'input_compiler':leg,'method':m['identity'][0],
                        'descriptor':m['identity'][1],'quality':m['quality'],'fallbacks':m['fallbacks'],
                        'source_map_facts':m.get('source_map_facts')})
        self.need(len(pairs)==8, f'default/all comparison pairs incomplete: {len(pairs)}')
        self.report['observations']['jarde_default_all'] = pairs
        self.report['observations']['jarde_method_quality_fallback_source_maps'] = quality_rows
        self.report['observations']['jarde_rebuilds'] = rebuild_observations

    def verify_jadx(self, originals):
        cells=self.doc.get('jadx_cells',[])
        self.need(len(cells)==8, f'expected eight JADX cells, got {len(cells)}')
        seen={}; observations=[]
        for cell in cells:
            name,leg=cell.get('class_name'),cell.get('input_compiler'); key=(name,leg)
            self.need(key not in seen, f'duplicate JADX cell {key}')
            seen[key]=cell
            if name not in EXPECTED or leg not in COMPILERS: continue
            c=self.command(cell.get('command'),f'jadx-{name}-{leg}')
            if c:
                self.need(c.get('exit_code')==cell.get('exit_code'), f'JADX {key}: exit differs from command')
                argv=c.get('argv',[]); class_pin=cell.get('input_class') or {}
                self.need(class_pin.get('path') == argv[-1], f'JADX {key}: command input class differs from frozen original class')
                for arg in ('--config','none','--threads-count','1','--no-res','--rename-flags','none','-d'):
                    self.need(arg in argv, f'JADX {key}: missing pinned option {arg}')
            self.need(cell.get('input_class') == originals[key].get('class'), f'JADX {key}: input class pin mismatch')
            for filepin in cell.get('output_files',[]): self.pinned_bytes(filepin,f'JADX output {key}')
            sp=cell.get('source')
            if sp:
                data=self.pinned_bytes(sp,f'JADX source {key}')
                output_by_path={p.get('path'):p for p in cell.get('output_files',[])}
                self.need(sp.get('path') in output_by_path and output_by_path[sp.get('path')]==sp, f'JADX {key}: source not among pinned generated files')
                self.need(data is not None, f'JADX {key}: source bytes missing')
            else:
                self.warnings.append(f'JADX {key}: no source was emitted; preserved as actual result')
            rows=self.verify_rebuilds('jadx',cell,{runtime:EXPECTED[name] for runtime in COMPILERS},name)
            observations.append({'cell':key,'exit_code':cell.get('exit_code'),'source':sp,
              'builds':{l:{'compile_exit_code':r.get('compile_exit_code'),'runtime_matches':{rr.get('runtime'):rr.get('matches_original_oracle') for rr in r.get('runtime_runs',[])}} for l,r in rows.items()},
              'source_error':cell.get('source_error')})
        expected={(n,l) for n in EXPECTED for l in COMPILERS}
        self.need(set(seen)==expected, f'JADX input matrix incomplete: missing={sorted(expected-set(seen))}')
        self.report['observations']['jadx_rebuilds'] = observations

    def run(self):
        # A live collector is deliberately not accepted. This script may be run after it closes.
        self.verify_integrity()
        if self.doc.get('status') != 'complete_pending_independent_review':
            self.report['pending'] = True
            return self.report
        originals=self.verify_originals()
        self.verify_jarde(originals)
        self.verify_jadx(originals)
        self.report['accepted_for_review'] = not self.errors
        self.report['pending'] = False
        self.report['errors'] = self.errors
        self.report['warnings'] = self.warnings
        return self.report

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run',type=Path,default=DEFAULT_RUN)
    ap.add_argument('--out',type=Path,default=None)
    args=ap.parse_args()
    review=Review(args.run)
    result=review.run()
    rendered=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if args.out:
        p=args.out.resolve()
        p.write_text(rendered,encoding='utf-8')
    print(rendered,end='')
    if result.get('pending'):
        return 2
    return 0 if result.get('accepted_for_review') else 1

if __name__=='__main__': raise SystemExit(main())
