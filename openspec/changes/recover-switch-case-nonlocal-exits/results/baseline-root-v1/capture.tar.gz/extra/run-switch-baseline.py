#!/usr/bin/env python3
"""Root-run original/Jarde/JADX baseline for the frozen switch nonlocal-exit family."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, re, shutil, sys
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
FIXTURE = ROOT / 'openspec/evidence/java-syntax-2026-10-05/switch-nonlocal-exit-patrol/fixture'
SOURCES = {
    'SN': ('5393e68866c8746d18b4556f0cca3d085f6c80600a7b4195ba00107b147fa5cc', 930),
    'SM': ('9020a135b245181039594535982c734a3c9fd04be948ede35c7fd61f468a6b95', 1186),
    'SL': ('05fd8992b322149e06d4912aa9572ca1e4ab3e73102fdb0a5e293b61ef54e41a', 1205),
    'LD': ('d8e267aba242cd1b4ab33e19dd034b1fce599ec1df25f245eb517ff45cc8b80d', 223),
}
CLI = Path('/private/tmp/jarde-direct-array-final-gates-root-v5-20261018/candidate-cli')
CLI_SHA = '605fdd1b2b0cc077bb9440a02b7f995ca33dded37b7527cc306f65a77bdf4c0c'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
COMPARE = ROOT / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_MANIFEST = ROOT / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
JDK_LEGS = ('javac8', 'javac23')
EVIDENCE = ('default', 'all')
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')
DEFAULT_OUT = Path('/private/tmp/jarde-switch-case-nonlocal-baseline-root-v1-20261018')


def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def pin(path: Path) -> dict:
    path=path.resolve(strict=True)
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)}

def write_json(path: Path, doc) -> None:
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    tmp.replace(path)

def load(path: Path,name: str):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot load helper {path}')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def fresh(path: Path) -> None:
    if path.exists(): raise RuntimeError(f'refusing existing output {path}')
    path.mkdir(parents=True)

def source_package(text: str) -> str:
    m=re.search(r'^\s*package\s+([\w.]+)\s*;',text,re.M)
    return m.group(1) if m else ''

def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=DEFAULT_OUT)
    args=ap.parse_args()
    root=ROOT.resolve(strict=True);out=args.out.resolve()
    if out.exists(): raise SystemExit(f'refusing existing output directory: {out}')
    if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('repository target must be absent before run')
    compare=load(COMPARE,'switch_case_baseline_compare_helpers')
    cli=CLI.resolve(strict=True);jadx=JADX.resolve(strict=True);jadx_jar=JADX_JAR.resolve(strict=True)
    if cli != CLI.resolve() or sha(cli)!=CLI_SHA: raise SystemExit('605 CLI path/digest mismatch')
    if sha(jadx)!=JADX_SHA or sha(jadx_jar)!=JADX_JAR_SHA: raise SystemExit('pinned JADX 1.5.6 binary/JAR mismatch')
    guard_path=root/GUARD_REL;scanner_path=root/SCANNER_REL
    if sha(guard_path)!=GUARD_SHA or sha(scanner_path)!=SCANNER_SHA: raise SystemExit('pinned run guard/scanner source mismatch')
    sources={name:FIXTURE/f'{name}.java' for name in SOURCES}
    for name,path in sources.items():
        actual=pin(path);expected_sha,expected_bytes=SOURCES[name]
        if actual['sha256']!=expected_sha or actual['bytes']!=expected_bytes: raise SystemExit(f'frozen fixture pin mismatch: {path}')
    jdks,jdk_record=compare.configured_jdks(JDK_MANIFEST,JDK_MANIFEST_SHA)
    if shutil.disk_usage(root).free < 5*1024**3: raise SystemExit('5 GiB free-space check failed')
    source_before=compare.source_closure(root)
    inputs={'fixture_sources':{k:pin(v) for k,v in sources.items()},'cli':pin(cli),'jadx':pin(jadx),'jadx_jar':pin(jadx_jar),
            'compare_helpers':pin(COMPARE),'runner':pin(Path(__file__)),'guard':pin(guard_path),'scanner':pin(scanner_path),'jdk_manifest':pin(JDK_MANIFEST),
            'jdk_tools':{leg:{tool:pin(path) for tool,path in row['tools'].items()} for leg,row in jdks.items()}}
    out.mkdir(parents=True);raw_dir=out/'raw';raw_dir.mkdir()
    guard=load(guard_path,'switch_case_root_guard');scanner=load(scanner_path,'switch_case_root_scanner')
    guard.ROOT=root;guard.OUT=raw_dir;guard.target_bytes=lambda:scanner.target_bytes(root);guard.command_stream=lambda p:compare.pin(p)
    guard.expected_test_summaries=lambda index,stdout:None
    commands=[]
    result={'schema':'switch-case-nonlocal-baseline-v1','status':'running','root':str(root),'output':str(out),
      'inputs_before':inputs,'source_pins_before':source_before,'jdk_manifest_record':jdk_record,
      'matrix':{'sources':list(SOURCES),'input_compilers':list(JDK_LEGS),'runtime_jvms':list(JDK_LEGS),'evidence':list(EVIDENCE),
       'jarde_cells':len(SOURCES)*len(JDK_LEGS)*len(EVIDENCE),'jadx_inputs':len(SOURCES)*len(JDK_LEGS)},
      'commands':commands,'original_classes':[],'original_oracles':[],'jarde_cells':[],'jadx_cells':[],
      'notes':['All four frozen Java sources are compiled intact with -source 8 -target 8 -g under both configured javac legs.',
       'Original class mains run with both configured Java executables and -Xverify:all; their exact stdout bytes are the per-input/runtime oracle.',
       'Jarde CLI exit code 4 is recorded as a capturable Partial result; when its JSON includes full class text, that exact text is saved and compiled.',
       'Generated source is written byte-for-byte from CLI JSON text or JADX output, with no method removal, source repair, or content rewriting.',
       'Compiler failures and diagnostics remain evidence; no generated-source runtime row is recorded unless compilation succeeds.']}
    write_json(out/'execution.json',result)
    env_base=compare.clean_env(dict(os.environ));env_base.pop('RUST_MIN_STACK',None);env_base.update(guard.ENV_VALUES)
    def command(label,argv,leg=None,phase=''):
        env=compare.clean_env(env_base,jdks[leg] if leg else None)
        row=guard.run_command(len(commands)+1,argv,env);row.update({'label':label,'phase':phase,'compiler_leg':leg})
        commands.append(row);write_json(out/'execution.json',result)
        if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        return row
    def raw(row,channel): return compare.command_artifact(row,channel)
    def compile_java(source,leg,outdir,label):
        outdir.parent.mkdir(parents=True,exist_ok=True);fresh(outdir)
        empty=outdir.parent/(outdir.name+'-empty-sourcepath');fresh(empty)
        flags=['-source','8','-target','8','-g','-encoding','UTF-8','-Xlint:-options','-proc:none']
        return command(label,[str(jdks[leg]['tools']['javac']),*flags,'-classpath',str(empty),'-sourcepath',str(empty),'-d',str(outdir),str(source)],leg,'javac')
    def run_main(label,class_root,class_name,leg,phase):
        package=''
        fqn=f'{package}.{class_name}' if package else class_name
        return command(label,[str(jdks[leg]['tools']['java']),'-Xverify:all','-cp',str(class_root),fqn],leg,phase)
    def write_source(source_bytes,path,label):
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(source_bytes)
        if path.read_bytes()!=source_bytes: raise RuntimeError(f'{label}: generated source bytes changed during capture')
        return pin(path)
    def compile_and_run(source_path,class_name,label,oracle_by_runtime,phase):
        rows=[]
        package=source_package(source_path.read_text(encoding='utf-8'))
        fqn=f'{package}.{class_name}' if package else class_name
        for build_leg in JDK_LEGS:
            outdir=out/'rebuilt-classes'/label/build_leg
            cr=compile_java(source_path,build_leg,outdir,f'{label}-{build_leg}-compile')
            cls=outdir/(package.replace('.','/')+'/' if package else '')/(class_name+'.class')
            item={'compiler':build_leg,'compile_command':cr['index'],'compile_exit_code':cr['exit_code'],
                  'compiled_class':pin(cls) if cls.is_file() else None,'class_facts':compare.parse_class(cls) if cls.is_file() else None,'runtime_runs':[]}
            if cr['exit_code']==0 and cls.is_file():
                for runtime in JDK_LEGS:
                    rr=command(f'{label}-{build_leg}-{runtime}-runtime',[str(jdks[runtime]['tools']['java']),'-Xverify:all','-cp',str(outdir),fqn],runtime,phase)
                    stdout=raw(rr,'stdout');item['runtime_runs'].append({'runtime':runtime,'command':rr['index'],'exit_code':rr['exit_code'],
                       'stdout_sha256':rr['streams']['stdout']['sha256'],'stderr_sha256':rr['streams']['stderr']['sha256'],
                       'matches_original_oracle':rr['exit_code']==0 and stdout==oracle_by_runtime.get(runtime)})
            rows.append(item)
        return rows
    error=None
    try:
        # Original matrix: 4 complete source files x 2 javac legs; run every class main on both JVMs.
        oracle={}
        for name,src in sources.items():
            for leg in JDK_LEGS:
                class_dir=out/'original-classes'/name/leg
                cr=compile_java(src,leg,class_dir,f'original-{name}-{leg}-compile')
                cls=class_dir/f'{name}.class'
                if cr['exit_code']!=0 or not cls.is_file():
                    result['original_classes'].append({'class_name':name,'compiler':leg,'compile_command':cr['index'],'exit_code':cr['exit_code'],'class':pin(cls) if cls.is_file() else None})
                    raise RuntimeError(f'original source did not compile intact: {name}/{leg}')
                facts=compare.parse_class(cls)
                result['original_classes'].append({'class_name':name,'compiler':leg,'source':pin(src),'compile_command':cr['index'],'class':pin(cls),'class_facts':facts})
                oracle[(name,leg)]={}
                for runtime in JDK_LEGS:
                    rr=run_main(f'original-{name}-{leg}-{runtime}',class_dir,name,runtime,'original-oracle')
                    if rr['exit_code']!=0: raise RuntimeError(f'original JVM oracle failed: {name}/{leg}/{runtime}')
                    data=raw(rr,'stdout');oracle[(name,leg)][runtime]=data
                    result['original_oracles'].append({'class_name':name,'input_compiler':leg,'runtime':runtime,'command':rr['index'],
                      'stdout_sha256':rr['streams']['stdout']['sha256'],'stderr_sha256':rr['streams']['stderr']['sha256'],'stdout_bytes':len(data)})
                write_json(out/'execution.json',result)
        # Jarde default/all for each full compiler-produced class. Exit 4 is a capturable Partial result.
        for name in SOURCES:
            for input_leg in JDK_LEGS:
                class_path=out/'original-classes'/name/input_leg/f'{name}.class'
                class_facts=compare.parse_class(class_path)
                for evidence in EVIDENCE:
                    argv=[str(cli),'class-source','--input',str(class_path),'--class',name,'--policy','single-class','--release','8','--format','json']
                    if evidence=='all': argv.extend(['--evidence','all'])
                    cr=command(f'jarde-{name}-{input_leg}-{evidence}',argv,phase='jarde-class-source')
                    cell={'class_name':name,'input_compiler':input_leg,'input_class':pin(class_path),'input_class_facts':class_facts,
                          'evidence':evidence,'command':cr['index'],'exit_code':cr['exit_code'],
                          'exit_classification':'exit-4-capturable' if cr['exit_code']==4 else ('success' if cr['exit_code']==0 else 'other-exit-captured'),
                          'json_artifact':None,'source_artifact':None,'rebuilds':[]}
                    stdout_bytes=raw(cr,'stdout')
                    jp=out/'jarde-json'/name/input_leg/f'{evidence}.json';jp.parent.mkdir(parents=True,exist_ok=True);jp.write_bytes(stdout_bytes)
                    cell['json_artifact']=pin(jp)
                    try:
                        doc=json.loads(stdout_bytes.decode('utf-8'))
                    except (UnicodeDecodeError,json.JSONDecodeError) as exc:
                        cell['json_capture_error']=f'{type(exc).__name__}: {exc}'
                    else:
                        if not isinstance(doc,dict):
                            cell['json_capture_error']='top-level JSON value is not an object'
                        else:
                            cell['outcome']=doc.get('outcome');cell['view']=doc.get('view')
                            text=doc.get('text')
                            cell['capture_status']=('partial-text-captured' if cr['exit_code']==4 and isinstance(text,str) else ('text-captured' if isinstance(text,str) else 'json-without-full-text'))
                            if isinstance(text,str):
                                sp=out/'jarde-source'/name/input_leg/evidence/f'{name}.java'
                                cell['source_artifact']=write_source(text.encode('utf-8'),sp,'Jarde text')
                                cell['source_exact_json_text']=True
                                # Compilation/runtime infrastructure failures propagate to the top-level receipt.
                                cell['rebuilds']=compile_and_run(sp,name,f'jarde-{name}-{input_leg}-{evidence}',oracle[(name,input_leg)],'jarde-runtime')
                            else: cell['source_error']='valid JSON did not expose full text'
                    result['jarde_cells'].append(cell);write_json(out/'execution.json',result)
        # JADX 1.5.6: each of the eight exact original class files is the direct input.
        vr=command('jadx-version',[str(jadx),'--version'],'javac23','jadx-version')
        version=(raw(vr,'stdout')+raw(vr,'stderr')).decode('utf-8',errors='replace')
        for name in SOURCES:
            for input_leg in JDK_LEGS:
                class_path=out/'original-classes'/name/input_leg/f'{name}.class'
                ddir=out/'jadx-output'/name/input_leg
                if ddir.exists(): raise RuntimeError(f'refusing existing JADX directory {ddir}')
                dr=command(f'jadx-{name}-{input_leg}',[str(jadx),'--config','none','--threads-count','1','--no-res','--rename-flags','none','-d',str(ddir),str(class_path)],'javac23','jadx-decompile')
                files=[pin(p) for p in sorted(ddir.rglob('*')) if p.is_file()] if ddir.exists() else []
                hits=[Path(x['path']) for x in files if Path(x['path']).name==f'{name}.java']
                cell={'class_name':name,'input_compiler':input_leg,'input_class':pin(class_path),'command':dr['index'],'exit_code':dr['exit_code'],
                      'jadx_version_output':version,'output_files':files,'source':None,'rebuilds':[]}
                if len(hits)==1:
                    sp=hits[0];cell['source']=pin(sp)
                    cell['rebuilds']=compile_and_run(sp,name,f'jadx-{name}-{input_leg}',oracle[(name,input_leg)],'jadx-runtime')
                elif hits: cell['source_error']=f'expected one {name}.java, found {len(hits)}'
                else: cell['source_error']=f'no {name}.java generated (exit {dr["exit_code"]})'
                result['jadx_cells'].append(cell);write_json(out/'execution.json',result)
        result['status']='complete_pending_independent_review'
    except Exception as exc:
        error=exc;result['status']='interrupted';result['failure']=f'{type(exc).__name__}: {exc}'
    finally:
        result['source_pins_after']=compare.source_closure(root)
        result['source_pins_unchanged']=result['source_pins_after']==result['source_pins_before']
        result['inputs_after']={'fixture_sources':{k:pin(v) for k,v in sources.items()},'cli':pin(cli),'jadx':pin(jadx),'jadx_jar':pin(jadx_jar),
           'compare_helpers':pin(COMPARE),'runner':pin(Path(__file__)),'guard':pin(guard_path),'scanner':pin(scanner_path),'jdk_manifest':pin(JDK_MANIFEST),
           'jdk_tools':{leg:{tool:pin(path) for tool,path in row['tools'].items()} for leg,row in jdks.items()}}
        result['inputs_unchanged']=result['inputs_after']==result['inputs_before']
        result['repository_target_absent_after']=not (root/'target').exists() and not (root/'target').is_symlink()
        result['command_count']=len(commands);result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        if not result['source_pins_unchanged'] or not result['inputs_unchanged'] or not result['repository_target_absent_after']:
            result['status']='interrupted';result.setdefault('failure','source/input pins changed or target directory appeared')
        write_json(out/'execution.json',result)
    if error is not None: raise error
    if result['status']!='complete_pending_independent_review': raise RuntimeError('final source/target check failed')
    return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except Exception as exc: raise SystemExit(f'switch baseline collector failed: {type(exc).__name__}: {exc}')
