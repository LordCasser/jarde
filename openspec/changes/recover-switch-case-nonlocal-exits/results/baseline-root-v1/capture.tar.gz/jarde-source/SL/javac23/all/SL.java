// jarde: presentation of `SL` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class SL extends java.lang.Object {
    public SL() {
        // @method <init>()V
        // @declaration a constructor of `SL`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int mixed(int[] xs) {
        // jarde: not recovered: the recovery run for `mixed([I)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method mixed([I)I
        // @declaration a static method of `SL`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 10 16 52 55 58 63 68 71 77
        // local 1 crosses a quoted fallback region; its assignments and consumers cannot be presented as one lexically bound definition-use slice
    }

    static int labeledBreak(int[] xs) {
        // jarde: not recovered: the recovery run for `labeledBreak([I)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method labeledBreak([I)I
        // @declaration a static method of `SL`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 10 16 44 47 58
        // local 1 crosses a quoted fallback region; its assignments and consumers cannot be presented as one lexically bound definition-use slice
    }

    public static void main(java.lang.String[] a) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `SL`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.io.PrintStream saved0 = java.lang.System.out;
        java.lang.StringBuilder saved1 = new java.lang.StringBuilder().append("");
        java.lang.StringBuilder saved2 = saved1.append(mixed(new int[]{1, 2, 4})).append("/");
        java.lang.StringBuilder saved3 = saved2.append(mixed(new int[]{1, 4})).append("/");
        saved0.println((java.lang.String) saved3.append(labeledBreak(new int[]{1, 5, 9})).toString());
        return;
    }
}
