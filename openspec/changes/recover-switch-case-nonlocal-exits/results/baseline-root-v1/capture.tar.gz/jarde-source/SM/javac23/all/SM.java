// jarde: presentation of `SM` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class SM extends java.lang.Object {
    public SM() {
        // @method <init>()V
        // @declaration a constructor of `SM`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int onlyBreak(int[] xs) {
        // @method onlyBreak([I)I
        // @declaration a static method of `SM`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int sum;
        int[] local2;
        int local3;
        int local4;
        sum = 0;
        local2 = xs;
        local3 = local2.length;
        local4 = 0;
        while (local4 < local3) {
            int x = local2[local4];
            switch (x) {
                case 1:
                    break;
                default:
                    sum = sum + x;
                    break;
            }
            sum = sum + 10;
            local4 = local4 + 1;
        }
        return sum;
    }

    static int onlyContinue(int[] xs) {
        // @method onlyContinue([I)I
        // @declaration a static method of `SM`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int sum;
        int[] local2;
        sum = 0;
        local2 = xs;
        for (int x : local2) {
            switch (x) {
                case 2:
                    break;
                default:
                    sum = sum + x;
                    break;
            }
        }
        return sum;
    }

    static int breakNoTail(int[] xs) {
        // @method breakNoTail([I)I
        // @declaration a static method of `SM`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int sum;
        int[] local2;
        sum = 0;
        local2 = xs;
        for (int x : local2) {
            switch (x) {
                case 1:
                    break;
                default:
                    sum = sum + x;
                    break;
            }
        }
        return sum;
    }

    static int ifVersion(int[] xs) {
        // @method ifVersion([I)I
        // @declaration a static method of `SM`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int sum;
        int[] local2;
        int local3;
        int local4;
        sum = 0;
        local2 = xs;
        local3 = local2.length;
        local4 = 0;
        while (local4 < local3) {
            int x = local2[local4];
            if (x == 1) {
            } else {
                sum = sum + x;
            }
            sum = sum + 10;
            local4 = local4 + 1;
        }
        return sum;
    }

    static int noTailMix(int[] xs) {
        // @method noTailMix([I)I
        // @declaration a static method of `SM`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int sum;
        int[] local2;
        sum = 0;
        local2 = xs;
        for (int x : local2) {
            switch (x) {
                case 1:
                    break;
                case 2:
                    break;
                default:
                    sum = sum + x;
                    break;
            }
        }
        return sum;
    }

    public static void main(java.lang.String[] a) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `SM`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.io.PrintStream saved0 = java.lang.System.out;
        java.lang.StringBuilder saved1 = new java.lang.StringBuilder().append("");
        java.lang.StringBuilder saved2 = saved1.append(onlyBreak(new int[]{1, 4})).append("/");
        java.lang.StringBuilder saved3 = saved2.append(onlyContinue(new int[]{2, 4})).append("/");
        java.lang.StringBuilder saved4 = saved3.append(breakNoTail(new int[]{1, 4})).append("/");
        java.lang.StringBuilder saved5 = saved4.append(ifVersion(new int[]{1, 4})).append("/");
        saved0.println((java.lang.String) saved5.append(noTailMix(new int[]{1, 2, 4})).toString());
        return;
    }
}
