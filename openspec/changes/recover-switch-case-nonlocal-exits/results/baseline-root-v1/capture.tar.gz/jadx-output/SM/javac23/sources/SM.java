// default package

/* JADX INFO: loaded from: SM.class */
public class SM {
    static int onlyBreak(int[] xs) {
        int sum = 0;
        for (int x : xs) {
            switch (x) {
                case 1:
                    break;
                default:
                    sum += x;
                    break;
            }
            sum += 10;
        }
        return sum;
    }

    static int onlyContinue(int[] xs) {
        int sum = 0;
        for (int x : xs) {
            switch (x) {
                case 2:
                    break;
                default:
                    sum += x;
                    break;
            }
        }
        return sum;
    }

    static int breakNoTail(int[] xs) {
        int sum = 0;
        for (int x : xs) {
            switch (x) {
                case 1:
                    break;
                default:
                    sum += x;
                    break;
            }
        }
        return sum;
    }

    static int ifVersion(int[] xs) {
        int sum = 0;
        for (int x : xs) {
            if (x != 1) {
                sum += x;
            }
            sum += 10;
        }
        return sum;
    }

    static int noTailMix(int[] xs) {
        int sum = 0;
        for (int x : xs) {
            switch (x) {
                case 1:
                case 2:
                    break;
                default:
                    sum += x;
                    break;
            }
        }
        return sum;
    }

    public static void main(String[] a) {
        System.out.println("" + onlyBreak(new int[]{1, 4}) + "/" + onlyContinue(new int[]{2, 4}) + "/" + breakNoTail(new int[]{1, 4}) + "/" + ifVersion(new int[]{1, 4}) + "/" + noTailMix(new int[]{1, 2, 4}));
    }
}
