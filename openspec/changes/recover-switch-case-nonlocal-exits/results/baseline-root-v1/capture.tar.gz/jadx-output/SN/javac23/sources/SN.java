// default package

/* JADX INFO: loaded from: SN.class */
public class SN {
    static int retInSwitchNoTail(int[] xs) {
        int sum = 0;
        for (int x : xs) {
            switch (x) {
                case 3:
                    return sum + 100;
                default:
                    sum += x;
                    break;
            }
        }
        return sum;
    }

    static int retInSwitchTail(int[] xs) {
        int sum = 0;
        for (int x : xs) {
            switch (x) {
                case 3:
                    return sum + 100;
                default:
                    sum = sum + x + 10;
                    break;
            }
        }
        return sum;
    }

    static int retAfterTail(int[] xs) {
        int sum = 0;
        for (int x : xs) {
            if (x == 3) {
                return sum + 100;
            }
            sum = sum + x + 10;
        }
        return sum;
    }

    static int labBreak(int[] xs) {
        int sum = 0;
        for (int x : xs) {
            switch (x) {
                case 5:
                    break;
                default:
                    sum += x;
                    break;
            }
            return sum;
        }
        return sum;
    }

    public static void main(String[] a) {
        System.out.println("" + retInSwitchNoTail(new int[]{1, 3}) + "/" + retInSwitchTail(new int[]{1, 3}) + "/" + retAfterTail(new int[]{1, 3}) + "/" + labBreak(new int[]{1, 5}));
    }
}
