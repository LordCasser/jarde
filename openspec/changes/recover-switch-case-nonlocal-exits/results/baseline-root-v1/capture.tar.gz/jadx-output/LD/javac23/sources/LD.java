// default package

/* JADX INFO: loaded from: LD.class */
public class LD {
    static int lab(int[] xs) {
        int s = 0;
        for (int x : xs) {
            switch (x) {
                case 5:
                    break;
                default:
                    s += x;
                    break;
            }
            return s;
        }
        return s;
    }

    public static void main(String[] a) {
        System.out.println(lab(new int[]{9, 1, 5}));
    }
}
