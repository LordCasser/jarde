// default package

/* JADX INFO: loaded from: SL.class */
public class SL {
    static int mixed(int[] xs) {
        int sum = 0;
        for (int x : xs) {
            switch (x) {
                case 1:
                    break;
                case 2:
                    continue;
                    break;
                case 3:
                    return sum + 100;
                default:
                    sum += x;
                    break;
            }
            sum += 10;
        }
        return sum;
    }

    static int labeledBreak(int[] xs) {
        int sum = 0;
        for (int x : xs) {
            switch (x) {
                case 5:
                    break;
                default:
                    sum += x;
                    break;
            }
            return sum;
        }
        return sum;
    }

    public static void main(String[] a) {
        System.out.println("" + mixed(new int[]{1, 2, 4}) + "/" + mixed(new int[]{1, 4}) + "/" + labeledBreak(new int[]{1, 5, 9}));
    }
}
