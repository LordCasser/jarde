#!/usr/bin/env python3
"""Bind a completed guarded run's complete source pin map to an exact Git tree."""
import hashlib,json,pathlib,subprocess,sys
ROOT=pathlib.Path('/Users/lordcasser/workspace/projects/jarde')
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    receipt,out,product=sys.argv[1:]
    assert len(product)==40 and all(c in '0123456789abcdef' for c in product)
    out=pathlib.Path(out);out.mkdir(parents=True,exist_ok=False)
    receipt=pathlib.Path(receipt);raw=receipt.read_bytes();doc=json.loads(raw)
    assert doc['status']=='passed' and doc.get('pins_unchanged') is True
    pins=dict(doc['source_pins']);assert pins==doc['source_pins_before_format']==doc['source_pins_after_format']
    run_source_count=len(pins)
    build_path=pathlib.Path('/private/tmp/jarde-switch-gates-root-v3-20261018/execution.json')
    build_raw=build_path.read_bytes();build=json.loads(build_raw)
    assert build['status']=='commands_passed_pending_independent_acceptance' and build['source_changes_accepted'] is True
    assert build['source_changes']==['tests/fixtures/corpus-fingerprint.json']
    cli=build['cli'];cli_bytes=pathlib.Path(cli['path']).read_bytes()
    assert len(cli_bytes)==cli['bytes']==62908496
    assert sha(cli_bytes)==cli['sha256']=='10a73d1ee30a3820a018a2461cc3c3b3028b02bf658588bc74c4ec3ba2eb1620'
    for row in build['source_after']:
        rel=pathlib.Path(row['path']).relative_to(ROOT).as_posix()
        assert rel not in pins or pins[rel]==row['sha256'],rel
        pins[rel]=row['sha256']
    argv=['git','ls-tree','-r','-z',product]
    p=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (out/'tree.stdout.raw').write_bytes(p.stdout);(out/'tree.stderr.raw').write_bytes(p.stderr)
    assert p.returncode==0
    tree={}
    for row in p.stdout.split(b'\0'):
        if not row:continue
        meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();tree[name.decode()]={'mode':mode,'kind':kind,'oid':oid}
    files={}
    for rel,expected in pins.items():
        b=(ROOT/rel).read_bytes();assert sha(b)==expected,rel
        row=tree[rel];assert row['kind']=='blob' and row['mode'] in ('100644','100755'),rel
        blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
        assert blob==row['oid'],rel
        assert ('100755' if (ROOT/rel).stat().st_mode & 0o111 else '100644')==row['mode'],rel
        files[rel]={'bytes':len(b),'sha256':expected,**row}
    review={'status':'accepted','product_sha':product,'receipt':{'path':str(receipt.resolve()),'bytes':len(raw),'sha256':sha(raw)},'source_count':len(files),'workspace_source_count':run_source_count,'compiled_source_count':len(build['source_after']),'compiled_receipt':{'path':str(build_path),'bytes':len(build_raw),'sha256':sha(build_raw),'cli':build['cli']},'complete_receipt_source_set_bound':True,'source_bytes':sum(v['bytes'] for v in files.values()),'files':files,'tree_command':{'argv':argv,'exit_code':p.returncode,'stdout':{'bytes':len(p.stdout),'sha256':sha(p.stdout)},'stderr':{'bytes':len(p.stderr),'sha256':sha(p.stderr)}}}
    (out/'root-review.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in review.items() if k not in ('files','tree_command')}))
if __name__=='__main__':main()
