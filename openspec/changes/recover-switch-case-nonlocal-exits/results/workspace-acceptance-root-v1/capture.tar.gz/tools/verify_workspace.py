#!/usr/bin/env python3
"""Supplemental offline audit for two terminal full-workspace Cargo test receipts."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

EXPECTED_SCHEMA = "finthrow-full-workspace-seed-replay-v1"
GATES = [
    ("p3_loop_terminal_return", "decoded_switch_case_returns_are_loop_terminal_leaves"),
    ("p3_loop_terminal_return", "four_way_switch_return_leaf_has_one_owner"),
    ("p3_loop_terminal_return", "switch_outer_breaks_keep_loop_owner_and_transfer_source"),
    ("p3_loop_terminal_return", "switch_loop_join_late_budget_cancel_and_deadline_publish_no_partial_source"),
    ("jarde_java", "region::switch_nonlocal_completion_tests::real_switch_return_certificate_and_target_boundaries_refuse_without_claims"),
    ("jarde_java", "region::switch_nonlocal_completion_tests::real_extra_entry_is_not_owned_by_the_switch_join_certificate"),
    ("jarde_java", "region::switch_nonlocal_completion_tests::exception_edge_incident_to_real_loop_switch_refuses_strict_completion"),
    ("jarde_java", "region::switch_nonlocal_completion_tests::direct_completion_edge_is_bound_to_its_real_jsr_clone"),
    ("p3_switch_nonlocal_late_stop", "late_request_budget_does_not_publish_a_partial_switch_return_method"),
]
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
RUNNING = re.compile(r"^\s*Running\s+(.+?)\s+\((.+)\)\s*$")
HARNESS_START = re.compile(r"^running (\d+) tests?$")
TEST_LINE = re.compile(r"^test (.+?) \.\.\. (ok|FAILED|ignored)(?:,.*)?$")
SUMMARY = re.compile(
    r"^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;"
)

class AuditError(Exception):
    pass

def need(ok: bool, msg: str) -> None:
    if not ok:
        raise AuditError(msg)

def read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise AuditError(f"cannot parse {path}: {exc}") from exc

def target_key(raw):
    need(isinstance(raw, list) and len(raw) == 3, f"bad target identity: {raw!r}")
    return tuple(str(x) for x in raw)

def count_key(raw):
    key = target_key(raw.get("target"))
    counts = raw.get("counts")
    need(isinstance(counts, list) and len(counts) == 3 and all(type(x) is int for x in counts),
         f"bad recorded count tuple for {key}: {counts!r}")
    return key, tuple(counts)

def read_raw(stream, where):
    need(isinstance(stream, dict), f"{where}: missing stream record")
    path = Path(stream.get("path", ""))
    need(path.is_file(), f"{where}: raw file missing: {path}")
    data = path.read_bytes()
    need(len(data) == stream.get("bytes"), f"{where}: raw byte length mismatch")
    digest = hashlib.sha256(data).hexdigest()
    need(digest == stream.get("sha256"), f"{where}: raw sha256 mismatch")
    return data

def artifacts_from_stdout(data, where):
    out = []
    for line in data.decode("utf-8", "replace").splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(item, dict) or item.get("reason") != "compiler-artifact":
            continue
        if not (item.get("profile") or {}).get("test"):
            continue
        target = item.get("target") or {}
        exe = item.get("executable")
        if not exe:
            continue
        kinds = target.get("kind") or []
        kind = "test" if "test" in kinds else ("example" if "example" in kinds else (kinds[0] if kinds else ""))
        out.append({
            "key": (str(item.get("package_id", "")), str(target.get("name", "")), kind),
            "executable": str(exe),
            "basename": Path(str(exe)).name,
        })
    need(out, f"{where}: no compiler-artifact executable records")
    return out

def running_targets(stderr_data, artifacts, planned, where):
    text = ANSI.sub("", stderr_data.decode("utf-8", "replace"))
    launches = []
    for line in text.splitlines():
        match = RUNNING.match(line)
        if not match:
            continue
        display, exe_path = match.groups()
        basename = Path(exe_path.strip()).name
        candidates = [a for a in artifacts if a["basename"] == basename]
        need(len(candidates) == 1, f"{where}: Running executable {basename!r} maps to {len(candidates)} compiler artifacts")
        key = candidates[0]["key"]
        need(key in planned, f"{where}: Running target absent from batch plan: {key}")
        launches.append({"target": key, "display": display.strip(), "executable": exe_path.strip()})
    need(launches, f"{where}: stderr contains no Cargo Running harness entries")
    keys = [x["target"] for x in launches]
    need(len(keys) == len(set(keys)), f"{where}: a test target was launched more than once")
    need(set(keys) == planned, f"{where}: stderr Running targets differ from planned targets: launched={sorted(keys)}, planned={sorted(planned)}")
    return launches

def harness_blocks(stdout_data, where):
    text = ANSI.sub("", stdout_data.decode("utf-8", "replace"))
    blocks = []
    active = None
    for line in text.splitlines():
        start = HARNESS_START.match(line.strip())
        if start:
            need(active is None, f"{where}: nested harness start before prior summary")
            active = {"declared": int(start.group(1)), "tests": [], "summary": None}
            continue
        if active is None:
            continue
        m = TEST_LINE.match(line.strip())
        if m:
            active["tests"].append((m.group(1), m.group(2)))
            continue
        m = SUMMARY.match(line.strip())
        if m:
            active["summary"] = tuple(int(v) for v in m.groups())
            passed, failed, ignored = active["summary"]
            observed = (sum(s == "ok" for _, s in active["tests"]),
                        sum(s == "FAILED" for _, s in active["tests"]),
                        sum(s == "ignored" for _, s in active["tests"]))
            need(observed == active["summary"], f"{where}: harness status lines {observed} disagree with summary {active['summary']}")
            need(active["declared"] == sum(active["summary"]), f"{where}: running count disagrees with summary")
            blocks.append(active)
            active = None
    need(active is None, f"{where}: unterminated test harness output")
    return blocks

def validate_one(path: Path):
    x = read_json(path)
    need(x.get("schema") == EXPECTED_SCHEMA, f"{path}: unexpected schema {x.get('schema')!r}")
    need(x.get("status") == "passed", f"{path}: execution is not terminal passed (status={x.get('status')!r}); partial runs cannot be accepted")
    for field in ("no_carried_execution", "target_absent_before", "pins_unchanged", "target_absent_after_clean"):
        need(x.get(field) is True, f"{path}: {field} is not true")
    need(x.get("finished_utc"), f"{path}: missing finished timestamp")
    pins_before = x.get("source_pins_before_format")
    pins = x.get("source_pins")
    pins_after = x.get("source_pins_after_format")
    need(isinstance(pins_before, dict) and isinstance(pins, dict) and isinstance(pins_after, dict), f"{path}: missing source pin maps")
    need(pins_before == pins == pins_after, f"{path}: source pins changed during formatting/run")
    commands = x.get("commands")
    plan = x.get("batch_plan")
    need(isinstance(commands, list) and isinstance(plan, list), f"{path}: missing command/batch plan arrays")
    expected_batches = x.get("expected_batch_count")
    need(expected_batches == len(plan) == len(commands), f"{path}: not every planned batch reached a receipt")
    need(str(x.get("seed", "")), f"{path}: missing seed")
    command_slots = list(commands)
    need(len({c.get("index") for c in command_slots}) == len(command_slots), f"{path}: duplicate command indexes")
    all_counts = {}
    gate_occurrences = {g: [] for g in GATES}
    batch_receipts = []
    need(len(command_slots) == len(plan), f"{path}: command count does not match batch plan")
    for plan_index, planned_batch in enumerate(plan):
        matches = [c for c in command_slots
                   if c.get("argv") == planned_batch.get("argv")
                   and c.get("planned_targets") == planned_batch.get("planned_targets")]
        need(len(matches) == 1, f"{path}: batch plan {plan_index} maps to {len(matches)} command receipts")
        cmd = matches[0]
        index = cmd.get("index")
        command_slots.remove(cmd)
        label = f"{path.name} command {index}/plan {plan_index}"
        need(cmd.get("exit_code") == 0 and cmd.get("guard_stop") is None, f"{label}: command did not finish cleanly")
        need(cmd.get("peak_target_bytes") is None or isinstance(cmd.get("peak_target_bytes"), int), f"{label}: invalid peak target field")
        streams = cmd.get("streams") or {}
        stdout = read_raw(streams.get("stdout"), f"{label} stdout")
        stderr = read_raw(streams.get("stderr"), f"{label} stderr")
        planned_raw = planned_batch.get("planned_targets")
        recorded_planned = cmd.get("planned_targets")
        need(recorded_planned == planned_raw, f"{label}: command target plan differs from manifest")
        planned_keys = {target_key(t) for t in planned_raw}
        need(len(planned_keys) == len(planned_raw), f"{label}: duplicate planned targets")
        artifacts = artifacts_from_stdout(stdout, label)
        art_keys = [a["key"] for a in artifacts if a["key"] in planned_keys]
        need(set(art_keys) == planned_keys, f"{label}: compiler-artifact set does not cover planned test targets")
        launches = running_targets(stderr, artifacts, planned_keys, label)
        blocks = harness_blocks(stdout, label)
        need(len(blocks) == len(launches), f"{label}: {len(launches)} stderr Running entries but {len(blocks)} stdout harness summaries")
        env = cmd.get("env_overrides") or {}
        need(env.get("CARGO_BUILD_JOBS") == "1", f"{label}: expected serialized Cargo test execution")
        need(env.get("RUST_TEST_THREADS") == "1", f"{label}: expected serialized test-harness execution")
        batch_counts = []
        for launch, block in zip(launches, blocks):
            key = launch["target"]
            counts = block["summary"]
            need(counts[1] == 0, f"{label}: target {key[1]} reports failed tests")
            need(key not in all_counts, f"{path.name}: target executed in multiple batches: {key}")
            all_counts[key] = counts
            batch_counts.append({"target": list(key), "counts": list(counts), "running": launch["display"],
                                 "harness_test_names": [name for name, _ in block["tests"]]})
            for gate in GATES:
                if key[1] == gate[0]:
                    gate_occurrences[gate].extend((key, name, status) for name, status in block["tests"] if name == gate[1])
        batch_receipts.append({"index": index, "targets_in_stderr_running_order": [list(x["target"]) for x in launches],
                               "target_counts_bound_by_running_order": batch_counts})
    need(len(all_counts) == len(x.get("target_inventory", [])), f"{path}: reconstructed target count differs from target inventory")
    inventory_keys = {target_key(t) for t in x["target_inventory"]}
    need(set(all_counts) == inventory_keys, f"{path}: executed target identities differ from metadata inventory")
    need(x.get("workspace_summary_count") == len(all_counts), f"{path}: workspace summary count differs from reconstructed harness count")
    totals = tuple(sum(counts[i] for counts in all_counts.values()) for i in range(3))
    need(tuple(x.get("workspace_totals", [])) == totals, f"{path}: workspace totals differ from reconstructed harness counts")
    # The fixed gate list is target-qualified; each must be present once and pass in its own harness.
    gate_receipts = []
    for gate in GATES:
        target_kinds = [key for key in inventory_keys if key[1] == gate[0]]
        need(len(target_kinds) == 1, f"{path}: gate target name {gate[0]!r} maps to {len(target_kinds)} metadata targets")
        gate_target = target_kinds[0]
        expected_kind = "lib" if gate[0] == "jarde_java" else "test"
        need(gate_target[2] == expected_kind, f"{path}: gate target {gate[0]} has unexpected kind {gate_target[2]!r}")
        hits = gate_occurrences[gate]
        need(len(hits) == 1, f"{path}: gate {gate} occurred {len(hits)} times, expected once")
        key, name, status = hits[0]
        need(key == gate_target and status == "ok", f"{path}: gate {gate} is not ok under its designated target")
        gate_receipts.append({"target": gate[0], "test": gate[1], "status": status, "full_target_id": list(key)})
    return {"path": str(path), "status": x["status"], "seed": str(x["seed"]),
            "source_pin_count": len(pins), "source_pins_sha256": hashlib.sha256(json.dumps(pins, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
            "target_count": len(all_counts), "target_counts": [{"target": list(k), "counts": list(v)} for k, v in sorted(all_counts.items())],
            "batch_receipts": batch_receipts, "critical_gates": gate_receipts}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("seed1", type=Path)
    ap.add_argument("seed2", type=Path)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    try:
        a = validate_one(args.seed1)
        b = validate_one(args.seed2)
        need(a["seed"] != b["seed"], "the two receipts must use distinct seeds")
        need(a["source_pins_sha256"] == b["source_pins_sha256"], "source pin maps differ across seeds")
        ca = {tuple(x["target"]): tuple(x["counts"]) for x in a["target_counts"]}
        cb = {tuple(x["target"]): tuple(x["counts"]) for x in b["target_counts"]}
        need(ca == cb, "per-target test count maps differ between seeds")
        report = {"schema": "switch-workspace-supplemental-review-v1", "status": "passed",
                  "source_pin_parity": {"passed": True, "sha256": a["source_pins_sha256"], "count": a["source_pin_count"]},
                  "target_parity": {"passed": True, "target_count": len(ca), "counts_equal_by_target_identity": True},
                  "seed1": a, "seed2": b,
                  "critical_gate_count": len(GATES), "critical_gates_each_seed_once_ok": True,
                  "method": "stdout harness summaries are associated positionally with stderr Running records after requiring CARGO_BUILD_JOBS=1; target identity is recovered from executable basename to compiler-artifact identity, never by artifact order."}
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(json.dumps({"status": "passed", "output": str(args.output), "targets": len(ca), "gates_per_seed": len(GATES)}, sort_keys=True))
        return 0
    except (AuditError, OSError) as exc:
        print(f"AUDIT FAILED: {exc}", file=sys.stderr)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
