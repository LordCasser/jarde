# Root accepted native workspace replay

Exact product cf857abaabc4fcff82689812226f9906b8d932b2. Both fixed fresh seeds passed: each 382 targets / 100 batches / 3716 passed / 0 failed / 98 ignored. The standard repository workspace_acceptor rechecked all 412 raw streams, guard/JDK/default-stack/source invariants, clean commands and target absence. The supplemental root-reviewed verifier reconstructs target identities from actual stderr Running order, verifies each of the nine new switch gates once per seed and compares every per-target count tuple. Artifact order is not used as execution order.

Both complete 5016-file workspace maps and the final CLI's 3063-file build closure bind byte-for-byte and by mode to the exact product Git tree (5023-file union). No test success is inferred merely from this source binding. CLI SHA256 is 10a73d1ee30a3820a018a2461cc3c3b3028b02bf658588bc74c4ec3ba2eb1620, 62908496 bytes; semantic/API matrices and final lint/MSRV/P5 evidence are separately archived.

Both runs started without target, used the default stack and the existing 5GiB / target1GiB one-second process-group guard, and finally ran exact cargo clean. Product own-CI acceptance and final clean-main delivery are separate gates; they were pending at this native capture checkpoint.
