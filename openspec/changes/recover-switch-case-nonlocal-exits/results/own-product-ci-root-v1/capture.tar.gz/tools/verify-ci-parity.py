#!/usr/bin/env python3
"""Accept own-CI verifier output only when its two workspace seeds have identical target summaries."""
import hashlib, json, sys
from pathlib import Path
SEEDS = ("5350648285461741569", "5350648285461741570")
CRITICAL = 27
NEW_CRITICAL = ['decoded_switch_case_returns_are_loop_terminal_leaves', 'four_way_switch_return_leaf_has_one_owner', 'switch_outer_breaks_keep_loop_owner_and_transfer_source', 'switch_loop_join_late_budget_cancel_and_deadline_publish_no_partial_source', 'real_switch_return_certificate_and_target_boundaries_refuse_without_claims', 'real_extra_entry_is_not_owned_by_the_switch_join_certificate', 'exception_edge_incident_to_real_loop_switch_refuses_strict_completion', 'direct_completion_edge_is_bound_to_its_real_jsr_clone', 'late_request_budget_does_not_publish_a_partial_switch_return_method']

def need(ok, message):
    if not ok: raise ValueError(message)

def main():
    if len(sys.argv) != 4:
        raise ValueError("usage: verify-ci-parity.py OWN_CI_VERIFIER.json NEW_ROOT_REVIEW.json PRODUCT_SHA")
    source, output = map(Path, sys.argv[1:3]); product = sys.argv[3]
    need(len(product) == 40 and all(c in "0123456789abcdef" for c in product), "PRODUCT_SHA must be a lowercase full SHA")
    raw = source.read_bytes(); doc = json.loads(raw)
    need(not output.exists(), f"refusing to overwrite output: {output}")
    need(doc.get("status") == "accepted", "own-CI verifier status is not accepted")
    need(doc.get("product", {}).get("head_sha") == product and doc.get("product", {}).get("expected_sha") == product,
         "own-CI verifier is not bound to the exact product")
    ci = doc.get("ci", {})
    jobs = ci.get("jobs", {})
    workflow = doc.get("workflow", {}).get("workflow_api_steps", {})
    need(isinstance(jobs, dict) and len(jobs) == ci.get("job_count"), "CI job inventory is malformed")
    need(isinstance(workflow, dict) and set(workflow) == set(jobs), "workflow step inventory differs from CI jobs")
    observed_steps = sum(row.get("api_step_count", -1) for row in jobs.values())
    need(observed_steps == ci.get("expanded_api_step_count"), "derived API step total differs from validated CI report")
    runs = doc.get("workspace_seed_runs")
    need(isinstance(runs, list) and len(runs) == 2, "expected exactly two workspace seed runs")
    need(tuple(str(r.get("seed")) for r in runs) == SEEDS, "workspace seed order does not match the fixed pair")
    summaries = [] ; totals = []
    for seed, run in zip(SEEDS, runs):
        critical = run.get("critical_tests_passed")
        need(isinstance(critical, dict) and len(critical) == CRITICAL, f"seed {seed}: expected all 27 critical tests")
        need(isinstance(critical, dict) and all(critical.get(k) == name for k, name in zip((
            "switch case return leaf", "switch four-way return leaf", "switch outer break ownership",
            "switch join budget cancel deadline", "switch return certificate boundaries",
            "switch extra entry refusal", "switch exception edge refusal", "switch cloned completion edge",
            "switch public late stop"), NEW_CRITICAL)),
             f"seed {seed}: one or more new switch gates are absent or mismatched")
        rows = run.get("target_summaries")
        need(isinstance(rows, list) and rows, f"seed {seed}: target_summaries is missing")
        for row in rows:
            need(isinstance(row, dict) and all(k in row for k in ("target_header", "target_executable", "target_name", "named_tests", "passed", "failed", "ignored", "measured", "filtered")),
                 f"seed {seed}: incomplete target summary row")
        total = {k:sum(r[k] for r in rows) for k in ("named_tests", "passed", "failed", "ignored", "measured", "filtered")}
        need(total["failed"] == 0, f"seed {seed}: failures in derived target totals")
        if "workspace_totals" in run:
            need(all(run["workspace_totals"].get(k) == total[k] for k in ("passed", "failed", "ignored", "measured", "filtered")),
                 f"seed {seed}: stored workspace totals disagree with target rows")
        summaries.append(rows); totals.append(total)
    need(summaries[0] == summaries[1], "the two seeds' complete target_summaries differ")
    report = {"status":"accepted", "product_sha":product, "ci":{"job_count":ci["job_count"],"expanded_api_step_count":observed_steps},
              "input":{"path":str(source),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()},
              "seed_order":list(SEEDS),"target_summaries_equal":True,
              "workspace_seed_runs":[{"seed":seed,"target_count":len(summaries[i]),"critical_tests_passed":CRITICAL,"derived_totals":totals[i]} for i,seed in enumerate(SEEDS)]}
    payload=json.dumps(report,indent=2,sort_keys=True)+"\n"
    with output.open("x",encoding="utf-8") as f: f.write(payload)
    print(f"accepted: {len(summaries[0])} target summaries match across both seeds; review: {output}")
    return 0

if __name__ == "__main__":
    try: raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        raise SystemExit(f"CI parity review failed: {exc}")
