#!/usr/bin/env python3
"""Read-only acceptance of this product commit's own GitHub Actions CI evidence."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

WORKSPACE_COMMAND = "cargo test --workspace --all-targets --all-features --locked"
SEEDS = ("5350648285461741569", "5350648285461741570")
EXPECTED_JOBS = {
    "stable": "stable / test and specification",
    "msrv": "MSRV 1.88.0",
    "supply-chain": "supply chain",
    "fuzz-smoke": "fuzz smoke",
}
CRITICAL_TESTS = {
    "public positive, independent source": "both_compilers_recover_the_independent_complete_source_with_all_physical_origins",
    "public positive, sealed originals": "both_sealed_originals_recover_only_the_throwing_target_and_keep_all_seven_methods",
    "public late budget stop": "public_late_analysis_stop_does_not_publish_a_partial_finally_body_or_map",
    "public pre-cancel stop": "public_precancel_reports_no_class_text_or_target_method",
    "guard canonical proof": "exception_only_finally_proves_independent_compilers_and_both_binding_row_boundaries",
    "guard canonical neighbors": "exception_only_finally_refuses_only_complete_canonical_semantic_neighbors",
    "guard budget cancel deadline": "exception_only_finally_stops_at_real_budget_cancel_and_deadline_checkpoints",
    "guard eliminated entry parameter phi": "exception_only_finally_accepts_only_eliminated_entry_parameter_phis",
    "Builder transaction rollback": "exception_only_finally_builder_restores_every_budget_stop",
    "direct-array library composition": "direct_array_constructor_arguments_are_composed_for_both_javac_legs",
    "direct-array library receiver identity": "same_owner_nested_constructors_select_the_matching_receiver",
    "direct-array library effect order": "verified_swap_does_not_reorder_effectful_direct_array_arguments",
    "direct-array public class-source matrix": "direct_array_arguments_generalize_across_both_javac_fixtures_and_evidence_modes",
    "direct-array public late stop": "public_late_analysis_stop_does_not_publish_a_partial_construction_body_or_map",
    "direct-array public pre-cancel": "public_precancel_reports_no_class_text_or_target_method",
    "original TestFinally3 debug profiles": "original_test_finally3_debug_profiles_keep_all_methods_and_array_origins",
    "constructed-array public composition dependency": "constructed_reference_array_elements_recover_as_one_complete_same_snapshot_family",
    "switch case return leaf": "decoded_switch_case_returns_are_loop_terminal_leaves",
    "switch four-way return leaf": "four_way_switch_return_leaf_has_one_owner",
    "switch outer break ownership": "switch_outer_breaks_keep_loop_owner_and_transfer_source",
    "switch join budget cancel deadline": "switch_loop_join_late_budget_cancel_and_deadline_publish_no_partial_source",
    "switch return certificate boundaries": "real_switch_return_certificate_and_target_boundaries_refuse_without_claims",
    "switch extra entry refusal": "real_extra_entry_is_not_owned_by_the_switch_join_certificate",
    "switch exception edge refusal": "exception_edge_incident_to_real_loop_switch_refuses_strict_completion",
    "switch cloned completion edge": "direct_completion_edge_is_bound_to_its_real_jsr_clone",
    "switch public late stop": "late_request_budget_does_not_publish_a_partial_switch_return_method",
    "reader fixture census": "repository_class_fixtures_validate_without_false_target_rejections",
}
CRITICAL_TEST_TARGETS = {
    "public positive, independent source": "recover_exception_only_finally_completion",
    "public positive, sealed originals": "recover_exception_only_finally_completion",
    "public late budget stop": "recover_exception_only_finally_stops",
    "public pre-cancel stop": "recover_exception_only_finally_stops",
    "guard canonical proof": "jarde_java",
    "guard canonical neighbors": "jarde_java",
    "guard budget cancel deadline": "jarde_java",
    "guard eliminated entry parameter phi": "jarde_java",
    "Builder transaction rollback": "jarde_java",
    "direct-array library composition": "jarde_java",
    "direct-array library receiver identity": "jarde_java",
    "direct-array library effect order": "jarde_java",
    "direct-array public class-source matrix": "recover_direct_array_constructor_arguments",
    "direct-array public late stop": "recover_direct_array_constructor_stops",
    "direct-array public pre-cancel": "recover_direct_array_constructor_stops",
    "original TestFinally3 debug profiles": "recover_original_test_finally3",
    "constructed-array public composition dependency": "p3_constructed_reference_array_elements",
    "switch case return leaf": "p3_loop_terminal_return",
    "switch four-way return leaf": "p3_loop_terminal_return",
    "switch outer break ownership": "p3_loop_terminal_return",
    "switch join budget cancel deadline": "p3_loop_terminal_return",
    "switch return certificate boundaries": "jarde_java",
    "switch extra entry refusal": "jarde_java",
    "switch exception edge refusal": "jarde_java",
    "switch cloned completion edge": "jarde_java",
    "switch public late stop": "p3_switch_nonlocal_late_stop",
    "reader fixture census": "jarde_reader",
}
PRODUCT_SOURCE_PATHS = (
    ".github/workflows/ci.yml",
    "crates/jarde-java/src/init.rs",
    "crates/jarde-java/src/build.rs",
    "crates/jarde-java/src/report.rs",
    "crates/jarde-java/src/guard.rs",
    "crates/jarde-reader/src/classfile.rs",
    "tests/recover_direct_array_constructor_arguments.rs",
    "tests/recover_direct_array_constructor_stops.rs",
    "tests/recover_original_test_finally3.rs",
    "tests/p3_constructed_reference_array_elements.rs",
    "tests/fixtures/constructor-direct-array-arguments/fixture-pins.json",
    "tests/fixtures/constructor-direct-array-arguments/DirectArrayConstructorArguments.java",
    "tests/fixtures/constructor-direct-array-arguments/same-owner/SameOwnerArrayArguments.java",
    "tests/fixtures/constructor-direct-array-arguments/reverse-order/ReverseArrayOrder.java",
    "tests/fixtures/corpus-fingerprint.json",
    "crates/jarde-java/src/region.rs",
    "crates/jarde-java/src/region/switch_nonlocal_completion_tests.rs",
    "crates/jarde-java/tests/p3_loop_terminal_return.rs",
    "tests/p3_switch_nonlocal_late_stop.rs",
    "tests/fixtures/p3-switch-jsr-clones/README.md",
    "tests/fixtures/p3-switch-jsr-clones/SwitchLoopJsrCloneDriver.java",
    "tests/fixtures/p3-switch-jsr-clones/generate.py",
    "tests/fixtures/p3-switch-jsr-clones/manifest.json",
    "tests/fixtures/p3-switch-jsr-clones/v49/SwitchLoopJsrClone.class",
    "tests/fixtures/p3-switch-nonlocal-exits/README.md",
    "tests/fixtures/p3-switch-nonlocal-exits/javac23/LD.class",
    "tests/fixtures/p3-switch-nonlocal-exits/javac23/SL.class",
    "tests/fixtures/p3-switch-nonlocal-exits/javac23/SM.class",
    "tests/fixtures/p3-switch-nonlocal-exits/javac23/SN.class",
    "tests/fixtures/p3-switch-nonlocal-exits/javac8/LD.class",
    "tests/fixtures/p3-switch-nonlocal-exits/javac8/SL.class",
    "tests/fixtures/p3-switch-nonlocal-exits/javac8/SM.class",
    "tests/fixtures/p3-switch-nonlocal-exits/javac8/SN.class",
    "tests/fixtures/p3-switch-nonlocal-exits/manifest.json",
    "tests/fixtures/p3-switch-nonlocal-exits/source/LD.java",
    "tests/fixtures/p3-switch-nonlocal-exits/source/SL.java",
    "tests/fixtures/p3-switch-nonlocal-exits/source/SM.java",
    "tests/fixtures/p3-switch-nonlocal-exits/source/SN.java",
    "tests/fixtures/switch-loop-exception-boundary/README.md",
    "tests/fixtures/switch-loop-exception-boundary/SwitchLoopExceptionBoundary.java",
    "tests/fixtures/switch-loop-exception-boundary/javac23/SwitchLoopExceptionBoundary.class",
    "tests/fixtures/switch-loop-exception-boundary/javac8/SwitchLoopExceptionBoundary.class",
    "tests/fixtures/switch-loop-exception-boundary/manifest.json",
)
FIXTURE_PIN_PATH = "tests/fixtures/constructor-direct-array-arguments/fixture-pins.json"

ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
GROUP_PREFIX = "##[group]Run "
SUMMARY = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
    r"(\d+) measured; (\d+) filtered out(?:; finished in .*)?$"
)
NAME_FRAGMENT = r"(?:[A-Za-z0-9_]|(?<!\*)\*\*\*(?!\*))+"
OUTCOME = re.compile(
    rf"^test ((?:{NAME_FRAGMENT})(?:::(?:{NAME_FRAGMENT}))*)(?: - should panic)? \.\.\. "
    r"(ok|FAILED|ignored(?:, .*)?)$"
)
RUNNING = re.compile(r"^running (\d+) tests?$", re.IGNORECASE)
RUN_TARGET = re.compile(r"^Running .+ \((?P<path>[^()]+)\)$")
HASHED_CARGO_EXECUTABLE = re.compile(r"(?P<target>[^/]+)-(?P<hash>[0-9a-f]{16})")


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def workflow_contract(path: Path):
    """Read the live workflow's job names, named run steps, and seed order."""
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    jobs: dict[str, dict] = {}
    current_job = None
    inside_jobs = False
    i = 0
    while i < len(lines):
        if lines[i] == "jobs:":
            inside_jobs = True
            i += 1
            continue
        if inside_jobs and re.match(r"^[^ ]", lines[i]):
            inside_jobs = False
        job_match = re.match(r"^  ([a-z][a-z0-9-]*):\s*$", lines[i]) if inside_jobs else None
        if job_match:
            current_job = job_match.group(1)
            jobs[current_job] = {"display": None, "run_steps": [], "steps": [], "workflow_api_steps": []}
            j = i + 1
            while j < len(lines) and not re.match(r"^  [a-z][a-z0-9-]*:\s*$", lines[j]):
                name_match = re.match(r"^    name:\s*(.*?)\s*$", lines[j])
                if name_match and jobs[current_job]["display"] is None:
                    jobs[current_job]["display"] = name_match.group(1).strip('"\'')
                step_match = re.match(r"^      - (name|uses):\s*(.*?)\s*$", lines[j])
                if step_match:
                    step_key, step_value = step_match.group(1), step_match.group(2).strip('"\'')
                    k = j + 1
                    has_run = False
                    uses_value = step_value if step_key == "uses" else None
                    while k < len(lines) and not re.match(r"^      - (?:name|uses):", lines[k]) and not re.match(r"^  [a-z][a-z0-9-]*:\s*$", lines[k]):
                        uses_match = re.match(r"^        uses:\s*(.*?)\s*$", lines[k])
                        if uses_match:
                            uses_value = uses_match.group(1).strip('"\'')
                        if re.match(r"^        run:\s*", lines[k]):
                            has_run = True
                        k += 1
                    if step_key == "name":
                        step_name = step_value
                        jobs[current_job]["steps"].append(step_name)
                        if has_run:
                            jobs[current_job]["run_steps"].append(step_name)
                    else:
                        need(bool(uses_value), f"workflow step has no action in {current_job}: {lines[j]}")
                        step_name = f"Run {uses_value}"
                    jobs[current_job]["workflow_api_steps"].append(step_name)
                    j = k - 1
                j += 1
            i = j - 1
        i += 1
    need(set(jobs) == set(EXPECTED_JOBS), f"workflow job IDs changed: {sorted(jobs)}")
    for job_id, display in EXPECTED_JOBS.items():
        need(jobs[job_id]["display"] == display, f"workflow display name changed for {job_id}")
        need(jobs[job_id]["run_steps"], f"workflow has no named run steps for {job_id}")

    seed_values = []
    for name in (
        "Run workspace tests with two fixed independent seeds (pass 1)",
        "Run workspace tests with two fixed independent seeds (pass 2)",
    ):
        match = re.search(
            r"(?ms)^      - name: " + re.escape(name) + r"\n(.*?)(?=^      - (?:name|uses):|^  [a-z][a-z0-9-]*:|\Z)",
            text,
        )
        need(match is not None, f"workflow is missing the full test step {name!r}")
        block = match.group(1)
        command = re.search(r"(?m)^        run:\s*(.*?)\s*$", block)
        seed = re.search(r"(?m)^          PROPTEST_RNG_SEED:\s*[\"']?(\d+)", block)
        need(command and command.group(1).strip("'\"") == WORKSPACE_COMMAND,
             f"workflow test step command changed: {name}")
        need(seed is not None, f"workflow test step has no PROPTEST_RNG_SEED: {name}")
        seed_values.append(seed.group(1))
    need(tuple(seed_values) == SEEDS, f"workflow seed order changed: {seed_values}")
    return text, jobs


def validate_ci_run(evidence: Path, workflow_jobs: dict, product_sha: str):
    run = read_json(evidence / "run.json")
    need(run.get("headSha") == product_sha,
         f"CI headSha is not the requested product commit {product_sha}: {run.get('headSha')!r}")
    need(run.get("workflowName") == "CI",
         f"run does not belong to the pinned CI workflow: {run.get('workflowName')!r}")
    need(run.get("status") == "completed", f"CI run is not completed: {run.get('status')!r}")
    need(run.get("conclusion") == "success", f"CI run conclusion is not success: {run.get('conclusion')!r}")
    rows = run.get("jobs")
    need(isinstance(rows, list) and len(rows) == 4, "run.json must contain all four CI jobs")
    by_name = {row.get("name"): row for row in rows}
    need(len(by_name) == 4 and set(by_name) == set(EXPECTED_JOBS.values()),
         f"CI job inventory differs from current workflow: {sorted(by_name)}")
    total_steps = 0
    job_report = {}
    for job_id, display in EXPECTED_JOBS.items():
        row = by_name[display]
        need(row.get("status") == "completed" and row.get("conclusion") == "success",
             f"CI job failed or incomplete: {display}")
        steps = row.get("steps")
        need(isinstance(steps, list) and steps, f"CI API omitted steps for {display}")
        total_steps += len(steps)
        for step in steps:
            need(step.get("status") == "completed" and step.get("conclusion") == "success",
                 f"CI step failed, skipped, or incomplete in {display}: {step}")
        api_names = [step.get("name") for step in steps]
        need(all(isinstance(name, str) and name for name in api_names),
             f"CI API contains a step with no name for {display}")
        need(api_names.count("Set up job") == 1 and api_names.count("Complete job") == 1,
             f"CI API lifecycle markers are missing or duplicated for {display}")
        workflow_names = workflow_jobs[job_id]["workflow_api_steps"]
        observed_workflow_names = [name for name in api_names
            if name not in ("Set up job", "Complete job") and not name.startswith("Post ")]
        need(observed_workflow_names == workflow_names,
             f"CI API workflow steps/order differ from pinned workflow for {display}")
        post_names = [name[5:] for name in api_names if name.startswith("Post ")]
        need(len(post_names) == len(set(post_names)) and all(name in workflow_names for name in post_names),
             f"CI API has an unknown or duplicated post-action step for {display}: {post_names}")
        need(api_names.index("Set up job") == 0 and api_names[-1] == "Complete job",
             f"CI API lifecycle marker order is invalid for {display}")
        need(len(api_names) == len(workflow_names) + len(post_names) + 2,
             f"CI API contains an unrecognized extra step for {display}")
        need(len(api_names) == len(set(api_names)),
             f"CI API contains duplicated step names for {display}")
        for expected in workflow_jobs[job_id]["workflow_api_steps"]:
            need(api_names.count(expected) == 1,
                 f"declared workflow step is absent/duplicated in CI API for {display}: {expected}")
        need(api_names.count("Run actions/checkout@v7.0.1") == 1,
             f"the workflow's checkout action is absent/duplicated in CI steps for {display}")
        job_report[job_id] = {
            "display_name": display,
            "api_step_count": len(steps),
            "successful_api_steps": len(steps),
            "named_workflow_steps_checked": len(workflow_jobs[job_id]["steps"]),
            "declared_workflow_steps_checked": len(workflow_jobs[job_id]["workflow_api_steps"]),
            "workflow_run_steps_checked": len(workflow_jobs[job_id]["run_steps"]),
        }
    expected_total = sum(len(job["workflow_api_steps"]) + 2 for job in workflow_jobs.values())
    # GitHub adds a setup and completion marker per job, plus post-action cleanup steps.
    # Their actual count is retained from the API; declared workflow steps must all be present.
    need(total_steps >= expected_total,
         f"CI API step count {total_steps} is smaller than the workflow declaration plus job lifecycle markers {expected_total}")
    return run, job_report, total_steps


def clean_line(line: str) -> str:
    line = ANSI.sub("", line).strip()
    # `gh run view --log` escapes terminal CSI bytes in some output lines as the literal
    # two-character prefix `^[`; remove that rendering too so Cargo's `Running` headers
    # and test records remain parseable.
    line = re.sub(r"\^\[\[[0-?]*[ -/]*[@-~]", "", line)
    line = re.sub(r"^[^\t\n]+\t[^\t\n]+\t(?=\d{4}-\d\d-\d\dT)", "", line)
    line = re.sub(r"^\d{4}-\d\d-\d\d[T ][^ ]+Z\s+", "", line)
    return line.strip()


def workspace_groups(raw: str):
    lines = raw.splitlines()
    starts = [i for i, line in enumerate(lines) if GROUP_PREFIX + WORKSPACE_COMMAND in clean_line(line)]
    need(len(starts) == 2, f"stable CI log must contain exactly two named full-workspace test steps; found {len(starts)}")
    groups = []
    for pos, start in enumerate(starts):
        end = starts[pos + 1] if pos + 1 < len(starts) else len(lines)
        for j in range(start + 1, end):
            if GROUP_PREFIX in clean_line(lines[j]):
                end = j
                break
        groups.append("\n".join(lines[start:end]))
    return groups


def parse_workspace_group(group: str, seed: str):
    # A test harness block is accepted only when every `running N tests` line has one
    # immediately following summary and the observed named results reconstruct it.
    lines = [clean_line(line) for line in group.splitlines()]
    seed_rows = [re.fullmatch(r"PROPTEST_RNG_SEED:\s*[\"']?(\d+)[\"']?", line)
                 for line in lines if "PROPTEST_RNG_SEED:" in line]
    need(len(seed_rows) == 1 and seed_rows[0] is not None and seed_rows[0].group(1) == seed,
         f"workspace log group must contain exactly one actual PROPTEST_RNG_SEED={seed} env line")
    # Cargo writes the next target's `Running` header before buffered output from the previous
    # test process has fully reached the Actions log. Keep the two ordered streams separate,
    # then pair them after parsing all complete result blocks.
    target_headers = [line for line in lines if line.startswith("Running ")]
    outcomes: list[tuple[str, str, str]] = []
    target_rows = []
    i = 0
    while i < len(lines):
        running = RUNNING.fullmatch(lines[i])
        if not running:
            if lines[i].startswith("test result:"):
                raise ValueError(f"Cargo test result has no matching running block in seed {seed}: {lines[i]}")
            i += 1
            continue
        declared = int(running.group(1))
        named = []
        j = i + 1
        while j < len(lines):
            summary = SUMMARY.fullmatch(lines[j])
            if summary:
                counts = tuple(map(int, summary.groups()[1:4]))
                measured, filtered = map(int, summary.groups()[4:6])
                need((summary.group(1) == "ok") == (counts[1] == 0),
                     f"test summary status/count disagree in seed {seed}: {lines[j]}")
                need(declared == len(named),
                     f"running count differs from named outcomes in seed {seed}: {declared} != {len(named)}")
                observed = (sum(state == "ok" for _, state in named),
                            sum(state == "FAILED" for _, state in named),
                            sum(state == "ignored" for _, state in named))
                need(observed == counts,
                     f"named outcomes do not reconstruct target summary in seed {seed}: {observed} != {counts}")
                need(counts[1] == 0 and filtered == 0,
                     f"workspace test target failed or was filtered in seed {seed}: {lines[j]}")
                target_rows.append({"named_tests": declared, "passed": counts[0], "failed": counts[1],
                                    "ignored": counts[2], "measured": measured, "filtered": filtered})
                target_rows[-1]["_named_outcomes"] = named
                i = j + 1
                break
            result = OUTCOME.fullmatch(lines[j])
            if result:
                raw_state = result.group(2)
                named.append((result.group(1), "ignored" if raw_state.startswith("ignored") else raw_state))
            elif lines[j].startswith("test result:") or lines[j].startswith("test "):
                raise ValueError(f"unparsed Cargo test line in seed {seed}: {lines[j]}")
            j += 1
        else:
            raise ValueError(f"running test block has no summary in seed {seed}")
    need(target_rows, f"workspace seed {seed} yielded no Cargo test result blocks")
    need(len(target_headers) == len(target_rows),
         f"workspace seed {seed} has {len(target_headers)} Cargo target headers but {len(target_rows)} result summaries")
    for row, header in zip(target_rows, target_headers):
        run_target = RUN_TARGET.fullmatch(header)
        need(run_target is not None,
             f"workspace seed {seed} has an unrecognized Cargo Running header: {header!r}")
        executable = run_target.group("path").rsplit("/", 1)[-1]
        executable_match = HASHED_CARGO_EXECUTABLE.fullmatch(executable)
        need(executable_match is not None,
             f"workspace seed {seed} has an unrecognized hashed Cargo executable: {executable!r}")
        row["target_header"] = header
        row["target_executable"] = executable
        row["target_name"] = executable_match.group("target")
        outcomes.extend((name, state, row["target_name"]) for name, state in row.pop("_named_outcomes"))
    need(sum(row["named_tests"] for row in target_rows) == len(outcomes),
         f"not every named test outcome was accounted for in seed {seed}")
    target_inventory = [row["target_header"] for row in target_rows]
    need(all(target_inventory) and len(target_inventory) == len(set(target_inventory)),
         f"workspace seed {seed} has a missing or duplicate Cargo target header")
    need(set(CRITICAL_TEST_TARGETS) == set(CRITICAL_TESTS),
         "every critical test must name its Cargo target explicitly")
    checks = {}
    for label, name in CRITICAL_TESTS.items():
        target = CRITICAL_TEST_TARGETS.get(label)
        matches = [(seen, state) for seen, state, target_name in outcomes
                   if seen.rsplit("::", 1)[-1] == name and (target is None or target_name == target)]
        need(len(matches) == 1 and matches[0][1] == "ok",
             f"critical test is missing, duplicated, or not passing in seed {seed}: {label} ({name})")
        checks[label] = name
    totals = {
        "passed": sum(row["passed"] for row in target_rows),
        "failed": sum(row["failed"] for row in target_rows),
        "ignored": sum(row["ignored"] for row in target_rows),
        "measured": sum(row["measured"] for row in target_rows),
        "filtered": sum(row["filtered"] for row in target_rows),
    }
    need(totals["failed"] == 0, f"workspace seed {seed} has failed tests")
    return {"seed": seed, "test_target_summaries": len(target_rows),
            "target_inventory": target_inventory, "target_summaries": target_rows,
            "named_test_outcomes": len(outcomes), "workspace_totals": totals,
            "critical_tests_passed": checks}


def validate_product_source_pins(evidence: Path, repo: Path, product_sha: str) -> dict:
    """Validate captured `git show <product>:<path>` bytes against their pin and checkout."""
    manifest_path = evidence / "source-pins.json"
    manifest = read_json(manifest_path)
    need(manifest.get("product_sha") == product_sha,
         "source-pins.json is not bound to the requested product SHA")
    files = manifest.get("files")
    need(isinstance(files, dict) and set(files) == set(PRODUCT_SOURCE_PATHS),
         f"product source pin inventory differs: {sorted(files or {})}")
    report = {}
    for rel in PRODUCT_SOURCE_PATHS:
        row = files[rel]
        need(isinstance(row, dict), f"source pin row is malformed: {rel}")
        captured = evidence / "product-source" / rel
        pinned = captured.read_bytes()
        current = (repo / rel).read_bytes()
        digest = sha(pinned)
        need(row.get("git_show") == f"git show {product_sha}:{rel}",
             f"source pin command is not the exact requested product git-show: {rel}")
        need(row.get("bytes") == len(pinned) and row.get("sha256") == digest,
             f"captured source bytes disagree with their pin: {rel}")
        need(current == pinned,
             f"current checkout source differs from the requested product git-show: {rel}")
        report[rel] = {"bytes": len(pinned), "sha256": digest}
    fixture_rows = manifest.get("fixture_classes")
    need(manifest.get("fixture_manifest") == FIXTURE_PIN_PATH,
         "fixture class pins are not bound to the direct-array fixture manifest")
    fixture_manifest = read_json(repo / FIXTURE_PIN_PATH)
    expected_classes = {row.get("path"): row.get("sha256")
                        for row in fixture_manifest.get("classes", [])}
    need(isinstance(fixture_rows, dict) and set(fixture_rows) == set(expected_classes),
         "captured fixture class inventory differs from fixture-pins.json")
    for rel, expected_sha in expected_classes.items():
        row = fixture_rows[rel]
        captured = evidence / "product-fixtures" / rel
        pinned = captured.read_bytes()
        current = (repo / rel).read_bytes()
        digest = sha(pinned)
        need(row.get("git_show") == f"git show {product_sha}:{rel}",
             f"fixture pin command is not bound to the requested product SHA: {rel}")
        need(row.get("fixture_manifest_sha256") == expected_sha == digest
             and row.get("bytes") == len(pinned) and row.get("sha256") == digest,
             f"fixture bytes disagree with fixture-pins.json or captured digest: {rel}")
        need(current == pinned,
             f"current checkout fixture differs from the requested product git-show: {rel}")
        report[rel] = {"bytes": len(pinned), "sha256": digest, "kind": "fixture-class"}
    return report


def validate_collection_receipt(evidence: Path, product_sha: str) -> dict:
    receipt = read_json(evidence / "collection.json")
    need(receipt.get("status") == "raw collection complete; independent acceptance pending",
         "collector receipt is incomplete")
    need(receipt.get("product_sha") == product_sha,
         "collector receipt is not bound to the requested product SHA")
    commands = receipt.get("commands")
    need(isinstance(commands, list) and commands,
         "collector receipt has no command inventory")
    for command in commands:
        need(command.get("exit_code") == 0, f"collector command failed: {command.get('argv')}")
        for channel in ("stdout", "stderr"):
            row = command.get("streams", {}).get(channel, {})
            path = Path(row.get("path", ""))
            need(path.is_absolute() and path.is_file(),
                 f"collector command {channel} artifact is missing")
            data = path.read_bytes()
            need(len(data) == row.get("bytes") and sha(data) == row.get("sha256"),
                 f"collector command {channel} artifact digest mismatch")
    need(receipt.get("fixture_class_count", 0) > 0,
         "collector receipt records no fixture-class pins")
    return {"run_id": receipt.get("run_id"), "command_count": len(commands),
            "fixture_class_count": receipt["fixture_class_count"]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evidence_dir", type=Path,
                        help="directory containing run.json, workflow.sha256, source-pins.json, product-source/ and four raw job logs")
    parser.add_argument("--product-sha", required=True,
                        help="exact 40-character product commit SHA to bind this CI evidence to")
    parser.add_argument("--repo", type=Path, required=True,
                        help="checkout whose current source is compared with captured product git-show bytes")
    args = parser.parse_args()
    need(re.fullmatch(r"[0-9a-f]{40}", args.product_sha) is not None,
         "--product-sha must be a full lowercase 40-character commit SHA")
    evidence = args.evidence_dir.resolve(strict=True)
    repo = args.repo.resolve(strict=True)
    collection = validate_collection_receipt(evidence, args.product_sha)
    source_pins = validate_product_source_pins(evidence, repo, args.product_sha)
    workflow_path = repo / ".github/workflows/ci.yml"
    workflow_text, workflow_jobs = workflow_contract(workflow_path)
    workflow_sha = sha(workflow_path.read_bytes())
    captured_workflow_sha = (evidence / "workflow.sha256").read_text(encoding="ascii").strip()
    need(captured_workflow_sha == workflow_sha,
         "captured workflow SHA-256 does not match the current product checkout")
    need(source_pins[".github/workflows/ci.yml"]["sha256"] == workflow_sha,
         "product git-show workflow source pin differs from CI workflow bytes")

    run, jobs, total_steps = validate_ci_run(evidence, workflow_jobs, args.product_sha)
    need(str(collection.get("run_id")) == str(run.get("databaseId")),
         "collector run ID differs from the captured GitHub Actions run")
    stable_log_path = evidence / "stable.log"
    stable_log = stable_log_path.read_text(encoding="utf-8", errors="replace")
    groups = workspace_groups(stable_log)
    seed_runs = [parse_workspace_group(group, seed) for group, seed in zip(groups, SEEDS)]
    need(seed_runs[0]["seed"] == SEEDS[0] and seed_runs[1]["seed"] == SEEDS[1],
         "workspace seed order differs from the current workflow")
    need(seed_runs[0]["target_inventory"] == seed_runs[1]["target_inventory"],
         "the two workspace seeds executed different Cargo target inventories")
    raw_log_steps = {}
    for job_id in ("msrv", "supply-chain", "fuzz-smoke"):
        path = evidence / f"{job_id}.log"
        need(path.is_file() and path.stat().st_size > 0, f"raw job log is missing or empty: {path.name}")
        display = EXPECTED_JOBS[job_id]
        observed = set()
        log_jobs = set()
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            columns = line.lstrip("\ufeff").split("\t", 2)
            if len(columns) == 3:
                log_jobs.add(columns[0])
                observed.add(columns[1])
        need(log_jobs == {display},
             f"raw log is not exclusively bound to the expected CI job {display}: {sorted(log_jobs)}")
        expected_run_steps = set(workflow_jobs[job_id]["run_steps"])
        missing = expected_run_steps - observed
        need(not missing,
             f"raw per-job log omits declared run-step output for {display}: {sorted(missing)}")
        raw_log_steps[job_id] = {"workflow_run_steps": sorted(expected_run_steps),
                                 "log_step_labels_observed": len(observed)}

    report = {
        "status": "accepted",
        "product": {"head_sha": run["headSha"], "expected_sha": args.product_sha},
        "workflow": {"path": str(workflow_path), "sha256": workflow_sha,
                     "workflow_api_steps": {key: len(value["workflow_api_steps"]) for key, value in workflow_jobs.items()},
                     "workflow_run_steps": {key: len(value["run_steps"]) for key, value in workflow_jobs.items()}},
        "collection": collection,
        "product_source_pins": source_pins,
        "ci": {"job_count": len(jobs), "expanded_api_step_count": total_steps, "jobs": jobs},
        "workspace_seed_runs": seed_runs,
        "raw_job_log_sha256": {name: sha((evidence / name).read_bytes())
                               for name in ("stable.log", "msrv.log", "supply-chain.log", "fuzz-smoke.log")},
        "raw_nonstable_job_log_step_checks": raw_log_steps,
        "gates": {
            "stable_jdk_and_named_extras": "every workflow/API step completed successfully",
            "layering_and_dependency_tree": "every stable job step completed successfully",
            "supply_chain": "both root and fuzz workspace cargo-deny steps completed successfully",
            "fuzz": "corpus replay and all three bounded smoke steps completed successfully",
        },
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        print(f"own-CI verification failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
