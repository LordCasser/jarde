#!/usr/bin/env python3
"""Collect raw GitHub Actions evidence and exact source pins for one direct-array product commit.

This is a prepared collector. The root operator supplies an exact product SHA, run ID, and fresh
output directory only when authorized to perform the external evidence collection.
"""
from __future__ import annotations

import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
REPO = 'LordCasser/jarde'
SOURCE_PATHS = (
    '.github/workflows/ci.yml',
    'crates/jarde-java/src/init.rs',
    'crates/jarde-java/src/build.rs',
    'crates/jarde-java/src/report.rs',
    'crates/jarde-java/src/guard.rs',
    'crates/jarde-reader/src/classfile.rs',
    'tests/recover_direct_array_constructor_arguments.rs',
    'tests/recover_direct_array_constructor_stops.rs',
    'tests/recover_original_test_finally3.rs',
    'tests/p3_constructed_reference_array_elements.rs',
    'tests/fixtures/constructor-direct-array-arguments/fixture-pins.json',
    'tests/fixtures/constructor-direct-array-arguments/DirectArrayConstructorArguments.java',
    'tests/fixtures/constructor-direct-array-arguments/same-owner/SameOwnerArrayArguments.java',
    'tests/fixtures/constructor-direct-array-arguments/reverse-order/ReverseArrayOrder.java',
    'tests/fixtures/corpus-fingerprint.json',
    'crates/jarde-java/src/region.rs',
    'crates/jarde-java/src/region/switch_nonlocal_completion_tests.rs',
    'crates/jarde-java/tests/p3_loop_terminal_return.rs',
    'tests/p3_switch_nonlocal_late_stop.rs',
    'tests/fixtures/p3-switch-jsr-clones/README.md',
    'tests/fixtures/p3-switch-jsr-clones/SwitchLoopJsrCloneDriver.java',
    'tests/fixtures/p3-switch-jsr-clones/generate.py',
    'tests/fixtures/p3-switch-jsr-clones/manifest.json',
    'tests/fixtures/p3-switch-jsr-clones/v49/SwitchLoopJsrClone.class',
    'tests/fixtures/p3-switch-nonlocal-exits/README.md',
    'tests/fixtures/p3-switch-nonlocal-exits/javac23/LD.class',
    'tests/fixtures/p3-switch-nonlocal-exits/javac23/SL.class',
    'tests/fixtures/p3-switch-nonlocal-exits/javac23/SM.class',
    'tests/fixtures/p3-switch-nonlocal-exits/javac23/SN.class',
    'tests/fixtures/p3-switch-nonlocal-exits/javac8/LD.class',
    'tests/fixtures/p3-switch-nonlocal-exits/javac8/SL.class',
    'tests/fixtures/p3-switch-nonlocal-exits/javac8/SM.class',
    'tests/fixtures/p3-switch-nonlocal-exits/javac8/SN.class',
    'tests/fixtures/p3-switch-nonlocal-exits/manifest.json',
    'tests/fixtures/p3-switch-nonlocal-exits/source/LD.java',
    'tests/fixtures/p3-switch-nonlocal-exits/source/SL.java',
    'tests/fixtures/p3-switch-nonlocal-exits/source/SM.java',
    'tests/fixtures/p3-switch-nonlocal-exits/source/SN.java',
    'tests/fixtures/switch-loop-exception-boundary/README.md',
    'tests/fixtures/switch-loop-exception-boundary/SwitchLoopExceptionBoundary.java',
    'tests/fixtures/switch-loop-exception-boundary/javac23/SwitchLoopExceptionBoundary.class',
    'tests/fixtures/switch-loop-exception-boundary/javac8/SwitchLoopExceptionBoundary.class',
    'tests/fixtures/switch-loop-exception-boundary/manifest.json',
)



EXTRA_FIXTURE_ROOTS = ('tests/fixtures/p3-switch-nonlocal-exits', 'tests/fixtures/switch-loop-exception-boundary', 'tests/fixtures/p3-switch-jsr-clones')
EXTRA_FIXTURE_PATHS = ('tests/fixtures/p3-switch-jsr-clones/README.md', 'tests/fixtures/p3-switch-jsr-clones/SwitchLoopJsrCloneDriver.java', 'tests/fixtures/p3-switch-jsr-clones/generate.py', 'tests/fixtures/p3-switch-jsr-clones/manifest.json', 'tests/fixtures/p3-switch-jsr-clones/v49/SwitchLoopJsrClone.class', 'tests/fixtures/p3-switch-nonlocal-exits/README.md', 'tests/fixtures/p3-switch-nonlocal-exits/javac23/LD.class', 'tests/fixtures/p3-switch-nonlocal-exits/javac23/SL.class', 'tests/fixtures/p3-switch-nonlocal-exits/javac23/SM.class', 'tests/fixtures/p3-switch-nonlocal-exits/javac23/SN.class', 'tests/fixtures/p3-switch-nonlocal-exits/javac8/LD.class', 'tests/fixtures/p3-switch-nonlocal-exits/javac8/SL.class', 'tests/fixtures/p3-switch-nonlocal-exits/javac8/SM.class', 'tests/fixtures/p3-switch-nonlocal-exits/javac8/SN.class', 'tests/fixtures/p3-switch-nonlocal-exits/manifest.json', 'tests/fixtures/p3-switch-nonlocal-exits/source/LD.java', 'tests/fixtures/p3-switch-nonlocal-exits/source/SL.java', 'tests/fixtures/p3-switch-nonlocal-exits/source/SM.java', 'tests/fixtures/p3-switch-nonlocal-exits/source/SN.java', 'tests/fixtures/switch-loop-exception-boundary/README.md', 'tests/fixtures/switch-loop-exception-boundary/SwitchLoopExceptionBoundary.java', 'tests/fixtures/switch-loop-exception-boundary/javac23/SwitchLoopExceptionBoundary.class', 'tests/fixtures/switch-loop-exception-boundary/javac8/SwitchLoopExceptionBoundary.class', 'tests/fixtures/switch-loop-exception-boundary/manifest.json')

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def command(out: Path, root: Path, argv: list[str], name: str) -> dict:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    stdout, stderr = out / name, out / (name + '.stderr.raw')
    stdout.parent.mkdir(parents=True, exist_ok=True)
    with stdout.open('xb') as so, stderr.open('xb') as se:
        result = subprocess.run(argv, cwd=root, stdout=so, stderr=se)
    row = {'argv': argv, 'exit_code': result.returncode, 'started_at': started,
           'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'streams': {'stdout': pin(stdout), 'stderr': pin(stderr)}}
    if result.returncode != 0:
        raise RuntimeError(f'command failed: {row}')
    return row


def main() -> int:
    if len(sys.argv) != 4:
        raise SystemExit('usage: collect-own-ci.py OUT_DIR RUN_ID PRODUCT_SHA')
    out, run_id, product = Path(sys.argv[1]).resolve(), sys.argv[2], sys.argv[3]
    if re.fullmatch(r'[0-9a-f]{40}', product) is None:
        raise SystemExit('PRODUCT_SHA must be a lowercase full 40-character SHA')
    if not run_id or out.exists():
        raise SystemExit('RUN_ID must be non-empty and OUT_DIR must be fresh')
    root = ROOT.resolve(strict=True)
    observed_fixture_paths = tuple(sorted(path.relative_to(root).as_posix()
        for rel_root in EXTRA_FIXTURE_ROOTS for path in (root / rel_root).rglob('*') if path.is_file()))
    if observed_fixture_paths != EXTRA_FIXTURE_PATHS:
        raise RuntimeError('switch/exception/JSR fixture inventory differs from the reviewed complete file list')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('refusing to collect while repository target exists')
    out.mkdir(parents=True)
    record = {'product_sha': product, 'run_id': run_id, 'commands': [],
              'status': 'collecting', 'source_paths': list(SOURCE_PATHS)}

    row = command(out, root, ['gh', 'run', 'view', run_id, '--repo', REPO,
        '--json', 'jobs,headSha,status,conclusion,url,databaseId,workflowName'], 'run.json')
    record['commands'].append(row)
    run = json.loads((out / 'run.json').read_text(encoding='utf-8'))
    if run.get('headSha') != product or run.get('status') != 'completed' or run.get('conclusion') != 'success':
        raise RuntimeError(f'run is not successful for the exact product SHA: {run}')
    if run.get('workflowName') != 'CI':
        raise RuntimeError(f'run does not belong to the pinned CI workflow: {run.get("workflowName")!r}')
    jobs = {'stable / test and specification': 'stable', 'MSRV 1.88.0': 'msrv',
            'supply chain': 'supply-chain', 'fuzz smoke': 'fuzz-smoke'}
    if {job.get('name') for job in run.get('jobs', [])} != set(jobs):
        raise RuntimeError('CI job inventory differs from the four-job workflow contract')
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(command, out, root, ['gh', 'run', 'view', run_id, '--repo', REPO,
            '--job', str(job['databaseId']), '--log'], jobs[job['name']] + '.log') for job in run['jobs']]
        record['commands'].extend(f.result() for f in futures)

    files = {}
    for rel in SOURCE_PATHS:
        row = command(out, root, ['git', 'show', product + ':' + rel], 'product-source/' + rel)
        record['commands'].append(row)
        captured = out / 'product-source' / rel
        data = captured.read_bytes()
        if data != (root / rel).read_bytes():
            raise RuntimeError(f'product git-show bytes differ from current checkout: {rel}')
        files[rel] = {'git_show': 'git show ' + product + ':' + rel,
                      'bytes': len(data), 'sha256': sha(data)}

    pin_path = 'tests/fixtures/constructor-direct-array-arguments/fixture-pins.json'
    fixture_manifest = json.loads((out / 'product-source' / pin_path).read_text(encoding='utf-8'))
    fixture_classes = {}
    for item in fixture_manifest.get('classes', []):
        rel = item.get('path')
        expected_sha = item.get('sha256')
        if not isinstance(rel, str) or not isinstance(expected_sha, str):
            raise RuntimeError('fixture-pins.json contains a malformed class row')
        row = command(out, root, ['git', 'show', product + ':' + rel], 'product-fixtures/' + rel)
        record['commands'].append(row)
        captured = out / 'product-fixtures' / rel
        data = captured.read_bytes()
        if sha(data) != expected_sha or data != (root / rel).read_bytes():
            raise RuntimeError(f'fixture class differs from committed pin or current checkout: {rel}')
        fixture_classes[rel] = {'git_show': 'git show ' + product + ':' + rel,
                                'bytes': len(data), 'sha256': sha(data),
                                'fixture_manifest_sha256': expected_sha}
    if not fixture_classes:
        raise RuntimeError('fixture-pins.json has no class records')

    pins = {'product_sha': product, 'files': files, 'fixture_classes': fixture_classes,
            'fixture_manifest': pin_path}
    (out / 'source-pins.json').write_text(json.dumps(pins, indent=2) + '\n', encoding='utf-8')
    (out / 'workflow.sha256').write_text(files['.github/workflows/ci.yml']['sha256'] + '\n', encoding='ascii')
    record['fixture_class_count'] = len(fixture_classes)
    record['status'] = 'raw collection complete; independent acceptance pending'
    (out / 'collection.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': record['status'], 'commands': len(record['commands']),
                      'fixture_classes': len(fixture_classes)}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
