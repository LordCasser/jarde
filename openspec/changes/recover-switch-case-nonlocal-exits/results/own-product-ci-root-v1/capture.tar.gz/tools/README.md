# Exact product CI collection prep

This private runner reuses the accepted direct-array own-product CI collector and verifier. Root supplies an exact full product commit SHA and a GitHub Actions run ID when running it. The collector captures the complete run JSON (including each job and step), all four unmodified raw job logs with stdout/stderr pins, `git show` bytes for product sources, and all source/fixture file bytes. The added source pins cover switch-return implementation and its library/public tests.

The verifier keeps the prior 18 direct-array/exception-only gates and adds exactly these nine switch gates (27 critical tests total including the inherited 18). The 24 files across the switch nonlocal-exit, exception-boundary, and JSR-clone fixture directories are all listed, copied by `git show`, and compared byte-for-byte with the checkout; the collector checks the directory inventory before capture. Each test must occur exactly once with outcome `ok` in each of the two fixed stable-workspace seed runs, under its declared Cargo target. It derives target inventories, test totals, and expanded API-step totals from actual logs, run metadata, and the parsed pinned workflow; it does not hard-code test-pass or API-step totals. The parity verifier checks full per-target summary lists match across seeds and binds to the caller-provided product SHA.

Run order after root supplies the commit and run ID:

1. `python3 -B collect-own-ci.py OUT_DIR RUN_ID PRODUCT_SHA`
2. `python3 -B verify-own-ci.py OUT_DIR --product-sha PRODUCT_SHA --repo /Users/lordcasser/workspace/projects/jarde > OWN_REVIEW.json`
3. `python3 -B verify-ci-parity.py OWN_REVIEW.json ROOT_PARITY_REVIEW.json PRODUCT_SHA`

These scripts are prepared only. No GitHub API, Git, toolchain, CI, or source mutation was invoked by this preparation. The old direct-array run is used solely as a source template and is not evidence for the new product.
