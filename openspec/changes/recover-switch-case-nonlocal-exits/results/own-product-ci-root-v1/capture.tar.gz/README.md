# Root accepted exact-product CI

Product cf857abaabc4fcff82689812226f9906b8d932b2; actual CI run39072531393, https://github.com/LordCasser/jarde/actions/runs/39072531393 . All four jobs and all 52 expanded API steps completed successfully. The step count is derived from captured API data and the pinned workflow, not supplied as a success constant.

The two stable-workspace seed groups each contain 382 actual Cargo targets / 3716 passed / 0 failed / 98 ignored / no filtered tests. Full per-target summaries are identical. Every one of 27 critical gates (18 prior plus nine switch gates) occurs once and is ok in each seed under its exact executable target. Raw Running headers, declared harness counts, individual outcomes and summaries were independently reconciled.

All four raw job logs, run/jobs/steps JSON, 74 command records / 148 raw stream pins, 69 git-show/current byte pins and three actual collector/verifier sources are retained. The 69 files include 43 source/workflow/new-fixture files and 26 previous direct-array fixture classes; all 24 files in the three new switch/exception/JSR fixture directories are included. Neither previous CI success nor the preparation-only scripts are used as new CI evidence.

Root also checked all non-stable declared run-step log labels, supply-chain checks, fuzz corpus replay and bounded smoke, JDK oracle/whole-class extras, dependency boundaries and OpenSpec success. This is product CI, not CI for a later documentation-only closure commit. Native two-seed and full semantic/API evidence are separate captures.
