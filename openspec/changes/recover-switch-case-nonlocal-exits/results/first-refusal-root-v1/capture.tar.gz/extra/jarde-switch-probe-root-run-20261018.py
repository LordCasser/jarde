import hashlib, importlib.util, json, os, shutil, subprocess, sys
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
OUT=Path('/private/tmp/jarde-switch-nonlocal-first-refusal-root-v1-20261018')
BASE=Path('/private/tmp/jarde-switch-case-nonlocal-baseline-root-v1-20261018')
PATCH=Path(sys.argv[1]).resolve(strict=True)
assert not OUT.exists() and not (ROOT/'target').exists()
OUT.mkdir(); (OUT/'raw').mkdir(); (OUT/'original-source').mkdir(); (OUT/'probe-source').mkdir()
def pin(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
files=['crates/jarde-java/src/region.rs','crates/jarde-java/src/build.rs']
original={f:(ROOT/f).read_bytes() for f in files}
for f,b in original.items(): (OUT/'original-source'/Path(f).name).write_bytes(b)
r={'status':'running','patch':pin(PATCH),'runner':pin(__file__),'source_before':{f:pin(ROOT/f) for f in files},'commands':[],'cells':[]}
def save(): (OUT/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
def host_command(label,argv):
    with (OUT/'raw'/f'{label}.stdout.raw').open('xb') as a,(OUT/'raw'/f'{label}.stderr.raw').open('xb') as b:
        p=subprocess.run(argv,cwd=ROOT,stdout=a,stderr=b)
    row={'label':label,'argv':argv,'exit_code':p.returncode,'stdout':pin(OUT/'raw'/f'{label}.stdout.raw'),'stderr':pin(OUT/'raw'/f'{label}.stderr.raw')};r['commands'].append(row);save()
    assert p.returncode==0,label
try:
    host_command('patch-check',['git','apply','--check',str(PATCH)])
    host_command('patch-apply',['git','apply',str(PATCH)])
    for f in files: shutil.copyfile(ROOT/f,OUT/'probe-source'/Path(f).name)
    r['probe_sources']={f:pin(ROOT/f) for f in files};save()
    spec=OUT/'build-commands.json';spec.write_text(json.dumps([['cargo','build','-p','jarde-cli','--all-features']])+'\n')
    host_command('guarded-build',['python3','-B',str(ROOT/'openspec/changes/recover-branch-throw-return-finally/tools/run_validation.py'),str(OUT/'build'),str(spec)])
    build=json.loads((OUT/'build/execution.json').read_text());assert build['status']=='commands_passed_pending_independent_acceptance' and build['target_absent'] and build['source_unchanged']
    cli=Path(build['cli']['path']);r['probe_cli']=pin(cli)
    c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','probe_compare')
    g=load(ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py','probe_guard')
    s=load(ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py','probe_scan')
    g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:s.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
    env=c.clean_env(dict(os.environ));env.pop('RUST_MIN_STACK',None);env.update(g.ENV_VALUES);env['JRE_SWITCH_NONLOCAL_PROBE']='1';g.ENV_VALUES={**g.ENV_VALUES,'JRE_SWITCH_NONLOCAL_PROBE':'1'}
    def without_usage(v):
        if isinstance(v,dict):return {k:without_usage(x) for k,x in v.items() if k!='usage'}
        if isinstance(v,list):return [without_usage(x) for x in v]
        return v
    baseline=json.loads((BASE/'execution.json').read_text())
    for n,cell in enumerate((x for x in baseline['jarde_cells'] if x['evidence']=='all'),1):
        name=cell['class_name'];leg=cell['input_compiler'];inp=Path(cell['input_class']['path']);assert pin(inp)==cell['input_class']
        argv=[str(cli),'class-source','--input',str(inp),'--class',name,'--policy','single-class','--release','8','--format','json','--evidence','all']
        row=g.run_command(n,argv,env);r['commands'].append(row);save();assert row['exit_code']==0 and row['guard_stop'] is None
        doc=json.loads(c.command_artifact(row,'stdout'));old=json.loads(Path(cell['json_artifact']['path']).read_text());same=without_usage(doc)==without_usage(old)
        r['cells'].append({'class':name,'compiler':leg,'command':n,'non_usage_json_unchanged':same,'stderr':row['streams']['stderr']});save();assert same,(name,leg,'probe changed output')
    r['status']='probe_captured_pending_architect_review'
except BaseException as e:
    r['status']='failed';r['failure']=repr(e);raise
finally:
    for f,b in original.items(): (ROOT/f).write_bytes(b)
    r['source_after']={f:pin(ROOT/f) for f in files};r['source_restored']=r['source_after']==r['source_before'];r['target_absent']=not (ROOT/'target').exists();save()
    print(json.dumps({k:r.get(k) for k in ['status','failure','source_restored','target_absent']}))
