import hashlib
import importlib.util
import json
from pathlib import Path
import shutil

BASE = Path('/private/tmp')
def write(p, d):
    p.write_text(json.dumps(d, indent=2, ensure_ascii=False) + '\n')
def check_pin(p):
    b = Path(p['path']).read_bytes()
    assert len(b) == p['bytes'] and hashlib.sha256(b).hexdigest() == p['sha256'], p['path']
    return b
def check_pins(x):
    if isinstance(x, dict):
        if {'path', 'bytes', 'sha256'} <= x.keys():
            check_pin(x)
        else:
            for v in x.values(): check_pins(v)
    elif isinstance(x, list):
        for v in x: check_pins(v)
def name(i):
    return bytes(i['name']).decode(), bytes(i['descriptor']).decode()

p = BASE / 'jarde-switch-combined-api-root-v1-20261018'
d = json.loads((p / 'execution.json').read_text())
assert d['status'] == 'complete_pending_independent_review'
assert d['command_count'] == len(d['commands']) == 16
assert all(d[k] for k in ('source_pins_unchanged', 'inputs_unchanged', 'repository_target_absent_after', 'copied_class_inputs_unchanged'))
check_pins(d['inputs_before'])
check_pins(d['inputs_after'])
for c in d['commands']:
    assert c['exit_code'] == 0 and c['guard_stop'] is None
    check_pins(c['streams']); check_pin(c['stdout_raw']); check_pin(c['stderr_raw'])
assert len(d['assertions']) == 22 and all(a['passed'] for a in d['assertions'])
counts = {'methods': 0, 'segments': 0, 'same_class_bci_origins': 0}
for cell in d['cells']:
    raw = check_pin(cell['json_artifact'])
    assert raw == check_pin(cell['stdout_raw'])
    doc = json.loads(raw)
    assert check_pin(cell['full_class_text']) == doc['text'].encode()
    facts = cell['input_class_facts']['methods']
    assert len(facts) == len(doc['methods'])
    identities = {name(m['item']['identity']): m['item']['identity'] for m in doc['methods']}
    bcis = {(f['name'], f['descriptor']): set(f['code']['bcis']) for f in facts if f['code']}
    for i, (m, f) in enumerate(zip(doc['methods'], facts)):
        item = m['item']; identity = item['identity']; key = name(identity)
        assert item['index'] == i == f['index']
        assert key == (f['name'], f['descriptor']) and item['access_flags'] == f['access']
        assert identity['owner'] == doc['class']
        report = m['outcome']['report']; text = report['text'].encode()
        sm = report['source_map']['segments']
        categories = report['evidence']['categories']
        assert next(c['state']['state'] for c in categories if c['kind'] == 'source_map') == 'complete'
        counts['methods'] += 1
        for s in sm:
            a,b = s['start'], s['end']
            assert 0 <= a < b <= len(text)
            text[:a].decode(); text[:b].decode()
            counts['segments'] += 1
            origin = s['origin']
            for o in [origin['primary'], *origin['derived']]:
                if o.get('bci') is None: continue
                k = name(o['method'])
                assert o['method'] == identities[k], 'full source identity mismatch'
                assert o['bci'] in bcis[k], 'origin outside physical Code'
                counts['same_class_bci_origins'] += 1
changed = [r for r in d['comparisons'] if not r['projection_equal']]
assert len(changed) == 24
targets = {'SN': {'retInSwitchNoTail','retInSwitchTail','labBreak'}, 'SL': {'mixed','labeledBreak'}, 'LD': {'lab'}}
assert all(r['identity']['name'] in targets.get(r['class_name'], set()) and r['new_quality'] == 'structured' and r['new_fallbacks'] == [] for r in changed)
review = {'status': 'accepted combined API stage only', 'commands':16, 'raw_streams':32,
          'assertions':22, **counts, 'changed_method_configurations':24,
          'all_56_other_method_configurations_projection_equal_to_605_baseline':True,
          'full_method_identity_order_flags_owner_and_utf8_bci_origins_verified':True,
          'source_and_inputs_unchanged_at_collection':True, 'target_absent':True,
          'limitations':['All six target methods structured; no whole-source recompilation or rebuilt runtime in this stage.',
                         'Source origins checked against real instruction BCIs; this is not a claim every instruction is printed.',
                         'Late-stop and adversarial switch tests and full gates remain pending.']}
assert len(d['comparisons']) == 80
write(p/'root-review.json', review)
shutil.copy2(__file__, p/'root-acceptor.py')
shutil.copy2('/private/tmp/jarde-switch-return-api-replay-prep-v2-20261018/run-switch-api-replay.py', p/'collector.py')
print(json.dumps(review,ensure_ascii=False))

