// jarde: presentation of `SN` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class SN extends java.lang.Object {
    public SN() {
        // @method <init>()V
        // @declaration a constructor of `SN`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int retInSwitchNoTail(int[] xs) {
        // @method retInSwitchNoTail([I)I
        // @declaration a static method of `SN`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int sum;
        int[] local2;
        int local3;
        int local4;
        sum = 0;
        local2 = xs;
        local3 = local2.length;
        local4 = 0;
        while (local4 < local3) {
            int x = local2[local4];
            switch (x) {
                case 3:
                    return sum + 100;
                default:
                    sum = sum + x;
                    local4 = local4 + 1;
                    break;
            }
        }
        return sum;
    }

    static int retInSwitchTail(int[] xs) {
        // @method retInSwitchTail([I)I
        // @declaration a static method of `SN`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int sum;
        int[] local2;
        int local3;
        int local4;
        sum = 0;
        local2 = xs;
        local3 = local2.length;
        local4 = 0;
        while (local4 < local3) {
            int x = local2[local4];
            switch (x) {
                case 3:
                    return sum + 100;
                default:
                    sum = sum + x;
                    sum = sum + 10;
                    local4 = local4 + 1;
                    break;
            }
        }
        return sum;
    }

    static int retAfterTail(int[] xs) {
        // @method retAfterTail([I)I
        // @declaration a static method of `SN`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int sum;
        int[] local2;
        int local3;
        int local4;
        sum = 0;
        local2 = xs;
        local3 = local2.length;
        local4 = 0;
        while (local4 < local3) {
            int x = local2[local4];
            if (x == 3) {
                return sum + 100;
            } else {
                sum = sum + x;
                sum = sum + 10;
                local4 = local4 + 1;
            }
        }
        return sum;
    }

    static int labBreak(int[] xs) {
        // @method labBreak([I)I
        // @declaration a static method of `SN`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int sum;
        int[] local2;
        int local3;
        int local4;
        sum = 0;
        local2 = xs;
        local3 = local2.length;
        local4 = 0;
        loop: while (local4 < local3) {
            int x = local2[local4];
            switch (x) {
                case 5:
                    break loop;
                default:
                    sum = sum + x;
                    local4 = local4 + 1;
                    continue;
            }
        }
        return sum;
    }

    public static void main(java.lang.String[] a) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `SN`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.io.PrintStream saved0 = java.lang.System.out;
        java.lang.StringBuilder saved1 = new java.lang.StringBuilder().append("");
        java.lang.StringBuilder saved2 = saved1.append(retInSwitchNoTail(new int[]{1, 3})).append("/");
        java.lang.StringBuilder saved3 = saved2.append(retInSwitchTail(new int[]{1, 3})).append("/");
        java.lang.StringBuilder saved4 = saved3.append(retAfterTail(new int[]{1, 3})).append("/");
        saved0.println((java.lang.String) saved4.append(labBreak(new int[]{1, 5})).toString());
        return;
    }
}
