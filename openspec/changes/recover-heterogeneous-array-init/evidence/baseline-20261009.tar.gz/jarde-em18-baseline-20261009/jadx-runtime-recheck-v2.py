#!/usr/bin/env python3
"""Recheck saved JADX outputs using their actual declared package names; includes addendum-02."""
from __future__ import annotations
import hashlib,json,pathlib,re,subprocess,time
ROOT=pathlib.Path('/private/tmp/jarde-em18-baseline-20261009')
LEGS={'javac8':pathlib.Path('/Library/Java/JavaVirtualMachines/corretto-1.8.0_432/Contents/Home'),'javac23':pathlib.Path('/Library/Java/JavaVirtualMachines/openjdk-23.0.1/Contents/Home')}
def h(b):return hashlib.sha256(b).hexdigest()
def hf(p):return h(p.read_bytes())
def run(label,home,cwd,classes,main,logdir,commands):
 p=subprocess.run([str(home/'bin/java'),'-Xverify:all','-cp',str(classes),main],cwd=str(cwd),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 logdir.mkdir(parents=True,exist_ok=True);op=logdir/(label.replace('/','_')+'.stdout');ep=logdir/(label.replace('/','_')+'.stderr');op.write_bytes(p.stdout);ep.write_bytes(p.stderr)
 commands.append({'label':label,'argv':[str(home/'bin/java'),'-Xverify:all','-cp',str(classes),main],'cwd':str(cwd),'exit':p.returncode,'stdout':str(op.relative_to(ROOT)),'stdout_sha256':h(p.stdout),'stderr':str(ep.relative_to(ROOT)),'stderr_sha256':h(p.stderr)})
 return p.returncode,h(p.stdout),h(p.stderr)
def entry_source(src,main):
 for p in sorted(src.rglob(main+'.java')):
  m=re.search(r'^\s*package\s+([\w.]+)\s*;',p.read_text(errors='replace'),re.M)
  return (m.group(1)+'.' if m else '')+main,p
 raise FileNotFoundError(f'missing source for {main}: {src}')
parents=[('matrix',ROOT,ROOT/'manifest.json'),('addendum-01',ROOT/'addendum-20261009-01',ROOT/'addendum-20261009-01/manifest.json'),('addendum-02',ROOT/'addendum-20261009-02',ROOT/'addendum-20261009-02/manifest.json')]
commands=[];results=[]
for tag,base,mp in parents:
 d=json.loads(mp.read_text());table=d['families'] if tag=='matrix' else d['cases']
 for fam,legs in table.items():
  for leg,x in legs.items():
   if x.get('jadx_compile_exit')!=0:continue
   case=base/'cases'/fam/leg if tag=='matrix' else base/fam/leg
   src=case/'jadx/sources';classes=case/'jadx-classes';main=x['main_class'] if tag=='matrix' else ('CT' if fam=='ct-legacy-frozen' else 'Main')
   fqcn,srcfile=entry_source(src,main);log=base/'jadx-runtime-recheck-v2'/fam/leg
   code,oh,eh=run(f'{tag}/{fam}/{leg}',LEGS[leg],case,classes,fqcn,log,commands)
   classpath=pathlib.Path(*fqcn.split('.')).with_suffix('.class');classfile=classes/classpath
   results.append({'dataset':tag,'family':fam,'leg':leg,'generated_source':str(srcfile),'main_class':fqcn,'main_class_sha256':hf(classfile) if classfile.exists() else None,'exit':code,'stdout_sha256':oh,'stderr_sha256':eh})
out={'schema':'em18-jadx-runtime-recheck-v2','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'runner_path':str(pathlib.Path(__file__)),'runner_sha256':hf(pathlib.Path(__file__)),'parents':[{'label':tag,'path':str(mp),'sha256':hf(mp)} for tag,_,mp in parents],'commands':commands,'results':results}
p=ROOT/'jadx-runtime-recheck-manifest-v2.json';p.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'manifest':str(p),'runner_sha256':out['runner_sha256'],'checks':len(results),'passed':sum(r['exit']==0 for r in results),'failures':sum(r['exit']!=0 for r in results)},indent=2))
