#!/usr/bin/env python3
"""Additive EM18 verification for the frozen legacy CT.class and legal BigDecimal outsider control."""
from __future__ import annotations
import hashlib,json,pathlib,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parent
PARENT=ROOT.parent
REPO=pathlib.Path('/Users/lordcasser/workspace/projects/jarde')
CT_CLASS=REPO/'openspec/evidence/java-syntax-2026-10-05/heterogeneous-array-init-patrol/fixture/CT.class'
CT_SOURCE=REPO/'openspec/evidence/java-syntax-2026-10-05/heterogeneous-array-init-patrol/fixture/CT.java'
CLI=pathlib.Path('/private/tmp/jarde-reference-slot-candidate-v2-cli');JADX=pathlib.Path('/opt/homebrew/bin/jadx')
LEGS={'javac8':pathlib.Path('/Library/Java/JavaVirtualMachines/corretto-1.8.0_432/Contents/Home'),'javac23':pathlib.Path('/Library/Java/JavaVirtualMachines/openjdk-23.0.1/Contents/Home')}
BIGDECIMAL_SOURCE=b'''import java.math.BigDecimal;\npublic class Main {\n  public static void main(String[] args) {\n    Number[] values = new Number[]{new BigDecimal("1.25")};\n    System.out.println(values.length + ":" + values[0]);\n  }\n}\n'''
def h(b):return hashlib.sha256(b).hexdigest()
def hf(p):return h(p.read_bytes())
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
commands=[]
def run(label,argv,cwd,log):
 try:
  p=subprocess.run([str(x) for x in argv],cwd=str(cwd),stdout=subprocess.PIPE,stderr=subprocess.PIPE);code=p.returncode;out=p.stdout;err=p.stderr
 except Exception as e:code=None;out=b'';err=(type(e).__name__+': '+str(e)).encode()
 op=log/(label.replace('/','_')+'.stdout');ep=log/(label.replace('/','_')+'.stderr');put(op,out);put(ep,err)
 commands.append({'label':label,'argv':[str(x) for x in argv],'cwd':str(cwd),'exit':code,'stdout':str(op.relative_to(ROOT)),'stdout_sha256':h(out),'stderr':str(ep.relative_to(ROOT)),'stderr_sha256':h(err)})
 return code,out,err
def compile_args(home,src,empty,dst):return [home/'bin/javac','-source','8','-target','8','-g:none','-classpath',empty,'-sourcepath',empty,'-d',dst,*src]
def srcs(top):return sorted(top.rglob('*.java')) if top.exists() else []
def tops(classes):return sorted(p.relative_to(classes).with_suffix('').as_posix().replace('/','.') for p in classes.rglob('*.class') if '$' not in p.name)

ct_sha=hf(CT_CLASS); frozen_expected='ed06cfab1a1a6c94b5b2d7677b802674529aa8b48d2df5bfdffffdcbc696e366'
if ct_sha!=frozen_expected:raise SystemExit('legacy frozen CT class hash mismatch')
initial=json.loads((PARENT/'manifest.json').read_text())
invalid_record={leg:initial['families']['closed-set-outsider-bigdecimal'][leg] for leg in LEGS}
manifest={'schema':'em18-baseline-addendum-v1','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'runner_path':str(pathlib.Path(__file__)),'runner_sha256':hf(pathlib.Path(__file__)),'parent_manifest':str(PARENT/'manifest.json'),'parent_manifest_sha256':hf(PARENT/'manifest.json'),'initial_invalid_bigdecimal_probe_preserved':invalid_record,'ct_source_sha256':hf(CT_SOURCE),'frozen_ct_class_sha256':ct_sha,'frozen_ct_expected_sha256':frozen_expected,'cli':str(CLI),'cli_sha256':hf(CLI),'jadx':str(JADX),'jadx_sha256':hf(JADX),'legs':{},'cases':{},'commands':[]}
manifest['commands']=commands
for leg,home in LEGS.items():
 manifest['legs'][leg]={'home':str(home),'java_sha256':hf(home/'bin/java'),'javac_sha256':hf(home/'bin/javac'),'jar_sha256':hf(home/'bin/jar'),'java_version_stderr':run(f'{leg}/java-version',[home/'bin/java','-version'],ROOT,ROOT/'logs')[2].decode(errors='replace').strip(),'javac_version_stdout':run(f'{leg}/javac-version',[home/'bin/javac','-version'],ROOT,ROOT/'logs')[1].decode(errors='replace').strip()}
 empty=ROOT/'empty';empty.mkdir(exist_ok=True)
 # Exact frozen CT.class byte sequence as an independent input artifact.
 ct=ROOT/'ct-legacy-frozen'/leg;classes=ct/'frozen-classes';classes.mkdir(parents=True,exist_ok=True);put(ct/'CT.class',CT_CLASS.read_bytes());put(ct/'CT.java',CT_SOURCE.read_bytes());put(classes/'CT.class',CT_CLASS.read_bytes())
 ct_runtime=run(f'{leg}/ct-frozen/original-run',[home/'bin/java','-Xverify:all','-cp',classes,'CT'],ct,ct/'logs')
 run(f'{leg}/ct-frozen/javap',[home/'bin/javap','-classpath',classes,'-c','-p','CT'],ct,ct/'logs')
 ctjar=ct/'CT-frozen.jar';jarcode=run(f'{leg}/ct-frozen/jar',[home/'bin/jar','cf',ctjar,'-C',classes,'.'],ct,ct/'logs')[0]
 ct_case={'class_sha256':hf(ct/'CT.class'),'jar_sha256':hf(ctjar) if ctjar.exists() else None,'original_runtime_exit':ct_runtime[0],'jadx_exit':None,'jadx_source_count':0,'jadx_compile_exit':None,'jadx_runtime_exit':None,'jarde_exit':None,'jarde_compile_exit':None,'jarde_runtime_exit':None}
 if ctjar.exists():
  jd=ct/'jadx';ct_case['jadx_exit']=run(f'{leg}/ct-frozen/jadx',[JADX,'-d',jd,ctjar],ct,ct/'logs')[0];js=srcs(jd/'sources');ct_case['jadx_source_count']=len(js);jc=ct/'jadx-classes';jc.mkdir(exist_ok=True)
  if js:
   ct_case['jadx_compile_exit']=run(f'{leg}/ct-frozen/jadx-javac',compile_args(home,js,empty,jc),ct,ct/'logs')[0]
   if ct_case['jadx_compile_exit']==0:ct_case['jadx_runtime_exit']=run(f'{leg}/ct-frozen/jadx-run',[home/'bin/java','-Xverify:all','-cp',jc,'CT'],ct,ct/'logs')[0]
  code,out,err=run(f'{leg}/ct-frozen/jarde',[CLI,'class-source','--input',ctjar,'--class','CT','--policy','plain-jar','--format','json','--evidence','all','--release','8'],ct,ct/'logs');ct_case['jarde_exit']=code;put(ct/'jarde-report.json',out)
  try: text=json.loads(out)['text'];put(ct/'jarde-src/CT.java',text.encode())
  except Exception: text=None
  dc=ct/'jarde-classes';dc.mkdir(exist_ok=True)
  if text is not None:
   ct_case['jarde_compile_exit']=run(f'{leg}/ct-frozen/jarde-javac',compile_args(home,[ct/'jarde-src/CT.java'],empty,dc),ct,ct/'logs')[0]
   if ct_case['jarde_compile_exit']==0:ct_case['jarde_runtime_exit']=run(f'{leg}/ct-frozen/jarde-run',[home/'bin/java','-Xverify:all','-cp',dc,'CT'],ct,ct/'logs')[0]
 manifest['cases'].setdefault('ct-legacy-frozen',{})[leg]=ct_case
 # Corrected, legal BigDecimal-to-Number array outsider control.
 bc=ROOT/'bigdecimal-control-corrected'/leg;src=bc/'src/Main.java';put(src,BIGDECIMAL_SOURCE);bclasses=bc/'original-classes';bclasses.mkdir(parents=True,exist_ok=True)
 bcompile=run(f'{leg}/bigdecimal-corrected/original-javac',compile_args(home,[src],empty,bclasses),bc,bc/'logs')[0];brun=None
 if bcompile==0:brun=run(f'{leg}/bigdecimal-corrected/original-run',[home/'bin/java','-Xverify:all','-cp',bclasses,'Main'],bc,bc/'logs')[0]
 bjar=bc/'input.jar';bjarcode=run(f'{leg}/bigdecimal-corrected/jar',[home/'bin/jar','cf',bjar,'-C',bclasses,'.'],bc,bc/'logs')[0] if bcompile==0 else None
 bcase={'source_sha256':hf(src),'original_compile_exit':bcompile,'original_runtime_exit':brun,'jar_exit':bjarcode,'input_jar_sha256':hf(bjar) if bjar.exists() else None,'jadx_exit':None,'jadx_source_count':0,'jadx_compile_exit':None,'jadx_runtime_exit':None,'jarde_exit':None,'jarde_compile_exit':None,'jarde_runtime_exit':None}
 if bjar.exists():
  jd=bc/'jadx';bcase['jadx_exit']=run(f'{leg}/bigdecimal-corrected/jadx',[JADX,'-d',jd,bjar],bc,bc/'logs')[0];js=srcs(jd/'sources');bcase['jadx_source_count']=len(js);jc=bc/'jadx-classes';jc.mkdir(exist_ok=True)
  if js:
   bcase['jadx_compile_exit']=run(f'{leg}/bigdecimal-corrected/jadx-javac',compile_args(home,js,empty,jc),bc,bc/'logs')[0]
   if bcase['jadx_compile_exit']==0:bcase['jadx_runtime_exit']=run(f'{leg}/bigdecimal-corrected/jadx-run',[home/'bin/java','-Xverify:all','-cp',jc,'Main'],bc,bc/'logs')[0]
  code,out,err=run(f'{leg}/bigdecimal-corrected/jarde',[CLI,'class-source','--input',bjar,'--class','Main','--policy','plain-jar','--format','json','--evidence','all','--release','8'],bc,bc/'logs');bcase['jarde_exit']=code;put(bc/'jarde-report.json',out)
  try:text=json.loads(out)['text'];put(bc/'jarde-src/Main.java',text.encode())
  except Exception:text=None
  dc=bc/'jarde-classes';dc.mkdir(exist_ok=True)
  if text is not None:
   bcase['jarde_compile_exit']=run(f'{leg}/bigdecimal-corrected/jarde-javac',compile_args(home,[bc/'jarde-src/Main.java'],empty,dc),bc,bc/'logs')[0]
   if bcase['jarde_compile_exit']==0:bcase['jarde_runtime_exit']=run(f'{leg}/bigdecimal-corrected/jarde-run',[home/'bin/java','-Xverify:all','-cp',dc,'Main'],bc,bc/'logs')[0]
 manifest['cases'].setdefault('bigdecimal-control-corrected',{})[leg]=bcase
# Inventory all addendum artifacts.
manifest['files']=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hf(p)} for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name!='manifest.json']
mp=ROOT/'manifest.json';mp.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'manifest':str(mp),'runner_sha256':manifest['runner_sha256'],'commands':len(commands),'files':len(manifest['files']),'cases':{k:{leg:{n:v.get(n) for n in ['original_runtime_exit','jadx_exit','jadx_compile_exit','jadx_runtime_exit','jarde_exit','jarde_compile_exit','jarde_runtime_exit']} for leg,v in legs.items()} for k,legs in manifest['cases'].items()}},indent=2))
