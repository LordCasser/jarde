#!/usr/bin/env python3
"""Fresh EM18 heterogeneous-array baseline patrol. Saves all commands and raw streams."""
from __future__ import annotations
import hashlib, json, os, pathlib, shutil, subprocess, sys, time, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('/Users/lordcasser/workspace/projects/jarde')
CT_SOURCE = REPO / 'openspec/evidence/java-syntax-2026-10-05/heterogeneous-array-init-patrol/fixture/CT.java'
CT_CLASS = REPO / 'openspec/evidence/java-syntax-2026-10-05/heterogeneous-array-init-patrol/fixture/CT.class'
CLI = pathlib.Path('/private/tmp/jarde-reference-slot-candidate-v2-cli')
JADX = pathlib.Path('/opt/homebrew/bin/jadx')
LEGS = {
 'javac8': pathlib.Path('/Library/Java/JavaVirtualMachines/corretto-1.8.0_432/Contents/Home'),
 'javac23': pathlib.Path('/Library/Java/JavaVirtualMachines/openjdk-23.0.1/Contents/Home'),
}
FROZEN_CT_SHA='ed06cfab1a1a6c94b5b2d7677b802674529aa8b48d2df5bfdffffdcbc696e366'

SOURCES = {
 'ct-legacy': {'Main':'CT.java','main':'CT','files':{'CT.java':CT_SOURCE.read_text()}},
 'boxed-number-six': {'Main':'Main.java','main':'Main','files':{'Main.java':'''public class Main {\n  public static void main(String[] args) {\n    Number[] values = new Number[]{Integer.valueOf(1), Long.valueOf(2L), Double.valueOf(3.5), Float.valueOf(4.0f), Byte.valueOf((byte)5), Short.valueOf((short)6)};\n    System.out.println(values.length + ":" + values[0] + ":" + values[5]);\n  }\n}\n'''}},
 'string-builder-charsequence': {'Main':'Main.java','main':'Main','files':{'Main.java':'''public class Main {\n  public static void main(String[] args) {\n    CharSequence[] values = new CharSequence[]{"x", new StringBuilder("y")};\n    System.out.println(values.length + ":" + values[0] + ":" + values[1]);\n  }\n}\n'''}},
 'arraylist-hashset-collection': {'Main':'Main.java','main':'Main','files':{'Main.java':'''import java.util.ArrayList;\nimport java.util.Collection;\nimport java.util.HashSet;\npublic class Main {\n  public static void main(String[] args) {\n    Collection<?>[] values = new Collection<?>[]{new ArrayList<String>(), new HashSet<String>()};\n    System.out.println(values.length + ":" + values[0].getClass().getSimpleName() + ":" + values[1].getClass().getSimpleName());\n  }\n}\n'''}},
 'exceptions-throwable': {'Main':'Main.java','main':'Main','files':{'Main.java':'''public class Main {\n  public static void main(String[] args) {\n    Throwable[] values = new Throwable[]{new IllegalStateException("s"), new IllegalArgumentException("a")};\n    System.out.println(values.length + ":" + values[0].getMessage() + ":" + values[1].getMessage());\n  }\n}\n'''}},
 'nested-number-array': {'Main':'Main.java','main':'Main','files':{'Main.java':'''public class Main {\n  public static void main(String[] args) {\n    Integer[] ints = new Integer[]{1};\n    Long[] longs = new Long[]{2L};\n    Number[][] values = new Number[][]{ints, longs};\n    System.out.println(values.length + ":" + values[0][0] + ":" + values[1][0]);\n  }\n}\n'''}},
 'same-jar-derived-base': {'Main':'Main.java','main':'Main','files':{
  'Main.java':'''public class Main {\n  public static void main(String[] args) {\n    Base[] values = new Base[]{new DerivedA(), new DerivedB()};\n    System.out.println(values.length + ":" + values[0].name() + ":" + values[1].name());\n  }\n}\n''',
  'Base.java':'''public abstract class Base implements Named { public abstract String name(); }\n''',
  'Named.java':'''public interface Named { String name(); }\n''',
  'DerivedA.java':'''public final class DerivedA extends Base { public String name() { return "a"; } }\n''',
  'DerivedB.java':'''public final class DerivedB extends Base { public String name() { return "b"; } }\n''',
 }},
 'closed-set-outsider-bigdecimal': {'Main':'Main.java','main':'Main','files':{'Main.java':'''import java.math.BigDecimal;\npublic class Main {\n  public static void main(String[] args) {\n    Number[] values = new Number[]{new BigDecimal("1.25")};\n    System.out.println(values.length + ":" + values[0].toPlainString());\n  }\n}\n'''}},
}

def sha(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def sha_file(path: pathlib.Path) -> str: return sha(path.read_bytes())
def put(path: pathlib.Path, data: bytes):
    path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)
def run(label, argv, cwd, logdir, records):
    logdir.mkdir(parents=True, exist_ok=True)
    try:
        p=subprocess.run([str(x) for x in argv],cwd=str(cwd),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        out,err=p.stdout,p.stderr; code=p.returncode
    except Exception as e:
        out=b''; err=(type(e).__name__+': '+str(e)).encode(); code=None
    outp=logdir/(label.replace('/','_')+'.stdout'); errp=logdir/(label.replace('/','_')+'.stderr')
    put(outp,out); put(errp,err)
    records.append({'label':label,'argv':[str(x) for x in argv],'cwd':str(cwd),'exit':code,'stdout':str(outp.relative_to(ROOT)),'stdout_sha256':sha(out),'stderr':str(errp.relative_to(ROOT)),'stderr_sha256':sha(err)})
    return code,out,err

def javac_args(home, sources, empty, classes):
    return [home/'bin/javac','-source','8','-target','8','-g:none','-classpath',empty,'-sourcepath',empty,'-d',classes,*sources]

def top_classes(classes):
    return sorted(p.relative_to(classes).with_suffix('').as_posix().replace('/','.') for p in classes.rglob('*.class') if '$' not in p.name)

def file_inventory():
    out=[]
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and p.name not in ('manifest.json',):
            out.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha_file(p)})
    return out

if sha_file(CT_CLASS)!=FROZEN_CT_SHA: raise SystemExit('frozen CT.class hash mismatch')
input_root=ROOT/'inputs'; put(input_root/'ct-legacy/CT.java',CT_SOURCE.read_bytes()); put(input_root/'ct-legacy/legacy-CT.class',CT_CLASS.read_bytes())
base={'schema':'em18-fresh-baseline-patrol-v1','root':str(ROOT),'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'runner_path':str(pathlib.Path(__file__)),'runner_sha256':sha_file(pathlib.Path(__file__)),'candidate_cli':str(CLI),'candidate_cli_sha256':sha_file(CLI),'jadx_executable':str(JADX),'jadx_executable_sha256':sha_file(JADX),'ct_source':str(CT_SOURCE),'ct_source_sha256':sha_file(CT_SOURCE),'frozen_ct_class':str(CT_CLASS),'frozen_ct_class_sha256':sha_file(CT_CLASS),'frozen_ct_class_expected_sha256':FROZEN_CT_SHA,'legs':{},'families':{},'commands':[]}
for leg,home in LEGS.items():
 base['legs'][leg]={'home':str(home),'javac_sha256':sha_file(home/'bin/javac'),'java_sha256':sha_file(home/'bin/java'),'jar_sha256':sha_file(home/'bin/jar'),'javap_sha256':sha_file(home/'bin/javap'),'javac_version':run(f'{leg}/javac-version',[home/'bin/javac','-version'],ROOT,ROOT/'tool-logs',base['commands'])[1].decode(errors='replace').strip(),'java_version':run(f'{leg}/java-version',[home/'bin/java','-version'],ROOT,ROOT/'tool-logs',base['commands'])[2].decode(errors='replace').strip(),'jadx_version':run(f'{leg}/jadx-version',[JADX,'--version'],ROOT,ROOT/'tool-logs',base['commands'])[1].decode(errors='replace').strip(),'cli_version':run(f'{leg}/cli-version',[CLI,'--version'],ROOT,ROOT/'tool-logs',base['commands'])[1].decode(errors='replace').strip()}
  
for leg,home in LEGS.items():
  empty=ROOT/'tool-inputs'/leg/'empty-classpath-sourcepath'; empty.mkdir(parents=True,exist_ok=True)
  for family,spec in SOURCES.items():
    case=ROOT/'cases'/family/leg; source_dir=case/'original-src'; classes=case/'original-classes'; source_dir.mkdir(parents=True,exist_ok=True);classes.mkdir(parents=True,exist_ok=True)
    for name,source in spec['files'].items(): put(source_dir/name,source.encode())
    srcfiles=[source_dir/name for name in spec['files']]
    cmds=base['commands']; outputs={}
    compile_code,_,_=run(f'{family}/{leg}/original-javac',javac_args(home,srcfiles,empty,classes),case,case/'logs',cmds)
    outputs['original_compile_exit']=compile_code
    main=spec['main']; main_name=main
    runtime_code=None
    if compile_code==0:
      runtime_code,_,_=run(f'{family}/{leg}/original-run',[home/'bin/java','-Xverify:all','-cp',classes,main_name],case,case/'logs',cmds)
    outputs['original_runtime_exit']=runtime_code
    # Preserve actual generated class inventory and javap for the original compile.
    if compile_code==0:
      for cls in top_classes(classes):
        run(f'{family}/{leg}/javap-{cls.replace(".","_")}',[home/'bin/javap','-classpath',classes,'-c','-p',cls],case,case/'logs',cmds)
    jar=case/'input.jar'
    jar.parent.mkdir(parents=True,exist_ok=True)
    jar_code,_,_=run(f'{family}/{leg}/jar',[home/'bin/jar','cf',jar,'-C',classes,'.'],case,case/'logs',cmds) if compile_code==0 else (None,b'',b'not run: original compile failed')
    outputs['jar_exit']=jar_code; outputs['input_jar_sha256']=sha_file(jar) if jar.exists() else None
    # JADX whole-jar decompilation, compile all produced Java sources in isolation, then verify/run.
    jadx_dir=case/'jadx'; jadx_code,_,_=run(f'{family}/{leg}/jadx',[JADX,'-d',jadx_dir,jar],case,case/'logs',cmds) if jar.exists() else (None,b'',b'not run: jar absent')
    outputs['jadx_exit']=jadx_code
    jadx_src=jadx_dir/'sources'; jadx_files=sorted(jadx_src.rglob('*.java')) if jadx_src.exists() else []
    outputs['jadx_source_count']=len(jadx_files); outputs['jadx_source_hashes']=[{'path':str(p.relative_to(case)),'sha256':sha_file(p)} for p in jadx_files]
    jclasses=case/'jadx-classes'; jclasses.mkdir(parents=True,exist_ok=True)
    if jadx_files:
      jc,_,_=run(f'{family}/{leg}/jadx-javac',javac_args(home,jadx_files,empty,jclasses),case,case/'logs',cmds)
    else: jc=None
    outputs['jadx_compile_exit']=jc; jr=None
    if jc==0: jr,_,_=run(f'{family}/{leg}/jadx-run',[home/'bin/java','-Xverify:all','-cp',jclasses,main_name],case,case/'logs',cmds)
    outputs['jadx_runtime_exit']=jr
    # Jarde class-source once for every top-level class in the jar. Combine complete report texts.
    jarde_dir=case/'jarde-src'; jarde_dir.mkdir(parents=True,exist_ok=True); jarde_entries=[]
    class_names=top_classes(classes)
    for idx,cls in enumerate(class_names):
      out_path=case/'jarde-reports'/f'{idx:02d}-{cls.replace(".","_")}.json'; out_path.parent.mkdir(parents=True,exist_ok=True)
      code,out,err=run(f'{family}/{leg}/jarde-{cls.replace(".","_")}',[CLI,'class-source','--input',jar,'--class',cls,'--policy','plain-jar','--format','json','--evidence','all','--release','8'],case,case/'logs',cmds)
      record=cmds[-1]; record['report_json']=str(out_path.relative_to(ROOT)); record['input_jar_sha256']=outputs['input_jar_sha256']
      text=None; parse_error=None
      try:
        obj=json.loads(out.decode('utf-8')); text=obj.get('text')
        record['outcome']=obj.get('outcome')
        record['text_sha256']=sha(text.encode('utf-8')) if isinstance(text,str) else None
      except Exception as e: parse_error=type(e).__name__+': '+str(e)
      put(out_path,out)
      if isinstance(text,str):
        srcpath=jarde_dir/(cls.replace('.','/')+'.java'); put(srcpath,text.encode('utf-8')); jarde_entries.append(srcpath)
      else: record['json_parse_error']=parse_error
    outputs['jarde_class_count']=len(class_names); outputs['jarde_text_source_count']=len(jarde_entries)
    outputs['jarde_sources']=[{'path':str(p.relative_to(case)),'sha256':sha_file(p)} for p in jarde_entries]
    dclasses=case/'jarde-classes'; dclasses.mkdir(parents=True,exist_ok=True)
    if len(jarde_entries)==len(class_names) and jarde_entries:
      dc,_,_=run(f'{family}/{leg}/jarde-javac',javac_args(home,jarde_entries,empty,dclasses),case,case/'logs',cmds)
    else: dc=None
    outputs['jarde_compile_exit']=dc; dr=None
    if dc==0: dr,_,_=run(f'{family}/{leg}/jarde-run',[home/'bin/java','-Xverify:all','-cp',dclasses,main_name],case,case/'logs',cmds)
    outputs['jarde_runtime_exit']=dr
    outputs['compiled_class_hashes']={label:[{'path':str(p.relative_to(case)),'sha256':sha_file(p)} for p in sorted((case/dirn).rglob('*.class'))] for label,dirn in [('original','original-classes'),('jadx','jadx-classes'),('jarde','jarde-classes')]}
    base['families'].setdefault(family,{})[leg]={'source_hashes':{name:sha(srcfiles[i].read_bytes()) for i,name in enumerate(spec['files'])},'main_class':main_name,'original_compiled_main_class_sha256':sha_file(classes/(main_name+'.class')) if (classes/(main_name+'.class')).exists() else None,**outputs}
# Inventory only after all command artifacts are present.
base['files']=file_inventory()
manifest=ROOT/'manifest.json'; manifest.write_text(json.dumps(base,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'manifest':str(manifest),'runner_sha256':base['runner_sha256'],'families':len(SOURCES),'legs':len(LEGS),'family_leg_runs':sum(len(v) for v in base['families'].values()),'commands':len(base['commands']),'files':len(base['files'])},indent=2))
