#!/usr/bin/env python3
"""Additive re-run of JADX-built classes using the actual package declared by generated source."""
from __future__ import annotations
import hashlib,json,pathlib,re,subprocess,time
ROOT=pathlib.Path('/private/tmp/jarde-em18-baseline-20261009'); ADD=ROOT/'addendum-20261009-01'
LEGS={'javac8':pathlib.Path('/Library/Java/JavaVirtualMachines/corretto-1.8.0_432/Contents/Home'),'javac23':pathlib.Path('/Library/Java/JavaVirtualMachines/openjdk-23.0.1/Contents/Home')}
def h(b):return hashlib.sha256(b).hexdigest()
def hf(p):return h(p.read_bytes())
cmds=[];res=[]
def run(label,home,cwd,classes,main,logdir):
 try:p=subprocess.run([str(home/'bin/java'),'-Xverify:all','-cp',str(classes),main],cwd=str(cwd),stdout=subprocess.PIPE,stderr=subprocess.PIPE);code=p.returncode;o=p.stdout;e=p.stderr
 except Exception as x:code=None;o=b'';e=(type(x).__name__+': '+str(x)).encode()
 logdir.mkdir(parents=True,exist_ok=True);op=logdir/(label.replace('/','_')+'.stdout');ep=logdir/(label.replace('/','_')+'.stderr');op.write_bytes(o);ep.write_bytes(e)
 cmds.append({'label':label,'argv':[str(home/'bin/java'),'-Xverify:all','-cp',str(classes),main],'cwd':str(cwd),'exit':code,'stdout':str(op.relative_to(ROOT)),'stdout_sha256':h(o),'stderr':str(ep.relative_to(ROOT)),'stderr_sha256':h(e)})
 return code,o,e

def get_pkg(source_root,main):
 matches=sorted(source_root.rglob(main+'.java'))
 for path in matches:
  txt=path.read_text(errors='replace');m=re.search(r'^\s*package\s+([\w.]+)\s*;',txt,re.M)
  return (m.group(1)+'.' if m else '')+main, str(path.relative_to(source_root))
 raise FileNotFoundError(f'no generated source for {main} under {source_root}')

parents=[('matrix',ROOT/'manifest.json'),('addendum',ADD/'manifest.json')]
entries=[]
for label,mp in parents:
 manifest=json.loads(mp.read_text()); legs=manifest['families'] if label=='matrix' else manifest['cases']
 for family,byleg in legs.items():
  for leg,x in byleg.items():
   if x.get('jadx_compile_exit')!=0:continue
   home=LEGS[leg]
   if label=='matrix':
    case=ROOT/'cases'/family/leg; src=case/'jadx/sources'; classes=case/'jadx-classes'; main=x['main_class']
    outbase=ROOT/'jadx-runtime-recheck'/family/leg
   else:
    case=ADD/family/leg; src=case/'jadx/sources';classes=case/'jadx-classes';main='CT' if family=='ct-legacy-frozen' else 'Main'
    outbase=ADD/'jadx-runtime-recheck'/family/leg
   fqcn,srcfile=get_pkg(src,main)
   code,_,_=run(f'{label}/{family}/{leg}',home,case,classes,fqcn,outbase)
   entries.append({'dataset':label,'family':family,'leg':leg,'generated_source':str((src/srcfile).relative_to(ROOT)) if src.is_relative_to(ROOT) else str(src/srcfile),'main_class':fqcn,'classes_path':str(classes),'classes_main_sha256':hf(classes/pathlib.Path(*fqcn.split('.')).with_suffix('.class')) if (classes/pathlib.Path(*fqcn.split('.')).with_suffix('.class')).exists() else None,'exit':code,'stdout_sha256':cmds[-1]['stdout_sha256'],'stderr_sha256':cmds[-1]['stderr_sha256']})
script=pathlib.Path(__file__)
out={'schema':'em18-jadx-runtime-recheck-v1','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'runner_path':str(script),'runner_sha256':hf(script),'parents':[{'label':k,'path':str(p),'sha256':hf(p)} for k,p in parents],'legs':{k:{'home':str(v),'java_sha256':hf(v/'bin/java')} for k,v in LEGS.items()},'commands':cmds,'results':entries}
path=ROOT/'jadx-runtime-recheck-manifest.json';path.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'manifest':str(path),'runner_sha256':out['runner_sha256'],'checks':len(entries),'passed':sum(e['exit']==0 for e in entries),'nonzero':sum(e['exit']!=0 for e in entries)},indent=2))
