package defpackage;

/* JADX INFO: loaded from: input.jar:DerivedA.class */
public final class DerivedA extends Base {
    @Override // defpackage.Base, defpackage.Named
    public String name() {
        return "a";
    }
}
