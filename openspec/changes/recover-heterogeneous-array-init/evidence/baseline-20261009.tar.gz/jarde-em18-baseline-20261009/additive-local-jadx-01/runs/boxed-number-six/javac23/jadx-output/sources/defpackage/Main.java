package defpackage;

/* JADX INFO: loaded from: input.jar:Main.class */
public class Main {
    public static void main(String[] strArr) {
        Number[] numberArr = {1, 2L, Double.valueOf(3.5d), Float.valueOf(4.0f), (byte) 5, (short) 6};
        System.out.println(numberArr.length + ":" + numberArr[0] + ":" + numberArr[5]);
    }
}
