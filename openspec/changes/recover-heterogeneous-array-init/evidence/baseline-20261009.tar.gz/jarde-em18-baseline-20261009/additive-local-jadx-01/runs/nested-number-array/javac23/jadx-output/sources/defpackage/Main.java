package defpackage;

/* JADX INFO: loaded from: input.jar:Main.class */
public class Main {
    public static void main(String[] strArr) {
        Number[][] numberArr = {new Integer[]{1}, new Long[]{2L}};
        System.out.println(numberArr.length + ":" + numberArr[0][0] + ":" + numberArr[1][0]);
    }
}
