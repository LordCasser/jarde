package defpackage;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

/* JADX INFO: loaded from: input.jar:Main.class */
public class Main {
    public static void main(String[] strArr) {
        Collection[] collectionArr = {new ArrayList(), new HashSet()};
        System.out.println(collectionArr.length + ":" + collectionArr[0].getClass().getSimpleName() + ":" + collectionArr[1].getClass().getSimpleName());
    }
}
