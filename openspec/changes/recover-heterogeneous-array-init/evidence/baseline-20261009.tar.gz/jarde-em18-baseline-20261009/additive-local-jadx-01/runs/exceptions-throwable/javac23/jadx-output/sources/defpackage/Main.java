package defpackage;

/* JADX INFO: loaded from: input.jar:Main.class */
public class Main {
    public static void main(String[] strArr) {
        Throwable[] thArr = {new IllegalStateException("s"), new IllegalArgumentException("a")};
        System.out.println(thArr.length + ":" + thArr[0].getMessage() + ":" + thArr[1].getMessage());
    }
}
