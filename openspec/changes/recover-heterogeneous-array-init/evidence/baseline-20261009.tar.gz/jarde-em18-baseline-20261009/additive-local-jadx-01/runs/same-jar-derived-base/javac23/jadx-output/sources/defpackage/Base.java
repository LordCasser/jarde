package defpackage;

/* JADX INFO: loaded from: input.jar:Base.class */
public abstract class Base implements Named {
    @Override // defpackage.Named
    public abstract String name();
}
