package defpackage;

/* JADX INFO: loaded from: input.jar:Named.class */
public interface Named {
    String name();
}
