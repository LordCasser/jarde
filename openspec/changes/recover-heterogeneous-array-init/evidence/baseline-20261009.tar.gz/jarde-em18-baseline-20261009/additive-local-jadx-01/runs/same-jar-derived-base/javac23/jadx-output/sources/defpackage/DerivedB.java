package defpackage;

/* JADX INFO: loaded from: input.jar:DerivedB.class */
public final class DerivedB extends Base {
    @Override // defpackage.Base, defpackage.Named
    public String name() {
        return "b";
    }
}
