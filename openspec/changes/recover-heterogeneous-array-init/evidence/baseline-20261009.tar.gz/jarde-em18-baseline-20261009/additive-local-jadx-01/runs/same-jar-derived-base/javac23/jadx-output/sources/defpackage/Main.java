package defpackage;

/* JADX INFO: loaded from: input.jar:Main.class */
public class Main {
    public static void main(String[] strArr) {
        Base[] baseArr = {new DerivedA(), new DerivedB()};
        System.out.println(baseArr.length + ":" + baseArr[0].name() + ":" + baseArr[1].name());
    }
}
