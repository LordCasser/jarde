package defpackage;

/* JADX INFO: loaded from: input.jar:Main.class */
public class Main {
    public static void main(String[] strArr) {
        CharSequence[] charSequenceArr = {"x", new StringBuilder("y")};
        System.out.println(charSequenceArr.length + ":" + ((Object) charSequenceArr[0]) + ":" + ((Object) charSequenceArr[1]));
    }
}
