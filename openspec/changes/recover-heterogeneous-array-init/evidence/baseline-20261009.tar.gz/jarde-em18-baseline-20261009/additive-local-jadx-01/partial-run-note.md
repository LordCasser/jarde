# Partial local JADX attempt (superseded by additive-local-jadx-02)

This first attempt used the same local source-built JADX executable and frozen inputs. It completed and saved raw outputs for 14 legs, then stopped before decompiling leg 15 because the runner compared the `ct-legacy-frozen` addendum manifest's `jar_sha256` field as though it were the primary manifest's `input_jar_sha256`. This was a runner schema lookup error; no input jar mismatch was established. The first 14 leg artifacts are retained as partial history. There is no complete manifest for this attempt. The corrected full rerun is in sibling `additive-local-jadx-02`, which accepts either saved schema field and verifies each exact hash.

Runner SHA-256: `0cf9bcf6fb7a41753856953356233a3da2a9111f04849028e151b1667c548a1c`.
