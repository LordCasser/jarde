public class Main {
  public static void main(String[] args) {
    Throwable[] values = new Throwable[]{new IllegalStateException("s"), new IllegalArgumentException("a")};
    System.out.println(values.length + ":" + values[0].getMessage() + ":" + values[1].getMessage());
  }
}
