// jarde: presentation of `Main` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class Main extends java.lang.Object {
    public Main() {
        // @method <init>()V
        // @declaration a constructor of `Main`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static void main(java.lang.String[] arg0) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `Main`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.lang.Integer[] local1 = new java.lang.Integer[]{java.lang.Integer.valueOf(1)};
        java.lang.Long[] local2 = new java.lang.Long[]{java.lang.Long.valueOf(2L)};
        // @bytecode 38 27 26 30 31 32 33 34 35 36 37
        // the array initializer element at BCI 38 is presented as `java.lang.Integer[]`, while the array component is `java.lang.Number[]`; without a hierarchy fact this `aastore` cannot be rewritten as a Java initializer without changing its compatibility or exception behavior
        // @bytecode 39 42 45 46 49 50 51 54 56 59 60 61 62 63 64 67 69 72 73 74 75 76 77 80 83
        // the statement at BCI 83 reads `local3`, and no statement of this body declared that local: the write that would have declared it was refused, so its name cannot be read here (P3 2b.2)
        return;
    }
}
