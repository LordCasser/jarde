public class Main {
  public static void main(String[] args) {
    Integer[] ints = new Integer[]{1};
    Long[] longs = new Long[]{2L};
    Number[][] values = new Number[][]{ints, longs};
    System.out.println(values.length + ":" + values[0][0] + ":" + values[1][0]);
  }
}
