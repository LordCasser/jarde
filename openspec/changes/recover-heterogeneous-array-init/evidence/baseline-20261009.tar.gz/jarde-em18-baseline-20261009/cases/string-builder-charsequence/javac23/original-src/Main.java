public class Main {
  public static void main(String[] args) {
    CharSequence[] values = new CharSequence[]{"x", new StringBuilder("y")};
    System.out.println(values.length + ":" + values[0] + ":" + values[1]);
  }
}
