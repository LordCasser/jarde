import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
public class Main {
  public static void main(String[] args) {
    Collection<?>[] values = new Collection<?>[]{new ArrayList<String>(), new HashSet<String>()};
    System.out.println(values.length + ":" + values[0].getClass().getSimpleName() + ":" + values[1].getClass().getSimpleName());
  }
}
