// jarde: presentation of `Main` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class Main extends java.lang.Object {
    public Main() {
        // @method <init>()V
        // @declaration a constructor of `Main`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static void main(java.lang.String[] arg0) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `Main`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 53 2 0 5 6 7 8 11 12 13 14 17 20 21 22 23 26 29 30 31 32 34 37 38 39 40 41 44 45 46 47 49 52
        // the array initializer element at BCI 53 is presented as `java.lang.Integer`, while the array component is `java.lang.Number`; without a hierarchy fact this `aastore` cannot be rewritten as a Java initializer without changing its compatibility or exception behavior
        // @bytecode 54 57 60 61 64 65 66 69 71 74 75 76 77 80 82 85 86 87 88 91 94
        // the statement at BCI 94 reads `local1`, and no statement of this body declared that local: the write that would have declared it was refused, so its name cannot be read here (P3 2b.2)
        return;
    }
}
