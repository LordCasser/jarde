public class Main {
  public static void main(String[] args) {
    Number[] values = new Number[]{Integer.valueOf(1), Long.valueOf(2L), Double.valueOf(3.5), Float.valueOf(4.0f), Byte.valueOf((byte)5), Short.valueOf((short)6)};
    System.out.println(values.length + ":" + values[0] + ":" + values[5]);
  }
}
