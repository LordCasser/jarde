public interface Named { String name(); }
