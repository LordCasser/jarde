public final class DerivedA extends Base { public String name() { return "a"; } }
