public abstract class Base implements Named { public abstract String name(); }
