public class Main {
  public static void main(String[] args) {
    Base[] values = new Base[]{new DerivedA(), new DerivedB()};
    System.out.println(values.length + ":" + values[0].name() + ":" + values[1].name());
  }
}
