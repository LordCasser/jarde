public final class DerivedB extends Base { public String name() { return "b"; } }
