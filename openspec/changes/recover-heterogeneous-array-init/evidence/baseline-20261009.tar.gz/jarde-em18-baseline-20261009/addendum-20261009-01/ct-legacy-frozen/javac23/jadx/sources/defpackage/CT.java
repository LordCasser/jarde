package defpackage;

import java.util.Arrays;

/* JADX INFO: loaded from: CT-frozen.jar:CT.class */
public class CT {
    static String io(Object obj) {
        return obj instanceof String ? ((String) obj).toUpperCase() : "?";
    }

    static String io2(Object obj) {
        return obj instanceof String ? ((String) obj).trim() : "?";
    }

    static Object up() {
        return Arrays.asList("a", "b");
    }

    static Number cov() {
        return (Number) Arrays.asList(1, 2L).get(0);
    }

    static int prim() {
        Integer num = 3;
        return Double.valueOf(num.intValue()).intValue();
    }

    public static void main(String[] strArr) {
        System.out.println(io("x") + "/" + io2(" y ") + "/" + up() + "/" + cov() + "/" + prim());
    }
}
