// jarde: presentation of `CT` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class CT extends java.lang.Object {
    public CT() {
        // @method <init>()V
        // @declaration a constructor of `CT`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static java.lang.String io(java.lang.Object arg0) {
        // @method io(Ljava/lang/Object;)Ljava/lang/String;
        // @declaration a static method of `CT`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        if (arg0 instanceof java.lang.String) {
            java.lang.String local1 = (java.lang.String) arg0;
            return local1.toUpperCase();
        } else {
            return "?";
        }
    }

    static java.lang.String io2(java.lang.Object arg0) {
        // @method io2(Ljava/lang/Object;)Ljava/lang/String;
        // @declaration a static method of `CT`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        return arg0 instanceof java.lang.String ? ((java.lang.String) arg0).trim() : "?";
    }

    static java.lang.Object up() {
        // @method up()Ljava/lang/Object;
        // @declaration a static method of `CT`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        java.util.List local0 = java.util.Arrays.asList((java.lang.Object[]) new java.lang.String[]{"a", "b"});
        return local0;
    }

    static java.lang.Number cov() {
        // jarde: not recovered: the recovery run for `cov()Ljava/lang/Number;` produced no statement (explanation only); the artifact's own comment lines are below
        // @method cov()Ljava/lang/Number;
        // @declaration a static method of `CT`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 23 20 1 0 4 5 6 7 10 11 12 13 16 19
        // the array initializer element at BCI 23 is presented as `java.lang.Integer`, while the array component is `java.lang.Number`; without a hierarchy fact this `aastore` cannot be rewritten as a Java initializer without changing its compatibility or exception behavior
        // @bytecode 24 25 26 31 34
        // the statement at BCI 34 reads `local0`, and no statement of this body declared that local: the write that would have declared it was refused, so its name cannot be read here (P3 2b.2)
    }

    static int prim() {
        // @method prim()I
        // @declaration a static method of `CT`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        java.lang.Double local0 = java.lang.Double.valueOf((double) java.lang.Integer.valueOf(3).intValue());
        return ((java.lang.Number) local0).intValue();
    }

    public static void main(java.lang.String[] arg0) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `CT`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.lang.System.out.println(io((java.lang.Object) "x") + "/" + io2((java.lang.Object) " y ") + "/" + up() + "/" + cov() + "/" + prim());
        return;
    }
}
