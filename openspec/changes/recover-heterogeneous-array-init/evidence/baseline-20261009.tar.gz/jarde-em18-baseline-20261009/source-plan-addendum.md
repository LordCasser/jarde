# Additive follow-up

The first patrol manifest preserves an invalid BigDecimal control source that called `toPlainString()` on a `Number`; its compile failure is not treated as a semantic result. This addendum uses a legal `Number[]` initializer with `BigDecimal` and deterministic `toString()` output. It also takes the exact frozen CT.class bytes as an independent input under both runtime legs. The first addendum run is preserved as-is; this corrected addendum has its own command-complete manifest.

The first JADX runtime attempts used the simple class name even though actual generated sources declared `package defpackage`; those exit-1 command records are preserved. `jadx-runtime-recheck.py` uses the package declared by the actual source files and verifies the already compiled outputs.
