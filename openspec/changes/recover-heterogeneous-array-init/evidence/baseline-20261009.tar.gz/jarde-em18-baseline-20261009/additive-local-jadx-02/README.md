# EM18 local source-built JADX replay

This is an additive replay of 18 frozen input jars using the local source-built JADX at `/Users/lordcasser/workspace/testzone/jadx/jadx-cli/build/install/jadx/bin/jadx`. The launcher reports `dev`; the read-only source checkout HEAD is `2fb1b16386941660fda07e9017285aec40fcb37f`. Its full install file and runtime JAR SHA-256 inventory is in `manifest.json`. The old patrol used Homebrew JADX `1.5.6` at `/opt/homebrew/bin/jadx`; that is a different distribution, so its behavior is not attributed to the source checkout.

All 18 legs used the frozen existing jars without rebuilding original Java. Local JADX generated-source sets were compiled with that leg's JDK using `-source 8 -target 8 -g:none`, explicit empty `-classpath` and `-sourcepath`, and isolated output classes; each actual package-qualified main then ran under `-Xverify:all`. Counts: JADX 18/18 exit 0, generated-source compile 18/18 exit 0, verifier runtime 18/18 exit 0, exact original stdout/stderr matches 18/18. The same-jar hierarchy case compiled all five generated source files together.

`source-output-byte-comparison.json` compares each generated source by relative path and SHA against the old saved JADX source tree, then records both raw stream matches. The saved Jarde baseline remains **0/18 behavioral passes**; successful local JADX recovery does not change that result.

Runner SHA-256: `c64133733e21bd792a0db66356fe5c45ed4388685871eef42c3620ee6b1c62da`. Manifest SHA-256: `61365ed13d9dd7e86ac513c9620c155f520ccf95e8aec058339df3a8a76a7524`.
