#!/usr/bin/env python3
"""Additive local source-built JADX replay of 18 frozen EM18 input jars."""
from __future__ import annotations
import hashlib, json, pathlib, re, subprocess, time, os

BASE = pathlib.Path('/private/tmp/jarde-em18-baseline-20261009')
OUT = BASE / 'additive-local-jadx-02'
LOCAL_JADX_ROOT = pathlib.Path('/Users/lordcasser/workspace/testzone/jadx/jadx-cli/build/install/jadx')
JADX = LOCAL_JADX_ROOT / 'bin/jadx'
JADX_REPO = pathlib.Path('/Users/lordcasser/workspace/testzone/jadx')
OLD_MANIFESTS = [BASE/'manifest.json', BASE/'addendum-20261009-02/manifest.json']
LEGS = {
 'javac8': pathlib.Path('/Library/Java/JavaVirtualMachines/corretto-1.8.0_432/Contents/Home'),
 'javac23': pathlib.Path('/Library/Java/JavaVirtualMachines/openjdk-23.0.1/Contents/Home'),
}
EMPTY = OUT/'empty-classpath-sourcepath'


def h(b: bytes) -> str: return hashlib.sha256(b).hexdigest()
def hf(p: pathlib.Path) -> str: return h(p.read_bytes())
def rel(p: pathlib.Path) -> str: return str(p.relative_to(OUT))
def put(p: pathlib.Path, b: bytes): p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b)
def run(label, argv, cwd, stdout_path, stderr_path):
    try:
        p = subprocess.run([str(x) for x in argv], cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        code, out, err = p.returncode, p.stdout, p.stderr
    except Exception as e:
        code, out, err = None, b'', (type(e).__name__ + ': ' + str(e)).encode()
    put(stdout_path, out); put(stderr_path, err)
    return {'label': label, 'argv': [str(x) for x in argv], 'cwd': str(cwd), 'exit': code,
            'stdout': rel(stdout_path), 'stdout_sha256': h(out),
            'stderr': rel(stderr_path), 'stderr_sha256': h(err)}

def family_entries():
    # 14 primary frozen jars, 2 frozen legacy CT jars, 2 corrected BigDecimal jars.
    out=[]
    for family in ['ct-legacy','boxed-number-six','string-builder-charsequence','arraylist-hashset-collection',
                   'exceptions-throwable','nested-number-array','same-jar-derived-base']:
        for leg in LEGS:
            case=BASE/'cases'/family/leg
            out.append((family,leg,case/'input.jar',case,'CT' if family=='ct-legacy' else 'Main',
                        BASE/'manifest.json',f'{family}/{leg}/original-run'))
    add=BASE/'addendum-20261009-02'
    for leg in LEGS:
        case=add/'ct-legacy-frozen'/leg
        out.append(('ct-legacy-frozen',leg,case/'CT-frozen.jar',case,'CT',add/'manifest.json',f'{leg}/ct-frozen/original-run'))
    for leg in LEGS:
        case=add/'bigdecimal-control-corrected'/leg
        out.append(('bigdecimal-control-corrected',leg,case/'input.jar',case,'Main',add/'manifest.json',f'{leg}/bigdecimal-corrected/original-run'))
    return out

old_data={p:json.loads(p.read_text()) for p in OLD_MANIFESTS}
def old_command(manifest_path, label):
    d=old_data[manifest_path]
    return next(c for c in d['commands'] if c['label']==label)

OUT.mkdir(parents=True, exist_ok=True); EMPTY.mkdir(exist_ok=True)
commands=[]; results=[]
# Tool identity: preserve the historical Homebrew tool facts and separately identify local build.
version=run('local-jadx-version',[JADX,'--version'],OUT,OUT/'tool/local-jadx-version.stdout',OUT/'tool/local-jadx-version.stderr'); commands.append(version)
head=subprocess.run(['git','-C',str(JADX_REPO),'rev-parse','HEAD'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
put(OUT/'tool/local-jadx-git-head.stdout',head.stdout); put(OUT/'tool/local-jadx-git-head.stderr',head.stderr)
commands.append({'label':'local-jadx-git-head-read-only','argv':['git','-C',str(JADX_REPO),'rev-parse','HEAD'],'cwd':str(OUT),'exit':head.returncode,
                 'stdout':'tool/local-jadx-git-head.stdout','stdout_sha256':h(head.stdout),'stderr':'tool/local-jadx-git-head.stderr','stderr_sha256':h(head.stderr)})
old_exe=pathlib.Path('/opt/homebrew/bin/jadx')
old_exe_real=old_exe.resolve()
old_version=run('historical-homebrew-jadx-version',[old_exe,'--version'],OUT,OUT/'tool/homebrew-jadx-version.stdout',OUT/'tool/homebrew-jadx-version.stderr'); commands.append(old_version)
# Record each JDK identity and exact executable hashes.
leg_meta={}
for leg,home in LEGS.items():
    jv=run(f'{leg}-java-version',[home/'bin/java','-version'],OUT,OUT/f'tool/{leg}-java-version.stdout',OUT/f'tool/{leg}-java-version.stderr'); commands.append(jv)
    cv=run(f'{leg}-javac-version',[home/'bin/javac','-version'],OUT,OUT/f'tool/{leg}-javac-version.stdout',OUT/f'tool/{leg}-javac-version.stderr'); commands.append(cv)
    leg_meta[leg]={'home':str(home),'java_sha256':hf(home/'bin/java'),'javac_sha256':hf(home/'bin/javac'),
                   'java_version_stderr_sha256':jv['stderr_sha256'],'javac_version_stdout_sha256':cv['stdout_sha256']}

for idx,(family,leg,jar,case,main,manifest_path,original_label) in enumerate(family_entries(),1):
    label=f'{family}/{leg}'; work=OUT/'runs'/family/leg; work.mkdir(parents=True,exist_ok=True)
    jar_sha=hf(jar)
    old_case=old_data[manifest_path]['families' if 'families' in old_data[manifest_path] else 'cases'][family][leg]
    expected_jar_sha=old_case.get('input_jar_sha256') or old_case.get('jar_sha256')
    if jar_sha != expected_jar_sha:
        raise SystemExit(f'frozen jar SHA mismatch against saved manifest: {label} {jar_sha}')
    orig=old_command(manifest_path,original_label)
    oldroot=manifest_path.parent
    oldout=(oldroot/orig['stdout']).read_bytes(); older=(oldroot/orig['stderr']).read_bytes()
    decomp=work/'jadx-output'
    dc=run(f'{label}/jadx',[JADX,'-d',decomp,jar],case,work/'jadx.stdout',work/'jadx.stderr'); commands.append(dc)
    source_root=decomp/'sources'; sources=sorted(source_root.rglob('*.java')) if source_root.exists() else []
    source_records=[{'path':str(p.relative_to(source_root)),'sha256':hf(p),'bytes':p.stat().st_size} for p in sources]
    # Derive the actual package-qualified entry point from generated Main/CT source.
    main_files=[p for p in sources if p.name==main+'.java']
    fqcn=None
    if main_files:
        txt=main_files[0].read_text(errors='replace')
        m=re.search(r'^\s*package\s+([\w.]+)\s*;',txt,re.M)
        fqcn=(m.group(1)+'.' if m else '')+main
    classes=work/'classes'; classes.mkdir(exist_ok=True)
    compile_cmd=None; compile_code=None; runtime_cmd=None; runtime_code=None; outbytes=b''; errbytes=b''
    if sources:
        javac_args=[LEGS[leg]/'bin/javac','-source','8','-target','8','-g:none','-classpath',EMPTY,'-sourcepath',EMPTY,'-d',classes,*sources]
        compile_cmd=run(f'{label}/javac-generated-sources',javac_args,case,work/'javac.stdout',work/'javac.stderr')
        commands.append(compile_cmd); compile_code=compile_cmd['exit']
    if compile_code==0 and fqcn:
        runtime_cmd=run(f'{label}/java-xverify-all',[LEGS[leg]/'bin/java','-Xverify:all','-cp',classes,fqcn],case,work/'runtime.stdout',work/'runtime.stderr')
        commands.append(runtime_cmd); runtime_code=runtime_cmd['exit']
        outbytes=(work/'runtime.stdout').read_bytes(); errbytes=(work/'runtime.stderr').read_bytes()
    result={'family':family,'leg':leg,'main_simple_name':main,'main_fqcn':fqcn,'frozen_input_jar':str(jar),'frozen_input_jar_sha256':jar_sha,
            'old_manifest':str(manifest_path),'old_manifest_sha256':hf(manifest_path),'old_original_run_label':original_label,
            'old_original_exit':orig['exit'],'old_original_stdout_sha256':h(oldout),'old_original_stderr_sha256':h(older),
            'jadx_exit':dc['exit'],'generated_source_count':len(sources),'generated_sources':source_records,
            'javac_command':compile_cmd,'javac_exit':compile_code,'java_xverify_command':runtime_cmd,'java_xverify_exit':runtime_code,
            'runtime_stdout_sha256':h(outbytes) if runtime_cmd else None,'runtime_stderr_sha256':h(errbytes) if runtime_cmd else None,
            'stdout_matches_original':outbytes==oldout if runtime_cmd else False,
            'stderr_matches_original':errbytes==older if runtime_cmd else False,
            'class_files':[{'path':str(p.relative_to(classes)),'sha256':hf(p),'bytes':p.stat().st_size} for p in sorted(classes.rglob('*.class'))]}
    results.append(result)
    print(f'[{idx}/18] {label}: jadx={dc["exit"]} sources={len(sources)} javac={compile_code} verify_run={runtime_code} out_match={result["stdout_matches_original"]} err_match={result["stderr_matches_original"]}',flush=True)

# Tool file inventory (including every runtime .jar) and old Homebrew library identity.
local_files=[]
for p in sorted(x for x in LOCAL_JADX_ROOT.rglob('*') if x.is_file()):
    local_files.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hf(p)})
homebrew_libroot=old_exe_real.parent.parent/'libexec'/'lib'
if not homebrew_libroot.exists():
    homebrew_libroot=old_exe_real.parent.parent/'lib'
homebrew_files=[]
for p in sorted(x for x in homebrew_libroot.rglob('*') if x.is_file()):
    homebrew_files.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hf(p)})
# All outputs in the experiment are hashed after execution; exclude manifest itself.
all_files=[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':hf(p)} for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='manifest.json']
manifest={'schema':'em18-additive-local-source-jadx-replay-v1','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
          'workspace_repo':'/Users/lordcasser/workspace/projects/jarde','purpose':'Additive re-decompile/recompile/runtime comparison using source-built local JADX; no original source recompile.',
          'reference_source_repo':str(JADX_REPO),'reference_source_git_head_read_only':head.stdout.decode().strip(),
          'local_jadx':{'root':str(LOCAL_JADX_ROOT),'executable':str(JADX),'executable_sha256':hf(JADX),'version_stdout_sha256':version['stdout_sha256'],'version_stdout':(OUT/'tool/local-jadx-version.stdout').read_text().strip(),'all_install_files':local_files,'runtime_jar_files':[x for x in local_files if x['path'].endswith('.jar')]},
          'historical_homebrew_jadx':{'executable':'/opt/homebrew/bin/jadx','resolved_executable':str(old_exe_real),'executable_sha256':hf(old_exe),'version_stdout':(OUT/'tool/homebrew-jadx-version.stdout').read_text().strip(),'library_root':str(homebrew_libroot),'library_files':homebrew_files,'note':'Historical EM18 manifests used this Homebrew distribution; it is distinct from the source-built JADX and its behavior is not attributed to the local source repo HEAD.'},
          'jdk_legs':leg_meta,'empty_classpath_sourcepath':str(EMPTY),'frozen_parent_manifests':[{'path':str(p),'sha256':hf(p)} for p in OLD_MANIFESTS],
          'runner_path':str(pathlib.Path(__file__)),'runner_sha256':hf(pathlib.Path(__file__)),'commands':commands,'results':results,
          'summary':{'distinct_legs':len(results),'jadx_exit0':sum(r['jadx_exit']==0 for r in results),'generated_sources_compile_exit0':sum(r['javac_exit']==0 for r in results),'xverify_runtime_exit0':sum(r['java_xverify_exit']==0 for r in results),'stdout_exact_matches_original':sum(r['stdout_matches_original'] for r in results),'stderr_exact_matches_original':sum(r['stderr_matches_original'] for r in results),'behavioral_exact_stream_matches':sum(r['stdout_matches_original'] and r['stderr_matches_original'] and r['java_xverify_exit']==r['old_original_exit'] for r in results)},
          'files':all_files}
mp=OUT/'manifest.json';mp.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'manifest':str(mp),'runner_sha256':manifest['runner_sha256'],'summary':manifest['summary'],'manifest_sha256':hf(mp)},indent=2))
