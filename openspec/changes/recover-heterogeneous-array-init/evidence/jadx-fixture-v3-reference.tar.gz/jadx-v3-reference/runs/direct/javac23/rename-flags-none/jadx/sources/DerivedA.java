// default package

/* JADX INFO: loaded from: direct-javac23.jar:DerivedA.class */
public final class DerivedA extends Mid {
    public DerivedA(int i) {
        super(i);
    }
}
