// default package

/* JADX INFO: loaded from: direct-javac8.jar:Mid.class */
public class Mid extends Base {
    public Mid(int i) {
        super(i);
    }
}
