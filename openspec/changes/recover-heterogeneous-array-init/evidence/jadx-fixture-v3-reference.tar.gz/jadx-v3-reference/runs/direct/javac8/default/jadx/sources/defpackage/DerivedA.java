package defpackage;

/* JADX INFO: loaded from: direct-javac8.jar:DerivedA.class */
public final class DerivedA extends Mid {
    public DerivedA(int i) {
        super(i);
    }
}
