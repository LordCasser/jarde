package defpackage;

/* JADX INFO: loaded from: direct-javac8.jar:DerivedB.class */
public final class DerivedB extends Base {
    public DerivedB(int i) {
        super(i);
    }
}
