// default package

/* JADX INFO: loaded from: direct-javac8.jar:LocalInterface.class */
public interface LocalInterface {
    int value();
}
