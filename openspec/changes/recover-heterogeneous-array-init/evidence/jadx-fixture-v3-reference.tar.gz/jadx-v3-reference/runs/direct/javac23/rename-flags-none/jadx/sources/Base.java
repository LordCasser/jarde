// default package

/* JADX INFO: loaded from: direct-javac23.jar:Base.class */
public class Base implements LocalInterface {
    private final int value;

    public Base(int i) {
        this.value = i;
    }

    @Override // LocalInterface
    public int value() {
        return this.value;
    }
}
