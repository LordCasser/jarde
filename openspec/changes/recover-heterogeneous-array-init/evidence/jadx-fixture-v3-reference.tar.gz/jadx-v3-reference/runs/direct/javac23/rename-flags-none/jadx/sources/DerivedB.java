// default package

/* JADX INFO: loaded from: direct-javac23.jar:DerivedB.class */
public final class DerivedB extends Base {
    public DerivedB(int i) {
        super(i);
    }
}
