// default package

/* JADX INFO: loaded from: direct-javac23.jar:LocalInterface.class */
public interface LocalInterface {
    int value();
}
