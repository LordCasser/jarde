package defpackage;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;

/* JADX INFO: loaded from: direct-javac23.jar:Main.class */
public final class Main {
    private static int trace;

    private static int mark(int i) {
        trace = (trace * 10) + i;
        return i;
    }

    private static Byte byteValue(int i) {
        return Byte.valueOf((byte) i);
    }

    private static Short shortValue(int i) {
        return Short.valueOf((short) i);
    }

    private static Integer integerValue(int i) {
        return Integer.valueOf(i);
    }

    private static Long longValue(int i) {
        return Long.valueOf(i);
    }

    private static Float floatValue(int i) {
        return Float.valueOf(i);
    }

    private static Double doubleValue(int i) {
        return Double.valueOf(i);
    }

    private static Number numberValue(int i) {
        return Integer.valueOf(i);
    }

    private static Object objectValue(int i) {
        return String.valueOf(i);
    }

    public static Number[] exactNumber() {
        return new Number[]{numberValue(mark(1))};
    }

    public static Object[] objectElement() {
        return new Object[]{objectValue(mark(1))};
    }

    public static Object[] nullElement() {
        return new Object[]{null};
    }

    private static String stringValue(int i) {
        return String.valueOf(i);
    }

    private static StringBuilder builderValue(int i) {
        return new StringBuilder(String.valueOf(i));
    }

    private static ArrayList<Object> listValue(int i) {
        return new ArrayList<>(Collections.singletonList(Integer.valueOf(mark(i))));
    }

    private static HashSet<Object> setValue(int i) {
        return new HashSet<>(Collections.singletonList(Integer.valueOf(mark(i))));
    }

    private static IllegalStateException stateFailure(int i) {
        return new IllegalStateException(String.valueOf(mark(i)));
    }

    private static IllegalArgumentException argumentFailure(int i) {
        return new IllegalArgumentException(String.valueOf(mark(i)));
    }

    private static Integer[] integerArray(int i) {
        return new Integer[]{Integer.valueOf(i)};
    }

    private static Long[] longArray(int i) {
        return new Long[]{Long.valueOf(i)};
    }

    private static ArrayList<?>[] listArray(int i) {
        return new ArrayList[]{listValue(i)};
    }

    private static HashSet<?>[] setArray(int i) {
        return new HashSet[]{setValue(i)};
    }

    private static DerivedA derivedA(int i) {
        return new DerivedA(i);
    }

    private static DerivedB derivedB(int i) {
        return new DerivedB(i);
    }

    private static DerivedA[] derivedAArray(int i) {
        return new DerivedA[]{derivedA(i)};
    }

    private static DerivedB[] derivedBArray(int i) {
        return new DerivedB[]{derivedB(i)};
    }

    public static Number[] boxedDirect() {
        return new Number[]{new Byte((byte) mark(1)), new Short((short) mark(2)), new Integer(mark(3)), new Long(mark(4)), new Float(mark(5)), new Double(mark(6))};
    }

    public static CharSequence[] sequenceDirect() {
        return new CharSequence[]{new String(String.valueOf(mark(1))), new StringBuilder(String.valueOf(mark(2)))};
    }

    public static Collection<?>[] collectionDirect() {
        return new Collection[]{new ArrayList(Collections.singletonList(Integer.valueOf(mark(1)))), new HashSet(Collections.singletonList(Integer.valueOf(mark(2))))};
    }

    public static Throwable[] throwableDirect() {
        return new Throwable[]{new IllegalStateException(String.valueOf(mark(1))), new IllegalArgumentException(String.valueOf(mark(2)))};
    }

    public static Number[][] numberGridDirect() {
        return new Number[][]{new Integer[]{Integer.valueOf(mark(1))}, new Long[]{Long.valueOf(mark(2))}};
    }

    public static Collection<?>[][] collectionGridDirect() {
        return new Collection[][]{new ArrayList[]{listValue(mark(1))}, new HashSet[]{setValue(mark(2))}};
    }

    public static Base[] ownTwoHopDirect() {
        return new Base[]{new DerivedA(mark(1)), new DerivedB(mark(2))};
    }

    public static LocalInterface[] ownInterfaceDirect() {
        return new LocalInterface[]{new DerivedA(mark(1)), new DerivedB(mark(2))};
    }

    public static Base[][] ownGridDirect() {
        return new Base[][]{new DerivedA[]{new DerivedA(mark(1))}, new DerivedB[]{new DerivedB(mark(2))}};
    }

    private static void observe(Object[] objArr) {
        Object obj = objArr[0];
        if (obj == null) {
            System.out.println("null");
        } else {
            System.out.println(obj.getClass().getName());
        }
        System.out.println(trace);
    }

    public static void main(String[] strArr) {
        trace = 0;
        observe(boxedDirect());
        trace = 0;
        observe(sequenceDirect());
        trace = 0;
        observe(collectionDirect());
        trace = 0;
        observe(throwableDirect());
        trace = 0;
        observe(numberGridDirect());
        trace = 0;
        observe(collectionGridDirect());
        trace = 0;
        observe(ownTwoHopDirect());
        trace = 0;
        observe(ownInterfaceDirect());
        trace = 0;
        observe(ownGridDirect());
        trace = 0;
        observe(exactNumber());
        trace = 0;
        observe(objectElement());
        trace = 0;
        observe(nullElement());
    }
}
