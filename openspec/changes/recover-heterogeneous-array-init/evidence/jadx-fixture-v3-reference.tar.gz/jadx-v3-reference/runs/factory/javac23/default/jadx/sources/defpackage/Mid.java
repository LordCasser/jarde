package defpackage;

/* JADX INFO: loaded from: factory-javac23.jar:Mid.class */
public class Mid extends Base {
    public Mid(int i) {
        super(i);
    }
}
