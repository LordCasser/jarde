// default package

/* JADX INFO: loaded from: factory-javac23.jar:LocalInterface.class */
public interface LocalInterface {
    int value();
}
