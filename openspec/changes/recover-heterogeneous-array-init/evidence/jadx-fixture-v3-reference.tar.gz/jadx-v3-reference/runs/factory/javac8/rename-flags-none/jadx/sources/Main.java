// default package

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;

/* JADX INFO: loaded from: factory-javac8.jar:Main.class */
public final class Main {
    private static int trace;

    private static int mark(int i) {
        trace = (trace * 10) + i;
        return i;
    }

    private static Byte byteValue(int i) {
        return Byte.valueOf((byte) i);
    }

    private static Short shortValue(int i) {
        return Short.valueOf((short) i);
    }

    private static Integer integerValue(int i) {
        return Integer.valueOf(i);
    }

    private static Long longValue(int i) {
        return Long.valueOf(i);
    }

    private static Float floatValue(int i) {
        return Float.valueOf(i);
    }

    private static Double doubleValue(int i) {
        return Double.valueOf(i);
    }

    private static Number numberValue(int i) {
        return Integer.valueOf(i);
    }

    private static Object objectValue(int i) {
        return String.valueOf(i);
    }

    public static Number[] exactNumber() {
        return new Number[]{numberValue(mark(1))};
    }

    public static Object[] objectElement() {
        return new Object[]{objectValue(mark(1))};
    }

    public static Object[] nullElement() {
        return new Object[]{null};
    }

    private static String stringValue(int i) {
        return String.valueOf(i);
    }

    private static StringBuilder builderValue(int i) {
        return new StringBuilder(String.valueOf(i));
    }

    private static ArrayList<Object> listValue(int i) {
        return new ArrayList<>(Collections.singletonList(Integer.valueOf(mark(i))));
    }

    private static HashSet<Object> setValue(int i) {
        return new HashSet<>(Collections.singletonList(Integer.valueOf(mark(i))));
    }

    private static IllegalStateException stateFailure(int i) {
        return new IllegalStateException(String.valueOf(mark(i)));
    }

    private static IllegalArgumentException argumentFailure(int i) {
        return new IllegalArgumentException(String.valueOf(mark(i)));
    }

    private static Integer[] integerArray(int i) {
        return new Integer[]{Integer.valueOf(i)};
    }

    private static Long[] longArray(int i) {
        return new Long[]{Long.valueOf(i)};
    }

    private static ArrayList<?>[] listArray(int i) {
        return new ArrayList[]{listValue(i)};
    }

    private static HashSet<?>[] setArray(int i) {
        return new HashSet[]{setValue(i)};
    }

    private static DerivedA derivedA(int i) {
        return new DerivedA(i);
    }

    private static DerivedB derivedB(int i) {
        return new DerivedB(i);
    }

    private static DerivedA[] derivedAArray(int i) {
        return new DerivedA[]{derivedA(i)};
    }

    private static DerivedB[] derivedBArray(int i) {
        return new DerivedB[]{derivedB(i)};
    }

    public static Number[] boxedFactory() {
        return new Number[]{byteValue(mark(1)), shortValue(mark(2)), integerValue(mark(3)), longValue(mark(4)), floatValue(mark(5)), doubleValue(mark(6))};
    }

    public static CharSequence[] sequenceFactory() {
        return new CharSequence[]{stringValue(mark(1)), builderValue(mark(2))};
    }

    public static Collection<?>[] collectionFactory() {
        return new Collection[]{listValue(1), setValue(2)};
    }

    public static Throwable[] throwableFactory() {
        return new Throwable[]{stateFailure(1), argumentFailure(2)};
    }

    public static Number[][] numberGridFactory() {
        return new Number[][]{integerArray(mark(1)), longArray(mark(2))};
    }

    public static Collection<?>[][] collectionGridFactory() {
        return new Collection[][]{listArray(mark(1)), setArray(mark(2))};
    }

    public static Base[] ownTwoHopFactory() {
        return new Base[]{derivedA(mark(1)), derivedB(mark(2))};
    }

    public static LocalInterface[] ownInterfaceFactory() {
        return new LocalInterface[]{derivedA(mark(1)), derivedB(mark(2))};
    }

    public static Base[][] ownGridFactory() {
        return new Base[][]{derivedAArray(mark(1)), derivedBArray(mark(2))};
    }

    private static void observe(Object[] objArr) {
        Object obj = objArr[0];
        if (obj == null) {
            System.out.println("null");
        } else {
            System.out.println(obj.getClass().getName());
        }
        System.out.println(trace);
    }

    public static void main(String[] strArr) {
        trace = 0;
        observe(boxedFactory());
        trace = 0;
        observe(sequenceFactory());
        trace = 0;
        observe(collectionFactory());
        trace = 0;
        observe(throwableFactory());
        trace = 0;
        observe(numberGridFactory());
        trace = 0;
        observe(collectionGridFactory());
        trace = 0;
        observe(ownTwoHopFactory());
        trace = 0;
        observe(ownInterfaceFactory());
        trace = 0;
        observe(ownGridFactory());
        trace = 0;
        observe(exactNumber());
        trace = 0;
        observe(objectElement());
        trace = 0;
        observe(nullElement());
    }
}
