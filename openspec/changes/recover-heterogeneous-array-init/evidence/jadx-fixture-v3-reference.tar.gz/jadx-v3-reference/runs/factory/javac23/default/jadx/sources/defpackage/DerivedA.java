package defpackage;

/* JADX INFO: loaded from: factory-javac23.jar:DerivedA.class */
public final class DerivedA extends Mid {
    public DerivedA(int i) {
        super(i);
    }
}
