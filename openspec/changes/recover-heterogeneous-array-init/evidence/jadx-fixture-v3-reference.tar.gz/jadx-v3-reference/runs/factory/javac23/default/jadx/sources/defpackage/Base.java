package defpackage;

/* JADX INFO: loaded from: factory-javac23.jar:Base.class */
public class Base implements LocalInterface {
    private final int value;

    public Base(int i) {
        this.value = i;
    }

    @Override // defpackage.LocalInterface
    public int value() {
        return this.value;
    }
}
