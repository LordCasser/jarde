// default package

/* JADX INFO: loaded from: factory-javac8.jar:DerivedA.class */
public final class DerivedA extends Mid {
    public DerivedA(int i) {
        super(i);
    }
}
