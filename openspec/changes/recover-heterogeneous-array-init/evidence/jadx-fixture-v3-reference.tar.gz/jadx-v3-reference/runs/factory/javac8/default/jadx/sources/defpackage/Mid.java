package defpackage;

/* JADX INFO: loaded from: factory-javac8.jar:Mid.class */
public class Mid extends Base {
    public Mid(int i) {
        super(i);
    }
}
