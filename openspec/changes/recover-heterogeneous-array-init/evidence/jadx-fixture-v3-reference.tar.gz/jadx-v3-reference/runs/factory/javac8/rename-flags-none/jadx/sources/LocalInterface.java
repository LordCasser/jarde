// default package

/* JADX INFO: loaded from: factory-javac8.jar:LocalInterface.class */
public interface LocalInterface {
    int value();
}
