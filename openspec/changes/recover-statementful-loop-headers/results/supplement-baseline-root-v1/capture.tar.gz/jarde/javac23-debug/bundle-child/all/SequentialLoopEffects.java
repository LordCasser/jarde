// jarde: presentation of `SequentialLoopEffects` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class SequentialLoopEffects extends java.lang.Object {
    public int c;

    public int z;

    public int phase;

    public int evaluations;

    public int phaseOneCalls;

    public int phaseTwoCalls;

    public int lastInputC;

    public int lastInputA;

    public int lastValue;

    public int throwAt;

    public int overrideAt;

    public int overrideValue;

    public long phaseTrace;

    public final java.lang.RuntimeException marker;

    public SequentialLoopEffects() {
        // @method <init>()V
        // @declaration a constructor of `SequentialLoopEffects`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.marker = new java.lang.RuntimeException("scheduled");
        return;
    }

    private int next(int current, int a) {
        // @method next(II)I
        // @declaration an instance method of `SequentialLoopEffects`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        int value;
        this.evaluations += 1;
        if (this.phase == 1) {
            this.phaseOneCalls += 1;
        } else if (this.phase == 2) {
            this.phaseTwoCalls += 1;
    }
        this.phaseTrace = this.phaseTrace << 2 | (long) this.phase;
        this.lastInputC = current;
        this.lastInputA = a;
        value = current + a;
        if (this.evaluations == this.overrideAt) {
            value = this.overrideValue;
        }
        this.lastValue = value;
        if (this.evaluations == this.throwAt) {
            throw this.marker;
        } else {
            return value;
        }
    }

    public int run(int a, int initialC) {
        // @method run(II)I
        // @declaration an instance method of `SequentialLoopEffects`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        this.c = initialC;
        this.phase = 1;
        // @bytecode 10 11 12 13 16 17 20 23 24 27 29
        // the loop@1 rule did not claim the block at BCI 10: it requires a test block whose every instruction is part of a value expression, and the instruction at BCI 13 is not part of one, so presenting the structure would have moved that effect out of the shape it decides
        // @bytecode 32 35 36 37 40 43 46 47 48 51 52 53 54 57 58 61 62 65 67 70 71 72 75 78 81 82 85
        // 5 live block(s) are reachable only through edges the normal-flow view leaves out: [32, 35, 51, 70, 81]
    }
}
