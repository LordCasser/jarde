#!/usr/bin/env python3
"""Independent read-only review of a completed Seq1 supplemental baseline capture."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
SOURCE_SHA = '0f29256873f90ba08a1cd41171266a43d88e1d69d3bbec4bf69e129084558f1d'
DRIVER_SHA = 'c9c9d1b230a7ec165e1340548e0dea307ec7afe4bfb54412daf45af62196d92e'
PARSER_SHA = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
METHODS = {('<init>', '()V'), ('next', '(II)I'), ('run', '(II)I')}
FIELDS = {
    ('c', 'I'), ('z', 'I'), ('phase', 'I'), ('evaluations', 'I'),
    ('phaseOneCalls', 'I'), ('phaseTwoCalls', 'I'), ('lastInputC', 'I'), ('lastInputA', 'I'),
    ('lastValue', 'I'), ('throwAt', 'I'), ('overrideAt', 'I'), ('overrideValue', 'I'),
    ('phaseTrace', 'J'), ('marker', 'Ljava/lang/RuntimeException;'),
}
EXPECTED_ORACLE = [
    'ORIGINAL case=0 input=-1,10 result=7',
    'ORIGINAL case=1 input=-2,20 result=8',
    'ORIGINAL case=2 input=-3,20 result=8',
    'ORIGINAL case=3 input=2147483647,0 result=2147483647',
    'ORIGINAL case=4 input=-2147483640,0 result=16',
    'ORIGINAL case=5 input=2147483647,-10 result=2147483637',
    'EFFECT case=back-zero-second result=0 evals=3 phase1=2 phase2=1 trace=112 c=0 z=6',
    'EFFECT case=multiple-second result=7 evals=8 phase1=3 phase2=5 trace=11212222',
    'EFFECT case=early-throw sameMarker=true evals=9 phase1=4 phase2=5 c=1 value=3 trace=112122221',
    'EFFECT case=late-throw sameMarker=true evals=14 phase1=5 phase2=9 c=7 z=7 value=6 trace=11212222112222',
    'EFFECT case=same-instance-recovery result=7 evals=17 phase1=6 phase2=11 trace=11212222112222122',
]


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin_path(path: Path) -> dict:
    path = path.resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha_bytes(data)}


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def load_module(path: Path):
    spec = importlib.util.spec_from_file_location('seq1_review_classfile', path)
    need(spec is not None and spec.loader is not None, f'cannot load parser {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def fact_from_path(path: Path, parser) -> dict:
    data = path.read_bytes()
    facts = parser.parse_class_file(data)
    facts['constant_pool_utf8'] = utf8_entries(data, parser)
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': sha_bytes(data), **facts}


def utf8_entries(data: bytes, parser) -> list[dict]:
    pos = 8

    def take(size: int) -> bytes:
        nonlocal pos
        chunk = data[pos:pos + size]
        need(len(chunk) == size, 'truncated constant pool while auditing UTF8 entries')
        pos += size
        return chunk

    count = int.from_bytes(take(2), 'big')
    rows = []
    index = 1
    while index < count:
        tag = take(1)[0]
        if tag == 1:
            raw = take(int.from_bytes(take(2), 'big'))
            rows.append({'index': index, 'text': raw.decode('utf-8', errors='strict'),
                         'bytes_hex': raw.hex(), 'byte_boundaries': sorted(parser.byte_boundaries(raw))})
        elif tag in (3, 4):
            take(4)
        elif tag in (5, 6):
            take(8)
            index += 1
        elif tag in (7, 8, 16, 19, 20):
            take(2)
        elif tag in (9, 10, 11, 12, 17, 18):
            take(4)
        elif tag == 15:
            take(3)
        else:
            raise ValueError(f'unknown constant-pool tag {tag}')
        index += 1
    return rows


def verify_fact_record(record: dict, parser, label: str) -> dict:
    path = Path(record['path'])
    actual = fact_from_path(path, parser)
    need(actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256'],
         f'{label}: class bytes differ from captured pin')
    for key in ('minor', 'major', 'access', 'class_name', 'fields', 'methods', 'constant_pool_utf8'):
        need(actual.get(key) == record.get(key), f'{label}: recorded class fact differs for {key}')
    return actual


def method_keys(facts: dict) -> set[tuple[str, str]]:
    return {(m['name'], m['descriptor']) for m in facts['methods']}


def field_keys(facts: dict) -> set[tuple[str, str]]:
    return {(f['name'], f['descriptor']) for f in facts['fields']}


def verify_target_class(facts: dict, label: str, require_inventory: bool = True) -> dict:
    need(facts['major'] == 52, f'{label}: class major is not 52')
    need(facts['class_name'] == 'SequentialLoopEffects', f'{label}: unexpected class name')
    need(all(m['code'] is not None for m in facts['methods']), f'{label}: method missing Code')
    for method in facts['methods']:
        code = method['code']
        raw = bytes.fromhex(code['code_hex'])
        need(len(raw) == code['code_length'], f'{label}: Code length mismatch')
        need(code['bcis'] == sorted(set(code['bcis'])) and code['bcis'][0] == 0,
             f'{label}: invalid physical BCI list')
        need(code['bcis'] == parser_bcis(raw), f'{label}: BCI census disagrees with Code')
        for start, end, handler, catch in code['rows']:
            need(0 <= start < end <= len(raw) and handler in code['bcis'],
                 f'{label}: invalid exception table range/handler')
            need(catch >= 0, f'{label}: invalid catch index')
    if require_inventory:
        need(method_keys(facts) == METHODS, f'{label}: complete method inventory differs')
        need(field_keys(facts) == FIELDS, f'{label}: complete field inventory differs')
        need(facts['access'] == 0x31, f'{label}: class access flags differ')
        expected_methods = {('<init>', '()V'): 1, ('next', '(II)I'): 2, ('run', '(II)I'): 1}
        expected_fields = {name: (0x11 if name == 'marker' else 1) for name, _ in FIELDS}
        need(all(m['access'] == expected_methods[(m['name'], m['descriptor'])] for m in facts['methods']),
             f'{label}: method access flags differ')
        need(all(f['access'] == expected_fields[f['name']] for f in facts['fields']),
             f'{label}: field access flags differ')
    return {'methods': len(facts['methods']), 'fields': len(facts['fields']),
            'all_code_present': all(m['code'] is not None for m in facts['methods']),
            'bci_counts': {m['name'] + m['descriptor']: len(m['code']['bcis']) for m in facts['methods']}}


def parser_bcis(code: bytes) -> list[int]:
    fixed = {0x10: 2, 0x11: 3, 0x12: 2, 0x13: 3, 0x14: 3, 0x15: 2, 0x16: 2, 0x17: 2,
             0x18: 2, 0x19: 2, 0x36: 2, 0x37: 2, 0x38: 2, 0x39: 2, 0x3a: 2, 0x84: 3,
             0xa9: 2, 0xbc: 2, 0xc5: 4, 0xb2: 3, 0xb3: 3, 0xb4: 3, 0xb5: 3, 0xb6: 3,
             0xb7: 3, 0xb8: 3, 0xbb: 3, 0xbd: 3, 0xc0: 3, 0xc1: 3, 0xb9: 5, 0xba: 5,
             0xc8: 5, 0xc9: 5}
    fixed.update({op: 3 for op in range(0x99, 0xa9)})
    fixed.update({0xc6: 3, 0xc7: 3})
    bcis, pc = [], 0
    while pc < len(code):
        bcis.append(pc); op = code[pc]
        if op == 0xaa:
            aligned = (pc + 4) & ~3
            low = int.from_bytes(code[aligned + 4:aligned + 8], 'big', signed=True)
            high = int.from_bytes(code[aligned + 8:aligned + 12], 'big', signed=True)
            need(high >= low, f'invalid tableswitch at {pc}')
            size = aligned - pc + 12 + 4 * (high - low + 1)
        elif op == 0xab:
            aligned = (pc + 4) & ~3
            pairs = int.from_bytes(code[aligned + 4:aligned + 8], 'big', signed=True)
            need(pairs >= 0, f'invalid lookupswitch at {pc}')
            size = aligned - pc + 8 + 8 * pairs
        elif op == 0xc4:
            need(pc + 1 < len(code), 'truncated wide')
            size = 6 if code[pc + 1] == 0x84 else 4
        else:
            size = fixed.get(op, 1)
        need(pc + size <= len(code), f'instruction overruns Code at {pc}')
        pc += size
    return bcis


def verify_raw_commands(execution: dict, out: Path, root: Path) -> dict:
    commands = execution.get('commands', [])
    need(commands, 'receipt has no command rows')
    labels = set()
    raw_rows = 0
    for i, row in enumerate(commands, 1):
        need(row.get('index') == i, f'command index gap at {i}')
        label = row.get('label')
        need(isinstance(label, str) and label not in labels, f'missing/duplicate command label {label}')
        labels.add(label)
        need(Path(row.get('cwd', '')).resolve() == root.resolve(), f'{label}: cwd differs from workspace')
        need(row.get('guard_stop') is None, f'{label}: command was guard-stopped')
        need(isinstance(row.get('peak_target_bytes'), int) and row['peak_target_bytes'] <= 1024**3,
             f'{label}: target-size guard exceeded 1 GiB')
        need(isinstance(row.get('free_bytes_after'), int) and row['free_bytes_after'] >= 5 * 1024**3,
             f'{label}: free-space guard below 5 GiB')
        need(row.get('env_overrides') == {
            'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
            'CARGO_PROFILE_TEST_DEBUG': '0', 'RUST_TEST_THREADS': '1', 'CARGO_TERM_COLOR': 'always'},
            f'{label}: guard environment differs')
        for stream_name in ('stdout', 'stderr'):
            stream = row.get('streams', {}).get(stream_name)
            need(isinstance(stream, dict), f'{label}: missing {stream_name} raw pin')
            path = Path(stream['path']).resolve(strict=True)
            need(path.parent == (out / 'raw').resolve(), f'{label}: raw stream escapes output/raw')
            data = path.read_bytes()
            need(len(data) == stream['bytes'] and sha_bytes(data) == stream['sha256'],
                 f'{label}: {stream_name} raw pin mismatch')
            raw_rows += 1
    return {'command_count': len(commands), 'raw_stream_count': raw_rows, 'labels': labels}


def read_stream(command: dict, name='stdout') -> bytes:
    return Path(command['streams'][name]['path']).read_bytes()


def verify_runtime_argv(run: dict, command: dict, out: Path, vm_leg: str, jdks: dict) -> None:
    argv = command['argv']
    need(len(argv) == 10 and argv[1] == '-B', f'{run["label"]}: unexpected runtime argv shape {argv}')
    need(Path(argv[0]).name.startswith('python'), f'{run["label"]}: wrapper runtime is not Python')
    need(Path(argv[2]).resolve() == (out / 'runtime-bound.py').resolve(),
         f'{run["label"]}: runtime wrapper path differs')
    need(argv[3] == '30' and argv[5] == '-Xverify:all' and argv[6] == '-cp',
         f'{run["label"]}: runtime verification/timeout flags differ')
    need(Path(argv[4]).resolve() == Path(jdks[vm_leg]['java']['path']).resolve(),
         f'{run["label"]}: JVM executable does not match pinned {vm_leg}')
    roots = argv[7].split(os.pathsep)
    need(len(roots) == 2 and Path(roots[0]).resolve() == Path(run['classpath'][0]).resolve()
         and Path(roots[1]).resolve() == Path(run['classpath'][1]).resolve(),
         f'{run["label"]}: runtime classpath differs from target+driver roots')
    need(argv[8] == 'SequentialLoopEffectsDriver', f'{run["label"]}: unexpected driver class')
    need(Path(argv[9]).resolve() == Path(run['classpath'][0]).resolve(),
         f'{run["label"]}: CodeSource expected root differs from target class root')


def command_for(commands: list[dict], label: str) -> dict:
    rows = [row for row in commands if row.get('label') == label]
    need(len(rows) == 1, f'expected exactly one command named {label}, found {len(rows)}')
    return rows[0]


def exact_argv(command: dict, expected: list[str], label: str) -> None:
    need(command.get('argv') == expected,
         f'{label}: argv differs\nactual={command.get("argv")}\nexpected={expected}')


def verify_oracle(execution: dict, out: Path) -> dict:
    runs = execution.get('original_runtime', [])
    need(len(runs) == 8, f'expected 8 original JVM runs, found {len(runs)}')
    rows = []
    stdout_values = []
    for run in runs:
        command = next(c for c in execution['commands'] if c['index'] == run['command'])
        vm = run['runtime']
        need(vm in ('javac8', 'javac23'), f'{run["label"]}: unknown runtime leg')
        need(command['tool_leg'] == vm, f'{run["label"]}: command tool leg mismatch')
        verify_runtime_argv(run, command, out, vm, execution['jdk_manifest']['tools'])
        need(run['exit_code'] == command['exit_code'] == 0, f'{run["label"]}: original runtime failed')
        need(command['label'] == f'original-{run["profile"]}-{vm}', f'{run["label"]}: command label mismatch')
        stdout = read_stream(command)
        stderr = read_stream(command, 'stderr')
        need(stdout.decode('utf-8', errors='strict').splitlines() == EXPECTED_ORACLE,
             f'{run["label"]}: actual 11-line oracle differs from frozen driver expectations')
        need(not stderr, f'{run["label"]}: original JVM emitted stderr')
        need(run['stdout'] == stdout.decode('utf-8', errors='strict'), f'{run["label"]}: recorded stdout differs from raw')
        need(run['stderr_sha256'] == sha_bytes(stderr), f'{run["label"]}: recorded stderr hash differs from raw')
        cp_roots = [Path(p).resolve() for p in run['classpath']]
        need(len(cp_roots) == 2 and cp_roots[1] == (out / 'driver-classes').resolve(),
             f'{run["label"]}: driver root is not the separated compiled driver directory')
        stdout_values.append(stdout)
        need(run['target_tree_before'] == run['target_tree_after'], f'{run["label"]}: target class tree changed during JVM run')
        need(run['driver_tree_before'] == run['driver_tree_after'], f'{run["label"]}: driver class tree changed during JVM run')
        for tree, root_dir, what in ((run['target_tree_before'], cp_roots[0], 'target'),
                                     (run['driver_tree_before'], cp_roots[1], 'driver')):
            for relative, record in tree.items():
                actual_path = root_dir / relative
                need(Path(record['path']).resolve() == actual_path.resolve(), f'{run["label"]}: {what} tree path mismatch')
                need(pin_path(actual_path) == record, f'{run["label"]}: {what} class bytes changed')
        rows.append({'label': run['label'], 'vm': vm, 'case_lines': len(EXPECTED_ORACLE),
                     'stdout_sha256': sha_bytes(stdout), 'classpath': [str(p) for p in cp_roots]})
    need(len(set(stdout_values)) == 1, 'original JVM/profile oracle stdout differs')
    oracle_pin = execution.get('original_oracle')
    need(isinstance(oracle_pin, dict), 'captured original oracle file is missing')
    oracle_path = Path(oracle_pin['path']).resolve(strict=True)
    oracle = oracle_path.read_bytes()
    need(oracle == stdout_values[0], 'saved oracle bytes differ from observed original JVM bytes')
    need(len(oracle) == oracle_pin['bytes'] and sha_bytes(oracle) == oracle_pin['sha256'], 'saved oracle pin mismatch')
    need(execution.get('original_runtime_agreement') is True, 'collector did not record original runtime agreement')
    return {'run_count': len(rows), 'case_count': len(rows) * len(EXPECTED_ORACLE),
            'stdout': stdout_values[0].decode('utf-8'), 'rows': rows,
            'oracle': {'path': str(oracle_path), 'bytes': len(oracle), 'sha256': sha_bytes(oracle)}}


def verify_source_map(doc: dict, facts: dict, label: str) -> tuple[list[dict], dict]:
    text = doc.get('text')
    text_bytes = text.encode('utf-8') if isinstance(text, str) else b''
    boundaries = {0, len(text_bytes)}
    for pos, byte in enumerate(text_bytes):
        if byte & 0xC0 != 0x80:
            boundaries.add(pos)
    source_size = facts['bytes']
    source_digests = set()
    details = []
    projection = []
    for row in doc.get('methods', []):
        ident = row.get('item', {}).get('identity', {})
        name = bytes(ident.get('name', [])).decode('utf-8', errors='strict')
        desc = bytes(ident.get('descriptor', [])).decode('utf-8', errors='strict')
        method = next((m for m in facts['methods'] if (m['name'], m['descriptor']) == (name, desc)), None)
        need(method is not None, f'{label}: source-map method lacks physical target method {name}{desc}')
        code_bcis = set(method['code']['bcis'])
        outcome = row.get('outcome', {})
        body = outcome.get('report', {})
        method_text = body.get('text', '')
        method_bytes = method_text.encode('utf-8')
        boundaries = {0, len(method_bytes)} | {i for i, b in enumerate(method_bytes) if b & 0xC0 != 0x80}
        source_map = body.get('source_map') or {}
        segments = source_map.get('segments', []) if isinstance(source_map, dict) else []
        covered, bad_offsets, bad_origins, owners = set(), [], [], []
        for segment in segments:
            start, end = segment.get('start'), segment.get('end')
            if (not isinstance(start, int) or not isinstance(end, int) or not (0 <= start < end <= len(method_bytes))
                    or start not in boundaries or end not in boundaries):
                bad_offsets.append([start, end])
            stack = [segment.get('origin', {})]
            while stack:
                node = stack.pop()
                if isinstance(node, dict):
                    if 'bci' in node and 'method' in node:
                        origin_method = node['method']
                        need(origin_method == ident, f'{label}: map identity differs from the exact physical method item')
                        origin_key = (bytes(origin_method.get('name', [])).decode('utf-8', errors='strict'),
                                      bytes(origin_method.get('descriptor', [])).decode('utf-8', errors='strict'))
                        if origin_key != (name, desc) or node['bci'] not in code_bcis:
                            bad_origins.append({'identity': list(origin_key), 'bci': node['bci']})
                        else:
                            covered.add(node['bci'])
                        owner = origin_method.get('owner', {})
                        class_bytes = owner.get('class_bytes', {})
                        if class_bytes:
                            location = owner.get('location', {})
                            variant = owner.get('variant', {})
                            owners.append({'length': class_bytes.get('length'), 'digest': class_bytes.get('digest'),
                                           'variant': variant, 'location': location})
                            if isinstance(class_bytes.get('digest'), str):
                                source_digests.add(class_bytes['digest'])
                    stack.extend(v for v in node.values() if isinstance(v, (dict, list)))
                elif isinstance(node, list):
                    stack.extend(node)
        bad_owner = [o for o in owners if o['length'] != source_size
                     or o['variant'].get('kind') != 'base'
                     or (o['location'].get('snapshot') is not None
                         and o['location'].get('snapshot') != o['digest'])]
        need(not bad_offsets and not bad_origins, f'{label}: invalid method-local source map range/origin')
        if segments:
            need(owners, f'{label}: source-map segments have no physical owner')
        if owners:
            digests = {o['digest'] for o in owners}
            if len(digests) != 1:
                bad_owner.append({'inconsistent_digests': sorted(str(x) for x in digests)})
            need(not bad_offsets and not bad_origins and not bad_owner,
             f'{label}: invalid text range, physical origin, or class owner: {bad_offsets=} {bad_origins=} {bad_owner=}')
        item = {'identity': [name, desc], 'outcome': outcome.get('kind'), 'quality': body.get('quality'),
                'fallbacks': body.get('fallbacks'), 'regions': body.get('regions'), 'source_map': source_map}
        projection.append(item)
        details.append({'identity': [name, desc], 'outcome': outcome.get('kind'),
                        'quality': body.get('quality'), 'fallbacks': body.get('fallbacks'),
                        'segment_count': len(segments), 'mapped_bcis': sorted(covered),
                        'unmapped_bcis': sorted(code_bcis - covered), 'owner_entries': len(owners),
                        'owner_digests': sorted({o['digest'] for o in owners})})
    need(len(source_digests) <= 1, f'{label}: mixed physical input class identities in source map')
    return details, {'text_sha256': sha_bytes(text_bytes) if isinstance(text, str) else None,
                     'owner_digests': sorted(source_digests),
                     'method_projection': projection}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--execution', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    execution_path = args.execution.resolve(strict=True)
    out = execution_path.parent
    report_out = args.out.resolve()
    need(not report_out.exists(), f'review output already exists: {report_out}')
    root = args.root.resolve(strict=True)
    receipt = json.loads(execution_path.read_text(encoding='utf-8'))
    need(receipt.get('schema') == 'seq1-effectful-body-first-full-class-baseline-v1', 'unexpected receipt schema')
    need(receipt.get('status') == 'captured-pending-independent-review',
         f'capture is not terminal and reviewable: {receipt.get("status")}')
    command_rows = receipt.get('commands', [])
    source_copy = out / 'inputs/SequentialLoopEffects.java'
    driver_copy = out / 'driver-source/SequentialLoopEffectsDriver.java'
    driver_root = out / 'driver-classes'
    empty_sourcepath = out / 'empty-sourcepath'
    cli_path = Path(receipt['cli']['path']).resolve()
    java_tools = {leg: {name: receipt['jdk_manifest']['tools'][leg][name]['path']
                        for name in ('java', 'javac', 'javap')}
                  for leg in ('javac8', 'javac23')}

    result = {'schema': 'seq1-effectful-body-first-independent-review-v1',
              'execution': pin_path(execution_path), 'status': 'reviewing', 'checks': {}, 'findings': {}}
    commands = verify_raw_commands(receipt, out, root)
    result['checks']['raw_commands'] = {'ok': True, 'count': commands['command_count'],
                                        'raw_stream_count': commands['raw_stream_count']}
    result['checks']['guard_target'] = {'source_unchanged': receipt.get('source_unchanged'),
                                        'target_absent': receipt.get('target_absent'),
                                        'external_inputs_equal': receipt.get('external_input_pins_before') == receipt.get('external_input_pins_after')}
    need(result['checks']['guard_target']['source_unchanged'] is True
         and result['checks']['guard_target']['target_absent'] is True
         and result['checks']['guard_target']['external_inputs_equal'], 'source/tool/target guard failed')

    for key, record in receipt['external_input_pins_before'].items():
        need(pin_path(Path(record['path'])) == record, f'external input pin changed: {key}')
    need(receipt['cli']['sha256'] == receipt['cli_sha256_argument'], 'CLI digest argument does not bind receipt CLI')
    need(receipt['accepted_parser']['sha256'] == PARSER_SHA, 'accepted parser report pin differs')
    need(receipt['target_source']['sha256'] == SOURCE_SHA and receipt['driver_source']['sha256'] == DRIVER_SHA,
         'source or driver receipt pin differs')
    manifest_path = Path(receipt['jdk_manifest']['path']).resolve(strict=True)
    need(sha_bytes(manifest_path.read_bytes()) == JDK_MANIFEST_SHA, 'JDK manifest pin differs')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    for leg in ('javac8', 'javac23'):
        manifest_leg = next((row for row in manifest.get('legs', []) if row.get('leg') == leg), None)
        need(manifest_leg is not None, f'JDK manifest has no {leg}')
        for tool in ('java', 'javac', 'javap'):
            actual = manifest_leg.get('jdk_tools', {}).get(tool, {})
            recorded = receipt['jdk_manifest']['tools'][leg][tool]
            need(Path(actual.get('path', '')).resolve() == Path(recorded['path']).resolve()
                 and actual.get('sha256') == recorded['sha256'],
                 f'{leg} {tool}: manifest and receipt differ')
            need(pin_path(Path(recorded['path'])) == recorded, f'{leg} {tool}: tool bytes differ from manifest')
    for rel, expected in ((GUARD_REL, GUARD_SHA), (SCANNER_REL, SCANNER_SHA)):
        tool_path = root / rel
        need(sha_bytes(tool_path.read_bytes()) == expected, f'guard/scanner source pin mismatch: {tool_path}')
    compare_path = root / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
    compare_pin = receipt['external_input_pins_before']['compare']
    need(pin_path(compare_path) == compare_pin, 'comparison helper source pin differs')
    compare = load_module(compare_path)
    need(compare.source_closure(root) == receipt.get('source_pins_before') == receipt.get('source_pins_after'),
         'fresh product/source closure differs from captured before/after pins')
    need(pin_path(Path(receipt['jadx']['path'])) == receipt['external_input_pins_before']['jadx'],
         'JADX executable bytes changed')
    need(pin_path(Path(receipt['jadx_jar']['path'])) == receipt['external_input_pins_before']['jadx_jar'],
         'JADX JAR bytes changed')

    source = Path(receipt['target_source']['path']); driver = Path(receipt['driver_source']['path'])
    parser_path = Path(receipt['accepted_parser']['path'])
    need(sha_bytes(source.read_bytes()) == SOURCE_SHA and sha_bytes(driver.read_bytes()) == DRIVER_SHA,
         'frozen source/driver pin differs')
    parser_path = out / 'accepted-classfile-parser.py' if (out / 'accepted-classfile-parser.py').exists() else parser_path
    need(parser_path.is_file() and sha_bytes(parser_path.read_bytes()) == PARSER_SHA, 'accepted parser copy pin differs')
    parser = load_module(parser_path)

    driver_cmd = command_for(command_rows, 'compile-reflection-driver')
    expected_driver_argv = [java_tools['javac8']['javac'], '-source', '8', '-target', '8', '-g',
                            '-encoding', 'UTF-8', '-proc:none', '-classpath', str(empty_sourcepath),
                            '-sourcepath', str(empty_sourcepath), '-d', str(driver_root), str(driver_copy)]
    exact_argv(driver_cmd, expected_driver_argv, 'driver compilation')
    driver_facts = receipt.get('driver_classes', [])
    need(len(driver_facts) == 1, f'expected one independent driver class, found {len(driver_facts)}')
    driver_fact = verify_fact_record(driver_facts[0], parser, 'reflection driver')
    need(driver_fact['major'] == 52 and driver_fact['class_name'] == 'SequentialLoopEffectsDriver',
         'independent driver identity/major mismatch')
    need(Path(driver_fact['path']).resolve() == (driver_root / 'SequentialLoopEffectsDriver.class').resolve(),
         'independent driver output path mismatch')

    jadx_version = command_for(command_rows, 'jadx-version')
    exact_argv(jadx_version, [receipt['jadx']['path'], '--version'], 'JADX version check')
    version_output = read_stream(jadx_version) + read_stream(jadx_version, 'stderr')
    need(jadx_version['exit_code'] == 0 and b'1.5.6' in version_output, 'JADX 1.5.6 version check failed')

    def verify_bundle(profile: str) -> Path:
        bundle = out / 'inputs' / f'{profile}.jar'
        need(bundle.is_file(), f'{profile}: deterministic class bundle missing')
        import zipfile
        with zipfile.ZipFile(bundle) as jar:
            names = jar.namelist()
            need(names == ['SequentialLoopEffects.class'], f'{profile}: unexpected bundle entries {names}')
            member = jar.read(names[0])
        target = Path(next(row for row in receipt['original_profiles'] if row['label'] == profile)['target']['path'])
        need(member == target.read_bytes(), f'{profile}: bundled target bytes differ from original class')
        return bundle

    profiles = receipt.get('original_profiles', [])
    need(len(profiles) == 4, f'expected 4 original compiler/debug profile rows, found {len(profiles)}')
    profile_facts = {}
    for profile in profiles:
        label = profile['label']
        need(profile['compiler'] in ('javac8', 'javac23') and profile['debug'] in ('debug', 'no-debug'),
             f'{label}: unexpected profile coordinates')
        command = next(c for c in receipt['commands'] if c['index'] == profile['compile_command'])
        need(command['label'] == 'original-' + label and command['tool_leg'] == profile['compiler'],
             f'{label}: original compile command binding mismatch')
        need(profile['exit_code'] == command['exit_code'], f'{label}: compile exit code mismatch')
        source_flags = ['-source', '8', '-target', '8'] if profile['compiler'] == 'javac8' else ['--release', '8']
        debug_flag = '-g' if profile['debug'] == 'debug' else '-g:none'
        expected_compile_argv = [java_tools[profile['compiler']]['javac'], *source_flags, debug_flag,
                                 '-encoding', 'UTF-8', '-proc:none', '-classpath', str(empty_sourcepath),
                                 '-sourcepath', str(empty_sourcepath), '-d', profile['class_root'], str(source_copy)]
        exact_argv(command, expected_compile_argv, 'original-' + label)
        if profile['exit_code'] == 0:
            expected_path = Path(profile['class_root']) / 'SequentialLoopEffects.class'
            facts = verify_fact_record(profile['target'], parser, label)
            verify_target_class(facts, label)
            need(Path(profile['target']['path']).resolve() == expected_path.resolve(), f'{label}: target path mismatch')
            outputs = profile['class_outputs']
            need(len(outputs) == 1 and Path(outputs[0]['path']).resolve() == expected_path.resolve(),
                 f'{label}: original compiler output inventory is not exactly the target class')
            need(outputs[0]['sha256'] == facts['sha256'] and outputs[0]['bytes'] == facts['bytes'],
                 f'{label}: original output pin differs from target facts')
            profile_facts[label] = facts
        result['findings'].setdefault('original_profiles', []).append({
            'label': label, 'compiler': profile['compiler'], 'debug': profile['debug'],
            'exit_code': profile['exit_code'], 'class_files': [x['path'] for x in profile['class_outputs']],
        })
    need(set(profile_facts) == {f'{leg}-{debug}' for leg in ('javac8', 'javac23') for debug in ('debug', 'no-debug')},
         'not all four original profiles compiled successfully')
    ref = profile_facts['javac8-debug']
    for label, facts in profile_facts.items():
        need(method_keys(facts) == method_keys(ref) and field_keys(facts) == field_keys(ref),
             f'{label}: compiler profile changed method/field identity')
    layout = {}
    for method in ref['methods']:
        key = method['name'] + method['descriptor']
        bcis = method['code']['bcis']
        for label, facts in profile_facts.items():
            m = next(x for x in facts['methods'] if (x['name'], x['descriptor']) == (method['name'], method['descriptor']))
            need(m['code']['bcis'] == bcis, f'{label}: physical BCI layout differs for {key}')
        layout[key] = {'code_length': method['code']['code_length'], 'instruction_count': len(bcis), 'bcis': bcis}
    result['checks']['original_class_inventory'] = {'ok': True, 'profiles': list(profile_facts), 'layout': layout,
                                                    'method_count': len(METHODS), 'field_count': len(FIELDS)}

    oracle = verify_oracle(receipt, out)
    result['checks']['original_oracle'] = {'ok': True, **oracle}
    wrong = receipt.get('wrong_root_control')
    need(isinstance(wrong, dict) and wrong.get('rejected'), 'CodeSource wrong-root negative control failed')
    wrong_command = next(c for c in receipt['commands'] if c['index'] == wrong['command'])
    need(wrong_command['label'] == 'wrong-root-control' and wrong_command['exit_code'] != 0,
         'wrong-root command record mismatch')
    need(b'CodeSource mismatch' in read_stream(wrong_command, 'stderr'), 'wrong-root rejection lacks CodeSource mismatch')
    wrong_expected = [wrong_command['argv'][0], '-B', str(out / 'runtime-bound.py'), '30',
                      java_tools['javac23']['java'], '-Xverify:all', '-cp',
                      os.pathsep.join((receipt['original_profiles'][0]['class_root'], str(driver_root))),
                      'SequentialLoopEffectsDriver', str(empty_sourcepath)]
    exact_argv(wrong_command, wrong_expected, 'wrong-root control')
    result['checks']['wrong_root'] = {'ok': True, 'exit_code': wrong_command['exit_code']}

    # Verify full Jarde reports and default/all projections without assuming quality or fallback.
    jarde_rows = receipt.get('jarde_cells', [])
    need(len(jarde_rows) == 16, f'expected 16 Jarde source cells, found {len(jarde_rows)}')
    jarde_projection = {}
    jarde_detail = []
    for cell in jarde_rows:
        key = (cell['profile'], cell['form'], cell['evidence'])
        facts = profile_facts[cell['profile']]
        need(cell['form'] in ('child', 'bundle-child') and cell['evidence'] in ('default', 'all'), f'invalid Jarde cell {key}')
        report_path = Path(cell['report']['path'])
        raw_doc = report_path.read_bytes()
        need(len(raw_doc) == cell['report']['bytes'] and sha_bytes(raw_doc) == cell['report']['sha256'], f'{key}: report pin mismatch')
        command = next(c for c in receipt['commands'] if c['index'] == cell['command'])
        need(command['label'] == f'jarde-{cell["profile"]}-{cell["form"]}-{cell["evidence"]}', f'{key}: command label mismatch')
        input_target = Path(profile_facts[cell['profile']]['path'])
        if cell['form'] == 'child':
            cli_input, policy = input_target, 'single-class'
        else:
            cli_input = verify_bundle(cell['profile'])
            policy = 'plain-jar'
        need(pin_path(cli_input) == cell['input'], f'{key}: exact input pin mismatch')
        expected_cli = [str(cli_path), 'class-source', '--input', str(cli_input), '--class',
                        'SequentialLoopEffects', '--policy', policy, '--release', '8', '--format', 'json']
        if cell['evidence'] == 'all':
            expected_cli.extend(['--evidence', 'all'])
        exact_argv(command, expected_cli, str(key))
        need(raw_doc == read_stream(command), f'{key}: saved report differs from raw stdout')
        doc = json.loads(raw_doc)
        need(len(doc.get('methods', [])) == 3, f'{key}: duplicate or missing complete method rows')
        need(cell['exit_code'] == command['exit_code'], f'{key}: exit code mismatch')
        source_text = doc.get('text')
        need(cell['input']['sha256'] == sha_bytes(Path(cell['input']['path']).read_bytes()),
             f'{key}: original class/JAR input pin differs')
        if isinstance(source_text, str):
            whole_path = Path(cell['whole_source']['path'])
            source_bytes = whole_path.read_bytes()
            need(len(source_bytes) == cell['whole_source']['bytes']
                 and sha_bytes(source_bytes) == cell['whole_source']['sha256'], f'{key}: source-text pin mismatch')
            need(source_bytes == source_text.encode('utf-8'), f'{key}: local source differs from report.text')
        map_summary, projection = verify_source_map(doc, facts, str(key))
        observed = {tuple(row['identity']) for row in map_summary}
        need(observed == METHODS, f'{key}: report method inventory mismatch: {observed}')
        jarde_projection[(cell['profile'], cell['form'], cell['evidence'])] = projection
        jarde_detail.append({'profile': cell['profile'], 'form': cell['form'], 'evidence': cell['evidence'],
                             'exit_code': cell['exit_code'], 'text_present': isinstance(source_text, str),
                             'methods': map_summary})
    parity = []
    for profile in profile_facts:
        for form in ('child', 'bundle-child'):
            default = jarde_projection[(profile, form, 'default')]
            all_mode = jarde_projection[(profile, form, 'all')]
            same_text = default['text_sha256'] == all_mode['text_sha256']
            def quality_fallback_projection(projection: dict) -> list[tuple]:
                return [(row['identity'], row['outcome'], row['quality'], row['fallbacks'])
                        for row in projection['method_projection']]
            same_quality_fallback = quality_fallback_projection(default) == quality_fallback_projection(all_mode)
            same_source_map = [row['source_map'] for row in default['method_projection']] == [
                row['source_map'] for row in all_mode['method_projection']]
            parity.append({'profile': profile, 'form': form, 'text_equal': same_text,
                           'method_quality_fallback_equal': same_quality_fallback,
                           'source_map_equal': same_source_map,
                           'method_projection_equal': default['method_projection'] == all_mode['method_projection']})
    need(all(p['text_equal'] and p['method_quality_fallback_equal'] and p['source_map_equal'] for p in parity), 'default/all text, quality/fallback, or map parity differs')
    result['checks']['jarde'] = {'cell_count': len(jarde_rows), 'method_inventory': 'checked',
                                 'source_map_offsets_origins': 'checked', 'default_all': parity,
                                 'observations': jarde_detail}

    jadx_rows = receipt.get('jadx_cells', [])
    need(len(jadx_rows) == 8, f'expected 8 JADX source cells, found {len(jadx_rows)}')
    jadx_sources = []
    for cell in jadx_rows:
        command = next(c for c in receipt['commands'] if c['index'] == cell['command'])
        need(command['label'] == f'jadx-{cell["profile"]}-{cell["form"]}', 'JADX command/cell label mismatch')
        target_input = Path(profile_facts[cell['profile']]['path'])
        jadx_input = target_input if cell['form'] == 'child' else verify_bundle(cell['profile'])
        expected_dest = out / 'jadx' / cell['profile'] / cell['form']
        expected_jadx = [receipt['jadx']['path'], '--config', 'none', '--threads-count', '1', '--no-res',
                         '--rename-flags', 'none', '-d', str(expected_dest), str(jadx_input)]
        exact_argv(command, expected_jadx, command['label'])
        need(cell['exit_code'] == command['exit_code'], 'JADX cell exit code mismatch')
        for pin in cell.get('sources', []):
            path = Path(pin['path']); data = path.read_bytes()
            need(len(data) == pin['bytes'] and sha_bytes(data) == pin['sha256'], 'JADX source pin mismatch')
            jadx_sources.append({'profile': cell['profile'], 'form': cell['form'], **pin})
    result['checks']['jadx'] = {'cell_count': len(jadx_rows), 'source_files': jadx_sources,
                                'exit_codes': [{'profile': c['profile'], 'form': c['form'], 'exit_code': c['exit_code']} for c in jadx_rows]}

    compiles = receipt.get('generated_compiles', [])
    need(len(compiles) == 48, f'expected 48 generated compile cells, found {len(compiles)}')
    compile_index = {}
    compile_outcomes = []
    compile_coordinates = set()
    for cell in compiles:
        need(isinstance(cell.get('label'), str), 'generated compile row lacks root-v2 label')
        command = next(c for c in receipt['commands'] if c['index'] == cell['command'])
        need(command['label'] == 'recompile-' + cell['label'], f'{cell["label"]}: compile command label mismatch')
        need(command['exit_code'] == cell['exit_code'], f'{cell["label"]}: compile exit mismatch')
        before = cell.get('source_pins_before'); after = cell.get('source_pins_after')
        need(before == after, f'{cell["label"]}: emitted source changed during compilation')
        source_origin = cell['origin']; source_cell = cell['source_cell']
        coordinate = (source_origin, source_cell, cell['compiler'], cell['debug'])
        need(coordinate not in compile_coordinates, f'duplicate generated compile coordinate {coordinate}')
        compile_coordinates.add(coordinate)
        if source_origin == 'jarde':
            src_cell = next(c for c in jarde_rows
                            if source_origin + '/' + c['profile'] + '/' + c['form'] + '/' + c['evidence'] == source_cell)
            src_paths = [Path(src_cell['whole_source']['path'])]
        else:
            src_cell = next(c for c in jadx_rows
                            if source_origin + '/' + c['profile'] + '/' + c['form'] == source_cell)
            src_paths = [Path(x['path']) for x in src_cell['sources']]
        need([pin_path(p) for p in src_paths] == before, f'{cell["label"]}: source pin is not bound to source cell')
        compiler_leg = cell['compiler']
        need(compiler_leg in ('javac8', 'javac23') and cell['debug'] == 'debug',
             f'{cell["label"]}: unexpected generated compile profile')
        flags = ['-source', '8', '-target', '8'] if compiler_leg == 'javac8' else ['--release', '8']
        expected_generated_argv = [java_tools[compiler_leg]['javac'], *flags, '-g', '-encoding', 'UTF-8',
                                   '-proc:none', '-classpath', str(empty_sourcepath), '-sourcepath',
                                   str(empty_sourcepath), '-d', cell['class_root'], *[str(p) for p in src_paths]]
        exact_argv(command, expected_generated_argv, cell['label'])
        need(command['tool_leg'] == compiler_leg, f'{cell["label"]}: compiler command JDK leg mismatch')
        need({p.resolve() for p in Path(cell['class_root']).rglob('*.class')} == {Path(x['path']).resolve() for x in cell.get('class_outputs', [])}, f'{cell["label"]}: actual full class tree differs from captured output inventory')
        observed_classes = []
        for class_record in cell.get('class_outputs', []):
            fact = verify_fact_record(class_record, parser, cell['label'] + ' class output')
            verify_target_class(fact, cell['label'] + ' class output', require_inventory=False)
            observed_classes.append(fact)
        if cell['exit_code'] == 0:
            need(Path(cell['class_root']).is_dir(), f'{cell["label"]}: successful class root missing')
            target_path = Path(cell['class_root']) / 'SequentialLoopEffects.class'
            if target_path.is_file():
                target_fact = verify_fact_record(cell['target'], parser, cell['label'] + ' target')
                target_check = verify_target_class(target_fact, cell['label'] + ' target')
                need(len(cell['class_outputs']) == 1
                     and Path(cell['class_outputs'][0]['path']).resolve() == target_path.resolve(),
                     f'{cell["label"]}: successful full-source output class tree is not exactly the target class')
            else:
                target_check = None
                need(cell.get('runtime_status') == 'no-runtime: expected target class absent',
                     f'{cell["label"]}: missing-target compile not classified no-runtime')
        else:
            need(cell.get('runtime_status') == 'no-runtime: full-source compile failed',
                 f'{cell["label"]}: compile failure not explicitly classified no-runtime')
            target_check = None
        compile_index[cell['label']] = cell
        compile_command = command
        stderr_text = read_stream(compile_command, 'stderr').decode('utf-8', errors='replace')
        error_lines = [line for line in stderr_text.splitlines()
                       if 'error:' in line.lower() or '错误' in line or 'error ' in line.lower()]
        compile_outcomes.append({'label': cell['label'], 'origin': source_origin, 'source_cell': source_cell,
                                 'compiler': cell['compiler'], 'debug': cell['debug'], 'exit_code': cell['exit_code'],
                                 'class_files': len(cell['class_outputs']), 'target_inventory': target_check,
                                 'diagnostic_error_lines': error_lines,
                                 'stderr': stderr_text if cell['exit_code'] != 0 else ''})

    expected_source_cells = {
        ('jarde', f'jarde/{profile}/{form}/{evidence}')
        for profile in ('javac8-debug', 'javac8-no-debug', 'javac23-debug', 'javac23-no-debug')
        for form in ('child', 'bundle-child') for evidence in ('default', 'all')
    } | {
        ('jadx', f'jadx/{profile}/{form}')
        for profile in ('javac8-debug', 'javac8-no-debug', 'javac23-debug', 'javac23-no-debug')
        for form in ('child', 'bundle')
    }
    expected_compile_coordinates = {
        (origin, source_cell, compiler, 'debug')
        for origin, source_cell in expected_source_cells for compiler in ('javac8', 'javac23')
    }
    need(compile_coordinates == expected_compile_coordinates,
         'generated compile coordinate matrix differs: '
         f'missing={sorted(expected_compile_coordinates - compile_coordinates)} '
         f'extra={sorted(compile_coordinates - expected_compile_coordinates)}')

    generated_runtime = receipt.get('generated_runtime', [])
    original_oracle = Path(receipt['original_oracle']['path']).read_bytes()
    expected_generated_runtime_labels = set()
    for cell in compiles:
        has_target = cell['exit_code'] == 0 and (Path(cell['class_root']) / 'SequentialLoopEffects.class').is_file()
        if has_target:
            need(cell.get('target') is not None, f'{cell["label"]}: target class facts are missing')
            for vm in ('javac8', 'javac23'):
                expected_generated_runtime_labels.add(
                    f'generated-{cell["origin"]}-{cell["source_cell"]}-{cell["compiler"]}-{cell["debug"]}-{vm}')
        elif cell['exit_code'] == 0:
            need(cell.get('runtime_status') == 'no-runtime: expected target class absent',
                 f'{cell["label"]}: missing target has no no-runtime reason')
        else:
            need(cell.get('runtime_status') == 'no-runtime: full-source compile failed',
                 f'{cell["label"]}: compile failure has no no-runtime reason')
    runtime_keys = set()
    runtime_results = []
    for run in generated_runtime:
        key = run['label']
        need(key not in runtime_keys, f'duplicate generated runtime label {key}')
        runtime_keys.add(key)
        command = next(c for c in receipt['commands'] if c['index'] == run['command'])
        need(command['label'] == key and command['exit_code'] == run['exit_code'], f'{key}: runtime binding mismatch')
        verify_runtime_argv(run, command, out, run['runtime'], receipt['jdk_manifest']['tools'])
        compile_prefix = key.removeprefix('generated-')
        compile_label = compile_prefix.rsplit('-', 1)[0]
        compile_cell = compile_index.get(compile_label)
        need(compile_cell is not None and compile_cell['exit_code'] == 0, f'{key}: runtime has no successful compile')
        need(Path(compile_cell['class_root']).resolve() == Path(run['classpath'][0]).resolve(), f'{key}: target root mismatch')
        raw_stdout = read_stream(command)
        raw_stderr = read_stream(command, 'stderr')
        need(run['stdout'] == raw_stdout.decode('utf-8', errors='replace'), f'{key}: stored stdout differs from raw')
        need(run['stderr_sha256'] == sha_bytes(raw_stderr), f'{key}: stored stderr pin differs from raw')
        need(run['target_tree_before'] == run['target_tree_after']
             and run['driver_tree_before'] == run['driver_tree_after'], f'{key}: class tree changed during runtime')
        compile_tree = {
            Path(item['path']).relative_to(Path(compile_cell['class_root']).resolve()).as_posix(): {
                'path': str(Path(item['path']).resolve()), 'bytes': item['bytes'], 'sha256': item['sha256']}
            for item in compile_cell.get('class_outputs', [])
        }
        need(run['target_tree_before'] == compile_tree,
             f'{key}: runtime target class tree differs from full-source compile output inventory')
        for tree, root_dir in ((run['target_tree_before'], Path(run['classpath'][0])),
                               (run['driver_tree_before'], Path(run['classpath'][1]))):
            for relative, record in tree.items():
                path = root_dir / relative
                need(Path(record['path']).resolve() == path.resolve() and pin_path(path) == record,
                     f'{key}: target/driver class pin changed')
        same_stdout = raw_stdout == original_oracle
        need(run['matches_original_oracle'] == same_stdout, f'{key}: match flag differs from raw output comparison')
        passed = command['exit_code'] == 0 and same_stdout
        need(passed, f'{key}: rebuilt runtime did not exit successfully with the exact original oracle')
        runtime_results.append({'label': key, 'exit_code': run['exit_code'], 'runtime': run['runtime'],
                                'matches_original_oracle': same_stdout, 'passed': passed,
                                'stdout_sha256': sha_bytes(raw_stdout)})
    need(runtime_keys == expected_generated_runtime_labels,
         f'generated runtime/compile target matrix differs: missing={sorted(expected_generated_runtime_labels-runtime_keys)} extra={sorted(runtime_keys-expected_generated_runtime_labels)}')
    result['checks']['generated'] = {'compile_count': len(compiles),
                                     'compile_successes': sum(c['exit_code'] == 0 for c in compiles),
                                     'compile_failures': [c for c in compile_outcomes if c['exit_code'] != 0],
                                     'compile_cells': compile_outcomes,
                                     'runtime_count': len(generated_runtime),
                                     'runtime_results': runtime_results,
                                     'all_successful_rebuild_runtimes_match': bool(runtime_results)
                                     and all(r['passed'] for r in runtime_results)}

    expected_labels = {'compile-reflection-driver', 'wrong-root-control', 'jadx-version'}
    expected_labels.update(f'original-{leg}-{debug}' for leg in ('javac8', 'javac23')
                           for debug in ('debug', 'no-debug'))
    expected_labels.update(f'original-{leg}-{debug}-{vm}' for leg in ('javac8', 'javac23')
                           for debug in ('debug', 'no-debug') for vm in ('javac8', 'javac23'))
    expected_labels.update(f'jarde-{profile}-{form}-{evidence}'
                           for profile in ('javac8-debug', 'javac8-no-debug', 'javac23-debug', 'javac23-no-debug')
                           for form in ('child', 'bundle-child') for evidence in ('default', 'all'))
    expected_labels.update(f'jadx-{profile}-{form}'
                           for profile in ('javac8-debug', 'javac8-no-debug', 'javac23-debug', 'javac23-no-debug')
                           for form in ('child', 'bundle'))
    expected_labels.update('recompile-' + c['label'] for c in compiles)
    expected_labels.update(runtime_keys)
    need(commands['labels'] == expected_labels,
         f'command matrix labels differ: missing={sorted(expected_labels-commands["labels"])} extra={sorted(commands["labels"]-expected_labels)}')
    result['checks']['command_matrix'] = {'expected_count': len(expected_labels),
                                          'observed_count': commands['command_count'],
                                          'complete': True}

    report_dir = report_out
    report_dir.mkdir(parents=True)
    result['status'] = 'reviewed'
    result['finished_utc'] = __import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()
    (report_dir / 'review.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'review': str(report_dir / 'review.json'),
                      'commands': commands['command_count'], 'original_runs': len(oracle['rows']),
                      'generated_compiles': len(compiles), 'generated_runtimes': len(generated_runtime),
                      'all_rebuild_runtime_match': result['checks']['generated']['all_successful_rebuild_runtimes_match']}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
