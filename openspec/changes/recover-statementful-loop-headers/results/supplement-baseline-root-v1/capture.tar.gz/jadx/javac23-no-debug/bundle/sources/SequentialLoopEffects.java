// default package

/* JADX INFO: loaded from: javac23-no-debug.jar:SequentialLoopEffects.class */
public final class SequentialLoopEffects {
    public int c;
    public int z;
    public int phase;
    public int evaluations;
    public int phaseOneCalls;
    public int phaseTwoCalls;
    public int lastInputC;
    public int lastInputA;
    public int lastValue;
    public int throwAt;
    public int overrideAt;
    public int overrideValue;
    public long phaseTrace;
    public final RuntimeException marker = new RuntimeException("scheduled");

    private int next(int i, int i2) {
        this.evaluations++;
        if (this.phase == 1) {
            this.phaseOneCalls++;
        } else if (this.phase == 2) {
            this.phaseTwoCalls++;
        }
        this.phaseTrace = (this.phaseTrace << 2) | ((long) this.phase);
        this.lastInputC = i;
        this.lastInputA = i2;
        int i3 = i + i2;
        if (this.evaluations == this.overrideAt) {
            i3 = this.overrideValue;
        }
        this.lastValue = i3;
        if (this.evaluations == this.throwAt) {
            throw this.marker;
        }
        return i3;
    }

    public int run(int i, int i2) {
        this.c = i2;
        this.phase = 1;
        while (true) {
            this.z = next(this.c, i);
            if (this.z >= 7) {
                break;
            }
            this.c = this.z;
        }
        this.phase = 2;
        while (true) {
            int next = next(this.c, i);
            this.z = next;
            if (next < 7) {
                return this.c;
            }
            this.c = this.z;
        }
    }
}
