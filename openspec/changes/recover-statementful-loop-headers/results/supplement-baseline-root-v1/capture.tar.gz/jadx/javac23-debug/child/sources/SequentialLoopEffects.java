// default package

/* JADX INFO: loaded from: SequentialLoopEffects.class */
public final class SequentialLoopEffects {
    public int c;
    public int z;
    public int phase;
    public int evaluations;
    public int phaseOneCalls;
    public int phaseTwoCalls;
    public int lastInputC;
    public int lastInputA;
    public int lastValue;
    public int throwAt;
    public int overrideAt;
    public int overrideValue;
    public long phaseTrace;
    public final RuntimeException marker = new RuntimeException("scheduled");

    private int next(int current, int a) {
        this.evaluations++;
        if (this.phase == 1) {
            this.phaseOneCalls++;
        } else if (this.phase == 2) {
            this.phaseTwoCalls++;
        }
        this.phaseTrace = (this.phaseTrace << 2) | ((long) this.phase);
        this.lastInputC = current;
        this.lastInputA = a;
        int value = current + a;
        if (this.evaluations == this.overrideAt) {
            value = this.overrideValue;
        }
        this.lastValue = value;
        if (this.evaluations == this.throwAt) {
            throw this.marker;
        }
        return value;
    }

    public int run(int a, int initialC) {
        this.c = initialC;
        this.phase = 1;
        while (true) {
            this.z = next(this.c, a);
            if (this.z >= 7) {
                break;
            }
            this.c = this.z;
        }
        this.phase = 2;
        while (true) {
            int next = next(this.c, a);
            this.z = next;
            if (next >= 7) {
                this.c = this.z;
            } else {
                return this.c;
            }
        }
    }
}
