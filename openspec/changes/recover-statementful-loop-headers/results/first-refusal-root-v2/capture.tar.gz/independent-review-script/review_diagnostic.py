#!/usr/bin/env python3
"""Independent read-only review of the temporary Seq1 diagnostic build/API receipts."""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import re

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
CAPTURE = Path('/private/tmp/jarde-seq1-diagnostic-root-v2-20261018')
PREP = CAPTURE / 'prep'
BASELINE_PATH = Path('/private/tmp/jarde-testsequentialloops-baseline-run-root-v1-20261018/execution.json')
REGION_REL = 'crates/jarde-java/src/region.rs'
API_SOURCE_KEYS = ('usage', 'elapsed_millis')
PROFILES = ('debug', 'no-debug')
FORMS = ('child', 'bundle-child')
EVIDENCE = ('default', 'all')


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(path: Path) -> dict:
    need(not path.is_symlink(), f'refusing symlink: {path}')
    path = path.resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def verify_pin(record: dict, label: str) -> bytes:
    need(isinstance(record, dict), f'{label}: missing pin')
    path = Path(record.get('path', ''))
    need(path.is_absolute() and path.is_file() and not path.is_symlink(), f'{label}: missing/nonregular artifact {path}')
    data = path.read_bytes()
    need(len(data) == record.get('bytes') and sha(data) == record.get('sha256'), f'{label}: byte/SHA pin mismatch')
    return data


def read_json_pin(record: dict, label: str) -> tuple[dict, bytes]:
    raw = verify_pin(record, label)
    return json.loads(raw.decode('utf-8', errors='strict')), raw


def closure(root: Path) -> dict:
    files = [root / 'Cargo.toml', root / 'Cargo.lock']
    for name in ('src', 'crates', 'tests', 'openspec/changes/recover-exception-only-finally-completion'):
        directory = root / name
        if directory.exists():
            for current, dirs, names in os.walk(directory):
                dirs[:] = sorted(d for d in dirs if d not in {'.git', 'target', '__pycache__'})
                for name in sorted(names):
                    path = Path(current) / name
                    if path.is_file() and not path.is_symlink():
                        files.append(path)
    return {p.relative_to(root).as_posix(): pin(p) for p in sorted(set(files))
            if p.is_file() and not p.is_symlink()}


def raw_stream(row: dict, stream: str, expected_dir: Path | None = None) -> bytes:
    record = row.get('streams', {}).get(stream)
    data = verify_pin(record, f'command {row.get("index")} {stream}')
    if expected_dir is not None:
        expected = expected_dir / f'{row["index"]}.{stream}.raw'
        need(Path(record['path']) == expected, f'{row.get("label",row.get("index"))}/{stream}: unexpected raw path')
    return data


def normalize(value):
    if isinstance(value, dict):
        return {k: normalize(v) for k, v in value.items() if k not in API_SOURCE_KEYS}
    if isinstance(value, list):
        return [normalize(v) for v in value]
    return value


def probe_facts(raw: bytes, label: str) -> dict:
    text = raw.decode('utf-8', errors='strict')
    marker = 'SEQ1_PROBE code=MethodCodeFacts {'
    start = text.find(marker)
    need(start >= 0 and text.count(marker) == 1, f'{label}: raw stderr does not contain one actual MethodCodeFacts probe')
    code_text = text[start:]
    code_start_match = re.search(r'code_span: ByteSpan \{\s*start: (\d+),\s*length: (\d+),', code_text)
    need(code_start_match is not None, f'{label}: Code span absent from stderr')
    code_start, code_length = map(int, code_start_match.groups())
    instructions_start = code_text.index('instructions: [')
    operands_start = code_text.index('    operands: [', instructions_start)
    instruction_text = code_text[instructions_start:operands_start]
    pattern = re.compile(r'InstructionFact \{\s*bci: (\d+),\s*opcode: (\d+),\s*width: (\d+),\s*span: ByteSpan \{\s*start: (\d+),\s*length: (\d+),', re.S)
    ins = [tuple(map(int, m.groups())) for m in pattern.finditer(instruction_text)]
    need(len(ins) == 25, f'{label}: expected 25 instructions in raw physical Code, got {len(ins)}')
    cursor = 0
    for bci, _opcode, width, span_start, span_length in ins:
        need(bci == cursor and width == span_length and span_start == code_start + bci,
             f'{label}: raw physical instruction span is discontinuous at BCI {bci}')
        cursor += width
    need(cursor == code_length == 42 and ins[0][0] == 0, f'{label}: raw Code is not 42 bytes / 25 contiguous BCIs')
    bcis = [x[0] for x in ins]

    canonical_start = text.index('canonical=CanonicalCfg {', start)
    ssa_start = text.index('ssa=SsaTable', canonical_start)
    canonical_text = text[canonical_start:ssa_start]
    block_pattern = re.compile(r'CanonicalBlock \{\s*id: CanonicalBlockId \{\s*bci: (\d+),\s*path: \[\],\s*\},\s*blocks: \[\s*([0-9,\s]+?)\s*\],', re.S)
    blocks = []
    for m in block_pattern.finditer(canonical_text):
        ids = [int(x) for x in re.findall(r'\d+', m.group(2))]
        need(len(ids) == 1, f'{label}: unexpected canonical-block expansion in diagnostic graph')
        blocks.append({'bci': int(m.group(1)), 'physical_blocks': ids})
    need([b['bci'] for b in blocks] == [0, 2, 14, 17, 23, 34, 40], f'{label}: unexpected canonical block BCI map')
    id_bci = {idx: row['bci'] for idx, row in enumerate(blocks)}

    natural_pattern = re.compile(r'SEQ1_PROBE natural header=Some\(CanonicalBlockId \{ bci: (\d+), path: \[\] \}\) blocks=\{([^}]*)\} latches=\{([^}]*)\} successors=\[([^]]*)\] predecessors=\[([^]]*)\]')
    natural = []
    for m in natural_pattern.finditer(text):
        to_bcis = lambda group: sorted(id_bci[int(x.strip())] for x in group.split(',') if x.strip())
        natural.append({'header_bci': int(m.group(1)), 'block_bcis': to_bcis(m.group(2)),
                        'latch_bcis': to_bcis(m.group(3)), 'successor_bcis': to_bcis(m.group(4)),
                        'predecessor_bcis': to_bcis(m.group(5))})
    expected_natural = [
        {'header_bci': 2, 'block_bcis': [2, 17], 'latch_bcis': [17], 'successor_bcis': [14, 17], 'predecessor_bcis': [0, 17]},
        {'header_bci': 23, 'block_bcis': [23, 34], 'latch_bcis': [34], 'successor_bcis': [34, 40], 'predecessor_bcis': [14, 34]},
    ]
    need(natural == expected_natural, f'{label}: actual natural-loop graph differs: {natural}')

    classifier = text.find('SEQ1_PROBE classifier header=CanonicalBlockId { bci: 2, path: [] } frame=Frame {')
    need(classifier >= 0, f'{label}: actual header-2 classifier trace missing')
    frame_start = classifier + len('SEQ1_PROBE classifier header=CanonicalBlockId { bci: 2, path: [] } frame=Frame {')
    frame_end = text.index('} blocks=', frame_start)
    frame_lines = text[frame_start:frame_end].splitlines()
    frame = {}
    for line in frame_lines:
        line = line.strip()
        m = re.fullmatch(r'([a-z_]+): (.*),', line)
        if m:
            frame[m.group(1)] = m.group(2)
    expected_frame = {
        'boundary': 'None', 'if_arm': 'None', 'shared_tail': 'None', 'scope': 'None',
        'own_loop': 'None', 'allow_own_loop_entry': 'false', 'own_try': 'None',
        'named_catch_rows': 'None', 'own_finally': 'None', 'segmented_finally_rows': 'None',
        'multi_return_finally_rows': 'None', 'void_loop_finally': 'false', 'lock_guard_finally': 'false',
        'nested_finally_row': 'None', 'case_entries': 'None', 'loop_exit': 'None', 'loop_targets': '[]',
        'transfer_source_bci': 'None', 'switch_join': 'None', 'switch_branch_bci': 'None',
        'switch_fallthrough_target': 'None', 'switch_continue': 'None',
    }
    need(frame == expected_frame, f'{label}: classifier Frame is not the default frame: {frame}')
    need('SEQ1_PROBE effectful_dual candidate=None' in text, f'{label}: old effectful-dual classifier result is not None')
    op_match = re.search(r'^SEQ1_PROBE operation bci=5 operation=Some\(Store \{ slot: 4 \}\)$', text, re.M)
    need(op_match is not None, f'{label}: BCI5 Store is absent from actual decoded operations')
    fallback_start = text.find('SEQ1_PROBE header_tested candidate=Some(')
    need(fallback_start >= 0, f'{label}: header-tested classifier result absent')
    fallback_end = text.find('SEQ1_PROBE walk start=CanonicalBlockId { bci: 2', fallback_start)
    fallback_text = text[fallback_start:fallback_end if fallback_end >= 0 else None]
    need('Fallback {' in fallback_text and 'requirement: StatementFree,' in fallback_text
         and 'block_bci: 2,' in fallback_text and 'at: 5,' in fallback_text,
         f'{label}: raw header fallback does not identify StatementFree at BCI5')
    return {'code_length': code_length, 'physical_bci_count': len(bcis), 'bcis': bcis,
            'canonical_blocks': blocks, 'natural_loops': natural,
            'classifier': {'header_bci': 2, 'frame_default': True, 'effectful_dual': None,
                           'header_tested': 'Fallback/StatementFree at BCI5', 'operation_bci5': 'Store(slot=4)'}}


def verify_api(api: dict, baseline: dict, capture: Path) -> dict:
    need(api.get('schema') == 'cf11-sequential-loops-current-api-replay-v1'
         and api.get('status') == 'captured-pending-independent-review', 'API replay is not the expected complete capture')
    need(api.get('normalization', {}).get('excluded_recursive_keys') == ['elapsed_millis', 'usage'],
         'API replay normalization key set is not exactly usage and elapsed_millis')
    need(api.get('source_unchanged') is True and api.get('cli_unchanged') is True
         and api.get('target_absent') is True, 'API replay final source/CLI/target guard failed')
    base_receipt_pin = pin(BASELINE_PATH)
    need(api.get('baseline_receipt') == base_receipt_pin, 'API baseline receipt pin mismatch')
    baseline_cli = baseline.get('cli')
    need(api.get('baseline_cli') == baseline_cli, 'API baseline CLI record differs from baseline receipt')
    verify_pin(baseline_cli, 'baseline CLI')
    cli = api.get('cli')
    actual_cli = verify_pin(cli, 'candidate CLI')
    need(api.get('product_revision_argument') == '2de80b6a0777d773bc40502005a21ab307bc1b0c',
         'API product revision differs from diagnostic invocation')
    need(len(actual_cli) == 63291488, 'candidate CLI size differs from captured executable')

    baseline_commands = {x['index']: x for x in baseline.get('commands', [])}
    api_commands = api.get('commands')
    need(isinstance(api_commands, list) and len(api_commands) == 8, 'API replay does not contain eight CLI requests')
    api_by_index = {x.get('index'): x for x in api_commands}
    need(set(api_by_index) == set(range(1, 9)), 'API command indices are incomplete')
    baseline_cells = {(x['profile'], x['input_form'], x['evidence']): x for x in baseline['jarde_cells']}
    api_cells = {(x['profile'], x['input_form'], x['evidence']): x for x in api.get('cells', [])}
    expected = {(p, f, e) for p in PROFILES for f in FORMS for e in EVIDENCE}
    need(set(api_cells) == set(baseline_cells) == expected, 'baseline/API eight-cell request matrix differs')
    need(len(api.get('baseline_cells', [])) == 8, 'API replay baseline request inventory incomplete')
    baseline_cell_rows = {(x['profile'], x['input_form'], x['evidence']): x for x in api['baseline_cells']}
    checked, raw_count = [], 0
    for key in sorted(expected):
        current = api_cells[key]
        old_api_row = baseline_cells[key]
        saved_base_row = baseline_cell_rows[key]
        old_cmd = baseline_commands.get(old_api_row['command'])
        need(old_cmd is not None and saved_base_row.get('command') == old_cmd['index'], f'{key}: baseline command binding mismatch')
        command = api_by_index.get(current.get('command'))
        need(command is not None and current.get('exit_code') == 0 and command.get('exit_code') == 0
             and command.get('guard_stop') is None, f'{key}: current CLI command failed or guard stopped')
        need(current.get('baseline_command') == old_cmd['index'], f'{key}: wrong original command binding')
        expected_argv = list(old_cmd['argv'])
        expected_argv[0] = cli['path']
        need(command.get('argv') == expected_argv and current.get('argv') == expected_argv,
             f'{key}: current argv differs from original only by CLI executable')
        need(Path(command.get('cwd', '')) == ROOT, f'{key}: API command cwd differs from repository root')
        need(command.get('peak_target_bytes', 2**60) <= 1024**3 and command.get('free_bytes_after',0) >= 5*1024**3, f'{key}: resource guard mismatch')
        need(not ({'RUST_MIN_STACK', 'CARGO_TARGET_DIR'} & set(command.get('env_overrides', {}))), f'{key}: forbidden environment override')
        for channel in ('stdout', 'stderr'):
            data = raw_stream(command, channel, capture / 'api' / 'raw')
            raw_count += 1
            if channel == 'stdout':
                candidate_stdout = data
        old_stdout = raw_stream(old_cmd, 'stdout')
        raw_stream(old_cmd, 'stderr')
        raw_count += 2
        old_report = verify_pin(old_api_row['report'], f'{key} baseline report')
        saved_old_report = verify_pin(saved_base_row['report'], f'{key} API-saved baseline report')
        current_report = verify_pin(current['candidate_report'], f'{key} candidate report')
        need(old_report == saved_old_report == old_stdout, f'{key}: original report and raw stdout differ')
        need(candidate_stdout == current_report, f'{key}: candidate report differs from raw stdout')
        need(sha(old_stdout) == saved_base_row.get('stdout_sha256'), f'{key}: baseline stdout SHA differs from replay receipt')
        old_doc = json.loads(old_report.decode('utf-8', errors='strict'))
        new_doc = json.loads(current_report.decode('utf-8', errors='strict'))
        equal = normalize(old_doc) == normalize(new_doc)
        need(equal and current.get('normalized_equal') is True and current.get('diff_count') == 0,
             f'{key}: recursive report differs outside usage/elapsed_millis')
        need(Path(current['candidate_report']['path']) == capture / 'api' / 'reports' / key[0] / key[1] / key[2] / 'report.json',
             f'{key}: report path differs from expected cell')
        checked.append({'selector': list(key), 'original_command': old_cmd['index'], 'current_command': command['index'],
                        'normalized_report_equal': True, 'baseline_report': old_api_row['report'],
                        'candidate_report': current['candidate_report']})
    need(raw_count == 32, 'expected stdout/stderr for 8 baseline and 8 candidate CLI requests')

    input_before, input_after = api.get('input_pins_before'), api.get('input_pins_after')
    need(isinstance(input_before, dict) and len(input_before) == 4 and input_before == input_after,
         'API baseline class/archive input pins changed or incomplete')
    for path_text, record in input_before.items():
        need(record.get('path') == path_text, f'API input pin key/path mismatch: {path_text}')
        verify_pin(record, 'API class/archive input')
    return {'cli': cli, 'request_count': len(checked), 'raw_streams_checked': raw_count,
            'normalized_reports_equal': len(checked), 'input_pins_unchanged': len(input_before), 'cells': checked}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    out = args.out.resolve()
    need(not out.exists(), f'refusing existing report: {out}')
    review_script_pin = pin(Path(__file__))
    root = ROOT.resolve(strict=True)
    need(root == ROOT and not (root / 'target').exists() and not (root / 'target').is_symlink(),
         'workspace target is present or repository root differs')

    execution_path = CAPTURE / 'execution.json'
    build_path = CAPTURE / 'build/execution.json'
    api_path = CAPTURE / 'api/execution.json'
    execution, execution_raw = read_json_pin(pin(execution_path), 'diagnostic execution receipt')
    build, build_raw = read_json_pin(pin(build_path), 'guarded build receipt')
    api, api_raw = read_json_pin(pin(api_path), 'API replay receipt')
    baseline, baseline_raw = read_json_pin(pin(BASELINE_PATH), 'original baseline receipt')
    need(execution.get('status') == 'captured_pending_independent_review'
         and execution.get('source_restored') is True and execution.get('target_absent') is True,
         'top diagnostic receipt is not complete/restored')
    need(build.get('status') == 'commands_passed_pending_independent_acceptance'
         and build.get('default_stack') is True and build.get('source_unchanged') is True
         and build.get('target_absent') is True and build.get('source_changes') == [],
         'guarded build receipt/default-stack/source/target gate failed')

    prep_manifest = json.loads((PREP / 'manifest.json').read_text(encoding='utf-8'))
    original_region = (PREP / 'region.original').read_bytes()
    instrumented_region = (PREP / 'region.instrumented').read_bytes()
    region_path = root / REGION_REL
    need(sha(original_region) == prep_manifest.get('source_sha256')
         and sha(instrumented_region) == prep_manifest.get('instrumented_sha256'),
         'prep region source pins do not match manifest')
    need(region_path.read_bytes() == original_region, 'current region.rs is not the restored prep original')
    current_region_pin = pin(region_path)
    build_before, build_after = build.get('source_before'), build.get('source_after')
    need(isinstance(build_before, list) and build_before == build_after and len(build_before) == 3134,
         'guarded build source_before/source_after differ or are incomplete')
    build_map = {row['path'].removeprefix(str(root) + '/'): row for row in build_before}
    need(REGION_REL in build_map and build_map[REGION_REL]['bytes'] == len(instrumented_region)
         and build_map[REGION_REL]['sha256'] == sha(instrumented_region),
         'guarded build source snapshot does not contain exact instrumented region')
    api_source = api.get('source_pins_before')
    need(isinstance(api_source, dict) and REGION_REL in api_source, 'API instrumented source closure missing region.rs')
    need(api_source[REGION_REL]['bytes'] == len(instrumented_region)
         and api_source[REGION_REL]['sha256'] == sha(instrumented_region),
         'API source closure does not bind exact instrumented region')
    need(set(build_map).issubset(api_source), 'API source closure omits files from guarded build source snapshot')
    for rel, build_pin in build_map.items():
        need(api_source[rel] == build_pin, f'API/build instrumented source pins differ at {rel}')
    current_closure = closure(root)
    need(set(current_closure) == set(api_source), 'current restored source closure file set differs from instrumented API closure')
    changed = []
    for rel, recorded in api_source.items():
        need(Path(recorded['path']) == root / rel, f'API source closure path is not canonical for {rel}')
        actual = current_closure[rel]
        if actual != recorded:
            changed.append(rel)
    need(changed == [REGION_REL], f'current restored closure differs at paths other than region.rs: {changed}')
    need(current_closure[REGION_REL] == current_region_pin, 'current closure region pin mismatch')
    need(closure(root) == current_closure, 'current source closure changed during review')

    build_spec_path = Path(build['spec']['path'])
    spec_bytes = verify_pin(build['spec'], 'guarded build spec')
    spec = json.loads(spec_bytes.decode('utf-8', errors='strict'))
    need(spec == [['cargo', 'build', '-p', 'jarde-cli', '--bin', 'jarde-cli', '--locked']],
         'guarded build spec is not the default-stack jarde-cli build')
    need(build.get('runner') == pin(Path(build['runner']['path']))
         and build.get('guard') == pin(Path(build['guard']['path']))
         and build.get('scanner') == pin(Path(build['scanner']['path'])),
         'guarded build runner/guard/scanner pin mismatch')
    build_commands = build.get('commands', [])
    need(len(build_commands) == 2 and build_commands[0].get('argv') == spec[0]
         and build_commands[0].get('exit_code') == 0 and build_commands[0].get('guard_stop') is None
         and build_commands[1].get('argv') == ['cargo', 'clean'] and build_commands[1].get('exit_code') == 0
         and build_commands[1].get('cleanup_only') is True,
         'guarded build or cleanup command receipt mismatch')
    build_raw_count = 0
    for row in build_commands:
        for channel in ('stdout', 'stderr'):
            raw_stream(row, channel, CAPTURE / 'build/raw')
            build_raw_count += 1
    cli = build.get('cli')
    cli_bytes = verify_pin(cli, 'guarded build candidate CLI')
    need(execution.get('cli') == cli and api.get('cli') == cli and sha(cli_bytes) == cli['sha256'],
         'diagnostic, build and API candidate CLI pins do not agree')
    runner_path = Path(build['runner']['path'])
    build_spec_record = pin(build_spec_path)
    need(execution['commands'][0]['argv'] == ['python3', '-B', str(runner_path), str(CAPTURE / 'build'), str(build_spec_path)],
         'top diagnostic build-wrapper argv mismatch')
    api_argv = execution['commands'][1]['argv']
    need(api_argv[:2] == ['python3', '-B'] and Path(api_argv[2]).is_absolute(),
         'top diagnostic API-wrapper argv mismatch')
    need(api_argv[3:] == ['--cli', cli['path'], '--cli-sha256', cli['sha256'],
                         '--product-revision', api.get('product_revision_argument'), '--out', str(CAPTURE / 'api')],
         'top diagnostic API wrapper does not bind the built CLI/revision/output')
    need(build_spec_record['path'] == str(build_spec_path), 'build spec resolved path changed')

    top_raw = 0
    need(len(execution.get('commands', [])) == 2, 'top diagnostic receipt does not have exactly build/API wrappers')
    summaries = []
    for idx, row in enumerate(execution['commands'], 1):
        need(row.get('exit_code') == 0, f'top-level command {idx} failed')
        parsed_summary = None
        for channel in ('stdout', 'stderr'):
            record = row[channel]
            raw = verify_pin(record, f'top-level command {idx} {channel}')
            need(Path(record['path']) == CAPTURE / f'{idx}.{channel}.raw', 'top-level raw stream path mismatch')
            top_raw += 1
            if channel == 'stdout':
                parsed_summary = json.loads(raw.decode('utf-8', errors='strict'))
        summaries.append(parsed_summary)
    need(summaries[0].get('cli') == cli and summaries[1].get('commands') == 8
         and summaries[1].get('status') == 'captured-pending-independent-review',
         'top-level wrapper summaries do not bind build/API receipts')

    api_review = verify_api(api, baseline, CAPTURE)
    diagnostic_facts = []
    for row in api['commands']:
        stderr = raw_stream(row, 'stderr', CAPTURE / 'api/raw')
        diagnostic_facts.append({'command': row['index'], **probe_facts(stderr, row['label'])})

    api_collector_source = Path(execution['commands'][1]['argv'][2])
    need(api_collector_source.is_file() and CAPTURE.joinpath('api/collect_current_api.py').read_bytes()
         == api_collector_source.read_bytes(), 'copied API collector differs from invoked collector')
    # Recheck immutable receipt files, CLI, and restored source pins after deriving all findings.
    need(pin(Path(__file__)) == review_script_pin, 'review script changed during review')
    need(pin(execution_path) == {'path': str(execution_path), 'bytes': len(execution_raw), 'sha256': sha(execution_raw)},
         'top execution receipt changed during review')
    need(build_path.read_bytes() == build_raw and api_path.read_bytes() == api_raw
         and BASELINE_PATH.read_bytes() == baseline_raw, 'build/API/baseline receipt changed during review')
    need(pin(Path(cli['path'])) == cli and closure(root)[REGION_REL] == current_region_pin
         and not (root / 'target').exists(), 'final CLI/source/target guard changed during review')

    result = {
        'schema': 'seq1-temporary-diagnostic-independent-review-v1',
        'status': 'read_only_diagnostic_review_complete',
        'review_script': review_script_pin,
        'inputs': {'execution': pin(execution_path), 'build_execution': pin(build_path),
                   'api_execution': pin(api_path), 'baseline': pin(BASELINE_PATH),
                   'candidate_cli': cli, 'prep_original_region': pin(PREP / 'region.original'),
                   'prep_instrumented_region': pin(PREP / 'region.instrumented')},
        'build': {'status': build['status'], 'default_stack': True, 'build_and_clean_commands': len(build_commands),
                  'raw_streams_checked': build_raw_count, 'source_before_after_identical': True,
                  'instrumented_region_sha256': sha(instrumented_region), 'current_original_region_sha256': sha(original_region),
                  'current_closure_only_difference': changed, 'target_absent': True},
        'api': api_review,
        'diagnostic_stderr': {'probes': diagnostic_facts,
                              'code_gate': 'all eight raw stderr streams independently report 42 Code bytes and 25 contiguous physical instructions',
                              'natural_loop_and_classifier_facts': 'recomputed from the actual raw Debug representation'},
        'raw_streams_checked': top_raw + build_raw_count + api_review['raw_streams_checked'],
        'limitations': ['Temporary diagnostics show actual parsed/classified facts only; they do not constitute product behavior or a recovery implementation result.',
                        'The API report comparison ignores exactly recursive keys `usage` and `elapsed_millis`; no other key is normalized away.',
                        'The build source snapshot began with the diagnostic-instrumented region.rs; the current restored closure is required to differ at that one path and match prep/region.original.']
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'api_requests': api_review['request_count'],
                      'stderr_probes': len(diagnostic_facts), 'source_diff_paths': changed,
                      'out': str(out)}, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
