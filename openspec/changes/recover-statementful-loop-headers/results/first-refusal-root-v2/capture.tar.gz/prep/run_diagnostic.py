from pathlib import Path
import json,subprocess,hashlib,shutil,datetime
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');PREP=Path('/private/tmp/jarde-seq1-diagnostic-prep-root-v2-20261018');OUT=Path('/private/tmp/jarde-seq1-diagnostic-root-v2-20261018');OUT.mkdir()
src=ROOT/'crates/jarde-java/src/region.rs';original=(PREP/'region.original').read_bytes();candidate=(PREP/'region.instrumented').read_bytes();assert src.read_bytes()==original and not (ROOT/'target').exists()
r={'status':'running','scope':'temporary diagnostic CLI only, not product','commands':[],'source_before_sha256':hashlib.sha256(original).hexdigest(),'instrumented_sha256':hashlib.sha256(candidate).hexdigest()}
def pin(path):
 b=path.read_bytes();return {'path':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def run(argv):
 i=len(r['commands'])+1;so=OUT/f'{i}.stdout.raw';se=OUT/f'{i}.stderr.raw'
 with so.open('xb') as a,se.open('xb') as b:rc=subprocess.run(argv,cwd=ROOT,stdout=a,stderr=b).returncode
 row={'argv':argv,'exit_code':rc,'stdout':pin(so),'stderr':pin(se)};r['commands'].append(row);assert rc==0,row
try:
 src.write_bytes(candidate)
 run(['python3','-B',str(ROOT/'openspec/changes/recover-branch-throw-return-finally/tools/run_validation.py'),str(OUT/'build'),str(PREP/'build-spec.json')])
 cli=OUT/'build/candidate-cli';r['cli']=pin(cli)
 run(['python3','-B','/private/tmp/jarde-sequential-loops-current-api-prep-luna-v1-20261018/collect_current_api.py','--cli',str(cli),'--cli-sha256',r['cli']['sha256'],'--product-revision','2de80b6a0777d773bc40502005a21ab307bc1b0c','--out',str(OUT/'api')])
 r['status']='captured_pending_independent_review'
except BaseException as exc:r.update(status='failed',error=repr(exc));raise
finally:
 assert src.read_bytes()==candidate,'unexpected concurrent edit: refusing to overwrite'
 src.write_bytes(original);r['source_restored']=src.read_bytes()==original;r['target_absent']=not (ROOT/'target').exists();r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n');shutil.copytree(PREP,OUT/'prep',ignore=shutil.ignore_patterns('__pycache__'))
 print(json.dumps({k:r.get(k) for k in ('status','source_restored','target_absent','error')}))
