v1 actual command refused before compilation: jarde-cli bin is not in default-run packages. v2 selects existing -p jarde-cli, no source diagnostic changes. Old raw and finally cleanup preserved.
