#!/usr/bin/env python3
"""Replay the eight frozen TestSequentialLoops class-source requests against a supplied CLI.
Prepared only. Run later with python -B after independent review; this collector does not build the CLI.
"""
from __future__ import annotations
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys

ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
BASELINE = Path('/private/tmp/jarde-testsequentialloops-baseline-run-root-v1-20261018/execution.json')
COMPARE_REL = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
RAW_NORMALIZE_KEYS = {'usage', 'elapsed_millis'}
EXPECTED_CELLS = {(profile, form, evidence)
                  for profile in ('debug', 'no-debug')
                  for form in ('child', 'bundle-child')
                  for evidence in ('default', 'all')}


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def normalize(value):
    if isinstance(value, dict):
        return {key: normalize(child) for key, child in value.items() if key not in RAW_NORMALIZE_KEYS}
    if isinstance(value, list):
        return [normalize(child) for child in value]
    return value


def differences(left, right, path='$', out=None):
    if out is None: out = []
    if type(left) is not type(right):
        out.append({'path': path, 'baseline_type': type(left).__name__, 'current_type': type(right).__name__})
    elif isinstance(left, dict):
        for key in sorted(set(left) | set(right)):
            if key not in left or key not in right:
                out.append({'path': f'{path}.{key}', 'baseline_present': key in left, 'current_present': key in right})
            else:
                differences(left[key], right[key], f'{path}.{key}', out)
    elif isinstance(left, list):
        if len(left) != len(right):
            out.append({'path': path + '.length', 'baseline': len(left), 'current': len(right)})
        for i, (a, b) in enumerate(zip(left, right)):
            differences(a, b, f'{path}[{i}]', out)
    elif left != right:
        left_text, right_text = repr(left), repr(right)
        out.append({'path': path, 'baseline': left_text[:500], 'current': right_text[:500]})
    return out


def baseline_command_stream(compare, row, channel: str) -> bytes:
    return compare.command_artifact(row, channel)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--cli', type=Path, required=True)
    parser.add_argument('--cli-sha256', required=True)
    parser.add_argument('--product-revision', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    cli, out = args.cli.resolve(strict=True), args.out.resolve()
    if out.exists(): raise SystemExit(f'refusing existing output: {out}')
    if re.fullmatch(r'[0-9a-f]{64}', args.cli_sha256) is None:
        raise SystemExit('--cli-sha256 must be a lowercase 64-character SHA-256')
    if re.fullmatch(r'[0-9a-f]{40}', args.product_revision) is None:
        raise SystemExit('--product-revision must be a lowercase 40-character revision identifier')
    if sha(cli) != args.cli_sha256: raise SystemExit('candidate CLI SHA-256 differs from --cli-sha256')
    if not ROOT.is_dir() or (ROOT / 'target').exists() or (ROOT / 'target').is_symlink():
        raise SystemExit('workspace must exist and target must be absent before replay')
    if not BASELINE.is_file(): raise SystemExit(f'baseline receipt missing: {BASELINE}')

    compare = load(ROOT / COMPARE_REL, 'seq1_compare')
    guard_path, scanner_path = ROOT / GUARD_REL, ROOT / SCANNER_REL
    if compare.sha(guard_path) != GUARD_SHA256 or compare.sha(scanner_path) != SCANNER_SHA256:
        raise SystemExit('root guard/scanner source pin mismatch')
    guard = load(guard_path, 'seq1_guard')
    scanner = load(scanner_path, 'seq1_scanner')
    jdks, jdk_pin = compare.configured_jdks(ROOT / JDK_REL, JDK_SHA256)
    java = jdks['javac23']['tools']['java']
    if shutil.disk_usage(ROOT).free < 5 * 1024**3:
        raise SystemExit('5 GiB free-space guard failed before replay')

    baseline = json.loads(BASELINE.read_text(encoding='utf-8'))
    if baseline.get('schema') != 'cf11-original-testsequentialloops-baseline-v1':
        raise SystemExit('unexpected Seq1 baseline receipt schema')
    if baseline.get('status') not in ('captured-pending-independent-review', 'accepted'):
        raise SystemExit(f'baseline is not a complete capture: {baseline.get("status")}')
    if (baseline.get('source_unchanged') is not True or baseline.get('target_absent') is not True
            or baseline.get('source_pins_before') != baseline.get('source_pins_after')):
        raise SystemExit('baseline lacks source-unchanged/target-absent closure')
    old_cli = baseline.get('cli') or {}
    old_cli_path = Path(old_cli.get('path', '')).resolve(strict=True)
    if compare.pin(old_cli_path) != old_cli or baseline.get('cli_sha256_argument') != old_cli.get('sha256'):
        raise SystemExit('baseline CLI path/digest pin mismatch')
    cells = baseline.get('jarde_cells')
    if not isinstance(cells, list) or len(cells) != 8:
        raise SystemExit('baseline does not contain exactly eight Jarde API cells')
    cell_keys = [(x.get('profile'), x.get('input_form'), x.get('evidence')) for x in cells]
    if set(cell_keys) != EXPECTED_CELLS or len(set(cell_keys)) != 8:
        raise SystemExit('baseline API cell matrix is incomplete or duplicated')
    commands = {row.get('index'): row for row in baseline.get('commands', [])}
    if len(commands) != len(baseline.get('commands', [])):
        raise SystemExit('baseline command indices are duplicated')

    rows = []
    input_pins_before = {}
    for cell in cells:
        idx = cell.get('command')
        row = commands.get(idx)
        if not isinstance(row, dict) or row.get('exit_code') != 0 or row.get('guard_stop') is not None:
            raise SystemExit(f'baseline command {idx} did not complete successfully')
        argv = row.get('argv')
        if not isinstance(argv, list) or not argv or Path(argv[0]).resolve() != old_cli_path:
            raise SystemExit(f'baseline command {idx} does not invoke the pinned original CLI')
        input_pin = cell.get('input')
        input_path = Path(input_pin.get('path', '')).resolve(strict=True)
        if compare.pin(input_path) != input_pin:
            raise SystemExit(f'baseline input changed: {input_path}')
        if input_path.as_posix() != argv[argv.index('--input') + 1]:
            raise SystemExit(f'baseline command {idx} input argument differs from its cell pin')
        old_report_pin = cell.get('report')
        report_path = Path(old_report_pin.get('path', '')).resolve(strict=True)
        if compare.pin(report_path) != old_report_pin:
            raise SystemExit(f'baseline report changed: {report_path}')
        old_stdout = baseline_command_stream(compare, row, 'stdout')
        baseline_command_stream(compare, row, 'stderr')
        if old_stdout != report_path.read_bytes():
            raise SystemExit(f'baseline raw stdout differs from saved report: command {idx}')
        old_doc = json.loads(old_stdout)
        input_pins_before[str(input_path)] = input_pin
        rows.append({'cell': cell, 'baseline_command': row, 'input': input_path,
                     'old_report': report_path, 'old_report_pin': old_report_pin,
                     'old_stdout': old_stdout, 'old_doc': old_doc})

    source_before = compare.source_closure(ROOT)
    cli_before = compare.pin(cli)
    input_before_actual = {path: compare.pin(Path(path)) for path in input_pins_before}
    if input_before_actual != input_pins_before:
        raise SystemExit('baseline inputs differ from their pre-replay pins')

    out.mkdir(parents=True)
    raw_dir = out / 'raw'; raw_dir.mkdir()
    guard.ROOT, guard.OUT = ROOT, raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda _index, _stdout: None
    report = {
        'schema': 'cf11-sequential-loops-current-api-replay-v1', 'status': 'running',
        'product_revision_argument': args.product_revision,
        'cli': cli_before, 'baseline_receipt': compare.pin(BASELINE),
        'baseline_cli': old_cli, 'jdk': jdk_pin,
        'compare_helper': compare.pin(ROOT / COMPARE_REL), 'guard': compare.pin(guard_path),
        'scanner': compare.pin(scanner_path), 'source_pins_before': source_before,
        'input_pins_before': input_before_actual, 'cells': [],
        'baseline_cells': [{'profile': x['cell']['profile'], 'input_form': x['cell']['input_form'],
                            'evidence': x['cell']['evidence'], 'command': x['baseline_command']['index'],
                            'input': x['cell']['input'], 'report': x['old_report_pin'],
                            'stdout_sha256': hashlib.sha256(x['old_stdout']).hexdigest()} for x in rows],
        'normalization': {'excluded_recursive_keys': sorted(RAW_NORMALIZE_KEYS)},
        'commands': [],
    }
    compare.write_json(out / 'execution.json', report)

    def run(argv, label):
        if (ROOT / 'target').exists() or (ROOT / 'target').is_symlink():
            raise RuntimeError('workspace target appeared during API replay')
        env = compare.clean_env(dict(os.environ), jdks['javac23'])
        env.update(guard.ENV_VALUES)
        env.pop('RUST_MIN_STACK', None)
        result = guard.run_command(len(report['commands']) + 1, [str(x) for x in argv], env)
        result['label'] = label
        result['tool_leg'] = 'javac23'
        report['commands'].append(result)
        compare.write_json(out / 'execution.json', report)
        if result['guard_stop'] is not None:
            raise RuntimeError(f'guard stopped API command {label}: {result["guard_stop"]}')
        return result

    try:
        for item in rows:
            cell, base_row = item['cell'], item['baseline_command']
            new_argv = [str(cli), *base_row['argv'][1:]]
            label = f"current-{cell['profile']}-{cell['input_form']}-{cell['evidence']}"
            run_row = run(new_argv, label)
            raw_stdout = compare.command_artifact(run_row, 'stdout')
            raw_stderr = compare.command_artifact(run_row, 'stderr')
            saved = out / 'reports' / cell['profile'] / cell['input_form'] / cell['evidence'] / 'report.json'
            saved.parent.mkdir(parents=True, exist_ok=True)
            saved.write_bytes(raw_stdout)
            result = {'profile': cell['profile'], 'input_form': cell['input_form'],
                      'evidence': cell['evidence'], 'baseline_command': base_row['index'],
                      'command': run_row['index'], 'argv': new_argv,
                      'input': item['cell']['input'], 'baseline_report': item['old_report_pin'],
                      'candidate_report': compare.pin(saved), 'exit_code': run_row['exit_code']}
            if run_row['exit_code'] == 0:
                current_doc = json.loads(raw_stdout)
                left, right = normalize(item['old_doc']), normalize(current_doc)
                diff = differences(left, right)
                result['normalized_equal'] = not diff
                result['diff_count'] = len(diff)
                if diff:
                    diff_path = saved.with_name('normalized-diff.json')
                    compare.write_json(diff_path, {'differences': diff})
                    result['difference_file'] = compare.pin(diff_path)
            else:
                result['normalized_equal'] = False
                result['stderr'] = raw_stderr.decode('utf-8', errors='replace')
            report['cells'].append(result)
            compare.write_json(out / 'execution.json', report)

        if compare.source_closure(ROOT) != source_before:
            raise RuntimeError('workspace source closure changed during API replay')
        if compare.pin(cli) != cli_before:
            raise RuntimeError('candidate CLI changed during replay')
        input_after = {path: compare.pin(Path(path)) for path in input_pins_before}
        if input_after != input_before_actual:
            raise RuntimeError('baseline inputs changed during replay')
        if compare.pin(BASELINE) != report['baseline_receipt']:
            raise RuntimeError('baseline receipt changed during replay')
        if (ROOT / 'target').exists() or (ROOT / 'target').is_symlink():
            raise RuntimeError('workspace target remains after replay')
        report.update({'source_unchanged': True, 'cli_unchanged': True,
                       'input_pins_after': input_after, 'target_absent': True,
                       'status': 'captured-pending-independent-review'})
        return 0
    except BaseException as exc:
        report['status'] = 'failed'
        report['error'] = repr(exc)
        raise
    finally:
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out / 'execution.json', report)
        shutil.copy2(__file__, out / 'collect_current_api.py')
        print(json.dumps({'status': report['status'], 'commands': len(report['commands']),
                          'out': str(out), 'error': report.get('error')}))


if __name__ == '__main__':
    sys.dont_write_bytecode = True
    raise SystemExit(main())
