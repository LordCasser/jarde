import json,hashlib,pathlib,re
P=pathlib.Path
root=P('/Users/lordcasser/workspace/projects/jarde')
base=P('/private/tmp/jarde-statementful-loop-header-api-replay-root-v1-20261018')
out=P(__file__).parent
checks=[]
def check(label,condition):
 checks.append({'gate':label,'passed':bool(condition)})
 if not condition: raise AssertionError(label)
def pin(p):
 p=P(p).resolve();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def valid(x): return pin(x['path'])==x
def strip(x):
 if isinstance(x,dict):return {k:strip(v) for k,v in x.items() if k!='usage'}
 if isinstance(x,list):return [strip(v) for v in x]
 return x
def method_projection(doc):
 rows=[]
 for m in doc['methods']:
  r=m.get('outcome',{}).get('report') or {}
  rows.append({'identity':m['item']['identity'],'index':m['item']['index'],'text':m.get('text'),'declaration':m.get('declaration'),'kind':m.get('outcome',{}).get('kind'),**{k:r.get(k) for k in ('quality','fallbacks','source_map','diagnostics')}})
 return rows
try:
 d=json.loads((base/'execution.json').read_text());check('terminal capture',d['status']=='captured-pending-independent-review')
 check('exact cells',len(d['commands'])==56 and len(d['positive_cells'])==44 and len(d['negative_cells'])==12)
 check('candidate pin',valid(d['new_cli']) and d['new_cli']['sha256']=='aabf62fe373876d176e6001bf3ed1fd84f80d2169ff5e787c4095c5d253c63d9' and d['new_cli']==d['new_cli_after'])
 check('closure stable',d['source_pins_before']==d['source_pins_after'] and d['source_unchanged'])
 check('external closure stable',d['external_inputs_before']==d['external_inputs_after'] and d['external_inputs_unchanged'])
 for name,x in d['external_inputs_before'].items():check('external '+name,valid(x))
 check('target absent',d['target_absent_after'] and not (root/'target').exists())
 commands={c['index']:c for c in d['commands']}
 for i,c in commands.items():
  check('command '+str(i),c['guard_stop'] is None and c['argv'][0]==d['new_cli']['path'] and c['free_bytes_after']>=5*1024**3 and c['peak_target_bytes']<=1024**3 and 'RUST_MIN_STACK' not in c['env_overrides'])
  for channel in ('stdout','stderr'):
   check('raw '+str(i)+channel,valid(c['streams'][channel]) and valid(c[channel+'_raw']) and c['streams'][channel]['sha256']==c[channel+'_raw']['sha256'])
 families={}
 for row in d['positive_cells']:
  family=row['family'];families[family]=families.get(family,0)+1;c=commands[row['new_command_index']]
  old=json.loads(P(row['old_report']['path']).read_text());new=json.loads(P(row['json_artifact']['path']).read_text());receipt=json.loads(P(d['old_receipts'][family]['pin']['path']).read_text());previous=next(x for x in receipt['commands'] if x['index']==row['old_command_index'])
  check('positive argv '+str(c['index']),c['argv'][1:]==previous['argv'][1:] and c['exit_code']==0 and valid(row['old_input']))
  check('positive full reports '+str(c['index']),valid(row['old_report']) and valid(row['json_artifact']) and strip(old)==strip(new))
  check('positive whole Java '+str(c['index']),valid(row['old_generated_source']) and valid(row['full_source_artifact']) and old['text'].encode()==new['text'].encode()==P(row['full_source_artifact']['path']).read_bytes()==P(row['old_generated_source']['path']).read_bytes())
 check('positive family counts',families=={'original':8,'supplement':16,'volatile':16,'legacy':4})
 pairs={};negative_summary=[]
 for row in d['negative_cells']:
  c=commands[row['command_index']];doc=json.loads(P(row['json_artifact']['path']).read_text());key=(row['input_leg'],row['file_class']);pairs.setdefault(key,{})[row['evidence']]=doc
  check('negative capture '+str(c['index']),c['exit_code'] in (0,4) and valid(row['input_class']) and valid(row['json_artifact']) and valid(row['full_source_artifact']) and P(row['full_source_artifact']['path']).read_bytes()==doc['text'].encode())
  negative_summary.append({'leg':key[0],'class':key[1],'evidence':row['evidence'],'exit':c['exit_code'],'methods':method_projection(doc)})
 for key,pair in pairs.items():check('negative default/all '+str(key),set(pair)=={'default','all'} and pair['default']['text']==pair['all']['text'] and method_projection(pair['default'])==method_projection(pair['all']))
 result={'status':'accepted','checks':checks,'positive_api_cells':44,'negative_api_cells':12,'raw_stream_pairs':56,'negative_summary':negative_summary,'matrix_reuse':'No JDK rerun. Complete generated Java and every non-usage JSON field are identical to the accepted old API/matrix inputs.','execution':pin(base/'execution.json'),'reviewer':pin(__file__)}
except Exception as e:
 result={'status':'failed','checks':checks,'error':repr(e)}
(out/'root-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('checks','negative_summary')},ensure_ascii=False))
if result['status']!='accepted':raise SystemExit(1)
