#!/usr/bin/env python3
"""Prepare a guarded API replay for statementful loop-header changes.

This collector is intentionally unexecuted at preparation time. It runs only the
parameterized Jarde CLI; it never runs javac, java, JADX, Cargo, Git, or network.
"""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, shutil, sys
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
COMPARE = ROOT / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
ROLLUP = ROOT / 'openspec/changes/recover-statementful-loop-headers/results/complete-semantic-rollup-root-v1.json'
OLD_RECEIPTS = {
    'original': Path('/private/tmp/jarde-seq1-original-final-pipeline-run-root-v1-20261018/baseline/execution.json'),
    'supplement': Path('/private/tmp/jarde-seq1-supplement-final-matrix-root-v1-20261018/execution.json'),
    'volatile': Path('/private/tmp/jarde-field-copy-matrix-root-v1-20261018/execution.json'),
    'legacy': Path('/private/tmp/jarde-cf11-forcondition-refusals-baseline-root-v1-20261018/execution.json'),
}
OLD_CLI_SHA = '0bb89f827c1e2b6b0e215d1940299be046a7adc57866389d87e6595ba0295677'
NEG_ROOT = ROOT / 'tests/fixtures/recover-loop-test-copy-store'
NEG_CLASSES = (('Probe', 'Probe'), ('ProbeControls', 'ProbeControls'), ('MultiCopy', 'Probe'))
NEG_LEGS = (('v8', 'javac23'), ('v8-javac8', 'javac8'))
EVIDENCE = ('default', 'all')
EXPECTED_POSITIVE_COUNTS = {'original': 8, 'supplement': 16, 'volatile': 16, 'legacy': 4}
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')
DEFAULT_OUT = Path('/private/tmp/jarde-statementful-loop-header-api-replay-root-v1-20261018')


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha_bytes(data)}


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    tmp.replace(path)


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper {path}')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def remove_usage(value):
    if isinstance(value, dict):
        return {k: remove_usage(v) for k, v in value.items() if k != 'usage'}
    if isinstance(value, list):
        return [remove_usage(v) for v in value]
    return value


def changed_paths(a, b, prefix='$') -> list[str]:
    if type(a) is not type(b):
        return [prefix]
    if isinstance(a, dict):
        out=[]
        for k in sorted(set(a) | set(b)):
            if k not in a or k not in b: out.append(f'{prefix}.{k}')
            else: out.extend(changed_paths(a[k], b[k], f'{prefix}.{k}'))
        return out
    if isinstance(a, list):
        out=[]
        if len(a) != len(b): out.append(f'{prefix}.length')
        for i,(x,y) in enumerate(zip(a,b)): out.extend(changed_paths(x,y,f'{prefix}[{i}]'))
        return out
    return [] if a == b else [prefix]


def identity(m: dict) -> dict:
    return m.get('item', {}).get('identity', {})


def method_summary(doc: dict) -> list[dict]:
    rows=[]
    for m in doc.get('methods', []):
        ident=identity(m)
        rep=m.get('outcome', {}).get('report') or {}
        rows.append({
            'identity': ident,
            'index': m.get('item', {}).get('index'),
            'declaration': m.get('declaration'),
            'no_body_kind': m.get('no_body_kind'),
            'outcome_kind': m.get('outcome', {}).get('kind'),
            'quality': rep.get('quality'),
            'fallbacks': rep.get('fallbacks'),
            'source_map': rep.get('source_map'),
            'diagnostics': rep.get('diagnostics'),
            'regions': rep.get('regions'),
            'text': m.get('text'),
        })
    return rows


def old_receipts() -> dict:
    docs={}
    for family,path in OLD_RECEIPTS.items():
        doc=json.loads(path.read_text(encoding='utf-8'))
        if doc.get('status') != 'captured-pending-independent-review':
            raise RuntimeError(f'{family}: unexpected capture status {doc.get("status")}')
        cli=doc.get('cli')
        if not isinstance(cli,dict) or cli.get('sha256') != OLD_CLI_SHA:
            raise RuntimeError(f'{family}: old CLI pin does not match shared accepted baseline')
        if pin(Path(cli['path'])) != {'path': str(Path(cli['path']).resolve()), 'bytes': cli.get('bytes'), 'sha256': cli.get('sha256')}:
            raise RuntimeError(f'{family}: old CLI executable differs from its receipt pin')
        cells=doc.get('jarde_cells')
        if not isinstance(cells,list) or len(cells) != EXPECTED_POSITIVE_COUNTS[family]:
            raise RuntimeError(f'{family}: expected {EXPECTED_POSITIVE_COUNTS[family]} Jarde cells')
        docs[family]=(path,doc)
    return docs


def verify_source_matrix_links(docs: dict, rollup: dict) -> dict:
    """Tie each old captured source text to its archived two-compiler input records."""
    by_family={row['family']:row for row in rollup['rows']}
    provenance={}
    for family,(receipt_path,receipt) in docs.items():
        if family == 'original':
            matrix_path=Path(by_family['original']['execution']['path'])
            matrix=json.loads(matrix_path.read_text(encoding='utf-8'))
            checks=[]
            for cell in receipt['jarde_cells']:
                source_ref=cell.get('whole_source')
                hits=[x for x in matrix['source_inputs'] if x.get('kind')=='jarde'
                      and x.get('profile')==cell.get('profile') and x.get('form')==cell.get('input_form')
                      and x.get('evidence')==cell.get('evidence')]
                if len(hits)!=1: raise RuntimeError('original: missing unique accepted matrix source input')
                row=hits[0]
                if (row['original_report']['bytes'],row['original_report']['sha256'])!=(cell['report']['bytes'],cell['report']['sha256']):
                    raise RuntimeError('original: baseline report is not the source of matrix input')
                if (row['source_copy']['bytes'],row['source_copy']['sha256'])!=(source_ref['bytes'],source_ref['sha256']):
                    raise RuntimeError('original: accepted matrix source copy differs from baseline whole source')
                if pin(Path(row['source_copy']['path'])) != row['source_copy']:
                    raise RuntimeError('original: accepted matrix source-copy file pin mismatch')
                checks.append({'profile':cell.get('profile'),'form':cell.get('input_form'),'evidence':cell.get('evidence'),
                               'source_copy':row['source_copy'],'source_copy_matches_old_text':True})
            provenance[family]={'matrix_receipt':pin(matrix_path),'checks':checks}
        elif family in ('supplement','volatile'):
            matrix_path=Path(by_family[family]['execution']['path'])
            matrix=json.loads(matrix_path.read_text(encoding='utf-8')); checks=[]
            for cell in receipt['jarde_cells']:
                profile=cell.get('profile'); form=cell.get('form'); evidence=cell.get('evidence')
                source_ref=cell.get('whole_source'); source_cell=f'jarde/{profile}/{form}/{evidence}'
                compiles=[x for x in matrix.get('generated_compiles',[]) if x.get('origin')=='jarde' and x.get('source_cell')==source_cell]
                if {x.get('compiler') for x in compiles} != {'javac8','javac23'}:
                    raise RuntimeError(f'{family}: source does not have both original compiler records: {source_cell}')
                for record in compiles:
                    pins=record.get('source_pins_before',[])
                    if not any((x.get('bytes'),x.get('sha256'))==(source_ref['bytes'],source_ref['sha256']) for x in pins):
                        raise RuntimeError(f'{family}: generated compiler source differs from captured API text: {source_cell}')
                checks.append({'source_cell':source_cell,'source':source_ref,'compiler_records':len(compiles)})
            provenance[family]={'matrix_receipt':pin(matrix_path),'checks':checks}
        else:
            checks=[]
            for cell in receipt['jarde_cells']:
                profile=cell.get('profile'); evidence=cell.get('evidence'); source_ref=cell.get('source')
                variant=f'jarde-{profile}-{evidence}'
                variants=[x for x in receipt.get('source_variants',[]) if x.get('variant')==variant]
                compiles=[x for x in receipt.get('compile_cells',[]) if x.get('variant')==variant]
                if len(variants)!=1 or len(compiles)!=2 or {c.get('compiler') for c in compiles}!={'javac8','javac23'}: raise RuntimeError(f'legacy: missing full-source compiler provenance for {variant}')
                sources=variants[0].get('sources',[])
                if not any((x.get('bytes'),x.get('sha256'))==(source_ref['bytes'],source_ref['sha256']) for x in sources):
                    raise RuntimeError(f'legacy: source variant differs from captured API text for {variant}')
                if not all(c.get('exit_code')==0 and any((x.get('bytes'),x.get('sha256'))==(source_ref['bytes'],source_ref['sha256']) for x in c.get('source_pins',[])) for c in compiles):
                    raise RuntimeError(f'legacy: compiler source differs from captured API text for {variant}')
                checks.append({'variant':variant,'source':source_ref,'compile_records':len(compiles)})
            provenance[family]={'receipt':pin(receipt_path),'checks':checks}
    return provenance


def collect_external_paths(docs: dict, rollup: dict) -> dict[str, Path]:
    paths={}
    def add(label, path): paths[label]=path.resolve(strict=True)
    add('semantic_rollup',ROLLUP)
    add('compare',COMPARE)
    add('guard',ROOT/GUARD_REL)
    add('scanner',ROOT/SCANNER_REL)
    add('collector',Path(__file__))
    for row in rollup.get('rows',[]):
        matrix_path=Path(row['execution']['path'])
        add(f'accepted_matrix:{row["family"]}',matrix_path)
        if row['family']=='original':
            matrix=json.loads(matrix_path.read_text(encoding='utf-8'))
            for i,source_row in enumerate(matrix.get('source_inputs',[])):
                if source_row.get('kind')=='jarde' and source_row.get('source_copy'):
                    add(f'accepted_source_copy:original:{i}',Path(source_row['source_copy']['path']))
    for family,(receipt_path,doc) in docs.items():
        add(f'receipt:{family}',receipt_path)
        cli=Path(doc['cli']['path']); add(f'old_cli:{family}',cli)
        command_by_index={row['index']:row for row in doc.get('commands',[])}
        for i,cell in enumerate(doc['jarde_cells']):
            add(f'old_input:{family}:{i}',Path(cell['input']['path']))
            add(f'old_report:{family}:{i}',Path(cell['report']['path']))
            source_ref=cell.get('whole_source') or cell.get('source')
            if source_ref: add(f'old_generated_source:{family}:{i}',Path(source_ref['path']))
            old_command=command_by_index[cell['command']]
            for channel in ('stdout','stderr'):
                add(f'old_raw:{family}:{i}:{channel}',Path(old_command['streams'][channel]['path']))
    for source in (NEG_ROOT/'Probe.java', NEG_ROOT/'ProbeControls.java', NEG_ROOT/'README.md',
                   NEG_ROOT/'patch_controls.py', ROOT/'tests/recover_loop_test_copy_store.rs'):
        add(f'negative_source:{source.name}',source)
    for leg,_ in NEG_LEGS:
        for cls,_declared in NEG_CLASSES:
            add(f'negative_class:{leg}:{cls}',NEG_ROOT/leg/f'{cls}.class')
    return paths


def validate_rollup(path: Path) -> dict:
    doc=json.loads(path.read_text(encoding='utf-8'))
    if doc.get('status') != 'accepted-matrix-rollup' or doc.get('CLI_SHA256') != OLD_CLI_SHA:
        raise RuntimeError('semantic rollup does not bind the accepted old CLI/matrices')
    return doc


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--cli',type=Path,required=True)
    ap.add_argument('--cli-sha256',required=True)
    ap.add_argument('--out',type=Path,default=DEFAULT_OUT)
    args=ap.parse_args()
    root=ROOT.resolve(strict=True); out=args.out.resolve()
    if out.exists(): raise SystemExit(f'refusing existing output directory: {out}')
    if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('repository target must be absent')
    cli=args.cli.resolve(strict=True)
    cli_before=pin(cli)
    if cli_before['sha256'] != args.cli_sha256.lower(): raise SystemExit('new CLI SHA-256 does not match argument')
    if not cli.stat().st_mode & 0o111: raise SystemExit('new CLI is not executable')
    if shutil.disk_usage(root).free < 5*1024**3: raise SystemExit('less than 5 GiB free before replay')

    if pin(COMPARE)['sha256'] != '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6':
        raise SystemExit('pinned comparison helper changed')
    compare=load(COMPARE,'statementful_loop_compare')
    guard_path=root/GUARD_REL; scanner_path=root/SCANNER_REL
    if pin(guard_path)['sha256'] != GUARD_SHA or pin(scanner_path)['sha256'] != SCANNER_SHA:
        raise SystemExit('pinned run guard/scanner changed')
    docs=old_receipts(); rollup=validate_rollup(ROLLUP)
    source_matrix_links=verify_source_matrix_links(docs,rollup)
    external_paths=collect_external_paths(docs,rollup)
    external_before={k:pin(p) for k,p in external_paths.items()}
    for family,(rp,receipt) in docs.items():
        for cell in receipt['jarde_cells']:
            if pin(Path(cell['input']['path'])) != cell['input']: raise SystemExit(f'{family}: input pin mismatch')
            if pin(Path(cell['report']['path'])) != cell['report']: raise SystemExit(f'{family}: old report pin mismatch')
    source_before=compare.source_closure(root)

    out.mkdir(parents=True)
    raw_dir=out/'raw'; raw_dir.mkdir()
    guard=load(guard_path,'statementful_loop_guard'); scanner=load(scanner_path,'statementful_loop_scanner')
    guard.ROOT=root; guard.OUT=raw_dir; guard.target_bytes=lambda:scanner.target_bytes(root)
    guard.command_stream=lambda p:compare.pin(p); guard.expected_test_summaries=lambda index,stdout:None
    env=compare.clean_env(dict(os.environ)); env.pop('RUST_MIN_STACK',None); env.update(guard.ENV_VALUES)
    result={
        'schema':'statementful-loop-header-cli-api-replay-v1','status':'running',
        'root':str(root),'out':str(out),'new_cli':cli_before,'new_cli_sha256_argument':args.cli_sha256.lower(),
        'source_pins_before':source_before,'external_inputs_before':external_before,
        'old_receipts':{family:{'pin':pin(path),'schema':doc.get('schema'),'status':doc.get('status'),
                                'cli':doc.get('cli'),'jarde_cell_count':len(doc['jarde_cells'])}
                        for family,(path,doc) in docs.items()},
        'source_matrix_links':source_matrix_links,
        'semantic_rollup':{'pin':pin(ROLLUP),'status':rollup['status'],'product_candidate':rollup.get('product_candidate'),
                           'cli_sha256':rollup.get('CLI_SHA256'),
                           'accepted_matrix_receipts':{row['family']:{'pin':pin(Path(row['execution']['path'])),
                               'expected_sha256':row['execution']['sha256']} for row in rollup.get('rows',[])}},
        'matrix':{'positive_cli_cells':sum(EXPECTED_POSITIVE_COUNTS.values()),'negative_cli_cells':12,
                  'negative_classes':[{'file_class':c,'declared_class':d} for c,d in NEG_CLASSES],
                  'negative_legs':[{'directory':l,'compiler':tool} for l,tool in NEG_LEGS],
                  'evidence':list(EVIDENCE)},
        'commands':[],'positive_cells':[],'negative_cells':[],
        'notes':['This receipt records actual CLI replay; compiler/runtime evidence is reused only when complete generated Java bytes are identical.','Positive replay changes only argv[0] from each captured old command. It compares the complete parsed JSON recursively after deleting only keys named usage, plus the full top-level source text bytes. Every other difference is recorded.','Old accepted matrix receipts document the already-run dual-JDK generated-source matrices. This API replay does not rerun or claim any compiler/runtime work.','Negative fixture cells store full JSON/source and per-method actual quality/outcome; no outcome is hard-coded.','The root guard enforces 5 GiB free, 1 GiB target, command timeout/termination policy, and records raw stdout/stderr. RUST_MIN_STACK is removed; target must be absent before and after.']}
    write_json(out/'execution.json',result)
    old_docs={}; new_docs={}
    try:
        for family,(receipt_path,receipt) in docs.items():
            by_index={x['index']:x for x in receipt.get('commands',[])}
            for ordinal,cell in enumerate(receipt['jarde_cells']):
                old_cmd=by_index.get(cell.get('command'))
                if old_cmd is None: raise RuntimeError(f'{family}: old command index missing')
                old_argv=old_cmd.get('argv')
                if not old_argv or Path(old_argv[0]).resolve()!=Path(receipt['cli']['path']).resolve():
                    raise RuntimeError(f'{family}: old argv is not bound to receipt CLI')
                if cell.get('exit_code') != 0 or old_cmd.get('exit_code') != 0 or old_cmd.get('guard_stop') is not None:
                    raise RuntimeError(f'{family}: prior positive API cell was not a clean exit-0 capture')
                input_arg=Path(old_argv[old_argv.index('--input')+1]).resolve()
                if input_arg != Path(cell['input']['path']).resolve(): raise RuntimeError(f'{family}: argv input differs from cell')
                expected_all='--evidence' in old_argv and old_argv[old_argv.index('--evidence')+1]=='all'
                if expected_all != (cell.get('evidence')=='all'): raise RuntimeError(f'{family}: evidence argv mismatch')
                old_report=Path(cell['report']['path']); old_doc=json.loads(old_report.read_text(encoding='utf-8'))
                old_source_ref=cell.get('whole_source') or cell.get('source')
                if not old_source_ref or pin(Path(old_source_ref['path'])) != old_source_ref:
                    raise RuntimeError(f'{family}: old generated-source pin missing or changed')
                old_source_bytes=old_doc.get('text','').encode('utf-8')
                if (len(old_source_bytes),sha_bytes(old_source_bytes)) != (old_source_ref['bytes'],old_source_ref['sha256']):
                    raise RuntimeError(f'{family}: old report text differs from its matrix source pin')
                old_stdout=old_cmd['streams']['stdout']
                if (old_stdout.get('bytes'),old_stdout.get('sha256')) != (cell['report'].get('bytes'),cell['report'].get('sha256')):
                    raise RuntimeError(f'{family}: report bytes/hash differ from captured stdout')
                for channel in ('stdout','stderr'):
                    if pin(Path(old_cmd['streams'][channel]['path'])) != old_cmd['streams'][channel]:
                        raise RuntimeError(f'{family}: old {channel} raw pin mismatch')
                old_docs[(family,ordinal)]=old_doc
                argv=[str(cli),*old_argv[1:]]
                if Path(argv[2+1]).resolve() != input_arg: # class-source --input <path>
                    raise RuntimeError(f'{family}: copied input argv changed')
                label=f'positive-{family}-{ordinal:02d}'
                cmd=guard.run_command(len(result['commands'])+1,argv,env)
                cmd.update({'label':label,'phase':'positive-api-replay','source_family':family,'old_cell_index':ordinal})
                result['commands'].append(cmd); write_json(out/'execution.json',result)
                if cmd.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {cmd["guard_stop"]}')
                if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError(f'target appeared during {label}')
                stdout=compare.command_artifact(cmd,'stdout'); stderr=compare.command_artifact(cmd,'stderr')
                for channel,data in (('stdout',stdout),('stderr',stderr)):
                    p=raw_dir/f'{cmd["index"]:02d}-{label}.{channel}.raw'; p.write_bytes(data); cmd[f'{channel}_raw']=pin(p)
                parsed=json.loads(stdout.decode('utf-8'))
                if not isinstance(parsed,dict) or not isinstance(parsed.get('methods'),list): raise RuntimeError(f'{label}: malformed class-source JSON')
                new_docs[(family,ordinal)]=parsed
                jp=out/'json'/'positive'/family/f'{ordinal:02d}.json'; write_json(jp,parsed)
                text=parsed.get('text'); text_pin=None
                if isinstance(text,str):
                    tp=out/'source'/'positive'/family/f'{ordinal:02d}.java.txt'; tp.parent.mkdir(parents=True,exist_ok=True); tp.write_bytes(text.encode('utf-8')); text_pin=pin(tp)
                stripped_old=remove_usage(old_doc); stripped_new=remove_usage(parsed)
                deltas=changed_paths(stripped_old,stripped_new)
                source_equal=isinstance(text,str) and text.encode('utf-8') == old_doc.get('text','').encode('utf-8')
                row={'family':family,'cell_ordinal':ordinal,'old_command_index':cell['command'],'new_command_index':cmd['index'],
                     'old_input':cell['input'],'old_report':cell['report'],'old_generated_source':old_source_ref,
                     'argv':argv,'exit_code':cmd.get('exit_code'),
                     'exit_classification':'success' if cmd.get('exit_code')==0 else ('exit-4-capturable' if cmd.get('exit_code')==4 else 'other-exit-captured'),
                     'stdout_raw':cmd['stdout_raw'],'stderr_raw':cmd['stderr_raw'],'json_artifact':pin(jp),'full_source_artifact':text_pin,
                     'old_full_source_sha256':sha_bytes(old_doc.get('text','').encode('utf-8')),
                     'new_full_source_sha256':sha_bytes(text.encode('utf-8')) if isinstance(text,str) else None,
                     'full_source_equal':source_equal,'nonusage_json_equal':not deltas,'nonusage_changed_paths':deltas,
                     'old_method_count':len(old_doc.get('methods',[])),'new_method_count':len(parsed.get('methods',[])),
                     'old_methods':method_summary(old_doc),'new_methods':method_summary(parsed)}
                result['positive_cells'].append(row); write_json(out/'execution.json',result)

        fixture_pins={}
        for leg,_tool in NEG_LEGS:
            for file_cls,_decl in NEG_CLASSES:
                path=NEG_ROOT/leg/f'{file_cls}.class'; fixture_pins[f'{leg}/{file_cls}']=pin(path)
                binary=_decl
                for evidence in EVIDENCE:
                    argv=[str(cli),'class-source','--input',str(path),'--class',binary,'--policy','single-class','--release','8','--format','json']
                    if evidence=='all': argv.extend(['--evidence','all'])
                    label=f'negative-{leg}-{file_cls}-{evidence}'
                    cmd=guard.run_command(len(result['commands'])+1,argv,env)
                    cmd.update({'label':label,'phase':'negative-copy-api-snapshot','input_leg':leg,'file_class':file_cls,'declared_class':binary,'evidence':evidence})
                    result['commands'].append(cmd); write_json(out/'execution.json',result)
                    if cmd.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {cmd["guard_stop"]}')
                    if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError(f'target appeared during {label}')
                    stdout=compare.command_artifact(cmd,'stdout'); stderr=compare.command_artifact(cmd,'stderr')
                    for channel,data in (('stdout',stdout),('stderr',stderr)):
                        p=raw_dir/f'{cmd["index"]:02d}-{label}.{channel}.raw'; p.write_bytes(data); cmd[f'{channel}_raw']=pin(p)
                    parsed=json.loads(stdout.decode('utf-8'))
                    if not isinstance(parsed,dict) or not isinstance(parsed.get('methods'),list): raise RuntimeError(f'{label}: malformed JSON')
                    jp=out/'json'/'negative'/leg/file_cls/f'{evidence}.json'; write_json(jp,parsed)
                    text=parsed.get('text'); tp=None
                    if isinstance(text,str):
                        tp=out/'source'/'negative'/leg/file_cls/f'{evidence}.java.txt'; tp.parent.mkdir(parents=True,exist_ok=True); tp.write_bytes(text.encode('utf-8'))
                    result['negative_cells'].append({'input_leg':leg,'compiler':_tool,'file_class':file_cls,'declared_class':binary,'evidence':evidence,
                        'input_class':pin(path),'argv':argv,'command_index':cmd['index'],'exit_code':cmd.get('exit_code'),
                        'exit_classification':'success' if cmd.get('exit_code')==0 else ('exit-4-capturable' if cmd.get('exit_code')==4 else 'other-exit-captured'),
                        'stdout_raw':cmd['stdout_raw'],'stderr_raw':cmd['stderr_raw'],'json_artifact':pin(jp),
                        'full_source_artifact':pin(tp) if tp else None,'top_outcome':parsed.get('outcome'),
                        'methods':method_summary(parsed)})
                    write_json(out/'execution.json',result)
        result['negative_fixture_pins_before']=fixture_pins
        result['status']='captured-pending-independent-review'
    except Exception as exc:
        result['status']='interrupted'; result['failure']=f'{type(exc).__name__}: {exc}'
        raise
    finally:
        result['source_pins_after']=compare.source_closure(root)
        result['source_unchanged']=result['source_pins_after']==result['source_pins_before']
        result['external_inputs_after']={k:pin(p) for k,p in external_paths.items()}
        result['external_inputs_unchanged']=result['external_inputs_after']==result['external_inputs_before']
        result['new_cli_after']=pin(cli)
        result['new_cli_unchanged']=result['new_cli_after']==result['new_cli']
        result['target_absent_after']=not (root/'target').exists() and not (root/'target').is_symlink()
        result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        if result['status']=='captured-pending-independent-review' and not all((result['source_unchanged'],result['external_inputs_unchanged'],result['new_cli_unchanged'],result['target_absent_after'])):
            result['status']='interrupted'; result['failure']='source/input/CLI changed or target was not absent after replay'
        write_json(out/'execution.json',result)
    print(json.dumps({'status':result['status'],'positive_cells':len(result['positive_cells']),
                      'negative_cells':len(result['negative_cells']),'commands':len(result['commands']),
                      'out':str(out)},ensure_ascii=False))
    return 0

if __name__=='__main__': raise SystemExit(main())
