# Statementful-loop `dup` admission: bounded static review

Scope: read-only review of the current candidate’s new header-copy gate in `Walker::statementful_loop_header`, its use of `build::local_assignment_at`, and the existing parameter-slot rules. No shared files were changed and no toolchain was run.

## Source pins and locations reviewed

- `crates/jarde-java/src/region.rs`, SHA-256 `9e27c9bee263a9fa2d09c1860e6cfcb45605b16b92e524c92009d156f18b59ea`; `statementful_loop_header` begins at line 17056. The new duplicate gate is at lines 17212–17319; final ownership claim remains at the helper’s end after the edge census.
- `crates/jarde-java/src/build.rs`, SHA-256 `e3f201df7bd01b9b0691d5f7229cbfd5efd82ce5b70fdd39f0f003170fe51b39`; `local_assignment_at` is at lines 8122–8219 and `single_use_at` at 17156–17162.
- `crates/jarde-java/src/region/statementful_loop_header_tests.rs`, SHA-256 `b22fb1382f46ded80bb15a902c4781a0fc1b284977517373a65a682e4b3e55ac`; it exercises exact-cost/limit stop with unchanged `visited` and the original/supplement loop proof.
- `crates/jarde-java/src/build/tests/field_test_copy_tests.rs`, SHA-256 `363281ef29477ea0367926d94eab441b154d0c5d9a4ffded949d1014cb62d4d0`; it records the separate `dup_x1` field-copy proof and controls.

## Adversarial review

No concrete defect found in the reviewed gate.

The new path only examines SSA instructions classified as `Operation::Duplicate`, and requires opcode `0x59`. It first requires the existing region admission (`unobservable_store_dance_part` or `store_dance_part`), which preserves the parameter-target rejection, then requires `local_assignment_at` to prove the same-block source → `dup; store` → direct terminal comparison form. That builder proof pins both copied values to the actual `dup`, checks definitions/replacements, and requires single uses for the source, stored copy, and tested copy. Thus an extra consumer cannot be accepted merely because `store_dance_part` sees matching identities. Requiring both gates also prevents the builder proof alone from admitting a parameter slot.

The `?` propagation on each `poll`/`charge` keeps cancellation/deadline/budget stops as `StopReason`; refusal paths return `None`. The helper does not mutate `visited` during the duplicate checks or graph proof. It performs the last poll before one `visited.extend(owner_nodes)`, so a stop in the reviewed path cannot publish a partial claim. The canonical edge loop polls and charges each edge. In the new copy section, the cost estimate accounts for the header-position scans, slot-entry scan, store/test/copy operand vectors, `local_assignment_at`’s bounded header scans, and its effects scan; `single_use_at` only pattern-matches the use slice length/sole element rather than walking all uses. No uncharged unbounded scan was apparent in this section.

The gate deliberately does not blanket-reject `Store` or `Operation::Other`; that preserves effectful statement prefixes and the separately proved `dup_x1`/field-copy family. No additional local failure was visible in those boundaries from static inspection. This is an architecture review only; it does not establish matrix/API success beyond the root-provided evidence that the parameter and `MultiCopy` controls now refuse and the Seq1 proof’s full/cost-limited API observations match.

## Evidence boundary

This review is limited to the current local gate and the cited existing proof seams. It does not claim all `Operation::Other` values are safe, nor does it expand the supported header grammar. Any later observed unrenderable non-`dup` header instruction should be handled from its own concrete input and Builder failure, not by broadening this `dup` gate preemptively.
