Independent read-only adversarial review of the step-10 aggregate-log binding.

Run with `python3 -B review.py`. It reads the saved official ZIP/API/workflow evidence and tests the helper’s positive path plus adversarial mutations; it does not request network access or invoke the full CI verifier.

The evidence binding passed under the recorded normal `python3 -B` invocation. The helper currently relies on Python `assert` for validation. The optimized-mode probe demonstrated that `python -O` disables those checks and returns a body with a tampered target name. The product run used `python3 -B`, so this does not invalidate that captured run; the helper should still reject optimized interpreter mode or use explicit validation before reuse.

The report preserves the initial v1 rejection receipt and records the original/refetched ZIP digest, helper/verifier/diff pins, and all negative-control outcomes.
