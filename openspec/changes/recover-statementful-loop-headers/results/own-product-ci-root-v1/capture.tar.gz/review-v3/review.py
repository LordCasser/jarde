#!/usr/bin/env python3
from __future__ import annotations
import copy, datetime as dt, hashlib, importlib.util, json, re, sys, zipfile
from pathlib import Path

sys.dont_write_bytecode = True
EVIDENCE = Path('/private/tmp/jarde-statementful-loop-own-product-ci-root-v1-20261018')
PREP = Path('/private/tmp/jarde-statementful-loop-own-ci-review-root-v3-20261018')
HELPER_PATH = PREP / 'missing_step_proof.py'
VERIFIER_PATH = PREP / 'verify-own-ci.py'
DIFF_PATH = Path('/private/tmp/jarde-statementful-loop-own-ci-review-root-v2-20261018/checker.diff')
FAILURE_PATH = Path('/private/tmp/jarde-statementful-loop-own-ci-review-root-v2-20261018/initial-review-failure.json')
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
JOB = 'stable / test and specification'
STEP_NAME = 'Run ignored JDK 25 instruction-boundary oracle'
TARGET = 'jdk25_instruction_boundaries_match_public_bytecode_inspection'
COMMAND = 'cargo test --test jvm_bytecode_oracle --locked -- --ignored --exact ' + TARGET
EXPECTED_ZIP_SHA = '5a78adc42db1736c87eff918da8826ecc422d1f456cdeae64ad173734fc234ca'

class OverlayArchive:
    def __init__(self, base, aggregate_name, transform):
        self.base, self.aggregate_name, self.transform = base, aggregate_name, transform
    def read(self, name):
        raw = self.base.read(name)
        return self.transform(raw) if name == self.aggregate_name else raw

def sha(b): return hashlib.sha256(b).hexdigest()
def need(ok,msg):
    if not ok: raise AssertionError(msg)
def expect_reject(name, fn):
    try: fn()
    except (AssertionError, ValueError, KeyError, IndexError) as exc:
        if str(exc).startswith('negative test setup:'):
            raise
        return {'case':name,'rejected':True,'exception':type(exc).__name__,'message':str(exc)[:240]}
    raise AssertionError(f'negative control unexpectedly accepted: {name}')
def load_helper():
    spec=importlib.util.spec_from_file_location('missing_step_proof_reviewed', HELPER_PATH)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

def main():
    helper=load_helper()
    supplement=json.loads((EVIDENCE/'step-log-supplement.json').read_text())
    failure=json.loads(FAILURE_PATH.read_text())
    api=json.loads((EVIDENCE/'jobs-api.json').read_text())
    workflow=(ROOT/'.github/workflows/ci.yml').read_text()
    job=next(row for row in api['jobs'] if row['name']==JOB)
    steps=job['steps']; step=next(row for row in steps if row.get('number')==10)
    previous=steps[steps.index(step)-1]; following=steps[steps.index(step)+1]
    zip_path=EVIDENCE/'run-logs.zip'; archive_bytes=zip_path.read_bytes(); zip_sha=sha(archive_bytes)
    need(supplement['argv']==['gh','api',f"repos/LordCasser/jarde/actions/runs/{api['run_id']}/logs"] if 'run_id' in api else True, 'supplement argv malformed')
    # The collected run id is authoritative in collection.json, not inferred from the API response.
    collection=json.loads((EVIDENCE/'collection.json').read_text())
    expected_argv=['gh','api',f"repos/LordCasser/jarde/actions/runs/{collection['run_id']}/logs"]
    need(supplement['argv']==expected_argv and supplement['exit_code']==0,'archive refetch argv/result differs')
    pin=supplement['streams']['stdout']
    need(Path(pin['path'])==zip_path and pin['bytes']==len(archive_bytes) and pin['sha256']==zip_sha==EXPECTED_ZIP_SHA,'refetched official ZIP bytes/hash differ')
    need(failure['observed_exit_code']==1 and failure['error'].endswith('stable _ test and specification/10_Run ignored JDK 25 instruction-boundary oracle.txt'),'historical initial rejection is missing or changed')
    need(failure['first_official_zip_sha256']==zip_sha,'refetched ZIP does not match the initially captured archive hash')
    with zipfile.ZipFile(zip_path) as z:
        names=z.namelist()
        need(len(names)==len(set(names)),'official archive has duplicate member names')
        aggregate_name='0_'+JOB.replace('/','_')+'.txt'
        folder=JOB.replace('/','_')+'/'
        member=lambda s: folder+str(s['number'])+'_'+s['name'].replace('/','_')+'.txt'
        prev_name,next_name=member(previous),member(following)
        need(aggregate_name in names and prev_name in names and next_name in names,'aggregate or one of adjacent API step members is missing')
        need(member(step) not in names,'step10 per-step member unexpectedly exists in official ZIP')
        need([previous['number'],step['number'],following['number']]==[9,10,11],'API neighbors do not bind step10 between 9 and 11')
        raw,proof=helper.derive(z,api,workflow,JOB,step)
        aggregate_raw=z.read(aggregate_name); before_raw=z.read(prev_name); after_raw=z.read(next_name)
        need(proof['raw_sha256']==sha(raw) and proof['aggregate_sha256']==sha(aggregate_raw),'helper proof hashes do not match original archive bytes')
        need(proof['previous_sha256']==sha(before_raw) and proof['following_sha256']==sha(after_raw),'helper adjacent-member pins do not match original bytes')
        need(proof['command']==COMMAND and proof['exact_test']==TARGET and (proof['passed'],proof['failed'],proof['ignored'],proof['filtered'])==(1,0,0,0),'proof reports wrong command/test/outcome')
        text=raw.decode('utf-8')
        plain=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text)
        need('##[group]Run '+COMMAND in plain and COMMAND in plain and 'Running tests/jvm_bytecode_oracle.rs (target/debug/deps/jvm_bytecode_oracle-' in plain,'isolated body lacks command or executable identity')
        need('test '+TARGET+' ... ok' in plain and 'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in plain,'isolated body lacks the exact passing ignored-test evidence')
        need(proof['aggregate_line_slice_zero_based'][0] < proof['aggregate_line_slice_zero_based'][1],'isolated aggregate boundaries are reversed')
        # Adversarial controls. All inputs use the original immutable archive except the one explicit aggregate overlay.
        negatives=[]
        bad_step=copy.deepcopy(previous)
        negatives.append(expect_reject('wrong API step number/name',lambda: helper.derive(z,api,workflow,JOB,bad_step)))
        bad_display=JOB+' (renamed)'
        negatives.append(expect_reject('wrong API job display',lambda: helper.derive(z,api,workflow,bad_display,step)))
        workflow_changed=workflow.replace(TARGET,'altered_target',1)
        negatives.append(expect_reject('changed workflow command',lambda: helper.derive(z,api,workflow_changed,JOB,step)))
        bad_prev_api=copy.deepcopy(api)
        bad_job=next(row for row in bad_prev_api['jobs'] if row['name']==JOB)
        bad_job['steps'][8]['number']=8
        bad_api_step=bad_job['steps'][9]
        negatives.append(expect_reject('wrong preceding API boundary',lambda: helper.derive(z,bad_prev_api,workflow,JOB,bad_api_step)))
        bad_next_api=copy.deepcopy(api)
        bad_job=next(row for row in bad_next_api['jobs'] if row['name']==JOB)
        bad_job['steps'][10]['number']=12
        bad_api_step=bad_job['steps'][9]
        negatives.append(expect_reject('wrong following API boundary',lambda: helper.derive(z,bad_next_api,workflow,JOB,bad_api_step)))
        bad_time_api=copy.deepcopy(api)
        bad_time_job=next(row for row in bad_time_api['jobs'] if row['name']==JOB)
        changed_time=bad_time_job['steps'][9]
        step9=bad_time_job['steps'][8]
        changed_time['started_at']=step9['started_at']; changed_time['completed_at']=step9['completed_at']
        negatives.append(expect_reject('API timestamps taken from adjacent prior step',lambda: helper.derive(z,bad_time_api,workflow,JOB,changed_time)))
        later_step=next(s for s in steps if s['number']==12)
        negatives.append(expect_reject('different API step identity',lambda: helper.derive(z,api,workflow,JOB,later_step)))
        def mutate(old,new):
            def apply(b):
                need(b.count(old)==1,'negative test setup: mutation anchor not unique')
                return b.replace(old,new,1)
            return apply
        command_body_line=next(line for line in raw.splitlines(keepends=True) if b'##[group]Run '+COMMAND.encode() in line)
        changed_command_line=command_body_line.replace(COMMAND.encode(),COMMAND.replace(TARGET,'altered_target').encode(),1)
        negatives.append(expect_reject('changed command in aggregate body',lambda: helper.derive(OverlayArchive(z,aggregate_name,mutate(command_body_line,changed_command_line)),api,workflow,JOB,step)))
        test_line=('test '+TARGET+' ... ok').encode()
        negatives.append(expect_reject('changed test name in aggregate body',lambda: helper.derive(OverlayArchive(z,aggregate_name,mutate(test_line,b'test another_target ... ok')),api,workflow,JOB,step)))
        summary_line=next(line for line in raw.splitlines(keepends=True) if b'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in line)
        changed_summary_line=summary_line.replace(b'1 passed',b'2 passed',1)
        negatives.append(expect_reject('changed aggregate summary counts',lambda: helper.derive(OverlayArchive(z,aggregate_name,mutate(summary_line,changed_summary_line)),api,workflow,JOB,step)))
        negatives.append(expect_reject('duplicate previous adjacent payload',lambda: helper.derive(OverlayArchive(z,aggregate_name,lambda b:b+b'\n'+before_raw),api,workflow,JOB,step)))
        negatives.append(expect_reject('duplicate following adjacent payload',lambda: helper.derive(OverlayArchive(z,aggregate_name,lambda b:b+b'\n'+after_raw),api,workflow,JOB,step)))
        # Also make the required target line non-unique without modifying the adjacent anchors.
        def duplicate_test_inside_body(b):
            rows=b.splitlines(keepends=True)
            matches=[i for i,line in enumerate(rows) if b'test '+TARGET.encode()+b' ... ok' in line]
            need(len(matches)==1,'negative test setup: target test line is not unique in aggregate')
            rows.insert(matches[0],rows[matches[0]])
            return b''.join(rows)
        negatives.append(expect_reject('duplicated exact target outcome inside isolated body',lambda: helper.derive(OverlayArchive(z,aggregate_name,duplicate_test_inside_body),api,workflow,JOB,step)))
        need(len(negatives)==13 and all(row['rejected'] for row in negatives),'one or more adversarial controls did not reject')
        # Check all body timestamps independently fall inside the exact API step interval (with the helper's documented 1s tolerance).
        stamps=[]
        stamp_re=re.compile(rb'^(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z) ?')
        for line in raw.splitlines():
            m=stamp_re.match(line); need(m is not None,'derived body contains an unprefixed log line')
            stamps.append(dt.datetime.fromisoformat(m.group(1).decode().replace('Z','+00:00')))
        start=dt.datetime.fromisoformat(step['started_at'].replace('Z','+00:00'))
        end=dt.datetime.fromisoformat(step['completed_at'].replace('Z','+00:00'))
        need(all(start-dt.timedelta(seconds=1)<=t<=end+dt.timedelta(seconds=1) for t in stamps),'derived body time outside API interval')
        # Probe optimized mode to prove validation remains active when Python assertions are disabled.
        import subprocess, textwrap
        optimize_program = textwrap.dedent(f'''
            import sys, zipfile, json, importlib.util
            from pathlib import Path
            sys.dont_write_bytecode=True
            hp=Path({str(HELPER_PATH)!r})
            spec=importlib.util.spec_from_file_location('step10_opt_probe',hp)
            m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
            class Overlay:
                def __init__(self,z,n): self.z=z;self.n=n
                def read(self,name):
                    b=self.z.read(name)
                    if name==self.n:
                        old={('test '+TARGET+' ... ok').encode()!r}
                        new={('test '+TARGET[:-1]+'X ... ok').encode()!r}
                        assert b.count(old)==1
                        b=b.replace(old,new,1)
                    return b
            ev=Path({str(EVIDENCE)!r}); ar=ev/'run-logs.zip'
            api=json.loads((ev/'jobs-api.json').read_text());job=next(j for j in api['jobs'] if j['name']=={JOB!r})
            step=next(s for s in job['steps'] if s.get('number')==10)
            wf=Path({str(ROOT/'.github/workflows/ci.yml')!r}).read_text()
            with zipfile.ZipFile(ar) as z:
                raw,proof=m.derive(Overlay(z,'0_'+{JOB.replace('/','_')!r}+'.txt'),api,wf,{JOB!r},step)
                print('returned='+str(len(raw))+'; altered_target='+str(({('test '+TARGET[:-1]+'X ... ok').encode()!r} in raw)))
        ''')
        optimized=subprocess.run([sys.executable,'-O','-B','-c',optimize_program],capture_output=True,text=True)
        optimized_probe={'exit_code':optimized.returncode,'stdout':optimized.stdout.strip(),'stderr':optimized.stderr.strip()}
        optimized_probe['tampered_target_rejected_under_optimized_mode']=(optimized.returncode!=0 and 'altered_target=True' not in optimized.stdout)
        need(optimized_probe['tampered_target_rejected_under_optimized_mode'],'python -O accepted a tampered target outcome')
        report={
          'schema':'statementful-loop-own-ci-step10-independent-review-v2','status':'accepted',
          'source_evidence':{
            'execution_dir':str(EVIDENCE),'initial_review_failure':str(FAILURE_PATH),'initial_review_failure_sha256':sha(FAILURE_PATH.read_bytes()),
            'initial_failure_preserved':True,'initial_failure_exit_code':failure['observed_exit_code'],
            'first_and_refetched_archive_sha256_equal':True,'archive_sha256':zip_sha,'archive_bytes':len(archive_bytes),
            'archive_member_count':len(names),'archive_member_names_unique':True,'api_step_count':len(job['steps']),
            'step10_per_step_member_absent':True,'previous_member':prev_name,'following_member':next_name,
            'step10_api':step,'neighbor_api_steps':[previous,following],
            'workflow_sha256':sha(workflow.encode()),'jobs_api_sha256':sha((EVIDENCE/'jobs-api.json').read_bytes()),
            'helper_sha256':sha(HELPER_PATH.read_bytes()),'verifier_sha256':sha(VERIFIER_PATH.read_bytes()),'checker_diff_sha256':sha(DIFF_PATH.read_bytes()),
            'supplement_sha256':sha((EVIDENCE/'step-log-supplement.json').read_bytes())},
          'integration_review':{'diff_path':str(DIFF_PATH),'derive_invoked_only_for_missing_per_step_member':True,'outer_verifier_pins_official_zip_and_checks_full_api_step_sequence':True,'proof_rows_are_appended_per_official_step_log_read':True},
          'positive':{'passed':True,'proof':proof,'derived_body_bytes':len(raw),'derived_body_sha256':sha(raw),
            'body_has_exact_command_test_summary_and_target_executable':True,'timestamps_inside_api_step_interval':True,
            'body_timestamp_count':len(stamps)},
          'negative_controls':negatives,'optimized_mode_probe':optimized_probe,
          'scope_and_limitations':['This validates the helper under normal and optimized Python against the captured official ZIP and API JSON; it does not make a network request or rerun the full CI verifier. The successful result depends on the caller also validating the complete workflow/API step sequence and official archive stream pin, as verify-own-ci.py does.']}
    out=Path('/private/tmp/jarde-statementful-loop-own-ci-review-root-v3-20261018')
    out.mkdir(parents=True,exist_ok=True)
    (out/'root-independent-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':'accepted','positive':'passed','negative_controls_rejected':len(negatives),'archive_sha256':zip_sha,'body_sha256':sha(raw),'report':str(out/'root-independent-review.json')},ensure_ascii=False))
if __name__=='__main__': main()
