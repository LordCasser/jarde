import hashlib, json, re, subprocess, sys
from pathlib import Path
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
run=Path(sys.argv[1]); out=Path(sys.argv[2]); assert not out.exists()
def pin(p):
    p=Path(p); data=p.read_bytes()
    return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
d=json.loads((run/'execution.json').read_bytes())
assert d['status']=='commands_passed_pending_independent_acceptance'
assert d['default_stack'] and d['source_changes_accepted'] and d['target_absent'] and not (ROOT/'target').exists()
assert d['source_changes']==['tests/fixtures/corpus-fingerprint.json']
for item in d['source_after']: assert pin(item['path'])==item
summaries=[]; names=[]
for c in d['commands']:
    assert c['exit_code']==0 and c.get('guard_stop') is None
    assert c.get('peak_target_bytes',0)<=1024**3 and c.get('free_bytes_after',5*1024**3)>=5*1024**3
    assert 'RUST_MIN_STACK' not in c.get('env_overrides',{})
    for stream in c['streams'].values(): assert pin(stream['path'])==stream
    text=Path(c['streams']['stdout']['path']).read_text()
    rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    passed=re.findall(r'^test (\S+)(?: - should panic)? \.\.\. ok$',text,re.M)
    if rows:
        assert len(rows)==1 and int(rows[0][1])==0 and len(passed)==int(rows[0][0])
        summaries.append({'index':c['index'],'argv':c['argv'],'counts':list(map(int,rows[0]))})
        names.extend(passed)
assert d['commands'][-1]['argv']==['cargo','clean']
critical=[n for n in names if 'statementful_loop_header_tests::' in n or 'field_test_copy_tests::' in n]
assert len(critical)>=10
for name in critical: assert names.count(name)==1
assert d['cli']['sha256']=='0bb89f827c1e2b6b0e215d1940299be046a7adc57866389d87e6595ba0295677'
assert pin(d['cli']['path'])==d['cli']
old=json.loads(subprocess.check_output(['git','show','2de80b6a0777d773bc40502005a21ab307bc1b0c:tests/fixtures/corpus-fingerprint.json'],cwd=ROOT))
new=json.loads((ROOT/'tests/fixtures/corpus-fingerprint.json').read_bytes())
a={x['path']:x for x in old['files']}; b={x['path']:x for x in new['files']}
assert len(a)==2387 and all(b.get(p)==v for p,v in a.items())
assert all(old[k]==new[k] for k in old if k!='files')
added=sorted(b.keys()-a.keys())
assert all(p.startswith(('tests/fixtures/recover-statementful-loop-headers/','tests/fixtures/recover-field-write-test-copies/')) for p in added)
result={'status':'accepted','execution':pin(run/'execution.json'),'cli':d['cli'],'summaries':summaries,
        'passing_appearances':sum(row['counts'][0] for row in summaries),'ignored_appearances':sum(row['counts'][2] for row in summaries),
        'critical_library_tests':critical,'fingerprint':{'old_entries_unchanged':2387,'total_entries':len(b),'additions':added,'metadata_unchanged':True},
        'source_count':len(d['source_after']),'default_stack':True,'target_absent':True,
        'scope':'Guarded fmt/CI Clippy/MSRV1.88/Reader/Java/public/fingerprint/P5 commands checked from actual argv and raw summaries. CLI is byte-identical to the full Java matrices. No whole-workspace seed or CI acceptance claimed here.'}
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'accepted','passed':result['passing_appearances'],'ignored':result['ignored_appearances'],'fingerprint':len(b),'review':str(out)}))
