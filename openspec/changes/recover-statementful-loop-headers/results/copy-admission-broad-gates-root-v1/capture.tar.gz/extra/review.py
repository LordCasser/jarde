#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, re, sys
from pathlib import Path

EXECUTION = Path('/private/tmp/jarde-statementful-loop-copy-broad-gates-root-v1-20261018/execution.json')
OUT = Path('/private/tmp/jarde-statementful-loop-copy-broad-gates-independent-review-luna-v1-20261018')
EXPECTED_CLI_SHA = 'aabf62fe373876d176e6001bf3ed1fd84f80d2169ff5e787c4095c5d253c63d9'
EXPECTED_COMMANDS = [
    ['cargo','fmt','--all','--','--check'],
    ['cargo','clippy','--workspace','--all-targets','--all-features','--locked'],
    ['/Users/lordcasser/.cargo/bin/cargo','+1.88.0','check','--workspace','--all-targets','--all-features','--locked'],
    ['cargo','test','-p','jarde-java','--lib','--locked'],
    ['cargo','test','-p','jarde-reader','--lib','--locked'],
    ['cargo','test','-p','jarde','--test','recover_loop_test_copy_store','--locked'],
    ['cargo','test','-p','jarde','--test','p3_for_latch','--locked'],
    ['cargo','test','-p','jarde-java','--test','p3_statementful_loop_headers','--locked'],
    ['cargo','test','-p','jarde','--test','p5_corpus_fingerprint','--locked'],
    ['cargo','test','--test','p5_benchmark','--all-features','--locked'],
    ['cargo','test','--test','p5_bulk_corpus','--all-features','--locked'],
    ['cargo','test','--test','p5_container_lookup','--all-features','--locked'],
    ['cargo','test','--test','p5_definition_read_reuse','--all-features','--locked'],
    ['cargo','test','--test','p5_facts_cache','--all-features','--locked'],
    ['cargo','test','--test','p5_optimize_workloads','--all-features','--locked'],
    ['cargo','test','--test','p5_shared_payload','--all-features','--locked'],
    ['cargo','build','-p','jarde-cli','--bin','jarde-cli','--locked'],
    ['cargo','clean'],
]
SUMMARY = re.compile(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;')
RUNNING = re.compile(r'^running (\d+) tests?$')
TESTLINE = re.compile(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?:,.*)?$')

def sha(b: bytes) -> str: return hashlib.sha256(b).hexdigest()
def need(ok: bool, msg: str):
    if not ok: raise ValueError(msg)
def parse_summary(text: str):
    runs=[]; test_names=[]; summary_lines=[]
    for line in text.splitlines():
        m=RUNNING.fullmatch(line)
        if m: runs.append(int(m.group(1)))
        m=SUMMARY.match(line)
        if m: summary_lines.append(tuple(map(int,m.groups())))
        m=TESTLINE.match(line)
        if m: test_names.append((m.group(1),m.group(2)))
    need(len(summary_lines)==1, f'expected exactly one Rust test summary, found {len(summary_lines)}')
    p,f,i,m,filtered=summary_lines[0]
    need(len(runs)==1, f'expected one test harness start, found {len(runs)}')
    need(runs[0] == p+f+i+m+filtered, 'harness count differs from outcomes in summary')
    need(len(test_names)==runs[0], f'parsed named test outcomes {len(test_names)} != running count {runs[0]}')
    need(f==0 and filtered==0, f'failures/filtered tests in output: {summary_lines[0]}')
    need(not any(state=='FAILED' for _,state in test_names), 'named failure in output')
    return {'running':runs[0], 'passed':p,'failed':f,'ignored':i,'measured':m,'filtered':filtered,
            'named_outcomes':len(test_names),'test_names':[name for name,_ in test_names],
            'ignored_names':[name for name,state in test_names if state=='ignored']}

def verify():
    x=json.loads(EXECUTION.read_text())
    need(x.get('status')=='commands_passed_pending_independent_acceptance', 'receipt status changed')
    need(len(x.get('commands',[]))==18, 'expected exactly 18 commands')
    need(x.get('default_stack') is True, 'default Rust stack was not recorded')
    need(x.get('target_absent') is True, 'target directory absence was not recorded')
    need(x.get('source_unchanged') is True and x.get('source_changes_accepted') is True, 'source-unchanged flags are not true')
    need(x.get('source_changes')==[] and x.get('allowed_source_changes')==[], 'receipt records source changes')
    before=x.get('source_before'); after=x.get('source_after')
    need(isinstance(before,list) and isinstance(after,list) and before==after, 'source_before/source_after byte inventories differ')
    paths=[r.get('path') for r in before]
    need(len(paths)==len(set(paths)) and paths==sorted(paths), 'source inventory is not unique and sorted')
    for row in before:
        need(isinstance(row.get('bytes'),int) and row['bytes']>=0 and re.fullmatch(r'[0-9a-f]{64}',row.get('sha256','')) is not None, 'malformed source byte pin')
    # Cross-check the still-present current source closure as a separate contemporaneous check.
    current={'checked':0,'matching':0,'missing':[],'changed':[]}
    for row in before:
        p=Path(row['path'])
        if not p.is_file(): current['missing'].append(row['path']); continue
        b=p.read_bytes(); current['checked']+=1
        if len(b)==row['bytes'] and sha(b)==row['sha256']: current['matching']+=1
        else: current['changed'].append({'path':row['path'],'expected_bytes':row['bytes'],'actual_bytes':len(b),'expected_sha256':row['sha256'],'actual_sha256':sha(b)})
    commands=x['commands']; summaries=[]; raw_pins=[]; cleanup_index=None
    for idx,(c,expected) in enumerate(zip(commands,EXPECTED_COMMANDS),1):
        need(c.get('index')==idx, f'command index mismatch at {idx}')
        argv=c.get('argv'); need(isinstance(argv,list) and argv, f'missing argv at command {idx}')
        if idx==2:
            need(argv[:6]==expected, 'clippy command prefix differs')
            need(argv[-2:]==['-D','warnings'], 'clippy warning policy differs')
            need(all(a=='--' or a.startswith('-A') or a.startswith('clippy::') or a=='-D' or a=='warnings' for a in argv[6:]),'unexpected clippy argument')
        else:
            need(argv==expected, f'argv differs at command {idx}: {argv!r}')
        need(c.get('exit_code')==0, f'command {idx} exit code is not zero')
        if 'guard_stop' in c: need(c['guard_stop'] is None, f'command {idx} was stopped by guard')
        if idx<18:
            need(c.get('peak_target_bytes',0)<=1024**3, f'command {idx} exceeded 1 GiB target limit')
            need(c.get('free_bytes_after',0)>=5*1024**3, f'command {idx} violates 5 GiB free-space guard')
            need(c.get('env_overrides',{}).get('CARGO_BUILD_JOBS')=='1', f'command {idx} did not serialize Cargo jobs')
        else:
            cleanup_index=idx
        streams=c.get('streams'); need(set(streams)=={'stdout','stderr'}, f'command {idx} does not retain both streams')
        for stream,meta in streams.items():
            raw=Path(meta['path']).resolve(strict=True)
            expected_dir=(EXECUTION.parent/'raw').resolve(strict=True)
            need(raw.parent==expected_dir, f'command {idx} {stream} escaped its raw directory')
            b=raw.read_bytes()
            need(len(b)==meta['bytes'] and sha(b)==meta['sha256'], f'command {idx} {stream} raw pin mismatch')
            raw_pins.append({'command':idx,'stream':stream,'path':str(raw),'bytes':len(b),'sha256':sha(b)})
        if 4<=idx<=16:
            text=Path(streams['stdout']['path']).read_text(errors='strict')
            summaries.append({'command':idx,'argv':argv,'summary':parse_summary(text)})
    need(cleanup_index==18 and commands[17].get('cleanup_only') is True, 'final command is not the recorded cleanup-only step')
    # Exact targeted outcomes: two new reader proof tests and both public regression controls.
    lib_names=summaries[0]['summary']['test_names']
    copy_names=summaries[2]['summary']['test_names']
    wanted_lib=[
      'region::statementful_loop_header_tests::actual_parameter_and_multi_copy_loop_test_candidates_refuse_without_claims',
      'region::statementful_loop_header_tests::real_sequential_loop_copy_candidate_accepts_and_stops_atomically']
    wanted_copy=['the_controls_keep_their_refusals_on_both_legs','the_multi_consumer_control_keeps_its_refusal_on_both_legs']
    for n in wanted_lib: need(lib_names.count(n)==1, f'new jarde_java reader test did not execute exactly once: {n}')
    for n in wanted_copy: need(copy_names.count(n)==1, f'public copy-control test did not execute exactly once: {n}')
    total={k:sum(s['summary'][k] for s in summaries) for k in ('passed','failed','ignored','measured','filtered')}
    java=summaries[0]['summary']; reader=summaries[1]['summary']
    p5=[s for s in summaries if 9<=s['command']<=16]
    p5tot={k:sum(s['summary'][k] for s in p5) for k in ('passed','failed','ignored','measured','filtered')}
    need(java['passed']==493 and java['ignored']==0, 'jarde-java summary differs from 493/0')
    need(reader['passed']==181 and reader['ignored']==0, 'jarde-reader summary differs from 181/0')
    need(p5tot['passed']==104 and p5tot['ignored']==5, f'P5 summary differs from 104/5: {p5tot}')
    need(total['passed']==798 and total['ignored']==6 and total['failed']==0 and total['filtered']==0, f'all test total differs: {total}')
    cli=x['cli']; cli_path=Path(cli['path']).resolve(strict=True); cli_bytes=cli_path.read_bytes()
    need(len(cli_bytes)==cli['bytes'] and sha(cli_bytes)==cli['sha256']==EXPECTED_CLI_SHA, 'CLI bytes/hash differ from expected candidate pin')
    support={}
    for key in ('runner','spec','guard','scanner'):
        row=x[key]; path=Path(row['path']).resolve(strict=True); b=path.read_bytes()
        support[key]={'path':str(path),'bytes':len(b),'sha256':sha(b),'matches_receipt':len(b)==row['bytes'] and sha(b)==row['sha256']}
        need(support[key]['matches_receipt'], f'{key} recorded source pin mismatch')
    result={
      'schema':'statementful-loop-copy-broad-gates-root-independent-review-v1',
      'status':'accepted' if not current['missing'] and not current['changed'] else 'accepted_capture_with_current_workspace_drift',
      'execution':{'path':str(EXECUTION),'sha256':sha(EXECUTION.read_bytes()),'original_status':x['status'],'command_count':len(commands)},
      'commands':{'all_exit_zero':True,'guard_stops':0,'raw_streams_verified':len(raw_pins),'cleanup_step':cleanup_index,'raw_pins':raw_pins},
      'tests':{'by_command':summaries,'aggregate':total,'jarde_java':{'passed':java['passed'],'ignored':java['ignored']},'jarde_reader':{'passed':reader['passed'],'ignored':reader['ignored']},'p5':p5tot,'new_reader_tests_each_ran_once':wanted_lib,'public_control_tests_each_ran_once':wanted_copy},
      'source_inventory':{'count':len(before),'before_equals_after':True,'recorded_changed_paths':0,'current_workspace_check':current},
      'cli':{'path':str(cli_path),'bytes':len(cli_bytes),'sha256':sha(cli_bytes)},
      'supporting_source_pins':support,
      'runtime_and_guard':{'default_stack':x['default_stack'],'target_absent_recorded':x['target_absent'],'min_free_bytes':5*1024**3,'max_target_bytes':1024**3},
      'limitations':['This validates the captured run and its raw evidence; it does not rerun Cargo. Any current-workspace drift is reported separately from the captured before/after equality.']
    }
    OUT.mkdir(parents=True,exist_ok=True)
    dest=OUT/'root-independent-review.json'
    dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'commands':18,'raw_streams':len(raw_pins),'tests':total,'source_count':len(before),'current_source_drift':len(current['missing'])+len(current['changed']),'review':str(dest)},ensure_ascii=False))

if __name__=='__main__':
    try: verify()
    except Exception as e:
        print(f'REVIEW FAILED: {type(e).__name__}: {e}',file=sys.stderr)
        raise
