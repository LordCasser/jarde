package jadx.tests.integration.loops;

/* JADX INFO: loaded from: TestSequentialLoops$TestCls.class */
public class TestSequentialLoops$TestCls {
    public int test(int i, int i2) {
        int i3;
        int i4 = i2;
        while (true) {
            i3 = i4;
            int i5 = i3 + i;
            if (i5 >= 7) {
                break;
            }
            i4 = i5;
        }
        while (true) {
            int i6 = i3 + i;
            if (i6 < 7) {
                return i3;
            }
            i3 = i6;
        }
    }
}
