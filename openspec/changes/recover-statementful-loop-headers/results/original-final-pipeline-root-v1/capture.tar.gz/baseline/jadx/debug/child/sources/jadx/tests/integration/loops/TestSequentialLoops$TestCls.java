package jadx.tests.integration.loops;

/* JADX INFO: loaded from: TestSequentialLoops$TestCls.class */
public class TestSequentialLoops$TestCls {
    public int test(int a, int b) {
        int c;
        int i = b;
        while (true) {
            c = i;
            int z = c + a;
            if (z >= 7) {
                break;
            }
            i = z;
        }
        while (true) {
            int z2 = c + a;
            if (z2 >= 7) {
                c = z2;
            } else {
                return c;
            }
        }
    }
}
