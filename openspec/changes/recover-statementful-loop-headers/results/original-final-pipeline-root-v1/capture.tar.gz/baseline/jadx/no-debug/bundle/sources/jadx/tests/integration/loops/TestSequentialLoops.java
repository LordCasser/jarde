package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug.jar:jadx/tests/integration/loops/TestSequentialLoops.class */
public class TestSequentialLoops extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug.jar:jadx/tests/integration/loops/TestSequentialLoops$TestCls.class */
    public static class TestCls {
        public int test(int i, int i2) {
            int i3;
            int i4 = i2;
            while (true) {
                i3 = i4;
                int i5 = i3 + i;
                if (i5 >= 7) {
                    break;
                }
                i4 = i5;
            }
            while (true) {
                int i6 = i3 + i;
                if (i6 < 7) {
                    return i3;
                }
                i3 = i6;
            }
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().countString(2, "while (").containsOne("break;").containsOne("return c;");
    }
}
