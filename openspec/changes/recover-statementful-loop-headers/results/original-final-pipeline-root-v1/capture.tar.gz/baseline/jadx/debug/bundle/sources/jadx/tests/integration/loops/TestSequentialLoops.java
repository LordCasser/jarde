package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug.jar:jadx/tests/integration/loops/TestSequentialLoops.class */
public class TestSequentialLoops extends IntegrationTest {

    /* JADX INFO: loaded from: debug.jar:jadx/tests/integration/loops/TestSequentialLoops$TestCls.class */
    public static class TestCls {
        public int test(int a, int b) {
            int c;
            int i = b;
            while (true) {
                c = i;
                int z = c + a;
                if (z >= 7) {
                    break;
                }
                i = z;
            }
            while (true) {
                int z2 = c + a;
                if (z2 >= 7) {
                    c = z2;
                } else {
                    return c;
                }
            }
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().countString(2, "while (").containsOne("break;").containsOne("return c;");
    }
}
