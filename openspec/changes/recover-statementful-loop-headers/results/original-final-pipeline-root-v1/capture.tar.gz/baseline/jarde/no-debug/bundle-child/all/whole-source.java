// jarde: presentation of `jadx/tests/integration/loops/TestSequentialLoops$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestSequentialLoops$TestCls extends java.lang.Object {
    public TestSequentialLoops$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestSequentialLoops$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public int test(int arg1, int arg2) {
        // @method test(II)I
        // @declaration an instance method of `jadx.tests.integration.loops.TestSequentialLoops$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int local3;
        int local4;
        local3 = arg2;
        while (true) {
            local4 = local3 + arg1;
            if (local4 >= 7) {
                break;
            }
            local3 = local4;
        }
        while ((local4 = local3 + arg1) >= 7) {
            local3 = local4;
        }
        return local3;
    }
}
