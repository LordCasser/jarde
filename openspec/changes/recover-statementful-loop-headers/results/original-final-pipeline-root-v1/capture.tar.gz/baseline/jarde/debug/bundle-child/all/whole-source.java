// jarde: presentation of `jadx/tests/integration/loops/TestSequentialLoops$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestSequentialLoops$TestCls extends java.lang.Object {
    public TestSequentialLoops$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestSequentialLoops$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public int test(int a, int b) {
        // @method test(II)I
        // @declaration an instance method of `jadx.tests.integration.loops.TestSequentialLoops$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int c;
        int z;
        c = b;
        while (true) {
            z = c + a;
            if (z >= 7) {
                break;
            }
            c = z;
        }
        while ((z = c + a) >= 7) {
            c = z;
        }
        return c;
    }
}
