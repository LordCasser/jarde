#!/usr/bin/env python3
"""Prepared full-source rebuild/runtime matrix for TestSequentialLoops outputs.

Use python -B after review. This collector consumes the read-only baseline and
compiles saved source artifacts only; it never edits the Jarde workspace.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASELINE = Path('/private/tmp/jarde-seq1-original-final-pipeline-run-root-v1-20261018/baseline')
BASELINE_REVIEW = Path('/private/tmp/jarde-seq1-original-final-pipeline-run-root-v1-20261018/baseline-review/root-review.json')
COMPARE_REL = Path('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
COMPARE_SHA256 = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
EXPECTED_SCHEMA = 'cf11-original-testsequentialloops-baseline-v1'
EXPECTED_STATUS = 'captured-pending-independent-review'
TARGET_REL = Path('jadx/tests/integration/loops/TestSequentialLoops$TestCls.class')
OWNER_REL = Path('jadx/tests/integration/loops/TestSequentialLoops.class')
INTERNAL_CLASS = 'jadx/tests/integration/loops/TestSequentialLoops$TestCls'
EXPECTED_METHODS = {('<init>', '()V'), ('test', '(II)I')}
PROFILES = ('debug', 'no-debug')
FORMS = {'jarde': ('child', 'bundle-child'), 'jadx': ('child', 'bundle')}
EVIDENCE = ('default', 'all')
JDK_LEGS = ('javac8', 'javac23')
RUNTIMES = ('javac8', 'javac23')
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def file_tree_pin(root: Path, compare) -> dict:
    return {path.relative_to(root).as_posix(): compare.pin(path)
            for path in sorted(root.rglob('*')) if path.is_file()}


def class_method_set(facts: dict) -> set[tuple[str, str]]:
    return {(row['name'], row['descriptor']) for row in facts['methods']}


def expected_source_name(kind: str, form: str) -> str:
    if kind == 'jadx' and form == 'bundle':
        return 'TestSequentialLoops.java'
    if form in ('child', 'bundle-child') or (kind == 'jadx' and form == 'child'):
        return 'TestSequentialLoops$TestCls.java'
    raise RuntimeError(f'unexpected source selector: {kind}/{form}')


def pin_is_current(compare, pin: dict, label: str) -> None:
    if compare.pin(Path(pin['path'])) != pin:
        raise RuntimeError(f'{label} pin changed: {pin.get("path")}')


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=ROOT)
    ap.add_argument('--baseline', type=Path, default=BASELINE)
    ap.add_argument('--baseline-review', type=Path, default=BASELINE_REVIEW)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    root, baseline, baseline_review = (args.root.resolve(strict=True), args.baseline.resolve(strict=True),
                                       args.baseline_review.resolve(strict=True))
    out = args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing existing output directory: {out}')
    if root != ROOT.resolve() or baseline != BASELINE.resolve() or baseline_review != BASELINE_REVIEW.resolve():
        raise SystemExit('workspace, baseline, or baseline-review path differs from the pinned Seq1 inputs')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('repository target exists before source-rebuild matrix')
    if shutil.disk_usage(root).free < 5 * 1024**3:
        raise SystemExit('root free-space guard below 5 GiB')

    compare_path = root / COMPARE_REL
    if hashlib.sha256(compare_path.read_bytes()).hexdigest() != COMPARE_SHA256:
        raise SystemExit('compare.py pin mismatch')
    compare = load_module(compare_path, 'seq1_rebuild_compare')
    guard_path, scanner_path = root / compare.GUARD_REL, root / compare.SCANNER_REL
    if compare.sha(guard_path) != compare.GUARD_SHA256 or compare.sha(scanner_path) != compare.SCANNER_SHA256:
        raise SystemExit('run guard/scanner source pin mismatch')
    guard = load_module(guard_path, 'seq1_rebuild_guard')
    scanner = load_module(scanner_path, 'seq1_rebuild_scanner')
    jdk_manifest_path = root / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
    jdks, jdk_record = compare.configured_jdks(jdk_manifest_path,
        'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
    helper_pins = {'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path),
                   'scanner': compare.pin(scanner_path), 'jdk_manifest': compare.pin(jdk_manifest_path)}

    baseline_path = baseline / 'execution.json'
    baseline_doc = json.loads(baseline_path.read_text(encoding='utf-8'))
    baseline_review_doc = json.loads(baseline_review.read_text(encoding='utf-8'))
    if baseline_doc.get('schema') != EXPECTED_SCHEMA or baseline_doc.get('status') != EXPECTED_STATUS:
        raise SystemExit('Seq1 baseline receipt schema/status differs from the reviewed capture')
    if baseline_review_doc.get('status') != 'read_only_baseline_review_complete':
        raise SystemExit('Seq1 baseline review is not accepted by its independent read-only checker')
    if baseline_review_doc.get('input', {}).get('path') != str(baseline_path):
        raise SystemExit('baseline review is bound to another execution receipt')
    if compare.sha(baseline_path) != baseline_review_doc.get('input', {}).get('sha256'):
        raise SystemExit('baseline receipt SHA differs from its independent review')
    if baseline_doc.get('source_unchanged') is not True or baseline_doc.get('target_absent') is not True:
        raise SystemExit('baseline does not attest unchanged source and absent target')
    if len(baseline_doc.get('commands', [])) != 24:
        raise SystemExit('Seq1 baseline must contain its 24 original/API/extraction commands')
    baseline_commands = {row['index']: row for row in baseline_doc['commands']}
    if len(baseline_commands) != 24:
        raise SystemExit('duplicate baseline command ids')
    for row in baseline_commands.values():
        if row.get('guard_stop') is not None:
            raise SystemExit(f'baseline command {row["index"]} has a guard stop')
        compare.command_artifact(row, 'stdout')
        compare.command_artifact(row, 'stderr')

    baseline_pin = compare.pin(baseline_path)
    review_pin = compare.pin(baseline_review)
    source_pin, driver_pin = baseline_doc['source'], baseline_doc['driver']
    source_path, driver_source_path = Path(source_pin['path']), Path(driver_pin['path'])
    runtime_bound_pin = baseline_doc['runtime_bound']
    runtime_bound = Path(runtime_bound_pin['path'])
    pin_is_current(compare, source_pin, 'original upstream source')
    pin_is_current(compare, driver_pin, 'baseline reflection driver')
    pin_is_current(compare, runtime_bound_pin, 'baseline timeout wrapper')
    source_copy_pin = baseline_doc['source_copy']
    pin_is_current(compare, source_copy_pin, 'baseline full source copy')
    if source_path.read_bytes() != Path(source_copy_pin['path']).read_bytes():
        raise SystemExit('baseline source copy differs from complete upstream source')

    oracle_pin = baseline_doc['original_oracle']
    oracle_path = Path(oracle_pin['path'])
    pin_is_current(compare, oracle_pin, 'original six-case JVM oracle')
    oracle_bytes = oracle_path.read_bytes()
    if len(oracle_bytes.decode('utf-8', errors='strict').splitlines()) != 6:
        raise SystemExit('original observed oracle does not contain six rows')
    runtime_rows = baseline_doc.get('original_runtime', [])
    expected_runtime_keys = {(profile, runtime) for profile in PROFILES for runtime in RUNTIMES}
    if len(runtime_rows) != 4 or {(r.get('profile'), r.get('runtime')) for r in runtime_rows} != expected_runtime_keys:
        raise SystemExit('baseline original oracle does not cover four profile/JVM pairs')
    for item in runtime_rows:
        command_row = baseline_commands.get(item.get('command'))
        if command_row is None or item.get('exit_code') != 0 or command_row.get('exit_code') != 0:
            raise SystemExit('an original target/JVM run did not succeed')
        if compare.command_artifact(command_row, 'stdout') != oracle_bytes:
            raise SystemExit('original JVM rows differ from the actual recorded oracle')
    boundary = baseline_doc.get('javac8_boundary') or {}
    boundary_row = next((r for r in baseline_doc['commands'] if r['label'] == 'original-javac8-harness-boundary'), None)
    if (boundary_row is None or boundary_row.get('exit_code') == 0 or not boundary.get('observed_major_55_diagnostic')
            or b'55.0' not in compare.command_artifact(boundary_row, 'stderr')):
        raise SystemExit('original javac8 major-55 framework boundary is absent or unverified')
    wrong = baseline_doc.get('wrong_root_control') or {}
    wrong_row = baseline_commands.get(wrong.get('command'))
    if wrong_row is None or wrong_row.get('exit_code') == 0 or b'target loaded from' not in compare.command_artifact(wrong_row, 'stderr'):
        raise SystemExit('original wrong-CodeSource-root negative control is absent or did not reject')

    profiles = {row['profile']: row for row in baseline_doc.get('profiles', [])}
    if set(profiles) != set(PROFILES):
        raise SystemExit('baseline lacks debug/no-debug original class profiles')
    original_class_pins = []
    for profile in profiles.values():
        target = profile['target']
        if target.get('major') != 52 or class_method_set(target) != EXPECTED_METHODS:
            raise SystemExit('original target class is not the two-method Java 8 profile')
        for pin in profile['class_files']:
            pin_is_current(compare, pin, 'original compiled class')
            original_class_pins.append(pin)

    dep_ref = baseline_doc['dependency_reference']
    pin_is_current(compare, dep_ref, 'baseline dependency receipt')
    dep_doc = json.loads(Path(dep_ref['path']).read_text(encoding='utf-8'))
    if baseline_doc['classpath'] != dep_doc['classpath'] or baseline_doc['jar_pins'] != dep_doc['jar_pins']:
        raise SystemExit('classpath/dependency pins differ from the bound source receipt')
    classpath_full = list(baseline_doc['classpath'])
    for pin in [baseline_doc['harness_jar'], *baseline_doc['jar_pins']]:
        pin_is_current(compare, pin, 'compile dependency')
    directory_pins = baseline_doc.get('directory_pins', {})
    if not directory_pins:
        raise SystemExit('baseline lacks dependency class-directory pins')
    for folder, expected in directory_pins.items():
        actual = {p.relative_to(folder).as_posix(): compare.pin(p) for p in sorted(Path(folder).rglob('*.class'))}
        if actual != expected:
            raise SystemExit(f'compile dependency class tree changed: {folder}')
    with zipfile.ZipFile(baseline_doc['harness_jar']['path']) as jar:
        if any('TestSequentialLoops' in name for name in jar.namelist()):
            raise SystemExit('compile harness contains the Seq1 target/outer class')
    for folder in directory_pins:
        if (Path(folder) / TARGET_REL).exists() or (Path(folder) / OWNER_REL).exists():
            raise SystemExit(f'compile dependency class tree contains original Seq1 target/outer: {folder}')

    cli_pin, jadx_pin, jadx_jar_pin = baseline_doc['cli'], baseline_doc['jadx'], baseline_doc['jadx_jar']
    for label, pin in (('frozen CLI', cli_pin), ('JADX executable', jadx_pin), ('JADX JAR', jadx_jar_pin)):
        pin_is_current(compare, pin, label)
    source_before = compare.source_closure(root)
    historical_source_matches_current = source_before == baseline_doc['source_pins_before']

    # Bind each compiler input to one exact baseline report/source and extraction input.
    source_inputs = []
    jarde_cells, jadx_cells = baseline_doc.get('jarde_cells', []), baseline_doc.get('jadx_cells', [])
    expected_jarde = {(p, f, e) for p in PROFILES for f in FORMS['jarde'] for e in EVIDENCE}
    expected_jadx = {(p, f) for p in PROFILES for f in FORMS['jadx']}
    if ({(r.get('profile'), r.get('input_form'), r.get('evidence')) for r in jarde_cells} != expected_jarde
            or len(jarde_cells) != len(expected_jarde)):
        raise SystemExit('baseline Jarde source grid is not the complete 2×2×2 matrix')
    if ({(r.get('profile'), r.get('input_form')) for r in jadx_cells} != expected_jadx
            or len(jadx_cells) != len(expected_jadx)):
        raise SystemExit('baseline JADX extraction grid is not the complete 2×2 matrix')
    for row in jarde_cells:
        if row.get('exit_code') != 0 or not row.get('whole_source') or not row.get('report'):
            raise SystemExit('a Jarde baseline cell lacks saved JSON/source output')
        for pin in (row['whole_source'], row['report'], row['input']):
            pin_is_current(compare, pin, 'baseline Jarde artifact')
        report_bytes = Path(row['report']['path']).read_bytes()
        if compare.command_artifact(baseline_commands[row['command']], 'stdout') != report_bytes:
            raise SystemExit('Jarde saved report differs from its original command stdout')
        doc = json.loads(report_bytes.decode('utf-8', errors='strict'))
        source_file = Path(row['whole_source']['path'])
        if doc.get('text', '').encode('utf-8') != source_file.read_bytes():
            raise SystemExit('Jarde source artifact differs from report JSON text')
        source_inputs.append({'kind': 'jarde', 'profile': row['profile'], 'form': row['input_form'],
                              'evidence': row['evidence'], 'input_pin': row['input'],
                              'original_source': row['whole_source'], 'original_report': row['report'],
                              'source_path': source_file})
    for row in jadx_cells:
        if row.get('exit_code') != 0 or len(row.get('sources') or []) != 1:
            raise SystemExit('a JADX baseline cell lacks exactly one emitted Java source')
        source_file = Path(row['sources'][0]['path'])
        pin_is_current(compare, row['sources'][0], 'baseline JADX source')
        command_row = baseline_commands.get(row.get('command'))
        if command_row is None:
            raise SystemExit('JADX cell references an unknown original command')
        input_path = Path(command_row['argv'][-1])
        input_pin = compare.pin(input_path)
        source_inputs.append({'kind': 'jadx', 'profile': row['profile'], 'form': row['input_form'],
                              'evidence': 'source', 'input_pin': input_pin,
                              'original_source': row['sources'][0], 'original_report': None,
                              'source_path': source_file})
    if len(source_inputs) != 12:
        raise SystemExit('expected 12 complete source artifacts')

    out.mkdir(parents=True)
    raw = out / 'raw'
    raw.mkdir()
    guard.ROOT, guard.OUT = root, raw
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda _index, _stdout: None
    runtime_bound_copy = out / runtime_bound.name
    shutil.copy2(runtime_bound, runtime_bound_copy)
    runtime_bound_copy_pin = compare.pin(runtime_bound_copy)
    if runtime_bound_copy.read_bytes() != runtime_bound.read_bytes():
        raise RuntimeError('private timeout-wrapper copy differs from baseline bytes')
    driver_copy = out / 'driver-source/TestSequentialLoopsDriver.java'
    driver_copy.parent.mkdir(parents=True)
    shutil.copy2(driver_source_path, driver_copy)
    if driver_copy.read_bytes() != driver_source_path.read_bytes():
        raise RuntimeError('private matrix driver copy differs from baseline driver bytes')
    driver_copy_pin = compare.pin(driver_copy)
    driver_empty = out / 'empty-sourcepath-driver'
    driver_empty.mkdir()
    driver_classes = out / 'driver-classes'
    driver_classes.mkdir()
    for item in source_inputs:
        path = out / 'input-sources' / item['kind'] / item['profile'] / item['form'] / str(item['evidence']) / 'jadx/tests/integration/loops' / expected_source_name(item['kind'], item['form'])
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(item['source_path'].read_bytes())
        item['source_copy'] = compare.pin(path)
        item['source_filename'] = path.name
        item['compile_source'] = path

    rows = []
    report = {
        'schema': 'cf11-testsequentialloops-full-source-rebuild-matrix-v1', 'status': 'running',
        'root': str(root), 'baseline_receipt': baseline_pin, 'baseline_review': review_pin,
        'baseline_review_input_sha256': baseline_review_doc['input']['sha256'],
        'baseline_source_closure_matches_current': historical_source_matches_current,
        'baseline_original_oracle': oracle_pin, 'original_oracle_sha256': hashlib.sha256(oracle_bytes).hexdigest(),
        'original_runtime': runtime_rows, 'original_javac8_framework_boundary': {
            'command': boundary_row['index'], 'exit_code': boundary_row['exit_code'],
            'major_55_observed': True, 'stdout': boundary_row['streams']['stdout'], 'stderr': boundary_row['streams']['stderr']},
        'historical_baseline_cli': cli_pin, 'jadx': jadx_pin, 'jadx_jar': jadx_jar_pin,
        'upstream_source': source_pin, 'baseline_driver': driver_pin,
        'runtime_timeout_wrapper': runtime_bound_pin, 'jdk_manifest': jdk_record,
        'source_pins': helper_pins, 'dependency_reference': dep_ref, 'dependency_reference_after': None,
        'classpath_full_compile': classpath_full,
        'runtime_classpath_policy': 'rebuilt target/owner output root plus independent reflection driver only',
        'source_before': source_before, 'original_class_pins': original_class_pins,
        'source_inputs': [{k: item.get(k) for k in ('kind','profile','form','evidence','input_pin','original_source','original_report','source_copy','source_filename')}
                          for item in source_inputs],
        'source_inputs_after': None, 'commands': rows, 'driver_compile': None, 'driver_copy_pin': driver_copy_pin, 'timeout_wrapper_copy_pin': runtime_bound_copy_pin,
        'compilation_cells': [], 'runtime_rows': [], 'wrong_root_controls': [],
        'notes': [
            'All 8 saved Jarde class sources and 4 saved JADX sources are copied byte-for-byte; no Java source is edited or method removed.',
            'Every one of the 12 source artifacts is attempted with javac8 source/target 8 and JDK23 --release 8, for 24 compile attempts.',
            'Compile errors, missing/invalid targets, runtime failures, and oracle mismatches are distinct outcomes; failed compiles never receive runtime rows.',
            'The full pinned harness/dependency classpath is used only for compilation. Every generated-target JVM run uses only its rebuilt class output root plus the independent driver.',
            'The original javac8 major-55 harness boundary is separately bound from the reviewed baseline; generated bundle compiler errors are classified from their own raw logs.',
            'No generated output is repaired. This matrix does not re-run Jarde/JADX or make an SSA claim.',
            'The baseline CLI and its source closure are historical evidence; current source closure is frozen and compared only with this matrix end state.',
        ],
    }

    def save():
        compare.write_json(out / 'execution.json', report)

    def run_cmd(label: str, argv: list, leg: str) -> dict:
        if (root / 'target').exists():
            raise RuntimeError('repository target appeared before external command')
        env = {key: value for key, value in os.environ.items() if key not in ENV_STRIP}
        env = compare.clean_env(env, jdks[leg])
        env.update(guard.ENV_VALUES)
        env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(rows) + 1, [str(arg) for arg in argv], env)
        row['label'], row['tool_leg'] = label, leg
        rows.append(row)
        save()
        if row.get('guard_stop') is not None:
            raise RuntimeError(f'root command guard stopped {label}: {row["guard_stop"]}')
        return row

    def tree(root_dir: Path) -> dict:
        return file_tree_pin(root_dir, compare)

    def run_target(label: str, classes: Path, runtime: str) -> dict:
        before_target, before_driver = tree(classes), tree(driver_classes)
        if before_driver != report['driver_compile']['classes_tree']:
            raise RuntimeError('independent driver class tree changed before runtime')
        if before_target != current_cell['target_classes_tree']:
            raise RuntimeError('generated target class tree changed before runtime')
        cp = [str(classes), str(driver_classes)]
        row = run_cmd(label, [sys.executable, '-B', runtime_bound_copy, '30', jdks[runtime]['tools']['java'],
                              '-Xverify:all', '-cp', os.pathsep.join(cp), 'TestSequentialLoopsDriver', classes], runtime)
        after_target, after_driver = tree(classes), tree(driver_classes)
        row['matrix_classpath'] = cp
        row['expected_target_root'] = str(classes)
        row['target_class_tree_before'], row['target_class_tree_after'] = before_target, after_target
        row['driver_class_tree_before'], row['driver_class_tree_after'] = before_driver, after_driver
        if after_target != before_target or after_driver != before_driver:
            raise RuntimeError(f'runtime modified an input class tree: {label}')
        return row

    try:
        driver_compile = run_cmd('compile-independent-driver-javac8', [
            jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g:none', '-Xlint:-options',
            '-encoding', 'UTF-8', '-proc:none', '-classpath', driver_empty, '-sourcepath', driver_empty,
            '-d', driver_classes, driver_copy,
        ], 'javac8')
        driver_files = sorted(driver_classes.rglob('*.class'))
        report['driver_compile'] = {'command': driver_compile['index'], 'exit_code': driver_compile['exit_code'],
                                    'source': compare.pin(driver_copy),
                                    'classes': [compare.pin(path) for path in driver_files]}
        if driver_compile['exit_code'] != 0 or len(driver_files) != 1:
            raise RuntimeError('independent reflection driver did not compile to exactly one class')
        report['driver_compile']['classes_tree'] = tree(driver_classes)
        save()

        compile_cells = []
        wrong_root_done = False
        oracle_sha = hashlib.sha256(oracle_bytes).hexdigest()
        for item in source_inputs:
            for compiler in JDK_LEGS:
                classes = out / 'compiled' / item['kind'] / item['profile'] / item['form'] / str(item['evidence']) / compiler / 'classes'
                classes.mkdir(parents=True)
                empty = classes.parent / 'empty-sourcepath'
                empty.mkdir()
                options = (['-source', '8', '-target', '8', '-g:none', '-Xlint:-options', '-proc:none']
                           if compiler == 'javac8' else ['--release', '8', '-g:none', '-proc:none'])
                label = f'compile-{item["kind"]}-{item["profile"]}-{item["form"]}-{item["evidence"]}-{compiler}'
                compile_cp = os.pathsep.join(classpath_full)
                compiled = run_cmd(label, [jdks[compiler]['tools']['javac'], *options, '-encoding', 'UTF-8',
                                           '-classpath', compile_cp, '-sourcepath', empty, '-d', classes,
                                           item['compile_source']], compiler)
                target_path = classes / TARGET_REL
                cell = {'kind': item['kind'], 'profile': item['profile'], 'form': item['form'],
                        'evidence': item['evidence'], 'compiler': compiler, 'source': item['source_copy'],
                        'original_source': item['original_source'], 'original_report': item['original_report'],
                        'source_filename': item['source_filename'], 'compile_classpath': classpath_full,
                        'compile_command': compiled['index'], 'compile_exit_code': compiled['exit_code'],
                        'target_class_expected': str(target_path), 'target_class': None, 'target_facts': None,
                        'owner_class': None, 'runtime': []}
                if compiled['exit_code'] != 0:
                    stderr = compare.command_artifact(compiled, 'stderr')
                    cell['status'] = ('compile_failed_javac8_major55_no_runtime'
                                      if compiler == 'javac8' and (b'55.0' in stderr or b'version 55' in stderr)
                                      else 'compile_failed_no_runtime')
                    cell['stderr_sha256'] = hashlib.sha256(stderr).hexdigest()
                elif not target_path.is_file():
                    cell['status'] = 'compile_succeeded_target_missing_no_runtime'
                else:
                    cell['target_class'] = compare.pin(target_path)
                    cell['target_classes_root'] = str(classes)
                    cell['target_classes_tree'] = tree(classes)
                    owner_path = classes / OWNER_REL
                    cell['owner_class'] = compare.pin(owner_path) if owner_path.is_file() else None
                    try:
                        facts = compare.parse_class(target_path)
                        cell['target_facts'] = facts
                        cell['declared_methods_match_expected'] = facts['class_name'] == INTERNAL_CLASS and class_method_set(facts) == EXPECTED_METHODS
                        cell['all_methods_have_code'] = all(method.get('code') is not None for method in facts['methods'])
                        cell['classfile_major_is_java8'] = facts['major'] == 52
                        if (cell['declared_methods_match_expected'] and cell['all_methods_have_code']
                                and cell['classfile_major_is_java8']):
                            cell['status'] = 'compiled_target_java8_two_methods'
                            current_cell = cell
                            if not wrong_root_done:
                                wrong = out / 'empty-wrong-root'
                                wrong.mkdir()
                                wrong_run = run_cmd('matrix-wrong-root-code-source-rejection', [
                                    sys.executable, '-B', runtime_bound_copy, '30', jdks['javac23']['tools']['java'],
                                    '-Xverify:all', '-cp', os.pathsep.join([str(classes), str(driver_classes)]),
                                    'TestSequentialLoopsDriver', wrong,
                                ], 'javac23')
                                wrong_stderr = compare.command_artifact(wrong_run, 'stderr')
                                wrong_ok = wrong_run['exit_code'] != 0 and b'target loaded from' in wrong_stderr
                                report['wrong_root_controls'].append({'command': wrong_run['index'],
                                    'exit_code': wrong_run['exit_code'], 'expected_root': str(wrong),
                                    'stderr_sha256': hashlib.sha256(wrong_stderr).hexdigest(), 'rejected': wrong_ok})
                                if not wrong_ok:
                                    raise RuntimeError('matrix wrong-root CodeSource control did not reject')
                                wrong_root_done = True
                            for runtime in RUNTIMES:
                                run = run_target(f'runtime-{item["kind"]}-{item["profile"]}-{item["form"]}-{item["evidence"]}-{compiler}-on-{runtime}', classes, runtime)
                                stdout = compare.command_artifact(run, 'stdout')
                                stderr = compare.command_artifact(run, 'stderr')
                                same = run['exit_code'] == 0 and stdout == oracle_bytes
                                runtime_cell = {'runtime': runtime, 'command': run['index'],
                                    'exit_code': run['exit_code'], 'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
                                    'stderr_sha256': hashlib.sha256(stderr).hexdigest(),
                                    'oracle_equal_byte_for_byte': same,
                                    'status': 'matches_original_jvm_oracle' if same else ('runtime_failed' if run['exit_code'] != 0 else 'runtime_oracle_mismatch'),
                                    'classpath': run['matrix_classpath'], 'stdout_bytes': len(stdout)}
                                cell['runtime'].append(runtime_cell)
                                report['runtime_rows'].append({**{k: cell[k] for k in ('kind','profile','form','evidence','compiler')}, **runtime_cell})
                                save()
                    except (ValueError, IndexError, KeyError) as parse_error:
                        cell['status'] = 'compiled_target_classfile_invalid_no_runtime'
                        cell['target_parse_error'] = str(parse_error)
                    else:
                        if cell['status'] != 'compiled_target_java8_two_methods':
                            cell['status'] = 'compiled_target_identity_or_major_mismatch_no_runtime'
                compile_cells.append(cell)
                report['compilation_cells'] = compile_cells
                save()

        # Recheck all baseline/source/tool inputs after every compile/runtime attempt.
        after_sources = []
        for item in source_inputs:
            for role, pin in (('source_copy', item['source_copy']), ('original_source', item['original_source']),
                              ('original_report', item['original_report']), ('input_class_or_archive', item['input_pin'])):
                if pin:
                    pin_is_current(compare, pin, role)
                    after_sources.append({'selector': [item['kind'], item['profile'], item['form'], item['evidence']],
                                          'role': role, 'pin': pin})
        report['source_inputs_after'] = after_sources
        report['source_after'] = compare.source_closure(root)
        report['baseline_receipt_after'] = compare.pin(baseline_path)
        report['dependency_reference_after'] = compare.pin(Path(dep_ref['path']))
        report['baseline_review_after'] = compare.pin(baseline_review)
        report['driver_source_after'] = compare.pin(driver_copy)
        report['driver_classes_tree_after'] = tree(driver_classes)
        report['timeout_wrapper_after'] = compare.pin(runtime_bound_copy)
        report['original_classes_after'] = [compare.pin(Path(pin['path'])) for pin in original_class_pins]
        report['helper_pins_after'] = {'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path),
                                       'scanner': compare.pin(scanner_path), 'jdk_manifest': compare.pin(jdk_manifest_path)}
        report['dependencies_after'] = {'harness': compare.pin(Path(baseline_doc['harness_jar']['path'])),
            'jars': [compare.pin(Path(pin['path'])) for pin in baseline_doc['jar_pins']],
            'classes': {folder: {p.relative_to(folder).as_posix(): compare.pin(p)
                                 for p in sorted(Path(folder).rglob('*.class'))} for folder in directory_pins}}
        if report['source_after'] != source_before or report['baseline_receipt_after'] != baseline_pin:
            raise RuntimeError('current shared source or historical baseline receipt changed during matrix')
        if report['dependency_reference_after'] != dep_ref:
            raise RuntimeError('baseline dependency reference changed during matrix')
        if report['baseline_review_after'] != review_pin or report['driver_source_after'] != driver_copy_pin:
            raise RuntimeError('baseline review or copied independent driver changed during matrix')
        if report['timeout_wrapper_after'] != runtime_bound_copy_pin:
            raise RuntimeError('copied timeout wrapper changed during matrix')
        if report['helper_pins_after'] != helper_pins:
            raise RuntimeError('matrix helper/JDK pins changed during collection')
        if report['original_classes_after'] != original_class_pins:
            raise RuntimeError('original class profiles changed during matrix')
        if (root / 'target').exists():
            raise RuntimeError('workspace target appeared by end of matrix')
        report['source_unchanged'] = True
        report['baseline_unchanged'] = True
        report['target_absent'] = True
        report['status'] = 'captured-pending-independent-review'
    except BaseException as error:
        report['status'] = 'failed'
        report['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out / 'execution.json', report)
        shutil.copy2(__file__, out / 'collector.py')
        print(json.dumps({'status': report['status'], 'compile_cells': len(report['compilation_cells']),
                          'runtime_rows': len(report['runtime_rows']), 'output': str(out)}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
