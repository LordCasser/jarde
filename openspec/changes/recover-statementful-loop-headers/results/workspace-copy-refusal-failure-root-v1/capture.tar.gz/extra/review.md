# `recover_loop_test_copy_store` regression review

Scope: read-only comparison of the two reported failures against `tests/recover_loop_test_copy_store.rs`, its complete fixture, pinned old outputs, and OpenSpec change `recover-loop-test-copy-store`. No toolchain or CLI was run; this memo does not attribute a specific new-code path to either failure without the failed raw output.

## Why these are real rejection controls

The test module doc and OpenSpec proposal/spec require a narrow loop-test copy form: a `dup; store` has exactly the paired store/test consumers, targets a body-declared local, and stays in the loop test's own operand position. Copy-family and guard controls are frozen byte-for-byte. The older `statementful` loop-header support cannot make the new head renderer an alternative way to print the copy when those conditions are absent.

### `ProbeControls.parameterTarget`

Source: `tests/fixtures/recover-loop-test-copy-store/ProbeControls.java`, `parameterTarget(int c, String path)`.

The loop has the same read/dup/store/compare pattern as `Probe.readAll`, but the store target is the method parameter `c`, not a local declared by the body. The target's definition is the method-entry/parameter slot. The recovery contract deliberately does not synthesize a body declaration or move the assignment into an unsupported parameter expression. Its pinned refusal is the explanation-only method with `@bytecode 0 11 21 28` and the original local-crossing diagnostic. `CONTROLS_TEXT` checks the complete class output on both compiler legs; the test also requires that no `while ((c =` presentation appears.

### `ProbeControls.guardIfFirst`

Source: same file, `guardIfFirst(String path)`.

The first assignment-copy is in `if ((total = fr.read()) > 0)` inside a `try/finally`, before the later loop. It is not the loop's own test. The protected range has the guard/close exception structure, and `total` is observable in the `if` arm. The complete pinned method remains explanation-only with its bytecode set and `the local assignment condition was not completely proved`; the test checks both the refusal marker and absence of `total = fr.read()` in recovered code. Do not let a loop-header recognizer absorb this preceding `if`-position assignment or broaden the copy movement rule from a loop test to an arbitrary condition.

### `MultiCopy.readAll`

Input: `tests/fixtures/recover-loop-test-copy-store/v8{,-javac8}/MultiCopy.class`, produced by `patch_controls.py` from each leg's complete `Probe.class` with exactly one same-width byte replacement in `readAll`: the loop test's `iconst_m1` becomes `dup` (`0x02` → `0x59`). The body and all other methods stay byte-identical to `Probe` for that leg.

The original test stack is `invoke read; dup; istore; iconst_m1; if_icmp...`: the duplicate is the exact store/test pair. In `MultiCopy`, the surviving value after the store is duplicated again and the branch compares that value with its own copy. The original read result therefore has a different use graph, and the branch no longer tests against `-1`. The frozen refusal is `@bytecode 0 17 27 37` plus the local-crossing explanation. Public assertions compare the patched refusal against the unpatched positive, require no `(local3 = local1.read())` text, and require `guardPlain` to remain identical. The fixture README records `-Xverify:all` on both JVM legs and `MultiCopy`'s original output `/1105`; the class is valid and its behavior differs from the positive loop, so a partially emitted `while` is not an acceptable snapshot update.

## Full frozen inputs and runnable oracle

The source inventory is complete, not a hand-trimmed negative:

- `Probe.java` and `ProbeControls.java` are the two full Java sources; `data.txt` is the 12-byte `hello\nworld\n` input.
- Each compiler leg has `Probe.class`, `ProbeControls.class`, and `MultiCopy.class`: six class inputs total. `MultiCopy.class` has no independent Java source; the one-byte generator derives it from the same leg's complete `Probe.class`.
- `Probe` has `<init>`, `readAll`, `guardPlain`, and `main`; `ProbeControls` has `<init>`, `parameterTarget`, `guardIfFirst`, and `main`. No method was deleted to obtain the refusal.
- `README.md` pins both compilation commands, all six class SHA-256 values, the one-byte patch location, verifier status, and original behavior.

Original JVM outputs recorded in the fixture README are `Probe: hello|world|/1105`, `ProbeControls: 1103/1105`, and patched `MultiCopy: /1105` on both compiler/JVM legs. The Rust ignored replay currently compiles and runs the stripped, recovered `Probe` text only and compares it against its original class. It does not compile refusal snapshots for `ProbeControls` or `MultiCopy`; their source-level refusing snapshots must remain exact and should not be made to compile by changing the expected text.

## Internal rejection coverage to add or verify

Keep the two public tests and their exact texts/assertions. Add Reader-backed coverage on these same committed valid class bytes so the rejection is proven after complete analysis, not by an invalid class or a partial source snapshot:

1. **Parameter declaration boundary:** for both `ProbeControls` compiler inputs, require completed facts/SSA and verify the store's local is the parameter entry slot, not a body declaration. Call the same consumer/recognizer the new loop-header path uses and require it not to claim this copy. The evidence should name the physical `Dup`, `Store`, and comparison branch identities and the parameter-slot ownership; do not merely assert a helper mirror predicate.
2. **Exact copy-use boundary:** for both `MultiCopy` compiler inputs, require complete canonical/SSA analysis and assert the modified producer/use chain: the value left after the store feeds another `Dup`, and the branch's operands are the duplicated runtime value, not the required constant comparator. The loop-test copy candidate must be refused when the consumer is extra or the branch operand identity is wrong. Pair it with the corresponding `Probe.readAll` positive from the same compiler leg to show that the one-byte change alone flips admission.
3. **Position/protected-context boundary:** for both `ProbeControls` inputs, verify that the `guardIfFirst` copy is in an `If` condition within the protected range, with exception rows present, while `guardPlain` remains the same guard/body control without an if-position dance. Require the statementful loop-header consumer not to claim the earlier if-condition copy and preserve its full-method refusal. This tests the position and handler boundary directly rather than relaxing the frozen text assertion.
4. **Atomic public result:** keep the whole `CONTROLS_TEXT` equality on both legs, the exact parameter and if refusal strings, the absence of a loop assignment in the parameter control, and the absence of a recovered assignment in `guardIfFirst`. Keep `MultiCopy`'s refusal markers, absence of the in-place read assignment, positive `Probe` comparison, and unchanged `guardPlain` assertion. Do not replace these with a weaker “fallback is acceptable” check.

The current reports identify both failing public tests, but without their exact failed output and the candidate's same-run reader facts I cannot say whether the new helper bypassed the parameter gate, the use-identity gate, or the protected-position gate. The tests above isolate each contract at the real consumer and keep that uncertainty explicit.
