import hashlib, importlib.util, json
from pathlib import Path
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
RUN = Path('/private/tmp/jarde-seq1-loop-boundary-inputs-root-v1-20261018')
def pin(path):
    path = Path(path); data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
d = json.loads((RUN/'execution.json').read_bytes())
assert d['status'] == 'captured-pending-independent-review'
assert d['source_unchanged'] and d['source_closure_before'] == d['source_closure_after']
assert d['target_absent'] and not (ROOT/'target').exists()
compare = module(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py', 'compare')
assert compare.source_closure(ROOT) == d['source_closure_after']
assert d['external_pins_before'] == d['external_pins_after']
for item in d['external_pins_after'].values():
    p = Path(item['path']); actual = pin(p)
    assert actual['bytes'] == item['bytes'] and actual['sha256'] == item['sha256']
parser = module(RUN/'accepted-classfile-parser.py', 'parser')
assert pin(RUN/'accepted-classfile-parser.py')['sha256'] == 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
assert len(d['commands']) == 10 and len(d['runtime']) == 6
for index,c in enumerate(d['commands'],1):
    assert c['index'] == index and c['exit_code'] == 0 and c.get('guard_stop') is None
    assert c['peak_target_bytes'] <= 1024**3 and c['free_bytes_after'] >= 5*1024**3
    for channel,item in c['streams'].items():
        assert Path(item['path']) == RUN/'raw'/f'{index}.{channel}.raw'
        assert pin(item['path']) == item
facts = {}
for record in d['classes']:
    parsed = parser.parse_class_file(Path(record['path']).read_bytes())
    for key,value in parsed.items(): assert record[key] == value
    assert pin(record['path']) == {key:record[key] for key in ['path','bytes','sha256']}
    facts[parsed['class_name']] = parsed
assert set(facts) == {'StatementfulLoopBoundary','StatementfulDualEntry','StatementfulJsrCloneHeader','DualEntryBoundaryDriver','JsrCloneHeaderDriver','StatementfulLoopBoundaryDriver'}
expected_methods = {'StatementfulLoopBoundary': {('<init>','()V'),('tick','(I)I'),('extraBodyExit','(I)I'),('multipleLatches','(I)I')}, 'StatementfulDualEntry': {('run','(II)I'),('tick','(I)I')}, 'StatementfulJsrCloneHeader': {('run','(I)I'),('tick','(I)I')}}
counts = {'classes':3,'code_bodies':0,'instructions':0,'handlers':0,'branch_targets':0,'jsr':0}
for name,methods in expected_methods.items():
    f = facts[name]
    assert {(m['name'],m['descriptor']) for m in f['methods']} == methods
    assert f['major'] == (52 if name == 'StatementfulLoopBoundary' else 49)
    for m in f['methods']:
        code=m['code']; data=bytes.fromhex(code['code_hex']); bcis=set(code['bcis'])
        counts['code_bodies']+=1; counts['instructions']+=len(bcis); counts['handlers']+=len(code['rows'])
        for at in sorted(bcis):
            op=data[at]
            if 0x99 <= op <= 0xa8 or op in (0xc6,0xc7):
                target=at+int.from_bytes(data[at+1:at+3],'big',signed=True)
                assert target in bcis; counts['branch_targets']+=1
            elif op in (0xc8,0xc9):
                assert at+int.from_bytes(data[at+1:at+5],'big',signed=True) in bcis
                counts['branch_targets']+=1
            assert op not in (0xaa,0xab), 'update independent switch count if fixture changes'
            counts['jsr']+=op in (0xa8,0xc9)
assert counts == {'classes':3,'code_bodies':8,'instructions':104,'handlers':0,'branch_targets':16,'jsr':2}
for driver in ['StatementfulLoopBoundaryDriver','DualEntryBoundaryDriver','JsrCloneHeaderDriver']:
    rows=[r for r in d['runtime'] if r['driver']==driver]
    assert len(rows)==2 and {r['jvm'] for r in rows}=={'javac8','javac23'}
    assert rows[0]['stdout']==rows[1]['stdout'] and rows[0]['stdout']
    for r in rows:
        c=d['commands'][r['command']-1]; argv=c['argv']
        assert r['exit_code']==0 and argv[1:4]==['-B',str(RUN/'runtime-bound.py'),'30']
        assert Path(argv[4]).resolve()==Path(d['jdk_manifest']['tools'][r['jvm']]['java']['path']).resolve()
        assert argv[5:]==['-Xverify:all','-cp',str(RUN/'driver-classes'),driver,r['target_root']]
        assert r['classpath']==[str(RUN/'driver-classes')]
        assert Path(c['streams']['stdout']['path']).read_text()==r['stdout']
        assert not Path(c['streams']['stderr']['path']).read_bytes()
        for kind in ['target','driver']:
            assert r[kind+'_tree_before']==r[kind+'_tree_after']
            for item in r[kind+'_tree_after'].values(): assert pin(item['path'])==item
out=RUN/'root-review.json'; assert not out.exists()
out.write_text(json.dumps({'status':'accepted-inputs','execution':pin(RUN/'execution.json'),'commands':10,'JVM_verifications':6,'fixture_census':counts,'scope':'Full Java methods executed on finite cases. Generated dual-entry and jsr controls only Class.forName/getDeclaredMethods verification under both JVMs, never run(); no Reader natural loop/clone claim yet.','prep_history':'Root rejected unexecuted JSR v2 iload0 after astore0; v3 loads saved limit local1. Collector Luna v1 had a mistyped manifest SHA and did not reject nonzero runtime; fresh root v2 corrected both before execution.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'accepted-inputs','fixture_census':counts,'review':str(out)}))
