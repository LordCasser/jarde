#!/usr/bin/env python3
"""Private, not-yet-run collector for Seq1 statementful loop boundary inputs.

Invoke only after root review: python3 -B collect.py --out <fresh-path>.
It captures a source-compiled Java class and a generated major-49 dual-entry class.
"""
from __future__ import annotations
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
PREP = Path('/private/tmp/jarde-seq1-loop-boundary-prep-luna-v1-20261018')
SOURCE = PREP / 'StatementfulLoopBoundary.java'
SOURCE_SHA = 'f9d606e84c71f34d10f42ad8909e46a1f43e8b2adbe4f929a4054db853a76f37'
SOURCE_DRIVER = PREP / 'StatementfulLoopBoundaryDriver.java'
SOURCE_DRIVER_SHA = 'db67d609db118c303fdc77ad2f81a1155f893364a05bf0c4c536f28a65713835'
DUAL_DRIVER = PREP / 'DualEntryBoundaryDriver.java'
DUAL_DRIVER_SHA = '9c4bcd550ad9b1866d3b63585b3762ead386a55350140f57f4504001d170531f'
GENERATOR = PREP / 'generate_dual_entry.py'
GENERATOR_SHA = 'dac2b914fd6e9b5f9b280540376412ed619b143a0fb0bd0a5b4d7bb9de5a2273'
JSR_PREP = Path('/private/tmp/jarde-seq1-loop-boundary-prep-luna-v3-20261018')
JSR_DRIVER = JSR_PREP / 'JsrCloneHeaderDriver.java'
JSR_DRIVER_SHA = '1b7ff08f26af451e624502bf7e0f5c239cd33ae2d120b81607eaed88207077de'
JSR_GENERATOR = JSR_PREP / 'generate_jsr_clone_header.py'
JSR_GENERATOR_SHA = 'a7fc85825a29df4a9a6373def1cc9751a7927e5cc0f038bf0d3e713262592d98'
PARSER = Path('/private/tmp/jarde-seq1-supplement-collector-prep-luna-v1-20261018/helpers/accepted-classfile-parser.py')
PARSER_SHA = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
COMPARE_REL = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
RUNTIME_BOUND = Path('/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
RUNTIME_BOUND_SHA = '73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
JDK_LEGS = ('javac8', 'javac23')


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temp.replace(path)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def tree_pins(directory: Path) -> dict:
    return {p.relative_to(directory).as_posix(): pin(p)
            for p in sorted(directory.rglob('*')) if p.is_file()}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    root = args.root.resolve(strict=True)
    out = args.out.resolve()
    if root != ROOT.resolve():
        raise SystemExit(f'workspace differs from pin: {root}')
    if out.exists():
        raise SystemExit(f'refusing existing output: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('workspace target must be absent before collection')

    compare_path = root / COMPARE_REL
    guard_path = root / GUARD_REL
    scanner_path = root / SCANNER_REL
    for path, expected, label in (
        (SOURCE, SOURCE_SHA, 'Java source'), (SOURCE_DRIVER, SOURCE_DRIVER_SHA, 'source driver'),
        (DUAL_DRIVER, DUAL_DRIVER_SHA, 'dual-entry driver'), (GENERATOR, GENERATOR_SHA, 'dual-entry generator'),
        (JSR_DRIVER, JSR_DRIVER_SHA, 'JSR-clone driver'), (JSR_GENERATOR, JSR_GENERATOR_SHA, 'JSR-clone generator'),
        (PARSER, PARSER_SHA, 'accepted classfile parser'), (RUNTIME_BOUND, RUNTIME_BOUND_SHA, 'runtime wrapper'),
        (guard_path, GUARD_SHA, 'command guard'), (scanner_path, SCANNER_SHA, 'target scanner'),
    ):
        if sha(path) != expected:
            raise SystemExit(f'{label} SHA pin mismatch: {path}')
    # Manifest pin copied from the already-accepted Seq1 collector. Verify before loading JDK tools.
    manifest_path = root / JDK_MANIFEST_REL
    manifest_sha = sha(manifest_path)
    expected_manifest_sha = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
    if manifest_sha != expected_manifest_sha:
        raise SystemExit(f'JDK manifest SHA pin mismatch: {manifest_path}')
    if sha(guard_path) != GUARD_SHA or sha(scanner_path) != SCANNER_SHA:
        raise SystemExit('guard/scanner pin mismatch')

    compare = load_module(compare_path, 'boundary_compare')
    guard = load_module(guard_path, 'boundary_guard')
    scanner = load_module(scanner_path, 'boundary_scanner')
    parser_module = load_module(PARSER, 'boundary_classfile_parser')
    jdks, jdk_pin = compare.configured_jdks(manifest_path, expected_manifest_sha)
    if shutil.disk_usage(root).free < 5 * 1024**3:
        raise SystemExit('5 GiB free-space guard failed')

    out.mkdir(parents=True)
    raw_dir = out / 'raw'; raw_dir.mkdir()
    guard.ROOT = root
    guard.OUT = raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, stdout_bytes: None

    copied = out / 'inputs'; copied.mkdir()
    source_copy = copied / SOURCE.name; shutil.copy2(SOURCE, source_copy)
    source_driver_copy = copied / SOURCE_DRIVER.name; shutil.copy2(SOURCE_DRIVER, source_driver_copy)
    dual_driver_copy = copied / DUAL_DRIVER.name; shutil.copy2(DUAL_DRIVER, dual_driver_copy)
    generator_copy = copied / GENERATOR.name; shutil.copy2(GENERATOR, generator_copy)
    jsr_driver_copy = copied / JSR_DRIVER.name; shutil.copy2(JSR_DRIVER, jsr_driver_copy)
    jsr_generator_copy = copied / JSR_GENERATOR.name; shutil.copy2(JSR_GENERATOR, jsr_generator_copy)
    parser_copy = copied / PARSER.name; shutil.copy2(PARSER, parser_copy)
    wrapper_copy = out / 'runtime-bound.py'; shutil.copy2(RUNTIME_BOUND, wrapper_copy)
    empty_classpath = out / 'empty-classpath'; empty_classpath.mkdir()
    empty_sourcepath = out / 'empty-sourcepath'; empty_sourcepath.mkdir()

    source_before = compare.source_closure(root)
    def external_pins():
        items = {
            'source': SOURCE, 'source_driver': SOURCE_DRIVER, 'dual_driver': DUAL_DRIVER,
            'generator': GENERATOR, 'jsr_driver': JSR_DRIVER, 'jsr_generator': JSR_GENERATOR,
            'accepted_parser': PARSER, 'runtime_wrapper': RUNTIME_BOUND,
            'compare': compare_path, 'guard': guard_path, 'scanner': scanner_path,
            'jdk_manifest': manifest_path,
            'source_copy': source_copy, 'source_driver_copy': source_driver_copy,
            'dual_driver_copy': dual_driver_copy, 'generator_copy': generator_copy,
            'jsr_driver_copy': jsr_driver_copy, 'jsr_generator_copy': jsr_generator_copy,
            'parser_copy': parser_copy, 'runtime_wrapper_copy': wrapper_copy,
        }
        result = {key: pin(path) for key, path in items.items()}
        result['python'] = {'path': sys.executable, 'bytes': Path(sys.executable).stat().st_size,
                            'sha256': sha(Path(sys.executable))}
        for leg in JDK_LEGS:
            for name, path in jdks[leg]['tools'].items():
                result[f'{leg}_{name}'] = pin(path)
        return result

    inputs_before = external_pins()
    commands = []
    report = {
        'schema': 'seq1-statementful-loop-boundary-capture-v1', 'status': 'running',
        'source': pin(SOURCE), 'source_driver': pin(SOURCE_DRIVER), 'dual_driver': pin(DUAL_DRIVER),
        'generator': pin(GENERATOR), 'jsr_driver': pin(JSR_DRIVER), 'jsr_generator': pin(JSR_GENERATOR),
        'accepted_parser': pin(PARSER), 'runtime_wrapper': pin(RUNTIME_BOUND),
        'jdk_manifest': jdk_pin, 'guard': pin(guard_path), 'scanner': pin(scanner_path),
        'source_closure_before': source_before, 'external_pins_before': inputs_before,
        'commands': commands, 'source_compile': None, 'dual_generation': None, 'jsr_generation': None,
        'driver_compile': None, 'classes': [], 'runtime': [],
        'notes': [
            'This collector was prepared but not run by its author. Root must review it before execution.',
            'StatementfulLoopBoundary.java is compiled in full with pinned javac8 debug settings.',
            'StatementfulDualEntry.class is generated by the frozen private standard-library generator; it is not a compiler output.',
            'Both reflection drivers live in a separate parentless class loader at runtime; target roots are arguments and are absent from ambient classpath.',
            'The collector records raw streams, complete Code/BCI/exception-row class facts, exact argv, runtime class-tree pins, and source/tool closure.',
            'JSR-clone input uses the corrected v3 generator; class validity and clone interpretation remain pending root verification.',
        ],
    }
    write_json(out / 'execution.json', report)

    def run(argv, label, leg):
        if (root / 'target').exists() or (root / 'target').is_symlink():
            raise RuntimeError('workspace target appeared during collection')
        if shutil.disk_usage(root).free < 5 * 1024**3:
            raise RuntimeError('5 GiB free-space guard failed during collection')
        env = compare.clean_env(dict(os.environ), jdks[leg])
        env.update(guard.ENV_VALUES)
        env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(commands) + 1, [str(x) for x in argv], env)
        row['label'] = label; row['tool_leg'] = leg
        commands.append(row)
        write_json(out / 'execution.json', report)
        if row.get('guard_stop') is not None:
            raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        return row

    def raw(row, channel='stdout') -> bytes:
        return compare.command_artifact(row, channel)

    def parse_class(path: Path) -> dict:
        data = path.read_bytes()
        facts = parser_module.parse_class_file(data)
        facts.update({'path': str(path.resolve()), 'bytes': len(data), 'sha256': sha_bytes(data)})
        return facts

    def record_runtime(target_root: Path, driver: str, vm_leg: str, class_name: str):
        target_before = tree_pins(target_root)
        driver_before = tree_pins(driver_root)
        command = run([sys.executable, '-B', wrapper_copy, '30', jdks[vm_leg]['tools']['java'],
                       '-Xverify:all', '-cp', str(driver_root), driver, str(target_root)],
                      f'{driver}-{class_name}-{vm_leg}', vm_leg)
        target_after = tree_pins(target_root); driver_after = tree_pins(driver_root)
        if target_before != target_after or driver_before != driver_after:
            raise RuntimeError(f'class files changed during {driver}/{vm_leg}')
        entry = {'label': command['label'], 'command': command['index'], 'exit_code': command['exit_code'],
                 'jvm': vm_leg, 'driver': driver, 'class_name': class_name,
                 'target_root': str(target_root), 'classpath': [str(driver_root)],
                 'target_tree_before': target_before, 'target_tree_after': target_after,
                 'driver_tree_before': driver_before, 'driver_tree_after': driver_after,
                 'stdout': raw(command).decode('utf-8', errors='replace'),
                 'stderr_sha256': sha_bytes(raw(command, 'stderr'))}
        report['runtime'].append(entry)
        write_json(out / 'execution.json', report)

    try:
        # Full-source Java input, pinned javac8 debug class.
        source_root = out / 'statementful' / 'classes'; source_root.mkdir(parents=True)
        src_compile = run([jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
                           '-encoding', 'UTF-8', '-proc:none', '-classpath', empty_classpath,
                           '-sourcepath', empty_sourcepath, '-d', source_root, source_copy],
                          'compile-statementful-boundary-javac8-debug', 'javac8')
        produced = sorted(source_root.rglob('*.class'))
        if src_compile['exit_code'] != 0 or [p.relative_to(source_root).as_posix() for p in produced] != ['StatementfulLoopBoundary.class']:
            raise RuntimeError('complete Java source compile failed or emitted unexpected class inventory; raw retained')
        source_class = source_root / 'StatementfulLoopBoundary.class'
        report['source_compile'] = {'command': src_compile['index'], 'exit_code': src_compile['exit_code'],
                                    'class_root': str(source_root), 'class': parse_class(source_class)}

        # Generate v49 dual-entry input, then capture bytes and class facts.
        dual_root = out / 'dual-entry' / 'classes'; dual_root.mkdir(parents=True)
        gen = run([sys.executable, '-B', generator_copy, dual_root / 'StatementfulDualEntry.class'],
                  'generate-dual-entry-v49', 'javac8')
        dual_class = dual_root / 'StatementfulDualEntry.class'
        if gen['exit_code'] != 0 or not dual_class.is_file():
            raise RuntimeError('dual-entry generator did not produce class; raw retained')
        dual_facts = parse_class(dual_class)
        if dual_facts['major'] != 49 or dual_facts['class_name'] != 'StatementfulDualEntry':
            raise RuntimeError('generated dual-entry class has unexpected major/name')
        report['dual_generation'] = {'command': gen['index'], 'exit_code': gen['exit_code'],
                                     'class_root': str(dual_root), 'class': dual_facts}

        jsr_root = out / 'jsr-clone' / 'classes'; jsr_root.mkdir(parents=True)
        jsr_gen = run([sys.executable, '-B', jsr_generator_copy, jsr_root / 'StatementfulJsrCloneHeader.class'],
                      'generate-jsr-clone-header-v49', 'javac8')
        jsr_class = jsr_root / 'StatementfulJsrCloneHeader.class'
        if jsr_gen['exit_code'] != 0 or not jsr_class.is_file():
            raise RuntimeError('JSR-clone generator did not produce class; raw retained')
        jsr_facts = parse_class(jsr_class)
        if jsr_facts['major'] != 49 or jsr_facts['class_name'] != 'StatementfulJsrCloneHeader':
            raise RuntimeError('generated JSR-clone class has unexpected major/name')
        report['jsr_generation'] = {'command': jsr_gen['index'], 'exit_code': jsr_gen['exit_code'],
                                    'class_root': str(jsr_root), 'class': jsr_facts}

        # Drivers are compiled separately and are the only runtime classpath entry.
        driver_root = out / 'driver-classes'; driver_root.mkdir()
        driver_compile = run([jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
                              '-encoding', 'UTF-8', '-proc:none', '-classpath', empty_classpath,
                              '-sourcepath', empty_sourcepath, '-d', driver_root,
                              source_driver_copy, dual_driver_copy, jsr_driver_copy],
                             'compile-isolated-reflection-drivers-javac8-debug', 'javac8')
        driver_classes = sorted(driver_root.rglob('*.class'))
        if driver_compile['exit_code'] != 0 or [p.relative_to(driver_root).as_posix() for p in driver_classes] != [
                'DualEntryBoundaryDriver.class', 'JsrCloneHeaderDriver.class', 'StatementfulLoopBoundaryDriver.class']:
            raise RuntimeError('driver compilation failed or produced unexpected classes; raw retained')
        report['driver_compile'] = {'command': driver_compile['index'], 'exit_code': driver_compile['exit_code'],
                                    'class_root': str(driver_root), 'classes': [parse_class(p) for p in driver_classes]}

        for path in (source_class, dual_class, jsr_class, *driver_classes):
            report['classes'].append(parse_class(path))
        for vm_leg in JDK_LEGS:
            record_runtime(source_root, 'StatementfulLoopBoundaryDriver', vm_leg, 'StatementfulLoopBoundary')
            record_runtime(dual_root, 'DualEntryBoundaryDriver', vm_leg, 'StatementfulDualEntry')
            record_runtime(jsr_root, 'JsrCloneHeaderDriver', vm_leg, 'StatementfulJsrCloneHeader')

        if len(commands) != 10 or len(report['runtime']) != 6 or any(c['exit_code'] != 0 for c in commands):
            raise RuntimeError('boundary input compilation/generation/JVM verification failed; raw retained')
        report['external_pins_after'] = external_pins()
        report['source_closure_after'] = compare.source_closure(root)
        report['source_unchanged'] = report['source_closure_after'] == source_before
        report['target_absent'] = not (root / 'target').exists()
        if report['external_pins_after'] != inputs_before or not report['source_unchanged'] or not report['target_absent']:
            raise RuntimeError('source/tool pin, repository closure, or target-absence check failed')
        report['status'] = 'captured-pending-independent-review'
        return 0
    except BaseException as exc:
        report['status'] = 'failed'; report['error'] = str(exc)
        raise
    finally:
        try:
            report['external_pins_after'] = external_pins()
            report['source_closure_after'] = compare.source_closure(root)
            report['source_unchanged'] = report['source_closure_after'] == source_before
            report['target_absent'] = not (root / 'target').exists()
            if report['external_pins_after'] != inputs_before or not report['source_unchanged'] or not report['target_absent']:
                report['final_guard_error'] = 'source/tool pins changed, source closure changed, or workspace target exists'
                if report['status'] == 'captured-pending-independent-review': report['status'] = 'failed'
        except BaseException as exc:
            report['final_guard_error'] = str(exc)
            if report['status'] == 'captured-pending-independent-review': report['status'] = 'failed'
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write_json(out / 'execution.json', report)
        shutil.copy2(__file__, out / 'collector.py')
        shutil.copy2(PARSER, out / 'accepted-classfile-parser.py')
        print(json.dumps({'status': report['status'], 'output': str(out), 'commands': len(commands),
                          'runtime': len(report['runtime']), 'error': report.get('error')}))

if __name__ == '__main__':
    raise SystemExit(main())
