import hashlib,json,re,sys
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');run=Path(sys.argv[1]);out=Path(sys.argv[2]);assert not out.exists()
def pin(path):
 path=Path(path).resolve(strict=True);data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
d=json.loads((run/'execution.json').read_bytes());assert d['status']=='commands_passed_pending_independent_acceptance'
assert d['default_stack'] and d['source_unchanged'] and d['source_before']==d['source_after'] and d['source_changes']==d['allowed_source_changes']==[] and d['source_changes_accepted'] and d['target_absent'] and not (ROOT/'target').exists()
assert pin(d['spec']['path'])==d['spec'];commands=json.loads(Path(d['spec']['path']).read_bytes());assert [c['argv'] for c in d['commands']]==commands+[['cargo','clean']]
for p in d['source_after']:assert pin(p['path'])==p
assert {'tests/p3_for_latch.rs','tests/fixtures/java8/cf11-for-condition/README.md'} <= {str(Path(p['path']).relative_to(ROOT)) for p in d['source_after']}
summaries=[];gate=0
for c in d['commands']:
 assert c['exit_code']==0 and c.get('guard_stop') is None
 if not c.get('cleanup_only'):
  assert c['peak_target_bytes']<=1024**3 and c['free_bytes_after']>=5*1024**3 and 'RUST_MIN_STACK' not in c.get('env_overrides',{})
 for p in c['streams'].values():assert pin(p['path'])==p
 raw=Path(c['streams']['stdout']['path']).read_text();rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)
 if c['argv'][:2]==['cargo','test']:
  assert len(rows)==1;counts=list(map(int,rows[0]));names=re.findall(r'^test (\S+)(?: - should panic)? \.\.\. ok$',raw,re.M);assert len(names)==counts[0] and counts[1]==0
  if 'p3_for_latch' in c['argv']:
   assert counts==[12,0,0];assert names.count('local_assignment_of_a_shared_condition_call_remains_a_structured_while')==1;gate+=1
  summaries.append({'argv':c['argv'],'counts':counts})
assert gate==1 and pin(d['cli']['path'])==d['cli'] and d['cli']['sha256']=='0bb89f827c1e2b6b0e215d1940299be046a7adc57866389d87e6595ba0295677'
report={'status':'accepted','execution':pin(run/'execution.json'),'reviewer':pin(__file__),'cli':d['cli'],'summaries':summaries,'passing_appearances':sum(r['counts'][0] for r in summaries),'ignored_appearances':sum(r['counts'][2] for r in summaries),'source_count':len(d['source_after']),'source_unchanged':True,'legacy_gate_exactly_once':True,'target_absent':True,'scope':'Test-only legacy expectation update. Final CLI byte-identical to all accepted complete Java/JADX/Jarde matrices. New source closure includes changed test and README, ready for product binding after both full seeds.'}
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'accepted','passed':report['passing_appearances'],'ignored':report['ignored_appearances'],'cli':d['cli']['sha256']}))
