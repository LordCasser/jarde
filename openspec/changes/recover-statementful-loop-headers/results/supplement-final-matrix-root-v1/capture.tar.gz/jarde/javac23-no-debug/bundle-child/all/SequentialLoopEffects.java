// jarde: presentation of `SequentialLoopEffects` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class SequentialLoopEffects extends java.lang.Object {
    public int c;

    public int z;

    public int phase;

    public int evaluations;

    public int phaseOneCalls;

    public int phaseTwoCalls;

    public int lastInputC;

    public int lastInputA;

    public int lastValue;

    public int throwAt;

    public int overrideAt;

    public int overrideValue;

    public long phaseTrace;

    public final java.lang.RuntimeException marker;

    public SequentialLoopEffects() {
        // @method <init>()V
        // @declaration a constructor of `SequentialLoopEffects`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.marker = new java.lang.RuntimeException("scheduled");
        return;
    }

    private int next(int arg1, int arg2) {
        // @method next(II)I
        // @declaration an instance method of `SequentialLoopEffects`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        int local3;
        this.evaluations += 1;
        if (this.phase == 1) {
            this.phaseOneCalls += 1;
        } else if (this.phase == 2) {
            this.phaseTwoCalls += 1;
    }
        this.phaseTrace = this.phaseTrace << 2 | (long) this.phase;
        this.lastInputC = arg1;
        this.lastInputA = arg2;
        local3 = arg1 + arg2;
        if (this.evaluations == this.overrideAt) {
            local3 = this.overrideValue;
        }
        this.lastValue = local3;
        if (this.evaluations == this.throwAt) {
            throw this.marker;
        } else {
            return local3;
        }
    }

    public int run(int arg1, int arg2) {
        // @method run(II)I
        // @declaration an instance method of `SequentialLoopEffects`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        this.c = arg2;
        this.phase = 1;
        while (true) {
            this.z = this.next(this.c, arg1);
            if (this.z >= 7) {
                break;
            }
            this.c = this.z;
        }
        this.phase = 2;
        while (true) {
            int saved0 = this.next(this.c, arg1);
            this.z = saved0;
            if (saved0 >= 7) {
            } else {
                break;
            }
            this.c = this.z;
        }
        return this.c;
    }
}
