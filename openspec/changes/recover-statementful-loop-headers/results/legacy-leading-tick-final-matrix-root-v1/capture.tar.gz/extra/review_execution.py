#!/usr/bin/env python3
"""Independent read-only review of the complete ForConditionRefusals capture."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, re
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASE = Path('/private/tmp/jarde-cf11-forcondition-refusals-baseline-root-v1-20261018')
PARSER = Path(__file__).with_name('classfile_helpers.py')
PARSER_SIZE = 54227
PARSER_SHA256 = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
COMPARE = ROOT / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA256 = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
SOURCE = ROOT / 'tests/fixtures/java8/cf11-for-condition/ForConditionRefusals.java'
SOURCE_SHA256 = 'e49e456fd8e128e8cddc108f3f2a5db1e863b1450a3fb8e9523ff3e19886a454'
FROZEN = ROOT / 'tests/fixtures/java8/cf11-for-condition/ForConditionRefusals.class'
FROZEN_SHA256 = '9afb4eeeb1558845789c2f4b929d3f6adcac237edb3484a11d4a0b68ddc1619b'
CLI_SHA256 = '0bb89f827c1e2b6b0e215d1940299be046a7adc57866389d87e6595ba0295677'
METHODS = {('<init>', '()V'), ('tick', '()V'), ('limit', '()I'),
           ('sumWithLeadingTickAndBreak', '()I'), ('sumWithAssignedCallBound', '()I')}
FIELDS = {('counter', 'I', 8), ('limit', 'I', 8), ('limitCalls', 'I', 8)}
PROFILES = ('javac8-debug', 'javac23-debug')
EVIDENCE = ('default', 'all')
COMPILERS = ('javac8', 'javac23')
VARIANTS = ('jarde-javac8-debug-default', 'jarde-javac8-debug-all',
            'jarde-javac23-debug-default', 'jarde-javac23-debug-all',
            'jadx-javac8-debug', 'jadx-javac23-debug')


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def verify_pin(record: dict, label: str) -> bytes:
    need(isinstance(record, dict), f'{label}: missing pin')
    path = Path(record.get('path', ''))
    need(path.is_absolute() and path.is_file(), f'{label}: missing file {path}')
    data = path.read_bytes()
    need(record == {'path': str(path.resolve()), 'bytes': len(data), 'sha256': sha(data)},
         f'{label}: bytes/SHA pin mismatch')
    return data


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None, f'cannot load {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def command_stream(row: dict, channel: str, out: Path, compare) -> bytes:
    need(row.get('guard_stop') is None, f'{row.get("label")}: runner guard stopped')
    rec = row.get('streams', {}).get(channel)
    data = verify_pin(rec, f'{row.get("label")}/{channel}')
    need(Path(rec['path']) == out / 'raw' / f'{row["index"]}.{channel}.raw',
         f'{row.get("label")}/{channel}: raw path is not index-bound')
    need(compare.command_artifact(row, channel) == data, f'{row.get("label")}/{channel}: helper read differs')
    return data


def parsed_methods(parsed: dict) -> dict:
    result = {}
    methods = parsed.get('methods', [])
    need([m.get('index') for m in methods] == list(range(len(methods))), 'method order/index is not physical')
    for method in methods:
        key = method['name'], method['descriptor']
        need(key not in result, f'duplicate method identity {key}')
        code = method.get('code')
        need(isinstance(code, dict), f'{key}: missing Code')
        raw = bytes.fromhex(code['code_hex'])
        bcis = code['bcis']
        need(len(raw) == code['code_length'] and bcis == sorted(set(bcis))
             and bcis and bcis[0] == 0 and bcis[-1] < len(raw), f'{key}: invalid physical Code/BCIs')
        need(bcis == helper.decode_bcis(raw), f'{key}: BCI decode differs from Code bytes')
        result[key] = method
    need(set(result) == METHODS, f'method inventory differs: {sorted(result)}')
    return result


def abi(parsed: dict) -> dict:
    return {
        'class_name': parsed['class_name'], 'class_access': parsed['access'],
        'fields': sorted((f['name'], f['descriptor'], f['access']) for f in parsed['fields']),
        'methods': sorted((m['name'], m['descriptor'], m['access']) for m in parsed['methods']),
    }


def compare_class_facts(data: bytes, path: Path, row: dict, label: str) -> dict:
    parsed = helper.parse_class_file(data)
    need(parsed['class_name'] == 'cf11/ForConditionRefusals' and parsed['major'] == 52,
         f'{label}: owner/major mismatch')
    need(parsed['access'] == 0x21, f'{label}: class access mismatch')
    need({(f['name'], f['descriptor'], f['access']) for f in parsed['fields']} == FIELDS,
         f'{label}: fields/access differ')
    physical = parsed_methods(parsed)
    need(all(m['access'] == (1 if m['name'] == '<init>' else 8) for m in parsed['methods']),
         f'{label}: method access differs')
    need(row.get('class_name') == parsed['class_name'] and row.get('major') == parsed['major']
         and row.get('class_access') == parsed['access'],
         f'{label}: receipt class identity/access differs from class bytes')
    recorded = {(m['name'], m['descriptor']): m for m in row.get('methods', [])}
    need(set(recorded) == METHODS, f'{label}: receipt method inventory differs from class bytes')
    for key, method in physical.items():
        got = recorded[key]
        for field in ('index', 'access', 'code'):
            need(got.get(field) == method.get(field), f'{label} {key}: receipt {field} differs from class bytes')
    need({(f['name'], f['descriptor'], f['access']) for f in row.get('fields', [])} == FIELDS,
         f'{label}: receipt field inventory differs from bytes')
    return parsed


def output_rows(data: bytes, label: str) -> list[dict]:
    text = data.decode('utf-8', errors='strict')
    pattern = re.compile(r'limit=(-?\d+) call=(leading-1|assigned|leading-2) return=(-?\d+) counter=(\d+) limitCalls=(\d+)')
    rows = []
    for line in text.splitlines():
        m = pattern.fullmatch(line)
        need(m is not None, f'{label}: malformed driver line {line!r}')
        rows.append({'limit': int(m[1]), 'call': m[2], 'return': int(m[3]),
                     'counter': int(m[4]), 'limit_calls': int(m[5]), 'raw': line})
    expected = [(limit, call) for limit in (-1, 0, 1, 4)
                for call in ('leading-1', 'assigned', 'leading-2')]
    need([(r['limit'], r['call']) for r in rows] == expected,
         f'{label}: expected all 12 calls in order; observed {len(rows)}')
    return rows


def method_identity(method: dict) -> tuple[str, str]:
    identity = method.get('item', {}).get('identity', {})
    try:
        return bytes(identity['name']).decode('utf-8'), bytes(identity['descriptor']).decode('utf-8')
    except (KeyError, TypeError, UnicodeDecodeError) as exc:
        raise ValueError(f'malformed Jarde method identity: {exc}') from exc


def audit_source_map(method_report_text: bytes, method: dict, physical_method: dict, class_bytes: bytes, label: str) -> dict:
    method_report_text.decode('utf-8', errors='strict')
    boundaries = helper.byte_boundaries(method_report_text)
    physical = set(physical_method['code']['bcis'])
    mapped, origins_seen, errors = set(), 0, []
    source_map = method.get('outcome', {}).get('report', {}).get('source_map') or {}
    segments = source_map.get('segments')
    need(isinstance(segments, list), f'{label}: no source-map segment list')
    owners = set()
    for index, segment in enumerate(segments):
        start, end = segment.get('start'), segment.get('end')
        need(isinstance(start, int) and isinstance(end, int) and 0 <= start <= end <= len(method_report_text),
             f'{label}: segment {index} range out of source bounds')
        need(start in boundaries and end in boundaries, f'{label}: segment {index} splits UTF-8 sequence')
        origin = segment.get('origin') or {}
        refs = []
        if isinstance(origin.get('primary'), dict): refs.append(origin['primary'])
        derived = origin.get('derived', [])
        need(isinstance(derived, list), f'{label}: segment {index} derived origins malformed')
        refs.extend(x for x in derived if isinstance(x, dict))
        need(refs, f'{label}: segment {index} has no origin')
        for ref in refs:
            origins_seen += 1
            method_origin = ref.get('method') or {}
            try:
                identity = (bytes(method_origin['name']).decode('utf-8'),
                            bytes(method_origin['descriptor']).decode('utf-8'))
            except (KeyError, TypeError, UnicodeDecodeError) as exc:
                raise ValueError(f'{label}: segment {index} has invalid source identity: {exc}') from exc
            need(identity == method_identity(method),
                 f'{label}: segment {index} belongs to {identity}')
            bci = ref.get('bci')
            need(isinstance(bci, int) and bci in physical, f'{label}: nonphysical BCI {bci!r}')
            mapped.add(bci)
            owner = method_origin.get('owner') or {}
            cb = owner.get('class_bytes') or {}
            location = owner.get('location') or {}
            variant = owner.get('variant') or {}
            need(cb.get('length') == len(class_bytes), f'{label}: owner class byte length differs')
            digest = cb.get('digest')
            need(isinstance(digest, str) and digest and location.get('snapshot') == digest and owner == method['item']['identity']['owner'],
                 f'{label}: class owner snapshot/digest differs')
            need(location.get('kind') == 'standalone_root' and variant.get('kind') == 'base',
                 f'{label}: unexpected source owner/variant')
            owners.add((digest, cb.get('length'), location.get('kind'), variant.get('kind')))
    missing = sorted(physical - mapped)
    need(not missing, f'{label}: physical BCIs have no source-map attribution: {missing}')
    need(len(owners) == 1, f'{label}: source-map origins disagree on class owner')
    return {'physical_bcis': sorted(physical), 'mapped_bcis': sorted(mapped),
            'segments': len(segments), 'origin_records': origins_seen,
            'utf8_boundary_valid': True, 'class_owner': list(next(iter(owners)))}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--execution', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    matrix_path, out = args.execution.resolve(strict=True), args.out.resolve()
    need(matrix_path == BASE / 'execution.json', f'unexpected matrix path {matrix_path}')
    need(not out.exists(), f'refusing existing review output {out}')
    receipt_bytes = matrix_path.read_bytes()
    doc = json.loads(receipt_bytes.decode('utf-8', errors='strict'))
    need(doc.get('schema') == 'cf11-forcondition-refusals-full-source-baseline-v1', 'wrong collector schema')
    need(doc.get('status') == 'captured-pending-independent-review', 'capture is not terminal/pending review')
    need(Path(doc['root']).resolve() == ROOT.resolve() and Path(doc['output']).resolve() == BASE.resolve(),
         'capture workspace/output root differs from the pinned run')
    need(not (ROOT / 'target').exists() and not (ROOT / 'target').is_symlink(), 'repository target exists during review')
    need(PARSER.stat().st_size == PARSER_SIZE and sha(PARSER.read_bytes()) == PARSER_SHA256,
         'accepted full classfile parser pin mismatch')
    global helper
    helper = load(PARSER, 'cf11_accepted_full_classfile_parser')
    compare = load(COMPARE, 'cf11_compare_helper')
    need(sha(COMPARE.read_bytes()) == COMPARE_SHA256, 'compare helper pin mismatch')

    need(verify_pin(doc['source'], 'fixture source') == SOURCE.read_bytes(), 'fixture source differs from receipt')
    need(doc['source'] == pin(SOURCE) and sha(SOURCE.read_bytes()) == SOURCE_SHA256,
         'fixture source pin mismatch')
    frozen_data = verify_pin(doc['frozen_javac23_class'], 'frozen javac23 class')
    need(doc['frozen_javac23_class'] == pin(FROZEN) and sha(frozen_data) == FROZEN_SHA256,
         'frozen javac23 class pin mismatch')
    need(doc.get('cli', {}).get('sha256') == CLI_SHA256 and verify_pin(doc['cli'], 'CLI') is not None,
         'selected CLI pin mismatch')
    need(doc.get('inputs_before') == doc.get('inputs_after'), 'external pins differ before/after')
    need(doc.get('source_pins_before') == doc.get('source_pins_after')
         and doc.get('source_pins_before') == doc.get('source_pins_after_finally'),
         'workspace source closure differs before/after/finally')
    need(doc.get('target_absent_after') is True and doc.get('target_absent_finally') is True,
         'collector target guard did not remain clear')
    need(doc.get('original_runtime_agreement') is True and doc.get('wrong_root_control', {}).get('rejected') is True,
         'original oracle agreement or CodeSource negative control missing')
    need(doc.get('source_pins_before') == compare.source_closure(ROOT),
         'captured workspace source closure differs from current tree')

    # Re-open all captured external pins, including compiler/JVM tools and helper/runtime inputs.
    for key, record in doc['inputs_before'].items():
        if key == 'jdk_tools':
            for name, row in record.items(): verify_pin(row, f'input {key}/{name}')
        else:
            verify_pin(record, f'input {key}')
    need(set(doc.get('inputs_after_finally', {})) == set(doc['inputs_before'])
         and doc.get('inputs_after_finally') == doc['inputs_before'],
         'finally input pins/inventory differ from pre-run inputs')
    for key, record in doc.get('inputs_after_finally', {}).items():
        if key == 'jdk_tools':
            for name, row in record.items(): verify_pin(row, f'final input {key}/{name}')
        else:
            verify_pin(record, f'final input {key}')

    commands = doc.get('commands', [])
    need(isinstance(commands, list), 'command inventory missing')
    by_label, by_index = {}, {}
    for row in commands:
        label, index = row.get('label'), row.get('index')
        need(isinstance(label, str) and label not in by_label, f'duplicate/invalid command label {label}')
        need(isinstance(index, int) and index not in by_index, f'duplicate/invalid command index {index}')
        need(row.get('guard_stop') is None, f'{label}: command guard stop')
        need(row.get('peak_target_bytes', 2**63) <= 1024**3 and row.get('free_bytes_after',0) >= 5*1024**3, f'{label}: resource limits failed')
        need('RUST_MIN_STACK' not in row.get('env_overrides', {}), f'{label}: nondefault stack')
        for channel in ('stdout', 'stderr'): command_stream(row, channel, BASE, compare)
        by_label[label], by_index[index] = row, row
    need(set(by_index) == set(range(1, len(commands) + 1)), 'command indices are not contiguous')

    expected_labels = {
        'compile-original-javac8-debug', 'compile-original-javac23-debug', 'compile-independent-driver',
        'driver-wrong-CodeSource-root', 'jadx-version',
    }
    expected_labels |= {f'original-runtime-{p}-{r}' for p in PROFILES for r in COMPILERS}
    expected_labels |= {f'jarde-{p}-{e}' for p in PROFILES for e in EVIDENCE}
    expected_labels |= {f'jadx-{p}' for p in PROFILES}
    expected_labels |= {f'compile-{v}-{c}' for v in VARIANTS for c in COMPILERS}
    expected_labels |= {f'rebuilt-runtime-{v}-{c}-{r}' for v in VARIANTS for c in COMPILERS for r in COMPILERS}
    need(set(by_label) == expected_labels,
         f'command label grid differs; missing={sorted(expected_labels-set(by_label))} extra={sorted(set(by_label)-expected_labels)}')
    need(len(doc.get('original_profiles', [])) == 2 and len(doc.get('original_runtime', [])) == 4,
         'original class/JVM matrix incomplete')
    need(len(doc.get('jarde_cells', [])) == 4 and len(doc.get('jadx_cells', [])) == 2,
         'Jarde/JADX output matrix incomplete')
    need(len(doc.get('compile_cells', [])) == 12 and len(doc.get('rebuilt_runtime', [])) == 24,
         'generated-source compile/JVM matrix incomplete')

    # Verify each original full-source class from its physical bytes and the independent parser.
    original_by_profile, class_facts = {}, {}
    for profile_row in doc['original_profiles']:
        profile = profile_row['profile']
        need(profile in PROFILES and profile not in original_by_profile, f'unexpected original profile {profile}')
        need(profile_row['exit_code'] == 0 and profile_row['target_exists'] is True,
             f'{profile}: complete source did not compile')
        command_row = by_index[profile_row['command']]
        need(command_row['label'] == f'compile-original-{profile}' and command_row['exit_code'] == 0,
             f'{profile}: original compile command binding/exit mismatch')
        target = Path(profile_row['class']['path']).resolve(strict=True)
        expected_root = BASE / 'original' / profile / 'classes'
        need(target == expected_root / 'cf11/ForConditionRefusals.class', f'{profile}: target path mismatch')
        need(profile_row['class'] == pin(target), f'{profile}: original class pin mismatch')
        tree = sorted(p.relative_to(expected_root).as_posix() for p in expected_root.rglob('*.class'))
        need(tree == ['cf11/ForConditionRefusals.class'], f'{profile}: original class tree changed: {tree}')
        parsed = compare_class_facts(target.read_bytes(), target, profile_row['facts'], profile)
        original_by_profile[profile] = profile_row
        class_facts[profile] = parsed
    need(set(original_by_profile) == set(PROFILES), 'one original compiler profile is missing')
    frozen = helper.parse_class_file(frozen_data)
    frozen_methods = parsed_methods(frozen)
    j23 = class_facts['javac23-debug']
    j23_methods = parsed_methods(j23)
    frozen_code_equal = all(frozen_methods[k]['code'] == j23_methods[k]['code'] for k in METHODS)
    need(frozen_code_equal and original_by_profile['javac23-debug'].get('frozen_javac23_code_equal') is True,
         'frozen javac23 per-method Code differs from fresh javac23 class')
    frozen_rows = original_by_profile['javac23-debug'].get('frozen_code_comparison', {})
    need(set(frozen_rows) == {name + desc for name, desc in METHODS}
         and all(frozen_rows[name + desc].get('equal') is True
                 and frozen_rows[name + desc].get('rebuilt') == j23_methods[(name, desc)]['code']
                 and frozen_rows[name + desc].get('frozen') == frozen_methods[(name, desc)]['code']
                 for name, desc in METHODS), 'receipt frozen Code comparison differs from physical class bytes')

    # Check exact compiler, driver-only classpath, CodeSource control and full observed 12-row oracle.
    tool_paths = {leg: {name: row['path'] for name, row in tools.items()}
                  for leg, tools in doc['jdk_manifest']['tools'].items()}
    for leg, profile, flags in (
        ('javac8', 'javac8-debug', ['-source', '8', '-target', '8', '-g']),
        ('javac23', 'javac23-debug', ['--release', '8', '-g']),
    ):
        argv = by_label[f'compile-original-{profile}']['argv']
        empty = str(BASE / 'empty-classpath')
        dest = str(BASE / 'original' / profile / 'classes')
        exact = [tool_paths[leg]['javac'], *flags, '-encoding', 'UTF-8', '-proc:none',
                 '-classpath', empty, '-sourcepath', empty, '-d', dest, str(BASE / 'source/ForConditionRefusals.java')]
        need(argv == exact, f'{profile}: full-source javac argv/classpath mismatch')
    driver_command = by_label['compile-independent-driver']
    driver_classes = BASE / 'driver-classes'
    empty = str(BASE / 'empty-classpath')
    driver_dest = str(BASE / 'driver-classes')
    driver_argv = [tool_paths['javac8']['javac'], '-source', '8', '-target', '8', '-g', '-encoding', 'UTF-8',
                   '-proc:none', '-classpath', empty, '-sourcepath', empty, '-d', driver_dest,
                   str(BASE / 'driver/ForConditionRefusalsDriver.java')]
    need(driver_command['exit_code'] == 0 and driver_command['argv'] == driver_argv,
         'driver compilation argv/classpath binding mismatch')
    driver_files = sorted(driver_classes.rglob('*.class'))
    need(len(driver_files) == 1 and doc['driver_classes'] == [pin(driver_files[0])],
         'driver-only class inventory differs')
    driver_source = verify_pin(doc['driver_source'], 'driver source').decode('utf-8')
    need('new URLClassLoader(new URL[] {actualRoot.toURI().toURL()}, null)' in driver_source
         and 'target.getClassLoader() != targetLoader' in driver_source
         and 'target loaded from ' in driver_source, 'driver does not prove parentless loading/CodeSource')

    oracle_outputs = []
    oracle_rows = {}
    for cell in doc['original_runtime']:
        profile, runtime = cell['profile'], cell['runtime']
        label = f'original-runtime-{profile}-{runtime}'
        cmd = by_label[label]
        need(cmd['exit_code'] == cell['exit_code'] == 0, f'{label}: runtime failed')
        argv = cmd['argv']
        need(Path(argv[0]).name.startswith('python'), f'{label}: not Python timeout wrapper')
        need(argv[1] == '-B' and Path(argv[2]) == BASE / Path(doc['runtime_wrapper']['path']).name
             and argv[3] == '30' and argv[4] == tool_paths[runtime]['java'] and argv[5] == '-Xverify:all',
             f'{label}: runtime/JVM argv mismatch')
        need(argv[6:9] == ['-cp', str(driver_classes), 'ForConditionRefusalsDriver'],
             f'{label}: target leaked into application classpath')
        expected_class_root = str((BASE / 'original' / profile / 'classes').resolve())
        need(argv[-2:] == [expected_class_root, expected_class_root], f'{label}: CodeSource roots differ')
        stdout = command_stream(cmd, 'stdout', BASE, compare)
        rows = output_rows(stdout, label)
        need(rows == cell.get('rows') and cell.get('row_count') == 12,
             f'{label}: raw observations differ from receipt rows')
        need(cell['stdout'] == cmd['streams']['stdout'] and cell['stderr'] == cmd['streams']['stderr'],
             f'{label}: runtime raw pins differ from command')
        oracle_outputs.append(stdout); oracle_rows[label] = rows
    need(len(oracle_outputs) == 4 and len(set(oracle_outputs)) == 1,
         'four original profile/JVM observations do not agree')
    oracle_data = verify_pin(doc['original_oracle'], 'saved original oracle')
    need(oracle_data == oracle_outputs[0] and output_rows(oracle_data, 'oracle') == doc['original_oracle_rows'],
         'saved oracle differs from observed original runs')
    wrong = by_label['driver-wrong-CodeSource-root']
    wrong_err = command_stream(wrong, 'stderr', BASE, compare)
    need(wrong['exit_code'] != 0 and b'target loaded from' in wrong_err
         and doc['wrong_root_control'].get('command') == wrong['index'],
         'negative CodeSource control did not fail at the expected check')

    # Reopen every Jarde report and prove complete per-method source-map attribution.
    jarde = {}
    map_audits = []
    for cell in doc['jarde_cells']:
        profile, evidence = cell['profile'], cell['evidence']
        key = (profile, evidence)
        need(key not in jarde and profile in PROFILES and evidence in EVIDENCE, f'duplicate/bad Jarde cell {key}')
        cmd = by_label[f'jarde-{profile}-{evidence}']
        need(cmd['exit_code'] == cell['exit_code'] == 0, f'Jarde extraction failed: {key}')
        argv = cmd['argv']
        target = original_by_profile[profile]['class']['path']
        expected_argv = [doc['cli']['path'], 'class-source', '--input', target, '--class', 'cf11/ForConditionRefusals',
                         '--policy', 'single-class', '--release', '8', '--format', 'json']
        if evidence == 'all': expected_argv += ['--evidence', 'all']
        need(argv == expected_argv and cmd['argv'][0] == doc['cli']['path'], f'Jarde CLI argv mismatch: {key}')
        raw = command_stream(cmd, 'stdout', BASE, compare)
        report_bytes = verify_pin(cell['report'], f'Jarde report {key}')
        need(raw == report_bytes, f'Jarde raw JSON differs from saved report: {key}')
        report = json.loads(report_bytes.decode('utf-8', errors='strict'))
        source_text = report.get('text')
        need(isinstance(source_text, str), f'Jarde report has no full text: {key}')
        source_bytes = source_text.encode('utf-8')
        need(source_bytes.decode('utf-8', errors='strict') == source_text, f'Jarde text is malformed UTF-8: {key}')
        need(verify_pin(cell['source'], f'Jarde source {key}') == source_bytes, f'Jarde source copy differs from report: {key}')
        facts = {(m['name'], m['descriptor']): m for m in original_by_profile[profile]['facts']['methods']}
        need({tuple(m['identity']) for m in cell['methods']} == METHODS and cell['method_inventory_matches'],
             f'Jarde method inventory differs: {key}')
        raw_methods = report.get('methods', [])
        need({method_identity(m) for m in raw_methods} == METHODS and len(raw_methods) == len(METHODS),
             f'Jarde report method inventory differs: {key}')
        projections = {tuple(m['identity']): m for m in cell['methods']}
        per_method = []
        for method in raw_methods:
            ident = method_identity(method)
            outcome = method.get('outcome', {})
            rep = outcome.get('report', {})
            projection = projections[ident]
            for field, actual in (('outcome_kind', outcome.get('kind')), ('quality', rep.get('quality')),
                                  ('fallbacks', rep.get('fallbacks')), ('regions', rep.get('regions')),
                                  ('source_map', rep.get('source_map'))):
                need(projection.get(field) == actual, f'{key} {ident}: collector projection {field} differs from JSON')
            need(outcome.get('kind') == 'recovered' and rep.get('quality') == 'structured' and rep.get('representation') == 'java' and rep.get('fallbacks') == [], f'{key} {ident}: not a structured Java result')
            report_text = rep.get('text')
            need(isinstance(report_text, str), f'{key} {ident}: method report text missing')
            audit = audit_source_map(report_text.encode('utf-8'), method, facts[ident],
                                     Path(original_by_profile[profile]['class']['path']).read_bytes(),
                                     f'{key} {ident}')
            per_method.append({'identity': list(ident), 'quality': rep.get('quality'),
                               'outcome_kind': outcome.get('kind'), 'fallbacks': rep.get('fallbacks'),
                               'map': audit})
        map_audits.append({'profile': profile, 'evidence': evidence, 'methods': per_method})
        jarde[key] = {'cell': cell, 'report': report, 'text': source_bytes, 'methods': projections}
    need(set(jarde) == {(p, e) for p in PROFILES for e in EVIDENCE}, 'Jarde cell grid missing')
    default_all = []
    for profile in PROFILES:
        default, all_evidence = jarde[(profile, 'default')], jarde[(profile, 'all')]
        need(default['text'] == all_evidence['text'], f'{profile}: default/all generated text differs')
        parity = []
        for ident in sorted(METHODS):
            a, b = default['methods'][ident], all_evidence['methods'][ident]
            fields = ('outcome_kind', 'quality', 'fallbacks', 'source_map')
            need(all(a.get(field) == b.get(field) for field in fields),
                 f'{profile} {ident}: default/all semantic outcome or map differs')
            parity.append({'identity': list(ident), 'quality': a.get('quality'),
                           'outcome_kind': a.get('outcome_kind'), 'fallbacks': a.get('fallbacks'),
                           'regions_differ': a.get('regions') != b.get('regions')})
        default_all.append({'profile': profile, 'text_equal': True, 'methods': parity})

    # Confirm JADX 1.5.6 reports and that emitted complete source bytes are the compile inputs.
    version = by_label['jadx-version']
    need(version['exit_code'] == 0, 'JADX version command failed')
    version_bytes = command_stream(version, 'stdout', BASE, compare) + command_stream(version, 'stderr', BASE, compare)
    need(b'1.5.6' in version_bytes, 'JADX version output does not identify 1.5.6')
    jadx_sources = {}
    for cell in doc['jadx_cells']:
        profile = cell['profile']; need(profile in PROFILES and profile not in jadx_sources, f'bad JADX profile {profile}')
        cmd = by_label[f'jadx-{profile}']
        need(cmd['exit_code'] == cell['exit_code'] == 0, f'JADX extraction failed {profile}')
        target = original_by_profile[profile]['class']['path']
        need(cmd['argv'] == [doc['jadx']['path'], '--config', 'none', '--threads-count', '1', '--no-res',
                             '--rename-flags', 'none', '-d', str(BASE / 'jadx' / profile), target],
             f'JADX argv mismatch {profile}')
        sources = cell.get('sources', [])
        need(len(sources) == 1, f'{profile}: expected one full source for this single class')
        source = verify_pin(sources[0], f'JADX source {profile}')
        need(source.decode('utf-8', errors='strict'), f'{profile}: JADX source is empty/not UTF-8')
        jadx_sources[profile] = sources[0]
    need(set(jadx_sources) == set(PROFILES), 'JADX extraction profile grid incomplete')

    # Audit every generated source compile and class output independently.
    sources_by_variant = {}
    for cell in doc['source_variants']:
        variant = cell.get('variant')
        need(variant in VARIANTS and variant not in sources_by_variant, f'bad/duplicate generated source variant {variant}')
        pins = cell.get('sources', [])
        need(len(pins) == 1, f'{variant}: incomplete source inventory')
        source_bytes = verify_pin(pins[0], f'{variant} source')
        source_bytes.decode('utf-8', errors='strict')
        if variant.startswith('jarde-'):
            profile, evidence = variant[len('jarde-'):].rsplit('-', 1)
            need(pins[0] == jarde[(profile, evidence)]['cell']['source'], f'{variant}: not the saved complete Jarde source')
        else:
            profile = variant.removeprefix('jadx-')
            need(pins[0] == jadx_sources[profile], f'{variant}: not the emitted JADX full source')
        sources_by_variant[variant] = pins[0]
    need(set(sources_by_variant) == set(VARIANTS), 'generated source variant inventory incomplete')

    compile_keys, compile_class_facts = set(), {}
    for cell in doc['compile_cells']:
        variant, compiler = cell['variant'], cell['compiler']
        key = (variant, compiler)
        need(key not in compile_keys and variant in VARIANTS and compiler in COMPILERS, f'bad/duplicate compile cell {key}')
        compile_keys.add(key)
        label = f'compile-{variant}-{compiler}'
        cmd = by_label[label]
        need(cell['command'] == cmd['index'] and cell['exit_code'] == cmd['exit_code'] == 0,
             f'{key}: generated source compile failed or command binding differs')
        need(cell.get('source_pins') == [sources_by_variant[variant]], f'{key}: compiler source provenance differs')
        argv = cmd['argv']
        flags = (['-source', '8', '-target', '8', '-g'] if compiler == 'javac8' else ['--release', '8', '-g'])
        empty = str(BASE / 'empty-classpath')
        dest_arg = str(BASE / 'rebuilt' / variant / compiler / 'classes')
        exact_argv = [tool_paths[compiler]['javac'], *flags, '-encoding', 'UTF-8', '-proc:none',
                      '-classpath', empty, '-sourcepath', empty, '-d', dest_arg,
                      sources_by_variant[variant]['path']]
        need(argv == exact_argv, f'{key}: javac argv/classpath/source mismatch')
        dest = BASE / 'rebuilt' / variant / compiler / 'classes'
        tree = sorted(p.relative_to(dest).as_posix() for p in dest.rglob('*.class'))
        need(tree == ['cf11/ForConditionRefusals.class'], f'{key}: unexpected generated class tree {tree}')
        pins = [pin(p) for p in sorted(dest.rglob('*.class'))]
        need(pins == cell.get('class_files'), f'{key}: saved class tree pins differ from actual output')
        target = dest / 'cf11/ForConditionRefusals.class'
        need(cell.get('target') == pin(target), f'{key}: target class pin mismatch')
        facts = cell.get('target_facts')
        need(isinstance(facts, dict) and facts.get('valid_class') is True,
             f'{key}: collector did not report valid complete target class')
        parsed = compare_class_facts(target.read_bytes(), target, facts, f'{key} rebuilt target')
        need(abi(parsed) == abi(class_facts['javac8-debug']), f'{key}: ABI/access differs from input class')
        # All compiler inputs are Java 8 variants with the same declared ABI; Code is verified above.
        compile_class_facts[key] = parsed
    need(compile_keys == {(v, c) for v in VARIANTS for c in COMPILERS}, '12 generated compile cells are incomplete')

    # Derive every rebuilt JVM comparison from stdout bytes; do not trust copied booleans.
    runtime_keys, runtime_verdicts = set(), []
    for cell in doc['rebuilt_runtime']:
        variant, compiler, runtime = cell['variant'], cell['compiler'], cell['runtime']
        key = (variant, compiler, runtime)
        need(key not in runtime_keys and variant in VARIANTS and compiler in COMPILERS and runtime in COMPILERS,
             f'bad/duplicate rebuilt runtime cell {key}')
        runtime_keys.add(key)
        label = f'rebuilt-runtime-{variant}-{compiler}-{runtime}'
        cmd = by_label[label]
        need(cell['command'] == cmd['index'] and cell['exit_code'] == cmd['exit_code'] == 0,
             f'{key}: JVM command failed/binding differs')
        argv = cmd['argv']
        dest = str((BASE / 'rebuilt' / variant / compiler / 'classes').resolve())
        need(argv[1:4] == ['-B', str(BASE / Path(doc['runtime_wrapper']['path']).name), '30']
             and argv[4] == tool_paths[runtime]['java'] and argv[5] == '-Xverify:all'
             and argv[6:9] == ['-cp', str((BASE / 'driver-classes').resolve()), 'ForConditionRefusalsDriver']
             and argv[-2:] == [dest, dest], f'{key}: runtime argv/classpath/CodeSource differs')
        stdout = command_stream(cmd, 'stdout', BASE, compare)
        rows = output_rows(stdout, label)
        need(cell.get('stdout') == cmd['streams']['stdout'] and cell.get('stderr') == cmd['streams']['stderr']
             and cell.get('rows') == rows and cell.get('row_count') == 12,
             f'{key}: stored observations/raw pins mismatch')
        equal = stdout == oracle_outputs[0]
        need(cell.get('matches_original_oracle') == equal, f'{key}: copied semantic comparison is not derived from bytes')
        need(equal, f'{key}: rebuilt VM differs from original oracle')
        runtime_verdicts.append({'variant': variant, 'compiler': compiler, 'runtime': runtime,
                                 'rows': len(rows), 'matches_original_oracle': equal})
    need(runtime_keys == {(v, c, r) for v in VARIANTS for c in COMPILERS for r in COMPILERS},
         '24 rebuilt VM runs are incomplete')

    counts = {
        'commands': len(commands), 'raw_streams': sum(len(row['streams']) for row in commands),
        'original_compiles': sum(x['label'].startswith('compile-original-') for x in commands),
        'driver_compiles': sum(x['label'] == 'compile-independent-driver' for x in commands),
        'cli_calls': sum(x['label'].startswith('jarde-') for x in commands),
        'jadx_calls': sum(x['label'].startswith('jadx-') for x in commands),
        'rebuilt_compiles': sum(x['label'].startswith('compile-') and not x['label'].startswith('compile-original-')
                                and x['label'] != 'compile-independent-driver' for x in commands),
        'original_vm_runs': sum(x['label'].startswith('original-runtime-') for x in commands),
        'rebuilt_vm_runs': sum(x['label'].startswith('rebuilt-runtime-') for x in commands),
        'wrong_root_controls': sum(x['label'] == 'driver-wrong-CodeSource-root' for x in commands),
    }
    need(counts['raw_streams'] == 2 * counts['commands'], 'not exactly two raw streams per command')
    need(doc.get('counts_derived_from_commands') == {k: v for k, v in counts.items()
         if k not in ('commands', 'raw_streams', 'wrong_root_controls')},
         'collector command count summary differs from actual labels')

    out.mkdir(parents=True)
    review = {
        'schema': 'cf11-forcondition-refusals-independent-review-v1',
        'status': 'reviewed-structural-and-semantic-evidence',
        'execution': pin(matrix_path), 'parser': pin(PARSER), 'compare_helper': pin(COMPARE),
        'counts_derived_from_raw_command_inventory': counts,
        'original_class_profiles': [{'profile': p, 'class': original_by_profile[p]['class'],
                                     'class_access': class_facts[p]['access'],
                                     'fields': len(class_facts[p]['fields']),
                                     'methods': len(class_facts[p]['methods']),
                                     'frozen_javac23_code_equal': original_by_profile[p].get('frozen_javac23_code_equal')}
                                    for p in PROFILES],
        'original_runtime_rows': [{'profile': c['profile'], 'runtime': c['runtime'], 'row_count': c['row_count']}
                                  for c in doc['original_runtime']],
        'oracle_agreement': True, 'wrong_codesource_control_rejected': True,
        'jarde_maps': map_audits, 'default_all_parity': default_all,
        'jadx_profiles': [{'profile': p, 'source': jadx_sources[p]} for p in PROFILES],
        'rebuilt_runtime_verdicts': runtime_verdicts,
        'all_rebuilt_match_original_oracle': all(x['matches_original_oracle'] for x in runtime_verdicts),
        'source_closure_unchanged': True, 'external_pins_unchanged': True,
        'target_absent_after_capture': True,
        'interpretation': 'This review verifies provenance, physical class facts, complete method source maps, and observed JVM comparisons. It does not itself convert the observations into a production expectation or test acceptance.',
    }
    (out / 'root-review.json').write_text(json.dumps(review, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps({'status': review['status'], 'counts': counts,
                      'all_rebuilt_match_original_oracle': review['all_rebuilt_match_original_oracle'],
                      'review': str(out / 'root-review.json')}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
