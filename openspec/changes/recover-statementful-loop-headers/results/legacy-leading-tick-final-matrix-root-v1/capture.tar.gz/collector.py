#!/usr/bin/env python3
"""Collect the complete ForConditionRefusals original/Jarde/JADX/rebuild oracle matrix.

Prepared only. Run with Python -B after root review; no source is repaired or trimmed.
"""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, re, shutil, sys
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
SOURCE = ROOT / 'tests/fixtures/java8/cf11-for-condition/ForConditionRefusals.java'
SOURCE_SHA256 = 'e49e456fd8e128e8cddc108f3f2a5db1e863b1450a3fb8e9523ff3e19886a454'
FROZEN_CLASS = ROOT / 'tests/fixtures/java8/cf11-for-condition/ForConditionRefusals.class'
FROZEN_CLASS_SHA256 = '9afb4eeeb1558845789c2f4b929d3f6adcac237edb3484a11d4a0b68ddc1619b'
CLI = Path('/private/tmp/jarde-statementful-loop-final-gates-root-v2-20261018/candidate-cli')
CLI_SHA256 = '0bb89f827c1e2b6b0e215d1940299be046a7adc57866389d87e6595ba0295677'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA256 = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA256 = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
DRIVER_SOURCE = Path(__file__).with_name('driver') / 'ForConditionRefusalsDriver.java'
CLASSFILE_HELPER = Path(__file__).with_name('classfile_helpers.py')
EXPECTED_CLASS_ACCESS = 0x0021
EXPECTED_FIELD_ACCESS = 0x0008
EXPECTED_METHOD_ACCESS = {'<init>': 0x0001, 'tick': 0x0008, 'limit': 0x0008,
                          'sumWithLeadingTickAndBreak': 0x0008, 'sumWithAssignedCallBound': 0x0008}
RUNTIME_BOUND = Path('/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
RUNTIME_BOUND_SHA256 = '73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
COMPARE_REL = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA256 = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
CLASSFILE_HELPER_SHA256 = '71da0f189169493a3445c6a1887bb689cf2d122584d32e8af59f00f05aa2374e'
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
INTERNAL_CLASS = 'cf11/ForConditionRefusals'
CLASS_DOT = 'cf11.ForConditionRefusals'
METHODS = {
    ('<init>', '()V'), ('tick', '()V'), ('limit', '()I'),
    ('sumWithLeadingTickAndBreak', '()I'), ('sumWithAssignedCallBound', '()I'),
}
FIELDS = {('counter', 'I'), ('limit', 'I'), ('limitCalls', 'I')}
PROFILES = ('javac8-debug', 'javac23-debug')
EVIDENCE = ('default', 'all')
REBUILT_SOURCES = ('jarde-javac8-debug-default', 'jarde-javac8-debug-all',
                   'jarde-javac23-debug-default', 'jarde-javac23-debug-all',
                   'jadx-javac8-debug', 'jadx-javac23-debug')


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_pin(path: Path) -> dict:
    path = Path(path).resolve(strict=True)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def method_code(facts: dict) -> dict:
    return {(m['name'], m['descriptor']): m['code'] for m in facts['methods']}


def output_rows(raw: bytes, label: str) -> list[dict]:
    lines = raw.decode('utf-8', errors='strict').splitlines()
    pattern = re.compile(r'limit=(-?\d+) call=(leading-1|assigned|leading-2) return=(-?\d+) counter=(\d+) limitCalls=(\d+)')
    rows = []
    for line in lines:
        match = pattern.fullmatch(line)
        if match is None:
            raise ValueError(f'{label}: malformed driver line: {line!r}')
        rows.append({'limit': int(match.group(1)), 'call': match.group(2), 'return': int(match.group(3)),
                     'counter': int(match.group(4)), 'limit_calls': int(match.group(5)), 'raw': line})
    expected_order = [(limit, call) for limit in (-1, 0, 1, 4)
                      for call in ('leading-1', 'assigned', 'leading-2')]
    if [(r['limit'], r['call']) for r in rows] != expected_order:
        raise ValueError(f'{label}: expected 12 ordered calls, observed {len(rows)} rows/order mismatch')
    return rows


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    root, out = args.root.resolve(strict=True), args.out.resolve()
    if root != ROOT.resolve(): raise SystemExit(f'workspace differs from pinned root: {root}')
    if out.exists(): raise SystemExit(f'refusing existing output: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink(): raise SystemExit('target must be absent before collection')
    if sha(SOURCE.read_bytes()) != SOURCE_SHA256: raise SystemExit('complete fixture source changed from pin')
    if sha(FROZEN_CLASS.read_bytes()) != FROZEN_CLASS_SHA256: raise SystemExit('frozen javac23 class changed from pin')
    if sha(CLI.read_bytes()) != CLI_SHA256: raise SystemExit('selected CLI pin mismatch')
    if sha(JADX.read_bytes()) != JADX_SHA256 or sha(JADX_JAR.read_bytes()) != JADX_JAR_SHA256:
        raise SystemExit('JADX executable/JAR pin mismatch')
    if sha(RUNTIME_BOUND.read_bytes()) != RUNTIME_BOUND_SHA256: raise SystemExit('runtime wrapper pin mismatch')

    compare_path = root / COMPARE_REL; guard_path = root / GUARD_REL; scanner_path = root / SCANNER_REL
    if hashlib.sha256(compare_path.read_bytes()).hexdigest() != COMPARE_SHA256:
        raise SystemExit('comparison helper pin mismatch')
    if hashlib.sha256(CLASSFILE_HELPER.read_bytes()).hexdigest() != CLASSFILE_HELPER_SHA256:
        raise SystemExit('independent classfile helper pin mismatch')
    compare = load_module(compare_path, 'forcondition_compare')
    classfile_helper = load_module(CLASSFILE_HELPER, 'forcondition_classfile_helper')
    if compare.sha(guard_path) != GUARD_SHA256 or compare.sha(scanner_path) != SCANNER_SHA256:
        raise SystemExit('guard/scanner source pin mismatch')
    guard = load_module(guard_path, 'forcondition_guard')
    scanner = load_module(scanner_path, 'forcondition_scanner')
    jdks, jdk_manifest_record = compare.configured_jdks(root / JDK_MANIFEST_REL, JDK_MANIFEST_SHA256)

    out.mkdir(parents=True); raw_dir = out / 'raw'; raw_dir.mkdir()
    guard.ROOT = root; guard.OUT = raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = lambda path: compare.pin(path)
    guard.expected_test_summaries = lambda index, stdout_bytes: None
    if shutil.disk_usage(root).free < 5 * 1024**3: raise SystemExit('5 GiB free-space guard failed')

    source_copy = out / 'source/ForConditionRefusals.java'; source_copy.parent.mkdir()
    shutil.copy2(SOURCE, source_copy)
    driver_copy = out / 'driver/ForConditionRefusalsDriver.java'; driver_copy.parent.mkdir()
    shutil.copy2(DRIVER_SOURCE, driver_copy)
    empty = out / 'empty-classpath'; empty.mkdir()
    runtime_copy = out / RUNTIME_BOUND.name; shutil.copy2(RUNTIME_BOUND, runtime_copy)
    source_before = compare.source_closure(root)
    tool_pins = {f'{leg}_{name}': compare.pin(path) for leg, config in jdks.items() for name, path in config['tools'].items()}
    external_before = {
        'source': compare.pin(SOURCE), 'source_copy': compare.pin(source_copy),
        'frozen_javac23_class': compare.pin(FROZEN_CLASS), 'driver': compare.pin(DRIVER_SOURCE),
        'driver_copy': compare.pin(driver_copy), 'cli': compare.pin(CLI), 'jadx': compare.pin(JADX),
        'jadx_jar': compare.pin(JADX_JAR), 'runtime_wrapper': compare.pin(RUNTIME_BOUND),
        'runtime_wrapper_copy': compare.pin(runtime_copy), 'jdk_manifest': compare.pin(root / JDK_MANIFEST_REL),
        'comparison_helper': compare.pin(compare_path), 'classfile_helper': compare.pin(CLASSFILE_HELPER),
        'guard': compare.pin(guard_path), 'scanner': compare.pin(scanner_path),
        'jdk_tools': tool_pins,
    }
    report = {
        'schema': 'cf11-forcondition-refusals-full-source-baseline-v1', 'status': 'running',
        'root': str(root), 'output': str(out), 'cli': compare.pin(CLI), 'jadx': compare.pin(JADX),
        'jadx_jar': compare.pin(JADX_JAR), 'jdk_manifest': jdk_manifest_record,
        'source': compare.pin(SOURCE), 'frozen_javac23_class': compare.pin(FROZEN_CLASS),
        'driver_source': compare.pin(DRIVER_SOURCE), 'runtime_wrapper': compare.pin(RUNTIME_BOUND),
        'inputs_before': external_before, 'source_pins_before': source_before,
        'commands': [], 'original_profiles': [], 'driver_classes': [], 'original_runtime': [],
        'original_oracle': None, 'jarde_cells': [], 'jadx_cells': [], 'source_variants': [],
        'compile_cells': [], 'rebuilt_runtime': [], 'wrong_root_control': None,
        'expected_method_identities': [list(x) for x in sorted(METHODS)],
        'expected_fields': [list(x) for x in sorted(FIELDS)],
        'runtime_case_limits': [-1, 0, 1, 4], 'runtime_rows_per_run_required': 12,
        'notes': ['Complete ForConditionRefusals.java is copied byte-for-byte; no method/source trimming.',
                  'Original observations reset static fields for each limit then invoke leading, assigned, leading in order.',
                  'Driver is the only application classpath entry; target is loaded with a parentless URLClassLoader and checked by CodeSource.',
                  'No return/counter/limitCalls oracle values are hard-coded; the four original dual-VM runs create it.',
                  'Compilation failures remain rows and have no runtime attempt; generated sources are never repaired.'],
    }
    compare.write_json(out / 'execution.json', report)
    rows = report['commands']

    def command(argv, label, leg='javac23'):
        if (root / 'target').exists(): raise RuntimeError('workspace target appeared during baseline collection')
        env = compare.clean_env(dict(os.environ), jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(rows) + 1, [str(v) for v in argv], env)
        row['label'] = label; row['tool_leg'] = leg; rows.append(row)
        compare.write_json(out / 'execution.json', report)
        if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        return row

    def artifact(row, channel='stdout'):
        return compare.command_artifact(row, channel)

    def validate_target(path: Path, label: str):
        raw = path.read_bytes()
        facts = compare.parse_class(path)
        header = classfile_helper.parse_class_file(raw)
        identities = set(compare.class_methods(facts))
        fields = {(x[0], x[1]) for x in facts['fields']}
        field_flags = {(x[0], x[1]): x[2] for x in facts['fields']}
        method_flags = {(m['name'], m['descriptor']): m['access'] for m in facts['methods']}
        helper_methods = {(m['name'], m['descriptor']): m for m in header['methods']}
        code_matches = identities == set(helper_methods) and all(
            facts_row['code'] is not None and helper_methods[key]['code'] is not None
            and facts_row['code']['code_hex'] == helper_methods[key]['code']['code_hex']
            and facts_row['code']['bcis'] == helper_methods[key]['code']['bcis']
            for key, facts_row in { (m['name'],m['descriptor']):m for m in facts['methods'] }.items())
        valid = facts['class_name'] == 'cf11/ForConditionRefusals' and facts['major'] == 52 \
            and header['class_name'] == facts['class_name'] and header['major'] == facts['major'] \
            and header['access'] == EXPECTED_CLASS_ACCESS and identities == METHODS and fields == FIELDS \
            and all(field_flags[key] == EXPECTED_FIELD_ACCESS for key in FIELDS) \
            and all(method_flags[key] == EXPECTED_METHOD_ACCESS[key[0]] for key in METHODS) \
            and code_matches and all(m['code'] is not None for m in facts['methods'])
        return facts, {'label': label, 'valid_class': valid, 'class_name': facts['class_name'],
                       'major': facts['major'], 'class_access': header['access'],
                       'fields': [{'name':x[0],'descriptor':x[1],'access':x[2]} for x in facts['fields']],
                       'methods': facts['methods'], 'method_identities': sorted([list(x) for x in identities]),
                       'method_access': [{'name':m['name'],'descriptor':m['descriptor'],'access':m['access']} for m in facts['methods']],
                       'method_local_bcis': [{'name':m['name'],'descriptor':m['descriptor'],'bcis':m['code']['bcis'] if m['code'] else None} for m in facts['methods']],
                       'independent_decoder_code_and_bci_agreement': code_matches,
                       'all_methods_have_code': all(m['code'] is not None for m in facts['methods'])}

    def run_driver(target_root: Path, expected_root: Path, leg: str, label: str):
        return command([sys.executable, '-B', runtime_copy, '30', jdks[leg]['tools']['java'], '-Xverify:all',
                        '-cp', out / 'driver-classes', 'ForConditionRefusalsDriver', target_root, expected_root], label, leg)

    try:
        # Compile the entire, unchanged Java source with both pinned compilers.
        original_code = {}
        for profile, leg, flags in (('javac8-debug', 'javac8', ['-source','8','-target','8','-g']),
                                    ('javac23-debug', 'javac23', ['--release','8','-g'])):
            dest = out / 'original' / profile / 'classes'; dest.mkdir(parents=True)
            compile_row = command([jdks[leg]['tools']['javac'], *flags, '-encoding','UTF-8','-proc:none',
                                   '-classpath',empty,'-sourcepath',empty,'-d',dest,source_copy],
                                  'compile-original-' + profile, leg)
            target = dest / 'cf11/ForConditionRefusals.class'
            row = {'profile': profile, 'javac_leg': leg, 'command': compile_row['index'],
                   'exit_code': compile_row['exit_code'], 'target_exists': target.is_file()}
            if compile_row['exit_code'] == 0 and target.is_file():
                facts, projection = validate_target(target, profile)
                row.update({'class': compare.pin(target), 'facts': projection})
                original_code[profile] = method_code(facts)
                if not projection['valid_class']: raise RuntimeError(f'{profile}: original class inventory/Code mismatch')
                if leg == 'javac23':
                    frozen_facts = compare.parse_class(FROZEN_CLASS)
                    frozen_code = method_code(frozen_facts)
                    same_code = original_code[profile] == frozen_code
                    row['frozen_javac23_code_equal'] = same_code
                    row['frozen_code_comparison'] = {name + desc: {'equal': original_code[profile].get((name,desc)) == frozen_code.get((name,desc)),
                        'rebuilt': original_code[profile].get((name,desc)), 'frozen': frozen_code.get((name,desc))}
                        for name,desc in sorted(METHODS)}
                    if not same_code: raise RuntimeError('new javac23 original Code differs from frozen class; raw facts retained')
            report['original_profiles'].append(row); compare.write_json(out / 'execution.json', report)
            if compile_row['exit_code'] != 0 or not target.is_file():
                raise RuntimeError(f'{profile}: complete original source compile failed; raw compiler output retained')

        # Compile only the independent driver. Target classes never enter this classpath.
        driver_classes = out / 'driver-classes'; driver_classes.mkdir()
        driver_compile = command([jdks['javac8']['tools']['javac'], '-source','8','-target','8','-g',
                                  '-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,
                                  '-d',driver_classes,driver_copy], 'compile-independent-driver', 'javac8')
        if driver_compile['exit_code'] != 0: raise RuntimeError('independent driver compilation failed')
        report['driver_classes'] = [compare.pin(p) for p in sorted(driver_classes.rglob('*.class'))]
        if len(report['driver_classes']) != 1: raise RuntimeError('driver-only class output inventory is not singular')

        # The original bytecode defines the oracle: every profile runs on both VMs.
        original_outputs=[]
        for profile in report['original_profiles']:
            target_root=Path(profile['class']['path']).parent.parent
            for runtime in ('javac8','javac23'):
                row=run_driver(target_root,target_root,runtime,f'original-runtime-{profile["profile"]}-{runtime}')
                stdout=artifact(row); parsed=output_rows(stdout,row['label']) if row['exit_code']==0 else []
                cell={'profile':profile['profile'],'runtime':runtime,'command':row['index'],'exit_code':row['exit_code'],
                      'classpath':[str(driver_classes)],'target_root':str(target_root),'stdout':compare.pin(Path(row['streams']['stdout']['path'])),
                      'stderr':compare.pin(Path(row['streams']['stderr']['path'])),'rows':parsed,'row_count':len(parsed)}
                report['original_runtime'].append(cell)
                if row['exit_code']==0 and len(parsed)==12: original_outputs.append(stdout)
                compare.write_json(out/'execution.json',report)
        if len(original_outputs)!=4 or len(set(original_outputs))!=1:
            raise RuntimeError('four original profile/JVM observations did not all succeed and agree byte-for-byte')
        oracle=out/'original-oracle.stdout';oracle.write_bytes(original_outputs[0])
        report['original_oracle']=compare.pin(oracle);report['original_runtime_agreement']=True
        report['original_oracle_rows']=output_rows(original_outputs[0],'original oracle')

        wrong=run_driver(Path(report['original_profiles'][1]['class']['path']).parent.parent,empty,'javac23','driver-wrong-CodeSource-root')
        err=artifact(wrong,'stderr')
        report['wrong_root_control']={'command':wrong['index'],'exit_code':wrong['exit_code'],
            'rejected':wrong['exit_code']!=0 and b'target loaded from' in err}
        if not report['wrong_root_control']['rejected']: raise RuntimeError('wrong CodeSource root control was not rejected')

        # Generate the four Jarde outputs from both original compiler profiles.
        source_by_variant={}
        for profile in report['original_profiles']:
            target=Path(profile['class']['path'])
            for evidence in EVIDENCE:
                argv=[CLI,'class-source','--input',target,'--class',INTERNAL_CLASS,'--policy','single-class','--release','8','--format','json']
                if evidence=='all': argv += ['--evidence','all']
                row=command(argv,f'jarde-{profile["profile"]}-{evidence}')
                raw=artifact(row)
                dest=out/'jarde'/profile['profile']/evidence;dest.mkdir(parents=True)
                report_path=dest/'report.json';report_path.write_bytes(raw)
                cell={'profile':profile['profile'],'evidence':evidence,'command':row['index'],'input':compare.pin(target),
                      'exit_code':row['exit_code'],'report':compare.pin(report_path)}
                try:
                    doc=json.loads(raw);text=doc.get('text')
                    if isinstance(text,str):
                        java=dest/'ForConditionRefusals.java';java.write_bytes(text.encode('utf-8'))
                        cell['source']=compare.pin(java);source_by_variant[f'jarde-{profile["profile"]}-{evidence}']=[java]
                    methods=[]
                    for method in doc.get('methods',[]):
                        ident=method.get('item',{}).get('identity',{});name=bytes(ident.get('name',[])).decode('utf-8');desc=bytes(ident.get('descriptor',[])).decode('utf-8')
                        outcome=method.get('outcome',{});rep=outcome.get('report',{})
                        methods.append({'identity':[name,desc],'outcome_kind':outcome.get('kind'),'quality':rep.get('quality'),
                                        'fallbacks':rep.get('fallbacks'),'regions':rep.get('regions'),'source_map':rep.get('source_map')})
                    cell['methods']=methods
                    cell['method_inventory_matches']=set(tuple(m['identity']) for m in methods)==METHODS
                except (ValueError,TypeError) as exc: cell['json_parse_error']=str(exc)
                report['jarde_cells'].append(cell);compare.write_json(out/'execution.json',report)

        # Generate full-source JADX output per original input profile.
        version=command([JADX,'--version'],'jadx-version')
        version_bytes=artifact(version)+artifact(version,'stderr')
        if version['exit_code']!=0 or b'1.5.6' not in version_bytes: raise RuntimeError('JADX version check failed')
        for profile in report['original_profiles']:
            target=Path(profile['class']['path']);dest=out/'jadx'/profile['profile']
            row=command([JADX,'--config','none','--threads-count','1','--no-res','--rename-flags','none','-d',dest,target],
                        'jadx-'+profile['profile'])
            sources=sorted(dest.rglob('*.java')) if dest.exists() else []
            cell={'profile':profile['profile'],'command':row['index'],'exit_code':row['exit_code'],
                  'sources':[compare.pin(p) for p in sources]}
            report['jadx_cells'].append(cell)
            if len(sources)==1 and row['exit_code']==0:
                source_by_variant['jadx-'+profile['profile']]=sources
            compare.write_json(out/'execution.json',report)

        # Recompile every generated full source with both compilers; run only successful class files.
        compile_flags={'javac8':['-source','8','-target','8','-g'],'javac23':['--release','8','-g']}
        for variant in REBUILT_SOURCES:
            sources=source_by_variant.get(variant)
            if not sources:
                report['source_variants'].append({'variant':variant,'status':'no complete source available','sources':[]})
                continue
            source_facts={'variant':variant,'status':'source captured','sources':[compare.pin(p) for p in sources]}
            report['source_variants'].append(source_facts)
            for compiler in ('javac8','javac23'):
                dest=out/'rebuilt'/variant/compiler/'classes';dest.mkdir(parents=True)
                cmd=[jdks[compiler]['tools']['javac'],*compile_flags[compiler],'-encoding','UTF-8','-proc:none',
                     '-classpath',empty,'-sourcepath',empty,'-d',dest,*sources]
                row=command(cmd,f'compile-{variant}-{compiler}',compiler)
                classfiles=sorted(dest.rglob('*.class'))
                cell={'variant':variant,'compiler':compiler,'command':row['index'],'exit_code':row['exit_code'],
                      'source_pins':[compare.pin(p) for p in sources],'class_files':[compare.pin(p) for p in classfiles],
                      'runtime_commands':[]}
                if row['exit_code']==0:
                    target=dest/'cf11/ForConditionRefusals.class'
                    if target.is_file():
                        facts,projection=validate_target(target,f'{variant}-{compiler}')
                        cell['target_facts']=projection;cell['target']=compare.pin(target)
                        if not projection['valid_class']:
                            cell['class_inventory_mismatch']=True
                    else:
                        cell['target_missing']=True
                    if target.is_file() and not cell.get('class_inventory_mismatch'):
                        for runtime in ('javac8','javac23'):
                            rr=run_driver(dest,dest,runtime,f'rebuilt-runtime-{variant}-{compiler}-{runtime}')
                            outbytes=artifact(rr);errbytes=artifact(rr,'stderr')
                            parsed=output_rows(outbytes,rr['label']) if rr['exit_code']==0 else []
                            equal=rr['exit_code']==0 and outbytes==original_outputs[0]
                            runtime_cell={'runtime':runtime,'command':rr['index'],'exit_code':rr['exit_code'],
                                'stdout':compare.pin(Path(rr['streams']['stdout']['path'])),'stderr':compare.pin(Path(rr['streams']['stderr']['path'])),
                                'rows':parsed,'row_count':len(parsed),'matches_original_oracle':equal}
                            cell['runtime_commands'].append(runtime_cell)
                            report['rebuilt_runtime'].append({'variant':variant,'compiler':compiler,**runtime_cell})
                            compare.write_json(out/'execution.json',report)
                report['compile_cells'].append(cell);compare.write_json(out/'execution.json',report)

        report['command_count'] = len(rows)
        report['raw_stream_count'] = 2 * len(rows)
        report['counts_derived_from_commands'] = {
            'original_compiles':sum(r['label'].startswith('compile-original-') for r in rows),
            'driver_compiles':sum(r['label']=='compile-independent-driver' for r in rows),
            'cli_calls':sum(r['label'].startswith('jarde-') for r in rows),
            'jadx_calls':sum(r['label'].startswith('jadx-') for r in rows),
            'rebuilt_compiles':sum(r['label'].startswith('compile-jarde-') or r['label'].startswith('compile-jadx-') for r in rows),
            'rebuilt_vm_runs':sum(r['label'].startswith('rebuilt-runtime-') for r in rows),
            'original_vm_runs':sum(r['label'].startswith('original-runtime-') for r in rows),
        }
        report['inputs_after']={
            'source':compare.pin(SOURCE),'source_copy':compare.pin(source_copy),'frozen_javac23_class':compare.pin(FROZEN_CLASS),
            'driver':compare.pin(DRIVER_SOURCE),'driver_copy':compare.pin(driver_copy),'cli':compare.pin(CLI),
            'jadx':compare.pin(JADX),'jadx_jar':compare.pin(JADX_JAR),'runtime_wrapper':compare.pin(RUNTIME_BOUND),
            'runtime_wrapper_copy':compare.pin(runtime_copy),'jdk_manifest':compare.pin(root/JDK_MANIFEST_REL),
            'comparison_helper':compare.pin(compare_path),'classfile_helper':compare.pin(CLASSFILE_HELPER),
            'guard':compare.pin(guard_path),'scanner':compare.pin(scanner_path),
            'jdk_tools':{f'{leg}_{name}':compare.pin(path) for leg,config in jdks.items() for name,path in config['tools'].items()},
        }
        if report['inputs_after'] != external_before: raise RuntimeError('input/tool pins changed during capture')
        report['source_pins_after']=compare.source_closure(root)
        if report['source_pins_after'] != source_before: raise RuntimeError('workspace source closure changed during capture')
        report['target_absent_after']=not (root/'target').exists() and not (root/'target').is_symlink()
        if not report['target_absent_after']: raise RuntimeError('target exists after capture')
        report['status']='captured-pending-independent-review'
    except BaseException as exc:
        report['status']='failed';report['error']=str(exc)
        raise
    finally:
        try:
            report['inputs_after_finally']={
                'source':compare.pin(SOURCE),'source_copy':compare.pin(source_copy),'frozen_javac23_class':compare.pin(FROZEN_CLASS),
                'driver':compare.pin(DRIVER_SOURCE),'driver_copy':compare.pin(driver_copy),'cli':compare.pin(CLI),
                'jadx':compare.pin(JADX),'jadx_jar':compare.pin(JADX_JAR),'runtime_wrapper':compare.pin(RUNTIME_BOUND),
                'runtime_wrapper_copy':compare.pin(runtime_copy),'jdk_manifest':compare.pin(root/JDK_MANIFEST_REL),
                'comparison_helper':compare.pin(compare_path),'classfile_helper':compare.pin(CLASSFILE_HELPER),
            'guard':compare.pin(guard_path),'scanner':compare.pin(scanner_path),
                'jdk_tools':{f'{leg}_{name}':compare.pin(path) for leg,config in jdks.items() for name,path in config['tools'].items()},
            }
            report['source_pins_after_finally']=compare.source_closure(root)
            report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
        except BaseException as post_error:
            report['status']='failed';report['final_guard_error']=repr(post_error)
        report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out/'execution.json',report)
        shutil.copy2(__file__,out/'collector.py')
        print(json.dumps({'status':report['status'],'commands':len(rows),'raw_streams':2*len(rows),
                          'rebuilt_compiles':report.get('counts_derived_from_commands',{}).get('rebuilt_compiles'),
                          'rebuilt_vm_runs':report.get('counts_derived_from_commands',{}).get('rebuilt_vm_runs'),
                          'error':report.get('error')}))

if __name__ == '__main__':
    raise SystemExit(main())
