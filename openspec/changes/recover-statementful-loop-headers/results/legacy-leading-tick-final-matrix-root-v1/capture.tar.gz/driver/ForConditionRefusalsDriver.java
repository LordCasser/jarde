import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.CodeSource;

public final class ForConditionRefusalsDriver {
    private static final String TARGET = "cf11.ForConditionRefusals";
    private static final int[] LIMITS = {-1, 0, 1, 4};

    private ForConditionRefusalsDriver() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            throw new IllegalArgumentException("usage: ForConditionRefusalsDriver <target-class-root> <expected-class-root>");
        }
        File actualRoot = new File(args[0]).getCanonicalFile();
        File expectedRoot = new File(args[1]).getCanonicalFile();
        URLClassLoader targetLoader = new URLClassLoader(new URL[] {actualRoot.toURI().toURL()}, null);
        try {
            Class<?> target = Class.forName(TARGET, true, targetLoader);
            CodeSource source = target.getProtectionDomain().getCodeSource();
            if (source == null || source.getLocation() == null) {
                throw new AssertionError("target has no CodeSource: " + TARGET);
            }
            File loadedRoot = new File(new URI(source.getLocation().toString())).getCanonicalFile();
            if (!loadedRoot.equals(expectedRoot)) {
                throw new AssertionError("target loaded from " + loadedRoot + ", expected " + expectedRoot);
            }
            if (target.getClassLoader() != targetLoader) {
                throw new AssertionError("target was not defined by the parentless target loader");
            }

            Field counter = field(target, "counter");
            Field limit = field(target, "limit");
            Field limitCalls = field(target, "limitCalls");
            Method leading = method(target, "sumWithLeadingTickAndBreak");
            Method assigned = method(target, "sumWithAssignedCallBound");
            for (int value : LIMITS) {
                counter.setInt(null, 0);
                limitCalls.setInt(null, 0);
                limit.setInt(null, value);
                emit(value, "leading-1", invoke(leading), counter, limitCalls);
                emit(value, "assigned", invoke(assigned), counter, limitCalls);
                emit(value, "leading-2", invoke(leading), counter, limitCalls);
            }
        } finally {
            targetLoader.close();
        }
    }

    private static Field field(Class<?> owner, String name) throws Exception {
        Field result = owner.getDeclaredField(name);
        result.setAccessible(true);
        return result;
    }

    private static Method method(Class<?> owner, String name) throws Exception {
        Method result = owner.getDeclaredMethod(name);
        result.setAccessible(true);
        if (result.getReturnType() != int.class || result.getParameterTypes().length != 0) {
            throw new AssertionError("unexpected method shape: " + name);
        }
        return result;
    }

    private static int invoke(Method method) throws Exception {
        Object value = method.invoke(null);
        if (!(value instanceof Integer)) {
            throw new AssertionError("method did not return int: " + method.getName());
        }
        return ((Integer) value).intValue();
    }

    private static void emit(int limit, String call, int result, Field counter, Field limitCalls) throws Exception {
        System.out.println("limit=" + limit + " call=" + call + " return=" + result
                + " counter=" + counter.getInt(null) + " limitCalls=" + limitCalls.getInt(null));
    }
}
