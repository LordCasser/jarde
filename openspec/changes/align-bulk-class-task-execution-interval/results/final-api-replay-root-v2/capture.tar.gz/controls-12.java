// jarde: presentation of `typedforeach/TypedListForEachCases` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package typedforeach;

public class TypedListForEachCases extends java.lang.Object {
    public static java.lang.Object seen;

    public static java.lang.Object after;

    public TypedListForEachCases() {
        // @method <init>()V
        // @declaration a constructor of `typedforeach.TypedListForEachCases`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static void strings(java.util.List<java.lang.String> arg0) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method strings(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
                    java.lang.String local1;
                    local1 = "before";
                    typedforeach.TypedListForEachCases.seen = local1;
                    for (java.lang.String iteratorElement24 : arg0) {
                        local1 = iteratorElement24;
                        typedforeach.TypedListForEachCases.seen = local1;
                    }
                    typedforeach.TypedListForEachCases.after = local1;
                    return;
    }

    public static void integers(java.util.List<java.lang.Integer> arg0) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/Integer;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method integers(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
                    Object local1;
                    local1 = null;
                    typedforeach.TypedListForEachCases.seen = local1;
                    for (java.lang.Integer iteratorElement23 : arg0) {
                        local1 = iteratorElement23;
                        typedforeach.TypedListForEachCases.seen = local1;
                    }
                    typedforeach.TypedListForEachCases.after = local1;
                    return;
    }

    public static void raw(java.util.List arg0) {
        // @method raw(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.lang.String local1;
        local1 = "before";
        typedforeach.TypedListForEachCases.seen = local1;
        for (java.lang.Object iteratorElement24 : arg0) {
            local1 = (java.lang.String) iteratorElement24;
            typedforeach.TypedListForEachCases.seen = local1;
        }
        typedforeach.TypedListForEachCases.after = local1;
        return;
    }

    public static void mismatch(java.util.List<java.lang.String> arg0) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method mismatch(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        Object local1;
        local1 = null;
        typedforeach.TypedListForEachCases.seen = local1;
        for (java.lang.Object iteratorElement23 : arg0) {
            local1 = (java.lang.Integer) iteratorElement23;
            typedforeach.TypedListForEachCases.seen = local1;
        }
        typedforeach.TypedListForEachCases.after = local1;
        return;
    }

    public static void declared(java.util.List<java.lang.String> arg0) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method declared(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
                    for (java.lang.String iteratorElement17 : arg0) {
                        java.lang.String local2 = iteratorElement17;
                        typedforeach.TypedListForEachCases.seen = local2;
                    }
                    return;
    }
}
