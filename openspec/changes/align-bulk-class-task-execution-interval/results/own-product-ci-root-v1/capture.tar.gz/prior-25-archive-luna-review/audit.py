from __future__ import annotations
import importlib.util, json, sys, traceback
from pathlib import Path
sys.dont_write_bytecode = True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
BASE=Path('/private/tmp/jarde-prefixed-retry-all-archives-luna-v1-20261018/audit_archives.py')
AREAS=[
 ('typed',ROOT/'openspec/changes/recover-typed-list-foreach-elements/results'),
 ('bulk',ROOT/'openspec/changes/align-bulk-class-task-execution-interval/results'),
 ('evidence',ROOT/'openspec/evidence/java-syntax-2026-10-18/cf11-foreach-original-bindings-analysis-root-v1'),
]
spec=importlib.util.spec_from_file_location('existing_archive_audit',BASE)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
entries=[]; errors=[]; discovered=[]
for group, directory in AREAS:
    paths=sorted(directory.glob('*/capture.tar.gz')) if group!='evidence' else sorted(directory.glob('capture.tar.gz'))
    for path in paths:
        discovered.append((group,path))
        try:
            result=mod.audit_one(path)
            result['group']=group
            entries.append(result)
        except Exception as exc:
            errors.append({'group':group,'archive':str(path),'error':f'{type(exc).__name__}: {exc}'})
report={
 'schema':'typed-foreach-bulk-native-capture-integrity-audit-v1',
 'status':'passed' if discovered and not errors else 'failed',
 'scope':[{'group':name,'directory':str(path)} for name,path in AREAS],
 'archive_count_discovered':len(discovered),
 'archive_count_verified':len(entries),
 'error_count':len(errors),
 'archives':entries,
 'errors':errors,
 'limitations':['Integrity only: adjacent capture-review pins, embedded manifest member set, member byte counts and SHA-256 values. This is not a CI or product-semantics audit.','No archive was extracted to disk; members were streamed by the existing audit_one helper.']
}
out=Path('/private/tmp/jarde-typed-foreach-native-archives-luna-v1-20261018/archive-audit.json')
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':report['status'],'discovered':len(discovered),'verified':len(entries),'errors':errors,'output':str(out)},ensure_ascii=False))
