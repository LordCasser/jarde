# Capture archive integrity audit

Status: **passed**. Dynamically discovered and independently reopened 25/25 archives: 15 typed-change, 9 bulk-change, and 1 evidence archive. Errors: 0.

For every archive, the JSON report records the archive byte count and SHA-256, adjacent `capture-review.json` verification, embedded manifest SHA-256, exact member count, and each member path, byte count, and SHA-256. The reused `audit_one` helper streamed each tar member and verified safe unique regular paths, the exact embedded-manifest/member set, and every manifest digest. No extraction was performed.

Aggregate: 2283 tar members and 14631218 compressed archive bytes. This report covers archive integrity only; it makes no CI or product-semantics claim.

Full machine-readable results: `archive-audit.json`.
