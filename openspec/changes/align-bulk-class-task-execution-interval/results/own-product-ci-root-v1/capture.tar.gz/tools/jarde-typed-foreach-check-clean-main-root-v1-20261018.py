#!/usr/bin/env python3
import argparse,datetime,hashlib,json,stat,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
PRODUCT='e69a3494c8fcd0ff4783be1e9ff71499a730adde'
BINDING=Path('/private/tmp/jarde-typed-foreach-workspace-acceptance-root-v2-20261018/product-source-binding.json')
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def pin(p):
    p=Path(p).resolve(strict=True);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
a=argparse.ArgumentParser();a.add_argument('--out',type=Path,required=True);args=a.parse_args();out=args.out.resolve()
need(not out.exists(),'fresh output required');out.mkdir(parents=True)
r={'status':'checking','product':PRODUCT,'checker':pin(__file__),'source_binding':pin(BINDING),'commands':[]}
def cmd(argv):
    i=len(r['commands'])+1;so=out/f'{i:02d}.stdout.raw';se=out/f'{i:02d}.stderr.raw'
    row={'argv':argv,'cwd':str(ROOT),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with so.open('xb') as f,se.open('xb') as g:row['exit_code']=subprocess.run(argv,cwd=ROOT,stdout=f,stderr=g).returncode
    row['streams']={'stdout':pin(so),'stderr':pin(se)};r['commands'].append(row)
    need(row['exit_code']==0,f'failed git command {argv}');return so.read_text().strip()
try:
    head=cmd(['git','rev-parse','HEAD']);r['head']=head
    need(cmd(['git','branch','--show-current'])=='main','current branch is not main')
    need(cmd(['git','status','--porcelain=v1','--untracked-files=normal'])=='','workspace is dirty')
    need(cmd(['git','rev-parse','origin/main'])==head,'origin/main differs from HEAD')
    remote=cmd(['git','ls-remote','origin','refs/heads/main']).split()
    need(remote==[head,'refs/heads/main'],'actual remote main differs from HEAD')
    need(cmd(['git','for-each-ref','--format=%(refname)','refs/heads'])=='refs/heads/main','extra local branches remain')
    cmd(['git','merge-base','--is-ancestor',PRODUCT,head])
    need(cmd(['git','diff','--name-only',PRODUCT,head,'--','src','crates','tests','.github','Cargo.toml','Cargo.lock'])=='','post-product code change')
    worktrees=cmd(['git','worktree','list','--porcelain']);aux=[]
    for block in worktrees.split('\n\n'):
        lines=block.splitlines()
        if not lines:continue
        path=Path(lines[0].removeprefix('worktree '))
        if path==ROOT:continue
        need('detached' in lines,f'auxiliary checkout still occupies a branch: {path}')
        need(cmd(['git','-C',str(path),'status','--porcelain=v1','--untracked-files=normal'])=='',f'auxiliary checkout has remaining changes: {path}')
        old=next(line[5:] for line in lines if line.startswith('HEAD '))
        cmd(['git','merge-base','--is-ancestor',old,head])
        aux.append({'path':str(path),'head':old,'detached':True,'clean':True,'ancestor_of_main':True,'target_exists':(path/'target').exists()})
    b=json.loads(BINDING.read_bytes());need(b['product_revision']==PRODUCT,'source binding product mismatch')
    for row in b['bindings']:
        p=ROOT/row['path'];need(p.is_file() and not p.is_symlink(),f'missing/unsafe source {p}')
        actual=pin(p);mode='100755' if p.stat().st_mode & 0o111 else '100644'
        need(actual['sha256']==row['sha256'] and actual['bytes']==row['bytes'] and mode==row['mode'],f'final source differs {p}')
    need(pin(b['cli']['path'])==b['cli'],'final CLI changed')
    need(not (ROOT/'target').exists() and not (ROOT/'target').is_symlink(),'repository target exists')
    r.update({'status':'accepted_clean_main','actual_remote_equals_head':True,'only_main_local_branch':True,'target_absent':True,'auxiliary_checkouts':aux,'source_files_rechecked':len(b['bindings']),'cli':b['cli']})
finally:
    r['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':r['status'],'head':r['head'],'auxiliary_checkouts':len(r.get('auxiliary_checkouts',[])),'source_files':r.get('source_files_rechecked')}))
