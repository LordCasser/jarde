#!/usr/bin/env python3
"""Read-only two-seed audit for the switch plus prefixed retry workspace replay."""
from __future__ import annotations
import argparse, hashlib, json, os, re, sys
from pathlib import Path

sys.dont_write_bytecode = True

ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
EXPECTED_SCHEMA = 'finthrow-full-workspace-seed-replay-v1'
GUARD_PATH = ROOT / 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_PATH = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_MANIFEST = ROOT / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
MAX_TARGET = 1024**3
MIN_FREE = 5 * 1024**3
STRIPPED = ['JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'RUST_MIN_STACK', 'CARGO_TARGET_DIR']
GATES = [
    ('p3_loop_terminal_return', 'decoded_switch_case_returns_are_loop_terminal_leaves'),
    ('p3_loop_terminal_return', 'four_way_switch_return_leaf_has_one_owner'),
    ('p3_loop_terminal_return', 'switch_outer_breaks_keep_loop_owner_and_transfer_source'),
    ('p3_loop_terminal_return', 'switch_loop_join_late_budget_cancel_and_deadline_publish_no_partial_source'),
    ('jarde_java', 'region::switch_nonlocal_completion_tests::real_switch_return_certificate_and_target_boundaries_refuse_without_claims'),
    ('jarde_java', 'region::switch_nonlocal_completion_tests::real_extra_entry_is_not_owned_by_the_switch_join_certificate'),
    ('jarde_java', 'region::switch_nonlocal_completion_tests::exception_edge_incident_to_real_loop_switch_refuses_strict_completion'),
    ('jarde_java', 'region::switch_nonlocal_completion_tests::direct_completion_edge_is_bound_to_its_real_jsr_clone'),
    ('p3_switch_nonlocal_late_stop', 'late_request_budget_does_not_publish_a_partial_switch_return_method'),
    ('jarde_java', 'region::protected_prefix_loop_tests::prefixed_exceptional_retry_uses_distinct_protected_and_handler_loop_edges'),
    ('jarde_java', 'region::protected_prefix_loop_tests::prefixed_exceptional_retry_late_budget_stop_restores_the_candidate_state'),
    ('jarde_java', 'region::protected_prefix_loop_tests::effectful_normal_join_bridge_is_refused_by_the_retry_certificate'),
    ('jarde_java', 'region::protected_prefix_loop_tests::catch_returning_to_the_outer_header_is_not_a_retry_continue'),
    ('jarde_java', 'region::protected_prefix_loop_tests::retry_facts_require_the_physical_row_to_match_the_same_canonical_row'),
    ('jarde_java', 'region::protected_prefix_loop_tests::retry_facts_preserve_the_full_reader_checkpoint_on_cancel_and_deadline'),
    ('jarde_java', 'region::protected_prefix_loop_tests::retry_owner_edge_closure_rejects_each_unowned_edge_class'),
    ('p3_prefixed_exceptional_retry_loops', 'prefixed_exceptional_retry_loop_is_structured_for_debug_and_no_debug_inputs'),
    ('p3_prefixed_exceptional_retry_loops', 'prefixed_exceptional_retry_late_recovery_budget_publishes_no_source_or_map'),
    ('p3_prefixed_exceptional_retry_loops', 'supplemental_pure_latch_bridges_keep_every_physical_source_origin'),
]
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
RUNNING = re.compile(r'^\s*Running\s+(.+?)\s+\((.+)\)\s*$')
HARNESS_START = re.compile(r'^running (\d+) tests?$')
TEST_LINE = re.compile(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?:,.*)?$')
SUMMARY = re.compile(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;')

class AuditError(Exception):
    pass

def need(ok, message):
    if not ok:
        raise AuditError(message)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def pin(path: Path):
    path = Path(path).resolve(strict=True)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}

def read_json(path):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception as exc:
        raise AuditError(f'cannot parse {path}: {exc}') from exc

def target_key(raw):
    need(isinstance(raw, list) and len(raw) == 3, f'bad target identity: {raw!r}')
    return tuple(str(x) for x in raw)

def read_raw(stream, where, out):
    need(isinstance(stream, dict), f'{where}: missing raw stream pin')
    path = Path(stream.get('path', ''))
    need(path.is_absolute() and not path.is_symlink(), f'{where}: raw path is noncanonical: {path}')
    path = path.resolve(strict=True)
    need(path.is_relative_to(out.resolve(strict=True)), f'{where}: raw stream escapes receipt output root')
    raw = path.read_bytes()
    need(len(raw) == stream.get('bytes') and sha(raw) == stream.get('sha256'), f'{where}: raw stream pin mismatch')
    return raw

def artifacts_from_stdout(data, where):
    result = []
    for line in data.splitlines():
        if not line.startswith(b'{'):
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(item, dict) or item.get('reason') != 'compiler-artifact':
            continue
        if not (item.get('profile') or {}).get('test') or not item.get('executable'):
            continue
        target = item.get('target') or {}
        kinds = target.get('kind') or []
        need(bool(kinds), f'{where}: test compiler-artifact omits target kind')
        result.append({'key': (str(item.get('package_id', '')), str(target.get('name', '')), str(kinds[0])),
                       'executable': str(item['executable']), 'basename': Path(item['executable']).name})
    need(result, f'{where}: no test compiler-artifact records')
    return result

def running_targets(stderr, artifacts, planned, where):
    text = ANSI.sub('', stderr.decode('utf-8', 'replace'))
    launches = []
    for line in text.splitlines():
        match = RUNNING.match(line)
        if not match:
            continue
        display, exe = match.groups()
        basename = Path(exe.strip()).name
        candidates = [a for a in artifacts if a['basename'] == basename]
        need(len(candidates) == 1, f'{where}: Running basename {basename!r} maps to {len(candidates)} artifacts')
        key = candidates[0]['key']
        need(key in planned, f'{where}: Running target is absent from this batch plan: {key}')
        launches.append({'target': key, 'display': display.strip(), 'executable': exe.strip()})
    need(launches, f'{where}: stderr has no Cargo Running entries')
    keys = [x['target'] for x in launches]
    need(len(keys) == len(set(keys)) and set(keys) == planned, f'{where}: Running order/target set is not exact')
    return launches

def harness_blocks(stdout, where):
    text = ANSI.sub('', stdout.decode('utf-8', 'replace'))
    blocks, active = [], None
    for line in text.splitlines():
        match = HARNESS_START.match(line.strip())
        if match:
            need(active is None, f'{where}: nested harness started before previous summary')
            active = {'declared': int(match.group(1)), 'tests': [], 'summary': None}
            continue
        if active is None:
            continue
        match = TEST_LINE.match(line.strip())
        if match:
            active['tests'].append((match.group(1), match.group(2)))
            continue
        match = SUMMARY.match(line.strip())
        if match:
            active['summary'] = tuple(int(x) for x in match.groups())
            observed = (sum(status == 'ok' for _, status in active['tests']),
                        sum(status == 'FAILED' for _, status in active['tests']),
                        sum(status == 'ignored' for _, status in active['tests']))
            need(observed == active['summary'], f'{where}: test statuses disagree with harness summary')
            need(active['declared'] == sum(active['summary']), f'{where}: harness declared count disagrees')
            blocks.append(active)
            active = None
    need(active is None, f'{where}: unterminated harness output')
    return blocks

def metadata_plan(metadata):
    members = set(metadata['workspace_members'])
    inventory, batches = [], []
    for package in metadata['packages']:
        if package['id'] not in members:
            continue
        targets = package['targets']
        inventory.extend((package['id'], t['name'], t['kind'][0]) for t in targets)
        base = ['cargo', 'test', '-p', package['name'], '--all-features', '--locked', '--message-format', 'json']
        unit = [t for t in targets if t['kind'][0] in ('lib', 'proc-macro', 'bin', 'example', 'bench')]
        if unit:
            kinds = {t['kind'][0] for t in unit}
            flags = []
            if kinds & {'lib', 'proc-macro'}: flags.append('--lib')
            if 'bin' in kinds: flags.append('--bins')
            if 'example' in kinds: flags.append('--examples')
            if 'bench' in kinds: flags.append('--benches')
            batches.append({'argv': base + flags, 'planned_targets': [(package['id'], t['name'], t['kind'][0]) for t in unit]})
        tests = [t for t in targets if t['kind'][0] == 'test']
        for start in range(0, len(tests), 4):
            group = tests[start:start + 4]
            batches.append({'argv': base + sum((['--test', t['name']] for t in group), []),
                            'planned_targets': [(package['id'], t['name'], t['kind'][0]) for t in group]})
    flat = [target for batch in batches for target in batch['planned_targets']]
    need(len(inventory) == len(set(inventory)), 'metadata target inventory has duplicate identities')
    need(len(flat) == len(set(flat)) and sorted(flat) == sorted(inventory), 'metadata-derived batches do not cover inventory exactly')
    return inventory, batches

def validate_gate_inventory(inventory):
    gate_records = []
    for target_name, test_name in GATES:
        matches = [t for t in inventory if t[1] == target_name]
        need(len(matches) == 1, f'gate target {target_name} resolves to {len(matches)} metadata identities')
        target = matches[0]
        expected_kind = 'lib' if target_name == 'jarde_java' else 'test'
        need(target[2] == expected_kind, f'gate target {target_name} has kind {target[2]}')
        gate_records.append((target, test_name))
    return gate_records

def check_resources(row, label):
    peak = row.get('peak_target_bytes')
    free = row.get('free_bytes_after')
    need(type(peak) is int and peak <= MAX_TARGET, f'{label}: target byte guard missing/exceeded')
    need(type(free) is int and free >= MIN_FREE, f'{label}: free-space guard missing/below 5 GiB')

def validate_one(receipt_path):
    receipt_path = Path(receipt_path).resolve(strict=True)
    out = receipt_path.parent
    x = read_json(receipt_path)
    need(x.get('schema') == EXPECTED_SCHEMA and x.get('status') == 'passed', f'{receipt_path}: nonterminal/wrong workspace receipt')
    need(x.get('root') == str(ROOT), f'{receipt_path}: wrong workspace root')
    need(x.get('finished_utc'), f'{receipt_path}: missing terminal timestamp')
    for field in ('no_carried_execution', 'target_absent_before', 'pins_unchanged', 'target_absent_after_clean'):
        need(x.get(field) is True, f'{receipt_path}: {field} is not true')
    need(not (ROOT / 'target').exists() and not (ROOT / 'target').is_symlink(), 'workspace target exists at audit time')

    # Source pins are stable before format, after format, after all builds, and against live files.
    before = x.get('source_pins_before_format'); pins = x.get('source_pins'); after = x.get('source_pins_after_format')
    need(isinstance(before, dict) and before and before == pins == after, f'{receipt_path}: source pins changed/missing')
    for rel, digest in pins.items():
        path = (ROOT / rel).resolve(strict=True)
        need(path.is_relative_to(ROOT) and path.is_file() and not path.is_symlink(), f'{receipt_path}: unsafe source pin path {rel}')
        need(sha(path.read_bytes()) == digest, f'{receipt_path}: live source pin changed: {rel}')

    # Exact durable guard, one-second polling, limits, JDK, runner, and child environment.
    need(x.get('guard_template') == {'path': str(GUARD_PATH), 'sha256': GUARD_SHA} and sha(GUARD_PATH.read_bytes()) == GUARD_SHA,
         f'{receipt_path}: durable guard pin mismatch')
    guard_text = GUARD_PATH.read_text(encoding='utf-8')
    need('time.sleep(1)' in guard_text, f'{receipt_path}: guard no longer polls at one-second intervals')
    need(x.get('target_size_scan_adapter') == {'path': str(SCANNER_PATH), 'sha256': SCANNER_SHA} and sha(SCANNER_PATH.read_bytes()) == SCANNER_SHA,
         f'{receipt_path}: target scanner pin mismatch')
    need(x.get('guard_limits') == {'free_bytes': MIN_FREE, 'target_bytes': MAX_TARGET}, f'{receipt_path}: wrong 5GiB/1GiB resource limits')
    runner = x.get('runner') or {}
    runner_path = Path(runner.get('path', '')).resolve(strict=True)
    need(pin(runner_path)['sha256'] == runner.get('sha256'), f'{receipt_path}: runner source pin mismatch')
    derived_path = Path(runner.get('derived_from', '')).resolve(strict=True)
    need(sha(derived_path.read_bytes()) == runner.get('derived_from_sha256'), f'{receipt_path}: derived runner source pin mismatch')
    jdk = x.get('jdk') or {}
    need(jdk.get('manifest') == {'path': str(JDK_MANIFEST), 'bytes': JDK_MANIFEST.stat().st_size, 'sha256': JDK_MANIFEST_SHA}
         and sha(JDK_MANIFEST.read_bytes()) == JDK_MANIFEST_SHA and jdk.get('manifest_expected_sha256') == JDK_MANIFEST_SHA,
         f'{receipt_path}: JDK 23 manifest pin mismatch')
    manifest = read_json(JDK_MANIFEST)
    leg = next((r for r in manifest['legs'] if r.get('leg') == 'javac23'), None)
    need(leg is not None and set(jdk.get('tools', {})) == {'java', 'javac', 'javap'}, f'{receipt_path}: JDK tool inventory incomplete')
    for name, tool_pin in jdk['tools'].items():
        listed = leg['jdk_tools'][name]
        need(tool_pin == {'path': str(Path(listed['path']).resolve()), 'bytes': listed['bytes'], 'sha256': listed['sha256']}
             and pin(Path(tool_pin['path'])) == tool_pin, f'{receipt_path}: JDK {name} pin mismatch')
    java_home = str(Path(leg['jdk_tools']['java']['path']).resolve().parent.parent)
    need(jdk.get('java_home') == java_home, f'{receipt_path}: JAVA_HOME differs from pinned JDK')
    env = x.get('environment') or {}
    need(env.get('stripped_names') == STRIPPED, f'{receipt_path}: child environment strip policy mismatch')
    overrides = env.get('overrides') or {}
    need(overrides.get('PROPTEST_RNG_SEED') == str(x.get('seed')) and overrides.get('CARGO_PROFILE_TEST_STRIP') == 'symbols'
         and overrides.get('CARGO_BUILD_JOBS') == '1' and overrides.get('CARGO_INCREMENTAL') == '0'
         and overrides.get('CARGO_PROFILE_DEV_DEBUG') == '0' and overrides.get('CARGO_PROFILE_TEST_DEBUG') == '0'
         and overrides.get('RUST_TEST_THREADS') == '1' and overrides.get('JAVA_HOME') == java_home
         and Path(overrides.get('PATH', '').split(os.pathsep)[0]) == Path(java_home) / 'bin'
         and 'RUST_MIN_STACK' not in overrides and 'CARGO_TARGET_DIR' not in overrides,
         f'{receipt_path}: child stack/target/JDK/test environment is not the pinned default')

    # Raw metadata is the authority for a fresh, dynamic inventory and batch plan.
    metadata_command = x.get('metadata_command') or {}
    need(metadata_command.get('index') == 1 and metadata_command.get('argv') == ['cargo', 'metadata', '--no-deps', '--format-version', '1', '--locked']
         and metadata_command.get('exit_code') == 0 and metadata_command.get('guard_stop') is None,
         f'{receipt_path}: cargo metadata command missing/failed')
    metadata_stdout = read_raw(metadata_command.get('streams', {}).get('stdout'), f'{receipt_path.name} metadata stdout', out)
    read_raw(metadata_command.get('streams', {}).get('stderr'), f'{receipt_path.name} metadata stderr', out)
    metadata_path = out / 'metadata.json'
    need(metadata_path.is_file(), f'{receipt_path}: archived metadata.json missing')
    metadata_bytes = metadata_path.read_bytes()
    file_record = x.get('metadata_file') or {}
    need(metadata_bytes == metadata_stdout and file_record == {'path': str(metadata_path.resolve()), 'bytes': len(metadata_bytes), 'sha256': sha(metadata_bytes)},
         f'{receipt_path}: metadata archive differs from raw command')
    metadata = json.loads(metadata_bytes)
    inventory, batches = metadata_plan(metadata)
    need(x.get('target_inventory') == [list(t) for t in inventory], f'{receipt_path}: dynamic target inventory differs from raw metadata')
    expected_plan = [{'argv': row['argv'], 'planned_targets': [list(t) for t in row['planned_targets']]} for row in batches]
    plan = x.get('batch_plan')
    need(plan == expected_plan and x.get('expected_batch_count') == len(plan), f'{receipt_path}: batch plan is incomplete or not metadata-derived')
    gate_identities = validate_gate_inventory(inventory)

    # Validate the format/metadata/batch/clean commands and each raw stream.
    commands = x.get('commands')
    need(isinstance(commands, list) and len(commands) == len(plan), f'{receipt_path}: batch receipt count differs')
    need([c.get('index') for c in commands] == list(range(2, len(plan) + 2)), f'{receipt_path}: noncontiguous batch command indexes')
    format_row = x.get('format_command') or {}
    need(format_row.get('index') == 0 and format_row.get('argv') == ['cargo', 'fmt', '--all', '--', '--check']
         and format_row.get('exit_code') == 0 and format_row.get('guard_stop') is None, f'{receipt_path}: format check failed')
    clean = x.get('clean_command') or {}
    need(clean.get('index') == len(plan) + 2 and clean.get('argv') == ['cargo', 'clean']
         and clean.get('exit_code') == 0 and clean.get('guard_stop') is None, f'{receipt_path}: exact final cargo clean missing/failed')
    all_commands = [format_row, metadata_command, *commands, clean]
    for row in all_commands:
        label = f'{receipt_path.name} command {row.get("index")}'
        need(row.get('cwd') == str(ROOT), f'{label}: command ran outside the pinned workspace root')
        need(row.get('exit_code') == 0 and row.get('guard_stop') is None, f'{label}: command failed or stopped')
        need(row.get('env_overrides') == overrides, f'{label}: command environment differs from recorded defaults')
        check_resources(row, label)
        read_raw(row.get('streams', {}).get('stdout'), f'{label} stdout', out)
        read_raw(row.get('streams', {}).get('stderr'), f'{label} stderr', out)

    all_counts = {}
    gate_hits = {gate: [] for gate in gate_identities}
    batch_receipts = []
    expected_exe_removals = []
    expected_dsym_removals = []
    collector_binding_differences = []
    for i, (row, spec) in enumerate(zip(commands, batches)):
        where = f'{receipt_path.name} batch {row["index"]}'
        need(row.get('argv') == spec['argv'] and row.get('planned_targets') == [list(t) for t in spec['planned_targets']],
             f'{where}: command argv or planned targets differ from metadata')
        planned = set(spec['planned_targets'])
        need(len(planned) == len(spec['planned_targets']), f'{where}: duplicate planned target')
        stdout = read_raw(row['streams']['stdout'], f'{where} stdout', out)
        stderr = read_raw(row['streams']['stderr'], f'{where} stderr', out)
        artifacts = artifacts_from_stdout(stdout, where)
        artifact_keys = [a['key'] for a in artifacts]
        need(len(artifact_keys) == len(set(artifact_keys)) and set(artifact_keys) == planned,
             f'{where}: fresh compiler-artifact target set differs from batch plan')
        launches = running_targets(stderr, artifacts, planned, where)
        blocks = harness_blocks(stdout, where)
        need(len(blocks) == len(launches), f'{where}: stdout summaries and stderr Running entries differ')
        batch_counts = []
        running_order_counts = []
        for launch, block in zip(launches, blocks):
            key = launch['target']
            counts = block['summary']
            need(all(n >= 0 for n in counts) and counts[1] == 0, f'{where}: {key} has invalid counts or failures')
            need(key not in all_counts, f'{receipt_path.name}: target ran more than once: {key}')
            all_counts[key] = counts
            tests = [{'name': name, 'status': status} for name, status in block['tests']]
            running_order_counts.append({'target': list(key), 'counts': list(counts), 'test_names': tests, 'running': launch['display']})
            batch_counts.append({'target': list(key), 'counts': list(counts), 'running': launch['display'],
                                 'harness_test_names': [name for name, _ in block['tests']]})
            for target_identity, gate_name in gate_identities:
                if key == target_identity:
                    gate_hits[(target_identity, gate_name)].extend((status, name) for name, status in block['tests'] if name == gate_name)
        # Check the collector's serialized count table without assuming artifact order equals execution order.
        recorded_counts = row.get('observed_counts') or []
        observed_map = {tuple(x['target']): tuple(x['counts']) for x in recorded_counts}
        # The inherited collector zipped artifact emission order to harness order. Verify that
        # historical table exactly, then use actual Running order as the authoritative binding.
        legacy_counts = [{'target': list(artifact['key']), 'counts': list(block['summary'])}
                         for artifact, block in zip(artifacts, blocks)]
        need(len(observed_map) == len(recorded_counts) and recorded_counts == legacy_counts,
             f'{where}: persisted collector table is not reconstructible from its raw artifacts/harness')
        actual_map = {tuple(x['target']): tuple(x['counts']) for x in running_order_counts}
        if observed_map != actual_map:
            collector_binding_differences.append({'index': row['index'],
                'original_artifact_order_counts': recorded_counts,
                'correct_running_order_counts': [{'target': x['target'], 'counts': x['counts']} for x in running_order_counts]})
        need(set(map(tuple, row.get('executed_targets', []))) == planned, f'{where}: recorded executed-target set differs')
        total = [sum(item['counts'][i] for item in running_order_counts) for i in range(3)]
        need(row.get('test_total') == total, f'{where}: batch totals disagree with Running-ordered harness summaries')

        removed = row.get('removed_test_executables') or []
        need(len(removed) == len(artifacts), f'{where}: removed executable records incomplete')
        removal_by_target = {tuple(r.get('target', [])): r for r in removed}
        need(len(removal_by_target) == len(removed) and set(removal_by_target) == set(artifact_keys), f'{where}: executable cleanup target mapping is not exact')
        for artifact in artifacts:
            target = artifact['key']; record = removal_by_target[target]; exe = Path(artifact['executable'])
            need(exe.is_absolute() and exe.resolve(strict=False).is_relative_to(ROOT / 'target')
                 and not exe.exists() and not exe.is_symlink(), f'{where}: compiled test executable remains or escaped target')
            need(record.get('command_index') == row['index'] and record.get('path') == str(exe.resolve(strict=False))
                 and record.get('bytes', 0) > 0 and re.fullmatch(r'[0-9a-f]{64}', record.get('sha256', '')),
                 f'{where}: executable cleanup record is not bound to raw compiler artifact')
            expected_exe_removals.append(record)
        dsyms = row.get('removed_test_dsym') or []
        for dsym in dsyms:
            path = Path(dsym['path'])
            need(path.is_absolute() and path.is_relative_to(ROOT / 'target') and not path.exists() and not path.is_symlink(),
                 f'{where}: removed dSYM remains or escaped target')
            members = dsym.get('members', [])
            need(dsym.get('sha256') == sha(json.dumps(members, sort_keys=True).encode())
                 and all(type(m.get('bytes')) is int and m['bytes'] >= 0 and re.fullmatch(r'[0-9a-f]{64}', m.get('sha256', '')) for m in members),
                 f'{where}: dSYM member archive invalid')
            expected_dsym_removals.append(dsym)
        batch_receipts.append({'index': row['index'], 'running_order': batch_counts, 'test_total': total})

    need(set(all_counts) == set(inventory) and len(all_counts) == len(inventory), f'{receipt_path}: executed identities differ from metadata inventory')
    need(x.get('workspace_summary_count') == len(all_counts), f'{receipt_path}: summary target count differs from dynamic inventory')
    totals = [sum(counts[i] for counts in all_counts.values()) for i in range(3)]
    need(x.get('workspace_totals') == totals and totals[0] > 0 and totals[1] == 0, f'{receipt_path}: dynamic workspace totals mismatch/fail')
    need(x.get('removed_completed_test_executables') == expected_exe_removals, f'{receipt_path}: aggregate executable cleanup records differ')
    need(x.get('removed_completed_test_dsym') == expected_dsym_removals, f'{receipt_path}: aggregate dSYM cleanup records differ')

    gate_receipts = []
    for target_identity, test_name in gate_identities:
        hits = gate_hits[(target_identity, test_name)]
        need(len(hits) == 1 and hits[0] == ('ok', test_name),
             f'{receipt_path}: required gate {target_identity[1]}::{test_name} occurrence/result is {hits!r}')
        gate_receipts.append({'target': list(target_identity), 'test': test_name, 'status': 'ok', 'occurrences': 1})

    need(x.get('workspace_summary_count') == len(x.get('target_inventory', [])), f'{receipt_path}: workspace count and inventory lengths differ')
    report_path = out / 'report.json'
    need(report_path.is_file(), f'{receipt_path}: compact report.json missing')
    report = read_json(report_path)
    need(report.get('status') == 'passed' and report.get('seed') == str(x['seed'])
         and report.get('workspace_summary_count') == len(all_counts) and report.get('workspace_totals') == totals
         and report.get('target_absent_before') is True and report.get('target_absent_after_clean') is True
         and report.get('pins_unchanged') is True, f'{receipt_path}: compact report disagrees with reconstructed receipt')
    return {'path': str(receipt_path), 'seed': str(x['seed']), 'target_count': len(inventory),
            'batch_count': len(plan), 'workspace_totals': totals, 'source_pin_count': len(pins),
            'source_pins_sha256': sha(json.dumps(pins, sort_keys=True, separators=(',', ':')).encode()),
            'inventory_sha256': sha(json.dumps(sorted(x['target_inventory']), separators=(',', ':')).encode()),
            'target_counts': [{'target': list(k), 'counts': list(v)} for k,v in sorted(all_counts.items())],
            'critical_gate_count': len(gate_receipts), 'critical_gates': gate_receipts,
            'batches': batch_receipts, 'collector_binding_differences': collector_binding_differences,
            'count_authority': 'Full raw harness summaries bound to exact Cargo Running executable identity; original collector tables preserved and separately reconstructed.'}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('seed1', type=Path, help='first terminal execution.json or containing seed directory')
    parser.add_argument('seed2', type=Path, help='second terminal execution.json or containing seed directory')
    parser.add_argument('--output', required=True, type=Path, help='private acceptance JSON output')
    args = parser.parse_args()
    try:
        p1 = args.seed1 / 'execution.json' if args.seed1.is_dir() else args.seed1
        p2 = args.seed2 / 'execution.json' if args.seed2.is_dir() else args.seed2
        a, b = validate_one(p1), validate_one(p2)
        need(a['seed'] != b['seed'], 'seed receipts are not distinct')
        need(a['source_pins_sha256'] == b['source_pins_sha256'], 'source pin maps differ across seeds')
        need(a['inventory_sha256'] == b['inventory_sha256'] and a['target_count'] == b['target_count'],
             'dynamic Cargo target inventories differ across seeds')
        ca = {tuple(x['target']): tuple(x['counts']) for x in a['target_counts']}
        cb = {tuple(x['target']): tuple(x['counts']) for x in b['target_counts']}
        need(ca == cb, 'per-target test counts differ across seeds')
        output = {'schema': 'switch-prefixed-retry-full-workspace-review-v1', 'status': 'passed',
                  'seed_count': 2, 'dynamic_target_count': len(ca), 'source_pin_count': len(json.loads(p1.read_text())['source_pins']),
                  'source_pins_equal': True, 'inventory_equal': True, 'per_target_counts_equal': True,
                  'critical_gates_per_seed': len(GATES), 'critical_gates_each_occur_once_and_pass': True,
                  'seed1': a, 'seed2': b,
                  'method': 'Reconstruct target inventory and Cargo batches from each archived raw metadata document; bind stdout harness summaries to stderr Running order, resolving executables through compiler-artifact target identity; compare full target-id count maps across independent seeds.'}
        dest = args.output.resolve()
        need(not dest.exists(), f'refusing to overwrite {dest}')
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'status': 'passed', 'targets': len(ca), 'gates_per_seed': len(GATES), 'output': str(dest)}, ensure_ascii=False))
        return 0
    except (AuditError, OSError, KeyError, TypeError, ValueError) as exc:
        print(f'AUDIT FAILED: {exc}', file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
