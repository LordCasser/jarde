# Typed foreach own-CI and native gate update (v3 prep)

Prepared from frozen own-CI v2 and native acceptance wrapper v2. No collection, network, Git, Cargo, JDK, CLI, or shared-repository write was performed. Root supplies the actual product SHA and workflow run ID later.

- `collect-own-ci.py` / `collector.diff`: adds only `src/bulk.rs` to the prior ordered source pins (12 paths total).
- `verify-own-ci.py` / `verifier.diff`: matching source inventory; keeps the same fixture contract, 41 inherited gates, and nine typed-foreach gates, then adds four exact `bulk_recovery_lifecycle` test identities (54 total). Test/pass totals remain parsed from the actual raw CI receipt; no new global pass total is assumed. The summary reports the added bulk gate count from the gate map.
- `verify_typed_foreach.py` / `native-wrapper.diff`: extends native two-receipt `GATES` from five to nine and asserts that exact inventory. The 385-target historical baseline is unchanged.
- `missing_step_proof.py`: copied byte-for-byte from frozen own-CI v2; no helper or log-acceptance changes.
- `pins.json`: input/output hashes and the exact requested contract.

The native checker still derives target totals and test counts from receipts. The four additions are checks of existing bulk lifecycle tests, not new tests or new evidence that they passed. This directory contains prepared tooling only.
