"""Bind the one omitted per-step member to its complete official aggregate body."""
import datetime as dt, hashlib, re
JOB='stable / test and specification'
NAME='Run ignored JDK 25 instruction-boundary oracle'
TARGET='jdk25_instruction_boundaries_match_public_bytecode_inspection'
COMMAND='cargo test --test jvm_bytecode_oracle --locked -- --ignored --exact '+TARGET
STAMP=re.compile(r'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z ?')
ANSI=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
def digest(raw):return hashlib.sha256(raw).hexdigest()
def payload(raw):return ''.join(STAMP.sub('',x) for x in raw.decode('utf-8-sig').splitlines(keepends=True))
def need(ok,message):
 if not ok:raise ValueError(message)
def derive(archive, api, workflow, display, step):
 need(display==JOB and step['number']==10 and step['name']==NAME and step['conclusion']=='success','step identity/status does not match the omitted API step')
 need('- name: '+NAME+'\n        run: '+COMMAND in workflow,'workflow does not pin the exact step command')
 job=next(j for j in api['jobs'] if j['name']==JOB);steps=job['steps'];index=steps.index(step)
 previous,following=steps[index-1],steps[index+1]
 need(previous['number']==9 and following['number']==11,'step is not between the expected API neighbors')
 folder=JOB.replace('/','_')+'/'
 def member(s):return folder+str(s['number'])+'_'+s['name'].replace('/','_')+'.txt'
 aggregate_name='0_'+JOB.replace('/','_')+'.txt'
 raw_aggregate=archive.read(aggregate_name);aggregate=payload(raw_aggregate)
 before_raw=archive.read(member(previous));after_raw=archive.read(member(following))
 before,after=payload(before_raw),payload(after_raw)
 need(aggregate.count(before)==1 and aggregate.count(after)==1,'adjacent API payload is not unique in the aggregate')
 start=aggregate.index(before)+len(before);end=aggregate.index(after)
 need(0<start<end and aggregate[:start].endswith('\n') and aggregate[:end].endswith('\n'),'aggregate slice boundaries are invalid')
 begin_line=aggregate[:start].count('\n');end_line=aggregate[:end].count('\n')
 raw_lines=raw_aggregate.decode('utf-8-sig').splitlines(keepends=True)
 raw=''.join(raw_lines[begin_line:end_line]).encode();body=payload(raw)
 need(body==aggregate[start:end],'raw slice does not equal normalized aggregate interval')
 need(body.startswith('##[group]Run '+COMMAND+'\n') and body.count('##[group]Run ')==1,'isolated body does not begin with exactly the pinned command group')
 plain=ANSI.sub('',body)
 need(plain.splitlines().count(COMMAND)==1,'isolated command line is absent or duplicated')
 need(plain.splitlines().count('running 1 test')==1,'isolated one-test harness header is absent or duplicated')
 need(plain.splitlines().count('test '+TARGET+' ... ok')==1,'exact target outcome is absent or duplicated')
 need(len(re.findall(r'^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;',plain,re.M))==1,'exact passing one-test summary is absent or duplicated')
 need(re.search(r'^\s*Running tests/jvm_bytecode_oracle\.rs \(target/debug/deps/jvm_bytecode_oracle-[0-9a-f]+\)$',plain,re.M) is not None,'expected integration-test executable is absent')
 need('... FAILED' not in plain,'isolated body includes a failed test')
 api_start=dt.datetime.fromisoformat(step['started_at'].replace('Z','+00:00'))
 api_end=dt.datetime.fromisoformat(step['completed_at'].replace('Z','+00:00'))
 stamps=[]
 for line in raw.decode().splitlines():
  match=STAMP.match(line);need(match is not None,'derived step log has a line without its timestamp prefix')
  stamp=dt.datetime.fromisoformat(match.group().strip().replace('Z','+00:00'));stamps.append(stamp)
  need(api_start-dt.timedelta(seconds=1)<=stamp<=api_end+dt.timedelta(seconds=1),'derived log timestamp falls outside the API step interval')
 proof={'authority':'unmodified official ZIP aggregate; one missing API step isolated between uniquely matching adjacent per-step payloads',
  'job':JOB,'step':step,'aggregate_member':aggregate_name,'aggregate_sha256':digest(raw_aggregate),
  'previous_member':member(previous),'previous_sha256':digest(before_raw),'following_member':member(following),'following_sha256':digest(after_raw),
  'comparison_normalization':'Strip only GitHub timestamp prefixes and UTF-8 BOM to align per-step and aggregate payloads; original raw bytes retained. Their timestamp fractional values differ.',
  'aggregate_line_slice_zero_based':[begin_line,end_line],'raw_bytes':len(raw),'raw_sha256':digest(raw),
  'first_log_time':stamps[0].isoformat(),'last_log_time':stamps[-1].isoformat(),'api_timestamp_tolerance_seconds':1,
  'command':COMMAND,'exact_test':TARGET,'passed':1,'failed':0,'ignored':0,'filtered':0}
 return raw,proof
