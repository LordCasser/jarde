# Next fixed TestNestedLoops gap: original foreach names

Current product candidate b78b34ed6ee908309de4f85d771adcab8ee24133 / CLI16bd is frozen while fresh native and own CI run. This note is analysis only; no new implementation or acceptance claim.

The complete original source is 876B, SHA4897fd18a15fce6e0abb40dc8afc6c7a3fa9f16e617f3c7e5e88072f6a37309e. Final API replay proves both String heads but retains synthetic header names and original s1/s2 copies. The literal upstream name golden remains open. Fixed original Code has45 instructions/119B; debug and no-debug source share physical slot roles.

Offline actual captured Code (not a new javap run): outer Iterator.next@17/checkcast@22/astore4@25; slot4 reads@57,67,77. Inner next@47/checkcast@52/astore6@55; slot6 reads@59,89. After outer backedge@100, tail@103/104/109/112/113/118 never reads slot4 or6. This is a strong candidate for moving the blank outer declaration into the head and promoting the inner first Declare into the head. It does not prove a generic same-name AST rewrite.

Existing seams validated against current sources:
- ClassSourceAstLocalDeclaration: bci/name/ty/source_type_name/scope_anchors. No initializer-presence or physical-slot identity field.
- ClassSourceAstLocalAssignment: bci/name/value_bci/cast_type/scope_anchors.
- SameClassBodyValueSite: same-run physical bci/opcode/stack_reads+writes/local_reads+writes, each local pair contains slot + SSA fact.
- SameClassInvokeValueFact: value/definition/uses/replaced_by.
- Existing opaque AST typed projector sees actual first Declare/Assign, header name, original RHS and scopes; retained Program can be inspected without another Reader/SSA pass.

Proposed proof direction, not an approved design:
1. Join first original target store BCI to physical local slot and current original declaration anchor. Never bind by printed name alone.
2. Inner Declare promotion can change the header name to the already-used original name and remove the sole first copy; no other AST reference rename should be needed. Close all uses and scope ownership first.
3. Outer Assign promotion additionally requires one blank declaration at the immediately enclosing permitted scope, no initializer or effects before the loop, no outside reads/writes/captures or competing declaration identity, and full target-use/phi closure within that loop owner. Preserve observed zero-iteration state by refusing initialized or observable targets.
4. Existing initialized current/seen-before/after control cases must remain unchanged and still compile/run. Extra writes, shadowing/reused slots, nested containers, captured locals, handlers and early exits need explicit boundaries before implementation.
5. Keep optional binding-fold eligibility separate from accepted generic declaration and typed-head eligibility; rejection cannot undo the current typed improvement. Reuse the same retained AST and atomic transaction. All scans/clones/emission need budget/Stop closure.

Open questions: does the existing declaration BCI for a hoisted blank exactly identify the loop first store in all accepted variants? Is complete SSA target-use inventory enough for every actual AST Local occurrence (origins may be derived/copied)? What narrow shape avoids any general scope solver? Do not add a global liveness entity until these actual gaps are proved.

Atlas local structural queries used: q_1a14e1be117_26ec, q_1a14e1be327_275b, q_1a14e1c1afa_dff9, q_1a14e1c1d4a_d94a, q_1a14e1c1c2a_d8ab, q_1a14e1c6679_a5e8. Existing full structural index skips extraction; report.rs includeCode snippets have stale byte boundaries and are truncated/misaligned. Names/locations were used only as leads and all cited field shapes were reread from current source. No Atlas dataflow completeness claim. Cache freshness is a separate tool debt, not this leaf's code scope.
