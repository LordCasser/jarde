# Bulk class execution interval patch (private preparation)

OpenSpec reviewed: `openspec/changes/align-bulk-class-task-execution-interval/`.
Apply state: ready, 1/4; private proposal only. No shared repository changes and no build/test commands run.

Only `src/bulk.rs` is copied and patched. The existing single `Registry::enter()` guard moves to the first statement of `run_class_task`, before the injected panic, ClassGate and delay. No gate, thresholds, assertions, weights, scheduling, or public types were changed.

Baseline `src/bulk.rs` SHA256: `f5ea5da0ceda12816858480955b3b679db78fb88fffb3981b820405947efa7b1`.
Private final copy SHA256: `f512998a8fd28052d9c2a23c9b04e6498246404ab389342f148a9e7893151e4b`.
See `patch.diff`, `baseline.sha256`, `final.sha256`, and `bulk.rs`.

RAII/drop review: `Registry::enter` increments under its existing mutex and returns `Entered`; the local mutex guard leaves scope before `enter` returns, so the class gate/delay do not hold the registry lock. `Entered::drop` decrements under the same mutex. Since `_entered` is owned by `run_class_task`, normal return, every early return, and unwind (including the test-injected entry panic) all drop this same guard. The existing outer `TaskGuard` remains responsible for publishing/closing a worker panic; this patch does not replace or duplicate that behavior. The existing lifecycle test retains its real two-party ClassGate, `high_water == 2`, worker join, panic, cancellation, and consumer paths; no mirrored test was added.
