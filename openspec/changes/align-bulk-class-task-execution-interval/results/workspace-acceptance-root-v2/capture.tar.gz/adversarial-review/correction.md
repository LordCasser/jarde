# Correction / follow-up to `review.md`

This supplements the frozen original review; it does not edit `review.md`.

## Native split-stream pairing: prior concern withdrawn

The local Cargo documentation explicitly states that a package's multiple test targets are executed serially. In the installed Rust 1.92.0 Cargo command reference, lines 206–212 read:

> “If the package contains multiple test targets, each target compiles to a special executable as aforementioned, and then is run serially.”

Document: `/Users/lordcasser/.rustup/toolchains/1.92.0-aarch64-apple-darwin/share/doc/rust/html/cargo/commands/cargo-test.html`
SHA-256: `553b7425e2a624a03730114be8138be020b2dc1635575824d2a480abe16b9d9c`

Given Cargo's serial test-executable execution, Cargo's stderr `Running` records and each executable's stdout harness block each preserve the same target order. The independent checker requires one complete harness block per launch and rejects count mismatches. Although the two files lack a shared timestamp, ordinal pairing is supported by Cargo's documented serial execution; the previously alleged arbitrary cross-stream swap false-accept path is not substantiated and should be removed from the findings/disposition.

## Target-name uniqueness in the available native metadata

The raw 385-target metadata snapshot at `/private/tmp/jarde-typed-foreach-workspace-seed1-root-v2-20261018/metadata.json` has SHA-256 `422120e14967f0d87c24d4a29a5b10058b9d7a7c3c2b619135978480321942a9`. Its only repeated target name is `task_operations`, occurring as the `jarde` example and `jarde` integration-test target. None of the v3 CI verifier's 54 gate target names equals `task_operations`; all nine distinct gate target names referenced by the CI gates resolve exactly once in this metadata. The native gate target names also each resolve exactly once; the base checker itself enforces exactly one metadata identity per native gate target.

This resolves the target-name-only ambiguity for the reviewed 385-target snapshot and current gate set. The CI verifier still does not independently load/require this metadata uniqueness; therefore describe it as confirmed for the available native inventory, not as a CI verifier invariant. The other 385-target snapshots found under `/private/tmp` have the same metadata SHA and same sole duplicate. The older 383-target snapshots likewise only duplicate `task_operations`.

## Remaining bounded note

The earlier observation that two-seed equality compares per-target counts rather than full named `(test,status)` outcomes remains accurate. It is a comparison-strength gap if exact named-result equality is required, not evidence that a required gate or failing test can currently be accepted: each receipt is independently reconstructed, all failures/filtered outcomes are rejected, and each named critical gate must pass exactly once.
