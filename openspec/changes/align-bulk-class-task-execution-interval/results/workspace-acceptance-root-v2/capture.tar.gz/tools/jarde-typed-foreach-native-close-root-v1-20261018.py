#!/usr/bin/env python3
import datetime,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
OUT=Path('/private/tmp/jarde-typed-foreach-workspace-acceptance-root-v2-20261018')
PRODUCT='e69a3494c8fcd0ff4783be1e9ff71499a730adde'
SEED1=Path('/private/tmp/jarde-typed-foreach-workspace-seed1-root-v2-20261018')
SEED2=Path('/private/tmp/jarde-typed-foreach-workspace-seed2-root-v2-20261018')
def pin(p):
    b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def need(ok,message):
    if not ok:raise RuntimeError(message)
need(sys.flags.optimize==0,'root source binder requires actual assertions enabled')
need(not OUT.exists(),'refuse overwrite')
for p in (SEED1,SEED2):
    d=json.loads((p/'execution.json').read_bytes())
    need(d['status']=='passed' and d['target_absent_after_clean'],'both actual seeds must be terminal and clean')
need(not (ROOT/'target').exists() and not (ROOT/'target').is_symlink(),'target present')
OUT.mkdir()
commands=[
 ['python3','-B','/private/tmp/jarde-typed-foreach-own-ci-prep-luna-v3-20261018/verify_typed_foreach.py',str(SEED1),str(SEED2),'--output',str(OUT/'native-review.json')],
 ['python3','-B','/private/tmp/jarde-typed-foreach-native-named-review-root-v1-20261018/review_named.py',str(OUT/'native-review.json'),'--out',str(OUT/'named-review.json')],
 ['python3','-B','/private/tmp/jarde-typed-foreach-product-bind-prep-root-v1-20261018/bind_product.py','--product',PRODUCT,'--build','/private/tmp/jarde-typed-foreach-bulk-interval-broad-root-v4-20261018/execution.json','--seed1',str(SEED1/'execution.json'),'--seed2',str(SEED2/'execution.json'),'--out',str(OUT/'product-source-binding.json')]]
record={'status':'running','product':PRODUCT,'python_optimization':sys.flags.optimize,'launcher':pin(Path(__file__)),'commands':[]}
try:
    for i,argv in enumerate(commands,1):
        row={'argv':argv,'cwd':str(ROOT),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        so=OUT/f'{i:02d}.stdout.raw';se=OUT/f'{i:02d}.stderr.raw'
        with so.open('xb') as f,se.open('xb') as g:row['exit_code']=subprocess.run(argv,cwd=ROOT,stdout=f,stderr=g).returncode
        row['streams']={'stdout':pin(so),'stderr':pin(se)};record['commands'].append(row)
        need(row['exit_code']==0,f'independent command {i} failed; raw kept')
    record['status']='accepted_two_native_receipts_named_outcomes_and_product_source_binding'
finally:
    record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':record['status'],'output':str(OUT)}))
