#!/usr/bin/env python3
"""Build the final portable NoCall implementation evidence package (cache-only)."""
from pathlib import Path
import argparse, hashlib, json, tarfile, io

CACHE=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
CORE=CACHE/'CORE'
OUT=CORE/'no-call-finally-implementation-evidence-v4'
BASE=CORE/'no-call-finally-planning-evidence-v1'
DEFAULT_BINDING=CORE/'no-call-finally-final-product-source-binding-v1'/'final-source-cli-head-binding.json'
STAGES=[
 ('no-call-finally-first-implementation-native-v1','historical_first_native_101_then_clean'),
 ('no-call-finally-format-v1','historical_formatter_harness_error_no_exit_receipt'),
 ('no-call-finally-format-v2','formatter_actual_exit_zero'),
 ('no-call-finally-second-implementation-native-v1','historical_second_native_5_commands'),
 ('no-call-finally-intermediate-full-source-v1','intermediate_full_source_10_command_replay'),
 ('no-call-finally-complete-local-native-v1','native_batch_with_actual_resource_guard_stop'),
 ('no-call-finally-local-native-continuation-v1','terminal_local_native_continuation'),
 ('no-call-finally-final-full-source-v1','final_complete_full_source_10_command_replay'),
]
AUDITS=[
 CORE/'no-call-finally-local-composite-native-source-independent-audit-v1.json',
 CORE/'no-call-finally-local-composite-native-source-independent-audit-addendum-v1.json',
 CORE/'no-call-finally-final-full-source-v1'/'independent-final-source-parent-review-v1.json',
]
SOURCE_BINDING_FILES=['final-source-cli-head-binding.json','source-head-tree.argv.json','source-head-tree.raw']
TEXT_SUFFIXES={'.py','.java','.rs','.md','.json','.txt','.stdout','.out','.raw','.class','.jar','.toml','.sh','.xml'}

def sha(data): return hashlib.sha256(data).hexdigest()
def add(items, src, arc, group):
    src=Path(src)
    if not src.is_file(): raise FileNotFoundError(src)
    if '__pycache__' in src.parts or src.suffix=='.pyc': return
    items[str(arc)]=(src,group)
def add_tree(items, root, arcroot, group):
    root=Path(root)
    if not root.exists(): raise FileNotFoundError(root)
    for p in sorted(root.rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(root)
        if '__pycache__' in rel.parts or p.suffix=='.pyc' or any(x in {'target','build'} for x in rel.parts): continue
        # Evidence artifacts are kept, executable tool binaries are represented by pins in receipts only.
        if p.name.startswith('jarde-cli') or (p.parent.name=='bin' and p.name in {'java','javac','cargo','rustc'}): continue
        add(items,p,Path(arcroot)/rel,group)
def receipt(stage):
    for rel in ['run-v1/execution.json','execution.json']:
        p=stage/rel
        if p.is_file(): return p
    return None
def summarize(stage):
    p=receipt(stage)
    if not p:
        err=stage/'harness-error.json'
        if err.is_file():
            e=json.loads(err.read_text()); stream_paths=[v.get('path') for v in e.get('streams',{}).values() if isinstance(v,dict) and v.get('path')]
            return {'stage':stage.name,'receipt':str(err),'status':e.get('status'),'attempted_commands':1,'commands_with_exit_receipt':0,'exit_codes':[],'raw_stream_references':len(stream_paths),'unique_raw_paths':len(set(stream_paths))}
        return {'stage':stage.name,'receipt':'absent','attempted_commands':0,'commands_with_exit_receipt':0,'raw_stream_references':0}
    d=json.loads(p.read_text())
    cmds=d.get('commands')
    if isinstance(cmds,list):
        command_list=cmds; status=d.get('status')
    elif isinstance(d.get('argv'),list):
        command_list=[d]; status=d.get('status') or 'single_command_receipt'
    else:
        command_list=[]; status=d.get('status')
    refs=[]
    for c in command_list:
        streams=c.get('streams',{})
        if isinstance(streams,dict):
            for val in streams.values():
                if isinstance(val,dict) and val.get('path'): refs.append(val['path'])
    return {'stage':stage.name,'receipt':str(p),'status':status,'attempted_commands':len(command_list),'commands_with_exit_receipt':len(command_list),'exit_codes':[c.get('exit_code') for c in command_list],'raw_stream_references':len(refs),'unique_raw_paths':len(set(refs))}
def find_screen():
    found=[]
    for p in CORE.glob('**/execution.json'):
        try:
            d=json.loads(p.read_text()); cs=d.get('commands',[])
            labels=' '.join(str(c.get('label',''))+' '+' '.join(map(str,c.get('argv',[]))) for c in cs).lower()
            if len(cs)==20 and all(x in labels for x in ('fo','fy','fx')) and 'screen' in str(p).lower(): found.append((p.parents[1],p,d))
        except Exception: pass
    return found
def verify_pin_entry(entry):
    path=Path(entry['path'])
    if not path.is_file(): raise RuntimeError(f"pinned input missing: {path}")
    data=path.read_bytes()
    if len(data)!=entry.get('bytes') or sha(data)!=entry.get('sha256'):
        raise RuntimeError(f"pinned input changed: {path}")
    return path
def collect_inputs(items, stage_root, group):
    # Preserve pinned source, driver, oracle, class/JAR fixture, runner/helper, and manifest inputs.
    # JDK/Rust/CLI executables remain metadata-only; no current-tree substitution is allowed.
    for ep in stage_root.glob('**/execution.json'):
        try: d=json.loads(ep.read_text())
        except Exception: continue
        for field in ('inputs_before','inputs_after'):
            for idx,entry in enumerate(d.get(field,[]) or []):
                p=verify_pin_entry(entry)
                low=str(p).lower()
                if p.name.startswith('jarde-cli') or '/bin/java' in low or '/bin/javac' in low or '/bin/cargo' in low or '/bin/rustc' in low:
                    continue
                if p.suffix.lower() not in TEXT_SUFFIXES: continue
                # Archive source paths with phase-local provenance; retain exact bytes verified above.
                arc=Path('pinned-inputs')/stage_root.name/field/(f'{idx:03d}-'+p.name)
                add(items,p,arc,'exact_input_before_after_pin')
def build(binding):
    if OUT.exists(): raise RuntimeError(f'output already exists; refusing to overwrite: {OUT}')
    missing=[]
    if not (BASE/'manifest.json').is_file() or not (BASE/'capture.tar.gz').is_file(): missing.append('separate baseline evidence package/manifest is missing')
    if not binding.is_file(): missing.append(f'final source binding missing: {binding}')
    screen=find_screen()
    if len(screen)!=1: missing.append(f'exactly one pinned 20-command FY/FX/FO screen required, found {len(screen)}')
    for n,_ in STAGES:
        if not (CORE/n).is_dir(): missing.append(f'stage missing: {CORE/n}')
    for p in AUDITS:
        if not p.is_file(): missing.append(f'independent audit missing: {p}')
    if missing: raise RuntimeError('package preconditions unmet:\n- '+'\n- '.join(missing))
    binding_data=json.loads(binding.read_text())
    if binding_data.get('product_head')!='02de294f7af2d0798e33d52ce5474e60efe17b03': raise RuntimeError('source binding product head is not the final expected head')
    if binding_data.get('frozen_cli',{}).get('sha256')!='fd7b33ce0411854e480186c7ade82ecc21d4401b79d1a0b1bd0d5c7774bbff25': raise RuntimeError('frozen CLI pin differs from final receipt')
    cont=json.loads((CORE/'no-call-finally-local-native-continuation-v1/run-v1/execution.json').read_text())
    if cont.get('status')=='running': raise RuntimeError('continuation receipt is not terminal')
    items={}
    base_m=json.loads((BASE/'manifest.json').read_text()); base_archive=BASE/'capture.tar.gz'
    base_ref={'archive_path':str(base_archive),'bytes':base_archive.stat().st_size,'sha256':sha(base_archive.read_bytes()),'manifest_path':str(BASE/'manifest.json'),'manifest_sha256':sha((BASE/'manifest.json').read_bytes()),'payload_count':base_m.get('payload_count')}
    # Reference prior package without copying its payloads.
    ref=OUT.parent/'baseline-reference-for-implementation-v3.json'
    ref.write_text(json.dumps(base_ref,indent=2)+'\n')
    add(items,ref,'baseline-package-reference.json','prior_red_baseline_reference')
    summaries=[]
    for dirname,group in STAGES:
        root=CORE/dirname
        add_tree(items,root,Path('stages')/dirname,group)
        collect_inputs(items,root,group)
        rp=receipt(root)
        if rp:
            rd=json.loads(rp.read_text())
            runner=rd.get('runner')
            if isinstance(runner,dict) and runner.get('path'):
                path=verify_pin_entry(runner)
                add(items,path,Path('tooling')/dirname/('runner-'+path.name),'pinned_stage_runner')
            for key,val in (rd.get('dependencies',{}) or {}).items():
                if isinstance(val,dict) and val.get('path'):
                    path=verify_pin_entry(val)
                    add(items,path,Path('tooling')/dirname/(key+'-'+path.name),'pinned_stage_dependency_helper')
        summaries.append(summarize(root))
    screen_root,screen_receipt,screen_data=screen[0]
    add_tree(items,screen_root,Path('stages')/'effectful-finally-after-no-call-screen-v1', 'actual_FY_FO_success_FX_compile_refusal_screen')
    collect_inputs(items,screen_root,'actual_FY_FO_success_FX_compile_refusal_screen')
    summaries.append({'stage':'effectful-finally-after-no-call-screen-v1','receipt':str(screen_receipt),'status':screen_data.get('status'),'commands':len(screen_data['commands']),'exit_codes':[x.get('exit_code') for x in screen_data['commands']],'raw_stream_references':sum(len(x.get('streams',{})) for x in screen_data['commands'])})
    # Exact product binding plus its raw Git tree command and output.
    add(items,binding,'bindings/final-source-cli-head-binding.json','final_git_source_and_frozen_cli_metadata')
    for name in SOURCE_BINDING_FILES[1:]:
        p=binding.parent/name
        if not p.is_file(): raise RuntimeError(f'missing required source-tree raw binding file: {p}')
        add(items,p,Path('bindings')/name,'final_git_source_tree_raw_binding')
    for p in AUDITS: add(items,p,Path('independent-audits')/p.name,'independent_final_audit')
    # Static, review and runner files related to this slice; avoid broad cache capture.
    for p in sorted(CORE.glob('no-call-finally-*')):
        if p.is_file() and p.suffix in {'.json','.py','.md'}: add(items,p,Path('analysis')/p.name,'related_review_or_static_analysis')
    # Explicitly package this builder so reproduction steps are available.
    builder=Path(__file__); add(items,builder,'builder/'+builder.name,'cache_only_package_builder')
    readme='''# NoCall 效果化 finally 实现阶段证据包\n\n本包汇集多阶段、不同源码快照的历史执行证据。各阶段保留自己的 execution 收据、raw、源码快照和输入 pin；不得把某阶段结果解释为另一阶段结果。\n\n实现阶段存在通过、拒绝和资源保护停止等不同结果。完整本地 native 批次的资源保护终止仍作为失败/中断历史保留；后续 continuation 是独立的最终收据。FY/FO 的本轮配对原类与生成源码运行验证通过；FX 两个生成源码编译命令返回 1 且未运行。screen 的预期就是混合结果，不以全部命令成功作为打包条件。\n\n先前红基线包以外部路径、大小、SHA 和 payload 数引用，不重复展开。最终绑定记录 product head 02de294f7af2d0798e33d52ce5474e60efe17b03、CLI SHA-256 fd7b33ce0411854e480186c7ade82ecc21d4401b79d1a0b1bd0d5c7774bbff25。CLI/JDK/Rust 可执行文件不打包；相关非二进制脚本、Java 源/driver/oracle、原始与重建 Java class/JAR、runner/helper 和 source-tree 原始绑定按各自收据 pin 收录。\n\n清单本身作为 tar 内一个 member。payload 数不含清单；tar 总 member 数为 payload_count + 1。\n'''
    readme_path=OUT.parent/'README-no-call-finally-implementation-v4.md'; readme_path.write_text(readme)
    add(items,readme_path,'README.md','package_scope_and_limits')
    members=[]
    for arc,(src,group) in sorted(items.items()):
        data=src.read_bytes(); members.append({'source_path':str(src),'archive_path':arc,'bytes':len(data),'sha256':sha(data),'group':group})
    manifest={'schema':'no-call-finally-implementation-evidence-v4','status':'packaged_after_final_source_binding_and_independent_audits','product_head':binding_data['product_head'],'frozen_cli':binding_data['frozen_cli'],'baseline_reference':base_ref,'stages':summaries,'payload_count':len(members),'manifest_member_count':1,'tar_member_count':len(members)+1,'members':members,'excluded':['frozen CLI executable','JDK/Rust toolchain executables','target/build outputs','__pycache__ and .pyc'],'interpretation':'Historical outcomes are preserved phase-by-phase. Nonzero/terminated commands remain so; no all-green implication.'}
    OUT.mkdir(parents=True,exist_ok=False)
    manifest_bytes=json.dumps(manifest,ensure_ascii=False,indent=2).encode()+b'\n'
    manifest_path=OUT/'manifest.json'; manifest_path.write_bytes(manifest_bytes)
    archive=OUT/'capture.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=6) as tf:
        for arc,(src,group) in sorted(items.items()):
            data=src.read_bytes(); info=tarfile.TarInfo(arc); info.size=len(data); info.mode=0o644; info.mtime=0; tf.addfile(info,io.BytesIO(data))
        info=tarfile.TarInfo('manifest.json'); info.size=len(manifest_bytes); info.mode=0o644; info.mtime=0; tf.addfile(info,io.BytesIO(manifest_bytes))
    print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'payload_count':len(members),'manifest_member_count':1,'tar_member_count':len(members)+1,'manifest_sha256':sha(manifest_bytes),'out':str(OUT)},indent=2))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--build',action='store_true'); ap.add_argument('--source-binding',type=Path,default=DEFAULT_BINDING); a=ap.parse_args()
    if a.build: build(a.source_binding)
    else:
        print(json.dumps({'prepared_only':True,'out':str(OUT),'out_exists':OUT.exists(),'binding_exists':DEFAULT_BINDING.is_file(),'screen_candidates':[str(x[1]) for x in find_screen()],'audit_exists':[p.is_file() for p in AUDITS]},indent=2))
if __name__=='__main__': main()
