from pathlib import Path
import json,hashlib,importlib.util,os,shutil,zipfile,datetime
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=B/'CORE';W=Path('/home/lordcasser/.codex/worktrees/local-increment-finally/jarde');D=C/'effectful-finally-after-no-call-screen-v1';D.mkdir(exist_ok=False);O=D/'run-v1';O.mkdir();OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');CLI=B/'jarde-cli-no-call-finally-local-native-continuation-v1'
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();v=p.read_bytes();return dict(path=str(p),bytes=len(v),sha256=hashlib.sha256(v).hexdigest())
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
assert not (W/'target').exists() and shutil.disk_usage(W).free>=5*1024**3
native=C/'no-call-finally-local-native-continuation-v1/execution.json';n=json.loads(native.read_text());assert n['source_manifest_before']==n['source_manifest_after'] and n['target_absent'];assert pin(CLI)=={k:n['frozen_cli'][k] for k in ['path','bytes','sha256']}
oldp=C/'effectful-finally-current-screen-v1/run-v1/execution.json';old=json.loads(oldp.read_text());assert old['inputs_identical'] and old['sources_identical']
tools={k:Path(v['path']) for k,v in old['tools'].items()}
for k,p in tools.items():assert pin(p)==old['tools'][k]
closure=load('no_call_parent_closure',OLD/'tools-prep/workspace_runner.py');closure.ROOT=W;paths=set(closure.source_paths())|{W/x['path'] for x in json.loads((W/'tests/fixtures/corpus-fingerprint.json').read_text())['files']}
def sources():return [dict(path=str(p.relative_to(W)),bytes=p.stat().st_size,sha256=pin(p)['sha256']) for p in sorted(paths)]
before=sources();assert before==n['source_manifest_before'];inputs={CLI,native,oldp,Path(__file__).resolve(),OLD/'tools-prep/guard.py',OLD/'tools-prep/target_scan.py',OLD/'tools-prep/workspace_runner.py',*tools.values()};jars=[]
for leg in ['javac23','javac8']:
 for name in ['FY','FX','FO']:
  p=Path(old['original_compiles'][leg]['jar_classes'][name]['path']);assert pin(p)==old['original_compiles'][leg]['jar_classes'][name]
  cp=next(row for row in old['original_compiles'][leg]['class_pins'] if Path(row['path']).name==name+'.class')
  with zipfile.ZipFile(p) as z:
   assert z.namelist()==[name+'.class'];data=z.read(name+'.class')
  assert len(data)==cp['bytes'] and hashlib.sha256(data).hexdigest()==cp['sha256'];jars.append((leg,name,p));inputs.add(p)
  f=W/'openspec/evidence/java-syntax-2026-10-05/return-effectful-finally-patrol/fixture'/(name+'.java');original=next(x for x in old['original_compiles'][leg]['source_pins'] if Path(x['path']).name==name+'.java');assert {k:pin(f)[k] for k in ['bytes','sha256']}=={k:original[k] for k in ['bytes','sha256']};inputs.add(f)
  for rt in ['java8','java23']:
   q=next(x for x in old['commands'] if x['label']==f'{leg}-{rt}-original-{name}');assert q['exit_code']==0;raw=Path(q['streams']['stdout']['path']);assert pin(raw)==q['streams']['stdout'];assert raw.read_bytes()==bytes.fromhex(old['oracle_hex'][name]);inputs.add(raw)
ip=[pin(p) for p in sorted(inputs)];g=load('no_call_parent_guard',OLD/'tools-prep/guard.py');scan=load('no_call_parent_scan',OLD/'tools-prep/target_scan.py');g.ROOT=W;g.OUT=O;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.target_bytes=lambda:scan.target_bytes(W);g.expected_test_summaries=lambda _i,_d:None;g.command_stream=pin;g.ENV_VALUES={}
r=dict(schema='effectful-finally-after-no-call-screen-v1',status='running',scope='All FY/FX/FO methods retained; paired real javac8 and javac23 release8 whole-source compilation. FY/FO main replay only when compiled, exact saved original oracle; FX expected still missing return. Not full parent behavioral coverage.',native_receipt=pin(native),frozen_cli=n['frozen_cli'],prior_screen=pin(oldp),source_manifest_before=before,inputs_before=ip,default_stack=True,guards=dict(free_bytes=5*1024**3,target_bytes=1024**3),commands=[],cases={})
def save():(O/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
def run(label,args,expected):
 args=[str(x) for x in args];env={'HOME':'/home/lordcasser','PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}
 if Path(args[0]) in tools.values():env.update(JAVA_HOME=str(Path(args[0]).parent.parent),PATH=str(Path(args[0]).parent)+':/usr/bin:/bin')
 q=g.run_command(len(r['commands'])+1,args,env);q.update(label=label,expected_exit=expected);r['commands'].append(q);save();assert q['exit_code']==expected and q['guard_stop'] is None;return q
save()
try:
 for leg,name,jar in jars:
  q=run(f'{leg}-current-whole-source-{name}',[CLI,'class-source','--input',jar,'--class',name,'--policy','plain-jar','--release','8','--format','json','--evidence','all','--budget','elapsed_millis=10000'],0);doc=json.loads(Path(q['streams']['stdout']['path']).read_text());assert len(doc['methods'])=={'FY':5,'FX':6,'FO':5}[name];dest=O/f'{leg}-{name}';dest.mkdir();source=dest/(name+'.java');source.write_bytes(doc['text'].encode());classes=dest/'classes';classes.mkdir();empty=dest/'empty-sourcepath';empty.mkdir();methods=[]
  for method in doc['methods']:
   out=method['outcome'];report=out.get('report',{});methods.append(dict(index=method['item']['index'],name=method['item']['name']['escaped'],descriptor=method['item']['descriptor']['escaped'],identity=method['item']['identity'],outcome=out['kind'],text=report.get('text'),diagnostics=report.get('diagnostics'),regions=report.get('regions')))
  if name=='FY':
   body=next(m for m in methods if m['name']=='noCall')['text'];assert '@bytecode' not in body and 'finally {' in body and body.count('return ')==2
  javac=tools[leg];flags=['--release','8','-Xlint:-options'] if leg=='javac23' else ['-source','8','-target','8'];expected=1 if name=='FX' else 0;c=run(f'{leg}-compile-exact-current-generated-{name}',[javac,*flags,'-g:none','-classpath',classes,'-sourcepath',empty,'-d',classes,source],expected);diagnostic=Path(c['streams']['stderr']['path']).read_bytes();assert source.read_bytes()==doc['text'].encode();runs=[]
  if expected==1:assert b'missing return' in diagnostic.lower()
  else:
   for rt in ['java8','java23']:
    q=run(f'{leg}-{rt}-rebuilt-main-{name}',[tools[rt],'-Xverify:all','-cp',classes,name],0);assert Path(q['streams']['stdout']['path']).read_bytes()==bytes.fromhex(old['oracle_hex'][name]);assert not Path(q['streams']['stderr']['path']).read_bytes();q['oracle_exact']=True;runs.append(len(r['commands']));save()
  r['cases'][leg+'/'+name]=dict(input_jar=pin(jar),generated_source=pin(source),method_count=len(doc['methods']),methods=methods,compile_exit=c['exit_code'],compile_missing_return=expected==1,source_unchanged=True,generated_runtime_commands=len(runs),runtime_command_indices=runs,rebuilt_classes=[pin(p) for p in sorted(classes.glob('*.class'))]);save()
 assert len(r['commands'])==20;r['status']='captured_twenty_command_FY_FO_rebuilt_main_success_FX_compile_refusal'
except BaseException as e:r['status']='failed_raw_preserved';r['error']=repr(e)
finally:
 r.update(source_manifest_after=sources(),inputs_after=[pin(p) for p in sorted(inputs)],target_absent=not (W/'target').exists(),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());r['sources_identical']=r['source_manifest_after']==before;r['inputs_identical']=r['inputs_after']==ip
 if not r['sources_identical'] or not r['inputs_identical'] or not r['target_absent']:r['status']='failed_integrity'
 save()
print(r['status'],len(r['commands']));raise SystemExit(0 if r['status']=='captured_twenty_command_FY_FO_rebuilt_main_success_FX_compile_refusal' else 1)
