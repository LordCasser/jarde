# NoCall 效果化 finally 实现阶段证据包

本包汇集多阶段、不同源码快照的历史执行证据。各阶段保留自己的 execution 收据、raw、源码快照和输入 pin；不得把某阶段结果解释为另一阶段结果。

实现阶段存在通过、拒绝和资源保护停止等不同结果。完整本地 native 批次的资源保护终止仍作为失败/中断历史保留；后续 continuation 是独立的最终收据。FY/FO 的本轮配对原类与生成源码运行验证通过；FX 两个生成源码编译命令返回 1 且未运行。screen 的预期就是混合结果，不以全部命令成功作为打包条件。

先前红基线包以外部路径、大小、SHA 和 payload 数引用，不重复展开。最终绑定记录 product head 02de294f7af2d0798e33d52ce5474e60efe17b03、CLI SHA-256 fd7b33ce0411854e480186c7ade82ecc21d4401b79d1a0b1bd0d5c7774bbff25。CLI/JDK/Rust 可执行文件不打包；相关非二进制脚本、Java 源/driver/oracle、原始与重建 Java class/JAR、runner/helper 和 source-tree 原始绑定按各自收据 pin 收录。

清单本身作为 tar 内一个 member。payload 数不含清单；tar 总 member 数为 payload_count + 1。
