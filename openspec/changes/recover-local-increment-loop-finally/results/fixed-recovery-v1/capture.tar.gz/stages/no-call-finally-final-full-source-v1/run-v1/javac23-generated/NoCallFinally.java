// jarde: presentation of `NoCallFinally` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class NoCallFinally extends java.lang.Object {
    public NoCallFinally() {
        // @method <init>()V
        // @declaration a constructor of `NoCallFinally`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int noCall(int[] arg0) {
        // @method noCall([I)I
        // @declaration a static method of `NoCallFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int local1;
        int[] local2;
        int local3;
        int local4;
        local1 = 0;
        local2 = arg0;
        local3 = local2.length;
        local4 = 0;
        while (local4 < local3) {
            int local5 = local2[local4];
            try {
                if (local5 == 3) {
                    int local6 = local1 + 7;
                    return local6;
                }
            } finally {
                local1 = local1 + 100;
            }
            local4 = local4 + 1;
        }
        return local1;
    }
}
