from pathlib import Path
import json,re,hashlib,zipfile,stat,datetime
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=B/'CORE';N=C/'no-call-finally-final-full-source-v1/run-v1';P=C/'effectful-finally-after-no-call-screen-v1/run-v1';R=Path('/home/lordcasser/.codex/worktrees/local-increment-finally/jarde');D=C/'no-call-finally-final-product-source-binding-v1';OUT=N.parent/'independent-final-source-parent-review-v1.json';assert not OUT.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 b=Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
checks=0;errors=[]
def ck(v,label):
 global checks
 checks+=1
 if not v:errors.append(label)
seen={}
def verify(row,label):
 key=(row['path'],row['bytes'],row['sha256'])
 if key not in seen:
  p=Path(row['path']);ck(p.is_file(),label+' exists')
  if p.is_file():
   b=p.read_bytes();ck((len(b),sha(b))==(row['bytes'],row['sha256']),label+' bytes/hash');seen[key]=True
 return Path(row['path']).read_bytes()
def recursive(v,label):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys() and Path(v['path']).is_absolute():verify(v,label)
  for x in v.values():recursive(x,label)
 elif isinstance(v,list):
  for x in v:recursive(x,label)
n=json.loads((N/'execution.json').read_text());p=json.loads((P/'execution.json').read_text());bind=json.loads((D/'final-source-cli-head-binding.json').read_text());native=json.loads(verify(n['native_receipt'],'bound native receipt'));old=json.loads((C/'effectful-finally-current-screen-v1/run-v1/execution.json').read_text());control=json.loads((C/'no-call-finally-independent-control-v1/run-v1/execution.json').read_text())
rawpins=[]
for label,d,count,failed in [('NoCall',n,10,[]),('parent',p,20,[6,16])]:
 ck(len(d['commands'])==count,label+' actual command count')
 ck([x['index'] for x in d['commands'] if x['exit_code']!=0]==failed,label+' expected actual nonzero subset')
 ck(all(x['exit_code']==1 for x in d['commands'] if x['index'] in failed),label+' genuine compile1')
 ck(d['source_manifest_before']==d['source_manifest_after'] and len(d['source_manifest_before'])==4929,label+' source4929 stable')
 ck(d['inputs_before']==d['inputs_after'] and d['inputs_identical'] and d['sources_identical'],label+' closed inputs stable')
 ck(d['default_stack'] and d['target_absent'],label+' defaultstack targetabsent')
 ck(d['guards']=={'free_bytes':5368709120,'target_bytes':1073741824},label+' guard5GiB/1GiB')
 recursive(d['inputs_before'],label+' inputpin');recursive(d.get('legs',d.get('cases')),label+' generated pins')
 for c in d['commands']:
  ck(c['guard_stop'] is None and c['peak_target_bytes']<1073741824 and c['free_bytes_after']>=5368709120,label+' actual guard '+str(c['index']))
  for row in c['streams'].values():verify(row,label+' raw');rawpins.append(row)
ck(len(rawpins)==len({x['path'] for x in rawpins})==60,'60 unique raw for30commands')
ck(n['frozen_cli']==p['frozen_cli']==bind['frozen_cli'],'same final CLI pin')
cli=verify(n['frozen_cli'],'external final CLI');ck(sha(cli)=='fd7b33ce0411854e480186c7ade82ecc21d4401b79d1a0b1bd0d5c7774bbff25' and len(cli)==59902896,'actual final CLI exact fd7b')
ck(stat.S_IMODE(Path(n['frozen_cli']['path']).stat().st_mode)==0o555,'CLI0555')
ck(bind['product_head']=='02de294f7af2d0798e33d52ce5474e60efe17b03' and bind['source_count']==4929 and bind['all_source_git_blobs_match'],'02de binding metadata')
ck(n['native_receipt']==p['native_receipt']==bind['source_receipt'],'both replays bind same actual native')
ck(n['source_manifest_before']==p['source_manifest_before']==native['source_manifest_before']==native['source_manifest_after'],'native source closure equal all replay4929')
manifest={r['path']:r for r in n['source_manifest_before']};rows={r['path']:r for r in bind['rows']};ck(len(rows)==len(manifest)==4929 and set(rows)==set(manifest),'exact bound4929 paths')
tree={}
for item in (D/'source-head-tree.raw').read_bytes().split(b'\0'):
 if item:
  header,name=item.split(b'\t',1);mode,kind,oid=header.decode().split();tree[name.decode()]=(mode,kind,oid)
ck(set(tree)==set(rows),'saved tree exact4929')
treecmd=json.loads((D/'source-head-tree.argv.json').read_text());argv=treecmd['argv'];ck(treecmd['exit_code']==0 and argv[:6]==['git','ls-tree','-r','-z',bind['product_head'],'--'] and set(argv[6:])==set(rows),'saved exact commit tree argv')
for name,row in rows.items():
 ck((row['bytes'],row['sha256'])==(manifest[name]['bytes'],manifest[name]['sha256']) and tree[name]==(row['mode'],'blob',row['git_blob']),'tree manifest '+name)
 b=(R/name).read_bytes();ck((len(b),sha(b))==(row['bytes'],row['sha256']) and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_blob'],'actual source bytes/blob '+name)
# Classfile method table read in Python; no javap/native execution.
def methods(data):
 at=8
 def u(n):
  nonlocal at
  x=int.from_bytes(data[at:at+n],'big');at+=n;return x
 cp=[None];total=u(2)
 while len(cp)<total:
  tag=u(1)
  if tag==1:
   size=u(2);cp.append(data[at:at+size].decode());at+=size
  elif tag in (3,4):cp.append(None);at+=4
  elif tag in (5,6):cp.extend([None,None]);at+=8
  elif tag in (7,8,16,19,20):cp.append((tag,u(2)))
  elif tag in (9,10,11,12,17,18):cp.append((tag,u(2),u(2)))
  elif tag==15:cp.append((tag,u(1),u(2)))
  else:raise ValueError(tag)
 u(2);u(2);u(2);ni=u(2);at+=2*ni
 def attrs():
  nonlocal at
  for _ in range(u(2)):u(2);size=u(4);at+=size
 for _ in range(u(2)):u(2);u(2);u(2);attrs()
 out=[]
 for _ in range(u(2)):
  u(2);name,desc=cp[u(2)],cp[u(2)];attrs();out.append((name,desc))
 return out
method_evidence=[];jarpins=[];runtime_evidence=[]
for label,d,groups in [('NoCall',n,n['legs']),('parent',p,p['cases'])]:
 for key,case in groups.items():
  leg=key.split('/')[0];klass='NoCallFinally' if label=='NoCall' else key.split('/')[1];want=2 if label=='NoCall' else (6 if klass=='FX' else 5)
  jar=case.get('frozen_jar',case.get('input_jar'));verify(jar,'input originaljar');jarpins.append(jar)
  with zipfile.ZipFile(jar['path']) as z:
   ck(z.namelist()==[klass+'.class'],'one unchanged original class jar '+key);original=z.read(klass+'.class')
  opath=R/('tests/fixtures/recover-local-increment-loop-finally/'+('v8' if leg=='javac23' else 'v8-javac8')+'/NoCallFinally.class') if label=='NoCall' else C/('effectful-finally-current-screen-v1/run-v1/'+leg+'-original-classes/'+klass+'.class')
  ck(original==opath.read_bytes(),'original class jar bytes '+key)
  clis=[c for c in d['commands'] if c['argv'][0]==n['frozen_cli']['path'] and c['argv'][c['argv'].index('--input')+1]==jar['path']];ck(len(clis)==1,'exact CLI input '+key);cmd=clis[0];doc=json.loads(Path(cmd['streams']['stdout']['path']).read_text());text=doc['text'].encode();source=verify(case['generated_source'],'full generatedsource')
  ck(source==text,'complete report.text byteexact '+key);ck(case['method_count']==len(doc['methods'])==want,'whole method count '+key)
  ids=[(m['item']['name']['escaped'],m['item']['descriptor']['escaped']) for m in doc['methods']];ck(ids==methods(original),'physical original method table preserved '+key)
  targetcomp=[c for c in d['commands'] if c['argv'][-1]==case['generated_source']['path']];ck(len(targetcomp)==1,'one complete source compile '+key);comp=targetcomp[0]
  ck(comp['argv'][0].endswith('/javac') and (('/jdk23/' in comp['argv'][0] and '--release' in comp['argv']) if leg=='javac23' else ('/jdk8/' in comp['argv'][0] and '-source' in comp['argv'] and '-target' in comp['argv'])),'real matching compiler leg '+key)
  cp=comp['argv'][comp['argv'].index('-classpath')+1];sp=comp['argv'][comp['argv'].index('-sourcepath')+1];dest=comp['argv'][comp['argv'].index('-d')+1]
  ck(cp==dest and str((N if label=='NoCall' else P)) in dest and not list(Path(sp).rglob('*.java')),'fresh compiledonly classpath/empty sourcepath '+key)
  info=[]
  for m in doc['methods']:
   r=m['outcome'].get('report',{});info.append({'name':m['item']['name']['escaped'],'descriptor':m['item']['descriptor']['escaped'],'wrapper_kind':m['outcome']['kind'],'quality':r.get('quality'),'representation':r.get('representation'),'content':r.get('content'),'fallbacks':r.get('fallbacks'),'all_regions_structured':all(x['structured'] for x in r.get('regions',[])),'bytecode_quote': '@bytecode' in r.get('text',''),'method_identity':m['item']['identity']})
  if klass!='FX':ck(comp['exit_code']==0 and all(x['quality']=='structured' and x['representation']=='java' and x['fallbacks']==[] and not x['bytecode_quote'] for x in info),'actual complete structured/java '+key)
  else:
   err=Path(comp['streams']['stderr']['path']).read_text();ck(comp['exit_code']==1 and 'missing return statement' in err,'actual FX missingreturn '+key);ck(case['runtime_command_indices']==[] and case['generated_runtime_commands']==0,'no false FX rebuilt runtime '+key);ck({x['name'] for x in info if x['bytecode_quote']}=={'finContinue','finReturn','finBreak'},'actual FX quoted methods '+key)
  method_evidence.append({'case':label+'/'+key,'input_jar':jar,'original_class':pin(opath),'generated_source':case['generated_source'],'compile_command':comp['index'],'compile_exit':comp['exit_code'],'methods':info})
  for c in d['commands']:
   if Path(c['argv'][0]).name!='java':continue
   if label=='NoCall':match=c['label'].startswith(leg+'-')
   else:match=c['argv'][-1]==klass and c['label'].startswith(leg+'-')
   if not match:continue
   args=c['argv'];cpath=args[args.index('-cp')+1].split(':');ck('-Xverify:all' in args and all(str(N if label=='NoCall' else P) in x and '.jar' not in x and ('generated' in x if label=='NoCall' else '/'+leg+'-'+klass+'/classes' in x) for x in cpath),'rebuilt-only runtime classpath '+label+key+str(c['index']))
   outbytes=Path(c['streams']['stdout']['path']).read_bytes();errbytes=Path(c['streams']['stderr']['path']).read_bytes();expected=Path(control['commands'][2]['streams']['stdout']['path']).read_bytes() if label=='NoCall' else bytes.fromhex(old['oracle_hex'][klass]);ck(outbytes==expected and errbytes==b'','actual immutable oracle '+label+key+str(c['index']))
   runtime_evidence.append({'group':label,'case':key,'command':c['index'],'stdout_bytes':len(outbytes),'stdout_sha256':sha(outbytes),'stdout_utf8':outbytes.decode(),'classpath':cpath})
ck(len(runtime_evidence)==12 and sum(x['group']=='NoCall' for x in runtime_evidence)==4 and all(x['stdout_bytes']==84 for x in runtime_evidence if x['group']=='NoCall'),'4NoCall84B plus8parent runtime')
# Immutable NoCall driver bytes bound to earlier original-control capture.
driver=R/'tests/fixtures/recover-local-increment-loop-finally/NoCallFinallyProbe.java';old_driver=next(x for x in control['inputs_before'] if x['path'].endswith('NoCallFinallyProbe.java'));verify(old_driver,'original driver pin');ck(pin(driver)['sha256']==old_driver['sha256'],'unchanged driver bytes since original control')
for c in n['commands']:
 if c['argv'][-1]==str(driver):ck('generated/classes' in c['argv'][c['argv'].index('-classpath')+1] and 'original' not in c['argv'][c['argv'].index('-classpath')+1],'driver compile rebuiltonly '+str(c['index']))
# Original FY/FO compiler class and Java sources remain those of the historical capture.
originalsourcepins=[]
for leg in ['javac23','javac8']:
 for row in old['original_compiles'][leg]['source_pins']+old['original_compiles'][leg]['class_pins']:
  verify(row,'historical parent original pin');originalsourcepins.append(row)
report={'schema':'no-call-finally-final-source-parent-independent-review-v1','status':'accepted_fixed_fixture_rebuild_and_parent_screen_with_explicit_FX_failures' if not errors else 'rejected','checks':checks,'errors':errors,'product_head':bind['product_head'],'source_count':4929,'source_binding':pin(D/'final-source-cli-head-binding.json'),'source_tree':pin(D/'source-head-tree.raw'),'source_tree_argv':pin(D/'source-head-tree.argv.json'),'native_receipt':n['native_receipt'],'frozen_cli':n['frozen_cli'],'NoCall_receipt':pin(N/'execution.json'),'parent_receipt':pin(P/'execution.json'),'commands':30,'raw_streams':60,'raw_pins':rawpins,'additional_unique_receipt_pins_reopened':len(seen),'methods':method_evidence,'runtime_evidence':runtime_evidence,'original_parent_source_class_pins':originalsourcepins,'NoCall_frozen_driver':pin(driver),'NoCall_old_original_control':pin(C/'no-call-finally-independent-control-v1/run-v1/execution.json'),'scope_correction':'Actual new FY and FO JSONs each have5methods, all quality=structured/representation=java/fallbacks=[] and no@bytecode. Their complete unchanged report.text compiles on truejavac8 and JDK23release8 and each rebuilt class runs on bothJava8/23 with old exactoracle. The earlier warning that FY/FO retain quotes was not an actual finding and is superseded by these raw facts. FXfinContinue/finReturn/finBreak remain mixed/fallback/quoted; finReturn explanation_only and both wholeFXjavac failmissingreturn, noFX rebuilt runtime.','accepted_scope':'IsolatedNoCall:2complete source compiles+2unchanged driver compiles+4rebuilt-only84B oracles. ParentFY/FO:4complete source compiles+8isolatedmain oracles. FX:2honest whole-sourcecompilefailures preserved. This is fixedfixture evidence, not allfinally/globalcorpus/JADX comparison or parentOpenSpec completion; ownCI remains separate.','execution_boundary':'Auditor only read files, parsed raw/classfile/ZIP and hashed source/CLI/JDK bytes in purePython. No product/native/Git/network execution or repository edits.','finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');b=OUT.read_bytes();print(json.dumps({'path':str(OUT),'bytes':len(b),'sha256':sha(b),'checks':checks,'errors':errors}))
