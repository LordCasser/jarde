from pathlib import Path
import json,re,hashlib,datetime
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE');H=B/'no-call-finally-actual-region-probe-v3';V=B/'no-call-finally-actual-facts-probe-v2';out=H/'independent-dynamic-scope-addendum-v1.json';assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 b=Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
d=json.loads((H/'execution.json').read_text());v=json.loads((V/'execution.json').read_text());errs=[];checks=0
def ck(x,label):
 global checks
 checks+=1
 if not x:errs.append(label)
ck(len(d['commands'])==2 and [x['exit_code'] for x in d['commands']]==[0,0],'actual2commands all0')
ck(d['commands'][0]['argv']==v['commands'][0]['argv'] and d['commands'][1]['argv']==['cargo','clean'],'same exact test andclean')
ck(d['source_manifest_before']==d['source_manifest_after'] and len(d['source_manifest_before'])==4924,'4924 beforeafter')
ck(d['probe_fixture_inputs_before']==d['probe_fixture_inputs_after']==v['probe_fixture_inputs_before'],'unchanged original fixturepins')
ck(d['default_stack'] is True and d['target_absent'] is True,'defaultstack targetabsent')
rawpins=[]
for c in d['commands']:
 ck(c['guard_stop'] is None and c['peak_target_bytes']<1073741824 and c['free_bytes_after']>=5368709120,'actual guard'+str(c['index']))
 for row in c['streams'].values():
  b=Path(row['path']).read_bytes();ck(len(b)==row['bytes'] and sha(b)==row['sha256'],'raw '+row['path']);rawpins.append(row)
s=Path(d['commands'][0]['streams']['stdout']['path']).read_text();ck(re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',s)==[('1','0','0')],'actual1/0/0')
terminal=re.findall(r'noCall: actual loop terminal_returns=\{\}, terminal_bodies=\{\}, outer_frame=([^\n]+)',s);frame=re.findall(r'noCall: actual for_header=None, body_frame=([^\n]+)',s)
ck(len(terminal)==len(frame)==2,'two actual region invocations')
ck(terminal[0]==terminal[1] and frame[0]==frame[1],'dual legs actualframes exact')
for text in frame:
 for wanted in ['boundary: Some(1)','scope: Some({1, 2, 5})','own_loop: Some(1)','loop_exit: Some(3)','exits: {3, 4}','continue_target: 1','own_finally: None','named_catch_rows: None']:ck(wanted in text,'actualframe '+wanted)
results=[]
for chunk in s.split('noCall: actual region result ')[1:]:
 result=chunk[:chunk.index('\njavac')].strip();results.append(result)
ck(len(results)==2 and results[0]==results[1],'both actualregionresults exact')
ck('form: While,' in results[0] and 'for_header: None,' in results[0] and 'UncoveredBlocks' in results[0] and re.search(r'blocks: \[\s+28,\s+46,',results[0]) is not None,'actualwhile and fallback28/46')
ck('claimed: {\n        0,\n        1,\n        2,\n        3,\n        5,\n    }' in results[0],'actualclaimed excludes4/6')
for leg in ['javac23','javac8']:
 normalized=lambda text:'\n'.join(x[x.index(leg+':')+len(leg)+2:] for x in text.splitlines() if leg+':' in x)
 old=Path(v['commands'][0]['streams']['stdout']['path']).read_text();ck(normalized(s)==normalized(old),leg+' canonical SSA effects samev2')
sm={r['path']:r for r in d['source_manifest_before']};oldsm={r['path']:r for r in v['source_manifest_before']};delta=sorted(p for p in sm if sm[p]!=oldsm[p]);ck(delta==['crates/jarde-java/src/guard.rs','crates/jarde-java/src/region.rs'],'v2 tov3 onlytesthelper prints rustdelta')
sourcepins=[]
for rel in ['crates/jarde-java/src/guard.rs','crates/jarde-java/src/region.rs','tests/fixtures/recover-local-increment-loop-finally/v8/NoCallFinally.class','tests/fixtures/recover-local-increment-loop-finally/v8-javac8/NoCallFinally.class']:
 p=H/'compiled-probe-source'/rel;b=p.read_bytes();ck((len(b),sha(b))==(sm[rel]['bytes'],sm[rel]['sha256']),'compiledmanifest '+rel);sourcepins.append(pin(p))
fixture=[p for p in sourcepins if p['path'].endswith('.class')]
for p in fixture:
 leg='javac8' if '/v8-javac8/' in p['path'] else 'javac23';orig=next(x for x in d['probe_fixture_inputs_before'] if '/'+leg+'-original/' in x['path']);ck(p['sha256']==orig['sha256'] and Path(p['path']).read_bytes()==Path(orig['path']).read_bytes(),'unchangedclass '+leg)
guard=(H/'compiled-probe-source/crates/jarde-java/src/guard.rs').read_text();region=(H/'compiled-probe-source/crates/jarde-java/src/region.rs').read_text();diff=(H/'compiled-probe-source/working.diff').read_text()
ck(diff.count('diff --git ')==2 and not any(x.startswith('-') and not x.startswith('---') for x in diff.splitlines()),'onlyaddedtwoRust diff')
ck('let recovered = crate::region::recover(' in guard and 'println!("noCall: actual region result {recovered:#?}")' in guard,'guardhelper actual recover print')
baseblobs={}
for part in diff.split('diff --git ')[1:]:
 rel=re.search(r'a/(\S+) b/',part).group(1);src=guard if rel.endswith('guard.rs') else region
 chunks=[]
 for hunk in re.split(r'\n@@[^\n]*\n',part)[1:]:
  added='\n'.join(x[1:] for x in hunk.splitlines() if x.startswith('+') and not x.startswith('+++'))+'\n';chunks.append(added)
 for add in chunks:
  ck(src.count(add)==1,'exactaddedspan '+rel)
  src=src.replace(add,'',1)
 b=src.encode();oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();prefix=re.search(r'index ([a-f0-9]+)\.\.',part).group(1);ck(oid.startswith(prefix),'reconstructedbaseblob '+rel);baseblobs[rel]=oid
 if rel.endswith('region.rs'):ck(all(add.startswith('        #[cfg(test)]\n') and 'println!' in add for add in chunks),'allregion addedsites cfgtest println')
report={'schema':'no-call-finally-dynamic-scope-independent-addendum-v1','status':'accepted_baseline_region_facts_only' if not errs else 'rejected','checks':checks,'errors':errs,'receipt':pin(H/'execution.json'),'raw_pins':rawpins,'source_snapshot':sourcepins,'source_diff':pin(H/'compiled-probe-source/working.diff'),'base_blobs_from_reversed_added_test_code':baseblobs,'source_count':4924,'source_delta_from_v2':delta,'actual_summary':{'passed':1,'failed':0,'ignored':0},'actual_dynamic_scope':{'terminal_returns':[],'terminal_bodies':[],'for_header':None,'form':'While','scope_nodes':[1,2,5],'scope_bci':[10,16,40],'boundary_node':1,'boundary_bci':10,'own_loop_node':1,'exit_node':3,'exit_bci':60,'loop_exit_nodes':[3,4],'loop_exit_bci':[60,28],'continue_target_node':1,'continue_target_bci':10,'claimed_nodes':[0,1,2,3,5],'uncovered_bci':[28,46],'body_frame_exact':frame[0],'both_legs_identical':True,'region_result_sha256':sha(results[0].encode())},
'phase_relationship':{'preflight_v1':'Previous audit preserves include-escape closure rejection before Cargo; no test execution.','facts_v2':pin(V/'independent-facts-audit-v1.json'),'facts_v2_status':'Not overwritten. Actual canonical/SSA/value/effects output normalized perleg matches v3 exactly.','region_v3':'cfgtest helper additionally invokes real region::recover on the same frozen class legs; region prints actual function return values and actual Frame. Reversing only test additions reproduces saved base Gitblob prefixes for both Rust files. Source4924 unchanged across run.','product_feature':'No production recovery implementation, fingerprint update, newCLI or feature/ownCI acceptance.'},
'promoted_from_previous_static_inference':['loop_terminal_returns actually empty for this region run, not merely inferred from28 exceptional outgoing.','Actual loop body Frame.scope excludes returnnode4 and handlernode6; terminal_bodies also empty, no namedcatch contribution.','Actual for_header is None, while form While and continue_target is headernode1/BCI10. Prior hypothetical updateBlock40 continuation classification does not describe current run.'],
'pending_implementation_risk':{'status':'not yet exercised by a new certificate','risk':'If future new certificate changes for_header to Some with update_bci54/update_block40, inherited outer continue_target may become node5/BCI40. That collides with inner finally boundary cleanup40. Loop jump classification could render false arm Continue and return next=None, while inner normal_completion_matches requires next40.','next_check':'Once a real complete certificate exists, observe actual new Frame/for_header and inner false-arm/next. Preserve cleanup40 as an inner semantic boundary before treating an edge as outer continue, or narrowly suppress only that certified internal edge classification. No global scope widening, fake namedcatch, framework or synthetic certificate should be introduced to simulate it.','current_boundary':'Current measured None/continue_target10 has no40collision. Do not report this hypothetical risk as current failure or as dynamically resolved.'},
'next_minimal_seam':'Implement only after parent-authorized planning: exact inner per-iteration SavedReturn proof and scopedreturn ownership for28; preserve lead16..22 outsideTry; privateTail54..60 and realjoin10 remain proposed. Currentregion evidence establishes required missing scope permission but does not validate future source emission.',
'limits':'Auditor used pure Python and cache writes only. No native/Git/repository edits. Test capture success proves baseline observation only; literal Recovered variant still contains Fallback28/46 and cannot be called successful source recovery.','finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');b=out.read_bytes();print(json.dumps({'path':str(out),'bytes':len(b),'sha256':sha(b),'checks':checks,'errors':errs}))
