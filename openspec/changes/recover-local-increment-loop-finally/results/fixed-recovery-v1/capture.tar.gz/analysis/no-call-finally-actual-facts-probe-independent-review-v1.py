from pathlib import Path
import json,re,hashlib,datetime
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE');H=B/'no-call-finally-actual-facts-probe-v2';out=H/'independent-facts-audit-v1.json';assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 b=Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
d=json.loads((H/'execution.json').read_text());errors=[];checks=0
def ck(x,label):
 global checks
 checks+=1
 if not x:errors.append(label)
ck(len(d['commands'])==2,'2 actual commands');ck([c['exit_code'] for c in d['commands']]==[0,0],'all0')
ck(d['source_manifest_before']==d['source_manifest_after'] and len(d['source_manifest_before'])==4924,'closed stable4924');ck(d['probe_fixture_inputs_before']==d['probe_fixture_inputs_after'],'fixture source beforeafter')
ck(d['default_stack'] is True and d['target_absent'] is True,'default stack exactclean')
ck(d['commands'][1]['argv']==['cargo','clean'],'exact clean argv');ck(d['commands'][0]['argv']==['cargo','test','-p','jarde-java','--lib','guard::finally_copy_tests::no_call_baseline_probes_real_increment_cleanup_and_loop_boundaries','--locked','--message-format=json-render-diagnostics','--','--exact','--nocapture'],'exact probe test argv')
rawpins=[]
for c in d['commands']:
 ck(c['guard_stop'] is None and c['peak_target_bytes']<1073741824 and c['free_bytes_after']>=5368709120,'actual guard '+str(c['index']))
 for row in c['streams'].values():
  raw=Path(row['path']).read_bytes();ck(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'raw pin '+row['path']);rawpins.append(row)
s=Path(d['commands'][0]['streams']['stdout']['path']).read_text();ck(re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',s)==[('1','0','0')],'actual summary1/0/0')
legs={}; expected_blocks=[(0,0,10,[],[1]),(1,10,16,[5,0],[3,2]),(2,16,28,[1],[5,4]),(3,60,62,[1],[]),(4,28,40,[2],[]),(5,40,60,[2],[1]),(6,46,54,[],[])]
for leg in ['javac23','javac8']:
 lines=[x[x.index(leg+':')+len(leg)+2:] for x in s.splitlines() if leg+':' in x]
 t='\n'.join(lines); blocks=[]
 for a,b,c,p,q in re.findall(r'canonical node=(\d+) block=CanonicalBlockId \{ bci: (\d+), path: \[\] \} end=(\d+) normal_predecessors=\[([^\]]*)\] normal_successors=\[([^\]]*)\]',t):
  nums=lambda v:[int(x.strip()) for x in v.split(',') if x.strip()]
  blocks.append((int(a),int(b),int(c),nums(p),nums(q)))
 ck(blocks==expected_blocks,leg+' exact7 canonical blocks')
 ck('NaturalLoop { header: 1, blocks: {1, 2, 5}, latches: {5}, irreducible: false }' in t,leg+' actual natural loop/latch')
 ck('from: CanonicalBlockId { bci: 28, path: [] }, to: CanonicalBlockId { bci: 46, path: [] }, kind: Exception { handler_ordinal: 0 }' in t,leg+' 28 actual exceptional edge')
 ck('SSA bci=54 op=Some(Increment { slot: 4, amount: 1 })' in t and 'SSA bci=57 op=Some(Transfer)' in t,leg+' fused54/57tail')
 ck(all('candidate row='+str(i)+' handler=CanonicalBlockId { bci: 46, path: [] } shape=false' in t for i in [0,1]),leg+' both actualcandidatefalse')
 effects=[{'bci':int(a),'handlers':b,'may_throw':c=='true'} for a,b,c in re.findall(r'effect bci=(\d+) handlers=\[([^\]]*)\] may_throw=(true|false)',t)]
 ck({e['bci'] for e in effects if e['may_throw']}=={5,19,53} and all(e['handlers']=='' for e in effects),leg+' actual effects no throwing protected instruction')
 ssa=[x for x in lines if x.startswith('SSA bci=')];phis=next(x for x in lines if x.startswith('actual phis'))
 for at,written in [(34,41),(40,43)]:ck(f'SSA bci={at} op=Some(Increment {{ slot: 1, amount: 100 }}) reads=[(Local(1), ValueId(2))] writes=[(Local(1), ValueId({written}))]' in t,leg+' normal iinc'+str(at))
 ck('SSA bci=48 op=Some(Increment { slot: 1, amount: 100 }) reads=[(Local(1), ValueId(7))] writes=[(Local(1), ValueId(28))]' in t,leg+' exceptional iinc7')
 ck('slot: Local(1), value: ValueId(7), inputs: [Value(ValueId(2)), Value(ValueId(41)), Value(ValueId(28))]' in phis,leg+' handlerphi inputs')
 legs[leg]={'canonical_blocks':blocks,'ssa_instruction_count':len(ssa),'effects':effects,'candidate_rows_false':[0,1],'actual_phis':phis,'ssa_return_and_increment_lines':[x for x in ssa if any(x.startswith('SSA bci='+str(at)+' ') for at in [28,29,31,32,34,37,39,40,46,48,51,53,54,57])],'normalized_facts_sha256':sha(t.encode())}
ck(legs['javac23']['normalized_facts_sha256']==legs['javac8']['normalized_facts_sha256'],'both actual normalized facts byte equal')
manifest={x['path']:x for x in d['source_manifest_before']};sg=H/'compiled-probe-source/guard.rs';g=sg.read_bytes();ck(sha(g)==manifest['crates/jarde-java/src/guard.rs']['sha256'] and len(g)==manifest['crates/jarde-java/src/guard.rs']['bytes'],'saved compiled guard manifest')
fixture=[]
for leg,dirname in [('javac23','v8'),('javac8','v8-javac8')]:
 p=H/('compiled-probe-source/'+dirname+'/NoCallFinally.class');b=p.read_bytes();original=next(x for x in d['probe_fixture_inputs_before'] if '/'+leg+'-original/' in x['path']);rp='tests/fixtures/recover-local-increment-loop-finally/'+dirname+'/NoCallFinally.class'
 ck(b==Path(original['path']).read_bytes() and sha(b)==original['sha256']==manifest[rp]['sha256'],'copied unchanged tree include '+leg);fixture.append({'compiled_copy':pin(p),'original':original,'manifest_path':rp})
probe=g.decode();at=probe.index('fn no_call_baseline_probes_real_increment_cleanup_and_loop_boundaries()');chunk=probe[at:probe.index('\n    #[test]',at)]
for assertion in ['assert!(cleanup_sequence(facts, &[48], false).is_none())','assert!(prove_conditional_return_finally(facts, &row).unwrap().is_none())','old.is_none()']:ck(assertion in chunk,'executed test assertion '+assertion)
diff=(H/'compiled-probe-source/working.diff').read_text();ck(diff.count('diff --git ')==1 and 'mod finally_copy_tests' in diff and not any(x.startswith('-') and not x.startswith('---') for x in diff.splitlines()),'test only added diff')
added='\n'.join(x[1:] for x in diff.splitlines() if x.startswith('+') and not x.startswith('+++'))+'\n';ck(probe.count(added)==1,'one exact added test span')
base=probe.replace(added,'',1).encode();oid=hashlib.sha1(b'blob '+str(len(base)).encode()+b'\0'+base).hexdigest();oldprefix=re.search(r'index ([0-9a-f]+)\.\.',diff).group(1);ck(oid.startswith(oldprefix),'reverse added test reconstructs saved baseblob')
v1=H.parent/'no-call-finally-actual-facts-probe-v1';v1err=(v1/'launcher.stderr.raw').read_text();ck('include escapes workspace' in v1err and 'closure.source_paths()' in v1err and not (v1/'execution.json').exists(),'v1 preflight lineage')
report={'schema':'no-call-finally-actual-facts-probe-independent-review-v1','status':'accepted_probe_facts_only' if not errors else 'rejected','checks':checks,'errors':errors,'receipt':pin(H/'execution.json'),'raw_pins':rawpins,'fixture_bindings':fixture,'saved_source':pin(sg),'saved_diff':pin(H/'compiled-probe-source/working.diff'),'saved_source_metadata':json.loads((H/'compiled-probe-source/execution.json').read_text()),'base_guard_reconstructed_git_blob':oid,'source_count':4924,'default_stack':True,'actual_summary':{'passed':1,'failed':0,'ignored':0},'target_absent':True,'actual_facts':legs,
'confirmed_three_questions':{'natural_loop':'Header node1/BCI10; natural nodes1,2,5=BCI10,16,40; latch node5/BCI40, irreducible=false.','return_leaf':'node4/BCI28 ends40; normal successors empty but actual canonical Exception(row0)→46.','fused_tail':'node5/BCI40 end60 contains iinc40/goto43 plus indexupdate54/goto57; actual normal successor node1/BCI10. No canonical block54.'},
'actual_test_assertions_not_printed':'Saved compiled test source asserts cleanup_sequence([48],false)==None, prove_conditional_return_finally(row0)==None and old prove_finally_copy==None on each leg, in addition to printed finally_copy_shape false for both rows. Successful exact test proves these assertions ran; the raw has no separate printed return value for those three assertions.',
'static_region_inferences_not_executed':[
 'Current loop_terminal_returns rejects a leaf with any canonical outgoing edge. Given actual28→46 row edge, it cannot admit28 through that existing path. Probe did not execute/print this private region function or actual Frame.scope.',
 'Frame::loop_body includes natural nodes plus proven transfers/terminal owners, so28 is expected absent unless another exact owner mechanism includes it. Finally_body outer.scope check would then prevent a naive inner Guard; actual runtime Frame/for_header remains unprobed.',
 'If adding an inner SavedReturn plan: lead16..22, protected22..34, boundary40, owned16/28/40/46, privateTail54..60 and Plan.join(real10) fit actual graph. Need exactloop terminal ownership permission before the child walk; do not fake named catch or own entirefor as Try.',
 'Counted-for update settled54 and enhanced-for presentation are still source-code hypotheses. Native region probe must show actual for_header/update and body_frame scope before relying on once-only tail update emission.'
 ],
'next_minimal_certificate_suggestions':[
 'Dedicated fixed-shape/iinc admission adjacent to current guard candidates, before scalable charged work; no generic Increment in finally_copy_shape or cleanup_sequence. True candidate still polls/charges all proof scans and final delivery.',
 'Bind actual rows0/1 and exact7node graph; take protected0? NO: row starts22. ArrayLength5/ArrayLoad19 may throw outsideTry. Protected22..34 contains only may_throw=false operations, while handler row covers onlystore46..48 and all increments lie outside rows.',
 'Prove c loop-header phi2 inputs initialstore17 and nonmatchincrement43; return increment34 writes41 and is not a backedge input. Indexphi5 separately inputs initial24 and update44. Save32/write40→load37/write42→return39 remains exact once-only value; c+7 must be rendered before cleanup.',
 'Do not equate handlerincrement input7 with loop input2: real handlerphi7 includes2,41 and its own increment output28. These conservative block-level exception/selfrow phis coexist with no takeable protectedthrow. Either close their exact semantic rows/edge origins in the narrow proof or explicitly prove no protected/self-binding instruction may throw; never replace actual SSA facts to force copy equality.',
 'Preserve caught Stack0 phi12→store46 local7/value27→load51/value29→throw53; no namedcatch or new throwable event is implied by catch-all structural rows.',
 'Keep saved-return and fallthrough boundaries distinct. Any exactloop owner metadata must be private/scoped to provedheader10/start16/rows0,1, charged before publication, and restore visited/checkpoint on refusal/stop. Build Try and tail atomically; Javafinally selects one c increment and outerloop update occurs once.',
 'Before implementation extend actualprobe only for missing regioncontext (loop_terminal_returns, body_frame scope, for_header/update_bci), not another compiler pipeline or generic framework. No feature implementation or fingerprint update is accepted by this receipt.'
 ],
'lineage':{'v1':'Preflight include escapes workspace error during closure.source_paths before Cargo dispatch; no completed native receipt. This is a guard-envelope/setup rejection, not a Rust test failure.','v2':'Copies same two original336B class bytes to tree-local include paths. Source4924 closes and is stable; workspace closure rule was not weakened. One cfg(test) probe and classcopies saved; no productionfeature/FPupdate/CLIbuild.'},'scope':'Only actual baseline Facts and exact probe1/0/0 accepted. No new production recovery, standalone rebuilt source success, newCLI, ownCI or full parent acceptance claimed. Pure Python/cache only.','finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');v=out.read_bytes();print(json.dumps({'path':str(out),'bytes':len(v),'sha256':sha(v),'checks':checks,'errors':errors}))
