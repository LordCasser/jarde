import pathlib,json,hashlib,struct,zipfile,datetime
B=pathlib.Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE');R=pathlib.Path('/home/lordcasser/.codex/worktrees/conditional-return-finally/jarde');O=pathlib.Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde/openspec/evidence/java-syntax-2026-10-05/return-effectful-finally-patrol');H=B/'effectful-finally-after-conditional-return-screen-v2/run-v1';out=B/'no-call-finally-next-slice-static-review-v1.json';assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 b=pathlib.Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def decode(data):
 pos=8
 def u(n):
  nonlocal pos
  v=int.from_bytes(data[pos:pos+n],'big');pos+=n;return v
 cp=[None];n=u(2)
 while len(cp)<n:
  t=u(1)
  if t==1:
   k=u(2);cp.append(data[pos:pos+k].decode());pos+=k
  elif t in (3,4):cp.append(None);pos+=4
  elif t in (5,6):cp.extend([None,None]);pos+=8
  elif t in (7,8,16,19,20):cp.append((t,u(2)))
  elif t in (9,10,11,12,17,18):cp.append((t,u(2),u(2)))
  elif t==15:cp.append((t,u(1),u(2)))
  else:raise ValueError(t)
 u(2);u(2);u(2);ni=u(2);pos+=2*ni
 def attrs():
  nonlocal pos
  a=[]
  for _ in range(u(2)):
   key=cp[u(2)];n=u(4);v=data[pos:pos+n];pos+=n;a.append((key,v))
  return a
 for _ in range(u(2)):u(2);u(2);u(2);attrs()
 for _ in range(u(2)):
  flags,name,desc=u(2),cp[u(2)],cp[u(2)];aa=attrs()
  if name!='noCall':continue
  raw=dict(aa)['Code'];stack,locals,size=struct.unpack_from('>HHI',raw);code=raw[8:8+size];at=8+size;cnt=int.from_bytes(raw[at:at+2],'big');rows=[struct.unpack_from('>HHHH',raw,at+2+8*i) for i in range(cnt)]
  return {'name':name,'descriptor':desc,'max_stack':stack,'max_locals':locals,'code_length':size,'code_sha256':sha(code),'code_hex':code.hex(),'rows':rows}
 raise ValueError('noCall absent')
receipt=json.loads((H/'execution.json').read_text());checks=[]
for c in receipt['commands']:
 for row in c['streams'].values():
  b=pathlib.Path(row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 checks.append({'index':c['index'],'exit_code':c['exit_code']})
assert [x['exit_code'] for x in checks]==[0,1,0,1,0,1,0,1]
classes=[]
for leg in ['javac23','javac8']:
 p=B/('effectful-finally-current-screen-v1/run-v1/'+leg+'-original-classes/FY.class');classes.append({'pin':pin(p),'decoded':decode(p.read_bytes())})
with zipfile.ZipFile(O/'fixture/fy.jar') as z:old=z.read('FY.class')
classes.append({'container':pin(O/'fixture/fy.jar'),'member':'FY.class','bytes':len(old),'sha256':sha(old),'decoded':decode(old)})
assert all(x['decoded']['code_length']==62 and x['decoded']['rows']==[(22,34,46,0),(46,48,46,0)] for x in classes)
reports=[]
for i in [1,5]:
 j=json.loads((H/(str(i)+'.stdout.raw')).read_text());m=next(x for x in j['methods'] if x['item']['name']['escaped']=='noCall')['outcome']['report']; reports.append({'stdout':pin(H/(str(i)+'.stdout.raw')),'method_wrapper_kind':next(x for x in j['methods'] if x['item']['name']['escaped']=='noCall')['outcome']['kind'],'quality':m['quality'],'regions':m['regions'],'fallbacks':m['fallbacks'],'text':m['text']})
d={'schema':'no-call-finally-next-slice-static-review-v1','status':'recommend_narrow_separate_slice_after_actual_facts_probe','scope':'Exploration only. Original source/classes, old saved presentation, current native-produced JSON and source seams read; pure Python class decode/raw pin checks only. No product change, toolchain, Git/JDK/Cargo/JADX run or implementation.',
'evidence':[pin(H/'execution.json'),pin(O/'fixture/FY.java'),pin(O/'results/jarde-FY.txt')]+[pin(R/('crates/jarde-java/src/'+f)) for f in ['guard.rs','region.rs','build.rs']],
'actual_screen':{'product_head':receipt['product_head'],'commands':checks,'raw_streams_reopened':16,'inputs_identical':receipt['inputs_identical'],'sources_identical':receipt['sources_identical'],'meaning':'Four CLI capture exit0, all four unchanged whole FY/FX generated Java compilations exit1. CLI exit0 is not noCall/full-class source recovery.'},'physical_classes':classes,'actual_noCall_reports':reports,
'bytecode_facts':{'protected_rows':'[22,34)->46 catch-all; [46,48)->46 handler binding self-protection only. Cleanup at34/40/48 is outside both protected regions.','return_chain':'28 iload1;29 bipush7;31 iadd;32 istore6;34 iinc1,100;37 iload6;39 ireturn.','fallthrough':'40 iinc1,100;43 goto54;54 iinc4,1;57 goto10.','exceptional':'46 astore7;48 iinc1,100;51 aload7;53 athrow.','loop':'0c=0;2..8 array/length/index init;10..13 index<length;16..20 element load/store5;22..25 x==3;60iload1/61ireturn. Null/array loads occur before the protected22..34 interval.','current_regions':'Actual published normal regions have blocks0; loop10/16/40; exit60. Blocks28(return) and46(handler) are live uncovered. Region publication is evidence of incomplete recovery, not the canonical instruction membership or first guard refusal.'},
'static_seams':[
 'guard::finally_copy_shape requires cleanup body to contain Invoke/Field/CheckCast. Increment alone cannot pass runs_code. resources dispatch places existing/new proofs behind finally_copy(), so noCall never reaches the fixed27 conditional-return proof through this route. A narrow iinc candidate must be considered before that gate or have its own dedicated dispatch; do not globally reclassify every pure local handler as an effectful finally.',
 'cleanup_sequence currently rejects Operation::Increment, and requires effects>0. Adding Increment globally without proving local-slot SSA incoming/outgoing relations is insufficient: iinc reads and rewrites local c, shared by the loop and exit return, while existing copy normalization describes stack-only producer roles. Prefer a narrow certificate for the one same-int-local increment, not a generic equivalence engine.',
 'New fixed27 proof requires one row, whole-method0 entry and5blocks. noCall has two rows, loop context, body22 and7publishedcanonical block identities. Extending only an opcode table or removing those guards is not a safe reuse.',
 'Minimal intended structure is a proved inner Try/Finally inside the existing array loop, retaining one saved return pair. Prove normal copy34/37/39, fallthrough copy40/43, handler46..54, binding row and c local flow; bounded body should stop at the fallthrough entry, then hand control to actual loop-update continuation. Existing private Plan fallthrough metadata/Continuation machinery may be reused if Facts confirms ownership and continuation.',
 'Actual row22 starts within published block16; saved-return producer28 is a separate published block. Native Facts must establish exact block16 lead16..22, which contains potentially-throwing array access, and whether40 includes54/57. Existing lead admission only accepts field/null leads, so a dedicated proved local-element lead or different narrowly-owned shape may be required. Do not move16..20 into try and do not invent block22 or54.',
 'Do not suppress uncovered-block/local-crosses diagnostics as the fix. They are consequences of missing ownership. Preserve cross-loop c binding and aliases first; then existing builder may emit c/local and saved return at32 under a bounded body. Try/cleanup/loop continuation must share rollback boundaries with existing finally checkpoints.'
 ],
'proposed_independent_fixture':{'class_name':'NoCallFinally','target_source':'public class NoCallFinally {\n  static int noCall(int[] xs) {\n    int c = 0;\n    for (int x : xs) {\n      try { if (x == 3) { return c + 7; } }\n      finally { c += 100; }\n    }\n    return c;\n  }\n}\n','constraints':'Copy original noCall body without helper calls, fields, counters, hooks or new finally behavior. Default constructor plus target only; separate fixed driver. Compile frozen source with true javac8 and javac23 --release8, pin real code/rows/SSA. No main-method slicing or removal of troublesome methods from final report.text.'},
'driver_oracle_design':{'driver':'NoCallFinallyProbe.java, standalone immutable source, package default, only calls noCall and prints deterministic result lines to original stdout; catches exactly NullPointerException for null case. No target reflection, patching, oracle recomputation or original-class fallback. Freeze bytes before Jarde implementation.','cases':[{'array':a,'expected':v} for a,v in [([],0),([1],100),([1,2],200),([3],7),([1,3],107),([1,2,3],207),([3,1],7),([3,3],7),([-3,0,3],207)] ]+[{'array':None,'expected':'NPE'}],'proposed_stdout':'0\n100\n200\n7\n107\n207\n7\n7\n207\nNPE\n','status':'Mathematically derived proposed oracle, NOT executed/frozen original proof. Root must establish actual dual-JVM original outputs before using it as acceptance.','observable_boundaries':'Nonmatching elements increment once and loop continues; first match terminates; c+7 is evaluated before that iteration cleanup. Moving cleanup before return-value calculation changes7/107/207 by100. Null preserves array evaluation before protected body.','limits':'Cleanup only mutates a dead local after return; driver cannot independently observe whether return-path cleanup actually ran, or whether rethrow-path local increment executed. No user-visible throwing operation exists inside22..34. Do not claim throw-helper, cleanup-count, suppressed-exception or overflow coverage. Those facts need analyzed byte mutations and full row/SSA certificate; adding a callback to make them observable changes this minimal fixture.'},
'root_next_actual_probe':['On current same-run MethodIr/Facts, record exact canonical per-block instruction lists/ends, normal+exception edges, loop header/backedge/exit ownership and all rows, before modifying production. Especially block16 boundary22 and block40 update54.','Record c parameter/local SSA merges at loop header, all three iinc definitions and consumers, save6/load6/return39 one-use chain, actual caught stack binding7 and rethrow identity; distinguish same slot from same incoming iteration value.','Show old finally_copy_shape returnsNone for the iinc-only handler, then identify next relevant guard/region seam with actual call path; do not label local diagnostic as first refusal.','Negative neighbors must remain complete/analyzable: change one iinc amount100→99; one slot to another initialized int (after confirming verifier state); return load6→load1; widen firstrow across34 or48 increment; retarget a protected branch to a valid alternative instruction with stack-compatible state. Probe completeness before asserting proof refusal.','Only after exact control/SSA map choose local inner certificate vs closed loop-owned form; keep unrelated candidate billing before any new charge and rerun unchanged oldP5. Include real late accepted-charge cancellation/deadline/count refusal before publication.'],
'acceptance_boundary':'A new separate OpenSpec child slice is appropriate; parent recover-return-through-effectful-finally stays broader. Keep FY original full source and all methods; after isolated success rescreen all FY/FX. FY.loopless/FO and continue/break remain compatibility controls; FX.finReturn is separate until actual evidence. Final independent whole-class report.text must compile unchanged under both compilers; unchanged driver compiles against rebuilt classes only and runs on both JVMs with no original JAR/class in classpath.',
'old_javap_boundary':'No saved FY javap file was located in inspected cache/evidence paths. Old saved jarde-FY.txt was read, and original old jar plus both fresh original compiler class bytes were independently decoded instead. This report does not claim a new javap execution or a missing historical javap file read.',
'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
out.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');raw=out.read_bytes();print(json.dumps({'path':str(out),'bytes':len(raw),'sha256':sha(raw)}))
