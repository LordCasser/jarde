import hashlib,importlib.util,json,os,subprocess
from pathlib import Path
P=Path(__file__).parent;ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
JAVAC=Path('/Users/lordcasser/Library/Java/JavaVirtualMachines/openjdk-23.0.1/Contents/Home/bin/javac')
G=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
S=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def pin(p):
 b=Path(p).read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert not (ROOT/'target').exists()
assert pin(G)['sha256']=='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
assert pin(S)['sha256']=='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
g=load(G,'guard');s=load(S,'scanner');g.ROOT=ROOT;g.OUT=P/'raw';g.OUT.mkdir();g.target_bytes=lambda:s.target_bytes(ROOT);g.command_stream=pin;g.expected_test_summaries=lambda i,b:None;g.ENV_VALUES={}
env={k:v for k,v in os.environ.items() if k not in ('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH')}
r=g.run_command(1,[str(JAVAC),'--release','8','-g','-encoding','UTF-8','-proc:none','-classpath',str(P/'classes'),'-sourcepath',str(P/'source'),'-d',str(P/'classes'),str(P/'source/HeaderBodyBoundaryControls.java')],env)
receipt=dict(status='root_compiled_real_ir_controls_no_target_execution' if r['exit_code']==0 else 'failed',command=r,source=pin(P/'source/HeaderBodyBoundaryControls.java'),compiler=pin(JAVAC),classes=[pin(p) for p in sorted((P/'classes').rglob('*.class'))],target_absent=not (ROOT/'target').exists(),target_code_executed=False)
(P/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));assert r['exit_code']==0 and r['guard_stop'] is None
