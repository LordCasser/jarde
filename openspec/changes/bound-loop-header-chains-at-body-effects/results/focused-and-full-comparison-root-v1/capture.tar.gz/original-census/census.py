#!/usr/bin/env python3
"""Read-only physical census of the frozen ComplexIf fixture bundle."""
from __future__ import annotations
import hashlib, importlib.util, json, os, stat, struct, zipfile
from pathlib import Path

BUNDLE = Path('/private/tmp/jarde-loop-header-body-boundary-public-tests-luna-v2-20261019')
FIX = BUNDLE / 'tests/fixtures/cf09-complex-if-body-boundary'
RECEIPT = Path('/private/tmp/jarde-testbreakincomplexif-baseline-root-v2-20261019/execution.json')
HELPER = Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
COMPARE = Path('/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
OUT = Path('/private/tmp/jarde-complex-if-body-boundary-fixture-census-luna-v1-20261019/review.json')

def need(ok, msg):
    if not ok: raise RuntimeError(msg)
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(p):
    b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(p.stat().st_mode)}
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def signed(data, at, width): return int.from_bytes(data[at:at+width], 'big', signed=True)
def branch_targets(code, bcis):
    """Decode JVM control transfers; report every target relative to opcode BCI."""
    out=[]; n=len(code)
    for bci in bcis:
        op=code[bci]
        if 0x99 <= op <= 0xa8 or op in (0xc6,0xc7):
            out.append({'bci':bci,'opcode':hex(op),'targets':[bci+signed(code,bci+1,2)]})
        elif op in (0xc8,0xc9):
            out.append({'bci':bci,'opcode':hex(op),'targets':[bci+signed(code,bci+1,4)]})
        elif op in (0xaa,0xab):
            p=bci+1
            while p % 4: p+=1
            default=bci+signed(code,p,4); targets=[default]
            if op==0xaa:
                low=signed(code,p+4,4); high=signed(code,p+8,4)
                need(high>=low and high-low<100000,'invalid tableswitch range')
                targets += [bci+signed(code,p+12+4*i,4) for i in range(high-low+1)]
            else:
                count=signed(code,p+4,4); need(0<=count<100000,'invalid lookupswitch size')
                targets += [bci+signed(code,p+12+8*i,4) for i in range(count)]
            out.append({'bci':bci,'opcode':hex(op),'targets':targets})
    valid=set(bcis)
    for row in out:
        need(all(t in valid for t in row['targets']),f"non-instruction branch target: {row}")
    return out

def main():
    h=module('classfile_helpers',HELPER); c=module('compare',COMPARE)
    receipt_bytes=RECEIPT.read_bytes(); need(sha(receipt_bytes)=='f3ef78d507b3e585b84c459fcbde577b1b4e0f864e2dbc74864782c1da19471e','receipt pin mismatch')
    receipt=json.loads(receipt_bytes); manifest=json.loads((FIX/'fixture-manifest.json').read_text())
    # Rebind copied provenance files to the accepted original capture, not just its local manifest.
    for rel, record in [('upstream/TestBreakInComplexIf.java', receipt['source_copy']),
                        ('caseplans.json', receipt['case_plan']),
                        ('driver/TestBreakInComplexIfDriver.java', receipt['driver_copy']),
                        ('runtime-bound-cwd.py', receipt['runtime_wrapper'])]:
        donor=Path(record['path']); copied=FIX/rel
        need(pin(donor)['bytes']==record['bytes'] and sha(donor.read_bytes())==record['sha256'],f'accepted source pin mismatch: {rel}')
        need(copied.read_bytes()==donor.read_bytes(),f'fixture provenance copy differs from accepted source: {rel}')
    need(Path(receipt['source']['path']).read_bytes()==(FIX/'upstream/TestBreakInComplexIf.java').read_bytes(),'upstream fixture differs from source checkout pinned by receipt')
    expected={x['path']:x for x in manifest['fixture_files']}
    actual={p.relative_to(FIX).as_posix():p for p in FIX.rglob('*') if p.is_file() and p.name!='fixture-manifest.json'}
    need(set(actual)==set(expected),f"fixture inventory differs: missing={sorted(set(expected)-set(actual))}, extra={sorted(set(actual)-set(expected))}")
    fixture_pins={}
    for rel,p in sorted(actual.items()):
        x=pin(p); need(x['bytes']==expected[rel]['bytes'] and x['sha256']==expected[rel]['sha256'],f'fixture pin mismatch: {rel}')
        fixture_pins[rel]=x
    total={'classes':0,'methods_with_code':0,'fields':0,'code_bytes':0,'instructions':0,'handlers':0,'branch_targets':0,'jsr_instructions':0,'classfile_bytes':0}
    profiles={}
    for profile in ('debug','no-debug'):
        rp=next(x for x in receipt['source_profiles'] if x['profile']==profile)
        tree=rp['class_tree']; need(len(tree)==3,f'{profile}: expected exactly three baseline classes')
        fixture_tree=FIX/profile/'class'; rows=[]; jar_name=f'{profile}-plain.jar'; jar_rows={}
        for rel,srcfact in sorted(tree.items()):
            donor=Path(srcfact['path']); fp=fixture_tree/rel; raw=fp.read_bytes()
            need(pin(donor)['bytes']==srcfact['bytes'] and sha(donor.read_bytes())==srcfact['sha256'],f'{profile} donor receipt pin mismatch {rel}')
            need(raw==donor.read_bytes(),f'{profile} fixture differs from accepted donor {rel}')
            parsed=h.parse_class_file(raw); cp=c.parse_class(fp)
            need(parsed['class_name']==cp['class_name']==rel[:-6],f'class identity mismatch {rel}')
            need(parsed['major']==cp['major'] and parsed['minor']==cp['minor'],f'version mismatch {rel}')
            need(parsed['methods']==cp['methods'],f'physical parsers disagree on methods {rel}')
            need([(f['name'],f['descriptor'],f['access']) for f in parsed['fields']]==cp['fields'],f'physical parsers disagree on fields {rel}')
            donor_fact=next(f for key,f in ((('outer_facts',rp.get('outer_facts')),('target_facts',rp.get('target_facts')),('point_facts',rp.get('point_facts')))) if f and f['class_name']==parsed['class_name'])
            need([(m['name'],m['descriptor'],m['access'],m['code']) for m in parsed['methods']]==[(m['name'],m['descriptor'],m['access'],m['code']) for m in donor_fact['methods']],f'receipt facts differ {rel}')
            method_rows=[]
            for m in parsed['methods']:
                code=m.get('code')
                if code is None: continue
                cb=bytes.fromhex(code['code_hex']); bcis=code['bcis']; branches=branch_targets(cb,bcis)
                jsr=sum(cb[b]==0xa8 or cb[b]==0xc9 for b in bcis)
                need(h.decode_bcis(cb)==bcis,f'BCI decode mismatch {rel}::{m["name"]}{m["descriptor"]}')
                method_rows.append({'name':m['name'],'descriptor':m['descriptor'],'access':m['access'],'code_bytes':len(cb),'instruction_count':len(bcis),'handler_count':len(code['rows']),'branch_target_count':sum(len(x['targets']) for x in branches),'jsr_instruction_count':jsr,'bcis':bcis,'handlers':code['rows'],'branches':branches})
                total['methods_with_code']+=1; total['code_bytes']+=len(cb); total['instructions']+=len(bcis); total['handlers']+=len(code['rows']); total['branch_targets']+=sum(len(x['targets']) for x in branches); total['jsr_instructions']+=jsr
            row=pin(fp); row.update({'donor_path':str(donor),'class_name':parsed['class_name'],'major':parsed['major'],'minor':parsed['minor'],'access':parsed['access'],'field_count':len(parsed['fields']),'method_count':len(parsed['methods']),'methods_with_code':method_rows})
            rows.append(row); total['classes']+=1; total['fields']+=len(parsed['fields']); total['classfile_bytes']+=len(raw)
            jar_rows[rel]=raw
        jar=FIX/jar_name
        with zipfile.ZipFile(jar) as z:
            names=sorted(n for n in z.namelist() if not n.endswith('/'))
            need(names==sorted(jar_rows),f'{profile} JAR entry inventory mismatch: {names}')
            for name in names:
                data=z.read(name); need(data==jar_rows[name],f'{profile} JAR bytes differ from tree: {name}')
                jar_rows[name]=data
        profiles[profile]={'classes':rows,'jar':pin(jar),'jar_entries':names,'jar_equals_profile_tree':True}
    out={'status':'independent_physical_fixture_census_passed','receipt':pin(RECEIPT),'receipt_status':receipt['status'],'helpers':{'classfile_helpers':pin(HELPER),'compare':pin(COMPARE)},'bundle':str(BUNDLE),'fixture_root':str(FIX),'manifest':pin(FIX/'fixture-manifest.json'),'audit_script':pin(Path(__file__).resolve()),'fixture_files':fixture_pins,'profiles':profiles,'totals':total}
    OUT.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'review':str(OUT),'sha256':sha(OUT.read_bytes()),'totals':total,'status':out['status']},sort_keys=True))
if __name__=='__main__': main()
