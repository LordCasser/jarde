# TestBreakInComplexIf 最终候选对照准备

这是私有的、尚未执行的 final-candidate collector/reviewer 适配。原始基线已经独立接受；这份准备没有调用候选 CLI、Jarde、JADX、JDK 或 Cargo，也没有改共享仓库。候选 CLI 路径和 SHA 必须由 root 在执行时提供。

适配基于已接受的 `TestContinueInLoop` final-candidate collector/reviewer 框架，并固定到 `TestBreakInComplexIf` 的完整原始基线：execution receipt SHA-256 为 `f3ef78d507b3e585b84c459fcbde577b1b4e0f864e2dbc74864782c1da19471e`，root marker SHA-256 为 `bb5ea6e8e7a7bb639876a037a5ae5e60ed38884724f1595721b16afc24a6490c`。marker 绑定了完整原始 outer/child/Point 输入、九个有界行为 case、JADX/Jarde API 证据和真实旧恢复缺口；reviewer 也固定校验它指向的独立审计 SHA `0637361277aeda897949b129a5d5665e151d103dd1a810a9bd1ed85cb6096f59`。

collector 复用已接受的原始/JADX字节和四个原始 VM oracle，不重跑那些工作。它对每个 `debug`/`no-debug`、`child`/`bundle-child`、`default`/`all` 组合分别请求 TestCls 和 Point，共 16 个 class-source API 格。它保存每格原始 JSON、whole-class 文本、方法文本和 SourceMap；每个 origin 必须落到该方法真实 Code BCI 且 UTF-8 byte span 有效，未映射的物理 BCI 会单独报告，不要求覆盖率达到 100%。`default` 与 `all` 的完整类文本、方法身份、质量、正文和 map 必须一致；整份 JSON 只允许沿用基线已出现的 evidence 差异路径。

每个 profile/form/evidence 组合把 API 分别返回的完整 TestCls 和 Point 源文件原字节复制后一起编译，8 个源组各尝试 javac 8 和 javac 23，共 16 个整组编译尝试。它不裁剪、不改写两个源文件。上游 outer/JUnit 源和原始 outer/child/Point class 树完整保留并固定；目标 class-source API 本身只产出 TestCls 和 Point，所以 compiler 输入是这两份完整输出，而不是另行拼入 outer 测试类。JDK 8 的框架依赖版本边界保留为实际结果，不预先认定编译成功或失败。

只有整组编译成功、target 与 Point 的二进制身份/版本/方法/字段/可见性都与原件匹配时才做 parentless 双 VM 观察和 wrong-CodeSource 控制。唯一允许单独记录的非源码元数据差异，是 Point 的 `this$0` 字段上仅 `ACC_SYNTHETIC` 一位的差异；原始 flags 和生成 flags 都完整保留，字段身份、类型及其余 flags 必须相同。其他方法、字段、访问级别或类库存变化都会使该编译根不具备 runtime eligibility。编译失败不伪造 VM 结果；每条真实失败及其 stdout/stderr 仍留在 receipt。目标测试不 structured 或运行 oracle 不一致会作为候选发现显示，不会被标成通过。

建议由 root 在候选 CLI 构建且 SHA 已知、workspace `target/` 不存在时执行：

```sh
python3 -B /private/tmp/jarde-testbreakincomplexif-final-candidate-prep-root-v4-20261019/collect_final.py \
  --out /private/tmp/<root-selected-fresh-output> \
  --cli /private/tmp/<root-selected-final-cli> \
  --cli-sha256 <root-supplied-64-character-sha256>

python3 -B /private/tmp/jarde-testbreakincomplexif-final-candidate-prep-root-v4-20261019/review.py \
  --receipt /private/tmp/<root-selected-fresh-output>/execution.json \
  --expected-cli-sha256 <same-root-supplied-sha256> \
  --out /private/tmp/<root-selected-fresh-review.json>
```

collector 自身执行时会校验 root 固定路径、候选 CLI SHA、5 GiB 可用磁盘、1 GiB target cap、空 cwd、30 秒 wrapper、固定 JDK/工具 pins、source closure、外部输入、driver/wrapper 与 generated output 的前后快照，并在 finally 再确认 `target/` 缺席。实际命令 raw stdout/stderr、argv、exit code、生成源码/类树都会留档。reviewer 独立重开这些 pins，核 API 输入/身份/映射、完整编译库存、parentless VM argv、错根拒绝和九 case 的 return/异常类型/stdout/input/after 状态。异常 message/stack 保留原始值，但比较 oracle 时不把 VM/debug 相关 message/stack 当成语义差异。

`static_preflight.py` 已在 `python3 -B` 下只读通过：重开接受基线，双 parser 核对两 profile 的 target+Point 四个 class，按原始 stdout 重解析 4 个原始 VM 的 9 行输出，并核对 16 个既有 API cell 的 whole-source 与 32 个方法 SourceMap。该静态 preflight 不等于候选验证。没有 candidate receipt、candidate Java 编译/运行、Rust 测试或最终验收结果。

## 文件

- `collect_final.py`：候选采集器，必须显式传入 root 选择的 CLI 与 SHA。
- `review.py`：独立收据审查器。
- `static_preflight.py`、`preflight.json`：只读、Python-only 的静态闭合检查。
- `adaptation.diff`：相对已接受 final-candidate 模板的完整脚本差异。
- `pins.json`：输入、工具、accepted baseline、原始类/JAR、驱动及准备文件 pins。


## v2 reviewer closure

审计器只跳过接受基线收据顶层三个历史 `source_pins_*` 工作区快照（before/after/after_finally）；基线收据、root marker、所有外部输入、原始 stdout/stderr、原始类/JAR、完整 source copies、API 输出和生成产物仍逐项重开。审计器还把实际上游 `TestBreakInComplexIf.java` 源文件加入精确 `external_input_pins` 路径集合，并要求与其余固定工具/来源路径完全相等。collector 的 tool path 列表去掉了同一独立审计文件的重复别名。

Root v3补齐FORMS常量，v2实际在输出目录创建前因NameError停止，零目标命令；未改变产品或原始/JADX基线。

Root v4移除从其它用例复制的driver字面量断言，保留已审驱动98419c8b…的精确SHA绑定与实际oracle；root再次读取确认inputSnapshot在invoke前、afterSnapshot在后。v3在输出目录创建前因旧字面量ValueError停止，零目标命令。
