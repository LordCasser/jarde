#!/usr/bin/env python3
"""Read-only reviewer for the frozen TestBreakInComplexIf final-candidate capture."""
from __future__ import annotations
import argparse, base64, hashlib, importlib.util, json, os, re, zipfile
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
BASE=Path('/private/tmp/jarde-testbreakincomplexif-baseline-root-v2-20261019')
BASE_SHA='f3ef78d507b3e585b84c459fcbde577b1b4e0f864e2dbc74864782c1da19471e'
BASE_REVIEW=BASE/'root-review.json'
BASE_REVIEW_SHA='bb5ea6e8e7a7bb639876a037a5ae5e60ed38884724f1595721b16afc24a6490c'
BASE_INDEPENDENT=Path('/private/tmp/jarde-testbreakincomplexif-baseline-independent-review-root-v3-20261019/review.json')
BASE_INDEPENDENT_SHA='0637361277aeda897949b129a5d5665e151d103dd1a810a9bd1ed85cb6096f59'
CASE_PLAN=Path('/private/tmp/jarde-testbreakincomplexif-baseline-prep-luna-v3-20261019/caseplans.json')
CASE_PLAN_SHA='732d70aad23c295762314fe165692520a0eb1f54fe93dbfd1b07c158331e5ae8'
SOURCE=Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestBreakInComplexIf.java')
CASE_PLAN_SOURCE=Path('/private/tmp/jarde-testbreakincomplexif-source-plan-luna-v2-20261019/upstream/TestBreakInComplexIf.java')
HISTORICAL_SOURCE_SNAPSHOT_KEYS=frozenset({'source_pins_before','source_pins_after','source_pins_after_finally'})
BASE_COLLECTOR=Path('/private/tmp/jarde-testbreakincomplexif-baseline-root-v2-20261019/collector.py')
BASE_COLLECTOR_SHA='52c6e4ad14a69bf6636ce3a4730deb2c392ca1930b889cb14ab5c7a91bf56e21'
CANDIDATE_COLLECTOR=Path('/private/tmp/jarde-testbreakincomplexif-final-candidate-prep-root-v4-20261019/collect_final.py')
CANDIDATE_COLLECTOR_SHA='5c879e71a96e4cbbcb9aba19a627a436161da3a2d3313339c980e36baba9a70c'
COMPARE_REL='openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
MANIFEST_REL='openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
MANIFEST_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL='openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL='openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
DEPENDENCY=Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018/execution.json')
DEPENDENCY_SHA='5a7d6572e600d19dc45d78030d0b12867bc742c4b014381fb5c7b059db171d35'
RUNTIME=BASE/'runtime-bound-cwd.py'
RUNTIME_SHA='bc917ec08e07ed462c18958f9a0d3b064b7d5bba3adc5fa41d9db49ff6c3de46'
UPSTREAM_SOURCE_SHA='8e31f1cbe056fee54e43bab414f1c3c5ad19803497a80844c20a1d5f50226d4f'
UPSTREAM_SOURCE_BYTES=1533
DRIVER=Path('/private/tmp/jarde-testbreakincomplexif-baseline-prep-luna-v3-20261019/driver/TestBreakInComplexIfDriver.java')
DRIVER_SHA='98419c8b279935d0b3f9bed1fb1a70a773c6cc19c80fc138d91cd9bf0fd5a1cf'
OUTER_INTERNAL='jadx/tests/integration/loops/TestBreakInComplexIf'
INTERNAL='jadx/tests/integration/loops/TestBreakInComplexIf$TestCls'
POINT_INTERNAL=INTERNAL+'$Point'
DOT='jadx.tests.integration.loops.TestBreakInComplexIf$TestCls'
POINT_DOT=DOT+'$Point'
PROFILES=('debug','no-debug'); FORMS=('child','bundle-child'); EVIDENCE=('default','all'); VMS=('javac8','javac23'); ROLES=('target','point')
CASE_NAMES=('source-check-first-map','source-check-complex-break','null-point-short-circuit','missing-first-key','last-allowed-index-99','exclusive-upper-bound-does-not-dereference-map','null-map-in-range','bounded-full-traversal','wrapped-start-breaks-immediately')
CASES=CASE_NAMES

def require(ok,msg):
    if not ok: raise AssertionError(msg)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def norm(x):
    if isinstance(x,dict): return {k:norm(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [norm(v) for v in x]
    return x
def pin(row,label):
    require(isinstance(row,dict) and {'path','bytes','sha256'}<=row.keys(),f'{label}: malformed file pin')
    original=Path(row['path']); require(not original.is_symlink(),f'{label}: symlink pin refused')
    p=original.resolve(strict=True); b=p.read_bytes()
    require(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],f'{label}: pin changed')
    return p
def pins(x,label='receipt'):
    found=[]
    if isinstance(x,dict):
        if {'path','bytes','sha256'}<=x.keys(): found.append((x,label)); return found
        for k,v in x.items(): found += pins(v,f'{label}.{k}')
    elif isinstance(x,list):
        for i,v in enumerate(x): found += pins(v,f'{label}[{i}]')
    return found
def accepted_baseline_immutable_pins(base):
    require({k for k in base if k.startswith('source_pins_')}==HISTORICAL_SOURCE_SNAPSHOT_KEYS,
            'accepted baseline historical source-snapshot schema changed')
    rows=[]
    for key,value in base.items():
        if key in HISTORICAL_SOURCE_SNAPSHOT_KEYS: continue
        rows.extend(pins(value,f'accepted original {key}'))
    return rows
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot import {path}')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def utf8bounds(s):
    out={0}; n=0
    for c in s: n+=len(c.encode('utf-8')); out.add(n)
    return out
def decode_bytes(xs): return bytes(xs).decode('utf-8','strict')
def parse_rows(raw):
    lines=raw.decode('utf-8','strict').splitlines(); require(len(lines)==len(CASES),f'expected {len(CASES)} rows, got {len(lines)}')
    rx=re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) target_stdout_b64=([^ ]*) after_b64=([^ ]*)$')
    dec=lambda s:base64.b64decode(s,validate=True).decode('utf-8','strict'); rows=[]
    for i,line in enumerate(lines):
        m=rx.fullmatch(line); require(m is not None,f'malformed CASE row: {line!r}')
        ix,name,inp,result,exc,msg,stack,out,after=m.groups(); require(int(ix)==i and name==CASES[i],f'case order mismatch at {i}')
        rows.append({'index':i,'name':name,'input':dec(inp),'result':dec(result),'exception_type':exc,'exception_message':dec(msg),'exception_stack':dec(stack),'target_stdout':dec(out),'after':dec(after),'raw':line})
    return rows
def proj(rows): return [{k:r[k] for k in ('index','name','input','result','exception_type','target_stdout','after')} for r in rows]
def parse_facts(compare,physical,path,label):
    a=compare.parse_class(path); b=physical.parse_class_file(Path(path).read_bytes())
    require(a['class_name']==b['class_name'] and a['major']==b['major'] and a['methods']==b['methods'],f'{label}: parser methods/Code disagree')
    require(sorted((f['name'],f['descriptor'],f['access']) for f in b['fields'])==sorted(a['fields']),f'{label}: parser fields disagree')
    a['access']=b['access']; require(len({(m['name'],m['descriptor']) for m in a['methods']})==len(a['methods']),f'{label}: duplicate methods')
    for m in a['methods']:
        c=m.get('code'); require(c is not None and c.get('bcis') and c['bcis'][0]==0 and c['bcis'][-1]<c['code_length'],f'{label}: invalid Code/BCIs')
    return a
def walk_commands(data, expected_env, output):
    cmds=data.get('commands',[]); by={x.get('index'):x for x in cmds}
    require(len(by)==len(cmds) and set(by)==set(range(1,len(cmds)+1)),'command index gaps/duplicates')
    labels=[x.get('label') for x in cmds]; require(None not in labels and len(labels)==len(set(labels)),'command labels missing/duplicated')
    for c in cmds:
        require(c.get('guard_stop') is None,f"guard stopped {c.get('label')}")
        require(Path(c.get('cwd','')).resolve()==ROOT.resolve(),f"command cwd differs from guarded workspace: {c.get('label')}")
        require(isinstance(c.get('peak_target_bytes'),int) and c['peak_target_bytes']<=1024**3,f"target cap exceeded: {c.get('label')}")
        require(isinstance(c.get('free_bytes_after'),int) and c['free_bytes_after']>=5*1024**3,f"disk guard: {c.get('label')}")
        require(c.get('env_overrides')==expected_env,f"guard environment overrides differ: {c.get('label')}")
        require(isinstance(c.get('argv'),list) and c['argv'],f"missing argv: {c.get('label')}")
        for ch in ('stdout','stderr'):
            stream=pin(c['streams'][ch],f"{c.get('label')} {ch}")
            require(stream==(Path(output).resolve()/'raw'/f"{c['index']}.{ch}.raw"),f"raw stream path differs from guard ledger: {c.get('label')} {ch}")
    return by
def method_map_issues(method,physical_method):
    body=(method.get('outcome') or {}).get('report') or {}; text=body.get('text'); sm=body.get('source_map')
    issues=[]; mapped=set()
    if not isinstance(text,str): return ['raw method text missing'],mapped,set()
    if not isinstance(sm,dict) or not isinstance(sm.get('segments'),list): return ['map/segments missing'],mapped,set()
    bounds=utf8bounds(text); phys=set((physical_method.get('code') or {}).get('bcis',[])); identity=method['item']['identity']
    raw=text.encode('utf-8')
    for i,s in enumerate(sm['segments']):
        st,en=s.get('start'),s.get('end')
        if type(st)!=int or type(en)!=int or not 0<=st<=en<=len(raw) or st not in bounds or en not in bounds:
            issues.append(f'segment {i} invalid UTF-8 bounds'); continue
        try: raw[st:en].decode('utf-8','strict')
        except UnicodeDecodeError: issues.append(f'segment {i} splits UTF-8 character')
        origin=s.get('origin'); refs=[]
        if not isinstance(origin,dict) or not isinstance(origin.get('primary'),dict): issues.append(f'segment {i} lacks primary origin'); continue
        derived=origin.get('derived',[])
        if not isinstance(derived,list): issues.append(f'segment {i} malformed derived origins'); continue
        refs=[origin['primary'],*derived]
        for ref in refs:
            if not isinstance(ref,dict): issues.append(f'segment {i} malformed origin ref'); continue
            bci=ref.get('bci'); ident=ref.get('method')
            if type(bci)!=int or bci not in phys: issues.append(f'segment {i} nonphysical BCI {bci!r}')
            else: mapped.add(bci)
            if ident!=identity: issues.append(f'segment {i} origin method identity differs')
    return issues,mapped,phys
def strip_usage(x):
    if isinstance(x,dict): return {k:strip_usage(v) for k,v in x.items() if k!='usage'}
    if isinstance(x,list): return [strip_usage(v) for v in x]
    return x
def differing_paths(a,b,path=()):
    if type(a)!=type(b): return {path}
    if isinstance(a,dict):
        out=set()
        for k in set(a)|set(b):
            if k not in a or k not in b: out.add(path+(k,))
            else: out |= differing_paths(a[k],b[k],path+(k,))
        return out
    if isinstance(a,list):
        if len(a)!=len(b): return {path+('<length>',)}
        out=set()
        for i,(x,y) in enumerate(zip(a,b)): out |= differing_paths(x,y,path+(i,))
        return out
    return set() if a==b else {path}
def source_visible_field_differences(original_fields, generated_fields, internal):
    """Allow only ACC_SYNTHETIC on the exact enclosing-instance field, never other member changes."""
    old={(x[0],x[1]):int(x[2]) for x in original_fields}
    new={(x[0],x[1]):int(x[2]) for x in generated_fields}
    if set(old)!=set(new): return None
    differences=[]
    for ident,old_access in old.items():
        new_access=new[ident]
        if old_access==new_access: continue
        if (internal==POINT_INTERNAL and ident==('this$0','L'+INTERNAL+';')
                and (old_access ^ new_access)==0x1000
                and (old_access & ~0x1000)==(new_access & ~0x1000)):
            differences.append({'class':internal,'field':ident[0],'descriptor':ident[1],
                'original_access':old_access,'generated_access':new_access,'differing_flag':'ACC_SYNTHETIC'})
        else: return None
    return differences

def expected_external_paths(candidate_cli_path):
    return {str(Path(x).resolve()) for x in (SOURCE,ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py',
      ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py',
      ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py',
      ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json',
      PARSER,DEPENDENCY,BASE/'execution.json',BASE_REVIEW,BASE_INDEPENDENT,CASE_PLAN,CASE_PLAN_SOURCE,DRIVER,RUNTIME,candidate_cli_path)}

def validate_receipt(receipt_path, expected_cli):
    receipt_path=Path(receipt_path).resolve(strict=True); receipt_digest=sha(receipt_path)
    receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
    require(receipt.get('schema')=='test-break-in-complex-if-final-jarde-candidate-v1','candidate schema mismatch')
    require(receipt.get('status')=='captured-pending-independent-review','candidate receipt is not a successful terminal capture')
    require(Path(receipt['root']).resolve()==ROOT.resolve(),'workspace root mismatch')
    require(receipt.get('candidate_cli_sha256_required')==expected_cli,'collector CLI argument pin mismatch')
    require(receipt['candidate_cli']['sha256']==expected_cli and sha(receipt['candidate_cli']['path'])==expected_cli,'candidate CLI pin mismatch')
    compare_path=pin(receipt['compare'],'compare helper'); parser=pin(receipt['physical_parser'],'physical parser')
    require(compare_path==ROOT/COMPARE_REL and sha(compare_path)==COMPARE_SHA,'compare helper pin mismatch')
    require(parser==PARSER.resolve() and sha(parser)==PARSER_SHA,'physical parser pin mismatch')
    guard_path=pin(receipt['guard'],'guard helper'); scanner_path=pin(receipt['scanner'],'target scanner')
    require(guard_path==ROOT/GUARD_REL and sha(guard_path)==GUARD_SHA,'guard helper pin mismatch')
    require(scanner_path==ROOT/SCANNER_REL and sha(scanner_path)==SCANNER_SHA,'target scanner pin mismatch')
    require(Path(receipt['jdk_manifest']['path']).resolve()==(ROOT/MANIFEST_REL).resolve() and sha(ROOT/MANIFEST_REL)==MANIFEST_SHA,'JDK manifest identity changed')
    require(sha(BASE/'execution.json')==BASE_SHA and sha(BASE_REVIEW)==BASE_REVIEW_SHA,'accepted original baseline or marker changed')
    require(sha(BASE_COLLECTOR)==BASE_COLLECTOR_SHA and sha(CANDIDATE_COLLECTOR)==CANDIDATE_COLLECTOR_SHA,'frozen baseline/candidate collector changed')
    compare=load(compare_path,'complexif_final_compare'); physical=load(parser,'complexif_final_physical')
    guard=load(guard_path,'complexif_final_guard'); base=json.loads((BASE/'execution.json').read_text(encoding='utf-8'))
    marker=json.loads(BASE_REVIEW.read_text(encoding='utf-8'))
    independent=Path(marker['independent_review']['path']).resolve(strict=True)
    require(sha(independent)==marker['independent_review']['sha256'],'accepted baseline independent review pin changed')
    require(marker.get('status')=='root_accepted_full_original_complex_if_with_explicit_loop_recovery_gap','baseline acceptance marker mismatch')
    require(len(base.get('commands',[]))==marker.get('counts',{}).get('commands') and len(base.get('jarde_cells',[]))==marker.get('counts',{}).get('jarde_calls') and len(base.get('original_runtime',[]))==marker.get('counts',{}).get('original_runtime_runs'),'accepted baseline root-marker counts differ from receipt')
    require(marker.get('receipt',{}).get('sha256')==BASE_SHA,'baseline marker does not bind the exact receipt')
    require(marker.get('independent_review',{}).get('path')==str(BASE_INDEPENDENT) and marker['independent_review'].get('sha256')==BASE_INDEPENDENT_SHA and sha(BASE_INDEPENDENT)==BASE_INDEPENDENT_SHA,'accepted independent baseline review pin mismatch')
    plan=base.get('case_plan',{}); plan_copy=base.get('case_plan_source_copy',{})
    require(Path(plan.get('path','')).resolve()==CASE_PLAN.resolve() and sha(CASE_PLAN)==CASE_PLAN_SHA,'accepted case-plan pin/path mismatch')
    require(Path(plan_copy.get('path','')).resolve()==CASE_PLAN_SOURCE.resolve() and sha(CASE_PLAN_SOURCE)==UPSTREAM_SOURCE_SHA and CASE_PLAN_SOURCE.read_bytes()==pin(base['source_copy'],'baseline upstream copy').read_bytes(),'case-plan source copy differs from complete upstream source')
    # Only these accepted historical workspace snapshots are exempt: the checkout has since evolved.
    # All baseline raw streams, original inputs, source copies, outputs, and tool pins remain reopened.
    for row,label in accepted_baseline_immutable_pins(base): pin(row,label)
    require(receipt['accepted_original_baseline']['sha256']==BASE_SHA and receipt['accepted_original_review']['sha256']==BASE_REVIEW_SHA,'candidate receipt does not bind accepted baseline')
    require(receipt['source']['sha256']==UPSTREAM_SOURCE_SHA and receipt['source']['bytes']==UPSTREAM_SOURCE_BYTES,'upstream source pin mismatch')
    upstream=pin(receipt['source'],'complete upstream source'); copied=pin(receipt['source_copy'],'upstream source copy')
    require(upstream.read_bytes()==copied.read_bytes(),'upstream source copy differs')
    require(receipt['source_copy']['path'].endswith('/source/jadx/tests/integration/loops/TestBreakInComplexIf.java'),'source copy path mismatch')
    require(receipt.get('runtime_case_names')==list(CASES) and base.get('runtime_case_names')==list(CASES),'case order differs from accepted baseline')
    require(receipt.get('accepted_jadx_evidence_reused',{}).get('jarde_cells')==base['jarde_cells'] and receipt.get('accepted_jadx_evidence_reused',{}).get('jadx_outputs')==base['jadx_outputs'],'original Jarde/JADX evidence was not reused byte-for-byte')
    require(receipt.get('accepted_jadx_evidence_reused',{}).get('api_cells')==16,'reused original Jarde API inventory mismatch')
    require(pin(receipt['driver_source'],'driver source')==DRIVER.resolve() and sha(DRIVER)==DRIVER_SHA,'reused runtime driver source changed')
    require(receipt['driver_source']==base['driver_source'],'candidate driver is not exact accepted baseline driver')
    require(receipt['runtime_wrapper']==base['runtime_wrapper'] and sha(RUNTIME)==RUNTIME_SHA,'runtime wrapper differs from accepted baseline')
    copied_collector=Path(receipt['output']).resolve()/'collector.py'
    require(copied_collector.is_file() and copied_collector.read_bytes()==CANDIDATE_COLLECTOR.read_bytes(),'captured collector copy does not bind prepared collector')

    # Reopen the complete original profile closure and dual-parser facts for target + nonstatic Point.
    profiles={x['profile']:x for x in base['source_profiles']}
    runs={(x['profile'],x['runtime']):x for x in base['original_runtime']}
    require(set(profiles)==set(PROFILES) and set(runs)=={(p,v) for p in PROFILES for v in VMS},'accepted original profile/VM grid incomplete')
    original={}
    for profile,pr in profiles.items():
        root=Path(pr['class_root']).resolve(strict=True); recorded=pr['class_tree']
        actual={p.relative_to(root).as_posix():p for p in sorted(root.rglob('*.class'))}
        require(set(actual)==set(recorded),'original complete outer/target/Point class tree paths differ')
        for rel,path in actual.items():
            pinrow=recorded[rel]; require(path.stat().st_size==pinrow['bytes'] and sha(path)==pinrow['sha256'],'original class bytes changed: '+rel)
        require(set(actual)=={OUTER_INTERNAL+'.class',INTERNAL+'.class',POINT_INTERNAL+'.class'},'original source class closure is not exactly outer/target/Point')
        facts={}
        for internal,key in ((INTERNAL,'target_facts'),(POINT_INTERNAL,'point_facts')):
            path=root/(internal+'.class'); parsed=parse_facts(compare,physical,path,f'baseline {profile} {internal}')
            require(parsed['class_name']==internal and parsed['major']==52 and norm(parsed)==norm(pr[key]),'baseline physical facts differ from accepted receipt')
            facts[internal]={(m['name'],m['descriptor']):m for m in parsed['methods']}
        original[profile]=facts
        bundle=pin(pr['bundle'],'original full plain JAR')
        with zipfile.ZipFile(bundle) as z:
            names=sorted(n for n in z.namelist() if not n.endswith('/'))
            require(names==sorted(recorded),'original plain JAR inventory differs from full class tree')
            for rel,path in actual.items(): require(z.read(rel)==path.read_bytes(),'original JAR member differs: '+rel)
    # Accepted original semantic oracle: preserve full raw streams, compare the approved semantic fields.
    for key,row in runs.items():
        require(row['exit_code']==0 and len(row['rows'])==len(CASES),'accepted original runtime row incomplete')
        for i,r in enumerate(row['rows']): require(r['name']==CASES[i] and r['index']==i,'accepted original oracle order changed')
    baseline_projection=[proj(runs[(p,v)]['rows']) for p in PROFILES for v in VMS]
    require(all(x==baseline_projection[0] for x in baseline_projection),'accepted original semantic results disagree across profiles/VMs')
    for runtime in base['original_runtime']:
        pin(runtime['stdout'],'accepted original stdout'); pin(runtime['stderr'],'accepted original stderr')
    for command in base['commands']:
        for stream in command.get('streams',{}).values(): pin(stream,'accepted original raw stream')
    for api in base['jarde_cells']:
        pin(api['input'],'accepted original API input'); pin(api['report'],'accepted original API JSON')
        if api.get('whole_source'): pin(api['whole_source'],'accepted original whole source')
    for row in base['jadx_outputs']:
        pin(row['input'],'accepted JADX input')
        for source in row['sources']: pin(source,'accepted complete JADX source')
    # Verify the accepted baseline's default/all pairs for both physical selectors and input forms.
    base_cells={(x['profile'],x['input_form'],x['evidence'],x['api_role']):x for x in base['jarde_cells']}
    require(len(base_cells)==16,'accepted baseline Jarde API key grid incomplete')
    base_docs={}
    for key,cell in base_cells.items():
        doc=json.loads(pin(cell['report'],'accepted baseline API report').read_text(encoding='utf-8'))
        base_docs[key]=doc
    for p in PROFILES:
        for f in FORMS:
            for role in ROLES:
                d=base_docs[(p,f,'default',role)]; a=base_docs[(p,f,'all',role)]
                require(d['text']==a['text'],'accepted baseline default/all class text differs')
                require([(m['item']['identity'],(m.get('outcome') or {}).get('report',{}).get('text'),(m.get('outcome') or {}).get('report',{}).get('source_map')) for m in d['methods']]
                        ==[(m['item']['identity'],(m.get('outcome') or {}).get('report',{}).get('text'),(m.get('outcome') or {}).get('report',{}).get('source_map')) for m in a['methods']],
                        'accepted baseline default/all raw method text/map differs')

    by=walk_commands(receipt,guard.ENV_VALUES,receipt['output'])
    for row,label in pins(receipt): pin(row,label)
    require(receipt.get('source_unchanged') is True and receipt.get('source_unchanged_finally') is True,'workspace source guard failed')
    require(receipt.get('source_pins_before')==receipt.get('source_pins_after')==receipt.get('source_pins_after_finally'),'workspace source snapshots differ')
    require(receipt.get('external_inputs_unchanged') is True and receipt.get('external_inputs_unchanged_finally') is True,'external input guard failed')
    require(receipt.get('external_input_pins_before')==receipt.get('external_input_pins_after')==receipt.get('external_input_pins_after_finally'),'external input snapshots differ')
    require(receipt.get('target_absent') is True and receipt.get('target_absent_finally') is True,'workspace target was not absent')
    require(receipt.get('driver_classes_unchanged') is True and receipt.get('runtime_wrapper_copy_unchanged') is True,'driver/wrapper copy changed')
    require(receipt.get('generated_outputs_unchanged') is True,'generated source/class outputs changed during collection')
    expected_external=expected_external_paths(receipt['candidate_cli']['path'])
    extfiles=receipt.get('external_input_pins_before',{}).get('files',[])
    require({str(Path(x['path']).resolve()) for x in extfiles}==expected_external,'external input file closure does not match required sources/tools')
    for row in extfiles: pin(row,'external pinned file')
    driver_root=BASE/'driver-classes'; expected_driver={p.relative_to(driver_root).as_posix():sha(p) for p in sorted(driver_root.rglob('*.class'))}
    actual_driver={Path(x['path']).relative_to(driver_root).as_posix():x['sha256'] for x in receipt['driver_classes']}
    require(actual_driver==expected_driver,'driver input class inventory differs from accepted original driver')
    copy_root=Path(receipt['output']).resolve()/'driver-classes'; copies=receipt.get('driver_class_copies_before',{})
    require(set(copies)==set(expected_driver),'copied driver class inventory incomplete')
    for rel,row in copies.items():
        path=pin(row,'copied parentless driver class'); require(path==copy_root/rel and row['sha256']==expected_driver[rel],'driver copy bytes/path differ from accepted baseline')
    wrapper=pin(receipt['runtime_wrapper'],'runtime wrapper'); wrapper_copy=pin(receipt['runtime_wrapper_copy'],'runtime wrapper copy')
    require(wrapper==RUNTIME.resolve() and wrapper.read_bytes()==wrapper_copy.read_bytes() and wrapper_copy==Path(receipt['output']).resolve()/'runtime-bound-cwd.py','runtime wrapper copy differs from accepted baseline')
    require(receipt.get('accepted_original_baseline',{}).get('sha256')==BASE_SHA,'baseline receipt pin in final capture differs')
    require(receipt.get('accepted_original_review',{}).get('sha256')==BASE_REVIEW_SHA,'baseline root review pin in final capture differs')
    require(receipt.get('jdk_manifest',{}).get('sha256')==MANIFEST_SHA and Path(receipt['jdk_manifest']['path']).resolve()==(ROOT/MANIFEST_REL).resolve(),'JDK manifest mismatch')
    jdks,manifest_tools=compare.configured_jdks(ROOT/MANIFEST_REL,MANIFEST_SHA)
    for leg in VMS:
        for tool in ('java','javac','javap'):
            got=receipt['jdk_manifest']['tools'][leg][tool]; p=pin(got,f'{leg} {tool}')
            require(p==Path(jdks[leg]['tools'][tool]).resolve() and got['sha256']==manifest_tools['tools'][leg][tool]['sha256'],'JDK tool differs from frozen manifest')
    require(sha(DEPENDENCY)==DEPENDENCY_SHA,'driver dependency receipt changed')
    dep=json.loads(DEPENDENCY.read_text(encoding='utf-8'))
    for row in receipt['dependency_artifacts']: pin(row,'runtime dependency artifact')
    require(receipt['dependency_classpath']==dep['classpath'],'dependency classpath differs from accepted parentless driver setup')
    require([(x['bytes'],x['sha256']) for x in receipt['dependency_artifacts']]==[(x['bytes'],x['sha256']) for x in [dep['harness_jar'],*dep.get('jar_pins',[])]],'dependency artifact closure differs')
    dep_dirs=dep.get('directory_pins',dep.get('directory_pins_before',{}))
    require(receipt.get('dependency_directory_pins')==dep_dirs,'runtime dependency class-directory pins differ')
    target_names={INTERNAL+'.class',POINT_INTERNAL+'.class',OUTER_INTERNAL+'.class'}
    for row in receipt['dependency_artifacts']:
        if row['path'].endswith('.jar'):
            with zipfile.ZipFile(row['path']) as z: require(not target_names.intersection(z.namelist()),'target/Point/outer class leaked into runtime dependencies')
    for folder,expected_tree in dep_dirs.items():
        actual={x.relative_to(Path(folder)).as_posix():pinrow for x in sorted(Path(folder).rglob('*.class'))
                for pinrow in [compare.pin(x)]}
        require(actual==expected_tree,'dependency class directory contents changed')
        require(not target_names.intersection(actual),'target/Point/outer class leaked into dependency directory')

    # Candidate CLI API matrix, all 16 physical class selectors.
    api_keys={(p,f,e,r) for p in PROFILES for f in FORMS for e in EVIDENCE for r in ROLES}
    cells={(x['profile'],x['input_form'],x['evidence'],x['api_role']):x for x in receipt['jarde_cells']}
    require(len(cells)==len(receipt['jarde_cells']) and set(cells)==api_keys,'candidate API grid has missing/duplicate selectors')
    api_docs={}; findings=[]; target_structured={}
    for key,cell in cells.items():
        profile,form,evidence,role=key; api_class=INTERNAL if role=='target' else POINT_INTERNAL
        require(cell.get('api_class')==api_class,'candidate API row class selector differs from role')
        cmd=by[cell['command']]; label=f'final-jarde-{profile}-{form}-{evidence}-{role}'
        require(cmd['label']==label and cmd['exit_code']==cell['exit_code']==0,'candidate API command failed or is misbound')
        expected_input=(Path(profiles[profile]['class_root'])/(api_class+'.class')) if form=='child' else Path(profiles[profile]['bundle']['path'])
        expected_input=expected_input.resolve(strict=True); require(pin(cell['input'],'API input')==expected_input,'API input is not accepted target/Point class or original bundle')
        argv=cmd['argv']; require(Path(argv[0]).resolve()==Path(receipt['candidate_cli']['path']).resolve(),'API used wrong candidate CLI')
        require(argv[1:3]==['class-source','--input'] and Path(argv[3]).resolve()==expected_input,'API request input argv mismatch')
        require(argv[argv.index('--class')+1]==api_class and argv[argv.index('--policy')+1]==('single-class' if form=='child' else 'plain-jar'),'API selector/policy mismatch')
        require(argv[argv.index('--release')+1]=='8' and argv[argv.index('--format')+1]=='json','API release/format mismatch')
        require((('--evidence' not in argv) if evidence=='default' else argv[argv.index('--evidence')+1]=='all'),'API evidence selection mismatch')
        report_path=pin(cell['report'],'candidate API report'); raw=report_path.read_bytes(); require(raw==pin(cmd['streams']['stdout'],'API stdout').read_bytes(),'API report differs from raw stdout')
        doc=json.loads(raw.decode('utf-8','strict')); api_docs[key]=doc
        whole=pin(cell['whole_source'],'candidate whole-class source').read_bytes(); require(doc['text'].encode('utf-8')==whole,'whole-class source differs from JSON report')
        original_fact=original[profile][api_class]
        methods={(m['name'],m['descriptor']):m for m in original_fact.values()}
        raw_methods={(m['item']['name']['escaped'],m['item']['descriptor']['escaped']):m for m in doc['methods']}
        summaries={(m['name'],m['descriptor']):m for m in cell['methods']}
        require(set(raw_methods)==set(summaries)==set(methods),'API physical method inventory differs from source class')
        target_bytes=(expected_input.read_bytes() if form=='child' else zipfile.ZipFile(expected_input).read(api_class+'.class'))
        require(doc.get('class',{}).get('class_bytes',{}).get('length')==len(target_bytes),'API class byte length differs from actual selected input member')
        for ident,method in raw_methods.items():
            summary=summaries[ident]; identity=method['item']['identity']; body=(method.get('outcome') or {}).get('report') or {}
            require(summary['identity']==identity and summary['outcome_kind']==method['outcome']['kind'] and summary['quality']==body.get('quality'),'stored method identity/outcome summary differs')
            require(summary['raw_text']==body.get('text') and summary['source_map']==body.get('source_map') and summary['fallbacks']==body.get('fallbacks') and summary['regions']==body.get('regions'),'stored raw method details differ from JSON')
            require(identity.get('owner')==doc.get('class') and identity.get('owner')==base_docs[key].get('class'),'API method owner differs from accepted original class identity')
            issues,mapped,physical_bcis=method_map_issues(method,methods[ident]); require(not issues,f'{key}/{ident} invalid physical/UTF-8 map anchors: {issues}')
            audit=summary['map_audit']; require(audit.get('issues')==[] and audit.get('map_present') is True and set(audit.get('mapped_bcis',[]))==mapped and set(audit.get('physical_bcis',[]))==physical_bcis,'stored method map audit differs from independently checked anchors')
            gaps=sorted(physical_bcis-mapped)
            if gaps: findings.append({'kind':'unmapped_physical_bcis','cell':key,'method':ident,'bcis':gaps})
        actual=sorted(raw_methods); expected=sorted(methods)
        require(cell.get('method_inventory_matches') is True and [tuple(x) for x in cell.get('physical_method_inventory',[])]==actual and [tuple(x) for x in cell.get('expected_physical_method_inventory',[])]==expected,'stored API inventory summary differs')
        require(cell.get('all_method_maps_valid') is True,'stored complete method-map validity summary is false')
        test_summary=summaries.get(('test','(Ljava/util/Map;I)I')) if role=='target' else None
        if test_summary is not None:
            require(cell.get('target_test_quality')==test_summary.get('quality') and cell.get('target_test_outcome')==test_summary.get('outcome_kind') and cell.get('target_test_map_audit')==test_summary.get('map_audit'),'target test summary differs from exact method row')
        if role=='target':
            target=raw_methods.get(('test','(Ljava/util/Map;I)I')); structured=bool(target and target.get('outcome',{}).get('kind')=='recovered' and target.get('outcome',{}).get('report',{}).get('quality')=='structured')
            target_structured[key]=structured
            if not structured: findings.append({'kind':'target_test_not_structured','cell':key})
    # Compare evidence modes on whole text and every raw method text/map; full JSON differences stay visible.
    for p in PROFILES:
        for f in FORMS:
            for role in ROLES:
                d=api_docs[(p,f,'default',role)]; a=api_docs[(p,f,'all',role)]
                require(d['text']==a['text'],'candidate default/all whole-class text differs')
                require([(m['item']['identity'],(m.get('outcome') or {}).get('kind'),(m.get('outcome') or {}).get('report',{}).get('quality'),(m.get('outcome') or {}).get('report',{}).get('text'),(m.get('outcome') or {}).get('report',{}).get('source_map')) for m in d['methods']]
                        ==[(m['item']['identity'],(m.get('outcome') or {}).get('kind'),(m.get('outcome') or {}).get('report',{}).get('quality'),(m.get('outcome') or {}).get('report',{}).get('text'),(m.get('outcome') or {}).get('report',{}).get('source_map')) for m in a['methods']],
                        'candidate default/all raw method text/map/quality differs')
                baseline_allowed=differing_paths(strip_usage(base_docs[(p,f,'default',role)]),strip_usage(base_docs[(p,f,'all',role)]))
                actual=differing_paths(strip_usage(d),strip_usage(a))
                require(actual<=baseline_allowed,f'{p}/{f}/{role}: JSON non-usage evidence differences expanded outside accepted baseline paths')

    # Each profile/form/evidence source group contains both exact selected class outputs.
    source_cells={(x['profile'],x['form'],x['evidence']):x for x in receipt['generated_source_cells']}
    source_keys={(p,f,e) for p in PROFILES for f in FORMS for e in EVIDENCE}
    require(len(source_cells)==len(receipt['generated_source_cells']) and set(source_cells)==source_keys,'generated source closure grid incomplete')
    expected_copy_pins={}
    for key,sc in source_cells.items():
        require(sc.get('source_available') is True and set(sc.get('classes',{}))==set(ROLES),'complete target+Point source pair unavailable')
        for role in ROLES:
            item=sc['classes'][role]; api_key=(*key,role); api_cell=cells[api_key]
            src=pin(item['source_pin'],'complete generated API source'); cp=pin(item['source_copy'],'verbatim source copy')
            require(src==Path(api_cell['whole_source']['path']).resolve() and src.read_bytes()==cp.read_bytes(),'generated class source was changed or mismatched')
            require(item['class_name']==(INTERNAL if role=='target' else POINT_INTERNAL),'source cell class identity differs')
            require(Path(item['java_file']).resolve()==cp and Path(item['source_path']).resolve()==src,'source copy escaped cell or selected artifact')
            expected_copy_pins[str(cp)]=item['source_copy']
        require(len(sc['java_files'])==2 and {Path(x).resolve() for x in sc['java_files']}=={Path(sc['classes'][r]['java_file']).resolve() for r in ROLES},'compile source list is not exactly the two selected full outputs')
    before=receipt.get('generated_source_copy_pins_before',{}); after=receipt.get('generated_source_copy_pins_after',{})
    require(set(before)==set(expected_copy_pins)==set(after),'generated source snapshot keyset is incomplete')
    require(norm(before)==norm(after) and all(norm(before[k])==norm(v) for k,v in expected_copy_pins.items()),'generated source copy snapshots changed')

    comp_by={}; compile_keys=set()
    for cr in receipt['generated_source_compilations']:
        key=(cr['profile'],cr['form'],cr['evidence'],cr['compiler'])
        require(key not in compile_keys,'duplicate compiler cell'); compile_keys.add(key)
        require(key[:3] in source_keys and key[3] in VMS and source_cells[key[:3]]['source_available'],'compiler row lacks selected source pair')
        cmd=by[cr['command']]; label=f"rebuild-jarde-{key[0]}-{key[1]}-{key[2]}-{key[3]}"
        require(cmd['label']==label and cmd['exit_code']==cr['exit_code'],'compile command ledger linkage differs')
        require(cr['stdout']==cmd['streams']['stdout'] and cr['stderr']==cmd['streams']['stderr'],'compile stdout/stderr pins differ from command')
        argv=cmd['argv']; leg=key[3]
        require(Path(argv[0]).resolve()==Path(receipt['jdk_manifest']['tools'][leg]['javac']['path']).resolve(),'wrong javac executable')
        for file in source_cells[key[:3]]['java_files']: require(Path(file).resolve() in {Path(x).resolve() for x in argv},'compiler omitted one of the two full class-source files')
        require(len([x for x in argv if x.endswith('.java')])==2,'compile did not use exactly the untrimmed target and Point sources')
        require('-proc:none' in argv and '-encoding' in argv and argv[argv.index('-encoding')+1]=='UTF-8' and '-classpath' in argv and argv[argv.index('-classpath')+1]==os.pathsep.join(receipt['dependency_classpath']),'compile classpath/options differ')
        require('-sourcepath' in argv and Path(argv[argv.index('-sourcepath')+1]).is_dir() and not list(Path(argv[argv.index('-sourcepath')+1]).iterdir()),'compile sourcepath is not isolated/empty')
        require(('-g' if key[0]=='debug' else '-g:none') in argv,'compiler debug profile differs')
        require(('--release' in argv and argv[argv.index('--release')+1]=='8') if leg=='javac23' else ('-source' in argv and argv[argv.index('-source')+1]=='8' and '-target' in argv and argv[argv.index('-target')+1]=='8'),'compiler release level differs')
        dest=Path(cr['class_root']).resolve(strict=True); expected_dest=(Path(receipt['output'])/'generated-classes'/key[0]/key[1]/key[2]/leg).resolve()
        require(dest==expected_dest and Path(argv[argv.index('-d')+1]).resolve()==dest,'compile output root differs from unique cell')
        tree={p.relative_to(dest).as_posix():p for p in sorted(dest.rglob('*.class'))}
        require(set(tree)==set(cr['class_tree']),'complete generated class inventory differs')
        runtime_eligible=False; targetfacts=None; pointfacts=None
        if cr['exit_code']==0:
            parsed={}
            for rel,path in tree.items():
                pinrow=cr['class_tree'][rel]; require(pin(pinrow,f'generated class {rel}')==path,'generated class tree pin/path mismatch')
                facts=parse_facts(compare,physical,path,f'generated {key} {rel}')
                require(facts['major']==52 and norm(facts)==norm(cr['class_facts'][rel]),'generated full class parser facts differ')
                parsed[rel]=facts
            require(set(parsed)=={INTERNAL+'.class',POINT_INTERNAL+'.class'},'generated source closure is not exactly target+Point')
            targetfacts=parsed[INTERNAL+'.class']; pointfacts=parsed[POINT_INTERNAL+'.class']
            expected_metadata=[]
            for internal,facts in ((INTERNAL,targetfacts),(POINT_INTERNAL,pointfacts)):
                basefacts=original[key[0]][internal]
                require({(m['name'],m['descriptor'],m['access']) for m in facts['methods']}=={(m['name'],m['descriptor'],m['access']) for m in basefacts.values()},'generated class method/access inventory differs from original')
                original_facts=profiles[key[0]]['target_facts'] if internal==INTERNAL else profiles[key[0]]['point_facts']
                require(facts.get('access')==original_facts.get('access'),'generated class source-visible class access differs from original')
                expected_metadata.extend(source_visible_field_differences(original_facts['fields'],facts['fields'],internal) or [])
                require(source_visible_field_differences(original_facts['fields'],facts['fields'],internal) is not None,'generated class field identity/type/source-visible access differs from original')
            require(norm(cr.get('metadata_differences',[]))==norm(expected_metadata),'recorded synthetic metadata difference differs from exact physical facts')
            if expected_metadata: findings.extend({'kind':'source_only_synthetic_flag_difference',**x} for x in expected_metadata)
            runtime_eligible=True
        require(cr.get('runtime_eligible') is runtime_eligible,'collector runtime eligibility differs from independently parsed complete class pair')
        if runtime_eligible:
            require(norm(cr.get('target_facts'))==norm(targetfacts) and norm(cr.get('point_facts'))==norm(pointfacts),'stored generated target/Point facts differ from actual class bytes')
        else:
            if cr['exit_code']!=0: findings.append({'kind':'generated_source_compile_failed','cell':key,'exit_code':cr['exit_code']})
            else: findings.append({'kind':'generated_class_pair_ineligible','cell':key,'reason':cr.get('class_facts_error')})
        comp_by[key]=cr
    expected_compile_keys={(p,f,e,v) for p,f,e in source_keys if source_cells[(p,f,e)]['source_available'] for v in VMS}
    require(compile_keys==expected_compile_keys,'generated compile grid is missing or duplicated')
    tree_before=receipt.get('generated_class_trees_before',{}); tree_after=receipt.get('generated_class_trees_after',{})
    expected_trees={str(Path(cr['class_root']).resolve()):norm(cr['class_tree']) for cr in comp_by.values()}
    require(set(tree_before)==set(expected_trees)==set(tree_after) and norm(tree_before)==norm(tree_after),'generated compiler-root before/after snapshot mismatch')
    require(all(norm(tree_before[k])==v for k,v in expected_trees.items()),'generated class tree snapshot differs from compiler rows')
    eligible={k for k,c in comp_by.items() if c['runtime_eligible']}

    wrong_by={}
    for w in receipt['generated_wrong_root_controls']:
        key=(w['profile'],w['form'],w['evidence'],w['compiler']); require(key not in wrong_by and key in eligible,'wrong-root control is duplicate or has no eligible target')
        wrong_by[key]=w; cmd=by[w['command']]; argv=cmd['argv']; cr=comp_by[key]
        require(cmd['label']==f"wrong-root-jarde-{key[0]}-{key[1]}-{key[2]}-{key[3]}" and cmd['exit_code']==w['exit_code']==1,'wrong-root did not exit with expected rejection')
        require(w['stdout']==cmd['streams']['stdout'] and w['stderr']==cmd['streams']['stderr'],'wrong-root raw streams misbound')
        require(len(argv)==13 and argv[1]=='-B' and Path(argv[2]).resolve()==Path(receipt['output']).resolve()/'runtime-bound-cwd.py' and argv[3]=='30','wrong-root wrapper argv mismatch')
        require(Path(argv[5]).resolve()==Path(receipt['jdk_manifest']['tools']['javac23']['java']['path']).resolve() and argv[6]=='-Xverify:all' and argv[7]=='-cp','wrong-root JVM invocation mismatch')
        require(Path(argv[8]).resolve()==Path(receipt['output']).resolve()/'driver-classes' and argv[9]=='TestBreakInComplexIfDriver','wrong-root driver classpath mismatch')
        target=Path(cr['class_root']).resolve(); wrongroot=Path(w['expected_wrong_root']).resolve(strict=True); cwd=Path(argv[4]).resolve(strict=True)
        require(Path(argv[10]).resolve()==target==Path(w['actual_target_root']).resolve() and Path(argv[11]).resolve()==wrongroot and Path(argv[12]).resolve()==cwd,'wrong-root/target/cwd argv mapping mismatch')
        require(wrongroot==Path(receipt['output']).resolve()/'empty-wrong-root' and not list(wrongroot.iterdir()),'wrong-root expected root is not isolated empty directory')
        require(cwd==Path(receipt['output']).resolve()/'wrong-root-cwd'/key[0]/key[1]/key[2]/key[3] and not list(cwd.iterdir()),'wrong-root JVM cwd is not exact/empty')
        require(w['rejected_before_target_case_output'] is True and b'wrong CodeSource:' in pin(w['stderr'],'wrong-root stderr').read_bytes() and b'CASE ' not in pin(w['stdout'],'wrong-root stdout').read_bytes(),'wrong-root did not reject before invoking target')
    require(set(wrong_by)==eligible,'each and only each compiled eligible target closure requires wrong-root rejection')

    runtimes={}
    for run in receipt['generated_runtime']:
        key=(run['profile'],run['form'],run['evidence'],run['compiler'],run['runtime']); require(key not in runtimes and key[:4] in eligible,'runtime row duplicate or not backed by eligible compile')
        runtimes[key]=run; cmd=by[run['command']]; argv=cmd['argv']; cr=comp_by[key[:4]]; target=Path(cr['class_root']).resolve()
        require(cmd['label']==f"runtime-jarde-{key[0]}-{key[1]}-{key[2]}-{key[3]}-{key[4]}" and cmd['exit_code']==run['exit_code'],'runtime command/row linkage differs')
        require(run['stdout']==cmd['streams']['stdout'] and run['stderr']==cmd['streams']['stderr'],'runtime raw streams misbound')
        require(len(argv)==13 and argv[1]=='-B' and Path(argv[2]).resolve()==Path(receipt['output']).resolve()/'runtime-bound-cwd.py' and argv[3]=='30','runtime wrapper argv mismatch')
        require(Path(argv[5]).resolve()==Path(receipt['jdk_manifest']['tools'][key[4]]['java']['path']).resolve() and argv[6]=='-Xverify:all' and argv[7]=='-cp','runtime Java leg mismatch')
        require(Path(argv[8]).resolve()==Path(receipt['output']).resolve()/'driver-classes' and argv[9]=='TestBreakInComplexIfDriver','runtime driver-only classpath mismatch')
        cwd=Path(argv[4]).resolve(strict=True); require(Path(argv[10]).resolve()==target==Path(argv[11]).resolve() and Path(argv[12]).resolve()==cwd,'runtime target root/cwd mismatch')
        require(Path(run['class_root']).resolve()==target and cwd==Path(receipt['output']).resolve()/'runtime-cwd'/key[0]/key[1]/key[2]/key[3]/key[4] and not list(cwd.iterdir()),'runtime root/cwd not isolated')
        if run['exit_code']==0:
            rows=parse_rows(pin(run['stdout'],'runtime stdout').read_bytes()); require(rows==run['rows'],'runtime rows differ from stdout')
            expected=runs[(key[0],key[4])]['rows']; matches=proj(rows)==proj(expected)
            require(run.get('matches_original_oracle') is matches,'stored semantic match flag differs')
            if not matches: findings.append({'kind':'generated_runtime_semantic_mismatch','cell':key})
        else:
            require(run.get('rows')==[] and run.get('matches_original_oracle') is False,'failed runtime row falsely claims output match')
            findings.append({'kind':'generated_runtime_failed','cell':key,'exit_code':run['exit_code']})
    expected_runtime={(p,f,e,c,v) for p,f,e,c in eligible for v in VMS}
    require(set(runtimes)==expected_runtime,'generated runtime grid differs from compiler-eligible outputs')

    expected_labels={f'final-jarde-{p}-{f}-{e}-{r}' for p in PROFILES for f in FORMS for e in EVIDENCE for r in ROLES}
    expected_labels|={f'rebuild-jarde-{p}-{f}-{e}-{v}' for p,f,e in source_keys if source_cells[(p,f,e)]['source_available'] for v in VMS}
    expected_labels|={f'wrong-root-jarde-{p}-{f}-{e}-{v}' for p,f,e,v in eligible}
    expected_labels|={f'runtime-jarde-{p}-{f}-{e}-{c}-{v}' for p,f,e,c in eligible for v in VMS}
    labels={c['label'] for c in receipt['commands']}; require(labels==expected_labels,'actual command label set differs from dynamic work grid')
    counts=receipt.get('counts_derived_from_commands',{})
    derived={'commands':len(receipt['commands']),'raw_streams':2*len(receipt['commands']),
      'final_jarde_api_calls':sum(x.startswith('final-jarde-') for x in labels),
      'generated_source_compiles':sum(x.startswith('rebuild-jarde-') for x in labels),
      'generated_vm_runs':sum(x.startswith('runtime-jarde-') for x in labels),
      'generated_wrong_root_runs':sum(x.startswith('wrong-root-jarde-') for x in labels)}
    require(counts==derived,'stored command counts differ from actual ledger')
    if not all(target_structured.values()): findings.append({'kind':'target_method_quality_incomplete','structured_cells':sum(target_structured.values()),'total_cells':len(target_structured)})
    return {'status':'reviewed_capture_integrity_and_candidate_observations','receipt_sha256':receipt_digest,
      'command_count':len(receipt['commands']),'api_cells':len(cells),'generated_source_cells':len(source_cells),
      'compile_cells':len(comp_by),'runtime_eligible_compiles':len(eligible),'wrong_root_cells':len(wrong_by),
      'positive_vm_cells':len(runtimes),'runtime_observations':sum(len(x.get('rows',[])) for x in runtimes.values()),
      'target_structured_cells':sum(target_structured.values()),'target_cells':len(target_structured),
      'findings':findings}

def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--receipt',type=Path,required=True); ap.add_argument('--expected-cli-sha256',required=True); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args()
    require(len(a.expected_cli_sha256)==64 and re.fullmatch('[0-9a-f]{64}',a.expected_cli_sha256) is not None,'expected CLI SHA must be lowercase 64-hex')
    require(not a.out.exists(),'refusing existing review output')
    result=validate_receipt(a.receipt.resolve(strict=True),a.expected_cli_sha256)
    a.out.parent.mkdir(parents=True,exist_ok=True); a.out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(result,sort_keys=True)); return 0
if __name__=='__main__': raise SystemExit(main())
