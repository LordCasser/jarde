use super::*;

use jarde_jvm::engine::analyze_method_ir;
use jarde_jvm::environment::ResolutionEnvironment;
use jarde_jvm::ir::{AnalysisStage, MethodAnalysisRequest};
use jarde_reader::artifact::{ArtifactInput, ArtifactSnapshot};
use jarde_reader::budget::{Budget, CancellationToken, Limits};
use jarde_reader::model::{
    ClassBytesId, Digest, JvmBytes, PhysicalClassLocation, PhysicalDefinitionId, PhysicalMethodId,
    PhysicalVariant,
};
use jarde_reader::view::{
    DelegationPolicy, LayoutMode, LoadDomain, LoadRoot, LoaderId, ModuleMode, MultiReleasePolicy,
    PhysicalScope, PhysicalView, RuntimeProfile, RuntimeUncertainty, RuntimeView,
};

const DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/cf09-complex-if-body-boundary/debug/class/jadx/tests/integration/loops/TestBreakInComplexIf$TestCls.class"
);
const NO_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/cf09-complex-if-body-boundary/no-debug/class/jadx/tests/integration/loops/TestBreakInComplexIf$TestCls.class"
);
const DESCRIPTOR: &[u8] = b"(Ljava/util/Map;I)I";

fn generous_limits() -> Limits {
    Limits {
        input_bytes: 1 << 20,
        archive_entries: 100,
        entry_bytes: 1 << 20,
        read_bytes: 1 << 20,
        class_bytes: 1 << 20,
        attribute_bytes: 1 << 20,
        code_bytes: 1 << 20,
        result_items: 1 << 20,
        output_bytes: 1 << 20,
        class_headers: 100,
        method_bodies: 100,
        ir_items: 1 << 20,
        ir_edges: 1 << 20,
        analysis_steps: 1 << 20,
        normalization_clones: 1 << 20,
        nested_depth: 32,
        dependency_depth: 8,
        elapsed_millis: u64::MAX,
    }
}

fn with_real_loop<R>(
    bytes: &[u8],
    budget: &mut Budget,
    check: impl FnOnce(
        &mut Walker<'_>,
        &CanonicalBlockId,
        usize,
        &BTreeSet<usize>,
        &CanonicalBlockId,
        &CanonicalBlockId,
    ) -> R,
) -> R {
    let mut read_budget = Budget::new(generous_limits());
    let snapshot = ArtifactSnapshot::open(ArtifactInput::bytes(bytes.to_vec()), &mut read_budget)
        .expect("the frozen complete TestCls opens");
    let owner = PhysicalDefinitionId {
        location: PhysicalClassLocation::StandaloneRoot {
            snapshot: snapshot.id().clone(),
        },
        class_bytes: ClassBytesId {
            digest: Digest(blake3::hash(bytes).to_hex().to_string()),
            length: u64::try_from(bytes.len()).expect("fixture length fits"),
        },
        variant: PhysicalVariant::Base,
    };
    let domain = LoadDomain {
        loader: LoaderId("app".to_owned()),
        parent_loader: None,
        delegation: DelegationPolicy::ParentFirst,
        roots: vec![LoadRoot::StandaloneClass {
            snapshot: snapshot.id().clone(),
        }],
        module_mode: ModuleMode::ClassPath,
        external_override: RuntimeUncertainty::None,
        runtime_transformation: RuntimeUncertainty::None,
    };
    let analysis = analyze_method_ir(
        &[snapshot.clone()],
        &MethodAnalysisRequest {
            environment: ResolutionEnvironment {
                runtime: RuntimeView {
                    physical: PhysicalView {
                        snapshot: snapshot.id().clone(),
                        scope: PhysicalScope::SnapshotAll,
                    },
                    profile: RuntimeProfile {
                        java_release: 8,
                        multi_release: MultiReleasePolicy::Disabled,
                        layout: LayoutMode::Generic,
                    },
                    load_domain: domain.clone(),
                },
                domains: vec![domain],
                providers: Vec::new(),
            },
            method: PhysicalMethodId {
                owner,
                name: JvmBytes(b"test".to_vec()),
                descriptor: JvmBytes(DESCRIPTOR.to_vec()),
            },
            stages: AnalysisStage::ALL.to_vec(),
        },
        &mut read_budget,
    )
    .expect("the pinned same-run method facts analyze");
    let ir = analysis.ir();
    let canonical = ir.canonical().expect("canonical CFG is present");
    let ssa = ir.ssa().expect("same-run SSA is present");
    let code = ir.code().expect("complete Code facts are present");
    let pool = ir.constant_pool();
    let operations = Operations::of(code, pool);
    let mut flow_budget = Budget::new(generous_limits());
    let view = NormalFlowView::build(canonical, &mut flow_budget)
        .expect("the complete normal-flow projection builds");
    let (header_node, natural) = (0..view.len())
        .find_map(|node| {
            view.loop_entered_at(node)
                .filter(|natural| natural.header() == node && !natural.is_irreducible())
                .map(|natural| (node, natural))
        })
        .expect("the frozen method has its natural loop");
    let header = view
        .id_of(header_node)
        .expect("natural header identity exists")
        .clone();
    let blocks = natural.blocks().clone();
    let exit = view
        .successor_ids(&header)
        .into_iter()
        .find(|successor| {
            view.index_of(successor)
                .is_some_and(|node| !blocks.contains(&node))
        })
        .expect("header has its proved external loop exit");
    let later_candidate = view
        .successor_ids(&header)
        .into_iter()
        .find(|successor| {
            view.index_of(successor)
                .is_some_and(|node| blocks.contains(&node) && node != header_node)
        })
        .expect("header has a structurally eligible later AND candidate");
    let chains = crate::concat::plan(ssa, &operations, &crate::build::FieldCopies::default());
    let sites = crate::init::Sites::empty();
    let excluded_edge_nodes = canonical
        .edges()
        .iter()
        .filter(|edge| {
            matches!(
                edge.kind(),
                CanonicalEdgeKind::Exception { .. } | CanonicalEdgeKind::Call { .. }
            )
        })
        .flat_map(|edge| [edge.from().clone(), edge.to().clone()])
        .collect();
    let mut walker = Walker {
        canonical,
        view: &view,
        ssa,
        operations: &operations,
        pool,
        chains: &chains,
        sites: &sites,
        code,
        method_synchronized: Some(false),
        has_reachable_explicit_monitor: false,
        return_is_boolean: false,
        handlers: &code.exception_handlers,
        profile: &crate::pass::JAVA_8,
        budget,
        catch_joins: BTreeSet::new(),
        loop_catch_terminal_owners: Vec::new(),
        fragmented: None,
        excluded_edge_nodes,
        visited: BTreeSet::new(),
        unclosed_tail_at: None,
        own_monitor: None,
        depth: 0,
    };
    check(
        &mut walker,
        &header,
        header_node,
        &blocks,
        &later_candidate,
        &exit,
    )
}

#[test]
fn later_and_statement_free_refusal_becomes_the_exact_real_body_boundary() {
    for (label, bytes) in [("debug", DEBUG), ("no-debug", NO_DEBUG)] {
        let mut budget = Budget::new(generous_limits());
        with_real_loop(bytes, &mut budget, |walker, header, header_node, blocks, candidate, exit| {
            assert_eq!(header.bci(), 7, "{label}: pinned natural header");
            assert_eq!(candidate.bci(), 14, "{label}: later candidate");
            assert_eq!(exit.bci(), 72, "{label}: shared exit");
            let candidate_node = walker.view.index_of(candidate).expect("candidate node");
            let reason = match walker.proved_header_test(header, candidate, candidate_node) {
                Ok(Err(reason @ FallbackReason::UnmetPrecondition {
                    pass,
                    requirement: crate::pass::Precondition::StatementFree,
                    block_bci,
                    ..
                })) if *pass == crate::pass::LOOP && block_bci == candidate.bci() => reason,
                other => panic!("{label}: expected this exact later StatementFree refusal, got {other:?}"),
            };
            assert!(
                walker
                    .later_and_body_boundary(header_node, candidate, candidate_node, exit, &reason)
                    .expect("the local edge check is budgeted"),
                "{label}: exact candidate target and common exit authorize the boundary"
            );
            match walker.header_test_chain(header, header_node, blocks) {
                Ok(Ok(Some(chain))) => {
                    assert_eq!(chain.operator, crate::ast::BinaryOp::LogicalAnd);
                    assert_eq!(chain.tests.len(), 1, "the header test remains in the prefix");
                    assert_eq!(chain.tests[0].0, *header);
                    assert_eq!(chain.body, *candidate);
                    assert_eq!(chain.exit, *exit);
                }
                other => panic!("{label}: expected an AND prefix and exact body boundary, got {other:?}"),
            }
        });
    }
}

#[test]
fn only_the_exact_later_loop_statement_free_reason_can_select_the_body_boundary() {
    let mut budget = Budget::new(generous_limits());
    with_real_loop(DEBUG, &mut budget, |walker, header, header_node, _, candidate, exit| {
        let candidate_node = walker.view.index_of(candidate).expect("candidate node");
        let statement_free = FallbackReason::unmet(
            &crate::pass::LOOP,
            crate::pass::Precondition::StatementFree,
            candidate.bci(),
            candidate.bci(),
        );
        assert!(walker
            .later_and_body_boundary(header_node, candidate, candidate_node, exit, &statement_free)
            .expect("matching evidence completes"));
        assert!(!walker
            .later_and_body_boundary(header_node, candidate, candidate_node, header, &statement_free)
            .expect("a mismatched common exit is a local refusal"));
        let test_bci = walker.terminal_bci(candidate).expect("candidate comparison BCI");
        let (_, decoded_target) = walker
            .operations
            .get(test_bci)
            .and_then(Operation::comparison)
            .expect("candidate has a decoded comparison");
        assert!(walker
            .and_body_edges_match(candidate, exit, decoded_target, test_bci)
            .expect("decoded edge check completes"));
        assert!(!walker
            .and_body_edges_match(candidate, exit, u32::MAX, test_bci)
            .expect("an absent decoded target is a local refusal"));
        let wrong_block = FallbackReason::unmet(
            &crate::pass::LOOP,
            crate::pass::Precondition::StatementFree,
            candidate.bci().saturating_add(1),
            candidate.bci(),
        );
        assert!(!walker
            .later_and_body_boundary(header_node, candidate, candidate_node, exit, &wrong_block)
            .expect("a different refusal owner is a local refusal"));
        assert!(!walker
            .later_and_body_boundary(
                header_node,
                candidate,
                candidate_node,
                exit,
                &FallbackReason::LoopShape { block_bci: candidate.bci() },
            )
            .expect("a topology failure is never a body boundary"));
        assert!(!walker
            .later_and_body_boundary(
                header_node,
                candidate,
                candidate_node,
                exit,
                &FallbackReason::ExceptionEdge {
                    block_bci: candidate.bci(),
                    handler_ordinal: 0,
                },
            )
            .expect("an exception-edge failure is never a body boundary"));
        let initial_header_refusal = FallbackReason::unmet(
            &crate::pass::LOOP,
            crate::pass::Precondition::StatementFree,
            header.bci(),
            header.bci(),
        );
        assert!(!walker
            .later_and_body_boundary(header_node, header, header_node, exit, &initial_header_refusal)
            .expect("initial-header effects retain the old path"));
    });
}

#[test]
fn stop_at_later_candidate_does_not_publish_partial_loop_ownership() {
    let mut limits = generous_limits();
    limits.analysis_steps = 1;
    let mut budget = Budget::new(limits);
    with_real_loop(DEBUG, &mut budget, |walker, header, header_node, blocks, _, _| {
        let result = walker.header_test_chain(header, header_node, blocks);
        assert!(
            matches!(
                result,
                Err(StopReason::Budget {
                    dimension: CountedBudgetDimension::AnalysisSteps,
                    ..
                })
            ),
            "the later candidate remains a stop when its proof budget is exhausted: {result:?}"
        );
        assert!(walker.visited.is_empty(), "chain proof owns no blocks before commit");
    });
}

#[test]
fn pre_cancelled_later_chain_remains_a_stop_without_partial_ownership() {
    let token = CancellationToken::new();
    token.cancel();
    let mut budget = Budget::with_cancellation_token(generous_limits(), token);
    with_real_loop(DEBUG, &mut budget, |walker, header, header_node, blocks, _, _| {
        let result = walker.header_test_chain(header, header_node, blocks);
        assert!(matches!(result, Err(StopReason::Cancelled { .. })));
        assert!(walker.visited.is_empty());
    });
}

#[test]
fn cancellation_during_later_boundary_check_remains_a_stop() {
    let token = CancellationToken::new();
    let mut budget = Budget::with_cancellation_token(generous_limits(), token.clone());
    with_real_loop(DEBUG, &mut budget, |walker, header, header_node, _, candidate, exit| {
        let candidate_node = walker.view.index_of(candidate).expect("candidate node");
        let reason = match walker.proved_header_test(header, candidate, candidate_node) {
            Ok(Err(reason @ FallbackReason::UnmetPrecondition {
                requirement: crate::pass::Precondition::StatementFree,
                ..
            })) => reason,
            other => panic!("the real later candidate must retain its precondition refusal: {other:?}"),
        };
        token.cancel();
        assert!(matches!(
            walker.later_and_body_boundary(header_node, candidate, candidate_node, exit, &reason),
            Err(StopReason::Cancelled { .. })
        ));
        assert!(walker.visited.is_empty(), "the stopped boundary proof owns no blocks");
    });
}
