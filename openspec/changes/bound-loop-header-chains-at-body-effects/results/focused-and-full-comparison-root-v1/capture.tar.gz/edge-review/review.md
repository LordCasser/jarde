# Read-only review: loop header body boundary

Shared source snapshot: `region.rs` SHA `5da4d9f40e0892ac134bb42fb1508fffad090b92338a86b9403efd47b7977510`; no files were changed and no toolchain was run.

## Findings

I found no false-accept path in the new boundary helper under its production call path. The caller reaches it only after a non-header candidate produced the exact `LOOP` / `StatementFree` refusal. Each candidate after the first header is admitted through `header_test_candidate`, which requires that its sole predecessor is the previous test and that it is in the natural loop. The helper re-reads that block's terminal comparison from the same `Operations` table and requires exactly two successors in the same `NormalFlowView`, one equal to the exact external exit identity and one whose BCI equals the decoded branch target. Then the existing AND-chain code requires the body predecessor set to equal the test blocks that flow to it. `header_tested_loop` retains its existing exact coverage and body walk before publishing a Region.

The route also keeps initial-header refusals outside the new helper; OR processing is in the other branch; non-`StatementFree` refusals do not enter the helper; and `StopReason` propagates with no ownership commit. A one-test result still returns `Ok(None)` to the existing single-header route. I found no gateway or return-clone ownership bypass in the changed code; those structures still pass through the pre-existing `loop_body_sequence`, `covers`, and body predecessor checks.

The current unit tests do not directly exercise the helper's decoded-target-absent branch. That is a coverage gap, not a production false acceptance: with one same-run class, the decoded comparison target and normal-flow successors both derive from the same Code. A narrow internal metamorphic test can exercise the guard without adding a production seam:

1. Start from the fixed class and capture the original canonical CFG, SSA, `NormalFlowView`, code, and candidate BCI.
2. Patch that candidate's conditional branch operand to a different valid BCI (for example the loop header), re-analyze the patched class, and use only its `Operations` table for the candidate BCI.
3. Temporarily point a test-only `Walker.operations` at those patched operations while retaining the original CFG/view/SSA. Call `later_and_body_boundary` with the exact synthetic `LOOP`/`StatementFree` reason and original exit; expect `false` because the patched target is absent from the original successors.

This deliberately combines two runs and is only a proof-gate metamorphic; label it as malformed internal facts, not valid JVM behavior. The original target/edge-positive test continues to use one same-run IR. Keep this test-only; no production `Operations` API or target parameter is needed.

The extra-entry unit overlay does retarget a real body exit transfer and reparse it, then checks that the candidate's predecessor uniqueness fails. Its StackMapTable is not updated, so its existing “parser/IR-only” label is correct. I did not find another concrete malformed-target or ownership hole.

## Pins

- `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/region.rs`: 1310095 bytes, SHA-256 `5da4d9f40e0892ac134bb42fb1508fffad090b92338a86b9403efd47b7977510`
- `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/region/and_body_boundary_tests.rs`: 31432 bytes, SHA-256 `54d23a3455404790d219cdce0bd4c234179dd8420f4c3b457d1ad4b1b584faa3`
- `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/decode.rs`: 73429 bytes, SHA-256 `d4164badbc241d8911730eff30b0e55b4b0061bf6dd3b1e2282b57834374160f`
- `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/facts.rs`: 58831 bytes, SHA-256 `40f0410aa75d0cd095f5a70460a5eef9f7dbb2af696a7005b45dcd18a0ff82ef`
