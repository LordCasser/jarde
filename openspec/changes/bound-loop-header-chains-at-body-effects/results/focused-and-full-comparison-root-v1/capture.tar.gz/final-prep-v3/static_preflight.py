#!/usr/bin/env python3
"""Python-only static pin/schema preflight; it never invokes the candidate collector or any toolchain."""
from __future__ import annotations
import ast, hashlib, importlib.util, json
from pathlib import Path
BASE=Path(__file__).parent
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
EXPECTED={
 'collect_final.py':'2f1f410e79c5f0e53605e07035a9ba53af1f4c61592242d6f920f31df5291953',
 'review.py':'4fc8cc3dd03a2ecf10ae0685ef1090506e63c59b51914ac461c44c83ca67af03',
 'baseline':'f3ef78d507b3e585b84c459fcbde577b1b4e0f864e2dbc74864782c1da19471e',
 'root_review':'bb5ea6e8e7a7bb639876a037a5ae5e60ed38884724f1595721b16afc24a6490c',
 'independent_review':'0637361277aeda897949b129a5d5665e151d103dd1a810a9bd1ed85cb6096f59',
 'case_plan':'732d70aad23c295762314fe165692520a0eb1f54fe93dbfd1b07c158331e5ae8',
 'source':'8e31f1cbe056fee54e43bab414f1c3c5ad19803497a80844c20a1d5f50226d4f',
 'driver':'98419c8b279935d0b3f9bed1fb1a70a773c6cc19c80fc138d91cd9bf0fd5a1cf',
}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def import_file(p,n):
 spec=importlib.util.spec_from_file_location(n,p); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def main():
 for name in ('collect_final.py','review.py'):
  path=BASE/name; ast.parse(path.read_text(encoding='utf-8'))
  assert sha(path)==EXPECTED[name],f'{name} pin mismatch'
  assert 'PLACEHOLDER' not in path.read_text(encoding='utf-8')
 c=import_file(BASE/'collect_final.py','static_collector'); r=import_file(BASE/'review.py','static_reviewer')
 base=c.BASELINE_DIR; receipt=base/'execution.json'; marker=base/'root-review.json'
 assert sha(receipt)==EXPECTED['baseline'] and sha(marker)==EXPECTED['root_review']
 data=json.loads(receipt.read_text()); mark=json.loads(marker.read_text())
 independent=Path(mark['independent_review']['path']); plan=Path(data['case_plan']['path'])
 assert sha(independent)==EXPECTED['independent_review'] and sha(plan)==EXPECTED['case_plan']
 assert sha(Path(data['source']['path']))==EXPECTED['source'] and sha(Path(data['driver_source']['path']))==EXPECTED['driver']
 assert mark['receipt']['sha256']==EXPECTED['baseline'] and mark['independent_review']['sha256']==EXPECTED['independent_review']
 assert mark['status']=='root_accepted_full_original_complex_if_with_explicit_loop_recovery_gap'
 assert data['schema']=='test-break-in-complex-if-full-source-baseline-v1' and data['status']=='captured-pending-independent-review'
 assert len(data['source_profiles'])==2 and len(data['original_runtime'])==4 and len(data['jarde_cells'])==16 and len(data['jadx_outputs'])==2
 historical={k for k in data if k.startswith('source_pins_')}
 assert historical==r.HISTORICAL_SOURCE_SNAPSHOT_KEYS
 immutable=r.accepted_baseline_immutable_pins(data)
 assert immutable and not any(label.startswith('accepted original source_pins_') for _,label in immutable)
 baseline_external={str(Path(x['path']).resolve()) for x in data['external_input_pins_before']['files']}
 assert str(c.SOURCE.resolve()) in baseline_external
 assert str(c.SOURCE.resolve()) in r.expected_external_paths('/private/tmp/candidate-cli')
 tree=ast.parse((BASE/'collect_final.py').read_text(encoding='utf-8'))
 tool_lists=[n.value for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='tool_paths' for x in n.targets)]
 assert len(tool_lists)==1 and sum(isinstance(x,ast.Name) and x.id=='SOURCE' for x in tool_lists[0].elts)==1
 keys={(x['profile'],x['input_form'],x['evidence'],x['api_role']) for x in data['jarde_cells']}
 expected={(p,f,e,role) for p in ('debug','no-debug') for f in ('child','bundle-child') for e in ('default','all') for role in ('target','point')}
 assert keys==expected and data['runtime_case_names']==list(c.CASE_NAMES)
 for run in data['original_runtime']:
  parsed=r.parse_rows(Path(run['stdout']['path']).read_bytes())
  assert parsed==run['rows'] and len(parsed)==9
 compare=c.load(ROOT/c.COMPARE_REL,'preflight_compare'); physical=c.load(c.PARSER,'preflight_physical')
 class_checks=[]
 for profile in data['source_profiles']:
  for internal,key in ((c.INTERNAL,'target_facts'),(c.POINT_INTERNAL,'point_facts')):
   path=Path(profile['class_root'])/(internal+'.class')
   facts=c.full_class_facts(compare,physical,path,'static original preflight')
   assert c.norm(facts)==c.norm(profile[key])
   class_checks.append({'profile':profile['profile'],'class':internal,'bytes':path.stat().st_size,'sha256':sha(path)})
 api_map_checks=0
 for cell in data['jarde_cells']:
  doc=json.loads(Path(cell['report']['path']).read_text(encoding='utf-8'))
  assert Path(cell['whole_source']['path']).read_bytes()==doc['text'].encode('utf-8')
  facts_key='target_facts' if cell['api_role']=='target' else 'point_facts'
  prof=next(p for p in data['source_profiles'] if p['profile']==cell['profile'])
  methods={(x['name'],x['descriptor']):x for x in prof[facts_key]['methods']}
  assert set(methods)=={(m['item']['name']['escaped'],m['item']['descriptor']['escaped']) for m in doc['methods']}
  for method in doc['methods']:
   ident=(method['item']['name']['escaped'],method['item']['descriptor']['escaped'])
   issues,_,_=r.method_map_issues(method,methods[ident]); assert not issues,(cell,ident,issues)
   api_map_checks+=1
 assert '--cli-sha256' in (BASE/'collect_final.py').read_text() and '--expected-cli-sha256' in (BASE/'review.py').read_text()
 assert 'PLACEHOLDER' not in (BASE/'review.py').read_text()
 result={'status':'static-preflight-only','collector_sha256':sha(BASE/'collect_final.py'),'reviewer_sha256':sha(BASE/'review.py'),
  'baseline_receipt_sha256':sha(receipt),'root_marker_sha256':sha(marker),'accepted_independent_review_sha256':sha(independent),
  'accepted_original_api_cells':len(keys),'original_vm_cells':len(data['original_runtime']),'case_count':9,
  'original_class_facts_reopened':class_checks,'baseline_method_maps_checked':api_map_checks,'historical_source_snapshots_skipped_exactly':sorted(historical),
  'accepted_external_source_closed':str(c.SOURCE.resolve()) in baseline_external,
  'candidate_cli':'not supplied; collector/reviewer require root-supplied path and exact SHA',
  'toolchain_or_candidate_execution':'not run'}
 (BASE/'preflight.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
