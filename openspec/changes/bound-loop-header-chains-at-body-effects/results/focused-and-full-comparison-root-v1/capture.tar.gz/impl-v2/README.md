# Bound loop header chain and body boundary — private v2 candidate

This private patch is based on the shared `region.rs` SHA `1dd7dfce8370772c9104dc96d26ffd5216b739f84968da64713e4bec12176f4d`. It is not applied and has not been built or tested.

The new boundary is restricted to a later AND candidate whose exact refusal is the loop pass's `StatementFree` precondition. Before classifying it as body, the helper checks the candidate's two normal successors using the existing `NormalFlowView`, confirms the exact shared exit and decoded branch target, and propagates budget/cancellation stops. The existing body walk and exact predecessor-closure check remain in place. A one-test result still returns `Ok(None)` and goes through the existing single-header recovery; OR handling and other refusals are unchanged.

The private unit module uses the accepted debug/no-debug `TestBreakInComplexIf$TestCls` bytes, plus root's compiled `HeaderBodyBoundaryControls.class` (SHA `c1d2c819c8eb659afba3ca15380eeba9cf632179519100d1965a9eb7ec40bf3d`). It checks the full actual loop region, its body If, loop-owned break, longer pure AND prefix, existing OR recovery, initial statementful header refusal, a parser/IR-only bytecode edge mutation that adds an extra predecessor, pre-cancellation, and a budget stop at the new helper charge. The edge mutation retains reader-produced nodes and does not claim JVM verification.

`changes.patch` carries the source edits. The candidate tree contains the new test file and control class under `candidate/`; the binary is provided separately because unified text patches cannot encode class bytes. Source pins and the root control capture path are in `pins.json`.

V1 remains frozen as `README-v1.md`, `pins-v1.json`, and `changes-v1.patch`. This v2 package does not include any OpenSpec checkbox edits. Root owns compilation, runtime comparison, and shared integration.
