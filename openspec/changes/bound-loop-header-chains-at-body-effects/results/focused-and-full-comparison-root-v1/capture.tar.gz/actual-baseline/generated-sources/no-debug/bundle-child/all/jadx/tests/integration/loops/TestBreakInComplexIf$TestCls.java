// jarde: presentation of `jadx/tests/integration/loops/TestBreakInComplexIf$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestBreakInComplexIf$TestCls extends java.lang.Object {
    public TestBreakInComplexIf$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestBreakInComplexIf$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    // jarde: generic Signature projection refused for `test(Ljava/util/Map;I)I`: unsupported (generic_source_shape_unproved): class name has no unambiguous Java source spelling
    private int test(java.util.Map arg1, int arg2) {
        // @method test(Ljava/util/Map;I)I
        // @declaration an instance method of `jadx.tests.integration.loops.TestBreakInComplexIf$TestCls`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        int local3;
        int local4;
        local3 = 1;
        local4 = arg2 + 1;
        while (local4 < 100) {
            jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point local5 = (jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point) arg1.get((java.lang.Object) ("" + local4 + ""));
            if (local5 != null) {
                if (local5.y != 100) {
                    break;
                } else {
                    local3 = local3 + 1;
                    local4 = local4 + 1;
                }
            } else {
                break;
            }
        }
        return local3;
    }

    public void check() {
        // @method check()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestBreakInComplexIf$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        java.util.HashMap local1 = new java.util.HashMap();
        local1.put((java.lang.Object) "3", (java.lang.Object) new jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point(this, 100, 100));
        local1.put((java.lang.Object) "4", (java.lang.Object) new jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point(this, 60, 100));
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat(this.test((java.util.Map) local1, 2)).isEqualTo(3);
        java.util.HashMap local2 = new java.util.HashMap();
        local2.put((java.lang.Object) "3", (java.lang.Object) new jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point(this, 100, 100));
        local2.put((java.lang.Object) "4", (java.lang.Object) new jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point(this, 60, 0));
        local2.put((java.lang.Object) "5", (java.lang.Object) new jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point(this, 60, 100));
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat(this.test((java.util.Map) local2, 2)).isEqualTo(2);
        return;
    }
}
