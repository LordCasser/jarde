// jarde: presentation of `jadx/tests/integration/loops/TestBreakInComplexIf$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestBreakInComplexIf$TestCls extends java.lang.Object {
    public TestBreakInComplexIf$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestBreakInComplexIf$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    // jarde: generic Signature projection refused for `test(Ljava/util/Map;I)I`: unsupported (generic_source_shape_unproved): class name has no unambiguous Java source spelling
    private int test(java.util.Map map, int mapX) {
        // @method test(Ljava/util/Map;I)I
        // @declaration an instance method of `jadx.tests.integration.loops.TestBreakInComplexIf$TestCls`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        int length;
        int x;
        length = 1;
        x = mapX + 1;
        while (x < 100) {
            jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point tile = (jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point) map.get((java.lang.Object) ("" + x + ""));
            if (tile != null) {
                if (tile.y != 100) {
                    break;
                } else {
                    length = length + 1;
                    x = x + 1;
                }
            } else {
                break;
            }
        }
        return length;
    }

    public void check() {
        // @method check()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestBreakInComplexIf$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        java.util.HashMap first = new java.util.HashMap();
        first.put((java.lang.Object) "3", (java.lang.Object) new jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point(this, 100, 100));
        first.put((java.lang.Object) "4", (java.lang.Object) new jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point(this, 60, 100));
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat(this.test((java.util.Map) first, 2)).isEqualTo(3);
        java.util.HashMap second = new java.util.HashMap();
        second.put((java.lang.Object) "3", (java.lang.Object) new jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point(this, 100, 100));
        second.put((java.lang.Object) "4", (java.lang.Object) new jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point(this, 60, 0));
        second.put((java.lang.Object) "5", (java.lang.Object) new jadx.tests.integration.loops.TestBreakInComplexIf$TestCls$Point(this, 60, 100));
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat(this.test((java.util.Map) second, 2)).isEqualTo(2);
        return;
    }
}
