#!/usr/bin/env python3
"""Collect a pinned final Jarde TestBreakInComplexIf candidate against accepted original oracles; preparation only."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, re, shutil, sys, zipfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
SOURCE = Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestBreakInComplexIf.java')
SOURCE_SHA256 = '8e31f1cbe056fee54e43bab414f1c3c5ad19803497a80844c20a1d5f50226d4f'

DEPENDENCY_REFERENCE = Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018/execution.json')
DEPENDENCY_REFERENCE_SHA256 = '5a7d6572e600d19dc45d78030d0b12867bc742c4b014381fb5c7b059db171d35'
BASELINE_INDEPENDENT_REVIEW = Path('/private/tmp/jarde-testbreakincomplexif-baseline-independent-review-root-v3-20261019/review.json')
BASELINE_INDEPENDENT_REVIEW_SHA256 = '0637361277aeda897949b129a5d5665e151d103dd1a810a9bd1ed85cb6096f59'
CASE_PLAN = Path('/private/tmp/jarde-testbreakincomplexif-baseline-prep-luna-v3-20261019/caseplans.json')
CASE_PLAN_SHA256 = '732d70aad23c295762314fe165692520a0eb1f54fe93dbfd1b07c158331e5ae8'
CASE_PLAN_SOURCE_COPY = Path('/private/tmp/jarde-testbreakincomplexif-source-plan-luna-v2-20261019/upstream/TestBreakInComplexIf.java')
RUNTIME_BOUND = Path('/private/tmp/jarde-testnotindexedloop-baseline-prep-luna-v2-20261019/runtime-bound-cwd.py')
RUNTIME_BOUND_SHA256 = 'bc917ec08e07ed462c18958f9a0d3b064b7d5bba3adc5fa41d9db49ff6c3de46'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA256 = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA256 = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
COMPARE_REL = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA256 = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
PARSER = Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA256 = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
DRIVER_SHA256 = '98419c8b279935d0b3f9bed1fb1a70a773c6cc19c80fc138d91cd9bf0fd5a1cf'

INTERNAL = 'jadx/tests/integration/loops/TestBreakInComplexIf$TestCls'
POINT_INTERNAL = INTERNAL + '$Point'
OUTER_INTERNAL = 'jadx/tests/integration/loops/TestBreakInComplexIf'
TARGET_DOT = 'jadx.tests.integration.loops.TestBreakInComplexIf$TestCls'
POINT_DOT = TARGET_DOT + '$Point'
RUNTIMES = ('javac8', 'javac23')
PROFILES = ('debug', 'no-debug')
EVIDENCE = ('default', 'all')
CASE_NAMES = ('source-check-first-map', 'source-check-complex-break', 'null-point-short-circuit', 'missing-first-key', 'last-allowed-index-99', 'exclusive-upper-bound-does-not-dereference-map', 'null-map-in-range', 'bounded-full-traversal', 'wrapped-start-breaks-immediately')


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def norm(value):
    if isinstance(value, dict): return {k:norm(v) for k,v in value.items()}
    if isinstance(value, (list, tuple)): return [norm(v) for v in value]
    return value

def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def same_content(compare, first: Path, second: Path) -> bool:
    left, right = compare.pin(first), compare.pin(second)
    return left.get('bytes') == right.get('bytes') and left.get('sha256') == right.get('sha256')


def full_class_facts(compare, physical, path: Path, role: str) -> dict:
    facts = compare.parse_class(path)
    actual = physical.parse_class_file(path.read_bytes())
    if actual['class_name'] != facts['class_name'] or actual['major'] != facts['major'] \
            or actual['methods'] != facts['methods']:
        raise RuntimeError(f'{role}: independent physical method/Code census differs')
    if sorted((x['name'], x['descriptor'], x['access']) for x in actual['fields']) != sorted(facts['fields']):
        raise RuntimeError(f'{role}: independent physical field census differs')
    facts['access'] = actual['access']
    if len({(m['name'], m['descriptor']) for m in facts['methods']}) != len(facts['methods']):
        raise RuntimeError(f'{role}: duplicate method identity')
    for method in facts['methods']:
        code = method.get('code')
        if code is None or not code.get('bcis') or code['bcis'][0] != 0 \
                or code['bcis'][-1] >= code['code_length']:
            raise RuntimeError(f'{role} {method["name"]}{method["descriptor"]}: invalid physical Code/BCIs')
    return facts


def source_visible_field_differences(original_fields, generated_fields, internal):
    """Allow only the unexpressible ACC_SYNTHETIC bit on this exact enclosing-instance field."""
    old={(x[0],x[1]):int(x[2]) for x in original_fields}
    new={(x[0],x[1]):int(x[2]) for x in generated_fields}
    if set(old)!=set(new): return None
    differences=[]
    for ident,old_access in old.items():
        new_access=new[ident]
        if old_access==new_access: continue
        if (internal==POINT_INTERNAL and ident==('this$0','L'+INTERNAL+';')
                and (old_access ^ new_access)==0x1000
                and (old_access & ~0x1000)==(new_access & ~0x1000)):
            differences.append({'class':internal,'field':ident[0],'descriptor':ident[1],
                'original_access':old_access,'generated_access':new_access,'differing_flag':'ACC_SYNTHETIC'})
        else: return None
    return differences

def class_tree(root: Path) -> dict:
    return {p.relative_to(root).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p)}
            for p in sorted(root.rglob('*.class'))}


def parse_oracle(stdout: bytes) -> list[dict]:
    import base64, re
    lines = stdout.decode('utf-8', errors='strict').splitlines()
    if len(lines) != len(CASE_NAMES): raise ValueError(f'expected {len(CASE_NAMES)} rows, got {len(lines)}')
    rows = []
    pattern = re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) target_stdout_b64=([^ ]*) after_b64=([^ ]*)$')
    def decode(value: str) -> str:
        return base64.b64decode(value, validate=True).decode('utf-8', errors='strict')
    for index, line in enumerate(lines):
        match = pattern.fullmatch(line)
        if match is None: raise ValueError(f'malformed oracle row: {line!r}')
        got_index, name, input_b64, result_b64, exception_type, message_b64, stack_b64, stdout_b64, after_b64 = match.groups()
        if int(got_index) != index or name != CASE_NAMES[index]:
            raise ValueError(f'case identity/order mismatch: {line!r}')
        rows.append({'index': index, 'name': name, 'input': decode(input_b64),
                     'result': decode(result_b64), 'exception_type': exception_type,
                     'exception_message': decode(message_b64), 'exception_stack': decode(stack_b64),
                     'target_stdout': decode(stdout_b64), 'after': decode(after_b64), 'raw': line})
    return rows

def oracle_projection(rows: list[dict]) -> list[dict]:
    return [{key: row[key] for key in ('index', 'name', 'input', 'result', 'exception_type', 'target_stdout', 'after')}
            for row in rows]

def utf8_boundaries(text: str) -> set[int]:
    boundaries = {0}; offset = 0
    for char in text:
        offset += len(char.encode('utf-8'))
        boundaries.add(offset)
    return boundaries

def audit_method_map(method: dict, physical: dict) -> dict:
    outcome = method.get('outcome', {}); body = outcome.get('report', {})
    text = body.get('text')
    source_map = body.get('source_map')
    result = {'outcome_kind': outcome.get('kind'), 'quality': body.get('quality'),
              'map_present': isinstance(source_map, dict), 'issues': []}
    if not isinstance(text, str):
        result['issues'].append('raw method text missing'); return result
    raw = text.encode('utf-8'); result['text_bytes'] = len(raw)
    if not isinstance(source_map, dict) or not isinstance(source_map.get('segments'), list):
        result['issues'].append('source map/segments missing'); return result
    bounds = utf8_boundaries(text); valid_bcis = set(physical.get('code', {}).get('bcis', [])); mapped = set()
    segments = source_map['segments']; result['segment_count'] = len(segments)
    for index, segment in enumerate(segments):
        start, end = segment.get('start'), segment.get('end')
        if type(start) is not int or type(end) is not int or not (0 <= start <= end <= len(raw)) or start not in bounds or end not in bounds:
            result['issues'].append(f'segment {index} has invalid UTF-8 byte bounds'); continue
        origin = segment.get('origin')
        if not isinstance(origin, dict) or not isinstance(origin.get('primary'), dict):
            result['issues'].append(f'segment {index} has no primary origin'); continue
        derived = origin.get('derived', [])
        if not isinstance(derived, list):
            result['issues'].append(f'segment {index} has malformed derived-origin list')
            continue
        for ref in [origin['primary'], *derived]:
            if not isinstance(ref, dict):
                result['issues'].append(f'segment {index} has malformed origin reference')
                continue
            bci = ref.get('bci')
            if type(bci) is not int or bci not in valid_bcis:
                result['issues'].append(f'segment {index} references nonphysical BCI {bci!r}')
            else: mapped.add(bci)
            ref_method = ref.get('method')
            item_identity = method.get('item', {}).get('identity', {})
            expected_owner = item_identity.get('owner') if isinstance(item_identity, dict) else None
            if not isinstance(ref_method, dict):
                result['issues'].append(f'segment {index} has no origin method identity')
                continue
            if not isinstance(expected_owner, dict) or not isinstance(ref_method.get('owner'), dict):
                result['issues'].append(f'segment {index} has malformed origin owner identity')
            try:
                ref_name = bytes(ref_method.get('name', [])).decode('utf-8', errors='strict')
                ref_descriptor = bytes(ref_method.get('descriptor', [])).decode('utf-8', errors='strict')
            except (TypeError, ValueError, UnicodeDecodeError):
                result['issues'].append(f'segment {index} has malformed origin method identity')
            else:
                if ref_name != physical.get('name') or ref_descriptor != physical.get('descriptor'):
                    result['issues'].append(f'segment {index} references a different method identity')
                if ref_method.get('owner') != expected_owner:
                    result['issues'].append(f'segment {index} origin owner differs from method owner')
    result['mapped_bcis'] = sorted(mapped)
    result['physical_bcis'] = sorted(valid_bcis)
    result['unmapped_physical_bcis'] = sorted(valid_bcis - mapped)
    result['covers_all_physical_bcis'] = mapped == valid_bcis
    return result


BASELINE_DIR = Path('/private/tmp/jarde-testbreakincomplexif-baseline-root-v2-20261019')
BASELINE_SHA256 = 'f3ef78d507b3e585b84c459fcbde577b1b4e0f864e2dbc74864782c1da19471e'
BASELINE_ROOT_REVIEW = BASELINE_DIR / 'root-review.json'
BASELINE_REVIEW_SHA256 = 'bb5ea6e8e7a7bb639876a037a5ae5e60ed38884724f1595721b16afc24a6490c'
PREP_V4 = Path('/private/tmp/jarde-testbreakincomplexif-baseline-prep-luna-v3-20261019')


def walk_pins(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= set(value) and isinstance(value.get('path'), str):
            yield value
        for child in value.values():
            yield from walk_pins(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk_pins(child)


def verify_pinned_row(compare, row, label):
    path = Path(row['path'])
    if not path.is_file() or path.is_symlink():
        raise RuntimeError(f'{label}: pinned file missing or unsafe: {path}')
    actual = compare.pin(path)
    if actual != {'path': str(path.resolve()), 'bytes': row['bytes'], 'sha256': row['sha256']}:
        raise RuntimeError(f'{label}: pinned file changed: {path}')
    return actual


def accepted_baseline(compare):
    receipt_path = BASELINE_DIR / 'execution.json'
    review_path = BASELINE_ROOT_REVIEW
    if sha(receipt_path) != BASELINE_SHA256 or sha(review_path) != BASELINE_REVIEW_SHA256:
        raise RuntimeError('accepted original baseline receipt/review pin changed')
    baseline = json.loads(receipt_path.read_text(encoding='utf-8'))
    review = json.loads(review_path.read_text(encoding='utf-8'))
    if baseline.get('status') != 'captured-pending-independent-review':
        raise RuntimeError('original baseline status changed; keep its historical status intact')
    if review.get('status') != 'root_accepted_full_original_complex_if_with_explicit_loop_recovery_gap':
        raise RuntimeError('original baseline root acceptance marker mismatch')
    if review.get('receipt', {}).get('sha256') != BASELINE_SHA256:
        raise RuntimeError('root marker does not bind the original execution receipt')
    independent_row = review.get('independent_review', {})
    independent_path = Path(independent_row.get('path', ''))
    if independent_path != BASELINE_INDEPENDENT_REVIEW or independent_row.get('sha256') != BASELINE_INDEPENDENT_REVIEW_SHA256 or not independent_path.is_file() or sha(independent_path) != independent_row.get('sha256'):
        raise RuntimeError('accepted baseline independent review is absent or changed')
    if sha(CASE_PLAN) != CASE_PLAN_SHA256 or Path(baseline.get('case_plan', {}).get('path', '')).resolve() != CASE_PLAN.resolve():
        raise RuntimeError('accepted baseline case-plan pin/path changed')
    if Path(baseline.get('case_plan_source_copy', {}).get('path', '')).resolve() != CASE_PLAN_SOURCE_COPY.resolve():
        raise RuntimeError('accepted baseline case-plan source copy path changed')
    for key in ('case_plan', 'case_plan_source_copy'):
        row = baseline.get(key, {})
        verify_pinned_row(compare, row, f'accepted {key}')
    if Path(baseline['case_plan_source_copy']['path']).read_bytes() != Path(baseline['source_copy']['path']).read_bytes():
        raise RuntimeError('accepted nine-case plan source copy differs from complete upstream source')
    # Reopen the immutable baseline artifacts this final collector actually reuses. Historical
    # workspace source-closure pins in the old receipt are not compared to today's evolved checkout.
    verify_pinned_row(compare, baseline['source'], 'original upstream source')
    verify_pinned_row(compare, baseline['source_copy'], 'original source copy')
    verify_pinned_row(compare, baseline['driver_source'], 'accepted runtime driver source')
    verify_pinned_row(compare, baseline['runtime_wrapper'], 'accepted runtime guard wrapper')
    for profile_row in baseline.get('source_profiles', []):
        root = Path(profile_row['class_root'])
        recorded = profile_row.get('class_tree', {})
        actual_paths = {p.relative_to(root).as_posix(): p for p in sorted(root.rglob('*.class'))}
        if set(actual_paths) != set(recorded): raise RuntimeError(f"original {profile_row.get('profile')} class tree paths changed")
        for rel, summary in recorded.items():
            actual = compare.pin(actual_paths[rel])
            if actual['bytes'] != summary.get('bytes') or actual['sha256'] != summary.get('sha256'):
                raise RuntimeError(f'original class output changed: {actual_paths[rel]}')
        verify_pinned_row(compare, profile_row['bundle'], f"original {profile_row.get('profile')} bundle")
    for pin in baseline.get('driver_classes', []):
        verify_pinned_row(compare, pin, 'accepted parentless driver class')
    for runtime_row in baseline.get('original_runtime', []):
        for stream in ('stdout', 'stderr'):
            verify_pinned_row(compare, runtime_row[stream], 'accepted original runtime stream')
    for api_row in baseline.get('jarde_cells', []):
        verify_pinned_row(compare, api_row['report'], 'accepted baseline Jarde API response')
        if api_row.get('whole_source'): verify_pinned_row(compare, api_row['whole_source'], 'accepted baseline Jarde source')
    for jadx_row in baseline.get('jadx_outputs', []):
        for pin in jadx_row.get('sources', []): verify_pinned_row(compare, pin, 'accepted baseline JADX source')
    for command_row in baseline.get('commands', []):
        for stream in command_row.get('streams', {}).values():
            verify_pinned_row(compare, stream, 'accepted baseline raw command stream')
    if len(baseline.get('source_profiles', [])) != 2 or len(baseline.get('original_runtime', [])) != 4:
        raise RuntimeError('accepted baseline lacks both original compiler profiles and four VM cells')
    if len(baseline.get('jarde_cells', [])) != 16 or len(baseline.get('jadx_outputs', [])) != 2:
        raise RuntimeError('accepted baseline lacks the pinned Jarde/JADX API and source evidence')
    expected_api_keys={(p,f,e,r) for p in PROFILES for f in FORMS for e in EVIDENCE for r in ('target','point')}
    actual_api_keys={(x.get('profile'),x.get('input_form'),x.get('evidence'),x.get('api_role')) for x in baseline['jarde_cells']}
    if actual_api_keys != expected_api_keys:
        raise RuntimeError('accepted baseline Jarde class-selector grid is incomplete or duplicated')
    if baseline.get('runtime_case_names') != list(CASE_NAMES):
        raise RuntimeError('accepted baseline nine-case order differs from frozen driver')
    if any(len(x.get('rows', [])) != len(CASE_NAMES) for x in baseline.get('original_runtime', [])):
        raise RuntimeError('accepted baseline does not contain all nine bounded oracle cases for all four original VM cells')
    return baseline, review


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--cli', type=Path, required=True, help='root-supplied final candidate CLI path')
    ap.add_argument('--cli-sha256', required=True, help='root-supplied exact final candidate CLI SHA-256')
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    root, out, cli = args.root.resolve(strict=True), args.out.resolve(), args.cli.resolve(strict=True)
    if len(args.cli_sha256) != 64 or any(ch not in '0123456789abcdef' for ch in args.cli_sha256):
        raise SystemExit('--cli-sha256 must be 64 lowercase hex characters')
    if root != ROOT.resolve(): raise SystemExit(f'workspace differs from pinned root: {root}')
    if out.exists(): raise SystemExit(f'refusing existing output: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink(): raise SystemExit('target must be absent')
    if sha(cli) != args.cli_sha256: raise SystemExit('candidate CLI SHA-256 mismatch')

    if sha(PARSER) != PARSER_SHA256: raise SystemExit(f'physical parser pin mismatch: {PARSER}')
    if sha(DEPENDENCY_REFERENCE) != DEPENDENCY_REFERENCE_SHA256: raise SystemExit(f'dependency reference pin mismatch: {DEPENDENCY_REFERENCE}')
    compare_path = root / COMPARE_REL
    guard_path, scanner_path = root / GUARD_REL, root / SCANNER_REL
    manifest_path = root / JDK_MANIFEST_REL
    for path, expected, label in ((compare_path, COMPARE_SHA256, 'compare'),
                                  (guard_path, GUARD_SHA256, 'guard'),
                                  (scanner_path, SCANNER_SHA256, 'scanner'),
                                  (manifest_path, JDK_MANIFEST_SHA256, 'JDK manifest')):
        if sha(path) != expected: raise SystemExit(f'{label} source pin mismatch: {path}')
    compare = load(compare_path, 'breaklabel_final_compare')
    guard = load(guard_path, 'breaklabel_final_guard')
    scanner = load(scanner_path, 'breaklabel_final_scanner')
    physical = load(PARSER, 'breaklabel_final_physical_parser')
    baseline, baseline_review = accepted_baseline(compare)
    jdks, jdk_record = compare.configured_jdks(manifest_path, JDK_MANIFEST_SHA256)
    dependency = json.loads(DEPENDENCY_REFERENCE.read_text(encoding='utf-8'))
    if dependency.get('schema') != 'cf11-original-nestedloops3-baseline-v1' or not dependency.get('classpath'):
        raise SystemExit('accepted parentless driver dependency reference mismatch')
    dep_dirs = dependency.get('directory_pins', dependency.get('directory_pins_before'))
    if not dep_dirs: raise SystemExit('dependency reference lacks class-directory pins')
    dep_rows = [dependency['harness_jar'], *dependency.get('jar_pins', [])]
    for row in dep_rows:
        if compare.pin(Path(row['path'])) != row: raise SystemExit(f'dependency artifact changed: {row["path"]}')
    for folder, expected in dep_dirs.items():
        actual = {p.relative_to(Path(folder)).as_posix(): compare.pin(p) for p in sorted(Path(folder).rglob('*.class'))}
        if actual != expected: raise SystemExit(f'dependency class directory changed: {folder}')
    target_class_names = {INTERNAL + '.class', POINT_INTERNAL + '.class', OUTER_INTERNAL + '.class'}
    for row in dep_rows:
        if row['path'].endswith('.jar'):
            with zipfile.ZipFile(row['path']) as archive:
                if target_class_names.intersection(archive.namelist()): raise SystemExit('target class leaked into accepted runtime dependencies')
    for folder in dep_dirs:
        if any((Path(folder) / name).is_file() for name in target_class_names):
            raise SystemExit(f'target class leaked into accepted runtime dependency directory: {folder}')

    # Reuse the accepted complete original bytecode closure and nine finite behavior observations.
    baseline_profiles = {x['profile']: x for x in baseline['source_profiles']}
    baseline_runtimes = {(x['profile'], x['runtime']): x for x in baseline['original_runtime']}
    original_facts = {profile: {INTERNAL: row['target_facts'], POINT_INTERNAL: row['point_facts']}
                      for profile, row in baseline_profiles.items()}
    if set(baseline_profiles) != {'debug', 'no-debug'}:
        raise RuntimeError('accepted source profile identities changed')
    for profile, row in baseline_profiles.items():
        root_classes = Path(row['class_root'])
        for internal in (INTERNAL, POINT_INTERNAL):
            cls = root_classes / (internal + '.class')
            facts = full_class_facts(compare, physical, cls, f'original {profile} {internal}')
            if facts['class_name'] != internal or facts['major'] != 52:
                raise RuntimeError(f'original {profile} class identity changed: {internal}')
            recorded = row['target_facts'] if internal == INTERNAL else row['point_facts']
            if norm(facts) != norm(recorded):
                raise RuntimeError(f'original {profile} physical facts differ from accepted receipt: {internal}')
        jar = Path(row['bundle']['path'])
        verify_pinned_row(compare, row['bundle'], f'original {profile} plain JAR')
        with zipfile.ZipFile(jar) as archive:
            names = set(archive.namelist())
            for internal in (INTERNAL, POINT_INTERNAL):
                if internal + '.class' not in names or archive.read(internal + '.class') != (root_classes / (internal + '.class')).read_bytes():
                    raise RuntimeError(f'original {profile} bundle member differs: {internal}')
    for key, row in baseline_runtimes.items():
        if row.get('exit_code') != 0 or len(row.get('rows', [])) != len(CASE_NAMES):
            raise RuntimeError(f'accepted original runtime oracle is incomplete: {key}')
    expected_oracles = [oracle_projection(baseline_runtimes[(profile, runtime)]['rows'])
                        for profile in PROFILES for runtime in RUNTIMES]
    if not all(x == expected_oracles[0] for x in expected_oracles):
        raise RuntimeError('accepted original nine-case semantic oracle differs across profile/VM cells')

    source = SOURCE
    driver_source = Path(baseline['driver_source']['path'])
    runtime_source = BASELINE_DIR / 'runtime-bound-cwd.py'
    driver_src_pin = compare.pin(driver_source)
    if driver_src_pin['sha256'] != DRIVER_SHA256 or driver_src_pin != baseline['driver_source']:
        raise RuntimeError('accepted ComplexIf driver source pin changed')
    driver_text = driver_source.read_text(encoding='utf-8')
    if driver_text.index('String initialInput = describeInput(i);') >= driver_text.index(
            'method.invoke(receiver, map, mapX);'):
        raise RuntimeError('driver does not snapshot input before invoking the target')
    runtime_src_pin = compare.pin(runtime_source)
    driver_root_original = BASELINE_DIR / 'driver-classes'
    driver_pin_rows = [compare.pin(p) for p in sorted(driver_root_original.rglob('*.class'))]
    expected_driver_pins = baseline.get('driver_classes', [])
    if driver_pin_rows != expected_driver_pins:
        raise RuntimeError('reused standalone reflection-driver classes differ from accepted baseline')
    source_before = compare.source_closure(root)
    generated_copy_pins = {}
    generated_class_roots = {}
    def copy_java_source(source_path: Path, destination_root: Path, relative_hint: Path | None = None):
        data = source_path.read_bytes()
        if relative_hint is not None:
            relative = relative_hint
        else:
            package_match = re.search(rb'(?m)^\s*package\s+([A-Za-z0-9_.]+)\s*;', data)
            class_match = re.search(rb'(?m)^\s*(?:public\s+)?(?:(?:final|abstract|strictfp)\s+)*class\s+([A-Za-z_$][A-Za-z0-9_$]*)\b', data)
            if class_match is None: raise RuntimeError(f'cannot identify class in complete candidate source: {source_path}')
            package = package_match.group(1).decode('ascii').replace('.', '/') if package_match else ''
            class_name = class_match.group(1).decode('ascii')
            relative = Path(package) / (class_name + '.java') if package else Path(class_name + '.java')
        destination = destination_root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists(): raise RuntimeError(f'duplicate candidate source path: {destination}')
        destination.write_bytes(data)
        if destination.read_bytes() != data: raise RuntimeError(f'candidate source copy changed bytes: {destination}')
        generated_copy_pins[str(destination)] = compare.pin(destination)
        return destination

    tool_paths=[SOURCE,cli,BASELINE_DIR/'execution.json',BASELINE_ROOT_REVIEW,BASELINE_INDEPENDENT_REVIEW,
                CASE_PLAN,CASE_PLAN_SOURCE_COPY,DEPENDENCY_REFERENCE,
                driver_source,runtime_source,root/JDK_MANIFEST_REL,compare_path,guard_path,scanner_path,PARSER]
    def external_snapshot():
        return {'files':[compare.pin(x) for x in tool_paths],
                'dependency_artifacts':[compare.pin(Path(x['path'])) for x in dep_rows],
                'dependency_directories':{str(Path(folder).resolve()):{p.relative_to(Path(folder)).as_posix():compare.pin(p)
                    for p in sorted(Path(folder).rglob('*.class'))} for folder in dep_dirs},
                'jdk_tools':{f'{leg}_{name}':compare.pin(path) for leg,spec in jdks.items() for name,path in spec['tools'].items()}}
    external_before=external_snapshot()

    out.mkdir(parents=True)
    raw_dir = out / 'raw'; raw_dir.mkdir()
    guard.ROOT = root; guard.OUT = raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, stdout_bytes: None
    if shutil.disk_usage(root).free < 5 * 1024**3: raise SystemExit('5 GiB free-space guard failed')

    # Copy the already compiled baseline driver for isolated execution; do not recompile original/JADX inputs.
    driver_classes = out / 'driver-classes'; driver_classes.mkdir()
    for source_class in sorted(driver_root_original.rglob('*.class')):
        dest = driver_classes / source_class.relative_to(driver_root_original)
        dest.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(source_class, dest)
    driver_copy_pins_before={p.relative_to(driver_classes).as_posix():compare.pin(p) for p in sorted(driver_classes.rglob('*.class'))}
    if len(driver_copy_pins_before)!=len(driver_pin_rows) or [x['sha256'] for x in driver_copy_pins_before.values()] != [x['sha256'] for x in driver_pin_rows]:
        raise RuntimeError('copied parentless driver classes differ from accepted baseline')
    runtime_copy = out / runtime_source.name; shutil.copy2(runtime_source, runtime_copy)
    source_copy = out / 'source/jadx/tests/integration/loops/TestBreakInComplexIf.java'
    source_copy.parent.mkdir(parents=True); shutil.copy2(source, source_copy)
    if compare.pin(source_copy)['sha256'] != SOURCE_SHA256: raise RuntimeError('copied complete source changed')
    empty = out / 'empty-classpath'; empty.mkdir()
    empty_wrong_root = out / 'empty-wrong-root'; empty_wrong_root.mkdir()
    if any(empty_wrong_root.iterdir()): raise RuntimeError('wrong CodeSource expected root must be empty')
    classpath_text = os.pathsep.join(dependency['classpath'])
    report = {
      'schema':'test-break-in-complex-if-final-jarde-candidate-v1','status':'running',
      'root':str(root),'output':str(out),'source':compare.pin(SOURCE),'source_copy':compare.pin(source_copy),
      'candidate_cli':compare.pin(cli),'candidate_cli_sha256_required':args.cli_sha256,
      'accepted_original_baseline':compare.pin(BASELINE_DIR/'execution.json'),
      'accepted_original_review':compare.pin(BASELINE_ROOT_REVIEW),
      'accepted_baseline_review_status':baseline_review.get('status'),
      'accepted_jadx_evidence_reused':{'api_cells':len(baseline['jarde_cells']),'full_source_outputs':len(baseline['jadx_outputs']),
                                       'jarde_cells':baseline['jarde_cells'],'jadx_outputs':baseline['jadx_outputs']},
      'original_oracles_reused':{f'{p}/{r}':baseline_runtimes[(p,r)] for p in PROFILES for r in RUNTIMES},
      'runtime_case_names':list(CASE_NAMES),'driver_source':driver_src_pin,'driver_classes':driver_pin_rows,
      'runtime_wrapper':runtime_src_pin,'runtime_wrapper_copy':compare.pin(runtime_copy),'driver_class_copies_before':driver_copy_pins_before,
      'jdk_manifest':jdk_record,'compare':compare.pin(compare_path),
      'guard':compare.pin(guard_path),'scanner':compare.pin(scanner_path),'physical_parser':compare.pin(PARSER),
      'dependency_classpath':dependency['classpath'],'dependency_artifacts':[compare.pin(Path(x['path'])) for x in dep_rows],
      'dependency_directory_pins':dep_dirs,'source_pins_before':source_before,'external_input_pins_before':external_before,
      'commands':[],'jarde_cells':[],'generated_source_cells':[],'generated_source_compilations':[],
      'generated_runtime':[],'generated_wrong_root_controls':[],
      'limits':['No original-source, JADX, original-JVM, or original/JADX full-source compilation command is rerun.',
                'The complete upstream TestBreakInComplexIf.java and outer JUnit classes remain pinned and untouched. The class-source API returns target and Point separately; the two complete API source texts are compiled together without edits, while the outer JUnit suite is not invoked.',
                'Final Jarde class-source requests cover the selected target and Point binary classes; original/JADX evidence is reused by exact accepted receipt pins.',
                'Source-map validity checks enforce physical BCIs and method identity; unmapped physical BCIs are recorded without requiring total coverage.']}
    compare.write_json(out/'execution.json',report)
    rows=report['commands']
    def command(argv,label,leg='javac23'):
        if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError('workspace target appeared')
        env=compare.clean_env(dict(os.environ),jdks[leg]);env.update(guard.ENV_VALUES);env.pop('RUST_MIN_STACK',None)
        row=guard.run_command(len(rows)+1,[str(x) for x in argv],env)
        row['label']=label;row['tool_leg']=leg;rows.append(row);compare.write_json(out/'execution.json',report)
        if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        return row
    def artifact(row,channel='stdout'):return compare.command_artifact(row,channel)
    def pin_tree(path):return {p.relative_to(path).as_posix():compare.pin(p) for p in sorted(path.rglob('*.class'))}
    try:
        # Sixteen current-candidate API cells: two physical classes x profile x input form x evidence.
        for profile in PROFILES:
            base_profile=baseline_profiles[profile]
            for role,api_class in (('target',INTERNAL),('point',POINT_INTERNAL)):
                class_input=Path(base_profile['class_root'])/(api_class+'.class')
                jar_input=Path(base_profile['bundle']['path'])
                for form,input_path,policy in (('child',class_input,'single-class'),('bundle-child',jar_input,'plain-jar')):
                    for evidence in EVIDENCE:
                        argv=[cli,'class-source','--input',input_path,'--class',api_class,'--policy',policy,'--release','8','--format','json']
                        if evidence=='all':argv += ['--evidence','all']
                        row=command(argv,f'final-jarde-{profile}-{form}-{evidence}-{role}')
                        raw=artifact(row); dest=out/'jarde'/profile/form/evidence/role;dest.mkdir(parents=True)
                        report_path=dest/'report.json';report_path.write_bytes(raw)
                        cell={'profile':profile,'input_form':form,'evidence':evidence,'api_class':api_class,'api_role':role,
                              'command':row['index'],'exit_code':row['exit_code'],'input':compare.pin(input_path),'report':compare.pin(report_path)}
                        try:
                            api=json.loads(raw.decode('utf-8',errors='strict'))
                            whole=dest/'whole-source.java';whole.write_bytes(api.get('text','').encode('utf-8'))
                            phys={(m['name'],m['descriptor']):m for m in original_facts[profile][api_class]['methods']}
                            summaries=[]
                            for method in api.get('methods',[]):
                                item=method.get('item',{});name=item.get('name',{}).get('escaped');descriptor=item.get('descriptor',{}).get('escaped')
                                body=method.get('outcome',{}).get('report',{});physical_method=phys.get((name,descriptor))
                                map_audit=audit_method_map(method,physical_method) if physical_method else {'issues':['no matching physical class method']}
                                summaries.append({'name':name,'descriptor':descriptor,'identity':item.get('identity'),
                                  'outcome_kind':method.get('outcome',{}).get('kind'),'quality':body.get('quality'),
                                  'fallbacks':body.get('fallbacks'),'regions':body.get('regions'),'raw_text':body.get('text'),
                                  'source_map':body.get('source_map'),'map_audit':map_audit})
                            actual=sorted((m['name'],m['descriptor']) for m in summaries)
                            expected=sorted((m['name'],m['descriptor']) for m in original_facts[profile][api_class]['methods'])
                            test=next((m for m in summaries if (m['name'],m['descriptor'])==('test','(Ljava/util/Map;I)I')),None)
                            all_maps_valid=bool(summaries) and all(not m.get('map_audit',{}).get('issues') for m in summaries)
                            unmapped={f"{m['name']}{m['descriptor']}":m.get('map_audit',{}).get('unmapped_physical_bcis',[]) for m in summaries}
                            cell.update({'whole_source':compare.pin(whole),'methods':summaries,'physical_method_inventory':actual,
                                         'expected_physical_method_inventory':expected,'method_inventory_matches':actual==expected,
                                         'all_method_maps_valid':all_maps_valid,'unmapped_physical_bcis_by_method':unmapped,
                                         'target_test_quality':test.get('quality') if test else None,
                                         'target_test_outcome':test.get('outcome_kind') if test else None,
                                         'target_test_map_audit':test.get('map_audit') if test else None})
                        except (ValueError,TypeError,UnicodeDecodeError) as e:cell['json_parse_error']=str(e)
                        report['jarde_cells'].append(cell);compare.write_json(out/'execution.json',report)

        if len(report['jarde_cells'])!=16:raise RuntimeError('final candidate did not produce all sixteen class-source API cells')
        # Preserve all API outcomes. If source-level failures occur, compilation records them rather
        # than aborting collection or relabeling the final output as accepted.
        for cell in report['jarde_cells']:
            if cell['exit_code']!=0 or cell.get('json_parse_error') or cell.get('method_inventory_matches') is not True:
                continue
            for method in cell.get('methods',[]):
                if method.get('map_audit',{}).get('issues'):
                    continue

        # Pair the two independently reported whole-class sources for each profile/form/evidence cell.
        # No source is trimmed or repaired; both complete outputs enter each compiler invocation.
        api_by={(c['profile'],c['input_form'],c['evidence'],c['api_role']):c for c in report['jarde_cells']}
        source_cells={}
        for profile in PROFILES:
            for form in FORMS:
                for evidence in EVIDENCE:
                    key=(profile,form,evidence)
                    members={role:api_by.get((*key,role)) for role in ('target','point')}
                    source_cell={'profile':profile,'form':form,'evidence':evidence,'source_available':False,
                                 'classes':{},'java_files':[]}
                    source_cells[key]=source_cell
                    valid=True
                    for role,api_class in (('target',INTERNAL),('point',POINT_INTERNAL)):
                        cell=members[role]
                        source_path=Path(cell['whole_source']['path']) if cell and cell.get('whole_source') else None
                        data=source_path.read_bytes() if source_path and source_path.is_file() else b''
                        if not data.strip() or not re.search(rb'(?m)^\s*(?:public\s+)?(?:(?:final|abstract|strictfp)\s+)*class\s+',data):
                            valid=False
                            source_cell['classes'][role]={'source_available':False,'source_pin':compare.pin(source_path) if source_path and source_path.is_file() else None}
                            continue
                        source_root=out/'generated-sources'/profile/form/evidence
                        relative=Path(api_class+'.java')
                        copied=copy_java_source(source_path,source_root,relative)
                        source_cell['classes'][role]={'source_available':True,'source_path':str(source_path),
                            'source_pin':compare.pin(source_path),'source_copy':compare.pin(copied),'class_name':api_class,
                            'java_file':str(copied)}
                        source_cell['java_files'].append(str(copied))
                    source_cell['source_available']=valid and len(source_cell['java_files'])==2
                    if source_cell['source_available']:
                        source_cell['source_root']=str(out/'generated-sources'/profile/form/evidence)
                    report['generated_source_cells'].append(source_cell);compare.write_json(out/'execution.json',report)
                    if not source_cell['source_available']:
                        continue
                    source_cell['java_files'].sort()
                    for compiler in RUNTIMES:
                        dest=out/'generated-classes'/profile/form/evidence/compiler;dest.mkdir(parents=True)
                        debug_arg='-g' if profile=='debug' else '-g:none'
                        if compiler=='javac8':argv=[jdks[compiler]['tools']['javac'],'-source','8','-target','8',debug_arg,'-encoding','UTF-8','-proc:none','-classpath',classpath_text,'-sourcepath',empty,'-d',dest,*source_cell['java_files']]
                        else:argv=[jdks[compiler]['tools']['javac'],'--release','8',debug_arg,'-encoding','UTF-8','-proc:none','-classpath',classpath_text,'-sourcepath',empty,'-d',dest,*source_cell['java_files']]
                        cr=command(argv,f"rebuild-jarde-{profile}-{form}-{evidence}-{compiler}",compiler)
                        class_tree=pin_tree(dest);rec={'profile':profile,'form':form,'evidence':evidence,'compiler':compiler,
                            'command':cr['index'],'exit_code':cr['exit_code'],'class_root':str(dest),'class_tree':class_tree,
                            'stdout':compare.pin(Path(cr['streams']['stdout']['path'])),'stderr':compare.pin(Path(cr['streams']['stderr']['path'])),
                            'runtime_eligible':False,'class_facts':None,'class_facts_error':None,'metadata_differences':[]}
                        if cr['exit_code']==0:
                            try:
                                facts={p.relative_to(dest).as_posix():full_class_facts(compare,physical,p,'final ComplexIf rebuild') for p in sorted(dest.rglob('*.class'))}
                                rec['class_facts']=facts
                                target=facts.get(INTERNAL+'.class');point=facts.get(POINT_INTERNAL+'.class')
                                rec['target_facts']=target;rec['point_facts']=point
                                expected_paths={INTERNAL+'.class',POINT_INTERNAL+'.class'}
                                if set(facts)!=expected_paths:rec['class_facts_error']='generated class tree is not exactly the target/Point source closure'
                                elif not target or target.get('class_name')!=INTERNAL or target.get('major')!=52 or not point or point.get('class_name')!=POINT_INTERNAL or point.get('major')!=52:
                                    rec['class_facts_error']='generated target/Point binary identity or release differs'
                                else:
                                    mismatch=[]
                                    for internal,generated in ((INTERNAL,target),(POINT_INTERNAL,point)):
                                        original=original_facts[profile][internal]
                                        em=sorted((m['name'],m['descriptor'],m['access']) for m in original['methods'])
                                        am=sorted((m['name'],m['descriptor'],m['access']) for m in generated['methods'])
                                        field_diffs=source_visible_field_differences(original['fields'],generated['fields'],internal)
                                        if am!=em or field_diffs is None or generated.get('access')!=original.get('access'):mismatch.append(internal)
                                        else:rec['metadata_differences'].extend(field_diffs)
                                    if mismatch:rec['class_facts_error']='generated source-visible method/field/class-access inventory differs: '+','.join(mismatch)
                                    else:rec['runtime_eligible']=True
                            except Exception as e:rec['class_facts_error']=repr(e)
                        report['generated_source_compilations'].append(rec);generated_class_roots[str(dest)] = class_tree;compare.write_json(out/'execution.json',report)
                        if rec['runtime_eligible']:
                            wrong_cwd=out/'wrong-root-cwd'/profile/form/evidence/compiler
                            wrong_cwd.mkdir(parents=True)
                            if any(wrong_cwd.iterdir()): raise RuntimeError(f'wrong-root cwd is not empty: {wrong_cwd}')
                            wrong=command([sys.executable,'-B',runtime_copy,'30',wrong_cwd,jdks['javac23']['tools']['java'],
                                           '-Xverify:all','-cp',driver_classes,'TestBreakInComplexIfDriver',dest,empty_wrong_root,wrong_cwd],
                                          f'wrong-root-jarde-{profile}-{form}-{evidence}-{compiler}','javac23')
                            wrong_out,wrong_err=artifact(wrong),artifact(wrong,'stderr')
                            rejected=wrong['exit_code']==1 and b'wrong CodeSource:' in wrong_err and b'CASE ' not in wrong_out
                            if any(wrong_cwd.iterdir()): raise RuntimeError(f'wrong-root target wrote into isolated cwd: {wrong_cwd}')
                            wrong_rec={'profile':profile,'form':form,'evidence':evidence,'compiler':compiler,'command':wrong['index'],
                              'exit_code':wrong['exit_code'],'expected_wrong_root':str(empty_wrong_root),'actual_target_root':str(dest),
                              'rejected_before_target_case_output':rejected,'stdout':compare.pin(Path(wrong['streams']['stdout']['path'])),
                              'stderr':compare.pin(Path(wrong['streams']['stderr']['path']))}
                            report['generated_wrong_root_controls'].append(wrong_rec);compare.write_json(out/'execution.json',report)
                            if not rejected: raise RuntimeError('wrong CodeSource negative control did not reject before target invocation')

        original_rows={(p,r):baseline_runtimes[(p,r)]['rows'] for p in PROFILES for r in RUNTIMES}
        for compilation in report['generated_source_compilations']:
            if not compilation['runtime_eligible']:continue
            profile,form,evidence,compiler=(compilation[k] for k in ('profile','form','evidence','compiler'))
            target=Path(compilation['class_root'])
            for runtime in RUNTIMES:
                cwd=out/'runtime-cwd'/profile/form/evidence/compiler/runtime;cwd.mkdir(parents=True)
                rr=command([sys.executable,'-B',runtime_copy,'30',cwd,jdks[runtime]['tools']['java'],'-Xverify:all','-cp',driver_classes,
                            'TestBreakInComplexIfDriver',target,target,cwd],f'runtime-jarde-{profile}-{form}-{evidence}-{compiler}-{runtime}',runtime)
                stdout=artifact(rr);rows_out=parse_oracle(stdout) if rr['exit_code']==0 else []
                match=rr['exit_code']==0 and oracle_projection(rows_out)==oracle_projection(original_rows[(profile,runtime)])
                record={'profile':profile,'form':form,'evidence':evidence,'compiler':compiler,'runtime':runtime,'command':rr['index'],
                        'exit_code':rr['exit_code'],'class_root':str(target),'rows':rows_out,'matches_original_oracle':match,
                        'stdout':compare.pin(Path(rr['streams']['stdout']['path'])),'stderr':compare.pin(Path(rr['streams']['stderr']['path']))}
                report['generated_runtime'].append(record);compare.write_json(out/'execution.json',report)

        report['generated_source_copy_pins_before']=generated_copy_pins
        report['generated_source_copy_pins_after']={path:compare.pin(Path(path)) for path in generated_copy_pins}
        report['generated_class_trees_before']=generated_class_roots
        report['generated_class_trees_after']={path:pin_tree(Path(path)) for path in generated_class_roots}
        report['generated_outputs_unchanged']=(report['generated_source_copy_pins_after']==generated_copy_pins
          and report['generated_class_trees_after']==generated_class_roots)
        report['source_pins_after']=compare.source_closure(root);report['source_unchanged']=report['source_pins_after']==source_before
        report['external_input_pins_after']=external_snapshot();report['external_inputs_unchanged']=report['external_input_pins_after']==external_before
        report['driver_class_copies_after']={p.relative_to(driver_classes).as_posix():compare.pin(p) for p in sorted(driver_classes.rglob('*.class'))}
        report['driver_classes_unchanged']=report['driver_class_copies_after']==driver_copy_pins_before
        report['runtime_wrapper_copy_after']=compare.pin(runtime_copy);report['runtime_wrapper_copy_unchanged']=report['runtime_wrapper_copy_after']==report['runtime_wrapper_copy']
        report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
        report['counts_derived_from_commands']={'commands':len(rows),'raw_streams':len(rows)*2,
          'final_jarde_api_calls':sum(r['label'].startswith('final-jarde-') for r in rows),
          'generated_source_compiles':sum(r['label'].startswith('rebuild-jarde-') for r in rows),
          'generated_vm_runs':sum(r['label'].startswith('runtime-jarde-') for r in rows),
          'generated_wrong_root_runs':sum(r['label'].startswith('wrong-root-jarde-') for r in rows)}
        if len(report['jarde_cells'])!=16:
            raise RuntimeError('candidate sixteen-cell API grid is incomplete')
        if any(c.get('exit_code')!=0 or c.get('json_parse_error') or c.get('method_inventory_matches') is not True for c in report['jarde_cells']):
            raise RuntimeError('one or more candidate API cells failed or lost a physical method inventory')
        expected_compile_cells=sum(2 for x in report['generated_source_cells'] if x.get('source_available'))
        if len(report['generated_source_compilations'])!=expected_compile_cells:
            raise RuntimeError('compiler attempts do not cover each source-available target/Point pair on both JDKs')
        eligible={(x['profile'],x['form'],x['evidence'],x['compiler']) for x in report['generated_source_compilations'] if x['runtime_eligible']}
        wrong={(x['profile'],x['form'],x['evidence'],x['compiler']) for x in report['generated_wrong_root_controls']}
        runtime={(x['profile'],x['form'],x['evidence'],x['compiler'],x['runtime']) for x in report['generated_runtime']}
        expected_runtime={(p,f,e,c,v) for p,f,e,c in eligible for v in RUNTIMES}
        if wrong!=eligible or runtime!=expected_runtime:
            raise RuntimeError('runtime/wrong-root rows do not match exactly the compiler-eligible class closures')
        if any(x['rejected_before_target_case_output'] is not True for x in report['generated_wrong_root_controls']):
            raise RuntimeError('a wrong-CodeSource control did not reject before target observations')
        if any((x['exit_code']==0 and len(x['rows'])!=len(CASE_NAMES)) or (x['exit_code']!=0 and x['rows']) for x in report['generated_runtime']):
            raise RuntimeError('runtime rows do not faithfully reflect each command exit/output')
        if (not report['source_unchanged'] or not report['target_absent'] or not report['external_inputs_unchanged']
                or not report['driver_classes_unchanged'] or not report['runtime_wrapper_copy_unchanged']
                or not report['generated_outputs_unchanged']):
            raise RuntimeError('workspace/source/tool/generated-output pins changed or target appeared')
        report['status']='captured-pending-independent-review'
    except BaseException as error:
        report['status']='failed';report['error']=str(error);raise
    finally:
        try:
            report['source_pins_after_finally']=compare.source_closure(root)
            report['source_unchanged_finally']=report['source_pins_after_finally']==source_before
            report['external_input_pins_after_finally']=external_snapshot()
            report['external_inputs_unchanged_finally']=report['external_input_pins_after_finally']==external_before
            report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
            if not report['source_unchanged_finally'] or not report['target_absent_finally'] or not report['external_inputs_unchanged_finally']:
                report['status']='failed';report['final_guard_error']='workspace source changed or target appeared'
        except BaseException as e:report['status']='failed';report['final_guard_error']=repr(e)
        report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out/'execution.json',report);shutil.copy2(__file__,out/'collector.py')
        print(json.dumps({'status':report['status'],'commands':len(rows),'api_cells':len(report['jarde_cells']),
                          'compile_cells':len(report['generated_source_compilations']),'vm_runs':len(report['generated_runtime']),
                          'error':report.get('error')}))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
