#!/usr/bin/env python3
"""Independent physical census of the compiled header/body boundary controls."""
import hashlib, importlib.util, json, stat
from pathlib import Path

ROOT=Path('/private/tmp/jarde-complex-if-body-boundary-controls-root-v1-20261019')
RECEIPT=ROOT/'execution.json'
MANIFEST=Path('/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json')
HELPER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
COMPARE=Path('/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
OUT=Path('/private/tmp/jarde-complex-if-body-boundary-controls-census-luna-v1-20261019/review.json')
EXPECTED_CLASS_SHA='b4bda85403a24e2623a390f7b8944bb4e0ab80e4142ebf375e8ef7079a70d9a8'

def need(v,m):
    if not v: raise RuntimeError(m)
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(p):
    b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(p.stat().st_mode)}
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
def sbe(code,p,n): return int.from_bytes(code[p:p+n],'big',signed=True)
def targets(code,bcis):
    rows=[]
    for b in bcis:
        op=code[b]; ts=[]
        if 0x99<=op<=0xa8 or op in (0xc6,0xc7): ts=[b+sbe(code,b+1,2)]
        elif op in (0xc8,0xc9): ts=[b+sbe(code,b+1,4)]
        elif op in (0xaa,0xab):
            p=b+1
            while p%4:p+=1
            ts=[b+sbe(code,p,4)]
            if op==0xaa:
                lo=sbe(code,p+4,4); hi=sbe(code,p+8,4); need(hi>=lo and hi-lo<100000,'bad tableswitch')
                ts += [b+sbe(code,p+12+4*i,4) for i in range(hi-lo+1)]
            else:
                n=sbe(code,p+4,4); need(0<=n<100000,'bad lookupswitch')
                ts += [b+sbe(code,p+12+8*i,4) for i in range(n)]
        if ts: rows.append({'bci':b,'opcode':f'0x{op:02x}','targets':ts})
    bciset=set(bcis)
    for r in rows: need(all(t in bciset for t in r['targets']),f'branch target not instruction: {r}')
    return rows

def main():
    hb=HELPER.read_bytes(); cb=COMPARE.read_bytes(); rb=RECEIPT.read_bytes(); mb=MANIFEST.read_bytes()
    receipt=json.loads(rb); manifest=json.loads(mb)
    need(sha(rb)=='668e7efeda13febf80d500c0efa7fb7d67ce3e4351b43ffa5690931389c733d3','receipt pin mismatch')
    toolchain_ref=manifest['toolchain_manifest']; toolchain_path=Path(toolchain_ref['path']); toolchain_raw=toolchain_path.read_bytes()
    need(sha(toolchain_raw)==toolchain_ref['sha256'],'configured toolchain manifest pin mismatch')
    toolchain=json.loads(toolchain_raw); tool=next(x['tools']['javac'] for x in toolchain['legs'] if x['leg']=='javac23')
    need(Path(receipt['compiler']['path']).resolve()==Path(tool['path']).resolve() and receipt['compiler']['bytes']==tool['bytes'] and receipt['compiler']['sha256']==tool['sha256'],'compiler does not match configured javac23 manifest')
    need(sha(Path(tool['path']).read_bytes())==tool['sha256'],'live configured compiler hash mismatch')
    cmd=receipt['command']; need(cmd['exit_code']==0 and cmd['guard_stop'] is None,'compile command not successful')
    for ch in ('stdout','stderr'):
        a=cmd['streams'][ch]; data=Path(a['path']).read_bytes(); need(len(data)==a['bytes'] and sha(data)==a['sha256'],f'{ch} raw pin mismatch')
    src=receipt['source']; sp=Path(src['path']); need(pin(sp)['bytes']==src['bytes'] and sha(sp.read_bytes())==src['sha256'],'source receipt pin mismatch')
    cls=receipt['classes']; need(len(cls)==1,'expected one control class')
    cp=Path(cls[0]['path']); raw=cp.read_bytes(); need(len(raw)==1678 and sha(raw)==EXPECTED_CLASS_SHA==cls[0]['sha256'],'compiled class pin mismatch')
    h=load('classfile_helpers',HELPER); c=load('compare',COMPARE)
    a=h.parse_class_file(raw); b=c.parse_class(cp)
    need(a['class_name']==b['class_name']=='HeaderBodyBoundaryControls','class identity mismatch')
    need(a['major']==b['major']==52 and a['minor']==b['minor']==0,'class version mismatch')
    need(a['fields']==[] and b['fields']==[],'unexpected fields')
    need(a['methods']==b['methods'],'physical parsers disagree on members/Code')
    want=[('<init>','()V',1),('andPrefix','(Ljava/util/Map;II)I',9),('orBody','(Ljava/util/Map;II)I',9),('initialEffect','(Ljava/util/Map;II)I',9)]
    need([(m['name'],m['descriptor'],m['access']) for m in a['methods']]==want,'method/access inventory mismatch')
    methods=[]; totals={'methods':0,'code_methods':0,'code_bytes':0,'instructions':0,'handlers':0,'branch_target_edges':0,'jsr_instructions':0}
    for m in a['methods']:
        co=m['code']; code=bytes.fromhex(co['code_hex']); bc=co['bcis']; br=targets(code,bc)
        need(h.decode_bcis(code)==bc,'instruction BCI disagreement')
        jsr=sum(code[x] in (0xa8,0xc9) for x in bc)
        methods.append({'name':m['name'],'descriptor':m['descriptor'],'access':m['access'],'max_stack':co['max_stack'],'max_locals':co['max_locals'],'code_length':co['code_length'],'code_hex':co['code_hex'],'bcis':bc,'instruction_count':len(bc),'handlers':co['rows'],'handler_count':len(co['rows']),'branch_transfers':br,'branch_target_edges':sum(len(x['targets']) for x in br),'jsr_instruction_count':jsr})
        totals['methods']+=1; totals['code_methods']+=co is not None; totals['code_bytes']+=len(code); totals['instructions']+=len(bc); totals['handlers']+=len(co['rows']); totals['branch_target_edges']+=sum(len(x['targets']) for x in br); totals['jsr_instructions']+=jsr
    result={'status':'independent_control_class_census_passed','claim_scope':'compiled classfile only; no target VM execution or behavioral claim','receipt':pin(RECEIPT),'receipt_status':receipt['status'],'source':pin(sp),'configured_jdk_manifest':{'pin':pin(MANIFEST),'toolchain_manifest':pin(toolchain_path),'toolchain_manifest_ref':toolchain_ref,'leg':'javac23','javac23':tool},'compiler':pin(Path(tool['path'])),'command_index':cmd['index'],'argv':cmd['argv'],'raw_streams':{k:pin(Path(v['path'])) for k,v in cmd['streams'].items()},'physical_decoders':{'classfile_helpers':pin(HELPER),'compare':pin(COMPARE)},'class':{**pin(cp),'class_name':a['class_name'],'major':a['major'],'minor':a['minor'],'access':a['access'],'fields':a['fields'],'methods':methods},'totals':totals,'audit_script':pin(Path(__file__).resolve())}
    OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'review':str(OUT),'review_sha256':sha(OUT.read_bytes()),'totals':totals,'status':result['status']}))
if __name__=='__main__': main()
