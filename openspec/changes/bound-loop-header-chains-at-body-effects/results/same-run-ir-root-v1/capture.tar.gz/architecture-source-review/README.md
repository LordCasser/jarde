# TestBreakInComplexIf 架构审查（只读）

审查对象：`crates/jarde-java/src/region.rs`，SHA-256 `1dd7dfce8370772c9104dc96d26ffd5216b739f84968da64713e4bec12176f4d`（1,307,045 bytes）。结论只基于源码；本轮 IR probe 尚未完成，不能据此断言该固定输入实际命中下述路径。

## 现有路径与边界

`header_tested_loop`（18065）先调 `header_test_chain`。链成功后，它从 `chain.body` 进入普通 `loop_body_sequence`，再把 `chain.tests` 写进 `Region::Loop`（18072–18144）。`Ok(None)` 则继续旧的单一 header test / `ForHeader` 路径（18145 起）；`Err(reason)` 会把整组 loop blocks 变成 gap（18146–18152）。因此，后续测试块的纯度拒绝若被当成 `Ok(None)`，已证明的多测试前缀会丢失，随后旧路径也无法表达这段前缀。

AND 链位于 `header_test_chain` 的 external-exit 分支（19161–19268）。每个测试都经 `proved_header_test`（19431–19477）；目前任何 `Err(reason)` 都立即成为整条链的拒绝（19200–19203）。候选检查 `header_test_candidate`（19409–19426）只核单前驱、loop 内位置与比较终结指令，不核纯度。候选后续块若不能继续形成同一出口链，现有代码已经把它作为 body 起点（19235–19253），并用精确前驱集合核对该边界（19258–19267）。

建议只考虑很窄的 AND 规则：只对已结构候选的**后续** AND 测试块处理纯度拒绝。注意 `proved_header_test` 顺序是 branch arity、leaving edge、`test_is_pure`，之后才核 successors 数量与 decoded target（19452–477）；因此 `UnmetPrecondition(StatementFree)` 本身并未证明 target 对应 CFG edge。分类为 body 边界前必须另行核该候选仍有预期的二 successor / decoded target 对应关系，以及已有共同 exit 和 exact predecessor closure。若这些 edge facts 不成立，保留原拒绝。满足条件时保留此前已证明的 tests，以该候选作为 `body`。不得把 `LoopShape`、ownership、leaving/exception edge、branch arity、其他 precondition 或 Stop 当成 body 边界；Stop 继续通过外层 `Result` 传播。

初始 header 的行为应维持当前代码，不要声称它必然走 `statementful_loop_header`：`header_test_chain` 先对首 successor 做 composite-candidate 预检（19161–85）；若该预检通过，初始 header 随后在 `proved_header_test` 中遇到 StatementFree 时会直接拒绝链，而不会返回 `Ok(None)` 让旧路径接手。只有链明确 `Ok(None)` 后，`header_tested_loop` 的旧单测路径才会在自身 purity refusal 处调用 `statementful_loop_header`（18204–11）。因此本片不应把初始 header 的 purity failure 重解释为 body，也不应扩大或重排旧 fallback。

若目前仅有 header 一个已证明测试，链仍应回 `Ok(None)`，保留旧单测试路径；候选拒绝本身不能让两测试链“成立”。若已证明 header 加至少一个后续测试，再遇到 statementful 候选，才有可保留的多测试前缀。需要覆盖该前缀长度大于 1 的情形。不要通过增加一个测试块后再丢掉其条件来凑链长度。

不建议在 OR 分支截断。OR 路径（19269–19385）没有 AND 分支共同的精确外部 exit 结构；后续 route 仍在 loop 内但不再是比较候选时，现有规则是 `LoopShape` 拒绝（19360–19366）。将该 route 改成 body 会改变短路路径和测试/主体的归属。除非真实 IR 与单独证明给出不同结构，本片应保持拒绝。

## body 与 break

loop body 普通 walk 会把候选块交给既有 `region_at_inner`。普通 `If` 的 join 若是 loop 的 `break_target`，代码可建立 `Region::LoopBreak` 空臂（约 6651–6708）；`finish_nested_if` 也有 loop-break arm / join 的处理（8796 起）。这给“将后续有副作用的条件块完整保留为 body If”提供了复用路径，避免新增 region 形状。不过这只是静态复用判断，必须由 IR probe 与实际输出确认该固定案例的前驱、join、break ownership 符合这些门。

## 必要对抗测试

- 固定输入命中后续 AND 纯度拒绝，证明初始 header 仍是 condition，statementful 块的赋值/调用与 break 仍在 loop body，顺序及 break 目标正确。
- 至少 header + 一个后续纯 test 后，再有 statementful AND test：保留完整多测试 prefix，并将后块作为 body；同时验证只有 header test 时仍走旧单测试回退。
- 初始 header 自身 statementful 的控制仍只走既有 `statementful_loop_header` 门；OR chain 的后续 statementful route 不截断。
- 非 StatementFree 的失败（额外 predecessor、非共同 exit、错误目标/分支 arity、exception/leaving edge、ownership 不闭合）仍拒绝整条复合链；budget/cancellation 在后来候选处仍产生原 Stop，不能降级成 body，也不能留下部分 ownership。

当前没有证据说明需要新机制；首选在 AND loop 内识别这个精确 precondition refusal，再复用已有 body walker 与 exact edge closure。若 probe 显示候选块无法被普通 walk 独占，或 break/join 的来源不闭合，应保留拒绝并报告事实，不放宽条件。
