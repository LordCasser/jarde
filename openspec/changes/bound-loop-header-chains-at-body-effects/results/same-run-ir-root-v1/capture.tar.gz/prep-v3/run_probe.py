import datetime, hashlib, json, subprocess, sys
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
PREP = Path(__file__).resolve().parent
HERE = Path('/private/tmp/jarde-testbreakincomplexif-ir-probe-runner-root-v2-20261019')
OUT = Path('/private/tmp/jarde-testbreakincomplexif-ir-probe-root-v2-20261019')
source = ROOT / 'crates/jarde-java/src/region.rs'
test = ROOT / 'crates/jarde-java/src/region/testbreakincomplexif_ir_probe_tests.rs'
sha = lambda b: hashlib.sha256(b).hexdigest()
pins = json.loads((PREP / 'pins.json').read_bytes())
original = source.read_bytes()
assert sha(original) == pins['source_pins']['region.rs']['sha256'], 'region.rs changed since prep'
assert sha((ROOT / 'crates/jarde-java/src/build.rs').read_bytes()) == pins['source_pins']['build.rs']['sha256'], 'build.rs changed since prep'
receipt = Path(pins['baseline_receipt']['path'])
assert sha(receipt.read_bytes()) == pins['baseline_receipt']['sha256'], 'baseline receipt changed'
for profile, row in pins['class_inputs'].items():
    for key in ('copy_path', 'receipt_path'):
        b = Path(row[key]).read_bytes()
        assert sha(b) == row['sha256'] and len(b) == row['bytes'], (profile, key)
    assert row['receipt_path'] == row['source_profile_path']
    assert row['receipt_sha256'] == pins['baseline_receipt']['sha256']
probe = (PREP / 'testbreakincomplexif_ir_probe_tests.rs').read_bytes()
assert sha(probe) == pins['prepared']['probe_module']['sha256']
assert not test.exists() and not (ROOT / 'target').exists() and not OUT.exists() and not HERE.exists()
original_copy = (PREP / 'original-region.rs').read_bytes()
candidate_copy = (PREP / 'candidate-region.rs').read_bytes()
assert original_copy == original and sha(original_copy) == pins['prepared']['original_region']['sha256']
marker = b'mod statementful_loop_header_tests;'
header = b'        let for_header = self.prove_for_header(header, header_node, blocks, &terminal_returns)?;'
gap = b') -> Run {\n    let fallback = Region::Fallback {'
assert original.count(marker) == original.count(header) == original.count(gap) == 1
candidate = original.replace(marker, marker + b'\n\n#[cfg(test)]\n#[path = "region/testbreakincomplexif_ir_probe_tests.rs"]\nmod testbreakincomplexif_ir_probe_tests;')
candidate = candidate.replace(header, header + b'\n        #[cfg(test)]\n        eprintln!("COMPLEX_IF_PROBE actual-header-tested header={header:?} terminal_returns={terminal_returns:?} for_header={for_header:#?}");')
candidate = candidate.replace(gap, b') -> Run {\n    #[cfg(test)]\n    eprintln!("COMPLEX_IF_PROBE gap reason={reason:?} next={next:?}");\n    let fallback = Region::Fallback {')
assert candidate == candidate_copy and sha(candidate_copy) == pins['prepared']['candidate_region']['sha256']
cmd = ['cargo', 'test', '-p', 'jarde-java', '--lib', '--locked', 'region::testbreakincomplexif_ir_probe_tests::dump_real_complex_if_ir_and_region_result', '--', '--exact', '--nocapture']
argv = ['python3', '-B', str(ROOT / 'openspec/changes/recover-branch-throw-return-finally/tools/run_validation.py'), str(OUT), str(HERE / 'commands.json')]
# Exclusive, fresh output directory. The prep tree is never written by this runner.
HERE.mkdir()
(HERE / 'original-region.rs').write_bytes(original_copy)
(HERE / 'candidate-region.rs').write_bytes(candidate_copy)
(HERE / 'probe.rs').write_bytes(probe)
(HERE / 'commands.json').write_text(json.dumps([cmd], indent=2) + '\n')
r = {'status': 'running', 'argv': argv, 'source_before_sha256': sha(original), 'candidate_sha256': sha(candidate), 'probe_sha256': sha(probe), 'prep_path': str(PREP), 'runner_output_path': str(HERE), 'pins': pins, 'instrumentation': 'Test-only header candidate and Region gap prints; normal recover output is authoritative.'}
try:
    source.write_bytes(candidate)
    test.write_bytes(probe)
    with (HERE / 'stdout.raw').open('xb') as so, (HERE / 'stderr.raw').open('xb') as se:
        proc = subprocess.run(argv, cwd=ROOT, stdout=so, stderr=se)
    r['runner_exit_code'] = proc.returncode
    assert proc.returncode == 0, 'guarded validation returned nonzero'
    execution = json.loads((OUT / 'execution.json').read_bytes())
    assert execution['source_unchanged'] and execution['target_absent']
    assert execution['status'] == 'commands_passed_pending_independent_acceptance'
    command = execution['commands'][0]
    raw_stdout = Path(command['streams']['stdout']['path']).read_text()
    assert '1 passed; 0 failed;' in raw_stdout
    r['status'] = 'root_executed_real_ir_probe_pending_architecture_review'
except BaseException as exc:
    r.update(status='failed', error=repr(exc))
    raise
finally:
    current = source.read_bytes() if source.exists() else None
    r['candidate_unchanged_until_restore'] = current == candidate
    if current is not None and current not in (candidate, original):
        (HERE / 'unexpected-region-before-restore.raw').write_bytes(current)
    r['probe_present_before_cleanup'] = test.exists()
    probe_before = test.read_bytes() if test.exists() else None
    r['probe_unchanged_before_cleanup'] = probe_before == probe
    if probe_before is not None and probe_before != probe:
        (HERE / 'unexpected-probe-before-cleanup.raw').write_bytes(probe_before)
    source.write_bytes(original)
    if test.exists():
        test.unlink()
    r['source_restored_exact'] = source.read_bytes() == original
    r['probe_removed'] = not test.exists()
    r['target_absent'] = not (ROOT / 'target').exists()
    r['cleanup_exact'] = (r['candidate_unchanged_until_restore'] and r['probe_present_before_cleanup']
                          and r['probe_unchanged_before_cleanup'] and r['source_restored_exact']
                          and r['probe_removed'] and r['target_absent'])
    if not r['cleanup_exact']:
        r['status'] = 'failed_cleanup_invariant'
    r['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (HERE / 'execution.json').write_text(json.dumps(r, indent=2) + '\n')
    print(json.dumps({k: r.get(k) for k in ('status', 'cleanup_exact', 'source_restored_exact', 'probe_removed', 'target_absent')}))
