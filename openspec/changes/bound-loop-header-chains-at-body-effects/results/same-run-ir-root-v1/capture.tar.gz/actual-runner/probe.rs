//! Temporary, read-only probe for the accepted original TestBreakInComplexIf class.
use super::*;
use jarde_jvm::engine::analyze_method_ir;
use jarde_jvm::environment::ResolutionEnvironment;
use jarde_jvm::ir::{AnalysisStage, MethodAnalysisRequest};
use jarde_reader::artifact::{ArtifactInput, ArtifactSnapshot};
use jarde_reader::budget::{Budget, Limits};
use jarde_reader::model::{
    ClassBytesId, Digest, JvmBytes, PhysicalClassLocation, PhysicalDefinitionId, PhysicalMethodId,
    PhysicalVariant,
};
use jarde_reader::view::{
    DelegationPolicy, LayoutMode, LoadDomain, LoadRoot, LoaderId, ModuleMode,
    MultiReleasePolicy, PhysicalScope, PhysicalView, RuntimeProfile, RuntimeUncertainty,
    RuntimeView,
};
use std::collections::BTreeSet;

const ORIGINAL_DEBUG: &[u8] = include_bytes!(
    "/private/tmp/jarde-testbreakincomplexif-ir-probe-prep-luna-v3-20261019/original/debug/TestBreakInComplexIf$TestCls.class"
);
const ORIGINAL_NO_DEBUG: &[u8] = include_bytes!(
    "/private/tmp/jarde-testbreakincomplexif-ir-probe-prep-luna-v3-20261019/original/no-debug/TestBreakInComplexIf$TestCls.class"
);

fn probe_budget() -> Budget {
    Budget::new(Limits {
        input_bytes: 1 << 20,
        archive_entries: 100,
        entry_bytes: 1 << 20,
        read_bytes: 1 << 20,
        class_bytes: 1 << 20,
        attribute_bytes: 1 << 20,
        code_bytes: 1 << 20,
        result_items: 1 << 20,
        output_bytes: 1 << 20,
        class_headers: 100,
        method_bodies: 100,
        ir_items: 1 << 20,
        ir_edges: 1 << 20,
        analysis_steps: 1 << 20,
        normalization_clones: 1 << 20,
        nested_depth: 32,
        dependency_depth: 8,
        elapsed_millis: u64::MAX,
    })
}

fn inspect(label: &str, bytes: &[u8], expected_blake3: &str) {
    assert_eq!(
        blake3::hash(bytes).to_hex().to_string(),
        expected_blake3,
        "{label}: exact accepted physical class bytes"
    );
    let mut budget = probe_budget();
    let snapshot = ArtifactSnapshot::open(ArtifactInput::bytes(bytes.to_vec()), &mut budget)
        .expect("pinned complete class opens");
    let definition = PhysicalDefinitionId {
        location: PhysicalClassLocation::StandaloneRoot {
            snapshot: snapshot.id().clone(),
        },
        class_bytes: ClassBytesId {
            digest: Digest(blake3::hash(bytes).to_hex().to_string()),
            length: u64::try_from(bytes.len()).expect("fixture length fits u64"),
        },
        variant: PhysicalVariant::Base,
    };
    let domain = LoadDomain {
        loader: LoaderId("app".into()),
        parent_loader: None,
        delegation: DelegationPolicy::ParentFirst,
        roots: vec![LoadRoot::StandaloneClass {
            snapshot: snapshot.id().clone(),
        }],
        module_mode: ModuleMode::ClassPath,
        external_override: RuntimeUncertainty::None,
        runtime_transformation: RuntimeUncertainty::None,
    };
    let analysis = analyze_method_ir(
        &[snapshot.clone()],
        &MethodAnalysisRequest {
            environment: ResolutionEnvironment {
                runtime: RuntimeView {
                    physical: PhysicalView {
                        snapshot: snapshot.id().clone(),
                        scope: PhysicalScope::SnapshotAll,
                    },
                    profile: RuntimeProfile {
                        java_release: 8,
                        multi_release: MultiReleasePolicy::Disabled,
                        layout: LayoutMode::Generic,
                    },
                    load_domain: domain.clone(),
                },
                domains: vec![domain],
                providers: Vec::new(),
            },
            method: PhysicalMethodId {
                owner: definition,
                name: JvmBytes(b"test".to_vec()),
                descriptor: JvmBytes(b"(Ljava/util/Map;I)I".to_vec()),
            },
            stages: AnalysisStage::ALL.to_vec(),
        },
        &mut budget,
    )
    .expect("Reader analyzes the exact baseline physical method");
    let ir = analysis.ir();
    let canonical = ir.canonical().expect("canonical CFG");
    let ssa = ir.ssa().expect("SSA from same run");
    let code = ir.code().expect("complete Code facts");
    let pool = ir.constant_pool();
    let operations = Operations::of(code, pool);
    for instruction in &code.instructions {
        eprintln!("COMPLEX_IF_PROBE {label}: physical-operation bci={} opcode={:#04x} operation={:?}", instruction.bci, instruction.opcode, operations.get(instruction.bci));
    }
    let mut flow_budget = probe_budget();
    let view = NormalFlowView::build(canonical, &mut flow_budget).expect("normal flow view");

    eprintln!("COMPLEX_IF_PROBE {label}: code={:#?}", code.instructions);
    eprintln!("COMPLEX_IF_PROBE {label}: canonical-blocks={:#?}", canonical.blocks());
    eprintln!("COMPLEX_IF_PROBE {label}: canonical-edges={:#?}", canonical.edges());
    eprintln!("COMPLEX_IF_PROBE {label}: normal-flow-ids={:#?}", view.ids());

    eprintln!("COMPLEX_IF_PROBE {label}: all-ssa-phis={:#?}", ssa.phis());
    for names in ssa.blocks() {
        for instruction in names.instructions() {
            eprintln!(
                "COMPLEX_IF_PROBE {label}: ssa-instruction block={:?} bci={} reads={:?} writes={:?}",
                names.block(), instruction.bci(), instruction.reads(), instruction.writes()
            );
        }
    }

    let mut counter_slots = BTreeSet::new();
    for node in 0..view.len() {
        let Some(natural) = view.loop_entered_at(node) else {
            continue;
        };
        if natural.header() != node {
            continue;
        }
        let header = view.id_of(node).expect("loop header identity");
        let block_nodes = natural.blocks();
        let block_ids = block_nodes
            .iter()
            .filter_map(|index| view.id_of(*index).cloned())
            .collect::<Vec<_>>();
        let latches = natural
            .latches()
            .iter()
            .filter_map(|index| view.id_of(*index).cloned())
            .collect::<Vec<_>>();
        let ipdom = view
            .immediate_post_dominator(node)
            .and_then(|index| view.id_of(index))
            .cloned();
        eprintln!(
            "COMPLEX_IF_PROBE {label}: natural-loop header={header:?} blocks={block_ids:?} latches={latches:?} ipdom={ipdom:?} irreducible={}",
            natural.is_irreducible()
        );
        // Probe the existing proof method directly on the same reader-produced graph. This
        // prints the exact ForHeader/update candidate without changing production or guessing a
        // slot; the complete public recovery result below remains the authoritative Region tree.
        let excluded_edge_nodes = canonical
            .edges()
            .iter()
            .filter(|edge| {
                matches!(
                    edge.kind(),
                    CanonicalEdgeKind::Exception { .. } | CanonicalEdgeKind::Call { .. }
                )
            })
            .flat_map(|edge| [edge.from().clone(), edge.to().clone()])
            .collect();
        let chains = crate::concat::plan(ssa, &operations, &crate::build::FieldCopies::default());
        let sites = crate::init::Sites::empty();
        let mut proof_budget = probe_budget();
        let mut walker = Walker {
            canonical,
            view: &view,
            ssa,
            operations: &operations,
            pool,
            chains: &chains,
            sites: &sites,
            code,
            method_synchronized: Some(false),
            has_reachable_explicit_monitor: false,
            return_is_boolean: false,
            handlers: &code.exception_handlers,
            profile: &crate::pass::JAVA_8,
            budget: &mut proof_budget,
            catch_joins: BTreeSet::new(),
            loop_catch_terminal_owners: Vec::new(),
            fragmented: None,
            excluded_edge_nodes,
            visited: BTreeSet::new(),
            unclosed_tail_at: None,
            own_monitor: None,
            depth: 0,
        };
        let terminal_returns = BTreeSet::new();
        let for_header = walker.prove_for_header(header, node, block_nodes, &terminal_returns);
        eprintln!("COMPLEX_IF_PROBE {label}: for-header-candidate={for_header:#?}");
        for edge in canonical.edges().iter().filter(|edge| {
            block_nodes.contains(&view.index_of(edge.from()).unwrap_or(usize::MAX))
                || block_nodes.contains(&view.index_of(edge.to()).unwrap_or(usize::MAX))
        }) {
            eprintln!("COMPLEX_IF_PROBE {label}: loop-edge={edge:?}");
        }
        for block_id in &block_ids {
            let Some(names) = ssa.block(block_id) else {
                continue;
            };
            for instruction in names.instructions() {
                let operation = operations.get(instruction.bci());
                if let Some(Operation::Increment { slot, amount }) = operation {
                    counter_slots.insert(*slot);
                    eprintln!(
                        "COMPLEX_IF_PROBE {label}: loop-counter-update block={block_id:?} bci={} slot={slot} amount={amount} reads={:?} writes={:?}",
                        instruction.bci(), instruction.reads(), instruction.writes()
                    );
                }
                if operation.is_some_and(|op| op.comparison().is_some()) {
                    let branch_node = view.index_of(block_id).expect("branch block in view");
                    let branch_ipdom = view
                        .immediate_post_dominator(branch_node)
                        .and_then(|index| view.id_of(index));
                    eprintln!(
                        "COMPLEX_IF_PROBE {label}: loop-branch bci={} operation={operation:?} successors={:?} ipdom={branch_ipdom:?}",
                        instruction.bci(), view.successor_ids(block_id)
                    );
                }
            }
        }
    }

    // Only the local(s) whose physical increment occurs in a natural loop are treated as loop
    // counters. Their full same-run SSA definitions, uses and phi operands are printed below.
    for slot in counter_slots {
        eprintln!("COMPLEX_IF_PROBE {label}: counter-slot={slot}");
        for phi in ssa.phis().iter().filter(|phi| phi.slot() == Slot::Local(slot)) {
            eprintln!("COMPLEX_IF_PROBE {label}: counter-phi={phi:#?}");
            eprintln!(
                "COMPLEX_IF_PROBE {label}: counter-phi-value={:#?}",
                ssa.value(phi.value())
            );
        }
        for names in ssa.blocks() {
            for instruction in names.instructions() {
                let reads = instruction
                    .reads()
                    .iter()
                    .filter(|(at, _)| *at == Slot::Local(slot))
                    .collect::<Vec<_>>();
                let writes = instruction
                    .writes()
                    .iter()
                    .filter(|(at, _)| *at == Slot::Local(slot))
                    .collect::<Vec<_>>();
                if !reads.is_empty() || !writes.is_empty() {
                    eprintln!(
                        "COMPLEX_IF_PROBE {label}: counter-access block={:?} bci={} reads={reads:?} writes={writes:?}",
                        names.block(), instruction.bci()
                    );
                    for (at, value_id) in instruction.reads().iter().chain(instruction.writes()) {
                        if *at == Slot::Local(slot) {
                            eprintln!(
                                "COMPLEX_IF_PROBE {label}: counter-value {value_id:?}={:#?}",
                                ssa.value(*value_id)
                            );
                        }
                    }
                }
            }
        }
    }

    let chains = crate::concat::plan(ssa, &operations, &crate::build::FieldCopies::default());
    let sites = crate::init::Sites::empty();
    let mut recovery_budget = probe_budget();
    let recovered = recover(
        canonical,
        &view,
        ssa,
        &operations,
        pool,
        &chains,
        &sites,
        code,
        Some(false),
        false,
        &crate::pass::JAVA_8,
        &mut recovery_budget,
    )
    .expect("existing Region recovery completes");
    eprintln!("COMPLEX_IF_PROBE {label}: recovered={recovered:#?}");
    eprintln!("COMPLEX_IF_PROBE {label}: regions-in-method-order={:#?}", recovered.regions);
    eprintln!("COMPLEX_IF_PROBE {label}: fallbacks={:#?}", recovered.fallbacks());
}

#[test]
fn dump_real_complex_if_ir_and_region_result() {
    for (label, bytes, expected_len, expected_blake3) in [
        (
            "debug",
            ORIGINAL_DEBUG,
            2210usize,
            "e555e5a6351a2e4a54c4f292655dbb4be535476f317f62931735472b38922e5d",
        ),
        (
            "no-debug",
            ORIGINAL_NO_DEBUG,
            1519usize,
            "8280bdc62eae2a7e2face43443aea82a3bfb1b12edf42641b059817cf0e670ae",
        ),
    ] {
        assert_eq!(bytes.len(), expected_len, "{label}: frozen class length");
        inspect(label, bytes, expected_blake3);
    }
}
