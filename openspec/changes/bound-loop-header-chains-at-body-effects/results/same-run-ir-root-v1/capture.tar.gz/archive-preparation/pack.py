import gzip,hashlib,io,json,stat,tarfile
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
TMP=Path('/private/tmp')
OUT=ROOT/'openspec/changes/bound-loop-header-chains-at-body-effects/results/same-run-ir-root-v1'
roots={
 'prep-v1':TMP/'jarde-testbreakincomplexif-ir-probe-prep-luna-v1-20261019',
 'prep-v2':TMP/'jarde-testbreakincomplexif-ir-probe-prep-luna-v2-20261019',
 'prep-v3':TMP/'jarde-testbreakincomplexif-ir-probe-prep-luna-v3-20261019',
 'precreated-v2-runner-snapshots':TMP/'jarde-testbreakincomplexif-ir-probe-runner-root-v1-20261019',
 'root-static-review':TMP/'jarde-testbreakincomplexif-ir-probe-review-root-v1-20261019',
 'actual-guarded-probe':TMP/'jarde-testbreakincomplexif-ir-probe-root-v2-20261019',
 'actual-runner':TMP/'jarde-testbreakincomplexif-ir-probe-runner-root-v2-20261019',
 'architecture-source-review':TMP/'jarde-testbreakincomplexif-architecture-luna-v1-20261019',
 'root-baseline-review':TMP/'jarde-complex-if-body-boundary-evidence-review-root-v1-20261019',
 'archive-preparation':Path(__file__).resolve().parent,
}
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not OUT.exists()
accepted=json.loads((roots['actual-guarded-probe']/'root-review.json').read_bytes())
receipt=(roots['actual-guarded-probe']/'execution.json').read_bytes()
assert sha(receipt)==accepted['receipt_sha256'] and accepted['source_restored_exact'] and accepted['target_absent']
rows=[];data={}
for label,base in roots.items():
 assert base.is_dir() and not base.is_symlink()
 for p in sorted(base.rglob('*')):
  assert not p.is_symlink()
  if p.is_dir():continue
  assert p.is_file() and not any(x in ('target','__pycache__') for x in p.parts)
  b=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode);name=label+'/'+str(p.relative_to(base))
  assert name not in data
  data[name]=(p,b,mode);rows.append(dict(archive_path=name,source_path=str(p),bytes=len(b),sha256=sha(b),mode=mode))
manifest=dict(schema='complex-if-same-run-ir-root-v1',members=rows,payload_member_count=len(rows),accepted_probe=accepted,notes=['Facts and cleanup only; no product fix claim. Original baseline archived separately.','Historical unexecuted preparations retained. No CLI/toolchain payload.'])
blob=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
OUT.mkdir(parents=True);archive=OUT/'capture.tar.gz'
with archive.open('xb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,(_,b,mode) in sorted(data.items()):
    m=tarfile.TarInfo(name);m.size=len(b);m.mode=mode;t.addfile(m,io.BytesIO(b))
   m=tarfile.TarInfo('ARCHIVE_INVENTORY.json');m.size=len(blob);m.mode=0o644;t.addfile(m,io.BytesIO(blob))
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(data)+1
 for name,(p,b,mode) in data.items():
  m=t.getmember(name);assert m.isfile() and m.mode==mode and t.extractfile(m).read()==b and p.read_bytes()==b and stat.S_IMODE(p.stat().st_mode)==mode
 assert t.extractfile('ARCHIVE_INVENTORY.json').read()==blob
(OUT/'capture.tar.gz.inventory.json').write_bytes(blob)
result=dict(status='root_packed_and_reopened_every_payload_bytes_modes',payload_members=len(data),archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,inventory_sha256=sha(blob))
(OUT/'root-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
