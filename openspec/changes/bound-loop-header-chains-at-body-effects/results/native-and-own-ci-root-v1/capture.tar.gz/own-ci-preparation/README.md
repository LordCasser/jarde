# Bound loop-header chains at body effects: native / own-CI preparation

Status: private static preparation only. No native or CI acceptance was run. The bundle reuses the frozen accepted tooling from `/private/tmp/jarde-post-test-break-prefix-own-ci-prep-luna-v3-20261019`; inherited native/CI checkers, official per-step ZIP collection, product binder, and the 13 inherited `--extra-critical` identities remain in force.

This leaf adds 11 exact identities: nine `jarde_java` gates under `region::and_body_boundary_tests`, plus the two tests in `p3_complex_if_body_boundary`. The resulting inventory is 71 native gates and 103 built-in CI gates plus the unchanged 13 extra-critical gates (116 total). Workspace target/pass/ignored totals remain derived from actual receipts.

The source inventory adds `crates/jarde-java/src/region/and_body_boundary_tests.rs` and `tests/p3_complex_if_body_boundary.rs`. The fixture root `tests/fixtures/cf09-complex-if-body-boundary` includes the complete original debug/no-debug trees, their two exact plain JARs, source/driver/case plan/runtime/license files, and the separately compiled v2 control class. The candidate fixture copy has the exact current 19-file shared inventory, including the control Java source and compile receipt, and seven filesystem class files; the original JARs retain exactly their three original class entries each. The root control class is pinned to `/private/tmp/jarde-complex-if-body-boundary-controls-root-v2-20261019/execution.json`; its receipt explicitly reports no target execution.

No product commit or final CLI SHA is supplied here. Fill those only from the final product build before collecting acceptance evidence. `pins.json` binds inherited tooling and the new gate/source/fixture contracts; `adaptation.diff` records the textual adaptation from the v3 base.

The copied v3 history files (`v1-to-v2.diff`, `v1-v2.diff`, `v2-to-post-test-v1.diff`, `v2-to-v3.diff`, `v3-manifest.json`, and `fixture-candidate-source-manifest.json`) are inherited historical records. The current adaptation is only `adaptation.diff`; no historical script is used as an acceptance tool.
