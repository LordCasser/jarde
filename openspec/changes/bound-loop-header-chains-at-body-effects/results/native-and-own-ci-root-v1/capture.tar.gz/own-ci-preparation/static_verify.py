#!/usr/bin/env python3
"""Static AST/pin checks only; does not import or run acceptance tools."""
import ast, hashlib, json
from pathlib import Path

OUT=Path('/private/tmp/jarde-loop-header-body-boundary-own-ci-prep-luna-v1-20261019')
BASE=Path('/private/tmp/jarde-post-test-break-prefix-own-ci-prep-luna-v3-20261019')
FIX=OUT/'candidate-fixture-root/tests/fixtures/cf09-complex-if-body-boundary'
SHARED_FIX=Path('/Users/lordcasser/workspace/projects/jarde/tests/fixtures/cf09-complex-if-body-boundary')

def need(v,m):
    if not v: raise RuntimeError(m)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def parse(path): return ast.parse(path.read_text())
def assignments(tree):
    d={}
    for n in tree.body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
            name=n.targets[0].id
            if name=='EXPECTED_FIXTURE_FILES' and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='tuple':
                arg=n.value.args[0]
                if isinstance(arg, ast.Call) and isinstance(arg.func, ast.Name) and arg.func.id == 'sorted':
                    arg = arg.args[0]
                if isinstance(arg,ast.BinOp) and isinstance(arg.op,ast.Add):
                    left = d[name] if isinstance(arg.left, ast.Name) and arg.left.id == name else ast.literal_eval(arg.left)
                    d[name]=tuple(sorted(left+ast.literal_eval(arg.right))); continue
            try:d[name]=ast.literal_eval(n.value)
            except (ValueError,TypeError): pass
        elif isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Name) and isinstance(n.op,ast.Add):
            try:d[n.target.id]=d[n.target.id]+ast.literal_eval(n.value)
            except (KeyError,ValueError,TypeError): pass
    return d

def ci_gates(path):
    env={}; current=None
    for n in parse(path).body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
            name=n.targets[0].id
            if name=='CRITICAL_TESTS':
                if isinstance(n.value,ast.Dict):
                    env[name]=ast.literal_eval(n.value); current=env[name]
                elif isinstance(n.value,ast.DictComp):
                    need(current is not None,'missing critical base')
                    transformed={}
                    for label,(test,target) in current.items():
                        transformed[label]=(('region::protected_prefix_loop_tests::'+test) if target=='jarde_java' else test,target)
                    env[name]=current=transformed
            else:
                try:env[name]=ast.literal_eval(n.value)
                except (ValueError,TypeError): pass
        elif isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='CRITICAL_TESTS' and n.value.func.attr=='update':
            arg=n.value.args[0]
            if isinstance(arg,ast.Name): current.update(env[arg.id])
            else: current.update(ast.literal_eval(arg))
    return current

def native_gates(path, wrapper):
    env=assignments(parse(path)); wen=assignments(parse(wrapper))
    groups=['HISTORICAL_OBJECT_ARGUMENT_GATES','CURRENT_GATES','ENTRY_SPLIT_GATES','IF_LOOP_ENTRY_GATES','LITERAL_BOOLEAN_GATES','CONTINUE_LADDER_GATES','ARRAY_SUBTRACT_GATES','POST_TEST_LOOP_BREAK_GATES','COMPLEX_IF_BODY_BOUNDARY_GATES']
    return list(wen['GATES'])+sum((env[g] for g in groups if g in env),[])

collect=OUT/'collect-own-ci.py'; verify=OUT/'verify-own-ci.py'
ca=assignments(parse(collect)); va=assignments(parse(verify))
need(ca['SOURCE_PATHS']==va['SOURCE_PATHS'],'collector/verifier source inventories differ')
need(ca['FIXTURE_ROOTS']==va['FIXTURE_ROOTS'],'collector/verifier fixture roots differ')
need(ca['EXPECTED_FIXTURE_FILES']==va['EXPECTED_FIXTURE_FILES'],'collector/verifier expected fixture inventories differ')
need(len(ca['SOURCE_PATHS'])==28 and len(set(ca['SOURCE_PATHS']))==28,'source inventory count/uniqueness mismatch')
need('crates/jarde-java/src/region/and_body_boundary_tests.rs' in ca['SOURCE_PATHS'] and 'tests/p3_complex_if_body_boundary.rs' in ca['SOURCE_PATHS'],'new source paths missing')
need('tests/fixtures/cf09-complex-if-body-boundary' in ca['FIXTURE_ROOTS'],'fixture root missing')
actual=tuple(sorted('tests/fixtures/cf09-complex-if-body-boundary/'+p.relative_to(FIX).as_posix() for p in FIX.rglob('*') if p.is_file()))
new_expected=tuple(x for x in ca['EXPECTED_FIXTURE_FILES'] if x.startswith('tests/fixtures/cf09-complex-if-body-boundary/'))
need(actual==new_expected and len(actual)==19,'new fixture root is not exact 19-file inventory')
shared_actual=tuple(sorted('tests/fixtures/cf09-complex-if-body-boundary/'+p.relative_to(SHARED_FIX).as_posix() for p in SHARED_FIX.rglob('*') if p.is_file()))
need(shared_actual==actual,'private fixture inventory differs from current shared fixture inventory')
for rel in actual:
    part=Path(rel).relative_to('tests/fixtures/cf09-complex-if-body-boundary')
    need((FIX/part).read_bytes()==(SHARED_FIX/part).read_bytes(),f'private fixture copy differs from shared source: {rel}')
need(sum(p.name.endswith('.class') for p in FIX.rglob('*.class'))==7,'new fixture root does not contain exactly seven filesystem classes')
need(len(list(FIX.glob('*-plain.jar')))==2,'expected exactly two original profile jars')
import zipfile
for jar in FIX.glob('*-plain.jar'):
    with zipfile.ZipFile(jar) as z: need(len(z.namelist())==3 and all(name.endswith('.class') for name in z.namelist()),f'original JAR class inventory changed: {jar.name}')

old_native=native_gates(BASE/'verify-native.py',BASE/'inherited/ancestor-iterator-verify-native.py')
new_native=native_gates(OUT/'verify-native.py',OUT/'inherited/ancestor-iterator-verify-native.py')
new_native_delta=set(new_native)-set(old_native)
need(len(old_native)==60 and len(new_native)==71 and len(set(new_native))==71,'native gate inventory count/uniqueness mismatch')
need(len(new_native_delta)==11,'native gate delta is not exactly eleven')
old_ci=ci_gates(BASE/'verify-own-ci.py'); new_ci=ci_gates(verify)
old_ci_pairs=set(old_ci.values()); new_ci_pairs=set(new_ci.values()); ci_delta=new_ci_pairs-old_ci_pairs
need(len(old_ci)==92 and len(new_ci)==103 and len(new_ci_pairs)==103,'CI built-in inventory count/uniqueness mismatch')
need(len(ci_delta)==11,'CI built-in gate delta is not exactly eleven')
need(set((name,target) for target,name in new_native_delta)==ci_delta,'native and CI new gate identities differ')
argv=json.loads((OUT/'acceptance-argv.json').read_text())
extras=[(s.split('=',1)[0],s.split('=',1)[1]) for i,s in enumerate(argv['verify_ci']) if s=='--extra-critical' for s in [argv['verify_ci'][i+1]]]
need(len(extras)==13 and len(set(extras))==13,'inherited extra-critical inventory changed')
need(set(extras).isdisjoint(new_ci_pairs),'new built-ins duplicate inherited extra-critical gate')
need(argv['expected_native_critical_gate_count']==71 and argv['expected_ci_exact_gate_count']==116,'acceptance argv gate counts mismatch')
# All inherited execution validators and official step-archive chain stay byte-for-byte identical.
unchanged=['collect-official-logs.py','bind_product_one.py','verify_workspace.py','inherited/ancestor-iterator-verify-native.py']
for rel in unchanged: need((OUT/rel).read_bytes()==(BASE/rel).read_bytes(),f'inherited tool changed: {rel}')
for rel in ['collect-own-ci.py','verify-own-ci.py','verify-native.py']:
    ast.parse((OUT/rel).read_text())
newcls=FIX/'controls/HeaderBodyBoundaryControls.class'
need(sha(newcls)=='c1d2c819c8eb659afba3ca15380eeba9cf632179519100d1965a9eb7ec40bf3d','control class pin mismatch')
source_records=[]
for rel in ca['SOURCE_PATHS']:
    p=Path('/Users/lordcasser/workspace/projects/jarde')/rel
    need(p.is_file(),f'source inventory path missing in shared tree: {rel}')
    source_records.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)})
report={'status':'static_preparation_checks_passed','execution':'no native/CI/toolchain/CLI commands executed','base':str(BASE),'source_paths':{'count':len(ca['SOURCE_PATHS']),'collector_verifier_equal':True,'new':list(ca['SOURCE_PATHS'][-2:]),'current_shared_pins':source_records},'fixtures':{'root':ca['FIXTURE_ROOTS'][-1],'file_count':len(actual),'class_files':7,'original_jars':2,'expected_exact_inventory':True,'private_copy_byte_equal_to_shared':True,'control_class_sha256':sha(newcls)},'gates':{'native_base':len(old_native),'native_total':len(new_native),'native_new':sorted([{'target':t,'test':n} for t,n in new_native_delta],key=lambda x:(x['target'],x['test'])),'ci_builtin_base':len(old_ci),'ci_builtin_total':len(new_ci),'ci_extra_critical_inherited':len(extras),'ci_total':len(new_ci)+len(extras),'ci_new':sorted([{'target':target,'test':name} for name,target in ci_delta],key=lambda x:(x['target'],x['test'])),'new_gate_sets_equal':True},'preserved_tools':{r:sha(OUT/r) for r in unchanged}}
(OUT/'static-review.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':report['status'],'source_count':len(ca['SOURCE_PATHS']),'fixture_count':len(actual),'native_gates':len(new_native),'ci_gates':len(new_ci)+len(extras),'report':str(OUT/'static-review.json')},sort_keys=True))
