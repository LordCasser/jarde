#!/usr/bin/env python3
"""Capture the official GitHub Actions run-log ZIP as a pinned supplemental command."""
from __future__ import annotations
import shutil
import time
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
REPO = 'LordCasser/jarde'

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def need(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)

def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit('usage: collect-official-logs.py EVIDENCE_DIR')
    evidence = Path(sys.argv[1]).resolve(strict=True)
    collection = json.loads((evidence / 'collection.json').read_text(encoding='utf-8'))
    run_id = str(collection.get('run_id', ''))
    need(re.fullmatch(r'[0-9]+', run_id) is not None, 'collection run ID is missing or invalid')
    run = json.loads((evidence / 'run.json').read_text(encoding='utf-8'))
    need(str(run.get('databaseId')) == run_id, 'captured run.json does not match collection run ID')
    need(run.get('headSha') == collection.get('product_sha'), 'captured run head does not match collected product')
    need(collection.get('status') == 'raw collection complete; independent acceptance pending', 'raw collection is not complete')
    archive, errors, supplement = evidence / 'run-logs.zip', evidence / 'run-logs.stderr.raw', evidence / 'step-log-supplement.json'
    need(not archive.exists() and not errors.exists() and not supplement.exists(), 'refusing to overwrite official-log evidence')
    argv = ['gh', 'api', f'repos/{REPO}/actions/runs/{run_id}/logs']
    row = {'argv': argv, 'run_id': run_id, 'product_sha': collection['product_sha'],
           'collection_json_sha256': sha((evidence / 'collection.json').read_bytes()),
           'run_json_sha256': sha((evidence / 'run.json').read_bytes()),
           'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    attempts = []
    for index in range(1, 4):
        attempt_zip = evidence / f'official-zip-attempt-{index}.zip'
        attempt_error = evidence / f'official-zip-attempt-{index}.stderr.raw'
        with attempt_zip.open('xb') as so, attempt_error.open('xb') as se:
            result = subprocess.run(argv, cwd=ROOT, stdout=so, stderr=se)
        attempts.append({'argv': argv, 'exit_code': result.returncode,
            'stdout': {'path': str(attempt_zip), 'bytes': attempt_zip.stat().st_size, 'sha256': sha(attempt_zip.read_bytes())},
            'stderr': {'path': str(attempt_error), 'bytes': attempt_error.stat().st_size, 'sha256': sha(attempt_error.read_bytes())}})
        if result.returncode == 0:
            break
        if index < 3:
            time.sleep(5)
    row['transport_attempts'] = attempts
    for source, target in [(attempt_zip, archive), (attempt_error, errors)]:
        with source.open('rb') as src, target.open('xb') as dst:
            shutil.copyfileobj(src, dst)
        need(source.read_bytes() == target.read_bytes(), 'ZIP transport copy changed bytes')
    row['exit_code'] = result.returncode
    row['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    row['streams'] = {
        'stdout': {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes())},
        'stderr': {'path': str(errors), 'bytes': errors.stat().st_size, 'sha256': sha(errors.read_bytes())},
    }
    supplement.write_text(json.dumps(row, indent=2) + '\n', encoding='utf-8')
    need(result.returncode == 0, 'official run-log ZIP request failed; raw failure was retained')
    need(archive.stat().st_size > 0, 'official run-log ZIP is empty')
    print(json.dumps({'exit_code': result.returncode, 'run_id': run_id, 'zip': row['streams']['stdout']}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
