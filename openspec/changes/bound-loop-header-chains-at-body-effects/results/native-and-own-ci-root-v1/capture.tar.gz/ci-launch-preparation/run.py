import datetime,hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
PREP=Path(__file__).resolve().parent
OUT=Path('/private/tmp/jarde-loop-header-body-boundary-own-ci-launch-root-v1-20261019')
plan=json.loads((PREP/'commands.json').read_text())
assert not (ROOT/'target').exists() and not OUT.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==plan['product']
OUT.mkdir()
r={'status':'running','plan_sha256':hashlib.sha256((PREP/'commands.json').read_bytes()).hexdigest(),'commands':[]}
def save(): (OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for i,argv in enumerate(plan['commands']):
  so=OUT/(str(i)+'.stdout.raw');se=OUT/(str(i)+'.stderr.raw');start=time.monotonic();utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with so.open('xb') as a,se.open('xb') as b: done=subprocess.run(argv,cwd=ROOT,stdout=a,stderr=b)
  row={'index':i,'argv':argv,'cwd':str(ROOT),'started_utc':utc,'duration_seconds':time.monotonic()-start,'exit_code':done.returncode,'stdout':str(so),'stderr':str(se)}
  r['commands'].append(row);save();print(json.dumps({'command':i,'exit_code':done.returncode}),flush=True)
  if done.returncode: raise RuntimeError('own-CI acceptance command failed; preserve raw evidence')
 report=json.loads((OUT/'2.stdout.raw').read_text());assert report['status']=='accepted' and not report['aggregate_step_proofs']
 assert report['ci']['job_count']==4 and report['ci']['expanded_api_step_count']==52 and report['critical_gate_count']==116
 dest=Path(plan['commands'][0][3])/'acceptance.json';assert not dest.exists();dest.write_bytes((OUT/'2.stdout.raw').read_bytes())
 r['status']='root_launch_commands_passed_complete_independent_ci_review';r['acceptance_path']=str(dest);r['target_absent']=not (ROOT/'target').exists();assert r['target_absent']
except BaseException as e:
 r['status']='failed';r['failure']=repr(e);raise
finally: save()
