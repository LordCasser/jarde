#!/usr/bin/env python3
"""Reopen preparation pins and inherited evidence; never runs Cargo or acceptance tools."""
import ast
import difflib
import hashlib
import json
import re
import stat
import zipfile
from pathlib import Path

BUNDLE = Path('/private/tmp/jarde-loop-header-body-boundary-own-ci-prep-luna-v1-20261019')
BASE = Path('/private/tmp/jarde-post-test-break-prefix-own-ci-prep-luna-v3-20261019')
REPO = Path('/Users/lordcasser/workspace/projects/jarde')
CLI = Path('/private/tmp/jarde-loop-header-body-boundary-focused-root-v5-20261019/candidate-cli')
CLI_SHA = '52ff01f7794c962f2fbb9d809612c0cc371ef297de8cb32a29629323d168cbca'
PRODUCT_SHA = 'c8af822ef6d929f8ad1221f58d02e27669c63fc7'
BASE_CI = Path('/private/tmp/jarde-post-test-break-prefix-own-ci-root-v1-20261019')
OUT = Path('/private/tmp/jarde-loop-header-body-boundary-root-ready-audit-luna-v1-20261019')


def need(value, message):
    if not value:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': digest(data)}


def literal_assignments(path):
    env = {}
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name == 'EXPECTED_FIXTURE_FILES' and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == 'tuple':
                arg = node.value.args[0]
                if isinstance(arg, ast.Call) and isinstance(arg.func, ast.Name) and arg.func.id == 'sorted':
                    arg = arg.args[0]
                if isinstance(arg, ast.BinOp) and isinstance(arg.op, ast.Add):
                    left = env[name] if isinstance(arg.left, ast.Name) and arg.left.id == name else ast.literal_eval(arg.left)
                    env[name] = tuple(sorted(left + ast.literal_eval(arg.right)))
                    continue
            try:
                env[name] = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                pass
        elif isinstance(node, ast.AugAssign) and isinstance(node.target, ast.Name) and isinstance(node.op, ast.Add):
            try:
                env[node.target.id] += ast.literal_eval(node.value)
            except (KeyError, ValueError, TypeError):
                pass
    return env


def ci_gates(path):
    current = None
    env = {}
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name == 'CRITICAL_TESTS':
                if isinstance(node.value, ast.Dict):
                    current = ast.literal_eval(node.value)
                elif isinstance(node.value, ast.DictComp):
                    current = {label: (('region::protected_prefix_loop_tests::' + test) if target == 'jarde_java' else test, target)
                               for label, (test, target) in current.items()}
            else:
                try:
                    env[name] = ast.literal_eval(node.value)
                except (ValueError, TypeError):
                    pass
        elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute):
            call = node.value
            if isinstance(call.func.value, ast.Name) and call.func.value.id == 'CRITICAL_TESTS' and call.func.attr == 'update':
                arg = call.args[0]
                current.update(env[arg.id] if isinstance(arg, ast.Name) else ast.literal_eval(arg))
    return current


def native_gates(path, wrapper):
    groups = ('HISTORICAL_OBJECT_ARGUMENT_GATES', 'CURRENT_GATES', 'ENTRY_SPLIT_GATES', 'IF_LOOP_ENTRY_GATES',
              'LITERAL_BOOLEAN_GATES', 'CONTINUE_LADDER_GATES', 'ARRAY_SUBTRACT_GATES',
              'POST_TEST_LOOP_BREAK_GATES', 'COMPLEX_IF_BODY_BOUNDARY_GATES')
    e = literal_assignments(path)
    w = literal_assignments(wrapper)
    return list(w['GATES']) + [pair for name in groups if name in e for pair in e[name]]


def verify_preparation(pins):
    checked = {'source': 0, 'fixture': 0, 'prepared': 0, 'inherited': 0, 'historical': 0}
    for row in pins['source_inventory']['current_shared_files']:
        path = REPO / row['path']
        data = path.read_bytes()
        need(len(data) == row['bytes'] and digest(data) == row['sha256'], f"source pin mismatch: {row['path']}")
        checked['source'] += 1
    fixture_root = BUNDLE / 'candidate-fixture-root'
    for row in pins['fixture_inventory']['files']:
        rel = Path(row['path'])
        candidate = fixture_root / rel
        shared = REPO / rel
        data = candidate.read_bytes()
        need(len(data) == row['bytes'] and digest(data) == row['sha256'], f"fixture pin mismatch: {rel}")
        need(oct(stat.S_IMODE(candidate.stat().st_mode)) == row['mode'], f"fixture mode mismatch: {rel}")
        need(data == shared.read_bytes(), f"fixture differs from shared: {rel}")
        checked['fixture'] += 1
    need(checked['fixture'] == 19 and pins['fixture_inventory']['class_files'] == 7, 'fixture inventory total mismatch')
    expected_root_files = tuple(sorted('tests/fixtures/cf09-complex-if-body-boundary/' + p.relative_to(fixture_root / 'tests/fixtures/cf09-complex-if-body-boundary').as_posix()
                                       for p in (fixture_root / 'tests/fixtures/cf09-complex-if-body-boundary').rglob('*') if p.is_file()))
    for script in ('collect-own-ci.py', 'verify-own-ci.py'):
        env = literal_assignments(BUNDLE / script)
        need(len(env['SOURCE_PATHS']) == 28 and len(set(env['SOURCE_PATHS'])) == 28, f'{script}: source inventory count')
        need(len(env['FIXTURE_ROOTS']) == 11 and len(set(env['FIXTURE_ROOTS'])) == 11, f'{script}: fixture roots')
        files = tuple(x for x in env['EXPECTED_FIXTURE_FILES'] if x.startswith('tests/fixtures/cf09-complex-if-body-boundary/'))
        need(files == expected_root_files, f'{script}: expected fixture inventory')
    for name, row in pins['modified_preparation_files'].items():
        p = BUNDLE / name
        data = p.read_bytes()
        need(len(data) == row['bytes'] and digest(data) == row['sha256'], f'prepared file pin mismatch: {name}')
        checked['prepared'] += 1
    for name, row in pins['unchanged_inherited_tools'].items():
        p = BUNDLE / name
        need(p.read_bytes() == (BASE / name).read_bytes(), f'inherited tool drift: {name}')
        need(digest(p.read_bytes()) == row['sha256'], f'inherited tool hash mismatch: {name}')
        checked['inherited'] += 1
    for name, row in pins['inherited_historical_artifacts'].items():
        p = BUNDLE / name
        need(p.read_bytes() == (BASE / name).read_bytes(), f'historical record drift: {name}')
        need(digest(p.read_bytes()) == row['sha256'], f'historical record hash mismatch: {name}')
        checked['historical'] += 1
    basepins = Path(pins['base_pins']['path'])
    need(digest(basepins.read_bytes()) == pins['base_pins']['sha256'], 'base pins sha mismatch')
    receipt = Path(pins['control_compilation_receipt']['path'])
    need(digest(receipt.read_bytes()) == pins['control_compilation_receipt']['sha256'], 'control receipt sha mismatch')
    pinfile=BUNDLE/'pins.json'; pinbytes=pinfile.read_bytes()
    checked['pins_file']={'path':str(pinfile),'bytes':len(pinbytes),'sha256':digest(pinbytes)}
    return checked, expected_root_files


def verify_diff_and_gates(pins):
    changed = ('collect-own-ci.py', 'verify-own-ci.py', 'verify-native.py', 'acceptance-argv.json', 'README.md', 'manifest.json')
    expected_diff = ''.join(line for rel in changed for line in difflib.unified_diff(
        (BASE / rel).read_text().splitlines(keepends=True) if (BASE / rel).is_file() else [],
        (BUNDLE / rel).read_text().splitlines(keepends=True), fromfile='base/' + rel, tofile='prepared/' + rel))
    need(expected_diff == (BUNDLE / 'adaptation.diff').read_text(), 'adaptation.diff does not exactly match the v3 base delta')
    old_native = native_gates(BASE / 'verify-native.py', BASE / 'inherited/ancestor-iterator-verify-native.py')
    new_native = native_gates(BUNDLE / 'verify-native.py', BUNDLE / 'inherited/ancestor-iterator-verify-native.py')
    native_delta = set(new_native) - set(old_native)
    old_ci = ci_gates(BASE / 'verify-own-ci.py')
    new_ci = ci_gates(BUNDLE / 'verify-own-ci.py')
    ci_delta = {(target, name) for name, target in set(new_ci.values()) - set(old_ci.values())}
    expected_new = {(row['target'], row['test']) for row in pins['new_gates']}
    need(len(old_native) == 60 and len(new_native) == 71 and len(set(new_native)) == 71, 'native gate count/uniqueness')
    need(native_delta == expected_new, 'native gates differ from prepared exact addition')
    need(len(old_ci) == 92 and len(new_ci) == 103 and len(set(new_ci.values())) == 103, 'CI built-in count/uniqueness')
    need(ci_delta == expected_new, 'CI built-in delta differs from native additions')
    argv = json.loads((BUNDLE / 'acceptance-argv.json').read_text())
    base_argv = json.loads((BASE / 'acceptance-argv.json').read_text())
    extra = lambda x: [x['verify_ci'][i + 1] for i, v in enumerate(x['verify_ci']) if v == '--extra-critical']
    need(extra(argv) == extra(base_argv) and len(extra(argv)) == 13, 'inherited extra-critical arguments changed')
    need(not {tuple(x.split('=', 1)) for x in extra(argv)} & ci_delta, 'extra-critical duplicates a new built-in')
    need(argv['expected_native_critical_gate_count'] == 71 and argv['expected_ci_exact_gate_count'] == 116, 'acceptance gate counts')
    # The native and official-CI execution-contract functions are unchanged; only the main gate ledger grew.
    def functions(path):
        return {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n, ast.FunctionDef)}
    old_collect, new_collect = functions(BASE / 'collect-own-ci.py'), functions(BUNDLE / 'collect-own-ci.py')
    old_ci_funcs, new_ci_funcs = functions(BASE / 'verify-own-ci.py'), functions(BUNDLE / 'verify-own-ci.py')
    old_native_funcs, new_native_funcs = functions(BASE / 'verify-native.py'), functions(BUNDLE / 'verify-native.py')
    need(old_collect == new_collect, 'collector execution functions changed beyond source/inventory constants')
    need({k:v for k,v in old_ci_funcs.items() if k != 'main'} == {k:v for k,v in new_ci_funcs.items() if k != 'main'}, 'CI verification functions changed outside main gate ledger')
    need({k:v for k,v in old_native_funcs.items() if k != 'main'} == {k:v for k,v in new_native_funcs.items() if k != 'main'}, 'native verification functions changed outside main gate ledger')
    for p in (BUNDLE / 'collect-own-ci.py', BUNDLE / 'verify-own-ci.py', BUNDLE / 'verify-native.py'):
        ast.parse(p.read_text())
    return {'native_base':len(old_native),'native_total':len(new_native),'native_added':len(native_delta),
            'ci_builtin_base':len(old_ci),'ci_builtin_total':len(new_ci),'ci_added':len(ci_delta),
            'inherited_extra_critical':len(extra(argv)),'ci_total':len(new_ci)+len(extra(argv)),
            'new_gate_identities':sorted([{'target':t,'test':n} for t,n in expected_new],key=lambda z:(z['target'],z['test']))}


def verify_previous_official_ci():
    receipt = json.loads((BASE_CI / 'collection.json').read_text())
    run = json.loads((BASE_CI / 'run.json').read_text())
    api = json.loads((BASE_CI / 'jobs-api.json').read_text())
    supplement = json.loads((BASE_CI / 'step-log-supplement.json').read_text())
    review = json.loads((BASE_CI / 'review.json').read_text())
    need(review.get('status') == 'accepted', 'inherited previous CI review is not accepted')
    need(receipt.get('status') == 'raw collection complete; independent acceptance pending', 'inherited raw CI receipt status')
    need(receipt.get('run_id') == str(run.get('databaseId')) == supplement.get('run_id'), 'inherited CI run binding')
    need(receipt.get('product_sha') == run.get('headSha') == supplement.get('product_sha'), 'inherited CI product binding')
    need(supplement.get('exit_code') == 0, 'inherited official ZIP request did not succeed')
    for channel in ('stdout','stderr'):
        row=supplement['streams'][channel]; p=Path(row['path']); data=p.read_bytes()
        need(len(data)==row['bytes'] and digest(data)==row['sha256'], f'inherited official ZIP {channel} pin')
    need(api.get('total_count') == 4 and len(api.get('jobs', [])) == 4, 'inherited CI jobs API count')
    run_jobs={row['name']:row for row in run.get('jobs',[])}
    api_jobs={row['id']:row for row in api['jobs']}
    need(len(run_jobs)==4 and len(api_jobs)==4, 'inherited run/jobs API inventory')
    step_members=[]; per_job={}
    with zipfile.ZipFile(BASE_CI/'run-logs.zip') as archive:
        names=archive.namelist(); need(len(names)==len(set(names)), 'duplicate inherited ZIP member')
        for api_job in api['jobs']:
            run_job=run_jobs[api_job['name']]
            need(run_job.get('status')=='completed' and run_job.get('conclusion')=='success' and api_job.get('status')=='completed' and api_job.get('conclusion')=='success', 'inherited job not successful')
            need(run_job['databaseId']==api_job['id'], 'inherited run/API job ID mismatch')
            folder=api_job['name'].replace('/','_'); jobs=[]
            for step in api_job['steps']:
                member=f"{folder}/{step['number']}_{step['name'].replace('/','_')}.txt"
                need(member in names, f'missing independent official step log: {member}')
                step_members.append(member); jobs.append(member)
            per_job[api_job['name']]=len(jobs)
        zip_entry_count=len(names)
    need(len(step_members)==52 and len(set(step_members))==52, 'inherited official ZIP does not bind 52 distinct step members')
    need(zip_entry_count==60, 'inherited official ZIP entry inventory differs from 52 steps + job/system entries')
    need(review['ci']['job_count']==4 and review['ci']['expanded_api_step_count']==52, 'accepted inherited review does not report 4 jobs/52 steps')
    seeds=review.get('workspace_seed_runs',[])
    need(len(seeds)==2 and {row['seed'] for row in seeds}=={'5350648285461741569','5350648285461741570'}, 'inherited review does not contain the two independent fixed seeds')
    need(all(row['target_count']==391 and row['workspace_totals']['failed']==0 and len(row['critical_tests_passed'])==105 for row in seeds), 'inherited seed summaries/gate outcomes incomplete')
    need(seeds[0]['target_inventory']==seeds[1]['target_inventory'] and seeds[0]['target_summaries']==seeds[1]['target_summaries'], 'inherited target outcomes differ between seeds')
    need(set(seeds[0]['critical_tests_passed'])==set(seeds[1]['critical_tests_passed']), 'inherited named gates differ between seeds')
    return {'status':review['status'],'run_id':receipt['run_id'],'product_sha':receipt['product_sha'],'job_count':4,
            'official_step_members':len(step_members),'zip_entries':zip_entry_count,'per_job_steps':per_job,
            'two_seed_gate_outcomes':{str(row['seed']):len(row['critical_tests_passed']) for row in seeds},
            'review_sha256':digest((BASE_CI/'review.json').read_bytes()),'zip_sha256':digest((BASE_CI/'run-logs.zip').read_bytes()),
            'official_zip_helper_unchanged':True}


def make_commands(argv):
    product=PRODUCT_SHA
    native_out='<FRESH_NATIVE_EVIDENCE_DIR_OUTSIDE_REPO>'
    ci_out='<FRESH_CI_EVIDENCE_DIR>'
    ci_run='<FINAL_CI_RUN_ID>'
    cli=CLI_SHA
    native_run=list(argv['native_run']); native_run[-1]=native_out
    verify_native=[ 'python3', str(BUNDLE/'verify-native.py'), native_out+'/execution.json', '--out', native_out+'/review.json' ]
    collect_ci=['python3',str(BUNDLE/'collect-own-ci.py'),ci_out,ci_run,product,cli]
    collect_zip=['python3',str(BUNDLE/'collect-official-logs.py'),ci_out]
    verify_ci=['python3',str(BUNDLE/'verify-own-ci.py'),ci_out,'--product-sha',product,'--cli-sha256',cli]
    extras=[argv['verify_ci'][i+1] for i,v in enumerate(argv['verify_ci']) if v=='--extra-critical']
    for value in extras: verify_ci.extend(['--extra-critical',value])
    return {'status':'argv_plan_only_not_executed','bundle_cwd':str(BUNDLE),'repo_cwd':str(REPO),
            'candidate_cli':file_pin(CLI),'candidate_cli_sha256':cli,
            'placeholders':{'product_commit_sha':product,'ci_run_id':ci_run,'native_evidence_dir':native_out,'ci_evidence_dir':ci_out},
            'sequence':[{'argv':native_run,'cwd':str(REPO)}, {'argv':verify_native,'cwd':str(BUNDLE)},
                        {'argv':collect_ci,'cwd':str(BUNDLE)}, {'argv':collect_zip,'cwd':str(BUNDLE)},
                        {'argv':verify_ci,'cwd':str(BUNDLE)}],
            'extra_critical_count':len(extras),'note':'Fill the product SHA and CI run ID from the final published product/run; recheck the final CLI hash before collection.'}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for name in ('audit.json','commands.json','README.md','manifest.json'):
        need(not (OUT/name).exists(), f'refusing to overwrite audit output: {name}')
    pins_path=BUNDLE/'pins.json'; pins=json.loads(pins_path.read_text())
    checked,fixture_files=verify_preparation(pins)
    gates=verify_diff_and_gates(pins)
    cli_pin=file_pin(CLI)
    need(cli_pin['sha256']==CLI_SHA, 'candidate CLI SHA does not match supplied v5 pin')
    previous=verify_previous_official_ci()
    # Current workflow file is source-pinned and matches the previously accepted 4-job workflow.
    workflow_pin=next(x for x in pins['source_inventory']['current_shared_files'] if x['path']=='.github/workflows/ci.yml')
    need(workflow_pin['sha256']== 'b545890a55cc4fda31d70b332889c111d789afbf0949581e96bf2b94ea6cd18a', 'workflow differs from the accepted prior 4-job workflow')
    argv=json.loads((BUNDLE/'acceptance-argv.json').read_text())
    commands=make_commands(argv)
    (OUT/'commands.json').write_text(json.dumps(commands,indent=2,sort_keys=True)+'\n')
    report={'status':'read_only_prep_audit_passed','current_leaf_acceptance':'not_run','cli':cli_pin,
            'preparation_pin_reopen_counts':checked,'fixture_paths':list(fixture_files),'gate_review':gates,
            'inherited_official_ci_evidence':previous,'workflow_sha256':workflow_pin['sha256'],
            'inheritance_checks':{'native_and_CI_existing_gates_retained':True,'official_per_step_ZIP_helpers_byte_identical':True,
                                  'CI_execution_functions_except_added_main_gate_ledger_AST_identical':True,
                                  'two_seed_and_named_gate_checkers_retained':True,
                                  'current_acceptance_expected_official_steps':'dynamic from fresh run receipt; prior accepted receipt had 4 jobs and 52 step members'},
            'product_sha':PRODUCT_SHA,'product_sha_source':'root-provided pushed product commit; not independently checked with Git','commands':'see commands.json'}
    (OUT/'audit.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    readme=('''# Root-ready audit: bound loop-header chains at body effects\n\n'''
            +'''Read-only static audit of the private acceptance preparation. It reopened all source/fixture/tool pins and verified the supplied focused-v5 CLI hash. It did not run Cargo, Git, network, JDK, CLI, native acceptance, or own-CI acceptance.\n\n'''
            +f'''The preparation contains {checked['source']} source pins and {checked['fixture']} fixture pins. The collector/verifier preserve 60 inherited native gates and 92 inherited built-in CI gates, add 11 exact identities, and retain the same 13 `--extra-critical` arguments: 71 native gates and 116 exact CI gates total. The complete 19-file fixture inventory matches the shared tree byte-for-byte.\n\n'''
            +'''The accepted prior own-CI receipt was independently reopened: 4 successful jobs, 52 separately named official per-step ZIP members, and 60 total archive entries. Current preparation retains the same byte-identical per-step ZIP collector and named-step verifier. This prior receipt is inheritance evidence, not acceptance of the current leaf. Fresh leaf CI must still supply its own run and ZIP; the verifier derives that run's actual step count.\n\n'''
            +'''`commands.json` contains the exact command order and inherited 13 gate arguments. The product SHA is set to the root-provided commit `'''+PRODUCT_SHA+'''`; supply the CI run ID. The candidate CLI pin is SHA256 `'''+CLI_SHA+'''`; recheck that the final product CLI remains identical before collection.\n''')
    (OUT/'README.md').write_text(readme)
    # Audit artifacts are mutually pinned by a small manifest without self-reference.
    manifest={}
    for name in ('audit.py','audit.json','commands.json','README.md'):
        data=(OUT/name).read_bytes(); manifest[name]={'bytes':len(data),'sha256':digest(data)}
    (OUT/'manifest.json').write_text(json.dumps({'schema':'loop-header-body-boundary-root-ready-audit-v1','status':'read-only-audit-complete_acceptance-not-run','files':manifest},indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':report['status'],'sources':checked['source'],'fixtures':checked['fixture'],'native_gates':gates['native_total'],'ci_gates':gates['ci_total'],'prior_ci_steps':previous['official_step_members'],'out':str(OUT)},sort_keys=True))


if __name__=='__main__':
    main()
