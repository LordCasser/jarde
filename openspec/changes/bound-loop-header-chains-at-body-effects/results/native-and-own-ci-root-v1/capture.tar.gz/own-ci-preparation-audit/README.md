# Root-ready audit: bound loop-header chains at body effects

Read-only static audit of the private acceptance preparation. It reopened all source/fixture/tool pins and verified the supplied focused-v5 CLI hash. It did not run Cargo, Git, network, JDK, CLI, native acceptance, or own-CI acceptance.

The preparation contains 28 source pins and 19 fixture pins. The collector/verifier preserve 60 inherited native gates and 92 inherited built-in CI gates, add 11 exact identities, and retain the same 13 `--extra-critical` arguments: 71 native gates and 116 exact CI gates total. The complete 19-file fixture inventory matches the shared tree byte-for-byte.

The accepted prior own-CI receipt was independently reopened: 4 successful jobs, 52 separately named official per-step ZIP members, and 60 total archive entries. Current preparation retains the same byte-identical per-step ZIP collector and named-step verifier. This prior receipt is inheritance evidence, not acceptance of the current leaf. Fresh leaf CI must still supply its own run and ZIP; the verifier derives that run's actual step count.

`commands.json` contains the exact command order and inherited 13 gate arguments. The product SHA is set to the root-provided commit `c8af822ef6d929f8ad1221f58d02e27669c63fc7`; supply the CI run ID. The candidate CLI pin is SHA256 `52ff01f7794c962f2fbb9d809612c0cc371ef297de8cb32a29629323d168cbca`; recheck that the final product CLI remains identical before collection.
