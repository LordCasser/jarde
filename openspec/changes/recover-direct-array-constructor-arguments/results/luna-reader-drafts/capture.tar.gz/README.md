# Array initializer reader repair v2

Private candidate only; no shared files were edited and no Rust/Java/JADX toolchain was run.

`candidate-v2.patch` changes only `crates/jarde-java/src/build.rs`. It is based on shared `build.rs` SHA-256 `678d335dd745a81b64d6f925a0301b124b9d435043b1713ab466374b2092a6b8`.

The reader now recognizes only an `invokespecial <init>` call for the constructor-specific path. It scans physical operands once with a budget charge per operand, requires the retained array to occur exactly once in a nonreceiver position, and checks each prefix operand is available before the current last store: method-entry values and a phi in the current block are available at block entry; an instruction definition must be in the same block at an earlier instruction position; caught values are refused. The existing immediate-reader shortcut is bypassed for constructor readers so the same checks apply when the call directly follows the last store.

Only operands after the retained array close the remaining source interval. Ordinary expressions still use `collect_expression_bcis`. A later sibling array is admitted only when its already-proved candidate has the exact physical final SSA value and same constructor consumer; its sources must be strictly after this array's last store and appear once as an operand. Those BCIs help close the interval and undergo shared handler checks, but are not added to the earlier array's sources or ownership. The existing interval equality and dependency-use checks reject gaps and aliases.

`candidate.patch` is an alias of `candidate-v2.patch`. Static whitespace checking passed; the parent must run compilation and the two positive fixtures plus refusal controls. No test result is claimed here.
