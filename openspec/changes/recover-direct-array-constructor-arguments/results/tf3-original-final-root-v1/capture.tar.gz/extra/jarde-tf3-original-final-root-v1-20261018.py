from pathlib import Path
import json,os,importlib.util,zipfile,hashlib,shutil,blake3
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');IN=Path('/private/tmp/jarde-tf3-original-inputs-root-v1-20261018');OUT=Path('/private/tmp/jarde-tf3-original-final-root-v1-20261018');OUT.mkdir();(OUT/'raw').mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','cmp');g=load(ROOT/c.GUARD_REL,'guard');scan=load(ROOT/c.SCANNER_REL,'scan');assert c.sha(ROOT/c.GUARD_REL)==c.GUARD_SHA256 and c.sha(ROOT/c.SCANNER_REL)==c.SCANNER_SHA256;g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:scan.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
jdks,jdkpin=c.configured_jdks(ROOT/c.DEFAULT_JDK_MANIFEST_REL,c.DEFAULT_JDK_MANIFEST_SHA256);cli=Path('/private/tmp/jarde-direct-array-focused-root-v3-20261018/candidate-cli');assert c.sha(cli)=='e01c6014bd1d1d220d72400beeb711791221aa2aa56e60eed0ba52f8714777c0';jadx=Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx');assert c.sha(jadx)=='64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
inputs=json.loads((IN/'execution.json').read_text());assert inputs['status']=='compiled profiles pending independent review';rows=[];report={'status':'running','source_before':c.source_closure(ROOT),'input_receipt':c.pin(IN/'execution.json'),'cli':c.pin(cli),'jadx':c.pin(jadx),'jadx_jar':c.pin(Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')),'jdk':jdkpin,'commands':rows,'jarde_cells':[],'jadx_cells':[]};c.write_json(OUT/'execution.json',report)
def cmd(argv,label):
 env=c.clean_env(dict(os.environ),jdks['javac23']);env.update(g.ENV_VALUES);env.pop('RUST_MIN_STACK',None);r=g.run_command(len(rows)+1,[str(x) for x in argv],env);r['label']=label;rows.append(r);c.write_json(OUT/'execution.json',report);assert r['guard_stop'] is None;return r
for p in inputs['profiles']:
 profile=p['profile'];target=Path(p['target_facts']['path']);classes=IN/profile/'classes';assert target.relative_to(classes).as_posix()=='jadx/tests/integration/trycatch/TestFinally3$TestCls.class'
 assert c.sha(target)==p['target_facts']['sha256'];bundle=OUT/(profile+'.jar')
 with zipfile.ZipFile(bundle,'w') as z:
  for f in sorted(classes.rglob('*.class')):z.writestr(zipfile.ZipInfo(f.relative_to(classes).as_posix(),(1980,1,1,0,0,0)),f.read_bytes())
 for form,inp,policy,cls in [('child',target,'single-class','jadx/tests/integration/trycatch/TestFinally3$TestCls'),('bundle-child',bundle,'plain-jar','jadx/tests/integration/trycatch/TestFinally3$TestCls'),('bundle-owner',bundle,'plain-jar','jadx/tests/integration/trycatch/TestFinally3')]:
  for evidence in ['default','all']:
   argv=[cli,'class-source','--input',inp,'--policy',policy,'--release','8','--class',cls,'--format','json']
   if evidence=='all':argv+=['--evidence','all']
   r=cmd(argv,profile+'-'+form+'-'+evidence);cell={'profile':profile,'form':form,'evidence':evidence,'command':r['index'],'input':c.pin(inp),'exit_code':r['exit_code']};report['jarde_cells'].append(cell)
   raw=c.command_artifact(r,'stdout')
   if raw.startswith(b'{'):
    doc=json.loads(raw);dest=OUT/'jarde'/profile/form/evidence;dest.mkdir(parents=True);(dest/'report.json').write_bytes(raw)
    if isinstance(doc.get('text'),str):(dest/'source.java').write_text(doc['text']);cell['source']=c.pin(dest/'source.java')
   c.write_json(OUT/'execution.json',report)
 for form,inp in [('child',target),('bundle',bundle)]:
  dest=OUT/'jadx'/profile/form;r=cmd([jadx,'--config','none','--threads-count','1','--no-res','--rename-flags','none','-d',dest,inp],'jadx-'+profile+'-'+form);report['jadx_cells'].append({'profile':profile,'form':form,'command':r['index'],'input':c.pin(inp),'exit_code':r['exit_code'],'sources':[c.pin(f) for f in sorted(dest.rglob('*.java'))]});c.write_json(OUT/'execution.json',report)
assert not (ROOT/'target').exists();report['source_after']=c.source_closure(ROOT);assert report['source_before']==report['source_after'];report['status']='final captured pending independent review';report['target_absent']=True;c.write_json(OUT/'execution.json',report);print(json.dumps({'status':report['status'],'commands':len(rows),'jarde_cells':len(report['jarde_cells']),'jadx_cells':len(report['jadx_cells'])}))
