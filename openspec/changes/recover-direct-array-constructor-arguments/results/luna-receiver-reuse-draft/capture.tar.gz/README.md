# Direct-array receiver reuse: private patch and billing evidence

## Scope and status

This is a private, uncompiled proposal against the current shared `crates/jarde-java/src/init.rs`. It changes no shared file and adds no type, mechanism, or budget-table edit. It covers the two repeated facts identified in review:

1. constructor operands are read and charged while selecting the constructor, then read and charged again after selection;
2. non-receiver operands are charged in the producer-validation loop, then iterated and charged a second time to build `physical_argument_counts`.

The minimal patch is [`init.rs.patch`](/private/tmp/jarde-direct-array-receiver-reuse-prep-20261018/init.rs.patch). It returns `(instruction, operands)` from the existing receiver-identity selector, consumes that same vector after selection, accumulates the value counts during the existing producer-validation pass, and removes the duplicate argument-count pass. The existing receiver identity revalidation remains in place. All later argument ordering, dependency, nested-site, array-site, handler, effect, and consumer checks remain textually unchanged.

No Rust compile, tests, Jarde CLI, JDK, Git, Cargo, or network command was run for this note. The root owns integration and the real P5 rerun against the unchanged ledger.

## Source evidence

In the current source, `verify_metered` calls `stack_operands_metered` inside its `<init>` scan and retains only the selected instruction (`init.rs:830-840`). It then calls `stack_operands_metered` again on that same instruction (`init.rs:862-869`). The helper charges `IrItems` once per `instruction.reads()` item and allocates/sorts a fresh vector (`init.rs:1830-1845`). Returning the already-read vector removes the duplicate charge and allocation without changing which receiver is selected or revalidated.

For ordinary constructor arguments, the producer loop charges each `operands.skip(1)` item as it validates its production point and ordering (`init.rs:966-984`). The code later charges and walks the same operands again to populate `physical_argument_counts` (`init.rs:995-1005`). Incrementing the map in the first loop preserves its exact-value multiplicity semantics while avoiding the second charge and iteration. The map is still used by the same `array_serves_argument` closure (`init.rs:1006-1012`).

## P5 attribution

The recorded seed-1 native run is `/private/tmp/jarde-direct-array-workspace-seed1-root-v1-20261018`. Its batch-65 raw output shows `flat-mixed` measured at 2501 `IrItems` against the pinned 2497, and the old whole-corpus direct/shared arms at 35687 against 35654. The other printed billing dimensions match. The test batch failed only the fixed-shape ledger and old per-method ledger assertions; see `65.stdout.raw` around lines 167-187. The report records `pins_unchanged: true` and the target absent after cleanup.

The flat fixture is the four committed classes `Scope`, `Shape`, `LambdaSample`, and `Holder` (`tests/p5_bulk_corpus.rs:345-352, 423-439`). The source fixtures show no explicit allocation in `Scope`, `Shape`, or `LambdaSample`; `Holder` has `new Object()` in `<clinit>` and `new Holder(value)` in `of(int)` (`tests/fixtures/p3-declaration/Holder.java:17-35`). In this flat case the selector reuse therefore accounts for the receiver plus argument reads of those two selected constructor calls (one read for `Object.<init>()`, two for `Holder.<init>(int)`), while the physical-argument recount accounts for the one non-receiver argument to `Holder.<init>(int)`: 1 + 2 + 1 = 4. This means the observed flat +4 is not accurately described as only zero-argument receiver reads.

The whole-corpus +33 cannot be safely attributed site-by-site from the aggregate raw totals alone. `p5_bulk_corpus::corpus()` includes nested/repeated Holder inputs, `ModLike`, `Guarded`, generated many-method and deep-expression classes, and the fixed total folds 187 requests (`tests/p5_bulk_corpus.rs:423-510`; the raw count is in `65.stdout.raw:179-187`). Some constructor invocations have ordinary arguments; a possible new-array/exception-path proof is not a zero-argument-only population. The private patch removes exactly the two repeated passes found in source, but only the root's unchanged-ledger P5 rerun can establish whether their saved charges match +33 in the actual corpus. If a residual remains, retain the old P5 receipt and localize it before changing any ledger.

## Review constraints

- Do not describe every saved `stack_operands_metered` item as a zero-argument receiver; the helper bills all `reads()` entries, while the physical-argument pass separately bills non-receiver values.
- Preserve the `is_the_instance` check in the scan and the later receiver check.
- Keep `physical_argument_counts` multiplicity exact (`== 1` remains the consumer contract); combine counting with an already-charged operand pass rather than removing its accounting altogether.
- Do not adjust `Billing::FLAT_MIXED` or the whole-corpus pin to make the seed pass.
- This patch is intentionally not a compile/test result. Root must integrate it and rerun the pinned P5 tests before concluding the billing change is accounted for.
