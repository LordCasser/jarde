The failure is a test expectation bug: `RecoveryReport.fallbacks` records region-level fallback reasons, while `Quality::Fallback` is computed independently from whole recovery/presentation structure. A completed fallback can therefore have an empty `fallbacks` vector; an existing explanation-only control explicitly asserts this.

The proposed minimal patch deletes only the invalid non-empty-vector assertion and leaves the existing whole-method `Quality::Fallback` and `AssertionError` text assertions unchanged. Default/all parity may still compare fallback vectors for equality. TF3 and exception-only positive tests pair an empty vector with Structured quality, and the stop test does not use the vector as stop evidence, so they have no analogous misuse.

No shared file was edited and no toolchain or CLI was run. Root can inspect the final `twoArrayArguments` report separately if it wants to add more specific refusal evidence.
