// default package

/* JADX INFO: loaded from: javac8.jar:CompleteDirectArrayArguments.class */
public final class CompleteDirectArrayArguments {
    public static int trace;
    public static int failAt = -1;
    public static int ctorFailAt = -1;
    public static int byteSinkCalls;
    public static int referenceSinkCalls;
    public static int intSinkCalls;
    public static int matrixSinkCalls;
    public static int elementSinkCalls;
    public static int pairSinkCalls;
    public static int evaluationSinkCalls;
    public static int elementCtorCalls;
    public static byte[] observedBytes;
    public static Object[] observedObjects;

    /* JADX INFO: loaded from: javac8.jar:CompleteDirectArrayArguments$ByteSink.class */
    public static final class ByteSink {
        public final byte[] value;

        ByteSink(byte[] bArr) {
            CompleteDirectArrayArguments.byteSinkCalls++;
            this.value = bArr;
        }
    }

    /* JADX INFO: loaded from: javac8.jar:CompleteDirectArrayArguments$Element.class */
    public static final class Element {
        public final int value;

        Element(int i) {
            CompleteDirectArrayArguments.elementCtorCalls++;
            if (CompleteDirectArrayArguments.ctorFailAt == i) {
                throw new IllegalArgumentException("element-ctor-" + i);
            }
            this.value = i;
        }
    }

    /* JADX INFO: loaded from: javac8.jar:CompleteDirectArrayArguments$ElementSink.class */
    public static final class ElementSink {
        public final Element[] value;

        ElementSink(Element[] elementArr) {
            CompleteDirectArrayArguments.elementSinkCalls++;
            this.value = elementArr;
        }
    }

    /* JADX INFO: loaded from: javac8.jar:CompleteDirectArrayArguments$EvaluationSink.class */
    public static final class EvaluationSink {
        public final byte[] bytes;
        public final int marker;

        EvaluationSink(byte[] bArr, int i) {
            CompleteDirectArrayArguments.evaluationSinkCalls++;
            this.bytes = bArr;
            this.marker = i;
        }
    }

    /* JADX INFO: loaded from: javac8.jar:CompleteDirectArrayArguments$IntSink.class */
    public static final class IntSink {
        public final int[] value;

        IntSink(int[] iArr) {
            CompleteDirectArrayArguments.intSinkCalls++;
            this.value = iArr;
        }
    }

    /* JADX INFO: loaded from: javac8.jar:CompleteDirectArrayArguments$MatrixSink.class */
    public static final class MatrixSink {
        public final int[][] value;

        MatrixSink(int[][] iArr) {
            CompleteDirectArrayArguments.matrixSinkCalls++;
            this.value = iArr;
        }
    }

    /* JADX INFO: loaded from: javac8.jar:CompleteDirectArrayArguments$PairSink.class */
    public static final class PairSink {
        public final byte[] bytes;
        public final Object[] objects;

        PairSink(byte[] bArr, Object[] objArr) {
            CompleteDirectArrayArguments.pairSinkCalls++;
            this.bytes = bArr;
            this.objects = objArr;
            CompleteDirectArrayArguments.observedBytes = bArr;
            CompleteDirectArrayArguments.observedObjects = objArr;
        }
    }

    /* JADX INFO: loaded from: javac8.jar:CompleteDirectArrayArguments$ReferenceSink.class */
    public static final class ReferenceSink {
        public final Object[] value;

        ReferenceSink(Object[] objArr) {
            CompleteDirectArrayArguments.referenceSinkCalls++;
            this.value = objArr;
        }
    }

    private CompleteDirectArrayArguments() {
    }

    private static int append(int i) {
        trace = (trace * 10) + i;
        if (failAt == i) {
            throw new IllegalStateException("mark-" + i);
        }
        return i;
    }

    private static byte appendByte(int i) {
        trace = (trace * 10) + i;
        if (failAt == i) {
            throw new IllegalStateException("mark-" + i);
        }
        return (byte) i;
    }

    private static int markedLength(int i, int i2) {
        append(i);
        return i2;
    }

    public static ByteSink bareBytes(int i) {
        return new ByteSink(new byte[i]);
    }

    public static ReferenceSink bareReferences(int i) {
        return new ReferenceSink(new Object[i]);
    }

    public static EvaluationSink markedLengthFailureStopsLaterWork() {
        return new EvaluationSink(new byte[markedLength(1, 2)], append(2));
    }

    public static IntSink initializedPrimitive() {
        return new IntSink(new int[]{append(1), append(2)});
    }

    public static ReferenceSink initializedReferences() {
        return new ReferenceSink(new Object[]{"left", "right"});
    }

    public static MatrixSink nestedChildren() {
        return new MatrixSink(new int[][]{new int[]{append(7), append(8)}, new int[]{append(9)}});
    }

    public static MatrixSink bareMultidimensional(int i, int i2) {
        return new MatrixSink(new int[i][i2]);
    }

    public static ElementSink constructedElements() {
        return new ElementSink(new Element[]{new Element(append(3)), new Element(append(4)), new Element(append(5))});
    }

    public static PairSink twoArrayArguments() {
        return new PairSink(new byte[]{appendByte(5)}, new Object[]{new Element(append(6))});
    }
}
