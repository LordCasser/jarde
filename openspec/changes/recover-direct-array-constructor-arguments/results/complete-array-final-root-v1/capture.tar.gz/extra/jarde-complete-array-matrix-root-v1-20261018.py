from pathlib import Path
import importlib.util,json,os,zipfile,shutil,sys,re
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');IN=Path('/private/tmp/jarde-complete-array-inputs-root-v1-20261018');CLI=Path(sys.argv[1]);OUT=Path(sys.argv[2]);FINAL=len(sys.argv)>3 and sys.argv[3]=='final';assert not OUT.exists() and not(ROOT/'target').exists();OUT.mkdir();(OUT/'raw').mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','cmp');g=load(ROOT/c.GUARD_REL,'guard');scan=load(ROOT/c.SCANNER_REL,'scan');assert c.sha(ROOT/c.GUARD_REL)==c.GUARD_SHA256 and c.sha(ROOT/c.SCANNER_REL)==c.SCANNER_SHA256;g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:scan.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
jdks,jdkpin=c.configured_jdks(ROOT/c.DEFAULT_JDK_MANIFEST_REL,c.DEFAULT_JDK_MANIFEST_SHA256);origin=json.loads((IN/'execution.json').read_text());assert origin['status']=='original inputs and fixed 14-case oracle accepted';JADX=Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx');JAR=Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar');assert c.sha(JADX)=='64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7' and c.sha(JAR)=='966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
rows=[];r={'status':'running','mode':'final' if FINAL else 'baseline','cli':c.pin(CLI),'original_receipt':c.pin(IN/'execution.json'),'jdk':jdkpin,'jadx':c.pin(JADX),'jadx_jar':c.pin(JAR),'commands':rows,'cells':[],'source_before':c.source_closure(ROOT)};c.write_json(OUT/'execution.json',r)
expected=re.search(r'```text\n(.*?)\n```',(IN/'README.md').read_text(),re.S).group(1).splitlines();assert len(expected)==14
pins=[c.pin(CLI),c.pin(JADX),c.pin(JAR),c.pin(IN/'CompleteDirectArrayArguments.java'),c.pin(IN/'CompleteDirectArrayArgumentsDriver.java')]+[item for p in origin['profiles'] for item in p['classes']]
def cmd(argv,leg,label):
 env=c.clean_env(dict(os.environ),jdks[leg]);env.update(g.ENV_VALUES);env.pop('RUST_MIN_STACK',None);row=g.run_command(len(rows)+1,[str(x) for x in argv],env);row['label']=label;rows.append(row);c.write_json(OUT/'execution.json',r);assert row['guard_stop'] is None;return row
def compile(src,leg,d,label):
 d.mkdir(parents=True);empty=d.parent/(d.name+'-empty');empty.mkdir();flags=['-source','8','-target','8'] if leg=='javac8' else ['--release','8'];return cmd([jdks[leg]['tools']['javac'],*flags,'-g:none','-proc:none','-encoding','UTF-8','-sourcepath',empty,'-classpath',empty,'-d',d,src],leg,label)
for profile in ['javac8','javac23']:
 original=IN/profile/'classes';bundle=OUT/(profile+'.jar')
 with zipfile.ZipFile(bundle,'w') as z:
  for p in sorted(original.rglob('*.class')):z.writestr(zipfile.ZipInfo(p.name,(1980,1,1,0,0,0)),p.read_bytes())
 inputs=[]
 for evidence in ['default','all']:
  argv=[CLI,'class-source','--input',bundle,'--policy','plain-jar','--release','8','--class','CompleteDirectArrayArguments','--format','json']
  if evidence=='all':argv+=['--evidence','all']
  row=cmd(argv,'javac23','jarde-'+profile+'-'+evidence);assert row['exit_code']==0;raw=c.command_artifact(row,'stdout');doc=json.loads(raw);d=OUT/'jarde'/profile/evidence;d.mkdir(parents=True);(d/'report.json').write_bytes(raw);src=d/'CompleteDirectArrayArguments.java';src.write_text(doc['text']);inputs.append(('jarde',evidence,src))
 d=OUT/'jadx'/profile;row=cmd([JADX,'--config','none','--threads-count','1','--no-res','--rename-flags','none','-d',d,bundle],'javac23','jadx-'+profile);assert row['exit_code']==0;found=list(d.rglob('CompleteDirectArrayArguments.java'));assert len(found)==1;inputs.append(('jadx','default',found[0]))
 for engine,evidence,source in inputs:
  label=engine+'-'+profile+'-'+evidence;cell={'engine':engine,'profile':profile,'evidence':evidence,'source':c.pin(source),'compiles':[]};r['cells'].append(cell)
  for compiler in ['javac8','javac23']:
   target=OUT/'rebuilt'/label/compiler;row=compile(source,compiler,target,label+'-'+compiler+'-compile');one={'compiler':compiler,'command':row['index'],'exit_code':row['exit_code'],'runs':[],'classes':[c.pin(p) for p in sorted(target.rglob('*.class'))]};cell['compiles'].append(one);c.write_json(OUT/'execution.json',r)
   if row['exit_code']!=0:
    if FINAL and engine=='jarde':raise RuntimeError(label+' source compile failed')
    continue
   driver=IN/compiler/'driver'
   for runtime in ['javac8','javac23']:
    row=cmd([jdks[runtime]['tools']['java'],'-Xverify:all','-cp',driver,'CompleteDirectArrayArgumentsDriver',target],runtime,label+'-'+compiler+'-'+runtime+'-run');actual=c.command_artifact(row,'stdout');stderr=c.command_artifact(row,'stderr');oracle=next(x for x in origin['oracles'] if x['compiler']==profile and x['runtime']==runtime);valid=row['exit_code']==0 and actual.decode().splitlines()==expected and stderr==b'' and actual==Path(oracle['stdout']['path']).read_bytes();one['runs'].append({'runtime':runtime,'command':row['index'],'exit_code':row['exit_code'],'matches_14case_oracle':valid});c.write_json(OUT/'execution.json',r)
    if FINAL and engine=='jarde' and not valid:raise RuntimeError(label+' runtime failed')
for rec in pins:assert c.pin(Path(rec['path']))==rec
r['source_after']=c.source_closure(ROOT);assert r['source_before']==r['source_after'];r['target_absent']=not(ROOT/'target').exists();assert r['target_absent'];r['status']='matrix collected pending root review';c.write_json(OUT/'execution.json',r);print(r['status'],len(rows))
