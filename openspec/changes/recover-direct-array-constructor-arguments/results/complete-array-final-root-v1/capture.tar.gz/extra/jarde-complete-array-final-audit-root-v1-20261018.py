from pathlib import Path
import json,hashlib,importlib.util,blake3,zipfile
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');IN=Path('/private/tmp/jarde-complete-array-inputs-root-v1-20261018');OUT=Path('/private/tmp/jarde-complete-array-final-root-v1-20261018')
s=importlib.util.spec_from_file_location('c',ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
d=json.loads((OUT/'execution.json').read_text());orig=json.loads((IN/'execution.json').read_text());assert d['status']=='matrix collected pending root review' and d['source_before']==d['source_after'] and d['target_absent']
for doc in (d,orig):
 for i,row in enumerate(doc['commands'],1):
  assert row['index']==i and row['guard_stop'] is None and row['exit_code']==0 and row['peak_target_bytes']<=1024**3 and row['free_bytes_after']>=5*1024**3
  for pin in row['streams'].values():assert c.pin(Path(pin['path']))==pin
for pin in (d['cli'],d['original_receipt'],d['jadx'],d['jadx_jar']):assert c.pin(Path(pin['path']))==pin
oracles={}
for row in orig['oracles']:
 raw=c.command_artifact(orig['commands'][row['command']-1],'stdout');assert len(raw.decode().splitlines())==14 and not c.command_artifact(orig['commands'][row['command']-1],'stderr');oracles[row['compiler'],row['runtime']]=raw
assert len(oracles)==4 and len(set(oracles.values()))==1
methodrows=[];parity={};usage_differences=[];totals={'jarde':[0,0],'jadx':[0,0]}
for cell in d['cells']:
 engine,profile,evidence=cell['engine'],cell['profile'],cell['evidence'];source=Path(cell['source']['path']);assert c.pin(source)==cell['source']
 for comp in cell['compiles']:
  cmd=d['commands'][comp['command']-1];assert cmd['exit_code']==comp['exit_code']==0 and cmd['argv'][-1]==str(source);totals[engine][0]+=1
  for pin in comp['classes']:assert c.pin(Path(pin['path']))==pin
  for run in comp['runs']:
   cmd=d['commands'][run['command']-1];assert cmd['exit_code']==0 and c.command_artifact(cmd,'stdout')==oracles[profile,run['runtime']] and not c.command_artifact(cmd,'stderr');totals[engine][1]+=1
 if engine!='jarde':continue
 raw=c.command_artifact(next(x for x in d['commands'] if x['label']=='jarde-'+profile+'-'+evidence),'stdout');doc=json.loads(raw);assert source.read_bytes()==doc['text'].encode() and source.with_name('report.json').read_bytes()==raw and doc['execution']['status']=='complete'
 docs=[doc]+[v['child'] for v in doc['member_family']['members']];assert len(docs)==9
 for one in docs:
  identity=one['class'];entry=identity['location']['entry'];name=bytes(entry['raw_name']).decode();p=IN/profile/'classes'/name;raw=p.read_bytes();pin=next(x for v in orig['profiles'] if v['compiler']==profile for x in v['classes'] if x['path']==str(p));assert c.pin(p)==pin;facts=c.parse_class(p);assert identity['class_bytes']=={'digest':blake3.blake3(raw).hexdigest(),'length':len(raw)}
  with zipfile.ZipFile(OUT/(profile+'.jar')) as z:assert z.infolist()[entry['ordinal']].filename==name and z.read(z.infolist()[entry['ordinal']])==raw
  assert len(one['methods'])==len(facts['methods']) and one['execution']['status']=='complete'
  for i,(m,physical) in enumerate(zip(one['methods'],facts['methods'])):
   ident=m['item']['identity'];assert m['item']['index']==i and ident['owner']==identity and bytes(ident['name']).decode()==physical['name'] and bytes(ident['descriptor']).decode()==physical['descriptor'];report=m['outcome']['report'];assert report['quality']=='structured' and report['execution']['status']=='complete' and report['fallbacks']==[];text=report['text'].encode();found=set()
   for seg in report['source_map']['segments']:
    a,b=seg['start'],seg['end'];assert 0<=a<=b<=len(text);text[:a].decode();text[:b].decode()
    for anchor in [seg['origin']['primary'],*seg['origin']['derived']]:
     assert anchor['method']==ident
     if anchor['bci'] is not None:assert anchor['bci'] in physical['code']['bcis'];found.add(anchor['bci'])
   assert found==set(physical['code']['bcis']),(profile,name,physical['name'],sorted(set(physical['code']['bcis'])-found))
   key=(profile,name,i);payload={f:report[f] for f in ('text','source_map','quality','fallbacks')}
   if key in parity:
    assert parity[key][0]==payload
    if parity[key][1]!=report['execution']:usage_differences.append({'profile':profile,'class':name,'method':physical['name'],'default':parity[key][1],'all':report['execution']})
   else:parity[key]=(payload,report['execution'])
   methodrows.append({'profile':profile,'evidence':evidence,'class':name,'method':physical['name'],'descriptor':physical['descriptor'],'mapped_bcis':sorted(found)})
assert totals=={'jarde':[8,16],'jadx':[4,8]} and len(methodrows)==88
review={'status':'root accepted complete positive array family','commands':len(d['commands']),'raw_streams':len(d['commands'])*2,'original_cases':56,'Jarde_compiles_runs_cases':[8,16,224],'JADX_compiles_runs_cases':[4,8,112],'physical_method_configurations':88,'methods':methodrows,'default_all_text_map_quality_fallback_equal':True,'default_all_execution_status_complete':True,'evidence_usage_differences':usage_differences,'limits':'Evidence all performs extra charged work; exact usage equality is not required. No global unit count increment.'}
(OUT/'root-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in review.items() if k not in ('methods','evidence_usage_differences')})
