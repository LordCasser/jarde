#!/usr/bin/env python3
"""Serial evidence collector for the ReverseArrayOrder natural/swapped comparison.

Prepared for root execution only. Invoke with `python -B collect.py --out ...`.
The script preserves CLI/JADX/compiler/JVM observations and makes no claim that a
JADX source output compiles or matches the oracle.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
INPUTS = Path('/private/tmp/jarde-reverse-array-inputs-root-v2-20261018')
DEFAULT_CLI = Path('/private/tmp/jarde-direct-array-focused-root-v3-20261018/candidate-cli')
DEFAULT_CLI_RECEIPT = Path('/private/tmp/jarde-direct-array-focused-root-v3-20261018/execution.json')
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA256 = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA256 = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
JDK_LEGS = ('javac8', 'javac23')
ORDERS = ('natural', 'swapped')
EVIDENCE = ('default', 'all')
EXPECTED_METHODS = {('<init>', '([B[B)V'), ('mark', '(I)I'), ('make', '()LReverseArrayOrder;')}


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def cli_receipt_digest(receipt: dict, cli: Path) -> str:
    records = []
    if isinstance(receipt.get('cli'), dict):
        records.append(receipt['cli'])
    if 'cli_path' in receipt or 'cli_sha256' in receipt:
        records.append({'path': receipt.get('cli_path'), 'sha256': receipt.get('cli_sha256')})
    digests = set()
    for row in records:
        if isinstance(row.get('path'), str) and isinstance(row.get('sha256'), str):
            try:
                if Path(row['path']).resolve() == cli:
                    digests.add(row['sha256'].lower())
            except OSError:
                continue
    if len(digests) != 1:
        raise RuntimeError('CLI receipt does not bind one exact path and digest')
    return next(iter(digests))


def expected_line(mode: str) -> bytes:
    left, right = (1, 2) if mode == 'natural' else (2, 1)
    return f'reverse-array:{mode},trace=12,left={left},right={right}\n'.encode('ascii')


def pin_matches(cmp, record: dict) -> bool:
    try:
        return cmp.pin(Path(record['path'])) == record
    except (OSError, KeyError, ValueError):
        return False


def method_key(method: dict) -> tuple[str, str] | None:
    try:
        identity = method['item']['identity']
        return bytes(identity['name']).decode('utf-8'), bytes(identity['descriptor']).decode('utf-8')
    except (KeyError, TypeError, ValueError):
        return None


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--cli', type=Path, default=DEFAULT_CLI)
    ap.add_argument('--cli-receipt', type=Path, default=DEFAULT_CLI_RECEIPT)
    ap.add_argument('--input-root', type=Path, default=INPUTS)
    args = ap.parse_args()

    root = ROOT.resolve(strict=True)
    out = args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing to overwrite output: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('refusing to run while repository target exists')
    inputs = args.input_root.resolve(strict=True)
    cli = args.cli.resolve(strict=True)
    cli_receipt_path = args.cli_receipt.resolve(strict=True)

    cmp_path = root / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
    cmp = load_module(cmp_path, 'reverse_final_compare_helpers')
    guard_path = root / cmp.GUARD_REL
    scanner_path = root / cmp.SCANNER_REL
    if cmp.sha(guard_path) != cmp.GUARD_SHA256 or cmp.sha(scanner_path) != cmp.SCANNER_SHA256:
        raise SystemExit('run guard/scanner source differs from pinned comparison helpers')
    if cmp.sha(JADX) != JADX_SHA256 or cmp.sha(JADX_JAR) != JADX_JAR_SHA256:
        raise SystemExit('JADX 1.5.6 executable/JAR pin mismatch')

    origin_path = inputs / 'execution.json'
    origin = json.loads(origin_path.read_text(encoding='utf-8'))
    if origin.get('status') != 'valid original and swap bytecode oracles captured; CLI review pending':
        raise SystemExit('reverse origin receipt is not the expected captured-oracle receipt')
    receipt = json.loads(cli_receipt_path.read_text(encoding='utf-8'))
    bound_digest = cli_receipt_digest(receipt, cli)
    if cmp.sha(cli) != bound_digest:
        raise SystemExit('current CLI bytes differ from its receipt-bound digest')
    # The handoff CLI receipt is currently allowed to be failed: capture its exact outputs for
    # independent review, while recording (never hiding) the receipt status below.

    manifest = (root / cmp.DEFAULT_JDK_MANIFEST_REL).resolve(strict=True)
    jdks, jdk_record = cmp.configured_jdks(manifest, cmp.DEFAULT_JDK_MANIFEST_SHA256)
    guard = load_module(guard_path, 'reverse_final_root_guard')
    scanner = load_module(scanner_path, 'reverse_final_target_scanner')
    guard.ROOT = root
    guard.OUT = out / 'raw'
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = cmp.pin
    guard.expected_test_summaries = lambda index, stdout_bytes: None
    if shutil.disk_usage(root).free < 5 * 1024**3:
        raise SystemExit('5 GiB free-space guard failed before run')

    source_path = inputs / 'ReverseArrayOrder.java'
    driver_source = inputs / 'ReverseArrayOrderDriver.java'
    for path in (source_path, driver_source, origin_path, cli_receipt_path, JADX, JADX_JAR, cli):
        if not path.is_file():
            raise SystemExit(f'missing input: {path}')
    input_records = {'source': cmp.pin(source_path), 'driver_source': cmp.pin(driver_source),
                     'origin_receipt': cmp.pin(origin_path), 'cli_receipt': cmp.pin(cli_receipt_path),
                     'cli': cmp.pin(cli), 'jadx': cmp.pin(JADX), 'jadx_jar': cmp.pin(JADX_JAR),
                     'jdk_manifest': cmp.pin(manifest), 'guard': cmp.pin(guard_path),
                     'scanner': cmp.pin(scanner_path)}
    class_records = {}
    driver_records = {}
    for profile in JDK_LEGS:
        profile_record = next(row for row in origin['classes'] if row['compiler'] == profile)
        for mode in ORDERS:
            class_record = profile_record[mode]
            class_path = Path(class_record['path']).resolve(strict=True)
            if not pin_matches(cmp, class_record):
                raise SystemExit(f'origin class changed: {profile}/{mode}')
            class_records[(profile, mode)] = class_path
            input_records[f'{profile}_{mode}_class'] = cmp.pin(class_path)
        driver_class = inputs / profile / 'driver/ReverseArrayOrderDriver.class'
        if not driver_class.is_file():
            raise SystemExit(f'missing precompiled isolated driver: {driver_class}')
        driver_records[profile] = driver_class
        input_records[f'{profile}_driver_class'] = cmp.pin(driver_class)
    for jdk_tools in jdks.values():
        for path in jdk_tools['tools'].values():
            input_records[str(path)] = cmp.pin(path)

    origin_oracles = {}
    for oracle in origin.get('oracles', []):
        profile, mode, runtime = oracle['compiler'], oracle['mode'], oracle['runtime']
        raw = Path(oracle['stdout']['path']).resolve(strict=True)
        if not pin_matches(cmp, oracle['stdout']) or raw.read_bytes() != expected_line(mode):
            raise SystemExit(f'original one-line oracle changed or invalid: {profile}/{mode}/{runtime}')
        cmd_row = origin['commands'][oracle['command'] - 1]
        if cmd_row['exit_code'] != 0 or cmp.command_artifact(cmd_row, 'stderr') != b'':
            raise SystemExit(f'original oracle command failed: {profile}/{mode}/{runtime}')
        origin_oracles[(profile, mode, runtime)] = raw.read_bytes()
    if len(origin_oracles) != 8:
        raise SystemExit(f'expected 8 original oracle rows, found {len(origin_oracles)}')
    input_records['oracle_raw'] = {f'{p}_{m}_{r}': cmp.pin(Path(next(o['stdout']['path'] for o in origin['oracles'] if (o['compiler'], o['mode'], o['runtime']) == (p, m, r)))) for p, m, r in origin_oracles}

    source_before = cmp.source_closure(root)
    out.mkdir(parents=True)
    (out / 'raw').mkdir()
    rows = []
    result = {
        'schema': 'reverse-array-final-collector-prep-v1', 'status': 'running',
        'root': str(root), 'input_root': str(inputs), 'output': str(out),
        'cli_receipt_status': receipt.get('status'),
        'cli_receipt_note': 'Receipt status is recorded as observed; the current CLI is collected without treating its failed receipt as acceptance.',
        'inputs_before': input_records, 'source_pins_before': source_before,
        'origin_receipt_status': origin.get('status'), 'jdk_manifest_record': jdk_record,
        'jadx_profile': {'version': '1.5.6', 'rename_flags': 'none', 'config': 'none', 'resources': False, 'threads': 1},
        'commands': rows, 'original_oracles': [], 'jarde_sources': [], 'jadx_sources': [],
        'rebuilds': [], 'driver_adaptations': [], 'notes': [
            'Full Jarde JSON and emitted source bytes are retained for CLI exit 0 or 4 (and recorded for other exits when stdout exists).',
            'Every generated source is compiled unchanged with both Java 8 target compilers; each successful class is run under both pinned JVMs using the existing isolated driver and its mode argument.',
            'If an emitted source declares a package, only the existing isolated driver lookup string is adapted to that exact FQN and the adapted driver is compiled separately; generated target source bytes remain unchanged.',
            'Jarde natural is expected to compile/run against its natural oracle; Jarde swapped is expected to be refused by compile failure with no runtime on expected behavior. These are recorded comparisons, not assumptions or preconditions.',
            'JADX outputs are observations only; compile/runtime success is never assumed.',
            'Natural class reports may carry the unrelated anonymous_typed_nesting_unproved projection refusal while their three member bodies are complete; this does not gate source capture or runtime measurement.'
        ]}
    cmp.write_json(out / 'execution.json', result)

    def command(label: str, argv: list[object], leg: str, phase: str) -> dict:
        env = cmp.clean_env(dict(os.environ), jdks[leg])
        env.update(guard.ENV_VALUES)
        env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(rows) + 1, [str(item) for item in argv], env)
        row.update({'label': label, 'phase': phase})
        rows.append(row)
        cmp.write_json(out / 'execution.json', result)
        if row.get('guard_stop') is not None:
            raise RuntimeError(f'guard stop at {label}: {row["guard_stop"]}')
        return row

    def fresh_dir(path: Path) -> None:
        if path.exists():
            raise RuntimeError(f'refusing existing output directory: {path}')
        path.mkdir(parents=True)

    def compile_source(source: Path, build_leg: str, classes: Path, label: str) -> dict:
        classes.parent.mkdir(parents=True, exist_ok=True)
        fresh_dir(classes)
        empty = classes.parent / (classes.name + '-empty-sourcepath')
        fresh_dir(empty)
        flags = (['-source', '8', '-target', '8', '-g:none', '-Xlint:-options', '-proc:none']
                 if build_leg == 'javac8' else ['--release', '8', '-g:none', '-proc:none'])
        argv = [jdks[build_leg]['tools']['javac'], *flags, '-encoding', 'UTF-8',
                '-classpath', str(empty), '-sourcepath', str(empty), '-d', str(classes), source]
        return command(label, argv, build_leg, 'whole-source-javac')

    def source_fqn(source: Path) -> str:
        text = source.read_text(encoding='utf-8')
        match = re.search(r'^\s*package\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*;', text, re.M)
        return (match.group(1) + '.' if match else '') + 'ReverseArrayOrder'

    def runtime_driver(profile: str, build_leg: str, fqn: str, label: str) -> Path:
        if fqn == 'ReverseArrayOrder':
            return driver_records[profile].parent
        original = driver_source.read_text(encoding='utf-8')
        needle = 'Class.forName("ReverseArrayOrder", true, loader)'
        replacement = 'Class.forName("' + fqn + '", true, loader)'
        if original.count(needle) != 1:
            raise RuntimeError('existing isolated driver has no unique class-name lookup to adapt')
        adapted_source = out / 'drivers' / profile / build_leg / label / 'ReverseArrayOrderDriver.java'
        adapted_source.parent.mkdir(parents=True, exist_ok=True)
        adapted_source.write_text(original.replace(needle, replacement), encoding='utf-8')
        adapted_classes = adapted_source.parent / 'classes'
        row = compile_source(adapted_source, build_leg, adapted_classes, label + '-driver-compile')
        main_class = adapted_classes / 'ReverseArrayOrderDriver.class'
        if row['exit_code'] != 0 or not main_class.is_file():
            raise RuntimeError(f'package-aware isolated driver failed to compile for {label}')
        result['driver_adaptations'].append({'profile': profile, 'build_compiler': build_leg,
            'target_fqn': fqn, 'source': cmp.pin(adapted_source), 'class': cmp.pin(main_class),
            'compile_command': row['index'], 'exit_code': row['exit_code']})
        return adapted_classes

    def report_methods(doc: dict) -> list[dict]:
        answer = []
        for method in doc.get('methods', []):
            report = method.get('outcome', {}).get('report', {})
            analysis = method.get('outcome', {}).get('analysis', {})
            answer.append({
                'identity': method_key(method), 'outcome_kind': method.get('outcome', {}).get('kind'),
                'quality': report.get('quality'), 'syntax_status': report.get('syntax_status'),
                'execution': report.get('execution'),
                'diagnostics': [{'code': d.get('code'), 'severity': d.get('severity')} for d in report.get('diagnostics', [])]
            })
        return answer

    def capture_jarde(profile: str, mode: str, evidence: str) -> dict:
        class_path = class_records[(profile, mode)]
        argv = [cli, 'class-source', '--input', class_path, '--class', 'ReverseArrayOrder',
                '--policy', 'single-class', '--release', '8', '--format', 'json']
        if evidence == 'all':
            argv.extend(['--evidence', 'all'])
        row = command(f'jarde-{profile}-{mode}-{evidence}', argv, 'javac23', 'jarde-class-source')
        cell = {'profile': profile, 'mode': mode, 'evidence': evidence,
                'input_class': cmp.pin(class_path), 'command': row['index'],
                'exit_code': row['exit_code'], 'stdout': None, 'json': None, 'source': None,
                'class_execution': None, 'anonymous_interface_projection': None,
                'methods': [], 'expected_behavior': ('compile_and_match_oracle' if mode == 'natural' else 'refuse_compile_no_runtime')}
        raw = cmp.command_artifact(row, 'stdout')
        raw_path = out / 'jarde' / profile / mode / evidence / 'report.json'
        raw_path.parent.mkdir(parents=True, exist_ok=True)
        raw_path.write_bytes(raw)
        cell['stdout'] = cmp.pin(raw_path)
        try:
            doc = json.loads(raw.decode('utf-8'))
            text = doc.get('text')
            cell['class_execution'] = doc.get('execution')
            cell['anonymous_interface_projection'] = doc.get('anonymous_interface_projection')
            cell['methods'] = report_methods(doc)
            cell['method_inventory_matches'] = {tuple(m['identity']) for m in cell['methods'] if m['identity']} == EXPECTED_METHODS
            cell['json'] = cmp.pin(raw_path)
            if isinstance(text, str):
                source = raw_path.parent / 'ReverseArrayOrder.java'
                source.write_bytes(text.encode('utf-8'))
                cell['source'] = cmp.pin(source)
        except (UnicodeDecodeError, json.JSONDecodeError, TypeError, AttributeError) as error:
            cell['parse_error'] = f'{type(error).__name__}: {error}'
        result['jarde_sources'].append(cell)
        cmp.write_json(out / 'execution.json', result)
        if cell['source']:
            rebuild('jarde', profile, mode, evidence, Path(cell['source']['path']))
        return cell

    def capture_jadx(profile: str, mode: str) -> dict:
        class_path = class_records[(profile, mode)]
        destination = out / 'jadx' / profile / mode
        destination.parent.mkdir(parents=True, exist_ok=True)
        row = command(f'jadx-{profile}-{mode}', [JADX, '--config', 'none', '--threads-count', '1',
                        '--no-res', '--rename-flags', 'none', '-d', destination, class_path],
                      'javac23', 'jadx-full-source')
        cell = {'profile': profile, 'mode': mode, 'input_class': cmp.pin(class_path),
                'command': row['index'], 'exit_code': row['exit_code'], 'source': None,
                'sources_found': [], 'expected_behavior': 'observe_without_success_assumption'}
        found = sorted(p for p in destination.rglob('ReverseArrayOrder.java') if p.is_file()) if destination.exists() else []
        cell['sources_found'] = [cmp.pin(path) for path in found]
        if len(found) == 1:
            cell['source'] = cmp.pin(found[0])
            rebuild('jadx', profile, mode, 'source', found[0])
        elif row['exit_code'] == 0:
            cell['source_error'] = f'expected one ReverseArrayOrder.java, found {len(found)}'
        result['jadx_sources'].append(cell)
        cmp.write_json(out / 'execution.json', result)
        return cell

    def rebuild(engine: str, profile: str, mode: str, evidence: str, source: Path) -> None:
        fqn = source_fqn(source)
        for build_leg in JDK_LEGS:
            label = f'{engine}-{profile}-{mode}-{evidence}-{build_leg}'
            classes = out / 'rebuilt' / engine / profile / mode / evidence / build_leg / 'classes'
            row = compile_source(source, build_leg, classes, label + '-compile')
            package_path = Path(*fqn.split('.')[:-1])
            target_class = classes / package_path / 'ReverseArrayOrder.class'
            produced = target_class.is_file()
            comp = {'engine': engine, 'profile': profile, 'mode': mode, 'evidence': evidence,
                    'build_compiler': build_leg, 'compile_command': row['index'],
                    'compile_exit_code': row['exit_code'], 'class': cmp.pin(target_class) if produced else None,
                    'class_facts': cmp.parse_class(target_class) if produced else None,
                    'runs': [], 'runtime_matches_origin': None,
                    'expected_compile_behavior': ('success' if engine == 'jarde' and mode == 'natural' else
                                                  'failure' if engine == 'jarde' and mode == 'swapped' else 'observe'),
                    'runtime_expectation': ('both_runtimes_match_origin' if engine == 'jarde' and mode == 'natural' else
                                            'no_runtime_after_expected_compile_refusal' if engine == 'jarde' and mode == 'swapped' else 'observe')}
            if row['exit_code'] == 0 and produced:
                facts = comp['class_facts']
                comp['method_inventory_matches'] = set(cmp.class_methods(facts)) == EXPECTED_METHODS
                driver_dir = runtime_driver(profile, build_leg, fqn,
                    f'{engine}-{profile}-{mode}-{evidence}-{build_leg}')
                for runtime in JDK_LEGS:
                    run = command(f'{label}-run-{runtime}', [jdks[runtime]['tools']['java'], '-Xverify:all',
                                   '-cp', driver_dir, 'ReverseArrayOrderDriver', classes, mode],
                                  runtime, 'rebuilt-isolated-runtime')
                    stdout = cmp.command_artifact(run, 'stdout')
                    stderr = cmp.command_artifact(run, 'stderr')
                    oracle = origin_oracles[(profile, mode, runtime)]
                    expected = expected_line(mode)
                    comp['runs'].append({'runtime': runtime, 'command': run['index'],
                        'exit_code': run['exit_code'], 'stdout_sha256': run['streams']['stdout']['sha256'],
                        'stderr_sha256': run['streams']['stderr']['sha256'],
                        'matches_one_line_oracle': run['exit_code'] == 0 and stdout == oracle == expected and stderr == b''})
                comp['runtime_matches_origin'] = all(item['matches_one_line_oracle'] for item in comp['runs'])
            result['rebuilds'].append(comp)
            cmp.write_json(out / 'execution.json', result)

    # Preserve the original fixed one-line oracle rows in this collector receipt.
    for (profile, mode, runtime), data in sorted(origin_oracles.items()):
        origin_row = next(row for row in origin['oracles'] if (row['compiler'], row['mode'], row['runtime']) == (profile, mode, runtime))
        result['original_oracles'].append({'profile': profile, 'mode': mode, 'runtime': runtime,
             'origin_command': origin_row['command'], 'stdout': cmp.pin(Path(origin_row['stdout']['path'])),
             'sha256': cmp.sha(Path(origin_row['stdout']['path'])), 'one_line_matches_expected': data == expected_line(mode)})
    cmp.write_json(out / 'execution.json', result)

    version = command('jadx-version', [JADX, '--version'], 'javac23', 'jadx-version')
    version_text = (cmp.command_artifact(version, 'stdout') + cmp.command_artifact(version, 'stderr')).decode('utf-8', errors='replace')
    result['jadx_version_observed'] = version_text
    result['jadx_version_contains_1_5_6'] = '1.5.6' in version_text
    cmp.write_json(out / 'execution.json', result)

    for profile in JDK_LEGS:
        for mode in ORDERS:
            for evidence in EVIDENCE:
                capture_jarde(profile, mode, evidence)
            capture_jadx(profile, mode)

    result['source_pins_after'] = cmp.source_closure(root)
    result['source_pins_unchanged'] = result['source_pins_before'] == result['source_pins_after']
    result['inputs_unchanged'] = all(pin_matches(cmp, record) for record in input_records.values()
                                    if isinstance(record, dict) and 'path' in record)
    result['target_absent'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
    result['status'] = 'collected_pending_review'
    cmp.write_json(out / 'execution.json', result)
    print(result['status'], len(rows), len(result['rebuilds']))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
