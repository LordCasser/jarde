from pathlib import Path
import json,hashlib
TMP=Path('/private/tmp')
def checked(name):
 p=TMP/name;d=json.loads((p/'execution.json').read_text())
 for i,row in enumerate(d['commands'],1):
  assert row['index']==i and row['guard_stop'] is None and row['peak_target_bytes']<=1024**3 and row['free_bytes_after']>=5*1024**3
  for pin in row['streams'].values():
   b=Path(pin['path']).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256']
 return p,d
p,d=checked('jarde-reverse-final-root-v1-20261018');assert d['status']=='collected_pending_review' and len(d['commands'])==69 and d['source_pins_unchanged'] and d['inputs_unchanged'] and d['target_absent'];counts={}
for item in d['rebuilds']:
 key=item['engine']+'/'+item['mode'];one=counts.setdefault(key,{'compiles':0,'compile_failures':0,'runs':0,'runtime_failures':0});one['compiles']+=1
 assert d['commands'][item['compile_command']-1]['exit_code']==item['compile_exit_code'];one['compile_failures']+=item['compile_exit_code']!=0
 if item['engine']=='jarde' and item['mode']=='swapped':assert item['compile_exit_code']==1 and item['runs']==[];continue
 assert item['compile_exit_code']==0 and len(item['runs'])==2
 for run in item['runs']:
  cmd=d['commands'][run['command']-1];one['runs']+=1;one['runtime_failures']+=run['exit_code']!=0;assert cmd['exit_code']==run['exit_code']
  raw=Path(cmd['streams']['stderr']['path']).read_text()
  if item['engine']=='jadx' and item['mode']=='swapped':assert run['exit_code']==1 and not run['matches_one_line_oracle'] and 'trace=21, left=2, right=1' in raw
  else:assert run['exit_code']==0 and run['matches_one_line_oracle'] and raw==''
for cell in d['jarde_sources']:
 report=json.loads(Path(cell['json']['path']).read_text());method=next(m for m in report['methods'] if m['item']['name']['escaped']=='make')['outcome']['report'];assert len(report['methods'])==3
 if cell['mode']=='natural':assert method['quality']=='structured' and report['execution']['status']=='partial' and cell['exit_code']==4 and 'anonymous_typed_nesting_unproved' in json.dumps(report['anonymous_interface_projection'])
 else:
  assert method['quality']=='fallback'
  if cell['evidence']=='all':assert not next(x for x in method['news'] if x['head']==0)['presented']
r={'status':'root accepted reverse control scope','commands':69,'raw_streams_reopened':138,'counts':counts,'original_bytecode_oracles':'2compilers x natural/swapped x JVM8/23 =8 verified original runs in reverse-originals-root-v2','JADX_observed_bug':'same argument values 2/1 but effects run 21 instead of original12 in all8 swapped executions','limitations':'Jarde natural class aggregate remains separate anonymous projection Partial/CLI4; swapped method refusal retained, no runtime after8 failed compiles.'};(p/'root-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(r)
p,d=checked('jarde-direct-array-order-probe-root-v1-20261018');assert d['status']=='actual JVM and construction-order control accepted' and d['source_before']==d['source_after'] and d['target_absent'] and len(d['oracles'])==8 and len(d['cells'])==4
for cell in d['cells']:
 assert cell['site']['presented']==(cell['mode']=='natural')
 if cell['mode']=='swapped':assert cell['site']['refusal']['code']=='jre_new_interleaved_effect' and 'BCI 5' in cell['site']['refusal']['message']
(p/'root-review.json').write_text(json.dumps({'status':'root accepted actual suffix dimension reorder control','commands':16,'raw_streams_reopened':32,'verified_original_runs':8,'natural_trace':123,'mutated_trace':132,'both_compilers_natural_site_presented':True,'both_compilers_mutant_site_refused':True,'actual_first_refusal':'jre_new_interleaved_effect at array BCI5; no claim first refusal is at SWAP','limits':'Private counterexample verification/site test; no emitted mutant compilation or runtime is claimed.'},ensure_ascii=False,indent=2)+'\n')
p,d=checked('jarde-direct-array-control-baseline-root-v2-20261018');assert d['status']=='control provenance baseline captured pending root review' and d['source_before']==d['source_after'] and d['target_absent'] and len(d['cells'])==8
for cell in d['cells']:
 assert cell['quality']=='fallback' and not cell['head53_mapped']
 if cell['evidence']=='all':assert cell['head53_site']['presented']
 else:assert cell['head53_site'] is None
(p/'root-review.json').write_text(json.dumps({'status':'root confirmed pre-existing generic fallback source gap','commands':8,'raw_streams_reopened':16,'profiles':2,'CLIs':['7287e856','e01c6014'],'both_default_and_all_head53_unmapped':True,'default_evidence_news_unrequested':True,'all_evidence_head53_presented_but_unmapped':True,'limits':'Fallback provenance debt pre-exists this array change; no fix claimed.'},ensure_ascii=False,indent=2)+'\n')
