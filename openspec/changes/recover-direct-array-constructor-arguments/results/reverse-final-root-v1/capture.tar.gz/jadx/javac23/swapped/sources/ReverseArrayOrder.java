// default package

/* JADX INFO: loaded from: ReverseArrayOrder.class */
public final class ReverseArrayOrder {
    public static int trace;
    public final byte[] left;
    public final byte[] right;

    public ReverseArrayOrder(byte[] bArr, byte[] bArr2) {
        this.left = bArr;
        this.right = bArr2;
    }

    public static int mark(int i) {
        trace = (trace * 10) + i;
        return i;
    }

    public static ReverseArrayOrder make() {
        return new ReverseArrayOrder(new byte[mark(2)], new byte[mark(1)]);
    }
}
