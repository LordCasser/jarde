from pathlib import Path
import subprocess,hashlib,json,os
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');product=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip();assert product.startswith('550b7ff92');tree=subprocess.check_output(['git','ls-tree','-rz','--full-tree',product],cwd=ROOT);blobs={}
for row in tree.split(b'\0'):
 if not row:continue
 meta,p=row.split(b'\t',1);mode,kind,digest=meta.split();
 if kind==b'blob':blobs[os.fsdecode(p)]=digest.decode()
algorithm=subprocess.check_output(['git','rev-parse','--show-object-format'],cwd=ROOT).decode().strip();assert algorithm=='sha1'
records={}
for name,key in [('jarde-direct-array-final-gates-root-v4-20261018','source_after'),('jarde-direct-array-workspace-seed1-root-v1-20261018','source_pins')]:
 p=Path('/private/tmp')/name/'execution.json';d=json.loads(p.read_text());items=d[key];rows=items if isinstance(items,list) else [{'path':str(ROOT/rel),'sha256':sha} for rel,sha in items.items()];bound=[]
 for pin in rows:
  path=Path(pin['path']);relative=path.relative_to(ROOT).as_posix();data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==pin['sha256'];gitdigest=hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest();assert blobs[relative]==gitdigest,(relative,'product mismatch');bound.append({'path':relative,'bytes':len(data),'sha256':pin['sha256'],'git_blob':gitdigest})
 records[name]={'source_count':len(bound),'files':bound}
r={'status':'root source byte binding accepted','product_sha':product,'git_object_format':algorithm,'receipts':records,'limits':'Seed1 running; this binds its starting sources, not execution success. Seed2 binding checked after completion.'};out=Path('/private/tmp/jarde-direct-array-product-binding-root-v1-20261018.json');out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(product,[(k,v['source_count']) for k,v in records.items()])
