

#[test]
fn probe_direct_array_constructor_argument_facts() {
    let methods = [
        ("barePrimitive", "(I)LDirectArrayConstructorArguments$ByteSink;"),
        ("bareReference", "(I)LDirectArrayConstructorArguments$ReferenceSink;"),
        ("initializedPrimitive", "()LDirectArrayConstructorArguments$IntSink;"),
        ("initializedReference", "()LDirectArrayConstructorArguments$ReferenceSink;"),
        ("nestedChildren", "()LDirectArrayConstructorArguments$MatrixSink;"),
        ("bareMultianewarray", "(II)LDirectArrayConstructorArguments$MatrixSink;"),
        ("constructedElements", "()LDirectArrayConstructorArguments$ElementSink;"),
        ("twoArrayArguments", "()LDirectArrayConstructorArguments$PairSink;"),
        ("directStringCharArray", "()Ljava/lang/String;"),
        ("stringOtherDescriptor", "()Ljava/lang/String;"),
        ("directStringCharArrayEffectful", "()Ljava/lang/String;"),
        ("directOtherCharArrayOwner", "()LDirectArrayConstructorArguments$CharSink;"),
    ];

    for compiler in ["javac8", "javac23"] {
    let bytes = std::fs::read(format!("/private/tmp/jarde-direct-array-inputs-root-v3-20261018/{compiler}/classes/DirectArrayConstructorArguments.class")).expect("root frozen fixture");
    eprintln!("COMPILER={compiler}");
    for (name, descriptor) in methods {
        let (analysis, _) = analyzed_caller(&bytes, name, descriptor);
        let ir = analysis.ir();
        let ssa = ir.ssa().expect("SSA");
        let code = ir.code().expect("code");
        let operations = Operations::of(code, ir.constant_pool());
        let fields = field::Plan::empty();
        let chains = crate::concat::Plan::empty();
        let method = crate::facts::MethodFacts::new(name, descriptor, 0);
        let mut budget = proof_budget();
        let composition = ArrayCompositionContext {
            chains: &chains,
            reserved: chains.owned(),
            java_release: 8,
            member_targets: &[],
            method: &method,
            code,
        };
        let mut arrays = crate::build::ArrayInitializers::prove_with_composition(
            ssa,
            &operations,
            &fields,
            Some(&composition),
            &mut budget,
        )
        .expect("array fact scan completes");

        eprintln!("\n=== {name}{descriptor} ===");
        for block in ssa.blocks() {
            for instruction in block.instructions() {
                if let Some(Operation::NewArray { .. }) = operations.get(instruction.bci()) {
                    let outputs: Vec<_> = instruction
                        .writes()
                        .iter()
                        .filter_map(|(slot, value)| {
                            matches!(slot, Slot::Stack(_)).then_some(*value)
                        })
                        .collect();
                    eprintln!(
                        "array bci={} op={:?} reads={:?} writes={:?}",
                        instruction.bci(),
                        operations.get(instruction.bci()),
                        instruction.reads(),
                        instruction.writes(),
                    );
                    for value in outputs {
                        eprintln!("  output={value:?} uses={:?}", ssa.value(value).uses());
                    }
                    eprintln!(
                        "  committed_initializer={} detail={:?}",
                        arrays.has_candidate_at(instruction.bci()),
                        arrays.candidate_debug(instruction.bci()),
                    );
                }
                if let Some(Operation::Invoke(call)) = operations.get(instruction.bci())
                    && call.name() == "<init>"
                {
                    eprintln!(
                        "invoke bci={} descriptor={} physical_operands={:?}",
                        instruction.bci(),
                        call.descriptor(),
                        stack_operands(instruction),
                    );
                }
            }
        }

        let plan = sites_after_array_composition(
            ssa,
            &operations,
            &chains,
            chains.owned(),
            &fields,
            &mut arrays,
            8,
            &[],
            &method,
            code,
            &mut budget,
        )
        .expect("constructor site census completes");
        for site in &plan.sites {
            eprintln!(
                "accepted new head={} ctor={} args={:?} expression={:?} atoms={:?}",
                site.head, site.constructor, site.arguments, site.expression,
                site.single_use_atoms,
            );
        }
        for refusal in &plan.refusals {
            eprintln!(
                "refused new head={} code={} message={}",
                refusal.head,
                format!("{:?}", refusal.refusal),
                "see refusal debug",
            );
        }
    }
    }
}
