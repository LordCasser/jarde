# Same-owner constructor receiver-selection candidate

## Status

Private, uncompiled candidate only. No shared source was edited, and no Git, Cargo, JDK, CLI, or JADX command was run. The unified patch is `receiver-selection.patch`; its staged source copy is `init.rs`. Fixture include paths in the patch are the requested future paths and are not present yet, so this draft has not been compiled or tested.

## Reproduction and BCI evidence

The supplied javac8/all report is `/private/tmp/jarde-same-owner-candidate-v3-matrix-root-v1-20261018/jarde/javac8/all/report.json`. Its `build()LSameOwnerArrayArguments;` `news` records say outer head 0 refuses because the constructor at BCI 15 reads another allocation; accepted same-owner leaves are head/dup/constructor `(10,13,15)` and `(21,24,26)`. The report's source-map segment for the outer expression includes derived BCI 30. The original source at `/private/tmp/jarde-same-owner-array-inputs-root-v1-20261018/SameOwnerArrayArguments.java` passes two same-owner leaves inside an array to the array overload. This supports outer constructor BCI 30 from recorded report evidence, not an inferred offset.

## Proposed selection change

In the existing block scan (current `crates/jarde-java/src/init.rs:791-842`), keep the owner/name filter, but treat each same-owner `<init>` as a candidate: read its stack operands with `stack_operands_metered`, and select it only when the first stack operand is `is_the_instance(ssa, receiver, &[head, dup.bci(), candidate_bci])`. A mismatch advances the scan. This makes BCI 15 and 26 ineligible for outer head 0 but eligible for their own recursively verified sites; BCI 30 is the outer candidate. The existing selected-candidate checks at `init.rs:853-866` and later effects, arguments, handlers, ownership, and pending array-site composition remain in place. Operand reads are charged through the existing helper (`init.rs:1824-1841`); `is_the_instance` is the existing SSA-definition identity predicate (`init.rs:2483-2488`).

The candidate adds both javac fixture includes and a unit through the existing production-order `direct_array_argument_sites` helper. It asserts the three accepted same-owner sites are exactly `(head, constructor) = (0,30), (10,15), (21,26)`, with no duplicate constructor sites. The supplied baseline's first wrong-receiver calls are exercised as scan mismatches. If no later matching receiver constructor exists, `found` remains `None` and the existing `never constructed` refusal at `init.rs:839-842` remains the result; there is no fallback that accepts by owner/BCI alone.

## Verification still required

After the two requested class files arrive, run the focused unit on both compiler legs and the candidate matrix's `build()` method. Verify source-map BCI 30, the unique three-site inventory, and that each of the two constructed elements is committed once. Add or run an explicit no-actual-outer-constructor negative if a pinned fixture is provided; none was present in the scoped fixture search. This static draft does not claim those checks passed.
