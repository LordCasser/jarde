// jarde: presentation of `SameOwnerArrayArguments` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class SameOwnerArrayArguments extends java.lang.Object {
    public static int ctorCalls;

    public int value;

    public SameOwnerArrayArguments[] children;

    public SameOwnerArrayArguments(int arg1) {
        // @method <init>(I)V
        // @declaration a constructor of `SameOwnerArrayArguments`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        SameOwnerArrayArguments.ctorCalls = SameOwnerArrayArguments.ctorCalls + 1;
        this.value = arg1;
        return;
    }

    public SameOwnerArrayArguments(SameOwnerArrayArguments[] arg1) {
        // @method <init>([LSameOwnerArrayArguments;)V
        // @declaration a constructor of `SameOwnerArrayArguments`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        SameOwnerArrayArguments.ctorCalls = SameOwnerArrayArguments.ctorCalls + 1;
        this.children = arg1;
        return;
    }

    public static SameOwnerArrayArguments build() {
        // jarde: not recovered: the recovery run for `build()LSameOwnerArrayArguments;` produced no statement (explanation only); the artifact's own comment lines are below
        // @method build()LSameOwnerArrayArguments;
        // @declaration a static method of `SameOwnerArrayArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the instruction at BCI 0 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 33 30 5 4 8 9 10 13 14 15 18 19 20 21 24 25 26 29
        // the copy at BCI 3 has no proved local assignment
    }
}
