from pathlib import Path
import importlib.util,json,os,zipfile
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');IN=Path('/private/tmp/jarde-direct-array-inputs-root-v3-20261018');OUT=Path('/private/tmp/jarde-direct-array-control-baseline-root-v1-20261018');assert not OUT.exists() and not(ROOT/'target').exists();OUT.mkdir();(OUT/'raw').mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','c');g=load(ROOT/c.GUARD_REL,'g');scan=load(ROOT/c.SCANNER_REL,'s');assert c.sha(ROOT/c.GUARD_REL)==c.GUARD_SHA256 and c.sha(ROOT/c.SCANNER_REL)==c.SCANNER_SHA256;g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:scan.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
jdks,jdkpin=c.configured_jdks(ROOT/c.DEFAULT_JDK_MANIFEST_REL,c.DEFAULT_JDK_MANIFEST_SHA256);r={'status':'running','commands':[],'cells':[],'source_before':c.source_closure(ROOT)};c.write_json(OUT/'execution.json',r)
for profile in ['javac8','javac23']:
 bundle=OUT/(profile+'.jar');classes=IN/profile/'classes'
 with zipfile.ZipFile(bundle,'w') as z:
  for p in sorted(classes.glob('*.class')):z.writestr(zipfile.ZipInfo(p.name,(1980,1,1,0,0,0)),p.read_bytes())
 for cli in [Path('/private/tmp/jarde-exception-only-final-focused-root-v3-20261018/candidate-cli'),Path('/private/tmp/jarde-direct-array-focused-root-v3-20261018/candidate-cli')]:
  for evidence in ['default','all']:
   argv=[str(cli),'class-source','--input',str(bundle),'--class','DirectArrayConstructorArguments','--policy','plain-jar','--release','8','--format','json']
   if evidence=='all':argv+=['--evidence','all']
   env=c.clean_env(dict(os.environ),jdks['javac23']);env.update(g.ENV_VALUES);row=g.run_command(len(r['commands'])+1,argv,env);r['commands'].append(row);assert row['exit_code'] in (0,4) and row['guard_stop'] is None;raw=c.command_artifact(row,'stdout');doc=json.loads(raw);dest=OUT/profile/c.sha(cli)[:12]/evidence;dest.mkdir(parents=True);(dest/'report.json').write_bytes(raw);(dest/'DirectArrayConstructorArguments.java').write_text(doc['text']);m=next(m for m in doc['methods'] if m['item']['name']['escaped']=='twoArrayArguments');b=m['outcome']['report'];covered={a['bci'] for s in b['source_map']['segments'] for a in [s['origin']['primary'],*s['origin']['derived']] if a['bci'] is not None};site=next(x for x in b['news'] if x['head']==53);r['cells'].append({'profile':profile,'cli':c.pin(cli),'evidence':evidence,'command':row['index'],'quality':b['quality'],'fallbacks':b['fallbacks'],'head53_site':site,'head53_mapped':53 in covered});c.write_json(OUT/'execution.json',r)
r['source_after']=c.source_closure(ROOT);assert r['source_before']==r['source_after'];r['target_absent']=not(ROOT/'target').exists();r['status']='control provenance baseline captured pending root review';c.write_json(OUT/'execution.json',r);print(r['status'],len(r['commands']))
