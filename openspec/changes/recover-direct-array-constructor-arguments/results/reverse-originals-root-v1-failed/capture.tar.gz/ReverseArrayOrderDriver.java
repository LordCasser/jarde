import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

public final class ReverseArrayOrderDriver {
    private ReverseArrayOrderDriver() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 2 || !("natural".equals(args[1]) || "swapped".equals(args[1]))) {
            throw new IllegalArgumentException("expected target directory and natural|swapped");
        }
        File targetDirectory = new File(args[0]).getCanonicalFile();
        URL targetUrl = targetDirectory.toURI().toURL();
        try (URLClassLoader loader = new URLClassLoader(
                new URL[] {targetUrl}, ClassLoader.getSystemClassLoader().getParent())) {
            Class<?> target = Class.forName("ReverseArrayOrder", true, loader);
            URL actualLocation = target.getProtectionDomain().getCodeSource().getLocation();
            if (!targetUrl.toURI().normalize().equals(actualLocation.toURI().normalize())) {
                throw new AssertionError("target loaded from " + actualLocation + ", expected " + targetUrl);
            }
            Field trace = target.getField("trace");
            trace.setInt(null, 0);
            Method make = target.getMethod("make");
            Object result = make.invoke(null);
            int observedTrace = trace.getInt(null);
            byte[] left = (byte[]) target.getField("left").get(result);
            byte[] right = (byte[]) target.getField("right").get(result);
            int expectedLeft = "natural".equals(args[1]) ? 1 : 2;
            int expectedRight = "natural".equals(args[1]) ? 2 : 1;
            if (observedTrace != 12 || left == null || right == null
                    || left.length != expectedLeft || right.length != expectedRight) {
                throw new AssertionError("trace=" + observedTrace + ", left="
                        + (left == null ? "null" : left.length) + ", right="
                        + (right == null ? "null" : right.length));
            }
            System.out.println("reverse-array:" + args[1] + ",trace=12,left="
                    + left.length + ",right=" + right.length);
        }
    }
}
