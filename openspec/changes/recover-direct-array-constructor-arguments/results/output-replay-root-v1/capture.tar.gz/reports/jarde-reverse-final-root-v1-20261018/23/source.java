// jarde: presentation of `ReverseArrayOrder` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class ReverseArrayOrder extends java.lang.Object {
    public static int trace;

    public final byte[] left;

    public final byte[] right;

    public ReverseArrayOrder(byte[] arg1, byte[] arg2) {
        // @method <init>([B[B)V
        // @declaration a constructor of `ReverseArrayOrder`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.left = arg1;
        this.right = arg2;
        return;
    }

    public static int mark(int arg0) {
        // @method mark(I)I
        // @declaration a static method of `ReverseArrayOrder`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        ReverseArrayOrder.trace = ReverseArrayOrder.trace * 10 + arg0;
        return arg0;
    }

    public static ReverseArrayOrder make() {
        // jarde: not recovered: the recovery run for `make()LReverseArrayOrder;` produced no statement (explanation only); the artifact's own comment lines are below
        // @method make()LReverseArrayOrder;
        // @declaration a static method of `ReverseArrayOrder`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the instruction at BCI 0 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 8 5
        // the array instruction at BCI 8 produces a value nothing in this body reads, so the instruction the bytecode runs has no place in the text
        // @bytecode 14 11
        // the array instruction at BCI 14 produces a value nothing in this body reads, so the instruction the bytecode runs has no place in the text
        // @bytecode 16
        // the instruction at BCI 16 is not part of the provable subset
        // @bytecode 5 8 11 14 17
        // the dependency chain from BCI 17 to final consumer 20 is not bounded
        // @bytecode 20 17 8 5 14 11
        // the value at BCI 20 was produced by a saved declaration this run could not commit
    }
}
