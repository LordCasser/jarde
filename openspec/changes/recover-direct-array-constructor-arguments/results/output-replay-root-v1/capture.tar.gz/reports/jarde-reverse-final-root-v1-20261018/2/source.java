// jarde: presentation of `ReverseArrayOrder` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class ReverseArrayOrder extends java.lang.Object {
    public static int trace;

    public final byte[] left;

    public final byte[] right;

    public ReverseArrayOrder(byte[] arg1, byte[] arg2) {
        // @method <init>([B[B)V
        // @declaration a constructor of `ReverseArrayOrder`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.left = arg1;
        this.right = arg2;
        return;
    }

    public static int mark(int arg0) {
        // @method mark(I)I
        // @declaration a static method of `ReverseArrayOrder`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        ReverseArrayOrder.trace = ReverseArrayOrder.trace * 10 + arg0;
        return arg0;
    }

    public static ReverseArrayOrder make() {
        // @method make()LReverseArrayOrder;
        // @declaration a static method of `ReverseArrayOrder`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new ReverseArrayOrder(new byte[mark(1)], new byte[mark(2)]);
    }
}
