// jarde: presentation of `CompleteDirectArrayArguments` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class CompleteDirectArrayArguments extends java.lang.Object {
    public static int trace;

    public static int failAt;

    public static int ctorFailAt;

    public static int byteSinkCalls;

    public static int referenceSinkCalls;

    public static int intSinkCalls;

    public static int matrixSinkCalls;

    public static int elementSinkCalls;

    public static int pairSinkCalls;

    public static int evaluationSinkCalls;

    public static int elementCtorCalls;

    public static byte[] observedBytes;

    public static java.lang.Object[] observedObjects;

    private CompleteDirectArrayArguments() {
        // @method <init>()V
        // @declaration a constructor of `CompleteDirectArrayArguments`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    private static int append(int arg0) {
        // @method append(I)I
        // @declaration a static method of `CompleteDirectArrayArguments`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        CompleteDirectArrayArguments.trace = CompleteDirectArrayArguments.trace * 10 + arg0;
        if (CompleteDirectArrayArguments.failAt == arg0) {
            throw new java.lang.IllegalStateException("mark-" + arg0);
        } else {
            return arg0;
        }
    }

    private static byte appendByte(int arg0) {
        // @method appendByte(I)B
        // @declaration a static method of `CompleteDirectArrayArguments`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        CompleteDirectArrayArguments.trace = CompleteDirectArrayArguments.trace * 10 + arg0;
        if (CompleteDirectArrayArguments.failAt == arg0) {
            throw new java.lang.IllegalStateException("mark-" + arg0);
        } else {
            return (byte) arg0;
        }
    }

    private static int markedLength(int arg0, int arg1) {
        // @method markedLength(II)I
        // @declaration a static method of `CompleteDirectArrayArguments`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        append(arg0);
        return arg1;
    }

    public static ByteSink bareBytes(int arg0) {
        // @method bareBytes(I)LCompleteDirectArrayArguments$ByteSink;
        // @declaration a static method of `CompleteDirectArrayArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new ByteSink(new byte[arg0]);
    }

    public static ReferenceSink bareReferences(int arg0) {
        // @method bareReferences(I)LCompleteDirectArrayArguments$ReferenceSink;
        // @declaration a static method of `CompleteDirectArrayArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new ReferenceSink(new java.lang.Object[arg0]);
    }

    public static EvaluationSink markedLengthFailureStopsLaterWork() {
        // @method markedLengthFailureStopsLaterWork()LCompleteDirectArrayArguments$EvaluationSink;
        // @declaration a static method of `CompleteDirectArrayArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new EvaluationSink(new byte[markedLength(1, 2)], append(2));
    }

    public static IntSink initializedPrimitive() {
        // @method initializedPrimitive()LCompleteDirectArrayArguments$IntSink;
        // @declaration a static method of `CompleteDirectArrayArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new IntSink(new int[]{append(1), append(2)});
    }

    public static ReferenceSink initializedReferences() {
        // @method initializedReferences()LCompleteDirectArrayArguments$ReferenceSink;
        // @declaration a static method of `CompleteDirectArrayArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new ReferenceSink(new java.lang.Object[]{"left", "right"});
    }

    public static MatrixSink nestedChildren() {
        // @method nestedChildren()LCompleteDirectArrayArguments$MatrixSink;
        // @declaration a static method of `CompleteDirectArrayArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new MatrixSink(new int[][]{new int[]{append(7), append(8)}, new int[]{append(9)}});
    }

    public static MatrixSink bareMultidimensional(int arg0, int arg1) {
        // @method bareMultidimensional(II)LCompleteDirectArrayArguments$MatrixSink;
        // @declaration a static method of `CompleteDirectArrayArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new MatrixSink(new int[arg0][arg1]);
    }

    public static ElementSink constructedElements() {
        // @method constructedElements()LCompleteDirectArrayArguments$ElementSink;
        // @declaration a static method of `CompleteDirectArrayArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new ElementSink(new Element[]{new Element(append(3)), new Element(append(4)), new Element(append(5))});
    }

    public static PairSink twoArrayArguments() {
        // @method twoArrayArguments()LCompleteDirectArrayArguments$PairSink;
        // @declaration a static method of `CompleteDirectArrayArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new PairSink(new byte[]{appendByte(5)}, new java.lang.Object[]{new Element(append(6))});
    }

    static {
        // @method <clinit>()V
        // @declaration a static initializer of `CompleteDirectArrayArguments`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        CompleteDirectArrayArguments.failAt = -1;
        CompleteDirectArrayArguments.ctorFailAt = -1;
    }

    public static final class Element extends java.lang.Object {
        public final int value;

        Element(int arg1) {
            // @method <init>(I)V
            // @declaration a constructor of `CompleteDirectArrayArguments$Element`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            CompleteDirectArrayArguments.elementCtorCalls = CompleteDirectArrayArguments.elementCtorCalls + 1;
            if (CompleteDirectArrayArguments.ctorFailAt == arg1) {
                throw new java.lang.IllegalArgumentException("element-ctor-" + arg1);
            } else {
                this.value = arg1;
                return;
            }
        }
    }

    public static final class EvaluationSink extends java.lang.Object {
        public final byte[] bytes;

        public final int marker;

        EvaluationSink(byte[] arg1, int arg2) {
            // @method <init>([BI)V
            // @declaration a constructor of `CompleteDirectArrayArguments$EvaluationSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            CompleteDirectArrayArguments.evaluationSinkCalls = CompleteDirectArrayArguments.evaluationSinkCalls + 1;
            this.bytes = arg1;
            this.marker = arg2;
            return;
        }
    }

    public static final class PairSink extends java.lang.Object {
        public final byte[] bytes;

        public final java.lang.Object[] objects;

        PairSink(byte[] arg1, java.lang.Object[] arg2) {
            // @method <init>([B[Ljava/lang/Object;)V
            // @declaration a constructor of `CompleteDirectArrayArguments$PairSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            CompleteDirectArrayArguments.pairSinkCalls = CompleteDirectArrayArguments.pairSinkCalls + 1;
            this.bytes = arg1;
            this.objects = arg2;
            CompleteDirectArrayArguments.observedBytes = arg1;
            CompleteDirectArrayArguments.observedObjects = arg2;
            return;
        }
    }

    public static final class ElementSink extends java.lang.Object {
        public final Element[] value;

        ElementSink(Element[] arg1) {
            // @method <init>([LCompleteDirectArrayArguments$Element;)V
            // @declaration a constructor of `CompleteDirectArrayArguments$ElementSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            CompleteDirectArrayArguments.elementSinkCalls = CompleteDirectArrayArguments.elementSinkCalls + 1;
            this.value = arg1;
            return;
        }
    }

    public static final class MatrixSink extends java.lang.Object {
        public final int[][] value;

        MatrixSink(int[][] arg1) {
            // @method <init>([[I)V
            // @declaration a constructor of `CompleteDirectArrayArguments$MatrixSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            CompleteDirectArrayArguments.matrixSinkCalls = CompleteDirectArrayArguments.matrixSinkCalls + 1;
            this.value = arg1;
            return;
        }
    }

    public static final class IntSink extends java.lang.Object {
        public final int[] value;

        IntSink(int[] arg1) {
            // @method <init>([I)V
            // @declaration a constructor of `CompleteDirectArrayArguments$IntSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            CompleteDirectArrayArguments.intSinkCalls = CompleteDirectArrayArguments.intSinkCalls + 1;
            this.value = arg1;
            return;
        }
    }

    public static final class ReferenceSink extends java.lang.Object {
        public final java.lang.Object[] value;

        ReferenceSink(java.lang.Object[] arg1) {
            // @method <init>([Ljava/lang/Object;)V
            // @declaration a constructor of `CompleteDirectArrayArguments$ReferenceSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            CompleteDirectArrayArguments.referenceSinkCalls = CompleteDirectArrayArguments.referenceSinkCalls + 1;
            this.value = arg1;
            return;
        }
    }

    public static final class ByteSink extends java.lang.Object {
        public final byte[] value;

        ByteSink(byte[] arg1) {
            // @method <init>([B)V
            // @declaration a constructor of `CompleteDirectArrayArguments$ByteSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            CompleteDirectArrayArguments.byteSinkCalls = CompleteDirectArrayArguments.byteSinkCalls + 1;
            this.value = arg1;
            return;
        }
    }
}
