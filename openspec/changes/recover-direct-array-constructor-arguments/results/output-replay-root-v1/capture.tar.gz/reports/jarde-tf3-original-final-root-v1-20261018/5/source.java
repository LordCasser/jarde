// jarde: presentation of `jadx/tests/integration/trycatch/TestFinally3` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.trycatch;

public class TestFinally3 extends jadx.tests.api.SmaliTest {
    public TestFinally3() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.trycatch.TestFinally3`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    @org.junit.jupiter.api.Test
    public void test() {
        // @method test()V
        // @declaration an instance method of `jadx.tests.integration.trycatch.TestFinally3`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        jadx.tests.api.utils.assertj.JadxCodeAssertions saved0 = jadx.tests.api.utils.assertj.JadxAssertions.assertThat((jadx.core.dex.nodes.ClassNode) this.getClassNode(TestCls.class)).code().containsOne("} finally {");
        ((jadx.tests.api.utils.assertj.JadxCodeAssertions) saved0.doesNotContain(new java.lang.CharSequence[]{"close(null);"})).containsOne("close(inputStream);");
        return;
    }

    @jadx.NotYetImplemented(value = "Finally extract failed")
    @org.junit.jupiter.api.Test
    public void test2NoDebug() {
        // @method test2NoDebug()V
        // @declaration an instance method of `jadx.tests.integration.trycatch.TestFinally3`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        this.noDebugInfo();
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat((jadx.core.dex.nodes.ClassNode) this.getClassNode(TestCls.class)).code().containsOne("} finally {").containsOne(indent() + "close(");
        return;
    }

    @org.junit.jupiter.api.Test
    public void testSmali() {
        // @method testSmali()V
        // @declaration an instance method of `jadx.tests.integration.trycatch.TestFinally3`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        jadx.tests.api.utils.assertj.JadxCodeAssertions saved0 = jadx.tests.api.utils.assertj.JadxAssertions.assertThat((jadx.core.dex.nodes.ClassNode) this.getClassNodeFromSmali()).code();
        ((jadx.tests.api.utils.assertj.JadxCodeAssertions) saved0.doesNotContain(new java.lang.CharSequence[]{"Type inference failed"})).containsOne("} finally {");
        return;
    }

    public static class TestCls extends java.lang.Object {
        public byte[] bytes;

        public TestCls() {
            // @method <init>()V
            // @declaration a constructor of `jadx.tests.integration.trycatch.TestFinally3$TestCls`, member flags 0x0001
            // recovered from bytecode; presentation is not claimed to compile
            super();
            return;
        }

        public byte[] test() throws java.lang.Exception {
            // @method test()[B
            // @declaration an instance method of `jadx.tests.integration.trycatch.TestFinally3$TestCls`, member flags 0x0001
            // recovered from bytecode; presentation is not claimed to compile
            java.io.InputStream inputStream;
            inputStream = null;
            try {
                byte[] local2;
                if (this.bytes == null) {
                    if (!this.validate()) {
                        return null;
                    } else {
                        inputStream = this.getInputStream();
                        this.bytes = this.read(inputStream);
                    }
                }
                local2 = this.convert(this.bytes);
                return local2;
            } finally {
                close(inputStream);
            }
        }

        private byte[] convert(byte[] bytes) throws java.lang.Exception {
            // @method convert([B)[B
            // @declaration an instance method of `jadx.tests.integration.trycatch.TestFinally3$TestCls`, member flags 0x0002
            // recovered from bytecode; presentation is not claimed to compile
            return new byte[0];
        }

        private boolean validate() throws java.lang.Exception {
            // @method validate()Z
            // @declaration an instance method of `jadx.tests.integration.trycatch.TestFinally3$TestCls`, member flags 0x0002
            // recovered from bytecode; presentation is not claimed to compile
            return false;
        }

        private java.io.InputStream getInputStream() throws java.lang.Exception {
            // @method getInputStream()Ljava/io/InputStream;
            // @declaration an instance method of `jadx.tests.integration.trycatch.TestFinally3$TestCls`, member flags 0x0002
            // recovered from bytecode; presentation is not claimed to compile
            return new java.io.ByteArrayInputStream(new byte[0]);
        }

        private byte[] read(java.io.InputStream in) throws java.lang.Exception {
            // @method read(Ljava/io/InputStream;)[B
            // @declaration an instance method of `jadx.tests.integration.trycatch.TestFinally3$TestCls`, member flags 0x0002
            // recovered from bytecode; presentation is not claimed to compile
            return new byte[0];
        }

        private static void close(java.io.InputStream is) {
            // @method close(Ljava/io/InputStream;)V
            // @declaration a static method of `jadx.tests.integration.trycatch.TestFinally3$TestCls`, member flags 0x000a
            // recovered from bytecode; presentation is not claimed to compile
            return;
        }
    }
}
