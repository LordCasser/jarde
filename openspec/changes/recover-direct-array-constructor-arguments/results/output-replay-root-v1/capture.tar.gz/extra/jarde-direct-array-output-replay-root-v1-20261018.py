from pathlib import Path
import importlib.util,json,os,sys,hashlib
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');CLI=Path(sys.argv[1]);OUT=Path(sys.argv[2]);assert not OUT.exists() and not(ROOT/'target').exists();OUT.mkdir();(OUT/'raw').mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','c');g=load(ROOT/c.GUARD_REL,'g');scan=load(ROOT/c.SCANNER_REL,'s');assert c.sha(ROOT/c.GUARD_REL)==c.GUARD_SHA256 and c.sha(ROOT/c.SCANNER_REL)==c.SCANNER_SHA256;g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:scan.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
jdks,jdkpin=c.configured_jdks(ROOT/c.DEFAULT_JDK_MANIFEST_REL,c.DEFAULT_JDK_MANIFEST_SHA256)
receipts=['jarde-tf3-original-final-root-v1-20261018','jarde-complete-array-final-root-v1-20261018','jarde-same-owner-final-root-v1-20261018','jarde-reverse-final-root-v1-20261018','jarde-direct-array-order-probe-root-v1-20261018','jarde-direct-array-control-baseline-root-v2-20261018','jarde-direct-char-string-final-root-v1-20261018'];rows=[];r={'status':'running','cli':c.pin(CLI),'jdk':jdkpin,'source_before':c.source_closure(ROOT),'prior_receipts':[],'commands':rows,'cells':[]};c.write_json(OUT/'execution.json',r)
def without_usage(v):
 if isinstance(v,dict):return {k:without_usage(x) for k,x in v.items() if k!='usage'}
 if isinstance(v,list):return [without_usage(x) for x in v]
 return v
def diffs(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  result=[]
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:result.append(path+'/'+k)
   else:result.extend(diffs(a[k],b[k],path+'/'+k))
  return result
 if isinstance(a,list) and isinstance(b,list):
  if len(a)!=len(b):return [path+'/length']
  return [p for i,(x,y) in enumerate(zip(a,b)) for p in diffs(x,y,path+'/'+str(i))]
 return [] if a==b else [path]
for name in receipts:
 prior_path=Path('/private/tmp')/name/'execution.json';prior=json.loads(prior_path.read_text());r['prior_receipts'].append(c.pin(prior_path));count=0
 for old in prior['commands']:
  argv=old['argv']
  if len(argv)<2 or argv[1]!='class-source':continue
  oldcli=Path(argv[0])
  if c.sha(oldcli)!='e01c6014bd1d1d220d72400beeb711791221aa2aa56e60eed0ba52f8714777c0':continue
  raw=c.command_artifact(old,'stdout');expected=json.loads(raw);inp=Path(argv[argv.index('--input')+1]);pin=c.pin(inp);env=c.clean_env(dict(os.environ),jdks['javac23']);env.update(g.ENV_VALUES);row=g.run_command(len(rows)+1,[str(CLI),*argv[1:]],env);rows.append(row);assert row['guard_stop'] is None and row['exit_code']==old['exit_code'];actualraw=c.command_artifact(row,'stdout');actual=json.loads(actualraw);cell={'prior':name,'prior_command':old['index'],'command':row['index'],'input':pin,'class_text_byte_identical':actual['text'].encode()==expected['text'].encode(),'non_usage_report_identical':without_usage(actual)==without_usage(expected),'all_observed_difference_paths':diffs(expected,actual)};r['cells'].append(cell);dest=OUT/'reports'/name/str(old['index']);dest.mkdir(parents=True);(dest/'report.json').write_bytes(actualraw);(dest/'source.java').write_text(actual['text']);c.write_json(OUT/'execution.json',r);assert c.pin(inp)==pin and cell['class_text_byte_identical'] and cell['non_usage_report_identical'],cell;count+=1
 assert count=={'jarde-tf3-original-final-root-v1-20261018':12,'jarde-complete-array-final-root-v1-20261018':4,'jarde-same-owner-final-root-v1-20261018':4,'jarde-reverse-final-root-v1-20261018':8,'jarde-direct-array-order-probe-root-v1-20261018':4,'jarde-direct-array-control-baseline-root-v2-20261018':4,'jarde-direct-char-string-final-root-v1-20261018':4}[name]
assert len(rows)==40;r['source_after']=c.source_closure(ROOT);assert r['source_before']==r['source_after'];r['target_absent']=not(ROOT/'target').exists();assert r['target_absent'];r['status']='complete pending root source-byte reuse acceptance';r['limits']='No JDK recompile/run in this replay. Every final generated source and entire non-usage report is byte/structurally identical to the separately accepted actual full-source compile/runtime evidence; measured work changes are retained.';c.write_json(OUT/'execution.json',r);print(r['status'],len(rows))
