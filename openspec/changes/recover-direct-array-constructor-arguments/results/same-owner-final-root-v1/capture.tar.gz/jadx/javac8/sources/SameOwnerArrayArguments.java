// default package

/* JADX INFO: loaded from: javac8.jar:SameOwnerArrayArguments.class */
public final class SameOwnerArrayArguments {
    public static int ctorCalls;
    public int value;
    public SameOwnerArrayArguments[] children;

    public SameOwnerArrayArguments(int i) {
        ctorCalls++;
        this.value = i;
    }

    public SameOwnerArrayArguments(SameOwnerArrayArguments[] sameOwnerArrayArgumentsArr) {
        ctorCalls++;
        this.children = sameOwnerArrayArgumentsArr;
    }

    public static SameOwnerArrayArguments build() {
        return new SameOwnerArrayArguments(new SameOwnerArrayArguments[]{new SameOwnerArrayArguments(1), new SameOwnerArrayArguments(2)});
    }
}
