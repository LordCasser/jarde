from pathlib import Path
import json,hashlib
out=Path('/private/tmp/jarde-same-owner-final-root-v1-20261018');d=json.loads((out/'execution.json').read_text());assert d['status']=='matrix collected pending root review' and d['target_absent'] and d['source_before']==d['source_after'];counts={};classes=[]
for row in d['commands']:
 assert row['guard_stop'] is None and row['exit_code']==0 and row['peak_target_bytes']<=1024**3 and row['free_bytes_after']>=5*1024**3
 for pin in row['streams'].values():
  b=Path(pin['path']).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256']
for cell in d['cells']:
 assert all(x['exit_code']==0 for x in cell['compiles']);runs=[r for x in cell['compiles'] for r in x['runs']];assert len(runs)==4 and all(x['matches_fixed_oracle'] and x['exit_code']==0 for x in runs);counts[cell['engine']]=counts.get(cell['engine'],0)+len(runs)
 if cell['engine']=='jarde':
  report=json.loads(Path(cell['source']['path']).with_name('report.json').read_text());assert len(report['methods'])==3 and all(m['outcome']['report']['quality']=='structured' and m['outcome']['report']['execution']['status']=='complete' for m in report['methods']);assert report['execution']['status']=='complete' and report['anonymous_interface_projection']['state']=='absent';classes.append({'profile':cell['profile'],'evidence':cell['evidence'],'execution':report['execution']['status']})
assert counts=={'jarde':16,'jadx':8}
r={'status':'root accepted complete same-owner source and runtime scope','commands':42,'raw_streams_reopened':84,'Jarde_compiles_runs_cases':[8,16,16],'JADX_compiles_runs_cases':[4,8,8],'root_site_identity_proof':'library pins outer0->30 leaf10->15 leaf21->26; exactly three constructors','class_scope_observations':classes,'limits':'This multi-site method does not trigger the separate unique-self-new anonymous projection issue; ReverseArrayOrder remains separate.'};(out/'root-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in r.items() if k!='class_scope_observations'})
