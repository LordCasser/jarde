import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

public final class SameOwnerArrayArgumentsDriver {
    private SameOwnerArrayArgumentsDriver() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            throw new IllegalArgumentException("expected target class directory");
        }
        File targetDirectory = new File(args[0]).getCanonicalFile();
        URL targetUrl = targetDirectory.toURI().toURL();

        // Use only bootstrap-visible classes as the parent so the target cannot be loaded from
        // the driver's application class path.
        try (URLClassLoader loader = new URLClassLoader(
                new URL[] {targetUrl}, ClassLoader.getSystemClassLoader().getParent())) {
            Class<?> target = Class.forName("SameOwnerArrayArguments", true, loader);
            URL actualCodeSource = target.getProtectionDomain().getCodeSource().getLocation();
            if (!targetUrl.toURI().normalize().equals(actualCodeSource.toURI().normalize())) {
                throw new AssertionError("target loaded from " + actualCodeSource + ", expected " + targetUrl);
            }

            Method build = target.getMethod("build");
            Object root = build.invoke(null);
            Field childrenField = target.getField("children");
            Object[] children = (Object[]) childrenField.get(root);
            if (children == null || children.length != 2) {
                throw new AssertionError("expected two children");
            }
            if (children[0] == children[1]) {
                throw new AssertionError("child instances must be distinct");
            }

            Field valueField = target.getField("value");
            Field callsField = target.getField("ctorCalls");
            int firstValue = valueField.getInt(children[0]);
            int secondValue = valueField.getInt(children[1]);
            boolean leavesHaveNoChildren = childrenField.get(children[0]) == null
                    && childrenField.get(children[1]) == null;
            int constructorCalls = callsField.getInt(null);
            if (firstValue != 1 || secondValue != 2 || !leavesHaveNoChildren || constructorCalls != 3) {
                throw new AssertionError("unexpected constructor result: values=" + firstValue + "/"
                        + secondValue + ", leavesNull=" + leavesHaveNoChildren
                        + ", ctorCalls=" + constructorCalls);
            }
            System.out.println("same-owner-array:len=2,values=1/2,distinct=true,leaves-null=true,ctorCalls=3");
        }
    }
}
