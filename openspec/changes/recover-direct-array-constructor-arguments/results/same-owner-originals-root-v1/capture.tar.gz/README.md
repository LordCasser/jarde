# Same-owner array constructor boundary fixture

`source/SameOwnerArrayArguments.java` is one complete Java class with overloads taking `int` and `SameOwnerArrayArguments[]`. `build()` constructs two same-owner leaf objects inside an array and passes that array to the outer overload. All three constructors increment the shared counter.

`driver/SameOwnerArrayArgumentsDriver.java` is intended to compile separately on Java 8. At runtime it accepts the target classes directory, loads the target through an isolated `URLClassLoader`, verifies the target class's `CodeSource` is exactly that directory, and checks array length, child values, child identity, null leaf arrays, and exactly three constructor calls. Its sole success line is fixed and contains no identity hashes.

The fixture and driver have not been compiled or run. This only tests the semantic boundary; it does not assert that recovery already succeeds for the untested same-owner shape.

```text
same-owner-array:len=2,values=1/2,distinct=true,leaves-null=true,ctorCalls=3
```
