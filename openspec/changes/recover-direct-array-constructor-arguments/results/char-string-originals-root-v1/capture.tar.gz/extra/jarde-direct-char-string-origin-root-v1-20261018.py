from pathlib import Path
import importlib.util,json,os,shutil,re
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');PREP=Path('/private/tmp/jarde-direct-char-string-complete-prep-root-v1-20261018');OUT=Path('/private/tmp/jarde-direct-char-string-inputs-root-v1-20261018');OUT.mkdir();(OUT/'raw').mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','cmp');g=load(ROOT/c.GUARD_REL,'guard');scan=load(ROOT/c.SCANNER_REL,'scan');assert c.sha(ROOT/c.GUARD_REL)==c.GUARD_SHA256 and c.sha(ROOT/c.SCANNER_REL)==c.SCANNER_SHA256;g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:scan.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
jdks,jdkpin=c.configured_jdks(ROOT/c.DEFAULT_JDK_MANIFEST_REL,c.DEFAULT_JDK_MANIFEST_SHA256)
files=[]
for name in ['DirectCharStringArguments.java','DirectCharStringArgumentsDriver.java','README.md']:
 src=PREP/name;dst=OUT/name;shutil.copyfile(src,dst);assert src.read_bytes()==dst.read_bytes();files.append(c.pin(dst))
expected=re.search(r'```text\n(.*?)\n```',(OUT/'README.md').read_text(),re.S).group(1).splitlines();assert len(expected)==7
rows=[];r={'status':'running','source':files,'jdk':jdkpin,'commands':rows,'profiles':[],'oracles':[]};c.write_json(OUT/'execution.json',r)
def cmd(argv,leg,label):
 env=c.clean_env(dict(os.environ),jdks[leg]);env.update(g.ENV_VALUES);env.pop('RUST_MIN_STACK',None);row=g.run_command(len(rows)+1,[str(x) for x in argv],env);row['label']=label;rows.append(row);c.write_json(OUT/'execution.json',r);assert row['exit_code']==0 and row['guard_stop'] is None;return row
for leg in ['javac8','javac23']:
 flags=['-source','8','-target','8'] if leg=='javac8' else ['--release','8'];d=OUT/leg/'classes';d.mkdir(parents=True);empty=OUT/leg/'empty';empty.mkdir()
 cmd([jdks[leg]['tools']['javac'],*flags,'-g:none','-proc:none','-encoding','UTF-8','-sourcepath',empty,'-classpath',empty,'-d',d,OUT/'DirectCharStringArguments.java'],leg,leg+'-source')
 r['profiles'].append({'compiler':leg,'classes':[c.pin(p) for p in sorted(d.rglob('*.class'))]});driver=OUT/leg/'driver';driver.mkdir()
 cmd([jdks[leg]['tools']['javac'],*flags,'-g:none','-proc:none','-encoding','UTF-8','-sourcepath',empty,'-classpath',empty,'-d',driver,OUT/'DirectCharStringArgumentsDriver.java'],leg,leg+'-driver')
 for runtime in ['javac8','javac23']:
  row=cmd([jdks[runtime]['tools']['java'],'-Xverify:all','-cp',driver,'DirectCharStringArgumentsDriver',d],runtime,leg+'-'+runtime+'-original');actual=c.command_artifact(row,'stdout').decode().splitlines();assert actual==expected and c.command_artifact(row,'stderr')==b'';r['oracles'].append({'compiler':leg,'runtime':runtime,'command':row['index'],'cases':7,'stdout':row['streams']['stdout']});c.write_json(OUT/'execution.json',r)
r['status']='original inputs and fixed 7-case oracle accepted';r['target_absent']=not(ROOT/'target').exists();assert r['target_absent'];c.write_json(OUT/'execution.json',r);print(r['status'])
