import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

public final class DirectCharStringArgumentsDriver {
    private static final String TARGET = "DirectCharStringArguments";

    private DirectCharStringArgumentsDriver() {}

    private static void require(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    private static Object call(Class<?> target, String name) throws Exception {
        Method method = target.getMethod(name);
        return method.invoke(null);
    }

    private static Field field(Class<?> target, String name) throws Exception {
        return target.getField(name);
    }

    private static String value(Object result, String expected) {
        String text = (String) result;
        require(expected.equals(text), "unexpected String value: " + text);
        return text;
    }

    private static void line(String value) {
        System.out.println(value);
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            throw new IllegalArgumentException("expected target class directory");
        }
        File targetDirectory = new File(args[0]).getCanonicalFile();
        URL targetUrl = targetDirectory.toURI().toURL();
        try (URLClassLoader loader = new URLClassLoader(
                new URL[] {targetUrl}, ClassLoader.getSystemClassLoader().getParent())) {
            Class<?> target = Class.forName(TARGET, true, loader);
            URL actualLocation = target.getProtectionDomain().getCodeSource().getLocation();
            require(targetUrl.toURI().normalize().equals(actualLocation.toURI().normalize()),
                    "target loaded from " + actualLocation + ", expected " + targetUrl);

            Field trace = field(target, "trace");
            Field failAt = field(target, "failAt");
            Field storedResult = field(target, "storedResult");
            Field storedSink = field(target, "storedSink");

            trace.setInt(null, 0);
            value(call(target, "constantString"), "ab");
            require(trace.getInt(null) == 0, "constant String unexpectedly changed trace");
            line("string-constant:value=ab,trace=0");

            failAt.setInt(null, 0);
            value(call(target, "effectfulString"), "ab");
            require(trace.getInt(null) == 12, "effectful String order was not 12");
            line("string-effectful:value=ab,trace=12");

            failAt.setInt(null, 0);
            trace.setInt(null, 0);
            Object returned = call(target, "storedString");
            value(returned, "cd");
            require(returned == storedResult.get(null), "stored String result lost object identity");
            require(trace.getInt(null) == 0, "stored String unexpectedly changed trace");
            line("string-stored:value=cd,identity=true");

            failAt.setInt(null, 0);
            value(call(target, "offsetString"), "bc");
            require(trace.getInt(null) == 123, "offset String element order was not 123");
            line("string-offset:value=bc,trace=123");

            failAt.setInt(null, 0);
            Object sink = call(target, "effectfulCharSink");
            require(sink == storedSink.get(null), "CharSink stored result lost object identity");
            require(sink.getClass().getClassLoader() == loader, "CharSink loader differs");
            require(targetUrl.toURI().normalize().equals(sink.getClass().getProtectionDomain()
                    .getCodeSource().getLocation().toURI().normalize()), "CharSink CodeSource differs");
            char[] chars = (char[]) sink.getClass().getField("value").get(sink);
            require(chars.length == 2 && chars[0] == 'a' && chars[1] == 'b',
                    "CharSink array contents differ");
            require(trace.getInt(null) == 12, "CharSink element order was not 12");
            line("char-sink:value=ab,trace=12,identity=true");

            failAt.setInt(null, 1);
            Throwable first = invokeFailure(target);
            require(first == field(target, "firstFailure").get(null), "first producer exception identity changed");
            require(trace.getInt(null) == 1, "later producer ran after first producer threw");
            line("string-throw-first:identity=true,trace=1");

            failAt.setInt(null, 2);
            Throwable second = invokeFailure(target);
            require(second == field(target, "secondFailure").get(null), "second producer exception identity changed");
            require(trace.getInt(null) == 12, "second producer failure trace changed");
            line("string-throw-second:identity=true,trace=12");
        }
    }

    private static Throwable invokeFailure(Class<?> target) throws Exception {
        try {
            call(target, "throwingString");
            throw new AssertionError("throwingString returned normally");
        } catch (InvocationTargetException wrapped) {
            return wrapped.getCause();
        }
    }
}
