# Direct char-array argument positive fixture

`source/DirectCharStringArguments.java` is a complete, self-contained class intended for recompilation as a whole. It contains no unrelated assertion path or `StringBuilder` caller. The only tested effects are the explicit `markChar` producers and result storage.

Compile the source into a dedicated target classes directory. Compile `driver/DirectCharStringArgumentsDriver.java` into a separate driver directory. Run the driver with only that driver directory on the process class path and pass the target classes directory as its single argument. The driver uses a Java 8 compatible `URLClassLoader` with the platform-parent boundary, then checks the target class's `ProtectionDomain` code source against the supplied directory. The nested `CharSink` is loaded from the same target directory.

The driver checks values, producer order, stored-result identity, the exact `char[]` contents and identity-bearing sink, and producer exception identity. Assertions execute in the driver only. The expected stdout is exactly:

```text
string-constant:value=ab,trace=0
string-effectful:value=ab,trace=12
string-stored:value=cd,identity=true
string-offset:value=bc,trace=123
char-sink:value=ab,trace=12,identity=true
string-throw-first:identity=true,trace=1
string-throw-second:identity=true,trace=12
```

The first throw case proves the second element producer did not run after the first threw. The second case proves the first producer ran before the second threw. No compiler or runtime has been invoked for this preparation.
