public final class DirectCharStringArguments {
    public static int trace;
    public static int failAt;
    public static final RuntimeException firstFailure = new RuntimeException("first-char-producer");
    public static final RuntimeException secondFailure = new RuntimeException("second-char-producer");
    public static String storedResult;
    public static CharSink storedSink;

    private DirectCharStringArguments() {}

    public static final class CharSink {
        public final char[] value;

        public CharSink(char[] value) {
            this.value = value;
        }
    }

    private static char markChar(int digit) {
        trace = trace * 10 + digit;
        if (failAt == 1 && digit == 1) {
            throw firstFailure;
        }
        if (failAt == 2 && digit == 2) {
            throw secondFailure;
        }
        return (char) ('a' + digit - 1);
    }

    public static String constantString() {
        return new String(new char[] {'a', 'b'});
    }

    public static String effectfulString() {
        trace = 0;
        return new String(new char[] {markChar(1), markChar(2)});
    }

    public static String storedString() {
        storedResult = new String(new char[] {'c', 'd'});
        return storedResult;
    }

    public static String offsetString() {
        trace = 0;
        return new String(new char[] {markChar(1), markChar(2), markChar(3)}, 1, 2);
    }

    public static CharSink effectfulCharSink() {
        trace = 0;
        storedSink = new CharSink(new char[] {markChar(1), markChar(2)});
        return storedSink;
    }

    public static String throwingString() {
        trace = 0;
        return new String(new char[] {markChar(1), markChar(2)});
    }
}
