package jadx.tests.integration.trycatch;

import jadx.NotYetImplemented;
import jadx.tests.api.SmaliTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug.jar:jadx/tests/integration/trycatch/TestFinally3.class */
public class TestFinally3 extends SmaliTest {

    /* JADX INFO: loaded from: no-debug.jar:jadx/tests/integration/trycatch/TestFinally3$TestCls.class */
    public static class TestCls {
        public byte[] bytes;

        public byte[] test() throws Exception {
            InputStream inputStream;
            InputStream inputStream2 = null;
            try {
                if (this.bytes == null) {
                    if (!validate()) {
                        return null;
                    }
                    inputStream = getInputStream();
                    this.bytes = read(inputStream);
                }
                inputStream2 = inputStream;
                return convert(this.bytes);
            } finally {
                close(inputStream);
            }
        }

        private byte[] convert(byte[] bArr) throws Exception {
            return new byte[0];
        }

        private boolean validate() throws Exception {
            return false;
        }

        private InputStream getInputStream() throws Exception {
            return new ByteArrayInputStream(new byte[0]);
        }

        private byte[] read(InputStream inputStream) throws Exception {
            return new byte[0];
        }

        private static void close(InputStream inputStream) {
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("} finally {").doesNotContain(new CharSequence[]{"close(null);"}).containsOne("close(inputStream);");
    }

    @NotYetImplemented("Finally extract failed")
    @Test
    public void test2NoDebug() {
        noDebugInfo();
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("} finally {").containsOne(indent() + "close(");
    }

    @Test
    public void testSmali() {
        JadxAssertions.assertThat(getClassNodeFromSmali()).code().doesNotContain(new CharSequence[]{"Type inference failed"}).containsOne("} finally {");
    }
}
