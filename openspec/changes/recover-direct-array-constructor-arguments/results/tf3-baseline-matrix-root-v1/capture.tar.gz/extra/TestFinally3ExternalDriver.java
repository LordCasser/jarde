import java.io.ByteArrayInputStream;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

/** Java 8 compatible, compile-time independent runtime oracle for TestFinally3$TestCls. */
public final class TestFinally3ExternalDriver {
    private static final String TARGET = "jadx.tests.integration.trycatch.TestFinally3$TestCls";

    private TestFinally3ExternalDriver() {
    }

    public static void main(String[] args) throws Exception {
        require(args.length == 1, "usage: TestFinally3ExternalDriver <target-class-directory>");
        File targetDir = new File(args[0]).getCanonicalFile();
        URL targetUrl = targetDir.toURI().toURL();
        // Keep the driver's class path out of the target's lookup path. Java 8 has no
        // platformClassLoader API, so the system loader's parent is the bootstrap side.
        try (URLClassLoader loader = new URLClassLoader(new URL[] { targetUrl },
                ClassLoader.getSystemClassLoader().getParent())) {
            Class<?> target = Class.forName(TARGET, true, loader);
            URL actualLocation = target.getProtectionDomain().getCodeSource().getLocation();
            require(new File(actualLocation.toURI()).getCanonicalFile().equals(targetDir),
                    "target class loaded from unexpected location: " + actualLocation);

            Constructor<?> ctor = target.getDeclaredConstructor();
            ctor.setAccessible(true);
            Field bytes = target.getDeclaredField("bytes");
            bytes.setAccessible(true);
            Method test = method(target, "test");
            Method convert = method(target, "convert", byte[].class);
            Method validate = method(target, "validate");
            Method getInputStream = method(target, "getInputStream");
            Method read = method(target, "read", java.io.InputStream.class);
            Method close = method(target, "close", java.io.InputStream.class);

            Object instance = ctor.newInstance();
            require(bytes.get(instance) == null, "case 1: bytes did not start null");
            require(invoke(test, instance) == null, "case 1: test() did not return null");
            require(bytes.get(instance) == null, "case 1: test() changed null bytes field");
            pass("case-1: constructor/null bytes/test returns null and preserves field");

            byte[] seeded = new byte[] { 1, 2 };
            bytes.set(instance, seeded);
            Object converted = invoke(test, instance);
            require(converted instanceof byte[] && ((byte[]) converted).length == 0,
                    "case 2: test() did not return an empty byte array");
            require(bytes.get(instance) == seeded, "case 2: test() replaced bytes field");
            require(seeded.length == 2 && seeded[0] == 1 && seeded[1] == 2,
                    "case 2: test() mutated bytes contents");
            pass("case-2: seeded test returns empty array and preserves field identity/content");

            byte[] convertArg = new byte[] { 3, 4 };
            Object convertedDirect = invoke(convert, instance, (Object) convertArg);
            require(convertedDirect instanceof byte[] && ((byte[]) convertedDirect).length == 0,
                    "case 3: convert(byte[]) did not return an empty array");
            require(convertArg.length == 2 && convertArg[0] == 3 && convertArg[1] == 4,
                    "case 3: convert(byte[]) mutated its argument");
            pass("case-3: convert returns empty array without changing its argument");

            require(Boolean.FALSE.equals(invoke(validate, instance)), "case 4: validate() was not false");
            pass("case-4: validate returns false");

            Object streamObject = invoke(getInputStream, instance);
            require(streamObject instanceof ByteArrayInputStream,
                    "case 5: getInputStream() did not return ByteArrayInputStream");
            require(((ByteArrayInputStream) streamObject).read() == -1,
                    "case 5: getInputStream() was not empty");
            pass("case-5: getInputStream returns empty ByteArrayInputStream");

            ByteArrayInputStream readArg = new ByteArrayInputStream(new byte[] { 79 });
            Object readResult = invoke(read, instance, (Object) readArg);
            require(readResult instanceof byte[] && ((byte[]) readResult).length == 0,
                    "case 6: read(InputStream) did not return an empty array");
            require(readArg.read() == 79, "case 6: read(InputStream) consumed the input");
            pass("case-6: read returns empty array and leaves input unconsumed");

            invoke(close, null, new Object[] { null });
            pass("case-7: close(null) returns normally");

            ByteArrayInputStream closeArg = new ByteArrayInputStream(new byte[] { 79 });
            invoke(close, null, new Object[] { closeArg });
            require(closeArg.read() == 79, "case 8: close(InputStream) consumed the input");
            pass("case-8: close(non-null stream) returns without consuming input");
        }
    }

    private static Method method(Class<?> type, String name, Class<?>... parameterTypes)
            throws NoSuchMethodException {
        Method result = type.getDeclaredMethod(name, parameterTypes);
        result.setAccessible(true);
        return result;
    }

    private static Object invoke(Method method, Object receiver, Object... args) throws Exception {
        try {
            return method.invoke(receiver, args);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof Exception) {
                throw (Exception) cause;
            }
            if (cause instanceof Error) {
                throw (Error) cause;
            }
            throw new AssertionError("unexpected throwable from " + method, cause);
        }
    }

    private static void require(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    private static void pass(String line) {
        System.out.println(line);
    }
}
