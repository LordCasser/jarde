// jarde: presentation of `DirectCharStringArguments` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class DirectCharStringArguments extends java.lang.Object {
    public static int trace;

    public static int failAt;

    public static final java.lang.RuntimeException firstFailure;

    public static final java.lang.RuntimeException secondFailure;

    public static java.lang.String storedResult;

    public static CharSink storedSink;

    private DirectCharStringArguments() {
        // @method <init>()V
        // @declaration a constructor of `DirectCharStringArguments`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    private static char markChar(int arg0) {
        // @method markChar(I)C
        // @declaration a static method of `DirectCharStringArguments`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        DirectCharStringArguments.trace = DirectCharStringArguments.trace * 10 + arg0;
        if (DirectCharStringArguments.failAt == 1) {
            if (arg0 == 1) {
                throw DirectCharStringArguments.firstFailure;
            }
        }
        if (DirectCharStringArguments.failAt == 2) {
            if (arg0 == 2) {
                throw DirectCharStringArguments.secondFailure;
            }
        }
        return (char) (97 + arg0 - 1);
    }

    public static java.lang.String constantString() {
        // @method constantString()Ljava/lang/String;
        // @declaration a static method of `DirectCharStringArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new java.lang.String(new char[]{'a', 'b'});
    }

    public static java.lang.String effectfulString() {
        // @method effectfulString()Ljava/lang/String;
        // @declaration a static method of `DirectCharStringArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        DirectCharStringArguments.trace = 0;
        return new java.lang.String(new char[]{markChar(1), markChar(2)});
    }

    public static java.lang.String storedString() {
        // @method storedString()Ljava/lang/String;
        // @declaration a static method of `DirectCharStringArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        DirectCharStringArguments.storedResult = new java.lang.String(new char[]{'c', 'd'});
        return DirectCharStringArguments.storedResult;
    }

    public static java.lang.String offsetString() {
        // @method offsetString()Ljava/lang/String;
        // @declaration a static method of `DirectCharStringArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        DirectCharStringArguments.trace = 0;
        return new java.lang.String(new char[]{markChar(1), markChar(2), markChar(3)}, 1, 2);
    }

    public static CharSink effectfulCharSink() {
        // @method effectfulCharSink()LDirectCharStringArguments$CharSink;
        // @declaration a static method of `DirectCharStringArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        DirectCharStringArguments.trace = 0;
        DirectCharStringArguments.storedSink = new CharSink(new char[]{markChar(1), markChar(2)});
        return DirectCharStringArguments.storedSink;
    }

    public static java.lang.String throwingString() {
        // @method throwingString()Ljava/lang/String;
        // @declaration a static method of `DirectCharStringArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        DirectCharStringArguments.trace = 0;
        return new java.lang.String(new char[]{markChar(1), markChar(2)});
    }

    static {
        // @method <clinit>()V
        // @declaration a static initializer of `DirectCharStringArguments`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        firstFailure = new java.lang.RuntimeException("first-char-producer");
        secondFailure = new java.lang.RuntimeException("second-char-producer");
    }

    public static final class CharSink extends java.lang.Object {
        public final char[] value;

        public CharSink(char[] arg1) {
            // @method <init>([C)V
            // @declaration a constructor of `DirectCharStringArguments$CharSink`, member flags 0x0001
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }
}
