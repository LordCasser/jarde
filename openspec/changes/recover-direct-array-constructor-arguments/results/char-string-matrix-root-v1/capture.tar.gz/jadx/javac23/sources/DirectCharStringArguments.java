// default package

/* JADX INFO: loaded from: javac23.jar:DirectCharStringArguments.class */
public final class DirectCharStringArguments {
    public static int trace;
    public static int failAt;
    public static final RuntimeException firstFailure = new RuntimeException("first-char-producer");
    public static final RuntimeException secondFailure = new RuntimeException("second-char-producer");
    public static String storedResult;
    public static CharSink storedSink;

    /* JADX INFO: loaded from: javac23.jar:DirectCharStringArguments$CharSink.class */
    public static final class CharSink {
        public final char[] value;

        public CharSink(char[] cArr) {
            this.value = cArr;
        }
    }

    private DirectCharStringArguments() {
    }

    private static char markChar(int i) {
        trace = (trace * 10) + i;
        if (failAt == 1 && i == 1) {
            throw firstFailure;
        }
        if (failAt == 2 && i == 2) {
            throw secondFailure;
        }
        return (char) ((97 + i) - 1);
    }

    public static String constantString() {
        return "ab";
    }

    public static String effectfulString() {
        trace = 0;
        return new String(new char[]{markChar(1), markChar(2)});
    }

    public static String storedString() {
        storedResult = "cd";
        return storedResult;
    }

    public static String offsetString() {
        trace = 0;
        return new String(new char[]{markChar(1), markChar(2), markChar(3)}, 1, 2);
    }

    public static CharSink effectfulCharSink() {
        trace = 0;
        storedSink = new CharSink(new char[]{markChar(1), markChar(2)});
        return storedSink;
    }

    public static String throwingString() {
        trace = 0;
        return new String(new char[]{markChar(1), markChar(2)});
    }
}
