# Seed 1 critical-gate review v2

Receipt: `/private/tmp/jarde-direct-array-workspace-seed1-root-v2-20261018/execution.json`.

This v2 review disambiguates the critical Rust test names by the Cargo target and checks each expected full test name against that target’s raw-`Running`-ordered summary mapping. The review covers eight gate categories and nine target-test rows because the pre-cancel test has the same Rust name in two distinct integration-test targets.

Source pin correction: the seed1 receipt records **4990** source pins and says they match current bytes. The **3,037** figure in the earlier v1 README belongs to a focused-source receipt; it was a memo typo here. The raw stream hash/length and metadata pins remain valid per the pinned v1 review JSON.

The workspace is the second full native run, according to the parent. Its present `target/` directory is expected from that run; this review does not treat it as a later P5 build. The stored `observed_counts` ordering difference is an existing runner/acceptor labeling limitation; attribution below follows raw `Running` records and does not classify the mismatch as a product defect.

| Gate | Cargo target | Full test name | Result |
|---|---|---|---|
| direct-array library positive | `jarde_java/lib` | `init::tests::direct_array_constructor_arguments_are_composed_for_both_javac_legs` | ok (1 match) |
| same-owner nested receiver selection | `jarde_java/lib` | `init::tests::same_owner_nested_constructors_select_the_matching_receiver` | ok (1 match) |
| verified stack swap ordering refusal | `jarde_java/lib` | `init::tests::verified_swap_does_not_reorder_effectful_direct_array_arguments` | ok (1 match) |
| public direct-array fixtures/evidence modes | `recover_direct_array_constructor_arguments/test` | `direct_array_arguments_generalize_across_both_javac_fixtures_and_evidence_modes` | ok (1 match) |
| public late-stop atomicity | `recover_direct_array_constructor_stops/test` | `public_late_analysis_stop_does_not_publish_a_partial_construction_body_or_map` | ok (1 match) |
| public pre-cancel atomicity (direct-array target) | `recover_direct_array_constructor_stops/test` | `public_precancel_reports_no_class_text_or_target_method` | ok (1 match) |
| public pre-cancel atomicity (exception-only target, same Rust test name) | `recover_exception_only_finally_stops/test` | `public_precancel_reports_no_class_text_or_target_method` | ok (1 match) |
| constructed reference-array element family | `p3_constructed_reference_array_elements/test` | `constructed_reference_array_elements_recover_as_one_complete_same_snapshot_family` | ok (1 match) |
| original TestFinally3 debug profile | `recover_original_test_finally3/test` | `original_test_finally3_debug_profiles_keep_all_methods_and_array_origins` | ok (1 match) |

The two `public_precancel_reports_no_class_text_or_target_method` rows are independently matched once each: `recover_direct_array_constructor_stops/test` and `recover_exception_only_finally_stops/test`. Both report `ok`; they are not merged by test-name substring or batch totals. `TestFinally3` is included as its own exact target/name row above.

Overall: **PASS** for the eight named gate categories. This is a read-only inspection of the existing closed seed1 receipt and review mapping; no compiler, CLI, Git, JDK, or network command was run.
