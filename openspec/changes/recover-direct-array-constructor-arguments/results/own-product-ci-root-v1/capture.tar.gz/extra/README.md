# Independent direct-array own-CI receipt review

Product `81b0684d579a09e16f328f2840bcd2400338219c`, run `39062097681`.

All 46 collection commands and 92 stdout/stderr artifacts match recorded lengths and SHA-256. The run completed successfully with 4 successful jobs and 52 successful steps. Captured sources and fixture classes match current bytes across 41 pins, including all 26 classes.

I reparsed the captured stable log for both fixed seeds. Each has 381 targets and 18 passing critical tests; each full target summary equals the accepted root-review row and the other seed. The parity report binds to the exact root-review byte count and SHA.

| Seed | Targets | Critical | Named tests | Passed | Failed | Ignored |
|---|---:|---:|---:|---:|---:|---:|
| 5350648285461741569 | 381 | 18 | 3805 | 3707 | 0 | 98 |
| 5350648285461741570 | 381 | 18 | 3805 | 3707 | 0 | 98 |

Overall: **PASS**.

All input byte counts and SHA-256 values are in `review.json`. Python `-B` read-only review; no GH, Git, Cargo, JDK, Jarde CLI, or network was used.
