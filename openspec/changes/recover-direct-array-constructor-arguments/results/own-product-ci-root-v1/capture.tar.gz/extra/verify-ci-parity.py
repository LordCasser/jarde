#!/usr/bin/env python3
"""Accept own-CI verifier output only when its two workspace seeds have identical target summaries."""
import hashlib, json, sys
from pathlib import Path
PRODUCT = "81b0684d579a09e16f328f2840bcd2400338219c"
SEEDS = ("5350648285461741569", "5350648285461741570")
CRITICAL = 18

def need(ok, message):
    if not ok: raise ValueError(message)

def main():
    if len(sys.argv) != 3:
        raise ValueError("usage: verify-ci-parity.py OWN_CI_VERIFIER.json NEW_ROOT_REVIEW.json")
    source, output = map(Path, sys.argv[1:])
    raw = source.read_bytes(); doc = json.loads(raw)
    need(not output.exists(), f"refusing to overwrite output: {output}")
    need(doc.get("status") == "accepted", "own-CI verifier status is not accepted")
    need(doc.get("product", {}).get("head_sha") == PRODUCT and doc.get("product", {}).get("expected_sha") == PRODUCT,
         "own-CI verifier is not bound to the exact product")
    ci = doc.get("ci", {})
    need(ci.get("job_count") == 4 and ci.get("expanded_api_step_count") == 52, "expected 4 CI jobs and 52 API steps")
    runs = doc.get("workspace_seed_runs")
    need(isinstance(runs, list) and len(runs) == 2, "expected exactly two workspace seed runs")
    need(tuple(str(r.get("seed")) for r in runs) == SEEDS, "workspace seed order does not match the fixed pair")
    summaries = [] ; totals = []
    for seed, run in zip(SEEDS, runs):
        critical = run.get("critical_tests_passed")
        need(isinstance(critical, dict) and len(critical) == CRITICAL, f"seed {seed}: expected 18 critical tests")
        rows = run.get("target_summaries")
        need(isinstance(rows, list) and rows, f"seed {seed}: target_summaries is missing")
        for row in rows:
            need(isinstance(row, dict) and all(k in row for k in ("target_header", "named_tests", "passed", "failed", "ignored", "measured", "filtered")),
                 f"seed {seed}: incomplete target summary row")
        total = {k:sum(r[k] for r in rows) for k in ("named_tests", "passed", "failed", "ignored", "measured", "filtered")}
        need(total["failed"] == 0, f"seed {seed}: failures in derived target totals")
        if "workspace_totals" in run:
            need(all(run["workspace_totals"].get(k) == total[k] for k in ("passed", "failed", "ignored", "measured", "filtered")),
                 f"seed {seed}: stored workspace totals disagree with target rows")
        summaries.append(rows); totals.append(total)
    need(summaries[0] == summaries[1], "the two seeds' complete target_summaries differ")
    report = {"status":"accepted", "product_sha":PRODUCT, "ci":{"job_count":4,"expanded_api_step_count":52},
              "input":{"path":str(source),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()},
              "seed_order":list(SEEDS),"target_summaries_equal":True,
              "workspace_seed_runs":[{"seed":seed,"target_count":len(summaries[i]),"critical_tests_passed":CRITICAL,"derived_totals":totals[i]} for i,seed in enumerate(SEEDS)]}
    payload=json.dumps(report,indent=2,sort_keys=True)+"\n"
    with output.open("x",encoding="utf-8") as f: f.write(payload)
    print(f"accepted: {len(summaries[0])} target summaries match across both seeds; review: {output}")
    return 0

if __name__ == "__main__":
    try: raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        raise SystemExit(f"CI parity review failed: {exc}")
