# Direct-array constructor proof: adversarial review

Read-only review of the current shared `crates/jarde-java/src/init.rs` and `crates/jarde-java/src/build.rs`, plus the checked-in direct-array fixtures/tests. No compiler, JDK, CLI, or Git command was run, and no shared file was changed. The requested prior memo at this directory was absent at review start; this report is the new artifact. Parent-reported test results are not treated as proof of these boundaries.

## Findings

### 1. Constructor argument evaluation order is not enforced in production

`verify_metered` builds `Site.arguments` by walking physical operands and checking only that each producer lies after the duplicated receiver and before the constructor (`init.rs:966-984`). There is no monotonicity check between adjacent producers. The positive fixture test checks increasing BCI order (`init.rs:3580-3586`), but this is an assertion about the known fixtures, not a production precondition.

This interacts with the new reader's prefix shortcut. For each physical operand before the array operand, `array_initializer_reader` accepts any Entry/Phi value or instruction definition that is available before the array's *last element store* (`build.rs:15555-15694`). It does not require the producer to precede the array allocation, or to precede earlier prefix operands. A legal bytecode ordering can therefore allocate/start initializing the array, evaluate a side-effecting earlier physical argument while retaining the array on stack, then finish the array and call the constructor. The current reader skips the prefix producer, and the outer constructor proof only checks that it occurred in the overall `new` span. Rendering the prefix expression before the array would move its side effect and array allocation relative to one another.

The suffix path has a related information-loss point: it merges all later operand sources into `dependencies` and `sibling_sources`, then checks only that their union equals the post-store interval (`build.rs:15696-15758`). It does not retain a source group per operand or prove that each operand's complete evaluation comes after the preceding operand. Sibling candidates carry a complete source set, but that set is also merged without a per-operand ordering comparison (`build.rs:14801-14837`, `15700-15724`).

**Minimal correction:** enforce strictly increasing physical-argument producer positions in `verify_metered` for the supported inline form, using the actual per-operand producer identity/position; reject values whose source expression cannot establish that order. In the reader, preserve one bounded source set per suffix operand and require its closed source interval to follow the previous operand's interval. For prefix operands, require each supported producer/dependency to finish before the array allocation (and in physical operand order), not merely before the last store. Keep the current exact interval, single-use, effect, and handler checks.

**Minimal controls:** add bytecode variants for (a) an earlier scalar argument effect after the array allocation but before its last element store, and (b) a later array argument whose dimension-producing call runs before an intervening scalar argument even though the array allocation itself follows it. Natural-order counterparts must remain accepted. The existing swapped-array test (`init.rs:3642-3663`) only swaps whole effectful array runs; it does not exercise a prefix scalar or an interleaved later dimension expression.

### 2. Handler-boundary coverage for prefix effects is provided by the enclosing construction proof

The reader directly compares handlers for all accounted suffix sources against the current array allocation (`build.rs:15760-15770`). It does not separately traverse prefix operand dependencies. However, when the array is admitted as an inline constructor argument, `verify_metered` sets `inline_arrays` and compares handler coverage for every instruction from the enclosing object allocation through its constructor, plus its consumer (`init.rs:1252-1294`). That range includes prefix effects. Thus I did not find a separate prefix-handler bypass for the complete direct-constructor path. Preserve this enclosing check when changing reader order logic; add one metamorphic boundary test with a prefix throw-capable call outside the array/object protected range to pin the contract.

### 3. Sibling source identity and uses are mostly closed; broaden negative controls

The sibling lookup requires an exact `candidate_values` mapping, matching `initializer.final_value`, and the same constructor consumer (`build.rs:14814-14825`). It excludes the consumer, requires every remaining source to be later than the current store, and rejects duplicate source BCIs (`14826-14837`). The reader requires a unique retained operand and checks physical operand multiplicity; sibling operands must also occur exactly once (`15598-15653`, `15706-15713`). The complete candidate proof checks its own sources/effects and uses before it becomes available to an earlier candidate (`14665-14703`, `15357-15387`). This is a sound basis for sibling reuse; I found no direct route for a second use of the sibling array value to pass these checks.

The committed tests pin two sibling array arguments and reject a swapped bytecode control, but do not directly pin duplicate sibling operand, a second consumer/escape, an unrelated gap between sibling sources, or a changed handler on a sibling source. Add small bytecode controls for those if they can be derived from the existing pair fixture. Do not turn the sibling helper into a general expression bypass.

### 4. Same-owner constructor selection is tied to receiver identity

The scan can encounter nested `<init>` calls on the same class (`init.rs:771-841`). It reads the constructor operands and selects a call only if its receiver is the exact allocated instance (`834-839`), then rechecks the selected receiver (`863-873`). The two-compiler test pins the outer and both nested same-owner sites (`init.rs:3604-3639`). This addresses the reported first-same-owner misselection. A useful additional negative is a bytecode variant with an earlier same-owner constructor on a different receiver and no matching receiver for the outer allocation; it should refuse rather than select by owner/name.

### 5. New reader work has unmetered collection/merge scans

The main scans for operands and prefix definitions poll/charge, as does `sibling_argument_sources` while walking candidate sources (`build.rs:14812-14830`, `15639-15694`). The new reader then has several scans with no explicit meter charge: inserting returned sibling sources (`15710-15713`), checking sibling/dependency overlap (`15744-15748`), constructing `accounted` from both sets (`15750-15754`), and collecting the entire instruction interval into a set (`15740-15743`). The final effect loop charges each accounted source, but that does not pay for the preceding interval scan and multiple set traversals.

**Minimal correction:** charge each instruction as the interval set is built. Avoid rescanning the same sets where possible; otherwise poll/charge each visited item in the sibling merge, overlap, and accounted construction. Keep the existing effect-loop charges. Add a budget stop test sized to fail specifically during the long suffix/interval scan and assert the reported stop dimension/BCI; current stop tests do not identify these individual loops.

## Test coverage gaps to keep visible

The full public-class test checks two javac artifacts, recovered text/source map parity, and a fallback control (`tests/recover_direct_array_constructor_arguments.rs:159-240`). It is valuable end-to-end evidence but does not prove the ordering and metering invariants above. A focused reader test should assert per-operand ordering on both the natural and metamorphic variants, while the public test should continue asserting full method recovery and origins. The current `arguments.windows(2)` assertion is useful evidence, but it should be paired with a production rejection test for a physically reversed/interleaved case.

## Follow-up reassessment

The suffix-source-order concern above is a test hypothesis, not an established implementation defect. The private probe packet at `/private/tmp/jarde-direct-array-order-probe-v1-20261018/` constructs valid bytecode that evaluates a later array dimension before an intervening scalar argument and uses `swap` to restore physical constructor operand order. The current source-interval equality should reject the inserted `swap`; root should run the actual site probe before considering a production ordering change. I found no stack-valid prefix-scalar interleaving that passes the array's contiguous allocation/element/store checks and closed-source/use checks. Treat both as unproven unless a real accepted variant shows otherwise.

I also withdraw the blanket recommendation to charge each set merge separately. Sibling sources are charged during candidate lookup and the accounted-effect pass; ordinary dependencies are charged during expression traversal and the accounted-effect pass; canonical method effects are charged before candidate analysis. The repeated set operations are therefore over already charged bounded facts. Add another charge only if the budget contract counts each CPU visit rather than unique IR facts.
