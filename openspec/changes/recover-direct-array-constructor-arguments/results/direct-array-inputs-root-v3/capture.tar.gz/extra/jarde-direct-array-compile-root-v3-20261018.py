from pathlib import Path
import importlib.util,json,os,shutil
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path('/private/tmp/jarde-direct-array-inputs-root-v3-20261018');OUT.mkdir();(OUT/'raw').mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','cmp');g=load(ROOT/c.GUARD_REL,'guard');scan=load(ROOT/c.SCANNER_REL,'scan');assert c.sha(ROOT/c.GUARD_REL)==c.GUARD_SHA256 and c.sha(ROOT/c.SCANNER_REL)==c.SCANNER_SHA256;g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:scan.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
jdks,jdkpin=c.configured_jdks(ROOT/c.DEFAULT_JDK_MANIFEST_REL,c.DEFAULT_JDK_MANIFEST_SHA256)
src=Path('/private/tmp/jarde-direct-array-constructor-arguments-prep-20261018/DirectArrayConstructorArguments.java');dst=OUT/src.name;shutil.copyfile(src,dst);assert src.read_bytes()==dst.read_bytes();rows=[];r={'status':'running','source':c.pin(src),'copy':c.pin(dst),'jdk':jdkpin,'commands':rows,'profiles':[]};c.write_json(OUT/'execution.json',r)
for leg in ['javac8','javac23']:
 d=OUT/leg/'classes';d.mkdir(parents=True);empty=OUT/leg/'empty';empty.mkdir();env=c.clean_env(dict(os.environ),jdks[leg]);env.update(g.ENV_VALUES);env.pop('RUST_MIN_STACK',None)
 flags=['-source','8','-target','8'] if leg=='javac8' else ['--release','8']
 row=g.run_command(len(rows)+1,[str(jdks[leg]['tools']['javac']),*flags,'-g:none','-proc:none','-encoding','UTF-8','-sourcepath',str(empty),'-classpath',str(empty),'-d',str(d),str(dst)],env);rows.append(row);c.write_json(OUT/'execution.json',r);assert row['exit_code']==0 and row['guard_stop'] is None
 r['profiles'].append({'compiler':leg,'classes':[c.pin(p) for p in sorted(d.rglob('*.class'))]})
r['status']='compiled pending proof review';r['target_absent']=not(ROOT/'target').exists();assert r['target_absent'];c.write_json(OUT/'execution.json',r);print(r['status'])
