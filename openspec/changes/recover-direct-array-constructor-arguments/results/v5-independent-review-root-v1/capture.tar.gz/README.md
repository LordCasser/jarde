# Independent read-only review of direct-array v5 final gates

The review record is in `review.json`. It was produced with Python `-B` by reading the existing receipt, raw streams, current source files, and replay script only. No build, CLI, JDK, Git, or network command was run.

The v5 receipt records 11 successful commands and 22 stdout/stderr streams; every raw stream byte count and SHA-256 matches its pin. The pinned runner, spec, guard, scanner, and candidate CLI files also match. The five test summaries reconcile to the observed Rust test outcome lines: 470 passed, 0 failed, 1 ignored, 0 measured, and 0 filtered. The library run is 461/0; the P5 corpus run is 5 passed plus 1 ignored; the three focused integration runs are 1, 1, and 2 passed. `source_before` equals `source_after`, the recorded 3,037 source pins still match current files, and the receipt records a successful final `cargo clean` with `target_absent: true`.

One current-state caveat: at review time the repository `target/` path exists, even though the receipt records it absent at completion. I did not inspect, remove, or modify it. Source pins remain consistent.

The 40-request replay script compares generated source text byte-for-byte and requires all report data outside `usage` to match recursively. Its `without_usage` helper removes every key named `usage` at every nesting depth, including per-method and child-family usage objects. `all_observed_difference_paths` records those differences but does not constrain them. This is broad on telemetry: arbitrary usage subfields may change or appear/disappear without failing the replay, although source text and all non-usage report content remain exact. A tighter check would preserve the usage object/key structure and report the known variable counters explicitly, while retaining equality checks for all other fields.

This is an independent evidence review, not final acceptance of the replay: the 40-request replay has not been run by this task.
