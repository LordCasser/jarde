#!/usr/bin/env python3
"""Read-only leaf acceptance for direct-array tests in two complete workspace receipts."""
from __future__ import annotations

import argparse
import importlib.util
import json
import re
import sys
from pathlib import Path

ROOT = Path("/Users/lordcasser/workspace/projects/jarde")
ACCEPTOR_PATH = ROOT / "openspec/changes/recover-branch-throw-return-finally/tools/workspace_acceptor.py"
OWN_CI_PATH = Path("/private/tmp/jarde-direct-array-own-ci-prep-20261018/verify-own-ci.py")

DIRECT_ARRAY_LABELS = (
    "direct-array library composition",
    "direct-array library receiver identity",
    "direct-array library effect order",
    "direct-array public class-source matrix",
    "direct-array public late stop",
    "direct-array public pre-cancel",
    "original TestFinally3 debug profiles",
    "constructed-array public composition dependency",
)

# These are Cargo target identities, not expected workspace target totals.
CRITICAL_TARGETS = {
    "direct-array library composition": ("jarde_java", "lib"),
    "direct-array library receiver identity": ("jarde_java", "lib"),
    "direct-array library effect order": ("jarde_java", "lib"),
    "direct-array public class-source matrix": ("recover_direct_array_constructor_arguments", "test"),
    "direct-array public late stop": ("recover_direct_array_constructor_stops", "test"),
    "direct-array public pre-cancel": ("recover_direct_array_constructor_stops", "test"),
    "original TestFinally3 debug profiles": ("recover_original_test_finally3", "test"),
    "constructed-array public composition dependency": ("p3_constructed_reference_array_elements", "test"),
}

ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
SUMMARY = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
    r"(\d+) measured; (\d+) filtered out(?:; finished in .*)?$"
)
RUNNING_TESTS = re.compile(r"^running (\d+) tests?$", re.IGNORECASE)


def test_groups(stdout_text: str, own_ci):
    """Return each target's named outcomes in Cargo stdout summary order."""
    lines = [line.strip() for line in stdout_text.splitlines()]
    groups = []
    i = 0
    while i < len(lines):
        running = RUNNING_TESTS.fullmatch(lines[i])
        if running is None:
            if lines[i].startswith("test result:"):
                raise ValueError(f"test summary has no matching running block: {lines[i]}")
            i += 1
            continue
        declared = int(running.group(1))
        outcomes = []
        j = i + 1
        while j < len(lines):
            summary = SUMMARY.fullmatch(lines[j])
            if summary is not None:
                passed, failed, ignored = map(int, summary.groups()[1:4])
                observed = (
                    sum(state == "ok" for _, state in outcomes),
                    sum(state == "FAILED" for _, state in outcomes),
                    sum(state == "ignored" for _, state in outcomes),
                )
                if declared != len(outcomes) or observed != (passed, failed, ignored):
                    raise ValueError(
                        f"named test outcomes do not reconstruct target summary: "
                        f"declared={declared}, named={len(outcomes)}, observed={observed}, "
                        f"summary={(passed, failed, ignored)}"
                    )
                groups.append(outcomes)
                i = j + 1
                break
            if RUNNING_TESTS.fullmatch(lines[j]):
                raise ValueError("Cargo began another target before summarizing the previous target")
            result = own_ci.OUTCOME.fullmatch(lines[j])
            if result is not None:
                raw_state = result.group(2)
                state = "ignored" if raw_state.startswith("ignored") else raw_state
                outcomes.append((result.group(1), state))
            elif lines[j].startswith("test result:") or lines[j].startswith("test "):
                raise ValueError(f"unparsed Cargo test output: {lines[j]}")
            j += 1
        else:
            raise ValueError("Cargo running-test block has no result summary")
    return groups


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"cannot load verifier module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def need(acceptor, condition: bool, message: str) -> None:
    acceptor.need(condition, message)


def read_seed(out: Path, expected_seed: str, acceptor, own_ci):
    out = out.resolve(strict=True)
    execution = json.loads((out / "execution.json").read_text(encoding="utf-8"))
    metadata = json.loads((out / "metadata.json").read_text(encoding="utf-8"))

    # Preserve the full, previously reviewed gate as the first check for each seed.
    accepted = acceptor.verify(execution, metadata, out, expected_seed)
    names = {label: own_ci.CRITICAL_TESTS[label] for label in DIRECT_ARRAY_LABELS}
    expected_labels = set(DIRECT_ARRAY_LABELS)
    need(acceptor, expected_labels <= set(own_ci.CRITICAL_TESTS), "direct-array critical labels are absent from own-CI inventory")
    need(acceptor, set(CRITICAL_TARGETS) == expected_labels, "direct-array target map does not cover the seven required leaves")

    target_counts: dict[tuple[str, str, str], tuple[int, ...]] = {}
    critical_seen = {label: [] for label in DIRECT_ARRAY_LABELS}
    for row in execution["commands"]:
        stdout = acceptor.verify_stream(out, row["streams"]["stdout"])
        stderr = acceptor.verify_stream(out, row["streams"]["stderr"])
        stdout_text = ANSI.sub("", stdout.decode("utf-8", errors="replace"))
        stderr_text = ANSI.sub("", stderr.decode("utf-8", errors="replace"))

        artifacts = acceptor.artifacts(stdout)
        by_executable = {str(Path(item["executable"]).resolve()): item for item in artifacts}
        summary_lines = [line for line in stdout_text.splitlines() if line.startswith("test result:")]
        summaries = [SUMMARY.fullmatch(line) for line in summary_lines]
        need(
            acceptor,
            all(match is not None for match in summaries)
            and all(
                match is not None
                and match.group(1) == "ok"
                and int(match.group(3)) == 0
                and int(match.group(5)) == 0
                and int(match.group(6)) == 0
                for match in summaries
            ),
            f"raw test summary is malformed or not fully passing in seed {expected_seed}, batch {row['index']}",
        )
        summaries = [match for match in summaries if match is not None]
        counts = [tuple(map(int, match.groups()[1:])) for match in summaries]
        running_paths = re.findall(r"^\s*Running[^\n]*\(([^()\n]+)\)\s*$", stderr_text, re.MULTILINE)
        executed = [str((acceptor.ROOT / path).resolve()) for path in running_paths]
        need(
            acceptor,
            len(counts) == len(executed) == len(artifacts)
            and len(set(executed)) == len(executed)
            and set(executed) == set(by_executable),
            f"raw summaries and actual Running order do not bind target identities in seed {expected_seed}, batch {row['index']}",
        )

        # The workspace runner executes targets in stderr Running order. Associate each raw
        # summary with that order, matching the reviewed workspace_acceptor contract.
        for executable, count in zip(executed, counts):
            item = by_executable[executable]
            identity = (item["package_id"], item["name"], item["kind"])
            need(acceptor, identity not in target_counts, f"duplicate target record in seed {expected_seed}: {identity}")
            target_counts[identity] = count

        groups = test_groups(stdout_text, own_ci)
        need(
            acceptor,
            len(groups) == len(executed) == len(counts),
            f"named Cargo test groups do not bind one-to-one to executed targets in seed {expected_seed}, batch {row['index']}",
        )
        for executable, group in zip(executed, groups):
            item = by_executable[executable]
            identity = (item["package_id"], item["name"], item["kind"])
            for label, name in names.items():
                for seen, state in group:
                    if seen.rsplit("::", 1)[-1] == name:
                        critical_seen[label].append((state, row["index"], identity))

    inventory = {tuple(row) for row in execution["target_inventory"]}
    need(acceptor, set(target_counts) == inventory, f"per-target count inventory differs in seed {expected_seed}")

    critical = {}
    for label, name in names.items():
        matches = critical_seen[label]
        need(
            acceptor,
            len(matches) == 1 and matches[0][0] == "ok",
            f"critical test missing, duplicated, or not ok in seed {expected_seed}: {label} ({name})",
        )
        target_name, target_kind = CRITICAL_TARGETS[label]
        matching_targets = [identity for identity in target_counts if identity[1:] == (target_name, target_kind)]
        need(
            acceptor,
            len(matching_targets) == 1,
            f"critical test target is absent or ambiguous in seed {expected_seed}: {label} -> {target_name}/{target_kind}",
        )
        need(
            acceptor,
            matches[0][2] == matching_targets[0],
            f"critical test outcome is not from its pinned target in seed {expected_seed}: {label}",
        )
        critical[label] = {
            "name": name,
            "outcome": "ok",
            "occurrences": 1,
            "target": list(matching_targets[0]),
            "command_index": matches[0][1],
        }

    return {
        "seed": expected_seed,
        "workspace_acceptor": accepted,
        "critical_tests": critical,
        "per_target_counts": {"|".join(key): list(value) for key, value in sorted(target_counts.items())},
        "_counts": target_counts,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed1-workspace", type=Path, required=True)
    parser.add_argument("--seed1-value", required=True)
    parser.add_argument("--seed2-workspace", type=Path, required=True)
    parser.add_argument("--seed2-value", required=True)
    args = parser.parse_args()

    acceptor = load_module("reviewed_workspace_acceptor", ACCEPTOR_PATH)
    own_ci = load_module("direct_array_own_ci", OWN_CI_PATH)
    need(
        acceptor,
        (args.seed1_value, args.seed2_value) == own_ci.SEEDS,
        f"workspace receipts must use the two distinct fixed seeds in workflow order: {own_ci.SEEDS}",
    )
    first = read_seed(args.seed1_workspace, args.seed1_value, acceptor, own_ci)
    second = read_seed(args.seed2_workspace, args.seed2_value, acceptor, own_ci)
    need(acceptor, first["_counts"] == second["_counts"], "per-target counts differ between the two workspace seeds")
    first.pop("_counts")
    second.pop("_counts")
    print(json.dumps({
        "status": "accepted_read_only",
        "critical_leaf_count_per_seed": len(DIRECT_ARRAY_LABELS),
        "per_target_counts_match": True,
        "seeds": [first, second],
    }, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
