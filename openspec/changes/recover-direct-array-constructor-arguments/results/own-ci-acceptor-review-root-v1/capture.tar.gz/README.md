# Own-CI and native leaf acceptor review

## Findings

The own-CI checker covers the requested 4 jobs / 52 expanded API steps. It reads the exact committed workflow bytes, checks the four job names and successful status, requires every expanded API step to complete successfully, checks workflow-declared steps against the CI API and raw non-stable logs, and asserts the total step count is 52. The collector requires the run head SHA to equal its runtime product SHA and copies the source paths and manifest-listed class bytes with `git show`; the checker verifies each captured source and fixture against its recorded product pin and the current checkout. The run ID is carried into collection and compared to the returned `databaseId` during acceptance.

The own-CI inventory contains 18 critical tests. Its workspace parser reconstructs each `running N tests` block from named outcomes and summary counts, associates outcome groups with target headers in order, rejects missing/duplicate critical outcomes, and checks each critical label against an explicit target string. The test names and target strings are disambiguated for the two late-stop and pre-cancel tests. One small strengthening is in the private patch: both collector and verifier now require `workflowName == "CI"`; the collector already requested this field but did not use it.

The original native leaf checker had a concrete attribution gap. It grouped every target executed by one Cargo command into `batch_targets`, then accepted a critical named outcome if the required target appeared anywhere in that command. If two tests with the same basename ran in different targets in that command, a result from the wrong target could borrow the correct target's presence. The private revision parses each stdout `running N tests` / named outcomes / summary block, binds that block to the corresponding stderr `Running` executable and compiler-artifact identity, and requires each critical occurrence's exact `(package_id, target name, kind)` to match its expected target. It also requires the two seed arguments to equal the two distinct fixed workflow seeds in order; the original checker only compared their resulting count maps, so identical or arbitrary seeds could be supplied twice.

The leaf checker otherwise obtains all workspace target identities from the reviewed workspace acceptor, binds summaries to raw `Running` executable paths, checks each target once, and compares the complete per-target count maps between seeds. The 7 direct-array leaf tests are a subset of the 18 own-CI tests; the own-CI checker remains the gate for the full 18.

## Private revisions

- [`accept_leaf_receipts.py`](/private/tmp/jarde-direct-array-own-ci-audit-20261018/accept_leaf_receipts.py) fixes per-test-to-target association and fixed-seed enforcement.
- [`accept_leaf_receipts.patch`](/private/tmp/jarde-direct-array-own-ci-audit-20261018/accept_leaf_receipts.patch) shows the complete private diff against the original leaf checker.
- [`collect-own-ci.py.patch`](/private/tmp/jarde-direct-array-own-ci-audit-20261018/collect-own-ci.py.patch) and [`verify-own-ci.py.patch`](/private/tmp/jarde-direct-array-own-ci-audit-20261018/verify-own-ci.py.patch) add the `CI` workflow-name guard.

Only Python AST parsing was used to check these drafts. No receipt was consumed and no GitHub, Git, Cargo, JDK, Jarde CLI, or network command was run. These are review drafts, not accepted evidence.

## Remaining receipt limitation

The own-CI acceptance verifies artifact lengths and hashes recorded in `collection.json`, but it does not independently reconstruct the collector's full command-to-file mapping from `argv` and require every raw stdout path to be the corresponding `run.json`, job log, or `product-source/...` file. The generated collector writes those mappings consistently, and the checker validates product bytes against the current checkout, but this is a receipt-integrity hardening opportunity if the acceptance boundary must also detect a manually rewritten collection manifest. The current revision leaves that wider receipt format unchanged.
