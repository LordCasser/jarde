
    #[test]
    fn temporary_root_tf3_actual_array_argument_probe() {
        for profile in ["debug", "no-debug"] {
            let path = format!("/private/tmp/jarde-tf3-original-inputs-root-v1-20261018/{profile}/classes/jadx/tests/integration/trycatch/TestFinally3$TestCls.class");
            let bytes = std::fs::read(path).expect("frozen exact source class");
            let (analysis, _) = analyzed_caller(&bytes, "getInputStream", "()Ljava/io/InputStream;");
            let ir = analysis.ir();
            let ssa = ir.ssa().expect("SSA");
            let code = ir.code().expect("Code");
            let operations = Operations::of(code, ir.constant_pool());
            let fields = field::Plan::empty();
            let chains = crate::concat::Plan::empty();
            let method = crate::facts::MethodFacts::new("getInputStream", "()Ljava/io/InputStream;", 0);
            let context = ArrayCompositionContext { chains: &chains, reserved: chains.owned(), java_release: 8, member_targets: &[], method: &method, code };
            let mut budget = proof_budget();
            let mut arrays = crate::build::ArrayInitializers::prove_with_composition(ssa, &operations, &fields, Some(&context), &mut budget).expect("array proof");
            println!("PROFILE={profile} CODE={code:?}");
            for block in ssa.blocks() {
                println!("BLOCK={:?}",block.block());
                for instruction in block.instructions() {
                    println!("INSTRUCTION={instruction:?} OP={:?}",operations.get(instruction.bci()));
                    for (_, value) in instruction.writes() { println!("VALUE={:?}",ssa.value(*value)); }
                }
                let ctor = block.instructions().iter().find(|i| i.bci()==7).expect("ctor7");
                println!("CTOR_OPERANDS={:?}",stack_operands(ctor));
                let mut meter = VerifyMeter::unmetered();
                let dependencies = value_dependency_bcis_metered(ssa, block.instructions(), stack_operands(ctor).iter().skip(1).map(|(_,v)|*v), &mut meter).expect("dependency");
                println!("ARGUMENT_DEPENDENCIES={dependencies:?} ARRAY_INITIALIZER_AT_5={}",arrays.has_candidate_at(5));
            }
            let sites = sites_after_array_composition(ssa, &operations, &chains, chains.owned(), &fields, &mut arrays, 8, &[], &method, code, &mut budget).expect("site census");
            println!("SITE_ACCEPTED={}", sites.site_at_head(0).is_some());
            for refusal in &sites.refusals { println!("FIRST_REFUSAL={:?}",refusal.refusal); }
            assert!(sites.site_at_head(0).is_none());
        }
    }
