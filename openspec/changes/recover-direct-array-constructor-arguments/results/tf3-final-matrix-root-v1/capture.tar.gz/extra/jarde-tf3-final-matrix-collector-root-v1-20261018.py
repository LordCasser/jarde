#!/usr/bin/env python3
"""Collect the TestFinally3 original/Jarde/JADX runtime baseline; preparation only."""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys

INPUTS = Path('/private/tmp/jarde-tf3-original-inputs-root-v1-20261018')
BASELINE = Path('/private/tmp/jarde-tf3-original-final-root-v1-20261018')
DRIVER = Path('/private/tmp/jarde-exception-only-tests-prep-20261017/testfinally3-reflection-driver/TestFinally3ExternalDriver.java')
ROOT_GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
ROOT_SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
ROOT_GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
ROOT_SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_MANIFEST = Path('/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json')
JDK_MANIFEST_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
SOURCE_PATH = Path('source/TestFinally3.java')
SOURCE_SHA = '0671606e6d7fee3aa1c8b8430758764eff60dfa00d4f0dc144006e0eb6808130'
TARGET_REL = Path('jadx/tests/integration/trycatch/TestFinally3$TestCls.class')
TARGET_NAME = 'jadx.tests.integration.trycatch.TestFinally3$TestCls'
MAIN = 'TestFinally3ExternalDriver'
JDKS = ('javac8', 'javac23')
RUNTIMES = ('javac8', 'javac23')
EVIDENCE = ('default', 'all')
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')
EXPECTED_LINES = [
    'case-1: constructor/null bytes/test returns null and preserves field',
    'case-2: seeded test returns empty array and preserves field identity/content',
    'case-3: convert returns empty array without changing its argument',
    'case-4: validate returns false',
    'case-5: getInputStream returns empty ByteArrayInputStream',
    'case-6: read returns empty array and leaves input unconsumed',
    'case-7: close(null) returns normally',
    'case-8: close(non-null stream) returns without consuming input',
]


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def save(path: Path, doc) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    tmp.replace(path)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot import guard helper: {path}')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def check_record(record: dict, label: str) -> Path:
    path = Path(record['path']).resolve(strict=True)
    actual = pin(path)
    if ('bytes' in record and actual['bytes'] != record['bytes']) or actual['sha256'] != record['sha256']:
        raise RuntimeError(f'{label} pin mismatch: {path}')
    return path


def validate_inputs(root: Path, inputs_receipt: dict, base_receipt: dict) -> dict:
    if inputs_receipt.get('target_absent') is not True or base_receipt.get('target_absent') is not True:
        raise RuntimeError('input/baseline receipt does not record repository target absent')
    source = check_record(inputs_receipt['source_copy'], 'copied original full source')
    if source.name != 'TestFinally3.java' or inputs_receipt['source']['sha256'] != SOURCE_SHA:
        raise RuntimeError('original full source name/hash differs from fixed pin')
    if inputs_receipt['source']['bytes'] != 1749 or inputs_receipt['source_copy']['sha256'] != SOURCE_SHA:
        raise RuntimeError('original source byte count/hash mismatch')
    if check_record(inputs_receipt['source'], 'original source') .read_bytes() != source.read_bytes():
        raise RuntimeError('copied original source is not byte-identical')
    if inputs_receipt['source_jadx_commit'] != '2fb1b16386941660fda07e9017285aec40fcb37f':
        raise RuntimeError('unexpected pinned JADX source revision')
    if base_receipt['input_receipt']['path'] != str(INPUTS / 'execution.json'):
        raise RuntimeError('baseline receipt points at a different input receipt')
    input_receipt_path = INPUTS / 'execution.json'
    input_pin = pin(input_receipt_path)
    if input_pin['bytes'] != base_receipt['input_receipt']['bytes'] or input_pin['sha256'] != base_receipt['input_receipt']['sha256']:
        raise RuntimeError('input receipt hash differs from baseline pin')
    if base_receipt['cli']['path'] != '/private/tmp/jarde-direct-array-focused-root-v3-20261018/candidate-cli' or \
            sha(check_record(base_receipt['cli'], 'candidate CLI')) != 'e01c6014bd1d1d220d72400beeb711791221aa2aa56e60eed0ba52f8714777c0':
        raise RuntimeError('candidate CLI path/hash differs from prior receipt')
    if sha(check_record(base_receipt['jadx'], 'JADX executable')) != '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7':
        raise RuntimeError('JADX executable pin mismatch')
    if sha(check_record(base_receipt['jadx_jar'], 'JADX jar')) != '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65':
        raise RuntimeError('JADX jar pin mismatch')
    manifest = check_record(inputs_receipt['jdk_manifest'], 'JDK manifest')
    if manifest != JDK_MANIFEST or sha(manifest) != JDK_MANIFEST_SHA:
        raise RuntimeError('JDK manifest path/hash differs from the root-pinned manifest')
    # Preserve the original harness classpath exactly, and validate every captured jar/class pin.
    classpath = [Path(p).resolve(strict=True) for p in inputs_receipt['classpath']]
    for item in inputs_receipt['jar_pins']:
        check_record(item, 'original classpath jar')
    check_record(inputs_receipt['harness_jar'], 'original test harness jar')
    for directory, entries in inputs_receipt['directory_pins'].items():
        for entry in entries.values():
            check_record(entry, f'original harness directory {directory}')
    if str(inputs_receipt['harness_jar']['path']) != str(classpath[0]):
        raise RuntimeError('original harness jar is not first on recorded classpath')
    resource_records = [inputs_receipt['source'], inputs_receipt['source_copy'],
                        inputs_receipt['harness_jar'], *inputs_receipt['jar_pins'],
                        inputs_receipt['jdk_manifest']]
    for entries in inputs_receipt['directory_pins'].values():
        resource_records.extend(entries.values())
    return {'source': pin(source), 'input_receipt': input_pin,
            'classpath': [str(p) for p in classpath], 'classpath_pins': inputs_receipt['jar_pins'],
            'resource_records': resource_records, 'harness_jar': inputs_receipt['harness_jar'],
            'directory_pins_count': sum(len(rows) for rows in inputs_receipt['directory_pins'].values())}


def configured_jdks(manifest_path: Path) -> tuple[dict, dict]:
    if sha(manifest_path) != JDK_MANIFEST_SHA:
        raise RuntimeError('JDK manifest pin mismatch')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    out, pins = {}, {}
    for leg in JDKS:
        row = next(x for x in manifest['legs'] if x['leg'] == leg)
        tools = {}
        for name in ('java', 'javac', 'javap'):
            rec = row['jdk_tools'][name]
            path = Path(rec['path']).resolve(strict=True)
            if sha(path) != rec['sha256']:
                raise RuntimeError(f'{leg}/{name} differs from JDK manifest')
            tools[name] = path
        home = tools['java'].parent.parent
        if any(p.parent != home / 'bin' for p in tools.values()):
            raise RuntimeError(f'{leg} tools do not share JAVA_HOME/bin')
        out[leg] = {'home': home, 'tools': tools}
        pins[leg] = {name: pin(path) for name, path in tools.items()}
    return out, pins


def clean_env(base: dict, jdk: dict | None = None) -> dict:
    env = {k: v for k, v in base.items() if k not in ENV_STRIP}
    if jdk:
        env['JAVA_HOME'] = str(jdk['home'])
        env['PATH'] = str(jdk['home'] / 'bin') + os.pathsep + env.get('PATH', '')
    return env


def source_classes(inputs: dict) -> dict[str, tuple[Path, Path]]:
    by_profile = {}
    for profile_row in inputs.get('profiles', []):
        profile = profile_row['profile']
        root = INPUTS / profile / 'classes'
        target = root / TARGET_REL
        outer = root / TARGET_REL.parent / 'TestFinally3.class'
        if not target.is_file() or not outer.is_file():
            raise RuntimeError(f'missing frozen original {profile} target/outer class')
        for record, actual in ((profile_row['target_facts'], target), (profile_row['outer_facts'], outer)):
            if pin(actual)['bytes'] != record['bytes'] or sha(actual) != record['sha256']:
                raise RuntimeError(f'{profile}: original class differs from input receipt: {actual}')
        by_profile[profile] = (target, outer)
    if set(by_profile) != {'debug', 'no-debug'}:
        raise RuntimeError('input receipt does not contain both original compiler profiles')
    return by_profile


def copy_original_target(source_class: Path, outer_class: Path, out_dir: Path) -> Path:
    if out_dir.exists():
        raise RuntimeError(f'refusing existing target output {out_dir}')
    target = out_dir / TARGET_REL
    target.parent.mkdir(parents=True)
    shutil.copyfile(source_class, target)
    shutil.copyfile(outer_class, target.parent / 'TestFinally3.class')
    return target


def exact_oracle(data: bytes, label: str) -> None:
    lines = data.decode('utf-8', errors='strict').splitlines()
    if lines != EXPECTED_LINES:
        raise RuntimeError(f'{label}: expected fixed eight-line oracle; got {lines!r}')


def copy_verbatim(src: Path, dst: Path, label: str) -> Path:
    if dst.exists():
        raise RuntimeError(f'refusing to overwrite source copy: {dst}')
    dst.parent.mkdir(parents=True, exist_ok=True)
    raw = src.read_bytes()
    dst.write_bytes(raw)
    if dst.read_bytes() != raw:
        raise RuntimeError(f'{label}: source copy changed bytes')
    return dst


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, default=Path('/Users/lordcasser/workspace/projects/jarde'))
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--inputs-receipt', type=Path, default=INPUTS / 'execution.json')
    ap.add_argument('--baseline-receipt', type=Path, default=BASELINE / 'execution.json')
    args = ap.parse_args()
    root = args.root.resolve(strict=True)
    out = args.out.resolve()
    if out.exists(): raise SystemExit(f'refusing existing output directory: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('repository target must be absent before the run')
    inputs_receipt_path = args.inputs_receipt.resolve(strict=True)
    baseline_receipt_path = args.baseline_receipt.resolve(strict=True)
    inputs = json.loads(inputs_receipt_path.read_text(encoding='utf-8'))
    baseline = json.loads(baseline_receipt_path.read_text(encoding='utf-8'))
    validated = validate_inputs(root, inputs, baseline)
    guard_path = root / ROOT_GUARD_REL
    scanner_path = root / ROOT_SCANNER_REL
    if sha(guard_path) != ROOT_GUARD_SHA or sha(scanner_path) != ROOT_SCANNER_SHA:
        raise SystemExit('root command guard/scanner source hash mismatch')
    jdks, jdk_pins = configured_jdks(JDK_MANIFEST)
    driver = DRIVER.resolve(strict=True)
    if driver.name != 'TestFinally3ExternalDriver.java':
        raise SystemExit('driver must retain its Java filename')
    extra_paths = [inputs_receipt_path, baseline_receipt_path, Path(inputs['source_copy']['path']),
        driver, guard_path, scanner_path, JDK_MANIFEST, Path(baseline['cli']['path']),
        Path(baseline['jadx']['path']), Path(baseline['jadx_jar']['path'])]
    for profile_row in inputs.get('profiles', []):
        extra_paths.extend([Path(profile_row['target_facts']['path']), Path(profile_row['outer_facts']['path'])])
    for leg_tools in jdk_pins.values():
        extra_paths.extend(Path(record['path']) for record in leg_tools.values())
    for row in baseline.get('jarde_cells', []):
        extra_paths.append(Path(row['source']['path']))
    for row in baseline.get('jadx_cells', []):
        extra_paths.extend(Path(item['path']) for item in row.get('sources', []))
    source_pins_before = {str(p.resolve(strict=True)): pin(p) for p in extra_paths}
    resource_pins_before = {rec['path']: check_record(rec, 'pinned input/runtime resource')
                            for rec in validated['resource_records']}
    guard = load_module(guard_path, 'tf3_baseline_guard')
    scanner = load_module(scanner_path, 'tf3_baseline_scanner')
    out.mkdir(parents=True)
    raw_dir = out / 'raw'; raw_dir.mkdir()
    guard.ROOT = root; guard.OUT = raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = lambda p: pin(p)
    guard.expected_test_summaries = lambda index, stdout_bytes: None
    base_env = clean_env(dict(os.environ))
    base_env.pop('RUST_MIN_STACK', None)
    base_env.update(guard.ENV_VALUES)
    cp = validated['classpath']
    cmds = []
    result = {'schema': 'tf3-original-baseline-v1', 'status': 'running', 'root': str(root),
        'output': str(out), 'inputs_receipt': pin(inputs_receipt_path), 'baseline_receipt': pin(baseline_receipt_path),
        'original_source': validated['source'], 'source_profile_sha256': SOURCE_SHA,
        'original_harness_classpath': cp, 'original_harness_pin': validated['harness_jar'],
        'original_harness_directory_pin_count': validated['directory_pins_count'],
        'driver': pin(driver), 'candidate_cli': pin(Path(baseline['cli']['path'])),
        'jadx': pin(Path(baseline['jadx']['path'])), 'jadx_jar': pin(Path(baseline['jadx_jar']['path'])),
        'root_guard': pin(guard_path), 'root_scanner': pin(scanner_path), 'jdk_tools': jdk_pins,
        'source_pins_before': source_pins_before, 'resource_pins_before':
            {str(p): pin(p) for p in resource_pins_before.values()}, 'commands': cmds,
        'original_oracles': [], 'jarde_cells': [], 'jadx_cells': [],
        'notes': ['Prepared collector: not executed during authoring.',
          'Commands are serialized through the pinned root guard, whose target/free-space monitor polls once per second.',
          'Every stdout/stderr byte stream is retained under raw/ and pinned in command receipts.',
          'Java source artifacts are copied byte-for-byte to a filename matching their public top-level class; no source edits are made.',
          'Failed generated-source compiles preserve diagnostics and produce no runtime row.',
          'Driver runs use only the separate driver output directory on the Java class path; target classes load in an isolated URLClassLoader from the explicit target root.']}
    save(out / 'execution.json', result)

    def command(label: str, argv: list[str], leg: str | None = None, phase: str = '') -> dict:
        env = clean_env(base_env, jdks[leg] if leg else None)
        row = guard.run_command(len(cmds) + 1, argv, env)
        row.update({'label': label, 'phase': phase})
        cmds.append(row); save(out / 'execution.json', result)
        if row.get('guard_stop') is not None:
            raise RuntimeError(f'root guard stopped {label}: {row["guard_stop"]}')
        return row

    def stdout(row: dict) -> bytes:
        rec = row['streams']['stdout']; p = Path(rec['path']); b = p.read_bytes()
        if len(b) != rec['bytes'] or sha(p) != rec['sha256']:
            raise RuntimeError(f'raw stdout hash mismatch: {row["index"]}')
        return b

    def stderr(row: dict) -> bytes:
        rec = row['streams']['stderr']; p = Path(rec['path']); b = p.read_bytes()
        if len(b) != rec['bytes'] or sha(p) != rec['sha256']:
            raise RuntimeError(f'raw stderr hash mismatch: {row["index"]}')
        return b

    def fresh(path: Path) -> None:
        if path.exists(): raise RuntimeError(f'refusing existing build output: {path}')
        path.mkdir(parents=True)

    def javac(src: Path, leg: str, outdir: Path, classpath: list[str], label: str) -> dict:
        fresh(outdir)
        empty = outdir.parent / (outdir.name + '-empty-sourcepath'); fresh(empty)
        flags = (['-source', '8', '-target', '8', '-g:none', '-Xlint:-options', '-proc:none']
                 if leg == 'javac8' else ['--release', '8', '-g:none', '-proc:none'])
        cpvalue = os.pathsep.join(classpath) if classpath else ''
        argv = [str(jdks[leg]['tools']['javac']), *flags, '-classpath', cpvalue,
                '-sourcepath', str(empty), '-d', str(outdir), str(src)]
        return command(label, argv, leg, 'javac')

    def compile_driver(leg: str, target_label: str, target_root: Path) -> tuple[dict, Path]:
        driver_dir = out / 'driver-classes' / target_label / leg
        driver_dir.parent.mkdir(parents=True, exist_ok=True)
        row = javac(driver, leg, driver_dir, [], f'{target_label}-{leg}-driver-javac')
        driver_class = driver_dir / (MAIN + '.class')
        return row, driver_class

    def run_driver(label: str, driver_class: Path, target_root: Path, runtime: str) -> tuple[dict, bool]:
        driver_dir = driver_class.parent
        row = command(label, [str(jdks[runtime]['tools']['java']), '-Xverify:all', '-cp', str(driver_dir),
                              MAIN, str(target_root)], runtime, 'runtime-8-cases')
        valid = False
        if row['exit_code'] == 0:
            exact_oracle(stdout(row), label); valid = True
        return row, valid

    try:
        original_classes = source_classes(inputs)
        # Frozen original inputs: 2 source profiles x 2 driver compilers x 2 JVM runtimes = 8 oracle runs.
        for profile, (source_class, outer_class) in original_classes.items():
            target_root = out / 'original' / profile / 'target-root'
            target_copy = copy_original_target(source_class, outer_class, target_root)
            input_record = {'profile': profile, 'input_class': pin(source_class),
                            'input_outer_class': pin(outer_class), 'isolated_target_class': pin(target_copy),
                            'isolated_outer_class': pin(target_copy.parent / 'TestFinally3.class'), 'runs': []}
            for driver_leg in JDKS:
                driver_compile, driver_class = compile_driver(driver_leg, f'original-{profile}', target_root)
                driver_result = {'compiler': driver_leg, 'compile_command': driver_compile['index'],
                                 'compile_exit_code': driver_compile['exit_code'],
                                 'driver_class': pin(driver_class) if driver_class.is_file() else None, 'runs': []}
                if driver_compile['exit_code'] == 0 and driver_class.is_file():
                    for runtime in RUNTIMES:
                        run, valid = run_driver(f'original-{profile}-driver-{driver_leg}-runtime-{runtime}',
                                                driver_class, target_root, runtime)
                        driver_result['runs'].append({'runtime': runtime, 'command': run['index'],
                                                      'exit_code': run['exit_code'], 'eight_cases_valid': valid,
                                                      'stdout_sha256': run['streams']['stdout']['sha256'],
                                                      'stderr_sha256': run['streams']['stderr']['sha256']})
                else:
                    stderr(driver_compile)
                input_record['runs'].append(driver_result)
            result['original_oracles'].append(input_record); save(out / 'execution.json', result)
        oracle = {}
        for profile, item in zip(original_classes, result['original_oracles']):
            oracle[profile] = {}
            for driver_row in item['runs']:
                for run in driver_row['runs']:
                    raw = stdout(cmds[run['command'] - 1])
                    oracle[profile][run['runtime']] = raw
            if len(oracle[profile]) != 2:
                raise RuntimeError(f'{profile}: did not collect both Java runtime oracle streams')
        # Jarde: child and bundle-child have 8 total profile/form/evidence cells, each javac 8/23.
        for cell in baseline['jarde_cells']:
            profile, form, evidence = cell['profile'], cell['form'], cell['evidence']
            source_rec = cell['source']
            if form not in ('child', 'bundle-child', 'bundle-owner'):
                continue
            source_orig = check_record(source_rec, f'prior Jarde {profile}/{form}/{evidence} source')
            suffix = 'TestFinally3.java' if form == 'bundle-owner' else 'TestFinally3$TestCls.java'
            source_copy = copy_verbatim(source_orig, out / 'jarde-sources' / profile / form / evidence / suffix,
                                        f'Jarde {profile}/{form}/{evidence}')
            compilers = ('javac23',) if form == 'bundle-owner' else JDKS
            cell_record = {'profile': profile, 'form': form, 'evidence': evidence,
                           'prior_source': pin(source_orig), 'compiled_source': pin(source_copy),
                           'source_copy_byte_identical': True, 'compiles': []}
            for leg in compilers:
                class_dir = out / 'jarde-classes' / profile / form / evidence / leg
                compile_cp = cp if form == 'bundle-owner' else []
                row = javac(source_copy, leg, class_dir, compile_cp,
                            f'jarde-{profile}-{form}-{evidence}-{leg}-source-javac')
                nested = class_dir / TARGET_REL
                item = {'compiler': leg, 'compile_command': row['index'], 'exit_code': row['exit_code'],
                        'stderr_sha256': row['streams']['stderr']['sha256'],
                        'target_class': pin(nested) if nested.is_file() else None, 'runtime_runs': []}
                if row['exit_code'] == 0 and nested.is_file():
                    driver_compile, driver_class = compile_driver(leg, f'jarde-{profile}-{form}-{evidence}-{leg}', class_dir)
                    item['driver_compile_command'] = driver_compile['index']
                    item['driver_class'] = pin(driver_class) if driver_class.is_file() else None
                    if driver_compile['exit_code'] == 0 and driver_class.is_file():
                        for runtime in RUNTIMES:
                            run, valid = run_driver(f'jarde-{profile}-{form}-{evidence}-{leg}-{runtime}',
                                                    driver_class, class_dir, runtime)
                            item['runtime_runs'].append({'runtime': runtime, 'command': run['index'],
                                'exit_code': run['exit_code'], 'eight_cases_valid': valid,
                                'matches_original_profile_oracle': valid and stdout(run) == oracle[profile][runtime],
                                'stdout_sha256': run['streams']['stdout']['sha256'],
                                'stderr_sha256': run['streams']['stderr']['sha256']})
                else:
                    stderr(row)  # Retain and validate diagnostic stream; no target/driver runtime is fabricated.
                cell_record['compiles'].append(item)
            result['jarde_cells'].append(cell_record); save(out / 'execution.json', result)
        expected_jarde = {'child': 4, 'bundle-child': 4, 'bundle-owner': 4}
        counts = {form: sum(1 for c in result['jarde_cells'] if c['form'] == form) for form in expected_jarde}
        if counts != expected_jarde:
            raise RuntimeError(f'expected 8 child/bundle-child and 4 owner source cells, got {counts}')
        # JADX: standalone child has 2 profile cells x both javacs; full bundle has 2 cells x javac23 only.
        jadx_by = {(c['profile'], c['form']): c for c in baseline['jadx_cells']}
        if len(jadx_by) != 4:
            raise RuntimeError(f'expected four prior JADX source cells, found {len(jadx_by)}')
        for (profile, form), prior in sorted(jadx_by.items()):
            source_orig = check_record(prior['sources'][0], f'prior JADX {profile}/{form} source')
            suffix = 'TestFinally3.java' if form == 'bundle' else 'TestFinally3$TestCls.java'
            source_copy = copy_verbatim(source_orig, out / 'jadx-sources' / profile / form / suffix,
                                        f'JADX {profile}/{form}')
            compilers = JDKS if form == 'child' else ('javac23',)
            cell_record = {'profile': profile, 'form': form, 'prior_source': pin(source_orig),
                           'compiled_source': pin(source_copy), 'source_copy_byte_identical': True,
                           'compiles': []}
            for leg in compilers:
                class_dir = out / 'jadx-classes' / profile / form / leg
                row = javac(source_copy, leg, class_dir, cp if form == 'bundle' else [],
                            f'jadx-{profile}-{form}-{leg}-source-javac')
                nested = class_dir / TARGET_REL
                item = {'compiler': leg, 'compile_command': row['index'], 'exit_code': row['exit_code'],
                        'stderr_sha256': row['streams']['stderr']['sha256'],
                        'target_class': pin(nested) if nested.is_file() else None, 'runtime_runs': []}
                if row['exit_code'] == 0 and nested.is_file():
                    driver_compile, driver_class = compile_driver(leg, f'jadx-{profile}-{form}-{leg}', class_dir)
                    item['driver_compile_command'] = driver_compile['index']
                    item['driver_class'] = pin(driver_class) if driver_class.is_file() else None
                    if driver_compile['exit_code'] == 0 and driver_class.is_file():
                        for runtime in RUNTIMES:
                            run, valid = run_driver(f'jadx-{profile}-{form}-{leg}-{runtime}', driver_class,
                                                    class_dir, runtime)
                            item['runtime_runs'].append({'runtime': runtime, 'command': run['index'],
                                'exit_code': run['exit_code'], 'eight_cases_valid': valid,
                                'matches_original_profile_oracle': valid and stdout(run) == oracle[profile][runtime],
                                'stdout_sha256': run['streams']['stdout']['sha256'],
                                'stderr_sha256': run['streams']['stderr']['sha256']})
                else:
                    stderr(row)
                cell_record['compiles'].append(item)
            result['jadx_cells'].append(cell_record); save(out / 'execution.json', result)
        result['source_pins_after'] = {str(p): pin(Path(p)) for p in source_pins_before}
        result['source_pins_unchanged'] = result['source_pins_after'] == source_pins_before
        result['resource_pins_after'] = {str(p): pin(p) for p in resource_pins_before.values()}
        result['resource_pins_unchanged'] = result['resource_pins_after'] == result['resource_pins_before']
        result['repository_target_absent_after'] = not (root / 'target').exists()
        result['commands_count'] = len(cmds)
        result['expected_cell_counts'] = {'original_oracle_profiles': 2, 'original_driver_compilers_per_profile': 2,
            'original_runtime_runs_per_driver': 2, 'jarde_child_and_bundle_child': 8, 'jarde_bundle_owner': 4,
            'jadx_standalone': 2, 'jadx_bundle': 2}
        if (not result['source_pins_unchanged'] or not result['resource_pins_unchanged']
                or not result['repository_target_absent_after']):
            raise RuntimeError('source/resource pin changed or repository target appeared')
        result['status'] = 'complete_pending_independent_review'
        result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(out / 'execution.json', result)
        return 0
    except Exception as exc:
        result['status'] = 'interrupted'
        result['failure'] = f'{type(exc).__name__}: {exc}'
        result['commands_count'] = len(cmds)
        result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(out / 'execution.json', result)
        raise


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        raise SystemExit(f'TF3 baseline collection failed: {type(exc).__name__}: {exc}')
