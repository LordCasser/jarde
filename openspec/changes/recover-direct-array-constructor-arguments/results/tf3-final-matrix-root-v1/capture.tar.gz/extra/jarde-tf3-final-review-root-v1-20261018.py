import json,pathlib,hashlib
out=pathlib.Path('/private/tmp/jarde-tf3-final-matrix-root-v1-20261018');d=json.loads((out/'execution.json').read_text());assert d['status']=='complete_pending_independent_review';rows=d['commands'];assert len(rows)==98
for i,c in enumerate(rows,1):
 assert c['index']==i and c['guard_stop'] is None and c['peak_target_bytes']<=1024**3 and c['free_bytes_after']>=5*1024**3
 for x in c['streams'].values():
  b=pathlib.Path(x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
compiles=[x for c in d['jarde_cells'] for x in c['compiles']];runs=[x for c in compiles for x in c['runtime_runs']];assert len(compiles)==20 and all(x['exit_code']==0 for x in compiles);assert len(runs)==40 and all(x['exit_code']==0 and x['eight_cases_valid'] and x['matches_original_profile_oracle'] for x in runs)
jc=[x for c in d['jadx_cells'] for x in c['compiles']];assert len(jc)==6 and all(x['exit_code']==1 and x['runtime_runs']==[] for x in jc)
for x in jc:
 raw=pathlib.Path(rows[x['compile_command']-1]['streams']['stderr']['path']).read_text();assert raw.count('可能尚未初始化变量inputStream')==2
for key in ('source_pins_unchanged','resource_pins_unchanged','repository_target_absent_after'):assert d[key]
base=pathlib.Path('/private/tmp/jarde-tf3-original-baseline-root-v2-20261018');final=pathlib.Path('/private/tmp/jarde-tf3-original-final-root-v1-20261018');count=0
for p in final.glob('jarde/*/*/*/report.json'):
 a=json.loads(p.read_text());b=json.loads((base/p.relative_to(final)).read_text())
 for aa,bb in zip([a]+[v['child'] for v in a['member_family'].get('members',[]) if 'child' in v],[b]+[v['child'] for v in b['member_family'].get('members',[]) if 'child' in v]):
  for m,n in zip(aa['methods'],bb['methods']):
   if m['item']['name']['escaped']=='getInputStream':continue
   for f in ('text','source_map','quality','representation','content','fallbacks'):assert m['outcome']['report'][f]==n['outcome']['report'][f],(p,m['item']['name']['escaped'],f)
   count+=1
r={'status':'root accepted exact final TestFinally3 scope','commands':98,'raw_streams_reopened':196,'Jarde_whole_source_compiles':20,'Jarde_rebuilt_runs':40,'Jarde_runtime_cases':320,'JADX_whole_source_compile_failures':6,'JADX_runtime_runs':0,'non_target_method_configurations_unchanged':count,'all_100_method_maps_independently_accepted':True,'limitations':'javac23-generated debug/noDebug inputs, major55 harness restricts owner compile to javac23; noop close count/order unobservable; no complete unit/71 increment'}
(out/'root-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(r)
