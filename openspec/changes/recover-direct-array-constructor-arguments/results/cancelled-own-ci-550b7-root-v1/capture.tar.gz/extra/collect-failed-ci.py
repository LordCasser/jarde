#!/usr/bin/env python3
"""Collect raw evidence for one completed failed/cancelled direct-array CI run.

This collector never accepts a successful run. It preserves exact old-product git-show bytes,
records whether each pinned path still matches the current checkout, and leaves acceptance pending.
"""
from __future__ import annotations

import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
REPO = 'LordCasser/jarde'
SOURCE_PATHS = (
    '.github/workflows/ci.yml',
    'crates/jarde-java/src/init.rs',
    'crates/jarde-java/src/build.rs',
    'crates/jarde-java/src/report.rs',
    'crates/jarde-java/src/guard.rs',
    'crates/jarde-reader/src/classfile.rs',
    'tests/recover_direct_array_constructor_arguments.rs',
    'tests/recover_direct_array_constructor_stops.rs',
    'tests/recover_original_test_finally3.rs',
    'tests/p3_constructed_reference_array_elements.rs',
    'tests/fixtures/constructor-direct-array-arguments/fixture-pins.json',
    'tests/fixtures/constructor-direct-array-arguments/DirectArrayConstructorArguments.java',
    'tests/fixtures/constructor-direct-array-arguments/same-owner/SameOwnerArrayArguments.java',
    'tests/fixtures/constructor-direct-array-arguments/reverse-order/ReverseArrayOrder.java',
    'tests/fixtures/corpus-fingerprint.json',
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def command(out: Path, root: Path, argv: list[str], name: str) -> dict:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    stdout, stderr = out / name, out / (name + '.stderr.raw')
    stdout.parent.mkdir(parents=True, exist_ok=True)
    with stdout.open('xb') as so, stderr.open('xb') as se:
        result = subprocess.run(argv, cwd=root, stdout=so, stderr=se)
    row = {'argv': argv, 'exit_code': result.returncode, 'started_at': started,
           'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'streams': {'stdout': pin(stdout), 'stderr': pin(stderr)}}
    if result.returncode != 0:
        raise RuntimeError(f'command failed: {row}')
    return row


def main() -> int:
    if len(sys.argv) != 4:
        raise SystemExit('usage: collect-failed-ci.py OUT_DIR RUN_ID PRODUCT_SHA')
    out, run_id, product = Path(sys.argv[1]).resolve(), sys.argv[2], sys.argv[3]
    if re.fullmatch(r'[0-9a-f]{40}', product) is None:
        raise SystemExit('PRODUCT_SHA must be a lowercase full 40-character SHA')
    if not run_id or out.exists():
        raise SystemExit('RUN_ID must be non-empty and OUT_DIR must be fresh')
    root = ROOT.resolve(strict=True)
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('refusing to collect while repository target exists')
    out.mkdir(parents=True)
    record = {'product_sha': product, 'run_id': run_id, 'commands': [],
              'status': 'collecting', 'source_paths': list(SOURCE_PATHS)}

    row = command(out, root, ['gh', 'run', 'view', run_id, '--repo', REPO,
        '--json', 'jobs,headSha,status,conclusion,url,databaseId,workflowName'], 'run.json')
    record['commands'].append(row)
    run = json.loads((out / 'run.json').read_text(encoding='utf-8'))
    if (str(run.get('databaseId')) != run_id or run.get('headSha') != product or run.get('status') != 'completed' or
            run.get('conclusion') not in ('failure', 'cancelled')):
        raise RuntimeError(f'run is not a completed failure/cancellation for the exact product SHA: {run}')
    jobs = {'stable / test and specification': 'stable', 'MSRV 1.88.0': 'msrv',
            'supply chain': 'supply-chain', 'fuzz smoke': 'fuzz-smoke'}
    run_jobs = run.get('jobs', [])
    if ({job.get('name') for job in run_jobs} != set(jobs) or len(run_jobs) != len(jobs)
            or any(job.get('status') != 'completed' or not job.get('databaseId') for job in run_jobs)):
        raise RuntimeError('CI job inventory differs from the four-job workflow contract')
    record['run_header'] = {
        'head_sha': run['headSha'],
        'status': run['status'],
        'conclusion': run['conclusion'],
        'url': run.get('url'),
        'workflow_name': run.get('workflowName'),
        'jobs': [
            {'name': job['name'], 'database_id': job['databaseId'],
             'status': job['status'], 'conclusion': job.get('conclusion')}
            for job in sorted(run_jobs, key=lambda item: item['name'])
        ],
    }
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(command, out, root, ['gh', 'run', 'view', run_id, '--repo', REPO,
            '--job', str(job['databaseId']), '--log'], jobs[job['name']] + '.log') for job in run['jobs']]
        log_rows = [f.result() for f in futures]
        for job_row in log_rows:
            raw_log = (out / job_row['streams']['stdout']['path']).read_bytes()
            if not raw_log:
                raise RuntimeError(f'job log is empty; full real log was not collected: {job_row["argv"]}')
        record['commands'].extend(log_rows)

    files = {}
    for rel in SOURCE_PATHS:
        row = command(out, root, ['git', 'show', product + ':' + rel], 'product-source/' + rel)
        record['commands'].append(row)
        captured = out / 'product-source' / rel
        data = captured.read_bytes()
        current = (root / rel).read_bytes()
        files[rel] = {'git_show': 'git show ' + product + ':' + rel,
                      'bytes': len(data), 'sha256': sha(data),
                      'current_checkout_matches': data == current,
                      'current_checkout_bytes': len(current),
                      'current_checkout_sha256': sha(current)}

    pin_path = 'tests/fixtures/constructor-direct-array-arguments/fixture-pins.json'
    fixture_manifest = json.loads((out / 'product-source' / pin_path).read_text(encoding='utf-8'))
    fixture_classes = {}
    for item in fixture_manifest.get('classes', []):
        rel = item.get('path')
        expected_sha = item.get('sha256')
        if not isinstance(rel, str) or not isinstance(expected_sha, str):
            raise RuntimeError('fixture-pins.json contains a malformed class row')
        row = command(out, root, ['git', 'show', product + ':' + rel], 'product-fixtures/' + rel)
        record['commands'].append(row)
        captured = out / 'product-fixtures' / rel
        data = captured.read_bytes()
        current = (root / rel).read_bytes()
        if sha(data) != expected_sha:
            raise RuntimeError(f'fixture class differs from the old product fixture pin: {rel}')
        fixture_classes[rel] = {'git_show': 'git show ' + product + ':' + rel,
                                'bytes': len(data), 'sha256': sha(data),
                                'fixture_manifest_sha256': expected_sha,
                                'current_checkout_matches': data == current,
                                'current_checkout_bytes': len(current),
                                'current_checkout_sha256': sha(current)}
    if not fixture_classes:
        raise RuntimeError('fixture-pins.json has no class records')

    pins = {'product_sha': product, 'files': files, 'fixture_classes': fixture_classes,
            'current_checkout_matches_product': all(
                item['current_checkout_matches'] for item in files.values()
            ) and all(item['current_checkout_matches'] for item in fixture_classes.values()),
            'fixture_manifest': pin_path}
    (out / 'source-pins.json').write_text(json.dumps(pins, indent=2) + '\n', encoding='utf-8')
    (out / 'workflow.sha256').write_text(files['.github/workflows/ci.yml']['sha256'] + '\n', encoding='ascii')
    record['fixture_class_count'] = len(fixture_classes)
    record['status'] = 'failed-run raw collection complete; no success accepted; independent failure analysis pending'
    (out / 'collection.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': record['status'], 'commands': len(record['commands']),
                      'fixture_classes': len(fixture_classes)}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
