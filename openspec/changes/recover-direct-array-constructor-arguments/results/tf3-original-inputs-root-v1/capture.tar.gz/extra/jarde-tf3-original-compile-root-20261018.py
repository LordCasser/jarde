from pathlib import Path
import json,hashlib,os,importlib.util,zipfile,datetime,shutil
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');JADX=Path('/Users/lordcasser/workspace/testzone/jadx');OUT=Path('/private/tmp/jarde-tf3-original-inputs-root-v1-20261018');OUT.mkdir();(OUT/'raw').mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','cmp');g=load(ROOT/c.GUARD_REL,'guard');scan=load(ROOT/c.SCANNER_REL,'scan');assert c.sha(ROOT/c.GUARD_REL)==c.GUARD_SHA256 and c.sha(ROOT/c.SCANNER_REL)==c.SCANNER_SHA256
g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:scan.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
jdks,jdkpin=c.configured_jdks(ROOT/c.DEFAULT_JDK_MANIFEST_REL,c.DEFAULT_JDK_MANIFEST_SHA256)
source=JADX/'jadx-core/src/test/java/jadx/tests/integration/trycatch/TestFinally3.java';assert c.sha(source)=='0671606e6d7fee3aa1c8b8430758764eff60dfa00d4f0dc144006e0eb6808130';(OUT/'source').mkdir();copy=OUT/'source/TestFinally3.java';shutil.copyfile(source,copy);(OUT/'empty-sourcepath').mkdir()
harness=OUT/'jadx-test-harness.jar';testbase=JADX/'jadx-core/build/classes/java/test';entries={}
for p in sorted(testbase.rglob('*.class')):
 rel=p.relative_to(testbase).as_posix()
 if rel.startswith('jadx/tests/api/') or rel.startswith('jadx/NotYetImplemented'):
  assert 'TestFinally3' not in rel;entries[rel]=c.pin(p)
with zipfile.ZipFile(harness,'w') as z:
 for rel,pin in entries.items():z.writestr(zipfile.ZipInfo(rel,(1980,1,1,0,0,0)),Path(pin['path']).read_bytes())
rel_dirs=['jadx-core/build/classes/java/main','jadx-plugins/jadx-input-api/build/classes/java/main','jadx-commons/jadx-zip/build/classes/java/main','jadx-commons/jadx-analysis/build/classes/java/main'];dirs=[JADX/x for x in rel_dirs];directory_pins={}
for p in dirs:
 assert p.is_dir();directory_pins[str(p)]={x.relative_to(p).as_posix():c.pin(x) for x in sorted(p.rglob('*.class'))}
deps=Path('/private/tmp/jarde-tf3-original-harness-deps-root-v1-20261018');jars=sorted(deps.glob('*.jar'))+[Path('/Users/lordcasser/.m2/repository/org/apiguardian/apiguardian-api/1.1.2/apiguardian-api-1.1.2.jar'),Path('/Users/lordcasser/.m2/repository/org/opentest4j/opentest4j/1.3.0/opentest4j-1.3.0.jar')];cp=[harness,*dirs,*jars]
rows=[];report={'status':'running','source':c.pin(source),'source_copy':c.pin(copy),'source_jadx_commit':'2fb1b16386941660fda07e9017285aec40fcb37f','harness_jar':c.pin(harness),'harness_entries':entries,'directory_pins':directory_pins,'classpath':[str(p) for p in cp],'jar_pins':[c.pin(p) for p in jars],'jdk_manifest':jdkpin,'guard':c.pin(ROOT/c.GUARD_REL),'scanner':c.pin(ROOT/c.SCANNER_REL),'commands':rows,'profiles':[]};c.write_json(OUT/'execution.json',report)
def cmd(argv,label):
 env=c.clean_env(dict(os.environ),jdks['javac23']);env.update(g.ENV_VALUES);env.pop('RUST_MIN_STACK',None);r=g.run_command(len(rows)+1,[str(x) for x in argv],env);r['label']=label;rows.append(r);c.write_json(OUT/'execution.json',report);assert r['guard_stop'] is None;return r
for label,flag in [('debug','-g'),('no-debug','-g:none')]:
 dest=OUT/label/'classes';dest.mkdir(parents=True);r=cmd([jdks['javac23']['tools']['javac'],'-source','1.8','-target','1.8',flag,'-encoding','UTF-8','-proc:none','-classpath',os.pathsep.join(str(p) for p in cp),'-sourcepath',OUT/'empty-sourcepath','-d',dest,copy],'compile-'+label);cell={'profile':label,'command':r['index'],'exit_code':r['exit_code'],'output_files':[c.pin(p) for p in sorted(dest.rglob('*')) if p.is_file()]};report['profiles'].append(cell)
 if r['exit_code']==0:
  target=dest/'jadx/tests/integration/trycatch/TestFinally3$TestCls.class';outer=dest/'jadx/tests/integration/trycatch/TestFinally3.class';assert target.is_file() and outer.is_file() and len(cell['output_files'])==2
  facts=c.parse_class(target);assert facts['major']==52 and len(facts['methods'])==7;cell['target_facts']=facts;cell['outer_facts']=c.parse_class(outer);v=cmd([jdks['javac23']['tools']['javap'],'-p','-s','-c','-v',target],'javap-'+label);assert v['exit_code']==0;cell['javap_command']=v['index']
 c.write_json(OUT/'execution.json',report)
assert c.sha(source)==report['source']['sha256'] and c.sha(copy)==report['source_copy']['sha256'];assert not (ROOT/'target').exists();report['status']='compiled profiles pending independent review' if all(p['exit_code']==0 for p in report['profiles']) else 'source compilation failure retained';report['target_absent']=True;c.write_json(OUT/'execution.json',report);print(json.dumps({'status':report['status'],'profiles':[(x['profile'],x['exit_code'],len(x['output_files'])) for x in report['profiles']],'commands':len(rows)}))
