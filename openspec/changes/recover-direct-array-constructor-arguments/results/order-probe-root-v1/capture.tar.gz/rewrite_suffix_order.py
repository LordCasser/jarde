#!/usr/bin/env python3
"""Rewrite javac -g:none ArrayArgumentOrderProbe.suffix for a read-only proof probe.

Input is the compiled ArrayArgumentOrderProbe.class. Output is a classfile with a valid
operand-stack-preserving mutation: mark(3) runs before mark(2), then JVM swap (0x5f)
restores the constructor's physical argument order before newarray. No branches or exception
tables occur in the target method, so insertion changes only Code.code_length and the Code
attribute length. Compile the Java source with the requested javac outside this script.
"""
import argparse
import pathlib
import struct


def u1(data, pos):
    return data[pos]


def u2(data, pos):
    return struct.unpack_from(">H", data, pos)[0]


def u4(data, pos):
    return struct.unpack_from(">I", data, pos)[0]


def put_u4(data, pos, value):
    struct.pack_into(">I", data, pos, value)


def skip_attributes(data, pos, count):
    for _ in range(count):
        length = u4(data, pos + 2)
        pos += 6 + length
    return pos


def skip_member(data, pos):
    attr_count = u2(data, pos + 6)
    return skip_attributes(data, pos + 8, attr_count)


def locate_suffix_code(data):
    if u4(data, 0) != 0xCAFEBABE:
        raise ValueError("not a classfile")
    cp_count = u2(data, 8)
    utf8 = {}
    pos = 10
    index = 1
    while index < cp_count:
        tag = u1(data, pos)
        pos += 1
        if tag == 1:
            size = u2(data, pos)
            utf8[index] = data[pos + 2 : pos + 2 + size].decode("utf-8")
            pos += 2 + size
        elif tag in (3, 4, 9, 10, 11, 12, 17, 18):
            pos += 4
        elif tag in (5, 6):
            pos += 8
            index += 1
        elif tag in (7, 8, 16, 19, 20):
            pos += 2
        elif tag == 15:
            pos += 3
        else:
            raise ValueError(f"unsupported constant-pool tag {tag}")
        index += 1

    pos += 6  # access_flags, this_class, super_class
    interfaces = u2(data, pos)
    pos += 2 + interfaces * 2
    fields = u2(data, pos)
    pos += 2
    for _ in range(fields):
        pos = skip_member(data, pos)
    methods = u2(data, pos)
    pos += 2
    for _ in range(methods):
        name = utf8[u2(data, pos + 2)]
        attr_count = u2(data, pos + 6)
        attr_pos = pos + 8
        for _ in range(attr_count):
            attr_name = utf8[u2(data, attr_pos)]
            attr_len = u4(data, attr_pos + 2)
            if name == "suffix" and attr_name == "Code":
                code_len_pos = attr_pos + 6 + 4
                code_len = u4(data, code_len_pos)
                code_pos = code_len_pos + 4
                return attr_pos, code_len_pos, code_pos, code_len
            attr_pos += 6 + attr_len
        pos = attr_pos
    raise ValueError("suffix() Code attribute not found")


def rewrite(source, destination):
    data = bytearray(pathlib.Path(source).read_bytes())
    attr_pos, code_len_pos, code_pos, code_len = locate_suffix_code(data)
    code = bytes(data[code_pos : code_pos + code_len])
    # javac emits iconst_2; invokestatic mark; iconst_3; invokestatic mark; newarray int.
    # Derive the shared constant-pool operand from the two adjacent invokestatic instructions.
    hits = []
    for pos in range(len(code) - 9):
        if code[pos] != 0x05 or code[pos + 1] != 0xB8:
            continue
        if code[pos + 4] != 0x06 or code[pos + 5] != 0xB8 or code[pos + 8 : pos + 10] != b"\xbc\x0a":
            continue
        first = code[pos + 2 : pos + 4]
        second = code[pos + 6 : pos + 8]
        if first == second:
            hits.append((pos, first))
    if len(hits) != 1:
        raise ValueError(f"expected one mark(2), mark(3), newarray sequence; found {len(hits)}")
    pos, cp = hits[0]
    old = code[pos : pos + 10]
    new = b"\x06\xb8" + cp + b"\x05\xb8" + cp + b"\x5f\xbc\x0a"
    assert len(new) == len(old) + 1
    data[code_pos + pos : code_pos + pos + len(old)] = new
    put_u4(data, code_len_pos, code_len + 1)
    put_u4(data, attr_pos + 2, u4(data, attr_pos + 2) + 1)
    pathlib.Path(destination).write_bytes(data)
    print(f"rewrote suffix bytecode at method-relative BCI {pos}; added JVM swap")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("input_class")
    parser.add_argument("output_class")
    args = parser.parse_args()
    rewrite(args.input_class, args.output_class)
