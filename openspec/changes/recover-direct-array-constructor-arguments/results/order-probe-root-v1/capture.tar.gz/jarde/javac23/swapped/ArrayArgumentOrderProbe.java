// jarde: presentation of `ArrayArgumentOrderProbe` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class ArrayArgumentOrderProbe extends java.lang.Object {
    private static int trace;

    public ArrayArgumentOrderProbe() {
        // @method <init>()V
        // @declaration a constructor of `ArrayArgumentOrderProbe`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    private static int mark(int arg0) {
        // @method mark(I)I
        // @declaration a static method of `ArrayArgumentOrderProbe`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        ArrayArgumentOrderProbe.trace = ArrayArgumentOrderProbe.trace * 10 + arg0;
        return arg0;
    }

    static Sink suffix() {
        // @method suffix()LArrayArgumentOrderProbe$Sink;
        // @declaration a static method of `ArrayArgumentOrderProbe`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the instruction at BCI 0 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 5
        // the array instruction at BCI 5 produces a value nothing in this body reads, so the instruction the bytecode runs has no place in the text
        // @bytecode 7 5
        // the instruction at BCI 7 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 13 5 10
        // the copy at BCI 7 has no proved local assignment
        mark(3);
        mark(2);
        // @bytecode 22
        // the instruction at BCI 22 is not part of the provable subset
        // @bytecode 23
        // the dependency chain from BCI 23 to final consumer 28 is not bounded
        // @bytecode 5 23 25
        // the dependency chain from BCI 25 to final consumer 28 is not bounded
        // @bytecode 28 25 5 23
        // the value at BCI 28 was produced by a saved declaration this run could not commit
    }

    static final class Sink extends java.lang.Object {
        final int[] first;

        final int middle;

        final int[] last;

        Sink(int[] arg1, int arg2, int[] arg3) {
            // @method <init>([II[I)V
            // @declaration a constructor of `ArrayArgumentOrderProbe$Sink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.first = arg1;
            this.middle = arg2;
            this.last = arg3;
            return;
        }
    }
}
