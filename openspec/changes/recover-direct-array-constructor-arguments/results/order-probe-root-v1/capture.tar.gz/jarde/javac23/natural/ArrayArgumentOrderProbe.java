// jarde: presentation of `ArrayArgumentOrderProbe` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class ArrayArgumentOrderProbe extends java.lang.Object {
    private static int trace;

    public ArrayArgumentOrderProbe() {
        // @method <init>()V
        // @declaration a constructor of `ArrayArgumentOrderProbe`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    private static int mark(int arg0) {
        // @method mark(I)I
        // @declaration a static method of `ArrayArgumentOrderProbe`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        ArrayArgumentOrderProbe.trace = ArrayArgumentOrderProbe.trace * 10 + arg0;
        return arg0;
    }

    static Sink suffix() {
        // @method suffix()LArrayArgumentOrderProbe$Sink;
        // @declaration a static method of `ArrayArgumentOrderProbe`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        return new Sink(new int[]{mark(1)}, mark(2), new int[mark(3)]);
    }

    static final class Sink extends java.lang.Object {
        final int[] first;

        final int middle;

        final int[] last;

        Sink(int[] arg1, int arg2, int[] arg3) {
            // @method <init>([II[I)V
            // @declaration a constructor of `ArrayArgumentOrderProbe$Sink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.first = arg1;
            this.middle = arg2;
            this.last = arg3;
            return;
        }
    }
}
