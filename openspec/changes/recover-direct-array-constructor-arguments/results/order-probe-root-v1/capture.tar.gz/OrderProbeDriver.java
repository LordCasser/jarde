import java.io.File; import java.net.*; import java.lang.reflect.*;
public final class OrderProbeDriver { public static void main(String[] args) throws Exception {
File dir=new File(args[0]).getCanonicalFile(); ClassLoader parent=ClassLoader.getSystemClassLoader().getParent();
try(URLClassLoader loader=new URLClassLoader(new URL[]{dir.toURI().toURL()},parent)) {
Class<?> c=Class.forName("ArrayArgumentOrderProbe",true,loader); if(!new File(c.getProtectionDomain().getCodeSource().getLocation().toURI()).getCanonicalFile().equals(dir)) throw new AssertionError("CodeSource");
Method m=c.getDeclaredMethod("suffix");m.setAccessible(true);Object sink=m.invoke(null);Field t=c.getDeclaredField("trace");t.setAccessible(true);int expected=args[1].equals("natural")?123:132;if(t.getInt(null)!=expected)throw new AssertionError("trace");
Class<?> s=sink.getClass();Field a=s.getDeclaredField("first"),b=s.getDeclaredField("middle"),d=s.getDeclaredField("last");a.setAccessible(true);b.setAccessible(true);d.setAccessible(true);int[] x=(int[])a.get(sink),y=(int[])d.get(sink);if(x.length!=1||x[0]!=1||b.getInt(sink)!=2||y.length!=3||x==y)throw new AssertionError("values");
System.out.println("order-probe:"+args[1]+",trace="+expected+",first=1,middle=2,last=3"); } }}