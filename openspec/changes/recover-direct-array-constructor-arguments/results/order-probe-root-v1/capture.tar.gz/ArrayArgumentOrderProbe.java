public final class ArrayArgumentOrderProbe {
    private static int trace;

    private static int mark(int digit) {
        trace = trace * 10 + digit;
        return digit;
    }

    static final class Sink {
        final int[] first;
        final int middle;
        final int[] last;

        Sink(int[] first, int middle, int[] last) {
            this.first = first;
            this.middle = middle;
            this.last = last;
        }
    }

    // Rewriter target: bytecode evaluates mark(2), then mark(3), then consumes mark(3) as
    // the last array's dimension. The mutant evaluates mark(3), then mark(2), swaps the two
    // results, and allocates the same final argument. The physical constructor operands still
    // have the same types and values; only their source evaluation order differs.
    static Sink suffix() {
        return new Sink(new int[] {mark(1)}, mark(2), new int[mark(3)]);
    }
}
