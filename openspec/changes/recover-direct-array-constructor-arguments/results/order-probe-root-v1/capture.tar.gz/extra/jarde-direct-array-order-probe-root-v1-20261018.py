from pathlib import Path
import importlib.util,json,os,zipfile,shutil
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');PREP=Path('/private/tmp/jarde-direct-array-order-probe-v1-20261018');OUT=Path('/private/tmp/jarde-direct-array-order-probe-root-v1-20261018');CLI=Path('/private/tmp/jarde-direct-array-focused-root-v3-20261018/candidate-cli');assert not OUT.exists() and not(ROOT/'target').exists();OUT.mkdir();(OUT/'raw').mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','c');g=load(ROOT/c.GUARD_REL,'g');scan=load(ROOT/c.SCANNER_REL,'s');assert c.sha(ROOT/c.GUARD_REL)==c.GUARD_SHA256 and c.sha(ROOT/c.SCANNER_REL)==c.SCANNER_SHA256;g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:scan.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
jdks,jdkpin=c.configured_jdks(ROOT/c.DEFAULT_JDK_MANIFEST_REL,c.DEFAULT_JDK_MANIFEST_SHA256)
for f in ('ArrayArgumentOrderProbe.java','rewrite_suffix_order.py'):shutil.copyfile(PREP/f,OUT/f)
rew=load(OUT/'rewrite_suffix_order.py','rew');driver=OUT/'OrderProbeDriver.java';driver.write_text('''import java.io.File; import java.net.*; import java.lang.reflect.*;
public final class OrderProbeDriver { public static void main(String[] args) throws Exception {
File dir=new File(args[0]).getCanonicalFile(); ClassLoader parent=ClassLoader.getSystemClassLoader().getParent();
try(URLClassLoader loader=new URLClassLoader(new URL[]{dir.toURI().toURL()},parent)) {
Class<?> c=Class.forName("ArrayArgumentOrderProbe",true,loader); if(!new File(c.getProtectionDomain().getCodeSource().getLocation().toURI()).getCanonicalFile().equals(dir)) throw new AssertionError("CodeSource");
Method m=c.getDeclaredMethod("suffix");m.setAccessible(true);Object sink=m.invoke(null);Field t=c.getDeclaredField("trace");t.setAccessible(true);int expected=args[1].equals("natural")?123:132;if(t.getInt(null)!=expected)throw new AssertionError("trace");
Class<?> s=sink.getClass();Field a=s.getDeclaredField("first"),b=s.getDeclaredField("middle"),d=s.getDeclaredField("last");a.setAccessible(true);b.setAccessible(true);d.setAccessible(true);int[] x=(int[])a.get(sink),y=(int[])d.get(sink);if(x.length!=1||x[0]!=1||b.getInt(sink)!=2||y.length!=3||x==y)throw new AssertionError("values");
System.out.println("order-probe:"+args[1]+",trace="+expected+",first=1,middle=2,last=3"); } }}''')
rows=[];r={'status':'running','commands':rows,'cli':c.pin(CLI),'jdk':jdkpin,'source_before':c.source_closure(ROOT),'oracles':[],'cells':[]};c.write_json(OUT/'execution.json',r)
def cmd(argv,leg,label):
 env=c.clean_env(dict(os.environ),jdks[leg]);env.update(g.ENV_VALUES);row=g.run_command(len(rows)+1,[str(x) for x in argv],env);row['label']=label;rows.append(row);c.write_json(OUT/'execution.json',r);assert row['guard_stop'] is None;return row
for leg in ('javac8','javac23'):
 flags=['-source','8','-target','8'] if leg=='javac8' else ['--release','8'];natural=OUT/leg/'natural';natural.mkdir(parents=True);empty=OUT/leg/'empty';empty.mkdir();dc=OUT/leg/'driver';dc.mkdir()
 for src,d in [(OUT/'ArrayArgumentOrderProbe.java',natural),(driver,dc)]:
  row=cmd([jdks[leg]['tools']['javac'],*flags,'-g:none','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',d,src],leg,leg+'-'+src.name);assert row['exit_code']==0
 swapped=OUT/leg/'swapped';shutil.copytree(natural,swapped);rew.rewrite(natural/'ArrayArgumentOrderProbe.class',swapped/'ArrayArgumentOrderProbe.class')
 for mode in ('natural','swapped'):
  target=OUT/leg/mode
  for runtime in ('javac8','javac23'):
   row=cmd([jdks[runtime]['tools']['java'],'-Xverify:all','-cp',dc,'OrderProbeDriver',target,mode],runtime,leg+'-'+mode+'-'+runtime);expect=f'order-probe:{mode},trace={123 if mode=="natural" else 132},first=1,middle=2,last=3\n'.encode();assert row['exit_code']==0 and c.command_artifact(row,'stdout')==expect and not c.command_artifact(row,'stderr');r['oracles'].append({'compiler':leg,'mode':mode,'runtime':runtime,'command':row['index']})
  bundle=OUT/(leg+'-'+mode+'.jar')
  with zipfile.ZipFile(bundle,'w') as z:
   for p in sorted(target.glob('*.class')):z.writestr(zipfile.ZipInfo(p.name,(1980,1,1,0,0,0)),p.read_bytes())
  row=cmd([CLI,'class-source','--input',bundle,'--class','ArrayArgumentOrderProbe','--policy','plain-jar','--release','8','--evidence','all','--format','json'],'javac23',leg+'-'+mode+'-jarde');assert row['exit_code'] in (0,4);raw=c.command_artifact(row,'stdout');doc=json.loads(raw);dest=OUT/'jarde'/leg/mode;dest.mkdir(parents=True);(dest/'report.json').write_bytes(raw);(dest/'ArrayArgumentOrderProbe.java').write_text(doc['text']);method=next(m for m in doc['methods'] if m['item']['name']['escaped']=='suffix');report=method['outcome']['report'];site=next(n for n in report['news'] if n['head']==0);assert site['presented']==(mode=='natural'),(leg,mode,site);r['cells'].append({'compiler':leg,'mode':mode,'command':row['index'],'quality':report['quality'],'site':site})
r['source_after']=c.source_closure(ROOT);assert r['source_before']==r['source_after'];r['target_absent']=not(ROOT/'target').exists();assert r['target_absent'];r['status']='actual JVM and construction-order control accepted';c.write_json(OUT/'execution.json',r);print(r['status'],len(rows))
