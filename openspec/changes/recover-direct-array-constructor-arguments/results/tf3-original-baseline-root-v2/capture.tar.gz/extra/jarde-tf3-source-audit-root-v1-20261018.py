from pathlib import Path
import json,importlib.util,sys,hashlib,blake3,zipfile
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');IN=Path('/private/tmp/jarde-tf3-original-inputs-root-v1-20261018');BASE=Path(sys.argv[1]);OUT=Path(sys.argv[2]);mode=sys.argv[3]
s=importlib.util.spec_from_file_location('cmp',ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
receipt=json.loads((BASE/'execution.json').read_text());rows=[];texts={};facts={}
for profile in ['debug','no-debug']:
 for binary in ['TestFinally3','TestFinally3$TestCls']:
  p=IN/profile/'classes'/'jadx/tests/integration/trycatch'/(binary+'.class');parsed=c.parse_class(p);facts[(profile,binary)]=(p,parsed,blake3.blake3(p.read_bytes()).hexdigest())
for cell in receipt['jarde_cells']:
 profile,form,evidence=cell['profile'],cell['form'],cell['evidence'];doc=json.loads((BASE/'jarde'/profile/form/evidence/'report.json').read_text())
 docs=[doc]+[x['child'] for x in doc['member_family'].get('members',[]) if 'child' in x]
 for d in docs:
  identity=d['class'];binary='TestFinally3$TestCls' if len(d['methods'])==7 else 'TestFinally3';path,parsed,b3=facts[(profile,binary)]
  assert identity['class_bytes']=={'digest':b3,'length':path.stat().st_size};assert len(d['methods'])==len(parsed['methods'])
  if form=='child':assert identity['location']['kind']=='standalone_root' and identity['location']['snapshot']==b3
  else:
   loc=identity['location'];assert loc['kind']=='archive_entry';entry=loc['entry'];assert bytes(entry['raw_name']).decode()=='jadx/tests/integration/trycatch/'+binary+'.class'
   with zipfile.ZipFile(BASE/(profile+'.jar')) as z:assert z.infolist()[entry['ordinal']].filename==bytes(entry['raw_name']).decode() and z.read(z.infolist()[entry['ordinal']])==path.read_bytes()
  for index,(method,physical) in enumerate(zip(d['methods'],parsed['methods'])):
   ident=method['item']['identity'];key=(bytes(ident['name']).decode(),bytes(ident['descriptor']).decode());assert key==(physical['name'],physical['descriptor']);assert ident['owner']==identity and method['item']['index']==index
   report=method['outcome']['report'];text=report['text'].encode('utf-8');found=set();bounds=[]
   for seg in report['source_map']['segments']:
    a,b=seg['start'],seg['end'];assert 0<=a<=b<=len(text);text[:a].decode('utf-8');text[:b].decode('utf-8');bounds.append((a,b))
    for anchor in [seg['origin']['primary'],*seg['origin']['derived']]:
     assert anchor['method']==ident
     if anchor['bci'] is not None:assert anchor['bci'] in physical['code']['bcis'];found.add(anchor['bci'])
   missing=sorted(set(physical['code']['bcis'])-found)
   expected=[4] if mode=='baseline' and key==('getInputStream','()Ljava/io/InputStream;') else []
   assert missing==expected,(profile,form,evidence,key,missing)
   comparekey=(profile,form,binary,index);payload=(report['text'],report['source_map'],report['quality'],report['fallbacks'])
   if comparekey in texts:assert texts[comparekey]==payload
   else:texts[comparekey]=payload
   rows.append({'profile':profile,'form':form,'evidence':evidence,'binary':binary,'index':index,'name':key[0],'descriptor':key[1],'class_blake3':b3,'instruction_count':len(physical['code']['bcis']),'mapped_bcis':sorted(found),'missing_bcis':missing,'segments':len(bounds)})
r={'status':'accepted '+mode+' source/map scope','receipt':c.pin(BASE/'execution.json'),'auditor':c.pin(Path(__file__)),'methods':rows,'method_configurations':len(rows),'known_baseline_gaps':[x for x in rows if x['missing_bcis']],'default_all_text_map_quality_fallback_equal':True,'limits':'Does not claim global fallback provenance repaired or any runtime.'};OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(r['status'],len(rows),'missingcases',len(r['known_baseline_gaps']))
