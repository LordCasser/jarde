from pathlib import Path
import re
base=Path('/private/tmp/jarde-direct-array-implementation-prep-20261018/crates/jarde-java/src')

p=base/'init.rs'
s=p.read_text()
# The removed String-only proof was the sole construction-pipeline consumer of this profile field.
s=s.replace('''    arrays: &'a crate::build::ChildArrayFacts<'a>,
    java_release: u16,
    member_targets: &'a [ProvedMemberInnerTarget],
''','''    arrays: &'a crate::build::ChildArrayFacts<'a>,
    member_targets: &'a [ProvedMemberInnerTarget],
''',1)
s=s.replace('''    pub(crate) reserved: &'a BTreeSet<u32>,
    pub(crate) java_release: u16,
    pub(crate) member_targets: &'a [ProvedMemberInnerTarget],
''','''    pub(crate) reserved: &'a BTreeSet<u32>,
    pub(crate) member_targets: &'a [ProvedMemberInnerTarget],
''',1)
s=s.replace('''        arrays,
        java_release: context.java_release,
        member_targets: context.member_targets,
''','''        arrays,
        member_targets: context.member_targets,
''',1)
s=s.replace('''    arrays: &crate::build::ArrayInitializers,
    java_release: u16,
    member_targets: &[ProvedMemberInnerTarget],
''','''    arrays: &crate::build::ArrayInitializers,
    member_targets: &[ProvedMemberInnerTarget],
''',1) # sites cfg(test)
s=s.replace('''        BTreeMap::new(),
        java_release,
        member_targets,
''','''        BTreeMap::new(),
        member_targets,
''',1)
s=s.replace('''    arrays: &mut crate::build::ArrayInitializers,
    java_release: u16,
    member_targets: &[ProvedMemberInnerTarget],
''','''    arrays: &mut crate::build::ArrayInitializers,
    member_targets: &[ProvedMemberInnerTarget],
''',1)
s=s.replace('''        pending_sites,
        java_release,
        member_targets,
''','''        pending_sites,
        member_targets,
''',1)
s=s.replace('''    mut pending_sites: BTreeMap<u32, Site>,
    java_release: u16,
    member_targets: &[ProvedMemberInnerTarget],
''','''    mut pending_sites: BTreeMap<u32, Site>,
    member_targets: &[ProvedMemberInnerTarget],
''',1)
s=s.replace('''        arrays: &array_facts,
        java_release,
        member_targets,
''','''        arrays: &array_facts,
        member_targets,
''',1)
# Remove release field from all context and facts literals in this source.
s=re.sub(r'^\s*(?:pub\(crate\) )?java_release:\s*[^,\n]+,\n','',s,flags=re.M)
# Remove positional release arguments following the arrays argument in test calls.
s=re.sub(r'((?:&mut )?(?:arrays|array_initializers),\n)(\s*)(?:java_release|8),\n',r'\1',s)
# Remove profile argument from the focused test helper and its call sites.
s=s.replace('''        java_release: u16,
        handler_range: Option<(u32, u32)>,
''','''        handler_range: Option<(u32, u32)>,
''',1)
s=s.replace('''            java_release,
            &[],
''','''            &[],
''',1)
s=re.sub(r'inline_char_sites\(([^,\n]+), ([^,\n]+), (?:8|7), ',r'inline_char_sites(\1, \2, ',s)
# Drop the old release-variation assertion: this rule no longer has a release-specific branch.
s=s.replace('''        let older_release = inline_char_sites("direct", "()Ljava/lang/String;", None);
        assert!(
            older_release.site_at_head(0).is_some(),
            "the generic constructor proof does not depend on the String-only Java 8 rule"
        );
''','',1)
# Previous call shape after signature change if the multiline replacement did not match.
s=s.replace('''        let older_release = inline_char_sites("direct", "()Ljava/lang/String;", 7, None);
        assert!(
            older_release.site_at_head(0).is_some(),
            "the generic constructor proof does not depend on the String-only Java 8 rule"
        );
''','',1)
# Rename no-release-sensitive helper references were converted above; update exact direct test if needed.
# Methods which build ArrayCompositionContext have method/code as the only remaining config.
p.write_text(s)

p=base/'build.rs'
s=p.read_text()
# Remove the removed context field from all exact ArrayCompositionContext literals.
s=re.sub(r'^\s*java_release:\s*[^,\n]+,\n(?=\s*(?:member_targets|method|code):)', '', s, flags=re.M)
# sites_after_array_composition arguments carry no release anymore.
s=re.sub(r'((?:&mut )?(?:arrays|array_initializers),\n)(\s*)(?:java_release|8),\n',r'\1',s)
p.write_text(s)

p=base/'report.rs'
s=p.read_text()
s=s.replace('''        reserved: reserved_for_arrays,
        java_release: request.profile.java_release,
        member_targets: request.member_inner_targets,
''','''        reserved: reserved_for_arrays,
        member_targets: request.member_inner_targets,
''',1)
s=s.replace('''        &mut array_initializers,
        request.profile.java_release,
        request.member_inner_targets,
''','''        &mut array_initializers,
        request.member_inner_targets,
''',1)
p.write_text(s)
