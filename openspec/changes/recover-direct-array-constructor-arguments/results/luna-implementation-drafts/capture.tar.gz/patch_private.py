from pathlib import Path
base=Path('/private/tmp/jarde-direct-array-implementation-prep-20261018/crates/jarde-java/src')

p=base/'build.rs'
s=p.read_text()
old='''    /// The complete physical interval of a proved inline array initializer whose sole consumer is
    /// an invocation inside a construction's argument run — the varargs lowering
    /// `anewarray; [dup; index; value; aastore]×n; invoke` whose result (directly or through
    /// further argument production) the constructor call reads. The element production, the closed
    /// interval and the single-use judgements are the ones this plan already proved; this accessor
    /// only states the chain's BCIs, and the caller decides which consumers its construction
    /// accepts. The consumer and every source must sit between the construction's copy and its
    /// call, so the initializer is written exactly where the bytecode evaluated it. A chain the
    /// constructor itself consumes directly stays its own slice's boundary (`new@1` embeds it only
    /// for the Java 8 `String(char[])` shape), and multi-dimensional chains (proved children) and
    /// local postfix elements are not argument-position shapes.
'''
new='''    /// The complete physical interval of a proved inline array initializer whose sole consumer is
    /// an invocation in this construction's argument run, including the constructor call itself
    /// when the initializer's final value is the exact physical argument. The element production,
    /// closed interval and single-use judgements are the ones this plan already proved; this
    /// accessor only states the chain's BCIs and final value, while the caller checks the actual
    /// operand identity. Every source other than the consumer must sit between the construction's
    /// copy and call, so the initializer is written where the bytecode evaluated it. Multi-
    /// dimensional chains (proved children) and local postfix elements remain outside this shape.
'''
assert old in s
s=s.replace(old,new)
s=s.replace('''        serves_argument: impl Fn(u32) -> bool,
    ) -> Option<BTreeSet<u32>> {
        self.child_facts()
            .inline_argument_chain_bcis(allocation, dup, constructor, serves_argument)
''','''        serves_argument: impl Fn(u32, ValueId) -> bool,
    ) -> Option<BTreeSet<u32>> {
        self.child_facts()
            .inline_argument_chain_bcis(allocation, dup, constructor, serves_argument)
''',1)
s=s.replace('''        serves_argument: impl Fn(u32) -> bool,
    ) -> Option<BTreeSet<u32>> {
''','''        serves_argument: impl Fn(u32, ValueId) -> bool,
    ) -> Option<BTreeSet<u32>> {
''',1)
s=s.replace('''        serves_argument: impl Fn(u32) -> bool,
        meter: &mut crate::init::VerifyMeter<'_>,
''','''        serves_argument: impl Fn(u32, ValueId) -> bool,
        meter: &mut crate::init::VerifyMeter<'_>,
''',1)
old='''        let consumer = initializer.consumer;
        let within = |bci: u32| dup < bci && bci < constructor;
        if !within(consumer) || !serves_argument(consumer) {
            return Ok(None);
        }
'''
new='''        let consumer = initializer.consumer;
        let within = |bci: u32| dup < bci && bci < constructor;
        let consumer_is_argument = (within(consumer) || consumer == constructor)
            && serves_argument(consumer, initializer.final_value);
        if !consumer_is_argument {
            return Ok(None);
        }
'''
assert old in s
s=s.replace(old,new,1)
s=s.replace('''                .inline_argument_chain_bcis(5, 3, 32, serves)
''','''                .inline_argument_chain_bcis(5, 3, 32, |consumer, _value| serves(consumer))
''',1)
s=s.replace('''                .inline_argument_chain_bcis(5, 3, 32, |consumer| consumer == 32)
''','''                .inline_argument_chain_bcis(5, 3, 32, |consumer, _value| consumer == 32)
''',1)
s=s.replace('''                .inline_argument_chain_bcis(5, 5, 32, serves)
''','''                .inline_argument_chain_bcis(5, 5, 32, |consumer, _value| serves(consumer))
''',1)
s=s.replace('''                .inline_argument_chain_bcis(5, 3, 29, serves)
''','''                .inline_argument_chain_bcis(5, 3, 29, |consumer, _value| serves(consumer))
''',1)
(base/'build.rs').write_text(s)

p=base/'init.rs'
s=p.read_text()
old='''        let array_serves_argument = |consumer: u32| {
            matches!(operations.get(consumer), Some(Operation::Invoke(_)))
                && argument_dependencies.contains(&consumer)
        };
'''
new='''        // A direct array argument is certified by the exact SSA value in the physical constructor
        // operand list. Count every non-receiver operand so a repeated value cannot claim two
        // argument positions; the ordinary intermediate-consumer path keeps its dependency rule.
        let mut physical_argument_counts = BTreeMap::new();
        for (_, value) in operands.iter().skip(1) {
            meter.charge(CountedBudgetDimension::IrItems, Some(at))?;
            *physical_argument_counts.entry(*value).or_insert(0usize) += 1;
        }
        let array_serves_argument = |consumer: u32, value: ValueId| {
            matches!(operations.get(consumer), Some(Operation::Invoke(_)))
                && if consumer == at {
                    physical_argument_counts.get(&value) == Some(&1)
                } else {
                    argument_dependencies.contains(&consumer)
                }
        };
'''
assert old in s
s=s.replace(old,new,1)
s=s.replace('''                        && array_serves_argument(consumer)
''','''                        && array_serves_argument(consumer, value)
''',1)
# Existing helper calls are changed to the new exact-value callback shape.
s=s.replace('''        let serves = |consumer: u32| dependencies.contains(&consumer);
''','''        let serves = |consumer: u32| dependencies.contains(&consumer);
''',1)
s=s.replace('''                .inline_argument_chain_bcis(5, 3, 32, serves)
''','''                .inline_argument_chain_bcis(5, 3, 32, |consumer, _value| serves(consumer))
''',1)
s=s.replace('''                .inline_argument_chain_bcis(5, 3, 32, |consumer| consumer == 32)
''','''                .inline_argument_chain_bcis(5, 3, 32, |consumer, _value| consumer == 32)
''',1)
s=s.replace('''                .inline_argument_chain_bcis(5, 5, 32, serves)
''','''                .inline_argument_chain_bcis(5, 5, 32, |consumer, _value| serves(consumer))
''',1)
s=s.replace('''                .inline_argument_chain_bcis(5, 3, 29, serves)
''','''                .inline_argument_chain_bcis(5, 3, 29, |consumer, _value| serves(consumer))
''',1)
# the previous generic helper test is in build.rs, not init.rs; update any callback remaining below separately.
# Frozen class inputs supplied by root.
needle='''    const INLINE_CHAR_ARRAY: &[u8] =
        include_bytes!("../../../tests/fixtures/em27-inline-string/em27/Probe.class");
'''
insert=needle+'''    const DIRECT_ARRAY_ARGUMENTS_JAVAC8: &[u8] = include_bytes!(
        "../../../tests/fixtures/constructor-direct-array-arguments/javac8/classes/DirectArrayConstructorArguments.class"
    );
    const DIRECT_ARRAY_ARGUMENTS_JAVAC23: &[u8] = include_bytes!(
        "../../../tests/fixtures/constructor-direct-array-arguments/javac23/classes/DirectArrayConstructorArguments.class"
    );
'''
assert needle in s
s=s.replace(needle,insert,1)
# Add a production-order composition helper after inline_char_sites.
needle='''    fn inline_char_sites(
        name: &str,
        descriptor: &str,
        java_release: u16,
        handler_range: Option<(u32, u32)>,
    ) -> Sites {
'''
start=s.index(needle)
end=s.index('\n    #[test]\n    fn only_the_complete_direct_java8_string_char_array_is_embedded()',start)
helper='''
    fn direct_array_argument_sites(class: &[u8], name: &str, descriptor: &str) -> Sites {
        let (analysis, _) = analyzed_caller(class, name, descriptor);
        let ir = analysis.ir();
        let ssa = ir.ssa().expect("ssa");
        let code = ir.code().expect("code");
        let operations = Operations::of(code, ir.constant_pool());
        let fields = field::Plan::empty();
        let chains = crate::concat::Plan::empty();
        let method = crate::facts::MethodFacts::new(name, descriptor, 0);
        let context = ArrayCompositionContext {
            chains: &chains,
            reserved: chains.owned(),
            java_release: 8,
            member_targets: &[],
        };
        let mut budget = proof_budget();
        let mut arrays = crate::build::ArrayInitializers::prove_with_composition(
            ssa,
            &operations,
            &fields,
            Some(&context),
            &mut budget,
        )
        .expect("array proof completes");
        sites_after_array_composition(
            ssa,
            &operations,
            &chains,
            chains.owned(),
            &fields,
            &mut arrays,
            8,
            &[],
            &method,
            code,
            &mut budget,
        )
        .expect("site composition completes")
    }
'''
s=s[:end]+helper+s[end:]
# Turn the measured wrongOwner into a generalized-array positive, keeping special String controls negative.
old='''        for (name, descriptor) in [
            ("wrongDescriptor", "()Ljava/lang/String;"),
            ("wrongOwner", "()Lem27/Probe$Holder;"),
            ("effectful", "()Ljava/lang/String;"),
            ("extraReader", "()Ljava/lang/String;"),
        ] {
'''
new='''        // A fully proved char[] passed directly to another owner's constructor is now covered by
        // the general exact-operand certificate. The Java 8 String special case remains separate.
        let other_owner = inline_char_sites("wrongOwner", "()Lem27/Probe$Holder;", 8, None);
        let other_owner_site = other_owner
            .site_at_head(0)
            .expect("complete direct char[] argument to another owner");
        assert_eq!(other_owner_site.class, "em27/Probe$Holder");
        assert_eq!(other_owner_site.arguments.len(), 1);

        for (name, descriptor) in [
            ("wrongDescriptor", "()Ljava/lang/String;"),
            ("effectful", "()Ljava/lang/String;"),
            ("extraReader", "()Ljava/lang/String;"),
        ] {
'''
assert old in s
s=s.replace(old,new,1)
# Add direct fixture integration near existing String case.
needle='''    #[test]
    fn only_the_complete_direct_java8_string_char_array_is_embedded() {
'''
test='''    #[test]
    fn direct_array_constructor_arguments_are_composed_for_both_javac_legs() {
        let cases = [
            (
                "barePrimitive",
                "(I)LDirectArrayConstructorArguments$ByteSink;",
                "$ByteSink",
                1,
                0,
            ),
            (
                "bareReference",
                "(I)LDirectArrayConstructorArguments$ReferenceSink;",
                "$ReferenceSink",
                1,
                0,
            ),
            (
                "initializedPrimitive",
                "(I)LDirectArrayConstructorArguments$ByteSink;",
                "$ByteSink",
                1,
                0,
            ),
            (
                "initializedReference",
                "(I)LDirectArrayConstructorArguments$ReferenceSink;",
                "$ReferenceSink",
                1,
                0,
            ),
            (
                "nestedChildren",
                "(I)LDirectArrayConstructorArguments$MatrixSink;",
                "$MatrixSink",
                1,
                0,
            ),
            (
                "bareMultianewarray",
                "(II)LDirectArrayConstructorArguments$MatrixSink;",
                "$MatrixSink",
                1,
                0,
            ),
            (
                "constructedElements",
                "(I)LDirectArrayConstructorArguments$ElementSink;",
                "$ElementSink",
                1,
                2,
            ),
            (
                "twoArrayArguments",
                "(I)LDirectArrayConstructorArguments$PairSink;",
                "$PairSink",
                2,
                0,
            ),
        ];
        for (compiler, class) in [
            ("javac8", DIRECT_ARRAY_ARGUMENTS_JAVAC8),
            ("javac23", DIRECT_ARRAY_ARGUMENTS_JAVAC23),
        ] {
            for (name, descriptor, owner_suffix, argument_count, element_sites) in cases {
                let plan = direct_array_argument_sites(class, name, descriptor);
                let accepted: Vec<_> = plan
                    .sites
                    .iter()
                    .filter(|site| site.class.ends_with(owner_suffix))
                    .collect();
                assert_eq!(accepted.len(), 1, "{compiler}/{name}: direct outer site");
                assert_eq!(
                    accepted[0].arguments.len(),
                    argument_count,
                    "{compiler}/{name}: physical argument count"
                );
                assert!(
                    accepted[0].expression.contains(&accepted[0].constructor),
                    "{compiler}/{name}: constructor remains in the composed expression"
                );
                let actual_element_sites = plan
                    .sites
                    .iter()
                    .filter(|site| site.class.ends_with("$Element"))
                    .count();
                assert_eq!(
                    actual_element_sites, element_sites,
                    "{compiler}/{name}: pending constructed elements commit once"
                );
            }
        }
    }

'''+needle
assert needle in s
s=s.replace(needle,test,1)
(base/'init.rs').write_text(s)
