# Direct array constructor argument candidate

This is a private candidate only. It edits copies of `crates/jarde-java/src/init.rs`, `build.rs`, and `report.rs`; it does not modify the shared checkout and was not compiled or run.

## Change

`ArrayInitializers` already proves the complete array source set, final SSA value, sole consumer, child composition and handler facts. The candidate lets the existing `inline_argument_chain_bcis_metered` accept the constructor itself as the consumer when the final value occurs exactly once among the physical non-receiver operands. Intermediate factory consumers retain the existing argument-dependency check. Bare `newarray` and `multianewarray` keep the existing one-use fallback, now checking the exact physical operand value too. Existing source-window, statement/effect, handler-coverage, `single_use_atoms`, and array/element-site composition continue through the existing path. `argument_dependencies` is unchanged.

The Java 8 `String(char[])` branch was a strict subset over the same `ArrayInitializer`: exact final value and constructor consumer, `char[]` dimensions only, no children or local postfix, constant `Push` element producers, and exact equality between its sources and the full interval. The generalized path checks all initializer sources remain in the interval, exact final operand identity, sole-use evidence, statement effects and handler coverage. The old certificate had no distinct accepted shape, so the candidate removes it and uses one array boundary refusal. The frozen `em27/Probe` test keeps stored and mutation controls; complete wrong-owner, effectful String, `String(char[], int, int)`, factory-consumed, and older-release direct cases become positive. Its exception-boundary control keeps the generic inline-array refusal.

## Test coverage prepared

The `init.rs` test diff adds a two-compiler fixture pass for bare primitive/reference arrays, initialized primitive/reference arrays, nested arrays, bare multidimensional arrays, constructed array elements, two direct array parameters, another-owner char arrays, and direct/effectful String arrays. It checks one accepted outer constructor, physical argument count, source argument order, outer expression ownership, and two composed `Element` sites in the constructed-elements method. The existing String fixture test retains stored, write, extra-reader, wrong-descriptor, and handler controls, while complete wrong-owner, effectful, and older-release direct cases become positive. The helper test pins the exact direct consumer and interval. The existing indirect factory-array test remains, updated for the accessor's final-value argument.

The fixture include paths expect root's frozen inputs at `tests/fixtures/constructor-direct-array-arguments/{javac8,javac23}/classes/DirectArrayConstructorArguments.class`. Root has since confirmed these fixtures are frozen. The construction and array-composition facts no longer carry a Java release: the generic proof does not consult it. The existing runtime profiles retain their actual `java_release` selection. The `inline_char_sites` test helper no longer accepts a release argument or repeats an older-release check. Its unchanged `NEW.required_release() == None` assertion remains. The new `ArrayCompositionContext` test helper supplies `method` and `code`; ordinary `verify_metered` no longer destructures an unused release. The bare-allocation path also requires its single use to share the block named by the NewArray SSA definition. A same-constructor wrong-final-value callback is now explicitly refused.

## Files

- `candidate.patch` / `candidate-v3.patch` — latest unified diff against the unchanged shared source. `candidate-v2-final.patch` retains v2.
- `candidate-v1.patch` — retained first draft, superseded by v2.
- `crates/jarde-java/src/init.rs`, `build.rs`, and `report.rs` — full private candidate copies.

Original shared-file SHA-256 at patch generation:

- `init.rs`: `85498c73526796a9e8abc281c4c8a8c10df93e0f05e1a2fcbcf810b3e4c93853`
- `build.rs`: `76f3e5d64e97456aa4f15d2c6e3c85fd0336737f23100c2cc501b83fb798baf0`


Original shared `report.rs` SHA-256: `7b44b8e59ba21b3e462ecaf8a86a05ae4685fe14a10925df96f7ec02579fc358`. This v3 candidate has only been statically inspected; it has not been compiled or executed.
