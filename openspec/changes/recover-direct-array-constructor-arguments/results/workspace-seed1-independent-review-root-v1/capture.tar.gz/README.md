# Independent seed 1 workspace receipt review

`review.json` independently checks `/private/tmp/jarde-direct-array-workspace-seed1-root-v2-20261018/execution.json` using Python `-B`. It reads closed receipt files and source pins only; it does not call the existing acceptor or execute Cargo, JDK, CLI, Git, or network operations.

The receipt has 100 test batches and 381 inventory targets. All 206 raw stdout/stderr streams, including format, metadata, test batches, and clean, match their recorded byte lengths and SHA-256 pins. The metadata file also matches its command output and pin. All commands exited 0 with no guard stop. The 3,037 recorded source pins match the current source bytes, and the recorded before/after maps agree.

For each batch, the review independently parses test compiler-artifact records, stderr `Running` executable paths, stdout `running N tests` blocks, each full test-name outcome, and the summary. It binds each ordered harness block to the corresponding actual `Running` executable, checks the block counts against its test names and summary, and verifies the resulting 381 target identities cover the receipt inventory exactly once. Independent totals are 3,707 passed, 0 failed, and 98 ignored; each target's names and counts are preserved in `review.json`.

The critical test check scans all 100 raw stdout streams as one aggregate and retains no batch assignment. The three direct-array library leaves, the direct-array class-source and stop tests, the constructed-array dependency test, and the original TestFinally3 test all appear with `ok`. The pre-cancel function name appears twice globally because the direct-array and exception-only stop integration files each define that same name; both outcomes are `ok`.

One receipt bookkeeping detail is recorded separately: `executed_targets` follows Cargo compiler-artifact order, and `observed_counts` follows the stdout summary sequence (100/100 batches). Those saved target/count vectors differ from the independently reconstructed raw stderr `Running` order in 92 batches. The review therefore records the direct `Running`-to-harness association from raw streams rather than treating the saved vector as its source of truth. This order difference does not change the receipt-wide totals or test-name outcomes.

The receipt records successful final `cargo clean` and `target_absent_after_clean: true`. Root reports a later P5 build is currently recreating `target/`; this review does not inspect or alter that directory.
