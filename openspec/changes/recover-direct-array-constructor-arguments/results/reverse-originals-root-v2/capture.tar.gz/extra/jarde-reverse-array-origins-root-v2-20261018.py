from pathlib import Path
import json,os,importlib.util,shutil,struct
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');PREP=Path('/private/tmp/jarde-reverse-array-order-prep-20261018');OUT=Path('/private/tmp/jarde-reverse-array-inputs-root-v2-20261018');assert not(ROOT/'target').exists();OUT.mkdir();(OUT/'raw').mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','cmp');g=load(ROOT/c.GUARD_REL,'guard');scan=load(ROOT/c.SCANNER_REL,'scan');assert c.sha(ROOT/c.GUARD_REL)==c.GUARD_SHA256 and c.sha(ROOT/c.SCANNER_REL)==c.SCANNER_SHA256;g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:scan.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
jdks,jdkpin=c.configured_jdks(ROOT/c.DEFAULT_JDK_MANIFEST_REL,c.DEFAULT_JDK_MANIFEST_SHA256)
for group,name in [('source','ReverseArrayOrder.java'),('driver','ReverseArrayOrderDriver.java')]:shutil.copyfile(PREP/group/name,OUT/name)
rewrite=OUT/'rewrite_swap.py';s=(PREP/'tools/rewrite_swap.py').read_text().replace('updated = data[:code_start + invoke] + b"\\x5f" + data[code_start + invoke:]','updated = bytearray(data[:code_start + invoke] + b"\\x5f" + data[code_start + invoke:])').replace('return updated','return bytes(updated)');assert 'updated = bytearray(' in s;rewrite.write_text(s)
rew=load(rewrite,'rew');rows=[];r={'status':'running','source':c.pin(OUT/'ReverseArrayOrder.java'),'driver':c.pin(OUT/'ReverseArrayOrderDriver.java'),'rewriter':c.pin(rewrite),'jdk':jdkpin,'commands':rows,'classes':[],'oracles':[],'jarde_cells':[]};c.write_json(OUT/'execution.json',r)
def cmd(argv,leg,label):
 env=c.clean_env(dict(os.environ),jdks[leg]);env.update(g.ENV_VALUES);env.pop('RUST_MIN_STACK',None);row=g.run_command(len(rows)+1,[str(x) for x in argv],env);row['label']=label;rows.append(row);c.write_json(OUT/'execution.json',r);assert row['guard_stop'] is None;return row
for leg in ['javac8','javac23']:
 flags=['-source','8','-target','8'] if leg=='javac8' else ['--release','8'];d=OUT/leg/'natural';d.mkdir(parents=True);empty=OUT/leg/'empty';empty.mkdir();driver=OUT/leg/'driver';driver.mkdir()
 for name,dest in [('ReverseArrayOrder.java',d),('ReverseArrayOrderDriver.java',driver)]:
  row=cmd([jdks[leg]['tools']['javac'],*flags,'-g:none','-proc:none','-encoding','UTF-8','-sourcepath',empty,'-classpath',empty,'-d',dest,OUT/name],leg,leg+'-'+name);assert row['exit_code']==0
 original=d/'ReverseArrayOrder.class';swap=OUT/leg/'swapped/ReverseArrayOrder.class';swap.parent.mkdir();swap.write_bytes(rew.rewrite(original.read_bytes()));a=c.parse_class(original);b=c.parse_class(swap);assert a.keys()==b.keys()
 for ma,mb in zip(a['methods'],b['methods']):
  if ma['name']=='make':
   assert len(bytes.fromhex(mb['code']['code_hex']))==len(bytes.fromhex(ma['code']['code_hex']))+1 and len(mb['code']['bcis'])==len(ma['code']['bcis'])+1
  else:assert ma==mb
 r['classes'].append({'compiler':leg,'natural':c.pin(original),'swapped':c.pin(swap),'natural_facts':a,'swapped_facts':b});c.write_json(OUT/'execution.json',r)
 for mode in ['natural','swapped']:
  target=OUT/leg/mode;expected='reverse-array:'+mode+',trace=12,left='+('1,right=2' if mode=='natural' else '2,right=1')+'\n'
  for runtime in ['javac8','javac23']:
   row=cmd([jdks[runtime]['tools']['java'],'-Xverify:all','-cp',driver,'ReverseArrayOrderDriver',target,mode],runtime,leg+'-'+mode+'-'+runtime);assert row['exit_code']==0 and c.command_artifact(row,'stdout')==expected.encode() and c.command_artifact(row,'stderr')==b'';r['oracles'].append({'compiler':leg,'mode':mode,'runtime':runtime,'command':row['index'],'stdout':row['streams']['stdout']});c.write_json(OUT/'execution.json',r)
  for cli in [Path('/private/tmp/jarde-exception-only-final-focused-root-v3-20261018/candidate-cli'),Path('/private/tmp/jarde-direct-array-focused-root-v2-20261018/candidate-cli')]:
   tag=c.sha(cli)[:12];row=cmd([cli,'class-source','--input',target/'ReverseArrayOrder.class','--class','ReverseArrayOrder','--policy','single-class','--release','8','--evidence','all','--format','json'],'javac23',leg+'-'+mode+'-'+tag);assert row['exit_code'] in (0,4);raw=c.command_artifact(row,'stdout');doc=json.loads(raw);dest=OUT/'jarde'/leg/mode/tag;dest.mkdir(parents=True);(dest/'report.json').write_bytes(raw);(dest/'ReverseArrayOrder.java').write_text(doc['text']);r['jarde_cells'].append({'compiler':leg,'mode':mode,'cli':c.pin(cli),'command':row['index'],'source':c.pin(dest/'ReverseArrayOrder.java')});c.write_json(OUT/'execution.json',r)
r['status']='valid original and swap bytecode oracles captured; CLI review pending';r['target_absent']=not(ROOT/'target').exists();assert r['target_absent'];c.write_json(OUT/'execution.json',r);print(r['status'],len(rows))
