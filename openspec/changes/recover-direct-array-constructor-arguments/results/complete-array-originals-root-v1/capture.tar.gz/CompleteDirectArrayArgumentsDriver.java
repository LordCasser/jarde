import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

/** Java 8 runtime oracle; it has no compile-time dependency on the fixture. */
public final class CompleteDirectArrayArgumentsDriver {
    private static final String TARGET = "CompleteDirectArrayArguments";

    private CompleteDirectArrayArgumentsDriver() {}

    public static void main(String[] args) throws Exception {
        require(args.length == 1, "usage: CompleteDirectArrayArgumentsDriver <target-class-directory>");
        File targetDir = new File(args[0]).getCanonicalFile();
        URL url = targetDir.toURI().toURL();
        try (URLClassLoader loader = new URLClassLoader(new URL[] { url },
                ClassLoader.getSystemClassLoader().getParent())) {
            Class<?> type = Class.forName(TARGET, true, loader);
            URL actual = type.getProtectionDomain().getCodeSource().getLocation();
            require(new File(actual.toURI()).getCanonicalFile().equals(targetDir),
                    "target loaded from unexpected CodeSource: " + actual);
            Oracle oracle = new Oracle(type);
            oracle.run();
        }
    }

    private static final class Oracle {
        private final Class<?> type;

        Oracle(Class<?> type) {
            this.type = type;
        }

        void run() throws Exception {
            reset();
            Object byteZero = call("bareBytes", new Class<?>[] { int.class }, 0);
            byte[] bytes0 = (byte[]) field(byteZero, "value");
            require(bytes0.length == 0 && intField("byteSinkCalls") == 1, "case 1");
            pass("case-1: dynamic byte array length zero");

            reset();
            Object bytePositive = call("bareBytes", new Class<?>[] { int.class }, 3);
            byte[] bytes3 = (byte[]) field(bytePositive, "value");
            require(bytes3.length == 3 && bytes3[0] == 0 && bytes3[1] == 0 && bytes3[2] == 0,
                    "case 2: byte array was not initialized to zero");
            require(intField("byteSinkCalls") == 1, "case 2: byte sink constructor count");
            pass("case-2: dynamic positive byte array length and zero initialization");

            reset();
            expect("java.lang.NegativeArraySizeException", null, () -> call("bareBytes", new Class<?>[] { int.class }, -1));
            require(intField("byteSinkCalls") == 0, "case 3: byte sink constructor ran after negative length");
            pass("case-3: negative byte length throws before sink construction");

            reset();
            Object refZero = call("bareReferences", new Class<?>[] { int.class }, 0);
            Object[] refs0 = (Object[]) field(refZero, "value");
            require(refs0.length == 0 && intField("referenceSinkCalls") == 1, "case 4");
            pass("case-4: dynamic reference array length zero");

            reset();
            Object refPositive = call("bareReferences", new Class<?>[] { int.class }, 2);
            Object[] refs2 = (Object[]) field(refPositive, "value");
            require(refs2.length == 2 && refs2[0] == null && refs2[1] == null,
                    "case 5: reference array was not initialized to null");
            pass("case-5: dynamic positive reference array length and null initialization");

            reset();
            expect("java.lang.NegativeArraySizeException", null,
                    () -> call("bareReferences", new Class<?>[] { int.class }, -1));
            require(intField("referenceSinkCalls") == 0,
                    "case 6: reference sink constructor ran after negative length");
            pass("case-6: negative reference length throws before sink construction");

            reset();
            setInt("failAt", 1);
            expect("java.lang.IllegalStateException", "mark-1", () -> call("markedLengthFailureStopsLaterWork"));
            require(intField("trace") == 1, "case 7: later argument was evaluated");
            require(intField("evaluationSinkCalls") == 0,
                    "case 7: constructor ran after effectful array length threw");
            pass("case-7: throwing effectful length skips later argument and constructor");

            reset();
            Object intsObject = call("initializedPrimitive");
            int[] ints = (int[]) field(intsObject, "value");
            require(ints.length == 2 && ints[0] == 1 && ints[1] == 2 && intField("trace") == 12,
                    "case 8: primitive initializer order/content");
            pass("case-8: initialized primitive array preserves element order");

            reset();
            Object initializedRefsObject = call("initializedReferences");
            Object[] initializedRefs = (Object[]) field(initializedRefsObject, "value");
            require(initializedRefs.length == 2 && "left".equals(initializedRefs[0])
                    && "right".equals(initializedRefs[1]), "case 9: reference initializer content");
            pass("case-9: initialized reference array preserves element values");

            reset();
            Object nestedObject = call("nestedChildren");
            int[][] nested = (int[][]) field(nestedObject, "value");
            require(nested.length == 2 && nested[0].length == 2 && nested[1].length == 1,
                    "case 10: nested dimensions");
            require(nested[0][0] == 7 && nested[0][1] == 8 && nested[1][0] == 9
                    && intField("trace") == 789, "case 10: nested child contents/order");
            pass("case-10: nested child arrays preserve dimensions and order");

            reset();
            Object multiObject = call("bareMultidimensional", new Class<?>[] { int.class, int.class }, 2, 3);
            int[][] multi = (int[][]) field(multiObject, "value");
            require(multi.length == 2 && multi[0].length == 3 && multi[1].length == 3,
                    "case 11: bare multidimensional dimensions");
            require(multi[0][0] == 0 && multi[0][1] == 0 && multi[0][2] == 0
                    && multi[1][0] == 0 && multi[1][1] == 0 && multi[1][2] == 0,
                    "case 11: bare multidimensional values");
            pass("case-11: bare multidimensional allocation");

            reset();
            Object elementsObject = call("constructedElements");
            Object[] elements = (Object[]) field(elementsObject, "value");
            require(elements.length == 3 && intField("trace") == 345,
                    "case 12: constructed element count/order");
            require(elementValue(elements[0]) == 3 && elementValue(elements[1]) == 4
                    && elementValue(elements[2]) == 5 && intField("elementCtorCalls") == 3
                    && intField("elementSinkCalls") == 1, "case 12: constructed elements");
            pass("case-12: constructed reference elements preserve order");

            reset();
            Object pair = call("twoArrayArguments");
            byte[] pairBytes = (byte[]) field(pair, "bytes");
            Object[] pairObjects = (Object[]) field(pair, "objects");
            require(intField("trace") == 56, "case 13: constructor argument evaluation was not left-to-right");
            require(pairBytes == staticField("observedBytes") && pairObjects == staticField("observedObjects"),
                    "case 13: constructor did not preserve array argument identity");
            require(pairBytes.length == 1 && pairBytes[0] == 5 && pairObjects.length == 1
                    && elementValue(pairObjects[0]) == 6 && intField("elementCtorCalls") == 1
                    && intField("pairSinkCalls") == 1, "case 13: array arguments content/count");
            pass("case-13: multiple array arguments evaluate left-to-right and preserve identity");

            reset();
            setInt("ctorFailAt", 4);
            expect("java.lang.IllegalArgumentException", "element-ctor-4", () -> call("constructedElements"));
            require(intField("trace") == 34 && intField("elementCtorCalls") == 2,
                    "case 14: work after throwing element constructor ran");
            require(intField("elementSinkCalls") == 0,
                    "case 14: parent sink constructor ran after element constructor failed");
            pass("case-14: throwing element constructor stops later elements and parent constructor");
        }

        private Object call(String name) throws Exception {
            return call(name, new Class<?>[0]);
        }

        private Object call(String name, Class<?>[] parameterTypes, Object... args) throws Exception {
            Method method = type.getDeclaredMethod(name, parameterTypes);
            method.setAccessible(true);
            return invoke(method, null, args);
        }

        private int elementValue(Object element) throws Exception {
            return ((Integer) field(element, "value")).intValue();
        }

        private Object field(Object receiver, String name) throws Exception {
            Field field = receiver.getClass().getDeclaredField(name);
            field.setAccessible(true);
            return field.get(receiver);
        }

        private Object staticField(String name) throws Exception {
            Field field = type.getDeclaredField(name);
            field.setAccessible(true);
            return field.get(null);
        }

        private int intField(String name) throws Exception {
            return ((Integer) staticField(name)).intValue();
        }

        private void setInt(String name, int value) throws Exception {
            Field field = type.getDeclaredField(name);
            field.setAccessible(true);
            field.setInt(null, value);
        }

        private void reset() throws Exception {
            setInt("trace", 0);
            setInt("failAt", -1);
            setInt("ctorFailAt", -1);
            setInt("byteSinkCalls", 0);
            setInt("referenceSinkCalls", 0);
            setInt("intSinkCalls", 0);
            setInt("matrixSinkCalls", 0);
            setInt("elementSinkCalls", 0);
            setInt("pairSinkCalls", 0);
            setInt("evaluationSinkCalls", 0);
            setInt("elementCtorCalls", 0);
            setStatic("observedBytes", null);
            setStatic("observedObjects", null);
        }

        private void setStatic(String name, Object value) throws Exception {
            Field field = type.getDeclaredField(name);
            field.setAccessible(true);
            field.set(null, value);
        }

        private void expect(String className, String message, ThrowingAction action) throws Exception {
            try {
                action.run();
            } catch (Throwable failure) {
                Throwable cause = unwrap(failure);
                require(cause.getClass().getName().equals(className),
                        "expected " + className + ", received " + cause.getClass().getName());
                if (message != null) {
                    require(message.equals(cause.getMessage()), "expected message " + message
                            + ", received " + cause.getMessage());
                }
                return;
            }
            throw new AssertionError("expected " + className + " but call returned normally");
        }

        private Throwable unwrap(Throwable failure) {
            if (failure instanceof InvocationTargetException && failure.getCause() != null) {
                return failure.getCause();
            }
            return failure;
        }

        private Object invoke(Method method, Object receiver, Object[] args) throws Exception {
            try {
                return method.invoke(receiver, args);
            } catch (InvocationTargetException e) {
                throw e;
            }
        }
    }

    private interface ThrowingAction {
        void run() throws Exception;
    }

    private static void require(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    private static void pass(String line) {
        System.out.println(line);
    }
}
