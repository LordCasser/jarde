public final class CompleteDirectArrayArguments {
    public static int trace;
    public static int failAt = -1;
    public static int ctorFailAt = -1;
    public static int byteSinkCalls;
    public static int referenceSinkCalls;
    public static int intSinkCalls;
    public static int matrixSinkCalls;
    public static int elementSinkCalls;
    public static int pairSinkCalls;
    public static int evaluationSinkCalls;
    public static int elementCtorCalls;
    public static byte[] observedBytes;
    public static Object[] observedObjects;

    private CompleteDirectArrayArguments() {}

    private static int append(int digit) {
        trace = trace * 10 + digit;
        if (failAt == digit) {
            throw new IllegalStateException("mark-" + digit);
        }
        return digit;
    }

    private static byte appendByte(int digit) {
        trace = trace * 10 + digit;
        if (failAt == digit) {
            throw new IllegalStateException("mark-" + digit);
        }
        return (byte) digit;
    }

    private static int markedLength(int digit, int length) {
        append(digit);
        return length;
    }

    public static final class ByteSink {
        public final byte[] value;
        ByteSink(byte[] value) {
            byteSinkCalls++;
            this.value = value;
        }
    }

    public static final class ReferenceSink {
        public final Object[] value;
        ReferenceSink(Object[] value) {
            referenceSinkCalls++;
            this.value = value;
        }
    }

    public static final class IntSink {
        public final int[] value;
        IntSink(int[] value) {
            intSinkCalls++;
            this.value = value;
        }
    }

    public static final class MatrixSink {
        public final int[][] value;
        MatrixSink(int[][] value) {
            matrixSinkCalls++;
            this.value = value;
        }
    }

    public static final class ElementSink {
        public final Element[] value;
        ElementSink(Element[] value) {
            elementSinkCalls++;
            this.value = value;
        }
    }

    public static final class PairSink {
        public final byte[] bytes;
        public final Object[] objects;
        PairSink(byte[] bytes, Object[] objects) {
            pairSinkCalls++;
            this.bytes = bytes;
            this.objects = objects;
            observedBytes = bytes;
            observedObjects = objects;
        }
    }

    public static final class EvaluationSink {
        public final byte[] bytes;
        public final int marker;
        EvaluationSink(byte[] bytes, int marker) {
            evaluationSinkCalls++;
            this.bytes = bytes;
            this.marker = marker;
        }
    }

    public static final class Element {
        public final int value;
        Element(int value) {
            elementCtorCalls++;
            if (ctorFailAt == value) {
                throw new IllegalArgumentException("element-ctor-" + value);
            }
            this.value = value;
        }
    }

    public static ByteSink bareBytes(int length) {
        return new ByteSink(new byte[length]);
    }

    public static ReferenceSink bareReferences(int length) {
        return new ReferenceSink(new Object[length]);
    }

    public static EvaluationSink markedLengthFailureStopsLaterWork() {
        return new EvaluationSink(new byte[markedLength(1, 2)], append(2));
    }

    public static IntSink initializedPrimitive() {
        return new IntSink(new int[] { append(1), append(2) });
    }

    public static ReferenceSink initializedReferences() {
        return new ReferenceSink(new Object[] { "left", "right" });
    }

    public static MatrixSink nestedChildren() {
        return new MatrixSink(new int[][] {
            new int[] { append(7), append(8) },
            new int[] { append(9) }
        });
    }

    public static MatrixSink bareMultidimensional(int rows, int columns) {
        return new MatrixSink(new int[rows][columns]);
    }

    public static ElementSink constructedElements() {
        return new ElementSink(new Element[] {
            new Element(append(3)),
            new Element(append(4)),
            new Element(append(5))
        });
    }

    public static PairSink twoArrayArguments() {
        return new PairSink(
            new byte[] { appendByte(5) },
            new Object[] { new Element(append(6)) }
        );
    }
}
