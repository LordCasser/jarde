# Complete direct-array constructor-argument positive fixture

These are new self-contained sources; they do not derive from or trim Jarde output. `CompleteDirectArrayArguments.java` contains the whole class and every helper/constructor needed to compile it. It intentionally has no `String`-specific negative case and no assertion inside the fixture. The separate Java 8-compatible `CompleteDirectArrayArgumentsDriver.java` has no compile-time reference to the fixture. It loads the target from the one class directory passed as its only argument through an isolated `URLClassLoader` and asserts that the target's `ProtectionDomain`/`CodeSource` resolves to that exact directory.

The fixture exposes `trace`, `failAt`, and `ctorFailAt` and simple constructor counters for external observation. `append` / `appendByte` append a digit before optionally throwing `IllegalStateException("mark-" + digit)`. `Element` increments its call counter before optionally throwing `IllegalArgumentException("element-ctor-" + value)`. The effectful array length is `markedLength(1, 2)` inside the first constructor argument; setting `failAt=1` must prevent evaluation of the following `append(2)` argument and prevent `EvaluationSink` construction. No target helper uses a fallback branch.

The driver's fixed successful stdout is exactly:

```text
case-1: dynamic byte array length zero
case-2: dynamic positive byte array length and zero initialization
case-3: negative byte length throws before sink construction
case-4: dynamic reference array length zero
case-5: dynamic positive reference array length and null initialization
case-6: negative reference length throws before sink construction
case-7: throwing effectful length skips later argument and constructor
case-8: initialized primitive array preserves element order
case-9: initialized reference array preserves element values
case-10: nested child arrays preserve dimensions and order
case-11: bare multidimensional allocation
case-12: constructed reference elements preserve order
case-13: multiple array arguments evaluate left-to-right and preserve identity
case-14: throwing element constructor stops later elements and parent constructor
```

The checks exercise: byte/reference lengths 0, positive and negative; default primitive/reference initialization; left-to-right initialized elements; nested child arrays; bare `new int[rows][columns]`; array elements built by `Element` constructors; two direct array-valued constructor arguments whose distinct effects yield trace `56`; `PairSink` records each received reference internally and the driver compares its fields by `==` to those exact references; and both effectful-length and element-constructor exceptions, including that later work and the enclosing constructor are skipped. This is prepared only; no compiler or JVM was run.

## v2 review adjustments

The caller of `twoArrayArguments()` now passes only `new byte[] { ... }` and `new Object[] { ... }` as the two `PairSink` arguments. `PairSink` stores the received parameters in the public instance fields and records the same references in the public observation fields from inside its constructor, so the call-site array expressions have no extra assignment consumers. The driver compares the `PairSink` fields with those recorded references using `==`. `elementValue` returns primitive `int` via explicit `Integer.intValue()`, so every element comparison is a numeric comparison rather than `Object == int`.

Static Java 8 type/varargs review: no-argument reflective calls pass an empty `Class<?>[]` and empty `Object[]`; argument calls pass boxed values through the `Object...` parameter and forward that array to `Method.invoke`; the exception-check lambdas use method-invocation statement expressions compatible with the void `ThrowingAction` interface. No compiler or JVM was invoked.
