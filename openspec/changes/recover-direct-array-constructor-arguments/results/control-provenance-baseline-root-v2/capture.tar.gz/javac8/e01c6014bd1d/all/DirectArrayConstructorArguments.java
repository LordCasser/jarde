// jarde: presentation of `DirectArrayConstructorArguments` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class DirectArrayConstructorArguments extends java.lang.Object {
    private static int trace;

    private DirectArrayConstructorArguments() {
        // @method <init>()V
        // @declaration a constructor of `DirectArrayConstructorArguments`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    private static int mark(int arg0) {
        // @method mark(I)I
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        DirectArrayConstructorArguments.trace = DirectArrayConstructorArguments.trace * 10 + arg0;
        return arg0;
    }

    private static byte markByte(int arg0) {
        // @method markByte(I)B
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        DirectArrayConstructorArguments.trace = DirectArrayConstructorArguments.trace * 10 + arg0;
        return (byte) arg0;
    }

    public static ByteSink barePrimitive(int arg0) {
        // @method barePrimitive(I)LDirectArrayConstructorArguments$ByteSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new ByteSink(new byte[arg0]);
    }

    public static ReferenceSink bareReference(int arg0) {
        // @method bareReference(I)LDirectArrayConstructorArguments$ReferenceSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new ReferenceSink(new java.lang.Object[arg0]);
    }

    public static IntSink initializedPrimitive() {
        // @method initializedPrimitive()LDirectArrayConstructorArguments$IntSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new IntSink(new int[]{mark(1), mark(2)});
    }

    public static ReferenceSink initializedReference() {
        // @method initializedReference()LDirectArrayConstructorArguments$ReferenceSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new ReferenceSink(new java.lang.Object[]{"left", "right"});
    }

    public static MatrixSink nestedChildren() {
        // @method nestedChildren()LDirectArrayConstructorArguments$MatrixSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new MatrixSink(new int[][]{new int[]{1, 2}, new int[]{3}});
    }

    public static MatrixSink bareMultianewarray(int arg0, int arg1) {
        // @method bareMultianewarray(II)LDirectArrayConstructorArguments$MatrixSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new MatrixSink(new int[arg0][arg1]);
    }

    public static ElementSink constructedElements() {
        // @method constructedElements()LDirectArrayConstructorArguments$ElementSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new ElementSink(new Element[]{new Element(mark(3)), new Element(mark(4))});
    }

    public static PairSink twoArrayArguments() {
        // @method twoArrayArguments()LDirectArrayConstructorArguments$PairSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        DirectArrayConstructorArguments.trace = 0;
        PairSink local0 = new PairSink(new byte[]{markByte(5)}, new java.lang.Object[]{new Element(mark(6))});
        if (DirectArrayConstructorArguments.trace != 56) {
            // @bytecode 49
            // the instruction at BCI 49 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
            // @bytecode 52
            // the instruction at BCI 52 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
            // @bytecode 77 74 71 68 62 65
            // the copy at BCI 52 has no proved local assignment
        } else {
            return local0;
        }
    }

    public static java.lang.String directStringCharArray() {
        // @method directStringCharArray()Ljava/lang/String;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new java.lang.String(new char[]{'a', 'b', 'c'});
    }

    public static java.lang.String stringOtherDescriptor() {
        // @method stringOtherDescriptor()Ljava/lang/String;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new java.lang.String(new char[]{'d', 'e', 'f'}, 0, 3);
    }

    public static java.lang.String directStringCharArrayEffectful() {
        // @method directStringCharArrayEffectful()Ljava/lang/String;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new java.lang.String(new char[]{'a', (char) mark(7), 'c'});
    }

    public static CharSink directOtherCharArrayOwner() {
        // @method directOtherCharArrayOwner()LDirectArrayConstructorArguments$CharSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new CharSink(new char[]{'x', 'y'});
    }

    public static final class Element extends java.lang.Object {
        final int value;

        Element(int arg1) {
            // @method <init>(I)V
            // @declaration a constructor of `DirectArrayConstructorArguments$Element`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }

    public static final class CharSink extends java.lang.Object {
        final char[] value;

        CharSink(char[] arg1) {
            // @method <init>([C)V
            // @declaration a constructor of `DirectArrayConstructorArguments$CharSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }

    public static final class PairSink extends java.lang.Object {
        final byte[] bytes;

        final java.lang.Object[] objects;

        PairSink(byte[] arg1, java.lang.Object[] arg2) {
            // @method <init>([B[Ljava/lang/Object;)V
            // @declaration a constructor of `DirectArrayConstructorArguments$PairSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.bytes = arg1;
            this.objects = arg2;
            return;
        }
    }

    public static final class ElementSink extends java.lang.Object {
        final Element[] value;

        ElementSink(Element[] arg1) {
            // @method <init>([LDirectArrayConstructorArguments$Element;)V
            // @declaration a constructor of `DirectArrayConstructorArguments$ElementSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }

    public static final class MatrixSink extends java.lang.Object {
        final int[][] value;

        MatrixSink(int[][] arg1) {
            // @method <init>([[I)V
            // @declaration a constructor of `DirectArrayConstructorArguments$MatrixSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }

    public static final class ReferenceSink extends java.lang.Object {
        final java.lang.Object[] value;

        ReferenceSink(java.lang.Object[] arg1) {
            // @method <init>([Ljava/lang/Object;)V
            // @declaration a constructor of `DirectArrayConstructorArguments$ReferenceSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }

    public static final class IntSink extends java.lang.Object {
        final int[] value;

        IntSink(int[] arg1) {
            // @method <init>([I)V
            // @declaration a constructor of `DirectArrayConstructorArguments$IntSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }

    public static final class ByteSink extends java.lang.Object {
        final byte[] value;

        ByteSink(byte[] arg1) {
            // @method <init>([B)V
            // @declaration a constructor of `DirectArrayConstructorArguments$ByteSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }
}
