// jarde: presentation of `DirectArrayConstructorArguments` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class DirectArrayConstructorArguments extends java.lang.Object {
    private static int trace;

    private DirectArrayConstructorArguments() {
        // @method <init>()V
        // @declaration a constructor of `DirectArrayConstructorArguments`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    private static int mark(int arg0) {
        // @method mark(I)I
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        DirectArrayConstructorArguments.trace = DirectArrayConstructorArguments.trace * 10 + arg0;
        return arg0;
    }

    private static byte markByte(int arg0) {
        // @method markByte(I)B
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        DirectArrayConstructorArguments.trace = DirectArrayConstructorArguments.trace * 10 + arg0;
        return (byte) arg0;
    }

    public static ByteSink barePrimitive(int arg0) {
        // @method barePrimitive(I)LDirectArrayConstructorArguments$ByteSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the instruction at BCI 0 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 10 7 5 4
        // the copy at BCI 3 has no proved local assignment
    }

    public static ReferenceSink bareReference(int arg0) {
        // @method bareReference(I)LDirectArrayConstructorArguments$ReferenceSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the instruction at BCI 0 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 11 8 5 4
        // the copy at BCI 3 has no proved local assignment
    }

    public static IntSink initializedPrimitive() {
        // @method initializedPrimitive()LDirectArrayConstructorArguments$IntSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the instruction at BCI 0 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 24 21 5 4 7 8 9 10 13 14 15 16 17 20
        // the copy at BCI 3 has no proved local assignment
    }

    public static ReferenceSink initializedReference() {
        // @method initializedReference()LDirectArrayConstructorArguments$ReferenceSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the instruction at BCI 0 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 21 18 5 4 8 9 10 12 13 14 15 17
        // the copy at BCI 3 has no proved local assignment
    }

    public static MatrixSink nestedChildren() {
        // @method nestedChildren()LDirectArrayConstructorArguments$MatrixSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the instruction at BCI 0 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 35 32 5 4 8 9 10 11 13 14 15 16 17 18 19 20 21 22 23 24 25 27 28 29 30 31
        // the copy at BCI 3 has no proved local assignment
    }

    public static MatrixSink bareMultianewarray(int arg0, int arg1) {
        // @method bareMultianewarray(II)LDirectArrayConstructorArguments$MatrixSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the instruction at BCI 0 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 13 10 6 4 5
        // the copy at BCI 3 has no proved local assignment
    }

    public static ElementSink constructedElements() {
        // @method constructedElements()LDirectArrayConstructorArguments$ElementSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the instruction at BCI 0 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 39 36 5 4 8 9 10 13 14 15 18 21 22 23 24 27 28 29 32 35
        // the copy at BCI 3 has no proved local assignment
    }

    public static PairSink twoArrayArguments() {
        // @method twoArrayArguments()LDirectArrayConstructorArguments$PairSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        DirectArrayConstructorArguments.trace = 0;
        // @bytecode 4
        // the instruction at BCI 4 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 7
        // the instruction at BCI 7 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 9
        // the array instruction at BCI 9 produces a value nothing in this body reads, so the instruction the bytecode runs has no place in the text
        // @bytecode 11 9
        // the instruction at BCI 11 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 17 9 14
        // the copy at BCI 11 has no proved local assignment
        // @bytecode 40 37 9 19 18 22 23 24 27 28 30 33 36
        // the copy at BCI 7 has no proved local assignment
        if (DirectArrayConstructorArguments.trace != 56) {
            // @bytecode 49
            // the instruction at BCI 49 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
            // @bytecode 52
            // the instruction at BCI 52 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
            // @bytecode 77 74 71 68 62 65
            // the copy at BCI 52 has no proved local assignment
        } else {
            // @bytecode 78 79
            // the statement at BCI 79 reads `local0`, and no statement of this body declared that local: the write that would have declared it was refused, so its name cannot be read here (P3 2b.2)
        }
    }

    public static java.lang.String directStringCharArray() {
        // @method directStringCharArray()Ljava/lang/String;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return new java.lang.String(new char[]{'a', 'b', 'c'});
    }

    public static java.lang.String stringOtherDescriptor() {
        // jarde: not recovered: the recovery run for `stringOtherDescriptor()Ljava/lang/String;` produced no statement (explanation only); the artifact's own comment lines are below
        // @method stringOtherDescriptor()Ljava/lang/String;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the instruction at BCI 0 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 5
        // the array instruction at BCI 5 produces a value nothing in this body reads, so the instruction the bytecode runs has no place in the text
        // @bytecode 7 5
        // the instruction at BCI 7 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 11 5
        // the copy at BCI 7 has no proved local assignment
        // @bytecode 12 5
        // the instruction at BCI 12 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 16 5
        // the copy at BCI 12 has no proved local assignment
        // @bytecode 17 5
        // the instruction at BCI 17 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 21 5
        // the copy at BCI 17 has no proved local assignment
        // @bytecode 27 24 5
        // the copy at BCI 3 has no proved local assignment
    }

    public static java.lang.String directStringCharArrayEffectful() {
        // jarde: not recovered: the recovery run for `directStringCharArrayEffectful()Ljava/lang/String;` produced no statement (explanation only); the artifact's own comment lines are below
        // @method directStringCharArrayEffectful()Ljava/lang/String;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the instruction at BCI 0 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 29 26 5 4 7 8 9 11 12 13 14 16 19 20 21 22 23 25
        // the copy at BCI 3 has no proved local assignment
    }

    public static CharSink directOtherCharArrayOwner() {
        // @method directOtherCharArrayOwner()LDirectArrayConstructorArguments$CharSink;
        // @declaration a static method of `DirectArrayConstructorArguments`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the instruction at BCI 0 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 20 17 5 4 7 8 9 11 12 13 14 16
        // the copy at BCI 3 has no proved local assignment
    }

    public static final class ByteSink extends java.lang.Object {
        final byte[] value;

        ByteSink(byte[] arg1) {
            // @method <init>([B)V
            // @declaration a constructor of `DirectArrayConstructorArguments$ByteSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }

    public static final class ReferenceSink extends java.lang.Object {
        final java.lang.Object[] value;

        ReferenceSink(java.lang.Object[] arg1) {
            // @method <init>([Ljava/lang/Object;)V
            // @declaration a constructor of `DirectArrayConstructorArguments$ReferenceSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }

    public static final class IntSink extends java.lang.Object {
        final int[] value;

        IntSink(int[] arg1) {
            // @method <init>([I)V
            // @declaration a constructor of `DirectArrayConstructorArguments$IntSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }

    public static final class MatrixSink extends java.lang.Object {
        final int[][] value;

        MatrixSink(int[][] arg1) {
            // @method <init>([[I)V
            // @declaration a constructor of `DirectArrayConstructorArguments$MatrixSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }

    public static final class ElementSink extends java.lang.Object {
        final Element[] value;

        ElementSink(Element[] arg1) {
            // @method <init>([LDirectArrayConstructorArguments$Element;)V
            // @declaration a constructor of `DirectArrayConstructorArguments$ElementSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }

    public static final class Element extends java.lang.Object {
        final int value;

        Element(int arg1) {
            // @method <init>(I)V
            // @declaration a constructor of `DirectArrayConstructorArguments$Element`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }

    public static final class PairSink extends java.lang.Object {
        final byte[] bytes;

        final java.lang.Object[] objects;

        PairSink(byte[] arg1, java.lang.Object[] arg2) {
            // @method <init>([B[Ljava/lang/Object;)V
            // @declaration a constructor of `DirectArrayConstructorArguments$PairSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.bytes = arg1;
            this.objects = arg2;
            return;
        }
    }

    public static final class CharSink extends java.lang.Object {
        final char[] value;

        CharSink(char[] arg1) {
            // @method <init>([C)V
            // @declaration a constructor of `DirectArrayConstructorArguments$CharSink`, member flags 0x0000
            // recovered from bytecode; presentation is not claimed to compile
            super();
            this.value = arg1;
            return;
        }
    }
}
