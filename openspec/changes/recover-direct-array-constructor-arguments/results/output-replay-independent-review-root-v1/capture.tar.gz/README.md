# Independent 40-request replay review

`review.json` is an independent read-only audit of `/private/tmp/jarde-direct-array-output-replay-root-v1-20261018/execution.json`. It was generated with Python `-B`; it reads the replay receipt, prior receipts, raw JSON streams, and input pins, and does not invoke the CLI, JDK, Git, or network.

All 40 replay commands are present with contiguous indices and no guard stop. Their exit codes are 36×0 and 4×4; every code matches the bound prior request. The four code-4 outcomes are the reverse-array controls (prior commands 2, 9, 36, and 43). The 40 cells bind exactly once to all 40 requests selected from prior receipts using the pinned old CLI SHA. Prior and replay command arguments after the CLI path match, and each class input path and SHA matches its cell.

All 80 replay streams and 80 corresponding prior streams match their recorded byte lengths and SHA-256 pins. For every cell, this review independently parses both JSON documents, recomputes the complete recursive value diff, and confirms its paths exactly match `all_observed_difference_paths`. All 40 generated source strings are byte-identical. Across all 1,255 actual JSON field changes, the only changed values are integer `usage.ir_items` (696 changes) and integer `usage.elapsed_millis` (559 changes); no other keys, types, list lengths, or values differ. The saved per-cell `class_text_byte_identical` and `non_usage_report_identical` claims also match this independent diff.

The receipt records an unchanged source closure and `target_absent: true` at replay completion. Root has indicated that `target/` currently exists because a later P5 build is in progress; this review does not inspect or change it.

The result is within the root's stated allowance for this replay: all report content outside the two named numeric usage fields is exactly equal, and every actual change is enumerated in `review.json`.
