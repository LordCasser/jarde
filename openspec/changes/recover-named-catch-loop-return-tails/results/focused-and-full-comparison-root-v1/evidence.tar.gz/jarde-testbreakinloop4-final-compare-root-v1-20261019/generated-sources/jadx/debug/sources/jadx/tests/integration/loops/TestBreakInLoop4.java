package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop4.class */
public class TestBreakInLoop4 extends IntegrationTest {

    /* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop4$TestCls.class */
    public static class TestCls {
        public double test(char c) {
            double m = 1.0d;
            for (int i = 0; i < 5; i++) {
                if (c != '.') {
                    if (c != 'a' && c != 'b') {
                        break;
                    }
                    m = 1024.0d;
                    break;
                }
            }
            return m;
        }

        public void check() {
            JadxAssertions.assertThat(test('.')).isEqualTo(1.0d);
            JadxAssertions.assertThat(test('a')).isEqualTo(1024.0d);
            JadxAssertions.assertThat(test('b')).isEqualTo(1024.0d);
            JadxAssertions.assertThat(test('c')).isEqualTo(1.0d);
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().doesNotContain(new CharSequence[]{"while"}).containsOne("for");
    }

    @Test
    public void testNoDebug() {
        noDebugInfo();
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().doesNotContain(new CharSequence[]{"while"}).containsOne("for");
    }
}
