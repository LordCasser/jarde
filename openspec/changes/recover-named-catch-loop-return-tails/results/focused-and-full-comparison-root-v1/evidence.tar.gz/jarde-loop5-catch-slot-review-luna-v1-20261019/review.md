# Read-only review: Loop5 catch-slot binding

Current integrated source pins:
- `build.rs`: `81c2a0b7b0c24f6ca0f1b6803f0abb421c07d5f06284abd1eb43b9be592cc331`
- `build/tests/loop5_catch_binding_tests.rs`: `195c7b14005606d38b3523ed2d8dbfcfb2b3573529c6206b9cac7dd5dd2cdfda`

## Result

I found no implementation boundary bug in the reviewed path. The exception is kept out of ordinary slot-write conflicts only when the write's `RegionPath` exactly selects a `catch_parameters` entry, that entry's slot equals the reused `LocalVariable` slot, the use BCI is the mapped handler BCI, the decoded operation stores to that slot, and the stored SSA value is `Phi { block: handler, slot: Stack(0) }` (`build.rs:2935-2949`). It then verifies the handler block's first SSA instruction is at the handler BCI, reads exactly that stack-0 Phi, and writes exactly the current local slot/current `written_value` (`2961-2979`). This prevents accepting a later handler-body assignment or a Phi from another block.

The map is created from each recovered `Region::Try` catch clause's own path, `parameter()`, and `handler()` (`build.rs:5259-5271`), and the normal production call passes that exact `RegionPaths.catch_parameters` map (`762-777`). Thus the slot exception is scoped to a recovered clause rather than inferred from type/slot resemblance. The existing `guard::handler_binding` uses the same handler-local stack-0 Phi contract and additionally requires a real handler row; here the recovered catch region is the trust boundary supplying the row-to-clause binding.

## Adversarial checks

The added negative test exercises absent/wrong lexical path, wrong handler block, wrong local slot, and non-handler Phi, requiring the ordinary conflicting-write result to remain (`loop5_catch_binding_tests.rs:92-171`). Those are real discriminating negative examples for the main false-attribution axes. The code itself also excludes non-entry stores by requiring `use_.bci == handler.bci()` and checking that the matching handler instruction is the block's first instruction.

Budgeting is bounded: each write use is charged and polled before the new decision branch (`build.rs:2916-2926`); the linear `SsaTable::block` lookup is preceded by a charge of `ssa.blocks().len() + 4`, then a poll (`2951-2963`). Cancellation/budget tests exist (`loop5_catch_binding_tests.rs:174-215`). The test uses a zero budget and therefore checks propagation at entry, not the new lookup's exact charge threshold.

## Remaining test boundary

No code fix is indicated from inspection. If tightening tests is desired, two narrow additional negatives would directly exercise checks that are currently enforced but not isolated: a fake handler `CanonicalBlockId` with the same BCI but a different canonical path (to prove exact block identity rather than BCI equality), and a same-path store use at a later BCI inside the handler (to prove the handler-entry-only gate). A charge-threshold test could also set a limit just below the incremental handler lookup charge. Cargo is active; I did not run tests or inspect raw outputs, so I make no runtime-pass claim.
