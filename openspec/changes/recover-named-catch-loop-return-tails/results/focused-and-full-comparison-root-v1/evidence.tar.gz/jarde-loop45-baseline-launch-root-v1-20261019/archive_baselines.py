from pathlib import Path
import hashlib,io,json,stat,tarfile
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');TMP=Path('/private/tmp');LAUNCH=TMP/'jarde-loop45-baseline-launch-root-v1-20261019'
DEST=ROOT/'openspec/evidence/java-syntax-2026-10-19/cf09-loop4-loop5-original-root-v1'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
assert load(LAUNCH/'execution.json')['status']=='both_collectors_closed_pending_review'
assert not (ROOT/'target').exists()
review={'status':'accepted_complete_baselines_with_two_recovery_gaps','product':'618b5e20f27f94ba28ea2f9e4310648718475f82','cli_sha256':'7e321a7f4fd6a029540ab169f79572c6ad83e74119900ac6d695290c9c055318','cases':{},'scope':'full original/JADX/Jarde observations accepted; not a recovery implementation or product acceptance','next':'same-run actual IR/Region probe before OpenSpec design; do not infer a shared cause from equal fallback codes'}
files={}
for num in (4,5):
 base=TMP/f'jarde-testbreakinloop{num}-baseline-root-v1-20261019';d=load(base/'execution.json')
 assert d['status']=='captured-pending-independent-review' and d['source_unchanged_finally'] and d['target_absent_finally']
 assert len(d['commands'])==46 and len(d['jarde_cells'])==8
 for cell in d['jarde_cells']:
  methods=cell['methods'];assert len(methods)==3
  test=next(x for x in methods if x['name']=='test');assert test['quality']=='fallback' and test['fallbacks']==['jre_region_uncovered_blocks']
  assert all(x['quality']=='structured' for x in methods if x['name']!='test')
 assert len(d['original_runtime'])==4 and all(x['exit_code']==0 for x in d['original_runtime'])
 comp=d['generated_source_compilations'];runs=d['generated_runtime'];assert len(comp)==20 and len(runs)==4
 assert all(x['kind']=='jadx' and x['matches_original_oracle'] for x in runs)
 assert sum(x['kind']=='jadx' and x['exit_code']==0 for x in comp)==2
 assert sum(x['kind']=='jarde' and x['exit_code']==0 for x in comp)==0
 review['cases'][str(num)]={'receipt_sha256':sha((base/'execution.json').read_bytes()),'commands':46,'raw_streams':92,'api_cells':8,'target_method_count':3,'test_quality':'fallback','fallback':'jre_region_uncovered_blocks','uncovered_bcis':[17,23,29] if num==4 else [14,23,106,39,88,46,53,60,67,74,81],'original_vms':4,'case_observations_per_original_and_jadx':16 if num==4 else 20,'check_invocations_per_original_and_jadx':4,'jarde_full_compile_attempts':16,'jarde_full_compile_successes':0,'jarde_vms':0,'jadx_full_compile_attempts':4,'jadx_full_compile_successes':2,'jadx_vms':4,'framework_boundary':'original/full JADX and Jarde JDK8 compile require major55 test harness; real check on JDK8 UnsupportedClassVersionError, JDK23 check pass','product_failure':'Jarde JDK23 full class has missing return because primary test is explanation-only','mapping_scope':'fallback quote anchors only, not structured mapping coverage'}
 for prefix,folder in [(f'loop{num}/actual',base),(f'loop{num}/prep-v1',TMP/f'jarde-testbreakinloop{num}-baseline-prep-luna-v1-20261019'),(f'loop{num}/prep-v2',TMP/f'jarde-testbreakinloop{num}-baseline-prep-luna-v2-20261019')]:
  for p in sorted(folder.rglob('*')):
   assert not p.is_symlink()
   if p.is_file():files[prefix+'/'+p.relative_to(folder).as_posix()]=p
 audit=TMP/('jarde-testbreakinloop4-baseline-audit-output-luna-v3-20261019' if num==4 else 'jarde-testbreakinloop5-baseline-review-root-v1-20261019');a=load(audit);assert a['status']=='independent-read-only-review' and a['default_all_text_maps_stable'];files[f'loop{num}/audit-review.json']=audit
for prefix,folder in [('loop4/audit-v3',TMP/'jarde-testbreakinloop4-baseline-audit-luna-v3-20261019'),('independent-review',TMP/'jarde-loop45-baseline-independent-review-luna-v1-20261019')]:
 for p in sorted(folder.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():files[prefix+'/'+p.relative_to(folder).as_posix()]=p
(LAUNCH/'root-review.json').write_text(json.dumps(review,indent=2)+'\n')
for p in sorted(LAUNCH.iterdir()):
 if p.is_file():files['root-launch-and-review/'+p.name]=p
for label,p in [('physical-parser.py',TMP/'jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py'),('compare.py',ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'),('guard.py',ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'),('target-size-scan.py',ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py')]:files['shared-tools/'+label]=p
assert not DEST.exists();DEST.mkdir();inventory=[]
with tarfile.open(DEST/'evidence.tar.gz','w:gz') as tar:
 for name,p in sorted(files.items()):
  b=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode);info=tarfile.TarInfo(name);info.size=len(b);info.mode=mode;info.mtime=0;tar.addfile(info,io.BytesIO(b));inventory.append({'path':name,'bytes':len(b),'mode':mode,'sha256':sha(b)})
with tarfile.open(DEST/'evidence.tar.gz','r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(inventory)
 for m,r in zip(members,inventory):assert m.isfile() and m.name==r['path'] and m.size==r['bytes'] and m.mode==r['mode'] and sha(tar.extractfile(m).read())==r['sha256']
(DEST/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
report={'status':'root_reopened_complete_loop4_loop5_baseline_payloads','payload_count':len(inventory),'payload_bytes':sum(r['bytes'] for r in inventory),'archive_bytes':(DEST/'evidence.tar.gz').stat().st_size,'archive_sha256':sha((DEST/'evidence.tar.gz').read_bytes()),'root_review_sha256':sha((LAUNCH/'root-review.json').read_bytes()),'scope':'both complete collectors and Python/raw audits closed before archive; all payload byte/mode/digests reopened; no CLI binary, external framework jars or target added'}
(DEST/'capture.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
