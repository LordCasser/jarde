from pathlib import Path
p=Path('/private/tmp/jarde-loop5-named-scope-v3-20261019/region.rs')
s=p.read_text()
needle='''    /// Prove one top-level header-tested loop branch whose external conditional body closes at
'''
helper='''    /// Validate the one ordinary named row allowed to own a protected loop. Exception edges are
    /// accounted individually here; callers still pass only normal edges to the route closure.
    fn named_loop_row_matches(&mut self, frame: &Frame, at: u32) -> Result<bool, StopReason> {
        let (Some(rows), Some(try_node)) = (frame.named_catch_rows.as_ref(), frame.own_try) else {
            return Ok(false);
        };
        let ([row], [canonical_row]) = (self.handlers, self.canonical.handler_rows()) else {
            return Ok(false);
        };
        let Some(try_id) = self.view.id_of(try_node) else {
            return Ok(false);
        };
        let work = self.handlers.len().saturating_add(self.canonical.handler_rows().len());
        charge(self.budget, CountedBudgetDimension::AnalysisSteps,
            u64::try_from(work).unwrap_or(u64::MAX), Some(at))?;
        poll(self.budget, Some(at))?;
        Ok(rows.len() == 1
            && rows.contains(&row.ordinal)
            && self.code.exception_handler_count == 1
            && self.code.exception_handlers.len() == 1
            && row.start_bci == try_id.bci()
            && row.start_bci < row.end_bci
            && row.catch_type_index.is_some()
            && canonical_row.ordinal() == row.ordinal
            && canonical_row.catch_type_index() == row.catch_type_index
            && canonical_row.handler_bci() == row.handler_bci
            && canonical_row.handler().is_some_and(|handler| handler.bci() == row.handler_bci)
)
    }

    /// Check all non-normal outgoing edges of one named-row owner without allowing them to become
    /// part of the normal-flow route certificate.
    fn named_loop_owner_edges_accounted(
        &mut self,
        owner: &CanonicalBlockId,
        frame: &Frame,
    ) -> Result<bool, StopReason> {
        if !self.named_loop_row_matches(frame, owner.bci())? {
            return Ok(false);
        }
        let ([row], [canonical_row]) = (self.handlers, self.canonical.handler_rows()) else {
            return Ok(false);
        };
        let work = self.canonical.edges().len();
        charge(self.budget, CountedBudgetDimension::AnalysisSteps,
            u64::try_from(work).unwrap_or(u64::MAX), Some(owner.bci()))?;
        for edge in self.canonical.edges() {
            poll(self.budget, Some(owner.bci()))?;
            if edge.from() != owner { continue; }
            match edge.kind() {
                CanonicalEdgeKind::Normal => {}
                CanonicalEdgeKind::Call { .. } | CanonicalEdgeKind::Return { .. } => return Ok(false),
                CanonicalEdgeKind::Exception { handler_ordinal } => {
                    if handler_ordinal != row.ordinal
                        || edge.to().bci() != row.handler_bci
                        || !self.exception_edge_takeable(owner, handler_ordinal)
                    { return Ok(false); }
                    let mut matching = false;
                    for site in self.canonical.throw_sites() {
                        poll(self.budget, Some(site.bci()))?;
                        if site.block() == owner && site.handlers().contains(&handler_ordinal) {
                            if site.bci() < row.start_bci || site.bci() >= row.end_bci { return Ok(false); }
                            matching = true;
                        }
                    }
                    if !matching || !self.exception_edge_accounted(owner, edge.to(), handler_ordinal, frame) {
                        return Ok(false);
                    }
                }
            }
        }
        let _ = canonical_row;
        Ok(true)
    }

    /// In a named try, the only side-body stay beyond the ordinary continue target is the unique
    /// natural latch itself. Its effects remain in the loop body; this certifies only its edge.
    fn is_named_natural_latch(
        &mut self,
        node: usize,
        header: usize,
        blocks: &BTreeSet<usize>,
        frame: &Frame,
    ) -> Result<bool, StopReason> {
        if !self.named_loop_row_matches(frame, self.view.id_of(node).map_or(0, CanonicalBlockId::bci))? {
            return Ok(false);
        }
        let Some(loop_of) = self.view.loop_entered_at(header) else { return Ok(false); };
        if loop_of.blocks() != blocks || loop_of.latches().as_slice() != [node]
            || self.view.successors(node) != [header]
        { return Ok(false); }
        let Some(id) = self.view.id_of(node) else { return Ok(false); };
        self.named_loop_owner_edges_accounted(id, frame)
    }

    /// For the exact proof branch, or the directly-preceding natural guard whose two arms are
    /// that branch and the certified latch, choose the latch as the loop-local join.
    fn loop_break_body_local_join(
        &self,
        node: usize,
        then_node: Option<usize>,
        else_node: Option<usize>,
        frame: &Frame,
    ) -> Option<usize> {
        let target = frame.loop_targets.last()?;
        let proof = target.break_body.as_ref()?;
        if node == proof.branch {
            return Some(proof.stay);
        }
        let loop_blocks = self.view.loop_entered_at(proof.header)?.blocks();
        if !loop_blocks.contains(&node) { return None; }
        let arms: BTreeSet<_> = [then_node?, else_node?].into_iter().collect();
        if arms != BTreeSet::from([proof.branch, proof.stay])
            || self.view.successors(node).iter().copied().collect::<BTreeSet<_>>() != arms
            || self.view.predecessors(proof.branch) != [node]
        { return None; }
        Some(proof.stay)
    }

'''
assert needle in s
s=s.replace(needle,helper+needle,1)
p.write_text(s)
