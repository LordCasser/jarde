from pathlib import Path
import hashlib, json

root = Path(__file__).parent
pins = json.loads((root / 'pins.json').read_text())
for item in pins['files']:
    candidate = (root / item['file']).read_bytes()
    base = (root / (item['file'] + '.base')).read_bytes()
    assert hashlib.sha256(base).hexdigest() == item['base_sha256']
    assert hashlib.sha256(candidate).hexdigest() == item['candidate_sha256']
assert 'loop5_return_tail_tests.rs' in (root / 'candidate.patch').read_text()
tests = (root / 'loop5_return_tail_tests.rs').read_text()
assert tests.count('#[ignore') == 0
for name in (
    'loop5_named_break_body_proof_binds_one_row_and_rejects_scope_drift',
    'loop5_try_level_candidate_refusal_restores_tentative_owners',
    'loop5_try_level_late_analysis_stop_restores_candidate_checkpoint',
    'loop5_full_try_owns_prefix_loop_and_return_tail_after_loop4_proof',
):
    assert name in tests
print('private source pins and acceptance-test markers verified')
