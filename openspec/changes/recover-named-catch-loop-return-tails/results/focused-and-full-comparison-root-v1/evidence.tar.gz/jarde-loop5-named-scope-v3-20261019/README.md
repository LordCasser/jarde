# Loop5 named-row scope v3 preparation

Private, unexecuted candidate. The shared checkout was read-only; `candidate.patch` is the exact unified diff and `.base` files preserve captured inputs. No Rust/Cargo/toolchain command was run.

## Scope

- Admit only the current ordinary `own_try + named_catch_rows` frame with one physical row, one canonical row, and matching handler metadata. Validate row instruction ownership separately from canonical exception-edge sources. Explain exception edges individually and pass only normal edges to the existing route closure/Kahn checks.
- Keep Loop5 `While`: assert `ForHeader` refuses, allow only unique natural latch 88 as the stay, retain it in the loop body, and choose it as join at branch 39 and exact directly-preceding guard 23 only when guard arms are `{branch, stay}` and branch 39's unique predecessor is 23.
- Reject canonical `Call` and `Return{subroutine}` edges for all candidate owners, including the return-tail proof. Enable the three previously ignored acceptance/rollback tests and add a frozen-reader commonproof positive plus metadata-drift and omitted exceptional-owner negatives.

Loop4's `ForHeader` and non-named behavior are untouched by the new join rule. `finite_loop_catch_tests.rs` is byte-identical to base.

## Exact file pins

- `region.rs`: +238/−15 lines; base/candidate SHA-256 `f2fc004ab7cce991f972dbfc68596828be5a5d50ce28fde74cf500a177c85cd3` / `89cdde464594df8afc78287f00f92a906a0e0072a4374d4076d058bd5fe3319b`.
- `finite_loop_catch_tests.rs`: +0/−0 lines; base/candidate SHA-256 `185779c3b981e185c03977c6ba4c897c3db1ac906c51bd0c6579a0edd58d44fc` / `185779c3b981e185c03977c6ba4c897c3db1ac906c51bd0c6579a0edd58d44fc`.
- `loop5_return_tail_tests.rs`: +100/−4 lines; base/candidate SHA-256 `ff73242e72759199978ede55be00d3dd1adb43cfb56964fcbf4cd0947f9f1501` / `d2cd3388967aa43ecd80b490b7274fc6782f631e5cfb612898e626de6f455c8b`.

## Validation

After review and integration, root can run the focused Loop45 IR probe and Loop5 module commands in `commands.json`. This preparation did not run them; results are unknown. `static_preflight.py` only verifies private source hashes and acceptance-test markers.
