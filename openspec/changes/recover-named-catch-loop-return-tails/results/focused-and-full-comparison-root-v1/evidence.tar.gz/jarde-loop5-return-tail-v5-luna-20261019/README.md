# Loop5 nested certified-arm v5 candidate

Private patch against the root-provided stable source snapshot, SHA256 `7835a0aafc80251ab8d8c90853d1b44a64daf4ab7952bfe8868b3277acdc0467`. No shared file was written and no Rust toolchain was run.

The closed stage trace shows branch 53 stops at its nested route: owners 67 and 74 were visited, while owner 81 was absent from the emitted regions. The existing certified root branch already uses `loop_body_sequence`; nested arms did not. The patch applies that same existing sequence collector only when the top LoopTarget matches the proof header and break target, the current branch is the proof root or an owner, and the selected walk entry is itself an owner. A selected exit leaf outside `proof.owners` remains handled by `region_at`, preserving its transfer/source location. Each certified sequence call is polled and charged by `owners.len()+1` before traversal.

The patch also makes the existing return-tail local edge gate reject Call/Return edges incident to an owner at either endpoint. This is a one-condition hardening requested after adversarial review; the complete named-scope edge proof remains unchanged. The pinned real Reader test already asserts full recovery and late-stop rollback, so no mirror test was added.

`candidate.patch` is the exact diff. `commands.json` lists the focused Reader gates for root execution. Preparation used Python `-B` static checks only.
