#!/usr/bin/env python3
"""Parse strict Loop5 extended driver receipts using the Python standard library."""
import argparse, base64, json, pathlib, sys

CASE_KEYS={'index','name','input_kind','input_label_b64','input_b64','result_b64','exception','exception_message_b64','exception_stack_b64','target_stdout_b64','after_kind','after_b64'}
CHECK_KEYS={'exception','exception_message_b64','exception_stack_b64','stdout_b64'}

def dec(s): return base64.b64decode(s, validate=True).decode('utf-8')
def parse_lines(lines, path='<input>'):
    rows=[]; check=None; seen_check=False
    for n,line in enumerate(lines,1):
        f=line.split()
        if not f: continue
        kind=f[0]
        if kind=='CASE' and seen_check: raise ValueError(f'{path}:{n}: CASE after CHECK')
        if kind=='CHECK':
            if seen_check: raise ValueError(f'{path}:{n}: duplicate CHECK')
            if len(rows)!=12: raise ValueError(f'{path}:{n}: CHECK before all 12 CASE records')
            seen_check=True
        elif kind!='CASE': raise ValueError(f'{path}:{n}: unknown record {kind!r}')
        d={}
        for item in f[1:]:
            if '=' not in item: raise ValueError(f'{path}:{n}: malformed field {item!r}')
            k,v=item.split('=',1)
            if k in d: raise ValueError(f'{path}:{n}: duplicate field {k!r}')
            d[k]=v
        expected=CASE_KEYS if kind=='CASE' else CHECK_KEYS
        if set(d)!=expected: raise ValueError(f'{path}:{n}: {kind} field set mismatch: missing={sorted(expected-set(d))} extra={sorted(set(d)-expected)}')
        if kind=='CASE':
            try: d['index']=int(d['index'])
            except ValueError: raise ValueError(f'{path}:{n}: invalid index')
            if d['input_kind'] not in ('string','null') or d['after_kind'] not in ('string','null'):
                raise ValueError(f'{path}:{n}: invalid input/after kind')
            for k in ('input_label_b64','result_b64','exception_message_b64','exception_stack_b64','target_stdout_b64'):
                d[k[:-4]]=dec(d[k])
            if d['input_kind']=='null':
                if d['input_b64']!='-': raise ValueError(f'{path}:{n}: null input must use input_b64=-')
                d['input']=None
            else: d['input']=dec(d['input_b64'])
            if d['after_kind']=='null':
                if d['after_b64']!='-': raise ValueError(f'{path}:{n}: null after must use after_b64=-')
                d['after']=None
            else: d['after']=dec(d['after_b64'])
            rows.append(d)
        else:
            check={'exception':d['exception'],'exception_message':dec(d['exception_message_b64']),
                   'exception_stack':dec(d['exception_stack_b64']),'stdout':dec(d['stdout_b64'])}
    if len(rows)!=12 or check is None: raise ValueError(f'{path}: expected 12 CASE then 1 CHECK; got {len(rows)} CASE and CHECK={check is not None}')
    if [r['index'] for r in rows]!=list(range(12)): raise ValueError(f'{path}: CASE indices are not exactly 0..11')
    return {'cases':rows,'check':check}

def validate_plan(observation, plan, path):
    expected=plan['cases']; rows=observation['cases']
    if len(expected)!=12: raise ValueError('plan must define 12 cases')
    for i,(r,e) in enumerate(zip(rows,expected)):
        if r['index']!=i or r['name']!=e['name']: raise ValueError(f'{path}: case {i} identity mismatch')
        want_kind='null' if e['input_kind']=='java-null' else 'string'
        if r['input_kind']!=want_kind or r['after_kind']!=want_kind: raise ValueError(f'{path}: case {i} input/after kind mismatch')
        want_label=e.get('display_sentinel',e.get('input'))
        if r['input_label']!=want_label: raise ValueError(f'{path}: case {i} label mismatch')
        if r['input']!=e.get('input') or r['after']!=e.get('input'): raise ValueError(f'{path}: case {i} input/after mismatch')
    if rows[10]['input_kind']!='null' or rows[10]['input'] is not None: raise ValueError(f'{path}: null case not encoded as null')

def case_projection(x):
    return [{k:r[k] for k in ('index','name','input_kind','input_label','input','result','exception','exception_message','exception_stack','target_stdout','after_kind','after')} for r in x['cases']]
def check_semantics(x): return {k:x['check'][k] for k in ('exception','exception_message','stdout')}

def encoded(s): return base64.b64encode(s.encode()).decode()
def self_test(plan):
    lines=[]
    for e in plan['cases']:
        null=e['input_kind']=='java-null'; value=e['input']; label=e.get('display_sentinel',value)
        lines.append('CASE index={} name={} input_kind={} input_label_b64={} input_b64={} result_b64={} exception=none exception_message_b64= exception_stack_b64= target_stdout_b64= after_kind={} after_b64={}'.format(
            e['index'],e['name'],'null' if null else 'string',encoded(label),'-' if null else encoded(value),encoded('return=0'),'null' if null else 'string','-' if null else encoded(value)))
    lines.append('CHECK exception=none exception_message_b64= exception_stack_b64= stdout_b64=')
    valid=parse_lines(lines); validate_plan(valid,plan,'synthetic')
    bad=[]
    bad.append(lines[:3]+[lines[3].replace('input_kind=string', 'input_kind=other', 1)]+lines[4:])
    bad.append([lines[0].replace(' name=', ' index=0 name=',1)]+lines[1:])
    bad.append(lines[:5]+[lines[-1]]+lines[5:])
    bad.append([lines[0].replace(' input_kind=string',' input_kind=string input_kind=null')]+lines[1:])
    for i,candidate in enumerate(bad):
        try: parse_lines(candidate,f'<negative-{i}>')
        except ValueError: continue
        raise AssertionError(f'negative parser case {i} was accepted')
    print('self-test passed: valid 12-row plan, unknown kind, duplicate field, CHECK ordering, and duplicate field rejection')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('receipts',nargs='*'); ap.add_argument('--against'); ap.add_argument('--out'); ap.add_argument('--self-test',action='store_true'); ap.add_argument('--plan')
    a=ap.parse_args(); pp=pathlib.Path(a.plan) if a.plan else pathlib.Path(__file__).parent/'plan/commands.json'; plan=json.loads(pp.read_text())
    if a.self_test: self_test(plan); return 0
    if not a.out or not a.receipts: ap.error('receipt mode requires --out and one or more receipt files')
    parsed={}
    for item in a.receipts:
        parsed[item]=parse_lines(pathlib.Path(item).read_text().splitlines(),item); validate_plan(parsed[item],plan,item)
    ref=parse_lines(pathlib.Path(a.against).read_text().splitlines(),a.against) if a.against else None
    if ref: validate_plan(ref,plan,a.against)
    result={'schema':'jarde.loop5.extended-cases.results.v2','status':'parsed','receipts':parsed}
    if ref:
        result['comparison']={p:{'cases_match':case_projection(v)==case_projection(ref),
          'check_semantics_match':check_semantics(v)==check_semantics(ref),
          'check_semantics':check_semantics(v),'check_stack_preserved':v['check']['exception_stack']} for p,v in parsed.items()}
    pathlib.Path(a.out).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    return 0
if __name__=='__main__': sys.exit(main())
