# Loop4 proved break-body private patch — v2

This is a fresh private revision for OpenSpec `recover-proved-loop-break-branch-bodies` tasks 2.1/2.2. The shared checkout remains read-only. No Rust/JVM/JADX/Jarde toolchain, Git, Cargo, CLI, network, Atlas write, formatter, or test was run while preparing it. v1 remains frozen and unchanged.

The implementation preserves the existing natural-loop set and ForHeader proof. `LoopBreakBodyProof` records the exact header, branch, external entry, in-loop stay, break exit, and external owners. `Walker::loop_break_branch_body` admits only one unique candidate in the scoped unprotected context. A finite worklist collects each owner once; it does not make a second cycle decision. The single acyclicity gate is the budgeted, cancellation-aware Kahn check, using the same helper for the real route and cycle-negative test. Canonical closure, predecessor agreement with `NormalFlowView`, direct goto transfer origins, and natural/visited/scope collision checks remain required.

The certificate extends only the current loop body scope and expected owners. `proved_break_body_join` is selected before the generic join path. A complete Walker checkpoint is charged before cloning; rollback moves the saved sets back and does not refund budget. Candidate collection, edge closure, Kahn traversal, predecessor projection, expected/actual owner construction, and final publication are budgeted/polled. A failed coverage/owner check restores the checkpoint before fallback.

The Reader-backed test names are:

- `reader_recovers_complete_loop4_body_for_both_debug_profiles`
- `reader_proof_owns_only_the_closed_route_and_refuses_occupied_or_scoped_candidates`
- `reader_late_implicit_latch_stop_restores_trial_state_without_refunding_usage`
- `edge_gate_rejects_external_entries_extra_exits_exceptions_and_cycles`
- `comparison_gate_refuses_switch_and_budget_or_cancellation_stays_a_stop`

Tests cover both frozen debug profiles, exact route ownership (17/23/29), original loop init/update/slot and break origins, refusal boundaries, altered edge rows, the shared Kahn cycle gate, and late Reader-path stop rollback. They are authored only; they have **not** been compiled or run. Parent should review the source patch, then run the OpenSpec-prescribed gates and record actual results.

## Review files

- `loop4.patch`: unified patch against the pinned shared `region.rs`, plus the new test module.
- `v1-v2.diff`: exact implementation/test delta from the immutable v1 preparation.
- `crates/jarde-java/src/region.rs`: private full source copy with implementation.
- `crates/jarde-java/src/region/loop_break_body_tests.rs`: new Reader-backed tests.
- `pins.json`: source-base, fixture, OpenSpec, private file, and patch SHA-256 pins.
- `static_preflight.py`: read-only Python checks for pins and expected patch wiring.

## Root integration plan

1. Confirm shared `region.rs` still matches `source_base.sha256`; review `loop4.patch` and the exact `v1-v2.diff`.
2. Run `python3 -B /private/tmp/jarde-loop4-break-body-impl-luna-v2-20261019/static_preflight.py` (read-only).
3. Integrate serially and execute the Reader-backed module plus required OpenSpec gates under the specified resource guards. Record real outcomes; no test result is implied by this preparation.

OpenSpec tasks 2.1/2.2 remain pending root review and actual test execution. This patch has not been integrated.
