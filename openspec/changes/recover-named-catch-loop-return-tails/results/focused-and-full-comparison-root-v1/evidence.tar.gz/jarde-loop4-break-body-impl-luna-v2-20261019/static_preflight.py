from pathlib import Path
import hashlib, json

BASE = Path("/Users/lordcasser/workspace/projects/jarde")
HERE = Path("/private/tmp/jarde-loop4-break-body-impl-luna-v2-20261019")
PINS = json.loads((HERE / "pins.json").read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(BASE / "crates/jarde-java/src/region.rs") == PINS["source_base"]["sha256"]
assert PINS["source_base"]["sha256"] == PINS["base_source_sha_expected"]
for key in ("private_region", "private_test", "patch", "v1_v2_diff", "readme", "static_preflight"):
    assert sha(Path(PINS[key]["path"])) == PINS[key]["sha256"], key
for fixture in PINS["fixtures"].values():
    path = Path(fixture["path"])
    assert path.stat().st_size == fixture["bytes"] and sha(path) == fixture["sha256"]
source = (HERE / "crates/jarde-java/src/region.rs").read_text()
test = (HERE / "crates/jarde-java/src/region/loop_break_body_tests.rs").read_text()
assert source.count("break_body: None") == source.count("LoopTarget {") - 1, "initialize every non-default LoopTarget literal"
assert "proved_break_body_join" in source and "loop_break_body_edges_closed" in source
assert "loop_break_body_acyclic" in source and "loop_break_body_branch_eligible" in source
assert "mod loop_break_body_tests;" in source
assert "let mut pending = vec![entry];" in source
route = source[source.index("fn loop_break_body_route("):source.index("/// Prove the one nested-loop side route", source.index("fn loop_break_body_route("))]
assert "active" not in route and "complete" not in route and "loop_break_body_acyclic" in route
for test_name in (
    "reader_recovers_complete_loop4_body_for_both_debug_profiles",
    "reader_proof_owns_only_the_closed_route_and_refuses_occupied_or_scoped_candidates",
    "reader_late_implicit_latch_stop_restores_trial_state_without_refunding_usage",
    "edge_gate_rejects_external_entries_extra_exits_exceptions_and_cycles",
    "comparison_gate_refuses_switch_and_budget_or_cancellation_stays_a_stop",
):
    assert f"fn {test_name}" in test
assert "29), id(23)" in test, "cycle stays internal to route owners"
assert "full_steps - 1" in test and "full_steps - canonical.edges().len() as u64" in test
patch=(HERE / "loop4.patch").read_text()
assert "loop_break_body_tests.rs" in patch and "proved_break_body_join" in patch
print("static preflight: pins and expected patch wiring verified; no toolchain invoked")
