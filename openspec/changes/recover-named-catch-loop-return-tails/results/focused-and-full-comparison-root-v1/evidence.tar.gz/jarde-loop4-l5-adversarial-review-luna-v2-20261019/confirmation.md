# Loop5 incoming Call/Return fix confirmation

Current product source: `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/region.rs`
SHA-256: `fad0d541819cc5caf4f0023a322034e40ac48d632f147a1fec8a78eb2ccf44da`

The earlier review's foreign legacy-subroutine ingress counterexample is closed by the current `certified_try_return_tail` scan at lines 11328-11344. It computes `from` and `to` against the exact `unique_owners` set, then refuses either `CanonicalEdgeKind::Call` or `Return` whenever `(from || to)` is true. Therefore a canonical `Return { call_site }` from a cloned `ret` block outside the candidate into an owned jsr continuation now returns `Ok(false)`; a Call edge targeting an owner is rejected by the same condition. This addresses the reported gap without changing normal-edge entry rules or the physical/canonical exception inventories.

This is source-only confirmation. Cargo is active; no tests, tools, or raw outputs were inspected, so runtime regression status is not claimed. The confirmation is bounded to the reviewed endpoint predicate and does not establish any broader Loop5 behavior.
