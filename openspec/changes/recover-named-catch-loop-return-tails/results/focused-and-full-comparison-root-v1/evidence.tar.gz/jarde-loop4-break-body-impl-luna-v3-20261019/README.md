# Loop4 transient diagnostic patch

This env-gated probe is for the root's guarded local test run only and is explicitly excluded from the product patch. It records the real loop candidate and proof, natural set/exits/ForHeader update, attached frame target/scope/body owners, actual body regions and Walker visited delta, final expected/actual/newly-visited sets, coverage/exact-owner decisions, and fallback reason. Set `JRE_LOOP4_PROBE=1` only on the focused diagnostic run. Root must restore exact pinned `region.rs` bytes afterward.

Base shared `region.rs` SHA-256: `f2fc004ab7cce991f972dbfc68596828be5a5d50ce28fde74cf500a177c85cd3`. `diagnostic.patch` is the transient patch; `region.base.rs` is a private read-only snapshot; `region.probe.rs` is the expected probed file. No toolchain was run by this preparation.
