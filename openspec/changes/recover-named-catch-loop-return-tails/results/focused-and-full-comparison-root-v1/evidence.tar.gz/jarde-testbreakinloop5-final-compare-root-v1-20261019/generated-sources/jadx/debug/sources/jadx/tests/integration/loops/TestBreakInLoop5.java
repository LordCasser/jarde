package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop5.class */
public class TestBreakInLoop5 extends IntegrationTest {

    /* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop5$TestCls.class */
    public static class TestCls {
        public long test(String spaceStr) {
            try {
                double multiplier = 1.0d;
                StringBuffer sb = new StringBuffer();
                for (int i = 0; i < spaceStr.length(); i++) {
                    char c = spaceStr.charAt(i);
                    if (!Character.isDigit(c) && c != '.') {
                        if (c == 'm' || c == 'M') {
                            multiplier = 1024.0d;
                            break;
                        }
                        if (c != 'g' && c != 'G') {
                            break;
                        }
                        multiplier = 1048576.0d;
                        break;
                    }
                    sb.append(spaceStr.charAt(i));
                }
                return (long) Math.ceil(Double.valueOf(sb.toString()).doubleValue() * multiplier);
            } catch (Exception e) {
                return -1L;
            }
        }

        public void check() {
            JadxAssertions.assertThat(test("1.2")).isEqualTo(2L);
            JadxAssertions.assertThat(test("12am")).isEqualTo(12L);
            JadxAssertions.assertThat(test("13m")).isEqualTo(13312L);
            JadxAssertions.assertThat(test("1G4")).isEqualTo(1048576L);
            JadxAssertions.assertThat(test("")).isEqualTo(-1L);
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code();
    }

    @Test
    public void testNoDebug() {
        noDebugInfo();
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code();
    }
}
