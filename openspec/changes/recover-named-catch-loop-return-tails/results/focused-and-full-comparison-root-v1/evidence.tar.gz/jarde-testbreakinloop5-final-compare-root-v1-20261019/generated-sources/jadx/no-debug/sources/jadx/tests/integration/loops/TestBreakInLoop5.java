package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop5.class */
public class TestBreakInLoop5 extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop5$TestCls.class */
    public static class TestCls {
        public long test(String str) {
            try {
                double d = 1.0d;
                StringBuffer stringBuffer = new StringBuffer();
                for (int i = 0; i < str.length(); i++) {
                    char cCharAt = str.charAt(i);
                    if (!Character.isDigit(cCharAt) && cCharAt != '.') {
                        if (cCharAt != 'm' && cCharAt != 'M') {
                            if (cCharAt != 'g' && cCharAt != 'G') {
                                break;
                            }
                            d = 1048576.0d;
                            break;
                        }
                        d = 1024.0d;
                        break;
                    }
                    stringBuffer.append(str.charAt(i));
                }
                return (long) Math.ceil(Double.valueOf(stringBuffer.toString()).doubleValue() * d);
            } catch (Exception e) {
                return -1L;
            }
        }

        public void check() {
            JadxAssertions.assertThat(test("1.2")).isEqualTo(2L);
            JadxAssertions.assertThat(test("12am")).isEqualTo(12L);
            JadxAssertions.assertThat(test("13m")).isEqualTo(13312L);
            JadxAssertions.assertThat(test("1G4")).isEqualTo(1048576L);
            JadxAssertions.assertThat(test("")).isEqualTo(-1L);
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code();
    }

    @Test
    public void testNoDebug() {
        noDebugInfo();
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code();
    }
}
