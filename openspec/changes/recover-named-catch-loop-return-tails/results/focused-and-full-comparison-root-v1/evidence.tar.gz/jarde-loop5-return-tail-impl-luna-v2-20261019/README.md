# Loop5 named-catch return-tail candidate v2 (private, unexecuted)

This v2 is a new private candidate. The reviewed v1 directory remains unchanged at `/private/tmp/jarde-loop5-return-tail-impl-luna-v1-20261019`; `v1-reference.json` records its close-out digests. The shared checkout remains read-only. No Cargo, Rust compiler, JDK, JADX, Jarde CLI, network, Git, or formatter was run.

## Changes from v1

`changes-v1-v2.diff` records the exact candidate and test changes.

- The certificate now models `saved_visited` as already containing the full prefix. It requires the owner prefix slice to equal `prefix`, the saved-owner intersection to equal exactly those prefix blocks, every owner to be currently visited and unique, and the newly visited delta to equal only loop owners plus the returned-expression tail. Reader tests call the isolated certificate with that real saved-prefix state.
- Physical exception-range coverage is checked independently: every canonical block containing an SSA instruction in the half-open physical range must be owned, and every owned instruction must fit the range except the try lead and exclusive-end return. `CanonicalHandlerRow::protected()` is compared to the exact canonical exception-edge source set for the row ordinal. Each such edge must target the named handler, be owned, pass `exception_edge_takeable`, and have a matching throw site inside the physical range. The Reader test pins the observed Loop5 source set `{0, 14, 23, 60, 81, 88, 106}` and separately checks all physically overlapping blocks, including non-source blocks.
- Budget accounting now includes visited-set scanning, worst-case owner-by-instruction scanning, clone/set insertion inventory, candidate body/owner vector growth, and a final publication poll. The one-unit-short proof test inherits every non-AnalysisSteps limit from `ample_budget`, so it reaches an AnalysisSteps Stop instead of failing an unrelated zero limit.
- Tests now call the actual `try_level` candidate path for forced join refusal and, after Loop4 proof integration, a one-unit-short late AnalysisSteps stop. The latter checks the checkpoint state is restored. The full recovery, actual candidate refusal, and late-stop integration tests remain ignored until the pending Loop4 named-row break-body proof is integrated; none is claimed as passing.

The local normal-edge ownership closure and `candidate_blocks_have_named_catch_scope` check edge ownership and exception scope; they do not traverse the graph to establish acyclicity or add a second DAG proof. The parent-owned Loop4 common proof remains authoritative for DAG reasoning and must be reviewed before final integration.

## Checkpoint state

`try_level`'s full candidate checkpoint does not copy `excluded_edge_nodes`. This patch does not mutate that set: its use in the new path is read-only through existing scope checks. The added refusal/late-stop tests exercise mutable candidate state (`visited`, `unclosed_tail_at`, `catch_joins`, loop-catch owners, fragmented facts, monitor state, and depth).

## Review/apply inputs

- `candidate.patch` concatenates the three file diffs. Individual patches are also present.
- `region.rs.base` matches the shared base digest recorded in `pins.json`; re-check before applying.
- The test module is inserted beside `finite_loop_catch_tests.rs` and consumes the parent-prepared frozen fixture paths:
  `tests/fixtures/recover-named-catch-loop-return-tails/original/{debug,no-debug}/classes/jadx/tests/integration/loops/TestBreakInLoop5$TestCls.class`.
- `region.rs.candidate` and `loop5_return_tail_tests.rs` are the complete candidate sources for review.

## Root-side validation plan (not run here)

After integrating the pending Loop4 proof and installing the fixtures, run isolated certificate tests:

```text
cargo test -p jarde-java --lib region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_return_tail_certificate_accepts_the_frozen_boundary_return -- --exact --nocapture
cargo test -p jarde-java --lib region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_return_tail_certificate_refuses_drift_duplicate_owners_and_stops_cleanly -- --exact --nocapture
```

Then run the actual refusal and late-stop candidate tests, removing their `ignore` attributes only when the Loop4 proof is integrated:

```text
cargo test -p jarde-java --lib region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_try_level_candidate_refusal_restores_tentative_owners -- --exact --ignored --nocapture
cargo test -p jarde-java --lib region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_try_level_late_analysis_stop_restores_candidate_checkpoint -- --exact --ignored --nocapture
cargo test -p jarde-java --lib region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_full_try_owns_prefix_loop_and_return_tail_after_loop4_proof -- --exact --ignored --nocapture
```

These are commands for the parent to evaluate, not evidence of compilation or passing tests. The parent owns integration, resource limits, execution, and cleanup.
