# Loop5 catch-slot Builder candidate v2 (private)

This fresh candidate is based on the unchanged shared `build.rs` SHA in `pins.json`; v1 remains immutable. It does not modify the repository.

The production change passes `RegionPaths.catch_parameters` into the single `decide_types` caller. It first requires exact clause path, parameter/local slot, handler BCI, decoded Store slot, and a stored `Stack(0)` Phi whose canonical block is that handler. It then charges `ssa.blocks().len() + 4` AnalysisSteps and polls before `ssa.block(handler)`. It inspects only that handler block's first instruction, requiring its BCI and exact one-element Stack(0)-read/Local(slot)-write rows to match the recorded values. There is no BCI-only whole-SSA scan. An empty catch map bypasses the added lookup and charge. The existing direct `Definition::Caught` rule, whole-slot reuse identity, and catch escape checking are unchanged.

The included test module has three gates: `loop5_handler_entry_phi_does_not_conflict_with_reused_double_slot` exercises debug/no-debug Reader inputs; `loop5_catch_binding_requires_exact_path_handler_slot_and_stack_zero_phi` rejects absent path, wrong handler, wrong slot, and a non-handler Phi; `loop5_catch_binding_propagates_budget_and_cancellation_stops` checks Stop propagation. The existing complete public gate is `tests/recover_loop45_original_public.rs`, which root should rerun after integrating this candidate.

Only Python `-B` was used to assemble and statically check the private candidate and fixture include paths. No Rust/Cargo/rustfmt/JVM/JADX/Jarde CLI command was run.
