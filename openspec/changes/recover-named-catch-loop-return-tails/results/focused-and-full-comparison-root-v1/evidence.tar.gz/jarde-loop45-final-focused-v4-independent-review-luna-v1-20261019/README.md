# Loop4/5 focused-v4 independent receipt audit

This package independently reopens the CLOSED focused-v4 execution receipt and all 14 stdout/stderr raw streams, recalculates byte counts and SHA-256 pins, parses test outcomes from raw logs, and reopens/re-hashes the 3,346 recorded source files. It did not access the still-open final comparison v2 directories and ran no Git, network, or toolchain commands.

Verified from the raw streams: CF12 integration 9 passed; library tests 540 passed, including the 14 added unit gates; public integration 4 passed. Clippy completed with exit 0, `cargo fmt --all -- --check` completed with exit 0, the offline CLI build completed with exit 0, and cleanup completed with exit 0. The original CF12 budget test remains present with its exact CHAR limit 365 at BCI 29 and NULL limit 130 at BCI 1.

Source pins before and after are identical (3,346 entries); no `.orig` files were present. The built CLI is 64,631,664 bytes, mode 0555, SHA-256 `d29b6fee723d8f59fbecd9fd8be9f15a8ec73de3a90f5a2a29b24ff91e4af607`.

This verifies the focused-v4 receipt and its scope. It is not the final three-way baseline comparison audit; that comparison was still running and was intentionally not read. See `review.json` for exact commands, names, pins, and per-stream evidence.
