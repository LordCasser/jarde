#!/usr/bin/env python3
"""Independent Python-only audit of the closed focused-v4 receipt."""
import collections, hashlib, json, os, re, stat
from pathlib import Path

RECEIPT=Path('/private/tmp/jarde-loop45-final-focused-root-v4-20261019/execution.json')
OUT=Path('/private/tmp/jarde-loop45-final-focused-v4-independent-review-luna-v1-20261019')
SOURCE_ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
EXPECTED_CLI_SHA='d29b6fee723d8f59fbecd9fd8be9f15a8ec73de3a90f5a2a29b24ff91e4af607'
EXPECTED_UNIT={
 'region::loop_break_body_tests::reader_recovers_complete_loop4_body_for_both_debug_profiles',
 'region::loop_break_body_tests::reader_proof_owns_only_the_closed_route_and_refuses_occupied_or_scoped_candidates',
 'region::loop_break_body_tests::reader_late_implicit_latch_stop_restores_trial_state_without_refunding_usage',
 'region::loop_break_body_tests::edge_gate_rejects_external_entries_extra_exits_exceptions_and_cycles',
 'region::loop_break_body_tests::comparison_gate_refuses_switch_and_budget_or_cancellation_stays_a_stop',
 'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_return_tail_certificate_accepts_the_frozen_boundary_return',
 'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_return_tail_certificate_refuses_drift_duplicate_owners_and_stops_cleanly',
 'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_try_level_candidate_refusal_restores_tentative_owners',
 'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_try_level_late_analysis_stop_restores_candidate_checkpoint',
 'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_full_try_owns_prefix_loop_and_return_tail_after_loop4_proof',
 'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_named_break_body_proof_binds_one_row_and_rejects_scope_drift',
 'build::tests::loop5_catch_binding_tests::loop5_handler_entry_phi_does_not_conflict_with_reused_double_slot',
 'build::tests::loop5_catch_binding_tests::loop5_catch_binding_requires_exact_path_handler_slot_and_stack_zero_phi',
 'build::tests::loop5_catch_binding_tests::loop5_catch_binding_propagates_budget_and_cancellation_stops',
}
EXPECTED_PUBLIC={
 'original_loop4_debug_and_no_debug_class_and_full_jar_keep_structured_conditional_break_body',
 'original_loop4_public_class_source_propagates_precancellation_without_partial_text',
 'original_loop5_debug_and_no_debug_class_and_full_jar_keep_named_catch_return_tail',
 'original_loop5_public_class_source_propagates_precancellation_without_partial_text',
}

def sha(data): return hashlib.sha256(data).hexdigest()
def need(ok,msg):
    if not ok: raise AssertionError(msg)
def parse_outcomes(text):
    out=[]
    for line in text.splitlines():
        m=re.fullmatch(r'test (.+) \.\.\. (ok|FAILED|ignored)(?:,.*)?',line)
        if m: out.append({'name':m.group(1),'status':m.group(2),'line':line})
    return out
def parse_summary(text):
    m=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)
    need(len(m)==1,f'expected one Cargo summary, found {len(m)}')
    return {'state':m[0][0],'passed':int(m[0][1]),'failed':int(m[0][2]),'ignored':int(m[0][3])}
def read_pin(pin,label):
    p=Path(pin['path']); need(p.is_file() and not p.is_symlink(),f'{label}: missing or symlink {p}')
    b=p.read_bytes(); need(len(b)==pin['bytes'],f'{label}: size mismatch {p}'); need(sha(b)==pin['sha256'],f'{label}: SHA mismatch {p}')
    return b

def main():
    receipt_bytes=RECEIPT.read_bytes(); d=json.loads(receipt_bytes)
    need(d['status']=='commands_passed_pending_independent_acceptance','unexpected receipt status')
    need(len(d['commands'])==7,'expected seven commands')
    raw_streams=[]
    raw_root=RECEIPT.parent/'raw'
    seen=set()
    for c in d['commands']:
        need(set(c['streams'])=={'stdout','stderr'},f'command {c["index"]}: missing raw stream')
        for typ,pin in c['streams'].items():
            p=Path(pin['path']); need(p.parent==raw_root and str(p) not in seen,f'raw path escaped/repeated: {p}')
            b=read_pin(pin,f'command {c["index"]} {typ}'); seen.add(str(p))
            raw_streams.append({'command':c['index'],'stream':typ,'path':str(p),'bytes':len(b),'sha256':sha(b)})
    need(len(raw_streams)==14,'expected 14 raw streams')
    commands=d['commands']
    def stdout(i): return Path(commands[i-1]['streams']['stdout']['path']).read_text(encoding='utf-8',errors='replace')
    def stderr(i): return Path(commands[i-1]['streams']['stderr']['path']).read_text(encoding='utf-8',errors='replace')
    # CF12 targeted suite: all nine exact names and both fixed stop points.
    cf_text=stdout(1); cf_rows=parse_outcomes(cf_text); cf_summary=parse_summary(cf_text)
    need(cf_summary=={'state':'ok','passed':9,'failed':0,'ignored':0},'CF12 summary mismatch')
    need(len(cf_rows)==9 and all(x['status']=='ok' for x in cf_rows),'CF12 named outcomes do not show nine passes')
    cf_names={x['name'] for x in cf_rows}
    expected_cf={
      'cf12_charat_stored_value_drives_char_source_type_and_full_origins',
      'cf12_null_first_direct_string_writes_drive_string_source_type_and_full_origins',
      'cf12_recovery_budget_stop_and_cancellation_publish_no_partial_source',
      'typed_boundary_four_char_seeds_have_specific_types_and_full_origins_in_both_debug_profiles',
      'typed_boundary_mixed_all_null_and_unknown_reference_stay_object_in_both_debug_profiles',
      'typed_boundary_null_first_exact_string_stays_string_in_both_debug_profiles',
      'typed_boundary_proof_budget_stops_before_publication_at_observed_sites',
      'typed_boundary_range_arithmetic_and_input_copy_remain_int_in_both_debug_profiles',
      'typed_boundary_real_slot_conflict_is_preserved_as_the_exact_fallback_in_default_and_all',
    }
    need(cf_names==expected_cf,f'CF12 names differ: missing={sorted(expected_cf-cf_names)} extra={sorted(cf_names-expected_cf)}')
    test_path=SOURCE_ROOT/'crates/jarde-java/tests/cf12_proved_local_source_types.rs'
    test_text=test_path.read_text(encoding='utf-8')
    # Confirm actual unchanged test still encodes the original exact stop sites.
    exact_limits=[]
    for m in re.finditer(r'assert_typed_boundary_budget_stop\(\s*(CHAR_CLASS|NULL_CLASS),\s*"([^"]+)",\s*"([^"]+)",\s*"([^"]+)",\s*(\d+),\s*(\d+),\s*\);',test_text,re.S):
        exact_limits.append({'fixture':m.group(1),'owner':m.group(2),'name':m.group(3),'descriptor':m.group(4),'limit':int(m.group(5)),'at_bci':int(m.group(6))})
    need(exact_limits==[
      {'fixture':'CHAR_CLASS','owner':'jadx/tests/integration/switches/TestSwitch$TestCls','name':'test','descriptor':'(Ljava/lang/String;)Ljava/lang/String;','limit':365,'at_bci':29},
      {'fixture':'NULL_CLASS','owner':'jadx/tests/integration/switches/TestSwitchNoDefault$TestCls','name':'test','descriptor':'(I)V','limit':130,'at_bci':1},
    ],f'CF12 exact stop pins changed: {exact_limits}')
    # Library suite: summary plus the requested fourteen exact gates.
    lib_text=stdout(2); lib_rows=parse_outcomes(lib_text); lib_summary=parse_summary(lib_text)
    need(lib_summary=={'state':'ok','passed':540,'failed':0,'ignored':0},'lib summary mismatch')
    need(len(lib_rows)==540 and all(x['status']=='ok' for x in lib_rows),'lib named outcomes do not all pass')
    lib_names={x['name'] for x in lib_rows}
    need(EXPECTED_UNIT<=lib_names,f'new unit gates missing: {sorted(EXPECTED_UNIT-lib_names)}')
    need(all(next(x for x in lib_rows if x['name']==name)['status']=='ok' for name in EXPECTED_UNIT),'one of fourteen new gates failed')
    panic=[x for x in lib_rows if ' - should panic' in x['name']]
    need(len(panic)==1 and panic[0]['status']=='ok','expected sole successful should-panic test')
    # Public tests.
    pub_text=stdout(3); pub_rows=parse_outcomes(pub_text); pub_summary=parse_summary(pub_text)
    need(pub_summary=={'state':'ok','passed':4,'failed':0,'ignored':0},'public summary mismatch')
    need({x['name'] for x in pub_rows}==EXPECTED_PUBLIC and all(x['status']=='ok' for x in pub_rows),'public names/status mismatch')
    # Tool/check commands and clean result.
    need(commands[3]['exit_code']==0 and commands[3]['argv'][:3]==['cargo','clippy','--offline'],'Clippy command failed or changed')
    clippy_err=stderr(4)
    clippy_blockers=[line for line in clippy_err.splitlines() if line.startswith('error:') or re.match(r'^warning:.*(?:clippy|warning)',line)]
    need(not clippy_blockers,'Clippy output contains a warning/error: '+repr(clippy_blockers))
    need(commands[4]['exit_code']==0 and commands[4]['argv']==['cargo','fmt','--all','--','--check'] and stdout(5)=='' and stderr(5)=='','fmt check did not cleanly pass')
    need(commands[5]['exit_code']==0 and commands[5]['argv'][:4]==['cargo','build','--offline','-p'] and 'Finished `dev` profile' in stderr(6),'CLI build did not complete cleanly')
    need(commands[6]['exit_code']==0 and commands[6]['argv']==['cargo','clean'],'cargo clean failed')
    clean_text=stderr(7); need('Removed 3192 files, 713.8MiB total' in clean_text,'cleanup report changed')
    # CLI identity and mode.
    cli=d['cli']; cli_bytes=read_pin(cli,'CLI')
    need(cli['bytes']==64631664 and sha(cli_bytes)==EXPECTED_CLI_SHA,'CLI size/SHA mismatch')
    cli_mode=stat.S_IMODE(Path(cli['path']).stat().st_mode)
    need(cli_mode==0o555,f'CLI mode mismatch: {oct(cli_mode)}')
    # Verify complete before/after source inventory at both declaration and filesystem levels.
    before=d['source_before']; after=d['source_after']
    need(len(before)==len(after)==3346 and before==after and d['source_unchanged'] is True,'source inventory changed')
    need(d['source_changes']==[] and d['allowed_source_changes']==[] and d['source_changes_accepted'] is True,'source change records unexpected')
    orig_paths=[x['path'] for x in before if x['path'].endswith('.orig') or x['path'].endswith('.orig~')]
    need(not orig_paths,f'.orig files present in source snapshot: {orig_paths}')
    need(not any(x['path'].endswith('/region.rs.orig') for x in before),'region.rs.orig is still in source snapshot')
    source_reopened=[]
    for pin in before:
        b=read_pin(pin,'source inventory')
        source_reopened.append({'path':pin['path'],'bytes':len(b),'sha256':sha(b)})
    need(d['target_absent'] is True,'repository target cleanup guard is false')
    report={
      'schema':'jarde.loop45.final-focused-v4-independent-review.v1',
      'status':'closed_v4_receipt_independently_verified',
      'receipt':{'path':str(RECEIPT),'bytes':len(receipt_bytes),'sha256':sha(receipt_bytes),'recorded_status':d['status'],'finished_utc':d['finished_utc']},
      'raw_streams':raw_streams,'raw_stream_count':len(raw_streams),
      'cf12':{'summary':cf_summary,'named_test_count':len(cf_rows),'named_tests':cf_rows,'exact_budget_stops':exact_limits},
      'lib':{'summary':lib_summary,'named_outcome_count':len(lib_rows),'new_unit_gates':sorted(EXPECTED_UNIT),'new_unit_gate_count':len(EXPECTED_UNIT),'should_panic_test':panic[0]['name']},
      'public':{'summary':pub_summary,'named_tests':pub_rows},
      'checks':{
        'clippy':{'exit_code':commands[3]['exit_code'],'argv':commands[3]['argv'],'blocking_warnings_or_errors':clippy_blockers,'stderr_bytes':len(clippy_err.encode())},
        'fmt':{'exit_code':commands[4]['exit_code'],'argv':commands[4]['argv'],'stdout_bytes':0,'stderr_bytes':0},
        'cli_build':{'exit_code':commands[5]['exit_code'],'argv':commands[5]['argv'],'success_line_present':True},
        'clean':{'exit_code':commands[6]['exit_code'],'removed':'3192 files, 713.8MiB'},
      },
      'cli':{'path':cli['path'],'bytes':len(cli_bytes),'sha256':sha(cli_bytes),'mode_octal':oct(cli_mode)},
      'source_integrity':{'before_count':len(before),'after_count':len(after),'unchanged':True,'orig_files':orig_paths,'reopened_file_count':len(source_reopened),'source_paths_and_pins':source_reopened,'target_absent':d['target_absent']},
      'scope':'Independent read-only audit of the closed focused-v4 receipt and its source pins. The still-open final comparison v2 directories were not accessed. No toolchain was run.',
    }
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':report['status'],'raw_streams':len(raw_streams),'cf12_passed':cf_summary['passed'],'lib_passed':lib_summary['passed'],'new_unit_gates':len(EXPECTED_UNIT),'public_passed':pub_summary['passed'],'clippy_clean':not clippy_blockers,'fmt':commands[4]['exit_code'],'cli_build':commands[5]['exit_code'],'source_files_reopened':len(source_reopened),'cli_mode':oct(cli_mode)},ensure_ascii=False))
if __name__=='__main__': main()
