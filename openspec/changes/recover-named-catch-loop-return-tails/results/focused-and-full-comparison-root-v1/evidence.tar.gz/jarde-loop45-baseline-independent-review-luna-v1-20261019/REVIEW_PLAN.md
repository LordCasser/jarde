# Loop4/5 independent baseline review plan

Status: waiting for root to confirm receipt closure. Do not inspect `/private/tmp/jarde-testbreakinloop4-baseline-root-v1-20261019` or `...loop5...` before that signal.

Frozen prep bundles inspected read-only:
- Loop4: `/private/tmp/jarde-testbreakinloop4-baseline-prep-luna-v2-20261019`
- Loop5: `/private/tmp/jarde-testbreakinloop5-baseline-prep-luna-v2-20261019`

Static preflight passed for both bundles. No JDK, Java, JADX, Jarde CLI, Cargo, Git, or network was invoked.

After closure, independently reopen actual `execution.json`, manifests, command records, raw stdout/stderr, class/JAR/source evidence and driver observations. Recompute pins from bytes; check source/copies/full source and JADX outer/inner trees; check API shape and complete class compilation evidence; independently parse physical classes/method BCI, fields/access flags; confirm method source mapping and UTF-8/BCI offsets; re-evaluate default/all stability, case/check semantics, isolated class loader and CodeSource negative controls, classpath contamination, driver-only application classpath, stdout and raw stream hashes. Treat Loop4 and Loop5 driver formats distinctly (Loop4: four CASE records then CHECK; Loop5: five CASE records, with check fields appended to last). Separate primary test observation from `check()` and framework loading behavior. Report discrepancies against raw files with paths and hashes.
