# Loop4/5 independent raw review

Read-only review of actual source, raw streams, class files, and API reports after both collectors closed. No collector rerun or product change.

## Loop4

- Source: 1068 bytes, SHA-256 `42b0f55b653b41bc69286e1947c8a19d94b0da810cdcc7cf48bb6d2cd6a256e5`. 46 commands and 92 raw stdout/stderr streams reopened and hash-checked.
- Original debug/no-debug target classes are major 52 and contain public `<init>()V`, `test(C)D`, and `check()V`; no fields. Original cases match the pinned plan in all four VM/profile cells using the `4 CASE records plus a terminal CHECK` protocol; target stdout is empty and inputs are unchanged.
- `check()` passes on JDK 23 in both profiles. JDK 8 records `UnsupportedClassVersionError` from framework class version 55 vs runtime maximum 52; this is separate from the successful primary case observations.
- All 8 Jarde API reports contain the complete 3-method inventory. Default/all pairs agree on whole source, identities, quality, text, and source maps across both profiles and input forms. Reopened 384 source-map references: 0 invalid UTF-8 byte-span or method-identity findings.
- `test` is `fallback` with `jre_region_uncovered_blocks`; 15 physical BCIs lack source-map coverage. The all-evidence region identifies [17, 23, 29] as live blocks omitted from normal-flow view.
- Full-source compile attempts: 16 Jarde, all failed (JDK 8 reports dependency major 55 vs supported 52; JDK 23 reports missing return); 4 JADX, 2 JDK 23 succeeded and 2 JDK 8 failed on IntegrationTest major 55 vs 52. The 2 successful JADX output class trees each contain outer+target; all 4 isolated VM runs match original cases and check across both runtimes/profiles.
- There are 3 original/generated wrong-CodeSource controls per target; each exits 1 at the expected CodeSource assertion. The JVM application classpath contains only the driver; 11 pinned dependency URLs are supplied to the isolated target loader and none contains the target class.

## Loop5

- Source: 1495 bytes, SHA-256 `4aef48802b7dc7cc47c7c03d6c2639103c2913345cb8be8818545e63ed1fea64`. 46 commands and 92 raw stdout/stderr streams reopened and hash-checked.
- Original debug/no-debug target classes are major 52 and contain public `<init>()V`, `test(Ljava/lang/String;)J`, and `check()V`; no fields. Original cases match the pinned plan in all four VM/profile cells using the `5 CASE records with check fields appended to the last CASE` protocol; target stdout is empty and inputs are unchanged.
- `check()` passes on JDK 23 in both profiles. JDK 8 records `UnsupportedClassVersionError` from framework class version 55 vs runtime maximum 52; this is separate from the successful primary case observations.
- All 8 Jarde API reports contain the complete 3-method inventory. Default/all pairs agree on whole source, identities, quality, text, and source maps across both profiles and input forms. Reopened 496 source-map references: 0 invalid UTF-8 byte-span or method-identity findings.
- `test` is `fallback` with `jre_region_uncovered_blocks`; 47 physical BCIs lack source-map coverage. The all-evidence region identifies [14, 23, 106, 39, 88, 46, 53, 60, 67, 74, 81] as live blocks omitted from normal-flow view.
- Full-source compile attempts: 16 Jarde, all failed (JDK 8 reports dependency major 55 vs supported 52; JDK 23 reports missing return); 4 JADX, 2 JDK 23 succeeded and 2 JDK 8 failed on IntegrationTest major 55 vs 52. The 2 successful JADX output class trees each contain outer+target; all 4 isolated VM runs match original cases and check across both runtimes/profiles.
- There are 3 original/generated wrong-CodeSource controls per target; each exits 1 at the expected CodeSource assertion. The JVM application classpath contains only the driver; 11 pinned dependency URLs are supplied to the isolated target loader and none contains the target class.
