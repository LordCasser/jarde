# Loop5 catch-slot Builder candidate (private)

This candidate is bound to the captured shared `build.rs` SHA in `pins.json`. It does not modify the repository.

The production change passes `RegionPaths.catch_parameters` into the single `decide_types` caller. A write is omitted from normal-local write compatibility only when its exact `SlotUse.path` resolves to the recovered clause, its parameter slot equals the local slot, its BCI is the handler BCI, the decoded operation is `Store` for that slot, the same SSA instruction reads `Stack(0)` and writes that local value, and the stored value is a `Stack(0)` Phi defined by that exact handler block. The existing direct `Definition::Caught` rule remains. New lookup work is charged and polled before inspecting the catch-path map. Reuse identity and catch escape checking are untouched.

`loop5_catch_binding_tests.rs` adds three gates: real Reader positive for debug/no-debug; negative mutations for absent path, wrong handler, wrong slot, and non-handler local Phi; and budget/cancellation stop propagation. The module is included by the patch. Existing public complete Loop5 tests remain the external integration gate.

No Rust/Cargo/rustfmt/JVM/JADX/Jarde CLI command was run. Root should integrate serially and run the focused tests. The arithmetic-result type warning from the prior analysis was checked against `Expr::presented_of`/`binary_type`: binary expressions derive their type from operand types, so it should resolve once the local multiplier type is decided; this candidate intentionally does not alter arithmetic typing.
