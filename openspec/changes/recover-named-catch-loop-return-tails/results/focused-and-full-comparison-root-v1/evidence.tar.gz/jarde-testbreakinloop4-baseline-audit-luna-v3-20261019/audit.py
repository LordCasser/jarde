#!/usr/bin/env python3
"""Independent read-only integrity/oracle review for the TestBreakInLoop4 baseline."""
from __future__ import annotations
import argparse, base64, hashlib, importlib.util, json, os, re, sys, zipfile
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
BASE=Path('/private/tmp/jarde-testbreakinloop4-baseline-prep-luna-v2-20261019')
SOURCE=Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestBreakInLoop4.java')
SOURCE_SHA='42b0f55b653b41bc69286e1947c8a19d94b0da810cdcc7cf48bb6d2cd6a256e5'
INTERNAL='jadx/tests/integration/loops/TestBreakInLoop4$TestCls'
OUTER='jadx/tests/integration/loops/TestBreakInLoop4'
DRIVER='TestBreakInLoop4Driver'
JADX=Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
CASE_PLAN=BASE/'caseplans.json'
CASE_PLAN_SHA='7743536efb7cf625fbfc6abf2da67c6422510d6312c28acdb7bc80e904bd0c4f'
DRIVER_SOURCE=BASE/'driver/TestBreakInLoop4Driver.java'
DRIVER_SHA='ddf2ab3bceda4628cb31dd004b9e7f97f877ac481587fd7879f9a487dfffa528'
COLLECTOR=BASE/'collect_baseline.py'
COLLECTOR_SHA='96fc3725d6a389c7f841bcd5f9d71f2756cc8856fb86e53725aad16a6070bbc3'
RUNTIMES=('javac8','javac23'); PROFILES=('debug','no-debug'); FORMS=('child','bundle-child'); EVIDENCE=('default','all')

class AuditError(RuntimeError): pass
def need(ok,msg):
    if not ok: raise AuditError(msg)
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def norm(x):
    if isinstance(x,dict): return {str(k):norm(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [norm(v) for v in x]
    return x
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    if not spec or not spec.loader: raise AuditError(f'cannot load helper {path}')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def pin(row,label):
    need(isinstance(row,dict) and {'path','bytes','sha256'} <= row.keys(),f'{label}: malformed pin')
    p=Path(row['path']).resolve(strict=True); b=p.read_bytes()
    need(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],f'{label}: bytes/hash mismatch {p}')
    return p
def reopen_pin_records(value,label='pin'):
    count=0
    if isinstance(value,dict):
        if {'path','bytes','sha256'} <= value.keys(): pin(value,label); return 1
        for k,v in value.items(): count+=reopen_pin_records(v,f'{label}.{k}')
    elif isinstance(value,list):
        for i,v in enumerate(value): count+=reopen_pin_records(v,f'{label}[{i}]')
    return count
def codepoints(text):
    out={0}; n=0
    for ch in text: n+=len(ch.encode('utf-8')); out.add(n)
    return out
def class_facts(compare,physical,path,label):
    a=compare.parse_class(path); b=physical.parse_class_file(Path(path).read_bytes())
    need(a['class_name']==b['class_name'] and a['major']==b['major'] and norm(a['methods'])==norm(b['methods']),f'{label}: independent class parsers differ')
    need(sorted((f['name'],f['descriptor'],f['access']) for f in b['fields'])==sorted(tuple(x) for x in a['fields']),f'{label}: field parser facts differ')
    a['access']=b['access']; return a
def tree(compare,root):
    root=Path(root); return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*.class'))}
def parse_rows(raw,names):
    lines=raw.decode('utf-8','strict').splitlines()
    need(len(lines)==len(names)+1 and sum(line.startswith('CHECK ') for line in lines)==1 and lines[-1].startswith('CHECK result='),f'{len(names)} cases must be followed by one CHECK result')
    cm=re.fullmatch(r'^CHECK result=(pass|error) exception=([^ ]+) stdout_b64=([^ ]*) exception_message_b64=([^ ]*)$',lines[-1]); need(cm is not None,'malformed final check() record')
    check={'result':cm.group(1),'exception_type':cm.group(2),'stdout':base64.b64decode(cm.group(3),validate=True).decode('utf-8','strict'),'exception_message':base64.b64decode(cm.group(4),validate=True).decode('utf-8','strict')}
    lines=lines[:-1]
    rx=re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) target_stdout_b64=([^ ]*) after_b64=([^ ]*)$')
    dec=lambda s:base64.b64decode(s,validate=True).decode('utf-8','strict')
    rows=[]
    for i,line in enumerate(lines):
        m=rx.fullmatch(line); need(m is not None,f'malformed driver row {i}: {line!r}')
        idx,name,inp,res,exc,msg,stack,out,after=m.groups()
        need(int(idx)==i and name==names[i],f'driver row order/name mismatch {i}')
        rows.append({'index':i,'name':name,'input':dec(inp),'result':dec(res),'exception_type':exc,
                     'exception_message':dec(msg),'exception_stack':dec(stack),'target_stdout':dec(out),'after':dec(after),'raw':line,'check_result':check['result'],'check_exception_type':check['exception_type'],'check_stdout':check['stdout'],'check_exception_message':check['exception_message']})
    return rows
def snapshot(values):
    if values is None:return 'null'
    return '['+','.join('null' if v is None else json.dumps(v,ensure_ascii=False,separators=(',',':')) for v in values)+']'

SEMANTIC_ROW_KEYS=('index','name','input','result','exception_type','target_stdout','after')
def semantic_rows(rows):
    # Only diagnostic rendering (message, stack and serialized line) may vary
    # across compiler/debug profiles. Return, exception type, output and state remain exact.
    return [{key:row[key] for key in SEMANTIC_ROW_KEYS} for row in rows]
def diagnostic_rows(rows):
    return [{'index':row['index'],'name':row['name'],'exception_type':row['exception_type'],
             'exception_message':row['exception_message'],'exception_stack':row['exception_stack'],
             'check_result':row['check_result'],'check_exception_type':row['check_exception_type'],
             'check_stdout':row['check_stdout'],'check_exception_message':row['check_exception_message'],'raw':row['raw']} for row in rows]
def oracle_check(rows,cases):
    issues=[]
    if len(rows)!=len(cases): return ['row count differs from plan']
    for row,c in zip(rows,cases):
        inp=c['input']; exp=c['expected']; state=inp
        wantres=f"return={exp['return']}"
        for key,want in [('input',inp),('after',inp),('result',wantres),('exception_type',exp['exception_type']),('target_stdout',exp['stdout'])]:
            if row[key]!=want: issues.append(f"{c['id']}: {key} differs")
    return issues
def source_visible_access(access):
    # Raw access flags remain in all class facts. ACC_SYNTHETIC is the sole
    # non-source flag allowed to differ between independently compiled source.
    return access & ~0x1000

def inventory_metadata_differences(original, generated, internal):
    differences=[]
    specs=(
        ('method',original['methods'],generated['methods'],lambda x:(x['name'],x['descriptor']),lambda x:x['access']),
        ('field',original['fields'],generated['fields'],
         lambda x:(x['name'],x['descriptor']) if isinstance(x,dict) else (x[0],x[1]),
         lambda x:x['access'] if isinstance(x,dict) else x[2]),
    )
    for kind,left,right,key_of,access_of in specs:
        lm={key_of(row):row for row in left}; rm={key_of(row):row for row in right}
        need(lm.keys()==rm.keys(),f'{internal}: {kind} name/descriptor inventory differs')
        for ident in sorted(lm):
            la,ra=access_of(lm[ident]),access_of(rm[ident])
            need(source_visible_access(la)==source_visible_access(ra),f'{internal}: source-visible {kind} flags differ at {ident}: {la} vs {ra}')
            if la!=ra:
                need((la^ra)==0x1000,f'{internal}: non-synthetic access flags differ at {ident}: {la} vs {ra}')
                differences.append({'class_name':internal,'member_kind':kind,'name':ident[0],
                                    'descriptor':ident[1],'original_access':la,'generated_access':ra,
                                    'allowed_difference':'ACC_SYNTHETIC only'})
    return differences

def method_map_audit(method, physical):
    outcome=method.get('outcome',{}); body=outcome.get('report',{})
    text=body.get('text'); source_map=body.get('source_map')
    result={'outcome_kind':outcome.get('kind'),'quality':body.get('quality'),
            'map_present':isinstance(source_map,dict),'issues':[]}
    if not isinstance(text,str):
        result['issues'].append('raw method text missing'); return result
    raw=text.encode('utf-8'); result['text_bytes']=len(raw)
    if not isinstance(source_map,dict) or not isinstance(source_map.get('segments'),list):
        result['issues'].append('source map/segments missing'); return result
    bounds=codepoints(text); valid_bcis=set(physical.get('code',{}).get('bcis',[])); mapped=set()
    segments=source_map['segments']; result['segment_count']=len(segments)
    for index,segment in enumerate(segments):
        start,end=segment.get('start'),segment.get('end')
        if type(start)!=int or type(end)!=int or not (0<=start<=end<=len(raw)) or start not in bounds or end not in bounds:
            result['issues'].append(f'segment {index} has invalid UTF-8 byte bounds'); continue
        origin=segment.get('origin')
        if not isinstance(origin,dict) or not isinstance(origin.get('primary'),dict):
            result['issues'].append(f'segment {index} has no primary origin'); continue
        derived=origin.get('derived',[])
        if not isinstance(derived,list):
            result['issues'].append(f'segment {index} has malformed derived-origin list'); continue
        for ref in [origin['primary'],*derived]:
            if not isinstance(ref,dict):
                result['issues'].append(f'segment {index} has malformed origin reference'); continue
            bci=ref.get('bci')
            if type(bci)!=int or bci not in valid_bcis:
                result['issues'].append(f'segment {index} references nonphysical BCI {bci!r}')
            else: mapped.add(bci)
            ref_method=ref.get('method'); expected_owner=method.get('item',{}).get('identity',{}).get('owner')
            if not isinstance(ref_method,dict):
                result['issues'].append(f'segment {index} has no origin method identity'); continue
            if not isinstance(expected_owner,dict) or not isinstance(ref_method.get('owner'),dict):
                result['issues'].append(f'segment {index} has malformed origin owner identity')
            try:
                ref_name=bytes(ref_method.get('name',[])).decode('utf-8','strict')
                ref_descriptor=bytes(ref_method.get('descriptor',[])).decode('utf-8','strict')
            except (TypeError,ValueError,UnicodeDecodeError):
                result['issues'].append(f'segment {index} has malformed origin method identity')
            else:
                if ref_name!=physical.get('name') or ref_descriptor!=physical.get('descriptor'):
                    result['issues'].append(f'segment {index} references a different method identity')
                if ref_method.get('owner')!=expected_owner:
                    result['issues'].append(f'segment {index} origin owner differs from method owner')
    result['mapped_bcis']=sorted(mapped); result['physical_bcis']=sorted(valid_bcis)
    result['unmapped_physical_bcis']=sorted(valid_bcis-mapped)
    result['covers_all_physical_bcis']=mapped==valid_bcis
    return result

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--receipt',type=Path,required=True); ap.add_argument('--cli',type=Path,required=True); ap.add_argument('--cli-sha256',required=True); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args()
    need(re.fullmatch('[0-9a-f]{64}',a.cli_sha256) is not None,'CLI SHA must be 64 lowercase hex')
    receipt_path=a.receipt.resolve(strict=True); data=json.loads(receipt_path.read_text()); out=a.out
    need(data.get('schema')=='test-break-in-loop4-full-source-baseline-v1','receipt schema mismatch')
    need(data.get('root')==str(ROOT) and Path(data.get('output','')).resolve()==receipt_path.parent,'root/output identity mismatch')
    need(data.get('status') in ('captured-pending-independent-review','failed'),'unexpected capture status')
    cli=a.cli.resolve(strict=True); need(data.get('candidate_cli_sha256_expected')==a.cli_sha256 and Path(data['cli']['path']).resolve()==cli and sha(cli)==a.cli_sha256,'candidate CLI binding mismatch')
    need(sha(SOURCE)==SOURCE_SHA and len(SOURCE.read_bytes())==1068,'upstream source pin changed')
    need(sha(CASE_PLAN)==CASE_PLAN_SHA and sha(DRIVER_SOURCE)==DRIVER_SHA and sha(COLLECTOR)==COLLECTOR_SHA,'frozen source/plan/collector pins changed')
    need(sha(receipt_path.parent/'collector.py')==COLLECTOR_SHA,'captured collector copy mismatch')
    compare_path=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
    guard_path=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
    scanner_path=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
    parser=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
    compare=load(compare_path,'breakcomplex_compare'); guard=load(guard_path,'breakcomplex_guard'); physical=load(parser,'breakcomplex_physical')
    source=Path(data['source']['path']); need(source.resolve()==SOURCE.resolve() and sha(source)==SOURCE_SHA,'receipt source binding differs')
    plan=json.loads(CASE_PLAN.read_text()); cases=plan['cases']; names=[x['id'] for x in cases]
    need(plan.get('schema')=='test-break-in-loop4-source-plan-v1','source-math plan schema mismatch')
    need(plan.get('method',{}).get('binary_name')==INTERNAL and plan['method'].get('descriptor')=='(C)D','source-math target method identity mismatch')
    need(plan.get('source_inventory',{}).get('explicit_target_fields')==[] and plan['source_inventory'].get('nested_helpers')==[],'source target/helper inventory differs')
    need(len(plan.get('original_outer_tests',[]))==2 and plan.get('original_check',{}).get('method')=='TestBreakInLoop4.TestCls.check()V','original JUnit/check closure is incomplete')
    need(data['runtime_case_names']==names and len(names)==4,'case order/count differs from pinned plan')
    plan_source_pin=plan['source']
    plan_source=Path(plan_source_pin['copy']).resolve(strict=True)
    need(plan_source_pin.get('bytes')==len(SOURCE.read_bytes())==1068
         and plan_source_pin.get('sha256')==SOURCE_SHA==sha(plan_source)
         and plan_source.read_bytes()==SOURCE.read_bytes(), 'pinned case-plan source copy differs from upstream bytes')
    need(data.get('case_plan_source_copy')=={'path':str(plan_source),'bytes':1068,'sha256':SOURCE_SHA},
         'receipt does not bind exact plan source copy')
    profile_by={p['profile']:p for p in data.get('source_profiles',[])}; findings=[]; physical_by_profile={}; pin_records=0
    need(len(profile_by)==2 and set(profile_by)==set(PROFILES),'original profile inventory incomplete')
    # Reopen all command raw streams and environmental/source/tool pin records first.
    commands=data.get('commands',[]); cmd_by={r['index']:r for r in commands}
    need(len(cmd_by)==len(commands) and sorted(cmd_by)==list(range(1,len(commands)+1)),'command indexes are not contiguous/unique')
    for row in commands:
        need(row['cwd']==str(ROOT) and row.get('guard_stop') is None,'command cwd/guard failure')
        need(row.get('peak_target_bytes',0)<=1024**3 and row.get('free_bytes_after',0)>=5*1024**3,'target/free-space guard boundary exceeded')
        need(row.get('env_overrides')==guard.ENV_VALUES,'command environment overrides differ from pinned guard')
        for channel in ('stdout','stderr'):
            stream=row.get('streams',{}).get(channel); path=pin(stream,f"command {row['index']} {channel}"); pin_records+=1
            raw_expected=Path(data['output'])/'raw'/f"{row['index']}.{channel}.raw"
            need(path==raw_expected.resolve() and path.read_bytes()==raw_expected.read_bytes(),f"command raw stream path mismatch {row['index']} {channel}")
        if row['exit_code']!=0: findings.append(f"command {row['index']} {row['label']} exited {row['exit_code']}; retained as observed")
    pin_records+=reopen_pin_records(data.get('external_input_pins_before',{}),'external before')
    pin_records+=reopen_pin_records(data.get('external_input_pins_after',{}),'external after')
    pin_records+=reopen_pin_records(data.get('external_input_pins_after_finally',{}),'external finally')
    need(data.get('external_inputs_unchanged') is True and data.get('external_input_pins_before')==data.get('external_input_pins_after')==data.get('external_input_pins_after_finally'),'external tool/source pins changed')
    pin_records+=reopen_pin_records(data.get('source_pins_before',[]),'source before')
    pin_records+=reopen_pin_records(data.get('source_pins_after',[]),'source after')
    pin_records+=reopen_pin_records(data.get('source_pins_after_finally',[]),'source finally')
    need(data.get('source_unchanged') is True and data.get('source_unchanged_finally') is True and data.get('source_pins_before')==data.get('source_pins_after')==data.get('source_pins_after_finally'),'workspace source closure changed')
    need(data.get('target_absent') is True and data.get('target_absent_finally') is True,'target directory is not absent')
    # Reopen source, driver, wrapper, and tool copies.
    for key in ('source_copy','driver_copy','runtime_wrapper'):
        pin(data[key],key); pin_records+=1
    for name,row in data.get('copied_tools',{}).items():
        path=pin(row,f'copied tool {name}'); pin_records+=1
        ext={'compare.py':compare_path,'guard.py':guard_path,'scanner.py':scanner_path,'classfile_helpers.py':parser}[name]
        need(path.read_bytes()==ext.read_bytes(),f'copied tool bytes differ: {name}')
    need(data.get('local_copies_unchanged') is True and data.get('local_copies_unchanged_finally') is True,'local copied source/driver/tool changed')
    # Original full-source compilation and independently parsed class/field/method inventories.
    for profile in PROFILES:
        row=profile_by[profile]; cmd=cmd_by[row['command']]
        need(cmd['label']==f'javac23-full-source-{profile}' and cmd['exit_code']==row['exit_code'],'original compiler command link mismatch')
        source_copy=pin(data['source_copy'],'copied full original source'); pin_records+=1
        argv=cmd['argv']; tool=data['jdk_manifest']['tools']['javac23']['javac']['path']
        want=[tool,'--release','8','-g' if profile=='debug' else '-g:none','-encoding','UTF-8','-proc:none',
              '-classpath',':'.join(data['dependency_classpath']),'-sourcepath',data['empty_classpath'],
              '-d',row['class_root'],str(source_copy)]
        need(argv==want,f'{profile}: full original source compile argv differs from exact configured JDK/source closure')
        if row['exit_code']!=0: findings.append(f'{profile}: original full source did not compile; no original runtime expected')
        else:
            root=Path(row['class_root']).resolve(strict=True); facts={}
            need(set(row['class_tree'])=={OUTER+'.class',INTERNAL+'.class'},'original full-source class tree inventory differs')
            need(norm(tree(compare,root))==norm(row['class_tree']),f'{profile}: original class tree differs from live files')
            for rel in sorted(row['class_tree']):
                f=class_facts(compare,physical,root/rel,f'{profile}/{rel}'); need(norm(f)==norm(row['outer_facts'] if rel==OUTER+'.class' else row['target_facts']),f'{profile}/{rel}: full class facts differ from receipt')
                facts[f['class_name']]=f
            need(set(facts)=={OUTER,INTERNAL},f'{profile}: class identities incomplete')
            expected_target_methods={('<init>','()V',0x0001),('test','(C)D',0x0001),('check','()V',0x0001)}
            need({(m['name'],m['descriptor'],m['access']) for m in facts[INTERNAL]['methods']}==expected_target_methods,
                 f'{profile}: exact TestCls method inventory differs')
            need(facts[INTERNAL]['fields']==[],f'{profile}: unexpected TestCls fields')
            physical_by_profile[profile]=facts
            jar=pin(row['bundle'],f'{profile} class bundle'); pin_records+=1
            with zipfile.ZipFile(jar) as z:
                need(sorted(x for x in z.namelist() if not x.endswith('/'))==sorted(row['class_tree']),f'{profile} class JAR members differ')
                for rel in row['class_tree']: need(z.read(rel)==(root/rel).read_bytes(),f'{profile} JAR bytes differ {rel}')
    # Original runtime rows: parentless driver, actual/expected roots, exact case oracle, and cross-VM stability.
    original=[]; python_launcher=None
    for row in data.get('original_runtime',[]):
        cmd=cmd_by[row['command']]; argv=cmd['argv']; root=Path(row['target_root']).resolve(strict=True)
        expected_vm=data['jdk_manifest']['tools'][row['runtime']]['java']['path']
        launcher=Path(argv[0]).resolve(strict=True)
        if python_launcher is None: python_launcher=launcher
        need(launcher==python_launcher and launcher.name.startswith('python'), 'runtime wrapper Python executable differs across captured rows')
        need(len(argv)==13+len(data['dependency_classpath']) and argv[13:]==data['dependency_classpath'] and argv[1:4]==['-B',str(Path(data['runtime_wrapper']['path']).resolve()),'30']
             and Path(argv[5]).resolve()==Path(expected_vm).resolve() and argv[6]=='-Xverify:all' and argv[7]=='-cp'
             and Path(argv[8]).resolve()==Path(data['driver_classes'][0]['path']).parent.resolve() and argv[9]==DRIVER,
             'original driver invocation isolation/JDK leg mismatch')
        need(Path(argv[10]).resolve()==root and Path(argv[11]).resolve()==root and Path(argv[4]).resolve()==Path(argv[12]).resolve(),'original CodeSource/cwd argv mismatch')
        cwd=Path(argv[4]).resolve(strict=True); need(not list(cwd.iterdir()),'original runtime cwd not empty after command')
        std=pin(row['stdout'],'original stdout'); err=pin(row['stderr'],'original stderr'); pin_records+=2
        need(std==Path(cmd['streams']['stdout']['path']).resolve() and err==Path(cmd['streams']['stderr']['path']).resolve(),
             'original runtime stream row does not match its command')
        rows=parse_rows(std.read_bytes(),names)
        issues=oracle_check(rows,cases); row['static_hypothesis_issues']=issues
        need(row['exit_code']==0 and cmd['exit_code']==0,'original runtime did not complete')
        original.append((row['profile'],row['runtime'],rows))
    need(len(original)==4 and len({(p,r) for p,r,_ in original})==4,'original runtime grid incomplete')
    need(data.get('runtime_semantic_agreement') is True and data.get('check_runtime_agreement') is True,
         'collector did not record stable case/check observations within each VM')
    need(data.get('check_jdk23_pass') is True,'JDK23 original check() did not pass in both source profiles')
    canonical=semantic_rows(original[0][2])
    need(all(semantic_rows(rows)==canonical for _,_,rows in original),
         'original semantic observations differ across profiles/VMs')
    check_outcomes={f'{p}/{r}':{'result':rows[0]['check_result'],'exception_type':rows[0]['check_exception_type'],'stdout':rows[0]['check_stdout'],'exception_message':rows[0]['check_exception_message']} for p,r,rows in original}
    need(data.get('check_results_by_runtime')==check_outcomes,'recorded check() outcomes differ from raw runtime output')
    original_diagnostics={f'{profile}/{runtime}':diagnostic_rows(rows) for profile,runtime,rows in original}
    baseline={(p,r):rows for p,r,rows in original}
    for p in PROFILES:
        for vm in RUNTIMES:
            matches=[rows for pp,rr,rows in original if pp==p and rr==vm]
            need(len(matches)==1,'duplicate or missing original runtime cell')
    # APIs: exact 8 cells, method inventories/maps tied to the proper physical target class.
    api_cells=data.get('jarde_cells',[]); api_map={}; api_content={}
    expected_api={(p,INTERNAL,f,e) for p in PROFILES for f in FORMS for e in EVIDENCE}
    for c in api_cells:
        key=(c['profile'],c['api_class'],c['input_form'],c['evidence']); need(key not in api_map and key in expected_api,f'duplicate/unknown API cell {key}')
        api_map[key]=c; cmd=cmd_by[c['command']]; report_path=pin(c['report'],f'API report {key}'); pin_records+=1
        raw=report_path.read_bytes(); need(raw==Path(cmd['streams']['stdout']['path']).read_bytes(),f'{key}: report bytes differ from stdout')
        doc=json.loads(raw.decode('utf-8','strict')); whole=pin(c['whole_source'],f'whole source {key}'); pin_records+=1
        whole_bytes=whole.read_bytes()
        need(bool(whole_bytes) and isinstance(doc.get('text'),str) and bool(doc['text'].strip()),f'{key}: whole class-source text is empty')
        need(whole_bytes==doc.get('text','').encode('utf-8'),f'{key}: whole source differs from API text')
        need(cmd['label']==f"jarde-{key[0]}-target-{key[2]}-{key[3]}",'API label/selector mismatch')
        argv=cmd['argv']; policy='single-class' if key[2]=='child' else 'plain-jar'
        expected_argv=[str(cli),'class-source','--input',str(Path(c['input']['path']).resolve()),'--class',key[1],
                       '--policy',policy,'--release','8','--format','json']
        if key[3]=='all': expected_argv += ['--evidence','all']
        need(argv==expected_argv,f'{key}: actual CLI arguments differ from exact selected input/evidence request')
        need(cmd['exit_code']==0 and c['exit_code']==0,f'{key}: API command did not return a successful complete report')
        facts=physical_by_profile.get(key[0],{}).get(key[1]); need(facts is not None,f'{key}: no physical class facts')
        physical_methods={(m['name'],m['descriptor']):m for m in facts['methods']}; seen=[]; raw_docs={}; semantic_methods={}
        for raw_method in doc.get('methods',[]):
            item=raw_method.get('item',{}); mk=(item.get('name',{}).get('escaped'),item.get('descriptor',{}).get('escaped'))
            need(mk not in raw_docs,f'{key}: duplicate raw API method {mk}')
            raw_docs[mk]=raw_method
        for m in c.get('methods',[]):
            mk=(m.get('name'),m.get('descriptor')); seen.append(mk)
            pm=physical_methods.get(mk); need(pm is not None and mk in raw_docs,f'{key}: API method not in physical class/report {mk}')
            raw_method=raw_docs[mk]; raw_identity=raw_method.get('item',{}).get('identity',{})
            raw_owner=raw_identity.get('owner')
            need(raw_owner==doc.get('class'),f'{key}/{mk}: method owner differs from report class identity')
            need(m.get('identity')==raw_identity and m.get('owner')==raw_owner
                 and m.get('location')==raw_owner.get('location') and m.get('variant')==raw_owner.get('variant'),
                 f'{key}/{mk}: summary method identity differs from raw report')
            raw_outcome=raw_method.get('outcome',{}); raw_body=raw_outcome.get('report',{})
            need(isinstance(raw_body.get('text'),str) and bool(raw_body['text'].strip()),f'{key}/{mk}: raw method source text is empty')
            need(m.get('outcome_kind')==raw_outcome.get('kind') and m.get('quality')==raw_body.get('quality')
                 and m.get('fallbacks')==raw_body.get('fallbacks') and m.get('regions')==raw_body.get('regions')
                 and m.get('raw_text')==raw_body.get('text') and m.get('source_map')==raw_body.get('source_map'),
                 f'{key}/{mk}: method summary differs from full raw report')
            identity_key=json.dumps(raw_identity,sort_keys=True,separators=(',',':'))
            need(identity_key not in semantic_methods,f'{key}: duplicate full method identity {mk}')
            semantic_methods[identity_key]={'identity':raw_identity,'quality':raw_body.get('quality'),
                                            'text':raw_body.get('text'),'source_map':raw_body.get('source_map')}
            audit=method_map_audit(raw_method,pm)
            need(m.get('map_audit')==audit,f'{key}/{mk}: stored map audit differs from independent recomputation')
            if audit['issues']: findings.append(f'{key}/{mk}: map findings {audit["issues"]}')
            if audit['unmapped_physical_bcis']: findings.append(f'{key}/{mk}: unmapped physical BCIs {audit["unmapped_physical_bcis"]}')
        need(sorted(seen)==sorted(physical_methods) and set(raw_docs)==set(physical_methods),'API method inventory does not match physical class inventory')
        api_content[key]={'whole_source_bytes':whole_bytes,'whole_source_sha256':hashlib.sha256(whole_bytes).hexdigest(),
                          'methods':semantic_methods}
        input_path=pin(c['input'],f'API input {key}'); pin_records+=1
        prof=profile_by[key[0]]
        if key[2]=='child': need(input_path==Path(prof['class_root'])/(key[1]+'.class'),'API child input differs from selected class')
        else: need(input_path==Path(prof['bundle']['path']),'API bundle input differs from full original JAR')
    need(set(api_map)==expected_api and len(api_cells)==len(expected_api),'full target API grid is incomplete')
    default_all_comparisons=[]
    for profile in PROFILES:
        for internal in (INTERNAL,):
            for form in FORMS:
                d=api_content[(profile,internal,form,'default')]
                allc=api_content[(profile,internal,form,'all')]
                default_methods=d['methods']; all_methods=allc['methods']
                identities_equal=set(default_methods)==set(all_methods)
                quality_equal=identities_equal and all(default_methods[k]['quality']==all_methods[k]['quality'] for k in default_methods)
                text_equal=identities_equal and all(default_methods[k]['text']==all_methods[k]['text'] for k in default_methods)
                maps_equal=identities_equal and all(default_methods[k]['source_map']==all_methods[k]['source_map'] for k in default_methods)
                row={'profile':profile,'api_class':internal,'input_form':form,
                     'whole_source_bytes_equal':d['whole_source_bytes']==allc['whole_source_bytes'],
                     'whole_source_sha256_equal':d['whole_source_sha256']==allc['whole_source_sha256'],
                     'method_identities_equal':identities_equal,'method_quality_equal':quality_equal,
                     'method_text_equal':text_equal,'method_source_maps_equal':maps_equal}
                row['equal']=all(row[k] for k in ('whole_source_bytes_equal','whole_source_sha256_equal',
                    'method_identities_equal','method_quality_equal','method_text_equal','method_source_maps_equal'))
                default_all_comparisons.append(row)
                for check in ('whole_source_bytes_equal','method_identities_equal','method_quality_equal','method_text_equal','method_source_maps_equal'):
                    if not row[check]: findings.append(f'{profile}/{internal}/{form}: default/all {check} is false')
    stable=all(row['equal'] for row in default_all_comparisons)
    # Full JADX trees are recorded with their exact complete class-bundle input and argv.
    jadx_by={}
    for output in data.get('jadx_outputs',[]):
        profile=output.get('compiler_profile'); need(profile in PROFILES and profile not in jadx_by,'duplicate/unknown JADX profile')
        jadx_by[profile]=output; row=cmd_by[output['command']]
        input_path=pin(output['input'],'JADX full-bundle input'); pin_records+=1
        prof=profile_by[profile]; need(input_path==Path(prof['bundle']['path']).resolve(strict=True),'JADX input is not the full original source bundle')
        argv=row['argv']; dest=Path(argv[-2]).resolve()
        expected_argv=[str(JADX),'--threads-count','1','--no-res','--config','none','-d',str(dest),str(input_path)]
        need(argv==expected_argv and row['label']==f'jadx-full-bundle-{profile}-default','JADX argv/flags/profile differ')
        source_rows=output.get('sources',[]); source_paths=[pin(item,'JADX generated source') for item in source_rows]
        pin_records+=len(source_rows)
        if row['exit_code']!=0: findings.append(f'{profile}: full-source JADX command exited {row["exit_code"]}; raw failure retained')
        actual_sources=sorted(dest.rglob('*.java')) if dest.exists() else []
        need([str(x.resolve()) for x in actual_sources]==[str(x.resolve()) for x in source_paths],f'{profile}: complete JADX source tree inventory differs')
    need(set(jadx_by)==set(PROFILES),'JADX full-source profile inventory incomplete')
    # Generated source inventory is exact; the complete outer and nested target source remain captured.
    cells=data.get('generated_source_cells',[]); cell_by={}
    expected_jarde_cells={(p,f,e) for p in PROFILES for f in FORMS for e in EVIDENCE}
    expected_jadx_cells={(p,'whole-outer-target-tree','default') for p in PROFILES}
    for cell in cells:
        key=(cell.get('kind'),cell.get('profile'),cell.get('form'),cell.get('evidence'))
        need(key not in cell_by,f'duplicate generated source cell {key}'); cell_by[key]=cell
        source_paths=cell.get('source_paths',[]); source_pins=cell.get('source_pins',[]); copies=cell.get('source_copies',[])
        need(len(source_paths)>=len(source_pins)==len(copies),f'{key}: source file/pin/copy inventory length differs')
        for i,(pin_row,copy_row) in enumerate(zip(source_pins,copies)):
            sp=pin(pin_row,f'{key} original API source {i}'); cp=pin(copy_row,f'{key} copied source {i}')
            pin_records+=2
            need(cp.read_bytes()==sp.read_bytes(),f'{key}: source copy differs from full API output')
        if cell.get('kind')=='jarde':
            need(key[1:] in expected_jarde_cells,f'unexpected Jarde source cell {key}')
            need(len(source_paths)==1 and cell.get('api_roles')==['target'],f'{key}: selected target source output slot is required')
            if cell.get('source_available') is True:
                need(len(source_pins)==1 and all(x is not None for x in source_paths),f'{key}: selected target source lacks a pin')
                api_files=cell.get('api_java_files',[]); need(len(api_files)==1,f'{key}: selected target source copy missing')
                need(cell.get('dependency_mode')=='selected-target-source' and cell.get('java_files')==api_files,
                     f'{key}: generated selected target source differs')
            else: findings.append(f'{key}: selected API source outputs unavailable; no source-pair compile inferred')
        elif cell.get('kind')=='jadx':
            need(key[1:] in expected_jadx_cells,f'unexpected JADX source cell {key}')
            if cell.get('source_available') is True:
                need(len(source_pins)==len(source_paths)>0,f'{key}: complete JADX source tree pin inventory differs')
                copied_paths=[row.get('path') for row in copies]
                need(cell.get('java_files')==copied_paths,f'{key}: full JADX copied source tree was not selected')
            else: findings.append(f'{key}: full JADX source files unavailable')
        else: raise AuditError(f'unknown generated source kind in {key}')
    need({key for key in cell_by if key[0]=='jarde'}=={('jarde',p,f,e) for p,f,e in expected_jarde_cells},'Jarde generated source cell grid incomplete')
    need({key for key in cell_by if key[0]=='jadx'}=={('jadx',*key) for key in expected_jadx_cells},'JADX generated source profile grid incomplete')

    # Successful generated compilations are parsed from complete outputs; failures remain observations.
    eligible={}; compiles=data.get('generated_source_compilations',[]); generated_class_roots={}; compile_keys=set()
    for c in compiles:
        key=(c['kind'],c['profile'],c.get('form'),c.get('evidence'),c['compiler']); need(key not in compile_keys,f'duplicate generated compiler cell {key}')
        compile_keys.add(key)
        cmd=cmd_by[c['command']]; need(cmd['exit_code']==c['exit_code'],'generated compile command/exit mismatch')
        for stream in ('stdout','stderr'):
            stream_path=pin(c[stream],f'{key} {stream}'); pin_records+=1
            need(stream_path==Path(cmd['streams'][stream]['path']).resolve(strict=True),f'{key}: compile {stream} not bound to command stream')
        cell=cell_by.get(key[:4]); need(cell is not None,f'{key}: no corresponding generated source cell')
        srcpaths=c.get('source_paths') or []
        need(srcpaths==cell.get('java_files') and bool(srcpaths),'generated compiler did not use the exact full selected source closure')
        argv=cmd['argv']; manifest_tools=data['jdk_manifest']['tools']
        need(argv[0]==manifest_tools[key[4]]['javac']['path'],f'{key}: compiler leg differs from pinned JDK tool')
        debug_arg='-g' if key[1]=='debug' else '-g:none'
        prefix=[argv[0]]+(['-source','8','-target','8',debug_arg] if key[4]=='javac8' else ['--release','8',debug_arg])
        suffix=['-encoding','UTF-8','-proc:none','-classpath',':'.join(data['dependency_classpath']),
                '-sourcepath',data['empty_classpath'],'-d',c['class_root'],*srcpaths]
        need(argv==prefix+suffix,f'{key}: full-source javac argv differs')
        if c['exit_code']!=0: findings.append(f'{key}: complete selected source compile failed; no runtime inferred')
        else:
            root=Path(c['class_root']).resolve(strict=True); need(norm(tree(compare,root))==norm(c['class_tree']),f'{key}: generated class tree differs')
            expected_generated_tree={INTERNAL+'.class'} if c['kind']=='jarde' else {OUTER+'.class',INTERNAL+'.class'}
            need(set(c['class_tree'])==expected_generated_tree,f'{key}: complete generated source class tree differs from the exact source closure')
            generated_class_roots[str(root)]=c['class_tree']; facts={}
            for rel in c['class_tree']:
                f=class_facts(compare,physical,root/rel,f'{key}/{rel}'); facts[f['class_name']]=f
            required={INTERNAL}
            if not required.issubset(facts): findings.append(f'{key}: generated selected target source did not produce its target binary')
            else:
                good=True; differences=[]
                for internal in required:
                    original_facts=physical_by_profile[c['profile']][internal]; actual=facts[internal]
                    if actual['major']!=52: good=False
                    try: differences.extend(inventory_metadata_differences(original_facts,actual,internal))
                    except AuditError as error: findings.append(f'{key}: {error}'); good=False
                need(c.get('allowed_synthetic_flag_differences',[])==differences,
                     f'{key}: recorded allowed synthetic differences differ from full raw inventories')
                if good and c.get('runtime_eligible') is True: eligible[key]=c
                else: findings.append(f'{key}: complete compiled target/helper inventory not eligible for isolated runtime')
    expected_compile_keys={(cell['kind'],cell['profile'],cell.get('form'),cell.get('evidence'),compiler)
                           for cell in cells if cell.get('source_available') is True for compiler in RUNTIMES}
    need(compile_keys==expected_compile_keys,'generated compiler grid missing/duplicated source/compiler cells')
    # Each successful eligible build has both VMs and a wrong-root attempt; compare only against accepted original rows.
    runtime_by={}; generated_diagnostics={}
    for row in data.get('generated_runtime',[]):
        key=(row['kind'],row['profile'],row.get('form'),row.get('evidence'),row['compiler']); full=key+(row['runtime'],)
        need(full not in runtime_by and key in eligible,f'unknown/duplicate generated runtime {full}')
        runtime_by[full]=row; cmd=cmd_by[row['command']]; argv=cmd['argv']
        need(len(argv)==13+len(data['dependency_classpath']) and argv[13:]==data['dependency_classpath'] and Path(argv[0]).resolve()==python_launcher and argv[9]==DRIVER
             and Path(argv[8]).resolve()==Path(data['driver_classes'][0]['path']).parent.resolve(),
             'generated driver invocation not bound to the captured Python wrapper/parentless classpath')
        need(Path(argv[10]).resolve()==Path(row['class_root']).resolve()==Path(eligible[key]['class_root']).resolve() and Path(argv[11]).resolve()==Path(argv[10]).resolve(),'generated actual/expected roots differ')
        rows=parse_rows(pin(row['stdout'],f'{full} stdout').read_bytes(),names); pin_records+=1
        generated_diagnostics['/'.join(str(x) for x in full)]=diagnostic_rows(rows)
        issues=oracle_check(rows,cases); row['static_hypothesis_issues']=issues
        base_rows=baseline[(row['profile'],row['runtime'])]
        case_match = row['exit_code']==0 and semantic_rows(rows)==semantic_rows(base_rows)
        check_fields=('check_result','check_exception_type','check_stdout')
        check_match = row['exit_code']==0 and bool(rows) and bool(base_rows) and all(rows[0].get(k)==base_rows[0].get(k) for k in check_fields)
        combined_match=case_match and check_match
        need(row.get('case_match') is case_match and row.get('check_match') is check_match
             and row.get('combined_match') is combined_match and row.get('matches_original_oracle') is combined_match,
             f'{full}: recorded case/check/combined comparisons differ from raw rows')
        if not case_match: findings.append(f'{full}: generated case observations differ from original observations')
        if not check_match: findings.append(f'{full}: generated check() exception/stdout differs from original for this VM')
    expected_runs={key+(vm,) for key in eligible for vm in RUNTIMES}
    need(set(runtime_by)==expected_runs,'eligible generated compiles do not have exactly two runtime rows each')
    wrong_by={}
    for row in data.get('generated_wrong_root_controls',[]):
        key=(row['kind'],row['profile'],row.get('form'),row.get('evidence'),row['compiler']); need(key in eligible and key not in wrong_by,'unknown/duplicate generated wrong-root row')
        wrong_by[key]=row; cmd=cmd_by[row['command']]; argv=cmd['argv']
        need(len(argv)==13+len(data['dependency_classpath']) and argv[13:]==data['dependency_classpath']
             and Path(argv[0]).resolve()==python_launcher
             and argv[1:4]==['-B',str(Path(data['runtime_wrapper']['path']).resolve()),'30']
             and Path(argv[5]).resolve()==Path(data['jdk_manifest']['tools']['javac23']['java']['path']).resolve()
             and argv[6:10]==['-Xverify:all','-cp',str(Path(data['driver_classes'][0]['path']).parent.resolve()),DRIVER]
             and Path(argv[10]).resolve()==Path(eligible[key]['class_root']).resolve()
             and Path(argv[11]).resolve()==Path(data['empty_classpath']).resolve()
             and Path(argv[12]).resolve()==Path(argv[4]).resolve(),
             'generated wrong-root argv launcher/roots/dependency URLs/cwd mismatch')
        err=pin(row['stderr'],f'{key} wrong-root stderr').read_bytes(); pin_records+=1
        need(row['exit_code']==1 and b'wrong CodeSource:' in err and row.get('rejected') is True,'wrong-root driver failed to reject expected root')
    need(set(wrong_by)==set(eligible),'eligible generated class roots lack exact wrong-root controls')
    # All saved generated source copies and class snapshots are reopened and compared by exact identity.
    before=data.get('generated_source_output_pins_before',{}); after=data.get('generated_source_output_pins_after',{})
    expected_copy_paths={row['path'] for cell in cells for row in cell.get('source_copies',[])}
    need(isinstance(before,dict) and before.keys()==after.keys() and set(before)==expected_copy_paths,
         'generated source snapshot path inventory differs from exact copied source closure')
    for path,before_pin in before.items():
        before_path=pin(before_pin,f'generated source before {path}'); after_path=pin(after[path],f'generated source after {path}')
        pin_records+=2
        need(before_path==after_path==Path(path).resolve(strict=True)
             and before_pin['bytes']==after[path]['bytes'] and before_pin['sha256']==after[path]['sha256'],
             f'generated source copy changed {path}')
    need(data.get('generated_outputs_unchanged') is True,'collector did not verify generated output immutability')
    trees_before=data.get('generated_class_trees',{}); trees_after=data.get('generated_class_trees_after',{})
    need(isinstance(trees_before,dict) and trees_before.keys()==trees_after.keys(),'generated class snapshot path inventory differs')
    for root,before_tree in trees_before.items():
        root_path=Path(root).resolve(strict=True)
        need(norm(before_tree)==norm(trees_after[root]) and norm(tree(compare,root_path))==norm(before_tree),f'generated class snapshot changed {root}')
        for rel,pin_row in before_tree.items(): pin_records+=1; pin(pin_row,f'{root}/{rel}')
    # Source API outputs and copied complete trees were reopened above; compiler argv
    # is checked against each generated source cell's recorded closure.
    # Original wrong-CodeSource control must fail before invoking test.
    wrong=data.get('wrong_root_control'); need(isinstance(wrong,dict),'original wrong-root control absent')
    wc=cmd_by[wrong['command']]; wa=wc['argv']
    need(wc['exit_code']==wrong['exit_code'] and len(wa)==13+len(data['dependency_classpath'])
         and wa[13:]==data['dependency_classpath'] and Path(wa[0]).resolve()==python_launcher
         and wa[1:4]==['-B',str(Path(data['runtime_wrapper']['path']).resolve()),'30']
         and Path(wa[5]).resolve()==Path(data['jdk_manifest']['tools']['javac23']['java']['path']).resolve()
         and wa[6:10]==['-Xverify:all','-cp',str(Path(data['driver_classes'][0]['path']).parent.resolve()),DRIVER]
         and Path(wa[10]).resolve()==Path(wrong['actual_target_root']).resolve()
         and Path(wa[11]).resolve()==Path(data['empty_classpath']).resolve()
         and Path(wa[12]).resolve()==Path(wa[4]).resolve(), 'original wrong-root argv mismatch')
    wrerr=pin(wrong['stderr'],'original wrong-root stderr').read_bytes(); pin_records+=1
    need(wrong['rejected'] is True and wrong['exit_code']==1 and b'wrong CodeSource:' in wrerr,'original wrong-root did not reject')
    need(not list(Path(wa[4]).resolve(strict=True).iterdir()),'original wrong-root cwd not empty')
    result={'status':'independent-read-only-review','receipt':str(receipt_path),'receipt_sha256':sha(receipt_path),
            'collector_status':data.get('status'),'python_launcher_observed':compare.pin(python_launcher),
            'commands':len(commands),'raw_streams':2*len(commands),
            'reopened_pin_records':pin_records,'original_profiles':sorted(profile_by),'original_vm_cells':len(original),
            'manual_oracle_cases_per_vm':len(names),'original_exception_diagnostics_by_cell':original_diagnostics,
            'generated_exception_diagnostics_by_cell':generated_diagnostics,
            'api_cells':len(api_cells),'api_keys_unique_complete':set(api_map)==expected_api,
            'default_all_text_maps_stable':stable,'default_all_comparisons':default_all_comparisons,'generated_compile_attempts':len(compiles),
            'generated_compile_successes':sum(c['exit_code']==0 for c in compiles),
            'generated_vm_rows':len(runtime_by),'wrong_root_rows':len(wrong_by),'observations':findings,
            'scope':'baseline evidence integrity and bounded runtime observations; not product acceptance'}
    out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    return result
if __name__=='__main__':
    try: print(json.dumps(main(),indent=2,sort_keys=True))
    except Exception as e: raise SystemExit(f'audit failed: {e}')
