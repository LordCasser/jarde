# Loop4 audit repair v3

This audit-only patch keeps the frozen v2 collector, driver, source plan, and source pins in place. The audit script binds `BASE` directly to `/private/tmp/jarde-testbreakinloop4-baseline-prep-luna-v2-20261019` so it reopens the same pinned bundle and its collector/driver/case-plan SHA values.

The closed receipt at `/private/tmp/jarde-testbreakinloop4-baseline-root-v1-20261019/execution.json` records 46 commands and 92 raw streams. The previous audit failed on an index assumption in the original wrong-root argv check. Both original and generated wrong-root commands actually have arguments 13+ as the pinned dependency URLs; v3 checks that exact suffix, the wrapper/JDK/driver/roots, and cwd index for both families. The generated wrong-root dependency tail had already been added to the frozen v2 collector.

Run only the independent audit against the closed capture:

```sh
python3 -B /private/tmp/jarde-testbreakinloop4-baseline-audit-luna-v3-20261019/audit.py \
  --receipt /private/tmp/jarde-testbreakinloop4-baseline-root-v1-20261019/execution.json \
  --cli /private/tmp/jarde-loop2-retry-final-focused-root-v2-20261019/candidate-cli \
  --cli-sha256 7e321a7f4fd6a029540ab169f79572c6ad83e74119900ac6d695290c9c055318 \
  --out /private/tmp/jarde-testbreakinloop4-baseline-audit-output-luna-v3-20261019
```

The original failed audit stderr is preserved at `/private/tmp/jarde-loop45-baseline-launch-root-v1-20261019/loop4-audit.stderr.raw`. No collector or toolchain rerun is part of this repair.


## Audit result

The v3 audit was run against the closed receipt and exited 0 with status `independent-read-only-review`: 46 commands, 92 raw streams, 13,171 reopened pin records, 8 complete API cells, 20 generated compiles attempted (2 succeeded), 4 generated VM rows, and both generated wrong-root controls verified. Original and generated wrong-root argv suffixes matched the pinned dependency URLs. The original JDK 8 `check()` error remained recorded as `UnsupportedClassVersionError` for framework class version 55 versus runtime maximum 52; the four case observations still completed. The audit result file is `/private/tmp/jarde-testbreakinloop4-baseline-audit-output-luna-v3-20261019`. Audit integrity success does not imply product acceptance; its `observations` retain compiler/map gaps and no Jarde runtime is inferred from failed compiles.
