# Loop4/5 public integration test v3 (private preparation)

This package is a private, unexecuted patch candidate. It removes only two decimal-spelling checks for `1024`, one for each target. The structured body may express the same constant as Java hexadecimal floating-point text (`0x1.0000000000000p10d`), so those exact decimal substrings are not stable formatting oracles. The Loop4 `break;` check and all other source-map, all-method structured-body, default/all, and token-call assertions remain unchanged; numeric runtime behavior remains for final VM validation.

The input file was verified byte-for-byte against the closed actual v2 receipt source pin `ddf49b0cec6009cdc6a6e15224f333e74ae6dd9fd742049b49cd2f7ad52cc245`. No workspace file was modified and no toolchain was run.
