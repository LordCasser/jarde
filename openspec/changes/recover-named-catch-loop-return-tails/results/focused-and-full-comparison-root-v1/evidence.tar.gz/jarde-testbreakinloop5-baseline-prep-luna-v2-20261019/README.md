# TestBreakInLoop5 full-source baseline preparation

This private v2 bundle is prepared but unexecuted; v1 is preserved unchanged for review history. It adds strict collector enforcement that `check_exception` and `check_stdout_b64` appear exactly once, on the final case row; reports generated case and `check()` matches separately and combines them as `matches_original_oracle = case_oracle_matches && check_matches_original`; and removes an unused driver output capture parameter without changing observations. `v1-v2.diff` contains the exact textual delta for the collector, auditor, driver, static preflight, and this README. It preserves the complete upstream `TestBreakInLoop5.java` byte-for-byte (1495 bytes; SHA-256 `4aef48802b7dc7cc47c7c03d6c2639103c2913345cb8be8818545e63ed1fea64`), including `TestCls.test(String)`, `check()`, both outer JUnit methods, and every import. No target method was removed or injected. `caseplans.json` retains all five original check inputs in order. The values `2`, `12`, `13312`, `1048576`, and `-1` are source-derived secondary comparisons only; original compiled class observations are the baseline oracle.

The target class binary is `jadx/tests/integration/loops/TestBreakInLoop5$TestCls`. Exact target inventory is public `<init>()V`, public `test(Ljava/lang/String;)J`, and public `check()V`, with no target fields or nested helpers. The driver invokes each `test` input, recording input, return/exception type, stdout, and post-call string; it then reflectively invokes the original `check()` and attaches its exception type/stdout to the final case record. It never invokes outer JUnit methods. Full scanning source remains intact, including `StringBuffer`, `Double.valueOf`, `Math.ceil`, the multiplier update, loop break, and catch return.

The accepted Loop2 collector/auditor was minimally adapted for this complete source. It captures the original full outer/target source compile, JDK 8 framework-55/52 boundary, JDK 23 `--release 8` debug/no-debug builds, full original/JADX outer source tree, all eight Jarde class/JAR × debug/no-debug × default/all API cells, complete generated source trees and selected-target recompiles, both JVM observations, raw stdout/stderr, maps, metadata, physical class inventories and BCI bounds, empty working directories, wrong-CodeSource controls, complete input/source/tool pins, and per-cell failures. Root review is still required before running the collector.

The runtime JVM application classpath remains driver-only. The driver creates a fresh parentless URLClassLoader with the exact target root followed by dependency URLs from the accepted pinned test-harness classpath. The dependency directory/JAR target-leak checks remain active. This allows the real `check()` body to resolve AssertJ while retaining strict target CodeSource verification. If the JDK 8 runtime cannot load a framework class compiled as major 55, the driver's `check_exception` records that observed boundary; it is not treated as a passing assertion. JDK 23 check observations are captured independently. Static case mismatches are recorded for review and do not suppress the remaining original cases or generated runs.

Candidate CLI: `/private/tmp/jarde-loop2-retry-final-focused-root-v2-20261019/candidate-cli` (64,347,312 bytes; SHA-256 `7e321a7f4fd6a029540ab169f79572c6ad83e74119900ac6d695290c9c055318`). Product lineage pin: `618b5e20f27f94ba28ea2f9e4310648718475f82`; this preparation makes no baseline or product-acceptance claim. `pins.json` records every local and external input. `adaptation.diff` is the precise unified diff against the accepted Loop2 scripts/driver; the original copied harness itself remains untouched.

After root review, use fresh output paths:

```sh
python3 -B /private/tmp/jarde-testbreakinloop5-baseline-prep-luna-v2-20261019/collect_baseline.py \
  --out /private/tmp/jarde-testbreakinloop5-baseline-root-v1-20261019 \
  --cli /private/tmp/jarde-loop2-retry-final-focused-root-v2-20261019/candidate-cli \
  --cli-sha256 7e321a7f4fd6a029540ab169f79572c6ad83e74119900ac6d695290c9c055318
python3 -B /private/tmp/jarde-testbreakinloop5-baseline-prep-luna-v2-20261019/audit.py \
  --receipt /private/tmp/jarde-testbreakinloop5-baseline-root-v1-20261019/execution.json \
  --cli /private/tmp/jarde-loop2-retry-final-focused-root-v2-20261019/candidate-cli \
  --cli-sha256 7e321a7f4fd6a029540ab169f79572c6ad83e74119900ac6d695290c9c055318 \
  --out /private/tmp/jarde-testbreakinloop5-baseline-review-root-v1-20261019
```

`python3 -B /private/tmp/jarde-testbreakinloop5-baseline-prep-luna-v2-20261019/static_preflight.py` parses the Python scripts and reopens source/plan/driver/CLI pins only. It does not execute JDK, Java, JADX, Jarde CLI, Cargo, Git, or network operations.
