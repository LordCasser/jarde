#!/usr/bin/env python3
"""Read-only source/plan/script preflight; invokes no toolchain."""
from pathlib import Path
import ast, hashlib, json, re
BASE=Path(__file__).parent
SOURCE=Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestBreakInLoop5.java')
CLI=Path('/private/tmp/jarde-loop2-retry-final-focused-root-v2-20261019/candidate-cli')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,msg):
    if not ok: raise SystemExit(msg)
plan=json.loads((BASE/'caseplans.json').read_text())
raw=SOURCE.read_bytes()
need(len(raw)==1495 and sha(SOURCE)=='4aef48802b7dc7cc47c7c03d6c2639103c2913345cb8be8818545e63ed1fea64','upstream full source pin differs')
need((BASE/'source-plan-copy/TestBreakInLoop5.java').read_bytes()==raw,'source-plan copy differs')
need((BASE/'source/jadx/tests/integration/loops/TestBreakInLoop5.java').read_bytes()==raw,'collector complete source copy differs')
need(sha(BASE/'caseplans.json')=='aa3c2c501444f07f582dc895da03756463ae13e5d842ede10ef47c7c0c9091b8','plan pin differs')
need(plan['schema']=='test-break-in-loop5-source-plan-v1' and plan['method']['descriptor']=='(Ljava/lang/String;)J','plan target differs')
need([c['input'] for c in plan['cases']]==['1.2','12am','13m','1G4',''],'all five original inputs must remain ordered')
need(plan['case_contract']['invoke_check'] is True and len(plan['original_check']['assertions'])==5,'original check assertions missing')
text=raw.decode('utf-8')
for token in ['public long test(String spaceStr)','public void check()','StringBuffer sb = new StringBuffer()','for (int i = 0; i < spaceStr.length(); i++)','Double.valueOf(sb.toString())','Math.ceil','catch (Exception e)','return -1;']:
    need(token in text,'complete source behavior missing: '+token)
for p in (BASE/'collect_baseline.py',BASE/'audit.py',BASE/'runtime-bound-cwd.py'):
    ast.parse(p.read_text(),filename=str(p))
need(sha(BASE/'driver/TestBreakInLoop5Driver.java')=='28a4ee318fb6f99ea25432ff8ab4f4c0b69a30c3ca4a6019e642f9fd727ae5ce','driver pin differs')
need("CASE_NAMES = ('decimal-natural-end', 'lowercase-invalid-break', 'm-unit', 'g-unit-break', 'empty-parse-failure')" in (BASE/'collect_baseline.py').read_text(),'collector case set differs')
need("check_exception" in (BASE/'collect_baseline.py').read_text() and 'getDeclaredMethod("check")' in (BASE/'driver/TestBreakInLoop5Driver.java').read_text(),'check execution protocol absent')
collector=(BASE/'collect_baseline.py').read_text()
need('check() fields must occur exactly once, on the final case row' in collector,'collector check-field placement guard absent')
need(all(x in collector for x in ['case_oracle_matches','check_matches_original','matches_original_oracle']), 'generated runtime match fields missing')
need('capturedOut' not in (BASE/'driver/TestBreakInLoop5Driver.java').read_text(),'unused capture output argument remains')
need("'-cp', driver_classes" in (BASE/'collect_baseline.py').read_text() and "'-Dtest.dependencies=' + classpath_text" in (BASE/'collect_baseline.py').read_text(),'runtime app classpath/dependency URL boundary differs')
need("new URLClassLoader(urls(actual), null)" in (BASE/'driver/TestBreakInLoop5Driver.java').read_text(),'parentless target loader contract missing')
need(re.search(r"COLLECTOR_SHA='([0-9a-f]+)'",(BASE/'audit.py').read_text()).group(1)==sha(BASE/'collect_baseline.py'),'auditor collector pin stale')
need(re.search(r"CASE_PLAN_SHA256 = '([0-9a-f]+)'",(BASE/'collect_baseline.py').read_text()).group(1)==sha(BASE/'caseplans.json'),'collector plan pin stale')
print('STATIC_PREFLIGHT_OK: complete source, source-derived cases, check invocation, scripts parse; no tool was executed')
