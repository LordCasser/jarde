# Loop45 主规格同步只读审查

## 结果

没有发现原有主规格丢失或重复。同步前文件 `/private/tmp/jarde-loop45-spec-sync-root-v1-20261019/main-before.md` 是当前 `openspec/specs/java8-recovery/spec.md` 的**逐字节前缀**。当前主规格仅在原文后追加两个新 Requirement，Loop4 3 个场景、Loop5 5 个场景共 8 个；两个 Requirement 名和 8 个 Scenario 名均各出现一次，没有把 delta 重复追加。移除两个 delta 的 `## ADDED Requirements` 包装标题后，主规格新增 tail 与这两个 delta 正文按顺序逐字相同。

当前主规格新增位置：Loop4 Requirement 第1328行；Loop5 Requirement 第1347行。旧内容完整保留，新增段落分别与两个 change delta 内容对应。

## 场景与实现/观察契约

- **Loop4 conditional break body（3场景）**：场景1要求完整 TestBreakInLoop4、构造器/test/check structured、for 的 init/update、条件赋值与 break、全图不再遗漏17/23/29，并以原件对照运行四个既定输入。现有实现入口是 `region.rs::loop_break_branch_body` / `loop_break_body_route`（当前约22441、22640行）：自然循环集合不扩大，只在分支 owner DAG 闭合时把条件体接入既有区域；现有 Reader 正例验证 owner 和 break来源。场景2对额外入口、不同出口、回边、异常、已占用与不可表达候选规定拒绝；场景3要求真实 break来源、Stop 原因/用量、default/all 和有效映射。这些是输出/拒绝/运行可见契约，没有要求 Jarde 复刻 Jadx 的 `for`/`while` 拼写。
- **Loop5 named catch return tail（5场景）**：场景1用完整 TestBreakInLoop5 的五个基准输入及原件对照描述行为，并要求完整方法与 check；场景2把范围右边界 return 的物理事实和 try/catch 求值位置说清楚；场景4、5规定 foreign scope/不完整 owner 拒绝及原子停止。与 `region.rs::certified_try_return_tail`（当前约11007行）所做的 named-row、single terminal return 和完整 prefix+loop+tail 证明匹配。Loop4 与 Loop5 的普通三方/整类编译/VM/check/source-map 接受仍由 OpenSpec tasks 的全量矩阵执行，不由这些局部 Reader 测试代替。
- **Loop5 catch slot scenario**：当前主规格描述可观察语义——handler 收到的异常绑定不应被当作同物理槽普通 double 的写入，错误 handler/path/slot、非入口值/写入保持拒绝及逃逸检查；已不暴露内部 Store/Stack0-Phi 实现细节。对应当前 Builder `decide_types` 分支（`build.rs` 约2938行）复用精确 `RegionPaths.catch_parameters` identity 检查 handler entry store 及本 handler 自身 stack-0 Phi；普通槽拆分、通用 Phi 放宽、强转均未加入。

新增场景限定在两个已命名原件及其证明边界，没有并入 finally/retry、任意多尾/多循环、一般槽重类型或其他 CF09 特性。Loop5 12-case扩展 oracle、native/full workspace 和 own-CI 仍是验收任务，不是已发生的结果；必须继续按两个 OpenSpec tasks 待填并等待完整运行/独立审计后再打勾。

## 输入 pins

见同目录 `inputs.sha256`。本审查只读规格、design/tasks 与已集成代码位置；没有读取运行中的三方 collector，也没有运行工具链。
