import hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
OUT=Path('/private/tmp/jarde-loop45-integration-root-v1-20261019');assert not OUT.exists();OUT.mkdir()
L4=Path('/private/tmp/jarde-loop4-break-body-impl-luna-v2-20261019')
L5=Path('/private/tmp/jarde-loop5-return-tail-impl-luna-v2-20261019')
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
region=ROOT/'crates/jarde-java/src/region.rs';assert pin(region)['sha256']=='f0087dcf55aa691a3a57e491265474d6645f836f301372fcfec003f63f444fb5'
candidate=L4/'crates/jarde-java/src/region.rs';assert pin(candidate)['sha256']=='79de99d3e0754ad9dae3225d6813bff03728859111d80ce053d8f8c6c91cde03'
r={'status':'integrating_uncompiled','inputs':[pin(p) for p in [region,candidate,L4/'loop4.patch',L5/'region.patch',L5/'finite_loop_catch_tests.patch',L5/'loop5_return_tail_tests.rs']]}
text=candidate.read_text()
bad='self\n            .canonical\n            .edges()\n            .edges()\n            .len()';assert text.count(bad)==1;text=text.replace(bad,'self\n            .canonical\n            .edges()\n            .len()',1)
start=text.index('    fn header_tested_loop(');finish=text.index('    fn statementful_loop_header(',start)
section=text[start:finish]
block_start=section.index('        let loop_break_body = if side_exit.is_none() && exit_gateway.is_none() {')
block_end=section.index('        if let Some(proof) = &loop_break_body {',block_start)
section=section[:block_start]+section[block_end:]
anchor='        let mut body_frame = frame.loop_body(\n';assert section.count(anchor)==1
proof='''        let loop_break_body = if side_exit.is_none() && exit_gateway.is_none() {
            self.loop_break_branch_body(
                header_node,
                blocks,
                &exits,
                exit_node,
                for_header
                    .as_ref()
                    .and_then(|proof| self.view.index_of(&proof.update_block))
                    .unwrap_or(header_node),
                frame,
            )?
        } else {
            None
        };
'''
section=section.replace(anchor,proof+anchor,1)
poll_block='''        if (side_exit.is_some() || loop_break_body.is_some())
            && let Err(stop) = poll(self.budget, Some(header.bci()))
        {
            if let Some(state) = body_state.take() {
                self.restore_loop_body_trial_state(state);
            }
            return Err(stop);
        }
'''
assert section.count(poll_block+poll_block)==1;section=section.replace(poll_block+poll_block,poll_block,1)
assert '.saturating_mul(8);' in section
section=section.replace('.saturating_mul(8);','.saturating_mul(MAX_REGION_DEPTH)\n                .saturating_mul(3);',1)
text=text[:start]+section+text[finish:]
region.write_text(text)
target=ROOT/'crates/jarde-java/src/region/loop_break_body_tests.rs';assert not target.exists();target.write_bytes((L4/'crates/jarde-java/src/region/loop_break_body_tests.rs').read_bytes())
patch=(L5/'region.patch').read_text();tail=patch.rsplit('\n@@',1)[1];assert 'statementful_loop_header_tests' in tail and tail.endswith('\n+\n');patch=patch.rsplit('\n@@',1)[0]+'\n'
adapted=OUT/'loop5-without-noop-eof.patch';adapted.write_text(patch)
for p in [adapted,L5/'finite_loop_catch_tests.patch']:
    subprocess.run(['git','apply','--check',str(p)],cwd=ROOT,check=True)
    subprocess.run(['git','apply',str(p)],cwd=ROOT,check=True)
target5=ROOT/'crates/jarde-java/src/region/loop5_return_tail_tests.rs';assert not target5.exists()
test=(L5/'loop5_return_tail_tests.rs').read_text();assert test.count('catch_joins: BTreeSet<usize>,')==1
test=test.replace('catch_joins: BTreeSet<usize>,','catch_joins: BTreeSet<(usize, usize)>,',1);target5.write_text(test)
r['root_corrections']=['remove invalid duplicate edges() call','prove break body before exits moves into Frame','remove duplicate adjacent poll','preserve conservative depth-scaled region scan bound','drop noop EOF-only Loop5 patch hunk','correct Loop5 snapshot catch-join tuple type']
r['outputs']=[pin(p) for p in [region,target,target5,ROOT/'crates/jarde-java/src/region/finite_loop_catch_tests.rs']]
(OUT/'integration.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':r['status'],'corrections':r['root_corrections']}))
