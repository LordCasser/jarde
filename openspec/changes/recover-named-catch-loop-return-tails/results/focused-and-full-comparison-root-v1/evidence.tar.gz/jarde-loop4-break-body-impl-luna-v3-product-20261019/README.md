# Loop4 owner-route integration repair — private v3

This narrow patch is based on the exact pre-L5-integration shared `region.rs` snapshot SHA-256 `f2fc004ab7cce991f972dbfc68596828be5a5d50ce28fde74cf500a177c85cd3`; root has since integrated L5 changes, so apply only these small Loop4 hunks to the current tree and preserve the concurrent L5 code.

The closed owner trace showed a valid certificate for natural-loop BCIs 5/11/36 and external route owners 17/23/29, but `region_at(11)` retained only the first nested region: branch 17 fell back at continuation 29 while visits to 23/29 remained in Walker state. Exact-owner checking correctly refused that mismatch.

The patch makes two certificate-local changes. For an if inside a certified route, if its direct successor is both the current frame boundary and another proof owner, that boundary is elected as this nested if's local join before the method-wide postdominator. This preserves the parent route's lexical continuation without changing `forward_join` globally. At the certified root branch, the existing `loop_body_sequence` consumes the contiguous external route through its straight assignment/goto owner and stops at the certified break exit or in-loop stay. Exact ownership checks remain unchanged.

The late-stop Reader test now requires the unlimited direct run to contain an actual header-5 `Loop` with a `ForHeader` before deriving its measured cutoff. Previously any nonempty fallback could qualify, so the one-short budget stopped at the expected-owner precharge before reaching the final latch scan. The test still checks interruption, full Walker-state restoration, and no refund of spent budget.

`loop4-v3.patch` contains only the two source changes and test strengthening. `v2-v3.diff` shows the private delta. This patch was not compiled or run and includes no transient diagnostic output; root owns integration and toolchain validation.
