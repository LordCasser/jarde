import hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
BASE=Path('/private/tmp/jarde-loop5-extended-cases-prep-luna-v2-20261019')
OUT=Path('/private/tmp/jarde-loop5-extended-original-root-v1-20261019')
assert not OUT.exists() and not (ROOT/'target').exists()
OUT.mkdir();(OUT/'raw').mkdir();(OUT/'driver-classes').mkdir()
def pin(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(p):
    got=pin(p['path']);assert got['bytes']==p['bytes'] and got['sha256']==p['sha256'],str(p['path'])
def all_pins(value):
    if isinstance(value,dict):
        if {'path','bytes','sha256'}<=value.keys():yield value
        else:
            for v in value.values():yield from all_pins(v)
    elif isinstance(value,list):
        for v in value:yield from all_pins(v)
plan=json.loads((BASE/'plan/commands.json').read_text());pins=json.loads((BASE/'plan/pins.json').read_text())
baseline=json.loads(Path(plan['baseline_execution_json']).read_text())
def external():
    records={p['path']:p for p in all_pins(pins)}
    for directory,rows in baseline['dependency_directory_pins'].items():
        d=Path(directory);actual={str(p.relative_to(d)) for p in d.rglob('*') if p.is_file()}
        assert actual==set(rows),directory
        records.update({p['path']:p for p in rows.values()})
    records[baseline['dependency_harness_jar']['path']]=baseline['dependency_harness_jar']
    for profile in baseline['source_profiles']:
        records.update({p['path']:p for p in profile['class_tree'].values()})
    for p in records.values():verify(p)
    return [pin(p) for p in sorted(records)]
spec=importlib.util.spec_from_file_location('extended_parser',BASE/'parse_extended_receipts.py');parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
r={'status':'running','launcher':pin(__file__),'plan':pin(BASE/'plan/commands.json'),'parser':pin(BASE/'parse_extended_receipts.py'),'commands':[],'runtimes':[],'source':'unchanged complete frozen Loop5 originals; no target code modified','inputs_before':external()}
env={k:v for k,v in os.environ.items() if k not in ['JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','CARGO_TARGET_DIR','RUST_MIN_STACK']}
def save(): (OUT/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
def run(argv,label):
    i=len(r['commands'])+1;so=OUT/'raw'/f'{i}.stdout.raw';se=OUT/'raw'/f'{i}.stderr.raw'
    with so.open('xb') as a,se.open('xb') as b: result=subprocess.run(argv,cwd=ROOT,env=env,stdout=a,stderr=b,timeout=45)
    row={'index':i,'label':label,'argv':argv,'exit_code':result.returncode,'stdout':pin(so),'stderr':pin(se)};r['commands'].append(row);save();return row
def argv_for(template,**values): return [p.format(**values) for p in template]
try:
    compile=run(argv_for(plan['compile_argv_template'],private_driver_classes=str(OUT/'driver-classes')),'compile-standalone-driver-javac8');assert compile['exit_code']==0
    r['driver_class_tree']=[pin(p) for p in sorted((OUT/'driver-classes').rglob('*')) if p.is_file()]
    assert len(r['driver_class_tree'])==1
    for cell,template in plan['runtime_argv_templates'].items():
        profile,runtime=cell.split('/');actual=next(x['actual_root'] for x in plan['profiles'] if x['name']==profile)
        cwd=OUT/f'empty-{profile}-{runtime}';cwd.mkdir()
        argv=argv_for(template,private_driver_classes=str(OUT/'driver-classes'),empty_cwd=str(cwd),actual_root=actual,expected_codesource=actual)
        cmd=run(argv,cell);assert cmd['exit_code']==0 and Path(cmd['stderr']['path']).read_bytes()==b''
        observation=parser.parse_lines(Path(cmd['stdout']['path']).read_text().splitlines(),cell);parser.validate_plan(observation,plan,cell)
        assert all(x['exception']=='none' and x['target_stdout']=='' for x in observation['cases'])
        assert observation['check']['exception']==('none' if runtime=='javac23' else 'java.lang.UnsupportedClassVersionError') and observation['check']['stdout']==''
        original=next(x for x in baseline['original_runtime'] if x['profile']==profile and x['runtime']==runtime)
        assert [(x['name'],x['input'],x['result'],x['exception'],x['target_stdout'],x['after']) for x in observation['cases'][:5]]==[(x['name'],x['input'],x['result'],x['exception_type'],x['target_stdout'],x['after']) for x in original['rows']]
        assert not any(cwd.iterdir())
        r['runtimes'].append({'profile':profile,'runtime':runtime,'command':cmd['index'],'actual_root':actual,'observation':observation});save()
    assert all(parser.case_projection(x['observation'])==parser.case_projection(r['runtimes'][0]['observation']) for x in r['runtimes'])
    wrong=OUT/'wrong-codesource';wrong.mkdir();cwd=OUT/'empty-wrong-control';cwd.mkdir()
    actual=plan['profiles'][0]['actual_root'];argv=argv_for(plan['runtime_argv_templates']['debug/javac23'],private_driver_classes=str(OUT/'driver-classes'),empty_cwd=str(cwd),actual_root=actual,expected_codesource=str(wrong))
    control=run(argv,'wrong-codesource-control');assert control['exit_code']==1 and Path(control['stdout']['path']).read_bytes()==b'' and 'wrong CodeSource' in Path(control['stderr']['path']).read_text();assert not any(cwd.iterdir())
    r['status']='original_extended_oracles_captured_pending_independent_review'
except BaseException as error:
    r.update(status='failed',error=repr(error));raise
finally:
    r['inputs_after']=external();r['inputs_unchanged']=r['inputs_before']==r['inputs_after'];r['driver_classes_after']=[pin(p) for p in sorted((OUT/'driver-classes').rglob('*')) if p.is_file()];r['driver_classes_unchanged']=r.get('driver_class_tree')==r['driver_classes_after'];r['target_absent']=not (ROOT/'target').exists();save();print(json.dumps({k:r.get(k) for k in ['status','error','inputs_unchanged','driver_classes_unchanged','target_absent']}))
assert r['inputs_unchanged'] and r['driver_classes_unchanged'] and r['target_absent']
