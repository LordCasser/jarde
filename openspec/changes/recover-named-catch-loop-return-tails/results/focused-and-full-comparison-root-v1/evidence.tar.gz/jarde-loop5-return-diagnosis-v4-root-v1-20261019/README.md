# Loop5 named-row return-tail v4 candidate

This private candidate is based on the stable integrated source snapshot pinned in `pins.json`. It contains a narrow route-gate correction and direct test alignment; shared sources remain untouched. No Rust toolchain or repository command was run.

The v3 production recovery failed because `recover()` places both endpoints of canonical Exception and Call edges in `excluded_edge_nodes`. Loop5 owners 60 and 81 are exception sources, so `loop_break_body_route` rejected them before the existing named-row owner proof could validate them. The standalone positive test had an empty excluded set and did not model production.

The candidate computes one `excluded_or_leaving` condition and allows those route owners only when the current frame has a named try context and `named_loop_owner_edges_accounted` succeeds. That proof checks the exact physical row, canonical handler identity, exception throw-site range, and canonical exception-edge attribution; it rejects Call and Return edges. The existing complete `named_loop_scope_edges` proof remains downstream. The direct test now constructs the same Exception|Call endpoint inventory as production and confirms missing named context and a foreign row are refused.

`candidate.patch` is the exact unified diff against the two pinned base files. `commands.json` gives the root's focused test command; it was not run here. Static checks passed.
