//! Temporary read-only probe of the four frozen original Loop4/Loop5 target classes.
//! This module is appended to finite_loop_catch_tests.rs only for the root-run test.
use super::*;

const LOOP4_DEBUG: &[u8] = include_bytes!(
    "/private/tmp/jarde-testbreakinloop4-baseline-root-v1-20261019/debug/classes/jadx/tests/integration/loops/TestBreakInLoop4$TestCls.class"
);
const LOOP4_NO_DEBUG: &[u8] = include_bytes!(
    "/private/tmp/jarde-testbreakinloop4-baseline-root-v1-20261019/no-debug/classes/jadx/tests/integration/loops/TestBreakInLoop4$TestCls.class"
);
const LOOP5_DEBUG: &[u8] = include_bytes!(
    "/private/tmp/jarde-testbreakinloop5-baseline-root-v1-20261019/debug/classes/jadx/tests/integration/loops/TestBreakInLoop5$TestCls.class"
);
const LOOP5_NO_DEBUG: &[u8] = include_bytes!(
    "/private/tmp/jarde-testbreakinloop5-baseline-root-v1-20261019/no-debug/classes/jadx/tests/integration/loops/TestBreakInLoop5$TestCls.class"
);

fn dump_one(label: &str, bytes: &[u8], expected_len: usize, descriptor: &[u8]) {
    assert_eq!(bytes.len(), expected_len, "{label}: frozen class length");
    super::with_frozen_method_ir(bytes, b"test", descriptor, |canonical, view, ssa, operations, code, recovered| {
        eprintln!("LOOP45_IR {label}: decoded-code={:#?}", code.instructions);
        eprintln!("LOOP45_IR {label}: physical-exception-rows={:#?}", code.exception_handlers);
        for instruction in &code.instructions {
            eprintln!("LOOP45_IR {label}: operation bci={} opcode={:#04x} operation={:?}",
                instruction.bci, instruction.opcode, operations.get(instruction.bci));
        }
        eprintln!("LOOP45_IR {label}: canonical-blocks={:#?}", canonical.blocks());
        eprintln!("LOOP45_IR {label}: canonical-edges-all-kinds={:#?}", canonical.edges());
        eprintln!("LOOP45_IR {label}: canonical-unreachable={:#?}", canonical.unreachable());
        eprintln!("LOOP45_IR {label}: normal-flow-ids={:#?}", view.ids());
        for id in view.ids() {
            eprintln!("LOOP45_IR {label}: normal-successors block={id:?} successors={:?}", view.successor_ids(id));
        }
        eprintln!("LOOP45_IR {label}: all-ssa-phis={:#?}", ssa.phis());
        for block in ssa.blocks() {
            for instruction in block.instructions() {
                eprintln!("LOOP45_IR {label}: ssa-instruction block={:?} bci={} reads={:?} writes={:?} operation={:?}",
                    block.block(), instruction.bci(), instruction.reads(), instruction.writes(), operations.get(instruction.bci()));
            }
        }
        let mut natural_count = 0usize;
        for node in 0..view.len() {
            let Some(natural) = view.loop_entered_at(node) else { continue };
            if natural.header() != node { continue; }
            natural_count += 1;
            let header = view.id_of(node).expect("natural-loop header");
            let members = natural.blocks().iter().filter_map(|n| view.id_of(*n).cloned()).collect::<Vec<_>>();
            let latches = natural.latches().iter().filter_map(|n| view.id_of(*n).cloned()).collect::<Vec<_>>();
            let member_nodes = natural.blocks().clone();
            let exits = canonical.edges().iter().filter(|edge| {
                matches!(edge.kind(), CanonicalEdgeKind::Normal)
                    && view.index_of(edge.from()).is_some_and(|n| member_nodes.contains(&n))
                    && view.index_of(edge.to()).is_some_and(|n| !member_nodes.contains(&n))
            }).collect::<Vec<_>>();
            let ipdom = view.immediate_post_dominator(node).and_then(|n| view.id_of(n)).cloned();
            eprintln!("LOOP45_IR {label}: natural-loop header={header:?} blocks={members:?} latches={latches:?} exits={exits:?} ipdom={ipdom:?} irreducible={}", natural.is_irreducible());
        }
        if natural_count == 0 { eprintln!("LOOP45_IR {label}: natural-loops=none"); }
        eprintln!("LOOP45_IR {label}: recovered-complete={recovered:#?}");
        eprintln!("LOOP45_IR {label}: recovered-region-tree={:#?}", recovered.regions);
        eprintln!("LOOP45_IR {label}: recovered-claimed={:#?}", recovered.claimed);
        eprintln!("LOOP45_IR {label}: recovered-fallbacks={:#?}", recovered.fallbacks());
    });
}

#[test]
fn dump_real_loop45_ir_and_region_result() {
    for (label, bytes, len, descriptor) in [
        ("loop4/debug", LOOP4_DEBUG, 1015usize, b"(C)D".as_slice()),
        ("loop4/no-debug", LOOP4_NO_DEBUG, 682usize, b"(C)D".as_slice()),
        ("loop5/debug", LOOP5_DEBUG, 1899usize, b"(Ljava/lang/String;)J".as_slice()),
        ("loop5/no-debug", LOOP5_NO_DEBUG, 1403usize, b"(Ljava/lang/String;)J".as_slice()),
    ] {
        dump_one(label, bytes, len, descriptor);
    }
}
