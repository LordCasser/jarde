# Loop4/Loop5 same-run IR probe preparation

This private probe bundle is prepared but unexecuted. It reads the four exact original target `.class` files named by the two completed baseline `execution.json` receipts: Loop4 debug/no-debug and Loop5 debug/no-debug. `pins.json` records each receipt path, exact class path, byte count, SHA-256, and the current shared helper's byte count/SHA-256. The Rust test checks each class length before analysis; SHA-256 values remain pinned in `pins.json` and are checked during preparation.

The probe is designed as a temporary child module of `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/region/finite_loop_catch_tests.rs`. It calls the existing private `super::with_frozen_method_ir` helper directly, so it reuses the exact current reader, `plan_four_conditional_strings`, normal-flow construction, and region recovery path. It does not define another Reader, walker, or budget path. The callback is observation-only: it prints decoded instructions, physical exception rows, operations, canonical blocks/edges/unreachable IDs, normal-flow IDs and successors, SSA phis and instruction reads/writes/operations, natural loop headers/members/latches/exits/immediate post-dominators, the full recovered value and region tree, claimed IDs, and fallbacks. It makes no positive recovery assertions and does not claim a fix.

Root can temporarily append this module declaration to the shared helper, execute the exact command in `commands.json`, then restore the shared helper byte-for-byte from the `helper` pin in `pins.json` in a `finally` path and clean any target output. This preparation does not perform that shared edit or run Cargo. Root should apply the 5 GiB free-space and 1 GiB target guards, retain the default stack, and restore the helper byte-for-byte in `finally`, then verify target cleanup.

```rust
#[path = "/private/tmp/jarde-loop45-ir-probe-prep-luna-v1-20261019/probe.rs"]
mod loop45_original_ir_probe;
```

Exact command:

```sh
cargo test -p jarde-java --lib region::finite_loop_catch_tests::loop45_original_ir_probe::dump_real_loop45_ir_and_region_result -- --exact --nocapture
```

`probe.rs` is the sole test source. This directory also includes `commands.json`, `pins.json`, and `README.md`. No Rust command was run during preparation.
