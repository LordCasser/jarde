from pathlib import Path
import hashlib, json, re

BASE = Path("/Users/lordcasser/workspace/projects/jarde")
HERE = Path("/private/tmp/jarde-loop4-break-body-impl-luna-v1-20261019")
PINS = json.loads((HERE / "pins.json").read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(BASE / "crates/jarde-java/src/region.rs") == PINS["source_base"]["sha256"]
assert PINS["source_base"]["sha256"] == PINS["base_source_sha_expected"]
for key in ("private_region", "private_test", "patch"):
    assert sha(Path(PINS[key]["path"])) == PINS[key]["sha256"], key
for fixture in PINS["fixtures"].values():
    path = Path(fixture["path"])
    assert path.stat().st_size == fixture["bytes"] and sha(path) == fixture["sha256"]
source = (HERE / "crates/jarde-java/src/region.rs").read_text()
test = (HERE / "crates/jarde-java/src/region/loop_break_body_tests.rs").read_text()
assert source.count("break_body: None") == source.count("LoopTarget {") - 1, "initialize every non-default LoopTarget literal"
assert "proved_break_body_join" in source and "loop_break_body_edges_closed" in source
assert "loop_break_body_acyclic" in source and "loop_break_body_branch_eligible" in source
assert "mod loop_break_body_tests;" in source
for bci in ("17", "23", "29", "26", "33"):
    assert bci in test
assert "assert_eq!(breaks, [26, 33])" in test
assert "CancellationToken" in test and "analysis_steps: 0" in test
assert "loop_break_body_edges_closed" in test and "loop_break_body_acyclic" in test
patch=(HERE / "loop4.patch").read_text()
assert "loop_break_body_tests.rs" in patch and "proved_break_body_join" in patch
print("static preflight: pins and expected patch wiring verified; no toolchain invoked")
