# Loop4 proved break-body private patch

This private patch implements the unprotected header-tested Loop4 slice from OpenSpec `recover-proved-loop-break-branch-bodies` tasks 2.1/2.2. Shared checkout files were read only. No Rust/JVM/JADX/Jarde toolchain, Git, Cargo, CLI, network, Atlas write, formatter, or test was run here.

The implementation keeps the natural loop set and existing ForHeader proof intact. A private `LoopBreakBodyProof` records the exact header, branch, external entry, in-loop stay, break exit, and external owners. `Walker::loop_break_branch_body` admits one unique candidate only in the already-scoped unprotected context. Its route proof checks decoded comparison branches, transfer opcodes at direct break edges, acyclicity, exact external entry, closed canonical normal edges, predecessor agreement with `NormalFlowView`, no natural/visited/scope collisions, and bounded budget polling/charging. The certificate extends only the current body frame and expected body owners. `proved_break_body_join` is selected before the generic join path. Body trial state restores the walker’s mutable ownership/auxiliary state on a stop; budget usage remains consumed.

`loop_break_body_tests.rs` adds Reader-backed tests for both frozen debug profiles, complete claimed ownership, blocks 17/23/29, ForHeader init/update/slot, break origins 26/33, no duplicate owners, occupied and parent-scope refusal, mutated external-entry/extra-exit/exception/back-edge rows, switch rejection, and budget/pre-cancellation stops. These tests are authored only; they have **not** been compiled or executed. The OpenSpec late-stop rollback requirement is implemented in the loop trial path; the parent should run the planned stop-boundary integration tests after review.

The expected-value numbers from static analysis are not used as an oracle in these tests. Reader-produced canonical/SSA/normal-flow facts are the test input. The frozen class file fixtures are independently pinned below; root’s already-copied full outer/source/JAR fixture remains outside this private patch.

## Review files

- `loop4.patch`: unified patch against the pinned `region.rs` plus new test module.
- `crates/jarde-java/src/region.rs`: private full source copy with implementation.
- `crates/jarde-java/src/region/loop_break_body_tests.rs`: new tests.
- `pins.json`: source, fixture, OpenSpec, patch, and private-file SHA-256 pins.
- `static_preflight.py`: read-only Python checks for pins, constructor initialization, gate wiring, and patch inclusion.

## Apply/verify plan for the root

1. Confirm the shared `region.rs` still matches `source_base.sha256` in `pins.json`, and review `loop4.patch` before applying it.
2. Run `python3 -B /private/tmp/jarde-loop4-break-body-impl-luna-v1-20261019/static_preflight.py` (read-only).
3. Integrate the patch serially, then run the Reader-backed module and required workspace gates under the OpenSpec design’s resource guards. Record actual outcomes; no result is implied by this private preparation.

OpenSpec tasks 2.1/2.2 remain unchecked until root review and real test execution. The patch is private and not integrated.
