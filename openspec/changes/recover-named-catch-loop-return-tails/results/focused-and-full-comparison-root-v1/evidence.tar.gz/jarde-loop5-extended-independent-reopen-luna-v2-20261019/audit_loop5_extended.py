import base64,hashlib,json
from pathlib import Path
OUT=Path('/private/tmp/jarde-loop5-extended-independent-reopen-luna-v2-20261019')
RECEIPT=Path('/private/tmp/jarde-loop5-extended-final-root-v2-20261019/execution.json')
def need(ok,msg):
    if not ok: raise AssertionError(msg)
def pin(path):
    b=Path(path).read_bytes(); return {'path':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def parse_raw(path):
    cases=[];check=None
    for line_no,line in enumerate(Path(path).read_bytes().decode('utf-8').splitlines(),1):
        p=line.split();need(bool(p),f'{path}:{line_no}: blank')
        kind=p[0];f={}
        for token in p[1:]:
            k,sep,v=token.partition('=');need(sep and k not in f,f'{path}:{line_no}: malformed/duplicate field');f[k]=v
        dec=lambda k:base64.b64decode(f[k],validate=True).decode('utf-8')
        if kind=='CASE':
            need(check is None and set(f)=={'index','name','input_kind','input_label_b64','input_b64','result_b64','exception','exception_message_b64','exception_stack_b64','target_stdout_b64','after_kind','after_b64'},f'{path}:{line_no}: CASE fields')
            ik=f['input_kind'];ak=f['after_kind'];label=dec('input_label_b64');need(ik in ('string','null') and ak==ik,f'{path}:{line_no}: kinds')
            if ik=='null': need(label=='<JAVA_NULL>' and f['input_b64']==f['after_b64']=='-',f'{path}:{line_no}: null');inp=after=None
            else: inp=dec('input_b64');after=dec('after_b64');need(inp==after==label,f'{path}:{line_no}: input')
            cases.append({'index':int(f['index']),'name':f['name'],'input_kind':ik,'input_label':label,'input':inp,'result':dec('result_b64'),'exception':f['exception'],'exception_message':dec('exception_message_b64'),'exception_stack':dec('exception_stack_b64'),'target_stdout':dec('target_stdout_b64'),'after_kind':ak,'after':after})
        elif kind=='CHECK':
            need(check is None and len(cases)==12 and set(f)=={'exception','exception_message_b64','exception_stack_b64','stdout_b64'},f'{path}:{line_no}: CHECK fields/order')
            check={'exception':f['exception'],'exception_message':dec('exception_message_b64'),'exception_stack':dec('exception_stack_b64'),'stdout':dec('stdout_b64')}
        else: raise AssertionError(f'{path}:{line_no}: unknown record')
    need(len(cases)==12 and [x['index'] for x in cases]==list(range(12)) and check is not None,f'{path}: expected 12 CASE + CHECK')
    return {'cases':cases,'check':check}
def tree(root):
    root=Path(root);need(root.is_dir() and not root.is_symlink(),f'unsafe class root {root}');d={}
    for p in sorted(root.rglob('*')):
        need(not p.is_symlink(),f'symlink {p}')
        if p.is_file():
            q=pin(p);d[p.relative_to(root).as_posix()]={'bytes':q['bytes'],'sha256':q['sha256']}
    return d
def external_pins(obj):
    found={}
    def walk(v):
        if isinstance(v,dict):
            if {'path','bytes','sha256'}<=set(v):found[v['path']]=v
            else:
                for z in v.values():walk(z)
        elif isinstance(v,list):
            for z in v:walk(z)
    for k in ('inputs_before','external_input_pins_before','source_pins_before','local_copy_pins_before','generated_source_output_pins_before','dependency_jar_pins','dependency_directory_pins'):walk(obj.get(k))
    return found
r=json.loads(RECEIPT.read_text(encoding='utf-8'));need(r['status']=='complete','extended receipt is not closed')
need(len(r['runs'])==20 and r['expected_run_count']==r['passed_run_count']==20,'expected exactly 20 VM runs')
O=Path('/private/tmp/jarde-loop5-extended-original-root-v1-20261019');o=json.loads((O/'execution.json').read_text(encoding='utf-8'))
need(len(o['runtimes'])==4,'expected four original oracle VMs')
oracles={}
for x in o['runtimes']:
    k=(x['profile'],x['runtime']);p=O/'raw'/f'{x["command"]}.stdout.raw';oracles[k]={'observation':parse_raw(p),'pin':pin(p)}
need(len(oracles)==4,'oracle runtime matrix')
run_reports=[];groups={}
for x in r['runs']:
    i=x['index'];actual=parse_raw(x['stdout']['path']);expected=oracles[(x['identity']['profile'],x['runtime'])]
    so=pin(x['stdout']['path']);se=pin(x['stderr']['path'])
    need(so==x['stdout'] and se==x['stderr'],f'run {i}: stdout/stderr pin mismatch')
    need(x['status']=='passed' and x['exit_code']==x['parser_exit_code']==0,f'run {i}: status')
    need(actual['cases']==expected['observation']['cases'],f'run {i}: CASE field mismatch')
    need(all(actual['check'][k]==expected['observation']['check'][k] for k in ('exception','exception_message','stdout')),f'run {i}: CHECK semantic mismatch')
    need(x['parser_comparison_flags']['cases_match'] is True and x['parser_comparison_flags']['check_semantics_match'] is True,f'run {i}: parser flags')
    need(x['reopened_comparison']['cases_match_all_fields'] is True and x['reopened_comparison']['check_semantics_match_type_message_stdout'] is True,f'run {i}: reopened flags')
    need(x['repository_target_absent_before_vm'] and x['repository_target_absent_after_vm'],f'run {i}: target guard')
    need(x['cwd_empty_after'] and not list(Path(x['cwd']).iterdir()),f'run {i}: cwd')
    need(x['application_classpath']==['/private/tmp/jarde-loop5-extended-original-root-v1-20261019/driver-classes'],f'run {i}: app classpath')
    need(x['expected_codesource']==x['class_root'] and x['class_root'] not in x['dependency_urls'],f'run {i}: target/dependency/code source')
    av=x['argv'];need(av[av.index('-cp')+1]==x['application_classpath'][0] and '-Xverify:all' in av and any('runtime-bound-cwd.py' in z for z in av),f'run {i}: JVM argv')
    run_reports.append({'run_index':i,'compilation_index':x['compilation_index'],'profile':x['identity']['profile'],'runtime':x['runtime'],'identity':x['identity'],'stdout_pin':so,'stderr_pin':se,'oracle_stdout_pin':expected['pin'],'case_records':len(actual['cases']),'check_records':1,'all_case_fields_match':True,'check_type_message_stdout_match':True,'driver_only_app_cp':True,'target_absent_from_dependency_urls':True,'codesource_matches_target_root':True,'cwd_empty_after':True})
    groups.setdefault(x['compilation_index'],[]).append(x)
C=json.loads(Path(r['comparison_path']).read_text(encoding='utf-8'));eligible=[(i,z) for i,z in enumerate(C['generated_source_compilations']) if z.get('exit_code')==0 and z.get('runtime_eligible') is True]
need(len(eligible)==10 and set(groups)=={i for i,_ in eligible},'eligible compilation inventory')
for i,row in eligible:
    pair=groups[i];need(len(pair)==2 and {z['runtime'] for z in pair}=={'javac8','javac23'},f'compilation {i}: runtime pair')
    ident={k:row.get(k) for k in ('kind','profile','form','evidence','compiler','command')};need(all(z['identity']==ident for z in pair),f'compilation {i}: identity')
    root=Path(row['class_root']);decl={Path(v['path']).resolve().relative_to(root.resolve()).as_posix():{'bytes':v['bytes'],'sha256':v['sha256']} for v in row['class_tree'].values()};need(tree(root)==decl,f'compilation {i}: class tree')
external_counts={}
for name,obj in (('oracle',o),('comparison',C)):
    ps=external_pins(obj);need(bool(ps),f'{name}: no pins')
    for p,expected in ps.items():need(pin(p)==expected,f'{name}: external pin mismatch {p}')
    external_counts[name]=len(ps)
for p in r['prep_pins_after']:need(pin(p['path'])==p,f'prep pin mismatch {p["path"]}')
DT=O/'driver-classes';driver_tree=[pin(p) for p in sorted(DT.rglob('*')) if p.is_file()]
need(driver_tree==o['driver_class_tree'],'frozen driver class tree mismatch')
need(all(r[k] is True for k in ('comparison_unchanged','oracle_unchanged','prep_unchanged','external_pins_unchanged','generated_trees_unchanged','driver_classes_unchanged','repository_target_absent_after','collector_output_target_absent','five_gib_free_remaining')),'final collector guards')
cases=next(iter(oracles.values()))['observation']['cases']
need(any(z['input'] is None and z['result']=='return=-1' for z in cases),'actual null')
need(any(z['input']=='15M' and z['result']=='return=15360' for z in cases),'M case')
need(any(z['input']=='2g' and z['result']=='return=2097152' for z in cases),'g case')
need(any(z['input']=='999999999999999999999999999' and z['result']=='return=9223372036854775807' for z in cases),'oversized case')
need(any(z['input']=='1..2' and z['result']=='return=-1' for z in cases),'repeated decimal point')
need(any(z['input']=='0M' and z['result']=='return=0' for z in cases),'zero case')
source=Path('/private/tmp/jarde-loop5-extended-cases-prep-luna-v2-20261019/driver/TestBreakInLoop5ExtendedDriver.java').read_text()
need('new URLClassLoader(urls(actual), null)' in source and 'target.getClassLoader() != loader' in source and 'origin.equals(expected)' in source and 'requireEmptyCwd(cwd)' in source,'driver source contract')
report={'schema':'jarde.loop5.extended-independent-reopen.v2','status':'passed','receipt':pin(RECEIPT),'counts':{'generated_vm_runs':20,'generated_stdout_raws':20,'generated_stderr_raws':20,'generated_raw_stream_files_total':40,'generated_case_records':240,'generated_check_records':20,'original_oracle_vm_runs':4,'original_oracle_stdout_raws':4,'original_oracle_case_records':48,'original_oracle_check_records':4},'eligible_compilations':10,'per_compilation_runtime_pair':['javac8','javac23'],'omitted_or_deduplicated_eligible_rows':False,'checks':{'all_240_case_records_all_fields_match':True,'all_20_check_type_message_stdout_match':True,'stacks_preserved_and_case_stack_compared':True,'check_stack_preserved_but_not_in_semantic_equality':True,'raw_stdout_and_stderr_pins_recomputed':True,'all_class_trees_reopened':True,'driver_only_application_cp':True,'parentless_loader_and_codesource_assertions_in_pinned_driver_source':True,'code_source_equals_actual_target_root_all_20_runs':True,'target_absent_from_dependency_urls_all_20_runs':True,'all_cwds_empty':True,'all_external_pins_recomputed':True,'all_prep_tool_source_pins_recomputed':True,'driver_class_pin_reopened':True,'target_and_final_receipt_guards_pass':True},'external_pin_counts':external_counts,'stimuli':{'actual_null_returns_minus_one':True,'15M_returns_15360':True,'2g_returns_2097152':True,'oversized_decimal_returns_long_max':True,'1_dotdot_2_returns_minus_one':True,'0M_returns_zero':True},'runs':run_reports,'counting_note':'Each of 20 VM runs has one stdout and one stderr raw file (40 total files). Only the 20 stdout observations contain CASE records: 20 × 12 = 240. Receipt reopen data is verification of those same streams, not additional runs.'}
path=OUT/'audit.json';path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':report['status'],'script':str(Path(__file__).resolve()) if '__file__' in globals() else 'script saved by launcher below','audit':str(path),'counts':report['counts'],'external_pin_counts':external_counts},ensure_ascii=False,indent=2))
