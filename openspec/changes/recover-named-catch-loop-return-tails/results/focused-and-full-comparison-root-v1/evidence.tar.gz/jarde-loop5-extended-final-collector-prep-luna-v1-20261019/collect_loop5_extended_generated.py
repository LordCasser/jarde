#!/usr/bin/env python3
"""Run the frozen 12-case Loop5 driver over every eligible class tree in a closed comparison receipt."""
from __future__ import annotations
import argparse,base64,hashlib,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
ORACLE=Path('/private/tmp/jarde-loop5-extended-original-root-v1-20261019')
BASELINE=Path('/private/tmp/jarde-testbreakinloop5-baseline-root-v1-20261019')
PREP=Path('/private/tmp/jarde-loop5-extended-cases-prep-luna-v2-20261019')
PARSER=PREP/'parse_extended_receipts.py'
PLAN=PREP/'plan/commands.json'
PREP_MANIFEST=PREP/'manifest.json'
PREP_PINS=PREP/'plan/pins.json'
SELF_ROOT=Path(__file__).resolve().parent
SELF_PINS=(SELF_ROOT/'pins.json',SELF_ROOT/'plan.json',SELF_ROOT/'collect_loop5_extended_generated.py')
DRIVER_ROOT=ORACLE/'driver-classes'
DRIVER_CLASS='TestBreakInLoop5ExtendedDriver'
OUTER_TIMEOUT=45
CASE_FIELDS={'index','name','input_kind','input_label_b64','input_b64','result_b64','exception','exception_message_b64','exception_stack_b64','target_stdout_b64','after_kind','after_b64'}
CHECK_FIELDS={'exception','exception_message_b64','exception_stack_b64','stdout_b64'}
CASE_TEXT=('index','name','input_kind','input_label','input','result','exception','exception_message','exception_stack','target_stdout','after_kind','after')
CHECK_TEXT=('exception','exception_message','stdout')

def digest(data): return hashlib.sha256(data).hexdigest()
def file_pin(path):
    path=Path(path); data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':digest(data)}
def b64(value): return base64.b64decode(value,validate=True).decode('utf-8')
def parse_raw(path):
    rows=[]; check=None; lines=Path(path).read_bytes().decode('utf-8').splitlines()
    for line_no,line in enumerate(lines,1):
        parts=line.split()
        if not parts: raise ValueError(f'{path}:{line_no}: blank record')
        kind=parts[0]; fields={}
        for token in parts[1:]:
            if '=' not in token: raise ValueError(f'{path}:{line_no}: malformed field')
            key,value=token.split('=',1)
            if key in fields: raise ValueError(f'{path}:{line_no}: duplicate field {key}')
            fields[key]=value
        if kind=='CASE':
            if check is not None or set(fields)!=CASE_FIELDS: raise ValueError(f'{path}:{line_no}: CASE order/fields invalid')
            index=int(fields['index']); ik=fields['input_kind']; ak=fields['after_kind']
            if ik not in ('string','null') or ak!=ik: raise ValueError(f'{path}:{line_no}: bad input/after kind')
            label=b64(fields['input_label_b64'])
            if ik=='null':
                if label!='<JAVA_NULL>' or fields['input_b64']!='-' or fields['after_b64']!='-': raise ValueError('invalid actual-null encoding')
                inp=after=None
            else:
                inp=b64(fields['input_b64']); after=b64(fields['after_b64'])
                if inp!=label or after!=inp: raise ValueError('input/after decoded values disagree')
            rows.append({'index':index,'name':fields['name'],'input_kind':ik,'input_label':label,'input':inp,
                         'result':b64(fields['result_b64']),'exception':fields['exception'],
                         'exception_message':b64(fields['exception_message_b64']),
                         'exception_stack':b64(fields['exception_stack_b64']),
                         'target_stdout':b64(fields['target_stdout_b64']),
                         'after_kind':ak,'after':after})
        elif kind=='CHECK':
            if check is not None or len(rows)!=12 or set(fields)!=CHECK_FIELDS: raise ValueError('CHECK must follow twelve CASE records exactly once')
            check={'exception':fields['exception'],'exception_message':b64(fields['exception_message_b64']),
                   'exception_stack':b64(fields['exception_stack_b64']),'stdout':b64(fields['stdout_b64'])}
        else: raise ValueError(f'{path}:{line_no}: unknown record kind {kind}')
    if len(rows)!=12 or [x['index'] for x in rows]!=list(range(12)) or check is None:
        raise ValueError(f'{path}: expected CASE 0..11 then CHECK')
    return {'cases':rows,'check':check,'raw_line_count':len(lines)}
def case_projection(obs): return [{k:r[k] for k in CASE_TEXT} for r in obs['cases']]
def check_semantics(obs): return {k:obs['check'][k] for k in CHECK_TEXT}
def compare(actual,oracle):
    return {'cases_match_all_fields':case_projection(actual)==case_projection(oracle),
            'check_semantics_match_type_message_stdout':check_semantics(actual)==check_semantics(oracle),
            'actual_check_stack_preserved':actual['check']['exception_stack'],
            'oracle_check_stack_preserved':oracle['check']['exception_stack']}
def tree_snapshot(root):
    root=Path(root)
    if root.is_symlink() or not root.is_dir(): raise ValueError(f'unsafe class root {root}')
    result={}
    for path in sorted(root.rglob('*')):
        if path.is_symlink(): raise ValueError(f'symlink beneath class root: {path}')
        if path.is_file():
            data=path.read_bytes(); result[path.relative_to(root).as_posix()]={'bytes':len(data),'sha256':digest(data)}
    return result
def declared_tree(row,root):
    expected={}
    for rel,item in row.get('class_tree',{}).items():
        path=Path(item['path'])
        try: path.resolve().relative_to(Path(root).resolve())
        except ValueError: raise ValueError(f'compiled class path escapes class root: {path}')
        expected[rel]={'bytes':item['bytes'],'sha256':item['sha256']}
    return expected
def external_pins(receipt):
    pins={}
    def visit(value):
        if isinstance(value,dict):
            if {'path','bytes','sha256'}<=set(value):
                pins[value['path']]=value
                return
            for child in value.values(): visit(child)
        elif isinstance(value,list):
            for child in value: visit(child)
    for key in ('inputs_before','external_input_pins_before','source_pins_before','local_copy_pins_before','generated_source_output_pins_before','dependency_jar_pins','dependency_directory_pins'):
        visit(receipt.get(key))
    checked=[]
    for expected in pins.values():
        path=Path(expected['path'])
        if not path.is_file() or path.is_symlink(): raise ValueError(f'external pin missing/unsafe: {path}')
        actual=file_pin(path)
        if actual['bytes']!=expected['bytes'] or actual['sha256']!=expected['sha256']: raise ValueError(f'external pin mismatch: {path}')
        checked.append(actual)
    return sorted(checked,key=lambda x:x['path'])
def changed_pins(pins):
    changed=[]
    for expected in pins:
        p=Path(expected['path'])
        try: actual=file_pin(p) if p.is_file() and not p.is_symlink() else None
        except OSError: actual=None
        if actual!=expected: changed.append(expected['path'])
    return changed
def write_json(path,value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def self_test():
    oracle=json.loads((ORACLE/'execution.json').read_text())
    obs=[]
    for run in oracle['runtimes']: obs.append(parse_raw(ORACLE/'raw'/f'{run["command"]}.stdout.raw'))
    if len(obs)!=4 or any(len(x['cases'])!=12 for x in obs): raise SystemExit('expected four frozen 12-case oracle runs')
    if any(x['cases'][10]['input'] is not None or x['cases'][10]['result']!='return=-1' for x in obs): raise SystemExit('actual-null raw self-test failed')
    left={'cases':obs[0]['cases'],'check':dict(obs[0]['check'])}; right={'cases':[dict(x) for x in left['cases']],'check':dict(left['check'])}
    right['cases'][0]['target_stdout']='changed'
    if compare(right,left)['cases_match_all_fields']: raise SystemExit('case-field negative self-test failed')
    right['cases'][0]['target_stdout']=left['cases'][0]['target_stdout']; right['check']['exception_stack']='changed line number'
    if not compare(right,left)['check_semantics_match_type_message_stdout']: raise SystemExit('CHECK semantic/stack self-test failed')
    print(json.dumps({'status':'self_test_passed','oracle_runs':4,'cases_per_run':12,'runtime_invoked':False}))
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--comparison',type=Path); ap.add_argument('--out',type=Path); ap.add_argument('--self-test',action='store_true'); a=ap.parse_args()
    if a.self_test: self_test(); return 0
    if a.comparison is None or a.out is None: ap.error('--comparison and --out required')
    comparison=a.comparison.resolve(strict=True); out=a.out.absolute()
    if out.exists(): raise FileExistsError(f'refusing existing output {out}')
    if out.is_symlink() or not str(out).startswith('/private/tmp/'): raise ValueError('out must be fresh under /private/tmp')
    try: out.resolve().relative_to(ROOT)
    except ValueError: pass
    else: raise ValueError('output must be outside the shared repository')
    out.mkdir(parents=True); (out/'raw').mkdir(); (out/'runtime-cwd').mkdir()
    comp_pin=file_pin(comparison); oracle_path=ORACLE/'execution.json'; oracle_pin=file_pin(oracle_path)
    receipt={'schema':'jarde.loop5.extended-generated-runtime.v1','status':'running',
             'comparison_path':str(comparison),'comparison_pin_before':comp_pin,
             'oracle_path':str(oracle_path),'oracle_pin_before':oracle_pin,'runs':[],
             'class_trees_before':[],'errors':[]}
    eligible=[]; original_pins=[]; comparison_pins=[]; prep_pins=[]; driver_tree={}
    try:
        cmp=json.loads(comparison.read_text(encoding='utf-8')); oracle=json.loads(oracle_path.read_text(encoding='utf-8'))
        prep_manifest=json.loads(PREP_MANIFEST.read_text(encoding='utf-8'))
        frozen=[x for x in prep_manifest['files'] if x['path'] in (str(PARSER),str(PLAN),str(PREP_PINS))]
        if len(frozen)!=3: raise ValueError('frozen parser/plan/prep pin files absent from manifest')
        for pin in frozen:
            actual=file_pin(pin['path'])
            if actual['bytes']!=pin['bytes'] or actual['sha256']!=pin['sha256']: raise ValueError(f'frozen prep pin mismatch: {pin["path"]}')
            prep_pins.append(actual)
        plan=json.loads(PLAN.read_text(encoding='utf-8'))
        for path in SELF_PINS: prep_pins.append(file_pin(path))
        frozen_raw={x['path']:x for x in json.loads((SELF_ROOT/'pins.json').read_text(encoding='utf-8'))['original_oracle_raw_streams']}
        for raw_pin in frozen_raw.values():
            actual=file_pin(raw_pin['path'])
            if actual!=raw_pin: raise ValueError(f'original oracle raw-stream pin mismatch: {raw_pin["path"]}')
            prep_pins.append(actual)
        driver_tree=tree_snapshot(DRIVER_ROOT)
        declared_driver={Path(x['path']).relative_to(DRIVER_ROOT).as_posix():{'bytes':x['bytes'],'sha256':x['sha256']} for x in oracle['driver_class_tree']}
        if driver_tree!=declared_driver: raise ValueError('frozen original-oracle driver class tree changed')
        runtime_rows={(x['profile'],x['runtime']):x for x in oracle['runtimes']}
        if len(runtime_rows)!=4: raise ValueError('original oracle runtime matrix is not 2×2')
        oracle_observations={}
        for key,item in runtime_rows.items():
            path=ORACLE/'raw'/f'{item["command"]}.stdout.raw'
            oracle_observations[key]=parse_raw(path)
            if len(oracle_observations[key]['cases'])!=12: raise ValueError(f'oracle cases incomplete for {key}')
            prep_pins.append(file_pin(path))
        original_pins=external_pins(oracle); comparison_pins=external_pins(cmp)
        rows=cmp.get('generated_source_compilations')
        if not isinstance(rows,list): raise ValueError('comparison lacks generated_source_compilations')
        eligible=[(i,x) for i,x in enumerate(rows) if x.get('exit_code')==0 and x.get('runtime_eligible') is True]
        if not eligible: raise ValueError('no successful runtime_eligible compilations in comparison')
        for i,item in eligible:
            root=Path(item['class_root']).resolve(strict=True); before=tree_snapshot(root)
            if not before or before!=declared_tree(item,root): raise ValueError(f'class tree differs from receipt row {i}')
            receipt['class_trees_before'].append({'compilation_index':i,
              'identity':{k:item.get(k) for k in ('kind','profile','form','evidence','compiler','command')},
              'class_root':str(root),'tree':before})
        template_py=next(x for x in oracle['commands'][1]['argv'] if x.endswith('/python3'))
        cmd_id=0
        for row_index,item in eligible:
            root=Path(item['class_root']).resolve(strict=True)
            for runtime in ('javac8','javac23'):
                key=(item['profile'],runtime)
                if key not in runtime_rows: raise ValueError(f'missing original runtime argv {key}')
                argv=list(oracle['commands'][runtime_rows[key]['command']-1]['argv'])
                cmd_id+=1
                cwd=out/'runtime-cwd'/f'row-{row_index:04d}-{item.get("kind")}-{item.get("profile")}-{item.get("form")}-{item.get("evidence")}-{item.get("compiler")}-{runtime}'
                cwd.mkdir(parents=True)
                if list(cwd.iterdir()): raise ValueError(f'cwd was not empty before run: {cwd}')
                argv[4]=str(cwd); argv[-3]=str(root); argv[-2]=str(root); argv[-1]=str(cwd)
                app_cp=argv[argv.index('-cp')+1]
                if app_cp!=str(DRIVER_ROOT): raise ValueError('application classpath differs from frozen driver-only path')
                dep=next(x for x in argv if x.startswith('-Dtest.dependencies=')).split('=',1)[1].split(':')
                if str(root) in dep: raise ValueError('target root appears as a dependency URL')
                rawout=out/'raw'/f'{cmd_id:04d}.stdout.raw'; rawerr=out/'raw'/f'{cmd_id:04d}.stderr.raw'
                run={'index':cmd_id,'compilation_index':row_index,
                     'identity':{k:item.get(k) for k in ('kind','profile','form','evidence','compiler','command')},
                     'runtime':runtime,'class_root':str(root),'expected_codesource':str(root),
                     'application_classpath':[app_cp],'dependency_urls':dep,'cwd':str(cwd),'argv':argv,'status':'started'}
                receipt['runs'].append(run); write_json(out/'execution.json',receipt)
                try:
                    proc=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=OUTER_TIMEOUT,check=False)
                    rawout.write_bytes(proc.stdout); rawerr.write_bytes(proc.stderr)
                    run['exit_code']=proc.returncode; run['stdout']=file_pin(rawout); run['stderr']=file_pin(rawerr)
                    if proc.returncode!=0: raise RuntimeError(f'Java wrapper exit {proc.returncode}')
                    if list(cwd.iterdir()): raise RuntimeError('driver cwd gained files')
                    actual=parse_raw(rawout); expected=oracle_observations[key]; independent=compare(actual,expected)
                    parse_result=out/'parser-results'/f'{cmd_id:04d}.json'
                    oracle_raw=ORACLE/'raw'/f'{runtime_rows[key]["command"]}.stdout.raw'
                    parser_argv=[template_py,'-B',str(PARSER),'--out',str(parse_result),'--against',str(oracle_raw),str(rawout)]
                    parser_proc=subprocess.run(parser_argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=25,check=False)
                    run['parser_argv']=parser_argv; run['parser_exit_code']=parser_proc.returncode
                    if parser_proc.returncode!=0: raise RuntimeError('frozen parser v2 rejected raw observations')
                    parsed=json.loads(parse_result.read_text(encoding='utf-8'))
                    flags=parsed.get('comparison',{}).get(str(rawout))
                    run['parser_result']=file_pin(parse_result); run['parser_comparison_flags']=flags
                    if not isinstance(flags,dict) or flags.get('cases_match') is not True or flags.get('check_semantics_match') is not True:
                        raise RuntimeError(f'frozen parser v2 comparison flags not both true: {flags}')
                    if not independent['cases_match_all_fields'] or not independent['check_semantics_match_type_message_stdout']:
                        raise RuntimeError(f'independent raw comparison differs: {independent}')
                    run['observation']=actual; run['comparison']=independent; run['status']='passed'
                except Exception as error:
                    run['status']='failed'; run['error']=f'{type(error).__name__}: {error}'
                    if not rawout.exists(): rawout.write_bytes(getattr(error,'stdout',None) or b'')
                    if not rawerr.exists(): rawerr.write_bytes(getattr(error,'stderr',None) or b'')
                    run.setdefault('stdout',file_pin(rawout)); run.setdefault('stderr',file_pin(rawerr))
                    receipt['errors'].append({'run_index':cmd_id,'error':run['error']})
                finally:
                    run['cwd_empty_after']=not list(cwd.iterdir())
                    write_json(out/'execution.json',receipt)
        # Independent second reopen of all captured raw outputs.
        for run in receipt['runs']:
            if run.get('status')!='passed': continue
            rawout=Path(run['stdout']['path']); rawerr=Path(run['stderr']['path'])
            if file_pin(rawout)!=run['stdout'] or file_pin(rawerr)!=run['stderr']:
                run['status']='failed'; run['error']='raw bytes/SHA changed after first read'; receipt['errors'].append({'run_index':run['index'],'error':run['error']}); write_json(out/'execution.json',receipt); continue
            obs=parse_raw(rawout); key=(run['identity']['profile'],run['runtime'])
            second=compare(obs,oracle_observations[key])
            run['reopened_observation']=obs
            run['reopened_raw_pins']={'stdout':file_pin(rawout),'stderr':file_pin(rawerr)}
            run['reopened_comparison']=second
            flags=run.get('parser_comparison_flags') or {}
            if flags.get('cases_match') is not True or flags.get('check_semantics_match') is not True or not second['cases_match_all_fields'] or not second['check_semantics_match_type_message_stdout']:
                run['status']='failed'; run['error']='second raw reopen or frozen parser comparison failed'; receipt['errors'].append({'run_index':run['index'],'error':run['error']})
            write_json(out/'execution.json',receipt)
    except Exception as error:
        receipt['status']='failed_partial'
        receipt['errors'].append({'error':f'{type(error).__name__}: {error}'})
    finally:
        receipt['comparison_pin_after']=file_pin(comparison) if comparison.is_file() else None
        receipt['comparison_unchanged']=receipt['comparison_pin_after']==comp_pin
        receipt['oracle_pin_after']=file_pin(oracle_path) if oracle_path.is_file() else None
        receipt['oracle_unchanged']=receipt['oracle_pin_after']==oracle_pin
        receipt['prep_pins_after']=[file_pin(x['path']) for x in prep_pins if Path(x['path']).is_file()]
        receipt['prep_unchanged']=receipt['prep_pins_after']==prep_pins
        receipt['original_external_pins_changed']=changed_pins(original_pins) if original_pins else []
        receipt['comparison_external_pins_changed']=changed_pins(comparison_pins) if comparison_pins else []
        receipt['external_pins_unchanged']=not receipt['original_external_pins_changed'] and not receipt['comparison_external_pins_changed']
        receipt['generated_class_trees_after']=[]
        for entry in receipt['class_trees_before']:
            try: after=tree_snapshot(entry['class_root'])
            except Exception as error: after={'error':f'{type(error).__name__}: {error}'}
            receipt['generated_class_trees_after'].append({'compilation_index':entry['compilation_index'],'class_root':entry['class_root'],'tree':after,'unchanged':after==entry['tree']})
        receipt['generated_trees_unchanged']=all(x['unchanged'] for x in receipt['generated_class_trees_after'])
        receipt['driver_class_tree_after']=tree_snapshot(DRIVER_ROOT) if DRIVER_ROOT.is_dir() else {}
        receipt['driver_classes_unchanged']=receipt['driver_class_tree_after']==driver_tree if driver_tree else False
        receipt['target_absent']=not (out/'target').exists()
        receipt['eligible_compilation_count']=len(eligible)
        receipt['expected_run_count']=2*len(eligible)
        receipt['passed_run_count']=sum(x.get('status')=='passed' for x in receipt['runs'])
        receipt['all_runs_passed']=receipt['expected_run_count']>0 and receipt['passed_run_count']==receipt['expected_run_count']
        checks=('comparison_unchanged','oracle_unchanged','prep_unchanged','external_pins_unchanged','generated_trees_unchanged','driver_classes_unchanged','target_absent','all_runs_passed')
        if receipt['status']!='failed_partial': receipt['status']='complete' if all(receipt.get(k) is True for k in checks) else 'failed'
        write_json(out/'execution.json',receipt)
    return 0 if receipt['status']=='complete' else 1
if __name__=='__main__': raise SystemExit(main())
