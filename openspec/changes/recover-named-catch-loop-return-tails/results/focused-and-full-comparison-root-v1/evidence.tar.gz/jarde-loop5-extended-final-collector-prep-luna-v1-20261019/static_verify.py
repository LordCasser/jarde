#!/usr/bin/env python3
"""Static-only checks for the prepared final Loop5 supplemental runner."""
import ast,hashlib,json,pathlib
out=pathlib.Path(__file__).resolve().parent
script=out/'collect_loop5_extended_generated.py'
ast.parse(script.read_text(encoding='utf-8'))
text=script.read_text(encoding='utf-8')
pins=json.loads((out/'pins.json').read_text(encoding='utf-8'))
plan=json.loads((out/'plan.json').read_text(encoding='utf-8'))
assert plan['status']=='prepared_not_executed'
assert 'runtime-eligible' in plan['selection'] and 'independent of class SHA' in plan['selection']
assert 'cases_match' in text and 'check_semantics_match' in text and 'parser_exit_code' in text
assert 'subprocess.run(argv' in text and 'subprocess.run(parser_argv' in text
assert 'generated_source_compilations' in text and 'target_absent' in text
assert plan['run_count'].startswith('2 ×')
assert pins['baseline_external_dependency_jar_pins'] and pins['baseline_external_dependency_directory_pins']
for item in pins['frozen_prep_files']+pins['original_oracle_raw_streams']+[pins['baseline_execution'],pins['original_oracle_execution']]:
 p=pathlib.Path(item['path']); assert p.is_file() and p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],p
print(json.dumps({'status':'static_preparation_checks_passed','pinned_inputs':True,'runtime_invoked':False}))
