# Loop5 final generated-class supplemental collector preparation

Prepared only. This package has not invoked Java, Jarde CLI, Cargo, Git, network, or Atlas writes.

Later run collect_loop5_extended_generated.py with --comparison pointing to the closed final full collector execution.json and --out pointing to a fresh private directory. The runner selects every generated_source_compilations row whose exit_code is zero and runtime_eligible is true, preserving each row identity; it does not deduplicate identical hashes or omit any profile, form, evidence mode, or compiler. It schedules both JDKs for each selected row.

Commands clone the matching original-oracle runtime argv. Only actual/expected CodeSource root and a fresh empty cwd change. The pinned original driver classes remain the sole application classpath; its wrapper, 30-second runtime limit, -Xverify:all, dependency URLs, and parentless loader remain fixed.

The runner verifies each physical compilation tree against its comparison receipt row before execution and rechecks it after. It also pins and rechecks the comparison receipt, original oracle receipt and raw streams, frozen driver class tree, parser and prep files, all available comparison external inputs, and the complete oracle dependency/JDK inventory. Every stdout/stderr stream is saved immediately, and execution.json is rewritten throughout the run so failures retain their raw outputs and partial receipt. Every process cwd must be empty before and after, and no target directory may exist inside the collector output.

For each run it strictly reopens twelve CASE records plus the separate CHECK from raw bytes, recalculates raw sizes and SHA-256, compares every decoded case field against the same profile/JDK original oracle, and compares CHECK type/message/stdout separately while preserving full stacks. It calls the frozen parser v2 and explicitly requires its cases_match and check_semantics_match flags to be true; parser exit status alone is not accepted. There is no Cargo/build function.

Run collect_loop5_extended_generated.py --self-test for the Python-only check against the already closed four-run original oracle. It launches no runtime.
