import hashlib,json,shutil
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
for number,change in [(4,'recover-proved-loop-break-branch-bodies'),(5,'recover-named-catch-loop-return-tails')]:
    baseline=Path(f'/private/tmp/jarde-testbreakinloop{number}-baseline-root-v1-20261019')
    receipt=baseline/'execution.json'; facts=json.loads(receipt.read_text())
    dest=ROOT/'tests/fixtures'/change
    assert not dest.exists()
    manifest={'schema':'complete-upstream-loop-fixtures-v1','baseline':pin(receipt),'files':[]}
    def copy(source,relative,expected=None):
        source=Path(source); original=pin(source)
        if expected:
            assert original['bytes']==expected['bytes'] and original['sha256']==expected['sha256']
        target=dest/relative; target.parent.mkdir(parents=True,exist_ok=True)
        assert not target.exists();shutil.copyfile(source,target)
        after=pin(target);assert (after['bytes'],after['sha256'])==(original['bytes'],original['sha256'])
        manifest['files'].append({'relative_path':str(relative),'source':original,'bytes':after['bytes'],'sha256':after['sha256']})
    copy(facts['source_copy']['path'],Path('source')/f'TestBreakInLoop{number}.java',facts['source'])
    for profile in facts['source_profiles']:
        for relative,original in profile['class_tree'].items():
            copy(original['path'],Path('original')/profile['profile']/'classes'/relative,original)
        original=profile['bundle']
        copy(original['path'],Path('original')/profile['profile']/f'TestBreakInLoop{number}-full-classes.jar',original)
    for name in ['JADX-LICENSE','JADX-NOTICE']:
        copy(ROOT/'tests/fixtures/recover-branching-named-catch-retry-loops/licenses'/name,Path('licenses')/name)
    (dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    (dest/'README.md').write_text(f'''# TestBreakInLoop{number} 完整原件

保留上游完整 Java（outer JUnit、nested TestCls 和原 check）、debug/no-debug 的全部 outer/target class 与同一完整 class JAR。没有裁剪方法、重写源码或为了通过恢复而更改 oracle。

来源为本地 JADX integration/loops/TestBreakInLoop{number}.java，源文件及每个二进制的 bytes/SHA、冻结输入路径见 manifest.json；许可证及 NOTICE 在 licenses/。产品实现只参考算法，没有复制 JADX 实现代码。

真实三方基线入口：openspec/evidence/java-syntax-2026-10-19/cf09-loop4-loop5-original-root-v1/README.md。原件由 JDK23 --release 8 编译为 major52；原生 javac8 的完整源码尝试因现有测试框架 major55/52 边界失败，收据原样保留。check 在 JDK23 实际通过，JDK8 的框架边界与独立 test cases 分开记录。

本目录只是冻结输入，不代表该特性实现或验收已通过。
''')
    print(json.dumps({'fixture':str(dest),'files':len(manifest['files']),'manifest':pin(dest/'manifest.json')}))
