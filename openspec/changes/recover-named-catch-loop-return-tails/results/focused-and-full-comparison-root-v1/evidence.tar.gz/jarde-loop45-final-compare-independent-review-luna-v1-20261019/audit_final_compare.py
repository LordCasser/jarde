#!/usr/bin/env python3
"""Independent Python-only audit of closed Loop4/5 comparison receipts."""
from __future__ import annotations
import collections, hashlib, json, re
from pathlib import Path

ROOT=Path('/private/tmp')
CLI_SHA='3dfb66010da33478d634cb0022abc18b02d7ee12bc3db095b5a8ddb6b9f8639b'
OUT=Path('/private/tmp/jarde-loop45-final-compare-independent-review-luna-v1-20261019')

class AuditError(RuntimeError): pass
def need(ok,msg):
    if not ok: raise AuditError(msg)
def sha(data): return hashlib.sha256(data).hexdigest()
def load_json(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def pin_file(pin, label):
    p=Path(pin['path'])
    need(p.is_file(),f'{label}: missing file {p}')
    data=p.read_bytes()
    need(len(data)==pin['bytes'],f'{label}: byte count mismatch {p}')
    need(sha(data)==pin['sha256'],f'{label}: SHA mismatch {p}')
    return data

def collect_pins(x, out):
    if isinstance(x,dict):
        if isinstance(x.get('path'),str) and type(x.get('bytes')) is int and isinstance(x.get('sha256'),str):
            out.append(x)
        for v in x.values(): collect_pins(v,out)
    elif isinstance(x,list):
        for v in x: collect_pins(v,out)

def normalized_case(row):
    keys=('index','name','input','result','exception_type','exception_message','exception_stack','target_stdout','after')
    return tuple(row.get(k) for k in keys)
def check_semantics(row, target, runtime):
    if target==4:
        if runtime=='javac23':
            return (row.get('check_result'),row.get('check_exception_type'),row.get('check_stdout'),row.get('check_exception_message'))
        return (row.get('check_result'),row.get('check_exception_type'),row.get('check_stdout'),row.get('check_exception_message'))
    return (row.get('check_exception'),row.get('check_stdout'))
def expected_check(target,runtime):
    if target==4:
        if runtime=='javac23': return ('pass','none','','')
        return ('error','java.lang.UnsupportedClassVersionError','',None)
    if runtime=='javac23': return ('none','')
    return ('java.lang.UnsupportedClassVersionError','')
def method_projection(method):
    return {k:method.get(k) for k in ('name','descriptor','identity','outcome_kind','quality','fallbacks','raw_text','source_map','map_audit')}

def audit_target(num):
    receipt_path=ROOT/f'jarde-testbreakinloop{num}-final-compare-root-v1-20261019/execution.json'
    rb=receipt_path.read_bytes(); rec=json.loads(rb)
    outroot=receipt_path.parent
    need(rec.get('status')=='captured-pending-independent-review',f'L{num}: receipt status unexpected')
    need(rec.get('candidate_cli_sha256_expected')==CLI_SHA,f'L{num}: expected CLI hash mismatch')
    cli=rec['cli']; need(cli['sha256']==CLI_SHA,f'L{num}: CLI receipt pin mismatch')
    cli_bytes=pin_file(cli,f'L{num} CLI'); need(len(cli_bytes)==cli['bytes'],f'L{num}: cli reread invalid')
    need(len(rec['commands'])==70,f'L{num}: expected 70 commands')
    raw_pins=[]; seen=set()
    for cmd in rec['commands']:
        need(set(cmd['streams'])=={'stdout','stderr'},f'L{num} cmd {cmd["index"]}: missing stream')
        for stream,pin in cmd['streams'].items():
            p=Path(pin['path'])
            need(p.parent==outroot/'raw' and not p.is_symlink(),f'L{num}: raw escaped or symlink: {p}')
            data=pin_file(pin,f'L{num} command {cmd["index"]} {stream}')
            need(str(p) not in seen,f'L{num}: duplicate raw path {p}'); seen.add(str(p))
            raw_pins.append({'command':cmd['index'],'stream':stream,'path':str(p),'bytes':len(data),'sha256':sha(data)})
    need(len(raw_pins)==140,f'L{num}: expected 140 raw pins')
    need([c['index'] for c in rec['commands']]==list(range(1,71)),f'L{num}: command indices are not complete')

    # Reopen every exact {path, bytes, sha256} pin referenced by the receipt, including
    # input, source/class outputs, API reports, dependency files and raw streams.
    all_pins=[]; collect_pins(rec,all_pins)
    unique={}
    for pin in all_pins:
        old=unique.get(pin['path'])
        if old is not None: need(old=={'bytes':pin['bytes'],'sha256':pin['sha256']},f'L{num}: conflicting duplicate pin {pin["path"]}')
        else: unique[pin['path']]={'bytes':pin['bytes'],'sha256':pin['sha256']}
    for path,pin in unique.items(): pin_file({'path':path,**pin},f'L{num} inventory')

    source_name=f'jadx/tests/integration/loops/TestBreakInLoop{num}$TestCls'
    desc={'<init>':'()V','test':'(C)D' if num==4 else '(Ljava/lang/String;)J','check':'()V'}
    expected_methods=[[name,desc[name]] for name in ('<init>','test','check')]
    cells=rec['jarde_cells']; need(len(cells)==8,f'L{num}: expected eight Jarde API calls')
    signatures=[(c['profile'],c['input_form'],c['evidence']) for c in cells]
    need(len(set(signatures))==8,f'L{num}: duplicate API signature')
    need(set(signatures)=={(p,f,e) for p in ('debug','no-debug') for f in ('child','bundle-child') for e in ('default','all')},f'L{num}: API profile/form/evidence matrix incomplete')
    api_rows=[]; api_by_key={}; map_gaps=[]
    for c in cells:
        need(c['exit_code']==0 and c['api_role']=='target',f'L{num}: API call failed or wrong role')
        report_pin=c['report']; report=load_json(report_pin['path'])
        need(report['outcome']=='performed',f'L{num}: report overall outcome not performed')
        need(report['fields']==[],f'L{num}: report has fields')
        methods=c['methods']; need(len(methods)==3,f'L{num}: expected three reflected method rows')
        need([[m['name'],m['descriptor']] for m in methods]==expected_methods,f'L{num}: method identity inventory mismatch')
        need(c['method_inventory_matches'] is True,f'L{num}: physical method inventory check false')
        need(sorted(c['physical_method_inventory'])==sorted(c['expected_physical_method_inventory']),f'L{num}: physical method inventory mismatch')
        report_methods=report['methods']
        need(len(report_methods)==3,f'L{num}: report method count mismatch')
        need(report['declaration']['declaration'].endswith('TestBreakInLoop'+str(num)+'$TestCls extends java.lang.Object'),f'L{num}: class declaration mismatch')
        projections=[]
        for rm,summary in zip(report_methods,methods):
            need(rm['outcome']['kind']=='recovered' and rm['outcome']['report']['quality']=='structured',f'L{num}: report method is not recovered/structured')
            need(rm['outcome']['report']['text']==summary['raw_text'],f'L{num}: report and method raw text differ')
            need(rm['outcome']['report']['source_map']==summary['source_map'],f'L{num}: report and method source maps differ')
            need(rm['item']['identity']['descriptor']==summary['identity']['descriptor'],f'L{num}: report method descriptor mismatch')
            need(rm['item']['identity']['name']==summary['identity']['name'],f'L{num}: report method name mismatch')
            need(summary['outcome_kind']=='recovered' and summary['quality']=='structured',f'L{num}: method not structured')
            need(summary.get('fallbacks')==[],f'L{num}: method has fallback')
            ma=summary['map_audit']
            need(ma['map_present'] and not ma['issues'],f'L{num}: source map absent or has structural issues')
            original_method=next(m for m in rec['source_profiles'][0]['target_facts']['methods'] if m['name']==summary['name'] and m['descriptor']==summary['descriptor'])
            need(ma['physical_bcis']==original_method['code']['bcis'],f'L{num}: map BCI source inventory differs from original class')
            if ma['unmapped_physical_bcis']:
                map_gaps.append({'profile':c['profile'],'input_form':c['input_form'],'evidence':c['evidence'],'method':summary['name'],'descriptor':summary['descriptor'],'unmapped_physical_bcis':ma['unmapped_physical_bcis']})
            # Ensure each source map segment names the same method identity and has valid UTF-8 extents.
            raw_text=summary['raw_text']; text_bytes=raw_text.encode('utf-8')
            need(len(text_bytes)==ma['text_bytes'],f'L{num}: UTF-8 source byte count mismatch')
            sm=summary['source_map']; need(sm and isinstance(sm.get('segments'),list),f'L{num}: source map missing')
            for seg in sm['segments']:
                need(0<=seg['start']<=seg['end']<=len(text_bytes),f'L{num}: source map byte span out of range')
                for pos in (seg['start'],seg['end']):
                    try: text_bytes[:pos].decode('utf-8')
                    except UnicodeDecodeError: raise AuditError(f'L{num}: source map span is not on UTF-8 boundary')
                origin=seg['origin']
                for o in [origin.get('primary')]+origin.get('derived',[]):
                    if o is not None:
                        ident=o.get('method')
                        need(ident is not None and ident['name']==summary['identity']['name'] and ident['descriptor']==summary['identity']['descriptor'],f'L{num}: BCI source identity mismatch')
            projections.append(method_projection(summary))
        key=(c['profile'],c['input_form'],c['evidence'])
        api_by_key[key]=c
        api_rows.append({'profile':c['profile'],'input_form':c['input_form'],'evidence':c['evidence'],'identities':expected_methods,'qualities':[m['quality'] for m in methods],'outcomes':[m['outcome_kind'] for m in methods],'method_bci_maps':[m['map_audit']['mapped_bcis'] for m in methods],'whole_source':c['whole_source']})

    stable_pairs=[]
    for profile in ('debug','no-debug'):
        for form in ('child','bundle-child'):
            a=api_by_key[(profile,form,'default')]; b=api_by_key[(profile,form,'all')]
            need(a['whole_source']['bytes']==b['whole_source']['bytes'] and a['whole_source']['sha256']==b['whole_source']['sha256'],f'L{num}: default/all whole source changed')
            ma={ (m['name'],m['descriptor']):m for m in a['methods'] }
            mb={ (m['name'],m['descriptor']):m for m in b['methods'] }
            need(ma.keys()==mb.keys(),f'L{num}: default/all method identity drift')
            for k in ma:
                for field in ('outcome_kind','quality','raw_text','source_map','map_audit'):
                    need(ma[k][field]==mb[k][field],f'L{num}: default/all {field} drift for {k}')
            stable_pairs.append({'profile':profile,'form':form,'whole_source_bytes':a['whole_source']['bytes'],'whole_source_sha256':a['whole_source']['sha256'],'methods_text_maps_quality_stable':True})

    expected_api={source_name:{'methods':expected_methods,'fields':[]}}
    need(rec['api_method_inventory_expected']['debug']=={source_name:expected_methods} and rec['api_method_inventory_expected']['no-debug']=={source_name:expected_methods},f'L{num}: API expected method inventory differs')
    need(rec['api_field_inventory_expected']['debug']=={source_name:[]} and rec['api_field_inventory_expected']['no-debug']=={source_name:[]},f'L{num}: API expected field inventory differs')
    need(len(rec['source_profiles'])==2 and all(x['exit_code']==0 for x in rec['source_profiles']),f'L{num}: original profile extraction failed')
    outer_name=f'jadx/tests/integration/loops/TestBreakInLoop{num}.class'
    target_class=source_name+'.class'
    for sp in rec['source_profiles']:
        need(set(sp['class_tree'])=={target_class,outer_name},f'L{num}: original profile tree is not the complete outer+target pair')
        need(all(sp['class_tree'][p]['bytes']>0 for p in (target_class,outer_name)),f'L{num}: original outer/target class empty')
        tf=sp['target_facts']
        need(tf['fields']==[] and [[m['name'],m['descriptor']] for m in tf['methods']]==expected_methods,f'L{num}: original physical target inventory mismatch')
        need(all(m['access']==1 and m['code'] is not None for m in tf['methods']),f'L{num}: original target method access/code inventory mismatch')
    plan=load_json(rec['case_plan']['path'])
    planned=[(c['id'],c['input']) for c in plan['cases']]
    need(len(planned)==(4 if num==4 else 5),f'L{num}: case plan count mismatch')
    need(len(rec['original_runtime'])==4,f'L{num}: expected four original VM profiles')
    original_by={}
    original_semantic_rows=[]
    original_case_count=0
    for o in rec['original_runtime']:
        need(o['exit_code']==0 and o['application_classpath']==[str(outroot/'driver-classes')],f'L{num}: original VM setup mismatch')
        cmd=rec['commands'][o['command']-1]
        jargv=cmd['argv']
        need('-Xverify:all' in jargv and '-cp' in jargv and jargv[jargv.index('-cp')+1]==str(outroot/'driver-classes'),f'L{num}: original VM classpath/verification mismatch')
        need(f'TestBreakInLoop{num}Driver' in jargv,f'L{num}: original VM driver identity mismatch')
        need(len(o['rows'])==len(planned),f'L{num}: original VM case count mismatch')
        need([(r['name'],r['input']) for r in o['rows']]==planned,f'L{num}: actual original VM input/name sequence differs from case plan')
        
        oracle_flag=o.get('manual_oracle_matches',o.get('source_plan_comparison_matches'))
        if num==5 and o['runtime']=='javac8':
            need(oracle_flag is False and o.get('source_plan_comparison_issues')==['original TestCls.check() assertion did not pass cleanly'],f'L5: expected isolated JDK8 check framework limitation not recorded cleanly')
        else:
            need(oracle_flag is True,f'L{num}: original case oracle comparison failed for {o["profile"]}/{o["runtime"]}')
        original_by[(o['profile'],o['runtime'])]=o
        original_semantic_rows.append([normalized_case(r) for r in o['rows']])
    check_results={}
    for profile in ('debug','no-debug'):
        for runtime in ('javac8','javac23'):
            o=original_by[(profile,runtime)]
            if num==4:
                observed={(r['check_result'],r['check_exception_type'],r['check_stdout']) for r in o['rows']}
                if runtime=='javac23': need(observed=={('pass','none','')},f'L4: original check did not pass {profile}/{runtime}')
                else: need(observed=={('error','java.lang.UnsupportedClassVersionError','')},f'L4: JDK8 check boundary missing {profile}/{runtime}')
            else:
                last=o['rows'][-1]
                if runtime=='javac23': need(last.get('check_exception')=='none' and last.get('check_stdout')=='',f'L5: original check did not pass {profile}/{runtime}')
                else: need(last.get('check_exception')=='java.lang.UnsupportedClassVersionError' and last.get('check_stdout')=='',f'L5: JDK8 check boundary missing {profile}/{runtime}')
            if num==4:
                row=o['rows'][0]
                check_results[f'{profile}/{runtime}']={'result':row['check_result'],'exception_type':row['check_exception_type'],'stdout':row['check_stdout'],'exception_message':row['check_exception_message']}
            else:
                check_results[f'{profile}/{runtime}']={'exception_type':last.get('check_exception'),'stdout':last.get('check_stdout')}

    comp=rec['generated_source_compilations']; need(len(comp)==20,f'L{num}: expected twenty source compilation attempts')
    compile_counts=collections.Counter((x['kind'],x['compiler'],x['exit_code']) for x in comp)
    need(compile_counts[('jarde','javac23',0)]==8 and compile_counts[('jadx','javac23',0)]==2,f'L{num}: expected eight Jarde and two JADX JDK23 compiles')
    need(compile_counts[('jarde','javac8',1)]==8 and compile_counts[('jadx','javac8',1)]==2,f'L{num}: expected ten JDK8 compile failures')
    boundary_err=Path(rec['javac8_full_source_boundary']['stderr']['path']).read_text(encoding='utf-8',errors='replace')
    need(rec['javac8_full_source_boundary']['exit_code']==1 and ('55.0' in boundary_err and '52.0' in boundary_err),f'L{num}: upstream JDK8 framework boundary not recorded')
    for x in comp:
        err=Path(x['stderr']['path']).read_text(encoding='utf-8',errors='replace')
        if x['compiler']=='javac8':
            need(x['exit_code']==1 and ('55.0' in err and '52.0' in err and 'jadx-test-harness.jar' in err),f'L{num}: JDK8 failure is not framework version boundary: {x["kind"]}/{x["profile"]}/{x["form"]}')
            need(not x['class_tree'],f'L{num}: failed JDK8 compile unexpectedly has class tree')
        else:
            need(x['exit_code']==0 and x['runtime_eligible'] is True,f'L{num}: successful compile not runtime eligible')
            cf=x['class_facts'][source_name+'.class']
            need(not cf['fields'] and [[m['name'],m['descriptor']] for m in cf['methods']]==expected_methods,f'L{num}: generated class inventory mismatch')
            if x['kind']=='jadx': need(set(x['class_facts'])=={source_name+'.class',outer_name},f'L{num}: successful JADX rebuild omitted outer or target class')
            need(all(m['access']==1 and m['code'] is not None for m in cf['methods']),f'L{num}: generated physical methods/access flags mismatch')
            need(cf['major']==52,f'L{num}: generated class major is not 52')

    gen=rec['generated_runtime']; need(len(gen)==20,f'L{num}: expected 20 generated VM runs')
    need(len(rec['generated_wrong_root_controls'])==10,f'L{num}: expected 10 wrong-CodeSource controls')
    vm_case_count=0; generated_rows=[]
    for o in rec['original_runtime']: original_case_count+=len(o['rows'])
    for x in gen:
        key=(x['profile'],x['runtime']); o=original_by[key]
        need(x['exit_code']==0 and x['application_classpath']==[str(outroot/'driver-classes')],f'L{num}: generated runtime setup failed')
        cmd=rec['commands'][x['command']-1]
        jargv=cmd['argv']
        need('-Xverify:all' in jargv and '-cp' in jargv and jargv[jargv.index('-cp')+1]==str(outroot/'driver-classes'),f'L{num}: generated VM classpath/verification mismatch')
        need(f'TestBreakInLoop{num}Driver' in jargv,f'L{num}: generated VM driver identity mismatch')
        dep_arg=' '.join(rec['dependency_classpath'])
        need(source_name not in dep_arg and str(outroot/'debug/classes') not in dep_arg and str(outroot/'no-debug/classes') not in dep_arg and '/generated-classes/' not in dep_arg,f'L{num}: target tree leaked into dependency classpath')
        need(x['class_root']==next(c['class_root'] for c in comp if c['kind']==x['kind'] and c['profile']==x['profile'] and c['form']==x['form'] and c['evidence']==x['evidence'] and c['compiler']==x['compiler'] and c['exit_code']==0),f'L{num}: runtime class root not from successful compiler output')
        need(len(x['rows'])==len(o['rows']),f'L{num}: generated VM case count mismatch')
        need([normalized_case(r) for r in x['rows']]==[normalized_case(r) for r in o['rows']],f'L{num}: generated VM cases differ from same-profile/runtime original {key} / {x["kind"]}/{x["form"]}/{x["evidence"]}')
        for gr,orow in zip(x['rows'],o['rows']):
            need(check_semantics(gr,num,x['runtime'])==check_semantics(orow,num,x['runtime']),f'L{num}: generated check result differs from same-runtime original')
        need(x['matches_original_oracle'] is True,f'L{num}: collector comparison flag false')
        generated_rows.append({'kind':x['kind'],'profile':x['profile'],'form':x['form'],'evidence':x['evidence'],'compiler':x['compiler'],'runtime':x['runtime'],'case_count':len(x['rows']),'cases_match_original':True,'check_match_original':True})
        vm_case_count+=len(x['rows'])
    need(original_case_count==(16 if num==4 else 20),f'L{num}: original VM total cases mismatch')
    need(all(rows==original_semantic_rows[0] for rows in original_semantic_rows),f'L{num}: original case outcomes differ across same-profile/runtime baseline cells')
    need(vm_case_count==(80 if num==4 else 100),f'L{num}: generated VM total cases mismatch')

    wrong=[]
    for x in rec['generated_wrong_root_controls']:
        need(x['exit_code']==1 and x['rejected'] is True,f'L{num}: wrong-root control not rejected')
        cmd=rec['commands'][x['command']-1]
        need(cmd['label'].startswith('wrong-root-'),f'L{num}: wrong-root command label mismatch')
        jargv=cmd['argv']; driver_pos=jargv.index(f'TestBreakInLoop{num}Driver')
        actual_target_root=jargv[driver_pos+1]; wrong_root=jargv[driver_pos+2]
        err=Path(x['stderr']['path']).read_text(encoding='utf-8',errors='replace')
        need(wrong_root==str(outroot/'empty-classpath') and actual_target_root.startswith(str(outroot/'generated-classes')+'/'),f'L{num}: wrong-root expected/actual CodeSource paths are not isolated')
        need('wrong CodeSource: expected=' in err and wrong_root in err and actual_target_root in err,f'L{num}: wrong-root stderr lacks exact CodeSource mismatch')
        wrong.append({'kind':x['kind'],'profile':x['profile'],'form':x['form'],'evidence':x['evidence'],'command':x['command'],'exit_code':x['exit_code'],'rejected':True,'actual_target_root':actual_target_root,'expected_wrong_root':wrong_root})
    need(rec['source_unchanged'] is True and rec['generated_outputs_unchanged'] is True and rec['local_copies_unchanged_finally'] is True and rec['external_inputs_unchanged'] is True,f'L{num}: run integrity changed')
    need(rec['target_absent_finally'] is True,f'L{num}: repository target cleanup guard failed')
    need(rec['runtime_semantic_agreement'] is True,f'L{num}: same-runtime original profiles disagree')

    return {
      'target':num,'receipt':{'path':str(receipt_path),'bytes':len(rb),'sha256':sha(rb),'status':rec['status'],'finished_utc':rec['finished_utc']},
      'cli':{'path':cli['path'],'bytes':len(cli_bytes),'sha256':sha(cli_bytes)},
      'command_count':len(rec['commands']),'raw_stream_count':len(raw_pins),'raw_streams':raw_pins,
      'all_receipt_file_pins':len(all_pins),'all_unique_receipt_files_reopened':len(unique),
      'api':{'calls':len(cells),'per_call_methods':3,'all_methods_recovered_structured':True,'all_targets_fieldless':True,'method_identities':expected_methods,'default_all_stable_pairs':stable_pairs,'all_physical_bcis_mapped':not map_gaps,'physical_bci_gaps':map_gaps,'source_map_utf8_spans_checked':True},
      'compilation':{'attempts':len(comp),'successes':sum(x['exit_code']==0 for x in comp),'success_by_kind':{'jarde':compile_counts[('jarde','javac23',0)],'jadx':compile_counts[('jadx','javac23',0)]},'jdk8_framework_version_failures':sum(x['compiler']=='javac8' and x['exit_code']==1 for x in comp),'compile_outcomes':dict((f'{k[0]}/{k[1]}/exit{k[2]}',v) for k,v in compile_counts.items())},
      'original_runtime':{'profile_runtime_cells':len(original_by),'cases_per_cell':4 if num==4 else 5,'total_case_observations':original_case_count,'case_name_inputs':planned,'observed_result_by_case':[{'name':r['name'],'input':r['input'],'result':r['result'],'exception_type':r['exception_type'],'target_stdout':r['target_stdout'],'after':r['after']} for r in original_by[('debug','javac23')]['rows']],'check_by_profile_runtime':{k:list(v) for k,v in check_results.items()}},
      'generated_runtime':{'runs':len(gen),'total_case_observations':vm_case_count,'runs':generated_rows},
      'wrong_root_controls':wrong,'wrong_root_count':len(wrong),
      'integrity':{'source_unchanged':rec['source_unchanged'],'generated_outputs_unchanged':rec['generated_outputs_unchanged'],'target_absent_finally':rec['target_absent_finally']},
      'notes':('Loop4 check() passes under javac23 and is independently blocked under javac8 by UnsupportedClassVersionError in framework class major 55 vs runtime max 52.' if num==4 else 'Loop5 check() passes under javac23. Under javac8 it is blocked by the same framework UnsupportedClassVersionError; receipt source-plan check flag is false for both javac8 originals only because that check assertion did not execute cleanly. The test() case results are compared independently and agree.')
    }

def main():
    results=[audit_target(n) for n in (4,5)]
    report={'schema':'jarde.loop45.final-compare-independent-review.v1','status':'closed_receipts_independently_reopened','targets':results,'combined':{'commands':sum(x['command_count'] for x in results),'raw_streams':sum(x['raw_stream_count'] for x in results),'api_calls':sum(x['api']['calls'] for x in results),'structured_methods':sum(x['api']['calls']*3 for x in results),'compile_attempts':sum(x['compilation']['attempts'] for x in results),'compile_successes':sum(x['compilation']['successes'] for x in results),'wrong_root_controls':sum(x['wrong_root_count'] for x in results),'generated_vm_runs':sum(x['generated_runtime']['runs'].__len__() for x in results),'original_vm_cells':sum(x['original_runtime']['profile_runtime_cells'] for x in results)},'scope':'Only closed final comparison receipts and their referenced local inputs/outputs were read. No toolchain was run. The separate Loop5 12-case collector remains unopened until it is closed.'}
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report['combined'],ensure_ascii=False))
if __name__=='__main__': main()
