# Loop4 exit-body architecture note

Read-only design note; no source or shared workspace files changed. This identifies the smallest likely region-recovery change for the observed Loop4 gap. It does not implement or authorize an OpenSpec change.

## Evidence pins

- IR trace: `/private/tmp/jarde-loop45-ir-probe-run-root-v1-20261019/raw/1.stderr.raw`, 292286 bytes, SHA-256 `cddd66ab28b5c4e16536bc5315bee53e32f7c43f47a91f115db16dfcc4888e74`.
- Jarde source: `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/region.rs`, SHA-256 `f0087dcf55aa691a3a57e491265474d6645f836f301372fcfec003f63f444fb5`.
- JADX `LoopRegionMaker.java`: `/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/main/java/jadx/core/dex/visitors/regions/maker/LoopRegionMaker.java`, SHA-256 `a77bedda10bdb0d36f3979c27c1fc9471da726b36f34ae14d505f6f659c6b13e`.
- JADX `IfRegionMaker.java`: `/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/main/java/jadx/core/dex/visitors/regions/maker/IfRegionMaker.java`, SHA-256 `3d3d4c2238a21368e5970db5d5cffb2e63a625e411e8cf64461bd6e604d74760`.

Line citations below refer to the pinned file contents above.

## Observed Loop4 shape

The trace confirms natural loop header 5, body set `{5, 11, 36}`, latch 36, and the two normal exits `5→42` and `11→17`; immediate post-dominator is 42. Blocks 17, 23, and 29 are outside that natural-loop set. The body is currently recovered as `If(branch=11, bci=14, then=empty Straight, else=Straight[36], join=42)` and the loop is retained, but blocks 17/23/29 appear later as an `UncoveredBlocks` fallback. There are no exception rows in the observed method.

The exit path is not a straight transfer prefix. It is a small conditional DAG:

- `17→23` or `17→29`; block 17 tests at bci 20.
- `23→42` or `23→29`; block 23 tests at bci 26.
- `29→42`; block 29 stores the double result and transfers at bci 33.

The exact edge list and decoded operations are in the pinned trace. This matters: a new proof cannot model the whole route as a single `LoopBreak` from branch 11, because that would erase the work and the two conditional tests. Existing `Region::If`, `Region::Straight`, and `Region::LoopBreak` can express this graph while retaining those blocks and transfer sites.

## Exact reason the current walk loses it

1. `Frame::loop_body` builds scope from the natural-loop blocks and the proven single-successor transfer sources; see `region.rs:4771-4804`. `loop_transfer_sources` is just nodes with one successor that is an exact known exit/continue target (`22078-22085`). For this graph that admits 29 as a predecessor of 42, but not the branch blocks 17 and 23. `loop_exit_gateway_pair` only adds its gateway when the gateway is a checked one-instruction transfer bridge; see `21958-22075`. It cannot certify this multi-block conditional subgraph.
2. In `region_at_inner`, successors that are known loop exits are admitted through the edge filter (`6084-6115`), but `Frame::stops_at` still stops at any node outside scope (`4956-4968`); the walk returns an empty `Straight` at that point (`5616-5619`). So merely putting 17 in the exit allow-list does not make it owned or traversable.
3. The branch classifier has a broad one-arm heuristic: `forward_join` accepts a successor if its predecessors are dominated by the branch, via `forward_join_predecessors` (`15490-15510`, `16245-16259`). The trace has 11 as the sole predecessor of 17, so 17 can be elected as the apparent forward join even though it starts a live exit-side subgraph. The one-arm branch code then walks only the other arm and synthesizes an empty arm for the elected successor (`6531-6599`, `6716-6773`). This explains the observed empty arm and retained `Straight[36]`. In this case the final expected set is only the natural loop body (plus any independently established owners); `covers(expected)` passes, so the Loop region is retained. The later method-wide uncovered scan reports 17/23/29, which is the actual loss (`18780-18846` shows loop-local checking and `22238-22244` defines `covers`; the trace records the final `UncoveredBlocks`).
4. Existing alternative proofs do not fit: `loop_bridge_join` recognizes a one-block `loop_exit_bridge` and an in-loop path to the latch/boundary (`6237-6271`); `nested_loop_side_exit` explicitly requires the outside route to lead to a nested loop header (`21400-21529`). The Loop4 route has neither shape. Do not broaden either proof by merely relaxing its terminal conditions.

## Smallest correct architectural direction

Keep natural-loop discovery, the `{5,11,36}` set, and `ForHeader` recognition unchanged. Add one narrow proof for an *exit-side structured body* owned by a conditional inside the current loop: here source branch 11, outside entry 17, exact break destination 42, sibling loop continuation 36. The certificate should return the exact ordered/set of external owners `{17,23,29}` and establish that every route from 17 is structured and ends at 42. Use this certificate in the branch-join reading that currently accepts only a one-block exit bridge, so the selected local join for branch 11 is the in-loop continuation/update 36. Then walk 17 under a frame scope extended by precisely those owners. Existing `region_at_inner`/`If`/`LoopBreak` logic can represent the inner DAG: branch 17 joins at 29, branch 23 has a `LoopBreak` arm to 42, and block 29's physical transfer to 42 becomes a `LoopBreak` with source bci 33. The branch at 11 must not itself become an empty edge or a synthetic break.

This is an extension of the existing exit-bridge/side-exit ownership concept, but it is a distinct proof shape (conditional exit subgraph). Keep it separate from `nested_loop_side_exit`: that proof owns an outside prefix to a nested loop, whereas Loop4's external region is a branching, statement-bearing path to the current loop's own exit.

The new proof should be attempted before `forward_join` can elect the external entry as an empty arm. It must not globally weaken the forward-join predicate. For this shape, success means the external route is explicitly owned and represented; otherwise the current refusal/uncovered reporting should remain.

## Proof obligations and refusal boundary

- Bind the proof to the exact current loop header, exact branch node/bci, exact outside successor, exact break target 42, and the other successor's proof that it remains in this loop and reaches its continuation/boundary. Do not borrow an enclosing loop's targets.
- Compute and retain a bounded owner set. Require the entry to be exclusively reached from the owning branch; internal nodes must have no unaccounted incoming owners; every normal successor must remain in the certified set or be exactly the current loop's break target. Require an acyclic route graph that terminates at that target; reject returns, method exits, additional exits, back edges, loop headers, switch nodes, cross-path nodes, already-visited/parent-owned nodes, and any route that escapes the frame.
- Check branch terminal instructions against decoded comparisons, and preserve their actual branches as `If`s. Check straight transfer/terminal instructions against decoded operations. Census canonical normal and non-normal edges and reject any unaccounted leaving/exception edge; the present no-exception observation does not justify omitting the check for other methods.
- Do not include target 42 in the body owner set. It remains the loop exit/shared continuation. Record each physical transfer origin through the existing `LoopBreak.source_bci` (26 for the direct conditional break edge, 33 for the goto at 29); do not synthesize a branch-11 source origin for the whole route. Existing gateway origins should remain reserved for their current header/latch gateway meanings.
- Charge/poll before graph scans, set clones, and owner-set expansion, following the established pattern around `loop_exit_gateway_pair` (`21981-22010`) and `nested_loop_side_exit` (`21414-21418`, `21484-21522`). Cancellation/budget stop must propagate without committing partial owners or visited state. As with side-exit trials (`18732-18778`), any speculative walk must restore the pre-attempt visited/auxiliary state on failure.
- Before accepting the loop, require exact actual ownership: body block multiset has no duplicates and equals natural-loop body owners plus the certificate owners and already-proved terminal owners; no extra nodes. Preserve the existing loop coverage/fallback behavior (`18817-18846`) and report refusal if any proof or coverage check fails.

## JADX comparison

JADX's `LoopRegionMaker.makeLoopRegion` selects a loop condition from loop exit blocks and validates it with `checkLoopExits` (`LoopRegionMaker.java:187-245`, `264-288`). With multiple exits, `validOutBlock` checks dominance-frontier crossings and admits only listed cases (`297-360`). Its endless-loop path searches valid outblocks then inserts breaks on proved incoming edges (`527-605`, `620-703`). `IfRegionMaker` intentionally allows a null/empty then region and omits a null else region (`98-118`), consistent with treating a direct join successor as an empty arm. This is useful structural context, not a requirement to mirror JADX's internal proof or Java spelling. The test's “for without while” observation remains a source-style expectation; equivalent Jarde structure should be judged by owned behavior and recovered control flow.

## Focused follow-up experiment for the implementation owner

Use the existing Loop4 baseline harness, with target absent until the implementation is frozen. First instrument a read-only/probe result for the candidate proof only: identify branch 11, its external entry 17, owners exactly `{17,23,29}`, exit 42, continuation 36, and each canonical/decoded edge/origin. Then enable the region change and inspect all four existing runtime/debug profiles. Assert the branch-11 then/else ownership, nested branch coverage, `LoopBreak` origins 26 and 33, no duplicate block owners, no uncovered 17/23/29, no added/changed exception facts, unchanged case behavior/stdout, and full-loop `check()` parity. Add adversarial refusal fixtures or targeted proof-level checks for a shared entry, a second non-loop exit, a cycle/back edge, a switch, an exception edge, and a node already owned by an enclosing frame. Do not use a passing syntactic snapshot alone as evidence; verify compiled output behavior and full source ownership.
