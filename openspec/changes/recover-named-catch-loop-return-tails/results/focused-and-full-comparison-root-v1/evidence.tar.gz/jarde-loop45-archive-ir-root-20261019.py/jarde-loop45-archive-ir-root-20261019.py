import gzip,hashlib,io,json,tarfile
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
DEST=ROOT/'openspec/evidence/java-syntax-2026-10-19/cf09-loop4-loop5-ir-root-v1'
assert not DEST.exists(); DEST.mkdir()
members={}
def add_file(path,name):
    p=Path(path); assert p.is_file() and name not in members
    members[name]=(p.read_bytes(),p.stat().st_mode&0o777,str(p))
def add_tree(path,prefix):
    for p in sorted(Path(path).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:
            add_file(p,str(Path(prefix)/p.relative_to(path)))
for path,prefix in [
('/private/tmp/jarde-loop45-ir-probe-prep-luna-v1-20261019','preparation'),
('/private/tmp/jarde-loop45-ir-probe-launch-root-v1-20261019','actual-launch'),
('/private/tmp/jarde-loop45-ir-probe-run-root-v1-20261019','actual-run'),
('/private/tmp/jarde-loop45-ir-review-luna-v1-20261019','independent-review'),
('/private/tmp/jarde-loop4-exit-body-design-luna-v1-20261019','architecture/loop4'),
('/private/tmp/jarde-loop5-protected-loop-design-luna-v1-20261019','architecture/loop5')]:
    add_tree(path,prefix)
for name in ['crates/jarde-java/src/region.rs','crates/jarde-java/src/region/finite_loop_catch_tests.rs','crates/jarde-java/src/build.rs','crates/jarde-java/src/guard.rs','openspec/changes/recover-branch-throw-return-finally/tools/run_validation.py','openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py','openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py']:
    add_file(ROOT/name,'source-and-tools/'+name)
assert hashlib.sha256(members['source-and-tools/crates/jarde-java/src/region.rs'][0]).hexdigest()=='f0087dcf55aa691a3a57e491265474d6645f836f301372fcfec003f63f444fb5'
assert hashlib.sha256(members['actual-run/raw/1.stderr.raw'][0]).hexdigest()=='cddd66ab28b5c4e16536bc5315bee53e32f7c43f47a91f115db16dfcc4888e74'
review=json.loads(members['independent-review/review.json'][0]); assert review['status']=='pass_with_scope_caveat'
actual=json.loads(members['actual-launch/execution.json'][0]); assert actual['runner_exit_code']==0 and actual['helper_restored'] and actual['inputs_and_source_restored'] and actual['target_absent']
assert b'the probe covers ctor' not in members['independent-review/FINDINGS.md'][0]
inventory={'schema':'reopened-archive-inventory-v1','members':[]}
archive=DEST/'evidence.tar.gz'
with archive.open('xb') as output,gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
    for name,(data,mode,path) in sorted(members.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=mode;info.mtime=0;tar.addfile(info,io.BytesIO(data))
        inventory['members'].append({'path':name,'bytes':len(data),'mode':mode,'sha256':hashlib.sha256(data).hexdigest(),'source_path':path})
with tarfile.open(archive,'r:gz') as tar:
    reopened=tar.getmembers();assert len(reopened)==len(members)
    for item in reopened:
        expected,mode,_=members[item.name];assert tar.extractfile(item).read()==expected and item.mode==mode
b=archive.read_bytes();capture={'schema':'root-archive-capture-v1','status':'all_members_reopened_and_matched','archive':{'path':str(archive.relative_to(ROOT)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'payload_count':len(members),'payload_bytes':sum(len(x[0]) for x in members.values()),'probe_test_passed':1,'probe_test_failed':0,'scope':'four original test methods; Sites::empty helper; physical class inventories are separate from IR method coverage','target_absent':not (ROOT/'target').exists()}
(DEST/'inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n')
(DEST/'capture.json').write_text(json.dumps(capture,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(capture,ensure_ascii=False))
