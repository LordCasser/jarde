import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.Base64;

/** Isolated observations of complete TestBreakInLoop4$TestCls and original check(). */
public final class TestBreakInLoop4Driver {
    private static final String TARGET = "jadx.tests.integration.loops.TestBreakInLoop4$TestCls";
    private static final char[] INPUTS = {'.', 'a', 'b', 'c'};
    private static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static String codeSource(Class<?> c) throws Exception {
        CodeSource source=c.getProtectionDomain().getCodeSource();
        if(source==null||source.getLocation()==null)throw new IllegalStateException("target has no CodeSource");
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }
    private static void requireEmptyCwd(String expected)throws Exception{
        String actual=Paths.get(".").toRealPath().toString();
        if(!actual.equals(expected))throw new IllegalStateException("unexpected JVM cwd: expected="+expected+" actual="+actual);
        String[] entries=new java.io.File(".").list();
        if(entries==null||entries.length!=0)throw new IllegalStateException("JVM cwd is not empty");
    }
    private static void observe(Method test,Object receiver,int index,String cwd,PrintStream resultOut)throws Exception{
        requireEmptyCwd(cwd);char input=INPUTS[index];PrintStream previous=System.out;
        ByteArrayOutputStream captured=new ByteArrayOutputStream();PrintStream targetOut=new PrintStream(captured,true,"UTF-8");
        Throwable cause=null;String result="<not-returned>";
        try{System.setOut(targetOut);try{result="return="+String.valueOf(test.invoke(receiver,Character.valueOf(input)));}
            catch(InvocationTargetException e){cause=e.getCause();}}
        finally{targetOut.flush();System.setOut(previous);targetOut.close();}
        String output=new String(captured.toByteArray(),StandardCharsets.UTF_8);
        resultOut.println("CASE index="+index+" name="+input+" input_b64="+b64(String.valueOf(input))
            +" result_b64="+b64(result)+" exception="+(cause==null?"none":cause.getClass().getName())
            +" exception_message_b64="+b64("")+" exception_stack_b64="+b64("")
            +" target_stdout_b64="+b64(output)+" after_b64="+b64(String.valueOf(input)));requireEmptyCwd(cwd);
    }
    public static void main(String[]args)throws Exception{
        if(args.length<3)throw new IllegalArgumentException("usage: TestBreakInLoop4Driver actualRoot expectedRoot emptyWorkingDirectory [dependencyUrl ...]");
        String actual=Paths.get(args[0]).toRealPath().toString(),expected=Paths.get(args[1]).toRealPath().toString();
        String cwd=Paths.get(args[2]).toRealPath().toString();requireEmptyCwd(cwd);
        URL[]urls=new URL[args.length-2];urls[0]=Paths.get(actual).toUri().toURL();
        for(int i=3;i<args.length;i++)urls[i-2]=Paths.get(args[i]).toUri().toURL();
        try(URLClassLoader loader=new URLClassLoader(urls,null)){
            Class<?>target=Class.forName(TARGET,true,loader);
            if(target.getClassLoader()!=loader)throw new IllegalStateException("target did not load from isolated loader");
            String origin=codeSource(target);if(!origin.equals(expected))throw new IllegalStateException("wrong CodeSource: expected="+expected+" actual="+origin);
            Constructor<?>ctor=target.getDeclaredConstructor();Object receiver=ctor.newInstance();
            Method test=target.getDeclaredMethod("test",Character.TYPE),check=target.getDeclaredMethod("check");
            test.setAccessible(true);check.setAccessible(true);String checkRow;PrintStream checkPrevious=System.out;
            ByteArrayOutputStream checkCaptured=new ByteArrayOutputStream();PrintStream checkOut=new PrintStream(checkCaptured,true,"UTF-8");
            Throwable checkCause=null;try{System.setOut(checkOut);try{check.invoke(receiver);}catch(InvocationTargetException e){checkCause=e.getCause();}}
            finally{checkOut.flush();System.setOut(checkPrevious);checkOut.close();}
            String checkText=new String(checkCaptured.toByteArray(),StandardCharsets.UTF_8);
            checkRow="CHECK result="+(checkCause==null?"pass":"error")+" exception="+(checkCause==null?"none":checkCause.getClass().getName())
                +" stdout_b64="+b64(checkText)+" exception_message_b64="+b64(checkCause==null?"":String.valueOf(checkCause.getMessage()));
            PrintStream resultOut=System.out;
            for(int i=0;i<INPUTS.length;i++)observe(test,receiver,i,cwd,resultOut);
            System.out.println(checkRow);requireEmptyCwd(cwd);
        }
    }
}
