# TestBreakInLoop4 full-source baseline preparation

This is an unexecuted preparation bundle. The pinned upstream input is the complete `TestBreakInLoop4.java` (1068 bytes, SHA-256 `42b0f55b653b41bc69286e1947c8a19d94b0da810cdcc7cf48bb6d2cd6a256e5`) copied byte-for-byte to `source/` and `source-plan-copy/`. It retains the complete outer JUnit class, nested `TestCls`, both outer tests, all four `check()` assertions, constructor, and target methods. The target binary name is `jadx.tests.integration.loops.TestBreakInLoop4$TestCls`; the measured source inventory is `<init>()V`, `test(C)D`, and `check()V`, with no fields or nested helpers.

The driver runs the original `check()` in every original/generated runtime cell and records its pass/error, exception class/message, and its own captured stdout independently. It then executes all four original inputs `.`, `a`, `b`, and `c`, recording return value, exception class, captured target stdout, and exact char input. Source-derived results `1.0, 1024.0, 1024.0, 1.0` are auxiliary hypotheses; the compiled original target is the behavior oracle. The driver does not invoke the outer JUnit methods. The outer source is still compiled unchanged and both full outer/target JADX source trees are captured.

The application JVM classpath contains only the reflection driver. A null-parent `URLClassLoader` receives the selected target root plus every dependency classpath entry from the pinned reference; the collector verifies the dependency classpath has no target-class contamination. CodeSource is checked against the expected target root. Each subprocess gets independent stdout/stderr raw files, including failed commands. The JDK 8 full-source compile retains its framework major-55/52 boundary. If `check()` cannot load a pinned major-55 dependency on JDK 8, that exception is recorded separately and the four target cases still execute; JDK 23 must execute the check normally for an accepted complete observation. A failed check is never represented as a pass.

The capture retains the prior harness capabilities: JDK 8/23, debug/no-debug, original full-source and generated-source compilations, complete outer+target JADX tree, class/JAR Jarde inputs × default/all evidence, source and quality text, diagnostics and raw maps, complete class inventories with physical method/BCI checks, two-VM execution, wrong-CodeSource rejection, and command/raw-stream pins. Runtime eligibility is derived from actual successful compiles and metadata agreement. The harness does not assume a fixed number of API methods or fields beyond the upstream target's verified source contract.

The candidate CLI is fixed at `/private/tmp/jarde-loop2-retry-final-focused-root-v2-20261019/candidate-cli`, 64,347,312 bytes, mode `0555`, SHA-256 `7e321a7f4fd6a029540ab169f79572c6ad83e74119900ac6d695290c9c055318`. Product lineage is `618b5e20f27f94ba28ea2f9e4310648718475f82`. Preparation makes no assumption about whether Jarde accepts or rejects this input or why.

After root review, run with fresh output directories:

```sh
python3 -B /private/tmp/jarde-testbreakinloop4-baseline-prep-luna-v2-20261019/collect_baseline.py \
  --out /private/tmp/jarde-testbreakinloop4-baseline-root-v1-20261019 \
  --cli /private/tmp/jarde-loop2-retry-final-focused-root-v2-20261019/candidate-cli \
  --cli-sha256 7e321a7f4fd6a029540ab169f79572c6ad83e74119900ac6d695290c9c055318
python3 -B /private/tmp/jarde-testbreakinloop4-baseline-prep-luna-v2-20261019/audit.py \
  --receipt /private/tmp/jarde-testbreakinloop4-baseline-root-v1-20261019/execution.json \
  --cli /private/tmp/jarde-loop2-retry-final-focused-root-v2-20261019/candidate-cli \
  --cli-sha256 7e321a7f4fd6a029540ab169f79572c6ad83e74119900ac6d695290c9c055318 \
  --out /private/tmp/jarde-testbreakinloop4-baseline-review-root-v1-20261019
```

`python3 -B /private/tmp/jarde-testbreakinloop4-baseline-prep-luna-v2-20261019/static_preflight.py` checks source copies, case plan, script syntax, and pins only. It does not run Java, javac, JADX, Jarde CLI, Cargo, Git, or network. `adaptation.diff` gives the script/driver/case-plan delta from the accepted Loop2 preparation; `pins.json` lists input and local-file pins (excluding the manifest's self-hash).


## v2 delta

Version 2 passes the same pinned dependency URLs to generated wrong-CodeSource controls as to normal generated runs. The JVM application classpath remains driver-only; those URLs are available only to the isolated target loader. `v1-v2.diff` records the collector, preflight, and README changes. The v1 bundle remains unchanged.
