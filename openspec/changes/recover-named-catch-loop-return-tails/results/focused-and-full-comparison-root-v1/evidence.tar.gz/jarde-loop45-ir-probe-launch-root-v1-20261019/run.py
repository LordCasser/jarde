import datetime,hashlib,json,os,shutil,subprocess,sys,traceback
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');PREP=Path('/private/tmp/jarde-loop45-ir-probe-prep-luna-v1-20261019');LAUNCH=Path(__file__).parent;RUN=Path('/private/tmp/jarde-loop45-ir-probe-run-root-v1-20261019');HELPER=ROOT/'crates/jarde-java/src/region/finite_loop_catch_tests.rs'
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':p.stat().st_mode&511}
config=json.loads((PREP/'pins.json').read_text());expected=[]
def gather(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys():expected.append(v)
  for x in v.values():gather(x)
 elif isinstance(v,list):
  for x in v:gather(x)
gather(config)
def verify():
 rows=[]
 for x in expected:
  actual=pin(x['path']);assert actual['bytes']==x['bytes'] and actual['sha256']==x['sha256'],x['path'];rows.append(actual)
 return rows
record={'status':'preflight','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'launcher':pin(__file__),'commands':pin(LAUNCH/'commands.json'),'probe_source':pin(PREP/'probe.rs'),'source_scope':'append temporary test child only; product Rust algorithm unchanged; exact restore after guarded runner','default_stack':True}
def save():(LAUNCH/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
original=None;applied=False
try:
 record['pins_before']=verify();assert not RUN.exists() and not (ROOT/'target').exists();assert shutil.disk_usage(ROOT).free>=5*1024**3
 original=HELPER.read_bytes();mode=HELPER.stat().st_mode&511;assert b'mod loop45_original_ir_probe;' not in original
 applied=True;HELPER.write_bytes(original+b'\n#[path = "/private/tmp/jarde-loop45-ir-probe-prep-luna-v1-20261019/probe.rs"]\nmod loop45_original_ir_probe;\n');record['temporary_helper']=pin(HELPER);record['status']='running';save()
 argv=['python3','-B',str(ROOT/'openspec/changes/recover-branch-throw-return-finally/tools/run_validation.py'),str(RUN),str(LAUNCH/'commands.json')];record['argv']=argv;save()
 with (LAUNCH/'stdout.raw').open('xb') as so,(LAUNCH/'stderr.raw').open('xb') as se:r=subprocess.run(argv,cwd=ROOT,stdout=so,stderr=se)
 record['runner_exit_code']=r.returncode
 if (RUN/'execution.json').exists():
  actual=json.loads((RUN/'execution.json').read_text());record['runner_receipt']=pin(RUN/'execution.json');record['runner_status']=actual['status'];assert actual['source_unchanged'] and actual['target_absent'];assert actual['status']=='commands_passed_pending_independent_acceptance'
 r.check_returncode();record['status']='probe_executed_pending_trace_review'
except BaseException as e:record.update(status='failed',error=repr(e),traceback=traceback.format_exc())
finally:
 if applied:HELPER.write_bytes(original);HELPER.chmod(mode)
 try:
  record['pins_after']=verify();record['inputs_and_source_restored']=record.get('pins_before')==record['pins_after'];record['helper_restored']=original is not None and HELPER.read_bytes()==original;record['target_absent']=not (ROOT/'target').exists();assert record['inputs_and_source_restored'] and record['helper_restored'] and record['target_absent']
 except BaseException as e:record.update(status='failed',finally_error=repr(e))
 record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({k:record.get(k) for k in ['status','error','finally_error','runner_exit_code','helper_restored','target_absent']}))
sys.exit(0 if record['status']=='probe_executed_pending_trace_review' else 1)
