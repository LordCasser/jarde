#!/usr/bin/env python3
"""Parse and compare Loop5 extended driver receipts; Python standard library only."""
import argparse, base64, json, pathlib, sys

def dec(s): return base64.b64decode(s, validate=True).decode('utf-8')
def parse(path):
    rows=[]; check=None
    for n,line in enumerate(pathlib.Path(path).read_text().splitlines(),1):
        f=line.split()
        if not f: continue
        kind=f[0]; d={}
        for item in f[1:]:
            if '=' not in item: raise ValueError(f'{path}:{n}: malformed field {item!r}')
            k,v=item.split('=',1); d[k]=v
        if kind=='CASE':
            d['index']=int(d['index']);
            for k in ['input_label_b64','result_b64','exception_message_b64','exception_stack_b64','target_stdout_b64']:
                d[k[:-4] if k.endswith('_b64') else k]=dec(d[k])
            d['input']=None if d['input_kind']=='null' else dec(d['input_b64'])
            d['after']=None if d['after_kind']=='null' else dec(d['after_b64'])
            rows.append(d)
        elif kind=='CHECK':
            if check is not None: raise ValueError(f'{path}:{n}: duplicate CHECK')
            check={**d,'stdout':dec(d['stdout_b64']),'exception_message':dec(d['exception_message_b64']),'exception_stack':dec(d['exception_stack_b64'])}
        else: raise ValueError(f'{path}:{n}: unknown record {kind!r}')
    if len(rows)!=12 or check is None: raise ValueError(f'{path}: expected 12 CASE and 1 CHECK, got {len(rows)} and {check is not None}')
    if [x['index'] for x in rows]!=list(range(12)): raise ValueError(f'{path}: CASE indices are not 0..11')
    if rows[10]['input'] is not None or rows[10]['input_label']!='<JAVA_NULL>': raise ValueError(f'{path}: null sentinel/input mismatch')
    return {'cases':rows,'check':check}

def comparable(x):
    return [{k:r[k] for k in ['index','name','input_kind','input_label','input','result','exception','exception_message','exception_stack','target_stdout','after']} for r in x['cases']]

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('receipts',nargs='+'); ap.add_argument('--against',help='receipt path to compare case rows against'); ap.add_argument('--out',required=True); a=ap.parse_args()
    parsed={p:parse(p) for p in a.receipts}; ref=parse(a.against) if a.against else None
    out={'schema':'jarde.loop5.extended-cases.results.v1','status':'parsed','receipts':parsed}
    if ref:
        out['case_comparison']={p:{'matches':comparable(v)==comparable(ref),'check_matches':v['check']==ref['check']} for p,v in parsed.items()}
    pathlib.Path(a.out).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
    bad=[p for p,v in out.get('case_comparison',{}).items() if not v['matches']]
    return 1 if bad else 0
if __name__=='__main__': sys.exit(main())
