# Loop5 extended case oracle preparation

This private package prepares a 12-case append-only behavior comparison. It has not run Java, javac, Jarde, Git, or network commands. The original baseline is unchanged.

The frozen baseline receipt is `/private/tmp/jarde-testbreakinloop5-baseline-root-v1-20261019/execution.json`; `plan/pins.json` pins that receipt, both Java executables, the driver and wrapper, dependency JARs, and a digest/count for each dependency directory pin map. Verify dependency directory contents against the full `dependency_directory_pins` value in the receipt before running. The baseline wrapper itself is reused by path and SHA; its argv layout is preserved in `plan/commands.json`.

`driver/TestBreakInLoop5ExtendedDriver.java` preserves the original five cases and adds 15M, 2g, m, 1..2, 0M, actual Java null, and the oversized numeric string. The null row displays `<JAVA_NULL>` in `input_label_b64`, declares `input_kind=null`, has `input_b64=-`, and passes a Java null reference to `test`.

Compile the driver with the pinned javac8 argv template after changing only `-d` to a fresh private driver-classes path and supplying this driver source. Keep the runtime application classpath limited to that driver classes directory. For each class root, invoke the pinned runtime wrapper with a dedicated empty cwd, 30-second timeout, runtime executable, `-Xverify:all`, the baseline `-Dtest.dependencies=...`, driver-only `-cp`, `TestBreakInLoop5ExtendedDriver`, then actual root, expected CodeSource root, and empty cwd. The exact original runtime argument templates and class roots are in `plan/commands.json`; only the root/cwd and driver class name/path need to be switched for each new execution directory.

Run the original debug and no-debug full class roots under javac8 and javac23 first to establish the added-case oracle. Then run the same driver over every successfully compiled generated class root from the closed Loop5 baseline, each under both runtimes. Preserve each complete stdout and stderr byte stream and its SHA-256 in the caller's receipt. The driver emits twelve `CASE` lines followed by one independent `CHECK` line; a check/framework error must not be mixed into case results.

Use `python3 -B parse_extended_receipts.py --out results.json <receipt stdout files...>`. To compare case behavior to an oracle receipt, add `--against <oracle stdout>`. The parser compares each full case observation, excluding `CHECK`; it reports check comparison separately.
