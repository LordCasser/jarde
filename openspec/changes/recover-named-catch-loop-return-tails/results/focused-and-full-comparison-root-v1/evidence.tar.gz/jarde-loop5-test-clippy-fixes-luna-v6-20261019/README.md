# Loop5 test Clippy cleanup v6 (private)

Base file SHA and candidate/patch SHAs are in `pins.json`. This changes only four test idioms in `loop5_return_tail_tests.rs`: boolean `assert_eq!` becomes equivalent `assert!`/`assert!(!...)`, `filter_map` to `filter(matches!(...))`, and `iter().any` equality to `contains`. Production code and assertion conditions are unchanged.

No shared files were written and no Rust/Cargo/rustfmt or other toolchain ran. Root should integrate the patch and rerun only the requested Clippy/fmt/CLI gates; the complete focused run already passed all 540 library tests and four public tests before this test-only cleanup.
