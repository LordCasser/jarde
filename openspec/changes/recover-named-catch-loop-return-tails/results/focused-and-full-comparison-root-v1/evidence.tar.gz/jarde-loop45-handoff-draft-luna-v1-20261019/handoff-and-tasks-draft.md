# Loop4/5 最终验收与交接草稿（待填证据）

> 状态：实现已集成，最后一处 Clippy 机械 lint 修复已集成；root 正在执行新的静态预检与 CLI 构建。本草稿不代表最终验收。

## 当前实现与已过门

Loop4 在现有自然循环边界内复用闭合的 break-body DAG 证明和既有 `Sequence`/`If`/`LoopBreak` 表达。只有 owner 唯一、单入口、无环、所有路径收敛到同一循环出口的分支体才能并入；自然循环集合不扩张，break 继续保留物理来源。

Loop5 在普通命名 catch 试探里组合初始化前缀、完整 `While` 和受保护的返回表达式。唯一边界外指令仍是范围右边界的真实末尾 `return`；自然循环和物理异常范围保持原样，named-row、owner、visited 增量及候选回滚沿用既有证明路径。

Builder 对共享槽的 catch 头绑定复用 `RegionPaths.catch_parameters` 的精确 catch 身份，只排除映射 handler 首条 store 所读的该 handler 自身 `Stack(0)` Phi。普通局部类型判断、whole 槽身份、resource/catch 声明和 catch 逃逸检查保持原契约；未引入一般槽拆分或泛化 Phi 放宽。

目前已通过：定向 Java lib **540**、公开 gates **4**、Reader **1**、fingerprint **5 通过 / 1 既有 ignored**。随后集成了 Clippy **4** 项机械 lint 修复；新的静态预检和 CLI build **进行中**。这些结果不得替代最终工作区或产品自身 CI。

## 待补证据与状态

| 门 | 当前状态 | 最终记录字段 |
|---|---|---|
| 静态预检、最终 CLI 构建 | 进行中 | `[退出码] [raw/receipt 路径及 SHA] [最终 CLI 路径/字节数/模式/SHA]` |
| Loop4/5 三方完整矩阵 | 待运行 | `[原件/JADX/Jarde 每目标命令数] [8 API] [全部方法/字段] [整类编译尝试与结果] [JDK8 55/52 边界]` |
| 隔离 VM 与运行观察 | 待运行 | `[按 profile/runtime 的 VM 数] [全部原件 case 与 check 结果] [stdout/异常原流] [原件与生成物对照]` |
| 错根、source map、default/all | 待运行 | `[CodeSource 错根拒绝] [物理来源映射与引用范围] [default/all 正文、identity、quality、maps 一致性]` |
| Loop5 12 例扩展 oracle | 待运行 | `[12 个输入/期望/原件/生成物观察逐项结果] [VM/runtime/profile]` |
| 全工作区验收 | 待运行 | `[target 数/分批/通过-失败-既有忽略] [具名门及退出码] [空间、守卫、target 清理收据]` |
| 产品自身 CI | 待运行 | `[提交] [CI run URL] [全部 job/独立步骤/双 seed 具名结果] [源码与产物绑定]` |
| OpenSpec / handoff / 账本 | 待完成 | `[主 spec 同步] [strict 校验] [最终 source/CLI/证据 pin] [提交/工作树审计]` |

三方矩阵必须完整保留 outer、target、构造器、`test` 与 `check`；每个方法、字段及失败原流都如实记录。JDK8 下原 JADX framework class major 55/52 的编译失败是已知基线边界，单独列出，不可算作成功，也不可掩盖 JDK23 或 Jarde 的失败。只有独立审阅闭合 raw、输出映射和 VM 结果之后，才能勾选相应验收项。

## 任务勾选草稿

### `recover-proved-loop-break-branch-bodies`

- [x] 1.1–1.2 冻结证据及完整 Loop4 fixtures 已完成。
- [x] 2.1–2.2 Reader 正反例、owner、Stop/rollback 定向验证已通过（当前记录：lib540/public4/Reader1/fingerprint5+1 ignored）。
- [ ] 3.1 Loop4 完整三方矩阵、整类重编、双 VM、check、错根和 source map；待最终 raw 审核。
- [ ] 3.2 全工作区与该产品自身 CI；待运行并逐项复核。
- [ ] 3.3 主 spec strict、handoff/71 单元账本局部状态及最终 Git/clean/target 审计；只在完整验收后更新。

### `recover-named-catch-loop-return-tails`

- [x] 1.1 冻结证据及真实 IR 已完成。
- [x] 2.1–2.4 Reader、Loop5 catch binding Builder 与负例/停止门已过当前定向门（当前记录：lib540/public4/Reader1/fingerprint5+1 ignored）。
- [ ] 3.1 Loop4/5 完整三方矩阵、整类重编、双 VM、check、错根、maps 和 Loop5 12 例扩展；待最终 raw 审核。
- [ ] 3.2 全工作区及产品自身 CI；待运行并逐项复核。
- [ ] 3.3 主 spec strict、handoff/账本、提交推送与最终工作树审计；只在完整验收后更新。

## 覆盖账本措辞（最终验收前不要更新）

固定 13 个原件中当前仍记为 **7 项完整接受、2 项已确认 gap 正在修复、4 项待完整基线/处理**。只有 Loop4/5 全部完成上述三方矩阵、扩展 case、全工作区与新产品自身 CI，并完成独立证据审计后，才把两项转为 accepted 并记为 **9/13**。在此之前不得把已通过的 Rust 定向门或成功构建写成两项完整交付。

**CF09、71 单元、612 文件整体继续标为 partial**；本轮只更新 Loop4/5 的精确局部事实，不扩张总分母或完成声明。
