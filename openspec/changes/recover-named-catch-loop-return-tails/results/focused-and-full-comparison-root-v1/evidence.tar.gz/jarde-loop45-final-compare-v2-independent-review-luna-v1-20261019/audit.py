import base64, hashlib, json, re, struct
from collections import Counter
from pathlib import Path

NEW = Path('/private/tmp/jarde-loop45-final-compare-v2-independent-review-luna-v1-20261019')

def sha(b): return hashlib.sha256(b).hexdigest()
def pin(path):
    b=Path(path).read_bytes(); return {'path':str(path),'bytes':len(b),'sha256':sha(b)}
def readjson(p): return json.loads(Path(p).read_text())
def verify_pin_record(r):
    b=Path(r['path']).read_bytes()
    assert len(b)==r['bytes'] and sha(b)==r['sha256'], r['path']
    return b
def verify_pin_map(m):
    count=0
    for rec in m.values():
        if isinstance(rec,dict) and 'path' in rec:
            verify_pin_record(rec); count+=1
        elif isinstance(rec,list):
            for x in rec:
                if isinstance(x,dict) and 'path' in x: verify_pin_record(x); count+=1
    return count
def dec(s): return base64.b64decode(s).decode('utf-8')
def check_stream(record):
    p=Path(record['path']); b=p.read_bytes()
    assert len(b)==record['bytes'], (p,len(b),record['bytes'])
    assert sha(b)==record['sha256'], p
    return b

def class_inventory(report):
    return {'class':report['class'], 'fields':report['fields'], 'methods':[
        {'declaration':m['declaration'],'identity':m['item']['identity'],
         'access_flags':m['item']['access_flags'],'quality':m['outcome']['report']['quality'],
         'method':m['outcome']['report']['method'],
         'source_map':m['outcome']['report']['source_map'],
         'text':m['text']}
        for m in report['methods']]}

def canonical_rows(rows, loop):
    # Reconstruct the physical line protocol from individual fields, not the receipt's parsed rows.
    raw_lines=[]
    for i,row in enumerate(rows):
        assert row['raw'].startswith(f'CASE index={i} ')
        fields=dict(re.findall(r'([A-Za-z0-9_]+)=([^ ]*)',row['raw']))
        assert int(fields['index'])==i
        assert dec(fields['input_b64'])==row['input']
        assert dec(fields['result_b64'])==row['result']
        assert dec(fields['after_b64'])==row['after']
        assert dec(fields['target_stdout_b64'])==row['target_stdout']
        assert fields['exception']==row['exception_type']
        assert dec(fields['exception_message_b64'])==row['exception_message']
        assert dec(fields['exception_stack_b64'])==row['exception_stack']
        if loop==5 and 'check_exception' in fields:
            assert i == len(rows)-1
            assert fields['check_exception']==row['check_exception']
            assert dec(fields['check_stdout_b64'])==row['check_stdout']
    return [{'input':r['input'],'result':r['result'],'exception_type':r['exception_type'],
             'exception_message':r['exception_message'],'exception_stack':r['exception_stack'],
             'target_stdout':r['target_stdout'],'after':r['after']} for r in rows]

def run_target(n):
    root=Path(f'/private/tmp/jarde-testbreakinloop{n}-final-compare-root-v2-20261019')
    old=Path(f'/private/tmp/jarde-testbreakinloop{n}-final-compare-root-v1-20261019')
    receipt=readjson(root/'execution.json'); oldrec=readjson(old/'execution.json')
    plan=readjson(receipt['case_plan']['path'])
    assert plan['source']['sha256']==receipt['source']['sha256']
    planned=[{'name':c['id'],'input':c['input'],'return':'return='+c['expected']['return'],
              'exception_type':c['expected']['exception_type'],'stdout':c['expected']['stdout'],
              'after':c['expected'].get('after',c['input'])} for c in plan['cases']]
    assert receipt['status']=='captured-pending-independent-review'
    assert len(receipt['commands'])==70
    assert receipt['source']['sha256']==('42b0f55b653b41bc69286e1947c8a19d94b0da810cdcc7cf48bb6d2cd6a256e5' if n==4 else '4aef48802b7dc7cc47c7c03d6c2639103c2913345cb8be8818545e63ed1fea64')
    assert receipt['cli']['sha256']=='d29b6fee723d8f59fbecd9fd8be9f15a8ec73de3a90f5a2a29b24ff91e4af607'
    assert receipt['cli']['bytes']==64631664
    command_pins=[]
    for c in receipt['commands']:
        assert c['index'] in range(1,71)
        assert c['exit_code'] is not None
        for stream in ('stdout','stderr'):
            b=check_stream(c['streams'][stream]); command_pins.append(c['streams'][stream])
    assert len(command_pins)==140
    old_labels=Counter(c['label'] for c in oldrec['commands'])
    assert oldrec['status']=='captured-pending-independent-review' and len(oldrec['commands'])==70
    assert old_labels==Counter(c['label'] for c in receipt['commands'])
    labels=Counter(c['label'] for c in receipt['commands'])
    assert len(labels)==70 and all(v==1 for v in labels.values())
    assert receipt['source_unchanged'] and receipt['source_unchanged_finally']
    assert receipt['source_pins_before']==receipt['source_pins_after_finally']
    assert receipt['local_copy_pins_before']==receipt['local_copy_pins_after_finally']
    assert receipt['external_input_pins_before']==receipt['external_input_pins_after_finally']
    reopened_repo_files=verify_pin_map(receipt['source_pins_after_finally'])
    reopened_generated_sources=verify_pin_map(receipt['generated_source_output_pins_after'])
    # Reopen physical class and JAR inputs as well as source reports.
    reopened_profile_classes=0
    for profile in receipt['source_profiles']:
        for fact in profile['class_tree'].values():
            raw=verify_pin_record(fact); assert raw[:4]==b'\xca\xfe\xba\xbe'; reopened_profile_classes+=1
    reopened_successful_class_files=0
    for tree in receipt['generated_class_trees_after'].values():
        if isinstance(tree,dict):
            for fact in tree.values():
                verify_pin_record(fact); reopened_successful_class_files+=1
    reopened_external_inputs=verify_pin_map(receipt['external_input_pins_after_finally'])
    assert receipt['local_copies_unchanged'] and receipt['local_copies_unchanged_finally']
    assert receipt['external_inputs_unchanged']
    assert receipt['target_absent'] and receipt['target_absent_finally']
    assert receipt['generated_outputs_unchanged']
    assert receipt['counts_derived_from_commands']
    assert len(receipt['generated_source_compilations'])==20
    comp=receipt['generated_source_compilations']
    success=[x for x in comp if x['exit_code']==0]
    failure=[x for x in comp if x['exit_code']!=0]
    assert len(success)==10 and len(failure)==10
    assert all(x['runtime_eligible'] for x in success)
    assert Counter((x['kind'],x['compiler']) for x in success)==Counter({('jarde','javac23'):8,('jadx','javac23'):2})
    assert all(x['compiler']=='javac8' for x in failure)
    assert all(x['runtime_eligible'] is False for x in failure)
    for failed in failure:
        stderr=Path(failed['stderr']['path']).read_text()
        assert '55.0' in stderr and '52.0' in stderr
    assert len(receipt['generated_runtime'])==20 and len(receipt['original_runtime'])==4
    assert len(receipt['generated_wrong_root_controls'])==10
    assert all(x['exit_code']==1 and x['rejected'] for x in receipt['generated_wrong_root_controls'])
    assert receipt['wrong_root_control']['exit_code']==1 and receipt['wrong_root_control']['rejected']
    assert len(receipt['jarde_cells'])==8 and len(receipt['jadx_outputs'])==2
    # Reopen API stdout bytes as complete JSON; derive method count/identity/quality from actual reports.
    api=[]
    commands_by_index={c['index']:c for c in receipt['commands']}
    for cell in receipt['jarde_cells']:
        api_cmd=commands_by_index[cell['command']]
        assert check_stream(api_cmd['streams']['stdout'])==Path(cell['report']['path']).read_bytes()
        raw=Path(cell['report']['path']).read_bytes()
        assert sha(raw)==cell['report']['sha256'] and len(raw)==cell['report']['bytes']
        assert raw==Path(cell['whole_source']['path']).read_bytes() if cell.get('whole_source_is_report') else True
        report=json.loads(raw)
        assert cell['exit_code']==0 and report['outcome']=='performed' and report['diagnostics']==[]
        assert len(report['methods'])==3 and report['fields']==[]
        descriptors=[bytes(m['item']['identity']['descriptor']).decode('ascii') for m in report['methods']]
        assert descriptors == (['()V','(C)D','()V'] if n==4 else ['()V','(Ljava/lang/String;)J','()V'])
        assert all(m['item']['access_flags']==1 for m in report['methods'])
        methods=[]
        for m in report['methods']:
            rr=m['outcome']['report']
            assert m['outcome']['kind']=='recovered'
            assert rr['quality']=='structured'
            assert rr['source_map']['segments']
            methods.append({'declaration':m['declaration'],'method':rr['method'],'quality':rr['quality'],
                            'text':m['text'],'source_map':rr['source_map']})
        api.append({'profile':cell['profile'],'form':cell['input_form'],'evidence':cell['evidence'],
                    'report_path':cell['report']['path'],'text':Path(cell['whole_source']['path']).read_text(),
                    'methods':methods,'inventory':class_inventory(report)})
    assert len(api)==8 and all(len(x['methods'])==3 for x in api)
    assert {(x['profile'],x['form'],x['evidence']) for x in api} == {
        (profile,form,evidence) for profile in ('debug','no-debug')
        for form in ('child','bundle-child') for evidence in ('default','all')}
    source_inventory=[]
    for profile in receipt['source_profiles']:
        facts=profile['target_facts']
        assert facts['fields']==[]
        method_rows=[(m['name'],m['descriptor'],m['access']) for m in facts['methods']]
        assert method_rows==[('<init>','()V',1),('test','(C)D' if n==4 else '(Ljava/lang/String;)J',1),('check','()V',1)]
        source_inventory.append({'profile':profile['profile'],'target_sha256':facts['sha256'],
                                 'target_bytes':facts['bytes'],'major':facts['major'],
                                 'fields':facts['fields'],'methods':method_rows,
                                 'class_tree_paths':sorted(profile['class_tree'])})
    # On each physical class, default/all and child/bundle-child have stable body text and maps.
    for profile in ('debug','no-debug'):
        group=[x for x in api if x['profile']==profile]
        assert len(group)==4
        by_ev={x['evidence']:x for x in group if x['form']=='child'}
        assert by_ev['default']['text']==by_ev['all']['text']
        for a,b in zip(by_ev['default']['methods'],by_ev['all']['methods']):
            assert a['text']==b['text'] and a['source_map']==b['source_map']
        assert len({x['text'] for x in group})==1
        group_by={(x['form'],x['evidence']):x for x in group}
        for form in ('child','bundle-child'):
            for a,b in zip(group_by[(form,'default')]['methods'],group_by[(form,'all')]['methods']):
                assert a['text']==b['text'] and a['quality']==b['quality'] and a['source_map']==b['source_map']
        for evidence in ('default','all'):
            for a,b in zip(group_by[('child',evidence)]['methods'],group_by[('bundle-child',evidence)]['methods']):
                def mapped_bcis(method):
                    return sorted({e['bci'] for seg in method['source_map']['segments']
                                   for e in (([seg['origin']['primary']] if seg['origin'].get('primary') else [])+
                                             seg['origin'].get('derived',[]))})
                assert a['text']==b['text'] and a['quality']==b['quality'] and mapped_bcis(a)==mapped_bcis(b)
    # Same physical execution source/artifact must be byte-identical to v1 for text, quality and source maps.
    old_api=[]
    old_commands={c['index']:c for c in oldrec['commands']}
    for cell in oldrec['jarde_cells']:
        report=readjson(cell['report']['path'])
        assert check_stream(old_commands[cell['command']]['streams']['stdout'])==Path(cell['report']['path']).read_bytes()
        old_api.append({'profile':cell['profile'],'form':cell['input_form'],'evidence':cell['evidence'],
                        'text':Path(cell['whole_source']['path']).read_text(),
                        'methods':[{'declaration':m['declaration'],'quality':m['outcome']['report']['quality'],
                                    'source_map':m['outcome']['report']['source_map'],'text':m['text']} for m in report['methods']]})
    oldlookup={(x['profile'],x['form'],x['evidence']):x for x in old_api}
    deltas=[]
    for x in api:
        o=oldlookup[(x['profile'],x['form'],x['evidence'])]
        same_text=x['text']==o['text']
        same_quality=[m['quality']==om['quality'] for m,om in zip(x['methods'],o['methods'])]
        same_maps=[m['source_map']==om['source_map'] for m,om in zip(x['methods'],o['methods'])]
        deltas.append({'profile':x['profile'],'form':x['form'],'evidence':x['evidence'],
                       'text_identical_to_v1':same_text,'method_quality_identical_to_v1':all(same_quality),
                       'method_maps_identical_to_v1':all(same_maps)})
    # Raw runtime CASE rows independently decode to the receipt records and must agree across runtimes.
    expected_cases=4 if n==4 else 5
    original=[]
    for obs in receipt['original_runtime']:
        assert obs['application_classpath']==[str(root/'driver-classes')]
        stdout=check_stream(obs['stdout']).decode()
        lines=[line for line in stdout.splitlines() if line.startswith('CASE ')]
        assert len(lines)==expected_cases
        assert len(obs['rows'])==expected_cases
        canonical=canonical_rows(obs['rows'],n)
        assert lines==[r['raw'] for r in obs['rows']]
        assert [{'name':r['name'],'input':r['input'],'return':r['result'],
                 'exception_type':r['exception_type'],'stdout':r['target_stdout'],'after':r['after']}
                for r in obs['rows']] == planned
        check_lines=[line for line in stdout.splitlines() if line.startswith('CHECK ')]
        assert len(check_lines)==(1 if n==4 else 0)
        original.append({'profile':obs['profile'],'runtime':obs['runtime'],'cases':canonical,
                         'check_line':check_lines[0] if check_lines else None,
                         'rows':obs['rows'],'stdout_sha256':obs['stdout']['sha256']})
    assert len(original)==4
    if n==4:
        check_matrix=receipt['check_results_by_runtime']
        assert check_matrix['debug/javac23']['result']=='pass' and check_matrix['no-debug/javac23']['result']=='pass'
        assert check_matrix['debug/javac8']['exception_type']=='java.lang.UnsupportedClassVersionError'
        assert check_matrix['no-debug/javac8']['exception_type']=='java.lang.UnsupportedClassVersionError'
    else:
        check_matrix={f"{x['profile']}/{x['runtime']}":x['rows'][-1]['check_exception'] for x in receipt['original_runtime']}
        assert all(check_matrix[k]=='none' for k in ('debug/javac23','no-debug/javac23'))
        assert all(check_matrix[k]=='java.lang.UnsupportedClassVersionError' for k in ('debug/javac8','no-debug/javac8'))
    case_sigs={json.dumps(x['cases'],sort_keys=True) for x in original}
    assert len(case_sigs)==1
    # Generated 20 executions match same profile/runtime original's semantic observations and separate check protocol.
    original_by={(x['profile'],x['runtime']):x for x in original}
    generated=[]
    for obs in receipt['generated_runtime']:
        assert obs['application_classpath']==[str(root/'driver-classes')]
        stdout=check_stream(obs['stdout']).decode()
        lines=[line for line in stdout.splitlines() if line.startswith('CASE ')]
        assert len(lines)==expected_cases and len(obs['rows'])==expected_cases
        canonical=canonical_rows(obs['rows'],n)
        assert lines==[r['raw'] for r in obs['rows']]
        orig=original_by[(obs['profile'],obs['runtime'])]
        assert canonical==orig['cases'], (n,obs['profile'],obs['kind'],obs['runtime'])
        check_lines=[line for line in stdout.splitlines() if line.startswith('CHECK ')]
        if n==4:
            assert len(check_lines)==1 and check_lines[0]==orig['check_line']
        else:
            assert len(check_lines)==0
        generated.append({'kind':obs['kind'],'profile':obs['profile'],'form':obs['form'],
                          'evidence':obs['evidence'],'compiler':obs['compiler'],'runtime':obs['runtime'],
                          'cases':canonical,'check_line':check_lines[0] if check_lines else None})
    assert len(generated)==20
    if n==5:
        check_matrix={}
        for orig in receipt['original_runtime']:
            row=orig['rows'][-1]
            check_matrix[f"{orig['profile']}/{orig['runtime']}"]={'exception':row['check_exception'],'stdout':row['check_stdout']}
        for obs in receipt['generated_runtime']:
            orig=original_by[(obs['profile'],obs['runtime'])]
            assert obs['rows'][-1]['check_exception']==orig['rows'][-1]['check_exception']
            assert obs['rows'][-1]['check_stdout']==orig['rows'][-1]['check_stdout']
        source_plan_check={f"{x['profile']}/{x['runtime']}":{'matches':x['source_plan_comparison_matches'],
                           'issues':x['source_plan_comparison_issues']} for x in receipt['original_runtime']}
        assert all(source_plan_check[k]['matches'] for k in ('debug/javac23','no-debug/javac23'))
        assert all(not source_plan_check[k]['matches'] for k in ('debug/javac8','no-debug/javac8'))
    # Source copy/profile and CLI bindings are stable and no wrong-root execution emits the target CASE protocol.
    for control in receipt['generated_wrong_root_controls']:
        out=check_stream(control['stdout']).decode()
        assert 'CASE ' not in out and 'CHECK ' not in out
    control=receipt['wrong_root_control']
    out=check_stream(control['stdout']).decode()
    assert 'CASE ' not in out and 'CHECK ' not in out
    # Independently derive test() BCI coverage from physical class facts and every source-map origin.
    primary=[]
    for profile_row in receipt['source_profiles']:
        profile=profile_row['profile']
        source_method=next(m for m in profile_row['target_facts']['methods'] if m['name']=='test')
        code_bcis=set(source_method['code']['bcis'])
        x=next(x for x in api if x['profile']==profile and x['form']=='child' and x['evidence']=='default')
        m=x['methods'][1]
        report=readjson(x['report_path'])
        test_report=report['methods'][1]['outcome']['report']
        mapped=set()
        for seg in test_report['source_map']['segments']:
            origin=seg.get('origin',{})
            entries=([origin['primary']] if origin.get('primary') else [])+origin.get('derived',[])
            for entry in entries:
                if entry['method']['name']==[116,101,115,116]: mapped.add(entry['bci'])
        primary.append({'profile':profile,'method_bci_count':len(code_bcis),'mapped_bci_count':len(mapped),
                        'missing_bcis':sorted(code_bcis-mapped),'extra_bcis':sorted(mapped-code_bcis),
                        'quality':m['quality']})
    expected_mapping=(23 if n==4 else 59)
    assert all(x['mapped_bci_count']==expected_mapping for x in primary)
    assert all(x['missing_bcis']==([] if n==4 else [103]) for x in primary)
    # The prior baseline v1 is a true pre-recovery baseline; report deltas without assuming text identity.
    v1_deltas={
        'cells_compared':len(deltas),
        'all_text_identical':all(x['text_identical_to_v1'] for x in deltas),
        'all_quality_identical':all(x['method_quality_identical_to_v1'] for x in deltas),
        'all_maps_identical':all(x['method_maps_identical_to_v1'] for x in deltas),
        'different_text_cells':sum(not x['text_identical_to_v1'] for x in deltas),
        'different_quality_cells':sum(not x['method_quality_identical_to_v1'] for x in deltas),
        'different_map_cells':sum(not x['method_maps_identical_to_v1'] for x in deltas),
    }
    # Aggregate raw integrity, proving 70 commands have two independently verified streams each.
    return {'loop':n,'receipt':pin(root/'execution.json'),'commands':70,'raw_streams':140,
            'all_raw_streams_rehashed':True,'raw_pins':command_pins,'command_labels':dict(labels),
            'cli':receipt['cli'],'source':receipt['source'],'case_plan_inputs_and_oracles':planned,'source_class_inventory':source_inventory,'compile_attempts':20,
            'compile_successes':10,'successful_compiles':dict(Counter(x['kind'] for x in success)),
            'jdk8_framework_boundary_failures':10,'generated_vm_runs':len(generated),
            'reopened_repository_source_files':reopened_repo_files,'reopened_generated_source_files':reopened_generated_sources,
            'reopened_original_profile_class_files':reopened_profile_classes,'reopened_generated_class_files':reopened_successful_class_files,
            'reopened_external_input_files':reopened_external_inputs,
            'original_vm_runs':len(original),'wrong_code_source_controls':10,
            'api_calls':len(api),'structured_methods':sum(len(x['methods']) for x in api),
            'default_all_text_maps_stable':True,'old_v1_comparisons':deltas,
            'original_runtime_cases':original,'generated_runtime_cases':generated,
            'primary_method_mapping':primary,'v1_delta_summary':v1_deltas,'runtime_semantic_agreement':receipt['runtime_semantic_agreement'],
            'manual_oracle_agreement':receipt.get('manual_oracle_agreement'),
            'check_results_by_runtime':receipt.get('check_results_by_runtime') if n==4 else check_matrix,
            'loop5_source_plan_check_status':source_plan_check if n==5 else None,
            'source_unchanged':receipt['source_unchanged'] and receipt['source_unchanged_finally'],
            'local_copies_unchanged':receipt['local_copies_unchanged'] and receipt['local_copies_unchanged_finally'],
            'external_inputs_unchanged':receipt['external_inputs_unchanged'],
            'generated_outputs_unchanged':receipt['generated_outputs_unchanged'],
            'target_absent':receipt['target_absent'] and receipt['target_absent_finally'],
            'javac8_boundary':receipt['javac8_full_source_boundary'],
            'source_profiles':receipt['source_profiles'],'dependency_directory_pins':receipt['dependency_directory_pins'],
            'old_v1_reference':str(old/'execution.json'),'note':'Derived independently from closed v2 execution receipt, all v2 raw streams, API reports and v1 reports; no tools rerun.'}

results=[run_target(4),run_target(5)]
(NEW/'review.json').write_text(json.dumps({'schema':'jarde.loop45.final-compare-v2-independent-review.v1','status':'raws_reopened_independently','targets':results,'scope':'No tools run; do not access the still-open extended-final-v2 receipt.'},indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':'verified','targets':[{'loop':r['loop'],'commands':r['commands'],'raw_streams':r['raw_streams'],'api_calls':r['api_calls'],'structured_methods':r['structured_methods'],'compile_successes':r['compile_successes'],'generated_vm_runs':r['generated_vm_runs'],'original_vm_runs':r['original_vm_runs'],'wrong_code_source_controls':r['wrong_code_source_controls'],'v1_exact':all(x['text_identical_to_v1'] and x['method_quality_identical_to_v1'] and x['method_maps_identical_to_v1'] for x in r['old_v1_comparisons'])} for r in results]},indent=2))
