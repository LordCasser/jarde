# Loop4/5 typed-boundary budget regression review

The closed native batch 85 output shows `typed_boundary_proof_budget_stops_before_publication_at_observed_sites` failing at the exact-stop assertion. It expects `AnalysisSteps`, `written: 0`, the supplied limit, and the observed BCI, then checks that no content, binding, text, or source map was published. The two unchanged thresholds are 365 at BCI 29 for the char-switch fixture and 130 at BCI 1 for the null-switch fixture. The batch has 8 passes and this one failure.

The static evidence favors the candidate-scan precharge as the cost bug. `Frame` stores `Vec<LoopTarget>`; the break-body proof is held by `LoopTarget.break_body: Option<Arc<LoopBreakBodyProof>>`, not as a direct Frame field. No `size_of`/`size_of_val` accounting for Frame, LoopTarget, or LoopBreakBodyProof appears in the region/build/test implementation. The failing dimension is explicit `AnalysisSteps`.

`header_tested_loop` can call `loop_break_branch_body` before it walks a loop body. That function's exact two-natural-exit condition is a necessary precondition for the proof, but the older implementation charged the conservative `blocks × (canonical edges + 1)` candidate-scan bound before checking it. A loop that had a single natural exit returned `None` without scanning candidate branches, after already paying the full bound. The char-switch fixture is a `for` loop containing a switch; root confirms its natural exit is unique.

The current shared source has moved the same three-line two-exit guard before the scan bound while retaining the cancellation poll. Comparison to the frozen `region.rs.base` snapshot confirms this is the only change in the extracted proof-function prefix. The retained patch SHA-256 is `40dc7e7fa54ba71418c88aee77ff8e40e11183246cf387e7261d58e1e9d718ba`. This is the minimal semantics-preserving adjustment: rejected one-exit candidates still return `None`, while eligible two-exit candidates still pay the same scan reservation and retain all proof checks.

This supports the static diagnosis and confirms the proposed code ordering is present. It does not confirm the fixed thresholds or suite pass; the owner-run native regression batch is still the required runtime check. No build, test, Git command, or toolchain was run for this review.

`review.json` records source and baseline pins, raw test evidence, static facts, and limitations.
