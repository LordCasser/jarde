#!/usr/bin/env python3
"""Read-only static audit of typed-boundary budget regression hypothesis."""
import hashlib,json,re
from pathlib import Path
OUT=Path('/private/tmp/jarde-loop45-budget-architecture-review-luna-v1-20261019')
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
BASE_REGION=Path('/private/tmp/jarde-loop4-v3-integration-root-v1-20261019/region.rs.base')
BASE_BUILD=Path('/private/tmp/jarde-loop5-builder-analysis-root-v1-20261019/build.rs.base')
TEST=ROOT/'crates/jarde-java/tests/cf12_proved_local_source_types.rs'
REGION=ROOT/'crates/jarde-java/src/region.rs'
BUILD=ROOT/'crates/jarde-java/src/build.rs'
RAW=Path('/private/tmp/jarde-loop45-native-root-v1-20261019/85.stdout.raw')
PATCH=Path('/private/tmp/jarde-loop4-cf12-scan-preflight-luna-v1-20261019/region.patch')

def sha(b): return hashlib.sha256(b).hexdigest()
def need(ok,msg):
    if not ok: raise AssertionError(msg)
def pin(path):
    b=path.read_bytes(); return {'path':str(path),'bytes':len(b),'sha256':sha(b)}
def extract(s,start,end):
    a=s.index(start); b=s.index(end,a)
    return s[a:b]

region=REGION.read_text(); baseline=BASE_REGION.read_text(); build=BUILD.read_text(); test=TEST.read_text()
raw=RAW.read_bytes().decode('utf-8',errors='replace')
patch_bytes=PATCH.read_bytes()
patch_text=patch_bytes.decode('utf-8')
base_fn=extract(baseline,'fn loop_break_branch_body(', 'let mut candidate = None')
current_fn=extract(region,'fn loop_break_branch_body(', 'let mut candidate = None')
frame=extract(region,'struct Frame {','\n}\n')
loop_target=extract(region,'struct LoopTarget {','\n}\n')
proof=extract(region,'struct LoopBreakBodyProof {','\n}\n')
need('if natural_exits.len() != 2 || !natural_exits.contains(&exit)' in current_fn,'current function lost exact two-exit gate')
need(current_fn.index('if natural_exits.len() != 2') < current_fn.index('let candidate_scan_bound = blocks'),'current function charges scan before eligibility gate')
need(base_fn.index('let candidate_scan_bound = blocks') < base_fn.index('if natural_exits.len() != 2'),'frozen baseline did not have pre-gate charge order')
need('saturating_mul(self.canonical.edges().len().saturating_add(1))' in current_fn,'expected O(blocks × edges) candidate bound absent')
need('CountedBudgetDimension::AnalysisSteps' in current_fn,'candidate scan charge dimension changed')
need('break_body: Option<Arc<LoopBreakBodyProof>>' in loop_target,'LoopTarget proof ownership changed')
need('break_body' not in frame,'LoopBreakBodyProof is not directly stored as a Frame field')
need('owners: BTreeSet<usize>' in proof,'proof owner payload changed')
need(not re.search(r'\bsize_of(?:_val)?\b',region+build+test),'unexpected size_of accounting in region/build/test')
need('CountedBudgetDimension::AnalysisSteps' in test and 'written: 0' in test,'test no longer asserts analysis budget stop before publication')
need('365,' in test and '29,' in test and '130,' in test and '1,' in test,'fixed CF12 threshold pins changed')
need('if natural_exits.len() != 2 || !natural_exits.contains(&exit)' in current_fn,'required early preflight absent from current source')
needs=['candidate_scan_bound','natural_exits.len() != 2','LoopBreakBodyProof','written: 0','StopReason::Budget']
for token in needs: need(token in (region+test),f'missing evidence token {token}')

outcomes=re.findall(r'^test .* \.\.\. (ok|FAILED|ignored)$',raw,re.M)
summary=re.findall(r'^test result: (.*)$',raw,re.M)
need(summary and '8 passed; 1 failed; 0 ignored' in summary[-1],'native batch 85 failure summary changed')
need('typed_boundary_proof_budget_stops_before_publication_at_observed_sites ... FAILED' in raw,'expected failing gate not present in closed native output')
need('assertion failed: matches!' in raw,'expected failure does not point to stop assertion')

# The feature's older snapshot already includes the proof and identical early rejection
# semantics, but originally prepaid the scan first. Check the exact minimal relocation.
base_prefix=base_fn[:]
current_prefix=current_fn[:]
needle='        if natural_exits.len() != 2 || !natural_exits.contains(&exit) {\n            return Ok(None);\n        }\n'
need(base_prefix.count(needle)==1 and current_prefix.count(needle)==1,'expected one eligibility gate per source')
base_without=base_prefix.replace(needle,'')
current_without=current_prefix.replace(needle,'')
need(base_without==current_without,'current proof function changed beyond gate relocation relative to selected baseline')

report={
 'schema':'jarde.loop45.typed-boundary-budget-static-review.v1',
 'status':'static_cost_cause_supported;_runtime_confirmation_pending',
 'evidence':{
  'current_region':pin(REGION),'current_build':pin(BUILD),'current_test':pin(TEST),
  'baseline_region_snapshot':pin(BASE_REGION),'baseline_build_snapshot':pin(BASE_BUILD),
  'native_batch85_stdout':pin(RAW),'three_line_gate_relocation_patch':pin(PATCH),
 },
 'failure_observed':{'summary':summary[-1],'failed_gate':'typed_boundary_proof_budget_stops_before_publication_at_observed_sites','assertion':'expected exact AnalysisSteps Stop at written=0, limit, and BCI; then content NotProduced, no artifact binding, empty text/source map','limits':{'char_switch':{'limit':365,'at_bci':29},'null_switch':{'limit':130,'at_bci':1}}},
 'static_facts':{
  'Frame_has_direct_LoopBreakBodyProof_field':False,
  'LoopTarget_stores_proof_through': 'Option<Arc<LoopBreakBodyProof>>',
  'size_of_accounting_for_Frame_LoopTarget_or_proof_in_region_build_test':False,
  'budget_dimension': 'AnalysisSteps',
  'call_site':'header_tested_loop calls loop_break_branch_body for eligible top-level loops before walking the body',
  'eligibility':'natural_exits must contain exactly two nodes including the selected break exit',
  'scan_precharge_bound':'blocks.len() * (canonical.edges().len() + 1)',
  'baseline_order':'prepaid candidate scan before checking the two-exit condition',
  'current_order':'keeps the cancellation poll, checks exact two-exit eligibility, then computes/prepays the scan only for eligible proofs',
  'integrated_patch_matches_relocation':'the retained 832-byte region.patch contains only this three-line predicate relocation; current source function matches its resulting order',
  'current_vs_selected_baseline':'the extracted loop_break_branch_body prefix differs only by relocating the three-line natural-exit gate before the scan bound/charge',
  'candidate_scan_for_ineligible_loop':'no branch/edge scan follows; the old code had nevertheless charged the full bound before returning None',
 },
 'assessment':{
  'size_of_Frame_hypothesis':'unsupported: the asserted failure is AnalysisSteps, no size_of/size_of_val accounting for Frame/LoopTarget/LoopBreakBodyProof appears in the relevant implementation or test, and Frame itself stores only Vec<LoopTarget> rather than the proof payload directly.',
  'unnecessary_scan_precharge_hypothesis':'strongly supported: a fixed-cost, necessary eligibility condition is evaluated only after a proportional O(blocks × edges) budget precharge, and rejected candidates return without scanning or producing a proof.',
  'minimal_correct_fix':'Evaluate natural_exits.len() == 2 and natural_exits.contains(exit) before the candidate-scan charge. Preserve the preceding budget poll for cancellation. Keep the conservative precharge unchanged for eligible two-exit proof candidates.',
  'correctness_reason':'The old code already returned None immediately for every non-two-exit case; moving that exact predicate earlier cannot make a previously refused candidate succeed. The only omitted work is a reservation for a scan that would never occur. The exact two-exit candidates retain the existing bound and route checks.',
  'remaining_limit':'No new native test or toolchain was run. Static inspection supports the cause and current source shows the gate relocation; only the owner-run closed regression batch can confirm the two pinned stops and the full suite.'
 },
 'test_fixture_context':'The closed output names CHAR_CLASS as TestSwitch.test(String) and NULL_CLASS as TestSwitchNoDefault.test(int); owner confirms the first fixture is a for loop containing a switch with one natural header exit. The function has no switch exclusion before charging, so that one-exit loop is eligible to hit the old unnecessary precharge path.',
 'integrated_patch_sha256':sha(patch_bytes),
 'source_line_refs':{'Frame':'crates/jarde-java/src/region.rs:4558','LoopBreakBodyProof':'crates/jarde-java/src/region.rs:4637','LoopTarget.break_body':'crates/jarde-java/src/region.rs:4778','loop caller':'crates/jarde-java/src/region.rs:19335','candidate preflight/charge':'crates/jarde-java/src/region.rs:22501','CF12 assertions':'crates/jarde-java/tests/cf12_proved_local_source_types.rs:706'},
 'scope':'Read-only source inspection, frozen local source snapshots, and already-closed native stdout only. No tools, tests, builds, or shared writes were performed.'
}
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':report['status'],'gate_move_minimal':True,'current_gate_before_charge':True,'baseline_gate_after_charge':True,'size_of_frame_cost_evidence':False,'failure_summary':summary[-1]},ensure_ascii=False))
