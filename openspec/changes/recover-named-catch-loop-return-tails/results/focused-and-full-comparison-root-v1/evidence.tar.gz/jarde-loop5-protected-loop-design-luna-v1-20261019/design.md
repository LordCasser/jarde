# Loop5 ordinary named-catch prefix + loop + return-tail design

Status: read-only design proposal. No shared file or production code was changed; no toolchain was run.

## Evidence and boundaries

The frozen Loop5 `test(String): long` method has one physical named exception row: ordinal 0, `[0,123)`, handler BCI 124, catch type constant-pool index 54. The natural loop header is 14, members `{14,23,39,88}`, latch 88, and normal-flow exits are `14→106` and `39→46`; its immediate postdominator is 106. The canonical block at 106 spans `[106,124)`, so it contains both the protected expression and the out-of-range return opcode. The decoded operations in that same block are `StringBuffer.toString` at 108, `Double.valueOf` at 111, `doubleValue` at 114, multiply at 118, `Math.ceil` at 119, conversion at 122, and `Return` at 123. The row ends exactly at the return instruction's BCI, exclusive. The handler begins at 124 and returns `-1` from its own block.

The actual debug and no-debug probe reports agree on these control-flow and boundary facts. The recovered tree has a `Try` whose body owns only block 0 and whose named catch owns block 124; an `UncoveredBlocks` fallback owns the other 11 blocks: 14, 23, 106, 39, 88, 46, 53, 60, 67, 74, 81. The input-specific debug and no-debug canonical class byte lengths differ (1899 and 1403), so the class-file bytes—not the statically inferred expected values—remain the runtime oracle. This proposal does not claim the feature already works.

Sources inspected:

- Real probe output: `/private/tmp/jarde-loop45-ir-probe-run-root-v1-20261019/raw/1.stderr.raw` (292286 bytes; SHA-256 `cddd66ab28b5c4e16536bc5315bee53e32f7c43f47a91f115db16dfcc4888e74`).
- Current recovery implementation: `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/region.rs` (1327012 bytes; SHA-256 `f0087dcf55aa691a3a57e491265474d6645f836f301372fcfec003f63f444fb5`).
- Current region writer: `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/build.rs` (2086471 bytes; SHA-256 `4593b653469c515f04a958a4707ea82df2a59e72846dc2ef8875789cc2101a4b`).
- Loop5 baseline execution receipt: `/private/tmp/jarde-testbreakinloop5-baseline-root-v1-20261019/execution.json` (6173904 bytes; SHA-256 `17770c94b51981a432430e285b0658a0da86c6948143a67388f5a77a08bb946a`).

Relevant source anchors (line numbers are for the pinned `region.rs` and `build.rs` above):

- `region.rs:792-818`: existing `Region::Try` can contain any body region and records `normal_exit_bci` specifically as a certified terminal goto. No new `Region` variant is needed for a sequence body; a return must not be smuggled into `normal_exit_bci`.
- `region.rs:1239-1259`: `sequence_region` and the current `protected_prefix_loop_shape`, which insists on exactly `Straight(prefix), Loop` (allowing a one-loop sequence wrapper).
- `region.rs:5479-5501, 5782-5802`: `region_at` depth/re-entry guard and the branch that ends a non-empty prefix immediately before an ordinary loop header.
- `region.rs:10261-10539`: named-row prefix+loop candidate and its checkpoint/rollback. It requires a nonempty straight prefix, a single loop, exact newly-visited loop ownership, named-row edge scope, then a loop-next bridge exactly at `protected_end`.
- `region.rs:10034-10109`: `candidate_blocks_have_named_catch_scope` verifies visited unique blocks, permitted named row ordinals and exception accounting, and rejects call edges. It does not by itself prove instruction-by-instruction BCI containment in the physical row.
- `region.rs:10667-10808`: `certified_try_exit` is a narrow bridge certificate: one instruction at `protected_end`, `Operation::Transfer`, one successor equal to a proved join, bridge outside rows/handlers, and every owned instruction before protected end (except lead). Keep this goto proof unchanged.
- `region.rs:1894-2087`: `ordinary_try_list_scope` is a separate, stricter complete-coverage census. It insists body-owner block spans exactly match the exception-row interval and rejects a body block extending beyond `row.end_bci` (`2060-2078`). Do not silently weaken this reporting proof to make recovery accept the mixed-boundary block.
- `build.rs:23584-23655`: existing writer emits Try lead before the statement, recursively walks its body into a Java `try`, then emits catch clauses. A `Sequence` body naturally writes prefix, loop, and returned expression in order.
- `region.rs:4558-4619, 4929-4953`: `Frame` already carries bounds, loop targets, and named rows; `protected()` creates the bounded protected frame. Avoid a new global CFG representation or generic frame mode unless the proof cannot be expressed locally.

The probe was run with `Sites::empty`; the available public result has the same uncovered-block boundary. The proposal therefore preserves this tested boundary: it does not claim typed Sites facts, field-sensitive facts, or success in contexts not covered by these inputs.

## Why the current certificate cannot accept this shape

The present speculative path is deliberately a *prefix + one loop + terminal goto bridge* proof. It needs the loop walker to produce exactly one `Region::Loop`; its following block must be `shape.protected_end` (`region.rs:10409-10471`). The later `certified_try_exit` accepts only a one-effect-free-transfer bridge block and bounds every candidate body instruction to the protected interval (`10667-10779`).

Loop5's loop exits to BCI 106; the physical row end is 123, not 106. The post-loop work is a returned expression in block 106, not a bridge block: BCI 106–122 are ordinary loads/invocations/arithmetic/conversion, and the terminal `lreturn` is at 123. The join is a method return, so there is no ordinary post-loop join block to use as the bridge. Thus even if the loop body can be recovered, `loop_next == protected_end` and the current bridge shape are incompatible with this method. Separately, the loop has a non-natural-set exit `39→46`; the current recovered tree leaves that exit's body uncovered. Loop5 tail integration must consume a fully recovered loop rather than reimplement the distinct acyclic break-body proof being designed for Loop4.

There is also an instruction/block boundary issue. The row excludes opcode BCI 123, but the canonical block `[106,124)` contains it. A block-overlap-only test would either reject the whole expression or falsely claim that the return opcode is protected. Recovery must keep physical row ownership instruction-precise while the existing region tree owns whole canonical blocks.

## Smallest local integration proposal

Add a sibling, separately named proof at the existing named-catch composition site; do not widen `certified_try_exit`. It may run only after the existing conditions already select an ordinary named-catch candidate (no retry, no finally/monitor/fragmented state) and after the child loop is a single complete `Region::Loop`. It should build the existing `Region::Sequence` form:

`Straight(prefix blocks) ; Loop ; Straight(tail block(s))`

as `Region::Try.body`. `Region::Try.normal_exit_bci` remains `None`: the body has a real return, not a goto represented by lexical continuation. No schema change is proposed.

The new proof should be an instruction-range *return-tail* certificate with these gates:

1. Use the already-proved `Catches` shape and exact named row set. Verify one unique matching physical/canonical row by ordinal, start, exclusive end, handler BCI, and catch-type index; ensure the handler remains outside the body and every takeable exceptional edge from candidate-owned instructions is accounted by that exact row. Existing named-row edge accounting remains necessary but is not sufficient for BCI range proof.
2. Require the prefix to have already been proven inside the row and before the loop header. Require the completed child `Loop`'s normal exit to be the unique entry to the tail at BCI 106, with no other normal-flow entry into the tail and no body region reaching past its terminal. The loop's early `39→46` branch belongs to the loop certificate, not to the post-loop tail proof.
3. Recover the tail from the natural-loop exit under the same protected `Frame`. Require one straight block (or a narrowly bounded straight sequence if later evidence demands it) whose potentially throwing/effectful expression instructions have starts in `[row.start_bci,row.end_bci)`, and whose only out-of-row instruction is exactly one terminal `Operation::Return` at `row.end_bci`. Require no bytecode between the row end and that terminal return, no second return/transfer, and no normal successor. For this frozen input the concrete proof is block `[106,124)`: expression BCIs 106–122 are protected and `Return` BCI 123 is the sole exclusive-boundary terminal.
4. Check the row at instruction granularity. For every body-owned block, enumerate its SSA instructions and require each instruction to be either in the exact protected interval or the specifically proved terminal return at the exclusive end. Also reject a candidate if a call edge, unknown/unaccounted exception edge, foreign row, catch handler, nested handler, or out-of-row nonterminal instruction is found. Keep the handler block separately owned by its `CatchClause`.
5. Require the canonical owner set to be closed and disjoint: union(prefix, loop region, tail) has no duplicate block; all newly visited blocks from the checkpoint are exactly those region owners; handler blocks are excluded from this union and recovered by the normal catch pass; no unexplained newly visited blocks or external predecessor into the tail are allowed. The whole Try must preserve current fallback for any uncovered/overlapped owners.

The existing `Region::Try` writer can then emit Java's logical `try { prefix; loop; return expression; } catch (...) { ... }`. The return opcode is not physically protected, but it cannot throw; the expression evaluations that can throw remain protected. This is the narrow semantic equivalence needed for Java source reconstruction. Keep the distinction explicit in a helper comment and in any diagnostic/certificate data: “row-protected expression; unprotected terminal return opcode.” Do not mark the terminal as belonging to the row.

The new candidate should reuse current named-catch candidate checkpoint mechanics (`region.rs:10299-10362`) and follow the current result discipline (`10525-10538`): on `Ok(None)` restore all checkpointed walker state and continue the ordinary path; on `Err(StopReason)` restore it and propagate the stop. Preserve the existing policy that budget use is not refunded. Keep row membership immutable and candidate-local. If the proof adds any mutable walker facts, include them in both checkpoint and restore; preferably keep it pure and return the accepted region/certificate instead. Do not commit partial ownership while deciding.

The existing ordinary try/list census should remain conservative. Its exact block-span rule at `2060-2078` cannot describe this row/block boundary; broadening it would turn an instruction-level recovery allowance into a general-purpose span exception. If a later consumer specifically needs the tail in the census, give that consumer its own proof and tests.

## Acceptance and adversarial tests

Use current frozen class inputs and current helper path; do not synthesize bytecode or infer success from the probe. The intended positive matrix is Loop5 debug and no-debug, while running the same path against both Loop4 frozen classes guards the shared prefix-loop/bridge code. For a successful Loop5 result require:

- exactly one ordinary `Try`, one named catch, and body `Sequence(Straight prefix, Loop, Straight returned tail)`; handler ownership remains outside the body;
- the loop body separately proves/owns its `39→46` exit or refuses the entire new composition cleanly;
- tail expression instruction BCIs through 122 are row-protected; BCI 123 is the only explicitly permitted out-of-row instruction and has `Operation::Return`;
- all recovered normal-flow blocks are owned exactly once, no fallback overlaps the candidate, and check/public helper agree on the same structure;
- the generated Java preserves the original expression order (`toString`, `Double.valueOf`, `doubleValue`, multiply, `ceil`, conversion), catch return, and no extra evaluation or dropped `StringBuffer` operations.

Negative/cancellation cases should refuse to the existing fallback without partial ownership when any one of these changes: wrong row ordinal/type/handler/start/end; a second matching/overlapping row or an unconsumed foreign row; expression instruction at or after the row end; return not exactly at the exclusive end or not the sole terminal; a normal successor after return; multiple or external predecessors to tail; a second post-loop exit destination; a catch handler included in body; an exception edge not accounted by the one named row; duplicate/foreign/unvisited block owner; incomplete or overlapping region owner inventory. Include a budget/cancellation refusal between prefix, loop, and tail proof steps and assert checkpoint state is restored while stop reason propagates. Do not require byte-identical debug/no-debug trees where debug metadata legitimately differs; require the structural certificate and BCI facts to match.

Keep Loop4's acyclic break-body proof independently scoped. Loop5's positive test should not pass by treating the outside-natural-loop `46..81` branch as tail code; that path is an early exit inside the loop and must be handled by the loop-region proof.

## Open implementation decision

The design assumes a `Straight` region over canonical block 106 can be emitted within `Try` while its instruction proof distinguishes the exclusive-end return. This matches existing block ownership plus writer behavior; before implementation, inspect the current `block`/`range` bookkeeping around the row and `Region::Try` source-span accounting to verify that no downstream invariant incorrectly treats all instructions in a claimed block as exception-row protected. If an existing writer or validation layer requires row ownership to align to block ends, add the smallest local Try-tail terminal exception to that validator, not a general partial-block ownership model. Do not use `normal_exit_bci` for this return.
