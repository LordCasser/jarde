# Loop5 protected-loop design prep

Read-only architecture proposal for the next implementation review: [design.md](design.md).

This directory is private scratch. It contains no implementation or generated class files. The proposal is based on the frozen Loop5 probe and source anchors documented in `design.md`; no JDK, Cargo, JADX, or Jarde process was run.
