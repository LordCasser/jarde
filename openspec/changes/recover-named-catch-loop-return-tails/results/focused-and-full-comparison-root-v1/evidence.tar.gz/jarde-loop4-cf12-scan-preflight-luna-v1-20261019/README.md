# Loop4 minimal preflight patch for the CF12 budget regression

This private candidate moves exactly the existing `natural_exits.len() != 2 || !natural_exits.contains(&exit)` refusal ahead of the expensive `candidate_scan_bound` charge in `loop_break_branch_body`.

The initial cancellation poll remains before the shape gate. For candidates that satisfy the existing two-exit/member predicate, the scan-bound calculation, second poll, full `AnalysisSteps` charge and all later proof work are byte-for-byte unchanged. No proof condition is relaxed and no budget limit/test is adjusted. A loop with any other exit shape still refuses; it now refuses before paying for work that the function cannot perform on that shape.

The frozen Loop4 and Loop5 candidates each have two natural exits and the selected break target belongs to that set (Loop4's header/body side exit and loop exit; Loop5's two established exits 14→106 and 39→46). They therefore pass the same gate and retain the same scan budget and proof path. This only avoids the charge for impossible shapes, including the reported single-natural-exit TestSwitch loop. The TestSwitch outcome remains refusal; this is not a new recovery rule.

No test was run or added. Root requested a guarded single-target rerun. This bundle contains only the exact source base, candidate, unified patch, and pins; it was generated with Python `-B` and does not modify shared files.

## Pins

- `region.rs.base`: 1385610 bytes, SHA-256 `fad0d541819cc5caf4f0023a322034e40ac48d632f147a1fec8a78eb2ccf44da`
- `region.rs.candidate`: 1385610 bytes, SHA-256 `86a20041442a196dfaa83da539d3f301b9b4974907620b3b50da1eb46f037be5`
- `region.patch`: 832 bytes, SHA-256 `40dc7e7fa54ba71418c88aee77ff8e40e11183246cf387e7261d58e1e9d718ba`
- Shared source read from `/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/region.rs`; its base bytes match `region.rs.base`.
