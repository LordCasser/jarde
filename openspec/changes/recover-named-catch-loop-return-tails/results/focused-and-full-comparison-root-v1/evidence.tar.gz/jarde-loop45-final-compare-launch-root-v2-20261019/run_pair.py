import datetime,hashlib,json,os,subprocess,time,sys
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
LAUNCH=Path('/private/tmp/jarde-loop45-final-compare-launch-root-v2-20261019')
CLI=Path(sys.argv[1]).resolve()
CLI_SHA=sys.argv[2]
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
record={'status':'preflight','started_utc':now(),'product':'pending_commit_bound_by_final_source_pins','cli_sha256':CLI_SHA,'preflights':[],'collectors':[],'scope':'two root-owned isolated Java/JADX/Jarde final comparisons run concurrently; no Cargo or shared source writes'}
def save(): (LAUNCH/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':oct(p.stat().st_mode&511)}
try:
 assert pin(CLI)['sha256']==CLI_SHA and not (ROOT/'target').exists()
 record['head']=subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,check=True,capture_output=True,text=True).stdout.strip()
 record['working_tree_status_before']=subprocess.run(['git','status','--porcelain=v1'],cwd=ROOT,check=True,capture_output=True,text=True).stdout
 record['cli']=pin(CLI)
 for num in (4,5):
  base=Path(f'/private/tmp/jarde-testbreakinloop{num}-baseline-prep-luna-v2-20261019')
  assert base.is_dir()
  argv=['python3','-B',str(base/'static_preflight.py')]
  with (LAUNCH/f'loop{num}-preflight.stdout.raw').open('xb') as so,(LAUNCH/f'loop{num}-preflight.stderr.raw').open('xb') as se:r=subprocess.run(argv,cwd=ROOT,stdout=so,stderr=se)
  record['preflights'].append({'case':num,'argv':argv,'exit_code':r.returncode});save();r.check_returncode()
 processes=[]
 for num in (4,5):
  base=Path(f'/private/tmp/jarde-testbreakinloop{num}-baseline-prep-luna-v2-20261019');out=Path(f'/private/tmp/jarde-testbreakinloop{num}-final-compare-root-v2-20261019');assert not out.exists()
  argv=['python3','-B',str(base/'collect_baseline.py'),'--out',str(out),'--cli',str(CLI),'--cli-sha256',CLI_SHA]
  so=(LAUNCH/f'loop{num}-collector.stdout.raw').open('xb');se=(LAUNCH/f'loop{num}-collector.stderr.raw').open('xb')
  row={'case':num,'argv':argv,'started_utc':now(),'collector_pin':pin(base/'collect_baseline.py'),'driver_pin':pin(base/f'driver/TestBreakInLoop{num}Driver.java'),'output':str(out)}
  child=subprocess.Popen(argv,cwd=ROOT,stdout=so,stderr=se);row['pid']=child.pid;record['collectors'].append(row);processes.append((child,row,so,se))
 record['status']='parallel_collectors_running';save();print('both collectors launched concurrently',flush=True)
 while processes:
  for item in list(processes):
   child,row,so,se=item;code=child.poll()
   if code is None:continue
   so.close();se.close();row['exit_code']=code;row['finished_utc']=now();processes.remove(item);save();print('collector closed '+str(row['case'])+' exit '+str(code),flush=True)
  if processes:time.sleep(0.5)
 assert all(x['exit_code']==0 for x in record['collectors'])
 record['status']='both_collectors_closed_pending_review';record['finished_utc']=now();assert not (ROOT/'target').exists();record['target_absent']=True;assert pin(CLI)==record['cli'];save();print(json.dumps({'status':record['status'],'cases':[x['case'] for x in record['collectors']]}),flush=True)
except BaseException as e:
 record['status']='failed_no_baseline_accepted';record['error']=repr(e);save();raise
