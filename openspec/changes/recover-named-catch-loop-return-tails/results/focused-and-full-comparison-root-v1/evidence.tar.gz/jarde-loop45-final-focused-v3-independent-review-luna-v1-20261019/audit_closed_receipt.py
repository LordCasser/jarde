#!/usr/bin/env python3
"""Independent Python-only audit of a closed Loop45 focused v3 receipt."""
from __future__ import annotations
import collections
import hashlib
import json
import re
from pathlib import Path

RECEIPT = Path('/private/tmp/jarde-loop45-final-focused-root-v3-20261019/execution.json')
OUT = Path('/private/tmp/jarde-loop45-final-focused-v3-independent-review-luna-v1-20261019')
EXPECTED_L4 = {
    'region::loop_break_body_tests::reader_recovers_complete_loop4_body_for_both_debug_profiles',
    'region::loop_break_body_tests::reader_proof_owns_only_the_closed_route_and_refuses_occupied_or_scoped_candidates',
    'region::loop_break_body_tests::reader_late_implicit_latch_stop_restores_trial_state_without_refunding_usage',
    'region::loop_break_body_tests::edge_gate_rejects_external_entries_extra_exits_exceptions_and_cycles',
    'region::loop_break_body_tests::comparison_gate_refuses_switch_and_budget_or_cancellation_stays_a_stop',
}
EXPECTED_L5 = {
    'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_return_tail_certificate_accepts_the_frozen_boundary_return',
    'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_return_tail_certificate_refuses_drift_duplicate_owners_and_stops_cleanly',
    'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_try_level_candidate_refusal_restores_tentative_owners',
    'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_try_level_late_analysis_stop_restores_candidate_checkpoint',
    'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_full_try_owns_prefix_loop_and_return_tail_after_loop4_proof',
    'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_named_break_body_proof_binds_one_row_and_rejects_scope_drift',
}
EXPECTED_BUILDER = {
    'build::tests::loop5_catch_binding_tests::loop5_handler_entry_phi_does_not_conflict_with_reused_double_slot',
    'build::tests::loop5_catch_binding_tests::loop5_catch_binding_requires_exact_path_handler_slot_and_stack_zero_phi',
    'build::tests::loop5_catch_binding_tests::loop5_catch_binding_propagates_budget_and_cancellation_stops',
}
EXPECTED_PUBLIC = {
    'original_loop4_debug_and_no_debug_class_and_full_jar_keep_structured_conditional_break_body',
    'original_loop4_public_class_source_propagates_precancellation_without_partial_text',
    'original_loop5_debug_and_no_debug_class_and_full_jar_keep_named_catch_return_tail',
    'original_loop5_public_class_source_propagates_precancellation_without_partial_text',
}
EXPECTED_READER = {'classfile::tests::repository_class_fixtures_validate_without_false_target_rejections'}

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def require(ok: bool, message: str) -> None:
    if not ok:
        raise AssertionError(message)

def parse_outcomes(text: str):
    rows=[]
    for line in text.splitlines():
        match=re.fullmatch(r'test (.+) \.\.\. (ok|FAILED|ignored)(?:,.*)?',line)
        if match:
            rows.append({'name':match.group(1),'status':match.group(2),'line':line})
    return rows

def summary(text: str):
    matches=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text,re.M)
    require(len(matches)==1, f'expected one Cargo summary, found {len(matches)}')
    state,*nums=matches[0]
    return {'state':state,'passed':int(nums[0]),'failed':int(nums[1]),'ignored':int(nums[2]),'measured':int(nums[3]),'filtered_out':int(nums[4])}

def main():
    receipt_bytes=RECEIPT.read_bytes(); receipt=json.loads(receipt_bytes)
    root=RECEIPT.parent; rawroot=root/'raw'
    require(receipt['status']=='failed','receipt status changed; this audit expects closed failed v3')
    require(len(receipt['commands'])==6,'expected six recorded commands')
    stream_pins=[]; actual_by_path={}
    for command in receipt['commands']:
        streams=command.get('streams',{})
        require(set(streams)=={'stdout','stderr'},f"command {command['index']} does not have both raw streams")
        for stream,pin in streams.items():
            path=Path(pin['path'])
            require(path.parent==rawroot and not path.is_symlink(),f'raw path escaped or is symlink: {path}')
            data=path.read_bytes()
            actual={'path':str(path),'bytes':len(data),'sha256':digest(data)}
            require(actual['bytes']==pin['bytes'],f'raw size mismatch: {path}')
            require(actual['sha256']==pin['sha256'],f'raw SHA mismatch: {path}')
            require(str(path) not in actual_by_path,'duplicate stream path in receipt')
            actual_by_path[str(path)]=actual
            stream_pins.append({'command':command['index'],'stream':stream,**actual})
    require(len(stream_pins)==12,'expected all twelve raw stream pins')

    functional=[]
    all_outcomes={}
    for index in (1,2,3,4):
        command=receipt['commands'][index-1]
        raw=Path(command['streams']['stdout']['path']).read_bytes().decode('utf-8')
        outcomes=parse_outcomes(raw); observed=collections.Counter(x['status'] for x in outcomes)
        reported=summary(raw)
        require(reported['passed']==observed['ok'] and reported['failed']==observed['FAILED'] and reported['ignored']==observed['ignored'],f'command {index} named outcomes disagree with Cargo summary')
        require(command['exit_code']==0 and reported['state']=='ok',f'functional command {index} not successful')
        all_outcomes[index]=outcomes
        functional.append({'command':index,'argv':command['argv'],'exit_code':command['exit_code'],'summary':reported,'named_outcome_count':len(outcomes),'named_status_counts':dict(observed)})

    unit=all_outcomes[1]
    unit_ok={x['name'] for x in unit if x['status']=='ok'}
    unit_names={x['name'] for x in unit}
    l4={n for n in unit_names if n.startswith('region::loop_break_body_tests::')}
    l5={n for n in unit_names if n.startswith('region::finite_loop_catch_tests::loop5_return_tail_tests::')}
    builder={n for n in unit_names if n.startswith('build::tests::loop5_catch_binding_tests::')}
    require(l4==EXPECTED_L4,f'Loop4 exact gate set differs: missing={sorted(EXPECTED_L4-l4)} extra={sorted(l4-EXPECTED_L4)}')
    require(l5==EXPECTED_L5,f'Loop5 exact gate set differs: missing={sorted(EXPECTED_L5-l5)} extra={sorted(l5-EXPECTED_L5)}')
    require(builder==EXPECTED_BUILDER,f'builder exact gate set differs: missing={sorted(EXPECTED_BUILDER-builder)} extra={sorted(builder-EXPECTED_BUILDER)}')
    unit_gates=sorted(l4|l5|builder)
    require(len(unit_gates)==14 and set(unit_gates)<=unit_ok,'one or more of the fourteen new unit gates did not pass')

    public={x['name']:x['status'] for x in all_outcomes[2]}
    require(set(public)==EXPECTED_PUBLIC and set(public.values())=={'ok'},'public gate identities/status differ from expected four passes')
    reader={x['name']:x['status'] for x in all_outcomes[3]}
    require(set(reader)==EXPECTED_READER and set(reader.values())=={'ok'},'Reader gate identity/status differs from expected pass')
    fingerprint=all_outcomes[4]
    fp_counts=collections.Counter(x['status'] for x in fingerprint)
    require(len(fingerprint)==6 and fp_counts=={'ok':5,'ignored':1},'fingerprint outcomes differ from 5 passed/1 ignored')
    ignored=[x['name'] for x in fingerprint if x['status']=='ignored']
    require(ignored==['regenerate_corpus_fingerprint'],'fingerprint ignored gate identity changed')
    panic_suffix=[x for x in unit if ' - should panic' in x['name']]
    require(len(panic_suffix)==1 and panic_suffix[0]['status']=='ok','expected the one successful should-panic test suffix')

    clippy=receipt['commands'][4]
    clippy_stderr=Path(clippy['streams']['stderr']['path']).read_text(encoding='utf-8',errors='replace')
    errors=[line for line in clippy_stderr.splitlines() if line.startswith('error:') and not line.startswith('error: could not compile')]
    lint_ids=re.findall(r'index\.html#([a-z0-9_]+)',clippy_stderr)
    require(clippy['exit_code']==101 and len(errors)==4,'expected exactly four blocking Clippy diagnostics')
    require(collections.Counter(lint_ids)==collections.Counter({'bool_assert_comparison':2,'unnecessary_filter_map':1,'manual_contains':1}),f'unexpected Clippy lint IDs: {lint_ids}')
    cleanup=receipt['commands'][5]
    require(cleanup['argv']==['cargo','clean'] and cleanup['exit_code']==0,'cleanup command did not complete successfully')

    source_before=receipt['source_before']; source_after=receipt['source_after']
    require(source_before==source_after and receipt['source_unchanged'] is True,'source inventory was not unchanged within v3 run')
    backup=[x for x in source_before if x['path'].endswith('/crates/jarde-java/src/region.rs.orig')]
    require(len(backup)==1,'expected old root region.rs.orig backup in source inventory')
    require(receipt['source_changes']==[] and receipt['allowed_source_changes']==[] and receipt['source_changes_accepted'] is True,'unexpected source changes in old run')
    require(receipt['target_absent'] is True,'target cleanup guard not satisfied')

    report={
      'schema':'jarde.loop45.final-focused-v3-independent-review.v1',
      'status':'old_focused_v3_raws_verified_but_not_final_acceptance',
      'receipt':{'path':str(RECEIPT),'bytes':len(receipt_bytes),'sha256':digest(receipt_bytes),'recorded_status':receipt['status'],'finished_utc':receipt['finished_utc']},
      'raw_streams_reopened':stream_pins,
      'raw_stream_count':len(stream_pins),
      'functional_commands':functional,
      'actual_gate_sets':{'unit_loop4':sorted(l4),'unit_loop5':sorted(l5),'unit_builder':sorted(builder),'public':sorted(public),'reader':sorted(reader)},
      'actual_gate_counts':{'unit_new_gates_passed':len(unit_gates),'loop4':len(l4),'loop5':len(l5),'builder':len(builder),'public':len(public),'reader':len(reader)},
      'fingerprint':{'passed':fp_counts['ok'],'ignored':fp_counts['ignored'],'ignored_test_names':ignored},
      'should_panic_suffix':panic_suffix[0]['name'],
      'clippy':{'exit_code':clippy['exit_code'],'blocking_diagnostics':errors,'lint_ids':lint_ids},
      'cleanup':{'argv':cleanup['argv'],'exit_code':cleanup['exit_code'],'target_absent':receipt['target_absent']},
      'old_source_binding':{'source_count':len(source_before),'source_unchanged_within_run':True,'region_rs_orig':backup[0],'source_changes':receipt['source_changes']},
      'scope_limit':'This functional receipt is bound to the old v3 source inventory including region.rs.orig. That backup was privately retained and then removed after closure. The subsequent source edits are described by the task owner as equivalent assert/filter/contains Clippy fixes; the still-running final static/CLI build has not been read or audited here. Therefore this receipt is not evidence for final-source acceptance.',
      'unclosed_build_path_read':False,
      'acceptance_complete':False,
    }
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':report['status'],'raw_stream_count':len(stream_pins),'unit_gate_passes':len(unit_gates),'public_passes':len(public),'reader_passes':len(reader),'fingerprint_pass_ignore':[fp_counts['ok'],fp_counts['ignored']],'clippy_blockers':len(errors),'acceptance_complete':False},ensure_ascii=False))

if __name__=='__main__':
    main()
