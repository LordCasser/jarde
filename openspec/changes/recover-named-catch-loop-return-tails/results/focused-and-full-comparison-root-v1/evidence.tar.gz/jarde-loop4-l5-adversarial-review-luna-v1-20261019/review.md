# Adversarial review: Loop5 named return-tail proof

Read-only source snapshot: `crates/jarde-java/src/region.rs`, SHA-256 `733205b26e38182f680e579726e0858deef076ace194545cbb3450b9b665bbc5`. No toolchain or test execution was performed; active Cargo output was not inspected.

## Finding: return-tail proof does not reject incoming legacy call/return edges

At `region.rs:11318-11335`, the normal-edge owner-closure check rejects foreign incoming **Normal** edges and owner outgoing normal edges. The following call/return check at `11328-11334` rejects `CanonicalEdgeKind::Call` and `Return` only when `from` is an owner. A `Call` or `Return` edge whose `to` is an owner is ignored. The preceding tail-predecessor check (`11307-11316`) uses `NormalFlowView`, so it does not close this gap for the canonical legacy-subroutine edge kinds.

A concrete adversarial graph is a protected prefix/loop/return-tail owner set with a canonical `Return { call_site }` edge from a cloned `ret` block outside that set into an owned continuation block. This is representable in the canonical model: `Return` edges connect a cloned legacy `ret` to the continuation after its `jsr`; the continuation may lie inside the exception range even when the call site lies outside it. The current proof's normal-edge scan does not see that foreign entry and its call/return test checks only `from`, so it could certify owners with an additional non-normal ingress. A `Call` edge targeting an owner is the same class of miss.

Minimal correction: while scanning canonical edges, refuse a `Call` or `Return` edge when either endpoint belongs to `unique_owners` (equivalently, test `(from || to)`). This matches the stricter named-loop scope check at `22301-22308`, which rejects call/return edges touching any physical protected block. Add one focused certificate refusal mutation for a foreign `Return` edge targeting an owner (and ideally a `Call` edge) so this ingress boundary stays explicit.

## Checks that passed by inspection

- The physical exception range and canonical exception-source inventory remain distinct. `certified_try_return_tail` derives physical membership from SSA instruction BCIs (`11216-11232`) and separately requires exact exception-edge sources to equal `canonical_row.protected()` (`11255-11295`). `named_loop_scope_edges` does the same at `22278-22296` and `22298-22350`.
- The terminal return is separately constrained to one decoded return opcode at the exclusive handler end, with the block ending immediately after it and a value producer defined inside the protected range (`11130-11158`). The candidate must be the sole named catch row/type/handler and have no lexical join (`11041-11090`).
- Named-loop candidates reject handler drift and wrong handler inventory (`22120-22158`), reject call/return edges touching the scoped physical range (`22301-22316`), check every protected exceptional source (`22318-22350`), and exclude foreign normal ingress for the side-route owners through `loop_break_body_edges_closed` (`22680-22697`, `22799-22843`, and helper `4653-4714`).
- The return-tail candidate validates exact owner ordering/uniqueness and the saved-visited prefix relation (`11061-11090`, `11174-11213`); its newly visited delta must equal owners minus the saved prefix.
- The try-level speculative candidate checkpoints and restores visited, unclosed-tail, catch joins, loop-catch owners, fragmented proof, monitor state, and depth; budget use is intentionally not refunded (`10561-10624`, `10857-10869`).

## Remaining acceptance boundary

Existing tests cover both frozen debug profiles, exact row and owner drift, duplicate/missing owners, cancellation/budget refusal, try-level rollback, named physical/canonical scope drift, and real Reader recovery (`loop5_return_tail_tests.rs:519-583, 589-823, 826-972, 976-1025`). They do not appear to cover a canonical Call/Return edge *targeting* a return-tail owner. Root's active Cargo run may establish regression status for existing cases but cannot close this uncovered proof boundary by itself.
