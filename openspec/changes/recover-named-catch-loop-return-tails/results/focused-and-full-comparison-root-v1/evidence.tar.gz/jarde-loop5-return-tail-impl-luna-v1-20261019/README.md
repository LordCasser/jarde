# Loop5 named-catch return-tail candidate (private, unexecuted)

This directory contains a review candidate for the Loop5 return-tail portion of `recover-named-catch-loop-return-tails`. It is bound to the `region.rs` base bytes in `pins.json`. The shared checkout has not been changed. No Cargo, Rust compiler, JDK, JADX, Jarde CLI, network, Git, or formatter was run.

## Scope

`region.patch` changes only the named-catch composition inside `try_level` and adds an independent `certified_try_return_tail` certificate. It preserves the existing `certified_try_exit` goto bridge path and does not alter `header_tested_loop`, the Loop4 break-body proof, global CFG handling, the Try writer, or the conservative ordinary Try-list census.

For the return-tail candidate, the protected body is assembled as existing prefix + one already-recovered loop + one straight singleton tail. The new certificate checks the singleton named physical/canonical exception row, exact handler/type/range, non-monitor/non-finally shape, owner uniqueness and newly-visited delta, existing named-catch-scope predicate, exact canonical protected-block set, decoded/SSA instruction agreement, expression producer inside the row, the sole Return at the row's exclusive end, and closed normal-edge ownership. A Return boundary is deliberately not treated as the old goto bridge.

`finite_loop_catch_tests.patch` includes the nested test module. `loop5_return_tail_tests.rs` has isolated certificate acceptance/refusal tests for both frozen debug modes and an ignored whole-recovery acceptance test. That ignored test explicitly awaits the independent Loop4 named-row break-body proof and is not a claimed pass. Fixture paths resolve to the fixture root that the parent task is preparing; the fixture bytes are pinned in `pins.json`.

The static expected results (2, 12, 13312, 1048576, -1) are not used to replace execution of the original five case observations. Those baseline/oracle runs belong to the parent task. The candidate tests do not infer framework-check success.

## Review/apply inputs

- `candidate.patch` concatenates the three file diffs; each component patch is also available separately.
- `region.rs.base` and `region.rs.candidate` permit exact local review against the pinned source.
- The one-line module insertion expects `loop5_return_tail_tests.rs` beside `finite_loop_catch_tests.rs`.
- Fixture files expected by `include_bytes!`:
  `tests/fixtures/recover-named-catch-loop-return-tails/original/{debug,no-debug}/classes/jadx/tests/integration/loops/TestBreakInLoop5$TestCls.class`.

## Root-side validation plan (not run here)

After the pending Loop4 proof is integrated and the frozen fixtures are installed, run the two isolated certificate tests:

```text
cargo test -p jarde-java --lib region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_return_tail_certificate_accepts_the_frozen_boundary_return -- --exact --nocapture
cargo test -p jarde-java --lib region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_return_tail_certificate_refuses_drift_duplicate_owners_and_stops_cleanly -- --exact --nocapture
```

Then explicitly run the ignored full-recovery test only after the Loop4 proof is integrated:

```text
cargo test -p jarde-java --lib region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_full_try_owns_prefix_loop_and_return_tail_after_loop4_proof -- --exact --ignored --nocapture
```

This is a test plan, not evidence that any test compiled or passed. Parent owns execution, resource limits, integration, and cleanup.

## Static close-out

The preparation performed only read-only source inspection and Python `-B` writes in this private directory. `pins.json` records relevant source, fixture, probe, OpenSpec, skill, base/candidate, and patch digests. The parent should re-check the shared base digest before applying the patch.
