use super::*;

const LOOP5_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-named-catch-loop-return-tails/original/debug/classes/jadx/tests/integration/loops/TestBreakInLoop5$TestCls.class",
);
const LOOP5_NO_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-named-catch-loop-return-tails/original/no-debug/classes/jadx/tests/integration/loops/TestBreakInLoop5$TestCls.class",
);

fn loop5_frozen_parts(
    canonical: &CanonicalCfg,
    view: &NormalFlowView,
    ssa: &SsaTable,
    operations: &Operations,
    code: &MethodCodeFacts,
    budget: &mut Budget,
) -> (
    CanonicalBlockId,
    crate::guard::Catches,
    Vec<CanonicalBlockId>,
    Vec<CanonicalBlockId>,
    CanonicalBlockId,
    Vec<CanonicalBlockId>,
    BTreeSet<usize>,
) {
    let start = canonical
        .blocks()
        .iter()
        .find(|block| block.id().bci() == 0)
        .expect("Loop5 try entry exists")
        .id()
        .clone();
    let shape = crate::guard::catches(
        canonical,
        view,
        ssa,
        operations,
        &code.exception_handlers,
        None,
        None,
        &crate::pass::JAVA_8,
        &start,
        budget,
    )
    .expect("Loop5 named catch facts complete")
    .expect("Loop5 has a named catch");
    let handler = shape.sites[0].handler.clone();
    let tail = canonical
        .blocks()
        .iter()
        .find(|block| block.id().bci() == 106)
        .expect("Loop5 returned expression block exists")
        .id()
        .clone();
    let prefix: Vec<_> = canonical
        .blocks()
        .iter()
        .filter(|block| block.id().bci() == 0)
        .map(|block| block.id().clone())
        .collect();
    let loop_blocks: Vec<_> = canonical
        .blocks()
        .iter()
        .filter(|block| {
            block.id().bci() != 0 && block.id() != &tail && block.id() != &handler
        })
        .map(|block| block.id().clone())
        .collect();
    let mut owners = prefix.clone();
    owners.extend(loop_blocks.iter().cloned());
    owners.push(tail.clone());
    let visited = owners
        .iter()
        .map(|block| view.index_of(block).expect("candidate owner is in normal flow"))
        .collect();
    (start, shape, prefix, loop_blocks, tail, owners, visited)
}

fn run_loop5_return_tail_certificate(
    canonical: &CanonicalCfg,
    view: &NormalFlowView,
    ssa: &SsaTable,
    operations: &Operations,
    code: &MethodCodeFacts,
    start: &CanonicalBlockId,
    shape: &crate::guard::Catches,
    prefix: &[CanonicalBlockId],
    loop_blocks: &[CanonicalBlockId],
    tail: &CanonicalBlockId,
    owners: &[CanonicalBlockId],
    visited: &BTreeSet<usize>,
    budget: &mut Budget,
) -> Result<bool, StopReason> {
    let chains = crate::concat::Plan::empty();
    let sites = crate::init::Sites::empty();
    let start_node = view.index_of(start).expect("try entry is mapped");
    let mut walker = Walker {
        canonical,
        view,
        ssa,
        operations,
        pool: &[],
        chains: &chains,
        sites: &sites,
        code,
        method_synchronized: Some(false),
        has_reachable_explicit_monitor: false,
        return_is_boolean: false,
        handlers: &code.exception_handlers,
        profile: &crate::pass::JAVA_8,
        budget,
        catch_joins: BTreeSet::new(),
        loop_catch_terminal_owners: Vec::new(),
        fragmented: None,
        excluded_edge_nodes: BTreeSet::new(),
        visited: visited.clone(),
        unclosed_tail_at: Some(777),
        own_monitor: None,
        depth: 7,
    };
    let frame = Frame {
        own_try: Some(start_node),
        named_catch_rows: Some(std::sync::Arc::new(BTreeSet::from([0]))),
        ..Frame::default()
    };
    let before_visited = walker.visited.clone();
    let before_tail = walker.unclosed_tail_at;
    let before_joins = walker.catch_joins.clone();
    let before_loop_owners = format!("{:?}", walker.loop_catch_terminal_owners);
    let before_fragmented = format!("{:?}", walker.fragmented);
    let before_monitor = format!("{:?}", walker.own_monitor);
    let before_depth = walker.depth;
    let result = walker.certified_try_return_tail(
        tail,
        &canonical
            .blocks()
            .iter()
            .find(|block| block.id().bci() == 14)
            .expect("Loop5 loop header exists")
            .id()
            .clone(),
        shape,
        &frame,
        prefix,
        loop_blocks,
        owners,
        &BTreeSet::new(),
    );
    assert_eq!(walker.visited, before_visited);
    assert_eq!(walker.unclosed_tail_at, before_tail);
    assert_eq!(walker.catch_joins, before_joins);
    assert_eq!(format!("{:?}", walker.loop_catch_terminal_owners), before_loop_owners);
    assert_eq!(format!("{:?}", walker.fragmented), before_fragmented);
    assert_eq!(format!("{:?}", walker.own_monitor), before_monitor);
    assert_eq!(walker.depth, before_depth);
    result
}

#[test]
fn loop5_return_tail_certificate_accepts_the_frozen_boundary_return() {
    for class in [LOOP5_DEBUG, LOOP5_NO_DEBUG] {
        with_frozen_method_ir(
            class,
            b"test",
            b"(Ljava/lang/String;)J",
            |canonical, view, ssa, operations, code, _recovered| {
                let mut shape_budget = ample_budget();
                let (start, shape, prefix, loop_blocks, tail, owners, visited) =
                    loop5_frozen_parts(canonical, view, ssa, operations, code, &mut shape_budget);
                assert_eq!(code.exception_handler_count as usize, 1);
                assert_eq!(
                    (code.exception_handlers[0].ordinal,
                     code.exception_handlers[0].start_bci,
                     code.exception_handlers[0].end_bci,
                     code.exception_handlers[0].handler_bci,
                     code.exception_handlers[0].catch_type_index),
                    (0, 0, 123, 124, Some(54))
                );
                assert_eq!(shape.join, None);
                // This isolated proof can be checked before Loop4's independent break-body proof
                // is integrated. It does not claim whole-method recovery succeeded.
                let mut budget = ample_budget();
                assert_eq!(
                    run_loop5_return_tail_certificate(
                        canonical, view, ssa, operations, code, &start, &shape,
                        &prefix, &loop_blocks, &tail, &owners, &visited, &mut budget,
                    )
                    .expect("the isolated boundary proof completes"),
                    true
                );
            },
        );
    }
}

#[test]
fn loop5_return_tail_certificate_refuses_drift_duplicate_owners_and_stops_cleanly() {
    use jarde_reader::budget::{CancellationToken, Limits};

    with_frozen_method_ir(
        LOOP5_DEBUG,
        b"test",
        b"(Ljava/lang/String;)J",
        |canonical, view, ssa, operations, code, _| {
            let mut shape_budget = ample_budget();
            let (start, shape, prefix, loop_blocks, tail, owners, visited) =
                loop5_frozen_parts(canonical, view, ssa, operations, code, &mut shape_budget);
            let refuse = |changed_code: &MethodCodeFacts,
                          changed_shape: &crate::guard::Catches,
                          changed_owners: &[CanonicalBlockId],
                          changed_visited: &BTreeSet<usize>| {
                let mut budget = ample_budget();
                assert_eq!(
                    run_loop5_return_tail_certificate(
                        canonical, view, ssa, operations, changed_code,
                        &start, changed_shape, &prefix, &loop_blocks, &tail,
                        changed_owners, changed_visited, &mut budget,
                    )
                    .expect("mutated certificate evidence is a bounded refusal"),
                    false
                );
            };

            let mut wrong_start = code.clone();
            wrong_start.exception_handlers[0].start_bci = 1;
            refuse(&wrong_start, &shape, &owners, &visited);
            let mut wrong_end = code.clone();
            wrong_end.exception_handlers[0].end_bci = 122;
            refuse(&wrong_end, &shape, &owners, &visited);
            let mut wrong_type = code.clone();
            wrong_type.exception_handlers[0].catch_type_index = Some(55);
            refuse(&wrong_type, &shape, &owners, &visited);
            let mut wrong_handler = code.clone();
            wrong_handler.exception_handlers[0].handler_bci = 106;
            refuse(&wrong_handler, &shape, &owners, &visited);
            let mut extra_row = code.clone();
            let mut foreign = extra_row.exception_handlers[0].clone();
            foreign.ordinal = 1;
            extra_row.exception_handlers.push(foreign);
            extra_row.exception_handler_count = 2;
            refuse(&extra_row, &shape, &owners, &visited);

            let mut wrong_catch = shape.clone();
            wrong_catch.sites[0].types = crate::guard::CatchTypes::Named(vec![55]);
            refuse(code, &wrong_catch, &owners, &visited);
            let mut wrong_handler_shape = shape.clone();
            wrong_handler_shape.sites[0].handler = tail.clone();
            refuse(code, &wrong_handler_shape, &owners, &visited);
            let mut duplicate_owner = owners.clone();
            duplicate_owner.push(tail.clone());
            refuse(code, &shape, &duplicate_owner, &visited);
            let mut missing_owner = visited.clone();
            missing_owner.remove(&view.index_of(&tail).expect("tail is mapped"));
            refuse(code, &shape, &owners, &missing_owner);

            let mut ample = ample_budget();
            let mut baseline_shape_budget = ample_budget();
            let (start, shape, prefix, loop_blocks, tail, owners, visited) =
                loop5_frozen_parts(canonical, view, ssa, operations, code, &mut baseline_shape_budget);
            assert!(run_loop5_return_tail_certificate(
                canonical, view, ssa, operations, code, &start, &shape,
                &prefix, &loop_blocks, &tail, &owners, &visited, &mut ample,
            ).expect("complete isolated proof"));
            let cost = ample.usage().analysis_steps;
            assert!(cost > 0);
            let mut short = Budget::new(Limits {
                analysis_steps: cost - 1,
                elapsed_millis: u64::MAX,
                ..Limits::default()
            });
            assert!(matches!(
                run_loop5_return_tail_certificate(
                    canonical, view, ssa, operations, code, &start, &shape,
                    &prefix, &loop_blocks, &tail, &owners, &visited, &mut short,
                ),
                Err(StopReason::Budget {
                    dimension: CountedBudgetDimension::AnalysisSteps,
                    ..
                })
            ));
            let token = CancellationToken::new();
            token.cancel();
            let mut cancelled = Budget::with_cancellation_token(
                Limits { elapsed_millis: u64::MAX, ..Limits::default() },
                token,
            );
            assert!(matches!(
                run_loop5_return_tail_certificate(
                    canonical, view, ssa, operations, code, &start, &shape,
                    &prefix, &loop_blocks, &tail, &owners, &visited, &mut cancelled,
                ),
                Err(StopReason::Cancelled { .. })
            ));
        },
    );
}

/// Full recovery acceptance is intentionally gated on the separate Loop4 break-body proof.
#[test]
#[ignore = "requires the pending Loop4 named-row break-body proof; not yet integrated"]
fn loop5_full_try_owns_prefix_loop_and_return_tail_after_loop4_proof() {
    for class in [LOOP5_DEBUG, LOOP5_NO_DEBUG] {
        with_frozen_method_ir(
            class,
            b"test",
            b"(Ljava/lang/String;)J",
            |canonical, _view, _ssa, _operations, _code, recovered| {
                assert!(recovered.is_structured(), "{:#?}", recovered.regions);
                assert_eq!(recovered.claimed.len(), canonical.blocks().len());
                assert_eq!(recovered.blocks, canonical.blocks().len());
                let tries: Vec<_> = recovered
                    .regions
                    .iter()
                    .filter_map(|region| match region {
                        Region::Try { .. } => Some(region),
                        _ => None,
                    })
                    .collect();
                let [Region::Try { body, catches, normal_exit_bci, .. }] = tries.as_slice() else {
                    panic!("one ordinary Try owns the frozen Loop5 body: {:#?}", recovered.regions);
                };
                assert_eq!(*normal_exit_bci, None);
                assert_eq!(catches.len(), 1);
                assert_eq!(catches[0].handler().bci(), 124);
                let Region::Sequence { regions } = body.as_ref() else {
                    panic!("the protected body is prefix + loop + tail: {body:#?}");
                };
                assert_eq!(regions.len(), 3);
                assert!(matches!(&regions[0], Region::Straight { blocks } if blocks.iter().map(CanonicalBlockId::bci).collect::<Vec<_>>() == vec![0]));
                fn one_loop_header(region: &Region) -> Option<u32> {
                    match region {
                        Region::Loop { header, .. } => Some(header.bci()),
                        Region::Sequence { regions } if regions.len() == 1 => {
                            one_loop_header(&regions[0])
                        }
                        _ => None,
                    }
                }
                assert_eq!(one_loop_header(&regions[1]), Some(14));
                assert!(matches!(&regions[2], Region::Straight { blocks } if blocks.iter().map(CanonicalBlockId::bci).collect::<Vec<_>>() == vec![106]));
                let mut budget = ample_budget();
                let owners = candidate_region_owner_counts(&recovered.regions, &mut budget, true, true)
                    .expect("owner inventory completes")
                    .expect("all regions have enumerable owners");
                assert_eq!(owners.len(), canonical.blocks().len());
                assert!(owners.values().all(|count| *count == 1));
            },
        );
    }
}
