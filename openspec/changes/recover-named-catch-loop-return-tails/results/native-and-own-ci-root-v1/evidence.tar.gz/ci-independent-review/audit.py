#!/usr/bin/env python3
"""Independent read-only re-open of closed Loop4/5 own-CI raw evidence."""
import ast, collections, hashlib, json, re, zipfile
from pathlib import Path

BASE=Path('/private/tmp/jarde-loop45-own-ci-root-v2-20261019')
OUT=Path('/private/tmp/jarde-loop45-own-ci-independent-review-luna-v1-20261019')
PRODUCT='412245d514896b1d0eb9a8fe24388f6a70668637'
CLI='d29b6fee723d8f59fbecd9fd8be9f15a8ec73de3a90f5a2a29b24ff91e4af607'
SEEDS=['5350648285461741569','5350648285461741570']

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p): return sha_bytes(Path(p).read_bytes())
def need(ok,msg):
    if not ok: raise AssertionError(msg)
def relpath(path):
    p=Path(path)
    try: return str(p.relative_to(BASE))
    except ValueError: return str(p)
def clean(line):
    line=re.sub(r'(?:\x1b|\^\[)\[[0-9;]*[A-Za-z]','',line)
    # GitHub step log prefix: job<TAB>step<TAB>timestampZ<space>
    parts=line.split('\t',2)
    if len(parts)==3:
        line=re.sub(r'^\d{4}-\d\d-\d\dT[^ ]+Z ?', '', parts[2])
    return line.strip()

def parse_workspace_group(group):
    lines=[clean(x) for x in group.splitlines()]
    headers=[]
    for line in lines:
        if line.startswith('Running '):
            m=re.fullmatch(r'Running (.+) \(target/debug/(?:deps|examples)/([^/ ]+)\)',line)
            need(m is not None,f'unrecognized Cargo target header {line!r}')
            em=re.fullmatch(r'(.+)-[0-9a-f]{16}',m.group(2))
            need(em is not None,f'unrecognized hashed Cargo binary {m.group(2)!r}')
            headers.append(em.group(1))
    blocks=[]; i=0
    while i<len(lines):
        rm=re.fullmatch(r'running (\d+) tests?',lines[i])
        if not rm:
            i+=1; continue
        n=int(rm.group(1)); i+=1; named=[]
        while i<len(lines):
            sm=re.fullmatch(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out(?:; finished in .*)?',lines[i])
            if sm:
                passed,failed,ignored,measured,filtered=map(int,sm.groups()[1:])
                need(len(named)==n,f'target block declares {n}, named {len(named)}')
                got=collections.Counter(x[1] for x in named)
                need((got['ok'],got['FAILED'],got['ignored'])==(passed,failed,ignored),'named outcomes differ from Cargo summary')
                need(failed==0,'failed outcomes present')
                blocks.append({'declared':n,'named':named,'summary':{'passed':passed,'failed':failed,'ignored':ignored,'measured':measured,'filtered':filtered}})
                i+=1; break
            om=re.fullmatch(r'test (.+?)(?: - should panic)? \.\.\. (ok|FAILED)(?:, .*)?',lines[i])
            ig=re.fullmatch(r'test (.+?) \.\.\. ignored(?:, .*)?',lines[i])
            if om: named.append((om.group(1),om.group(2)))
            elif ig: named.append((ig.group(1),'ignored'))
            elif lines[i].startswith('test result:') or lines[i].startswith('test '):
                raise AssertionError(f'unparsed Cargo output in named test block: {lines[i]!r}')
            i+=1
        else: raise AssertionError('incomplete named test block')
    need(len(blocks)==len(headers),f'Cargo target headers ({len(headers)}) and outcome blocks ({len(blocks)}) differ')
    for target,block in zip(headers,blocks): block['target']=target
    triples=collections.Counter((b['target'],name,status) for b in blocks for name,status in b['named'])
    return blocks,triples

def source_gate_inventory():
    # Read the frozen inherited gate declaration as data; do not execute verifier code.
    old=Path('/private/tmp/jarde-loop2-retry-native-ci-prep-luna-v2-20261019/verify-own-ci.py')
    tree=ast.parse(old.read_text())
    tables={}
    for node in tree.body:
        if isinstance(node,ast.Assign):
            names=[t.id for t in node.targets if isinstance(t,ast.Name)]
            if not names: continue
            name=names[0]
            if isinstance(node.value,ast.Dict):
                try: tables[name]=ast.literal_eval(node.value)
                except Exception: pass
            elif name=='CRITICAL_TESTS' and isinstance(node.value,ast.DictComp):
                # Frozen verifier's one comprehension prefixes module identity for jarde_java tests.
                oldmap=tables['CRITICAL_TESTS']
                tables[name]={label:((('region::protected_prefix_loop_tests::'+test) if target=='jarde_java' else test),target) for label,(test,target) in oldmap.items()}
        elif isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and isinstance(node.value.func.value,ast.Name) and node.value.func.value.id=='CRITICAL_TESTS' and node.value.func.attr=='update':
            arg=node.value.args[0]
            mapping=ast.literal_eval(arg) if isinstance(arg,ast.Dict) else tables.get(arg.id) if isinstance(arg,ast.Name) else None
            need(mapping is not None,f'cannot read frozen gate update at line {node.lineno}')
            tables['CRITICAL_TESTS'].update(mapping)
    base=tables['CRITICAL_TESTS']
    need(len(base)==110, f'inherited gate declaration count {len(base)} != 110')
    argv=json.loads(Path('/private/tmp/jarde-loop45-native-ci-prep-luna-v3-20261019/acceptance-argv.json').read_text())['fixed_ci_extra_critical']
    extra=argv
    need(len(extra)==13,'frozen accepted verifier extra-gate argument count')
    inherited={(target,name) for name,target in base.values()}
    for spec in extra:
        target,sep,name=spec.partition('='); need(bool(sep and target and name),'bad frozen extra identity')
        inherited.add((target,name))
    review=json.loads((BASE/'loop45-review.json').read_text())
    supplemental={(g['target'],g['test']) for g in review['supplemental_exact_gates']}
    need(len(supplemental)==18,'supplemental gate list count')
    allgates=inherited|supplemental
    need(len(inherited)==123 and len(allgates)==141,'gate inventory totals')
    return sorted(inherited),sorted(supplemental),sorted(allgates)

def main():
    coll=json.loads((BASE/'collection.json').read_text()); run=json.loads((BASE/'run.json').read_text()); api=json.loads((BASE/'jobs-api.json').read_text()); supp=json.loads((BASE/'step-log-supplement.json').read_text())
    need(coll['status']=='raw collection complete; independent acceptance pending' and coll['product_sha']==PRODUCT and coll['cli_sha256']==CLI,'collector identity/status')
    need(run['databaseId']==39251504476 and run['headSha']==PRODUCT and run['status']=='completed' and run['conclusion']=='success','run status/head')
    need(api['total_count']==4 and len(api['jobs'])==4,'API jobs count')
    need(len(coll['commands'])==184,'canonical command count')
    rawpins=[]; cmd_summaries=[]
    # Rehash every canonical command stream and each preserved transport attempt, preserving failed attempts.
    for ci,c in enumerate(coll['commands']):
        streams=[]
        for attempt in c.get('transport_attempts',[]):
            for which,s in attempt.get('streams',{}).items():
                p=Path(s['path']); data=p.read_bytes()
                need(len(data)==s['bytes'] and sha_bytes(data)==s['sha256'],f'cmd {ci} attempt {which} raw pin mismatch')
                rawpins.append({'command':ci,'attempt':True,'stream':which,'path':relpath(p),'bytes':len(data),'sha256':sha_bytes(data),'exit_code':attempt['exit_code'],'argv':attempt['argv']})
        for which,s in c.get('streams',{}).items():
            p=Path(s['path']); data=p.read_bytes()
            need(len(data)==s['bytes'] and sha_bytes(data)==s['sha256'],f'cmd {ci} {which} raw pin mismatch')
            streams.append({'stream':which,'path':relpath(p),'bytes':len(data),'sha256':sha_bytes(data)})
            rawpins.append({'command':ci,'attempt':False,'stream':which,'path':relpath(p),'bytes':len(data),'sha256':sha_bytes(data),'exit_code':c['exit_code'],'argv':c['argv']})
        cmd_summaries.append({'index':ci,'argv':c['argv'],'exit_code':c['exit_code'],'transport_attempts':len(c.get('transport_attempts',[])),'streams':streams})
    need(len(rawpins)>0,'no raw pins')
    # Independent source/fixture binding from the command stream table and materialized git-show bytes.
    source_paths=coll['source_paths']; fixture_files=coll['fixture_files']
    need(len(source_paths)==34 and len(fixture_files)==144,'source/fixture inventory counts')
    pins=json.loads((BASE/'source-pins.json').read_text())
    need(pins['product_sha']==PRODUCT and pins['cli_sha256']==CLI,'source pin artifact product/CLI')
    source_counts=collections.Counter(); source_cmds=[]; fixture_cmds=[]
    for c in coll['commands']:
        argv=c['argv']
        if len(argv)==3 and argv[:2]==['git','show'] and argv[2].startswith(PRODUCT+':'):
            path=argv[2].split(':',1)[1]
            source_counts[path]+=1
            payload=Path(c['streams']['stdout']['path']).read_bytes()
            root=BASE/'product-source'/path
            if path in source_paths:
                need(root.is_file() and payload==root.read_bytes(),f'git-show/source file mismatch {path}')
                meta=pins['source_files'][path]
                need(len(payload)==meta['bytes'] and sha_bytes(payload)==meta['sha256'],f'source pin mismatch {path}')
                source_cmds.append(path)
            elif path in fixture_files:
                froot=BASE/'product-fixtures'/path
                need(froot.is_file() and payload==froot.read_bytes(),f'git-show/fixture file mismatch {path}')
                meta=pins['fixture_files'][path]
                need(len(payload)==meta['bytes'] and sha_bytes(payload)==meta['sha256'],f'fixture pin mismatch {path}')
                fixture_cmds.append(path)
            else: raise AssertionError(f'git show outside declared inventory: {path}')
    need(set(source_cmds)==set(source_paths) and len(source_cmds)==34,'not every source path git-show bound')
    need(set(fixture_cmds)==set(fixture_files) and len(fixture_cmds)==144,'not every fixture git-show bound')
    need(coll['source_before_after_equal'] is True and coll['target_absent_after'] is True,'collector source/clean flags')
    # The actual full workspace test runs in official stable raw log.
    stable=(BASE/'stable.log').read_text(errors='replace')
    markers=[m.start() for m in re.finditer(r'##\[group\]Run cargo test --workspace --all-targets --all-features --locked',stable)]
    need(len(markers)==2,'expected exactly two fixed-seed workspace invocations')
    ends=[stable.find('##[endgroup]',m) for m in markers]
    # invocation block extends through each command output and stops at next step group; group delimiter is not reliable
    groups=[]
    for i,start in enumerate(markers):
        end=markers[i+1] if i+1<len(markers) else stable.find('##[group]Run cargo test --test jvm_bytecode_oracle',start)
        if end<0: end=len(stable)
        groups.append(stable[start:end])
    counters=[]; seed_blocks=[]; seed_summaries=[]
    for seed,g in zip(SEEDS,groups):
        need(f'PROPTEST_RNG_SEED: {seed}' in g,f'seed {seed} not in raw workspace block')
        blocks,counter=parse_workspace_group(g)
        counters.append(counter); seed_blocks.append(blocks)
        seed_summaries.append({'seed':seed,'target_count':len(blocks),'named_test_count':sum(len(b['named']) for b in blocks),'status_counts':dict(collections.Counter(st for _,_,st in counter.elements())),'targets':[{'target':b['target'],'declared':b['declared'],'summary':b['summary']} for b in blocks]})
    need(counters[0]==counters[1],'full target/test/status Counter differs by seed')
    need(len(seed_blocks[0])==len(seed_blocks[1])==394,'target count not 394')
    need(sum(counters[0].values())==sum(counters[1].values())==3939,'named outcome total not 3939')
    status_count=collections.Counter()
    for (_,_,status),count in counters[0].items(): status_count[status]+=count
    need(status_count=={'ok':3841,'ignored':98},f'unexpected aggregate statuses {status_count}')
    # Exact 141 gates checked against independently parsed raw Counter.
    baseg,suppg,allg=source_gate_inventory()
    gate_rows=[]
    for target,name in allg:
        n=counters[0][(target,name,'ok')]
        total=sum(counters[0][(target,name,s)] for s in ('ok','FAILED','ignored'))
        need(n==total==1,f'exact gate not exactly one pass per seed: {target}::{name} {n}/{total}')
        need(counters[1][(target,name,'ok')]==1,'exact gate missing seed2')
        gate_rows.append({'target':target,'test':name,'seed1':'ok once','seed2':'ok once','kind':'inherited' if (target,name) in baseg else 'supplemental'})
    # Official API jobs and the unmodified official step ZIP: exact members must represent all 52 API steps.
    api_jobs={j['id']:j for j in api['jobs']}
    need(len(api_jobs)==4,'API job identities')
    run_job_ids={j['databaseId'] for j in run['jobs']}
    need(run_job_ids==set(api_jobs),'run metadata and API job identities differ')
    jobstep=[]
    for job in api['jobs']:
        need(job.get('status')=='completed' and job.get('conclusion')=='success',f"API job not successful {job.get('name')}")
        for st in job['steps']:
            need(st.get('status')=='completed' and st.get('conclusion')=='success',f"step not successful {job['name']}::{st['name']}")
            jobstep.append((job['name'],st['name'],st['number']))
    need(len(jobstep)==52,'API step count not 52')
    zip_path=BASE/'run-logs.zip'; zdata=zip_path.read_bytes()
    need(len(zdata)==supp['streams']['stdout']['bytes'] and sha_bytes(zdata)==supp['streams']['stdout']['sha256'],'official ZIP raw pin')
    need(zdata==(BASE/'official-zip-attempt-1.zip').read_bytes(),'official ZIP transport copy differs')
    with zipfile.ZipFile(zip_path) as z:
        names=z.namelist(); need(len(names)==60,'official ZIP member count drift')
        # Each API step member is keyed by display job + ordinal + exact sanitized step name.
        missing=[]; checked=[]
        for jname,sname,num in jobstep:
            base_name=jname.replace(' / ',' _ ')
            step_name=sname.replace('/','_')
            member=f'{base_name}/{num}_{step_name}.txt'
            if member not in names:
                # GitHub ZIP encodes slash/spaces in job path; match unique ordinal+name suffix.
                candidates=[n for n in names if n.endswith(f'/{num}_{step_name}.txt')]
                if len(candidates)!=1: missing.append((jname,num,sname,candidates))
                else: member=candidates[0]
            if member in names:
                content=z.read(member); need(len(content)>0 or ('Post ' in sname),'empty step member unexpectedly')
                checked.append({'job':jname,'step':sname,'number':num,'member':member,'bytes':len(content),'sha256':sha_bytes(content)})
        need(not missing,f'API step members missing/ambiguous: {missing[:3]}')
        need(len(checked)==52,'not all official ZIP step members matched')
    # Product identity and inventory hashes.
    need(coll['source_file_count']==34 and coll['fixture_file_count']==144,'collector counts')
    need(len(pins['source_files'])==34 and len(pins['fixture_files'])==144,'pins inventories')
    review=json.loads((BASE/'loop45-review.json').read_text())
    need(review['status']=='accepted' and review['product']['head_sha']==PRODUCT and review['product']['cli_sha256']==CLI,'review identity differs')
    need(review['full_counter_sha256']=='4d7f47ae3006322df17f7baad9b6addba4abc12f834c775be52e73fee333fed9','full Counter digest mismatch with expected frozen review')
    # Independently encode sorted full counter and compare its actual digest (not merely review JSON).
    rows=[[t,n,s,c] for (t,n,s),c in sorted(counters[0].items())]
    digest=sha_bytes(json.dumps(rows,ensure_ascii=False,separators=(',',':')).encode())
    # This audit's key encoding is documented separately; equality to review digest is diagnostic only.
    input_names=['collection.json','run.json','jobs-api.json','step-log-supplement.json','run-logs.zip','loop45-review.json']
    input_pins=[{'path':name,'bytes':(BASE/name).stat().st_size,'sha256':sha_file(BASE/name)} for name in input_names]
    transport_records=[a for c in coll['commands'] for a in c.get('transport_attempts',[])]
    transport_summary={'attempts':len(transport_records),'failed_attempts':sum(a['exit_code']!=0 for a in transport_records),'successful_attempts':sum(a['exit_code']==0 for a in transport_records),'canonical_commands_final_failed':sum(c['exit_code']!=0 for c in coll['commands'])}
    report={'schema':'loop45-own-ci-independent-raw-review-v1','status':'raw_integrity_and_semantics_verified',
      'product_sha':PRODUCT,'cli_sha256':CLI,'run':{'id':run['databaseId'],'head_sha':run['headSha'],'status':run['status'],'conclusion':run['conclusion']},
      'input_artifact_pins':input_pins,'commands':{'canonical_count':len(coll['commands']),'raw_stream_instances':len(rawpins),'transport_summary':transport_summary,'command_records':cmd_summaries},
      'source_binding':{'source_count':34,'fixture_file_count':144,'source_git_show_count':len(source_cmds),'fixture_git_show_count':len(fixture_cmds),'source_fixture_files_rehashed':True,'git_commit':PRODUCT},
      'workspace_runs':seed_summaries,'seed_counters_equal':True,'full_counter_distinct_entries':len(counters[0]),'full_counter_named_rows':len(rows),'full_counter_sha256_canonical_json_rows':digest,
      'status_totals':dict(status_count),'gate_counts':{'inherited':len(baseg),'supplemental':len(suppg),'total':len(allg),'supplemental_classes':{'region':sum(t.startswith('region::') for _,t in suppg),'public':sum(target=='recover_loop45_original_public' for target,_ in suppg),'builder':sum(t.startswith('build::tests::') for _,t in suppg)}},'gates':gate_rows,
      'official_ci':{'api_jobs':4,'successful_steps':len(jobstep),'official_zip_members':60,'matched_api_step_members':len(checked),'expanded_api_steps':checked,'zip_sha256':sha_bytes(zdata),'zip_bytes':len(zdata),'not_aggregate_rebuilt':True},
      'native_receipt_separation':'No native receipt or native observed_counts were read or merged; source is own-CI receipt/log/official ZIP only.'}
    (OUT/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (OUT/'raw-pins.json').write_text(json.dumps(rawpins,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['status','commands','source_binding','workspace_runs','full_counter_distinct_entries','full_counter_sha256_canonical_json_rows','status_totals','gate_counts','official_ci'] if k!='commands'},ensure_ascii=False))

if __name__=='__main__': main()
