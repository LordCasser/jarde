# Independent own-CI raw audit

Read-only audit of the CLOSED evidence under `/private/tmp/jarde-loop45-own-ci-root-v2-20261019`. `audit.py` uses Python `-B`; it does not call Git, network, Cargo, JDK, or product tooling.

The audit rehashes every canonical command stream and preserved transport attempt, checks source and fixture `git show` stdout against the materialized files and pins, parses both fixed-seed Cargo workspace sections from the stable job raw log, rebuilds complete `(target, test, status)` Counters, checks every inherited and Loop45 exact gate, and maps the official ZIP's 52 API job steps to their exact members. It preserves the official ZIP as downloaded; it does not rebuild an aggregate archive.

Results: 184 canonical commands; 384 raw stream instances; 8 transport attempts (2 failed attempts followed by successful retries; no canonical command ended in failure); 34 source files and 144 fixture files bound to commit `412245d514896b1d0eb9a8fe24388f6a70668637`; each seed has 394 targets / 3,939 named outcomes (3,841 pass, 0 fail, 98 ignored); complete seed Counters match with canonical digest `4d7f47ae3006322df17f7baad9b6addba4abc12f834c775be52e73fee333fed9`; all 141 exact gates pass once per seed (123 inherited + 18 supplemental); 4 API jobs and all 52 steps succeeded, with all 52 step logs matched to members in the 60-member, 877,856-byte official ZIP.

`review.json` contains derived outcomes and job-step member pins. `raw-pins.json` contains the individual raw-stream paths, byte counts, hashes, exit statuses, and argv. `manifest.json` pins this audit package and its closed input artifacts. The review is limited to this own-CI evidence and does not import or merge native receipt counts.
