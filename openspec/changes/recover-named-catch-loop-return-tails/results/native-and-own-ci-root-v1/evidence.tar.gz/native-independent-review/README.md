# Loop4/5 native v2 independent raw audit

This audit independently reopened the CLOSED native v2 receipt and all 212 stdout/stderr streams, then parsed each harness block into a unique `(package, target, test name, status)` result. Expected targets were derived from the captured Cargo metadata and bound to raw harness blocks using stderr `Running` executable identities. No Git, network, or toolchain ran; the older failed native v1 and still-open own-CI results were not read.

The raw stream results cover 394 unique metadata-derived targets and 3,939 unique tests: 3,841 passed, 0 failed, 98 ignored. All 96 critical gates occurred exactly once and passed. This includes 14 Loop4/Loop5/Builder unit gates, 4 public integration gates, and all 9 tests in `cf12_proved_local_source_types`, including the exact budget-stop gate. The raw-derived per-target counts match the separate root review target table.

The receipt’s per-batch `observed_counts` field does not match the raw `Running`-bound outputs for 316 target/batch entries. For example, batch 2 raw output binds 249 tests to the `jarde` lib target, while that receipt field assigns 249 to the `task_operations` example. Overall totals still match. The audit reports the raw-derived target counts and records this discrepancy separately; it does not treat it as a test failure.

All 5,299 source pins were rehashed and matched before/after formatting and the stored source set. `cargo fmt --all -- --check` and `cargo clean` both exited 0; no guard triggered, the repository target directory was absent after cleanup, and 394 completed test executables were removed. The recorded guard ceiling was 1 GiB, maximum observed target size 854,234,934 bytes, with free space always above the 5 GiB floor. `RUST_MIN_STACK` was absent and not overridden.

See `review.json` for every raw pin, all 3,939 target/test/status identities, the 96 gates, exact CF12 and new gate names, source pins, and the `observed_counts` discrepancy.
