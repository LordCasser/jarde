from __future__ import annotations
import ast, collections, hashlib, json, re
from pathlib import Path

OUT=Path('/private/tmp/jarde-loop45-native-v2-independent-review-luna-v1-20261019')
RECEIPT=Path('/private/tmp/jarde-loop45-native-root-v2-20261019/execution.json')
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
REVIEW=Path('/private/tmp/jarde-loop45-native-review-root-v1-20261019/review.json')
INHERITED=Path('/private/tmp/jarde-loop2-retry-native-ci-prep-luna-v2-20261019/inherited/ancestor-iterator-verify-native.py')

def sha(b): return hashlib.sha256(b).hexdigest()
def pin(path):
    p=Path(path); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def canonical_sha(v): return sha(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode())
def load(p): return json.loads(Path(p).read_text())
def verify_stream(ref):
    p=Path(ref['path']); b=p.read_bytes()
    assert len(b)==ref['bytes'] and sha(b)==ref['sha256'], str(p)
    return b

def strip_ansi(s): return re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',s)
RUN_RE=re.compile(r'^\s*Running\s+(.*?)\s+\(target/debug/(?:deps|examples)/[^)]*\)\s*$')
BLOCK_RE=re.compile(r'^running\s+(\d+)\s+tests?\s*$')
TEST_RE=re.compile(r'^test\s+(.+?)\s+\.\.\.\s+(ok|FAILED|ignored)(?:,.*)?$')
SUMMARY_RE=re.compile(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;')

def target_from_running(desc, executed):
    if desc.startswith('unittests src/lib.rs'):
        kind='lib'; name_candidates=[x for x in executed if x[2]=='lib']
    elif desc.startswith('unittests src/main.rs'):
        kind='bin'; name_candidates=[x for x in executed if x[2]=='bin']
    elif desc.startswith('unittests src/bin/'):
        kind='bin'; stem=Path(desc.split(' (',1)[0].split('/')[-1]).stem
        name_candidates=[x for x in executed if x[2]=='bin' and x[1]==stem]
    elif desc.startswith('unittests examples/'):
        kind='example'; stem=Path(desc.split(' (',1)[0].split('/')[-1]).stem
        name_candidates=[x for x in executed if x[2]=='example' and x[1]==stem]
    elif desc.startswith('tests/'):
        kind='test'; stem=Path(desc.split(' (',1)[0].split('/')[-1]).stem
        name_candidates=[x for x in executed if x[2]=='test' and x[1]==stem]
    else:
        raise AssertionError(f'unrecognized Cargo Running target: {desc}')
    assert len(name_candidates)==1,(desc,name_candidates)
    return tuple(name_candidates[0])

def parse_harness_output(stdout, stderr, command):
    executed=[tuple(x) for x in command['executed_targets']]
    assert len(executed)==len(set(executed))
    assert set(executed)=={tuple(x) for x in command['planned_targets']}
    assert set(executed)=={tuple(x['target']) for x in command['observed_counts']}
    stderr_lines=strip_ansi(stderr.decode('utf-8','replace')).splitlines()
    running=[target_from_running(m.group(1),executed) for line in stderr_lines if (m:=RUN_RE.match(line))]
    assert len(running)==len(executed) and len(set(running))==len(running),(command['index'],running,executed)
    lines=stdout.decode('utf-8','replace').splitlines(); blocks=[]; i=0
    while i<len(lines):
        match=BLOCK_RE.match(lines[i])
        if not match:
            i+=1; continue
        declared=int(match.group(1)); tests=[]; counts=None; j=i+1
        while j<len(lines):
            test=TEST_RE.match(lines[j])
            if test: tests.append((test.group(1),test.group(2)))
            summary=SUMMARY_RE.match(lines[j])
            if summary:
                counts=tuple(map(int,summary.groups())); break
            # A new block before a summary means this block was malformed.
            if BLOCK_RE.match(lines[j]): break
            j+=1
        assert counts is not None,(command['index'],i,'missing test result summary')
        observed=(sum(x[1]=='ok' for x in tests),sum(x[1]=='FAILED' for x in tests),sum(x[1]=='ignored' for x in tests))
        assert declared==len(tests) and counts==observed,(command['index'],declared,len(tests),counts,observed)
        blocks.append({'declared':declared,'counts':counts,'tests':tests})
        i=j+1
    assert len(blocks)==len(running),(command['index'],len(blocks),len(running))
    results=[]; target_rows=[]
    for target,block in zip(running,blocks):
        target_rows.append({'target':list(target),'counts':list(block['counts']),'test_count':len(block['tests'])})
        results.extend({'target':list(target),'test':test,'status':status} for test,status in block['tests'])
    assert command['test_total']==[sum(x['counts'][i] for x in blocks) for i in range(3)]
    return target_rows,results

def expected_critical_gates(native_review):
    names=[]
    for key,value in native_review.items():
        if isinstance(value,list) and key.endswith('_gates'):
            for x in value:
                if isinstance(x,dict): names.append((x['target'],x['test']))
    tree=ast.parse(INHERITED.read_text())
    gate_node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='GATES' for t in n.targets))
    inherited=ast.literal_eval(gate_node.value)
    inherited=[(x[0],x[1]) for x in inherited]
    names.extend(inherited)
    assert len(names)==96 and len(set(names))==96,(len(names),len(set(names)))
    return names, inherited

def run_audit():
    receipt=load(RECEIPT); native_review=load(REVIEW)
    assert receipt['status']=='passed' and receipt['schema']=='finthrow-full-workspace-seed-replay-v1'
    assert receipt['seed']=='5350648285461741569' and receipt['no_carried_execution'] is True
    assert native_review['native_receipt']['path']==str(RECEIPT)
    assert native_review['status']=='passed' and native_review['critical_gate_count']==96
    assert sha(INHERITED.read_bytes())==native_review['inherited_gate_wrapper']['sha256']
    raw_pins=[]
    all_commands=[receipt['format_command'],receipt['metadata_command'],*receipt['commands'],receipt['clean_command']]
    assert len(all_commands)==106
    assert [x['index'] for x in all_commands]==list(range(106))
    for cmd in all_commands:
        assert cmd['exit_code']==0 and cmd.get('guard_stop') is None
        for stream in ('stdout','stderr'):
            verify_stream(cmd['streams'][stream]); raw_pins.append(cmd['streams'][stream])
    assert len(raw_pins)==212
    # Format, metadata, clean, and batch command results are independently read from their pinned raw files.
    fmt=receipt['format_command']; assert fmt['argv']==['cargo','fmt','--all','--','--check']
    assert verify_stream(fmt['streams']['stdout'])==b'' and verify_stream(fmt['streams']['stderr'])==b''
    metadata_bytes=verify_stream(receipt['metadata_command']['streams']['stdout'])
    assert metadata_bytes==Path(receipt['metadata_file']['path']).read_bytes()
    assert sha(metadata_bytes)==receipt['metadata_file']['sha256'] and len(metadata_bytes)==receipt['metadata_file']['bytes']
    metadata=json.loads(metadata_bytes)
    assert metadata['workspace_root']==str(ROOT)
    workspace=set(metadata['workspace_members'])
    kinds={'lib','test','example','bin'}
    metadata_targets=[]
    for package in metadata['packages']:
        if package['id'] not in workspace: continue
        for target in package['targets']:
            kind=target['kind'][0]
            if kind in kinds: metadata_targets.append((package['id'],target['name'],kind))
    assert len(metadata_targets)==394 and len(set(metadata_targets))==394
    recorded_inventory={tuple(x) for x in receipt['target_inventory']}
    assert recorded_inventory==set(metadata_targets)
    assert receipt['metadata_command']['exit_code']==0
    # Every planned target is assigned once across 103 batches, and every per-target harness result is reconstructed from raw text.
    assert len(receipt['commands'])==103 and receipt['expected_batch_count']==103
    assert [c['index'] for c in receipt['commands']]==list(range(2,105))
    seen_targets=[]; target_summaries=[]; results=[]; batch_records=[]
    for command in receipt['commands']:
        assert command['exit_code']==0
        assert command['guard_stop'] is None
        assert command['peak_target_bytes']<=receipt['guard_limits']['target_bytes']
        assert command['free_bytes_after']>=receipt['guard_limits']['free_bytes']
        assert 'RUST_MIN_STACK' not in command['env_overrides']
        for name in receipt['environment']['stripped_names']:
            assert name not in command['env_overrides']
        stdout=verify_stream(command['streams']['stdout']); stderr=verify_stream(command['streams']['stderr'])
        summaries,run_results=parse_harness_output(stdout,stderr,command)
        seen_targets.extend(tuple(x['target']) for x in summaries)
        target_summaries.extend(summaries); results.extend(run_results)
        batch_records.append({'index':command['index'],'planned':len(command['planned_targets']),
                              'executed':len(command['executed_targets']),'targets':summaries,
                              'test_rows':len(run_results),'test_total':command['test_total'],
                              'peak_target_bytes':command['peak_target_bytes'],'free_bytes_after':command['free_bytes_after']})
    assert len(seen_targets)==394 and len(set(seen_targets))==394 and set(seen_targets)==recorded_inventory
    outcome_counts=collections.Counter(x['status'] for x in results)
    assert outcome_counts=={'ok':3841,'ignored':98} and len(results)==3939
    unique_keys=[(tuple(x['target']),x['test']) for x in results]
    assert len(unique_keys)==len(set(unique_keys))==3939
    assert sum(x['test_count'] for x in target_summaries)==3939
    raw_target_counts=collections.defaultdict(lambda:[0,0,0])
    receipt_observation_mismatches=[]
    for row in target_summaries:
        counts=raw_target_counts[tuple(row['target'])]
        for i,value in enumerate(row['counts']): counts[i]+=value
    for command in receipt['commands']:
        # Compare this batch's collector-side count table with raw summaries bound by stderr Running order.
        stdout=verify_stream(command['streams']['stdout']); stderr=verify_stream(command['streams']['stderr'])
        raw_rows,_=parse_harness_output(stdout,stderr,command)
        raw_for_batch={tuple(x['target']):tuple(x['counts']) for x in raw_rows}
        recorded={tuple(x['target']):tuple(x['counts']) for x in command['observed_counts']}
        if raw_for_batch!=recorded:
            for key in sorted(set(raw_for_batch)|set(recorded)):
                if raw_for_batch.get(key)!=recorded.get(key):
                    receipt_observation_mismatches.append({'command':command['index'],'target':list(key),
                        'raw_running_bound':raw_for_batch.get(key),'receipt_observed_counts':recorded.get(key)})
    root_review_targets={tuple(x['target']):tuple(x['counts']) for x in native_review['workspace']['target_counts']}
    assert len(raw_target_counts)==394 and dict((k,tuple(v)) for k,v in raw_target_counts.items())==root_review_targets
    assert [sum(x['counts'][i] for x in target_summaries) for i in range(3)]==[3841,0,98]
    assert receipt['workspace_summary_count']==394
    assert receipt['workspace_totals']==[3841,0,98]
    # Bind the independent 96-gate expectation set to raw test events, not the receipt summary.
    gates,inherited=expected_critical_gates(native_review)
    result_by_alias=collections.defaultdict(list)
    for row in results: result_by_alias[(row['target'][1],row['test'])].append(row)
    gate_results=[]
    for target,test in gates:
        matches=result_by_alias[(target,test)]
        assert len(matches)==1 and matches[0]['status']=='ok',(target,test,matches)
        gate_results.append({'target':target,'test':test,'status':matches[0]['status']})
    assert len(gate_results)==96
    # Exact newly added Loop4/Loop5/Builder unit gates and public gates are individually present once and passing.
    new_unit=[(target,test) for target,test in gates if target=='jarde_java' and any(
        key in test for key in ('region::loop_break_body_tests::','region::finite_loop_catch_tests::loop5_return_tail_tests::','build::tests::loop5_catch_binding_tests::'))]
    public=[(target,test) for target,test in gates if target=='recover_loop45_original_public']
    assert len(new_unit)==14 and len(public)==4
    new_unit_records=[]; public_records=[]
    for target,test in new_unit+public:
        rows=result_by_alias[(target,test)];assert len(rows)==1 and rows[0]['status']=='ok'
        rec={'target':target,'test':test,'status':rows[0]['status']}
        (new_unit_records if (target,test) in new_unit else public_records).append(rec)
    cf12=[x for x in results if x['target'][1]=='cf12_proved_local_source_types']
    assert len(cf12)==9 and all(x['status']=='ok' for x in cf12)
    cf12_precision=[x for x in cf12 if x['test'] in {
        'typed_boundary_proof_budget_stops_before_publication_at_observed_sites',
        'typed_boundary_null_first_exact_string_stays_string_in_both_debug_profiles',
        'typed_boundary_four_char_seeds_have_specific_types_and_full_origins_in_both_debug_profiles',
        'typed_boundary_mixed_all_null_and_unknown_reference_stay_object_in_both_debug_profiles',
        'typed_boundary_range_arithmetic_and_input_copy_remain_int_in_both_debug_profiles',
        'typed_boundary_real_slot_conflict_is_preserved_as_the_exact_fallback_in_default_and_all',
        'cf12_charat_stored_value_drives_char_source_type_and_full_origins',
        'cf12_null_first_direct_string_writes_drive_string_source_type_and_full_origins',
        'cf12_recovery_budget_stop_and_cancellation_publish_no_partial_source'}]
    assert len(cf12_precision)==9 and all(x['status']=='ok' for x in cf12_precision)
    # Reopen every pinned source file, then prove formatter and final source pin sets match byte-for-byte.
    before=receipt['source_pins_before_format']; mid=receipt['source_pins']; after=receipt['source_pins_after_format']
    assert len(before)==len(mid)==len(after)==5299 and before==mid==after
    assert receipt['pins_unchanged'] is True
    reopened_source=[]
    for rel,digest in after.items():
        path=ROOT/rel; b=path.read_bytes()
        assert sha(b)==digest,rel
        reopened_source.append({'path':rel,'bytes':len(b),'sha256':digest})
    source_manifest_sha=canonical_sha(after)
    assert source_manifest_sha==native_review['source_pins_sha256']
    # Guard, default stack, target cleanup, formatting, and cargo clean are evidenced by this receipt.
    assert receipt['target_absent_before'] is True and receipt['target_absent_after_clean'] is True
    assert not (ROOT/'target').exists()
    assert all(command['guard_stop'] is None for command in all_commands)
    assert all(command['peak_target_bytes']<=receipt['guard_limits']['target_bytes'] for command in receipt['commands'])
    assert all(command['free_bytes_after']>=receipt['guard_limits']['free_bytes'] for command in receipt['commands'])
    assert receipt['environment']['stripped_present_at_start']=={k:False for k in receipt['environment']['stripped_names']}
    assert pin(receipt['runner']['path'])['sha256']==receipt['runner']['sha256']
    assert pin(receipt['guard_template']['path'])['sha256']==receipt['guard_template']['sha256']
    assert pin(receipt['target_size_scan_adapter']['path'])['sha256']==receipt['target_size_scan_adapter']['sha256']
    clean=receipt['clean_command']; clean_stderr=verify_stream(clean['streams']['stderr']).decode('utf-8','replace')
    assert clean['argv']==['cargo','clean'] and clean['exit_code']==0
    assert len(receipt['removed_completed_test_executables'])==394
    assert len(receipt['removed_completed_test_dsym'])==0
    # No unrelated historical failed native attempt is mixed into this v2 receipt.
    review={
      'schema':'jarde.loop45.native-v2-independent-raw-review.v1',
      'status':'closed_native_v2_raw_streams_and_tests_independently_verified',
      'receipt':{'path':str(RECEIPT),'bytes':RECEIPT.stat().st_size,'sha256':sha(RECEIPT.read_bytes()),'status':receipt['status'],'seed':receipt['seed']},
      'raw_stream_count':len(raw_pins),'raw_streams':raw_pins,
      'targets':{'count':len(seen_targets),'metadata_derived_count':len(metadata_targets),'all_target_results_reopened':True,'target_summaries':target_summaries,'raw_running_bound_counts':{json.dumps(k):v for k,v in sorted(raw_target_counts.items())},'receipt_observed_counts_disagreement_count':len(receipt_observation_mismatches),'receipt_observed_counts_disagreement_samples':receipt_observation_mismatches[:25]},
      'test_results':{'count':len(results),'unique_target_test_identities':len(unique_keys),'statuses':dict(outcome_counts),'rows':results},
      'critical_gates':{'count':len(gate_results),'unique_count':len(set((x['target'],x['test']) for x in gate_results)),'all_once_and_pass':True,'rows':gate_results,'inherited_count':len(inherited)},
      'new_loop45_unit_gates':new_unit_records,'public_loop45_gates':public_records,
      'cf12_exact_gates':cf12_precision,
      'source_pins':{'count':len(after),'before_format_equal_after_format_and_source':True,'reopened_file_count':len(reopened_source),'canonical_sha256':source_manifest_sha,'files':reopened_source},
      'format':{'argv':fmt['argv'],'exit_code':fmt['exit_code'],'stdout_bytes':fmt['streams']['stdout']['bytes'],'stderr_bytes':fmt['streams']['stderr']['bytes']},
      'cleanup':{'argv':clean['argv'],'exit_code':clean['exit_code'],'target_absent_before':receipt['target_absent_before'],'target_absent_after_clean':receipt['target_absent_after_clean'],'removed_executable_count':len(receipt['removed_completed_test_executables']),'removed_dsym_count':len(receipt['removed_completed_test_dsym']),'clean_stderr':clean_stderr},
      'guard':{'triggered':False,'target_limit_bytes':receipt['guard_limits']['target_bytes'],'max_observed_target_bytes':max(c['peak_target_bytes'] for c in receipt['commands']),'minimum_free_bytes':min(c['free_bytes_after'] for c in receipt['commands']),'free_limit_bytes':receipt['guard_limits']['free_bytes'],'default_rust_min_stack':True},
      'scope':'Independent verification of CLOSED native v2 only; no old failed native v1 runs or unclosed own-CI results were read. No Git/network/toolchain/shared writes.'
    }
    (OUT/'review.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':review['status'],'raw_streams':len(raw_pins),'targets':len(seen_targets),'test_results':len(results),'statuses':dict(outcome_counts),'critical_gates':len(gate_results),'new_unit':len(new_unit_records),'public':len(public_records),'cf12':len(cf12_precision),'source_pins':len(reopened_source),'guard_triggered':False,'target_absent':True},indent=2))

if __name__=='__main__': run_audit()
