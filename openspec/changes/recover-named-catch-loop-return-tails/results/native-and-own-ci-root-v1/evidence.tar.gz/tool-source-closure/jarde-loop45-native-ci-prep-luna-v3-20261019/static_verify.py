#!/usr/bin/env python3
"""Static-only audit of private Loop45 native/CI adapters and two-seed outcome Counter."""
from __future__ import annotations
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from collections import Counter

OUT = Path(__file__).resolve().parent
V2 = Path('/private/tmp/jarde-loop45-native-ci-prep-luna-v2-20261019')
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASE = Path('/private/tmp/jarde-loop2-retry-native-ci-prep-luna-v2-20261019')
V1 = Path('/private/tmp/jarde-loop45-native-ci-prep-luna-v1-20261019')

def need(ok: bool, reason: str) -> None:
    if not ok:
        raise SystemExit(reason)

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

for name in ('common.py','verify-native-loop45.py','collect-own-ci-loop45.py',
             'verify-own-ci-loop45.py','static_verify.py'):
    path=OUT/name
    need(path.is_file() and not path.is_symlink(),f'missing private adapter: {name}')
    ast.parse(path.read_text(encoding='utf-8'),filename=str(path))

tree=ast.parse((OUT/'common.py').read_text(encoding='utf-8'))
base_pins=next(ast.literal_eval(n.value) for n in tree.body
               if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BASE_PINS' for t in n.targets))
for rel,digest in base_pins.items():
    path=BASE/rel
    need(path.is_file() and not path.is_symlink() and sha(path)==digest,f'frozen accepted base changed: {rel}')
v1_manifest=json.loads((OUT/'pins.json').read_text(encoding='utf-8'))
for item in v1_manifest['v1_files']:
    path=Path(item['path'])
    need(path.is_file() and path.stat().st_size==item['bytes'] and sha(path)==item['sha256'],
         f'Loop45 v1 input changed: {path}')
for item in v1_manifest['v2_files']:
    path=Path(item['path'])
    need(path.is_file() and path.stat().st_size==item['bytes'] and sha(path)==item['sha256'],
         f'Loop45 v2 input changed: {path}')
v2_manifest=v1_manifest['v2_manifest']
v2_manifest_path=Path(v2_manifest['path'])
need(v2_manifest_path.is_file() and v2_manifest_path.stat().st_size==v2_manifest['bytes'] and sha(v2_manifest_path)==v2_manifest['sha256'],
     'closed Loop45 v2 manifest changed')
base_review=json.loads((BASE/'static-review.json').read_text(encoding='utf-8'))
need(base_review['native_exact_gate_count']==78 and base_review['ci_exact_gate_count']==123,
     'accepted base gate inventory is not 78 native / 123 CI')
base_argv=json.loads((BASE/'acceptance-argv.json').read_text(encoding='utf-8'))
extras=[base_argv['verify_ci'][i+1] for i,token in enumerate(base_argv['verify_ci'][:-1]) if token=='--extra-critical']
need(len(extras)==13,'inherited CI argument inventory changed')
argv=json.loads((OUT/'acceptance-argv.json').read_text(encoding='utf-8'))
need(argv['fixed_ci_extra_critical']==extras,'recorded inherited CI identities changed')
need(argv['ci_fixed_seeds']==['5350648285461741569','5350648285461741570'],'fixed seeds changed')

l4=ROOT/'crates/jarde-java/src/region/loop_break_body_tests.rs'
l5=ROOT/'crates/jarde-java/src/region/loop5_return_tail_tests.rs'
builder_source=ROOT/'crates/jarde-java/src/build/tests/loop5_catch_binding_tests.rs'
public_path=ROOT/'tests/recover_loop45_original_public.rs'
def test_names(path):
    s=path.read_text(encoding='utf-8')
    import re
    return re.findall(r'(?m)^\s*#\[test\]\s*(?:#\[ignore[^\n]*\]\s*)?\s*fn\s+(\w+)\s*\(',s)
need(len(test_names(l4))==5 and len(test_names(l5))==6,'integrated Loop4/Loop5 test counts differ from current source')
need(len(test_names(public_path))==4,'public exact test count differs from current source')
common_spec=importlib.util.spec_from_file_location('loop45_common_static',OUT/'common.py')
common=importlib.util.module_from_spec(common_spec); common_spec.loader.exec_module(common)
need(len(common.REGION_GATES)==11 and len(common.PUBLIC_GATES)==4,'current exact gate inventory is incomplete')
need({n.rsplit('::',1)[-1] for t,n in common.REGION_GATES if 'loop_break_body_tests' in n}==set(test_names(l4)),
     'Loop4 exact gate list does not match all current tests')
need({n.rsplit('::',1)[-1] for t,n in common.REGION_GATES if 'loop5_return_tail_tests' in n}==set(test_names(l5)),
     'Loop5 exact gate list does not match all current tests')
need(all(n.startswith('region::finite_loop_catch_tests::loop5_return_tail_tests::') for t,n in common.REGION_GATES if 'loop5_return_tail_tests' in n),
     'Loop5 exact gate identities omit the enclosing finite_loop_catch_tests module')
need(all(t=='jarde_java' for t,n in common.REGION_GATES),'Region gates must bind jarde_java exact target')
need(all(test in public_path.read_text(encoding='utf-8') for target,test in common.PUBLIC_GATES),
     'public exact gate missing from source')
need(tuple(common.CI_SOURCE_ADDITIONS)==(
    'crates/jarde-java/src/region/loop_break_body_tests.rs',
    'crates/jarde-java/src/region/loop5_return_tail_tests.rs',
    'tests/recover_loop45_original_public.rs',
    'crates/jarde-java/src/build/tests/loop5_catch_binding_tests.rs'),'CI source inventory omits a required shared test source')

builder_gates=[{'target':t,'test':n} for t,n in common.DEFERRED_BUILDER_GATES]
need(len(builder_gates)==3 and all(t=='jarde_java' and n.startswith('build::tests::loop5_catch_binding_tests::') for t,n in common.DEFERRED_BUILDER_GATES),
     'deferred builder exact identities changed')
need(all(g not in [{'target':t,'test':n} for t,n in common.REGION_GATES] for g in builder_gates),
     'deferred builder gates were incorrectly promoted into current Region gates')
need(common.DEFERRED_BUILDER_SOURCE=='crates/jarde-java/src/build/tests/loop5_catch_binding_tests.rs',
     'deferred builder source path changed')
builder_source_exists=builder_source.is_file() and not builder_source.is_symlink()
if builder_source_exists:
    need(set(test_names(builder_source))=={n.rsplit('::',1)[-1] for t,n in common.DEFERRED_BUILDER_GATES},
         'integrated builder child test functions differ from deferred gate inventory')
else:
    builder_source_status='prepared_not_executed_shared_child_missing'


native_text=(OUT/'verify-native-loop45.py').read_text(encoding='utf-8')
need('common.REGION_GATES' in native_text and 'common.PUBLIC_GATES' in native_text and 'args.extra_critical' in native_text,
     'native adapter does not include current exact gates and extras')
collector=(OUT/'collect-own-ci-loop45.py').read_text(encoding='utf-8')
ci=(OUT/'verify-own-ci-loop45.py').read_text(encoding='utf-8')
need('common.extend_ci_inventory(old)' in collector and 'common.extend_ci_inventory(old)' in ci,
     'CI collector/verifier lack shared source/fixture inventory extension')
need('named_outcome_counter' in ci and 'compare_seed_counters' in ci and 'Counter(triples)' in ci,
     'CI wrapper does not compare complete target/testname/status Counter')
need('target_summaries' in ci and 'full_counter_sha256' in ci,
     'CI wrapper omitted inherited summaries or full Counter evidence')
need('old.official_step_logs' in ci and 'acceptance-argv.json' in ci,
     'CI verifier omitted inherited official-log/argv binding')

# Exercise the actual v2 outcome parser on synthetic Cargo text. The swapped statuses
# retain identical target summary totals but must differ in full triplet Counter.
ci_spec=importlib.util.spec_from_file_location('loop45_ci_static',OUT/'verify-own-ci-loop45.py')
ci_mod=importlib.util.module_from_spec(ci_spec); ci_spec.loader.exec_module(ci_mod)
frozen=common.load_pinned('verify-own-ci.py','loop45_frozen_ci_static')
def sample(second):
    rows=[('alpha','ok'),('beta','ignored')] if not second else [('alpha','ignored'),('beta','ok')]
    return '\n'.join([
      'PROPTEST_RNG_SEED: "5350648285461741569"',
      'Running jarde_java (/tmp/jarde_java-0123456789abcdef)',
      'running 2 tests',
      f'test region::sample::{rows[0][0]} ... {rows[0][1]}',
      f'test region::sample::{rows[1][0]} ... {rows[1][1]}' + (', ignored by design' if rows[1][1]=='ignored' else ''),
      'test result: ok. 1 passed; 0 failed; 1 ignored; 0 measured; 0 filtered out',
    ])
left=ci_mod.named_outcome_counter(frozen,sample(False))
right=ci_mod.named_outcome_counter(frozen,sample(True))
need(sum(left.values())==sum(right.values())==2,'synthetic Counter outcome count mismatch')
need(left!=right,'full Counter self-test did not detect swapped named statuses')
try:
    ci_mod.compare_seed_counters(left,right)
except ValueError:
    pass
else:
    raise SystemExit('full Counter comparison accepted different (target,test,status) multisets')
# Same complete Counter must be accepted.
ci_mod.compare_seed_counters(left,ci_mod.named_outcome_counter(frozen,sample(False)))

plan=json.loads((OUT/'command-plan.json').read_text(encoding='utf-8'))
need(plan['verify_native'][2]==str(OUT/'verify-native-loop45.py') and plan['collect_ci'][2]==str(OUT/'collect-own-ci-loop45.py') and plan['verify_ci'][2]==str(OUT/'verify-own-ci-loop45.py'), 'command plan points outside v3 adapters')
required_builder_extra=[f'{target}={test}' for target,test in common.DEFERRED_BUILDER_GATES]
need(plan['required_final_builder_extra_critical']==required_builder_extra
     and json.loads((OUT/'acceptance-argv.json').read_text())['final_builder_extra_critical']==required_builder_extra,
     'final builder --extra-critical identities are incomplete')
for key in ('verify_native','verify_ci'):
    args=plan[key]
    actual=[args[i+1] for i,token in enumerate(args[:-1]) if token=='--extra-critical']
    need(actual==required_builder_extra,f'{key} does not pass all deferred builder gates as repeated exact flags')
need(plan['status']=='prepared_not_executed','plan must remain unexecuted')
need(plan['inheritance']['preserved_native_gate_count']==78 and plan['inheritance']['preserved_ci_gate_count']==123,
     'inherited gate counts changed')
need(plan['region_gate_inventory']['currently_integrated_loop4_count']==5
     and plan['region_gate_inventory']['currently_integrated_loop5_count']==6
     and plan['region_gate_inventory']['currently_integrated_total']==11,
     'dynamic current Region inventory changed')
need(plan['region_gate_inventory']['deferred_builder_source']==common.DEFERRED_BUILDER_SOURCE
     and plan['region_gate_inventory']['deferred_builder_gates']==builder_gates,
     'deferred builder gates/source are not represented accurately')
need('extra-critical' in plan['region_gate_inventory']['future_extra_supported_by_repeated_flag'],
     'future exact gates are not supported')
need(set(plan['not_run'])=={'native acceptance','own-CI acceptance','Cargo','JDK','CLI','Git','network'},
     'non-execution record incomplete')
fixture_roots=[ROOT/rel for rel in common.CI_FIXTURE_ROOT_ADDITIONS]
need(all(x.is_dir() and not x.is_symlink() for x in fixture_roots),'fixture roots missing/unsafe')
fixture_files=[p for root in fixture_roots for p in root.rglob('*') if p.is_file()]
need(fixture_files and all(not p.is_symlink() for p in fixture_files),'recursive fixture inventory empty/unsafe')
print(json.dumps({'status':'static_preparation_checks_passed','native_inherited_gates':78,
 'ci_inherited_gates':123,'current_loop4_region_gates':5,'current_loop5_region_gates':6,
 'current_region_gates':11,'public_gates':4,'deferred_builder_gates':builder_gates,
 'deferred_builder_source_status': 'present_and_name_checked' if builder_source_exists else 'prepared_not_executed_shared_child_missing',
 'ci_full_counter_selftest':'passed','fixture_files_seen_now':len(fixture_files),
 'runtime_acceptance':'not run'},ensure_ascii=False))
