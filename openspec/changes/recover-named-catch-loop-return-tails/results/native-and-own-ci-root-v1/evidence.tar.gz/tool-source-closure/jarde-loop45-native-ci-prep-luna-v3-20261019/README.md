# Loop45 native and own-CI acceptance preparation v3

This private adapter reuses the accepted Loop2 native/CI collectors, verifiers, official ZIP parser, and product binder by exact SHA pins. The frozen Loop2 base, Loop45 prep v1, and closed Loop45 prep v2 remain unchanged. No acceptance or toolchain was run.

The adapter preserves 78 inherited native gates and 123 inherited CI gates, adds currently integrated exact gates (5 Loop4 Region tests, 6 Loop5 Region tests, and 4 public class-source tests), and accepts repeated --extra-critical TARGET=FULL_TEST_NAME values for finalized gates. Current formulas: 78 + 11 current region + 4 public + deferred builder extras native; 123 + 11 current region + 4 public + deferred builder extras CI.

The shared loop5_return_tail_tests.rs currently contains six tests; all six exact full module paths are included among current Region gates. The builder work is separate: its shared child source crates/jarde-java/src/build/tests/loop5_catch_binding_tests.rs is not currently integrated. Its three exact jarde_java build::tests::loop5_catch_binding_tests gates are recorded as deferred, remain outside built-in REGION_GATES, and must be supplied as repeated --extra-critical only after the file is integrated and bound. Static verification explicitly reports the missing child source as prepared-not-executed; the collector cannot produce a valid source-bound CI receipt until that shared file is integrated.

The CI verifier checks inherited 123 gates, official step ZIP and live source binding, all supplemental exact gates once per seed, target inventories and summaries, and a separate Counter containing every parsed (target, testname, status) outcome for both fixed seeds. It compares complete Counters, including ignored and failed statuses, rather than relying on aggregate target summaries. The report records the number and SHA-256 of the Counter.

The collector recursively inventories the two frozen fixture roots and adds both Region test sources, tests/recover_loop45_original_public.rs, and the deferred builder child source path. Existing source and fixture Git-blob/live-byte checks, successful run binding, fixed seeds, 5 GiB free-space requirement, 1 GiB target bound, default stack/environment behavior, and cleanup rules are inherited unchanged.

static_verify.py uses Python -B only: AST checks, exact gate/source checks, frozen artifact hash checks, fixture inventory checks, and a synthetic full-Counter mismatch self-test. It does not run Cargo, JDK, CLI, Git, or network.


The six L5 tests are nested under finite_loop_catch_tests::loop5_return_tail_tests in the Rust module tree; current exact gate identities include the full module path. The private builder candidate is not a shared source and does not count as an integrated gate.
