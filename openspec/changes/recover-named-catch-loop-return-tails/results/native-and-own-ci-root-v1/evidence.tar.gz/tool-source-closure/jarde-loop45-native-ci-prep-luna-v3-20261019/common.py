"""Process-local adapters over the accepted Loop2 native/CI preparation."""
from __future__ import annotations
import hashlib
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASE = Path('/private/tmp/jarde-loop2-retry-native-ci-prep-luna-v2-20261019')
BASE_PINS = {
    'verify-native.py': '7d67c4d679f2fb21c6ac7a821f3a24ad4b6bf3ec9b6a4de7690916fa86d4a4b1',
    'verify-own-ci.py': 'd45ac260085595f0d15402fc0baf5ee504d48b02c139e7950fd80f4e77d1d8b5',
    'collect-own-ci.py': '82cd49ef71c7805e9d5e51346439782c53d3c6ecdf155bc9ee31f6ae67648482',
    'collect-official-logs.py': '99e6fc29ad9b00ed348631aa49b880651a42edcba890195b5b1a33d4f9ae60ef',
    'bind_product_one.py': '59ef3f1b42e713ca334e8ae9dc1e87ccdf4aef829e3a2c0a041d722463bbdcc0',
    'verify_workspace.py': '8321198c09133aad60d8591b1d3e8f4c849420c4b3a37c1bc4c4aa12129d9830',
    'inherited/ancestor-iterator-verify-native.py': '6ed9fda0ab467c191747365bbe4cea6e084e1053be9bc2eddc28ab3c4fc231c9',
    'acceptance-argv.json': 'c324c6b205e7a2eda920613a48ca7891e82f1218f5829c716e5c56b464662741',
}
CI_SOURCE_ADDITIONS = (
    'crates/jarde-java/src/region/loop_break_body_tests.rs',
    'crates/jarde-java/src/region/loop5_return_tail_tests.rs',
    'tests/recover_loop45_original_public.rs',
    'crates/jarde-java/src/build/tests/loop5_catch_binding_tests.rs',
)
CI_FIXTURE_ROOT_ADDITIONS = (
    'tests/fixtures/recover-proved-loop-break-branch-bodies',
    'tests/fixtures/recover-named-catch-loop-return-tails',
)
REGION_GATES = (
    ('jarde_java', 'region::loop_break_body_tests::reader_recovers_complete_loop4_body_for_both_debug_profiles'),
    ('jarde_java', 'region::loop_break_body_tests::reader_proof_owns_only_the_closed_route_and_refuses_occupied_or_scoped_candidates'),
    ('jarde_java', 'region::loop_break_body_tests::reader_late_implicit_latch_stop_restores_trial_state_without_refunding_usage'),
    ('jarde_java', 'region::loop_break_body_tests::edge_gate_rejects_external_entries_extra_exits_exceptions_and_cycles'),
    ('jarde_java', 'region::loop_break_body_tests::comparison_gate_refuses_switch_and_budget_or_cancellation_stays_a_stop'),
    ('jarde_java', 'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_return_tail_certificate_accepts_the_frozen_boundary_return'),
    ('jarde_java', 'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_return_tail_certificate_refuses_drift_duplicate_owners_and_stops_cleanly'),
    ('jarde_java', 'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_try_level_candidate_refusal_restores_tentative_owners'),
    ('jarde_java', 'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_try_level_late_analysis_stop_restores_candidate_checkpoint'),
    ('jarde_java', 'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_full_try_owns_prefix_loop_and_return_tail_after_loop4_proof'),
    ('jarde_java', 'region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_named_break_body_proof_binds_one_row_and_rejects_scope_drift'),
)
DEFERRED_BUILDER_SOURCE = 'crates/jarde-java/src/build/tests/loop5_catch_binding_tests.rs'
DEFERRED_BUILDER_GATES = (
    ('jarde_java', 'build::tests::loop5_catch_binding_tests::loop5_handler_entry_phi_does_not_conflict_with_reused_double_slot'),
    ('jarde_java', 'build::tests::loop5_catch_binding_tests::loop5_catch_binding_requires_exact_path_handler_slot_and_stack_zero_phi'),
    ('jarde_java', 'build::tests::loop5_catch_binding_tests::loop5_catch_binding_propagates_budget_and_cancellation_stops'),
)
PUBLIC_GATES = (
    ('recover_loop45_original_public', 'original_loop4_debug_and_no_debug_class_and_full_jar_keep_structured_conditional_break_body'),
    ('recover_loop45_original_public', 'original_loop4_public_class_source_propagates_precancellation_without_partial_text'),
    ('recover_loop45_original_public', 'original_loop5_debug_and_no_debug_class_and_full_jar_keep_named_catch_return_tail'),
    ('recover_loop45_original_public', 'original_loop5_public_class_source_propagates_precancellation_without_partial_text'),
)
def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()
def load_pinned(relative: str, module_name: str):
    path = BASE / relative
    expected = BASE_PINS[relative]
    if not path.is_file() or path.is_symlink() or sha(path) != expected:
        raise RuntimeError(f'frozen base changed: {relative}')
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load frozen base: {relative}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
def extend_ci_inventory(module):
    module.SOURCE_PATHS = tuple(dict.fromkeys((*module.SOURCE_PATHS, *CI_SOURCE_ADDITIONS)))
    roots = tuple(dict.fromkeys((*module.FIXTURE_ROOTS, *CI_FIXTURE_ROOT_ADDITIONS)))
    module.FIXTURE_ROOTS = roots
    discovered = set(module.EXPECTED_FIXTURE_FILES)
    old_expected = set(discovered)
    for rel in CI_FIXTURE_ROOT_ADDITIONS:
        root = ROOT / rel
        if not root.is_dir() or root.is_symlink():
            raise RuntimeError(f'new frozen fixture root missing/unsafe: {rel}')
        for path in root.rglob('*'):
            if path.is_symlink():
                raise RuntimeError(f'symlink in recursively pinned fixture root: {path}')
            if path.is_file():
                discovered.add(path.relative_to(ROOT).as_posix())
    module.EXPECTED_FIXTURE_FILES = tuple(sorted(discovered))
    return {'source_paths': list(module.SOURCE_PATHS), 'fixture_roots': list(module.FIXTURE_ROOTS),
            'new_fixture_paths': sorted(discovered - old_expected)}
