#!/usr/bin/env python3
"""Static-only audit of private Loop45 native/CI adapters and two-seed outcome Counter."""
from __future__ import annotations
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from collections import Counter

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASE = Path('/private/tmp/jarde-loop2-retry-native-ci-prep-luna-v2-20261019')
V1 = Path('/private/tmp/jarde-loop45-native-ci-prep-luna-v1-20261019')

def need(ok: bool, reason: str) -> None:
    if not ok:
        raise SystemExit(reason)

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

for name in ('common.py','verify-native-loop45.py','collect-own-ci-loop45.py',
             'verify-own-ci-loop45.py','static_verify.py'):
    path=OUT/name
    need(path.is_file() and not path.is_symlink(),f'missing private adapter: {name}')
    ast.parse(path.read_text(encoding='utf-8'),filename=str(path))

tree=ast.parse((OUT/'common.py').read_text(encoding='utf-8'))
base_pins=next(ast.literal_eval(n.value) for n in tree.body
               if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BASE_PINS' for t in n.targets))
for rel,digest in base_pins.items():
    path=BASE/rel
    need(path.is_file() and not path.is_symlink() and sha(path)==digest,f'frozen accepted base changed: {rel}')
v1_manifest=json.loads((OUT/'pins.json').read_text(encoding='utf-8'))
for item in v1_manifest['v1_files']:
    path=Path(item['path'])
    need(path.is_file() and path.stat().st_size==item['bytes'] and sha(path)==item['sha256'],
         f'Loop45 v1 input changed: {path}')
base_review=json.loads((BASE/'static-review.json').read_text(encoding='utf-8'))
need(base_review['native_exact_gate_count']==78 and base_review['ci_exact_gate_count']==123,
     'accepted base gate inventory is not 78 native / 123 CI')
base_argv=json.loads((BASE/'acceptance-argv.json').read_text(encoding='utf-8'))
extras=[base_argv['verify_ci'][i+1] for i,token in enumerate(base_argv['verify_ci'][:-1]) if token=='--extra-critical']
need(len(extras)==13,'inherited CI argument inventory changed')
argv=json.loads((OUT/'acceptance-argv.json').read_text(encoding='utf-8'))
need(argv['fixed_ci_extra_critical']==extras,'recorded inherited CI identities changed')
need(argv['ci_fixed_seeds']==['5350648285461741569','5350648285461741570'],'fixed seeds changed')

l4=ROOT/'crates/jarde-java/src/region/loop_break_body_tests.rs'
l5=ROOT/'crates/jarde-java/src/region/loop5_return_tail_tests.rs'
public_path=ROOT/'tests/recover_loop45_original_public.rs'
def test_names(path):
    s=path.read_text(encoding='utf-8')
    import re
    return re.findall(r'(?m)^\s*#\[test\]\s*(?:#\[ignore[^\n]*\]\s*)?\s*fn\s+(\w+)\s*\(',s)
need(len(test_names(l4))==5 and len(test_names(l5))==5,'integrated Loop4/Loop5 test counts differ from current source')
need(len(test_names(public_path))==4,'public exact test count differs from current source')
common_spec=importlib.util.spec_from_file_location('loop45_common_static',OUT/'common.py')
common=importlib.util.module_from_spec(common_spec); common_spec.loader.exec_module(common)
need(len(common.REGION_GATES)==10 and len(common.PUBLIC_GATES)==4,'current exact gate inventory is incomplete')
need({n.rsplit('::',1)[-1] for t,n in common.REGION_GATES if 'loop_break_body_tests' in n}==set(test_names(l4)),
     'Loop4 exact gate list does not match all current tests')
need({n.rsplit('::',1)[-1] for t,n in common.REGION_GATES if 'loop5_return_tail_tests' in n}==set(test_names(l5)),
     'Loop5 exact gate list does not match all current tests')
need(all(t=='jarde_java' for t,n in common.REGION_GATES),'Region gates must bind jarde_java exact target')
need(all(test in public_path.read_text(encoding='utf-8') for target,test in common.PUBLIC_GATES),
     'public exact gate missing from source')
need(tuple(common.CI_SOURCE_ADDITIONS)==(
    'crates/jarde-java/src/region/loop_break_body_tests.rs',
    'crates/jarde-java/src/region/loop5_return_tail_tests.rs',
    'tests/recover_loop45_original_public.rs'),'CI source inventory omits a required shared test source')

deferred=argv['deferred_final_loop5_extra']
need(deferred['target']=='jarde_java' and deferred['test']=='region::finite_loop_catch_tests::loop5_return_tail_tests::loop5_named_break_body_proof_binds_one_row_and_rejects_scope_drift',
     'deferred sixth Loop5 identity changed')
need('not yet integrated' in deferred['status'],'deferred gate is incorrectly claimed as current')

native_text=(OUT/'verify-native-loop45.py').read_text(encoding='utf-8')
need('common.REGION_GATES' in native_text and 'common.PUBLIC_GATES' in native_text and 'args.extra_critical' in native_text,
     'native adapter does not include current exact gates and extras')
collector=(OUT/'collect-own-ci-loop45.py').read_text(encoding='utf-8')
ci=(OUT/'verify-own-ci-loop45.py').read_text(encoding='utf-8')
need('common.extend_ci_inventory(old)' in collector and 'common.extend_ci_inventory(old)' in ci,
     'CI collector/verifier lack shared source/fixture inventory extension')
need('named_outcome_counter' in ci and 'compare_seed_counters' in ci and 'Counter(triples)' in ci,
     'CI wrapper does not compare complete target/testname/status Counter')
need('target_summaries' in ci and 'full_counter_sha256' in ci,
     'CI wrapper omitted inherited summaries or full Counter evidence')
need('old.official_step_logs' in ci and 'acceptance-argv.json' in ci,
     'CI verifier omitted inherited official-log/argv binding')

# Exercise the actual v2 outcome parser on synthetic Cargo text. The swapped statuses
# retain identical target summary totals but must differ in full triplet Counter.
ci_spec=importlib.util.spec_from_file_location('loop45_ci_static',OUT/'verify-own-ci-loop45.py')
ci_mod=importlib.util.module_from_spec(ci_spec); ci_spec.loader.exec_module(ci_mod)
frozen=common.load_pinned('verify-own-ci.py','loop45_frozen_ci_static')
def sample(second):
    rows=[('alpha','ok'),('beta','ignored')] if not second else [('alpha','ignored'),('beta','ok')]
    return '\n'.join([
      'PROPTEST_RNG_SEED: "5350648285461741569"',
      'Running jarde_java (/tmp/jarde_java-0123456789abcdef)',
      'running 2 tests',
      f'test region::sample::{rows[0][0]} ... {rows[0][1]}',
      f'test region::sample::{rows[1][0]} ... {rows[1][1]}' + (', ignored by design' if rows[1][1]=='ignored' else ''),
      'test result: ok. 1 passed; 0 failed; 1 ignored; 0 measured; 0 filtered out',
    ])
left=ci_mod.named_outcome_counter(frozen,sample(False))
right=ci_mod.named_outcome_counter(frozen,sample(True))
need(sum(left.values())==sum(right.values())==2,'synthetic Counter outcome count mismatch')
need(left!=right,'full Counter self-test did not detect swapped named statuses')
try:
    ci_mod.compare_seed_counters(left,right)
except ValueError:
    pass
else:
    raise SystemExit('full Counter comparison accepted different (target,test,status) multisets')
# Same complete Counter must be accepted.
ci_mod.compare_seed_counters(left,ci_mod.named_outcome_counter(frozen,sample(False)))

plan=json.loads((OUT/'command-plan.json').read_text(encoding='utf-8'))
need(plan['verify_native'][2]==str(OUT/'verify-native-loop45.py') and plan['collect_ci'][2]==str(OUT/'collect-own-ci-loop45.py') and plan['verify_ci'][2]==str(OUT/'verify-own-ci-loop45.py'), 'command plan points outside v2 adapters')
need(plan['status']=='prepared_not_executed','plan must remain unexecuted')
need(plan['inheritance']['preserved_native_gate_count']==78 and plan['inheritance']['preserved_ci_gate_count']==123,
     'inherited gate counts changed')
need(plan['region_gate_inventory']['currently_integrated_loop4_count']==5
     and plan['region_gate_inventory']['currently_integrated_loop5_count']==5,
     'dynamic current Region inventory changed')
need('extra-critical' in plan['region_gate_inventory']['future_extra_supported_by_repeated_flag'],
     'future exact gates are not supported')
need(set(plan['not_run'])=={'native acceptance','own-CI acceptance','Cargo','JDK','CLI','Git','network'},
     'non-execution record incomplete')
fixture_roots=[ROOT/rel for rel in common.CI_FIXTURE_ROOT_ADDITIONS]
need(all(x.is_dir() and not x.is_symlink() for x in fixture_roots),'fixture roots missing/unsafe')
fixture_files=[p for root in fixture_roots for p in root.rglob('*') if p.is_file()]
need(fixture_files and all(not p.is_symlink() for p in fixture_files),'recursive fixture inventory empty/unsafe')
print(json.dumps({'status':'static_preparation_checks_passed','native_inherited_gates':78,
 'ci_inherited_gates':123,'current_loop4_region_gates':5,'current_loop5_region_gates':5,
 'public_gates':4,'deferred_final_loop5_extra':deferred,'ci_full_counter_selftest':'passed',
 'fixture_files_seen_now':len(fixture_files),'runtime_acceptance':'not run'},ensure_ascii=False))
