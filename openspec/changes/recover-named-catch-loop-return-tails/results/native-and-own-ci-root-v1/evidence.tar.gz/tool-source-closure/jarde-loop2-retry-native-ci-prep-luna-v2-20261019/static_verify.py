#!/usr/bin/env python3
"""Static-only audit of the prepared Loop2 native/CI acceptance bundle."""
from __future__ import annotations
import ast
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
OLD = Path('/private/tmp/jarde-loop-header-body-boundary-own-ci-prep-luna-v1-20261019')
BASE_GATES = {
    ('jarde_java', 'region::finite_loop_catch_tests::loop2_original_retry_tree_has_exact_four_owner_retry_shape_debug_and_nodebug'),
    ('jarde_java', 'region::finite_loop_catch_tests::loop2_retry_proof_used_minus_one_and_precancel_are_atomic'),
    ('jarde_java', 'region::finite_loop_catch_tests::loop2_retry_proof_refuses_mutated_range_shared_rows_wrong_transfer_and_nonthrow_leaf'),
    ('p3_branching_catch_retry', 'original_loop2_debug_and_no_debug_default_and_all_keep_the_full_structured_retry_class'),
}
EDGE_GATES = {
    ('jarde_java', 'region::finite_loop_catch_tests::loop2_real_reader_graphs_reject_external_entries_wrong_targets_return_leaf_and_shared_rows'),
    ('jarde_java', 'region::finite_loop_catch_tests::loop2_late_region_budget_stop_does_not_publish_a_partial_retry_loop'),
    ('p3_branching_catch_retry', 'reachable_retry_controls_keep_both_polarities_and_full_methods_for_all_compiler_profiles'),
}
GATES = BASE_GATES | EDGE_GATES
FILES = ('verify-native.py', 'verify-own-ci.py', 'collect-own-ci.py', 'collect-official-logs.py',
         'bind_product_one.py', 'verify_workspace.py', 'inherited/ancestor-iterator-verify-native.py')
def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()
def need(ok: bool, reason: str) -> None:
    if not ok:
        raise SystemExit(reason)

for rel in FILES:
    path = OUT / rel
    need(path.is_file() and not path.is_symlink(), f'missing prepared file: {rel}')
    ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
for rel in ('verify_workspace.py', 'inherited/ancestor-iterator-verify-native.py',
            'collect-official-logs.py', 'bind_product_one.py'):
    need(sha(OUT / rel) == sha(OLD / rel), f'inherited accepted tool changed: {rel}')

native = ast.parse((OUT / 'verify-native.py').read_text(encoding='utf-8'))
ci = ast.parse((OUT / 'verify-own-ci.py').read_text(encoding='utf-8'))
collector = ast.parse((OUT / 'collect-own-ci.py').read_text(encoding='utf-8'))
def top_level_assignments(tree):
    found = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    found[target.id] = node.value
    return found
def assigned(tree, name):
    value = None
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            value = ast.literal_eval(node.value)
        elif isinstance(node, ast.AugAssign) and isinstance(node.target, ast.Name) and node.target.id == name:
            value = value + ast.literal_eval(node.value)
    if value is None:
        raise SystemExit(f'missing AST assignment {name}')
    return value
native_gate_rows = assigned(native, 'LOOP2_RETRY_GATES')
need({tuple(x) for x in native_gate_rows} == BASE_GATES and len(native_gate_rows) == 4, 'native Loop2 base gates differ')
native_edge_rows = assigned(native, 'LOOP2_RETRY_EDGE_GATES')
need({tuple(x) for x in native_edge_rows} == EDGE_GATES and len(native_edge_rows) == 3, 'native Loop2 edge gates differ')
ci_rows = assigned(ci, 'LOOP2_RETRY_CRITICAL_TESTS')
need({(v[1], v[0]) for v in ci_rows.values()} == BASE_GATES and len(ci_rows) == 4, 'CI Loop2 base gates differ')
ci_edge_rows = assigned(ci, 'LOOP2_RETRY_EDGE_CRITICAL_TESTS')
need({(v[1], v[0]) for v in ci_edge_rows.values()} == EDGE_GATES and len(ci_edge_rows) == 3, 'CI Loop2 edge gates differ')
for tree, label in ((ci, 'verify-own-ci.py'), (collector, 'collect-own-ci.py')):
    source_paths = assigned(tree, 'SOURCE_PATHS')
    need('crates/jarde-java/src/region/finite_loop_catch_tests.rs' in source_paths,
         f'{label} omits finite-loop test source pin')
    need('tests/p3_branching_catch_retry.rs' in source_paths, f'{label} omits public test source pin')
    roots = assigned(tree, 'FIXTURE_ROOTS')
    need('tests/fixtures/recover-branching-named-catch-retry-loops' in roots,
         f'{label} omits Loop2 fixture root')
    code = (OUT / label).read_text(encoding='utf-8')
    need("(ROOT / FIXTURE_ROOTS[-1]).rglob('*')" in code,
         f'{label} does not dynamically include future files under the Loop2 fixture root')

fixture_root = ROOT / 'tests/fixtures/recover-branching-named-catch-retry-loops'
fixture_files = sorted(p for p in fixture_root.rglob('*') if p.is_file() and not p.is_symlink())
for target, test in GATES:
    source = ROOT / ('crates/jarde-java/src/region/finite_loop_catch_tests.rs' if target == 'jarde_java' else 'tests/p3_branching_catch_retry.rs')
    need(source.is_file() and test.rsplit('::', 1)[-1] in source.read_text(encoding='utf-8'),
         f'exact gate source identity missing: {target}::{test}')
need(fixture_root.is_dir(), 'Loop2 fixture root missing')
need(sum(p.suffix == '.class' for p in fixture_files) >= 10, 'Loop2 fixture class matrix incomplete')
need(sum(p.suffix == '.java' for p in fixture_files) >= 3, 'Loop2 fixture Java sources incomplete')
need((fixture_root / 'README.md').is_file(), 'Loop2 fixture README missing')
need((fixture_root / 'licenses/JADX-LICENSE').is_file() and (fixture_root / 'licenses/JADX-NOTICE').is_file(), 'Loop2 source license files missing')
for case in ('duplicate-physical-handler-row', 'external-normal-entry-to-retry-leaf', 'retry-throw-leaf-returns', 'wrong-retry-target'):
    need(any(f'/rejections/{case}/' in '/' + p.relative_to(fixture_root).as_posix() for p in fixture_files), f'missing refusal fixture: {case}')
need(all(p.relative_to(ROOT).as_posix() in (OUT / 'verify-own-ci.py').read_text(encoding='utf-8')
         or "(ROOT / FIXTURE_ROOTS[-1]).rglob('*')" in (OUT / 'verify-own-ci.py').read_text(encoding='utf-8')
         for p in fixture_files), 'fixture inventory is not covered by exact-plus-dynamic pinning')

acceptance = json.loads((OUT / 'acceptance-argv.json').read_text(encoding='utf-8'))
args = acceptance['verify_ci']
extras = [args[i+1] for i, token in enumerate(args[:-1]) if token == '--extra-critical']
need(len(extras) == 13, 'accepted 13 extra-critical identities were not preserved')
# Compute gate inventories from native list literals and CI dictionary/update literals.
native_assign = top_level_assignments(native)
inherited_tree = ast.parse((OUT / 'inherited/ancestor-iterator-verify-native.py').read_text(encoding='utf-8'))
inherited_assign = top_level_assignments(inherited_tree)
base_native = len(ast.literal_eval(inherited_assign['GATES']))
native_names = ('HISTORICAL_OBJECT_ARGUMENT_GATES', 'CURRENT_GATES', 'ENTRY_SPLIT_GATES',
                'IF_LOOP_ENTRY_GATES', 'LITERAL_BOOLEAN_GATES', 'CONTINUE_LADDER_GATES',
                'ARRAY_SUBTRACT_GATES', 'POST_TEST_LOOP_BREAK_GATES',
                'COMPLEX_IF_BODY_BOUNDARY_GATES', 'LOOP2_RETRY_GATES', 'LOOP2_RETRY_EDGE_GATES')
native_count = base_native + sum(len(ast.literal_eval(native_assign[name])) for name in native_names)
ci_assign = top_level_assignments(ci)
base_ci = next(len(node.value.keys) for node in ci.body if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'CRITICAL_TESTS' for t in node.targets) and isinstance(node.value, ast.Dict))
ci_updates = []
for node in ast.walk(ci):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == 'CRITICAL_TESTS' and node.func.attr == 'update':
        item = node.args[0]
        if isinstance(item, ast.Name):
            ci_updates.append(len(ast.literal_eval(ci_assign[item.id])))
        elif isinstance(item, ast.Dict):
            ci_updates.append(len(item.keys))
ci_builtin_count = base_ci + sum(ci_updates)
need(base_native == 18 and native_count == 78 and native_count - len(GATES) == 71,
     f'native inventory did not compute to 78 (base={base_native}, total={native_count})')
need(ci_builtin_count == 110 and ci_builtin_count - len(GATES) == 103,
     f'CI built-in inventory did not compute to 110 (total={ci_builtin_count})')
need(acceptance['expected_native_critical_gate_count'] == native_count and
     acceptance['expected_ci_exact_gate_count'] == ci_builtin_count + len(extras),
     'acceptance inventory differs from AST-computed gate counts')
need('collect-official-logs.py' in ' '.join(acceptance['collect_official_step_zip']), 'official per-step ZIP command missing')
need(acceptance['expected_native_critical_gate_count'] == 78 and acceptance['expected_ci_exact_gate_count'] == 123, 'exact gate inventory does not retain old gates plus four additions')
need(not any('pass' in k.lower() or 'workspace' in k.lower() for k in acceptance.get('exact_named_gate_inventory', {})), 'runtime pass/target totals must not be fixed')
need('workspace_totals' in (OUT / 'verify-native.py').read_text(encoding='utf-8') and
     'target_count' in (OUT / 'verify-own-ci.py').read_text(encoding='utf-8'),
     'runtime counts are not reported from receipts')
need('aggregate_step_proofs' in (OUT / 'verify-own-ci.py').read_text(encoding='utf-8') and
     'DERIVED_STEP_PROOFS = []' in (OUT / 'verify-own-ci.py').read_text(encoding='utf-8'),
     'official per-step ZIP must remain non-aggregate')

print(json.dumps({'status': 'static_preparation_checks_passed', 'native_gate_count': native_count, 'ci_builtin_gate_count': ci_builtin_count,
                  'ci_extra_critical_count': len(extras), 'ci_gate_count': ci_builtin_count + len(extras),
                  'native_added_gates': len(GATES), 'ci_added_gates': len(GATES),
                  'fixture_files_seen_now': len(fixture_files),
                  'fixture_discovery': 'dynamic recursive source binding includes later refusal fixtures',
                  'inherited_acceptance_tool_count': len(FILES)}, ensure_ascii=False))
