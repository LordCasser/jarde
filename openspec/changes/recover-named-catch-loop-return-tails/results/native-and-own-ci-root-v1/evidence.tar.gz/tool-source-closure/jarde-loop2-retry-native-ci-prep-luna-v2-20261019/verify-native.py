#!/usr/bin/env python3
"""Check one native workspace receipt against inherited and current leaf gates."""
import argparse, hashlib, importlib.util, json, sys
from pathlib import Path
sys.dont_write_bytecode = True
BASE = Path(__file__).with_name('verify_workspace.py')
BASE_SHA = '8321198c09133aad60d8591b1d3e8f4c849420c4b3a37c1bc4c4aa12129d9830'
INHERITED_WRAPPER = Path(__file__).parent / 'inherited/ancestor-iterator-verify-native.py'
INHERITED_WRAPPER_SHA = '6ed9fda0ab467c191747365bbe4cea6e084e1053be9bc2eddc28ab3c4fc231c9'
HISTORICAL_OBJECT_ARGUMENT_GATES = [
 ('jarde', 'facade::generic_list_foreach_binding_slot_closed_tests::optional_remove_argument_break_leaves_required_list_proof_and_equals_edit'),
 ('jarde', 'facade::generic_list_foreach_binding_slot_closed_tests::unmatched_optional_equals_key_does_not_hide_valid_calls'),
]
CURRENT_GATES = [
 ('jarde_java', 'report::exact_cast_call_batch_tests::iterative_batch_proves_multiple_get_cast_children_and_rejects_mutations'),
 ('jarde', 'facade::generic_list_foreach_binding_slot_closed_tests::generic_list_indexed_get_keeps_its_exact_single_cast_use_and_ast_child'),
 ('jarde', 'class_source::tests::complete_body_primitive_result_requires_exact_signature_and_descriptor_type'),
 ('jarde_java', 'report::exact_cast_call_batch_tests::iterative_batch_propagates_budget_and_cancellation_stops'),
 ('jarde_java', 'report::generic_void_parameter_census_tests::invoke_receiver_census_uses_consumed_stack_depth_not_stack_zero'),
 ('p3_iterable_foreach', 'subtype_owners_project_and_extra_next_or_iterator_escape_refuse'),
 ('p3_nested_loop_side_exits', 'indexed_list_parameter_signatures_require_exact_direct_get_cast_evidence'),
 ('p3_nested_loop_side_exits', 'indexed_list_parameter_primitive_result_must_match_signature_exactly'),
 ('recover_lambda_primitive_array_capture', 'the_primitive_array_capture_recovers_in_both_javac_legs'),
 ('recover_lambda_primitive_array_capture', 'the_multianewarray_capture_preserves_its_members_while_the_nested_helper_recovers'),
 ('jarde_reader', 'classfile::tests::repository_class_fixtures_validate_without_false_target_rejections'),
 ('jarde_java', 'build::tests::proved_loop_assignment_consumes_real_char_and_only_known_widenings'),
 ('p3_assignment_condition_widening', 'fixed_upstream_and_dynamic_controls_recover_the_widened_loop_condition'),
 ('p3_assignment_condition_widening', 'cancellation_does_not_publish_a_partial_condition_body'),
]
ENTRY_SPLIT_GATES = [
 ('jarde_java', 'region::tests::entry_split_region_proof_uses_real_ir_and_stops_before_publication'),
 ('p3_entry_split_int_loops', 'entry_split_integer_loop_accepts_signed_slot_and_polarity_variants'),
 ('p3_entry_split_int_loops', 'entry_split_controls_without_the_complete_int_proof_remain_quoted'),
 ('p3_entry_split_int_loops', 'entry_split_candidate_stops_do_not_publish_a_half_prefix'),
 ('p3_entry_split_int_loops', 'entry_split_topology_and_stack_controls_refuse_whole_methods'),
 ('p3_entry_split_int_loops', 'entry_split_legacy_subroutine_remains_outside_java8_proof'),
 ('p3_entry_split_int_loops', 'entry_split_exceptional_prefix_remains_whole_method_refusal'),
 ('p3_entry_split_int_loops', 'entry_split_analysis_request_can_omit_ssa_without_fabricating_that_stage'),
 ('p3_entry_split_int_loops', 'entry_split_accepts_nonzero_value_slot_and_counter_up'),
 ('p3_entry_split_int_loops', 'entry_split_output_byte_stops_hit_each_prefix_copy_without_publishing_text'),
 ('p3_entry_split_int_loops', 'entry_split_sourcemap_stop_keeps_the_complete_body_and_only_a_reliable_prefix'),
]


IF_LOOP_ENTRY_GATES = [
 ('jarde_java', 'build::tests::if_arm_nested_loop_entry_origin_uses_real_transfer_and_edge_facts'),
 ('p3_if_loop_entry_origins', 'if_loop_entry_origin_is_public_for_class_and_jar_inputs'),
 ('p3_if_loop_entry_origins', 'if_loop_entry_public_source_propagates_precancellation'),
]

LITERAL_BOOLEAN_GATES = [
 ('jarde_java', 'build::tests::literal_only_boolean_local_uses_the_real_read_phi_and_closes_the_full_access_census'),
 ('p3_proved_literal_boolean_locals', 'original_flag_is_boolean_through_class_and_plain_jar_default_and_all_profiles'),
 ('p3_proved_literal_boolean_locals', 'refusal_controls_keep_integer_consumers_and_reject_the_non_boolean_store'),
 ('p3_proved_literal_boolean_locals', 'pre_cancelled_public_class_source_does_not_publish_a_class_artifact'),
 ('p3_hoisted_boolean', 'a_literal_local_with_a_closed_boolean_return_is_declared_boolean'),
]

CONTINUE_LADDER_GATES = [
 ('jarde_java', 'region::tests::continue_ladder_joins_close_the_real_loop_and_stop_on_budget'),
 ('p3_continue_ladder_joins', 'original_debug_no_debug_class_and_plain_jar_share_the_public_source_contract'),
 ('p3_continue_ladder_joins', 'original_public_class_source_propagates_precancellation'),
]



ARRAY_SUBTRACT_GATES = [
 ('jarde_java', 'build::tests::proved_int_array_subtract_uses_real_ir_and_keeps_existing_boundaries'),
]

POST_TEST_LOOP_BREAK_GATES = [
 ('p3_post_test_loop_break_prefixes', 'original_profiles_and_plain_jars_share_the_public_post_test_break_contract'),
 ('p3_post_test_loop_break_prefixes', 'original_public_class_source_propagates_precancellation_without_partial_text'),
 ('jarde_java', 'region::tests::post_test_break_prefix_uses_real_ir_and_stops_without_partial_ownership'),
]

COMPLEX_IF_BODY_BOUNDARY_GATES = [
 ('jarde_java', 'region::and_body_boundary_tests::one_pure_header_keeps_the_existing_loop_route_and_owns_effectful_body'),
 ('jarde_java', 'region::and_body_boundary_tests::a_longer_pure_and_prefix_stops_before_the_effectful_body'),
 ('jarde_java', 'region::and_body_boundary_tests::the_existing_or_route_and_effectful_initial_tests_remain_unchanged'),
 ('jarde_java', 'region::and_body_boundary_tests::an_extra_real_bytecode_entry_does_not_become_a_body_boundary'),
 ('jarde_java', 'region::and_body_boundary_tests::only_the_exact_later_loop_statement_free_reason_can_select_the_body_boundary'),
 ('jarde_java', 'region::and_body_boundary_tests::stop_at_later_candidate_does_not_publish_partial_loop_ownership'),
 ('jarde_java', 'region::and_body_boundary_tests::budget_stop_at_body_boundary_does_not_publish_partial_ownership'),
 ('jarde_java', 'region::and_body_boundary_tests::pre_cancelled_later_chain_remains_a_stop_without_partial_ownership'),
 ('jarde_java', 'region::and_body_boundary_tests::cancellation_during_later_boundary_check_remains_a_stop'),
 ('p3_complex_if_body_boundary', 'original_debug_and_no_debug_class_and_plain_jar_keep_the_effectful_body_boundary'),
 ('p3_complex_if_body_boundary', 'low_output_budget_and_precancellation_publish_no_partial_class_artifact'),
]

LOOP2_RETRY_GATES = [
 ('jarde_java', 'region::finite_loop_catch_tests::loop2_original_retry_tree_has_exact_four_owner_retry_shape_debug_and_nodebug'),
 ('jarde_java', 'region::finite_loop_catch_tests::loop2_retry_proof_used_minus_one_and_precancel_are_atomic'),
 ('jarde_java', 'region::finite_loop_catch_tests::loop2_retry_proof_refuses_mutated_range_shared_rows_wrong_transfer_and_nonthrow_leaf'),
 ('p3_branching_catch_retry', 'original_loop2_debug_and_no_debug_default_and_all_keep_the_full_structured_retry_class'),
]

LOOP2_RETRY_EDGE_GATES = [
 ('jarde_java', 'region::finite_loop_catch_tests::loop2_real_reader_graphs_reject_external_entries_wrong_targets_return_leaf_and_shared_rows'),
 ('jarde_java', 'region::finite_loop_catch_tests::loop2_late_region_budget_stop_does_not_publish_a_partial_retry_loop'),
 ('p3_branching_catch_retry', 'reachable_retry_controls_keep_both_polarities_and_full_methods_for_all_compiler_profiles'),
]

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('receipt',type=Path)
 ap.add_argument('--out',type=Path,required=True)
 a=ap.parse_args()
 if a.out.exists(): raise FileExistsError(f'refusing to overwrite {a.out}')
 if hashlib.sha256(BASE.read_bytes()).hexdigest()!=BASE_SHA: raise RuntimeError('frozen accepted workspace checker changed')
 if hashlib.sha256(INHERITED_WRAPPER.read_bytes()).hexdigest()!=INHERITED_WRAPPER_SHA: raise RuntimeError('frozen accepted ancestor gate wrapper changed')
 spec=importlib.util.spec_from_file_location('frozen_workspace_checker',BASE)
 c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
 ws=importlib.util.spec_from_file_location('frozen_ancestor_gate_wrapper',INHERITED_WRAPPER)
 inherited=importlib.util.module_from_spec(ws);ws.loader.exec_module(inherited)
 gates=list(inherited.GATES)+HISTORICAL_OBJECT_ARGUMENT_GATES+CURRENT_GATES+ENTRY_SPLIT_GATES+IF_LOOP_ENTRY_GATES+LITERAL_BOOLEAN_GATES+CONTINUE_LADDER_GATES+ARRAY_SUBTRACT_GATES+POST_TEST_LOOP_BREAK_GATES+COMPLEX_IF_BODY_BOUNDARY_GATES+LOOP2_RETRY_GATES+LOOP2_RETRY_EDGE_GATES
 if len(inherited.GATES)!=18 or len(ENTRY_SPLIT_GATES)!=11 or len(IF_LOOP_ENTRY_GATES)!=3 or len(LITERAL_BOOLEAN_GATES)!=5 or len(CONTINUE_LADDER_GATES)!=3 or len(ARRAY_SUBTRACT_GATES)!=1 or len(POST_TEST_LOOP_BREAK_GATES)!=3 or len(COMPLEX_IF_BODY_BOUNDARY_GATES)!=11 or len(LOOP2_RETRY_GATES)!=4 or len(LOOP2_RETRY_EDGE_GATES)!=3 or len(set(gates))!=len(gates): raise RuntimeError('inherited/new exact gate identities changed or collide')
 c.GATES=gates
 rpath=a.receipt/'execution.json' if a.receipt.is_dir() else a.receipt
 x=c.validate_one(rpath)
 if x['seed']!='5350648285461741569': raise RuntimeError('unexpected fixed workspace seed')
 if x['critical_gate_count']!=len(gates): raise RuntimeError('exact gate inventory was not fully checked')
 required=set(HISTORICAL_OBJECT_ARGUMENT_GATES+CURRENT_GATES+ENTRY_SPLIT_GATES+IF_LOOP_ENTRY_GATES+LITERAL_BOOLEAN_GATES+CONTINUE_LADDER_GATES+ARRAY_SUBTRACT_GATES+POST_TEST_LOOP_BREAK_GATES+COMPLEX_IF_BODY_BOUNDARY_GATES+LOOP2_RETRY_GATES+LOOP2_RETRY_EDGE_GATES)
 got={(tuple(g['target'])[1],g['test']) for g in x['critical_gates']}
 if not required <= got: raise RuntimeError('one or more exact gates absent from checked receipts')
 native_pin={'path':str(Path(rpath).resolve()),'bytes':Path(rpath).stat().st_size,'sha256':hashlib.sha256(Path(rpath).read_bytes()).hexdigest()}
 dest=a.out.resolve();dest.parent.mkdir(parents=True,exist_ok=True)
 report={'schema':'single-seed-post-test-loop-workspace-review-v2','status':'passed',
  'native_receipt':native_pin,'source_pins_sha256':x['source_pins_sha256'],
  'seed':x['seed'],'target_count':x['target_count'],'batch_count':x['batch_count'],
  'workspace_totals':x['workspace_totals'],'source_pin_count':x['source_pin_count'],
  'critical_gate_count':len(gates),'inherited_gate_count':len(inherited.GATES),
  'historical_object_argument_gates':[{'target':t,'test':n} for t,n in HISTORICAL_OBJECT_ARGUMENT_GATES],
  'current_exact_gates':[{'target':t,'test':n} for t,n in CURRENT_GATES],
  'entry_split_exact_gates':[{'target':t,'test':n} for t,n in ENTRY_SPLIT_GATES],
  'if_loop_entry_exact_gates':[{'target':t,'test':n} for t,n in IF_LOOP_ENTRY_GATES],
  'literal_boolean_exact_gates':[{'target':t,'test':n} for t,n in LITERAL_BOOLEAN_GATES],
  'continue_ladder_exact_gates':[{'target':t,'test':n} for t,n in CONTINUE_LADDER_GATES],
  'array_subtract_exact_gates':[{'target':t,'test':n} for t,n in ARRAY_SUBTRACT_GATES],
  'post_test_loop_break_exact_gates':[{'target':t,'test':n} for t,n in POST_TEST_LOOP_BREAK_GATES],
  'complex_if_body_boundary_exact_gates':[{'target':t,'test':n} for t,n in COMPLEX_IF_BODY_BOUNDARY_GATES],
  'loop2_retry_exact_gates':[{'target':t,'test':n} for t,n in LOOP2_RETRY_GATES],
  'loop2_retry_edge_exact_gates':[{'target':t,'test':n} for t,n in LOOP2_RETRY_EDGE_GATES],
  'critical_gates_each_occur_once_and_pass':True,'workspace':x,
  'checker':{'path':str(BASE),'sha256':BASE_SHA},
  'inherited_gate_wrapper':{'path':str(INHERITED_WRAPPER),'sha256':INHERITED_WRAPPER_SHA},
  'reviewer':str(Path(__file__).resolve())}
 dest.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'status':'passed','seed':x['seed'],'targets':x['target_count'],'gates':len(gates),'output':str(dest)}))
if __name__=='__main__': main()
