#!/usr/bin/env python3
"""Run the accepted native verifier plus exact Loop4/Loop5 and later gates."""
from __future__ import annotations
import argparse
import sys
sys.dont_write_bytecode = True
import common


def pair(spec: str) -> tuple[str, str]:
    target, sep, test = spec.partition('=')
    if not sep or not target or not test or any(ch.isspace() for ch in target + test):
        raise argparse.ArgumentTypeError('expected TARGET=FULL_TEST_NAME without whitespace')
    return target, test


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('receipt')
    parser.add_argument('--out', required=True)
    parser.add_argument('--extra-critical', action='append', default=[], type=pair,
                        metavar='TARGET=FULL_TEST_NAME',
                        help='additional exact gate, e.g. a Region proof test after its name is fixed')
    args = parser.parse_args()
    old = common.load_pinned('verify-native.py', 'loop45_frozen_native_wrapper')
    add = list(common.PUBLIC_GATES) + list(args.extra_critical)
    existing = list(old.CURRENT_GATES)
    combined = existing + add
    if len(combined) != len(set(combined)):
        raise SystemExit('duplicate native exact gate identity')
    old.CURRENT_GATES = combined
    sys.argv = [str(common.BASE / 'verify-native.py'), args.receipt, '--out', args.out]
    result = old.main()
    if result not in (None, 0):
        return int(result)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
