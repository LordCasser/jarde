#!/usr/bin/env python3
"""Static-only audit of the private Loop45 native/CI acceptance adapters."""
from __future__ import annotations
import ast
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASE = Path('/private/tmp/jarde-loop2-retry-native-ci-prep-luna-v2-20261019')

def need(ok: bool, reason: str) -> None:
    if not ok:
        raise SystemExit(reason)

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

for name in ('common.py', 'verify-native-loop45.py', 'collect-own-ci-loop45.py',
             'verify-own-ci-loop45.py', 'static_verify.py'):
    path = OUT / name
    need(path.is_file() and not path.is_symlink(), f'missing private adapter: {name}')
    ast.parse(path.read_text(encoding='utf-8'), filename=str(path))

common_tree = ast.parse((OUT / 'common.py').read_text(encoding='utf-8'))
base_pins = next(ast.literal_eval(node.value) for node in common_tree.body
                 if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'BASE_PINS' for t in node.targets))
for rel, expected in base_pins.items():
    path = BASE / rel
    need(path.is_file() and not path.is_symlink() and sha(path) == expected,
         f'frozen accepted base artifact changed: {rel}')
base_review = json.loads((BASE / 'static-review.json').read_text(encoding='utf-8'))
need(base_review['native_exact_gate_count'] == 78 and base_review['ci_exact_gate_count'] == 123,
     'accepted base gate inventory is not 78 native / 123 CI')
argv = json.loads((BASE / 'acceptance-argv.json').read_text(encoding='utf-8'))
extras = [argv['verify_ci'][i + 1] for i, token in enumerate(argv['verify_ci'][:-1]) if token == '--extra-critical']
need(len(extras) == 13, 'the inherited 13 CI --extra-critical identities changed')
need(json.loads((OUT / 'acceptance-argv.json').read_text(encoding='utf-8'))['fixed_ci_extra_critical'] == extras,
     'the recorded baseline 13 CI identities differ from the frozen accepted argv')
need(json.loads((OUT / 'acceptance-argv.json').read_text(encoding='utf-8'))['ci_fixed_seeds'] ==
     ['5350648285461741569', '5350648285461741570'], 'the two fixed CI seeds changed')

public = (
 ('recover_loop45_original_public', 'original_loop4_debug_and_no_debug_class_and_full_jar_keep_structured_conditional_break_body'),
 ('recover_loop45_original_public', 'original_loop4_public_class_source_propagates_precancellation_without_partial_text'),
 ('recover_loop45_original_public', 'original_loop5_debug_and_no_debug_class_and_full_jar_keep_named_catch_return_tail'),
 ('recover_loop45_original_public', 'original_loop5_public_class_source_propagates_precancellation_without_partial_text'),
)
root_test = ROOT / 'tests/recover_loop45_original_public.rs'
need(root_test.is_file() and not root_test.is_symlink(), 'integrated Loop45 public test source is absent/unsafe')
source_text = root_test.read_text(encoding='utf-8')
for target, test in public:
    need(test in source_text, f'Loop45 public gate missing from integrated test: {test}')

native_text = (OUT / 'verify-native-loop45.py').read_text(encoding='utf-8')
need('common.PUBLIC_GATES' in native_text and 'args.extra_critical' in native_text and 'old.CURRENT_GATES = combined' in native_text,
     'native adapter does not extend frozen exact-gate validation')
collector_text = (OUT / 'collect-own-ci-loop45.py').read_text(encoding='utf-8')
ci_text = (OUT / 'verify-own-ci-loop45.py').read_text(encoding='utf-8')
need('common.extend_ci_inventory(old)' in collector_text and 'common.extend_ci_inventory(old)' in ci_text,
     'CI adapters do not share the dynamic source/fixture inventory extension')
need("!= 123" in ci_text and 'old.parse_workspace_group' in ci_text and 'target_summaries' in ci_text,
     'CI verifier does not retain 123 base gates and full two-seed counter comparison')
need('old.official_step_logs' in ci_text and 'acceptance-argv.json' in ci_text,
     'CI verifier omitted the frozen official-step/log or 13-identity source')
common_text = (OUT / 'common.py').read_text(encoding='utf-8')
need('CI_SOURCE_ADDITIONS' in common_text and 'CI_FIXTURE_ROOT_ADDITIONS' in common_text and 'root.rglob' in common_text,
     'Loop45 source/fixtures are not recursively included')
plan = json.loads((OUT / 'command-plan.json').read_text(encoding='utf-8'))
need(plan['status'] == 'prepared_not_executed', 'command plan is not marked unexecuted')
need(plan['inheritance']['preserved_native_gate_count'] == 78 and plan['inheritance']['preserved_ci_gate_count'] == 123,
     'command plan changes inherited gate inventory')
need('runtime_target_source_and_pass_counts' in plan['invariants'], 'dynamic receipt-derived counters are not documented')
need('Git' in plan['not_run'] and 'network' in plan['not_run'] and 'Cargo' in plan['not_run'], 'non-execution record is incomplete')

fixture_roots = [ROOT / rel for rel in ('tests/fixtures/recover-proved-loop-break-branch-bodies',
                                        'tests/fixtures/recover-named-catch-loop-return-tails')]
need(all(path.is_dir() and not path.is_symlink() for path in fixture_roots), 'one or more Loop45 fixture roots missing/unsafe')
fixture_files = sorted(path for base in fixture_roots for path in base.rglob('*') if path.is_file())
need(fixture_files and all(not path.is_symlink() for path in fixture_files), 'Loop45 recursive fixture inventory empty/unsafe')

print(json.dumps({
    'status': 'static_preparation_checks_passed',
    'native_base_gates': 78,
    'ci_base_gates': 123,
    'public_loop45_gates': len(public),
    'inherited_extra_critical': len(extras),
    'loop45_fixture_files_seen_now': len(fixture_files),
    'runtime_counters': 'not pinned; receipt-derived',
    'native_ci_binding_execution': 'not run'
}, ensure_ascii=False))
