#!/usr/bin/env python3
"""Reuse accepted CI/source/log verification and add exact Loop4/5/future gates."""
from __future__ import annotations
import argparse
import contextlib
import io
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import common


def parse_pair(spec: str) -> tuple[str, str]:
    target, sep, test = spec.partition('=')
    if not sep or not target or not test or any(ch.isspace() for ch in target + test):
        raise argparse.ArgumentTypeError('expected TARGET=FULL_TEST_NAME without whitespace')
    return target, test


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence_dir', type=Path)
    parser.add_argument('--product-sha', required=True)
    parser.add_argument('--cli-sha256', required=True)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--extra-critical', action='append', default=[], type=parse_pair,
                        metavar='TARGET=FULL_TEST_NAME',
                        help='additional exact gate after its Region test name is finalized')
    args = parser.parse_args()
    if args.out.exists():
        raise FileExistsError(f'refusing to overwrite {args.out}')
    old = common.load_pinned('verify-own-ci.py', 'loop45_frozen_ci_verifier')
    common.extend_ci_inventory(old)
    base_argv_pin = common.BASE / 'acceptance-argv.json'
    if common.sha(base_argv_pin) != common.BASE_PINS['acceptance-argv.json']:
        raise RuntimeError('frozen accepted CI argument inventory changed')
    acceptance_argv = json.loads(base_argv_pin.read_text(encoding='utf-8'))
    args_vector = acceptance_argv['verify_ci']
    fixed_extra = [args_vector[i + 1] for i, token in enumerate(args_vector[:-1]) if token == '--extra-critical']
    if len(fixed_extra) != 13:
        raise RuntimeError('accepted 13 --extra-critical identities are not intact')
    base_sys_argv = [str(common.BASE / 'verify-own-ci.py'), str(args.evidence_dir),
                     '--product-sha', args.product_sha, '--cli-sha256', args.cli_sha256,
                     '--repo', str(common.ROOT)]
    for spec in fixed_extra:
        base_sys_argv.extend(['--extra-critical', spec])
    saved_argv = sys.argv
    stdout = io.StringIO()
    try:
        sys.argv = base_sys_argv
        with contextlib.redirect_stdout(stdout):
            status = old.main()
    finally:
        sys.argv = saved_argv
    if status not in (None, 0):
        return int(status)
    base_report = json.loads(stdout.getvalue())
    if base_report.get('status') != 'accepted' or base_report.get('critical_gate_count') != 123:
        raise RuntimeError('frozen CI verifier did not accept all 123 inherited gates')

    gates = list(common.PUBLIC_GATES) + list(args.extra_critical)
    if len(gates) != len(set(gates)):
        raise SystemExit('duplicate supplemental CI exact gate identity')
    known = set(old.CRITICAL_TESTS.values())
    if any((test, target) in known for target, test in gates):
        raise SystemExit('supplemental gate duplicates an inherited exact identity')
    for index, (target, test) in enumerate(gates, start=1):
        old.CRITICAL_TESTS[f'Loop45 supplemental {index}: {target}::{test}'] = (test, target)

    logs = old.official_step_logs(args.evidence_dir.resolve(strict=True))
    stable = logs[old.EXPECTED_JOBS['stable']]
    _, _, seeds = old.workflow_contract(common.ROOT / '.github/workflows/ci.yml')
    groups = old.workspace_groups(stable)
    if len(groups) != 2:
        raise RuntimeError('official stable step log does not contain both fixed-seed runs')
    seed_reports = [old.parse_workspace_group(group, seed) for group, seed in zip(groups, seeds)]
    if [row['seed'] for row in seed_reports] != list(seeds):
        raise RuntimeError('official workspace run seeds differ from workflow order')
    if (seed_reports[0]['target_inventory'] != seed_reports[1]['target_inventory']
            or seed_reports[0]['target_summaries'] != seed_reports[1]['target_summaries']):
        raise RuntimeError('complete per-target outcomes/counters differ between fixed seeds')
    labels = [f'Loop45 supplemental {index}: {target}::{test}'
              for index, (target, test) in enumerate(gates, start=1)]
    for index, seed_report in enumerate(seed_reports):
        passed = seed_report['critical_tests_passed']
        if not set(labels).issubset(passed):
            raise RuntimeError(f'supplemental exact gate outcomes absent in seed {seeds[index]}')

    report = {
        'schema': 'loop45-own-ci-supplemental-review-v1',
        'status': 'accepted',
        'product': base_report['product'],
        'base_acceptance': base_report,
        'base_exact_gate_count': 123,
        'loop45_public_gate_count': len(common.PUBLIC_GATES),
        'deferred_extra_critical_count': len(args.extra_critical),
        'supplemental_exact_gates': [
            {'target': target, 'test': test, 'runs': [seeds[0], seeds[1]], 'once_per_seed_passed': True}
            for target, test in gates
        ],
        'complete_target_summaries_equal_between_seeds': True,
        'fixed_seeds': list(seeds),
        'source_and_fixture_inventory': {
            'source_paths': list(old.SOURCE_PATHS),
            'fixture_roots': list(old.FIXTURE_ROOTS),
            'fixture_file_count': len(old.EXPECTED_FIXTURE_FILES),
        },
        'official_step_zip_and_live_source_binding': 'validated by pinned frozen base CI verifier/collector',
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'base_gates': 123,
                      'supplemental_gates': len(gates), 'output': str(args.out)}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
