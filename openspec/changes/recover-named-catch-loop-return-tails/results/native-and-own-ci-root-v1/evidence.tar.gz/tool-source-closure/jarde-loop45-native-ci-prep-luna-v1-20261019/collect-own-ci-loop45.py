#!/usr/bin/env python3
"""Collect own-CI evidence with the frozen collector and added Loop4/5 source pins."""
from __future__ import annotations
import argparse
import sys
sys.dont_write_bytecode = True
import common


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence_dir')
    parser.add_argument('run_id')
    parser.add_argument('product_sha')
    parser.add_argument('cli_sha256')
    args = parser.parse_args()
    old = common.load_pinned('collect-own-ci.py', 'loop45_frozen_ci_collector')
    common.extend_ci_inventory(old)
    sys.argv = [str(common.BASE / 'collect-own-ci.py'), args.evidence_dir,
                args.run_id, args.product_sha, args.cli_sha256]
    return int(old.main())

if __name__ == '__main__':
    raise SystemExit(main())
