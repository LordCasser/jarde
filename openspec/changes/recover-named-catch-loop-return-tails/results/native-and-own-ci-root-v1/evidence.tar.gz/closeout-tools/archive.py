import hashlib,json,tarfile,sys,io,stat
from pathlib import Path
out=Path(sys.argv[1]);cfg=json.loads(Path(sys.argv[2]).read_text());assert not out.exists();out.mkdir(parents=True)
rows=[];excluded=[];seen=set()
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=9) as tar:
 for item in cfg:
  base=Path(item['path']);assert base.exists(),base
  for p in sorted(base.rglob('*')) if base.is_dir() else [base]:
   if not p.is_file():continue
   assert not p.is_symlink(),p
   rel=p.relative_to(base).as_posix() if base.is_dir() else p.name
   name=item['prefix']+'/'+rel
   assert name not in seen;seen.add(name)
   b=p.read_bytes();row={'member':name,'original_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':stat.S_IMODE(p.stat().st_mode)}
   if p.name=='candidate-cli' or '__pycache__' in p.parts or p.suffix=='.pyc':excluded.append(row);continue
   t=tarfile.TarInfo(name);t.size=len(b);t.mode=row['mode'];t.mtime=0;tar.addfile(t,io.BytesIO(b));rows.append(row)
(out/'inventory.json').write_text(json.dumps({'payloads':rows,'excluded':excluded},ensure_ascii=False,indent=2)+'\n')
with tarfile.open(out/'evidence.tar.gz','r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for m,r in zip(members,rows):
  b=tar.extractfile(m).read();assert m.name==r['member'] and m.mode==r['mode'] and len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
p=out/'evidence.tar.gz';b=p.read_bytes();result={'status':'all_members_reopened_and_matched','archive':{'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'payload_count':len(rows),'payload_bytes':sum(r['bytes'] for r in rows),'excluded_count':len(excluded)}
(out/'capture.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
