from pathlib import Path
import json,hashlib,collections
P=Path('/private/tmp');out=P/'jarde-loop45-final-root-review-v3-20261019';assert not out.exists();out.mkdir()
def pin(row):
 b=Path(row['path']).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];return b
def reopen(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=set(v):pin(v);return 1
  return sum(reopen(x) for x in v.values())
 if isinstance(v,list):return sum(reopen(x) for x in v)
 return 0
rows=[]
for n in (4,5):
 base=P/f'jarde-testbreakinloop{n}-final-compare-root-v2-20261019';r=json.loads((base/'execution.json').read_text());audit=json.loads((base/'review.json').read_text());old=json.loads((P/f'jarde-testbreakinloop{n}-final-compare-root-v1-20261019'/'execution.json').read_text())
 assert r['status']=='captured-pending-independent-review' and len(r['commands'])==70
 assert sum(reopen(c) for c in r['commands'])==140
 assert all(r[k] for k in ('source_unchanged_finally','local_copies_unchanged_finally','external_inputs_unchanged','target_absent_finally','generated_outputs_unchanged'))
 assert audit['api_keys_unique_complete'] and audit['default_all_text_maps_stable']
 assert len(r['jarde_cells'])==8
 for c,previous in zip(r['jarde_cells'],old['jarde_cells']):
  assert c['method_inventory_matches'] and len(c['methods'])==3
  for m,prev in zip(c['methods'],previous['methods']):
   assert m['quality']=='structured' and m['outcome_kind']=='recovered' and not m['fallbacks'] and not m['map_audit']['issues']
   assert m['raw_text']==prev['raw_text'] and m['quality']==prev['quality'] and m['map_audit']['mapped_bcis']==prev['map_audit']['mapped_bcis']
   if m['name']=='test':assert (len(m['map_audit']['mapped_bcis']),len(m['map_audit']['physical_bcis']),m['map_audit']['unmapped_physical_bcis'])==((23,23,[]) if n==4 else (59,60,[103]))
 comp=r['generated_source_compilations'];assert len(comp)==20;success=[c for c in comp if c['exit_code']==0];failed=[c for c in comp if c['exit_code']!=0];assert collections.Counter(c['kind'] for c in success)=={'jarde':8,'jadx':2};assert all(c['compiler']=='javac23' and c['runtime_eligible'] for c in success);assert len(failed)==10
 for c in failed:
  raw=pin(c['stderr']).decode();assert c['compiler']=='javac8' and '55.0' in raw and '52.0' in raw
 assert len(r['generated_runtime'])==20 and all(c['exit_code']==0 and c['matches_original_oracle'] and all(v for v in c.values() if isinstance(v,bool)) for c in r['generated_runtime'])
 assert len(r['original_runtime'])==4 and len(r['generated_wrong_root_controls'])==10 and all(c['rejected'] and c['exit_code']!=0 for c in r['generated_wrong_root_controls'])
 rows.append({'loop':n,'raw_streams':140,'api':8,'structured_methods':24,'compiles':20,'jarde_success':8,'jadx_success':2,'jdk8_framework_compile_failures':10,'generated_vm':20,'original_vm':4,'wrong_codesource':10,'test_source_map':[23,23] if n==4 else [59,60],'missing_bcis':[] if n==4 else [103],'prior_version_method_text_and_physical_coverage_unchanged':True})
r=json.loads((P/'jarde-loop5-extended-final-root-v2-20261019'/'execution.json').read_text());o=json.loads((P/'jarde-loop5-extended-original-root-v1-20261019'/'execution.json').read_text());assert r['status']=='complete' and r['all_runs_passed'] and r['passed_run_count']==20

def parse(raw):
 lines=raw.decode().splitlines();assert len(lines)==13;cases=[]
 for i,line in enumerate(lines):
  kind,*parts=line.split();pairs=[x.split('=',1) for x in parts];d=dict(pairs);assert len(d)==len(pairs)
  if i<12:assert kind=='CASE' and int(d['index'])==i;cases.append(d)
  else:assert kind=='CHECK';check=d
 return cases,{k:v for k,v in check.items() if k!='exception_stack_b64'}
oracle={}
for x in o['runtimes']:
 c=o['commands'][x['command']-1];assert c['exit_code']==0;oracle[x['profile'],x['runtime']]=parse(pin(c['stdout']));pin(c['stderr'])
seen=set()
for x in r['runs']:
 key=(x['compilation_index'],x['runtime']);assert key not in seen;seen.add(key);assert x['exit_code']==0 and x['status']=='passed';assert parse(pin(x['stdout']))==oracle[x['identity']['profile'],x['runtime']];pin(x['stderr'])
assert len(seen)==20 and len({x[0] for x in seen})==10
for i in {x[0] for x in seen}:assert {rt for ci,rt in seen if ci==i}=={'javac8','javac23'}
a=json.loads((P/'jarde-loop5-extended-independent-reopen-luna-v2-20261019'/'audit.json').read_text());assert a['status']=='passed' and all(a['checks'].values()) and a['counts']['generated_case_records']==240
result={'status':'root_final_comparison_and_extended_accepted','product':'412245d514896b1d0eb9a8fe24388f6a70668637','cli_sha256':'d29b6fee723d8f59fbecd9fd8be9f15a8ec73de3a90f5a2a29b24ff91e4af607','comparison':rows,'extended':{'generated_vm':20,'generated_raw_streams':40,'generated_CASE':240,'generated_CHECK':20,'oracle_vm':4,'oracle_CASE':48},'scope':'Loop5 physical goto103→14 remains unmapped; native and own CI acceptance separate'}
(out/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
