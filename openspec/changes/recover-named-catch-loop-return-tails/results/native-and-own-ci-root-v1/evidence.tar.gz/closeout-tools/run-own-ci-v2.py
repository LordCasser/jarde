from pathlib import Path
import json,subprocess,hashlib,sys
root=Path('/Users/lordcasser/workspace/projects/jarde');launch=Path('/private/tmp/jarde-loop45-own-ci-launch-root-v2-20261019');assert not launch.exists() and not (root/'target').exists();launch.mkdir();rows=[]
for i,argv in enumerate(json.loads(Path(__file__).with_name('own-ci-commands-v2.json').read_text()),1):
 assert not (root/'target').exists();print('CI evidence step '+str(i)+' started',flush=True)
 so=launch/f'{i}.stdout.raw';se=launch/f'{i}.stderr.raw'
 with so.open('xb') as a,se.open('xb') as b:r=subprocess.run(argv,cwd=root,stdout=a,stderr=b)
 row={'argv':argv,'exit_code':r.returncode,'streams':{}}
 for k,p in [('stdout',so),('stderr',se)]:
  data=p.read_bytes();row['streams'][k]={'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 rows.append(row);(launch/'execution.json').write_text(json.dumps({'status':'running' if r.returncode==0 else 'failed','commands':rows},indent=2)+'\n');print('CI evidence step '+str(i)+' closed exit '+str(r.returncode),flush=True)
 if r.returncode:sys.exit(r.returncode)
(launch/'execution.json').write_text(json.dumps({'status':'closed_all_commands_passed','commands':rows},indent=2)+'\n')
