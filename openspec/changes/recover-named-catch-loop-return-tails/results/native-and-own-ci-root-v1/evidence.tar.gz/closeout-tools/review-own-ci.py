from pathlib import Path
import json,hashlib,zipfile
root=Path('/Users/lordcasser/workspace/projects/jarde');p=Path('/private/tmp/jarde-loop45-own-ci-root-v2-20261019');r=json.loads((p/'loop45-review.json').read_text());b=r['base_acceptance'];c=json.loads((p/'collection.json').read_text());assert r['status']=='accepted' and r['product']['head_sha']=='412245d514896b1d0eb9a8fe24388f6a70668637';assert b['ci']['job_count']==4 and b['ci']['expanded_api_step_count']==52 and not b['aggregate_step_proofs'];assert r['complete_target_testname_status_counter_equal_between_seeds'] and r['full_named_outcome_count_per_seed']==[3939,3939]
paths={}
def walk(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=set(v):
   q=Path(v['path']);data=q.read_bytes();assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256'];paths[str(q)]=v;return
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)
walk(c['commands']);walk(json.loads((p/'step-log-supplement.json').read_text()));assert len(c['commands'])==184 and all(x['exit_code']==0 for x in c['commands'])
sources=json.loads((p/'source-pins.json').read_text());bound=0
for key,folder in [('source_files','product-source'),('fixture_files','product-fixtures')]:
 for rel,row in sources[key].items():
  data=(p/folder/rel).read_bytes();assert data==(root/rel).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];bound+=1
assert bound==178
with zipfile.ZipFile(p/'run-logs.zip') as z:assert z.testzip() is None;zip_members=len(z.infolist())
assert all(s['target_count']==394 and [s['workspace_totals'][k] for k in ('passed','failed','ignored')]==[3841,0,98] for s in b['workspace_seed_runs']);gates=b['critical_gate_count']+len(r['supplemental_exact_gates']);assert gates==141
out=Path('/private/tmp/jarde-loop45-ci-root-acceptance-v1-20261019');assert not out.exists();out.mkdir();record={'status':'frozen_verifiers_and_root_raw_pins_passed_pending_independent_CI_audit','product':r['product'],'run_id':c['run_id'],'jobs':4,'official_api_steps':52,'aggregate_reconstructions':0,'canonical_commands':len(c['commands']),'reopened_unique_stream_or_zip_pin_paths':len(paths),'source_paths':34,'fixture_files':144,'live_and_product_source_bindings':bound,'seeds':[s['seed'] for s in b['workspace_seed_runs']],'targets_per_seed':[s['target_count'] for s in b['workspace_seed_runs']],'workspace_totals_per_seed':[s['workspace_totals'] for s in b['workspace_seed_runs']],'full_named_outcomes_per_seed':r['full_named_outcome_count_per_seed'],'full_counter_sha256':r['full_counter_sha256'],'critical_gates_per_seed':gates,'official_zip_member_count_including_aggregates':zip_members};(out/'acceptance.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
