//! One class file presented as Java source: its declaration, its fields and its member bodies.
//!
//! # What this module owns, and what it does not
//!
//! The reads belong to the layers below, and this module performs none of them itself: the class's
//! declaration, its fields and its method records are the class read [`crate::Engine::class_source`]
//! binds and walks, and every member body is one analysis run with the presentation of that same
//! run's payload — the run [`crate::Engine::recover_method`] performs, on the class that entry
//! prepares once for the whole presentation. What lives here is the **assembly**: the Java spelling
//! of one class from those results, and the report that publishes the facts *and* the spelling
//! beside each other, so a caller can check one against the other instead of trusting the text.
//!
//! # Every member says what it is
//!
//! A class file is not source and this text does not claim to be one; what it must never do is let
//! a member look like something it is not:
//!
//! * a member whose declaration carries no `Code` attribute — an `abstract` or `native` member — is
//!   written as the declaration it is (`public abstract void run();`) with a `// jarde:` marker
//!   above it, and no run is performed for it (there is no body to run on);
//! * a member whose recovery run stopped, produced an artifact holding no statement, or was refused
//!   keeps its declaration and a block whose whole content is the marker that says so: an empty
//!   body is never written for a body that was not recovered;
//! * a member whose raw descriptor is not one this presentation can read as a Java type gets a
//!   marker and no declaration at all, and no run is performed for it either.
//!
//! `// jarde:` is the one marker prefix, so a reader — or a `grep` — finds every place where the
//! text is not a full recovery, and the same lines are published per member in the report
//! ([`ClassSourceField::markers`], [`ClassSourceMethod::markers`]).
//!
//! # What the text is not
//!
//! It is not a compilable project, and it does not claim to be one. The one `package` statement it
//! writes is the package the class's **own** internal name states — `a/b/C` declares `a.b`, and a
//! name with no `/` is the default package and declares none — which is a statement about that name
//! and not about the directory the class was found in. No `import` is resolved or elided, no
//! resource is parsed and no annotation type is resolved outside this class file. An isolated
//! physical member remains named `p.Outer$Inner`; only a separately proved root/child relation,
//! capture, call census and complete bodies can publish a nested root source unit.
//!
//! What the text writes about a declaration is what the class file's own attributes say about it,
//! and never an inference from anything else:
//!
//! * a field's `ConstantValue` (JVMS 4.7.2) is its own initializer; an ordinary interface's
//!   `<clinit>` value reaches a declaration only after the complete field group, evaluation order
//!   and runtime initialization phase have been proved. The original field and method reports stay
//!   available beside that source projection;
//! * a member's `Exceptions` (JVMS 4.7.4) is its `throws` clause, in the attribute's own order, and
//!   no exception is ever inferred from an `athrow`;
//! * a member's `AnnotationDefault` (JVMS 4.7.22) is its `default <literal>`.
//!
//! A value this presentation has no literal for — an unsupported NaN bit pattern, a nested
//! annotation with an invalid source name, or a floating-point field initializer — is written as
//! no initializer and no default rather than guessed. Names are spelled
//! the one way source spells them (`/` becomes `.`, and nothing else), and the raw bytes of every
//! name and descriptor stay published in the report.
//!
//! # Determinism
//!
//! The text is a pure function of the class bytes, the request and the budget's *limits*: no
//! ordering comes from a map, no name is invented twice, no timestamp and no count from a previous
//! run is written. The one field two runs of the same request may differ in is the elapsed clock in
//! `usage`, which is not part of the text.

use crate::facade::{
    ClassDeclarationFacts, ClassDeclarationItem, ClassRef, EnvironmentRequest, FieldItem,
    MethodItem,
};
use crate::{
    AnalysisStage, AttributeShell, Budget, Coverage, CpEntryFacts, Diagnostic, Error,
    ExecutionReport, JvmBytes, JvmString, Limits, MemberHeader, MemberTableStop, NoBodyKind,
    PhysicalDefinitionId, PhysicalMethodId, PhysicalView, Result, TerminationReason, UsageSnapshot,
    attribute_facts, budget_dimension_code,
};
use jarde_java::report::TypedFunctionalKind;
use jarde_java::report::{GenericConstructorCandidate, GenericReturnCandidate, GenericReturnValue};
use jarde_java::{
    LocalVariable, NameTable, RecoveryContent, RecoveryFacts, RecoveryReport, SlotEvidence,
    alias_for, comment_text, escape_string, is_java_identifier, nested_member_reference_spelling,
    type_of_component,
};
use jarde_jvm::method_ir::parameter_positions;
use jarde_reader::budget::CountedBudgetDimension;
use jarde_reader::classfile::{
    Base, ClassMemberFacts, CpEntryKind, DescriptorComponent, DescriptorKind, ElementConstantTag,
    ElementValueFacts, EnclosingMethodFacts, InnerClassFacts, TypeAnnotationFacts, TypePathEntry,
    cp_entry, descriptor_facts,
};
use jarde_reader::signature::{
    ClassSignatureErasureProof, SignatureType, TypeArgument, TypeParameter, TypeParameterErasure,
    parse_class_signature, parse_field_signature, parse_method_signature,
    prove_class_signature_erasure, prove_field_signature_erasure_with_class_scope,
    prove_method_signature_erasure_with_class_scope,
};
use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------------------------
// The request
// ---------------------------------------------------------------------------------------------

/// One class-source request: the class to present, and the environment it is read in.
///
/// The two fields are the method operations' own shape ([`crate::MethodOperationRequest`]) for the
/// class-level target, so a caller that can name a class for [`crate::Engine::class_view`] can name
/// one here with the same [`ClassRef`] and the same [`EnvironmentRequest`].
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceRequest {
    /// The class to present: a friendly name searched with the navigation rules over the
    /// environment's scope, or the physical definition a listing handed back. Several definitions
    /// of one name are all returned as candidates and nothing is presented (see
    /// [`crate::OperationOutcome`]).
    pub class: ClassRef,
    /// The environment this request runs in: the physical view its scope is read under, the policy
    /// that states its roots, and the runtime profile every member's recovery is presented under.
    pub environment: EnvironmentRequest,
}

/// Typed class-level nesting facts supplied to class-source assembly from the selected class read.
///
/// These remain an internal handoff: they are not method IR or part of the serialized class-source
/// report. Later assembly proofs may consume them without decoding the class attributes again.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub(crate) struct ClassSourceAssemblyContext {
    pub(crate) major_version: Option<u16>,
    pub(crate) inner_classes: Vec<InnerClassFacts>,
    pub(crate) enclosing_method: Option<EnclosingMethodFacts>,
    pub(crate) resolved_inner_classes: Vec<ResolvedInnerClass>,
    pub(crate) resolved_enclosing_method: Option<ResolvedEnclosingMethod>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct ResolvedInnerClass {
    pub(crate) class: Vec<u8>,
    pub(crate) outer_class: Option<Vec<u8>>,
    pub(crate) inner_name: Option<JvmBytes>,
    pub(crate) access_flags: u16,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct ResolvedEnclosingMethod {
    pub(crate) class: Vec<u8>,
    pub(crate) method: Option<(JvmBytes, JvmBytes)>,
}

/// Read the nesting facts the selected class contributes to assembly through the reader's typed
/// attribute parser. The caller supplies only the selected class's own nesting shells.
pub(crate) fn read_class_source_assembly_context(
    bytes: &[u8],
    shells: &[AttributeShell],
    pool: &[CpEntryFacts],
    budget: &mut Budget,
) -> Result<ClassSourceAssemblyContext> {
    let facts = attribute_facts(bytes, shells, pool, budget)?;
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(facts.inner_classes.len())
            .unwrap_or(u64::MAX)
            .saturating_add(u64::from(facts.enclosing_method.is_some())),
    )?;
    let mut resolved_inner_classes = Vec::with_capacity(facts.inner_classes.len());
    for row in &facts.inner_classes {
        budget.poll()?;
        resolved_inner_classes.push(ResolvedInnerClass {
            class: jarde_reader::classfile::cp_class_name(pool, row.class_index)?.0,
            outer_class: (row.outer_class_index != 0)
                .then(|| jarde_reader::classfile::cp_class_name(pool, row.outer_class_index))
                .transpose()?
                .map(|name| name.0),
            inner_name: row.inner_name.clone(),
            access_flags: row.access_flags,
        });
    }
    let resolved_enclosing_method = facts
        .enclosing_method
        .as_ref()
        .map(|method| {
            let class = jarde_reader::classfile::cp_class_name(pool, method.class_index)?.0;
            let member = if method.method_index == 0 {
                None
            } else {
                match &jarde_reader::classfile::cp_entry(pool, method.method_index)?.kind {
                    jarde_reader::classfile::CpEntryKind::NameAndType {
                        name, descriptor, ..
                    } => Some((name.clone(), descriptor.clone())),
                    _ => {
                        return Err(Error::invalid_input(
                            "classfile_constant_pool_tag_mismatch",
                            "EnclosingMethod method_index does not refer to a NameAndType constant",
                        ));
                    }
                }
            };
            Ok(ResolvedEnclosingMethod {
                class,
                method: member,
            })
        })
        .transpose()?;
    Ok(ClassSourceAssemblyContext {
        major_version: bytes
            .get(6..8)
            .map(|version| u16::from_be_bytes([version[0], version[1]])),
        inner_classes: facts.inner_classes,
        enclosing_method: facts.enclosing_method,
        resolved_inner_classes,
        resolved_enclosing_method,
    })
}

// ---------------------------------------------------------------------------------------------
// The report
// ---------------------------------------------------------------------------------------------

/// The class-level declaration of one class-source report, and the Java spelling the assembled text
/// opens with.
///
/// The item is the one the class read published — the same read
/// [`crate::ClassViewReport::declaration`] answers with — so the physical definition, the facts the
/// class file's own header states, whether the entry's path agrees with the declared name and where
/// the member walk stopped all keep the meaning they have there. `name` and `declaration` add the
/// spelling, and nothing else: they are derived from `item.declaration` alone.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceDeclaration {
    /// The class-level item of the read this report presents.
    pub item: ClassDeclarationItem,
    /// The class's own name, as its declaration spells it: the simple name `this_class` states —
    /// everything after the last `/` of the internal name, with `$` **kept**, so `p/Outer$Inner` is
    /// `Outer$Inner` and `p/More17$1` is `More17$1`.
    ///
    /// The package the rest of the name states is written as the text's own `package` statement (see
    /// [`ClassSourceReport::text`]) and never as a qualification of this name, and a constructor is
    /// spelled with this name rather than with the internal one. The internal name itself stays in
    /// [`Self::item`], so the bytes the class file states and the one line spelled from them are
    /// published side by side. A class `Signature` can replace the header spelling only after its
    /// variable scope and physical parent identities have been proved; the raw attribute and any
    /// refusal remain alongside the projected text.
    pub name: String,
    /// The declaration line the assembled text opens with, without its opening brace (for example
    /// `public class Base extends java.lang.Object implements p.Marker`).
    ///
    /// Only the flags Java source spells are written (`public`/`protected`/`private`, `abstract`,
    /// `final`, `strictfp`); the raw `access_flags` stay in [`Self::item`], and the bits that are not
    /// source keywords (`ACC_SUPER`, `ACC_SYNTHETIC`, `ACC_MODULE`) are not invented into text.
    /// An ordinary interface's `extends` list is the interfaces the class file declares — its
    /// `super_class` is `java/lang/Object` by the format's own rule, so it is not written as a
    /// superclass. A canonical annotation's implicit `java/lang/annotation/Annotation` remains in
    /// [`Self::item`] and is not written into its `@interface` header. The name of every type the
    /// header does write is the internal name the pool states, `/` written as `.`; only the class's
    /// **own** name is the simple one (see [`Self::name`]).
    pub declaration: String,
    /// Class-level Runtime*Annotations shells and the complete value facts read from each.
    pub annotation_attributes: Vec<ClassAnnotationAttribute>,
    /// Complete class-level annotation uses this presentation can spell, in physical attribute
    /// order and then attribute entry order.
    pub annotation_uses: Vec<String>,
    /// One refusal for every class-level annotation that cannot be faithfully represented in Java.
    pub annotation_refusals: Vec<String>,
    /// The class's own generic Signature, when its attribute could be read.
    pub generic_signature: Option<JvmBytes>,
    /// Why the class Signature could not be published as a complete Java header.
    pub generic_refusal: Option<String>,
    /// The type-parameter header text a **successful** projection spelled (`U`,
    /// `U, V`, `N extends java.lang.Number`). It is the one Signature projection the member
    /// fold's own nested header can carry verbatim; `None` with a `generic_signature` states a
    /// projection the fold does not have. Deliberately absent from the JSON view.
    #[serde(skip)]
    pub(crate) generic_type_parameters: Option<String>,
    /// The exact class Signature erasure scope that published this header. It is kept for the
    /// separately proved member-family pass and is deliberately absent from the JSON view.
    #[serde(skip)]
    pub(crate) generic_scope: Option<ClassSignatureErasureProof>,
    /// The `implements` entries whose **published header text** carries the interface's own type
    /// arguments, by binary name. This is the fact the bridge admission reads — the shared
    /// contract of `recover-bridge-admission-gates` and this projection: a header that carries
    /// the erased contract's type arguments is what lets a recompiled source regenerate the
    /// bridge, so a bridge whose contract owner is one of these entries may hide, and every
    /// other generic interface contract keeps its bridge visible. Empty for a header no
    /// projection published, and deliberately absent from the JSON view.
    #[serde(skip)]
    pub(crate) header_interface_arguments: Vec<Vec<u8>>,
}

/// One class-level annotation attribute's original shell and its parsed annotation entries.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassAnnotationAttribute {
    pub attribute: AttributeShell,
    pub annotations: Vec<ElementValueFacts>,
}

/// One member's own `Runtime*Annotations` attribute, kept beside the spelling derived from it.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MemberAnnotationUses {
    pub attributes: Vec<MemberAnnotationAttribute>,
    pub uses: Vec<String>,
    pub refusals: Vec<String>,
}

/// The raw shell and complete annotation values of one field or method declaration attribute.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MemberAnnotationAttribute {
    pub attribute: AttributeShell,
    pub annotations: Vec<ElementValueFacts>,
}

/// One method's own `Runtime*ParameterAnnotations` attribute, including its leading `u1` count.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ParameterAnnotationAttribute {
    pub attribute: AttributeShell,
    /// `None` means the shell was retained after its content could not be read.
    pub parameter_count: Option<u8>,
    pub parameters: Vec<Vec<ElementValueFacts>>,
}

/// Parsed and source-spelled parameter annotations, aligned only by descriptor parameter position.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ParameterAnnotationUses {
    pub attributes: Vec<ParameterAnnotationAttribute>,
    /// One list for each descriptor parameter, including positions with no annotation.
    pub uses_by_position: Vec<Vec<String>>,
    pub refusals: Vec<String>,
}

/// One type annotation shell and every entry it physically contains, with the attempted spelling.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct TypeAnnotationUses {
    pub attributes: Vec<TypeAnnotationAttribute>,
    pub field_uses: Vec<String>,
    pub return_uses: Vec<String>,
    /// Descriptor parameter position to type-only source spellings.
    pub parameter_uses: Vec<Vec<String>>,
    /// Refusals retain the entry's owner, target and path in their text.
    pub refusals: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct TypeAnnotationAttribute {
    pub attribute: AttributeShell,
    pub annotations: Vec<TypeAnnotationUse>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct TypeAnnotationUse {
    pub target_type: u8,
    pub target_info: Vec<u8>,
    pub type_path: Vec<TypePathEntry>,
    pub annotation: ElementValueFacts,
    pub spelling: Option<String>,
    pub refusal: Option<String>,
}

/// The raw member annotation facts handed from the one member-table read to its declaration writer.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub(crate) struct MemberAnnotationFacts {
    pub(crate) declaration: MemberAnnotationUses,
    pub(crate) parameters: ParameterAnnotationUses,
    pub(crate) type_uses: TypeAnnotationUses,
}

/// Parsed annotation facts and local attribute errors from one member's annotation shells.
pub(crate) struct MemberAnnotationRead {
    pub(crate) facts: MemberAnnotationFacts,
    pub(crate) errors: Vec<Error>,
}

/// One field of the presented class, with the spelling the assembled text writes.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceField {
    /// The field record of the class read: its table position, its physical identity, its own raw
    /// name and descriptor, and its access flags.
    pub item: FieldItem,
    /// The declaration the text writes for this field, without its terminating `;`. `None` exactly
    /// when the field's raw descriptor is not one this presentation can read as a field descriptor
    /// (JVMS 4.3.2): the text then writes only the markers.
    ///
    /// The field's own `ConstantValue` attribute (JVMS 4.7.2), when it declares one and states a
    /// value this presentation has a literal for, is written as this declaration's initializer
    /// (`static final int N = 3`). For a proved ordinary-interface group, its same-run `<clinit>`
    /// RHS is appended here only after every fragment has been emitted successfully; the field
    /// remains in this vector at its original physical table index. A proved enum group changes
    /// only assembled source text: enum constants have no fabricated field records, while every
    /// physical field (including the backing array) remains here at its original index. A proven
    /// field `Signature` can replace the descriptor type while keeping the physical field identity
    /// in [`Self::item`].
    pub declaration: Option<String>,
    /// The field's own declaration annotation attributes, their complete values, spellings, and
    /// any annotation-level refusal.
    pub annotations: MemberAnnotationUses,
    /// Type annotation attributes physically owned by this field.
    pub type_annotations: TypeAnnotationUses,
    /// Every `// jarde:` marker the text carries for this field, in the order it writes them, each
    /// one line: an unspellable raw name/descriptor or the field `Signature` projection decision.
    /// Empty when no such explanation is needed.
    pub markers: Vec<String>,
}

/// A same-read, same-class field whose exact integer ConstantValue is already in its declaration.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct ProvedIntegerConstant {
    pub(crate) field: FieldItem,
    pub(crate) name: String,
    pub(crate) value: i32,
}

/// One method of the presented class: the record of the class read, the spelling of its declaration,
/// the text this presentation wrote for it, and the result of its own body's run.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum EnumConstructorSourceTail {
    Unrecognized,
    NoArg,
    Int,
    SingleString,
    StringVarargs,
}

impl EnumConstructorSourceTail {
    fn is_recognized(self) -> bool {
        self != Self::Unrecognized
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceMethod {
    /// The method record of the class read: its table position, its physical identity a single-method
    /// recovery request consumes directly, its own raw name and descriptor, its access flags, and
    /// what its declaration says about its body ([`crate::MemberBodyEvidence`]).
    pub item: MethodItem,
    /// The `abstract`/`native` kind the member's own flags declare, when they declare one. `Some`
    /// exactly when the member declares no `Code` attribute *and* says which of the two it is; a
    /// member that declares neither is `None`, which is what the bytes state.
    pub no_body_kind: Option<NoBodyKind>,
    /// The Java spelling of this physical member, without its opening brace and without a
    /// terminating `;`. `None` exactly when the member's raw descriptor is not one this presentation
    /// can read as a method descriptor (JVMS 4.3.3), in which case no declaration is written and
    /// [`Self::outcome`] is [`ClassSourceOutcome::Unspelled`]. An admitted bridge keeps this physical
    /// spelling here while [`Self::text`] carries its projection explanation.
    ///
    /// A member named `<init>` is spelled as the constructor it is (the class's own name, no return
    /// type), and `<clinit>` as Java's static initializer block (`static`), each with a marker that
    /// names the raw member it came from. A proved enum group may omit its physical constructor,
    /// helpers, and `<clinit>` from assembled source, but their method-table entries and original
    /// outcomes remain here; the projection does not create replacement method records.
    pub declaration: Option<String>,
    /// The method's own declaration annotation attributes, values, spellings, and refusals.
    pub annotations: MemberAnnotationUses,
    /// The method's own parameter annotation attributes, in descriptor-position order when the
    /// attribute's `u1 num_parameters` proves that mapping.
    pub parameter_annotations: ParameterAnnotationUses,
    /// Type annotation attributes physically owned by this method.
    pub type_annotations: TypeAnnotationUses,
    /// The member's own text in the assembled source: its optional marker, its declaration and
    /// either its block or its `;`, or an identity-bearing bridge projection explanation. One level
    /// of indentation is already applied, so the text can be read on its own or found inside
    /// [`ClassSourceReport::text`] unchanged.
    ///
    /// A recovered body is placed by splitting the recovery artifact at its own block — the envelope
    /// comment lines the recovery layer wrote, then the statements it wrote — and indenting both one
    /// level deeper. That split is a reading of the fixpoint shape
    /// [`jarde_java::recover`] emits; a produced artifact that does not have it is quoted line by
    /// line as comments rather than placed as if it were statements.
    pub text: String,
    /// Every `// jarde:` marker the text carries for this member, in the order it writes them, each
    /// one line: a member with no `Code` attribute, a run that stopped or produced no statement, a
    /// member that could not be spelled, the alias of a raw name Java cannot spell, a run whose
    /// analysis did not complete, or a bridge projection explanation.
    pub markers: Vec<String>,
    /// What the member's own body produced: one recovery run's report, a declaration without a body,
    /// an unspellable member, or the member-level refusal of its run.
    pub outcome: ClassSourceOutcome,
    /// Same-run source candidate retained for the final family writer only.
    #[serde(skip)]
    pub(crate) same_run_generic_return: Option<GenericReturnCandidate>,
    /// A complete same-run AST/SSA proof for the method body under its generic Signature. This is
    /// installed only inside the class transaction after every return, condition, throw and
    /// incoming call source has been joined to the physical method and formal slots.
    #[serde(skip)]
    pub(crate) same_class_generic_body_proof: Option<SameClassGenericMethodBodyProof>,
    /// The physical method's ordinary Signature attempt refused. Family assembly may replace
    /// that one marker on a cloned writer record only after its separate proof succeeds.
    #[serde(skip)]
    pub(crate) generic_signature_refused: bool,
    /// The staged generic declaration and body were charged and published together.
    #[serde(skip)]
    pub(crate) generic_signature_projected: bool,
    /// Closed source-tail shape parsed from this physical constructor's Signature.
    #[serde(skip)]
    pub(crate) enum_constructor_source_tail: EnumConstructorSourceTail,
    /// Whether the ordinary physical-descriptor projection refused that source tail only because
    /// the VM-injected enum name and ordinal make its descriptor longer.
    #[serde(skip)]
    pub(crate) enum_constructor_signature_erasure_refused: bool,
}

/// The fields changed while proving and rendering one generic-call member. Keeping this overlay
/// separate lets the class transaction stage a declaration without cloning its RecoveryReport.
#[derive(Debug, Eq, PartialEq)]
pub(crate) struct GenericCallProjectionState {
    pub(crate) declaration: Option<String>,
    pub(crate) text: String,
    pub(crate) markers: Vec<String>,
    pub(crate) same_class_generic_body_proof: Option<SameClassGenericMethodBodyProof>,
    pub(crate) generic_signature_refused: bool,
    pub(crate) generic_signature_projected: bool,
    pub(crate) enum_constructor_source_tail: EnumConstructorSourceTail,
    pub(crate) enum_constructor_signature_erasure_refused: bool,
}

impl ClassSourceMethod {
    /// Save only the mutable projection fields before the ordinary per-member Signature attempt.
    /// The RecoveryReport, annotations, and all other source facts remain in the original record.
    pub(crate) fn generic_call_projection_state(
        &self,
        budget: &mut Budget,
    ) -> Result<GenericCallProjectionState> {
        budget.poll()?;
        if self.same_class_generic_body_proof.is_some() {
            return Err(Error::unsupported(
                "generic_call_projection_state_unexpected_body_proof",
                "the pre-transaction source snapshot already carries a staged body proof",
            ));
        }
        let mut copied_bytes = u64::try_from(self.text.len()).unwrap_or(u64::MAX);
        let mut copied_steps = 8u64;
        if let Some(declaration) = &self.declaration {
            copied_bytes =
                copied_bytes.saturating_add(u64::try_from(declaration.len()).unwrap_or(u64::MAX));
        }
        copied_steps =
            copied_steps.saturating_add(u64::try_from(self.markers.len()).unwrap_or(u64::MAX));
        for marker in &self.markers {
            budget.poll()?;
            copied_bytes =
                copied_bytes.saturating_add(u64::try_from(marker.len()).unwrap_or(u64::MAX));
        }
        budget.charge(CountedBudgetDimension::AnalysisSteps, copied_steps)?;
        budget.charge(CountedBudgetDimension::OutputBytes, copied_bytes)?;
        Ok(GenericCallProjectionState {
            declaration: self.declaration.clone(),
            text: self.text.clone(),
            markers: self.markers.clone(),
            same_class_generic_body_proof: None,
            generic_signature_refused: self.generic_signature_refused,
            generic_signature_projected: self.generic_signature_projected,
            enum_constructor_source_tail: self.enum_constructor_source_tail,
            enum_constructor_signature_erasure_refused: self
                .enum_constructor_signature_erasure_refused,
        })
    }

    /// Move a completed projection overlay onto its physical method record.
    pub(crate) fn install_generic_call_projection_state(
        &mut self,
        state: GenericCallProjectionState,
    ) {
        self.declaration = state.declaration;
        self.text = state.text;
        self.markers = state.markers;
        self.same_class_generic_body_proof = state.same_class_generic_body_proof;
        self.generic_signature_refused = state.generic_signature_refused;
        self.generic_signature_projected = state.generic_signature_projected;
        self.enum_constructor_source_tail = state.enum_constructor_source_tail;
        self.enum_constructor_signature_erasure_refused =
            state.enum_constructor_signature_erasure_refused;
    }

    fn take_generic_call_projection_state(&mut self) -> GenericCallProjectionState {
        GenericCallProjectionState {
            declaration: self.declaration.take(),
            text: std::mem::take(&mut self.text),
            markers: std::mem::take(&mut self.markers),
            same_class_generic_body_proof: self.same_class_generic_body_proof.take(),
            generic_signature_refused: std::mem::take(&mut self.generic_signature_refused),
            generic_signature_projected: std::mem::take(&mut self.generic_signature_projected),
            enum_constructor_source_tail: std::mem::replace(
                &mut self.enum_constructor_source_tail,
                EnumConstructorSourceTail::Unrecognized,
            ),
            enum_constructor_signature_erasure_refused: std::mem::take(
                &mut self.enum_constructor_signature_erasure_refused,
            ),
        }
    }
}

impl GenericCallProjectionState {
    /// Clone a raw pre-transaction overlay for one component's isolated staging area.
    pub(crate) fn clone_raw_for_stage(&self, budget: &mut Budget) -> Result<Self> {
        budget.poll()?;
        if self.same_class_generic_body_proof.is_some() {
            return Err(Error::unsupported(
                "generic_call_projection_state_unexpected_body_proof",
                "only the raw pre-transaction overlay can seed a component stage",
            ));
        }
        let mut copied_bytes = u64::try_from(self.text.len()).unwrap_or(u64::MAX);
        let mut copied_steps = 8u64;
        if let Some(declaration) = &self.declaration {
            copied_bytes =
                copied_bytes.saturating_add(u64::try_from(declaration.len()).unwrap_or(u64::MAX));
        }
        copied_steps =
            copied_steps.saturating_add(u64::try_from(self.markers.len()).unwrap_or(u64::MAX));
        for marker in &self.markers {
            budget.poll()?;
            copied_bytes =
                copied_bytes.saturating_add(u64::try_from(marker.len()).unwrap_or(u64::MAX));
        }
        budget.charge(CountedBudgetDimension::AnalysisSteps, copied_steps)?;
        budget.charge(CountedBudgetDimension::OutputBytes, copied_bytes)?;
        Ok(Self {
            declaration: self.declaration.clone(),
            text: self.text.clone(),
            markers: self.markers.clone(),
            same_class_generic_body_proof: None,
            generic_signature_refused: self.generic_signature_refused,
            generic_signature_projected: self.generic_signature_projected,
            enum_constructor_source_tail: self.enum_constructor_source_tail,
            enum_constructor_signature_erasure_refused: self
                .enum_constructor_signature_erasure_refused,
        })
    }

    pub(crate) fn project_generic(
        &mut self,
        record: &ClassSourceMethod,
        declaration: String,
        signature: &[u8],
        proof: &str,
        budget: &mut Budget,
    ) -> Result<()> {
        let placed = match &record.outcome {
            ClassSourceOutcome::Recovered { report, .. } => {
                let Some(body) = artifact(&report.text) else {
                    return Ok(());
                };
                Placed::Block(body)
            }
            ClassSourceOutcome::NoBody if record.no_body_kind.is_some() => Placed::Without,
            _ => return Ok(()),
        };
        let marker = format!(
            "// jarde: generic Signature `{}` projected after descriptor erasure and {proof}",
            comment_text(&String::from_utf8_lossy(signature)),
        );
        let marker_bytes = u64::try_from(marker.len()).unwrap_or(u64::MAX);
        budget.poll()?;
        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        budget.charge(CountedBudgetDimension::OutputBytes, marker_bytes)?;
        budget.charge(
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(self.markers.len()).unwrap_or(u64::MAX),
        )?;
        for _ in &self.markers {
            budget.poll()?;
        }
        let mut markers = std::mem::take(&mut self.markers);
        let old_marker_count = markers.len();
        markers.push(marker);
        let rendered_bytes = match &placed {
            Placed::Without => {
                declaration_member_text_bytes(&declaration, &markers, &record.annotations)
            }
            Placed::Block(body) => block_member_text_bytes(
                &declaration,
                body.envelope,
                body.statements,
                &markers,
                &record.annotations,
            ),
            Placed::Quoted(_) => unreachable!("generic Signature body is a recovered block"),
        };
        if let Err(error) = budget.charge(CountedBudgetDimension::OutputBytes, rendered_bytes) {
            markers.truncate(old_marker_count);
            self.markers = markers;
            return Err(error.into());
        }
        let text = prefix_method_annotations(
            match placed {
                Placed::Without => declaration_member(&declaration, &markers),
                body => block_member(&declaration, body, &markers),
            },
            &record.annotations,
        );
        self.declaration = Some(declaration);
        self.text = text;
        self.markers = markers;
        self.generic_signature_refused = false;
        self.generic_signature_projected = true;
        Ok(())
    }

    pub(crate) fn refuse_generic(
        &mut self,
        record: &ClassSourceMethod,
        reason: &str,
        budget: &mut Budget,
    ) -> Result<()> {
        let marker = format!(
            "// jarde: generic Signature projection refused for `{}`: {}",
            label(&record.item),
            comment_text(reason)
        );
        let marker_bytes = u64::try_from(marker.len()).unwrap_or(u64::MAX);
        let text_bytes = u64::try_from(self.text.len())
            .unwrap_or(u64::MAX)
            .saturating_add(marker_bytes)
            .saturating_add(5);
        budget.poll()?;
        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        budget.charge(CountedBudgetDimension::OutputBytes, marker_bytes)?;
        budget.charge(CountedBudgetDimension::OutputBytes, text_bytes)?;
        let text = format!("    {marker}\n{}", self.text);
        self.markers.push(marker);
        self.text = text;
        self.generic_signature_refused = true;
        Ok(())
    }

    pub(crate) fn project_generic_call_arguments(
        &mut self,
        record: &ClassSourceMethod,
        original_emission: &str,
        projected_emission: &str,
        markers: &[String],
        budget: &mut Budget,
    ) -> Result<bool> {
        budget.poll()?;
        let mut copied_bytes = 0u64;
        for marker in &self.markers {
            budget.poll()?;
            copied_bytes =
                copied_bytes.saturating_add(u64::try_from(marker.len()).unwrap_or(u64::MAX));
        }
        for marker in markers {
            budget.poll()?;
            copied_bytes =
                copied_bytes.saturating_add(u64::try_from(marker.len()).unwrap_or(u64::MAX));
        }
        budget.charge(
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(markers.len())
                .unwrap_or(u64::MAX)
                .saturating_add(u64::try_from(self.markers.len()).unwrap_or(u64::MAX))
                .saturating_add(1),
        )?;
        budget.charge(CountedBudgetDimension::OutputBytes, copied_bytes)?;
        let ClassSourceOutcome::Recovered { report, .. } = &record.outcome else {
            return Ok(false);
        };
        let Some(original_artifact) = artifact(&report.text) else {
            return Ok(false);
        };
        let Some(declaration) = self.declaration.as_deref() else {
            return Ok(false);
        };
        let Some(original_text) = self.lambda_projection_text(record, &report.text, &[], budget)?
        else {
            return Ok(false);
        };
        let original_matches =
            class_source_body_lines_match(original_emission, original_artifact.statements);
        if original_text != self.text || !original_matches {
            return Ok(false);
        }
        let mut all_markers = std::mem::take(&mut self.markers);
        let old_marker_count = all_markers.len();
        all_markers.extend(markers.iter().cloned());
        let rendered_bytes = block_member_text_bytes(
            declaration,
            original_artifact.envelope,
            projected_emission,
            &all_markers,
            &record.annotations,
        );
        if let Err(error) = budget.charge(CountedBudgetDimension::OutputBytes, rendered_bytes) {
            all_markers.truncate(old_marker_count);
            self.markers = all_markers;
            return Err(error.into());
        }
        let text = prefix_method_annotations(
            block_member(
                declaration,
                Placed::Block(Artifact {
                    envelope: original_artifact.envelope,
                    statements: projected_emission,
                }),
                &all_markers,
            ),
            &record.annotations,
        );
        self.text = text;
        self.markers = all_markers;
        Ok(true)
    }

    fn lambda_projection_text(
        &self,
        record: &ClassSourceMethod,
        recovery_text: &str,
        markers: &[String],
        budget: &mut Budget,
    ) -> Result<Option<String>> {
        budget.poll()?;
        let Some(declaration) = self.declaration.as_deref() else {
            return Ok(None);
        };
        let Some(artifact) = artifact(recovery_text) else {
            return Ok(None);
        };
        let mut copied_bytes = 0u64;
        for marker in &self.markers {
            budget.poll()?;
            copied_bytes =
                copied_bytes.saturating_add(u64::try_from(marker.len()).unwrap_or(u64::MAX));
        }
        for marker in markers {
            budget.poll()?;
            copied_bytes =
                copied_bytes.saturating_add(u64::try_from(marker.len()).unwrap_or(u64::MAX));
        }
        budget.charge(
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(self.markers.len())
                .unwrap_or(u64::MAX)
                .saturating_add(u64::try_from(markers.len()).unwrap_or(u64::MAX)),
        )?;
        budget.charge(CountedBudgetDimension::OutputBytes, copied_bytes)?;
        budget.charge(
            CountedBudgetDimension::OutputBytes,
            block_member_text_bytes(
                declaration,
                artifact.envelope,
                artifact.statements,
                &self.markers,
                &record.annotations,
            ),
        )?;
        let mut all_markers = self.markers.clone();
        all_markers.extend(markers.iter().cloned());
        Ok(Some(prefix_method_annotations(
            block_member(declaration, Placed::Block(artifact), &all_markers),
            &record.annotations,
        )))
    }
}

/// The analysis half of one member's run, as this report publishes it.
///
/// The recovery report carries the other half — the artifact and its planes — and this is the part
/// of the run that is the analysis's own: the execution plane (which is where a stage that stopped
/// is stated, including a stop that still left the recovery layer enough tables to produce
/// something) and how many diagnostics the run published. The whole analysis report is not copied:
/// a caller that wants it re-runs the member with [`crate::Engine::recover_method`], which is the
/// same run by construction.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceRunFacts {
    /// The execution plane of the member's own analysis run.
    pub execution: ExecutionReport,
    /// How many diagnostics that run published.
    pub diagnostics: u64,
}

/// What one member's body produced.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
pub enum ClassSourceOutcome {
    /// One recovery run over this member's body: the analysis of the member and the presentation of
    /// that same run's payload, which is exactly what one [`crate::Engine::recover_method`] request
    /// answers with. `report` may hold a stop and no text (`jre_ir_table_missing`, a refused output
    /// charge, a cancellation) — the marker and [`ClassSourceReport::execution`] state that this
    /// member body is not part of the presentation.
    Recovered {
        /// The presentation of the run's own payload: the Java text, its segment table, its
        /// content classification, its quality and the planes of the run.
        ///
        /// The text here is the artifact as the recovery layer wrote it — a method **body**, with
        /// its own envelope comments and its own positions — while [`ClassSourceMethod::text`] is
        /// that artifact placed inside this presentation. The segment table's offsets are therefore
        /// offsets of *this* text, not of the assembled source, which carries no map of its own.
        report: Box<RecoveryReport>,
        /// The analysis half of the same run.
        analysis: ClassSourceRunFacts,
    },
    /// The member declares no `Code` attribute: no run was performed, no body attempt was charged,
    /// and no empty body is invented for it. This is a declaration and never a stop — the class is
    /// presented whole beside it — which is why it carries no execution plane of its own.
    NoBody,
    /// The member's raw descriptor is not one this presentation can read as the descriptor of its
    /// kind: no declaration was written, no run was performed, and the member's record keeps the
    /// bytes.
    ///
    /// This is not a stop of the request and not a failure of a read — nothing was read — and it is
    /// deliberately not counted as work that was skipped either (see
    /// [`ClassSourceReport::coverage`]): a member whose bytes are not a descriptor at all is outside
    /// the schema this presentation serves, and the marker it carries is where that is stated.
    Unspelled,
    /// The member's own run was refused before it produced a report: a charge the budget refused, a
    /// cancellation, or a failure of the run's own read. The refusal is this member's own — the
    /// members beside it keep their results (A13) — and its execution plane closes the report's when
    /// the refusal ended the whole request.
    Refused {
        execution: ExecutionReport,
        diagnostics: Vec<Diagnostic>,
    },
}

/// One class presented as Java source, with the facts it was spelled from.
///
/// `text` is the assembled source: the class declaration, then its fields (in proved `<clinit>` write
/// order for a projected static group, otherwise in physical field-table order), then
/// its methods in the order the class file's own method table declares them. A fully projected
/// proved static initializer is omitted from assembled source, but remains in `methods` with its
/// original recovery result. A proved enum group likewise changes only this assembled text: its
/// constants and source constructor replace the proved compiler-generated declarations, and a
/// narrowly proved static suffix may replace the matching `<clinit>` statements. Every physical
/// `fields` and `methods` item, table index, identity, and member outcome remains in this report's
/// vectors and JSON; member recovery reports keep their own source maps anchored to the original
/// bytecode. A stopped or refused enum proof leaves the whole enum group in its physical form.
/// `fields` always keeps physical field-table order; `methods` keeps the method-table order and
/// original recovery results. The planes are the request's own: `limits` is
/// the complete effective configuration, `usage` what that configuration was charged, `coverage`
/// the class and member tables this request read beside the members it attempted a body for, and
/// `execution` the merge of every stop of the request.
/// A proved direct member identity is retained in `member_family` with a separate child physical
/// report. A closed source projection replaces only this root report's text; child text, physical
/// methods, outcomes and their method-local source maps remain unchanged.
///
/// One member's stop does not end the class: a member whose recovery stopped keeps its own result
/// and the members beside it are still presented, exactly as a class view keeps the bodies beside a
/// stopped one. What a stopped member *does* do is make [`Self::execution`] non-`Complete`, so a
/// class whose presentation is partial is never published as a complete one.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceReport {
    /// The physical view this presentation read.
    pub view: PhysicalView,
    /// The physical definition this presentation is of: the identity a later read consumes.
    pub class: PhysicalDefinitionId,
    /// The class-level declaration, or `None` when the item charge for it was refused. The same read
    /// established the facts either way; a report that could not pay for its own declaration
    /// publishes nothing else — no field, no member, no text — and states the stop in `execution`
    /// and `diagnostics`.
    pub declaration: Option<ClassSourceDeclaration>,
    /// The analysis stages every member's run was asked for, in phase order: the recovery
    /// operation's own table ([`crate::MethodOperation::Recovery`]), published so a caller can
    /// reproduce one member's run with [`crate::Engine::recover_method`] and read the same schedule.
    pub stages: Vec<AnalysisStage>,
    /// The fields of the class read, in physical field-table order, each with its spelling.
    pub fields: Vec<ClassSourceField>,
    /// The methods of the class read, in the order its method table declares them, each with the
    /// result of its own run.
    pub methods: Vec<ClassSourceMethod>,
    /// Names written only in the assembled source, anchored to their physical method and field.
    pub integer_constant_projections: Vec<MemberFamilyDerivedProjection>,
    #[serde(skip)]
    pub(crate) integer_constant_candidates: Vec<ProvedIntegerConstant>,
    /// Source-only direct override hints, each anchored to the child and selected parent methods.
    /// Neither method's physical annotation attributes are changed.
    pub direct_override_proofs: Vec<ClassSourceDirectOverrideProof>,
    /// Direct member evidence for this request. A prepared child keeps its own physical class,
    /// member table, coverage, execution and source maps. Its `usage` is the cumulative snapshot
    /// of the *same* request budget at the end of that child's preparation.
    pub member_family: ClassSourceMemberFamily,
    /// A separately proved, narrow nested enum source projection. Each enum keeps its own
    /// physical report (including its enum group proof); projecting it only changes the owner's
    /// assembled text.
    pub nested_enum_family: ClassSourceNestedEnumFamily,
    /// A separately proved direct member annotation. Its child remains a physical report even
    /// when the owner's assembled source contains the declaration.
    pub nested_annotation_family: ClassSourceNestedAnnotationFamily,
    /// The bounded anonymous-interface expression projection, with ranges in `text` and anchors
    /// to the physical root/child method sites that supplied each generated expression.
    pub anonymous_interface_projection: ClassSourceAnonymousInterfaceProjection,
    /// Same-run class-level bridge admission results. These are adapter evidence for the
    /// subsequent source projection and remain visible beside the physical method records.
    #[doc(hidden)]
    pub bridge_proofs: Vec<ClassSourceBridgeProof>,
    /// Cross-class enum-switch mapping decisions from this class-source run, including refusals.
    #[doc(hidden)]
    pub enum_switch_proofs: Vec<ClassSourceEnumSwitchProof>,
    /// The all-or-nothing proof result for ordinary Java 8 static field initializers. The
    /// proof's field indices and write positions remain available beside the projected declarations;
    /// the original method records and recovery reports are retained in [`Self::methods`].
    pub initializer_proof: ClassSourceInitializerProof,
    /// The class-text projection inputs this report's assembled [`Self::text`] was staged with,
    /// retained as facts of the first pass so the member-fold channel can re-project the same
    /// text byte-for-byte (see [`ClassSourceProjectionInputs`]). Absent when the first pass
    /// staged no projection beside the physical member records.
    #[serde(skip_serializing_if = "ClassSourceProjectionInputs::is_empty")]
    pub projection_inputs: ClassSourceProjectionInputs,
    /// Same-run proof input retained only for the next class-source projection stage. This is
    /// private assembly state and is deliberately absent from the serialized report.
    #[serde(skip)]
    pub(crate) enum_constant_proof: crate::enum_constants::ClassSourceEnumConstantProof,
    /// Same-run selected enum subclass relations, awaiting exclusivity, constructor and body proof.
    /// This private handoff has no projection authority and is deliberately absent from JSON.
    #[serde(skip)]
    pub(crate) enum_constant_body_relations: Vec<crate::facade::PendingEnumConstantBodyRelation>,
    /// The assembled Java source. Empty exactly when [`Self::declaration`] is `None`. A proved
    /// member projection contains one root source unit with a nested child declaration; refusal
    /// retains this root's physical text. The narrow derived ranges in `member_family` refer to
    /// this string; method-local recovery maps still refer only to their own recovery text.
    pub text: String,
    /// The complete effective limits this request ran under.
    pub limits: Limits,
    /// What those limits were charged, in the engine's own dimensions.
    ///
    /// The snapshot is cumulative for this request. Binding and preparing each physical class
    /// charge their own reads and bodies; when `member_family` contains a child, this root snapshot
    /// also includes the child's work. The child's `usage` is an earlier cumulative snapshot of the
    /// same budget, not a separately reset counter.
    pub usage: UsageSnapshot,
    /// Which class and member records this request read, and how many members it attempted a body
    /// for (`class_source_bodies`, in the method table's own coordinates).
    ///
    /// The class and member ranges are [`crate::ClassViewReport::coverage`]'s own, under the same
    /// labels and with the same rule for their state: the structure plane is `CompleteWithinSchema`
    /// when the read reached its ends, and a member whose own run stopped below does not rewrite it.
    /// This operation's range counts the members it *could* run a body for — one that declares a
    /// `Code` attribute and whose descriptor it can read — scanned up to the runs it entered and
    /// skipped from there to the end, and the dimension is `Partial` whenever such a member was left
    /// without a run: a stop of the request before it, a body attempt the budget refused, the
    /// preparation of the class failing, or a class that could not be prepared at all.
    ///
    /// A member that declares no body is outside that range, which is the same rule the class view
    /// applies to a body nobody asked for: a declaration is not a body attempt. A member whose bytes
    /// are not a method descriptor is outside it too — such a member is published as
    /// [`ClassSourceOutcome::Unspelled`], which is a statement about the bytes rather than work this
    /// presentation left undone.
    pub coverage: Coverage,
    /// The merge of every plane this request published: the name search, the class read, the member
    /// table's own stop, every member's run and any selected child preparation. Each child report
    /// separately preserves its physical execution state.
    pub execution: ExecutionReport,
    /// The class-level diagnostics this presentation re-publishes: the class read's own (a path that
    /// disagrees with the declared name, a member table that stopped) and one for each stop this
    /// presentation itself took over the member items.
    ///
    /// A member-level failure is deliberately not copied here: a refused member keeps its own
    /// diagnostic inside its record ([`ClassSourceOutcome::Refused`]) and the stop it states, exactly
    /// as a class view keeps a refused body's — one finding has one home, and the class's own list
    /// stays the list of things that happened to the class.
    pub diagnostics: Vec<Diagnostic>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceDirectOverrideProof {
    pub child: jarde_reader::model::PhysicalMethodId,
    pub parent: jarde_reader::model::PhysicalMethodId,
}

/// Prepared family identity, capture and calls are independent of the final source projection.
/// Only `projection: Projected` states that the root text contains a nested declaration. The
/// separate child report always retains its physical text and method-local source maps.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "state", rename_all = "snake_case")]
pub enum ClassSourceMemberFamily {
    Absent,
    Refused {
        reason: String,
        /// A resolved child is retained even when the two physical rows disagree.
        child: Option<Box<ClassSourceReport>>,
    },
    RefusedPair {
        reason: String,
        /// Every child physically prepared before the joint proof refused.
        children: Vec<Box<ClassSourceReport>>,
    },
    Prepared {
        relation: ClassSourceMemberRelation,
        child: Box<ClassSourceReport>,
        /// Capture evidence only; a refused capture keeps both physical reports intact.
        capture: ClassSourceMemberCapture,
        /// Family-local construction verdicts; original method bodies remain physical.
        calls: ClassSourceMemberCalls,
        /// Source-unit projection is separate from the physical relation and local certificates.
        projection: ClassSourceMemberProjection,
    },
    PreparedPair {
        /// The root's InnerClasses order, retained with each selected physical child.
        members: [ClassSourceMemberChild; 2],
        projection: ClassSourceMemberProjection,
    },
    /// The direct static member family a fold projection renders: every child stays its own
    /// physical report, and only `projection: Projected` states that the root's text carries
    /// the nested declarations. The members are in the root's InnerClasses row order.
    PreparedStatic {
        members: Vec<ClassSourceMemberChild>,
        projection: ClassSourceMemberProjection,
    },
    /// The member family a fold projection renders with proved non-static rows beside its
    /// static ones: the root's text carries every nested declaration, the synthetic outer
    /// capture (constructor parameter, field and write) is elided inside that scope, and the
    /// javac access bridges the family proved are hidden with their call sites re-spelled. The
    /// members are in the root's InnerClasses row order.
    PreparedFold {
        members: Vec<ClassSourceMemberChild>,
        projection: ClassSourceMemberProjection,
    },
}

/// One selected physical child retained beside its proved relation, in the order the root's
/// own `InnerClasses` table states. The declaration pair and the static fold family share it.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
pub struct ClassSourceMemberChild {
    pub relation: ClassSourceMemberRelation,
    pub child: Box<ClassSourceReport>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "state", rename_all = "snake_case")]
pub enum ClassSourceNestedEnumFamily {
    Absent,
    Refused {
        reason: String,
        #[serde(skip)]
        child: Option<Box<ClassSourceReport>>,
    },
    Prepared {
        relation: ClassSourceMemberRelation,
        #[serde(skip)]
        child: Box<ClassSourceReport>,
        projection: ClassSourceNestedEnumProjection,
    },
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "state", rename_all = "snake_case")]
pub enum ClassSourceNestedEnumProjection {
    Refused {
        reason: String,
    },
    Projected {
        derived: Vec<MemberFamilyDerivedProjection>,
    },
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "state", rename_all = "snake_case")]
pub enum ClassSourceNestedAnnotationFamily {
    Absent,
    Refused {
        reason: String,
        #[serde(skip)]
        child: Option<Box<ClassSourceReport>>,
    },
    Prepared {
        relation: ClassSourceMemberRelation,
        #[serde(skip)]
        child: Box<ClassSourceReport>,
        projection: ClassSourceNestedAnnotationProjection,
    },
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "state", rename_all = "snake_case")]
pub enum ClassSourceNestedAnnotationProjection {
    Refused {
        reason: String,
    },
    Projected {
        derived: Vec<MemberFamilyDerivedProjection>,
    },
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "state", rename_all = "snake_case")]
pub enum ClassSourceAnonymousInterfaceProjection {
    Absent,
    Refused {
        reason: String,
    },
    Projected {
        derived: Vec<MemberFamilyDerivedProjection>,
    },
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "state", rename_all = "snake_case")]
pub enum ClassSourceMemberProjection {
    Refused {
        reason: String,
    },
    Projected {
        derived: Vec<MemberFamilyDerivedProjection>,
    },
}

/// A source-unit byte range created by the proved family writer. It never replaces a physical
/// method's recovery map: the range is in the root report's `text`, while every anchor names its
/// own physical definition and member.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MemberFamilyDerivedProjection {
    pub kind: MemberFamilyDerivedKind,
    pub start: usize,
    pub end: usize,
    pub anchors: Vec<MemberFamilyPhysicalAnchor>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum MemberFamilyDerivedKind {
    IntegerConstantName,
    NestedEnumDeclaration,
    NestedAnnotationDeclaration,
    NestedEnumTypeReference,
    MemberConstruction,
    MemberReturnType,
    MemberGenericSignature,
    MemberConstructorName,
    MemberClassDeclaration,
    MemberMethodDeclaration,
    CapturedOuterRead,
    OuterSuperCall,
    HiddenCaptureField,
    HiddenConstructorParameter,
    HiddenCaptureWrite,
    HiddenOuterSuperBridge,
    NestedAnonymousExpression,
    /// One reference a static member fold re-spelled: a pool `$` name of a folded member became
    /// the nested source spelling inside the fold's own text. The anchors name the physical
    /// evidence (field, method point, or member signature) beside both class definitions.
    StaticMemberTypeReference,
    /// One javac access bridge a member fold hid from the root's text: the anchors name the
    /// bridge's own method identity beside the passthrough field it read.
    HiddenAccessBridge,
    /// One access-bridge call site a member fold re-spelled into the qualified field access the
    /// bridge forwarded: the anchors name the invokestatic site and the hidden bridge.
    AccessBridgeCall,
    /// The javac assert switch field the assert projection hid from the class's text: the
    /// anchors name the physical field beside the class definition it was proved against, and
    /// the span is the header the field's declaration would have followed.
    HiddenAssertSwitchField,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum MemberFamilyPhysicalAnchor {
    ClassDefinition {
        definition: PhysicalDefinitionId,
    },
    Field {
        field: jarde_reader::model::PhysicalMemberId,
        index: u64,
    },
    MethodPoint {
        method: PhysicalMethodId,
        bci: u32,
    },
    ConstructorParameter {
        method: PhysicalMethodId,
        index: u32,
    },
    MethodSignature {
        method: PhysicalMethodId,
    },
    /// The bridge's raw MethodRef and the exact selected target declaration are retained together.
    OuterSuperTarget {
        method: PhysicalMethodId,
        owner: JvmBytes,
        name: JvmBytes,
        descriptor: JvmBytes,
    },
    EnumConstantGroup {
        definition: PhysicalDefinitionId,
        constants: Vec<jarde_reader::model::PhysicalMemberId>,
        initializer: PhysicalMethodId,
    },
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "state", rename_all = "snake_case")]
pub enum ClassSourceMemberCalls {
    Proved {
        sites: Vec<MemberCallProof>,
    },
    StaticProved {
        sites: Vec<StaticMemberCallProof>,
    },
    StaticDeclarationOnly,
    Refused {
        reason: String,
        sites: Vec<MemberCallProof>,
        refusals: Vec<MemberCallRefusal>,
    },
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct StaticMemberCallProof {
    pub caller: PhysicalMethodId,
    pub allocation_bci: u32,
    pub copy_bci: u32,
    pub constructor_bci: u32,
    pub constructor: PhysicalMethodId,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MemberCallProof {
    pub caller: PhysicalMethodId,
    pub allocation_bci: u32,
    pub copy_bci: u32,
    pub qualifier_bci: u32,
    pub null_check_bci: u32,
    pub null_pop_bci: u32,
    pub constructor_bci: u32,
    pub constructor: PhysicalMethodId,
    pub ordinary_argument_bcis: Vec<u32>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MemberCallRefusal {
    pub caller: PhysicalMethodId,
    pub allocation_bci: u32,
    pub reason: String,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "state", rename_all = "snake_case")]
pub enum ClassSourceMemberCapture {
    Proved {
        proof: MemberCaptureProof,
    },
    StaticNoCapture {
        #[serde(skip)]
        target: Box<jarde_java::report::ProvedStaticMemberTarget>,
    },
    /// The physical relation is proved, but no constructor use target is claimed.
    StaticDeclaration,
    Refused {
        reason: String,
    },
}

/// Physical evidence for capture only. A writer must separately prove every changed expression.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MemberCaptureProof {
    pub field_index: u64,
    pub field_name: String,
    pub constructor: PhysicalMethodId,
    pub write_bci: u32,
    pub reads: Vec<MemberCaptureRead>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MemberCaptureRead {
    pub method: PhysicalMethodId,
    pub bci: u32,
    /// SSA consumers of the value loaded from the capture field, in this physical method.
    pub consumer_bcis: Vec<u32>,
}

/// A physical, linear bridge from a selected Outer to its direct superclass method.
/// This is evidence only; the family writer must separately accept every use before hiding it.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct OuterSuperBridgeProof {
    pub bridge: PhysicalMethodId,
    pub outer_name: JvmBytes,
    pub invoke_bci: u32,
    pub target_method: PhysicalMethodId,
    pub target_owner: JvmBytes,
    pub target_name: JvmBytes,
    pub target_descriptor: JvmBytes,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct OuterSuperCallProof {
    pub caller: PhysicalMethodId,
    pub call_bci: u32,
    pub capture_read_bci: u32,
    pub argument_bcis: Vec<u32>,
    pub bridge: OuterSuperBridgeProof,
}

/// Complete physical use census within the selected input and request-visible scope. It does
/// not by itself prove Java source overload binding; the writer must establish that separately.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct OuterSuperBridgeClosureProof {
    pub bridge: OuterSuperBridgeProof,
    pub calls: Vec<OuterSuperCallProof>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceMemberRelation {
    pub root: PhysicalDefinitionId,
    pub child: PhysicalDefinitionId,
    pub simple_name: String,
    /// Source modifiers come from the matching InnerClasses rows, not child class access flags.
    pub access_flags: u16,
}

/// The map entries this class-source request proved from a selected helper's physical `<clinit>`.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceEnumSwitchEntry {
    pub key: i64,
    pub constant: Vec<u8>,
    pub constant_field_bci: u32,
    pub ordinal_bci: u32,
    pub table_read_bci: u32,
    pub store_bci: u32,
    pub handler_ordinal: u32,
    pub handler_bci: u32,
}

/// One same-run enum-switch candidate's class-level proof and projection outcome.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceEnumSwitchProof {
    pub member: jarde_reader::model::PhysicalMethodId,
    pub switch_bci: u32,
    pub read_bci: u32,
    pub table_owner: String,
    pub table_name: String,
    pub helper: Option<jarde_reader::model::PhysicalDefinitionId>,
    pub enum_definition: Option<jarde_reader::model::PhysicalDefinitionId>,
    pub entries: Vec<ClassSourceEnumSwitchEntry>,
    pub projected: bool,
    pub refusal: Option<String>,
}

/// A class-level bridge admission result and the state of its complete-source projection.
/// Admission preserves the ordinary recovery report and physical method table; `projected` only
/// states whether this class-source body emitted the explanation in place of a Java declaration.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceBridgeProof {
    /// The physical bridge method whose same-run plan entered this proof.
    pub member: jarde_reader::model::PhysicalMethodId,
    /// The unique source method when all forward and signature premises were established.
    pub target: Option<jarde_reader::model::PhysicalMethodId>,
    /// The invocation BCI retained by the same-run `bridge@1` candidate.
    pub call_bci: Option<u32>,
    /// Whether the bridge may be elided from Java source under the proved inherited contract.
    pub admitted: bool,
    /// Whether the complete source replaced this member's Java declaration with a proof note.
    pub projected: bool,
    /// The first conservative reason the complete proof refused admission.
    pub refusal: Option<String>,
}

/// Whether the complete ordinary interface or class static initializer group passed proof.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
pub enum ClassSourceInitializerProof {
    /// The class is outside this proof's scope or has no ordinary-class runtime static group.
    NotApplicable,
    /// Every runtime field write in the group passed, in original `<clinit>` order.
    Proved {
        /// Physical field index and its same-run write position and BCI, in initializer order.
        fields: Vec<ClassSourceInitializerField>,
    },
    /// The whole runtime initializer group was refused with the first unmet proof condition.
    Refused { reason: String },
}

/// The write whose value would be eligible for a later source projection.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceInitializerField {
    /// The unchanged physical `field_info` table index.
    pub field_index: u64,
    /// The statement's order in the same-run `<clinit>` AST.
    pub write_order: usize,
    /// The `putstatic` BCI claimed by `field@1`.
    pub write_bci: u32,
}

/// The class-text projection inputs one root's assembled [`ClassSourceReport::text`] was staged
/// with, retained as the facts of that first pass — never recomputed, and never a second decision.
///
/// The first pass assembles its text from the physical member records plus a handful of same-run
/// side channels (omitted helper members, marker lines, substituted member texts, an enum-constant
/// projection and a proved initializer field order). Those channels live in the assembly context
/// alone, so a later projection of the same report — the member fold's root re-projection — could
/// previously rebuild only the physical text and had to refuse whenever the first pass had staged
/// anything else. Retaining them here closes that gap the only sound way it can be closed: as
/// facts. Every entry is what the first pass actually wrote (a text, an index, a marker line), and
/// the consumer's re-projection is byte-equal to the first pass or it is refused.
///
/// The field is absent from the serialized report when every channel is empty — the class without
/// any of these projections serializes exactly as it did before this field existed.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceProjectionInputs {
    /// Physical method indices the assembled text omits entirely: proved array-constructor
    /// helpers and omitted lambda companions, whose every class-wide use a projection rewrote,
    /// and a `<clinit>` the assert projection left empty. The member records themselves stay in
    /// [`ClassSourceReport::methods`].
    pub omitted_methods: Vec<u64>,
    /// Physical field indices the assembled text omits: the javac assert switch field, hidden
    /// with its whole pattern (initialization line and every guard) proved rewritten to `assert`
    /// statements. The field records themselves stay in [`ClassSourceReport::fields`].
    pub hidden_fields: Vec<u64>,
    /// The marker lines the assembled text carries at the top of the class body, in order.
    pub markers: Vec<String>,
    /// The composed member texts the assembled text substitutes for those members' physical
    /// ones: each entry is the exact text the first pass placed (declaration, markers, body).
    pub member_texts: Vec<ClassSourceProjectedMemberText>,
    /// The root's own proved enum-constant projection, as the texts it staged.
    pub enum_projection: Option<ClassSourceEnumProjectionTexts>,
}

impl ClassSourceProjectionInputs {
    /// Whether every channel is empty: the serialized form of a class without projections.
    pub fn is_empty(&self) -> bool {
        self.omitted_methods.is_empty()
            && self.hidden_fields.is_empty()
            && self.markers.is_empty()
            && self.member_texts.is_empty()
            && self.enum_projection.is_none()
    }
}

/// One member's projected text, as the first pass placed it into the assembled class text.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceProjectedMemberText {
    /// The unchanged physical `method_info` table index of the member this text substitutes.
    pub member: u64,
    /// The composed text: the member's own declaration and markers, the projection's added
    /// marker lines, and the projected body placed inside them.
    pub text: String,
    /// The projected body this text was placed from, with the anchors a later re-spelling of
    /// that body needs. `None` for a projection this report states as text only — a renamed
    /// lambda companion, an array-constructor rewrite — whose body a later channel may keep but
    /// not re-spell, because no anchor table was emitted for it.
    pub emission: Option<ClassSourceProjectedMemberEmission>,
}

/// The re-spellable half of one projected member text: the emitted body and its own anchor table.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceProjectedMemberEmission {
    /// The emitted body artifact: envelope comments, braces, statements — the text a projection
    /// re-emitted from the member's own same-run program with its edits applied.
    pub body: String,
    /// The marker lines the projection added beside the member's own markers.
    pub extra_markers: Vec<String>,
    /// The emitted body's anchor table: byte ranges in `body` with the physical instruction
    /// positions their nodes came from. Only segments anchored to this member are retained; a
    /// spliced-in donor body (an inlined companion) keeps its own member's anchors and is not
    /// re-spellable through this table.
    pub segments: Vec<ClassSourceBodySegment>,
}

/// One anchor of a projected member emission: a byte range and the physical positions it states.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceBodySegment {
    /// Start of the range, in bytes of [`ClassSourceProjectedMemberEmission::body`].
    pub start: u64,
    /// End of the range, in bytes of the same body.
    pub end: u64,
    /// The bytecode indexes of the physical instructions this range's nodes came from.
    pub bcis: Vec<u32>,
}

/// The root's own enum-constant projection as staged texts: the constants list, the source
/// constructors and the static initializer suffix, with the physical indices they replace or
/// omit. A stopped or refused proof never reaches this retention.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceEnumProjectionTexts {
    /// Physical field indices of the projected enum constants.
    pub constant_field_indices: Vec<u64>,
    /// The backing array field the projection's constants replaced.
    pub backing_field_index: u64,
    /// Physical method indices the projection omits (`values`/`valueOf` and the like).
    pub implicit_method_indices: Vec<u64>,
    /// The constants list text, as placed.
    pub constants_text: String,
    /// The source constructor texts, each with the physical method index it replaces.
    pub constructor_texts: Vec<ClassSourceEnumConstructorText>,
    /// The proved static initializer suffix, when one was staged.
    pub initializer_text: Option<String>,
}

/// One enum constructor the projection re-spelled, keyed by the member it replaces.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ClassSourceEnumConstructorText {
    /// The unchanged physical `method_info` table index of the constructor.
    pub member: u64,
    /// The source constructor text, as placed.
    pub text: String,
}

// ---------------------------------------------------------------------------------------------
// The class file's flags, as source spells them
// ---------------------------------------------------------------------------------------------
//
// One table per declaration position (JVMS 4.1-B for a class, 4.5-A for a field, 4.6-A for a
// method), read here in one vocabulary: a modifier list has to read every bit of the one table it
// belongs to, so the bits are stated together rather than one part named from another layer and the
// rest from here. What is *not* restated is any rule about them: which of the three visibilities
// wins, that an interface is abstract by its kind, and that a body-less member is `abstract` or
// `native` are all read from the same table, below.

/// `ACC_PUBLIC` (JVMS 4.1-B).
const ACC_PUBLIC: u16 = 0x0001;
/// `ACC_PRIVATE` (JVMS 4.1-B).
const ACC_PRIVATE: u16 = 0x0002;
/// `ACC_PROTECTED` (JVMS 4.1-B).
const ACC_PROTECTED: u16 = 0x0004;
/// `ACC_FINAL` (JVMS 4.1-B).
const ACC_FINAL: u16 = 0x0010;
/// `ACC_STATIC` (JVMS 4.1-B/4.5-A/4.6-A): a class's own `static` describes a nesting this
/// presentation does not claim, so only a member's is written.
const ACC_STATIC: u16 = 0x0008;
/// `ACC_SYNCHRONIZED` on a method, `ACC_SUPER` on a class (JVMS 4.1-B/4.6-A): one bit, two
/// meanings, decided by the table it is read in.
const ACC_SYNCHRONIZED: u16 = 0x0020;
/// `ACC_VOLATILE` on a field (JVMS 4.5-A).
const ACC_VOLATILE: u16 = 0x0040;
/// `ACC_TRANSIENT` on a field, `ACC_VARARGS` on a method (JVMS 4.5-A/4.6-A): one bit, two
/// meanings, decided by the table it is read in.
const ACC_TRANSIENT: u16 = 0x0080;
/// `ACC_VARARGS` (JVMS 4.6-A): [`ACC_TRANSIENT`]'s bit in a *method's* own `access_flags`, stating
/// that the member's last parameter is the variable-arity one. It is read where the parameter list
/// is spelled ([`method_descriptor`]) and nowhere else.
const ACC_VARARGS: u16 = 0x0080;
/// `ACC_NATIVE` on a method (JVMS 4.6-A).
const ACC_NATIVE: u16 = 0x0100;
/// `ACC_INTERFACE` (JVMS 4.1-B).
const ACC_INTERFACE: u16 = 0x0200;
/// `ACC_ABSTRACT` (JVMS 4.1-B/4.6-A).
const ACC_ABSTRACT: u16 = 0x0400;
/// `ACC_STRICT` (JVMS 4.1-B/4.6-A).
const ACC_STRICT: u16 = 0x0800;
/// `ACC_ANNOTATION` (JVMS 4.1-B).
const ACC_ANNOTATION: u16 = 0x2000;
/// `ACC_ENUM` (JVMS 4.1-B): a class declared `enum`, or a field holding an enum constant.
const ACC_ENUM: u16 = 0x4000;

fn is_static(access_flags: u16) -> bool {
    access_flags & ACC_STATIC != 0
}

// ---------------------------------------------------------------------------------------------
// Names and descriptors, as Java source spells them
// ---------------------------------------------------------------------------------------------

/// One internal name as source spells a **reference** to it: `/` becomes `.` and nothing else
/// happens.
///
/// This is the spelling of every type a declaration names and does not declare: a `super_class`, the
/// interfaces of an `implements`/`extends` list, and a member's own `throws` clause. The one change
/// is deliberate. Turning `p.Outer$Inner` into a nesting relation, or splitting a name into a
/// package and a simple name, would be inventing structure the class file does not state; `$` is a
/// legal Java identifier character, and the name stays the one the bytes carry.
fn class_name(raw: &[u8]) -> String {
    String::from_utf8_lossy(raw).replace('/', ".")
}

/// The simple name one internal name states: everything after its last `/`, with `$` kept.
///
/// This is the name a class's **own** declaration and its constructors are spelled with. The package
/// the name states before that `/` is not dropped: it is written as the text's `package` statement
/// ([`package_name`]), which is the one place Java source states it. Only the last `/` is a package
/// boundary — `$` is a legal Java identifier character, so `p/More17$1` states the simple name
/// `More17$1`, exactly as `p/Outer$Inner` states `Outer$Inner`.
fn simple_name(raw: &[u8]) -> String {
    let simple = match raw.iter().rposition(|byte| *byte == b'/') {
        Some(position) => &raw[position + 1..],
        None => raw,
    };
    String::from_utf8_lossy(simple).into_owned()
}

/// The package one internal name states, as a `package` statement spells it, or `None` for a name
/// that states none (the default package).
///
/// The package is the internal name in front of its last `/`, with every remaining `/` written as
/// `.` — the same rule [`class_name`] applies to the whole name. `None` means the text writes no
/// `package` line at all: a name with no `/` is in the unnamed package, which source spells with no
/// statement rather than with an empty one.
fn package_name(raw: &[u8]) -> Option<String> {
    let position = raw.iter().rposition(|byte| *byte == b'/')?;
    Some(String::from_utf8_lossy(&raw[..position]).replace('/', "."))
}

/// The name the text writes for one raw member name, and whether it had to be changed.
///
/// The change is [`alias_for`]'s and it is deterministic: a raw name Java cannot spell (a method
/// named `foo-bar`) becomes the alias that function states, and the marker the caller writes says
/// which raw name that alias came from. `<init>` and `<clinit>` never reach this rule — they are
/// spelled as the declarations they are — and a name that is already an identifier is unchanged.
fn written_name(raw: &[u8]) -> (String, bool) {
    let text = String::from_utf8_lossy(raw).into_owned();
    if is_java_identifier(&text) {
        (text, false)
    } else {
        (alias_for(&text), true)
    }
}

/// One descriptor component as Java source spells its type.
///
/// The spelling is the recovery layer's own ([`type_of_component`]), so this presentation and the
/// statements of a recovered body cannot disagree about how a type is written: a primitive is the
/// primitive's own name, and an array is spelled from its element outwards with one `[]` per
/// dimension. Nothing about the production is read here — the reader states it
/// ([`jarde_reader::classfile::descriptor_facts`]) — and an object name Java cannot write is
/// refused rather than spelled lossily into a type position.
fn source_type(component: &DescriptorComponent) -> Option<String> {
    Some(type_of_component(component)?.spell().to_owned())
}

/// One field descriptor as Java source spells it (JVMS 4.3.2), or `None` when the bytes are not
/// that production.
fn field_type(descriptor: &[u8]) -> Option<String> {
    let facts = descriptor_facts(descriptor, DescriptorKind::Field).ok()?;
    source_type(facts.single()?)
}

/// One method descriptor as this presentation writes its declaration.
#[derive(Clone, Debug, Eq, PartialEq)]
struct Signature {
    /// The parameters in declaration order: the type as Java spells it, and the **local slot** the
    /// parameter occupies, with the receiver counted.
    ///
    /// The type is the array spelling the descriptor states — one `[]` per dimension — because that
    /// is the type the descriptor's component names ([`source_type`]); which of the parameters is
    /// written with the dots of [`Self::varargs`] is the **list's** own rule and is applied where
    /// the list is written ([`arguments`]).
    ///
    /// The slot is the JVM layer's derivation from the descriptor's own facts
    /// ([`parameter_positions`]): `this` holds slot 0 of a member that is not `static`, and each
    /// parameter starts where the one before it ended — a `long`/`double` filling two slots and
    /// **an array of either filling one**, like every other array.
    parameters: Vec<(String, u16)>,
    /// Whether the declaration's **last** parameter is written `T...`: true exactly when the
    /// member's own `ACC_VARARGS` is set and the descriptor's last parameter is an array, which is
    /// the one shape the flag can apply to (see [`method_descriptor`]).
    ///
    /// It is stated here and not spelled into [`Self::parameters`] because it is a fact about the
    /// parameter **list** — the last position, and only the last — while each entry above is the
    /// type its own component names.
    varargs: bool,
    /// The return type, or `None` for `V`.
    returns: Option<String>,
    /// How many slots the parameters occupy together, the receiver included: the first slot a body
    /// of this member may declare a local in.
    slots: u16,
}

/// One method descriptor as Java source spells it, or `None` when the bytes are not that production
/// or state a type this presentation cannot write.
///
/// The descriptor is read **once**, by the reader's own facts, and everything the declaration needs
/// comes from that one reading: the types are the recovery layer's spelling of the reader's
/// components, and the slots are the JVM layer's derivation from those same components. So a
/// signature's parameter names and the body's references to them are one reading of one descriptor
/// — never two parses that could place a parameter in two different slots.
///
/// `varargs` is the member's own `ACC_VARARGS` (0x0080), the one fact of the declaration that the
/// descriptor does not state. It reaches the **last** parameter and only when that parameter is an
/// array: `[I` is written `int...` and `[[B` is written `byte[]...` — the element type, then the
/// `[]` it still has, then the dots the last `[]` became. A member whose flag is set and whose last
/// parameter is not an array states no `...` at all: the flag is carried by no position, and the
/// parameters are written as the descriptor states them.
fn method_descriptor(descriptor: &[u8], is_static: bool, varargs: bool) -> Option<Signature> {
    let facts = descriptor_facts(descriptor, DescriptorKind::Method).ok()?;
    let positions = parameter_positions(&facts, is_static)?;
    let parameters = facts
        .parameters()
        .iter()
        .zip(positions)
        .map(|(component, slot)| Some((source_type(component)?, slot)))
        .collect::<Option<Vec<(String, u16)>>>()?;
    // The two facts meet here, and neither alone states a `...`: the member's own flag states that
    // its last parameter is the variable-arity one, and the descriptor's own last component states
    // whether there is an array for that to mean. An array parameter of a member without the flag
    // keeps its brackets, and a flag on a member whose last parameter is not an array is written as
    // the descriptor states it.
    let varargs = varargs
        && facts
            .parameters()
            .last()
            .is_some_and(DescriptorComponent::is_array);
    let returns = match facts.result() {
        Some(component) => Some(source_type(component)?),
        None => None,
    };
    let slots = u16::from(!is_static).checked_add(facts.parameter_slots()?)?;
    Some(Signature {
        parameters,
        varargs,
        returns,
        slots,
    })
}

/// The declaration line one class is written as, without its opening brace.
///
/// The kind comes from the class file's own flags — `@interface`, `interface`, `enum` or `class` —
/// and so does everything else here:
///
/// * only the modifiers source spells are written, and one that the kind already means is not
///   repeated (`abstract` on an interface, `abstract`/`final` on an enum);
/// * a class's superclass is written from `super_class`, which the format requires to be present for
///   every class that is not `module-info`;
/// * an ordinary interface's `extends` list is the interfaces the class file declares, because its
///   own `super_class` is `java/lang/Object` by the format's rule and is not a source superclass;
///   a canonical annotation's implicit `Annotation` interface remains in the facts but is omitted
///   from the `@interface` header.
fn class_declaration(name: &str, facts: &ClassDeclarationFacts) -> String {
    class_declaration_with_types(name, facts, None, None, None)
}

pub(crate) fn nested_member_class_header(name: &str, facts: &ClassDeclarationFacts) -> String {
    class_declaration(name, facts)
}

fn class_declaration_with_types(
    name: &str,
    facts: &ClassDeclarationFacts,
    parameters: Option<&str>,
    generic_superclass: Option<&str>,
    generic_interfaces: Option<&[String]>,
) -> String {
    let flags = facts.access_flags;
    let interface = flags & ACC_INTERFACE != 0;
    let canonical_annotation = flags & (ACC_ANNOTATION | ACC_INTERFACE)
        == (ACC_ANNOTATION | ACC_INTERFACE)
        && facts.interfaces.len() == 1
        && facts.interfaces[0].raw().0 == b"java/lang/annotation/Annotation";
    let enumeration = !interface && flags & ACC_ENUM != 0;
    let mut words: Vec<&str> = Vec::new();
    words.extend(visibility(flags));
    if !interface {
        if flags & ACC_ABSTRACT != 0 && !enumeration {
            words.push("abstract");
        }
        if flags & ACC_FINAL != 0 && !enumeration {
            words.push("final");
        }
        if flags & ACC_STRICT != 0 {
            words.push("strictfp");
        }
    }
    let kind = if flags & ACC_ANNOTATION != 0 {
        "@interface"
    } else if interface {
        "interface"
    } else if enumeration {
        "enum"
    } else {
        "class"
    };
    let mut line = String::new();
    for word in words {
        line.push_str(word);
        line.push(' ');
    }
    line.push_str(kind);
    line.push(' ');
    line.push_str(name);
    if let Some(parameters) = parameters {
        line.push('<');
        line.push_str(parameters);
        line.push('>');
    }
    if canonical_annotation {
        return line;
    }
    let supers: Vec<String> = generic_interfaces
        .map(<[String]>::to_vec)
        .unwrap_or_else(|| {
            facts
                .interfaces
                .iter()
                .map(|interface| class_name(&interface.raw().0))
                .collect()
        });
    if interface {
        if !supers.is_empty() {
            line.push_str(" extends ");
            line.push_str(&supers.join(", "));
        }
        return line;
    }
    if !enumeration && let Some(super_class) = &facts.super_class {
        line.push_str(" extends ");
        if let Some(generic_superclass) = generic_superclass {
            line.push_str(generic_superclass);
        } else {
            line.push_str(&class_name(&super_class.raw().0));
        }
    }
    if !supers.is_empty() {
        line.push_str(" implements ");
        line.push_str(&supers.join(", "));
    }
    line
}

/// The names the parameters of one member are written with, in **slot** order: index 0 is slot 0,
/// which is the receiver of a member that is not `static` and the first parameter of one that is.
///
/// The names are the recovery layer's own — [`NameTable`] over the debug names the member's run
/// read — so the signature and the body spell one parameter the same way: a slot the debug table
/// names once takes that name (aliased when Java cannot spell it), a slot it names over several
/// records takes the first variable's name, and a slot it does not name takes the ordinal name the
/// naming table invents (`arg<slot>`), which is exactly what the body's statements say.
///
/// A member no run was performed for — one that declares no body, one that could not be spelled —
/// carries no debug names at all, so its parameters take those ordinal names. That is a rule of this
/// presentation's, stated here, and not a claim about the source: the class file does not state
/// parameter names, and the debug table is the only place one may come from.
fn parameter_names(facts: Option<&RecoveryFacts>, slots: u16) -> Vec<String> {
    let mut records: Vec<Vec<String>> = vec![Vec::new(); usize::from(slots)];
    for record in facts.into_iter().flat_map(|facts| facts.debug_locals()) {
        if let Some(names) = records.get_mut(usize::from(record.slot())) {
            names.push(record.name().to_owned());
        }
    }
    let evidence: Vec<SlotEvidence> = records
        .into_iter()
        .map(|names| match names.len() {
            0 => SlotEvidence::Unnamed,
            1 => SlotEvidence::Whole(names[0].clone()),
            _ => SlotEvidence::Split(names.into_iter().map(Some).collect()),
        })
        .collect();
    let table = if facts.is_some_and(|facts| facts.method().has_receiver()) {
        NameTable::build_with_receiver(slots, slots, &evidence)
    } else {
        NameTable::build(slots, slots, &evidence)
    };
    (0..slots)
        .map(|slot| {
            table
                .name(LocalVariable::new(slot, 0))
                .map(|name| name.text().to_owned())
                .unwrap_or_else(|| format!("arg{slot}"))
        })
        .collect()
}

/// One raw name or descriptor, as a comment line can carry it.
///
/// Two steps, both of them the engine's own: the reader's escaped display of the bytes
/// ([`JvmString::escaped`]), then [`comment_text`], which is what makes the result safe inside a
/// `//` comment. The second step is not cosmetic — Java processes `\uXXXX` before it lexes, so a
/// comment carrying one would end the line it is written on, which is the hazard the recovery
/// layer's own emitter states for its reasons.
fn comment_name(value: &JvmString) -> String {
    comment_text(&value.escaped())
}

/// How one member is named inside a marker: its own raw name and descriptor, as the recovery
/// report's `method` field spells them (`name` then `descriptor`, no separator).
fn label(item: &MethodItem) -> String {
    format!(
        "{}{}",
        comment_name(&item.name),
        comment_name(&item.descriptor)
    )
}

/// The visibility Java source spells, or nothing at all for a package-private declaration.
fn visibility(access_flags: u16) -> Option<&'static str> {
    if access_flags & ACC_PUBLIC != 0 {
        Some("public")
    } else if access_flags & ACC_PROTECTED != 0 {
        Some("protected")
    } else if access_flags & ACC_PRIVATE != 0 {
        Some("private")
    } else {
        None
    }
}

/// One member's declaration as this presentation spells it, with the marker its spelling needs.
///
/// The request's own orchestration reads this value: it spells a member *before* deciding whether to
/// run a recovery for it ([`spellable_descriptor`]), so a member whose declaration cannot be written is never
/// given a run that could not be placed anywhere.
pub(crate) struct Spelled {
    /// The declaration, without a terminating `;` and without an opening brace. `None` exactly when
    /// the member's raw descriptor is not one this presentation can read as the descriptor of its
    /// kind.
    pub(crate) declaration: Option<String>,
    /// The marker the spelling itself needs: an alias for a name Java cannot spell, or the statement
    /// that no declaration could be written at all. `None` when the declaration is faithful.
    pub(crate) marker: Option<String>,
    pub(crate) annotations: MemberAnnotationUses,
    pub(crate) parameter_annotations: ParameterAnnotationUses,
    pub(crate) type_annotations: TypeAnnotationUses,
}

/// Whether this presentation can write a declaration for a member whose raw descriptor these bytes
/// are: a method descriptor (JVMS 4.3.3) whose every type is one Java source spells.
///
/// A member this answers `false` for is published as
/// [`ClassSourceOutcome::Unspelled`](crate::ClassSourceOutcome::Unspelled), and no recovery run is
/// performed for it — a run whose artifact could not be placed under a declaration would be work
/// whose result this presentation has nowhere to write.
pub(crate) fn spellable_descriptor(descriptor: &[u8]) -> bool {
    match descriptor_facts(descriptor, DescriptorKind::Method) {
        Ok(facts) => facts
            .components()
            .all(|component| type_of_component(component).is_some()),
        Err(_) => false,
    }
}

/// Whether one member's own attribute table declares an attribute of this name.
///
/// The name is compared against the shell's own raw bytes, which is what the class file states; the
/// attributes this presentation reads are the declaration attributes whose content it spells
/// (`ConstantValue`, `Exceptions`, `AnnotationDefault`).
fn declares_attribute(member: &MemberHeader, name: &[u8]) -> bool {
    member
        .attributes
        .iter()
        .any(|shell| shell.name.raw().0.as_slice() == name)
}

/// The attribute shells of one member whose own name is this one, in table order.
fn attribute_shells(member: &MemberHeader, name: &[u8]) -> Vec<AttributeShell> {
    member
        .attributes
        .iter()
        .filter(|shell| shell.name.raw().0.as_slice() == name)
        .cloned()
        .collect()
}

/// Whether one member's own declaration annotation table has a content shell to read.
pub(crate) fn declares_member_annotations(member: &MemberHeader) -> bool {
    member.attributes.iter().any(|shell| {
        matches!(
            shell.name.raw().0.as_slice(),
            b"RuntimeVisibleAnnotations"
                | b"RuntimeInvisibleAnnotations"
                | b"RuntimeVisibleTypeAnnotations"
                | b"RuntimeInvisibleTypeAnnotations"
        )
    })
}

/// Whether one method's own parameter annotation table has a content shell to read.
pub(crate) fn declares_parameter_annotations(member: &MemberHeader) -> bool {
    member.attributes.iter().any(|shell| {
        matches!(
            shell.name.raw().0.as_slice(),
            b"RuntimeVisibleParameterAnnotations" | b"RuntimeInvisibleParameterAnnotations"
        )
    })
}

/// Reads only the member's declaration, parameter and type-annotation attributes, preserving every
/// shell even when its contents stop. Invalid content is local to its own shell; a budget refusal or
/// cancellation stops before any later shell is read.
pub(crate) fn declared_member_annotations(
    bytes: &[u8],
    member: &MemberHeader,
    pool: &[CpEntryFacts],
    budget: &mut Budget,
) -> MemberAnnotationRead {
    let mut facts = MemberAnnotationFacts::default();
    let mut errors = Vec::new();
    let shells = member
        .attributes
        .iter()
        .filter(|shell| {
            matches!(
                shell.name.raw().0.as_slice(),
                b"RuntimeVisibleAnnotations"
                    | b"RuntimeInvisibleAnnotations"
                    | b"RuntimeVisibleParameterAnnotations"
                    | b"RuntimeInvisibleParameterAnnotations"
                    | b"RuntimeVisibleTypeAnnotations"
                    | b"RuntimeInvisibleTypeAnnotations"
            )
        })
        .cloned()
        .collect::<Vec<_>>();
    // Attribute names are unique within their owning table. Treat repeated shells as one local
    // structural refusal while leaving other, independent annotation attributes readable.
    let mut counts = std::collections::BTreeMap::<Vec<u8>, usize>::new();
    for shell in &shells {
        *counts.entry(shell.name.raw().0.clone()).or_default() += 1;
    }
    let mut duplicate_errors = std::collections::BTreeSet::<Vec<u8>>::new();
    let mut stopped = false;
    for (index, shell) in shells.iter().enumerate() {
        let name = shell.name.raw().0.as_slice();
        let parameter = matches!(
            name,
            b"RuntimeVisibleParameterAnnotations" | b"RuntimeInvisibleParameterAnnotations"
        );
        let type_annotation = matches!(
            name,
            b"RuntimeVisibleTypeAnnotations" | b"RuntimeInvisibleTypeAnnotations"
        );
        let duplicate = counts.get(name).copied().unwrap_or_default() > 1;
        if stopped || duplicate {
            let reason = if stopped {
                "annotation content read stopped before this attribute".to_owned()
            } else {
                let error = Error::invalid_input(
                    "classfile_duplicate_attribute",
                    format!(
                        "member declares more than one {} attribute",
                        String::from_utf8_lossy(name)
                    ),
                );
                if duplicate_errors.insert(name.to_vec()) {
                    errors.push(error.clone());
                }
                error.to_string()
            };
            push_unread_annotation_shell(
                &mut facts,
                shell.clone(),
                parameter,
                type_annotation,
                reason,
            );
            continue;
        }
        let parsed = attribute_facts(bytes, std::slice::from_ref(shell), pool, budget);
        match parsed {
            Ok(parsed) => push_parsed_annotation_shell(&mut facts, shell.clone(), &parsed),
            Err(error) => {
                push_unread_annotation_shell(
                    &mut facts,
                    shell.clone(),
                    parameter,
                    type_annotation,
                    format!("annotation attribute read stopped: {error}"),
                );
                let ends = matches!(
                    error,
                    Error::BudgetExceeded { .. } | Error::Cancelled { .. }
                );
                errors.push(error);
                stopped = ends;
            }
        }
        if stopped {
            for pending in &shells[index + 1..] {
                let pending_name = pending.name.raw().0.as_slice();
                let parameter = matches!(
                    pending_name,
                    b"RuntimeVisibleParameterAnnotations" | b"RuntimeInvisibleParameterAnnotations"
                );
                let type_annotation = matches!(
                    pending_name,
                    b"RuntimeVisibleTypeAnnotations" | b"RuntimeInvisibleTypeAnnotations"
                );
                push_unread_annotation_shell(
                    &mut facts,
                    pending.clone(),
                    parameter,
                    type_annotation,
                    "annotation content read stopped before this attribute".to_owned(),
                );
            }
            break;
        }
    }
    MemberAnnotationRead { facts, errors }
}

fn push_parsed_annotation_shell(
    facts: &mut MemberAnnotationFacts,
    shell: AttributeShell,
    parsed: &jarde_reader::classfile::AttributeFacts,
) {
    match shell.name.raw().0.as_slice() {
        b"RuntimeVisibleAnnotations" => {
            facts
                .declaration
                .attributes
                .push(MemberAnnotationAttribute {
                    attribute: shell,
                    annotations: parsed.runtime_visible_annotations.clone(),
                })
        }
        b"RuntimeInvisibleAnnotations" => {
            facts
                .declaration
                .attributes
                .push(MemberAnnotationAttribute {
                    attribute: shell,
                    annotations: parsed.runtime_invisible_annotations.clone(),
                })
        }
        b"RuntimeVisibleParameterAnnotations" => {
            let parsed = parsed.runtime_visible_parameter_annotations.as_ref();
            facts
                .parameters
                .attributes
                .push(ParameterAnnotationAttribute {
                    attribute: shell,
                    parameter_count: parsed.map(|annotations| annotations.parameter_count),
                    parameters: parsed
                        .map_or_else(Vec::new, |annotations| annotations.parameters.clone()),
                });
        }
        b"RuntimeInvisibleParameterAnnotations" => {
            let parsed = parsed.runtime_invisible_parameter_annotations.as_ref();
            facts
                .parameters
                .attributes
                .push(ParameterAnnotationAttribute {
                    attribute: shell,
                    parameter_count: parsed.map(|annotations| annotations.parameter_count),
                    parameters: parsed
                        .map_or_else(Vec::new, |annotations| annotations.parameters.clone()),
                });
        }
        b"RuntimeVisibleTypeAnnotations" | b"RuntimeInvisibleTypeAnnotations" => {
            let annotations = if shell.name.raw().0 == b"RuntimeVisibleTypeAnnotations" {
                &parsed.runtime_visible_type_annotations
            } else {
                &parsed.runtime_invisible_type_annotations
            };
            facts.type_uses.attributes.push(TypeAnnotationAttribute {
                attribute: shell,
                annotations: annotations.iter().map(unspelled_type_annotation).collect(),
            });
        }
        _ => unreachable!("only member annotation attributes are passed"),
    }
}

fn push_unread_annotation_shell(
    facts: &mut MemberAnnotationFacts,
    shell: AttributeShell,
    parameter: bool,
    type_annotation: bool,
    reason: String,
) {
    if type_annotation {
        facts.type_uses.attributes.push(TypeAnnotationAttribute {
            attribute: shell,
            annotations: Vec::new(),
        });
        facts.type_uses.refusals.push(reason);
    } else if parameter {
        facts
            .parameters
            .attributes
            .push(ParameterAnnotationAttribute {
                attribute: shell,
                parameter_count: None,
                parameters: Vec::new(),
            });
        facts.parameters.refusals.push(reason);
    } else {
        facts
            .declaration
            .attributes
            .push(MemberAnnotationAttribute {
                attribute: shell,
                annotations: Vec::new(),
            });
        facts.declaration.refusals.push(reason);
    }
}

fn unspelled_type_annotation(fact: &TypeAnnotationFacts) -> TypeAnnotationUse {
    TypeAnnotationUse {
        target_type: fact.target_type,
        target_info: fact.target_info.clone(),
        type_path: fact.type_path.clone(),
        annotation: fact.annotation.clone(),
        spelling: None,
        refusal: None,
    }
}

/// Whether one member's own attribute table declares an `AnnotationDefault` attribute (JVMS 4.7.22).
///
/// This is the one predicate behind the two decisions the class-source orchestration makes about that
/// attribute: whether the class's constant pool has to be resolved at all (a class none of whose
/// members declares one spells no `default` and reads no pool for it), and whether this member has an
/// attribute to read.
pub(crate) fn declares_annotation_default(member: &MemberHeader) -> bool {
    declares_attribute(member, b"AnnotationDefault")
}

/// Whether one member's own attribute table declares an `Exceptions` attribute (JVMS 4.7.4).
///
/// It is [`declares_annotation_default`]'s own rule for that attribute: the pool a member's
/// `throws` clause is spelled from is resolved only when some member really declares one, and a
/// member that declares none has nothing to read.
pub(crate) fn declares_exceptions(member: &MemberHeader) -> bool {
    declares_attribute(member, b"Exceptions")
}

pub(crate) fn declares_signature(member: &MemberHeader) -> bool {
    declares_attribute(member, b"Signature")
}

/// Whether one field's own attribute table declares a `ConstantValue` attribute (JVMS 4.7.2).
pub(crate) fn declares_constant_value(field: &MemberHeader) -> bool {
    declares_attribute(field, b"ConstantValue")
}

/// The default one member's own `AnnotationDefault` attribute states (JVMS 4.7.22), resolved against
/// the class's constant pool as far as this presentation spells it, or `None` when no `default` is
/// written.
///
/// The read is [`attribute_facts`] over this member's own `AnnotationDefault` shell(s) — the reader's
/// one parser for that attribute, and only those shells are handed over, so the `attribute_bytes`
/// charge is exactly this attribute's — and nothing here reads a body, a use site or another member:
/// the declaration default is the value the member's own attribute declares.
///
/// `None` is exactly the state "nothing to write", and it is never a stop of the request: the member
/// declares no `AnnotationDefault` at all, or its value is one this presentation has no literal for.
/// Those include an unspellable NaN bit pattern, a nested annotation with an invalid source name,
/// and an array holding one of those (see [`MemberDefault`]). The member keeps
/// the declaration its flags and its descriptor state, which is what the class file's *other* facts
/// say about it; not one literal is invented for it.
///
/// An `Err` is the reader's own failure to read the attribute (its bytes are damaged, its charge was
/// refused, the request was cancelled): the caller decides what that is worth — a budget or a
/// cancellation is the request's own stop, exactly as a refused `Exceptions` read is.
pub(crate) fn declared_annotation_default(
    bytes: &[u8],
    member: &MemberHeader,
    pool: &[CpEntryFacts],
    budget: &mut Budget,
) -> Result<Option<MemberDefault>> {
    if !declares_annotation_default(member) {
        return Ok(None);
    }
    let shells = attribute_shells(member, b"AnnotationDefault");
    let Some(value) = attribute_facts(bytes, &shells, pool, budget)?.annotation_default else {
        return Ok(None);
    };
    Ok(resolve_default(&value, pool))
}

/// The declaration facts one member's own attribute table states, as its declaration writes them.
///
/// `Exceptions` is read once from this member's own shells, in attribute order. Its raw names
/// prove a generic `Signature`'s optional throws suffix; its source spellings keep the same
/// declaration clause before and after the member's recovery run.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct MemberAttributes {
    /// The member's own `AnnotationDefault` (JVMS 4.7.22), when it declares one this presentation
    /// has a literal for.
    pub(crate) default: Option<MemberDefault>,
    /// The exception types the member's own `Exceptions` attribute (JVMS 4.7.4) states, in the
    /// attribute's own order; empty when the member declares none.
    pub(crate) throws: Vec<String>,
    /// The same physical exception names before source spelling, for signature erasure proof.
    pub(crate) throws_raw: Vec<Vec<u8>>,
    /// A complete descriptor-to-slot projection of this member's parameter attribute.
    pub(crate) parameters: Option<Vec<ProvedMethodParameter>>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct ProvedMethodParameter {
    pub(crate) slot: u16,
    pub(crate) name: String,
    pub(crate) is_final: bool,
}

fn prove_method_parameters(
    entries: &[jarde_reader::classfile::MethodParameterFacts],
    descriptor: &[u8],
    flags: u16,
) -> Option<Vec<ProvedMethodParameter>> {
    let signature = method_descriptor(descriptor, is_static(flags), flags & ACC_VARARGS != 0)?;
    if entries.len() != signature.parameters.len() || flags & (0x1000 | 0x0040) != 0 {
        return None;
    }
    let mut used = std::collections::BTreeSet::new();
    let parameters: Vec<ProvedMethodParameter> = entries
        .iter()
        .zip(signature.parameters.iter())
        .map(|(entry, (_, slot))| {
            if entry.access_flags & (0x1000 | 0x8000) != 0 {
                return None;
            }
            let name = std::str::from_utf8(&entry.name.as_ref()?.0).ok()?;
            if !is_java_identifier(name) || !used.insert(name.to_owned()) {
                return None;
            }
            Some(ProvedMethodParameter {
                slot: *slot,
                name: name.to_owned(),
                is_final: entry.access_flags & ACC_FINAL != 0,
            })
        })
        .collect::<Option<_>>()?;
    let mut evidence = vec![SlotEvidence::Unnamed; usize::from(signature.slots)];
    for parameter in &parameters {
        evidence[usize::from(parameter.slot)] = SlotEvidence::Whole(parameter.name.clone());
    }
    let table = if is_static(flags) {
        NameTable::build(signature.slots, signature.slots, &evidence)
    } else {
        NameTable::build_with_receiver(signature.slots, signature.slots, &evidence)
    };
    parameters
        .iter()
        .all(|parameter| {
            table
                .name(LocalVariable::whole(parameter.slot))
                .is_some_and(|name| name.text() == parameter.name)
        })
        .then_some(parameters)
}

/// The declaration facts one member's own attribute table states (JVMS 4.7.4, 4.7.22).
///
/// A member that declares neither attribute is read by neither reader (both answer from the shells
/// the member really has), and an `Err` is the first read that failed: a member whose own attributes
/// cannot be read has no declaration this presentation can state faithfully, which is the caller's
/// own decision to make — see [`declared_annotation_default`].
pub(crate) fn declared_member_attributes(
    bytes: &[u8],
    member: &MemberHeader,
    pool: &[CpEntryFacts],
    budget: &mut Budget,
) -> Result<MemberAttributes> {
    let default = declared_annotation_default(bytes, member, pool, budget)?;
    let throws_raw = if declares_exceptions(member) {
        attribute_facts(
            bytes,
            &attribute_shells(member, b"Exceptions"),
            pool,
            budget,
        )?
        .exceptions
        .iter()
        .map(|name| name.0.clone())
        .collect()
    } else {
        Vec::new()
    };
    let parameters = if member
        .attributes
        .iter()
        .any(|attribute| attribute.name.raw().0 == b"MethodParameters")
    {
        let entries = attribute_facts(
            bytes,
            &attribute_shells(member, b"MethodParameters"),
            pool,
            budget,
        )?
        .method_parameters;
        if let Some(entries) = entries {
            budget.charge(
                CountedBudgetDimension::AnalysisSteps,
                u64::try_from(member.descriptor.raw().0.len())
                    .unwrap_or(u64::MAX)
                    .saturating_add(
                        u64::try_from(entries.len())
                            .unwrap_or(u64::MAX)
                            .saturating_mul(4),
                    ),
            )?;
            prove_method_parameters(&entries, &member.descriptor.raw().0, member.access_flags)
        } else {
            None
        }
    } else {
        None
    };
    Ok(MemberAttributes {
        default,
        throws: throws_raw.iter().map(|name| class_name(name)).collect(),
        throws_raw,
        parameters,
    })
}

/// Select only the two exact Java 8 functional targets whose source spelling this slice proves.
/// Parsing and erasure use the same path as final declaration projection; this is only a target
/// hypothesis until the direct Code, bootstrap, Program and SSA are checked in the same run.
pub(crate) fn typed_functional_signature_target(
    member: &MemberHeader,
    attributes: &MemberAttributes,
    bytes: &[u8],
    pool: &[CpEntryFacts],
    class_internal: &[u8],
    class_flags: u16,
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    class_scope: &[TypeParameterErasure],
    class_signature_present: bool,
    budget: &mut Budget,
) -> Result<Option<TypedFunctionalKind>> {
    let shells = attribute_shells(member, b"Signature");
    if shells.len() != 1
        || class_internal.contains(&b'$')
        || class_flags & (ACC_INTERFACE | ACC_ENUM | ACC_ANNOTATION) != 0
        || class_superclass != Some(b"java/lang/Object".as_slice())
        || !class_interfaces.is_empty()
        || !class_scope.is_empty()
        || class_signature_present
        || !attributes.throws_raw.is_empty()
        || member.descriptor.raw().0.as_slice() != b"()Ljava/util/function/Function;"
            && member.descriptor.raw().0.as_slice() != b"()Ljava/util/function/Supplier;"
    {
        return Ok(None);
    }
    let raw = attribute_facts(bytes, &shells, pool, budget)?
        .signature
        .ok_or_else(|| {
            Error::invalid_input(
                "jvm_signature_missing",
                "Signature attribute did not resolve",
            )
        })?
        .0;
    let parsed = parse_method_signature(&raw, budget)?;
    if !parsed.type_parameters.is_empty()
        || !parsed.parameters.is_empty()
        || !parsed.throws.is_empty()
    {
        return Ok(None);
    }
    prove_method_signature_erasure_with_class_scope(
        &parsed,
        &member.descriptor.raw().0,
        &attributes.throws_raw,
        class_scope,
        budget,
    )?;
    Ok(match raw.as_slice() {
        b"()Ljava/util/function/Function<Ljava/lang/String;Ljava/lang/Integer;>;" => {
            Some(TypedFunctionalKind::FunctionStringInteger)
        }
        b"()Ljava/util/function/Supplier<Ljava/lang/String;>;" => {
            Some(TypedFunctionalKind::SupplierString)
        }
        _ => None,
    })
}

/// The class-level state of one member's same-class binding question, as the assembly drives it.
///
/// The ordinary projection path no longer treats a same-class constant-pool entry as a refusal on
/// its own: the entry is a candidate fact, and the decision belongs to the use-site inventory the
/// class-level assembly collects over this class's own decoded bodies. [`Self::Pending`] is what
/// the member loop passes — a member whose pool holds a naming entry is held back unpublished until
/// the inventory is complete — and the commit phase passes the proof outcome for every held member.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum SameClassBinding {
    /// The use-site inventory of this presentation is still being collected: hold the candidate.
    Pending,
    /// Every actual same-class use site of the member is proved to keep binding its physical
    /// target, and no unreadable reference source names it.
    Proven,
    /// Every non-overload binding fact is closed, but an actual same-arity source overload call
    /// still needs the generic-call component's complete staged overload proof before commit.
    OverloadPending,
    /// A use site, a competing same-name declaration, or a reference source is not proved; the
    /// member keeps its erased declaration and the existing refusal.
    Unproved,
}

/// One physically decoded `invoke*` site of the selected class's own body set: the caller's own
/// label, the site's BCI and opcode, and the owner/name/descriptor the pool entry states.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SameClassInvokeUse {
    pub(crate) caller: String,
    pub(crate) physical_caller: PhysicalMethodId,
    pub(crate) bci: u32,
    pub(crate) opcode: u8,
    pub(crate) owner: Vec<u8>,
    pub(crate) name: Vec<u8>,
    pub(crate) descriptor: Vec<u8>,
    /// Physical SSA values aligned to descriptor parameter order. Empty is meaningful only when
    /// `ssa_operands_complete` is true for a zero-argument call.
    pub(crate) argument_values: Vec<jarde_jvm::method_ir::ValueId>,
    pub(crate) receiver_value: Option<jarde_jvm::method_ir::ValueId>,
    pub(crate) result_value: Option<jarde_jvm::method_ir::ValueId>,
    pub(crate) argument_value_facts: Vec<SameClassInvokeValueFact>,
    pub(crate) receiver_value_fact: Option<SameClassInvokeValueFact>,
    pub(crate) result_value_fact: Option<SameClassInvokeValueFact>,
    pub(crate) ssa_operands_complete: bool,
    /// For a constructor invocation, the receiver identity established by the same run's SSA.
    /// `None` means this is not a constructor invocation; `Unknown` stays local to this site and
    /// must not make unrelated same-class consumers incomplete.
    pub(crate) constructor_receiver: Option<SameClassConstructorReceiver>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SameClassInvokeValueFact {
    pub(crate) value: jarde_jvm::method_ir::ValueId,
    pub(crate) definition: jarde_jvm::method_ir::Definition,
    pub(crate) uses: Vec<Option<u32>>,
    pub(crate) replaced_by: Option<jarde_jvm::method_ir::ValueId>,
}

/// One same-run SSA output at an AST expression's primary BCI. Generic body proofs retain only
/// the load/result identities needed to close formal reads and return/condition/throw consumers.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SameClassBodyValueSite {
    pub(crate) bci: u32,
    pub(crate) opcode: u8,
    pub(crate) stack_reads: Vec<(u32, SameClassInvokeValueFact)>,
    pub(crate) stack_writes: Vec<SameClassInvokeValueFact>,
    pub(crate) local_reads: Vec<(u16, SameClassInvokeValueFact)>,
    pub(crate) local_writes: Vec<(u16, SameClassInvokeValueFact)>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) enum SameClassGenericBodyReturnSource {
    Parameter {
        slot: u16,
    },
    Call {
        bci: u32,
        opcode: u8,
        owner: Vec<u8>,
        name: Vec<u8>,
        descriptor: Vec<u8>,
    },
}

/// The evidence retained by the emitter for an AST-shaped generic method body. It records actual
/// physical formal identities and each return source; it is not a boolean saying that a body was
/// merely seen or parsed.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SameClassGenericMethodBodyProof {
    pub(crate) method: PhysicalMethodId,
    pub(crate) formal_names: Vec<(u16, String)>,
    pub(crate) return_sources: Vec<SameClassGenericBodyReturnSource>,
    pub(crate) condition_slots: Vec<u16>,
    pub(crate) throw_sites: Vec<u32>,
    pub(crate) field_write_sites: Vec<u32>,
    pub(crate) constructor_call_bci: Option<u32>,
    pub(crate) constructor_init: Option<jarde_java::init::InitRecord>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum SameClassConstructorReceiver {
    UninitializedThis,
    NewObject,
    Unknown,
}

/// One physically decoded field access of the selected class's own body set. A write site carries
/// its source-level proof when the RHS is one of the narrowly supported same-scope parameter,
/// literal-null, or completed raw-allocation forms; an absent proof makes the projected field
/// unsafe for that writer. A read site carries the SSA-side classification of what the loaded
/// value feeds: `Some(true)` only when every consumer keeps accepting the parameterized value (an
/// `Object`-parameter argument position, or a consumer that does not select members on it).
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SameClassFieldUse {
    pub(crate) caller: String,
    pub(crate) physical_method: PhysicalMethodId,
    pub(crate) bci: u32,
    pub(crate) opcode: u8,
    pub(crate) owner: Vec<u8>,
    pub(crate) name: Vec<u8>,
    pub(crate) descriptor: Vec<u8>,
    pub(crate) read_expressible: Option<bool>,
    pub(crate) write_source: Option<SameClassFieldWriteSource>,
    pub(crate) receiver_source: Option<SameClassFieldReceiverSource>,
    pub(crate) source_complete: bool,
}

/// A receiver fact from the actual committed source statement at this field-use BCI.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) enum SameClassFieldReceiverSource {
    This,
    Parameter { slot: u16 },
    RawLocal,
}

/// A narrowly proved source for one same-class field write. `None` on the use site means the
/// physical write was decoded but its value did not match one of these closed shapes.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) enum SameClassFieldWriteSource {
    Null,
    /// A same-run `ldc`/`ldc_w` String constant used once as a String field's physical RHS.
    /// This fact is for the narrow method-body certificate only; generic field assignment proofs
    /// deliberately do not treat it as evidence that a value satisfies a type variable.
    StringConstant {
        value_bci: u32,
    },
    Parameter {
        method: PhysicalMethodId,
        slot: u16,
    },
    RawAllocation {
        owner: Vec<u8>,
    },
}

/// The actual source parameter types and declared method bounds a completed same-class method
/// record publishes. Generic facts are present only when that method's own `Signature` projected
/// successfully; otherwise only the physical descriptor is available to the field-write proof.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SameClassPublishedMethodParameters {
    pub(crate) method: PhysicalMethodId,
    pub(crate) parameter_slots: Vec<u16>,
    pub(crate) descriptor_parameters: Vec<Vec<u8>>,
    pub(crate) generic_parameters: Option<Vec<SignatureType>>,
    pub(crate) method_type_parameters: Vec<TypeParameter>,
}

/// A member a readable but non-body reference source names: an `ldc` method handle or a
/// bootstrap-table row/argument. The first slice reads these to keep the inventory honest but does
/// not prove a functional-position target, so a candidate such a source names stays refused.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SameClassMemberRef {
    pub(crate) owner: Vec<u8>,
    pub(crate) name: Vec<u8>,
    pub(crate) descriptor: Vec<u8>,
    pub(crate) method: bool,
}

/// The bounded use-site inventory of one selected class, as the commit phase hands it to the
/// binding proofs: every decoded body's invoke and field sites, every readable non-body source,
/// and whether the scan covered every supported consumer at all.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct SameClassUseFacts<'a> {
    pub(crate) complete: bool,
    pub(crate) invokes: &'a [SameClassInvokeUse],
    pub(crate) field_uses: &'a [SameClassFieldUse],
    pub(crate) member_refs: &'a [SameClassMemberRef],
}

/// One same-class generic caller dependency. Indices are physical method-table positions, never
/// names or erased descriptors: overloads and method/class binders remain distinct.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct GenericCallDependency {
    pub(crate) caller: usize,
    pub(crate) callee: usize,
}

/// A connected set of candidate declarations that must stage or roll back together. `order` is
/// callee-first; a cyclic component has no safe order and is rejected without retrying inference.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct GenericCallComponent {
    pub(crate) members: Vec<usize>,
    pub(crate) order: Option<Vec<usize>>,
}

/// The published generic contract read from one physical same-class method. The caller may use
/// this only after the matching declaration has been staged from the same Signature and erasure
/// proof; its physical identity keeps overloaded methods and method binders separate.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SameClassGenericMethodContract {
    pub(crate) method: PhysicalMethodId,
    pub(crate) method_parameters: Vec<TypeParameter>,
    pub(crate) parameters: Vec<SignatureType>,
    pub(crate) result: Option<SignatureType>,
}

/// Source type proved at one invocation argument. Only a direct emitted parameter is admitted in
/// overload selection; generic substitution can additionally receive an exact nested call result
/// whose own callee and uses were proved first. Casts, aliases, unknown locals, and AST `presented`
/// types do not create a source type.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SameClassGenericArgumentSource {
    pub(crate) caller: PhysicalMethodId,
    pub(crate) origin: SameClassGenericArgumentOrigin,
    pub(crate) source_type: SignatureType,
    pub(crate) caller_method_parameters: Vec<TypeParameter>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) enum SameClassGenericArgumentOrigin {
    Formal {
        slot: u16,
    },
    NullLiteral,
    NestedCall {
        bci: u32,
        opcode: u8,
        owner: Vec<u8>,
        name: Vec<u8>,
        descriptor: Vec<u8>,
    },
}

/// A consistent invocation substitution for the callee's method-level type variables.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SameClassGenericSubstitution {
    pub(crate) method_arguments: Vec<SignatureType>,
    pub(crate) argument_sources: Vec<SameClassGenericArgumentSource>,
}

/// Prove direct type-variable substitution and all explicit bounds for one invocation. The
/// caller's and callee's method binders are resolved before their shared class scope, so a method
/// `T` shadowing class `T` cannot silently become the class variable. Only direct formal source
/// types are accepted here; general expressions need their own source proof.
pub(crate) fn prove_same_class_generic_substitution(
    class_scope: &[TypeParameterErasure],
    class_parameters: &[TypeParameter],
    callee: &SameClassGenericMethodContract,
    actuals: &[SameClassGenericArgumentSource],
    budget: &mut Budget,
) -> Result<Option<SameClassGenericSubstitution>> {
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(callee.parameters.len().saturating_add(actuals.len())).unwrap_or(u64::MAX),
    )?;
    if callee.parameters.len() != actuals.len() {
        return Ok(None);
    }
    let mut method_arguments: Vec<Option<SignatureType>> =
        vec![None; callee.method_parameters.len()];
    for (parameter, actual) in callee.parameters.iter().zip(actuals) {
        budget.poll()?;
        if !same_class_call_type_matches(
            parameter,
            &actual.source_type,
            class_scope,
            class_parameters,
            &callee.method_parameters,
            &actual.caller_method_parameters,
            &mut method_arguments,
            budget,
            0,
        )? {
            return Ok(None);
        }
    }
    if method_arguments.iter().any(Option::is_none) {
        // An unconstrained type variable cannot be inferred from a null, omitted, or otherwise
        // unobserved argument. It must have one direct source at an actual parameter position.
        return Ok(None);
    }
    Ok(Some(SameClassGenericSubstitution {
        method_arguments: method_arguments.into_iter().flatten().collect(),
        argument_sources: actuals.to_vec(),
    }))
}

pub(crate) fn same_class_generic_result_matches(
    class_scope: &[TypeParameterErasure],
    caller_method_parameters: &[TypeParameter],
    caller_result: &SignatureType,
    callee: &SameClassGenericMethodContract,
    substitution: &SameClassGenericSubstitution,
    budget: &mut Budget,
) -> Result<bool> {
    let Some(callee_result) = callee.result.as_ref() else {
        return Ok(false);
    };
    let Some(substituted) = substitute_same_class_method_result(
        callee_result,
        &callee.method_parameters,
        &substitution.method_arguments,
        budget,
        0,
    )?
    else {
        return Ok(false);
    };
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    Ok(signature_types_same_generic_call_binding(
        &substituted,
        caller_result,
        class_scope,
        caller_method_parameters,
    ))
}

pub(crate) fn same_class_generic_substituted_result(
    callee: &SameClassGenericMethodContract,
    substitution: &SameClassGenericSubstitution,
    budget: &mut Budget,
) -> Result<Option<SignatureType>> {
    let Some(result) = callee.result.as_ref() else {
        return Ok(None);
    };
    substitute_same_class_method_result(
        result,
        &callee.method_parameters,
        &substitution.method_arguments,
        budget,
        0,
    )
}

pub(crate) fn same_class_generic_source_assignable_to_descriptor(
    source: &SignatureType,
    caller_method_parameters: &[TypeParameter],
    descriptor: &[u8],
    class_scope: &[TypeParameterErasure],
    class_parameters: &[TypeParameter],
    budget: &mut Budget,
) -> Result<Option<bool>> {
    let mut method_descriptor = Vec::with_capacity(descriptor.len().saturating_add(4));
    method_descriptor.push(b'(');
    method_descriptor.extend_from_slice(descriptor);
    method_descriptor.extend_from_slice(b")V");
    let parsed = match parse_method_signature(&method_descriptor, budget) {
        Ok(parsed) => parsed,
        Err(error @ (Error::BudgetExceeded { .. } | Error::Cancelled { .. })) => {
            return Err(error);
        }
        Err(_) => return Ok(None),
    };
    let [target] = parsed.parameters.as_slice() else {
        return Ok(None);
    };
    overload_source_type_assignable(
        source,
        target,
        caller_method_parameters,
        class_scope,
        class_parameters,
        budget,
        0,
    )
}

fn substitute_same_class_method_result(
    source: &SignatureType,
    method_parameters: &[TypeParameter],
    method_arguments: &[SignatureType],
    budget: &mut Budget,
    depth: usize,
) -> Result<Option<SignatureType>> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    if depth > 64 {
        return Ok(None);
    }
    match source {
        SignatureType::Base(_) => Ok(Some(source.clone())),
        SignatureType::Array(component) => Ok(substitute_same_class_method_result(
            component,
            method_parameters,
            method_arguments,
            budget,
            depth + 1,
        )?
        .map(|component| SignatureType::Array(Box::new(component)))),
        SignatureType::TypeVariable(name) => {
            let mut binders = method_parameters
                .iter()
                .enumerate()
                .filter(|(_, binder)| binder.name == *name);
            let Some((index, _)) = binders.next() else {
                return Ok(Some(source.clone()));
            };
            if binders.next().is_some() {
                return Ok(None);
            }
            Ok(method_arguments.get(index).cloned())
        }
        SignatureType::Class(class) => {
            let mut result = class.clone();
            for segment in &mut result.segments {
                budget.poll()?;
                for argument in &mut segment.arguments {
                    let TypeArgument::Exact(source) = argument else {
                        return Ok(None);
                    };
                    let Some(substituted) = substitute_same_class_method_result(
                        source,
                        method_parameters,
                        method_arguments,
                        budget,
                        depth + 1,
                    )?
                    else {
                        return Ok(None);
                    };
                    *source = substituted;
                }
            }
            Ok(Some(SignatureType::Class(result)))
        }
    }
}

fn same_class_call_type_matches(
    target: &SignatureType,
    actual: &SignatureType,
    class_scope: &[TypeParameterErasure],
    class_parameters: &[TypeParameter],
    callee_method_parameters: &[TypeParameter],
    caller_method_parameters: &[TypeParameter],
    substitutions: &mut [Option<SignatureType>],
    budget: &mut Budget,
    depth: usize,
) -> Result<bool> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    if depth > 64 {
        return Ok(false);
    }
    match (target, actual) {
        (SignatureType::Base(left), SignatureType::Base(right)) => Ok(left == right),
        (SignatureType::Array(left), SignatureType::Array(right)) => same_class_call_type_matches(
            left,
            right,
            class_scope,
            class_parameters,
            callee_method_parameters,
            caller_method_parameters,
            substitutions,
            budget,
            depth + 1,
        ),
        (SignatureType::TypeVariable(target_name), _) => {
            if let Some((index, binder)) = callee_method_parameters
                .iter()
                .enumerate()
                .find(|(_, binder)| binder.name == *target_name)
            {
                if !same_class_call_type_satisfies_method_bounds(
                    actual,
                    binder,
                    class_scope,
                    class_parameters,
                    caller_method_parameters,
                    budget,
                )? {
                    return Ok(false);
                }
                let Some(previous) = substitutions.get_mut(index) else {
                    return Ok(false);
                };
                if let Some(previous) = previous {
                    Ok(signature_types_same_generic_call_binding(
                        previous,
                        actual,
                        class_scope,
                        caller_method_parameters,
                    ))
                } else {
                    *previous = Some(actual.clone());
                    Ok(true)
                }
            } else {
                let Some((target_index, _)) = class_scope
                    .iter()
                    .enumerate()
                    .find(|(_, binder)| binder.name == *target_name)
                else {
                    return Ok(false);
                };
                let SignatureType::TypeVariable(actual_name) = actual else {
                    return Ok(false);
                };
                if caller_method_parameters
                    .iter()
                    .any(|binder| binder.name == *actual_name)
                {
                    return Ok(false);
                }
                Ok(class_scope
                    .get(target_index)
                    .is_some_and(|binder| binder.name == *actual_name))
            }
        }
        (SignatureType::Class(target), SignatureType::Class(actual)) => {
            if target.segments.len() != actual.segments.len() {
                return Ok(false);
            }
            for (target, actual) in target.segments.iter().zip(&actual.segments) {
                if target.binary_name != actual.binary_name
                    || target.arguments.len() != actual.arguments.len()
                {
                    return Ok(false);
                }
                for (target_argument, actual_argument) in
                    target.arguments.iter().zip(&actual.arguments)
                {
                    let (TypeArgument::Exact(target), TypeArgument::Exact(actual)) =
                        (target_argument, actual_argument)
                    else {
                        return Ok(false);
                    };
                    if !same_class_call_type_matches(
                        target,
                        actual,
                        class_scope,
                        class_parameters,
                        callee_method_parameters,
                        caller_method_parameters,
                        substitutions,
                        budget,
                        depth + 1,
                    )? {
                        return Ok(false);
                    }
                }
            }
            Ok(true)
        }
        _ => Ok(false),
    }
}

/// Generic invocation equality uses binder identity within one physical caller. A method binder
/// shadows a same-named class binder, while repeated references to the same method binder remain
/// equivalent. The older field-writer comparison intentionally keeps its narrower semantics.
fn signature_types_same_generic_call_binding(
    left: &SignatureType,
    right: &SignatureType,
    class_scope: &[TypeParameterErasure],
    method_binders: &[TypeParameter],
) -> bool {
    match (left, right) {
        (SignatureType::Base(left), SignatureType::Base(right)) => left == right,
        (SignatureType::Array(left), SignatureType::Array(right)) => {
            signature_types_same_generic_call_binding(left, right, class_scope, method_binders)
        }
        (SignatureType::TypeVariable(left), SignatureType::TypeVariable(right)) => {
            left == right
                && (method_binders.iter().any(|binder| binder.name == *left)
                    || (class_scope_variable(left, class_scope)
                        && !method_binders.iter().any(|binder| binder.name == *left)))
        }
        (SignatureType::Class(left), SignatureType::Class(right)) => {
            left.segments.len() == right.segments.len()
                && left
                    .segments
                    .iter()
                    .zip(&right.segments)
                    .all(|(left, right)| {
                        left.binary_name == right.binary_name
                            && left.arguments.len() == right.arguments.len()
                            && left
                                .arguments
                                .iter()
                                .zip(&right.arguments)
                                .all(|(left, right)| {
                                    matches!((left, right),
                                    (TypeArgument::Exact(left), TypeArgument::Exact(right))
                                        if signature_types_same_generic_call_binding(
                                            left, right, class_scope, method_binders
                                        ))
                                })
                    })
        }
        _ => false,
    }
}

fn same_class_call_type_satisfies_method_bounds(
    actual: &SignatureType,
    target: &TypeParameter,
    class_scope: &[TypeParameterErasure],
    class_parameters: &[TypeParameter],
    caller_method_parameters: &[TypeParameter],
    budget: &mut Budget,
) -> Result<bool> {
    let mut required = Vec::new();
    if let Some(bound) = &target.class_bound {
        required.push(bound);
    }
    required.extend(target.interface_bounds.iter());
    if required.is_empty() {
        return Ok(matches!(
            actual,
            SignatureType::TypeVariable(_) | SignatureType::Class(_)
        ));
    }
    for bound in required {
        budget.poll()?;
        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        let SignatureType::Class(required_class) = bound else {
            return Ok(false);
        };
        let Some(required_segment) = required_class.segments.last() else {
            return Ok(false);
        };
        if required_class
            .segments
            .iter()
            .any(|segment| !segment.arguments.is_empty())
        {
            return Ok(false);
        }
        let required_name = required_segment.binary_name.as_slice();
        if required_name == b"java/lang/Object" {
            continue;
        }
        let actual_bound_matches = match actual {
            SignatureType::Class(actual_class) => actual_class
                .segments
                .last()
                .is_some_and(|segment| segment.binary_name.as_slice() == required_name),
            SignatureType::TypeVariable(actual_name) => caller_method_parameters
                .iter()
                .find(|binder| binder.name == *actual_name)
                .or_else(|| {
                    class_scope
                        .iter()
                        .position(|binder| binder.name == *actual_name)
                        .and_then(|index| class_parameters.get(index))
                })
                .is_some_and(|actual_binder| {
                    std::iter::once(actual_binder.class_bound.as_ref())
                        .flatten()
                        .chain(actual_binder.interface_bounds.iter())
                        .any(|bound| {
                            matches!(bound, SignatureType::Class(class)
                                if class.segments.last().is_some_and(|segment| segment.binary_name.as_slice() == required_name)
                                    && class.segments.iter().all(|segment| segment.arguments.is_empty()))
                        })
                }),
            SignatureType::Base(_) | SignatureType::Array(_) => false,
        };
        if !actual_bound_matches {
            return Ok(false);
        }
    }
    Ok(true)
}

// ---------------------------------------------------------------------------------------------
// Closed same-class overload proof for a source cast at a generic call site
// ---------------------------------------------------------------------------------------------

/// One source argument admitted by the overload proof. A non-null argument retains the physical
/// caller, its formal or nested-call origin, the Signature type, and the caller binder list that
/// proved its source type. Null has no invented source type and cannot infer a callee method binder.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SameClassOverloadActual {
    pub(crate) source: Option<SameClassGenericArgumentSource>,
    pub(crate) null_literal: bool,
}

/// One complete, source-writable same-class declaration that can participate in overload
/// resolution. `owner` is the class-file internal name paired with the physical method identity;
/// the caller supplies it from the same completed class inventory.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SameClassOverloadCandidate {
    pub(crate) method: PhysicalMethodId,
    pub(crate) owner: Vec<u8>,
    pub(crate) descriptor: Vec<u8>,
    pub(crate) access_flags: u16,
    pub(crate) parameters: Vec<SignatureType>,
    pub(crate) method_parameters: Vec<TypeParameter>,
    pub(crate) source_writable: bool,
}

/// Prove that a source invocation remains pinned to its physical target after adding only
/// explicit-bound reference upcasts. This is intentionally a finite proof: it accepts a complete
/// same-class overload inventory on an `Object` subclass with no interfaces, excludes varargs,
/// bridge and synthetic declarations, and resolves only the JDK reference relationships listed in
/// `closed_jdk8_reference_relation`. An unknown relationship makes the whole proof unavailable;
/// the positive-only widening helper is not used as a negative fact.
pub(crate) fn prove_same_class_overload_argument_upcasts(
    class_internal: &[u8],
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    class_scope: &[TypeParameterErasure],
    class_parameters: &[TypeParameter],
    caller: &PhysicalMethodId,
    target: &jarde_java::facts::CallTarget,
    call_bci: u32,
    overloads_complete: bool,
    actuals: &[SameClassOverloadActual],
    overloads: &[SameClassOverloadCandidate],
    budget: &mut Budget,
) -> Result<Option<Vec<jarde_java::report::ClassSourceInvokeArgumentCast>>> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    if !overloads_complete
        || class_superclass != Some(b"java/lang/Object".as_slice())
        || !class_interfaces.is_empty()
        || target.owner().as_bytes() != class_internal
        || target.is_interface_reference()
        || !matches!(
            target.kind(),
            jarde_java::facts::InvokeKind::Static
                | jarde_java::facts::InvokeKind::Virtual
                | jarde_java::facts::InvokeKind::Special
        )
        || target.name().starts_with('<')
        // The closed candidate slice contains declarations from this class only. Object's
        // inherited instance methods are additional source candidates even when this class has no
        // interfaces, so their names are outside this proof.
        || is_object_instance_method_name(target.name().as_bytes())
        || overloads.is_empty()
    {
        return Ok(None);
    }
    let expected_static = target.kind() == jarde_java::facts::InvokeKind::Static;
    let mut selected = None;
    let mut seen_methods = std::collections::HashSet::new();
    for (index, candidate) in overloads.iter().enumerate() {
        budget.poll()?;
        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        if !candidate.source_writable
            || candidate.owner != class_internal
            || candidate.method.owner != caller.owner
            || candidate.method.name.0.as_slice() != target.name().as_bytes()
            || candidate.descriptor.as_slice() != candidate.method.descriptor.0.as_slice()
            || candidate.access_flags & (ACC_VARARGS | 0x0040 | 0x1000) != 0
            || (candidate.access_flags & ACC_STATIC != 0) != expected_static
            || !seen_methods.insert(candidate.method.clone())
        {
            return Ok(None);
        }
        let Some(parameter_descriptors) = overload_parameter_descriptors(&candidate.descriptor)
        else {
            return Ok(None);
        };
        budget.charge(
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(parameter_descriptors.len()).unwrap_or(u64::MAX),
        )?;
        if parameter_descriptors.len() != candidate.parameters.len() {
            return Ok(None);
        }
        if candidate.method.name.0.as_slice() == target.name().as_bytes()
            && candidate.descriptor.as_slice() == target.descriptor().as_bytes()
            && target.owner().as_bytes() == candidate.owner
        {
            if selected.replace(index).is_some() {
                return Ok(None);
            }
        }
    }
    let Some(selected) = selected else {
        return Ok(None);
    };
    let caller_method_parameters = overload_actual_method_parameters(caller, actuals, budget)?;
    if caller_method_parameters.is_none() && actuals.iter().any(|actual| actual.source.is_some()) {
        return Ok(None);
    }
    let caller_method_parameters = caller_method_parameters.unwrap_or_default();
    let mut actual_types = Vec::with_capacity(actuals.len());
    for actual in actuals {
        budget.poll()?;
        match (&actual.source, actual.null_literal) {
            (Some(source), false) if source.caller == *caller => {
                actual_types.push(Some(source.source_type.clone()));
            }
            (None, true) => actual_types.push(None),
            _ => return Ok(None),
        }
    }
    let uncast_resolution = overload_target_is_unique_most_specific(
        selected,
        overloads,
        &actual_types,
        &caller_method_parameters,
        class_scope,
        class_parameters,
        budget,
    )?;
    if uncast_resolution == Some(true) {
        return Ok(Some(Vec::new()));
    }

    // A cast is considered only where the target's physical parameter descriptor is exactly one
    // of this direct formal's explicit reference bounds. Every other argument keeps its proved
    // source type. This prevents an erasure or `Object` type from being used to invent `T`.
    let Some(selected_parameter_descriptors) =
        overload_parameter_descriptors(&overloads[selected].descriptor)
    else {
        return Ok(None);
    };
    let mut cast_choices = Vec::new();
    for (argument_index, actual) in actuals.iter().enumerate() {
        budget.poll()?;
        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        let Some(source) = &actual.source else {
            continue;
        };
        let SignatureType::TypeVariable(name) = &source.source_type else {
            continue;
        };
        let Some(parameter_descriptor) = selected_parameter_descriptors.get(argument_index) else {
            return Ok(None);
        };
        let Some(target_name) = descriptor_reference_name(parameter_descriptor) else {
            continue;
        };
        if !explicit_reference_bound_matches(
            name,
            &target_name,
            &source.caller_method_parameters,
            class_scope,
            class_parameters,
            budget,
        )? {
            continue;
        }
        let Ok(target_name) = std::str::from_utf8(&target_name) else {
            continue;
        };
        let source_type = SignatureType::Class(jarde_reader::signature::ClassType {
            segments: vec![jarde_reader::signature::ClassTypeSegment {
                binary_name: target_name.as_bytes().to_vec(),
                arguments: Vec::new(),
            }],
        });
        cast_choices.push((
            argument_index,
            source_type,
            jarde_java::ast::Type::Reference(target_name.replace('/', ".")),
        ));
    }
    if cast_choices.is_empty() {
        return Ok(None);
    }

    // Apply the closed set together, then remove each cast whose absence still leaves this target
    // uniquely most-specific. This is polynomial in the descriptor arity and keeps only edits
    // that the proof needs; there is no powerset search over JVM arguments.
    let mut keep = vec![true; cast_choices.len()];
    let mut candidate_actuals = actual_types.clone();
    for (argument_index, source_type, _) in &cast_choices {
        let Some(actual) = candidate_actuals.get_mut(*argument_index) else {
            return Ok(None);
        };
        *actual = Some(source_type.clone());
    }
    let cast_resolution = overload_target_is_unique_most_specific(
        selected,
        overloads,
        &candidate_actuals,
        &caller_method_parameters,
        class_scope,
        class_parameters,
        budget,
    )?;
    if cast_resolution != Some(true) {
        return Ok(None);
    }
    loop {
        let mut changed = false;
        for (choice_index, (argument_index, _, _)) in cast_choices.iter().enumerate() {
            if !keep[choice_index] {
                continue;
            }
            budget.poll()?;
            budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
            let Some(original) = actual_types.get(*argument_index) else {
                return Ok(None);
            };
            {
                let Some(actual) = candidate_actuals.get_mut(*argument_index) else {
                    return Ok(None);
                };
                *actual = original.clone();
            }
            if overload_target_is_unique_most_specific(
                selected,
                overloads,
                &candidate_actuals,
                &caller_method_parameters,
                class_scope,
                class_parameters,
                budget,
            )? == Some(true)
            {
                keep[choice_index] = false;
                changed = true;
            } else {
                let Some(actual) = candidate_actuals.get_mut(*argument_index) else {
                    return Ok(None);
                };
                *actual = Some(cast_choices[choice_index].1.clone());
            }
        }
        if !changed {
            break;
        }
    }
    let solution: Vec<_> = keep
        .iter()
        .enumerate()
        .filter_map(|(index, keep)| keep.then_some(index))
        .collect();
    if solution.is_empty() {
        return Ok(None);
    }
    let opcode = match target.kind() {
        jarde_java::facts::InvokeKind::Virtual => 0xb6,
        jarde_java::facts::InvokeKind::Special => 0xb7,
        jarde_java::facts::InvokeKind::Static => 0xb8,
        jarde_java::facts::InvokeKind::Interface => return Ok(None),
    };
    Ok(Some(
        solution
            .into_iter()
            .map(|choice| {
                let (argument_index, _, ty) = &cast_choices[choice];
                jarde_java::report::ClassSourceInvokeArgumentCast {
                    call_bci,
                    opcode,
                    target: target.clone(),
                    argument_index: *argument_index,
                    ty: ty.clone(),
                }
            })
            .collect(),
    ))
}

fn overload_actual_method_parameters(
    caller: &PhysicalMethodId,
    actuals: &[SameClassOverloadActual],
    budget: &mut Budget,
) -> Result<Option<Vec<TypeParameter>>> {
    let mut result: Option<Vec<TypeParameter>> = None;
    for actual in actuals {
        budget.poll()?;
        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        let Some(source) = &actual.source else {
            continue;
        };
        if source.caller != *caller {
            return Ok(None);
        }
        if result
            .as_ref()
            .is_some_and(|parameters| parameters != &source.caller_method_parameters)
        {
            return Ok(None);
        }
        result.get_or_insert_with(|| source.caller_method_parameters.clone());
    }
    Ok(result)
}

fn overload_parameter_descriptors(descriptor: &[u8]) -> Option<Vec<Vec<u8>>> {
    let facts = descriptor_facts(descriptor, DescriptorKind::Method).ok()?;
    facts
        .parameters()
        .iter()
        .map(|parameter| parameter.bytes(descriptor).map(<[u8]>::to_vec))
        .collect()
}

fn descriptor_reference_name(descriptor: &[u8]) -> Option<Vec<u8>> {
    if descriptor.first() != Some(&b'L') || descriptor.last() != Some(&b';') {
        return None;
    }
    let name = descriptor.get(1..descriptor.len().checked_sub(1)?)?;
    (!name.is_empty() && !name.contains(&b'[')).then(|| name.to_vec())
}

fn explicit_reference_bound_matches(
    variable: &[u8],
    target: &[u8],
    caller_method_parameters: &[TypeParameter],
    class_scope: &[TypeParameterErasure],
    class_parameters: &[TypeParameter],
    budget: &mut Budget,
) -> Result<bool> {
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(
            caller_method_parameters
                .len()
                .saturating_add(class_scope.len()),
        )
        .unwrap_or(u64::MAX),
    )?;
    budget.poll()?;
    let mut method_matches = caller_method_parameters
        .iter()
        .filter(|parameter| parameter.name == variable);
    let binder = if let Some(parameter) = method_matches.next() {
        if method_matches.next().is_some() {
            return Ok(false);
        }
        parameter
    } else {
        let mut matches = class_scope
            .iter()
            .enumerate()
            .filter(|(_, parameter)| parameter.name == variable);
        let Some((index, _)) = matches.next() else {
            return Ok(false);
        };
        if matches.next().is_some() {
            return Ok(false);
        }
        let Some(parameter) = class_parameters.get(index) else {
            return Ok(false);
        };
        parameter
    };
    for bound in std::iter::once(binder.class_bound.as_ref())
        .flatten()
        .chain(binder.interface_bounds.iter())
    {
        budget.poll()?;
        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        if matches!(bound, SignatureType::Class(class)
            if signature_class_erasure(bound) == Some(target)
                && !class.segments.is_empty())
        {
            return Ok(true);
        }
    }
    Ok(false)
}

fn overload_target_is_unique_most_specific(
    selected: usize,
    overloads: &[SameClassOverloadCandidate],
    actuals: &[Option<SignatureType>],
    caller_method_parameters: &[TypeParameter],
    class_scope: &[TypeParameterErasure],
    class_parameters: &[TypeParameter],
    budget: &mut Budget,
) -> Result<Option<bool>> {
    let mut applicable = Vec::new();
    for (index, candidate) in overloads.iter().enumerate() {
        budget.poll()?;
        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        let applicability = overload_candidate_applicability(
            candidate,
            actuals,
            caller_method_parameters,
            class_scope,
            class_parameters,
            budget,
        )?;
        match applicability {
            Some(Some(parameters)) => applicable.push((index, parameters)),
            Some(None) => {}
            None => return Ok(None),
        }
    }
    let Some(selected_parameters) = applicable
        .iter()
        .find(|(index, _)| *index == selected)
        .map(|(_, parameters)| parameters.clone())
    else {
        return Ok(Some(false));
    };
    for (index, parameters) in applicable {
        budget.poll()?;
        if index == selected {
            continue;
        }
        let mut strict = false;
        for (selected_type, other_type) in selected_parameters.iter().zip(&parameters) {
            let selected_to_other = overload_source_type_assignable(
                selected_type,
                other_type,
                caller_method_parameters,
                class_scope,
                class_parameters,
                budget,
                0,
            )?;
            let other_to_selected = overload_source_type_assignable(
                other_type,
                selected_type,
                caller_method_parameters,
                class_scope,
                class_parameters,
                budget,
                0,
            )?;
            match (selected_to_other, other_to_selected) {
                (Some(true), Some(false)) => strict = true,
                (Some(true), Some(true)) => {}
                (Some(false), _) | (_, Some(false)) => return Ok(Some(false)),
                _ => return Ok(None),
            }
        }
        if !strict {
            return Ok(Some(false));
        }
    }
    Ok(Some(true))
}

fn overload_candidate_applicability(
    candidate: &SameClassOverloadCandidate,
    actuals: &[Option<SignatureType>],
    caller_method_parameters: &[TypeParameter],
    class_scope: &[TypeParameterErasure],
    class_parameters: &[TypeParameter],
    budget: &mut Budget,
) -> Result<Option<Option<Vec<SignatureType>>>> {
    if candidate.parameters.len() != actuals.len() {
        return Ok(Some(None));
    }
    if !overload_candidate_binders_are_closed(candidate, budget)? {
        return Ok(None);
    }
    let mut method_arguments: Vec<Option<SignatureType>> =
        vec![None; candidate.method_parameters.len()];
    for (parameter, actual) in candidate.parameters.iter().zip(actuals) {
        budget.poll()?;
        match actual {
            Some(actual) => {
                if !overload_infer_method_arguments(
                    parameter,
                    actual,
                    &candidate.method_parameters,
                    &mut method_arguments,
                    class_scope,
                    caller_method_parameters,
                    budget,
                    0,
                )? {
                    return Ok(Some(None));
                }
            }
            None if !candidate.method_parameters.is_empty()
                && overload_type_mentions_method_binder(
                    parameter,
                    &candidate.method_parameters,
                    budget,
                )? =>
            {
                // A generic invocation with a null argument can infer from target typing or other
                // constraints. This proof does not model those constraints, so it cannot use null
                // to declare the overload inapplicable.
                return Ok(None);
            }
            None => {}
        }
    }
    if method_arguments.iter().any(Option::is_none) {
        return Ok(Some(None));
    }
    let method_arguments: Vec<_> = method_arguments.into_iter().flatten().collect();
    for (index, argument) in method_arguments.iter().enumerate() {
        let Some(binder) = candidate.method_parameters.get(index) else {
            return Ok(Some(None));
        };
        match overload_method_argument_satisfies_bounds(
            argument,
            binder,
            &candidate.method_parameters,
            &method_arguments,
            class_scope,
            class_parameters,
            caller_method_parameters,
            budget,
        )? {
            Some(true) => {}
            Some(false) => return Ok(Some(None)),
            None => return Ok(None),
        }
    }
    let mut instantiated = Vec::with_capacity(candidate.parameters.len());
    for (parameter, actual) in candidate.parameters.iter().zip(actuals) {
        let Some(parameter) = substitute_same_class_method_result(
            parameter,
            &candidate.method_parameters,
            &method_arguments,
            budget,
            0,
        )?
        else {
            return Ok(Some(None));
        };
        if let Some(actual) = actual {
            match overload_source_type_assignable(
                actual,
                &parameter,
                caller_method_parameters,
                class_scope,
                class_parameters,
                budget,
                0,
            )? {
                Some(true) => {}
                Some(false) => return Ok(Some(None)),
                None => return Ok(None),
            }
        } else if !overload_reference_type(&parameter) {
            return Ok(Some(None));
        }
        instantiated.push(parameter);
    }
    Ok(Some(Some(instantiated)))
}

/// The overload proof models method inference only when each method binder occurs once as a
/// complete formal parameter. Repeated/nested inference constraints can choose a common type or
/// depend on target typing; treating those shapes as inapplicable would be an unsafe negative.
fn overload_candidate_binders_are_closed(
    candidate: &SameClassOverloadCandidate,
    budget: &mut Budget,
) -> Result<bool> {
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(
            candidate
                .parameters
                .len()
                .saturating_add(candidate.method_parameters.len()),
        )
        .unwrap_or(u64::MAX),
    )?;
    let mut names = std::collections::HashSet::new();
    for binder in &candidate.method_parameters {
        budget.poll()?;
        if !names.insert(binder.name.as_slice()) {
            return Ok(false);
        }
        let mut direct_count = 0;
        for parameter in &candidate.parameters {
            budget.poll()?;
            if overload_type_mentions_method_binder(
                parameter,
                &candidate.method_parameters,
                budget,
            )? {
                if matches!(parameter, SignatureType::TypeVariable(name) if name == &binder.name) {
                    direct_count += 1;
                } else {
                    // The broad predicate identifies at least one method binder. A direct binder
                    // can coexist with other independent parameters, but nested forms are opaque.
                    let mentions_this =
                        overload_type_mentions_one_method_binder(parameter, &binder.name, budget)?;
                    if mentions_this {
                        return Ok(false);
                    }
                }
            }
        }
        if direct_count != 1 {
            return Ok(false);
        }
    }
    Ok(true)
}

fn overload_type_mentions_one_method_binder(
    ty: &SignatureType,
    name: &[u8],
    budget: &mut Budget,
) -> Result<bool> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    match ty {
        SignatureType::TypeVariable(candidate) => Ok(candidate == name),
        SignatureType::Array(component) => {
            overload_type_mentions_one_method_binder(component, name, budget)
        }
        SignatureType::Class(class) => {
            for segment in &class.segments {
                budget.poll()?;
                for argument in &segment.arguments {
                    let present = match argument {
                        TypeArgument::Exact(ty)
                        | TypeArgument::Extends(ty)
                        | TypeArgument::Super(ty) => {
                            overload_type_mentions_one_method_binder(ty, name, budget)?
                        }
                        TypeArgument::Any => false,
                    };
                    if present {
                        return Ok(true);
                    }
                }
            }
            Ok(false)
        }
        SignatureType::Base(_) => Ok(false),
    }
}

fn overload_method_argument_satisfies_bounds(
    actual: &SignatureType,
    binder: &TypeParameter,
    method_parameters: &[TypeParameter],
    method_arguments: &[SignatureType],
    class_scope: &[TypeParameterErasure],
    class_parameters: &[TypeParameter],
    caller_method_parameters: &[TypeParameter],
    budget: &mut Budget,
) -> Result<Option<bool>> {
    let mut bounds = Vec::new();
    for bound in std::iter::once(binder.class_bound.as_ref())
        .flatten()
        .chain(binder.interface_bounds.iter())
    {
        let Some(bound) = substitute_same_class_method_result(
            bound,
            method_parameters,
            method_arguments,
            budget,
            0,
        )?
        else {
            return Ok(None);
        };
        bounds.push(bound);
    }
    if bounds.is_empty() {
        return Ok(overload_reference_type(actual).then_some(true));
    }
    let mut unknown = false;
    for bound in &bounds {
        match overload_source_type_assignable(
            actual,
            bound,
            caller_method_parameters,
            class_scope,
            class_parameters,
            budget,
            0,
        )? {
            Some(true) => {}
            Some(false) => return Ok(Some(false)),
            None => unknown = true,
        }
    }
    Ok((!unknown).then_some(true))
}

fn overload_infer_method_arguments(
    parameter: &SignatureType,
    actual: &SignatureType,
    method_parameters: &[TypeParameter],
    substitutions: &mut [Option<SignatureType>],
    class_scope: &[TypeParameterErasure],
    caller_method_parameters: &[TypeParameter],
    budget: &mut Budget,
    depth: usize,
) -> Result<bool> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    if depth > 64 {
        return Ok(false);
    }
    if let SignatureType::TypeVariable(name) = parameter {
        let mut binders = method_parameters
            .iter()
            .enumerate()
            .filter(|(_, binder)| binder.name == *name);
        if let Some((index, _)) = binders.next() {
            if binders.next().is_some() {
                return Ok(false);
            }
            let Some(slot) = substitutions.get_mut(index) else {
                return Ok(false);
            };
            if let Some(previous) = slot {
                return Ok(signature_types_same_generic_call_binding(
                    previous,
                    actual,
                    class_scope,
                    caller_method_parameters,
                ));
            }
            *slot = Some(actual.clone());
            return Ok(true);
        }
    }
    match (parameter, actual) {
        (SignatureType::Array(parameter), SignatureType::Array(actual)) => {
            overload_infer_method_arguments(
                parameter,
                actual,
                method_parameters,
                substitutions,
                class_scope,
                caller_method_parameters,
                budget,
                depth + 1,
            )
        }
        (SignatureType::Class(parameter), SignatureType::Class(actual))
            if parameter.segments.len() == actual.segments.len() =>
        {
            for (parameter, actual) in parameter.segments.iter().zip(&actual.segments) {
                if parameter.binary_name != actual.binary_name
                    || parameter.arguments.len() != actual.arguments.len()
                {
                    return Ok(true);
                }
                for (parameter, actual) in parameter.arguments.iter().zip(&actual.arguments) {
                    let (TypeArgument::Exact(parameter), TypeArgument::Exact(actual)) =
                        (parameter, actual)
                    else {
                        return Ok(false);
                    };
                    if !overload_infer_method_arguments(
                        parameter,
                        actual,
                        method_parameters,
                        substitutions,
                        class_scope,
                        caller_method_parameters,
                        budget,
                        depth + 1,
                    )? {
                        return Ok(false);
                    }
                }
            }
            Ok(true)
        }
        _ => Ok(true),
    }
}

fn overload_type_mentions_method_binder(
    ty: &SignatureType,
    method_parameters: &[TypeParameter],
    budget: &mut Budget,
) -> Result<bool> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    match ty {
        SignatureType::TypeVariable(name) => Ok(method_parameters
            .iter()
            .any(|parameter| parameter.name == *name)),
        SignatureType::Array(component) => {
            overload_type_mentions_method_binder(component, method_parameters, budget)
        }
        SignatureType::Class(class) => {
            for segment in &class.segments {
                budget.poll()?;
                for argument in &segment.arguments {
                    let mentioned = match argument {
                        TypeArgument::Exact(ty) => {
                            overload_type_mentions_method_binder(ty, method_parameters, budget)?
                        }
                        TypeArgument::Any | TypeArgument::Extends(_) | TypeArgument::Super(_) => {
                            true
                        }
                    };
                    if mentioned {
                        return Ok(true);
                    }
                }
            }
            Ok(false)
        }
        SignatureType::Base(_) => Ok(false),
    }
}

fn overload_reference_type(ty: &SignatureType) -> bool {
    matches!(
        ty,
        SignatureType::TypeVariable(_) | SignatureType::Class(_) | SignatureType::Array(_)
    )
}

/// `Some(true/false)` is a closed answer; `None` means the finite hierarchy does not decide it.
fn overload_source_type_assignable(
    source: &SignatureType,
    target: &SignatureType,
    caller_method_parameters: &[TypeParameter],
    class_scope: &[TypeParameterErasure],
    class_parameters: &[TypeParameter],
    budget: &mut Budget,
    depth: usize,
) -> Result<Option<bool>> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    if depth > 64 {
        return Ok(None);
    }
    if overload_shared_shadowed_binder_name(
        source,
        target,
        caller_method_parameters,
        class_scope,
        budget,
    )? {
        // The same spelling can denote a caller method binder on one side and the class binder
        // on the other. Without preserving those two binder identities through the candidate
        // projection, equality would turn a shadowed `T` into a false overload match.
        return Ok(None);
    }
    if signature_types_same_generic_call_binding(
        source,
        target,
        class_scope,
        caller_method_parameters,
    ) {
        return Ok(Some(true));
    }
    match (source, target) {
        (SignatureType::Base(source), SignatureType::Base(target)) if source == target => {
            Ok(Some(true))
        }
        // Primitive widening, boxing and unboxing affect JLS applicability. They are outside this
        // reference-upcast proof, so an unequal/base-reference pair is unknown rather than a
        // negative applicability fact.
        (SignatureType::Base(_), _) | (_, SignatureType::Base(_)) => Ok(None),
        (SignatureType::Array(source), SignatureType::Array(target)) => {
            overload_source_type_assignable(
                source,
                target,
                caller_method_parameters,
                class_scope,
                class_parameters,
                budget,
                depth + 1,
            )
        }
        (SignatureType::Array(_), SignatureType::Class(target)) => Ok(signature_class_erasure(
            &SignatureType::Class(target.clone()),
        )
        .map(|name| {
            name == b"java/lang/Object"
                || name == b"java/lang/Cloneable"
                || name == b"java/io/Serializable"
        })),
        (SignatureType::Class(source), SignatureType::Class(target)) => {
            if source == target {
                return Ok(Some(true));
            }
            let source_signature = SignatureType::Class(source.clone());
            let Some(source_name) = signature_class_erasure(&source_signature) else {
                return Ok(None);
            };
            let target_signature = SignatureType::Class(target.clone());
            let Some(target_name) = signature_class_erasure(&target_signature) else {
                return Ok(None);
            };
            if target_name == b"java/lang/Object" {
                return Ok(Some(true));
            }
            // The one parameterized JDK edge in this closed proof is String's actual Java 8
            // `Comparable<String>` header. Wildcard conversions remain unknown below.
            if source_name == b"java/lang/String"
                && target_name == b"java/lang/Comparable"
                && target.segments.last().is_some_and(|segment| {
                    matches!(
                        segment.arguments.as_slice(),
                        [TypeArgument::Exact(SignatureType::Class(string))]
                            if signature_class_erasure(&SignatureType::Class(string.clone()))
                                == Some(b"java/lang/String".as_slice())
                                && string.segments.iter().all(|segment| segment.arguments.is_empty())
                    )
                })
            {
                return Ok(Some(true));
            }
            if source_name == target_name {
                if target
                    .segments
                    .iter()
                    .all(|segment| segment.arguments.is_empty())
                {
                    return Ok(Some(true));
                }
                if target.segments.iter().any(|segment| {
                    segment.arguments.iter().any(|argument| {
                        matches!(
                            argument,
                            TypeArgument::Any | TypeArgument::Extends(_) | TypeArgument::Super(_)
                        )
                    })
                }) {
                    return Ok(None);
                }
                return Ok(Some(false));
            }
            let raw_relation = closed_jdk8_reference_relation(source_name, target_name);
            if source
                .segments
                .iter()
                .any(|segment| !segment.arguments.is_empty())
                || target
                    .segments
                    .iter()
                    .any(|segment| !segment.arguments.is_empty())
            {
                return Ok(match raw_relation {
                    Some(false) => Some(false),
                    Some(true) | None => None,
                });
            }
            Ok(raw_relation)
        }
        (SignatureType::TypeVariable(name), SignatureType::Class(target)) => {
            let target = SignatureType::Class(target.clone());
            if signature_class_erasure(&target).as_deref() == Some(b"java/lang/Object") {
                return Ok(Some(true));
            }
            let Some(binder) = overload_find_binder(
                name,
                caller_method_parameters,
                class_scope,
                class_parameters,
                budget,
            )?
            else {
                return Ok(None);
            };
            let mut bounds = Vec::new();
            bounds.extend(binder.class_bound.iter());
            bounds.extend(binder.interface_bounds.iter());
            if bounds.is_empty() {
                return Ok(Some(false));
            }
            let mut unknown = false;
            for bound in bounds {
                let relation = overload_source_type_assignable(
                    bound,
                    &target,
                    caller_method_parameters,
                    class_scope,
                    class_parameters,
                    budget,
                    depth + 1,
                )?;
                match relation {
                    Some(true) => return Ok(Some(true)),
                    Some(false) => {}
                    None => unknown = true,
                }
            }
            Ok((!unknown).then_some(false))
        }
        (SignatureType::TypeVariable(_), SignatureType::Array(_)) => Ok(Some(false)),
        // Different variables can still be related through their bounds (for example
        // `U extends T`). This helper does not close variable-to-variable bounds, so it cannot
        // use this pair as negative overload-applicability evidence.
        (SignatureType::TypeVariable(_), SignatureType::TypeVariable(_)) => Ok(None),
        (SignatureType::Class(_), SignatureType::Array(_)) => Ok(Some(false)),
        (SignatureType::Array(_), SignatureType::TypeVariable(_)) => Ok(Some(false)),
        (SignatureType::Class(_), SignatureType::TypeVariable(_)) => Ok(Some(false)),
    }
}

fn overload_shared_shadowed_binder_name(
    source: &SignatureType,
    target: &SignatureType,
    caller_method_parameters: &[TypeParameter],
    class_scope: &[TypeParameterErasure],
    budget: &mut Budget,
) -> Result<bool> {
    let mut source_names = std::collections::HashSet::new();
    let mut target_names = std::collections::HashSet::new();
    overload_collect_type_variables(source, &mut source_names, budget)?;
    overload_collect_type_variables(target, &mut target_names, budget)?;
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(source_names.len()).unwrap_or(u64::MAX),
    )?;
    budget.poll()?;
    Ok(source_names.iter().any(|name| {
        target_names.contains(name)
            && caller_method_parameters
                .iter()
                .any(|parameter| parameter.name.as_slice() == *name)
            && class_scope
                .iter()
                .any(|parameter| parameter.name.as_slice() == *name)
    }))
}

fn overload_collect_type_variables<'a>(
    ty: &'a SignatureType,
    names: &mut std::collections::HashSet<&'a [u8]>,
    budget: &mut Budget,
) -> Result<()> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    match ty {
        SignatureType::TypeVariable(name) => {
            names.insert(name);
        }
        SignatureType::Array(component) => {
            overload_collect_type_variables(component, names, budget)?;
        }
        SignatureType::Class(class) => {
            for segment in &class.segments {
                budget.poll()?;
                for argument in &segment.arguments {
                    match argument {
                        TypeArgument::Exact(ty)
                        | TypeArgument::Extends(ty)
                        | TypeArgument::Super(ty) => {
                            overload_collect_type_variables(ty, names, budget)?;
                        }
                        TypeArgument::Any => {}
                    }
                }
            }
        }
        SignatureType::Base(_) => {}
    }
    Ok(())
}

fn overload_find_binder<'a>(
    name: &[u8],
    caller_method_parameters: &'a [TypeParameter],
    class_scope: &[TypeParameterErasure],
    class_parameters: &'a [TypeParameter],
    budget: &mut Budget,
) -> Result<Option<&'a TypeParameter>> {
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(
            caller_method_parameters
                .len()
                .saturating_add(class_scope.len()),
        )
        .unwrap_or(u64::MAX),
    )?;
    budget.poll()?;
    let mut method = caller_method_parameters
        .iter()
        .filter(|parameter| parameter.name == name);
    if let Some(parameter) = method.next() {
        return Ok(method.next().is_none().then_some(parameter));
    }
    let mut class = class_scope
        .iter()
        .enumerate()
        .filter(|(_, parameter)| parameter.name == name);
    let Some((index, _)) = class.next() else {
        return Ok(None);
    };
    if class.next().is_some() {
        return Ok(None);
    }
    Ok(class_parameters.get(index))
}

/// Closed Java 8 header facts used by this proof: `Number` implements `Serializable` but not
/// `Comparable`; `String` implements `Serializable`, `Comparable` and `CharSequence`; all four
/// types inherit from `Object`. The caller's Java source dialect is Java 8, so later JDK interfaces
/// such as `Constable` and `ConstantDesc` are deliberately absent. `None` is unknown, never a
/// negative assignability claim.
fn closed_jdk8_reference_relation(source: &[u8], target: &[u8]) -> Option<bool> {
    const OBJECT: &[u8] = b"java/lang/Object";
    const NUMBER: &[u8] = b"java/lang/Number";
    const STRING: &[u8] = b"java/lang/String";
    const COMPARABLE: &[u8] = b"java/lang/Comparable";
    const SERIALIZABLE: &[u8] = b"java/io/Serializable";
    const CHAR_SEQUENCE: &[u8] = b"java/lang/CharSequence";
    if source == target || target == OBJECT {
        return Some(true);
    }
    let closed = [
        OBJECT,
        NUMBER,
        STRING,
        COMPARABLE,
        SERIALIZABLE,
        CHAR_SEQUENCE,
    ];
    if !closed.contains(&source) || !closed.contains(&target) {
        return None;
    }
    let assignable = match source {
        NUMBER => target == SERIALIZABLE,
        STRING => matches!(target, COMPARABLE | SERIALIZABLE | CHAR_SEQUENCE),
        COMPARABLE | SERIALIZABLE | CHAR_SEQUENCE => false,
        OBJECT => false,
        _ => false,
    };
    Some(assignable)
}

/// Split generic candidates into undirected dependency components and topologically order each
/// acyclic component with callees before callers. This is a bounded DAG pass, not a type fixpoint:
/// candidates outside a dependency component remain independent and can still publish.
pub(crate) fn generic_call_components(
    candidates: &[usize],
    dependencies: &[GenericCallDependency],
    budget: &mut Budget,
) -> Result<Vec<GenericCallComponent>> {
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(candidates.len().saturating_add(dependencies.len())).unwrap_or(u64::MAX),
    )?;
    let mut candidate_set = std::collections::BTreeSet::new();
    for candidate in candidates {
        budget.poll()?;
        if !candidate_set.insert(*candidate) {
            return Err(Error::invalid_input(
                "generic_call_candidate_duplicate",
                "one physical method was staged more than once",
            ));
        }
    }
    let mut adjacency = std::collections::BTreeMap::<usize, Vec<usize>>::new();
    let mut callee_dependencies = std::collections::BTreeMap::<usize, Vec<usize>>::new();
    for candidate in &candidate_set {
        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        adjacency.entry(*candidate).or_default();
        callee_dependencies.entry(*candidate).or_default();
    }
    for edge in dependencies {
        budget.poll()?;
        if !candidate_set.contains(&edge.caller) || !candidate_set.contains(&edge.callee) {
            continue;
        }
        adjacency.entry(edge.caller).or_default().push(edge.callee);
        adjacency.entry(edge.callee).or_default().push(edge.caller);
        callee_dependencies
            .entry(edge.caller)
            .or_default()
            .push(edge.callee);
    }
    for neighbors in adjacency.values_mut() {
        budget.charge(
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(neighbors.len()).unwrap_or(u64::MAX),
        )?;
        neighbors.sort_unstable();
        neighbors.dedup();
    }
    for dependencies in callee_dependencies.values_mut() {
        budget.charge(
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(dependencies.len()).unwrap_or(u64::MAX),
        )?;
        dependencies.sort_unstable();
        dependencies.dedup();
    }

    let mut remaining = candidate_set;
    let mut components = Vec::new();
    while let Some(start) = remaining.first().copied() {
        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        let mut pending = vec![start];
        let mut members = Vec::new();
        remaining.remove(&start);
        while let Some(member) = pending.pop() {
            budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
            members.push(member);
            if let Some(neighbors) = adjacency.get(&member) {
                for neighbor in neighbors {
                    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
                    if remaining.remove(neighbor) {
                        pending.push(*neighbor);
                    }
                }
            }
        }
        budget.charge(
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(members.len()).unwrap_or(u64::MAX),
        )?;
        members.sort_unstable();

        budget.charge(
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(members.len()).unwrap_or(u64::MAX),
        )?;
        let mut indegree = std::collections::BTreeMap::new();
        let member_set: std::collections::BTreeSet<_> = members.iter().copied().collect();
        for member in &members {
            budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
            let mut count = 0usize;
            for callee in callee_dependencies.get(member).into_iter().flatten() {
                budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
                if member_set.contains(callee) {
                    count += 1;
                }
            }
            indegree.insert(*member, count);
        }
        budget.charge(
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(indegree.len()).unwrap_or(u64::MAX),
        )?;
        let mut ready: std::collections::BTreeSet<usize> = indegree
            .iter()
            .filter_map(|(member, count)| (*count == 0).then_some(*member))
            .collect();
        let mut order = Vec::with_capacity(members.len());
        while let Some(callee) = ready.pop_first() {
            budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
            order.push(callee);
            for caller in adjacency.get(&callee).into_iter().flatten() {
                budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
                let depends_on = callee_dependencies
                    .get(caller)
                    .is_some_and(|callees| callees.binary_search(&callee).is_ok());
                if !depends_on {
                    continue;
                }
                let Some(count) = indegree.get_mut(caller) else {
                    continue;
                };
                *count = count.saturating_sub(1);
                if *count == 0 {
                    ready.insert(*caller);
                }
            }
        }
        let order = (order.len() == members.len()).then_some(order);
        components.push(GenericCallComponent { members, order });
    }
    Ok(components)
}

/// Find a same-class constructor call whose receiver is this object's uninitialized `this`, or
/// whose receiver identity the same-run SSA could not establish. The source argument adaptation of
/// that delegation is outside the class-scope constructor proof, so either result blocks that
/// constructor's projected header. A `new` allocation is positively classified and remains safe.
pub(crate) fn unproved_same_class_this_delegate_bci(
    class_internal: &[u8],
    member: &MemberHeader,
    facts: &SameClassUseFacts,
    budget: &mut Budget,
) -> Result<Option<u32>> {
    if member.name.raw().0 != b"<init>" {
        return Ok(None);
    }
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(facts.invokes.len()).unwrap_or(u64::MAX),
    )?;
    for use_site in facts.invokes {
        budget.poll()?;
        if use_site.owner != class_internal
            || use_site.name != b"<init>"
            || use_site.descriptor != member.descriptor.raw().0
        {
            continue;
        }
        match use_site.constructor_receiver {
            Some(SameClassConstructorReceiver::UninitializedThis)
            | Some(SameClassConstructorReceiver::Unknown)
            | None => return Ok(Some(use_site.bci)),
            Some(SameClassConstructorReceiver::NewObject) => {}
        }
    }
    Ok(None)
}

/// The number of parameters one method descriptor declares.
fn descriptor_parameter_count(descriptor: &[u8]) -> Option<usize> {
    method_descriptor(descriptor, false, false).map(|signature| signature.parameters.len())
}

/// Prove one held generic method candidate's same-class binding from the completed inventory.
///
/// The proof is deliberately bounded to what the selected class alone can close: the class's own
/// physical parent is `java/lang/Object` and it implements no interfaces (no external same-name
/// candidate can compete), the name is not one of `Object`'s own instance methods, and every
/// same-name declaration is represented uniquely and can be named in source. With no same-arity
/// sibling, the physical descriptor closes binding directly. A real invoke to any member of the
/// closed same-arity set yields [`SameClassBinding::OverloadPending`], including for a generic
/// sibling that has no direct incoming invoke of its own; only the complete staged overload proof
/// may promote it before the component commits. Variable-arity/bridge members, unexplained sites,
/// non-body references, or incomplete inventories remain refused.
pub(crate) fn prove_same_class_method_binding(
    class_internal: &[u8],
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    method_headers: &[MemberHeader],
    member_index: usize,
    facts: &SameClassUseFacts,
    budget: &mut Budget,
) -> Result<SameClassBinding> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(method_headers.len()).unwrap_or(u64::MAX),
    )?;
    let Some(member) = method_headers.get(member_index) else {
        return Ok(SameClassBinding::Unproved);
    };
    let name = member.name.raw().0.as_slice();
    let descriptor = member.descriptor.raw().0.as_slice();
    // The visible candidate set closes only over the selected class and the platform root.
    if class_superclass != Some(b"java/lang/Object".as_slice())
        || !class_interfaces.is_empty()
        || is_object_instance_method_name(name)
    {
        return Ok(SameClassBinding::Unproved);
    }
    if name != b"<init>" && !std::str::from_utf8(name).is_ok_and(is_java_identifier) {
        return Ok(SameClassBinding::Unproved);
    }
    if !facts.complete {
        return Ok(SameClassBinding::Unproved);
    }
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(method_headers.len())
            .unwrap_or(u64::MAX)
            .saturating_mul(u64::try_from(method_headers.len()).unwrap_or(u64::MAX)),
    )?;

    // A source overload set cannot contain bytecode-only bridge/synthetic declarations or
    // variable-arity members: either can affect applicability without a source declaration that
    // the final staged set can faithfully represent. Also require every descriptor to be valid
    // and unique, so an invoke can be joined to exactly one physical header.
    let mut overload_competition = false;
    let arity = descriptor_parameter_count(descriptor);
    for (index, sibling) in method_headers.iter().enumerate() {
        budget.poll()?;
        if sibling.name.raw().0.as_slice() != name {
            continue;
        }
        let sibling_descriptor = sibling.descriptor.raw().0.as_slice();
        if sibling.access_flags & (ACC_VARARGS | 0x0040 | 0x1000) != 0
            || descriptor_parameter_count(sibling_descriptor).is_none()
        {
            return Ok(SameClassBinding::Unproved);
        }
        if method_headers[..index].iter().any(|prior| {
            prior.name.raw().0.as_slice() == name
                && prior.descriptor.raw().0.as_slice() == sibling_descriptor
        }) {
            return Ok(SameClassBinding::Unproved);
        }
        if index != member_index && descriptor_parameter_count(sibling_descriptor) == arity {
            overload_competition = true;
        }
    }
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(facts.invokes.len() + facts.member_refs.len())
            .unwrap_or(u64::MAX)
            .saturating_add(
                u64::try_from(facts.invokes.len())
                    .unwrap_or(u64::MAX)
                    .saturating_mul(u64::try_from(method_headers.len()).unwrap_or(u64::MAX)),
            )
            .saturating_add(
                u64::try_from(facts.member_refs.len())
                    .unwrap_or(u64::MAX)
                    .saturating_mul(u64::try_from(method_headers.len()).unwrap_or(u64::MAX)),
            ),
    )?;
    budget.poll()?;
    let mut same_arity_invokes = 0usize;
    for use_site in facts.invokes {
        budget.poll()?;
        if use_site.name != name {
            continue;
        }
        if use_site.owner != class_internal {
            if overload_competition {
                return Ok(SameClassBinding::Unproved);
            }
            continue;
        }
        let mut matched = method_headers.iter().filter(|header| {
            header.name.raw().0.as_slice() == name
                && header.descriptor.raw().0.as_slice() == use_site.descriptor
        });
        let Some(target_header) = matched.next() else {
            return Ok(SameClassBinding::Unproved);
        };
        if matched.next().is_some() {
            return Ok(SameClassBinding::Unproved);
        }
        let opcode_matches = if is_static(target_header.access_flags) {
            use_site.opcode == 0xb8
        } else {
            matches!(use_site.opcode, 0xb6 | 0xb7)
        };
        if !opcode_matches {
            return Ok(SameClassBinding::Unproved);
        }
        if descriptor_parameter_count(use_site.descriptor.as_slice()) == arity {
            same_arity_invokes = same_arity_invokes.saturating_add(1);
        }
    }
    for reference in facts.member_refs {
        budget.poll()?;
        if !reference.method || reference.name != name {
            continue;
        }
        if reference.owner != class_internal {
            if overload_competition {
                return Ok(SameClassBinding::Unproved);
            }
            continue;
        }
        let mut matched = method_headers.iter().filter(|header| {
            header.name.raw().0.as_slice() == name
                && header.descriptor.raw().0.as_slice() == reference.descriptor
        });
        if matched.next().is_none() || matched.next().is_some() {
            return Ok(SameClassBinding::Unproved);
        }
        // Method handles/bootstrap references are not an invoke site whose source overload can
        // be checked by the generic-call transaction.
        return Ok(SameClassBinding::Unproved);
    }
    if overload_competition {
        return Ok(if same_arity_invokes > 0 {
            SameClassBinding::OverloadPending
        } else {
            SameClassBinding::Unproved
        });
    }
    Ok(SameClassBinding::Proven)
}

/// Prove one held field `Signature` candidate's same-class binding from the completed inventory.
///
/// Fields do not overload, so the binding itself is the owner/name/descriptor identity every
/// access site states; what needs proof is that the *source* keeps working: a field the projected
/// type would make unspellable at one of its own read sites (the loaded value selecting members,
/// flowing into a local, or entering a functional position) stays on its physical descriptor. A
/// same-name sibling field — legal bytes but no Java source spelling — and any unreadable or
/// non-body source naming the field keep the existing refusal.
pub(crate) fn prove_same_class_field_binding(
    class_internal: &[u8],
    field_headers: &[MemberHeader],
    member_index: usize,
    facts: &SameClassUseFacts,
    budget: &mut Budget,
) -> Result<SameClassBinding> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    let member = &field_headers[member_index];
    let name = member.name.raw().0.as_slice();
    let descriptor = member.descriptor.raw().0.as_slice();
    for (index, sibling) in field_headers.iter().enumerate() {
        if index == member_index || sibling.name.raw().0.as_slice() != name {
            continue;
        }
        // Two same-name fields have one source spelling between them at best; the bytes may be
        // legal but the projection cannot claim a binding it cannot even name.
        return Ok(SameClassBinding::Unproved);
    }
    if !facts.complete {
        return Ok(SameClassBinding::Unproved);
    }
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(facts.field_uses.len() + facts.member_refs.len()).unwrap_or(u64::MAX),
    )?;
    budget.poll()?;
    for use_site in facts.field_uses {
        if use_site.owner != class_internal || use_site.name != name {
            continue;
        }
        if use_site.descriptor != descriptor {
            return Ok(SameClassBinding::Unproved);
        }
        if use_site.read_expressible == Some(false) {
            return Ok(SameClassBinding::Unproved);
        }
    }
    for reference in facts.member_refs {
        if !reference.method
            && reference.owner == class_internal
            && reference.name == name
            && reference.descriptor == descriptor
        {
            return Ok(SameClassBinding::Unproved);
        }
    }
    Ok(SameClassBinding::Proven)
}

/// The same-class field sites, with their callers and BCIs, for a proven field's source note.
pub(crate) fn same_class_field_use_note(
    facts: &SameClassUseFacts,
    name: &[u8],
    budget: &mut Budget,
) -> Result<String> {
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(facts.field_uses.len()).unwrap_or(u64::MAX),
    )?;
    let mut sites = Vec::new();
    for use_site in facts.field_uses {
        budget.poll()?;
        if use_site.name == name && sites.len() < 4 {
            sites.push(format!("{}@{}", use_site.caller, use_site.bci));
        }
    }
    if sites.is_empty() {
        return Ok("no consumed same-class entry".to_owned());
    }
    Ok(format!("same-class uses at {}", sites.join(", ")))
}

fn class_scope_variable(name: &[u8], class_scope: &[TypeParameterErasure]) -> bool {
    class_scope.iter().any(|parameter| parameter.name == name)
}

fn charge_signature_type_proof(ty: &SignatureType, budget: &mut Budget) -> Result<u64> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    match ty {
        SignatureType::Base(_) => Ok(0),
        SignatureType::TypeVariable(_) => Ok(1),
        SignatureType::Array(element) => charge_signature_type_proof(element, budget),
        SignatureType::Class(class) => {
            let mut variable_count = 0_u64;
            for segment in &class.segments {
                budget.poll()?;
                budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
                for argument in &segment.arguments {
                    budget.poll()?;
                    match argument {
                        TypeArgument::Any => {
                            budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
                        }
                        TypeArgument::Exact(ty)
                        | TypeArgument::Extends(ty)
                        | TypeArgument::Super(ty) => {
                            variable_count = variable_count
                                .saturating_add(charge_signature_type_proof(ty, budget)?);
                        }
                    }
                }
            }
            Ok(variable_count)
        }
    }
}

fn charge_field_write_source_proof(
    source: &SameClassFieldWriteSource,
    target: &SignatureType,
    class_scope: &[TypeParameterErasure],
    methods: &[SameClassPublishedMethodParameters],
    budget: &mut Budget,
) -> Result<()> {
    let target_variables = charge_signature_type_proof(target, budget)?;
    match source {
        SameClassFieldWriteSource::Null => {
            budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        }
        SameClassFieldWriteSource::StringConstant { .. } => {
            budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        }
        SameClassFieldWriteSource::RawAllocation { owner } => {
            budget.charge(
                CountedBudgetDimension::AnalysisSteps,
                u64::try_from(owner.len()).unwrap_or(u64::MAX),
            )?;
        }
        SameClassFieldWriteSource::Parameter { method, slot } => {
            budget.charge(
                CountedBudgetDimension::AnalysisSteps,
                u64::try_from(methods.len()).unwrap_or(u64::MAX),
            )?;
            budget.poll()?;
            let Some(method) = methods.iter().find(|candidate| candidate.method == *method) else {
                return Ok(());
            };
            budget.charge(
                CountedBudgetDimension::AnalysisSteps,
                u64::try_from(method.parameter_slots.len()).unwrap_or(u64::MAX),
            )?;
            budget.poll()?;
            if let Some(position) = method
                .parameter_slots
                .iter()
                .position(|candidate| candidate == slot)
            {
                if let Some(source) = method
                    .generic_parameters
                    .as_ref()
                    .and_then(|parameters| parameters.get(position))
                {
                    if let Some(descriptor) = method.descriptor_parameters.get(position) {
                        budget.charge(
                            CountedBudgetDimension::AnalysisSteps,
                            u64::try_from(descriptor.len()).unwrap_or(u64::MAX),
                        )?;
                    }
                    let source_variables = charge_signature_type_proof(source, budget)?;
                    budget.charge(
                        CountedBudgetDimension::AnalysisSteps,
                        u64::try_from(
                            class_scope
                                .len()
                                .saturating_add(method.method_type_parameters.len()),
                        )
                        .unwrap_or(u64::MAX)
                        .saturating_mul(target_variables.max(source_variables)),
                    )?;
                    if let SignatureType::TypeVariable(name) = source {
                        for parameter in &method.method_type_parameters {
                            budget.poll()?;
                            if parameter.name != *name {
                                continue;
                            }
                            if let Some(bound) = &parameter.class_bound {
                                charge_signature_type_proof(bound, budget)?;
                            }
                            for bound in &parameter.interface_bounds {
                                charge_signature_type_proof(bound, budget)?;
                            }
                        }
                    }
                } else if let Some(descriptor) = method.descriptor_parameters.get(position) {
                    budget.charge(
                        CountedBudgetDimension::AnalysisSteps,
                        u64::try_from(descriptor.len()).unwrap_or(u64::MAX),
                    )?;
                }
            }
        }
    }
    Ok(())
}

fn class_type_arguments_present(ty: &SignatureType) -> bool {
    match ty {
        SignatureType::Array(element) => class_type_arguments_present(element),
        SignatureType::Class(class) => class
            .segments
            .iter()
            .any(|segment| !segment.arguments.is_empty()),
        SignatureType::Base(_) | SignatureType::TypeVariable(_) => false,
    }
}

fn signature_types_same_class_binding(
    left: &SignatureType,
    right: &SignatureType,
    class_scope: &[TypeParameterErasure],
    method_binders: &[jarde_reader::signature::TypeParameter],
) -> bool {
    match (left, right) {
        (SignatureType::Base(left), SignatureType::Base(right)) => left == right,
        (SignatureType::Array(left), SignatureType::Array(right)) => {
            signature_types_same_class_binding(left, right, class_scope, method_binders)
        }
        (SignatureType::TypeVariable(left), SignatureType::TypeVariable(right)) => {
            left == right
                && class_scope_variable(left, class_scope)
                && !method_binders.iter().any(|binder| binder.name == *left)
        }
        (SignatureType::Class(left), SignatureType::Class(right)) => {
            left.segments.len() == right.segments.len()
                && left
                    .segments
                    .iter()
                    .zip(&right.segments)
                    .all(|(left, right)| {
                        left.binary_name == right.binary_name
                            && left.arguments.len() == right.arguments.len()
                            && left
                                .arguments
                                .iter()
                                .zip(&right.arguments)
                                .all(|(left, right)| match (left, right) {
                                    (TypeArgument::Any, TypeArgument::Any) => true,
                                    (TypeArgument::Exact(left), TypeArgument::Exact(right))
                                    | (TypeArgument::Extends(left), TypeArgument::Extends(right))
                                    | (TypeArgument::Super(left), TypeArgument::Super(right)) => {
                                        signature_types_same_class_binding(
                                            left,
                                            right,
                                            class_scope,
                                            method_binders,
                                        )
                                    }
                                    _ => false,
                                })
                    })
        }
        _ => false,
    }
}

fn signature_class_erasure(ty: &SignatureType) -> Option<&[u8]> {
    let SignatureType::Class(class) = ty else {
        return None;
    };
    class
        .segments
        .last()
        .map(|segment| segment.binary_name.as_slice())
}

fn descriptor_reference_shape(descriptor: &[u8]) -> Option<(u32, Vec<u8>)> {
    let facts = descriptor_facts(descriptor, DescriptorKind::Field).ok()?;
    let component = facts.single()?;
    let Base::Object(name) = component.base() else {
        return None;
    };
    Some((component.dimensions(), name.0.clone()))
}

fn signature_reference_shape(ty: &SignatureType) -> Option<(u32, &[u8])> {
    let mut dimensions = 0_u32;
    let mut base = ty;
    while let SignatureType::Array(element) = base {
        dimensions = dimensions.checked_add(1)?;
        base = element;
    }
    Some((dimensions, signature_class_erasure(base)?))
}

fn signature_raw_reference_matches_descriptor(ty: &SignatureType, descriptor: &[u8]) -> bool {
    if class_type_arguments_present(ty) {
        return false;
    }
    let Some((signature_dimensions, signature_name)) = signature_reference_shape(ty) else {
        return false;
    };
    let Some((descriptor_dimensions, descriptor_name)) = descriptor_reference_shape(descriptor)
    else {
        return false;
    };
    signature_dimensions == descriptor_dimensions && signature_name == descriptor_name
}

fn raw_parameter_assignable(descriptor: &[u8], target: &SignatureType, java_release: u16) -> bool {
    let Some((source_dimensions, source_name)) = descriptor_reference_shape(descriptor) else {
        return false;
    };
    raw_reference_assignable(source_dimensions, &source_name, target, java_release)
}

fn raw_reference_assignable(
    source_dimensions: u32,
    source_name: &[u8],
    target: &SignatureType,
    java_release: u16,
) -> bool {
    let Some((target_dimensions, target_name)) = signature_reference_shape(target) else {
        return false;
    };
    if source_dimensions != target_dimensions {
        return false;
    }
    if source_name == target_name {
        return true;
    }
    let (Ok(source_name), Ok(target_name)) = (
        std::str::from_utf8(source_name),
        std::str::from_utf8(target_name),
    ) else {
        return false;
    };
    let source_name = source_name.replace('/', ".");
    let target_name = target_name.replace('/', ".");
    jarde_java::release_reference_argument_widens(java_release, &source_name, &target_name)
}

fn descriptor_reference_assignable(source: &[u8], target: &[u8], java_release: u16) -> bool {
    if source == target {
        return source
            .first()
            .is_some_and(|byte| *byte == b'L' || *byte == b'[');
    }
    let source_is_reference = source
        .first()
        .is_some_and(|byte| *byte == b'L' || *byte == b'[');
    if source_is_reference && target == b"Ljava/lang/Object;" {
        return true;
    }
    if source.first() == Some(&b'[')
        && matches!(target, b"Ljava/lang/Cloneable;" | b"Ljava/io/Serializable;")
    {
        return true;
    }
    let mut source_component = source;
    let mut target_component = target;
    while source_component.first() == Some(&b'[') && target_component.first() == Some(&b'[') {
        source_component = &source_component[1..];
        target_component = &target_component[1..];
        let source_primitive = source_component.first().is_some_and(|byte| {
            matches!(*byte, b'Z' | b'B' | b'C' | b'S' | b'I' | b'J' | b'F' | b'D')
        });
        let target_primitive = target_component.first().is_some_and(|byte| {
            matches!(*byte, b'Z' | b'B' | b'C' | b'S' | b'I' | b'J' | b'F' | b'D')
        });
        if source_primitive || target_primitive {
            return source_component == target_component;
        }
    }
    match (source_component.first(), target_component.first()) {
        (Some(b'['), Some(b'L')) => matches!(
            target_component,
            b"Ljava/lang/Object;" | b"Ljava/lang/Cloneable;" | b"Ljava/io/Serializable;"
        ),
        (Some(b'L'), Some(b'L')) => {
            let Some((0, source_name)) = descriptor_reference_shape(source_component) else {
                return false;
            };
            let Some((0, target_name)) = descriptor_reference_shape(target_component) else {
                return false;
            };
            target_name == b"java/lang/Object"
                || raw_reference_names_assignable(&source_name, &target_name, java_release)
        }
        _ => false,
    }
}

fn raw_reference_names_assignable(
    source_name: &[u8],
    target_name: &[u8],
    java_release: u16,
) -> bool {
    if source_name == target_name {
        return true;
    }
    let (Ok(source_name), Ok(target_name)) = (
        std::str::from_utf8(source_name),
        std::str::from_utf8(target_name),
    ) else {
        return false;
    };
    let source_name = source_name.replace('/', ".");
    let target_name = target_name.replace('/', ".");
    jarde_java::release_reference_argument_widens(java_release, &source_name, &target_name)
}

fn raw_field_receiver_source(
    use_site: &SameClassFieldUse,
    class_internal: &[u8],
    class_is_generic: bool,
    methods: &[SameClassPublishedMethodParameters],
    budget: &mut Budget,
) -> Result<bool> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    if !class_is_generic || use_site.opcode != 0xb5 || use_site.owner != class_internal {
        return Ok(false);
    }
    match use_site.receiver_source.as_ref() {
        Some(SameClassFieldReceiverSource::RawLocal) => Ok(true),
        Some(SameClassFieldReceiverSource::Parameter { slot }) => {
            budget.charge(
                CountedBudgetDimension::AnalysisSteps,
                u64::try_from(methods.len()).unwrap_or(u64::MAX),
            )?;
            let mut matching = methods
                .iter()
                .filter(|method| method.method == use_site.physical_method);
            let Some(method) = matching.next() else {
                return Ok(false);
            };
            if matching.next().is_some() {
                return Ok(false);
            }
            budget.charge(
                CountedBudgetDimension::AnalysisSteps,
                u64::try_from(method.parameter_slots.len()).unwrap_or(u64::MAX),
            )?;
            let Some(position) = method
                .parameter_slots
                .iter()
                .position(|parameter_slot| parameter_slot == slot)
            else {
                return Ok(false);
            };
            let Some(descriptor) = method.descriptor_parameters.get(position) else {
                return Ok(false);
            };
            if !descriptor_reference_shape(descriptor)
                .is_some_and(|(dimensions, owner)| dimensions == 0 && owner == class_internal)
            {
                return Ok(false);
            }
            if let Some(parameters) = &method.generic_parameters {
                let Some(source) = parameters.get(position) else {
                    return Ok(false);
                };
                budget.charge(
                    CountedBudgetDimension::AnalysisSteps,
                    u64::try_from(descriptor.len()).unwrap_or(u64::MAX),
                )?;
                Ok(signature_raw_reference_matches_descriptor(
                    source, descriptor,
                ))
            } else {
                Ok(true)
            }
        }
        Some(SameClassFieldReceiverSource::This) | None => Ok(false),
    }
}

fn raw_field_write_source_assignable(
    source: &SameClassFieldWriteSource,
    target_descriptor: &[u8],
    methods: &[SameClassPublishedMethodParameters],
    java_release: u16,
    budget: &mut Budget,
) -> Result<bool> {
    budget.poll()?;
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(target_descriptor.len()).unwrap_or(u64::MAX),
    )?;
    match source {
        SameClassFieldWriteSource::Null => Ok(true),
        SameClassFieldWriteSource::StringConstant { .. } => Ok(false),
        SameClassFieldWriteSource::RawAllocation { owner } => {
            budget.charge(
                CountedBudgetDimension::AnalysisSteps,
                u64::try_from(owner.len()).unwrap_or(u64::MAX),
            )?;
            let mut source = Vec::with_capacity(owner.len().saturating_add(2));
            source.push(b'L');
            source.extend_from_slice(owner);
            source.push(b';');
            Ok(descriptor_reference_assignable(
                &source,
                target_descriptor,
                java_release,
            ))
        }
        SameClassFieldWriteSource::Parameter { method, slot } => {
            budget.charge(
                CountedBudgetDimension::AnalysisSteps,
                u64::try_from(methods.len()).unwrap_or(u64::MAX),
            )?;
            let mut matching = methods
                .iter()
                .filter(|candidate| candidate.method == *method);
            let Some(method) = matching.next() else {
                return Ok(false);
            };
            if matching.next().is_some() {
                return Ok(false);
            }
            budget.charge(
                CountedBudgetDimension::AnalysisSteps,
                u64::try_from(method.parameter_slots.len()).unwrap_or(u64::MAX),
            )?;
            let Some(position) = method
                .parameter_slots
                .iter()
                .position(|candidate| candidate == slot)
            else {
                return Ok(false);
            };
            let Some(source_descriptor) = method.descriptor_parameters.get(position) else {
                return Ok(false);
            };
            budget.charge(
                CountedBudgetDimension::AnalysisSteps,
                u64::try_from(source_descriptor.len()).unwrap_or(u64::MAX),
            )?;
            Ok(descriptor_reference_assignable(
                source_descriptor,
                target_descriptor,
                java_release,
            ))
        }
    }
}

fn raw_method_type_variable_bound<'a>(
    source: &SignatureType,
    method: &'a SameClassPublishedMethodParameters,
    descriptor: &[u8],
) -> Option<&'a [u8]> {
    let SignatureType::TypeVariable(name) = source else {
        return None;
    };
    let mut parameters = method
        .method_type_parameters
        .iter()
        .filter(|parameter| parameter.name == *name);
    let parameter = parameters.next()?;
    if parameters.next().is_some() || !parameter.interface_bounds.is_empty() {
        return None;
    }
    let Some(SignatureType::Class(bound)) = parameter.class_bound.as_ref() else {
        return None;
    };
    if bound
        .segments
        .iter()
        .any(|segment| !segment.arguments.is_empty())
    {
        return None;
    }
    let bound_name = bound.segments.last()?.binary_name.as_slice();
    let Some((0, descriptor_name)) = descriptor_reference_shape(descriptor) else {
        return None;
    };
    (bound_name == descriptor_name.as_slice()).then_some(bound_name)
}

fn field_write_source_assignable(
    source: &SameClassFieldWriteSource,
    target: &SignatureType,
    class_scope: &[TypeParameterErasure],
    methods: &[SameClassPublishedMethodParameters],
    java_release: u16,
) -> bool {
    match source {
        SameClassFieldWriteSource::Null => true,
        SameClassFieldWriteSource::StringConstant { .. } => false,
        SameClassFieldWriteSource::RawAllocation { owner } => {
            if !matches!(target, SignatureType::Class(_)) || !class_type_arguments_present(target) {
                return false;
            }
            raw_reference_assignable(0, owner, target, java_release)
        }
        SameClassFieldWriteSource::Parameter { method, slot } => {
            let mut matching = methods
                .iter()
                .filter(|candidate| candidate.method == *method);
            let Some(method) = matching.next() else {
                return false;
            };
            if matching.next().is_some() {
                return false;
            }
            let Some(position) = method
                .parameter_slots
                .iter()
                .position(|candidate| candidate == slot)
            else {
                return false;
            };
            if let Some(parameters) = &method.generic_parameters {
                let Some(source) = parameters.get(position) else {
                    return false;
                };
                let Some(descriptor) = method.descriptor_parameters.get(position) else {
                    return false;
                };
                if signature_types_same_class_binding(
                    source,
                    target,
                    class_scope,
                    &method.method_type_parameters,
                ) {
                    return true;
                }
                if let Some(bound) = raw_method_type_variable_bound(source, method, descriptor)
                    && matches!(target, SignatureType::Class(_))
                    && class_type_arguments_present(target)
                {
                    return raw_reference_assignable(0, bound, target, java_release);
                }
                // A published Signature may still state a raw reference parameter, such as the
                // List parameter of an otherwise-generic method. Preserve that source shape as
                // the unchecked assignment it was; List<String> cannot enter this raw path.
                return !class_type_arguments_present(source)
                    && signature_raw_reference_matches_descriptor(source, descriptor)
                    && class_type_arguments_present(target)
                    && raw_parameter_assignable(descriptor, target, java_release);
            }
            method
                .descriptor_parameters
                .get(position)
                .is_some_and(|descriptor| {
                    // A raw reference (including a raw component in an array) can flow to its
                    // parameterized counterpart through Java's existing unchecked assignment.
                    class_type_arguments_present(target)
                        && raw_parameter_assignable(descriptor, target, java_release)
                })
        }
    }
}

fn prove_field_write_source_assignable(
    source: &SameClassFieldWriteSource,
    target: &SignatureType,
    class_scope: &[TypeParameterErasure],
    methods: &[SameClassPublishedMethodParameters],
    java_release: u16,
    budget: &mut Budget,
) -> Result<bool> {
    charge_field_write_source_proof(source, target, class_scope, methods, budget)?;
    budget.poll()?;
    Ok(field_write_source_assignable(
        source,
        target,
        class_scope,
        methods,
        java_release,
    ))
}

/// Whether one member's generic projection settled in this call, or is held for the class-level
/// same-class binding proof. A held candidate publishes nothing yet — no header, no refusal — so
/// the commit phase is the only place a half-decided member could appear, and it publishes whole
/// members through the same path a direct projection uses.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum SignatureProjection {
    /// This call decided the member: a header was projected, a refusal was written, or the member
    /// had no `Signature` to project at all.
    Settled,
    /// The member's pool entry names a same-class member and the use-site inventory is still
    /// being collected: the candidate is held back for the class-level proof.
    DeferredSameClass,
}

/// Decide one generic method-header projection from this member's own Signature, an already
/// published class-variable scope, and a typed return candidate from the same recovery run.
/// Syntax/erasure failures are refusals; budget and cancellation remain operation stops.
pub(crate) fn project_method_signature(
    record: &mut ClassSourceMethod,
    member: &MemberHeader,
    attributes: &MemberAttributes,
    candidate: Option<&GenericReturnCandidate>,
    constructor_candidate: Option<&GenericConstructorCandidate>,
    physical_fields: &[MemberHeader],
    bytes: &[u8],
    pool: &[CpEntryFacts],
    class_internal: &[u8],
    class_flags: u16,
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    class_scope: &[TypeParameterErasure],
    class_signature_present: bool,
    resolved_inner_classes: &[ResolvedInnerClass],
    same_class: SameClassBinding,
    unproved_this_delegate_bci: Option<u32>,
    budget: &mut Budget,
) -> Result<SignatureProjection> {
    let shells = attribute_shells(member, b"Signature");
    if shells.is_empty() {
        if class_flags & 0x4000 != 0
            && member.name.raw().0 == b"<init>"
            && member.descriptor.raw().0 == b"(Ljava/lang/String;ILjava/lang/String;)V"
        {
            record.enum_constructor_source_tail = EnumConstructorSourceTail::SingleString;
        }
        return project_member_inner_descriptor_path(record, candidate, budget)
            .map(|()| SignatureProjection::Settled);
    }
    let mut projection = record.take_generic_call_projection_state();
    let previous_constructor_tail = projection.enum_constructor_source_tail;
    let previous_constructor_erasure_refused =
        projection.enum_constructor_signature_erasure_refused;
    let result = project_method_signature_with_state(
        record,
        &mut projection,
        member,
        attributes,
        candidate,
        constructor_candidate,
        physical_fields,
        bytes,
        pool,
        class_internal,
        class_flags,
        class_superclass,
        class_interfaces,
        class_scope,
        class_signature_present,
        resolved_inner_classes,
        same_class,
        unproved_this_delegate_bci,
        budget,
    );
    if result.is_err() {
        projection.enum_constructor_source_tail = previous_constructor_tail;
        projection.enum_constructor_signature_erasure_refused =
            previous_constructor_erasure_refused;
    }
    record.install_generic_call_projection_state(projection);
    result
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn project_method_signature_with_state(
    record: &ClassSourceMethod,
    projection: &mut GenericCallProjectionState,
    member: &MemberHeader,
    attributes: &MemberAttributes,
    candidate: Option<&GenericReturnCandidate>,
    constructor_candidate: Option<&GenericConstructorCandidate>,
    physical_fields: &[MemberHeader],
    bytes: &[u8],
    pool: &[CpEntryFacts],
    class_internal: &[u8],
    class_flags: u16,
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    class_scope: &[TypeParameterErasure],
    class_signature_present: bool,
    resolved_inner_classes: &[ResolvedInnerClass],
    same_class: SameClassBinding,
    unproved_this_delegate_bci: Option<u32>,
    budget: &mut Budget,
) -> Result<SignatureProjection> {
    let shells = attribute_shells(member, b"Signature");
    if shells.is_empty() {
        return Err(Error::unsupported(
            "generic_call_projection_state_requires_signature",
            "a generic-call overlay can only project a member with a Signature attribute",
        ));
    }
    /// The closure's own two answers: a projection to publish, or a same-class entry this call
    /// must hold for the class-level proof.
    enum MethodProjection {
        Deferred,
        Declaration(String, Vec<u8>, &'static str),
    }
    let result = (|| -> Result<MethodProjection> {
        let facts = attribute_facts(bytes, &shells, pool, budget)?;
        let raw = facts
            .signature
            .ok_or_else(|| {
                Error::invalid_input(
                    "jvm_signature_missing",
                    "Signature attribute did not resolve",
                )
            })?
            .0;
        let parsed = parse_method_signature(&raw, budget)?;
        let name = &member.name.raw().0;
        projection.enum_constructor_source_tail = if shells.len() == 1
            && name.as_slice() == b"<init>"
            && member.descriptor.raw().0.as_slice() == b"(Ljava/lang/String;II)V"
            && parsed.type_parameters.is_empty()
            && parsed.parameters.as_slice() == [SignatureType::Base(b'I')]
            && parsed.result.is_none()
            && parsed.throws.is_empty()
        {
            EnumConstructorSourceTail::Int
        } else if shells.len() == 1
            && name.as_slice() == b"<init>"
            && member.descriptor.raw().0.as_slice() == b"(Ljava/lang/String;I)V"
            && parsed.type_parameters.is_empty()
            && parsed.parameters.is_empty()
            && parsed.result.is_none()
            && parsed.throws.is_empty()
        {
            EnumConstructorSourceTail::NoArg
        } else if shells.len() == 1
            && name.as_slice() == b"<init>"
            && member.descriptor.raw().0.as_slice() == b"(Ljava/lang/String;ILjava/lang/String;)V"
            && parsed.type_parameters.is_empty()
            && matches!(parsed.parameters.as_slice(), [SignatureType::Class(class)]
                if class.segments.len() == 1
                    && class.segments[0].binary_name == b"java/lang/String"
                    && class.segments[0].arguments.is_empty())
            && parsed.result.is_none()
            && parsed.throws.is_empty()
        {
            EnumConstructorSourceTail::SingleString
        } else if shells.len() == 1
            && name.as_slice() == b"<init>"
            && member.descriptor.raw().0.as_slice() == b"(Ljava/lang/String;I[Ljava/lang/String;)V"
            && parsed.type_parameters.is_empty()
            && matches!(parsed.parameters.as_slice(), [SignatureType::Array(element)]
                if matches!(element.as_ref(), SignatureType::Class(class)
                    if class.segments.len() == 1
                        && class.segments[0].binary_name == b"java/lang/String"
                        && class.segments[0].arguments.is_empty()))
            && parsed.result.is_none()
            && parsed.throws.is_empty()
        {
            EnumConstructorSourceTail::StringVarargs
        } else {
            EnumConstructorSourceTail::Unrecognized
        };
        let erasure = prove_method_signature_erasure_with_class_scope(
            &parsed,
            &member.descriptor.raw().0,
            &attributes.throws_raw,
            class_scope,
            budget,
        )?;
        let no_body_generic = matches!(record.outcome, ClassSourceOutcome::NoBody)
            && !parsed.type_parameters.is_empty();
        let class_scope_constructor = name == b"<init>"
            && parsed.type_parameters.is_empty()
            && class_signature_present
            && !class_scope.is_empty()
            && (constructor_candidate.is_some()
                || projection
                    .same_class_generic_body_proof
                    .as_ref()
                    .is_some_and(|proof| {
                        proof.constructor_call_bci.is_some() && proof.constructor_init.is_some()
                    }));
        let generic_constructor =
            name == b"<init>" && (!parsed.type_parameters.is_empty() || class_scope_constructor);
        if no_body_generic {
            prove_no_body_generic_hierarchy(
                record,
                class_internal,
                class_flags,
                class_superclass,
                class_interfaces,
                budget,
            )?;
        }
        let body_generic_throws = matches!(record.outcome, ClassSourceOutcome::Recovered { .. })
            && parsed.type_parameters.is_empty()
            && parsed
                .throws
                .iter()
                .any(|throws| matches!(throws, SignatureType::TypeVariable(_)));
        let body_method_local_generic_throws =
            matches!(record.outcome, ClassSourceOutcome::Recovered { .. })
                && !parsed.type_parameters.is_empty()
                && member.descriptor.raw().0.as_slice() == b"()V"
                && parsed.parameters.is_empty()
                && parsed.result.is_none()
                && matches!(parsed.throws.as_slice(), [SignatureType::TypeVariable(_)]);
        let static_method_local_generic_throws =
            matches!(record.outcome, ClassSourceOutcome::Recovered { .. })
                && !parsed.type_parameters.is_empty()
                && matches!(parsed.throws.as_slice(), [SignatureType::TypeVariable(_)]);
        let body_generic_null_return =
            matches!(record.outcome, ClassSourceOutcome::Recovered { .. })
                && !parsed.type_parameters.is_empty()
                && matches!(candidate, Some(GenericReturnCandidate {
                parameters,
                value: GenericReturnValue::NullLiteral,
            }) if parameters.is_empty());
        let body_generic_void = matches!(record.outcome, ClassSourceOutcome::Recovered { .. })
            && !parsed.type_parameters.is_empty()
            && parsed.result.is_none()
            && parsed.throws.is_empty()
            && attributes.throws_raw.is_empty()
            && matches!(candidate, Some(GenericReturnCandidate {
                parameters,
                value: GenericReturnValue::VoidBody { .. },
            }) if !parameters.is_empty());
        let body_ordinary_parameterized_null_return = matches!(
            record.outcome,
            ClassSourceOutcome::Recovered { .. }
        ) && parsed.type_parameters.is_empty()
            && shells.len() == 1
            && parsed.parameters.is_empty()
            && parsed.throws.is_empty()
            && attributes.throws_raw.is_empty()
            && member.descriptor.raw().0.as_slice() == b"()Ljava/util/List;"
            && member.access_flags & (ACC_PUBLIC | ACC_STATIC) == ACC_PUBLIC
            && !class_internal.contains(&b'$')
            && class_flags & (ACC_INTERFACE | ACC_ENUM | ACC_ANNOTATION) == 0
            && class_superclass == Some(b"java/lang/Object".as_slice())
            && class_interfaces.is_empty()
            && class_scope.is_empty()
            && !class_signature_present
            && matches!(parsed.result.as_ref(), Some(SignatureType::Class(class))
                    if matches!(class.segments.as_slice(), [segment]
                        if segment.binary_name.as_slice() == b"java/util/List"
                            && matches!(segment.arguments.as_slice(), [TypeArgument::Exact(SignatureType::Class(string))]
                                if matches!(string.segments.as_slice(), [string]
                                    if string.binary_name.as_slice() == b"java/lang/String"
                                        && string.arguments.is_empty()))))
            && matches!(candidate, Some(GenericReturnCandidate {
                    parameters,
                    value: GenericReturnValue::NullLiteral,
                }) if parameters.is_empty());
        budget.charge(
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(pool.len()).unwrap_or(u64::MAX),
        )?;
        if pool.iter().any(|entry| matches!(&entry.kind,
            CpEntryKind::MethodRef { owner, name: called, .. } | CpEntryKind::InterfaceMethodRef { owner, name: called, .. }
                if owner.0.as_slice() == class_internal && called.0.as_slice() == name.as_slice()
        )) {
            // The pool entry is a candidate fact, not a refusal: the class-level assembly holds
            // this member until its own decoded bodies state which members the entry's sites
            // really target. A proven binding falls through to the same shape proofs as an
            // unreferenced member; anything unproved keeps the existing refusal text.
            match same_class {
                SameClassBinding::Pending => {
                    return Ok(MethodProjection::Deferred);
                }
                SameClassBinding::Proven => {}
                SameClassBinding::OverloadPending => {
                    return Ok(MethodProjection::Deferred);
                }
                SameClassBinding::Unproved => {
                    return Err(Error::unsupported("generic_call_binding_unproved", "a same-class Methodref names this method or an adjacent overload"));
                }
            }
        }
        if class_scope_constructor && let Some(bci) = unproved_this_delegate_bci {
            return Err(Error::unsupported(
                "unproved_this_delegate_call",
                format!(
                    "same-class this-constructor delegation at BCI {bci} has no source argument adaptation proof"
                ),
            ));
        }
        let (declaration, proof) = if generic_constructor {
            (
                generic_constructor_declaration(
                    record,
                    projection,
                    attributes,
                    &parsed,
                    &erasure.type_parameters,
                    constructor_candidate,
                    projection.same_class_generic_body_proof.as_ref(),
                    physical_fields,
                    class_internal,
                    class_flags,
                    class_superclass,
                    class_interfaces,
                    class_scope,
                    class_signature_present,
                    budget,
                )?,
                if class_scope_constructor
                    && constructor_candidate
                        .is_some_and(|candidate| !candidate.field_writes.is_empty())
                    || class_scope_constructor
                        && projection
                            .same_class_generic_body_proof
                            .as_ref()
                            .is_some_and(|proof| !proof.field_write_sites.is_empty())
                {
                    "same-run AST/Code/SSA constructor body proof"
                } else if class_scope_constructor {
                    "same-run AST/Code/SSA empty Object-constructor proof"
                } else {
                    "same-run AST/SSA empty-constructor proof"
                },
            )
        } else if no_body_generic {
            let declaration = no_body_generic_method_declaration(
                record,
                projection,
                attributes,
                &parsed,
                &erasure.type_parameters,
                class_scope,
                budget,
            )?;
            (declaration, "physical no-body declaration proof")
        } else if body_method_local_generic_throws {
            let declaration = body_method_local_generic_throws_declaration(
                record,
                projection,
                attributes,
                &parsed,
                candidate,
                class_internal,
                class_flags,
                class_superclass,
                class_interfaces,
                class_scope,
                class_signature_present,
                budget,
            )?;
            (
                declaration,
                "same-run AST/Code/SSA empty-void and method-local Signature scope/erasure proof",
            )
        } else if body_generic_null_return {
            let declaration = generic_null_instance_method_declaration(
                record,
                projection,
                attributes,
                &parsed,
                candidate,
                class_internal,
                class_flags,
                class_superclass,
                class_interfaces,
                class_scope,
                class_signature_present,
                budget,
            )?;
            (
                declaration,
                "same-run AST/Code/SSA exact null-return and method-local Signature scope/erasure proof",
            )
        } else if body_generic_void {
            let declaration = generic_void_body_declaration(
                record,
                projection,
                attributes,
                &parsed,
                candidate,
                &erasure.type_parameters,
                class_internal,
                resolved_inner_classes,
                budget,
            )?;
            (
                declaration,
                "same-run complete straight-line AST/Code/SSA parameter-use and Signature erasure proof",
            )
        } else if body_ordinary_parameterized_null_return {
            let declaration = ordinary_parameterized_declaration(
                record,
                Some(projection),
                attributes,
                &parsed,
                candidate,
                class_flags,
                class_internal,
                class_superclass,
                class_interfaces,
                class_scope,
                true,
                budget,
            )?;
            (
                declaration,
                "same-run AST/Code/SSA exact null-return and parameterized method Signature erasure proof",
            )
        } else if static_method_local_generic_throws {
            let declaration = static_method_local_generic_throws_declaration(
                record,
                projection,
                attributes,
                &parsed,
                candidate,
                class_internal,
                class_flags,
                class_superclass,
                class_interfaces,
                class_scope,
                class_signature_present,
                budget,
            )?;
            (
                declaration,
                "same-run AST/SSA direct parameter return and method-local Signature scope/erasure proof",
            )
        } else if parsed.type_parameters.is_empty() {
            let empty_void_wildcard_parameter = ordinary_empty_void_wildcard_parameter_is_proved(
                record,
                attributes,
                &parsed,
                candidate,
                class_flags,
                class_internal,
                class_superclass,
                class_interfaces,
            );
            let declaration = ordinary_parameterized_declaration(
                record,
                Some(projection),
                attributes,
                &parsed,
                candidate,
                class_flags,
                class_internal,
                class_superclass,
                class_interfaces,
                class_scope,
                false,
                budget,
            )?;
            (
                declaration,
                if body_generic_throws {
                    "same-run AST/Code/SSA empty-void proof"
                } else if empty_void_wildcard_parameter {
                    "same-run AST/Code/SSA unused-parameter proof"
                } else if matches!(
                    candidate.map(|candidate| &candidate.value),
                    Some(GenericReturnValue::TypedFunctional { .. })
                ) {
                    "same-run direct Code/SSA/Program and LambdaMetafactory target proof"
                } else if matches!(
                    candidate.map(|candidate| &candidate.value),
                    Some(GenericReturnValue::VoidBody { .. })
                ) {
                    "same-run AST/Code/SSA straight-line void body proof"
                } else {
                    "same-run AST/SSA parameter-return proof"
                },
            )
        } else if let Some(body_proof) = projection.same_class_generic_body_proof.as_ref() {
            (
                generic_method_body_declaration(
                    record,
                    projection,
                    attributes,
                    &parsed,
                    body_proof,
                    class_scope,
                    budget,
                )?,
                "same-run complete AST/Code/SSA formal and return-consumer proof",
            )
        } else {
            (
                generic_method_declaration(
                    record, projection, attributes, &parsed, candidate, false, None,
                )?,
                "same-run AST/SSA parameter-return proof",
            )
        };
        Ok(MethodProjection::Declaration(declaration, raw, proof))
    })();
    match result {
        Ok(MethodProjection::Deferred) => Ok(SignatureProjection::DeferredSameClass),
        Ok(MethodProjection::Declaration(declaration, signature, proof)) => {
            let proof = if same_class == SameClassBinding::Proven {
                format!("{proof}; same-class call binding proved")
            } else {
                proof.to_owned()
            };
            projection
                .project_generic(record, declaration, &signature, &proof, budget)
                .map(|()| SignatureProjection::Settled)
        }
        Err(error @ (Error::BudgetExceeded { .. } | Error::Cancelled { .. })) => Err(error),
        Err(error) => {
            projection.enum_constructor_signature_erasure_refused =
                projection.enum_constructor_source_tail.is_recognized()
                    && matches!(
                        &error,
                        Error::InvalidInput { code, .. }
                            if code == "jvm_signature_erasure_mismatch"
                    );
            projection
                .refuse_generic(record, &error.to_string(), budget)
                .map(|()| SignatureProjection::Settled)
        }
    }
}

pub(crate) fn staged_same_class_generic_method_contract_with_state(
    record: &ClassSourceMethod,
    state: &GenericCallProjectionState,
    member: &MemberHeader,
    attributes: &MemberAttributes,
    bytes: &[u8],
    pool: &[CpEntryFacts],
    class_scope: &[TypeParameterErasure],
    budget: &mut Budget,
) -> Result<Option<SameClassGenericMethodContract>> {
    staged_same_class_generic_method_contract_facts(
        record,
        state.generic_signature_projected,
        state.declaration.is_some(),
        member,
        attributes,
        bytes,
        pool,
        class_scope,
        budget,
    )
}

fn staged_same_class_generic_method_contract_facts(
    record: &ClassSourceMethod,
    generic_signature_projected: bool,
    declaration_present: bool,
    member: &MemberHeader,
    attributes: &MemberAttributes,
    bytes: &[u8],
    pool: &[CpEntryFacts],
    class_scope: &[TypeParameterErasure],
    budget: &mut Budget,
) -> Result<Option<SameClassGenericMethodContract>> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    if !generic_signature_projected
        || record.item.identity.name.0 != member.name.raw().0
        || record.item.identity.descriptor.0 != member.descriptor.raw().0
        || !declaration_present
        || !matches!(
            &record.outcome,
            ClassSourceOutcome::Recovered { .. } | ClassSourceOutcome::NoBody
        )
    {
        return Ok(None);
    }
    same_class_generic_method_contract_from_signature(
        record.item.identity.clone(),
        member,
        attributes,
        bytes,
        pool,
        class_scope,
        budget,
    )
}

pub(crate) fn same_class_generic_method_contract_from_signature(
    method: PhysicalMethodId,
    member: &MemberHeader,
    attributes: &MemberAttributes,
    bytes: &[u8],
    pool: &[CpEntryFacts],
    class_scope: &[TypeParameterErasure],
    budget: &mut Budget,
) -> Result<Option<SameClassGenericMethodContract>> {
    let shells = attribute_shells(member, b"Signature");
    if shells.len() != 1 {
        return Ok(None);
    }
    let facts = attribute_facts(bytes, &shells, pool, budget)?;
    let Some(raw) = facts.signature.map(|signature| signature.0) else {
        return Ok(None);
    };
    let parsed = parse_method_signature(&raw, budget)?;
    prove_method_signature_erasure_with_class_scope(
        &parsed,
        &member.descriptor.raw().0,
        &attributes.throws_raw,
        class_scope,
        budget,
    )?;
    Ok(Some(SameClassGenericMethodContract {
        method,
        method_parameters: parsed.type_parameters,
        parameters: parsed.parameters,
        result: parsed.result,
    }))
}

/// Project the two method Signatures that close the first generic enclosing-member family slice.
/// The caller has already proved the physical root/child relation, capture and complete call
/// closure. This function supplies the root's published Signature scope to the existing method
/// erasure and source-type spelling machinery; it does not infer a type from emitted text.
pub(crate) fn project_member_family_generic_signature(
    record: &mut ClassSourceMethod,
    member: &MemberHeader,
    attributes: &MemberAttributes,
    bytes: &[u8],
    pool: &[CpEntryFacts],
    class_internal: &[u8],
    class_flags: u16,
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    class_scope: &[TypeParameterErasure],
    target: &jarde_java::report::ProvedMemberInnerTarget,
    root_return: bool,
    budget: &mut Budget,
) -> Result<()> {
    let refused = |why| Error::unsupported("generic_member_family_signature_unproved", why);
    let shells = attribute_shells(member, b"Signature");
    if shells.len() != 1
        || class_scope.len() != 1
        || class_scope[0].descriptor != b"Ljava/lang/Object;"
        || record.markers.len() != 1
        || !record.generic_signature_refused
        || !record.annotations.attributes.is_empty()
        || !record.parameter_annotations.attributes.is_empty()
        || !record.type_annotations.attributes.is_empty()
    {
        return Err(refused(
            "family method is outside the one-variable unannotated Signature slice",
        ));
    }
    let raw = attribute_facts(bytes, &shells, pool, budget)?
        .signature
        .ok_or_else(|| {
            Error::invalid_input(
                "jvm_signature_missing",
                "Signature attribute did not resolve",
            )
        })?
        .0;
    let parsed = parse_method_signature(&raw, budget)?;
    if !parsed.type_parameters.is_empty() {
        return Err(refused(
            "method-local type variables are outside the family scope",
        ));
    }
    prove_method_signature_erasure_with_class_scope(
        &parsed,
        &member.descriptor.raw().0,
        &attributes.throws_raw,
        class_scope,
        budget,
    )?;

    let declaration = if root_return {
        let SignatureType::Class(result) = parsed
            .result
            .as_ref()
            .ok_or_else(|| refused("root method has no generic result"))?
        else {
            return Err(refused("root result is not the selected member class"));
        };
        let [outer, inner] = result.segments.as_slice() else {
            return Err(refused(
                "root result does not carry the complete outer/member Signature path",
            ));
        };
        if class_internal != target.outer.as_bytes()
            || member.name.raw().0 != b"make"
            || member.descriptor.raw().0 != format!("()L{};", target.owner).as_bytes()
            || !parsed.parameters.is_empty()
            || !parsed.throws.is_empty()
            || outer.binary_name != target.outer.as_bytes()
            || outer.arguments.as_slice()
                != [TypeArgument::Exact(SignatureType::TypeVariable(
                    class_scope[0].name.clone(),
                ))]
            || inner.binary_name != target.owner.as_bytes()
            || !inner.arguments.is_empty()
        {
            return Err(refused(
                "root method Signature is not the selected Outer<T>.Inner return",
            ));
        }
        let result = spell_ordinary_signature_type_with_member_path(
            parsed.result.as_ref().unwrap(),
            class_scope,
            &target.source_type_path,
            budget,
            0,
        )?;
        let mut signature = method_descriptor(&member.descriptor.raw().0, false, false)
            .ok_or_else(|| refused("root physical descriptor cannot be spelled"))?;
        signature.returns = Some(result);
        let (name, aliased) = written_name(&member.name.raw().0);
        if aliased || !is_java_identifier(&name) {
            return Err(refused("root method name has no source spelling"));
        }
        format_generic_method_header(record, &signature, &name, &[], &attributes.throws)
    } else {
        if member.name.raw().0 != b"id"
            || member.descriptor.raw().0 != b"(Ljava/lang/Object;)Ljava/lang/Object;"
            || parsed.parameters.as_slice()
                != [SignatureType::TypeVariable(class_scope[0].name.clone())]
            || parsed.result.as_ref()
                != Some(&SignatureType::TypeVariable(class_scope[0].name.clone()))
            || !parsed.throws.is_empty()
        {
            return Err(refused(
                "child method Signature is not the inherited T id(T) shape",
            ));
        }
        let candidate = record.same_run_generic_return.as_ref().ok_or_else(|| {
            refused("child identity method has no retained same-run body candidate")
        })?;
        let mut staged = record.clone();
        // The one marker is precisely the independent physical request's missing outer scope.
        // It is omitted only on this temporary family-writer record after the relation gate above.
        staged.markers.clear();
        ordinary_parameterized_declaration(
            &staged,
            None,
            attributes,
            &parsed,
            Some(candidate),
            class_flags,
            class_internal,
            class_superclass,
            class_interfaces,
            class_scope,
            false,
            budget,
        )?
    };
    // `record` is a family-writer clone. Drop only the independently recorded scope refusal;
    // `project_generic` replaces it with the successful family-scope note below.
    record.markers.clear();
    record.project_generic(
        declaration,
        &raw,
        if root_return {
            "selected family return Signature and proved member construction"
        } else {
            "proved inherited outer-variable scope and same-run parameter-return proof"
        },
        budget,
    )
}

/// Spell one generic constructor only after its same-run body candidate, Signature erasure, and
/// the class-level call-binding gates have all passed. The complete declaration is built before
/// `project_generic` publishes any part of it.
#[allow(clippy::too_many_arguments)]
fn generic_constructor_declaration(
    record: &ClassSourceMethod,
    projection: &GenericCallProjectionState,
    attributes: &MemberAttributes,
    parsed: &jarde_reader::signature::MethodSignature,
    method_scope: &[TypeParameterErasure],
    candidate: Option<&GenericConstructorCandidate>,
    body_proof: Option<&SameClassGenericMethodBodyProof>,
    physical_fields: &[MemberHeader],
    class_internal: &[u8],
    class_flags: u16,
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    class_scope: &[TypeParameterErasure],
    class_signature_present: bool,
    budget: &mut Budget,
) -> Result<String> {
    let refused = |why| Error::unsupported("generic_constructor_source_unproved", why);
    let item = &record.item;
    if item.name.raw().0 != b"<init>"
        || projection.declaration.is_none()
        || !matches!(record.outcome, ClassSourceOutcome::Recovered { .. })
        || !projection.markers.is_empty()
        || item.access_flags & !(ACC_PUBLIC | ACC_PRIVATE | ACC_PROTECTED) != 0
        || attributes.default.is_some()
        || !attributes.throws_raw.is_empty()
        || !parsed.throws.is_empty()
        || parsed.result.is_some()
        || !record.annotations.attributes.is_empty()
        || !record.annotations.refusals.is_empty()
        || !record.parameter_annotations.attributes.is_empty()
        || !record.parameter_annotations.refusals.is_empty()
        || !record.type_annotations.attributes.is_empty()
        || !record.type_annotations.refusals.is_empty()
        || class_internal.contains(&b'$')
        || class_flags & (ACC_INTERFACE | ACC_ENUM | ACC_ANNOTATION) != 0
        || class_superclass != Some(b"java/lang/Object".as_slice())
        || !class_interfaces.is_empty()
    {
        return Err(refused(
            "constructor flags, throws, annotations, nesting, or class hierarchy lack a faithful source position",
        ));
    }
    let (parameters, init, forwarded_parameter_slots, field_writes) =
        if let Some(candidate) = candidate {
            (
                candidate.parameters.as_slice(),
                &candidate.init,
                candidate.forwarded_parameter_slots.as_slice(),
                candidate.field_writes.as_slice(),
            )
        } else {
            let proof = body_proof.filter(|proof| {
                proof.method == item.identity
                    && proof.constructor_call_bci.is_some()
                    && proof
                        .constructor_init
                        .as_ref()
                        .is_some_and(|init| init.bci == proof.constructor_call_bci)
                    && parsed.type_parameters.is_empty()
                    && method_scope.is_empty()
                    && !class_scope.is_empty()
                    && class_signature_present
            });
            let proof = proof
                .ok_or_else(|| refused("same-run AST/SSA does not prove the constructor body"))?;
            (
                proof.formal_names.as_slice(),
                proof.constructor_init.as_ref().unwrap(),
                &[][..],
                &[][..],
            )
        };
    let this_class = std::str::from_utf8(class_internal)
        .map_err(|_| refused("constructor owner has no source UTF-8"))?;
    if !init.presented
        || init.target != Some(jarde_java::ast::ConstructorTarget::Super)
        || init.class.as_deref() != Some("java/lang/Object")
        || init.declared.as_deref() != Some(this_class)
    {
        return Err(refused(
            "same-run InitRecord does not prove Object() for this class",
        ));
    }
    let mut signature = method_descriptor(&item.descriptor.raw().0, false, false)
        .ok_or_else(|| refused("physical constructor descriptor cannot be spelled"))?;
    let class_scope_constructor = parsed.type_parameters.is_empty();
    if signature.parameters.len() != parsed.parameters.len()
        || signature.parameters.len() != parameters.len()
        || (class_scope_constructor
            && (!forwarded_parameter_slots.is_empty()
                || !method_scope.is_empty()
                || class_scope.is_empty()
                || !class_signature_present))
        || (!class_scope_constructor && !field_writes.is_empty())
    {
        return Err(refused(
            "constructor Signature, physical parameter positions, and same-run body proof differ",
        ));
    }
    let mut scope = Vec::with_capacity(class_scope.len() + method_scope.len());
    scope.extend_from_slice(method_scope);
    scope.extend_from_slice(class_scope);
    let mut type_parameters = Vec::with_capacity(parsed.type_parameters.len());
    for parameter in &parsed.type_parameters {
        budget.poll()?;
        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        let name = std::str::from_utf8(&parameter.name)
            .map_err(|_| refused("constructor type parameter name is not source UTF-8"))?;
        if !is_java_identifier(name) {
            return Err(refused(
                "constructor type parameter has no Java source spelling",
            ));
        }
        let mut bounds = Vec::new();
        for bound in parameter
            .class_bound
            .iter()
            .chain(parameter.interface_bounds.iter())
        {
            bounds.push(spell_ordinary_signature_type(bound, &scope, budget, 0)?);
        }
        if bounds.is_empty() {
            bounds.push("java.lang.Object".to_owned());
        }
        type_parameters.push(format!("{name} extends {}", bounds.join(" & ")));
    }
    let mut parameter_types = Vec::with_capacity(parsed.parameters.len());
    for parameter in &parsed.parameters {
        parameter_types.push(spell_ordinary_signature_type(parameter, &scope, budget, 0)?);
    }
    for ((_, slot), (candidate_slot, name)) in signature.parameters.iter().zip(parameters) {
        if slot != candidate_slot || !is_java_identifier(name) {
            return Err(refused(
                "same-run constructor parameter slot or name is unproved",
            ));
        }
    }
    for ((spelling, _), ty) in signature.parameters.iter_mut().zip(parameter_types) {
        *spelling = ty;
    }
    if class_scope_constructor {
        budget.charge(
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(parameters.len())
                .unwrap_or(u64::MAX)
                .saturating_add(
                    u64::try_from(field_writes.len())
                        .unwrap_or(u64::MAX)
                        .saturating_mul(u64::try_from(parameters.len()).unwrap_or(u64::MAX)),
                ),
        )?;
        for write in field_writes {
            budget.poll()?;
            let mut parameter_found = false;
            for (slot, _) in parameters {
                budget.poll()?;
                parameter_found |= *slot == write.parameter_slot;
            }
            if write.owner.as_bytes() != class_internal || !parameter_found {
                return Err(refused(
                    "same-run field write does not name this class and a physical constructor parameter",
                ));
            }
            if !generic_constructor_field_matches_physical_field(
                write,
                class_internal,
                physical_fields,
                budget,
            )? {
                return Err(refused(
                    "same-run field write does not name one unique instance field declaration",
                ));
            }
        }
    }
    let class_name = simple_name(class_internal);
    if !is_java_identifier(&class_name) || class_name.contains('$') {
        return Err(refused("class name has no faithful constructor spelling"));
    }
    let args = parameters
        .iter()
        .zip(&signature.parameters)
        .map(|((_, name), (ty, _))| format!("{ty} {name}"))
        .collect::<Vec<_>>();
    let mut words = visibility(item.access_flags)
        .map(str::to_owned)
        .into_iter()
        .collect::<Vec<_>>();
    if !type_parameters.is_empty() {
        words.push(format!("<{}>", type_parameters.join(", ")));
    }
    let prefix = if words.is_empty() {
        String::new()
    } else {
        format!("{} ", words.join(" "))
    };
    Ok(format!("{prefix}{class_name}({})", args.join(", ")))
}

fn generic_constructor_field_matches_physical_field(
    write: &jarde_java::report::GenericConstructorFieldWrite,
    class_internal: &[u8],
    physical_fields: &[MemberHeader],
    budget: &mut Budget,
) -> Result<bool> {
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(physical_fields.len()).unwrap_or(u64::MAX),
    )?;
    if write.owner.as_bytes() != class_internal {
        return Ok(false);
    }
    let mut matching = None;
    for field in physical_fields {
        budget.poll()?;
        if field.name.raw().0 == write.name.as_bytes() {
            if matching.is_some() {
                return Ok(false);
            }
            matching = Some(field);
        }
    }
    Ok(matching.is_some_and(|field| {
        field.descriptor.raw().0 == write.descriptor.as_bytes()
            && field.access_flags & ACC_STATIC == 0
    }))
}

/// The initial no-body projection proves the class has no inherited source contract to satisfy.
/// `$` in a binary name is conservatively treated as nested because this class-source view does not
/// publish an InnerClasses nesting proof.
fn prove_no_body_generic_hierarchy(
    record: &ClassSourceMethod,
    class_internal: &[u8],
    class_flags: u16,
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    budget: &mut Budget,
) -> Result<()> {
    let refused = |why| Error::unsupported("generic_inherited_contract_unproved", why);
    budget.poll()?;
    if !matches!(record.no_body_kind, Some(NoBodyKind::Abstract))
        || class_flags & (ACC_ANNOTATION | ACC_ENUM) != 0
        || class_internal.contains(&b'$')
        || class_superclass != Some(b"java/lang/Object".as_slice())
        || !class_interfaces.is_empty()
    {
        return Err(refused(
            "no-body generic projection requires a top-level class or root interface with Object as its physical superclass and no interfaces",
        ));
    }
    let name = &record.item.name.raw().0;
    if is_object_instance_method_name(name) {
        return Err(refused(
            "method name may override an Object instance method",
        ));
    }
    Ok(())
}

/// Re-spell descriptor positions only when the same-run body returned the selected member
/// creation. This is the raw-signature slice: the body's target and qualifier slot constrain every
/// replacement, and the physical descriptor still controls all other positions.
fn project_member_inner_descriptor_path(
    record: &mut ClassSourceMethod,
    candidate: Option<&GenericReturnCandidate>,
    budget: &mut Budget,
) -> Result<()> {
    let Some(candidate) = candidate else {
        return Ok(());
    };
    let (source_type_path, target_owner, qualifier_slot) = match &candidate.value {
        GenericReturnValue::MemberCreation {
            target,
            qualifier_slot,
        } => (
            &target.source_type_path,
            target.owner.as_str(),
            Some(*qualifier_slot),
        ),
        GenericReturnValue::StaticMemberCreation { target, .. } => {
            (&target.source_type_path, target.owner.as_str(), None)
        }
        _ => return Ok(()),
    };
    let refused = |why| Error::unsupported("member_inner_source_path_unproved", why);
    if record.declaration.is_none()
        || !record.markers.is_empty()
        || !matches!(record.outcome, ClassSourceOutcome::Recovered { .. })
    {
        return Err(refused(
            "the same-run member creation has no complete recovered declaration to project",
        ));
    }
    let signature = method_descriptor(
        &record.item.descriptor.raw().0,
        is_static(record.item.access_flags),
        record.item.access_flags & ACC_VARARGS != 0,
    )
    .ok_or_else(|| refused("physical descriptor cannot be spelled"))?;
    if candidate.parameters.len() != signature.parameters.len() {
        return Err(refused(
            "same-run parameter positions differ from the descriptor",
        ));
    }
    if let Some(qualifier_slot) = qualifier_slot {
        let Some((qualifier_type, _)) = signature
            .parameters
            .iter()
            .find(|(_, slot)| *slot == qualifier_slot)
        else {
            return Err(refused("member qualifier is not a method parameter slot"));
        };
        let Some(outer) = source_type_path.iter().find(|segment| {
            segment.binary_name
                == source_type_path
                    .last()
                    .and_then(|segment| segment.enclosing_binary_name.as_deref())
                    .unwrap_or("")
        }) else {
            return Err(refused("selected source path has no enclosing member type"));
        };
        let Some(member) = source_type_path
            .iter()
            .find(|segment| segment.binary_name == target_owner)
        else {
            return Err(refused("selected source path has no target member type"));
        };
        if qualifier_type != &outer.binary_name.replace('/', ".")
            || member.enclosing_binary_name.as_deref() != Some(outer.binary_name.as_str())
            || member.is_static
            || !outer.is_static
            || source_type_path.last().is_none_or(|last| last != member)
        {
            return Err(refused(
                "selected qualifier, enclosing type, and member path do not agree",
            ));
        }
    }
    if let Some(result) = &signature.returns
        && result != "java.lang.Object"
        && result != &target_owner.replace('/', ".")
    {
        return Err(refused(
            "physical result is neither Object nor the selected member type",
        ));
    }
    for ((_, descriptor_slot), (candidate_slot, name)) in
        signature.parameters.iter().zip(&candidate.parameters)
    {
        if descriptor_slot != candidate_slot || !is_java_identifier(name) {
            return Err(refused("same-run parameter names or slots are incomplete"));
        }
    }

    let mut declaration = record.declaration.clone().expect("checked above");
    let mut mapped_segments = source_type_path.iter().collect::<Vec<_>>();
    mapped_segments.sort_by_key(|segment| std::cmp::Reverse(segment.binary_name.len()));
    let mut changed = false;
    for segment in mapped_segments {
        let physical_name = segment.binary_name.replace('/', ".");
        let expected_count = signature
            .parameters
            .iter()
            .filter(|(ty, _)| descriptor_component_base(ty) == physical_name)
            .count()
            + usize::from(
                signature
                    .returns
                    .as_deref()
                    .is_some_and(|ty| descriptor_component_base(ty) == physical_name),
            );
        if expected_count == 0 {
            continue;
        }
        let source_name = match &candidate.value {
            GenericReturnValue::StaticMemberCreation { target, .. }
                if segment.binary_name == target.owner =>
            {
                target.simple_name.as_str()
            }
            _ => segment.source_name.as_str(),
        };
        let (rewritten, count) = replace_java_type_token(&declaration, &physical_name, source_name);
        if count != expected_count {
            return Err(refused(
                "declaration type positions do not match the physical member descriptor",
            ));
        }
        declaration = rewritten;
        changed = true;
    }
    if !changed {
        return Err(refused(
            "selected member source path does not occur in the physical method declaration",
        ));
    }
    // Keep the projection explicit beside the recovered method so readers can see why the `$`
    // spelling changed. The block itself is reused verbatim from the same run.
    let marker = format!(
        "// jarde: descriptor type path for `{}` follows the same-run proved member creation",
        target_owner
    );
    let mut markers = record.markers.clone();
    markers.push(marker);
    let report = match &record.outcome {
        ClassSourceOutcome::Recovered { report, .. } => report,
        _ => unreachable!("checked recovered outcome above"),
    };
    let Some(block) = artifact(&report.text) else {
        return Err(refused("same-run body artifact has no complete block"));
    };
    let text = prefix_method_annotations(
        block_member(&declaration, Placed::Block(block), &markers),
        &record.annotations,
    );
    budget.charge(
        CountedBudgetDimension::OutputBytes,
        u64::try_from(text.len()).unwrap_or(u64::MAX),
    )?;
    record.declaration = Some(declaration);
    record.text = text;
    record.markers = markers;
    Ok(())
}

fn descriptor_component_base(ty: &str) -> &str {
    ty.strip_suffix("[]").unwrap_or(ty)
}

fn replace_java_type_token(text: &str, from: &str, to: &str) -> (String, usize) {
    let is_identifier = |byte: u8| byte.is_ascii_alphanumeric() || matches!(byte, b'_' | b'$');
    let bytes = text.as_bytes();
    let needle = from.as_bytes();
    let mut output = String::with_capacity(text.len());
    let mut cursor = 0;
    let mut count = 0;
    while cursor < bytes.len() {
        let Some(relative) = text[cursor..].find(from) else {
            output.push_str(&text[cursor..]);
            break;
        };
        let start = cursor + relative;
        let end = start + needle.len();
        let left_is_boundary = start == 0 || !is_identifier(bytes[start - 1]);
        let right_is_boundary = end == bytes.len() || !is_identifier(bytes[end]);
        if left_is_boundary && right_is_boundary {
            output.push_str(&text[cursor..start]);
            output.push_str(to);
            cursor = end;
            count += 1;
        } else {
            let next = start + from.len();
            output.push_str(&text[cursor..next]);
            cursor = next;
        }
    }
    (output, count)
}

fn is_object_instance_method_name(name: &[u8]) -> bool {
    const OBJECT_INSTANCE_METHODS: &[&[u8]] = &[
        b"getClass",
        b"hashCode",
        b"equals",
        b"clone",
        b"toString",
        b"notify",
        b"notifyAll",
        b"wait",
        b"finalize",
    ];
    OBJECT_INSTANCE_METHODS.contains(&name)
}

#[allow(clippy::too_many_arguments)]
fn prove_body_generic_throws_shape(
    record: &ClassSourceMethod,
    parsed: &jarde_reader::signature::MethodSignature,
    candidate: Option<&GenericReturnCandidate>,
    class_internal: &[u8],
    class_flags: u16,
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    budget: &mut Budget,
) -> Result<()> {
    let refused = |why| Error::unsupported("body_generic_throws_source_unproved", why);
    let item = &record.item;
    if !matches!(record.outcome, ClassSourceOutcome::Recovered { .. })
        || !matches!(item.descriptor.raw().0.as_slice(), b"()V")
        || item.name.raw().0 == b"<init>"
        || item.name.raw().0 == b"<clinit>"
        || is_object_instance_method_name(&item.name.raw().0)
        || item.access_flags & (ACC_ABSTRACT | ACC_NATIVE | ACC_VARARGS) != 0
        || class_internal.contains(&b'$')
        || class_flags & (ACC_INTERFACE | ACC_ENUM | ACC_ANNOTATION) != 0
        || class_superclass != Some(b"java/lang/Object".as_slice())
        || !class_interfaces.is_empty()
        || !parsed.type_parameters.is_empty()
        || !parsed.parameters.is_empty()
        || parsed.result.is_some()
        || !matches!(parsed.throws.as_slice(), [SignatureType::TypeVariable(_)])
    {
        return Err(refused(
            "method Signature, member, or class hierarchy exceeds the supported empty-void shape",
        ));
    }
    if !matches!(
        candidate,
        Some(GenericReturnCandidate {
            parameters,
            value: GenericReturnValue::EmptyVoid,
        }) if parameters.is_empty()
    ) {
        return Err(refused(
            "same-run AST/Code/SSA does not prove the exact empty void body",
        ));
    }
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn prove_body_method_local_generic_throws_shape(
    record: &ClassSourceMethod,
    projection: &GenericCallProjectionState,
    parsed: &jarde_reader::signature::MethodSignature,
    candidate: Option<&GenericReturnCandidate>,
    class_internal: &[u8],
    class_flags: u16,
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    class_scope: &[TypeParameterErasure],
    class_signature_present: bool,
    budget: &mut Budget,
) -> Result<()> {
    let refused = |why| Error::unsupported("body_method_local_generic_throws_source_unproved", why);
    let item = &record.item;
    if !matches!(record.outcome, ClassSourceOutcome::Recovered { .. })
        || projection.declaration.is_none()
        || !projection.markers.is_empty()
        || !record.annotations.refusals.is_empty()
        || !record.parameter_annotations.refusals.is_empty()
        || !record.type_annotations.attributes.is_empty()
        || !record.type_annotations.refusals.is_empty()
        || item.access_flags
            & !(ACC_PUBLIC
                | ACC_PRIVATE
                | ACC_PROTECTED
                | ACC_FINAL
                | ACC_SYNCHRONIZED
                | ACC_STRICT)
            != 0
        || item.descriptor.raw().0.as_slice() != b"()V"
        || matches!(item.name.raw().0.as_slice(), b"<init>" | b"<clinit>")
        || is_object_instance_method_name(&item.name.raw().0)
        || class_internal.contains(&b'$')
        || class_flags & (ACC_INTERFACE | ACC_ENUM | ACC_ANNOTATION) != 0
        || class_superclass != Some(b"java/lang/Object".as_slice())
        || !class_interfaces.is_empty()
        || !class_scope.is_empty()
        || class_signature_present
        || !parsed.parameters.is_empty()
        || parsed.result.is_some()
        || parsed.type_parameters.len() != 1
        || !matches!(parsed.throws.as_slice(), [SignatureType::TypeVariable(_)])
    {
        return Err(refused(
            "method Signature, member, or class hierarchy exceeds the supported empty-void shape",
        ));
    }
    if !matches!(
        candidate,
        Some(GenericReturnCandidate {
            parameters,
            value: GenericReturnValue::EmptyVoid,
        }) if parameters.is_empty()
    ) {
        return Err(refused(
            "same-run AST/Code/SSA does not prove the exact empty void body",
        ));
    }
    let [parameter] = parsed.type_parameters.as_slice() else {
        unreachable!("shape checked above")
    };
    let bounds = parameter
        .class_bound
        .iter()
        .chain(parameter.interface_bounds.iter())
        .collect::<Vec<_>>();
    let [SignatureType::Class(bound)] = bounds.as_slice() else {
        return Err(refused(
            "method variable must have exactly one proved class bound and no additional bounds",
        ));
    };
    let [segment] = bound.segments.as_slice() else {
        return Err(refused("method variable bound is nested"));
    };
    if !segment.arguments.is_empty()
        || !matches!(
            segment.binary_name.as_slice(),
            b"java/lang/Throwable"
                | b"java/lang/Exception"
                | b"java/lang/RuntimeException"
                | b"java/lang/Error"
        )
    {
        return Err(refused(
            "method variable bound is not a proved JDK throwable root",
        ));
    }
    let name = std::str::from_utf8(&parameter.name)
        .map_err(|_| refused("method variable name is not source UTF-8"))?;
    if !is_java_identifier(name)
        || parsed.throws.first() != Some(&SignatureType::TypeVariable(parameter.name.clone()))
    {
        return Err(refused(
            "throws variable is not the source-spellable method-local variable",
        ));
    }
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn body_method_local_generic_throws_declaration(
    record: &ClassSourceMethod,
    projection: &GenericCallProjectionState,
    attributes: &MemberAttributes,
    parsed: &jarde_reader::signature::MethodSignature,
    candidate: Option<&GenericReturnCandidate>,
    class_internal: &[u8],
    class_flags: u16,
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    class_scope: &[TypeParameterErasure],
    class_signature_present: bool,
    budget: &mut Budget,
) -> Result<String> {
    prove_body_method_local_generic_throws_shape(
        record,
        projection,
        parsed,
        candidate,
        class_internal,
        class_flags,
        class_superclass,
        class_interfaces,
        class_scope,
        class_signature_present,
        budget,
    )?;
    if attributes.default.is_some() {
        return Err(Error::unsupported(
            "body_method_local_generic_throws_source_unproved",
            "annotation default has no source position in this method shape",
        ));
    }
    let [parameter] = parsed.type_parameters.as_slice() else {
        return Err(Error::unsupported(
            "body_method_local_generic_throws_source_unproved",
            "method must declare exactly one local type variable",
        ));
    };
    let variable_name = std::str::from_utf8(&parameter.name).map_err(|_| {
        Error::unsupported(
            "body_method_local_generic_throws_source_unproved",
            "method variable name is not source UTF-8",
        )
    })?;
    let bound_internal = match parameter.class_bound.as_ref() {
        Some(SignatureType::Class(bound)) => &bound.segments[0].binary_name,
        _ => unreachable!("validated by shape proof"),
    };
    let bound = simple_generic_class_name(bound_internal)?;
    let signature =
        method_descriptor(&record.item.descriptor.raw().0, false, false).ok_or_else(|| {
            Error::unsupported(
                "body_method_local_generic_throws_source_unproved",
                "physical method descriptor cannot be spelled",
            )
        })?;
    let (method_name, aliased) = written_name(&record.item.name.raw().0);
    if aliased || !is_java_identifier(&method_name) {
        return Err(Error::unsupported(
            "body_method_local_generic_throws_source_unproved",
            "method name has no faithful Java spelling",
        ));
    }
    Ok(format_generic_method_header(
        record,
        &signature,
        &method_name,
        &[format!("{variable_name} extends {bound}")],
        &[variable_name.to_owned()],
    ))
}

#[allow(clippy::too_many_arguments)]
fn static_method_local_generic_throws_declaration(
    record: &ClassSourceMethod,
    projection: &GenericCallProjectionState,
    attributes: &MemberAttributes,
    parsed: &jarde_reader::signature::MethodSignature,
    candidate: Option<&GenericReturnCandidate>,
    class_internal: &[u8],
    class_flags: u16,
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    class_scope: &[TypeParameterErasure],
    class_signature_present: bool,
    budget: &mut Budget,
) -> Result<String> {
    let refused = |why| Error::unsupported("generic_source_shape_unproved", why);
    let item = &record.item;
    if !matches!(record.outcome, ClassSourceOutcome::Recovered { .. })
        || item.access_flags & ACC_STATIC == 0
        || class_internal.contains(&b'$')
        || class_flags & (ACC_INTERFACE | ACC_ENUM | ACC_ANNOTATION) != 0
        || class_superclass != Some(b"java/lang/Object".as_slice())
        || !class_interfaces.is_empty()
        || !class_scope.is_empty()
        || class_signature_present
        || !matches!(
            candidate,
            Some(GenericReturnCandidate {
                value: GenericReturnValue::Parameter(_),
                ..
            })
        )
        || !matches!(parsed.throws.as_slice(), [SignatureType::TypeVariable(_)])
    {
        return Err(refused(
            "method-local generic throws requires a direct parameter return in a top-level, non-generic Object subclass with no interfaces",
        ));
    }
    let [SignatureType::TypeVariable(throws_variable)] = parsed.throws.as_slice() else {
        unreachable!("shape checked above")
    };
    let mut matching_parameters = parsed
        .type_parameters
        .iter()
        .filter(|parameter| parameter.name == *throws_variable);
    let Some(parameter) = matching_parameters.next() else {
        return Err(refused(
            "throws variable is outside the method-local type parameter scope",
        ));
    };
    if matching_parameters.next().is_some() {
        return Err(refused(
            "throws variable does not identify a unique method-local type parameter",
        ));
    }
    if !parameter.interface_bounds.is_empty() {
        return Err(refused(
            "throws variable cannot have additional interface bounds",
        ));
    }
    let Some(SignatureType::Class(bound)) = parameter.class_bound.as_ref() else {
        return Err(refused(
            "throws variable must have one explicit class first bound",
        ));
    };
    let [segment] = bound.segments.as_slice() else {
        return Err(refused("throws variable bound is nested"));
    };
    if !segment.arguments.is_empty()
        || !matches!(
            segment.binary_name.as_slice(),
            b"java/lang/Throwable"
                | b"java/lang/Exception"
                | b"java/lang/RuntimeException"
                | b"java/lang/Error"
        )
    {
        return Err(refused(
            "throws variable bound is not a proved JDK throwable root",
        ));
    }
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    generic_method_declaration(
        record, projection, attributes, parsed, candidate, true, None,
    )
}

fn no_body_generic_method_declaration(
    record: &ClassSourceMethod,
    projection: &GenericCallProjectionState,
    attributes: &MemberAttributes,
    parsed: &jarde_reader::signature::MethodSignature,
    method_scope: &[TypeParameterErasure],
    class_scope: &[TypeParameterErasure],
    budget: &mut Budget,
) -> Result<String> {
    let refused = |why| Error::unsupported("generic_source_shape_unproved", why);
    let item = &record.item;
    if projection.declaration.is_none()
        || !matches!(record.no_body_kind, Some(NoBodyKind::Abstract))
        || matches!(item.name.raw().0.as_slice(), b"<init>" | b"<clinit>")
        || item.access_flags
            & !(ACC_PUBLIC
                | ACC_PRIVATE
                | ACC_PROTECTED
                | ACC_STATIC
                | ACC_FINAL
                | ACC_ABSTRACT
                | ACC_NATIVE
                | ACC_SYNCHRONIZED
                | ACC_STRICT
                | ACC_VARARGS)
            != 0
        || attributes.default.is_some()
        || !record.annotations.refusals.is_empty()
        || !record.parameter_annotations.refusals.is_empty()
        || !record.type_annotations.attributes.is_empty()
        || !record.type_annotations.refusals.is_empty()
    {
        return Err(refused(
            "method flags, annotations, or source name cannot be preserved",
        ));
    }
    let mut scope = Vec::with_capacity(class_scope.len() + method_scope.len());
    scope.extend_from_slice(class_scope);
    scope.extend_from_slice(method_scope);
    let mut signature = method_descriptor(
        &item.descriptor.raw().0,
        is_static(item.access_flags),
        item.access_flags & ACC_VARARGS != 0,
    )
    .ok_or_else(|| refused("physical method descriptor cannot be spelled"))?;
    if signature.parameters.len() != parsed.parameters.len() {
        return Err(refused("generic and physical parameter positions differ"));
    }
    let mut parameters = Vec::with_capacity(parsed.parameters.len());
    for parameter in &parsed.parameters {
        parameters.push(spell_ordinary_signature_type(parameter, &scope, budget, 0)?);
    }
    let result = parsed
        .result
        .as_ref()
        .map(|result| spell_ordinary_signature_type(result, &scope, budget, 0))
        .transpose()?;
    let mut type_parameters = Vec::with_capacity(parsed.type_parameters.len());
    for parameter in &parsed.type_parameters {
        let mut bounds = Vec::new();
        for bound in parameter
            .class_bound
            .iter()
            .chain(parameter.interface_bounds.iter())
        {
            bounds.push(spell_ordinary_signature_type(bound, &scope, budget, 0)?);
        }
        let name = std::str::from_utf8(&parameter.name)
            .map_err(|_| refused("type parameter name is not source UTF-8"))?;
        if !is_java_identifier(name) {
            return Err(refused("type parameter has no Java source spelling"));
        }
        if bounds.is_empty() {
            bounds.push("java.lang.Object".to_owned());
        }
        type_parameters.push(format!("{name} extends {}", bounds.join(" & ")));
    }
    let mut generic_throws = Vec::with_capacity(parsed.throws.len());
    for exception in &parsed.throws {
        budget.poll()?;
        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        match exception {
            SignatureType::TypeVariable(variable) => {
                let Some(first_bound) = scope.iter().find(|entry| entry.name == *variable) else {
                    return Err(refused(
                        "throws variable is outside the emitted class and method scopes",
                    ));
                };
                if !matches!(
                    first_bound.descriptor.as_slice(),
                    b"Ljava/lang/Throwable;"
                        | b"Ljava/lang/Exception;"
                        | b"Ljava/lang/RuntimeException;"
                        | b"Ljava/lang/Error;"
                ) {
                    return Err(refused(
                        "throws variable first bound is not a proved JDK throwable root",
                    ));
                }
                generic_throws.push(
                    std::str::from_utf8(variable)
                        .map_err(|_| refused("throws variable name is not source UTF-8"))?
                        .to_owned(),
                );
            }
            SignatureType::Class(class) => {
                let [segment] = class.segments.as_slice() else {
                    return Err(refused(
                        "nested throws class has no preserved source position",
                    ));
                };
                if !segment.arguments.is_empty() {
                    return Err(refused(
                        "parameterized throws class is not a legal Java exception type",
                    ));
                }
                generic_throws.push(simple_generic_class_name(&segment.binary_name)?);
            }
            _ => return Err(refused("throws type has no supported Java source spelling")),
        }
    }
    let throws = if parsed.throws.is_empty() {
        attributes.throws.clone()
    } else {
        generic_throws
    };
    for ((spelling, _), ty) in signature.parameters.iter_mut().zip(parameters) {
        *spelling = ty;
    }
    signature.returns = result;
    let (name, aliased) = written_name(&item.name.raw().0);
    if aliased || !is_java_identifier(&name) {
        return Err(refused("method name has no faithful Java spelling"));
    }
    Ok(format_generic_method_header(
        record,
        &signature,
        &name,
        &type_parameters,
        &throws,
    ))
}

/// Assemble a fully spelled generic method head after its source types and proof gates have
/// succeeded. No-body methods and recovered empty-void methods share this final spelling path.
fn format_generic_method_header(
    record: &ClassSourceMethod,
    signature: &Signature,
    name: &str,
    type_parameters: &[String],
    throws: &[String],
) -> String {
    let flags = record.item.access_flags;
    let mut words = Vec::new();
    words.extend(visibility(flags));
    if flags & ACC_STATIC != 0 {
        words.push("static");
    }
    if flags & ACC_FINAL != 0 {
        words.push("final");
    }
    if flags & ACC_ABSTRACT != 0 {
        words.push("abstract");
    }
    if flags & ACC_NATIVE != 0 {
        words.push("native");
    }
    if flags & ACC_SYNCHRONIZED != 0 {
        words.push("synchronized");
    }
    if flags & ACC_STRICT != 0 {
        words.push("strictfp");
    }
    let mut arguments = Vec::with_capacity(signature.parameters.len());
    for (position, (ty, slot)) in signature.parameters.iter().enumerate() {
        let annotations = record
            .parameter_annotations
            .uses_by_position
            .get(position)
            .into_iter()
            .flatten()
            .map(|annotation| format!("{annotation} "))
            .collect::<String>();
        let varargs = signature.varargs && position + 1 == signature.parameters.len();
        arguments.push(format!(
            "{annotations}{} arg{slot}",
            varargs_type(ty, varargs)
        ));
    }
    let mut declaration = String::new();
    if !words.is_empty() {
        declaration.push_str(&words.join(" "));
        declaration.push(' ');
    }
    if !type_parameters.is_empty() {
        declaration.push('<');
        declaration.push_str(&type_parameters.join(", "));
        declaration.push_str("> ");
    }
    declaration.push_str(signature.returns.as_deref().unwrap_or("void"));
    declaration.push(' ');
    declaration.push_str(name);
    declaration.push('(');
    declaration.push_str(&arguments.join(", "));
    declaration.push(')');
    declaration.push_str(&throws_clause(throws));
    declaration
}

/// Spell ordinary parameterized method types only after the reader has proved their erasures.
/// A recovered body's candidate is the same Program/SSA reading that supplied its parameter
/// names; no-body members have no Program and use descriptor slot names.
fn ordinary_parameterized_declaration(
    record: &ClassSourceMethod,
    projection: Option<&GenericCallProjectionState>,
    attributes: &MemberAttributes,
    parsed: &jarde_reader::signature::MethodSignature,
    candidate: Option<&GenericReturnCandidate>,
    class_flags: u16,
    class_internal: &[u8],
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    class_scope: &[TypeParameterErasure],
    allow_null_return: bool,
    budget: &mut Budget,
) -> Result<String> {
    let refused = |why| Error::unsupported("ordinary_generic_source_unproved", why);
    let item = &record.item;
    let empty_void_wildcard_parameter = ordinary_empty_void_wildcard_parameter_is_proved(
        record,
        attributes,
        parsed,
        candidate,
        class_flags,
        class_internal,
        class_superclass,
        class_interfaces,
    );
    if projection.map_or(record.declaration.is_none(), |state| {
        state.declaration.is_none()
    }) || matches!(item.name.raw().0.as_slice(), b"<init>" | b"<clinit>")
        || item.access_flags
            & !(ACC_PUBLIC
                | ACC_PRIVATE
                | ACC_PROTECTED
                | ACC_STATIC
                | ACC_FINAL
                | ACC_ABSTRACT
                | ACC_NATIVE
                | ACC_SYNCHRONIZED
                | ACC_STRICT
                | ACC_VARARGS)
            != 0
        || attributes.default.is_some()
        || !record.annotations.refusals.is_empty()
        || !record.parameter_annotations.refusals.is_empty()
        || !record.type_annotations.attributes.is_empty()
        || !record.type_annotations.refusals.is_empty()
    {
        return Err(refused(
            "member flags, annotation positions, or source name cannot be preserved",
        ));
    }
    match &record.outcome {
        ClassSourceOutcome::Recovered { .. }
            if projection.map_or(record.markers.is_empty(), |state| state.markers.is_empty()) => {}
        ClassSourceOutcome::NoBody if record.no_body_kind.is_some() => {}
        _ => {
            return Err(refused(
                "method body or no-body declaration has no complete source proof",
            ));
        }
    }
    let mut signature = method_descriptor(
        &item.descriptor.raw().0,
        is_static(item.access_flags),
        item.access_flags & ACC_VARARGS != 0,
    )
    .ok_or_else(|| refused("physical method descriptor cannot be spelled"))?;
    if signature.parameters.len() != parsed.parameters.len() {
        return Err(refused("generic and physical parameter positions differ"));
    }
    let source_type_path = match candidate.map(|candidate| &candidate.value) {
        Some(GenericReturnValue::MemberCreation { target, .. }) => {
            Some(target.source_type_path.as_slice())
        }
        Some(GenericReturnValue::StaticMemberCreation { target, .. }) => {
            Some(target.source_type_path.as_slice())
        }
        _ => None,
    };
    let mut parameter_types = Vec::with_capacity(parsed.parameters.len());
    for parameter in &parsed.parameters {
        parameter_types.push(spell_ordinary_signature_type_with_member_path(
            parameter,
            class_scope,
            source_type_path.unwrap_or(&[]),
            budget,
            0,
        )?);
    }
    let result = parsed
        .result
        .as_ref()
        .map(|result| {
            spell_ordinary_signature_type_with_member_path(
                result,
                class_scope,
                source_type_path.unwrap_or(&[]),
                budget,
                0,
            )
        })
        .transpose()?;
    let mut generic_throws = Vec::with_capacity(parsed.throws.len());
    for exception in &parsed.throws {
        budget.poll()?;
        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
        match exception {
            SignatureType::Class(class) => {
                let [segment] = class.segments.as_slice() else {
                    return Err(refused(
                        "nested throws type has no preserved source position",
                    ));
                };
                if !segment.arguments.is_empty() {
                    return Err(refused(
                        "parameterized throws type has no preserved source position",
                    ));
                }
                generic_throws.push(simple_generic_class_name(&segment.binary_name)?);
            }
            SignatureType::TypeVariable(variable) => {
                match &record.outcome {
                    ClassSourceOutcome::NoBody => {}
                    ClassSourceOutcome::Recovered { .. } => prove_body_generic_throws_shape(
                        record,
                        parsed,
                        candidate,
                        class_internal,
                        class_flags,
                        class_superclass,
                        class_interfaces,
                        budget,
                    )?,
                    _ => {
                        return Err(refused(
                            "generic throws variable has no complete body or no-body proof",
                        ));
                    }
                }
                let Some(class_variable) = class_scope.iter().find(|item| item.name == *variable)
                else {
                    return Err(refused(
                        "generic throws variable is not present in the emitted class header",
                    ));
                };
                if !matches!(
                    class_variable.descriptor.as_slice(),
                    b"Ljava/lang/Throwable;"
                        | b"Ljava/lang/Exception;"
                        | b"Ljava/lang/RuntimeException;"
                        | b"Ljava/lang/Error;"
                ) {
                    return Err(refused(
                        "generic throws variable first bound is not a proved JDK throwable root",
                    ));
                }
                let name = std::str::from_utf8(variable)
                    .map_err(|_| refused("generic throws variable name is not source UTF-8"))?;
                if !is_java_identifier(name) {
                    return Err(refused(
                        "generic throws variable has no Java source spelling",
                    ));
                }
                generic_throws.push(name.to_owned());
            }
            _ => {
                return Err(refused(
                    "generic throws type has no preserved Java source spelling",
                ));
            }
        }
    }
    let throws = if parsed.throws.is_empty() {
        attributes.throws.clone()
    } else {
        generic_throws
    };
    if let ClassSourceOutcome::Recovered { .. } = &record.outcome {
        let returned = if let Some(proof) = projection
            .and_then(|state| state.same_class_generic_body_proof.as_ref())
            .or(record.same_class_generic_body_proof.as_ref())
        {
            if proof.method != item.identity
                || proof.formal_names.len() != signature.parameters.len()
                || (parsed.result.is_some() && proof.return_sources.is_empty())
                || (proof.constructor_call_bci.is_some() != (item.identity.name.0 == b"<init>"))
                || proof
                    .field_write_sites
                    .iter()
                    .collect::<std::collections::HashSet<_>>()
                    .len()
                    != proof.field_write_sites.len()
            {
                return Err(refused(
                    "same-run generic body proof has different method formals",
                ));
            }
            for ((_, slot), (proof_slot, proof_name)) in
                signature.parameters.iter().zip(&proof.formal_names)
            {
                if slot != proof_slot || !is_java_identifier(proof_name) {
                    return Err(refused(
                        "same-run generic body proof has different formal identity",
                    ));
                }
            }
            let mut returned_positions = Vec::new();
            for source in &proof.return_sources {
                if let SameClassGenericBodyReturnSource::Parameter { slot } = source {
                    let Some(position) = signature.parameters.iter().position(|(_, at)| at == slot)
                    else {
                        return Err(refused("generic return source is not a physical formal"));
                    };
                    if parsed.result.as_ref() != Some(&parsed.parameters[position]) {
                        return Err(refused(
                            "generic return formal differs from the Signature result",
                        ));
                    }
                    returned_positions.push(position);
                }
            }
            Some(returned_positions)
        } else {
            let candidate = candidate.ok_or_else(|| {
                refused("same-run Program/SSA cannot prove the body under parameterized types")
            })?;
            if candidate.parameters.len() != signature.parameters.len() {
                return Err(refused("same-run parameter count differs from descriptor"));
            }
            for ((_, slot), (candidate_slot, name)) in
                signature.parameters.iter().zip(&candidate.parameters)
            {
                budget.poll()?;
                budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
                if slot != candidate_slot || !is_java_identifier(name) {
                    return Err(refused(
                        "same-run parameter slot or source name is unproved",
                    ));
                }
            }
            let void_body_parameters_proved = if let GenericReturnValue::VoidBody {
                unread_parameter_slots,
            } = &candidate.value
            {
                budget.charge(
                    CountedBudgetDimension::AnalysisSteps,
                    u64::try_from(
                        parsed
                            .parameters
                            .len()
                            .saturating_add(unread_parameter_slots.len()),
                    )
                    .unwrap_or(u64::MAX),
                )?;
                let mut proved = unread_parameter_slots
                    .windows(2)
                    .all(|slots| slots[0] < slots[1]);
                for slot in unread_parameter_slots {
                    budget.poll()?;
                    proved &= signature
                        .parameters
                        .binary_search_by_key(slot, |(_, physical_slot)| *physical_slot)
                        .is_ok();
                }
                for (position, parameter) in parsed.parameters.iter().enumerate() {
                    budget.poll()?;
                    let physical = signature.parameters.get(position);
                    let preserved = physical.is_some_and(|(physical_type, slot)| {
                        matches!(parameter, SignatureType::TypeVariable(_))
                            || parameter_types.get(position) == Some(physical_type)
                            || unread_parameter_slots.binary_search(slot).is_ok()
                    });
                    proved &= preserved;
                }
                proved
            } else {
                false
            };
            match &candidate.value {
                GenericReturnValue::EmptyVoid
                    if parsed.result.is_none()
                        && matches!(parsed.throws.as_slice(), [SignatureType::TypeVariable(_)]) =>
                {
                    Some(Vec::new())
                }
                GenericReturnValue::EmptyVoid if empty_void_wildcard_parameter => Some(Vec::new()),
                GenericReturnValue::EmptyVoid => None,
                // A complete straight-line void body whose parameters are only read keeps compiling
                // when a class-scope variable replaces the erased parameter spelling: the reader
                // proved the variable's erasure is that parameter, so every read stays assignable to
                // the context that accepted the erased reference. The same-run candidate refused any
                // reassignment of the parameter locals, which is the write side this proof refuses.
                GenericReturnValue::VoidBody {
                    unread_parameter_slots,
                } if parsed.result.is_none()
                    && parsed.throws.is_empty()
                    && void_body_parameters_proved =>
                {
                    Some(Vec::new())
                }
                GenericReturnValue::VoidBody { .. } => None,
                GenericReturnValue::NullLiteral if allow_null_return => Some(Vec::new()),
                GenericReturnValue::NullLiteral => None,
                GenericReturnValue::Parameter(slot) => signature
                    .parameters
                    .iter()
                    .position(|(_, at)| *at == *slot)
                    .map(|position| vec![position]),
                GenericReturnValue::Conditional {
                    test,
                    when_true,
                    when_false,
                } => {
                    let test_position =
                        signature.parameters.iter().position(|(_, at)| *at == *test);
                    let true_position = signature
                        .parameters
                        .iter()
                        .position(|(_, at)| *at == *when_true);
                    let false_position = signature
                        .parameters
                        .iter()
                        .position(|(_, at)| *at == *when_false);
                    match (test_position, true_position, false_position) {
                        (Some(test_position), Some(true_position), Some(false_position))
                            if parsed.parameters[test_position] == SignatureType::Base(b'Z') =>
                        {
                            Some(vec![true_position, false_position])
                        }
                        _ => None,
                    }
                }
                GenericReturnValue::MemberCreation {
                    target,
                    qualifier_slot,
                } => {
                    let qualifier_position = signature
                        .parameters
                        .iter()
                        .position(|(_, slot)| *slot == *qualifier_slot);
                    qualifier_position
                        .is_some_and(|position| {
                            let parameter_matches =
                                parsed.parameters.get(position).is_some_and(|ty| {
                                    member_signature_class_matches(
                                        ty,
                                        &target.outer,
                                        &target.source_type_path,
                                        false,
                                    )
                                });
                            parameter_matches
                                && parsed.result.as_ref().is_some_and(|ty| {
                                    signature_result_matches_member_creation(ty, target)
                                })
                        })
                        .then_some(Vec::new())
                }
                GenericReturnValue::StaticMemberCreation { target, .. } => parsed
                    .result
                    .as_ref()
                    .is_some_and(|ty| {
                        member_signature_class_matches(
                            ty,
                            &target.owner,
                            &target.source_type_path,
                            false,
                        )
                    })
                    .then_some(Vec::new()),
                GenericReturnValue::TypedFunctional { target } => {
                    let expected = match target.kind {
                        TypedFunctionalKind::FunctionStringInteger => {
                            "java.util.function.Function<java.lang.String, java.lang.Integer>"
                        }
                        TypedFunctionalKind::SupplierString => {
                            "java.util.function.Supplier<java.lang.String>"
                        }
                    };
                    (parsed.parameters.is_empty() && result.as_deref() == Some(expected))
                        .then_some(Vec::new())
                }
            }
        }
        .ok_or_else(|| {
            refused("return source is not a proven parameter value or selected member creation")
        })?;
        if projection
            .and_then(|state| state.same_class_generic_body_proof.as_ref())
            .or(record.same_class_generic_body_proof.as_ref())
            .is_none()
        {
            let Some(candidate) = candidate else {
                return Err(refused("generic return candidate is missing"));
            };
            if !matches!(
                candidate.value,
                GenericReturnValue::MemberCreation { .. }
                    | GenericReturnValue::StaticMemberCreation { .. }
                    | GenericReturnValue::TypedFunctional { .. }
            ) && returned
                .iter()
                .any(|position| parsed.result.as_ref() != Some(&parsed.parameters[*position]))
            {
                return Err(refused(
                    "returned parameter has a different generic source type",
                ));
            }
        }
    }
    for ((spelling, _), ty) in signature.parameters.iter_mut().zip(parameter_types) {
        *spelling = ty;
    }
    signature.returns = result;
    let (name, aliased) = written_name(&item.name.raw().0);
    if aliased || !is_java_identifier(&name) {
        return Err(refused("method name has no faithful Java spelling"));
    }
    let mut words = Vec::new();
    words.extend(visibility(item.access_flags));
    if is_static(item.access_flags) {
        words.push("static");
    }
    if item.access_flags & ACC_FINAL != 0 {
        words.push("final");
    }
    if item.access_flags & ACC_ABSTRACT != 0 {
        words.push("abstract");
    }
    if item.access_flags & ACC_NATIVE != 0 {
        words.push("native");
    }
    if item.access_flags & ACC_SYNCHRONIZED != 0 {
        words.push("synchronized");
    }
    if item.access_flags & ACC_STRICT != 0 {
        words.push("strictfp");
    }
    if is_default_member(class_flags, item) {
        words.push("default");
    }
    let names = projection
        .and_then(|state| state.same_class_generic_body_proof.as_ref())
        .or(record.same_class_generic_body_proof.as_ref())
        .map(|proof| proof.formal_names.as_slice())
        .or_else(|| candidate.map(|candidate| candidate.parameters.as_slice()));
    let mut arguments = Vec::new();
    for (position, (ty, slot)) in signature.parameters.iter().enumerate() {
        let name = names
            .and_then(|names| names.get(position).map(|(_, name)| name.clone()))
            .unwrap_or_else(|| format!("arg{slot}"));
        let varargs = signature.varargs && position + 1 == signature.parameters.len();
        let annotations = record
            .parameter_annotations
            .uses_by_position
            .get(position)
            .into_iter()
            .flatten()
            .map(|annotation| format!("{annotation} "))
            .collect::<String>();
        arguments.push(format!("{annotations}{} {name}", varargs_type(ty, varargs)));
    }
    Ok(format!(
        "{}{} {}({}){}",
        if words.is_empty() {
            String::new()
        } else {
            format!("{} ", words.join(" "))
        },
        signature.returns.as_deref().unwrap_or("void"),
        name,
        arguments.join(", "),
        throws_clause(&throws),
    ))
}

/// The first narrow empty-body parameter projection: one static `List` wildcard whose bound has
/// an existing simple source spelling. The body candidate is produced from the same complete
/// Code/AST/SSA run and carries every physical parameter slot.
fn ordinary_empty_void_wildcard_parameter_is_proved(
    record: &ClassSourceMethod,
    attributes: &MemberAttributes,
    parsed: &jarde_reader::signature::MethodSignature,
    candidate: Option<&GenericReturnCandidate>,
    class_flags: u16,
    class_internal: &[u8],
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
) -> bool {
    let item = &record.item;
    candidate.is_some_and(|candidate| matches!(&candidate.value, GenericReturnValue::EmptyVoid))
        && is_static(item.access_flags)
        && item.access_flags & !(ACC_PUBLIC | ACC_PRIVATE | ACC_PROTECTED | ACC_STATIC) == 0
        && attributes.throws_raw.is_empty()
        && parsed.result.is_none()
        && parsed.throws.is_empty()
        && record.annotations.attributes.is_empty()
        && record.annotations.refusals.is_empty()
        && record.parameter_annotations.attributes.is_empty()
        && record.parameter_annotations.refusals.is_empty()
        && record.type_annotations.attributes.is_empty()
        && record.type_annotations.refusals.is_empty()
        && !class_internal.contains(&b'$')
        && class_flags & (ACC_INTERFACE | ACC_ENUM | ACC_ANNOTATION) == 0
        && class_superclass == Some(b"java/lang/Object".as_slice())
        && class_interfaces.is_empty()
        && matches!(parsed.parameters.as_slice(), [SignatureType::Class(class)]
            if matches!(class.segments.as_slice(), [segment]
                if segment.binary_name == b"java/util/List"
                    && matches!(segment.arguments.as_slice(), [argument]
                        if ordinary_simple_wildcard_argument(argument))))
}

fn ordinary_simple_wildcard_argument(argument: &TypeArgument) -> bool {
    let simple_class = |ty: &SignatureType| {
        matches!(ty, SignatureType::Class(class)
            if matches!(class.segments.as_slice(), [segment]
                if segment.arguments.is_empty()
                    && simple_generic_class_name(&segment.binary_name).is_ok()))
    };
    let primitive_array = |ty: &SignatureType| {
        matches!(ty, SignatureType::Array(element)
            if matches!(element.as_ref(), SignatureType::Base(b'B' | b'C' | b'D' | b'F' | b'I' | b'J' | b'S' | b'Z')))
    };
    match argument {
        TypeArgument::Any => true,
        TypeArgument::Extends(ty) | TypeArgument::Super(ty) => {
            simple_class(ty) || primitive_array(ty)
        }
        TypeArgument::Exact(_) => false,
    }
}

fn spell_ordinary_signature_type(
    ty: &SignatureType,
    class_scope: &[TypeParameterErasure],
    budget: &mut Budget,
    depth: usize,
) -> Result<String> {
    spell_ordinary_signature_type_with_member_path(ty, class_scope, &[], budget, depth)
}

/// The class-header spelling of one `Signature` type — the `extends`/`implements` entries
/// [`ClassSourceDeclaration::project_generic_signature`] publishes. It is the same recursion as
/// the member and annotation positions, with one difference: a single-segment class name is
/// spelled by [`binary_pool_class_name`], the class file's own name with `$` kept, because that
/// is the name the raw header already states for every parent no `Signature` projects. A
/// projected entry therefore adds its type arguments and changes no name.
fn spell_class_header_signature_type(
    ty: &SignatureType,
    class_scope: &[TypeParameterErasure],
    budget: &mut Budget,
    depth: usize,
) -> Result<String> {
    spell_signature_type_with_spelling(
        ty,
        class_scope,
        &[],
        ClassNameSpelling::BinaryPoolName,
        budget,
        depth,
    )
}

/// How one class type's binary name becomes text.
#[derive(Clone, Copy, Eq, PartialEq)]
enum ClassNameSpelling {
    /// A member, annotation, `throws` or type-parameter position: a single-segment name is
    /// spelled only when a member proof selected its source path
    /// ([`simple_generic_class_name`]), so a `$` name without that proof has no spelling here.
    SelectedSourcePath,
    /// The class header's own `extends`/`implements` entries ([`binary_pool_class_name`]).
    BinaryPoolName,
}

fn spell_ordinary_signature_type_with_member_path(
    ty: &SignatureType,
    class_scope: &[TypeParameterErasure],
    source_type_path: &[jarde_java::report::ProvedMemberInnerSourceSegment],
    budget: &mut Budget,
    depth: usize,
) -> Result<String> {
    spell_signature_type_with_spelling(
        ty,
        class_scope,
        source_type_path,
        ClassNameSpelling::SelectedSourcePath,
        budget,
        depth,
    )
}

fn spell_signature_type_with_spelling(
    ty: &SignatureType,
    class_scope: &[TypeParameterErasure],
    source_type_path: &[jarde_java::report::ProvedMemberInnerSourceSegment],
    class_names: ClassNameSpelling,
    budget: &mut Budget,
    depth: usize,
) -> Result<String> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    if depth > 128 {
        return Err(Error::unsupported(
            "ordinary_generic_source_unproved",
            "type nesting exceeds source projection depth",
        ));
    }
    let nested = depth + 1;
    match ty {
        SignatureType::Base(code) => Ok(match code {
            b'B' => "byte",
            b'C' => "char",
            b'D' => "double",
            b'F' => "float",
            b'I' => "int",
            b'J' => "long",
            b'S' => "short",
            b'Z' => "boolean",
            _ => {
                return Err(Error::unsupported(
                    "ordinary_generic_source_unproved",
                    "unknown primitive signature type",
                ));
            }
        }
        .to_owned()),
        SignatureType::Array(element) => Ok(format!(
            "{}[]",
            spell_signature_type_with_spelling(
                element,
                class_scope,
                source_type_path,
                class_names,
                budget,
                nested,
            )?
        )),
        SignatureType::TypeVariable(name) => class_scope
            .iter()
            .find(|variable| variable.name == *name)
            .and_then(|variable| std::str::from_utf8(&variable.name).ok())
            .filter(|name| is_java_identifier(name))
            .map(str::to_owned)
            .ok_or_else(|| {
                Error::unsupported(
                    "ordinary_generic_source_unproved",
                    "type variable is not present in the emitted class header",
                )
            }),
        SignatureType::Class(class) => {
            if class.segments.is_empty() {
                return Err(Error::unsupported(
                    "ordinary_generic_source_unproved",
                    "nested binary class path has no unique Java source spelling",
                ));
            }
            let mut result = String::new();
            let mut previous_mapping: Option<&jarde_java::report::ProvedMemberInnerSourceSegment> =
                None;
            for segment in &class.segments {
                budget.poll()?;
                let mapping = unique_member_source_segment(source_type_path, &segment.binary_name)?;
                if let Some(mapping) = mapping {
                    if !segment.arguments.is_empty()
                        && segment.arguments.len() != mapping.type_parameter_count
                    {
                        return Err(Error::unsupported(
                            "ordinary_generic_source_unproved",
                            "selected member type has a different number of source arguments",
                        ));
                    }
                    if mapping.is_static || mapping.enclosing_binary_name.is_none() {
                        result = mapping.source_name.clone();
                    } else {
                        let previous = previous_mapping.ok_or_else(|| {
                            Error::unsupported(
                                "ordinary_generic_source_unproved",
                                "non-static member type has no explicit enclosing Signature segment",
                            )
                        })?;
                        if mapping.enclosing_binary_name.as_deref()
                            != Some(previous.binary_name.as_str())
                            || !segment_is_immediate_source_child(
                                &mapping.source_name,
                                &previous.source_name,
                            )
                        {
                            return Err(Error::unsupported(
                                "ordinary_generic_source_unproved",
                                "selected non-static member does not follow the Signature's enclosing segment",
                            ));
                        }
                        let suffix = mapping
                            .source_name
                            .strip_prefix(&previous.source_name)
                            .and_then(|suffix| suffix.strip_prefix('.'))
                            .ok_or_else(|| {
                                Error::unsupported(
                                    "ordinary_generic_source_unproved",
                                    "selected member source path is inconsistent",
                                )
                            })?;
                        if !is_java_identifier(suffix) {
                            return Err(Error::unsupported(
                                "ordinary_generic_source_unproved",
                                "selected member source segment is not a Java identifier",
                            ));
                        }
                        result.push('.');
                        result.push_str(suffix);
                    }
                    previous_mapping = Some(mapping);
                } else {
                    if class.segments.len() != 1 {
                        return Err(Error::unsupported(
                            "ordinary_generic_source_unproved",
                            "nested binary class path has no selected Java source spelling",
                        ));
                    }
                    result = match class_names {
                        ClassNameSpelling::SelectedSourcePath => {
                            simple_generic_class_name(&segment.binary_name)?
                        }
                        ClassNameSpelling::BinaryPoolName => {
                            binary_pool_class_name(&segment.binary_name)?
                        }
                    };
                    previous_mapping = None;
                }
                if !segment.arguments.is_empty() {
                    let mut arguments = Vec::with_capacity(segment.arguments.len());
                    for argument in &segment.arguments {
                        budget.poll()?;
                        budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
                        let spelling = match argument {
                            TypeArgument::Any => "?".to_owned(),
                            TypeArgument::Exact(ty) => spell_signature_type_with_spelling(
                                ty,
                                class_scope,
                                source_type_path,
                                class_names,
                                budget,
                                nested,
                            )?,
                            TypeArgument::Extends(ty) => format!(
                                "? extends {}",
                                spell_signature_type_with_spelling(
                                    ty,
                                    class_scope,
                                    source_type_path,
                                    class_names,
                                    budget,
                                    nested,
                                )?
                            ),
                            TypeArgument::Super(ty) => format!(
                                "? super {}",
                                spell_signature_type_with_spelling(
                                    ty,
                                    class_scope,
                                    source_type_path,
                                    class_names,
                                    budget,
                                    nested,
                                )?
                            ),
                        };
                        arguments.push(spelling);
                    }
                    result.push('<');
                    result.push_str(&arguments.join(", "));
                    result.push('>');
                }
            }
            Ok(result)
        }
    }
}

fn unique_member_source_segment<'a>(
    source_type_path: &'a [jarde_java::report::ProvedMemberInnerSourceSegment],
    binary_name: &[u8],
) -> Result<Option<&'a jarde_java::report::ProvedMemberInnerSourceSegment>> {
    let mut found: Option<&jarde_java::report::ProvedMemberInnerSourceSegment> = None;
    for segment in source_type_path {
        if segment.binary_name.as_bytes() != binary_name {
            continue;
        }
        if found.is_some_and(|previous| previous != segment) {
            return Err(Error::unsupported(
                "ordinary_generic_source_unproved",
                "selected member source path is ambiguous",
            ));
        }
        found = Some(segment);
    }
    Ok(found)
}

fn segment_is_immediate_source_child(child: &str, parent: &str) -> bool {
    child
        .strip_prefix(parent)
        .and_then(|suffix| suffix.strip_prefix('.'))
        .is_some_and(is_java_identifier)
}

fn member_signature_class_matches(
    ty: &SignatureType,
    expected_binary_name: &str,
    source_type_path: &[jarde_java::report::ProvedMemberInnerSourceSegment],
    require_all_source_segments: bool,
) -> bool {
    let SignatureType::Class(class) = ty else {
        return false;
    };
    let Some(expected) = source_type_path
        .iter()
        .find(|segment| segment.binary_name == expected_binary_name)
    else {
        return false;
    };
    if class
        .segments
        .last()
        .is_none_or(|segment| segment.binary_name.as_slice() != expected_binary_name.as_bytes())
        || (require_all_source_segments && class.segments.len() != 2)
    {
        return false;
    }
    if expected.type_parameter_count > 0
        && !class.segments.last().is_some_and(|segment| {
            segment.arguments.is_empty() || segment.arguments.len() == expected.type_parameter_count
        })
    {
        return false;
    }
    true
}

fn signature_result_matches_member_creation(
    ty: &SignatureType,
    target: &jarde_java::report::ProvedMemberInnerTarget,
) -> bool {
    if matches!(
        ty,
        SignatureType::Class(class)
            if class.segments.len() == 1
                && class.segments[0].binary_name.as_slice() == b"java/lang/Object"
                && class.segments[0].arguments.is_empty()
    ) {
        return true;
    }
    let SignatureType::Class(class) = ty else {
        return false;
    };
    let Some(outer) = target
        .source_type_path
        .iter()
        .find(|segment| segment.binary_name == target.outer)
    else {
        return false;
    };
    let Some(member) = target
        .source_type_path
        .iter()
        .find(|segment| segment.binary_name == target.owner)
    else {
        return false;
    };
    class.segments.len() == 2
        && class.segments[0].binary_name.as_slice() == outer.binary_name.as_bytes()
        && class.segments[1].binary_name.as_slice() == member.binary_name.as_bytes()
        && class.segments[0].arguments.len() == outer.type_parameter_count
        && class.segments[1].arguments.len() == member.type_parameter_count
        && !class.segments[0].arguments.is_empty()
}

fn generic_void_body_declaration(
    record: &ClassSourceMethod,
    projection: &GenericCallProjectionState,
    attributes: &MemberAttributes,
    parsed: &jarde_reader::signature::MethodSignature,
    candidate: Option<&GenericReturnCandidate>,
    erasures: &[TypeParameterErasure],
    class_internal: &[u8],
    resolved_inner_classes: &[ResolvedInnerClass],
    budget: &mut Budget,
) -> Result<String> {
    let refused = |why| Error::unsupported("generic_source_shape_unproved", why);
    let [parameter] = parsed.type_parameters.as_slice() else {
        return Err(refused(
            "generic void body requires exactly one method type parameter",
        ));
    };
    let Some(SignatureType::Class(bound)) = parameter.class_bound.as_ref() else {
        return Err(refused("generic void body requires one class bound"));
    };
    let Some(physical) = method_descriptor(&record.item.descriptor.raw().0, false, false) else {
        return Err(refused(
            "physical generic void descriptor cannot be spelled",
        ));
    };
    if !parameter.interface_bounds.is_empty()
        || bound.segments.len() != 1
        || !bound.segments[0].arguments.is_empty()
        || erasures.len() != 1
        || erasures[0].name != parameter.name
        || !erasures[0].descriptor.starts_with(b"L")
        || parsed.parameters.as_slice()
            != [
                SignatureType::TypeVariable(parameter.name.clone()),
                SignatureType::Base(b'Z'),
            ]
        || physical.parameters.len() != 2
        || physical.parameters[1].0 != "boolean"
        || physical.parameters[0].0 == "boolean"
        || !attributes.throws_raw.is_empty()
        || !matches!(candidate, Some(GenericReturnCandidate {
            parameters,
            value: GenericReturnValue::VoidBody {
                unread_parameter_slots: _,
            },
        }) if parameters.len() == 2)
    {
        return Err(refused(
            "generic void body must be `<T extends B> void` with physical `(B, boolean)`, exact erasure, and two same-run parameter slots",
        ));
    }
    let bound_name = if bound.segments[0].binary_name.contains(&b'$') {
        let expected_erasure = [
            b"L".as_slice(),
            bound.segments[0].binary_name.as_slice(),
            b";",
        ]
        .concat();
        if erasures[0].descriptor != expected_erasure {
            return Err(refused(
                "nested bound does not match the proved physical parameter erasure",
            ));
        }
        selected_nested_sibling_bound_spelling(
            class_internal,
            &bound.segments[0].binary_name,
            &physical.parameters[0].0,
            resolved_inner_classes,
        )?
    } else {
        simple_generic_class_name(&bound.segments[0].binary_name)?
    };
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    generic_method_declaration(
        record,
        projection,
        attributes,
        parsed,
        candidate,
        false,
        Some(&bound_name),
    )
}

/// A `$` class name is source-spellable here only because the already selected physical method
/// descriptor supplied that exact spelling and the selected class plus the bound prove direct
/// siblings in one named source family. This deliberately does not canonicalize `$` to `.`.
fn selected_nested_sibling_bound_spelling(
    class_internal: &[u8],
    bound_internal: &[u8],
    physical_parameter_spelling: &str,
    resolved_inner_classes: &[ResolvedInnerClass],
) -> Result<String> {
    let refused = || {
        Error::unsupported(
            "generic_source_shape_unproved",
            "nested bound lacks an unambiguous spelling in the selected class family",
        )
    };
    let unique = |internal: &[u8]| {
        let mut matches = resolved_inner_classes
            .iter()
            .filter(|entry| entry.class == internal);
        let entry = matches.next()?;
        matches.next().is_none().then_some(entry)
    };
    let class = unique(class_internal).ok_or_else(refused)?;
    let bound = unique(bound_internal).ok_or_else(refused)?;
    let (Some(outer), Some(class_name), Some(bound_name)) = (
        class.outer_class.as_deref(),
        class.inner_name.as_ref().map(|name| name.0.as_slice()),
        bound.inner_name.as_ref().map(|name| name.0.as_slice()),
    ) else {
        return Err(refused());
    };
    let class_binary = [outer, b"$", class_name].concat();
    let bound_binary = [outer, b"$", bound_name].concat();
    let outer_source = std::str::from_utf8(outer).map_err(|_| refused())?;
    let class_source = std::str::from_utf8(class_name).map_err(|_| refused())?;
    let inner_source = std::str::from_utf8(bound_name).map_err(|_| refused())?;
    if !outer_source.split('/').all(is_java_identifier)
        || !is_java_identifier(class_source)
        || !is_java_identifier(inner_source)
    {
        return Err(refused());
    }
    let expected_source_name = format!("{}${inner_source}", outer_source.replace('/', "."));
    if class_binary != class_internal
        || bound_binary != bound_internal
        || outer != bound.outer_class.as_deref().unwrap_or_default()
        || physical_parameter_spelling != expected_source_name
    {
        return Err(refused());
    }
    Ok(physical_parameter_spelling.to_owned())
}

fn spell_generic_body_signature_type(
    ty: &jarde_reader::signature::SignatureType,
    method_variables: &[(Vec<u8>, String, String)],
    class_scope: &[TypeParameterErasure],
    budget: &mut Budget,
    depth: usize,
) -> Result<String> {
    use jarde_reader::signature::SignatureType;

    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    if depth > 128 {
        return Err(Error::unsupported(
            "generic_source_shape_unproved",
            "generic method type nesting exceeds source projection depth",
        ));
    }
    match ty {
        SignatureType::TypeVariable(name) => method_variables
            .iter()
            .find(|(candidate, _, _)| candidate == name)
            .map(|(_, spelling, _)| spelling.clone())
            .or_else(|| {
                class_scope
                    .iter()
                    .find(|candidate| candidate.name == *name)
                    .and_then(|candidate| std::str::from_utf8(&candidate.name).ok())
                    .filter(|name| is_java_identifier(name))
                    .map(str::to_owned)
            })
            .ok_or_else(|| {
                Error::unsupported(
                    "generic_source_shape_unproved",
                    "type variable is outside the emitted method and class scopes",
                )
            }),
        SignatureType::Array(element) => Ok(format!(
            "{}[]",
            spell_generic_body_signature_type(
                element,
                method_variables,
                class_scope,
                budget,
                depth + 1,
            )?
        )),
        _ => spell_ordinary_signature_type(ty, class_scope, budget, depth),
    }
}

fn generic_method_body_declaration(
    record: &ClassSourceMethod,
    projection: &GenericCallProjectionState,
    attributes: &MemberAttributes,
    parsed: &jarde_reader::signature::MethodSignature,
    proof: &SameClassGenericMethodBodyProof,
    class_scope: &[TypeParameterErasure],
    budget: &mut Budget,
) -> Result<String> {
    use jarde_reader::signature::SignatureType;

    let refused = |why| Error::unsupported("generic_source_shape_unproved", why);
    let item = &record.item;
    let is_static = item.access_flags & ACC_STATIC != 0;
    if proof.method != item.identity
        || item.name.raw().0 == b"<init>"
        || item.access_flags
            & !(ACC_PUBLIC
                | ACC_PRIVATE
                | ACC_PROTECTED
                | ACC_STATIC
                | ACC_FINAL
                | ACC_SYNCHRONIZED
                | ACC_STRICT)
            != 0
        || !record.annotations.attributes.is_empty()
        || !record.parameter_annotations.attributes.is_empty()
        || !record.type_annotations.attributes.is_empty()
        || !projection.markers.is_empty()
    {
        return Err(refused(
            "body certificate does not match a preservable generic method declaration",
        ));
    }
    if parsed.type_parameters.is_empty() {
        return Err(refused("method has no local type parameters"));
    }
    let formal_count = proof.formal_names.len();
    let signature_type_count = parsed
        .parameters
        .len()
        .saturating_add(usize::from(parsed.result.is_some()))
        .saturating_add(parsed.throws.len());
    let bound_count = parsed
        .type_parameters
        .iter()
        .map(|parameter| {
            parameter
                .class_bound
                .iter()
                .count()
                .saturating_add(parameter.interface_bounds.len())
        })
        .fold(0usize, usize::saturating_add);
    let proof_work = formal_count
        .saturating_mul(formal_count)
        .saturating_add(signature_type_count.saturating_mul(parsed.type_parameters.len()))
        .saturating_add(formal_count)
        .saturating_add(proof.return_sources.len())
        .saturating_add(bound_count)
        .saturating_add(parsed.type_parameters.len())
        .saturating_add(parsed.throws.len());
    budget.charge(
        CountedBudgetDimension::AnalysisSteps,
        u64::try_from(proof_work).unwrap_or(u64::MAX),
    )?;
    let mut variables = Vec::with_capacity(parsed.type_parameters.len());
    for parameter in &parsed.type_parameters {
        budget.poll()?;
        let variable = std::str::from_utf8(&parameter.name)
            .map_err(|_| refused("type variable name is not source UTF-8"))?;
        if !is_java_identifier(variable) {
            return Err(refused("type variable has no Java source spelling"));
        }
        let mut bounds = Vec::new();
        for bound in parameter
            .class_bound
            .iter()
            .chain(parameter.interface_bounds.iter())
        {
            budget.poll()?;
            let SignatureType::Class(class) = bound else {
                return Err(refused("type-variable bound is unsupported"));
            };
            let [segment] = class.segments.as_slice() else {
                return Err(refused("nested bounds are unsupported"));
            };
            if !segment.arguments.is_empty() {
                return Err(refused("parameterized bounds are unsupported"));
            }
            bounds.push(simple_generic_class_name(&segment.binary_name)?);
        }
        if bounds.is_empty() {
            bounds.push("java.lang.Object".to_owned());
        }
        variables.push((
            parameter.name.clone(),
            variable.to_owned(),
            bounds.join(" & "),
        ));
    }

    let signature = method_descriptor(&item.descriptor.raw().0, is_static, false)
        .ok_or_else(|| refused("physical descriptor cannot be spelled"))?;
    let Some(slots) = jarde_jvm::method_ir::parameter_positions(
        &descriptor_facts(&item.descriptor.raw().0, DescriptorKind::Method)?,
        is_static,
    ) else {
        return Err(refused("physical parameter slots are unavailable"));
    };
    if slots.len() != parsed.parameters.len()
        || proof.formal_names.len() != slots.len()
        || signature.parameters.len() != slots.len()
        || proof
            .formal_names
            .iter()
            .map(|(slot, _)| *slot)
            .collect::<std::collections::BTreeSet<_>>()
            .len()
            != slots.len()
    {
        return Err(refused(
            "body formal identities do not match physical parameters",
        ));
    }
    let mut arguments = Vec::with_capacity(slots.len());
    let mut parameter_types = Vec::with_capacity(slots.len());
    for (position, slot) in slots.iter().enumerate() {
        budget.poll()?;
        let Some((_, name)) = proof
            .formal_names
            .iter()
            .find(|(formal_slot, _)| formal_slot == slot)
        else {
            return Err(refused("body certificate omits a physical formal"));
        };
        if !is_java_identifier(name) {
            return Err(refused("formal name has no Java source spelling"));
        }
        let ty = spell_generic_body_signature_type(
            &parsed.parameters[position],
            &variables,
            class_scope,
            budget,
            0,
        )?;
        parameter_types.push(parsed.parameters[position].clone());
        arguments.push(format!("{ty} {name}"));
    }
    let result_name = match parsed.result.as_ref() {
        None => {
            if !proof.return_sources.is_empty() {
                return Err(refused("void method body has value-return sources"));
            }
            "void".to_owned()
        }
        Some(result) => {
            if proof.return_sources.is_empty() {
                return Err(refused(
                    "value-returning method has no certified return source",
                ));
            }
            for source in &proof.return_sources {
                budget.poll()?;
                match source {
                    SameClassGenericBodyReturnSource::Parameter { slot } => {
                        let Some(position) = slots.iter().position(|formal| formal == slot) else {
                            return Err(refused(
                                "return source is outside the physical formal slots",
                            ));
                        };
                        if parameter_types.get(position) != Some(result) {
                            return Err(refused(
                                "return source formal does not have the Signature result type",
                            ));
                        }
                    }
                    SameClassGenericBodyReturnSource::Call { .. } => {}
                }
            }
            spell_generic_body_signature_type(result, &variables, class_scope, budget, 0)?
        }
    };
    let throws = parsed
        .throws
        .iter()
        .map(|exception| match exception {
            SignatureType::Class(class) => {
                budget.poll()?;
                let [segment] = class.segments.as_slice() else {
                    return Err(refused("nested throws type is unsupported"));
                };
                if !segment.arguments.is_empty() {
                    return Err(refused("parameterized throws type is unsupported"));
                }
                simple_generic_class_name(&segment.binary_name)
            }
            SignatureType::TypeVariable(_) => {
                spell_generic_body_signature_type(exception, &variables, class_scope, budget, 0)
            }
            _ => Err(refused(
                "method-local generic throws type lacks a body proof",
            )),
        })
        .collect::<Result<Vec<_>>>()?;
    if throws != attributes.throws {
        return Err(refused(
            "generic throws Signature differs from physical Exceptions",
        ));
    }
    let (name, aliased) = written_name(&item.name.raw().0);
    if aliased || !is_java_identifier(&name) {
        return Err(refused("method name has no faithful source spelling"));
    }
    let mut words = Vec::new();
    words.extend(visibility(item.access_flags));
    if is_static {
        words.push("static");
    }
    if item.access_flags & ACC_FINAL != 0 {
        words.push("final");
    }
    if item.access_flags & ACC_SYNCHRONIZED != 0 {
        words.push("synchronized");
    }
    if item.access_flags & ACC_STRICT != 0 {
        words.push("strictfp");
    }
    Ok(format!(
        "{}<{}> {} {}({}){}",
        if words.is_empty() {
            String::new()
        } else {
            format!("{} ", words.join(" "))
        },
        variables
            .iter()
            .map(|(_, name, bound)| format!("{name} extends {bound}"))
            .collect::<Vec<_>>()
            .join(", "),
        result_name,
        name,
        arguments.join(", "),
        throws_clause(&throws),
    ))
}

fn generic_method_declaration(
    record: &ClassSourceMethod,
    projection: &GenericCallProjectionState,
    attributes: &MemberAttributes,
    parsed: &jarde_reader::signature::MethodSignature,
    candidate: Option<&GenericReturnCandidate>,
    method_local_throws_proved: bool,
    first_bound_spelling: Option<&str>,
) -> Result<String> {
    let refused = |why| Error::unsupported("generic_source_shape_unproved", why);
    let candidate = candidate
        .ok_or_else(|| refused("the recovered AST/SSA body is not a direct parameter return"))?;
    let item = &record.item;
    let void_body = matches!(&candidate.value, GenericReturnValue::VoidBody { .. });
    let null_instance_return = matches!(candidate.value, GenericReturnValue::NullLiteral);
    let is_static = item.access_flags & ACC_STATIC != 0;
    if projection.declaration.is_none()
        || (void_body && is_static)
        || (!void_body && is_static == null_instance_return)
        || item.access_flags
            & !(ACC_PUBLIC
                | ACC_PRIVATE
                | ACC_PROTECTED
                | ACC_STATIC
                | ACC_FINAL
                | ACC_SYNCHRONIZED
                | ACC_STRICT)
            != 0
        || !record.annotations.attributes.is_empty()
        || !record.parameter_annotations.attributes.is_empty()
        || !record.type_annotations.attributes.is_empty()
        || !projection.markers.is_empty()
    {
        return Err(refused(
            "method flags, annotations, or existing source refusals cannot be preserved in this generic shape",
        ));
    }
    if parsed.type_parameters.is_empty() {
        return Err(refused("method has no local type parameters"));
    }
    let mut variables = Vec::new();
    for parameter in &parsed.type_parameters {
        let mut bounds = Vec::new();
        for bound in parameter
            .class_bound
            .iter()
            .chain(parameter.interface_bounds.iter())
        {
            let SignatureType::Class(bound) = bound else {
                return Err(refused("type-variable bound is unsupported"));
            };
            let [bound] = bound.segments.as_slice() else {
                return Err(refused("nested bounds are unsupported"));
            };
            if !bound.arguments.is_empty() {
                return Err(refused("parameterized bounds are unsupported"));
            }
            bounds.push(if first_bound_spelling.is_some() && variables.is_empty() {
                first_bound_spelling.expect("checked above").to_owned()
            } else {
                simple_generic_class_name(&bound.binary_name)?
            });
        }
        let variable = std::str::from_utf8(&parameter.name)
            .map_err(|_| refused("type variable name is not source UTF-8"))?;
        if !is_java_identifier(variable) {
            return Err(refused("type variable has no Java source spelling"));
        }
        if bounds.is_empty() {
            bounds.push("java.lang.Object".to_owned());
        }
        variables.push((
            parameter.name.clone(),
            variable.to_owned(),
            bounds.join(" & "),
        ));
    }
    let result_name = if void_body {
        if parsed.result.is_some() {
            return Err(refused("proved void body has a non-void Signature result"));
        }
        "void"
    } else {
        let Some(SignatureType::TypeVariable(result_variable)) = &parsed.result else {
            return Err(refused("result is outside the supported source shape"));
        };
        let Some((_, result_name, _)) = variables
            .iter()
            .find(|(name, _, _)| name == result_variable)
        else {
            return Err(refused("result variable is outside the method scope"));
        };
        result_name.as_str()
    };
    if parsed.parameters.len() != candidate.parameters.len() {
        return Err(refused("parameter count differs from the same-run body"));
    }
    for exception in &parsed.throws {
        let physical_class_throws = matches!(
            exception,
            SignatureType::Class(class)
                if class.segments.len() == 1
                    && class.segments[0].arguments.is_empty()
                    && simple_generic_class_name(&class.segments[0].binary_name).is_ok()
        );
        let proved_local_throws = method_local_throws_proved
            && matches!(exception, SignatureType::TypeVariable(variable)
                if parsed.type_parameters.iter().any(|parameter| parameter.name == *variable));
        if !physical_class_throws && !proved_local_throws {
            return Err(refused(
                "generic throws type cannot be preserved by the physical Exceptions clause",
            ));
        }
    }
    let signature = method_descriptor(&item.descriptor.raw().0, is_static, false)
        .ok_or_else(|| refused("physical descriptor cannot be spelled"))?;
    if signature.parameters.len() != candidate.parameters.len() {
        return Err(refused("parameter slot mapping differs from descriptor"));
    }
    let mut arguments = Vec::new();
    let mut result_slots = Vec::new();
    let mut bool_slots = Vec::new();
    for (position, ((ty, slot), (candidate_slot, name))) in signature
        .parameters
        .iter()
        .zip(&candidate.parameters)
        .enumerate()
    {
        if slot != candidate_slot || !is_java_identifier(name) {
            return Err(refused("same-run parameter name or slot is unproved"));
        }
        let spelling = match &parsed.parameters[position] {
            SignatureType::TypeVariable(name) => {
                let Some((_, spelling, _)) =
                    variables.iter().find(|(variable, _, _)| variable == name)
                else {
                    return Err(refused("parameter variable is outside the method scope"));
                };
                if parsed
                    .result
                    .as_ref()
                    .is_some_and(|result| matches!(result, SignatureType::TypeVariable(result) if result == name))
                {
                    result_slots.push(*slot);
                }
                spelling.clone()
            }
            SignatureType::Base(b'Z') if ty == "boolean" => {
                bool_slots.push(*slot);
                "boolean".to_owned()
            }
            SignatureType::Base(_) => ty.clone(),
            SignatureType::Class(class) => {
                let [segment] = class.segments.as_slice() else {
                    return Err(refused("nested parameter type is unsupported"));
                };
                if !segment.arguments.is_empty()
                    || simple_generic_class_name(&segment.binary_name).is_err()
                {
                    return Err(refused(
                        "parameterized or unspellable parameter type is unsupported",
                    ));
                }
                ty.clone()
            }
            _ => {
                return Err(refused(
                    "parameter uses an unsupported generic source shape",
                ));
            }
        };
        arguments.push(format!("{spelling} {name}"));
    }
    let return_proved = match candidate.value {
        GenericReturnValue::EmptyVoid => false,
        GenericReturnValue::VoidBody { .. } => void_body && parsed.result.is_none(),
        GenericReturnValue::NullLiteral => null_instance_return && parsed.parameters.is_empty(),
        GenericReturnValue::Parameter(slot) => result_slots.contains(&slot),
        GenericReturnValue::Conditional {
            test,
            when_true,
            when_false,
        } => {
            bool_slots.contains(&test)
                && result_slots.contains(&when_true)
                && result_slots.contains(&when_false)
        }
        GenericReturnValue::MemberCreation { .. } => false,
        GenericReturnValue::StaticMemberCreation { .. } => false,
        GenericReturnValue::TypedFunctional { .. } => false,
    };
    if !return_proved {
        return Err(refused(
            "return value does not come solely from parameters of the result type variable",
        ));
    }
    let (name, aliased) = written_name(&item.name.raw().0);
    if aliased || !is_java_identifier(&name) {
        return Err(refused("method name has no faithful source spelling"));
    }
    let mut words = Vec::new();
    words.extend(visibility(item.access_flags));
    if is_static {
        words.push("static");
    }
    if item.access_flags & ACC_FINAL != 0 {
        words.push("final")
    }
    if item.access_flags & ACC_SYNCHRONIZED != 0 {
        words.push("synchronized")
    }
    if item.access_flags & ACC_STRICT != 0 {
        words.push("strictfp")
    }
    let throws = if method_local_throws_proved {
        parsed
            .throws
            .iter()
            .map(|throws| match throws {
                SignatureType::TypeVariable(variable) => variables
                    .iter()
                    .find(|(name, _, _)| name == variable)
                    .map(|(_, name, _)| name.clone())
                    .ok_or_else(|| refused("throws variable has no emitted method type parameter")),
                _ => Err(refused(
                    "strict source gate admits one local throws variable",
                )),
            })
            .collect::<Result<Vec<_>>>()?
    } else {
        attributes.throws.clone()
    };
    Ok(format!(
        "{}<{}> {} {}({}){}",
        if words.is_empty() {
            String::new()
        } else {
            format!("{} ", words.join(" "))
        },
        variables
            .iter()
            .map(|(_, name, bound)| format!("{name} extends {bound}"))
            .collect::<Vec<_>>()
            .join(", "),
        result_name,
        name,
        arguments.join(", "),
        throws_clause(&throws),
    ))
}

#[allow(clippy::too_many_arguments)]
fn generic_null_instance_method_declaration(
    record: &ClassSourceMethod,
    projection: &GenericCallProjectionState,
    attributes: &MemberAttributes,
    parsed: &jarde_reader::signature::MethodSignature,
    candidate: Option<&GenericReturnCandidate>,
    class_internal: &[u8],
    class_flags: u16,
    class_superclass: Option<&[u8]>,
    class_interfaces: &[Vec<u8>],
    class_scope: &[TypeParameterErasure],
    class_signature_present: bool,
    budget: &mut Budget,
) -> Result<String> {
    let refused = |why| Error::unsupported("generic_source_shape_unproved", why);
    let item = &record.item;
    if !matches!(record.outcome, ClassSourceOutcome::Recovered { .. })
        || item.access_flags & (ACC_PUBLIC | ACC_STATIC) != ACC_PUBLIC
        || item.descriptor.raw().0.as_slice() != b"()Ljava/lang/Number;"
        || class_internal.contains(&b'$')
        || class_flags & (ACC_INTERFACE | ACC_ENUM | ACC_ANNOTATION) != 0
        || class_superclass != Some(b"java/lang/Object".as_slice())
        || !class_interfaces.is_empty()
        || !class_scope.is_empty()
        || class_signature_present
        || !attributes.throws_raw.is_empty()
        || !parsed.parameters.is_empty()
        || !parsed.throws.is_empty()
        || !matches!(candidate, Some(GenericReturnCandidate {
            parameters,
            value: GenericReturnValue::NullLiteral,
        }) if parameters.is_empty())
    {
        return Err(refused(
            "null-return method-local type variable requires a public no-argument instance method on a top-level Object subclass with no interfaces",
        ));
    }
    let [parameter] = parsed.type_parameters.as_slice() else {
        return Err(refused(
            "null-return method must declare exactly one type variable",
        ));
    };
    let Some(SignatureType::TypeVariable(result)) = parsed.result.as_ref() else {
        return Err(refused("null-return method result is not a type variable"));
    };
    let Some(SignatureType::Class(bound)) = parameter.class_bound.as_ref() else {
        return Err(refused(
            "null-return type variable must have one class bound",
        ));
    };
    if parameter.name != *result
        || !parameter.interface_bounds.is_empty()
        || bound.segments.len() != 1
        || bound.segments[0].binary_name.as_slice() != b"java/lang/Number"
        || !bound.segments[0].arguments.is_empty()
    {
        return Err(refused(
            "null-return Signature must be one method-local T extends Number result",
        ));
    }
    budget.poll()?;
    budget.charge(CountedBudgetDimension::AnalysisSteps, 1)?;
    generic_method_declaration(
        record, projection, attributes, parsed, candidate, false, None,
    )
}

fn simple_generic_class_name(raw: &[u8]) -> Result<String> {
    let text = std::str::from_utf8(raw).map_err(|_| {
        Error::unsupported(
            "generic_source_shape_unproved",
            "class name is not source UTF-8",
        )
    })?;
    if text.contains('$') || text.split('/').any(|part| !is_java_identifier(part)) {
        return Err(Error::unsupported(
            "generic_source_shape_unproved",
            "class name has no unambiguous Java source spelling",
        ));
    }
    Ok(text.replace('/', "."))
}

/// The class-header spelling of one binary class name: the class file's own name, its package
/// separators written as dots and every `$` kept — exactly the name [`class_name`] writes for
/// every parent the raw header states, so a projected entry is the same reference the raw header
/// already held and only its type arguments are new.
///
/// This is the one position where a `$` name needs no nesting proof: the presentation writes
/// every class as the top-level unit its binary name states, and the class header is that unit's
/// own declaration. A member, annotation or type-parameter position cannot call this — there a
/// `$` name without the member proof that selected a source path keeps the raw descriptor
/// declaration ([`simple_generic_class_name`]).
///
/// A name with a part that is not a Java identifier has no spelling at all, exactly as in the
/// selected-source-path rule.
fn binary_pool_class_name(raw: &[u8]) -> Result<String> {
    let text = std::str::from_utf8(raw).map_err(|_| {
        Error::unsupported(
            "generic_source_shape_unproved",
            "class name is not source UTF-8",
        )
    })?;
    if text.split('/').any(|part| !is_java_identifier(part)) {
        return Err(Error::unsupported(
            "generic_source_shape_unproved",
            "class name has no unambiguous Java source spelling",
        ));
    }
    Ok(text.replace('/', "."))
}

/// The initializer one field's own `ConstantValue` attribute states (JVMS 4.7.2), as the field's
/// declaration writes it, or `None` when the field's declaration states none.
///
/// The read is [`attribute_facts`] over this field's own `ConstantValue` shell(s) — the reader's one
/// parser for that attribute, and only those shells are handed over, so the `attribute_bytes` charge
/// is exactly this attribute's — and nothing here reads a `<clinit>`, a use site or another member:
/// the initializer is the constant the field's own attribute declares.
///
/// `None` is "nothing to write": the field declares no `ConstantValue` at all, or its value is one
/// this presentation has no literal for (see [`resolve_constant_value`]). The field then keeps the
/// initializer-less declaration its flags and its descriptor state, and not one literal is invented
/// for it.
///
/// An `Err` is the reader's own failure to read the attribute — its bytes are damaged, its charge was
/// refused, the request was cancelled. A field record states no refusal of its own in this report
/// (unlike a member's own run), so the caller's decision is the read's own: the presentation stops
/// where the read that could not be performed happened, rather than publishing a declaration it
/// could not establish.
pub(crate) fn declared_constant_value(
    bytes: &[u8],
    field: &MemberHeader,
    pool: &[CpEntryFacts],
    budget: &mut Budget,
) -> Result<Option<MemberDefault>> {
    if !declares_constant_value(field) {
        return Ok(None);
    }
    let shells = attribute_shells(field, b"ConstantValue");
    let Some(index) = attribute_facts(bytes, &shells, pool, budget)?.constant_value else {
        return Ok(None);
    };
    Ok(resolve_constant_value(
        &field.descriptor.raw().0,
        index.0,
        pool,
    ))
}

/// The initializer one `ConstantValue` attribute states for one field (JVMS 4.7.2), or `None` when
/// this presentation has no literal for it.
///
/// The attribute states one pool index and **no type**: which constant it is comes from the
/// descriptor of the field it initializes, so the same `CONSTANT_Integer` is `3` in an `int` field,
/// `true` in a `boolean` field and `'A'` in a `char` field, and the pair has to agree for any
/// initializer to be written at all. A `float`/`double` constant — which this field path does not
/// spell — a `Z` that is neither `0` nor `1`, an index that names no entry or an
/// entry of another kind (a `CONSTANT_Utf8`, a `CONSTANT_Long` in an `int` field) each state no
/// initializer rather than one that is invented, and a field that declares the attribute keeps the
/// declaration its flags and its descriptor state.
fn resolve_constant_value(
    descriptor: &[u8],
    index: u16,
    pool: &[CpEntryFacts],
) -> Option<MemberDefault> {
    let entry = &cp_entry(pool, index).ok()?.kind;
    match (descriptor, entry) {
        ([b'I'], CpEntryKind::Integer { value }) => Some(MemberDefault::Integer(*value)),
        ([b'J'], CpEntryKind::Long { value }) => Some(MemberDefault::Long(*value)),
        ([b'B'], CpEntryKind::Integer { value }) => Some(MemberDefault::Byte(*value)),
        ([b'S'], CpEntryKind::Integer { value }) => Some(MemberDefault::Short(*value)),
        ([b'C'], CpEntryKind::Integer { value }) => {
            Some(MemberDefault::Char(u16::try_from(*value).ok()?))
        }
        ([b'Z'], CpEntryKind::Integer { value }) => Some(MemberDefault::Boolean(match value {
            0 => false,
            1 => true,
            _ => return None,
        })),
        (b"Ljava/lang/String;", CpEntryKind::String { value, .. }) => {
            Some(MemberDefault::String(value.clone()))
        }
        _ => None,
    }
}

/// One declaration's literal, as the class file's own attribute states it.
///
/// Two attributes state a literal this presentation writes, and both state it as one of these values:
/// a member's `AnnotationDefault` (JVMS 4.7.22), written after the `default` keyword of its
/// declaration, and a field's `ConstantValue` (JVMS 4.7.2), written as that field's initializer. The
/// value is the attribute's own constant with the pool entries its own indexes name resolved, and it
/// exists only for the kinds this presentation has a literal for: for an `AnnotationDefault` the
/// eight constant tags, a string, an enum constant, a class literal, a nested annotation and arrays
/// of those; for a
/// `ConstantValue` the kinds [`resolve_constant_value`] accepts. A value that is not here is a value
/// the declaration writes no default and no initializer for — [`declared_annotation_default`] and
/// [`declared_constant_value`] resolve nothing for a `float`/`double` field constant or an array
/// that holds one, because a partial literal would be a claim the attribute does not make. F/D
/// variants are constructed only by the AnnotationDefault path.
///
/// The two paths share this one vocabulary so they spell one constant one way: `3L` is the same
/// spelling whichever attribute states it, and a string is escaped by the one rule this engine
/// escapes string literals with.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) enum MemberDefault {
    /// `B`: a `byte`, written as the decimal integer it is.
    Byte(i32),
    /// `C`: a `char`, written as the character literal of its UTF-16 code unit.
    Char(u16),
    /// `I`: an `int`, written as the decimal integer it is.
    Integer(i32),
    /// `S`: a `short`, written as the decimal integer it is.
    Short(i32),
    /// `Z`: a `boolean`, written as `true` or `false`.
    Boolean(bool),
    /// `J`: a `long`, written as the decimal integer it is with the `L` its type needs.
    Long(i64),
    /// `F`/`D`: an annotation constant's raw IEEE bits, never used for a field initializer.
    Float(u32),
    Double(u64),
    /// `s`: a string, written as the Java string literal its text is.
    String(JvmBytes),
    /// `e`: an enum constant, written as its type's name, a dot, and the constant's own simple name.
    Enum {
        type_name: String,
        constant_name: String,
    },
    /// `c`: a class literal, written as its type's name and `.class`.
    Class {
        type_name: String,
    },
    /// `@`: a nested annotation with its type and explicitly named values in attribute order.
    Annotation {
        type_name: String,
        elements: Vec<(String, MemberDefault)>,
    },
    /// `[`: the elements the array declares, written `{ elem, elem }`.
    Array(Vec<MemberDefault>),
}

impl MemberDefault {
    /// The literal this default is written as, after the `default` keyword.
    fn spelling(&self) -> String {
        match self {
            Self::Byte(value) | Self::Integer(value) | Self::Short(value) => value.to_string(),
            Self::Boolean(value) => if *value { "true" } else { "false" }.to_owned(),
            Self::Long(value) => format!("{value}L"),
            Self::Float(bits) => float_default_spelling(*bits)
                .expect("only a faithfully spellable annotation float is resolved"),
            Self::Double(bits) => double_default_spelling(*bits)
                .expect("only a faithfully spellable annotation double is resolved"),
            Self::Char(value) => char_literal(*value),
            Self::String(bytes) => {
                format!("\"{}\"", escape_string(&String::from_utf8_lossy(&bytes.0)))
            }
            Self::Enum {
                type_name,
                constant_name,
            } => format!("{type_name}.{constant_name}"),
            Self::Class { type_name } => format!("{type_name}.class"),
            Self::Annotation {
                type_name,
                elements,
            } => {
                let elements: Vec<String> = elements
                    .iter()
                    .map(|(name, value)| format!("{name} = {}", value.spelling()))
                    .collect();
                format!("@{type_name}({})", elements.join(", "))
            }
            Self::Array(elements) if elements.is_empty() => "{}".to_owned(),
            Self::Array(elements) => {
                let written: Vec<String> = elements.iter().map(Self::spelling).collect();
                format!("{{{}}}", written.join(", "))
            }
        }
    }
}

/// One `element_value` (JVMS 4.7.22.1) resolved against the pool this class's read published, or
/// `None` when this presentation has no literal for it ([`declared_annotation_default`]).
///
/// The tag decides the reading, not the member's descriptor: `B`/`C`/`I`/`S`/`Z` all name one
/// `CONSTANT_Integer`, and the value `65` is `65` under `I`, `'A'` under `C` and no boolean at all
/// under `Z`. A value the class file states something else for is no literal either: a `Z` that is
/// neither `0` nor `1`, a `C` outside the `0..=0xFFFF` one UTF-16 code unit is, an index that does not
/// hold the constant its tag names, a `c` whose descriptor is the `void` one (a `V` names no type this
/// presentation spells), and an enum constant whose name is not UTF-8. Each states no default, and no
/// default is invented for it.
fn resolve_default(value: &ElementValueFacts, pool: &[CpEntryFacts]) -> Option<MemberDefault> {
    Some(match value {
        ElementValueFacts::Constant { tag, index } => {
            match (tag, &cp_entry(pool, index.0).ok()?.kind) {
                (ElementConstantTag::Byte, CpEntryKind::Integer { value }) => {
                    MemberDefault::Byte(*value)
                }
                (ElementConstantTag::Char, CpEntryKind::Integer { value }) => {
                    MemberDefault::Char(u16::try_from(*value).ok()?)
                }
                (ElementConstantTag::Integer, CpEntryKind::Integer { value }) => {
                    MemberDefault::Integer(*value)
                }
                (ElementConstantTag::Short, CpEntryKind::Integer { value }) => {
                    MemberDefault::Short(*value)
                }
                (ElementConstantTag::Boolean, CpEntryKind::Integer { value }) => {
                    MemberDefault::Boolean(match value {
                        0 => false,
                        1 => true,
                        _ => return None,
                    })
                }
                (ElementConstantTag::Long, CpEntryKind::Long { value }) => {
                    MemberDefault::Long(*value)
                }
                (ElementConstantTag::Float, CpEntryKind::Float { bits }) => {
                    float_default_spelling(*bits).map(|_| MemberDefault::Float(*bits))?
                }
                (ElementConstantTag::Double, CpEntryKind::Double { bits }) => {
                    double_default_spelling(*bits).map(|_| MemberDefault::Double(*bits))?
                }
                _ => return None,
            }
        }
        ElementValueFacts::Utf8(bytes) => MemberDefault::String(bytes.clone()),
        ElementValueFacts::Enum {
            type_descriptor,
            constant_name,
        } => MemberDefault::Enum {
            type_name: descriptor_type(&type_descriptor.0, DescriptorKind::Field)?,
            constant_name: String::from_utf8(constant_name.0.clone()).ok()?,
        },
        ElementValueFacts::Class(descriptor) => MemberDefault::Class {
            type_name: descriptor_type(&descriptor.0, DescriptorKind::Return)?,
        },
        ElementValueFacts::Annotation {
            type_descriptor,
            elements,
        } => {
            let type_name = annotation_type_name(&type_descriptor.0)?;
            let elements = elements
                .iter()
                .map(|element| {
                    let name = String::from_utf8(element.name.0.clone()).ok()?;
                    is_java_identifier(&name).then_some(())?;
                    Some((name, resolve_default(&element.value, pool)?))
                })
                .collect::<Option<Vec<_>>>()?;
            MemberDefault::Annotation {
                type_name,
                elements,
            }
        }
        ElementValueFacts::Array(elements) => MemberDefault::Array(
            elements
                .iter()
                .map(|element| resolve_default(element, pool))
                .collect::<Option<Vec<MemberDefault>>>()?,
        ),
    })
}

/// Spell finite IEEE values as exact Java hexadecimal floating-point literals without converting
/// the raw facts through host floating-point arithmetic. Unsupported NaN patterns have no spelling.
fn float_default_spelling(bits: u32) -> Option<String> {
    let sign = if bits >> 31 == 0 { "" } else { "-" };
    let exponent = (bits >> 23) & 0xff;
    let fraction = bits & 0x7f_ffff;
    match (exponent, fraction) {
        (0xff, 0) => Some(format!(
            "Float.{}INFINITY",
            if sign.is_empty() {
                "POSITIVE_"
            } else {
                "NEGATIVE_"
            }
        )),
        (0xff, 0x40_0000) if sign.is_empty() => Some("Float.NaN".to_owned()),
        (0xff, _) => None,
        (0, 0) => Some(format!("{sign}0.0f")),
        (0, fraction) => Some(format!("{sign}0x0.{:06x}p-126f", fraction << 1)),
        _ => Some(format!(
            "{sign}0x1.{:06x}p{}f",
            fraction << 1,
            i32::try_from(exponent).unwrap() - 127
        )),
    }
}

fn double_default_spelling(bits: u64) -> Option<String> {
    let sign = if bits >> 63 == 0 { "" } else { "-" };
    let exponent = (bits >> 52) & 0x7ff;
    let fraction = bits & 0x000f_ffff_ffff_ffff;
    match (exponent, fraction) {
        (0x7ff, 0) => Some(format!(
            "Double.{}INFINITY",
            if sign.is_empty() {
                "POSITIVE_"
            } else {
                "NEGATIVE_"
            }
        )),
        (0x7ff, 0x0008_0000_0000_0000) if sign.is_empty() => Some("Double.NaN".to_owned()),
        (0x7ff, _) => None,
        (0, 0) => Some(format!("{sign}0.0d")),
        (0, fraction) => Some(format!("{sign}0x0.{fraction:013x}p-1022d")),
        _ => Some(format!(
            "{sign}0x1.{fraction:013x}p{}d",
            i32::try_from(exponent).unwrap() - 1023
        )),
    }
}

/// The class type a nested annotation descriptor names, when each segment is a source identifier.
///
/// Annotation descriptors name a class, not an array or primitive. A slash becomes a package dot;
/// every resulting segment must remain writable without guessing an alias, because aliases would
/// name a different annotation type at the use site.
fn annotation_type_name(descriptor: &[u8]) -> Option<String> {
    if !descriptor.starts_with(b"L") || !descriptor.ends_with(b";") {
        return None;
    }
    let internal_name = &descriptor[1..descriptor.len() - 1];
    if internal_name.is_empty()
        || internal_name.split(|byte| *byte == b'/').any(|segment| {
            segment.is_empty()
                || segment
                    .iter()
                    .any(|byte| matches!(*byte, b'.' | b'[' | b';'))
        })
    {
        return None;
    }
    let type_name = descriptor_type(descriptor, DescriptorKind::Field)?;
    type_name
        .split('.')
        .all(is_java_identifier)
        .then_some(type_name)
}

/// The Java type one field or return descriptor names, as the recovery layer spells types.
///
/// It is the same spelling the parameters and the field declarations are written with
/// ([`source_type`]), so a default's enum type or class literal cannot name a type the declaration
/// beside it would write differently. A descriptor this presentation cannot spell — a `V` class
/// literal names `void`, which is no type here — states no default.
fn descriptor_type(descriptor: &[u8], kind: DescriptorKind) -> Option<String> {
    let facts = descriptor_facts(descriptor, kind).ok()?;
    source_type(facts.single()?)
}

/// One `char` value's own text as a character literal, escaped by the rule every literal in this
/// repository is escaped with: the delimiter, the backslash, the controls and the line terminators
/// are escapes, every other unit inside the BMP is written as itself, and a unit a literal cannot
/// carry is spelled `\uXXXX`.
///
/// This is the character literal the recovery layer's own `switch` keys are written with (`case
/// 'a':`), for the one place a declaration states a character: its escape table is the emitter's,
/// and it is stated here because that table is not published.
fn char_literal(value: u16) -> String {
    let mut literal = String::from("'");
    match value {
        0x27 => literal.push_str("\\'"),
        0x5c => literal.push_str("\\\\"),
        0x08 => literal.push_str("\\b"),
        0x09 => literal.push_str("\\t"),
        0x0a => literal.push_str("\\n"),
        0x0c => literal.push_str("\\f"),
        0x0d => literal.push_str("\\r"),
        0x20..=0x7e => literal.push(char::from_u32(u32::from(value)).unwrap_or('?')),
        other => literal.push_str(&format!("\\u{other:04x}")),
    }
    literal.push('\'');
    literal
}

/// The `throws` clause one member's own `Exceptions` attribute is written as, after its parameter
/// list, or nothing at all when the member declares no exception.
///
/// The clause is one line of the declaration and it states exactly the types the attribute states,
/// in the attribute's own order ([`declared_exceptions`]); an empty list is no clause, because
/// `throws` with nothing after it is not a clause Java writes.
fn throws_clause(throws: &[String]) -> String {
    if throws.is_empty() {
        return String::new();
    }
    format!(" throws {}", throws.join(", "))
}

/// Whether one member is written with `default`: a member of a class whose own flags include
/// `ACC_INTERFACE`, whose own flags are neither `ACC_STATIC` nor `ACC_ABSTRACT`, and whose
/// declaration carries a `Code` attribute.
///
/// Those are exactly the members the format calls default methods: an interface's body-bearing
/// member that is not static. A class never gains one — `default` is no class member modifier — and
/// an interface's `static` member stays `static` with no `default` beside it. The `Code` attribute is
/// read off the member's own record ([`MethodItem::body`]), which is the same fact the member's run
/// is decided by, so a member spelled here and a member run there cannot disagree about whether the
/// class file declares a body.
fn is_default_member(class_flags: u16, item: &MethodItem) -> bool {
    class_flags & ACC_INTERFACE != 0
        && item.access_flags & ACC_STATIC == 0
        && item.access_flags & ACC_ABSTRACT == 0
        && matches!(item.body, crate::MemberBodyEvidence::CodeAttribute { .. })
}

/// Spells one method's declaration, and the marker its own spelling needs.
///
/// `class` is the class's own spelling ([`ClassSourceDeclaration::name`]), which a constructor's
/// declaration is written with: the class file names it `<init>`, and Java spells the same
/// declaration with the class's name, so nothing here claims a name the bytes do not state — the raw
/// name stays in [`ClassSourceMethod::item`]. `<clinit>` is spelled as Java's static initializer
/// block (`static`), which is the declaration the class file means.
///
/// `class_flags` are the flags of the class that **declares** this member, which one rule of the
/// spelling needs and the member's own flags cannot state: a member of an interface
/// (`ACC_INTERFACE`, 0x0200) that is neither `static` (0x0008) nor `abstract` (0x0400) and whose
/// declaration carries a `Code` attribute is a `default` member, and `default` is written between
/// its access modifiers and its return type. A class's own member never gains one, and an
/// interface's `static` member stays `static` whichever class flags it sits in.
///
/// The member's own `ACC_VARARGS` (0x0080) is the one fact of the parameter list beside the
/// descriptor ([`method_descriptor`]): when it is set and the descriptor's last parameter is an
/// array, that parameter is written `T...` in place of `T[]`, and every position before it — and
/// the last one of every member without the flag — is written exactly as the descriptor states it.
/// The declaration is all the flag changes: no argument is expanded or boxed here, and the body
/// still reads the slot as the array it is.
///
/// `throws` is the member's own `Exceptions` attribute (JVMS 4.7.4), as the read that resolved it
/// published it: a member that declares one is written `throws A, B` after its parameter list, in
/// the attribute's own order, and a member that declares none — or one whose attribute declares no
/// exception — writes no clause. No exception is inferred from an `athrow`.
///
/// `default` is the member's own `AnnotationDefault` attribute (JVMS 4.7.22), as the read that
/// resolved it published it: a member that declares one is written `default <literal>` after its
/// parameter list, and a member that declares none — and one whose value this presentation has no
/// literal for — writes no `default` at all. Which class declares such a member is not read here:
/// the attribute's presence is the fact, so an ordinary interface or class member that declares one
/// is written the same way an annotation type's member is.
#[allow(clippy::too_many_arguments)]
pub(crate) fn spell_method(
    item: &MethodItem,
    facts: Option<&RecoveryFacts>,
    recovered_parameter_names: Option<&[Option<String>]>,
    class: &str,
    class_internal: &[u8],
    nested_class_members: &[String],
    class_flags: u16,
    attributes: Option<&MemberAttributes>,
    annotations: &MemberAnnotationFacts,
    pool: &[CpEntryFacts],
) -> Spelled {
    let signature = method_descriptor(
        &item.descriptor.raw().0,
        is_static(item.access_flags),
        item.access_flags & ACC_VARARGS != 0,
    );
    let parameter_count = signature
        .as_ref()
        .map(|signature| signature.parameters.len());
    let mut member_annotations =
        spell_member_annotation_uses(annotations.declaration.clone(), pool);
    let mut parameter_annotations =
        spell_parameter_annotation_uses(annotations.parameters.clone(), pool, parameter_count);
    let type_annotations = spell_type_annotation_uses(
        annotations.type_uses.clone(),
        TypeUseOwner::Method,
        &item.descriptor.raw().0,
        pool,
        &member_annotations,
        Some(&annotations.parameters),
        parameter_count,
    );
    if item.name.raw().0 == b"<clinit>" {
        refuse_uses(
            &mut member_annotations,
            "class initializer blocks have no Java method declaration to annotate",
        );
    }
    let mut spelled = spell_method_declaration(
        item,
        facts,
        recovered_parameter_names,
        class,
        class_internal,
        nested_class_members,
        class_flags,
        attributes,
        &parameter_annotations.uses_by_position,
        &type_annotations,
    );
    if spelled.declaration.is_none() {
        refuse_uses(
            &mut member_annotations,
            "method descriptor cannot be spelled as a Java declaration",
        );
        refuse_parameter_uses(
            &mut parameter_annotations,
            "method descriptor cannot establish parameter positions",
        );
    }
    spelled.annotations = member_annotations;
    spelled.parameter_annotations = parameter_annotations;
    spelled.type_annotations = type_annotations;
    spelled
}

#[allow(clippy::too_many_arguments)]
fn spell_method_declaration(
    item: &MethodItem,
    facts: Option<&RecoveryFacts>,
    recovered_parameter_names: Option<&[Option<String>]>,
    class: &str,
    class_internal: &[u8],
    nested_class_members: &[String],
    class_flags: u16,
    attributes: Option<&MemberAttributes>,
    parameter_annotations: &[Vec<String>],
    type_annotations: &TypeAnnotationUses,
) -> Spelled {
    // The class a nested reference in this declaration is spelled against — the class whose text
    // the declaration is written into — together with the `InnerClasses` row set that gates the
    // spelling at all.
    let current = std::str::from_utf8(class_internal).ok();
    let (default, throws) = attributes.map_or((None, &[][..]), |attributes| {
        (attributes.default.as_ref(), attributes.throws.as_slice())
    });
    let raw = &item.name.raw().0;
    match raw.as_slice() {
        b"<clinit>" => {
            return Spelled {
                declaration: Some("static".to_owned()),
                marker: None,
                annotations: MemberAnnotationUses::default(),
                parameter_annotations: ParameterAnnotationUses::default(),
                type_annotations: TypeAnnotationUses::default(),
            };
        }
        b"<init>" => {
            let Some(signature) = method_descriptor(
                &item.descriptor.raw().0,
                is_static(item.access_flags),
                item.access_flags & ACC_VARARGS != 0,
            ) else {
                return Spelled {
                    declaration: None,
                    marker: Some(not_a_descriptor(item, "method")),
                    annotations: MemberAnnotationUses::default(),
                    parameter_annotations: ParameterAnnotationUses::default(),
                    type_annotations: TypeAnnotationUses::default(),
                };
            };
            let mut declaration = String::new();
            if let Some(word) = visibility(item.access_flags) {
                declaration.push_str(word);
                declaration.push(' ');
            }
            declaration.push_str(class);
            declaration.push_str(&arguments(
                facts,
                recovered_parameter_names,
                &signature,
                current,
                nested_class_members,
                parameter_annotations,
                &type_annotations.parameter_uses,
                attributes.and_then(|attributes| attributes.parameters.as_deref()),
            ));
            declaration.push_str(&throws_clause(throws));
            return Spelled {
                declaration: Some(declaration),
                marker: None,
                annotations: MemberAnnotationUses::default(),
                parameter_annotations: ParameterAnnotationUses::default(),
                type_annotations: TypeAnnotationUses::default(),
            };
        }
        _ => {}
    }
    let Some(signature) = method_descriptor(
        &item.descriptor.raw().0,
        is_static(item.access_flags),
        item.access_flags & ACC_VARARGS != 0,
    ) else {
        return Spelled {
            declaration: None,
            marker: Some(not_a_descriptor(item, "method")),
            annotations: MemberAnnotationUses::default(),
            parameter_annotations: ParameterAnnotationUses::default(),
            type_annotations: TypeAnnotationUses::default(),
        };
    };
    let (name, aliased) = written_name(raw);
    let mut words: Vec<&str> = Vec::new();
    words.extend(visibility(item.access_flags));
    if is_static(item.access_flags) {
        words.push("static");
    }
    if item.access_flags & ACC_FINAL != 0 {
        words.push("final");
    }
    if item.access_flags & ACC_ABSTRACT != 0 {
        words.push("abstract");
    }
    if item.access_flags & ACC_NATIVE != 0 {
        words.push("native");
    }
    if item.access_flags & ACC_SYNCHRONIZED != 0 {
        words.push("synchronized");
    }
    if item.access_flags & ACC_STRICT != 0 {
        words.push("strictfp");
    }
    if is_default_member(class_flags, item) {
        // The last modifier: `default` stands between the access modifiers and the return type,
        // which is where Java source writes it (`public default int zero()`).
        words.push("default");
    }
    let returns = signature.returns.as_deref().unwrap_or("void");
    let returns =
        nested_member_reference_spelling(returns, current, Some(nested_class_members)).into_owned();
    let returns = if type_annotations.return_uses.is_empty() {
        returns
    } else {
        decorate_qualified_type(&returns, &type_annotations.return_uses).unwrap_or(returns)
    };
    let mut declaration = String::new();
    for word in words {
        declaration.push_str(word);
        declaration.push(' ');
    }
    declaration.push_str(&returns);
    declaration.push(' ');
    declaration.push_str(&name);
    declaration.push_str(&arguments(
        facts,
        recovered_parameter_names,
        &signature,
        current,
        nested_class_members,
        parameter_annotations,
        &type_annotations.parameter_uses,
        attributes.and_then(|attributes| attributes.parameters.as_deref()),
    ));
    declaration.push_str(&throws_clause(throws));
    if let Some(default) = default {
        // The default stands between the parameter list and the `;` (or the body), which is the one
        // place Java source states one.
        declaration.push_str(" default ");
        declaration.push_str(&default.spelling());
    }
    Spelled {
        declaration: Some(declaration),
        marker: aliased.then(|| aliased_name(item)),
        annotations: MemberAnnotationUses::default(),
        parameter_annotations: ParameterAnnotationUses::default(),
        type_annotations: TypeAnnotationUses::default(),
    }
}

/// Spells one field's declaration, and the marker its own spelling needs.
///
/// `constant` is the value the field's own `ConstantValue` attribute (JVMS 4.7.2) states, as the
/// read that resolved it published it: a field with one is written `<declaration> = <literal>`, and
/// a field that declares no such attribute — or one whose value this presentation has no literal
/// for — is written without an initializer at all. Nothing is inferred from a `<clinit>` or a use
/// site, so the one `=` this presentation writes is the one the field's own attribute states.
fn spell_field_declaration(
    item: &FieldItem,
    current_class: Option<&str>,
    nested_class_members: &[String],
    constant: Option<&MemberDefault>,
) -> Spelled {
    let Some(field_type) = field_type(&item.descriptor.raw().0).map(|ty| {
        nested_member_reference_spelling(&ty, current_class, Some(nested_class_members))
            .into_owned()
    }) else {
        return Spelled {
            declaration: None,
            marker: Some(not_a_descriptor_field(item)),
            annotations: MemberAnnotationUses::default(),
            parameter_annotations: ParameterAnnotationUses::default(),
            type_annotations: TypeAnnotationUses::default(),
        };
    };
    let (name, aliased) = written_name(&item.name.raw().0);
    let declaration = field_declaration_with_type(item, &field_type, constant);
    Spelled {
        declaration: Some(declaration),
        marker: aliased.then(|| {
            format!(
                "// jarde: the field's raw name `{}` is not a Java identifier; it is written as `{name}`",
                comment_name(&item.name)
            )
        }),
        annotations: MemberAnnotationUses::default(),
        parameter_annotations: ParameterAnnotationUses::default(),
        type_annotations: TypeAnnotationUses::default(),
    }
}

fn field_declaration_with_type(
    item: &FieldItem,
    ty: &str,
    constant: Option<&MemberDefault>,
) -> String {
    let (name, _) = written_name(&item.name.raw().0);
    let mut words: Vec<&str> = Vec::new();
    words.extend(visibility(item.access_flags));
    if is_static(item.access_flags) {
        words.push("static");
    }
    if item.access_flags & ACC_FINAL != 0 {
        words.push("final");
    }
    if item.access_flags & ACC_VOLATILE != 0 {
        words.push("volatile");
    }
    if item.access_flags & ACC_TRANSIENT != 0 {
        words.push("transient");
    }
    let mut declaration = String::new();
    for word in words {
        declaration.push_str(word);
        declaration.push(' ');
    }
    declaration.push_str(ty);
    declaration.push(' ');
    declaration.push_str(&name);
    if let Some(constant) = constant {
        declaration.push_str(" = ");
        declaration.push_str(&constant.spelling());
    }
    declaration
}

/// Atomically project one field's generic type after reader erasure proof and the first source
/// compatibility gate. Every refusal keeps the physical descriptor declaration intact.
pub(crate) fn project_field_signature(
    record: &mut ClassSourceField,
    member: &MemberHeader,
    bytes: &[u8],
    pool: &[CpEntryFacts],
    class_internal: &[u8],
    class_flags: u16,
    class_scope: &[TypeParameterErasure],
    class_header_projected: bool,
    constant: Option<&MemberDefault>,
    same_class: SameClassBinding,
    same_class_note: &str,
    same_class_field_uses: &[SameClassFieldUse],
    published_method_parameters: &[SameClassPublishedMethodParameters],
    java_release: u16,
    budget: &mut Budget,
) -> Result<SignatureProjection> {
    let shells = attribute_shells(member, b"Signature");
    if shells.is_empty() {
        return Ok(SignatureProjection::Settled);
    }
    enum FieldProjection {
        Deferred,
        Declaration(String, Vec<u8>),
    }
    let result = (|| -> Result<FieldProjection> {
        let facts = attribute_facts(bytes, &shells, pool, budget)?;
        let raw = facts
            .signature
            .ok_or_else(|| {
                Error::invalid_input("jvm_signature_missing", "Signature did not resolve")
            })?
            .0;
        let parsed = parse_field_signature(&raw, budget)?;
        prove_field_signature_erasure_with_class_scope(
            &parsed,
            &member.descriptor.raw().0,
            class_scope,
            budget,
        )?;

        if same_class == SameClassBinding::Proven {
            budget.charge(
                CountedBudgetDimension::AnalysisSteps,
                u64::try_from(same_class_field_uses.len()).unwrap_or(u64::MAX),
            )?;
            for use_site in same_class_field_uses {
                budget.poll()?;
                if use_site.owner != class_internal
                    || use_site.name != member.name.raw().0
                    || use_site.descriptor != member.descriptor.raw().0
                    || !matches!(use_site.opcode, 0xb3 | 0xb5)
                {
                    continue;
                }
                let Some(source) = use_site.write_source.as_ref() else {
                    return Err(Error::unsupported(
                        "field_generic_write_source_unproved",
                        format!(
                            "writer {}@{} has no closed SSA source",
                            use_site.caller, use_site.bci
                        ),
                    ));
                };
                let raw_receiver = raw_field_receiver_source(
                    use_site,
                    class_internal,
                    class_header_projected && !class_scope.is_empty(),
                    published_method_parameters,
                    budget,
                )?;
                let source_complete = raw_receiver
                    || matches!(source, SameClassFieldWriteSource::RawAllocation { .. });
                let assignable = if raw_receiver {
                    raw_field_write_source_assignable(
                        source,
                        &use_site.descriptor,
                        published_method_parameters,
                        java_release,
                        budget,
                    )?
                } else {
                    prove_field_write_source_assignable(
                        source,
                        &parsed.ty,
                        class_scope,
                        published_method_parameters,
                        java_release,
                        budget,
                    )?
                };
                if !assignable || (source_complete && !use_site.source_complete) {
                    return Err(Error::unsupported(
                        "field_generic_write_source_unproved",
                        format!(
                            "writer {}@{} is not source-assignable to the projected field type",
                            use_site.caller, use_site.bci
                        ),
                    ));
                }
            }
        }

        if record.declaration.is_none()
            || !record.markers.is_empty()
            || !std::str::from_utf8(&record.item.name.raw().0).is_ok_and(is_java_identifier)
            || record.item.access_flags
                & !(ACC_PUBLIC
                    | ACC_PRIVATE
                    | ACC_PROTECTED
                    | ACC_STATIC
                    | ACC_FINAL
                    | ACC_VOLATILE
                    | ACC_TRANSIENT)
                != 0
            // A `$`-nested class's field keeps a source position only inside the nesting its
            // own header proof published; without that header the position is unproved and the
            // field stays on its physical descriptor.
            || (class_internal.contains(&b'$') && !class_header_projected)
            || class_flags & (ACC_INTERFACE | ACC_ENUM | ACC_ANNOTATION) != 0
            || !record.type_annotations.attributes.is_empty()
            || !record.type_annotations.refusals.is_empty()
        {
            return Err(Error::unsupported(
                "field_generic_source_unproved",
                "field name, flags, descriptor, or type-use annotation path cannot be preserved",
            ));
        }

        budget.charge(
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(pool.len()).unwrap_or(u64::MAX),
        )?;
        if pool.iter().any(|entry| {
            matches!(&entry.kind,
                CpEntryKind::FieldRef { owner, name, descriptor, .. }
                    if owner.0.as_slice() == class_internal
                        && name.0.as_slice() == member.name.raw().0.as_slice()
                        && descriptor.0.as_slice() == member.descriptor.raw().0.as_slice()
            )
        }) {
            // As with methods, the entry is a candidate fact: the class-level inventory of this
            // class's own decoded bodies decides whether a real read/write site keeps accepting the
            // parameterized type. Unproved sites keep the existing refusal.
            match same_class {
                SameClassBinding::Pending => {
                    return Ok(FieldProjection::Deferred);
                }
                SameClassBinding::Proven => {}
                SameClassBinding::OverloadPending => {
                    return Err(Error::unsupported(
                        "field_generic_binding_unproved",
                        "overload-pending binding applies only to methods",
                    ));
                }
                SameClassBinding::Unproved => {
                    return Err(Error::unsupported(
                        "field_generic_body_unproved",
                        format!(
                            "a same-class Fieldref names this field and descriptor; {same_class_note}"
                        ),
                    ));
                }
            }
        }

        let ty = spell_ordinary_signature_type(&parsed.ty, class_scope, budget, 0)?;
        Ok(FieldProjection::Declaration(
            field_declaration_with_type(&record.item, &ty, constant),
            raw,
        ))
    })();
    match result {
        Ok(FieldProjection::Deferred) => Ok(SignatureProjection::DeferredSameClass),
        Ok(FieldProjection::Declaration(declaration, signature)) => {
            let marker = format!(
                "// jarde: field Signature `{}` projected after descriptor erasure and {}",
                comment_text(&String::from_utf8_lossy(&signature)),
                if same_class == SameClassBinding::Proven {
                    comment_text(same_class_note)
                } else {
                    "no same-class Fieldref".to_owned()
                },
            );
            let mut markers = record.markers.clone();
            markers.push(marker);
            let text = declaration_member(&declaration, &markers);
            budget.charge(
                CountedBudgetDimension::OutputBytes,
                u64::try_from(text.len()).unwrap_or(u64::MAX),
            )?;
            record.declaration = Some(declaration);
            record.markers = markers;
            Ok(SignatureProjection::Settled)
        }
        Err(error @ (Error::BudgetExceeded { .. } | Error::Cancelled { .. })) => Err(error),
        Err(error) => {
            let marker = format!(
                "// jarde: field Signature projection refused for `{}{}`: {}",
                comment_name(&record.item.name),
                comment_name(&record.item.descriptor),
                comment_text(&error.to_string()),
            );
            let mut markers = record.markers.clone();
            markers.push(marker);
            let text =
                declaration_member(record.declaration.as_deref().unwrap_or_default(), &markers);
            budget.charge(
                CountedBudgetDimension::OutputBytes,
                u64::try_from(text.len()).unwrap_or(u64::MAX),
            )?;
            record.markers = markers;
            Ok(SignatureProjection::Settled)
        }
    }
}

/// One parameter's type as the list writes it: the type the descriptor states, or — for the last
/// parameter of a member whose own `ACC_VARARGS` applies — that type's last `[]` written as the
/// three dots of a variable-arity parameter (`byte[][]` → `byte[]...`).
///
/// The cut is exact and not a second reading of the bytes: the spelling it trims is the one
/// [`source_type`] wrote from the same component, and [`method_descriptor`] states the flag only
/// for a component that is an array, so a type that does not end in `[]` is written as it stands
/// rather than trimmed to a type the descriptor never named.
fn varargs_type(ty: &str, varargs: bool) -> String {
    match ty.strip_suffix("[]") {
        Some(element) if varargs => format!("{element}..."),
        _ => ty.to_owned(),
    }
}

/// The argument list one declaration is written with: every parameter of the descriptor, in
/// declaration order, each with its type and its name.
///
/// A parameter's slot is the JVM layer's own derivation ([`Signature::parameters`]) — `this` holds
/// slot 0 of a member that is not `static`, a `long`/`double` fills two slots and an **array of
/// either fills one** — and the name is the one the body's own statements use for that slot
/// ([`parameter_names`]), so the declaration and the body cannot name two different slots for one
/// parameter.
///
/// The one parameter whose type is not written as the descriptor states it is the last one of a
/// member whose own `ACC_VARARGS` applies ([`Signature::varargs`]): it is written `T...`, the array
/// it is with the last `[]` spelled as the dots (see [`varargs_type`]). No other position is
/// touched, and no call site is read: the declaration says the member takes a variable number of
/// arguments, and the body still reads the slot as the array the descriptor states.
fn arguments(
    facts: Option<&RecoveryFacts>,
    recovered_parameter_names: Option<&[Option<String>]>,
    signature: &Signature,
    current_class: Option<&str>,
    nested_class_members: &[String],
    parameter_annotations: &[Vec<String>],
    type_annotations: &[Vec<String>],
    proved: Option<&[ProvedMethodParameter]>,
) -> String {
    let mut names = parameter_names(facts, signature.slots);
    if let Some(recovered) = recovered_parameter_names {
        for (name, chosen) in names.iter_mut().zip(recovered) {
            if let Some(chosen) = chosen {
                *name = chosen.clone();
            }
        }
    }
    let proved = proved.filter(|parameters| {
        facts.is_some_and(|facts| {
            facts.debug_locals().len() == parameters.len()
                && parameters
                    .iter()
                    .zip(facts.debug_locals())
                    .all(|(parameter, local)| {
                        local.slot() == parameter.slot
                            && local.name() == parameter.name
                            && local.range().is_none()
                    })
        })
    });
    let written: Vec<String> = signature
        .parameters
        .iter()
        .enumerate()
        .map(|(position, (ty, slot))| {
            let name = names
                .get(usize::from(*slot))
                .cloned()
                .unwrap_or_else(|| format!("arg{slot}"));
            let varargs = signature.varargs && position + 1 == signature.parameters.len();
            let ty =
                nested_member_reference_spelling(ty, current_class, Some(nested_class_members));
            let ty = type_annotations
                .get(position)
                .filter(|items| !items.is_empty())
                .and_then(|items| decorate_qualified_type(ty.as_ref(), items))
                .unwrap_or_else(|| ty.into_owned());
            let ty = varargs_type(&ty, varargs);
            let annotations = parameter_annotations
                .get(position)
                .into_iter()
                .flatten()
                .map(|annotation| format!("{annotation} "))
                .collect::<String>();
            let final_word = if proved
                .and_then(|parameters| parameters.get(position))
                .is_some_and(|parameter| {
                    parameter.slot == *slot && parameter.name == name && parameter.is_final
                }) {
                "final "
            } else {
                ""
            };
            format!("{annotations}{final_word}{ty} {name}")
        })
        .collect();
    format!("({})", written.join(", "))
}

/// The marker of a member whose raw descriptor is not the descriptor of its kind (JVMS 4.3.2/4.3.3).
fn not_a_descriptor(item: &MethodItem, kind: &str) -> String {
    format!(
        "// jarde: not spelled: the descriptor `{}` of the member `{}` is not a {kind} descriptor, so this presentation writes no declaration for it and performs no run for it",
        comment_name(&item.descriptor),
        comment_name(&item.name)
    )
}

fn not_a_descriptor_field(item: &FieldItem) -> String {
    format!(
        "// jarde: not spelled: the descriptor `{}` of the field `{}` is not a field descriptor, so this presentation writes no declaration for it",
        comment_name(&item.descriptor),
        comment_name(&item.name)
    )
}

/// The marker of a member whose raw name Java cannot spell.
fn aliased_name(item: &MethodItem) -> String {
    format!(
        "// jarde: the member's raw name `{}` is not a Java identifier; it is written as `{}`",
        comment_name(&item.name),
        written_name(&item.name.raw().0).0
    )
}

// ---------------------------------------------------------------------------------------------
// The text: one class, its members, and the blocks the recovery layer wrote
// ---------------------------------------------------------------------------------------------

/// One produced artifact, split at its own block: the envelope comment lines the recovery layer
/// wrote, and the statements it wrote.
struct Artifact<'a> {
    /// The envelope: the `//` lines the artifact opens with (`@method`, `@declaration`, the
    /// statement that the presentation is not claimed to compile).
    envelope: &'a str,
    /// The statements, with neither the artifact's opening brace nor its closing one.
    statements: &'a str,
}

/// Splits one produced artifact into its envelope and its statements, by the shape the emitter of
/// [`jarde_java::recover`] writes: comment lines, a line holding `{` alone, the statements at one
/// level of indentation, and a line holding `}` alone as the last line.
///
/// The split is a reading of that shape and it is deliberately strict: the statements of a body are
/// indented, so `{` alone can only be the block's own opening brace, and `}` alone as the last line
/// can only be its closing one. Anything else is not placed at all — the caller quotes it line by
/// line instead of guessing where a statement starts — because placing a statement outside the
/// member it belongs to would be worse than not placing it.
fn artifact(text: &str) -> Option<Artifact<'_>> {
    let mut open: Option<usize> = None;
    let mut close: Option<usize> = None;
    let mut at = 0usize;
    for line in text.split_inclusive('\n') {
        let bare = line.trim_end_matches('\n');
        if bare == "{" && open.is_none() {
            open = Some(at);
        }
        if bare == "}" {
            close = Some(at);
        }
        at += line.len();
    }
    let open = open?;
    let close = close?;
    if close < open + 2 {
        return None;
    }
    let trailing = &text[close..];
    if trailing != "}\n" && trailing != "}" {
        return None;
    }
    Some(Artifact {
        envelope: &text[..open],
        statements: &text[open + 2..close],
    })
}

/// One artifact this presentation could not place, quoted line by line as comments: nothing a run
/// produced is dropped, and none of it is read as a statement.
fn quote(text: &str) -> String {
    let mut quoted = String::new();
    for line in text.lines() {
        quoted.push_str("// ");
        quoted.push_str(line);
        quoted.push('\n');
    }
    quoted
}

/// One block of text, every non-blank line prefixed with `depth` levels of indentation.
fn indent(text: &str, depth: usize) -> String {
    let pad = "    ".repeat(depth);
    let mut out = String::new();
    for line in text.split_inclusive('\n') {
        if line.trim_end_matches('\n').is_empty() {
            out.push_str(line);
            continue;
        }
        out.push_str(&pad);
        out.push_str(line);
    }
    out
}

/// What one member's block holds.
enum Placed<'a> {
    /// The artifact's own envelope and statements, as the recovery layer wrote them.
    Block(Artifact<'a>),
    /// A produced artifact whose shape this presentation does not recognize: quoted line by line.
    Quoted(&'a str),
    /// No artifact at all: the marker is the whole body.
    Without,
}

/// One member written as a declaration and a block, at one level of indentation.
fn block_member(declaration: &str, placed: Placed<'_>, markers: &[String]) -> String {
    let mut out = format!("    {declaration} {{\n");
    for marker in markers {
        out.push_str(&indent(&format!("{marker}\n"), 2));
    }
    match placed {
        Placed::Without => {}
        Placed::Block(artifact) => {
            // The envelope is written one level in from the class body (it stood outside the
            // artifact's braces, and this presentation writes it inside them), and the statements
            // keep the one level of indentation their own block gave them: both land at the same
            // depth, one level below the declaration above them.
            out.push_str(&indent(artifact.envelope, 2));
            out.push_str(&indent(artifact.statements, 1));
        }
        Placed::Quoted(text) => out.push_str(&indent(&quote(text), 2)),
    }
    out.push_str("    }\n");
    out
}

/// Exact byte length of one already-known block rendering, used to reserve output budget before
/// allocating the projection text.
fn indented_text_bytes(text: &str, depth: usize) -> u64 {
    let pad = u64::try_from(depth.saturating_mul(4)).unwrap_or(u64::MAX);
    text.split_inclusive('\n').fold(0u64, |total, line| {
        let line_bytes = u64::try_from(line.len()).unwrap_or(u64::MAX);
        let indentation = if line.trim_end_matches('\n').is_empty() {
            0
        } else {
            pad
        };
        total.saturating_add(line_bytes).saturating_add(indentation)
    })
}

fn block_member_text_bytes(
    declaration: &str,
    envelope: &str,
    statements: &str,
    markers: &[String],
    annotations: &MemberAnnotationUses,
) -> u64 {
    let marker_bytes = markers.iter().fold(0u64, |total, marker| {
        total
            .saturating_add(indented_text_bytes(marker, 2))
            .saturating_add(1)
    });
    let annotation_bytes = annotations.uses.iter().fold(0u64, |total, annotation| {
        total
            .saturating_add(4)
            .saturating_add(u64::try_from(annotation.len()).unwrap_or(u64::MAX))
            .saturating_add(1)
    });
    4u64.saturating_add(u64::try_from(declaration.len()).unwrap_or(u64::MAX))
        .saturating_add(3) // ` {\n`
        .saturating_add(marker_bytes)
        .saturating_add(indented_text_bytes(envelope, 2))
        .saturating_add(indented_text_bytes(statements, 1))
        .saturating_add(6) // `    }\n`
        .saturating_add(annotation_bytes)
}

fn declaration_member_text_bytes(
    declaration: &str,
    markers: &[String],
    annotations: &MemberAnnotationUses,
) -> u64 {
    let marker_bytes = markers.iter().fold(0u64, |total, marker| {
        total
            .saturating_add(indented_text_bytes(marker, 1))
            .saturating_add(1)
    });
    let annotation_bytes = annotations.uses.iter().fold(0u64, |total, annotation| {
        total
            .saturating_add(4)
            .saturating_add(u64::try_from(annotation.len()).unwrap_or(u64::MAX))
            .saturating_add(1)
    });
    marker_bytes
        .saturating_add(4)
        .saturating_add(u64::try_from(declaration.len()).unwrap_or(u64::MAX))
        .saturating_add(2) // `;\n`
        .saturating_add(annotation_bytes)
}

/// One member written as a declaration and a `;`, which is how Java spells a member that declares no
/// body at all.
fn declaration_member(declaration: &str, markers: &[String]) -> String {
    let mut out = String::new();
    for marker in markers {
        out.push_str(&indent(&format!("{marker}\n"), 1));
    }
    out.push_str(&format!("    {declaration};\n"));
    out
}

/// One field's written form with a projection's own declaration: the same markers the physical
/// member carries, beside the re-spelled declaration a static member fold states.
pub(crate) fn field_member_text(field: &ClassSourceField, declaration: &str) -> String {
    declaration_member(declaration, &field.markers)
}

/// One member written as its markers alone: nothing else about it can be spelled.
fn comment_member(markers: &[String]) -> String {
    let mut out = String::new();
    for marker in markers {
        out.push_str(&indent(&format!("{marker}\n"), 1));
    }
    out
}

/// The stable code of one execution plane's stop, or `None` when the plane is `Complete`.
fn stop_code(execution: &ExecutionReport) -> Option<String> {
    match execution {
        ExecutionReport::Complete { .. } => None,
        ExecutionReport::Partial { reason, .. } | ExecutionReport::Failed { reason, .. } => {
            Some(match reason {
                TerminationReason::BudgetExceeded { dimension } => {
                    format!("budget_exceeded_{}", budget_dimension_code(*dimension))
                }
                TerminationReason::Error { code } | TerminationReason::Unsupported { code } => {
                    code.clone()
                }
            })
        }
        ExecutionReport::Cancelled { .. } => Some("cancelled".to_owned()),
    }
}

/// The markers one recovered member carries, in the order the text writes them.
///
/// The order is the member's own spelling first, then its body's: a name Java cannot spell is a fact
/// about the declaration, and a body that was not recovered is a fact about the block below it.
fn recovered_markers(
    item: &MethodItem,
    spelled: &Spelled,
    report: &RecoveryReport,
    analysis: &ClassSourceRunFacts,
) -> Vec<String> {
    let mut markers = markers_of(spelled);
    markers.extend(run_markers(item, report, analysis));
    markers
}

/// The markers one run's own verdict adds over a spelling: the run's content verdict, and what
/// stopped either of its planes. [`recovered_markers`] writes them after the spelling's own
/// markers; [`ClassSourceMethod::with_rerun_body`] writes them over a body a rerun replaced.
fn run_markers(
    item: &MethodItem,
    report: &RecoveryReport,
    analysis: &ClassSourceRunFacts,
) -> Vec<String> {
    let member = label(item);
    // A run **stopped** before it had an artifact: the artifact is absent, and the marker says which
    // plane of the run ended it. The recovery's *outcome* is what decides this, not the execution
    // plane alone: a run whose evidence phase stopped after the artifact was committed is a produced
    // member with a non-`Complete` execution, and it is marked as such below
    // (`add-demand-driven-core-results`, D1).
    if report.stop().is_some() {
        let stop = stop_code(&report.execution).unwrap_or_else(|| "unstated".to_owned());
        // Two planes can state a stop of the same run, and they can name different causes: the
        // analysis stops first (a refused charge, a damaged body) and the recovery layer then stops
        // on the table that run never published. Both are written, because "the artifact was not
        // produced" and "what stopped the run that would have produced it" are different answers.
        let blamed = match stop_code(&analysis.execution) {
            Some(analysis) => {
                format!("; the analysis of that member did not complete ({analysis})")
            }
            None => String::new(),
        };
        return vec![format!(
            "// jarde: not recovered: the recovery run for `{member}` stopped ({stop}){blamed}"
        )];
    }
    let mut markers = Vec::new();
    match report.content {
        RecoveryContent::ContainsStatements => {}
        RecoveryContent::ExplanationOnly => {
            markers.push(format!(
                "// jarde: not recovered: the recovery run for `{member}` produced no statement (explanation only); the artifact's own comment lines are below"
            ));
            return markers;
        }
        RecoveryContent::NotProduced => {
            markers.push(format!(
                "// jarde: not recovered: the recovery run for `{member}` states that it produced no artifact content; the lines below are what it wrote"
            ));
            return markers;
        }
    }
    if let Some(code) = stop_code(&analysis.execution) {
        markers.push(format!(
            "// jarde: diagnosed stop: the run for `{member}` did not complete ({code}); the text below is what that run produced"
        ));
    }
    if let Some(stop) = stop_code(&report.execution) {
        // The artifact is here and the run is not `Complete`: what stopped is the optional evidence
        // this request selected, and saying so is different from saying the member was not recovered.
        markers.push(format!(
            "// jarde: evidence stopped: the run for `{member}` produced the text below; the evidence it selected stopped ({stop})"
        ));
    }
    markers
}

// ---------------------------------------------------------------------------------------------
// The members, as this presentation builds them
// ---------------------------------------------------------------------------------------------

/// Which class-header position one parent definition is proved for: the two positions
/// [`ClassSourceDeclaration::project_generic_signature`] asks the selected environment about.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum ClassHeaderParentPosition {
    /// The direct superclass the relaxed direct-parent path projects (`extends Parent<String>`,
    /// whose parent name is the class file's own binary name).
    DirectSuperclass,
    /// One interface entry the class `Signature` spells with type arguments.
    Interface,
}

/// What one class-header parent's definition in the selected environment states about the
/// class's own `Signature` claim.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum ClassHeaderParentProof {
    /// The definition proves the claim this position makes: one single-parameter class parent,
    /// or one interface declaring exactly the number of type parameters the `Signature` spells
    /// as arguments.
    Proved,
    /// The selected environment does not provide the definition. The entry then keeps its
    /// physical spelling: an absent definition is not a claim the class file contradicts.
    Unresolved,
    /// The definition resolves and contradicts the claim — another kind, another arity, a
    /// header this read cannot state. The projection refuses rather than spelling a header from
    /// a contradicted claim.
    Contradicted,
}

impl ClassSourceDeclaration {
    /// The declaration of one class-level item, as this presentation spells it: the simple name
    /// `this_class` states, and the declaration line the kind and the flags state.
    pub(crate) fn of(item: ClassDeclarationItem) -> Self {
        let name = simple_name(&item.declaration.this_class.raw().0);
        let declaration = class_declaration(&name, &item.declaration);
        Self {
            item,
            name,
            declaration,
            annotation_attributes: Vec::new(),
            annotation_uses: Vec::new(),
            annotation_refusals: Vec::new(),
            generic_signature: None,
            generic_refusal: None,
            generic_type_parameters: None,
            generic_scope: None,
            header_interface_arguments: Vec::new(),
        }
    }

    /// Project the class's own Signature only after its parent identities and variable erasures
    /// agree with the physical header — and, for a `$`-nested name, after its own
    /// `InnerClasses` self row proves the member position (the fold's row criteria). The
    /// returned scope is handed to member signatures only when the complete class header was
    /// published.
    pub(crate) fn project_generic_signature(
        &mut self,
        bytes: &[u8],
        shells: &[AttributeShell],
        pool: &[CpEntryFacts],
        nesting: &ClassSourceAssemblyContext,
        budget: &mut Budget,
        mut prove_header_parent: impl FnMut(
            ClassHeaderParentPosition,
            &[u8],
            usize,
            &mut Budget,
        ) -> Result<ClassHeaderParentProof>,
    ) -> Result<Option<ClassSignatureErasureProof>> {
        let signatures: Vec<_> = shells
            .iter()
            .filter(|shell| shell.name.raw().0 == b"Signature")
            .cloned()
            .collect();
        if signatures.is_empty() {
            return Ok(None);
        }
        let result = (|| -> Result<Option<(String, ClassSignatureErasureProof, Vec<Vec<u8>>)>> {
            let raw = attribute_facts(bytes, &signatures, pool, budget)?
                .signature
                .ok_or_else(|| {
                    Error::invalid_input(
                        "jvm_signature_missing",
                        "class Signature attribute did not resolve",
                    )
                })?;
            let parsed = parse_class_signature(&raw.0, budget)?;
            let parameterized_superclass = parsed.type_parameters.is_empty()
                && parsed
                    .superclass
                    .segments
                    .iter()
                    .any(|segment| !segment.arguments.is_empty());
            let parameterized_interfaces = parsed.interfaces.iter().any(|interface| {
                interface
                    .segments
                    .iter()
                    .any(|segment| !segment.arguments.is_empty())
            });
            let direct_parent_candidate = parsed.type_parameters.is_empty()
                && matches!(parsed.superclass.segments.as_slice(), [segment]
                    if matches!(segment.arguments.as_slice(), [TypeArgument::Exact(SignatureType::Class(class))]
                        if matches!(class.segments.as_slice(), [string]
                            if string.binary_name == b"java/lang/String" && string.arguments.is_empty())));
            // The interface-only shape: no type parameters of its own and no parameterized
            // superclass, so the one generic position the class `Signature` states is an
            // `implements` entry. It is the fourth path below, and it also decides what the
            // shared gates mean for this class: they ask about the class's **own** header
            // position, and a class that entered the projection only through an interface keeps
            // the raw header they would refuse — the `Ok(None)` this shape returned before an
            // interface entry could enter the projection at all.
            let interface_only = parsed.type_parameters.is_empty()
                && !parameterized_superclass
                && parameterized_interfaces;
            if parsed.type_parameters.is_empty()
                && !parameterized_superclass
                && !parameterized_interfaces
            {
                return Ok(None);
            }
            self.generic_signature = Some(raw.clone());
            let facts = &self.item.declaration;
            let own_header_gate = |error: Error| -> Result<
                Option<(String, ClassSignatureErasureProof, Vec<Vec<u8>>)>,
            > {
                if interface_only { Ok(None) } else { Err(error) }
            };
            if facts.access_flags & (ACC_ANNOTATION | ACC_ENUM) != 0
                || !is_java_identifier(&self.name)
                || shells.iter().any(|shell| {
                    matches!(
                        shell.name.raw().0.as_slice(),
                        b"RuntimeVisibleTypeAnnotations" | b"RuntimeInvisibleTypeAnnotations"
                    )
                })
            {
                return own_header_gate(Error::unsupported(
                    "class_generic_source_unproved",
                    "class kind, nesting, name, or type-use annotations lack a faithful generic header position",
                ));
            }
            // A `$` in the class's own name states a nesting claim the header cannot spell on
            // its own: only the class's own InnerClasses self row proves the member position
            // (the same row criteria the member fold requires of a child). The refusal keeps
            // the chain head's exact code and message, so a row that does not join, a local or
            // anonymous shape, or a synthetic `$`-spelled top-level class stays blocked.
            if self.name.contains('$')
                && !crate::member_inner::prove_nested_member_position(
                    &facts.this_class.raw().0,
                    facts.access_flags,
                    nesting,
                    budget,
                )?
            {
                return own_header_gate(Error::unsupported(
                    "class_generic_source_unproved",
                    "class kind, nesting, name, or type-use annotations lack a faithful generic header position",
                ));
            }
            let physical_super = match facts.super_class.as_ref() {
                Some(physical_super) => physical_super,
                None => {
                    return own_header_gate(Error::unsupported(
                        "class_generic_source_unproved",
                        "physical superclass is absent",
                    ));
                }
            };
            if facts.access_flags & ACC_INTERFACE != 0
                && physical_super.raw().0 != b"java/lang/Object"
            {
                return own_header_gate(Error::unsupported(
                    "class_generic_source_unproved",
                    "interface physical superclass is not java/lang/Object",
                ));
            }
            let physical_interfaces: Vec<Vec<u8>> = facts
                .interfaces
                .iter()
                .map(|name| name.raw().0.clone())
                .collect();
            let proof = prove_class_signature_erasure(
                &parsed,
                &physical_super.raw().0,
                &physical_interfaces,
                budget,
            )?;
            let mut header_interface_arguments: Vec<Vec<u8>> = Vec::new();
            let mut projected_interfaces: Option<Vec<String>> = None;
            if direct_parent_candidate {
                if !parsed.interfaces.is_empty() || !physical_interfaces.is_empty() {
                    return Err(Error::unsupported(
                        "class_generic_source_unproved",
                        "direct parameterized superclass projection does not include interfaces",
                    ));
                }
                let [parent] = parsed.superclass.segments.as_slice() else {
                    unreachable!("direct parent candidate has exactly one segment")
                };
                // The name proved here is the class file's own binary name (`$` kept): the raw
                // header already spells every parent that way, so the projected entry adds the
                // type arguments and changes no name.
                match prove_header_parent(
                    ClassHeaderParentPosition::DirectSuperclass,
                    &parent.binary_name,
                    parent.arguments.len(),
                    budget,
                )? {
                    ClassHeaderParentProof::Proved => {}
                    ClassHeaderParentProof::Unresolved | ClassHeaderParentProof::Contradicted => {
                        return Err(Error::unsupported(
                            "class_generic_source_unproved",
                            "direct superclass does not resolve to one proved single-parameter parent definition",
                        ));
                    }
                }
            } else if parameterized_superclass {
                return Err(Error::unsupported(
                    "class_generic_source_unproved",
                    "only a single direct Parent<String> superclass is supported for a class without type parameters",
                ));
            } else if !matches!(parsed.superclass.segments.as_slice(), [segment] if segment.arguments.is_empty()) {
                // A superclass path the header cannot spell from the `Signature` (a nested
                // binary path with no arguments of its own). Every shape whose own type
                // parameters or superclass entered the projection refuses here, exactly as
                // before; the interface-only shape keeps the physical header, which is the
                // whole projection its raw entries would spell anyway.
                return own_header_gate(Error::unsupported(
                    "class_generic_source_unproved",
                    "parameterized or nested parent needs a separate inherited-member proof",
                ));
            } else if interface_only {
                // Each interface entry is spelled with its type arguments only when the selected
                // environment's definition proves the arity the class `Signature` states (and
                // then exactly the entries whose header carries arguments are recorded for the
                // bridge admission). Every other entry keeps the physical spelling the raw
                // header states, so a class this path cannot prove is byte-identical to the
                // header it had before the path existed.
                let mut header_interfaces = Vec::with_capacity(parsed.interfaces.len());
                for (interface, physical) in parsed.interfaces.iter().zip(&physical_interfaces) {
                    match interface.segments.as_slice() {
                        [segment] if !segment.arguments.is_empty() => {
                            match prove_header_parent(
                                ClassHeaderParentPosition::Interface,
                                &segment.binary_name,
                                segment.arguments.len(),
                                budget,
                            )? {
                                ClassHeaderParentProof::Proved => {
                                    header_interfaces.push(spell_class_header_signature_type(
                                        &SignatureType::Class(interface.clone()),
                                        &proof.type_parameters,
                                        budget,
                                        0,
                                    )?);
                                    header_interface_arguments.push(physical.clone());
                                }
                                ClassHeaderParentProof::Unresolved => {
                                    header_interfaces.push(class_name(physical));
                                }
                                ClassHeaderParentProof::Contradicted => {
                                    return Err(Error::unsupported(
                                        "class_generic_source_unproved",
                                        "an interface definition contradicts the class Signature's type arguments",
                                    ));
                                }
                            }
                        }
                        _ => header_interfaces.push(class_name(physical)),
                    }
                }
                if header_interface_arguments.is_empty() {
                    // No entry carried its arguments, so this path publishes nothing: the class
                    // keeps the physical declaration it had, with no projection claim and no
                    // note. (An interface-only class whose definitions are all absent is the
                    // whole pre-change state of every such class.)
                    return Ok(None);
                }
                projected_interfaces = Some(header_interfaces);
            } else if parsed.interfaces.iter().any(|interface| {
                !matches!(interface.segments.as_slice(), [segment] if segment.arguments.is_empty())
            }) {
                return Err(Error::unsupported(
                    "class_generic_source_unproved",
                    "parameterized or nested parent needs a separate inherited-member proof",
                ));
            }
            let mut parameters = Vec::with_capacity(parsed.type_parameters.len());
            for parameter in &parsed.type_parameters {
                let name = std::str::from_utf8(&parameter.name).map_err(|_| {
                    Error::unsupported(
                        "class_generic_source_unproved",
                        "type variable name is not source UTF-8",
                    )
                })?;
                if !is_java_identifier(name) {
                    return Err(Error::unsupported(
                        "class_generic_source_unproved",
                        "type variable name is not a Java identifier",
                    ));
                }
                let mut bounds = Vec::new();
                for bound in parameter
                    .class_bound
                    .iter()
                    .chain(&parameter.interface_bounds)
                {
                    if !matches!(
                        bound,
                        SignatureType::Class(_) | SignatureType::TypeVariable(_)
                    ) {
                        return Err(Error::unsupported(
                            "class_generic_source_unproved",
                            "type-variable bound is not a Java class or type variable",
                        ));
                    }
                    bounds.push(spell_ordinary_signature_type(
                        bound,
                        &proof.type_parameters,
                        budget,
                        0,
                    )?);
                }
                let omit_object = bounds.len() == 1
                    && bounds[0] == "java.lang.Object"
                    && parameter.interface_bounds.is_empty();
                parameters.push(if bounds.is_empty() || omit_object {
                    name.to_owned()
                } else {
                    format!("{name} extends {}", bounds.join(" & "))
                });
            }
            let (superclass, interfaces) = match projected_interfaces {
                // The interface-only path spelled every entry itself: a projected entry keeps
                // its type arguments, every other entry keeps the physical name — and the bare
                // superclass keeps the physical name too, exactly the raw header's own spelling.
                Some(interfaces) => (class_name(&physical_super.raw().0), interfaces),
                None => {
                    // The relaxed direct-parent path publishes a superclass whose binary name
                    // may carry `$` (the raw header's own spelling); every other shape keeps
                    // the member/annotation spelling, which a `$` name without a selected
                    // source path has none of.
                    let superclass = if direct_parent_candidate {
                        spell_class_header_signature_type(
                            &SignatureType::Class(parsed.superclass),
                            &proof.type_parameters,
                            budget,
                            0,
                        )?
                    } else {
                        spell_ordinary_signature_type(
                            &SignatureType::Class(parsed.superclass),
                            &proof.type_parameters,
                            budget,
                            0,
                        )?
                    };
                    let mut interfaces = Vec::with_capacity(parsed.interfaces.len());
                    for interface in parsed.interfaces {
                        interfaces.push(spell_ordinary_signature_type(
                            &SignatureType::Class(interface),
                            &proof.type_parameters,
                            budget,
                            0,
                        )?);
                    }
                    (superclass, interfaces)
                }
            };
            let type_parameters = (!parameters.is_empty()).then(|| parameters.join(", "));
            let declaration = class_declaration_with_types(
                &self.name,
                facts,
                type_parameters.as_deref(),
                Some(&superclass),
                Some(&interfaces),
            );
            budget.charge(
                CountedBudgetDimension::OutputBytes,
                u64::try_from(declaration.len()).unwrap_or(u64::MAX),
            )?;
            // Recorded only past the last fallible step of the closure, so a stop never
            // leaves a carried header beside a refusal.
            self.generic_type_parameters = type_parameters;
            Ok(Some((declaration, proof, header_interface_arguments)))
        })();
        match result {
            Ok(Some((declaration, proof, header_interface_arguments))) => {
                self.declaration = declaration;
                self.generic_scope = Some(proof.clone());
                self.header_interface_arguments = header_interface_arguments;
                Ok(Some(proof))
            }
            Ok(None) => {
                // Nothing was published, so no entry may claim a header that carries type
                // arguments: the assignment above only carries the raw attribute for the paths
                // below it, and a gate that answered `Ok(None)` (the total gate, or an
                // interface-only class whose own header gates did not pass) leaves the physical
                // declaration exactly as it was.
                self.generic_signature = None;
                self.header_interface_arguments = Vec::new();
                Ok(None)
            }
            Err(error @ (Error::BudgetExceeded { .. } | Error::Cancelled { .. })) => {
                self.generic_refusal = Some(format!("projection stopped: {error}"));
                self.header_interface_arguments = Vec::new();
                Err(error)
            }
            Err(error) => {
                self.generic_refusal = Some(error.to_string());
                self.header_interface_arguments = Vec::new();
                Ok(None)
            }
        }
    }

    pub(crate) fn with_annotations(
        mut self,
        attributes: Vec<ClassAnnotationAttribute>,
        pool: &[CpEntryFacts],
    ) -> Self {
        let mut counts = std::collections::BTreeMap::<Vec<u8>, usize>::new();
        for attribute in &attributes {
            for annotation in &attribute.annotations {
                if let ElementValueFacts::Annotation {
                    type_descriptor, ..
                } = annotation
                {
                    *counts.entry(type_descriptor.0.clone()).or_default() += 1;
                }
            }
        }
        for attribute in &attributes {
            for annotation in &attribute.annotations {
                match spell_class_annotation(annotation, pool, &counts) {
                    Ok(spelling) => self.annotation_uses.push(spelling),
                    Err(reason) => self.annotation_refusals.push(reason),
                }
            }
        }
        self.annotation_attributes = attributes;
        self
    }
}

/// The narrow Java 8 package-info certificate consumed by the class-source writer. This is a
/// source projection over the selected read's facts; it does not parse or infer classfile data.
pub(crate) fn proved_package_info_source(
    declaration: &ClassSourceDeclaration,
    facts: &ClassMemberFacts,
    class_version: (u16, u16),
    structure_complete: bool,
    execution: &ExecutionReport,
) -> std::result::Result<String, &'static str> {
    let raw_name = &facts.this_class.raw().0;
    let Some(package_bytes) = raw_name.strip_suffix(b"/package-info") else {
        return Err("internal name is not a package path ending in package-info");
    };
    if !legal_package_name(package_bytes) {
        return Err("package path is not a legal non-empty Java package name");
    }
    if class_version != (52, 0) || facts.access_flags != 0x1600 {
        return Err(
            "classfile version or access flags are not the standard Java 8 package-info shape",
        );
    }
    if facts
        .super_class
        .as_ref()
        .map(|name| name.raw().0.as_slice())
        != Some(b"java/lang/Object".as_slice())
        || !facts.interfaces.is_empty()
        || facts.field_count != 0
        || facts.method_count != 0
        || facts.stopped_at.is_some()
        || !structure_complete
    {
        return Err("class head or empty member tables are not completely proved");
    }
    if !matches!(execution, ExecutionReport::Complete { .. }) {
        return Err("class-source execution did not complete");
    }
    if facts.attributes.len() != 1
        || facts.attributes[0].name.raw().0 != b"RuntimeVisibleAnnotations"
        || declaration.annotation_attributes.len() != 1
        || declaration.annotation_attributes[0].attribute.name.raw().0
            != b"RuntimeVisibleAnnotations"
        || !declaration.annotation_refusals.is_empty()
    {
        return Err("only one complete RuntimeVisibleAnnotations attribute is supported");
    }
    let annotation_count = declaration
        .annotation_attributes
        .iter()
        .map(|attribute| attribute.annotations.len())
        .sum::<usize>();
    if annotation_count != 1 || annotation_count != declaration.annotation_uses.len() {
        return Err("exactly one complete writable package annotation is required");
    }
    if !matches!(
        &declaration.annotation_attributes[0].annotations[0],
        ElementValueFacts::Annotation { type_descriptor, elements }
            if type_descriptor.0 == b"Ljava/lang/Deprecated;" && elements.is_empty()
    ) {
        return Err("the only supported package annotation is empty java.lang.Deprecated");
    }
    let package = String::from_utf8(package_bytes.to_vec())
        .map_err(|_| "package path is not valid UTF-8")?
        .replace('/', ".");
    let mut text = String::new();
    for annotation in &declaration.annotation_uses {
        text.push_str(annotation);
        text.push('\n');
    }
    text.push_str(&format!("package {package};\n"));
    Ok(text)
}

fn legal_package_name(raw: &[u8]) -> bool {
    let Ok(package) = std::str::from_utf8(raw) else {
        return false;
    };
    !package.is_empty()
        && package
            .split('/')
            .all(|segment| !segment.is_empty() && is_java_identifier(segment))
}

fn spell_class_annotation(
    annotation: &ElementValueFacts,
    pool: &[CpEntryFacts],
    counts: &std::collections::BTreeMap<Vec<u8>, usize>,
) -> std::result::Result<String, String> {
    let ElementValueFacts::Annotation {
        type_descriptor, ..
    } = annotation
    else {
        return Err("class annotation entry is not an annotation fact".to_owned());
    };
    if counts.get(&type_descriptor.0).copied().unwrap_or(0) > 1 {
        return Err(format!(
            "duplicate annotation type `{}` is conservatively refused",
            String::from_utf8_lossy(&type_descriptor.0)
        ));
    }
    spell_annotation_body(annotation, pool)
}

fn spell_annotation_body(
    annotation: &ElementValueFacts,
    pool: &[CpEntryFacts],
) -> std::result::Result<String, String> {
    let ElementValueFacts::Annotation {
        type_descriptor,
        elements,
    } = annotation
    else {
        return Err("annotation entry is not an annotation fact".to_owned());
    };
    let Some(type_name) = annotation_type_name(&type_descriptor.0) else {
        return Err(format!(
            "annotation type `{}` is not a Java source name",
            String::from_utf8_lossy(&type_descriptor.0)
        ));
    };
    let Some(elements) = elements
        .iter()
        .map(|element| {
            let name = String::from_utf8(element.name.0.clone()).ok()?;
            is_java_identifier(&name).then_some(())?;
            Some((name, resolve_default(&element.value, pool)?))
        })
        .collect::<Option<Vec<_>>>()
    else {
        return Err(format!(
            "annotation `@{type_name}` has an element with no faithful Java spelling"
        ));
    };
    if elements.is_empty() {
        Ok(format!("@{type_name}"))
    } else {
        let elements = elements
            .iter()
            .map(|(name, value)| format!("{name} = {}", value.spelling()))
            .collect::<Vec<_>>()
            .join(", ");
        Ok(format!("@{type_name}({elements})"))
    }
}

#[derive(Clone, Copy)]
enum TypeUseOwner {
    Field,
    Method,
}

fn spell_type_annotation_uses(
    mut uses: TypeAnnotationUses,
    owner: TypeUseOwner,
    descriptor: &[u8],
    pool: &[CpEntryFacts],
    declarations: &MemberAnnotationUses,
    parameter_declarations: Option<&ParameterAnnotationUses>,
    parameter_count: Option<usize>,
) -> TypeAnnotationUses {
    uses.parameter_uses = vec![Vec::new(); parameter_count.unwrap_or_default()];
    let declaration_types = declarations
        .attributes
        .iter()
        .flat_map(|attribute| {
            attribute
                .annotations
                .iter()
                .filter_map(|annotation| match annotation {
                    ElementValueFacts::Annotation {
                        type_descriptor, ..
                    } => Some(type_descriptor.0.clone()),
                    _ => None,
                })
        })
        .collect::<std::collections::BTreeSet<_>>();
    let parameter_declaration_types = parameter_declarations.map(|parameters| {
        let mut by_position =
            vec![std::collections::BTreeSet::<Vec<u8>>::new(); parameter_count.unwrap_or_default()];
        for attribute in &parameters.attributes {
            if attribute.parameter_count.map(usize::from) != parameter_count {
                continue;
            }
            for (position, annotations) in attribute.parameters.iter().enumerate() {
                for annotation in annotations {
                    if let ElementValueFacts::Annotation {
                        type_descriptor, ..
                    } = annotation
                        && let Some(slot) = by_position.get_mut(position)
                    {
                        slot.insert(type_descriptor.0.clone());
                    }
                }
            }
        }
        by_position
    });
    let parameter_declarations_unmapped = parameter_declarations.is_some_and(|parameters| {
        parameters
            .attributes
            .iter()
            .any(|attribute| attribute.parameter_count.map(usize::from) != parameter_count)
    });
    let mut counts = std::collections::BTreeMap::<(u8, Vec<u8>, Vec<u8>), usize>::new();
    for attribute in &uses.attributes {
        for annotation in &attribute.annotations {
            if let ElementValueFacts::Annotation {
                type_descriptor, ..
            } = &annotation.annotation
            {
                *counts
                    .entry((
                        annotation.target_type,
                        annotation.target_info.clone(),
                        type_descriptor.0.clone(),
                    ))
                    .or_default() += 1;
            }
        }
    }
    for attribute in &mut uses.attributes {
        for annotation in &mut attribute.annotations {
            let ElementValueFacts::Annotation {
                type_descriptor, ..
            } = &annotation.annotation
            else {
                annotation.refusal =
                    Some("type annotation entry is not an annotation fact".to_owned());
                continue;
            };
            let position = match (
                owner,
                annotation.target_type,
                annotation.target_info.as_slice(),
            ) {
                (TypeUseOwner::Field, 0x13, []) => None,
                (TypeUseOwner::Method, 0x14, []) => None,
                (TypeUseOwner::Method, 0x16, [position]) => Some(usize::from(*position)),
                (TypeUseOwner::Field, 0x13, _) => {
                    annotation.refusal = Some("FIELD target_info must be empty".to_owned());
                    continue;
                }
                (TypeUseOwner::Method, 0x14, _) => {
                    annotation.refusal = Some("METHOD_RETURN target_info must be empty".to_owned());
                    continue;
                }
                (TypeUseOwner::Method, 0x16, _) => {
                    annotation.refusal = Some(
                        "METHOD_FORMAL_PARAMETER target_info must contain one index byte"
                            .to_owned(),
                    );
                    continue;
                }
                (TypeUseOwner::Field, _, _) => {
                    annotation.refusal =
                        Some("type annotation target does not belong to a field".to_owned());
                    continue;
                }
                (TypeUseOwner::Method, _, _) => {
                    annotation.refusal = Some(
                        "type annotation target is outside the supported method targets".to_owned(),
                    );
                    continue;
                }
            };
            if !annotation.type_path.is_empty() {
                annotation.refusal =
                    Some("non-empty type_path is not source-spellable in this change".to_owned());
                continue;
            }
            if let Some(position) = position
                && parameter_count.is_none_or(|count| position >= count)
            {
                annotation.refusal = Some(format!(
                    "formal parameter position {position} is outside the descriptor parameter count"
                ));
                continue;
            }
            if position.is_some() && parameter_declarations_unmapped {
                annotation.refusal = Some(
                    "parameter declaration annotations do not map to descriptor positions"
                        .to_owned(),
                );
                continue;
            }
            if counts
                .get(&(
                    annotation.target_type,
                    annotation.target_info.clone(),
                    type_descriptor.0.clone(),
                ))
                .copied()
                .unwrap_or(0)
                > 1
            {
                annotation.refusal = Some(
                    "duplicate annotation type at the same target is conservatively refused"
                        .to_owned(),
                );
                continue;
            }
            let declaration_conflict = match position {
                Some(position) => parameter_declaration_types
                    .as_ref()
                    .and_then(|by_position| by_position.get(position))
                    .is_some_and(|types| types.contains(&type_descriptor.0)),
                None => declaration_types.contains(&type_descriptor.0),
            };
            if declaration_conflict {
                annotation.refusal = Some(
                    "same annotation type is present on the declaration and type target".to_owned(),
                );
                continue;
            }
            let Ok(spelling) = spell_annotation_body(&annotation.annotation, pool) else {
                annotation.refusal =
                    Some("annotation value has no faithful Java source spelling".to_owned());
                continue;
            };
            if qualify_type_descriptor(descriptor, owner, position).is_none() {
                annotation.refusal = Some("target type is primitive, array, single-segment, or has ambiguous nested-class spelling".to_owned());
                continue;
            }
            annotation.spelling = Some(spelling.clone());
            match position {
                Some(position) => uses.parameter_uses[position].push(spelling),
                None if matches!(owner, TypeUseOwner::Field) => uses.field_uses.push(spelling),
                None => uses.return_uses.push(spelling),
            }
        }
    }
    for attribute in &uses.attributes {
        for annotation in &attribute.annotations {
            if let Some(reason) = &annotation.refusal {
                uses.refusals.push(format!(
                    "target=0x{:02x} info={:?} path={:?}: {reason}",
                    annotation.target_type, annotation.target_info, annotation.type_path
                ));
            }
        }
    }
    uses
}

fn qualify_type_descriptor(
    descriptor: &[u8],
    owner: TypeUseOwner,
    parameter: Option<usize>,
) -> Option<String> {
    let facts = descriptor_facts(
        descriptor,
        match owner {
            TypeUseOwner::Field => DescriptorKind::Field,
            TypeUseOwner::Method => DescriptorKind::Method,
        },
    )
    .ok()?;
    let component = match owner {
        TypeUseOwner::Field => facts.single()?,
        TypeUseOwner::Method => match parameter {
            Some(position) => facts.parameters().get(position)?,
            None => facts.result()?,
        },
    };
    if component.is_array() || !matches!(component.base(), Base::Object(_)) {
        return None;
    }
    let name = source_type(component)?;
    let (package, simple) = name.rsplit_once('.')?;
    if simple.contains('$') || package.is_empty() {
        return None;
    }
    Some(format!("{package}.@{{annotation}} {simple}"))
}

fn decorate_qualified_type(ty: &str, annotations: &[String]) -> Option<String> {
    let (package, simple) = ty.rsplit_once('.')?;
    if package.is_empty() || simple.contains('$') || ty.contains("[]") {
        return None;
    }
    Some(format!("{package}.{} {simple}", annotations.join(" ")))
}

fn replace_first(text: &str, from: &str, to: &str) -> String {
    text.find(from).map_or_else(
        || text.to_owned(),
        |at| format!("{}{}{}", &text[..at], to, &text[at + from.len()..]),
    )
}

fn spell_member_annotation_uses(
    mut annotations: MemberAnnotationUses,
    pool: &[CpEntryFacts],
) -> MemberAnnotationUses {
    let mut counts = std::collections::BTreeMap::<Vec<u8>, usize>::new();
    for attribute in &annotations.attributes {
        for annotation in &attribute.annotations {
            if let ElementValueFacts::Annotation {
                type_descriptor, ..
            } = annotation
            {
                *counts.entry(type_descriptor.0.clone()).or_default() += 1;
            }
        }
    }
    for attribute in &annotations.attributes {
        for annotation in &attribute.annotations {
            match annotation {
                ElementValueFacts::Annotation {
                    type_descriptor, ..
                } if counts.get(&type_descriptor.0).copied().unwrap_or_default() > 1 => {
                    annotations.refusals.push(format!(
                        "duplicate annotation type `{}` at one member position is conservatively refused",
                        String::from_utf8_lossy(&type_descriptor.0)
                    ));
                }
                _ => match spell_annotation_body(annotation, pool) {
                    Ok(spelling) => annotations.uses.push(spelling),
                    Err(reason) => annotations.refusals.push(reason),
                },
            }
        }
    }
    annotations
}

fn spell_parameter_annotation_uses(
    mut annotations: ParameterAnnotationUses,
    pool: &[CpEntryFacts],
    expected_count: Option<usize>,
) -> ParameterAnnotationUses {
    let Some(expected_count) = expected_count else {
        for attribute in &annotations.attributes {
            if attribute.parameter_count.is_some() {
                annotations.refusals.push(format!(
                    "parameter annotation attribute `{}` has no descriptor positions to attach to",
                    String::from_utf8_lossy(&attribute.attribute.name.raw().0)
                ));
            }
        }
        return annotations;
    };
    annotations.uses_by_position = vec![Vec::new(); expected_count];
    let mut by_position = vec![Vec::<&ElementValueFacts>::new(); expected_count];
    for attribute in &annotations.attributes {
        let Some(parameter_count) = attribute.parameter_count else {
            continue;
        };
        if usize::from(parameter_count) != expected_count
            || attribute.parameters.len() != expected_count
        {
            annotations.refusals.push(format!(
                "parameter annotation attribute `{}` declares {parameter_count} position(s) for a descriptor with {expected_count} parameter(s); its groups are not aligned",
                String::from_utf8_lossy(&attribute.attribute.name.raw().0)
            ));
            continue;
        }
        for (position, group) in attribute.parameters.iter().enumerate() {
            by_position[position].extend(group);
        }
    }
    for (position, entries) in by_position.into_iter().enumerate() {
        let mut counts = std::collections::BTreeMap::<Vec<u8>, usize>::new();
        for annotation in &entries {
            if let ElementValueFacts::Annotation {
                type_descriptor, ..
            } = annotation
            {
                *counts.entry(type_descriptor.0.clone()).or_default() += 1;
            }
        }
        for annotation in entries {
            match annotation {
                ElementValueFacts::Annotation {
                    type_descriptor, ..
                } if counts.get(&type_descriptor.0).copied().unwrap_or_default() > 1 => {
                    annotations.refusals.push(format!(
                        "parameter position {position}: duplicate annotation type `{}` is conservatively refused",
                        String::from_utf8_lossy(&type_descriptor.0)
                    ));
                }
                _ => match spell_annotation_body(annotation, pool) {
                    Ok(spelling) => annotations.uses_by_position[position].push(spelling),
                    Err(reason) => annotations
                        .refusals
                        .push(format!("parameter position {position}: {reason}")),
                },
            }
        }
    }
    annotations
}

fn refuse_uses(annotations: &mut MemberAnnotationUses, reason: &str) {
    for spelling in annotations.uses.drain(..) {
        annotations.refusals.push(format!("{reason}: {spelling}"));
    }
}

fn refuse_parameter_uses(annotations: &mut ParameterAnnotationUses, reason: &str) {
    for (position, uses) in annotations.uses_by_position.iter_mut().enumerate() {
        for spelling in uses.drain(..) {
            annotations.refusals.push(format!(
                "parameter position {position}: {reason}: {spelling}"
            ));
        }
    }
}

impl ClassSourceField {
    /// One field record with the spelling the text writes for it, initializer included when the
    /// field's own `ConstantValue` attribute states one.
    pub(crate) fn of(
        item: FieldItem,
        current_class: Option<&str>,
        nested_class_members: &[String],
        constant: Option<&MemberDefault>,
        annotations: MemberAnnotationFacts,
        pool: &[CpEntryFacts],
    ) -> Self {
        let mut spelled =
            spell_field_declaration(&item, current_class, nested_class_members, constant);
        let mut member_annotations =
            spell_member_annotation_uses(annotations.declaration.clone(), pool);
        let type_annotations = spell_type_annotation_uses(
            annotations.type_uses,
            TypeUseOwner::Field,
            &item.descriptor.raw().0,
            pool,
            &member_annotations,
            None,
            None,
        );
        if let Some(declaration) = &spelled.declaration
            && let (Some(ty), Some(decorated)) = (
                field_type(&item.descriptor.raw().0).map(|ty| {
                    nested_member_reference_spelling(&ty, current_class, Some(nested_class_members))
                        .into_owned()
                }),
                field_type(&item.descriptor.raw().0).and_then(|ty| {
                    decorate_qualified_type(
                        nested_member_reference_spelling(
                            &ty,
                            current_class,
                            Some(nested_class_members),
                        )
                        .as_ref(),
                        &type_annotations.field_uses,
                    )
                }),
            )
            && !type_annotations.field_uses.is_empty()
        {
            spelled.declaration = Some(replace_first(declaration, &ty, &decorated));
        }
        if spelled.declaration.is_none() {
            refuse_uses(
                &mut member_annotations,
                "field descriptor cannot be spelled as a Java declaration",
            );
        }
        spelled.annotations = member_annotations;
        spelled.type_annotations = type_annotations;
        let markers = markers_of(&spelled);
        Self {
            item,
            declaration: spelled.declaration,
            annotations: spelled.annotations,
            type_annotations: spelled.type_annotations,
            markers,
        }
    }
}

impl ClassSourceMethod {
    /// Rebuild the same recovered method envelope around already emitted projected statements.
    pub(crate) fn integer_constant_projection_text(&self, body: &str) -> Option<String> {
        let declaration = self.declaration.as_ref()?;
        let ClassSourceOutcome::Recovered { report, .. } = &self.outcome else {
            return None;
        };
        let original = artifact(&report.text)?;
        if !self.markers.is_empty() {
            return None;
        }
        let staged = Artifact {
            envelope: original.envelope,
            statements: body,
        };
        Some(prefix_method_annotations(
            block_member(declaration, Placed::Block(staged), &self.markers),
            &self.annotations,
        ))
    }

    /// This member's text with its body replaced by the assert projection's staged statements,
    /// keeping the original envelope the recovery wrote and every marker already placed.
    ///
    /// The markers are kept rather than refused (unlike the integer-constant projection): the
    /// assert fold replaces statement text inside the same block, and a marker another
    /// projection placed above the declaration states a fact this replacement does not touch.
    /// A member whose current body is not its own AST's emission is refused by the caller before
    /// this composes anything.
    pub(crate) fn assert_projection_text(&self, body: &str) -> Option<String> {
        let declaration = self.declaration.as_ref()?;
        let ClassSourceOutcome::Recovered { report, .. } = &self.outcome else {
            return None;
        };
        let original = artifact(&report.text)?;
        let staged = Artifact {
            envelope: original.envelope,
            statements: body,
        };
        Some(prefix_method_annotations(
            block_member(declaration, Placed::Block(staged), &self.markers),
            &self.annotations,
        ))
    }
    /// The one physical-recovery marker that may be replaced by a later complete family re-run.
    /// It remains on this physical record; only the separately assembled source text omits it.
    pub(crate) fn has_only_explanation_marker(&self) -> bool {
        let ClassSourceOutcome::Recovered { report, .. } = &self.outcome else {
            return false;
        };
        report.content == RecoveryContent::ExplanationOnly
            && self.markers
                == [format!(
                    "// jarde: not recovered: the recovery run for `{}` produced no statement (explanation only); the artifact's own comment lines are below",
                    label(&self.item)
                )]
    }

    /// Stage the entire declaration, body placement and source note before publishing them.
    pub(crate) fn project_generic(
        &mut self,
        declaration: String,
        signature: &[u8],
        proof: &str,
        budget: &mut Budget,
    ) -> Result<()> {
        let placed = match &self.outcome {
            ClassSourceOutcome::Recovered { report, .. } => {
                let Some(body) = artifact(&report.text) else {
                    return Ok(());
                };
                Placed::Block(body)
            }
            ClassSourceOutcome::NoBody if self.no_body_kind.is_some() => Placed::Without,
            _ => return Ok(()),
        };
        let marker = format!(
            "// jarde: generic Signature `{}` projected after descriptor erasure and {proof}",
            comment_text(&String::from_utf8_lossy(signature)),
        );
        let mut markers = self.markers.clone();
        markers.push(marker);
        let text = prefix_method_annotations(
            match placed {
                Placed::Without => declaration_member(&declaration, &markers),
                body => block_member(&declaration, body, &markers),
            },
            &self.annotations,
        );
        budget.charge(
            CountedBudgetDimension::OutputBytes,
            u64::try_from(text.len()).unwrap_or(u64::MAX),
        )?;
        self.declaration = Some(declaration);
        self.text = text;
        self.markers = markers;
        self.generic_signature_refused = false;
        self.generic_signature_projected = true;
        Ok(())
    }

    /// A typed-only method reference cannot be left under a raw descriptor header if its
    /// class-source Signature transaction failed (including an output-budget stop). Retain the
    /// physical report for inspection, but publish only an explicit incomplete-source marker.
    pub(crate) fn withhold_unprojected_functional_body(&mut self) {
        if self.generic_signature_projected {
            return;
        }
        let marker = format!(
            "// jarde: typed functional source for `{}` withheld because its generic declaration was not projected",
            label(&self.item),
        );
        self.markers.push(marker);
        self.text = comment_member(&self.markers);
    }

    /// The complete-source explanation for this bridge's original physical identity, call BCI and
    /// retained source-level target.
    pub(crate) fn bridge_projection_marker(&self, target: &Self, call_bci: u32) -> String {
        format!(
            "// jarde: projected bridge `{}` at physical method record {}: bridge@1 proved a pure call at BCI {} to source declaration `{}` at method record {}; the resolved erased contract lets javac regenerate the bridge",
            label(&self.item),
            self.item.index,
            call_bci,
            label(&target.item),
            target.item.index,
        )
    }

    /// Replaces this member's complete Java declaration with the supplied proof marker while
    /// retaining its physical declaration and original recovery outcome for the report.
    pub(crate) fn project_bridge(&mut self, marker: String) {
        self.markers.push(marker);
        self.text = comment_member(&self.markers);
    }

    /// Atomically replaces only the rendered body with a re-emission of the same-run AST.
    /// Atomically replaces the rendered body once and appends all markers proved for that body.
    pub(crate) fn project_enum_switch_group(
        &mut self,
        recovery_text: &str,
        markers_to_add: Vec<String>,
    ) -> bool {
        let Some(declaration) = self.declaration.as_ref() else {
            return false;
        };
        let Some(artifact) = artifact(recovery_text) else {
            return false;
        };
        let mut markers = self.markers.clone();
        markers.extend(markers_to_add);
        let text = block_member(declaration, Placed::Block(artifact), &markers);
        self.text = prefix_method_annotations(text, &self.annotations);
        self.markers = markers;
        true
    }

    pub(crate) fn array_projection_text(
        &self,
        recovery_text: &str,
        marker: String,
    ) -> Option<String> {
        let declaration = self.declaration.as_ref()?;
        let artifact = artifact(recovery_text)?;
        let mut markers = self.markers.clone();
        markers.push(marker);
        Some(prefix_method_annotations(
            block_member(declaration, Placed::Block(artifact), &markers),
            &self.annotations,
        ))
    }

    /// This member's text re-emitted from a projection's own body, with one marker per projected
    /// site inside the block. Same shape as [`Self::array_projection_text`], for the member-level
    /// lambda-site rewrites that carry several markers at once.
    pub(crate) fn lambda_projection_text(
        &self,
        recovery_text: &str,
        markers: &[String],
    ) -> Option<String> {
        let declaration = self.declaration.as_ref()?;
        let artifact = artifact(recovery_text)?;
        let mut all = self.markers.clone();
        all.extend(markers.iter().cloned());
        Some(prefix_method_annotations(
            block_member(declaration, Placed::Block(artifact), &all),
            &self.annotations,
        ))
    }

    /// Whether a fresh emission of this member's own same-run AST is still exactly the body this
    /// member shows — the safety check a projection that re-emits the whole body makes before it
    /// replaces anything. The comparison is the block's own region, line by line without
    /// indentation, so a marker written beside the declaration does not fail it, while a body
    /// another projection already rewrote does. Such a member keeps its physical presentation.
    pub(crate) fn matches_current_text(&self, recovery_text: &str) -> bool {
        let Some(declaration) = self.declaration.as_deref() else {
            return false;
        };
        let Some(artifact) = artifact(recovery_text) else {
            return false;
        };
        let Some(region) = self.current_body_region(declaration) else {
            return false;
        };
        let expected: Vec<&str> = artifact
            .envelope
            .lines()
            .chain(artifact.statements.lines())
            .map(str::trim)
            .filter(|line| !line.is_empty())
            .collect();
        expected == region
    }

    /// The trimmed lines between this member's declaration line and its closing brace: the body
    /// the current text actually shows.
    fn current_body_region(&self, declaration: &str) -> Option<Vec<&str>> {
        let opening = format!("    {declaration} {{");
        let mut opening_at = None;
        let mut closing_at = None;
        for (index, line) in self.text.lines().enumerate() {
            if line == opening && opening_at.is_none() {
                opening_at = Some(index);
            }
            if line == "    }" {
                closing_at = Some(index);
            }
        }
        let opening = opening_at?;
        let closing = closing_at.filter(|closing| *closing > opening)?;
        Some(
            self.text
                .lines()
                .skip(opening + 1)
                .take(closing - opening - 1)
                .map(str::trim)
                .filter(|line| !line.is_empty())
                .collect(),
        )
    }

    /// This member's declaration with the companion's method name replaced by its renamed,
    /// non-conflicting spelling. `None` unless the name occurs exactly once in the declaration —
    /// the rename is surgical or it is not made at all.
    pub(crate) fn renamed_declaration(&self, old: &str, new: &str) -> Option<String> {
        let declaration = self.declaration.as_deref()?;
        let from = format!(" {old}(");
        let to = format!(" {new}(");
        if declaration.matches(&from).count() != 1 {
            return None;
        }
        Some(declaration.replacen(&from, &to, 1))
    }

    /// This member's complete text with a renamed declaration and the rename's own marker inside
    /// the body block, stating the physical name the class file still declares. The rename is
    /// composed on `base` — the member's current text, or a staged body projection of it.
    pub(crate) fn lambda_rename_text(
        &self,
        renamed_declaration: &str,
        marker: &str,
        base: Option<&str>,
    ) -> Option<String> {
        let declaration = self.declaration.as_deref()?;
        let original_line = format!("    {declaration} {{\n");
        let renamed_line = format!("    {renamed_declaration} {{\n");
        let text = base.unwrap_or(&self.text);
        if text.matches(&original_line).count() != 1 {
            return None;
        }
        let mut text = text.replacen(&original_line, &renamed_line, 1);
        let marker_line = indent(&format!("{marker}\n"), 2);
        text.insert_str(renamed_line.len(), &marker_line);
        Some(text)
    }

    /// Places one projected body inside this member's declaration and markers — the exact
    /// composition [`Self::lambda_projection_text`] performs, with the one extension a member
    /// fold needs: the declaration line may be the fold's own re-spelled spelling. The markers
    /// are this member's own followed by the projection's added lines, in the first pass's own
    /// order, so a projected body placed here lands byte-for-byte where the first pass put it.
    pub(crate) fn projected_body_method_text(
        &self,
        body: &str,
        declaration_override: Option<&str>,
        extra_markers: &[String],
    ) -> Option<String> {
        let declaration = declaration_override.unwrap_or(self.declaration.as_ref()?);
        let artifact = artifact(body)?;
        let mut all = self.markers.clone();
        all.extend(extra_markers.iter().cloned());
        Some(prefix_method_annotations(
            block_member(declaration, Placed::Block(artifact), &all),
            &self.annotations,
        ))
    }

    /// The span mapping of [`Self::projected_body_method_text`]: one single-line span of the
    /// projected body, translated through the same placement, and verified against the composed
    /// text exactly as the physical member's mapping is.
    pub(crate) fn projected_body_span(
        &self,
        body: &str,
        declaration_override: Option<&str>,
        extra_markers: &[String],
        start: usize,
        end: usize,
    ) -> Option<(usize, usize)> {
        let declaration = declaration_override.unwrap_or(self.declaration.as_ref()?);
        let placed = artifact(body)?;
        let source = body.get(start..end)?;
        if source.is_empty() || source.contains('\n') {
            return None;
        }
        let annotations = self
            .annotations
            .uses
            .iter()
            .map(|annotation| 4 + annotation.len() + 1)
            .sum::<usize>();
        let marker_len = self
            .markers
            .iter()
            .chain(extra_markers)
            .map(|marker| indent(&format!("{marker}\n"), 2).len())
            .sum::<usize>();
        let block_prefix = annotations + format!("    {declaration} {{\n").len() + marker_len;
        let mapped = placed_artifact_span(&placed, start, end, block_prefix)?;
        let text = self.projected_body_method_text(body, declaration_override, extra_markers)?;
        (text.get(mapped.0..mapped.1)? == source).then_some(mapped)
    }

    /// Spells one fully recovered method inside a class-source anonymous expression. The method
    /// declaration and annotations come from its own selected physical class; `body` is emitted
    /// from that method's same-run AST at the corresponding nested indentation.
    pub(crate) fn anonymous_projection_text(&self, body: &str) -> Option<String> {
        self.anonymous_projection_text_at(body, 3)
    }

    pub(crate) fn anonymous_projection_text_at(
        &self,
        body: &str,
        declaration_indent: usize,
    ) -> Option<String> {
        let declaration = self.declaration.as_ref()?;
        // Java 8 anonymous bodies cannot declare static methods; bridge and synthetic methods
        // are physical implementation artifacts rather than source declarations.
        if self.item.access_flags & (ACC_STATIC | 0x0040 | 0x1000) != 0
            || !self.markers.is_empty()
            || !self.parameter_annotations.refusals.is_empty()
            || self
                .parameter_annotations
                .uses_by_position
                .iter()
                .any(|uses| !uses.is_empty())
            || !self.type_annotations.refusals.is_empty()
            || !self.type_annotations.field_uses.is_empty()
            || !self.type_annotations.return_uses.is_empty()
            || self
                .type_annotations
                .parameter_uses
                .iter()
                .any(|uses| !uses.is_empty())
            || !matches!(self.outcome, ClassSourceOutcome::Recovered { .. })
        {
            return None;
        }
        let mut text = String::new();
        let indentation = "    ".repeat(declaration_indent);
        for annotation in &self.annotations.uses {
            text.push_str(&indentation);
            text.push_str(annotation);
            text.push('\n');
        }
        text.push_str(&format!("{indentation}{declaration} {{\n"));
        text.push_str(body);
        text.push_str(&indentation);
        text.push_str("}\n");
        Some(text)
    }

    pub(crate) fn anonymous_return_projection_text(&self, body: &str) -> Option<String> {
        self.anonymous_return_projection_parts(body, 1)
            .map(|(text, _)| text)
    }

    pub(crate) fn anonymous_return_projection(
        &self,
        body: &jarde_java::report::ClassSourceAnonymousReturn,
        anchors: Vec<MemberFamilyPhysicalAnchor>,
    ) -> Option<MemberFamilyMethodText> {
        let (text, body_start) = self.anonymous_return_projection_parts(&body.text, 1)?;
        let start = body_start.checked_add(body.expression_range.start)?;
        let end = body_start.checked_add(body.expression_range.end)?;
        if start >= end || text.get(start..end)? != body.text.get(body.expression_range.clone())? {
            return None;
        }
        Some(MemberFamilyMethodText {
            index: self.item.index,
            text,
            derived: vec![MemberFamilyDerivedProjection {
                kind: MemberFamilyDerivedKind::NestedAnonymousExpression,
                start,
                end,
                anchors,
            }],
        })
    }

    /// [`Self::anonymous_return_projection`] for a member whose text must keep what it already
    /// carries: the projected statements are placed under the member's own **physical prefix** —
    /// every marker line exactly as the pass that wrote it wrote it, and the declaration's own
    /// opening line — instead of being composed from the declaration alone.
    ///
    /// [`Self::anonymous_return_projection_parts`] composes the member text itself and therefore
    /// has to refuse a member that carries a marker (it cannot reproduce one byte for byte: the
    /// generic Signature refusal writes its line one level in, while the recovery-time composer
    /// writes its own two). Keeping the physical prefix instead makes the placement exact for both
    /// writers, and the envelope the recovery layer wrote inside the block is dropped exactly as
    /// the composed placement drops it. `body` is the **statements** form
    /// [`jarde_java::report::emit_class_source_anonymous_return`] writes, and its expression range
    /// is translated through this placement.
    pub(crate) fn projected_statements_method_text(
        &self,
        body: &jarde_java::report::ClassSourceAnonymousReturn,
        anchors: Vec<MemberFamilyPhysicalAnchor>,
    ) -> Option<MemberFamilyMethodText> {
        let declaration = self.declaration.as_ref()?;
        if !matches!(self.outcome, ClassSourceOutcome::Recovered { .. }) {
            return None;
        }
        let declaration_line = format!("    {declaration} {{\n");
        if self.text.match_indices(&declaration_line).count() != 1 {
            return None;
        }
        let at = self.text.find(&declaration_line)?;
        let prefix = self.text.get(..at + declaration_line.len())?;
        let mut text = String::with_capacity(prefix.len() + body.text.len() + "    }\n".len());
        text.push_str(prefix);
        let body_start = text.len();
        text.push_str(&body.text);
        text.push_str("    }\n");
        let start = body_start.checked_add(body.expression_range.start)?;
        let end = body_start.checked_add(body.expression_range.end)?;
        if start >= end || text.get(start..end)? != body.text.get(body.expression_range.clone())? {
            return None;
        }
        Some(MemberFamilyMethodText {
            index: self.item.index,
            text,
            derived: vec![MemberFamilyDerivedProjection {
                kind: MemberFamilyDerivedKind::NestedAnonymousExpression,
                start,
                end,
                anchors,
            }],
        })
    }

    fn anonymous_return_projection_parts(
        &self,
        body: &str,
        declaration_indent: usize,
    ) -> Option<(String, usize)> {
        let declaration = self.declaration.as_ref()?;
        if !self.markers.is_empty()
            || !self.parameter_annotations.refusals.is_empty()
            || self
                .parameter_annotations
                .uses_by_position
                .iter()
                .any(|uses| !uses.is_empty())
            || !self.type_annotations.refusals.is_empty()
            || !self.type_annotations.field_uses.is_empty()
            || !self.type_annotations.return_uses.is_empty()
            || self
                .type_annotations
                .parameter_uses
                .iter()
                .any(|uses| !uses.is_empty())
            || !matches!(self.outcome, ClassSourceOutcome::Recovered { .. })
        {
            return None;
        }
        let mut text = String::new();
        let indentation = "    ".repeat(declaration_indent);
        for annotation in &self.annotations.uses {
            text.push_str(&indentation);
            text.push_str(annotation);
            text.push('\n');
        }
        text.push_str(&format!("{indentation}{declaration} {{\n"));
        let body_start = text.len();
        text.push_str(body);
        text.push_str(&indentation);
        text.push_str("}\n");
        Some((text, body_start))
    }

    /// One member whose declaration carries no `Code` attribute: the declaration Java spells for it
    /// (`public abstract void run();`) and the markers that say why it has no body here. `kind` is
    /// what the member's own flags declare, which decides the form: an `abstract` or `native` member
    /// is written as the body-less declaration Java writes for it, and one that declares neither is
    /// written as a block whose whole content is the marker.
    pub(crate) fn no_body(item: MethodItem, kind: Option<NoBodyKind>, spelled: Spelled) -> Self {
        let mut markers = markers_of(&spelled);
        let member = label(&item);
        markers.push(match kind {
            Some(NoBodyKind::Abstract) => format!(
                "// jarde: no body: the member `{member}` is declared abstract and its declaration \
                 carries no Code attribute"
            ),
            Some(NoBodyKind::Native) => format!(
                "// jarde: no body: the member `{member}` is declared native and its declaration \
                 carries no Code attribute"
            ),
            None => format!(
                "// jarde: no body: the member `{member}` declares no Code attribute and is neither \
                 abstract nor native"
            ),
        });
        let text = match &spelled.declaration {
            Some(declaration) if kind.is_some() => declaration_member(declaration, &markers),
            Some(declaration) => block_member(declaration, Placed::Without, &markers),
            None => comment_member(&markers),
        };
        let text = prefix_method_annotations(text, &spelled.annotations);
        Self {
            item,
            no_body_kind: kind,
            declaration: spelled.declaration,
            annotations: spelled.annotations,
            parameter_annotations: spelled.parameter_annotations,
            type_annotations: spelled.type_annotations,
            text,
            markers,
            outcome: ClassSourceOutcome::NoBody,
            same_run_generic_return: None,
            same_class_generic_body_proof: None,
            generic_signature_refused: false,
            generic_signature_projected: false,
            enum_constructor_source_tail: EnumConstructorSourceTail::Unrecognized,
            enum_constructor_signature_erasure_refused: false,
        }
    }

    /// One member whose raw descriptor is not one this presentation can read: no declaration, no
    /// run, and the markers that state both.
    pub(crate) fn unspelled(item: MethodItem, spelled: Spelled) -> Self {
        let markers = markers_of(&spelled);
        Self {
            item,
            no_body_kind: None,
            declaration: None,
            text: comment_member(&markers),
            annotations: spelled.annotations,
            parameter_annotations: spelled.parameter_annotations,
            type_annotations: spelled.type_annotations,
            markers,
            outcome: ClassSourceOutcome::Unspelled,
            same_run_generic_return: None,
            same_class_generic_body_proof: None,
            generic_signature_refused: false,
            generic_signature_projected: false,
            enum_constructor_source_tail: EnumConstructorSourceTail::Unrecognized,
            enum_constructor_signature_erasure_refused: false,
        }
    }

    /// One member whose own run was refused before it produced a report.
    pub(crate) fn refused(
        item: MethodItem,
        spelled: Spelled,
        execution: ExecutionReport,
        diagnostics: Vec<Diagnostic>,
    ) -> Self {
        let mut markers = markers_of(&spelled);
        markers.push(format!(
            "// jarde: not recovered: the run for `{}` was refused ({})",
            label(&item),
            stop_code(&execution).unwrap_or_else(|| "reason not stated".to_owned())
        ));
        let text = match &spelled.declaration {
            Some(declaration) => block_member(declaration, Placed::Without, &markers),
            None => comment_member(&markers),
        };
        let text = prefix_method_annotations(text, &spelled.annotations);
        Self {
            item,
            no_body_kind: None,
            declaration: spelled.declaration,
            annotations: spelled.annotations,
            parameter_annotations: spelled.parameter_annotations,
            type_annotations: spelled.type_annotations,
            text,
            markers,
            outcome: ClassSourceOutcome::Refused {
                execution,
                diagnostics,
            },
            same_run_generic_return: None,
            same_class_generic_body_proof: None,
            generic_signature_refused: false,
            generic_signature_projected: false,
            enum_constructor_source_tail: EnumConstructorSourceTail::Unrecognized,
            enum_constructor_signature_erasure_refused: false,
        }
    }

    /// One member one recovery run presented, with the facts of that same run.
    pub(crate) fn recovered(
        item: MethodItem,
        spelled: Spelled,
        report: Box<RecoveryReport>,
        analysis: ClassSourceRunFacts,
        same_run_generic_return: Option<GenericReturnCandidate>,
    ) -> Self {
        let mut markers = recovered_markers(&item, &spelled, &report, &analysis);
        let placed = if report.text.is_empty() {
            Placed::Without
        } else {
            match artifact(&report.text) {
                Some(artifact) => Placed::Block(artifact),
                None => {
                    markers.push(not_placed_marker(&item));
                    Placed::Quoted(&report.text)
                }
            }
        };
        let text = match &spelled.declaration {
            Some(declaration) => block_member(declaration, placed, &markers),
            None => comment_member(&markers),
        };
        let text = prefix_method_annotations(text, &spelled.annotations);
        Self {
            item,
            no_body_kind: None,
            declaration: spelled.declaration,
            annotations: spelled.annotations,
            parameter_annotations: spelled.parameter_annotations,
            type_annotations: spelled.type_annotations,
            text,
            markers,
            outcome: ClassSourceOutcome::Recovered { report, analysis },
            same_run_generic_return,
            same_class_generic_body_proof: None,
            generic_signature_refused: false,
            generic_signature_projected: false,
            enum_constructor_source_tail: EnumConstructorSourceTail::Unrecognized,
            enum_constructor_signature_erasure_refused: false,
        }
    }

    /// Replaces this record's body with one **rerun's** (change
    /// `recover-nested-class-literal-values`, correction round): the class-source assembly reran
    /// the member under a presentation that keeps member classes pool-spelled, and the run refused
    /// what the first run had recovered. Everything the rerun did not decide stays exactly as the
    /// first presentation wrote it — the declaration, its annotations, and every marker outside
    /// the body (a member-name alias, a refused generic Signature projection) are facts about the
    /// member and the first run's spelling, not about the body — and the run's own verdict writes
    /// the run-level markers after them.
    pub(crate) fn with_rerun_body(
        mut self,
        report: Box<RecoveryReport>,
        analysis: ClassSourceRunFacts,
    ) -> Self {
        let placed = if report.text.is_empty() {
            Placed::Without
        } else {
            match artifact(&report.text) {
                Some(artifact) => Placed::Block(artifact),
                None => {
                    self.markers.push(not_placed_marker(&self.item));
                    Placed::Quoted(&report.text)
                }
            }
        };
        let text = match &self.declaration {
            Some(declaration) => block_member(declaration, placed, &self.markers),
            None => comment_member(&self.markers),
        };
        self.text = prefix_method_annotations(text, &self.annotations);
        self.markers
            .extend(run_markers(&self.item, &report, &analysis));
        self.outcome = ClassSourceOutcome::Recovered { report, analysis };
        self
    }
}

/// The markers one spelling carries, as the vector the member record publishes.
fn class_source_body_lines_match(left: &str, right: &str) -> bool {
    left.lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .eq(right.lines().map(str::trim).filter(|line| !line.is_empty()))
}

fn markers_of(spelled: &Spelled) -> Vec<String> {
    let mut markers = spelled.marker.clone().into_iter().collect::<Vec<_>>();
    markers.extend(spelled.annotations.refusals.iter().map(|reason| {
        format!(
            "// jarde: member annotation refused: {}",
            comment_text(reason)
        )
    }));
    markers.extend(spelled.parameter_annotations.refusals.iter().map(|reason| {
        format!(
            "// jarde: parameter annotation refused: {}",
            comment_text(reason)
        )
    }));
    markers.extend(spelled.type_annotations.refusals.iter().map(|reason| {
        format!(
            "// jarde: type annotation refused: {}",
            comment_text(reason)
        )
    }));
    markers
}

fn prefix_method_annotations(text: String, annotations: &MemberAnnotationUses) -> String {
    if annotations.uses.is_empty() {
        return text;
    }
    let mut prefixed = String::new();
    for annotation in &annotations.uses {
        prefixed.push_str("    ");
        prefixed.push_str(annotation);
        prefixed.push('\n');
    }
    prefixed.push_str(&text);
    prefixed
}

/// The text-only portion of a proved enum projection. The physical member records remain intact.
pub(crate) struct EnumConstantSourceProjection {
    constant_field_indices: Vec<u64>,
    backing_field_index: u64,
    implicit_method_indices: Vec<u64>,
    constants_text: String,
    constructor_texts: Vec<(u64, String)>,
    initializer_text: Option<String>,
}

/// The already-proved choices and bookkeeping that control one class-text assembly.
pub(crate) struct ClassSourceTextContext<'a> {
    pub(crate) initializer_field_order: Option<&'a [usize]>,
    pub(crate) declared_methods: u64,
    pub(crate) member_table: Option<&'a MemberTableStop>,
    pub(crate) execution: &'a ExecutionReport,
    pub(crate) enum_projection: Option<&'a EnumConstantSourceProjection>,
    pub(crate) array_helper_indices: Option<&'a [u64]>,
    pub(crate) array_method_texts: Option<&'a [(u64, String)]>,
    pub(crate) array_helper_markers: Option<&'a [String]>,
    /// Physical field indices the assembled text omits: the assert projection's hidden switch
    /// field. `None` when no projection staged one, which is the assembly of every class that
    /// keeps its fields physical.
    pub(crate) hidden_fields: Option<&'a [u64]>,
}

impl EnumConstantSourceProjection {
    /// The texts of this projection as the report retains them: a fact copy, index for index.
    pub(crate) fn retained(&self) -> ClassSourceEnumProjectionTexts {
        ClassSourceEnumProjectionTexts {
            constant_field_indices: self.constant_field_indices.clone(),
            backing_field_index: self.backing_field_index,
            implicit_method_indices: self.implicit_method_indices.clone(),
            constants_text: self.constants_text.clone(),
            constructor_texts: self
                .constructor_texts
                .iter()
                .map(|(member, text)| ClassSourceEnumConstructorText {
                    member: *member,
                    text: text.clone(),
                })
                .collect(),
            initializer_text: self.initializer_text.clone(),
        }
    }
}

/// Rebuilds the assembly-side enum projection from its retained texts: the same index sets and
/// the same placed strings, so an assembly over the rebuilt projection writes the same bytes the
/// first pass did. This is placement of retained facts, never a second proof.
pub(crate) fn retained_enum_projection(
    texts: &ClassSourceEnumProjectionTexts,
) -> EnumConstantSourceProjection {
    EnumConstantSourceProjection {
        constant_field_indices: texts.constant_field_indices.clone(),
        backing_field_index: texts.backing_field_index,
        implicit_method_indices: texts.implicit_method_indices.clone(),
        constants_text: texts.constants_text.clone(),
        constructor_texts: texts
            .constructor_texts
            .iter()
            .map(|entry| (entry.member, entry.text.clone()))
            .collect(),
        initializer_text: texts.initializer_text.clone(),
    }
}

/// The initializer field order a proved initializer group staged, derived from the proof the
/// report already carries: proved fields in their `<clinit>` write order, every other field after
/// them in physical order — the same permutation [`crate::facade`]'s first pass staged, read here
/// from the serialized fact instead of being recomputed. `None` exactly when the first pass kept
/// the physical order (no proved group).
pub(crate) fn initializer_field_order_from_proof(
    proof: &ClassSourceInitializerProof,
    fields: &[ClassSourceField],
) -> Option<Vec<usize>> {
    let ClassSourceInitializerProof::Proved { fields: proved } = proof else {
        return None;
    };
    let mut order = Vec::with_capacity(fields.len());
    let mut projected = std::collections::BTreeSet::new();
    for entry in proved {
        let matching: Vec<usize> = fields
            .iter()
            .enumerate()
            .filter_map(|(index, field)| (field.item.index == entry.field_index).then_some(index))
            .collect();
        let [physical] = matching.as_slice() else {
            return None;
        };
        let physical = *physical;
        if !projected.insert(physical) {
            return None;
        }
        order.push(physical);
    }
    for (physical, _) in fields.iter().enumerate() {
        if projected.insert(physical) {
            order.push(physical);
        }
    }
    (order.len() == fields.len()).then_some(order)
}

/// The source text of one arbitrary user-tail enum constructor: the folded declaration spells
/// the user parameters only, in argument order, each assigned to its own stored field. One
/// spelling shared by the ordinary constant list and the constant-body projection.
fn spell_user_tail_constructor_text(
    declaration_name: &str,
    access_flags: u16,
    tail: &crate::enum_constants::ProvedEnumUserConstructorTail,
) -> String {
    let mut constructor_declaration = String::new();
    if let Some(modifier) = visibility(access_flags) {
        constructor_declaration.push_str(modifier);
        constructor_declaration.push(' ');
    }
    constructor_declaration.push_str(declaration_name);
    constructor_declaration.push('(');
    for (index, parameter) in tail.parameters.iter().enumerate() {
        if index > 0 {
            constructor_declaration.push_str(", ");
        }
        constructor_declaration.push_str(&parameter.type_text);
        constructor_declaration.push_str(&format!(" arg{index}"));
    }
    constructor_declaration.push(')');
    let mut assignments = String::new();
    for (index, parameter) in tail.parameters.iter().enumerate() {
        assignments.push_str(&format!(
            "        this.{} = arg{index};\n",
            parameter.field_name
        ));
    }
    format!("    {constructor_declaration} {{\n{assignments}    }}\n")
}

pub(crate) fn prepare_enum_constant_source_projection(
    declaration: &ClassSourceDeclaration,
    fields: &[ClassSourceField],
    methods: &[ClassSourceMethod],
    group: &crate::enum_constants::ProvedOrdinaryEnumConstantGroup,
    terminal_constructor_body: Option<String>,
    initializer: Option<(u64, String)>,
    budget: &mut Budget,
) -> Result<Option<EnumConstantSourceProjection>> {
    let Ok(constructor_index) = usize::try_from(group.constructor_method_index) else {
        return Ok(None);
    };
    let source_field = group
        .constructor_field_index
        .and_then(|index| usize::try_from(index).ok())
        .and_then(|index| fields.get(index));
    let Some(constructor) = methods.get(constructor_index) else {
        return Ok(None);
    };
    let user_tail = group.constructor_user_tail.as_ref();
    let no_source_constructor = group.constructor_field_index.is_none() && user_tail.is_none();
    let has_only_enum_signature_marker =
        constructor.enum_constructor_signature_erasure_refused && constructor.markers.len() == 1;
    // The arbitrary tail's own proof owns the constructor shape; the one marker it can carry is
    // the same JVM-only name/ordinal Signature erasure refusal the recognized tails absorb.
    let has_arbitrary_signature_marker = user_tail.is_some()
        && constructor.markers.len() <= 1
        && constructor
            .markers
            .first()
            .is_none_or(|marker| marker.contains("jvm_signature_erasure_mismatch"));
    if constructor.item.index != group.constructor_method_index
        || (!no_source_constructor && user_tail.is_none() && source_field.is_none())
        || source_field.is_some_and(|field| {
            Some(field.item.index) != group.constructor_field_index || field.declaration.is_none()
        })
        || (!no_source_constructor && constructor.declaration.is_none())
        || (!no_source_constructor
            && user_tail.is_none()
            && group.constructor_signature_present
            && !matches!(
                constructor.enum_constructor_source_tail,
                EnumConstructorSourceTail::Int
                    | EnumConstructorSourceTail::SingleString
                    | EnumConstructorSourceTail::StringVarargs
            ))
        || (!constructor.markers.is_empty()
            && !has_only_enum_signature_marker
            && !has_arbitrary_signature_marker)
        || !constructor.annotations.refusals.is_empty()
        || !constructor.parameter_annotations.refusals.is_empty()
        || !constructor.type_annotations.refusals.is_empty()
        || (user_tail.is_some()
            && (constructor
                .parameter_annotations
                .uses_by_position
                .iter()
                .any(|uses| !uses.is_empty())
                || constructor
                    .type_annotations
                    .parameter_uses
                    .iter()
                    .any(|uses| !uses.is_empty())))
        || constructor
            .parameter_annotations
            .uses_by_position
            .iter()
            .take(2)
            .any(|uses| !uses.is_empty())
        || constructor
            .type_annotations
            .parameter_uses
            .iter()
            .take(2)
            .any(|uses| !uses.is_empty())
    {
        return Ok(None);
    }

    let implicit_signature_shape = if group.constructor_signature_present {
        constructor.enum_constructor_source_tail == EnumConstructorSourceTail::NoArg
            && constructor.enum_constructor_signature_erasure_refused
            && constructor.markers.len() == 1
    } else {
        constructor.enum_constructor_source_tail != EnumConstructorSourceTail::NoArg
            && !constructor.enum_constructor_signature_erasure_refused
            && constructor.markers.is_empty()
    };
    if no_source_constructor
        && (group.delegating_constructor_method_index.is_some()
            || constructor.item.descriptor.raw().0 != b"(Ljava/lang/String;I)V"
            || constructor.enum_constructor_source_tail == EnumConstructorSourceTail::Int
            || constructor.enum_constructor_source_tail == EnumConstructorSourceTail::SingleString
            || constructor.enum_constructor_source_tail == EnumConstructorSourceTail::StringVarargs
            || !implicit_signature_shape)
    {
        return Ok(None);
    }

    let field_name = if let Some(source_field) = source_field {
        let (name, aliased) = written_name(&source_field.item.name.raw().0);
        if aliased {
            return Ok(None);
        }
        Some(name)
    } else {
        None
    };
    let mut constructor_texts = Vec::new();
    if let Some(delegating_index) = group.delegating_constructor_method_index {
        if field_name.is_none() {
            return Ok(None);
        }
        let Ok(delegating_index_usize) = usize::try_from(delegating_index) else {
            return Ok(None);
        };
        let Some(delegating) = methods.get(delegating_index_usize) else {
            return Ok(None);
        };
        let valid_hidden_constructor = |method: &ClassSourceMethod| {
            method.declaration.is_some()
                && method.enum_constructor_source_tail == EnumConstructorSourceTail::NoArg
                && method.enum_constructor_signature_erasure_refused
                && method.markers.len() == 1
                && method.annotations.refusals.is_empty()
                && method.parameter_annotations.refusals.is_empty()
                && method.type_annotations.refusals.is_empty()
                && method
                    .parameter_annotations
                    .uses_by_position
                    .iter()
                    .all(Vec::is_empty)
                && method
                    .type_annotations
                    .parameter_uses
                    .iter()
                    .all(Vec::is_empty)
        };
        if delegating.item.index != delegating_index
            || delegating.item.name.raw().0 != b"<init>"
            || delegating.item.descriptor.raw().0 != b"(Ljava/lang/String;I)V"
            || !valid_hidden_constructor(delegating)
            || group.constructor_body.is_none()
            || terminal_constructor_body.is_none()
            || group.constructor_signature_present
                != (constructor.enum_constructor_source_tail == EnumConstructorSourceTail::Int)
        {
            return Ok(None);
        }

        let mut delegating_declaration = String::new();
        if let Some(modifier) = visibility(delegating.item.access_flags) {
            delegating_declaration.push_str(modifier);
            delegating_declaration.push(' ');
        }
        delegating_declaration.push_str(&declaration.name);
        delegating_declaration.push_str("()");
        let delegating_body =
            format!("    {delegating_declaration} {{\n        this(0);\n    }}\n");
        constructor_texts.push((
            delegating_index,
            prefix_method_annotations(delegating_body, &delegating.annotations),
        ));

        let source_parameter_type_uses = constructor
            .type_annotations
            .parameter_uses
            .get(2)
            .map(Vec::as_slice)
            .unwrap_or(&[]);
        let Some(parameter_type) = (if source_parameter_type_uses.is_empty() {
            Some("int".to_owned())
        } else {
            decorate_qualified_type("int", source_parameter_type_uses)
        }) else {
            return Ok(None);
        };
        let source_parameter_annotations = constructor
            .parameter_annotations
            .uses_by_position
            .get(2)
            .map(Vec::as_slice)
            .unwrap_or(&[]);
        let parameter_annotations = source_parameter_annotations
            .iter()
            .map(|annotation| format!("{annotation} "))
            .collect::<String>();
        let mut terminal_declaration = String::new();
        if let Some(modifier) = visibility(constructor.item.access_flags) {
            terminal_declaration.push_str(modifier);
            terminal_declaration.push(' ');
        }
        terminal_declaration.push_str(&declaration.name);
        terminal_declaration.push('(');
        terminal_declaration.push_str(&parameter_annotations);
        terminal_declaration.push_str(&parameter_type);
        terminal_declaration.push_str(" arg0)");
        let Some(statements) = terminal_constructor_body else {
            return Ok(None);
        };
        let terminal_body = format!("    {terminal_declaration} {{\n{statements}    }}\n");
        constructor_texts.push((
            group.constructor_method_index,
            prefix_method_annotations(terminal_body, &constructor.annotations),
        ));
    } else {
        if terminal_constructor_body.is_some() {
            return Ok(None);
        }
        if let Some(tail) = user_tail {
            // The arbitrary tail's proof carries each parameter's type text and its own stored
            // field; the folded declaration spells the user parameters only, in argument order.
            constructor_texts.push((
                group.constructor_method_index,
                prefix_method_annotations(
                    spell_user_tail_constructor_text(
                        &declaration.name,
                        constructor.item.access_flags,
                        tail,
                    ),
                    &constructor.annotations,
                ),
            ));
        } else if !no_source_constructor {
            let Some(field_name) = field_name.as_deref() else {
                return Ok(None);
            };
            let string_varargs = constructor.enum_constructor_source_tail
                == EnumConstructorSourceTail::StringVarargs;
            let single_string =
                constructor.enum_constructor_source_tail == EnumConstructorSourceTail::SingleString;
            if string_varargs
                && (constructor.item.descriptor.raw().0
                    != b"(Ljava/lang/String;I[Ljava/lang/String;)V"
                    || constructor.item.access_flags != 0x0082
                    || constructor
                        .type_annotations
                        .parameter_uses
                        .get(2)
                        .is_some_and(|uses| !uses.is_empty()))
            {
                return Ok(None);
            }
            let source_parameter_type_uses = constructor
                .type_annotations
                .parameter_uses
                .get(2)
                .map(Vec::as_slice)
                .unwrap_or(&[]);
            let Some(parameter_type) = (if string_varargs {
                Some("java.lang.String...".to_owned())
            } else if single_string && source_parameter_type_uses.is_empty() {
                Some("java.lang.String".to_owned())
            } else if source_parameter_type_uses.is_empty() {
                Some("int".to_owned())
            } else {
                decorate_qualified_type(
                    if single_string {
                        "java.lang.String"
                    } else {
                        "int"
                    },
                    source_parameter_type_uses,
                )
            }) else {
                return Ok(None);
            };
            let source_parameter_annotations = constructor
                .parameter_annotations
                .uses_by_position
                .get(2)
                .map(Vec::as_slice)
                .unwrap_or(&[]);
            let parameter_annotations = source_parameter_annotations
                .iter()
                .map(|annotation| format!("{annotation} "))
                .collect::<String>();
            let mut constructor_declaration = String::new();
            if let Some(modifier) = visibility(constructor.item.access_flags) {
                constructor_declaration.push_str(modifier);
                constructor_declaration.push(' ');
            }
            constructor_declaration.push_str(&declaration.name);
            constructor_declaration.push('(');
            constructor_declaration.push_str(&parameter_annotations);
            constructor_declaration.push_str(&parameter_type);
            constructor_declaration.push_str(" arg0)");
            let constructor_body = format!(
                "    {constructor_declaration} {{\n        this.{field_name} = arg0;\n    }}\n"
            );
            // The one known marker comes from the JVM-only name/ordinal parameters making the physical
            // descriptor longer than the already parsed source Signature. The enum proof checks that
            // source tail independently; no other constructor marker is absorbed by this projection.
            constructor_texts.push((
                group.constructor_method_index,
                prefix_method_annotations(constructor_body, &constructor.annotations),
            ));
        }
    }

    if initializer.is_some() {
        budget.charge(
            CountedBudgetDimension::IrItems,
            u64::try_from(fields.len()).unwrap_or(u64::MAX),
        )?;
    }
    let initializer_text = match initializer {
        Some((field_index, text)) => {
            let mut target = None;
            for field in fields {
                budget.poll()?;
                if field.item.index == field_index && target.replace(field).is_some() {
                    return Ok(None);
                }
            }
            let Some(target) = target else {
                return Ok(None);
            };
            if !((target.item.name.raw().0 == b"totalUnits"
                && target.item.descriptor.raw().0 == b"I"
                && target.item.access_flags == 0x0008)
                || (target.item.descriptor.raw().0 == b"Ljava/util/Map;"
                    && target.item.access_flags == 0x0019))
                || target.item.identity.owner != constructor.item.identity.owner
                || target.declaration.is_none()
                || (target.item.descriptor.raw().0 == b"I" && !target.markers.is_empty())
                || (target.item.descriptor.raw().0 == b"Ljava/util/Map;"
                    && target
                        .markers
                        .iter()
                        .any(|marker| !marker.contains("field_generic_source_unproved")))
            {
                return Ok(None);
            }
            Some(text)
        }
        None => None,
    };

    let mut constants_text = String::new();
    for (index, constant) in group.constants.iter().enumerate() {
        constants_text.push_str("    ");
        constants_text.push_str(&constant.name);
        if let Some(argument) = &constant.source_argument {
            if let crate::enum_constants::ProvedEnumSourceArgument::StringVarargs(values) = argument
            {
                let source_capacity = values.iter().fold(0_u64, |total, value| {
                    total
                        .saturating_add(
                            u64::try_from(value.value.len())
                                .unwrap_or(u64::MAX)
                                .saturating_mul(6),
                        )
                        .saturating_add(4)
                });
                budget.charge(CountedBudgetDimension::OutputBytes, source_capacity)?;
            }
            constants_text.push('(');
            constants_text.push_str(&argument.source_text());
            constants_text.push(')');
        }
        if index + 1 == group.constants.len() {
            constants_text.push_str(";\n");
        } else {
            constants_text.push_str(",\n");
        }
    }
    let mut implicit_method_indices: Vec<u64> = [
        group.initializer_method_index,
        group.values_method_index,
        group.value_of_method_index,
        group.values_factory_method_index,
    ]
    .into();
    if no_source_constructor {
        implicit_method_indices.push(group.constructor_method_index);
    }
    if group.constants.is_empty() {
        let hidden: std::collections::BTreeSet<u64> =
            implicit_method_indices.iter().copied().collect();
        let hidden_fields: std::collections::BTreeSet<u64> = group
            .constants
            .iter()
            .map(|constant| constant.field_index)
            .chain(std::iter::once(group.backing_field_index))
            .collect();
        let has_user_member =
            fields.iter().any(|field| {
                !hidden_fields.contains(&field.item.index) && field.declaration.is_some()
            }) || methods.iter().any(|method| {
                !hidden.contains(&method.item.index)
                    && !constructor_texts
                        .iter()
                        .any(|(index, _)| *index == method.item.index)
                    && method.item.name.raw().0 != b"<clinit>"
            }) || initializer_text.is_some();
        if has_user_member {
            constants_text.push_str("    ;\n");
        }
    }
    let output_bytes = u64::try_from(constants_text.len())
        .unwrap_or(u64::MAX)
        .saturating_add(constructor_texts.iter().fold(0u64, |total, (_, text)| {
            total.saturating_add(u64::try_from(text.len()).unwrap_or(u64::MAX))
        }))
        .saturating_add(
            initializer_text
                .as_ref()
                .map_or(0, |text| u64::try_from(text.len()).unwrap_or(u64::MAX)),
        );
    budget.charge(CountedBudgetDimension::OutputBytes, output_bytes)?;

    Ok(Some(EnumConstantSourceProjection {
        constant_field_indices: group
            .constants
            .iter()
            .map(|constant| constant.field_index)
            .collect(),
        backing_field_index: group.backing_field_index,
        implicit_method_indices,
        constants_text,
        constructor_texts,
        initializer_text,
    }))
}

/// Place the members retained by the proved body group directly inside their owning constant.
/// The method text is the selected child's same-run member artifact, not parsed class source.
pub(crate) fn prepare_enum_constant_body_source_projection(
    declaration: &ClassSourceDeclaration,
    fields: &[ClassSourceField],
    methods: &[ClassSourceMethod],
    group: &crate::enum_constants::ProvedEnumConstantBodyGroup,
    shape: &crate::facade::PendingEnumConstantBodyGroupShape,
    budget: &mut Budget,
) -> Result<Option<EnumConstantSourceProjection>> {
    if group.constants.is_empty()
        || shape.constants.len() != group.constants.len()
        || shape.implicit_members.len() != 6
    {
        return Ok(None);
    }
    let mut constants_text = String::new();
    let mut constant_field_indices = Vec::with_capacity(group.constants.len());
    for (position, constant) in group.constants.iter().enumerate() {
        budget.poll()?;
        let Some(field) = usize::try_from(constant.field_index)
            .ok()
            .and_then(|index| fields.get(index))
        else {
            return Ok(None);
        };
        if shape.constants[position].field_index != constant.field_index
            || shape.constants[position].constructor_bci != constant.constructor_bci
            || field.item.index != constant.field_index
            || field.item.identity.owner != declaration.item.definition
            || field.declaration.is_none()
            || !field.markers.is_empty()
        {
            return Ok(None);
        }
        let (name, aliased) = written_name(&field.item.name.raw().0);
        if aliased {
            return Ok(None);
        }
        constants_text.push_str("    ");
        constants_text.push_str(&name);
        if !constant.source_arguments.is_empty() {
            // The argument spelling is the one arbitrary-argument channel's own joined text.
            let arguments =
                crate::enum_constants::user_arguments_source_text(&constant.source_arguments);
            budget.charge(
                CountedBudgetDimension::OutputBytes,
                u64::try_from(arguments.len().saturating_mul(6).saturating_add(4))
                    .unwrap_or(u64::MAX),
            )?;
            constants_text.push('(');
            constants_text.push_str(&arguments);
            constants_text.push(')');
        }
        match (&constant.subclass, &constant.methods) {
            (None, None) => {}
            (Some(subclass), Some(body_methods)) if !body_methods.is_empty() => {
                constants_text.push_str(" {\n");
                constants_text.push_str("        // jarde: selected enum child definition: ");
                constants_text.push_str(&format!("{subclass:?}"));
                constants_text.push('\n');
                for method in body_methods.iter() {
                    budget.poll()?;
                    if method.item.identity.owner != *subclass
                        || method.declaration.is_none()
                        || !method.markers.is_empty()
                        || !matches!(method.outcome, ClassSourceOutcome::Recovered { .. })
                        || !method.text.ends_with("}\n")
                    {
                        return Ok(None);
                    }
                    constants_text.push_str(&indent(&method.text, 1));
                }
                constants_text.push_str("    }");
            }
            _ => return Ok(None),
        }
        constants_text.push_str(if position + 1 == group.constants.len() {
            ";\n"
        } else {
            ",\n"
        });
        constant_field_indices.push(constant.field_index);
    }
    let backing_field_index = shape.implicit_members[0].table_index;
    let backing_field = usize::try_from(backing_field_index)
        .ok()
        .and_then(|index| fields.get(index));
    if shape.implicit_members[0].name != b"$VALUES"
        || backing_field.is_none_or(|field| {
            field.item.index != backing_field_index
                || field.item.identity.owner != declaration.item.definition
        })
    {
        return Ok(None);
    }
    let mut implicit_method_indices = Vec::new();
    for member in shape
        .implicit_members
        .iter()
        .skip(1)
        .chain(shape.constructors.iter())
    {
        let Some(method) = usize::try_from(member.table_index)
            .ok()
            .and_then(|index| methods.get(index))
        else {
            return Ok(None);
        };
        if method.item.index != member.table_index
            || method.item.identity.owner != declaration.item.definition
            || method.item.name.raw().0 != member.name
            || method.item.descriptor.raw().0 != member.descriptor
        {
            return Ok(None);
        }
        if !implicit_method_indices.contains(&member.table_index) {
            implicit_method_indices.push(member.table_index);
        }
    }
    let mut constructor_texts = Vec::new();
    if let Some(text) = &group.constructor_text {
        let constructors: Vec<_> = shape
            .constructors
            .iter()
            .filter(|member| member.descriptor == b"(Ljava/lang/String;ILjava/lang/String;)V")
            .collect();
        let [constructor] = constructors.as_slice() else {
            return Ok(None);
        };
        let Some(method) = usize::try_from(constructor.table_index)
            .ok()
            .and_then(|index| methods.get(index))
        else {
            return Ok(None);
        };
        if method.item.index != constructor.table_index
            || method.enum_constructor_source_tail != EnumConstructorSourceTail::SingleString
            || !text.ends_with("}\n")
        {
            return Ok(None);
        }
        budget.charge(
            CountedBudgetDimension::OutputBytes,
            u64::try_from(text.len()).unwrap_or(u64::MAX),
        )?;
        constructor_texts.push((constructor.table_index, text.clone()));
    } else if let Some(tail) = &group.constructor_user_tail {
        // The arbitrary tail spells through the one shared user-tail constructor text.
        let constructors: Vec<_> = shape
            .constructors
            .iter()
            .filter(|member| member.descriptor == shape.constants[0].constructor_descriptor)
            .collect();
        let [constructor] = constructors.as_slice() else {
            return Ok(None);
        };
        let Some(method) = usize::try_from(constructor.table_index)
            .ok()
            .and_then(|index| methods.get(index))
        else {
            return Ok(None);
        };
        if method.item.index != constructor.table_index || method.item.name.raw().0 != b"<init>" {
            return Ok(None);
        }
        let text =
            spell_user_tail_constructor_text(&declaration.name, method.item.access_flags, tail);
        budget.charge(
            CountedBudgetDimension::OutputBytes,
            u64::try_from(text.len()).unwrap_or(u64::MAX),
        )?;
        constructor_texts.push((constructor.table_index, text));
    } else if group
        .constants
        .iter()
        .any(|constant| !constant.source_arguments.is_empty())
    {
        return Ok(None);
    }
    budget.charge(
        CountedBudgetDimension::OutputBytes,
        u64::try_from(constants_text.len()).unwrap_or(u64::MAX),
    )?;
    Ok(Some(EnumConstantSourceProjection {
        constant_field_indices,
        backing_field_index,
        implicit_method_indices,
        constants_text,
        constructor_texts,
        initializer_text: None,
    }))
}

/// The marker of a produced artifact whose shape this presentation does not recognize.
fn not_placed_marker(item: &MethodItem) -> String {
    format!(
        "// jarde: not placed: the recovery artifact for `{}` is not a block this presentation can \
         place, so its text is quoted below line by line",
        label(item)
    )
}

/// The class-source text: the `package` line the class's own name states, the declaration, the
/// fields in the requested projection order, the members, and the class file's own shortfall where
/// there is one. A supplied initializer order is a complete permutation prepared only after a full
/// class-level proof and atomic expression emission.
///
/// The `package` statement is the one thing written above the class: it is the package
/// [`package_name`] reads off `this_class`, and a name with no `/` states none — the default
/// package, which source spells with no statement at all. It is a statement about that one name and
/// not about the directory the class was found in, which no read of this presentation established.
pub(crate) fn source_text(
    declaration: &ClassSourceDeclaration,
    fields: &[ClassSourceField],
    methods: &[ClassSourceMethod],
    context: &ClassSourceTextContext<'_>,
) -> String {
    source_text_with_member(
        declaration,
        fields,
        &[],
        methods,
        context,
        None,
        &[],
        &[],
        &mut Vec::new(),
        &[],
    )
    .expect("ordinary class writer has no derived ranges to translate")
}

pub(crate) fn source_text_with_nested_declaration(
    declaration: &ClassSourceDeclaration,
    fields: &[ClassSourceField],
    methods: &[ClassSourceMethod],
    context: &ClassSourceTextContext<'_>,
    method_texts: &[MemberFamilyMethodText],
    nested: &NestedClassSourceText,
) -> (String, Vec<MemberFamilyDerivedProjection>) {
    source_text_with_nested_declarations(
        declaration,
        fields,
        &[],
        methods,
        context,
        method_texts,
        std::slice::from_ref(nested),
        &[],
    )
}

/// The same assembly with any number of sibling nested declarations: the fold's children are
/// appended in the order the caller states (the root's own `InnerClasses` row order), one
/// blank line apart, before the unit's closing brace. The hidden methods are root members a
/// fold proved synthetic (the javac access bridges); each keeps a derived record anchored on
/// the header its omission hides beside.
pub(crate) fn source_text_with_nested_declarations(
    declaration: &ClassSourceDeclaration,
    fields: &[ClassSourceField],
    field_texts: &[MemberFamilyMethodText],
    methods: &[ClassSourceMethod],
    context: &ClassSourceTextContext<'_>,
    method_texts: &[MemberFamilyMethodText],
    nested: &[NestedClassSourceText],
    hidden: &[HiddenFoldMethod],
) -> (String, Vec<MemberFamilyDerivedProjection>) {
    let mut derived = Vec::new();
    let text = source_text_with_member(
        declaration,
        fields,
        field_texts,
        methods,
        context,
        None,
        method_texts,
        nested,
        &mut derived,
        hidden,
    )
    .expect("nested declaration writer has no member-family ranges to translate");
    (text, derived)
}

/// Rebuild one ordinary root source unit with staged method text and translate its physical spans.
/// This intentionally accepts only a root the ordinary writer reproduces exactly; class-family or
/// initializer projections need their own combined certificate and are refused here.
pub(crate) fn source_text_with_method_projections(
    root: &ClassSourceReport,
    method_texts: &[MemberFamilyMethodText],
) -> Option<(String, Vec<MemberFamilyDerivedProjection>)> {
    let declaration = root.declaration.as_ref()?;
    let context = ClassSourceTextContext {
        initializer_field_order: None,
        declared_methods: u64::try_from(root.methods.len()).ok()?,
        member_table: None,
        execution: &root.execution,
        enum_projection: None,
        array_helper_indices: None,
        array_method_texts: None,
        array_helper_markers: None,
        hidden_fields: None,
    };
    if source_text(declaration, &root.fields, &root.methods, &context) != root.text {
        return None;
    }
    let mut derived = Vec::new();
    let text = source_text_with_member(
        declaration,
        &root.fields,
        &[],
        &root.methods,
        &context,
        None,
        method_texts,
        &[],
        &mut derived,
        &[],
    )?;
    let expected = method_texts
        .iter()
        .map(|method| method.derived.len())
        .sum::<usize>();
    if derived.len() != expected
        || derived.iter().any(|entry| {
            entry.start >= entry.end
                || text.get(entry.start..entry.end).is_none()
                || entry.anchors.is_empty()
        })
    {
        return None;
    }
    Some((text, derived))
}

/// A family source unit is assembled from physical member records, with only certified body
/// replacements and the one certified capture field omitted. No physical report is mutated.
pub(crate) struct MemberFamilyTextProjection<'a> {
    pub(crate) relation: &'a ClassSourceMemberRelation,
    pub(crate) child: &'a ClassSourceReport,
    pub(crate) capture: Option<&'a MemberCaptureProof>,
    pub(crate) static_target: Option<&'a jarde_java::report::ProvedStaticMemberTarget>,
    pub(crate) generic_static: Option<&'a GenericStaticMemberText>,
    pub(crate) root_methods: &'a [MemberFamilyMethodText],
    pub(crate) child_methods: &'a [MemberFamilyMethodText],
    pub(crate) outer_super_bridges: &'a [OuterSuperBridgeClosureProof],
}

pub(crate) struct GenericStaticMemberText {
    pub(crate) header: String,
    pub(crate) field_index: u64,
    pub(crate) field_declaration: String,
    pub(crate) bridge: PhysicalMethodId,
    pub(crate) bridge_invoke_bci: u32,
}

#[derive(Clone)]
pub(crate) struct MemberFamilyMethodText {
    pub(crate) index: u64,
    pub(crate) text: String,
    /// Ranges in `text`, translated by the family writer when it appends the method.
    pub(crate) derived: Vec<MemberFamilyDerivedProjection>,
}

pub(crate) struct NestedClassSourceText {
    pub(crate) text: String,
    pub(crate) derived: Vec<MemberFamilyDerivedProjection>,
}

/// One root method a member fold omits from the assembled unit — a proved javac access bridge —
/// with the anchors its hidden declaration records.
pub(crate) struct HiddenFoldMethod {
    pub(crate) index: u64,
    pub(crate) anchors: Vec<MemberFamilyPhysicalAnchor>,
}

/// Translate one exact, single-line recovery span through this writer's artifact placement.
/// The equality check catches any drift in the envelope/statements indentation contract.
pub(crate) fn member_family_recovered_span(
    method: &ClassSourceMethod,
    recovery: &RecoveryReport,
    start: usize,
    end: usize,
) -> Option<(usize, usize)> {
    member_family_recovered_span_with_declaration(method, recovery, None, start, end)
}

/// The span mapping of [`member_family_recovered_method_text_with_declaration`]: the same
/// declaration override, so a fold's declaration rewrite moves the spans it publishes by exactly
/// the bytes that rewrite changed.
pub(crate) fn member_family_recovered_span_with_declaration(
    method: &ClassSourceMethod,
    recovery: &RecoveryReport,
    declaration_override: Option<&str>,
    start: usize,
    end: usize,
) -> Option<(usize, usize)> {
    let declaration = declaration_override.unwrap_or(method.declaration.as_ref()?);
    let body = artifact(&recovery.text)?;
    let source = recovery.text.get(start..end)?;
    if source.is_empty() || source.contains('\n') {
        return None;
    }
    let annotations = method
        .annotations
        .uses
        .iter()
        .map(|annotation| 4 + annotation.len() + 1)
        .sum::<usize>();
    let marker_len = if method.has_only_explanation_marker() {
        0
    } else {
        method
            .markers
            .iter()
            .map(|marker| indent(&format!("{marker}\n"), 2).len())
            .sum()
    };
    let block_prefix = annotations + format!("    {declaration} {{\n").len() + marker_len;
    let mapped = placed_artifact_span(&body, start, end, block_prefix)?;
    let text = member_family_recovered_method_text_with_declaration(
        method,
        recovery,
        declaration_override,
    )?;
    (text.get(mapped.0..mapped.1)? == source).then_some(mapped)
}

/// The offset of one body-artifact span inside `block_member`'s placement of that artifact:
/// envelope bytes sit one level in from the class body, statement bytes one level below the
/// declaration — the two depths `block_member` itself indents to — and a span crossing or
/// outside the artifact's own braces has no placement.
fn placed_artifact_span(
    body: &Artifact<'_>,
    start: usize,
    end: usize,
    block_prefix: usize,
) -> Option<(usize, usize)> {
    let envelope_end = body.envelope.len();
    let (part, local_start, local_end, depth, prefix) = if end <= envelope_end {
        (body.envelope, start, end, 2, block_prefix)
    } else {
        let statement_start = envelope_end + 2;
        if start < statement_start || end > statement_start + body.statements.len() {
            return None;
        }
        (
            body.statements,
            start - statement_start,
            end - statement_start,
            1,
            block_prefix + indent(body.envelope, 2).len(),
        )
    };
    let mapped_start = prefix + indented_offset(part, local_start, depth, false)?;
    let mapped_end = prefix + indented_offset(part, local_end, depth, true)?;
    Some((mapped_start, mapped_end))
}

fn indented_offset(text: &str, offset: usize, depth: usize, end_boundary: bool) -> Option<usize> {
    if offset > text.len() || !text.is_char_boundary(offset) {
        return None;
    }
    let mut source = 0;
    let mut written = 0;
    for line in text.split_inclusive('\n') {
        if end_boundary && offset == source {
            return Some(written);
        }
        let padding = if line.trim_end_matches('\n').is_empty() {
            0
        } else {
            4 * depth
        };
        if offset < source + line.len() {
            return Some(written + padding + offset - source);
        }
        written += padding + line.len();
        source += line.len();
    }
    (offset == source).then_some(written)
}

pub(crate) fn member_family_recovered_method_text(
    method: &ClassSourceMethod,
    recovery: &RecoveryReport,
) -> Option<String> {
    member_family_recovered_method_text_with_declaration(method, recovery, None)
}

/// The same reassembly with one projection's own spelling of the declaration: a family fold that
/// renders a nested declaration in this text rewrites the member's declaration line to the source
/// name of the class it folds ([`Self::declaration`]), and both the text and every span the
/// projection publishes have to be computed against that same line or the two drift apart.
pub(crate) fn member_family_recovered_method_text_with_declaration(
    method: &ClassSourceMethod,
    recovery: &RecoveryReport,
    declaration_override: Option<&str>,
) -> Option<String> {
    let declaration = declaration_override.unwrap_or(method.declaration.as_ref()?);
    let body = artifact(&recovery.text)?;
    let markers = if method.has_only_explanation_marker() {
        &[][..]
    } else {
        method.markers.as_slice()
    };
    Some(prefix_method_annotations(
        block_member(declaration, Placed::Block(body), markers),
        &method.annotations,
    ))
}

/// The capture certificate's exact six-instruction template has no source-level constructor
/// work beyond the direct zero-argument super call. Its implicit first parameter and field write
/// are omitted together; ordinary parameters and their annotations retain descriptor positions.
pub(crate) fn member_family_constructor_text(
    method: &ClassSourceMethod,
    simple_name: &str,
) -> Option<String> {
    if method.item.identity.name.0 != b"<init>"
        || method.declaration.is_none()
        || !method.declaration.as_ref()?.ends_with(')')
        || !method.markers.is_empty()
        || !method.annotations.refusals.is_empty()
        || !method.parameter_annotations.refusals.is_empty()
        || !method.type_annotations.refusals.is_empty()
        || !method.type_annotations.field_uses.is_empty()
        || !method.type_annotations.return_uses.is_empty()
        || method.item.access_flags & !(ACC_PUBLIC | ACC_PRIVATE | ACC_PROTECTED) != 0
    {
        return None;
    }
    let signature = method_descriptor(&method.item.identity.descriptor.0, false, false)?;
    if signature.returns.is_some() || signature.parameters.is_empty() {
        return None;
    }
    if method.parameter_annotations.uses_by_position.len() != signature.parameters.len()
        || method.type_annotations.parameter_uses.len() != signature.parameters.len()
    {
        return None;
    }
    if method
        .parameter_annotations
        .uses_by_position
        .first()
        .is_some_and(|uses| !uses.is_empty())
        || method
            .type_annotations
            .parameter_uses
            .first()
            .is_some_and(|uses| !uses.is_empty())
    {
        return None;
    }
    let mut declaration = String::new();
    if let Some(word) = visibility(method.item.access_flags) {
        declaration.push_str(word);
        declaration.push(' ');
    }
    declaration.push_str(simple_name);
    declaration.push('(');
    for (ordinary_index, (ty, _)) in signature.parameters.iter().skip(1).enumerate() {
        if ordinary_index != 0 {
            declaration.push_str(", ");
        }
        let position = ordinary_index + 1;
        for annotation in method
            .parameter_annotations
            .uses_by_position
            .get(position)
            .into_iter()
            .flatten()
        {
            declaration.push_str(annotation);
            declaration.push(' ');
        }
        let type_uses = method
            .type_annotations
            .parameter_uses
            .get(position)
            .map(Vec::as_slice)
            .unwrap_or(&[]);
        let ty = if type_uses.is_empty() {
            ty.clone()
        } else {
            decorate_qualified_type(ty, type_uses)?
        };
        declaration.push_str(&ty);
        declaration.push_str(&format!(" arg{ordinary_index}"));
    }
    declaration.push(')');
    let text = format!("    {declaration} {{\n        super();\n        return;\n    }}\n");
    Some(prefix_method_annotations(text, &method.annotations))
}

pub(crate) fn member_family_source_text(
    root: &ClassSourceReport,
    member: &MemberFamilyTextProjection<'_>,
) -> Option<(String, Vec<MemberFamilyDerivedProjection>)> {
    let declaration = root.declaration.as_ref()?;
    let child_declaration = member.child.declaration.as_ref()?;
    let capture_field = member.capture.and_then(|capture| {
        member
            .child
            .fields
            .iter()
            .find(|field| field.item.index == capture.field_index)
    });
    if root.class != member.relation.root
        || member.child.class != member.relation.child
        || (member.capture.is_some() && capture_field.is_none())
        || member.capture.is_some_and(|capture| capture.constructor.owner != member.child.class)
        // A regenerated capture field cannot preserve extra physical modifiers.
        || capture_field.is_some_and(|field| field.item.access_flags != (ACC_FINAL | 0x1000)
            || !field.annotations.attributes.is_empty()
            || !field.type_annotations.attributes.is_empty())
        || !is_java_identifier(&member.relation.simple_name)
        || (member.generic_static.is_none() && (child_declaration.generic_signature.is_some()
            || child_declaration.generic_refusal.is_some()))
        || !child_declaration.annotation_refusals.is_empty()
        || (member.capture.is_some() && member.relation.access_flags & ACC_STATIC != 0)
        || (member.capture.is_none() && (member.relation.access_flags & ACC_STATIC == 0
            || (member.static_target.is_none_or(|target| target.definition != member.child.class)
                && member.generic_static.is_none())
            || (member.generic_static.is_none() && !member.child.fields.is_empty())))
        || child_declaration.item.declaration.access_flags
            & (ACC_INTERFACE | ACC_ENUM | ACC_ANNOTATION)
            != 0
        || member.child.fields.iter().any(|field| {
            Some(field.item.index) != member.capture.map(|capture| capture.field_index) && field.declaration.is_none()
        })
        || member.outer_super_bridges.iter().any(|closed| {
            closed.calls.is_empty()
                || root
                    .methods
                    .iter()
                    .filter(|method| method.item.identity == closed.bridge.bridge)
                    .count()
                    != 1
                || closed
                    .calls
                    .iter()
                    .any(|call| call.caller.owner != member.child.class || call.bridge != closed.bridge)
        })
        || member.outer_super_bridges.iter().enumerate().any(|(index, closed)| {
            member.outer_super_bridges[index + 1..]
                .iter()
                .any(|other| other.bridge.bridge == closed.bridge.bridge)
        })
    {
        return None;
    }
    // The staged member texts stay out of this rebuild deliberately: a first pass that staged
    // them (a lambda companion rewrite) keeps its pre-existing refusal here, and the assert
    // projection — which refuses beside any staged text — never adds one. The omitted-member and
    // hidden-field channels enter only for a class the assert projection itself staged (one
    // with hidden fields), so every other first pass keeps exactly the equality it had.
    let assert_projected = !root.projection_inputs.hidden_fields.is_empty();
    let context = ClassSourceTextContext {
        initializer_field_order: None,
        declared_methods: root.methods.len() as u64,
        member_table: None,
        execution: &root.execution,
        enum_projection: None,
        array_helper_indices: assert_projected
            .then_some(&root.projection_inputs.omitted_methods[..]),
        array_method_texts: None,
        array_helper_markers: None,
        hidden_fields: assert_projected.then_some(&root.projection_inputs.hidden_fields[..]),
    };
    if source_text(declaration, &root.fields, &root.methods, &context) != root.text {
        return None;
    }
    let mut derived = Vec::new();
    let text = source_text_with_member(
        declaration,
        &root.fields,
        &[],
        &root.methods,
        &context,
        Some(member),
        &[],
        &[],
        &mut derived,
        &[],
    )?;
    let expected = 1
        + usize::from(member.capture.is_none())
        + 3 * usize::from(member.generic_static.is_some())
        + member.outer_super_bridges.len()
        + root.projection_inputs.hidden_fields.len()
        + member.child.projection_inputs.hidden_fields.len()
        + member
            .root_methods
            .iter()
            .map(|method| method.derived.len())
            .sum::<usize>()
        + member
            .child_methods
            .iter()
            .map(|method| method.derived.len())
            .sum::<usize>();
    if derived.len() != expected
        || derived.iter().any(|entry| {
            entry.start >= entry.end
                || text.get(entry.start..entry.end).is_none()
                || entry.anchors.is_empty()
        })
    {
        return None;
    }
    Some((text, derived))
}

/// Assemble the two separately proved declaration-only children inside the existing root writer.
/// The physical root remains the equality baseline, and neither child's text is published alone.
pub(crate) fn declaration_pair_source_text(
    root: &ClassSourceReport,
    members: &[ClassSourceMemberChild; 2],
) -> Option<(String, Vec<MemberFamilyDerivedProjection>)> {
    let declaration = root.declaration.as_ref()?;
    // The same retained-input equality as the narrow writer: the pair composes the physical root
    // the assert projection staged (omitted members and hidden fields included), while every
    // other first pass — staged member texts among them — keeps the refusal it had.
    let assert_projected = !root.projection_inputs.hidden_fields.is_empty();
    let context = ClassSourceTextContext {
        initializer_field_order: None,
        declared_methods: root.methods.len() as u64,
        member_table: None,
        execution: &root.execution,
        enum_projection: None,
        array_helper_indices: assert_projected
            .then_some(&root.projection_inputs.omitted_methods[..]),
        array_method_texts: None,
        array_helper_markers: None,
        hidden_fields: assert_projected.then_some(&root.projection_inputs.hidden_fields[..]),
    };
    if source_text(declaration, &root.fields, &root.methods, &context) != root.text {
        return None;
    }
    let mut nested_text = String::new();
    let mut nested_derived = Vec::new();
    for (index, member) in members.iter().enumerate() {
        if member.relation.root != root.class || member.relation.child != member.child.class {
            return None;
        }
        let mut methods = Vec::new();
        for method in &member.child.methods {
            let mut derived = Vec::new();
            if method.item.identity.name.0 != b"<init>" {
                let declaration = method.declaration.as_ref()?;
                let mut positions = method.text.match_indices(declaration);
                let (start, _) = positions.next()?;
                if positions.next().is_some() {
                    return None;
                }
                derived.push(MemberFamilyDerivedProjection {
                    kind: MemberFamilyDerivedKind::MemberMethodDeclaration,
                    start,
                    end: start + declaration.len(),
                    anchors: vec![MemberFamilyPhysicalAnchor::MethodSignature {
                        method: method.item.identity.clone(),
                    }],
                });
            }
            methods.push(MemberFamilyMethodText {
                index: method.item.index,
                text: method.text.clone(),
                derived,
            });
        }
        let projection = MemberFamilyTextProjection {
            relation: &member.relation,
            child: &member.child,
            capture: None,
            static_target: None,
            generic_static: None,
            root_methods: &[],
            child_methods: &methods,
            outer_super_bridges: &[],
        };
        let (text, derived) = render_member_class(&projection)?;
        if index != 0 {
            nested_text.push('\n');
        }
        let offset = nested_text.len();
        nested_text.push_str(&text);
        nested_derived.extend(derived.into_iter().map(|mut entry| {
            entry.start += offset;
            entry.end += offset;
            entry
        }));
    }
    let nested = NestedClassSourceText {
        text: nested_text,
        derived: nested_derived,
    };
    let mut derived = Vec::new();
    let text = source_text_with_member(
        declaration,
        &root.fields,
        &[],
        &root.methods,
        &context,
        None,
        &[],
        std::slice::from_ref(&nested),
        &mut derived,
        &[],
    )?;
    if derived.len() != 6
        || derived.iter().any(|entry| {
            entry.start >= entry.end
                || text.get(entry.start..entry.end).is_none()
                || entry.anchors.is_empty()
        })
    {
        return None;
    }
    Some((text, derived))
}

fn source_text_with_member(
    declaration: &ClassSourceDeclaration,
    fields: &[ClassSourceField],
    field_texts: &[MemberFamilyMethodText],
    methods: &[ClassSourceMethod],
    context: &ClassSourceTextContext<'_>,
    member_family: Option<&MemberFamilyTextProjection<'_>>,
    method_texts: &[MemberFamilyMethodText],
    nested_classes: &[NestedClassSourceText],
    derived: &mut Vec<MemberFamilyDerivedProjection>,
    hidden_methods: &[HiddenFoldMethod],
) -> Option<String> {
    let initializer_field_order = context.initializer_field_order;
    let declared_methods = context.declared_methods;
    let member_table = context.member_table;
    let execution = context.execution;
    let enum_projection = context.enum_projection;
    let array_helper_indices = context.array_helper_indices;
    let array_method_texts = context.array_method_texts;
    let array_helper_markers = context.array_helper_markers;
    let hidden_fields = context.hidden_fields;
    let mut out = String::new();
    out.push_str(&format!(
        "// jarde: presentation of `{}` from the class file's own declaration and one recovery run per member.\n",
        comment_name(&declaration.item.declaration.this_class)
    ));
    out.push_str(
        "// jarde: not a compilable project: no imports and no resources are claimed (the `package` \
         line is the class file's own name, not a claim about a directory); every place this text is \
         not a full recovery carries a marker of this prefix.\n",
    );
    if let Some(package) = package_name(&declaration.item.declaration.this_class.raw().0) {
        out.push_str(&format!("package {package};\n\n"));
    }
    for use_line in &declaration.annotation_uses {
        out.push_str(use_line);
        out.push('\n');
    }
    for refusal in &declaration.annotation_refusals {
        out.push_str("// jarde: class annotation refused: ");
        out.push_str(refusal);
        out.push('\n');
    }
    if !declaration.annotation_uses.is_empty() || !declaration.annotation_refusals.is_empty() {
        out.push('\n');
    }
    if let Some(signature) = &declaration.generic_signature {
        out.push_str(&format!(
            "// jarde: class Signature `{}` {}\n",
            comment_text(&String::from_utf8_lossy(&signature.0)),
            if declaration.generic_refusal.is_some() {
                "not projected"
            } else if declaration.name.contains('$') {
                "projected after physical parent erasure and nested member proof"
            } else {
                "projected after physical parent erasure proof"
            },
        ));
    }
    if let Some(refusal) = &declaration.generic_refusal {
        out.push_str("// jarde: class Signature projection refused: ");
        out.push_str(&comment_text(refusal));
        out.push('\n');
    }
    let header_start = out.len();
    out.push_str(&declaration.declaration);
    out.push_str(" {\n");
    if let Some(member) = member_family {
        for closed in member.outer_super_bridges {
            derived.push(MemberFamilyDerivedProjection {
                kind: MemberFamilyDerivedKind::HiddenOuterSuperBridge,
                start: header_start,
                end: out.len() - 1,
                anchors: vec![
                    MemberFamilyPhysicalAnchor::MethodPoint {
                        method: closed.bridge.bridge.clone(),
                        bci: closed.bridge.invoke_bci,
                    },
                    MemberFamilyPhysicalAnchor::OuterSuperTarget {
                        method: closed.bridge.target_method.clone(),
                        owner: closed.bridge.target_owner.clone(),
                        name: closed.bridge.target_name.clone(),
                        descriptor: closed.bridge.target_descriptor.clone(),
                    },
                ],
            });
        }
    }
    for hidden in hidden_methods {
        derived.push(MemberFamilyDerivedProjection {
            kind: MemberFamilyDerivedKind::HiddenAccessBridge,
            start: header_start,
            end: out.len() - 1,
            anchors: hidden.anchors.clone(),
        });
    }
    if let Some(markers) = array_helper_markers {
        for marker in markers {
            out.push_str(&indent(&format!("{marker}\n"), 1));
        }
    }
    let mut first = true;
    if let Some(projection) = enum_projection {
        out.push_str(&projection.constants_text);
        first = false;
    }
    let physical_order;
    let field_order = if let Some(order) = initializer_field_order {
        order
    } else {
        physical_order = (0..fields.len()).collect::<Vec<_>>();
        &physical_order
    };
    for &field_index in field_order {
        let field = &fields[field_index];
        if enum_projection.is_some_and(|projection| {
            field.item.index == projection.backing_field_index
                || projection
                    .constant_field_indices
                    .contains(&field.item.index)
        }) {
            continue;
        }
        if hidden_fields.is_some_and(|hidden| hidden.contains(&field.item.index)) {
            // The assert projection proved the field's whole pattern rewritten: the declaration
            // goes with it, and the derived record keeps the physical field anchored on the
            // header it was hidden beside.
            derived.push(MemberFamilyDerivedProjection {
                kind: MemberFamilyDerivedKind::HiddenAssertSwitchField,
                start: header_start,
                end: out.len() - 1,
                anchors: vec![
                    MemberFamilyPhysicalAnchor::Field {
                        field: field.item.identity.clone(),
                        index: field.item.index,
                    },
                    MemberFamilyPhysicalAnchor::ClassDefinition {
                        definition: field.item.identity.owner.clone(),
                    },
                ],
            });
            continue;
        }
        if !first {
            out.push('\n');
        }
        first = false;
        for annotation in &field.annotations.uses {
            out.push_str(&indent(&format!("{annotation}\n"), 1));
        }
        if let Some(projected) = field_texts
            .iter()
            .find(|projected| projected.index == field.item.index)
        {
            let offset = out.len();
            out.push_str(&projected.text);
            for entry in &projected.derived {
                let source_span = projected.text.get(entry.start..entry.end)?;
                let mut translated = entry.clone();
                translated.start += offset;
                translated.end += offset;
                if out.get(translated.start..translated.end) != Some(source_span) {
                    return None;
                }
                derived.push(translated);
            }
        } else {
            match (&field.declaration, field.markers.is_empty()) {
                (Some(declaration), _) => {
                    out.push_str(&declaration_member(declaration, &field.markers))
                }
                (None, _) => out.push_str(&comment_member(&field.markers)),
            }
        }
    }
    if let Some(projection) = enum_projection
        && let Some(initializer_text) = &projection.initializer_text
    {
        if !first {
            out.push('\n');
        }
        first = false;
        out.push_str(initializer_text);
    }
    for method in methods {
        if member_family.is_some_and(|member| {
            member
                .outer_super_bridges
                .iter()
                .any(|closed| closed.bridge.bridge == method.item.identity)
        }) {
            continue;
        }
        if hidden_methods
            .iter()
            .any(|hidden| hidden.index == method.item.index)
        {
            continue;
        }
        if array_helper_indices.is_some_and(|indices| indices.contains(&method.item.index)) {
            continue;
        }
        if let Some(projection) = enum_projection {
            if let Some((_, constructor_text)) = projection
                .constructor_texts
                .iter()
                .find(|(index, _)| *index == method.item.index)
            {
                if !first {
                    out.push('\n');
                }
                first = false;
                out.push_str(constructor_text);
                continue;
            }
            if projection
                .implicit_method_indices
                .contains(&method.item.index)
            {
                continue;
            }
        }
        if (initializer_field_order.is_some() || enum_projection.is_some())
            && method.item.identity.name.0 == b"<clinit>"
            && method.item.identity.descriptor.0 == b"()V"
        {
            continue;
        }
        if !first {
            out.push('\n');
        }
        first = false;
        if let Some(projected) = member_family.and_then(|member| {
            member
                .root_methods
                .iter()
                .find(|projected| projected.index == method.item.index)
        }) {
            append_family_method(&mut out, projected, false, derived)?;
        } else if let Some(projected) = method_texts
            .iter()
            .find(|projected| projected.index == method.item.index)
        {
            append_family_method(&mut out, projected, false, derived)?;
        } else if let Some((_, projected)) = array_method_texts
            .and_then(|texts| texts.iter().find(|(index, _)| *index == method.item.index))
        {
            out.push_str(projected);
        } else {
            out.push_str(&method.text);
        }
    }
    let presented = u64::try_from(methods.len()).unwrap_or(u64::MAX);
    let mut trailing = Vec::new();
    match member_table {
        // The walk stopped inside a member record: what the members behind it are is not read, so no
        // count of them is stated here — the stop's own code and position are what the bytes say.
        Some(stop) => trailing.push(format!(
            "// jarde: the class file's member table stopped at {}[{}] ({}); the members above are \
             the reliable prefix and this presentation lists no others",
            table_name(stop),
            stop.index,
            comment_text(&stop.code)
        )),
        None if presented < declared_methods => trailing.push(format!(
            "// jarde: the class file declares {declared_methods} method record(s) and {presented} \
             were presented: the request stopped before the rest ({})",
            stop_code(execution).unwrap_or_else(|| "reason not stated".to_owned())
        )),
        None => {}
    }
    if !trailing.is_empty() {
        out.push('\n');
        for marker in trailing {
            out.push_str(&indent(&format!("{marker}\n"), 1));
        }
    }
    if let Some(member) = member_family {
        if !first {
            out.push('\n');
        }
        let offset = out.len();
        let (child_text, child_derived) = render_member_class(member)?;
        out.push_str(&child_text);
        derived.extend(child_derived.into_iter().map(|mut entry| {
            entry.start += offset;
            entry.end += offset;
            entry
        }));
    }
    for nested in nested_classes {
        if !first {
            out.push('\n');
        }
        let offset = out.len();
        out.push_str(&nested.text);
        derived.extend(nested.derived.iter().cloned().map(|mut entry| {
            entry.start += offset;
            entry.end += offset;
            entry
        }));
    }
    out.push_str("}\n");
    Some(out)
}

fn render_member_class(
    member: &MemberFamilyTextProjection<'_>,
) -> Option<(String, Vec<MemberFamilyDerivedProjection>)> {
    let child = member.child;
    let declaration = child
        .declaration
        .as_ref()
        .expect("validated child declaration");
    let mut facts = declaration.item.declaration.clone();
    const SOURCE_CLASS_FLAGS: u16 = ACC_PUBLIC
        | ACC_PRIVATE
        | ACC_PROTECTED
        | ACC_ABSTRACT
        | ACC_FINAL
        | ACC_STRICT
        | ACC_STATIC;
    facts.access_flags = (facts.access_flags & !SOURCE_CLASS_FLAGS)
        | (member.relation.access_flags & SOURCE_CLASS_FLAGS);
    let mut out = String::new();
    let mut derived = Vec::new();
    for annotation in &declaration.annotation_uses {
        out.push_str(&indent(&format!("{annotation}\n"), 1));
    }
    let mut class_header_declaration = member.generic_static.map_or_else(
        || class_declaration(&member.relation.simple_name, &facts),
        |generic| generic.header.clone(),
    );
    if member.relation.access_flags & ACC_STATIC != 0 {
        let visibility_len = ["public ", "protected ", "private "]
            .iter()
            .find(|prefix| class_header_declaration.starts_with(**prefix))
            .map_or(0, |prefix| prefix.len());
        class_header_declaration.insert_str(visibility_len, "static ");
    }
    let class_header = indent(&format!("{class_header_declaration} {{\n"), 1);
    let header_start = out.len();
    out.push_str(&class_header);
    if let Some(capture) = member.capture {
        let capture_field = child
            .fields
            .iter()
            .find(|field| field.item.index == capture.field_index)
            .expect("validated capture field");
        derived.push(MemberFamilyDerivedProjection {
            kind: MemberFamilyDerivedKind::HiddenCaptureField,
            start: header_start,
            end: out.len() - 1,
            anchors: vec![MemberFamilyPhysicalAnchor::Field {
                field: capture_field.item.identity.clone(),
                index: capture_field.item.index,
            }],
        });
    } else {
        derived.push(MemberFamilyDerivedProjection {
            kind: MemberFamilyDerivedKind::MemberClassDeclaration,
            start: header_start,
            end: out.len() - 1,
            anchors: vec![
                MemberFamilyPhysicalAnchor::ClassDefinition {
                    definition: member.relation.child.clone(),
                },
                MemberFamilyPhysicalAnchor::ClassDefinition {
                    definition: member.relation.root.clone(),
                },
            ],
        });
    }
    if let Some(generic) = member.generic_static {
        derived.push(MemberFamilyDerivedProjection {
            kind: MemberFamilyDerivedKind::MemberGenericSignature,
            start: header_start,
            end: out.len() - 1,
            anchors: vec![MemberFamilyPhysicalAnchor::ClassDefinition {
                definition: member.relation.child.clone(),
            }],
        });
        derived.push(MemberFamilyDerivedProjection {
            kind: MemberFamilyDerivedKind::MemberMethodDeclaration,
            start: header_start,
            end: out.len() - 1,
            anchors: vec![MemberFamilyPhysicalAnchor::MethodPoint {
                method: generic.bridge.clone(),
                bci: generic.bridge_invoke_bci,
            }],
        });
    }
    let mut first = true;
    for field in &child.fields {
        if member
            .capture
            .is_some_and(|capture| field.item.index == capture.field_index)
        {
            continue;
        }
        if child
            .projection_inputs
            .hidden_fields
            .contains(&field.item.index)
        {
            // The child's own assert projection hid this field; the nested rendering hides it
            // too, anchored beside the header its flat text anchored it on.
            derived.push(MemberFamilyDerivedProjection {
                kind: MemberFamilyDerivedKind::HiddenAssertSwitchField,
                start: header_start,
                end: out.len() - 1,
                anchors: vec![MemberFamilyPhysicalAnchor::Field {
                    field: field.item.identity.clone(),
                    index: field.item.index,
                }],
            });
            continue;
        }
        if !first {
            out.push('\n');
        }
        first = false;
        for annotation in &field.annotations.uses {
            out.push_str(&indent(&format!("{annotation}\n"), 2));
        }
        let text = match &field.declaration {
            Some(_)
                if member
                    .generic_static
                    .is_some_and(|generic| generic.field_index == field.item.index) =>
            {
                declaration_member(&member.generic_static.unwrap().field_declaration, &[])
            }
            Some(declaration) => declaration_member(declaration, &field.markers),
            None => comment_member(&field.markers),
        };
        let field_start = out.len();
        out.push_str(&indent(&text, 1));
        if member
            .generic_static
            .is_some_and(|generic| generic.field_index == field.item.index)
        {
            derived.push(MemberFamilyDerivedProjection {
                kind: MemberFamilyDerivedKind::MemberGenericSignature,
                start: field_start,
                end: out.len() - 1,
                anchors: vec![MemberFamilyPhysicalAnchor::Field {
                    field: field.item.identity.clone(),
                    index: field.item.index,
                }],
            });
        }
    }
    for method in &child.methods {
        if member
            .generic_static
            .is_some_and(|generic| generic.bridge == method.item.identity)
        {
            continue;
        }
        // A member the child's own assert projection omitted (its switch line was all its
        // `<clinit>` held) carries no declaration here either, exactly as the child's flat text
        // omits it. Other first passes keep their members here as before: this channel reaches
        // the nested writer only beside the child's hidden fields.
        if !child.projection_inputs.hidden_fields.is_empty()
            && child
                .projection_inputs
                .omitted_methods
                .contains(&method.item.index)
        {
            continue;
        }
        if !first {
            out.push('\n');
        }
        first = false;
        if let Some(projected) = member
            .child_methods
            .iter()
            .find(|projected| projected.index == method.item.index)
        {
            let mut projected = projected.clone();
            if method.item.identity.name.0 == b"<init>" && member.capture.is_none() {
                let old_name = &declaration.name;
                let old_token = format!("{old_name}(");
                let Some(local_start) = projected.text.find(&old_token) else {
                    return None;
                };
                let local_end = local_start + old_name.len();
                projected
                    .text
                    .replace_range(local_start..local_end, &member.relation.simple_name);
                projected.derived.push(MemberFamilyDerivedProjection {
                    kind: MemberFamilyDerivedKind::MemberConstructorName,
                    start: local_start,
                    end: local_start + member.relation.simple_name.len(),
                    anchors: vec![
                        MemberFamilyPhysicalAnchor::MethodPoint {
                            method: method.item.identity.clone(),
                            bci: 0,
                        },
                        MemberFamilyPhysicalAnchor::ClassDefinition {
                            definition: member.relation.child.clone(),
                        },
                    ],
                });
            }
            append_family_method(&mut out, &projected, true, &mut derived)?;
        } else {
            out.push_str(&indent(&method.text, 1));
        }
    }
    out.push_str("    }\n");
    Some((out, derived))
}

fn append_family_method(
    out: &mut String,
    method: &MemberFamilyMethodText,
    nested: bool,
    derived: &mut Vec<MemberFamilyDerivedProjection>,
) -> Option<()> {
    let offset = out.len();
    if nested {
        out.push_str(&indent(&method.text, 1));
    } else {
        out.push_str(&method.text);
    }
    for entry in &method.derived {
        let mut entry = entry.clone();
        if nested {
            let source_span = method.text.get(entry.start..entry.end)?;
            let start = indented_offset(&method.text, entry.start, 1, false)?;
            let end = indented_offset(&method.text, entry.end, 1, true)?;
            entry.start = offset + start;
            entry.end = offset + end;
            if out.get(entry.start..entry.end) != Some(source_span) {
                return None;
            }
        } else {
            entry.start += offset;
            entry.end += offset;
        }
        derived.push(entry);
    }
    Some(())
}

/// Render one direct static member as a nested declaration of the fold's own source unit, from the
/// child's typed declaration and member records. The child's physical report text is never parsed
/// or sliced: the header is rebuilt from the row's own flags with the fold's spelling of the types
/// it names, staged field and method texts carry the re-spelled references, and every physical
/// constructor is renamed to the member's own source name — the pool's `$` name it came in with is
/// not a name the nested unit can resolve. The staged texts' derived ranges are translated through
/// this writer's placement, exactly as the family method writer does.
/// The synthetic members one proved non-static child elides inside a fold's nested declaration:
/// the capture field's row and the constructor's synthetic first parameter. The write statement
/// itself is removed from the staged constructor text before this renderer sees it.
#[derive(Clone, Copy)]
pub(crate) struct InstanceMemberElision {
    pub(crate) capture_field_index: u64,
}

/// The first pass's own class-text projection channels a nested child block carries beside its
/// staged texts: the members its projection omitted, its marker lines, and the member texts its
/// projection substituted. The enum-constant and initializer projections are deliberately absent
/// — a child whose first pass staged either is refused at the fold's child gate rather than
/// degraded here.
pub(crate) struct NestedRetainedTexts<'a> {
    pub(crate) omitted_methods: &'a [u64],
    pub(crate) markers: &'a [String],
    pub(crate) member_texts: &'a [ClassSourceProjectedMemberText],
    pub(crate) hidden_fields: &'a [u64],
}

pub(crate) fn nested_static_member_source_text(
    simple_name: &str,
    access_flags: u16,
    declaration: &ClassSourceDeclaration,
    fields: &[ClassSourceField],
    field_texts: &[MemberFamilyMethodText],
    methods: &[ClassSourceMethod],
    method_texts: &[MemberFamilyMethodText],
    fold_targets: &[(&str, &str)],
    child_definition: PhysicalDefinitionId,
    root_definition: PhysicalDefinitionId,
    elision: Option<InstanceMemberElision>,
    retained: &NestedRetainedTexts<'_>,
) -> Option<NestedClassSourceText> {
    const SOURCE_CLASS_FLAGS: u16 = ACC_PUBLIC
        | ACC_PRIVATE
        | ACC_PROTECTED
        | ACC_ABSTRACT
        | ACC_FINAL
        | ACC_STRICT
        | ACC_STATIC;
    let rewrite = |name: &str| -> String {
        fold_targets
            .iter()
            .find_map(|(pool, spelling)| (name == *pool).then(|| (*spelling).to_owned()))
            .unwrap_or_else(|| name.to_owned())
    };
    let mut facts = declaration.item.declaration.clone();
    facts.access_flags =
        (facts.access_flags & !SOURCE_CLASS_FLAGS) | (access_flags & SOURCE_CLASS_FLAGS);
    let superclass = facts
        .super_class
        .as_ref()
        .map(|super_class| rewrite(&class_name(&super_class.raw().0)));
    let interfaces = facts
        .interfaces
        .iter()
        .map(|interface| rewrite(&class_name(&interface.raw().0)))
        .collect::<Vec<_>>();
    // A child whose own run projected its type-parameter header carries it verbatim: that
    // projection is the one Signature position this nested rebuild already spells every other
    // part of (row flags, physical parents), so the two spellings cannot diverge.
    let mut class_header_declaration = class_declaration_with_types(
        simple_name,
        &facts,
        declaration.generic_type_parameters.as_deref(),
        superclass.as_deref(),
        Some(&interfaces),
    );
    if access_flags & ACC_STATIC != 0 {
        let visibility_len = ["public ", "protected ", "private "]
            .iter()
            .find(|prefix| class_header_declaration.starts_with(**prefix))
            .map_or(0, |prefix| prefix.len());
        class_header_declaration.insert_str(visibility_len, "static ");
    }
    let mut text = String::new();
    let mut derived = Vec::new();
    for annotation in &declaration.annotation_uses {
        text.push_str(&indent(&format!("{annotation}\n"), 1));
    }
    for refusal in &declaration.annotation_refusals {
        text.push_str(&indent(
            &format!("// jarde: class annotation refused: {refusal}\n"),
            1,
        ));
    }
    let header_line = indent(&format!("{class_header_declaration} {{\n"), 1);
    let own_start = text.len() + "    ".len();
    text.push_str(&header_line);
    derived.push(MemberFamilyDerivedProjection {
        kind: MemberFamilyDerivedKind::MemberClassDeclaration,
        start: own_start,
        end: text.len() - 1,
        anchors: vec![
            MemberFamilyPhysicalAnchor::ClassDefinition {
                definition: child_definition.clone(),
            },
            MemberFamilyPhysicalAnchor::ClassDefinition {
                definition: root_definition.clone(),
            },
        ],
    });
    let hidden_span = (own_start, text.len() - 1);
    // The first pass's own marker lines — omitted helper and projection notes — sit directly
    // under the header, before any member, exactly where the flat unit placed them.
    for marker in retained.markers {
        text.push_str(&indent(&format!("{marker}\n"), 2));
    }
    let mut first = true;
    for field in fields {
        if elision.is_some_and(|elision| elision.capture_field_index == field.item.index) {
            // The synthetic capture field's declaration is hidden with its constructor
            // parameter: the fold's own text never names it, and the derived record keeps
            // the physical field it removed, anchored on the declaration it hides beside.
            derived.push(MemberFamilyDerivedProjection {
                kind: MemberFamilyDerivedKind::HiddenCaptureField,
                start: hidden_span.0,
                end: hidden_span.1,
                anchors: vec![
                    MemberFamilyPhysicalAnchor::Field {
                        field: field.item.identity.clone(),
                        index: field.item.index,
                    },
                    MemberFamilyPhysicalAnchor::ClassDefinition {
                        definition: child_definition.clone(),
                    },
                ],
            });
            continue;
        }
        if retained.hidden_fields.contains(&field.item.index) {
            // The child's own assert projection proved its switch field rewritten; the fold's
            // nested rendering keeps that hiding, anchored beside the header as its flat text
            // was.
            derived.push(MemberFamilyDerivedProjection {
                kind: MemberFamilyDerivedKind::HiddenAssertSwitchField,
                start: hidden_span.0,
                end: hidden_span.1,
                anchors: vec![
                    MemberFamilyPhysicalAnchor::Field {
                        field: field.item.identity.clone(),
                        index: field.item.index,
                    },
                    MemberFamilyPhysicalAnchor::ClassDefinition {
                        definition: child_definition.clone(),
                    },
                ],
            });
            continue;
        }
        if !first {
            text.push('\n');
        }
        first = false;
        for annotation in &field.annotations.uses {
            text.push_str(&indent(&format!("{annotation}\n"), 2));
        }
        if let Some(projected) = field_texts
            .iter()
            .find(|projected| projected.index == field.item.index)
        {
            let offset = text.len();
            text.push_str(&indent(&projected.text, 1));
            for entry in &projected.derived {
                let source_span = projected.text.get(entry.start..entry.end)?;
                let start = indented_offset(&projected.text, entry.start, 1, false)?;
                let end = indented_offset(&projected.text, entry.end, 1, true)?;
                let mut translated = entry.clone();
                translated.start = offset + start;
                translated.end = offset + end;
                if text.get(translated.start..translated.end) != Some(source_span) {
                    return None;
                }
                derived.push(translated);
            }
        } else {
            let member = match &field.declaration {
                Some(declaration) => declaration_member(declaration, &field.markers),
                None => comment_member(&field.markers),
            };
            text.push_str(&indent(&member, 1));
        }
    }
    for method in methods {
        // A member the first pass's projection omitted carries no declaration here either: its
        // uses were rewritten in the retained member texts, and the physical record stays in the
        // child's own report.
        if retained.omitted_methods.contains(&method.item.index) {
            continue;
        }
        if !first {
            text.push('\n');
        }
        first = false;
        // A member whose body the first pass projected keeps that projected text here — the
        // fold's own staged texts (method_texts) still win, because those are the ones carrying
        // the fold's re-spelled references.
        let mut staged = method_texts
            .iter()
            .find(|projected| projected.index == method.item.index)
            .cloned()
            .or_else(|| {
                retained
                    .member_texts
                    .iter()
                    .find(|projected| projected.member == method.item.index)
                    .map(|projected| MemberFamilyMethodText {
                        index: method.item.index,
                        text: projected.text.clone(),
                        derived: Vec::new(),
                    })
            })
            .unwrap_or_else(|| MemberFamilyMethodText {
                index: method.item.index,
                text: method.text.clone(),
                derived: Vec::new(),
            });
        if method.item.identity.name.0 == b"<init>" {
            let old_name = &declaration.name;
            let old_token = format!("{old_name}(");
            let Some(local_start) = staged.text.find(&old_token) else {
                return None;
            };
            let local_end = local_start + old_name.len();
            staged
                .text
                .replace_range(local_start..local_end, simple_name);
            staged.derived.push(MemberFamilyDerivedProjection {
                kind: MemberFamilyDerivedKind::MemberConstructorName,
                start: local_start,
                end: local_start + simple_name.len(),
                anchors: vec![
                    MemberFamilyPhysicalAnchor::MethodPoint {
                        method: method.item.identity.clone(),
                        bci: 0,
                    },
                    MemberFamilyPhysicalAnchor::ClassDefinition {
                        definition: child_definition.clone(),
                    },
                ],
            });
            if elision.is_some() {
                // The synthetic first parameter leaves the constructor's source list: the
                // descriptor's first parameter is the proved Outer capture, and the capture
                // write that consumed it is already gone from the staged body. Derived ranges
                // the facade staged after this list move by exactly the bytes dropped, plus
                // the rename's own delta.
                let list_start = local_start + simple_name.len() + "(".len();
                let Some(drop) = top_level_parameter_end(&staged.text, list_start) else {
                    return None;
                };
                let name_delta = simple_name.len() as isize - old_name.len() as isize;
                staged.text.replace_range(list_start..drop, "");
                shift_derived_ranges(
                    &mut staged.derived,
                    local_start + old_name.len(),
                    name_delta - (drop - list_start) as isize,
                );
                // The hidden capture write's record keeps the declaration line as its span: the
                // line itself just changed length, so the range is re-clamped to it.
                let line_end = staged.text.find('\n').unwrap_or(staged.text.len());
                for entry in &mut staged.derived {
                    if entry.kind == MemberFamilyDerivedKind::HiddenCaptureWrite {
                        entry.start = entry.start.min(line_end);
                        entry.end = line_end;
                    }
                }
                staged.derived.push(MemberFamilyDerivedProjection {
                    kind: MemberFamilyDerivedKind::HiddenConstructorParameter,
                    start: local_start,
                    end: local_start + simple_name.len() + "()".len(),
                    anchors: vec![
                        MemberFamilyPhysicalAnchor::ConstructorParameter {
                            method: method.item.identity.clone(),
                            index: 0,
                        },
                        MemberFamilyPhysicalAnchor::ClassDefinition {
                            definition: child_definition.clone(),
                        },
                    ],
                });
            }
        }
        let offset = text.len();
        text.push_str(&indent(&staged.text, 1));
        for entry in &staged.derived {
            let Some(source_span) = staged.text.get(entry.start..entry.end) else {
                return None;
            };
            let Some(start) = indented_offset(&staged.text, entry.start, 1, false) else {
                return None;
            };
            let Some(end) = indented_offset(&staged.text, entry.end, 1, true) else {
                return None;
            };
            let mut translated = entry.clone();
            translated.start = offset + start;
            translated.end = offset + end;
            if text.get(translated.start..translated.end) != Some(source_span) {
                return None;
            }
            derived.push(translated);
        }
    }
    text.push_str("    }\n");
    Some(NestedClassSourceText { text, derived })
}

/// The end of a constructor's first source parameter: just past the first top-level separator,
/// or at the closing parenthesis when the list holds only that parameter. The list begins just
/// after its opening parenthesis; generic angle brackets, annotations, nested parentheses and
/// literals never separate parameters.
fn top_level_parameter_end(text: &str, open: usize) -> Option<usize> {
    let bytes = text.as_bytes();
    let mut depth = 1isize;
    let mut angles = 0isize;
    let mut index = open;
    let mut literal: Option<u8> = None;
    let mut escaped = false;
    while index < bytes.len() {
        let byte = bytes[index];
        if let Some(quote) = literal {
            if escaped {
                escaped = false;
            } else if byte == b'\\' {
                escaped = true;
            } else if byte == quote {
                literal = None;
            }
        } else if byte == b'"' || byte == b'\'' {
            literal = Some(byte);
        } else {
            match byte {
                b'(' => depth += 1,
                b')' => {
                    depth -= 1;
                    if depth == 0 {
                        return Some(index);
                    }
                }
                b'<' => angles += 1,
                b'>' => angles -= 1,
                b',' if depth == 1 && angles == 0 => {
                    let mut end = index + 1;
                    if bytes.get(end) == Some(&b' ') {
                        end += 1;
                    }
                    return Some(end);
                }
                _ => {}
            }
        }
        index += 1;
    }
    None
}

/// Move every derived range that begins at or after `from` by `delta` byte positions.
fn shift_derived_ranges(derived: &mut [MemberFamilyDerivedProjection], from: usize, delta: isize) {
    for entry in derived.iter_mut() {
        if entry.start >= from {
            entry.start = (entry.start as isize + delta).max(0) as usize;
            entry.end = (entry.end as isize + delta).max(0) as usize;
        }
    }
}

/// Render a proved enum as a lexical member using the child's typed declaration and member
/// records. The physical report text is never parsed or sliced.
pub(crate) fn nested_enum_source_text(
    simple_name: &str,
    access_flags: u16,
    declaration: &ClassSourceDeclaration,
    fields: &[ClassSourceField],
    methods: &[ClassSourceMethod],
    enum_projection: &EnumConstantSourceProjection,
    method_texts: &[MemberFamilyMethodText],
    descendant: Option<&NestedClassSourceText>,
    anchors: Vec<MemberFamilyPhysicalAnchor>,
) -> Option<NestedClassSourceText> {
    const SOURCE_CLASS_FLAGS: u16 =
        ACC_PUBLIC | ACC_PRIVATE | ACC_PROTECTED | ACC_ABSTRACT | ACC_FINAL | ACC_STRICT;
    let mut facts = declaration.item.declaration.clone();
    facts.access_flags =
        (facts.access_flags & !SOURCE_CLASS_FLAGS) | (access_flags & SOURCE_CLASS_FLAGS);
    let header = nested_member_class_header(simple_name, &facts);
    let mut text = format!("    {header} {{\n");
    let own_start = "    ".len();
    let mut derived = Vec::new();
    let mut first = true;
    text.push_str(&indent(&enum_projection.constants_text, 1));
    if !enum_projection.constants_text.is_empty() {
        first = false;
    }
    for field in fields {
        if field.item.index == enum_projection.backing_field_index
            || enum_projection
                .constant_field_indices
                .contains(&field.item.index)
        {
            continue;
        }
        if !first {
            text.push('\n');
        }
        first = false;
        for annotation in &field.annotations.uses {
            text.push_str(&indent(&format!("{annotation}\n"), 2));
        }
        let member = match &field.declaration {
            Some(declaration) => declaration_member(declaration, &field.markers),
            None => comment_member(&field.markers),
        };
        text.push_str(&indent(&member, 1));
    }
    if let Some(initializer) = &enum_projection.initializer_text {
        if !first {
            text.push('\n');
        }
        first = false;
        text.push_str(&indent(initializer, 1));
    }
    for method in methods {
        if let Some((_, replacement)) = enum_projection
            .constructor_texts
            .iter()
            .find(|(index, _)| *index == method.item.index)
        {
            if !first {
                text.push('\n');
            }
            first = false;
            text.push_str(&indent(replacement, 1));
            continue;
        }
        if enum_projection
            .implicit_method_indices
            .contains(&method.item.index)
            || (enum_projection.initializer_text.is_some()
                && method.item.identity.name.0 == b"<clinit>"
                && method.item.identity.descriptor.0 == b"()V")
        {
            continue;
        }
        if !first {
            text.push('\n');
        }
        first = false;
        let Some(replacement) = method_texts
            .iter()
            .find(|replacement| replacement.index == method.item.index)
        else {
            text.push_str(&indent(&method.text, 1));
            continue;
        };
        let offset = text.len();
        text.push_str(&indent(&replacement.text, 1));
        for entry in &replacement.derived {
            let source_span = replacement.text.get(entry.start..entry.end)?;
            let start = indented_offset(&replacement.text, entry.start, 1, false)?;
            let end = indented_offset(&replacement.text, entry.end, 1, true)?;
            let mut translated = entry.clone();
            translated.start = offset + start;
            translated.end = offset + end;
            if text.get(translated.start..translated.end) != Some(source_span) {
                return None;
            }
            derived.push(translated);
        }
    }
    if let Some(descendant) = descendant {
        if !first {
            text.push('\n');
        }
        let offset = text.len();
        let descendant_text = indent(&descendant.text, 1);
        text.push_str(&descendant_text);
        for entry in &descendant.derived {
            let start = indented_offset(&descendant.text, entry.start, 1, false)?;
            let end = indented_offset(&descendant.text, entry.end, 1, true)?;
            let mut translated = entry.clone();
            translated.start = offset + start;
            translated.end = offset + end;
            if translated.start >= translated.end
                || !text.is_char_boundary(translated.start)
                || !text.is_char_boundary(translated.end)
            {
                return None;
            }
            derived.push(translated);
        }
    }
    text.push_str("    }\n");
    derived.push(MemberFamilyDerivedProjection {
        kind: MemberFamilyDerivedKind::NestedEnumDeclaration,
        start: own_start,
        end: text.len() - 1,
        anchors,
    });
    Some(NestedClassSourceText { text, derived })
}

/// The name of the member table one stop happened in.
fn table_name(stop: &MemberTableStop) -> &'static str {
    match stop.phase {
        crate::MemberTablePhase::Fields => "fields",
        crate::MemberTablePhase::Methods => "methods",
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use jarde_java::report::GenericConstructorFieldWrite;

    const MEMBER_ANNOTATION_TARGET: &[u8] = include_bytes!(
        "../openspec/evidence/java-syntax-2026-09-22/member-annotation-uses/generated/original/MemberTagged.class"
    );

    #[test]
    fn raw_receiver_assignment_uses_java_reference_and_array_erasure_rules() {
        let java_release = 8;
        for (source, target) in [
            (
                b"Ljava/lang/String;".as_slice(),
                b"Ljava/lang/Object;".as_slice(),
            ),
            (
                b"[Ljava/lang/String;".as_slice(),
                b"[Ljava/lang/Object;".as_slice(),
            ),
            (
                b"[[Ljava/lang/String;".as_slice(),
                b"[[Ljava/lang/Object;".as_slice(),
            ),
            (b"[I".as_slice(), b"Ljava/lang/Object;".as_slice()),
            (
                b"[[Ljava/lang/Object;".as_slice(),
                b"[Ljava/lang/Object;".as_slice(),
            ),
            (b"[[I".as_slice(), b"[Ljava/lang/Object;".as_slice()),
            (b"[I".as_slice(), b"Ljava/lang/Cloneable;".as_slice()),
        ] {
            assert!(descriptor_reference_assignable(
                source,
                target,
                java_release
            ));
        }
        for (source, target) in [
            (b"[I".as_slice(), b"[Ljava/lang/Object;".as_slice()),
            (b"[I".as_slice(), b"[J".as_slice()),
            (
                b"[Ljava/lang/Object;".as_slice(),
                b"[Ljava/lang/Number;".as_slice(),
            ),
        ] {
            assert!(!descriptor_reference_assignable(
                source,
                target,
                java_release
            ));
        }
    }

    #[test]
    fn raw_receiver_type_proof_propagates_budget_and_cancellation() {
        let method = generic_void_probe().0.item.identity;
        let use_site = SameClassFieldUse {
            caller: "set".to_owned(),
            physical_method: method.clone(),
            bci: 12,
            opcode: 0xb5,
            owner: b"probe/Bound".to_vec(),
            name: b"value".to_vec(),
            descriptor: b"Ljava/lang/Object;".to_vec(),
            read_expressible: None,
            write_source: Some(SameClassFieldWriteSource::Null),
            receiver_source: Some(SameClassFieldReceiverSource::Parameter { slot: 0 }),
            source_complete: true,
        };
        let published = [SameClassPublishedMethodParameters {
            method,
            parameter_slots: vec![0],
            descriptor_parameters: vec![b"Lprobe/Bound;".to_vec()],
            generic_parameters: None,
            method_type_parameters: Vec::new(),
        }];

        assert!(
            raw_field_receiver_source(
                &use_site,
                b"probe/Bound",
                true,
                &published,
                &mut Budget::new(unlimited_annotation_test_limits()),
            )
            .expect("a published generic class can have a raw formal")
        );
        assert!(
            !raw_field_receiver_source(
                &use_site,
                b"probe/Bound",
                false,
                &published,
                &mut Budget::new(unlimited_annotation_test_limits()),
            )
            .expect("an ordinary nongeneric class reference is not a raw type")
        );

        let mut limits = unlimited_annotation_test_limits();
        limits.analysis_steps = 0;
        let mut budget = Budget::new(limits);
        assert!(matches!(
            raw_field_receiver_source(&use_site, b"probe/Bound", true, &published, &mut budget),
            Err(Error::BudgetExceeded {
                dimension: crate::BudgetDimension::AnalysisSteps,
                ..
            })
        ));

        let cancellation = crate::CancellationToken::new();
        cancellation.cancel();
        let mut budget =
            Budget::with_cancellation_token(unlimited_annotation_test_limits(), cancellation);
        assert!(matches!(
            raw_field_receiver_source(&use_site, b"probe/Bound", true, &published, &mut budget),
            Err(Error::Cancelled { .. })
        ));
    }

    fn unlimited_annotation_test_limits() -> Limits {
        Limits {
            input_bytes: u64::MAX,
            archive_entries: u64::MAX,
            entry_bytes: u64::MAX,
            read_bytes: u64::MAX,
            class_bytes: u64::MAX,
            attribute_bytes: u64::MAX,
            code_bytes: u64::MAX,
            result_items: u64::MAX,
            output_bytes: u64::MAX,
            class_headers: u64::MAX,
            method_bodies: u64::MAX,
            ir_items: u64::MAX,
            ir_edges: u64::MAX,
            analysis_steps: u64::MAX,
            normalization_clones: u64::MAX,
            nested_depth: u64::MAX,
            dependency_depth: u64::MAX,
            elapsed_millis: u64::MAX,
        }
    }

    fn generic_void_probe() -> (
        ClassSourceMethod,
        MemberAttributes,
        jarde_reader::signature::MethodSignature,
        GenericReturnCandidate,
        Vec<jarde_reader::signature::TypeParameterErasure>,
    ) {
        use jarde_reader::model::{
            ClassBytesId, Digest, PhysicalClassLocation, PhysicalVariant, SnapshotId,
        };
        use jarde_reader::signature::{ClassType, ClassTypeSegment, SignatureType, TypeParameter};

        let owner = PhysicalDefinitionId {
            location: PhysicalClassLocation::StandaloneRoot {
                snapshot: SnapshotId("void-generic-probe".to_owned()),
            },
            class_bytes: ClassBytesId {
                digest: Digest("void-generic-probe".to_owned()),
                length: 0,
            },
            variant: PhysicalVariant::Base,
        };
        let descriptor_bytes = b"(Lprobe/Bound;Z)V".to_vec();
        let jvm_string = |value: &[u8]| {
            let text = std::str::from_utf8(value).expect("probe strings are ASCII");
            serde_json::from_value(serde_json::json!({
                "raw": value,
                "utf16": value.iter().map(|byte| u16::from(*byte)).collect::<Vec<_>>(),
                "escaped": text,
            }))
            .expect("valid probe JVM string")
        };
        let name: JvmString = jvm_string(b"set");
        let descriptor: JvmString = jvm_string(&descriptor_bytes);
        let method = MethodItem {
            index: 0,
            identity: PhysicalMethodId {
                owner,
                name: JvmBytes(b"set".to_vec()),
                descriptor: JvmBytes(descriptor_bytes.clone()),
            },
            name,
            descriptor,
            access_flags: ACC_PUBLIC,
            body: crate::facade::MemberBodyEvidence::CodeAttribute {
                content_span: jarde_reader::model::ByteSpan::new(0, 0),
            },
        };
        let record = ClassSourceMethod {
            item: method,
            no_body_kind: None,
            declaration: Some("public void set(probe.Bound arg1, boolean arg2)".to_owned()),
            annotations: MemberAnnotationUses::default(),
            parameter_annotations: ParameterAnnotationUses::default(),
            type_annotations: TypeAnnotationUses::default(),
            text: "    public void set(probe.Bound arg1, boolean arg2) { }\n".to_owned(),
            markers: Vec::new(),
            outcome: ClassSourceOutcome::NoBody,
            same_run_generic_return: None,
            same_class_generic_body_proof: None,
            generic_signature_refused: false,
            generic_signature_projected: false,
            enum_constructor_source_tail: EnumConstructorSourceTail::Unrecognized,
            enum_constructor_signature_erasure_refused: false,
        };
        let attributes = MemberAttributes {
            default: None,
            throws: Vec::new(),
            throws_raw: Vec::new(),
            parameters: None,
        };
        let parsed = jarde_reader::signature::MethodSignature {
            type_parameters: vec![TypeParameter {
                name: b"T".to_vec(),
                class_bound: Some(SignatureType::Class(ClassType {
                    segments: vec![ClassTypeSegment {
                        binary_name: b"probe/Bound".to_vec(),
                        arguments: Vec::new(),
                    }],
                })),
                interface_bounds: Vec::new(),
            }],
            parameters: vec![
                SignatureType::TypeVariable(b"T".to_vec()),
                SignatureType::Base(b'Z'),
            ],
            result: None,
            throws: Vec::new(),
        };
        let candidate = GenericReturnCandidate {
            parameters: vec![(1, "arg1".to_owned()), (2, "arg2".to_owned())],
            value: GenericReturnValue::VoidBody {
                unread_parameter_slots: vec![],
            },
        };
        let erasures = vec![jarde_reader::signature::TypeParameterErasure {
            name: b"T".to_vec(),
            descriptor: b"Lprobe/Bound;".to_vec(),
        }];
        (record, attributes, parsed, candidate, erasures)
    }

    #[test]
    fn void_generic_signature_stops_before_publishing_on_cancel_or_analysis_budget() {
        let (record, attributes, parsed, candidate, erasures) = generic_void_probe();
        let mut detached_record = record.clone();
        let projection = detached_record.take_generic_call_projection_state();
        assert!(detached_record.declaration.is_none());
        assert!(detached_record.text.is_empty());
        assert!(detached_record.markers.is_empty());
        let before = detached_record.clone();

        let mut success_budget = Budget::new(unlimited_annotation_test_limits());
        let declaration = generic_void_body_declaration(
            &detached_record,
            &projection,
            &attributes,
            &parsed,
            Some(&candidate),
            &erasures,
            b"probe/Setter",
            &[],
            &mut success_budget,
        )
        .expect("state-aware generic void proof reads the retained overlay");
        assert!(declaration.contains("<T extends probe.Bound> void set(T arg1, boolean arg2)"));

        let cancelled = jarde_reader::budget::CancellationToken::new();
        cancelled.cancel();
        let mut cancelled_budget =
            Budget::with_cancellation_token(unlimited_annotation_test_limits(), cancelled);
        let error = generic_void_body_declaration(
            &detached_record,
            &projection,
            &attributes,
            &parsed,
            Some(&candidate),
            &erasures,
            b"probe/Setter",
            &[],
            &mut cancelled_budget,
        )
        .expect_err("pre-cancellation stops the void Signature proof");
        assert!(matches!(error, Error::Cancelled { .. }));
        assert_eq!(detached_record, before);

        let mut limits = unlimited_annotation_test_limits();
        limits.analysis_steps = 0;
        let mut exhausted = Budget::new(limits);
        let error = generic_void_body_declaration(
            &detached_record,
            &projection,
            &attributes,
            &parsed,
            Some(&candidate),
            &erasures,
            b"probe/Setter",
            &[],
            &mut exhausted,
        )
        .expect_err("an exhausted analysis budget stops the void Signature proof");
        assert!(matches!(error, Error::BudgetExceeded { .. }));
        assert_eq!(detached_record, before);
    }

    #[test]
    fn generic_call_projection_state_stops_atomically_and_clones_with_metering() {
        let (mut record, _, _, _, _) = generic_void_probe();
        record.no_body_kind = Some(NoBodyKind::Abstract);
        let old_marker = "// jarde: preexisting generic signature refusal".to_owned();
        record.markers.push(old_marker.clone());
        record.text = format!("    {old_marker}\n{}", record.text);

        let mut snapshot_budget = Budget::new(unlimited_annotation_test_limits());
        let mut state = record
            .generic_call_projection_state(&mut snapshot_budget)
            .expect("the pre-attempt projection state is retained");
        let mut raw_clone_budget = Budget::new(unlimited_annotation_test_limits());
        let before = state
            .clone_raw_for_stage(&mut raw_clone_budget)
            .expect("the raw state snapshot is metered");
        let before_record = record.clone();

        let signature = b"<T:Lprobe/Bound;>(TT;Z)V";
        let proof = "same-run AST/Code/SSA void-body proof";
        let marker = format!(
            "// jarde: generic Signature `{}` projected after descriptor erasure and {proof}",
            comment_text(&String::from_utf8_lossy(signature)),
        );
        let mut limits = unlimited_annotation_test_limits();
        limits.output_bytes = u64::try_from(marker.len()).unwrap_or(u64::MAX);
        let mut output_budget = Budget::new(limits);
        let error = state
            .project_generic(
                &record,
                "public <T extends probe.Bound> void set(T arg1, boolean arg2)".to_owned(),
                signature,
                proof,
                &mut output_budget,
            )
            .expect_err("rendered member bytes exceed the remaining output budget");
        assert!(matches!(error, Error::BudgetExceeded { .. }));
        assert_eq!(state, before);
        assert_eq!(record, before_record);

        let cancellation = crate::CancellationToken::new();
        cancellation.cancel();
        let mut cancelled =
            Budget::with_cancellation_token(unlimited_annotation_test_limits(), cancellation);
        let error = state
            .project_generic(
                &record,
                "public <T extends probe.Bound> void set(T arg1, boolean arg2)".to_owned(),
                signature,
                proof,
                &mut cancelled,
            )
            .expect_err("pre-cancellation stops before mutating the staged overlay");
        assert!(matches!(error, Error::Cancelled { .. }));
        assert_eq!(state, before);
        assert_eq!(record, before_record);

        let mut no_analysis_limits = unlimited_annotation_test_limits();
        no_analysis_limits.analysis_steps = 0;
        let mut no_analysis = Budget::new(no_analysis_limits);
        assert!(matches!(
            state.clone_raw_for_stage(&mut no_analysis),
            Err(Error::BudgetExceeded {
                dimension: crate::BudgetDimension::AnalysisSteps,
                ..
            })
        ));
        assert_eq!(state, before);
        assert_eq!(record, before_record);

        let mut no_output_limits = unlimited_annotation_test_limits();
        no_output_limits.output_bytes = 0;
        let mut no_output = Budget::new(no_output_limits);
        assert!(matches!(
            state.clone_raw_for_stage(&mut no_output),
            Err(Error::BudgetExceeded {
                dimension: crate::BudgetDimension::OutputBytes,
                ..
            })
        ));
        assert_eq!(state, before);
        assert_eq!(record, before_record);

        let mut metered_copy_budget = Budget::new(unlimited_annotation_test_limits());
        let copy = state
            .clone_raw_for_stage(&mut metered_copy_budget)
            .expect("a funded raw-state clone succeeds");
        assert_eq!(copy, state);
        assert_eq!(state, before);
        assert_eq!(record, before_record);
    }

    #[test]
    fn void_generic_header_output_budget_publishes_no_partial_declaration() {
        let (mut record, _, _, _, _) = generic_void_probe();
        record.no_body_kind = Some(NoBodyKind::Abstract);
        let before = record.clone();
        let mut limits = unlimited_annotation_test_limits();
        limits.output_bytes = 0;
        let error = record
            .project_generic(
                "public <T extends probe.Bound> void set(T arg1, boolean arg2)".to_owned(),
                b"<T:Lprobe/Bound;>(TT;Z)V",
                "same-run AST/SSA void-body proof",
                &mut Budget::new(limits),
            )
            .expect_err("output budget rejects the complete staged projection");
        assert!(matches!(error, Error::BudgetExceeded { .. }));
        assert_eq!(record, before);
        assert!(!record.text.contains("<T extends"));
        assert!(!record.generic_signature_projected);
    }

    #[test]
    fn functional_withholding_uses_projected_state_not_markers_or_source_text() {
        let (mut failed, _, _, _, _) = generic_void_probe();
        failed
            .markers
            .push("// jarde: generic Signature projected".to_owned());
        failed.text = "    public java.util.function.Function raw() { return value; }\n".to_owned();
        failed.withhold_unprojected_functional_body();
        assert!(failed.text.contains("typed functional source"));
        assert!(!failed.text.contains("Function raw"));

        let (mut projected, _, _, _, _) = generic_void_probe();
        projected.no_body_kind = Some(NoBodyKind::Abstract);
        projected
            .project_generic(
                "public <T extends probe.Bound> void set(T arg1, boolean arg2)".to_owned(),
                b"<T:Lprobe/Bound;>(TT;Z)V",
                "same-run AST/SSA void-body proof",
                &mut Budget::new(unlimited_annotation_test_limits()),
            )
            .expect("complete projection fits the budget");
        assert!(projected.generic_signature_projected);
        let text = projected.text.clone();
        projected.withhold_unprojected_functional_body();
        assert_eq!(projected.text, text);
    }

    #[test]
    fn anonymous_capture_class_facts_are_passed_as_typed_assembly_input() {
        const ANONYMOUS: &[u8] = include_bytes!(
            "../tests/fixtures/proved-java-structure/anonymous-capture/AnonymousCaptureCases$1.class"
        );
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        let selected = jarde_reader::classfile::class_facts(ANONYMOUS, &mut budget)
            .expect("the committed Java 8 anonymous class is structurally readable");
        let shells: Vec<_> = selected
            .attributes
            .iter()
            .filter(|attribute| {
                matches!(
                    attribute.name.raw().0.as_slice(),
                    b"InnerClasses" | b"EnclosingMethod"
                )
            })
            .cloned()
            .collect();
        let assembly = read_class_source_assembly_context(
            ANONYMOUS,
            &shells,
            &selected.constant_pool,
            &mut budget,
        )
        .expect("the selected class's nesting attributes decode into typed facts");

        assert!(assembly.inner_classes.iter().any(|inner| {
            jarde_reader::classfile::cp_class_name(&selected.constant_pool, inner.class_index)
                .is_ok_and(|name| name.0 == b"AnonymousCaptureCases$1")
                && inner.inner_name.is_none()
        }));
        let enclosing = assembly
            .enclosing_method
            .expect("anonymous local class has EnclosingMethod");
        assert_eq!(
            jarde_reader::classfile::cp_class_name(&selected.constant_pool, enclosing.class_index)
                .expect("enclosing class index resolves")
                .0,
            b"AnonymousCaptureCases"
        );
        let method = selected
            .constant_pool
            .iter()
            .find(|entry| entry.index == enclosing.method_index)
            .expect("enclosing method index resolves");
        let CpEntryKind::NameAndType {
            name, descriptor, ..
        } = &method.kind
        else {
            panic!("EnclosingMethod points to a NameAndType entry");
        };
        assert_eq!(name.0, b"baseArgumentAndCapture");
        assert_eq!(descriptor.0, b"()LAnonymousCaptureCases$Renderer;");
    }

    #[test]
    fn ordinary_signature_types_spell_each_structured_argument_and_array() {
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        let parsed = parse_method_signature(
            b"(Ljava/util/List<*>;Ljava/util/List<+Ljava/lang/Number;>;Ljava/util/List<-Ljava/lang/String;>;Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/Integer;>;>;[Ljava/util/List<Ljava/lang/String;>;)V",
            &mut budget,
        ).unwrap();
        let written = parsed
            .parameters
            .iter()
            .map(|ty| spell_ordinary_signature_type(ty, &[], &mut budget, 0).unwrap())
            .collect::<Vec<_>>();
        assert_eq!(
            written,
            [
                "java.util.List<?>",
                "java.util.List<? extends java.lang.Number>",
                "java.util.List<? super java.lang.String>",
                "java.util.Map<java.lang.String, java.util.List<java.lang.Integer>>",
                "java.util.List<java.lang.String>[]",
            ]
        );
        let nested = parse_method_signature(b"(Lp/Outer.Inner;)V", &mut budget).unwrap();
        assert!(matches!(
            spell_ordinary_signature_type(&nested.parameters[0], &[], &mut budget, 0),
            Err(Error::Unsupported { .. })
        ));
    }

    #[test]
    fn class_header_spelling_keeps_pool_names_the_member_spelling_refuses() {
        // The design premise this pin answers: the member/annotation spelling channel refuses
        // every `$`-named single-segment class, so the class header needs its own leaf rule —
        // the class file's own binary name (`class_name`), which is what the raw header already
        // states for every parent no `Signature` projects. Without the header rule the whole
        // parent MVP and the interface projection could not spell a single `$` name.
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        let parsed = parse_method_signature(
            b"(LBR$Box<Ljava/lang/String;>;Ljava/lang/Comparable<LBR$Impl;>;Lp/Outer$Mid$Leaf<Ljava/lang/Integer;>;Ljava/lang/String;)V",
            &mut budget,
        )
        .unwrap();
        let written = parsed
            .parameters
            .iter()
            .map(|ty| spell_class_header_signature_type(ty, &[], &mut budget, 0).unwrap())
            .collect::<Vec<_>>();
        assert_eq!(
            written,
            [
                "BR$Box<java.lang.String>",
                "java.lang.Comparable<BR$Impl>",
                "p.Outer$Mid$Leaf<java.lang.Integer>",
                "java.lang.String",
            ]
        );
        // The same types through the member spelling: the `$` names refuse (the boundary
        // `ordinary-parameterized-signatures` pinned), and the no-`$` name is byte-identical
        // between the two rules — the header rule changes nothing but the `$` refusal.
        assert_eq!(
            spell_ordinary_signature_type(&parsed.parameters[3], &[], &mut budget, 0).unwrap(),
            "java.lang.String"
        );
        for index in [0, 1, 2] {
            assert!(matches!(
                spell_ordinary_signature_type(&parsed.parameters[index], &[], &mut budget, 0),
                Err(Error::Unsupported { .. })
            ));
        }
        // A name that is not a Java identifier has no spelling under either rule.
        let bad = parse_method_signature(b"(Lp/Bad-Name;)V", &mut budget).unwrap();
        assert!(matches!(
            spell_class_header_signature_type(&bad.parameters[0], &[], &mut budget, 0),
            Err(Error::Unsupported { .. })
        ));
    }

    #[test]
    fn selected_member_path_spells_only_exact_nested_signature_segments() {
        let identity = jarde_reader::model::PhysicalDefinitionId {
            location: jarde_reader::model::PhysicalClassLocation::StandaloneRoot {
                snapshot: jarde_reader::model::SnapshotId("member-path-test".to_owned()),
            },
            class_bytes: jarde_reader::model::ClassBytesId {
                digest: jarde_reader::model::Digest("member-path".to_owned()),
                length: 0,
            },
            variant: jarde_reader::model::PhysicalVariant::Base,
        };
        let path = vec![
            jarde_java::report::ProvedMemberInnerSourceSegment {
                definition: identity.clone(),
                binary_name: "matrix/Outer".to_owned(),
                source_name: "matrix.Outer".to_owned(),
                type_parameter_count: 0,
                enclosing_binary_name: None,
                is_static: true,
            },
            jarde_java::report::ProvedMemberInnerSourceSegment {
                definition: identity.clone(),
                binary_name: "matrix/Outer$A".to_owned(),
                source_name: "matrix.Outer.A".to_owned(),
                type_parameter_count: 1,
                enclosing_binary_name: Some("matrix/Outer".to_owned()),
                is_static: true,
            },
            jarde_java::report::ProvedMemberInnerSourceSegment {
                definition: identity,
                binary_name: "matrix/Outer$A$Generic".to_owned(),
                source_name: "matrix.Outer.A.Generic".to_owned(),
                type_parameter_count: 1,
                enclosing_binary_name: Some("matrix/Outer$A".to_owned()),
                is_static: false,
            },
        ];
        let mut budget = Budget::new(unlimited_annotation_test_limits());

        let raw =
            parse_method_signature(b"(Lmatrix/Outer$A;)Lmatrix/Outer$A;", &mut budget).unwrap();
        assert_eq!(
            spell_ordinary_signature_type_with_member_path(
                &raw.parameters[0],
                &[],
                &path,
                &mut budget,
                0,
            )
            .unwrap(),
            "matrix.Outer.A"
        );

        let parameterized = parse_method_signature(
            b"(Lmatrix/Outer$A<Ljava/lang/String;>;)Lmatrix/Outer$A<Ljava/lang/String;>.Generic<Ljava/lang/Integer;>;",
            &mut budget,
        )
        .unwrap();
        assert_eq!(
            spell_ordinary_signature_type_with_member_path(
                &parameterized.parameters[0],
                &[],
                &path,
                &mut budget,
                0,
            )
            .unwrap(),
            "matrix.Outer.A<java.lang.String>"
        );
        assert_eq!(
            spell_ordinary_signature_type_with_member_path(
                parameterized.result.as_ref().unwrap(),
                &[],
                &path,
                &mut budget,
                0,
            )
            .unwrap(),
            "matrix.Outer.A<java.lang.String>.Generic<java.lang.Integer>"
        );

        let wrong_arity = parse_method_signature(
            b"(Lmatrix/Outer$A<Ljava/lang/String;Ljava/lang/Integer;>;)V",
            &mut budget,
        )
        .unwrap();
        assert!(matches!(
            spell_ordinary_signature_type_with_member_path(
                &wrong_arity.parameters[0],
                &[],
                &path,
                &mut budget,
                0,
            ),
            Err(Error::Unsupported { .. })
        ));

        let omitted_enclosing = parse_method_signature(
            b"(Lmatrix/Outer$A$Generic<Ljava/lang/Integer;>;)V",
            &mut budget,
        )
        .unwrap();
        assert!(matches!(
            spell_ordinary_signature_type_with_member_path(
                &omitted_enclosing.parameters[0],
                &[],
                &path,
                &mut budget,
                0,
            ),
            Err(Error::Unsupported { .. })
        ));

        let legal_dollar_name =
            parse_method_signature(b"(Lmatrix/Dollar$Type;)V", &mut budget).unwrap();
        assert!(matches!(
            spell_ordinary_signature_type_with_member_path(
                &legal_dollar_name.parameters[0],
                &[],
                &path,
                &mut budget,
                0,
            ),
            Err(Error::Unsupported { .. })
        ));
    }

    /// The shape [`jarde_java::recover`] emits, so the split is tested against the text it really
    /// produces rather than against a convenient one.
    const ARTIFACT: &str = "// @method run()V\n// @declaration an instance method of `p/T`\n\
                            // recovered from bytecode; presentation is not claimed to compile\n\
                            {\n    if (arg0) {\n        return;\n    }\n}\n";

    #[test]
    fn one_field_descriptor_is_spelled_as_java_spells_it() {
        for (descriptor, expected) in [
            (&b"I"[..], "int"),
            (b"Z", "boolean"),
            (b"J", "long"),
            (b"Ljava/lang/String;", "java.lang.String"),
            (b"[I", "int[]"),
            (b"[[J", "long[][]"),
            (b"[Ljava/util/List;", "java.util.List[]"),
        ] {
            assert_eq!(
                field_type(descriptor).as_deref(),
                Some(expected),
                "descriptor {}",
                String::from_utf8_lossy(descriptor)
            );
        }
    }

    #[test]
    fn bytes_that_are_not_a_field_descriptor_are_refused_rather_than_guessed() {
        for descriptor in [
            &b""[..],
            b"V",
            b"II",
            b"Il",
            b"Ljava/lang/String",
            b"[Z]",
            b"L;",
            b"(",
            b"not-a-descriptor",
        ] {
            assert_eq!(
                field_type(descriptor),
                None,
                "descriptor {}",
                String::from_utf8_lossy(descriptor)
            );
        }
    }

    /// P3 6.7: the third argument is the member's own `ACC_VARARGS`, and none of the descriptors
    /// below declares one — the flag is stated by the test after this one, because it is the only
    /// part of the reading it changes.
    #[test]
    fn one_method_descriptor_is_spelled_with_its_slots_and_its_return_type() {
        let signature = method_descriptor(b"(JLjava/lang/String;[I)V", true, false)
            .expect("a method descriptor");
        assert_eq!(
            signature.parameters,
            vec![
                ("long".to_owned(), 0),
                ("java.lang.String".to_owned(), 2),
                ("int[]".to_owned(), 3),
            ],
            "a wide parameter occupies two slots, and the next one starts after it"
        );
        assert!(!signature.varargs, "no `ACC_VARARGS` is set on this member");
        assert_eq!(signature.returns, None, "`V` states no return type");
        assert_eq!(signature.slots, 4);

        let empty =
            method_descriptor(b"()[Ljava/lang/Object;", true, false).expect("a method descriptor");
        assert!(empty.parameters.is_empty());
        assert!(
            !empty.varargs,
            "there is no parameter for the flag to reach"
        );
        assert_eq!(empty.returns.as_deref(), Some("java.lang.Object[]"));
        assert_eq!(empty.slots, 0);
    }

    #[test]
    fn method_parameters_need_a_complete_safe_slot_projection() {
        let entry = |name: Option<&[u8]>, flags| jarde_reader::classfile::MethodParameterFacts {
            name_index: u16::from(name.is_some()),
            name: name.map(|name| jarde_reader::model::JvmBytes(name.to_vec())),
            access_flags: flags,
        };
        let entries = [entry(Some(b"first"), 0), entry(Some(b"second"), ACC_FINAL)];
        let proved = prove_method_parameters(&entries, b"(JDI)V", 0);
        assert!(proved.is_none(), "descriptor count must match");
        let proved = prove_method_parameters(&entries, b"(JD)V", 0).unwrap();
        assert_eq!(
            proved.iter().map(|item| item.slot).collect::<Vec<_>>(),
            [1, 3]
        );
        assert!(proved[1].is_final);
        let static_proved = prove_method_parameters(&entries, b"(JD)V", ACC_STATIC).unwrap();
        assert_eq!(
            static_proved
                .iter()
                .map(|item| item.slot)
                .collect::<Vec<_>>(),
            [0, 2]
        );
        for entries in [
            [entry(None, 0), entry(Some(b"second"), 0)],
            [entry(Some(b"first"), 0), entry(Some(b"first"), 0)],
            [entry(Some(b"class"), 0), entry(Some(b"second"), 0)],
            [entry(Some(b"first"), 0x1000), entry(Some(b"second"), 0)],
            [entry(Some(b"first"), 0x8000), entry(Some(b"second"), 0)],
        ] {
            assert!(prove_method_parameters(&entries, b"(JD)V", 0).is_none());
        }
        assert!(prove_method_parameters(&entries, b"(JD)V", 0x0040).is_none());
        assert!(
            prove_method_parameters(
                &[entry(Some(b"wide"), 0), entry(Some(b"arg2"), 0)],
                b"(JLjava/lang/String;)V",
                0,
            )
            .is_none(),
            "an invented name for a wide slot cannot alias a source parameter"
        );
    }

    #[test]
    fn projected_parameter_names_and_final_are_one_declaration() {
        let signature =
            method_descriptor(b"(Ljava/lang/String;I)Ljava/lang/String;", false, false).unwrap();
        let parameters = vec![
            ProvedMethodParameter {
                slot: 1,
                name: "paramStr".into(),
                is_final: false,
            },
            ProvedMethodParameter {
                slot: 2,
                name: "number".into(),
                is_final: true,
            },
        ];
        let facts = RecoveryFacts::new(
            jarde_java::MethodFacts::new("named", "(Ljava/lang/String;I)Ljava/lang/String;", 3)
                .with_access_flags(0),
        )
        .with_debug_locals(vec![
            jarde_java::DebugLocal::named(1, "paramStr"),
            jarde_java::DebugLocal::named(2, "number"),
        ]);
        assert_eq!(
            arguments(
                Some(&facts),
                None,
                &signature,
                None,
                &[],
                &[],
                &[],
                Some(&parameters)
            ),
            "(java.lang.String paramStr, final int number)"
        );
        assert_eq!(
            arguments(
                None,
                None,
                &signature,
                None,
                &[],
                &[],
                &[],
                Some(&parameters)
            ),
            "(java.lang.String arg1, int arg2)"
        );
        let lvt = facts.clone().with_debug_locals(vec![
            jarde_java::DebugLocal::over(1, "paramStr", 0, 4),
            jarde_java::DebugLocal::over(2, "number", 0, 4),
        ]);
        assert_eq!(
            arguments(
                Some(&lvt),
                None,
                &signature,
                None,
                &[],
                &[],
                &[],
                Some(&parameters)
            ),
            "(java.lang.String paramStr, int number)"
        );
    }

    /// P3 6.7: `ACC_VARARGS` (0x0080) is the member's own fact that its **last** parameter is the
    /// variable-arity one, and the two facts it takes to write a `...` meet in the signature: the
    /// flag, and a descriptor whose last component is an array. The reading of the descriptor itself
    /// does not move — the types stay the arrays the bytes state — and the dots are what the
    /// parameter list writes for the one position the flag reaches.
    #[test]
    fn a_varargs_flag_writes_the_last_parameters_array_as_the_dots() {
        let ints = method_descriptor(b"(I[I)V", true, true).expect("a method descriptor");
        assert_eq!(
            ints.parameters,
            vec![("int".to_owned(), 0), ("int[]".to_owned(), 1)],
            "the descriptor's own types are read the same way with and without the flag"
        );
        assert!(ints.varargs);
        assert_eq!(
            arguments(None, None, &ints, None, &[], &[], &[], None),
            "(int arg0, int... arg1)"
        );

        // `[[B`: the dots take the place of the **last** `[]`, so the element type keeps the `[]`
        // it has and the parameter is written `byte[]...`, never `byte[][]` or `byte...`.
        let grid = method_descriptor(b"([[B)V", true, true).expect("a method descriptor");
        assert_eq!(
            arguments(None, None, &grid, None, &[], &[], &[], None),
            "(byte[]... arg0)"
        );

        // The controls. The same descriptor without the flag keeps the array spelling, and the flag
        // on a member whose last parameter is not an array is written as the descriptor states it.
        let without_the_flag =
            method_descriptor(b"(I[I)V", true, false).expect("a method descriptor");
        assert!(!without_the_flag.varargs);
        assert_eq!(
            arguments(None, None, &without_the_flag, None, &[], &[], &[], None),
            "(int arg0, int[] arg1)"
        );
        let not_an_array = method_descriptor(b"(II)V", true, true).expect("a method descriptor");
        assert!(!not_an_array.varargs, "no `...` is invented for an `int`");
        assert_eq!(
            arguments(None, None, &not_an_array, None, &[], &[], &[], None),
            "(int arg0, int arg1)"
        );
        let no_parameters = method_descriptor(b"()V", true, true).expect("a method descriptor");
        assert!(
            !no_parameters.varargs,
            "there is no last parameter to reach"
        );
        assert_eq!(
            arguments(None, None, &no_parameters, None, &[], &[], &[], None),
            "()"
        );

        // The flag reaches the descriptor's last parameter and not the slot the receiver holds: an
        // instance member's `this` is no position of the list, so the dots land on slot 1 here.
        let instance = method_descriptor(b"([I)V", false, true).expect("a method descriptor");
        assert_eq!(
            arguments(None, None, &instance, None, &[], &[], &[], None),
            "(int... arg1)"
        );
    }

    #[test]
    fn recovered_names_follow_parameter_slots_across_a_wide_value() {
        let signature = method_descriptor(b"(JI)I", true, false).expect("a method descriptor");
        let recovered = [Some("arg0_2".to_owned()), None, Some("arg2_2".to_owned())];
        assert_eq!(
            arguments(
                None,
                Some(&recovered),
                &signature,
                None,
                &[],
                &[],
                &[],
                None
            ),
            "(long arg0_2, int arg2_2)"
        );
    }

    /// JVMS 2.6.1: an array fills **one** slot whatever its element type, and a member that is not
    /// `static` puts its receiver in slot 0 — the two facts the parameter names of a declaration are
    /// looked up by, and the two the body's own `arg<slot>` names are numbered by.
    #[test]
    fn an_arrays_element_width_does_not_move_the_parameters_after_it() {
        let static_mixed = method_descriptor(b"([JI)V", true, false).expect("a method descriptor");
        assert_eq!(
            static_mixed.parameters,
            vec![("long[]".to_owned(), 0), ("int".to_owned(), 1)],
            "`long[]` is a reference: the `int` after it is at slot 1, not at slot 2"
        );
        assert_eq!(static_mixed.slots, 2);

        let instance_mixed =
            method_descriptor(b"([JI)V", false, false).expect("a method descriptor");
        assert_eq!(
            instance_mixed.parameters,
            vec![("long[]".to_owned(), 1), ("int".to_owned(), 2)],
            "slot 0 holds the receiver of a member that is not static"
        );
        assert_eq!(instance_mixed.slots, 3);

        let double_grid = method_descriptor(b"([[DJ)J", true, false).expect("a method descriptor");
        assert_eq!(
            double_grid.parameters,
            vec![("double[][]".to_owned(), 0), ("long".to_owned(), 1)],
            "a two-dimensional `double[][]` is one slot, and the `long` after it two"
        );
        assert_eq!(double_grid.slots, 3);

        // The controls: a `double` written on its own really is two slots, and an `int[]` (whose
        // element is one slot wide) reads the same way before and after this rule.
        let wide = method_descriptor(b"(DI)J", true, false).expect("a method descriptor");
        assert_eq!(
            wide.parameters,
            vec![("double".to_owned(), 0), ("int".to_owned(), 2)]
        );
        assert_eq!(wide.slots, 3);
        assert_eq!(wide.returns.as_deref(), Some("long"));
        let narrow_array = method_descriptor(b"([II)V", true, false).expect("a method descriptor");
        assert_eq!(
            narrow_array.parameters,
            vec![("int[]".to_owned(), 0), ("int".to_owned(), 1)]
        );
    }

    #[test]
    fn bytes_that_are_not_a_method_descriptor_are_refused_rather_than_guessed() {
        for descriptor in [
            &b""[..],
            b"I",
            b"()",
            b"()VV",
            b"(I",
            b"(I)Z ",
            b"not-a-descriptor",
            // An object name Java cannot write is no type: a type position states a Java type or
            // states that it could not be written, and a lossy spelling is neither.
            b"(L\xff;)V",
        ] {
            assert_eq!(
                // P3 6.7: the varargs flag is stated **beside** the descriptor the parameter list is
                // read from, so a descriptor that is not one is refused before a flag can matter.
                method_descriptor(descriptor, true, false),
                None,
                "descriptor {}",
                String::from_utf8_lossy(descriptor)
            );
            assert!(!spellable_descriptor(descriptor));
        }
        assert!(spellable_descriptor(b"()V"));
        assert!(spellable_descriptor(b"(JLjava/lang/String;[I)V"));
        assert!(spellable_descriptor(b"([JI)V"));
    }

    #[test]
    fn one_internal_name_is_spelled_dotted_and_nothing_else_about_it_changes() {
        assert_eq!(class_name(b"p/Outer$Inner"), "p.Outer$Inner");
        assert_eq!(
            class_name(b"HistoricalControlFlow"),
            "HistoricalControlFlow"
        );
        assert_eq!(class_name(b"a/b/C"), "a.b.C");
    }

    #[test]
    fn a_binary_name_is_split_where_its_own_last_slash_is() {
        // The class's own name: the package is everything before the **last** `/`, and a `$` inside
        // either part stays where it is — no nesting relation is read out of it.
        assert_eq!(simple_name(b"a/b/C"), "C");
        assert_eq!(simple_name(b"p/Outer$Inner"), "Outer$Inner");
        assert_eq!(simple_name(b"p/More17$1"), "More17$1");
        assert_eq!(simple_name(b"C"), "C");

        // The package line the same split states; a name with no `/` is the default package, which
        // writes no line at all.
        assert_eq!(package_name(b"a/b/C"), Some("a.b".to_owned()));
        assert_eq!(package_name(b"p/Outer$Inner"), Some("p".to_owned()));
        assert_eq!(package_name(b"C"), None);
    }

    #[test]
    fn a_name_java_cannot_spell_becomes_the_deterministic_alias() {
        assert_eq!(written_name(b"run"), ("run".to_owned(), false));
        assert_eq!(written_name(b"int"), ("int_".to_owned(), true));
        assert_eq!(written_name(b"weird-name"), ("weird_name".to_owned(), true));
        assert_eq!(
            written_name(b"weird-name"),
            written_name(b"weird-name"),
            "the alias is a function of the raw name alone"
        );
    }

    #[test]
    fn one_artifact_is_split_at_its_own_block() {
        let artifact = artifact(ARTIFACT).expect("the emitter's own shape");
        assert_eq!(
            artifact.envelope,
            "// @method run()V\n// @declaration an instance method of `p/T`\n\
             // recovered from bytecode; presentation is not claimed to compile\n"
        );
        assert_eq!(
            artifact.statements, "    if (arg0) {\n        return;\n    }\n",
            "the statements keep the one level of indentation their own block gave them"
        );
    }

    #[test]
    fn a_text_that_is_not_that_shape_is_not_placed() {
        assert!(artifact("").is_none());
        assert!(artifact("// only comments\n").is_none());
        assert!(artifact("{\n    return;\n}\ntrailing\n").is_none());
        assert!(artifact("}\n{\n").is_none());
        assert!(
            artifact("{\n    return;\n}\n").is_some(),
            "an empty envelope is still the shape"
        );
    }

    #[test]
    fn one_member_block_puts_the_envelope_and_the_statements_at_the_same_depth() {
        let artifact = artifact(ARTIFACT).expect("the emitter's own shape");
        let member = block_member(
            "public void run()",
            Placed::Block(artifact),
            &["// jarde: a marker".to_owned()],
        );
        assert_eq!(
            member,
            "    public void run() {\n\
             \x20       // jarde: a marker\n\
             \x20       // @method run()V\n\
             \x20       // @declaration an instance method of `p/T`\n\
             \x20       // recovered from bytecode; presentation is not claimed to compile\n\
             \x20       if (arg0) {\n\
             \x20           return;\n\
             \x20       }\n\
             \x20   }\n"
        );
    }

    #[test]
    fn one_member_without_an_artifact_keeps_its_marker_inside_the_block() {
        let member = block_member(
            "public void run()",
            Placed::Without,
            &["// jarde: no body".to_owned()],
        );
        assert_eq!(
            member,
            "    public void run() {\n        // jarde: no body\n    }\n"
        );
    }

    #[test]
    fn one_member_whose_artifact_cannot_be_placed_quotes_it_line_by_line() {
        let member = block_member(
            "public void run()",
            Placed::Quoted("not a block\n"),
            &["// jarde: not placed".to_owned()],
        );
        assert_eq!(
            member,
            "    public void run() {\n        // jarde: not placed\n        // not a block\n    }\n"
        );
    }

    #[test]
    fn one_stop_code_is_the_engines_own_spelling_of_its_reason() {
        let cancelled = ExecutionReport::Cancelled {
            usage: UsageSnapshot::default(),
        };
        assert_eq!(stop_code(&cancelled).as_deref(), Some("cancelled"));
        let budget = ExecutionReport::Partial {
            reason: TerminationReason::BudgetExceeded {
                dimension: crate::BudgetDimension::MethodBodies,
            },
            usage: UsageSnapshot::default(),
        };
        assert_eq!(
            stop_code(&budget).as_deref(),
            Some("budget_exceeded_method_bodies")
        );
        let complete = ExecutionReport::Complete {
            usage: UsageSnapshot::default(),
        };
        assert_eq!(stop_code(&complete), None);
    }

    #[test]
    fn member_annotation_budget_stop_keeps_the_raw_shell_unread() {
        let mut discovery = Budget::new(unlimited_annotation_test_limits());
        let class = jarde_reader::classfile::class_facts(MEMBER_ANNOTATION_TARGET, &mut discovery)
            .expect("the frozen class structure");
        let field = class
            .fields
            .iter()
            .find(|field| field.name.raw().0 == b"field")
            .expect("the annotated field");
        let mut limits = unlimited_annotation_test_limits();
        limits.attribute_bytes = 0;
        let mut budget = Budget::new(limits);

        let read = declared_member_annotations(
            MEMBER_ANNOTATION_TARGET,
            field,
            &class.constant_pool,
            &mut budget,
        );

        assert_eq!(read.facts.declaration.attributes.len(), 1);
        assert_eq!(
            read.facts.declaration.attributes[0].attribute.name.raw().0,
            b"RuntimeVisibleAnnotations"
        );
        assert!(read.facts.declaration.attributes[0].annotations.is_empty());
        assert!(read.facts.declaration.refusals[0].contains("budget exceeded for AttributeBytes"));
        assert!(matches!(
            read.errors.as_slice(),
            [Error::BudgetExceeded {
                dimension: crate::BudgetDimension::AttributeBytes,
                ..
            }]
        ));
    }

    #[test]
    fn member_annotation_cancellation_keeps_the_raw_shell_unread() {
        let mut discovery = Budget::new(unlimited_annotation_test_limits());
        let class = jarde_reader::classfile::class_facts(MEMBER_ANNOTATION_TARGET, &mut discovery)
            .expect("the frozen class structure");
        let field = class
            .fields
            .iter()
            .find(|field| field.name.raw().0 == b"field")
            .expect("the annotated field");
        let cancellation = crate::CancellationToken::new();
        cancellation.cancel();
        let mut budget =
            Budget::with_cancellation_token(unlimited_annotation_test_limits(), cancellation);

        let read = declared_member_annotations(
            MEMBER_ANNOTATION_TARGET,
            field,
            &class.constant_pool,
            &mut budget,
        );

        assert_eq!(read.facts.declaration.attributes.len(), 1);
        assert!(read.facts.declaration.attributes[0].annotations.is_empty());
        assert!(read.facts.declaration.refusals[0].contains("cancelled:"));
        assert!(matches!(read.errors.as_slice(), [Error::Cancelled { .. }]));
    }

    #[test]
    fn field_write_parameter_proof_distinguishes_published_generic_and_raw_parameters() {
        use jarde_reader::signature::{ClassType, ClassTypeSegment, SignatureType, TypeArgument};

        let mut budget = Budget::new(unlimited_annotation_test_limits());
        let field = parse_field_signature(b"Ljava/util/List<TT;>;", &mut budget)
            .expect("the target List<T> signature parses")
            .ty;
        let published =
            parse_method_signature(b"(Ljava/util/List<Ljava/lang/String;>;)V", &mut budget)
                .expect("the published List<String> parameter parses");
        let raw_descriptor = b"Ljava/util/List;".to_vec();
        let method_identity = generic_void_probe().0.item.identity;
        let source = SameClassFieldWriteSource::Parameter {
            method: method_identity.clone(),
            slot: 1,
        };
        let class_scope = vec![jarde_reader::signature::TypeParameterErasure {
            name: b"T".to_vec(),
            descriptor: b"Ljava/lang/Object;".to_vec(),
        }];
        let string_literal = SameClassFieldWriteSource::StringConstant { value_bci: 7 };
        let mut literal_budget = Budget::new(unlimited_annotation_test_limits());
        assert!(!field_write_source_assignable(
            &string_literal,
            &field,
            &class_scope,
            &[],
            8,
        ));
        assert!(
            !raw_field_write_source_assignable(
                &string_literal,
                b"Ljava/lang/String;",
                &[],
                8,
                &mut literal_budget,
            )
            .expect("string constant is deliberately excluded from generic field proofs")
        );
        let published_method = SameClassPublishedMethodParameters {
            method: method_identity.clone(),
            parameter_slots: vec![1],
            descriptor_parameters: vec![raw_descriptor.clone()],
            generic_parameters: Some(published.parameters),
            method_type_parameters: Vec::new(),
        };
        assert!(!field_write_source_assignable(
            &source,
            &field,
            &class_scope,
            &[published_method],
            8,
        ));

        let published_raw_method = SameClassPublishedMethodParameters {
            method: method_identity.clone(),
            parameter_slots: vec![1],
            descriptor_parameters: vec![b"Ljava/util/List;".to_vec()],
            generic_parameters: Some(vec![SignatureType::Class(ClassType {
                segments: vec![ClassTypeSegment {
                    binary_name: b"java/util/List".to_vec(),
                    arguments: Vec::new(),
                }],
            })]),
            method_type_parameters: Vec::new(),
        };
        assert!(field_write_source_assignable(
            &source,
            &field,
            &class_scope,
            &[published_raw_method],
            8,
        ));
        let published_raw_array_list_method = SameClassPublishedMethodParameters {
            method: method_identity.clone(),
            parameter_slots: vec![1],
            descriptor_parameters: vec![b"Ljava/util/ArrayList;".to_vec()],
            generic_parameters: Some(vec![SignatureType::Class(ClassType {
                segments: vec![ClassTypeSegment {
                    binary_name: b"java/util/ArrayList".to_vec(),
                    arguments: Vec::new(),
                }],
            })]),
            method_type_parameters: Vec::new(),
        };
        assert!(field_write_source_assignable(
            &source,
            &field,
            &class_scope,
            &[published_raw_array_list_method.clone()],
            8,
        ));
        assert!(!field_write_source_assignable(
            &source,
            &field,
            &class_scope,
            &[published_raw_array_list_method],
            9,
        ));

        let raw_method = SameClassPublishedMethodParameters {
            method: method_identity.clone(),
            parameter_slots: vec![1],
            descriptor_parameters: vec![raw_descriptor],
            generic_parameters: None,
            method_type_parameters: Vec::new(),
        };
        assert!(field_write_source_assignable(
            &source,
            &field,
            &class_scope,
            &[raw_method],
            8,
        ));

        let raw_array_target = SignatureType::Array(Box::new(SignatureType::Class(ClassType {
            segments: vec![ClassTypeSegment {
                binary_name: b"java/util/List".to_vec(),
                arguments: vec![TypeArgument::Exact(SignatureType::TypeVariable(
                    b"T".to_vec(),
                ))],
            }],
        })));
        let array_source = SameClassFieldWriteSource::Parameter {
            method: method_identity.clone(),
            slot: 1,
        };
        let raw_array_method = SameClassPublishedMethodParameters {
            method: method_identity.clone(),
            parameter_slots: vec![1],
            descriptor_parameters: vec![b"[Ljava/util/List;".to_vec()],
            generic_parameters: None,
            method_type_parameters: Vec::new(),
        };
        assert!(field_write_source_assignable(
            &array_source,
            &raw_array_target,
            &class_scope,
            &[raw_array_method],
            8,
        ));
        let published_raw_array_method = SameClassPublishedMethodParameters {
            method: method_identity.clone(),
            parameter_slots: vec![1],
            descriptor_parameters: vec![b"[Ljava/util/List;".to_vec()],
            generic_parameters: Some(vec![SignatureType::Array(Box::new(SignatureType::Class(
                ClassType {
                    segments: vec![ClassTypeSegment {
                        binary_name: b"java/util/List".to_vec(),
                        arguments: Vec::new(),
                    }],
                },
            )))]),
            method_type_parameters: Vec::new(),
        };
        assert!(field_write_source_assignable(
            &array_source,
            &raw_array_target,
            &class_scope,
            &[published_raw_array_method],
            8,
        ));

        let shadowed_method = SameClassPublishedMethodParameters {
            method: method_identity,
            parameter_slots: vec![1],
            descriptor_parameters: vec![b"Ljava/lang/Object;".to_vec()],
            generic_parameters: Some(vec![SignatureType::TypeVariable(b"T".to_vec())]),
            method_type_parameters: vec![TypeParameter {
                name: b"T".to_vec(),
                class_bound: None,
                interface_bounds: Vec::new(),
            }],
        };
        let class_variable_source = SameClassFieldWriteSource::Parameter {
            method: shadowed_method.method.clone(),
            slot: 1,
        };
        assert!(!field_write_source_assignable(
            &class_variable_source,
            &SignatureType::TypeVariable(b"T".to_vec()),
            &class_scope,
            &[shadowed_method],
            8,
        ));
    }

    #[test]
    fn raw_parameter_platform_widening_rejects_invalid_utf8_name_collisions() {
        let target = SignatureType::Class(jarde_reader::signature::ClassType {
            segments: vec![jarde_reader::signature::ClassTypeSegment {
                binary_name: vec![b'f', b'o', b'o', b'/', 0x81],
                arguments: vec![jarde_reader::signature::TypeArgument::Exact(
                    SignatureType::TypeVariable(b"T".to_vec()),
                )],
            }],
        });
        assert!(!raw_parameter_assignable(b"Lfoo/\x80;", &target, 8));
    }

    #[test]
    fn published_method_type_variable_uses_only_its_matching_raw_class_bound() {
        use jarde_reader::signature::{ClassType, ClassTypeSegment, TypeArgument};

        let string = || {
            SignatureType::Class(ClassType {
                segments: vec![ClassTypeSegment {
                    binary_name: b"java/lang/String".to_vec(),
                    arguments: Vec::new(),
                }],
            })
        };
        let target = SignatureType::Class(ClassType {
            segments: vec![ClassTypeSegment {
                binary_name: b"java/util/Map".to_vec(),
                arguments: vec![TypeArgument::Exact(string()), TypeArgument::Exact(string())],
            }],
        });
        let method_identity = generic_void_probe().0.item.identity;
        let source = SameClassFieldWriteSource::Parameter {
            method: method_identity.clone(),
            slot: 1,
        };
        let raw_bound = TypeParameter {
            name: b"R".to_vec(),
            class_bound: Some(SignatureType::Class(ClassType {
                segments: vec![ClassTypeSegment {
                    binary_name: b"java/util/HashMap".to_vec(),
                    arguments: Vec::new(),
                }],
            })),
            interface_bounds: Vec::new(),
        };
        let method = SameClassPublishedMethodParameters {
            method: method_identity.clone(),
            parameter_slots: vec![1],
            descriptor_parameters: vec![b"Ljava/util/HashMap;".to_vec()],
            generic_parameters: Some(vec![SignatureType::TypeVariable(b"R".to_vec())]),
            method_type_parameters: vec![raw_bound.clone()],
        };
        assert!(field_write_source_assignable(
            &source,
            &target,
            &[],
            &[method.clone()],
            8,
        ));
        assert!(!field_write_source_assignable(
            &source,
            &target,
            &[],
            &[method.clone()],
            9,
        ));

        let parameterized_bound = TypeParameter {
            class_bound: Some(SignatureType::Class(ClassType {
                segments: vec![ClassTypeSegment {
                    binary_name: b"java/util/HashMap".to_vec(),
                    arguments: vec![TypeArgument::Exact(string()), TypeArgument::Exact(string())],
                }],
            })),
            ..raw_bound.clone()
        };
        let method_with_parameterized_bound = SameClassPublishedMethodParameters {
            method: method_identity.clone(),
            method_type_parameters: vec![parameterized_bound],
            ..method.clone()
        };
        assert!(!field_write_source_assignable(
            &source,
            &target,
            &[],
            &[method_with_parameterized_bound],
            8,
        ));

        let interface_only_bound = TypeParameter {
            class_bound: None,
            interface_bounds: vec![SignatureType::Class(ClassType {
                segments: vec![ClassTypeSegment {
                    binary_name: b"java/util/HashMap".to_vec(),
                    arguments: Vec::new(),
                }],
            })],
            ..raw_bound
        };
        let method_with_interface_bound = SameClassPublishedMethodParameters {
            method: method_identity,
            method_type_parameters: vec![interface_only_bound],
            ..method
        };
        assert!(!field_write_source_assignable(
            &source,
            &target,
            &[],
            &[method_with_interface_bound],
            8,
        ));
    }

    #[test]
    fn field_write_source_type_walk_charges_exact_work_and_propagates_stops() {
        let mut parse_budget = Budget::new(unlimited_annotation_test_limits());
        let source_type = parse_field_signature(b"Ljava/util/List<TT;>;", &mut parse_budget)
            .expect("the parameter source type parses")
            .ty;
        let target_type = source_type.clone();
        let method_identity = generic_void_probe().0.item.identity;
        let source = SameClassFieldWriteSource::Parameter {
            method: method_identity.clone(),
            slot: 1,
        };
        let methods = [SameClassPublishedMethodParameters {
            method: method_identity,
            parameter_slots: vec![1],
            descriptor_parameters: vec![b"Ljava/util/List;".to_vec()],
            generic_parameters: Some(vec![source_type]),
            method_type_parameters: Vec::new(),
        }];
        let class_scope = [jarde_reader::signature::TypeParameterErasure {
            name: b"T".to_vec(),
            descriptor: b"Ljava/lang/Object;".to_vec(),
        }];

        let mut exact = unlimited_annotation_test_limits();
        exact.analysis_steps = 25;
        let mut exact_budget = Budget::new(exact);
        let assignable = prove_field_write_source_assignable(
            &source,
            &target_type,
            &class_scope,
            &methods,
            8,
            &mut exact_budget,
        )
        .expect("exactly twenty-five type and lookup steps fit");
        assert!(assignable, "the parameter's published type matches");
        assert_eq!(exact_budget.usage().analysis_steps, 25);

        let mut short = unlimited_annotation_test_limits();
        short.analysis_steps = 24;
        let mut short_budget = Budget::new(short);
        assert!(matches!(
            prove_field_write_source_assignable(
                &source,
                &target_type,
                &class_scope,
                &methods,
                8,
                &mut short_budget,
            ),
            Err(Error::BudgetExceeded {
                dimension: crate::BudgetDimension::AnalysisSteps,
                limit: 24,
                consumed: 24,
                ..
            })
        ));
        assert_eq!(short_budget.usage().analysis_steps, 24);

        let cancellation = crate::CancellationToken::new();
        cancellation.cancel();
        let mut cancelled =
            Budget::with_cancellation_token(unlimited_annotation_test_limits(), cancellation);
        assert!(matches!(
            prove_field_write_source_assignable(
                &source,
                &target_type,
                &class_scope,
                &methods,
                8,
                &mut cancelled,
            ),
            Err(Error::Cancelled { .. })
        ));
        assert_eq!(cancelled.usage().analysis_steps, 0);
    }

    #[test]
    fn incomplete_same_class_field_inventory_cannot_prove_a_field_binding() {
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        let class = jarde_reader::classfile::class_facts(MEMBER_ANNOTATION_TARGET, &mut budget)
            .expect("the frozen class structure reads");
        assert!(!class.fields.is_empty());
        let facts = SameClassUseFacts {
            complete: false,
            invokes: &[],
            field_uses: &[],
            member_refs: &[],
        };
        assert_eq!(
            prove_same_class_field_binding(
                &class.this_class.raw().0,
                &class.fields,
                0,
                &facts,
                &mut budget,
            )
            .expect("an incomplete inventory is a refusal, not an error"),
            SameClassBinding::Unproved,
        );
    }

    #[test]
    fn generic_constructor_field_write_requires_one_unique_instance_field_by_name() {
        fn member(name: &[u8], descriptor: &[u8], access_flags: u16) -> MemberHeader {
            let jvm_string = |raw: &[u8]| {
                serde_json::from_value::<jarde_reader::model::JvmString>(serde_json::json!({
                    "raw": raw,
                    "utf16": raw.iter().map(|byte| *byte as u16).collect::<Vec<_>>(),
                    "escaped": String::from_utf8_lossy(raw),
                }))
                .unwrap()
            };
            MemberHeader {
                name: jvm_string(name),
                descriptor: jvm_string(descriptor),
                access_flags,
                attributes: Vec::new(),
            }
        }

        let write = GenericConstructorFieldWrite {
            bci: 9,
            owner: "Hold".to_owned(),
            name: "value".to_owned(),
            descriptor: "Ljava/lang/Object;".to_owned(),
            parameter_slot: 1,
        };
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        assert!(
            generic_constructor_field_matches_physical_field(
                &write,
                b"Hold",
                &[member(b"value", b"Ljava/lang/Object;", 0)],
                &mut budget,
            )
            .expect("one matching instance field is a proof")
        );

        for fields in [
            vec![member(b"value", b"Ljava/lang/String;", 0)],
            vec![
                member(b"value", b"Ljava/lang/Object;", 0),
                member(b"value", b"Ljava/lang/String;", 0),
            ],
            vec![member(b"value", b"Ljava/lang/Object;", ACC_STATIC)],
        ] {
            let mut budget = Budget::new(unlimited_annotation_test_limits());
            assert!(
                !generic_constructor_field_matches_physical_field(
                    &write,
                    b"Hold",
                    &fields,
                    &mut budget,
                )
                .expect("a mismatched physical field is a refusal")
            );
        }
    }

    #[test]
    fn class_scope_constructor_gate_matches_exact_same_class_target_and_receiver() {
        fn member(name: &[u8], descriptor: &[u8]) -> MemberHeader {
            let jvm_string = |raw: &[u8]| {
                serde_json::from_value::<jarde_reader::model::JvmString>(serde_json::json!({
                    "raw": raw,
                    "utf16": raw.iter().map(|byte| *byte as u16).collect::<Vec<_>>(),
                    "escaped": String::from_utf8_lossy(raw),
                }))
                .unwrap()
            };
            MemberHeader {
                name: jvm_string(name),
                descriptor: jvm_string(descriptor),
                access_flags: 0,
                attributes: Vec::new(),
            }
        }
        fn invoke(
            owner: &[u8],
            descriptor: &[u8],
            receiver: Option<SameClassConstructorReceiver>,
            bci: u32,
        ) -> SameClassInvokeUse {
            let physical_owner = crate::PhysicalDefinitionId {
                location: jarde_reader::model::PhysicalClassLocation::StandaloneRoot {
                    snapshot: jarde_reader::model::SnapshotId("generic-call-invoke".to_owned()),
                },
                class_bytes: jarde_reader::model::ClassBytesId {
                    digest: jarde_reader::model::Digest("generic-call-invoke".to_owned()),
                    length: 0,
                },
                variant: jarde_reader::model::PhysicalVariant::Base,
            };
            SameClassInvokeUse {
                caller: "caller()V".to_owned(),
                physical_caller: PhysicalMethodId {
                    owner: physical_owner,
                    name: crate::JvmBytes(b"caller".to_vec()),
                    descriptor: crate::JvmBytes(b"()V".to_vec()),
                },
                bci,
                opcode: 0xb7,
                owner: owner.to_vec(),
                name: b"<init>".to_vec(),
                descriptor: descriptor.to_vec(),
                argument_values: Vec::new(),
                receiver_value: None,
                result_value: None,
                argument_value_facts: Vec::new(),
                receiver_value_fact: None,
                result_value_fact: None,
                ssa_operands_complete: false,
                constructor_receiver: receiver,
            }
        }

        let target = member(b"<init>", b"(Ljava/lang/Object;)V");
        for (receiver, expected) in [
            (
                Some(SameClassConstructorReceiver::UninitializedThis),
                Some(11),
            ),
            (Some(SameClassConstructorReceiver::Unknown), Some(11)),
            (None, Some(11)),
            (Some(SameClassConstructorReceiver::NewObject), None),
        ] {
            let invokes = [invoke(b"pkg/Hold", b"(Ljava/lang/Object;)V", receiver, 11)];
            let facts = SameClassUseFacts {
                complete: true,
                invokes: &invokes,
                field_uses: &[],
                member_refs: &[],
            };
            let mut budget = Budget::new(unlimited_annotation_test_limits());
            assert_eq!(
                unproved_same_class_this_delegate_bci(b"pkg/Hold", &target, &facts, &mut budget,)
                    .expect("bounded invocation scan succeeds"),
                expected,
            );
        }

        let invokes = [
            invoke(
                b"pkg/Other",
                b"(Ljava/lang/Object;)V",
                Some(SameClassConstructorReceiver::UninitializedThis),
                21,
            ),
            invoke(
                b"pkg/Hold",
                b"(Ljava/lang/String;)V",
                Some(SameClassConstructorReceiver::UninitializedThis),
                22,
            ),
        ];
        let facts = SameClassUseFacts {
            complete: true,
            invokes: &invokes,
            field_uses: &[],
            member_refs: &[],
        };
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        assert_eq!(
            unproved_same_class_this_delegate_bci(b"pkg/Hold", &target, &facts, &mut budget,)
                .expect("bounded invocation scan succeeds"),
            None,
        );
    }

    #[test]
    fn generic_call_components_are_callee_first_and_cycles_are_rejected() {
        let candidates = [0, 1, 2, 3];
        let dependencies = [
            GenericCallDependency {
                caller: 0,
                callee: 1,
            },
            GenericCallDependency {
                caller: 1,
                callee: 2,
            },
            GenericCallDependency {
                caller: 2,
                callee: 1,
            },
        ];
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        let components = generic_call_components(&candidates, &dependencies, &mut budget)
            .expect("finite graph planning is bounded");
        assert_eq!(components.len(), 2);
        assert_eq!(components[0].members, [0, 1, 2]);
        assert_eq!(components[0].order, None);
        assert_eq!(components[1].members, [3]);
        assert_eq!(components[1].order.as_deref(), Some([3].as_slice()));

        let dependencies = [
            GenericCallDependency {
                caller: 0,
                callee: 1,
            },
            GenericCallDependency {
                caller: 1,
                callee: 2,
            },
        ];
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        let components = generic_call_components(&candidates, &dependencies, &mut budget)
            .expect("finite graph planning is bounded");
        assert_eq!(components[0].order.as_deref(), Some([2, 1, 0].as_slice()));
    }

    #[test]
    fn generic_call_components_meter_dense_fan_in_and_honor_cancellation() {
        let callee_count = 8usize;
        let caller_count = 8usize;
        let candidates = (0..callee_count + caller_count).collect::<Vec<_>>();
        let dependencies = (callee_count..callee_count + caller_count)
            .flat_map(|caller| {
                (0..callee_count).map(move |callee| GenericCallDependency { caller, callee })
            })
            .collect::<Vec<_>>();

        let mut constrained_limits = unlimited_annotation_test_limits();
        // The input-manifest precharge alone cannot also fund the graph's processing passes.
        constrained_limits.analysis_steps =
            u64::try_from(candidates.len().saturating_add(dependencies.len())).unwrap_or(u64::MAX);
        let mut constrained_budget = Budget::new(constrained_limits);
        assert!(matches!(
            generic_call_components(&candidates, &dependencies, &mut constrained_budget),
            Err(Error::BudgetExceeded {
                dimension: crate::BudgetDimension::AnalysisSteps,
                ..
            })
        ));

        let mut budget = Budget::new(unlimited_annotation_test_limits());
        let components = generic_call_components(&candidates, &dependencies, &mut budget)
            .expect("a fully budgeted dense fan-in graph is ordered");
        assert_eq!(components.len(), 1);
        let expected_order = (0..callee_count + caller_count).collect::<Vec<_>>();
        assert_eq!(
            components[0].order.as_deref(),
            Some(expected_order.as_slice())
        );

        let cancellation = crate::CancellationToken::new();
        cancellation.cancel();
        let mut cancelled_budget =
            Budget::with_cancellation_token(unlimited_annotation_test_limits(), cancellation);
        assert!(matches!(
            generic_call_components(&candidates, &dependencies, &mut cancelled_budget),
            Err(Error::Cancelled { .. })
        ));
    }

    #[test]
    fn generic_call_substitution_preserves_binders_bounds_and_arrays() {
        use jarde_reader::signature::{ClassType, ClassTypeSegment};

        let class_parameters = vec![TypeParameter {
            name: b"T".to_vec(),
            class_bound: Some(SignatureType::Class(ClassType {
                segments: vec![ClassTypeSegment {
                    binary_name: b"java/lang/Number".to_vec(),
                    arguments: Vec::new(),
                }],
            })),
            interface_bounds: vec![SignatureType::Class(ClassType {
                segments: vec![ClassTypeSegment {
                    binary_name: b"java/lang/Runnable".to_vec(),
                    arguments: Vec::new(),
                }],
            })],
        }];
        let class_scope = vec![TypeParameterErasure {
            name: b"T".to_vec(),
            descriptor: b"Ljava/lang/Number;".to_vec(),
        }];
        let owner = PhysicalDefinitionId {
            location: jarde_reader::model::PhysicalClassLocation::StandaloneRoot {
                snapshot: jarde_reader::model::SnapshotId("generic-call-binder".to_owned()),
            },
            class_bytes: jarde_reader::model::ClassBytesId {
                digest: jarde_reader::model::Digest("generic-call-binder".to_owned()),
                length: 0,
            },
            variant: jarde_reader::model::PhysicalVariant::Base,
        };
        let identity = PhysicalMethodId {
            owner: owner.clone(),
            name: crate::JvmBytes(b"identity".to_vec()),
            descriptor: crate::JvmBytes(b"(Ljava/lang/Number;)Ljava/lang/Number;".to_vec()),
        };
        let caller = PhysicalMethodId {
            owner,
            name: crate::JvmBytes(b"relay".to_vec()),
            descriptor: crate::JvmBytes(b"(Ljava/lang/Number;)Ljava/lang/Number;".to_vec()),
        };
        let bound = |name: &[u8]| TypeParameter {
            name: name.to_vec(),
            class_bound: Some(SignatureType::Class(ClassType {
                segments: vec![ClassTypeSegment {
                    binary_name: b"java/lang/Number".to_vec(),
                    arguments: Vec::new(),
                }],
            })),
            interface_bounds: vec![SignatureType::Class(ClassType {
                segments: vec![ClassTypeSegment {
                    binary_name: b"java/lang/Runnable".to_vec(),
                    arguments: Vec::new(),
                }],
            })],
        };
        let callee = SameClassGenericMethodContract {
            method: identity.clone(),
            method_parameters: vec![bound(b"U")],
            parameters: vec![SignatureType::TypeVariable(b"U".to_vec())],
            result: Some(SignatureType::TypeVariable(b"U".to_vec())),
        };
        let actual = SameClassGenericArgumentSource {
            caller: caller.clone(),
            origin: SameClassGenericArgumentOrigin::Formal { slot: 1 },
            source_type: SignatureType::TypeVariable(b"T".to_vec()),
            caller_method_parameters: Vec::new(),
        };
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        let substitution = prove_same_class_generic_substitution(
            &class_scope,
            &class_parameters,
            &callee,
            &[actual],
            &mut budget,
        )
        .expect("the direct binder proof is bounded")
        .expect("the matching class intersection bounds satisfy U");
        assert_eq!(
            substitution.method_arguments,
            [SignatureType::TypeVariable(b"T".to_vec())]
        );

        let shadowed = SameClassGenericArgumentSource {
            caller: caller.clone(),
            origin: SameClassGenericArgumentOrigin::Formal { slot: 1 },
            source_type: SignatureType::TypeVariable(b"T".to_vec()),
            caller_method_parameters: vec![bound(b"T")],
        };
        let class_target = SameClassGenericMethodContract {
            method: identity.clone(),
            method_parameters: Vec::new(),
            parameters: vec![SignatureType::TypeVariable(b"T".to_vec())],
            result: Some(SignatureType::TypeVariable(b"T".to_vec())),
        };
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        assert!(
            prove_same_class_generic_substitution(
                &class_scope,
                &class_parameters,
                &class_target,
                &[shadowed],
                &mut budget,
            )
            .expect("the binder mismatch is an ordinary refusal")
            .is_none()
        );

        let array_contract = SameClassGenericMethodContract {
            method: identity,
            method_parameters: Vec::new(),
            parameters: vec![SignatureType::Array(Box::new(SignatureType::TypeVariable(
                b"T".to_vec(),
            )))],
            result: Some(SignatureType::Array(Box::new(SignatureType::TypeVariable(
                b"T".to_vec(),
            )))),
        };
        let array_source = SameClassGenericArgumentSource {
            caller,
            origin: SameClassGenericArgumentOrigin::Formal { slot: 1 },
            source_type: SignatureType::Array(Box::new(SignatureType::TypeVariable(b"T".to_vec()))),
            caller_method_parameters: Vec::new(),
        };
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        assert!(
            prove_same_class_generic_substitution(
                &class_scope,
                &class_parameters,
                &array_contract,
                &[array_source],
                &mut budget,
            )
            .expect("array binder proof is bounded")
            .is_some()
        );
    }
}

#[cfg(test)]
mod same_class_overload_proof_tests {
    use super::*;
    use jarde_java::facts::{CallTarget, InvokeKind};
    use jarde_reader::model::{
        ClassBytesId, Digest, PhysicalClassLocation, PhysicalVariant, SnapshotId,
    };
    use jarde_reader::signature::{ClassType, ClassTypeSegment};

    fn unlimited_annotation_test_limits() -> Limits {
        Limits {
            input_bytes: u64::MAX,
            archive_entries: u64::MAX,
            entry_bytes: u64::MAX,
            read_bytes: u64::MAX,
            class_bytes: u64::MAX,
            attribute_bytes: u64::MAX,
            code_bytes: u64::MAX,
            result_items: u64::MAX,
            output_bytes: u64::MAX,
            class_headers: u64::MAX,
            method_bodies: u64::MAX,
            ir_items: u64::MAX,
            ir_edges: u64::MAX,
            analysis_steps: u64::MAX,
            normalization_clones: u64::MAX,
            nested_depth: u64::MAX,
            dependency_depth: u64::MAX,
            elapsed_millis: u64::MAX,
        }
    }

    fn owner() -> PhysicalDefinitionId {
        PhysicalDefinitionId {
            location: PhysicalClassLocation::StandaloneRoot {
                snapshot: SnapshotId("gc07-overload-proof".to_owned()),
            },
            class_bytes: ClassBytesId {
                digest: Digest("gc07-overload-proof".to_owned()),
                length: 0,
            },
            variant: PhysicalVariant::Base,
        }
    }

    fn method_header(name: &[u8], descriptor: &[u8], access_flags: u16) -> MemberHeader {
        let jvm_string = |raw: &[u8]| {
            serde_json::from_value::<jarde_reader::model::JvmString>(serde_json::json!({
                "raw": raw,
                "utf16": raw.iter().map(|byte| *byte as u16).collect::<Vec<_>>(),
                "escaped": String::from_utf8_lossy(raw),
            }))
            .expect("test JVM string is valid")
        };
        MemberHeader {
            name: jvm_string(name),
            descriptor: jvm_string(descriptor),
            access_flags,
            attributes: Vec::new(),
        }
    }

    fn invoke_use(
        caller: &PhysicalMethodId,
        owner: &[u8],
        name: &[u8],
        descriptor: &[u8],
    ) -> SameClassInvokeUse {
        SameClassInvokeUse {
            caller: "relay(Ljava/lang/Number;)V".to_owned(),
            physical_caller: caller.clone(),
            bci: 7,
            opcode: 0xb6,
            owner: owner.to_vec(),
            name: name.to_vec(),
            descriptor: descriptor.to_vec(),
            argument_values: Vec::new(),
            receiver_value: None,
            result_value: None,
            argument_value_facts: Vec::new(),
            receiver_value_fact: None,
            result_value_fact: None,
            ssa_operands_complete: false,
            constructor_receiver: None,
        }
    }

    #[test]
    fn same_class_binding_defers_only_closed_same_arity_overload_competition() {
        let owner_id = owner();
        let caller = caller(&owner_id);
        let class = b"p/Bound".to_vec();
        let methods = [
            method_header(b"pick", b"(Ljava/lang/Object;)V", ACC_PUBLIC),
            method_header(b"pick", b"(Ljava/lang/String;)V", ACC_PUBLIC),
        ];
        let invoke = invoke_use(&caller, &class, b"pick", b"(Ljava/lang/Object;)V");
        let complete = SameClassUseFacts {
            complete: true,
            invokes: std::slice::from_ref(&invoke),
            field_uses: &[],
            member_refs: &[],
        };
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        assert_eq!(
            prove_same_class_method_binding(
                &class,
                Some(b"java/lang/Object"),
                &[],
                &methods,
                0,
                &complete,
                &mut budget,
            )
            .expect("closed overload competition is a deferred proof"),
            SameClassBinding::OverloadPending,
        );

        let no_incoming = SameClassUseFacts {
            complete: true,
            invokes: &[],
            field_uses: &[],
            member_refs: &[],
        };
        assert_eq!(
            prove_same_class_method_binding(
                &class,
                Some(b"java/lang/Object"),
                &[],
                &methods,
                0,
                &no_incoming,
                &mut budget,
            )
            .expect("unused overload has no call-site proof"),
            SameClassBinding::Unproved,
        );

        let incomplete = SameClassUseFacts {
            complete: false,
            invokes: std::slice::from_ref(&invoke),
            field_uses: &[],
            member_refs: &[],
        };
        assert_eq!(
            prove_same_class_method_binding(
                &class,
                Some(b"java/lang/Object"),
                &[],
                &methods,
                0,
                &incomplete,
                &mut budget,
            )
            .expect("incomplete inventory remains a refusal"),
            SameClassBinding::Unproved,
        );

        let unresolved = invoke_use(&caller, &class, b"pick", b"(Ljava/lang/Number;)V");
        let unknown_use = SameClassUseFacts {
            complete: true,
            invokes: std::slice::from_ref(&unresolved),
            field_uses: &[],
            member_refs: &[],
        };
        assert_eq!(
            prove_same_class_method_binding(
                &class,
                Some(b"java/lang/Object"),
                &[],
                &methods,
                0,
                &unknown_use,
                &mut budget,
            )
            .expect("unexplained sibling target remains a refusal"),
            SameClassBinding::Unproved,
        );
    }

    #[test]
    fn same_class_binding_defers_unreferenced_generic_sibling_for_real_same_arity_target() {
        let owner_id = owner();
        let caller = caller(&owner_id);
        let class = b"p/BoundOverload".to_vec();
        let methods = [
            method_header(b"pick", b"(Ljava/lang/Number;)V", ACC_PUBLIC),
            method_header(b"pick", b"(Ljava/lang/Comparable;)V", ACC_PUBLIC),
        ];
        // The real bytecode target is pick(Number). The generic sibling erases to Comparable
        // and has no direct invoke, but it still participates in source overload resolution.
        let invoked = invoke_use(&caller, &class, b"pick", b"(Ljava/lang/Number;)V");
        let facts = SameClassUseFacts {
            complete: true,
            invokes: std::slice::from_ref(&invoked),
            field_uses: &[],
            member_refs: &[],
        };
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        assert_eq!(
            prove_same_class_method_binding(
                &class,
                Some(b"java/lang/Object"),
                &[],
                &methods,
                1,
                &facts,
                &mut budget,
            )
            .expect("closed competing header is deferred for the overload proof"),
            SameClassBinding::OverloadPending,
        );
    }

    #[test]
    fn same_class_binding_keeps_unclosed_overload_inventories_unproved() {
        let owner_id = owner();
        let caller = caller(&owner_id);
        let class = b"p/BoundOverload".to_vec();
        let methods = [
            method_header(b"pick", b"(Ljava/lang/Number;)V", ACC_PUBLIC),
            method_header(b"pick", b"(Ljava/lang/Comparable;)V", ACC_PUBLIC),
        ];
        let mut budget = Budget::new(unlimited_annotation_test_limits());

        let no_same_name_invoke = SameClassUseFacts {
            complete: true,
            invokes: &[],
            field_uses: &[],
            member_refs: &[],
        };
        assert_eq!(
            prove_same_class_method_binding(
                &class,
                Some(b"java/lang/Object"),
                &[],
                &methods,
                1,
                &no_same_name_invoke,
                &mut budget,
            )
            .expect("an unused overload set is refused"),
            SameClassBinding::Unproved,
        );

        let invoked = invoke_use(&caller, &class, b"pick", b"(Ljava/lang/Number;)V");
        let closed_calls = SameClassUseFacts {
            complete: true,
            invokes: std::slice::from_ref(&invoked),
            field_uses: &[],
            member_refs: &[],
        };
        assert_eq!(
            prove_same_class_method_binding(
                &class,
                Some(b"java/lang/Number"),
                &[],
                &methods,
                1,
                &closed_calls,
                &mut budget,
            )
            .expect("a non-Object parent leaves external overloads open"),
            SameClassBinding::Unproved,
        );
        assert_eq!(
            prove_same_class_method_binding(
                &class,
                Some(b"java/lang/Object"),
                &[b"java/io/Serializable".to_vec()],
                &methods,
                1,
                &closed_calls,
                &mut budget,
            )
            .expect("implemented interfaces leave external overloads open"),
            SameClassBinding::Unproved,
        );
        let member_ref = SameClassMemberRef {
            owner: class.clone(),
            name: b"pick".to_vec(),
            descriptor: b"(Ljava/lang/Number;)V".to_vec(),
            method: true,
        };
        let non_body_reference = SameClassUseFacts {
            complete: true,
            invokes: std::slice::from_ref(&invoked),
            field_uses: &[],
            member_refs: std::slice::from_ref(&member_ref),
        };
        assert_eq!(
            prove_same_class_method_binding(
                &class,
                Some(b"java/lang/Object"),
                &[],
                &methods,
                1,
                &non_body_reference,
                &mut budget,
            )
            .expect("non-body method references are not source overload proof"),
            SameClassBinding::Unproved,
        );

        for (owner, descriptor, opcode) in [
            (&class[..], &b"(Ljava/io/Serializable;)V"[..], 0xb6),
            (&b"p/Foreign"[..], &b"(Ljava/lang/Number;)V"[..], 0xb6),
            (&class[..], &b"(Ljava/lang/Number;)V"[..], 0xb8),
        ] {
            let mut invoke = invoke_use(&caller, owner, b"pick", descriptor);
            invoke.opcode = opcode;
            let facts = SameClassUseFacts {
                complete: true,
                invokes: std::slice::from_ref(&invoke),
                field_uses: &[],
                member_refs: &[],
            };
            assert_eq!(
                prove_same_class_method_binding(
                    &class,
                    Some(b"java/lang/Object"),
                    &[],
                    &methods,
                    1,
                    &facts,
                    &mut budget,
                )
                .expect("unexplained, foreign, or opcode-inconsistent use is refused"),
                SameClassBinding::Unproved,
            );
        }

        let duplicate = [
            method_header(b"pick", b"(Ljava/lang/Number;)V", ACC_PUBLIC),
            method_header(b"pick", b"(Ljava/lang/Comparable;)V", ACC_PUBLIC),
            method_header(b"pick", b"(Ljava/lang/Comparable;)V", ACC_PUBLIC),
        ];
        let invoked = invoke_use(&caller, &class, b"pick", b"(Ljava/lang/Number;)V");
        let facts = SameClassUseFacts {
            complete: true,
            invokes: std::slice::from_ref(&invoked),
            field_uses: &[],
            member_refs: &[],
        };
        assert_eq!(
            prove_same_class_method_binding(
                &class,
                Some(b"java/lang/Object"),
                &[],
                &duplicate,
                1,
                &facts,
                &mut budget,
            )
            .expect("ambiguous physical declaration is refused"),
            SameClassBinding::Unproved,
        );

        for bad_flags in [ACC_PUBLIC | ACC_VARARGS, ACC_PUBLIC | 0x0040] {
            let bad = [
                method_header(b"pick", b"(Ljava/lang/Number;)V", ACC_PUBLIC),
                method_header(b"pick", b"(Ljava/lang/Comparable;)V", bad_flags),
            ];
            assert_eq!(
                prove_same_class_method_binding(
                    &class,
                    Some(b"java/lang/Object"),
                    &[],
                    &bad,
                    1,
                    &facts,
                    &mut budget,
                )
                .expect("varargs and bridge competitors are refused"),
                SameClassBinding::Unproved,
            );
        }
    }

    #[test]
    fn same_class_binding_propagates_budget_and_cancellation() {
        let owner_id = owner();
        let caller = caller(&owner_id);
        let class = b"p/BoundOverload".to_vec();
        let methods = [
            method_header(b"pick", b"(Ljava/lang/Number;)V", ACC_PUBLIC),
            method_header(b"pick", b"(Ljava/lang/Comparable;)V", ACC_PUBLIC),
        ];
        let invoked = invoke_use(&caller, &class, b"pick", b"(Ljava/lang/Number;)V");
        let facts = SameClassUseFacts {
            complete: true,
            invokes: std::slice::from_ref(&invoked),
            field_uses: &[],
            member_refs: &[],
        };
        let mut limits = unlimited_annotation_test_limits();
        limits.analysis_steps = 0;
        let mut exhausted = Budget::new(limits);
        assert!(matches!(
            prove_same_class_method_binding(
                &class,
                Some(b"java/lang/Object"),
                &[],
                &methods,
                1,
                &facts,
                &mut exhausted,
            ),
            Err(Error::BudgetExceeded {
                dimension: crate::BudgetDimension::AnalysisSteps,
                ..
            })
        ));

        let token = crate::CancellationToken::new();
        token.cancel();
        let mut cancelled =
            Budget::with_cancellation_token(unlimited_annotation_test_limits(), token);
        assert!(matches!(
            prove_same_class_method_binding(
                &class,
                Some(b"java/lang/Object"),
                &[],
                &methods,
                1,
                &facts,
                &mut cancelled,
            ),
            Err(Error::Cancelled { .. })
        ));
    }

    fn class_type(name: &[u8]) -> SignatureType {
        SignatureType::Class(ClassType {
            segments: vec![ClassTypeSegment {
                binary_name: name.to_vec(),
                arguments: Vec::new(),
            }],
        })
    }

    fn number_comparable_parameter(name: &[u8]) -> TypeParameter {
        TypeParameter {
            name: name.to_vec(),
            class_bound: Some(class_type(b"java/lang/Number")),
            interface_bounds: vec![SignatureType::Class(ClassType {
                segments: vec![ClassTypeSegment {
                    binary_name: b"java/lang/Comparable".to_vec(),
                    arguments: vec![TypeArgument::Exact(SignatureType::TypeVariable(
                        name.to_vec(),
                    ))],
                }],
            })],
        }
    }

    fn number_parameter(name: &[u8]) -> TypeParameter {
        TypeParameter {
            name: name.to_vec(),
            class_bound: Some(class_type(b"java/lang/Number")),
            interface_bounds: Vec::new(),
        }
    }

    fn caller(owner: &PhysicalDefinitionId) -> PhysicalMethodId {
        PhysicalMethodId {
            owner: owner.clone(),
            name: crate::JvmBytes(b"relay".to_vec()),
            descriptor: crate::JvmBytes(b"(Ljava/lang/Number;)V".to_vec()),
        }
    }

    fn candidate(
        owner: &PhysicalDefinitionId,
        name: &[u8],
        descriptor: &[u8],
        parameters: Vec<SignatureType>,
        method_parameters: Vec<TypeParameter>,
    ) -> SameClassOverloadCandidate {
        SameClassOverloadCandidate {
            method: PhysicalMethodId {
                owner: owner.clone(),
                name: crate::JvmBytes(name.to_vec()),
                descriptor: crate::JvmBytes(descriptor.to_vec()),
            },
            owner: b"p/Bound".to_vec(),
            descriptor: descriptor.to_vec(),
            access_flags: ACC_PUBLIC,
            parameters,
            method_parameters,
            source_writable: true,
        }
    }

    fn source(
        caller: &PhysicalMethodId,
        variable: &[u8],
        binders: Vec<TypeParameter>,
    ) -> SameClassOverloadActual {
        SameClassOverloadActual {
            source: Some(SameClassGenericArgumentSource {
                caller: caller.clone(),
                origin: SameClassGenericArgumentOrigin::Formal { slot: 1 },
                source_type: SignatureType::TypeVariable(variable.to_vec()),
                caller_method_parameters: binders,
            }),
            null_literal: false,
        }
    }

    fn primitive_source(
        caller: &PhysicalMethodId,
        slot: u16,
        descriptor: u8,
    ) -> SameClassOverloadActual {
        SameClassOverloadActual {
            source: Some(SameClassGenericArgumentSource {
                caller: caller.clone(),
                origin: SameClassGenericArgumentOrigin::Formal { slot },
                source_type: SignatureType::Base(descriptor),
                caller_method_parameters: Vec::new(),
            }),
            null_literal: false,
        }
    }

    fn invoke(
        caller: &PhysicalMethodId,
        class_parameters: &[TypeParameter],
        class_scope: &[TypeParameterErasure],
        target_descriptor: &str,
        actuals: &[SameClassOverloadActual],
        overloads: &[SameClassOverloadCandidate],
        complete: bool,
    ) -> Option<Vec<jarde_java::report::ClassSourceInvokeArgumentCast>> {
        let target = CallTarget::new(
            InvokeKind::Virtual,
            "p/Bound",
            "pick",
            target_descriptor,
            false,
        );
        prove_same_class_overload_argument_upcasts(
            b"p/Bound",
            Some(b"java/lang/Object"),
            &[],
            class_scope,
            class_parameters,
            caller,
            &target,
            17,
            complete,
            actuals,
            overloads,
            &mut Budget::new(unlimited_annotation_test_limits()),
        )
        .expect("the overload proof is bounded")
    }

    #[test]
    fn bound_overload_casts_only_to_the_physical_targets_explicit_number_bound() {
        let owner = owner();
        let caller = caller(&owner);
        let parameter = number_comparable_parameter(b"T");
        let scope = vec![TypeParameterErasure {
            name: b"T".to_vec(),
            descriptor: b"Ljava/lang/Number;".to_vec(),
        }];
        let target = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Number;)V",
            vec![class_type(b"java/lang/Number")],
            Vec::new(),
        );
        let comparable = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Comparable;)V",
            vec![class_type(b"java/lang/Comparable")],
            Vec::new(),
        );
        let object = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Object;)V",
            vec![class_type(b"java/lang/Object")],
            Vec::new(),
        );
        let actuals = [source(&caller, b"T", Vec::new())];
        let overloads = [target, comparable, object];
        let edits = invoke(
            &caller,
            &[parameter],
            &scope,
            "(Ljava/lang/Number;)V",
            &actuals,
            &overloads,
            true,
        )
        .expect("the complete closed overload set is provable");
        assert_eq!(edits.len(), 1);
        assert_eq!(edits[0].call_bci, 17);
        assert_eq!(edits[0].argument_index, 0);
        assert_eq!(edits[0].opcode, 0xb6);
        assert_eq!(
            edits[0].ty,
            jarde_java::ast::Type::Reference("java.lang.Number".to_owned())
        );
    }

    #[test]
    fn wide_second_argument_keeps_its_descriptor_position_when_casting_first() {
        let owner = owner();
        let caller = PhysicalMethodId {
            owner: owner.clone(),
            name: crate::JvmBytes(b"relay".to_vec()),
            descriptor: crate::JvmBytes(b"(Ljava/lang/Number;J)V".to_vec()),
        };
        let parameter = number_comparable_parameter(b"T");
        let scope = vec![TypeParameterErasure {
            name: b"T".to_vec(),
            descriptor: b"Ljava/lang/Number;".to_vec(),
        }];
        let number_long = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Number;J)V",
            vec![class_type(b"java/lang/Number"), SignatureType::Base(b'J')],
            Vec::new(),
        );
        let comparable_long = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Comparable;J)V",
            vec![
                class_type(b"java/lang/Comparable"),
                SignatureType::Base(b'J'),
            ],
            Vec::new(),
        );
        let object_long = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Object;J)V",
            vec![class_type(b"java/lang/Object"), SignatureType::Base(b'J')],
            Vec::new(),
        );
        let actuals = [
            source(&caller, b"T", Vec::new()),
            primitive_source(&caller, 2, b'J'),
        ];
        let edits = invoke(
            &caller,
            &[parameter],
            &scope,
            "(Ljava/lang/Number;J)V",
            &actuals,
            &[number_long, comparable_long, object_long],
            true,
        )
        .expect("both descriptor parameters close the same physical call");
        assert_eq!(edits.len(), 1);
        assert_eq!(edits[0].argument_index, 0);
    }

    #[test]
    fn plain_upper_bound_is_already_unique_and_same_name_string_is_closed_negative() {
        let owner = owner();
        let caller = caller(&owner);
        let parameter = number_parameter(b"T");
        let scope = vec![TypeParameterErasure {
            name: b"T".to_vec(),
            descriptor: b"Ljava/lang/Number;".to_vec(),
        }];
        let number = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Number;)V",
            vec![class_type(b"java/lang/Number")],
            Vec::new(),
        );
        let object = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Object;)V",
            vec![class_type(b"java/lang/Object")],
            Vec::new(),
        );
        let actuals = [source(&caller, b"T", Vec::new())];
        assert_eq!(
            invoke(
                &caller,
                &[parameter.clone()],
                &scope,
                "(Ljava/lang/Number;)V",
                &actuals,
                &[number.clone(), object.clone()],
                true,
            ),
            Some(Vec::new())
        );

        let string = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/String;)V",
            vec![class_type(b"java/lang/String")],
            Vec::new(),
        );
        assert_eq!(
            invoke(
                &caller,
                &[parameter],
                &scope,
                "(Ljava/lang/Number;)V",
                &actuals,
                &[number, string, object],
                true,
            ),
            Some(Vec::new())
        );
    }

    #[test]
    fn same_name_overload_uses_unbounded_typevar_and_does_not_narrow_to_string() {
        let owner = owner();
        let caller = caller(&owner);
        let parameter = TypeParameter {
            name: b"T".to_vec(),
            class_bound: Some(class_type(b"java/lang/Object")),
            interface_bounds: Vec::new(),
        };
        let scope = vec![TypeParameterErasure {
            name: b"T".to_vec(),
            descriptor: b"Ljava/lang/Object;".to_vec(),
        }];
        let object = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Object;)V",
            vec![class_type(b"java/lang/Object")],
            Vec::new(),
        );
        let string = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/String;)V",
            vec![class_type(b"java/lang/String")],
            Vec::new(),
        );
        assert_eq!(
            invoke(
                &caller,
                &[parameter],
                &scope,
                "(Ljava/lang/Object;)V",
                &[source(&caller, b"T", Vec::new())],
                &[object, string],
                true,
            ),
            Some(Vec::new()),
            "an unbounded T widens to Object and is not assignable to String"
        );
    }

    #[test]
    fn unknown_typevar_bound_is_not_negative_evidence_for_an_overload() {
        let owner = owner();
        let caller = caller(&owner);
        let parameter = TypeParameter {
            name: b"T".to_vec(),
            class_bound: Some(class_type(b"foreign/Unknown")),
            interface_bounds: Vec::new(),
        };
        let scope = vec![TypeParameterErasure {
            name: b"T".to_vec(),
            descriptor: b"Lforeign/Unknown;".to_vec(),
        }];
        let object = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Object;)V",
            vec![class_type(b"java/lang/Object")],
            Vec::new(),
        );
        let other = candidate(
            &owner,
            b"pick",
            b"(Lforeign/MaybeNumber;)V",
            vec![class_type(b"foreign/MaybeNumber")],
            Vec::new(),
        );
        assert_eq!(
            invoke(
                &caller,
                &[parameter],
                &scope,
                "(Ljava/lang/Object;)V",
                &[source(&caller, b"T", Vec::new())],
                &[object, other],
                true,
            ),
            None,
            "an unresolved bound/candidate relation cannot be called inapplicable"
        );
    }

    #[test]
    fn distinct_type_variables_are_not_assumed_incompatible() {
        let method_parameters = [TypeParameter {
            name: b"U".to_vec(),
            class_bound: Some(SignatureType::TypeVariable(b"T".to_vec())),
            interface_bounds: Vec::new(),
        }];
        let class_parameters = [TypeParameter {
            name: b"T".to_vec(),
            class_bound: Some(class_type(b"java/lang/Object")),
            interface_bounds: Vec::new(),
        }];
        let class_scope = [TypeParameterErasure {
            name: b"T".to_vec(),
            descriptor: b"Ljava/lang/Object;".to_vec(),
        }];
        let mut budget = Budget::new(unlimited_annotation_test_limits());
        assert_eq!(
            overload_source_type_assignable(
                &SignatureType::TypeVariable(b"U".to_vec()),
                &SignatureType::TypeVariable(b"T".to_vec()),
                &method_parameters,
                &class_scope,
                &class_parameters,
                &mut budget,
                0,
            )
            .expect("bounded type-variable comparison is charged"),
            None,
            "U extends T is related by its bound and cannot be called inapplicable"
        );
    }

    #[test]
    fn overload_proof_propagates_budget_exhaustion_and_cancellation() {
        let owner = owner();
        let caller = caller(&owner);
        let target = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Number;)V",
            vec![class_type(b"java/lang/Number")],
            Vec::new(),
        );
        let actuals = [source(&caller, b"T", Vec::new())];
        let parameters = [number_parameter(b"T")];
        let scope = [TypeParameterErasure {
            name: b"T".to_vec(),
            descriptor: b"Ljava/lang/Number;".to_vec(),
        }];
        let mut limits = unlimited_annotation_test_limits();
        limits.analysis_steps = 0;
        let mut exhausted = Budget::new(limits);
        assert!(matches!(
            prove_same_class_overload_argument_upcasts(
                b"p/Bound",
                Some(b"java/lang/Object"),
                &[],
                &scope,
                &parameters,
                &caller,
                &CallTarget::new(
                    InvokeKind::Virtual,
                    "p/Bound",
                    "pick",
                    "(Ljava/lang/Number;)V",
                    false,
                ),
                17,
                true,
                &actuals,
                &[target.clone()],
                &mut exhausted,
            ),
            Err(Error::BudgetExceeded { .. })
        ));

        let token = jarde_reader::budget::CancellationToken::new();
        token.cancel();
        let mut cancelled =
            Budget::with_cancellation_token(unlimited_annotation_test_limits(), token);
        assert!(matches!(
            prove_same_class_overload_argument_upcasts(
                b"p/Bound",
                Some(b"java/lang/Object"),
                &[],
                &scope,
                &parameters,
                &caller,
                &CallTarget::new(
                    InvokeKind::Virtual,
                    "p/Bound",
                    "pick",
                    "(Ljava/lang/Number;)V",
                    false,
                ),
                17,
                true,
                &actuals,
                &[target],
                &mut cancelled,
            ),
            Err(Error::Cancelled { .. })
        ));
    }

    #[test]
    fn callee_method_binder_is_substituted_and_unknown_user_hierarchy_refuses() {
        let owner = owner();
        let caller = caller(&owner);
        let class_parameter = number_parameter(b"T");
        let scope = vec![TypeParameterErasure {
            name: b"T".to_vec(),
            descriptor: b"Ljava/lang/Number;".to_vec(),
        }];
        let generic_target = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Number;)V",
            vec![SignatureType::TypeVariable(b"U".to_vec())],
            vec![number_parameter(b"U")],
        );
        let object = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Object;)V",
            vec![class_type(b"java/lang/Object")],
            Vec::new(),
        );
        let actuals = [source(&caller, b"T", Vec::new())];
        assert_eq!(
            invoke(
                &caller,
                &[class_parameter.clone()],
                &scope,
                "(Ljava/lang/Number;)V",
                &actuals,
                &[generic_target.clone(), object.clone()],
                true,
            ),
            Some(Vec::new())
        );

        let unknown = candidate(
            &owner,
            b"pick",
            b"(Lforeign/MaybeNumber;)V",
            vec![class_type(b"foreign/MaybeNumber")],
            Vec::new(),
        );
        assert_eq!(
            invoke(
                &caller,
                &[class_parameter],
                &scope,
                "(Ljava/lang/Number;)V",
                &actuals,
                &[generic_target, object, unknown],
                true,
            ),
            None,
            "unknown hierarchy facts cannot be treated as a negative applicability result"
        );
    }

    #[test]
    fn incomplete_or_foreign_physical_inventories_never_pin_a_target() {
        let owner = owner();
        let caller = caller(&owner);
        let parameter = number_parameter(b"T");
        let scope = vec![TypeParameterErasure {
            name: b"T".to_vec(),
            descriptor: b"Ljava/lang/Number;".to_vec(),
        }];
        let target = candidate(
            &owner,
            b"pick",
            b"(Ljava/lang/Number;)V",
            vec![class_type(b"java/lang/Number")],
            Vec::new(),
        );
        let actuals = [source(&caller, b"T", Vec::new())];
        assert_eq!(
            invoke(
                &caller,
                &[parameter.clone()],
                &scope,
                "(Ljava/lang/Number;)V",
                &actuals,
                &[target.clone()],
                false,
            ),
            None
        );

        let mut foreign = target;
        foreign.owner = b"q/Other".to_vec();
        assert_eq!(
            invoke(
                &caller,
                &[parameter],
                &scope,
                "(Ljava/lang/Number;)V",
                &actuals,
                &[foreign],
                true,
            ),
            None
        );

        let object_named_target = CallTarget::new(
            InvokeKind::Virtual,
            "p/Bound",
            "equals",
            "(Ljava/lang/Number;)V",
            false,
        );
        assert!(
            prove_same_class_overload_argument_upcasts(
                b"p/Bound",
                Some(b"java/lang/Object"),
                &[],
                &scope,
                &[number_parameter(b"T")],
                &caller,
                &object_named_target,
                17,
                true,
                &actuals,
                &[candidate(
                    &owner,
                    b"equals",
                    b"(Ljava/lang/Number;)V",
                    vec![class_type(b"java/lang/Number")],
                    Vec::new(),
                )],
                &mut Budget::new(unlimited_annotation_test_limits()),
            )
            .expect("Object method names are an ordinary refusal")
            .is_none(),
            "Object's inherited equals(Object) belongs to the source overload set"
        );
    }
}
