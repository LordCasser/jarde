#!/usr/bin/env python3
"""Guarded whole-class C2W comparison. This script runs tools only when explicitly invoked."""
from __future__ import annotations
import datetime, hashlib, json, os, re, shutil, sys, zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
PINS=HERE/'pins.json'
STRIP=('JAVA_HOME','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH')

def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def pin(p):
 p=Path(p).resolve(strict=True); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def dump(p,v):
 p=Path(p); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def check_pin(row):
 actual=pin(row['path'])
 if (actual['bytes'],actual['sha256'])!=(row.get('bytes'),row.get('sha256')):raise RuntimeError('pinned input changed: '+actual['path'])
 return actual
def package_name(text):
 m=re.search(r'(?m)^\s*package\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*;',text)
 return m.group(1) if m else ''
def rust_string_constant(source,name):
 # Parse exactly one Rust ordinary string literal following `const NAME: &str =`.
 marker=re.compile(r'\bconst\s+'+re.escape(name)+r'\s*:\s*&\s*str\s*=\s*')
 matches=list(marker.finditer(source))
 if len(matches)!=1:raise RuntimeError('expected one Rust constant '+name)
 i=matches[0].end()
 if i>=len(source) or source[i]!='"':raise RuntimeError('expected an ordinary Rust string literal for '+name)
 i+=1; out=[]
 while i<len(source):
  c=source[i]
  if c=='"':return ''.join(out)
  if c!='\\':out.append(c); i+=1; continue
  i+=1
  if i>=len(source):raise RuntimeError('unterminated escape in '+name)
  c=source[i]
  if c=='\n':
   i+=1
   while i<len(source) and source[i] in ' \t\r':i+=1
  elif c=='r':out.append('\r'); i+=1
  elif c=='n':out.append('\n'); i+=1
  elif c=='t':out.append('\t'); i+=1
  elif c=='0':out.append('\0'); i+=1
  elif c in ('\\','"',"'"):out.append(c); i+=1
  else:raise RuntimeError('unsupported escape in '+name+': \\'+c)
 raise RuntimeError('unterminated Rust string constant '+name)
def verify_candidate(cli,receipt):
 if not cli.is_file() or not os.access(cli,os.X_OK) or cli.stat().st_mode&0o777!=0o555:raise RuntimeError('candidate CLI must be executable and frozen mode 0555')
 doc=load(receipt)
 if doc.get('status')!='commands_passed_pending_independent_acceptance':raise RuntimeError('candidate build receipt is not complete/accepted for independent review')
 row=doc.get('cli')
 if not isinstance(row,dict):raise RuntimeError('candidate receipt does not pin CLI')
 actual=pin(cli)
 if row.get('path')!=actual['path'] or row.get('bytes')!=actual['bytes'] or row.get('sha256')!=actual['sha256']:raise RuntimeError('receipt CLI pin mismatch')
 cmds=[x for x in doc.get('commands',[]) if not x.get('cleanup_only')]
 if not cmds:raise RuntimeError('candidate build receipt has no commands')
 for cmd in cmds:
  if cmd.get('exit_code')!=0 or cmd.get('guard_stop') is not None:raise RuntimeError('candidate build receipt includes failed/guarded command')
  for stream in cmd.get('streams',{}).values():check_pin(stream)
 spec=json.loads(Path(doc['command_spec']['path']).read_text(encoding='utf-8'))
 actual_argv=[x.get('argv') for x in doc.get('commands',[]) if not x.get('cleanup_only')]
 if actual_argv!=spec:raise RuntimeError('candidate receipt commands differ from pinned command spec')
 if doc.get('target_absent') is not True:raise RuntimeError('candidate build receipt does not confirm target absent')
 before=doc.get('source_manifest_before'); after=doc.get('source_manifest_after')
 if not isinstance(before,list) or not before or not isinstance(after,list) or {x.get('path') for x in before}!={x.get('path') for x in after}:
  raise RuntimeError('candidate receipt source closure is incomplete or changed membership')
 for key in ('runner','command_spec'):
  if not isinstance(doc.get(key),dict):raise RuntimeError('candidate receipt lacks '+key+' pin')
  check_pin(doc[key])
 return {'cli':actual,'receipt':pin(receipt),'status':doc['status'],'command_count':len(cmds),
         'runner':doc['runner'],'command_spec':doc['command_spec']}
def env_for(home):
 e={k:v for k,v in os.environ.items() if k not in STRIP}; e['JAVA_HOME']=str(home); e['PATH']=str(Path(home)/'bin')+os.pathsep+e.get('PATH',''); return e

def main():
 if len(sys.argv)!=2:raise SystemExit('usage: collect.py FRESH_OUTPUT_DIR')
 out=Path(sys.argv[1]).resolve()
 if out.exists():raise SystemExit('refusing non-fresh output: '+str(out))
 p=load(PINS)
 if p.get('schema')!='jarde-wrap-family-comparison-pins-v1':raise RuntimeError('pins schema mismatch')
 for row in p['fixed_inputs'].values():check_pin(row)
 check_pin(p['candidate_cli']); check_pin(p['candidate_receipt'])
 cli=Path(p['candidate_cli']['path']).resolve(); receipt=Path(p['candidate_receipt']['path']).resolve()
 if not receipt.is_file():raise RuntimeError('candidate receipt unavailable; wait until root build is complete')
 candidate=verify_candidate(cli,receipt)
 manifest=load(p['fixed_inputs']['jdk_manifest']['path']); legs={}
 for row in manifest.get('legs',[]):
  name=row.get('leg')
  if name not in ('javac8','javac23'):continue
  tools={}
  for tool in ('javac','java','javap'):
   rec=row['jdk_tools'][tool]; actual=pin(rec['path'])
   if actual['bytes']!=rec['bytes'] or actual['sha256']!=rec['sha256']:raise RuntimeError('fixed JDK tool pin mismatch: '+name+'/'+tool)
   tools[tool]=Path(actual['path'])
  legs[name]={'tools':tools,'home':tools['java'].parent.parent}
 if set(legs)!={'javac8','javac23'}:raise RuntimeError('fixed JDK8/JDK23 tools missing')
 # The guard and target scanner are fixed/pinned modules; no cargo target is produced here.
 import importlib.util
 def module(path,name):
  spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
 guard=module(p['fixed_inputs']['guard']['path'],'wrap_comparison_guard')
 scanner=module(p['fixed_inputs']['target_scanner']['path'],'wrap_comparison_scanner')
 out.mkdir(parents=True); rawdir=out/'raw'; rawdir.mkdir()
 guard.ROOT=Path(p['workspace_root']); guard.OUT=rawdir; guard.ENV_VALUES={}
 guard.expected_test_summaries=lambda _i,_s:None
 guard.target_bytes=lambda:scanner.target_bytes(Path(p['workspace_root']))
 guard.command_stream=lambda path:{'path':str(Path(path).resolve()),'bytes':Path(path).stat().st_size,'sha256':sha(Path(path).read_bytes())}
 fixed={k:v for k,v in p['fixed_inputs'].items()}
 source=Path(fixed['original_source']['path']); runner=Path(fixed['runner_source']['path']); original=Path(fixed['original_class']['path'])
 expected=rust_string_constant(Path(fixed['expected_test']['path']).read_text(encoding='utf-8'),'C2W_EXPECTED_RUN')
 tool_paths=[HERE/'collect.py',HERE/'check.py',HERE/'README.md',HERE/'pins.json',HERE/'prepare_pins.py',cli,receipt,
             Path(candidate['runner']['path']),Path(candidate['command_spec']['path'])]
 tool_paths.extend(Path(x['path']) for x in fixed.values())
 tool_paths.extend(Path(tool) for leg in legs.values() for tool in leg['tools'].values())
 tool_paths=list(dict.fromkeys(Path(x).resolve(strict=True) for x in tool_paths))
 doc={'schema':'jarde-wrap-family-comparison-v1','status':'running','output_root':str(out),
      'candidate_build':candidate,'fixed_inputs':fixed,'jdk_legs':{n:{'home':str(x['home']),'tools':{k:str(v) for k,v in x['tools'].items()}} for n,x in legs.items()},
      'resource_guard':p['guard_policy'],'expected_stdout':expected,'commands':[],'original_lanes':[],'jadx_lanes':[],'jarde_lanes':[],
      'source_pins_before':[pin(Path(x['path'])) for x in fixed.values()],
      'tool_paths_before':[str(x) for x in tool_paths],'tool_pins_before':[pin(x) for x in tool_paths]}
 dump(out/'execution.json',doc); idx=0
 def run(label,argv,home):
  nonlocal idx
  idx+=1; row={'index':idx,'label':label,'argv':[str(x) for x in argv],'cwd':str(Path(p['workspace_root'])),'java_home':str(home),
               'state':'started','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  doc['commands'].append(row); dump(out/'execution.json',doc)
  result=guard.run_command(idx,row['argv'],env_for(home)); row.update(result); row['label']=label
  row['state']='guard-stopped' if row.get('guard_stop') else 'observed'
  streams={}
  for name,meta in row.get('streams',{}).items():
   q=Path(meta['path']); b=q.read_bytes(); meta.update(bytes=len(b),sha256=sha(b)); streams[name]=b
  dump(out/'execution.json',doc)
  if row.get('guard_stop') is not None:raise RuntimeError('resource guard stopped '+label)
  return row,streams.get('stdout',b''),streams.get('stderr',b'')
 def compile_run(label,sources,jdk,classdir,copy_original=False,pkg=''):
  classdir.mkdir(parents=True); empty=classdir/'empty-sourcepath'; empty.mkdir()
  frozen_copy=None
  if copy_original:
   shutil.copyfile(original,classdir/'C2W.class'); frozen_copy=pin(classdir/'C2W.class')
  flags=['-source','8','-target','8','-Xlint:-options'] if jdk=='javac8' else ['--release','8']
  cp=classdir if copy_original else classdir
  comp,_,_=run(label+'-compile',[legs[jdk]['tools']['javac'],*flags,'-proc:none','-g:none','-classpath',cp,'-sourcepath',empty,'-d',classdir,*sources],legs[jdk]['home'])
  lane={'label':label,'jdk':jdk,'sources':[pin(x) for x in sources],'compile':comp,'run':None,'runtime_state':'compile-failed-no-runtime','stdout':None,'stderr':None,'stdout_sha256':None}
  if frozen_copy:lane['frozen_class_copy']=frozen_copy
  if comp.get('exit_code')==0:
   main_class=(pkg+'.' if pkg else '')+'C2W'; runner_class=(pkg+'.' if pkg else '')+'C2WRunner'
   mainrow,mainb,maine=run(label+'-main-run',[legs[jdk]['tools']['java'],'-Xverify:all','-cp',classdir,main_class],legs[jdk]['home'])
   runrow,outb,errb=run(label+'-runner-run',[legs[jdk]['tools']['java'],'-Xverify:all','-cp',classdir,runner_class],legs[jdk]['home'])
   lane.update(run_main=mainrow,main_stdout=mainb.decode('utf-8','replace'),main_stdout_sha256=sha(mainb),
               run=runrow,runtime_state='ran' if mainrow.get('exit_code')==0 and runrow.get('exit_code')==0 else 'run-failed',
               stdout=outb.decode('utf-8','replace'),stderr=errb.decode('utf-8','replace'),stdout_sha256=sha(outb),stderr_sha256=sha(errb))
  lane['compiled_classes']=[pin(x) for x in sorted(classdir.rglob('*.class'))]
  return lane
 def runner_for(pkg,dest):
  original_text=runner.read_text(encoding='utf-8')
  if re.search(r'(?m)^\s*package\s+',original_text):raise RuntimeError('fixed Runner unexpectedly declares package')
  content=(('package '+pkg+';\n') if pkg else '')+original_text
  dest.parent.mkdir(parents=True,exist_ok=True); dest.write_text(content,encoding='utf-8'); return dest
 try:
  # The original C2W bytecode remains frozen; only the pinned Runner is compiled against it.
  for jdk in ('javac8','javac23'):
   dest=out/'original-classes'/jdk; adapter=runner_for('',out/'inputs'/'original'/jdk/'C2WRunner.java')
   lane=compile_run('original-frozen-'+jdk,[adapter],jdk,dest,copy_original=True); lane['runner']=pin(adapter)
   doc['original_lanes'].append(lane); dump(out/'execution.json',doc)
  # Two fresh whole-class JADX renders, each compiled with the same Runner under both JDKs.
  for profile in ('default','none'):
   base=out/'jadx'/profile; gen=base/'source'; gen.mkdir(parents=True)
   args=[fixed['jadx']['path'],'--no-res','--config','none','--threads-count','1']
   if profile=='none':args.extend(['--rename-flags','none'])
   args.extend(['-d',gen,original])
   render,_,_=run('jadx-'+profile+'-render',args,legs['javac23']['home'])
   sources=sorted(gen.rglob('*.java'))
   main_source=next((x for x in sources if re.search(r'\bclass\s+C2W\b',x.read_text(encoding='utf-8',errors='replace'))),None)
   row={'profile':profile,'render':render,'generated_sources':[pin(x) for x in sources],'lanes':[]}
   doc['jadx_lanes'].append(row); dump(out/'execution.json',doc)
   if render.get('exit_code')==0 and main_source is not None and sources:
    pkg=package_name(main_source.read_text(encoding='utf-8')); adapter=runner_for(pkg,out/'inputs'/'jadx'/profile/'C2WRunner.java')
    for jdk in ('javac8','javac23'):
     lane=compile_run('jadx-'+profile+'-'+jdk,[*sources,adapter],jdk,out/'jadx-classes'/profile/jdk,pkg=pkg)
     lane.update(profile=profile,runner=pin(adapter)); row['lanes'].append(lane); dump(out/'execution.json',doc)
  # Jarde whole-class rendering; preserve raw response and compile exactly its returned source.
  renderdir=out/'jarde'; renderdir.mkdir(); argv=[cli,'class-source','--input',original,'--class','C2W','--policy','single-class','--release','8','--format','json','--evidence','all']
  rend,raw,err=run('jarde-whole-class-render',argv,legs['javac23']['home']); (renderdir/'response.raw.json').write_bytes(raw)
  jrow={'render':rend,'raw_response':pin(renderdir/'response.raw.json'),'render_stderr_sha256':sha(err),'lanes':[],'generated_source':None}
  doc['jarde_lanes'].append(jrow)
  try:
   response=json.loads(raw.decode('utf-8')) if rend.get('exit_code')==0 else None
  except Exception:response=None
  text=response.get('text') if isinstance(response,dict) else None
  if isinstance(text,str):
   src=renderdir/'C2W.java'; src.write_text(text,encoding='utf-8'); jrow['generated_source']=pin(src); jrow['response_summary']={'class':response.get('class'),'outcome':response.get('outcome'),'execution':response.get('execution')}
   pkg=package_name(text); adapter=runner_for(pkg,out/'inputs'/'jarde'/'C2WRunner.java')
   for jdk in ('javac8','javac23'):
    lane=compile_run('jarde-'+jdk,[src,adapter],jdk,out/'jarde-classes'/jdk,pkg=pkg); lane['runner']=pin(adapter); jrow['lanes'].append(lane); dump(out/'execution.json',doc)
  doc['source_pins_after']=[pin(Path(x['path'])) for x in fixed.values()]
  doc['tool_pins_after']=[pin(Path(x)) for x in doc['tool_paths_before']]
  doc['source_tool_inputs_unchanged']=doc['source_pins_before']==doc['source_pins_after']
  doc['source_tool_inputs_unchanged']=doc['source_tool_inputs_unchanged'] and doc['tool_pins_before']==doc['tool_pins_after']
  doc['actual_command_count']=len(doc['commands'])
  doc['status']='observed' if doc['source_tool_inputs_unchanged'] else 'failed'
  if doc['status']!='observed':doc['failure']='immutable inputs changed during collection'
  dump(out/'execution.json',doc); return 0 if doc['status']=='observed' else 1
 except BaseException as exc:
  doc['status']='failed'; doc['failure']={'type':type(exc).__name__,'message':str(exc),'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}; dump(out/'execution.json',doc); raise
if __name__=='__main__':
 try:raise SystemExit(main())
 except SystemExit:raise
 except Exception as exc:
  print(f'collector failed: {type(exc).__name__}: {exc}',file=sys.stderr); raise SystemExit(1)
