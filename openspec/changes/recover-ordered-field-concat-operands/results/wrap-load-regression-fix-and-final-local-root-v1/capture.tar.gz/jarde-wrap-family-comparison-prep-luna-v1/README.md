# C2W whole-class comparison

This preparation contains a guarded collector and independent checker for the complete `C2W`
class. It compares the frozen original class, fresh JADX `default` and `none` source, and the
Jarde class-source response. Each compiled source is kept unchanged; only the fixed
`C2WRunner.java` receives a package declaration when its generated class requires one.

Each lane compiles under the fixed JDK 8 and JDK 23 pins, then runs both `C2W.main` and
`C2WRunner` with `-Xverify:all`. The checker requires every compile and runtime to succeed,
requires each Runner output to equal the exact `C2W_EXPECTED_RUN` Rust test constant, and compares
each generated `C2W.main` output byte-for-byte with the frozen class under the same JDK. This
exercises the adjacent catch blocks and reused local slot in the real `main` method.

The collector requires the frozen root-v10 CLI and completed `execution.json` receipt, verifies
their pins and command evidence, and does not build Jarde. It refuses an existing output
directory. Every external command runs through the pinned one-second guard, which enforces at
least 5 GiB free space and a maximum 1 GiB workspace `target` directory.

After the root-v10 build receipt is complete, run `prepare_pins.py`, then invoke:

```sh
python3 -B /private/tmp/jarde-wrap-family-comparison-prep-luna-v1/collect.py /private/tmp/jarde-wrap-family-comparison-root-v1
python3 -B /private/tmp/jarde-wrap-family-comparison-prep-luna-v1/check.py /private/tmp/jarde-wrap-family-comparison-root-v1/execution.json
```

Preparation only hashed fixed inputs and statically parsed these Python files. It did not invoke
Cargo, JDK, JADX, or the Jarde CLI.
