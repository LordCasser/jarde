#!/usr/bin/env python3
"""Freeze static inputs for the C2W whole-class differential; launches no toolchain."""
import hashlib, json
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
HERE=Path(__file__).resolve().parent
FIX=ROOT/'openspec/evidence/java-syntax-2026-09-30/cf15-crossing-patrol/wrap'
JDK_MANIFEST=ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
GUARD=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
JADX=Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_JAR=Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
CLI=Path('/private/tmp/jarde-ordered-field-final-check-root-v10/candidate-cli')
RECEIPT=Path('/private/tmp/jarde-ordered-field-final-check-root-v10/execution.json')
def pin(p):
 p=Path(p).resolve(strict=True); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def main():
 rows={name:pin(path) for name,path in {
  'original_class':FIX/'original/C2W.class','original_source':FIX/'C2W.java','runner_source':FIX/'C2WRunner.java',
  'expected_test':ROOT/'tests/p3_throwable_wrap_arguments.rs','jdk_manifest':JDK_MANIFEST,
  'jadx':JADX,'jadx_jar':JADX_JAR,'guard':GUARD,'target_scanner':SCANNER}.items()}
 manifest=json.loads(JDK_MANIFEST.read_text(encoding='utf-8'))
 legs={}
 for row in manifest.get('legs',[]):
  if row.get('leg') not in ('javac8','javac23'): continue
  tools={}
  for name in ('javac','java','javap'):
   t=row.get('jdk_tools',{}).get(name)
   if not t: raise SystemExit('missing fixed JDK pin '+row.get('leg','?')+'/'+name)
   p=Path(t['path']).resolve(strict=True); actual=pin(p)
   if actual['bytes']!=t.get('bytes') or actual['sha256']!=t.get('sha256'):
    raise SystemExit('fixed JDK tool differs from manifest: '+str(p))
   tools[name]=actual
  legs[row['leg']]={'home':str(Path(tools['java']['path']).parent.parent),'tools':tools}
 if set(legs)!={'javac8','javac23'}: raise SystemExit('JDK8 and JDK23 manifest legs are required')
 doc={'schema':'jarde-wrap-family-comparison-pins-v1','status':'prepared_not_executed','workspace_root':str(ROOT),
      'fixture_root':str(FIX),'fixed_inputs':rows,'jdk_legs':legs,
      'candidate_cli':pin(CLI),'candidate_receipt':pin(RECEIPT),
      'guard_policy':{'minimum_free_bytes':5*1024**3,'maximum_target_bytes':1024**3,'sample_interval_seconds':1},
      'execution_policy':{'jdk_order':['javac8','javac23'],'profiles':['jadx-default','jadx-none'],
                          'lane_groups':['original-frozen-class','jadx-complete-source','jarde-complete-source'],
                          'jarde_build':'never; receipt must be complete before collector starts'}}
 (HERE/'pins.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print('pins.json prepared; no JDK/JADX/CLI/Cargo command executed')
if __name__=='__main__':main()
