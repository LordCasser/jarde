#!/usr/bin/env python3
"""Independent acceptance checker for the complete C2W differential receipt."""
import hashlib, json, re, sys
from pathlib import Path

SCHEMA='jarde-wrap-family-comparison-v1'
def sha(b):return hashlib.sha256(b).hexdigest()
def pin_ok(row):
 try:
  b=Path(row['path']).read_bytes(); return len(b)==row.get('bytes') and sha(b)==row.get('sha256')
 except Exception:return False
def strip_java_comments_and_literals(text):
 # Keep line breaks and offsets while blanking comments/string/char literals for declaration scans.
 out=list(text); i=0; state='code'
 while i<len(text):
  c=text[i]; n=text[i+1] if i+1<len(text) else ''
  if state=='code':
   if c=='/' and n=='/':out[i]=out[i+1]=' '; i+=2; state='line'; continue
   if c=='/' and n=='*':out[i]=out[i+1]=' '; i+=2; state='block'; continue
   if c=='"':out[i]=' '; i+=1; state='string'; continue
   if c=="'":out[i]=' '; i+=1; state='char'; continue
   i+=1; continue
  if state=='line':
   if c=='\n':state='code'
   else:out[i]=' '
   i+=1; continue
  if state=='block':
   if c=='*' and n=='/':out[i]=out[i+1]=' '; i+=2; state='code'; continue
   if c!='\n':out[i]=' '
   i+=1; continue
  if c=='\\':
   out[i]=' '; i+=1
   if i<len(text):
    if text[i]!='\n':out[i]=' '
    i+=1
   continue
  if (state=='string' and c=='"') or (state=='char' and c=="'"):out[i]=' '; state='code'; i+=1; continue
  if c!='\n':out[i]=' '
  i+=1
 return ''.join(out)
def class_and_public_methods(text):
 clean=strip_java_comments_and_literals(text)
 if not re.search(r'\bclass\s+C2W\b',clean):return None,set()
 names=set(re.findall(r'(?m)^\s*public\s+(?:(?:static|final|synchronized|strictfp)\s+)*[\w.$<>?,\[\] ]+\s+([A-Za-z_$][\w$]*)\s*\(',clean))
 return 'C2W',names
def rust_string_constant(source,name):
 matches=list(re.finditer(r'\bconst\s+'+re.escape(name)+r'\s*:\s*&\s*str\s*=\s*',source))
 if len(matches)!=1:raise ValueError('expected one Rust constant '+name)
 i=matches[0].end()
 if i>=len(source) or source[i]!='"':raise ValueError('expected ordinary Rust string literal '+name)
 i+=1; out=[]
 while i<len(source):
  c=source[i]
  if c=='"':return ''.join(out)
  if c!='\\':out.append(c); i+=1; continue
  i+=1
  if i>=len(source):raise ValueError('unterminated Rust string escape')
  c=source[i]
  if c=='\n':
   i+=1
   while i<len(source) and source[i] in ' \t\r':i+=1
  elif c=='n':out.append('\n'); i+=1
  elif c=='r':out.append('\r'); i+=1
  elif c=='t':out.append('\t'); i+=1
  elif c=='0':out.append('\0'); i+=1
  elif c in ('\\','"',"'"):out.append(c); i+=1
  else:raise ValueError('unsupported Rust escape')
 raise ValueError('unterminated Rust string '+name)
def errors_for(doc):
 e=[]
 if doc.get('schema')!=SCHEMA:e.append('schema mismatch')
 if doc.get('status')!='observed':e.append('collector did not finish successfully')
 if doc.get('source_tool_inputs_unchanged') is not True:e.append('immutable source/tool pins changed')
 if doc.get('source_pins_before')!=doc.get('source_pins_after'):e.append('fixture input before/after pins differ')
 for group in ('source_pins_before','source_pins_after','tool_pins_before','tool_pins_after'):
  for row in doc.get(group,[]):
   if not pin_ok(row):e.append('stale or missing '+group+' pin: '+str(row.get('path')))
 if doc.get('tool_pins_before')!=doc.get('tool_pins_after'):e.append('tool and candidate pins changed during collection')
 build=doc.get('candidate_build',{})
 if build.get('status')!='commands_passed_pending_independent_acceptance':e.append('candidate build receipt status mismatch')
 for key in ('cli','receipt','runner','command_spec'):
  if not pin_ok(build.get(key,{})):e.append('candidate build '+key+' pin invalid')
 try:
  receipt=json.loads(Path(build['receipt']['path']).read_text(encoding='utf-8'))
  if receipt.get('status')!=build.get('status'):e.append('candidate receipt status differs from embedded build status')
  if receipt.get('cli')!=build.get('cli'):e.append('candidate CLI pin differs from root receipt')
  for key in ('runner','command_spec'):
   if receipt.get(key)!=build.get(key):e.append('candidate receipt '+key+' differs from embedded pin')
  if receipt.get('target_absent') is not True:e.append('candidate root receipt does not confirm target absent')
  before=receipt.get('source_manifest_before'); after=receipt.get('source_manifest_after')
  if not isinstance(before,list) or not before or not isinstance(after,list) or {x.get('path') for x in before}!={x.get('path') for x in after}:
   e.append('candidate root source manifest is missing or changed membership')
  spec=json.loads(Path(build['command_spec']['path']).read_text(encoding='utf-8'))
  if [x.get('argv') for x in receipt.get('commands',[]) if not x.get('cleanup_only')]!=spec:e.append('candidate receipt command argv differs from pinned spec')
  for cmd in receipt.get('commands',[]):
   if cmd.get('exit_code')!=0 or cmd.get('guard_stop') is not None:e.append('candidate root command failed/guarded')
   for stream in cmd.get('streams',{}).values():
    if not pin_ok(stream):e.append('candidate root raw stream pin invalid')
 except Exception as ex:e.append('candidate build receipt cannot be verified: '+type(ex).__name__+': '+str(ex))
 expected=doc.get('expected_stdout')
 if not isinstance(expected,str) or not expected.endswith('\n'):e.append('expected stdout missing or malformed')
 try:
  pins_for_expected=json.loads((Path(__file__).resolve().parent/'pins.json').read_text(encoding='utf-8'))
  fixture_expected=rust_string_constant(Path(pins_for_expected['fixed_inputs']['expected_test']['path']).read_text(encoding='utf-8'),'C2W_EXPECTED_RUN')
  if expected!=fixture_expected:e.append('recorded expected stdout differs from pinned Rust test constant')
 except Exception as ex:e.append('cannot independently recover pinned expected stdout: '+type(ex).__name__+': '+str(ex))
 lanes=[]
 for row in doc.get('original_lanes',[]):lanes.append(('original',row))
 for prof in doc.get('jadx_lanes',[]):
  for row in prof.get('lanes',[]):lanes.append(('jadx-'+str(prof.get('profile')),row))
 for prof in doc.get('jarde_lanes',[]):
  for row in prof.get('lanes',[]):lanes.append(('jarde',row))
 ids=[(kind,row.get('jdk'),row.get('profile')) for kind,row in lanes]
 required={('original','javac8',None),('original','javac23',None)}
 required|={(f'jadx-{profile}',jdk,profile) for profile in ('default','none') for jdk in ('javac8','javac23')}
 required|={('jarde',jdk,None) for jdk in ('javac8','javac23')}
 if set(ids)!=required or len(ids)!=len(required):e.append('whole-class lane matrix incomplete or duplicated')
 if len(doc.get('original_lanes',[]))!=2:e.append('original frozen-class lanes missing')
 if {x.get('profile') for x in doc.get('jadx_lanes',[])}!={'default','none'}:e.append('JADX default/none full-class renders missing')
 if len(doc.get('jarde_lanes',[]))!=1:e.append('Jarde whole-class render missing')
 original_main={}
 for row in doc.get('original_lanes',[]):
  rp=row.get('run_main',{}).get('streams',{}).get('stdout',{})
  if pin_ok(rp):original_main[row.get('jdk')]=Path(rp['path']).read_bytes()
 if set(original_main)!={'javac8','javac23'}:e.append('original frozen-class main stdout baseline missing')
 # Runner output is the fixture's exact Rust constant. C2W.main is compared with the frozen
 # class under the same JDK, covering the repeated catch-slot path directly.
 for kind,row in lanes:
  label=row.get('label','?'); comp=row.get('compile',{})
  if comp.get('exit_code')!=0 or comp.get('guard_stop') is not None:e.append('lane compile failed: '+label)
  if row.get('frozen_class_copy'):
   if not pin_ok(row['frozen_class_copy']):e.append('original frozen class copy pin invalid: '+label)
   elif row['frozen_class_copy'].get('sha256')!=doc.get('fixed_inputs',{}).get('original_class',{}).get('sha256'):
    e.append('original lane did not preserve frozen C2W.class bytes: '+label)
  mainrun=row.get('run_main')
  if not isinstance(mainrun,dict):e.append('C2W.main was not run: '+label)
  else:
   if mainrun.get('exit_code')!=0 or mainrun.get('guard_stop') is not None:e.append('C2W.main runtime failed: '+label)
   mp=mainrun.get('streams',{}).get('stdout',{})
   if not pin_ok(mp):e.append('C2W.main stdout pin invalid: '+label)
   else:
    mainbytes=Path(mp['path']).read_bytes()
    if sha(mainbytes)!=row.get('main_stdout_sha256'):e.append('C2W.main stdout hash mismatch: '+label)
    baseline=original_main.get(row.get('jdk'))
    if baseline is not None and mainbytes!=baseline:e.append('C2W.main stdout differs from frozen original: '+label)
  run=row.get('run')
  if not isinstance(run,dict):e.append('compile failure/no runtime in lane: '+label); continue
  if run.get('exit_code')!=0 or run.get('guard_stop') is not None:e.append('lane runtime failed: '+label)
  outpin=run.get('streams',{}).get('stdout',{})
  if not pin_ok(outpin):e.append('runtime stdout pin invalid: '+label); continue
  actual=Path(outpin['path']).read_bytes()
  if expected is not None and actual!=expected.encode('utf-8'):e.append('runtime stdout differs from C2W_EXPECTED_RUN: '+label)
  if sha(actual)!=row.get('stdout_sha256'):e.append('runtime stdout hash differs from lane record: '+label)
  for c in row.get('compiled_classes',[]):
   if not pin_ok(c):e.append('compiled class evidence pin invalid: '+label)
  for source in row.get('sources',[]):
   if not pin_ok(source):e.append('compiled source pin invalid: '+label)
 # Every source renderer must have supplied an entire compilable C2W source, with all fixture public methods.
 source_rows=[]
 for prof in doc.get('jadx_lanes',[]):
  for s in prof.get('generated_sources',[]):source_rows.append(('JADX-'+str(prof.get('profile')),s))
 for prof in doc.get('jarde_lanes',[]):
  if prof.get('generated_source'):source_rows.append(('Jarde',prof['generated_source']))
 if len([x for x in source_rows if x[0].startswith('JADX')])<2:e.append('JADX did not emit a complete source for both profiles')
 if not any(k=='Jarde' for k,_ in source_rows):e.append('Jarde generated whole-class source missing')
 required_methods=set()
 try:
  pins=json.loads((Path(__file__).resolve().parent/'pins.json').read_text(encoding='utf-8'))
  original=Path(pins['fixed_inputs']['original_source']['path']).read_text(encoding='utf-8')
  _,required_methods=class_and_public_methods(original)
  if 'main' not in required_methods:e.append('fixture parser did not find C2W.main')
 except Exception as ex:e.append('cannot parse fixture public API: '+type(ex).__name__+': '+str(ex))
 for label,ref in source_rows:
  if not pin_ok(ref):e.append('generated source pin invalid: '+label);continue
  text=Path(ref['path']).read_text(encoding='utf-8',errors='replace')
  if re.search(r'@bytecode|not\s+recovered',text,re.I):e.append('generated source contains refusal marker: '+label)
  cls,names=class_and_public_methods(text)
  if cls!='C2W':e.append('generated source does not declare complete C2W class: '+label)
  missing=required_methods-names
  if missing:e.append('generated source omitted public fixture method(s) '+', '.join(sorted(missing))+': '+label)
 # Command provenance is mandatory, including failed commands and their raw streams.
 commands=doc.get('commands',[])
 if not commands:e.append('no guarded command evidence')
 if doc.get('actual_command_count')!=len(commands):e.append('actual command count mismatch')
 for c in commands:
  if c.get('exit_code') is None or c.get('guard_stop') is not None:e.append('command incomplete or resource guard stopped: '+str(c.get('label')))
  for stream in ('stdout','stderr'):
   if not pin_ok(c.get('streams',{}).get(stream,{})):e.append('command raw stream pin invalid: '+str(c.get('label'))+'/'+stream)
 # Refuse an incorrectly partial successful receipt even if the lane list was edited.
 for jrow in doc.get('jarde_lanes',[]):
  if jrow.get('render',{}).get('exit_code')!=0:e.append('Jarde class-source render failed')
  if not jrow.get('generated_source'):e.append('Jarde render has no source text')
 for prow in doc.get('jadx_lanes',[]):
  if prow.get('render',{}).get('exit_code')!=0:e.append('JADX render failed: '+str(prow.get('profile')))
  if not prow.get('generated_sources'):e.append('JADX render emitted no full source files: '+str(prow.get('profile')))
 return e
def main():
 if len(sys.argv)!=2:raise SystemExit('usage: check.py EXECUTION_JSON')
 doc=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8')); errs=errors_for(doc)
 if errs:
  for x in errs:print('FAIL:',x)
  return 1
 print('all eight complete-class JDK lanes compiled and ran with byte-identical C2W_EXPECTED_RUN; no refusal markers found')
 return 0
if __name__=='__main__':raise SystemExit(main())
