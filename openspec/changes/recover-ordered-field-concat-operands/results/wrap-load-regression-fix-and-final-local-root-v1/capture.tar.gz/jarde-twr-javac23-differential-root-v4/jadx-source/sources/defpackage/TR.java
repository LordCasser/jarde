package defpackage;

/* JADX INFO: loaded from: TR-javac23-frozen.jar:TR.class */
public class TR implements AutoCloseable {
    private final String name;

    public TR(String str) {
        this.name = str;
    }

    public String use() {
        return "used:" + this.name;
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        System.out.println("closed:" + this.name);
    }

    static String one(String str) {
        TR tr = new TR(str);
        try {
            String strUse = tr.use();
            tr.close();
            return strUse;
        } catch (Throwable th) {
            try {
                tr.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    static String two(String str) {
        TR tr = new TR(str + "a");
        try {
            TR tr2 = new TR(str + "b");
            try {
                String str2 = tr.use() + tr2.use();
                tr2.close();
                tr.close();
                return str2;
            } catch (Throwable th) {
                try {
                    tr2.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        } catch (Throwable th3) {
            try {
                tr.close();
            } catch (Throwable th4) {
                th3.addSuppressed(th4);
            }
            throw th3;
        }
    }

    public static void main(String[] strArr) {
        System.out.println(one("p"));
        System.out.println(two("q"));
    }
}
