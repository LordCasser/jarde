# Anonymous superclass argument replay comparison

This private collector compares the frozen three-class fixture with two already-built Jarde CLIs: the parent root-v5 build and the current final-check v2 build. It validates each CLI against its focused receipt and frozen executable, then builds one deterministic zip from `AnonymousSuperArgs.class`, `AnonymousSuperArgs$1.class`, and `Base.class` without changing the fixture.

The collector reuses the pinned root resource guard and target-size scanner, and the fixed JDK 8/23 paths in the existing controls manifest. It does not build Jarde. The runner records original frozen-class runs and recompiles the checked-in `AnonymousSuperArgs.java` plus `Base.java` on both JDKs. It runs pinned JADX against the same zip, retains every emitted `.java` file, and submits the whole source set unchanged to both compilers. It asks both Jarde CLIs for JSON and text output for the root, anonymous child, and `Base`; it keeps full JSON, direct text, method text, and concat report facts. All attempted commands retain raw stdout/stderr and their exit status. Compile failure is preserved and suppresses runtime execution for that lane.

Root can collect the comparison with:

```sh
python3 -B /private/tmp/jarde-anonymous-super-args-comparison-prep-luna-v4/collect.py \
  /private/tmp/jarde-loop-combined-focused-root-v5/candidate-cli \
  /private/tmp/jarde-loop-combined-focused-root-v5/execution.json \
  /private/tmp/jarde-ordered-field-final-check-root-v2/candidate-cli \
  /private/tmp/jarde-ordered-field-final-check-root-v2/execution.json \
  /private/tmp/jarde-anonymous-super-args-comparison-root-v1
```

Then run the standard-library-only independent checker:

```sh
python3 -B /private/tmp/jarde-anonymous-super-args-comparison-prep-luna-v4/check.py \
  /private/tmp/jarde-anonymous-super-args-comparison-root-v1/execution.json
```

`check.py` compares each whole-class runtime observation with the exact oracle recorded by the existing `replay.py`, and reports per-JDK improvement, regression, matching, or incomplete observations. It does not promote failed compilation to success and does not assume either CLI or JADX must compile. The root/child method comparison records whether emitted method text, report text, and concat facts changed; it makes no claim about which result is correct without the runtime oracle.

Output is private and must be a fresh directory. This preparation has not run Cargo, JDK, JADX, or either CLI.


The v2 full collector records each CLI render. To test Jarde output directly, this thin runner reads the pinned `AnonymousSuperArgs` and `Base` source pins from each candidate's JSON report, verifies each file is byte-for-byte equal to its report `text`, then compiles and runs those two candidate sources under JDK 8 and 23. It uses no original fixture source, changes no source, and does not rerun CLI or JADX:

```sh
python3 -B /private/tmp/jarde-anonymous-super-args-comparison-prep-luna-v4/projected-root-replay.py \
  /private/tmp/jarde-anonymous-super-args-projected-root-replay-root-v1
```

The projected-root receipt identifies each candidate lane and its exact Jarde source pins, distinguishing this root+Base compile scope from v2's three-physical-class render lanes. Compile failures remain compile-failed/no-runtime observations.
