#!/usr/bin/env python3
"""Independently classify recorded anonymous-super-args observations; runs no tools."""
from __future__ import annotations
import argparse
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile

HERE = Path(__file__).resolve().parent
EXPECTED = b'arg:capture|arg:super-label|arg:super-value|base:explicit:17\nexplicit:17:captured\n'
CLI_LABELS = ('parent_v5', 'current_final_v2')
CLASSES = ('AnonymousSuperArgs', 'AnonymousSuperArgs$1', 'Base')
JDKS = ('javac8', 'javac23')


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def pin(path: Path) -> dict:
    p = Path(path).resolve(strict=True)
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': sha(raw)}


def verify(record: dict, base: Path | None = None) -> bytes:
    need(isinstance(record, dict) and all(k in record for k in ('path', 'bytes', 'sha256')), 'incomplete artifact pin')
    path = Path(record['path'])
    need(not path.is_symlink() and path.is_file(), f'missing or linked artifact: {path}')
    resolved = path.resolve()
    if base is not None:
        need(resolved.is_relative_to(base.resolve()), f'artifact escaped expected directory: {path}')
    raw = path.read_bytes()
    need(len(raw) == record['bytes'] and sha(raw) == record['sha256'], f'artifact pin differs: {path}')
    return raw


def lane_state(lane: dict) -> str:
    compile_row = lane.get('compile')
    run_row = lane.get('run')
    if compile_row is None:
        return 'no-runtime-observation'
    if compile_row.get('exit_code') != 0 or compile_row.get('guard_stop') is not None:
        return 'compile-failed'
    if run_row is None:
        return 'no-runtime-observation'
    if run_row.get('exit_code') != 0 or run_row.get('guard_stop') is not None:
        return 'run-failed'
    return 'oracle-match' if lane.get('oracle_match') is True else 'runtime-mismatch'


def verify_captured_lane(lane: dict, outdir: Path, jdk_legs: dict) -> None:
    compile_row = lane.get('compile')
    run_row = lane.get('run')
    source_records = lane.get('sources', [])
    for item in source_records:
        verify(item)
    source_paths = [str(Path(item['path']).resolve()) for item in source_records]
    if compile_row is not None:
        compile_argv = compile_row.get('argv', [])
        leg = jdk_legs[lane['jdk']]
        need(compile_argv and compile_argv[0] == leg['tools']['javac'], 'compile used a different javac than the pinned JDK')
        need(source_paths and compile_argv[-len(source_paths):] == source_paths, 'compile source arguments differ from pinned complete source set')
        for stream in compile_row.get('streams', {}).values():
            verify(stream, outdir / 'raw')
    if run_row is None:
        need(lane.get('runtime_state', '').startswith('no-runtime'), 'run command is missing without a no-runtime state')
        return
    stdout = verify(run_row['streams']['stdout'], outdir / 'raw')
    stderr = verify(run_row['streams']['stderr'], outdir / 'raw')
    need(run_row.get('argv', [None])[0] == jdk_legs[lane['jdk']]['tools']['java'],
         'runtime used a different java than the pinned JDK')
    need(run_row.get('argv', [None])[-1] == lane.get('main_class'), 'runtime main class differs from the recorded source identity')
    need(sha(stdout) == lane.get('stdout_sha256') and stdout.decode('utf-8', 'replace') == lane.get('stdout'),
         'lane stdout differs from its raw run stream')
    need(sha(stderr) == lane.get('stderr_sha256') and stderr.decode('utf-8', 'replace') == lane.get('stderr'),
         'lane stderr differs from its raw run stream')


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('execution', type=Path)
    ap.add_argument('--out', type=Path)
    args = ap.parse_args()
    execution = args.execution.resolve(strict=True)
    outdir = execution.parent.resolve()
    doc = json.loads(execution.read_text(encoding='utf-8'))
    need(doc.get('schema') == 'anonymous-super-args-candidate-comparison-v1', 'unexpected comparison schema')
    need(doc.get('status') == 'observed', 'collector did not finish an observation run')
    before = doc.get('source_pins_before')
    after = doc.get('source_pins_after')
    need(isinstance(before, list) and isinstance(after, list) and before == after and doc.get('source_inputs_unchanged') is True,
         'pinned source/tool inputs changed during collection')
    for item in before:
        verify(item)
    for label in ('parent_v5', 'current_final_v2'):
        evidence = doc['candidate_clis'][label]
        verify(evidence['cli'])
        cli_pin = evidence['cli']
        cli_path = Path(cli_pin['path'])
        need(cli_path.stat().st_mode & 0o777 == 0o555, f'{label} CLI is not mode 0555')
        receipt_raw = verify(evidence['receipt'])
        receipt_doc = json.loads(receipt_raw)
        need(receipt_doc.get('status') == 'commands_passed_pending_independent_acceptance',
             f'{label} focused receipt status differs')
        need(receipt_doc.get('cli', {}).get('path') == cli_pin['path']
             and receipt_doc.get('cli', {}).get('bytes') == cli_pin['bytes']
             and receipt_doc.get('cli', {}).get('sha256') == cli_pin['sha256'],
             f'{label} CLI does not match its focused receipt')
    verify(doc['replay_oracle']['pin'])
    for item in doc.get('frozen_classes', []) + doc.get('source_files', []):
        verify(item)
    manifest_raw = verify(doc['jdk_manifest'])
    manifest = json.loads(manifest_raw)
    for tool in ('jadx', 'jadx_jar', 'guard', 'scanner'):
        verify(doc['tools'][tool])
    for leg_name in JDKS:
        leg = doc['jdk_legs'][leg_name]
        manifest_leg = next((item for item in manifest.get('legs', []) if item.get('leg') == leg_name), None)
        need(manifest_leg is not None and manifest_leg.get('jdk_tools') == leg['pins'],
             f'fixed {leg_name} tool pins differ from the manifest')
        for name in ('javac', 'java', 'javap'):
            verify(leg['pins'][name])
    raw_inventory = set()
    command_rows = doc.get('commands', [])
    for index, row in enumerate(command_rows, 1):
        need(row.get('index') == index, 'command indices are not contiguous')
        need(row.get('guard_stop') is None, f'guard stopped command {row.get("label")}')
        for stream in row.get('streams', {}).values():
            verify(stream, outdir / 'raw')
            raw_inventory.add(Path(stream['path']).resolve())
    actual_raw = {p.resolve() for p in (outdir / 'raw').glob('*.raw') if p.is_file()}
    need(raw_inventory == actual_raw, 'raw stream inventory is incomplete or contains unreferenced files')
    archive = doc.get('zip', {})
    verify(archive.get('pin', {}), outdir)
    with zipfile.ZipFile(archive['pin']['path']) as zf:
        members = sorted(zf.namelist())
    need(members == sorted(x['path'].split('/')[-1] for x in doc['frozen_classes']), 'class zip members differ from frozen class set')
    need(doc.get('replay_oracle', {}).get('stdout', '').encode() == EXPECTED, 'recorded source oracle differs from reviewed fixture oracle')
    for original in doc.get('original_class_runs', []):
        raw = verify(original['command']['streams']['stdout'], outdir / 'raw')
        verify(original['command']['streams']['stderr'], outdir / 'raw')
        need(original['command'].get('argv', [None])[0] == doc['jdk_legs'][original['jdk']]['tools']['java']
             and original['command'].get('argv', [])[-1] == 'AnonymousSuperArgs',
             'frozen class was not run by the pinned JDK/java main')
        need(sha(raw) == original['stdout_sha256'] and raw.decode('utf-8', 'replace') == original['stdout'],
             'frozen-class stdout differs from its raw run stream')
    for record in doc.get('javap', []):
        raw = verify(record['command']['streams']['stdout'], outdir / 'raw')
        need(record['command'].get('argv', [None])[0] == doc['jdk_legs'][record['jdk']]['tools']['javap'],
             'javap command differs from the pinned JDK')
        need(verify(record['stdout'], outdir) == raw, 'saved javap output differs from raw stdout')
    jadx_command = doc.get('jadx', {}).get('command')
    if jadx_command:
        need(jadx_command.get('argv', [None])[0] == doc['tools']['jadx']['path'], 'JADX command differs from pinned binary')
        verify(jadx_command['streams']['stdout'], outdir / 'raw')
        verify(jadx_command['streams']['stderr'], outdir / 'raw')

    # Every physical class was requested in both formats from both frozen CLIs.
    renders = {item['cli']: item for item in doc.get('candidate_renders', [])}
    need(set(renders) == set(CLI_LABELS), 'old/current CLI render matrix is incomplete')
    render_checks = []
    render_sources = {label: {} for label in CLI_LABELS}
    render_methods = {label: {} for label in CLI_LABELS}
    for cli_label in CLI_LABELS:
        class_map = {row['class']: row for row in renders[cli_label].get('classes', [])}
        need(set(class_map) == set(CLASSES), f'{cli_label} class render set differs')
        for class_name, class_row in class_map.items():
            formats = class_row.get('formats', {})
            need(set(formats) >= {'json', 'text'}, f'{cli_label}/{class_name} format pair incomplete')
            for fmt in ('json', 'text'):
                expected_argv = [renders[cli_label]['cli_pin']['path'], 'class-source', '--input', doc['zip']['pin']['path'],
                    '--class', class_name, '--policy', 'plain-jar', '--release', '8', '--format', fmt, '--evidence', 'all']
                need(formats[fmt]['command'].get('argv') == expected_argv,
                     f'{cli_label}/{class_name}/{fmt} command arguments differ')
                raw = verify(formats[fmt]['raw_stdout'], outdir)
                raw_command = verify(formats[fmt]['command']['streams']['stdout'], outdir / 'raw')
                verify(formats[fmt]['command']['streams']['stderr'], outdir / 'raw')
                need(raw == raw_command, 'saved render response differs from raw CLI stdout')
                if fmt == 'json' and formats[fmt].get('parsed'):
                    parsed = formats[fmt]['parsed']
                    response_raw = verify(parsed['report'], outdir)
                    need(response_raw == raw, 'saved JSON report differs from raw JSON stdout')
                    response = json.loads(response_raw)
                    source = response.get('text')
                    if isinstance(source, str):
                        render_sources[cli_label][class_name] = source
                        source_raw = verify(parsed['source'], outdir)
                        need(source_raw == source.encode('utf-8'), 'saved source differs from JSON response text')
                        methods = []
                        for method in response.get('methods', []):
                            outcome = method.get('outcome', {})
                            report = outcome.get('report', {})
                            item = method.get('item', {})
                            methods.append({'declaration': method.get('declaration'), 'identity': item.get('identity'),
                                'name': item.get('name'), 'descriptor': item.get('descriptor'),
                                'method_text': method.get('text'), 'outcome_kind': outcome.get('kind'),
                                'report_text': report.get('text'), 'compile_status': report.get('compile_status'),
                                'syntax_status': report.get('syntax_status'), 'concat_facts': report.get('concats'),
                                'report_diagnostics': report.get('diagnostics', [])})
                        facts_raw = verify(parsed['method_facts'], outdir)
                        need(json.loads(facts_raw) == methods, 'method text/concat report facts differ from raw JSON')
                        render_methods[cli_label][class_name] = methods
            pair = formats['text_vs_json']
            render_checks.append({'cli': cli_label, 'class': class_name,
                'json_text_and_direct_text_byte_identical': pair.get('byte_identical'),
                'json_available': pair.get('comparable')})
    whole_class_comparison = []
    for class_name in CLASSES:
        old_text = render_sources['parent_v5'].get(class_name)
        new_text = render_sources['current_final_v2'].get(class_name)
        derived_diff = list(difflib.unified_diff(
            old_text.splitlines(keepends=True) if old_text is not None else [],
            new_text.splitlines(keepends=True) if new_text is not None else [],
            fromfile=f'parent_v5/{class_name}.java', tofile=f'current_final_v2/{class_name}.java'))
        whole_class_comparison.append({'class': class_name,
            'old_available': old_text is not None, 'current_available': new_text is not None,
            'byte_identical': old_text is not None and new_text is not None and old_text == new_text,
            'parent_v5_sha256': sha(old_text.encode()) if old_text is not None else None,
            'current_final_v2_sha256': sha(new_text.encode()) if new_text is not None else None,
            'unified_diff': derived_diff})
    need(doc.get('whole_class_text_comparison') == whole_class_comparison,
         'whole-class text comparisons differ from pinned raw JSON responses')

    # Root and anonymous child method source/report text and concat facts remain observation-only.
    method_changes = doc.get('root_child_method_comparison', [])
    derived_method_changes = []
    for class_name in ('AnonymousSuperArgs', 'AnonymousSuperArgs$1'):
        old_methods = render_methods['parent_v5'].get(class_name, [])
        new_methods = render_methods['current_final_v2'].get(class_name, [])
        def method_key(method):
            identity = method.get('identity')
            need(isinstance(identity, dict) and set(identity) == {'owner', 'name', 'descriptor'},
                 'physical method identity has an unexpected JSON shape')
            need(isinstance(identity['owner'], dict) and isinstance(identity['name'], list) and isinstance(identity['descriptor'], list),
                 'physical method identity has unexpected field types')
            return json.dumps(identity, sort_keys=True, separators=(',', ':'))
        old_map = {method_key(method): method for method in old_methods}
        new_map = {method_key(method): method for method in new_methods}
        for identity in sorted(set(old_map) | set(new_map)):
            before_row, after_row = old_map.get(identity), new_map.get(identity)
            derived_method_changes.append({'class': class_name, 'method_identity': json.loads(identity),
                'old_present': before_row is not None, 'current_present': after_row is not None,
                'method_text_equal': before_row is not None and after_row is not None and before_row.get('method_text') == after_row.get('method_text'),
                'report_text_equal': before_row is not None and after_row is not None and before_row.get('report_text') == after_row.get('report_text'),
                'concat_facts_equal': before_row is not None and after_row is not None and before_row.get('concat_facts') == after_row.get('concat_facts'),
                'parent_v5': before_row, 'current_final_v2': after_row})
    need(method_changes == derived_method_changes,
         'root/child method text and concat report comparison differs from raw JSON')
    method_report = [{'class': row['class'], 'identity': row['method_identity'],
                      'old_present': row['old_present'], 'current_present': row['current_present'],
                      'method_text_equal': row['method_text_equal'], 'report_text_equal': row['report_text_equal'],
                      'concat_facts_equal': row['concat_facts_equal'],
                      'old_method_text': row.get('parent_v5', {}).get('method_text') if row.get('parent_v5') else None,
                      'current_method_text': row.get('current_final_v2', {}).get('method_text') if row.get('current_final_v2') else None,
                      'old_report_text': row.get('parent_v5', {}).get('report_text') if row.get('parent_v5') else None,
                      'current_report_text': row.get('current_final_v2', {}).get('report_text') if row.get('current_final_v2') else None,
                      'old_concat_facts': row.get('parent_v5', {}).get('concat_facts') if row.get('parent_v5') else None,
                      'current_concat_facts': row.get('current_final_v2', {}).get('concat_facts') if row.get('current_final_v2') else None}
                     for row in method_changes]
    method_classes = {row.get('class') for row in method_changes}
    for class_name in ('AnonymousSuperArgs', 'AnonymousSuperArgs$1'):
        if class_name not in method_classes:
            method_report.append({'class': class_name, 'method_identity': None, 'available': False,
                                  'state': 'no-method-report-text-extracted'})

    # The frozen bytecode and the two checked-in Java files establish the fixture oracle independently.
    original_class = {row['jdk']: row for row in doc.get('original_class_runs', [])}
    original_source = {row['jdk']: row for row in doc.get('original_source_lanes', [])}
    need(set(original_class) == set(JDKS) and set(original_source) == set(JDKS), 'original class/source JDK matrix incomplete')
    base_valid = True
    baseline_rows = []
    for leg in JDKS:
        frozen = original_class[leg]
        src = original_source[leg]
        verify_captured_lane(src, outdir, doc['jdk_legs'])
        frozen_ok = frozen['command'].get('exit_code') == 0 and frozen.get('oracle_match') is True
        source_state = lane_state(src)
        source_ok = source_state == 'oracle-match'
        base_valid &= frozen_ok and source_ok
        baseline_rows.append({'jdk': leg, 'frozen_class_state': 'oracle-match' if frozen_ok else 'mismatch-or-failed',
                              'original_source_state': source_state})

    # Preserve compilation failures as failures/no-runtime. A compile failure is never a pass.
    candidate_lanes = {(row['cli'], row['jdk']): row for row in doc.get('candidate_whole_class_lanes', [])}
    need(set(candidate_lanes) == {(cli, jdk) for cli in CLI_LABELS for jdk in JDKS}, 'candidate whole-class lane matrix incomplete')
    for lane in candidate_lanes.values():
        verify_captured_lane(lane, outdir, doc['jdk_legs'])
    candidate_states = {f'{cli}/{jdk}': lane_state(candidate_lanes[(cli, jdk)])
                        for cli in CLI_LABELS for jdk in JDKS}
    candidate_details = {}
    for (cli, jdk), lane in candidate_lanes.items():
        candidate_details[f'{cli}/{jdk}'] = {'state': lane_state(lane),
            'compile_exit_code': lane.get('compile', {}).get('exit_code') if lane.get('compile') else None,
            'run_exit_code': lane.get('run', {}).get('exit_code') if lane.get('run') else None,
            'runtime_stdout': lane.get('stdout') if lane.get('run') else None,
            'runtime_stdout_sha256': lane.get('stdout_sha256') if lane.get('run') else None,
            'oracle_match': lane.get('oracle_match') if lane.get('run') else False}
    side_by_side = {}
    for jdk in JDKS:
        old_state = candidate_states[f'parent_v5/{jdk}']
        current_state = candidate_states[f'current_final_v2/{jdk}']
        if not base_valid:
            relation = 'baseline-invalid-inconclusive'
        elif old_state != 'oracle-match' and current_state == 'oracle-match':
            relation = 'current-improves-observed-runtime'
        elif old_state == 'oracle-match' and current_state != 'oracle-match':
            relation = 'current-regresses-observed-runtime'
        elif old_state == current_state == 'oracle-match':
            relation = 'both-match-oracle'
        elif old_state == current_state:
            relation = 'same-incomplete-or-failing-observation'
        else:
            relation = 'different-nonpassing-observations'
        side_by_side[jdk] = {'parent_v5': old_state, 'current_final_v2': current_state,
                             'relation': relation, 'baseline_oracle_valid': base_valid}
    jadx_lanes = {row['jdk']: row for row in doc.get('jadx', {}).get('lanes', [])}
    need(set(jadx_lanes) == set(JDKS), 'JADX JDK compile/run matrix incomplete')
    for lane in jadx_lanes.values():
        verify_captured_lane(lane, outdir, doc['jdk_legs'])
    jadx_states = {leg: lane_state(jadx_lanes[leg]) for leg in JDKS}

    result = {'schema': 'anonymous-super-args-candidate-comparison-check-v1',
        'status': 'observations_checked', 'execution_sha256': sha(execution.read_bytes()),
        'baseline_oracle_valid': base_valid, 'original_baselines': baseline_rows,
        'parent_v5_vs_current_final_v2': side_by_side, 'candidate_states': candidate_states,
        'candidate_runtime_details': candidate_details,
        'jadx_states': jadx_states, 'render_text_checks': render_checks,
        'whole_class_text_comparison': whole_class_comparison,
        'root_child_method_text_and_concat_facts': method_report,
        'compile_failure_policy': 'compile failure is recorded as compile-failed/no-runtime and never counted as success',
        'target_absent_claim': False, 'toolchain_executed_by_checker': False}
    output = args.out.resolve() if args.out else outdir / 'check.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f'check failed: {type(exc).__name__}: {exc}', file=sys.stderr)
        raise SystemExit(1)
