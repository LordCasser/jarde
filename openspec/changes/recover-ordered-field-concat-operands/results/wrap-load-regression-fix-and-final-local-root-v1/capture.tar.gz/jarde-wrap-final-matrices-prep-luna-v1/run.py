#!/usr/bin/env python3
"""Sequential, raw-capturing runner for the nine final class-matrix steps."""
from __future__ import annotations
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
PREP = Path('/private/tmp/jarde-wrap-final-matrices-prep-luna-v1')
OUT = Path('/private/tmp/jarde-wrap-final-matrices-root-v1')
CURRENT_CLI = Path('/private/tmp/jarde-ordered-field-final-check-root-v10/candidate-cli')
CURRENT_RECEIPT = Path('/private/tmp/jarde-ordered-field-final-check-root-v10/execution.json')
OLD_CLI = Path('/private/tmp/jarde-loop-combined-focused-root-v5/candidate-cli')
OLD_RECEIPT = OLD_CLI.parent / 'execution.json'
PARENT_OUT = Path('/private/tmp/jarde-loop-candidate-comparison-root-v6')
FIELD_OUT = Path('/private/tmp/jarde-ordered-field-concat-comparison-root-v5')
TWR_OUT = Path('/private/tmp/jarde-twr-javac23-differential-root-v4')
ANON_OUT = Path('/private/tmp/jarde-anonymous-super-args-comparison-root-v4')

STEPS = [
    ['python3', '/private/tmp/jarde-loop-candidate-comparison-prep-root-v3/collect.py', str(CURRENT_CLI), str(CURRENT_RECEIPT), str(PARENT_OUT)],
    ['python3', '/private/tmp/jarde-loop-candidate-comparison-prep-root-v3/check.py', str(PARENT_OUT / 'execution.json')],
    ['python3', '/private/tmp/jarde-loop-candidate-runtime-accept-root-v1.py', str(PARENT_OUT / 'execution.json')],
    ['python3', '/private/tmp/jarde-ordered-field-concat-comparison-prep-luna-v5/collect.py', str(CURRENT_CLI), str(CURRENT_RECEIPT), str(FIELD_OUT)],
    ['python3', '/private/tmp/jarde-ordered-field-runtime-accept-root-v2.py', str(FIELD_OUT / 'execution.json')],
    ['python3', str(PREP / 'twr/collect.py'), str(TWR_OUT)],
    ['python3', str(PREP / 'twr/check.py'), str(TWR_OUT / 'execution.json')],
    ['python3', str(PREP / 'anon/collect.py'), str(OLD_CLI), str(OLD_RECEIPT), str(CURRENT_CLI), str(CURRENT_RECEIPT), str(ANON_OUT)],
    ['python3', str(PREP / 'anon/check.py'), str(ANON_OUT / 'execution.json')],
]
FRESH_OUTPUTS = (PARENT_OUT, FIELD_OUT, TWR_OUT, ANON_OUT)

def pin(path: Path) -> dict:
    path = Path(path).resolve(strict=True)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def save(doc: dict) -> None:
    (OUT / 'execution.json').write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def main() -> int:
    if OUT.exists():
        raise SystemExit(f'refusing to overwrite non-fresh orchestrator output: {OUT}')
    if any(path.exists() for path in FRESH_OUTPUTS):
        existing = [str(path) for path in FRESH_OUTPUTS if path.exists()]
        raise SystemExit('refusing to reuse matrix output directories: ' + ', '.join(existing))
    OUT.mkdir(parents=True)
    raw_dir = OUT / 'raw'
    raw_dir.mkdir()
    doc = {
        'schema': 'ordered-field-final-class-matrices-orchestration-v1',
        'status': 'running',
        'runner': pin(Path(__file__)),
        'candidate_cli': pin(CURRENT_CLI),
        'focused_receipt': pin(CURRENT_RECEIPT),
        'old_candidate_cli': pin(OLD_CLI),
        'old_focused_receipt': pin(OLD_RECEIPT),
        'fresh_output_directories': [str(path) for path in FRESH_OUTPUTS],
        'commands': [],
        'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    save(doc)
    for index, argv in enumerate(STEPS, 1):
        script = Path(argv[1])
        row = {'index': index, 'argv': argv, 'script': pin(script), 'status': 'running',
               'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        doc['commands'].append(row)
        save(doc)
        stdout_path = raw_dir / f'{index}.stdout.raw'
        stderr_path = raw_dir / f'{index}.stderr.raw'
        with stdout_path.open('xb') as stdout_file, stderr_path.open('xb') as stderr_file:
            result = subprocess.run(argv, cwd=ROOT, stdout=stdout_file, stderr=stderr_file, check=False)
        row.update({
            'exit_code': result.returncode,
            'status': 'completed' if result.returncode == 0 else 'failed',
            'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'streams': {'stdout': pin(stdout_path), 'stderr': pin(stderr_path)},
        })
        save(doc)
        print(json.dumps({'completed_step': index, 'exit_code': result.returncode}), flush=True)
        if result.returncode:
            doc['status'] = 'failed'
            save(doc)
            return result.returncode
    doc['status'] = 'completed_sequential_collectors_and_checks'
    doc['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save(doc)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
