# Final class-matrix orchestration preparation

Prepared a nine-step sequential orchestrator at `run.py` for the v10 candidate CLI and receipt. The future run records starting CLI/receipt pins, each invoked script pin, command argv, raw stdout/stderr bytes and hashes, and final status in a fresh output directory. Every matrix output directory is checked for freshness before any step starts.

The sequence reuses the parent comparison root-v3 collector/checker and runtime acceptor root-v1 into a fresh loop-candidate root-v6 output; the field root-v5 collector and runtime acceptor root-v2 into a fresh field-comparison root-v5 output; then copied TWR root-v3 collector/root-v4 checker and copied anonymous root-v5 collector/checker into fresh TWR root-v4 and anonymous root-v4 outputs. TWR and anonymous copied current-side CLI/receipt paths now point to `/private/tmp/jarde-ordered-field-final-check-root-v10`; anonymous old-side paths remain at loop-combined-focused root-v5.

`root-final-script-pins.json` pins the orchestrator and its source scripts. `changes.diff` records the two focused path updates and the new orchestrator. All Python files passed AST parsing and static path/step checks. The orchestrator was not run; no CLI, JDK, JADX, or other toolchain was invoked.
