#!/usr/bin/env python3
"""Read-only acceptance of an exact product CI run against a fresh ordered-field workspace receipt."""
from __future__ import annotations
import argparse, gzip, hashlib, importlib.util, json, re, stat, sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
CI_HELPER_PATH = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/verify-conditional-ci-root-v5.py'
CI_HELPER_SHA256 = 'bea37c7d4d37182168a7c1cbbde3ee31c94d61f6bc32667bedbdd02ce7e5b0ca'
CAPTURE_PATH = Path('/private/tmp/jarde-ordered-field-own-ci-prep-luna-v1/capture-own-ci.py')
CAPTURE_SHA256 = '842ce7f7b9ae20c19962b9495fb62c1d8eac2d87ccc05d1c482d4c95818a7bdf'
WORKSPACE_PREP = Path('/private/tmp/jarde-wrap-validation-prep-luna-v1/workspace')
WORKSPACE_RUNNER = WORKSPACE_PREP / 'workspace_runner.py'
WORKSPACE_RUNNER_SHA256 = '557d1decba94c3f0e58fee22c7335de77f3087c9337924824724f0412135c38f'
WORKSPACE_ACCEPTOR = WORKSPACE_PREP / 'accept_workspace.py'
WORKSPACE_ACCEPTOR_SHA256 = '22e09682af9e4443b87fbd10082f16226d5cce2bc2baf6ffaa3508b36aafdca7'
FOCUSED_RUNNER = Path('/private/tmp/jarde-cf11-structured-list-focused-runner-prep-luna-v7/run.py')
FOCUSED_RUNNER_SHA256 = 'c8b1016eaf9506912876fd92e8544d5f78e472401beb99e3fd75b549607956bc'
FOCUSED_RECEIPT_RUNNER = Path('/private/tmp/jarde-loop-focused-runner-root-v1.py')
FOCUSED_RECEIPT_RUNNER_SHA256 = '7209ad1732c097e555c0cda2eba8ffa39ab55bf109616cfaac5f15a1bb749b9f'
WORKSPACE_SCHEMA = 'ordered-field-full-workspace-run-v2'
WORKSPACE_ACCEPTANCE_SCHEMA = 'ordered-field-full-workspace-acceptance-v2'
CAPTURE_SCHEMA = 'ordered-field-own-ci-capture-v1'
BASE_ENV = {'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0',
            'CARGO_PROFILE_TEST_DEBUG':'0','RUST_TEST_THREADS':'1','CARGO_TERM_COLOR':'always'}
FREE_LIMIT, TARGET_LIMIT = 5*1024**3, 1024**3
EXPECTED_JOBS = {'stable / test and specification','MSRV 1.88.0','supply chain','fuzz smoke'}
SUMMARY_RE = re.compile(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;')
OUTCOME_RE = re.compile(r'^test ([^\n]+?) \.\.\. (?:(?!^test ).)*?\b(ok|ignored|FAILED)(?:, [^\n]*)?$', re.M | re.S)
ANSI_RE = re.compile(r'\x1b\[[0-9;]*m')


def need(ok, message):
    if not ok: raise ValueError(message)
def sha(raw: bytes) -> str: return hashlib.sha256(raw).hexdigest()
def sha_file(path: Path) -> str: return sha(path.read_bytes())
def load_json(path: Path): return json.loads(path.read_text(encoding='utf-8'))
def load_module(name: str, path: Path):
    spec=importlib.util.spec_from_file_location(name,path)
    need(spec is not None and spec.loader is not None,'cannot load pinned module: '+str(path))
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def stream_bytes(ref: dict, evidence_root: Path) -> bytes:
    path=Path(ref.get('path',''))
    if not path.is_absolute(): path=evidence_root/path
    need(not path.is_symlink(),'raw stream is a symlink: '+str(path))
    path=path.resolve(strict=True)
    need(path.is_relative_to(evidence_root.resolve(strict=True)),'raw stream escapes its receipt directory: '+str(path))
    raw=path.read_bytes()
    need(len(raw)==ref.get('bytes') and sha(raw)==ref.get('sha256'),'raw stream pin mismatch: '+str(path))
    return raw

def source_manifest_pins(rows: list[dict]) -> dict[str,str]:
    need(isinstance(rows,list) and rows,'source manifest is absent')
    result={}
    for row in rows:
        need(isinstance(row,dict) and isinstance(row.get('path'),str) and
             re.fullmatch(r'[0-9a-f]{64}',row.get('sha256','')),'malformed source manifest row')
        path=Path(row['path'])
        if path.is_absolute():
            need(path.resolve().is_relative_to(ROOT),'focused source path escapes product root')
            key=path.resolve().relative_to(ROOT).as_posix()
        else: key=path.as_posix()
        relative=Path(key)
        need(not relative.is_absolute() and '..' not in relative.parts,'source manifest path escapes product root')
        need(type(row.get('bytes')) is int and row['bytes']>=0,'source manifest byte length is missing')
        need(key not in result,'duplicate path in source manifest')
        live=ROOT/relative
        need(live.is_file() and not live.is_symlink() and live.stat().st_size==row['bytes'] and sha_file(live)==row['sha256'],
                 'focused source row no longer matches live bytes: '+key)
        result[key]=row['sha256']
    return result

def check_command(row: dict, index: int, argv: list[str], env_expected: dict[str,str], evidence_root: Path,
                  *, cleanup_only=False):
    need(row.get('index')==index and row.get('argv')==argv and row.get('cwd')==str(ROOT),
         f'command {index} index/argv/cwd differs')
    need(row.get('exit_code')==0 and row.get('guard_stop') is None,f'command {index} failed or hit guard')
    need(row.get('env_overrides')==env_expected,f'command {index} environment differs')
    need(set(row.get('streams',{}))=={'stdout','stderr'},f'command {index} lacks raw streams')
    for ref in row['streams'].values(): stream_bytes(ref,evidence_root)
    if cleanup_only:
        proof=row.get('cleanup_only',{})
        need(argv==['cargo','clean'] and proof.get('exact_argv')==argv and
             proof.get('space_precheck_bypassed') is True and proof.get('space_monitor_abort_bypassed') is True and
             all(type(proof.get(side,{}).get(key)) is int and proof[side][key]>=0
                 for side in ('observed_before','observed_after') for key in ('target_bytes','free_bytes')) and
             row.get('free_bytes_after')==proof.get('observed_after',{}).get('free_bytes') and
             type(row.get('peak_target_bytes')) is int and
             row['peak_target_bytes']>=max(proof.get('observed_before',{}).get('target_bytes',0),
                                           proof.get('observed_after',{}).get('target_bytes',0)),
             'cleanup bypass is not scoped to exact cargo clean observations')
    else:
        need(row.get('cleanup_only') is None and type(row.get('peak_target_bytes')) is int and
             row['peak_target_bytes']<=TARGET_LIMIT and type(row.get('free_bytes_after')) is int and
             row['free_bytes_after']>=FREE_LIMIT,'command exceeded or omitted resource guard')

def parse_test_stream(raw: bytes):
    text=ANSI_RE.sub('',raw.decode('utf-8',errors='replace'))
    summaries=[(status,int(passed),int(failed),int(ignored)) for status,passed,failed,ignored in SUMMARY_RE.findall(text)]
    outcomes=[(name,status) for name,status in OUTCOME_RE.findall(text)]
    return summaries,outcomes

def load_ci():
    need(CI_HELPER_PATH.is_file() and sha_file(CI_HELPER_PATH)==CI_HELPER_SHA256,'pinned CI parser changed')
    return load_module('ordered_field_ci_parser',CI_HELPER_PATH)

def workflow_bytes(product: str, ci, pins: dict[str,str]) -> bytes:
    rel='.github/workflows/ci.yml'; raw=ci.git_blob(product,rel)
    need(sha(raw)==pins.get(rel)==sha_file(ROOT/rel),'selected workflow differs from live/product source closure')
    return raw

def workflow_clippy_argv(product: str, ci, pins: dict[str,str]) -> list[str]:
    text=workflow_bytes(product,ci,pins).decode('utf-8')
    start=text.index('          cargo clippy'); end=text.index('\n\n',start)
    return text[start:end].split()

def verify_capture(capture_dir: Path, product: str, run_id: str, ci):
    need(not capture_dir.is_symlink(),'capture directory is linked')
    capture_dir=capture_dir.resolve(strict=True); receipt=capture_dir/'capture-execution-root-v2.json'
    need(not receipt.is_symlink(),'capture receipt is linked')
    doc=load_json(receipt)
    need(doc.get('schema')==CAPTURE_SCHEMA and doc.get('status')=='captured','capture is incomplete or wrong schema')
    need(doc.get('product_commit')==product and doc.get('run_id')==int(run_id),'capture commit/run differs')
    collector=doc.get('collector',{}); cp=Path(collector.get('path',''))
    need(cp.resolve()==CAPTURE_PATH.resolve() and cp.is_file() and
         sha_file(cp)==CAPTURE_SHA256==collector.get('sha256'),
         'capture collector path/hash differs from prepared adapter')
    summary=doc.get('validated_run_summary',{})
    need(summary.get('headSha')==product and summary.get('status')=='completed' and summary.get('conclusion')=='success',
         'CI summary head/status/conclusion differs')
    match=re.search(r'/actions/runs/(\d+)(?:$|[/?#])',summary.get('url',''))
    need(match and int(match.group(1))==int(run_id),'CI URL does not identify requested run')
    jobs=summary.get('jobs',[])
    need(len(jobs)==4 and {j.get('name') for j in jobs}==EXPECTED_JOBS,'CI job inventory differs from four expected jobs')
    need(all(j.get('status')=='completed' and j.get('conclusion')=='success' and j.get('steps') and
             all(s.get('status')=='completed' and s.get('conclusion')=='success' for s in j['steps']) for j in jobs),
         'some CI job or step did not complete successfully')
    steps=sum(len(j['steps']) for j in jobs)
    need(doc.get('jobs')==4 and doc.get('steps')==steps,'capture job/step totals differ from API summary')
    commands=doc.get('commands',[]); need(len(commands)==3,'capture lacks exact summary/stable/supply commands')
    ids={j['name']:str(j['databaseId']) for j in jobs}
    expected=[['gh','run','view',str(run_id),'--json','headSha,status,conclusion,jobs,url'],
      ['gh','run','view',str(run_id),'--job',ids['stable / test and specification'],'--log'],
      ['gh','run','view',str(run_id),'--job',ids['supply chain'],'--log']]
    raw_logs=[]
    for i,(row,argv) in enumerate(zip(commands,expected)):
        need(row.get('argv')==argv and row.get('cwd')==str(ROOT) and row.get('exit_code')==0 and
             not row.get('timed_out') and row.get('spawn_error') is None,f'capture command {i} failed or differs')
        env=row.get('environment_override',{})
        need(set(env)=={'NO_PROXY','no_proxy'} and all(item.get('appended')==[
             'results-receiver.actions.githubusercontent.com','productionresultssa1.blob.core.windows.net'] and
             re.fullmatch(r'[0-9a-f]{64}',item.get('final_value_sha256','')) for item in env.values()),
             'capture proxy environment record is malformed')
        out=stream_bytes(row['stdout'],capture_dir); stream_bytes(row['stderr'],capture_dir)
        if i==0: need(json.loads(out)==summary,'captured summary stdout differs from API summary')
        else:
            filename='ci-stable-job-v2.log.gz' if i==1 else 'ci-supply-job-v2.log.gz'
            packed=(capture_dir/filename).read_bytes(); ref=row['stdout']
            need(len(packed)==ref.get('bytes') and sha(packed)==ref.get('sha256'),'compressed log pin differs')
            decoded=gzip.decompress(packed)
            need(len(decoded)==ref.get('uncompressed_bytes') and sha(decoded)==ref.get('raw_sha256') and
                 gzip.compress(decoded,mtime=0)==packed,'compressed log does not reproduce pinned raw bytes')
            raw_ref=row.get('stdout_raw',{}); raw_path=capture_dir/raw_ref.get('path','')
            need(not raw_path.is_symlink() and raw_path.resolve().parent==capture_dir and raw_path.read_bytes()==decoded and
                 raw_ref.get('bytes')==len(decoded) and raw_ref.get('sha256')==sha(decoded),'raw CI log pin differs')
            raw_logs.append(decoded)
    return doc,summary,steps,raw_logs,sha_file(receipt)

def verify_focus(path: Path, focus_sha: str, cli_path: Path, cli_sha: str, product: str, ci, pins, runner):
    raw=path.read_bytes(); need(sha(raw)==focus_sha,'focused receipt SHA differs'); focus=json.loads(raw)
    need(focus.get('status')=='commands_passed_pending_independent_acceptance','focused check is not complete/passing')
    root_runner=focus.get('runner',{})
    need(root_runner.get('path')==str(FOCUSED_RECEIPT_RUNNER) and root_runner.get('sha256')==FOCUSED_RECEIPT_RUNNER_SHA256 and
         FOCUSED_RECEIPT_RUNNER.is_file() and sha_file(FOCUSED_RECEIPT_RUNNER)==FOCUSED_RECEIPT_RUNNER_SHA256,
         'focused receipt runner path/hash differs from the reviewed root runner')
    before=source_manifest_pins(focus.get('source_manifest_before',[])); after=source_manifest_pins(focus.get('source_manifest_after',[]))
    need(before==after,'focused source closure changed')
    spec=focus.get('command_spec',{}); spec_path=Path(spec.get('path',''))
    need(spec_path.is_file() and not spec_path.is_symlink(),'focused command spec is missing or linked')
    spec_raw=spec_path.read_bytes()
    need(len(spec_raw)==spec.get('bytes') and sha(spec_raw)==spec.get('sha256'),'focused command spec pin differs')
    expected=json.loads(spec_raw); need(isinstance(expected,list) and len(expected)==7 and all(isinstance(x,list) for x in expected),
         'focused command spec is not seven ordered commands')
    need(expected[0]==['cargo','fmt','--all','--','--check'] and expected[1]==workflow_clippy_argv(product,ci,pins) and
         expected[-1]==['openspec','validate','--all','--strict','--no-interactive'],
         'focused fmt/clippy/strict OpenSpec argv differs from required exact commands')
    need(sum(1 for x in expected if x==['cargo','build','-p','jarde-cli','--locked'])==1 and
         sum(1 for x in expected if x[:2]==['cargo','test'])>=1,
         'focused command spec lacks one CLI build or test gates')
    need(expected[4]==['cargo','clean','-p','jarde','-p','jarde-java'] and
         expected[5]==['cargo','build','-p','jarde-cli','--locked'] and
         not any(argv[:2]==['cargo','test'] for argv in expected[4:]),
         'focused tests/package-clean/CLI-build order differs')
    rows=focus.get('commands',[]); need(len(rows)==8,'focused receipt must contain seven gates plus cleanup')
    root=path.parent.resolve(strict=True); all_names=[]
    for i,(row,argv) in enumerate(zip(rows[:-1],expected),1):
        need(row.get('index')==i and row.get('argv')==argv and row.get('cwd')==str(ROOT) and
             row.get('exit_code')==0 and row.get('guard_stop') is None,
             f'focused command {i} failed or differs from its command spec')
        need(row.get('cleanup_only') is None and type(row.get('peak_target_bytes')) is int and
             row['peak_target_bytes']<=TARGET_LIMIT and type(row.get('free_bytes_after')) is int and
             row['free_bytes_after']>=FREE_LIMIT and row.get('env_overrides')==BASE_ENV,
             f'focused command {i} guard/environment differs')
        need(set(row.get('streams',{}))=={'stdout','stderr'},'focused command lacks raw streams')
        for ref in row['streams'].values(): stream_bytes(ref,root)
        if argv[:2]==['cargo','test']:
            stdout=stream_bytes(row['streams']['stdout'],root); summaries,outcomes=parse_test_stream(stdout)
            need(summaries and all(state=='ok' and failed==0 for state,_,failed,_ in summaries),
                 f'focused test command {i} has a failed summary')
            need(sum(passed+failed+ignored for _,passed,failed,ignored in summaries)==len(outcomes),
                 f'focused test command {i} named outcomes do not match summary totals')
            stored=[tuple(x) for x in row.get('actual_test_summaries',[])]
            need(stored==[(a,str(b),str(c),str(d)) for a,b,c,d in summaries],
                 f'focused test command {i} summary record differs from raw output')
            all_names.extend(outcomes)
    clean=rows[-1]
    need(clean.get('index')==8 and clean.get('argv')==['cargo','clean'] and clean.get('exit_code')==0 and
         clean.get('cleanup_only') is True,'focused final cleanup is not successful exact cargo clean')
    need(set(clean.get('streams',{}))=={'stdout','stderr'},'focused cleanup lacks raw stdout/stderr')
    for ref in clean.get('streams',{}).values(): stream_bytes(ref,root)
    need(focus.get('target_absent') is True and focus.get('default_stack') is True,'focused cleanup/default stack postcondition differs')
    freeze=focus.get('cli',{}); cli_path=cli_path.resolve(strict=True)
    need(not cli_path.is_symlink() and cli_path==Path(freeze.get('path','')).resolve(strict=True) and
         cli_path.stat().st_size==freeze.get('bytes') and sha_file(cli_path)==freeze.get('sha256')==cli_sha and
         stat.S_IMODE(cli_path.stat().st_mode)==0o555,
         'CLI argv pin does not match the focused frozen executable')
    focused_expected=getattr(runner,'FOCUSED_EXPECTED_OUTCOMES',{})
    need(isinstance(focused_expected,dict) and focused_expected,'workspace runner has no focused named-outcome contract')
    for name,status in focused_expected.items():
        hits=[(actual,state) for actual,state in all_names if actual==name or actual.endswith('::'+name)]
        need(len(hits)==1 and hits[0][1]==status,f'focused named result differs or is not unique: {name}')
    return focus,{'path':str(path.resolve()),'sha256':focus_sha},before,{'path':str(cli_path),'bytes':cli_path.stat().st_size,
      'sha256':cli_sha,'mode':oct(stat.S_IMODE(cli_path.stat().st_mode))}

def verify_workspace(path: Path, workspace_sha: str, acceptance_path: Path, acceptance_sha: str,
                     focus: dict, focus_info: dict, focus_pins: dict[str,str], cli_pin: dict, runner_path: Path, ci, seeds):
    path=path.resolve(strict=True); ex_path=path/'execution.json'; meta_path=path/'metadata.json'
    raw=ex_path.read_bytes(); need(sha(raw)==workspace_sha,'workspace receipt SHA differs'); ex=json.loads(raw)
    need(ex.get('schema')==WORKSPACE_SCHEMA and ex.get('status')=='passed' and ex.get('no_carried_execution') is True,
         'fresh workspace receipt is not complete/passing')
    need(ex.get('rust_min_stack') is None and ex.get('seeds')==list(seeds) and
         ex.get('guard_limits')=={'minimum_free_bytes':FREE_LIMIT,'maximum_target_bytes':TARGET_LIMIT,'poll_interval_seconds':1},
         'workspace seeds/default stack/guard limits differ')
    source_before=ex.get('source_pins_before'); source_after=ex.get('source_pins_after')
    need(isinstance(source_before,dict) and source_before==source_after,'workspace source closure changed')
    runner=load_module('ordered_field_workspace_runner',runner_path)
    live=runner.pin_sources(runner.source_paths())
    need(live==source_before==focus_pins,'focused/workspace/live source closure differs')
    need(ex.get('source_closure_count_at_start')==len(live),'workspace source count differs from dynamic closure')
    spec_sha=focus.get('command_spec',{}).get('sha256')
    bound=ex.get('focused_input_receipt',{})
    need(bound.get('path')==focus_info['path'] and bound.get('sha256')==focus_info['sha256'] and
         bound.get('status')==focus.get('status') and bound.get('command_spec_sha256')==spec_sha,
         'workspace receipt is not bound to this focused receipt')
    cli=ex.get('candidate_cli',{})
    need({k:cli.get(k) for k in ('path','bytes','sha256')}=={k:cli_pin[k] for k in ('path','bytes','sha256')},
         'workspace CLI does not match the focused frozen CLI argv pin')
    acceptance_path=acceptance_path.resolve(strict=True); accepted_raw=acceptance_path.read_bytes()
    need(sha(accepted_raw)==acceptance_sha,'workspace acceptance SHA differs'); accepted=json.loads(accepted_raw)
    need(accepted.get('schema')==WORKSPACE_ACCEPTANCE_SCHEMA and accepted.get('status')=='accepted_local_workspace_only' and
         accepted.get('not_ci_or_product_release_acceptance') is True and accepted.get('execution_sha256')==workspace_sha and
         accepted.get('focused_receipt_sha256')==focus_info['sha256'] and accepted.get('source_pin_count')==len(live) and
         accepted.get('target_absent') is True and accepted.get('target_count')==ex.get('expected_target_count') and
         accepted.get('batch_count_per_seed')==ex.get('expected_batch_count') and accepted.get('seeds')==list(seeds),
         'workspace independent acceptance does not bind this run/closure')
    metadata_raw=meta_path.read_bytes(); metadata=json.loads(metadata_raw); planned,inventory=runner.expected_workspace_commands(metadata)
    by_id,by_named,meta_inventory=ci.metadata_targets(metadata); batches=len(planned)
    need(set(inventory)==set(meta_inventory)==set(tuple(x) for x in ex.get('target_inventory',[])) and
         len(meta_inventory)==ex.get('expected_target_count')==ex.get('metadata',{}).get('target_count') and
         ex.get('metadata',{}).get('batch_count')==batches and
         len(ex.get('static_manifest_target_inventory',[]))==len(meta_inventory) and
         set(tuple(x) for x in ex['static_manifest_target_inventory'])==set(meta_inventory),
         'Cargo metadata target inventory differs from exact workspace plan')
    commands=ex.get('commands',[]); need(len(commands)==2+2*batches+1 and
         ex.get('expected_command_count_including_clean')==len(commands)==ex.get('observed_command_count_including_clean'),
         'workspace command count differs from two metadata-derived sweeps')
    need(commands[0].get('argv')==['cargo','fmt','--all','--','--check'] and
         commands[1].get('argv')==['cargo','metadata','--no-deps','--format-version','1','--locked'],
         'workspace fmt/metadata preflight order differs')
    env_base={**BASE_ENV,'PROPTEST_RNG_SEED':seeds[0],'CARGO_PROFILE_TEST_STRIP':'symbols'}
    need(stream_bytes(commands[1]['streams']['stdout'],path)==metadata_raw,'workspace metadata differs from raw command stdout')
    observations={seed:[] for seed in seeds}; seen={seed:set() for seed in seeds}; all_raw=set()
    for index,row in enumerate(commands[:-1]):
        for ref in row.get('streams',{}).values(): all_raw.add(Path(ref['path']).resolve())
        if index==0: check_command(row,index,['cargo','fmt','--all','--','--check'],env_base,path); continue
        if index==1: check_command(row,index,['cargo','metadata','--no-deps','--format-version','1','--locked'],env_base,path); continue
        offset=index-2; seed=seeds[offset//batches]; batch=offset%batches
        need(row.get('proptest_seed')==seed and row.get('argv')==planned[batch],f'workspace batch {index} order/seed differs')
        env={**BASE_ENV,'PROPTEST_RNG_SEED':seed,'CARGO_PROFILE_TEST_STRIP':'symbols'}
        check_command(row,index,planned[batch],env,path)
        observed=ci.local_command_observation(row,by_id,by_named); ci.check_workspace_argv(row.get('argv',[]),observed,by_named)
        for suite in observed:
            suite['outcomes']=[(name,'ignored' if state.startswith('ignored') else state) for name,state in suite['outcomes']]
        need(len(observed)==len(row.get('executed_targets',[]))==len(row.get('observed_summaries',[])),
             f'workspace batch {index} target summaries differ')
        actual=[(n,s) for suite in observed for n,s in suite['outcomes']]
        stored=[(x.get('name'),x.get('status')) for x in row.get('named_test_outcomes',[])]
        need(actual==stored and row.get('named_test_outcome_count')==len(actual),f'workspace batch {index} named outcomes differ from raw stdout')
        sums=[('ok' if x['counts'][1]==0 else 'FAILED',*x['counts']) for x in observed]
        stored_sums=[(x.get('status'),x.get('passed'),x.get('failed'),x.get('ignored')) for x in row.get('observed_summaries',[])]
        need(sums==stored_sums,f'workspace batch {index} summary counts differ from raw stdout')
        for suite in observed:
            key=suite['key']; need(key not in seen[seed],'workspace target repeated in seed')
            seen[seed].add(key); observations[seed].append(suite)
    totals_by_seed={s:[sum(x['counts'][i] for x in observations[s]) for i in range(3)] for s in seeds}
    for seed in seeds: need(seen[seed]==set(meta_inventory),'workspace target inventory incomplete for '+seed)
    totals=[sum(totals_by_seed[s][i] for s in seeds) for i in range(3)]
    count=sum(len(observations[s]) for s in seeds)
    need(ex.get('format_check')=={'exit_code':0,'guard_stop':None},'workspace format check did not pass')
    need(ex.get('workspace_totals')==totals and ex.get('workspace_summary_count')==count,'workspace totals differ from raw target summaries')
    need(accepted.get('test_totals')=={'passed':totals[0],'failed':totals[1],'ignored':totals[2],
         'target_summary_count':count,'named_test_outcome_count':sum(len(x['outcomes']) for s in seeds for x in observations[s])},
         'acceptance totals differ from raw workspace observations')
    clean_index=len(commands)-1; clean=commands[clean_index]
    env={**BASE_ENV,'PROPTEST_RNG_SEED':seeds[-1],'CARGO_PROFILE_TEST_STRIP':'symbols'}
    check_command(clean,clean_index,['cargo','clean'],env,path,cleanup_only=True)
    for ref in clean.get('streams',{}).values(): all_raw.add(Path(ref['path']).resolve())
    raw_files={p.resolve() for p in path.glob('*.raw') if p.is_file()}
    need(raw_files==all_raw and len(all_raw)==len(commands)*2,'workspace raw stream inventory is incomplete')
    cleanup=ex.get('cleanup',{})
    need(cleanup.get('status')=='passed' and cleanup.get('target_absent_after') is True and cleanup.get('pins_unchanged') is True and cleanup.get('command')==clean and not (ROOT/'target').exists(),
         'workspace finally-clean postcondition differs')
    need(ex.get('runner',{}).get('sha256_before')==ex.get('runner',{}).get('sha256_after')==sha_file(runner_path),
         'workspace runner changed during recorded run')
    required=set(runner.REQUIRED_NAMED_TESTS)
    required_outcomes={}
    for seed in seeds:
        matches=[]
        for name in sorted(required):
            found=[state for suite in observations[seed] for actual,state in suite['outcomes'] if actual==name or actual.endswith('::'+name)]
            need(len(found)==1 and found[0]=='ok',f'required local named test not exactly once passing for {seed}: {name}')
            matches.append(name)
        required_outcomes[seed]=matches
    local_info={'execution':str(ex_path),'execution_sha256':workspace_sha,'metadata':str(meta_path),'metadata_sha256':sha(metadata_raw),
       'seed_target_counts':{s:len(observations[s]) for s in seeds},'target_count':len(inventory),'batch_count_per_seed':batches,
       'source_pin_count':len(live),'workspace_totals_by_seed':totals_by_seed,'workspace_totals':totals,
       'workspace_summary_count':count,'workspace_acceptance':str(acceptance_path),'workspace_acceptance_sha256':acceptance_sha}
    return ex,metadata,observations,live,local_info,required_outcomes

def bind_ci_name(raw_name: str, status: str, target: dict) -> str:
    if '***' not in raw_name: return raw_name
    pattern='^'+'[^\n]*'.join(re.escape(part) for part in raw_name.split('***'))+'$'
    choices=[name for name,state in target['outcomes'] if state==status and re.fullmatch(pattern,name)]
    need(len(choices)==1,'masked CI label does not bind to one same-status local outcome: '+repr(raw_name))
    return choices[0]

def verify_product_ci(capture: Path, product: str, run_id: str, observations: dict, product_pins: dict, ci, seeds):
    doc,summary,steps,logs,capture_sha=verify_capture(capture,product,run_id,ci)
    workflow=workflow_bytes(product,ci,product_pins).decode('utf-8')
    need(tuple(ci.CI_SEEDS_RE.findall(workflow))==tuple(seeds) and workflow.count('run: '+ci.WORKSPACE_CMD)==2,
         'product workflow does not contain the same two workspace seed runs')
    groups=ci.command_groups(ci.strip_log(logs[0]).splitlines(),ci.WORKSPACE_CMD)
    need(len(groups)==2,'CI stable log does not contain exactly two workspace runs')
    unused=list(groups); seed_runs=[]
    for seed in seeds:
        targets=observations[seed]; matches=[g for g in unused if seed in g]
        need(len(matches)==1,'cannot bind exactly one CI group to seed '+seed)
        group=matches[0]; unused.remove(group)
        headers=[]
        for line in group.splitlines():
            if 'Running ' in ci.clean(line):
                row=ci.parse_ci_header(line,targets)
                if row is not None: headers.append(row)
        blocks=ci.stdout_blocks_cargo_json(group.encode())
        need(len(headers)==len(blocks)==len(targets),'CI seed lacks one target header/result per local target')
        need({tuple(x['key']) for x in headers}=={tuple(x['key']) for x in targets} and len({tuple(x['key']) for x in headers})==len(headers),
             'CI seed target headers omit/duplicate/add a workspace target')
        local={tuple(x['key']):x for x in targets}; observed=[]
        for header,block in zip(headers,blocks):
            expected=local[tuple(header['key'])]; bound=[]
            for name,state in block['outcomes']:
                normalized='ignored' if state=='ignored' or state.startswith('ignored, ') else state
                actual=bind_ci_name(name,normalized,expected)
                bound.append((actual,normalized))
            need(block['counts']==expected['counts'] and tuple(bound)==tuple(expected['outcomes']),
                 'CI target counts/named outcomes differ from local same-seed target '+repr(expected['key']))
            observed.append({'key':list(expected['key']),'counts':list(block['counts']),
                             'outcomes':[{'name':n,'status':s} for n,s in bound]})
        totals=[sum(x['counts'][i] for x in observed) for i in range(3)]
        seed_runs.append({'seed':seed,'target_count':len(observed),'workspace_totals':totals,'target_observations':observed})
    need(not unused,'unbound CI seed groups remain')
    return {'capture_sha256':capture_sha,'jobs':len(summary['jobs']),'steps':steps,'seed_runs':seed_runs}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for flag in ('product-commit','run-id','capture','focused-receipt','focused-receipt-sha256','candidate-cli',
                 'candidate-cli-sha256','workspace','workspace-receipt-sha256','workspace-acceptance',
                 'workspace-acceptance-sha256','out'):
        ap.add_argument('--'+flag,type=Path if flag in ('capture','focused-receipt','candidate-cli','workspace','workspace-acceptance','out') else str,required=True)
    ap.add_argument('--workspace-runner',type=Path,default=WORKSPACE_RUNNER)
    args=ap.parse_args()
    need(re.fullmatch(r'[0-9a-f]{40}',args.product_commit) is not None and args.run_id.isdecimal(),'product commit/run ID invalid')
    for value in (args.focused_receipt_sha256,args.candidate_cli_sha256,args.workspace_receipt_sha256,args.workspace_acceptance_sha256):
        need(re.fullmatch(r'[0-9a-f]{64}',value) is not None,'SHA argument must be lowercase 64-hex')
    args.workspace=args.workspace.resolve(strict=True)
    focus_path=args.focused_receipt.resolve(strict=True)
    need(not focus_path.is_symlink() and sha_file(focus_path)==args.focused_receipt_sha256,'focused receipt path/hash differs')
    cli_path=args.candidate_cli.resolve(strict=True)
    need(not cli_path.is_symlink() and sha_file(cli_path)==args.candidate_cli_sha256,'CLI path/hash differs')
    runner_path=args.workspace_runner.resolve(strict=True)
    need(runner_path==WORKSPACE_RUNNER.resolve() and sha_file(runner_path)==WORKSPACE_RUNNER_SHA256,
         'ordered-field workspace runner path/hash differs from reviewed v2')
    need(WORKSPACE_ACCEPTOR.is_file() and sha_file(WORKSPACE_ACCEPTOR)==WORKSPACE_ACCEPTOR_SHA256,
         'ordered-field workspace acceptor source pin differs')
    ci=load_ci(); runner=load_module('ordered_field_workspace_runner',runner_path)
    # The source closure is taken from the focused receipt and independently recomputed by the workspace runner.
    focus_manifest=load_json(focus_path).get('source_manifest_before',[])
    focus_pins=source_manifest_pins(focus_manifest)
    product_pins=runner.pin_sources(runner.source_paths())
    need(product_pins==focus_pins,'focused and current live source closures differ')
    product_blobs=ci.blob_sha256s(args.product_commit,product_pins)
    need(product_blobs==product_pins,'selected product commit differs from the complete focused/workspace/live source closure')
    workflow=workflow_bytes(args.product_commit,ci,product_pins).decode('utf-8')
    seeds=tuple(ci.CI_SEEDS_RE.findall(workflow))
    need(len(seeds)==2 and len(set(seeds))==2 and workflow.count('run: '+ci.WORKSPACE_CMD)==2,
         'product workflow does not contain exactly two distinct workspace seed runs')
    focus,focus_info,focus_pins,cli_pin=verify_focus(focus_path,args.focused_receipt_sha256,cli_path,
        args.candidate_cli_sha256,args.product_commit,ci,product_pins,runner)
    workspace,metadata,observations,workspace_pins,local_info,required=verify_workspace(
        args.workspace,args.workspace_receipt_sha256,args.workspace_acceptance,args.workspace_acceptance_sha256,
        focus,focus_info,focus_pins,cli_pin,runner_path,ci,seeds)
    need(workspace_pins==product_pins,'workspace/current product source closures differ')
    ci_result=verify_product_ci(args.capture.resolve(strict=True),args.product_commit,args.run_id,
        observations,product_pins,ci,seeds)
    refs={'focused_receipt_runner':{'path':str(FOCUSED_RECEIPT_RUNNER),'sha256':FOCUSED_RECEIPT_RUNNER_SHA256},
          'ci_parser':{'path':str(CI_HELPER_PATH),'sha256':CI_HELPER_SHA256},
          'capture_collector':{'path':str(CAPTURE_PATH),'sha256':sha_file(CAPTURE_PATH)},
          'workspace_runner':{'path':str(runner_path),'sha256':WORKSPACE_RUNNER_SHA256},
          'workspace_acceptor':{'path':str(WORKSPACE_ACCEPTOR),'sha256':WORKSPACE_ACCEPTOR_SHA256},
          'focused_source_manifest_runner':{'path':str(FOCUSED_RUNNER),'sha256':FOCUSED_RUNNER_SHA256}}
    need(FOCUSED_RUNNER.is_file() and sha_file(FOCUSED_RUNNER)==FOCUSED_RUNNER_SHA256,
         'pinned focused source-manifest runner changed')
    for path,want in ((CI_HELPER_PATH,CI_HELPER_SHA256),):
        need(path.is_file() and sha_file(path)==want,'repository CI helper changed')
        rel=path.relative_to(ROOT).as_posix()
        need(product_pins.get(rel)==want and sha(ci.git_blob(args.product_commit,rel))==want,
             'CI parser source is outside the exact product/live closure')
    result={'schema':'ordered-field-own-ci-acceptance-v1','status':'accepted_local_own_ci_observation',
      'product_commit':args.product_commit,'run_id':int(args.run_id),
      'ci':{'capture_sha256':ci_result['capture_sha256'],'jobs':ci_result['jobs'],'steps':ci_result['steps'],
            'all_jobs_and_steps_succeeded':True,'seed_runs':ci_result['seed_runs']},
      'fresh_local_workspace':local_info,'required_named_tests_per_seed':required,
      'focused_receipt':focus_info,'candidate_cli':cli_pin,
      'source_closure':{'count':len(product_pins),'focused_workspace_product_git_live_equal':True},
      'references':refs,
      'acceptance_scope':'Exact argv-selected product commit and CI run. All four jobs and every observed step succeeded; each product CI seed is compared target-by-target and test-by-test with the corresponding fresh local workspace seed. The dynamically enumerated full source closure is equal across focused receipt, workspace receipt, product Git and live files; the focused Clippy argv is read from that product commit workflow; the frozen CLI is pinned by path, size and SHA.'}
    out=args.out.resolve()
    need(not out.exists() and not out.is_relative_to(ROOT),'refusing overwrite or workspace-local acceptance output')
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('x',encoding='utf-8') as f:f.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'product_commit':args.product_commit,'run_id':int(args.run_id),
      'jobs':ci_result['jobs'],'steps':ci_result['steps'],'target_count':local_info['target_count'],
      'batch_count_per_seed':local_info['batch_count_per_seed'],'source_closure_count':len(product_pins),
      'workspace_totals_by_seed':local_info['workspace_totals_by_seed']},ensure_ascii=False))

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print('Ordered-field own-CI verification failed: '+str(exc),file=sys.stderr)
        raise SystemExit(1)
