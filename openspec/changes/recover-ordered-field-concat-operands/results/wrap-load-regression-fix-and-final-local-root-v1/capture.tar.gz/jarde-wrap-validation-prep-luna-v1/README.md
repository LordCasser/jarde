# Wrap validation preparation

Prepared private, unexecuted validation tools for the throwable-wrap integration case. No build, test, JDK/JADX, CLI, or Git commands were run.

`focused-commands-v10.json` retains the seven normal commands and adds `--test p3_throwable_wrap_arguments` to the existing combined Cargo test command. `accept-focused.py` requires `wrap_family_recovers_every_variant_with_the_required_spelling` in the integration-test required list while retaining the prior gate. The receipts remain eight command records including cleanup and two Cargo test commands.

The copied workspace runner retains its original 14-entry focused exact-outcome map and adds the wrap case separately to `REQUIRED_NAMED_TESTS`. The independent workspace acceptor checks that the named wrap outcome appears exactly once and passes in `jarde/p3_throwable_wrap_arguments` for each seed. The copied own-CI verifier points to the copied workspace tools and refreshed SHA pins; its required-test validation reads the runner map for both seeds. The 195-command, 96-batch, and 364-target inventory rules were left unchanged.

`root-final-script-pins.json` records SHA-256/byte pins for outputs plus source origins. `changes.diff` shows each change against its source. Python AST parsing and static structure checks passed; no runtime validation was performed.
