package defpackage;

/* JADX INFO: loaded from: OrderedFieldConcat.class */
public final class OrderedFieldConcat {
    public int value;
    public volatile int volatileValue;
    public int later;
    public Object payload;
    public int toStringCalls;
    public String textResult = "object";
    public String events = "";

    public OrderedFieldConcat(int value, int volatileValue, int later) {
        this.value = value;
        this.volatileValue = volatileValue;
        this.later = later;
    }

    private void event(String value) {
        if (!this.events.isEmpty()) {
            this.events += ",";
        }
        this.events += value;
    }

    public static String instanceFields(OrderedFieldConcat receiver) {
        return "value=" + receiver.value + ";volatile=" + receiver.volatileValue;
    }

    public static String plainPlusObjectBeforeLaterField(OrderedFieldConcat receiver) {
        return "object=" + receiver + ";later=" + receiver.later;
    }

    public static String explicitValueOfBeforeLaterField(OrderedFieldConcat receiver) {
        return "object=" + String.valueOf(receiver) + ";later=" + receiver.later;
    }

    public static String objectFieldBeforeLaterField(OrderedFieldConcat receiver) {
        return "object=" + receiver.payload + ";later=" + receiver.later;
    }

    public static String objectBeforeLaterField(OrderedFieldConcat receiver) {
        return "object=" + receiver + ";later=" + receiver.later;
    }

    public static String nullObject(Object value) {
        return "object=" + value;
    }

    public static String charArrayAsObject(Object value) {
        return "object=" + value;
    }

    public String toString() {
        this.toStringCalls++;
        this.later = 99;
        event("object.toString");
        return this.textResult;
    }
}
