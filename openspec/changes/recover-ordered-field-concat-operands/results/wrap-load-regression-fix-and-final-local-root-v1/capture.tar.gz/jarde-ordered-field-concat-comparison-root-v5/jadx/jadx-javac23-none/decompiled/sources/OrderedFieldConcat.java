// default package

/* JADX INFO: loaded from: OrderedFieldConcat.class */
public final class OrderedFieldConcat {
    public int value;
    public volatile int volatileValue;
    public int later;
    public Object payload;
    public int toStringCalls;
    public String textResult = "object";
    public String events = "";

    public OrderedFieldConcat(int i, int i2, int i3) {
        this.value = i;
        this.volatileValue = i2;
        this.later = i3;
    }

    private void event(String str) {
        if (!this.events.isEmpty()) {
            this.events += ",";
        }
        this.events += str;
    }

    public static String instanceFields(OrderedFieldConcat orderedFieldConcat) {
        return "value=" + orderedFieldConcat.value + ";volatile=" + orderedFieldConcat.volatileValue;
    }

    public static String plainPlusObjectBeforeLaterField(OrderedFieldConcat orderedFieldConcat) {
        return "object=" + orderedFieldConcat + ";later=" + orderedFieldConcat.later;
    }

    public static String explicitValueOfBeforeLaterField(OrderedFieldConcat orderedFieldConcat) {
        return "object=" + String.valueOf(orderedFieldConcat) + ";later=" + orderedFieldConcat.later;
    }

    public static String objectFieldBeforeLaterField(OrderedFieldConcat orderedFieldConcat) {
        return "object=" + orderedFieldConcat.payload + ";later=" + orderedFieldConcat.later;
    }

    public static String objectBeforeLaterField(OrderedFieldConcat orderedFieldConcat) {
        return "object=" + orderedFieldConcat + ";later=" + orderedFieldConcat.later;
    }

    public static String nullObject(Object obj) {
        return "object=" + obj;
    }

    public static String charArrayAsObject(Object obj) {
        return "object=" + obj;
    }

    public String toString() {
        this.toStringCalls++;
        this.later = 99;
        event("object.toString");
        return this.textResult;
    }
}
