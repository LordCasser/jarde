// jarde: presentation of `OrderedFieldConcat` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class OrderedFieldConcat extends java.lang.Object {
    public int value;

    public volatile int volatileValue;

    public int later;

    public java.lang.Object payload;

    public int toStringCalls;

    public java.lang.String textResult;

    public java.lang.String events;

    public OrderedFieldConcat(int arg1, int arg2, int arg3) {
        // @method <init>(III)V
        // @declaration a constructor of `OrderedFieldConcat`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.textResult = "object";
        this.events = "";
        this.value = arg1;
        this.volatileValue = arg2;
        this.later = arg3;
        return;
    }

    private void event(java.lang.String arg1) {
        // @method event(Ljava/lang/String;)V
        // @declaration an instance method of `OrderedFieldConcat`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        if (!this.events.isEmpty()) {
            this.events = this.events + ",";
        }
        this.events = this.events + arg1;
        return;
    }

    public static java.lang.String instanceFields(OrderedFieldConcat arg0) {
        // @method instanceFields(LOrderedFieldConcat;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "value=" + arg0.value + ";volatile=" + arg0.volatileValue;
    }

    public static java.lang.String plainPlusObjectBeforeLaterField(OrderedFieldConcat arg0) {
        // @method plainPlusObjectBeforeLaterField(LOrderedFieldConcat;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "object=" + java.lang.String.valueOf((java.lang.Object) arg0) + ";later=" + arg0.later;
    }

    public static java.lang.String explicitValueOfBeforeLaterField(OrderedFieldConcat arg0) {
        // @method explicitValueOfBeforeLaterField(LOrderedFieldConcat;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "object=" + java.lang.String.valueOf((java.lang.Object) arg0) + ";later=" + arg0.later;
    }

    public static java.lang.String objectFieldBeforeLaterField(OrderedFieldConcat arg0) {
        // @method objectFieldBeforeLaterField(LOrderedFieldConcat;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "object=" + java.lang.String.valueOf((java.lang.Object) arg0.payload) + ";later=" + arg0.later;
    }

    public static java.lang.String objectBeforeLaterField(OrderedFieldConcat arg0) {
        // @method objectBeforeLaterField(LOrderedFieldConcat;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "object=" + java.lang.String.valueOf((java.lang.Object) arg0) + ";later=" + arg0.later;
    }

    public static java.lang.String nullObject(java.lang.Object arg0) {
        // @method nullObject(Ljava/lang/Object;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "object=" + arg0;
    }

    public static java.lang.String charArrayAsObject(java.lang.Object arg0) {
        // @method charArrayAsObject(Ljava/lang/Object;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "object=" + arg0;
    }

    public java.lang.String toString() {
        // @method toString()Ljava/lang/String;
        // @declaration an instance method of `OrderedFieldConcat`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        this.toStringCalls += 1;
        this.later = 99;
        this.event("object.toString");
        return this.textResult;
    }
}
