// jarde: presentation of `OrderedFieldConcat` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class OrderedFieldConcat extends java.lang.Object {
    public int value;

    public volatile int volatileValue;

    public int later;

    public java.lang.Object payload;

    public int toStringCalls;

    public java.lang.String textResult;

    public java.lang.String events;

    public OrderedFieldConcat(int value, int volatileValue, int later) {
        // @method <init>(III)V
        // @declaration a constructor of `OrderedFieldConcat`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.textResult = "object";
        this.events = "";
        this.value = value;
        this.volatileValue = volatileValue;
        this.later = later;
        return;
    }

    private void event(java.lang.String value) {
        // @method event(Ljava/lang/String;)V
        // @declaration an instance method of `OrderedFieldConcat`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        if (!this.events.isEmpty()) {
            this.events = this.events + ",";
        }
        this.events = this.events + value;
        return;
    }

    public static java.lang.String instanceFields(OrderedFieldConcat receiver) {
        // @method instanceFields(LOrderedFieldConcat;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "value=" + receiver.value + ";volatile=" + receiver.volatileValue;
    }

    public static java.lang.String plainPlusObjectBeforeLaterField(OrderedFieldConcat receiver) {
        // @method plainPlusObjectBeforeLaterField(LOrderedFieldConcat;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "object=" + java.lang.String.valueOf((java.lang.Object) receiver) + ";later=" + receiver.later;
    }

    public static java.lang.String explicitValueOfBeforeLaterField(OrderedFieldConcat receiver) {
        // @method explicitValueOfBeforeLaterField(LOrderedFieldConcat;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "object=" + java.lang.String.valueOf((java.lang.Object) receiver) + ";later=" + receiver.later;
    }

    public static java.lang.String objectFieldBeforeLaterField(OrderedFieldConcat receiver) {
        // @method objectFieldBeforeLaterField(LOrderedFieldConcat;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "object=" + java.lang.String.valueOf((java.lang.Object) receiver.payload) + ";later=" + receiver.later;
    }

    public static java.lang.String objectBeforeLaterField(OrderedFieldConcat receiver) {
        // @method objectBeforeLaterField(LOrderedFieldConcat;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "object=" + java.lang.String.valueOf((java.lang.Object) receiver) + ";later=" + receiver.later;
    }

    public static java.lang.String nullObject(java.lang.Object value) {
        // @method nullObject(Ljava/lang/Object;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "object=" + value;
    }

    public static java.lang.String charArrayAsObject(java.lang.Object value) {
        // @method charArrayAsObject(Ljava/lang/Object;)Ljava/lang/String;
        // @declaration a static method of `OrderedFieldConcat`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return "object=" + value;
    }

    public java.lang.String toString() {
        // @method toString()Ljava/lang/String;
        // @declaration an instance method of `OrderedFieldConcat`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        this.toStringCalls += 1;
        this.later = 99;
        this.event("object.toString");
        return this.textResult;
    }
}
