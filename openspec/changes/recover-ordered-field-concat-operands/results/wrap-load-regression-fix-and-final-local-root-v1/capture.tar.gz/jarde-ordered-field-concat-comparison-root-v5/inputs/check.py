#!/usr/bin/env python3
"""Independent structural checker for an ordered-field concat comparison receipt."""
import hashlib, importlib.util, json, re, sys
from pathlib import Path

SCHEMA='jarde-ordered-field-concat-comparison-v1'
def sha(data): return hashlib.sha256(data).hexdigest()
def pin_ok(row):
 try:
  p=Path(row['path']); b=p.read_bytes()
  return len(b)==row.get('bytes') and sha(b)==row.get('sha256')
 except Exception: return False
def errors_for(doc):
 e=[]
 if doc.get('schema')!=SCHEMA:e.append('schema mismatch')
 if doc.get('status')!='observed':e.append('collector did not finish with observed status')
 if doc.get('source_tool_inputs_unchanged') is not True:e.append('source/tool pins changed during collection')
 if doc.get('actual_command_count')!=len(doc.get('commands',[])):e.append('command count does not match records')
 if len(doc.get('candidate_lanes',[]))!=4 or doc.get('actual_candidate_lane_count')!=4:e.append('candidate four-lane matrix incomplete')
 if len(doc.get('jadx_lanes',[]))!=4 or doc.get('actual_jadx_lane_count')!=4:e.append('JADX four-lane matrix incomplete')
 if len(doc.get('three_way_lanes',[]))!=4:e.append('three-way whole-class comparison matrix incomplete')
 before=doc.get('source_tool_pins_before',[]); after=doc.get('source_tool_pins_after',[])
 if before!=after:e.append('before/after immutable input pins differ')
 for row in before:
  if not pin_ok(row):e.append('immutable input pin is not current: '+str(row.get('path')))
 for group in ('candidate_cli','candidate_focused_receipt'):
  if not pin_ok(doc.get(group,{})):e.append(group+' pin is not current')
 for key in ('runner','command_spec'):
  if not pin_ok(doc.get('candidate_focused_build',{}).get(key,{})):e.append('focused build '+key+' pin is not current')
 build=doc.get('candidate_focused_build',{})
 receipt_path=Path(doc.get('output_root',''))/'inputs'/'focused-receipt.json'
 try:
  receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
  if not pin_ok({'path':str(receipt_path),'bytes':doc['candidate_focused_receipt']['bytes'],'sha256':doc['candidate_focused_receipt']['sha256']}):e.append('copied focused receipt pin mismatch')
  if build.get('source_manifest_before')!=receipt.get('source_manifest_before') or build.get('source_manifest_after')!=receipt.get('source_manifest_after'):e.append('focused receipt source closure arrays are not embedded exactly')
  spec_path=Path(build['command_spec']['path'])
  spec=json.loads(spec_path.read_text(encoding='utf-8'))
  if [x.get('argv') for x in receipt.get('commands',[]) if not x.get('cleanup_only')]!=spec:e.append('focused receipt actual argv differs from pinned command spec')
  for c in build.get('commands',[]):
   if c.get('exit_code')!=0 or c.get('guard_stop') is not None:e.append('focused root build command failed/guarded')
   for stream in c.get('streams',{}).values():
    if not pin_ok(stream):e.append('focused root build raw stream pin invalid')
 except Exception as ex:e.append('focused receipt copy/closure cannot be verified: '+type(ex).__name__+': '+str(ex))
 if doc.get('candidate_cli',{}).get('path') and Path(doc['candidate_cli']['path']).exists():
  if not pin_ok(doc['candidate_cli']):e.append('candidate CLI binary pin invalid')
  elif Path(doc['candidate_cli']['path']).stat().st_mode & 0o777 != 0o555:e.append('candidate CLI mode is not frozen 0555')
 # Recompute the focused source closure independently from the frozen helper modules.
 try:
  pins=json.loads((Path(__file__).resolve().parent/'pins.json').read_text(encoding='utf-8'))
  fm=pins['focused_manifest_module']['path']; cm=pins['source_closure_module']['path']
  def module(path,name):
   spec=importlib.util.spec_from_file_location(name,path); value=importlib.util.module_from_spec(spec); spec.loader.exec_module(value); return value
  focus=module(fm,'field_check_source_manifest'); closure=module(cm,'field_check_source_closure')
  from pathlib import Path as P
  focus.ROOT=P(pins['workspace_root']); focus.CLOSURE_MODULE=closure; closure.ROOT=P(pins['workspace_root'])
  if focus.source_manifest()!=build.get('source_manifest_after'):e.append('current workspace source closure differs from focused receipt')
 except Exception as ex:e.append('cannot independently recompute focused source closure: '+type(ex).__name__+': '+str(ex))
 # Every command keeps actual argv, exit status, and hash-checked raw stdout/stderr.
 for c in doc.get('commands',[]):
  if not c.get('argv') or c.get('exit_code') is None:e.append('command lacks argv/exit code: '+str(c.get('label')))
  for stream in ('stdout','stderr'):
   if not pin_ok(c.get('streams',{}).get(stream,{})):e.append('command raw '+stream+' pin invalid: '+str(c.get('label')))
   if c.get('guard_stop') is not None:e.append('resource guard stopped command: '+str(c.get('label')))
 # The six original Java lanes are retained as individually pinned evidence.
 originals=doc.get('original_jvm_six_lanes',[])
 if len(originals)!=6:e.append('six-lane original JVM evidence missing')
 for row in originals:
  for key in ('class','javap_stdout','main_stdout'):
   if not pin_ok(row.get(key,{})):e.append('original evidence pin invalid '+str(row.get('id'))+'/'+key)
  if not pin_ok(row.get('null_runner_stdout',{})):
   e.append('null-receiver original output pin invalid '+str(row.get('id')))
  for key in ('compile_command','javap_command','run_command','null_runner_command'):
   cmd=row.get(key)
   if cmd and (cmd.get('exit_code')!=0 or cmd.get('guard_stop') is not None):e.append('original command failed '+str(row.get('id'))+'/'+key)
 # Validate candidate compile/run gates and compare all observed stdout without assuming equality.
 expected={('javac8','debug'),('javac8','none'),('javac23','debug'),('javac23','none')}
 actual={(x.get('jdk'),x.get('mode')) for x in doc.get('candidate_lanes',[])}
 if actual!=expected:e.append('candidate JDK/profile identities mismatch')
 actual_j={(x.get('jdk'),x.get('mode')) for x in doc.get('jadx_lanes',[])}
 if actual_j!=expected:e.append('JADX JDK/profile identities mismatch')
 for row in doc.get('candidate_lanes',[])+doc.get('jadx_lanes',[]):
  prefix=row.get('label','')
  if not pin_ok(row.get('input_class',{})):e.append('render input class pin invalid: '+prefix)
  for key in ('render_stdout','report_pin','generated_source','source_map_methods','derived_runner'):
   if row.get(key) and not pin_ok(row[key]):e.append('candidate artifact pin invalid '+prefix+'/'+key)
  for c in row.get('compile_run',{}).get('classes',[]):
   if not pin_ok(c):e.append('candidate compiled class pin invalid: '+prefix)
  rc=row.get('render_command',{}).get('exit_code')
  record=row.get('compile_run')
  if rc!=0 and record is not None:e.append('compile attempted after failed renderer: '+prefix)
  if record:
   comp=record.get('compile',{}); run=record.get('run')
   if comp.get('exit_code')!=0 or comp.get('guard_stop') is not None:
    if run is not None or row.get('runtime_state')!='no-runtime':e.append('runtime after failed compile: '+prefix)
   elif run is None:e.append('successful compile lacks runtime attempt: '+prefix)
   elif run.get('exit_code') is None:e.append('runtime missing exit code: '+prefix)
   if run:
    for stream in ('stdout','stderr'):
     if not pin_ok(run.get('streams',{}).get(stream,{})):e.append('runtime raw stream pin invalid: '+prefix+'/'+stream)
   comparison=row.get('stdout_comparison')
   if comparison:
    if comparison.get('baseline_sha256')!=row.get('original_null_runner_stdout',{}).get('sha256'):
     e.append('stdout comparison uses wrong original baseline: '+prefix)
    if run and comparison.get('candidate_sha256')!=run.get('streams',{}).get('stdout',{}).get('sha256'):
     e.append('stdout comparison candidate hash mismatch: '+prefix)
  if row.get('render_command',{}).get('guard_stop') is not None:e.append('render guard stopped: '+prefix)
 for row in doc.get('jadx_lanes',[]):
  label=row.get('label','')
  if not pin_ok(row.get('input_class',{})):e.append('JADX input class pin invalid: '+label)
  for source in row.get('generated_sources',[]):
   if not pin_ok(source):e.append('JADX source pin invalid: '+label)
  if row.get('derived_runner') and not pin_ok(row['derived_runner']):e.append('JADX derived Runner pin invalid: '+label)
  for c in row.get('compile_run',{}).get('classes',[]):
   if not pin_ok(c):e.append('JADX compiled class pin invalid: '+label)
 # Verify original bytecode BCI requirements against actual method source maps and generated source.
 for row in doc.get('candidate_lanes',[]):
  targets=row.get('expected_source_map_bcis',{})
  method_rows=[]
  map_pin=row.get('source_map_methods')
  srcpin=row.get('generated_source',{})
  whole_bytes=Path(srcpin['path']).read_bytes() if srcpin and pin_ok(srcpin) else None
  if map_pin and pin_ok(map_pin):
   try: method_rows=json.loads(Path(map_pin['path']).read_text(encoding='utf-8'))
   except Exception as ex:e.append('source-map method table unreadable '+row.get('label','')+': '+str(ex))
  else:e.append('candidate source-map method table missing '+row.get('label',''))
  by_name={m.get('name'):m for m in method_rows}
  for target_name in ('instanceFields.value','instanceFields.volatileValue','objectFieldBeforeLaterField.payload'):
   target=targets.get(target_name,{})
   if target.get('field_bci') is None or target.get('append_bci') is None:
    e.append('original javap did not resolve field/append BCIs '+row.get('label','')+'/'+target_name)
    continue
   method=target_name.split('.',1)[0]; mapped=by_name.get(method)
   if not mapped or not mapped.get('source_map') or not mapped.get('segments'):
    e.append('actual source map missing for '+row.get('label','')+'/'+method); continue
   bcis=set(mapped.get('mapped_bcis',[]))
   if target['field_bci'] not in bcis:e.append('field read BCI absent from source map '+row.get('label','')+'/'+target_name)
   if target['append_bci'] not in bcis:e.append('append/conversion BCI absent from source map '+row.get('label','')+'/'+target_name)
   physical=mapped.get('physical_identity')
   if not isinstance(physical,dict):e.append('method row lacks physical identity '+row.get('label','')+'/'+method)
   method_text=mapped.get('method_text')
   method_bytes=method_text.encode('utf-8') if isinstance(method_text,str) else None
   report_text=mapped.get('report_text')
   report_bytes=report_text.encode('utf-8') if isinstance(report_text,str) else None
   if mapped.get('artifact_scope')!='recovery-report-text' or report_bytes is None:
    e.append('source-map artifact scope is not recovery-report.text '+row.get('label','')+'/'+method)
   if method_bytes is None or whole_bytes is None:
    e.append('method.text or assembled class text unavailable '+row.get('label','')+'/'+method)
   elif not method_bytes or whole_bytes.count(method_bytes)!=1 or mapped.get('method_text_unique_in_assembled_class') is not True:
    e.append('method.text is not uniquely present in assembled class '+row.get('label','')+'/'+method)
   def anchors(origin):
    return (origin.get('primary',[]) if isinstance(origin,dict) else [], origin.get('derived',[]) if isinstance(origin,dict) else [])
   primary_field=False; derived_append=False; physical_mismatch=False
   for seg in mapped['segments']:
    if seg.get('start') is None or seg.get('end') is None or seg.get('text') is None:
     e.append('source map segment has no verifiable byte range/text '+row.get('label','')+'/'+method); break
    if report_bytes is not None:
     try:
      artifact=report_bytes[seg['start']:seg['end']].decode('utf-8')
     except Exception: artifact=None
     if artifact!=seg['text']:
      e.append('source-map segment does not slice recovery-report.text '+row.get('label','')+'/'+method); break
    prim,der=anchors(seg.get('origins'))
    if isinstance(prim,dict):
     if prim.get('bci')==target['field_bci'] and prim.get('provenance')=='Direct':primary_field=True
     if prim.get('method')!=physical:physical_mismatch=True
    for origin in der:
     if isinstance(origin,dict):
      if origin.get('bci')==target['append_bci'] and origin.get('provenance')=='Derived':derived_append=True
      if origin.get('method')!=physical:physical_mismatch=True
   if not primary_field:e.append('field read is not a direct primary source-map origin '+row.get('label','')+'/'+target_name)
   if not derived_append:
    e.append('append is not represented as a derived origin from the field operand '+row.get('label','')+'/'+target_name)
   if physical_mismatch:e.append('source-map anchor physical method identity differs from its method row '+row.get('label','')+'/'+method)
  obj=by_name.get('objectFieldBeforeLaterField',{})
  # This check records the exact conversion syntax required by the design and ties its append site to the real Object overload BCI.
  if srcpin and pin_ok(srcpin):
   text=Path(srcpin['path']).read_text(encoding='utf-8')
   pattern=r'(?:java\.lang\.)?String\.valueOf\s*\(\s*\(\s*(?:java\.lang\.)?Object\s*\)'
   if not re.search(pattern,text):
    e.append('field-backed Object conversion lacks explicit valueOf(Object) in assembled class: '+row.get('label',''))
   for mapped in by_name.values():
    report=mapped.get('report_text','')
    method_source=mapped.get('method_text','')
    if mapped.get('name')=='objectFieldBeforeLaterField' and (not re.search(pattern,report) or not re.search(pattern,method_source)):
     e.append('field-backed Object conversion wrapper is absent from report/class method text: '+row.get('label',''))
  elif row.get('render_command',{}).get('exit_code')==0:e.append('successful render has no generated whole-class source '+row.get('label',''))
  if obj and targets.get('objectFieldBeforeLaterField.payload',{}).get('append_bci') not in set(obj.get('mapped_bcis',[])):
   e.append('field-backed Object append conversion BCI not mapped '+row.get('label',''))
  controls=row.get('conversion_controls',{})
  if controls.get('explicit_equals_builder') is False:e.append('explicit valueOf and builder field controls differ '+row.get('label',''))
 # Recompute every pairwise byte observation; no lane is presumed equal to another.
 for tri in doc.get('three_way_lanes',[]):
  key=(tri.get('jdk'),tri.get('mode')); cand=next((x for x in doc.get('candidate_lanes',[]) if (x.get('jdk'),x.get('mode'))==key),{})
  jadx_row=next((x for x in doc.get('jadx_lanes',[]) if (x.get('jdk'),x.get('mode'))==key),{})
  orig=cand.get('original_null_runner_stdout',{}).get('sha256')
  ch=cand.get('stdout_comparison',{}).get('candidate_sha256'); jh=jadx_row.get('stdout_comparison',{}).get('candidate_sha256')
  if (tri.get('original_stdout_sha256'),tri.get('jarde_stdout_sha256'),tri.get('jadx_stdout_sha256'))!=(orig,ch,jh):e.append('three-way output hashes do not match lane receipts')
  if tri.get('jarde_matches_original')!=bool(ch and ch==orig) or tri.get('jadx_matches_original')!=bool(jh and jh==orig) or tri.get('jarde_matches_jadx')!=bool(ch and jh and ch==jh):e.append('three-way equality result is inaccurate')
 # The source-derived comparison has no assertion that every implementation matches the original; differences are reported as data.
 result={'candidate_runtime_matches_original':sum(1 for x in doc.get('candidate_lanes',[]) if x.get('stdout_comparison',{}).get('byte_identical') is True),
         'candidate_runtime_differences':sum(1 for x in doc.get('candidate_lanes',[]) if x.get('runtime_state')=='ran' and x.get('stdout_comparison',{}).get('byte_identical') is False),
         'jadx_runtime_matches_original':sum(1 for x in doc.get('jadx_lanes',[]) if x.get('stdout_comparison',{}).get('byte_identical') is True),
         'jadx_runtime_differences':sum(1 for x in doc.get('jadx_lanes',[]) if x.get('runtime_state')=='ran' and x.get('stdout_comparison',{}).get('byte_identical') is False),
         'candidate_compile_failures':sum(1 for x in doc.get('candidate_lanes',[]) if x.get('compile_run',{}).get('compile',{}).get('exit_code') not in (None,0)),
         'jadx_compile_failures':sum(1 for x in doc.get('jadx_lanes',[]) if x.get('compile_run',{}).get('compile',{}).get('exit_code') not in (None,0))}
 return e,result
def main():
 if len(sys.argv)!=2:raise SystemExit('usage: check.py EXECUTION_JSON')
 doc=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
 errors,result=errors_for(doc)
 print(json.dumps(result,ensure_ascii=False,indent=2))
 if errors:
  for x in errors:print('FAIL:',x)
  return 1
 print('comparison receipt, raw provenance, and required source-map BCI checks passed; runtime equality remains reported per lane')
 return 0
if __name__=='__main__':raise SystemExit(main())
