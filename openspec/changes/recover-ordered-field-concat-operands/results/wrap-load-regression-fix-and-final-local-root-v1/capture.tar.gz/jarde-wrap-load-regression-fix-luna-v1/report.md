# C2W main false refusal: catch identity must be handler scoped

The private patch is based on the current shared `crates/jarde-java/src/build.rs` SHA-256
`be3f54386e9355f0feb466eda9b9d258e89c52a4ca9b1e431a6df0cea86f1b66`.

`/private/tmp/jarde-ordered-field-full-workspace-run-root-v6/59.stdout.raw` shows that the whole
class `C2W` failed only because `main` was refused with `local 1 escapes catch parameter scope at
region [0, 1]`; the other wrap-family tests passed. `main` has adjacent `try/catch` statements whose
handlers reuse local slot 1. `catch_parameter_stays_in_clause` proves escape for one `(clause,
handler, slot)` at a time and already compares each read with that handler's own entry-store
`ValueId`. The added unconditional `Definition::Caught` refusal confuses a different catch's value
with that current binding, so a read in another reused-slot handler falsely counts as escape.

The value identity is sufficient for the new Load rule too: it invokes this helper for every
registered handler. A true catch-parameter copy follows Store/Load/Phi aliases to the corresponding
handler entry `ValueId` and is refused there. The missing/empty-phi and `PhiInput::Itself` refusals
remain intact. `Definition::Caught.block/bci` are throw-site coordinates (the SSA builder creates
Caught values from `self.caught(source, bci, ordinal)`), so comparing those fields with the handler
would be incorrect. A direct Caught value that did not pass through a handler entry cannot be the
local input of an `aload`; adding a separate general Caught-origin proof is unnecessary here.

The patch removes only the global Caught rejection and documents the exact handler-entry identity
check. It does not change the declared-type check: exact verifier-stated reference types, null and
Object behavior remain as currently implemented. The existing `wrap_family_recovers_every_variant_with_the_required_spelling` assertion continues to enforce whole-class output, while SHARED/ESCAPED scope checks retain their existing behavior. No shared file was changed and no Cargo/JDK/JADX/CLI/Git command was run.
