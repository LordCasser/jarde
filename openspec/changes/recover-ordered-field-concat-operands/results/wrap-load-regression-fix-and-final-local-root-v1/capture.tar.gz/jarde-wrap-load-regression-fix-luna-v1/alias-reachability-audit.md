# Caught-value reachability through handler entry stores

## Result

I found no reachable `aload` path that carries a caught exception into a local without passing through the handler's entry store value that `catch_parameter_stays_in_clause` compares against. A handler receives the exception on operand stack slot 0. Its local catch parameter exists only after a store consumes that stack value. The new Load guard inspects the Load's actual `Slot::Local` input, so the raw `Definition::Caught` stack value cannot itself be that input.

The per-handler walk therefore still catches aliases after removal of the global `Caught` rejection. It compares against the selected handler's entry write value, not the shared JVM local slot. `Caught.block/bci` being throw-site coordinates does not weaken this identity check.

## SSA route from exception edge to local

`Assigner::resolve` handles an exception input by supplying a `Caught` value specifically for `Slot::Stack(0)`; other slots come from the protected source state. This applies both when an exception edge has an anchored throw site and when no site anchors the edge (`crates/jarde-jvm/src/ssa.rs:1403-1429`). `caught()` records `Definition::Caught { block, bci }` using the source block and throw-site BCI (`:1474-1524`).

At handler entry, the block's entry state merges each logical predecessor's value for a slot. For stack slot 0, multiple exception predecessors can yield a phi whose leaves are different throw-site `Caught` values; one usable incoming value can instead make the phi trivial. The instruction that stores stack slot 0 into the catch local is a normal `Operation::Store`, and its SSA write is a distinct instruction value. `catch_parameter_stays_in_clause` retrieves that write by handler block, handler BCI, and local slot (`crates/jarde-java/src/build.rs:4053-4067`). The store's source is the stack operand (`store_operand`, `build.rs:33310-33316`). Thus the multi-source phi, if present, is upstream of the entry write. It does not replace the entry write as the local's initial reaching definition.

Every later local read names the current reaching local value. If the value comes directly from the catch entry, the alias walk immediately sees the entry write's `ValueId`. If the bytecode copies it through another local, the walk follows the output of each `Store` to its stack operand and each `Load` to its local input (`build.rs:4121-4141`). If control flow merges the catch value with other values, the walk explores every non-self phi input. Any path carrying this catch binding eventually reaches the entry write and rejects the proof (`:4108-4119`).

## Trivial phis and replacement chains

The SSA simplifier replaces only trivial phis, records the target in `replaced_by`, and redirects reads to the target (`crates/jarde-jvm/src/ssa.rs:1747-1771`, `:1822-1834`). The helper follows each `replaced_by` link before inspecting the definition (`crates/jarde-java/src/build.rs:4105-4108`), so a simplified local phi that resolves to the entry write still hits the identity check. A nontrivial phi retains its inputs and the helper visits each one. Missing and empty phi records, and `PhiInput::Itself`, continue to fail closed (`:4108-4119`); there is no path where those cases silently erase a possible entry-store contributor.

The catch entry itself is a `Definition::Instruction` written by the handler's store, not a phi, so trivial-phi replacement does not rename that instruction value. A join after the entry can simplify to it, in which case the replacement chain reaches it; otherwise the join's inputs include it and the walk reaches it directly.

## Scope of the conclusion

This establishes reachability for the relevant source shape: a `presented_reference_store_value` `Operation::Load`, whose actual input is a local read, with aliases made by local stores/loads and control-flow phis. Other operations that could transform or carry the reference are not accepted as proven aliases by this bounded walk: unknown instruction definitions return false. The existing narrow `List.iterator()` exception walks its inputs, and an input equal to the catch entry is likewise found. This audit does not claim completeness for arbitrary JVM reference expressions; those shapes remain refused by the current proof.

If a handler lacks the expected entry store at its handler BCI and slot, `catch_parameter_stays_in_clause` returns false rather than inferring binding from slot reuse (`:4053-4067`). That is conservative and does not create a bypass.

No source was modified. I did not run Cargo, JDK, JADX, CLI, or Git commands.
