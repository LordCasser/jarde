# OpenSpec recover-loop-body-try-catch candidate comparison

The collector entry point is `collect.py`. Invoke it with a root-frozen candidate CLI, that CLI's focused root execution receipt, and a new output directory:

```sh
python3 -B /private/tmp/jarde-loop-candidate-comparison-prep-luna-v2/collect.py \
  /private/tmp/jarde-loop-combined-focused-root-v5/candidate-cli \
  /private/tmp/jarde-loop-combined-focused-root-v5/execution.json \
  /private/tmp/jarde-loop-candidate-comparison-root-v2
```

The CLI path and SHA are read from argv and must exactly match the root receipt's `cli` object; the executable must be mode 0555. The receipt must use the current `commands_passed_pending_independent_acceptance` schema, carry complete before/after source manifests, successful build/test and cleanup command records, and confirm `target_absent`. Before collecting comparisons, the script recomputes the current source closure and requires it to equal `source_manifest_after`; its count is derived from that manifest.

The candidate comparison has 16 render lanes: DF and DV for debug/none × javac8/javac23, plus RetryFixture v2/v3 across the same four mode/JDK combinations. DF/DV are rendered separately and then compiled together with Runner for four joint runtime lanes. Retry candidates are rendered, compiled as whole classes with Runner, and run only after a successful compile. A failed or guarded compile never reaches Java runtime. Only a copied Runner may receive a package prefix needed by generated sources.

Fixed original and JADX evidence is reused from the pinned baseline receipts in `pins.json`. The independently accepted default-package JADX Runner adapter is also validated and referenced from its exact root receipt. Retry original stdout is checked byte-for-byte against the fixture oracle. The checker preserves the actual JADX outcomes instead of assuming a package or successful result.

`check.py` independently validates the resulting execution receipt and raw pins. `test_check.py` exercises the current v5 receipt, the existing accepted adapter, actual v2/v3 original oracle records, and compile-failure runtime suppression. These checks use Python's standard library only. The collector does not compile Rust or download target dependencies. Its per-command guard requires at least 5 GiB free space, limits the workspace target tree to 1 GiB, and samples resource usage every second.
