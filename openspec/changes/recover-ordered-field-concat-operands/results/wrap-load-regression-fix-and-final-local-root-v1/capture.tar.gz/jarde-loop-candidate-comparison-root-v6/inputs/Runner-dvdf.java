import java.util.Arrays;

public final class Runner {
    private interface Call { int run() throws Throwable; }
    private static String show(int[] xs) {
        return xs == null ? "null" : Arrays.toString(xs);
    }
    private static void check(String owner, String method, int[] xs, Call call) {
        String label = owner + "." + method + " input=" + show(xs);
        try {
            System.out.println(label + " => value=" + call.run());
        } catch (Throwable t) {
            System.out.println(label + " => throws=" + t.getClass().getName());
        }
    }
    private static int[] input(int which) {
        if (which == 0) return new int[0];
        if (which == 1) return new int[] {1, -2, 3};
        return null;
    }
    public static void main(String[] args) {
        for (int n = 0; n < 3; n++) {
            final int[] xs = input(n);
            check("DV", "plainFor", xs, new Call() { public int run() { return DV.plainFor(xs); } });
            check("DV", "whileLoop", xs, new Call() { public int run() { return DV.whileLoop(xs); } });
            check("DV", "forEach", xs, new Call() { public int run() { return DV.forEach(xs); } });
            check("DV", "loopNoTry", xs, new Call() { public int run() { return DV.loopNoTry(xs); } });
            check("DF", "loopCatch", xs, new Call() { public int run() { return DF.loopCatch(xs); } });
            check("DF", "loopFinally", xs, new Call() { public int run() { return DF.loopFinally(xs); } });
        }
    }
}
