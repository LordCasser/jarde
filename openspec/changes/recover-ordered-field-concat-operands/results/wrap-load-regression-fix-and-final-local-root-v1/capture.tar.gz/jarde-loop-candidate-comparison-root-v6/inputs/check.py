#!/usr/bin/env python3
"""Small stdlib checker for candidate comparison receipts and pinned oracles."""
from __future__ import annotations
import hashlib, importlib.util, json, re, sys
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
FOCUS_MODULE=Path('/private/tmp/jarde-cf11-structured-list-focused-runner-prep-luna-v7/run.py')
FOCUS_MODULE_SHA='c8b1016eaf9506912876fd92e8544d5f78e472401beb99e3fd75b549607956bc'
CLOSURE_MODULE=Path('/private/tmp/jarde-iterator-assignment-full-validation-prep-luna-v2/workspace_runner.py')
CLOSURE_MODULE_SHA='63e52b55fe5d20d5f2ece98ac80676ccdb2de8dfd33d7199b688e075fb1e9673'

def pin(path):
    p=Path(path); data=p.read_bytes()
    return {'path':str(p.resolve()),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def check_embedded_pin(row):
    if not isinstance(row,dict) or not all(k in row for k in ('path','bytes','sha256')): return ['incomplete raw pin']
    try: actual=pin(row['path'])
    except Exception as exc: return ['raw pin unavailable: '+str(row.get('path'))+' ('+type(exc).__name__+')']
    return [] if all(actual[k]==row[k] for k in ('path','bytes','sha256')) else ['raw pin mismatch: '+str(row['path'])]

def check_nested_pins(value):
    errors=[]
    if isinstance(value,dict):
        if all(k in value for k in ('path','bytes','sha256')) and isinstance(value.get('path'),str): errors.extend(check_embedded_pin(value))
        for child in value.values(): errors.extend(check_nested_pins(child))
    elif isinstance(value,list):
        for child in value: errors.extend(check_nested_pins(child))
    return errors

def check_default_adapter(doc):
    row=doc.get('accepted_default_jadx_adapter',{}); errors=[]
    receipt_pin=row.get('receipt',{})
    errors.extend(check_embedded_pin(receipt_pin))
    if errors: return errors
    try: receipt=json.loads(Path(receipt_pin['path']).read_text(encoding='utf-8'))
    except Exception as exc: return ['default JADX adapter receipt unavailable: '+type(exc).__name__]
    if receipt.get('schema')!='jarde-loop-body-catch-default-package-supplement-v1' or receipt.get('status')!='observed' or receipt.get('source_tool_inputs_unchanged') is not True:
        errors.append('default JADX adapter receipt is not observed')
    if row.get('lanes')!=receipt.get('lanes') or len(receipt.get('lanes',[]))!=4: errors.append('default JADX adapter lanes mismatch')
    if receipt.get('derived_runner_rule')!='exact bytes: b"package defpackage;\\n" + original Runner.java': errors.append('default JADX Runner adaptation rule mismatch')
    try:
        original=Path(receipt['original_runner']['path']).read_bytes(); derived=Path(receipt['derived_runner']['path']).read_bytes()
        if derived!=b'package defpackage;\n'+original: errors.append('default JADX Runner bytes do not match allowed prefix')
    except Exception as exc: errors.append('default JADX Runner source unavailable: '+type(exc).__name__)
    for lane in receipt.get('lanes',[]):
        errors.extend(check_nested_pins(lane))
        if lane.get('compile',{}).get('exit_code')!=0 or lane.get('run',{}).get('exit_code')!=0: errors.append('default JADX adapter lane did not compile/run')
    return errors

def check_root_build(doc):
    """Independently validate the pinned root build, raw test summaries and current source closure."""
    errors=[]; ref=doc.get('candidate_focused_receipt',{}); cli=doc.get('candidate_cli',{})
    try:
        actual_receipt=pin(ref['path'])
        if any(actual_receipt[k]!=ref[k] for k in ('path','bytes','sha256')): errors.append('focused receipt pin mismatch')
        receipt=json.loads(Path(ref['path']).read_text(encoding='utf-8'))
    except Exception as exc: return ['focused receipt unavailable: '+type(exc).__name__]
    if receipt.get('status')!='commands_passed_pending_independent_acceptance' or 'cli_freeze' in receipt: errors.append('legacy/invalid root focused receipt schema')
    cli_row=receipt.get('cli',{})
    for k in ('path','bytes','sha256'):
        if cli_row.get(k)!=cli.get(k): errors.append('focused receipt cli does not match candidate '+k)
    try:
        actual_cli=pin(cli_row['path'])
        if any(actual_cli[k]!=cli_row[k] for k in ('path','bytes','sha256')): errors.append('candidate CLI pin mismatch')
        if Path(cli_row['path']).stat().st_mode&0o777!=0o555: errors.append('candidate CLI mode is not 0555')
    except Exception as exc: errors.append('candidate CLI unavailable: '+type(exc).__name__)
    before=receipt.get('source_manifest_before'); after=receipt.get('source_manifest_after')
    if not isinstance(before,list) or not before or not isinstance(after,list) or not after: errors.append('source manifest arrays missing')
    else:
        if {x.get('path') for x in before}!={x.get('path') for x in after}: errors.append('source manifest membership changed during build')
        expected_count=len(after)
        if doc.get('candidate_source_closure_count')!=expected_count: errors.append('source closure count differs from current receipt')
        try:
            for path,expected in ((FOCUS_MODULE,FOCUS_MODULE_SHA),(CLOSURE_MODULE,CLOSURE_MODULE_SHA)):
                if pin(path)['sha256']!=expected: raise RuntimeError('pinned source manifest module changed')
            def module(path,name):
                spec=importlib.util.spec_from_file_location(name,path); value=importlib.util.module_from_spec(spec); spec.loader.exec_module(value); return value
            focus=module(FOCUS_MODULE,'check_current_source_manifest'); closure=module(CLOSURE_MODULE,'check_current_source_closure')
            focus.ROOT=ROOT; focus.CLOSURE_MODULE=closure; closure.ROOT=ROOT
            if focus.source_manifest()!=after: errors.append('current workspace source differs from source_manifest_after')
        except Exception as exc: errors.append('cannot independently recompute current source closure: '+type(exc).__name__+': '+str(exc))
    for key in ('runner','command_spec'):
        errors.extend(check_embedded_pin(receipt.get(key,{})))
    try:
        spec=json.loads(Path(receipt['command_spec']['path']).read_text(encoding='utf-8'))
        commands=receipt.get('commands',[])
        normal=[x for x in commands if not x.get('cleanup_only')]
        if [x.get('argv') for x in normal]!=spec: errors.append('actual root commands differ from pinned command spec')
    except Exception as exc:
        commands=[]; errors.append('root command spec unavailable: '+type(exc).__name__)
    tests=[]; builds=[]; cleans=[]
    for row in commands:
        if row.get('exit_code')!=0 or row.get('guard_stop') is not None: errors.append('root command failed or was guarded: '+str(row.get('argv')))
        streams=row.get('streams',{})
        for stream in ('stdout','stderr'): errors.extend(check_embedded_pin(streams.get(stream,{})))
        argv=row.get('argv',[])
        if argv[:2]==['cargo','test']:
            tests.append(row)
            try:
                raw=Path(streams['stdout']['path']).read_text(encoding='utf-8',errors='replace')
                raw=re.sub(r'\x1b\[[0-9;]*m','',raw)
                actual=[list(x) for x in re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)]
                if actual!=row.get('actual_test_summaries'): errors.append('test actual summaries differ from pinned stdout')
                if not actual or any(x[0]!='ok' or int(x[1])<=0 or int(x[2])!=0 for x in actual): errors.append('missing or failing actual test summary')
            except Exception as exc: errors.append('cannot read root test stdout: '+type(exc).__name__)
        if argv[:2]==['cargo','build']: builds.append(row)
        if row.get('cleanup_only'): cleans.append(row)
    if not tests: errors.append('focused receipt has no test command')
    if not builds: errors.append('focused receipt has no CLI build command')
    if len(cleans)!=1 or cleans[0].get('argv')!=['cargo','clean'] or cleans[0].get('exit_code')!=0: errors.append('focused receipt lacks successful cargo clean')
    if receipt.get('target_absent') is not True: errors.append('focused receipt does not confirm target absent')
    return errors

def source_closure_count(receipt):
    """Return the current receipt's explicit closure cardinality, with no legacy constant."""
    for key in ('source_closure_files','source_closure'):
        value=receipt.get(key)
        if isinstance(value,list): return len(value)
    manifest=receipt.get('source_manifest_before')
    if isinstance(manifest,list): return len(manifest)
    value=receipt.get('source_closure_count')
    if isinstance(value,int) and value>=0: return value
    build=receipt.get('build')
    if isinstance(build,dict) and isinstance(build.get('source_closure_count'),int):
        return build['source_closure_count']
    return None

def check_candidate(doc, verify_build=True, verify_adapter=True):
    errors=[]
    if doc.get('schema')!='jarde-loop-candidate-comparison-v1': errors.append('schema')
    if doc.get('status')!='observed': errors.append('execution status')
    if doc.get('source_tool_inputs_unchanged') is not True: errors.append('input/tool pins changed')
    closure=doc.get('candidate_source_closure_count')
    if not isinstance(closure,int) or closure<=0: errors.append('current candidate source closure count missing')
    if verify_build: errors.extend(check_root_build(doc))
    lanes=doc.get('candidate_lanes',[])
    if len(lanes)!=16 or doc.get('actual_candidate_lane_count')!=16: errors.append('candidate lane cardinality')
    render_count=sum(1 for x in doc.get('commands',[]) if str(x.get('label','')).endswith('-render'))
    if render_count!=16: errors.append('fresh candidate render cardinality')
    groups={}
    for row in lanes:
        label=row.get('label','')
        if label.startswith('dvdf-'):
            parts=label.split('-'); key=('dvdf',parts[1],parts[2])
            groups[key]=groups.get(key,0)+1
        elif label.startswith('retry-'):
            parts=label.split('-'); key=(parts[1],parts[2],parts[3])
            groups[key]=groups.get(key,0)+1
        cr=row.get('compile_run')
        if label.startswith('retry-') and row.get('original_oracle_byte_match') is not True: errors.append('pinned original oracle mismatch: '+label)
        if label.startswith('dvdf-') and cr is not None: errors.append('DV/DF per-class render must remain render-only: '+label)
        if label.startswith('retry-') and row.get('render_command',{}).get('exit_code')==0 and cr is None: errors.append('successful retry render lacks compile record: '+label)
        if cr:
            compile_row=cr.get('compile',{})
            if compile_row.get('exit_code')!=0 or compile_row.get('guard_stop'):
                if cr.get('run') is not None or row.get('runtime_state')!='no-runtime': errors.append('runtime after failed/guarded compile: '+label)
            elif cr.get('run') is None and row.get('runtime_state')!='no-runtime': errors.append('runtime state mismatch: '+label)
            elif cr.get('run') is not None and row.get('runtime_state')=='ran' and row.get('stdout_comparison',{}).get('byte_identical') is not True: errors.append('candidate runtime differs from pinned original: '+label)
        elif label.startswith('retry-') and row.get('runtime_state') not in ('no-runtime','no-runtime-until-joint-compile'): errors.append('missing compile record with runtime: '+label)
    whole=doc.get('whole_class_runs',[])
    if len(whole)!=4: errors.append('DV/DF joint compile/runtime lane cardinality')
    for row in whole:
        cr=row.get('compile_run',{}); comp=cr.get('compile') or {}
        if comp.get('exit_code')!=0 or comp.get('guard_stop'):
            if cr.get('run') is not None or cr.get('runtime_state','').startswith('ran'): errors.append('runtime after failed DV/DF joint compile')
        elif cr.get('run') is None and cr.get('runtime_state')=='ran': errors.append('DV/DF joint runtime record missing')
        elif cr.get('run') is not None and cr.get('runtime_state')=='ran' and row.get('stdout_comparison',{}).get('byte_identical') is not True:
            errors.append('DV/DF joint runtime differs from pinned original')
    adapter=doc.get('accepted_default_jadx_adapter',{})
    if adapter.get('status')!='observed' or adapter.get('source_tool_inputs_unchanged') is not True or len(adapter.get('lanes',[]))!=4:
        errors.append('accepted original/JADX default-package adapter evidence missing')
    if verify_adapter: errors.extend(check_default_adapter(doc))
    if len(groups)!=12 or any(n!=2 for k,n in groups.items() if k[0]=='dvdf'): errors.append('sample/mode/JDK lane cardinality')
    if sum(1 for k in groups if k[0]=='v2')!=4 or sum(1 for k in groups if k[0]=='v3')!=4: errors.append('retry fixture lane cardinality')
    for key,base in doc.get('reused_baselines',{}).items():
        if base.get('status')!='observed': errors.append('baseline not observed: '+key)
        if not base.get('execution',{}).get('sha256'): errors.append('baseline receipt not SHA-pinned: '+key)
        if key in ('retry-v2','retry-v3'):
            evidence=base.get('raw_evidence',[])
            originals=[x.get('record',{}) for x in evidence if x.get('kind')=='prior-lane' and x.get('family')=='original']
            if len(originals)!=4 or any(x.get('oracle_byte_match') is not True for x in originals): errors.append('pinned retry original oracle evidence incomplete: '+key)
            for family in ('jadx-default','jadx-none'):
                if sum(1 for x in evidence if x.get('kind')=='prior-lane' and x.get('family')==family)!=4: errors.append('pinned JADX evidence incomplete: '+key+'/'+family)
    if closure is not None and (not isinstance(closure,int) or closure<0): errors.append('invalid current source closure count')
    return errors

def check_retry_oracles(execution):
    """Confirm every original lane's recorded oracle result; do not assert JADX outcomes."""
    originals=[x for x in execution.get('lanes',[]) if x.get('family')=='original']
    expected={(m,j) for m in ('debug','none') for j in ('javac8','javac23')}
    actual={(x.get('mode'),x.get('jdk')) for x in originals}
    if actual!=expected or len(originals)!=4: return ['original lane cardinality']
    errors=[]
    if any(x.get('oracle_byte_match') is not True or x.get('runtime_state')!='ran' for x in originals): errors.append('original raw stdout differs from fixture oracle')
    return errors

def main():
    if len(sys.argv)!=2: raise SystemExit('usage: check.py execution.json')
    doc=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    errors=check_candidate(doc)
    if errors:
        for e in errors: print('FAIL:',e)
        return 1
    print('candidate receipt structure and safety checks passed')
    return 0
if __name__=='__main__': raise SystemExit(main())
