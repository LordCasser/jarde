#!/usr/bin/env python3
"""Stdlib-only checker tests against fixed baseline receipts and failure fixtures."""
import json, unittest
from pathlib import Path
import check

BASE=Path('/private/tmp')
class CheckerTests(unittest.TestCase):
    def test_current_closure_count_is_derived_not_legacy_literal(self):
        receipt={'source_closure_files':['a','b','c']}
        self.assertEqual(check.source_closure_count(receipt),3)
        self.assertEqual(check.source_closure_count({'source_closure_count':17}),17)
        self.assertIsNone(check.source_closure_count({}))
        receipt=json.loads((BASE/'jarde-loop-combined-focused-root-v5/execution.json').read_text())
        self.assertEqual(check.source_closure_count(receipt),len(receipt['source_manifest_before']))

    def test_v5_root_build_receipt_and_current_cli_are_independently_validated(self):
        receipt=BASE/'jarde-loop-combined-focused-root-v5/execution.json'
        doc=json.loads(receipt.read_text())
        candidate={'candidate_focused_receipt':check.pin(receipt),'candidate_cli':check.pin(doc['cli']['path']),
                   'candidate_source_closure_count':len(doc['source_manifest_after'])}
        self.assertEqual(check.check_root_build(candidate),[])

    def test_independently_accepted_default_jadx_adapter_has_exact_runner_only_prefix(self):
        receipt=json.loads((BASE/'jarde-loop-body-catch-default-package-root-v1/execution.json').read_text())
        candidate={'accepted_default_jadx_adapter':{'receipt':check.pin(BASE/'jarde-loop-body-catch-default-package-root-v1/execution.json'),
                  'status':receipt['status'],'source_tool_inputs_unchanged':receipt['source_tool_inputs_unchanged'],'lanes':receipt['lanes']}}
        self.assertEqual(check.check_default_adapter(candidate),[])

    def test_old_original_oracles_are_real_and_complete(self):
        for version in ('v2','v3'):
            doc=json.loads((BASE/f'jarde-loop-catch-retry-baseline-root-{version}-v1/execution.json').read_text())
            self.assertEqual(check.check_retry_oracles(doc),[],version)
            self.assertEqual(sum(1 for x in doc['lanes'] if x.get('family')=='jadx-default'),4)
            self.assertEqual(sum(1 for x in doc['lanes'] if x.get('family')=='jadx-none'),4)

    def test_compile_failure_never_runs_old_or_partial_class(self):
        doc={'schema':'jarde-loop-candidate-comparison-v1','status':'observed','source_tool_inputs_unchanged':True,'candidate_source_closure_count':17,
             'actual_candidate_lane_count':16,'commands':[{'label':f'x-{i}-render'} for i in range(16)],
             'candidate_lanes':[],'reused_baselines':{},'accepted_default_jadx_adapter':{'status':'observed','source_tool_inputs_unchanged':True,'lanes':[{}, {}, {}, {}]}}
        for version in ('v2','v3'):
            for mode in ('debug','none'):
                for jdk in ('javac8','javac23'):
                    doc['candidate_lanes'].append({'label':f'retry-{version}-{mode}-{jdk}','runtime_state':'no-runtime','original_oracle_byte_match':True,
                         'compile_run':{'compile':{'exit_code':1,'guard_stop':None},'run':None}})
        # Candidate matrix cardinality still must include four DV/DF source renders in each of four lanes.
        for mode in ('debug','none'):
            for jdk in ('javac8','javac23'):
                for cls in ('DF','DV'):
                    doc['candidate_lanes'].append({'label':f'dvdf-{mode}-{jdk}-{cls}','runtime_state':'no-runtime-until-joint-compile'})
        for mode in ('debug','none'):
            for jdk in ('javac8','javac23'):
                doc.setdefault('whole_class_runs',[]).append({'compile_run':{'compile':{'exit_code':1,'guard_stop':None},'run':None,'runtime_state':'no-runtime'},'stdout_comparison':{'byte_identical':False}})
        self.assertEqual(check.check_candidate(doc,verify_build=False,verify_adapter=False),[])
        doc['candidate_lanes'][0]['compile_run']['run']={'exit_code':0}
        self.assertTrue(any('runtime after failed' in e for e in check.check_candidate(doc,verify_build=False,verify_adapter=False)))

if __name__=='__main__': unittest.main()
