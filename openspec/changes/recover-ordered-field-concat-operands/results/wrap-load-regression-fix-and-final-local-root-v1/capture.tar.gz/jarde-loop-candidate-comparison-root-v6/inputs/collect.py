#!/usr/bin/env python3
"""Run candidate-only Jarde render/whole-class compile/runtime comparisons.

Original and JADX evidence is reused from fixed root-v4/v2/v3 receipts. All
candidate rendering and generated-source validation is performed in a fresh
output tree with the CLI and receipt supplied by argv.
"""
from __future__ import annotations
import datetime, hashlib, importlib.util, json, os, re, shutil, sys
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
HERE=Path(__file__).resolve().parent
JDK_MANIFEST=ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JADX=Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_JAR=Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
GUARD_PATH=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER_PATH=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
FOCUS_RUNNER=Path('/private/tmp/jarde-loop-focused-runner-root-v1.py')
FOCUS_RUNNER_SHA='7209ad1732c097e555c0cda2eba8ffa39ab55bf109616cfaac5f15a1bb749b9f'
FOCUS_MODULE=Path('/private/tmp/jarde-cf11-structured-list-focused-runner-prep-luna-v7/run.py')
FOCUS_MODULE_SHA='c8b1016eaf9506912876fd92e8544d5f78e472401beb99e3fd75b549607956bc'
CLOSURE_MODULE=Path('/private/tmp/jarde-iterator-assignment-full-validation-prep-luna-v2/workspace_runner.py')
CLOSURE_MODULE_SHA='63e52b55fe5d20d5f2ece98ac80676ccdb2de8dfd33d7199b688e075fb1e9673'
OLD={
 'dvdf-debug':Path('/private/tmp/jarde-loop-body-catch-baseline-debug-root-v4-v1/execution.json'),
 'dvdf-none':Path('/private/tmp/jarde-loop-body-catch-baseline-none-root-v4-v1/execution.json'),
 'retry-v2':Path('/private/tmp/jarde-loop-catch-retry-baseline-root-v2-v1/execution.json'),
 'retry-v3':Path('/private/tmp/jarde-loop-catch-retry-baseline-root-v3-v1/execution.json'),
}
DEFAULT_ADAPTER_RECEIPT=Path('/private/tmp/jarde-loop-body-catch-default-package-root-v1/execution.json')
FREE=5*1024**3; TARGET=1024**3; STRIP=('JAVA_HOME','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH')
SCHEMA='jarde-loop-candidate-comparison-v1'

def sha(b): return hashlib.sha256(b).hexdigest()
def pin(p):
 p=Path(p); b=p.read_bytes(); return {'path':str(p.resolve()),'bytes':len(b),'sha256':sha(b)}
def dump(p,v):
 Path(p).parent.mkdir(parents=True,exist_ok=True); Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=lambda value: str(value) if isinstance(value,Path) else (_ for _ in ()).throw(TypeError(type(value).__name__)))+'\n',encoding='utf-8')
def loadmod(path,name):
 spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def package_of(src):
 m=re.search(r'(?m)^\s*package\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*;',src)
 return m.group(1) if m else ''
def class_of(src):
 m=re.search(r'(?m)^\s*public\s+(?:(?:final|abstract|sealed|non-sealed)\s+)*class\s+([A-Za-z_$][\w$]*)\b',src)
 return m.group(1) if m else None
def old_doc(key):
 p=OLD[key]; d=json.loads(p.read_text());
 if d.get('status')!='observed' or d.get('source_tool_inputs_unchanged') is False: raise RuntimeError('old evidence is not observed/unchanged: '+key)
 return p,d
def baseline_pin_ref(path, expected=None):
 actual=pin(path)
 if expected and (actual['sha256']!=expected.get('sha256') or actual['bytes']!=expected.get('bytes')): raise RuntimeError('baseline raw/source pin mismatch: '+str(path))
 return actual
def verify_embedded_pins(value):
 """Verify every {path,bytes,sha256} object copied from a prior receipt."""
 if isinstance(value,dict):
  if all(k in value for k in ('path','bytes','sha256')) and isinstance(value.get('path'),str): baseline_pin_ref(Path(value['path']),value)
  for child in value.values(): verify_embedded_pins(child)
 elif isinstance(value,list):
  for child in value: verify_embedded_pins(child)
def raw_command_refs(execution,predicate):
 rows=[]
 for cmd in execution.get('commands',[]):
  if predicate(cmd.get('label','')):
   verify_embedded_pins(cmd.get('streams',{}))
   rows.append({'index':cmd.get('index'),'label':cmd.get('label'),'exit_code':cmd.get('exit_code'),'guard_stop':cmd.get('guard_stop'),'streams':cmd.get('streams')})
 return rows
def command(execution,label):
 for row in execution.get('commands',[]):
  if row.get('label')==label: return row
 raise RuntimeError('pinned baseline command missing: '+label)

def validate_build_receipt(cli,receipt,rdoc):
 """Accept only the root runner's cli/source-manifest/cleanup receipt contract."""
 if 'cli_freeze' in rdoc or rdoc.get('status')!='commands_passed_pending_independent_acceptance':
  raise RuntimeError('candidate focused receipt is not the current root-runner schema/status')
 cli_row=rdoc.get('cli')
 if not isinstance(cli_row,dict): raise RuntimeError('focused receipt lacks cli pin')
 actual_cli=pin(cli)
 if cli_row.get('path')!=str(cli) or cli_row.get('bytes')!=actual_cli['bytes'] or cli_row.get('sha256')!=actual_cli['sha256']:
  raise RuntimeError('focused receipt cli path/bytes/SHA does not match argv candidate')
 if (cli.stat().st_mode & 0o777)!=0o555: raise RuntimeError('candidate CLI must be immutable mode 0555')
 before=rdoc.get('source_manifest_before'); after=rdoc.get('source_manifest_after')
 if not isinstance(before,list) or not isinstance(after,list) or not before or not after:
  raise RuntimeError('focused receipt must carry complete source_manifest_before/after arrays')
 if {x.get('path') for x in before}!={x.get('path') for x in after}: raise RuntimeError('source manifest membership changed during root build')
 runner=rdoc.get('runner',{}); spec=rdoc.get('command_spec',{})
 for label,row in [('root runner',runner),('root command spec',spec)]:
  if not all(k in row for k in ('path','bytes','sha256')): raise RuntimeError(label+' pin incomplete')
  baseline_pin_ref(Path(row['path']),row)
 spec_argv=json.loads(Path(spec['path']).read_text(encoding='utf-8'))
 commands=rdoc.get('commands',[])
 normal=[x for x in commands if not x.get('cleanup_only')]
 if [x.get('argv') for x in normal]!=spec_argv: raise RuntimeError('root command receipt differs from pinned command spec')
 test_rows=[]; build_rows=[]; clean_rows=[]
 for row in commands:
  if row.get('exit_code')!=0 or row.get('guard_stop') is not None: raise RuntimeError('root build command failed or was guard-stopped')
  verify_embedded_pins(row.get('streams',{}))
  argv=row.get('argv',[])
  if argv[:2]==['cargo','test']:
   test_rows.append(row)
   raw=Path(row['streams']['stdout']['path']).read_text(encoding='utf-8',errors='replace')
   raw=re.sub(r'\x1b\[[0-9;]*m','',raw)
   summaries=[list(x) for x in re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)]
   if summaries!=row.get('actual_test_summaries'): raise RuntimeError('root test summaries do not match pinned raw stdout')
   if not summaries or any(s[0]!='ok' or int(s[1])<=0 or int(s[2])!=0 for s in summaries): raise RuntimeError('root test command lacks complete passing actual summaries')
  if argv[:2]==['cargo','build']: build_rows.append(row)
  if row.get('cleanup_only'): clean_rows.append(row)
 if not test_rows or not build_rows: raise RuntimeError('root receipt lacks test or build command')
 if len(clean_rows)!=1 or clean_rows[0].get('argv')!=['cargo','clean'] or clean_rows[0].get('exit_code')!=0: raise RuntimeError('root cleanup receipt is incomplete')
 if rdoc.get('target_absent') is not True: raise RuntimeError('root target is not recorded absent after cleanup')
 focus=loadmod(FOCUS_MODULE,'candidate_focused_source_manifest')
 closure=loadmod(CLOSURE_MODULE,'candidate_source_closure')
 focus.ROOT=ROOT; focus.CLOSURE_MODULE=closure; closure.ROOT=ROOT
 current=focus.source_manifest()
 if current!=after: raise RuntimeError('current workspace source closure differs from receipt source_manifest_after')
 return {'source_manifest_count':len(after),'source_manifest_before_count':len(before),'source_manifest_changed_paths':[a['path'] for a,b in zip(before,after) if a!=b],
         'root_commands':[{'index':x.get('index'),'argv':x.get('argv'),'exit_code':x.get('exit_code'),'guard_stop':x.get('guard_stop'),'actual_test_summaries':x.get('actual_test_summaries',[]),'streams':x.get('streams')} for x in commands],
         'cleanup_exit':clean_rows[0]['exit_code'],'target_absent':rdoc['target_absent'],
         'runner':runner,'command_spec':spec}

def validate_default_adapter_receipt():
 """Bind the prior independently observed default-package JADX Runner adaptation."""
 p=DEFAULT_ADAPTER_RECEIPT; d=json.loads(p.read_text(encoding='utf-8'))
 if d.get('schema')!='jarde-loop-body-catch-default-package-supplement-v1' or d.get('status')!='observed' or d.get('source_tool_inputs_unchanged') is not True:
  raise RuntimeError('default-package adapter receipt is not independently observed')
 verify_embedded_pins(d)
 for mode,key in [('debug','dvdf-debug'),('none','dvdf-none')]:
  expected=pin(OLD[key]); recorded=d.get('baseline_receipts',{}).get(mode,{})
  if recorded.get('path')!=expected['path'] or recorded.get('bytes')!=expected['bytes'] or recorded.get('sha256')!=expected['sha256']:
   raise RuntimeError('default-package adapter does not bind the exact '+mode+' original receipt')
 if d.get('actual_command_count')!=8 or len(d.get('lanes',[]))!=4: raise RuntimeError('default-package adapter lane/command set incomplete')
 original=d.get('original_runner',{}); derived=d.get('derived_runner',{})
 original_bytes=Path(original['path']).read_bytes(); derived_bytes=Path(derived['path']).read_bytes()
 if derived_bytes!=b'package defpackage;\n'+original_bytes: raise RuntimeError('default-package Runner adapter is not the exact permitted prefix')
 if original['sha256']!=pin(Path(OLD['dvdf-debug'].parent)/'inputs'/'Runner.java')['sha256']: raise RuntimeError('default-package adapter does not derive from pinned original Runner')
 expected={(m,j) for m in ('debug','none') for j in ('javac8','javac23')}
 seen=set()
 for lane in d['lanes']:
  key=(lane.get('mode'),lane.get('jdk')); seen.add(key)
  if key not in expected or lane.get('source_class_identities')!=['defpackage.DF','defpackage.DV'] or lane.get('runner_class_identity')!='defpackage.Runner':
   raise RuntimeError('default-package adapter lane identity mismatch')
  if lane.get('compile',{}).get('exit_code')!=0 or lane.get('compile',{}).get('guard_stop') is not None or lane.get('run',{}).get('exit_code')!=0 or lane.get('run',{}).get('guard_stop') is not None:
   raise RuntimeError('default-package adapter lane did not compile/run successfully')
  baseline=json.loads(OLD['dvdf-'+lane['mode']].read_text(encoding='utf-8'))
  expected_sources=[]
  for cls in ('DF','DV'):
   row=next(x for x in baseline['jadx'] if x.get('jdk')==lane['jdk'] and x.get('profile')=='default')
   src=next(x for x in row['sources'] if Path(x['path']).name==cls+'.java')
   expected_sources.append(src)
  if lane['sources'][:2]!=expected_sources: raise RuntimeError('adapter source pins differ from fixed default JADX outputs')
 if seen!=expected: raise RuntimeError('default-package adapter matrix incomplete')
 return {'receipt':pin(p),'schema':d['schema'],'status':d['status'],'derived_runner':derived,'derived_runner_rule':d.get('derived_runner_rule'),
         'lanes':d['lanes'],'commands':d['commands'],'source_tool_inputs_unchanged':d['source_tool_inputs_unchanged']}

def main():
 if len(sys.argv)!=4: raise SystemExit('usage: collect.py CANDIDATE_CLI FOCUSED_RECEIPT /private/tmp/FRESH_OUTPUT')
 cli,receipt,out=map(lambda x:Path(x).resolve(),sys.argv[1:])
 if not cli.is_file() or not os.access(cli,os.X_OK): raise SystemExit('candidate CLI missing or not executable')
 if (cli.stat().st_mode & 0o777)!=0o555: raise SystemExit('candidate CLI must be frozen at mode 0555')
 if not receipt.is_file(): raise SystemExit('candidate focused receipt missing')
 if out.exists(): raise SystemExit('refuse non-fresh output: '+str(out))
 cli_pin=pin(cli); receipt_pin=pin(receipt); rdoc=json.loads(receipt.read_text(encoding='utf-8'))
 build_evidence=validate_build_receipt(cli,receipt,rdoc)
 default_adapter=validate_default_adapter_receipt()
 prep=json.loads((HERE/'pins.json').read_text(encoding='utf-8'))
 if prep.get('schema')!='jarde-loop-candidate-comparison-pins-v2': raise SystemExit('preparation pins schema mismatch')
 for asset in prep.get('assets',[]):
  actual=pin(Path(asset['path']))
  if actual['bytes']!=asset['bytes'] or actual['sha256']!=asset['sha256']: raise SystemExit('preparation asset pin mismatch: '+asset['path'])
 for asset in prep.get('reused_baseline_receipts',[]):
  actual=pin(Path(asset['path']))
  if actual['bytes']!=asset['bytes'] or actual['sha256']!=asset['sha256']: raise SystemExit('baseline receipt pin mismatch: '+asset['path'])
 jm=json.loads(JDK_MANIFEST.read_text(encoding='utf-8')); legs={}
 for row in jm.get('legs',[]):
  name=row.get('leg'); tools=row.get('jdk_tools',{})
  if name not in ('javac8','javac23'): continue
  ps={n:Path(tools[n]['path']).resolve() for n in ('javac','java','javap')}
  for n,p in ps.items():
   if pin(p)['sha256']!=tools[n]['sha256']: raise RuntimeError('pinned JDK changed '+name+'/'+n)
  legs[name]={'tools':ps,'home':ps['java'].parent.parent,'pins':tools}
 if set(legs)!={'javac8','javac23'}: raise RuntimeError('pinned javac8/javac23 missing')
 guard=loadmod(GUARD_PATH,'candidate_guard'); scanner=loadmod(SCANNER_PATH,'candidate_scanner')
 out.mkdir(parents=True); (out/'raw').mkdir(); (out/'inputs').mkdir()
 guard.ROOT=ROOT; guard.OUT=out/'raw'; guard.ENV_VALUES={}; guard.expected_test_summaries=lambda i,s:None
 guard.target_bytes=lambda:scanner.target_bytes(ROOT)
 guard.command_stream=lambda p:{'path':str(Path(p).resolve()),'bytes':Path(p).stat().st_size,'sha256':sha(Path(p).read_bytes())}
 olddocs={}; oldpins={}
 for k,p in OLD.items():
  actual=pin(p); d=json.loads(p.read_text(encoding='utf-8'))
  if d.get('status')!='observed': raise RuntimeError('old evidence status not observed: '+k)
  olddocs[k]=d; oldpins[k]=actual
 tracked=[Path(__file__),HERE/'pins.json',cli,receipt,JDK_MANIFEST,JADX,JADX_JAR,GUARD_PATH,SCANNER_PATH,FOCUS_RUNNER,FOCUS_MODULE,CLOSURE_MODULE,DEFAULT_ADAPTER_RECEIPT,*OLD.values(),*legs['javac8']['tools'].values(),*legs['javac23']['tools'].values(),Path(build_evidence['runner']['path']),Path(build_evidence['command_spec']['path'])]
 tracked.extend(HERE/x for x in ['RetryFixture-v2.java','Runner-v2.java','RetryFixture-v3.java','Runner-v3.java','Runner-dvdf.java','fixture-manifest-v2.json','fixture-manifest-v3.json','check.py','test_check.py','README.md'])
 before=[pin(p) for p in tracked]
 for p in tracked:
  if p.parent==HERE and p.is_file(): shutil.copyfile(p,out/'inputs'/p.name)
 doc={'schema':SCHEMA,'status':'running','candidate_cli':cli_pin,'candidate_focused_receipt':receipt_pin,'candidate_focused_build':build_evidence,
      'accepted_default_jadx_adapter':default_adapter,
      'candidate_source_closure_count':build_evidence['source_manifest_count'],
      'candidate_source_closure_evidence':'current workspace source closure exactly equals candidate focused receipt source_manifest_after; count is derived dynamically, with no legacy count assumed',
      'jdk_legs':legs,'tool_pins':{k:pin(p) for k,p in [('jdk_manifest',JDK_MANIFEST),('jadx',JADX),('jadx_jar',JADX_JAR),('guard',GUARD_PATH),('scanner',SCANNER_PATH)]},
      'resource_guard':{'minimum_free_bytes':FREE,'maximum_target_bytes':TARGET,'sample_interval_seconds':1,'process_group_termination':True},
      'reused_baselines':{},'commands':[],'candidate_lanes':[],'source_tool_pins_before':before}
 for k,p in OLD.items(): doc['reused_baselines'][k]={'execution':oldpins[k],'schema':olddocs[k].get('schema'),'status':olddocs[k].get('status'),'raw_evidence':[]}
 dump(out/'execution.json',doc)
 def run(label,argv,home):
  idx=len(doc['commands'])+1; env={k:v for k,v in os.environ.items() if k not in STRIP}; env['JAVA_HOME']=str(home); env['PATH']=str(home/'bin')+os.pathsep+env.get('PATH','')
  row={'index':idx,'label':label,'argv':[str(x) for x in argv],'cwd':str(ROOT),'java_home':str(home),'state':'started','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}; doc['commands'].append(row); dump(out/'execution.json',doc)
  res=guard.run_command(idx,row['argv'],env); row.update(res); row['label']=label; row['state']='guard-stopped' if row.get('guard_stop') else 'observed'
  for stream,m in row.get('streams',{}).items():
   p=Path(m['path']); m.update(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
  dump(out/'execution.json',doc)
  if row.get('guard_stop'): raise RuntimeError('guard stopped '+label)
  return row,Path(row['streams']['stdout']['path']).read_bytes(),Path(row['streams']['stderr']['path']).read_bytes()
 def compile_run(label,sources,leg,mode,classdir,runner_name):
  classdir.mkdir(parents=True); empty=classdir.parent/'empty-paths'; empty.mkdir()
  flags=['-source','8','-target','8','-Xlint:-options'] if leg=='javac8' else ['--release','8']
  comp,_,_=run(label+'-compile',[legs[leg]['tools']['javac'],*flags,'-proc:none','-g' if mode=='debug' else '-g:none','-classpath',empty,'-sourcepath',empty,'-d',classdir,*sources],legs[leg]['home'])
  ran=None; ob=b''; eb=b''
  if comp.get('exit_code')==0 and not comp.get('guard_stop'):
   ran,ob,eb=run(label+'-run',[legs[leg]['tools']['java'],'-Xverify:all','-cp',classdir,runner_name],legs[leg]['home'])
  files=sorted(classdir.rglob('*.class'))
  return {'compile':comp,'run':ran,'runtime_state':'ran' if ran and ran.get('exit_code') is not None and not ran.get('guard_stop') else 'no-runtime','class_paths':[p.relative_to(classdir).as_posix() for p in files],'classes':[pin(p) for p in files]},ob,eb
 def adapt_runner(srcpath,package,target):
  text=srcpath.read_text(encoding='utf-8'); target.parent.mkdir(parents=True,exist_ok=True)
  # Existing package line is never expected; only adapt the independent Runner copy.
  if package and not re.match(r'(?m)^\s*package\s+',text): text='package '+package+';\n'+text
  target.write_text(text,encoding='utf-8'); return target,((package+'.Runner') if package else 'Runner')
 def render_class(label,cf,class_name,leg,mode,runner_src,compile_dir,compile_single=True):
  folder=out/'candidate'/label; folder.mkdir(parents=True,exist_ok=True)
  cmd,raw,err=run(label+'-render',[cli,'class-source','--input',cf,'--class',class_name,'--policy','single-class','--release','8','--format','json','--evidence','all'],legs[leg]['home'])
  rawfile=folder/'response.raw.json'; rawfile.write_bytes(raw)
  item={'label':label,'class':class_name,'jdk':leg,'mode':mode,'render_command':cmd,'raw_response':pin(rawfile),'stderr_sha256':sha(err),'methods':[],'runtime_state':'no-runtime'}
  if cmd.get('exit_code')==0 and not cmd.get('guard_stop'):
   jd=json.loads(raw.decode('utf-8')); src=folder/(class_name+'.java'); src.write_text(jd['text'],encoding='utf-8'); dump(folder/'report.json',jd)
   item.update(source=pin(src),report=pin(folder/'report.json'),class_identity=jd.get('class'),outcome=jd.get('outcome'),execution=jd.get('execution'))
   maps=[]
   for m in jd.get('methods',[]):
    it=m.get('item',{}); ident=it.get('identity',{}); rep=m.get('outcome',{}).get('report',{})
    name=it.get('name',{}); descriptor=it.get('descriptor',{})
    row={'declaration':m.get('declaration'),'item':it,'identity':ident,'name':name,'name_escaped':name.get('escaped') if isinstance(name,dict) else None,
      'descriptor':descriptor,'descriptor_escaped':descriptor.get('escaped') if isinstance(descriptor,dict) else None,
      'identity_name_bytes':ident.get('name'),'identity_descriptor_bytes':ident.get('descriptor'),
      'method_outcome_kind':m.get('outcome',{}).get('kind'),'report_outcome':rep.get('outcome'),'compile_status':rep.get('compile_status'),'syntax_status':rep.get('syntax_status'),'source_map':rep.get('source_map'),'diagnostics':rep.get('diagnostics',[])}
    item['methods'].append(row); maps.append(row)
   dump(folder/'wholeclass-source-maps.json',{'class':jd.get('class'),'methods':maps}); item['source_maps']=pin(folder/'wholeclass-source-maps.json')
   package=package_of(jd['text']); source_class=class_of(jd['text'])
   item.update(source_package=package,source_class=source_class)
   if compile_single:
    adapter,runclass=adapt_runner(runner_src,package,out/'inputs'/'derived-runner'/label/'Runner.java')
    sources=[src,adapter]
    rec,ob,eb=compile_run(label,sources,leg,mode,compile_dir,runclass)
    item.update(compile_run=rec,runtime_state=rec['runtime_state'],derived_runner=pin(adapter),runner_identity=runclass,stdout_sha256=sha(ob),stderr_sha256=sha(eb))
   else:
    item.update(compile_strategy='whole-class-only',runtime_state='no-runtime-until-joint-compile')
  return item
 # Pin and reference old evidence without executing or rewriting it.
 def ref_raw(group,path,expected=None): return baseline_pin_ref(path,expected)
 # DV/DF: four lanes; retain original/JADX references from debug/none v4 receipts.
 for mode,key in [('debug','dvdf-debug'),('none','dvdf-none')]:
  bp,bd=old_doc(key)
  for leg in ('javac8','javac23'):
   oldorig=bd['original'][leg]; oldclassdir=Path(OLD[key].parent)/'legs'/leg/'original'/'classes'
   verify_embedded_pins(oldorig)
   doc['reused_baselines'][key]['raw_evidence'].append({'kind':'original-lane','jdk':leg,'record':oldorig,'commands':raw_command_refs(bd,lambda label: label.startswith(leg+'-original'))})
   for cls in ('DF','DV'):
    cf=oldclassdir/(cls+'.class')
    expected=next((x for x in oldorig.get('classes',[]) if Path(x['path']).name==cls+'.class'),None)
    if not cf.is_file(): raise RuntimeError('fixed baseline class missing '+str(cf))
    cp=ref_raw(key,cf,expected)
    doc['reused_baselines'][key]['raw_evidence'].append({'kind':'original-class','class':cls,'jdk':leg,'pin':cp})
   whole=[]
   for cls in ('DF','DV'):
    # Run Jarde per exact original compiler output and keep each method's complete evidence.
    item=render_class(f'dvdf-{mode}-{leg}-{cls}',oldclassdir/(cls+'.class'),cls,leg,mode,HERE/'Runner-dvdf.java',out/'candidate/render-only'/mode/leg/cls/'unused',compile_single=False)
    doc['candidate_lanes'].append(item); dump(out/'execution.json',doc)
    if 'source' in item: whole.append(Path(item['source']['path']))
   oldcmd=command(bd,f'{leg}-original-run'); original=Path(oldcmd['streams']['stdout']['path']).read_bytes()
   if len(whole)==2:
    # Whole-class compilation uses generated DF/DV together and the unchanged baseline Runner.
    source_packages=[]; source_classes=[]
    for cls in ('DF','DV'):
     row=next(x for x in doc['candidate_lanes'] if x['label']==f'dvdf-{mode}-{leg}-{cls}')
     source_packages.append(row.get('source_package')); source_classes.append(row.get('source_class'))
    if source_classes!=['DF','DV'] or len(set(source_packages))!=1:
     rec={'compile':None,'run':None,'runtime_state':'no-runtime: generated packages/classes do not form one Runner lane','class_paths':[],'classes':[]}; ob=eb=b''; adapter=None; runclass=None
    else:
     package=source_packages[0]; adapter,runclass=adapt_runner(HERE/'Runner-dvdf.java',package,out/'inputs'/'derived-runner'/f'dvdf-whole-{mode}-{leg}'/'Runner.java')
     rec,ob,eb=compile_run(f'dvdf-whole-{mode}-{leg}',[*whole,adapter],leg,mode,out/'candidate/whole-dvdf'/mode/leg/'classes',runclass)
    doc.setdefault('whole_class_runs',[]).append({'sample':'DV/DF','mode':mode,'jdk':leg,'compile_run':rec,'stdout_sha256':sha(ob),'stderr_sha256':sha(eb),
      'derived_runner':pin(adapter) if adapter else None,'runner_identity':runclass,
      'stdout_comparison':{'original_sha256':sha(original),'candidate_sha256':sha(ob),'byte_identical':rec['runtime_state']=='ran' and ob==original}})
   else:
    doc.setdefault('whole_class_runs',[]).append({'sample':'DV/DF','mode':mode,'jdk':leg,
      'compile_run':{'compile':None,'run':None,'runtime_state':'no-runtime: one or both candidate whole-class sources unavailable','class_paths':[],'classes':[]},
      'stdout_comparison':{'original_sha256':sha(original),'candidate_sha256':None,'byte_identical':False},'derived_runner':None,'runner_identity':None})
   for oldlane in bd.get('jadx',[]):
    if oldlane.get('jdk')==leg:
     # Legacy v4 stores exact generated source file pins; summarize their SHA without rerunning JADX.
     verify_embedded_pins(oldlane)
     decompiler=command(bd,oldlane['command'])
     verify_embedded_pins(decompiler.get('streams',{}))
     doc['reused_baselines'][key]['raw_evidence'].append({'kind':'jadx','class':oldlane.get('class'),'profile':oldlane.get('profile'),'lane':oldlane,
       'command':{'index':decompiler.get('index'),'label':decompiler.get('label'),'exit_code':decompiler.get('exit_code'),'streams':decompiler.get('streams')}})
   for physical in bd.get('javap',[]):
    if physical.get('jdk')==leg:
     verify_embedded_pins(physical)
     doc['reused_baselines'][key]['raw_evidence'].append({'kind':'original-javap','class':physical.get('class'),'jdk':leg,'record':physical})
   adapter_lane=next(x for x in default_adapter['lanes'] if x.get('mode')==mode and x.get('jdk')==leg)
   doc['reused_baselines'][key]['raw_evidence'].append({'kind':'accepted-jadx-default-package-adapter','receipt':default_adapter['receipt'],
      'runner':default_adapter['derived_runner'],'lane':adapter_lane})
   dump(out/'execution.json',doc)
 # Retry v2/v3: eight lanes (4 per fixture version), candidate render/compile/run only.
 for version in ('v2','v3'):
  key='retry-'+version; bp,bd=old_doc(key); fixture=HERE/f'RetryFixture-{version}.java'; runner=HERE/f'Runner-{version}.java'
  manifest=json.loads((HERE/f'fixture-manifest-{version}.json').read_text(encoding='utf-8'))
  for mode in ('debug','none'):
   for leg in ('javac8','javac23'):
    oldlane=next(x for x in bd['lanes'] if x.get('family')=='original' and x.get('mode')==mode and x.get('jdk')==leg)
    verify_embedded_pins(oldlane)
    cf=Path(OLD[key].parent)/'legs'/mode/leg/'original'/'classes'/'RetryFixture.class'
    cp=ref_raw(key,cf,next(x for x in oldlane.get('classes',[]) if Path(x['path']).name=='RetryFixture.class'))
    doc['reused_baselines'][key]['raw_evidence'].append({'kind':'original-class','mode':mode,'jdk':leg,'pin':cp,'oracle_byte_match':oldlane.get('oracle_byte_match'),'stdout_sha256':oldlane.get('stdout_sha256')})
    # Pin prior original/JADX lane records and outputs. No outcome is inferred for candidate.
    for oldj in bd['lanes']:
     if oldj.get('mode')==mode and oldj.get('jdk')==leg and oldj.get('family') in ('original','jadx-default','jadx-none'):
      verify_embedded_pins(oldj)
      family=oldj.get('family'); prefix='original-' if family=='original' else ('jadx-default-' if family=='jadx-default' else 'jadx-none-')
      token=mode+'/'+leg
      cmds=raw_command_refs(bd,lambda label,prefix=prefix,token=token: label.startswith(prefix) and token in label)
      doc['reused_baselines'][key]['raw_evidence'].append({'kind':'prior-lane','family':family,'mode':mode,'jdk':leg,'record':oldj,'commands':cmds})
    item=render_class(f'retry-{version}-{mode}-{leg}',cf,'RetryFixture',leg,mode,runner,out/'candidate/compile/retry'/version/mode/leg/'classes',compile_single=True)
    # Validate the fixture's original stdout against the manifest-defined oracle byte stream.
    expected='\n'.join(manifest['oracle_stdout'])+'\n' if isinstance(manifest.get('oracle_stdout'),list) else None
    item['original_oracle_byte_match']=oldlane.get('oracle_byte_match')
    item['expected_original_stdout_sha256']=oldlane.get('stdout_sha256')
    oldcmd=command(bd,f'original-{mode}/{leg}-run'); original_stdout=Path(oldcmd['streams']['stdout']['path']).read_bytes()
    item['stdout_comparison']={'original_sha256':sha(original_stdout),'candidate_sha256':item.get('stdout_sha256'),
      'byte_identical':item.get('runtime_state')=='ran' and item.get('stdout_sha256')==sha(original_stdout)}
    item['fixture_oracle_cases']=manifest.get('oracle',[])
    doc['candidate_lanes'].append(item); dump(out/'execution.json',doc)
 # Snapshot check and final receipt.
 after=[pin(p) for p in tracked]; doc['source_tool_pins_after']=after; doc['source_tool_inputs_unchanged']=before==after
 doc['actual_command_count']=len(doc['commands']); doc['actual_candidate_lane_count']=len(doc['candidate_lanes'])
 doc['status']='observed' if doc['source_tool_inputs_unchanged'] else 'failed'
 if not doc['source_tool_inputs_unchanged']: doc['failure']={'type':'SourcePinChanged','message':'CLI, receipt, JDK, guard, fixture or baseline changed during run'}
 dump(out/'execution.json',doc)
 return 0 if doc['status']=='observed' else 1

if __name__=='__main__':
 try: raise SystemExit(main())
 except SystemExit: raise
 except BaseException as exc:
  if len(sys.argv)==4:
   p=Path(sys.argv[3]).resolve()/'execution.json'
   if p.is_file():
    try:
     d=json.loads(p.read_text()); d['status']='failed'; d['failure']={'type':type(exc).__name__,'message':str(exc),'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}; dump(p,d)
    except BaseException: pass
  raise
