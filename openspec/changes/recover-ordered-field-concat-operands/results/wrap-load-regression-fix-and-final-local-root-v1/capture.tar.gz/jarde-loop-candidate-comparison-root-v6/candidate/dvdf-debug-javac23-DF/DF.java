// jarde: presentation of `DF` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class DF extends java.lang.Object {
    public DF() {
        // @method <init>()V
        // @declaration a constructor of `DF`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int defaultFirst(int x) {
        // @method defaultFirst(I)I
        // @declaration a static method of `DF`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        switch (x) {
            case 1:
                return 10;
            case 2:
                return 20;
            default:
                return 0;
        }
    }

    static int defaultFallthrough(int x) {
        // @method defaultFallthrough(I)I
        // @declaration a static method of `DF`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        switch (x) {
            case 1:
                return 100;
            case 2:
            default:
                return 200;
        }
    }

    static int loopCatch(int[] xs) {
        // @method loopCatch([I)I
        // @declaration a static method of `DF`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int good;
        int[] local2;
        good = 0;
        local2 = xs;
        for (int x : local2) {
            try {
                if (x < 0) {
                    throw new java.lang.IllegalArgumentException("neg");
                } else {
                    good = good + x;
                }
            } catch (java.lang.IllegalArgumentException e) {
                good = good - 1;
            }
        }
        return good;
    }

    static int loopFinally(int[] xs) {
        // @method loopFinally([I)I
        // @declaration a static method of `DF`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int c;
        int[] local2;
        int local3;
        int local4;
        c = 0;
        local2 = xs;
        local3 = local2.length;
        for (local4 = 0; local4 < local3; local4 = local4 + 1) {
            int x = local2[local4];
            if (x == 3) {
                c = c + 1000;
            } else {
                c = c + x;
                c = c + 1000;
            }
        }
        return c;
        // @bytecode 51 53 59 61
        // 1 live block(s) are reachable only through edges the normal-flow view leaves out: [51]
    }

    public static void main(java.lang.String[] a) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `DF`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.io.PrintStream saved0 = java.lang.System.out;
        java.lang.StringBuilder saved1 = new java.lang.StringBuilder().append("").append(defaultFirst(1)).append("/").append(defaultFirst(9)).append("/").append(defaultFallthrough(1)).append("/").append(defaultFallthrough(2)).append("/").append(defaultFallthrough(9)).append("/");
        java.lang.StringBuilder saved2 = saved1.append(loopCatch(new int[]{1, -2, 3})).append("/");
        saved0.println((java.lang.String) saved2.append(loopFinally(new int[]{3, 4})).toString());
        return;
    }
}
