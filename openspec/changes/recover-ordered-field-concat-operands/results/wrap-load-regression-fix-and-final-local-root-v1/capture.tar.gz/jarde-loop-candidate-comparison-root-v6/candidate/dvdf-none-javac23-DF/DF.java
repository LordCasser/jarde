// jarde: presentation of `DF` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class DF extends java.lang.Object {
    public DF() {
        // @method <init>()V
        // @declaration a constructor of `DF`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int defaultFirst(int arg0) {
        // @method defaultFirst(I)I
        // @declaration a static method of `DF`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        switch (arg0) {
            case 1:
                return 10;
            case 2:
                return 20;
            default:
                return 0;
        }
    }

    static int defaultFallthrough(int arg0) {
        // @method defaultFallthrough(I)I
        // @declaration a static method of `DF`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        switch (arg0) {
            case 1:
                return 100;
            case 2:
            default:
                return 200;
        }
    }

    static int loopCatch(int[] arg0) {
        // @method loopCatch([I)I
        // @declaration a static method of `DF`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int local1;
        int[] local2;
        local1 = 0;
        local2 = arg0;
        for (int local5 : local2) {
            try {
                if (local5 < 0) {
                    throw new java.lang.IllegalArgumentException("neg");
                } else {
                    local1 = local1 + local5;
                }
            } catch (java.lang.IllegalArgumentException local6) {
                local1 = local1 - 1;
            }
        }
        return local1;
    }

    static int loopFinally(int[] arg0) {
        // @method loopFinally([I)I
        // @declaration a static method of `DF`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int local1;
        int[] local2;
        int local3;
        int local4;
        local1 = 0;
        local2 = arg0;
        local3 = local2.length;
        for (local4 = 0; local4 < local3; local4 = local4 + 1) {
            int local5 = local2[local4];
            if (local5 == 3) {
                local1 = local1 + 1000;
            } else {
                local1 = local1 + local5;
                local1 = local1 + 1000;
            }
        }
        return local1;
        // @bytecode 51 53 59 61
        // 1 live block(s) are reachable only through edges the normal-flow view leaves out: [51]
    }

    public static void main(java.lang.String[] arg0) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `DF`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.io.PrintStream saved0 = java.lang.System.out;
        java.lang.StringBuilder saved1 = new java.lang.StringBuilder().append("").append(defaultFirst(1)).append("/").append(defaultFirst(9)).append("/").append(defaultFallthrough(1)).append("/").append(defaultFallthrough(2)).append("/").append(defaultFallthrough(9)).append("/");
        java.lang.StringBuilder saved2 = saved1.append(loopCatch(new int[]{1, -2, 3})).append("/");
        saved0.println((java.lang.String) saved2.append(loopFinally(new int[]{3, 4})).toString());
        return;
    }
}
