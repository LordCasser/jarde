// jarde: presentation of `DV` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class DV extends java.lang.Object {
    public DV() {
        // @method <init>()V
        // @declaration a constructor of `DV`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int plainFor(int[] xs) {
        // @method plainFor([I)I
        // @declaration a static method of `DV`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int g;
        int i;
        g = 0;
        for (i = 0; i < xs.length; i = i + 1) {
            try {
                if (xs[i] < 0) {
                    throw new java.lang.IllegalArgumentException("n");
                } else {
                    g = g + xs[i];
                }
            } catch (java.lang.IllegalArgumentException e) {
                g = g - 1;
            }
        }
        return g;
    }

    static int whileLoop(int[] xs) {
        // @method whileLoop([I)I
        // @declaration a static method of `DV`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int g;
        int i;
        g = 0;
        for (i = 0; i < xs.length; i = i + 1) {
            try {
                if (xs[i] < 0) {
                    throw new java.lang.IllegalArgumentException("n");
                } else {
                    g = g + xs[i];
                }
            } catch (java.lang.IllegalArgumentException e) {
                g = g - 1;
            }
        }
        return g;
    }

    static int forEach(int[] xs) {
        // @method forEach([I)I
        // @declaration a static method of `DV`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int g;
        int[] local2;
        g = 0;
        local2 = xs;
        for (int x : local2) {
            try {
                g = g + x;
            } catch (java.lang.Exception e) {
                g = g - 1;
            }
        }
        return g;
    }

    static int loopNoTry(int[] xs) {
        // @method loopNoTry([I)I
        // @declaration a static method of `DV`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int g;
        int[] local2;
        g = 0;
        local2 = xs;
        for (int x : local2) {
            if (x < 0) {
                g = g - 1;
            } else {
                g = g + x;
            }
        }
        return g;
    }

    public static void main(java.lang.String[] a) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `DV`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.io.PrintStream saved0 = java.lang.System.out;
        java.lang.StringBuilder saved1 = new java.lang.StringBuilder().append("");
        java.lang.StringBuilder saved2 = saved1.append(plainFor(new int[]{1, -2, 3})).append("/");
        java.lang.StringBuilder saved3 = saved2.append(whileLoop(new int[]{1, -2, 3})).append("/");
        java.lang.StringBuilder saved4 = saved3.append(forEach(new int[]{1, 2})).append("/");
        saved0.println((java.lang.String) saved4.append(loopNoTry(new int[]{1, -2, 3})).toString());
        return;
    }
}
