#!/usr/bin/env python3
"""Read-only independent census of staged class fixture additions vs HEAD."""
from __future__ import annotations
import hashlib, json, pathlib, struct, subprocess, sys
ROOT = pathlib.Path('/Users/lordcasser/workspace/projects/jarde')
OUT = pathlib.Path('/private/tmp/jarde-reader-census-audit-luna-v1/census.json')
def git(*args: str, data: bytes | None = None) -> bytes:
    p = subprocess.run(['git', *args], cwd=ROOT, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    return p.stdout
def digest(b: bytes) -> str: return hashlib.sha256(b).hexdigest()
def need(condition, message):
    if not condition: raise ValueError(message)
def u1(b, o): return b[o], o+1
def u2(b, o): return struct.unpack_from('>H', b, o)[0], o+2
def u4(b, o): return struct.unpack_from('>I', b, o)[0], o+4
def parse_class(b: bytes):
    need=lambda c,m: (_ for _ in ()).throw(ValueError(m)) if not c else None
    need(b[:4] == b'\xca\xfe\xba\xbe', 'bad class magic')
    cp_count, o = u2(b, 8); cp=[None]*cp_count; i=1
    while i<cp_count:
        tag,o=u1(b,o)
        if tag==1:
            n,o=u2(b,o); cp[i]=b[o:o+n].decode('utf-8','replace'); o+=n
        elif tag in (3,4): o+=4
        elif tag in (5,6): o+=8; i+=1
        elif tag in (7,8,16,19,20): o+=2
        elif tag in (9,10,11,12,17,18): o+=4
        elif tag==15: o+=3
        else: raise ValueError(f'unknown cp tag {tag} at {i}')
        need(o<=len(b), 'truncated constant pool'); i+=1
    # access, this, super, interfaces
    o+=6; n,o=u2(b,o); o+=2*n
    # fields
    n,o=u2(b,o)
    def attrs(o,n):
        out=[]
        for _ in range(n):
            ni,o=u2(b,o); ln,o=u4(b,o); out.append((cp[ni], b[o:o+ln])); o+=ln
        return out,o
    for _ in range(n):
        o+=6; ac,o=u2(b,o); _,o=attrs(o,ac)
    methods, o=u2(b,o); bodies=handlers=targets=jsr=0; method_rows=[]
    for _ in range(methods):
        access,o=u2(b,o); name_i,o=u2(b,o); desc_i,o=u2(b,o); ac,o=u2(b,o); aa,o=attrs(o,ac)
        for aname,ab in aa:
            if aname!='Code': continue
            bodies+=1; q=0
            max_stack,q=u2(ab,q); max_locals,q=u2(ab,q); code_len,q=u4(ab,q)
            code=ab[q:q+code_len]; q+=code_len
            eh,q=u2(ab,q); handlers+=eh; q+=8*eh
            nested,q=u2(ab,q)
            for _a in range(nested):
                _,q=u2(ab,q); ln,q=u4(ab,q); q+=ln
            need(q==len(ab), 'Code attribute trailing bytes')
            starts=set(); branch=[]; pc=0
            while pc<len(code):
                start=pc; starts.add(start); op=code[pc]; pc+=1
                if 0x99<=op<=0xa8 or op in (0xc6,0xc7):
                    off=struct.unpack_from('>h',code,pc)[0]; branch.append((start,start+off)); pc+=2
                    if op in (0xa8,): jsr+=1
                elif op in (0xc8,0xc9):
                    off=struct.unpack_from('>i',code,pc)[0]; branch.append((start,start+off)); pc+=4
                    if op==0xc9: jsr+=1
                elif op==0xaa:
                    pad=(-pc)%4; pc+=pad
                    default,low,high=struct.unpack_from('>iii',code,pc); pc+=12
                    branch.append((start,start+default));
                    for _k in range(high-low+1):
                        off=struct.unpack_from('>i',code,pc)[0]; pc+=4; branch.append((start,start+off))
                elif op==0xab:
                    pad=(-pc)%4; pc+=pad
                    default,np=struct.unpack_from('>ii',code,pc); pc+=8; branch.append((start,start+default))
                    for _k in range(np):
                        key,off=struct.unpack_from('>ii',code,pc); pc+=8; branch.append((start,start+off))
                elif op==0xc4:
                    widened=code[pc]; pc+=1; pc+=4 if widened==0x84 else 2
                else:
                    lens={0x10:1,0x11:2,0x12:1,0x13:2,0x14:2,
                    **{x:1 for x in range(0x15,0x1a)}, **{x:1 for x in range(0x36,0x3b)},
                    0x84:2, **{x:2 for x in range(0x99,0xa9)},
                    **{x:2 for x in range(0xb2,0xb9)}, 0xb9:4,0xba:4,0xbb:2,0xbc:1,0xbd:2,0xc0:2,0xc1:2,0xc5:3,0xc6:2,0xc7:2}
                    pc+=lens.get(op,0)
                need(pc<=len(code), f'instruction {op:02x} overruns Code')
            need(pc==len(code), 'Code stream not fully decoded')
            for s,t in branch:
                need(t in starts, f'bad branch target {s}->{t}')
            targets+=len(branch)
            method_rows.append({'name':cp[name_i],'descriptor':cp[desc_i],'handlers':eh,'branch_targets':len(branch),'jsr':sum(1 for s,t in branch if code[s] in (0xa8,0xc9))})
    # class attributes (not relevant to method census, still require exact class consumption)
    ac,o=u2(b,o); _,o=attrs(o,ac); need(o==len(b),'class trailing bytes')
    return {'bodies':bodies,'handlers':handlers,'branch_targets':targets,'jsr':jsr,'methods':method_rows}
# Added staged .class paths; only fixture-tree additions enter census.
staged=git('diff','--cached','--name-status','-z','--diff-filter=A','--','*.class').split(b'\0')
added=[]
for i in range(0,len(staged)-1,2):
    status,path=staged[i],staged[i+1]
    if status==b'A' and path.startswith(b'tests/fixtures/') and path.endswith(b'.class'):
        added.append(path.decode())
added.sort()
need(len(added)==23, f'expected 23 staged fixture class additions, saw {len(added)}')
# HEAD class path/blob inventory, with original bytes streamed from git cat-file.
entries=git('ls-tree','-r','-z','--full-tree','HEAD','--','tests/fixtures').split(b'\0')
head=[]
for row in entries:
    if not row: continue
    meta,path=row.split(b'\t',1); mode,typ,oid=meta.split()
    if path.endswith(b'.class'):
        head.append((path.decode(),oid.decode()))
need(len(head)==1140, f'expected 1140 HEAD fixture classes, saw {len(head)}')
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
for path,oid in head: proc.stdin.write(oid.encode()+b'\n')
proc.stdin.close(); old_checks=[]
for path,oid in head:
    hdr=proc.stdout.readline().split(); need(len(hdr)==3 and hdr[1]==b'blob',f'bad git object header for {path}')
    size=int(hdr[2]); old=proc.stdout.read(size); proc.stdout.read(1)
    live=(ROOT/path).read_bytes(); need(live==old, f'HEAD class bytes changed: {path}')
    old_checks.append({'path':path,'blob':oid,'sha256':digest(old)})
err=proc.stderr.read(); rc=proc.wait(); need(rc==0 and not err, 'git cat-file stream failed')
# Parse additions; partition by top fixture family.
families={}
for path in added:
    b=(ROOT/path).read_bytes(); counts=parse_class(b)
    parts=path.split('/'); family=parts[2] if len(parts)>2 else 'unknown'
    row={'path':path,'sha256':digest(b),**{k:v for k,v in counts.items() if k!='methods'},'methods':counts['methods']}
    fam=families.setdefault(family,{'classes':0,'bodies':0,'handlers':0,'branch_targets':0,'jsr':0,'files':[]})
    fam['classes']+=1
    for k in ('bodies','handlers','branch_targets','jsr'): fam[k]+=counts[k]
    fam['files'].append(row)
totals={k:sum(v[k] for v in families.values()) for k in ('classes','bodies','handlers','branch_targets','jsr')}
need(totals=={'classes':23,'bodies':139,'handlers':27,'branch_targets':138,'jsr':0},f'unexpected aggregate delta: {totals}')
result={'schema':'jarde-reader-census-audit-v1','head_commit':git('rev-parse','HEAD').decode().strip(),'head_class_count':len(head),'head_old_class_bytes_unchanged':True,'head_old_class_inventory_sha256':digest('\n'.join(f'{p} {o} {next(x["sha256"] for x in old_checks if x["path"]==p)}' for p,o in head).encode()),'added_paths_sha256':digest('\n'.join(added).encode()),'added_class_count':len(added),'added_class_paths':added,'families':families,'delta':totals,'head_old_classes_verified':len(old_checks)}
OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:result[k] for k in ('head_commit','head_class_count','head_old_class_bytes_unchanged','head_old_classes_verified','added_class_count','families','delta','added_paths_sha256')},indent=2))
