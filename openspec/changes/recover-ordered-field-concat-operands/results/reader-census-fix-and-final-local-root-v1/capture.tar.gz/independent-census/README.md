# Reader fixture census audit

This is a read-only independent measurement of the workspace-v8 `jarde-reader` census mismatch. It does not run Cargo or any Java/JADX/CLI tool and does not edit the shared checkout.

`audit_census.py` reads staged added `.class` paths from Git, parses each classfile's method Code attributes, exception tables, branch/switch target encodings and `jsr` opcodes, and verifies each target is an instruction boundary. It streams every HEAD `.class` blob with `git cat-file --batch` and byte-compares all 1,140 originals against the working tree. It writes detailed per-file/per-method results to `census.json`; rerun only when a fresh read-only census is needed.

Measured staged delta: 23 classes, 139 Code bodies, 27 handler records, 138 branch/switch targets, zero `jsr`. Families: patrol `2/12/7/30/0`; negative-load `1/3/0/0/0`; p3 loop-body-catch `4/24/12/60/0`; retry `8/24/8/40/0`; ordered-field-concat `8/76/0/8/0` (classes/bodies/handlers/targets/jsr). All 1,140 HEAD class paths had identical bytes.

`v8-evidence.json` binds the original record 93 receipt and raw streams. It records 177 passing tests, the sole failed census test, and successful `cargo clean` with target absent; raw logs remain at the original v8 paths. No test was rerun here.

`suggested.patch` is the deliberately minimal source proposal: clarify that 828 is a historical checkpoint, add one current ledger comment, and update only the final expected tuple. It does not edit the workspace. Review it against the latest source and apply only after independent validation. Long historical ledger prose and all class/branch validation assertions remain untouched.
