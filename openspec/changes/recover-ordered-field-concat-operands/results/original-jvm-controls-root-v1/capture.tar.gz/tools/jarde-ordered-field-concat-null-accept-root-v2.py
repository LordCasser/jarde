from pathlib import Path
import json, hashlib
BASE=Path('/private/tmp/jarde-ordered-field-concat-original-root-v2')
OUT=Path('/private/tmp/jarde-ordered-field-concat-null-original-root-v2')
def pin(p):
 b=Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check_capture(path,count):
 d=json.loads((path/'execution.json').read_text());assert len(d['commands'])==count
 assert d['source_manifest_before']==d['source_manifest_after'] and d['target_absent']
 assert d['commands'][-1]['argv']==['cargo','clean']
 for c in d['commands']:
  assert c['exit_code']==0 and c.get('guard_stop') is None
  for s in c['streams'].values():assert pin(s['path'])==s
 return d
old=check_capture(BASE,37);new=check_capture(OUT,13)
expected='nullReceiver=NullPointerException events='
observations=[]
for i in range(6):
 c=new['commands'][i*2+1];assert c['argv'][-1]=='Runner' and '-Xverify:all' in c['argv']
 b=Path(c['streams']['stdout']['path']).read_text();lines=b.splitlines()
 assert lines.count(expected)==1 and not any('missing-npe' in x for x in lines)
 original=old['commands'][i*6+2];assert original['argv'][-1]=='Runner'
 assert '\n'.join(x for x in lines if x!=expected)+'\n'==Path(original['streams']['stdout']['path']).read_text()
 cp=c['argv'][c['argv'].index('-cp')+1].split(':')[1]
 observations.append({'lane':i,'class':pin(Path(cp)/'OrderedFieldConcat.class'),'stdout':c['streams']['stdout'],'null_receiver_npe':True,'other_oracles_unchanged':True})
summary={'status':'accepted_original_null_receiver_observations_only','normal_commands':12,'raw_streams':26,'source_count':len(new['source_manifest_before']),'source_unchanged':True,'observations':observations,'jarde_candidate_accepted':False}
(OUT/'root-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='observations'}))
