# Ordered instance-field concat fixture (private prep)

This directory contains a minimal Java 8 compatible class and independent Runner for the ordered instance-field concat recovery change. It has direct same-owner local receivers, normal and volatile int fields, Object conversion that mutates a later field, null and char[] Object-overload controls, and named negative shapes for static fields, receiver calls, a void effect, and an extra field-value use.

`manifest.json` records source SHA-256 values, the four JDK/profile compile groups, corresponding `javap` and runtime commands, and the source-derived expected stdout. Every group writes under its own `runs/<jdk>/<profile>/` directory. Execute compile before javap/run; the plan intentionally has no shell wrapper and no commands have been executed here. `-g` and `-g:none` are kept separate for both pinned JDK installations.

The stdout oracle has not been observed by compiling or running this fixture. A root executor should first inspect the sources, then run the manifest argv entries with the established disk/target/one-second guard and capture raw stdout, stderr, exit status, and `javap` output. No claim of compilation or runtime success is made.
