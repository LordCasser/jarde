# Ordered instance-field concat fixture (private prep v2)

This is a v2 copy of the v1 private fixture. The v1 directory remains untouched. The source-8/target-8 matrix still has four independent javac8/javac23 × debug/none lanes. Two additional Java 23 compiler-default source lanes (debug/none) omit `-source` and `-target`, so the default-target classfile and its concat strategy can be inspected separately.

The class includes direct instance int field reads, volatile access, Object-valued field operands, null and char[] Object-overload cases, and ordered `toString` side effects. The Runner normalizes char[] identity checks to avoid requiring equal identity strings across JVM processes. It reports plain-plus, explicit `String.valueOf((Object) ...)`, and builder-backed field conversion as observations. The manifest leaves those lines pending observation for each lane; the only required cross-form relation is that explicit valueOf and builder-backed conversion agree.

`manifest.json` contains inert javac/javap/java argv plans and source hashes. No Java tool, CLI, Cargo, or rustfmt command has been run. The stdout oracle is partial and source-derived; it is not an execution receipt.
