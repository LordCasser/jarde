#!/usr/bin/env python3
"""Create the fixture manifest and inert Java command plan; runs no Java tools."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = [ROOT / "OrderedFieldConcat.java", ROOT / "Runner.java"]
JDKS = {
    "javac8": "/Library/Java/JavaVirtualMachines/corretto-1.8.0_432/Contents/Home/bin",
    "javac23": "/Library/Java/JavaVirtualMachines/openjdk-23.0.1/Contents/Home/bin",
}
profiles = {"debug": "-g", "none": "-g:none"}
commands = []
for jdk, bindir in JDKS.items():
    for profile, debug_flag in profiles.items():
        lane = ROOT / "runs" / jdk / profile
        classes = lane / "classes"
        empty = lane / "empty"
        commands.append({
            "label": f"{jdk}-{profile}-compile",
            "argv": [f"{bindir}/javac", "-source", "8", "-target", "8", "-Xlint:-options",
                     debug_flag, "-proc:none", "-classpath", str(empty), "-sourcepath", str(empty),
                     "-d", str(classes), *map(str, SRC)],
            "cwd": str(ROOT), "creates": [str(classes), str(empty)],
        })
        commands.append({
            "label": f"{jdk}-{profile}-javap",
            "argv": [f"{bindir}/javap", "-p", "-c", "-s", "-v", "-classpath", str(classes), "OrderedFieldConcat"],
            "cwd": str(ROOT), "stdout_path": str(lane / "OrderedFieldConcat.javap.txt"),
        })
        commands.append({
            "label": f"{jdk}-{profile}-run",
            "argv": [f"{bindir}/java", "-Xverify:all", "-cp", str(classes), "Runner"],
            "cwd": str(ROOT), "stdout_path": str(lane / "Runner.stdout"),
        })

# Separate JDK 23 source-default controls intentionally omit -source/-target.
for profile, debug_flag in profiles.items():
    lane = ROOT / "runs" / "javac23" / "source-default" / profile
    classes = lane / "classes"
    empty = lane / "empty"
    commands.append({
        "label": f"javac23-source-default-{profile}-compile",
        "argv": [f"{JDKS['javac23']}/javac", debug_flag, "-proc:none", "-classpath", str(empty),
                 "-sourcepath", str(empty), "-d", str(classes), *map(str, SRC)],
        "cwd": str(ROOT), "creates": [str(classes), str(empty)],
    })
    commands.append({
        "label": f"javac23-source-default-{profile}-javap",
        "argv": [f"{JDKS['javac23']}/javap", "-p", "-c", "-s", "-v", "-classpath", str(classes), "OrderedFieldConcat"],
        "cwd": str(ROOT), "stdout_path": str(lane / "OrderedFieldConcat.javap.txt"),
    })
    commands.append({
        "label": f"javac23-source-default-{profile}-run",
        "argv": [f"{JDKS['javac23']}/java", "-Xverify:all", "-cp", str(classes), "Runner"],
        "cwd": str(ROOT), "stdout_path": str(lane / "Runner.stdout"),
    })

oracle = (
    "fields=value=3;volatile=5\n"
    "objectMutation=object=object;later=99 calls=1 events=object.toString\n"
    "nullObjectToString=object=null;later=99 calls=1 events=object.toString\n"
    "nullObject=object=null\n"
    "charArrayObject=true\n"
    "objectFieldNull=object=null;later=7\n"
    "objectFieldCharArray=true\n"
    "nullReceiver=NullPointerException events=\n"
    "staticControl=value=17;done\n"
    "receiverCallControl=value=3;done events=nextReceiver\n"
    "voidEffectControl=value=3;later=7 events=voidEffect\n"
    "extraUseControl=value=3;again=3\n"
)
manifest = {
    "schema": "jarde-ordered-field-concat-fixture-prep-v1",
    "status": "prepared_not_compiled_or_executed",
    "source_level": "Java 8",
    "sources": [
        {"path": str(p), "bytes": p.stat().st_size,
         "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
        for p in SRC
    ],
    "groups": [
        {"jdk": j, "profile": p, "directory": str(ROOT / "runs" / j / p),
         "debug_info": p == "debug"}
        for j in JDKS for p in profiles
    ],
    "source_default_control_lanes": [
        {"jdk": "javac23", "source_level": "compiler default", "profile": p,
         "directory": str(ROOT / "runs" / "javac23" / "source-default" / p)}
        for p in profiles
    ],
    "commands": commands,
    "stdout_oracle": {
        "status": "partial_pending_observation",
        "utf8": oracle, "sha256": hashlib.sha256(oracle.encode()).hexdigest(),
        "omitted_observation_lines": ["plainPlusControl=...", "explicitValueOfControl=...", "builderObjectFieldControl=..."],
        "required_relation": "For each lane, explicitValueOfControl result must equal builderObjectFieldControl result; record plainPlusControl as observed without assuming an outcome."
    },
    "cases": [
        {"name": "instanceFields", "kind": "positive", "assert": "one direct instance field read feeds each following append; volatile access remains once"},
        {"name": "plainPlusObjectBeforeLaterField", "kind": "observation", "assert": "record source-level plus result; no fixed timing expectation across compiler versions"},
        {"name": "explicitValueOfBeforeLaterField", "kind": "observation", "assert": "compare explicit java.lang.String.valueOf((Object) operand) result with builderObjectFieldControl"},
        {"name": "objectFieldBeforeLaterField", "kind": "positive", "assert": "direct Object field operand; explicit conversion result must match explicitValueOfBeforeLaterField"},
        {"name": "objectBeforeLaterField", "kind": "positive", "assert": "Object conversion calls toString before later field read; value is 99, one call/event"},
        {"name": "nullObject", "kind": "overload-control", "assert": "explicit Object overload appends null text"},
        {"name": "charArrayAsObject", "kind": "overload-control", "assert": "explicit Object overload yields [C@ form rather than char-array contents"},
        {"name": "nullReceiver", "kind": "positive-exception-control", "assert": "original getfield null receiver throws NullPointerException"},
        {"name": "staticFieldBetweenAppends", "kind": "negative", "assert": "getstatic shape is present as a refusal control"},
        {"name": "receiverCallShape", "kind": "negative", "assert": "method call computes field receiver"},
        {"name": "voidEffectBetweenAppends", "kind": "negative", "assert": "void call interrupts append chain"},
        {"name": "fieldHasExtraUse", "kind": "negative", "assert": "the source local value is reused after the append; javap must determine whether bytecode exposes a second field-read SSA use or only a local load/store outside the chain"},
    ],
    "limitations": ["Commands are inert plans only.", "No javac, java, javap, CLI, Cargo, or rustfmt command was run.", "The common stdout oracle is partial; plain+, explicit valueOf, and builder results remain pending observation per lane."],
}
(ROOT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
