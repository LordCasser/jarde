public final class OrderedFieldConcat {
    public static int staticValue = 17;

    public int value;
    public volatile int volatileValue;
    public int later;
    public Object payload;
    public int toStringCalls;
    public String textResult = "object";
    public String events = "";

    public OrderedFieldConcat(int value, int volatileValue, int later) {
        this.value = value;
        this.volatileValue = volatileValue;
        this.later = later;
    }

    private void event(String value) {
        if (!events.isEmpty()) {
            events += ",";
        }
        events += value;
    }

    // Positive: exact same-owner local receiver, direct next-append consumers.
    public static String instanceFields(OrderedFieldConcat receiver) {
        return new StringBuilder().append("value=").append(receiver.value)
                .append(";volatile=").append(receiver.volatileValue).toString();
    }

    // Source-level plus control for comparison with the explicit append chain.
    public static String plainPlusObjectBeforeLaterField(OrderedFieldConcat receiver) {
        return "object=" + receiver + ";later=" + receiver.later;
    }

    // Explicit conversion control: valueOf(Object) must finish before getfield.
    public static String explicitValueOfBeforeLaterField(OrderedFieldConcat receiver) {
        return "object=" + java.lang.String.valueOf((Object) receiver)
                + ";later=" + receiver.later;
    }

    // Field-backed Object operand for explicit conversion timing and overload controls.
    public static String objectFieldBeforeLaterField(OrderedFieldConcat receiver) {
        return new StringBuilder().append("object=").append(receiver.payload)
                .append(";later=").append(receiver.later).toString();
    }

    // Positive: append(Object) must finish conversion before the later getfield.
    public static String objectBeforeLaterField(OrderedFieldConcat receiver) {
        return new StringBuilder().append("object=").append((Object) receiver)
                .append(";later=").append(receiver.later).toString();
    }

    // Positive overload controls: explicit Object cast for null and char[] values.
    public static String nullObject(Object value) {
        return new StringBuilder().append("object=").append((Object) value).toString();
    }

    public static String charArrayAsObject(Object value) {
        return new StringBuilder().append("object=").append((Object) value).toString();
    }

    // Negative shape: getstatic between append operations.
    public static String staticFieldBetweenAppends() {
        return new StringBuilder().append("value=").append(staticValue)
                .append(";done").toString();
    }

    // Negative shape: receiver call cannot establish the allowed local-load proof.
    public OrderedFieldConcat nextReceiver() {
        event("nextReceiver");
        return this;
    }

    public static String receiverCallShape(OrderedFieldConcat receiver) {
        return new StringBuilder().append("value=").append(receiver.nextReceiver().value)
                .append(";done").toString();
    }

    // Negative shape: an unrelated void effect interrupts the append chain.
    public void voidEffect() {
        event("voidEffect");
    }

    public static String voidEffectBetweenAppends(OrderedFieldConcat receiver) {
        StringBuilder builder = new StringBuilder().append("value=").append(receiver.value);
        receiver.voidEffect();
        return builder.append(";later=").append(receiver.later).toString();
    }

    // Negative shape: the field read has a second observable use.
    public static String fieldHasExtraUse(OrderedFieldConcat receiver) {
        int observed = receiver.value;
        StringBuilder builder = new StringBuilder().append("value=").append(observed);
        return builder.append(";again=").append(observed).toString();
    }

    // Negative shape: null receiver preserves the original getfield NPE point.
    public static String nullReceiver(OrderedFieldConcat receiver) {
        return new StringBuilder().append("value=").append(receiver.value)
                .append(";later=").append(receiver.later).toString();
    }

    @Override
    public String toString() {
        toStringCalls++;
        later = 99;
        event("object.toString");
        return textResult;
    }
}
