#!/usr/bin/env python3
"""Create inert Java source/command manifest; executes no Java tools."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
JDKS = {
    "javac8": "/Library/Java/JavaVirtualMachines/corretto-1.8.0_432/Contents/Home/bin",
    "javac23": "/Library/Java/JavaVirtualMachines/openjdk-23.0.1/Contents/Home/bin",
}
profiles = {"debug": "-g", "none": "-g:none"}
positive_sources = [ROOT / "OrderedFieldConcat.java", ROOT / "Runner.java"]
negative_sources = [ROOT / "OrderedFieldConcatNegatives.java", ROOT / "NegativeRunner.java"]
commands = []
lane_rows = []

lanes = [(j, p, "source8-target8") for j in JDKS for p in profiles]
lanes += [("javac23", p, "source-default") for p in profiles]
for jdk, profile, target_mode in lanes:
    bindir = JDKS[jdk]
    flags = ["-source", "8", "-target", "8", "-Xlint:-options"] if target_mode == "source8-target8" else []
    lane = ROOT / "runs" / jdk / target_mode / profile
    empty = lane / "empty"
    pos = lane / "positive"
    neg = lane / "negative-original"
    debug_flag = profiles[profile]
    lane_rows.append({"jdk": jdk, "profile": profile, "target_mode": target_mode,
                      "positive_directory": str(pos), "negative_original_directory": str(neg)})
    commands.extend([
        {"label": f"{jdk}-{target_mode}-{profile}-positive-compile",
         "role": "original-positive-fixture", "argv": [f"{bindir}/javac", *flags, debug_flag,
             "-proc:none", "-classpath", str(empty), "-sourcepath", str(empty), "-d", str(pos),
             *map(str, positive_sources)], "cwd": str(ROOT), "creates": [str(pos), str(empty)]},
        {"label": f"{jdk}-{target_mode}-{profile}-positive-javap",
         "role": "original-positive-fixture", "argv": [f"{bindir}/javap", "-p", "-c", "-s", "-v",
             "-classpath", str(pos), "OrderedFieldConcat"], "cwd": str(ROOT),
         "stdout_path": str(lane / "OrderedFieldConcat.javap.txt")},
        {"label": f"{jdk}-{target_mode}-{profile}-positive-run",
         "role": "original-positive-fixture", "argv": [f"{bindir}/java", "-Xverify:all", "-cp", str(pos), "Runner"],
         "cwd": str(ROOT), "stdout_path": str(lane / "Runner.stdout")},
        {"label": f"{jdk}-{target_mode}-{profile}-negative-original-compile",
         "role": "original-negative-oracle", "argv": [f"{bindir}/javac", *flags, debug_flag,
             "-proc:none", "-classpath", str(empty), "-sourcepath", str(empty), "-d", str(neg),
             *map(str, negative_sources)], "cwd": str(ROOT), "creates": [str(neg), str(empty)]},
        {"label": f"{jdk}-{target_mode}-{profile}-negative-original-javap",
         "role": "original-negative-oracle", "argv": [f"{bindir}/javap", "-p", "-c", "-s", "-v",
             "-classpath", str(neg), "OrderedFieldConcatNegatives"], "cwd": str(ROOT),
         "stdout_path": str(lane / "OrderedFieldConcatNegatives.javap.txt")},
        {"label": f"{jdk}-{target_mode}-{profile}-negative-original-run",
         "role": "original-negative-oracle", "argv": [f"{bindir}/java", "-Xverify:all", "-cp", str(neg), "NegativeRunner"],
         "cwd": str(ROOT), "stdout_path": str(lane / "NegativeRunner.stdout")},
    ])

positive_oracle = (
    "fields=value=3;volatile=5\n"
    "objectMutation=object=object;later=99 calls=1 events=object.toString\n"
    "nullObjectToString=object=null;later=99 calls=1 events=object.toString\n"
    "nullObject=object=null\n"
    "charArrayObject=true\n"
    "objectFieldNull=object=null;later=7\n"
    "objectFieldCharArray=true\n"
)
negative_oracle = (
    "staticControl=value=17;done\n"
    "receiverCallControl=value=3;done events=nextReceiver\n"
    "voidEffectControl=value=3;later=7 events=voidEffect\n"
    "extraUseControl=value=3;again=3\n"
)
all_sources = positive_sources + negative_sources
manifest = {
    "schema": "jarde-ordered-field-concat-fixture-prep-v3",
    "status": "prepared_not_compiled_or_executed",
    "source_level": "Java 8 for four source8-target8 lanes; Java 23 compiler defaults for two separate controls",
    "sources": [{"path": str(p), "bytes": p.stat().st_size,
                 "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
                 "role": "positive" if p in positive_sources else "negative-original-oracle"}
                for p in all_sources],
    "positive_class_scope": "OrderedFieldConcat contains only positive whole-class recovery methods and Runner; rejected concat shapes are excluded from this class.",
    "negative_class_scope": "OrderedFieldConcatNegatives retains the four rejected shapes with an exact same-owner receiver type and NegativeRunner records original JVM behavior.",
    "lanes": lane_rows,
    "commands": commands,
    "positive_stdout_oracle": {
        "status": "partial_pending_observation",
        "utf8": positive_oracle, "sha256": hashlib.sha256(positive_oracle.encode()).hexdigest(),
        "observation_lines": ["plainPlusControl=...", "explicitValueOfControl=...", "builderObjectFieldControl=..."],
        "required_relation": "For each lane, explicitValueOfControl result must equal builderObjectFieldControl result; record plainPlusControl without assuming a cross-version outcome."
    },
    "negative_original_stdout_oracle": {"utf8": negative_oracle,
        "sha256": hashlib.sha256(negative_oracle.encode()).hexdigest()},
    "negative_recovery_policy": "The CLI may refuse the separate negative class. If the recovered Negative class does not compile, record compile failure and do not run its Runner; NegativeRunner commands here describe the original source/JVM baseline only.",
    "prior_execution_attribution": "The earlier 18-command v2 run applies only to the exact v2 source hashes and outputs. It is not evidence for these v3 files.",
    "limitations": ["All commands are inert plans.", "No javac, java, javap, Jarde CLI, Cargo, or rustfmt command was run.", "Positive observation lines remain pending; the listed oracle is partial and source-derived."]
}
(ROOT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
