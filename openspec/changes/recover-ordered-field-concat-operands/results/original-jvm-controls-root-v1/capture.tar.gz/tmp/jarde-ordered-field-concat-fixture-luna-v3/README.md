# Ordered instance-field concat fixture (private prep v3)

This version separates whole-class positive recovery from intentional refusals. `OrderedFieldConcat.java` and `Runner.java` contain the positive instance-field, volatile, Object field, null, char[] and conversion-order controls. They are compiled and run in isolated positive directories. The four refusal examples and their same-owner receiver/helper fields live only in `OrderedFieldConcatNegatives.java`; `NegativeRunner.java` preserves the expected behavior of the original source.

The manifest contains the four source-8/target-8 JDK/profile lanes and two separate Java 23 compiler-default lanes. Each lane has independent positive and negative-original output paths and javap captures. Negative-original commands establish the original-source JVM baseline. A later recovered negative class may fail compilation; that result must suppress runtime for that recovered class. Do not conflate it with the original NegativeRunner baseline.

The v2 run completed against v2's source hashes. It does not validate these changed v3 sources. This directory is preparation only: no Java tool, Jarde CLI, Cargo, or rustfmt command has been run. The three plus/valueOf/builder lines remain pending observation; only explicit valueOf and builder equality is required.
