# Retry proof gate test candidate

This private candidate adds two permanent tests to `crates/jarde-java/src/region/finite_loop_catch_tests.rs`.

Baseline snapshots used to prepare the patch:

- `crates/jarde-java/src/region.rs`: `6f10c13d37b2472b77a0a5bc1d97f9bb45d05a65a030dca4f555d0221c3a707a`
- `crates/jarde-java/src/region/finite_loop_catch_tests.rs`: `084a4ab256bd19c1c7c755e523841d8a06704a4b02bf86bbcb0af6a5353f3f5c`

The patch reuses all eight existing `RetryFixture.class` fixtures (v2/v3, debug/none, javac8/javac23). Each lane is opened and analyzed through the existing frozen-class loader, producing its real canonical CFG, SSA table, decoded operations, and handler rows. The new checks call `Walker::retry_loop_facts` directly so budget exhaustion and cancellation are observed inside the proof that would otherwise return `RetryLoopFacts` for publication.

The counterexamples mutate only proof inputs derived from those actual fixtures: physical exception rows, guard join facts, or a decoded opcode fact while retaining the fixture's actual SSA and canonical graph. These deliberately inconsistent combinations exercise rejection gates; they are not valid class files, JVM executions, verifier evidence, or behavior claims. The SSA-tail case shortens the physical row and guard end together so the proof reaches its independent comparison with the unchanged real SSA terminal transfer. A full `recover` call with a mutated handler target then checks that retry refusal still leaves ordinary completed-tree owner uniqueness and coverage checks active.

Candidate artifact hashes at handoff:

- Target baseline test file: `084a4ab256bd19c1c7c755e523841d8a06704a4b02bf86bbcb0af6a5353f3f5c`
- Candidate test file: `61f7274e994e1a16cd47d247b8ed1c47093dd3876db0bbc940acbdd6c012ac84`
- `candidate.patch`: `874dbec6a1f580c33bfbdad6fef99550522faf8e18e1d98cdf4cda0c25b37327`

The candidate is intentionally unexecuted here. No Rust formatter, build, test, JDK, JADX, or CLI command was run. The root task should apply this patch alongside the existing excIR test candidate and run its planned single fresh build/test cycle. Static patch application was checked only against a private copy of the baseline file.
