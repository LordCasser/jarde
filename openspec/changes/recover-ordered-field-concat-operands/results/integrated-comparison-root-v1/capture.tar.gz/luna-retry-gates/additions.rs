
fn retry_shape_for_test(
    canonical: &CanonicalCfg,
    view: &NormalFlowView,
    ssa: &SsaTable,
    operations: &Operations,
    code: &MethodCodeFacts,
) -> (CanonicalBlockId, crate::guard::Catches) {
    let header = canonical
        .blocks()
        .iter()
        .find(|block| block.id().bci() == 0)
        .expect("frozen retry header exists")
        .id()
        .clone();
    let mut budget = ample_budget();
    let shape = crate::guard::catches(
        canonical,
        view,
        ssa,
        operations,
        &code.exception_handlers,
        None,
        None,
        &crate::pass::JAVA_8,
        &header,
        &mut budget,
    )
    .expect("the real frozen guard facts complete")
    .expect("the real frozen method has one named retry catch");
    (header, shape)
}

fn retry_proof_for_test(
    canonical: &CanonicalCfg,
    view: &NormalFlowView,
    ssa: &SsaTable,
    operations: &Operations,
    code: &MethodCodeFacts,
    handlers: &[jarde_reader::classfile::ExceptionHandlerFact],
    header: &CanonicalBlockId,
    shape: &crate::guard::Catches,
    budget: &mut Budget,
) -> Result<Option<RetryLoopFacts>, StopReason> {
    let chains = crate::concat::Plan::empty();
    let sites = crate::init::Sites::empty();
    let mut walker = Walker {
        canonical,
        view,
        ssa,
        operations,
        pool: &[],
        chains: &chains,
        sites: &sites,
        code,
        method_synchronized: None,
        has_reachable_explicit_monitor: false,
        return_is_boolean: false,
        handlers,
        profile: &crate::pass::JAVA_8,
        budget,
        catch_joins: BTreeSet::new(),
        loop_catch_terminal_owners: Vec::new(),
        fragmented: None,
        excluded_edge_nodes: BTreeSet::new(),
        visited: BTreeSet::new(),
        unclosed_tail_at: None,
        own_monitor: None,
        depth: 0,
    };
    walker.retry_loop_facts(header, shape)
}

fn assert_retry_facts_refuse(
    canonical: &CanonicalCfg,
    view: &NormalFlowView,
    ssa: &SsaTable,
    operations: &Operations,
    code: &MethodCodeFacts,
    handlers: &[jarde_reader::classfile::ExceptionHandlerFact],
    header: &CanonicalBlockId,
    shape: &crate::guard::Catches,
    label: &str,
) {
    let mut budget = ample_budget();
    assert!(
        retry_proof_for_test(
            canonical, view, ssa, operations, code, handlers, header, shape, &mut budget,
        )
        .expect("proof-level mutation is a bounded refusal")
        .is_none(),
        "retry proof admitted mutated evidence: {label}"
    );
}

fn assert_retry_refusal_preserves_completed_owners(
    canonical: &CanonicalCfg,
    view: &NormalFlowView,
    ssa: &SsaTable,
    operations: &Operations,
    code: &MethodCodeFacts,
    handlers: Vec<jarde_reader::classfile::ExceptionHandlerFact>,
) {
    let mut changed_code = code.clone();
    changed_code.exception_handler_count = handlers.len() as u32;
    changed_code.exception_handlers = handlers;
    let chains = crate::concat::Plan::empty();
    let sites = crate::init::Sites::empty();
    let mut budget = ample_budget();
    let recovered = recover(
        canonical,
        view,
        ssa,
        operations,
        &[],
        &chains,
        &sites,
        &changed_code,
        Some(false),
        false,
        &crate::pass::JAVA_8,
        &mut budget,
    )
    .expect("inconsistent physical facts produce a bounded recovery result");
    let tree = Region::Sequence {
        regions: recovered.regions.clone(),
    };
    assert!(
        find_retry_loop(&tree, 0).is_none(),
        "the refused physical row cannot publish the retry loop"
    );
    let owners: Vec<_> = recovered
        .regions
        .iter()
        .flat_map(Region::blocks)
        .cloned()
        .collect();
    let unique: BTreeSet<_> = owners.iter().cloned().collect();
    let expected: BTreeSet<_> = canonical
        .blocks()
        .iter()
        .map(|block| block.id().clone())
        .collect();
    assert_eq!(owners.len(), unique.len(), "ordinary overlap gate stays active");
    assert_eq!(unique, expected, "fallback recovery still accounts for each real block");
    assert_eq!(recovered.claimed.len(), canonical.blocks().len());
}

#[test]
fn retry_proof_budget_used_minus_one_and_precancel_stop_inside_the_proof() {
    use jarde_reader::budget::{CancellationToken, Limits};

    with_frozen_method(
        RETRY_V3_NONE_JAVAC8,
        b"test",
        b"()I",
        |canonical, view, ssa, operations, code, _| {
            let (header, shape) = retry_shape_for_test(canonical, view, ssa, operations, code);
            let mut complete = ample_budget();
            assert!(retry_proof_for_test(
                canonical,
                view,
                ssa,
                operations,
                code,
                &code.exception_handlers,
                &header,
                &shape,
                &mut complete,
            )
            .expect("unbounded retry proof completes")
            .is_some());
            let used = complete.usage().analysis_steps;
            assert!(used > 0);

            let mut exhausted = Budget::new(Limits {
                analysis_steps: used - 1,
                elapsed_millis: u64::MAX,
                ..Limits::default()
            });
            assert!(matches!(
                retry_proof_for_test(
                    canonical,
                    view,
                    ssa,
                    operations,
                    code,
                    &code.exception_handlers,
                    &header,
                    &shape,
                    &mut exhausted,
                ),
                Err(StopReason::Budget {
                    dimension: CountedBudgetDimension::AnalysisSteps,
                    ..
                })
            ));

            let token = CancellationToken::new();
            token.cancel();
            let mut cancelled = Budget::with_cancellation_token(
                Limits {
                    analysis_steps: u64::MAX,
                    elapsed_millis: u64::MAX,
                    ..Limits::default()
                },
                token,
            );
            assert!(matches!(
                retry_proof_for_test(
                    canonical,
                    view,
                    ssa,
                    operations,
                    code,
                    &code.exception_handlers,
                    &header,
                    &shape,
                    &mut cancelled,
                ),
                Err(StopReason::Cancelled { .. })
            ));
        },
    );
}

#[test]
fn retry_proof_rejects_mutated_physical_and_transfer_evidence() {
    use jarde_reader::classfile::ExceptionHandlerFact;

    with_frozen_method(
        RETRY_V3_NONE_JAVAC8,
        b"test",
        b"()I",
        |canonical, view, ssa, operations, code, _| {
            let (header, shape) = retry_shape_for_test(canonical, view, ssa, operations, code);
            let base_rows = code.exception_handlers.clone();
            let row = base_rows.first().expect("one physical named row").clone();
            let handler_bci = shape.sites[0].handler.bci();
            let alternate_block = canonical
                .blocks()
                .iter()
                .map(|block| block.id())
                .find(|block| {
                    block.bci() != header.bci()
                        && block.bci() != handler_bci
                        && Some(block) != shape.join.as_ref()
                })
                .expect("a real non-header, non-handler block exists")
                .clone();

            let mut wrong_start_rows = base_rows.clone();
            wrong_start_rows[0].start_bci = row.start_bci.saturating_add(1);
            assert_retry_facts_refuse(
                canonical, view, ssa, operations, code, &wrong_start_rows, &header, &shape,
                "physical named row start disagrees with the protected header",
            );

            let mut wrong_type_rows = base_rows.clone();
            wrong_type_rows[0].catch_type_index = Some(
                row.catch_type_index
                    .expect("the frozen row is named")
                    .wrapping_add(1),
            );
            assert_retry_facts_refuse(
                canonical, view, ssa, operations, code, &wrong_type_rows, &header, &shape,
                "physical named catch type disagrees with the proved CatchSite",
            );

            let mut wrong_handler_rows = base_rows.clone();
            wrong_handler_rows[0].handler_bci = alternate_block.bci();
            assert_retry_facts_refuse(
                canonical, view, ssa, operations, code, &wrong_handler_rows, &header, &shape,
                "physical handler target disagrees with canonical CatchSite",
            );

            let mut shared_handler_rows = base_rows.clone();
            let mut shared = row.clone();
            shared.ordinal = shared_handler_rows
                .iter()
                .map(|candidate| candidate.ordinal)
                .max()
                .unwrap_or(0)
                .saturating_add(1);
            shared.start_bci = row.end_bci;
            shared.end_bci = row.end_bci.saturating_add(1);
            shared_handler_rows.push(shared);
            assert_retry_facts_refuse(
                canonical, view, ssa, operations, code, &shared_handler_rows, &header, &shape,
                "a second physical row shares the handler",
            );

            let mut overlapping_rows = base_rows.clone();
            let mut competing: ExceptionHandlerFact = row.clone();
            competing.ordinal = competing.ordinal.saturating_add(1);
            competing.start_bci = row.start_bci.saturating_add(1);
            competing.end_bci = row.end_bci.saturating_sub(1);
            competing.handler_bci = alternate_block.bci();
            overlapping_rows.push(competing);
            assert_retry_facts_refuse(
                canonical, view, ssa, operations, code, &overlapping_rows, &header, &shape,
                "an overlapping physical handler row competes for protected bytes",
            );

            let mut missing_exit = shape.clone();
            missing_exit.join = None;
            assert_retry_facts_refuse(
                canonical, view, ssa, operations, code, &base_rows, &header, &missing_exit,
                "retry shape has no proved normal exit",
            );

            let mut wrong_exit = shape.clone();
            wrong_exit.join = Some(alternate_block.clone());
            assert_retry_facts_refuse(
                canonical, view, ssa, operations, code, &base_rows, &header, &wrong_exit,
                "guard normal exit disagrees with the header's real normal successor",
            );

            // Preserve the real SSA and canonical CFG, but vary only the decoded opcode fact used
            // by the retry certificate. This deliberately inconsistent proof input must not be
            // treated as a new physical class or a JVM behavior example.
            let changed_transfer_code = jarde_reader::classfile::MethodCodeFacts::from_parts(
                code.max_stack,
                code.max_locals,
                code.code_span.clone(),
                code.instructions
                    .iter()
                    .cloned()
                    .zip(code.operands().iter().cloned())
                    .map(|(instruction, mut operands)| {
                        if instruction.bci == row.end_bci {
                            operands.effective_opcode = 0x00;
                        }
                        (instruction, operands)
                    })
                    .collect(),
                base_rows.clone(),
                code.exception_handler_count,
                code.execution.clone(),
                code.stopped_at.clone(),
                code.debug().clone(),
            );
            let changed_transfer_operations = Operations::of(&changed_transfer_code, &[]);
            assert_retry_facts_refuse(
                canonical,
                view,
                ssa,
                &changed_transfer_operations,
                &changed_transfer_code,
                &base_rows,
                &header,
                &shape,
                "physical range-end opcode no longer states a goto transfer",
            );

            // Keep the real canonical graph and SSA. Change the end in both the physical row and
            // guard fact so the proof reaches its independently read SSA-tail check; the end is a
            // proof-layer mutation, not a new or JVM-verifier-valid class-file claim.
            let last_protected_throw = canonical
                .throw_sites()
                .iter()
                .filter(|site| row.start_bci <= site.bci() && site.bci() < row.end_bci)
                .map(|site| site.bci())
                .max()
                .expect("the real retry row protects a throw site");
            let mut short_rows = base_rows.clone();
            short_rows[0].end_bci = last_protected_throw.saturating_add(1);
            assert!(short_rows[0].end_bci < row.end_bci);
            let mut short_shape = shape.clone();
            short_shape.protected_end = short_rows[0].end_bci;
            assert_retry_facts_refuse(
                canonical, view, ssa, operations, code, &short_rows, &header, &short_shape,
                "physical range end disagrees with the real SSA terminal transfer BCI",
            );

            // The unmodified real handler row is then passed through full recovery once with one
            // inconsistent physical target, proving the ordinary completed-tree owner gate remains
            // on the path after retry refusal. No JVM behavior is claimed for this mutation.
            assert_retry_refusal_preserves_completed_owners(
                canonical,
                view,
                ssa,
                operations,
                code,
                wrong_handler_rows,
            );
        },
    );
}
