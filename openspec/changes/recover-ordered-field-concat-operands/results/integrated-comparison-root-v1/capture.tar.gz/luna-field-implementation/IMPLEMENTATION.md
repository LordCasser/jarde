# Ordered field concat private candidate

## Snapshot

- Git HEAD when copied: see `base.sha`.
- The candidate baseline is the shared working-tree content copied before edits, including the parent's already-dirty `build.rs` and `report.rs`; exact input file hashes are in `baseline.sha256` and the original dirty status is in `shared-status.txt`.
- Source changes are only in `candidate/`. `candidate.patch` is relative to those copied working-tree files. No shared file was changed.
- No Cargo, rustfmt, JDK, JADX, or CLI command was run.

## Implementation

- `report` calls one concat planning entry, which performs the existing conditional planning and then its field certificate with the already-built field plan, decoded Code facts, and existing budget.
- The certificate only examines ordinary concat refusals with `jre_concat_interleaved_effect`. It accepts claimed instance reads only when the receiver is the immediately preceding local `Load`, the field result is the sole value consumed by the immediately following append, and the receiver load result is used only by that field read.
- The existing concat verifier still checks the allocation, append overloads/order, builder identity, tail, and chain aliases. A second check requires the String tail's sole consumer to be the immediately following same-block instruction and compares complete ordered exception-handler facts from allocation through that consumer.
- New scans charge and poll the existing `IrItems` budget. The chain and owner set are changed only after all checks and budget charges succeed; the optional meter charges the actual verifier replay path, including its refusal path.
- Object-overload parts on a field-certified chain are emitted at their append position as `java.lang.String.valueOf((java.lang.Object) operand)`. Existing non-field chains leave this set empty and keep their previous text.
- Added permanent Rust cases cover all four existing retry-v2 lanes, all four v3 source-8/target-8 positive class lanes, an explicit `char[]` field on `append(Object)`, static and receiver-call negative controls, and a generated valid class whose `getfield` result is duplicated and consumed by two append calls. A direct planner-stage one-under-successful-budget run and pre-cancelled token assert `Stop` before a plan with owner changes can be returned.
- The tests reuse the root-installed class files under `tests/fixtures/proved-ordered-field-concat/`; this candidate does not duplicate fixture binaries and did not run a compiler or execute them.

## v3 review corrections

- The coverage test reads physical `CodeInstruction.bci` fields, the verifier's old field-copy predicate retains its first matching copy semantics, and no unnecessary `mut` remains.
- The pre-cancel regression first constructs the existing ordinary refusal, then calls the certificate stage directly with a cancelled budget so the stop comes from the certificate's own first charged poll.
- A generated valid version-52 class provides `getfield; dup_x1; append; swap; append`; its field result has two downstream append consumers. This is a real classfile fixture built by the existing test helpers and the test asserts the concat remains refused. The direct unit test separately pins the same-SSA multiple-instruction and Phi-reader rejection predicate.

## Remaining review points

- Direct field certification builds one charged SSA index for instruction writers/readers and Phi inputs. The separate verifier replay now charges each instruction, read, field-copy candidate, and Phi/receiver-trace step at the point it visits it; it no longer reserves a guessed fixed number of whole-body passes. A direct planner-stage one-under-successful-budget test proves the stop occurs inside certification before the `Plan` is returned. A pre-cancelled token covers the same boundary.
- Another test passes the real IR with an empty field plan to prove an unclaimed field read stays refused, and a test-only Code-facts copy splits exception-row coverage at the actual getfield BCI (it does not claim those modified rows form a JVM-verifiable class). Row comparisons use complete handler facts, not ordinal alone. Reader census includes Phi inputs, so a field or receiver value that enters a Phi is not treated as a single immediate instruction use.
- The Java negatives exercise static access and a method-produced receiver. The generated class uses valid `getfield; dup_x1; append; swap; append` bytecode to retain and consume a second copy of the field result. The value stored to a local before concat is not itself a candidate field operand; the direct planner's whole-body use census handles multiply consumed or Phi-merged SSA values for the actual direct-getfield shape. A predicate unit test also covers a second same-SSA instruction reader and a Phi input.
- Root reported that plain `+` on its local JDK 23 control already produced `String.valueOf(Object)` before the later field read. This candidate makes no claim that the local plain-plus control differs; its emitted wrapper explicitly pins the physical `Object` overload by design.
- No Cargo, rustfmt, JDK, JADX, or CLI command was run, per the task boundary.
