# Ordered field concat comparison collector (private preparation)

`collect.py` accepts the root-frozen Jarde CLI, its focused execution receipt, and a fresh output directory:

```sh
python3 -B /private/tmp/jarde-ordered-field-concat-comparison-prep-luna-v1/collect.py \
  /absolute/path/to/frozen-jarde \
  /absolute/path/to/focused-receipt.json \
  /private/tmp/jarde-ordered-field-concat-comparison-root-v1
```

The collector validates the focused receipt, exact CLI SHA/mode, complete source manifest, pinned root runner and command specification, successful build/test/cleanup records, current source closure, and target absence. It reuses the six frozen original JVM lanes and four source-8/target-8 class files pinned in `pins.json`; each lane also retains original `javap`, stdout, and supplemental null-receiver stdout evidence.

It runs four fresh Jarde `class-source` renders and compiles each generated class source unchanged with the fixture Runner, adding a package declaration only to the copied Runner when the generated class requires one. It also runs four actual JADX lanes: default for debug and `--rename-flags none` for none, one per JDK. Both streams and true exit codes are kept. A failed render does not compile; a failed compile never runs Java. Candidate, JADX, and original stdout hashes and all three pairwise byte comparisons are recorded lane by lane without assuming they all match.

For every candidate report the collector saves both each class method's `text` and each recovery report's `text`, along with the method's physical identity. Source-map segment offsets are sliced only against `outcome.report.text` (`artifact_scope: recovery-report-text`); they are not translated to class or method offsets. The checker separately verifies that the exact method `text` occurs once in the assembled class, and checks the Object conversion wrapper in the assembled class, method text, and recovery report text. It binds every source-map anchor's method identity to the method row and checks direct/derived provenance: the field read is a direct primary origin, while append is a derived origin from the actual operand. Expected field-read and following `StringBuilder.append` BCIs come from that lane's pinned original `javap` output. Any disagreement remains a reported checker failure for root review; this preparation makes no product acceptance claim.

The per-command guard/scanner and two JDK legs are pinned from the existing root tools. The guard requires at least 5 GiB free space, caps the workspace target directory at 1 GiB, and samples every second. The collector and checker are preparation only. No CLI, JADX, javac, java, javap, Cargo, or rustfmt command has been run from this directory.
