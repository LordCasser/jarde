#!/usr/bin/env python3
"""Collect frozen ordered-field-concat original/JADX/Jarde comparisons.

Usage: python3 -B collect.py CANDIDATE_CLI FOCUSED_RECEIPT FRESH_OUTPUT
The script runs tools only when root invokes it. Never reuse an output directory.
"""
from __future__ import annotations
import datetime, hashlib, importlib.util, json, os, re, shutil, sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
PINS_PATH=HERE/'pins.json'
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
FIXTURE=ROOT/'tests/fixtures/proved-ordered-field-concat'
FOCUS=Path('/private/tmp/jarde-loop-focused-runner-root-v1.py')
FOCUS_MOD=Path('/private/tmp/jarde-cf11-structured-list-focused-runner-prep-luna-v7/run.py')
CLOSURE_MOD=Path('/private/tmp/jarde-iterator-assignment-full-validation-prep-luna-v2/workspace_runner.py')
STRIP=('JAVA_HOME','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH')
SCHEMA='jarde-ordered-field-concat-comparison-v1'

def sha(data:bytes)->str: return hashlib.sha256(data).hexdigest()
def pin(path):
 p=Path(path); b=p.read_bytes(); return {'path':str(p.resolve()),'bytes':len(b),'sha256':sha(b)}
def dump(path,value):
 p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(value,ensure_ascii=False,indent=2,default=str)+'\n',encoding='utf-8')
def read_json(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def load_module(path,name):
 spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def check_pin(row):
 p=Path(row['path']); actual=pin(p)
 if actual['bytes']!=row.get('bytes') or actual['sha256']!=row.get('sha256'):
  raise RuntimeError('pinned input changed: '+str(p))
 return actual
def package_of(src):
 m=re.search(r'(?m)^\s*package\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*;',src)
 return m.group(1) if m else ''
def class_of(src):
 m=re.search(r'(?m)^\s*public\s+(?:(?:final|abstract|sealed|non-sealed)\s+)*class\s+([A-Za-z_$][\w$]*)\b',src)
 return m.group(1) if m else None
def name_text(value):
 if isinstance(value,str): return value
 if isinstance(value,dict):
  for key in ('escaped','text','name','value'):
   if isinstance(value.get(key),str): return value[key]
 return None
def verify_build_receipt(cli,receipt,rdoc,prep):
 if rdoc.get('status')!='commands_passed_pending_independent_acceptance': raise RuntimeError('focused receipt status mismatch')
 cli_row=rdoc.get('cli')
 if not isinstance(cli_row,dict): raise RuntimeError('focused receipt has no CLI pin')
 actual=pin(cli)
 if cli_row.get('path')!=str(cli.resolve()) or cli_row.get('bytes')!=actual['bytes'] or cli_row.get('sha256')!=actual['sha256']:
  raise RuntimeError('focused receipt does not pin argv CLI')
 if cli.stat().st_mode & 0o777 != 0o555: raise RuntimeError('candidate CLI must be frozen mode 0555')
 before=rdoc.get('source_manifest_before'); after=rdoc.get('source_manifest_after')
 if not isinstance(before,list) or not before or not isinstance(after,list) or not after: raise RuntimeError('focused receipt lacks complete source manifests')
 if {x.get('path') for x in before}!={x.get('path') for x in after}: raise RuntimeError('root build changed source closure membership')
 for key in ('runner','command_spec'):
  check_pin(rdoc.get(key,{}))
 spec=json.loads(Path(rdoc['command_spec']['path']).read_text(encoding='utf-8'))
 commands=rdoc.get('commands',[])
 if [x.get('argv') for x in commands if not x.get('cleanup_only')]!=spec: raise RuntimeError('actual build argv differs from pinned command spec')
 tests=[]; builds=[]; cleans=[]
 for row in commands:
  if row.get('exit_code')!=0 or row.get('guard_stop') is not None: raise RuntimeError('root build/test command failed or guard-stopped')
  for value in row.get('streams',{}).values(): check_pin(value)
  argv=row.get('argv',[])
  if argv[:2]==['cargo','test']:
   tests.append(row)
   raw=Path(row['streams']['stdout']['path']).read_text(encoding='utf-8',errors='replace')
   raw=re.sub(r'\x1b\[[0-9;]*m','',raw)
   summaries=[list(x) for x in re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)]
   if summaries!=row.get('actual_test_summaries') or not summaries or any(x[0]!='ok' or int(x[1])<=0 or int(x[2])!=0 for x in summaries):
    raise RuntimeError('focused receipt test summary is missing or disagrees with raw output')
  if argv[:2]==['cargo','build']: builds.append(row)
  if row.get('cleanup_only'): cleans.append(row)
 if not tests or not builds or len(cleans)!=1 or cleans[0].get('argv')!=['cargo','clean'] or cleans[0].get('exit_code')!=0:
  raise RuntimeError('focused receipt lacks successful build/test/clean evidence')
 if rdoc.get('target_absent') is not True: raise RuntimeError('focused receipt does not confirm target absent')
 for key,pinrow in [('focused runner',prep['focused_runner']),('focused manifest module',prep['focused_manifest_module']),('closure module',prep['source_closure_module'])]:
  check_pin(pinrow)
 focus=load_module(FOCUS_MOD,'field_fixture_source_manifest'); closure=load_module(CLOSURE_MOD,'field_fixture_source_closure')
 focus.ROOT=ROOT; focus.CLOSURE_MODULE=closure; closure.ROOT=ROOT
 if focus.source_manifest()!=after: raise RuntimeError('current workspace source closure differs from focused receipt after manifest')
 return {'source_manifest_before_count':len(before),'source_manifest_after_count':len(after),
         'source_manifest_before':before,'source_manifest_after':after,
         'source_manifest_changed_paths':[x['path'] for x,y in zip(before,after) if x!=y],
         'commands':[{'index':x.get('index'),'argv':x.get('argv'),'exit_code':x.get('exit_code'),'guard_stop':x.get('guard_stop'),'streams':x.get('streams')} for x in commands],
         'runner':rdoc['runner'],'command_spec':rdoc['command_spec'],'target_absent':True}
def prepare_environment(home):
 env={k:v for k,v in os.environ.items() if k not in STRIP}
 env['JAVA_HOME']=str(home); env['PATH']=str(home/'bin')+os.pathsep+env.get('PATH','')
 return env
def bci_set(value):
 found=set()
 def walk(x):
  if isinstance(x,dict):
   if isinstance(x.get('bci'),int): found.add(x['bci'])
   for y in x.values(): walk(y)
  elif isinstance(x,list):
   for y in x: walk(y)
 walk(value); return found
def source_map(report):
 if not isinstance(report,dict): return None
 direct=report.get('source_map')
 if isinstance(direct,dict) and isinstance(direct.get('segments'),list): return direct
 # Preserve a future schema without silently manufacturing any map.
 def seek(x):
  if isinstance(x,dict):
   if isinstance(x.get('segments'),list) and ('source_map' in x or all(isinstance(y,dict) for y in x['segments'])): return x
   for y in x.values():
    z=seek(y)
    if z is not None:return z
  elif isinstance(x,list):
   for y in x:
    z=seek(y)
    if z is not None:return z
  return None
 return seek(report)
def method_bytecode_targets(javap_text,method,field,descriptor,append_descriptor):
 lines=javap_text.splitlines(); start=None
 pattern=re.compile(r'\b'+re.escape(method)+r'\s*\(')
 for i,line in enumerate(lines):
  if pattern.search(line) and line.rstrip().endswith(';'):
   start=i; break
 if start is None: raise RuntimeError('javap method not found: '+method)
 block=[]
 for line in lines[start+1:]:
  if re.match(r'^\s*(?:public|private|protected)\s+.*\)\s*;$',line): break
  block.append(line)
 instructions=[]
 for line in block:
  m=re.match(r'^\s*(\d+):\s+(.*)$',line)
  if m: instructions.append((int(m.group(1)),m.group(2)))
 field_bci=next((bci for bci,ins in instructions if re.search(r'\bgetfield\b',ins) and re.search(r'// Field .*'+re.escape(field)+r':'+re.escape(descriptor),ins)),None)
 appends=[bci for bci,ins in instructions if 'StringBuilder.append:('+append_descriptor+')Ljava/lang/StringBuilder;' in ins]
 append_bci=next((bci for bci in appends if field_bci is not None and bci>field_bci),None)
 return {'field_bci':field_bci,'append_bci':append_bci,'all_matching_append_bcis':appends,'method':method,'field':field,'descriptor':descriptor}
def report_methods(jd,text):
 rows=[]
 whole=text.encode('utf-8')
 for method in jd.get('methods',[]) if isinstance(jd,dict) else []:
  item=method.get('item',{}); ident=item.get('identity',{}) if isinstance(item,dict) else {}
  nm=name_text(item.get('name')) if isinstance(item,dict) else None
  if nm is None and isinstance(ident,dict): nm=name_text(ident.get('name'))
  descriptor=item.get('descriptor') if isinstance(item,dict) else None
  rep=method.get('outcome',{}).get('report',{}) if isinstance(method.get('outcome'),dict) else {}
  method_text=method.get('text')
  report_text=rep.get('text') if isinstance(rep,dict) else None
  method_range=None
  if isinstance(method_text,str):
   method_bytes=method_text.encode('utf-8')
   starts=[m.start() for m in re.finditer(re.escape(method_bytes),whole)]
   # This range only binds method.text to the assembled class. Source-map coordinates below belong
   # to recovery-report.text and are never translated into class coordinates.
   if len(starts)==1: method_range={'start':starts[0],'end':starts[0]+len(method_bytes)}
   elif method_bytes==b'': method_range=None
  else: method_bytes=b''
  report_bytes=report_text.encode('utf-8') if isinstance(report_text,str) else b''
  sm=source_map(rep)
  segments=[]
  if sm:
   for seg in sm['segments']:
    st,en=seg.get('start'),seg.get('end')
    snippet=None
    if isinstance(st,int) and isinstance(en,int) and 0<=st<=en<=len(report_bytes):
     try: snippet=report_bytes[st:en].decode('utf-8')
     except UnicodeDecodeError: pass
    origins=seg.get('origin',{})
    segments.append({'start':st,'end':en,'text':snippet,'origins':origins,'bcis':sorted(bci_set(origins))})
  rows.append({'name':nm,'descriptor':descriptor,'physical_identity':ident,'method_text':method_text,
               'method_text_unique_in_assembled_class':method_range is not None,'report_text':report_text,
               'artifact_scope':'recovery-report-text','declaration':method.get('declaration'),
               'outcome_kind':method.get('outcome',{}).get('kind') if isinstance(method.get('outcome'),dict) else None,
               'report_outcome':rep.get('outcome') if isinstance(rep,dict) else None,
               'source_map':sm,'segments':segments,'mapped_bcis':sorted(set(b for x in segments for b in x['bcis']))})
 return rows
def add_runner_prefix(source_path,package,target):
 text=Path(source_path).read_text(encoding='utf-8')
 if re.search(r'(?m)^\s*package\s+',text): raise RuntimeError('Runner input already declares a package')
 content=(f'package {package};\n' if package else '')+text
 target.parent.mkdir(parents=True,exist_ok=True); target.write_text(content,encoding='utf-8')
 return target,content
def write_class_source_command(cli,cf,outpath,home,run):
 return run('candidate-class-source-render',[cli,'class-source','--input',cf,'--class','OrderedFieldConcat','--policy','single-class','--release','8','--format','json','--evidence','all'],home)

def main():
 if len(sys.argv)!=4: raise SystemExit('usage: collect.py CANDIDATE_CLI FOCUSED_RECEIPT FRESH_OUTPUT')
 cli,receipt,out=map(lambda x:Path(x).resolve(),sys.argv[1:])
 if not cli.is_file() or not os.access(cli,os.X_OK) or cli.stat().st_mode & 0o777 != 0o555: raise SystemExit('candidate CLI must exist, be executable, and frozen mode 0555')
 if not receipt.is_file(): raise SystemExit('focused receipt missing')
 if out.exists(): raise SystemExit('refuse non-fresh output: '+str(out))
 prep=read_json(PINS_PATH)
 if prep.get('schema')!='jarde-ordered-field-concat-comparison-pins-v1': raise RuntimeError('pins schema mismatch')
 # Verify all pinned existing inputs before output creation.
 for key in ('original_execution','original_summary','null_original_execution','null_original_summary','fixture_manifest','jdk_manifest','jadx_binary','jadx_jar','guard','target_scanner','focused_runner','focused_manifest_module','source_closure_module'):
  check_pin(prep[key])
 for group in ('fixture_sources','fixture_source8_target8_classes'):
  for row in prep[group]: check_pin(row)
 for lane in prep['original_lanes']:
  for key in ('class','javap_stdout','main_stdout'):
   check_pin(lane[key])
  if lane.get('null_runner_stdout'): check_pin(lane['null_runner_stdout'])
  for key in ('compile_command','javap_command','run_command','null_runner_command'):
   if lane.get(key):
    for stream in lane[key].get('streams',{}).values(): check_pin(stream)
    if lane[key].get('exit_code')!=0 or lane[key].get('guard_stop') is not None: raise RuntimeError('fixed original JVM lane failed')
 rdoc=read_json(receipt); build=verify_build_receipt(cli,receipt,rdoc,prep)
 jdk_manifest=read_json(prep['jdk_manifest']['path']); legs={}
 for row in jdk_manifest['legs']:
  name=row['leg']; tools={}
  if name not in ('javac8','javac23'): continue
  for tool in ('javac','java','javap'):
   tools[tool]=Path(row['jdk_tools'][tool]['path']).resolve()
   if pin(tools[tool])['sha256']!=row['jdk_tools'][tool]['sha256']: raise RuntimeError('pinned JDK changed '+name+'/'+tool)
  legs[name]={'tools':tools,'home':tools['java'].parent.parent,'pins':row['jdk_tools']}
 if set(legs)!={'javac8','javac23'}: raise RuntimeError('JDK8/JDK23 tool pins missing')
 guard=load_module(prep['guard']['path'],'field_comparison_guard')
 scanner=load_module(prep['target_scanner']['path'],'field_comparison_target_scanner')
 out.mkdir(parents=True); (out/'raw').mkdir(); (out/'inputs').mkdir()
 guard.ROOT=ROOT; guard.OUT=out/'raw'; guard.ENV_VALUES={}; guard.expected_test_summaries=lambda i,s:None
 guard.target_bytes=lambda:scanner.target_bytes(ROOT)
 guard.command_stream=lambda p:{'path':str(Path(p).resolve()),'bytes':Path(p).stat().st_size,'sha256':sha(Path(p).read_bytes())}
 sources=[Path(x['path']) for x in prep['fixture_sources']]
 source_map={p.name:p for p in sources}
 runner_src=source_map['Runner.java']
 jadx=Path(prep['jadx_binary']['path']); jadx_java_home=legs['javac23']['home']
 tracked=[Path(__file__),PINS_PATH,Path(__file__).with_name('check.py'),Path(__file__).with_name('README.md'),
          cli,receipt,Path(rdoc['runner']['path']),Path(rdoc['command_spec']['path']),
          Path(prep['original_execution']['path']),Path(prep['original_summary']['path']),Path(prep['null_original_execution']['path']),Path(prep['null_original_summary']['path']),
          Path(prep['fixture_manifest']['path']),Path(prep['jdk_manifest']['path']),jadx,Path(prep['jadx_jar']['path']),Path(prep['guard']['path']),Path(prep['target_scanner']['path']),FOCUS,FOCUS_MOD,CLOSURE_MOD,
          *[Path(x['path']) for x in prep['fixture_sources']],*[Path(x['path']) for x in prep['fixture_source8_target8_classes']],
          *[Path(x['path']) for x in prep['original_lanes'] for key in ('class','javap_stdout','main_stdout','null_runner_stdout') if key in x]]
 for lane in prep['original_lanes']:
  for key in ('compile_command','javap_command','run_command','null_runner_command'):
   for stream in lane.get(key,{}).get('streams',{}).values(): tracked.append(Path(stream['path']))
 tracked.extend(p for row in legs.values() for p in row['tools'].values())
 input_before=[pin(p) for p in tracked]
 for p in [Path(__file__),PINS_PATH,Path(__file__).with_name('check.py'),Path(__file__).with_name('README.md'),runner_src,receipt,Path(rdoc['command_spec']['path'])]:
  if p.is_file():
   name=p.name if p!=receipt and p!=Path(rdoc['command_spec']['path']) else ('focused-receipt.json' if p==receipt else 'focused-command-spec.json')
   shutil.copyfile(p,out/'inputs'/name)
 doc={'schema':SCHEMA,'status':'running','output_root':str(out),'candidate_cli':pin(cli),'candidate_focused_receipt':pin(receipt),'candidate_focused_build':build,
      'baseline_sources':prep['fixture_sources'],'baseline_classes':prep['fixture_source8_target8_classes'],
      'baseline_receipt_pins':{k:prep[k] for k in ('original_execution','original_summary','null_original_execution','null_original_summary','fixture_manifest')},
      'original_jvm_six_lanes':prep['original_lanes'],'jdk_legs':legs,
      'tool_pins':{k:prep[k] for k in ('jdk_manifest','jadx_binary','jadx_jar','guard','target_scanner','focused_runner','focused_manifest_module','source_closure_module')},
      'resource_guard':prep['resource_limits'],'commands':[],'candidate_lanes':[],'jadx_lanes':[],
      'source_tool_pins_before':input_before}
 dump(out/'execution.json',doc)
 def run(label,argv,home):
  idx=len(doc['commands'])+1; row={'index':idx,'label':label,'argv':[str(x) for x in argv],
       'cwd':str(ROOT),'java_home':str(home),'state':'started','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  doc['commands'].append(row); dump(out/'execution.json',doc)
  result=guard.run_command(idx,row['argv'],prepare_environment(home)); row.update(result); row['label']=label
  row['state']='guard-stopped' if row.get('guard_stop') else 'observed'
  for meta in row.get('streams',{}).values():
   p=Path(meta['path']); meta.update(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
  dump(out/'execution.json',doc)
  if row.get('guard_stop'): raise RuntimeError('resource guard stopped '+label)
  return row,Path(row['streams']['stdout']['path']).read_bytes(),Path(row['streams']['stderr']['path']).read_bytes()
 def compile_and_run(label,sourcefiles,leg,mode,runclass,classdir):
  classdir.mkdir(parents=True); empty=classdir.parent/'empty-classpath'; empty.mkdir()
  flags=['-source','8','-target','8','-Xlint:-options'] if leg=='javac8' else ['--release','8']
  comp,_,_=run(label+'-compile',[legs[leg]['tools']['javac'],*flags,'-proc:none','-g' if mode=='debug' else '-g:none',
                    '-classpath',empty,'-sourcepath',empty,'-d',classdir,*sourcefiles],legs[leg]['home'])
  ran=None; stdout=b''; stderr=b''
  if comp.get('exit_code')==0 and comp.get('guard_stop') is None:
   ran,stdout,stderr=run(label+'-run',[legs[leg]['tools']['java'],'-Xverify:all','-cp',classdir,runclass],legs[leg]['home'])
  classes=[pin(p) for p in sorted(classdir.rglob('*.class'))]
  return {'compile':comp,'run':ran,'runtime_state':'ran' if ran else 'no-runtime','classes':classes},stdout,stderr
 original_lanes={(x['jdk'],x['mode']):x for x in prep['original_lanes'] if x['target_mode']=='source8-target8'}
 if len(original_lanes)!=4: raise RuntimeError('source8/target8 original lanes missing')
 # Jarde class-source render and whole-class Runner compile/run: four fixed source8/target8 lanes.
 for jdk in ('javac8','javac23'):
  for mode in ('debug','none'):
   base=original_lanes[(jdk,mode)]; label=f'candidate-{jdk}-{mode}'; folder=out/'candidate'/label; folder.mkdir(parents=True)
   cf=Path(base['class']['path'])
   render,raw,err=write_class_source_command(cli,cf,folder,legs[jdk]['home'],run)
   rawfile=folder/'response.raw.json'; rawfile.write_bytes(raw)
   javap_text=Path(base['javap_stdout']['path']).read_text(encoding='utf-8',errors='replace')
   expected_bcis={
    'instanceFields.value':method_bytecode_targets(javap_text,'instanceFields','value','I','I'),
    'instanceFields.volatileValue':method_bytecode_targets(javap_text,'instanceFields','volatileValue','I','I'),
    'objectFieldBeforeLaterField.payload':method_bytecode_targets(javap_text,'objectFieldBeforeLaterField','payload','Ljava/lang/Object;','Ljava/lang/Object;'),
   }
   lane={'label':label,'jdk':jdk,'mode':mode,'input_class':base['class'],'render_command':render,'expected_source_map_bcis':expected_bcis,

         'render_stdout':pin(rawfile),'render_stderr_sha256':sha(err),'runtime_state':'no-runtime',
         'original_main_stdout':base['main_stdout'],'original_null_runner_stdout':base['null_runner_stdout']}
   if render.get('exit_code')==0:
    try: result=json.loads(raw.decode('utf-8'))
    except Exception as exc: result={'parse_error':type(exc).__name__+': '+str(exc)}
    lane['report']=result; dump(folder/'report.json',result); lane['report_pin']=pin(folder/'report.json')
    generated=result.get('text') if isinstance(result,dict) else None
    if isinstance(generated,str):
     src=folder/'OrderedFieldConcat.java'; src.write_text(generated,encoding='utf-8'); lane['generated_source']=pin(src)
     lane['class_identity']=result.get('class'); lane['class_source_outcome']=result.get('outcome'); lane['execution']=result.get('execution')
     lane['source_package']=package_of(generated); lane['source_class']=class_of(generated)
     maps=report_methods(result,generated); dump(folder/'source-map-methods.json',maps); lane['source_map_methods']=pin(folder/'source-map-methods.json')
     adapter,outtext=add_runner_prefix(runner_src,lane['source_package'],out/'inputs'/'derived-runner'/label/'Runner.java')
     lane['derived_runner']=pin(adapter); lane['derived_runner_sha256']=sha(outtext.encode())
     record,stdout,stderr=compile_and_run(label,[src,adapter],jdk,mode,(lane['source_package']+'.Runner') if lane['source_package'] else 'Runner',out/'candidate'/'classes'/label)
     lane['compile_run']=record; lane['runtime_state']=record['runtime_state']; lane['candidate_stdout']=record['run']['streams']['stdout'] if record.get('run') else None
     lane['candidate_stderr']=record['run']['streams']['stderr'] if record.get('run') else None
     lane['stdout_comparison']={'baseline_sha256':base['null_runner_stdout']['sha256'],'candidate_sha256':sha(stdout) if record.get('run') else None,
                                'byte_identical':bool(record.get('run') and stdout==Path(base['null_runner_stdout']['path']).read_bytes())}
     lines=stdout.decode('utf-8',errors='replace').splitlines()
     line=lambda prefix: next((x for x in lines if x.startswith(prefix)),None)
     explicit=line('explicitValueOfControl='); builder=line('builderObjectFieldControl='); plain=line('plainPlusControl=')
     def control_value(x):
      if x is None:return None
      return x.split(' calls=',1)[0].split('=',1)[1]
     lane['conversion_controls']={'plain_plus':plain,'explicit_value_of':explicit,'builder_field':builder,
       'explicit_equals_builder':control_value(explicit)==control_value(builder) if explicit and builder else None,
       'plain_plus_observed_only':True}
    else:
     lane['render_no_text_reason']='successful CLI exit but no string text field in response'
   doc['candidate_lanes'].append(lane); dump(out/'execution.json',doc)
 # JADX default/none: four matching fixed source8/target8 lanes, real outcomes retained.
 for jdk in ('javac8','javac23'):
  for mode in ('debug','none'):
   base=original_lanes[(jdk,mode)]; label=f'jadx-{jdk}-{mode}'; folder=out/'jadx'/label; folder.mkdir(parents=True)
   output=folder/'decompiled'; args=[jadx,'--no-res','--config','none','--threads-count','1']
   if mode=='none': args.extend(['--rename-flags','none'])
   args.extend(['-d',output,Path(base['class']['path'])])
   render,raw,err=run(label+'-render',args,jadx_java_home)
   sources=sorted(output.rglob('OrderedFieldConcat.java')) if output.exists() else []
   lane={'label':label,'jdk':jdk,'mode':mode,'jadx_profile':'default' if mode=='debug' else 'none',
         'input_class':base['class'],'render_command':render,'render_stdout_sha256':sha(raw),'render_stderr_sha256':sha(err),
         'generated_sources':[pin(p) for p in sources],'runtime_state':'no-runtime',
         'original_null_runner_stdout':base['null_runner_stdout']}
   if render.get('exit_code')==0 and len(sources)==1:
    src=sources[0]; generated=src.read_text(encoding='utf-8'); lane['source_package']=package_of(generated); lane['source_class']=class_of(generated)
    adapter,outtext=add_runner_prefix(runner_src,lane['source_package'],out/'inputs'/'derived-runner'/label/'Runner.java')
    lane['derived_runner']=pin(adapter); lane['derived_runner_sha256']=sha(outtext.encode())
    record,stdout,stderr=compile_and_run(label,[src,adapter],jdk,mode,(lane['source_package']+'.Runner') if lane['source_package'] else 'Runner',out/'jadx'/'classes'/label)
    lane['compile_run']=record; lane['runtime_state']=record['runtime_state']; lane['candidate_stdout']=record['run']['streams']['stdout'] if record.get('run') else None
    lane['candidate_stderr']=record['run']['streams']['stderr'] if record.get('run') else None
    lane['stdout_comparison']={'baseline_sha256':base['null_runner_stdout']['sha256'],'candidate_sha256':sha(stdout) if record.get('run') else None,
                               'byte_identical':bool(record.get('run') and stdout==Path(base['null_runner_stdout']['path']).read_bytes())}
   elif render.get('exit_code')==0:
    lane['render_diagnostic']='expected exactly one OrderedFieldConcat.java from successful JADX render'
   doc['jadx_lanes'].append(lane); dump(out/'execution.json',doc)
 # Pair the three actual whole-class executions by JDK/profile; keep differences as observations.
 candidate_by={(x['jdk'],x['mode']):x for x in doc['candidate_lanes']}
 jadx_by={(x['jdk'],x['mode']):x for x in doc['jadx_lanes']}
 doc['three_way_lanes']=[]
 for key in sorted(original_lanes):
  original=original_lanes[key]; cand=candidate_by[key]; jadx_row=jadx_by[key]
  cand_hash=cand.get('stdout_comparison',{}).get('candidate_sha256')
  jadx_hash=jadx_row.get('stdout_comparison',{}).get('candidate_sha256')
  original_hash=original['null_runner_stdout']['sha256']
  doc['three_way_lanes'].append({'jdk':key[0],'mode':key[1],
      'original_stdout_sha256':original_hash,'jarde_stdout_sha256':cand_hash,'jadx_stdout_sha256':jadx_hash,
      'jarde_runtime_state':cand.get('runtime_state'),'jadx_runtime_state':jadx_row.get('runtime_state'),
      'jarde_exit_code':cand.get('compile_run',{}).get('run',{}).get('exit_code') if cand.get('compile_run',{}).get('run') else None,
      'jadx_exit_code':jadx_row.get('compile_run',{}).get('run',{}).get('exit_code') if jadx_row.get('compile_run',{}).get('run') else None,
      'jarde_matches_original':bool(cand_hash and cand_hash==original_hash),
      'jadx_matches_original':bool(jadx_hash and jadx_hash==original_hash),
      'jarde_matches_jadx':bool(cand_hash and jadx_hash and cand_hash==jadx_hash)})
 # Bind all immutable inputs and each command's actual raw streams before publishing final receipt.
 after=[pin(p) for p in tracked]; doc['source_tool_pins_after']=after
 doc['source_tool_inputs_unchanged']=input_before==after
 doc['actual_command_count']=len(doc['commands']); doc['actual_candidate_lane_count']=len(doc['candidate_lanes']); doc['actual_jadx_lane_count']=len(doc['jadx_lanes'])
 doc['status']='observed' if doc['source_tool_inputs_unchanged'] and len(doc['candidate_lanes'])==4 and len(doc['jadx_lanes'])==4 else 'failed'
 if doc['status']!='observed': doc['failure']={'type':'InputChangedOrIncomplete','message':'source/tool pins changed or lane set incomplete'}
 dump(out/'execution.json',doc)
 return 0 if doc['status']=='observed' else 1

if __name__=='__main__':
 try: raise SystemExit(main())
 except SystemExit: raise
 except BaseException as exc:
  if len(sys.argv)==4:
   p=Path(sys.argv[3]).resolve()/'execution.json'
   if p.is_file():
    try:
     doc=read_json(p); doc['status']='failed'; doc['failure']={'type':type(exc).__name__,'message':str(exc),'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}; dump(p,doc)
    except BaseException: pass
  raise
