#!/usr/bin/env python3
"""Freeze known original fixture/JVM evidence pins; runs no external toolchain."""
import hashlib, json
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
HERE=Path(__file__).resolve().parent
FIXTURE=ROOT/'tests/fixtures/proved-ordered-field-concat'
ORIGINAL=Path('/private/tmp/jarde-ordered-field-concat-original-root-v2')
NULL=Path('/private/tmp/jarde-ordered-field-concat-null-original-root-v2')
JDK_MANIFEST=ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JADX=Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_JAR=Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
GUARD=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
FOCUS=Path('/private/tmp/jarde-loop-focused-runner-root-v1.py')
FOCUS_MOD=Path('/private/tmp/jarde-cf11-structured-list-focused-runner-prep-luna-v7/run.py')
CLOSURE_MOD=Path('/private/tmp/jarde-iterator-assignment-full-validation-prep-luna-v2/workspace_runner.py')

def pin(p):
 p=Path(p); b=p.read_bytes(); return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
orig_exec=load(ORIGINAL/'execution.json'); orig_sum=load(ORIGINAL/'root-summary.json')
null_exec=load(NULL/'execution.json'); null_sum=load(NULL/'root-summary.json')
fixture_manifest=load(FIXTURE/'manifest.json')
assert orig_sum.get('status')=='accepted_original_fixture_observations_only'
assert null_sum.get('status')=='accepted_original_null_receiver_observations_only'
assert len(orig_sum.get('observations',[]))==6 and len(null_sum.get('observations',[]))==6
assert orig_exec.get('status')=='commands_passed_pending_independent_acceptance' and orig_exec.get('target_absent') is True
assert null_exec.get('status')=='commands_passed_pending_independent_acceptance' and null_exec.get('target_absent') is True

# These are the six positive Runner invocations in root execution command order.
positive_compiles=[]
for row in orig_exec['commands']:
 argv=row.get('argv',[])
 if argv and Path(argv[0]).name=='javac' and any(Path(x).name=='OrderedFieldConcat.java' for x in argv):
  positive_compiles.append(row)
assert len(positive_compiles)==6
lanes=[]
null_observations={x['lane']:x for x in null_sum['observations']}
null_runs=[]
for row in null_exec['commands']:
 argv=row.get('argv',[])
 if argv and Path(argv[0]).name=='java' and argv[-1]=='Runner': null_runs.append(row)
assert len(null_runs)==6
# Original summary observations are ordered: source8 j8 debug/none, source8 j23 debug/none, default j23 debug/none.
for idx, comp in enumerate(positive_compiles):
 argv=comp['argv']; outdir=Path(argv[argv.index('-d')+1])
 jdk='javac8' if 'corretto-1.8.0_432' in argv[0] else 'javac23'
 mode='none' if '-g:none' in argv else 'debug'
 target_mode='source8-target8' if '-source' in argv else 'source-default'
 javap=next(r for r in orig_exec['commands'] if r.get('argv',[]) and Path(r['argv'][0]).name=='javap' and str(outdir) in r['argv'])
 run=next(r for r in orig_exec['commands'] if r.get('argv',[]) and Path(r['argv'][0]).name=='java' and str(outdir) in r['argv'] and r['argv'][-1]=='Runner')
 cls=outdir/'OrderedFieldConcat.class'
 if target_mode=='source8-target8':
  frozen=FIXTURE/f'{jdk}-{mode}'/'OrderedFieldConcat.class'
  assert pin(frozen)['sha256']==pin(cls)['sha256']
  cls=frozen
 main_stdout=Path(run['streams']['stdout']['path'])
 lane={'id':f'{jdk}-{target_mode}-{mode}','jdk':jdk,'mode':mode,'target_mode':target_mode,
       'class':pin(cls),'javap_stdout':pin(Path(javap['streams']['stdout']['path'])),
       'main_stdout':pin(main_stdout),'compile_command':comp,'javap_command':javap,'run_command':run,
       'original_summary_observation':orig_sum['observations'][idx]}
 # The supplemental null-receiver receipt covers the same six ordered lanes.
 nb=null_runs[idx]
 lane['null_runner_stdout']=pin(Path(nb['streams']['stdout']['path']))
 lane['null_runner_command']=nb
 lane['null_summary_observation']=null_observations[idx]
 lanes.append(lane)

sources=[pin(FIXTURE/n) for n in ['OrderedFieldConcat.java','OrderedFieldConcatNegatives.java','Runner.java','NegativeRunner.java']]
classes=[]
for jdk in ['javac8','javac23']:
 for mode in ['debug','none']:
  p=FIXTURE/f'{jdk}-{mode}'/'OrderedFieldConcat.class'
  row=next(x for x in fixture_manifest['classes'] if x['path']==f'tests/fixtures/proved-ordered-field-concat/{jdk}-{mode}/OrderedFieldConcat.class')
  q=pin(p); assert q['bytes']==row['bytes'] and q['sha256']==row['sha256']
  classes.append(q)

pins={
 'schema':'jarde-ordered-field-concat-comparison-pins-v1',
 'workspace_root':str(ROOT),
 'fixture_root':str(FIXTURE),
 'original_execution':pin(ORIGINAL/'execution.json'),
 'original_summary':pin(ORIGINAL/'root-summary.json'),
 'null_original_execution':pin(NULL/'execution.json'),
 'null_original_summary':pin(NULL/'root-summary.json'),
 'fixture_manifest':pin(FIXTURE/'manifest.json'),
 'fixture_sources':sources,
 'fixture_source8_target8_classes':classes,
 'jdk_manifest':pin(JDK_MANIFEST),
 'jadx_binary':pin(JADX),
 'jadx_jar':pin(JADX_JAR),
 'guard':pin(GUARD),
 'target_scanner':pin(SCANNER),
 'focused_runner':pin(FOCUS),
 'focused_manifest_module':pin(FOCUS_MOD),
 'source_closure_module':pin(CLOSURE_MOD),
 'jdk_legs':load(JDK_MANIFEST)['legs'],
 'original_lanes':lanes,
 'resource_limits':{'minimum_free_bytes':5368709120,'maximum_target_bytes':1073741824,'sample_interval_seconds':1},
}
(HERE/'pins.json').write_text(json.dumps(pins,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
