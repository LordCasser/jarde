#!/usr/bin/env python3
"""Archive accepted workspace-v9 evidence after independently supplied acceptance."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import pathlib
import re
import tarfile

REPO = pathlib.Path('/Users/lordcasser/workspace/projects/jarde')
RUN = pathlib.Path('/private/tmp/jarde-ordered-field-full-workspace-run-root-v9')
PREP = pathlib.Path('/private/tmp/jarde-wrap-validation-prep-luna-v1')
ACCEPT_PREP = pathlib.Path('/private/tmp/jarde-wrap-workspace-acceptance-prep-luna-v2')
DEST = REPO / 'openspec/changes/recover-ordered-field-concat-operands/results/full-workspace-accepted-root-v9'
FOCUSED_CLI_SHA256 = 'c8c18f26a256027262b514455c33f24d0ae1cbcec658e3d6ab76b2c3a9c2ccfd'
SEEDS = ('5350648285461741569', '5350648285461741570')
RUNNER_PATH = PREP / 'workspace/workspace_runner.py'
ACCEPTOR_PATH = ACCEPT_PREP / 'accept_workspace.py'
OWN_CI_PATH = ACCEPT_PREP / 'verify-own-ci.py'


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def file_pin(path: pathlib.Path) -> dict[str, object]:
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}


def member_pin(source: pathlib.Path | bytes) -> dict[str, object]:
    raw = source if isinstance(source, bytes) else source.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def read_json(path: pathlib.Path) -> tuple[dict, bytes]:
    require(path.is_file() and not path.is_symlink(), f'missing or linked file: {path}')
    raw = path.read_bytes()
    value = json.loads(raw)
    require(isinstance(value, dict), f'expected JSON object: {path}')
    return value, raw


def verify_local_archive(local_archive_dir: pathlib.Path) -> dict:
    local_archive_dir = local_archive_dir.resolve(strict=True)
    local_archive = local_archive_dir / 'capture.tar.gz'
    local_manifest = local_archive_dir / 'manifest.json'
    manifest, manifest_raw = read_json(local_manifest)
    require(manifest.get('archive', {}).get('path') == 'capture.tar.gz', 'local archive path differs from its manifest')
    rows = manifest.get('members')
    require(manifest.get('schema') == 1 and isinstance(rows, list) and rows,
            'local archive manifest schema/member list differs')
    archive_raw = local_archive.read_bytes()
    archive_pin = manifest['archive']
    require(len(archive_raw) == archive_pin.get('bytes') and sha(archive_raw) == archive_pin.get('sha256'),
            'local archive digest differs from its manifest')
    expected = {row['path']: row for row in rows}
    require(len(expected) == len(rows), 'local archive manifest has duplicate members')
    with tarfile.open(local_archive, 'r:gz') as tf:
        files = {item.name: item for item in tf.getmembers() if item.isfile()}
        require(set(files) == set(expected), 'local archive member set differs from its manifest')
        for name, row in expected.items():
            raw = tf.extractfile(files[name]).read()
            require(len(raw) == row.get('bytes') and sha(raw) == row.get('sha256'),
                    f'local archive member pin differs: {name}')
    return {
        'archive_path': str(local_archive),
        'archive_bytes': len(archive_raw),
        'archive_sha256': sha(archive_raw),
        'manifest_path': str(local_manifest),
        'manifest_sha256': sha(manifest_raw),
        'member_count': len(rows),
        'members': [{'path': row['path'], 'bytes': row['bytes'], 'sha256': row['sha256']} for row in rows],
        'copied_into_workspace_v9_archive': False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('acceptance', type=pathlib.Path, help='accepted-local-workspace JSON produced by accept_workspace.py')
    parser.add_argument('expected_sha256', help='expected SHA-256 of the acceptance JSON')
    parser.add_argument('--focused-receipt', type=pathlib.Path, required=True)
    parser.add_argument('--focused-sha256', required=True)
    parser.add_argument('--focused-root-summary', type=pathlib.Path, required=True)
    parser.add_argument('--focused-root-summary-sha256', required=True)
    parser.add_argument('--local-archive-dir', type=pathlib.Path, required=True,
                        help='directory containing capture.tar.gz and its manifest.json')
    args = parser.parse_args()
    require(re.fullmatch(r'[0-9a-f]{64}', args.expected_sha256) is not None, 'expected SHA-256 must be lowercase hex')
    require(not DEST.exists(), f'refusing to overwrite existing destination: {DEST}')

    acceptance, acceptance_raw = read_json(args.acceptance.resolve(strict=True))
    require(sha(acceptance_raw) == args.expected_sha256, 'acceptance SHA-256 differs from the supplied expected value')
    require(acceptance.get('schema') == 'ordered-field-full-workspace-acceptance-v2', 'acceptance schema differs')
    require(acceptance.get('status') == 'accepted_local_workspace_only', 'acceptance is not accepted local workspace evidence')
    require(acceptance.get('not_ci_or_product_release_acceptance') is True, 'acceptance scope marker differs')
    require(acceptance.get('target_absent') is True, 'acceptance does not confirm target cleanup')

    execution_path = RUN / 'execution.json'
    execution, execution_raw = read_json(execution_path)
    require(sha(execution_raw) == acceptance.get('execution_sha256'), 'acceptance is not bound to workspace-v9 execution bytes')
    require(execution.get('schema') == 'ordered-field-full-workspace-run-v2', 'workspace execution schema differs')
    require(execution.get('status') == 'passed', 'workspace execution is not terminal-passed')
    rows = execution.get('commands')
    expected_count = execution.get('expected_command_count_including_clean')
    observed_count = execution.get('observed_command_count_including_clean')
    require(isinstance(rows, list) and isinstance(expected_count, int) and isinstance(observed_count, int),
            'workspace command inventory is missing')
    require(expected_count == 195 and len(rows) == expected_count == observed_count,
            'actual terminal command count differs from the 195-command receipt inventory')
    require(execution.get('expected_batch_count') == 96 and execution.get('expected_target_count') == 364,
            'workspace frozen batch/target inventory differs')
    require(acceptance.get('batch_count_per_seed') == 96 and acceptance.get('target_count') == 364,
            'acceptance batch/target inventory differs from workspace receipt')
    require(acceptance.get('test_totals', {}).get('failed') == 0 and
            acceptance.get('test_totals', {}).get('target_summary_count') > 0,
            'acceptance includes test failures or no target summaries')
    require(execution.get('seeds') == list(SEEDS) and acceptance.get('seeds') == list(SEEDS),
            'workspace and acceptance seed pair differs')
    require(execution.get('target_inventory') and len(execution['target_inventory']) == acceptance['target_count'],
            'workspace target inventory length differs')
    require(execution.get('guard_limits') == {'minimum_free_bytes': 5 * 1024**3,
                                               'maximum_target_bytes': 1024**3,
                                               'poll_interval_seconds': 1},
            'workspace guard limits differ from the pinned runner')
    require(acceptance.get('target_associated_suite_count_per_seed') == {seed: 364 for seed in SEEDS},
            'acceptance does not report every target for both seeds')
    require(execution.get('source_closure_count_at_start') == 4854, 'workspace source closure count differs')
    before, after = execution.get('source_pins_before'), execution.get('source_pins_after')
    require(isinstance(before, dict) and len(before) == 4854 and before == after,
            'workspace 4,854-source pins are absent or changed')
    require(acceptance.get('source_pin_count') == len(before), 'acceptance source pin count differs')

    require(rows[0].get('index') == 0 and rows[0].get('argv') == ['cargo', 'fmt', '--all', '--', '--check'],
            'command index 0 is not the recorded format check')
    require(rows[1].get('index') == 1 and rows[1].get('argv') == ['cargo', 'metadata', '--no-deps', '--format-version', '1', '--locked'],
            'command index 1 is not the recorded metadata command')
    require([row.get('index') for row in rows] == list(range(expected_count)), 'command indices are not contiguous')
    require(all(row.get('exit_code') == 0 and row.get('guard_stop') is None for row in rows),
            'workspace receipt contains a failed or guarded command')
    for row in rows:
        require(row.get('cwd') == str(REPO), f"command {row.get('index')} working directory differs")
        if row.get('cleanup_only') is not None:
            proof = row['cleanup_only']
            require(row is rows[-1] and row.get('argv') == ['cargo', 'clean'] and
                    proof.get('exact_argv') == ['cargo', 'clean'] and
                    proof.get('space_precheck_bypassed') is True and
                    proof.get('space_monitor_abort_bypassed') is True and
                    all(type(proof.get(side, {}).get(key)) is int and proof[side][key] >= 0
                        for side in ('observed_before', 'observed_after') for key in ('target_bytes', 'free_bytes')) and
                    row.get('free_bytes_after') == proof['observed_after']['free_bytes'] and
                    row.get('peak_target_bytes') >= max(proof['observed_before']['target_bytes'],
                                                        proof['observed_after']['target_bytes']),
                    'cleanup guard bypass is not limited to exact cargo clean observations')
        else:
            require(type(row.get('peak_target_bytes')) is int and row['peak_target_bytes'] <= 1024**3 and
                    type(row.get('free_bytes_after')) is int and row['free_bytes_after'] >= 5 * 1024**3,
                    f"command {row.get('index')} exceeded a workspace resource guard")
    test_rows = [row for row in rows if row.get('argv', [])[:2] == ['cargo', 'test']]
    require(len(test_rows) == 192, 'workspace does not contain 192 test batches across two seeds')
    per_seed = {seed: 0 for seed in SEEDS}
    for row in test_rows:
        seed = row.get('env_overrides', {}).get('PROPTEST_RNG_SEED')
        require(seed in per_seed, f'test batch has an unknown seed: {seed}')
        per_seed[seed] += 1
    require(per_seed == {seed: 96 for seed in SEEDS}, 'test batches are not 96 per seed')
    clean = rows[-1]
    require(clean.get('argv') == ['cargo', 'clean'] and clean.get('exit_code') == 0 and clean.get('guard_stop') is None,
            'final command is not a successful exact cargo clean')
    cleanup = execution.get('cleanup', {})
    require(cleanup.get('status') == 'passed' and cleanup.get('target_absent_after') is True and
            cleanup.get('pins_unchanged') is True and cleanup.get('source_pins_after') == before and
            cleanup.get('command', {}).get('argv') == ['cargo', 'clean'] and
            cleanup.get('command', {}).get('exit_code') == 0,
            'final cleanup is not successful or target directory remains')

    require(re.fullmatch(r'[0-9a-f]{64}', args.focused_sha256) is not None, 'focused receipt SHA must be lowercase hex')
    require(re.fullmatch(r'[0-9a-f]{64}', args.focused_root_summary_sha256) is not None,
            'focused root summary SHA must be lowercase hex')
    focused_path = args.focused_receipt.resolve(strict=True)
    focused, focused_raw = read_json(focused_path)
    require(sha(focused_raw) == args.focused_sha256, 'focused receipt SHA differs from the supplied value')
    require(execution.get('focused_input_receipt', {}).get('path') == str(focused_path) and
            execution.get('focused_input_receipt', {}).get('sha256') == args.focused_sha256 and
            acceptance.get('focused_receipt_sha256') == args.focused_sha256,
            'workspace-v9 and acceptance do not bind the focused receipt')
    require(focused.get('status') == 'commands_passed_pending_independent_acceptance' and
            focused.get('target_absent') is True and
            focused.get('source_manifest_before') == focused.get('source_manifest_after') and
            len(focused.get('commands', [])) == 8 and
            all(row.get('exit_code') == 0 and row.get('guard_stop') is None for row in focused['commands']),
            'focused summary inputs do not match the completed eight-command receipt')
    require(focused.get('cli', {}).get('sha256') == FOCUSED_CLI_SHA256,
            'focused CLI identity differs from the pinned candidate')
    require(len(focused.get('source_manifest_before', [])) == 4854,
            'focused receipt source manifest count differs')
    root_summary, root_summary_raw = read_json(args.focused_root_summary.resolve(strict=True))
    require(sha(root_summary_raw) == args.focused_root_summary_sha256,
            'focused root summary SHA differs from the supplied value')
    require(root_summary.get('status') == 'accepted_final_local_checks_new_product_pending_runtime' and
            root_summary.get('source_count') == 4854 and root_summary.get('full_class_runtime_accepted') is False,
            'focused root summary status/source/runtime scope differs')
    cli = focused['cli']
    cli_path = pathlib.Path(cli['path'])
    require(cli_path.is_file() and not cli_path.is_symlink() and file_pin(cli_path) ==
            {'bytes': cli.get('bytes'), 'sha256': FOCUSED_CLI_SHA256},
            'focused candidate CLI bytes/SHA differ from the accepted identity')
    required_rows = root_summary.get('required_tests', [])
    require(len(required_rows) == 2 and
            [(sum(int(x[1]) for x in row['summaries']), sum(int(x[2]) for x in row['summaries']),
              sum(int(x[3]) for x in row['summaries'])) for row in required_rows] == [(569, 0, 0), (136, 0, 4)],
            'focused root summary does not preserve 391+178 census and 136/0/4 integration totals')
    summaries = [summary for command in required_rows for summary in command.get('summaries', [])]
    require((sum(int(s[1]) for s in summaries), sum(int(s[2]) for s in summaries), sum(int(s[3]) for s in summaries)) == (705, 0, 4),
            'focused root summary totals differ from the accepted 705/0/4 result')
    focused_summary = {
        'path': str(focused_path), 'sha256': sha(focused_raw), 'status': focused['status'],
        'command_count': len(focused['commands']), 'target_absent': focused['target_absent'],
        'source_manifest_count': len(focused['source_manifest_before']),
        'root_summary_path': str(args.focused_root_summary.resolve(strict=True)),
        'root_summary_sha256': sha(root_summary_raw), 'root_summary_source_count': root_summary['source_count'],
        'root_summary_totals': {'passed': 705, 'failed': 0, 'ignored': 4},
        'candidate_cli_sha256': focused['cli']['sha256'],
        'commands': [{'index': row['index'], 'argv': row['argv'], 'exit_code': row['exit_code']} for row in focused['commands']],
    }
    local_archive_reference = verify_local_archive(args.local_archive_dir)

    pinned_tools = json.loads((ACCEPT_PREP / 'pins.json').read_text())
    tool_specs = [
        ('workspace-runner.py', RUNNER_PATH, '557d1decba94c3f0e58fee22c7335de77f3087c9337924824724f0412135c38f'),
        ('workspace-acceptor-v2.py', ACCEPTOR_PATH, '5a0ba7f3e763706701117017fd628383c7281ee288e3af902a01bfcdaa8f1d4c'),
        ('workspace-own-ci-v2.py', OWN_CI_PATH, 'e1e9544af84c3397e170f2720743eab479e21e500a677b2f680431e22e567df9'),
    ]
    focused_summary_raw = (json.dumps(focused_summary, indent=2) + '\n').encode()
    local_archive_reference_raw = (json.dumps(local_archive_reference, indent=2) + '\n').encode()
    members: dict[str, pathlib.Path | bytes] = {
        'workspace-v9-execution.json': execution_path,
        'workspace-v9-metadata.json': RUN / 'metadata.json',
        'acceptance.json': args.acceptance.resolve(strict=True),
        'focused-receipt-summary.json': focused_summary_raw,
        'focused-root-summary.json': root_summary_raw,
        'prior-localarchive-reference.json': local_archive_reference_raw,
        'prep/workspace-v2-pins.json': ACCEPT_PREP / 'pins.json',
        'prep/workspace-v2-diff.txt': ACCEPT_PREP / 'changes.diff',
        'prep/workspace-v2-readme.md': ACCEPT_PREP / 'README.md',
        'archive.py': pathlib.Path(__file__).resolve(strict=True),
    }
    for name, path, expected_sha in tool_specs:
        require(path.is_file() and not path.is_symlink(), f'missing pinned tool: {path}')
        pin = pinned_tools.get(str(path))
        require(isinstance(pin, dict) and pin.get('sha256') == expected_sha and
                file_pin(path) == {'bytes': pin.get('bytes'), 'sha256': expected_sha},
                f'prepared tool pin differs: {path}')
        members[name] = path
    for rel, path in [('prep/pins.json', ACCEPT_PREP / 'pins.json'), ('prep/changes.diff', ACCEPT_PREP / 'changes.diff'),
                      ('prep/README.md', ACCEPT_PREP / 'README.md')]:
        require(path.is_file() and not path.is_symlink(), f'missing preparation artifact: {path}')
    metadata_path = RUN / 'metadata.json'
    require(metadata_path.is_file() and not metadata_path.is_symlink(), 'workspace metadata file missing or linked')

    raw_paths: set[pathlib.Path] = set()
    raw_members: set[str] = set()
    for row in rows:
        streams = row.get('streams', {})
        require(set(streams) == {'stdout', 'stderr'}, f"command {row.get('index')} lacks both raw streams")
        for stream_name, ref in streams.items():
            path = pathlib.Path(ref.get('path', '')).resolve(strict=True)
            require(not pathlib.Path(ref.get('path', '')).is_symlink() and path.is_relative_to(RUN.resolve()),
                    f'raw stream escapes or links outside workspace-v9 run: {path}')
            raw = path.read_bytes()
            require(len(raw) == ref.get('bytes') and sha(raw) == ref.get('sha256'), f'raw stream pin differs: {path}')
            require(path not in raw_paths, f'raw stream is referenced more than once: {path}')
            raw_paths.add(path)
            arcname = f'raw/{path.name}'
            require(arcname not in raw_members, f'raw stream basename collision: {arcname}')
            raw_members.add(arcname)
            members[arcname] = path
    actual_raws = {path.resolve() for path in RUN.glob('*.raw') if path.is_file()}
    require(actual_raws == raw_paths, 'workspace-v9 run directory has missing or unreferenced raw streams')
    require(acceptance.get('raw_stream_count') == len(raw_paths), 'acceptance raw stream count differs from the receipt')
    metadata_stdout = rows[1]['streams']['stdout']
    require(json.loads(pathlib.Path(metadata_stdout['path']).read_text()) == json.loads((RUN / 'metadata.json').read_text()),
            'saved metadata differs from command index 1 stdout')

    expected_source_paths = {
        'workspace-v9-execution.json', 'workspace-v9-metadata.json', 'acceptance.json',
        'focused-receipt-summary.json', 'focused-root-summary.json', 'prior-localarchive-reference.json',
        'prep/workspace-v2-pins.json', 'prep/workspace-v2-diff.txt', 'prep/workspace-v2-readme.md',
        'archive.py', 'workspace-runner.py', 'workspace-acceptor-v2.py', 'workspace-own-ci-v2.py',
    } | raw_members
    require(set(members) == expected_source_paths, 'archive member inventory differs from the prepared scope')
    for rel, source in members.items():
        if isinstance(source, pathlib.Path):
            require(source.is_file() and not source.is_symlink(), f'archive source is missing or linked: {rel}')

    summary = (
        '# Workspace v9 local acceptance archive\n\n'
        'This bundle records local full-workspace acceptance only. It makes no product CI or push-clean claim.\n\n'
        f'- Acceptance: `accepted_local_workspace_only`; SHA-256 `{args.expected_sha256}`.\n'
        f'- Workspace receipt SHA-256: `{sha(execution_raw)}`; records `{len(rows)}` (including format check, metadata, and final cleanup).\n'
        f'- Test batches: `{len(test_rows)}` total, 96 for each of the two pinned seeds; target inventory: `{len(execution["target_inventory"])}`.\n'
        f'- Source pins: `{len(before)}` entries; before/after maps match.\n'
        f'- Raw streams: `{len(raw_paths)}` members, each checked against receipt bytes and SHA-256.\n'
        f'- Focused receipt: `{args.focused_sha256}`, summarized in `focused-receipt-summary.json`; the related root summary records 705 passed, 0 failed, 4 ignored.\n'
        f'- Earlier durable archive: `{local_archive_reference["archive_path"]}`; its verified {local_archive_reference["member_count"]}-member archive is referenced by `prior-localarchive-reference.json`, not copied.\n\n'
        'The compressed bundle and the detached manifest list the evidence under the tar member paths; no unpacked payload directory is created.\n'
    )
    DEST.mkdir(parents=True)
    readme_path = DEST / 'README.md'
    readme_path.write_text(summary, encoding='utf-8')
    manifest_rows = []
    for rel, path in sorted(members.items()):
        pin = member_pin(path)
        manifest_rows.append({'path': f'evidence/{rel}', **pin})
    manifest_path = DEST / 'members.json'
    manifest_path.write_text(json.dumps({'schema': 1, 'members': manifest_rows}, indent=2) + '\n', encoding='utf-8')
    archive_path = DEST / 'workspace-v9-accepted.tar.gz'
    with tarfile.open(archive_path, 'w:gz') as tf:
        for rel, path in sorted(members.items()):
            arcname = f'evidence/{rel}'
            if isinstance(path, bytes):
                info = tarfile.TarInfo(arcname)
                info.size = len(path)
                info.mode = 0o644
                tf.addfile(info, io.BytesIO(path))
            else:
                tf.add(path, arcname=arcname)
        tf.add(manifest_path, arcname='members.json')
        tf.add(readme_path, arcname='README.md')
    with tarfile.open(archive_path, 'r:gz') as tf:
        embedded = json.load(tf.extractfile('members.json'))
        expected = {row['path']: row for row in embedded['members']}
        found = {item.name: item for item in tf.getmembers() if item.isfile() and item.name.startswith('evidence/')}
        require(set(found) == set(expected), 'reopened tar member set differs from manifest')
        for name, row in expected.items():
            raw = tf.extractfile(found[name]).read()
            require(len(raw) == row['bytes'] and sha(raw) == row['sha256'], f'reopened tar member pin differs: {name}')
    print(json.dumps({'status': 'archived', 'destination': str(DEST), 'records': len(rows),
                      'test_batches': len(test_rows), 'raw_streams': len(raw_paths),
                      'members': len(manifest_rows), 'archive': str(archive_path)}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
