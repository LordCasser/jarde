#!/usr/bin/env python3
"""Prepare a durable archive of the terminal workspace-v7 WA golden failure."""
from __future__ import annotations

import hashlib
import json
import pathlib
import sys
import tarfile

REPO = pathlib.Path('/Users/lordcasser/workspace/projects/jarde')
RUN = pathlib.Path('/private/tmp/jarde-ordered-field-full-workspace-run-root-v7')
PREP = pathlib.Path('/private/tmp/jarde-wrap-validation-prep-luna-v1')
ACCEPT_V2 = pathlib.Path('/private/tmp/jarde-wrap-workspace-acceptance-prep-luna-v2')
DEST = REPO / 'openspec/changes/recover-ordered-field-concat-operands/results/full-workspace-wa-golden-failure-root-v7'


def digest(path: pathlib.Path) -> tuple[int, str]:
    data = path.read_bytes()
    return len(data), hashlib.sha256(data).hexdigest()


def main() -> int:
    if len(sys.argv) != 1:
        raise SystemExit('usage: python3 archive_failure.py')
    if DEST.exists():
        raise SystemExit(f'refusing to overwrite existing archive destination: {DEST}')
    execution_path = RUN / 'execution.json'
    execution = json.loads(execution_path.read_text())
    if execution.get('status') != 'failed':
        raise SystemExit('execution is not a terminal failure')
    commands = execution.get('commands', [])
    observed = execution.get('observed_command_count_including_clean')
    if not isinstance(observed, int) or len(commands) != observed or execution.get('expected_command_count_including_clean') != 195:
        raise SystemExit('receipt command counts do not match its frozen inventory')
    if execution.get('expected_batch_count') != 96 or execution.get('expected_target_count') != 364:
        raise SystemExit('receipt batch/target inventory changed')
    if not execution.get('cleanup', {}).get('attempted') or execution['cleanup'].get('status') != 'passed':
        raise SystemExit('cleanup did not complete successfully')
    if execution['cleanup'].get('target_absent_after') is not True:
        raise SystemExit('cleanup did not confirm target removal')
    if execution.get('source_pins_before') != execution.get('source_pins_after'):
        raise SystemExit('execution source pins differ')
    if any(c.get('guard_stop') is not None for c in commands):
        raise SystemExit('receipt contains a guard stop')
    if execution['cleanup'].get('pins_unchanged') is not True:
        raise SystemExit('cleanup did not certify unchanged source pins')
    failing = [c for c in commands if c.get('index') == 76]
    if len(failing) != 1:
        raise SystemExit('expected exactly one recorded batch 76')
    batch = failing[0]
    if batch.get('exit_code') != 101 or batch.get('guard_stop') is not None:
        raise SystemExit('batch 76 is not the expected unguarded test failure')
    if batch.get('argv') != ['cargo', 'test', '-p', 'jarde', '--all-features', '--locked', '--message-format', 'json', '--test', 'recover_unicode_identifiers', '--test', 'recover_write_accessor_field_types', '--test', 'same_class_generic_binding', '--test', 'same_class_generic_call_consumers']:
        raise SystemExit('batch 76 command argv differs from the terminal receipt expectation')
    summaries = [(x.get('passed'), x.get('failed'), x.get('status')) for x in batch.get('observed_summaries', [])]
    if summaries != [(4, 0, 'ok'), (8, 1, 'FAILED')]:
        raise SystemExit(f'unexpected batch 76 summaries: {summaries}')
    if any(c.get('exit_code') != 0 for c in commands if c is not batch and c.get('argv') != ['cargo', 'clean']):
        raise SystemExit('a command before the recorded WA failure also failed')
    names = {x.get('name'): x.get('status') for x in batch.get('named_test_outcomes', [])}
    if names.get('the_nine_write_accessor_types_all_recover') != 'FAILED':
        raise SystemExit('expected WA exact-golden test failure is absent')
    if names.get('the_recovered_wa_text_recompiles_and_prints_the_original_line') != 'ok':
        raise SystemExit('same-batch compile/runtime test did not pass')
    failures = [name for name, status in names.items() if status == 'FAILED']
    if failures != ['the_nine_write_accessor_types_all_recover']:
        raise SystemExit(f'unexpected named test failures: {failures}')
    metadata_path = RUN / 'metadata.json'
    if not metadata_path.is_file():
        raise SystemExit('metadata.json is missing')

    source_items = [
        ('workspace-runner.py', PREP / 'workspace/workspace_runner.py'),
        ('workspace-acceptor-old.py', PREP / 'workspace/accept_workspace.py'),
        ('workspace-acceptor-v2.py', ACCEPT_V2 / 'accept_workspace.py'),
        ('own-ci-verifier-v2.py', ACCEPT_V2 / 'verify-own-ci.py'),
        ('wa-test-source-v7.rs', pathlib.Path('/private/tmp/jarde-wa-concat-golden-audit-luna-v1/wa-test-source-v7.rs')),
        ('archive-failure-script.py', pathlib.Path(__file__)),
        ('audit-report.json', pathlib.Path('/private/tmp/jarde-wa-concat-golden-audit-luna-v1/audit.json')),
        ('proposed-test-patch.diff', pathlib.Path('/private/tmp/jarde-wa-concat-golden-audit-luna-v1/proposed-test.patch')),
        ('audit-readme.md', pathlib.Path('/private/tmp/jarde-wa-concat-golden-audit-luna-v1/README.md')),
        ('audit-pins.json', pathlib.Path('/private/tmp/jarde-wa-concat-golden-audit-luna-v1/pins.json')),
        ('wa-frozen-history.txt', REPO / 'openspec/evidence/java-syntax-2026-10-05/recover-write-accessor-field-types/fixed/WA-rendered-fixed.txt'),
        ('focused-v10-commands.json', pathlib.Path('/private/tmp/jarde-ordered-field-final-check-commands-root-v10.json')),
        ('workspace-acceptance-v2-pins.json', ACCEPT_V2 / 'pins.json'),
        ('workspace-acceptance-v2-diff.txt', ACCEPT_V2 / 'changes.diff'),
        ('workspace-acceptance-v2-readme.md', ACCEPT_V2 / 'README.md'),
    ]
    members: dict[str, pathlib.Path] = {
        'execution.json': execution_path,
        'metadata.json': metadata_path,
    }
    for name, path in source_items:
        if not path.is_file():
            raise SystemExit(f'required source missing: {path}')
        members[f'inputs/{name}'] = path
    test_source_pin = execution.get('source_pins_before', {}).get('tests/recover_write_accessor_field_types.rs')
    if not test_source_pin or digest(pathlib.Path('/private/tmp/jarde-wa-concat-golden-audit-luna-v1/wa-test-source-v7.rs'))[1] != test_source_pin:
        raise SystemExit('preserved v7 WA test source does not match the terminal source pin')
    # Preserve every raw stream named by the receipt, including early batches and cleanup.
    for command in commands:
        for stream, record in command.get('streams', {}).items():
            path = pathlib.Path(record['path'])
            if not path.is_file():
                raise SystemExit(f'referenced raw stream missing: {path}')
            size, sha = digest(path)
            if size != record.get('bytes') or sha != record.get('sha256'):
                raise SystemExit(f'referenced raw stream pin mismatch: {path}')
            members[f'raw/{path.name}'] = path

    DEST.mkdir(parents=True)
    manifest = []
    for rel, source in sorted(members.items()):
        size, sha = digest(source)
        manifest.append({'path': rel, 'bytes': size, 'sha256': sha})
    manifest_path = DEST / 'members.json'
    manifest_path.write_text(json.dumps({'schema': 1, 'members': manifest}, indent=2) + '\n')
    readme_path = DEST / 'README.md'
    readme_path.write_text(
        '# Workspace v7 WA golden failure\n\n'
        'This archive preserves the terminal workspace-v7 failure at batch 76. '
        'The WA nine-accessor exact-golden test was the sole named failure; '
        'the recovered-text compile/runtime test passed in the same batch.\n\n'
        f'- Terminal commands recorded: {observed}; expected full inventory: {execution["expected_command_count_including_clean"]}.\n'
        f'- Raw streams: {sum(1 for item in manifest if item["path"].startswith("raw/"))} files.\n'
        '- The receipt, metadata, sources, and raw streams are stored under `payload/` inside the tarball.\n'
        '- Member byte counts and SHA-256 pins: `members.json` (detached beside the tarball and embedded in it).\n'
        '- Compressed evidence: [workspace-v7-wa-golden-failure.tar.gz](workspace-v7-wa-golden-failure.tar.gz)\n'
    )
    archive = DEST / 'workspace-v7-wa-golden-failure.tar.gz'
    with tarfile.open(archive, 'w:gz') as tf:
        for rel, source in sorted(members.items()):
            tf.add(source, arcname=f'payload/{rel}')
        tf.add(manifest_path, arcname='members.json')
        tf.add(readme_path, arcname='README.md')
    # Reopen the archive and verify each member against the detached and embedded manifest.
    with tarfile.open(archive, 'r:gz') as tf:
        embedded = json.load(tf.extractfile('members.json'))
        expected = {x['path']: x for x in embedded['members']}
        found = {m.name.removeprefix('payload/'): m for m in tf.getmembers() if m.isfile() and m.name.startswith('payload/')}
        if set(found) != set(expected):
            raise SystemExit('archive member set differs from manifest')
        for rel, info in expected.items():
            data = tf.extractfile(found[rel]).read()
            if len(data) != info['bytes'] or hashlib.sha256(data).hexdigest() != info['sha256']:
                raise SystemExit(f'archive member verification failed: {rel}')
    print(f'archived {len(manifest)} members from {observed} terminal commands to {DEST}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
