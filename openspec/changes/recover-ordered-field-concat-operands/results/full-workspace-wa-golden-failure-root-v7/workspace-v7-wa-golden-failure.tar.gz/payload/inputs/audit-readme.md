# WA golden failure audit

The terminal workspace-v7 run failed at test batch 76. The raw Rust assertion’s `right` value is byte-identical to the frozen historical `WA-rendered-fixed.txt`; a unified line comparison shows exactly one changed line in the actual `left` value. The changed line is `WA.main`’s println: the renderer now emits the same ordered fields with literal concatenation (`"" + ...`) instead of the old `StringBuilder.append` chain. All nine accessor bodies otherwise remain identical.

The batch’s named outcomes record 8 passing accessor tests, the nine-accessor strict golden as the sole failure, and `the_recovered_wa_text_recompiles_and_prints_the_original_line` as passing. That compile/runtime test includes the original and recovered output comparison, so its successful result confirms those runtime assertions passed. The adjacent other-target summary in the same batch was 4 passed, 0 failed.

`proposed-test.patch` adapts only the expected golden in memory. It asserts that the exact old println literal occurs once, replaces exactly that one literal, and keeps the full-report equality assertion. It leaves the evidence file unchanged. This is an expected-text update; the evidence does not indicate a production regression.

`wa-test-source-v7.rs` is a read-only `git show HEAD` snapshot whose SHA-256 matches the v7 source pin. It is the source that produced the failed run; the current checkout may contain the later focused-v11 test correction.

The archive tool is [archive_failure.py](archive_failure.py). It is prepared but not executed. Running `python3 archive_failure.py` after reviewing it creates the durable bundle at `openspec/changes/recover-ordered-field-concat-operands/results/full-workspace-wa-golden-failure-root-v7`. The script validates the terminal receipt, source pins, cleanup, failure identity, and raw stream hashes; it refuses to overwrite an existing destination, then writes a gzip tarball with a per-member byte/SHA-256 manifest and reopens the tarball to verify every member. It invokes no build or test tools.
