# Workspace acceptance threshold refresh

This new acceptor copy follows the frozen v10 focused raw outputs. The receipt is SHA-pinned at `722c0c738a85fc03cddb2249049f4fd5087002abe0cdd4e35c4df5173acbbf74`. Its two Cargo test stdout streams are SHA-pinned in `pins.json`; parsing the pinned raw bytes confirms the `jarde-java --lib` suite has 391 passed and the `p3_patterns` suite has 92 passed, both with zero failures and ignored tests.

The new acceptor changes only the lib lower bound/description from 390 to 391 and the strict `p3_patterns` expectation/description from 91 to 92. All existing field-name expectations, the per-seed wrap integration gate, source/raw pins, metadata inventory, resource guards, and cleanup checks remain byte-for-byte as in the source copy. The `RUNNER` constant still points to `/private/tmp/jarde-wrap-validation-prep-luna-v1/workspace/workspace_runner.py`.

The new own-CI verifier changes only `WORKSPACE_ACCEPTOR` and its SHA-256. Its `WORKSPACE_RUNNER` path and `557d...` SHA remain unchanged. No Rust, JDK, JADX, CLI, or Git command was run. AST parsing and static diff/pin checks passed. `changes.diff` contains both file diffs; `pins.json` contains source/output and raw evidence pins.
