# Ordered-field own-product CI acceptance preparation

Status: `prepared_not_executed`. No capture, verifier, build, test, Git, Cargo, `gh`, JDK, JADX, or product CLI command was run during this preparation. The current product has not been committed and this package contains no accepted CI observation. Do not substitute the prior CF11 run.

This package adapts the prior own-product verifier v10 around the current root receipts and the ordered-field full-workspace v2 metadata/batching format. It keeps the receipt/raw-stream parsing path and product CI parser, while freezing v10 and the v2 runner/acceptor for review. The capture adapter is a thin copy of the existing root CI collector: its only behavior changes remove the hard-coded 52-step count and require each of the four expected jobs to expose at least one step. It still captures the exact summary, stable job log, and supply-chain log with complete raw bytes.

The focused receipt format has no `schema` key. The verifier checks its passing `status`, matching before/after source manifests, command-spec path/size/SHA, all six successful command records plus exact `cargo clean`, test summaries and named outcomes from raw stdout, default stack, target cleanup, and the full CLI path/size/SHA plus on-disk mode `0555`. It derives the required ordered-field names from the pinned workspace runner rather than pinning new aggregate test totals. The focused Clippy vector must equal the exact argv parsed from `.github/workflows/ci.yml` at the selected product commit.

The fresh workspace receipt and its independent acceptance are checked against the v2 metadata-derived command plan, exact two seeds in the selected product workflow, complete per-target local stdout outcomes and summaries, cleanup, and current dynamic source pins. The verifier compares the complete focused source manifest, workspace before/after pins, dynamically scanned live source closure, and selected product Git blobs. It then matches every product-CI target's counts and each named test status to the local result for the same seed. CI requires the four expected jobs and every reported step to be completed/successful; it records the observed step total dynamically rather than assuming a fixed total.

There are no fixed product commit, run ID, source count, target count, batch count, or new test-count pins. The commit and run ID are mandatory argv. The candidate CLI path and SHA are also mandatory argv and must agree with both receipts and the frozen file. Workspace output counts are calculated from metadata and independently parsed raw test output.

The previous product-specific verifier had a focused-schema check and CF11-only source/test/final-build constraints. This adapter drops the focused `schema` requirement, updates the workspace receipt binding to the ordered-field v2 fields, and omits the separate CF11 final-build stage. It retains focused command/raw evidence, source closure, CLI freeze, exact product-workflow Clippy argv, actual CI all-green evidence, and same-seed target/test comparison. The full frozen v10 remains alongside this file; `verify-own-ci-v10-to-ordered-field.diff` and `capture-own-ci-v3-to-adapter.diff` show the adapter changes.

After a new product commit exists and its actual CI run completes successfully, run the prepared collector with the exact commit and run ID:

```sh
python3 /private/tmp/jarde-ordered-field-own-ci-prep-luna-v1/capture-own-ci.py \
  --product-commit <new-product-commit> \
  --run-id <actual-ci-run-id> \
  --out /private/tmp/jarde-ordered-field-own-ci-capture-root-v1
```

Use the new focused receipt, fresh workspace v2 output and independent acceptance, then run the verifier. Supply the CLI path and SHA exactly as recorded in the focused receipt:

```sh
python3 /private/tmp/jarde-ordered-field-own-ci-prep-luna-v1/verify-own-ci.py \
  --product-commit <new-product-commit> \
  --run-id <actual-ci-run-id> \
  --capture /private/tmp/jarde-ordered-field-own-ci-capture-root-v1 \
  --focused-receipt <fresh-focused-execution.json> \
  --focused-receipt-sha256 <focused-execution-sha256> \
  --candidate-cli <path-from-focused-receipt-cli> \
  --candidate-cli-sha256 <sha256-from-focused-receipt-cli> \
  --workspace <fresh-workspace-v2-directory> \
  --workspace-receipt-sha256 <workspace-execution-sha256> \
  --workspace-acceptance <fresh-workspace-acceptance.json> \
  --workspace-acceptance-sha256 <workspace-acceptance-sha256> \
  --out /private/tmp/jarde-ordered-field-own-ci-acceptance-root-v1/summary.json
```

`pins.json` records source and artifact hashes. All paths above are preparation defaults or future argv placeholders; they do not claim a new commit/run or a passing result.
