# Ordered-field full-workspace validation preparation v2

This private v2 adapts the existing CF11 v4 metadata-driven batch runner to the root final-check focused receipt. It reads the receipt-pinned `command_spec`, verifies its file size, SHA-256, and JSON commands, then requires the receipt's six successful normal commands to match it exactly, followed by successful exact `cargo clean`. It parses every focused test command's raw stdout, checks summaries and named-outcome totals against receipt fields, pins all raw streams, validates the CLI binary freeze, and requires an unchanged complete source manifest. The workspace phase keeps the existing metadata-derived target inventory, two Proptest seeds, maximum four integration targets per batch, exact unique target coverage, artifact/summary/raw-stream cross-checks, deletion of completed test executables, and finally cleanup.

Root runs the workspace phase after the focused final-check receipt completes. Supply that receipt's final SHA-256 and its recorded current CLI path/SHA-256:

```sh
python3 /private/tmp/jarde-ordered-field-full-workspace-prep-luna-v2/workspace_runner.py \
  --focused-receipt /private/tmp/jarde-ordered-field-final-check-root-v2/execution.json \
  --focused-receipt-sha256 <final-focused-receipt-sha256> \
  --candidate-cli <cli-path-from-focused-receipt> \
  --candidate-cli-sha256 <cli-sha256-from-focused-receipt> \
  --out /private/tmp/jarde-ordered-field-full-workspace-run-root-v2
```

Then independently accept the workspace receipt with its emitted execution SHA-256:

```sh
python3 /private/tmp/jarde-ordered-field-full-workspace-prep-luna-v2/accept_workspace.py \
  --execution /private/tmp/jarde-ordered-field-full-workspace-run-root-v2/execution.json \
  --execution-sha256 <execution-sha256> \
  --focused-receipt /private/tmp/jarde-ordered-field-final-check-root-v2/execution.json \
  --focused-receipt-sha256 <final-focused-receipt-sha256> \
  --metadata /private/tmp/jarde-ordered-field-full-workspace-run-root-v2/metadata.json \
  --out /private/tmp/jarde-ordered-field-full-workspace-run-root-v2/acceptance.json
```

Fmt, the current CI Clippy argv, and global strict OpenSpec are part of the focused command specification and are verified from the receipt. Local target-size settings remain guarded at 1 GiB; default Rust stack is preserved. This package is prepared only. It has not run Cargo, OpenSpec, JDK, JADX, the CLI, or the workspace runner.
