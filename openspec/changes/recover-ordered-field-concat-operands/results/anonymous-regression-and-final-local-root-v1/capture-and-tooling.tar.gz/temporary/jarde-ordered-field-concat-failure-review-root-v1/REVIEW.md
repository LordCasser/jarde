# Anonymous child concat assertion review

## Observed batch-6 output

The read-only `6.stdout.raw` from `/private/tmp/jarde-ordered-field-full-workspace-run-root-v2` reports `101 passed; 1 failed`; failure is at `tests/class_source.rs:8708`, the old `append("body:").append(local1)` substring assertion. The actual root text already passes the preceding anonymous initializer assertion and contains:

```java
Base local2 = new Base(...) {
    java.lang.String render() {
        AnonymousSuperArgs.event("body:" + local1);
        return super.render() + ":" + local1;
    }
};
```

This distinguishes the failing delta from the enclosing initializer's projection: the initializer is present and passes its assertion; the failed expectation is the child's recovered string form.

## Finding from source paths

The output change is attributable to the child concat certificate, not `presented_reference_store_value`.

`presented_reference_store_value` is reached from the local-write declaration scan for a stack value stored to a local. The new arm accepts only an `Operation::Load` whose actual local read is single-use and on a presented path, with that load immediately before the local `Store`. It neither recognizes a `Field` instruction nor builds concat operands. The anonymous child's `render` body is the source expression `event("body:" + captured)`; a `getfield` used between a builder's append calls is the relevant candidate here, not a reference Load-to-Store initializer.

The concat flow is different and direct: `report.rs` calls `plan_with_ordered_field_operands`; that first runs the existing conditional/ordinary planner and then examines only `jre_concat_interleaved_effect` refusals. The new direct-field certificate requires an exact `fields.claim(bci)` for a non-static read, a same-identity receiver from the immediately preceding local Load, one receiver reader, a field result used once by the immediately following append, and the existing builder/tail checks. It then reruns `verify` with only those certified field BCIs permitted. In `verify(..., ordered_field_reads = None, ...)`, a normal field read between appends still follows the old refusal path unless it is an existing field-copy receiver read. With the ordered-field set, the claimed direct field read is owned by the new chain. The emitter then writes `+` for that newly accepted chain.

The explicit `String.valueOf((Object) ...)` emitter arm is not the cause if this append is physically `append(String)`: that arm only marks an `append(Object)` position, and its parameter check fails for String. This should still be confirmed from the child's constant-pool descriptor before attributing the exact emitted form.

## Compatibility assessment

This one case is a previously refused field-interleaved concat, not an already accepted pure chain or a `FieldCopies` receiver-copy chain. Its new `+` form is the feature's intended behavior for a proven direct instance-field operand, and the source fixture itself spells the operand as `"body:" + captured`. Therefore the observation alone does not show a regression in the old pure/field-copy text guarantee. It is a visible behavior change at an existing assertion and needs the exact child IR proof before the assertion is changed.

Pure chains still use the existing plan/verifier call with no ordered field read set. Existing compound-field receiver-copy recognition remains its separate `copies` branch. No general source-string/field rule was added to the `RefLoad` initializer proof.

## Minimum review gate before adjusting the test

Use the exact `AnonymousSuperArgs$1.class` bytes from the failing snapshot and inspect the child member `render()Ljava/lang/String;` (confirm actual owner/name/descriptor from the read declaration). In one analysis request and one recovery request over that payload, log and check:

1. The physical `getfield` CP identity (owner, name, descriptor, non-static) and its exact `FieldPlan` claim; its receiver is the SSA output of the immediately preceding actual `aload` of the method receiver, and that load SSA value has only this field read as consumer.
2. The field result SSA identity is the argument read by the immediate next physical append, with no other instruction or phi consumer. Decode the append owner/name/descriptor and establish which overload is physically called.
3. The append receiver is the `StringBuilder`/`StringBuffer` value proved from the chain allocation; each append result is the next append's receiver or the selected tail's receiver. The field and selected tail are in the same SSA block.
4. The selected `toString()Ljava/lang/String;` is the one consumed as the String argument of the actual `event(String)` call (or whichever decoded call consumes it), rather than the first/nearest same-class tail in the body. It is the chain's sole tail.
5. Report records and source-map provenance show that this exact field BCI, append BCI(s), tail BCI and consuming call are the claimed chain. Print all complete decoded Code exception rows and compare their full ordered identities over allocation through consumer; ensure no exceptional row is split or omitted.
6. Recover the same `render()` payload and confirm the physical operation/SSA chain above is what is presented. Include a retained pure-concat and FieldCopies control in the nearby regression set to show their text is unchanged.

No BCI should be hard-coded as an identity check. Resolve operations from the physical instruction's own constant-pool index and follow SSA values. Preserve `fields.claim` identity and the existing tail/consumer/exception-row checks.

## Smallest fix depending on the proof

- If all gates hold, update only the stale expected spelling for this field-backed case to the new `+` form, but pair it with a test assertion for the physical descriptor, same-SSA field-to-append-to-tail flow, and report/source-map ownership above. Keep a separate prior pure/FieldCopies golden assertion unchanged.
- If any gate fails, do not bless the new string by changing the expected substring. Keep the old refused concat and tighten only the new ordered-field certificate at the failing premise (or its exact field-plan claim). Do not change `presented_reference_store_value` for this symptom.

This review is static. No shared files were edited and no Cargo, JDK, JADX, or CLI tool was run.
