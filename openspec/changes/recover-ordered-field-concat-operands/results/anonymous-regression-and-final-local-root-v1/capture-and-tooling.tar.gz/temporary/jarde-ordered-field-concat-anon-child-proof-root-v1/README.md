# Anonymous child render evidence snippet

This is a private test candidate to paste into `crates/jarde-java/tests/p3_patterns.rs`; it does not modify the checkout. It only relies on existing test helpers `analyze`, `facts_of_exact`, `members_of`, `recover_body`, and `ordered_trace_member_ref`.

The test chooses both concat tails by matching the actual `toString` SSA result to the actual `event(String)` stack argument and `areturn` stack value. It walks each tail's builder receiver backwards through same-block append result definitions until the physical CP identity `AnonymousSuperArgs$1.val$captured` is reached. Assertions check the local reference load/getfield/append physical adjacency, exact SSA identities, all-method instruction and Phi use counts for the load, field result, and tail result, exact same SSA block, report presentation, and complete ordered exception-table rows for each physical instruction from the report chain head through its consumer. It prints only the chosen flow, matched field/concat records, physical method identity, exception rows, and source-map entries for selected BCIs.

The test intentionally derives BCIs from consumers and physical member references. No Cargo/JDK/JADX/CLI command was run, so this is a reviewable candidate, not a compiled or runtime-validated test. Before changing the existing expectation, inspect its emitted report with the root-owned collection run.

Base checkout/source pins at preparation time:

- `crates/jarde-java/tests/p3_patterns.rs`: `55108ba724fc493d3fe0cee33742b14b964a7397f9a1763f4019e295b677189f`
- fixture `AnonymousSuperArgs$1.class`: `e65c29fc6d6f0835d2fc94e222446332b1ce6d1fe860ba6dbd71aefd8ab8223e`
