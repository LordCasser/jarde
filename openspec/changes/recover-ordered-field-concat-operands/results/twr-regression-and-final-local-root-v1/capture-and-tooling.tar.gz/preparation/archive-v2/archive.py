#!/usr/bin/env python3
"""Prepare and verify a deterministic private evidence tar; does not touch repository state."""
from __future__ import annotations
import argparse, hashlib, io, json, os, stat, tarfile
from pathlib import Path, PurePosixPath

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
OUT_BASE=Path('/private/tmp')
V5=Path('/private/tmp/jarde-ordered-field-final-check-root-v5')
V5_RECEIPT_SHA='7fd0a7794c7be065f132d4b96f0a4adaf5dacbacb26e823e3c03dbc90dee854b'
V3=Path('/private/tmp/jarde-ordered-field-full-workspace-run-root-v3')
TWR=Path('/private/tmp/jarde-twr-javac23-differential-root-v2')
TWR_PREP_V1=Path('/private/tmp/jarde-twr-javac23-differential-prep-luna-v1')
TWR_PREP_V2=Path('/private/tmp/jarde-twr-javac23-differential-prep-luna-v2')
FINAL_ACCEPT=Path('/private/tmp/jarde-ordered-field-final-check-accept-root-v3.py')
COMMAND_SPEC=Path('/private/tmp/jarde-ordered-field-final-check-commands-root-v5.json')
WORKSPACE_PREP=Path('/private/tmp/jarde-ordered-field-full-workspace-prep-luna-v2')
GOLDEN_PREP=Path('/private/tmp/jarde-ordered-field-golden-audit-luna-v1')
CLEAN_PREP=Path('/private/tmp/jarde-ordered-field-clean-main-audit-prep-luna-v1')
TWR_CLASS=ROOT/'openspec/evidence/java-syntax-2026-10-04/twr-javac8-codegen-patrol/fixture/javac23-TR/TR.class'
TWR_SOURCE=ROOT/'openspec/evidence/java-syntax-2026-10-04/twr-javac8-codegen-patrol/fixture/TR.java'
TWR_RENDERED=ROOT/'openspec/evidence/java-syntax-2026-10-04/twr-javac8-codegen-patrol/results/TR-javac23-rendered.txt'
EXPECTED_TWR_RENDERED_SHA='edd2a00f960a78dc33a1323172efbb825e0787ce95e0b87b9f9f3bada9171acb'
EXPECTED_TWR_CLASS_SHA='1401152b546f9dd1528fc9683882ac9334b04944dba01a79ffb6892c6025660d'
EXPECTED_TWR_SUMMARY_SHA='9757773708e01bf0983bdd47e46fe5ebdc35df7d106030adce3398dfb8b7e3f1'
EXPECTED_CHANGED_METHODS={'close','use'}
EXPECTED_SOURCE_PATHS=(
 'crates/jarde-java/src/build.rs',
 'crates/jarde-java/src/concat.rs',
 'crates/jarde-java/src/region.rs',
 'crates/jarde-java/src/region/finite_loop_catch_tests.rs',
 'crates/jarde-java/src/report.rs',
 'crates/jarde-java/tests/p3_patterns.rs',
 'tests/class_source.rs',
 'tests/p3_twr_lead_sequence.rs',
)


def sha(b:bytes)->str: return hashlib.sha256(b).hexdigest()
def file_record(path:Path)->dict:
 path=Path(path)
 if path.is_symlink() or not path.is_file(): raise RuntimeError(f'not a regular non-symlink file: {path}')
 b=path.read_bytes(); return {'path':str(path),'bytes':len(b),'sha256':sha(b)}
def load_json(path:Path): return json.loads(Path(path).read_text(encoding='utf-8'))
def add_file(entries:list, arc:str, source:Path, group:str):
 source=Path(source); record=file_record(source); entries.append({'archive_path':arc,'source_path':str(source),'bytes':record['bytes'],'sha256':record['sha256'],'group':group,'data':source.read_bytes()})
def add_bytes(entries:list,arc:str,data:bytes,origin:str,group:str):
 entries.append({'archive_path':arc,'source_path':origin,'bytes':len(data),'sha256':sha(data),'group':group,'data':data})
def add_text_tree(entries:list,src:Path,arcbase:str,group:str):
 src=Path(src)
 if not src.is_dir(): raise RuntimeError(f'missing required directory: {src}')
 for path in sorted(src.rglob('*')):
  if not path.is_file() or path.is_symlink() or '__pycache__' in path.parts: continue
  data=path.read_bytes()
  if path.suffix.lower() in {'.class','.jar','.pyc','.dylib','.so','.rlib','.a','.exe'}: continue
  if data.startswith((b'\x7fELF',b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'MZ')): continue
  try: data.decode('utf-8')
  except UnicodeDecodeError: continue
  rel=path.relative_to(src).as_posix()
  add_bytes(entries,f'{arcbase}/{rel}',data,str(path),group)
def add_tree_text_results(entries:list,src:Path,arcbase:str,group:str):
 forbidden_dirs={'target','original-class','jadx-classes','render-classes','classes'}
 forbidden_suffix={'.class','.jar','.pyc','.dylib','.so','.rlib','.a'}
 for path in sorted(src.rglob('*')):
  if not path.is_file() or path.is_symlink(): continue
  rel=path.relative_to(src)
  if any(part in forbidden_dirs or part.endswith('-classes') for part in rel.parts): continue
  if path.suffix.lower() in forbidden_suffix or path.stat().st_mode & 0o111: continue
  data=path.read_bytes()
  # TWR run artifacts are intended to be readable evidence text/JSON/source/raw only.
  try: data.decode('utf-8')
  except UnicodeDecodeError: continue
  add_bytes(entries,f'{arcbase}/{rel.as_posix()}',data,str(path),group)
def add_root_execution_raw(entries:list,src:Path,arcbase:str,group:str):
 for name in ('execution.json','metadata.json'):
  add_file(entries,f'{arcbase}/{name}',src/name,group)
 for p in sorted(src.glob('*.raw')):
  add_file(entries,f'{arcbase}/raw/{p.name}',p,group)

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('archive',type=Path,help='fresh destination .tar path')
 args=ap.parse_args(); archive=args.archive.resolve(); manifest_path=archive.with_suffix(archive.suffix+'.manifest.json')
 if archive.exists() or manifest_path.exists(): raise SystemExit('refusing to overwrite archive or its manifest')
 entries=[]
 # The v5 receipt is independently accepted, frozen by its exact root-provided digest.
 receipt=V5/'execution.json'
 if sha(receipt.read_bytes())!=V5_RECEIPT_SHA: raise RuntimeError('final-check-v5 receipt SHA differs')
 r5=load_json(receipt); summary=load_json(V5/'root-summary.json')
 if summary.get('status')!='accepted_final_local_checks_and_same_product_binary': raise RuntimeError('final-check-v5 summary is not accepted')
 if r5.get('default_stack') is not True or r5.get('target_absent') is not True: raise RuntimeError('final-check-v5 receipt lacks default stack/clean target')
 if r5.get('source_manifest_before')!=r5.get('source_manifest_after'): raise RuntimeError('final-check-v5 source manifest changed')
 add_file(entries,'accepted/final-check-v5/execution.json',receipt,'final-check-v5')
 add_file(entries,'accepted/final-check-v5/root-summary.json',V5/'root-summary.json','final-check-v5')
 for p in sorted((V5/'raw').rglob('*')):
  if p.is_file() and not p.is_symlink(): add_file(entries,'accepted/final-check-v5/raw/'+p.relative_to(V5/'raw').as_posix(),p,'final-check-v5')
 add_file(entries,'accepted/final-check-v5/accept-v3.py',FINAL_ACCEPT,'final-check-accept-v3')
 add_file(entries,'accepted/final-check-v5/command-spec-v5.json',COMMAND_SPEC,'command-spec-v5')
 # Preserve the v3 failed full-workspace execution independently; never fold it into accepted v5/v4 evidence.
 v3doc=load_json(V3/'execution.json')
 if v3doc.get('status')!='failed': raise RuntimeError('full-workspace-v3 is not the expected failed execution')
 add_root_execution_raw(entries,V3,'failed/full-workspace-v3','full-workspace-v3-failure')
 # TWR v2 text evidence and generated sources only; omit class/jar/tool binaries and compiled outputs.
 twr_exec=TWR/'execution.json'; twr_summary=load_json(TWR/'root-summary.json'); twr_check=load_json(TWR/'check.json')
 if sha(twr_exec.read_bytes())!=EXPECTED_TWR_SUMMARY_SHA: raise RuntimeError('TWR v2 execution receipt SHA differs')
 twr_doc=load_json(twr_exec)
 if twr_summary.get('status')!='accepted_TWR_complete_class_runtime_and_two_field_chain_deltas' or twr_summary.get('commands')!=23 or twr_summary.get('receipt_sha256')!=EXPECTED_TWR_SUMMARY_SHA:
  raise RuntimeError('TWR summary does not match accepted 23-command result')
 if len(twr_doc.get('commands',[]))!=23 or any(c.get('exit_code')!=0 or c.get('guard_stop') for c in twr_doc['commands']):
  raise RuntimeError('TWR command receipt does not show 23 successful guarded commands')
 if twr_check.get('status')!='accepted' or set(twr_check.get('changed_method_text_names',[]))!=EXPECTED_CHANGED_METHODS or twr_check.get('one_two_complete_method_text_equal') is not True:
  raise RuntimeError('TWR method delta / one-two invariants differ')
 if not twr_check.get('all_required_lanes_compile_and_run_exit_zero'): raise RuntimeError('TWR result lacks complete successful compile/runtime lanes')
 if not all(x.get('stdout_byte_equal_to_original') is True for x in twr_check.get('runtime_comparisons',[])) or len(twr_check.get('runtime_comparisons',[]))!=6:
  raise RuntimeError('TWR raw stdout lane comparisons are incomplete or differ')
 if not all(x.get('compile_exit')==0 and x.get('run_exit')==0 for x in twr_check.get('lane_exit_states',[])) or len(twr_check.get('lane_exit_states',[]))!=8:
  raise RuntimeError('TWR compile/run lane exit evidence is incomplete')
 add_tree_text_results(entries,TWR,'twr/differential-v2','twr-differential-v2')
 # Freeze exact old javac23 TR golden input bytes separately for reviewer diffs.
 if sha(TWR_CLASS.read_bytes())!=EXPECTED_TWR_CLASS_SHA: raise RuntimeError('old TWR23 golden class changed')
 add_file(entries,'twr/original-golden/TR-javac23.class',TWR_CLASS,'twr-original-golden')
 add_file(entries,'twr/original-golden/TR.java',TWR_SOURCE,'twr-original-golden')
 if sha(TWR_RENDERED.read_bytes())!=EXPECTED_TWR_RENDERED_SHA: raise RuntimeError('historical TR javac23 rendered golden changed')
 add_file(entries,'twr/original-golden/TR-javac23-rendered.txt',TWR_RENDERED,'twr-historical-rendered-golden')
 for name,src in (('prep-v1',TWR_PREP_V1),('prep-v2',TWR_PREP_V2)):
  add_text_tree(entries,src,f'twr/preparation/{name}',f'twr-prep-{name}')
 # Capture preparation inputs and audits as text only.
 add_text_tree(entries,WORKSPACE_PREP,'preparation/full-workspace-v2','workspace-prep-v2')
 add_text_tree(entries,GOLDEN_PREP,'preparation/golden-audit','golden-audit')
 add_text_tree(entries,CLEAN_PREP,'preparation/clean-main','clean-main-prep')
 required_prep_scripts={
  'preparation/full-workspace-v2/workspace_runner.py',
  'preparation/full-workspace-v2/accept_workspace.py',
  'preparation/clean-main/audit-clean-main.py',
  'preparation/clean-main/audit-clean-main-frozen-v2.py',
 }
 if not required_prep_scripts.issubset({e['archive_path'] for e in entries}):
  raise RuntimeError('required workspace/clean-main preparation scripts were not included')
 # Active full-workspace-v4 artifacts are intentionally neither read nor included.
 # Eight source snapshots are selected by name and verified against the exact final-check-v5 manifest.
 manifest_rows={row['path']:row for row in r5['source_manifest_before']}
 if len(manifest_rows)!=len(r5['source_manifest_before']): raise RuntimeError('final-check-v5 manifest has duplicate paths')
 if set(EXPECTED_SOURCE_PATHS)-set(manifest_rows): raise RuntimeError('one or more required source snapshots are missing from v5 manifest')
 selected=[]
 for rel in EXPECTED_SOURCE_PATHS:
  source=ROOT/rel; expected=manifest_rows[rel]; actual=file_record(source)
  if any(actual[k]!=expected[k] for k in ('bytes','sha256')): raise RuntimeError(f'source differs from final-check-v5 manifest: {rel}')
  add_file(entries,'source-snapshot/final-check-v5/'+rel,source,'source-snapshot-v5'); selected.append({k:expected[k] for k in ('path','bytes','sha256')})
 add_bytes(entries,'source-snapshot/final-check-v5/manifest-excerpt.json',json.dumps(selected,ensure_ascii=False,indent=2).encode()+b'\n','generated from final-check-v5 source_manifest_before','source-snapshot-manifest')
 # No duplicate archive names; every member is an ordinary file with a normalized relative path.
 names=[e['archive_path'] for e in entries]
 if len(names)!=len(set(names)): raise RuntimeError('duplicate archive member path')
 for name in names:
  pp=PurePosixPath(name)
  if pp.is_absolute() or '..' in pp.parts: raise RuntimeError(f'unsafe archive path: {name}')
 archive.parent.mkdir(parents=True,exist_ok=True)
 with tarfile.open(archive,'w',format=tarfile.PAX_FORMAT) as tf:
  for item in sorted(entries,key=lambda x:x['archive_path']):
   ti=tarfile.TarInfo(item['archive_path']); ti.size=item['bytes']; ti.mtime=0; ti.uid=0; ti.gid=0; ti.uname='root'; ti.gname='root'; ti.mode=0o644; ti.type=tarfile.REGTYPE
   tf.addfile(ti,io.BytesIO(item['data']))
 # Re-open and hash every member from the actual archive bytes before publishing the manifest.
 with tarfile.open(archive,'r:') as tf:
  members=tf.getmembers(); seen={}
  for m in members:
   if not m.isfile(): raise RuntimeError(f'non-regular tar member: {m.name}')
   b=tf.extractfile(m).read(); seen[m.name]={'bytes':len(b),'sha256':sha(b)}
 expected={e['archive_path']:{'bytes':e['bytes'],'sha256':e['sha256']} for e in entries}
 if seen!=expected: raise RuntimeError('archive member hashes/lengths differ after reopen')
 tar_bytes=archive.read_bytes()
 manifest={'schema':'jarde-ordered-field-twr-regression-archive-v1','status':'created-and-reopened-verified',
  'archive':{'path':str(archive),'bytes':len(tar_bytes),'sha256':sha(tar_bytes)},'archive_member_count':len(entries),
  'members':[{'path':e['archive_path'],'source':e['source_path'],'group':e['group'],'bytes':e['bytes'],'sha256':e['sha256']} for e in sorted(entries,key=lambda x:x['archive_path'])],
  'full_workspace_v3_status':'failed-preserved-separately','full_workspace_v4':'not-read-not-included; fresh full-workspace and its own CI were unfinished',
  'final_check_v5_receipt_sha256':V5_RECEIPT_SHA,'source_snapshot_v5_files':selected,
  'twr_result':{'receipt_sha256':EXPECTED_TWR_SUMMARY_SHA,'commands':23,'changed_methods':['close','use'],'one_two_complete_method_text_equal':True}}
 manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'status':manifest['status'],'archive':manifest['archive'],'manifest':str(manifest_path),'member_count':len(entries)},indent=2))

if __name__=='__main__':
 try: main()
 except Exception as e: raise SystemExit(f'archive preparation failed: {type(e).__name__}: {e}')
