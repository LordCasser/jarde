# Ordered-field and TWR regression archive preparation

`archive.py` prepares one deterministic tar from the independently accepted final-check-v5 evidence, the preserved failed full-workspace-v3 execution, the accepted TWR differential, and their text-only preparation inputs. It reopens the produced tar, hashes every member, checks every byte length, and only then writes a separate member manifest. The script was prepared but not run; it has not created a tar or changed repository state.

The archive keeps the failed `full-workspace-v3` execution, metadata, and all raw streams under a separate `failed/full-workspace-v3/` prefix. It never merges that failure into accepted evidence. It records final-check-v5 separately, pinned to receipt SHA `7fd0a7794c7be065f132d4b96f0a4adaf5dacbacb26e823e3c03dbc90dee854b`, and preserves the final-check-v5 acceptance script, command spec v5, raw streams, and summary without the CLI binary.

The TWR v2 evidence records 23 successful commands. Its independent check reports that the `use()` and `close()` method texts changed, the complete `one()` and `two()` method texts stayed equal, and all eight source runtime lanes plus both frozen-class lanes passed with raw stdout matching the original baseline. The archive retains the complete execution receipt, raw output, generated source and text/JSON results. It excludes compiled classes and the JAR, while preserving the old javac23 `TR.class` bytes and historical `TR-javac23-rendered.txt` separately as frozen golden inputs for review.

The source snapshot contains exactly eight files selected by path from the final-check-v5 source manifest: `build.rs`, `concat.rs`, `region.rs`, `region/finite_loop_catch_tests.rs`, `report.rs`, `p3_patterns.rs`, `tests/class_source.rs`, and `tests/p3_twr_lead_sequence.rs`. Before adding each file, the script checks its byte length and SHA-256 against that exact manifest entry. It includes the selected manifest excerpt with the files.

The full-workspace and clean-main preparation folders include their Python runners and checkers even when their executable bit is set. The collector skips compiled artifacts by suffix or binary file signature, then the archive check explicitly requires all four workspace/clean-main Python scripts.

Fresh full-workspace-v4 is not read or included. The fresh full-workspace run and its own CI were unfinished when this preparation was made. This archive contains only the already-finished independent historical evidence; the v3 failure remains a standalone failed record. Root can archive this evidence now without waiting for v4.

Root may run the script using a fresh archive path:

```sh
python3 -B /private/tmp/jarde-twr-regression-archive-prep-luna-v2/archive.py \
  /private/tmp/jarde-twr-regression-archive-root-v2/evidence.tar
```

The script will then write `/private/tmp/jarde-twr-regression-archive-root-v2/evidence.tar.manifest.json`. The script does not inspect active full-workspace-v4 artifacts. No tar has been generated during preparation.
