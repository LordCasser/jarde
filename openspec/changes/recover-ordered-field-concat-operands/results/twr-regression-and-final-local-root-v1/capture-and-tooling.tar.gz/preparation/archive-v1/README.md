# Ordered-field and TWR regression archive preparation

`archive.py` prepares one deterministic tar from the independently accepted final-check-v5 evidence, the preserved failed full-workspace-v3 execution, the accepted TWR differential, and their text-only preparation inputs. It reopens the produced tar, hashes every member, checks every byte length, and only then writes a separate member manifest. The script was prepared but not run; it has not created a tar or changed repository state.

The archive keeps the failed `full-workspace-v3` execution, metadata, and all raw streams under a separate `failed/full-workspace-v3/` prefix. It never merges that failure into accepted evidence. It records final-check-v5 separately, pinned to receipt SHA `7fd0a7794c7be065f132d4b96f0a4adaf5dacbacb26e823e3c03dbc90dee854b`, and preserves the final-check-v5 acceptance script, command spec v5, raw streams, and summary without the CLI binary.

The TWR v2 evidence records 23 successful commands. Its independent check reports that the `use()` and `close()` method texts changed, the complete `one()` and `two()` method texts stayed equal, and all eight source runtime lanes plus both frozen-class lanes passed with raw stdout matching the original baseline. The archive retains the complete execution receipt, raw output, generated source and text/JSON results. It excludes compiled classes and the JAR, while preserving the old javac23 `TR.class` bytes separately as the frozen golden input for review.

The source snapshot contains exactly eight files selected by path from the final-check-v5 source manifest: `build.rs`, `concat.rs`, `region.rs`, `region/finite_loop_catch_tests.rs`, `report.rs`, `p3_patterns.rs`, `class_source.rs`, and `tests/p3_twr_lead_sequence.rs`. Before adding each file, the script checks its byte length and SHA-256 against that exact manifest entry. It includes the selected manifest excerpt with the files.

Fresh full-workspace-v4 was still active when this preparation was made and was not read. The archive script requires a separate accepted full-workspace-v4 JSON receipt at execution time and refuses a pending or failed gate. The v3 failure remains a standalone failed record even after that gate passes.

Root may run the script only after the full-workspace-v4 acceptance receipt is available, using a fresh archive path:

```sh
python3 -B /private/tmp/jarde-twr-regression-archive-prep-luna-v1/archive.py \
  /private/tmp/jarde-twr-regression-archive-root-v1/evidence.tar \
  --full-v4-acceptance /path/to/accepted-full-workspace-v4.json
```

The script will then write `/private/tmp/jarde-twr-regression-archive-root-v1/evidence.tar.manifest.json`. No tar has been generated during preparation.
