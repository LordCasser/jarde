# Ordered-field clean-main audit preparation

Status: `prepared_not_executed`. This is a private read-only audit adapter. No Git command, repository toolchain, or shared file was run or modified during preparation. The script must be run by the root orchestrator only after it has the actual product commit, final docs HEAD, focused receipt, and accepted own-CI summary.

The adapter uses argv for the product commit, docs HEAD, focused receipt path/SHA, and own-CI acceptance path/SHA. It has no pinned product commit, receipt digest, or fixed source-file count. It accepts the focused receipt's current schema-less shape, requires `commands_passed_pending_independent_acceptance`, and dynamically validates equal non-empty `source_manifest_before` / `source_manifest_after` lists. The own-CI receipt must be an accepted `ordered-field-own-ci-acceptance-v1` result for the same product commit and exact focused path/SHA; its dynamically reported source-closure count must equal the focused manifest length.

At execution, it independently enumerates both Git trees and hashes every manifest blob, then checks focused SHA, manifest row byte count, product blob SHA, docs-HEAD blob SHA, and live file bytes/mode. It retains the main-only branch and exact `HEAD == main == origin/main == remote refs/heads/main == docs HEAD` checks, and requires the product commit to be an ancestor of docs HEAD. It inspects the actual worktree inventory, requires one root on `main` plus the known 14 auxiliary worktrees, requires every auxiliary checkout detached, and checks every worktree is clean, an ancestor of main, and free of `target` and `fuzz/target`. This package does not claim those live checks passed; only a later execution can produce `accepted_clean_main`.

Root execution shape (replace every placeholder with current, independently reviewed values and choose a new output directory outside the repository):

```sh
python3 /private/tmp/jarde-ordered-field-clean-main-audit-prep-luna-v1/audit-clean-main.py \
  <NEW_OUTSIDE_REPO_DIR> <PRODUCT_COMMIT_40_HEX> <FINAL_DOCS_HEAD_40_HEX> \
  --focused-receipt <ACTUAL_FOCUSED_EXECUTION_JSON> \
  --focused-receipt-sha256 <ACTUAL_FOCUSED_SHA256> \
  --own-ci-acceptance <ACTUAL_ACCEPTED_OWN_CI_SUMMARY_JSON> \
  --own-ci-acceptance-sha256 <ACTUAL_OWN_CI_SUMMARY_SHA256>
```

`audit-clean-main-frozen-v2.py` is the unmodified v2 baseline. `audit-clean-main-v2-to-ordered-field.diff` contains the minimal adaptation. Neither file is a run result.
