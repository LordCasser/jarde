# Frozen javac 23 TWR differential replay

This private preparation compares the frozen `javac23-TR/TR.class` sample with the parent-v5 and current-final-v4 Jarde CLIs. It pins the exact class and checked-in `TR.java`, validates both focused CLI receipts, uses the fixed JDK 8/23 paths and the existing root guard/scanner, and never builds Jarde.

The collector records original-class and original-source runtime baselines on both JDKs, runs fixed JADX on a one-class deterministic archive and compiles every emitted Java file unchanged, requests JSON and text class-source output from both CLIs, and compiles/runs each complete generated `TR.java` unchanged on both JDKs. It preserves complete JSON reports and per-method text, nested report, concat facts and map facts. Compile failures are retained as failures with no runtime result.

Run against a fresh output directory:

```sh
python3 -B /private/tmp/jarde-twr-javac23-differential-prep-luna-v1/collect.py \
  /private/tmp/jarde-twr-javac23-differential-root-v1
```

Then run the offline checker:

```sh
python3 -B /private/tmp/jarde-twr-javac23-differential-prep-luna-v1/check.py \
  /private/tmp/jarde-twr-javac23-differential-root-v1/execution.json
```

The checker verifies complete raw stream pins, requires `one()` and `two()` complete method text to match, and rejects any method-text difference outside `use()` or `close()`. It compares raw stdout bytes for each successful runtime lane against the frozen class/source baseline on the same JDK. It does not treat compilation failure as success or assume runtime equivalence.

No CLI, JDK, JADX, or Cargo command has been run during preparation.
