#!/usr/bin/env python3
"""Offline receipt checker for the guarded TWR differential; never runs tools."""
import argparse, hashlib, json, sys
from pathlib import Path

def need(ok,msg):
 if not ok: raise ValueError(msg)
def verify(ref):
 p=Path(ref['path']); need(p.is_file() and not p.is_symlink(),f'missing/linked artifact {p}')
 b=p.read_bytes(); need(len(b)==ref['bytes'] and hashlib.sha256(b).hexdigest()==ref['sha256'],f'hash mismatch {p}'); return b
def lane_stdout(lane,outdir):
 run=lane.get('run')
 if run is None: return None
 need(run.get('exit_code')==0 and not run.get('guard_stop'),f"runtime failed in {lane.get('label')}")
 return verify(run['streams']['stdout'])
def decode_method_name(row):
 name=row.get('name')
 if isinstance(name,dict): return name.get('escaped')
 return name if isinstance(name,str) else None
def methods_from_render(render,outdir):
 parsed=render['formats']['json']['parsed']; raw=verify(parsed['report_pin']); report=json.loads(raw)
 source=verify(parsed['source_pin']); need(source==report['text'].encode('utf-8'),'saved generated source differs from JSON report text')
 methods=report.get('methods',[]); need(isinstance(methods,list) and methods,'JSON report has no methods')
 facts=json.loads(verify(parsed['methods_pin']).decode('utf-8'))
 need(len(facts)==len(methods),'saved method facts count differs')
 result={}
 for row in methods:
  item=row.get('item',{}); name=decode_method_name(item)
  if not name: raise ValueError('method has no stable decoded name')
  identity=item.get('identity'); need(isinstance(identity,dict),'method lacks physical identity')
  key=json.dumps(identity,sort_keys=True,separators=(',',':'))
  result[name]=(key,row)
 need({'one','two','use','close'}.issubset(result),f"expected methods missing: {set(('one','two','use','close'))-set(result)}")
 return report,result

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('execution',type=Path); ap.add_argument('--out',type=Path); a=ap.parse_args()
 ep=a.execution.resolve(strict=True); outdir=ep.parent; d=json.loads(ep.read_text())
 need(d.get('status')=='observed','collector did not complete observations')
 need(d.get('schema')=='twr-javac23-differential-v1','unexpected receipt schema')
 for ref in (d['frozen_class'],d['original_source'],d['archive'],d['jdk_manifest'],*d['tools'].values()): verify(ref)
 need(d['source_pins_before']==d['source_pins_after'],'frozen class/source/archive pins changed')
 for row in d['commands']:
  need(row.get('state')=='observed' and row.get('guard_stop') is None,f"command failed guard: {row.get('label')}")
  for stream in row.get('streams',{}).values(): verify(stream)
 # All JSON and direct-text responses remain available as raw command output.
 renders={r['cli']:r for r in d['renders']}; need(set(renders)=={'parent_v5','current_final_v4'},'render sides missing')
 for label,render in renders.items():
  json_raw=verify(render['formats']['json']['stdout_pin']); text_raw=verify(render['formats']['text']['stdout_pin'])
  need(json.loads(json_raw)['text'].encode('utf-8')==verify(render['formats']['json']['parsed']['source_pin']),f'{label} source differs from report')
  # Full JSON keeps methods, report, concat facts and source maps; pinned extracted method records cross-check it.
  report,method_map=methods_from_render(render,outdir)
  need(verify(render['formats']['json']['command']['streams']['stdout'])==json_raw,'JSON response differs from command stdout')
  need(verify(render['formats']['text']['command']['streams']['stdout'])==text_raw,'text response differs from command stdout')
 old_report,old=methods_from_render(renders['parent_v5'],outdir)
 cur_report,cur=methods_from_render(renders['current_final_v4'],outdir)
 changed=[]
 for name in sorted(set(old)|set(cur)):
  if name not in old or name not in cur: changed.append(name); continue
  need(old[name][0]==cur[name][0],f'physical method identity differs for {name}')
  if old[name][1].get('text')!=cur[name][1].get('text'): changed.append(name)
 need(old['one'][1].get('text')==cur['one'][1].get('text'),'one() full method text changed')
 need(old['two'][1].get('text')==cur['two'][1].get('text'),'two() full method text changed')
 need(set(changed).issubset({'use','close'}),f'method-text changes exceed use/close: {changed}')
 # Preserve full stdout bytes and require runtime equivalence where every lane compiled and ran.
 original_class={r['jdk']:r for r in d['original_class_lanes']}; original_source={r['jdk']:r for r in d['original_source_lanes']}
 candidate={ (r['cli'],r['jdk']):r for r in d['render_source_lanes'] }
 need(set(candidate)=={(cli,jdk) for cli in ('parent_v5','current_final_v4') for jdk in ('javac8','javac23')},'candidate Jarde source lanes incomplete')
 need({r['jdk'] for r in original_class}=={'javac8','javac23'} and {r['jdk'] for r in original_source}=={'javac8','javac23'},'original baseline lanes incomplete')
 need({r['jdk'] for r in jadx.values()}=={'javac8','javac23'},'JADX source lanes incomplete')
 jadx={(r['jdk']):r for r in d['jadx']['lanes']}
 runtime_checks=[]
 for jdk in ('javac8','javac23'):
  base_class=verify(original_class[jdk]['command']['streams']['stdout']) if original_class[jdk]['exit_code']==0 else None
  base_src=lane_stdout(original_source[jdk],outdir) if original_source[jdk]['runtime_state']=='ran' else None
  if base_class is not None and base_src is not None:
   need(base_class==base_src,f'original frozen class/source stdout differs on {jdk}')
  candidate_bytes={}
  for label in ('parent_v5','current_final_v4'):
   lane=candidate.get((label,jdk)); need(lane is not None,'candidate runtime lane missing')
   observed=lane_stdout(lane,outdir) if lane.get('runtime_state')=='ran' else None
   candidate_bytes[label]=observed
   if observed is not None and base_class is not None:
    runtime_checks.append({'candidate':label,'jdk':jdk,'stdout_byte_equal_to_original':observed==base_class,'stdout_sha256':hashlib.sha256(observed).hexdigest()})
  if all(candidate_bytes.get(k) is not None for k in ('parent_v5','current_final_v4')):
   runtime_checks.append({'candidate_pair':'parent_v5/current_final_v4','jdk':jdk,'stdout_byte_equal':candidate_bytes['parent_v5']==candidate_bytes['current_final_v4'],'parent_sha256':hashlib.sha256(candidate_bytes['parent_v5']).hexdigest(),'current_sha256':hashlib.sha256(candidate_bytes['current_final_v4']).hexdigest()})
  jl=jadx.get(jdk)
  if jl and jl.get('runtime_state')=='ran':
   observed=lane_stdout(jl,outdir)
   if base_class is not None: runtime_checks.append({'candidate':'jadx','jdk':jdk,'stdout_byte_equal_to_original':observed==base_class,'stdout_sha256':hashlib.sha256(observed).hexdigest()})
 result={'status':'verified-observations','receipt':str(ep),'changed_method_text_names':changed,
  'only_use_close_method_text_changed':set(changed).issubset({'use','close'}),
  'one_two_complete_method_text_equal':True,'full_report_preserved':True,'runtime_byte_comparisons':runtime_checks,
  'candidate_lane_states':[{'cli':r['cli'],'jdk':r['jdk'],'runtime_state':r['runtime_state'],'compile_exit':r['compile'].get('exit_code'),'run_exit':r['run'].get('exit_code') if r.get('run') else None} for r in d['render_source_lanes']],
  'jadx_lane_states':[{'jdk':r['jdk'],'runtime_state':r['runtime_state'],'compile_exit':r['compile'].get('exit_code'),'run_exit':r['run'].get('exit_code') if r.get('run') else None} for r in d['jadx']['lanes']],
  'compile_failures_are_observations_not_success':True,'toolchain_executed_by_checker':False}
 dest=a.out.resolve() if a.out else outdir/'check.json'; dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
if __name__=='__main__':
 try: raise SystemExit(main())
 except Exception as e: print(f'check failed: {type(e).__name__}: {e}',file=sys.stderr); raise SystemExit(1)
