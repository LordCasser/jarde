#!/usr/bin/env python3
"""Guarded TWR javac23 frozen-class differential replay; no Jarde build."""
from __future__ import annotations
import datetime, hashlib, importlib.util, json, os, re, sys, zipfile
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
PREP=Path(__file__).resolve().parent
FIX=ROOT/'openspec/evidence/java-syntax-2026-10-04/twr-javac8-codegen-patrol/fixture'
CLASS=FIX/'javac23-TR/TR.class'; SOURCE=FIX/'TR.java'
JDK_MANIFEST=ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
GUARD=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
JADX=Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx'); JADX_JAR=Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
OLD_CLI=Path('/private/tmp/jarde-loop-combined-focused-root-v5/candidate-cli'); OLD_RECEIPT=OLD_CLI.parent/'execution.json'
CURRENT_CLI=Path('/private/tmp/jarde-ordered-field-final-check-root-v4/candidate-cli'); CURRENT_RECEIPT=CURRENT_CLI.parent/'execution.json'
RECEIPT_HELPER=Path('/private/tmp/jarde-anonymous-super-args-comparison-prep-luna-v4/collect.py')
FREE_LIMIT=5*1024**3; TARGET_LIMIT=1024**3
STRIP_ENV=('JAVA_HOME','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH')
EXPECTED_PINS={
 'source':'2644e768e2e75de4b72eeb09718538476248c34627f3de25ae5c8fb4560288ab',
 'jdk_manifest':'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec',
 'jadx':'64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7',
 'jadx_jar':'966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65',
 'guard':'51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33',
 'scanner':'d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7',
 'receipt_helper':'eda1b3760db06e258771510a9b7890277c4720c4176ef40ca8036278b25b51f5'}


def sha(b): return hashlib.sha256(b).hexdigest()
def pin(p):
 p=Path(p).resolve(strict=True); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def dump(p,v):
 p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def load(path,name):
 sp=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(sp); sp.loader.exec_module(m); return m


def main():
 if len(sys.argv)!=2: raise SystemExit('usage: collect.py FRESH_OUTPUT_DIR')
 out=Path(sys.argv[1]).resolve()
 if out.exists(): raise SystemExit(f'refusing to overwrite non-fresh output: {out}')
 if pin(CLASS)['sha256']!='1401152b546f9dd1528fc9683882ac9334b04944dba01a79ffb6892c6025660d':
  raise SystemExit('frozen javac23-TR/TR.class pin differs; update only after review')
 receipts=load(RECEIPT_HELPER,'twr_receipt_helper')
 old_ev=receipts.receipt_cli(OLD_CLI,OLD_RECEIPT,require_live_closure=False)
 current_ev=receipts.receipt_cli(CURRENT_CLI,CURRENT_RECEIPT,require_live_closure=True)
 manifest=json.loads(JDK_MANIFEST.read_text(encoding='utf-8')); legs={}
 for row in manifest.get('legs',[]):
  name=row.get('leg')
  if name not in ('javac8','javac23'): continue
  tools={}
  for tool,record in row['jdk_tools'].items():
   if tool not in ('javac','java','javap'): continue
   p=Path(record['path']).resolve(strict=True); actual=pin(p)
   if actual['bytes']!=record['bytes'] or actual['sha256']!=record['sha256']: raise RuntimeError(f'fixed JDK pin mismatch {name}/{tool}')
   tools[tool]=p
  legs[name]={'home':tools['java'].parent.parent,'tools':tools,'pins':row['jdk_tools']}
 if set(legs)!={'javac8','javac23'}: raise RuntimeError('fixed JDK8/JDK23 legs missing')
 for label,p in (('source',SOURCE),('jdk_manifest',JDK_MANIFEST),('jadx',JADX),('jadx_jar',JADX_JAR),('guard',GUARD),('scanner',SCANNER),('receipt_helper',RECEIPT_HELPER)):
  if pin(p)['sha256']!=EXPECTED_PINS[label]: raise RuntimeError(f'pinned input changed: {label}')
 out.mkdir(parents=True); raw=out/'raw'; raw.mkdir()
 guard=load(GUARD,'twr_candidate_guard'); scanner=load(SCANNER,'twr_candidate_scanner')
 guard.ROOT=ROOT; guard.OUT=raw; guard.ENV_VALUES={}; guard.expected_test_summaries=lambda _i,_s:None
 guard.target_bytes=lambda:scanner.target_bytes(ROOT)
 guard.command_stream=lambda p:{'path':str(Path(p).resolve()),'bytes':Path(p).stat().st_size,'sha256':sha(Path(p).read_bytes())}
 # One-entry deterministic jar: exactly the frozen class under comparison.
 jar=out/'TR-javac23-frozen.jar'
 with zipfile.ZipFile(jar,'w',compression=zipfile.ZIP_STORED) as z:
  info=zipfile.ZipInfo('TR.class',(1980,1,1,0,0,0)); info.create_system=3; info.external_attr=0o100644<<16
  z.writestr(info,CLASS.read_bytes())
 doc={'schema':'twr-javac23-differential-v1','status':'running','frozen_class':pin(CLASS),'original_source':pin(SOURCE),'archive':pin(jar),
      'candidate_clis':{'parent_v5':old_ev,'current_final_v4':current_ev},'jdk_manifest':pin(JDK_MANIFEST),
      'jdk_legs':{n:{'home':str(x['home']),'tools':{k:str(v) for k,v in x['tools'].items()},'pins':x['pins']} for n,x in legs.items()},
      'tools':{'jadx':pin(JADX),'jadx_jar':pin(JADX_JAR),'guard':pin(GUARD),'scanner':pin(SCANNER),'receipt_helper':pin(RECEIPT_HELPER)},
      'guard_policy':{'minimum_free_bytes':FREE_LIMIT,'maximum_target_bytes':TARGET_LIMIT,'sample_interval_seconds':1},
      'commands':[],'original_class_lanes':[],'original_source_lanes':[],'jadx':None,'renders':[],'render_source_lanes':[],
      'source_pins_before':[pin(CLASS),pin(SOURCE),pin(jar)],'source_pins_after':None}
 dump(out/'execution.json',doc); counter=0
 def run(label,argv,home):
  nonlocal counter
  counter+=1; env={k:v for k,v in os.environ.items() if k not in STRIP_ENV}; env['JAVA_HOME']=str(home); env['PATH']=str(home/'bin')+os.pathsep+env.get('PATH','')
  row={'index':counter,'label':label,'argv':[str(x) for x in argv],'cwd':str(ROOT),'java_home':str(home),'state':'started','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  doc['commands'].append(row); dump(out/'execution.json',doc)
  result=guard.run_command(counter,row['argv'],env); row.update(result); row['label']=label; row['state']='guard-stopped' if row.get('guard_stop') else 'observed'
  streams={}
  for name,ref in row.get('streams',{}).items():
   p=Path(ref['path']); b=p.read_bytes(); ref.update(bytes=len(b),sha256=sha(b)); streams[name]=b
  dump(out/'execution.json',doc)
  if row.get('guard_stop'): raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
  return row,streams.get('stdout',b''),streams.get('stderr',b'')
 def compile_run(label,files,jdk,outclasses,main='TR'):
  outclasses.mkdir(parents=True); empty=outclasses/'empty-classpath'; empty.mkdir(); leg=legs[jdk]
  flags=['-source','8','-target','8','-Xlint:-options'] if jdk=='javac8' else ['--release','8']
  c,_,_=run(label+'-compile',[leg['tools']['javac'],*flags,'-proc:none','-g:none','-classpath',empty,'-sourcepath',empty,'-d',outclasses,*files],leg['home'])
  lane={'label':label,'jdk':jdk,'sources':[pin(x) for x in files],'compile':c,'run':None,'runtime_state':'compile-failed-no-runtime','stdout':None,'stdout_sha256':None,'stderr_sha256':None}
  if c.get('exit_code')==0:
   r,stdout,stderr=run(label+'-run',[leg['tools']['java'],'-Xverify:all','-cp',outclasses,main],leg['home'])
   lane.update(run=r,runtime_state='ran' if r.get('exit_code')==0 else 'run-failed',stdout=stdout.decode('utf-8','replace'),stdout_sha256=sha(stdout),stderr_sha256=sha(stderr))
  return lane
 try:
  for jdk in ('javac8','javac23'):
   row,stdout,stderr=run('original-frozen-class-'+jdk,[legs[jdk]['tools']['java'],'-Xverify:all','-cp',CLASS.parent,'TR'],legs[jdk]['home'])
   lane={'jdk':jdk,'command':row,'stdout':stdout.decode('utf-8','replace'),'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr),'exit_code':row.get('exit_code')}
   doc['original_class_lanes'].append(lane); dump(out/'execution.json',doc)
  for jdk in ('javac8','javac23'):
   lane=compile_run('original-source-'+jdk,[SOURCE],jdk,out/'original-source'/jdk)
   doc['original_source_lanes'].append(lane); dump(out/'execution.json',doc)
  jadxdir=out/'jadx-source'; jadxdir.mkdir(); row,stdout,stderr=run('jadx-decompile',[JADX,'-d',jadxdir,jar],legs['javac23']['home'])
  jfiles=sorted(jadxdir.rglob('*.java')); doc['jadx']={'command':row,'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr),'sources':[pin(p) for p in jfiles],'source_count':len(jfiles),'lanes':[]}
  for jdk in ('javac8','javac23'):
   lane=compile_run('jadx-'+jdk,jfiles,jdk,out/'jadx-classes'/jdk)
   doc['jadx']['lanes'].append(lane); dump(out/'execution.json',doc)
  for cli_label,cli,ev in (('parent_v5',OLD_CLI,old_ev),('current_final_v4',CURRENT_CLI,current_ev)):
   forms={}
   for fmt in ('json','text'):
    base=out/'renders'/cli_label/fmt; base.mkdir(parents=True)
    argv=[cli,'class-source','--input',jar,'--class','TR','--policy','plain-jar','--release','8','--format',fmt,'--evidence','all']
    row,stdout,stderr=run(cli_label+'-TR-'+fmt,argv,legs['javac23']['home']); rp=base/('response.raw.json' if fmt=='json' else 'response.raw.txt'); rp.write_bytes(stdout)
    entry={'command':row,'stdout_pin':pin(rp),'stderr_sha256':sha(stderr),'parsed':None}
    if fmt=='json' and row.get('exit_code')==0:
     response=json.loads(stdout.decode('utf-8')); dump(base/'report.json',response); text=response.get('text')
     if isinstance(text,str):
      src=base/'TR.java'; src.write_text(text,encoding='utf-8'); methods=[]
      for m in response.get('methods',[]):
       outcome=m.get('outcome',{}); report=outcome.get('report',{})
       methods.append({'identity':m.get('item',{}).get('identity'),'name':m.get('item',{}).get('name'),'descriptor':m.get('item',{}).get('descriptor'),
        'declaration':m.get('declaration'),'text':m.get('text'),'outcome_kind':outcome.get('kind'),'report':report,'concat_facts':report.get('concats'),
        'source_maps':{k:v for k,v in report.items() if 'map' in k.lower()}})
      dump(base/'methods.json',methods)
      entry['parsed']={'report_pin':pin(base/'report.json'),'source_pin':pin(src),'methods_pin':pin(base/'methods.json'),'source_text_sha256':sha(text.encode())}
      for jdk in ('javac8','javac23'):
       lane=compile_run(cli_label+'-rendered-'+jdk,[src],jdk,out/'render-classes'/cli_label/jdk)
       lane['cli']=cli_label; doc['render_source_lanes'].append(lane); dump(out/'execution.json',doc)
    forms[fmt]=entry
   doc['renders'].append({'cli':cli_label,'cli_pin':ev['cli'],'formats':forms}); dump(out/'execution.json',doc)
  doc['source_pins_after']=[pin(CLASS),pin(SOURCE),pin(jar)]
  if doc['source_pins_before']!=doc['source_pins_after']: raise RuntimeError('frozen sample inputs changed')
  doc['status']='observed'; dump(out/'execution.json',doc)
  return 0
 except BaseException as e:
  doc['status']='failed'; doc['failure']={'type':type(e).__name__,'message':str(e),'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}; dump(out/'execution.json',doc); raise

if __name__=='__main__':
 try: raise SystemExit(main())
 except BaseException as e:
  print(f'collector failed: {type(e).__name__}: {e}',file=sys.stderr); raise SystemExit(1)
