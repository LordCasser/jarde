# Root 多行测试日志适配

继承已审阅 workspace-prep-luna-v2 的全部来源、metadata、两 seed、完整 inventory、raw/artifact、资源和 cleanup 条件。仅把具名测试结果读取扩大到 Rust harness 的 --nocapture 多行输出，且不越过下一条 `test ` 记录，保留 `- should panic` 名称。focused-v6 两个测试命令实际提取390与116结果（后者113成功、3 ignored），严格等于原raw各summary之和。

原v2在 focused command4 对多行P5漏计，root-v3首次仅支持无空格名称导致漏掉一个 should-panic，二者都在前置验收阶段 exit1、未创建 workspace-run-v5、未执行Cargo。root-v4完成名称修正后实际启动，scope/seed/失败路径与v2相同。旧准备文件未改写。CI verifier root-v3使用同一解析器，workflow计数和全部具名状态比较仍完整保留。

本说明记录适配与观察，不声称正在运行的 workspace-v5 已通过。
