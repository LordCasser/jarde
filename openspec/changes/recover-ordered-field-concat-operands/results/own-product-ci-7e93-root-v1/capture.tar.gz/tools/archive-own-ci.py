#!/usr/bin/env python3
"""Create a durable, referenced own-CI evidence archive after acceptance."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile
import tempfile

CAPTURE_COLLECTOR = Path('/private/tmp/jarde-ordered-field-own-ci-prep-luna-v1/capture-own-ci.py')
CAPTURE_SHA256 = '842ce7f7b9ae20c19962b9495fb62c1d8eac2d87ccc05d1c482d4c95818a7bdf'
OWN_CI_VERIFIER = Path('/private/tmp/jarde-wrap-workspace-acceptance-prep-luna-v4/verify-own-ci.py')
OWN_CI_VERIFIER_SHA256 = '08dd3bf0758400ad413eba0d12283ff584c6c00f7b11b53d0b6af948f7b8c5db'
WORKSPACE_RUNNER = Path('/private/tmp/jarde-wrap-validation-prep-luna-v1/workspace/workspace_runner.py')
WORKSPACE_RUNNER_SHA256 = '557d1decba94c3f0e58fee22c7335de77f3087c9337924824724f0412135c38f'
WORKSPACE_ACCEPTOR = Path('/private/tmp/jarde-wrap-workspace-acceptance-prep-luna-v2/accept_workspace.py')
WORKSPACE_ACCEPTOR_SHA256 = '5a0ba7f3e763706701117017fd628383c7281ee288e3af902a01bfcdaa8f1d4c'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_pin(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8'))


def safe_member(name: str) -> str:
    p = PurePosixPath(name)
    need(not p.is_absolute() and '..' not in p.parts and name not in ('', '.'), f'unsafe archive member: {name!r}')
    return p.as_posix()


def check_prior(kind: str, archive: Path, manifest_path: Path) -> dict:
    manifest = load(manifest_path)
    members = manifest.get('members')
    need(isinstance(members, list) and members, f'{kind}: missing member manifest')
    expected = {}
    for row in members:
        name = safe_member(row.get('path', ''))
        need(name not in expected, f'{kind}: duplicate manifest member {name}')
        expected[name] = (row.get('bytes'), row.get('sha256'))
    raw = archive.read_bytes()
    archive_sha = sha(raw)
    pinned_sha = manifest.get('archive_sha256')
    archive_row = manifest.get('archive')
    if isinstance(archive_row, dict):
        pinned_sha = archive_row.get('sha256')
        need(archive_row.get('bytes') == len(raw), f'{kind}: archive byte count differs')
    if pinned_sha is not None:
        need(pinned_sha == archive_sha, f'{kind}: archive SHA differs from manifest')
    seen = {}
    with tarfile.open(archive, 'r:gz') as tf:
        for member in tf.getmembers():
            if not member.isfile():
                continue
            name = safe_member(member.name)
            stream = tf.extractfile(member)
            need(stream is not None, f'{kind}: cannot read {name}')
            data = stream.read()
            if name in expected:
                seen[name] = (len(data), sha(data))
            elif name not in ('README.md', 'members.json'):
                raise ValueError(f'{kind}: unexpected tar member {name}')
    need(seen == expected, f'{kind}: archive content differs from detached member manifest')
    return {'kind': kind, 'archive_path': str(archive), 'archive_bytes': len(raw), 'archive_sha256': archive_sha,
            'manifest_path': str(manifest_path), 'manifest_sha256': sha(manifest_path.read_bytes()),
            'verified_members': len(seen), 'member_sha256_by_path': {name: value[1] for name, value in seen.items()}}


def tar_json_member(archive: Path, suffix: str) -> dict:
    with tarfile.open(archive, 'r:gz') as tf:
        choices = [m for m in tf.getmembers() if m.isfile() and m.name.endswith(suffix)]
        need(len(choices) == 1, f'archive must contain exactly one {suffix}')
        stream = tf.extractfile(choices[0])
        need(stream is not None, f'cannot read archive member {choices[0].name}')
        return json.loads(stream.read())


def capture_inputs(capture_dir: Path, product: str, run_id: int, accepted: dict) -> tuple[Path, list[Path], dict]:
    execution = capture_dir / 'capture-execution-root-v2.json'
    doc = load(execution)
    need(doc.get('schema') == 'ordered-field-own-ci-capture-v1' and doc.get('status') == 'captured',
         'capture is not a completed v2 capture')
    need(doc.get('product_commit') == product and doc.get('run_id') == run_id,
         'capture product/run binding differs')
    need(doc.get('jobs') == 4 and isinstance(doc.get('steps'), int) and doc['steps'] == 52,
         'capture is not the accepted 4-job/52-step observation')
    summary = doc.get('validated_run_summary', {})
    need(summary.get('headSha') == product and summary.get('status') == 'completed' and summary.get('conclusion') == 'success',
         'capture summary binding/status differs')
    commands = doc.get('commands')
    need(isinstance(commands, list) and len(commands) == 3, 'capture does not contain exactly its three actual commands')
    files = {execution.resolve()}
    for i, cmd in enumerate(commands):
        need(cmd.get('exit_code') == 0 and cmd.get('timed_out') is False and cmd.get('spawn_error') is None,
             f'capture command {i} did not complete successfully')
        for stream_name in ('stdout', 'stderr', 'stdout_raw'):
            row = cmd.get(stream_name)
            if row is None:
                continue
            need(isinstance(row, dict), f'capture command {i} {stream_name} reference malformed')
            rel = safe_member(row.get('path', ''))
            path = (capture_dir / rel).resolve(strict=True)
            need(path.parent == capture_dir.resolve(), f'capture artifact escapes its directory: {rel}')
            data = path.read_bytes()
            need(len(data) == row.get('bytes') and sha(data) == row.get('sha256'),
                 f'capture artifact byte/SHA pin differs: {rel}')
            if 'raw_sha256' in row:
                unpacked = gzip.decompress(data) if rel.endswith('.gz') else data
                need(row['raw_sha256'] == sha(unpacked), f'capture raw SHA field differs: {rel}')
                if 'uncompressed_bytes' in row:
                    need(row['uncompressed_bytes'] == len(unpacked), f'capture uncompressed byte count differs: {rel}')
            files.add(path)
        packed_stdout = cmd.get('stdout', {})
        raw_stdout = cmd.get('stdout_raw')
        if isinstance(packed_stdout, dict) and 'raw_sha256' in packed_stdout:
            need(isinstance(raw_stdout, dict) and raw_stdout.get('sha256') == packed_stdout['raw_sha256'] and
                 raw_stdout.get('bytes') == packed_stdout.get('uncompressed_bytes'),
                 f'capture command {i} compressed/raw stdout references disagree')
    need(accepted.get('ci', {}).get('capture_sha256') == sha(execution.read_bytes()),
         'acceptance does not bind the supplied capture execution receipt')
    return execution, sorted(files), doc


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--product-commit', required=True)
    ap.add_argument('--run-id', required=True, type=int)
    ap.add_argument('--capture', required=True, type=Path, help='capture directory')
    ap.add_argument('--acceptance', required=True, type=Path)
    ap.add_argument('--acceptance-sha256', required=True)
    ap.add_argument('--out', required=True, type=Path, help='fresh destination directory')
    ap.add_argument('--prior-archive', action='append', nargs=3, metavar=('KIND', 'TAR_GZ', 'MANIFEST'), required=True,
                    help='repeat for workspace-v9, local, and full-class references')
    args = ap.parse_args()
    need(len(args.product_commit) == 40 and all(c in '0123456789abcdef' for c in args.product_commit), 'invalid product commit')
    need(args.run_id > 0, 'invalid run ID')
    acceptance_path = args.acceptance.resolve(strict=True)
    acceptance_bytes = acceptance_path.read_bytes()
    need(sha(acceptance_bytes) == args.acceptance_sha256, 'acceptance SHA differs from runtime pin')
    accepted = json.loads(acceptance_bytes)
    need(accepted.get('schema') == 'ordered-field-own-ci-acceptance-v1' and
         accepted.get('status') == 'accepted_local_own_ci_observation', 'own-CI acceptance is not accepted')
    need(accepted.get('product_commit') == args.product_commit and accepted.get('run_id') == args.run_id,
         'acceptance product/run binding differs')
    ci = accepted.get('ci', {})
    need(ci.get('jobs') == 4 and ci.get('steps') == 52 and ci.get('all_jobs_and_steps_succeeded') is True,
         'acceptance does not record 4 successful jobs and 52 successful steps')
    closure = accepted.get('source_closure', {})
    need(closure.get('count') == 4854 and closure.get('focused_workspace_product_git_live_equal') is True,
         'acceptance source-closure evidence differs')
    refs = accepted.get('references', {})
    need(refs.get('capture_collector') == {'path': str(CAPTURE_COLLECTOR), 'sha256': CAPTURE_SHA256},
         'acceptance capture collector reference differs')
    need(refs.get('workspace_runner', {}).get('path') == str(WORKSPACE_RUNNER) and
         refs.get('workspace_runner', {}).get('sha256') == WORKSPACE_RUNNER_SHA256,
         'acceptance workspace runner reference differs')
    need(refs.get('workspace_acceptor', {}).get('path') == str(WORKSPACE_ACCEPTOR) and
         refs.get('workspace_acceptor', {}).get('sha256') == WORKSPACE_ACCEPTOR_SHA256,
         'acceptance workspace acceptor reference differs')
    need(CAPTURE_COLLECTOR.is_file() and sha(CAPTURE_COLLECTOR.read_bytes()) == CAPTURE_SHA256, 'capture collector pin changed')
    need(OWN_CI_VERIFIER.is_file() and sha(OWN_CI_VERIFIER.read_bytes()) == OWN_CI_VERIFIER_SHA256, 'own-CI verifier pin changed')
    need(WORKSPACE_RUNNER.is_file() and sha(WORKSPACE_RUNNER.read_bytes()) == WORKSPACE_RUNNER_SHA256, 'workspace runner pin changed')
    need(WORKSPACE_ACCEPTOR.is_file() and sha(WORKSPACE_ACCEPTOR.read_bytes()) == WORKSPACE_ACCEPTOR_SHA256, 'workspace acceptor pin changed')
    capture_dir = args.capture.resolve(strict=True)
    _, capture_files, capture_doc = capture_inputs(capture_dir, args.product_commit, args.run_id, accepted)
    focused = accepted.get('focused_receipt', {})
    workspace = accepted.get('fresh_local_workspace', {})
    need(focused.get('sha256') and workspace.get('execution_sha256') and workspace.get('workspace_acceptance_sha256'),
         'acceptance focused/workspace reference hashes are incomplete')
    prior = [check_prior(kind, Path(tar).resolve(strict=True), Path(manifest).resolve(strict=True))
             for kind, tar, manifest in args.prior_archive]
    need({x['kind'] for x in prior} == {'workspace-v9', 'local', 'full-class'},
         'supply exactly workspace-v9, local, and full-class archive references')
    workspace_archive = next(x for x in prior if x['kind'] == 'workspace-v9')
    local_archive = next(x for x in prior if x['kind'] == 'local')
    local_focus_sha = local_archive['member_sha256_by_path'].get('execution.json')
    need(local_focus_sha == focused['sha256'],
         'accepted focused receipt SHA does not resolve to execution.json in the supplied local archive')
    workspace_hashes = workspace_archive['member_sha256_by_path']
    need(workspace['execution_sha256'] in workspace_hashes.values() and
         workspace['workspace_acceptance_sha256'] in workspace_hashes.values(),
         'workspace execution/acceptance hashes do not resolve to supplied workspace-v9 archive members')
    workspace_tar = Path(workspace_archive['archive_path'])
    focused_summary = tar_json_member(workspace_tar, 'focused-receipt-summary.json')
    need(focused_summary.get('sha256') == focused['sha256'],
         'workspace-v9 focused summary reference differs from own-CI acceptance focused receipt SHA')
    local_reference = tar_json_member(workspace_tar, 'prior-localarchive-reference.json')
    need(local_reference.get('archive_sha256') == local_archive['archive_sha256'],
         'workspace-v9 local archive reference does not bind the supplied local archive')

    out = args.out.resolve()
    need(not out.exists(), f'refusing to overwrite {out}')
    out.mkdir(parents=True)
    source_files = [acceptance_path, *capture_files, CAPTURE_COLLECTOR, OWN_CI_VERIFIER, WORKSPACE_RUNNER, WORKSPACE_ACCEPTOR,
                    Path(__file__).resolve()]
    unique = {}
    for src in source_files:
        src = src.resolve(strict=True)
        unique[src] = src
    entries = []
    def add_data(tf: tarfile.TarFile, name: str, data: bytes) -> None:
        name = safe_member(name)
        import io
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o444
        info.mtime = 0
        tf.addfile(info, io.BytesIO(data))
        entries.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
    evidence = {'schema': 'ordered-field-own-ci-archive-references-v1', 'product_commit': args.product_commit,
                'run_id': args.run_id, 'capture_sha256': sha((capture_dir/'capture-execution-root-v2.json').read_bytes()),
                'acceptance_sha256': args.acceptance_sha256, 'focused_receipt_sha256': focused['sha256'],
                'workspace_execution_sha256': workspace['execution_sha256'],
                'workspace_acceptance_sha256': workspace['workspace_acceptance_sha256'],
                'source_closure_count': 4854, 'prior_archives': prior,
                'capture_command_count': len(capture_doc['commands'])}
    archive = out / 'capture.tar.gz'
    with tarfile.open(archive, 'w:gz', compresslevel=9) as tf:
        for src in sorted(unique, key=lambda p: str(p)):
            if src == acceptance_path:
                arcname = 'evidence/own-ci-acceptance.json'
            elif src in capture_files:
                arcname = 'evidence/capture/' + src.name
            elif src == CAPTURE_COLLECTOR:
                arcname = 'tools/capture-own-ci.py'
            elif src == OWN_CI_VERIFIER:
                arcname = 'tools/verify-own-ci.py'
            elif src == WORKSPACE_RUNNER:
                arcname = 'tools/workspace_runner.py'
            elif src == WORKSPACE_ACCEPTOR:
                arcname = 'tools/accept_workspace.py'
            else:
                arcname = 'tools/archive-own-ci.py'
            add_data(tf, arcname, src.read_bytes())
        add_data(tf, 'evidence/prior-archive-references.json', (json.dumps(evidence, sort_keys=True, indent=2)+'\n').encode())
    archive_raw = archive.read_bytes()
    manifest = {'schema': 'ordered-field-own-ci-durable-archive-v1',
                'archive': {'path': archive.name, 'bytes': len(archive_raw), 'sha256': sha(archive_raw)}, 'members': entries}
    manifest_path = out / 'members.json'
    manifest_path.write_text(json.dumps(manifest, sort_keys=True, indent=2)+'\n', encoding='utf-8')
    readme = ('# Own-CI observation archive\n\n'
              f'This archive records an accepted local own-CI observation for product commit `{args.product_commit}` and run `{args.run_id}`. '
              'It contains the verifier acceptance, its three-command capture and pinned raw/log artifacts, and the referenced verifier tools. '
              'The prior workspace-v9, local, and full-class archives are referenced and byte-checked; their contents are not duplicated here. '
              'This records the accepted observation only; it does not claim that the product was pushed or merged.\n\n'
              'Verify `capture.tar.gz` against `members.json`; every member is reopened and checked by the preparation script.\n')
    (out/'README.md').write_text(readme, encoding='utf-8')
    # Reopen the final tar and check every recorded member byte-for-byte.
    with tarfile.open(archive, 'r:gz') as tf:
        for row in entries:
            stream = tf.extractfile(row['path'])
            need(stream is not None, f"archive member missing: {row['path']}")
            data = stream.read()
            need(len(data) == row['bytes'] and sha(data) == row['sha256'], f"archive member changed: {row['path']}")
    print(json.dumps({'status': 'archive_created', 'archive': str(archive), 'archive_sha256': sha(archive_raw),
                      'members': len(entries), 'product_commit': args.product_commit, 'run_id': args.run_id}, indent=2))

if __name__ == '__main__':
    main()
