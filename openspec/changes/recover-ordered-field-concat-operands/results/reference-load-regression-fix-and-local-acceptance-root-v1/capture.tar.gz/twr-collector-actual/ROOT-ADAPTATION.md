仅把 current CLI 入口改为修复后的 final-check-root-v7；所有完整类、原/JADX/父项、双 JDK、来源、失败无运行与 guard 门保持。旧 schema key current_final_v4 为历史标签，真实产品绑定由 cli path/hash/receipt 证明。尚未执行。
