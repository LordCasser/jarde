#!/usr/bin/env python3
"""Offline acceptance checker; never invokes JDK, JADX, CLI, or Cargo."""
import argparse, hashlib, json, sys
from pathlib import Path

def need(ok,msg):
 if not ok: raise ValueError(msg)
def verify(ref):
 need(isinstance(ref,dict) and all(k in ref for k in ('path','bytes','sha256')),'incomplete artifact pin')
 p=Path(ref['path']); need(p.is_file() and not p.is_symlink(),f'missing/linked artifact {p}')
 b=p.read_bytes(); need(len(b)==ref['bytes'] and hashlib.sha256(b).hexdigest()==ref['sha256'],f'hash mismatch {p}'); return b
def lane_stdout(lane):
 run=lane.get('run'); need(isinstance(run,dict),'successful lane has no runtime command')
 need(run.get('exit_code')==0 and not run.get('guard_stop'),f"runtime failed: {lane.get('label')}")
 raw=verify(run['streams']['stdout'])
 need(lane.get('stdout_sha256')==hashlib.sha256(raw).hexdigest(),f"runtime stdout hash mismatch: {lane.get('label')}")
 need(lane.get('stdout')==raw.decode('utf-8','replace'),f"runtime stdout text differs from raw bytes: {lane.get('label')}")
 return raw
def decode_method_name(item):
 n=item.get('name'); return n.get('escaped') if isinstance(n,dict) else n if isinstance(n,str) else None
def methods_from_render(render):
 parsed=render['formats']['json']['parsed']; raw=verify(parsed['report_pin']); report=json.loads(raw)
 source=verify(parsed['source_pin']); need(source==report['text'].encode('utf-8'),'saved generated source differs byte-for-byte from JSON report')
 methods=report.get('methods'); need(isinstance(methods,list) and methods,'JSON report contains no method list')
 derived=[]; result={}
 for row in methods:
  item=row.get('item',{}); name=decode_method_name(item); identity=item.get('identity')
  need(name and isinstance(identity,dict),'method lacks stable name or physical identity')
  key=json.dumps(identity,sort_keys=True,separators=(',',':'))
  need(name not in result,f'duplicate method name {name}')
  result[name]=(key,row)
  outcome=row.get('outcome',{}); method_report=outcome.get('report',{})
  derived.append({'identity':identity,'name':item.get('name'),'descriptor':item.get('descriptor'),
   'declaration':row.get('declaration'),'text':row.get('text'),'outcome_kind':outcome.get('kind'),'report':method_report,
   'concat_facts':method_report.get('concats'),'source_maps':{k:v for k,v in method_report.items() if 'map' in k.lower()}})
 facts=json.loads(verify(parsed['methods_pin']).decode('utf-8'))
 need(facts==derived,'saved method/report/concat/map facts differ from complete raw JSON report')
 need({'one','two','use','close'}.issubset(result),'one/two/use/close methods are missing')
 return report,result

def require_lane(lane,jdk,main_class):
 comp=lane.get('compile'); need(isinstance(comp,dict),'lane has no compile attempt')
 need(comp.get('exit_code')==0 and not comp.get('guard_stop'),f"compile failed: {lane.get('label')}")
 expected_javac=jdk['tools']['javac']; need(comp.get('argv',[None])[0]==expected_javac,'lane compiled with an unpinned javac')
 need(all(verify(x) is not None for x in lane.get('sources',[])),'lane source pins missing')
 need(lane.get('main_class')==main_class,'lane main class differs from derived class identity')
 run=lane.get('run'); need(isinstance(run,dict) and run.get('exit_code')==0,'lane has no successful runtime command')
 need(run.get('argv',[None])[0]==jdk['tools']['java'] and run.get('argv',[])[-1:]==[main_class],'lane ran with wrong Java or main class')
 return lane_stdout(lane)

def validate(ep):
 outdir=ep.parent; d=json.loads(ep.read_text())
 need(d.get('status')=='observed' and d.get('schema')=='twr-javac23-differential-v1','collector receipt is incomplete')
 for ref in (d['frozen_class'],d['original_source'],d['archive'],d['jdk_manifest'],*d['tools'].values()): verify(ref)
 need(d['source_pins_before']==d['source_pins_after'],'frozen class/source/archive pins changed')
 for row in d['commands']:
  need(row.get('state')=='observed' and row.get('guard_stop') is None,f"resource guard stopped {row.get('label')}")
  for stream in row.get('streams',{}).values(): verify(stream)
 renders={r['cli']:r for r in d['renders']}; need(set(renders)=={'parent_v5','current_final_v4'},'render sides missing')
 expected_cli={'parent_v5':'/private/tmp/jarde-loop-combined-focused-root-v5/candidate-cli','current_final_v4':'/private/tmp/jarde-ordered-field-final-check-root-v4/candidate-cli'}
 reports={}; methodsets={}
 for label,render in renders.items():
  need(render['cli_pin']['path']==expected_cli[label],'render CLI identity differs')
  for fmt in ('json','text'):
   entry=render['formats'][fmt]; raw=verify(entry['stdout_pin'])
   need(verify(entry['command']['streams']['stdout'])==raw,'saved render output differs from command stdout')
   need(entry['command'].get('exit_code')==0,'Jarde render command failed')
   argv=entry['command']['argv']; need(argv==[expected_cli[label],'class-source','--input',d['archive']['path'],'--class','TR','--policy','plain-jar','--release','8','--format',fmt,'--evidence','all'],f'{label}/{fmt} render argv differs')
  json_report,methods=methods_from_render(render); reports[label]=json_report; methodsets[label]=methods
 old=methodsets['parent_v5']; cur=methodsets['current_final_v4']; changed=[]
 for name in sorted(set(old)|set(cur)):
  if name not in old or name not in cur: changed.append(name); continue
  need(old[name][0]==cur[name][0],f'physical method identity differs for {name}')
  if old[name][1].get('text')!=cur[name][1].get('text'): changed.append(name)
 need(old['one'][1].get('text')==cur['one'][1].get('text'),'one() full method text changed')
 need(old['two'][1].get('text')==cur['two'][1].get('text'),'two() full method text changed')
 need(set(changed).issubset({'use','close'}),f'method text changed outside use/close: {changed}')
 jdklegs=d['jdk_legs']; baselines={}; states=[]
 original_class={r['jdk']:r for r in d['original_class_lanes']}; original_source={r['jdk']:r for r in d['original_source_lanes']}
 need(set(original_class)=={'javac8','javac23'} and set(original_source)=={'javac8','javac23'},'original class/source JDK lanes incomplete')
 for jdkname in ('javac8','javac23'):
  leg=jdklegs[jdkname]
  classrow=original_class[jdkname]; need(classrow['exit_code']==0,'original frozen class runtime failed')
  classbytes=verify(classrow['command']['streams']['stdout'])
  need(classrow['command'].get('argv',[None])[0]==leg['tools']['java'] and classrow['command'].get('argv',[])[-1:]==['TR'],'original frozen class used wrong runtime argv')
  need(classrow['stdout_sha256']==hashlib.sha256(classbytes).hexdigest() and classrow['stdout']==classbytes.decode('utf-8','replace'),'original class stdout differs from raw')
  sourcebytes=require_lane(original_source[jdkname],leg,'TR')
  need(classbytes==sourcebytes,f'original frozen class/source stdout bytes differ on {jdkname}')
  baselines[jdkname]=classbytes
  states.append({'candidate':'original-source','jdk':jdkname,'compile_exit':original_source[jdkname]['compile']['exit_code'],'run_exit':original_source[jdkname]['run']['exit_code']})
 candidate={(r['cli'],r['jdk']):r for r in d['render_source_lanes']}
 expected_lanes={(c,j) for c in ('parent_v5','current_final_v4') for j in ('javac8','javac23')}
 need(set(candidate)==expected_lanes,'Jarde source runtime lanes incomplete')
 runtime_comparisons=[]
 for cli,jdkname in sorted(expected_lanes):
  lane=candidate[(cli,jdkname)]; out=require_lane(lane,jdklegs[jdkname],'TR')
  need(out==baselines[jdkname],f'{cli} generated source stdout differs byte-for-byte from original on {jdkname}')
  runtime_comparisons.append({'candidate':cli,'jdk':jdkname,'stdout_byte_equal_to_original':True,'stdout_sha256':hashlib.sha256(out).hexdigest()})
  states.append({'candidate':cli,'jdk':jdkname,'compile_exit':lane['compile']['exit_code'],'run_exit':lane['run']['exit_code']})
  need(lane.get('cli')==cli,f'{cli}/{jdkname} lane identity differs')
 jadx=d['jadx']; need(isinstance(jadx,dict) and jadx.get('source_count')>0,'JADX emitted no Java sources')
 jlanes={r['jdk']:r for r in jadx['lanes']}; need(set(jlanes)=={'javac8','javac23'},'JADX JDK lanes incomplete')
 for jdkname,lane in jlanes.items():
  out=require_lane(lane,jdklegs[jdkname],jadx['main_class'])
  need(out==baselines[jdkname],f'JADX output differs byte-for-byte from original on {jdkname}')
  runtime_comparisons.append({'candidate':'jadx','jdk':jdkname,'stdout_byte_equal_to_original':True,'stdout_sha256':hashlib.sha256(out).hexdigest()})
  states.append({'candidate':'jadx','jdk':jdkname,'compile_exit':lane['compile']['exit_code'],'run_exit':lane['run']['exit_code']})
 result={'status':'accepted','receipt':str(ep),'changed_method_text_names':changed,'only_use_close_method_text_changed':True,
  'one_two_complete_method_text_equal':True,'full_report_method_concat_maps_preserved_and_checked':True,
  'runtime_comparisons':runtime_comparisons,'all_required_lanes_compile_and_run_exit_zero':True,
  'lane_exit_states':states,'toolchain_executed_by_checker':False}
 return result

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('execution',type=Path); ap.add_argument('--out',type=Path); a=ap.parse_args()
 ep=a.execution.resolve(strict=True); dest=a.out.resolve() if a.out else ep.parent/'check.json'
 try: result=validate(ep)
 except Exception as e:
  result={'status':'unaccepted','receipt':str(ep),'failure':{'type':type(e).__name__,'message':str(e)},'toolchain_executed_by_checker':False}
  dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n'); print(json.dumps(result,ensure_ascii=False,indent=2)); return 1
 dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n'); print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
