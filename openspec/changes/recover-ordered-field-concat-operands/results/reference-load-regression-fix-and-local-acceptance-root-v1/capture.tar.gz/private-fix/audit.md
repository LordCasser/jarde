# Read-only audit of the applied private candidate

Scope: inspected the current `build.rs` helper and the private candidate README. No shared files were
changed and no Cargo/JDK/JADX/CLI/Git command was run.

## Findings

1. `catch_parameter_stays_in_clause` rejects a missing phi record and an explicit
   `PhiInput::Itself`, but it does **not** reject an empty recorded phi. The phi branch obtains
   `Some(inputs)`, iterates zero inputs, then lets the worklist drain and returns `true`. The new
   synthetic outside-read calls this helper, so an empty phi can be mistaken for a caught-alias-free
   source. Minimum fix: return `Ok(false)` when `inputs.is_empty()` before iterating. This matches the
   helper's existing “unknown phi inputs keep the old refusal” contract.

2. The helper only branches on replacement, phi, and instruction definitions. A
   `Definition::Caught` that is not equal to the registered handler-entry store falls through and is
   accepted. Normal catch aliases should hit the entry-store identity first, but the proof should
   state its contract directly. Minimum fix: explicitly return `Ok(false)` for
   `Definition::Caught { .. }` (or make the definition match exhaustive with refusal as the default).
   `Definition::Entry` must remain admissible here because this helper also receives ordinary
   method-parameter copies; the separate reaching-read proof remains responsible for rejecting an
   entry value as an uninitialized definition of the hoisted local.

3. README's “incomplete phi ... refused” is too broad until (1) is fixed. A missing phi table entry
   and `PhiInput::Itself` are refused; an empty phi is currently accepted. After the minimal fix, the
   phrase is accurate for the phi shapes this helper can observe. The phrase “unknown edge” should be
   limited to unknown/missing phi inputs because method `Entry` sources intentionally remain valid.

4. The decided-type check is soundly conservative for the ordinary named types represented by
   `RefType::Named`: `value_type` normalizes class descriptors and array descriptors through
   `spell_reference`; equality then requires the same Java spelling. Arrays are represented as
   named descriptors, so exact array types compare correctly. A named subtype to a supertype (for
   example `String[]` to `Object[]`, or a concrete class to an interface) is refused without
   hierarchy evidence. `RefType::Unknown` is spelled as `Object`; the special Object-target branch
   accepts any `Value::Ref`, which is safe for assignment to `java.lang.Object`. Accepting both
   `Object` and `java.lang.Object` as the target spelling is harmless.

5. The README claims a null reference Load can be admitted, and the type helper has a null arm, but
   `presented_reference_store_value` first requires `Value::Ref(_)`; a Load whose SSA type is
   `Value::Null` is rejected before the type helper runs. This is a conservative false negative, not
   an unsound acceptance. Minimum scope choice: remove the unreachable null arm and say “exact named
   type or Object” in the README. Supporting null would require changing the upstream Load proof too,
   so that is unnecessary for this regression.

## Recommendation

Before accepting the safety claim, add the two one-line catch-walk refusals (empty phi and explicit
Caught), and narrow the README's null and unknown-edge wording. Do not expand the type solver; exact
normalized names plus the Object rule safely constrain this newly admitted Load path, with subtype
cases left refused.
