# Private candidate: close the cross-exception reference Load gate

This candidate is based on the shared `crates/jarde-java/src/build.rs` SHA-256
`ebe8af9449baccf14cf0e2cdf70bcb1861a8e467fdc6110179aedabb5968d187`.

`reference-load-caught-alias.patch` changes only `build.rs`. It keeps the new same-block,
immediate-predecessor Load admission and adds two requirements for that path:

- Trace the Load's actual local input through the existing bounded catch-parameter SSA alias proof.
  A direct or copied catch binding, an incomplete phi, or an unknown edge is refused. Parameter
  `Entry` values remain admissible.
- Pass the decided declaration type into the reaching-write proof. Each newly admitted reference
  Load must have the exact verifier-stated type, be null, or target `Object`. A hierarchy conversion
  without class-assignability evidence is refused.

Constructor and static-call branches remain unchanged. The permanent unit test uses the existing
`ScopeRefusalsEscape.sharedHandler` class fixture and its actual SSA chain (catch entry -> local Load
-> slot 1 store), and asserts both the catch-alias and Runnable-type refusals. The copied
`tests/preserve_local_scope_refusals.rs` is review context only; it is not changed, so the existing
SHARED/ESCAPED assertions remain as-is.

This is deliberately scoped to the new Load admission. It does not change the general type solver or
add a public carrier. No Cargo/JDK/JADX/CLI/Git command was run.
