#!/usr/bin/env python3
"""Guarded replay of each CLI's rendered root and Base source files."""
from __future__ import annotations
import datetime, hashlib, importlib.util, json, os, re, sys
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
PREP = Path(__file__).resolve().parent
GUARD = ROOT / 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
V2_EXEC = Path('/private/tmp/jarde-anonymous-super-args-comparison-root-v2/execution.json')
FREE_LIMIT, TARGET_LIMIT = 5 * 1024**3, 1024**3
EXPECTED = 'arg:capture|arg:super-label|arg:super-value|base:explicit:17\nexplicit:17:captured\n'
STRIP_ENV = ('JAVA_HOME', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH')


def sha(b: bytes) -> str: return hashlib.sha256(b).hexdigest()
def pin(p: Path) -> dict:
    p = Path(p).resolve(strict=True); b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}
def dump(p: Path, x) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def main() -> int:
    if len(sys.argv) != 2: raise SystemExit('usage: projected-root-replay.py FRESH_OUTPUT_DIR')
    out = Path(sys.argv[1]).resolve()
    if out.exists(): raise SystemExit(f'refusing non-fresh output: {out}')
    v2 = json.loads(V2_EXEC.read_text(encoding='utf-8'))
    if v2.get('status') != 'observed': raise SystemExit('v2 execution receipt is not observed')
    candidate_rows = {row.get('cli'): row for row in v2.get('candidate_renders', [])}
    if set(candidate_rows) != {'parent_v5', 'current_final_v2'}: raise SystemExit('v2 lacks both candidate render groups')
    candidate_sources = {}
    for cli_label in ('parent_v5', 'current_final_v2'):
        class_rows = {row.get('class'): row for row in candidate_rows[cli_label].get('classes', [])}
        if not {'AnonymousSuperArgs', 'Base'}.issubset(class_rows): raise SystemExit(f'{cli_label} lacks root/Base renders')
        source_paths, source_pins = [], []
        for class_name in ('AnonymousSuperArgs', 'Base'):
            parsed = class_rows[class_name].get('formats', {}).get('json', {}).get('parsed')
            if not isinstance(parsed, dict): raise SystemExit(f'{cli_label}/{class_name} has no successful JSON report')
            source_pin, report_pin = parsed.get('source'), parsed.get('report')
            if not isinstance(source_pin, dict) or not isinstance(report_pin, dict): raise SystemExit(f'{cli_label}/{class_name} lacks report/source pins')
            source_path, report_path = Path(source_pin['path']).resolve(strict=True), Path(report_pin['path']).resolve(strict=True)
            if pin(source_path) != source_pin: raise SystemExit(f'{cli_label}/{class_name} generated-source pin changed')
            if pin(report_path) != report_pin: raise SystemExit(f'{cli_label}/{class_name} raw JSON report pin changed')
            report = json.loads(report_path.read_text(encoding='utf-8'))
            report_text = report.get('text')
            source_bytes = source_path.read_bytes()
            if not isinstance(report_text, str) or source_bytes != report_text.encode('utf-8'):
                raise SystemExit(f'{cli_label}/{class_name} source is not byte-for-byte the report text')
            source_paths.append(source_path); source_pins.append(source_pin)
        candidate_sources[cli_label] = {'paths':source_paths,'pins':source_pins}
    main_text = candidate_sources['parent_v5']['paths'][0].read_bytes().decode('utf-8')
    match = re.search(r'(?m)^\s*package\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*;', main_text)
    main_class = (match.group(1) + '.' if match else '') + 'AnonymousSuperArgs'
    legs = v2['jdk_legs']
    if set(legs) != {'javac8', 'javac23'}: raise SystemExit('v2 lacks the two pinned JDK legs')
    for leg in legs.values():
        for tool in ('javac', 'java'):
            p = Path(leg['tools'][tool]).resolve(strict=True)
            expected = leg['pins'][tool]
            actual=pin(p)
            if any(actual[k] != expected[k] for k in ('bytes','sha256')): raise SystemExit(f'pinned JDK tool changed: {p}')

    out.mkdir(parents=True)
    raw = out / 'raw'; raw.mkdir()
    guard = load(GUARD, 'projected_root_guard')
    scanner = load(SCANNER, 'projected_root_scanner')
    guard.ROOT = ROOT; guard.OUT = raw; guard.ENV_VALUES = {}
    guard.expected_test_summaries = lambda _index, _stream: None
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.command_stream = lambda path: {'path': str(Path(path).resolve()), 'bytes': Path(path).stat().st_size, 'sha256': sha(Path(path).read_bytes())}
    doc = {'schema':'anonymous-super-args-projected-root-replay-v1','status':'running',
           'scope':'compile and execute each CLI candidate rendered AnonymousSuperArgs + Base source exactly as pinned in v2 JSON reports; no original fixture sources are used and no source is patched',
           'candidate_render_sources':{k:v['pins'] for k,v in candidate_sources.items()},
           'source_pins_before':{k:[pin(p) for p in v['paths']] for k,v in candidate_sources.items()}, 'source_pins_after':None,
           'jdk_legs':legs, 'guard':{'path':str(GUARD),'sha256':pin(GUARD)['sha256'],'scanner_path':str(SCANNER),'scanner_sha256':pin(SCANNER)['sha256'], 'minimum_free_bytes':FREE_LIMIT,'maximum_target_bytes':TARGET_LIMIT},
           'main_class':main_class,'expected_original_stdout':EXPECTED,'lanes':[],'commands':[]}
    dump(out/'execution.json',doc)
    counter=0
    for cli_label in ('parent_v5','current_final_v2'):
        sources=candidate_sources[cli_label]['paths']; source_pins=candidate_sources[cli_label]['pins']
        for leg_name in ('javac8','javac23'):
            leg=legs[leg_name]; home=Path(leg['home'])
            classes=out/'classes'/cli_label/leg_name; classes.mkdir(parents=True)
            empty=classes/'empty-classpath'; empty.mkdir()
            release=['-source','8','-target','8','-Xlint:-options'] if leg_name=='javac8' else ['--release','8']
            env={k:v for k,v in os.environ.items() if k not in STRIP_ENV}
            env['JAVA_HOME']=str(home); env['PATH']=str(home/'bin')+os.pathsep+env.get('PATH','')
            lane={'candidate_context':cli_label,'jdk':leg_name,'sources':source_pins,'source_policy':'candidate Jarde report source, byte-for-byte unchanged','compile':None,'run':None,'runtime_state':'not-run'}
            def invoke(label, argv):
                nonlocal counter
                counter+=1
                row={'index':counter,'label':label,'argv':[str(x) for x in argv],'cwd':str(ROOT),'java_home':str(home),'state':'started','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
                doc['commands'].append(row); dump(out/'execution.json',doc)
                result=guard.run_command(counter,row['argv'],env); row.update(result)
                row['label']=label; row['state']='guard-stopped' if row.get('guard_stop') else 'observed'
                for stream in row.get('streams',{}).values():
                    rp=Path(stream['path']); b=rp.read_bytes(); stream.update(bytes=len(b),sha256=sha(b))
                dump(out/'execution.json',doc)
                return row, Path(row['streams']['stdout']['path']).read_bytes(), Path(row['streams']['stderr']['path']).read_bytes()
            comp,_,_=invoke(f'{cli_label}-{leg_name}-projected-root-compile',[leg['tools']['javac'],*release,'-proc:none','-g:none','-classpath',empty,'-sourcepath',empty,'-d',classes,*sources])
            lane['compile']=comp
            if comp.get('exit_code') == 0 and not comp.get('guard_stop'):
                run,stdout,stderr=invoke(f'{cli_label}-{leg_name}-projected-root-run',[leg['tools']['java'],'-Xverify:all','-cp',classes,main_class])
                lane['run']=run; lane['runtime_state']='ran' if run.get('exit_code') == 0 and not run.get('guard_stop') else 'runtime-failed'
                lane['stdout']=stdout.decode('utf-8','replace'); lane['stdout_sha256']=sha(stdout); lane['stderr_sha256']=sha(stderr); lane['oracle_match']=stdout.decode('utf-8','replace')==EXPECTED and run.get('exit_code')==0
            else:
                lane['runtime_state']='compile-failed-no-runtime'
            doc['lanes'].append(lane); dump(out/'execution.json',doc)
            if comp.get('guard_stop') or (lane.get('run') and lane['run'].get('guard_stop')):
                raise RuntimeError(f'resource guard stopped {cli_label}/{leg_name}')
    doc['source_pins_after']={k:[pin(p) for p in v['paths']] for k,v in candidate_sources.items()}
    if doc['source_pins_before'] != doc['source_pins_after']: raise RuntimeError('source manifest changed during projected replay')
    doc['status']='observed'; dump(out/'execution.json',doc)
    print(json.dumps({'status':doc['status'],'lanes':[{k:r.get(k) for k in ('candidate_context','jdk','runtime_state','oracle_match')} for r in doc['lanes']],'receipt':str(out/'execution.json')},indent=2))
    return 0

if __name__ == '__main__': raise SystemExit(main())
