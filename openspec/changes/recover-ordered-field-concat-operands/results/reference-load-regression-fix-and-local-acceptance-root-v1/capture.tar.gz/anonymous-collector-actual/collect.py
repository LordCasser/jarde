#!/usr/bin/env python3
"""Collect a guarded, side-by-side replay of the frozen anonymous-class sample."""
from __future__ import annotations

import datetime
import difflib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import zipfile

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
HERE = Path(__file__).resolve().parent
FIX = ROOT / 'tests/fixtures/proved-java-structure/anonymous-super-args'
EVIDENCE = ROOT / 'openspec/evidence/java-syntax-2026-09-27/anonymous-super-args'
JDK_MANIFEST = ROOT / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
GUARD_PATH = ROOT / 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER_PATH = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
FOCUS_MODULE = Path('/private/tmp/jarde-cf11-structured-list-focused-runner-prep-luna-v7/run.py')
FOCUS_MODULE_SHA = 'c8b1016eaf9506912876fd92e8544d5f78e472401beb99e3fd75b549607956bc'
CLOSURE_MODULE = Path('/private/tmp/jarde-iterator-assignment-full-validation-prep-luna-v2/workspace_runner.py')
CLOSURE_MODULE_SHA = '63e52b55fe5d20d5f2ece98ac80676ccdb2de8dfd33d7199b688e075fb1e9673'
OLD_CLI = Path('/private/tmp/jarde-loop-combined-focused-root-v5/candidate-cli')
OLD_RECEIPT = Path('/private/tmp/jarde-loop-combined-focused-root-v5/execution.json')
CURRENT_CLI = Path('/private/tmp/jarde-ordered-field-final-check-root-v9/candidate-cli')
CURRENT_RECEIPT = Path('/private/tmp/jarde-ordered-field-final-check-root-v9/execution.json')
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3
STRIP_ENV = ('JAVA_HOME', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH')
CLASSES = ('AnonymousSuperArgs', 'AnonymousSuperArgs$1', 'Base')
EXPECTED_STDOUT = b'arg:capture|arg:super-label|arg:super-value|base:explicit:17\nexplicit:17:captured\n'
SUMMARY_RE = re.compile(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;')
PACKAGE_RE = re.compile(r'(?m)^\s*package\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*;')
CLASS_RE = re.compile(r'(?m)^\s*(?:(?:public|protected|private|abstract|final|strictfp|static)\s+)*class\s+([A-Za-z_$][\w$]*)\b')
SCHEMA = 'anonymous-super-args-candidate-comparison-v1'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(path: Path) -> dict:
    path = Path(path).resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def dump(path: Path, value) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot import pinned module: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_pin(record: dict, label: str) -> Path:
    if not isinstance(record, dict) or not all(k in record for k in ('path', 'bytes', 'sha256')):
        raise RuntimeError(f'incomplete {label} pin')
    path = Path(record['path'])
    actual = pin(path)
    if any(actual[k] != record[k] for k in ('path', 'bytes', 'sha256')):
        raise RuntimeError(f'{label} pin differs: {path}')
    return path


def receipt_cli(cli: Path, receipt: Path, *, require_live_closure: bool) -> dict:
    if not cli.is_file() or cli.is_symlink() or not os.access(cli, os.X_OK):
        raise RuntimeError(f'CLI is absent, linked, or non-executable: {cli}')
    if cli.stat().st_mode & 0o777 != 0o555:
        raise RuntimeError(f'CLI is not frozen mode 0555: {cli}')
    doc = json.loads(receipt.read_text(encoding='utf-8'))
    if doc.get('status') != 'commands_passed_pending_independent_acceptance':
        raise RuntimeError(f'focused receipt is not a completed root-runner receipt: {receipt}')
    recorded = doc.get('cli')
    actual = pin(cli)
    if not isinstance(recorded, dict) or any(recorded.get(k) != actual[k] for k in ('path', 'bytes', 'sha256')):
        raise RuntimeError(f'focused CLI pin does not match {receipt}')
    if doc.get('default_stack') is not True or doc.get('target_absent') is not True:
        raise RuntimeError(f'focused receipt lacks default-stack/clean postcondition: {receipt}')
    before, after = doc.get('source_manifest_before'), doc.get('source_manifest_after')
    if not isinstance(before, list) or not isinstance(after, list) or not before or not after:
        raise RuntimeError(f'focused receipt lacks complete source manifests: {receipt}')
    if {x.get('path') for x in before} != {x.get('path') for x in after}:
        raise RuntimeError(f'focused source manifest membership changed: {receipt}')
    for label, record in (('focused runner', doc.get('runner')), ('command spec', doc.get('command_spec'))):
        verify_pin(record, label)
    spec = doc['command_spec']
    expected = json.loads(Path(spec['path']).read_text(encoding='utf-8'))
    normal = [row for row in doc.get('commands', []) if not row.get('cleanup_only')]
    if [row.get('argv') for row in normal] != expected:
        raise RuntimeError(f'focused receipt command argv differs from its command_spec: {receipt}')
    clean = [row for row in doc.get('commands', []) if row.get('cleanup_only')]
    if len(clean) != 1 or clean[0].get('argv') != ['cargo', 'clean'] or clean[0].get('exit_code') != 0:
        raise RuntimeError(f'focused receipt lacks exact successful cargo clean: {receipt}')
    for row in doc['commands']:
        if row.get('exit_code') != 0 or row.get('guard_stop') is not None:
            raise RuntimeError(f"focused command failed or hit guard: {row.get('argv')}")
        for ref in row.get('streams', {}).values():
            verify_pin(ref, 'focused command stream')
    builds = [row for row in normal if row.get('argv') == ['cargo', 'build', '-p', 'jarde-cli', '--locked']]
    if len(builds) != 1:
        raise RuntimeError(f'focused receipt has no unique successful CLI build: {receipt}')
    if require_live_closure:
        for path, expected_pin in ((FOCUS_MODULE, FOCUS_MODULE_SHA), (CLOSURE_MODULE, CLOSURE_MODULE_SHA)):
            if sha(path.read_bytes()) != expected_pin:
                raise RuntimeError(f'focused source-closure helper changed: {path}')
        focus = load_module(FOCUS_MODULE, 'anon_focus_manifest')
        closure = load_module(CLOSURE_MODULE, 'anon_workspace_closure')
        focus.ROOT = ROOT
        focus.CLOSURE_MODULE = closure
        closure.ROOT = ROOT
        if focus.source_manifest() != after:
            raise RuntimeError('current source closure differs from the current focused receipt')
    return {'receipt': pin(receipt), 'cli': actual, 'runner': doc['runner'], 'command_spec': doc['command_spec'],
            'manifest_count': len(after), 'build_command': builds[0], 'target_absent': doc['target_absent']}


def main() -> int:
    if len(sys.argv) != 6:
        raise SystemExit('usage: collect.py OLD_CLI OLD_RECEIPT CURRENT_CLI CURRENT_RECEIPT FRESH_OUTPUT')
    old_cli, old_receipt, current_cli, current_receipt, out = [Path(x).resolve() for x in sys.argv[1:]]
    if old_cli != OLD_CLI.resolve() or old_receipt != OLD_RECEIPT.resolve():
        raise SystemExit('old comparison side must use the pinned parent root-v5 CLI and receipt')
    if current_cli != CURRENT_CLI.resolve() or current_receipt != CURRENT_RECEIPT.resolve():
        raise SystemExit('current comparison side must use the pinned final-check v9 CLI and receipt')
    if out.exists():
        raise SystemExit(f'refusing to overwrite non-fresh output: {out}')
    old_evidence = receipt_cli(old_cli, old_receipt, require_live_closure=False)
    current_evidence = receipt_cli(current_cli, current_receipt, require_live_closure=True)
    for path, expected in ((GUARD_PATH, '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'),
                           (SCANNER_PATH, 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7')):
        if sha(path.read_bytes()) != expected:
            raise RuntimeError(f'pinned root guard/scanner changed: {path}')
    if not JADX.is_file() or not JADX_JAR.is_file():
        raise RuntimeError('pinned JADX binary or jar missing')
    jdk_manifest_pin = pin(JDK_MANIFEST)
    manifest = json.loads(JDK_MANIFEST.read_text(encoding='utf-8'))
    legs = {}
    for row in manifest.get('legs', []):
        name = row.get('leg')
        if name not in ('javac8', 'javac23'):
            continue
        tools = row['jdk_tools']
        entries = {}
        for tool in ('javac', 'java', 'javap'):
            entry = tools[tool]
            path = Path(entry['path']).resolve(strict=True)
            actual = pin(path)
            if actual['bytes'] != entry['bytes'] or actual['sha256'] != entry['sha256']:
                raise RuntimeError(f'fixed JDK tool pin differs: {name}/{tool}')
            entries[tool] = path
        legs[name] = {'tools': entries, 'home': entries['java'].parent.parent, 'pins': tools}
    if set(legs) != {'javac8', 'javac23'}:
        raise RuntimeError('fixed javac8/javac23 paths are missing from the manifest')

    frozen = sorted(FIX.glob('*.class'))
    expected_hashes = {}
    for line in (EVIDENCE / 'class-sha256.txt').read_text(encoding='utf-8').splitlines():
        digest, name = line.split(None, 1)
        expected_hashes[name.strip()] = digest
    if sorted(p.name.removesuffix('.class') for p in frozen) != sorted(CLASSES):
        raise RuntimeError('frozen fixture class membership differs')
    class_pins = [pin(path) for path in frozen]
    for item in class_pins:
        if expected_hashes.get(Path(item['path']).name) != item['sha256']:
            raise RuntimeError(f'frozen class differs from reviewed replay pin: {item["path"]}')
    sources = sorted(FIX.glob('*.java'))
    if [p.name for p in sources] != ['AnonymousSuperArgs.java', 'Base.java']:
        raise RuntimeError('source fixture membership differs from the two reviewed Java files')
    replay_path = EVIDENCE / 'replay.py'
    replay_text = replay_path.read_text(encoding='utf-8')
    expected_match = re.search(r'^EXPECTED\s*=\s*(["\'].*?["\'])\s*$', replay_text, re.M)
    if not expected_match:
        raise RuntimeError('cannot recover the reviewed source-oracle string from replay.py')
    import ast
    oracle_text = ast.literal_eval(expected_match.group(1))
    if oracle_text.encode('utf-8') != EXPECTED_STDOUT:
        raise RuntimeError('replay.py oracle no longer matches the known reviewed output')

    guard = load_module(GUARD_PATH, 'anonymous_candidate_guard')
    scanner = load_module(SCANNER_PATH, 'anonymous_candidate_scanner')
    out.mkdir(parents=True)
    raw_dir = out / 'raw'
    raw_dir.mkdir()
    guard.ROOT = ROOT
    guard.OUT = raw_dir
    guard.ENV_VALUES = {}
    guard.expected_test_summaries = lambda _index, _stream: None
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.command_stream = lambda path: {
        'path': str(Path(path).resolve()), 'bytes': Path(path).stat().st_size,
        'sha256': sha(Path(path).read_bytes())
    }
    doc = {
        'schema': SCHEMA, 'status': 'running',
        'candidate_clis': {'parent_v5': old_evidence, 'current_final_v2': current_evidence},
        'fixture_root': str(FIX), 'replay_oracle': {'path': str(replay_path), 'pin': pin(replay_path), 'stdout': oracle_text},
        'frozen_classes': class_pins, 'source_files': [pin(p) for p in sources],
        'zip': None, 'jdk_manifest': jdk_manifest_pin, 'jdk_legs': {name: {'tools': {tool: str(path) for tool, path in leg['tools'].items()}, 'home': str(leg['home']), 'pins': leg['pins']} for name, leg in legs.items()},
        'tools': {'jadx': pin(JADX), 'jadx_jar': pin(JADX_JAR),
                  'guard': pin(GUARD_PATH), 'scanner': pin(SCANNER_PATH)},
        'resource_guard': {'minimum_free_bytes': FREE_LIMIT, 'maximum_target_bytes': TARGET_LIMIT,
                           'sample_interval_seconds': 1, 'process_group_termination': True},
        'commands': [], 'original_class_runs': [], 'original_source_lanes': [],
        'jadx': {}, 'candidate_renders': [], 'candidate_whole_class_lanes': [],
        'source_pins_before': None, 'source_pins_after': None
    }

    tracked = [Path(__file__).resolve(), HERE / 'check.py', HERE / 'pins.json', HERE / 'README.md',
               old_cli, old_receipt, current_cli, current_receipt,
               JDK_MANIFEST, JADX, JADX_JAR, GUARD_PATH, SCANNER_PATH, FOCUS_MODULE, CLOSURE_MODULE,
               replay_path, EVIDENCE / 'class-sha256.txt', EVIDENCE / 'report.md', *frozen, *sources,
               *(path for leg in legs.values() for path in leg['tools'].values()),
               Path(old_evidence['command_spec']['path']), Path(current_evidence['command_spec']['path']),
               Path(old_evidence['runner']['path']), Path(current_evidence['runner']['path'])]
    pins_before = [pin(path) for path in tracked]
    doc['source_pins_before'] = pins_before
    dump(out / 'execution.json', doc)

    command_counter = 0
    def run(label: str, argv: list, home: Path) -> tuple[dict, bytes, bytes]:
        nonlocal command_counter
        command_counter += 1
        env = {k: v for k, v in os.environ.items() if k not in STRIP_ENV}
        env['JAVA_HOME'] = str(home)
        env['PATH'] = str(home / 'bin') + os.pathsep + env.get('PATH', '')
        row = {'index': command_counter, 'label': label, 'argv': [str(x) for x in argv],
               'cwd': str(ROOT), 'java_home': str(home), 'state': 'started',
               'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        doc['commands'].append(row)
        dump(out / 'execution.json', doc)
        result = guard.run_command(command_counter, row['argv'], env)
        row.update(result)
        row['label'] = label
        row['state'] = 'guard-stopped' if row.get('guard_stop') else 'observed'
        for stream in row.get('streams', {}).values():
            raw_path = Path(stream['path'])
            raw = raw_path.read_bytes()
            stream.update(bytes=len(raw), sha256=sha(raw))
        dump(out / 'execution.json', doc)
        if row.get('guard_stop'):
            raise RuntimeError(f'resource guard stopped {label}: {row["guard_stop"]}')
        return row, Path(row['streams']['stdout']['path']).read_bytes(), Path(row['streams']['stderr']['path']).read_bytes()

    def compile_run(label: str, source_files: list[Path], leg_name: str, output: Path, main_class: str) -> dict:
        output.mkdir(parents=True)
        empty = output / 'empty-classpath'
        empty.mkdir()
        leg = legs[leg_name]
        if leg_name == 'javac8':
            release_flags = ['-source', '8', '-target', '8', '-Xlint:-options']
        else:
            release_flags = ['--release', '8']
        argv = [leg['tools']['javac'], *release_flags, '-proc:none', '-g:none',
                '-classpath', empty, '-sourcepath', empty, '-d', output, *source_files]
        comp, _stdout, _stderr = run(label + '-compile', argv, leg['home'])
        run_row = None
        stdout, stderr = b'', b''
        if comp.get('exit_code') == 0 and not comp.get('guard_stop'):
            run_row, stdout, stderr = run(label + '-run',
                [leg['tools']['java'], '-Xverify:all', '-cp', output, main_class], leg['home'])
        classes = sorted(output.rglob('*.class'))
        return {'compile': comp, 'run': run_row,
                'runtime_state': 'ran' if run_row is not None else 'no-runtime-after-compile',
                'main_class': main_class, 'sources': [pin(p) for p in source_files],
                'classes': [pin(p) for p in classes], 'stdout': stdout.decode('utf-8', 'replace'),
                'stdout_sha256': sha(stdout), 'stderr': stderr.decode('utf-8', 'replace'),
                'stderr_sha256': sha(stderr), 'oracle_match': run_row is not None and stdout == EXPECTED_STDOUT}

    try:
        # Make one deterministic zip containing only the three frozen classes.
        archive = out / 'anonymous-super-args.zip'
        with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            for path in frozen:
                info = zipfile.ZipInfo(path.name, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                zf.writestr(info, path.read_bytes())
        with zipfile.ZipFile(archive) as zf:
            members = sorted(zf.namelist())
            if members != sorted(path.name for path in frozen):
                raise RuntimeError('class zip contains unexpected members')
        tracked.append(archive)
        pins_before.append(pin(archive))
        doc['zip'] = {'pin': pin(archive), 'members': members,
                      'class_pins': class_pins, 'created_by': 'Python zipfile from frozen class bytes'}
        dump(out / 'execution.json', doc)

        # Validate both the frozen class and the original Java sources on each JDK.
        for leg_name in ('javac8', 'javac23'):
            leg = legs[leg_name]
            label = f'original-class-{leg_name}'
            row, stdout, stderr = run(label, [leg['tools']['java'], '-Xverify:all', '-cp', FIX, 'AnonymousSuperArgs'], leg['home'])
            doc['original_class_runs'].append({'jdk': leg_name, 'command': row,
                'stdout': stdout.decode('utf-8', 'replace'), 'stdout_sha256': sha(stdout),
                'stderr_sha256': sha(stderr), 'oracle_match': stdout == EXPECTED_STDOUT})
            lane = compile_run(f'original-source-{leg_name}', sources, leg_name,
                               out / 'original-source' / leg_name / 'classes', 'AnonymousSuperArgs')
            lane['jdk'] = leg_name
            doc['original_source_lanes'].append(lane)
            dump(out / 'execution.json', doc)
        for leg_name in ('javac8', 'javac23'):
            leg = legs[leg_name]
            cmd, stdout, stderr = run(f'javap-{leg_name}',
                [leg['tools']['javap'], '-classpath', FIX, '-p', '-c', '-s', 'AnonymousSuperArgs', 'Base', 'AnonymousSuperArgs$1'],
                leg['home'])
            p = out / 'javap' / f'{leg_name}.txt'
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(stdout)
            doc.setdefault('javap', []).append({'jdk': leg_name, 'command': cmd, 'stdout': pin(p), 'stderr_sha256': sha(stderr)})
            dump(out / 'execution.json', doc)

        # Run fixed JADX against the same exact frozen-class archive, then compile every emitted Java file.
        jadx_dir = out / 'jadx-source'
        jadx_row, jadx_stdout, jadx_stderr = run('jadx-decompile', [JADX, '-d', jadx_dir, archive], legs['javac23']['home'])
        jadx_files = sorted(jadx_dir.rglob('*.java'))
        doc['jadx'] = {'command': jadx_row, 'stdout_sha256': sha(jadx_stdout), 'stderr_sha256': sha(jadx_stderr),
                       'sources': [pin(p) for p in jadx_files], 'source_count': len(jadx_files), 'lanes': []}
        for leg_name in ('javac8', 'javac23'):
            main_source = next((p for p in jadx_files if CLASS_RE.search(p.read_text(encoding='utf-8', errors='replace'))
                                and CLASS_RE.search(p.read_text(encoding='utf-8', errors='replace')).group(1) == 'AnonymousSuperArgs'), None)
            if main_source is None or not jadx_files:
                lane = {'jdk': leg_name, 'compile': None, 'run': None, 'runtime_state': 'no-runtime: no complete JADX source set',
                        'sources': [pin(p) for p in jadx_files], 'oracle_match': False}
            else:
                match = PACKAGE_RE.search(main_source.read_text(encoding='utf-8'))
                package = match.group(1) if match else ''
                main_class = (package + '.' if package else '') + 'AnonymousSuperArgs'
                lane = compile_run(f'jadx-{leg_name}', jadx_files, leg_name,
                                   out / 'jadx-classes' / leg_name, main_class)
            lane['jdk'] = leg_name
            doc['jadx']['lanes'].append(lane)
            dump(out / 'execution.json', doc)

        # Render each physical class as JSON and text from both CLI builds, then compile all three JSON texts together.
        cli_rows = [('parent_v5', old_cli, old_evidence), ('current_final_v2', current_cli, current_evidence)]
        for cli_label, cli, cli_evidence in cli_rows:
            render_rows = []
            for class_name in CLASSES:
                formats = {}
                for fmt in ('json', 'text'):
                    base = out / 'jarde' / cli_label / class_name.replace('$', '_dollar_') / fmt
                    base.mkdir(parents=True)
                    argv = [cli, 'class-source', '--input', archive, '--class', class_name,
                            '--policy', 'plain-jar', '--release', '8', '--format', fmt, '--evidence', 'all']
                    command_row, stdout, stderr = run(f'{cli_label}-{class_name}-{fmt}', argv, legs['javac23']['home'])
                    raw_path = base / ('response.raw.json' if fmt == 'json' else 'response.raw.txt')
                    raw_path.write_bytes(stdout)
                    form = {'command': command_row, 'raw_stdout': pin(raw_path), 'stderr_sha256': sha(stderr),
                            'exit_code': command_row.get('exit_code'), 'parsed': None}
                    if fmt == 'json' and command_row.get('exit_code') == 0:
                        try:
                            response = json.loads(stdout.decode('utf-8'))
                            response_path = base / 'report.json'
                            response_path.write_bytes(stdout)
                            source_text = response.get('text')
                            if isinstance(source_text, str):
                                source_path = base / f'{class_name}.java'
                                source_path.write_text(source_text, encoding='utf-8')
                                methods = []
                                for method in response.get('methods', []):
                                    item = method.get('item', {})
                                    outcome = method.get('outcome', {})
                                    report = outcome.get('report', {})
                                    identity = item.get('identity', {})
                                    name = item.get('name', {})
                                    descriptor = item.get('descriptor', {})
                                    methods.append({'declaration': method.get('declaration'),
                                        'identity': identity, 'name': name, 'descriptor': descriptor,
                                        'method_text': method.get('text'), 'outcome_kind': outcome.get('kind'),
                                        'report_text': report.get('text'), 'compile_status': report.get('compile_status'),
                                        'syntax_status': report.get('syntax_status'),
                                        'concat_facts': report.get('concats'), 'report_diagnostics': report.get('diagnostics', [])})
                                method_path = base / 'method-facts.json'
                                dump(method_path, methods)
                                form['parsed'] = {'report': pin(response_path), 'source': pin(source_path),
                                    'class': response.get('class'), 'outcome': response.get('outcome'),
                                    'execution': response.get('execution'), 'source_text_sha256': sha(source_text.encode()),
                                    'methods': methods, 'method_facts': pin(method_path)}
                        except (UnicodeError, json.JSONDecodeError) as exc:
                            form['parse_error'] = f'{type(exc).__name__}: {exc}'
                    formats[fmt] = form
                    dump(out / 'execution.json', doc)
                json_text_pin = (formats['json'].get('parsed') or {}).get('source')
                text_bytes = Path(formats['text']['raw_stdout']['path']).read_bytes()
                json_text = Path(json_text_pin['path']).read_bytes() if json_text_pin else None
                formats['text_vs_json'] = {'comparable': json_text is not None,
                    'byte_identical': json_text is not None and json_text == text_bytes,
                    'json_text_sha256': sha(json_text) if json_text is not None else None,
                    'text_stdout_sha256': sha(text_bytes)}
                render_rows.append({'class': class_name, 'formats': formats})
                dump(out / 'execution.json', doc)
            json_sources = []
            for render in render_rows:
                parsed = render['formats']['json'].get('parsed')
                if parsed and parsed.get('source'):
                    json_sources.append(Path(parsed['source']['path']))
            for leg_name in ('javac8', 'javac23'):
                if len(json_sources) != len(CLASSES):
                    lane = {'jdk': leg_name, 'compile': None, 'run': None,
                            'runtime_state': f'no-runtime: expected 3 complete class texts, observed {len(json_sources)}',
                            'sources': [pin(p) for p in json_sources], 'oracle_match': False}
                else:
                    main_text = next((p.read_text(encoding='utf-8') for p in json_sources
                                      if CLASS_RE.search(p.read_text(encoding='utf-8'))
                                      and CLASS_RE.search(p.read_text(encoding='utf-8')).group(1) == 'AnonymousSuperArgs'), '')
                    match = PACKAGE_RE.search(main_text)
                    package = match.group(1) if match else ''
                    main_class = (package + '.' if package else '') + 'AnonymousSuperArgs'
                    lane = compile_run(f'jarde-{cli_label}-{leg_name}', json_sources, leg_name,
                                       out / 'jarde-classes' / cli_label / leg_name, main_class)
                lane.update({'cli': cli_label, 'jdk': leg_name})
                doc['candidate_whole_class_lanes'].append(lane)
                dump(out / 'execution.json', doc)
            doc['candidate_renders'].append({'cli': cli_label, 'cli_pin': cli_evidence['cli'], 'classes': render_rows})
            dump(out / 'execution.json', doc)

        # Compare root/anonymous-child method text and concat report facts without pre-judging outcomes.
        by_cli = {item['cli']: {entry['class']: entry for entry in item['classes']} for item in doc['candidate_renders']}
        whole_class_comparison = []
        for class_name in CLASSES:
            old_parsed = by_cli['parent_v5'][class_name]['formats']['json'].get('parsed') or {}
            new_parsed = by_cli['current_final_v2'][class_name]['formats']['json'].get('parsed') or {}
            old_source_pin = old_parsed.get('source')
            new_source_pin = new_parsed.get('source')
            old_text = Path(old_source_pin['path']).read_text(encoding='utf-8') if old_source_pin else None
            new_text = Path(new_source_pin['path']).read_text(encoding='utf-8') if new_source_pin else None
            whole_class_comparison.append({'class': class_name,
                'old_available': isinstance(old_text, str), 'current_available': isinstance(new_text, str),
                'byte_identical': isinstance(old_text, str) and isinstance(new_text, str) and old_text == new_text,
                'parent_v5_sha256': sha(old_text.encode('utf-8')) if isinstance(old_text, str) else None,
                'current_final_v2_sha256': sha(new_text.encode('utf-8')) if isinstance(new_text, str) else None,
                'unified_diff': list(difflib.unified_diff(
                    old_text.splitlines(keepends=True) if isinstance(old_text, str) else [],
                    new_text.splitlines(keepends=True) if isinstance(new_text, str) else [],
                    fromfile=f'parent_v5/{class_name}.java', tofile=f'current_final_v2/{class_name}.java'))})
        doc['whole_class_text_comparison'] = whole_class_comparison
        changes = []
        for class_name in ('AnonymousSuperArgs', 'AnonymousSuperArgs$1'):
            old_row = by_cli['parent_v5'][class_name]['formats']['json'].get('parsed') or {}
            new_row = by_cli['current_final_v2'][class_name]['formats']['json'].get('parsed') or {}
            old_methods = old_row.get('methods', [])
            new_methods = new_row.get('methods', [])
            def key(method):
                identity = method.get('identity')
                if not isinstance(identity, dict) or set(identity) != {'owner', 'name', 'descriptor'}:
                    raise RuntimeError('unexpected physical method identity JSON shape')
                if not isinstance(identity['owner'], dict) or not isinstance(identity['name'], list) or not isinstance(identity['descriptor'], list):
                    raise RuntimeError('physical method identity fields have unexpected JSON types')
                return json.dumps(identity, sort_keys=True, separators=(',', ':'))
            old_map = {key(m): m for m in old_methods}
            new_map = {key(m): m for m in new_methods}
            for ident in sorted(set(old_map) | set(new_map)):
                before, after = old_map.get(ident), new_map.get(ident)
                changes.append({'class': class_name, 'method_identity': json.loads(ident),
                    'old_present': before is not None, 'current_present': after is not None,
                    'method_text_equal': before is not None and after is not None and before.get('method_text') == after.get('method_text'),
                    'report_text_equal': before is not None and after is not None and before.get('report_text') == after.get('report_text'),
                    'concat_facts_equal': before is not None and after is not None and before.get('concat_facts') == after.get('concat_facts'),
                    'parent_v5': before, 'current_final_v2': after})
        doc['root_child_method_comparison'] = changes
        classifications = {}
        for lane in doc['candidate_whole_class_lanes']:
            cli_label, leg_name = lane['cli'], lane['jdk']
            if lane.get('runtime_state') != 'ran':
                verdict = 'no-runtime-observation'
            elif lane.get('oracle_match'):
                verdict = 'runtime-matches-reviewed-oracle'
            else:
                verdict = 'runtime-differs-from-reviewed-oracle'
            classifications[f'{cli_label}/{leg_name}'] = verdict
        doc['runtime_observations'] = classifications
        doc['source_pins_after'] = [pin(path) for path in tracked]
        doc['source_inputs_unchanged'] = pins_before == doc['source_pins_after']
        doc['actual_command_count'] = len(doc['commands'])
        doc['status'] = 'observed' if doc['source_inputs_unchanged'] else 'failed'
        if not doc['source_inputs_unchanged']:
            doc['failure'] = {'type': 'InputChanged', 'message': 'one or more pinned tools, receipts, source files, or baselines changed during collection'}
        dump(out / 'execution.json', doc)
        return 0 if doc['status'] == 'observed' else 1
    except BaseException as exc:
        doc['status'] = 'failed'
        doc['failure'] = {'type': type(exc).__name__, 'message': str(exc),
                          'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        dump(out / 'execution.json', doc)
        raise


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except BaseException as error:
        print(f'collector failed: {type(error).__name__}: {error}', file=sys.stderr)
        raise SystemExit(1)
