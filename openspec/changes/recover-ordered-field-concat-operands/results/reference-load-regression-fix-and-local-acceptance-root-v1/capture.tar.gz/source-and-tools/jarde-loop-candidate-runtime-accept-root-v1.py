import json,hashlib,sys
from pathlib import Path
p=Path(sys.argv[1]);d=json.loads(p.read_text());h=lambda b:hashlib.sha256(b).hexdigest()
assert d['status']=='observed' and d['source_tool_inputs_unchanged']
assert len(d['commands'])==d['actual_command_count']==40
assert len(d['candidate_lanes'])==d['actual_candidate_lane_count']==16
pins=[]
def verify(x):
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=x.keys():
   b=Path(x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'],x['path'];pins.append(x)
  for y in x.values():verify(y)
 elif isinstance(x,list):
  for y in x:verify(y)
verify(d)
for c in d['commands']:assert c['exit_code']==0 and c.get('guard_stop') is None
for lane in d['candidate_lanes']:
 assert lane['render_command']['exit_code']==0
 response=json.loads(Path(lane['raw_response']['path']).read_text())
 assert Path(lane['source']['path']).read_bytes()==response['text'].encode('utf-8')
 for method in response['methods']:
  assert method['text'] in response['text']
rows=d['whole_class_runs']+[r for r in d['candidate_lanes'] if r.get('compile_run')]
assert len(rows)==12
observed=[]
for r in rows:
 cr=r['compile_run'];assert cr['compile']['exit_code']==0 and cr['run']['exit_code']==0 and cr['runtime_state']=='ran'
 run_bytes=Path(cr['run']['streams']['stdout']['path']).read_bytes();comp=r['stdout_comparison'];assert comp['byte_identical'] and comp['original_sha256']==comp['candidate_sha256']==h(run_bytes)
 originals=[q for q in pins if q['sha256']==comp['original_sha256'] and q['path'].endswith('.stdout.raw') and not q['path'].startswith(str(p.parent))]
 assert originals and all(Path(q['path']).read_bytes()==run_bytes for q in originals)
 if 'retry-v2' in r.get('label',''):
  assert b'breaks=0' in run_bytes and b'uncaught-error:2' in run_bytes
 observed.append({'lane':r.get('label',r.get('sample','')+'-'+r.get('mode','')+'-'+r.get('jdk','')),'stdout_sha256':h(run_bytes),'lines':len(run_bytes.splitlines())})
s={'status':'accepted_unmodified_whole_class_runtime_matrix','commands':40,'renders':16,'compiled_runtime_lanes':12,'all_original_outputs_byte_identical':True,'runs':observed,'cli':d['candidate_cli'],'receipt':{'bytes':p.stat().st_size,'sha256':h(p.read_bytes())},'global_product_delivery_accepted':False}
(p.parent/'root-runtime-summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s))
