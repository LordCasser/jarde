from pathlib import Path
import json,hashlib,re,importlib.util,sys
p=Path(sys.argv[1]);d=json.loads(p.read_text())
def pin(p):
 b=Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert d['status']=='commands_passed_pending_independent_acceptance'
assert d['source_manifest_before']==d['source_manifest_after'] and d['target_absent'] and d['default_stack']
assert len(d['commands'])==8
assert [c['argv'] for c in d['commands'][:-1]]==json.loads(Path(d['command_spec']['path']).read_text())
for item in [d['runner'],d['command_spec'],d['cli']]:assert pin(item['path'])==item
observed=[]
for c in d['commands']:
 assert c['exit_code']==0 and c.get('guard_stop') is None
 for s in c['streams'].values():assert pin(s['path'])==s
 if c['argv'][:2]==['cargo','test']:
  raw=Path(c['streams']['stdout']['path']).read_text();raw=re.sub(r'\x1b\[[0-9;]*m','',raw)
  actual=[list(x) for x in re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)]
  assert actual==c['actual_test_summaries'] and actual and all(x[0]=='ok' and int(x[1])>0 and x[2]=='0' for x in actual)
  needed=['retry_proof_budget_used_minus_one_and_precancel_stop_inside_the_proof','retry_proof_rejects_mutated_physical_and_transfer_evidence','short_budget_and_precancel_stop_inside_field_certificate_before_owner_commit','a_physical_handler_row_split_across_the_field_chain_keeps_the_refusal','an_unclaimed_field_read_cannot_complete_the_concat_refusal','reference_load_rejects_caught_parameter_alias_from_real_handler_ssa','same_block_reference_load_is_presented_outside_try_for_fixed_dv_variants'] if '--lib' in c['argv'] else ['anonymous_super_args_render_traces_each_message_from_its_consumer','retry_v2_exc_same_payload_proves_field_append_tail_error_value_flow_on_all_lanes','a_field_backed_object_append_pins_the_conversion_and_keeps_origins','v3_instance_field_concats_are_recovered_in_all_four_compiler_lanes','ordered_field_candidate_rejects_static_receiver_call_and_duplicated_result','ordered_field_concat_pre_cancel_publishes_no_partial_owner','ordered_field_concat_short_ir_budget_stops_without_partial_owner','the_refused_slices_keep_the_instructions_their_closure_covers']
  for name in needed:assert re.search(r'test [^\n]*'+re.escape(name)+r' \.{3} ok',raw),name
  observed.append({'argv':c['argv'],'summaries':actual,'required_tests':needed})
assert d['commands'][-1]['argv']==['cargo','clean'] and len(observed)==2
root=Path('/Users/lordcasser/workspace/projects/jarde')
for f in d['source_manifest_after']:
 b=(root/f['path']).read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
def load_module(path,name):
 spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
focus=load_module('/private/tmp/jarde-cf11-structured-list-focused-runner-prep-luna-v7/run.py','root_focus_accept')
closure=load_module('/private/tmp/jarde-iterator-assignment-full-validation-prep-luna-v2/workspace_runner.py','root_closure_accept')
focus.ROOT=root;focus.CLOSURE_MODULE=closure;closure.ROOT=root
assert focus.source_manifest()==d['source_manifest_after']
assert not(root/'target').exists()
strict=d['commands'][-2];assert strict['argv']==['openspec','validate','--all','--strict','--no-interactive']
strict_raw=Path(strict['streams']['stdout']['path']).read_text()+Path(strict['streams']['stderr']['path']).read_text()
assert 'failed' in strict_raw.lower() and re.search(r'0 failed',strict_raw),strict_raw[-3000:]
summary={'status':'accepted_final_local_checks_new_product_pending_runtime','source_count':len(d['source_manifest_after']),'required_tests':observed,'cli':d['cli'],'full_class_runtime_accepted':False}
(p.parent/'root-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
