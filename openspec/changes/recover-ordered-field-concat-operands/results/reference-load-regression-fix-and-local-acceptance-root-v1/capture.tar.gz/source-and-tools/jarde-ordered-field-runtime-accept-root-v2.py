import json,hashlib,sys,importlib.util,re
from pathlib import Path
p=Path(sys.argv[1]);d=json.loads(p.read_text());h=lambda b:hashlib.sha256(b).hexdigest()
checker=Path('/private/tmp/jarde-ordered-field-concat-comparison-prep-luna-v5/check.py')
spec=importlib.util.spec_from_file_location('field_structural_accept',checker);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
errors,result=m.errors_for(d);assert not errors,errors
assert len(d['commands'])==24 and all(c['exit_code']==0 and c.get('guard_stop') is None for c in d['commands'])
accepted=[]
for r in d['candidate_lanes']+d['jadx_lanes']:
 cr=r['compile_run'];assert r['render_command']['exit_code']==0 and cr['compile']['exit_code']==0 and cr['run']['exit_code']==0 and cr['runtime_state']=='ran'
 baseline=Path(r['original_null_runner_stdout']['path']).read_bytes();actual=Path(cr['run']['streams']['stdout']['path']).read_bytes();assert baseline==actual and r['stdout_comparison']['byte_identical']
 assert len(actual.splitlines())==11 and actual.count(b'nullReceiver=NullPointerException events=')==1
 assert b'objectMutation=object=object;later=99 calls=1 events=object.toString' in actual
 assert b'nullObjectToString=object=null;later=99 calls=1 events=object.toString' in actual
 assert b'charArrayObject=true' in actual and b'objectFieldCharArray=true' in actual and b'fields=value=3;volatile=5' in actual
 original_runner=Path('/Users/lordcasser/workspace/projects/jarde/tests/fixtures/proved-ordered-field-concat/Runner.java').read_bytes()
 prefix=('package '+r['source_package']+';\n').encode() if r['source_package'] else b''
 assert Path(r['derived_runner']['path']).read_bytes()==prefix+original_runner
 if r['label'].startswith('candidate'):
  report=json.loads(Path(r['render_stdout']['path']).read_text());src=Path(r['generated_source']['path']);assert src.read_bytes()==report['text'].encode()
  assert str(src) in cr['compile']['argv']
 else:
  assert len(r['generated_sources'])==1 and r['generated_sources'][0]['path'] in cr['compile']['argv']
 accepted.append({'lane':r['label'],'stdout_sha256':h(actual),'lines':11})
s={'status':'accepted_unmodified_field_whole_class_runtime_and_source_maps','candidate_lanes':4,'jadx_lanes':4,'commands':24,'all_outputs_byte_identical':True,'runs':accepted,'structural_checks':result,'checker':{'path':str(checker),'bytes':checker.stat().st_size,'sha256':h(checker.read_bytes())},'receipt':{'bytes':p.stat().st_size,'sha256':h(p.read_bytes())},'cli':d['candidate_cli'],'global_product_delivery_accepted':False}
(p.parent/'root-runtime-summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s))
