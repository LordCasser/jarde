# Ordered-field workspace runner candidate: early product-failure preservation

Candidate only. This directory was prepared from `/private/tmp/jarde-ordered-field-full-workspace-prep-root-v4` by reading/copying the runner, acceptance script, and own-CI verifier. The shared repository and historical receipts/archives were not changed. No workspace command was executed and no Cargo/JDK/JADX/CLI/Git command was run. Python AST parsing was the only check performed on the candidate scripts.

## Exact change

The candidate redirects `OUT` to this new private prep directory so it cannot reuse root-v4 outputs. In the seed-batch loop, the runner already preserves the command row and raw stdout/stderr. It now persists `observed_summaries`, `actual_test_summaries`, all parsed `named_test_outcomes`, counts, and totals before checking whether the command exit was nonzero, a guard fired, any actual summary is `FAILED`/has failures, or any named outcome is `FAILED`. A product-failure record raises immediately before iterating newline-delimited Cargo compiler-artifact JSON. The raised error includes batch, seed, exit, guard, summary rows, failed named outcomes, and raw stream pins. Existing raw files remain available and finally-clean remains armed.

On the successful path, the original full compiler-artifact parser, executable path/symlink/type checks, exact metadata-planned target inventory, both seed loops, all focused and required outcome gates, source closure and limits remain in place. The acceptor compares the new actual summary rows to both raw stdout and the original observed-summary field. The acceptance script remains success-only and now binds to the candidate runner path; it reports the actual runner error when rejecting a failed receipt. It does not relax target/artifact/seed gates.

The ownCI verifier copy is derived from `/private/tmp/jarde-ordered-field-own-ci-prep-root-v3/verify-own-ci.py`; only `WORKSPACE_PREP`, runner SHA, and acceptor SHA bindings are changed. Its file is a candidate and must itself receive a fresh hash pin in any new ownCI launch/receipt. Existing ownCI receipts and archives must remain frozen.

## Hash binding

- Root-v4 runner baseline SHA-256: `b23e5f0a5a0b55b3a3684fba3dd6976ef544b153413e1a42d9355f70ab0b5b20`
- Root-v4 acceptance baseline SHA-256: `2fadf2b1d7d50887030ad117eeb16d2b6d0421be085c19a0b16d80885b7ecae1`
- Candidate runner: `/private/tmp/jarde-ordered-field-full-workspace-prep-root-v5/workspace_runner.py`, SHA-256 `ab5e8f6bd6d7ead5cf6facf4dc97d4639d8a9b7455dcab22ed6bea402c228348`
- Candidate acceptance: `/private/tmp/jarde-ordered-field-full-workspace-prep-root-v5/accept_workspace.py`, SHA-256 `e8262abeea999164c150c28e848124ba0d384b8bee27a1fef0698b8aa9caa62d`
- Candidate ownCI verifier: `/private/tmp/jarde-ordered-field-full-workspace-prep-root-v5/verify-own-ci.py`, SHA-256 `07fce312c911e7624668f4414f37c102ed10557a428a734d15bf143b13fb8cd2`

`candidate.patch` contains runner/acceptance changes against the exact root-v4 files. `verify-own-ci.patch` shows the isolated verifier binding changes. Do not reuse root-v4 runner/acceptance hash bindings for the candidate; any new runner receipt and ownCI verifier receipt must bind the candidate paths and these exact hashes. No root-v5 workspace output is present or implied.
