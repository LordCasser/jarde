# Root-v5 workspace scripts: static audit

Read-only review of the three exact scripts named by the parent task. No workspace run, Cargo/JDK/JADX/CLI/Git command, shared-repository edit, or receipt/archive change was performed. Python AST parsing and AST literal comparison were used for static verification.

## Inputs and pins

- Runner: `/private/tmp/jarde-ordered-field-full-workspace-prep-root-v5/workspace_runner.py`, SHA-256 `378a91863f2b02ac3fe618c50b32ccc6753f4f633c37a548d3b98b3def0abc43`.
- Local acceptor: `/private/tmp/jarde-ordered-field-full-workspace-prep-root-v5/accept_workspace.py`, SHA-256 `115f28dcaa32746655178e7ff65e6ad58a881116ed3ec99b49cc9ee71a8cf165`.
- ownCI verifier: `/private/tmp/jarde-ordered-field-own-ci-prep-root-v4/verify-own-ci.py`, SHA-256 `33f8b39c8537988e1015b69a75168f36daa511d895fd32493ebca21d9521b97d`.
- Failure replay record: `/private/tmp/jarde-ordered-field-full-workspace-prep-root-v5/failure-log-replay.json`.

## Findings

There is no remaining `rows[:6]` or six-command focused slice in these scripts. The focused command contract is seven ordinary commands plus one final cleanup: runner and local acceptor require `len(expected) == 7` and `len(rows) == 8`, inspect every `rows[:-1]` command against the seven-item spec, and inspect `rows[-1]` as exact `cargo clean`. ownCI likewise checks a seven-entry command spec, eight receipt rows, maps all seven ordinary rows with `zip(rows[:-1], expected)`, and validates row 8 as final cleanup. The full-workspace receipt uses a metadata-derived batch count (`2 + 2*batches + 1`), checks every command except the final cleanup through `commands[:-1]`, and indexes final cleanup as `len(commands)-1`; no fixed six-command omission was found.

CLI and strict gates are present. The focused runner verifies exactly one successful `cargo build -p jarde-cli --locked` in the receipt. The local acceptor also verifies that build exists among `rows[:-1]`. ownCI independently verifies the focused command spec begins with exact fmt and workflow clippy argv, ends with exact `openspec validate --all --strict --no-interactive`, includes exactly one CLI build and at least one test command, checks all command rows against the spec, and verifies the frozen CLI path/hash/mode. The final `cargo clean` is separately checked. Therefore the seventh ordinary strict command and eighth final cleanup are not dropped by a stale slice.

The two newly added `jarde-java` unit gates match between runner and local acceptor. Static AST literal comparison found both `FOCUSED_EXPECTED_OUTCOMES` and `FOCUSED_EXPECTED` have 14 entries and are exactly equal. Both include `build::tests::reference_load_rejects_caught_parameter_alias_from_real_handler_ssa: ok` and `build::tests::same_block_reference_load_is_presented_outside_try_for_fixed_dv_variants: ok`. The runner unions the focused map into `REQUIRED_NAMED_TESTS` (`REQUIRED_NAMED_TESTS |= set(FOCUSED_EXPECTED_OUTCOMES)`), so these two also become per-workspace required passing names. The local acceptor requires the focused set exactly once per seed and rechecks its subset against the `jarde-java` lib / `p3_patterns` suites. ownCI loops over the runner's focused map and requires exactly one same-status local hit per name; it also derives the full required-name set from the pinned runner and requires every one exactly once and passing per seed. The dynamic named-outcome equality remains intact.

The replay evidence is consistent with the intended failure-path fix: batch 67, first seed, exit 101, one failed named test `the_refused_slices_keep_the_instructions_their_closure_covers`, and a failed summary with 3 passed / 1 failed / 1 ignored were captured in `failure-log-replay.json`. The recorded error is `workspace product test command failed before artifact parsing` and includes the original stdout/stderr pins. This is evidence from the replay record, not an independent execution in this audit.

## One remaining acceptance gap

The runner and local acceptor each pin `expected[4]` to exact `cargo clean -p jarde -p jarde-java`. However, the ownCI verifier does not assert that command, and none of the three validators explicitly pins the CLI build to index 5, after the package clean. ownCI checks only that there is exactly one CLI build somewhere in the seven commands; it checks every row matches whatever command spec is supplied, but the command spec hash is receipt-provided and ownCI does not bind its fifth/sixth entries to those exact argv values. As a result, the current receipts produced by the pinned runner/acceptor enforce the package-clean command at index 5? The runner/acceptor require it at index 5 in 1-based command numbering (zero-based `expected[4]`), but they do not require the unique CLI build to follow it. ownCI itself can accept a command spec with no package cleanup or with the CLI build before it, as long as the other explicit fmt/clippy/strict/build/test and row-to-spec gates hold.

Recommended narrow fix before treating the ownCI verifier as an independent proof of the seven-command order: require `expected[4] == ['cargo','clean','-p','jarde','-p','jarde-java']`, require `expected[5] == ['cargo','build','-p','jarde-cli','--locked']`, and require every `cargo test` command to precede index 4. Keep the current dynamic seven-command length, row-to-spec equality, exact strict final command, final cleanup, raw log verification, and dynamic named gates. Then repin the ownCI verifier and any new ownCI receipt that names its source hash. This is an audit recommendation only; no script was changed here.

## Limits

This review verifies static code and the provided replay JSON only. It does not independently certify that root-v5 full-workspace execution passed; the parent states the current root final-source focused run is still in progress. No output or result is inferred from that in-progress run.
