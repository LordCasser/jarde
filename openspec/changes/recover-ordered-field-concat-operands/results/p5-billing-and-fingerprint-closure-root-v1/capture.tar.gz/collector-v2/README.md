# P5 per-method billing delta collector

`collect.py` collects a private old/current `recover_method` comparison for the 24 declared methods in `Guarded.class` and 19 in `BooleanContexts.class`. It first sends each CLI an `inspect_header` request for each actual class path, then builds every recovery request from that response's `StandaloneRoot` snapshot, `class_bytes`, and method headers. Recovery uses the fixed Java 8 standalone classpath environment, all six `AnalysisStage` values, the `RecoveryEvidenceRequest::all()` selection, and the limits from `tests/bulk_support.rs::limits`.

The collector checks the two class SHA pins before running, verifies each supplied CLI SHA and frozen mode against the executable, and requires each build receipt to pin that exact CLI and contain a successful guarded `cargo build -p jarde-cli --locked` row whose stdout and stderr still match their receipt pins. It supports the actual receipt fields `cli_freeze` (old) and `cli` (current). It preserves each exact request, complete raw stdout/response, raw stderr, command argv, exit status, guard stop, peak target size, free-space readings, and the child environment rules. Each call uses the pinned root guard and target scanner with the 5 GiB free-space limit, 1 GiB target limit, one-second sampling, a child process group, and an environment with `RUST_MIN_STACK`, `CARGO_TARGET_DIR`, and JVM option variables removed.

The per-method billing delta comes from `result.report.execution.usage`, which includes recovery proof charges. The script also retains `result.analysis.execution.usage` separately so the phase snapshot cannot be mistaken for the complete recovery ledger. It reports every counted dimension and exact old/current values for `text`, `outcome`, `content`, and `source_map`; semantic differences are collected verbatim instead of being hidden behind a full-response equality check. The observed totals and equality checks are reported without manufacturing baseline values. Header reads are separately pinned and are not included in the recovery usage comparison.

The CLI paths, their SHA values, and build receipt paths are arguments so this prep does not bind results to mutable build paths. Run from any directory with the exact root-owned artifacts:

```sh
python3 /private/tmp/jarde-p5-billing-delta-audit-luna-v2/collect.py \
  --old-cli /private/tmp/jarde-cf11-structured-list-candidate-cli-root-v4 \
  --old-sha256 d3d15d3dd875bc79410298e3ed1e56010fc39c1849e97dc893cadb49d8c65e6f \
  --old-buildreceipt /private/tmp/jarde-cf11-structured-list-focused-root-v12/execution.json \
  --current-cli /private/tmp/jarde-ordered-field-final-check-root-v5/candidate-cli \
  --current-sha256 f991644eb87cef29df1509b270ba48d7c5d26ba72f46a5fae3271fc4528e3622 \
  --current-buildreceipt /private/tmp/jarde-ordered-field-final-check-root-v5/execution.json \
  --output-dir /private/tmp/jarde-p5-billing-delta-audit-root-v1
```

The output path must not already exist. This script has not been run; it does not contain observed comparison values or a fabricated baseline. `summary.json`, `methods.json`, and `semantic_differences.json` are written after all 43 method requests from both CLIs complete; their expected +44 and equality checks are reported as measured results. Individual pins remain available if a CLI request fails partway through.
