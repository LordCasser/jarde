#!/usr/bin/env python3
"""Collect a pinned old/new jarde-cli recover_method comparison for two class files."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import shutil
from typing import Any


HERE = Path(__file__).resolve().parent
PINS_PATH = HERE / "pins.json"
LIMITS = {
    "input_bytes": 16 * 1024 * 1024,
    "archive_entries": 10_000,
    "entry_bytes": 16 * 1024 * 1024,
    "read_bytes": 64 * 1024 * 1024,
    "class_bytes": 16 * 1024 * 1024,
    "attribute_bytes": 16 * 1024 * 1024,
    "code_bytes": 16 * 1024 * 1024,
    "result_items": 100_000,
    "output_bytes": 64 * 1024 * 1024,
    "class_headers": 10_000,
    "method_bodies": 10_000,
    "ir_items": 1 << 22,
    "ir_edges": 1 << 22,
    "analysis_steps": 1 << 22,
    "normalization_clones": 1 << 20,
    "nested_depth": 8,
    "dependency_depth": 8,
    "elapsed_millis": 2**64 - 1,
}
COUNTED_USAGE = (
    "input_bytes",
    "archive_entries",
    "entry_bytes",
    "read_bytes",
    "class_bytes",
    "attribute_bytes",
    "code_bytes",
    "result_items",
    "output_bytes",
    "class_headers",
    "method_bodies",
    "ir_items",
    "ir_edges",
    "analysis_steps",
    "normalization_clones",
)
STAGES = [
    "raw_facts",
    "raw_cfg",
    "legacy_normalization",
    "canonical_cfg",
    "frame",
    "ssa",
]


def json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def ensure_file(path_text: str, label: str) -> Path:
    path = Path(path_text).expanduser().resolve(strict=True)
    if not path.is_file():
        raise ValueError(f"{label} is not a file: {path}")
    return path


def verify_cli(path_text: str, pinned_sha: str, label: str) -> tuple[Path, str]:
    path = ensure_file(path_text, label)
    actual = sha256_file(path)
    if actual != pinned_sha.lower():
        raise ValueError(f"{label} SHA-256 mismatch: argv={pinned_sha}, actual={actual}, path={path}")
    if not os.access(path, os.X_OK):
        raise ValueError(f"{label} is not executable: {path}")
    if stat.S_IMODE(path.stat().st_mode) != 0o555:
        raise ValueError(f"{label} is not frozen read/execute-only (expected mode 0555): {path}")
    return path, actual


def request_document(input_path: Path, operation: dict[str, Any]) -> dict[str, Any]:
    return {"input_path": str(input_path), "limits": LIMITS, "operation": operation}


def pin_file(path: Path) -> dict[str, Any]:
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha256_file(path)}


def load_pinned_module(path_text: str, expected_sha: str, module_name: str):
    path = ensure_file(path_text, module_name)
    actual = sha256_file(path)
    if actual != expected_sha:
        raise ValueError(f"{module_name} pin mismatch: expected={expected_sha}, actual={actual}, path={path}")
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"cannot load pinned {module_name}: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, path, actual


def build_receipt_binding(receipt_path: Path, cli_path: Path, cli_sha: str, label: str) -> dict[str, Any]:
    receipt_raw = receipt_path.read_bytes()
    try:
        receipt = json.loads(receipt_raw)
    except json.JSONDecodeError as error:
        raise ValueError(f"{label} build receipt is not JSON: {receipt_path}") from error
    successful_builds = [
        row for row in receipt.get("commands", [])
        if row.get("argv") == ["cargo", "build", "-p", "jarde-cli", "--locked"]
        and row.get("exit_code") == 0
        and row.get("guard_stop") is None
    ]
    if not successful_builds:
        raise ValueError(f"{label} build receipt has no successful guarded jarde-cli build: {receipt_path}")
    build = successful_builds[-1]
    pinned_streams = {}
    for stream_name, stream_pin in build.get("streams", {}).items():
        stream_path = ensure_file(stream_pin["path"], f"{label} build {stream_name}")
        actual_stream = pin_file(stream_path)
        if actual_stream["bytes"] != stream_pin["bytes"] or actual_stream["sha256"] != stream_pin["sha256"]:
            raise ValueError(f"{label} build {stream_name} does not match its receipt pin: {stream_path}")
        pinned_streams[stream_name] = actual_stream
    recorded_cli = receipt.get("cli_freeze", receipt.get("cli"))
    if not isinstance(recorded_cli, dict):
        raise ValueError(f"{label} build receipt has no CLI artifact pin (cli_freeze/cli): {receipt_path}")
    expected_cli = {
        "path": str(cli_path),
        "bytes": cli_path.stat().st_size,
        "sha256": cli_sha,
        "mode": oct(stat.S_IMODE(cli_path.stat().st_mode)),
    }
    compared_keys = ("path", "bytes", "sha256") + (("mode",) if "mode" in recorded_cli else ())
    receipt_cli_binding = {
        "receipt_key": "cli_freeze" if "cli_freeze" in receipt else "cli",
        "receipt_cli": recorded_cli,
        "argv_cli": expected_cli,
        "compared_keys": list(compared_keys),
        "matches": all(recorded_cli.get(key) == expected_cli[key] for key in compared_keys),
    }
    if not receipt_cli_binding["matches"]:
        raise ValueError(f"{label} CLI pin in build receipt does not match the supplied CLI: {receipt_path}")
    return {
        "label": label,
        "cli": pin_file(cli_path),
        "receipt": pin_file(receipt_path),
        "receipt_status": receipt.get("status"),
        "build_command": {
            "index": build.get("index"),
            "argv": build.get("argv"),
            "exit_code": build.get("exit_code"),
            "guard_stop": build.get("guard_stop"),
            "streams": pinned_streams,
        },
        "receipt_cli_binding": receipt_cli_binding,
        "receipt_cli_binding_note": None,
    }


def run_pinned(
    cli_path: Path,
    request: dict[str, Any],
    pin_dir: Path,
    *,
    guard: Any,
    env: dict[str, str],
) -> dict[str, Any]:
    pin_dir.mkdir(parents=True, exist_ok=False)
    request_raw = json_bytes(request)
    request_path = pin_dir / "request.json"
    request_path.write_bytes(request_raw)
    argv = [str(cli_path), "--request", str(request_path)]
    guard.OUT = pin_dir
    free_bytes_before = shutil.disk_usage(guard.ROOT).free
    target_bytes_before = guard.target_bytes()
    row = guard.run_command(1, argv, env)
    row["resource_guard_pre_and_post"] = {
        "free_bytes_before": free_bytes_before,
        "free_bytes_after": row["free_bytes_after"],
        "target_bytes_before": target_bytes_before,
        "peak_target_bytes": row["peak_target_bytes"],
    }
    row["child_environment"] = {
        "removed_keys": [
            "RUST_MIN_STACK", "CARGO_TARGET_DIR", "JAVA_TOOL_OPTIONS", "_JAVA_OPTIONS",
            "JDK_JAVA_OPTIONS", "CLASSPATH",
        ],
        "removed_keys_present_in_parent": sorted(
            key for key in ("RUST_MIN_STACK", "CARGO_TARGET_DIR", "JAVA_TOOL_OPTIONS", "_JAVA_OPTIONS", "JDK_JAVA_OPTIONS", "CLASSPATH")
            if key in os.environ
        ),
        "default_rust_stack": "RUST_MIN_STACK omitted from child environment",
        "overrides": guard.ENV_VALUES,
    }
    (pin_dir / "command.json").write_bytes(json_bytes(row))
    (pin_dir / "exit.json").write_bytes(json_bytes({
        key: row.get(key) for key in ("argv", "exit_code", "guard_stop", "peak_target_bytes", "free_bytes_after")
    }))
    stdout_path = pin_dir / "1.stdout.raw"
    stderr_path = pin_dir / "1.stderr.raw"
    stdout = stdout_path.read_bytes() if stdout_path.exists() else b""
    try:
        response = json.loads(stdout)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise RuntimeError(f"CLI stdout is not a complete JSON response; raw streams are pinned at {pin_dir}") from error
    (pin_dir / "response.json").write_bytes(json_bytes(response))
    if response.get("status") != "ok" or row["exit_code"] != 0 or row["guard_stop"] is not None:
        raise RuntimeError(
            f"CLI request failed (exit={row['exit_code']}, guard_stop={row['guard_stop']}, status={response.get('status')}); request, response and guarded raw streams are pinned at {pin_dir}"
        )
    return response


def root_snapshot_and_class_bytes(header_response: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    report = header_response["result"]["report"]
    source = report["source"]
    location = source["location"]
    if location.get("kind") != "standalone_root":
        raise ValueError(f"InspectHeader did not return StandaloneRoot: {location}")
    snapshot = location["snapshot"]
    class_bytes = source["class_bytes"]
    return snapshot, class_bytes


def recover_request(input_path: Path, snapshot: dict[str, Any], class_bytes: dict[str, Any], member: dict[str, Any]) -> dict[str, Any]:
    owner = {
        "location": {"kind": "standalone_root", "snapshot": snapshot},
        "class_bytes": class_bytes,
        "variant": {"kind": "base"},
    }
    method = {
        "owner": owner,
        "name": member["name"]["raw"],
        "descriptor": member["descriptor"]["raw"],
    }
    domain = {
        "loader": "app",
        "parent_loader": None,
        "delegation": {"kind": "parent_first"},
        "roots": [{"kind": "standalone_class", "snapshot": snapshot}],
        "module_mode": {"kind": "class_path"},
        "external_override": "none",
        "runtime_transformation": "none",
    }
    environment = {
        "runtime": {
            "physical": {"snapshot": snapshot, "scope": {"kind": "snapshot_all"}},
            "profile": {
                "java_release": 8,
                "multi_release": {"kind": "disabled"},
                "layout": {"kind": "generic"},
            },
            "load_domain": domain,
        },
        "domains": [domain],
        "providers": [],
    }
    operation = {
        "kind": "recover_method",
        "environment": environment,
        "method": method,
        "stages": STAGES,
        "evidence": {
            "kinds": ["source_map", "region_details", "rule_details", "name_details", "read_details"],
            "driver_bci_range": None,
            "expected_artifact": None,
        },
    }
    return request_document(input_path, operation)


def member_pin_name(index: int, member: dict[str, Any]) -> str:
    name = bytes(member["name"]["raw"]).decode("ascii", "backslashreplace")
    descriptor = bytes(member["descriptor"]["raw"]).decode("ascii", "backslashreplace")
    slug = "".join(char if char.isalnum() or char in "._-" else "_" for char in name)
    key = hashlib.sha256(json_bytes([member["name"]["raw"], member["descriptor"]["raw"]])).hexdigest()[:10]
    return f"{index:02d}-{slug}-{key}"


def usage_from(response: dict[str, Any], report: str) -> dict[str, int]:
    usage = response["result"][report]["execution"]["usage"]
    missing = [field for field in COUNTED_USAGE if field not in usage]
    wrong_type = [field for field in COUNTED_USAGE if type(usage.get(field)) is not int]
    if missing or wrong_type:
        raise ValueError(f"{report}.execution.usage missing or non-integer counted fields: missing={missing}, non_integer={wrong_type}")
    return usage


def compare_one(old: dict[str, Any], new: dict[str, Any]) -> dict[str, Any]:
    old_recovery = old["result"]["report"]
    new_recovery = new["result"]["report"]
    exact_fields = ("text", "outcome", "content", "source_map")
    equal = {field: old_recovery[field] == new_recovery[field] for field in exact_fields}
    old_recovery_usage = usage_from(old, "report")
    new_recovery_usage = usage_from(new, "report")
    old_analysis_usage = usage_from(old, "analysis")
    new_analysis_usage = usage_from(new, "analysis")
    deltas = {
        field: new_recovery_usage[field] - old_recovery_usage[field]
        for field in COUNTED_USAGE
    }
    return {
        "semantic_report_fields_exact_equal": equal,
        "counted_usage_delta_current_minus_old": deltas,
        "old_recovery_counted_usage": {key: old_recovery_usage[key] for key in COUNTED_USAGE},
        "current_recovery_counted_usage": {key: new_recovery_usage[key] for key in COUNTED_USAGE},
        "old_analysis_phase_counted_usage": {key: old_analysis_usage[key] for key in COUNTED_USAGE},
        "current_analysis_phase_counted_usage": {key: new_analysis_usage[key] for key in COUNTED_USAGE},
        "semantic_report_fields": {
            field: {"old": old_recovery[field], "current": new_recovery[field]}
            for field in exact_fields if not equal[field]
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--old-cli", required=True)
    parser.add_argument("--old-sha256", required=True)
    parser.add_argument("--old-buildreceipt", required=True)
    parser.add_argument("--current-cli", required=True)
    parser.add_argument("--current-sha256", required=True)
    parser.add_argument("--current-buildreceipt", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    try:
        pins = json.loads(PINS_PATH.read_text(encoding="utf-8"))
        old_cli, old_sha = verify_cli(args.old_cli, args.old_sha256, "old CLI")
        current_cli, current_sha = verify_cli(args.current_cli, args.current_sha256, "current CLI")
        old_receipt = ensure_file(args.old_buildreceipt, "old buildreceipt")
        current_receipt = ensure_file(args.current_buildreceipt, "current buildreceipt")
        old_build_binding = build_receipt_binding(old_receipt, old_cli, old_sha, "old")
        current_build_binding = build_receipt_binding(current_receipt, current_cli, current_sha, "current")
        guard, guard_path, guard_sha = load_pinned_module(
            pins["execution_guard"]["path"], pins["execution_guard"]["sha256"], "jarde_rootguard"
        )
        scanner, scanner_path, scanner_sha = load_pinned_module(
            pins["target_scanner"]["path"], pins["target_scanner"]["sha256"], "jarde_target_scanner"
        )
        repo_root = Path(pins["root"]).resolve(strict=True)
        guard.ROOT = repo_root
        guard.target_bytes = lambda: scanner.target_bytes(repo_root)
        guard.expected_test_summaries = lambda index, raw: None
        guard.command_stream = lambda path: pin_file(Path(path))
        excluded_env = {
            "RUST_MIN_STACK",
            "CARGO_TARGET_DIR",
            "JAVA_TOOL_OPTIONS",
            "_JAVA_OPTIONS",
            "JDK_JAVA_OPTIONS",
            "CLASSPATH",
        }
        env = {key: value for key, value in os.environ.items() if key not in excluded_env}
        env.update(guard.ENV_VALUES)
        output_dir = Path(args.output_dir).expanduser().resolve()
        if output_dir.exists():
            raise ValueError(f"output directory already exists; refusing to overwrite pins: {output_dir}")
        output_dir.mkdir(parents=True)
        (output_dir / "buildreceipts").mkdir()
        (output_dir / "buildreceipts/old.execution.json").write_bytes(old_receipt.read_bytes())
        (output_dir / "buildreceipts/current.execution.json").write_bytes(current_receipt.read_bytes())
        dependencies = {
            "execution_guard": pin_file(guard_path),
            "target_scanner": pin_file(scanner_path),
        }
        (output_dir / "build_bindings.json").write_bytes(
            json_bytes({"old": old_build_binding, "current": current_build_binding, "dependencies": dependencies})
        )

        legs = {
            "old": {"path": str(old_cli), "sha256": old_sha, "receipt": str(old_receipt)},
            "current": {"path": str(current_cli), "sha256": current_sha, "receipt": str(current_receipt)},
        }
        classes_summary: dict[str, Any] = {}
        all_rows: list[dict[str, Any]] = []
        for class_pin in pins["classes"]:
            class_name = class_pin["name"]
            input_path = ensure_file(class_pin["path"], f"{class_name} class")
            class_sha = sha256_file(input_path)
            if class_sha != class_pin["sha256"]:
                raise ValueError(f"{class_name} class SHA-256 mismatch: pinned={class_pin['sha256']}, actual={class_sha}")
            class_dir = output_dir / class_pin["id"]
            class_dir.mkdir()
            per_leg: dict[str, tuple[dict[str, Any], list[dict[str, Any]]]] = {}
            for leg_name, cli_path in (("old", old_cli), ("current", current_cli)):
                header_request = request_document(input_path, {
                    "kind": "inspect_header",
                    "target": {"kind": "root"},
                    "mode": "strict",
                })
                header_response = run_pinned(
                    cli_path,
                    header_request,
                    class_dir / leg_name / "inspect-header",
                    guard=guard,
                    env=env,
                )
                snapshot, class_bytes = root_snapshot_and_class_bytes(header_response)
                if class_bytes["length"] != input_path.stat().st_size:
                    raise ValueError(
                        f"{class_name} {leg_name} InspectHeader class-byte length {class_bytes['length']} "
                        f"does not match fixture size {input_path.stat().st_size}"
                    )
                members = header_response["result"]["report"]["inspection"]["header"]["methods"]
                if len(members) != class_pin["method_count"]:
                    raise ValueError(
                        f"{class_name} {leg_name} method count {len(members)} != pinned {class_pin['method_count']}"
                    )
                observations = []
                for index, member in enumerate(members):
                    pin_name = member_pin_name(index, member)
                    request = recover_request(input_path, snapshot, class_bytes, member)
                    response = run_pinned(
                        cli_path,
                        request,
                        class_dir / leg_name / "recover-method" / pin_name,
                        guard=guard,
                        env=env,
                    )
                    identity = {
                        "index": index,
                        "name_raw": member["name"]["raw"],
                        "descriptor_raw": member["descriptor"]["raw"],
                        "name_ascii": bytes(member["name"]["raw"]).decode("ascii", "backslashreplace"),
                        "descriptor_ascii": bytes(member["descriptor"]["raw"]).decode("ascii", "backslashreplace"),
                        "pin_name": pin_name,
                    }
                    observations.append({"identity": identity, "response": response})
                per_leg[leg_name] = (header_response, observations)

            old_observations = per_leg["old"][1]
            current_observations = per_leg["current"][1]
            if len(old_observations) != len(current_observations):
                raise ValueError(f"{class_name}: old/current member result counts differ")
            class_rows = []
            for old_item, current_item in zip(old_observations, current_observations, strict=True):
                if old_item["identity"] != current_item["identity"]:
                    raise ValueError(f"{class_name}: old/current header method order or identity differs")
                result = compare_one(old_item["response"], current_item["response"])
                row = {"class": class_name, **old_item["identity"], **result}
                class_rows.append(row)
                all_rows.append(row)
            classes_summary[class_name] = {
                "class_path": str(input_path),
                "class_sha256": class_sha,
                "method_count": len(class_rows),
                "methods_with_counted_delta": [
                    {
                        "index": row["index"],
                        "name_raw": row["name_raw"],
                        "descriptor_raw": row["descriptor_raw"],
                        "name_ascii": row["name_ascii"],
                        "descriptor_ascii": row["descriptor_ascii"],
                        "delta": row["counted_usage_delta_current_minus_old"],
                    }
                    for row in class_rows
                    if any(value != 0 for value in row["counted_usage_delta_current_minus_old"].values())
                ],
            }

        aggregate = {field: sum(row["counted_usage_delta_current_minus_old"][field] for row in all_rows) for field in COUNTED_USAGE}
        semantic_differences = [
            {
                "class": row["class"],
                "index": row["index"],
                "name_raw": row["name_raw"],
                "descriptor_raw": row["descriptor_raw"],
                "name_ascii": row["name_ascii"],
                "descriptor_ascii": row["descriptor_ascii"],
                "fields": row["semantic_report_fields"],
            }
            for row in all_rows if row["semantic_report_fields"]
        ]
        semantic_fields = ("text", "outcome", "content", "source_map")
        semantic_equal = all(
            all(row["semantic_report_fields_exact_equal"].values()) for row in all_rows
        )
        delta_methods = [
            {
                "class": row["class"],
                "index": row["index"],
                "name_raw": row["name_raw"],
                "descriptor_raw": row["descriptor_raw"],
                "delta": row["counted_usage_delta_current_minus_old"],
            }
            for row in all_rows
            if any(value != 0 for value in row["counted_usage_delta_current_minus_old"].values())
        ]
        summary = {
            "status": "comparison_collected",
            "comparison": "current_minus_old",
            "legs": legs,
            "build_bindings": {"old": old_build_binding, "current": current_build_binding},
            "dependencies": dependencies,
            "class_pins": pins["classes"],
            "method_count": len(all_rows),
            "expected_method_count_43": len(all_rows) == 43,
            "semantic_fields_compared": list(semantic_fields),
            "semantic_fields_exact_equal_for_all_methods": semantic_equal,
            "semantic_differences": semantic_differences,
            "counted_usage_delta_sum": aggregate,
            "expected_delta_check": {
                "analysis_steps_is_plus_44": aggregate.get("analysis_steps") == 44,
                "other_counted_dimensions_are_unchanged": all(
                    value == 0 for field, value in aggregate.items() if field != "analysis_steps"
                ),
            },
            "methods_with_counted_delta": delta_methods,
            "classes": classes_summary,
        }
        (output_dir / "methods.json").write_bytes(json_bytes(all_rows))
        (output_dir / "semantic_differences.json").write_bytes(json_bytes(semantic_differences))
        (output_dir / "summary.json").write_bytes(json_bytes(summary))
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, KeyError, TypeError, RuntimeError, json.JSONDecodeError) as error:
        print(f"collect.py: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
