#!/usr/bin/env python3
"""Read-only independent acceptance of the pinned P5 billing comparison."""
from __future__ import annotations
import hashlib, json, os, stat
from pathlib import Path

ROOT = Path('/private/tmp/jarde-p5-billing-delta-audit-root-v1')
USAGE = ('input_bytes','archive_entries','entry_bytes','read_bytes','class_bytes',
         'attribute_bytes','code_bytes','result_items','output_bytes','class_headers',
         'method_bodies','ir_items','ir_edges','analysis_steps','normalization_clones')
CLASSES = {'guarded': ('Guarded', 24), 'boolean-contexts': ('BooleanContexts', 19)}
FIELDS = ('text','outcome','content','source_map')
REMOVED = {'RUST_MIN_STACK','CARGO_TARGET_DIR','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH'}

def jread(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical_digest_tree(root):
    h=hashlib.sha256()
    for p in sorted(x for x in root.rglob('*') if x.is_file()):
        rel=p.relative_to(root).as_posix().encode()
        h.update(len(rel).to_bytes(4,'big')); h.update(rel)
        b=p.read_bytes(); h.update(len(b).to_bytes(8,'big')); h.update(hashlib.sha256(b).digest())
    return h.hexdigest()
def check(ok, msg):
    if not ok: raise AssertionError(msg)
def call(pin):
    d=jread(pin/'command.json'); req=jread(pin/'request.json'); ex=jread(pin/'exit.json'); res=jread(pin/'response.json')
    check(d['argv'][1:] == ['--request', str(pin/'request.json')], f'argv/request mismatch: {pin}')
    check(d['cwd'] == '/Users/lordcasser/workspace/projects/jarde', f'cwd mismatch: {pin}')
    check(d['exit_code'] == 0 and d['guard_stop'] is None, f'command did not pass: {pin}')
    check(ex == {k:d.get(k) for k in ('argv','exit_code','guard_stop','peak_target_bytes','free_bytes_after')}, f'exit pin mismatch: {pin}')
    check(res.get('status') == 'ok', f'non-ok response: {pin}')
    for stream in ('stdout','stderr'):
        sp=pin/f'1.{stream}.raw'; pinrow=d['streams'][stream]
        check(sp.is_file() and sp.stat().st_size == pinrow['bytes'] and sha(sp)==pinrow['sha256'], f'{stream} pin mismatch: {pin}')
    check(json.loads((pin/'1.stdout.raw').read_text(encoding='utf-8')) == res, f'raw stdout != parsed response pin: {pin}')
    check(d['child_environment']['removed_keys'] == sorted(REMOVED) or set(d['child_environment']['removed_keys']) == REMOVED, f'removed env set mismatch: {pin}')
    check(d['child_environment']['default_rust_stack'] == 'RUST_MIN_STACK omitted from child environment', f'RUST_MIN_STACK rule absent: {pin}')
    check(not d['child_environment']['removed_keys_present_in_parent'], f'removed parent env present: {pin}')
    check(d['child_environment']['overrides'] == d['env_overrides'], f'env overrides disagree: {pin}')
    check(d['resource_guard_pre_and_post']['target_bytes_before'] == 0 and d['resource_guard_pre_and_post']['peak_target_bytes'] == d['peak_target_bytes'], f'target guard pin mismatch: {pin}')
    check(d['resource_guard_pre_and_post']['free_bytes_before'] >= 5*1024**3 and d['free_bytes_after'] >= 5*1024**3, f'free-space guard below 5GiB: {pin}')
    return req,res,d

def main():
    check(ROOT.is_dir(), f'missing root {ROOT}')
    summary=jread(ROOT/'summary.json'); methods=jread(ROOT/'methods.json'); diffs=jread(ROOT/'semantic_differences.json'); build=jread(ROOT/'build_bindings.json')
    check(len(methods)==43, f'method row count {len(methods)}')
    cli_by_leg={}
    for leg in ('old','current'):
        b=build[leg]; cli=Path(b['cli']['path']); receipt=Path(b['receipt']['path'])
        check(cli.is_file() and sha(cli)==b['cli']['sha256'],f'{leg} CLI content pin mismatch')
        check(stat.S_IMODE(cli.stat().st_mode)==0o555 and os.access(cli,os.X_OK),f'{leg} CLI mode mismatch')
        check(receipt.is_file() and sha(receipt)==b['receipt']['sha256'],f'{leg} receipt pin mismatch')
        rec=jread(receipt)
        rows=[x for x in rec.get('commands',[]) if x.get('argv')==['cargo','build','-p','jarde-cli','--locked'] and x.get('exit_code')==0 and x.get('guard_stop') is None]
        check(bool(rows),f'{leg} receipt lacks successful guarded build')
        bind=b['receipt_cli_binding']
        check(bind['matches'],f'{leg} receipt CLI binding not recorded as matching')
        receipt_cli=rec.get('cli_freeze',rec.get('cli'))
        check(receipt_cli is not None and receipt_cli.get('path')==str(cli) and receipt_cli.get('bytes')==cli.stat().st_size and receipt_cli.get('sha256')==sha(cli),f'{leg} receipt does not bind exact CLI')
        row=rows[-1]; recorded=b['build_command']
        check(recorded.get('argv')==row.get('argv') and recorded.get('exit_code')==row.get('exit_code') and recorded.get('guard_stop')==row.get('guard_stop'),f'{leg} successful build row differs')
        for stream,pin in row.get('streams',{}).items():
            sp=Path(pin['path']); check(sp.is_file() and sp.stat().st_size==pin['bytes'] and sha(sp)==pin['sha256'],f'{leg} build {stream} stream pin mismatch')
        cli_by_leg[leg]=cli
    check(summary['method_count']==43, 'summary count mismatch')
    check(summary['semantic_fields_compared']==list(FIELDS), 'wrong compared semantic fields')
    observations={}
    call_count=0
    identity_order={}
    for class_id,(class_name,expected) in CLASSES.items():
        legs={}
        for leg in ('old','current'):
            hreq,hres,_=call(ROOT/class_id/leg/'inspect-header'); call_count+=1
            check(hreq['operation']=={'kind':'inspect_header','target':{'kind':'root'},'mode':'strict'},f'header request wrong: {class_id}/{leg}')
            header=hres['result']['report']
            check(header['source']['location']['kind']=='standalone_root', f'header root kind wrong: {class_id}/{leg}')
            methods_header=header['inspection']['header']['methods']
            check(len(methods_header)==expected,f'physical methods={len(methods_header)} expected={expected}: {class_id}/{leg}')
            entries=[]
            for p in sorted((ROOT/class_id/leg/'recover-method').iterdir()):
                req,res,cmd=call(p); call_count+=1
                op=req['operation']; check(op['kind']=='recover_method',f'wrong operation: {p}')
                check(req['input_path']==hreq['input_path'],f'class input path differs: {p}')
                check(op['method']['owner']['location']['snapshot']==header['source']['location']['snapshot'],f'owner snapshot != header: {p}')
                check(op['method']['owner']['class_bytes']==header['source']['class_bytes'],f'class bytes != header: {p}')
                check(op['environment']['runtime']['physical']['snapshot']==header['source']['location']['snapshot'],f'physical snapshot != header: {p}')
                check(op['stages']==['raw_facts','raw_cfg','legacy_normalization','canonical_cfg','frame','ssa'],f'stage request mismatch: {p}')
                check(op['evidence']['kinds']==['source_map','region_details','rule_details','name_details','read_details'],f'evidence selection mismatch: {p}')
                report=res['result']['report']; usage=report['execution']['usage']; phase=res['result']['analysis']['execution']['usage']
                check(all(type(usage.get(k)) is int for k in USAGE),f'recovery usage missing/non-int field: {p}')
                check(all(type(phase.get(k)) is int for k in USAGE),f'analysis usage missing/non-int field: {p}')
                stages=res['result']['analysis']['stages']
                check([x['stage'] for x in stages]==list(op['stages']) and all(x['state']['kind']=='completed' for x in stages),f'incomplete analysis stages: {p}')
                ident=(tuple(op['method']['name']),tuple(op['method']['descriptor']))
                entries.append((ident,req,res,p))
            check(len(entries)==expected,f'recovery calls={len(entries)} expected={expected}: {class_id}/{leg}')
            entries.sort(key=lambda x: x[3].name)
            legs[leg]=(hreq,hres,entries)
        a,b=legs['old'],legs['current']
        check(a[0]==b[0],f'old/current inspect request differ: {class_id}')
        check(a[1]['result']['report']['inspection']['header']['methods']==b[1]['result']['report']['inspection']['header']['methods'],f'old/current method headers differ: {class_id}')
        check([x[0] for x in a[2]]==[x[0] for x in b[2]],f'old/current physical identity/order differs: {class_id}')
        check(len(set(x[0] for x in a[2]))==expected,f'physical identities not unique: {class_id}')
        identity_order[class_name]=[x[0] for x in a[2]]
        for old,new in zip(a[2],b[2]):
            check(old[1]==new[1],f'old/current recover request differs: {old[3].parent.name}')
            old_phase=old[2]['result']['analysis']['execution']['usage']; new_phase=new[2]['result']['analysis']['execution']['usage']
            check(all(old_phase[k]==new_phase[k] for k in USAGE),f'analysis-phase usage differs: {old[3].parent.name}')
            check(old[0]==new[0],f'old/current method identity differs: {old[3].parent.name}')
            oldrep=old[2]['result']['report']; newrep=new[2]['result']['report']
            eq={field:oldrep[field]==newrep[field] for field in FIELDS}
            check(all(eq.values()),f'semantic field mismatch: {old[3].parent.name} {eq}')
            delta={k:newrep['execution']['usage'][k]-oldrep['execution']['usage'][k] for k in USAGE}
            key=(class_name,old[3].name)
            observations[key]=(delta,eq,old[2],new[2])
    check(call_count==90,f'command count {call_count} != 90')
    aggregate={k:sum(v[0][k] for v in observations.values()) for k in USAGE}
    check(aggregate==summary['counted_usage_delta_sum'], 'recomputed aggregate != summary aggregate')
    check(aggregate['analysis_steps']==44 and all(v==0 for k,v in aggregate.items() if k!='analysis_steps'),f'unexpected aggregate: {aggregate}')
    check(diffs==[], 'semantic_differences.json is nonempty')
    check(summary['semantic_fields_exact_equal_for_all_methods'] is True, 'summary semantic equality claim false')
    actual_changed=[]
    for (cls,pinname),(delta,eq,old,new) in observations.items():
        if any(delta[k] for k in USAGE): actual_changed.append((cls,pinname,delta))
    expected={'Guarded':{'20-syncThrowsCatching-eb2a108925':13,'21-secondInitFailsCatching-a4df3c6513':13,'22-suppressedCatching-9400b40d93':18}}
    got={(c,p):d['analysis_steps'] for c,p,d in actual_changed}
    check(got=={(c,p):v for c,entries in expected.items() for p,v in entries.items()},f'unexpected per-method deltas: {got}')
    for _,_,d in actual_changed: check(all(v==0 for k,v in d.items() if k!='analysis_steps'), f'non-analysis delta in {d}')
    # Validate the guard/scanner dependency pins and class pins from the collector manifest.
    for d in build['dependencies'].values():
        p=Path(d['path']); check(p.is_file() and p.stat().st_size==d['bytes'] and sha(p)==d['sha256'],f'dependency pin mismatch: {p}')
    rootpins=json.loads(Path('/private/tmp/jarde-p5-billing-delta-audit-luna-v2/pins.json').read_text())
    for cp in rootpins['classes']:
        p=Path(cp['path']); check(p.is_file() and sha(p)==cp['sha256'],f'class pin mismatch: {p}')
    return {
       'status':'accepted_with_evidence_limit', 'commands_recomputed':call_count,'physical_methods_recomputed':len(observations),
       'old_current_requests_exactly_equal':True, 'all_15_report_usage_dimensions_present_and_recomputed':True,
       'analysis_usage_15_dimensions_present_and_equal':True, 'semantic_fields_exact_equal':True,'semantic_differences':0,
       'aggregate_report_usage_delta':aggregate,'changed_method_analysis_steps':{f'{c}.{p}':d['analysis_steps'] for c,p,d in actual_changed},
       'cli_build_receipt_dependency_class_pins_verified':True,
       'root_path':str(ROOT),'root_tree_sha256':canonical_digest_tree(ROOT),
       'limitations':['CLI recovery responses report stage completion and recovered regions, but do not serialize canonical CFG edges/blocks; therefore this audit does not claim a direct CFG edge-count reconstruction of the charged scans. The +44 is independently recomputed from the 43 report.execution.usage pairs (13+13+18).']
    }

if __name__=='__main__':
    result=main(); print(json.dumps(result,ensure_ascii=False,indent=2))
