# Private candidate: proved if-arm loop-entry origins

This bundle is a static implementation candidate for OpenSpec task 2.1 and the build-local portion of task 2.2. It has not been compiled or run. The production source is a private copy; no shared repository file was changed.

`changes.patch` adds a narrow parent-If origin proof. It accepts only a nonempty arm whose first child is a one-block `Straight`, whose block has exactly one SSA instruction decoded as `Operation::Transfer`, and whose immediately following child is a `Loop` with a different actual header. The complete canonical outgoing edge set for that gateway must contain exactly one `Normal` edge to that header. It adds the derived transfer origin to the emitted `If`; it does not alter Region/CFG facts, loop gateway/latch bookkeeping, or Java text. The existing terminal-if-join proof now calls the same exact-edge helper, preserving its full-edge-list charge and poll.

The internal test uses the actual original class plus two fixture paths agreed with the fixture agent. It expects the original `goto` and a shifted `goto_w` candidate to prove from each input's actual Region and Code facts; an effect-prefixed gateway must refuse. It directly tests IrEdges exhaustion, IrItems exhaustion, and pre-cancellation at the transfer BCI with charged usage retained. It also checks that the full reports are produced and the derived transfer maps onto the `if (` presentation. The public transaction/output/map-stop coverage is assigned to the separate public-test draft.

At review time the fixture paths were not yet present in the shared tree, so this candidate cannot be compiled until the fixture agent's files are integrated. The supplied control hashes in `pins.json` are agent-reported, not independently rehashed. No test result is claimed. The control byte layouts must still be validated by the root's reader/IR/JVM gates; in particular they must remain real standalone class files.

The test covers ordinary `Region::If`. The implementation also uses the same helper for `Region::CompoundIf`, whose builder emits the same `StmtKind::If`; no compound-specific positive fixture is claimed. This remains a point for root review if design intends to exclude compound conditions.

Pinned inputs and candidate hashes are in `pins.json`. `base/` is the shared `build.rs` snapshot at the recorded SHA; `candidate/` contains the sole private modified Rust source. Changes to the shared source since the snapshot must be reviewed before applying the patch.
