import sys,subprocess,json,hashlib,importlib.util,os,shutil
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path(__file__).parent;RAW=OUT/'raw';assert not RAW.exists();RAW.mkdir()
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
GUARD=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py';SCAN=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
assert pin(GUARD)['sha256']=='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33' and pin(SCAN)['sha256']=='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
g=load(GUARD,'fmt_guard');s=load(SCAN,'fmt_scan');g.ROOT=ROOT;g.OUT=RAW;g.target_bytes=lambda:s.target_bytes(ROOT);g.command_stream=pin;g.expected_test_summaries=lambda i,b:None
env={k:v for k,v in os.environ.items() if k not in ['RUST_MIN_STACK','CARGO_TARGET_DIR','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH']};env.update(g.ENV_VALUES)
paths=['crates/jarde-java/src/build.rs','crates/jarde-reader/src/classfile.rs','tests/p3_if_loop_entry_origins.rs'];assert all((ROOT/p).is_file() for p in paths)
assert not (ROOT/'target').exists() and shutil.disk_usage(ROOT).free>=5*1024**3
def sources():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','src','crates','tests','Cargo.toml','Cargo.lock'],cwd=ROOT).split(b'\0')
 return {os.fsdecode(n):pin(ROOT/os.fsdecode(n)) for n in sorted(set(names)-{b''}) if (ROOT/os.fsdecode(n)).is_file()}
r={'status':'running','guard':pin(GUARD),'scanner':pin(SCAN),'formatter':pin(Path(shutil.which('rustfmt')).resolve()),'source_before':sources(),'commands':[],'allowed_format_paths':paths}
try:
 row=g.run_command(1,['rustfmt','--edition','2024',*paths],env);r['commands'].append(row);assert row['exit_code']==0 and row['guard_stop'] is None
 r['source_after']=sources();changed=sorted(k for k in r['source_before'].keys()|r['source_after'].keys() if r['source_before'].get(k)!=r['source_after'].get(k));assert set(changed)<=set(paths);r['changed_paths']=changed;r['status']='root_guarded_format_complete'
except Exception as e:r['status']='failed';r['error']=repr(e);raise
finally:
 row=g.run_command(len(r['commands'])+1,['cargo','clean'],env);r['commands'].append(row);r['target_absent']=not (ROOT/'target').exists();assert row['exit_code']==0 and r['target_absent'];(OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'changed_paths':r.get('changed_paths'),'target_absent':r['target_absent']}))
