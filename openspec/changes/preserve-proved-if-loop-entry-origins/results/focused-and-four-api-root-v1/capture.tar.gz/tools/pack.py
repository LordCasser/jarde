from pathlib import Path
import hashlib,json,tarfile,io,stat
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
TMP=Path('/private/tmp')
DEST=ROOT/'openspec/changes/preserve-proved-if-loop-entry-origins/results/focused-and-four-api-root-v1'
ROOTS=[]
for v in range(1,5):
 ROOTS.extend([(TMP/f'jarde-if-loop-entry-focused-root-v{v}-20261019',f'focused/v{v}'),(TMP/f'jarde-if-loop-entry-focused-prep-root-v{v}-20261019',f'commands/v{v}')])
for v in range(1,4): ROOTS.append((TMP/f'jarde-if-loop-entry-format-root-v{v}-20261019',f'format/v{v}'))
ROOTS.extend([(TMP/'jarde-if-loop-entry-four-api-root-v1-20261019','four-api'),(TMP/'jarde-looprestore2-origin-rebind-prep-luna-v2-20261019','four-api-tools'),(TMP/'jarde-if-loop-entry-fixture-root-v1-20261019','fixture-review'),(TMP/'jarde-if-loop-entry-adversarial-review-luna-v1-20261019','adversarial'),(TMP/'jarde-if-loop-entry-builder-stop-luna-v3-20261019','public-stop-prep'),(TMP/'jarde-proved-if-loop-entry-origins-impl-luna-v1-20261019','implementation/v1'),(TMP/'jarde-proved-if-loop-entry-origins-impl-luna-v2-20261019','implementation/v2')])
def pin(p):
 b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert not DEST.exists() and not (ROOT/'target').exists()
payload=[];excluded=[]
for base,prefix in ROOTS:
 assert base.is_dir()
 for p in sorted(base.rglob('*')):
  assert not p.is_symlink(),str(p)
  if not p.is_file():continue
  assert '__pycache__' not in p.parts and p.suffix!='.pyc'
  if p.name=='candidate-cli':excluded.append(pin(p));continue
  b=p.read_bytes();payload.append((prefix+'/'+p.relative_to(base).as_posix(),p,b))
payload.append(('tools/pack.py',Path(__file__),Path(__file__).read_bytes()))
assert len({x[0] for x in payload})==len(payload)
inv={'schema':'if-loop-entry-focused-four-api-archive-v1','payload_members':len(payload),'members':[{'path':n,'source':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':stat.S_IMODE(p.stat().st_mode)} for n,p,b in payload],'excluded_frozen_cli_binaries':excluded}
DEST.mkdir(parents=True)
(DEST/'inventory.json').write_text(json.dumps(inv,ensure_ascii=False,indent=2)+'\n')
with tarfile.open(DEST/'capture.tar.gz','w:gz') as t:
 for n,p,b in payload:
  x=tarfile.TarInfo(n);x.size=len(b);x.mode=stat.S_IMODE(p.stat().st_mode);t.addfile(x,io.BytesIO(b))
 b=(DEST/'inventory.json').read_bytes();x=tarfile.TarInfo('ARCHIVE_INVENTORY.json');x.size=len(b);x.mode=0o644;t.addfile(x,io.BytesIO(b))
with tarfile.open(DEST/'capture.tar.gz','r:gz') as t:
 assert len(t.getmembers())==len(payload)+1
 for item in inv['members']:
  b=t.extractfile(item['path']).read();assert b==Path(item['source']).read_bytes();assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256'] and t.getmember(item['path']).mode==item['mode']
 assert json.loads(t.extractfile('ARCHIVE_INVENTORY.json').read())==inv
review={'status':'root_reopened_all_payload_bytes_and_modes','archive':pin(DEST/'capture.tar.gz'),'payload_members':len(payload),'excluded':excluded,'scope':'Actual focused failures and successful resumes, actual four CLI API calls, source-only correction review. No fresh native or own CI acceptance claimed here.'}
(DEST/'root-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review))
