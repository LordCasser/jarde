# Adversarial review: proved if-arm nested-loop entry origin

Read-only static review of the current production source, root public test, and this OpenSpec change. No shared files were changed; no Cargo/JDK/CLI/Git/network commands were run. This is a static review, not runtime acceptance.

## Findings

The implementation matches the narrow source-only boundary. `nonempty_if_nested_loop_entry_transfer` (`crates/jarde-java/src/build.rs`) accepts only a `Sequence` whose first child is one `Straight` region containing one canonical block and whose immediate next child is a `Loop`. It rejects same-block and clone identities, requires exactly one SSA instruction mapped to `Operation::Transfer`, then requires the complete outgoing edge set to be exactly one `Normal` edge to that loop's actual header. It bills the canonical-edge scan as `IrEdges`, polls, and bills the new origin as one `IrItems` before returning the physical BCI.

The ordinary `Region::If` invokes the helper only after building each arm and only when that arm emitted statements. It adds the returned BCI as a derived origin on the `StmtKind::If`; it changes no text, operations, Region ownership, or loop metadata. The old empty-arm rule remains on its existing branch. The compound-if path is not changed. `loop_region` continues to fold `gateway_origins` onto the loop statement; the entry helper does not modify that field. The existing latch-oriented consumers still constrain gateway origins as before, so no new coupling to loop latch proof was found.

The direct real-IR test has two positive inputs (the original `goto` and the `goto_w` control), one negative effect-prefix input, and direct-helper checks for an insufficient `IrEdges` limit, an `IrItems` stop, and pre-cancellation. Cancellation is checked before edge charging, so its expected `IrEdges` usage is zero; it does not demonstrate a partially charged scan. The exception-edge test elsewhere in the same block exercises `nonempty_if_join_transfer` on a different fixture; it does not exercise the new nested-loop-entry helper. Thus extra/exceptional gateway exits, a non-adjacent loop child, and clone identities are guarded in code but lack direct negative controls. This is a coverage gap, not a demonstrated implementation bug.

The public test verifies class and JAR inputs under default/all evidence, exact whole-class text, structured body, exact method identity, every physical BCI and UTF-8 span, and BCI 8 as a derived origin on the existing BCI 5 `if` span while retaining BCI 17. Its pre-cancelled request checks public stop propagation. It does not exercise a budget/cancellation stop *inside the new helper through Builder*: the unit tests call the helper directly. Since the helper returns before the `If` is pushed and the error propagates through `?`, the stop path is statically consistent with the Builder's method-level failure path; an end-to-end budget stop at the proof site is not established by these tests.

OpenSpec scope is correctly narrow: it excludes arbitrary goto mapping, DEX, text changes, Region/canonical changes, and broad CF08 closure. The added test coverage supports the original and width-variant positive and effect-prefix refusal; it does not yet instantiate every refusal scenario named in the requirement.

## Pin summary

Exact source byte lengths, SHA-256 pins, and line markers are in `pins.json`. No runtime result is inferred from these source observations.
