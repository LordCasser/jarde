# TestLoopRestore2 final four-API origin rebind (preparation only)

This private collector/reviewer pair is ready for the root agent to run after the final CLI build receipt exists. It has not run the CLI, a JDK, Cargo, or tests. Invoke the collector with a frozen CLI, its accepted build review, and a new output directory outside the workspace:

```sh
python3 -B collect_rebind.py --cli /private/tmp/<final-cli> --cli-build /private/tmp/<accepted-cli-build-review.json> --out /private/tmp/<new-rebind-capture>
python3 -B review_rebind.py /private/tmp/<new-rebind-capture>/execution.json --out /private/tmp/<new-rebind-capture>/review.json
```

The collector pins the exact CLI bytes and requires its accepted build review to bind the same path and digest. It replays the four original `class-source` command lines directly from the accepted baseline receipt, changing only argv element zero to that CLI: class/JAR input crossed with default/all evidence. It uses the accepted baseline’s existing 30-second cwd wrapper, workspace source-closure and target guards, empty cwd/sourcepath, and pinned command-stream capture helpers. It requires unchanged repository sources and helper/tool/JDK pins before and after. No compilation or target method invocation occurs in this rebind.

For each API report, comparison recursively removes `usage` values and removes only `methods[].outcome.report.source_map`; every other JSON field must equal the corresponding accepted baseline report. The complete Java source must remain byte-for-byte equal. This exact equality is the condition for reusing the accepted eight successful Jarde whole-source compiler legs; the two original JADX full-source compilation failures remain in the baseline and are not retried.

The map gate derives the selected segment from the pinned baseline method report: it must be the unique parent `if` segment with primary BCI 5 and UTF-8 byte span 208..269. For this fixed input it requires the current map to equal the baseline map with exactly one `Derived` BCI 8 origin added to that segment. Its position in the `derived` list may vary because that list preserves first-appearance order; deleting that one new ref must restore the complete baseline map, including the order of every preexisting origin. All segments, bounds, primaries, and other derived origins (including the existing BCI 17 and the false-condition BCI 5 evidence) must remain exact. It independently verifies all references are physical and each requested map covers all ten BCIs with valid UTF-8 boundaries.

The implementation reuses the accepted baseline’s pinned compare/source-closure, guard, target-size scanner, physical class parser, and runtime wrapper. It introduces no product code or generic map framework. The fixed Raung class/JAR, baseline report, collector, review, and helper pins are in `pins.json`. The selected byte span is an assertion about this accepted fixture, not a reusable region-recognition rule.
