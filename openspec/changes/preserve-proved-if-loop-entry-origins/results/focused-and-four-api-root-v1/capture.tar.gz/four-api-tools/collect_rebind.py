#!/usr/bin/env python3
"""Capture four final-CLI TestLoopRestore2 API reports and verify a single source-map origin addition."""
from __future__ import annotations
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASE = Path('/private/tmp/jarde-looprestore2-baseline-root-v1-20261019')
BASE_RECEIPT = BASE / 'execution.json'
BASE_SHA = 'dbd183d84d4f3992046db3424e3419aee09c9d6a69aac5e4d5998169bc01a46f'
BASE_REVIEW = BASE / 'root-review.json'
BASE_REVIEW_SHA = '7368d781effad8647a46738113e30e3b3a3b3947c416602c019a77588a14993f'
BASE_COLLECTOR = BASE / 'collector.py'
BASE_COLLECTOR_SHA = '093118528661bf15b11e45050922ca4872be7bfdd6a4f11ff5f3c032b32b4af1'
ORIGINAL_CLASS = BASE / 'input/loops/TestLoopRestore2.class'
ORIGINAL_CLASS_SHA = '4fd1503499a049efa8e736a98de4339b6504973f80208987ed0774073df9c447'
ORIGINAL_JAR = BASE / 'input/original.jar'
ORIGINAL_JAR_SHA = '89d1f82e7a1c46db40ddf1631c750817c0e1f920a06794dd0b4f2a7d64a9ac48'
RUNTIME_WRAPPER = BASE / 'runtime-bound-cwd.py'
RUNTIME_WRAPPER_SHA = 'bc917ec08e07ed462c18958f9a0d3b064b7d5bba3adc5fa41d9db49ff6c3de46'
INTERNAL = 'loops/TestLoopRestore2'
METHOD = ('test', '([I[I)V')
EXPECTED_BCI8 = 8
EXPECTED_PARENT_PRIMARY_BCI = 5
EXPECTED_PARENT_SPAN = (208, 269)
EXPECTED_PHYSICAL_BCIS = [0, 1, 2, 5, 8, 11, 14, 17, 20, 23]


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load pinned helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def pin(path: Path) -> dict:
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def accepted_cli_receipt(path: Path, cli: Path) -> dict:
    receipt = json.loads(path.read_text(encoding='utf-8'))
    if not str(receipt.get('status', '')).startswith('root_accepted_'):
        raise RuntimeError('CLI build receipt is not root-accepted')
    info = receipt.get('cli') or receipt.get('final_cli')
    if not isinstance(info, dict):
        raise RuntimeError('accepted CLI build receipt has no cli/final_cli binding')
    bound_path = Path(info.get('path', '')).resolve(strict=True)
    digest = info.get('sha256')
    if bound_path != cli or digest != sha(cli):
        raise RuntimeError('accepted CLI receipt does not bind the supplied frozen CLI')
    if info.get('bytes') is not None and info['bytes'] != cli.stat().st_size:
        raise RuntimeError('CLI size differs from accepted build receipt')
    return receipt


def normalize(value, path=()):
    if isinstance(value, dict):
        is_method_report = (len(path) >= 4 and path[-1] == 'report' and path[-2] == 'outcome'
                            and isinstance(path[-3], int) and path[-4] == 'methods')
        out = {}
        for key, item in value.items():
            if key == 'usage' or (is_method_report and key == 'source_map'):
                continue
            out[key] = normalize(item, path + (key,))
        return out
    if isinstance(value, list):
        return [normalize(item, path + (index,)) for index, item in enumerate(value)]
    return value


def report_method(api: dict) -> dict:
    matches = []
    for method in api.get('methods', []):
        item = method.get('item', {})
        name = item.get('name', {}).get('escaped')
        desc = item.get('descriptor', {}).get('escaped')
        if (name, desc) == METHOD:
            matches.append(method)
    if len(matches) != 1:
        raise RuntimeError(f'API has {len(matches)} copies of the exact target method')
    result = matches[0].get('outcome', {}).get('report')
    if not isinstance(result, dict):
        raise RuntimeError('target method has no structured report')
    return result


def ref_bci(ref) -> int | None:
    return ref.get('bci') if isinstance(ref, dict) else None


def selected_parent_segment(source_text: str, source_map: dict) -> dict:
    matches = []
    raw = source_text.encode('utf-8')
    for segment in source_map.get('segments', []):
        origin = segment.get('origin', {})
        primary = origin.get('primary', {})
        start, end = segment.get('start'), segment.get('end')
        if ref_bci(primary) != EXPECTED_PARENT_PRIMARY_BCI or type(start) is not int or type(end) is not int:
            continue
        if not (0 <= start <= end <= len(raw)):
            continue
        node = raw[start:end].decode('utf-8', 'strict')
        if node.lstrip().startswith('if (') and 'do {' in node and '} while (' in node:
            matches.append(segment)
    if len(matches) != 1:
        raise RuntimeError(f'expected one baseline parent-if segment for primary BCI 5, found {len(matches)}')
    chosen = matches[0]
    if (chosen['start'], chosen['end']) != EXPECTED_PARENT_SPAN:
        raise RuntimeError('baseline parent-if UTF-8 span differs from accepted 208..269 source span')
    return chosen


def baseline_parent_info(base_method_report: dict) -> tuple[dict, int]:
    source_text = base_method_report.get('text')
    source_map = base_method_report.get('source_map')
    if not isinstance(source_text, str) or not isinstance(source_map, dict):
        raise RuntimeError('baseline target method lacks source text/map')
    selected = selected_parent_segment(source_text, source_map)
    idx = source_map['segments'].index(selected)
    origin = selected.get('origin', {})
    derived = origin.get('derived')
    if not isinstance(derived, list) or any(ref_bci(ref) == EXPECTED_BCI8 for ref in derived):
        raise RuntimeError('baseline selected parent if has invalid/BCI-8 derived origins')
    return selected, idx


def validate_map_delta(base_report: dict, current_report: dict, physical_bcis: list[int]) -> dict:
    base_map, current_map = base_report.get('source_map'), current_report.get('source_map')
    text = current_report.get('text')
    if not isinstance(base_map, dict) or not isinstance(current_map, dict) or not isinstance(text, str):
        raise RuntimeError('missing source map or method text')
    selected_base, selected_index = baseline_parent_info(base_report)
    if len(current_map.get('segments', [])) != len(base_map.get('segments', [])):
        raise RuntimeError('source-map segment count changed')
    current_segments = current_map['segments']
    if selected_index >= len(current_segments):
        raise RuntimeError('selected parent-if segment disappeared')
    selected_current = current_segments[selected_index]
    if (selected_current.get('start'), selected_current.get('end')) != (selected_base.get('start'), selected_base.get('end')):
        raise RuntimeError('selected parent-if source span changed')
    if selected_current.get('origin', {}).get('primary') != selected_base.get('origin', {}).get('primary'):
        raise RuntimeError('selected parent-if primary origin changed')
    added_refs = []
    for segment_index, segment in enumerate(current_segments):
        origin = segment.get('origin', {})
        primary = origin.get('primary')
        if ref_bci(primary) == EXPECTED_BCI8:
            raise RuntimeError('BCI 8 was assigned as a primary origin')
        for derived_index, ref in enumerate(origin.get('derived', [])):
            if ref_bci(ref) == EXPECTED_BCI8:
                added_refs.append((segment_index, derived_index, ref))
    if len(added_refs) != 1 or added_refs[0][0] != selected_index:
        raise RuntimeError('expected exactly one new BCI 8 derived ref on the proved parent-if segment')
    _, derived_index, added_ref = added_refs[0]
    expected_added = dict(selected_base['origin']['primary'])
    expected_added['bci'] = EXPECTED_BCI8
    expected_added['provenance'] = 'Derived'
    if added_ref != expected_added:
        raise RuntimeError('new derived BCI 8 origin identity differs from the proved parent method origin')
    without_added = json.loads(json.dumps(current_map))
    del without_added['segments'][selected_index]['origin']['derived'][derived_index]
    if without_added != base_map:
        raise RuntimeError('removing the one BCI 8 derived ref does not restore the entire baseline map')
    encoded = text.encode('utf-8')
    boundaries = {0}
    count = 0
    for char in text:
        count += len(char.encode('utf-8'))
        boundaries.add(count)
    mapped = set()
    for segment in current_map.get('segments', []):
        start, end = segment.get('start'), segment.get('end')
        if type(start) is not int or type(end) is not int or not (0 <= start <= end <= len(encoded)):
            raise RuntimeError('source map segment has invalid byte bounds')
        if start not in boundaries or end not in boundaries:
            raise RuntimeError('source map segment splits a UTF-8 code point')
        origin = segment.get('origin', {})
        refs = [origin.get('primary'), *origin.get('derived', [])]
        for ref in refs:
            bci = ref_bci(ref)
            if bci not in physical_bcis:
                raise RuntimeError(f'source map references nonphysical BCI {bci!r}')
            if bci == EXPECTED_BCI8:
                if ref.get('provenance') != 'Derived':
                    raise RuntimeError('BCI 8 is not marked Derived')
            mapped.add(bci)
    if sorted(mapped) != sorted(physical_bcis):
        raise RuntimeError(f'physical map coverage is {len(mapped)}/{len(physical_bcis)}, expected 10/10')
    return {'physical_bcis': physical_bcis, 'mapped_bcis': sorted(mapped),
            'coverage': f'{len(mapped)}/{len(physical_bcis)}',
            'parent_segment': {'start': EXPECTED_PARENT_SPAN[0], 'end': EXPECTED_PARENT_SPAN[1],
                               'primary_bci': EXPECTED_PARENT_PRIMARY_BCI,
                               'derived_bcis': [ref_bci(x) for x in next(s for s in current_map['segments']
                                   if s['start'] == EXPECTED_PARENT_SPAN[0] and s['end'] == EXPECTED_PARENT_SPAN[1])['origin']['derived']]}}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--cli', type=Path, required=True, help='frozen final candidate CLI binary')
    ap.add_argument('--cli-build', type=Path, required=True, help='accepted build review binding that CLI')
    ap.add_argument('--out', type=Path, required=True, help='new empty evidence directory')
    ap.add_argument('--root', type=Path, default=ROOT)
    a = ap.parse_args()
    root = a.root.resolve(strict=True)
    if root != ROOT.resolve():
        raise SystemExit('workspace root differs from the pinned root')
    cli = a.cli.resolve(strict=True)
    cli_build = a.cli_build.resolve(strict=True)
    out = a.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing existing output directory: {out}')
    if out == root or root in out.parents:
        raise SystemExit('rebind output must be outside the product workspace')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('workspace target must be absent before capture')
    if shutil.disk_usage(root).free < 5 * 1024**3:
        raise SystemExit('5 GiB free-space guard failed')
    if sha(BASE_RECEIPT) != BASE_SHA or sha(BASE_REVIEW) != BASE_REVIEW_SHA or sha(BASE_COLLECTOR) != BASE_COLLECTOR_SHA:
        raise SystemExit('accepted original baseline receipt/review/collector pin mismatch')
    base = json.loads(BASE_RECEIPT.read_text(encoding='utf-8'))
    accepted_review = json.loads(BASE_REVIEW.read_text(encoding='utf-8'))
    if accepted_review.get('status') != 'root_accepted_original_raung_baseline_with_explicit_bci8_gap':
        raise SystemExit('original baseline is not root-accepted')
    if sha(ORIGINAL_CLASS) != ORIGINAL_CLASS_SHA or sha(ORIGINAL_JAR) != ORIGINAL_JAR_SHA:
        raise SystemExit('frozen baseline class/JAR changed')
    receipt = accepted_cli_receipt(cli_build, cli)
    cli_pin = pin(cli)

    base_cells = {(cell['input_form'], cell['evidence']): cell for cell in base['api_cells']}
    if set(base_cells) != {('class', 'default'), ('class', 'all'), ('jar', 'default'), ('jar', 'all')}:
        raise SystemExit('accepted baseline API cell set differs from the exact four requested cells')
    if len(base['api_cells']) != 4 or len(base['generated_source_compiles']) != 10:
        # 8 Jarde and 2 JADX compile attempts are the accepted reuse boundary.
        raise SystemExit('accepted baseline compile/API counts differ from the frozen evidence')
    for cell in base['api_cells']:
        if cell.get('exit_code') != 0 or not isinstance(cell.get('raw_report'), dict):
            raise SystemExit('accepted baseline has a failed/missing API report')
        method = report_method(cell['raw_report'])
        if not isinstance(method.get('text'), str):
            raise SystemExit('baseline target method source text missing')
        baseline_parent_info(method)

    baseline_collector = load(BASE_COLLECTOR, 'looprestore2_baseline_collector')
    compare_path = root / baseline_collector.COMPARE_REL
    guard_path = root / baseline_collector.GUARD_REL
    scanner_path = root / baseline_collector.SCANNER_REL
    manifest_path = root / baseline_collector.JDK_MANIFEST_REL
    parser_path = baseline_collector.PARSER
    helper_pins = {
        compare_path: baseline_collector.COMPARE_SHA256,
        guard_path: baseline_collector.GUARD_SHA256,
        scanner_path: baseline_collector.SCANNER_SHA256,
        manifest_path: baseline_collector.JDK_MANIFEST_SHA256,
        parser_path: baseline_collector.PARSER_SHA256,
        RUNTIME_WRAPPER: RUNTIME_WRAPPER_SHA,
    }
    for path, expected in helper_pins.items():
        if sha(path) != expected:
            raise SystemExit(f'pinned API guard helper changed: {path}')
    compare = load(compare_path, 'looprestore2_rebind_compare')
    guard = load(guard_path, 'looprestore2_rebind_guard')
    scanner = load(scanner_path, 'looprestore2_rebind_scanner')
    jdks, jdk_record = compare.configured_jdks(manifest_path, baseline_collector.JDK_MANIFEST_SHA256)
    physical = load(parser_path, 'looprestore2_rebind_physical')
    physical_class = physical.parse_class_file(ORIGINAL_CLASS.read_bytes())
    method_facts = [m for m in physical_class.get('methods', []) if (m.get('name'), m.get('descriptor')) == METHOD]
    if len(method_facts) != 1 or method_facts[0].get('code', {}).get('bcis') != EXPECTED_PHYSICAL_BCIS:
        raise SystemExit('pinned original physical method census differs from the accepted ten-BCI method')
    code_hex = method_facts[0]['code']['code_hex']
    if int(code_hex[EXPECTED_BCI8 * 2:EXPECTED_BCI8 * 2 + 2], 16) not in (0xa7, 0xc8):
        raise SystemExit('BCI 8 is not an unconditional goto/goto_w in the original method')

    source_before = compare.source_closure(root)
    empty_cwd = out / 'empty-cwd'
    empty_sourcepath = out / 'empty-sourcepath'
    raw_dir = out / 'raw'
    raw_dir.mkdir(parents=True)
    empty_cwd.mkdir()
    empty_sourcepath.mkdir()
    wrapper_copy = out / RUNTIME_WRAPPER.name
    shutil.copy2(RUNTIME_WRAPPER, wrapper_copy)
    if sha(wrapper_copy) != RUNTIME_WRAPPER_SHA:
        raise RuntimeError('copied 30-second runtime wrapper differs from pinned source')
    guard.ROOT = root
    guard.OUT = raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, stdout: None

    tool_paths = [cli, cli_build, BASE_RECEIPT, BASE_REVIEW, BASE_COLLECTOR,
                  ORIGINAL_CLASS, ORIGINAL_JAR, compare_path, guard_path, scanner_path,
                  manifest_path, parser_path, RUNTIME_WRAPPER, wrapper_copy]
    external_before = {'files': [compare.pin(path) for path in tool_paths],
                       'jdk_tools': {f'{leg}_{tool}': compare.pin(path)
                                     for leg, config in jdks.items() for tool, path in config['tools'].items()}}
    report = {
        'schema': 'test-looprestore2-origin-rebind-four-api-v1', 'status': 'running',
        'root': str(root), 'out': str(out), 'cli': cli_pin,
        'accepted_cli_build': compare.pin(cli_build), 'accepted_cli_build_status': receipt['status'],
        'baseline_receipt': compare.pin(BASE_RECEIPT), 'baseline_review': compare.pin(BASE_REVIEW),
        'baseline_cli_sha256': base.get('cli_sha256_expected'),
        'original_class': compare.pin(ORIGINAL_CLASS), 'original_jar': compare.pin(ORIGINAL_JAR),
        'physical_method': {'identity': METHOD, 'bcis': EXPECTED_PHYSICAL_BCIS,
                            'bci8_opcode': int(code_hex[EXPECTED_BCI8 * 2:EXPECTED_BCI8 * 2 + 2], 16)},
        'guard_tools': {str(path): expected for path, expected in helper_pins.items()},
        'runtime_wrapper_timeout_seconds': 30, 'jdk': jdk_record,
        'source_pins_before': source_before, 'external_pins_before': external_before,
        'empty_cwd': str(empty_cwd), 'empty_sourcepath': str(empty_sourcepath),
        'commands': [], 'api_cells': [], 'notes': [
            'Exactly the four accepted class/JAR x default/all API calls are replayed; each argv is copied from the accepted baseline and only argv[0] is replaced by the frozen final CLI.',
            'No compilation or target-method invocation occurs in this rebind. Exact whole-source equality to the accepted baseline permits reuse of its eight successful Jarde whole-source compile records.',
            'Each current API JSON is compared to its baseline JSON after recursive usage removal and removal of only methods[].outcome.report.source_map; no other report differences are normalized.',
            'The source-map gate permits only one Derived BCI 8 on the unique baseline if segment (primary BCI 5, UTF-8 bytes 208..269); its derived-list position is unrestricted, and removing exactly that ref must restore the entire baseline map byte-for-byte in structure and ordering.'
        ]
    }
    compare.write_json(out / 'execution.json', report)
    rows = []
    try:
        for form, evidence in (('class', 'default'), ('class', 'all'), ('jar', 'default'), ('jar', 'all')):
            base_cell = base_cells[(form, evidence)]
            base_command = base['commands'][base_cell['command'] - 1]
            argv = list(base_command['effective_argv'])
            if not argv or Path(argv[0]).name != Path(base['cli']['path']).name:
                raise RuntimeError('baseline API argv does not begin with its accepted CLI path')
            argv[0] = str(cli)
            if argv[1:] != base_command['effective_argv'][1:]:
                raise RuntimeError('API argv changed beyond the candidate CLI path')
            env = compare.clean_env(dict(os.environ), jdks['javac23'])
            env.update(guard.ENV_VALUES)
            env.pop('RUST_MIN_STACK', None)
            wrapped = [sys.executable, '-B', str(wrapper_copy), '30', str(empty_cwd), *argv]
            row = guard.run_command(len(rows) + 1, wrapped, env)
            row['label'] = f'rebind-{form}-{evidence}'
            row['effective_argv'] = argv
            row['tool_leg'] = 'jarde-cli'
            rows.append(row)
            report['commands'] = rows
            if row['exit_code'] != 0 or row.get('guard_stop'):
                raise RuntimeError(f'final CLI API call failed/guard-stopped: {row}')
            stdout_path = Path(row['streams']['stdout']['path'])
            raw_bytes = stdout_path.read_bytes()
            api = json.loads(raw_bytes.decode('utf-8', 'strict'))
            raw_copy = out / 'reports' / form / evidence / 'report.json'
            raw_copy.parent.mkdir(parents=True, exist_ok=True)
            raw_copy.write_bytes(raw_bytes)
            base_api = base_cell['raw_report']
            if normalize(api) != normalize(base_api):
                raise RuntimeError(f'normalized complete API report differs from accepted baseline: {form}/{evidence}')
            if api.get('text') != base_api.get('text'):
                raise RuntimeError(f'complete Java source differs from accepted baseline: {form}/{evidence}')
            base_method, current_method = report_method(base_api), report_method(api)
            map_audit = validate_map_delta(base_method, current_method, EXPECTED_PHYSICAL_BCIS)
            cell = {'input_form': form, 'evidence': evidence, 'command': row['index'], 'exit_code': row['exit_code'],
                    'input': compare.pin(Path(base_command['effective_argv'][3])),
                    'stdout': compare.pin(stdout_path), 'stderr': compare.pin(Path(row['streams']['stderr']['path'])),
                    'api_report': compare.pin(raw_copy), 'raw_report': api,
                    'normalized_report_matches_baseline': True, 'whole_source_matches_baseline': True,
                    'method_identity': METHOD, 'map_audit': map_audit}
            report['api_cells'].append(cell)
            compare.write_json(out / 'execution.json', report)

        source_after = compare.source_closure(root)
        external_after = {'files': [compare.pin(path) for path in tool_paths],
                          'jdk_tools': {f'{leg}_{tool}': compare.pin(path)
                                        for leg, config in jdks.items() for tool, path in config['tools'].items()}}
        report['source_pins_after'] = source_after
        report['source_unchanged'] = source_after == source_before
        report['external_pins_after'] = external_after
        report['external_inputs_unchanged'] = external_after == external_before
        report['empty_cwd_after'] = not any(empty_cwd.iterdir())
        report['empty_sourcepath_after'] = not any(empty_sourcepath.iterdir())
        report['target_absent'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
        report['counts'] = {'commands': len(rows), 'api_cells': len(report['api_cells']),
                            'source_maps_10_of_10': sum(c['map_audit']['coverage'] == '10/10' for c in report['api_cells']),
                            'compile_attempts_this_rebind': 0, 'target_method_runs_this_rebind': 0}
        if len(rows) != 4 or len(report['api_cells']) != 4 or report['counts']['source_maps_10_of_10'] != 4:
            raise RuntimeError('four API cells or four 10/10 maps were not completed')
        if not all((report['source_unchanged'], report['external_inputs_unchanged'], report['empty_cwd_after'],
                    report['empty_sourcepath_after'], report['target_absent'])):
            raise RuntimeError('source/tool/empty-directory/target guard failed')
        report['status'] = 'captured_pending_independent_review'
    except BaseException as exc:
        report['status'] = 'failed'
        report['error'] = repr(exc)
        raise
    finally:
        try:
            report['source_pins_after_finally'] = compare.source_closure(root)
            report['source_unchanged_finally'] = report['source_pins_after_finally'] == source_before
            final_external = {'files': [compare.pin(path) for path in tool_paths],
                              'jdk_tools': {f'{leg}_{tool}': compare.pin(path)
                                            for leg, config in jdks.items() for tool, path in config['tools'].items()}}
            report['external_pins_after_finally'] = final_external
            report['external_inputs_unchanged_finally'] = final_external == external_before
            report['target_absent_finally'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
            report['empty_cwd_after_finally'] = not any(empty_cwd.iterdir())
            report['empty_sourcepath_after_finally'] = not any(empty_sourcepath.iterdir())
            if not all((report['source_unchanged_finally'], report['external_inputs_unchanged_finally'], report['target_absent_finally'], report['empty_cwd_after_finally'], report['empty_sourcepath_after_finally'])):
                report['status'] = 'failed'
                report['finally_guard_error'] = 'final source/tool/target check failed'
        except BaseException as exc:
            report['status'] = 'failed'
            report['finally_guard_error'] = repr(exc)
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out / 'execution.json', report)
        shutil.copy2(__file__, out / 'collect_rebind.py')
    print(json.dumps({'status': report['status'], 'commands': len(rows),
                      'api_cells': len(report['api_cells']), 'source_maps_10_of_10': report.get('counts', {}).get('source_maps_10_of_10'),
                      'error': report.get('error')}))
    return 0 if report['status'] == 'captured_pending_independent_review' else 1


if __name__ == '__main__':
    raise SystemExit(main())
