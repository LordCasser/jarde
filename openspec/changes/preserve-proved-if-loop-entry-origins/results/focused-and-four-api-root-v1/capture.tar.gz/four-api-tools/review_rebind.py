#!/usr/bin/env python3
"""Independently reopen and validate a four-API final-CLI source-map rebind receipt."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path('/private/tmp/jarde-looprestore2-baseline-root-v1-20261019')
BASE_RECEIPT = BASE / 'execution.json'
BASE_SHA = 'dbd183d84d4f3992046db3424e3419aee09c9d6a69aac5e4d5998169bc01a46f'
BASE_REVIEW = BASE / 'root-review.json'
BASE_REVIEW_SHA = '7368d781effad8647a46738113e30e3b3a3b3947c416602c019a77588a14993f'
COLLECTOR = Path(__file__).with_name('collect_rebind.py')
COLLECTOR_SHA = 'e7a612b605e25ce65b52365c0f7fc2908f71d085b1b2a100edd1709008beeeb1'


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def load_collector():
    if sha(COLLECTOR) != COLLECTOR_SHA:
        raise RuntimeError('rebind collector pin mismatch')
    spec = importlib.util.spec_from_file_location('looprestore2_origin_rebind_collector', COLLECTOR)
    if spec is None or spec.loader is None:
        raise RuntimeError('cannot load pinned rebind collector')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('execution', type=Path)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    out = args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing existing review output: {out}')
    if sha(BASE_RECEIPT) != BASE_SHA or sha(BASE_REVIEW) != BASE_REVIEW_SHA:
        raise SystemExit('accepted original baseline receipt/review pin mismatch')
    baseline = json.loads(BASE_RECEIPT.read_text(encoding='utf-8'))
    baseline_review = json.loads(BASE_REVIEW.read_text(encoding='utf-8'))
    if baseline_review.get('status') != 'root_accepted_original_raung_baseline_with_explicit_bci8_gap':
        raise SystemExit('original baseline lacks root acceptance')
    current = json.loads(args.execution.read_text(encoding='utf-8'))
    if current.get('schema') != 'test-looprestore2-origin-rebind-four-api-v1' or current.get('status') != 'captured_pending_independent_review':
        raise SystemExit('rebind execution is not a complete capture')
    collector = load_collector()
    cells = {(c.get('input_form'), c.get('evidence')): c for c in current.get('api_cells', [])}
    baseline_cells = {(c['input_form'], c['evidence']): c for c in baseline['api_cells']}
    expected_cells = {('class', 'default'), ('class', 'all'), ('jar', 'default'), ('jar', 'all')}
    if set(cells) != expected_cells or set(baseline_cells) != expected_cells or len(current.get('commands', [])) != 4:
        raise SystemExit('four exact API cells/commands are required')
    if current.get('counts', {}).get('source_maps_10_of_10') != 4 or current.get('counts', {}).get('compile_attempts_this_rebind') != 0 or current.get('counts', {}).get('target_method_runs_this_rebind') != 0:
        raise SystemExit('rebind scope or four-map coverage summary differs')
    cli = Path(current['cli']['path']).resolve(strict=True)
    cli_build = Path(current['accepted_cli_build']['path']).resolve(strict=True)
    if sha(cli) != current['cli']['sha256'] or sha(cli_build) != current['accepted_cli_build']['sha256']:
        raise SystemExit('frozen CLI or accepted build receipt changed after capture')
    receipt = collector.accepted_cli_receipt(cli_build, cli)
    if receipt.get('status') != current.get('accepted_cli_build_status'):
        raise SystemExit('accepted CLI receipt status changed')
    for key in expected_cells:
        cell, base_cell = cells[key], baseline_cells[key]
        if cell.get('exit_code', 0) != 0 or cell.get('normalized_report_matches_baseline') is not True or cell.get('whole_source_matches_baseline') is not True:
            raise SystemExit(f'API report/source comparison not accepted: {key}')
        api = cell.get('raw_report')
        if not isinstance(api, dict) or collector.normalize(api) != collector.normalize(base_cell['raw_report']):
            raise SystemExit(f'complete normalized API JSON differs from baseline: {key}')
        if api.get('text') != base_cell['raw_report'].get('text'):
            raise SystemExit(f'whole Java source differs from baseline: {key}')
        source_map_audit = collector.validate_map_delta(
            collector.report_method(base_cell['raw_report']),
            collector.report_method(api), collector.EXPECTED_PHYSICAL_BCIS)
        if source_map_audit.get('coverage') != '10/10':
            raise SystemExit(f'physical map coverage is incomplete: {key}')
        command = current['commands'][cell['command'] - 1]
        base_command = baseline['commands'][base_cell['command'] - 1]
        argv = command.get('effective_argv', [])
        expected_argv = list(base_command.get('effective_argv', []))
        if not expected_argv or not argv or argv[0] != str(cli) or argv[1:] != expected_argv[1:]:
            raise SystemExit(f'API argv differs beyond the final CLI path: {key}')
        if command.get('exit_code') != 0 or command.get('guard_stop'):
            raise SystemExit(f'command failed or was guard-stopped: {key}')
        if cell.get('map_audit') != source_map_audit:
            raise SystemExit(f'stored map audit differs from recomputed audit: {key}')

    compiles = [item for item in baseline.get('generated_source_compiles', []) if item.get('kind') == 'jarde']
    if len(compiles) != 8 or any(item.get('exit_code') != 0 for item in compiles):
        raise SystemExit('baseline does not contain eight successful Jarde whole-source compiler legs')
    baseline_text_hashes = {sha(Path(cell['whole_source']['path'])) for cell in baseline['api_cells']}
    if len(baseline_text_hashes) != 1:
        raise SystemExit('the four accepted baseline whole-source artifacts are not byte-identical')
    expected_source_hash = next(iter(baseline_text_hashes))
    for item in compiles:
        files = item.get('source_files', [])
        if len(files) != 1 or files[0].get('sha256') != expected_source_hash:
            raise SystemExit('baseline Jarde compile did not consume the exact shared whole-source bytes')

    guards = ('source_unchanged', 'external_inputs_unchanged', 'empty_cwd_after',
              'empty_sourcepath_after', 'target_absent', 'source_unchanged_finally',
              'external_inputs_unchanged_finally', 'target_absent_finally',
              'empty_cwd_after_finally', 'empty_sourcepath_after_finally')
    if any(current.get(field) is not True for field in guards):
        raise SystemExit('source/tool/empty cwd/sourcepath/target guard failed')
    review = {
        'schema': 'test-looprestore2-origin-rebind-review-v1', 'status': 'accepted_four_api_origin_rebind',
        'execution': {'path': str(args.execution.resolve()), 'bytes': args.execution.stat().st_size,
                      'sha256': sha(args.execution)},
        'baseline': {'path': str(BASE_RECEIPT), 'sha256': BASE_SHA,
                     'root_review_sha256': BASE_REVIEW_SHA},
        'cli': current['cli'], 'accepted_cli_build': current['accepted_cli_build'],
        'api_cells': [{'input_form': form, 'evidence': evidence,
                       'normalized_full_json_matches_baseline': True,
                       'whole_java_source_matches_baseline': True,
                       'physical_bci_coverage': '10/10',
                       'map_delta': cells[(form, evidence)]['map_audit']}
                      for form, evidence in (('class', 'default'), ('class', 'all'), ('jar', 'default'), ('jar', 'all'))],
        'compile_reuse': {'baseline_jarde_whole_source_successes': 8,
                          'reused_without_recompile_because_java_bytes_match': True,
                          'jadx_failures_retained_from_baseline': 2},
        'scope': {'api_commands': 4, 'compiles_in_rebind': 0, 'target_method_runs': 0},
        'guards': {field: True for field in guards},
        'collector': {'path': str(COLLECTOR), 'sha256': COLLECTOR_SHA}
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': review['status'], 'api_cells': 4,
                      'maps_10_of_10': 4, 'output': str(out)}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
