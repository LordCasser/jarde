import json,subprocess
from pathlib import Path
p=Path(__file__).parent
a=json.loads((p/"argv.json").read_bytes())
with (p/"stdout.raw").open("xb") as so,(p/"stderr.raw").open("xb") as se:r=subprocess.run(a,stdout=so,stderr=se)
(p/"execution.json").write_text(json.dumps({"argv":a,"exit_code":r.returncode},indent=2)+"\n")
print(r.returncode)
raise SystemExit(r.returncode)
