#!/usr/bin/env python3
"""Create and byte-verify one explicit evidence archive (preparation only)."""
from __future__ import annotations
import argparse, gzip, hashlib, io, json, os, stat, tarfile
from pathlib import Path

TMP=Path('/private/tmp').resolve()
HERE=Path(__file__).resolve().parent
ROOT=Path('/Users/lordcasser/workspace/projects/jarde').resolve()
EXCLUDED_PARTS={'target','__pycache__','.pytest_cache','.mypy_cache','.ruff_cache','.cache','node_modules'}
A_DIRS=(
 ('baseline','jarde-testbreakwithlabel-baseline-root-v1-20261019'),
 ('prep','jarde-testbreakwithlabel-baseline-prep-luna-v3-20261019'),
 ('review-independent','jarde-testbreakwithlabel-baseline-review-luna-v4-20261019'),
 ('review-root','jarde-testbreakwithlabel-baseline-review-root-v2-20261019'),
 ('audit-failure-capture','jarde-testbreakwithlabel-audit-failure-capture-root-v1-20261019'),
 ('audit-execution','jarde-testbreakwithlabel-audit-execution-root-v2-20261019'),
 ('boolean-local-audit','jarde-testbreakwithlabel-boolean-local-audit-luna-v1-20261019'),
 ('fixed-audit','jarde-cf09-fixed-audit-luna-v1-20261019'),
 ('sequential-caseplan','jarde-cf09-sequential-loops-caseplan-luna-v1-20261019'),
 ('sequential-caseplan-review','jarde-cf09-sequential-loops-caseplan-review-root-v1-20261019'),
)
B_NATIVE='jarde-if-loop-entry-workspace-seed1-root-v1-20261019'
B_FAILED='jarde-if-loop-entry-own-ci-root-v1-20261019'
B_HISTORY=tuple(f'jarde-if-loop-entry-own-ci-root-v{i}-20261019' for i in range(2,7))
B_UNACCEPTED=('jarde-if-loop-entry-own-ci-root-v7-20261019','jarde-if-loop-entry-own-ci-root-v8-20261019')
B_ACCEPT_ARGV=('jarde-if-loop-entry-root-ci-acceptance-argv-v1-20261019','jarde-if-loop-entry-root-ci-acceptance-argv-v2-20261019','jarde-if-loop-entry-root-ci-acceptance-argv-v3-20261019')
B_TRANSPORT='jarde-if-loop-entry-ci-transport-root-v1-20261019'
B_TOOLS='jarde-if-loop-entry-native-own-ci-prep-luna-v2-20261019'
B_NAMED='jarde-if-loop-entry-final-ci-named-review-root-v1-20261019'
LICENSES=(
 ('upstream-fixture-licenses/JADX-LICENSE',ROOT/'tests/fixtures/cf08-if-loop-entry/licenses/JADX-LICENSE'),
 ('upstream-fixture-licenses/JADX-NOTICE',ROOT/'tests/fixtures/cf08-if-loop-entry/licenses/JADX-NOTICE'),
)

def need(ok:bool,msg:str)->None:
 if not ok: raise ValueError(msg)
def sha(data:bytes)->str:return hashlib.sha256(data).hexdigest()
def read_json(path:Path):return json.loads(path.read_bytes())
def mode(path:Path)->int:return stat.S_IMODE(path.stat().st_mode)
def safe(path:Path)->None:
 need(not path.is_symlink(),f'symlink refused: {path}')
def collect_tree(root:Path,arcroot:str,items:dict[str,tuple[Path,bytes,int]])->None:
 safe(root);need(root.is_dir(),f'missing directory: {root}')
 for p in [root,*sorted(root.rglob('*'))]:
  safe(p)
  rel=p.relative_to(root)
  if any(part in EXCLUDED_PARTS for part in p.parts):
   raise ValueError(f'cache/build path refused: {p}')
  if p.is_dir():
   name=arcroot if not rel.parts else arcroot+'/'+rel.as_posix()
   add(items,name,p,b'',mode(p),is_dir=True)
  elif p.is_file():
   data=p.read_bytes();name=arcroot+'/'+rel.as_posix();add(items,name,p,data,mode(p))
  else:raise ValueError(f'non-regular path refused: {p}')
def add(items,name,path,data,filemode,is_dir=False):
 need(name not in items,f'duplicate archive path: {name}')
 items[name]=(path,data,filemode)
def verify_a_inputs()->None:
 b=read_json(TMP/A_DIRS[0][1]/'execution.json')
 root=read_json(TMP/A_DIRS[0][1]/'root-review.json')
 review=read_json(TMP/A_DIRS[3][1]/'review.json')
 need(b.get('status')=='captured-pending-independent-review','baseline receipt status changed; preserve its original pending status')
 need(root.get('status')=='root_accepted_complete_original_baseline_with_explicit_boolean_local_stdout_gap','root review acceptance marker mismatch')
 ex=(TMP/A_DIRS[0][1]/'execution.json').resolve();raw=ex.read_bytes()
 need(root.get('execution')=={'path':str(ex),'bytes':len(raw),'sha256':sha(raw)},'root review does not bind exact baseline receipt')
 rp=(TMP/A_DIRS[3][1]/'review.json').resolve();rr=rp.read_bytes()
 need(root.get('independent_review')=={'path':str(rp),'bytes':len(rr),'sha256':sha(rr)},'root review does not bind independent review')
 need(review.get('schema')=='test-break-with-label-full-source-baseline-v1' and review.get('receipt_sha256')==sha(raw),'independent review schema/receipt binding mismatch')

def verify_b_inputs(final_root:Path,named_file:Path)->None:
 native=read_json(TMP/B_NATIVE/'execution.json');nr=read_json(TMP/B_NATIVE/'review.json')
 need(nr.get('status')=='passed','native review not accepted')
 need(native.get('status')=='passed','native workspace receipt is not passed')
 failed=read_json(TMP/B_FAILED/'collection.json')
 need(failed.get('status')=='collection failed; no CI accepted','first failed CI attempt must remain explicitly failed')
 failed_rows=[c for c in failed.get('commands',[]) if c.get('exit_code')!=0 and Path(c.get('streams',{}).get('stdout',{}).get('path','')).name=='supply-chain.log']
 need(len(failed_rows)==1, 'first failure no longer identifies exactly one supply-chain log capture error')
 fail=failed_rows[0]; stderr=Path(fail['streams']['stderr']['path']).read_bytes()
 need(b'EOF' in stderr and fail.get('streams',{}).get('stdout',{}).get('bytes')==0, 'first failure no longer preserves GitHub API EOF evidence')
 for name in B_HISTORY:
  root=TMP/name;need(root.is_dir(),f'missing CI retry history: {root}')
  historical=read_json(root/'collection.json')
  need(historical.get('status')=='collection failed; no CI accepted',f'historical retry was not retained as a failed collection: {name}')
  for p in root.rglob('*'):safe(p)
 for name in B_UNACCEPTED:
  root=TMP/name;need(root.is_dir(),f'missing pre-acceptance collection: {root}')
  pending=read_json(root/'collection.json')
  need(pending.get('status')=='raw collection complete; independent acceptance pending',f'pre-acceptance history status changed: {name}')
  for p in root.rglob('*'):safe(p)
 for name in B_ACCEPT_ARGV:
  root=TMP/name;need(root.is_dir() and (root/'argv.json').is_file(),f'missing historical acceptance argv: {root}')
  for p in root.rglob('*'):safe(p)
 need(final_root.is_dir() and final_root.resolve().is_relative_to(TMP), 'final CI root must be an explicit directory under /private/tmp')
 review_path=final_root/'review.json';need(review_path.is_file(),'final CI root lacks review.json')
 cr=read_json(review_path)
 need(cr.get('status')=='accepted' and cr.get('critical_gate_count')==93 and cr.get('aggregate_step_proofs')==[], 'final CI review acceptance/gate closure mismatch')
 need(named_file.is_file() and named_file.resolve().is_relative_to(TMP),'named-outcome review file missing/outside /private/tmp')
 named=read_json(named_file)
 need(named.get('status')=='root_accepted_all_named_outcomes_equal_across_both_fixed_seeds','named outcome review not accepted')
 need(named.get('accepted_ci_review_sha256')==sha(review_path.read_bytes()),'named outcome review does not bind final CI review')

def make_items(kind:str,final_root:Path|None,named_file:Path|None)->dict[str,tuple[Path,bytes,int]]:
 items={}
 if kind=='breakwithlabel':
  verify_a_inputs()
  for prefix,name in A_DIRS:collect_tree(TMP/name,'private-tmp/'+name,items)
  for arc,p in LICENSES:
   safe(p);need(p.is_file(),f'missing license: {p}');add(items,arc,p,p.read_bytes(),mode(p))
  collect_tree(HERE,'archive-preparation',items)
 else:
  need(final_root is not None and named_file is not None,'CI archive requires --final-ci-root and --named-review-file')
  verify_b_inputs(final_root,named_file)
  collect_tree(TMP/B_NATIVE,'private-tmp/'+B_NATIVE,items)
  # First supply-chain collection failure is retained as failed history, never relabelled.
  collect_tree(TMP/B_FAILED,'private-tmp/'+B_FAILED,items)
  history_paths={ (TMP/name).resolve() for name in (*B_HISTORY,*B_UNACCEPTED,*B_ACCEPT_ARGV,B_TRANSPORT) }
  for name in B_HISTORY:collect_tree(TMP/name,'private-tmp/'+name,items)
  for name in B_UNACCEPTED:collect_tree(TMP/name,'private-tmp/'+name,items)
  for name in B_ACCEPT_ARGV:collect_tree(TMP/name,'private-tmp/'+name,items)
  collect_tree(TMP/B_TRANSPORT,'private-tmp/'+B_TRANSPORT,items)
  collect_tree(TMP/B_TOOLS,'private-tmp/'+B_TOOLS,items)
  named_root=(TMP/B_NAMED).resolve()
  collect_tree(named_root,'private-tmp/'+B_NAMED,items)
  if final_root.resolve() not in history_paths and final_root.resolve()!=named_root:
   collect_tree(final_root,'private-tmp/'+final_root.name,items)
  included_roots={ (TMP/B_NATIVE).resolve(), (TMP/B_FAILED).resolve(), (TMP/B_TOOLS).resolve(), named_root, final_root.resolve(), *history_paths }
  if not any(named_file.resolve().is_relative_to(root) for root in included_roots):
   add(items,'private-tmp/'+named_file.relative_to(TMP).as_posix(),named_file,named_file.read_bytes(),mode(named_file))
  collect_tree(HERE,'archive-preparation',items)
 return dict(sorted(items.items()))

def run(kind:str,out:Path,final_root:Path|None,named_file:Path|None)->dict:
 out=out.resolve();need(not out.exists(),'output already exists');need(not out.is_relative_to(HERE),'output cannot be inside prep directory')
 items=make_items(kind,final_root,named_file)
 rows=[]
 for arc,(src,data,m) in items.items():
  rows.append({'archive_path':arc,'source_path':str(src.resolve()),'bytes':len(data),'sha256':sha(data),'mode':m,'kind':'directory' if src.is_dir() else 'file'})
 manifest={'schema':'jarde-final-evidence-archive-v1','evidence_kind':kind,'payload_count':len(rows),'members':rows,
  'scope_note':('Original TestBreakWithLabel baseline remains status captured-pending-independent-review; separate root review accepted its evidence with a documented Boolean-local stdout gap.' if kind=='breakwithlabel' else 'Native review is retained with the first own-CI collection failure and all retry histories. Only the explicit final accepted CI receipt and named-outcome review are treated as accepted.'),
  'external_binary_policy':'JDK, CLI, GitHub CLI, and external dependency installations are not copied; receipts retain exact external pins.'}
 blob=(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
 out.parent.mkdir(parents=True,exist_ok=True)
 # Normalize tar metadata; gzip mtime is fixed for a reproducible container given identical payload bytes.
 raw=io.BytesIO()
 with tarfile.open(fileobj=raw,mode='w',format=tarfile.PAX_FORMAT) as tar:
  for arc,(src,data,m) in items.items():
   info=tarfile.TarInfo(arc);info.mode=m;info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
   if src.is_dir():info.type=tarfile.DIRTYPE;info.size=0;tar.addfile(info)
   else:info.size=len(data);tar.addfile(info,io.BytesIO(data))
  info=tarfile.TarInfo('ARCHIVE_INVENTORY.json');info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.size=len(blob);tar.addfile(info,io.BytesIO(blob))
 with out.open('xb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:gz.write(raw.getvalue())
 # Reopen and compare exact member set and each regular file's bytes/mode/hash.
 with tarfile.open(out,'r:gz') as tar:
  members=tar.getmembers();byname={m.name:m for m in members}
  expected=set(items)|{'ARCHIVE_INVENTORY.json'}
  need(len(byname)==len(members) and set(byname)==expected,'archive member set has duplicates or omissions')
  for arc,(src,data,m) in items.items():
   info=byname[arc];need(info.mode==m,f'mode mismatch: {arc}')
   if src.is_dir():need(info.isdir(),f'directory type mismatch: {arc}')
   else:
    need(info.isfile(),f'file type mismatch: {arc}')
    got=tar.extractfile(info).read();need(got==data and len(got)==len(data) and sha(got)==sha(data),f'byte mismatch: {arc}')
  inv=tar.extractfile(byname['ARCHIVE_INVENTORY.json']).read();need(inv==blob,'inventory mismatch')
 sidecar=out.with_suffix(out.suffix+'.inventory.json')
 with sidecar.open('xb') as f:f.write(blob)
 return {'status':'packed-and-reopened','archive':str(out),'archive_sha256':sha(out.read_bytes()),'inventory':str(sidecar),'inventory_sha256':sha(blob),'members':len(rows)}

def main()->None:
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('kind',choices=['breakwithlabel','if-loop-entry-ci']);ap.add_argument('--out',type=Path,required=True)
 ap.add_argument('--final-ci-root',type=Path);ap.add_argument('--named-review-file',type=Path)
 a=ap.parse_args();print(json.dumps(run(a.kind,a.out,a.final_ci_root,a.named_review_file),indent=2))
if __name__=='__main__':main()
