# Final evidence archive preparation

`archive-breakwithlabel.py` and `archive-if-loop-entry-ci.py` prepare fail-closed, byte-verified archives. Both use the shared `archive.py` implementation. It has not been run. It uses only Python's standard library; invoke the corresponding wrapper as `python3 -B archive-*.py ...` after the respective evidence is accepted. It rejects missing inputs, symlinks, cache/build directories, duplicate member names, pre-existing outputs, and any archive member whose bytes or mode do not reopen exactly. Each archive contains an embedded inventory and receives an adjacent `.inventory.json` sidecar. The archiver and this README are included in each archive as preparation inputs.

## CF09 TestBreakWithLabel

After reviewing the pinned root acceptance, run:

```sh
python3 -B /private/tmp/jarde-final-evidence-archive-tools-luna-v3-20261019/archive-breakwithlabel.py \
  --out /Users/lordcasser/workspace/projects/jarde/openspec/evidence/java-syntax-2026-10-19/cf09-testbreakwithlabel-original-root-v1.tar.gz
```

The archive includes the full original baseline, Luna preparation and independent review, root review, both audit captures, Boolean-local audit, fixed-CF09 audit, sequential-loop finite-input case plan and its root review, and the fixture’s JADX-LICENSE and JADX-NOTICE files. The sequential-loop case plan is mathematical planning only; it does not claim runtime execution or CF09 closure. The source baseline's original `captured-pending-independent-review` status remains intact; the separate root review records acceptance with the documented Boolean-local stdout gap. External JDK/CLI/harness installations are referenced by receipts, not copied.

## If-loop-entry native and own CI

After root has accepted the final retry and generated its named-outcome review, run:

```sh
python3 -B /private/tmp/jarde-final-evidence-archive-tools-luna-v3-20261019/archive-if-loop-entry-ci.py \
  --final-ci-root /private/tmp/jarde-if-loop-entry-own-ci-root-v9-20261019 \
  --named-review-file /private/tmp/EXACT_ACCEPTED_NAMED_REVIEW.json \
  --out /Users/lordcasser/workspace/projects/jarde/openspec/changes/preserve-proved-if-loop-entry-origins/results/final-native-own-ci.tar.gz
```

The script includes the accepted native workspace evidence, failed own-CI collections v1-v6 (preserving each raw stream and the supply-chain API failures), unaccepted raw collections v7-v8, both failed root acceptance-argv attempts, and the root-reviewed transport retry collector and ZIP collector changes, the accepted tooling and named-review verifier, plus the explicitly supplied v9 final CI directory and its review. It requires the final review to say `accepted`, close all 93 exact gates, and have no aggregate step proofs. The named-outcome review must bind the exact final CI `review.json` SHA. The first failed collection is archived as a failed historical attempt, not as CI success.

The script intentionally requires the v9 final root and named-review file as arguments. It does not treat an incomplete retry as final or infer success from the GitHub run status alone. No archiver, CI collector, build, or test was executed while preparing these files.
