from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=B/'CORE';W=Path('/home/lordcasser/.codex/worktrees/conditional-return-finally/jarde');O=C/'conditional-return-finally-recovery-evidence-v2';O.mkdir(exist_ok=False)
def sha(v):return hashlib.sha256(v).hexdigest()
payload={};members=[];phases=[]
def add(name,p,group):
 p=Path(p);assert p.is_file() and not p.is_symlink();v=p.read_bytes();assert name not in payload and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts;payload[name]=v;members.append(dict(path=name,bytes=len(v),sha256=sha(v),source_path=str(p),group=group))
def directory(name,p,group):
 for q in sorted(p.rglob('*')):
  if q.is_file():add(name+'/'+q.relative_to(p).as_posix(),q,group)
for name,rel,commands in [
 ('first-compile','conditional-return-finally-first-implementation-native-v1',2),
 ('second-native','conditional-return-finally-second-implementation-native-v1',5),
 ('wip-replay','conditional-return-finally-new-full-source-v1/run-v1',10),
 ('negative-compat','conditional-return-finally-negative-compat-native-v1',4),
 ('final-native','conditional-return-finally-final-product-native-v1',15),
 ('final-replay','conditional-return-finally-final-full-source-v1/run-v1',10),
 ('first-FYFX-screen','effectful-finally-after-conditional-return-screen-v1/run-v1',1),
 ('final-FYFX-screen','effectful-finally-after-conditional-return-screen-v2/run-v1',8)]:
 p=C/rel;r=json.loads((p/'execution.json').read_text());assert len(r['commands'])==commands
 for row in r['commands']:
  for stream in row['streams'].values():
   v=Path(stream['path']).read_bytes();assert len(v)==stream['bytes'] and sha(v)==stream['sha256']
 if 'source_manifest_before' in r and 'source_manifest_after' in r:assert r['source_manifest_before']==r['source_manifest_after']
 if 'sources_identical' in r:assert r['sources_identical'] and r['inputs_identical']
 directory('phases/'+name,p,'actual_captured_phase_not_relabelled')
 phases.append(dict(name=name,status=r['status'],commands=commands,raw_streams=2*commands,receipt='phases/'+name+'/execution.json',error=r.get('error')))
for rel in ['conditional-return-finally-first-implementation-source-snapshot-v1','conditional-return-finally-second-implementation-source-snapshot-v1','conditional-return-finally-final-product-source-binding-v1']:
 directory('source/'+rel,C/rel,'historical_exact_source_or_actual_git_tree')
for rel in ['conditional-return-finally-final-full-source-launch-v1','conditional-return-finally-new-full-source-launch-v1','effectful-finally-after-conditional-return-screen-launch-v1','effectful-finally-after-conditional-return-screen-launch-v2']:
 directory('dispatch/'+rel,C/rel,'actual_phase_dispatch')
for rel in ['conditional-return-final-product-independent-audit-v1.json','effectful-finally-after-conditional-return-screen-v2/independent-audit-v1.json','conditional-return-finally-current-implementation-static-review-v1.json','conditional-return-finally-reader-census-root-v1.json']:
 add('audits/'+rel,C/rel,'independent_or_root_audit_exact_scope')
for rel in ['independent-audit-v1.json','independent-audit-v2.json']:
 add('audits/wip-'+rel,C/'conditional-return-finally-new-full-source-v1'/rel,'historical_wip_independent_audit')
for rel in ['replay_loopless_new_full_source_v1.py','replay_loopless_final_full_source_v1.py','screen_effectful_finally_after_conditional_return_v1.py','screen_effectful_finally_after_conditional_return_v2.py']:
 add('runners/'+rel,B/rel,'executed_phase_runner')
for p in sorted((W/'tests/fixtures/recover-conditional-return-finally-copies').rglob('*')):
 if p.is_file():add('frozen-fixture/'+p.relative_to(W/'tests/fixtures/recover-conditional-return-finally-copies').as_posix(),p,'unchanged_original_fixture_driver_oracle')
add('package-builder.py',Path(__file__).resolve(),'package_builder')
m=dict(schema='conditional-return-finally-recovery-evidence-v1',status='packaged_actual_local_recovery_not_own_ci',product_head='51de58710291cd3a3587f7040eec6f972cb26229',full_source_count=4922,phases=phases,commands=sum(p['commands'] for p in phases),command_raw_streams=sum(p['raw_streams'] for p in phases),final_native=dict(commands=15,passed=74,failed=0,ignored=4),final_replay=dict(commands=10,generated_source_bytes=1225,whole_methods_each=2,actual_generated_compiles=2,driver_compiles_rebuilt_only=2,runtime_oracles=4,stdout_each_bytes=134),FYFX=dict(commands=8,CLI_exit0=4,whole_javac_exit1=4,compiler='all four compile commands use real JDK23 --release8; javac8 names identify frozen input leg only',FY_methods=5,FX_methods=6,FY_loopless_recovered=True,remaining='FY.noCall and FX.finReturn/other old missing-return gaps retained; no generated runtime'),historical_failures='first native compiler stale enum test field failed before behavioral tests; first FY screen CLI0 then harness wrongly expected direct literal return; no javac reached. All originals/raw retained, neither is final product CI.',own_ci='pending separately; not included or borrowed',payload_count=len(members),members=sorted(members,key=lambda r:r['path']))
v=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode();(O/'manifest.json').write_bytes(v)
with (O/'capture.tar.gz').open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,data in sorted({**payload,'manifest.json':v}.items()):
    i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data))
with tarfile.open(O/'capture.tar.gz') as t:
 assert len(t.getmembers())==len(payload)+1
 for i in t.getmembers():assert i.isfile() and t.extractfile(i).read()=={**payload,'manifest.json':v}[i.name]
a=(O/'capture.tar.gz').read_bytes();r=dict(status='root_reopened_verified_all_payloads',bytes=len(a),sha256=sha(a),payload_count=len(members),member_count=len(members)+1,commands=m['commands'],command_raw_streams=m['command_raw_streams'],manifest_sha256=sha(v));(O/'execution.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
