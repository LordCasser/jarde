from pathlib import Path
import json,hashlib,importlib.util,os,shutil,zipfile,subprocess,datetime
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=B/'CORE';W=Path('/home/lordcasser/.codex/worktrees/conditional-return-finally/jarde');D=C/'effectful-finally-after-conditional-return-screen-v2';D.mkdir(exist_ok=False);O=D/'run-v1';O.mkdir();OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');CLI=B/'jarde-cli-conditional-return-finally-final-product-v1'
def pin(p):
 p=Path(p);v=p.read_bytes();assert p.is_file() and not p.is_symlink();return dict(path=str(p),bytes=len(v),sha256=hashlib.sha256(v).hexdigest())
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
assert not (W/'target').exists() and shutil.disk_usage(W).free>=5*1024**3
native=C/'conditional-return-finally-final-product-native-v1/execution.json';n=json.loads(native.read_text());assert n['source_manifest_before']==n['source_manifest_after'] and n['target_absent'];assert pin(CLI)=={k:n['frozen_cli'][k] for k in ['path','bytes','sha256']}
oldp=C/'effectful-finally-current-screen-v1/run-v1/execution.json';old=json.loads(oldp.read_text());assert old['inputs_identical'] and old['sources_identical'];oldpins={x['path']:x for x in old['inputs_after']}
javac=Path(old['tools']['javac23']['path']);assert pin(javac)==old['tools']['javac23']
closure=load('next_finally_source_closure',OLD/'tools-prep/workspace_runner.py');closure.ROOT=W;paths=set(closure.source_paths())|{W/x['path'] for x in json.loads((W/'tests/fixtures/corpus-fingerprint.json').read_text())['files']}
def sources():return [dict(path=str(p.relative_to(W)),bytes=p.stat().st_size,sha256=pin(p)['sha256']) for p in sorted(paths)]
before=sources();assert before==n['source_manifest_before']
inputs={CLI,native,oldp,javac,Path(__file__).resolve()};jars=[]
for leg in ['javac23','javac8']:
 for name in ['FY','FX']:
  p=C/f'effectful-finally-current-screen-v1/run-v1/{leg}-original-jars/{name}.jar';r=next(x for x in old['commands'] if x.get('label')==f'{leg}-whole-class-json-{name}');assert str(p)==r['argv'][3]
  # The jar is bound by the old case's actual input pin/record, not just its filename.
  assert pin(p)==old['original_compiles'][leg]['jar_classes'][name]
  case=old['cases'][leg][name]
  with zipfile.ZipFile(p) as z:
   data=z.read(name+'.class')
  cp=next(row for row in old['original_compiles'][leg]['class_pins'] if Path(row['path']).name==name+'.class')
  assert len(data)==cp['bytes'] and hashlib.sha256(data).hexdigest()==cp['sha256']
  jars.append((leg,name,p));inputs.add(p)
 for f in ['FY.java','FX.java']:
  source=W/'openspec/evidence/java-syntax-2026-10-05/return-effectful-finally-patrol/fixture'/f
  oldsource=next(row for row in old['original_compiles'][leg]['source_pins'] if Path(row['path']).name==f);assert {k:pin(source)[k] for k in ['bytes','sha256']}=={k:oldsource[k] for k in ['bytes','sha256']}
  inputs.add(source)
# Verify raw old CLI input bytes against its retained artifact before reuse.
for leg,name,p in jars:
 with zipfile.ZipFile(p) as z:assert z.namelist()==[name+'.class']
rowpins=[pin(p) for p in sorted(inputs)];g=load('next_finally_guard',OLD/'tools-prep/guard.py');scan=load('next_finally_target_scan',OLD/'tools-prep/target_scan.py');g.ROOT=W;g.OUT=O;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.target_bytes=lambda:scan.target_bytes(W);g.expected_test_summaries=lambda _i,_d:None;g.command_stream=pin;g.ENV_VALUES={}
env={'HOME':'/home/lordcasser','PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}
r=dict(schema='effectful-finally-after-conditional-return-screen-v2',status='running',scope='Fixed conditional-return product FY/FX whole-class rescreen. All methods retained. All four recompile commands actually use JDK23 --release8; compiler legs identify original frozen input. No original runtime rerun or generated runtime; loopless restoration does not certify noCall/finReturn or parent completion.',product_head='51de58710291cd3a3587f7040eec6f972cb26229',native_receipt=pin(native),frozen_cli=n['frozen_cli'],prior_screen=pin(oldp),source_manifest_before=before,inputs_before=rowpins,default_stack=True,guards=dict(free_bytes=5*1024**3,target_bytes=1024**3),commands=[],cases={})
def save():(O/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
def run(label,args,expected):
 q=g.run_command(len(r['commands'])+1,[str(x) for x in args],env);q.update(label=label,expected_exit=expected);r['commands'].append(q);save();assert q['exit_code']==expected and q['guard_stop'] is None;return q
save()
try:
 for leg,name,jar in jars:
  q=run(f'{leg}-current-whole-source-{name}',[CLI,'class-source','--input',jar,'--class',name,'--policy','plain-jar','--release','8','--format','json','--evidence','all','--budget','elapsed_millis=10000'],0);doc=json.loads(Path(q['streams']['stdout']['path']).read_text());dest=O/f'{leg}-{name}';dest.mkdir();source=dest/(name+'.java');source.write_bytes(doc['text'].encode());classes=dest/'classes';classes.mkdir();empty=dest/'empty-sourcepath';empty.mkdir()
  methods=[]
  for method in doc['methods']:
   out=method['outcome'];report=out.get('report',{});methods.append(dict(index=method['item']['index'],name=method['item']['name']['escaped'],descriptor=method['item']['descriptor']['escaped'],identity=method['item']['identity'],outcome=out['kind'],text=report.get('text'),diagnostics=report.get('diagnostics'),regions=report.get('regions')))
  
  if name=='FY':
   loopless=next(m for m in methods if m['name']=='loopless');assert '@bytecode' not in loopless['text'] and 'finally {' in loopless['text'] and 'int local1 = 3000;' in loopless['text'] and 'return local1;' in loopless['text']
  c=run(f'{leg}-compile-exact-current-generated-{name}',[javac,'--release','8','-g:none','-Xlint:-options','-classpath',classes,'-sourcepath',empty,'-d',classes,source],1);diagnostic=Path(c['streams']['stderr']['path']).read_bytes();assert b'missing return' in diagnostic.lower();assert source.read_bytes()==doc['text'].encode()
  r['cases'][leg+'/'+name]=dict(input_jar=pin(jar),generated_source=pin(source),method_count=len(doc['methods']),methods=methods,compile_exit=c['exit_code'],compile_missing_return=True,source_unchanged=True,generated_runtime_commands=0);save()
 assert len(r['commands'])==8;r['status']='captured_current_eight_command_refusal_screen'
except BaseException as e:r['status']='failed_raw_preserved';r['error']=repr(e)
finally:
 r.update(source_manifest_after=sources(),inputs_after=[pin(p) for p in sorted(inputs)],target_absent=not (W/'target').exists(),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());r['sources_identical']=r['source_manifest_after']==before;r['inputs_identical']=r['inputs_after']==rowpins
 if not r['sources_identical'] or not r['inputs_identical'] or not r['target_absent']:r['status']='failed_integrity'
 save()
print(r['status'],len(r['commands']));raise SystemExit(0 if r['status']=='captured_current_eight_command_refusal_screen' else 1)
