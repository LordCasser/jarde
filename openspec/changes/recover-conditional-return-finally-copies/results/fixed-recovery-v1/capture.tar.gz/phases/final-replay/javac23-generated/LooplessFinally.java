// jarde: presentation of `LooplessFinally` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class LooplessFinally extends java.lang.Object {
    static int value;

    public LooplessFinally() {
        // @method <init>()V
        // @declaration a constructor of `LooplessFinally`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int loopless(int[] arg0) {
        // @method loopless([I)I
        // @declaration a static method of `LooplessFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        try {
            if (arg0.length > 0) {
                if (arg0[0] == 3) {
                    int local1 = LooplessFinally.value;
                    return local1;
                }
            }
        } finally {
            java.lang.System.out.println("f");
        }
        return -1;
    }
}
