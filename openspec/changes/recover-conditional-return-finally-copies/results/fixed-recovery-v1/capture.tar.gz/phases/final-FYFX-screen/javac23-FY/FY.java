// jarde: presentation of `FY` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class FY extends java.lang.Object {
    public FY() {
        // @method <init>()V
        // @declaration a constructor of `FY`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int emptyFin(int[] arg0) {
        // @method emptyFin([I)I
        // @declaration a static method of `FY`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int[] local1;
        local1 = arg0;
        for (int local4 : local1) {
            if (local4 == 3) {
                return local4 * 1000;
            }
        }
        return -1;
    }

    static int noCall(int[] arg0) {
        // jarde: not recovered: the recovery run for `noCall([I)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method noCall([I)I
        // @declaration a static method of `FY`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 10 16 28 40 46 54 60
        // local 1 crosses a quoted fallback region; its assignments and consumers cannot be presented as one lexically bound definition-use slice
    }

    static int loopless(int[] arg0) {
        // @method loopless([I)I
        // @declaration a static method of `FY`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        try {
            if (arg0.length > 0) {
                if (arg0[0] == 3) {
                    int local1 = 3000;
                    return local1;
                }
            }
        } finally {
            java.lang.System.out.println("f");
        }
        return -1;
    }

    public static void main(java.lang.String[] arg0) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `FY`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.io.PrintStream saved0 = java.lang.System.out;
        java.lang.StringBuilder saved1 = new java.lang.StringBuilder().append("");
        java.lang.StringBuilder saved2 = saved1.append(emptyFin(new int[]{1, 3})).append("/");
        java.lang.StringBuilder saved3 = saved2.append(noCall(new int[]{1, 3})).append("/");
        saved0.println((java.lang.String) saved3.append(loopless(new int[]{3})).toString());
        return;
    }
}
