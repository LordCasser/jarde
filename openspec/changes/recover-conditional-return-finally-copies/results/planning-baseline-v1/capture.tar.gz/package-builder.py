from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=B/'CORE';W=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');O=C/'loopless-planning-baseline-evidence-v1';O.mkdir(exist_ok=False)
def sha(v):return hashlib.sha256(v).hexdigest()
payload={};rows=[]
def add(name,p,group):
 p=Path(p);assert p.is_file() and not p.is_symlink();v=p.read_bytes();assert name not in payload and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
 payload[name]=v;rows.append(dict(path=name,bytes=len(v),sha256=sha(v),source_path=str(p),group=group))
groups=[('independent-control','loopless-independent-control-v1',12),('full-FY-FX-current-screen','effectful-finally-after-dispatch-screen-v1',8)];cmdgroups=[];sources=[]
for label,dirname,count in groups:
 base=C/dirname;d=json.loads((base/'run-v1/execution.json').read_text());assert len(d['commands'])==count;assert d['source_manifest_before']==d['source_manifest_after'] and len(d['source_manifest_before'])==4915;sources.append(d['source_manifest_before'])
 for p in sorted(base.rglob('*')):
  if p.is_file() and not p.name.endswith('.tmp'):add(label+'/'+p.relative_to(base).as_posix(),p,label)
 for command in d['commands']:
  assert command['exit_code']==command['expected_exit']
  for q in command['streams'].values():
   v=Path(q['path']).read_bytes();assert len(v)==q['bytes'] and sha(v)==q['sha256'];assert str(Path(q['path'])) in {r['source_path'] for r in rows}
 cmdgroups.append(dict(group=label,commands=count,raw_streams=2*count,exit_codes=[x['exit_code'] for x in d['commands']]))
assert sources[0]==sources[1]
screen=json.loads((C/'effectful-finally-after-dispatch-screen-v1/run-v1/execution.json').read_text())
for legname,case in screen['cases'].items():add('original-jars/'+legname.replace('/','-')+'.jar',case['input_jar']['path'],'unchanged_original_input')
for name in ['FY.java','FX.java']:add('original-full-source/'+name,W/'openspec/evidence/java-syntax-2026-10-05/return-effectful-finally-patrol/fixture'/name,'unchanged_original_full_source')
for name in ['guard.py','target_scan.py','workspace_runner.py']:add('helpers/'+name,Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep')/name,'executed_helper')
for name in ['run.py','source-head-binding.json','source-head-tree.raw','source-head-tree.argv.json']:
 if name!='run.py':add('parent-product-lineage/'+name,C/'static-prefix-dispatch-fixed-source-replay-v1'/name,'source_git_binding_not_new_execution')
add('parent-product-lineage/native-execution.json',C/'static-prefix-candidate-dispatch-fix-v1/execution.json','prior_build_reference_not_repeated_execution')
add('parent-product-lineage/accepted-local-package-execution.json',C/'static-prefix-dispatch-local-evidence-v1/execution.json','prior_package_pin_not_repeated_execution')
add('helpers/screen_effectful_finally_after_dispatch_v1.py',B/'screen_effectful_finally_after_dispatch_v1.py','executed_harness')
for name in ['effectful-finally-after-dispatch-screen-launch-v1']:
 for p in sorted((C/name).iterdir()):
  if p.is_file():add('screen-launch/'+p.name,p,'actual_dispatch_metadata')
for name in ['effectful-finally-loopless-guard-seam-review-v1.json','effectful-finally-loopless-fixture-acceptance-plan-v1.json','loopless-design-notes-root-v1.json']:add('planning-reviews/'+name,C/name,'static_or_design_only')
add('package-builder.py',Path(__file__).resolve(),'package_builder')
m=dict(schema='loopless-planning-baseline-evidence-v1',scope='Actual original-class control and a89 full generated-source refusal only. No new recovery implementation or rebuilt runtime.',product_head='a89d423c9a6e5d62ceb3f8185a818ebe3d67a17b',frozen_cli=dict(path=str(B/'jarde-cli-static-prefix-dispatch-fix-v1'),bytes=59699632,sha256='6e075292bf761f178858f5714b3dbbf51e57a9e711ca1d87d45e77312228db96',mode='0555',inside_archive=False),source_count=4915,actual_command_groups=cmdgroups,command_count=20,command_raw_count=40,original_driver_runs=4,original_driver_stdout_bytes=134,independent_generated_source_bytes=1560,independent_generated_source_sha256='57926d1ddc3ad60342c853a185ff5fa3d8e8ae5c79288da0cffe65f5ad76a8c1',independent_generated_source_compiles=2,independent_generated_source_compile_exit=1,full_FY_FX_compiles=4,full_FY_FX_compile_exit=1,full_FY_FX_rebuild_tool='JDK23 javac --release8 for all four',rebuilt_runtime_commands=0,limits=['The independent class is a new source fixture with a mutable field return, not original FY byte identity.','Current full FY/FX retain all methods and remain compile failures; no method deletion.','Static proof-seam notes are not runtime guard/SSA instrumentation.','Parent-product-lineage contains prior build/source binding references; those commands are not counted as current 20 executions. Their full raw is preserved separately by the accepted prefix local evidence archive.','JDK tools and CLI binaries are external pins, not bundled.'],payload_count=len(rows),members=sorted(rows,key=lambda r:r['path']))
v=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode();(O/'manifest.json').write_bytes(v)
with (O/'capture.tar.gz').open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,data in sorted({**payload,'manifest.json':v}.items()):
    i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data))
with tarfile.open(O/'capture.tar.gz') as t:
 assert len(t.getmembers())==len(payload)+1
 for i in t.getmembers():assert i.isfile() and t.extractfile(i).read()=={**payload,'manifest.json':v}[i.name]
a=(O/'capture.tar.gz').read_bytes();e=dict(status='reopened_and_verified_every_member',archive=str(O/'capture.tar.gz'),bytes=len(a),sha256=sha(a),payload_count=len(rows),member_count=len(rows)+1,commands=20,command_raw_streams=40,manifest_sha256=sha(v));(O/'execution.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e))
