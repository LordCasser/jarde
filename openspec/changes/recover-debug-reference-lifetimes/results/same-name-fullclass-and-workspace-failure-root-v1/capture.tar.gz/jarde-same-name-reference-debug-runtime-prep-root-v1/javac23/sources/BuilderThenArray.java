// jarde: presentation of `BuilderThenArray` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class BuilderThenArray extends java.lang.Object {
    public BuilderThenArray() {
        // @method <init>()V
        // @declaration a constructor of `BuilderThenArray`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static java.lang.String run(java.lang.String x) {
        // @method run(Ljava/lang/String;)Ljava/lang/String;
        // @declaration a static method of `BuilderThenArray`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int n;
        char[] v_2;
        int i;
        java.lang.StringBuilder v = new java.lang.StringBuilder(x);
        n = v.length();
        v_2 = new char[n];
        for (i = 0; i < n; i = i + 1) {
            v_2[i] = x.charAt(i);
        }
        return new java.lang.String(v_2);
    }

    public static void main(java.lang.String[] a) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `BuilderThenArray`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.lang.System.out.println((java.lang.String) run("abc"));
        return;
    }
}
