# Same-name reference LVT test update (private v2 candidate)

This v2 differs from v1 only in the redundant first-declaration assertion for `StringThenQueue`: that source begins with `java.lang.String v = x.trim();`, not a constructor expression. The full expected class remains exact under both essential and all-evidence selections, so the assertion correction does not weaken the source check. The concrete second declaration, three recovered method identities, source-map ownership, and marker checks remain intact.

All eight same-name fixtures remain in the test set. Frozen source baselines and other different-name, negative, held-use, and nonzero-held-use checks are unchanged. This bundle is private; no Rust, Java, Jarde, or CLI command was run.
