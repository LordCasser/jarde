# Reference-prefix full-workspace preparation v2

This private preparation adapts the root-owned v5 workspace runner and acceptor. It preserves the dynamic Cargo source/target inventory, both fixed Proptest seeds, command and raw-stream capture, completed-test-executable cleanup, the 5 GiB free-space and 1 GiB target limits with one-second polling, default Rust stack, and `finally` exact `cargo clean` behavior. The prior ordered-field named-test gates remain required for each full-workspace seed.

The focused input must be a completed successful receipt with a fresh `cargo build -p jarde-cli --locked`. The validator reads and verifies the focused CLI's path, byte count, and SHA-256, then requires that its bytes and SHA-256 match each of the actual debug and none runtime receipts. A debug/none/focused path can differ; every referenced path is independently verified against its own recorded length and hash, and all three original CLI pins and both runtime receipt pins are retained in the workspace record. If either binary's bytes or SHA differ, workspace validation stops and the runtime matrix must be rerun against the focused CLI.

The focused receipt's selected suites are gated on these exact named outcomes, each appearing once and passing:

- 4 raw-alias/LVT tests
- 6 protected-prefix-loop tests, including `effect_suffix_inside_try_refuses_prefix_loop_and_restores_full_state`
- 2 ordinary try/prefix-loop integration tests
- 1 structured-list test that checks the full 11-method report

The complete workspace still additionally requires the existing ordered-field focused outcomes, Jarde Java/readers, corpus, and other prior gates in both seeds. Source and target counts are derived dynamically; no historical count is pinned.

The only available debug/none runtime receipts are:

- debug: `/private/tmp/jarde-reference-prefix-candidate-debug-root-v1/execution.json`
- none: `/private/tmp/jarde-reference-prefix-candidate-none-root-v1/execution.json`

Their receipt hashes and historic CLI identity are in `pins.json`. They were captured with a different path than the fresh focused build may use, so path equality is intentionally not required. Focused v7 failed Clippy; v8 failed compilation with E0716. Both receipts are preserved as historical failures and cannot be accepted. At the time this v2 preparation was made, v9's focused receipt was still running and is not pinned as a completed input. No workspace runner or acceptor was executed while preparing this directory.

After a successful final focused receipt is available and its CLI bytes/SHA match both runtime receipts, invoke the runner with the receipt paths and hashes:

```sh
python3 /private/tmp/jarde-reference-prefix-workspace-prep-luna-v2/workspace_runner.py \
  --focused-receipt /path/to/final-focused/execution.json \
  --focused-receipt-sha256 FOCUSED_RECEIPT_SHA256 \
  --runtime-debug-receipt /private/tmp/jarde-reference-prefix-candidate-debug-root-v1/execution.json \
  --runtime-debug-receipt-sha256 DEBUG_RECEIPT_SHA256 \
  --runtime-none-receipt /private/tmp/jarde-reference-prefix-candidate-none-root-v1/execution.json \
  --runtime-none-receipt-sha256 NONE_RECEIPT_SHA256
```

Then run the read-only acceptor with the produced workspace receipt, its receipt SHA-256, the same focused/runtime input paths and hashes, the runner-captured Cargo metadata JSON, and a new output path. The acceptor independently verifies target-associated raw output, named outcomes, both seeds, source closure, guard and cleanup postconditions, plus the additional named gates. This directory is preparation only, not evidence that a future run passes.
