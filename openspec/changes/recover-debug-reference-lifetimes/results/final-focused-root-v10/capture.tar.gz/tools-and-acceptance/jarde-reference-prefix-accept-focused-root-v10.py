import hashlib, importlib.util, json, re, sys
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
RUNNER = Path('/private/tmp/jarde-reference-prefix-workspace-prep-luna-v4/workspace_runner.py')
def pin(path):
    path = Path(path); b = path.read_bytes()
    return {'path': str(path), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
assert pin(RUNNER)['sha256'] == '691e7c073c202ff7782ec8323f0a8c1892ad8748fd55c6d952515f9809736c22'
spec = importlib.util.spec_from_file_location('workspace_protocol_v4', RUNNER)
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
path = Path('/private/tmp/jarde-reference-prefix-final-focused-run-root-v10/execution.json')
f = json.loads(path.read_text()); commands, command_spec = m.validate_focused_receipt(f, path)
live = m.pin_sources(m.source_paths())
assert len(live) == len(f['source_manifest_before'])
assert live == {x['path']:x['sha256'] for x in f['source_manifest_before']}
assert live == {x['path']:x['sha256'] for x in f['source_manifest_after']}
assert commands[0] == ['cargo','fmt','--all','--','--check']
workflow = (ROOT/'.github/workflows/ci.yml').read_text()
clippy_block = workflow.split('run: >-',1)[1].split('      - name:',1)[0]
clippy_argv = clippy_block.split()
actual_clippy = [c for c in commands if c[:2] == ['cargo','clippy']]
assert actual_clippy == [clippy_argv]
totals = [0,0,0]
for c in f['commands']:
    for summary in c.get('actual_test_summaries',[]):
        assert summary[0] == 'ok'
        totals = [a+int(b) for a,b in zip(totals,summary[1:])]
strict = next(c for c in f['commands'] if c['argv'][:2] == ['openspec','validate'])
strict_raw = '\n'.join(Path(x['path']).read_text() for x in strict['streams'].values())
assert re.search(r'360 passed, 0 failed', strict_raw)
assert f['cli']['bytes'] == 62562992 and f['cli']['sha256'] == 'fe00fa7f0edc587a4e85bcc1136bd4397738c2a9df632432a2e79a8221c8bdd6'
assert Path(f['cli']['path']).stat().st_mode & 0o777 == 0o555
runtime = {}
for mode, sha in [('debug','4c0593380d27be965b553866ac7b6fed17f7cfc586126bb6f7afe8be46a8e501'),('none','d0bc8b2c01655d8ce4468b6565546663afa25796bc63c33c428ff44bb5de0093')]:
    rp = Path(f'/private/tmp/jarde-reference-prefix-candidate-{mode}-root-v1/execution.json')
    runtime[mode] = m.validate_runtime_matrix_cli(rp, sha, mode)
    assert (runtime[mode]['cli']['bytes'],runtime[mode]['cli']['sha256']) == (f['cli']['bytes'],f['cli']['sha256'])
assert not (ROOT/'target').exists()
out = Path('/private/tmp/jarde-reference-prefix-final-focused-acceptance-root-v10.json'); assert not out.exists()
result = {'status':'accepted_focused_component_only','not_workspace_ci_or_release':True,'verifier':pin(__file__),'workspace_protocol':pin(RUNNER),'execution':pin(path),'command_spec':command_spec,'source_count':len(live),'totals':dict(zip(('passed','failed','ignored'),totals)),'named_gates':sorted(m.REQUIRED_FOCUSED_NAMED_TESTS),'cli':f['cli'],'runtime_cli_refs':runtime,'peak_target_bytes':max(c.get('peak_target_bytes',0) for c in f['commands']),'strict':'360 passed / 0 failed','target_absent':True}
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'acceptance':pin(out),'totals':totals,'source_count':len(live),'named_gates':len(m.REQUIRED_FOCUSED_NAMED_TESTS)}))
