#!/usr/bin/env python3
"""Independent read-only acceptance audit for the paired EM20 baseline receipts."""
import hashlib, json, pathlib, re, zipfile
BASE=pathlib.Path('/private/tmp')
MODES=('debug','none')
EXPECTED_CLASS_PATHS=['cf11/Runner.class','cf11/UpstreamNestedLoops.class']
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def read_json(p): return json.loads(pathlib.Path(p).read_text())
def pin_file(p):
 p=pathlib.Path(p); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha_bytes(b)}
def decode_bytes(v): return bytes(v).decode('utf-8')
def check(cond,msg):
 if not cond: raise AssertionError(msg)
def report_method_rows(report):
 rows=[]
 for m in report['methods']:
  item=m['item']; ident=item['identity']; member=ident.get('member',ident); name=decode_bytes(member['name']); desc=decode_bytes(member['descriptor'])
  nested=m['outcome']['report']; method=nested['method']; source_map=nested.get('source_map',{}); segments=source_map.get('segments',[])
  check(method==name+desc, f'method identity mismatch {method} vs {name+desc}')
  owner=nested.get('artifact',{}).get('binding',{}).get('method',{}).get('owner',{})
  root_digest=report['class']['class_bytes']['digest']
  check(owner.get('class_bytes',{}).get('digest')==root_digest, f'owner/class digest mismatch in {method}')
  body=nested.get('text','').encode('utf-8')
  for seg in segments:
   check(0<=seg['start']<=seg['end']<=len(body), f'source map span out of bounds {method}')
   origin=seg.get('origin',{})
   for ref in ([origin.get('primary')] if origin.get('primary') else [])+origin.get('derived',[]):
    mid=ref.get('method')
    if mid:
     check(mid.get('name')==member['name'] and mid.get('descriptor')==member['descriptor'],f'source-map method identity mismatch {method}')
     check(mid.get('owner',{}).get('class_bytes',{}).get('digest')==root_digest, f'source-map owner digest mismatch {method}')
  rows.append({'name':name,'descriptor':desc,'method':method,'entry_text_sha256':sha_bytes(m.get('text','').encode('utf-8')),'markers':m.get('markers',[]),'recovery_text':nested.get('text') if name in ('rawAliasEscape','handled') else None,'outcome':nested['outcome'],'content':nested['content'],'source_map_state':next((x.get('state',{}).get('state') for x in nested.get('evidence',{}).get('categories',[]) if x.get('kind')=='source_map'),None),'source_map_segments':len(segments),'text_sha256':sha_bytes(body),'diagnostics':[{'code':d.get('code'),'message':d.get('message')} for d in nested.get('diagnostics',[]) if d.get('severity') in ('error','warning') or d.get('code') in ('jre_region_uncovered_blocks','jre_field_accesses')]})
 return rows
def normalize_compile_argv(argv):
 out=[str(x).replace('-combined/','-SCENARIO/').replace('-isolated-UpstreamNestedLoops/','-SCENARIO/') for x in argv]
 try:
  i=out.index('-d'); out[i+1]='<classes-dir>'
 except (ValueError,IndexError): pass
 return out
results={'schema':'em20-current-baseline-independent-audit-v1','modes':{},'checks':{},'limitations':['read-only audit; no toolchain rerun','report class.class_bytes.digest is BLAKE3 while receipt class pins are SHA-256; direct digest equality is not applicable; report digest is checked against view.snapshot, input class length and the independent original-class SHA-256 pin are checked separately','single-target isolated compiles are duplicate input sets, not additional independent scenarios','compile failure means no generated-source runtime evidence']}
all_raw=[]; total_commands=0
for mode in MODES:
 root=BASE/f'jarde-em20-raw-alias-escape-baseline-{mode}-current-root-v1'; receipt_path=root/'execution.json'; d=read_json(receipt_path); total_commands+=len(d['commands'])
 check(d['status']=='observed', f'{mode}: unexpected status')
 check(d['actual_command_count']==25 and len(d['commands'])==25, f'{mode}: expected 25 commands')
 check(d['source_tool_inputs_unchanged'] is True and d['source_tool_pins_before']==d['source_tool_pins_after'],f'{mode}: source/tool before-after changed')
 for pin in d['source_tool_pins_before']:
  live=pin_file(pin['path']); check(live['bytes']==pin['bytes'] and live['sha256']==pin['sha256'],f'{mode}: live source/tool pin changed: {pin["path"]}')
 check(d['javac_debug_info']=={'mode':mode,'argument':'-g' if mode=='debug' else '-g:none'},f'{mode}: compiler mode receipt mismatch')
 check(d['collector_config']['javac_debug']==mode,f'{mode}: collector config mismatch')
 check(d['cli_mode']=='0o555',f'{mode}: receipt CLI mode not 0555')
 cli=d['cli']; live_cli=pin_file(cli['path']); check(live_cli['sha256']==cli['sha256'] and live_cli['bytes']==cli['bytes'],f'{mode}: CLI pin mismatch')
 check(pathlib.Path(cli['path']).stat().st_mode & 0o777 == 0o555,f'{mode}: live CLI mode mismatch')
 receipt=d['build_receipt']; live_rcpt=pin_file(receipt['path']); check(live_rcpt['sha256']==receipt['sha256'] and live_rcpt['bytes']==receipt['bytes'],f'{mode}: build receipt pin mismatch')
 check(d['build_receipt_cli_binding']['path']==cli['path'] and d['build_receipt_cli_binding']['sha256']==cli['sha256'],f'{mode}: receipt CLI binding mismatch')
 check(d['resource_guard']=={'minimum_free_bytes':5368709120,'maximum_target_bytes':1073741824,'poll_seconds':1,'peak_target_sampled':True},f'{mode}: guard config mismatch')
 peaks=[]; frees=[]
 for c in d['commands']:
  check(c.get('guard_stop') is None, f'{mode} command {c["index"]}: guard stop')
  peaks.append(c.get('peak_target_bytes')); frees.append(c.get('free_bytes_after'))
  check(c.get('peak_target_bytes') is not None and c['peak_target_bytes']<=1024**3,f'{mode} command {c["index"]}: target cap')
  check(c.get('free_bytes_after') is not None and c['free_bytes_after']>=5*1024**3,f'{mode} command {c["index"]}: free-space floor')
  for stream in ('stdout','stderr'):
   rec=c['streams'][stream]; p=pathlib.Path(rec['path']); b=p.read_bytes()
   check(len(b)==rec['bytes'] and sha_bytes(b)==rec['sha256'],f'{mode} {c["index"]} {stream}: raw pin mismatch')
   all_raw.append({'mode':mode,'command_index':c['index'],'label':c['label'],'stream':stream,**rec})
   check(p.parent==root/'raw',f'{mode}: raw escaped output dir')
 # Ensure javac option in every compile argv is exactly selected; source/runtime paths as labels imply.
 compile_rows=[c for c in d['commands'] if c['label'].endswith('-compile')]
 check(len(compile_rows)==14,f'{mode}: expected 14 compile commands')
 javac_arg='-g' if mode=='debug' else '-g:none'
 check(all(javac_arg in c['argv'] and (('-g:none' not in c['argv']) if mode=='debug' else '-g' not in c['argv']) for c in compile_rows),f'{mode}: compile argv mode mismatch')
 # Original 17-case oracle: both JDK runtimes exactly match the archived oracle bytes.
 orig_rows=d['original_compile_rows']; check(len(orig_rows)==2,f'{mode}: original compile row count')
 original_runtime=[]
 v2pins=read_json('/private/tmp/jarde-em20-raw-alias-escape-baseline-prep-luna-v3/pins.json')
 old_stdout=v2pins['old_runner_stdout']
 for row in orig_rows:
  check(row['compile_exit']==0 and row['run_exit']==0 and row['class_set_exact'] is True,f'{mode}: original compile/runtime/classset')
  cmd=next(c for c in d['commands'] if c['label']==row['run_command']); current=pathlib.Path(cmd['streams']['stdout']['path']).read_bytes()
  ref=old_stdout['2' if row['label']=='javac8-original' else '5']; old=pathlib.Path(ref['path']).read_bytes()
  check(len(current)==ref['bytes'] and sha_bytes(current)==ref['sha256'] and current==old,f'{mode}: original runtime oracle differs')
  check(len(current.splitlines())==17,f'{mode}: expected 17 runtime oracle lines')
  original_runtime.append({'jdk':row['label'].split('-')[0],'compile_exit':row['compile_exit'],'run_exit':row['run_exit'],'class_paths':row['class_paths'],'stdout_bytes':len(current),'stdout_sha256':sha_bytes(current),'matches_archived_oracle':True})
 # Verify manifest entries, copied inputs, original class set, and v23 input jar.
 manifest=read_json(d['inputs_manifest_path']); check(manifest==d['input_entries'],f'{mode}: receipt manifest mismatch')
 input_summary=[]; full_target_source=None
 for entry in manifest['target_classes']+[manifest['runner']]:
  src=pathlib.Path(d['collector_config']['inputs_dir'])/entry['source']; copy=root/'inputs'/src.name
  for f in (src,copy):
   b=f.read_bytes(); check(len(b)==entry['bytes'] and sha_bytes(b)==entry['sha256'],f'{mode}: manifest source mismatch {f}')
  input_summary.append({'source':entry['source'],'bytes':entry['bytes'],'sha256':entry['sha256']})
  if entry.get('class')=='cf11.UpstreamNestedLoops':
   full_target_source=copy.read_text()
   check('rawAliasEscape' in full_target_source and 'handled' in full_target_source,f'{mode}: complete source lost target methods')
 check(manifest['target_classes'][0]['class']=='cf11.UpstreamNestedLoops' and manifest['runner']['class']=='cf11.Runner',f'{mode}: fixture identity')
 for row in orig_rows: check(row['class_paths']==EXPECTED_CLASS_PATHS,f'{mode}: original output classset differs')
 jar=root/'inputs/for-condition-controls.jar'
 with zipfile.ZipFile(jar) as z:
  names=sorted(z.namelist()); expected=sorted(c['class'].replace('.','/')+'.class' for c in manifest['target_classes'])
  check(names==expected,f'{mode}: JADX input jar class set')
  for name in names:
   expected_bytes=(root/'legs/javac23-original/classes'/name).read_bytes()
   check(z.read(name)==expected_bytes,f'{mode}: JADX jar class bytes mismatch {name}')
 # Verify the distinct JADX rename profiles and Jarde evidence argv are faithfully recorded.
 jadx_commands={c['label']:c for c in d['commands']}
 check('default' in d['jadx']['profiles'] and 'none' in d['jadx']['profiles'],f'{mode}: missing JADX profiles')
 check(d['jadx']['profiles']['default']['exact_target_sources'] and d['jadx']['profiles']['none']['exact_target_sources'],f'{mode}: JADX sources not exact target set')
 check('--rename-flags' not in jadx_commands['jadx-default']['argv'],f'{mode}: default JADX unexpectedly renamed')
 nargv=jadx_commands['jadx-none']['argv']; check('--rename-flags' in nargv and nargv[nargv.index('--rename-flags')+1]=='none',f'{mode}: JADX none profile flag missing')
 for prof in ('default','all'):
  for jdk in ('javac8','javac23'):
   c=next(x for x in d['commands'] if x['label']==f'{jdk}-jarde-{prof}-UpstreamNestedLoops-render')
   check(('--evidence' not in c['argv']) if prof=='default' else ('--evidence' in c['argv'] and c['argv'][c['argv'].index('--evidence')+1]=='all'),f'{mode}: Jarde evidence mode argv mismatch')
 # Each 4 JADX profile/JDK compile attempt fails at the preserved erased List<T> misuse; no runtime runs.
 jadx=[]
 for row in d['jadx_compile_rows']:
  c=next(x for x in d['commands'] if x['label']==row['compile_command'])
  err=pathlib.Path(c['streams']['stderr']['path']).read_text(errors='replace')
  check(row['compile_exit']==1 and row['run_command'] is None and row['run_exit'] is None,f'{mode}: JADX compile/runtime status')
  check('Integer' in err and 'String' in err and '.add(' in err,f'{mode}: expected type error absent')
  profile='none' if '-jadx-none' in row['label'] else 'default'
  jadx_source=pathlib.Path(row['source_pins'][0]['path']); jadx_lines=jadx_source.read_text().splitlines(); line_no=next((i for i,line in enumerate(jadx_lines,1) if '.add(' in line and ('target.' in line or 'list.' in line)),None)
  jadx.append({'label':row['label'],'profile':profile,'jdk':row['label'].split('-')[0],'compile_exit':1,'runtime':'not_run','source_path':str(jadx_source),'source_sha256':row['source_pins'][0]['sha256'],'source_line':line_no,'source_line_text':jadx_lines[line_no-1].strip() if line_no else None,'stderr_sha256':c['streams']['stderr']['sha256'],'first_diagnostic':next((x.strip() for x in err.splitlines() if '错误:' in x),None)})
 check(len(jadx)==4,f'{mode}: expected four JADX compile attempts')
 # All four reports: identity and source-map integrity, with special method evidence.
 report_summaries=[]; special={}
 for profile in d['jarde_profiles']:
  report_path=pathlib.Path(profile['report_pin']['path']); rp=pin_file(report_path)
  check(rp['sha256']==profile['report_pin']['sha256'] and rp['bytes']==profile['report_pin']['bytes'],f'{mode}: report pin mismatch')
  report=read_json(report_path); check(report['outcome']=='performed' and len(report['methods'])==11,f'{mode}: report/method count')
  class_digest=report['class']['class_bytes']['digest']; class_len=report['class']['class_bytes']['length']
  check(re.fullmatch(r'[0-9a-f]{64}',class_digest) is not None,f'{mode} {profile["label"]}: malformed report class digest')
  check(report.get('view',{}).get('snapshot')==class_digest,f'{mode} {profile["label"]}: report snapshot/class digest mismatch')
  jdk=profile['jdk']; class_pin=next(x for x in d['original_compile_rows'] if x['label']==jdk+'-original')['classes']
  original_pin=next(x for x in class_pin if x['path'].endswith('/cf11/UpstreamNestedLoops.class'))
  check(class_len==original_pin['bytes'],f'{mode} {profile["label"]}: report input class length differs')
  pinned_class=pin_file(original_pin['path'])
  check(pinned_class['bytes']==original_pin['bytes'] and pinned_class['sha256']==original_pin['sha256'],f'{mode} {profile["label"]}: original input class SHA-256 pin mismatch')
  methods=report_method_rows(report)
  method_set={x['method'] for x in methods}
  check(len(methods)==11 and all(x['source_map_state']=='complete' for x in methods),f'{mode} {profile["label"]}: methods/source-map incomplete')
  check(len(method_set)==11,f'{mode}: duplicate method identity')
  if report_summaries: check(method_set=={x['method'] for x in report_summaries[0]['methods']},f'{mode}: report method inventories differ')
  source_path=pathlib.Path(profile['source_pin']['path']); source_bytes=source_path.read_bytes()
  check(sha_bytes(source_bytes)==profile['source_pin']['sha256'] and len(source_bytes)==profile['source_pin']['bytes'],f'{mode}: generated source pin mismatch')
  check(source_bytes==report['text'].encode('utf-8'),f'{mode}: saved generated source differs from report text')
  source=source_bytes.decode('utf-8')
  # Body output for target methods must be present and identified under the expected descriptors.
  wanted={x['method']:x for x in methods if x['name'] in ('rawAliasEscape','handled')}
  check(set(wanted)=={'rawAliasEscape(Ljava/util/List;Ljava/util/List;)V','handled(Ljava/util/List;Ljava/util/List;)V'},f'{mode}: special method identities missing')
  for method_name in wanted:
   row=wanted[method_name]; check(row['source_map_segments']>0,f'{mode}: no source map segments for {method_name}')
   if method_name.startswith('rawAliasEscape'):
    check(row['content']=='contains_statements' and row['outcome']=='produced',f'{mode}: rawAliasEscape not recovered')
    check(any('ordinary_generic_source_unproved' in mark for mark in row['markers']),f'{mode}: rawAliasEscape generic refusal marker missing')
    check('local4.next()' in row['recovery_text'],f'{mode}: rawAliasEscape recovered text missing iterator value')
   if method_name.startswith('handled'):
    check(row['content']=='explanation_only' and 'jarde_refused_body();' in row['recovery_text'] and 'quoted fallback region' in row['recovery_text'],f'{mode}: handled refusal explanation/stub mismatch')
    check(any('explanation only' in mark for mark in row['markers']),f'{mode}: handled explanation-only marker missing')
    uncovered=[d['message'] for d in row['diagnostics'] if d['code']=='jre_region_uncovered_blocks']
    check(len(uncovered)==1 and '3 live block(s)' in uncovered[0] and '[7, 16, 47]' in uncovered[0],f'{mode}: handled uncovered block set changed')
   special.setdefault(profile['label'],{})[method_name]=row
  report_summaries.append({'label':profile['label'],'report_path':str(report_path),'source_path':str(source_path),'profile':'all' if '-all-' in profile['label'] else 'default','jdk':jdk,'class_digest':class_digest,'class_digest_algorithm':'BLAKE3','class_digest_matches_view_snapshot':True,'original_class_sha256':original_pin['sha256'],'class_bytes':class_len,'report_sha256':rp['sha256'],'source_sha256':sha_bytes(source_bytes),'methods':methods,'special_source_lines':{k:{'source_map_segments':v['source_map_segments'],'text_sha256':v['text_sha256']} for k,v in wanted.items()}})
 # default/all output is expected to be byte-identical within a compiler mode across both JDKs.
 source_hashes={r['source_sha256'] for r in report_summaries}
 source_bytes={pathlib.Path(r['source_path']).read_bytes() for r in report_summaries}
 check(len(source_hashes)==1 and len(source_bytes)==1,f'{mode}: default/all generated whole-class sources are not byte-identical')

 # Jarde combined failures; isolated attempts have same inputs except output directory and are not separate cases.
 jarde=[]; duplicated=[]
 for row in d['jarde_compile_rows']:
  c=next(x for x in d['commands'] if x['label']==row['compile_command']); err=pathlib.Path(c['streams']['stderr']['path']).read_text(errors='replace')
  check(row['compile_exit']==1 and row['run_command'] is None and row['run_exit'] is None,f'{mode}: Jarde compile/runtime status')
  isolated='-isolated-' in row['label']
  jarde.append({'label':row['label'],'jdk':row['label'].split('-')[0],'evidence_mode':'all' if '-all-' in row['label'] else 'default','kind':'isolated_duplicate' if isolated else 'combined','compile_exit':1,'runtime':'not_run','source_pins':row['source_pins'],'stderr_sha256':c['streams']['stderr']['sha256'],'diagnostics':[line.strip() for line in err.splitlines() if '错误:' in line or 'cannot find symbol' in line or '找不到符号' in line]})
 check(len(jarde)==8,f'{mode}: expected 8 Jarde compile attempts')
 for prof in ('default','all'):
  for jdk in ('javac8','javac23'):
   row=next(r for r in d['jarde_compile_rows'] if r['label']==f'{jdk}-jarde-{prof}-combined')
   c=next(c for c in d['commands'] if c['label']==row['compile_command'])
   stderr=pathlib.Path(c['streams']['stderr']['path']).read_text(errors='replace')
   errors=[line for line in stderr.splitlines() if '错误:' in line]
   if mode=='debug':
    check(len(errors)==2 and ':159: 错误:' in errors[0] and 'String无法转换为Integer' in errors[0] and ':201: 错误:' in errors[1] and '找不到符号' in errors[1],f'{mode} {row["label"]}: expected rawAliasEscape then handled compiler diagnostics')
   else:
    check(len(errors)==1 and ':200: 错误:' in errors[0] and '找不到符号' in errors[0] and '无法转换为Integer' not in stderr and '无法转换为String' not in stderr,f'{mode} {row["label"]}: expected handled-only compiler diagnostic')
 for prof in ('default','all'):
  for jdk in ('javac8','javac23'):
   a=next(r for r in d['jarde_compile_rows'] if r['label']==f'{jdk}-jarde-{prof}-combined')
   b=next(r for r in d['jarde_compile_rows'] if r['label']==f'{jdk}-jarde-{prof}-isolated-UpstreamNestedLoops')
   ca=next(c for c in d['commands'] if c['label']==a['compile_command']); cb=next(c for c in d['commands'] if c['label']==b['compile_command'])
   check(a['source_pins']==b['source_pins'],f'{mode}: isolated source pins not duplicate')
   check(normalize_compile_argv(ca['argv'])==normalize_compile_argv(cb['argv']),f'{mode}: isolated argv differs beyond output directory')
   check(ca['streams']['stderr']['sha256']==cb['streams']['stderr']['sha256'],f'{mode}: isolated stderr differs')
   duplicated.append({'jdk':jdk,'evidence_mode':prof,'combined_label':a['label'],'isolated_label':b['label'],'same_inputs':True,'same_stderr':True,'independent_case_count':1})
 # source text exact expected refusal and rawAlias output shape.
 src_default=root/'jarde/javac8-jarde-default-UpstreamNestedLoops/UpstreamNestedLoops.java'
 text=src_default.read_text()
 if mode=='debug': check('java.lang.Integer value;' in text and 'value = (java.lang.String) local4.next();' in text,f'{mode}: rawAlias merged-local source shape missing')
 else: check('java.lang.Integer local5 = (java.lang.Integer) local4.next();' in text and 'java.lang.String local5_2 = (java.lang.String) local4.next();' in text,f'{mode}: rawAlias no-LVT distinct-local source shape missing')
 handled_line=next((i for i,line in enumerate(text.splitlines(),1) if 'jarde_refused_body();' in line),None)
 results['modes'][mode]={'execution_receipt':pin_file(receipt_path),'status':d['status'],'command_count':len(d['commands']),'raw_stream_count':50,'raw_streams':None,'compiler_mode':d['javac_debug_info'],'resource_guard':d['resource_guard'],'observed_guard_extrema':{'max_target_bytes':max(peaks),'min_free_bytes':min(frees)},'source_tool_inputs_unchanged':d['source_tool_inputs_unchanged'],'source_tool_pin_count':len(d['source_tool_pins_before']),'source_tool_pins_sha256':sha_bytes(json.dumps(d['source_tool_pins_before'],sort_keys=True,separators=(',',':')).encode()),'source_tool_live_pin_match':True,'cli':{**cli,'mode':d['cli_mode']},'build_receipt':receipt,'manifest_inputs':input_summary,'full_source_methods_present':{'rawAliasEscape':True,'handled':True},'original_runtime_oracles':original_runtime,'classset':{'expected_original_paths':EXPECTED_CLASS_PATHS,'original_exact_for_both_jdks':True,'jadx_jar_entries_exact':True},'jadx_rejections':jadx,'jarde_reports':report_summaries,'jarde_compile_rejections':jarde,'combined_isolated_duplicate_pairs':duplicated,'key_source_locations':{'debug_raw_alias_assignment_line':159 if mode=='debug' else None,'handled_stub_line':handled_line}}
# Cross-mode expected scenario comparison and mode difference.
check(total_commands==50,'expected 50 total command rows')
check(len(all_raw)==100,'expected 100 raw stream records')
for mode in MODES: results['modes'][mode]['raw_streams']=all_raw[:]
# Replace repeated raw records with per-mode entries for compactness.
for mode in MODES: results['modes'][mode]['raw_streams']=[x for x in all_raw if x['mode']==mode]
check(results['modes']['debug']['original_runtime_oracles']==results['modes']['none']['original_runtime_oracles'],'original runtime differs across compiler debug modes')
results['cross_mode']={'original_17_case_oracle_same':True,'original_stdout_sha256':results['modes']['debug']['original_runtime_oracles'][0]['stdout_sha256'],'debug_raw_alias_escape_compile_error':'asserted in each combined stderr: String cannot be converted to Integer at UpstreamNestedLoops.java:159','none_raw_alias_escape_type_error_absent':'asserted absent in each combined stderr','remaining_jarde_compile_error':'handled() explanation-only stub at generated source line 201 (-g), line 200 (-g:none)','neither_jarde_mode_has_generated_runtime':True,'interpretation':'-g exposes a merged local type conflict in rawAliasEscape; -g:none removes that specific compiler error, but full generated source still fails on handled and therefore has no runtime result.'}
results['totals']={'execution_receipts':2,'commands':total_commands,'raw_streams':len(all_raw),'jarde_reports':8,'jadx_rejected_compile_attempts':8,'jarde_compile_attempts_including_duplicate_isolated':16,'independent_jarde_compile_input_cases':8,'original_jdk_runs_per_mode':2,'oracle_scenarios_per_jdk_run':17}
# Cross-mode report method identities must remain exact even though local source spelling changes.
sets=[]
for mode in MODES:
 sets.append({r['method'] for r in results['modes'][mode]['jarde_reports'][0]['methods']})
check(sets[0]==sets[1], 'debug/none method identity inventories differ')
# Ensure stream pin references are complete; references only, never copy the raw files.
out=BASE/'jarde-em20-current-baseline-audit-luna-v1'
out.mkdir(exist_ok=True)
(out/'audit.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'totals':results['totals'],'cross_mode':results['cross_mode'],'mode_summary':{m:{k:v for k,v in results['modes'][m].items() if k in ('execution_receipt','status','command_count','compiler_mode','observed_guard_extrema','source_tool_inputs_unchanged','cli','build_receipt','classset','key_source_locations')} for m in MODES},'audit_json':str(out/'audit.json')},indent=2,ensure_ascii=False))
