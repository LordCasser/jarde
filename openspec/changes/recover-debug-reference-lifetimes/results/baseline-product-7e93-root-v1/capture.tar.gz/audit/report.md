# EM20 当前 baseline 独立只读验收

审计对象是 root 串行生成的 `debug` 与 `none` 两个 baseline 输出。没有重跑 collector、Cargo、JDK、JADX 或 CLI；receipt、raw stream 和报告原件均保留在原路径。详细逐项数据及 100 条 raw 引用见 `audit.json`，路径/SHA 索引见 `pins.json`。

两份 receipt 都是 `status=observed`，每份 25 条命令、50 个 stdout/stderr raw stream；总计 50 条命令和 100 份 raw。全部 raw 路径、字节数和 SHA-256 与 receipt 一致。两模式均记录 18 个 source/tool pins，before/after 完全相同，且当前文件仍与 pin 一致。v12 CLI 当前文件 mode 为 `0555`，SHA `c8c18f26a256027262b514455c33f24d0ae1cbcec658e3d6ab76b2c3a9c2ccfd`；对应 build receipt SHA `887bff1cb4999f13d03e9d3e6b411a032c46ce26151b0f566ea78448a7869401`。

实际 javac argv 与记录一致：`debug` 是 `-g`，`none` 是 `-g:none`。guard 配置保留 5 GiB free-space 下限、1 GiB target 上限、1 秒轮询。两次记录都没有 guard stop；最大 target 采样 0 bytes，最低 free-space 分别为 22020132864 bytes（debug）与 21904326656 bytes（none）。完整 source manifest 的每项均与原件和输出副本的字节数/SHA 相符；target source 仍包含完整 `UpstreamNestedLoops`、`rawAliasEscape` 与 `handled`，Runner 也保留。JADX 输入 JAR 精确包含 manifest target class；两份 original 编译都只产出预期 `cf11/UpstreamNestedLoops.class` 与 `cf11/Runner.class`。

两个 JDK 的 original class 与 Runner 均编译成功、运行退出码为 0、class set 精确；每个 Runner 输出 17 个场景，逐字节匹配既有 oracle，SHA 均为 `50ea25f5e9f74bc8d69b3dc945cd9ba006ef9a615a9e149c73e64c33f70f6231`。

JADX default 与 rename-none 两个 profile 在两个 JDK 下的四次 compile 都以 1 退出，均未进入 runtime。default 源在 `UpstreamNestedLoops.java:88` 调用 `target.add(value)`；rename-none 源在 `:89` 调用 `list.add(it.next())`。两者都保留 `List<String>` 目标与 `Integer` 值的冲突。每种 javac debug 模式的四次 profile/JDK 尝试均由实际 stderr 断言为相应类型错误；所有 raw stderr SHA 都记录在 `audit.json`。

每个 Jarde receipt 有四个独立的 combined compile 输入（default/all × javac8/javac23），全部 compile 退出码 1，全部没有 generated-source runtime。每个 combined stderr 都被实际断言：`-g` 下依次出现第 159 行 `String` 无法转换为 `Integer` 和第 201 行 `handled` stub 找不到符号；`-g:none` 下只有第 200 行 `handled` stub 找不到符号，rawAliasEscape 类型错误确实缺席。另四个 `isolated` 命令逐对使用同一 generated source 与 Runner pins，除各自输出目录路径外 argv 相同，stderr 也相同；它们是 combined 尝试的重复输入，不计作额外场景。

八份 Jarde JSON report 均完整读取并检查：每份有 11 个方法；method name/descriptor 与恢复身份一致；方法集合一致；每个方法的 source-map segment 都落在其 body 文本字节范围内，source-map origin 的 owner/member identity 与对应方法一致；保存的 `.java` 字节等于报告 `text`。八份 default/all × JDK generated whole-class `.java` 文件经 SHA 与原始 bytes 双重断言完全一致。报告 `class.class_bytes.digest` 使用 BLAKE3，而原 class receipt pin 使用 SHA-256，因此两者不能直接比较；审计验证 report digest 与同报告 `view.snapshot` 相同，report class length 与原 class pin 长度相同，并独立复核原 class 的 SHA-256 pin 当前仍成立。逐报告路径、摘要、方法身份和 source-map 数量都在 `audit.json` 中。

`rawAliasEscape(Ljava/util/List;Ljava/util/List;)V` 在八份报告中都作为有语句的 recovered body 存在，身份及 source-map 均完整；generic Signature 声明投影仍标记 `ordinary_generic_source_unproved`。`-g` 输出把重用 local 合成 `Integer value`，随后在第 159 行将 `(String) local4.next()` 赋给它；`-g:none` 输出把两个作用域分别写为 `Integer local5` 与 `String local5_2`，不再出现这项类型错误。

`handled(Ljava/util/List;Ljava/util/List;)V` 在八份报告中都明确是 `explanation_only`：每份 nested report 恰有一条 uncovered-block 诊断，精确列出 `[7, 16, 47]`；局部 3 的定义与使用跨越 quoted fallback region，因此输出 `jarde_refused_body()` stub（debug 第 201 行，none 第 200 行）。两种 mode 的全类 compile 都失败，均没有 generated-source runtime 证据，也不能记作行为通过。

## 审计产物 pins

- `audit_baselines.py`: `d5f81167e77f08f91410e1690fcfed22d6423ca1e89971cac415553622507f46`
- `audit.json`: `6948f44e342efff64c17c79b7f9330ff38bc3a8b7dea2bf458809b187b2563fe`
