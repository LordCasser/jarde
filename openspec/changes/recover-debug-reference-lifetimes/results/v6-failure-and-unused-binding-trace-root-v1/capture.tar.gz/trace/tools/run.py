from pathlib import Path
import subprocess,hashlib,json,stat
P=Path('/private/tmp/jarde-reference-lvt-read-trace-prep-root-v1')
S=Path('/Users/lordcasser/workspace/projects/jarde/crates/jarde-java/src/reuse.rs')
pins=json.loads((P/'pins.json').read_text())
base=(P/'base-reuse.rs').read_bytes()
assert hashlib.sha256(S.read_bytes()).hexdigest()==pins['base']
mode=stat.S_IMODE(S.stat().st_mode)
try:
 S.write_bytes((P/'candidate-reuse.rs').read_bytes())
 r=subprocess.run(['python3','/private/tmp/jarde-loop-focused-runner-root-v1.py','/private/tmp/jarde-reference-lvt-read-trace-run-root-v1',str(P/'commands.json')])
finally:
 S.write_bytes(base);S.chmod(mode)
 assert hashlib.sha256(S.read_bytes()).hexdigest()==pins['base']
 print('reference trace source restored')
raise SystemExit(r.returncode)
