#!/usr/bin/env python3
"""Root guarded candidate validation. Never accepts a product from command exits alone."""
import sys, os, json, re, hashlib, shutil, subprocess, importlib.util, datetime
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
OUT = Path(sys.argv[1])
SPEC = Path(sys.argv[2])
assert not OUT.exists() and not (ROOT / 'target').exists()
assert shutil.disk_usage(ROOT).free >= 5 * 1024**3
def pin(p):
    p = Path(p); b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
def module(p, expected, name):
    assert pin(p)['sha256'] == expected
    spec = importlib.util.spec_from_file_location(name, p)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
focus = module(Path('/private/tmp/jarde-cf11-structured-list-focused-runner-prep-luna-v7/run.py'), 'c8b1016eaf9506912876fd92e8544d5f78e472401beb99e3fd75b549607956bc', 'focus')
focus.CLOSURE_MODULE = module(Path('/private/tmp/jarde-iterator-assignment-full-validation-prep-luna-v2/workspace_runner.py'), '63e52b55fe5d20d5f2ece98ac80676ccdb2de8dfd33d7199b688e075fb1e9673', 'closure')
guard = module(ROOT / 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py', '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33', 'guard')
scanner = module(ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py', 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7', 'scanner')
commands = json.loads(SPEC.read_text())
OUT.mkdir(); (OUT / 'raw').mkdir()
guard.ROOT = ROOT; guard.OUT = OUT / 'raw'
guard.target_bytes = lambda: scanner.target_bytes(ROOT)
guard.expected_test_summaries = lambda i, raw: None
guard.command_stream = pin
env_values = {'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'RUST_TEST_THREADS': '1', 'CARGO_TERM_COLOR': 'always'}
env = {k:v for k,v in os.environ.items() if k not in ('RUST_MIN_STACK','CARGO_TARGET_DIR','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH')}
env.update(env_values); guard.ENV_VALUES = env_values
record = {'status':'running','runner':pin(__file__),'command_spec':pin(SPEC),'source_manifest_before':focus.source_manifest(),'commands':[],'default_stack':True,'guard':{'minimum_free_bytes':5*1024**3,'maximum_target_bytes':1024**3,'interval_seconds':1}}
def save():
    (OUT/'execution.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
save()
try:
    for argv in commands:
        row = guard.run_command(len(record['commands'])+1,argv,env)
        record['commands'].append(row); save()
        raw = Path(row['streams']['stdout']['path']).read_text()
        raw = re.sub(r'\x1b\[[0-9;]*m','',raw)
        row['actual_test_summaries'] = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)
        save()
        assert row['exit_code']==0 and row['guard_stop'] is None, 'Command failed or guard stopped'
        if argv[:2] == ['cargo','test']:
            assert row['actual_test_summaries'] and all(x[0]=='ok' and int(x[1])>0 and x[2]=='0' for x in row['actual_test_summaries']), 'Missing or failing test summaries'
        if argv[:2] == ['cargo','build']:
            cli = OUT/'candidate-cli'; shutil.copyfile(ROOT/'target/debug/jarde-cli',cli); cli.chmod(0o555); record['cli']=pin(cli)
    record['status']='commands_passed_pending_independent_acceptance'
except BaseException as e:
    record['status']='failed'; record['failure']={'type':type(e).__name__,'message':str(e)}
finally:
    record['source_manifest_after']=focus.source_manifest()
    i = len(record['commands'])+1
    so=OUT/'raw'/f'{i}.stdout.raw';se=OUT/'raw'/f'{i}.stderr.raw'
    with so.open('xb') as a,se.open('xb') as b:
        rc=subprocess.run(['cargo','clean'],cwd=ROOT,env=env,stdout=a,stderr=b).returncode
    record['commands'].append({'index':i,'argv':['cargo','clean'],'exit_code':rc,'streams':{'stdout':pin(so),'stderr':pin(se)},'cleanup_only':True})
    record['target_absent']=not (ROOT/'target').exists()
    if rc!=0 or not record['target_absent']: record['status']='failed'
    record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat(); save()
    print(json.dumps({k:record.get(k) for k in ('status','failure','target_absent','cli')}))
sys.exit(0 if record['status']=='commands_passed_pending_independent_acceptance' else 1)
