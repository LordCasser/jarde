# EM20 `rawAliasEscape` baseline prep v3

v3 is a fresh private copy of v2. It preserves the complete `UpstreamNestedLoops.java` and `Runner.java` inputs, manifest, original/JADX/Jarde source flow, pinned JDK/JADX/resource guard/scanner/classfile parser, and the historical 25-command matrix. v2 and its receipts remain untouched.

The v3 collector makes javac compiler debug information explicit with `--javac-debug debug|none` (default `debug`). `debug` passes `-g`; `none` passes `-g:none`. This option applies to original, JADX-rendered, and Jarde-generated full-class compile commands on both pinned JDKs. The selected mode and exact compiler argument are recorded in `collector_config` and the top-level execution receipt. Inputs and generated Java remain unchanged.

Compiler debug information is independent of the presentation modes in this experiment. Jarde `default` and `all` select evidence reporting (`--evidence all` for `all`); they do not choose javac debug metadata. JADX `default` and `none` compare normal name handling with `--rename-flags none`; that option also does not choose javac debug metadata. Use `BASELINE_DEBUG_INFO=none` to test the no-debug-attributes compile path and `BASELINE_DEBUG_INFO=debug` for the `-g` path.

The latest frozen CLI and receipt are pinned to v12: CLI `/private/tmp/jarde-ordered-field-final-check-root-v12/candidate-cli`, SHA-256 `c8c18f26a256027262b514455c33f24d0ae1cbcec658e3d6ab76b2c3a9c2ccfd`; receipt `/private/tmp/jarde-ordered-field-final-check-root-v12/execution.json`, SHA-256 `887bff1cb4999f13d03e9d3e6b411a032c46ce26151b0f566ea78448a7869401`. Both are recorded in `pins.json`.

After the root confirms that its active toolchain session is terminal and authorizes the serial baseline runs, invoke the following twice, using a fresh output path for each run. The first command enables javac debug attributes; the second removes them. They are separate invocations and must not run concurrently:

```sh
CURRENT_CLI_PATH=/private/tmp/jarde-ordered-field-final-check-root-v12/candidate-cli \
CURRENT_CLI_SHA256=c8c18f26a256027262b514455c33f24d0ae1cbcec658e3d6ab76b2c3a9c2ccfd \
CURRENT_BUILD_RECEIPT=/private/tmp/jarde-ordered-field-final-check-root-v12/execution.json \
CURRENT_BUILD_RECEIPT_SHA256=887bff1cb4999f13d03e9d3e6b411a032c46ce26151b0f566ea78448a7869401 \
BASELINE_DEBUG_INFO=debug \
BASELINE_OUT=/private/tmp/jarde-em20-raw-alias-escape-baseline-debug-root-v1 \
sh /private/tmp/jarde-em20-raw-alias-escape-baseline-prep-luna-v3/run-current.sh
```

```sh
CURRENT_CLI_PATH=/private/tmp/jarde-ordered-field-final-check-root-v12/candidate-cli \
CURRENT_CLI_SHA256=c8c18f26a256027262b514455c33f24d0ae1cbcec658e3d6ab76b2c3a9c2ccfd \
CURRENT_BUILD_RECEIPT=/private/tmp/jarde-ordered-field-final-check-root-v12/execution.json \
CURRENT_BUILD_RECEIPT_SHA256=887bff1cb4999f13d03e9d3e6b411a032c46ce26151b0f566ea78448a7869401 \
BASELINE_DEBUG_INFO=none \
BASELINE_OUT=/private/tmp/jarde-em20-raw-alias-escape-baseline-nodebug-root-v1 \
sh /private/tmp/jarde-em20-raw-alias-escape-baseline-prep-luna-v3/run-current.sh
```

Each run retains the existing 5 GiB free-space, 1 GiB target-size, and one-second polling guard. The collector retains the original 25-command source/class/JADX/Jarde workflow and its full class compile/runtime failure handling; it does not assume any new result. Original compile/runtime and raw failures are captured, generated-source compile failures are preserved, and generated-source runtime is attempted only after successful compilation. `handled` remains in the original complete class as authored.

This prep has not been executed. `static-check.json` records static validation only. `pins.json` binds the collector, runner, full source inputs, CLI/receipt, and existing tool pins. `diff-from-v1.patch` is retained as historical v2 preparation evidence.
