# Outer try boundary comparison preparation

This is a private, unexecuted preparation. It does not edit the shared repository, compile Java, run JDK/JADX/Jarde, or claim that proxy-generated classes have any particular physical class set. The full target is referenced from the existing pinned v3 fixture at `/private/tmp/jarde-em20-raw-alias-escape-baseline-prep-luna-v3/inputs/UpstreamNestedLoops.java` (4,543 bytes); no second target copy is stored here. The target remains the complete 11-method class, including `handled` and the other existing methods. The existing full-class collector still owns and preserves the original 17 `Runner` scenarios; this boundary harness supplements them.

`OuterTryBoundaryRunner.java` uses only `java.lang.reflect.Proxy` and `InvocationHandler` lambdas to implement `List`/`Iterator` behavior. Ten scenarios cover success and empty iteration plus a `RuntimeException` and an `Error` injected separately at `input.iterator()`, `Iterator.hasNext()`, `Iterator.next()`, and `output.add()`. Every line records the observed exception type/message, ordered calls, `UpstreamNestedLoops.effects`, and output contents. Nothing in the harness pre-fills the expected outcome. The lambda-based harness is intended to avoid declared helper classes, but its physical class set is deliberately left for root's actual javac receipt to establish.

`collect_boundary_matrix.py` accepts two already completed fresh full-class collector output directories, one with `-g` and one with `-g:none`, and exact CLI/build-receipt paths and SHA-256 values. Before issuing comparison commands, it checks each full-class collector receipt’s recorded command inventory and all 5 GiB/1 GiB/1-second guard records for each matrix; command count may vary when compile failures change whether isolated retries are needed; verifies both matrix receipts bind the supplied mode-0555 CLI and build receipt; verifies the full original target, original class pins, exact JADX source sets, and actual Jarde default/all reports with 11 unique methods; confirms the original `Runner.java` and 17-line original runtime outputs remain present; and confirms each generated Jarde Java file is byte-identical to its 11-method report text. It then reuses the pinned v3 collector's `Recorder`, pinned process-group guard, scanner, JDK manifest, and JDK8/JDK23 tools.

For each compiler-debug mode it stages the original target, JADX default source, JADX rename-none source, Jarde default source, and Jarde all source byte-for-byte with the harness, then compiles each pair under both JDKs. Runtime is attempted only after a successful compile. The exact resulting physical class paths, compiler/runtime exits, stream pins, and source identities are recorded as observed; a failed generated-source compile remains a compile failure with no runtime. The original four runs form the actual oracle: their exit/stdout/stderr equality is computed from raw output, and each successful source run is compared with the original run for the same JDK and compiler mode. No source is edited to make a compile pass.

After root has produced and accepted the two fresh full-class matrix outputs and has finished its active toolchain session, use the actual CLI/build-receipt pins supplied by root. Replace the example matrix paths with those two fresh execution directories; do not point this comparison at the older `/private/tmp/jarde-em20-raw-alias-escape-baseline-*-current-root-v1` evidence. The output directory must be new:

```sh
python3 /private/tmp/jarde-outer-try-boundary-comparison-prep-luna-v1/collect_boundary_matrix.py \
  --debug-matrix /private/tmp/ROOT_FRESH_DEBUG_FULLCLASS_MATRIX \
  --none-matrix /private/tmp/ROOT_FRESH_NONE_FULLCLASS_MATRIX \
  --cli /private/tmp/ROOT_FROZEN_CLI \
  --cli-sha256 ROOT_FROZEN_CLI_SHA256 \
  --build-receipt /private/tmp/ROOT_CLI_BUILD_RECEIPT.json \
  --build-receipt-sha256 ROOT_CLI_BUILD_RECEIPT_SHA256 \
  --out /private/tmp/jarde-outer-try-boundary-comparison-root-v1
```

The collector refuses to overwrite an existing output. It writes a full `execution.json`, one raw stdout/stderr pair per actual command, staged-source copies, per-run classes and observed class-set rows, and before/after tool/input pins. It makes no prior claim that any class set is exact or any compilation/runtime passes. Preparation validation was limited to Python AST parsing and static source/pin inspection; the collector and harness have not been compiled or executed.
