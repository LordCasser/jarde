#!/usr/bin/env python3
"""Prepare paired full-class outer-try boundary evidence; never assume results pass."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, shutil, sys
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
EXPECTED_TARGET = 'cf11.UpstreamNestedLoops'
EXPECTED_HARNESS = 'cf11.OuterTryBoundaryRunner'
EXPECTED_CLASS_PATHS = sorted(['cf11/UpstreamNestedLoops.class', 'cf11/OuterTryBoundaryRunner.class'])
MIN_FREE, MAX_TARGET = 5 * 1024**3, 1024**3


def sha(data): return hashlib.sha256(data).hexdigest()
def pin(path):
    path=Path(path); data=path.read_bytes(); return {'path':str(path.resolve()),'bytes':len(data),'sha256':sha(data)}
def read_json(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def write_json(path,value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def check(condition,message):
    if not condition: raise SystemExit(message+'; no comparison command run')
def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module


def method_identities(report):
    rows=[]
    for entry in report.get('methods',[]):
        identity=entry.get('item',{}).get('identity',{})
        member=identity.get('member',identity)
        def decode(value):
            return bytes(value).decode('utf-8') if isinstance(value,list) else value
        rows.append(decode(member.get('name'))+decode(member.get('descriptor')))
    return rows


def validate_matrix(root,mode,cli,cli_sha,build_receipt,build_sha):
    root=Path(root).resolve(strict=True); receipt_path=root/'execution.json'; receipt=read_json(receipt_path)
    check(receipt.get('status')=='observed',f'{mode} matrix receipt not observed')
    check(receipt.get('actual_command_count')==len(receipt.get('commands',[])) and receipt.get('actual_command_count',0)>0,f'{mode} full-class collector command inventory is incomplete')
    for command in receipt['commands']:
        check(command.get('guard_stop') is None,f'{mode} baseline command stopped by guard: {command.get("label")}')
        check(command.get('peak_target_bytes') is not None and command['peak_target_bytes']<=MAX_TARGET and command.get('free_bytes_after') is not None and command['free_bytes_after']>=MIN_FREE,f'{mode} baseline guard extrema exceed configured bounds')
        for stream_name in ('stdout','stderr'):
            stream=command['streams'][stream_name]; stream_path=Path(stream['path']).resolve(strict=True); raw=stream_path.read_bytes()
            check(stream_path.parent==root/'raw' and len(raw)==stream['bytes'] and sha(raw)==stream['sha256'],f'{mode} baseline raw stream pin mismatch: {stream_path}')
    check(receipt.get('javac_debug_info')=={'mode':mode,'argument':'-g' if mode=='debug' else '-g:none'},f'{mode} matrix compiler mode mismatch')
    check(receipt.get('source_tool_inputs_unchanged') is True and receipt.get('source_tool_pins_before')==receipt.get('source_tool_pins_after'),f'{mode} matrix source/tool pins changed')
    check(len(receipt.get('original_compile_rows',[]))==2 and len(receipt.get('jadx',{}).get('profiles',{}))==2 and len(receipt.get('jarde_profiles',[]))==4,f'{mode} full-class source matrix inventory incomplete')
    legacy=[]
    for original_row in receipt['original_compile_rows']:
        check(original_row.get('compile_exit')==0 and original_row.get('run_exit')==0 and original_row.get('class_set_exact') is True,f'{mode} original full-class/Runner run absent')
        run_row=next(row for row in receipt['commands'] if row['label']==original_row['run_command'])
        stdout=Path(run_row['streams']['stdout']['path']).read_bytes(); stderr=Path(run_row['streams']['stderr']['path']).read_bytes()
        check(len(stdout.splitlines())==17,f'{mode} original Runner output does not retain 17 scenarios')
        legacy.append({'jdk':original_row['label'].split('-')[0],'exit_code':run_row.get('exit_code'),'stdout_bytes':len(stdout),'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr),'scenario_lines':len(stdout.splitlines())})
    check(receipt.get('resource_guard')=={'minimum_free_bytes':MIN_FREE,'maximum_target_bytes':MAX_TARGET,'poll_seconds':1,'peak_target_sampled':True},f'{mode} matrix guard settings mismatch')
    cli_pin=pin(cli); build_pin=pin(build_receipt)
    check(cli_pin['sha256']==cli_sha and (Path(cli).stat().st_mode&0o777)==0o555,f'{mode} supplied CLI pin/mode mismatch')
    check(build_pin['sha256']==build_sha,f'{mode} supplied build receipt SHA mismatch')
    check(receipt.get('cli',{}).get('path')==str(Path(cli).resolve()) and receipt['cli'].get('sha256')==cli_sha,f'{mode} matrix did not use supplied CLI')
    check(receipt.get('build_receipt',{}).get('path')==str(Path(build_receipt).resolve()) and receipt['build_receipt'].get('sha256')==build_sha,f'{mode} matrix build receipt identity mismatch')
    binding=receipt.get('build_receipt_cli_binding',{})
    check(binding.get('path')==str(Path(cli).resolve()) and binding.get('sha256')==cli_sha and binding.get('bytes')==cli_pin['bytes'],f'{mode} build receipt CLI binding mismatch')
    manifest=read_json(receipt['inputs_manifest_path'])
    check(manifest==receipt.get('input_entries') and manifest.get('package')=='cf11' and manifest.get('source_level')=='Java 8',f'{mode} source manifest mismatch')
    targets=[x.get('class') for x in manifest.get('target_classes',[])]
    check(targets==[EXPECTED_TARGET],f'{mode} target must remain the complete UpstreamNestedLoops class')
    original=root/'inputs'/'UpstreamNestedLoops.java'; target_pin=pin(original)
    target_entry=manifest['target_classes'][0]
    check(target_pin['bytes']==target_entry['bytes'] and target_pin['sha256']==target_entry['sha256'],f'{mode} copied full target source pin mismatch')
    target_text=original.read_text(encoding='utf-8')
    check(all(name+'(' in target_text for name in ('handled','rawAliasEscape')),f'{mode} full target source missing audit methods')
    runner_source=root/'inputs'/'Runner.java'; runner_entry=manifest.get('runner',{}); runner_pin=pin(runner_source)
    check(runner_entry.get('class')=='cf11.Runner' and runner_pin['bytes']==runner_entry['bytes'] and runner_pin['sha256']==runner_entry['sha256'],f'{mode} original full Runner source pin mismatch')
    profiles={}
    for name in ('default','none'):
        profile=receipt['jadx']['profiles'][name]
        check(profile.get('exact_target_sources') is True and len(profile.get('sources',[]))==1,f'{mode} JADX {name} target set not exact')
        source_pin=profile['sources'][0]; source=Path(source_pin['path']).resolve(strict=True); actual=pin(source)
        check(actual['bytes']==source_pin['bytes'] and actual['sha256']==source_pin['sha256'],f'{mode} JADX {name} source pin mismatch')
        profiles['jadx-'+name]={'path':str(source),'pin':actual,'report_path':None,'report_pin':None}
    original_classes={row['label'].split('-')[0]:row.get('classes',[]) for row in receipt.get('original_compile_rows',[])}
    for profile in receipt.get('jarde_profiles',[]):
        source_pin=profile.get('source_pin'); report_pin=profile.get('report_pin')
        check(profile.get('render_exit')==0 and source_pin is not None and report_pin is not None,f'{mode} Jarde profile lacks a real report/source')
        command=next(row for row in receipt['commands'] if row['label']==profile['render_command'])
        check(command['argv'][0]==str(Path(cli).resolve()),f'{mode} Jarde report was not rendered by supplied CLI')
        source=Path(source_pin['path']).resolve(strict=True); report_path=Path(report_pin['path']).resolve(strict=True)
        actual_source=pin(source); actual_report=pin(report_path); report=read_json(report_path)
        check(actual_source['bytes']==source_pin['bytes'] and actual_source['sha256']==source_pin['sha256'],f'{mode} Jarde generated source pin mismatch')
        check(actual_report['bytes']==report_pin['bytes'] and actual_report['sha256']==report_pin['sha256'],f'{mode} Jarde report pin mismatch')
        check(report.get('outcome')=='performed' and len(report.get('methods',[]))==11,f'{mode} Jarde report is not whole-class/11-method')
        identities=method_identities(report)
        check(len(identities)==11 and len(set(identities))==11 and 'handled(Ljava/util/List;Ljava/util/List;)V' in identities and 'rawAliasEscape(Ljava/util/List;Ljava/util/List;)V' in identities,f'{mode} Jarde report omits or duplicates whole-class method identities')
        digest=report.get('class',{}).get('class_bytes',{}).get('digest')
        check(isinstance(digest,str) and len(digest)==64 and report.get('view',{}).get('snapshot')==digest and report.get('class',{}).get('location',{}).get('snapshot')==digest,f'{mode} Jarde class/report snapshot identity mismatch')
        jdk_classes=original_classes.get(profile.get('jdk'),[])
        target_class=next((c for c in jdk_classes if c['path'].endswith('/cf11/UpstreamNestedLoops.class')),None)
        check(target_class is not None and report['class']['class_bytes']['length']==target_class['bytes'],f'{mode} Jarde report class length differs from original class pin')
        check(actual_source['bytes']==len(report.get('text','').encode('utf-8')) and source.read_bytes()==report['text'].encode('utf-8'),f'{mode} generated Java changed from report text')
        if profile.get('mode') in ('default','all') and profile.get('jdk') in ('javac8','javac23'):
            profiles['jarde-'+profile['mode']+'-'+profile['jdk']]={'path':str(source),'pin':actual_source,'report_path':str(report_path),'report_pin':actual_report,'method_count':len(identities),'method_identities':identities}
    check(set(profiles)=={'jadx-default','jadx-none','jarde-default-javac8','jarde-all-javac8','jarde-default-javac23','jarde-all-javac23'},f'{mode} source profile inventory incomplete')
    check(all(profiles['jarde-'+m+'-'+j]['report_pin'] for m in ('default','all') for j in ('javac8','javac23')),f'{mode} Jarde profile records incomplete')
    return {'root':root,'receipt_path':receipt_path,'receipt':receipt,'target_source':original,'target_pin':target_pin,'runner_source':runner_source,'runner_pin':runner_pin,'sources':profiles,'manifest_pin':pin(receipt['inputs_manifest_path']),'legacy_runner_oracles':legacy}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--debug-matrix',type=Path,required=True,help='fresh full-class -g collector output directory')
    p.add_argument('--none-matrix',type=Path,required=True,help='fresh full-class -g:none collector output directory')
    p.add_argument('--cli',type=Path,required=True); p.add_argument('--cli-sha256',required=True)
    p.add_argument('--build-receipt',type=Path,required=True); p.add_argument('--build-receipt-sha256',required=True)
    p.add_argument('--out',type=Path,required=True,help='new output directory; overwrite is refused')
    a=p.parse_args()
    for key,value in vars(a).items():
        if isinstance(value,Path): setattr(a,key,value.resolve())
    check(not a.out.exists(),f'refuse overwrite: {a.out}')
    cli_pin=pin(a.cli); build_pin=pin(a.build_receipt)
    check(cli_pin['sha256']==a.cli_sha256 and (a.cli.stat().st_mode&0o777)==0o555,'CLI exact SHA/mode mismatch')
    check(build_pin['sha256']==a.build_receipt_sha256,'build receipt SHA mismatch')
    receipt=read_json(a.build_receipt)
    binding=receipt.get('cli',{})
    check(receipt.get('status')=='commands_passed_pending_independent_acceptance' and binding.get('path')==str(a.cli) and binding.get('sha256')==a.cli_sha256 and binding.get('bytes')==cli_pin['bytes'],'build receipt does not bind exact CLI')
    matrices={
        'debug':validate_matrix(a.debug_matrix,'debug',a.cli,a.cli_sha256,a.build_receipt,a.build_receipt_sha256),
        'none':validate_matrix(a.none_matrix,'none',a.cli,a.cli_sha256,a.build_receipt,a.build_receipt_sha256),
    }
    check(matrices['debug']['target_pin']['sha256']==matrices['none']['target_pin']['sha256'],'paired matrices use different complete target source')
    pins_file='/private/tmp/jarde-em20-raw-alias-escape-baseline-prep-luna-v3/pins.json'
    prep_pins=read_json(pins_file)
    collector_path=Path('/private/tmp/jarde-em20-raw-alias-escape-baseline-prep-luna-v3/collect_controls.py').resolve(strict=True)
    collector_sha=prep_pins['prepared_collector']['sha256']
    matrix_config=matrices['debug']['receipt']['collector_config']
    guard_path=Path(matrix_config['guard']).resolve(strict=True); guard_sha=matrix_config['guard_sha256']
    scanner_path=Path(matrix_config['scanner']).resolve(strict=True); scanner_sha=matrix_config['scanner_sha256']
    jdk_manifest=Path(prep_pins['jdk_manifest']['path']).resolve(strict=True); jdk_manifest_sha=prep_pins['jdk_manifest']['sha256']
    check(pin(collector_path)['sha256']==collector_sha and pin(guard_path)['sha256']==guard_sha and pin(scanner_path)['sha256']==scanner_sha and pin(jdk_manifest)['sha256']==jdk_manifest_sha,'pinned collector/tool guard inputs changed')
    helper=load_module(collector_path,'outer_try_baseline_collector')
    guard=helper.import_pinned(guard_path,guard_sha,'outer_try_guard')
    scanner=helper.import_pinned(scanner_path,scanner_sha,'outer_try_scanner')
    guard.OUT=a.out/'raw'; guard.ROOT=ROOT; guard.expected_test_summaries=lambda index,stdout:None; guard.ENV_VALUES={}
    guard.target_bytes=lambda:scanner.target_bytes(ROOT)
    guard.command_stream=lambda path:{'path':str(Path(path).resolve()),'bytes':Path(path).stat().st_size,'sha256':sha(Path(path).read_bytes())}
    jdk_doc=read_json(jdk_manifest); legs={}; tool_pins=[]
    source_tool_by_path={item['path']:item for m in matrices.values() for item in m['receipt']['source_tool_pins_before']}
    for leg in jdk_doc.get('legs',[]):
        tools=leg.get('jdk_tools',{})
        if {'java','javac','javap'} <= tools.keys():
            for name, item in tools.items():
                path=Path(item['path']).resolve(); expected=item['sha256']; actual=pin(path)
                check(actual['sha256']==expected,f'JDK tool pin mismatch: {path}')
                tool_pins.append(actual)
            home=Path(tools['java']['path']).resolve().parent.parent
            legs[leg['leg']]={'home':home,'tools':{name:Path(item['path']).resolve() for name,item in tools.items()}}
    check(set(legs)=={'javac8','javac23'},'both pinned JDK legs required')
    tool_paths={collector_path,guard_path,scanner_path,jdk_manifest,Path(pins_file),a.cli,a.build_receipt,Path(__file__).resolve(),Path(__file__).with_name('OuterTryBoundaryRunner.java').resolve()}
    for matrix in matrices.values():
        tool_paths.add(matrix['receipt_path'])
        tool_paths.add(Path(matrix['manifest_pin']['path']))
        tool_paths.add(matrix['runner_source'])
        for original_row in matrix['receipt'].get('original_compile_rows',[]):
            tool_paths.update(Path(row['path']) for row in original_row.get('classes',[]))
        jar_pin=matrix['receipt'].get('jadx',{}).get('jar_pin')
        if jar_pin: tool_paths.add(Path(jar_pin['path']))
        for info in matrix['sources'].values():
            tool_paths.add(Path(info['path']))
            if info.get('report_path'): tool_paths.add(Path(info['report_path']))
        tool_paths.update(Path(row['path']) for row in matrix['receipt']['source_tool_pins_before'])
    tool_paths.update(Path(pin_row['path']) for pin_row in tool_pins)
    tracked=[]
    for path in sorted(tool_paths,key=str):
        actual=pin(path)
        expected=source_tool_by_path.get(str(path))
        if expected is not None: check(actual['bytes']==expected['bytes'] and actual['sha256']==expected['sha256'],f'matrix tool/source input pin changed: {path}')
        tracked.append(path)
    execution={'schema':'outer-try-boundary-fullclass-comparison-v1','status':'preflight_complete','execution_policy':'prepared for future root-owned run; no result is prefilled','cli':cli_pin,'build_receipt':build_pin,'build_receipt_cli_binding':binding,'compiler_modes':{m:matrices[m]['receipt']['javac_debug_info'] for m in matrices},'resource_guard':{'minimum_free_bytes':MIN_FREE,'maximum_target_bytes':MAX_TARGET,'poll_seconds':1,'process_group_guard':'reused pinned v3 guard','rust_stack':'default/inherited; RUST_MIN_STACK is not overridden'},'source_tool_pins_before':[pin(x) for x in tracked],'source_tool_pins_after':[],'source_tool_inputs_unchanged':None,'commands':[],'matrices':{m:{'root':str(x['root']),'receipt':pin(x['receipt_path']),'target_source':x['target_pin'],'runner_source':x['runner_pin'],'manifest':x['manifest_pin'],'legacy_runner_oracles':x['legacy_runner_oracles'],'sources':x['sources']} for m,x in matrices.items()},'harness':pin(Path(__file__).with_name('OuterTryBoundaryRunner.java')),'runs':[],'cross_mode_original_output_same':None,'source_matches_original_by_jdk_mode':None}
    a.out.mkdir(parents=True); (a.out/'raw').mkdir(); (a.out/'runs').mkdir()
    write_json(a.out/'execution.json',execution)
    helper.ROOT=ROOT; recorder=helper.Recorder(a.out,guard,execution)
    run_results=[]
    for mode,matrix in matrices.items():
        javac_debug='-g' if mode=='debug' else '-g:none'
        for jdk in ('javac8','javac23'):
            for source_id in ('original','jadx-default','jadx-none','jarde-default','jarde-all'):
                if source_id=='original': source_info={'path':str(matrix['target_source']),'pin':matrix['target_pin'],'report_path':None,'report_pin':None}
                elif source_id.startswith('jadx-'): source_info=matrix['sources'][source_id]
                else: source_info=matrix['sources'][source_id+'-'+jdk]
                source=Path(source_info['path']); source_hash=source_info['pin']['sha256']
                run_label=f'{mode}-{jdk}-{source_id}'
                work=a.out/'runs'/run_label; srcdir=work/'src'; classes=work/'classes'; empty=work/'empty-paths'
                srcdir.mkdir(parents=True); classes.mkdir(); empty.mkdir()
                target_copy=srcdir/'UpstreamNestedLoops.java'; harness_copy=srcdir/'OuterTryBoundaryRunner.java'
                shutil.copyfile(source,target_copy); shutil.copyfile(execution['harness']['path'],harness_copy)
                copied_target=pin(target_copy); copied_harness=pin(harness_copy)
                check(copied_target['sha256']==source_hash,f'{run_label} target copy changed')
                flags=['-source','8','-target','8','-Xlint:-options'] if jdk=='javac8' else ['--release','8']
                tools=legs[jdk]['tools']; home=legs[jdk]['home']
                compile_row,_,_=recorder.run(run_label+'-compile',[tools['javac'],*flags,'-proc:none',javac_debug,'-classpath',empty,'-sourcepath',empty,'-d',classes,target_copy,harness_copy],home)
                class_files=sorted(p for p in classes.rglob('*.class') if p.is_file())
                class_paths=sorted(p.relative_to(classes).as_posix() for p in class_files)
                class_pins=[pin(p) for p in class_files]
                runtime_row=None; runtime_stdout=None; runtime_stderr=None
                if compile_row.get('exit_code')==0 and compile_row.get('guard_stop') is None:
                    runtime_row, runtime_stdout, runtime_stderr=recorder.run(run_label+'-run',[tools['java'],'-Xverify:all','-cp',classes,EXPECTED_HARNESS],home)
                run_results.append({'matrix':mode,'jdk':jdk,'source_id':source_id,'source':source_info,'target_copy':copied_target,'harness_copy':copied_harness,'javac_debug_argument':javac_debug,'compile_command':compile_row['label'],'compile_exit':compile_row.get('exit_code'),'runtime_command':runtime_row['label'] if runtime_row else None,'runtime_exit':runtime_row.get('exit_code') if runtime_row else None,'class_paths':class_paths,'class_set_exact':class_paths==EXPECTED_CLASS_PATHS if compile_row.get('exit_code')==0 else None,'classes':class_pins,'stdout_sha256':sha(runtime_stdout) if runtime_stdout is not None else None,'stderr_sha256':sha(runtime_stderr) if runtime_stderr is not None else None,'oracle_comparison':None})
                execution['runs']=run_results; write_json(a.out/'execution.json',execution)
    originals={(r['matrix'],r['jdk']):r for r in run_results if r['source_id']=='original'}
    legacy_oracles=[entry for matrix in matrices.values() for entry in matrix['legacy_runner_oracles']]
    legacy_keys={(row['exit_code'],row['stdout_sha256'],row['stderr_sha256']) for row in legacy_oracles}
    legacy_cross_mode_same=len(legacy_keys)==1
    original_rows=list(originals.values())
    if any(row['runtime_exit'] is None for row in original_rows):
        original_same=None
    else:
        oracle_keys={(row['runtime_exit'],row['stdout_sha256'],row['stderr_sha256']) for row in original_rows}
        original_same=len(oracle_keys)==1
    for result in run_results:
        baseline=originals[(result['matrix'],result['jdk'])]
        result['oracle_comparison']={'reference_source':'original','reference_runtime_available':baseline['runtime_exit'] is not None,'same_exit_stdout_stderr':None if result['runtime_exit'] is None or baseline['runtime_exit'] is None else result['runtime_exit']==baseline['runtime_exit'] and result['stdout_sha256']==baseline['stdout_sha256'] and result['stderr_sha256']==baseline['stderr_sha256']}
    execution['cross_mode_original_output_same']=original_same
    execution['legacy_17_runner_cross_mode_same']=legacy_cross_mode_same
    execution['source_matches_original_by_jdk_mode']={r['matrix']+'/'+r['jdk']+'/'+r['source_id']:r['oracle_comparison']['same_exit_stdout_stderr'] for r in run_results}
    execution['source_tool_pins_after']=[pin(x) for x in tracked]
    execution['source_tool_inputs_unchanged']=execution['source_tool_pins_before']==execution['source_tool_pins_after']
    execution['actual_command_count']=len(execution['commands'])
    execution['status']='observed' if execution['source_tool_inputs_unchanged'] else 'input_pin_changed'
    write_json(a.out/'execution.json',execution)
    print(json.dumps({'status':execution['status'],'command_count':execution['actual_command_count'],'run_rows':len(run_results),'out':str(a.out)},indent=2))
    return 0

if __name__=='__main__': raise SystemExit(main())
