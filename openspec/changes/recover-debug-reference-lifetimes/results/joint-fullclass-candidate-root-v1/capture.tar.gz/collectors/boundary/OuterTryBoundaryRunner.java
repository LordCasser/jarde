package cf11;

import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Independent ten-case harness for handled(List<String>, List<String>). */
public final class OuterTryBoundaryRunner {
    private static final String NO_FAILURE = "none";

    private OuterTryBoundaryRunner() {
    }

    @SuppressWarnings("unchecked")
    private static Iterator<String> iterator(final String boundary,
            final Throwable injected, final List<String> events,
            final String[] values, final int[] cursor) {
        return (Iterator<String>) Proxy.newProxyInstance(
                OuterTryBoundaryRunner.class.getClassLoader(),
                new Class<?>[] {Iterator.class},
                (proxy, method, args) -> {
                    String name = method.getName();
                    if ("hasNext".equals(name)) {
                        events.add("iterator.hasNext");
                        if ("hasNext".equals(boundary)) {
                            throw injected;
                        }
                        return Boolean.valueOf(cursor[0] < values.length);
                    }
                    if ("next".equals(name)) {
                        events.add("iterator.next");
                        if ("next".equals(boundary)) {
                            throw injected;
                        }
                        return values[cursor[0]++];
                    }
                    if ("remove".equals(name)) {
                        throw new UnsupportedOperationException("remove");
                    }
                    if ("toString".equals(name)) {
                        return "boundary-iterator";
                    }
                    if ("hashCode".equals(name)) {
                        return Integer.valueOf(System.identityHashCode(proxy));
                    }
                    if ("equals".equals(name)) {
                        return Boolean.valueOf(proxy == args[0]);
                    }
                    throw new UnsupportedOperationException(name);
                });
    }

    @SuppressWarnings("unchecked")
    private static List<String> input(final String boundary,
            final Throwable injected, final List<String> events,
            final String[] values) {
        final int[] cursor = new int[] {0};
        return (List<String>) Proxy.newProxyInstance(
                OuterTryBoundaryRunner.class.getClassLoader(),
                new Class<?>[] {List.class},
                (proxy, method, args) -> {
                    String name = method.getName();
                    if ("iterator".equals(name)) {
                        events.add("input.iterator");
                        if ("iterator".equals(boundary)) {
                            throw injected;
                        }
                        return iterator(boundary, injected, events, values, cursor);
                    }
                    if ("toString".equals(name)) {
                        return "boundary-input";
                    }
                    if ("hashCode".equals(name)) {
                        return Integer.valueOf(System.identityHashCode(proxy));
                    }
                    if ("equals".equals(name)) {
                        return Boolean.valueOf(proxy == args[0]);
                    }
                    throw new UnsupportedOperationException(name);
                });
    }

    @SuppressWarnings("unchecked")
    private static List<String> output(final String boundary,
            final Throwable injected, final List<String> events,
            final List<String> outputs) {
        return (List<String>) Proxy.newProxyInstance(
                OuterTryBoundaryRunner.class.getClassLoader(),
                new Class<?>[] {List.class},
                (proxy, method, args) -> {
                    String name = method.getName();
                    if ("add".equals(name) && args != null && args.length == 1) {
                        String value = (String) args[0];
                        events.add("output.add:" + value);
                        if ("output.add".equals(boundary)) {
                            throw injected;
                        }
                        outputs.add(value);
                        return Boolean.TRUE;
                    }
                    if ("toString".equals(name)) {
                        return "boundary-output";
                    }
                    if ("hashCode".equals(name)) {
                        return Integer.valueOf(System.identityHashCode(proxy));
                    }
                    if ("equals".equals(name)) {
                        return Boolean.valueOf(proxy == args[0]);
                    }
                    throw new UnsupportedOperationException(name);
                });
    }

    private static void run(String scenario, String boundary,
            boolean error, String... values) {
        List<String> events = new ArrayList<String>();
        List<String> outputs = new ArrayList<String>();
        Throwable injected = error
                ? new AssertionError("injected-" + boundary + "-Error")
                : new RuntimeException("injected-" + boundary + "-RuntimeException");
        UpstreamNestedLoops.effects = 0;
        Throwable observed = null;
        try {
            new UpstreamNestedLoops().handled(
                    input(boundary, injected, events, values),
                    output(boundary, injected, events, outputs));
        } catch (Throwable failure) {
            observed = failure;
        }
        String type = observed == null ? NO_FAILURE : observed.getClass().getName();
        String message = observed == null ? NO_FAILURE : String.valueOf(observed.getMessage());
        System.out.println("scenario=" + scenario
                + "|exception=" + type
                + "|message=" + message
                + "|events=" + events
                + "|effects=" + UpstreamNestedLoops.effects
                + "|outputs=" + outputs);
    }

    public static void main(String[] args) {
        run("iterator-runtime", "iterator", false, "value");
        run("iterator-error", "iterator", true, "value");
        run("hasNext-runtime", "hasNext", false, "value");
        run("hasNext-error", "hasNext", true, "value");
        run("next-runtime", "next", false, "value");
        run("next-error", "next", true, "value");
        run("output-add-runtime", "output.add", false, "value");
        run("output-add-error", "output.add", true, "value");
        run("success", NO_FAILURE, false, "value");
        run("empty", NO_FAILURE, false);
    }
}
