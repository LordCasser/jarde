# Protected prefix-loop adjacent tests and certificate audit

This private candidate is pinned to the current shared sources and base commit; it changes only `protected_prefix_loop_tests.rs`. It has not been compiled or run. Root owns all toolchain runs.

## Candidate test delta

The candidate adds three narrow assertions to the real `handled(List,List)` SSA fixture:

1. `candidate_row_binding_stops_without_publishing_a_partial_scope` now first measures the successful helper's actual `AnalysisSteps` use, then reruns the same real row/site binding with exactly one fewer step. The second result must be an `AnalysisSteps` stop, and consumed budget remains charged. Since `named_catch_rows_for_shape` returns `Result<Option<Arc<BTreeSet<_>>>, StopReason>`, an error has no row-set payload that could publish a partial scope. The pre-existing late child `RecursionStop` test and its full `WalkerState` rollback assertion are unchanged.
2. In the actual positive candidate, the same physical blocks `[0,7,16]` must fail `candidate_blocks_have_named_catch_scope` under `Frame::default()` and pass under the bound named-row frame. The existing competing-ordinal and duplicate-owner refusals remain intact.
3. The test derives the owner vector as the prefix's `blocks()` followed by `candidate_region_blocks` for the actual loop, then asserts that vector equals flattened `Try.body.blocks()` (`[0,7,16]`). It passes that derived vector to `certified_try_exit`, so the successful prefix-plus-loop certificate exercises the same owner-slice construction rule as the production branch.

## What the certificate proves for both shapes

`Walker::certified_try_exit` has one shape gate at its start: the legacy path accepts exactly one `Switch`; the new path is enabled only when an explicit owner slice is supplied and `protected_prefix_loop_shape` accepts a nonempty `Straight` prefix followed by one `Loop` (optionally wrapped as a one-element `Sequence`). After that gate, both paths execute the same code and the same checks. There is no shape-dependent branch in the physical proof.

The common proof requires a known join; requires the proposed bridge to equal `protected_end`; refuses any physical exception row covering the bridge or using it as a handler; finds the canonical bridge block and requires exactly one SSA instruction at that BCI, its physical width to end the block, `Operation::Transfer`, and exactly one normal successor equal to the join. It constructs `owned` from the supplied owner vector in the new path and from `Region::blocks()` in the Switch path. It refuses a catch handler that is also body-owned, an empty body, a body containing the bridge, or a bridge already visited. Every owned instruction must fall within the named protected range, with only the established fused-lead exception. It also refuses frame/switch boundaries, loop headers, and active loop break/continue targets at the bridge.

Finally, it requires at least one normal-flow predecessor of the bridge and requires every such predecessor to be owned. `closed_transfer_edges` iterates the complete canonical edge set: every edge into the bridge must be a `Normal` edge from an owned block; every edge out of the bridge must be the single `Normal` edge to the join. Thus exception/call/return edges crossing the bridge are refused independent of whether the body is a Switch or a prefix-plus-loop. The producer-side named-scope check is also common to the candidate prefix and loop: for every exception edge leaving an owned block, the exact row ordinal must be in the bound scope and `exception_edge_accounted` must accept it; any call edge from an owned block refuses the candidate. The loop itself must first be produced by the existing `region_at` reader and pass exact visited-delta and unique-owner checks.

The new candidate does not add a separate “effect operation” check to `certified_try_exit`; there is no such explicit check in that function. The certificate proves transfer/range/edge ownership properties, while loop-shape acceptance and instruction interpretation remain responsibilities of the existing region reader. Therefore this audit does not claim a new general effect-safety proof. The shape-independent claim is limited to the certificate's listed physical gates and the shared producer-side exception/call ownership check.

The positive owner assertion directly compares the production-equivalent pieces: cloned prefix blocks plus the existing loop collector's output against the actual body tree's flattened physical ownership. It is bound to the successful recovered tree, not a synthetic IR. The certificate itself stores ownership in a `BTreeSet`, so it is not the duplicate-owner gate; the candidate's earlier collector/visited checks are. Existing duplicate-loop mutation proves repeated physical ownership remains visible and is refused before certification.

## Legacy Switch controls and limits of evidence

The existing adjacent integration tests are `cf16_named_catch_owns_complete_switch_and_range_end_transfer`, `cf16_partial_case_ranges_and_real_resource_keep_their_boundaries`, and `cf16_stopped_runs_do_not_publish_a_partial_try` in `crates/jarde-java/tests/p3_java_recovery.rs`. The first is a real complete Switch/catch case: it checks exact exception-table/canonical edges, one source owner per block, structured output, and a complete source map. The second runs three partial-range Switch variants and requires they not be presented as the named `try { switch (...) }`; it separately requires a resource guard to remain a guard. The third requires output/source-map atomicity under output-budget stop and cancellation. These are behavioral controls for preserving the established Switch lane and its refusals.

Those integration assertions do not independently force each private `certified_try_exit` return branch (for example, no source-level claim here says the partial Switch fixture reaches the helper's `closed_transfer_edges` branch). The common-gate equivalence is established statically from the shared function body, and its successful use is checked on the real new shape. There is no direct shape-specific synthetic test for every effect/exception/call/normal gate; constructing inconsistent IR solely to force those branches would not be meaningful. This remains a boundary of the unit evidence, not a reason to weaken either lane.

## Minimum adjacent validation still needed

Root should apply the pinned test-only patch and run:

- `cargo test -p jarde-java --lib region::protected_prefix_loop_tests` to execute the new no-scope and partial-paid-row assertions alongside existing positive, duplicate, competing-row, Guard, and late-child-stop checks;
- `cargo test -p jarde-java --test p3_java_recovery cf16_` to preserve the real Switch positive, partial-range negatives, and stop/cancel contract;
- the existing full-class `ordinary_try_prefix_loop` integration target and the full two-JDK original/JADX/Jarde behavior collector, if those are part of acceptance. The private helper/unit pass cannot substitute for complete-class output, compilation, runtime equality, source-map, or delivery evidence.

The first two are the minimum local adjacent tests for this test-only delta and the legacy Switch boundary. The full-class/two-JDK gate remains a separate required product-acceptance step and must not be inferred from these tests.

## Pins and execution status

See `pins.json` for exact SHA-256 values and match checks. Base commit: `7e93eb30647338dd8a6ddfc9994392f23457aa3e`. The shared `region.rs`, source test file, and outer integration file all match the pinned hashes. No shared files were modified and no Cargo/JDK/JADX/CLI/Git operation was run for this candidate.
