#!/usr/bin/env python3
"""Read-only acceptance for paired EM20 raw-alias-escape captures."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import struct
import zipfile
from pathlib import Path

PREP = Path('/private/tmp/jarde-em20-raw-alias-escape-baseline-prep-luna-v3')
PREP_PINS = PREP / 'pins.json'
PROJECT = Path('/Users/lordcasser/workspace/projects/jarde')
METHODS = {
    '<init>', 'test', 'renamed', 'numbers', 'castBoundary', 'rawLists',
    'rawAliasEscape', 'reassigned', 'wildcardNull', 'handled', 'indexOverload',
}
DESCRIPTORS = {
    'rawAliasEscape': '(Ljava/util/List;Ljava/util/List;)V',
    'handled': '(Ljava/util/List;Ljava/util/List;)V',
}
ORACLE_SHA = '50ea25f5e9f74bc8d69b3dc945cd9ba006ef9a615a9e149c73e64c33f70f6231'
ORACLE_LABELS = [
    'baseline-both-empty', 'baseline-unmatched', 'baseline-five-character-match-add',
    'baseline-non-five-match-remove', 'baseline-remove-continues-and-clears',
    'baseline-null-first-list', 'baseline-null-second-list', 'baseline-null-element',
    'renamed-string-positive', 'integer-nested-add-positive', 'explicit-cast-object-boundary',
    'raw-list-method-control', 'raw-alias-heap-pollution', 'parameter-reassignment',
    'wildcard-null-write', 'try-catch-handler', 'remove-object-and-index-overloads',
]
ORACLE_RAW_ALIAS_LINE = ('raw-alias-heap-pollution|exception=java.lang.ClassCastException|'
                         'left=[kept, 7]|right=[7]|effects=1')
MIN_FREE = 5 * 1024**3
MAX_TARGET = 1024**3

class AuditError(RuntimeError):
    pass

def require(ok: bool, message: str) -> None:
    if not ok:
        raise AuditError(message)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def pin_file(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': sha(data)}

def check_pin(pin: dict, where: str) -> Path:
    require(isinstance(pin, dict), f'{where}: missing pin object')
    path = Path(pin.get('path', ''))
    require(path.is_file(), f'{where}: pinned file missing: {path}')
    actual = pin_file(path)
    require(actual['bytes'] == pin.get('bytes') and actual['sha256'] == pin.get('sha256'),
            f'{where}: bytes/hash mismatch: {path}')
    return path

def command_map(execution: dict) -> dict[str, dict]:
    rows = execution.get('commands')
    require(isinstance(rows, list) and rows, 'execution.commands missing or empty')
    require(execution.get('actual_command_count') == len(rows), 'actual_command_count differs from command rows')
    require([r.get('index') for r in rows] == list(range(1, len(rows) + 1)), 'command indices are not contiguous')
    by_label = {}
    for row in rows:
        label = row.get('label')
        require(isinstance(label, str) and label not in by_label, f'duplicate/invalid command label: {label}')
        require(row.get('state') == 'observed', f'{label}: command was not observed')
        require(row.get('guard_stop') is None, f'{label}: resource guard stopped command: {row.get("guard_stop")}')
        require(isinstance(row.get('exit_code'), int), f'{label}: missing exit code')
        peak = row.get('peak_target_bytes')
        free = row.get('free_bytes_after')
        require(isinstance(peak, int) and 0 <= peak <= MAX_TARGET, f'{label}: target cap exceeded or unsampled')
        require(isinstance(free, int) and free >= MIN_FREE, f'{label}: free-space floor not met')
        streams = row.get('streams')
        require(isinstance(streams, dict), f'{label}: stream pins missing')
        for channel in ('stdout', 'stderr'):
            check_pin(streams.get(channel), f'{label}.{channel}')
        by_label[label] = row
    return by_label

def check_physical_class_set(row: dict, where: str) -> None:
    expected = ['cf11/Runner.class', 'cf11/UpstreamNestedLoops.class']
    require(row.get('class_paths') == expected, f'{where}: physical class paths differ from the two full-source classes')
    classes = row.get('classes')
    require(isinstance(classes, list) and len(classes) == len(expected), f'{where}: class file pins missing')
    actual = []
    for item in classes:
        path = check_pin(item, f'{where} class file')
        actual.append(path.relative_to(path.parents[1]).as_posix())
    require(sorted(actual) == expected, f'{where}: pinned class files do not match reported physical paths')

def cmd_bytes(row: dict, channel: str) -> bytes:
    return Path(row['streams'][channel]['path']).read_bytes()

def check_source_tools(execution: dict) -> None:
    before = execution.get('source_tool_pins_before')
    after = execution.get('source_tool_pins_after')
    require(isinstance(before, list) and before, 'source_tool_pins_before missing')
    require(before == after, 'source/tool before-after pins differ')
    for idx, item in enumerate(before):
        check_pin(item, f'source/tool pin {idx}')
    require(execution.get('source_tool_inputs_unchanged') is True, 'collector did not confirm unchanged source/tool inputs')
    by_path = {item['path']: item for item in before}
    config = execution.get('collector_config', {})
    prepared = json.loads(PREP_PINS.read_text(encoding='utf-8'))['prepared_collector']
    require(by_path.get(prepared['path'], {}).get('sha256') == prepared['sha256'],
            'captured source/tool set does not include the pinned v3 collector')
    expected = {
        'cli': ('cli_sha256',),
        'build_receipt': ('build_receipt_sha256',),
        'jdk_manifest': ('jdk_manifest_sha256',),
        'jadx': ('jadx_sha256',),
        'jadx_jar': ('jadx_jar_sha256',),
        'guard': ('guard_sha256',),
        'scanner': ('scanner_sha256',),
        'classfile_parser': ('classfile_parser_sha256',),
    }
    for path_key, (sha_key,) in expected.items():
        path, digest = config.get(path_key), config.get(sha_key)
        require(isinstance(path, str) and isinstance(digest, str), f'collector_config lacks {path_key} pins')
        pin = by_path.get(str(Path(path).resolve()))
        require(pin is not None and pin['sha256'] == digest, f'{path_key} config does not match source/tool pin')
    manifest = json.loads(Path(config['jdk_manifest']).read_text(encoding='utf-8'))
    manifest_tools = {
        str(Path(tool['path']).resolve()): tool['sha256']
        for leg in manifest.get('legs', [])
        for tool in leg.get('jdk_tools', {}).values()
    }
    for path, digest in manifest_tools.items():
        require(path in by_path and by_path[path]['sha256'] == digest, f'JDK executable pin differs from manifest: {path}')
    input_manifest = json.loads((PREP / 'inputs/manifest.json').read_text(encoding='utf-8'))
    for item in [*input_manifest['target_classes'], input_manifest['runner']]:
        path = (PREP / 'inputs' / item['source']).resolve()
        require(str(path) in by_path and by_path[str(path)]['bytes'] == item['bytes']
                and by_path[str(path)]['sha256'] == item['sha256'],
                f'full-source input pin differs from manifest: {item["source"]}')

def check_cli_receipt(execution: dict) -> dict:
    cli_pin = execution.get('cli')
    cli = check_pin(cli_pin, 'CLI')
    mode = os.stat(cli).st_mode & 0o777
    require(mode == 0o555 and execution.get('cli_mode') == '0o555', 'CLI is not pinned mode 0555')
    receipt_pin = execution.get('build_receipt')
    receipt_path = check_pin(receipt_pin, 'build receipt')
    receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
    binding = receipt
    config = execution.get('collector_config', {})
    binding_path = config.get('receipt_cli_object', 'cli')
    for part in binding_path.split('.'):
        require(isinstance(binding, dict) and part in binding, f'build receipt has no CLI binding path {binding_path}')
        binding = binding[part]
    expected_status = config.get('receipt_accepted_value', 'commands_passed_pending_independent_acceptance')
    status_key = config.get('receipt_status_key', 'status')
    require(receipt.get(status_key) == expected_status == 'commands_passed_pending_independent_acceptance',
            'build receipt is not the accepted pending-independent-acceptance receipt')
    require(isinstance(binding, dict), 'CLI binding is not an object')
    for key, value in (('path', str(cli)), ('bytes', cli.stat().st_size), ('sha256', cli_pin['sha256'])):
        require(binding.get(key) == value, f'build receipt CLI binding mismatch at {key}')
    mode_key = config.get('receipt_mode_key')
    if mode_key:
        require(binding.get(mode_key) == '0o555', 'build receipt CLI mode mismatch')
    require(execution.get('build_receipt_cli_binding') == binding, 'execution receipt binding differs from build receipt')
    return {'cli': cli_pin, 'receipt': receipt_pin, 'receipt_binding_path': binding_path}

def source_map_audit(report: dict, identity: dict, code_length: int, report_label: str) -> dict:
    text = report.get('text')
    require(isinstance(text, str), f'{report_label}: raw method report text missing')
    text_bytes = text.encode('utf-8')
    boundaries = {0}
    offset = 0
    for char in text:
        offset += len(char.encode('utf-8'))
        boundaries.add(offset)
    source_map = report.get('source_map')
    require(isinstance(source_map, dict) and isinstance(source_map.get('segments'), list),
            f'{report_label}: method source_map.segments missing')
    bcis = []
    for segment in source_map['segments']:
        start, end = segment.get('start'), segment.get('end')
        require(type(start) is int and type(end) is int and 0 <= start <= end <= len(text_bytes),
                f'{report_label}: source-map byte range is outside raw method text')
        require(start in boundaries and end in boundaries,
                f'{report_label}: source-map range splits a UTF-8 code point')
        origin = segment.get('origin')
        require(isinstance(origin, dict) and isinstance(origin.get('primary'), dict)
                and isinstance(origin.get('derived'), list),
                f'{report_label}: unexpected source-map origin representation')
        refs = [origin['primary'], *origin['derived']]
        for ref in refs:
            require(isinstance(ref, dict) and ref.get('method') == identity,
                    f'{report_label}: primary/derived source-map method differs from method identity')
            bci = ref.get('bci')
            require(bci is None or (type(bci) is int and 0 <= bci < code_length),
                    f'{report_label}: source-map BCI is outside actual Code.code_length')
            if bci is not None:
                bcis.append(bci)
    return {'segments': source_map['segments'], 'bci_set': sorted(set(bcis)),
            'bci_reference_count': len(bcis)}

def method_identity_audit(doc: dict, report_label: str, classfile_path: Path) -> dict:
    owner = doc.get('class')
    class_bytes = owner.get('class_bytes') if isinstance(owner, dict) else None
    length = class_bytes.get('length') if isinstance(class_bytes, dict) else None
    require(isinstance(length, int) and length > 0, f'{report_label}: class.class_bytes.length missing')
    classfile = classfile_path.read_bytes()
    require(len(classfile) == length, f'{report_label}: original class bytes differ from report class length')
    methods = doc.get('methods')
    require(isinstance(methods, list) and len(methods) == 11, f'{report_label}: expected 11 actual method records')
    identities = set()
    names = []
    facts = {}
    for m in methods:
        item = m.get('item') if isinstance(m, dict) else None
        require(isinstance(item, dict), f'{report_label}: method item missing')
        ident = item.get('identity')
        require(isinstance(ident, dict), f'{report_label}: method identity missing')
        require(ident.get('owner') == owner, f'{report_label}: method owner does not equal report class owner')
        raw_name = ident.get('name')
        raw_desc = ident.get('descriptor')
        desc_obj = item.get('descriptor')
        require(isinstance(raw_name, list) and all(type(x) is int and 0 <= x <= 255 for x in raw_name),
                f'{report_label}: method identity name has unexpected representation')
        require(isinstance(raw_desc, list) and all(type(x) is int and 0 <= x <= 255 for x in raw_desc),
                f'{report_label}: method identity descriptor has unexpected representation')
        name = bytes(raw_name).decode('utf-8')
        descriptor = bytes(raw_desc).decode('utf-8')
        require(isinstance(desc_obj, dict) and desc_obj.get('raw') == raw_desc and desc_obj.get('escaped') == descriptor,
                f'{report_label}: descriptor identity/raw/escaped fields disagree for {name}')
        span = (item.get('body') or {}).get('content_span')
        require(isinstance(span, dict), f'{report_label}: method code content_span missing for {name}')
        start, count = span.get('start'), span.get('length')
        require(type(start) is int and type(count) is int and start >= 0 and count > 0 and start + count <= length,
                f'{report_label}: method content_span outside report class bytes for {name}')
        require(count >= 8 and start + 8 <= len(classfile),
                f'{report_label}: Code attribute content is shorter than its header for {name}')
        code_length = struct.unpack('>I', classfile[start + 4:start + 8])[0]
        require(code_length <= 65535 and code_length <= count - 8,
                f'{report_label}: actual Code.code_length does not fit its Code attribute for {name}')
        outcome = m.get('outcome')
        require(isinstance(outcome, dict), f'{report_label}: method outcome missing for {name}')
        raw_report = outcome.get('report')
        require(raw_report is None or isinstance(raw_report, dict),
                f'{report_label}: unexpected per-method raw report representation for {name}')
        if outcome.get('kind') == 'recovered':
            require(isinstance(raw_report, dict), f'{report_label}: recovered method has no per-method raw report: {name}')
            require(raw_report.get('method') == name + descriptor,
                    f'{report_label}: raw report method label differs from physical identity for {name}')
            binding = raw_report.get('artifact', {}).get('binding', {})
            require(binding.get('method') == ident,
                    f'{report_label}: raw report artifact binding differs from physical identity for {name}')
            require('source_map' in raw_report,
                    f'{report_label}: recovered method has no source map: {name}')
        if isinstance(raw_report, dict) and 'source_map' in raw_report:
            map_audit = source_map_audit(raw_report, ident, code_length, f'{report_label}/{name}')
        else:
            map_audit = {'segments': None, 'bci_set': [], 'bci_reference_count': 0}
        identity = (json.dumps(owner, sort_keys=True), tuple(raw_name), tuple(raw_desc))
        require(identity not in identities, f'{report_label}: duplicate method identity {name}{descriptor}')
        identities.add(identity)
        names.append(name)
        facts[name] = {'descriptor': descriptor, 'span': {'start': start, 'length': count},
                       'code_length': code_length, 'source_map': map_audit['segments'],
                       'bci_set': map_audit['bci_set'],
                       'bci_reference_count': map_audit['bci_reference_count'],
                       'raw_report_text': raw_report.get('text', '') if isinstance(raw_report, dict) else '',
                       'raw_report': raw_report, 'method_record': m}
    require(set(names) == METHODS, f'{report_label}: actual method names differ: {sorted(names)}')
    for name, descriptor in DESCRIPTORS.items():
        require(facts[name]['descriptor'] == descriptor, f'{report_label}: descriptor mismatch for {name}')
    return {'method_count': len(methods), 'method_names': sorted(names), 'methods': facts,
            'class_owner': owner}

def audit_capture(mode: str, capture: Path, prep_pins: dict) -> dict:
    execution_path = capture / 'execution.json'
    require(execution_path.is_file(), f'{mode}: missing execution.json in {capture}')
    execution_pin = pin_file(execution_path)
    execution = json.loads(execution_path.read_text(encoding='utf-8'))
    require(execution.get('schema') == 'cf11-target-full-source-capture-v2', f'{mode}: unexpected capture schema')
    require(execution.get('status') == 'observed', f'{mode}: capture is not fully observed')
    require(execution.get('package') == 'cf11' and execution.get('classes') == ['cf11.UpstreamNestedLoops']
            and execution.get('runner_class') == 'cf11.Runner', f'{mode}: full target/Runner identity changed')
    require(execution.get('javac_debug_info') == {'mode': mode, 'argument': '-g' if mode == 'debug' else '-g:none'},
            f'{mode}: compiler debug mode receipt mismatch')
    config = execution.get('collector_config', {})
    require(config.get('javac_debug') == mode, f'{mode}: collector_config javac_debug mismatch')
    guard = execution.get('resource_guard', {})
    require(guard.get('minimum_free_bytes') == MIN_FREE and guard.get('maximum_target_bytes') == MAX_TARGET
            and guard.get('poll_seconds') == 1 and guard.get('peak_target_sampled') is True,
            f'{mode}: guard configuration changed')
    require(execution.get('input_entries') == json.loads((PREP / 'inputs/manifest.json').read_text(encoding='utf-8')),
            f'{mode}: full source manifest differs from pinned 4,543B target + Runner')
    manifest_path = check_pin(execution.get('inputs_manifest'), f'{mode} input manifest')
    require(pin_file(manifest_path) == pin_file(PREP / 'inputs/manifest.json'),
            f'{mode}: input manifest pin differs from prep')
    check_source_tools(execution)
    binding = check_cli_receipt(execution)
    commands = command_map(execution)
    compile_rows = [r for r in commands.values() if r['label'].endswith('-compile')]
    for row in compile_rows:
        argv = row.get('argv', [])
        want = '-g' if mode == 'debug' else '-g:none'
        debug_flags = [x for x in argv if x in ('-g', '-g:none')]
        require(debug_flags == [want], f'{mode}: compiler argv does not carry exactly {want}: {row["label"]}')

    original_rows = execution.get('original_compile_rows')
    require(isinstance(original_rows, list) and len(original_rows) == 2, f'{mode}: expected two actual original JDK compile rows')
    originals = {}
    oracle_pin = prep_pins['old_runner_stdout']['2']
    require(oracle_pin.get('sha256') == ORACLE_SHA, 'pinned original 17-key stdout oracle changed')
    oracle_path = check_pin(oracle_pin, 'original 17-key stdout oracle')
    oracle_stdout = oracle_path.read_bytes()
    oracle_lines = oracle_stdout.decode('utf-8').splitlines()
    require([line.split('|', 1)[0] for line in oracle_lines] == ORACLE_LABELS,
            'original stdout oracle labels/order differ from the frozen 17-key sequence')
    require(ORACLE_RAW_ALIAS_LINE in oracle_lines, 'original stdout oracle raw-alias line differs')
    for row in original_rows:
        jdk = row.get('label', '').removesuffix('-original')
        require(jdk in ('javac8', 'javac23') and jdk not in originals, f'{mode}: unexpected original compile identity')
        require(row.get('compile_exit') == 0 and row.get('run_exit') == 0 and row.get('class_set_exact') is True,
                f'{mode}: original {jdk} full-source compile/runtime/class set failed')
        check_physical_class_set(row, f'{mode} original {jdk}')
        manifest = json.loads((PREP / 'inputs/manifest.json').read_text(encoding='utf-8'))
        expected_source_pins = {item['source']: (item['bytes'], item['sha256'])
                                for item in [*manifest['target_classes'], manifest['runner']]}
        actual_source_pins = {Path(x['path']).name: (x['bytes'], x['sha256']) for x in row.get('source_pins', [])}
        require(actual_source_pins == expected_source_pins, f'{mode}: original {jdk} did not compile exact full input sources')
        run = commands.get(row.get('run_command'))
        require(run is not None and run.get('exit_code') == 0, f'{mode}: original {jdk} runner did not pass')
        stdout, stderr = cmd_bytes(run, 'stdout'), cmd_bytes(run, 'stderr')
        require(stdout == oracle_stdout, f'{mode}: original {jdk} stdout differs from frozen 17-key oracle')
        originals[jdk] = {'row': row, 'stdout': stdout, 'stderr': stderr, 'run_command': run['label']}
    original_target_sizes = {}
    original_target_paths = {}
    for jdk, original in originals.items():
        class_pin = next((x for x in original['row']['classes'] if x['path'].endswith('/cf11/UpstreamNestedLoops.class')), None)
        require(class_pin is not None, f'{mode}: original {jdk} target class pin missing')
        original_target_sizes[jdk] = class_pin['bytes']
        original_target_paths[jdk] = check_pin(class_pin, f'{mode} original {jdk} target class')

    profiles = execution.get('jarde_profiles')
    require(isinstance(profiles, list) and len(profiles) == 4, f'{mode}: expected four Jarde whole-class reports')
    seen = set()
    report_records = {}
    for profile in profiles:
        identity = (profile.get('jdk'), profile.get('mode'))
        require(identity in {(j, m) for j in ('javac8', 'javac23') for m in ('default', 'all')},
                f'{mode}: invalid Jarde profile identity {identity}')
        require(identity not in seen, f'{mode}: duplicate Jarde report identity {identity}')
        seen.add(identity)
        require(profile.get('class') == 'cf11.UpstreamNestedLoops' and profile.get('render_exit') == 0,
                f'{mode}: Jarde render failed for {identity}')
        report_path = check_pin(profile.get('report_pin'), f'{mode} report {identity}')
        source_path = check_pin(profile.get('source_pin'), f'{mode} generated Java {identity}')
        doc = json.loads(report_path.read_text(encoding='utf-8'))
        render = commands.get(profile.get('render_command'))
        require(render is not None and render.get('exit_code') == 0, f'{mode}: missing successful raw render command for {identity}')
        raw_report = json.loads(cmd_bytes(render, 'stdout').decode('utf-8'))
        require(raw_report == doc, f'{mode}: saved report differs from the raw CLI JSON for {identity}')
        require(profile.get('render_stdout_sha256') == render['streams']['stdout']['sha256']
                and profile.get('render_stderr_sha256') == render['streams']['stderr']['sha256'],
                f'{mode}: render report stream hashes differ from raw stream pins for {identity}')
        require(profile.get('report_execution') == doc.get('execution')
                and isinstance(doc.get('execution'), dict) and doc['execution'].get('status') == 'complete',
                f'{mode}: render execution report is not bound to a complete whole-class report for {identity}')
        argv = render.get('argv', [])
        require(argv and argv[0] == str(binding['cli']['path']) and 'class-source' in argv,
                f'{mode}: render command did not invoke the pinned current CLI for {identity}')
        require('--input' in argv and argv[argv.index('--input') + 1] == str(original_target_paths[identity[0]]),
                f'{mode}: render command input is not the same-JDK original target class for {identity}')
        require('--class' in argv and argv[argv.index('--class') + 1] == 'cf11.UpstreamNestedLoops',
                f'{mode}: render command class identity mismatch for {identity}')
        has_all = '--evidence' in argv and argv[argv.index('--evidence') + 1] == 'all'
        require(has_all == (identity[1] == 'all'), f'{mode}: render evidence selector mismatch for {identity}')
        source_bytes = source_path.read_bytes()
        report_text = doc.get('text')
        require(isinstance(report_text, str) and source_bytes == report_text.encode('utf-8'),
                f'{mode}: saved generated Java differs byte-for-byte from report.text for {identity}')
        methods = method_identity_audit(doc, f'{mode}/{identity}', original_target_paths[identity[0]])
        require(doc['class']['class_bytes']['length'] == original_target_sizes[identity[0]],
                f'{mode}: report owner byte length differs from its same-JDK original target class')
        body = methods['methods']
        require('rawAliasEscape' in body and 'handled' in body, f'{mode}: target method identities absent')
        # Confirm the report's own rendered method fragments identify the same bytecode members.
        for method_name, desc in DESCRIPTORS.items():
            method = next(m for m in doc['methods'] if bytes(m['item']['identity']['name']).decode('utf-8') == method_name)
            method_text = method.get('text')
            require(isinstance(method_text, str) and f'// @method {method_name}{desc}' in method_text,
                    f'{mode}: {method_name} text is not tied to its report identity')
        alias = body['rawAliasEscape']
        alias_record = alias['method_record']
        alias_report = alias['raw_report']
        expected_parameters = ('target', 'source') if mode == 'debug' else ('arg1', 'arg2')
        declaration = alias_record.get('declaration')
        declaration_match = re.fullmatch(
            r'public void rawAliasEscape\(java\.util\.List (\w+), java\.util\.List (\w+)\)',
            declaration or '')
        require(declaration_match is not None and declaration_match.groups() == expected_parameters,
                f'{mode}: rawAliasEscape declaration lost its two exact raw-List parameters')
        alias_text = alias['raw_report_text']
        local_match = re.search(r'^\s*java\.util\.List (\w+);\s*$', alias_text, re.MULTILINE)
        require(local_match is not None, f'{mode}: rawAliasEscape raw-List alias local is missing')
        local_name = local_match.group(1)
        iterator_match = re.search(r'^\s*java\.util\.Iterator (\w+);\s*$', alias_text, re.MULTILINE)
        require(iterator_match is not None, f'{mode}: rawAliasEscape iterator local is missing')
        iterator_name = iterator_match.group(1)
        alias_assignment = f'{local_name} = {expected_parameters[0]};'
        first_iter_assignment = f'{iterator_name} = {expected_parameters[1]}.iterator();'
        second_iter_assignment = f'{iterator_name} = {expected_parameters[0]}.iterator();'
        require(alias_assignment in alias_text,
                f'{mode}: rawAliasEscape raw List alias is not assigned from its first parameter')
        require(first_iter_assignment in alias_text and second_iter_assignment in alias_text,
                f'{mode}: rawAliasEscape does not iterate source then target through its two named parameters')
        loops = list(re.finditer(r'while\s*\(\s*(\w+)\.hasNext\(\)\s*\)\s*\{([^{}]*)\}',
                                 alias_text, re.DOTALL))
        require(len(loops) == 2 and all(loop.group(1) == iterator_name for loop in loops),
                f'{mode}: rawAliasEscape should have two loops over the reported iterator')
        cast_locals = ('value', 'value_2') if mode == 'debug' else ('local5', 'local5_2')
        integer_decl = (f'java.lang.Integer {cast_locals[0]} = '
                        f'(java.lang.Integer) {iterator_name}.next();')
        string_decl = (f'java.lang.String {cast_locals[1]} = '
                       f'(java.lang.String) {iterator_name}.next();')
        require(integer_decl in loops[0].group(2),
                f'{mode}: first rawAliasEscape loop lacks its initialized Integer cast local')
        require(f'{local_name}.add((java.lang.Object) {cast_locals[0]});' in loops[0].group(2),
                f'{mode}: first rawAliasEscape loop does not add the Integer local through the raw List alias')
        require(string_decl in loops[1].group(2),
                f'{mode}: second rawAliasEscape loop lacks its initialized String cast local')
        second_assignment_at = alias_text.index(second_iter_assignment)
        require(alias_text.index(first_iter_assignment) < loops[0].start()
                and loops[0].end() < second_assignment_at < loops[1].start(),
                f'{mode}: rawAliasEscape iterator assignments do not bracket their corresponding loops')
        require(alias['raw_report'].get('outcome') == 'produced'
                and alias_record['outcome'].get('kind') == 'recovered',
                f'{mode}: rawAliasEscape is not a recovered, produced method report')
        require({27, 69} <= set(alias['bci_set']),
                f'{mode}: rawAliasEscape source map omits cast BCIs 27/69 across primary+derived origins')

        handled = body['handled']
        handled_record = handled['method_record']
        handled_report = handled['raw_report']
        require(handled_record['outcome'].get('kind') == 'recovered'
                and handled_report.get('outcome') == 'produced',
                f'{mode}: handled is not a recovered, produced method report')
        require(handled_report.get('fallbacks') == [], f'{mode}: handled still reports a fallback')
        require('@bytecode' not in handled['raw_report_text']
                and '@bytecode' not in handled_record.get('text', '')
                and 'jarde_refused_body' not in handled['raw_report_text'],
                f'{mode}: handled retains fallback bytecode/refusal text')
        protected_bcis = {0, 7, 16, 47, 50, 59}
        require(protected_bcis <= set(handled['bci_set']),
                f'{mode}: handled source map omits one of the six protected ownership BCIs')
        if identity[1] == 'all':
            regions = handled_report.get('regions')
            require(isinstance(regions, list), f'{mode}: handled all-evidence region records missing')
            block_owners = {bci: [] for bci in protected_bcis}
            for region in regions:
                require(isinstance(region, dict) and isinstance(region.get('blocks'), list),
                        f'{mode}: handled all-evidence region has unexpected shape')
                for bci in protected_bcis:
                    if bci in region['blocks']:
                        block_owners[bci].append(region)
            require(all(len(owners) == 1 for owners in block_owners.values()),
                    f'{mode}: handled all-evidence protected block BCIs do not each have exactly one region owner')
            try_regions = [region for region in regions
                           if region.get('bci') == 0 and region.get('structured') is True
                           and {0, 7, 16, 50} <= set(region['blocks'])]
            require(len(try_regions) == 1,
                    f'{mode}: handled all-evidence structured protected Try region does not cover BCIs 0/7/16/50')
        report_records[identity] = {'profile': profile, 'doc': doc, 'source': source_bytes,
                                    'methods': methods, 'report_pin': profile['report_pin'],
                                    'source_pin': profile['source_pin']}
    require(seen == {(j, m) for j in ('javac8', 'javac23') for m in ('default', 'all')},
            f'{mode}: incomplete Jarde mode/JDK matrix')
    for jdk in ('javac8', 'javac23'):
        require(report_records[(jdk, 'default')]['source'] == report_records[(jdk, 'all')]['source'],
                f'{mode}: Jarde default/all whole-class output differs on {jdk}')
        for method_name in METHODS:
            default_map = report_records[(jdk, 'default')]['methods']['methods'][method_name]['source_map']
            all_map = report_records[(jdk, 'all')]['methods']['methods'][method_name]['source_map']
            require(default_map == all_map,
                    f'{mode}: Jarde default/all raw source maps differ for {jdk}/{method_name}')
    descriptor_map = {name: info['descriptor'] for name, info in next(iter(report_records.values()))['methods']['methods'].items()}
    for identity, value in report_records.items():
        current = {name: info['descriptor'] for name, info in value['methods']['methods'].items()}
        require(current == descriptor_map, f'{mode}: method descriptor identities vary between reports at {identity}')

    jarde_rows = execution.get('jarde_compile_rows')
    require(isinstance(jarde_rows, list) and len(jarde_rows) == 4, f'{mode}: expected four actual Jarde full-source compile/run rows')
    jarde_seen = set()
    for row in jarde_rows:
        label = row.get('label', '')
        m = re.fullmatch(r'(javac8|javac23)-jarde-(default|all)-combined', label)
        require(m is not None, f'{mode}: Jarde row is not a combined full-source case: {label}')
        jdk, profile_mode = m.groups()
        require((jdk, profile_mode) not in jarde_seen, f'{mode}: duplicate Jarde compile identity {label}')
        jarde_seen.add((jdk, profile_mode))
        require(row.get('compile_exit') == 0 and row.get('run_exit') == 0,
                f'{mode}: Jarde {label} did not compile and run successfully')
        require(row.get('class_set_exact') is True, f'{mode}: Jarde {label} emitted a changed physical class set')
        check_physical_class_set(row, f'{mode} {label}')
        run = commands.get(row.get('run_command'))
        require(run is not None and run.get('exit_code') == 0, f'{mode}: Jarde runtime command absent/failed for {label}')
        original = originals[jdk]
        require(cmd_bytes(run, 'stdout') == original['stdout'] and cmd_bytes(run, 'stderr') == original['stderr'],
                f'{mode}: Jarde {label} stdout/stderr differs from same-JDK original')
        comparison = row.get('runtime_comparison')
        require(isinstance(comparison, dict) and comparison.get('same_jdk_original') is True,
                f'{mode}: Jarde {label} comparison receipt is not true')
        expected_sources = {x['path']: x for x in row.get('source_pins', [])}
        generated = report_records[(jdk, profile_mode)]['source_pin']
        runner_pin = next((x for x in row.get('source_pins', []) if Path(x.get('path', '')).name == 'Runner.java'), None)
        require(generated['path'] in expected_sources and expected_sources[generated['path']] == generated,
                f'{mode}: Jarde compile did not consume the exact saved whole-class source')
        expected_runner = prep_pins['original_sources']['Runner.java']
        require(runner_pin is not None and runner_pin['bytes'] == expected_runner['bytes']
                and runner_pin['sha256'] == expected_runner['sha256'],
                f'{mode}: Jarde compile did not consume the unchanged full Runner.java')
    require(jarde_seen == {(j, m) for j in ('javac8', 'javac23') for m in ('default', 'all')},
            f'{mode}: Jarde compile matrix incomplete')

    jadx_profiles = execution.get('jadx', {}).get('profiles', {})
    require(set(jadx_profiles) == {'default', 'none'}, f'{mode}: JADX source profile set changed')
    require(all(p.get('exact_target_sources') is True and p.get('exit_code') == 0 for p in jadx_profiles.values()),
            f'{mode}: JADX did not emit the exact target source under both settings')
    jar_pin = check_pin(execution.get('jadx', {}).get('jar_pin'), f'{mode} JADX input jar')
    require(execution['jadx'].get('jar_entries') == ['cf11.UpstreamNestedLoops'], f'{mode}: JADX input class list changed')
    with zipfile.ZipFile(jar_pin) as jar:
        require(jar.namelist() == ['cf11/UpstreamNestedLoops.class'], f'{mode}: JADX jar physical entries changed')
        require(jar.read('cf11/UpstreamNestedLoops.class') == original_target_paths['javac23'].read_bytes(),
                f'{mode}: JADX did not receive the exact JDK23 original target class bytes')
    jadx_rows = execution.get('jadx_compile_rows')
    require(isinstance(jadx_rows, list) and len(jadx_rows) == 4, f'{mode}: expected four JADX negative-control compile rows')
    jadx_seen = set()
    for row in jadx_rows:
        label = row.get('label', '')
        m = re.fullmatch(r'(javac8|javac23)-jadx-(default|none)', label)
        require(m is not None, f'{mode}: unexpected JADX compile row: {label}')
        jdk, profile = m.groups()
        require((jdk, profile) not in jadx_seen, f'{mode}: duplicate JADX row {label}')
        jadx_seen.add((jdk, profile))
        require(row.get('compile_exit', 0) != 0 and row.get('run_exit') is None and row.get('run_command') is None,
                f'{mode}: JADX negative-control did not fail at compile/no-runtime: {label}')
        compile_command = commands.get(row.get('compile_command'))
        require(compile_command is not None and compile_command.get('exit_code') != 0,
                f'{mode}: JADX compiler raw command does not show its failure: {label}')
        source_pin = next((x for x in row.get('source_pins', []) if Path(x.get('path', '')).name == 'UpstreamNestedLoops.java'), None)
        require(source_pin is not None, f'{mode}: JADX compile row lacks its target source pin')
        profile_sources = jadx_profiles[profile].get('sources', [])
        require(len(profile_sources) == 1, f'{mode}: expected one pinned JADX target source for {profile}')
        generated_source_pin = profile_sources[0]
        generated_source = check_pin(generated_source_pin, f'{mode} JADX {profile} generated source')
        copied_source = check_pin(source_pin, f'{mode} JADX {profile} compile source')
        require(generated_source.read_bytes() == copied_source.read_bytes(),
                f'{mode}: compile input differs from the emitted JADX source for {profile}')
        expected_runner = prep_pins['original_sources']['Runner.java']
        runner_pin = next((x for x in row.get('source_pins', []) if Path(x.get('path', '')).name == 'Runner.java'), None)
        require(runner_pin is not None and runner_pin['bytes'] == expected_runner['bytes']
                and runner_pin['sha256'] == expected_runner['sha256'],
                f'{mode}: JADX control compile did not use the unchanged full Runner.java')
        stderr = cmd_bytes(compile_command, 'stderr').decode('utf-8', errors='replace')
        source_text = Path(source_pin['path']).read_text(encoding='utf-8')
        require(source_text in stderr or str(Path(source_pin['path'])) in stderr,
                f'{mode}: raw JADX compiler error does not identify its exact source')
        require('Integer' in stderr and 'String' in stderr and 'add(' in stderr,
                f'{mode}: JADX failure is not the known raw-alias add(Integer)->String control')
        require('rawAliasEscape' in source_text, f'{mode}: JADX control source omits rawAliasEscape')
    require(jadx_seen == {(j, p) for j in ('javac8', 'javac23') for p in ('default', 'none')},
            f'{mode}: JADX negative-control matrix incomplete')

    return {
        'mode': mode,
        'execution_pin': execution_pin,
        'status': execution['status'],
        'actual_command_count': execution['actual_command_count'],
        'guard_stop_none_count': len(commands),
        'source_tool_pin_count': len(execution['source_tool_pins_before']),
        'source_tool_inputs_unchanged': execution['source_tool_inputs_unchanged'],
        'cli_receipt': binding,
        'jarde_report_count': len(profiles),
        'jarde_pass_count': len(jarde_rows),
        'jadx_negative_control_count': len(jadx_rows),
        'original_stdout_oracle_sha256': ORACLE_SHA,
        'methods_per_report': 11,
        'method_descriptors': descriptor_map,
        'reports': {f'{jdk}/{pm}': {'report': v['report_pin'], 'source': v['source_pin']}
                    for (jdk, pm), v in sorted(report_records.items())},
    }

def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--debug-capture', type=Path, required=True)
    p.add_argument('--none-capture', type=Path, required=True)
    p.add_argument('--report', type=Path, help='optional new JSON result path; refuses overwrite')
    a = p.parse_args()
    try:
        prep_pins = json.loads(PREP_PINS.read_text(encoding='utf-8'))
        for key in ('prepared_collector', 'prepared_runner'):
            asset = prep_pins[key]
            asset_path = Path(asset['path'])
            require(asset_path.is_file() and sha(asset_path.read_bytes()) == asset['sha256'],
                    f'pinned prep {key} hash mismatch: {asset_path}')
        manifest_pin = pin_file(PREP / 'inputs/manifest.json')
        expected_manifest_pin = prep_pins['source_manifest']
        require(manifest_pin['bytes'] == expected_manifest_pin['bytes']
                and manifest_pin['sha256'] == expected_manifest_pin['sha256'], 'prep input manifest pin changed')
        for name, path in (('debug', a.debug_capture), ('none', a.none_capture)):
            require(path.is_dir(), f'{name}: capture directory does not exist: {path}')
        require(a.debug_capture.resolve() != a.none_capture.resolve(), 'debug and none captures must be distinct')
        require(not (PROJECT / 'target').exists(), 'shared workspace target directory remains; expected targetabsent')
        result = {
            'schema': 'jarde-reference-prefix-candidate-audit-v5',
            'status': 'passed',
            'target_absent_observation': {'path': str(PROJECT / 'target'), 'absent': True},
            'captures': {
                'debug': audit_capture('debug', a.debug_capture.resolve(), prep_pins),
                'none': audit_capture('none', a.none_capture.resolve(), prep_pins),
            },
        }
        require(result['captures']['debug']['method_descriptors'] == result['captures']['none']['method_descriptors'],
                'debug/none report method descriptors differ')
        require(result['captures']['debug']['cli_receipt']['cli']['sha256'] ==
                result['captures']['none']['cli_receipt']['cli']['sha256'],
                'debug/none captures do not use the same frozen CLI')
        if a.report:
            report = a.report.resolve()
            require(not report.exists(), f'refuse overwrite: {report}')
            report.parent.mkdir(parents=True, exist_ok=True)
            report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (AuditError, OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({'schema': 'jarde-reference-prefix-candidate-audit-v5',
                          'status': 'failed', 'error': str(exc)}, ensure_ascii=False, indent=2))
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
