# EM20 双模式候选验收器 v5（私有准备）

v5 从 v4 独立复制而来；v1、v2、v3、历史 receipt 和 raw 文件均未修改。验收器仅读取两份新鲜 debug/none capture，不启动 Cargo、JDK、JADX 或 CLI，不改 capture 或共享仓库。当前只完成静态准备；新的候选 capture 尚未验收。

```sh
python3 /private/tmp/jarde-reference-prefix-candidate-audit-luna-v5/verify_candidate.py \
  --debug-capture /private/tmp/<fresh-debug-capture> \
  --none-capture /private/tmp/<fresh-none-capture> \
  --report /private/tmp/<new-private-audit-dir>/acceptance.json
```

v4 保留 v3 的输入/tool/receipt/CLI/raw-stream/guard、原始双 JDK 编译运行、17-key stdout oracle、JADX negative-control、方法 identity/source-map UTF-8 与 Code `code_length` 门。v2 将 handled 的 source-map BCI 集合误当成 region block owners；v3 已改为要求六个受保护位置 `{0,7,16,47,50,59}` 都至少在 source map 中出现。这样允许 source map 同时记录普通指令与 derived 来源，不再要求它只能等于六个 canonical region owners。

对 `--evidence all` 的 handled 方法，v3 已加入读取 `raw_report.regions`：六个 BCI 必须各自恰好出现在一个 region 的 `blocks` 中；必须有一个从 BCI 0 开始且 `structured=true` 的 protected region，其 blocks 覆盖 `0/7/16/50`。这个 region 要求仅用于 all-evidence 报告；default profile 的 regions 为空时允许通过。方法 source-map 仍独立检查六个目标 BCI 都出现。

rawAlias 检查要求 raw List alias 明确赋值自第一个参数；两次 cast 都在各自的 while body 中以初始化声明出现，Integer cast 局部被第一循环的 raw List alias 以 Object 形态 add，String cast 局部在第二循环独立出现。第二次 iterator 赋值必须位于第一循环结束之后、第二循环开始之前。实际 debug/none candidate 的 8 份报告均已只读检查上述赋值关系，并匹配预期的循环局部变量形态。debug 模式检查 `value` 和 `value_2`；none 模式按既有无 LVT baseline 的实际变量形态检查 `local5` 和 `local5_2`。参数声明分别检查 debug 的 `target/source` 和 none 的 `arg1/arg2`，并核对 source/target iterator 的循环次序及 BCI 27/69 的 primary 或 derived 引用。

v2 的 UTF-8/map/Code-length smoke 和原始 stdout oracle 检查仍适用。旧历史 debug report 复用同一个名字 `value`，这是旧数据，不作为 v3 候选；因此 v4 对 debug candidate 的实际命名断言不预填或假定验收结果。历史 handled report 中，六个目标 BCI 的 block owner 可唯一定位，但旧输出缺少覆盖 `0/7/16/50` 的 structured protected region；它不能满足 handled 的新候选门。本次仅对已存在 candidate 报告抽查并静态检查脚本 AST；没有运行验收器或任何工具链。


v5 修复了 v4 首次执行暴露的输入 manifest 类型误比：`check_pin()` 返回经过字节/SHA 校验的路径，后续对该路径与 prep manifest 分别生成 `{path, bytes, sha256}` pin 后比较。失败记录保留在 v4 执行历史中；v5 不重写该记录。静态检查确认其余 `check_pin()` 调用都将返回值用作路径读取、路径分解或仅作 pin 校验，没有再将路径与 pin 字典直接比较。
