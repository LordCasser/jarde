#!/usr/bin/env python3
"""Root independent raw/source/tool/compile/runtime audit, no toolchain."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
CAP = Path('/private/tmp/jarde-reference-prefix-candidate-boundary-root-v1')
OUT = Path('/private/tmp/jarde-reference-prefix-boundary-acceptance-root-v1.json')
assert not OUT.exists() and not (ROOT / 'target').exists()
checked = {}

def pin(p):
    p = Path(p)
    assert p.is_file() and not p.is_symlink(), str(p)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def check(x):
    assert pin(x['path']) == x, x['path']
    checked[x['path']] = x
    return Path(x['path']).read_bytes()

def check_tree(x):
    if isinstance(x, dict):
        if {'path', 'bytes', 'sha256'} <= x.keys():
            check({k: x[k] for k in ('path', 'bytes', 'sha256')})
        for v in x.values():
            check_tree(v)
    elif isinstance(x, list):
        for v in x:
            check_tree(v)

d = json.loads((CAP / 'execution.json').read_bytes())
assert d['status'] == 'observed'
assert d['source_tool_pins_before'] == d['source_tool_pins_after']
assert d['source_tool_inputs_unchanged'] is True
assert d['resource_guard']['minimum_free_bytes'] == 5 * 1024**3
assert d['resource_guard']['maximum_target_bytes'] == 1024**3
assert d['resource_guard']['poll_seconds'] == 1
check_tree(d)
assert os.stat(d['cli']['path']).st_mode & 0o777 == 0o555
receipt = json.loads(check(d['build_receipt']))
assert receipt['cli'] == d['cli'] == d['build_receipt_cli_binding']
assert receipt['status'] == 'commands_passed_pending_independent_acceptance'
cmds = d['commands']
assert len(cmds) == d['actual_command_count'] == 32
assert [r['index'] for r in cmds] == list(range(1, 33))
by_label = {r['label']: r for r in cmds}
assert len(by_label) == len(cmds)
for r in cmds:
    assert r['state'] == 'observed' and r['guard_stop'] is None
    assert r['peak_target_bytes'] <= 1024**3 and r['free_bytes_after'] >= 5 * 1024**3

def streams(r):
    return tuple(check(r['streams'][c]) for c in ('stdout', 'stderr'))

originals = {}
seen = set()
successes = []
negatives = []
assert len(d['runs']) == 20
for r in d['runs']:
    ident = (r['matrix'], r['jdk'], r['source_id'])
    assert ident not in seen
    seen.add(ident)
    mode, jdk, source = ident
    assert mode in ('debug', 'none') and jdk in ('javac8', 'javac23')
    compile_cmd = by_label[r['compile_command']]
    assert compile_cmd['exit_code'] == r['compile_exit']
    argv = compile_cmd['argv']
    flag = '-g' if mode == 'debug' else '-g:none'
    assert [s for s in argv if s in ('-g', '-g:none')] == [flag]
    assert argv[-2:] == [r['target_copy']['path'], r['harness_copy']['path']]
    assert check(r['source']['pin']) == check(r['target_copy'])
    assert check(r['harness_copy']) == check(d['harness'])
    if source.startswith('jarde-'):
        report = json.loads(check(r['source']['report_pin']))
        assert report['text'].encode() == check(r['target_copy'])
        assert len(report['methods']) == 11 and report['execution']['status'] == 'complete'
    if source.startswith('jadx-'):
        assert r['compile_exit'] != 0 and r['runtime_exit'] is None and r['runtime_command'] is None
        err = streams(compile_cmd)[1]
        assert b'Integer' in err and b'String' in err and b'add(' in err
        negatives.append(ident)
        continue
    assert r['compile_exit'] == 0 and r['runtime_exit'] == 0 and r['class_set_exact'] is True
    assert r['class_paths'] == ['cf11/OuterTryBoundaryRunner.class', 'cf11/UpstreamNestedLoops.class']
    assert len(r['classes']) == 2
    runtime = by_label[r['runtime_command']]
    assert runtime['exit_code'] == 0
    output = streams(runtime)
    assert hashlib.sha256(output[0]).hexdigest() == r['stdout_sha256']
    assert hashlib.sha256(output[1]).hexdigest() == r['stderr_sha256']
    if source == 'original':
        originals[(mode, jdk)] = output
    successes.append((ident, output))
assert len(originals) == 4 and len(successes) == 12 and len(negatives) == 8
oracle = originals[('debug', 'javac8')]
assert all(o == oracle for o in originals.values())
labels = ['iterator-runtime','iterator-error','hasNext-runtime','hasNext-error','next-runtime','next-error','output-add-runtime','output-add-error','success','empty']
lines = oracle[0].decode().splitlines()
assert [line.split('|')[0] for line in lines] == ['scenario=' + x for x in labels]
assert oracle[1] == b''
events = ['input.iterator','iterator.hasNext','iterator.next','output.add:value']
for index, boundary in enumerate(['iterator', 'hasNext', 'next', 'output.add']):
    common = '|events=[' + ', '.join(events[:index + 1]) + ']'
    assert lines[index * 2] == 'scenario=' + labels[index * 2] + '|exception=none|message=none' + common + '|effects=1|outputs=[]'
    assert lines[index * 2 + 1] == 'scenario=' + labels[index * 2 + 1] + '|exception=java.lang.AssertionError|message=injected-' + boundary + '-Error' + common + '|effects=0|outputs=[]'
assert lines[8] == 'scenario=success|exception=none|message=none|events=[input.iterator, iterator.hasNext, iterator.next, output.add:value, iterator.hasNext]|effects=1|outputs=[value]'
assert lines[9] == 'scenario=empty|exception=none|message=none|events=[input.iterator, iterator.hasNext]|effects=0|outputs=[]'
for ident, output in successes:
    assert output == originals[ident[:2]], ident
result = {'status': 'passed', 'auditor': pin(__file__), 'capture': pin(CAP / 'execution.json'), 'actual_commands': len(cmds), 'actual_raw_streams': 2 * len(cmds), 'checked_file_count': len(checked), 'checked_files': list(checked.values()), 'original_runtime_count': len(originals), 'jarde_fullclass_runtime_count': 8, 'jadx_compile_failed_no_runtime_count': len(negatives), 'scenarios_per_runtime': len(lines), 'stdout_oracle_sha256': hashlib.sha256(oracle[0]).hexdigest(), 'exact_oracle_lines': lines, 'all_runtime_outputs_byte_equal': True, 'target_absent': True}
with OUT.open('x') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('checked_files', 'exact_oracle_lines')}, ensure_ascii=False))
