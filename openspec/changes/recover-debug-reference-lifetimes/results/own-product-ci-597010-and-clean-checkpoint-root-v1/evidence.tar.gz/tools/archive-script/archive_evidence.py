#!/usr/bin/env python3
"""Package accepted own-CI and clean-checkpoint evidence without toolchain or Git access."""
from __future__ import annotations
import argparse
import datetime
import gzip
import hashlib
import json
import os
import re
import tarfile
from pathlib import Path, PurePosixPath


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def sha_file(path: Path) -> str:
    return sha(path.read_bytes())


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def file_rows(root: Path, role: str) -> list[tuple[Path, str, str]]:
    need(not root.is_symlink(), f'{role} input directory is a symlink')
    root = root.resolve(strict=True)
    need(root.is_dir(), f'{role} input is not a directory')
    rows = []
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError(f'{role} contains a symlink: {path}')
        rel = path.relative_to(root)
        if path.is_dir():
            continue
        need(path.is_file(), f'{role} contains a non-file entry: {path}')
        need(not ({'.git', 'target', 'fuzz'} & set(rel.parts)),
             f'{role} includes a prohibited build or Git directory: {rel}')
        need(not (path.stat().st_mode & 0o111), f'{role} includes an executable: {rel}')
        need(path.suffix.lower() not in {'.dylib', '.so', '.a', '.jar', '.class', '.exe', '.bin'},
             f'{role} includes a binary artifact: {rel}')
        need(path.stat().st_size <= 100 * 1024 * 1024,
             f'{role} member exceeds 100 MiB: {rel}')
        rows.append((path, rel.as_posix(), role))
    return rows


def read_json(path: Path, label: str) -> dict:
    need(path.is_file() and not path.is_symlink(), f'{label} is missing or linked')
    value = json.loads(path.read_text(encoding='utf-8'))
    need(isinstance(value, dict), f'{label} must be a JSON object')
    return value


def verify_ref(ref: dict, root: Path, label: str, found: list[dict], *, compressed=False) -> bytes:
    rel = PurePosixPath(ref.get('path', ''))
    need(not rel.is_absolute() and rel.parts and '..' not in rel.parts,
         f'{label} path is unsafe: {rel}')
    stream = root.joinpath(*rel.parts)
    need(not stream.is_symlink() and stream.is_file(), f'{label} file missing or linked: {rel}')
    raw = stream.read_bytes()
    need(type(ref.get('bytes')) is int and len(raw) == ref['bytes'] and
         sha(raw) == ref.get('sha256'), f'{label} bytes/SHA differ: {rel}')
    row = {'path': rel.as_posix(), 'bytes': len(raw), 'sha256': sha(raw), 'role': label}
    if compressed:
        unpacked = gzip.decompress(raw)
        need(type(ref.get('uncompressed_bytes')) is int and
             len(unpacked) == ref['uncompressed_bytes'] and
             sha(unpacked) == ref.get('raw_sha256'), f'{label} compressed payload bytes/SHA differ: {rel}')
        row.update({'uncompressed_bytes': len(unpacked), 'raw_sha256': sha(unpacked)})
    else:
        need('raw_sha256' not in ref and 'uncompressed_bytes' not in ref,
             f'{label} unexpectedly uses compressed-log metadata')
    found.append(row)
    return raw


def copy_member(source: Path, member: str, tar: tarfile.TarFile, rows: list[dict]) -> None:
    raw = source.read_bytes()
    info = tarfile.TarInfo(member)
    info.size = len(raw)
    info.mode = 0o644
    info.mtime = 0
    import io
    tar.addfile(info, io.BytesIO(raw))
    rows.append({'member': member, 'source': str(source), 'bytes': len(raw), 'sha256': sha(raw)})


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--capture-dir', type=Path, required=True)
    ap.add_argument('--acceptance', type=Path, required=True)
    ap.add_argument('--acceptance-sha256', required=True)
    ap.add_argument('--checkpoint-record', type=Path, required=True)
    ap.add_argument('--checkpoint-sha256', required=True)
    ap.add_argument('--tool-pin', action='append', default=[], metavar='NAME=PATH=SHA256',
                    help='repeat once per verifier/collector/runner/acceptor tool to preserve')
    ap.add_argument('--output', type=Path, required=True,
                    help='new output directory outside all input directories')
    args = ap.parse_args()

    need(not args.capture_dir.is_symlink(), 'capture directory is a symlink')
    capture_dir = args.capture_dir.resolve(strict=True)
    need(not args.acceptance.is_symlink() and not args.checkpoint_record.is_symlink(),
         'acceptance or checkpoint record is a symlink')
    acceptance = args.acceptance.resolve(strict=True)
    checkpoint = args.checkpoint_record.resolve(strict=True)
    out = args.output.resolve()
    need(re.fullmatch(r'[0-9a-f]{64}', args.acceptance_sha256) and sha_file(acceptance) == args.acceptance_sha256,
         'own-CI acceptance SHA differs from explicit pin')
    need(re.fullmatch(r'[0-9a-f]{64}', args.checkpoint_sha256) and sha_file(checkpoint) == args.checkpoint_sha256,
         'checkpoint SHA differs from explicit pin')
    need(not out.exists(), 'output directory must be new')
    need(not out.is_relative_to(capture_dir), 'output must be outside capture directory')

    capture_rows = file_rows(capture_dir, 'capture')
    cap_candidates = [p for p, rel, _ in capture_rows
                      if Path(rel).name == 'execution.json' or
                      (Path(rel).name.startswith('capture-execution') and Path(rel).suffix == '.json')]
    need(len(cap_candidates) == 1, 'capture directory must contain exactly one execution JSON')
    capture_exec_path = cap_candidates[0]
    capture_exec = read_json(capture_exec_path, 'capture execution')
    need(capture_exec.get('schema') == 'jarde-own-ci-capture-prep-v1' and
         capture_exec.get('status') == 'captured_all_success',
         "capture execution is not the v1 collector's completed all-success status")
    verified_capture_streams: list[dict] = []
    for command in capture_exec.get('commands', []):
        for stream_name in ('stdout', 'stderr'):
            ref = command.get(stream_name)
            need(isinstance(ref, dict), f'capture command lacks {stream_name} raw reference')
            verify_ref(ref, capture_dir, f'capture command {stream_name}', verified_capture_streams)
    jobs = capture_exec.get('jobs')
    need(isinstance(jobs, list) and jobs, 'capture execution has no job records')
    for job in jobs:
        raw_ref, compressed_ref = job.get('raw_log'), job.get('compressed_log')
        need(isinstance(raw_ref, dict) and isinstance(compressed_ref, dict),
             'capture job lacks raw_log or compressed_log')
        raw_bytes = verify_ref(raw_ref, capture_dir, 'job raw_log', verified_capture_streams)
        packed = verify_ref(compressed_ref, capture_dir, 'job compressed_log', verified_capture_streams, compressed=True)
        need(gzip.decompress(packed) == raw_bytes,
             'job raw_log bytes differ from decompressed compressed_log')
    need(verified_capture_streams, 'capture execution contains no verified command/log streams')

    own_ci = read_json(acceptance, 'own-CI acceptance')
    need(own_ci.get('schema') == 'jarde-own-ci-product-acceptance-v1' and
         own_ci.get('status') == 'accepted_product_ci_observation',
         'own-CI acceptance is not an accepted product-CI observation')
    need(own_ci.get('ci', {}).get('all_jobs_and_steps_succeeded') is True,
         'own-CI acceptance does not affirm all jobs and steps succeeded')
    need(own_ci.get('product_commit') == capture_exec.get('product_sha') and
         own_ci.get('run_id') == capture_exec.get('run_id'),
         'capture product_sha/run ID differs from accepted product_commit/run ID')
    checkpoint_obj = read_json(checkpoint, 'clean checkpoint execution')
    need(checkpoint_obj.get('schema') == 'reference-prefix-clean-main-audit-v1' and
         checkpoint_obj.get('status') == 'accepted_clean_main',
         'checkpoint is not an accepted reference-prefix clean-main audit')
    need(checkpoint_obj.get('product_commit') == own_ci.get('product_commit') and
         checkpoint_obj.get('own_ci_product_commit') == own_ci.get('product_commit') and
         checkpoint_obj.get('own_ci_run_id') == own_ci.get('run_id'),
         'clean-main checkpoint does not bind the accepted own-CI product/run')
    command_evidence = checkpoint_obj.get('commands')
    need(isinstance(command_evidence, list) and command_evidence and
         all(isinstance(row, dict) and row.get('exit_code') == 0 and
             type(row.get('stdout_bytes')) is int and type(row.get('stderr_bytes')) is int and
             re.fullmatch(r'[0-9a-f]{64}', row.get('stdout_sha256', '')) and
             re.fullmatch(r'[0-9a-f]{64}', row.get('stderr_sha256', '')) for row in command_evidence),
         'checkpoint command hash evidence is malformed or contains a failed command')

    tools = []
    names = set()
    for spec in args.tool_pin:
        parts = spec.split('=', 2)
        need(len(parts) == 3 and re.fullmatch(r'[A-Za-z0-9_.-]+', parts[0]) and
             re.fullmatch(r'[0-9a-f]{64}', parts[2]),
             'tool pin must be NAME=PATH=64-hex-SHA256')
        name, raw_path, expected = parts
        need(name not in names, f'duplicate tool pin name: {name}')
        names.add(name)
        raw_tool_path = Path(raw_path)
        need(not raw_tool_path.is_symlink(), f'tool source is a symlink: {name}')
        path = raw_tool_path.resolve(strict=True)
        need(path.is_file() and sha_file(path) == expected,
             f'tool source SHA differs from explicit pin: {name}')
        tools.append((name, path, expected))
    need(tools, 'at least one independently pinned tool source is required')

    sources = [(p, 'capture/' + rel, role) for p, rel, role in capture_rows]
    sources += [(acceptance, 'acceptance/own-ci-acceptance.json', 'acceptance'),
                (checkpoint, 'checkpoint-record/' + checkpoint.name, 'checkpoint-record')]
    for name, path, _ in tools:
        sources.append((path, 'tools/' + name + '/' + path.name, 'tool'))
    archive_script = Path(__file__).resolve(strict=True)
    sources.append((archive_script, 'tools/archive-script/' + archive_script.name, 'tool'))
    members = [member for _, member, _ in sources]
    need(len(members) == len(set(members)), 'archive member paths collide')

    out.mkdir(parents=True)
    tar_path = out / 'evidence.tar.gz'
    inventory = []
    with tarfile.open(tar_path, 'w:gz', compresslevel=6) as tar:
        for source, member, _role in sources:
            copy_member(source, member, tar, inventory)
        manifest = {'schema': 'jarde-own-ci-clean-checkpoint-archive-v2',
                    'product_commit': own_ci['product_commit'], 'run_id': own_ci['run_id'],
                    'capture_product_sha': capture_exec['product_sha'],
                    'capture_execution_status': capture_exec.get('status'),
                    'own_ci_status': own_ci.get('status'),
                    'checkpoint_status': checkpoint_obj.get('status'),
                    'checkpoint_command_evidence_count': len(command_evidence),
                    'checkpoint_raw_streams_present': False,
                    'verified_capture_streams': verified_capture_streams,
                    'members': inventory}
        manifest_raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
        info = tarfile.TarInfo('archive-manifest.json')
        info.size, info.mode, info.mtime = len(manifest_raw), 0o644, 0
        import io
        tar.addfile(info, io.BytesIO(manifest_raw))

    with tarfile.open(tar_path, 'r:gz') as tar:
        actual = set(tar.getnames())
        expected = set(members) | {'archive-manifest.json'}
        need(actual == expected, 'reopened archive member set differs from planned inventory')
        for row in inventory:
            raw = tar.extractfile(row['member']).read()
            need(len(raw) == row['bytes'] and sha(raw) == row['sha256'],
                 f'reopened archive member bytes/SHA differ: {row["member"]}')
        manifest_read = json.load(tar.extractfile('archive-manifest.json'))
        need(manifest_read.get('members') == inventory, 'reopened manifest differs from planned inventory')

    readme = (f"# Own-CI and clean-checkpoint evidence archive\n\n"
              f"Product commit: `{own_ci['product_commit']}`. Workflow run: `{own_ci['run_id']}`. "
              f"Own-CI acceptance status: `{own_ci['status']}`. Capture status: `{capture_exec.get('status')}`. "
              f"Checkpoint status: `{checkpoint_obj.get('status')}`; its {len(command_evidence)} command results are recorded as byte-count/SHA evidence, and no checkpoint raw stream files were present in its schema.\n\n"
              f"The archive contains {len(inventory)} pinned evidence/tool members and "
              f"{len(verified_capture_streams)} individually verified capture command/log streams. Every source member was checked "
              f"by byte count and SHA-256 before packaging; the tar was reopened and every member rechecked.\n\n"
              f"This archive records only the supplied acceptance and checkpoint evidence. It does not "
              f"assert release, deployment, or other product completion beyond those records.\n")
    (out / 'README.md').write_text(readme, encoding='utf-8')
    print(json.dumps({'archive': str(tar_path), 'members': len(inventory) + 1,
                      'capture_streams': len(verified_capture_streams),
                      'checkpoint_command_evidence_count': len(command_evidence),
                      'checkpoint_raw_streams_present': False,
                      'own_ci_status': own_ci['status'], 'checkpoint_status': checkpoint_obj.get('status')},
                     indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
