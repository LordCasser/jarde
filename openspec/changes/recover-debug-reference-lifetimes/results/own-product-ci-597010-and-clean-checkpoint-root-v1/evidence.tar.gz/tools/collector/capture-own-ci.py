#!/usr/bin/env python3
"""Capture one explicitly selected product GitHub Actions run, without accepting it."""
from __future__ import annotations

import argparse
import datetime as dt
import gzip
import hashlib
import json
import re
import subprocess
import sys
import time
from pathlib import Path


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def stamp() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def invoke(argv: list[str], cwd: Path) -> dict:
    started = stamp()
    before = time.monotonic()
    try:
        p = subprocess.run(argv, cwd=cwd, capture_output=True, check=False)
        return {'argv': argv, 'cwd': str(cwd), 'started_at': started,
                'duration_seconds': time.monotonic() - before,
                'exit_code': p.returncode, 'spawn_error': None,
                'stdout': p.stdout or b'', 'stderr': p.stderr or b''}
    except OSError as exc:
        return {'argv': argv, 'cwd': str(cwd), 'started_at': started,
                'duration_seconds': time.monotonic() - before, 'exit_code': None,
                'spawn_error': f'{type(exc).__name__}: {exc}', 'stdout': b'',
                'stderr': str(exc).encode()}


def save_stream(out: Path, stem: str, stream: bytes) -> dict:
    path = out / stem
    with path.open('xb') as f:
        f.write(stream)
    return {'path': path.name, 'bytes': len(stream), 'sha256': sha(stream)}


def save_command(out: Path, stem: str, row: dict) -> dict:
    saved = {k: v for k, v in row.items() if k not in ('stdout', 'stderr')}
    saved['stdout'] = save_stream(out, stem + '.stdout.raw', row['stdout'])
    saved['stderr'] = save_stream(out, stem + '.stderr.raw', row['stderr'])
    return saved


def persist(path: Path, doc: dict) -> None:
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    tmp.replace(path)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--product-sha', required=True, help='exact lowercase 40-hex product commit')
    ap.add_argument('--run-id', required=True, help='exact decimal GitHub Actions run ID')
    ap.add_argument('--output', required=True, type=Path, help='new private capture directory; must not exist')
    ap.add_argument('--repo-root', required=True, type=Path, help='the product checkout whose CI run is being captured')
    a = ap.parse_args()
    if not re.fullmatch(r'[0-9a-f]{40}', a.product_sha):
        ap.error('--product-sha must be lowercase 40-hex')
    if not re.fullmatch(r'[1-9][0-9]*', a.run_id):
        ap.error('--run-id must be a positive decimal integer')
    root = a.repo_root.resolve(strict=True)
    out = a.output.expanduser().resolve()
    if out.exists():
        raise SystemExit(f'refusing to overwrite capture directory: {out}')
    out.mkdir(parents=True)
    receipt_path = out / 'capture-execution.json'
    self_path = Path(__file__).resolve()
    doc = {'schema': 'jarde-own-ci-capture-prep-v1', 'status': 'capturing',
           'product_sha': a.product_sha, 'run_id': int(a.run_id),
           'repo_root': str(root),
           'collector': {'path': str(self_path), 'sha256': sha(self_path.read_bytes())},
           'commands': [], 'jobs': []}
    persist(receipt_path, doc)

    def run(argv: list[str], stem: str) -> tuple[dict, dict]:
        row = invoke(argv, root)
        saved = save_command(out, stem, row)
        doc['commands'].append(saved)
        persist(receipt_path, doc)
        return row, saved

    summary_argv = ['gh', 'run', 'view', a.run_id, '--json',
                    'headSha,status,conclusion,jobs,url']
    summary_row, summary_saved = run(summary_argv, 'run-summary')
    doc['summary_command'] = summary_saved
    try:
        summary = json.loads(summary_row['stdout'])
    except Exception as exc:
        doc.update(status='capture_failed', failure=f'summary is not JSON: {type(exc).__name__}')
        persist(receipt_path, doc)
        return 1
    doc['summary'] = summary
    jobs = summary.get('jobs')
    if not isinstance(jobs, list) or not jobs:
        doc.update(status='capture_failed', failure='run summary has no job inventory')
        persist(receipt_path, doc)
        return 1

    # Capture every job log, including failed or auxiliary jobs. Keep API inventory
    # and per-job command streams so a later verifier can account for every step.
    for index, job in enumerate(jobs):
        job_id = job.get('databaseId')
        name = job.get('name')
        if not isinstance(job_id, int) or not isinstance(name, str) or not name:
            doc.update(status='capture_failed', failure=f'malformed job row at index {index}')
            persist(receipt_path, doc)
            return 1
        stem = f'job-{index:03d}'
        argv = ['gh', 'run', 'view', a.run_id, '--job', str(job_id), '--log']
        log_row, log_saved = run(argv, stem)
        packed = gzip.compress(log_row['stdout'], mtime=0)
        packed_ref = save_stream(out, stem + '.log.gz', packed)
        # Keep compressed bytes pinned and also describe the exact uncompressed source.
        packed_ref['uncompressed_bytes'] = len(log_row['stdout'])
        packed_ref['raw_sha256'] = sha(log_row['stdout'])
        raw_log_ref = save_stream(out, stem + '.log.stdout.raw', log_row['stdout'])
        doc['jobs'].append({'index': index, 'database_id': job_id, 'name': name,
                            'status': job.get('status'), 'conclusion': job.get('conclusion'),
                            'steps': job.get('steps', []), 'log_command': log_saved,
                            'compressed_log': packed_ref, 'raw_log': raw_log_ref})
        persist(receipt_path, doc)

    run_id_match = re.search(r'/actions/runs/(\d+)(?:$|[/?#])', summary.get('url', ''))
    all_success = (summary_row['exit_code'] == 0 and summary_row['spawn_error'] is None
                   and summary.get('headSha') == a.product_sha
                   and summary.get('status') == 'completed'
                   and summary.get('conclusion') == 'success'
                   and run_id_match is not None and int(run_id_match.group(1)) == int(a.run_id)
                   and len(doc['jobs']) == len(jobs)
                   and all(j.get('status') == 'completed' and j.get('conclusion') == 'success'
                           and isinstance(j.get('steps'), list) and j['steps']
                           and all(s.get('status') == 'completed' and s.get('conclusion') == 'success'
                                   for s in j['steps']) for j in doc['jobs'])
                   and all(c.get('exit_code') == 0 and c.get('spawn_error') is None
                           for c in doc['commands']))
    doc['status'] = 'captured_all_success' if all_success else 'captured_observation_requires_review'
    doc['job_count'] = len(doc['jobs'])
    doc['step_count'] = sum(len(j['steps']) for j in doc['jobs'] if isinstance(j.get('steps'), list))
    persist(receipt_path, doc)
    print(json.dumps({'status': doc['status'], 'product_sha': a.product_sha,
                      'run_id': int(a.run_id), 'jobs': doc['job_count'],
                      'steps': doc['step_count'], 'receipt': str(receipt_path)}, ensure_ascii=False))
    return 0 if all_success else 1


if __name__ == '__main__':
    sys.exit(main())
