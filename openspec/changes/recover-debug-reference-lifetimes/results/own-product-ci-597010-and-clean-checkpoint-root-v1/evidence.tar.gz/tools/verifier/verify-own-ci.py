#!/usr/bin/env python3
"""Read-only acceptance of an exact product CI run against a fresh ordered-field workspace receipt."""
from __future__ import annotations
import argparse, ast, gzip, hashlib, importlib.util, json, re, stat, sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
CI_HELPER_PATH = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/verify-conditional-ci-root-v5.py'
CI_HELPER_SHA256 = 'bea37c7d4d37182168a7c1cbbde3ee31c94d61f6bc32667bedbdd02ce7e5b0ca'
CAPTURE_PATH = Path('/private/tmp/jarde-current-own-ci-verifier-prep-luna-v4/capture-own-ci.py')
CAPTURE_SHA256 = '484dca8612ace135b2860445bb1af4628c05c857d38d6bbce9c9384de7977c37'
WORKSPACE_RUNNER = Path('/private/tmp/jarde-reference-prefix-workspace-prep-luna-v4/workspace_runner.py')
WORKSPACE_RUNNER_SHA256 = '691e7c073c202ff7782ec8323f0a8c1892ad8748fd55c6d952515f9809736c22'
WORKSPACE_ACCEPTOR = Path('/private/tmp/jarde-reference-prefix-workspace-acceptor-root-v5/accept_workspace.py')
WORKSPACE_ACCEPTOR_SHA256 = '5f24f35d27d50a5fca7b128247a3bc094f2109de958af875cf9128a886105c79'
WORKSPACE_SCHEMA = 'ordered-field-full-workspace-run-v2'
WORKSPACE_ACCEPTANCE_SCHEMA = 'ordered-field-full-workspace-acceptance-v2'
CAPTURE_SCHEMA = 'jarde-own-ci-capture-prep-v1'
BASE_ENV = {'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0',
            'CARGO_PROFILE_TEST_DEBUG':'0','RUST_TEST_THREADS':'1','CARGO_TERM_COLOR':'always'}
FREE_LIMIT, TARGET_LIMIT = 5*1024**3, 1024**3
SUMMARY_RE = re.compile(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;')
OUTCOME_RE = re.compile(r'^test ([^\n]+?) \.\.\. (?:(?!^test ).)*?\b(ok|ignored|FAILED)(?:, [^\n]*)?$', re.M | re.S)
ANSI_RE = re.compile(r'\x1b\[[0-9;]*m')


def need(ok, message):
    if not ok: raise ValueError(message)
def sha(raw: bytes) -> str: return hashlib.sha256(raw).hexdigest()
def sha_file(path: Path) -> str: return sha(path.read_bytes())
def load_json(path: Path): return json.loads(path.read_text(encoding='utf-8'))
def load_module(name: str, path: Path):
    spec=importlib.util.spec_from_file_location(name,path)
    need(spec is not None and spec.loader is not None,'cannot load pinned module: '+str(path))
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def stream_bytes(ref: dict, evidence_root: Path) -> bytes:
    path=Path(ref.get('path',''))
    if not path.is_absolute(): path=evidence_root/path
    need(not path.is_symlink(),'raw stream is a symlink: '+str(path))
    path=path.resolve(strict=True)
    need(path.is_relative_to(evidence_root.resolve(strict=True)),'raw stream escapes its receipt directory: '+str(path))
    raw=path.read_bytes()
    need(len(raw)==ref.get('bytes') and sha(raw)==ref.get('sha256'),'raw stream pin mismatch: '+str(path))
    return raw

def source_manifest_pins(rows: list[dict]) -> dict[str,str]:
    need(isinstance(rows,list) and rows,'source manifest is absent')
    result={}
    for row in rows:
        need(isinstance(row,dict) and isinstance(row.get('path'),str) and
             re.fullmatch(r'[0-9a-f]{64}',row.get('sha256','')),'malformed source manifest row')
        path=Path(row['path'])
        if path.is_absolute():
            need(path.resolve().is_relative_to(ROOT),'focused source path escapes product root')
            key=path.resolve().relative_to(ROOT).as_posix()
        else: key=path.as_posix()
        relative=Path(key)
        need(not relative.is_absolute() and '..' not in relative.parts,'source manifest path escapes product root')
        need(type(row.get('bytes')) is int and row['bytes']>=0,'source manifest byte length is missing')
        need(key not in result,'duplicate path in source manifest')
        live=ROOT/relative
        need(live.is_file() and not live.is_symlink() and live.stat().st_size==row['bytes'] and sha_file(live)==row['sha256'],
                 'focused source row no longer matches live bytes: '+key)
        result[key]=row['sha256']
    return result

def check_command(row: dict, index: int, argv: list[str], env_expected: dict[str,str], evidence_root: Path,
                  *, cleanup_only=False):
    need(row.get('index')==index and row.get('argv')==argv and row.get('cwd')==str(ROOT),
         f'command {index} index/argv/cwd differs')
    need(row.get('exit_code')==0 and row.get('guard_stop') is None,f'command {index} failed or hit guard')
    need(row.get('env_overrides')==env_expected,f'command {index} environment differs')
    need(set(row.get('streams',{}))=={'stdout','stderr'},f'command {index} lacks raw streams')
    for ref in row['streams'].values(): stream_bytes(ref,evidence_root)
    if cleanup_only:
        proof=row.get('cleanup_only',{})
        need(argv==['cargo','clean'] and proof.get('exact_argv')==argv and
             proof.get('space_precheck_bypassed') is True and proof.get('space_monitor_abort_bypassed') is True and
             all(type(proof.get(side,{}).get(key)) is int and proof[side][key]>=0
                 for side in ('observed_before','observed_after') for key in ('target_bytes','free_bytes')) and
             row.get('free_bytes_after')==proof.get('observed_after',{}).get('free_bytes') and
             type(row.get('peak_target_bytes')) is int and
             row['peak_target_bytes']>=max(proof.get('observed_before',{}).get('target_bytes',0),
                                           proof.get('observed_after',{}).get('target_bytes',0)),
             'cleanup bypass is not scoped to exact cargo clean observations')
    else:
        need(row.get('cleanup_only') is None and type(row.get('peak_target_bytes')) is int and
             row['peak_target_bytes']<=TARGET_LIMIT and type(row.get('free_bytes_after')) is int and
             row['free_bytes_after']>=FREE_LIMIT,'command exceeded or omitted resource guard')

def parse_test_stream(raw: bytes):
    text=ANSI_RE.sub('',raw.decode('utf-8',errors='replace'))
    summaries=[(status,int(passed),int(failed),int(ignored)) for status,passed,failed,ignored in SUMMARY_RE.findall(text)]
    outcomes=[(name,status) for name,status in OUTCOME_RE.findall(text)]
    return summaries,outcomes

def load_ci():
    need(CI_HELPER_PATH.is_file() and sha_file(CI_HELPER_PATH)==CI_HELPER_SHA256,'pinned CI parser changed')
    return load_module('ordered_field_ci_parser',CI_HELPER_PATH)

def workflow_bytes(product: str, ci, pins: dict[str,str]) -> bytes:
    rel='.github/workflows/ci.yml'; raw=ci.git_blob(product,rel)
    need(sha(raw)==pins.get(rel)==sha_file(ROOT/rel),'selected workflow differs from live/product source closure')
    return raw

def workflow_clippy_argv(product: str, ci, pins: dict[str,str]) -> list[str]:
    text=workflow_bytes(product,ci,pins).decode('utf-8')
    start=text.index('          cargo clippy'); end=text.index('\n\n',start)
    return text[start:end].split()

def verify_capture(capture_dir: Path, product: str, run_id: str, ci):
    need(not capture_dir.is_symlink(),'capture directory is linked')
    capture_dir=capture_dir.resolve(strict=True); receipt=capture_dir/'capture-execution.json'
    need(not receipt.is_symlink(),'capture receipt is linked')
    doc=load_json(receipt)
    need(doc.get('schema')==CAPTURE_SCHEMA and doc.get('status')=='captured_all_success',
         'capture is incomplete or did not observe all successful jobs/steps')
    need(doc.get('product_sha')==product and doc.get('run_id')==int(run_id) and
         doc.get('repo_root')==str(ROOT),'capture product/run/repository binding differs')
    collector=doc.get('collector',{}); cp=Path(collector.get('path',''))
    need(not cp.is_symlink() and cp.resolve()==CAPTURE_PATH.resolve() and cp.is_file() and
         sha_file(cp)==CAPTURE_SHA256==collector.get('sha256'),
         'capture collector path/hash differs from prepared all-job adapter')
    summary=doc.get('summary',{})
    need(summary.get('headSha')==product and summary.get('status')=='completed' and
         summary.get('conclusion')=='success','CI summary head/status/conclusion differs')
    match=re.search(r'/actions/runs/(\d+)(?:$|[/?#])',summary.get('url',''))
    need(match and int(match.group(1))==int(run_id),'CI URL does not identify requested run')
    summary_jobs=summary.get('jobs')
    need(isinstance(summary_jobs,list) and summary_jobs,'CI summary has no dynamic job inventory')
    commands=doc.get('commands',[]); jobs=doc.get('jobs',[])
    need(len(jobs)==len(summary_jobs) and len(commands)==len(jobs)+1,
         'capture command/job inventory is incomplete')
    command_files=set(); all_logs=[]; seen_ids=set(); step_count=0
    def verify_command(row, argv, label):
        need(row.get('argv')==argv and row.get('cwd')==str(ROOT) and row.get('exit_code')==0 and
             row.get('spawn_error') is None, f'{label} command failed or differs')
        need(set(row.get('stdout',{}))=={'path','bytes','sha256'} and
             set(row.get('stderr',{}))=={'path','bytes','sha256'},f'{label} command lacks pinned raw streams')
        out=stream_bytes(row['stdout'],capture_dir); stream_bytes(row['stderr'],capture_dir)
        for ref in (row['stdout'],row['stderr']):
            need(ref['path'] not in command_files, f'{label} reuses a raw stream path')
            command_files.add(ref['path'])
        return out
    summary_argv=['gh','run','view',str(run_id),'--json','headSha,status,conclusion,jobs,url']
    summary_stdout=verify_command(commands[0],summary_argv,'summary')
    need(json.loads(summary_stdout)==summary,'captured summary stdout differs from receipt summary')
    summary_command=doc.get('summary_command',{})
    need(summary_command==commands[0],'summary command reference differs')
    for index,(job,api_job) in enumerate(zip(jobs,summary_jobs)):
        job_id=api_job.get('databaseId'); name=api_job.get('name')
        need(type(job_id) is int and job_id not in seen_ids and isinstance(name,str) and name,
             f'malformed/duplicate API job identity at index {index}')
        seen_ids.add(job_id)
        need(job.get('index')==index and job.get('database_id')==job_id and job.get('name')==name and
             job.get('status')==api_job.get('status') and job.get('conclusion')==api_job.get('conclusion') and
             job.get('steps')==api_job.get('steps'),f'captured job/step inventory differs at index {index}')
        steps=job.get('steps'); step_count+=len(steps) if isinstance(steps,list) else 0
        need(job.get('status')=='completed' and job.get('conclusion')=='success' and isinstance(steps,list) and steps and
             all(x.get('status')=='completed' and x.get('conclusion')=='success' for x in steps),
             f'job or one of its steps did not succeed: {name}')
        row=commands[index+1]
        argv=['gh','run','view',str(run_id),'--job',str(job_id),'--log']
        raw=verify_command(row,argv,f'job {index}')
        need(job.get('log_command')==row,'job log command reference differs')
        packed_ref=job.get('compressed_log',{}); raw_ref=job.get('raw_log',{})
        packed=stream_bytes(packed_ref,capture_dir); decoded=stream_bytes(raw_ref,capture_dir)
        need(gzip.decompress(packed)==raw and decoded==raw and gzip.compress(raw,mtime=0)==packed,
             f'job raw/compressed log differs from the captured command stdout: {name}')
        need(packed_ref.get('uncompressed_bytes')==len(raw) and packed_ref.get('raw_sha256')==sha(raw),
             f'job compressed-log metadata differs: {name}')
        for ref in (packed_ref,raw_ref):
            need(isinstance(ref.get('path'),str) and ref['path'] not in command_files,
                 f'job {index} reuses a raw/compressed log path')
            command_files.add(ref['path'])
        all_logs.append({'index':index,'name':name,'raw':raw})
    need(doc.get('job_count')==len(jobs) and doc.get('step_count')==step_count,
         'dynamic captured job/step totals differ')
    need(all(row.get('exit_code')==0 and row.get('spawn_error') is None for row in commands),
         'one or more summary/job log retrieval commands failed')
    actual_files={p.name for p in capture_dir.iterdir() if p.is_file()}
    need(actual_files==command_files|{receipt.name},'capture has missing or unreferenced files')
    need(all(p.is_file() and not p.is_symlink() for p in capture_dir.iterdir()),
         'capture contains linked or non-file evidence')
    return doc,summary,step_count,all_logs,sha_file(receipt)

def verify_focus(path: Path, focus_sha: str, cli_path: Path, cli_sha: str, focused_runner_path: Path,
                 focused_runner_sha: str, product: str, ci, pins, runner):
    raw=path.read_bytes(); need(sha(raw)==focus_sha,'focused receipt SHA differs'); focus=json.loads(raw)
    need(focus.get('status')=='commands_passed_pending_independent_acceptance',
         'focused check is not complete/passing')
    focused_runner_path=focused_runner_path.resolve(strict=True)
    runner_pin=focus.get('runner',{})
    need(not focused_runner_path.is_symlink() and focused_runner_path.is_file() and
         sha_file(focused_runner_path)==focused_runner_sha==runner_pin.get('sha256') and
         runner_pin.get('path')==str(focused_runner_path) and runner_pin.get('bytes')==focused_runner_path.stat().st_size,
         'future focused runner path/bytes/hash do not match the v10 receipt')
    before=source_manifest_pins(focus.get('source_manifest_before',[]))
    after=source_manifest_pins(focus.get('source_manifest_after',[]))
    need(before==after,'focused source closure changed')
    expected,spec_pin=runner.validate_focused_receipt(focus,path)
    expected_clippy=workflow_clippy_argv(product,ci,pins)
    need(expected.count(['cargo','fmt','--all','--','--check'])==1 and expected.count(expected_clippy)==1 and
         expected.count(['cargo','build','-p','jarde-cli','--locked'])==1 and
         expected.count(['openspec','validate','--all','--strict','--no-interactive'])==1 and
         any(argv[:2]==['cargo','test'] for argv in expected),
         'focused command spec omits an exact current workflow gate')
    cli=focus.get('cli',{}); cli_path=cli_path.resolve(strict=True)
    need(not cli_path.is_symlink() and cli_path==Path(cli.get('path','')).resolve(strict=True) and
         cli_path.stat().st_size==cli.get('bytes') and sha_file(cli_path)==cli.get('sha256')==cli_sha and
         stat.S_IMODE(cli_path.stat().st_mode)==0o555,
         'CLI argv pin does not match the focused frozen executable')
    return (focus, {'path':str(path.resolve()),'sha256':focus_sha}, before,
            {'path':str(cli_path),'bytes':cli_path.stat().st_size,'sha256':cli_sha,'mode':oct(stat.S_IMODE(cli_path.stat().st_mode))},
            {'path':str(focused_runner_path),'bytes':focused_runner_path.stat().st_size,'sha256':focused_runner_sha})

def expected_workspace_batches_from_runner(runner_path: Path, metadata: dict):
    """Run only the pinned runner's pure nested metadata planner, not its guarded main."""
    need(runner_path.is_file() and not runner_path.is_symlink() and
         sha_file(runner_path) == WORKSPACE_RUNNER_SHA256,
         'pinned workspace runner changed before metadata-plan extraction')
    tree = ast.parse(runner_path.read_text(encoding='utf-8'), filename=str(runner_path))
    mains = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main']
    need(len(mains) == 1, 'pinned workspace runner must have exactly one main function')
    planners = [node for node in ast.walk(mains[0])
                if isinstance(node, ast.FunctionDef) and node.name == 'make_batches']
    need(len(planners) == 1, 'pinned runner main must define exactly one make_batches planner')
    planner = planners[0]
    need(not planner.decorator_list and planner.args.args and planner.args.args[0].arg == 'metadata',
         'pinned make_batches signature differs')
    module = ast.fix_missing_locations(ast.Module(body=[planner], type_ignores=[]))
    namespace = {}
    exec(compile(module, str(runner_path) + ':make_batches', 'exec'), namespace, namespace)
    planned, inventory = namespace['make_batches'](metadata)
    need(isinstance(planned, list) and planned and isinstance(inventory, list),
         'pinned runner make_batches returned malformed plan')
    return planned, inventory


def verify_workspace(path: Path, workspace_sha: str, acceptance_path: Path, acceptance_sha: str,
                     focus: dict, focus_info: dict, focus_pins: dict[str,str], cli_pin: dict, runner_path: Path, runner, acceptor, ci, seeds):
    path=path.resolve(strict=True); ex_path=path/'execution.json'; meta_path=path/'metadata.json'
    raw=ex_path.read_bytes(); need(sha(raw)==workspace_sha,'workspace receipt SHA differs'); ex=json.loads(raw)
    need(ex.get('schema')==WORKSPACE_SCHEMA and ex.get('status')=='passed' and ex.get('no_carried_execution') is True,
         'fresh workspace receipt is not complete/passing')
    need(ex.get('rust_min_stack') is None and ex.get('seeds')==list(seeds) and
         ex.get('guard_limits')=={'minimum_free_bytes':FREE_LIMIT,'maximum_target_bytes':TARGET_LIMIT,'poll_interval_seconds':1},
         'workspace seeds/default stack/guard limits differ')
    source_before=ex.get('source_pins_before'); source_after=ex.get('source_pins_after')
    need(isinstance(source_before,dict) and source_before==source_after,'workspace source closure changed')
    live=runner.pin_sources(runner.source_paths())
    need(live==source_before==focus_pins,'focused/workspace/live source closure differs')
    need(ex.get('source_closure_count_at_start')==len(live),'workspace source count differs from dynamic closure')
    spec_sha=focus.get('command_spec',{}).get('sha256')
    bound=ex.get('focused_input_receipt',{})
    need(bound.get('path')==focus_info['path'] and bound.get('sha256')==focus_info['sha256'] and
         bound.get('status')==focus.get('status') and bound.get('command_spec_sha256')==spec_sha,
         'workspace receipt is not bound to this focused receipt')
    cli=ex.get('candidate_cli',{})
    need({k:cli.get(k) for k in ('path','bytes','sha256')}=={k:cli_pin[k] for k in ('path','bytes','sha256')},
         'workspace CLI does not match the focused frozen CLI argv pin')
    acceptance_path=acceptance_path.resolve(strict=True); accepted_raw=acceptance_path.read_bytes()
    need(sha(accepted_raw)==acceptance_sha,'workspace acceptance SHA differs'); accepted=json.loads(accepted_raw)
    need(accepted.get('schema')==WORKSPACE_ACCEPTANCE_SCHEMA and accepted.get('status')=='accepted_local_workspace_only' and
         accepted.get('not_ci_or_product_release_acceptance') is True and accepted.get('execution_sha256')==workspace_sha and
         accepted.get('focused_receipt_sha256')==focus_info['sha256'] and accepted.get('source_pin_count')==len(live) and
         accepted.get('target_absent') is True and accepted.get('target_count')==ex.get('expected_target_count') and
         accepted.get('batch_count_per_seed')==ex.get('expected_batch_count') and accepted.get('seeds')==list(seeds),
         'workspace independent acceptance does not bind this run/closure')
    need(accepted.get('required_named_test_outcomes_by_seed')==ex.get('required_named_test_outcomes_by_seed'),
         'accepted required named-test gates differ from workspace execution')
    metadata_raw=meta_path.read_bytes(); metadata=json.loads(metadata_raw); planned,inventory=expected_workspace_batches_from_runner(runner_path,metadata)
    by_id,by_named,meta_inventory=ci.metadata_targets(metadata); batches=len(planned)
    need(set(inventory)==set(meta_inventory)==set(tuple(x) for x in ex.get('target_inventory',[])) and
         len(meta_inventory)==ex.get('expected_target_count')==ex.get('metadata',{}).get('target_count') and
         ex.get('metadata',{}).get('batch_count')==batches and
         len(ex.get('static_manifest_target_inventory',[]))==len(meta_inventory) and
         set(tuple(x) for x in ex['static_manifest_target_inventory'])==set(meta_inventory),
         'Cargo metadata target inventory differs from exact workspace plan')
    commands=ex.get('commands',[]); need(len(commands)==2+2*batches+1 and
         ex.get('expected_command_count_including_clean')==len(commands)==ex.get('observed_command_count_including_clean'),
         'workspace command count differs from two metadata-derived sweeps')
    need(commands[0].get('argv')==['cargo','fmt','--all','--','--check'] and
         commands[1].get('argv')==['cargo','metadata','--no-deps','--format-version','1','--locked'],
         'workspace fmt/metadata preflight order differs')
    env_base={**BASE_ENV,'PROPTEST_RNG_SEED':seeds[0],'CARGO_PROFILE_TEST_STRIP':'symbols'}
    need(stream_bytes(commands[1]['streams']['stdout'],path)==metadata_raw,'workspace metadata differs from raw command stdout')
    observations={seed:[] for seed in seeds}; seen={seed:set() for seed in seeds}; all_raw=set()
    for index,row in enumerate(commands[:-1]):
        for ref in row.get('streams',{}).values(): all_raw.add(Path(ref['path']).resolve())
        if index==0: check_command(row,index,['cargo','fmt','--all','--','--check'],env_base,path); continue
        if index==1: check_command(row,index,['cargo','metadata','--no-deps','--format-version','1','--locked'],env_base,path); continue
        offset=index-2; seed=seeds[offset//batches]; batch=offset%batches
        need(row.get('proptest_seed')==seed and row.get('argv')==planned[batch],f'workspace batch {index} order/seed differs')
        env={**BASE_ENV,'PROPTEST_RNG_SEED':seed,'CARGO_PROFILE_TEST_STRIP':'symbols'}
        check_command(row,index,planned[batch],env,path)
        observed=ci.local_command_observation(row,by_id,by_named); ci.check_workspace_argv(row.get('argv',[]),observed,by_named)
        for suite in observed:
            suite['outcomes']=[(name,'ignored' if state.startswith('ignored') else state) for name,state in suite['outcomes']]
        need(len(observed)==len(row.get('executed_targets',[]))==len(row.get('observed_summaries',[])),
             f'workspace batch {index} target summaries differ')
        actual=[(n,s) for suite in observed for n,s in suite['outcomes']]
        stored=[(x.get('name'),x.get('status')) for x in row.get('named_test_outcomes',[])]
        need(actual==stored and row.get('named_test_outcome_count')==len(actual),f'workspace batch {index} named outcomes differ from raw stdout')
        sums=[('ok' if x['counts'][1]==0 else 'FAILED',*x['counts']) for x in observed]
        stored_sums=[(x.get('status'),x.get('passed'),x.get('failed'),x.get('ignored')) for x in row.get('observed_summaries',[])]
        need(sums==stored_sums,f'workspace batch {index} summary counts differ from raw stdout')
        for suite in observed:
            key=suite['key']; need(key not in seen[seed],'workspace target repeated in seed')
            seen[seed].add(key); observations[seed].append(suite)
    totals_by_seed={s:[sum(x['counts'][i] for x in observations[s]) for i in range(3)] for s in seeds}
    for seed in seeds: need(seen[seed]==set(meta_inventory),'workspace target inventory incomplete for '+seed)
    totals=[sum(totals_by_seed[s][i] for s in seeds) for i in range(3)]
    count=sum(len(observations[s]) for s in seeds)
    need(ex.get('format_check')=={'exit_code':0,'guard_stop':None},'workspace format check did not pass')
    need(ex.get('workspace_totals')==totals and ex.get('workspace_summary_count')==count,'workspace totals differ from raw target summaries')
    need(accepted.get('test_totals')=={'passed':totals[0],'failed':totals[1],'ignored':totals[2],
         'target_summary_count':count,'named_test_outcome_count':sum(len(x['outcomes']) for s in seeds for x in observations[s])},
         'acceptance totals differ from raw workspace observations')
    clean_index=len(commands)-1; clean=commands[clean_index]
    env={**BASE_ENV,'PROPTEST_RNG_SEED':seeds[-1],'CARGO_PROFILE_TEST_STRIP':'symbols'}
    check_command(clean,clean_index,['cargo','clean'],env,path,cleanup_only=True)
    for ref in clean.get('streams',{}).values(): all_raw.add(Path(ref['path']).resolve())
    raw_files={p.resolve() for p in path.glob('*.raw') if p.is_file()}
    need(raw_files==all_raw and len(all_raw)==len(commands)*2,'workspace raw stream inventory is incomplete')
    cleanup=ex.get('cleanup',{})
    need(cleanup.get('status')=='passed' and cleanup.get('target_absent_after') is True and cleanup.get('pins_unchanged') is True and cleanup.get('command')==clean and not (ROOT/'target').exists(),
         'workspace finally-clean postcondition differs')
    need(ex.get('runner',{}).get('sha256_before')==ex.get('runner',{}).get('sha256_after')==sha_file(runner_path),
         'workspace runner changed during recorded run')
    required=set(runner.REQUIRED_NAMED_TESTS)
    required_outcomes={}
    for seed in seeds:
        matches=[]
        for name in sorted(required):
            found=[state for suite in observations[seed] for actual,state in suite['outcomes'] if actual==name or actual.endswith('::'+name)]
            need(len(found)==1 and found[0]=='ok',f'required local named test not exactly once passing for {seed}: {name}')
            matches.append(name)
        required_outcomes[seed]=matches
        for ignored_name in sorted(runner.REQUIRED_IGNORED_TESTS):
            ignored=[state for suite in observations[seed] for actual,state in suite['outcomes']
                     if actual==ignored_name or actual.endswith('::'+ignored_name)]
            need(len(ignored)==1 and ignored[0]=='ignored',
                 f'required ignored gate is not exactly once ignored for {seed}: {ignored_name}')
        field_expected=acceptor.FOCUSED_FIELD_EXPECTED
        field_suites=[suite for suite in observations[seed]
                      if suite['key'] in (('jarde-java','jarde_java','lib'),('jarde-java','p3_patterns','test'))]
        field_outcomes=[(name,state) for suite in field_suites for name,state in suite['outcomes']
                        if name in field_expected]
        need(len(field_outcomes)==len(field_expected) and dict(field_outcomes)==field_expected,
             f'original field-focused outcomes differ for {seed}')
        java_lib=[suite for suite in observations[seed] if suite['key']==('jarde-java','jarde_java','lib')]
        need(len(java_lib)==1 and java_lib[0]['counts'][1]==0 and java_lib[0]['counts'][0]>=390 and
             len(java_lib[0]['outcomes'])==java_lib[0]['counts'][0],
             f'jarde-java library focused baseline differs for {seed}')
        p3_target=[suite for suite in observations[seed] if suite['key']==('jarde-java','p3_patterns','test')]
        need(len(p3_target)==1 and p3_target[0]['counts']==(92,0,0) and len(p3_target[0]['outcomes'])==92,
             f'p3_patterns full gate differs for {seed}')
        reader=[suite for suite in observations[seed] if suite['key']==('jarde-reader','jarde_reader','lib')]
        reader_rows=[(name,state) for suite in reader for name,state in suite['outcomes']
                     if name.rsplit('::',1)[-1]=='repository_class_fixtures_validate_without_false_target_rejections']
        need(len(reader)==1 and len(reader_rows)==1 and reader_rows[0][1]=='ok',
             f'reader class-fixture gate differs for {seed}')
        same_name=[suite for suite in observations[seed]
                   if suite['key']==('jarde','p3_reference_slot_lifetimes','test')]
        same_name_rows=[(name,state) for suite in same_name for name,state in suite['outcomes']
                        if name=='same_name_lvt_sources_split_into_exact_typed_independent_names']
        need(len(same_name)==1 and same_name[0]['counts'][1]==0 and len(same_name_rows)==1 and same_name_rows[0][1]=='ok',
             f'same-name LVT integration gate differs for {seed}')
        p5=[suite for suite in observations[seed] if suite['key']==('jarde','p5_corpus_fingerprint','test')]
        p5_expected={'corpus_files_match_the_recorded_fingerprint':'ok',
                     'the_manifest_matches_its_rendered_classification':'ok',
                     'every_dimension_is_carried_by_existing_corpus':'ok',
                     'every_acceptance_row_is_indexed_against_existing_corpus':'ok',
                     'the_indexed_rows_are_the_rows_the_acceptance_table_names':'ok',
                     'regenerate_corpus_fingerprint':'ignored'}
        need(len(p5)==1 and p5[0]['counts']==(5,0,1) and len(p5[0]['outcomes'])==6 and
             {name:state for name,state in p5[0]['outcomes']}==p5_expected,
             f'P5 corpus and ignored outcome set differs for {seed}')
    local_info={'execution':str(ex_path),'execution_sha256':workspace_sha,'metadata':str(meta_path),'metadata_sha256':sha(metadata_raw),
       'seed_target_counts':{s:len(observations[s]) for s in seeds},'target_count':len(inventory),'batch_count_per_seed':batches,
       'source_pin_count':len(live),'workspace_totals_by_seed':totals_by_seed,'workspace_totals':totals,
       'workspace_summary_count':count,'workspace_acceptance':str(acceptance_path),'workspace_acceptance_sha256':acceptance_sha}
    return ex,metadata,observations,live,local_info,required_outcomes

def bind_ci_name(raw_name: str, status: str, target: dict) -> str:
    if '***' not in raw_name: return raw_name
    pattern='^'+'[^\n]*'.join(re.escape(part) for part in raw_name.split('***'))+'$'
    choices=[name for name,state in target['outcomes'] if state==status and re.fullmatch(pattern,name)]
    need(len(choices)==1,'masked CI label does not bind to one same-status local outcome: '+repr(raw_name))
    return choices[0]

def verify_product_ci(capture: Path, product: str, run_id: str, observations: dict, product_pins: dict, ci, seeds):
    doc,summary,steps,logs,capture_sha=verify_capture(capture,product,run_id,ci)
    workflow=workflow_bytes(product,ci,product_pins).decode('utf-8')
    need(tuple(ci.CI_SEEDS_RE.findall(workflow))==tuple(seeds) and workflow.count('run: '+ci.WORKSPACE_CMD)==2,
         'product workflow does not contain the same two workspace seed runs')
    groups=[]
    for job in logs:
        job_groups=ci.command_groups(ci.strip_log(job['raw']).splitlines(),ci.WORKSPACE_CMD)
        groups.extend({'job_index':job['index'],'job_name':job['name'],'text':group} for group in job_groups)
    need(len(groups)==2,'all CI job logs must contain exactly the two workspace seed runs in total')
    unused=list(groups); seed_runs=[]
    for seed in seeds:
        targets=observations[seed]; matches=[g for g in unused if seed in g['text']]
        need(len(matches)==1,'cannot bind exactly one CI group to seed '+seed)
        matched=matches[0]; unused.remove(matched); group=matched['text']
        headers=[]
        for line in group.splitlines():
            if 'Running ' in ci.clean(line):
                row=ci.parse_ci_header(line,targets)
                if row is not None: headers.append(row)
        blocks=ci.stdout_blocks_cargo_json(group.encode())
        need(len(headers)==len(blocks)==len(targets),'CI seed lacks one target header/result per local target')
        need({tuple(x['key']) for x in headers}=={tuple(x['key']) for x in targets} and
             len({tuple(x['key']) for x in headers})==len(headers),
             'CI seed target headers omit/duplicate/add a workspace target')
        local={tuple(x['key']):x for x in targets}; observed=[]
        for header,block in zip(headers,blocks):
            expected=local[tuple(header['key'])]; bound=[]
            for name,state in block['outcomes']:
                normalized='ignored' if state=='ignored' or state.startswith('ignored, ') else state
                actual=bind_ci_name(name,normalized,expected)
                bound.append((actual,normalized))
            need(block['counts']==expected['counts'] and tuple(bound)==tuple(expected['outcomes']),
                 'CI target counts/named outcomes differ from local same-seed target '+repr(expected['key']))
            observed.append({'key':list(expected['key']),'counts':list(block['counts']),
                             'outcomes':[{'name':n,'status':s} for n,s in bound]})
        totals=[sum(x['counts'][i] for x in observed) for i in range(3)]
        seed_runs.append({'seed':seed,'job_index':matched['job_index'],'job_name':matched['job_name'],
                          'target_count':len(observed),'workspace_totals':totals,'target_observations':observed})
    need(not unused,'unbound CI seed groups remain')
    return {'capture_sha256':capture_sha,'jobs':len(summary['jobs']),'steps':steps,
            'all_jobs_and_steps_succeeded':True,'seed_runs':seed_runs}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    path_flags=('capture','focused-receipt','candidate-cli','workspace','workspace-acceptance','focused-runner','out')
    for flag in ('product-commit','run-id','capture','focused-receipt','focused-receipt-sha256','candidate-cli',
                 'candidate-cli-sha256','workspace','workspace-receipt-sha256','workspace-acceptance',
                 'workspace-acceptance-sha256','focused-runner','focused-runner-sha256','out'):
        ap.add_argument('--'+flag,type=Path if flag in path_flags else str,required=True)
    ap.add_argument('--workspace-runner',type=Path,default=WORKSPACE_RUNNER)
    args=ap.parse_args()
    need(re.fullmatch(r'[0-9a-f]{40}',args.product_commit) is not None and args.run_id.isdecimal() and int(args.run_id)>0,
         'exact product commit/run ID is invalid')
    for value in (args.focused_receipt_sha256,args.candidate_cli_sha256,args.workspace_receipt_sha256,
                  args.workspace_acceptance_sha256,args.focused_runner_sha256):
        need(re.fullmatch(r'[0-9a-f]{64}',value) is not None,'SHA argument must be lowercase 64-hex')
    args.workspace=args.workspace.resolve(strict=True)
    focus_path=args.focused_receipt.resolve(strict=True)
    need(not focus_path.is_symlink() and sha_file(focus_path)==args.focused_receipt_sha256,
         'focused receipt path/hash differs')
    cli_path=args.candidate_cli.resolve(strict=True)
    need(not cli_path.is_symlink() and sha_file(cli_path)==args.candidate_cli_sha256,'candidate CLI path/hash differs')
    runner_path=args.workspace_runner.resolve(strict=True)
    need(runner_path==WORKSPACE_RUNNER.resolve() and sha_file(runner_path)==WORKSPACE_RUNNER_SHA256,
         'workspace runner path/hash differs from reviewed v4')
    need(WORKSPACE_ACCEPTOR.is_file() and not WORKSPACE_ACCEPTOR.is_symlink() and
         sha_file(WORKSPACE_ACCEPTOR)==WORKSPACE_ACCEPTOR_SHA256,
         'workspace acceptor source pin differs from reviewed v5 SHA')
    ci=load_ci(); runner=load_module('reference_prefix_workspace_runner_v4',runner_path)
    acceptor=load_module('reference_prefix_workspace_acceptor_v5',WORKSPACE_ACCEPTOR)
    focus_manifest=load_json(focus_path).get('source_manifest_before',[])
    focus_pins=source_manifest_pins(focus_manifest)
    product_pins=runner.pin_sources(runner.source_paths())
    need(product_pins==focus_pins,'focused and current live source closures differ')
    product_blobs=ci.blob_sha256s(args.product_commit,product_pins)
    need(product_blobs==product_pins,
         'selected product commit differs from the complete focused/workspace/live source closure')
    workflow=workflow_bytes(args.product_commit,ci,product_pins).decode('utf-8')
    seeds=tuple(ci.CI_SEEDS_RE.findall(workflow))
    need(len(seeds)==2 and len(set(seeds))==2 and workflow.count('run: '+ci.WORKSPACE_CMD)==2,
         'product workflow does not contain exactly two distinct workspace seed runs')
    focus,focus_info,focus_pins,cli_pin,focused_runner_pin=verify_focus(
        focus_path,args.focused_receipt_sha256,cli_path,args.candidate_cli_sha256,
        args.focused_runner,args.focused_runner_sha256,args.product_commit,ci,product_pins,runner)
    workspace,metadata,observations,workspace_pins,local_info,required=verify_workspace(
        args.workspace,args.workspace_receipt_sha256,args.workspace_acceptance,args.workspace_acceptance_sha256,
        focus,focus_info,focus_pins,cli_pin,runner_path,runner,acceptor,ci,seeds)
    need(workspace_pins==product_pins,'workspace/current product source closures differ')
    ci_result=verify_product_ci(args.capture.resolve(strict=True),args.product_commit,args.run_id,
        observations,product_pins,ci,seeds)
    need(CAPTURE_PATH.is_file() and sha_file(CAPTURE_PATH)==CAPTURE_SHA256,
         'all-job capture collector pin changed')
    rel=CI_HELPER_PATH.relative_to(ROOT).as_posix()
    product_blob_sha=sha(ci.git_blob(args.product_commit,rel))
    need(product_blob_sha==CI_HELPER_SHA256==sha_file(CI_HELPER_PATH),
         'CI parser live bytes and selected product-commit blob differ from pinned tool SHA')
    ci_parser_provenance={'path':str(CI_HELPER_PATH),'expected_sha256':CI_HELPER_SHA256,
      'live_sha256':sha_file(CI_HELPER_PATH),'product_commit':args.product_commit,
      'product_commit_blob_sha256':product_blob_sha,
      'member_of_dynamic_source_closure':rel in product_pins,
      'role':'auxiliary CI parser, separately pinned from compiled source closure'}
    refs={'focused_receipt_runner':focused_runner_pin,
          'ci_parser':{'path':str(CI_HELPER_PATH),'sha256':CI_HELPER_SHA256},
          'capture_collector':{'path':str(CAPTURE_PATH),'sha256':CAPTURE_SHA256},
          'workspace_runner':{'path':str(runner_path),'sha256':WORKSPACE_RUNNER_SHA256},
          'workspace_acceptor':{'path':str(WORKSPACE_ACCEPTOR),'sha256':WORKSPACE_ACCEPTOR_SHA256}}
    result={'schema':'jarde-own-ci-product-acceptance-v1','status':'accepted_product_ci_observation',
      'product_commit':args.product_commit,'run_id':int(args.run_id),
      'ci':{'capture_sha256':ci_result['capture_sha256'],'jobs':ci_result['jobs'],'steps':ci_result['steps'],
            'all_jobs_and_steps_succeeded':ci_result['all_jobs_and_steps_succeeded'],'seed_runs':ci_result['seed_runs']},
      'fresh_local_workspace':local_info,'required_named_tests_per_seed':required,
      'focused_receipt':focus_info,'candidate_cli':cli_pin,
      'source_closure':{'count':len(product_pins),'focused_workspace_product_git_live_equal':True,
                        'source_sha256_by_path':product_pins},
      'references':refs,'tool_provenance':{'ci_parser':ci_parser_provenance},
      'acceptance_scope':'Exact selected product commit and Actions run. Every API-reported job and every step succeeded and all raw logs were captured. Both workflow seeds are compared target-by-target and named-test-by-named-test with fresh local workspace results. The dynamically enumerated complete source closure is byte-identical across focused/workspace receipts, live checkout, and selected product Git blobs; current v5 workspace-acceptor gates include existing field, P5, ignored, LVT, ordinary/protected-prefix, structured, and same-name integration outcomes.'}
    out=args.out.resolve()
    need(not out.exists() and not out.is_relative_to(ROOT),'refusing overwrite or workspace-local acceptance output')
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('x',encoding='utf-8') as f:f.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'product_commit':args.product_commit,'run_id':int(args.run_id),
      'jobs':ci_result['jobs'],'steps':ci_result['steps'],'target_count':local_info['target_count'],
      'batch_count_per_seed':local_info['batch_count_per_seed'],'source_closure_count':len(product_pins),
      'workspace_totals_by_seed':local_info['workspace_totals_by_seed']},ensure_ascii=False))

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print('Jarde current-product own-CI verification failed: '+str(exc),file=sys.stderr)
        raise SystemExit(1)
