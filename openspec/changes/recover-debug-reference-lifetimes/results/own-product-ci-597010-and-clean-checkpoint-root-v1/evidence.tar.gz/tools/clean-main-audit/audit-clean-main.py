#!/usr/bin/env python3
"""Read-only main/worktree/source-closure audit bound to an accepted product CI record."""
from __future__ import annotations
import argparse, datetime, hashlib, json, os, re, subprocess, sys
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
EXPECTED_AUX_WORKTREES = 14
OWN_CI_SCHEMA = 'jarde-own-ci-product-acceptance-v1'
FOCUSED_STATUS = 'commands_passed_pending_independent_acceptance'
WORKSPACE_SCHEMA = 'ordered-field-full-workspace-run-v2'  # workspace protocol v4
WORKSPACE_ACCEPTANCE_SCHEMA = 'ordered-field-full-workspace-acceptance-v2'
TOOL_PINS = {
    'own_ci_verifier_v4': (
        Path('/private/tmp/jarde-current-own-ci-verifier-prep-luna-v4/verify-own-ci.py'),
        '06873a28ca1944531685b732a53a9027f254424185f62b5e8e742167b206dcb3',
    ),
    'workspace_runner_v4': (
        Path('/private/tmp/jarde-reference-prefix-workspace-prep-luna-v4/workspace_runner.py'),
        '691e7c073c202ff7782ec8323f0a8c1892ad8748fd55c6d952515f9809736c22',
    ),
    'workspace_acceptor_v5': (
        Path('/private/tmp/jarde-reference-prefix-workspace-acceptor-root-v5/accept_workspace.py'),
        '5f24f35d27d50a5fca7b128247a3bc094f2109de958af875cf9128a886105c79',
    ),
    'focused_receipt_runner': (
        Path('/private/tmp/jarde-loop-focused-runner-root-v1.py'),
        '7209ad1732c097e555c0cda2eba8ffa39ab55bf109616cfaac5f15a1bb749b9f',
    ),
    'ci_parser': (
        ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/verify-conditional-ci-root-v5.py',
        'bea37c7d4d37182168a7c1cbbde3ee31c94d61f6bc32667bedbdd02ce7e5b0ca',
    ),
    'capture_collector_v4': (
        Path('/private/tmp/jarde-current-own-ci-verifier-prep-luna-v4/capture-own-ci.py'),
        '484dca8612ace135b2860445bb1af4628c05c857d38d6bbce9c9384de7977c37',
    ),
}

ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('output_dir', type=Path)
ap.add_argument('--expected-head', required=True)
ap.add_argument('--product-commit', required=True)
ap.add_argument('--own-ci-acceptance', type=Path, required=True)
ap.add_argument('--own-ci-acceptance-sha256', required=True)
args = ap.parse_args()
OUT = args.output_dir.resolve()


def need(ok, message):
    if not ok:
        raise AssertionError(message)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def sha_file(path: Path) -> str:
    return sha(path.read_bytes())


def git(argv, cwd=ROOT, allowed=(0,)):
    proc = subprocess.run(['git', *argv], cwd=cwd, capture_output=True)
    record = {'argv': ['git', *argv], 'cwd': str(cwd), 'exit_code': proc.returncode,
              'stdout_sha256': sha(proc.stdout), 'stdout_bytes': len(proc.stdout),
              'stderr_sha256': sha(proc.stderr), 'stderr_bytes': len(proc.stderr)}
    commands.append(record)
    if proc.returncode not in allowed:
        raise RuntimeError(f'git command failed: {argv!r} ({proc.returncode})')
    return proc.stdout


def tree(commit):
    raw = git(['ls-tree', '-r', '-z', commit])
    result = {}
    for record in raw.split(b'\0'):
        if not record:
            continue
        header, sep, path = record.partition(b'\t')
        need(bool(sep), 'malformed git ls-tree record')
        mode, kind, oid = header.split()
        need(kind == b'blob', 'pinned source path is not a blob')
        result[path] = (mode, oid)
    return result, sha(raw)


def blobs_sha256(commit, paths, tree_map):
    """Resolve the dynamic source set through one recorded cat-file batch."""
    oids = []
    for path in paths:
        need(path in tree_map, f'pinned source missing from {commit}: {os.fsdecode(path)}')
        oids.append(tree_map[path][1])
    stdin = b''.join(oid + b'\n' for oid in oids)
    proc = subprocess.run(['git', 'cat-file', '--batch'], cwd=ROOT, input=stdin, capture_output=True)
    commands.append({'argv': ['git', 'cat-file', '--batch'], 'cwd': str(ROOT),
                     'exit_code': proc.returncode, 'stdin_bytes': len(stdin),
                     'stdin_sha256': sha(stdin), 'stdout_sha256': sha(proc.stdout),
                     'stdout_bytes': len(proc.stdout), 'stderr_sha256': sha(proc.stderr),
                     'stderr_bytes': len(proc.stderr)})
    need(proc.returncode == 0, f'git cat-file failed for {commit}')
    raw, pos, values = proc.stdout, 0, {}
    for path, oid in zip(paths, oids):
        end = raw.find(b'\n', pos)
        need(end >= 0, 'truncated git cat-file header')
        fields = raw[pos:end].split()
        need(len(fields) == 3 and fields[0] == oid and fields[1] == b'blob',
             'unexpected git cat-file header')
        size = int(fields[2]); start = end + 1; stop = start + size
        need(stop < len(raw) and raw[stop:stop + 1] == b'\n', 'truncated git cat-file blob')
        values[path] = sha(raw[start:stop]); pos = stop + 1
    need(pos == len(raw), 'unexpected trailing git cat-file output')
    return values


def ancestor(left, right):
    git(['merge-base', '--is-ancestor', left, right], allowed=(0, 1))
    return commands[-1]['exit_code'] == 0


def pinned_receipt(ref, label):
    need(isinstance(ref, dict) and isinstance(ref.get('path'), str) and
         re.fullmatch(r'[0-9a-f]{64}', ref.get('sha256', '')) is not None,
         f'{label} reference is malformed')
    path = Path(ref['path'])
    need(path.is_absolute() and not path.is_symlink() and path.is_file(),
         f'{label} is missing, relative, or linked')
    path = path.resolve(strict=True)
    raw = path.read_bytes()
    need(sha(raw) == ref['sha256'], f'{label} SHA-256 differs from its accepted reference')
    return path, json.loads(raw)


def source_map(rows):
    need(isinstance(rows, list) and rows, 'focused source manifest is absent')
    result = {}
    byte_counts = {}
    for row in rows:
        need(isinstance(row, dict) and isinstance(row.get('path'), str),
             'malformed focused source row')
        raw_path = Path(row['path'])
        if raw_path.is_absolute():
            resolved = raw_path.resolve()
            need(resolved.is_relative_to(ROOT), 'focused source path escapes product root')
            rel = resolved.relative_to(ROOT).as_posix()
        else:
            need('..' not in raw_path.parts and raw_path.parts and raw_path.as_posix() == row['path'],
                 'unsafe or non-canonical focused source path')
            rel = raw_path.as_posix()
        digest = row.get('sha256')
        need(re.fullmatch(r'[0-9a-f]{64}', digest or '') is not None,
             f'invalid source digest: {rel}')
        need(type(row.get('bytes')) is int and row['bytes'] >= 0,
             f'invalid source byte count: {rel}')
        encoded = rel.encode()
        need(encoded not in result, f'duplicate source path: {rel}')
        result[encoded] = digest
        byte_counts[encoded] = row['bytes']
    return result, byte_counts


def normalized_map(raw, label):
    need(isinstance(raw, dict) and raw, f'{label} source map is absent')
    result = {}
    for path, digest in raw.items():
        pure = Path(path)
        need(isinstance(path, str) and not pure.is_absolute() and '..' not in pure.parts and
             pure.parts and pure.as_posix() == path, f'{label} has unsafe or non-canonical source path')
        need(re.fullmatch(r'[0-9a-f]{64}', digest or '') is not None,
             f'{label} has invalid source digest: {path}')
        result[path.encode()] = digest
    return result


def load_tool_pins():
    found = {}
    for name, (path, expected) in TOOL_PINS.items():
        need(not path.is_symlink() and path.is_file(), f'pinned tool is missing or linked: {name}')
        actual = sha_file(path)
        need(actual == expected, f'pinned tool changed: {name}')
        found[name] = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': actual}
    return found


commands = []
result = {'schema': 'reference-prefix-clean-main-audit-v1', 'status': 'running',
          'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'expected_head': args.expected_head, 'product_commit': args.product_commit,
          'own_ci_acceptance': str(args.own_ci_acceptance.resolve()),
          'own_ci_acceptance_sha256': args.own_ci_acceptance_sha256, 'commands': commands}
try:
    need(re.fullmatch(r'[0-9a-f]{40}', args.product_commit) is not None,
         'product commit must be lowercase full Git SHA')
    need(re.fullmatch(r'[0-9a-f]{40}', args.expected_head) is not None,
         'expected head must be lowercase full Git SHA')
    need(re.fullmatch(r'[0-9a-f]{64}', args.own_ci_acceptance_sha256) is not None,
         'own-CI acceptance SHA-256 must be lowercase full digest')
    need(not OUT.exists() and not OUT.is_relative_to(ROOT),
         'audit output must be new and outside repository')
    tool_pins = load_tool_pins()

    need(not args.own_ci_acceptance.is_symlink() and args.own_ci_acceptance.is_file(),
         'own-CI acceptance reference missing or symlink')
    own_ci_raw = args.own_ci_acceptance.read_bytes()
    need(sha(own_ci_raw) == args.own_ci_acceptance_sha256,
         'own-CI acceptance SHA differs from argv pin')
    own_ci = json.loads(own_ci_raw)
    need(own_ci.get('schema') == OWN_CI_SCHEMA and
         own_ci.get('status') == 'accepted_product_ci_observation',
         'own-CI record is not an accepted product-CI observation from verifier v3')
    need(own_ci.get('product_commit') == args.product_commit,
         'own-CI acceptance product commit differs from --product-commit')
    ci = own_ci.get('ci', {})
    need(ci.get('all_jobs_and_steps_succeeded') is True and
         type(ci.get('jobs')) is int and ci['jobs'] > 0 and
         type(ci.get('steps')) is int and ci['steps'] > 0,
         'own-CI acceptance does not record all successful CI jobs and steps')
    closure = own_ci.get('source_closure', {})
    need(isinstance(closure, dict) and closure.get('focused_workspace_product_git_live_equal') is True,
         'own-CI acceptance does not prove a four-way source closure')
    accepted_source_map = normalized_map(closure.get('source_sha256_by_path'), 'own-CI acceptance')
    need(closure.get('count') == len(accepted_source_map),
         'own-CI source closure count differs from its path map')

    focus_path, focused = pinned_receipt(own_ci.get('focused_receipt'), 'focused receipt')
    need(focused.get('status') == FOCUSED_STATUS,
         'focused receipt does not report completed command checks')
    before, after = focused.get('source_manifest_before'), focused.get('source_manifest_after')
    need(isinstance(before, list) and before == after and before,
         'focused before/after source manifests are missing, changed, or empty')
    focus_pins, source_bytes = source_map(before)
    need(focus_pins == accepted_source_map,
         'own-CI accepted source blobs differ from this focused receipt')
    manifest_sha = sha(json.dumps(before, sort_keys=True, separators=(',', ':')).encode())
    for count_key in ('source_manifest_before_count', 'source_manifest_after_count'):
        if count_key in focused:
            need(focused[count_key] == len(before), f'{count_key} differs from dynamic manifest')
    for digest_key in ('source_manifest_before_sha256', 'source_manifest_after_sha256'):
        if digest_key in focused:
            need(focused[digest_key] == manifest_sha, f'{digest_key} differs from dynamic manifest')

    workspace_ref = own_ci.get('fresh_local_workspace', {})
    need(isinstance(workspace_ref, dict), 'own-CI workspace reference is absent')
    workspace_path = Path(workspace_ref.get('execution', ''))
    need(workspace_path.is_absolute() and not workspace_path.is_symlink() and workspace_path.is_file(),
         'workspace execution reference is missing, relative, or linked')
    workspace_path = workspace_path.resolve(strict=True)
    workspace_raw = workspace_path.read_bytes()
    workspace_sha = workspace_ref.get('execution_sha256')
    need(re.fullmatch(r'[0-9a-f]{64}', workspace_sha or '') is not None and
         sha(workspace_raw) == workspace_sha,
         'workspace execution hash differs from own-CI reference')
    workspace = json.loads(workspace_raw)
    need(workspace.get('schema') == WORKSPACE_SCHEMA and workspace.get('status') == 'passed' and
         workspace.get('no_carried_execution') is True,
         'workspace v4 receipt is not complete and passing')
    workspace_before = normalized_map(workspace.get('source_pins_before'), 'workspace before')
    workspace_after = normalized_map(workspace.get('source_pins_after'), 'workspace after')
    need(workspace_before == workspace_after == focus_pins,
         'workspace before/after source pins differ from the focused closure')
    need(workspace.get('source_closure_count_at_start') == len(focus_pins) and
         workspace_ref.get('source_pin_count') == len(focus_pins),
         'workspace dynamic source count differs from the linked receipts')
    focus_binding = workspace.get('focused_input_receipt', {})
    focus_spec_sha = focused.get('command_spec', {}).get('sha256')
    need(focus_binding.get('path') == str(focus_path) and
         focus_binding.get('sha256') == own_ci['focused_receipt']['sha256'] and
         focus_binding.get('status') == focused.get('status') and
         focus_binding.get('command_spec_sha256') == focus_spec_sha,
         'workspace receipt does not bind this exact focused v11 receipt')

    acceptance_path = Path(workspace_ref.get('workspace_acceptance', ''))
    acceptance_sha = workspace_ref.get('workspace_acceptance_sha256')
    need(acceptance_path.is_absolute() and not acceptance_path.is_symlink() and acceptance_path.is_file() and
         re.fullmatch(r'[0-9a-f]{64}', acceptance_sha or '') is not None,
         'workspace acceptance reference is malformed')
    acceptance_path = acceptance_path.resolve(strict=True)
    accepted_workspace_raw = acceptance_path.read_bytes()
    need(sha(accepted_workspace_raw) == acceptance_sha,
         'workspace acceptance hash differs from own-CI reference')
    accepted_workspace = json.loads(accepted_workspace_raw)
    need(accepted_workspace.get('schema') == WORKSPACE_ACCEPTANCE_SCHEMA and
         accepted_workspace.get('status') == 'accepted_local_workspace_only' and
         accepted_workspace.get('not_ci_or_product_release_acceptance') is True and
         accepted_workspace.get('execution_sha256') == workspace_sha and
         accepted_workspace.get('focused_receipt_sha256') == own_ci['focused_receipt']['sha256'] and
         accepted_workspace.get('source_pin_count') == len(focus_pins) and
         accepted_workspace.get('target_absent') is True,
         'workspace independent acceptance does not bind this exact workspace/focused closure')
    own_workspace_cli = own_ci.get('candidate_cli', {})
    focused_cli = focused.get('cli', {})
    workspace_cli = workspace.get('candidate_cli', {})
    cli_fields = ('path', 'bytes', 'sha256')
    need(all(own_workspace_cli.get(k) == focused_cli.get(k) == workspace_cli.get(k)
             for k in cli_fields),
         'focused/workspace/product-CI accepted CLI pins differ')

    references = own_ci.get('references', {})
    for key, tool_name in (('workspace_runner', 'workspace_runner_v4'),
                           ('workspace_acceptor', 'workspace_acceptor_v5'),
                           ('focused_receipt_runner', 'focused_receipt_runner'),
                           ('ci_parser', 'ci_parser'),
                           ('capture_collector', 'capture_collector_v4')):
        ref = references.get(key, {})
        expected_tool = tool_pins[tool_name]
        need(ref.get('path') == expected_tool['path'] and ref.get('sha256') == expected_tool['sha256'],
             f'accepted own-CI {key} reference differs from the current reviewed tool')

    head = git(['rev-parse', 'HEAD']).decode().strip()
    main = git(['rev-parse', 'main']).decode().strip()
    origin_main = git(['rev-parse', 'origin/main']).decode().strip()
    branch = git(['branch', '--show-current']).decode().strip()
    local_branches = git(['for-each-ref', '--format=%(refname:short)', 'refs/heads']).decode().splitlines()
    origin_url = git(['remote', 'get-url', 'origin']).decode().strip()
    remote_heads = git(['ls-remote', '--heads', 'origin']).decode().splitlines()
    need(head == main == origin_main == args.expected_head and branch == 'main',
         'HEAD/main/origin/main differ from --expected-head or branch is not main')
    need(local_branches == ['main'], f'local branch set is not exactly main: {local_branches}')
    need(origin_url and remote_heads == [args.expected_head + '\trefs/heads/main'],
         'origin main does not equal --expected-head')
    need(ancestor(args.product_commit, args.expected_head),
         'accepted product commit is not an ancestor of --expected-head')

    product_tree, product_tree_sha = tree(args.product_commit)
    expected_tree, expected_tree_sha = tree(args.expected_head)
    paths = sorted(focus_pins)
    product_hashes = blobs_sha256(args.product_commit, paths, product_tree)
    expected_hashes = blobs_sha256(args.expected_head, paths, expected_tree)
    live_hashes = {}
    for encoded, digest in focus_pins.items():
        rel = os.fsdecode(encoded)
        path = ROOT.joinpath(*Path(rel).parts)
        need(not path.is_symlink() and path.is_file(), f'live source missing or symlink: {rel}')
        actual = sha_file(path)
        need(path.stat().st_size == source_bytes[encoded],
             f'live source byte count differs from focused receipt: {rel}')
        need(actual == digest == product_hashes[encoded] == expected_hashes[encoded],
             f'source bytes differ across focused/workspace/product/expected-head/live: {rel}')
        need(product_tree[encoded][0] in (b'100644', b'100755') and
             product_tree[encoded][0] == expected_tree[encoded][0],
             f'source mode differs or is unsupported: {rel}')
        live_hashes[rel] = actual

    wt_text = git(['worktree', 'list', '--porcelain']).decode()
    worktrees = []
    for block in wt_text.strip().split('\n\n'):
        fields = {}
        for line in block.splitlines():
            key, sep, value = line.partition(' ')
            fields[key] = value if sep else True
        need('worktree' in fields and 'HEAD' in fields, 'malformed git worktree record')
        path = Path(fields['worktree']).resolve()
        status = git(['status', '--ignored', '--porcelain=v1', '--untracked-files=all'], cwd=path).decode().splitlines()
        ignored = [line for line in status if line.startswith('!!')]
        changes = [line for line in status if not line.startswith('!!')]
        wt_head = fields['HEAD']
        is_root = path == ROOT
        wt = {'path': str(path), 'head': wt_head, 'branch': fields.get('branch'),
              'detached': bool(fields.get('detached')), 'clean': not changes,
              'status_change_count': len(changes), 'ignored_entry_count': len(ignored),
              'target_exists': (path / 'target').exists(),
              'fuzz_target_exists': (path / 'fuzz' / 'target').exists(),
              'main_ancestor': ancestor(wt_head, 'main'), 'is_root': is_root}
        worktrees.append(wt)
    roots = [w for w in worktrees if w['is_root']]
    aux = [w for w in worktrees if not w['is_root']]
    need(len({w['path'] for w in worktrees}) == len(worktrees), 'duplicate physical worktree path')
    need(len(roots) == 1 and len(aux) == EXPECTED_AUX_WORKTREES and
         roots[0]['branch'] == 'refs/heads/main' and not roots[0]['detached'],
         f'root/main and {EXPECTED_AUX_WORKTREES} auxiliary checkout topology differs')
    need(all(w['detached'] and w['branch'] is None for w in aux),
         'an auxiliary worktree is not detached')
    need(all(w['clean'] and w['main_ancestor'] and not w['target_exists'] and
             not w['fuzz_target_exists'] for w in worktrees),
         'a worktree is dirty, not a main ancestor, or contains target output')

    result.update(status='accepted_clean_main', expected_head=args.expected_head,
                  product_commit=args.product_commit, head=head, main=main, origin_main=origin_main,
                  branch=branch, local_branches=local_branches, origin_url=origin_url,
                  remote_heads=remote_heads, product_commit_is_ancestor_of_expected_head=True,
                  own_ci_product_commit=own_ci['product_commit'], own_ci_run_id=own_ci['run_id'],
                  worktree_count=len(worktrees), worktrees=worktrees,
                  source_pin_count=len(focus_pins), source_manifest_before_sha256=manifest_sha,
                  product_tree_raw_sha256=product_tree_sha,
                  expected_tree_raw_sha256=expected_tree_sha,
                  source_blob_match_count=len(focus_pins),
                  focused_receipt={'path': str(focus_path), 'sha256': own_ci['focused_receipt']['sha256']},
                  workspace_receipt={'path': str(workspace_path), 'sha256': workspace_sha},
                  workspace_acceptance={'path': str(acceptance_path), 'sha256': acceptance_sha},
                  own_ci_acceptance_status=own_ci['status'], tool_pins=tool_pins)
except Exception as exc:
    result.update(status='failed', error=f'{type(exc).__name__}: {exc}')
finally:
    OUT.mkdir(parents=True, exist_ok=False)
    (OUT / 'execution.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: result.get(k) for k in ('status', 'product_commit', 'expected_head',
                                                 'head', 'worktree_count', 'source_pin_count', 'error')}))
sys.exit(0 if result['status'] == 'accepted_clean_main' else 1)
