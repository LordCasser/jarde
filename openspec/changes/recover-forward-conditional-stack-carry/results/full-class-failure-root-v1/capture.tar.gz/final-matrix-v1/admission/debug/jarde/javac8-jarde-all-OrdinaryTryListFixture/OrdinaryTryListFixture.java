// jarde: presentation of `cf11/OrdinaryTryListFixture` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf11;

public class OrdinaryTryListFixture extends java.lang.Object {
    public static int effects;

    public OrdinaryTryListFixture() {
        // @method <init>()V
        // @declaration a constructor of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public void renamedTry(java.util.List<java.lang.String> source, java.util.List<java.lang.String> sink) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method renamedTry(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        for (java.lang.Object iteratorElement17 : source) {
                            java.lang.String element = (java.lang.String) iteratorElement17;
                            if (element == null) {
                                sink.add(null);
                            } else if (element.length() == 0) {
                                sink.add(element);
    } else {
                                sink.add(null);
    }
                            cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                        }
                    } catch (java.lang.RuntimeException problem) {
                        cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                    }
                    return;
    }

    public void stringBranch(java.util.List<java.lang.String> input, java.util.List<java.lang.String> output) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method stringBranch(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        for (java.lang.Object iteratorElement17 : input) {
                            java.lang.String value = (java.lang.String) iteratorElement17;
                            if (value == null) {
                                output.add(null);
                            } else if (value.length() == 0) {
                                output.add(value);
    } else {
                                output.add(null);
    }
                            cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                        }
                    } catch (java.lang.RuntimeException failure) {
                        output.add(null);
                        cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                    }
                    return;
    }

    public void integerTry(java.util.List<java.lang.Integer> selected, java.util.List<java.lang.Integer> available) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/Integer;>;Ljava/util/List<Ljava/lang/Integer;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method integerTry(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        for (java.lang.Object iteratorElement17 : selected) {
                            java.lang.Integer value = (java.lang.Integer) iteratorElement17;
                            if (value == null) {
                                available.add(null);
                            } else if (value.intValue() > 0) {
                                available.add(value);
    } else {
                                available.add(null);
    }
                            cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                        }
                    } catch (java.lang.RuntimeException failure) {
                        cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                    }
                    return;
    }

    public void nestedTry(java.util.List<java.lang.String> source, java.util.List<java.lang.String> witness, java.util.List<java.lang.String> destination) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method nestedTry(Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        java.lang.String outer;
                        java.util.Iterator local6;
                        for (java.lang.Object iteratorElement20 : source) {
                            outer = (java.lang.String) iteratorElement20;
                            for (java.lang.Object iteratorElement50 : witness) {
                                java.lang.String inner = (java.lang.String) iteratorElement50;
                                if (outer.equals((java.lang.Object) inner)) {
                                    destination.add(outer);
                                }
                            }
                            cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                        }
                    } catch (java.lang.RuntimeException failure) {
                        cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                    }
                    return;
    }

    public void stringRemovePrefix(java.util.List<java.lang.String> input, java.util.List<java.lang.String> output, java.lang.Object key) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method stringRemovePrefix(Ljava/util/List;Ljava/util/List;Ljava/lang/Object;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        output.remove(key);
                        for (java.lang.Object iteratorElement28 : input) {
                            java.lang.String value = (java.lang.String) iteratorElement28;
                            output.add(value);
                            cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                        }
                    } catch (java.lang.RuntimeException failure) {
                        cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                    }
                    return;
    }

    // jarde: generic Signature projection refused for `catchVisibleIteratorGap(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    public void catchVisibleIteratorGap(java.util.List input, java.util.List output) {
        // @method catchVisibleIteratorGap(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int marker;
        marker = 0;
        try {
            java.util.Iterator local4 = input.iterator();
            marker = 1;
            while (local4.hasNext()) {
                output.add((java.lang.Object) local4.next());
                cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
            }
        } catch (java.lang.RuntimeException local4) {
            cf11.OrdinaryTryListFixture.effects = marker;
        }
        return;
    }

    // jarde: generic Signature projection refused for `unknownCatchUse(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    public void unknownCatchUse(java.util.List input, java.util.List output) {
        // @method unknownCatchUse(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        try {
            for (java.lang.Object iteratorElement17 : input) {
                java.lang.String value = (java.lang.String) iteratorElement17;
                output.add((java.lang.Object) value);
            }
        } catch (java.lang.RuntimeException failure) {
            consume((java.lang.Object) output);
        }
        return;
    }

    private static void consume(java.lang.Object value) {
        // jarde: not recovered: the recovery run for `consume(Ljava/lang/Object;)V` produced no statement (explanation only); the artifact's own comment lines are below
        // @method consume(Ljava/lang/Object;)V
        // @declaration a static method of `cf11.OrdinaryTryListFixture`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 3 4 7 8 11 12 13 16
        // the saved producer at BCI 0 has 3 consumers, so one local binding cannot prove its execution count
        // @bytecode 13 0
        // the value at BCI 13 was produced by a saved declaration this run could not commit
        jarde_refused_body();
    }

    // jarde: generic Signature projection refused for `reassignedInCatch(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public void reassignedInCatch(java.util.List input, java.util.List replacement) {
        // @method reassignedInCatch(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        try {
            for (java.lang.Object iteratorElement17 : input) {
                java.lang.String value = (java.lang.String) iteratorElement17;
                replacement.add((java.lang.Object) value);
            }
        } catch (java.lang.RuntimeException failure) {
            input = replacement;
            input.add((java.lang.Object) null);
        }
        return;
    }

    // jarde: generic Signature projection refused for `rawAliasInCatch(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    public void rawAliasInCatch(java.util.List input, java.util.List output) {
        // @method rawAliasInCatch(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        try {
            for (java.lang.Object iteratorElement17 : input) {
                java.lang.String value = (java.lang.String) iteratorElement17;
                output.add((java.lang.Object) value);
            }
        } catch (java.lang.RuntimeException failure) {
            java.util.List escaped = output;
            escaped.add((java.lang.Object) "polluted");
        }
        return;
    }

    // jarde: generic Signature projection refused for `multiCatch(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public void multiCatch(java.util.List input, java.util.List output) {
        // @method multiCatch(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        try {
            java.util.Iterator failure = input.iterator();
            while (failure.hasNext()) {
                java.lang.String value = (java.lang.String) failure.next();
                output.add((java.lang.Object) value);
            }
        } catch (java.lang.IllegalArgumentException | java.lang.IllegalStateException failure) {
            output.add((java.lang.Object) null);
        }
        return;
    }

    // jarde: generic Signature projection refused for `indexOverload(Ljava/util/List;Ljava/util/List;Ljava/lang/Integer;I)V`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    public void indexOverload(java.util.List values, java.util.List witness, java.lang.Integer key, int position) {
        // @method indexOverload(Ljava/util/List;Ljava/util/List;Ljava/lang/Integer;I)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        try {
            for (java.lang.Object iteratorElement20 : values) {
                java.lang.Integer value = (java.lang.Integer) iteratorElement20;
                values.remove((java.lang.Object) key);
                witness.add((java.lang.Object) value);
                values.remove(position);
            }
        } catch (java.lang.RuntimeException failure) {
            witness.add((java.lang.Object) null);
        }
        return;
    }
}
