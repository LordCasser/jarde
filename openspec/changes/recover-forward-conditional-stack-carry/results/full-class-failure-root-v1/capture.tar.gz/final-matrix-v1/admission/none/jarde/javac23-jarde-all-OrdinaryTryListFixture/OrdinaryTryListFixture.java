// jarde: presentation of `cf11/OrdinaryTryListFixture` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf11;

public class OrdinaryTryListFixture extends java.lang.Object {
    public static int effects;

    public OrdinaryTryListFixture() {
        // @method <init>()V
        // @declaration a constructor of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public void renamedTry(java.util.List<java.lang.String> arg1, java.util.List<java.lang.String> arg2) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method renamedTry(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        for (java.lang.Object iteratorElement17 : arg1) {
                            java.lang.String local4 = (java.lang.String) iteratorElement17;
                            if (local4 == null) {
                                arg2.add(null);
                            } else if (local4.length() == 0) {
                                arg2.add(local4);
    } else {
                                arg2.add(null);
    }
                            cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                        }
                    } catch (java.lang.RuntimeException local3) {
                        cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                    }
                    return;
    }

    public void stringBranch(java.util.List<java.lang.String> arg1, java.util.List<java.lang.String> arg2) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method stringBranch(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        for (java.lang.Object iteratorElement17 : arg1) {
                            java.lang.String local4 = (java.lang.String) iteratorElement17;
                            if (local4 == null) {
                                arg2.add(null);
                            } else if (local4.length() == 0) {
                                arg2.add(local4);
    } else {
                                arg2.add(null);
    }
                            cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                        }
                    } catch (java.lang.RuntimeException local3) {
                        arg2.add(null);
                        cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                    }
                    return;
    }

    public void integerTry(java.util.List<java.lang.Integer> arg1, java.util.List<java.lang.Integer> arg2) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/Integer;>;Ljava/util/List<Ljava/lang/Integer;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method integerTry(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        for (java.lang.Object iteratorElement17 : arg1) {
                            java.lang.Integer local4 = (java.lang.Integer) iteratorElement17;
                            if (local4 == null) {
                                arg2.add(null);
                            } else if (local4.intValue() > 0) {
                                arg2.add(local4);
    } else {
                                arg2.add(null);
    }
                            cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                        }
                    } catch (java.lang.RuntimeException local3) {
                        cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                    }
                    return;
    }

    public void nestedTry(java.util.List<java.lang.String> arg1, java.util.List<java.lang.String> arg2, java.util.List<java.lang.String> arg3) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method nestedTry(Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        java.lang.String local5;
                        java.util.Iterator local6;
                        for (java.lang.Object iteratorElement20 : arg1) {
                            local5 = (java.lang.String) iteratorElement20;
                            for (java.lang.Object iteratorElement50 : arg2) {
                                java.lang.String local7 = (java.lang.String) iteratorElement50;
                                if (local5.equals((java.lang.Object) local7)) {
                                    arg3.add(local5);
                                }
                            }
                            cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                        }
                    } catch (java.lang.RuntimeException local4) {
                        cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                    }
                    return;
    }

    public void stringRemovePrefix(java.util.List<java.lang.String> arg1, java.util.List<java.lang.String> arg2, java.lang.Object arg3) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method stringRemovePrefix(Ljava/util/List;Ljava/util/List;Ljava/lang/Object;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        arg2.remove(arg3);
                        for (java.lang.Object iteratorElement28 : arg1) {
                            java.lang.String local5 = (java.lang.String) iteratorElement28;
                            arg2.add(local5);
                            cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                        }
                    } catch (java.lang.RuntimeException local4) {
                        cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
                    }
                    return;
    }

    // jarde: generic Signature projection refused for `catchVisibleIteratorGap(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    public void catchVisibleIteratorGap(java.util.List arg1, java.util.List arg2) {
        // @method catchVisibleIteratorGap(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int local3;
        local3 = 0;
        try {
            java.util.Iterator local4 = arg1.iterator();
            local3 = 1;
            while (local4.hasNext()) {
                arg2.add((java.lang.Object) (java.lang.String) local4.next());
                cf11.OrdinaryTryListFixture.effects = cf11.OrdinaryTryListFixture.effects + 1;
            }
        } catch (java.lang.RuntimeException local4) {
            cf11.OrdinaryTryListFixture.effects = local3;
        }
        return;
    }

    // jarde: generic Signature projection refused for `unknownCatchUse(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    public void unknownCatchUse(java.util.List arg1, java.util.List arg2) {
        // @method unknownCatchUse(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        try {
            for (java.lang.Object iteratorElement17 : arg1) {
                java.lang.String local4 = (java.lang.String) iteratorElement17;
                arg2.add((java.lang.Object) local4);
            }
        } catch (java.lang.RuntimeException local3) {
            consume((java.lang.Object) arg2);
        }
        return;
    }

    private static void consume(java.lang.Object arg0) {
        // jarde: not recovered: the recovery run for `consume(Ljava/lang/Object;)V` produced no statement (explanation only); the artifact's own comment lines are below
        // @method consume(Ljava/lang/Object;)V
        // @declaration a static method of `cf11.OrdinaryTryListFixture`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 3 4 7 8 11 12 13 16
        // the saved producer at BCI 0 has 3 consumers, so one local binding cannot prove its execution count
        // @bytecode 13 0
        // the value at BCI 13 was produced by a saved declaration this run could not commit
        jarde_refused_body();
    }

    // jarde: generic Signature projection refused for `reassignedInCatch(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public void reassignedInCatch(java.util.List arg1, java.util.List arg2) {
        // @method reassignedInCatch(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        try {
            for (java.lang.Object iteratorElement17 : arg1) {
                java.lang.String local4 = (java.lang.String) iteratorElement17;
                arg2.add((java.lang.Object) local4);
            }
        } catch (java.lang.RuntimeException local3) {
            arg1 = arg2;
            arg1.add((java.lang.Object) null);
        }
        return;
    }

    // jarde: generic Signature projection refused for `rawAliasInCatch(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public void rawAliasInCatch(java.util.List arg1, java.util.List arg2) {
        // @method rawAliasInCatch(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 7 16 42
        // local 4 crosses a protected region, but SSA does not prove that every path to its reads reaches a presented write
        return;
    }

    // jarde: generic Signature projection refused for `multiCatch(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public void multiCatch(java.util.List arg1, java.util.List arg2) {
        // @method multiCatch(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        try {
            java.util.Iterator local3 = arg1.iterator();
            while (local3.hasNext()) {
                java.lang.String local4 = (java.lang.String) local3.next();
                arg2.add((java.lang.Object) local4);
            }
        } catch (java.lang.IllegalArgumentException | java.lang.IllegalStateException local3) {
            arg2.add((java.lang.Object) null);
        }
        return;
    }

    // jarde: generic Signature projection refused for `indexOverload(Ljava/util/List;Ljava/util/List;Ljava/lang/Integer;I)V`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    public void indexOverload(java.util.List arg1, java.util.List arg2, java.lang.Integer arg3, int arg4) {
        // @method indexOverload(Ljava/util/List;Ljava/util/List;Ljava/lang/Integer;I)V
        // @declaration an instance method of `cf11.OrdinaryTryListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        try {
            for (java.lang.Object iteratorElement20 : arg1) {
                java.lang.Integer local6 = (java.lang.Integer) iteratorElement20;
                arg1.remove((java.lang.Object) arg3);
                arg2.add((java.lang.Object) local6);
                arg1.remove(arg4);
            }
        } catch (java.lang.RuntimeException local5) {
            arg2.add((java.lang.Object) null);
        }
        return;
    }
}
