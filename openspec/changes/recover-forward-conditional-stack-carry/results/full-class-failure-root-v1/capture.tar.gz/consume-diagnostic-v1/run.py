from pathlib import Path
import importlib.util,os,json
base=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
s=importlib.util.spec_from_file_location('guard',base/'tools-prep/guard.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
g.OUT=base/'consume-diagnostic-v1';g.expected_test_summaries=lambda *a:None
env=os.environ.copy();[env.pop(k,None) for k in (*g.STRIPPED_ENV_KEYS,'RUST_MIN_STACK','CARGO_TARGET_DIR')];env.update(g.ENV_VALUES);env['RUSTUP_TOOLCHAIN']='stable'
rows=[]
try:rows.append(g.run_command(1,['cargo','test','-p','jarde-java','--lib','--locked','diagnose_consume_stack_carry','--','--ignored','--nocapture'],env))
finally:
 rows.append(g.run_command(2,['cargo','clean'],env));(g.OUT/'execution.json').write_text(json.dumps(rows,indent=2))
