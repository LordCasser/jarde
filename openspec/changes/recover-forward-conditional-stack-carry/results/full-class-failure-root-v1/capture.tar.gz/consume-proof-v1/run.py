from pathlib import Path
import importlib.util,os,json,hashlib
b=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');s=importlib.util.spec_from_file_location('guard',b/'tools-prep/guard.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
g.OUT=b/'consume-proof-v1';g.expected_test_summaries=lambda *a:None;g.command_stream=lambda p:{'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
env=os.environ.copy();[env.pop(k,None) for k in (*g.STRIPPED_ENV_KEYS,'RUST_MIN_STACK','CARGO_TARGET_DIR')];env.update(g.ENV_VALUES);env['RUSTUP_TOOLCHAIN']='stable';rows=[]
try:
 for i,a in enumerate([['cargo','fmt','--all'],['cargo','test','-p','jarde-java','--lib','--locked','forward_conditional_carry','--','--nocapture']],1):
  r=g.run_command(i,a,env);rows.append(r)
  if r['exit_code'] or r['guard_stop']:break
finally:
 rows.append(g.run_command(3,['cargo','clean'],env));(g.OUT/'execution.json').write_text(json.dumps({'commands':rows,'target_absent':not (g.ROOT/'target').exists()},indent=2))
