from pathlib import Path
import hashlib,json,re
BASE=Path('/private/tmp/jarde-foreach-fold-focused-root-v6-20261018');OUT=Path(__file__).parent

def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(v):
 a=pin(v['path']);assert (a['bytes'],a['sha256'])==(v['bytes'],v['sha256']);return a
r=json.loads((BASE/'execution.json').read_text());assert r['status']=='failed' and r['target_absent'] and r['source_unchanged'] and r['source_changes_accepted'] and r['default_stack']
assert r['source_before']==r['source_after'] and not r['source_changes'];assert len(r['commands'])==5
for p in r['source_before']:check(p)
for c in r['commands']:
 for s in c['streams'].values():check(s)
for c,n in zip(r['commands'][:3],[25,1,19]):
 assert c['exit_code']==0 and c['guard_stop'] is None
 assert c['test_summaries']==[['ok',str(n),'0','1' if n==19 else '0']]
 assert c['peak_target_bytes']<=1024**3 and c['free_bytes_after']>=5*1024**3
assert r['commands'][3]['exit_code']==101 and r['commands'][3]['guard_stop'] is None
err=Path(r['commands'][3]['streams']['stderr']['path']).read_text();assert 'function `assert_typed_foreach_copies` is never used' in err and 'due to 1 previous error' in err
assert r['commands'][4]['argv']==['cargo','clean'] and r['commands'][4]['exit_code']==0
names=['typed_foreach_binding_fold_handles_inner_and_visible_outer_bindings','typed_foreach_binding_fold_promotes_direct_first_declaration','typed_foreach_optional_fold_refuses_shadow_writes_captures_and_fallbacks','stale_optional_foreach_binding_plan_falls_back_to_typed_copy','generic_list_foreach_binding_closes_actual_ssa_and_refuses_mutated_facts','original_nested_loops_folds_both_proven_local_bindings_without_changing_raw_sources','nested_foreach_late_cancel_budget_and_deadline_keep_raw_source_atomically']
rows=[]
for c in r['commands'][:3]:
 text=Path(c['streams']['stdout']['path']).read_text();rows.extend(re.findall(r'^test (\S+) \.\.\. (ok|ignored[^\n]*)$',text,re.M))
assert len(rows)==46 and sum(s=='ok' for _,s in rows)==45
for name in names:assert sum(n.split('::')[-1]==name and s=='ok' for n,s in rows)==1,name
out={'status':'root-selected-tests-accepted-clippy-unresolved','scope':'45 tests passed / 1 old diagnostic ignored only. Whole runner failed exact CI Clippy due now-unused old test helper; no CLI built, broad/native/CI/Java acceptance not claimed.','receipt':pin(BASE/'execution.json'),'source_files':len(r['source_before']),'commands':5,'raw_streams':10,'passed':45,'failed_tests':0,'ignored':1,'critical_gates':names,'named_results':rows,'clippy_failure_preserved':True,'default_stack':True,'target_absent':True,'source_unchanged':True}
(OUT/'review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['status','passed','ignored','source_files']},ensure_ascii=False))
