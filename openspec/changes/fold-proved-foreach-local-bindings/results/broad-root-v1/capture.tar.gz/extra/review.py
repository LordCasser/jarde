from pathlib import Path
import hashlib,json,re,stat
OUT=Path(__file__).parent;BASE=Path('/private/tmp/jarde-foreach-fold-broad-root-v1-20261018')
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(v):assert pin(v['path'])==v
r=json.loads((BASE/'execution.json').read_text());assert r['status']=='commands_passed_pending_independent_acceptance' and r['source_unchanged'] and r['source_changes_accepted'] and r['default_stack'] and r['target_absent'];assert r['source_before']==r['source_after'] and r['source_changes']==r['allowed_source_changes']==[]
for v in r['source_after']:check(v)
assert len(r['commands'])==18 and r['commands'][-1]['argv']==['cargo','clean'] and r['commands'][-1]['exit_code']==0
for c in r['commands']:
 assert c['exit_code']==0
 if not c.get('cleanup_only'):assert c['guard_stop'] is None and c['free_bytes_after']>=5*1024**3 and c['peak_target_bytes']<=1024**3
 for v in c['streams'].values():check(v)
assert r['commands'][0]['argv']==['cargo','fmt','--all','--','--check']
assert r['commands'][1]['argv'][:7]==['cargo','clippy','--workspace','--all-targets','--all-features','--locked','--'] and r['commands'][1]['argv'][-2:]==['-D','warnings']
assert r['commands'][2]['argv'][1:]==['+1.88.0','check','--workspace','--all-targets','--all-features','--locked']
rows=[];counts=[]
for c in r['commands']:
 if c['argv'][:2]==['cargo','test']:
  summaries=c['test_summaries'];assert len(summaries)==1 and summaries[0][0]=='ok' and int(summaries[0][1])>0 and summaries[0][2]=='0';counts.append({'argv':c['argv'],'passed':int(summaries[0][1]),'ignored':int(summaries[0][3])});raw=Path(c['streams']['stdout']['path']).read_text();named=re.findall(r'^test (\S+)(?: - should panic)? \.\.\. (ok|ignored[^\n]*)$',raw,re.M);assert len(named)==int(summaries[0][1])+int(summaries[0][3]);rows.extend(named)
assert sum(x['passed'] for x in counts)==808 and sum(x['ignored'] for x in counts)==6
focused=json.loads(Path('/private/tmp/jarde-foreach-fold-focused-review-root-v1-20261018/review.json').read_text())
for name in focused['critical_gates']:assert sum(n.split('::')[-1]==name and s=='ok' for n,s in rows)==1,name
check(r['cli']);assert r['cli']['sha256']=='c688920cac70ee9e46681672ebaaba5df2948c5ef5b5f262d006548ca1f83ebe' and not Path(r['cli']['path']).stat().st_mode & stat.S_IWUSR
out={'status':'root-broad-accepted','receipt':pin(BASE/'execution.json'),'cli':r['cli'],'commands':18,'raw_streams':36,'source_files':len(r['source_after']),'source_unchanged':True,'passed':808,'ignored':6,'failed':0,'critical_gates':focused['critical_gates'],'test_groups':counts,'default_stack':True,'resource_guards':True,'target_absent':True,'scope':'Local broad checks and frozen CLI only. Full Java comparison/two fresh native/product CI remain pending.'};(OUT/'review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['status','passed','ignored','source_files','cli']}))
