from pathlib import Path
import json,hashlib,subprocess
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path(__file__).parent

def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(v):assert pin(v['path'])==v
rp=Path('/private/tmp/jarde-foreach-fold-dataset-root-v1-20261018/execution.json');r=json.loads(rp.read_text());assert r['status']=='commands_passed_pending_independent_acceptance' and r['target_absent'] and r['default_stack'] and r['source_changes_accepted'] and not r['source_unchanged'];assert r['source_changes']==['tests/fixtures/corpus-fingerprint.json'];assert len(r['commands'])==4
for c in r['commands']:
 assert c['exit_code']==0
 if not c.get('cleanup_only'):assert c['guard_stop'] is None and c['peak_target_bytes']<=1024**3 and c['free_bytes_after']>=5*1024**3
 for v in c['streams'].values():check(v)
for v in r['source_after']:check(v)
assert [c['test_summaries'] for c in r['commands'][:3]]==[[['ok','1','0','0']],[['ok','1','0','0']],[['ok','5','0','1']]]
oldbytes=subprocess.check_output(['git','show','HEAD:tests/fixtures/corpus-fingerprint.json'],cwd=ROOT);(OUT/'fingerprint-before.json').write_bytes(oldbytes);old=json.loads(oldbytes);new=json.loads((ROOT/'tests/fixtures/corpus-fingerprint.json').read_text());a={x['path']:x for x in old['files']};b={x['path']:x for x in new['files']};assert len(a)==2429 and len(b)==2432 and len(a)==len(old['files']) and len(b)==len(new['files'])
assert all(b.get(k)==v for k,v in a.items());extra=set(b)-set(a);expected={'tests/fixtures/foreach-local-bindings/debug/TestNestedLoops$TestCls.class','tests/fixtures/foreach-local-bindings/none/TestNestedLoops$TestCls.class','tests/fixtures/foreach-local-bindings/source/TestNestedLoops.java'};assert extra==expected
carriers=new['dimensions']['recovery']['carriers'];newcarriers=carriers[:3];assert carriers[3:]==old['dimensions']['recovery']['carriers'];assert newcarriers==[{'kind':'file','path':'tests/fixtures/foreach-local-bindings/debug/TestNestedLoops$TestCls.class'},{'kind':'file','path':'tests/fixtures/foreach-local-bindings/none/TestNestedLoops$TestCls.class'},{'kind':'record','path':'tests/fixtures/foreach-local-bindings/README.md'}]
norm=json.loads(json.dumps(new));norm['files']=old['files'];norm['dimensions']['recovery']['carriers']=old['dimensions']['recovery']['carriers'];assert norm==old
before={x['path']:x for x in r['source_before']};after={x['path']:x for x in r['source_after']};assert before.keys()==after.keys();changed=[k for k in before if before[k]!=after[k]];assert changed==[str(ROOT/'tests/fixtures/corpus-fingerprint.json')];assert hashlib.sha256(oldbytes).hexdigest()==before[changed[0]]['sha256']
out={'status':'root-dataset-accepted','receipt':pin(rp),'passed':7,'ignored':1,'source_files':len(after),'only_source_change':'tests/fixtures/corpus-fingerprint.json','reader_measured':[1303,5755,630,4066,14],'fingerprint_before':len(a),'fingerprint_after':len(b),'all_old_records_unchanged':True,'other_manifest_metadata_unchanged':True,'added_records':[b[k] for k in sorted(extra)],'added_carriers':newcarriers,'target_absent':True,'default_stack':True,'scope':'Dataset preparation accepted. No CLI, Java matrix, broad/native or own CI acceptance.'};(OUT/'review.json').write_text(json.dumps(out,indent=2)+'\n');print(out['status'],len(a),len(b))
