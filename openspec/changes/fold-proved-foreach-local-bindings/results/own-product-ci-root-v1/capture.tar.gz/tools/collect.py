import datetime,hashlib,json,subprocess,sys
from pathlib import Path
out=Path(sys.argv[1]).resolve(strict=True);run=sys.argv[2];assert run.isdigit()
argv=['gh','api',f'repos/LordCasser/jarde/actions/runs/{run}/logs']
row={'argv':argv,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
stdout=out/'run-logs.zip';stderr=out/'run-logs.stderr.raw'
with stdout.open('xb') as so,stderr.open('xb') as se:
 row['exit_code']=subprocess.run(argv,cwd='/Users/lordcasser/workspace/projects/jarde',stdout=so,stderr=se).returncode
row['streams']={k:{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in [('stdout',stdout),('stderr',stderr)]}
with (out/'step-log-supplement.json').open('x') as f:json.dump(row,f,indent=2);f.write('\n')
assert row['exit_code']==0
print(json.dumps({'exit_code':row['exit_code'],'zip':row['streams']['stdout']}))
