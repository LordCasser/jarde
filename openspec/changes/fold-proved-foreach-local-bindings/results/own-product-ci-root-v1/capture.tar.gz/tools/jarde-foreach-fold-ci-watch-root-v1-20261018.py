import datetime,hashlib,json,subprocess
from pathlib import Path
OUT=Path('/private/tmp/jarde-foreach-fold-ci-watch-root-v1-20261018');assert not OUT.exists();OUT.mkdir()
argv=['gh','run','watch','39120933555','--repo','LordCasser/jarde','--interval','60','--exit-status']
r={'status':'waiting','argv':argv,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'product':'0a7e3c98f63b128a13a658a475b9e69a9e60d048'}
(OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
so=OUT/'stdout.raw';se=OUT/'stderr.raw'
with so.open('xb') as f,se.open('xb') as g:q=subprocess.run(argv,cwd='/Users/lordcasser/workspace/projects/jarde',stdout=f,stderr=g)
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
r.update({'status':'watch-ended-success' if q.returncode==0 else 'watch-ended-nonzero','exit_code':q.returncode,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout':pin(so),'stderr':pin(se),'note':'Wake-up status only. Full exact-product official-log acceptance is separate.'})
(OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'exit_code':q.returncode}));raise SystemExit(q.returncode)
