# Final narrow architecture acceptance

Date: 2026-10-18. Read-only review of the requested optional foreach binding fold and typed foreach projection.

## Pinned inputs

- `src/facade.rs` SHA-256: `cdbdb4d2ed652055c501072bb06dfad45493589b2ef7710cf799d4f77a430fc6`
- `crates/jarde-java/src/report.rs` SHA-256: `7f95ecec71e05b6a167d721bbe657660d55c646966e3638764c042b3b66272fb`
- `openspec/changes/fold-proved-foreach-local-bindings/design.md` SHA-256: `d49d923e94e0288c5d2d454de7d4a07da451af84bfedeea6b5219d1c68e69235`

## Result

No concrete semantic or transaction defect found in the requested paths.

The facade treats binding recovery as optional: a missing or unprovable binding site omits only `edit.binding`; the typed foreach edit is still staged. `Stop` is propagated with `?`, so budget, cancellation, and deadline outcomes are not converted into optional-proof failure. The slot proof requires a unique direct store, matches every collected AST target read to a physical `aload` and SSA local read, rejects other-slot reads/writes at those sites, and checks the store's known-use BCI census against both physical and AST reads.

`SsaUse(None)` is treated as a phi operand, not as a missing physical read. The implementation filters `None` and demands exact equality of the remaining BCIs; it still requires the store and every observed read to retain the same unreplaced direct instruction definition. The focused fixture documents the real None operands and tests that removing a known Some-BCI use or changing a read definition to Phi refuses the optional fold.

The report projector rebuilds the binding proof against the same opaque AST and compares the complete binding plan before adding it to `binding_by_bci`. Failure or stale-plan inequality leaves the typed edit available. Edits are applied to a cloned program; traversal/merge/removal errors propagate before a projected AST is returned. The facade's staged/final plan comparison charges and compares the binding metadata and read-origin sets as part of equality.

The binding inventory distinguishes AST nodes beyond BCI: it checks node shape, target name, and full origin set, and counts target assignments/declarations. The same-origin, same-BCI literal assignment metamorphism is rejected. Nested traversal continues into a surviving foreach body after an outer fold, and the report test applies nested typed edits under Try/Switch while preserving ancillary statements. Blank declaration removal is conditional on a successfully folded BCI and rechecks BCI, full origin, declaration shape, and name.

## Coverage boundary

The report's explicit budget/cancel/deadline atomicity test uses typed edits with no binding plans; it verifies the clone-and-discard transaction and recursive Try/Switch traversal. I did not find a separate late-Stop test with a binding plan that stops specifically during origin merge or blank removal. The implementation paths propagate the same `StopReason` before returning the staged clone, so this is a test-coverage boundary, not an observed defect. Parent reports the final broad gate as 808 passed, 0 failed, 6 previously ignored, and final CLI SHA `c688920cac70ee9e46681672ebaaba5df2948c5ef5b5f262d006548ca1f83ebe`; I did not run tools or independently verify that gate.
