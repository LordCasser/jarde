#!/usr/bin/env python3
"""Independent read-only reviewer for the TestNestedLoops generated-source matrix."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, re
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
BASELINE_SCHEMA='cf11-testnestedloops-current-full-source-baseline-v1'
MATRIX_SCHEMA='cf11-testnestedloops-current-generated-source-matrix-v2'
INTERNAL='jadx/tests/integration/loops/TestNestedLoops$TestCls'
EXPECTED_METHODS={('<init>','()V'),('test','(Ljava/util/List;Ljava/util/List;)V')}
PROFILES=('debug','no-debug'); FORMS=('child','bundle-child'); EVIDENCE=('default','all')
LEGS=('javac8','javac23'); RUNTIMES=('javac8','javac23')
CASE_NAMES=('both-empty','unmatched','five-character-match-add','non-five-match-remove',
 'non-five-match-continues-and-clears','null-first-list','null-second-list','null-element')
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def file_pin(compare,path): return compare.pin(Path(path).resolve(strict=True))
def require_pin(compare,record,label):
 if not isinstance(record,dict) or not {'path','bytes','sha256'}<=record.keys(): raise RuntimeError(f'{label}: malformed pin')
 p=Path(record['path']).resolve(strict=True)
 actual=compare.pin(p)
 if actual!=record: raise RuntimeError(f'{label}: bytes/SHA differ at {p}')
 return p
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path)
 if spec is None or spec.loader is None: raise RuntimeError(f'cannot import {path}')
 module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module
def parse_rows(raw):
 pattern=re.compile(r'^CASE index=(\d+) name=([^ ]+) exception=([^ ]+) l1=(.*?) l2=(.*)$')
 rows=[]
 for i,line in enumerate(raw.decode('utf-8','strict').splitlines()):
  m=pattern.fullmatch(line)
  if m is None or int(m.group(1))!=i or i>=len(CASE_NAMES) or m.group(2)!=CASE_NAMES[i]:
   raise RuntimeError(f'malformed or misordered driver row: {line!r}')
  _,name,exc,left,right=m.groups()
  rows.append({'index':i,'name':name,'exception_type':exc,'left_after':left,'right_after':right,'raw':line})
 if len(rows)!=8: raise RuntimeError(f'expected 8 observation rows, got {len(rows)}')
 return rows
def semantic(rows): return [{k:r[k] for k in ('index','name','exception_type','left_after','right_after')} for r in rows]
def tree_pins(compare,root): return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*.class'))}
def file_pins(compare,root): return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*')) if p.is_file()}
def physical_facts(compare,physical,path):
 facts=compare.parse_class(path); independent=physical.parse_class_file(path.read_bytes())
 if independent['class_name']!=facts['class_name'] or independent['major']!=facts['major'] or independent['methods']!=facts['methods']:
  raise RuntimeError(f'independent class/method/Code parser mismatch: {path}')
 if sorted((x['name'],x['descriptor'],x['access']) for x in independent['fields'])!=sorted(facts['fields']):
  raise RuntimeError(f'independent field parser mismatch: {path}')
 facts['access']=independent['access']
 keys={(m['name'],m['descriptor']) for m in facts['methods']}
 if len(keys)!=len(facts['methods']): raise RuntimeError(f'duplicate method identity: {path}')
 for m in facts['methods']:
  code=m.get('code')
  if code is None or not code.get('bcis') or code['bcis'][0]!=0 or code['bcis'][-1]>=code['code_length']:
   raise RuntimeError(f'missing/invalid Code or BCI facts: {path} {m.get("name")}{m.get("descriptor")}')
  raw=bytes.fromhex(code['code_hex'])
  if len(raw)!=code['code_length'] or physical.decode_bcis(raw)!=code['bcis']:
   raise RuntimeError(f'physical instruction decode differs from BCI facts: {path} {m.get("name")}{m.get("descriptor")}')
  rows=code.get('rows')
  if not isinstance(rows,list): raise RuntimeError(f'malformed exception table: {path}')
  for row in rows:
   if not isinstance(row,(list,tuple)) or len(row)!=4:
    raise RuntimeError(f'malformed exception row: {path} {row!r}')
   start,end,handler,catch=row
   if not all(isinstance(v,int) for v in row) or not (0<=start<end<=code['code_length'] and handler in code['bcis'] and start in code['bcis'] and end in set(code['bcis'])|{code['code_length']} and catch>=0):
    raise RuntimeError(f'exception table row outside Code bounds: {path} {row!r}')
 return facts
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--matrix',type=Path,required=True); ap.add_argument('--matrix-sha256',required=True)
 ap.add_argument('--baseline',type=Path,required=True); ap.add_argument('--baseline-sha256',required=True)
 ap.add_argument('--out',type=Path,required=True); ap.add_argument('--root',type=Path,default=ROOT)
 a=ap.parse_args(); matrix_path=a.matrix.resolve(strict=True); baseline_path=a.baseline.resolve(strict=True); root=a.root.resolve(strict=True); out=a.out.resolve()
 for value,label in ((a.matrix_sha256,'matrix'),(a.baseline_sha256,'baseline')):
  if re.fullmatch('[0-9a-f]{64}',value) is None: raise SystemExit(f'{label} SHA must be explicit lowercase SHA-256')
 if sha_bytes(matrix_path.read_bytes())!=a.matrix_sha256: raise SystemExit('matrix receipt differs from supplied SHA')
 if sha_bytes(baseline_path.read_bytes())!=a.baseline_sha256: raise SystemExit('baseline receipt differs from supplied SHA')
 if root!=ROOT.resolve(): raise SystemExit('workspace root differs from pinned checkout')
 if out.exists(): raise SystemExit(f'refusing existing review output: {out}')
 matrix=json.loads(matrix_path.read_text(encoding='utf-8')); base=json.loads(baseline_path.read_text(encoding='utf-8'))
 if matrix.get('schema')!=MATRIX_SCHEMA or matrix.get('status')!='captured-pending-independent-review': raise SystemExit('matrix schema/status is not a completed pending capture')
 if base.get('schema')!=BASELINE_SCHEMA or base.get('status')!='captured-pending-independent-review': raise SystemExit('baseline schema/status mismatch')
 # Verify imported helper files before executing their module code.
 helper_records=(matrix['compare'],matrix['guard'],matrix['scanner'],matrix['physical_parser'])
 for record,label in zip(helper_records,('compare','guard','scanner','physical parser')):
  if not isinstance(record,dict) or not {'path','bytes','sha256'}<=record.keys(): raise RuntimeError(f'{label}: malformed helper pin')
  helper_path=Path(record['path']).resolve(strict=True); helper_bytes=helper_path.read_bytes()
  if len(helper_bytes)!=record['bytes'] or sha_bytes(helper_bytes)!=record['sha256']:
   raise RuntimeError(f'{label}: helper changed before import: {helper_path}')
 compare_path=Path(matrix['compare']['path']).resolve(strict=True); parser_path=Path(matrix['physical_parser']['path']).resolve(strict=True)
 compare=load(compare_path,'nested_matrix_review_compare'); physical=load(parser_path,'nested_matrix_review_physical')
 for record,label in zip(helper_records,('compare','guard','scanner','physical parser')): require_pin(compare,record,label)
 manifest=matrix.get('jdk_manifest')
 if not isinstance(manifest,dict) or not isinstance(manifest.get('path'),str) or not isinstance(manifest.get('sha256'),str):
  raise RuntimeError('malformed JDK manifest path/SHA record')
 jdk_path=Path(manifest['path']).resolve(strict=True)
 if sha_bytes(jdk_path.read_bytes())!=manifest['sha256'] or manifest['sha256']!='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec':
  raise RuntimeError('JDK manifest path/SHA differs from the frozen manifest')
 jdks,jdk_record=compare.configured_jdks(jdk_path,'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
 if jdk_record!=manifest: raise RuntimeError('configured JDK receipt differs from matrix manifest')
 baseline_pin=compare.pin(baseline_path)
 if matrix.get('baseline_receipt')!=baseline_pin or baseline_pin['sha256']!=a.baseline_sha256:
  raise RuntimeError('matrix is not bound to the supplied baseline receipt')
 if matrix.get('baseline_sha256_argument')!=a.baseline_sha256: raise RuntimeError('matrix baseline argument differs from supplied baseline')
 if base.get('source_unchanged') is not True or base.get('target_absent') is not True: raise RuntimeError('baseline source/target receipt gates failed')
 commands=matrix.get('commands',[]); command_by_id={r.get('index'):r for r in commands}
 if len(command_by_id)!=len(commands) or None in command_by_id: raise RuntimeError('matrix command IDs missing/duplicated')
 if sorted(command_by_id)!=list(range(1,len(commands)+1)): raise RuntimeError('matrix command numbering is not contiguous')
 for row in commands:
  if row.get('guard_stop') is not None: raise RuntimeError(f'guard stop recorded for command {row.get("index")}')
  if not isinstance(row.get('free_bytes_after'),int) or row['free_bytes_after']<5*1024**3:
   raise RuntimeError(f'free-space guard below 5 GiB for command {row.get("index")}')
  if not isinstance(row.get('peak_target_bytes'),int) or row['peak_target_bytes']>1024**3:
   raise RuntimeError(f'target peak exceeded 1 GiB for command {row.get("index")}')
  for stream in ('stdout','stderr'): compare.command_artifact(row,stream)
  if row.get('exit_code')!=row.get('streams',{}).get('exit_code',row.get('exit_code')): raise RuntimeError('command stream exit metadata mismatch')
 # Independently read all four original raw JVM observations; never trust saved counts or projections.
 base_commands={r.get('index'):r for r in base.get('commands',[])}
 if len(base_commands)!=len(base.get('commands',[])): raise RuntimeError('baseline command IDs duplicated')
 for base_cmd in base_commands.values():
  if base_cmd.get('guard_stop') is not None: raise RuntimeError('baseline command has a guard stop')
  if not isinstance(base_cmd.get('free_bytes_after'),int) or base_cmd['free_bytes_after']<5*1024**3:
   raise RuntimeError(f'baseline free-space guard below 5 GiB for command {base_cmd.get("index")}')
  if not isinstance(base_cmd.get('peak_target_bytes'),int) or base_cmd['peak_target_bytes']>1024**3:
   raise RuntimeError(f'baseline target peak exceeded 1 GiB for command {base_cmd.get("index")}')
  compare.command_artifact(base_cmd,'stdout'); compare.command_artifact(base_cmd,'stderr')
 oracle={}
 for row in base.get('original_runtime',[]):
  key=(row.get('profile'),row.get('runtime')); cmd=base_commands.get(row.get('command'))
  if key in oracle or key[0] not in PROFILES or key[1] not in RUNTIMES or cmd is None or cmd.get('exit_code')!=0:
   raise RuntimeError('invalid or duplicate original oracle row')
  raw=compare.command_artifact(cmd,'stdout'); parsed=parse_rows(raw)
  if row.get('rows')!=parsed: raise RuntimeError('saved baseline rows differ from original raw stdout')
  oracle[key]=semantic(parsed)
 if set(oracle)!={(p,r) for p in PROFILES for r in RUNTIMES}: raise RuntimeError('original profile/runtime oracle coverage incomplete')
 expected_oracles={f'{p}/{r}':v for (p,r),v in oracle.items()}
 if matrix.get('original_oracles')!=expected_oracles: raise RuntimeError('matrix saved oracle projection differs from independently parsed original raw streams')
 # Rebind each source cell to exact baseline whole-source bytes and check its compiled filename/path.
 base_jarde={(r['profile'],r['input_form'],r['evidence']):r for r in base.get('jarde_cells',[])}
 base_jadx={(r['compiler_profile'],r['display_profile']):r for r in base.get('jadx_outputs',[])}
 source_cells=matrix.get('source_cells',[]); source_keys=set(); source_copy_pins={}
 for cell in source_cells:
  kind=cell.get('kind'); profile=cell.get('profile')
  if kind=='jarde':
   key=(profile,cell.get('form'),cell.get('evidence')); srcrow=base_jarde.get(key)
   if srcrow is None: raise RuntimeError(f'unexpected Jarde source cell {key}')
   require_pin(compare,srcrow['input'],'baseline Jarde original class')
   original=require_pin(compare,srcrow['whole_source'],'baseline Jarde source')
   report_path=require_pin(compare,srcrow['report'],'baseline Jarde report')
   report_doc=json.loads(report_path.read_text(encoding='utf-8'))
   if report_doc.get('text','').encode('utf-8')!=original.read_bytes(): raise RuntimeError('baseline Jarde report text differs from whole-source bytes')
   if len(cell.get('source_copies',[]))!=1: raise RuntimeError('Jarde cell must copy one whole source')
   item=cell['source_copies'][0]; copy=require_pin(compare,item['copy'],'Jarde copied source')
   if item['source']!=srcrow['whole_source'] or original.read_bytes()!=copy.read_bytes(): raise RuntimeError('Jarde source copy changed bytes')
   expected_rel='jadx/tests/integration/loops/TestNestedLoops$TestCls.java'
   if Path(copy).relative_to(Path(matrix['output'])/'sources'/'-'.join(map(str,key))).as_posix()!=expected_rel:
    raise RuntimeError('Jarde source copy is not at expected owner/file path')
   source_keys.add(('jarde',*key)); source_copy_pins[str(copy)]=item['copy']
  elif kind=='jadx':
   if cell.get('form')!='bundle' or cell.get('evidence')!='source': raise RuntimeError('unexpected JADX cell form')
   key=(profile,'default'); srcrow=base_jadx.get(key)
   if srcrow is None: raise RuntimeError(f'unexpected JADX profile {key}')
   require_pin(compare,srcrow['input'],'baseline JADX class bundle')
   pins=srcrow.get('sources',[]); copies=cell.get('source_copies',[])
   if len(pins)!=len(copies) or not pins: raise RuntimeError('JADX output source inventory differs from copied inventory')
   for srcpin,item in zip(pins,copies):
    original=require_pin(compare,srcpin,'baseline JADX source'); copy=require_pin(compare,item['copy'],'copied JADX source')
    if item['source']!=srcpin or original.read_bytes()!=copy.read_bytes(): raise RuntimeError('JADX complete source copy changed bytes')
    source_copy_pins[str(copy)]=item['copy']
   if not any(Path(item['copy']['path']).name=='TestNestedLoops.java' for item in copies): raise RuntimeError('JADX copied outer source missing')
   source_keys.add(('jadx',profile,'bundle'))
  else: raise RuntimeError(f'unknown source kind {kind!r}')
 expected_sources={('jarde',p,f,e) for p in PROFILES for f in FORMS for e in ('default','all')}|{('jadx',p,'bundle') for p in PROFILES}
 if source_keys!=expected_sources or len(source_cells)!=10: raise RuntimeError('source grid not exact 8 Jarde + 2 JADX cells')
 # Every source cell must have one compile attempt per compiler. Reparse all successful output classes independently.
 compilations=matrix.get('compilations',[]); by_compile={}
 source_by_key={tuple(c['cell_key']):c for c in source_cells}
 if len(compilations)!=20: raise RuntimeError('compile attempt inventory is not 10×2')
 for comp in compilations:
  key=tuple(comp.get('cell_key',[])); leg=comp.get('leg'); ckey=(key,leg)
  if ckey in by_compile or leg not in LEGS: raise RuntimeError('compile selector duplicated/invalid')
  by_compile[ckey]=comp
  command=command_by_id.get(comp.get('command'))
  if command is None or command.get('exit_code')!=comp.get('exit_code') or command.get('label')!=f"compile-{'-'.join(map(str,key))}-{leg}":
   raise RuntimeError('compile row is not tied to matching raw command/selector')
  if command.get('tool_leg')!=leg: raise RuntimeError('compiler tool leg differs from compile record')
  argv=command.get('argv',[])
  expected_compiler=jdks[leg]['tools']['javac']
  if argv[0]!=str(expected_compiler): raise RuntimeError('compile command does not use the pinned JDK compiler')
  if leg=='javac8':
   if not all(token in argv for token in ('-source','8','-target','8','-encoding','UTF-8','-proc:none')):
    raise RuntimeError('javac8 compile flags differ from Java 8-target contract')
  elif not all(token in argv for token in ('--release','8','-encoding','UTF-8','-proc:none')):
   raise RuntimeError('javac23 compile flags differ from Java 8 release contract')
  if ('-g' if key[0]=='debug' else '-g:none') not in argv: raise RuntimeError('compile debug profile flags differ')
  if '-classpath' not in argv or argv[argv.index('-classpath')+1]!=os.pathsep.join(base['dependency_classpath']):
   raise RuntimeError('compile dependency classpath differs from original harness receipt')
  if '-d' not in argv or Path(argv[argv.index('-d')+1]).resolve()!=Path(comp['class_root']).resolve(): raise RuntimeError('javac destination differs from recorded class root')
  source_cell=source_by_key.get(key)
  if source_cell is None or comp.get('source_copies')!=source_cell.get('source_copies'):
   raise RuntimeError('compile source list differs from its full-source cell')
  if not comp.get('source_copies'): raise RuntimeError('compile command lacks whole-source inputs')
  for source in comp['source_copies']:
   copy=require_pin(compare,source['copy'],'compile source copy')
   if copy.read_bytes()!=Path(source['source']['path']).read_bytes(): raise RuntimeError('compile source bytes differ')
   if str(copy) not in {str(Path(x)) for x in argv}: raise RuntimeError('javac argv omits a full source copy')
  compiled_root=Path(comp['class_root']).resolve(strict=True)
  actual_tree=file_pins(compare,compiled_root)
  if any(not rel.endswith('.class') for rel in actual_tree): raise RuntimeError(f'non-class file appeared in compiler output tree: {key}/{leg}')
  if actual_tree!=comp.get('class_tree'): raise RuntimeError(f'class tree pin mismatch: {key}/{leg}')
  if comp['exit_code']==0:
   facts={}
   for rel,pin in actual_tree.items():
    path=require_pin(compare,pin,'compiled class')
    facts[rel]=physical_facts(compare,physical,path)
   if json.loads(json.dumps(facts))!=comp.get('class_facts'): raise RuntimeError(f'saved dual-parser facts differ from physical class files: {key}/{leg}')
   if any(f['major']!=52 for f in facts.values()): raise RuntimeError(f'compiled output contains non-Java-8 classfile: {key}/{leg}')
   target=facts.get(INTERNAL+'.class')
   expected_tree=({INTERNAL+'.class'} if key[1] in FORMS else {'jadx/tests/integration/loops/TestNestedLoops.class',INTERNAL+'.class'})
   if set(facts)!=expected_tree: raise RuntimeError(f'compiled class tree differs from complete source form: {key}/{leg}: {set(facts)}')
   if target is None or target.get('major')!=52 or EXPECTED_METHODS!={(m['name'],m['descriptor']) for m in target['methods']}:
    raise RuntimeError(f'target class identity/full method inventory/major invalid: {key}/{leg}')
   profile_row=next((x for x in base.get('source_profiles',[]) if x.get('profile')==key[0]),None)
   if profile_row is None: raise RuntimeError(f'missing original class profile {key[0]}')
   def member_surface(f):
    return (f['class_name'],f['access'],tuple(sorted(tuple(x) for x in f['fields'])),
            tuple(sorted((x['name'],x['descriptor'],x['access']) for x in f['methods'])))
   target_expected=profile_row.get('target_facts')
   if target_expected is None or member_surface(target)!=member_surface(target_expected):
    raise RuntimeError(f'compiled target class/member/access inventory differs from original source profile: {key}/{leg}')
   if key[1]=='bundle':
    outer=facts.get('jadx/tests/integration/loops/TestNestedLoops.class'); outer_expected=profile_row.get('outer_facts')
    if outer is None or outer_expected is None or member_surface(outer)!=member_surface(outer_expected):
     raise RuntimeError(f'compiled complete outer/member/access inventory differs from original source profile: {key}/{leg}')
  elif comp.get('class_facts') is not None: raise RuntimeError('failed compile falsely carries class facts')
  else:
   failed_err=compare.command_artifact(command,'stderr')
   if b'55.0' not in failed_err or b'52.0' not in failed_err:
    raise RuntimeError(f'failed compile is not the observed Java 55-to-52 dependency boundary: {key}/{leg}')
 expected_compile_keys={(tuple(cell['cell_key']),leg) for cell in source_cells for leg in LEGS}
 if set(by_compile)!=expected_compile_keys: raise RuntimeError('compile grid is incomplete')
 failed_keys={(key,leg) for (key,leg),comp in by_compile.items() if comp['exit_code']!=0}
 expected_failures={(('debug','bundle'),'javac8'),(('no-debug','bundle'),'javac8')}
 if failed_keys!=expected_failures: raise RuntimeError(f'full-source compile boundary differs from raw observations: {failed_keys}')
 # Driver classes are checked via byte pins and the narrow parser summary; strict parser is unsuitable for MUTF8 literals.
 driver_source=require_pin(compare,matrix['driver_source'],'driver source'); driver_copy=require_pin(compare,matrix['driver_copy'],'driver copy')
 driver_bytes=driver_source.read_bytes()
 if driver_source.read_bytes()!=driver_copy.read_bytes(): raise RuntimeError('reflection driver source copy differs')
 if sha_bytes(driver_source.read_bytes())!='4534f142ad673595898a581ebb474a0d2783cbd974b403f8c658e74792e59df0':
  raise RuntimeError('reflection driver is not the frozen parentless eight-case driver')
 for marker in (b'new URLClassLoader(new URL[] {url}, null)',b'target.getClassLoader() != loader',b'wrong CodeSource:'):
  if marker not in driver_bytes: raise RuntimeError('reflection driver lacks parentless loading/CodeSource assertion')
 driver_root=Path(matrix['output'])/'driver-classes'; driver_tree=file_pins(compare,driver_root)
 if len(driver_tree)!=3 or json.loads(json.dumps([compare.parse_class(Path(pin['path'])) for _,pin in sorted(driver_tree.items())]))!=matrix.get('driver_summaries'):
  raise RuntimeError('driver class tree or narrow parser summaries differ')
 driver_recorded={pin['path']:pin for pin in matrix.get('driver_classes',[])}
 if len(driver_recorded)!=3 or set(driver_recorded)!={str(Path(matrix['output'])/'driver-classes'/rel) for rel in driver_tree}:
  raise RuntimeError('driver class inventory differs')
 for pin in driver_recorded.values(): require_pin(compare,pin,'driver class byte pin')
 driver_cmd=command_by_id.get((matrix.get('driver_compile') or {}).get('command'))
 if driver_cmd is None or driver_cmd.get('exit_code')!=0 or driver_cmd.get('tool_leg')!='javac8': raise RuntimeError('driver compile is absent/failed')
 driver_argv=driver_cmd['argv']
 driver_cpflag='-classpath' if '-classpath' in driver_argv else '-cp'
 if driver_argv[driver_argv.index(driver_cpflag)+1]!=str(Path(matrix['output'])/'empty-classpath'):
  raise RuntimeError('driver compile classpath is not isolated')
 if str(driver_copy) not in driver_argv: raise RuntimeError('driver compile command omits exact source copy')
 # Runtime checks: exact compile/runtime pairing, fresh parentless target loading and semantic result vs original raw oracle.
 runtime_rows=matrix.get('runtime_rows',[]); runtime_keys=set(); runtime_commands=set()
 for row in runtime_rows:
  key=tuple(row.get('cell_key',[])); compiler=row.get('compiler'); runtime=row.get('runtime'); rk=(key,compiler,runtime)
  if rk in runtime_keys or compiler not in LEGS or runtime not in RUNTIMES: raise RuntimeError('runtime selector duplicate/invalid')
  runtime_keys.add(rk); cmd=command_by_id.get(row.get('command'))
  expected_label=f"runtime-{'-'.join(map(str,key))}-{compiler}-{runtime}"
  if cmd is None or cmd.get('label')!=expected_label or cmd.get('tool_leg')!=runtime:
   raise RuntimeError('runtime command label/JVM leg differs from selector')
  compile_row=by_compile.get((key,compiler))
  if cmd is None or compile_row is None or compile_row['exit_code']!=0: raise RuntimeError('runtime has no successful matching compile')
  if cmd.get('exit_code')!=row.get('exit_code') or row.get('exit_code')!=0: raise RuntimeError('runtime command did not exit successfully')
  argv=cmd['argv']; expected_root=str(Path(compile_row['class_root']).resolve())
  if row.get('application_classpath')!=[str(Path(matrix['output'])/'driver-classes')]: raise RuntimeError('runtime application classpath not driver-only')
  if '-cp' not in argv or argv[argv.index('-cp')+1]!=row['application_classpath'][0]: raise RuntimeError('runtime argv classpath differs')
  if argv[-2:]!=[expected_root,expected_root] or argv[-3]!='TestNestedLoopsDriver' or '-Xverify:all' not in argv:
   raise RuntimeError('runtime target/expected CodeSource roots or verify flag differ')
  wrapper=matrix.get('local_copies_before',[])[1]['path']
  if argv[1:4]!=['-B',wrapper,'30'] or argv[4]!=str(jdks[runtime]['tools']['java']):
   raise RuntimeError('runtime wrapper invocation differs')
  raw=compare.command_artifact(cmd,'stdout'); parsed=parse_rows(raw); projection=semantic(parsed)
  if row.get('rows')!=parsed or row.get('semantic_projection')!=projection: raise RuntimeError('runtime saved observations differ from raw stdout')
  expected=oracle[(key[0],runtime)]
  if projection!=expected or row.get('matches_original_profile_runtime') is not True:
   raise RuntimeError(f'compiled output differs from matching original profile/runtime oracle: {key}/{compiler}/{runtime}')
  runtime_commands.add(row['command'])
 successful={(key,leg) for (key,leg),c in by_compile.items() if c['exit_code']==0}
 if runtime_keys!={(key,leg,runtime) for key,leg in successful for runtime in RUNTIMES}:
  raise RuntimeError('successful-compile runtime coverage is not exactly two JVMs each')
  # One wrong-root check per successful compile; raw stacktrace must show driver's real CodeSource rejection.
 wrongs=matrix.get('wrong_root_rows',[]); wrong_keys=set()
 for row in wrongs:
  key=tuple(row.get('cell_key',[])); leg=row.get('compiler'); wk=(key,leg)
  if wk in wrong_keys: raise RuntimeError('duplicate wrong-root control')
  wrong_keys.add(wk); compiled=by_compile.get(wk); cmd=command_by_id.get(row.get('command'))
  if compiled is None or compiled['exit_code']!=0 or cmd is None:
   raise RuntimeError('wrong-root control lacks successful compile')
  if cmd.get('label')!=f"wrong-root-{'-'.join(map(str,key))}-{leg}" or cmd.get('tool_leg')!='javac23':
   raise RuntimeError('wrong-root command label/JVM leg differs from selector')
  err=compare.command_artifact(cmd,'stderr'); argv=cmd['argv']; actual=str(Path(compiled['class_root']).resolve())
  if cmd.get('exit_code')==0 or b'wrong CodeSource:' not in err or row.get('rejected') is not True:
   raise RuntimeError('wrong CodeSource negative control did not reject in raw stderr')
  if argv[-2:]!=[actual,row.get('expected_wrong_root')] or row.get('actual_target_root')!=actual:
   raise RuntimeError('wrong-root actual/expected locations differ from argv')
  if argv[-3]!='TestNestedLoopsDriver' or '-Xverify:all' not in argv or '-cp' not in argv or argv[argv.index('-cp')+1]!=str(Path(matrix['output'])/'driver-classes'):
   raise RuntimeError('wrong-root driver/runtime invocation is not isolated')
  if argv[1:4]!=['-B',matrix['local_copies_before'][1]['path'],'30'] or argv[4]!=str(jdks['javac23']['tools']['java']):
   raise RuntimeError('wrong-root timeout wrapper invocation differs')
 if wrong_keys!=successful: raise RuntimeError('wrong-root control count does not match successful compiles')
 if set(runtime_commands)&{r['command'] for r in wrongs}: raise RuntimeError('runtime and wrong-root command IDs overlap')
 used={driver_cmd['index']}|{c['command'] for c in compilations}|runtime_commands|{r['command'] for r in wrongs}
 if used!=set(command_by_id): raise RuntimeError('unclassified or reused command rows in matrix receipt')
 # Recompute the closure assertions from all receipt-level snapshots and current generated files.
 def generated_now():
  source_paths=matrix['generated_output_pins_before']['sources']
  class_roots=matrix['generated_output_pins_before']['class_trees']
  return {'sources':{p:file_pin(compare,p) for p in source_paths},
          'class_trees':{r:file_pins(compare,Path(r)) for r in class_roots}}
 gen_before=matrix.get('generated_output_pins_before'); gen_after=matrix.get('generated_output_pins_after'); gen_final=matrix.get('generated_output_pins_after_finally')
 now=generated_now()
 if gen_before!=gen_after or gen_before!=gen_final or gen_before!=now or matrix.get('generated_outputs_unchanged') is not True or matrix.get('generated_outputs_unchanged_finally') is not True:
  raise RuntimeError('generated source/driver/compiled-class closure failed')
 for key in ('source_unchanged','source_unchanged_finally','external_inputs_unchanged','local_copies_unchanged','target_absent','target_absent_finally'):
  if matrix.get(key) is not True: raise RuntimeError(f'matrix closure gate false: {key}')
 if matrix.get('source_pins_before')!=base.get('source_pins_before'):
  raise RuntimeError('matrix source-before closure differs from its baseline closure')
 if matrix.get('source_pins_before')!=matrix.get('source_pins_after') or matrix.get('source_pins_before')!=matrix.get('source_pins_after_finally'):
  raise RuntimeError('source closure before/after/finally differs')
 live_source=compare.source_closure(root)
 if live_source!=matrix.get('source_pins_before') or live_source!=base.get('source_pins_before'):
  raise RuntimeError('live source closure differs from captured matrix/baseline source-before pins')
 if (root/'target').exists() or (root/'target').is_symlink():
  raise RuntimeError('workspace target directory exists at independent review time')
 if matrix.get('external_pins_before')!=matrix.get('external_pins_after') or matrix.get('external_pins_before')!=matrix.get('external_pins_after_finally'):
  raise RuntimeError('external file pins before/after/finally differ')
 for pin in matrix.get('external_pins_before',[]): require_pin(compare,pin,'external input')
 if matrix.get('dependency_directory_pins_before')!=matrix.get('dependency_directory_pins_after') or matrix.get('dependency_directory_pins_before')!=matrix.get('dependency_directory_pins_after_finally'):
  raise RuntimeError('dependency directory pins before/after/finally differ')
 for folder,pins in matrix.get('dependency_directory_pins_before',{}).items():
  current={path:file_pin(compare,path) for path in pins}
  if current!=pins: raise RuntimeError(f'dependency directory changed since capture: {folder}')
 if matrix.get('local_copies_before')!=matrix.get('local_copies_after') or matrix.get('local_copies_before')!=matrix.get('local_copies_after_finally'):
  raise RuntimeError('driver/runtime wrapper copies changed')
 for pin in matrix.get('local_copies_before',[]): require_pin(compare,pin,'local driver/runtime copy')
 # Derive counts solely from independently traversed rows.
 failures=[(k,l) for (k,l),c in by_compile.items() if c['exit_code']!=0]
 summary={'status':'independent_review_passed','matrix_receipt':compare.pin(matrix_path),'baseline_receipt':baseline_pin,
  'source_cells':len(source_cells),'source_copies':len(source_copy_pins),'compile_attempts':len(by_compile),
  'compile_successes':len(successful),'compile_failures':len(failures),'failed_compile_selectors':[[list(k),l] for k,l in failures],
  'successful_class_files':sum(len(by_compile[key]['class_tree']) for key in successful),
  'successful_classes_with_dual_parse':sum(len(by_compile[key]['class_facts']) for key in successful),
  'runtime_observations':sum(len(r.get('rows',[])) for r in runtime_rows),'runtime_runs':len(runtime_rows),
  'wrong_root_controls':len(wrongs),'commands':len(commands),'raw_streams':2*len(commands),
  'class_parsed':True,'runtime_rows_checked_against_raw_original_oracles':True,'generated_closure_checked':True}
 out.mkdir(parents=True)
 record={'schema':'cf11-testnestedloops-current-generated-source-matrix-independent-review-v1',**summary}
 (out/'review.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:summary[k] for k in ('status','source_cells','compile_attempts','compile_successes','compile_failures','runtime_runs','wrong_root_controls','commands')}))
 return 0
if __name__=='__main__': raise SystemExit(main())
