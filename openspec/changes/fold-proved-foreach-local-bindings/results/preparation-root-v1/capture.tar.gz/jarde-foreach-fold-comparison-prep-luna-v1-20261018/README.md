# Fold-proved foreach full comparison preparation

Prepared only. No candidate CLI was supplied or built here; none of the collector/reviewer tools were executed. All run directories must be new and supplied later by root. No shared files were changed.

## Reused captures and reviewers

- `original/collect_original.py` is the existing complete `TestNestedLoops.java` capture with one narrow change: `--cli` and `--cli-sha256` are required and validated against the exact candidate. It preserves the full upstream outer+inner Java source and its real JDK 8 class-major boundary. It captures four original JVM oracle runs and eight Jarde API cells (debug/no-debug × child/bundle-child × default/all), so together with the controls capture there are 20 API cells.
- `generated/collect_original_generated.py` is the existing complete generated-source compiler/runtime matrix. It takes the newly captured original receipt and explicit receipt SHA; the added `--expected-cli-sha256` binds that receipt to the root-supplied candidate. It recompiles saved full Jarde/JADX source outputs with both Java 8-target compilers and checks runtime/wrong-CodeSource behavior. It does not reuse old generated class files.
- `controls/collect_controls.py` is the existing complete 19-case control collector. It now requires `--cli-sha256` as well as `--cli`, validates the pair, and records that expected digest. It retains the 4 original compiler/debug profiles, 19 cases, 12 Jarde API cells, complete JADX outputs, and full generated-source compile/runtime matrix.
- `controls/review_controls_structure.py` is the previous independent controls matrix reviewer, repointed only to this adjacent collector and frozen input copies. It checks physical Code/BCIs, APIs, UTF-8 raw maps, source copies, compilation/runtime cells, wrong CodeSource, and preserved refusal/failure cells.
- `generated/review_generated_matrix.py` is the existing independent reviewer for full original generated Java recompilation. Invoke it with the new original receipt and new generated-matrix receipt and their explicit SHA-256 values.
- `review_projection_delta.py` is a small JSON-only delta checker against the accepted prior original and controls receipts. It verifies exact projected-source edits, unchanged raw RecoveryReport text/maps/quality/fallbacks, full-class text changed only in the intended method, same original runtime oracle rows, and the explicit candidate CLI SHA. It supplements, rather than replaces, the structural and generated-matrix reviewers.

The copied Java drivers/fixtures are byte-identical to their accepted prior inputs. The physical class parser, compare parser, guard/scanner, JDK manifest, and JADX tool are reused by their pinned paths; no replacement parser or runner was introduced.

## Exact expected source delta

The comparator transforms only the existing `test` method in each of the eight original API cells. For debug input, exact foreach bindings change from synthetic `iteratorElement17/iteratorElement47` to existing `s1/s2`; for no-debug input they change to existing `local4/local6`. It removes only the separate uninitialized outer declaration, its first assignment, and the inner first declaration. Every remaining byte of the method/class projection must match the result of those exact line edits; it does not normalize whitespace.

In the 12 control API cells, only `declared` is allowed to fold: its `iteratorElement17` head becomes the existing `value`, and only `String value = iteratorElement17;` is removed. Initialized `strings`/`integers` keep their observable `current` declaration, initializer, and body copy. `raw`, `mismatch`, and constructor text stay byte-identical. All control and original `RecoveryReport.text`, `source_map`, `quality`, and `fallbacks` stay byte-identical to the previous final accepted receipts.

## Root execution and review order

Root supplies `CANDIDATE_CLI` and its lowercase 64-character `CANDIDATE_CLI_SHA256` after the real product is built. Use fresh output roots, with the repository target absent and the existing guard enforcing disk/target limits. Run these existing collectors serially:

1. `python3 original/collect_original.py --cli CANDIDATE_CLI --cli-sha256 CANDIDATE_CLI_SHA256 --out ORIGINAL_OUT`
2. `python3 generated/collect_original_generated.py --baseline ORIGINAL_OUT/execution.json --baseline-sha256 ORIGINAL_RECEIPT_SHA256 --expected-cli-sha256 CANDIDATE_CLI_SHA256 --out GENERATED_OUT`
3. `python3 controls/collect_controls.py --cli CANDIDATE_CLI --cli-sha256 CANDIDATE_CLI_SHA256 --out CONTROLS_OUT`

Then run both existing structural reviewers and `review_projection_delta.py` using the old final receipts pinned in `pins.json` plus the three new receipts. Do not convert compile/API refusal into a pass or infer old target totals. In particular preserve: the original full-source javac 8 major-55/52 boundary; the original generated matrix's observed two outer-framework boundary failures; and the controls JADX complete-source `String`-iterator/`Integer`-cast compile failures in all eight compiler/profile cells. The expected controls and original behavior must come from the captured original class, never from hardcoded expected messages. Keep complete outer/child Java sources; no source trimming, hand repair, or target class on driver classpath.
