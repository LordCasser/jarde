import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;

public final class TypedListForEachDriver {
    private static final class TraceList extends AbstractList<Object> {
        final List<Object> data;
        final List<String> events = new ArrayList<String>();
        final String mode;
        int returned;
        TraceList(String mode, Object... values) {
            this.mode = mode;
            this.data = new ArrayList<Object>(Arrays.asList(values));
        }
        public Object get(int i) { return data.get(i); }
        public int size() { return data.size(); }
        public Iterator<Object> iterator() {
            events.add("iterator");
            if (mode.equals("iterator")) throw new IllegalStateException("iterator");
            return new Iterator<Object>() {
                int index;
                public boolean hasNext() {
                    events.add("hasNext:" + index);
                    if (mode.equals("hasNextAfterOne") && returned > 0)
                        throw new IllegalStateException("hasNextAfterOne");
                    return index < data.size();
                }
                public Object next() {
                    events.add("next:" + index);
                    if (mode.equals("nextAfterOne") && returned > 0)
                        throw new IllegalStateException("nextAfterOne");
                    Object v = data.get(index++);
                    returned++;
                    return v;
                }
            };
        }
    }
    private static final class Case {
        final String name, method;
        final List<?> values;
        Case(String n, String m, List<?> v) { name=n; method=m; values=v; }
    }
    private static List<Object> list(Object... xs) { return new ArrayList<Object>(Arrays.asList(xs)); }
    private static String b64(Object x) {
        return Base64.getEncoder().encodeToString(String.valueOf(x).getBytes(StandardCharsets.UTF_8));
    }
    private static String type(Object x) { return x == null ? "null" : x.getClass().getName(); }
    private static void run(String actualRoot, String expectedRoot, Case c) throws Exception {
        URL actual = Paths.get(actualRoot).toRealPath().toUri().toURL();
        URL expected = Paths.get(expectedRoot).toRealPath().toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(new URL[]{actual}, null)) {
            Class<?> target = Class.forName("typedforeach.TypedListForEachCases", true, loader);
            URL code = target.getProtectionDomain().getCodeSource().getLocation();
            if (target.getClassLoader() != loader || !code.toURI().normalize().equals(expected.toURI().normalize()))
                throw new IllegalStateException("wrong CodeSource: " + code + " expected " + expected);
            Field seen = target.getField("seen"), after = target.getField("after");
            seen.set(null, "seed"); after.set(null, "unset");
            Method method = target.getMethod(c.method, List.class);
            String exception = "none";
            try { method.invoke(null, c.values); }
            catch (InvocationTargetException e) { exception = e.getCause().getClass().getName(); }
            Object sv=seen.get(null), av=after.get(null);
            String trace = c.values instanceof TraceList ? String.join(",", ((TraceList)c.values).events) : "";
            System.out.println("CASE name="+c.name+" exception="+exception+" seenType="+type(sv)+" seen="+b64(sv)
                    +" afterType="+type(av)+" after="+b64(av)+" trace="+b64(trace));
        }
    }
    public static void main(String[] args) throws Exception {
        String actual=args[0], expected=args[1];
        List<Case> cases=new ArrayList<Case>();
        cases.add(new Case("strings-empty","strings",list()));
        cases.add(new Case("strings-normal","strings",list("first","last")));
        cases.add(new Case("strings-null-element","strings",list("first",null)));
        cases.add(new Case("strings-wrong-after-success","strings",list("first",Integer.valueOf(9))));
        cases.add(new Case("strings-null-source","strings",null));
        cases.add(new Case("integers-empty","integers",list()));
        cases.add(new Case("integers-normal","integers",list(3,8)));
        cases.add(new Case("integers-null-element","integers",list(3,null)));
        cases.add(new Case("integers-wrong-after-success","integers",list(3,"bad")));
        cases.add(new Case("integers-null-source","integers",null));
        cases.add(new Case("raw-string","raw",list("ok")));
        cases.add(new Case("raw-wrong-after-success","raw",list("ok",Integer.valueOf(2))));
        cases.add(new Case("mismatch-integer-element","mismatch",list(Integer.valueOf(4))));
        cases.add(new Case("mismatch-string-element","mismatch",list("bad")));
        cases.add(new Case("declared-empty","declared",list()));
        cases.add(new Case("declared-normal","declared",list("a","b")));
        cases.add(new Case("trace-iterator-throws","strings",new TraceList("iterator","first")));
        cases.add(new Case("trace-hasNext-after-one","strings",new TraceList("hasNextAfterOne","first","last")));
        cases.add(new Case("trace-next-after-one","strings",new TraceList("nextAfterOne","first","last")));
        for (Case c:cases) run(actual,expected,c);
    }
}
