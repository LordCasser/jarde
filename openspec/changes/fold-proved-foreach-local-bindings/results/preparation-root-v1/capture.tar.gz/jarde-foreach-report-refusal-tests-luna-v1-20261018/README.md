# Private report AST refusal supplement

`tests.patch` adds two tests to the existing `generic_call_ast_projection_tests` module, using its existing `typed_foreach_ast` and `typed_foreach_budget` helpers. The boundary test covers same-name formal, nested foreach binder, lambda capture, LocalAssign, PrefixUpdate, Fallback, and foreign-derived read. Each requires the optional fold proof to refuse while the separate typed foreach edit still projects and the original copy remains. A stale optional binding plan is tested as the same typed-only fallback.

Late budget/cancellation at the fold commit boundary is left pending: no new observer harness was added. Existing public report tests cover cancellation/budget/deadline integration; root should decide whether internal commit-boundary coverage is still needed. No fixtures or shared files changed. Patch is unexecuted; no Cargo/JDK/CLI/network operation ran.
