# Fold-proved foreach own-CI preparation

This private bundle adapts the frozen typed-foreach own-CI v3 collector, verifier, and two-seed native wrapper to the `fold-proved-foreach-local-bindings` leaf. It is preparation only; root must bind the final product SHA, completed CI run ID, two fresh native seed receipts, and source hashes after freeze/commit. No final product or pass total is claimed here.

The CI checker preserves the prior 54 exact gates and adds seven review-confirmed identities: four `jarde_java` report tests, one facade SSA-closure test, and two `structured_list_generic_bodies` public tests. Its resulting inventory is 61 exact gates; per-seed workspace totals remain parsed from the official logs. The native wrapper preserves the nine prior gates, adds the same seven identities, and keeps the historical 385-target baseline. Actual metadata target inventory and per-target counts remain receipt-derived.

The source contract retains the prior 12 own-CI source paths and all three `typed-list-foreach` fixture files. It adds `tests/fixtures/foreach-local-bindings/source/TestNestedLoops.java` as a source pin and the debug/no-debug child class files as fixture pins. Product source hashes are deliberately pending root freeze/commit. The new fixture README is descriptive and outside the binary fixture inventory.

`missing_step_proof.py` is copied unchanged from v3; no log acceptance strategy was modified. The `.diff` files show only collector/verifier/native-wrapper adaptations against v3. `base-v3-pins.json` preserves the frozen v3 pins.

