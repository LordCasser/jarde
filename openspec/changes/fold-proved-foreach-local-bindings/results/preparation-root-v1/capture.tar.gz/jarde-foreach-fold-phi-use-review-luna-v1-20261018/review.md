# Narrow review: ignoring SSA phi-use `None` in foreach local closure

## Conclusion

The proposed rule is sound for this optional source fold, under the exact conditions stated: treat `None` only as a phi-operand bookkeeping use; compare the complete multiset of all `Some(bci)` uses to the exhaustive physical local-read BCIs and AST target-read BCIs; require one physical write at the binding store; and require every local-read fact to retain the exact canonical written `ValueId` and `Definition::Instruction` with no replacement. Keep incomplete code/SSA/AST and any read whose canonical fact is `Phi`, changed, foreign, duplicated or missing as refusal. I found no concrete counterexample within those invariants.

`SsaUse::bci` documents `None` specifically as “for the operand of a phi, which no instruction produces” (`crates/jarde-jvm/src/ssa.rs:203-214`). `Assigner::complete` records phi operands with `record_use(..., None, ...)`; instruction reads use `Some(instruction.bci)` (`ssa.rs:1354 and 1635`). Trivial phi replacement deliberately transfers these phi-operand records to the canonical operand while preserving the phi’s predecessor accounting; therefore a still-instruction-defined stored value can legitimately carry `None` records even though its concrete loads are all enumerated.

The full local-read census is the key safety boundary. The scan populates `SameClassBodyValueSite` for every SSA-backed instruction with any local/stack read or write, and copies each value’s identity, definition, all uses, and replacement state (`src/facade.rs:20060-20132` and `20003-20015`). The closure visits the whole method’s body-value inventory, requires the only slot write to be the selected store, and matches every local load’s canonical value/definition and exact BCI against AST target reads. A non-trivial phi that later supplies a local load yields a Phi-defined local-read fact and fails the exact `ValueId`/`Definition::Instruction` test. A phi use with no later instruction read is only administrative liveness/accounting; it cannot produce an observable read by itself.

## Conditions to preserve in the implementation

- Filter `None` only from `written.uses`; do not treat a local-read fact’s own unresolved/phi `value` or `Definition::Phi` as ignorable.
- Compare sorted `Some` BCIs as a multiset, preserving duplicates until equality. Do not compare only counts, sets, or filtered use count.
- Keep AST target-read BCIs one-to-one with distinct physical local-read instructions and require same owner/complete code.
- Keep `written.replaced_by == None`, exact single-store/write-slot checks, and per-read `replaced_by == None`, definition/value equality, and load-opcode validation.
- Maintain precharges for the number of `written.uses` entries, including phi entries, before iterating/copying; charge allocation for the collected `Some` vector by its upper bound (`uses.len()`) before allocation.

This is not a general rule for dropping phi facts. It is safe here because this proof does not use phi inputs as AST reads: it independently closes every observable local load and rejects a different canonical read definition. If any one of those census/completeness conditions is weakened, ignoring `None` would no longer be justified.

The observed v5 use list supplied by root (`None/57/None/67/77/None/None`) is consistent with three instruction-backed loads plus phi-edge records, but this review does not independently re-run or accept that receipt. No code or tests were run.
