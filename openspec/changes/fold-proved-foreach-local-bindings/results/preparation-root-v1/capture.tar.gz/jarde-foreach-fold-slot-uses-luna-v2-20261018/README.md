# SSA uses closure with phi operands

Additive private patch against current shared `src/facade.rs`. `None` entries in the stored value's use vector are treated as phi operands and ignored for the physical BCI census. The count of known (`Some`) use BCIs must still equal the target AST read count, and the sorted known-use set must equal both physical local-load BCIs and target AST read BCIs. Every physical load remains constrained to the original stored ValueId/Definition, unreplaced status, aload opcode, one local read, zero local writes, and valid load stack output. Unknown/Phi value definitions still refuse.

Tests retain actual positive SSA facts (including their None operands), mutate a known BCI use to None, and add read-fact Phi plus malformed extra-other-slot-read/foreign-slot-write cases. Malformed mutations are internal-only, not legal-JVM evidence. No shared writes or tools ran.
