# Proved foreach local binding fold — v2 private patch

Base: same shared candidate noted by root (`a31f32e35`); this v2 starts from frozen private v1. Patch files are `src/facade.rs` and `crates/jarde-java/src/report.rs`; it does not include unchanged `ast.rs`.

Corrections: count all target Assign nodes so a same-origin literal-RHS duplicate is rejected; charge each site’s local/stack fact lengths before the nested scan and each local-use list before membership checks; charge selected names/types/origin comparisons and visible-ancestor matching before comparing; precharge each target-read origin while preparing the projection plan comparison; and include the optional binding payload in the staged/final typed-edit equality budget.

The report AST metamorphisms cover direct inner Declare promotion, outer blank+Assign at the same BCI, sibling-branch visibility refusal, same-origin literal duplicate assignment refusal, and outside-loop reference refusal. These tests make no legal-JVM evidence claim. Root is preparing facade slot-closure tests separately.

No Cargo, rustfmt, JDK, CLI, or runtime tests were run. This patch is uncompiled and requires root’s targeted proof gates and compile review.
