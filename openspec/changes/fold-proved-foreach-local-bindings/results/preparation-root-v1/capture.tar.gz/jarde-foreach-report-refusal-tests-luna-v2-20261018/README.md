# Private report AST refusal supplement v2

Standalone additive patch based on `/private/tmp/jarde-foreach-fold-impl-luna-v2-20261018/crates/jarde-java/src/report.rs`. Compared with v1, typed-only assertions expect the existing independent typed projection to unwrap the physical cast to the synthetic local, and stale optional-plan mismatch changes `target_name` to a definite nonmatching value instead of popping an already-empty target-read list. Covers same-name formal, nested foreach binder, lambda capture, LocalAssign, PrefixUpdate, Fallback, foreign-derived read, and stale optional-plan fallback. Refusal cases keep the typed header and original local copy.

Late budget/cancellation at the fold commit boundary remains pending; no observer framework was added. Unexecuted, no shared edits or toolchain use.
