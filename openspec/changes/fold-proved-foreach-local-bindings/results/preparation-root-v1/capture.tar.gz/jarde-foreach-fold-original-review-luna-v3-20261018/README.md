# Original baseline independent audit v3

The prior prepared audit v1 passed its receipt/raw/artifact/BCI/map/runtime checks. A stricter independent cross-binding extension was added. Its v2 run failed on the checker itself: `strict_checks.py` read the runtime wrapper from argv index 1, which is `-B`; the saved command places the wrapper at argv index 2. The v2 failure and raw stderr are preserved in the copied `results/` folder.

v3 changes that strict check to argv index 2 and reruns the same fixed receipt, with no acceptance condition removed.
