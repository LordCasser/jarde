# Original baseline independent audit v4

The original audit v1 passed. Strict-check v2 failed because it read the runtime wrapper at the wrong argv index; v3 fixed that runtime check but repeated the same index mistake for the wrong-root control. Both failure outputs are retained in the prior version directories. v4 uses argv index 2 for the wrapper and keeps all checks.
