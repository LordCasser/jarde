# Folded foreach fixture / coverage cross-check

Read-only code-review evidence for `fold-proved-foreach-local-bindings`. No repository files were changed and no parser, test, Cargo, JDK, CLI, Git mutation, or network operation was run. Counts are intentionally not estimated; root must measure the actual classfile delta with the existing reader census.

## Fixture inputs and inventories

The proposed public patch adds two distinct physical `.class` files for the same internal class `jadx/tests/integration/loops/TestNestedLoops$TestCls`: the debug and no-debug inputs. Their frozen source pins are in `/private/tmp/jarde-foreach-fold-public-tests-luna-v1-20261018/fixture-pins.json`:

- debug: 1,356 bytes, SHA-256 `4741538cc0ef1ba378cca4fccc8505007956a6b14520a1808c3874d7ea167e2c`
- no-debug: 917 bytes, SHA-256 `f557e2072c25b68dc89199ae3a75e045f6ebdf3e80d022f851fc0094b21d5807`
- complete upstream Java input: 876 bytes, SHA-256 `4897fd18a15fce6e0abb40dc8afc6c7a3fa9f16e617f3c7e5e88072f6a37309e`

The reader census is `crates/jarde-reader/src/classfile.rs::repository_class_fixtures_validate_without_false_target_rejections` (currently asserts `(1301, 5751, 630, 4050, 14)` for classes, Code bodies, handlers, non-handler targets, and jsr instructions). `class_fixture_paths()` recursively discovers every `.class` below `tests/fixtures`, so the two class files will enter the census automatically once installed. Re-measure every tuple member from the full walk; do not add a guessed delta or alter earlier ledger entries.

The independent corpus inventory is `tests/p5_corpus_fingerprint.rs::corpus_files_match_the_recorded_fingerprint`, with its rendered records in `tests/fixtures/corpus-fingerprint.json`. The recursive corpus walk includes `.class` and `.java` files under `tests/fixtures`, so all three proposed fixture files need exact new manifest rows (bytes and recorded digest) if copied into the repository. The recovery dimension's explicit `DIMENSIONS` carriers at `tests/p5_corpus_fingerprint.rs` should reference the two classfiles; include the Java source only if root determines it is an intended recovery carrier. Do not edit existing manifest rows or P5 thresholds. The proposed fixture directory is `tests/fixtures/foreach-local-bindings/{debug,none,source}/`.

No separate golden-source inventory is implicated by this public patch: its expectations are in `tests/structured_list_generic_bodies.rs` and the fixed input bytes are the fixtures above. Retain all existing raw/generic fixtures and expectations.

## Refusal-boundary coverage to cross-check

The OpenSpec 2.3 boundary list is broader than the public positive regression. Existing public controls include nearby raw alias/reassignment/wildcard refusal (`nearby_list_controls_refuse_only_unproved_generic_projections`), pre-cancel, analysis-budget stop, and late-deadline atomicity. These preserve raw recovery text/maps and reject partial generic publication. The new positive debug/no-debug case and declared-only expected fold do not alone establish the following implementation boundaries; confirm internal proof tests cover them:

- an extra write or read of the candidate local outside the loop, including read before/after the loop;
- capture/foreign binder cases: same-name formal, nested foreach/catch/resource/lambda binder, or a sibling declaration;
- sibling `if/else`, `switch`, `catch/finally` declaration must not be treated as a lexical ancestor;
- wrong-source/duplicate AST nodes and incomplete/non-closed phi evidence must refuse folding while retaining reliable typed foreach heads;
- cancellation, budget stop, and deadline at the fold commit boundary must publish neither a folded declaration nor partial per-method/class projection.

The public patch's positive checks should continue to assert both nested heads retain their original local names, body copies remain, only the proven empty outer declaration disappears, unrelated body statements stay byte-for-byte/textually stable, default/all/no-rule-details agree, and raw method text/source map remain the unprojected recovery artifact. This note is a cross-check list, not an assertion that any missing implementation test has failed.

## Correction and additive positive-gold review

Correction to the final paragraph above: accepted folded positives remove the synthetic local-copy statements; refusal controls preserve the original copies. The positive assertion list below is supported by the Java sources and current test references, but the proposed assertions are unexecuted and root must validate formatting/results with the real implementation.

The existing `FIXED` (`UpstreamNestedLoops`), `DISTINCT_STRING`, and `DISTINCT_INTEGER` Java sources each contain the same nested foreach pattern: outer/inner locals are the foreach targets and have no other declaration semantics. Their corresponding tests currently require both synthetic copies via `assert_typed_foreach_copies`; these are positive cases under the no-whitelist fold contract. The additive private patch `positive-fold-update.patch` changes only those assertions to require the original typed headers and absence of self-copy statements. Existing body assertions (`add`, `remove(Object)`, trailing clear/effects), typed declarations, physical raw Object headers/casts, UTF-8 maps, and full physical-BCI mapping remain untouched. The fixed class's default/all/no-RuleDetails equality and raw text/map equality checks are unchanged.

The previously identified typed-list fixtures with initialization and visibility before/after the loop are not included in this proposed fold update; they remain refusal controls where the local has reads beyond the loop proof boundary. Do not alter their assertions absent a separate proof.
