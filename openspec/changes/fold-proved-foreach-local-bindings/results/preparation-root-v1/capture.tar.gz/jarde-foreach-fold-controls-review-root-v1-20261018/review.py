import hashlib,json,subprocess,sys
from pathlib import Path
OUT=Path(__file__).parent
RECEIPT=Path('/private/tmp/jarde-foreach-fold-controls-root-v1-20261018/execution.json')
CHECKER=Path('/private/tmp/jarde-foreach-fold-comparison-prep-luna-v3-20261018/controls/review_controls_structure.py')
CLI='c688920cac70ee9e46681672ebaaba5df2948c5ef5b5f262d006548ca1f83ebe'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
argv=[sys.executable,'-B',str(CHECKER),'--receipt',str(RECEIPT),'--expected-cli-sha256',CLI]
r=subprocess.run(argv,capture_output=True);(OUT/'stdout.raw').write_bytes(r.stdout);(OUT/'stderr.raw').write_bytes(r.stderr);assert r.returncode==0 and not r.stderr
a=json.loads(r.stdout);d=json.loads(RECEIPT.read_text());assert a['integrity_findings']==[]
f=a['failed_cells'];assert len(f)==8 and all(x['kind']=='generated-compile' and x['cell'][0]=='jadx' and x['exit_code']==1 for x in f)
assert a['counts']=={'commands':137,'original_profiles':4,'original_vm':8,'original_case_rows':152,'api_cells':12,'jadx_cells':4,'generated_compiles':32,'generated_compile_successes':24,'generated_compile_failures':8,'generated_vm':48,'generated_wrong_root':24,'raw_oracle_equal':True}
failed=[x for x in d['generated_compiles'] if x['exit_code']!=0];assert len(failed)==8
for x in failed:
 p=Path(x['streams']['stderr']['path']);pinx=pin(p);assert pinx==x['streams']['stderr'];b=p.read_bytes();assert b'java.lang.String' in b and b'java.lang.Integer' in b
for x in d['jarde_cells']:
 api=json.loads(Path(x['report']['path']).read_text());assert api['outcome']=='performed' and api['execution']['status']=='complete'
 assert all(m['outcome']['kind']=='recovered' and m['outcome']['report']['quality']=='structured' and not m['outcome']['report']['fallbacks'] for m in api['methods'])
assert len(d['generated_runs'])==48 and all(x['exit_code']==0 and x['matches_original'] for x in d['generated_runs'])
result={'status':'root-controls-accepted','receipt':pin(RECEIPT),'checker':pin(CHECKER),'argv':argv,'exit_code':r.returncode,'stdout':pin(OUT/'stdout.raw'),'stderr':pin(OUT/'stderr.raw'),'counts':a['counts'],'generated_case_rows':48*19,'preserved_jadx_compile_failures':f,'candidate_cli_sha256':CLI}
(OUT/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'generated_vm':48,'generated_cases':912,'preserved_jadx_failures':8}))
