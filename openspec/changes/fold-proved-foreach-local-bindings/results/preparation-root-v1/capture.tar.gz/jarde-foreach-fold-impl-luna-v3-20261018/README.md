# Proved foreach local binding fold — v3 private patch

Base: same shared candidate noted by root (`a31f32e35`); v3 starts from frozen v2. Patch touches only `src/facade.rs` and `crates/jarde-java/src/report.rs`.

Fixes in this revision: one common typed-edit match/origin update after folding (no double count or moved value); reference names are borrowed directly from `Type::Reference` instead of calling `.spell()`; visible blank declaration comparisons are charged per item before comparing; `written.uses` must match the target-read count before allocation, and stored uses allocation/sorting is charged; each retained visible-vector clone has proportional AnalysisSteps precharged.

Report AST tests cover inner Declare promotion, outer same-BCI blank+Assign, sibling visibility refusal, same-origin literal duplicate assignment refusal, and outside-loop reference refusal. Root is preparing facade slot-closure tests separately. These tests do not claim legal-JVM evidence.

No Cargo, rustfmt, JDK, CLI, or runtime tests were run. This patch is uncompiled and needs root's targeted proof gates and compile review.
