#!/usr/bin/env python3
"""Read-only independent audit for the captured original Java baseline."""
import argparse,hashlib,importlib.util,json,sys
from pathlib import Path
BASE=Path('/private/tmp/jarde-typed-foreach-original-final-root-v1-20261018'); ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
RHS='433b6a723137adb4aed904b2c7935079821def5b1b91f1593630c224bc73f439'; INNER='jadx/tests/integration/loops/TestNestedLoops$TestCls'; OUTER='jadx/tests/integration/loops/TestNestedLoops'
WANT=[('<init>','()V'),('test','(Ljava/util/List;Ljava/util/List;)V')]
def need(v,m):
    if not v: raise ValueError(m)
def digest(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()
def blob(r,limit=1<<30):
    p=Path(r['path']); need(p.is_file() and p.stat().st_size<=limit,'missing/large '+str(p)); b=p.read_bytes(); need(len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],'pin '+str(p)); return b
def module(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
def walkpins(x):
    if isinstance(x,dict):
        if {'path','bytes','sha256'}<=x.keys(): blob(x)
        for v in x.values(): walkpins(v)
    elif isinstance(x,list):
        for v in x: walkpins(v)
def main():
    global BASE, RHS
    ap=argparse.ArgumentParser(); ap.add_argument('--baseline',type=Path,required=True); ap.add_argument('--baseline-sha256',required=True); ap.add_argument('--write',type=Path,required=True); cli_args=ap.parse_args(); BASE=cli_args.baseline.resolve(); RHS=cli_args.baseline_sha256; out=cli_args.write.resolve(); need(not out.exists(),'output exists')
    rp=BASE/'execution.json'; need(digest(rp)==RHS,'receipt pin'); d=json.loads(rp.read_text()); need(d['status']=='captured-pending-independent-review' and d['root']==str(ROOT),'receipt state/root')
    cs=d['commands']; need(len(cs)==20 and [c['index'] for c in cs]==list(range(1,21)),'command census'); need(sum(s['bytes'] for c in cs for s in c['streams'].values())<5<<30,'raw limit')
    for c in cs:
        need(c['exit_code']==(1 if c['index'] in (1,9) else 0) and c['guard_stop'] is None and c['free_bytes_after']>=5<<30 and c['peak_target_bytes']<=1<<30,'command guard/exit')
        for s in c['streams'].values(): blob(s)
    for a,b in [('source_pins_before','source_pins_after'),('source_pins_before','source_pins_after_finally'),('external_input_pins_before','external_input_pins_after'),('external_input_pins_before','external_input_pins_after_finally'),('local_copy_pins_before','local_copy_pins_after'),('local_copy_pins_before','local_copy_pins_after_finally')]: need(d[a]==d[b],a+' differs')
    for k in ('source_pins_before','external_input_pins_before','local_copy_pins_before'): walkpins(d[k])
    need(all(d[k] for k in ('source_unchanged','source_unchanged_finally','external_inputs_unchanged','local_copies_unchanged','local_copies_unchanged_finally','target_absent','target_absent_finally')),'guard flags')
    blob(d['compare']); blob(d['physical_parser']); cmp=module(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','cmp_audit'); phy=module('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py','phy_audit')
    need(len(d['source_profiles'])==2 and {p['profile'] for p in d['source_profiles']}=={'debug','no-debug'},'profile grid')
    need(d['javac8_full_source_boundary']['class_tree']=={} and b'55.0' in blob(cs[0]['streams']['stderr']) and b'52.0' in blob(cs[0]['streams']['stderr']),'javac8 harness boundary')
    need(blob(cs[9]['streams']['stdout']).strip()==b'1.5.6','JADX version')
    facts={}
    for p in d['source_profiles']:
        need(p['exit_code']==0 and set(p['class_tree'])=={INNER+'.class',OUTER+'.class'},'profile class census'); seen={}
        cr=Path(p['class_root']); need({q.relative_to(cr).as_posix() for q in cr.rglob('*.class')}==set(p['class_tree']),'live full class tree')
        for rel,r in p['class_tree'].items():
            b=blob(r); path=Path(r['path']); a=cmp.parse_class(path); z=phy.parse_class_file(b); need(a['class_name']==z['class_name'] and a['major']==z['major'] and a['methods']==z['methods'] and sorted((f['name'],f['descriptor'],f['access']) for f in z['fields'])==sorted(a['fields']),'parser mismatch')
            for m in z['methods']:
                code=m.get('code'); need(code and phy.decode_bcis(bytes.fromhex(code['code_hex']))==code['bcis'],'instruction decode')
                starts=set(code['bcis'])|{code['code_length']}
                need(all(start in starts and end in starts and 0<=start<end<=code['code_length'] and handler in set(code['bcis']) for start,end,handler,catch in code['rows']),'handler boundary')
            a['access']=z['access']; seen[a['class_name']]=a
            saved=p['target_facts'] if a['class_name']==INNER else p['outer_facts']
            need((a['class_name'],a['major'],a['access'],sorted((f['name'],f['descriptor'],f['access']) for f in z['fields']),[(m['name'],m['descriptor'],m['access'],m['code']['code_hex'],m['code']['bcis']) for m in z['methods']])==(saved['class_name'],saved['major'],saved['access'],sorted(tuple(f) for f in saved['fields']),[(m['name'],m['descriptor'],m['access'],m['code']['code_hex'],m['code']['bcis']) for m in saved['methods']]),'saved class facts mismatch')
        # Compare both saved profile inventories via receipt pins and target facts.
        o=seen[OUTER]; need(o['major']==52 and [(m['name'],m['descriptor']) for m in o['methods']]==[('<init>','()V'),('test','()V')] and not o['fields'],'outer inventory')
        t=seen[INNER]; need(t['major']==52 and sorted((m['name'],m['descriptor']) for m in t['methods'])==WANT and not t['fields'],'target identity')
        facts[p['profile']]=seen
    for p in d['source_profiles']:
        need(p['target_facts']['path']==str(Path(p['class_root'])/(INNER+'.class')),'target path')
    need(len(d['original_runtime'])==4 and {(r['profile'],r['runtime']) for r in d['original_runtime']}=={(p,v) for p in ('debug','no-debug') for v in ('javac8','javac23')} and d['runtime_semantic_agreement'],'runtime matrix'); outs=[]
    need(not (ROOT/'target').exists(),'live target absent')
    driver_files={q.name for q in (BASE/'driver-classes').rglob('*.class')}; need(driver_files=={'TestNestedLoopsDriver.class','TestNestedLoopsDriver$Case.class','TestNestedLoopsDriver$Observation.class'},'driver inventory'); walkpins(d['driver_classes'])
    for r in d['original_runtime']:
        run=cs[r['command']-1]; av=run['argv']; cp=av[av.index('-cp')+1].split(':'); need(cp==[str(BASE/'driver-classes')] and av[-2:]==[r['target_root'],r['target_root']],'runtime classpath/root binding')
        need(av[4]==d['jdk_manifest']['tools'][r['runtime']]['java']['path'] and '-Xverify:all' in av and av[-3]=='TestNestedLoopsDriver' and r['target_root']==str(BASE/r['profile']/'classes'),'actual runtime VM/root')
        b=blob(r['stdout']); need(r['exit_code']==0 and not blob(r['stderr']) and len(r['rows'])==8,'runtime result'); lines=b.decode().splitlines(); need(lines==[x['raw'] for x in r['rows']],'saved rows'); outs.append(lines)
    need(all(x==outs[0] for x in outs) and d['wrong_root_control']['rejected'] and b'wrong CodeSource:' in blob(d['wrong_root_control']['stderr']),'runtime/code source')
    manifest=json.loads((ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json').read_text())
    need(len(d['jarde_cells'])==8,'API grid'); groups={}; owners={}
    for c in d['jarde_cells']:
        cmd=cs[c['command']-1]; need(c['exit_code']==0 and cmd['label'].startswith('jarde-'),'API command'); raw=blob(c['report']); need(raw==blob(cmd['streams']['stdout']),'API raw stdout/report'); api=json.loads(raw); need(api['execution']['status']=='complete' and len(api['methods'])==2,'API complete/methods')
        trees=facts[c['profile']]; target=trees[INNER]; identities=[]; summaries=[]
        for x in api['methods']:
            it=x['item']['identity']; name=bytes(it['name']).decode(); desc=bytes(it['descriptor']).decode(); identities.append((name,desc)); need(it['owner']==api['class'],'item owner')
            m=next(m for m in target['methods'] if (m['name'],m['descriptor'])==(name,desc)); rr=x['outcome']['report']; need(x['outcome']['kind']=='recovered' and rr['quality']=='structured' and not rr['fallbacks'],'method quality')
            body=rr['text']; bt=body.encode(); allowed=set(m['code']['bcis']); got=set(); bounds={0,len(bt)}
            bounds.update(i for i,b in enumerate(bt) if b&0xc0!=0x80)
            for seg in rr['source_map']['segments']:
                need(0<=seg['start']<seg['end']<=len(bt) and seg['start'] in bounds and seg['end'] in bounds,'UTF8 map span')
                org=seg['origin'];
                for o in [org.get('primary'),*org.get('derived',[])]:
                    if o:
                        need(o['method']['owner']==api['class'] and bytes(o['method']['name']).decode()==name and bytes(o['method']['descriptor']).decode()==desc and o['bci'] in allowed,'map origin'); got.add(o['bci'])
            need(got==allowed,'map Code BCI coverage'); summaries.append((name,desc,x['text'],body,rr['quality'],rr['fallbacks'],rr['source_map']))
        need(sorted(identities)==WANT and api['text']==Path(c['whole_source']['path']).read_text() and blob(c['whole_source']).decode()==api['text'],'API whole source/identity')
        groups.setdefault((c['profile'],c['input_form']),{})[c['evidence']]=(api['text'],summaries)
        owners.setdefault((c['profile'],c['input_form']),set()).add(json.dumps(api['class']['class_bytes'],sort_keys=True))
    need(len(groups)==4 and all(set(v)=={'default','all'} for v in groups.values()),'API pair matrix')
    for v in groups.values(): need(v['default']==v['all'],'default/all projected evidence differs')
    for (prof,form),v in owners.items():
        if form=='child': need(v==owners[(prof,'bundle-child')],'owner BLAKE3 cross-input mismatch')
    need(len(d['jadx_outputs'])==2 and {(j['compiler_profile'],j['display_profile']) for j in d['jadx_outputs']}=={('debug','default'),('no-debug','default')},'JADX source grid')
    for o in d['jadx_outputs']:
        need(o['exit_code']==0 and len(o['sources'])==1,'JADX complete output'); blob(o['sources'][0])
    result={'status':'passed','receipt_sha256':RHS,'commands':20,'raw_streams':40,'runtime_runs':4,'runtime_cases':32,'api_cells':8,'jadx_outputs':2,'classes':4}
    out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result))
if __name__=='__main__':
    try: main()
    except Exception as e: print('AUDIT FAILED:',e,file=sys.stderr); raise
