#!/usr/bin/env python3
"""Read-only independent structural review for typed-list-foreach-controls-matrix-v1."""
import argparse, hashlib, importlib.util, json, re, sys, zipfile
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
COLLECTOR=Path('/private/tmp/jarde-foreach-fold-comparison-prep-luna-v1-20261018/controls/collect_controls.py')
PREP=Path('/private/tmp/jarde-foreach-fold-comparison-prep-luna-v1-20261018/controls/controls-input')
TARGET=PREP/'TypedListForEachCases.java'; DRIVER=PREP/'TypedListForEachDriver.java'
TARGET_SHA='e38e258bc8cb57b1bf1cedbe2100a72a5ece84fc37d4bcf37d1297b25392eaf7'
DRIVER_SHA='9c40cd3b2a0938ed392174c2713de5e627ae9d8376d3804c5479131eed5beed7'
COMPARE=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'; CH='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'; GH='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'; SH='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
MANIFEST=ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'; MH='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py'); PH='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
INTERNAL='typedforeach/TypedListForEachCases'; PROFILES=('javac8-debug','javac8-no-debug','javac23-debug','javac23-no-debug'); LEGS=('javac8','javac23'); VMS=LEGS
EVIDENCE=('default','all','essential'); CASES=('strings-empty','strings-normal','strings-null-element','strings-wrong-after-success','strings-null-source','integers-empty','integers-normal','integers-null-element','integers-wrong-after-success','integers-null-source','raw-string','raw-wrong-after-success','mismatch-integer-element','mismatch-string-element','declared-empty','declared-normal','trace-iterator-throws','trace-hasNext-after-one','trace-next-after-one')
def sha(b): return hashlib.sha256(b).hexdigest()
def module(p,n):
 s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--receipt',type=Path,required=True); ap.add_argument('--expected-cli-sha256',required=True); a=ap.parse_args()
 report=json.loads(a.receipt.read_text()); findings=[]; failed=[]
 def need(ok,msg):
  if not ok: findings.append(msg)
 def data(pin,label):
  p=Path(pin.get('path','')); need(p.is_absolute() and p.is_file(),f'{label}: missing artifact {p}')
  if not p.is_file(): return b''
  b=p.read_bytes(); need(len(b)==pin.get('bytes') and sha(b)==pin.get('sha256'),f'{label}: pin changed'); return b
 def walk(x,label='receipt'):
  if isinstance(x,dict):
   if {'path','bytes','sha256'}<=x.keys(): data(x,label)
   else:
    for k,v in x.items(): walk(v,f'{label}.{k}')
  elif isinstance(x,list):
   for i,v in enumerate(x): walk(v,f'{label}[{i}]')
 def loadpin(p,h,label): need(p.is_file() and sha(p.read_bytes())==h,f'{label} pin mismatch')
 loadpin(COMPARE,CH,'compare'); loadpin(GUARD,GH,'guard'); loadpin(SCANNER,SH,'scanner'); loadpin(MANIFEST,MH,'JDK manifest'); loadpin(PARSER,PH,'physical parser')
 collector_copy=Path(report.get('output',''))/'collector.py'; need(collector_copy.is_file() and collector_copy.read_bytes()==COLLECTOR.read_bytes(),'captured collector missing/differs')
 for p,h in ((TARGET,TARGET_SHA),(DRIVER,DRIVER_SHA)): loadpin(p,h,str(p))
 cmp=module(COMPARE,'typed_review_compare'); physical=module(PARSER,'typed_review_physical')
 need(report.get('baseline',{}).get('sha256')=='4f48e3b14738cb4d3746763290788f525bba4bb1a1a3d47aebcf0111e6f8d482','baseline receipt pin differs'); need(report.get('schema')=='typed-list-foreach-controls-matrix-v1','wrong receipt schema'); need(report.get('status')=='captured-pending-review','receipt is not complete pending-review')
 cli=report.get('cli',{}); need(cli.get('sha256','').lower()==a.expected_cli_sha256.lower(),'CLI receipt digest differs from requested digest'); need(re.fullmatch('[0-9a-fA-F]{64}',a.expected_cli_sha256) is not None,'expected CLI digest is not SHA-256'); need(cli.get('sha256')==a.expected_cli_sha256.lower(),'CLI hash format/value mismatch')
 need(report.get('products_unchanged') is True and report.get('products_unchanged_finally') is True,'protected artifacts changed'); need(report.get('source_unchanged') is True and report.get('source_unchanged_finally') is True,'source closure changed'); need(report.get('external_inputs_unchanged') is True and report.get('local_copies_unchanged') is True,'external/local copy changed'); need(report.get('target_absent') is True and report.get('target_absent_finally') is True and not (ROOT/'target').exists() and not (ROOT/'target').is_symlink(),'target is not absent')
 for before,after in [('source_pins_before','source_pins_after'),('source_pins_before','source_pins_after_finally'),('external_pins_before','external_pins_after'),('external_pins_before','external_pins_after_finally'),('local_copies_before','local_copies_after'),('local_copies_before','local_copies_after_finally'),('protected_products_before_final','protected_products_after'),('protected_products_before_final','protected_products_after_finally')]: need(report.get(before)==report.get(after),f'{before} != {after}')
 walk(report)
 try: need(cmp.source_closure(ROOT)==report.get('source_pins_after_finally'),'current source closure differs from final receipt')
 except Exception as e: need(False,'cannot recheck source closure: '+repr(e))
 commands=report.get('commands',[]); need([x.get('index') for x in commands]==list(range(1,len(commands)+1)),'command stream indices are not contiguous')
 for c in commands:
  need(c.get('guard_stop') is None and c.get('peak_target_bytes',1<<62)<=1<<30 and c.get('free_bytes_after',0)>=5*1024**3,f"resource guard failed: {c.get('label')}")
  need(set(c.get('streams',{}))=={'stdout','stderr'},f"streams missing: {c.get('label')}"); need(c.get('cwd')==str(ROOT),f"unexpected command cwd: {c.get('label')}")
  if c.get('argv',[]) and 'class-source' in c['argv']:
   need(Path(c['argv'][0]).resolve()==Path(cli.get('path','/missing')).resolve(),f"wrong CLI in {c.get('label')}")
  for stream in c.get('streams',{}).values(): data(stream,f"command {c.get('index')} stream")
 for run in [*report.get('original_runs',[]),*report.get('original_wrong_root',[]),*report.get('generated_runs',[]),*report.get('generated_wrong_root',[])]:
  command=next((x for x in commands if x.get('index')==run.get('command')),{}); argv=command.get('argv',[])
  need('-Xverify:all' in argv and '-cp' in argv,'runtime verification/classpath flag absent')
  if '-cp' in argv:
   i=argv.index('-cp'); expected_cp=str((Path(report['output'])/'driver-classes').resolve())
   need(argv[i+1]==expected_cp and argv[i+2]=='TypedListForEachDriver','runtime classpath is not driver-only')
   need(argv[-2:]==[run.get('actual_root'),run.get('expected_root')],'runtime roots differ from actual argv')
   need(run.get('application_classpath')==[expected_cp],'runtime classpath receipt differs')
  if 'rejected' not in run: need(run.get('actual_root')==run.get('expected_root'),'successful run loaded unexpected root')
 need(not (Path(report['output'])/'driver-classes'/ (INTERNAL+'.class')).exists(),'target leaked onto driver classpath')
 profiles=report.get('source_profiles',[]); need([x.get('profile') for x in profiles]==list(PROFILES),'original profile set/order incomplete')
 def inventory(root):
  root=Path(root); result={}
  for p in sorted(root.rglob('*.class')):
   x=cmp.parse_class(p); y=physical.parse_class_file(p.read_bytes()); need((x['class_name'],x['major'])==(y['class_name'],y['major']),'class header parsers disagree: '+str(p))
   need(sorted(x['fields'])==sorted((f['name'],f['descriptor'],f['access']) for f in y['fields']),'field parsers disagree: '+str(p)); need(sorted((m['name'],m['descriptor'],m['access']) for m in x['methods'])==sorted((m['name'],m['descriptor'],m['access']) for m in y['methods']),'method parsers disagree: '+str(p))
   for m,n in zip(x['methods'],y['methods']):
    if m['code'] is None: need(n['code'] is None,'Code presence differs: '+str(p)); continue
    z=m['code']; q=n['code']; raw=bytes.fromhex(z['code_hex']); need(q is not None and z['code_hex']==q['code_hex'] and z['code_length']==q['code_length'] and z['bcis']==q['bcis']==physical.decode_bcis(raw),'actual Code/BCI parsers disagree: '+str(p))
   result[p.relative_to(root).as_posix()]=(x['class_name'],x['major'],y['access'],tuple(sorted(x['fields'])),tuple(sorted((m['name'],m['descriptor'],m['access']) for m in x['methods'])))
  return result
 orig={}; original_invs=[]
 for p in profiles:
  root=Path(p.get('class_root','')); inv=inventory(root); original_invs.append(inv); orig[p['profile']]=inv; rec=p.get('class_inventory')
  need(rec is not None and json.dumps(inv,sort_keys=True)==json.dumps(rec,sort_keys=True),'original inventory differs from receipt '+p['profile']); target=root/(INTERNAL+'.class'); need(target.is_file(),'original target absent '+p['profile'])
  if target.is_file():
   f=cmp.parse_class(target); access=physical.parse_class_file(target.read_bytes())['access']; need(f['major']==52 and access==0x21,'target class access/version differs '+p['profile'])
   need({(m['name'],m['descriptor'],m['access']) for m in f['methods']}=={('<init>','()V',1),*((n,'(Ljava/util/List;)V',9) for n in ('strings','integers','raw','mismatch','declared'))},'target method inventory differs '+p['profile']); need(set(f['fields'])=={('seen','Ljava/lang/Object;',9),('after','Ljava/lang/Object;',9)},'target fields differ '+p['profile'])
  tree=p.get('class_tree',{}); need(set(tree)==set(inv),'original class tree incomplete '+p['profile'])
  for rel,pin in tree.items(): need(Path(pin['path']).resolve()==(root/rel).resolve(),'original class path differs '+rel); data(pin,'original class '+rel)
 need(len(profiles)==4 and all(x==original_invs[0] for x in original_invs),'original four-profile inventories differ'); driver=report.get('driver_compile',{}); drroot=Path(report.get('output',''))/'driver-classes'; di=inventory(drroot) if drroot.exists() else {}
 need(driver.get('exit_code')==0 and set(driver.get('class_facts') or {})==set(di)=={Path(x['path']).relative_to(drroot).as_posix() for x in driver.get('classes',[])},'driver compile/class inventory incomplete'); runs=report.get('original_runs',[]); need(len(runs)==8 and {(x.get('profile'),x.get('vm')) for x in runs}=={(p,v) for p in PROFILES for v in VMS},'original eight VM cells incomplete'); oracle={}; raw_oracles=[]
 for r in runs:
  row=next((x for x in commands if x.get('index')==r.get('command')),{}); out=data(row.get('streams',{}).get('stdout',{}),'original stdout') if row else b''; need(row.get('exit_code')==r.get('exit_code'),'original runtime exit differs from command')
  if r.get('exit_code')==0:
   lines=out.decode('utf8').splitlines(); names=[(re.search(r'CASE name=([^ ]+)',x) or [None,''])[1] for x in lines]; need(names==list(CASES) and r.get('rows')==lines,f"original cases malformed {r.get('profile')}/{r.get('vm')}"); oracle[(r['profile'],r['vm'])]=out; raw_oracles.append(out)
  else: failed.append({'kind':'original-runtime','profile':r.get('profile'),'vm':r.get('vm'),'exit_code':r.get('exit_code')})
 need(len(oracle)==8 and len(set(raw_oracles))==1,'original raw stdout oracle differs/incomplete'); failed += [{'kind':'original-compile','profile':p.get('profile'),'exit_code':p.get('exit_code')} for p in profiles if p.get('exit_code')!=0]
 wrong=report.get('original_wrong_root',[]); need(len(wrong)==4 and {x.get('profile') for x in wrong}==set(PROFILES),'original wrong-root matrix incomplete')
 for x in wrong:
  row=next((r for r in commands if r.get('index')==x.get('command')),{}); err=data(row.get('streams',{}).get('stderr',{}),'wrong-root stderr') if row else b''; need(row.get('exit_code')==x.get('exit_code'),'original wrong-root exit differs from command')
  if not(x.get('exit_code')==1 and b'wrong CodeSource:' in err and x.get('rejected') is True and x.get('actual_root')!=x.get('expected_root')): failed.append({'kind':'original-wrong-root','profile':x.get('profile'),'exit_code':x.get('exit_code')})
 apis=report.get('jarde_cells',[]); jadx=report.get('jadx_cells',[]); docs={}; need(len(apis)==12 and {(x.get('profile'),x.get('evidence')) for x in apis}=={(p,e) for p in PROFILES for e in EVIDENCE},'API 4x3 matrix incomplete'); need(len(jadx)==4 and {x.get('profile') for x in jadx}==set(PROFILES),'JADX four-cell matrix incomplete'); cells={('jarde',x['profile'],x['evidence']):x for x in apis}; cells.update({('jadx',x['profile'],'source'):x for x in jadx})
 for c in apis:
  raw=data(c.get('report',{}),'API report'); doc=json.loads(raw); need(c.get('api_status')==doc.get('execution',{}).get('status'),'API status differs from JSON'); row=next((r for r in commands if r.get('index')==c.get('command')),{}); need(row.get('exit_code')==c.get('exit_code'),'API exit differs from command')
  need(c.get('source_ready') is True and c.get('exit_code')==0 and row.get('exit_code')==0,'API cell is not a successful source-ready capture')
  need(doc.get('execution',{}).get('status')=='complete' and doc.get('outcome')=='performed' and len(doc.get('methods',[]))==6,'API report is not complete/performed with all six methods')
  if c.get('source_ready'):
   docs[(c['profile'],c['evidence'])]=doc
   need(doc.get('execution',{}).get('status')=='complete' and doc.get('outcome')=='performed' and len(doc.get('methods',[]))==6,'class-source API incomplete/low quality')
   whole=doc.get('text','').encode('utf8'); need(data(c.get('whole_source',{}),'whole source')==whole and bool(whole.strip()),'whole source differs from API text')
   if c.get('evidence') in ('default','all'):
    for m in doc.get('methods',[]):
     rr=m.get('outcome',{}).get('report',{}); text=rr.get('text'); sm=rr.get('source_map')
     need(isinstance(text,str) and isinstance(sm,dict) and isinstance(sm.get('segments'),list),'default/all raw method map missing')
     if not isinstance(text,str) or not isinstance(sm,dict) or not isinstance(sm.get('segments'),list): continue
     need(rr.get('quality')=='structured','raw method quality is not structured')
     bs=text.encode('utf8'); bounds={0,len(bs),*(i for i,b in enumerate(bs) if b&0xC0!=0x80)}
     try: mk=cmp.method_key(m); ident=m['item']['identity']; tc=cmp.parse_class(Path(next(x for x in profiles if x['profile']==c['profile'])['class_root'])/(INTERNAL+'.class')); allowed=set(next(q for q in tc['methods'] if (q['name'],q['descriptor'])==mk)['code']['bcis']); seen=set()
     except Exception: allowed=None; ident=None; seen=set()
     for seg in sm['segments']:
      lo,hi=seg.get('start'),seg.get('end'); need(isinstance(lo,int) and isinstance(hi,int) and lo in bounds and hi in bounds and lo<=hi,'raw-map range outside RecoveryReport.text UTF-8 coordinates')
      org=seg.get('origin',{}); origins=[org.get('primary',{})]+org.get('derived',[])
      for o in origins:
       if 'bci' in o and allowed is not None: need(o.get('method')==ident and o['bci'] in allowed,'raw-map origin has wrong physical owner/BCI'); seen.add(o['bci'])
     need(allowed is not None and seen==allowed,'raw-map does not cover all physical method BCIs')
    need({cmp.method_key(m) for m in doc.get('methods',[])}=={(m['name'],m['descriptor']) for m in cmp.parse_class(Path(next(x for x in profiles if x['profile']==c['profile'])['class_root'])/(INTERNAL+'.class'))['methods']},'API method inventory differs from physical class')
 for prof in PROFILES:
  pair=[]
  for ev in ('default','all'):
   c=cells.get(('jarde',prof,ev))
   if c and c.get('source_ready'):
    d=json.loads(data(c['report'],'API report')); pair.append({cmp.method_key(m):(m.get('text'),m.get('outcome',{}).get('report',{})) for m in d.get('methods',[])})
  need(len({docs.get((prof,e),{}).get('text') for e in EVIDENCE})==1 and len({tuple((cmp.method_key(m),m.get('text')) for m in docs.get((prof,e),{}).get('methods',[])) for e in EVIDENCE})==1,'default/all/essential whole/projected text differs '+prof)
  if len(pair)==2:
   need(pair[0].keys()==pair[1].keys(),'default/all method sets differ '+prof)
   for k in pair[0].keys()&pair[1].keys():
    xp,x=pair[0][k]; yp,y=pair[1][k]; need(xp==yp and x.get('text')==y.get('text'),'raw/projected method text differs default/all '+str(k))
    need(isinstance(x.get('source_map'),dict) and isinstance(x.get('source_map',{}).get('segments'),list) and isinstance(y.get('source_map'),dict) and isinstance(y.get('source_map',{}).get('segments'),list),'raw map absent default/all '+str(k))
    need(x['source_map']==y['source_map'],'raw map differs default/all '+str(k))
 for c in jadx:
  row=next((r for r in commands if r.get('index')==c.get('command')),{}); need(row.get('exit_code')==c.get('exit_code'),'JADX exit differs from command')
  if c.get('exit_code')!=0: failed.append({'kind':'jadx-launch','profile':c.get('profile'),'exit_code':c.get('exit_code'),'sources':len(c.get('sources',[]))})
  jar=c.get('input',{}); data(jar,'JADX jar'); prof=next(x for x in profiles if x['profile']==c.get('profile')); root=Path(prof['class_root'])
  try:
   with zipfile.ZipFile(jar['path']) as z:
    names=sorted(n for n in z.namelist() if n.endswith('.class')); expected=sorted(prof.get('class_tree',{})); need(names==expected,'JADX archive class inventory differs '+c['profile'])
    for n in expected: need(z.read(n)==(root/n).read_bytes(),'JADX archive class bytes differ '+n)
  except Exception as e: need(False,'invalid JADX archive '+repr(e))
 compiles=report.get('generated_compiles',[]); gruns=report.get('generated_runs',[]); gwr=report.get('generated_wrong_root',[]); need(len(compiles)==32,'generated compile matrix incomplete')
 def ck(x): return (x.get('kind'),x.get('profile'),x.get('variant'),x.get('leg'),x.get('debug'))
 expected={( 'jarde',p,e,l,'-g:none' if 'no-debug' in p else '-g') for p in PROFILES for e in EVIDENCE for l in LEGS}|{('jadx',p,'source',l,'-g:none' if 'no-debug' in p else '-g') for p in PROFILES for l in LEGS}
 need({ck(x) for x in compiles}==expected,'generated compile axis matrix incomplete or unexpected')
 for x in compiles:
  key=(x.get('kind'),x.get('profile'),x.get('variant')); cell=cells.get(key); need(cell is not None,'compile source cell missing '+str(key))
  if cell:
   pins=[cell.get('whole_source')] if key[0]=='jarde' else cell.get('sources',[]); copies=x.get('source_copies',[]); need([z.get('source',{}).get('path') for z in copies]==[z.get('path') for z in pins],'source-copy input set differs '+str(key)); sr=Path(report.get('output',''))/'generated-sources'/Path(x.get('class_root','')).name
   for z in copies:
    src=data(z.get('source',{}),'generated source'); dst=data(z.get('copy',{}),'source copy'); need(src==dst,'generated source bytes changed'); dest=Path(z.get('copy',{}).get('path','')); name=dest.name; mat=re.search(rb'^\s*package\s+([A-Za-z_$][A-Za-z0-9_$.]*)\s*;',src,re.M); pkg=mat.group(1).decode().replace('.','/') if mat else ''
    need(bool(re.fullmatch(r'[A-Za-z_$][A-Za-z0-9_$]*\.java',name)),'illegal Java source filename '+name); need(dest.parent==(sr/pkg if pkg else sr),'source path disagrees with Java package')
    if key[0]=='jarde': need(name=='TypedListForEachCases.java' and b'public class TypedListForEachCases' in src,'Jarde filename/public class mismatch')
    elif pins: need(name==Path(z['source']['path']).name,'JADX basename changed')
  row=next((r for r in commands if r.get('index')==x.get('command')),{}); need(row.get('exit_code')==x.get('exit_code'),'compile exit differs from command'); root=Path(x.get('class_root','')); actual=inventory(root) if x.get('exit_code')==0 else {}
  if x.get('exit_code')==0:
   need(actual==orig.get(x.get('profile')) and x.get('class_inventory_matches_original') is True,'successful output changed complete class/access/method/field inventory '+str(ck(x))); tree=x.get('class_tree',{}); need(set(tree)==set(actual),'successful output class tree incomplete')
   for rel,z in tree.items(): need(Path(z['path']).resolve()==(root/rel).resolve(),'generated class path differs '+rel); data(z,'generated class '+rel)
  else: failed.append({'kind':'generated-compile','cell':ck(x),'exit_code':x.get('exit_code'),'stderr':x.get('streams',{}).get('stderr',{}).get('sha256')})
  rs=[r for r in gruns if (r.get('kind'),r.get('profile'),r.get('variant'),r.get('compiler'),r.get('debug'))==ck(x)]; ws=[r for r in gwr if (r.get('kind'),r.get('profile'),r.get('variant'),r.get('compiler'),r.get('debug'))==ck(x)]
  if x.get('exit_code')==0: need(len(rs)==2 and {r.get('vm') for r in rs}==set(VMS) and len(ws)==1,'success compile lacks exactly 2 VM/1 wrong-root '+str(ck(x)))
  else: need(not rs and not ws,'failed compile has runtime evidence '+str(ck(x)))
  for r in rs:
   row=next((z for z in commands if z.get('index')==r.get('command')),{}); out=data(row.get('streams',{}).get('stdout',{}),'generated stdout') if row else b''; need(row.get('exit_code')==r.get('exit_code'),'generated run exit differs from command'); equal=r.get('exit_code')==0 and out==oracle.get((r.get('profile'),r.get('vm'))); need(r.get('matches_original')==equal,'raw stdout match flag differs '+str(ck(x)))
   if not equal: failed.append({'kind':'generated-runtime','cell':ck(x),'vm':r.get('vm'),'exit_code':r.get('exit_code'),'stdout_sha256':sha(out)})
  for r in ws:
   row=next((z for z in commands if z.get('index')==r.get('command')),{}); err=data(row.get('streams',{}).get('stderr',{}),'generated wrong-root stderr') if row else b''; need(row.get('exit_code')==r.get('exit_code'),'wrong-root exit differs from command')
   if not(r.get('exit_code')==1 and r.get('rejected') is True and b'wrong CodeSource:' in err and r.get('actual_root')!=r.get('expected_root')): failed.append({'kind':'generated-wrong-root','cell':ck(x),'exit_code':r.get('exit_code')})
 failed += [{'kind':'api-cli','profile':c.get('profile'),'evidence':c.get('evidence'),'exit_code':c.get('exit_code')} for c in apis if c.get('exit_code')!=0]; result={'receipt':str(a.receipt.resolve()),'schema':report.get('schema'),'status':report.get('status'),'counts':{'commands':len(commands),'original_profiles':len(profiles),'original_vm':len(runs),'original_case_rows':sum(len(x.get('rows',[])) for x in runs),'api_cells':len(apis),'jadx_cells':len(jadx),'generated_compiles':len(compiles),'generated_compile_successes':sum(x.get('exit_code')==0 for x in compiles),'generated_compile_failures':sum(x.get('exit_code')!=0 for x in compiles),'generated_vm':len(gruns),'generated_wrong_root':len(gwr),'raw_oracle_equal':len(set(raw_oracles))==1 if raw_oracles else False},'failed_cells':failed,'integrity_findings':findings,'assessment':'review evidence only; compiler/runtime failures are preserved, not converted to passes'}; print(json.dumps(result,ensure_ascii=False,indent=2)); return 0 if not findings else 2
if __name__=='__main__': raise SystemExit(main())
