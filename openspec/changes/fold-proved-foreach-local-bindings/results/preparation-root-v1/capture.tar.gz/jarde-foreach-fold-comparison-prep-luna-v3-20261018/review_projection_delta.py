#!/usr/bin/env python3
"""Compare the prior typed foreach artifacts with root-supplied candidate receipts."""
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path

ORIGINAL_OLD_SHA = '433b6a723137adb4aed904b2c7935079821def5b1b91f1593630c224bc73f439'
CONTROLS_OLD_SHA = 'dc8fd91c60d95d1d26d630d2bf8ba57b8ab54b9f58ed6582160286a4c9b4cc3a'
HEADER = re.compile(r'^([ \t]*)for \(java\.lang\.String ([A-Za-z_$][A-Za-z0-9_$]*) : ([A-Za-z_$][A-Za-z0-9_$]*)\) \{\r?\n$')
IDENT = re.compile(r'^[A-Za-z_$][A-Za-z0-9_$]*$')

def need(ok: bool, message: str) -> None:
    if not ok: raise ValueError(message)

def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def readpin(pin: dict, label: str) -> bytes:
    p = Path(pin.get('path', ''))
    need(p.is_absolute() and p.is_file(), f'{label}: missing artifact {p}')
    raw = p.read_bytes()
    need(len(raw) == pin.get('bytes') and digest(p) == pin.get('sha256'), f'{label}: pin mismatch {p}')
    return raw

def name_of(method: dict) -> str:
    return bytes(method['item']['identity']['name']).decode('utf-8')

def methods(doc: dict) -> dict[str, dict]:
    result = {name_of(m): m for m in doc['methods']}
    need(len(result) == len(doc['methods']), 'duplicate method name in API cell')
    return result

def replace_once(text: str, old: str, new: str, label: str) -> str:
    need(old and text.count(old) == 1, f'{label}: expected exact source fragment is not unique')
    return text.replace(old, new, 1)

def fold_original_test(text: str, profile: str) -> str:
    lines = text.splitlines(keepends=True)
    hits = [(i, HEADER.fullmatch(line)) for i, line in enumerate(lines)]
    hits = [(i, m) for i, m in hits if m]
    need(len(hits) == 2, f'{profile}: expected exactly two typed foreach headers')
    expected_collections = ('l1', 'l2') if profile == 'debug' else ('arg1', 'arg2')
    targets = []
    remove = set()
    for ordinal, ((index, match), synthetic, collection, shape) in enumerate(zip(
            hits, ('iteratorElement17', 'iteratorElement47'), expected_collections, ('assign', 'declare'))):
        indent, old_name, got_collection = match.groups()
        need(old_name == synthetic and got_collection == collection, f'{profile}: original foreach identity changed')
        need(index + 1 < len(lines), f'{profile}: header has no first body statement')
        if shape == 'assign':
            binding = re.fullmatch(r'([ \t]*)([A-Za-z_$][A-Za-z0-9_$]*) = ' + re.escape(synthetic) + r';\r?\n', lines[index + 1])
        else:
            binding = re.fullmatch(r'([ \t]*)java\.lang\.String ([A-Za-z_$][A-Za-z0-9_$]*) = ' + re.escape(synthetic) + r';\r?\n', lines[index + 1])
        need(binding is not None, f'{profile}: first binding statement shape differs at foreach {ordinal}')
        target = binding.group(2)
        need(IDENT.fullmatch(target) is not None, f'{profile}: invalid existing local name')
        targets.append(target)
        lines[index] = indent + f'for (java.lang.String {target} : {collection}) {{\n'
        remove.add(index + 1)
    expected_targets = ('s1', 's2') if profile == 'debug' else ('local4', 'local6')
    need(tuple(targets) == expected_targets, f'{profile}: existing target local names differ: {targets}')
    declaration = re.compile(r'^([ \t]*)java\.lang\.String ' + re.escape(targets[0]) + r';\r?\n$')
    decl_hits = [i for i, line in enumerate(lines) if i < hits[0][0] and declaration.fullmatch(line)]
    need(len(decl_hits) == 1, f'{profile}: outer uninitialized declaration is absent/ambiguous')
    remove.add(decl_hits[0])
    for index in sorted(remove, reverse=True): del lines[index]
    return ''.join(lines)

def fold_declared(text: str, profile: str) -> str:
    lines = text.splitlines(keepends=True)
    hits = [(i, HEADER.fullmatch(line)) for i, line in enumerate(lines)]
    hits = [(i, m) for i, m in hits if m]
    need(len(hits) == 1, f'{profile} declared control: expected exactly one typed foreach header')
    index, match = hits[0]
    indent, old_name, collection = match.groups()
    no_debug = profile.endswith('no-debug')
    expected_collection, target = ('arg0', 'local2') if no_debug else ('values', 'value')
    need(old_name == 'iteratorElement17' and collection == expected_collection,
         f'{profile} declared control: original foreach identity changed')
    need(index + 1 < len(lines), f'{profile} declared control: missing first body statement')
    binding = re.fullmatch(
        r'([ \t]*)java\.lang\.String ([A-Za-z_$][A-Za-z0-9_$]*) = iteratorElement17;\r?\n',
        lines[index + 1],
    )
    need(binding is not None and binding.group(2) == target,
         f'{profile} declared control: first declaration differs')
    lines[index] = indent + f'for (java.lang.String {target} : {expected_collection}) {{\n'
    del lines[index + 1]
    return ''.join(lines)

def cmd_map(receipt: dict) -> dict:
    rows = receipt.get('commands', [])
    result = {row.get('index'): row for row in rows}
    need(len(result) == len(rows) and None not in result, 'command indices are missing/duplicated')
    return result

def load_cell(receipt: dict, cell: dict, label: str) -> dict:
    raw = readpin(cell['report'], label + ' raw report')
    command = cmd_map(receipt).get(cell.get('command'))
    need(cell.get('source_ready') is True and cell.get('exit_code') == 0, label + ': API cell is not successful/source-ready')
    need(command is not None and command.get('exit_code') == cell.get('exit_code') == 0, label + ': report command/exit mismatch')
    stdout = readpin(command['streams']['stdout'], label + ' command stdout')
    need(raw == stdout, label + ': saved API report differs from command stdout')
    doc = json.loads(raw)
    whole = readpin(cell['whole_source'], label + ' complete source').decode('utf-8')
    need(doc.get('text') == whole, label + ': full source artifact differs from API text')
    need(doc.get('execution', {}).get('status') == 'complete' and doc.get('outcome') == 'performed', label + ': API execution is not complete/performed')
    need(isinstance(doc.get('methods'), list) and len(doc['methods']) == 6, label + ': complete six-method report missing')
    for method in doc['methods']:
        report = method.get('outcome', {}).get('report')
        need(isinstance(report, dict), label + ': recovered method report missing')
        need(isinstance(report.get('text'), str) and report.get('quality') == 'structured', label + ': raw report text/quality missing')
        sm = report.get('source_map')
        need(isinstance(sm, dict) and isinstance(sm.get('segments'), list), label + ': raw source map missing')
        raw_text = report['text'].encode('utf-8')
        boundaries = {0, len(raw_text), *(i for i, byte in enumerate(raw_text) if byte & 0xC0 != 0x80)}
        for segment in sm['segments']:
            lo, hi = segment.get('start'), segment.get('end')
            need(isinstance(lo, int) and isinstance(hi, int) and lo in boundaries and hi in boundaries and lo <= hi,
                 label + ': raw map range outside UTF-8 text bounds')
    return doc

def compare_cell(old_receipt: dict, new_receipt: dict, old_cell: dict, new_cell: dict,
                 label: str, changed_method: str, transform) -> dict:
    old_doc = load_cell(old_receipt, old_cell, label + ' prior')
    new_doc = load_cell(new_receipt, new_cell, label + ' candidate')
    old_methods, new_methods = methods(old_doc), methods(new_doc)
    need(old_methods.keys() == new_methods.keys(), label + ': method set changed')
    expected_whole = old_doc['text']
    changed = []
    for name in old_methods:
        before, after = old_methods[name], new_methods[name]
        need(before['item']['identity'] == after['item']['identity'], label + f': {name} physical identity changed')
        a, b = before['outcome']['report'], after['outcome']['report']
        need(isinstance(a, dict) and isinstance(b, dict), label + f': {name} raw RecoveryReport missing')
        for key in ('text', 'source_map', 'quality', 'fallbacks'):
            need(key in a and key in b, label + f': {name} raw RecoveryReport.{key} absent')
            need(a[key] == b[key], label + f': {name} raw RecoveryReport.{key} changed')
        projected = transform(before['text']) if name == changed_method else before['text']
        need(after['text'] == projected, label + f': {name} projected text differs beyond the exact fold')
        if name == changed_method:
            expected_whole = replace_once(expected_whole, before['text'], projected, label + ' whole-source method replacement')
            changed.append(name)
    need(new_doc['text'] == expected_whole, label + ': complete source changed outside the exact projected method')
    return {'selector': label, 'method_set': sorted(old_methods), 'folded_method': changed}

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--old-original', type=Path, required=True)
    ap.add_argument('--new-original', type=Path, required=True)
    ap.add_argument('--old-controls', type=Path, required=True)
    ap.add_argument('--new-controls', type=Path, required=True)
    ap.add_argument('--expected-cli-sha256', required=True)
    ap.add_argument('--out', type=Path, required=True)
    a = ap.parse_args()
    need(not a.out.exists(), 'refusing to overwrite output')
    for p, expected, label in ((a.old_original, ORIGINAL_OLD_SHA, 'prior original receipt'),
                               (a.old_controls, CONTROLS_OLD_SHA, 'prior controls receipt')):
        need(digest(p) == expected, label + ' SHA mismatch')
    need(re.fullmatch(r'[0-9a-f]{64}', a.expected_cli_sha256) is not None, 'candidate CLI SHA must be explicit lowercase SHA-256')
    old_original, new_original = json.loads(a.old_original.read_text()), json.loads(a.new_original.read_text())
    old_controls, new_controls = json.loads(a.old_controls.read_text()), json.loads(a.new_controls.read_text())
    for receipt, label in ((new_original, 'original'), (new_controls, 'controls')):
        need(receipt.get('cli', {}).get('sha256') == a.expected_cli_sha256, label + ' receipt candidate CLI SHA mismatch')
    old_o = {(r['profile'], r['input_form'], r['evidence']): r for r in old_original.get('jarde_cells', [])}
    new_o = {(r['profile'], r['input_form'], r['evidence']): r for r in new_original.get('jarde_cells', [])}
    expected_o = {(p, f, e) for p in ('debug', 'no-debug') for f in ('child', 'bundle-child') for e in ('default', 'all')}
    need(set(old_o) == set(new_o) == expected_o, 'original 8-cell API grid differs')
    for key in expected_o:
        need(old_o[key].get('input', {}).get('sha256') == new_o[key].get('input', {}).get('sha256'), f'original input class bytes changed: {key}')
    rows = []
    for key in sorted(expected_o):
        profile = key[0]
        rows.append(compare_cell(old_original, new_original, old_o[key], new_o[key], f'original/{key}', 'test',
                                 lambda text, profile=profile: fold_original_test(text, profile)))
    old_c = {(r['profile'], r['evidence']): r for r in old_controls.get('jarde_cells', [])}
    new_c = {(r['profile'], r['evidence']): r for r in new_controls.get('jarde_cells', [])}
    expected_c = {(p, e) for p in ('javac8-debug', 'javac8-no-debug', 'javac23-debug', 'javac23-no-debug')
                  for e in ('default', 'all', 'essential')}
    need(set(old_c) == set(new_c) == expected_c, 'controls 12-cell API grid differs')
    old_profiles = {r['profile']: {k: v['sha256'] for k, v in r.get('class_tree', {}).items()} for r in old_controls.get('source_profiles', [])}
    new_profiles = {r['profile']: {k: v['sha256'] for k, v in r.get('class_tree', {}).items()} for r in new_controls.get('source_profiles', [])}
    need(len(old_profiles) == len(new_profiles) == 4 and old_profiles == new_profiles, 'controls original profile class trees changed')
    for key in sorted(expected_c):
        rows.append(compare_cell(old_controls, new_controls, old_c[key], new_c[key], f'controls/{key}', 'declared',
                                 lambda text, profile=key[0]: fold_declared(text, profile)))
    # Keep the fixed Java behavior oracle identical across captures, including exception and list-state rows.
    for before, after, label in ((old_original, new_original, 'original'), (old_controls, new_controls, 'controls')):
        left = {(r.get('profile'), r.get('runtime', r.get('vm'))): r.get('rows') for r in before.get('original_runtime', before.get('original_runs', []))}
        right = {(r.get('profile'), r.get('runtime', r.get('vm'))): r.get('rows') for r in after.get('original_runtime', after.get('original_runs', []))}
        need(left and left == right, label + ': raw original runtime oracle rows differ')
    result = {'status': 'projection_delta_verified', 'candidate_cli_sha256': a.expected_cli_sha256,
              'original_api_cells': len(expected_o), 'controls_api_cells': len(expected_c),
              'exact_projection_comparisons': rows,
              'note': 'This delta check does not replace the structural matrix reviewers: they must independently verify Code, maps, compile/run cells, wrong-CodeSource controls, and preserved compiler failures.'}
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'original_api_cells': len(expected_o), 'controls_api_cells': len(expected_c), 'output': str(a.out.resolve())}))
    return 0
if __name__ == '__main__':
    try: raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print(f'projection delta review failed: {exc}')
        raise SystemExit(1)
