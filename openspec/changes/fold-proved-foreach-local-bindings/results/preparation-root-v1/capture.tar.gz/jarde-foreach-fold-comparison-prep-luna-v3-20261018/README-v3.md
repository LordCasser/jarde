# Reviewer v3 hardening (private, not executed)

Copied v2 bundle byte-for-byte before making three fail-closed reviewer changes. v2 remains unchanged at `/private/tmp/jarde-foreach-fold-comparison-prep-luna-v2-20261018/`.

- Generated wrong-root now requires command and row exit exactly 1, the actual compiled target root, and independently derives the intentional expected root as `<matrix output>/empty-classpath`; argv/receipt must agree and roots differ. This matches the frozen original generated receipt argv: target classes are the first driver arg and the empty-classpath directory is the expected-CodeSource arg.
- Controls requires every one of the 12 Jarde API cells to be source-ready, exit 0, complete/performed, and have all six methods; default/all source-map equality is unconditional after requiring segment lists. This does not erase compiler/JADX/runtime failures, which remain reported separately.
- Projection delta requires successful/source-ready API cells, complete/performed six-method reports, structured raw text, present maps/segments and valid UTF-8 map bounds, plus explicit raw-field presence/equality. The exact projected delta rules are unchanged.

Static `ast.parse` succeeded for the three v3 scripts. No reviewer/collector, CLI, JDK, Cargo, or repository command was run. Root should execute v3 against the current captures; this preparation does not claim an acceptance result.
