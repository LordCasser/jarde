# Adversarial review: foreach-fold candidate v2

Read-only review of `/private/tmp/jarde-foreach-fold-impl-luna-v2-20261018/changes.patch` and its copied facade against the prior v1 findings and the OpenSpec budget/revalidation requirements. This is a static review of an immutable, uncompiled candidate. No toolchain or runtime tests were run.

## Findings

### P1: folded edit increments its match count twice, causing the complete projection to be rejected

In `changes.patch:289-330`, the successful fold path now correctly continues into recursive descent (fixing v1’s skipped nested loop), and the previous same-origin Assign ambiguity is guarded by the all-method `target_assignments` count (`changes.patch:775-780`, checked at 927-929). However, the folded branch still falls through to the common typed-edit match increment: `folded.insert(bci)` is followed by the common `*matched.entry(bci).or_default() += 1` at line 330. The old `continue` is gone, and no branch prevents the second increment. The existing final check requires every matched count to equal one (`changes.patch:461-462`), so any edit that actually folds gets count 2 and `project_class_source_generic_edits` returns `None`. Move the match accounting to a single shared path or avoid the extra increment for a folded edit; retain recursive descent so the inner candidate is visited.

### P2: the physical-use copy is not charged to the allocation/item budget before collection

`generic_list_foreach_binding_slot_closed` charges `written.uses.len()` to `AnalysisSteps` (lines 25-35), and later charges `target_count` plus the `nested_facts` work before `stored_uses` is built. But `let mut stored_uses: Vec<_> = written.uses.iter().flatten().copied().collect()` (lines 117-118) allocates a new vector proportional to `written.uses.len()` without an `IrItems` charge for that length. The current IrItems charge at lines 36-39 covers `target_count + 1`, and later charges cover `nested_facts`; those are not guaranteed to bound `written.uses` on a deliberately inconsistent candidate that is about to be refused. Charge the exact use count to the allocation/item dimension before collecting it (or compare without allocating, after charging comparison work). This is a bounded fix, not a request to restructure the proof.

## Recheck of prior v1 findings and other requested areas

- The v1 recursion bypass is fixed: the fold no longer `continue`s before recursive descent; calls into `ForEach` bodies remain (`changes.patch:341-347`).
- The v1 same-origin Assign gap is fixed for target assignments: every target-named Assign increments a count, and exactly one is required for the Assign binding (`changes.patch:775-780`, `927-929`). The new literal-RHS same-origin AST negative case is present (`changes.patch:1024-1031`).
- New slot-closure work now precharges per-site fact-vector lengths and local-read uses before scanning (`changes.patch:40-59`, `78-107`). The remaining issue is the `stored_uses` allocation noted above.
- The staged/final facade comparison now includes the optional binding payload and charges both plans’ read origins/name/origin identity work before equality (`changes.patch:168-187`; report-side plan equality at `216-252`). It compares the complete typed-edit vectors, including `binding`, rather than just type/name.
- The statement/expr traversal still handles binder sites, writes, lambda captures, same-method origins and target read closure as in v1. Origin merge retains method and CP metadata. Stop still propagates, and failed optional proof retains typed-only edits. These are static observations only, not a claim of compiled or runtime correctness.
