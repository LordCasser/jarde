# Private v2 helper test preparation

This standalone additive patch is based on `/private/tmp/jarde-foreach-fold-impl-luna-v2-20261018/src/facade.rs`, inserted after the existing `generic_list_foreach_binding_slot_closed` helper. It uses the frozen debug original `TestNestedLoops$TestCls.class`, asks for `jadx/tests/integration/loops/TestNestedLoops$TestCls`, selects method `test`, and builds local SSA evidence by running the existing method analyzer plus `scan_member_uses`. It expects the fixed binding store at BCI 25 and AST target reads at BCIs 57, 67, and 77.

Refusal mutations cover extra same-slot write/read, missing physical load, replacement, Phi, missing/duplicate/unknown stored uses, duplicate/missing AST reads, and foreign direct and derived origins tied to a changed physical method identity. The positive case tests actual same-run ValueIds; it does not construct public IR values.

Unexecuted. No shared files were changed and no Cargo, JDK, CLI, Git mutation, or network operation ran. Root should validate compile/API and actual BCI assumptions.
