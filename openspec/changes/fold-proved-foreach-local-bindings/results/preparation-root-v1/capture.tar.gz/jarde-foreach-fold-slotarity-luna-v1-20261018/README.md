# Typed foreach slot-read arity guard

Private additive patch based on current shared facade.rs. Target-slot aload facts now require exactly one local read and no local writes. Two internal malformed-fact mutations cover an extra other-slot read and a foreign-slot write at the same target read BCI; both must refuse while target read BCIs remain unchanged. These are not legal-JVM evidence. No shared files or toolchain were touched.
