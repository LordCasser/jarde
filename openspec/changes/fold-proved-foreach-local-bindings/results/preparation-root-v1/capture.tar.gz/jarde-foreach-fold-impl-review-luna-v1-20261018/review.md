# Adversarial review: fold-proved foreach snapshot v1

Scope: read-only review of `/private/tmp/jarde-foreach-fold-impl-review-root-v1-20261018/changes.patch` against the active OpenSpec design and tasks 2.1/2.3. Snapshot is immutable; findings apply to this snapshot and may be resolved by later edits. No tests or product tools were run.

## Findings

### Blocker: applying an outer fold skips traversal into its body, so nested edits are not applied

In `changes.patch:120-124`, the successful binding path removes the first body statement and executes `continue`. This is inside the statement loop in `apply_foreach_edits`. The recursive descent into a `ForEach` body is later in the same function (`changes.patch:142-145`), so the continue bypasses it. With the fixture’s outer and inner loops nested, folding the outer candidate prevents reaching the inner candidate. The later `matched` completeness check (`changes.patch:251`) then rejects the projection because the inner typed edit was not matched, so the combined result cannot publish. This directly blocks the required paired outer-Assign/inner-Declare case. Preserve traversal after applying the current edit, taking care to use the original-node plan while the first statement is removed.

### High: first-binding identity is matched by OriginSet alone, so same-origin Assign clones can impersonate the selected binding

The scan computes `selected_binding = statement.origin == first_origin` (`changes.patch:487-490`). For Assign-shaped bindings, any assignment with that exact origin and target name passes the selected-write exception (`changes.patch:520-524`); unlike declarations, assignments do not increment a uniqueness counter. If an AST contains a second same-origin Assign node (the precise same-BCI/cloned-node boundary called out in the design), it can be treated as the proven initial binding even outside the actual selected loop child. The proof needs a structural node/path identity or an explicit unique-count tied to the selected foreach body’s direct first child, not merely equal origins. Add a same-BCI duplicate-Assign metamorphism and require the optional proof to refuse while typed projection remains usable.

## Reviewed dimensions

- Actual statement-list traversal carries preceding blank declarations per list and gives sibling branches cloned visibility environments; no concrete sibling-scope leak found in this snapshot.
- Name/binder coverage includes parameters, declaration/assignment names, foreach binders, try resources/catches, lambda parameters, local assignments, prefix/postfix updates, and lambda-body local reads. Lambda captures of either selected name are rejected.
- Selected loop, first expression/cast, blank declaration, and collected target-read origins are checked against the same physical method. Header merge carries the binding and blank origins as derived origins with method/CP metadata preserved.
- Physical slot closure checks one store, complete body-value local reads/writes for that slot, AST read BCI equality, same SSA value/definition/use closure, and refuses replaced/foreign reads and unclosed phi-like facts.
- New statement/expression work generally charges/polls before queuing/scanning; selected names, origins and comparison work are charged before cloning/comparing. No broader uncharged whole-tree pass was evident in the added traversal.
- A mismatched or unavailable optional binding proof falls back to the existing typed edit. Stop errors propagate. The projection mutates a cloned tree and publishes only after all edits/removals match, so this path appears atomic.
- Facade constructs and sends a complete optional binding plan, and report-side revalidation rebuilds and compares that plan before applying the fold.

These latter checks do not mitigate the two findings above. This review did not establish successful compilation, runtime behavior, or acceptance of the complete-plan/final-revalidation path.
