# Private helper test preparation

`tests.patch` adds one focused unit test module after `generic_list_foreach_binding_slot_closed`. It seeds the proof with `TypedListForEachCases.strings` from the checked-in fixture, obtains the actual method identity from a normal class-source report, runs the existing Method IR analysis and `scan_member_uses`, and asserts the real BCI 25 store plus the three AST-read BCIs 57/67/77. Mutations cover an extra slot write, missing physical read, replacement, Phi, missing/unknown stored uses, duplicate/missing AST reads, and a foreign-method origin.

This is unexecuted. No shared files were edited and no Cargo, JDK, CLI, Git mutation, or network operation ran. Root should compile-check API imports/fixture coordinates and run the real test.
