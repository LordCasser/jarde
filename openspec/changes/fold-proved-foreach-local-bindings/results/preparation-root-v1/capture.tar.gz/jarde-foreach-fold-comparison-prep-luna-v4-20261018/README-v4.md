# Projection reviewer v4 schema correction (private, not executed)

Copied v3 bundle to a fresh directory; v2 and v3 are preserved. Only `review_projection_delta.py` changed in v4.

The original receipt family uses its actual schema: no `source_ready` field, two physical identities (`<init>()V`, `test(Ljava/util/List;Ljava/util/List;)V`), successful CLI command, complete/performed report, and pinned whole-source artifact. The controls family separately requires `source_ready=true` and exactly six identities: `<init>()V`, `strings(Ljava/util/List;)V`, `integers(Ljava/util/List;)V`, `raw(Ljava/util/List;)V`, `mismatch(Ljava/util/List;)V`, and `declared(Ljava/util/List;)V`. Identity sets were confirmed from the saved original and controls reports/physical inventory.

Both families now require each method’s recovered report, `text`, `source_map`, `quality`, and `fallbacks`; structured quality; a map object with segment list; UTF-8-aligned segments satisfying `0 <= start < end <= byte_length`. An empty segments list is valid (confirmed for controls `essential` evidence); missing maps and zero-width segments fail. The exact source projection transforms and prior receipt pins are unchanged.

Static `ast.parse` succeeded. No reviewer/collector, CLI, JDK, Cargo, repository command, or shared write was performed. Root should run this v4 checker against current captures.
