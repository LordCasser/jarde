"""Additional read-only cross-bindings for the original baseline receipt."""
import hashlib, json, re, zipfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
INNER = 'jadx/tests/integration/loops/TestNestedLoops$TestCls'
OUTER = 'jadx/tests/integration/loops/TestNestedLoops'
COMPARE_SHA = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
PHYSICAL_SHA = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
CASE_NAMES = ('both-empty', 'unmatched', 'five-character-match-add', 'non-five-match-remove',
              'non-five-match-continues-and-clears', 'null-first-list', 'null-second-list', 'null-element')
LABELS = (
 'javac8-full-upstream-source-boundary','javac23-full-source-debug','javac23-full-source-no-debug',
 'compile-independent-reflection-driver','original-runtime-debug-javac8','original-runtime-debug-javac23',
 'original-runtime-no-debug-javac8','original-runtime-no-debug-javac23','driver-code-source-wrong-root-control',
 'jadx-version','jarde-debug-child-default','jarde-debug-child-all','jarde-debug-bundle-child-default',
 'jarde-debug-bundle-child-all','jarde-no-debug-child-default','jarde-no-debug-child-all',
 'jarde-no-debug-bundle-child-default','jarde-no-debug-bundle-child-all','jadx-full-bundle-debug-default',
 'jadx-full-bundle-no-debug-default')

def need(v, message):
    if not v: raise ValueError(message)

def blob(pin, limit=1<<30):
    path=Path(pin['path'])
    need(path.is_file() and path.stat().st_size <= limit, f'missing/large pinned file {path}')
    data=path.read_bytes()
    need(len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'], f'pin mismatch {path}')
    return data

def audit(d, base):
    cs=d['commands']
    need([c['label'] for c in cs]==list(LABELS), 'command labels/order differ from the captured 20-command contract')
    # Recheck the actual runnable and analysis tools, including the selected CLI itself.
    cli=blob(d['cli'], limit=1<<30)
    need(len(cli)==d['cli']['bytes'], 'CLI byte count')
    ext_files=d['external_input_pins_before']['files']
    cli_matches=[p for p in ext_files if p['path']==d['cli']['path']]
    need(cli_matches==[d['cli']], 'CLI top-level identity differs from the recursively checked external-input pin')
    need(d['compare']['path']==str(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py') and d['compare']['sha256']==COMPARE_SHA, 'compare tool identity pin')
    need(d['physical_parser']['path']=='/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py' and d['physical_parser']['sha256']==PHYSICAL_SHA, 'physical parser identity pin')
    need(blob(d['compare'])==Path(d['compare']['path']).read_bytes(), 'compare artifact differs from imported live module')
    need(blob(d['physical_parser'])==Path(d['physical_parser']['path']).read_bytes(), 'physical parser artifact differs from imported live module')
    # Original sources and all private copies used by compiler/driver must be byte-identical.
    for key in ('source','source_copy','driver_source','driver_copy','runtime_wrapper','jadx','jadx_jar'):
        blob(d[key])
    need(blob(d['source'])==blob(d['source_copy']), 'captured upstream source and local compile copy differ')
    need(blob(d['driver_source'])==blob(d['driver_copy']), 'pinned driver source differs from executed compile copy')
    local=d['local_copy_pins_before']
    need(local['driver_copy']==d['driver_copy'] and local['runtime_copy']==d['runtime_wrapper'] and local['source_copy']==d['source_copy'], 'local-copy snapshot does not bind source/driver/runtime artifacts')
    # Each Java API command must execute the pinned CLI with the exact input, class, policy, evidence, and release.
    for cell in d['jarde_cells']:
        command=cs[cell['command']-1]
        profile, form, evidence=cell['profile'],cell['input_form'],cell['evidence']
        need(command['label']==f'jarde-{profile}-{form}-{evidence}', 'API command label does not bind cell selector')
        policy='single-class' if form=='child' else 'plain-jar'
        expected=[d['cli']['path'],'class-source','--input',cell['input']['path'],'--class',INNER,
                  '--policy',policy,'--release','8','--format','json']
        if evidence=='all': expected += ['--evidence','all']
        need(command['argv']==expected, f'API command argv differs from exact {profile}/{form}/{evidence} request')
        output_dir=base/'jarde'/profile/form/evidence
        need(Path(cell['report']['path'])==output_dir/'report.json' and Path(cell['whole_source']['path'])==output_dir/'whole-source.java', 'API report/full-source paths differ from selector')
        api=json.loads(blob(cell['report']))
        whole=blob(cell['whole_source']).decode('utf-8')
        need(api['text']==whole and all(m['text'] in whole for m in api['methods']), 'whole source omits/reformats saved method projections')
    # The parentless runtime command must be the exact pinned wrapper/driver-only classpath and wrong-root negative control.
    for run in d['original_runtime']:
        command=cs[run['command']-1]
        av=command['argv']
        need(av[2]==d['runtime_wrapper']['path'] and av[4]==d['jdk_manifest']['tools'][run['runtime']]['java']['path'], 'runtime wrapper/JVM command binding')
        need(av[av.index('-cp')+1]==str(base/'driver-classes') and av[-3]=='TestNestedLoopsDriver', 'runtime includes target classes on driver classpath')
        need(command['label']==f"original-runtime-{run['profile']}-{run['runtime']}", 'runtime command label/profile mismatch')
        rows=run['rows']
        need([r['index'] for r in rows]==list(range(8)) and tuple(r['name'] for r in rows)==CASE_NAMES, 'runtime cases differ from the pinned eight-case driver contract')
        for row in rows:
            expected=(f"CASE index={row['index']} name={row['name']} exception={row['exception_type']} "
                      f"l1={row['left_after']} l2={row['right_after']}")
            need(row['raw']==expected, 'runtime row fields do not reconstruct exact captured stdout row')
    wrong=d['wrong_root_control']; command=cs[wrong['command']-1]
    need(wrong['command']==9 and command['exit_code']==1 and wrong['exit_code']==1, 'wrong-CodeSource control is not command 9 / exit 1')
    need(command['argv'][2]==d['runtime_wrapper']['path'] and command['argv'][-2:]==[wrong['actual_target_root'],wrong['expected_wrong_root']], 'wrong-root command does not use recorded roots')
    need(Path(wrong['actual_target_root'])==base/'debug/classes' and Path(wrong['expected_wrong_root'])==base/'empty-classpath', 'wrong-root paths do not bind the original debug class and empty root')
    # The two JADX bundles contain precisely the actual profile classes; whole output is the outer Java source with nested class.
    for output in d['jadx_outputs']:
        command=cs[output['command']-1]
        profile=output['compiler_profile']; jar=output['input'];
        need(command['label']==f'jadx-full-bundle-{profile}-default', 'JADX output command selector mismatch')
        outdir=base/'jadx'/profile/'default'
        need(command['argv']==[d['jadx']['path'],'--threads-count','1','--no-res','--config','none','-d',str(outdir),jar['path']], 'JADX command argv differs from pinned full-bundle invocation')
        need(command['exit_code']==0 and output['exit_code']==0, 'JADX invocation failed')
        jar_bytes=blob(jar)
        expected_classes={f'{INNER}.class',f'{OUTER}.class'}
        with zipfile.ZipFile(jar['path']) as archive:
            names={n for n in archive.namelist() if n.endswith('.class')}
            need(names==expected_classes, 'full-input jar class inventory differs from outer/child pair')
            prof=next(p for p in d['source_profiles'] if p['profile']==profile)
            for name in names:
                need(archive.read(name)==blob(prof['class_tree'][name]), f'jar class bytes differ from source profile: {name}')
        source=output['sources'][0]
        expected_source=outdir/'sources/jadx/tests/integration/loops/TestNestedLoops.java'
        need(Path(source['path'])==expected_source, 'JADX output is not the complete outer source path')
        text=blob(source).decode('utf-8')
        need('class TestNestedLoops' in text and 'class TestCls' in text and re.search(r'void\s+test\s*\(List<String>\s+\w+\s*,\s*List<String>\s+\w+\)', text), 'JADX source does not contain full outer/child class declarations and generic List<String> test signature')
    return {'cli_sha256':d['cli']['sha256'],'api_argv_cells':len(d['jarde_cells']),'full_source_method_embeddings':True,
            'runtime_case_names':list(CASE_NAMES),'full_jadx_archives_verified':len(d['jadx_outputs']),
            'compare_and_physical_parser_pins':True,'source_driver_runtime_copy_bindings':True}
