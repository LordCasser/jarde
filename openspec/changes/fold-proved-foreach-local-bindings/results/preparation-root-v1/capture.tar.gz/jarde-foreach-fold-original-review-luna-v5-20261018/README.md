# Original baseline independent audit v5

The audit v1 result passed. Strict-check v2/v3 failures were checker argv-index mistakes; v4 then assumed JADX debug parameter names in the no-debug output. The earlier raw failures are preserved in their version directories. v5 checks the complete outer/child source and generic two-List signature without assuming local parameter names. No baseline evidence or acceptance threshold was changed.
