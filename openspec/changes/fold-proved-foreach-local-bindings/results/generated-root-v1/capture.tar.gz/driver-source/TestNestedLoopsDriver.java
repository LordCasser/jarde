import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Runs the historical eight list cases against only the supplied target class directory. */
public final class TestNestedLoopsDriver {
    private static final String TARGET = "jadx.tests.integration.loops.TestNestedLoops$TestCls";

    private static final class Case {
        final String name;
        final String[] left;
        final String[] right;
        final boolean nullLeft;
        final boolean nullRight;
        final boolean nullElement;

        Case(String name, String[] left, String[] right) {
            this(name, left, right, false, false, false);
        }

        Case(String name, String[] left, String[] right, boolean nullLeft,
                boolean nullRight, boolean nullElement) {
            this.name = name;
            this.left = left;
            this.right = right;
            this.nullLeft = nullLeft;
            this.nullRight = nullRight;
            this.nullElement = nullElement;
        }
    }

    private static final Case[] CASES = {
        new Case("both-empty", new String[0], new String[0]),
        new Case("unmatched", new String[] {"left"}, new String[] {"right"}),
        new Case("five-character-match-add", new String[] {"abcde", "later"}, new String[] {"abcde", "tail"}),
        new Case("non-five-match-remove", new String[] {"four", "later", "tail"}, new String[] {"four"}),
        new Case("non-five-match-continues-and-clears", new String[] {"four", "keep"}, new String[] {"four"}),
        new Case("null-first-list", new String[] {"value"}, new String[] {"value"}, true, false, false),
        new Case("null-second-list", new String[] {"value"}, new String[] {"value"}, false, true, false),
        new Case("null-element", new String[] {"unused"}, new String[] {"value"}, false, false, true),
    };

    private static ArrayList<String> list(String[] values) {
        return new ArrayList<String>(Arrays.asList(values));
    }

    private static String codeSource(Class<?> target) throws Exception {
        CodeSource source = target.getProtectionDomain().getCodeSource();
        if (source == null || source.getLocation() == null) {
            throw new IllegalStateException("target has no CodeSource");
        }
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }

    private static final class Observation {
        final Throwable failure;
        final String left;
        final String right;
        Observation(Throwable failure, String left, String right) {
            this.failure = failure;
            this.left = left;
            this.right = right;
        }
    }

    private static Observation invoke(String actualRoot, String expectedRoot, Case testCase) throws Exception {
        URL url = Paths.get(actualRoot).toRealPath().toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(new URL[] {url}, null)) {
            Class<?> target = Class.forName(TARGET, true, loader);
            if (target.getClassLoader() != loader) {
                throw new IllegalStateException("target did not load from the parentless loader");
            }
            String actual = codeSource(target);
            String expected = Paths.get(expectedRoot).toRealPath().toString();
            if (!actual.equals(expected)) {
                throw new IllegalStateException("wrong CodeSource: expected=" + expected + " actual=" + actual);
            }
            Constructor<?> constructor = target.getDeclaredConstructor();
            Object instance = constructor.newInstance();
            Method method = target.getDeclaredMethod("test", List.class, List.class);
            ArrayList<String> left = list(testCase.left);
            ArrayList<String> right = list(testCase.right);
            if (testCase.nullElement) {
                left.clear();
                left.add(null);
            }
            List<String> first = testCase.nullLeft ? null : left;
            List<String> second = testCase.nullRight ? null : right;
            try {
                method.invoke(instance, first, second);
                return new Observation(null, String.valueOf(first), String.valueOf(second));
            } catch (InvocationTargetException failure) {
                return new Observation(failure.getCause(), String.valueOf(first), String.valueOf(second));
            }
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            throw new IllegalArgumentException("usage: TestNestedLoopsDriver actualRoot expectedRoot");
        }
        String actualRoot = Paths.get(args[0]).toRealPath().toString();
        String expectedRoot = Paths.get(args[1]).toRealPath().toString();
        for (int index = 0; index < CASES.length; index++) {
            Case testCase = CASES[index];
            Observation observed = invoke(actualRoot, expectedRoot, testCase);
            System.out.println("CASE index=" + index + " name=" + testCase.name
                    + " exception=" + (observed.failure == null ? "none" : observed.failure.getClass().getName())
                    + " l1=" + (testCase.nullLeft ? "<null>" : observed.left)
                    + " l2=" + (testCase.nullRight ? "<null>" : observed.right));
        }
    }
}
