package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import java.util.List;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestNestedLoops.class */
public class TestNestedLoops extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestNestedLoops$TestCls.class */
    public static class TestCls {
        public void test(List<String> list, List<String> list2) {
            for (String str : list) {
                for (String str2 : list2) {
                    if (str.equals(str2)) {
                        if (str.length() == 5) {
                            list2.add(str);
                        } else {
                            list.remove(str2);
                        }
                    }
                }
            }
            if (list2.size() > 0) {
                list.clear();
            }
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("for (String s1 : l1) {").containsOne("for (String s2 : l2) {").containsOne("if (s1.equals(s2)) {").containsOne("l2.add(s1);").containsOne("l1.remove(s2);");
    }
}
