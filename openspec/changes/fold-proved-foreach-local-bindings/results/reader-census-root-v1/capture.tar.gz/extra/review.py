from pathlib import Path
import hashlib,json,importlib.util,re
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path(__file__).parent

def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def mod(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
phy=mod('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py','phy');cmp=mod(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','cmp')
rows=[];delta=[0,0,0,0,0]
for variant in ['debug','none']:
 p=ROOT/f'tests/fixtures/foreach-local-bindings/{variant}/TestNestedLoops$TestCls.class';a=phy.parse_class_file(p.read_bytes());b=cmp.parse_class(p);assert a['class_name']==b['class_name'] and a['methods']==b['methods'] and a['major']==52 and a['fields']==[];methods=[];delta[0]+=1
 for m in a['methods']:
  code=m['code'];raw=bytes.fromhex(code['code_hex']);bcis=phy.decode_bcis(raw);assert bcis==code['bcis'];branches=[]
  for bci in bcis:
   op=raw[bci];assert op not in [0xaa,0xab]
   if 0x99<=op<=0xa8 or op in [0xc6,0xc7,0xc8,0xc9]:
    length=4 if op in [0xc8,0xc9] else 2;target=bci+int.from_bytes(raw[bci+1:bci+1+length],'big',signed=True);assert target in bcis;branches.append({'bci':bci,'opcode':op,'target':target})
   if op in [0xa8,0xc9]:delta[4]+=1
  delta[1]+=1;delta[2]+=len(code['rows']);delta[3]+=len(branches);methods.append({'name':m['name'],'descriptor':m['descriptor'],'access':m['access'],'code_bytes':len(raw),'instruction_count':len(bcis),'bcis':bcis,'branches':branches,'handlers':code['rows']})
 rows.append({'variant':variant,'input':pin(p),'class':a['class_name'],'major':a['major'],'access':a['access'],'fields':a['fields'],'methods':methods})
assert delta==[2,4,0,16,0]
p=Path('/private/tmp/jarde-foreach-fold-reader-census-root-v1-20261018/execution.json');r=json.loads(p.read_text());assert r['status']=='failed' and r['target_absent'] and r['source_unchanged'] and r['source_before']==r['source_after'];c=r['commands'][0];assert c['exit_code']==101 and c['guard_stop'] is None and c['peak_target_bytes']<=1024**3 and c['free_bytes_after']>=5*1024**3
err=Path(c['streams']['stderr']['path']).read_text();assert 'left: (1303, 5755, 630, 4066, 14)' in err and 'right: (1301, 5751, 630, 4050, 14)' in err
for cmd in r['commands']:
 for v in cmd['streams'].values():assert pin(v['path'])==v
old=[1301,5751,630,4050,14];new=[x+y for x,y in zip(old,delta)];assert new==[1303,5755,630,4066,14]
out={'status':'actual-full-reader-census-measured-gold-update-pending-rerun','receipt':pin(p),'old':old,'delta':delta,'measured':new,'inputs':rows,'scope':'Actual full Reader walk failed only old measured inventory assertion; independently decoded new inputs explain every increment. Not accepted updated-gold Reader pass yet.'};(OUT/'review.json').write_text(json.dumps(out,indent=2)+'\n');print(out['status'],new)
