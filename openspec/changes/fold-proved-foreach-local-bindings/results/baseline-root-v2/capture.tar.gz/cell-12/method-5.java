    public static void declared(java.util.List<java.lang.String> arg0) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method declared(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
                    for (java.lang.String iteratorElement17 : arg0) {
                        java.lang.String local2 = iteratorElement17;
                        typedforeach.TypedListForEachCases.seen = local2;
                    }
                    return;
    }
