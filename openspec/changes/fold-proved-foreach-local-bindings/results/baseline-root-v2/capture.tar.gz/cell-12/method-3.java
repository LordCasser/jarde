    public static void raw(java.util.List arg0) {
        // @method raw(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.lang.String local1;
        local1 = "before";
        typedforeach.TypedListForEachCases.seen = local1;
        for (java.lang.Object iteratorElement24 : arg0) {
            local1 = (java.lang.String) iteratorElement24;
            typedforeach.TypedListForEachCases.seen = local1;
        }
        typedforeach.TypedListForEachCases.after = local1;
        return;
    }
