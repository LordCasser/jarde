    public static void strings(java.util.List<java.lang.String> arg0) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method strings(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
                    java.lang.String local1;
                    local1 = "before";
                    typedforeach.TypedListForEachCases.seen = local1;
                    for (java.lang.String iteratorElement24 : arg0) {
                        local1 = iteratorElement24;
                        typedforeach.TypedListForEachCases.seen = local1;
                    }
                    typedforeach.TypedListForEachCases.after = local1;
                    return;
    }
