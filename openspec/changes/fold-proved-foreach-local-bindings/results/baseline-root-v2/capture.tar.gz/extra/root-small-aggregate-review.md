# Small `BindingSite` proof review

Static, read-only review of the proposed opaque-AST aggregate. No shared files or tests changed.

## Assessment

The narrow aggregate is sufficient for the fixed inner and outer folds if its selectors identify actual AST nodes by structural child position/role (and full origin), and the helper reconstructs and compares the same aggregate from the immutable source AST at final validation. It need not export a general scope path or local-occurrence model. A BCI/name-only read anchor is insufficient: repeated anchors, especially the outer blank declaration and first assignment at BCI 25, do not identify a node. Keep those selectors internal to the opaque helper or encode only the exact selected sites in the doc-hidden `BindingSite`.

For the inner fold, require the first body statement to be the unique `Declare s2 = (E) synthetic`, then remove that exact node and rename the head to `s2`. For outer `s1`, require one uninitialized `Declare s1` in the exact parent statement vector before the loop and the first body statement to be `Assign s1 = (E) synthetic`; remove those two exact nodes. Same-vector predecessor is a sound, deliberately narrow visibility rule for the fixed root-level case. It rejects branch-local blanks without relying on flattened `scope_anchors`. Both modes must establish that the synthetic head name has exactly the cast-child use being removed and no other local binding/write/use.

The method-wide name closure must count declaration sites outside the ordinary expression walk: method formals; `Declare`, `Assign`, and `ForEach` names; `For.init/update`; try resources; catch names; and `Lambda.params`. It must also count `ExprKind::LocalAssign.name` as a write. Ordinary `ExprKind::Local` reads are reached by the current recursive expression walker. Member names, field names, type/path names, labels, and `IntegerConstantName` are not local uses. A same-spelling declaration anywhere else can conservatively reject the fold; no shadow-resolution subsystem is needed.

The actual AST tree supplies the arm distinction the current `scope_anchors` omit: If then/else vectors, Try body/catch/finally vectors, and each SwitchArm body are distinct child containers. A recursive helper that retains exact parent-child selection while visiting them can prove that every target read is under the selected foreach body; it must not flatten those edges into the existing BCI-only anchors. This also catches reads in conditions/iterables and nested lambdas. Lambda parameters and resource/catch declarations still need explicit name enumeration because the expression visitor does not represent them as `Local` nodes.

## Remaining physical-fact condition

`SameClassBodyValueSite` provides method-wide local reads/writes and `SameClassInvokeValueFact` identities, but `Definition::Phi { block, slot }` exposes no incoming-value list (the SSA value has uses/replacement metadata, not phi operands). Therefore “one write plus every read/value identity” is only a complete physical closure when the proof can establish a direct unambiguous value relation from retained facts. If a relevant target read is phi-defined, replaced, or otherwise cannot be tied to the selected store using those facts, refuse the optional fold. Do not infer that the first binding dominates all loop-body reads from BCI order: the body may branch, loop, or contain captures. This conservative refusal still allows the syntax/AST aggregate to cover the fixed cases if their same-run facts expose a closed direct relation.

## Source pins

- AST expression walker and statement containers: `crates/jarde-java/src/report.rs:8822-9020`.
- AST expression/declaration variants: `crates/jarde-java/src/ast.rs:173-290,760-920`.
- Existing scope inventories and their flattened anchors: `crates/jarde-java/src/report.rs:3510-4015`.
- Physical retained facts: `src/class_source.rs:2615-2632`; capture: `src/facade.rs:19590-19650`.
- SSA definitions show `Phi` stores only block/slot: `crates/jarde-jvm/src/ssa.rs:184-226`.
- Fixed source anchors: outer loop 13, synthetic next 17, outer blank/assignment BCI 25; inner loop 42, next 47, first declaration 55 (prior fixture/map notes cited in `README.md`).
