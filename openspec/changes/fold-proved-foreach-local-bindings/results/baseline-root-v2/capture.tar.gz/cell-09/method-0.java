    public TypedListForEachCases() {
        // @method <init>()V
        // @declaration a constructor of `typedforeach.TypedListForEachCases`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }
