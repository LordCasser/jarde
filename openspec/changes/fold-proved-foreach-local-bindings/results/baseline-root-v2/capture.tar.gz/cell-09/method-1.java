    public static void strings(java.util.List<java.lang.String> values) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method strings(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
                    java.lang.String current;
                    current = "before";
                    typedforeach.TypedListForEachCases.seen = current;
                    for (java.lang.String iteratorElement24 : values) {
                        current = iteratorElement24;
                        typedforeach.TypedListForEachCases.seen = current;
                    }
                    typedforeach.TypedListForEachCases.after = current;
                    return;
    }
