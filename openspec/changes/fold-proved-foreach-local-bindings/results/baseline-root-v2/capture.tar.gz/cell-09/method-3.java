    public static void raw(java.util.List values) {
        // @method raw(Ljava/util/List;)V
        // @declaration a static method of `typedforeach.TypedListForEachCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.lang.String current;
        current = "before";
        typedforeach.TypedListForEachCases.seen = current;
        for (java.lang.Object iteratorElement24 : values) {
            current = (java.lang.String) iteratorElement24;
            typedforeach.TypedListForEachCases.seen = current;
        }
        typedforeach.TypedListForEachCases.after = current;
        return;
    }
