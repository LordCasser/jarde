import hashlib,json,shutil,stat
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
OUT=Path(__file__).parent

def pin(p):
 p=Path(p); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(v):
 a=pin(v['path']);assert (a['bytes'],a['sha256'])==(v['bytes'],v['sha256']),v;return a
def read(p):return json.loads(Path(p).read_text())
binding=read('/private/tmp/jarde-typed-foreach-workspace-acceptance-root-v2-20261018/product-source-binding.json')
assert binding['product_revision']=='e69a3494c8fcd0ff4783be1e9ff71499a730adde'
for v in binding['bindings']:
 p=ROOT/v['path'];check({**v,'path':str(p)});assert bool(p.stat().st_mode & stat.S_IXUSR)==(v['mode']=='100755'),v['path']
assert len(binding['bindings'])==5150
api_path=Path('/private/tmp/jarde-typed-foreach-hardened-api-replay-root-v2-20261018/execution.json')
assert pin(api_path)['sha256']=='72ab91b63437acf96acadc54eed7676c19bdb11bc3d0fbeb66d549e2791127ac'
api=read(api_path);review=read(api_path.parent/'root-review.json')
assert review['status']=='root-independent-api-replay-accepted';check(review['receipt']);check(review['cli'])
assert review['cli']['sha256']=='85ca6e7d36c0edeb72f7f6a3c33c405f203028fb21d128522f0b0a3a92e1cf78'
assert api['source_before']==api['source_after'];assert api['protected_before']==api['protected_after']
for v in api['source_before'].values():check(v)
for v in api['protected_before']:check(v)
assert len(api['source_before'])==3301 and len(api['protected_before'])==1518
assert len(api['commands'])==len(api['cells'])==len(review['rows'])==20
for c in api['commands']:
 assert c['exit_code']==0 and c['guard_stop'] is None
 assert c['argv'][0]==review['cli']['path']
 for s in c['streams'].values():check(s)
rows=[]
for i,c in enumerate(api['cells'],1):
 for k in ['old_report','report','whole_source']:check(c[k])
 old=read(c['old_report']['path']);new=read(c['report']['path'])
 def non_usage(v):
  if isinstance(v,dict):return {k:non_usage(x) for k,x in v.items() if k!='usage'}
  if isinstance(v,list):return [non_usage(x) for x in v]
  return v
 assert non_usage(old)==non_usage(new)
 java=Path(c['whole_source']['path']).read_text();assert java==new['text']
 cell=OUT/f'cell-{i:02d}';cell.mkdir()
 shutil.copyfile(c['report']['path'],cell/'class-source.json');shutil.copyfile(c['whole_source']['path'],cell/'complete.java')
 for j,m in enumerate(new['methods']):
  if m['text'] is not None:(cell/f'method-{j}.java').write_text(m['text'])
  if m['outcome']['kind']=='recovered':(cell/f'method-{j}-raw-report.json').write_text(json.dumps(m['outcome']['report'],ensure_ascii=False,indent=2)+'\n')
 if c['family']=='original':
  outer,inner=('s1','s2') if c['selectors']['profile']=='debug' else ('local4','local6')
  assert f'java.lang.String {outer};' in java
  assert f'for (java.lang.String iteratorElement17 : ' in java and f'{outer} = iteratorElement17;' in java
  assert f'for (java.lang.String iteratorElement47 : ' in java and f'java.lang.String {inner} = iteratorElement47;' in java
 rows.append({'family':c['family'],'selectors':c['selectors'],'methods':len(new['methods']),'all_non_usage_json_exact':True,'complete_java_exact':True,'baseline_json':pin(cell/'class-source.json'),'baseline_java':pin(cell/'complete.java')})
aggregate=read(ROOT/'openspec/changes/recover-typed-list-foreach-elements/results/final-root-acceptance-v1.json')
assert aggregate['status']=='root-accepted-final-focused-and-java-matrices'
checks=[]
for c in aggregate['checks']:
 check(c);assert read(c['path'])==c['review'];checks.append({'name':c['name'],**pin(c['path'])})
controls=read('/private/tmp/jarde-typed-foreach-controls-final-review-root-v3-20261018/review.json')
assert controls['integrity_findings']==[] and controls['counts']['raw_oracle_equal']
assert len(controls['failed_cells'])==8 and all(c['cell'][0]=='jadx' and c['exit_code']==1 for c in controls['failed_cells'])
receipts=[]
for p,h in [('/private/tmp/jarde-typed-foreach-original-final-root-v1-20261018/execution.json','433b6a723137adb4aed904b2c7935079821def5b1b91f1593630c224bc73f439'),('/private/tmp/jarde-typed-foreach-original-generated-final-root-v1-20261018/execution.json','1d171a5ad5a3ef83fd72bde289ae67977ae9fe0cf36a622c9b4e576dbf8d1149'),('/private/tmp/jarde-typed-foreach-controls-final-root-v1-20261018/execution.json','dc8fd91c60d95d1d26d630d2bf8ba57b8ab54b9f58ed6582160286a4c9b4cc3a')]:
 v=pin(p);assert v['sha256']==h;receipts.append(v)
up=pin('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestNestedLoops.java')
assert up['bytes']==876 and up['sha256']=='4897fd18a15fce6e0abb40dc8afc6c7a3fa9f16e617f3c7e5e88072f6a37309e'
result={'status':'root-baseline-revalidated-and-frozen','scope':'Read/revalidate accepted existing evidence only; no new CLI/JDK/runtime execution; not new candidate acceptance. Collector pending status retained separately from prior root acceptance.','product_revision':binding['product_revision'],'source_files':len(binding['bindings']),'source_binding':pin('/private/tmp/jarde-typed-foreach-workspace-acceptance-root-v2-20261018/product-source-binding.json'),'cli':review['cli'],'api_receipt':pin(api_path),'prior_root_review':pin(api_path.parent/'root-review.json'),'commands':20,'raw_streams':40,'source_before_after':3301,'protected_before_after':1518,'rows':rows,'prior_checks':checks,'java_matrix_receipts':receipts,'upstream':up,'controls_counts':controls['counts'],'preserved_failures':aggregate['preserved_failures'],'physical_boundary':{'instructions':45,'code_bytes':119,'outer':{'statement':13,'next':17,'cast':22,'store':25,'slot':4,'reads':[57,67,77]},'inner':{'statement':42,'next':47,'cast':52,'store':55,'slot':6,'reads':[59,89]},'note':'BCI25 blank Declare and first Assign are distinct actual AST nodes. Full physical pins are in preceding analysis evidence; no numeric-range scope inference.'}}
(OUT/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','source_files','commands','raw_streams','controls_counts']},ensure_ascii=False))
