# Seed1 independent audit memo — pending live-target gate

Audit target: `/private/tmp/jarde-foreach-fold-workspace-seed1-root-v1-20261018/execution.json`.

This is a pre-audit memo only. The exact fixed `BASE.validate_one` was **not invoked** because it requires the live repository `target/` to be absent; the parent confirmed seed2 Cargo is currently running and `target/` exists. No pass is claimed, no gate counts are independently validated yet, and no waiver/monkeypatch was used. Wait until seed2 has finished and the exact base checker’s live target-absent precondition can be met, then root can run the fixed wrapper across both receipts.

Recorded from the immutable seed1 receipt (not an independent acceptance): schema `finthrow-full-workspace-seed-replay-v1`, status `passed`, seed `5350648285461741569`, metadata-derived target count field `385`, expected batch count `101`, aggregate harness totals `[3766, 0, 98]`, 101 batch command rows. Receipt flags say target absent before and after clean and pins unchanged. The checker must still reconstruct these from raw metadata/Cargo streams, bind harness blocks to actual `Running` order, verify all sixteen exact gates once, and report legacy collector-order differences without changing counts.

Pins:

- execution receipt SHA-256: `0ae25dad4ec7c6b15be62f5e42a323d680eb61eac9ecbe23d7b94b05cce307ff`
- prepared wrapper `/private/tmp/jarde-foreach-local-bindings-own-ci-prep-luna-v2-20261018/verify_typed_foreach.py`: `f1f1b056cfe305c42e48a3df1c8ae07d8d56b39b1ae2072ccfb523fc99b1d0f1`
- fixed base checker `/private/tmp/jarde-prefixed-retry-workspace-acceptance-root-v1-20261018/reproduction/independent-checker/verify_workspace.py`: `78773c0b0a532a61acbaec46a4565134d0f6822891e81398c6acd255ec0e8bbf`
- runner `/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-branch-throw-return-finally/tools/workspace_runner.py`: `416d9597704be082f3e1891999713fac6b0ce7e51c46c57bf47072e2c8aae953`
- guard: `51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33`
- target scanner: `d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7`

The wrapper’s fixed 16-gate list will be applied unchanged. Base checker resource limits are 5 GiB free and 1 GiB target; receipt records a successful final `cargo clean`. This memo is private and does not alter any receipt.
