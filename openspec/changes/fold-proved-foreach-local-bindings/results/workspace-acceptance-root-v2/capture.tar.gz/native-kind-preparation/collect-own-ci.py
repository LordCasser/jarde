#!/usr/bin/env python3
"""Collect raw GitHub Actions evidence and source pins for the typed-list foreach leaf gates.

Prepared only. The root operator supplies OUT, RUN_ID, and PRODUCT_SHA when collecting CI.
"""
from __future__ import annotations

import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
REPO = 'LordCasser/jarde'
FIXTURE_ROOT = 'tests/fixtures'
FIXTURE_ROOTS = (
    'tests/fixtures/typed-list-foreach',
    'tests/fixtures/foreach-local-bindings/debug',
    'tests/fixtures/foreach-local-bindings/none',
)
EXPECTED_FIXTURE_FILES = (
    'tests/fixtures/foreach-local-bindings/debug/TestNestedLoops$TestCls.class',
    'tests/fixtures/foreach-local-bindings/none/TestNestedLoops$TestCls.class',
    'tests/fixtures/typed-list-foreach/README.md',
    'tests/fixtures/typed-list-foreach/TypedListForEachCases.class',
    'tests/fixtures/typed-list-foreach/TypedListForEachCases.java',
)
SOURCE_PATHS = (
    '.github/workflows/ci.yml',
    'Cargo.toml',
    'Cargo.lock',
    'src/facade.rs',
    'src/class_source.rs',
    'src/bulk.rs',
    'crates/jarde-java/src/report.rs',
    'crates/jarde-java/src/build.rs',
    'crates/jarde-reader/src/classfile.rs',
    'tests/structured_list_generic_bodies.rs',
    'tests/p3_hoisted_iterator_foreach.rs',
    'tests/fixtures/corpus-fingerprint.json',
    'tests/fixtures/foreach-local-bindings/source/TestNestedLoops.java',
)
JOBS = {
    'stable / test and specification': 'stable',
    'MSRV 1.88.0': 'msrv',
    'supply chain': 'supply-chain',
    'fuzz smoke': 'fuzz-smoke',
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def command(out: Path, root: Path, argv: list[str], name: str) -> dict:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    stdout, stderr = out / name, out / (name + '.stderr.raw')
    stdout.parent.mkdir(parents=True, exist_ok=True)
    with stdout.open('xb') as so, stderr.open('xb') as se:
        result = subprocess.run(argv, cwd=root, stdout=so, stderr=se)
    return {
        'argv': argv,
        'exit_code': result.returncode,
        'started_at': started,
        'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'streams': {
            'stdout': {'path': str(stdout), 'bytes': stdout.stat().st_size, 'sha256': sha(stdout.read_bytes())},
            'stderr': {'path': str(stderr), 'bytes': stderr.stat().st_size, 'sha256': sha(stderr.read_bytes())},
        },
    }


def need(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def check_ci(run: dict, jobs_api: dict, product: str) -> list[dict]:
    need(run.get('headSha') == product, 'run headSha differs from PRODUCT_SHA')
    need(run.get('status') == 'completed' and run.get('conclusion') == 'success', 'CI run is not completed successfully')
    need(run.get('workflowName') == 'CI', 'run is not the CI workflow')
    run_jobs = run.get('jobs')
    api_jobs = jobs_api.get('jobs')
    need(isinstance(run_jobs, list) and len(run_jobs) == 4, 'gh run view did not return exactly four jobs')
    need(isinstance(api_jobs, list) and len(api_jobs) == 4, 'GitHub jobs API did not return exactly four jobs')
    need(jobs_api.get('total_count') == 4, 'GitHub jobs API total_count is not four')
    by_name = {row.get('name'): row for row in run_jobs}
    api_by_id = {row.get('id'): row for row in api_jobs}
    need(len(by_name) == 4 and set(by_name) == set(JOBS), f'unexpected CI job names: {sorted(by_name)}')
    need(len(api_by_id) == 4, 'GitHub jobs API contains duplicate job IDs')
    result = []
    for display, slug in JOBS.items():
        job = by_name[display]
        api = api_by_id.get(job.get('databaseId'))
        need(api is not None, f'GitHub jobs API omitted {display}')
        need(job.get('status') == 'completed' and job.get('conclusion') == 'success', f'job failed/incomplete: {display}')
        need(api.get('name') == display and api.get('status') == 'completed' and api.get('conclusion') == 'success',
             f'GitHub API job differs or failed: {display}')
        steps = job.get('steps')
        api_steps = api.get('steps')
        need(isinstance(steps, list) and steps and isinstance(api_steps, list) and len(steps) == len(api_steps),
             f'job step inventory missing/different: {display}')
        for left, right in zip(steps, api_steps):
            need(left.get('name') == right.get('name'), f'job step order differs between APIs: {display}')
            need(left.get('status') == 'completed' and left.get('conclusion') == 'success',
                 f'run-view step failed/incomplete in {display}: {left}')
            need(right.get('status') == 'completed' and right.get('conclusion') == 'success',
                 f'jobs-API step failed/incomplete in {display}: {right}')
        result.append({'name': display, 'slug': slug, 'database_id': job['databaseId'], 'steps': len(steps)})
    return result


def main() -> int:
    if len(sys.argv) != 4:
        raise SystemExit('usage: collect-own-ci.py OUT_DIR RUN_ID PRODUCT_SHA')
    out, run_id, product = Path(sys.argv[1]).resolve(), sys.argv[2], sys.argv[3]
    if re.fullmatch(r'[0-9a-f]{40}', product) is None:
        raise SystemExit('PRODUCT_SHA must be a lowercase full 40-character SHA')
    if not re.fullmatch(r'[0-9]+', run_id) or out.exists():
        raise SystemExit('RUN_ID must be numeric and OUT_DIR must be fresh')
    root = ROOT.resolve(strict=True)
    fixture_dirs = tuple(root / rel for rel in FIXTURE_ROOTS)
    need(all(path.is_dir() and not path.is_symlink() for path in fixture_dirs), 'one or more pinned fixture roots are missing or unsafe')
    fixture_paths = tuple(sorted(path.relative_to(root).as_posix() for fixture_dir in fixture_dirs for path in fixture_dir.rglob('*') if path.is_file()))
    need(len(fixture_paths) == len(set(fixture_paths)) and fixture_paths, 'fixture inventory is empty or overlapping')
    need(fixture_paths == EXPECTED_FIXTURE_FILES, f'typed-list-foreach fixture inventory differs: {fixture_paths}')
    source_paths = tuple(sorted(set(SOURCE_PATHS) | set(fixture_paths)))
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('refusing to collect while repository target exists')
    source_before = {rel: (root / rel).read_bytes() for rel in source_paths}
    out.mkdir(parents=True)
    record = {'product_sha': product, 'run_id': run_id, 'status': 'collecting',
              'commands': [], 'source_paths': list(SOURCE_PATHS),
              'fixture_root': FIXTURE_ROOT, 'fixture_roots': list(FIXTURE_ROOTS), 'fixture_files': list(fixture_paths)}
    try:
        row = command(out, root, ['gh', 'run', 'view', run_id, '--repo', REPO,
            '--json', 'jobs,headSha,status,conclusion,url,databaseId,workflowName'], 'run.json')
        record['commands'].append(row)
        need(row['exit_code'] == 0, 'gh run view failed')
        run = json.loads((out / 'run.json').read_text(encoding='utf-8'))

        row = command(out, root, ['gh', 'api', f'repos/{REPO}/actions/runs/{run_id}/jobs?per_page=100'], 'jobs-api.json')
        record['commands'].append(row)
        need(row['exit_code'] == 0, 'GitHub jobs API request failed')
        jobs_api = json.loads((out / 'jobs-api.json').read_text(encoding='utf-8'))
        checked_jobs = check_ci(run, jobs_api, product)

        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            futures = [pool.submit(command, out, root, ['gh', 'run', 'view', run_id, '--repo', REPO,
                '--job', str(job['database_id']), '--log'], job['slug'] + '.log') for job in checked_jobs]
            log_rows = [future.result() for future in futures]
        record['commands'].extend(log_rows)
        need(all(row['exit_code'] == 0 for row in log_rows), 'one or more complete job-log captures failed')

        files = {}
        fixtures = {}
        for rel in source_paths:
            is_fixture = any(rel.startswith(fixture_root + '/') for fixture_root in FIXTURE_ROOTS)
            target = ('product-fixtures/' if is_fixture else 'product-source/') + rel
            row = command(out, root, ['git', 'show', product + ':' + rel], target)
            record['commands'].append(row)
            need(row['exit_code'] == 0, f'git show failed: {rel}')
            data = (out / target).read_bytes()
            need(data == source_before[rel], f'git-show bytes differ from initial current checkout: {rel}')
            dest = fixtures if is_fixture else files
            dest[rel] = {'git_show': f'git show {product}:{rel}', 'bytes': len(data), 'sha256': sha(data)}

        source_after = {rel: (root / rel).read_bytes() for rel in source_paths}
        need(source_after == source_before, 'source/fixture bytes changed during collection')
        need(not (root / 'target').exists() and not (root / 'target').is_symlink(), 'target appeared during collection')
        (out / 'source-pins.json').write_text(json.dumps({
            'product_sha': product, 'source_files': files, 'fixture_files': fixtures,
            'fixture_root': FIXTURE_ROOT, 'fixture_roots': list(FIXTURE_ROOTS), 'fixture_file_count': len(fixtures),
        }, indent=2) + '\n', encoding='utf-8')
        (out / 'workflow.sha256').write_text(files['.github/workflows/ci.yml']['sha256'] + '\n', encoding='ascii')
        record['checked_jobs'] = checked_jobs
        record['source_file_count'] = len(files)
        record['fixture_file_count'] = len(fixtures)
        record['source_before_after_equal'] = True
        record['target_absent_after'] = True
        record['status'] = 'raw collection complete; independent acceptance pending'
        (out / 'collection.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'status': record['status'], 'captured_commands': len(record['commands']),
                          'source_files': len(files), 'fixture_files': len(fixtures), 'jobs': len(checked_jobs)}))
        return 0
    except Exception as exc:
        record['failure'] = repr(exc)
        record['status'] = 'collection failed; no CI accepted'
        (out / 'collection.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
        raise


if __name__ == '__main__':
    raise SystemExit(main())
