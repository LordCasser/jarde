# Native acceptance checker v3 private repair

Copied the v2 private preparation bundle to this fresh directory. v2 and the original BASE remain unchanged.

The old fixed checker rejected the new `jarde` facade test gate because `validate_gate_inventory` at line 184 inferred every non-`jarde_java` test target must have Cargo kind `test`. The exact metadata identity for crate `jarde` is kind `lib`; the actual test gate is compiled as a lib test target. The v3 private verifier changes only that expectation to treat names `jarde_java` and `jarde` as `lib`, while preserving the subsequent exact metadata identity/unique-match validation. No other checker logic or acceptance criteria changed.

`verify_typed_foreach.py` changes only `BASE` to this private copied checker and `BASE_SHA` to `87b8f2151aa1c47eaf0233835430480945c8d8c2a9be7a7b0c089d9cbfcdbb39`. All 16 gate identities and the original Running/harness, metadata, source-pin, guard, resource, clean, and target-absence checks remain inherited unchanged from v2.

Static `ast.parse` succeeded for the copied checker and wrapper. No checker/acceptance wrapper, CLI, Cargo, JDK, or shared repository operation was run. Root must inspect and execute the new wrapper; this bundle does not claim native acceptance.

Hashes:
- original BASE: `78773c0b0a532a61acbaec46a4565134d0f6822891e81398c6acd255ec0e8bbf`
- private v3 BASE: `87b8f2151aa1c47eaf0233835430480945c8d8c2a9be7a7b0c089d9cbfcdbb39`
- v2 wrapper: `f1f1b056cfe305c42e48a3df1c8ae07d8d56b39b1ae2072ccfb523fc99b1d0f1`
- v3 wrapper: `a3a0ae70a2ed879ae72d36003d1c283cf961d5091b683c391f1976cea06b962c`
