import datetime,hashlib,json,shutil,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
OUT=Path('/private/tmp/jarde-foreach-fold-workspace-acceptance-root-v2-20261018')
S1=Path('/private/tmp/jarde-foreach-fold-workspace-seed1-root-v1-20261018/execution.json')
S2=Path('/private/tmp/jarde-foreach-fold-workspace-seed2-root-v1-20261018/execution.json')
PRODUCT='0a7e3c98f63b128a13a658a475b9e69a9e60d048'
WRAP=Path('/private/tmp/jarde-foreach-local-bindings-own-ci-prep-luna-v3-20261018/verify_typed_foreach.py')
NAMED=Path('/private/tmp/jarde-typed-foreach-native-named-review-root-v1-20261018/review_named.py')
BINDER=Path('/private/tmp/jarde-typed-foreach-product-bind-prep-root-v1-20261018/bind_product.py')
OLD_BASE=Path('/private/tmp/jarde-prefixed-retry-workspace-acceptance-root-v1-20261018/reproduction/independent-checker/verify_workspace.py')
BASE=Path('/private/tmp/jarde-foreach-local-bindings-own-ci-prep-luna-v3-20261018/verify_workspace.py')
def pin(p):
 p=Path(p).resolve(strict=True);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert not OUT.exists() and not (ROOT/'target').exists()
assert all(json.loads(p.read_text())['status']=='passed' for p in (S1,S2))
OUT.mkdir();(OUT/'tools').mkdir()
for p in (Path(__file__),WRAP,NAMED,BINDER,BASE):shutil.copy2(p,OUT/'tools'/p.name)
shutil.copy2(OLD_BASE,OUT/'tools/original-verify_workspace.py')
r={'status':'checking','product':PRODUCT,'tool_pins':[pin(p) for p in (WRAP,NAMED,BINDER,BASE,OLD_BASE)],'commands':[]}
plans=[('native',[sys.executable,'-B',str(WRAP),str(S1),str(S2),'--output',str(OUT/'review.json')]),('named',[sys.executable,'-B',str(NAMED),str(OUT/'review.json'),'--out',str(OUT/'named-status-review.json')]),('binding',[sys.executable,'-B',str(BINDER),'--product',PRODUCT,'--build','/private/tmp/jarde-foreach-fold-broad-root-v1-20261018/execution.json','--seed1',str(S1),'--seed2',str(S2),'--out',str(OUT/'product-source-binding.json')])]
try:
 for name,argv in plans:
  start=datetime.datetime.now(datetime.timezone.utc).isoformat();so=OUT/(name+'.stdout.raw');se=OUT/(name+'.stderr.raw')
  with so.open('xb') as f,se.open('xb') as g:q=subprocess.run(argv,cwd=ROOT,stdout=f,stderr=g)
  row={'argv':argv,'exit_code':q.returncode,'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout':pin(so),'stderr':pin(se)};r['commands'].append(row);assert q.returncode==0,(name,se.read_text())
 r['status']='root-native-and-product-binding-accepted'
finally:
 (OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'commands':len(r['commands'])}))
