#!/usr/bin/env python3
"""Supplement frozen native acceptance with exact named/status equality across seeds."""
import argparse,hashlib,importlib.util,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
BASE=Path('/private/tmp/jarde-prefixed-retry-workspace-acceptance-root-v1-20261018/reproduction/independent-checker/verify_workspace.py')
BASE_SHA='78773c0b0a532a61acbaec46a4565134d0f6822891e81398c6acd255ec0e8bbf'
def need(ok,message):
    if not ok: raise RuntimeError(message)
def pin(p):
    p=Path(p).resolve(strict=True); b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def named_inventory(checker,receipt):
    out=receipt.parent; d=json.loads(receipt.read_bytes()); result={}
    need(d.get('status')=='passed','nonterminal receipt')
    for row in d['commands']:
        label=f"{receipt} command {row['index']}"
        stdout=checker.read_raw(row['streams']['stdout'],label+' stdout',out)
        stderr=checker.read_raw(row['streams']['stderr'],label+' stderr',out)
        artifacts=checker.artifacts_from_stdout(stdout,label)
        launches=checker.running_targets(stderr,artifacts,{tuple(t) for t in row['planned_targets']},label)
        blocks=checker.harness_blocks(stdout,label)
        need(len(launches)==len(blocks),'launch/harness count mismatch')
        for launch,block in zip(launches,blocks):
            key=launch['target']; tests=dict(block['tests'])
            need(key not in result and len(tests)==len(block['tests']),'duplicate target or named test')
            need(all(v in ('ok','ignored') for v in tests.values()),'failed or unknown named outcome')
            result[key]=tests
    need(set(result)==set(map(tuple,d['target_inventory'])),'full target inventory not covered')
    return d,result
p=argparse.ArgumentParser();p.add_argument('accepted_review',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
need(not a.out.exists(),'output already exists')
need(pin(BASE)['sha256']==BASE_SHA,'frozen checker changed')
spec=importlib.util.spec_from_file_location('native_named_checker',BASE);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
review=json.loads(a.accepted_review.read_bytes());need(review.get('status')=='passed','independent native acceptance has not passed')
r1=Path(review['seed1']['path']);r2=Path(review['seed2']['path'])
x,n1=named_inventory(c,r1);y,n2=named_inventory(c,r2)
need((str(x['seed']),str(y['seed']))==('5350648285461741569','5350648285461741570'),'unexpected fixed seed pair/order')
need(n1==n2,'complete per-target named status sets differ across seeds')
rows=[{'target':list(k),'outcomes':[{'name':name,'status':status} for name,status in sorted(n1[k].items())]} for k in sorted(n1)]
report={'status':'accepted','independent_acceptance':pin(a.accepted_review),'checker':pin(BASE),'reviewer':pin(__file__),
 'seed_receipts':[pin(r1),pin(r2)],'fixed_seeds':[str(x['seed']),str(y['seed'])],
 'target_count':len(rows),'named_outcomes_per_seed':sum(len(t) for t in n1.values()),
 'every_named_status_equal_across_seeds':True,'targets':rows,
 'ordering_basis':'Cargo test executes test binaries serially; stdout harness blocks and stderr Running launches each preserve their own order. Metadata/artifact/executable identities bind each serial launch. No timestamp interleaving inference is used.'}
a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('status','target_count','named_outcomes_per_seed','every_named_status_equal_across_seeds')}))
