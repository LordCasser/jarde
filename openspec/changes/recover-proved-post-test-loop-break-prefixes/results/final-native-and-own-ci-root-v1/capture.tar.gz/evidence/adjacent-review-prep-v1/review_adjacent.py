#!/usr/bin/env python3
"""Read-only exact-gate review for nine accepted adjacent regression identities."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, sys
from pathlib import Path
sys.dont_write_bytecode = True
HELPER = Path(__file__).with_name('verify_workspace.py')
HELPER_SHA256 = '8321198c09133aad60d8591b1d3e8f4c849420c4b3a37c1bc4c4aa12129d9830'
GATES = (('p3_for_latch', 'computed_init_return_leaf_and_latch_keep_one_physical_for_source'), ('p3_nested_loop_side_exits', 'upstream_nested_loops4_is_structured_with_complete_physical_sources'), ('p3_nested_loop_side_exits', 'controlled_returns_keep_full_class_maps_for_both_physical_methods'), ('p3_nested_loop_side_exits', 'a_late_public_budget_stop_and_precancellation_publish_no_partial_body'), ('p3_nested_loop_side_exits', 'upstream_nested_loops2_keeps_outer_for_around_inner_while'), ('p3_branch_throw_return_finally', 'branch_throw_return_finally_recovers_both_compilers_and_sealed_ex_with_evidence_parity'), ('p3_branch_throw_return_finally', 'branch_throw_return_finally_late_analysis_budget_publishes_no_partial_source'), ('p3_nested_finally_cleanup', 'nested_saved_return_is_complete_for_both_compilers_and_sealed_ex'), ('p3_nested_finally_cleanup', 'nested_saved_return_late_budget_publishes_no_partial_source_or_map'))

def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('receipt', type=Path, help='terminal native workspace execution.json')
    parser.add_argument('--out', required=True, type=Path, help='new review JSON path')
    args = parser.parse_args()
    try:
        raw_helper = HELPER.read_bytes()
        if sha(raw_helper) != HELPER_SHA256:
            raise ValueError('inherited workspace verifier source pin mismatch')
        spec = importlib.util.spec_from_file_location('post_test_break_workspace_verifier', HELPER)
        if spec is None or spec.loader is None:
            raise ValueError('cannot load inherited workspace verifier')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.GATES = GATES
        result = module.validate_one(args.receipt)
        if result.get('critical_gate_count') != len(GATES):
            raise ValueError('validated gate count differs from the exact nine-gate list')
        expected = [{'target': list(t), 'test': n, 'status': 'ok', 'occurrences': 1} for t, n in GATES]
        if result.get('critical_gates') != expected:
            raise ValueError('validated gate identities/order differ from this review')
        receipt = Path(result['path'])
        receipt_raw = receipt.read_bytes()
        output = {
            'schema': 'post-test-break-prefix-adjacent-native-review-v1',
            'status': 'passed',
            'receipt': {'path': str(receipt), 'bytes': len(receipt_raw), 'sha256': sha(receipt_raw)},
            'workspace_target_count': result['target_count'],
            'workspace_batch_count': result['batch_count'],
            'workspace_totals': result['workspace_totals'],
            'source_pin_count': result['source_pin_count'],
            'source_pins_sha256': result['source_pins_sha256'],
            'inventory_sha256': result['inventory_sha256'],
            'critical_gate_count': len(GATES),
            'critical_gates_each_occur_once_and_pass': True,
            'critical_gates': result['critical_gates'],
            'inherited_verifier': {'path': str(HELPER), 'bytes': len(raw_helper), 'sha256': sha(raw_helper)},
            'method': 'Validated one terminal native receipt with the unchanged full workspace parser and its live source, guard, metadata, batch, resource, and cleanup checks; only the exact gate list was replaced in memory. No tests were run by this reviewer.'
        }
        dest = args.out.resolve()
        if dest.exists():
            raise ValueError(f'refusing to overwrite {dest}')
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'status':'passed','gates':len(GATES),'output':str(dest)}))
        return 0
    except (module.AuditError if 'module' in locals() else Exception, OSError, KeyError, TypeError, ValueError) as exc:
        print(f'REVIEW FAILED: {exc}', file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
