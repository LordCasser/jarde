import hashlib,inspect,importlib.util,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
BASE=Path('/private/tmp/jarde-post-test-break-prefix-own-ci-prep-luna-v3-20261019/verify-own-ci.py')
assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='e504bf05cb667002680ae03b979185e4757fe806ac0a42a854701181a58962c7'
spec=importlib.util.spec_from_file_location('ci_full_names',BASE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
e=Path(sys.argv[1]);out=Path(sys.argv[2]);assert not out.exists()
accepted=json.loads((e/'review.json').read_bytes());assert accepted['status']=='accepted' and accepted['critical_gate_count']==105 and accepted['aggregate_step_proofs']==[]
source=inspect.getsource(m.parse_workspace_group);old="'named_test_outcomes': len(outcomes),";assert source.count(old)==1
source=source.replace(old,old+" 'full_named_outcomes': sorted(outcomes),")
ns=dict(m.__dict__);exec(compile(source,'<read-only-extra-result-observer>','exec'),ns);parse=ns['parse_workspace_group']
log=m.official_step_logs(e)[m.EXPECTED_JOBS['stable']];groups=m.workspace_groups(log);seeds=[r['seed'] for r in accepted['workspace_seed_runs']];assert len(groups)==len(seeds)==2
results=[parse(g,s) for g,s in zip(groups,seeds)];assert results[0]['full_named_outcomes']==results[1]['full_named_outcomes']
for r in results:
 assert len(r['full_named_outcomes'])==r['named_test_outcomes'] and len({(n,t) for n,state,t in r['full_named_outcomes']})==len(r['full_named_outcomes'])
r={'status':'root_accepted_all_named_outcomes_equal_across_both_fixed_seeds','accepted_ci_review_sha256':hashlib.sha256((e/'review.json').read_bytes()).hexdigest(),'product':accepted['product'],'seed_outcomes':results,'observer_change':'Only extends the return value of the exact frozen accepted parser with its already validated named outcome triples; no collection or tests rerun.'}
out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'named_outcomes_each_seed':len(results[0]['full_named_outcomes'])}))
