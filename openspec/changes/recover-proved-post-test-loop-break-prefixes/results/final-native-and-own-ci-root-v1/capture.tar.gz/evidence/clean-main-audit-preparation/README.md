# DoWhile clean-main 审计脚本准备

`audit.py` 是待 root 在文档提交/推送完成后运行的只读检查器。它复用已接受 clean-main 证据的 35 条 Git argv/断言形态，但运行时重新读取当前 HEAD、远端 `origin/main`、分支、worktree、源状态、祖先关系、`target` 目录与磁盘空间；不会把参考收据中的旧 HEAD 当成当前结论。

用法：

```sh
python3 -B audit.py --out /private/tmp/NEW-AUDIT-DIR --cli /private/tmp/jarde-post-test-break-prefix-focused-root-v1-20261019/candidate-cli
```

输出目录必须不存在。每次实际启动的 Git 子进程都会保存 argv、cwd、退出码、原始 stdout/stderr、大小和 SHA 到独立文件与 `execution.json`。调用使用 argv + `subprocess.run(shell=False)`，不经 login shell。检查要求主 worktree 当前分支为 main、HEAD 等于 remote main、local branches 只有 main；主 worktree加14个明确 worktree共15个，全部 clean、target 不存在，aux detached 且其实际 porcelain HEAD 是当前 main HEAD 的祖先。

已接受产品 revision 与 CLI artifact 分字段记录：revision `79385b75a3fb0287f9cc545eb756ee8923e46583`，CLI SHA-256 `8c91115a91a31b041ecaf53a2b964bb57606342d04b524035293ae0b7accd285`。文档 HEAD 可以是该产品 commit 的后继；脚本单独核产品 commit 为当前 HEAD 的祖先，且核 CLI 文件 SHA，不把 CLI binary 复制到输出。

35 条为六个根检查、重复主 status，以及14个 aux 的 status+动态 ancestor 检查；另加一条 product-commit ancestor 检查（总计36个 Git argv）。本脚本未运行 Git、`ls-remote`、构建或测试，结果未产生。
