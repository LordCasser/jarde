#!/usr/bin/env python3
"""Read-only clean-main audit; no shell, Git mutations, builds, or target cleanup."""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, subprocess, sys, time, stat
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
TMP = Path('/private/tmp').resolve()
AUX = [
 '/Users/lordcasser/.codex/worktrees/dt08-local-capture/jarde',
 '/Users/lordcasser/.codex/worktrees/dt09-anon-init-impl/jarde',
 '/Users/lordcasser/.codex/worktrees/dt12-enum-constant-bodies/jarde',
 '/Users/lordcasser/.codex/worktrees/dt13-nested-enum/jarde',
 '/Users/lordcasser/.codex/worktrees/dt16-generic-null/jarde',
 '/Users/lordcasser/.codex/worktrees/dt26-captured-lambda/jarde',
 '/Users/lordcasser/.codex/worktrees/dt29-branched-concat/jarde',
 '/Users/lordcasser/.codex/worktrees/effectful-loop-exits/jarde',
 '/Users/lordcasser/.codex/worktrees/enum-constant-bodies/jarde',
 '/Users/lordcasser/.codex/worktrees/inner-this-baseline/jarde',
 '/Users/lordcasser/.codex/worktrees/plain-enum-arities/jarde',
 '/Users/lordcasser/.codex/worktrees/same-package-field-writes/jarde',
 '/Users/lordcasser/.codex/worktrees/shared-catchall-finally/jarde',
 '/Users/lordcasser/.codex/worktrees/string-ternary-enum/jarde',
]
EXPECTED_WORKTREES = {str(ROOT), *AUX}
PRODUCT_COMMIT = '79385b75a3fb0287f9cc545eb756ee8923e46583'
CLI_SHA256 = '8c91115a91a31b041ecaf53a2b964bb57606342d04b524035293ae0b7accd285'
class AuditError(Exception): pass

def sha(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def need(condition, message):
    if not condition: raise AuditError(message)
def parse_worktrees(raw: str):
    rows=[]; row={}
    for line in raw.splitlines()+['']:
        if not line:
            if row: rows.append(row); row={}
            continue
        key, _, value = line.partition(' ')
        row[key]=value
    return rows
def file_sha(path: Path):
    h=hashlib.sha256(); total=0
    with path.open('rb') as stream:
        while True:
            block=stream.read(1024*1024)
            if not block: break
            h.update(block); total+=len(block)
    return total,h.hexdigest()
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', required=True, type=Path, help='new external evidence directory; must not exist')
    ap.add_argument('--cli', required=True, type=Path, help='external CLI artifact to hash, never copied')
    args=ap.parse_args()
    out=args.out.absolute()
    if not out.resolve().is_relative_to(TMP): raise SystemExit('output must be a new directory under /private/tmp')
    if out.exists(): raise SystemExit(f'refusing to overwrite output: {out}')
    out.mkdir(parents=True)
    commands=[]; checks=[]; started=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    env=os.environ.copy(); env.update({'GIT_OPTIONAL_LOCKS':'0','GIT_TERMINAL_PROMPT':'0'})
    for key in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES'):
        env.pop(key,None)
    def check(name, condition, detail):
        if not condition: raise AuditError(detail)
        checks.append({'name':name,'status':'passed','detail':detail})
    def run(argv, cwd=ROOT):
        index=len(commands)+1
        proc=subprocess.run(argv,cwd=str(cwd),env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False,check=False)
        (out/f'{index:02d}.stdout.raw').write_bytes(proc.stdout)
        (out/f'{index:02d}.stderr.raw').write_bytes(proc.stderr)
        commands.append({'index':index,'argv':argv,'cwd':str(cwd),'exit_code':proc.returncode,'stdout_path':str(out/f'{index:02d}.stdout.raw'),'stdout_bytes':len(proc.stdout),'stdout_sha256':sha(proc.stdout),'stderr_path':str(out/f'{index:02d}.stderr.raw'),'stderr_bytes':len(proc.stderr),'stderr_sha256':sha(proc.stderr)})
        if proc.returncode != 0: raise AuditError(f'command {index} failed ({proc.returncode}): {argv!r}')
        return proc.stdout.decode('utf-8','strict')
    status='failed'; failure=None; summary={}
    try:
        # Product CLI identity is separate from product source revision and later documentation HEAD.
        supplied_cli=args.cli.absolute(); need(not supplied_cli.is_symlink(),'CLI input path must not be a symlink')
        cli=supplied_cli.resolve(strict=True); need(cli.is_file(),'CLI path is not a regular file')
        cli_bytes,cli_hash=file_sha(cli); check('product_cli_sha',cli_hash==CLI_SHA256,'CLI SHA matches the accepted product CLI pin')
        summary['product_cli']={'path':str(cli),'bytes':cli_bytes,'sha256':cli_hash,'mode':stat.S_IMODE(cli.stat().st_mode),'copied':False}
        summary['product_code_commit']=PRODUCT_COMMIT
        head=run(['git','rev-parse','HEAD']).strip(); need(len(head)==40,'HEAD is not a full commit id')
        branch=run(['git','branch','--show-current']).strip(); check('main_branch',branch=='main',f'current branch is {branch!r}')
        clean=run(['git','status','--porcelain']); check('main_clean',clean=='','main worktree porcelain is empty')
        remote_raw=run(['git','ls-remote','--heads','origin','main'])
        remote_rows=[line.split() for line in remote_raw.splitlines() if line.strip()]
        need(len(remote_rows)==1 and len(remote_rows[0])==2 and remote_rows[0][1]=='refs/heads/main','remote main lookup is missing or ambiguous')
        remote=remote_rows[0][0]; check('head_equals_remote_main',remote==head,'local HEAD and origin/main are compared from this run')
        branches=run(['git','for-each-ref','--format=%(refname:short)','refs/heads']).splitlines()
        check('local_branches_only_main',branches==['main'],f'local branches: {branches!r}')
        worktree_raw=run(['git','worktree','list','--porcelain'])
        parsed=parse_worktrees(worktree_raw)
        paths={r.get('worktree') for r in parsed}
        check('exact_worktree_inventory',paths==EXPECTED_WORKTREES and len(parsed)==15,'exactly the main worktree and 14 named auxiliaries are present')
        by_path={r['worktree']:r for r in parsed}
        # Keep the accepted inventory's explicit duplicate main status check.
        check('main_checkout_clean',run(['git','-C',str(ROOT),'status','--porcelain'])=='','explicit main worktree status is empty')
        # The product code revision and CLI pin are distinct; documentation may advance HEAD afterward.
        run(['git','merge-base','--is-ancestor',PRODUCT_COMMIT,head])
        check('product_commit_is_ancestor',True,'accepted product commit is an ancestor; documentation HEAD may be later')
        summary['product_revision_is_ancestor_of_documentation_head']=True
        worktree_rows=[]
        for path in AUX:
            row=by_path[path]; aux_head=row.get('HEAD')
            need(aux_head and len(aux_head)==40,'auxiliary worktree lacks full HEAD in porcelain inventory')
            check(f'{path}:detached','detached' in row and 'branch' not in row,f'auxiliary worktree {path} has detached HEAD metadata')
            aux_clean=run(['git','-C',path,'status','--porcelain'])
            check(f'{path}:clean',aux_clean=='',f'auxiliary worktree {path} status is empty')
            run(['git','merge-base','--is-ancestor',aux_head,head])
            check(f'{path}:ancestor',True,f'actual auxiliary HEAD {aux_head} is an ancestor of current main HEAD')
            target=Path(path)/'target'
            check(f'{path}:target_absent',not target.exists() and not target.is_symlink(),f'target absent for {path}')
            worktree_rows.append({'path':path,'head':aux_head,'detached':True,'clean':True,'target_absent':True,'ancestor_of_main_head':True})
        main_target=ROOT/'target'; check('main_target_absent',not main_target.exists() and not main_target.is_symlink(),'main target directory is absent')
        worktree_rows.insert(0,{'path':str(ROOT),'head':head,'detached':False,'clean':True,'target_absent':True,'ancestor_of_main_head':True})
        free=shutil.disk_usage(ROOT).free
        summary.update({'head':head,'branch':branch,'remote_main':remote,'local_branches':branches,'worktrees':worktree_rows,'free_bytes':free,'primary_target_absent':True,'worktree_count':len(worktree_rows)})
        status='passed'
    except (AuditError,OSError,UnicodeError,ValueError) as exc:
        failure=str(exc)
    result={'schema':'jarde-post-test-break-prefix-clean-main-audit-v1','status':status,'started_utc':started,'finished_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'commands':commands,'command_count':len(commands),'checks':checks,'check_count':len(checks),'all_completed_checks_passed':status=='passed','summary':summary,'failure':failure,'scope':'Read-only Git status/rev-parse/branch/worktree/merge-base and ls-remote plus filesystem target/disk inspection. No Git mutation, build, cleanup, or CLI execution.'}
    (out/'execution.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'status':status,'commands':len(commands),'out':str(out)}))
    return 0 if status=='passed' else 1
if __name__=='__main__': raise SystemExit(main())
