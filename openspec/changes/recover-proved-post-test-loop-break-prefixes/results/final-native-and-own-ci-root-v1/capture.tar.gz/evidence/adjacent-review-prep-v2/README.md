# DoWhile fresh native 相邻回归只读 reviewer 准备

本目录 v2 修正 v1 的 gate 身份比较：比较 `(target[1], test, status, occurrences)`，并在输出中保留 verifier 返回的完整 target 三元组。本目录准备一个只读审阅脚本，用已接受 workspace verifier 的完整 `validate_one(receipt)` 校验 future DoWhile native receipt，并在内存中将 gate list 换成已接受的九个精确相邻身份。脚本不执行 Cargo、不启动测试；它仍验证终态、workspace source pins 与 live source、guard/scanner/JDK、动态 metadata 与 batches、资源、原始 stream 和清理状态。

命令：

```sh
python3 -B review_adjacent.py CURRENT_NATIVE_EXEC --out NEW_REVIEW.json
```

九个 gate 来自既有 Continue native `regression-review.json`，覆盖 CF07、CF11、finThrow、nestedFin。新脚本只把这些精确 identities 计入这次 receipt，并要求每项恰好一次且通过；不重跑这些测试。原始接受记录只为 gate 列表来源，不代表 DoWhile native 已通过。

DoWhile fresh native 仍在运行，本准备没有读取其 receipt，也没有执行旧 Continue receipt 的 smoke。未来运行时，parser 的 live source-pin 检查若发现版本漂移会拒绝，不会放宽校验来复用旧收据。


v2 保留 v1 原目录不变。此次修正只涉及 gate receipt 身份比较；未读取或重新验证 native 收据。
