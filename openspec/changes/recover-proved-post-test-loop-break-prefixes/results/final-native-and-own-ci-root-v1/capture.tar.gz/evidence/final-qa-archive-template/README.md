# DoWhile 最终 QA 归档准备

此目录只有待 root 填充并审阅的 manifest 模板。它不是可执行的 accepted-inputs manifest，所有未产生的 final acceptance / CI / ZIP pins 均为空或明确占位符。当前 native/CI 收据没有在本准备中读取；不要把 Continue 或其它 change 的接受状态、SHA、CI run 当成本片事实。

计划归档目录已按明确路径列出：native、own-CI、product binding、named outcomes、CI wait、own-CI v3 prep 和 root static review、adjacent reviewer v1 实际失败历史、adjacent reviewer v1/v2 prep、named observer、最终 acceptance 和 spec sync。历史准备和失败载荷须保留。若任何必需目录未生成，packer 应失败，不可静默跳过。

模板使用与已接受 archive 相同的 manifest schema 和 `pack.py`；不修改 packer。root 应在 native 与 own-CI 均被接受后，用实际 marker/status/receipt/official ZIP SHA 替换占位项，并核对所有 artifact binding。`candidate-cli` 二进制不得进入归档。

输入参考：

- 已接受 schema 示例：`/private/tmp/jarde-continue-ladder-final-archive-manifest-root-v1-20261019/manifest.json`
- unchanged packer：`/private/tmp/jarde-testbreakwithlabel-native-own-ci-archive-prep-luna-v2-20261019/pack.py`
- 本片 prep：`/private/tmp/jarde-post-test-break-prefix-own-ci-prep-luna-v3-20261019`
- 本片 adjacent reviewer prep v1/v2 和 root 实际失败/修正历史目录：见 `manifest.template.json`。
