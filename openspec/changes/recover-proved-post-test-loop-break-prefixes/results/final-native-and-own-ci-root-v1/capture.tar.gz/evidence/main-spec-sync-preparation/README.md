# 主 spec 同步补丁准备

此目录仅保存待审补丁，未改共享 OpenSpec 文件，也未运行 CLI 或验证器。它把 `recover-proved-post-test-loop-break-prefixes` delta 中唯一 ADDED requirement 合并到现有 `java8-recovery` 主 spec 的 `## Requirements` 下，不复制 delta 操作标题、不修改原有条款。

主 spec 基线为 115,762 bytes，SHA-256 `6d5b7423645d3b40439f384a3c7001989fee49742309bd1a5f7e4fd83d0515b4`。标题此前不存在。拟追加 1 requirement、4 scenarios：34→35 requirements，217→221 scenarios。完整结果、patch 和 delta/source pins 见本目录文件。

应用条件：root 完成本产品 native/own-CI 接受后再审阅并应用；当前该 change 仍为 5/6。此准备不表示实现验收或 OpenSpec 校验通过。
