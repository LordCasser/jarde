# Post-test loop-break native / own-CI 准备包（v3）

状态：私有验收准备。v3 记录已接受的 focused run，但完整 native workspace 矩阵和本 change 的 own-CI 收集尚未运行。focused 收据、root review、当前源码/fixture/test pins 与冻结 Luna 候选 pins 均见 `pins.json`；CLI 只记录外部路径、大小和 SHA，不复制进准备包。

focused run 已通过 512 项 jarde-java library tests、两个本 change public targets、continue-ladder 两项、loop-exit-gateways 15 项、effectful-exits 12 项、Reader census 以及 fingerprint gate；格式、workspace Clippy、CLI 构建和清理也通过。原始 execution 状态仍写作 `commands_passed_pending_independent_acceptance`，以绑定的 root review `root_accepted_exact_focused_gates_fmt_clippy_zero_source_change_build_and_clean` 为接受依据。该次检查绑定 3,282 个 source files，确认零 source changes 且 target 已清理。

后续 native 验收门为 60 个精确 identities；own-CI 保留 92 个内建门与 13 个继承 `--extra-critical`，合计 105 个。所有 targets、测试数量与忽略数必须从实际 receipts 派生。`verify-native.py`、`verify-own-ci.py`、collector、官方 ZIP collector、workspace verifier、product binder 和 acceptance argv 均沿用 v2 的规则；v3 不改验证逻辑。

fixture 目录有 12 个文件，物理库存增量为 `[4,8,0,6,0]`，预期总计 `[1334,5866,631,4223,16]`。focused receipt 已通过 Reader census 与 fingerprint gate。fixture manifest/readme 保持原样，其中准备时点的 pending 文案是历史记录；当前状态以 `pins.json` 中的 focused receipt、root review 和 source pins 为准。

冻结候选的 unit gate 为 `jarde_java=region::tests::post_test_break_prefix_uses_real_ir_and_stops_without_partial_ownership`。两个 public gates 为 `p3_post_test_loop_break_prefixes::original_profiles_and_plain_jars_share_the_public_post_test_break_contract` 与 `p3_post_test_loop_break_prefixes::original_public_class_source_propagates_precancellation_without_partial_text`。focused run 已执行这些相关目标；full native/CI gates 尚待执行。

正式验收时使用 `acceptance-argv.json` 的全部继承与新增门，遵循严格零 source change binder。不要单独重复已由完整 target batch 覆盖的测试，也不要把 focused receipt当作完整 native/CI 结果。
