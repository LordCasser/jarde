from pathlib import Path
import subprocess,json,datetime
O=Path(__file__).parent
assert not (O/'execution.json').exists()
a=['gh','run','watch','39200895508','--exit-status','--interval','30']
r={'status':'running','argv':a,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
with (O/'stdout.raw').open('xb') as so,(O/'stderr.raw').open('xb') as se:p=subprocess.run(a,stdout=so,stderr=se)
r.update(status='completed',exit_code=p.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
(O/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
raise SystemExit(p.returncode)
