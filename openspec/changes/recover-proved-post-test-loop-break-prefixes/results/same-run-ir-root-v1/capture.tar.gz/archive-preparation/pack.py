#!/usr/bin/env python3
"""Prepare/reopen the accepted TestDoWhileBreak same-run IR probe evidence archive."""
from __future__ import annotations
import argparse, gzip, hashlib, io, json, stat, tarfile
from pathlib import Path, PurePosixPath

TMP=Path('/private/tmp').resolve(); HERE=Path(__file__).resolve().parent
RECEIPT_SHA='e4e09af786c677a226d2cad966e2969467972391f4d7dccbbc1e82c4f92ab9a9'
MARKER_SHA='ed375b9e8b5ce55ced040224d51ee1b10de3fd560336bd2cef0b683e4870f7b7'
ROOTS=(
 ('probe-prep','jarde-testdowhilebreak-ir-probe-prep-luna-v1-20261019'),
 ('root-prep','jarde-testdowhilebreak-ir-probe-root-prep-v1-20261019'),
 ('accepted-probe','jarde-testdowhilebreak-ir-probe-root-v1-20261019'),
 ('loop-exit-ownership','jarde-testdowhilebreak-loop-exit-ownership-luna-v1-20261019'),
)
EXCLUDED={'target','__pycache__','.pytest_cache','.mypy_cache','.ruff_cache','.cache','node_modules'}

def sha(b): return hashlib.sha256(b).hexdigest()
def need(ok,msg):
 if not ok: raise SystemExit('archive refused: '+msg)
def safe(path):
 p=path.absolute()
 for x in (p,*p.parents): need(not x.is_symlink(),f'symlink path component: {x}')
 return p
def read_file(path):
 p=safe(path); need(p.is_file(),f'missing/nonregular file: {p}')
 before=p.stat(); b=p.read_bytes(); after=p.stat(); mode=stat.S_IMODE(after.st_mode)
 need((before.st_size,before.st_mtime_ns,before.st_mode)==(after.st_size,after.st_mtime_ns,after.st_mode) and len(b)==after.st_size,f'file changed while reading: {p}')
 return b,mode

def acceptance(root):
 rp=safe(root/'root-review.json'); rb,rm=read_file(rp)
 need(sha(rb)==MARKER_SHA,'accepted root-review marker SHA mismatch')
 marker=json.loads(rb); ep=safe(root/'execution.json'); eb,_=read_file(ep)
 need(sha(eb)==RECEIPT_SHA,'accepted execution receipt SHA mismatch')
 receipt=json.loads(eb)
 need(marker.get('execution_sha256')==RECEIPT_SHA,'marker does not bind exact receipt')
 need(marker.get('wrapper_execution_sha256')=='169332327c10bc1a47ab518f49a6e754b2f94bb10bcc8d2107dd6b93aacec937','wrapper execution pin differs')
 need(marker.get('raw_stderr_sha256')=='2c9074446cbc5960087901a1ffa7188dbfdb9433714dc283df22f040076f380c','probe raw stderr pin differs')
 first=next((c for c in receipt.get('commands',[]) if c.get('index')==1),None)
 need(first is not None and first.get('streams',{}).get('stderr',{}).get('sha256')==marker.get('raw_stderr_sha256'),'root marker stderr pin does not match captured command')
 need(receipt.get('source_unchanged') is True and receipt.get('source_changes')==[] and receipt.get('source_changes_accepted') is True and receipt.get('target_absent') is True,'source restoration/cleanup facts differ')
 need(marker.get('status')=='root_accepted_same_run_do_while_ir_and_exact_source_restoration','unexpected acceptance status')
 need(receipt.get('status')=='commands_passed_pending_independent_acceptance','raw receipt status was rewritten')
 return {'marker_path':str(rp),'marker_sha256':sha(rb),'marker_mode':rm,'receipt_path':str(ep),'receipt_sha256':sha(eb),'acceptance_status':marker['status'],'wrapper_execution_sha256':marker['wrapper_execution_sha256'],'architecture_facts':{k:marker[k] for k in ('class_code_bytes','physical_instructions','canonical_blocks','normal_edges','natural_loop','actual_header_for_header','first_internal_gap')}}

def collect():
 accepted_root=TMP/'jarde-testdowhilebreak-ir-probe-root-v1-20261019'; gate=acceptance(accepted_root)
 items={}
 def add(name,path,data,mode,is_dir=False):
  rel=PurePosixPath(name); need(not rel.is_absolute() and '..' not in rel.parts and bool(rel.parts),f'unsafe archive path {name}')
  key=rel.as_posix(); need(key not in items and key!='ARCHIVE_INVENTORY.json',f'duplicate/reserved archive path {key}')
  items[key]=(path,data,mode,is_dir)
 for label,dirname in ROOTS:
  root=safe(TMP/dirname); need(root.is_dir(),f'missing evidence root {root}')
  add(label+'/',root,b'',stat.S_IMODE(root.stat().st_mode),True)
  for p in sorted(root.rglob('*'),key=lambda p:p.as_posix()):
   need(not p.is_symlink(),f'symlink in evidence tree: {p}')
   need(not any(x in EXCLUDED for x in p.parts),f'cache/build artifact in evidence tree: {p}')
   arc=f'{label}/{p.relative_to(root).as_posix()}'
   if p.is_dir(): add(arc+'/',p,b'',stat.S_IMODE(p.stat().st_mode),True)
   elif p.is_file():
    b,m=read_file(p); add(arc,p,b,m)
   else: need(False,f'nonregular evidence entry: {p}')
 pins=json.loads((HERE/'pins.json').read_text(encoding='utf-8'))
 expected={r['path']:{k:v for k,v in r.items() if k!='label'} for r in pins['members']}
 actual={str(p.absolute()):({'path':str(p.absolute()),'type':'directory','mode':m} if d else {'path':str(p.absolute()),'type':'file','bytes':len(b),'sha256':sha(b),'mode':m}) for p,b,m,d in items.values()}
 need(actual==expected,'source trees differ from frozen file/directory pins')
 for row in pins['preparation_tools']:
  p=HERE/row['name']; b,m=read_file(p)
  need(str(p)==row['path'] and len(b)==row['bytes'] and sha(b)==row['sha256'] and m==row['mode'],f'preparation tool pin mismatch: {p}')
  add('archive-preparation/'+p.name,p,b,m)
 p=HERE/'pins.json'; b,m=read_file(p); add('archive-preparation/pins.json',p,b,m)
 rows=[{'archive_path':n,'source_path':str(p.absolute()),'type':'directory' if d else 'file','bytes':len(b),'sha256':sha(b),'mode':m} for n,(p,b,m,d) in sorted(items.items())]
 manifest={'schema':'test-do-while-break-same-run-ir-probe-archive-v1','payload_member_count':len(rows),'members':rows,'accepted_probe':gate,'notes':['This is same-run IR evidence and architecture review only, not product implementation or behavior acceptance.','No CLI, compiler, JDK or dependency payload is copied.']}
 return manifest,items

def verify(out,manifest,items,blob):
 with tarfile.open(out,'r:gz') as tar:
  members=tar.getmembers(); by={m.name:m for m in members}; need(len(by)==len(members) and set(by)==set(items)|{'ARCHIVE_INVENTORY.json'},'tar member set differs')
  for name,(src,data,mode,is_dir) in items.items():
   info=by[name]; need(info.mode==mode and (info.isdir() if is_dir else info.isfile()),f'type/mode mismatch {name}')
   if not is_dir:
    got=tar.extractfile(info).read(); need(got==data and sha(got)==sha(data),f'payload mismatch {name}')
    now,now_mode=read_file(src); need(now==data and now_mode==mode,f'source changed during packaging {src}')
  need(tar.extractfile(by['ARCHIVE_INVENTORY.json']).read()==blob,'embedded inventory mismatch')

def main():
 ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--out',type=Path,required=True); args=ap.parse_args()
 out=safe(args.out); side=out.with_suffix(out.suffix+'.inventory.json')
 need(not out.exists() and not side.exists(),'refuse existing archive or sidecar')
 roots=[TMP/name for _,name in ROOTS]
 need(not any(out==r or out.is_relative_to(r) for r in roots) and not out.is_relative_to(HERE),'output overlaps evidence/preparation')
 manifest,items=collect(); total=sum(len(b) for _,b,_,d in items.values() if not d); need(total<=512*1024*1024,'payload exceeds 512 MiB')
 blob=(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode(); out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('xb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as gz:
   with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
    for name,(src,data,mode,is_dir) in sorted(items.items()):
     info=tarfile.TarInfo(name); info.mode=mode; info.mtime=0; info.uid=info.gid=0; info.uname=info.gname=''
     if is_dir: info.type=tarfile.DIRTYPE; info.size=0; tar.addfile(info)
     else: info.size=len(data); tar.addfile(info,io.BytesIO(data))
    info=tarfile.TarInfo('ARCHIVE_INVENTORY.json'); info.size=len(blob); info.mode=0o644; info.mtime=0; info.uid=info.gid=0; info.uname=info.gname=''; tar.addfile(info,io.BytesIO(blob))
 verify(out,manifest,items,blob)
 with side.open('xb') as f: f.write(blob)
 print(json.dumps({'status':'packed-and-reopened','archive':str(out),'archive_sha256':sha(out.read_bytes()),'inventory':str(side),'member_count':len(items)},indent=2))
if __name__=='__main__': main()
