# TestDoWhileBreak same-run IR probe 归档准备

本目录只准备证据归档器，没有生成归档。工具基于已接受的 ContinueInLoop IR probe packer，按完整目录树保留文件字节、空目录和 mode，并在未来打包后重开逐项校验成员、类型、mode、bytes、SHA-256 与 embedded inventory。

归档计划包含四棵完整私有树：原探针准备 `/private/tmp/jarde-testdowhilebreak-ir-probe-prep-luna-v1-20261019`、root 执行准备 `/private/tmp/jarde-testdowhilebreak-ir-probe-root-prep-v1-20261019`、实际接受的探针输出 `/private/tmp/jarde-testdowhilebreak-ir-probe-root-v1-20261019`，以及静态所有权备忘 `/private/tmp/jarde-testdowhilebreak-loop-exit-ownership-luna-v1-20261019`。输出树保留完整 execution/root-review、所有 raw stdout/stderr 和恢复结果；root-prep 保存原/候选 region 源快照、commands、raw 和执行收据，也保留 OpenSpec proposal/spec/design/tasks 的指令与状态 JSON；这些指令/状态是准备材料，不是 IR 执行结果。共享临时源现在已恢复/删除，因此不会再尝试从 receipt 逐外部源码 pin 复开；本归档保存运行时捕获的快照及接受 marker，避免把已清理的临时状态描述成仍在现场。

接受绑定：execution SHA-256 `e4e09af786c677a226d2cad966e2969467972391f4d7dccbbc1e82c4f92ab9a9`；root-review SHA-256 `ed375b9e8b5ce55ced040224d51ee1b10de3fd560336bd2cef0b683e4870f7b7`；wrapper execution SHA-256 `169332327c10bc1a47ab518f49a6e754b2f94bb10bcc8d2107dd6b93aacec937`。root 状态为 `root_accepted_same_run_do_while_ir_and_exact_source_restoration`。packer 会校验 marker 对 execution 的绑定、wrapper/stderr 固定 pin、raw receipt 状态、source unchanged/no changes/target absent。临时探针结果为 1 passed/0 failed/0 ignored，峰值 target bytes 167,409,253；source exact restoration、probe removal 和 target absence 均已 root 接受。

实际观察仅记录既有控制流事实：header 2，natural loop 成员 2/13、latch 13、ipdom 21；effect prefix 指令位于 BCI 8/9/10（Push 0/Store 9/Goto 10→21）；ForHeader 实际为 None；首个内部拒绝 `ArmsDoNotMeet` 在 block 13。结论限于现有 gateway 逻辑能保留 effect，后续问题是 statementful prefix 的独占证书；不新增 CFG/Region，也不宣称生产修复或方法行为测试通过。

`pins.json` 固定四棵静态树的所有文件/目录 path、type、mode、bytes 和 SHA-256。归档期间不复制 CLI、编译器、依赖或其他外部载荷。`adaptation.diff` 对照已接受 ContinueInLoop packer 的最小用例适配。

如 root 审查后要打包，使用新输出路径：

```sh
python3 -B /private/tmp/jarde-testdowhilebreak-ir-probe-evidence-archive-prep-luna-v1-20261019/pack.py \
  --out /private/tmp/new-output/do-while-ir-probe.tar.gz
```

本次只做私有静态准备和 pins/语法校验；没有运行 packer、Cargo、JDK、CLI、Git 或网络，也没有修改共享源。
