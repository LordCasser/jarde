import datetime,hashlib,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');PREP=Path('/private/tmp/jarde-testdowhilebreak-ir-probe-prep-luna-v1-20261019');HERE=Path(__file__).parent;OUT=Path('/private/tmp/jarde-testdowhilebreak-ir-probe-root-v1-20261019')
source=ROOT/'crates/jarde-java/src/region.rs';test=ROOT/'crates/jarde-java/src/region/do_while_break_ir_probe_tests.rs';original=source.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest()
pins=json.loads((PREP/'pins.json').read_bytes())
for group in ('class_inputs','prepared','source_pins'):
 for name,row in pins[group].items():
  if isinstance(row,dict) and {'path','sha256'} <= row.keys():
   f=Path(row['path']);b=f.read_bytes();assert sha(b)==row['sha256'],str(f)
   if 'bytes' in row:assert len(b)==row['bytes']
ci=json.loads(Path('/private/tmp/jarde-continue-ladder-own-ci-root-v1-20261019/review.json').read_bytes());assert ci['status']=='accepted' and ci['critical_gate_count']==102 and ci['product']['head_sha']=='050cedbd255ffaddf9e51acf8d2ad52fe573519b'
wait=json.loads(Path('/private/tmp/jarde-continue-ladder-ci-wait-root-v1-20261019/execution.json').read_bytes());assert wait['status']=='completed' and wait['exit_code']==0
assert subprocess.check_output(['git','show','050cedbd255ffaddf9e51acf8d2ad52fe573519b:crates/jarde-java/src/region.rs'],cwd=ROOT)==original
assert not test.exists() and not (ROOT/'target').exists() and not OUT.exists()
a=b'mod statementful_loop_header_tests;';assert original.count(a)==1
candidate=original.replace(a,a+b'\n\n#[cfg(test)]\n#[path = "region/do_while_break_ir_probe_tests.rs"]\nmod do_while_break_ir_probe_tests;')
a=b'        let for_header = self.prove_for_header(header, header_node, blocks, &terminal_returns)?;';assert candidate.count(a)==1
candidate=candidate.replace(a,a+b'\n        #[cfg(test)]\n        eprintln!("DOWHILE_BREAK_PROBE actual-header-tested header={header:?} terminal_returns={terminal_returns:?} for_header={for_header:#?}");')
a=b') -> Run {\n    let fallback = Region::Fallback {';assert candidate.count(a)==1
candidate=candidate.replace(a,b') -> Run {\n    #[cfg(test)]\n    eprintln!("DOWHILE_BREAK_PROBE gap reason={reason:?} next={next:?}");\n    let fallback = Region::Fallback {')
probe=(PREP/'do_while_break_ir_probe_tests.rs').read_bytes();assert (HERE/'original-region.rs').read_bytes()==original and (HERE/'candidate-region.rs').read_bytes()==candidate
cmd=['cargo','test','-p','jarde-java','--lib','--locked','region::do_while_break_ir_probe_tests::dump_real_do_while_break_ir_and_region_result','--','--exact','--nocapture'];(HERE/'commands.json').write_text(json.dumps([cmd],indent=2)+'\n')
argv=['python3','-B',str(ROOT/'openspec/changes/recover-branch-throw-return-finally/tools/run_validation.py'),str(OUT),str(HERE/'commands.json')]
r={'status':'running','argv':argv,'source_before_sha256':sha(original),'candidate_sha256':sha(candidate),'probe_sha256':sha(probe),'pins':pins,'instrumentation':'Temporary test-only prints of actual header-tested for-header and gap reasons; no production control flow or public diagnostic added.'}
try:
 source.write_bytes(candidate);test.write_bytes(probe)
 with (HERE/'stdout.raw').open('xb') as so,(HERE/'stderr.raw').open('xb') as se:proc=subprocess.run(argv,cwd=ROOT,stdout=so,stderr=se)
 r['runner_exit_code']=proc.returncode;assert proc.returncode==0
 x=json.loads((OUT/'execution.json').read_bytes());assert x['source_unchanged'] and x['target_absent'] and x['status']=='commands_passed_pending_independent_acceptance'
 row=x['commands'][0];raw=Path(row['streams']['stdout']['path']).read_text();assert '1 passed; 0 failed;' in raw
 r['status']='root_executed_real_ir_probe_pending_architecture_review'
except BaseException as e:r.update(status='failed',error=repr(e));raise
finally:
 r['candidate_unchanged_until_restore']=source.read_bytes()==candidate and test.read_bytes()==probe
 source.write_bytes(original);test.unlink();r['source_restored_exact']=source.read_bytes()==original;r['probe_removed']=not test.exists();r['target_absent']=not (ROOT/'target').exists();r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(HERE/'execution.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['status','source_restored_exact','probe_removed','target_absent']}))
