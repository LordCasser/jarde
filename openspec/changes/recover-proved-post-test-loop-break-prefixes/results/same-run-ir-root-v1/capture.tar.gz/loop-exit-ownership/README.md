# Do-while exit-prefix ownership: static code facts

This is a read-only source trace, not an implementation review or runtime result. The pending TestDoWhileBreak IR/header trace has not been observed here. The proposed BCI topology (`header 2`, effect prefix 8, latch 13, final join 21) remains a hypothesis until the root probe reports it.

Source pin: `crates/jarde-java/src/region.rs` SHA-256 `19d21dd5f17f48018a5d427a62971b1e4754f1083df3a08cfcc91546705df371`.

## What the current code does

`loop_region` at lines 15885–15960 first tries the special body-branch path only when each header successor is either inside the natural-loop set or passes `loop_exit_bridge` (15931–15945). The later `latch_tested_loop` also requires a single latch and a latch successor outside the natural loop (20195–20220). For an ordinary header comparison, every outside header successor must pass that same bridge helper (20241–20252). Then it rejects any natural-loop block with an outside successor except the latch's chosen exit or a `loop_exit_bridge` (20329–20338).

`loop_exit_bridge` is deliberately narrow: it requires an outside block whose sole instruction is `goto`/`goto_w`, whose only predecessor is the tested source, and whose only outgoing canonical edge is normal to the selected exit (20515–20565). Thus a block containing a store followed by `goto` cannot serve as the current bridge. If the hypothesized `2 -> 8 -> 21` branch exists and 8 is outside the natural set, these checks can reject the latch-loop candidate before body construction. This is the concrete likely refusal point; it is not a break misclassification.

Once a loop body is built, `loop_body` stores two distinct facts: `exits` and one `break_target` (4768–4832). It adds `loop_transfer_sources` to lexical scope (4787–4790). That helper is broad: it selects any normal-flow node with exactly one successor to any target passed to it (21250–21257). In `latch_tested_loop`, its targets are the enclosing loops’ exits/continue destinations plus this loop’s exits (20353–20377). If the hypothesized 8→21 edge is represented and both 8 and 21 are in that target set, 8 will be admitted to scope. This scope membership alone does not prove that 8 is a safe, uniquely owned effect prefix.

At a branch arm, `Frame::arm` preserves the parent scope and loop targets (arm setup at 6543 and `Frame::arm` at 4852–4872). At `region_at_inner`, a node in `target.exits` with one successor equal to a loop’s exact `break_target` is marked `is_transfer_gateway` (5496–5505). That suppresses generic transfer handling for the gateway; actual break classification checks `target.break_target == Some(node)`, not membership in `target.exits` (5506–5521). Therefore, under the hypothesized metadata `exits=(8, 21)` and `break_target=21`, node 8 is not itself classified as a break. Its single-successor path can be walked and the break is emitted when traversal reaches 21.

There is one way the store could be omitted by the existing generic `if` writer: if join selection makes node 8 the `join_node` and the arm directly targeting that join is represented as empty. `join_arm` emits `LoopBreak` only when the selected join itself equals a loop’s `break_target` (if arm construction around 6509–6528 and 6678–6685). So the dangerous combination is not merely `8 ∈ exits`; it is selecting 8 as the break target/join. If the certified final target remains 21, the current transfer-vs-gateway distinction is designed to retain the prefix statements.

## Narrow reuse point and conditions

The smallest existing traversal/emission route is the ordinary `Region::If` arm walk through `region_at`, bounded by the already-present `Frame::scope`/`LoopTarget`; it can emit a straight prefix followed by the existing `LoopBreak` leaf. The root’s proposed prefix proof should feed only the loop-candidate acceptance/ownership decision. It should not rewrite `LoopTarget.break_target` to 8 or add a generic break node for every member of `exits`.

To let that route safely own an effectful prefix, the proof needs to establish that the prefix is the unique route from the branch to the same final break target: exact branch-to-prefix entry, one normal successor chain, final edge to the selected break target, unique predecessor/owner (no alternate entry), no exception/call or unmodeled edge, and no overlap with natural-loop blocks or another arm. The proof also needs to ensure branch join selection does not collapse the prefix to the empty join arm. `loop_transfer_sources` only provides a coarse candidate scope and must not be treated as this certificate.

Do not broaden `loop_exit_bridge` itself: that helper explicitly promises an effect-free one-instruction transfer. Reuse its outgoing/incoming edge accounting pattern for a separately constrained prefix certificate if the actual trace supports the hypothesized shape; retain existing single-goto behavior for ordinary bridge cases. Existing `loop_body_sequence` only walks natural-loop blocks at its top level (20422–20445), so the prefix must be reached recursively from the branch arm, not by simply widening the natural-loop block set. Widening that set would alter loop ownership semantics.

## Boundary of this conclusion

Confirmed from source: an effectful exit prefix is rejected by the current pure-goto bridge gates; once present in scope, it is not automatically a break when `break_target` is the later join; an `If` arm can preserve it if it is walked to that later break target. Not confirmed: whether the fixed class has these blocks/edges, whether the failure occurs at these exact predicates, or whether the current join picker would select 8 or 21. The pending actual IR trace is required before attributing the observed fallback or choosing a change.
