# TestDoWhileBreak same-run IR probe preparation (private, unexecuted)

This is a temporary `#[cfg(test)]` facts probe adapted from the accepted ContinueInLoop IR probe. It does not change production behavior or propose a recovery rule. The diagnostic receipt is `/private/tmp/jarde-testdowhilebreak-baseline-root-v1-20261019/execution.json` (SHA-256 `b5e89a48be39df7700d11d663fa02d0ebb22865b3a7ea989589854b330cd9602`), with independent root acceptance at `/private/tmp/jarde-testdowhilebreak-baseline-root-v1-20261019/root-review.json` (SHA-256 `27b72505573b4154d8c12ff05ab0618518c9f74f1df996457aa5ae8b43a3c2bc`). That baseline reports `test(I)I` fallback `jre_region_arms_do_not_meet` at canonical block 13; this is a published refusal, not a claim about the first internal trial.

The probe embeds the exact Java 8 nested target class bytes from the accepted debug/no-debug full-source profile outputs. Debug is 677 bytes, SHA-256 `037e32820ff9cd17e4d00e9ce9d9c7d764df3d2065b07eb9d5ab0dfa809308b3`, same-run owner BLAKE3 `7921cb5070950102ac6017912816b545c4b30a58ce15945052a47d286aff2ac4`. No-debug is 412 bytes, SHA-256 `151c8d3ad5d4e36c15daa50f12e6cdb10d6a04d90bd92bc05535cca80c6e140c`, owner BLAKE3 `0787f9ca37f4c81defca25a52da928527bff3913433c3bdeb87e838eac751394`. Both physical methods are `test(I)I`; their exact Code bytes and BCI lists are also recorded in `pins.json`.

The test invokes the existing `analyze_method_ir` path and prints raw instructions, canonical blocks/edges, normal-flow identifiers, natural-loop headers/members/latches/ipdoms/irreducibility, actual `prove_for_header` results, every same-run SSA phi and instruction read/write, loop updates and branch successors, then the complete existing Region recovery in method order and its fallback reasons. It makes no hardcoded topology assertion beyond pinning exact class length/identity bytes; no synthetic SSA or graph is used. The method-order Region dump shows the earliest published refusal. It does not claim that this equals the first internal attempted join.

`module.patch` adds one temporary test module to the currently pinned `region.rs`. The precise future filter is:

```text
cargo test -p jarde-java --lib region::do_while_break_ir_probe_tests::dump_real_do_while_break_ir_and_region_result -- --exact --nocapture
```

Do not apply while another guarded build or shared edit is active. Before a future root-owned run, recheck that shared `region.rs` is still SHA-256 `19d21dd5f17f48018a5d427a62971b1e4754f1083df3a08cfcc91546705df371` and `build.rs` is still SHA-256 `4593b653469c515f04a958a4707ea82df2a59e72846dc2ef8875789cc2101a4b`. Root should apply the test file and module line only, run through the guarded validation path, then restore the exact pre-run `region.rs` bytes and remove the temporary test file before checking the target directory is absent. This preparation does not execute Cargo, JDK, CLI, Git, or network operations.
