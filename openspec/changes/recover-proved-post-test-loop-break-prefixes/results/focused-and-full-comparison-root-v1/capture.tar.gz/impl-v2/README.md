# Private candidate v2: post-test loop break prefix

This is an uncompiled, unexecuted private candidate. The shared `region.rs` was not edited. The exact base source is `base-region.rs` (SHA256 recorded in `pins.json`). Version 1 remains frozen at its original path.

## Changes from v1

The old `exit_node: Option<usize>` contract is retained everywhere that feeds the existing return analysis, `Frame::loop_body`, and expected-exit filter. The new prefix proof uses a separate `exact_exit_node: usize`; the latch-successor comparison explicitly wraps the successor before comparing it with the old option. This avoids changing surrounding loop semantics.

The test's short-budget and cancelled-budget usage checks now read through each `Walker`'s borrowed budget, then inspect the Walker's rollback fields. This avoids using the original budget while a mutable borrow remains held by the Walker.

The existing real debug and no-debug `TestDoWhileBreak$TestCls.test(I)I` fixtures also drive a changed-edge control. The test derives the prefix terminal transfer and Code span from Reader's same-run facts, changes only that physical `goto` displacement to the already discovered loop-header BCI, and runs a fresh full Reader/SSA/canonical analysis over the changed class bytes. It checks that the decoded physical displacement and `NormalFlowView` edge both changed, that the prefix is now part of the actual natural loop, and that the outside-prefix certificate refuses it for that changed scope. It does not mutate or fabricate canonical/SSA facts. The class mutation does not rewrite StackMapTable, so this is a parser/IR graph control only and makes no JVM-verification claim.

## Existing proof scope

The candidate adds one bounded certificate for a statement-bearing, single outside block that ends in the exact normal transfer to the loop's final exit. The unchanged pure-goto bridge remains preferred. The proof is called from both header-branch classification and latch exit ownership; a locally carried proof prevents charging the same header edge twice. No loop membership, `LoopTarget`, `Region`, `ForHeader`, or Builder behavior is changed.

The unit reads both permanent original child classes through real Reader/SSA/canonical stages. It checks successful proof and loop ownership, wrong-owner/exit/parent-boundary refusal, precharge Stop and pre-cancel rollback, plus the changed-edge graph control above. The source has not been formatted, compiled, or tested; root must review and run the focused test before integration.

## Review files

- `changes.patch` is the complete base-to-candidate region diff.
- `v1-to-v2.patch` isolates this revision from the frozen v1 candidate.
- `unit-test.txt` contains the added test in isolation.
- `repo/` contains the private candidate source tree and the two already-permanent fixture copies.
- `pins.json` records byte counts and SHA256 for candidate, diffs, fixture inputs, OpenSpec sources, and accepted same-run IR evidence. The manifest intentionally does not hash itself.

Suggested focused command for root, not run here:

`cargo test -p jarde-java --lib post_test_break_prefix_uses_real_ir_and_stops_without_partial_ownership`
