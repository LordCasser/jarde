# TestDoWhileBreak final-candidate matrix preparation (private, not executed)

This bundle adapts the accepted TestContinueInLoop final-candidate collector/reviewer to the already accepted complete TestDoWhileBreak baseline. It is preparation only and makes no claim that a current candidate passed. The prior v2 launch failure is retained at `/private/tmp/jarde-testdowhilebreak-final-matrix-launch-root-v1-20261019/1.stderr.raw`: the order-check needle included a semicolon absent from the actual nested invocation. Root reported that failure occurred before any target command or output-tree creation. V3 checks the actual invocation substring. V3 has not been executed.

The frozen baseline receipt SHA-256 is `b5e89a48be39df7700d11d663fa02d0ebb22865b3a7ea989589854b330cd9602`; its root acceptance marker is `27b72505573b4154d8c12ff05ab0618518c9f74f1df996457aa5ae8b43a3c2bc`, and its independent audit is `5e4281051ecefd613d3f7f01d9162f819da06feca983df8eb34b4f06be36c8c6`. The final candidate pipeline reopens and binds those artifacts, reuses the original runtime rows and exact Jarde/JADX API/source evidence, and does not rerun original, JADX, or original/JADX JVM legs.

The complete upstream source is 563 bytes, SHA-256 `7c8db1024a14626aaafdd977a722665e077f8e17f5751f2249bc7be6e9eba577`. The target is `jadx/tests/integration/loops/TestDoWhileBreak$TestCls`, with `<init>()V` and `test(I)I`, no fields. Its accepted source tree contains exactly the outer and nested target classes. The physical target method has Code length 23 and 14 instruction BCIs: `0,1,2,3,5,8,9,10,13,16,17,18,21,22`. The two fixed cases are `strict-threshold-do-body-latch` (`k=9`, returns 5) and `break-sets-return-local-before-exit` (`k=10`, returns 0). These cases do not require a do-while spelling; equivalent while output is allowed.

The accepted original baseline retains and validates both outer and nested class files. Current class-source requests select the child class: their complete generated Java source is compiled as supplied, and the generated class tree is required to contain the requested target class only. The collector does not trim the original input or demand that Jarde regenerate the outer JUnit class.

The collector requires explicit `--cli` and `--cli-sha256`; the candidate CLI is supplied as an explicit path/hash at execution time. Root supplied the focused candidate path `/private/tmp/jarde-post-test-break-prefix-focused-root-v1-20261019/candidate-cli` with SHA-256 `8c91115a91a31b041ecaf53a2b964bb57606342d04b524035293ae0b7accd285`; this is recorded as an input pin, not as an executed matrix result. The root can execute the prepared pair with:

```sh
python3 -B /private/tmp/jarde-testdowhilebreak-final-candidate-prep-luna-v3-20261019/collect_final.py \
  --root /Users/lordcasser/workspace/projects/jarde \
  --out /private/tmp/jarde-testdowhilebreak-final-candidate-root-v3-20261019 \
  --cli /private/tmp/jarde-post-test-break-prefix-focused-root-v1-20261019/candidate-cli \
  --cli-sha256 8c91115a91a31b041ecaf53a2b964bb57606342d04b524035293ae0b7accd285
python3 -B /private/tmp/jarde-testdowhilebreak-final-candidate-prep-luna-v3-20261019/review.py \
  --receipt /private/tmp/jarde-testdowhilebreak-final-candidate-root-v3-20261019/execution.json \
  --expected-cli-sha256 8c91115a91a31b041ecaf53a2b964bb57606342d04b524035293ae0b7accd285 \
  --out /private/tmp/jarde-testdowhilebreak-final-candidate-review-luna-v3-20261019/review.json
```

Expected capture shape: 8 class/JAR × default/all API calls; 16 complete-source compiler attempts (debug/no-debug × child/bundle-child × two compiler legs); 32 successful target VM runs and 16 wrong-CodeSource controls if every complete build succeeds; 64 observations from the two cases. The reviewer checks the full outer+target class inventory, physical target identity/BCIs, structured target output and valid source-map anchors, exact default/all identity/text/map stability, full source copies and successful compile class trees, isolated parentless runtime/wrong-root execution, and all command/input/source/tool/cleanup guards. It records uncovered BCIs rather than treating comments as executed source; the accepted original map currently covers all 14 target BCIs.

The historical refusal remains explicit: baseline Jarde had 16 full-source compile failures and no VM runs. Two JADX source cells compiled on Java 23 while two Java 8 framework cells failed; accepted original/JADX execution was only four VM runs/eight observations. The final collector does not trim or repair generated source.

Static checks only: Python AST/syntax parsing and parser-only verification of all four accepted baseline stdout files (two expected rows per VM). No target method was invoked; no JDK/Javac/JADX/Jarde/CLI/Cargo/Git/network command was run. Root must inspect both scripts before using them.
