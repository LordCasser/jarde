// jarde: presentation of `jadx/tests/integration/loops/TestDoWhileBreak$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestDoWhileBreak$TestCls extends java.lang.Object {
    public TestDoWhileBreak$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestDoWhileBreak$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public int test(int k) throws java.lang.InterruptedException {
        // @method test(I)I
        // @declaration an instance method of `jadx.tests.integration.loops.TestDoWhileBreak$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int i;
        i = 3;
        do {
            if (k > 9) {
                i = 0;
                break;
            }
            i = i + 1;
        } while (i < 5);
        return i;
    }
}
