# Private candidate: post-test loop break prefix

Static implementation proposal only; this bundle was **not compiled or run**. The shared `region.rs` remains the pinned base, and no shared source was written.

## Candidate

The patch adds a bounded certificate for one statement-bearing canonical block outside a natural loop. It requires a conditional source in that loop, the other source successor to stay in-loop, a single real loop latch, and the prefix to be a non-clone block outside the natural set. The prefix must have one normal predecessor from that source and one normal successor to the same final exit reached by the latch. The source and latch outgoing canonical rows must exactly match their normal-flow successors, so exception, jsr-call/return, or other unprojected rows refuse. The prefix's physical Code instruction sequence must match its same-run SSA block from its first block BCI through its final `goto`/`goto_w`. Unknown operations and embedded transfers refuse; known statement effects remain in place. Parent scope, ownership, and stop roles are checked before proof work.

The existing pure-goto `loop_exit_bridge` remains unchanged and is considered first. The certificate is consulted from both `loop_region` body-branch classification and `latch_tested_loop` exit ownership; the first proof is passed locally to avoid charging the same header edge twice, bound to that exact exit. It does not modify natural-loop membership, `LoopTarget`, `Region`, `ForHeader`, Builder behavior, or value rendering. The existing If/transfer gateway/LoopBreak path is expected to keep the statement once and target the final exit.

All added edge, SSA-instruction, successor, enclosing-transfer-role, and Code-instruction iterations are charged before iteration and polled per item. Proof Stop errors propagate before any ownership mutation. A refused precharge has zero usage because no scan began; a pre-cancel is reported by that charge with zero usage.

## Unit draft

`post_test_break_prefix_uses_real_ir_and_stops_without_partial_ownership` reads both permanent original child classes through real Reader/SSA/canonical stages. It derives header/latch/prefix/exit roles from each profile rather than matching BCI constants. It checks the certificate, wrong-owner/wrong-exit-role/parent-boundary refusals, the actual analysis-step precharge Stop and pre-cancel result without `visited` or tail mutation, then requires the completed loop tree to own the prefix once and retain one `LoopBreak` whose source is the prefix terminal transfer and whose loop identity is the recovered header.

The refusal cases perturb only certificate arguments while keeping Reader facts real; they are not changed-graph fixtures. Therefore the OpenSpec's separate changed-edge graph-variant boundary criterion remains pending for root review. This bundle makes no verifier, runtime, or full-pipeline claim.

## Files and pins

- `repo/crates/jarde-java/src/region.rs`: complete candidate source.
- `changes.patch`: unified diff from the exact base.
- `unit-test.txt`: added unit in isolation.
- `repo/tests/fixtures/...`: private copies of the two already shared original class files at their permanent repository paths.
- `pins.json`: byte lengths and SHA256 pins for the base, candidate, patch, test, class files, OpenSpec, and accepted same-run IR references.

## Proposed focused command (not run)

`cargo test -p jarde-java --lib post_test_break_prefix_uses_real_ir_and_stops_without_partial_ownership`
