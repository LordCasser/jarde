from pathlib import Path
import concurrent.futures, subprocess, hashlib, json
base=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/downloads')
assets=[('corretto8.tar.gz',102618718,'https://corretto.aws/downloads/resources/8.504.04.1/amazon-corretto-8.504.04.1-linux-x64.tar.gz','4ce436ddc3258e43b35d0c1f5041913ae5fc14b4f9c5892de5684abc51c858ae'),('openjdk23.tar.gz',210744162,'https://download.java.net/java/GA/jdk23.0.1/c28985cbf10d4e648e4004050f8781aa/11/GPL/openjdk-23.0.1_linux-x64_bin.tar.gz',None),('jadx-1.5.6.zip',72646741,'https://github.com/skylot/jadx/releases/download/v1.5.6/jadx-1.5.6.zip','545ea2be9c242511bc145755cf4bda2485ade42966e096f8b4d3da2a230e8974')]
step=20*1024*1024;jobs=[]
for name,size,url,digest in assets:
 folder=base/(name+'.parts');folder.mkdir(exist_ok=True)
 prefix=(base/name).open('rb').read(step);assert len(prefix)==step
 
 if not (folder/'000.part').exists():(folder/'000.part').write_bytes(prefix)
 for index,start in enumerate(range(step,size,step),1):jobs.append((folder,index,start,min(start+step,size)-1,url,size))
def download(job):
 folder,index,start,end,url,size=job;p=folder/f'{index:03}.part';h=folder/f'{index:03}.resume.headers';e=folder/f'{index:03}.resume.stderr';attempts=[]
 for attempt in range(4):
  present=p.stat().st_size if p.exists() else 0
  assert present<=end-start+1
  if present==end-start+1:return str(p)
  begin=start+present;tail=folder/f'{index:03}.tail'
  argv=['curl','--fail','--location','--silent','--show-error','--max-time','900','--range',f'{begin}-{end}','--dump-header',str(h),'--output',str(tail),url]
  with e.open('ab') as out:rc=subprocess.call(argv,stderr=out)
  if tail.exists() and tail.stat().st_size:
   assert f'content-range: bytes {begin}-{end}/{size}' in h.read_text().lower(),h
   assert tail.stat().st_size<=end-begin+1
   with p.open('ab') as target:target.write(tail.read_bytes())
   tail.unlink()
  attempts.append({'argv':argv,'exit_code':rc,'present_bytes':p.stat().st_size if p.exists() else 0})
  (folder/f'{index:03}.attempts.json').write_text(json.dumps(attempts,indent=2)+'\n')
 assert p.stat().st_size==end-start+1,(p,p.stat().st_size)
 return str(p)

with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
 for p in pool.map(download,jobs):print('complete',p,flush=True)
manifest=[]
for name,size,url,digest in assets:
 folder=base/(name+'.parts');dest=base/('verified-'+name)
 with dest.open('xb') as out:
  for p in sorted(folder.glob('*.part')):out.write(p.read_bytes())
 assert dest.stat().st_size==size
 actual=hashlib.sha256(dest.read_bytes()).hexdigest()
 if digest:assert actual==digest,(name,actual,digest)
 manifest.append({'path':str(dest),'bytes':size,'sha256':actual,'source':url})
(base/'range-download-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('verified all download sizes and supplied digests',flush=True)
