from pathlib import Path
import json,hashlib,subprocess
ROOT=Path('/home/lordcasser/workspace/projects/jarde');base=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
focused=base/'focused-v6/execution.json';r=json.loads(focused.read_text());assert r['status']=='commands_passed_pending_independent_acceptance' and r['target_absent'] and not (ROOT/'target').exists()
paths={'jdk-manifest':base/'tools/jdk-manifest.json','jadx':base/'tools/jadx/bin/jadx','jadx-jar':base/'tools/jadx/lib/jadx-1.5.6-all.jar','guard':ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py','scanner':ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py','classfile-parser':next((base/'baseline45/pinned-tools').glob('*cf07*.py'))}
for family in ('baseline','admission'):
 for debug in ('debug','none'):
  inputs=ROOT/'tests/fixtures/cf11-ordinary-try-list-generic'/family;out=base/'final-matrix-v1'/family/debug
  args=['python3','-B',str(ROOT/'openspec/changes/recover-ordinary-try-list-generic-bodies/tools/collect_full_class.py'),'--inputs-dir',str(inputs),'--inputs-manifest',str(inputs/'manifest.json'),'--out',str(out),'--javac-debug',debug,'--cli',r['cli']['path'],'--cli-sha256',r['cli']['sha256'],'--build-receipt',str(focused),'--build-receipt-sha256',sha(focused)]
  for key,p in paths.items():args+=['--'+key,str(p),'--'+key+'-sha256',sha(p)]
  print('start',family,debug,flush=True);rc=subprocess.call(args,cwd=ROOT);print('end',family,debug,rc,flush=True)
  if rc:raise SystemExit(rc)
