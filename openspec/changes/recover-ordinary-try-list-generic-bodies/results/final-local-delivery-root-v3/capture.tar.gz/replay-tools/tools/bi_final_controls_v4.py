from pathlib import Path
import subprocess,json,hashlib
B=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
O=B/'bi-final-current-controls-v4';O.mkdir(exist_ok=False);rows=[];pairs=[]
ps=[Path('tests/fixtures/recover-conditional-rhs-field-compound/v8/BI.class'),Path('tests/fixtures/recover-conditional-rhs-field-compound/v8-javac8/BI.class'),B/'bi-original-jar-input-v1/BI.class']
for pi,p in enumerate(ps):
 for ev in ('default','all'):
  ds=[]
  for v in (6,13):
   a=[str(B/f'candidate-cli-v{v}'),'class-source','--input',str(p),'--class','BI','--policy','single-class','--release','8','--format','json']
   if ev=='all': a+=['--evidence','all']
   c=subprocess.run(a,capture_output=True);assert c.returncode==0;n=f'{pi}-v{v}-{ev}';ds.append(json.loads(c.stdout))
   for k,z in [('stdout',c.stdout),('stderr',c.stderr)]: (O/f'{n}.{k}.raw').write_bytes(z)
   rows.append({'argv':a,'exit_code':0,'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'streams':{k:{'path':str(O/f'{n}.{k}.raw'),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()} for k,z in [('stdout',c.stdout),('stderr',c.stderr)]}})
  assert ds[0]['text']==ds[1]['text']
  def maps(d):
   out=[]
   for m in d['methods']:
    r=m['outcome'].get('report');assert r is not None and 'source_map' in r
    out.append((m['item']['identity'],r['representation'],r['quality'],r['text'],r['source_map']))
   return out
  assert maps(ds[0])==maps(ds[1]);assert ds[0]['class']['class_bytes']==ds[1]['class']['class_bytes'];pairs.append({'input':str(p),'evidence':ev,'text_maps_quality_identity':'byte_equal'})
d={'status':'accepted','commands':rows,'pairs':pairs,'final_cli':json.loads((B/'focused-v13/execution.json').read_text())['cli']};(O/'execution.json').write_text(json.dumps(d,indent=2)+'\n');print('accepted',len(rows),'renders')
