from pathlib import Path
import subprocess
B=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
for a in (["python3",str(B/"tools/run_forward_order.py"),"--version","v13","--out",str(B/"forward-order-v3")],["python3",str(B/"tools/run_matrix_v4.py")]):
 r=subprocess.run(a)
 if r.returncode: raise SystemExit(r.returncode)
