from pathlib import Path
import json,importlib.util,hashlib,os,sys
ROOT=Path('/home/lordcasser/workspace/projects/jarde');base=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');out=base/'extra-jdk8-none-v1';assert not out.exists() and not (ROOT/'target').exists();out.mkdir()
p=base/'tools-prep/guard.py';sp=importlib.util.spec_from_file_location('guard',p);g=importlib.util.module_from_spec(sp);sp.loader.exec_module(g);g.ROOT=ROOT;g.OUT=out;g.expected_test_summaries=lambda i,x:None
scanp=base/'tools-prep/target_scan.py';sp=importlib.util.spec_from_file_location('scan',scanp);scan=importlib.util.module_from_spec(sp);sp.loader.exec_module(scan);g.target_bytes=lambda:scan.target_bytes(ROOT)
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
g.command_stream=lambda path:pin(path)
r={'runner':pin(__file__),'status':'running','commands':[],'cli':pin(base/'candidate-cli-v6'),'bridge':pin(base/'tools/JavacBridge.java'),'java':pin(base/'tools/jdk8/amazon-corretto-8.504.04.1-linux-x64/bin/java'),'guard':pin(p),'target_absent_before':True}
env={k:v for k,v in os.environ.items() if k not in ('JAVA_HOME','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','RUST_MIN_STACK')};env.update(g.ENV_VALUES)
def save():(out/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,argv):
 row=g.run_command(len(r['commands'])+1,[str(x) for x in argv],env);row['label']=label;r['commands'].append(row);save();assert row['exit_code']==0 and row['guard_stop'] is None,(label,row['exit_code'],row['guard_stop']);return row
try:
 src=ROOT/'tests/fixtures/cf11-ordinary-try-list-generic/baseline';original=out/'original';original.mkdir();j=str(base/'tools/jdk8/amazon-corretto-8.504.04.1-linux-x64/bin/java');bridge=str(base/'tools/jdk8/amazon-corretto-8.504.04.1-linux-x64/bin/javac')
 compile_args=['-source','8','-target','8','-g:none','-proc:none']
 run('original-compile',[bridge,*compile_args,'-d',original,src/'UpstreamNestedLoops.java',src/'Runner.java'])
 oracle=run('original-run',[j,'-Xverify:all','-cp',original,'cf11.Runner']);expected=Path(oracle['streams']['stdout']['path']).read_bytes();assert len(expected.splitlines())==45;assert not Path(oracle['streams']['stderr']['path']).read_bytes()
 for mode in ('default','all'):
  argv=[base/'candidate-cli-v6','class-source','--input',original/'cf11/UpstreamNestedLoops.class','--class','cf11.UpstreamNestedLoops','--policy','single-class','--release','8','--format','json']
  if mode=='all':argv+=['--evidence','all']
  row=run(mode+'-render',argv);doc=json.loads(Path(row['streams']['stdout']['path']).read_text());folder=out/mode;folder.mkdir();source=folder/'UpstreamNestedLoops.java';source.write_bytes(doc['text'].encode());r.setdefault('generated_sources',[]).append(pin(source))
  classes=folder/'classes';classes.mkdir();run(mode+'-compile',[bridge,*compile_args,'-d',classes,source,src/'Runner.java'])
  actual=run(mode+'-run',[j,'-Xverify:all','-cp',classes,'cf11.Runner']);assert Path(actual['streams']['stdout']['path']).read_bytes()==expected;assert not Path(actual['streams']['stderr']['path']).read_bytes()
 r['status']='matched-complete-class-45-rows';r['target_absent_after']=not (ROOT/'target').exists()
except BaseException as e:r['status']='failed';r['error']=repr(e)
finally:save();print(json.dumps({k:r.get(k) for k in ('status','error','cli','generated_sources')}),flush=True)
raise SystemExit(0 if r['status']=='matched-complete-class-45-rows' else 1)
