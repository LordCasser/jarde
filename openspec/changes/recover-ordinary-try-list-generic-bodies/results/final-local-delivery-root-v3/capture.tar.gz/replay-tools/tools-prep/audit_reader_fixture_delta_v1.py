#!/usr/bin/env python3
"""Pure-Python census audit for the four 2026-10-14 reader-fixture additions.

Uses the maintained audit_candidate classfile parser and archived instruction decoder.
This records only the four added fixture files and their delta against the prior fixed
tuple; it does not invoke Rust, Cargo, a compiler, Jarde, or a local parser implementation.
"""
import argparse
import datetime
import hashlib
import importlib.util
import json
import pathlib
import sys

sys.dont_write_bytecode = True

BASE = pathlib.Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
REPO = pathlib.Path('/home/lordcasser/workspace/projects/jarde')
AUDITOR = BASE / 'review' / 'audit_candidate.py'
REFERENCE = BASE / 'baseline45'
BLAKE3_PATH = BASE / 'tools' / 'pythonlib'
OLD_TUPLE = (1165, 5163, 503, 3284, 10)
EXPECTED_DELTA = (4, 62, 18, 145, 0)
EXPECTED_NEW = tuple(a + b for a, b in zip(OLD_TUPLE, EXPECTED_DELTA))
FIXTURES = (
    ('tests/fixtures/cf11-ordinary-try-list-generic/UpstreamNestedLoops.class',
     'cf11/UpstreamNestedLoops', 17, 17, 6, 71),
    ('tests/fixtures/cf11-ordinary-try-list-generic/admission/OrdinaryTryListFixture.class',
     'cf11/OrdinaryTryListFixture', 13, 13, 12, 50),
    ('tests/fixtures/forward-conditional-stack-carry/javac8/ForwardCarryProbe.class',
     'cf11/ForwardCarryProbe', 16, 16, 0, 12),
    ('tests/fixtures/forward-conditional-stack-carry/javac23/ForwardCarryProbe.class',
     'cf11/ForwardCarryProbe', 16, 16, 0, 12),
)


def load_auditor():
    sys.path.insert(0, str(BLAKE3_PATH))
    spec = importlib.util.spec_from_file_location('maintained_audit_candidate', AUDITOR)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def branch_targets(code, decode):
    """Return encoded branch/switch targets using only decoded instruction boundaries."""
    instructions = decode(code)
    starts = {bci for bci, _, _ in instructions}
    targets = []
    for bci, opcode, operand in instructions:
        if 0x99 <= opcode <= 0xa8 or opcode in (0xc6, 0xc7):
            offset = int.from_bytes(operand[-2:], 'big', signed=True)
            targets.append({'bci': bci, 'kind': 'branch', 'offset': offset, 'target': bci + offset})
        elif opcode in (0xc8, 0xc9):
            offset = int.from_bytes(operand[-4:], 'big', signed=True)
            targets.append({'bci': bci, 'kind': 'branch', 'offset': offset, 'target': bci + offset})
        elif opcode == 0xaa:
            payload = bci + 1 + ((4 - ((bci + 1) & 3)) & 3) - bci
            default = int.from_bytes(operand[payload:payload + 4], 'big', signed=True)
            low = int.from_bytes(operand[payload + 4:payload + 8], 'big', signed=True)
            high = int.from_bytes(operand[payload + 8:payload + 12], 'big', signed=True)
            targets.append({'bci': bci, 'kind': 'switch-default', 'offset': default,
                            'target': bci + default})
            for index, at in enumerate(range(payload + 12, len(operand), 4)):
                offset = int.from_bytes(operand[at:at + 4], 'big', signed=True)
                targets.append({'bci': bci, 'kind': 'switch-case', 'key': low + index,
                                'offset': offset, 'target': bci + offset})
            if high - low + 1 != len(operand[payload + 12:]) // 4:
                raise ValueError(f'malformed tableswitch at BCI {bci}')
        elif opcode == 0xab:
            payload = bci + 1 + ((4 - ((bci + 1) & 3)) & 3) - bci
            default = int.from_bytes(operand[payload:payload + 4], 'big', signed=True)
            pairs = int.from_bytes(operand[payload + 4:payload + 8], 'big', signed=True)
            targets.append({'bci': bci, 'kind': 'switch-default', 'offset': default,
                            'target': bci + default})
            for index in range(pairs):
                at = payload + 8 + 8 * index
                key = int.from_bytes(operand[at:at + 4], 'big', signed=True)
                offset = int.from_bytes(operand[at + 4:at + 8], 'big', signed=True)
                targets.append({'bci': bci, 'kind': 'switch-case', 'key': key,
                                'offset': offset, 'target': bci + offset})
            if len(operand) != payload + 8 + 8 * pairs:
                raise ValueError(f'malformed lookupswitch at BCI {bci}')
    invalid = [row for row in targets if row['target'] not in starts]
    if invalid:
        raise ValueError(f'control-flow target does not land on an instruction: {invalid!r}')
    return targets


def file_pin(path):
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def audit(auditor):
    decode = auditor.load_decoder(REFERENCE)
    class_rows = []
    totals = [0, 0, 0, 0, 0]
    for relpath, expected_owner, expected_methods, expected_bodies, expected_handlers, expected_targets in FIXTURES:
        path = REPO / relpath
        data = path.read_bytes()
        parsed = auditor.class_file(path)
        if parsed['owner'] != expected_owner:
            raise ValueError(f'{relpath}: owner {parsed["owner"]!r} != {expected_owner!r}')
        methods = []
        bodies = handlers = targets_count = subroutines = 0
        for key, method in sorted(parsed['methods'].items(), key=lambda pair: pair[1]['index']):
            code = method['code']
            if code is None:
                methods.append({'method': key, 'index': method['index'], 'has_code': False,
                                'handlers': 0, 'branch_targets': 0, 'jsr': 0})
                continue
            bodies += 1
            handlers += len(method['exceptions'])
            targets = branch_targets(code, decode)
            targets_count += len(targets)
            jsr_count = sum(1 for bci, opcode, _ in decode(code) if opcode in (0xa8, 0xc9))
            subroutines += jsr_count
            for start, end, handler, _catch_type in method['exceptions']:
                starts = {bci for bci, _, _ in decode(code)}
                if start not in starts or end <= start or (end != len(code) and end not in starts) or handler not in starts:
                    raise ValueError(f'{relpath}/{key}: invalid exception range/handler {(start, end, handler)!r}')
            methods.append({'method': key, 'index': method['index'], 'has_code': True,
                            'code_bytes': len(code), 'handlers': len(method['exceptions']),
                            'branch_targets': len(targets), 'jsr': jsr_count,
                            'targets': targets})
        expected = (expected_methods, expected_bodies, expected_handlers, expected_targets)
        actual = (len(parsed['methods']), bodies, handlers, targets_count)
        if actual != expected:
            raise ValueError(f'{relpath}: measured {actual!r}, expected fixture facts {expected!r}')
        if subroutines:
            raise ValueError(f'{relpath}: unexpected jsr/jsr_w count {subroutines}')
        totals[0] += 1
        totals[1] += bodies
        totals[2] += handlers
        totals[3] += targets_count
        totals[4] += subroutines
        class_rows.append({
            'fixture': relpath,
            'owner': parsed['owner'],
            'major': parsed['major'],
            'sha256': hashlib.sha256(data).hexdigest(),
            'blake3': auditor.class_digest(data),
            'bytes': len(data),
            'physical_method_count': len(parsed['methods']),
            'code_body_count': bodies,
            'handler_record_count': handlers,
            'normal_branch_target_count': targets_count,
            'jsr_instruction_count': subroutines,
            'methods': methods,
        })
    actual_delta = tuple(totals)
    if actual_delta != EXPECTED_DELTA:
        raise ValueError(f'four-class delta {actual_delta!r} != expected {EXPECTED_DELTA!r}')
    if tuple(old + add for old, add in zip(OLD_TUPLE, actual_delta)) != EXPECTED_NEW:
        raise ValueError('old tuple plus measured delta did not produce the expected new tuple')
    return {
        'four_class_delta': list(actual_delta),
        'prior_fixed_tuple': list(OLD_TUPLE),
        'derived_new_tuple': list(EXPECTED_NEW),
        'classes': class_rows,
        'maintained_auditor': file_pin(AUDITOR),
        'decoder_reference': str(REFERENCE.resolve()),
        'decoder_sha256': auditor.pin(REFERENCE / 'pinned-tools' /
            'jarde-computed-for-cf07-final-replay-verifier-root-v4-f30754e1e524.py')['sha256'],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=pathlib.Path,
                        default=BASE / 'tools-prep' / 'private-audits' / 'reader-fixture-census-v1.json')
    args = parser.parse_args()
    out = args.out.resolve()
    if out.exists():
        raise SystemExit('refuse overwrite: ' + str(out))
    sys.path.insert(0, str(BLAKE3_PATH))
    auditor = load_auditor()
    dependency_before = auditor.blake3_dependency()
    result = audit(auditor)
    if dependency_before != auditor.blake3_dependency():
        raise RuntimeError('maintained BLAKE3 dependency changed during audit')
    report = {
        'schema': 'reader-fixture-census-four-class-delta-v1',
        'status': 'accepted',
        'audited_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'auditor_script': file_pin(pathlib.Path(__file__)),
        'hash_dependency': dependency_before,
        'scope': 'four added classfiles only; branch target rows are decoded instruction offsets validated against instruction starts',
        'result': result,
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'report': str(out),
                      'delta': result['four_class_delta'], 'new_tuple': result['derived_new_tuple']}))


if __name__ == '__main__':
    main()
