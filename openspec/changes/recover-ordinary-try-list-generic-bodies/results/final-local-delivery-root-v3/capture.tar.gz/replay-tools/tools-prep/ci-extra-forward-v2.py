#!/usr/bin/env python3
"""Observe the CI ignored-runtime and public-example legs under the local JDK matrix.

This does not claim the exact GitHub Actions Temurin toolchain. It uses the local Java 25.0.4.1
runtime with the pinned native JDK 23.0.1 javac/javap PATH setup supplied by root. CI tree/closure
shell checks remain separate and are not replaced by this runner.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import time

BASE = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
ROOT = Path('/home/lordcasser/workspace/projects/jarde').resolve()
TOOLS = BASE / 'tools'
PREP = BASE / 'tools-prep'
GUARD_PATH = PREP / 'guard.py'
SCAN_PATH = PREP / 'target_scan.py'
CLOSURE_PATH = PREP / 'workspace_runner_forward_v3.py'
CI_PATH = ROOT / '.github/workflows/ci.yml'
JDK_MANIFEST = TOOLS / 'jdk-manifest.json'
JAVA_TOOL_PREFIX = TOOLS / 'java25-javac23-bin'
JDK23_BIN = TOOLS / 'jdk23/jdk-23.0.1/bin'
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3
SUMMARY_RE = re.compile(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;')
NAMED_RE = re.compile(r'^test (.+) \.\.\. (ok|ignored|FAILED)(?:, .*)?$', re.M)

# Exact CI selectors/filters are preserved. Cargo's JSON message format is inserted so the
# completed test executable can be identified and safely unlinked after each completed test.
CI_TEST_COMMANDS = [
    ('ignored-jdk25-instruction-oracle',
     ['cargo', 'test', '--test', 'jvm_bytecode_oracle', '--locked', '--', '--ignored', '--exact',
      'jdk25_instruction_boundaries_match_public_bytecode_inspection'],
     ['cargo', 'test', '--test', 'jvm_bytecode_oracle', '--locked', '--message-format=json', '--',
      '--ignored', '--exact', 'jdk25_instruction_boundaries_match_public_bytecode_inspection'],
     'jdk25_instruction_boundaries_match_public_bytecode_inspection'),
    ('ignored-p3-execution-comparison',
     ['cargo', 'test', '--test', 'p3_execution_comparison', '--locked', '--', '--ignored'],
     ['cargo', 'test', '--test', 'p3_execution_comparison', '--locked', '--message-format=json', '--', '--ignored'],
     None),
    ('ignored-functional-constructor-full-class',
     ['cargo', 'test', '-p', 'jarde-cli', '--test', 'json_cli', '--locked', '--', '--ignored', '--exact',
      'functional_constructor_arguments_replay_the_complete_class_on_both_jdks'],
     ['cargo', 'test', '-p', 'jarde-cli', '--test', 'json_cli', '--locked', '--message-format=json', '--',
      '--ignored', '--exact', 'functional_constructor_arguments_replay_the_complete_class_on_both_jdks'],
     'functional_constructor_arguments_replay_the_complete_class_on_both_jdks'),
    ('ignored-p3-bigdecimal-number-comparison',
     ['cargo', 'test', '--test', 'p3_bigdecimal_number_widening', '--locked', '--', '--ignored'],
     ['cargo', 'test', '--test', 'p3_bigdecimal_number_widening', '--locked', '--message-format=json', '--', '--ignored'],
     None),
    ('ignored-nested-int-array-oracle',
     ['cargo', 'test', '--test', 'p3_nested_int_array_compound_updates', '--locked', '--', '--ignored', '--exact',
      'nested_int_array_updates_match_the_frozen_runner_oracle'],
     ['cargo', 'test', '--test', 'p3_nested_int_array_compound_updates', '--locked', '--message-format=json', '--',
      '--ignored', '--exact', 'nested_int_array_updates_match_the_frozen_runner_oracle'],
     'nested_int_array_updates_match_the_frozen_runner_oracle'),
    ('ignored-returned-int-array-full-class',
     ['cargo', 'test', '--test', 'p3_nested_int_array_compound_updates', '--locked', '--', '--ignored', '--exact',
      'returned_int_array_updates_compile_and_execute_as_a_complete_class'],
     ['cargo', 'test', '--test', 'p3_nested_int_array_compound_updates', '--locked', '--message-format=json', '--',
      '--ignored', '--exact', 'returned_int_array_updates_compile_and_execute_as_a_complete_class'],
     'returned_int_array_updates_compile_and_execute_as_a_complete_class'),
]
CI_EXAMPLE_COMMANDS = [
    ('example-inspect-class-header',
     ['cargo', 'run', '--example', 'inspect_class_header', '--locked', '--',
      'tests/fixtures/historical/ecj-4.6.1/v52/HistoricalControlFlow.class']),
    ('example-resolve-and-analyze',
     ['cargo', 'run', '--example', 'resolve_and_analyze', '--locked', '--',
      'tests/fixtures/historical/ecj-4.6.1/v52/HistoricalControlFlow.class']),
]
CI_SHELL_LEGS_LEFT_FOR_ROOT = [
    'cargo tree --workspace --all-features --locked -e features plus exact grep/deny checks',
    'cargo tree --workspace --all-features --locked -e normal plus forbidden dependency grep',
    'CI layered crate dependency closure function over normal/all edges and all-features variants',
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def file_pin(path: Path) -> dict:
    info = path.lstat()
    resolved = path.resolve(strict=True)
    if not resolved.is_file():
        raise RuntimeError(f'expected regular tool/source file: {path}')
    return {
        'path': str(path), 'bytes': resolved.stat().st_size, 'sha256': sha256(resolved),
        'symlink': path.is_symlink(), 'link_target': os.readlink(path) if path.is_symlink() else None,
        'resolved_path': str(resolved), 'mode': stat.S_IMODE(info.st_mode),
    }


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper module: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def extract_json_test_artifacts(stdout_path: Path) -> list[dict]:
    result = []
    for line in stdout_path.read_text(encoding='utf-8', errors='replace').splitlines():
        if not line.startswith('{'):
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get('reason') == 'compiler-artifact' and event.get('profile', {}).get('test') and event.get('executable'):
            target = event.get('target', {})
            result.append({
                'package_id': event.get('package_id'), 'target_name': target.get('name'),
                'target_kind': target.get('kind'), 'executable': event['executable'],
            })
    return result


def unlink_completed_test_executable(root: Path, artifact: dict, command_index: int) -> dict:
    raw = Path(artifact['executable'])
    path = raw if raw.is_absolute() else root / raw
    deps = (root / 'target/debug/deps').resolve(strict=True)
    if path.is_symlink():
        raise RuntimeError(f'refusing linked test executable: {path}')
    if not isinstance(artifact.get('target_kind'), list) or 'test' not in artifact['target_kind']:
        raise RuntimeError(f'refusing non-test Cargo artifact: {artifact}')
    resolved = path.resolve(strict=True)
    info = resolved.lstat()
    if (resolved.parent != deps or not stat.S_ISREG(info.st_mode) or not info.st_mode & 0o111):
        raise RuntimeError(f'refusing out-of-scope/non-executable test artifact: {resolved}')
    item = {
        **artifact, 'path': str(resolved), 'bytes': info.st_size, 'sha256_before_unlink': sha256(resolved),
        'completed_command_index': command_index,
    }
    resolved.unlink()
    return item


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True, help='new private directory for raw evidence')
    args = parser.parse_args()
    out = args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing to overwrite existing evidence: {out}')
    if out.is_relative_to(ROOT):
        raise SystemExit('evidence output must stay outside the shared repository')
    if (ROOT / 'target').exists():
        raise SystemExit('fresh target preflight failed; wait until current workspace runner cleaned target')
    if shutil.disk_usage(ROOT).free < FREE_LIMIT:
        raise SystemExit('5 GiB free-space preflight failed')
    for path in (GUARD_PATH, SCAN_PATH, CLOSURE_PATH, CI_PATH, JDK_MANIFEST):
        if not path.is_file():
            raise SystemExit(f'required runner input missing: {path}')
    for path in (JAVA_TOOL_PREFIX, JDK23_BIN):
        if not path.is_dir():
            raise SystemExit(f'required local Java PATH directory missing: {path}')

    guard = load_module('ci_extra_guard', GUARD_PATH)
    scanner = load_module('ci_extra_scanner', SCAN_PATH)
    closure = load_module('ci_extra_closure', CLOSURE_PATH)
    # Patch the copied guard explicitly: its default root/stream format is for its old repo-local run.
    guard.ROOT = ROOT
    guard.OUT = out
    guard.FREE_LIMIT = FREE_LIMIT
    guard.TARGET_LIMIT = TARGET_LIMIT
    guard.expected_test_summaries = lambda _index, _stdout: None
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.command_stream = lambda path: {
        'path': str(Path(path).resolve()), 'bytes': Path(path).stat().st_size, 'sha256': sha256(Path(path))
    }
    closure.ROOT = ROOT
    source_paths = closure.source_paths()
    if not source_paths:
        raise RuntimeError('complete source closure unexpectedly empty')

    env = os.environ.copy()
    stripped_keys = []
    for key in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'JAVA_HOME',
                'RUST_MIN_STACK', 'CARGO_TARGET_DIR'):
        if key in env:
            env.pop(key)
            stripped_keys.append(key)
    env.update(guard.ENV_VALUES)
    env['RUSTUP_TOOLCHAIN'] = 'stable'
    env['PATH'] = str(JAVA_TOOL_PREFIX) + os.pathsep + str(JDK23_BIN) + os.pathsep + env.get('PATH', '')
    if 'RUST_MIN_STACK' in env:
        raise RuntimeError('RUST_MIN_STACK must stay unset for default thread stack')

    out.mkdir(parents=True, exist_ok=False)
    record = {
        'schema': 'ci-extra-forward-local-validation-v1',
        'status': 'running',
        'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'workspace_root': str(ROOT), 'output_root': str(out),
        'runner': file_pin(Path(__file__).resolve()),
        'helper_pins_before': {str(path): file_pin(path) for path in
                               (GUARD_PATH, SCAN_PATH, CLOSURE_PATH, CI_PATH, JDK_MANIFEST)},
        'tool_pins_before': {},
        'environment': {
            'overrides': {**guard.ENV_VALUES, 'RUSTUP_TOOLCHAIN': 'stable',
                          'PATH_prefix': [str(JAVA_TOOL_PREFIX), str(JDK23_BIN)]},
            'stripped_keys': stripped_keys, 'RUST_MIN_STACK': None,
            'PATH': env['PATH'],
            'java_environment_label': 'local Java 25.0.4.1 runtime + pinned JDK 23.0.1 javac/javap',
            'not_exact_CI_toolchain': 'CI is Temurin 25.0.4+7; local Java/JDK cells remain environment-specific',
            'toolprovider_release8_note': 'Any local Java 25 ToolProvider ctsym/release-8 failure is captured as observed; no workaround is applied.',
        },
        'source_manifest_before': {str(path.relative_to(ROOT)): sha256(path) for path in sorted(source_paths)},
        'ci_reference_tests': [{'label': label, 'argv': original, 'test_filter': selector}
                               for label, original, _json, selector in CI_TEST_COMMANDS],
        'ci_reference_examples': [{'label': label, 'argv': argv} for label, argv in CI_EXAMPLE_COMMANDS],
        'ci_shell_checks_not_run': CI_SHELL_LEGS_LEFT_FOR_ROOT,
        'commands': [], 'removed_completed_test_executables': [],
        'guards': {'minimum_free_bytes': FREE_LIMIT, 'maximum_target_bytes': TARGET_LIMIT,
                   'poll_seconds': 1, 'process_group_termination': True, 'default_stack': True},
        'final_cleanup': {'armed': True, 'argv': ['cargo', 'clean']},
    }

    def save() -> None:
        temporary = out / 'execution.json.tmp'
        temporary.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        temporary.replace(out / 'execution.json')

    def verify_sources(stage: str) -> None:
        current = {str(path.relative_to(ROOT)): sha256(path) for path in sorted(closure.source_paths())}
        if current != record['source_manifest_before']:
            record['source_change_detected_at'] = stage
            record['source_manifest_after'] = current
            raise RuntimeError(f'source closure changed at {stage}')

    def observe(index: int, label: str, argv: list[str], *, ci_argv: list[str] | None = None,
                selector: str | None = None, is_test: bool = False) -> dict:
        verify_sources(f'before-{index}')
        row = guard.run_command(index, argv, env)
        row['label'] = label
        record['commands'].append(row)
        save()
        row['ci_reference_argv'] = ci_argv
        if ci_argv is not None:
            row['cargo_json_message_format_added'] = True
        row['expected_exact_test_name'] = selector
        row['test_target'] = is_test
        raw = Path(row['streams']['stdout']['path']).read_text(encoding='utf-8', errors='replace')
        summaries = [{'status': m.group(1), 'passed': int(m.group(2)), 'failed': int(m.group(3)),
                      'ignored': int(m.group(4)), 'line': m.group(0)} for m in SUMMARY_RE.finditer(raw)]
        outcomes = [{'name': m.group(1), 'status': m.group(2), 'line': m.group(0)} for m in NAMED_RE.finditer(raw)]
        row['actual_test_summaries'] = summaries
        row['named_test_outcomes'] = outcomes
        if is_test:
            exact_ok = (selector is None or
                        sum(item['name'] == selector and item['status'] == 'ok' for item in outcomes) == 1)
            run_ok = bool(summaries) and all(x['status'] == 'ok' and x['failed'] == 0 for x in summaries)
            row['test_observation_check'] = {
                'has_summary': bool(summaries), 'all_summaries_ok': run_ok,
                'exact_selected_test_once_ok': exact_ok,
                'passed_total': sum(x['passed'] for x in summaries),
                'failed_total': sum(x['failed'] for x in summaries),
                'ignored_total': sum(x['ignored'] for x in summaries),
                'at_least_one_test_ran': sum(x['passed'] + x['failed'] for x in summaries) > 0,
                'no_ignored_tests_left_unrun': sum(x['ignored'] for x in summaries) == 0,
            }
            if row['exit_code'] is not None and row['guard_stop'] is None:
                artifacts = extract_json_test_artifacts(Path(row['streams']['stdout']['path']))
                if len(artifacts) != 1:
                    raise RuntimeError(f'{label}: expected exactly one completed test target artifact, got {artifacts}')
                expected_target = Path(ci_argv[ci_argv.index('--test') + 1]).stem if ci_argv and '--test' in ci_argv else None
                if expected_target and artifacts[0]['target_name'] != expected_target:
                    raise RuntimeError(f'{label}: Cargo artifact target {artifacts[0]["target_name"]!r} != {expected_target!r}')
                row['completed_test_artifacts'] = artifacts
                record['removed_completed_test_executables'].append(
                    unlink_completed_test_executable(ROOT, artifacts[0], index))
        save()
        verify_sources(f'after-{index}')
        return row

    overall_error = None
    try:
        record['tool_pins_before'] = collect_tool_pins()
        save()
        index = 1
        for label, ci_argv, json_argv, selector in CI_TEST_COMMANDS:
            row = observe(index, label, json_argv, ci_argv=ci_argv, selector=selector, is_test=True)
            index += 1
            if row['guard_stop'] is not None:
                overall_error = f'{label} stopped by resource guard'
                break
        if overall_error is None:
            for label, argv in CI_EXAMPLE_COMMANDS:
                row = observe(index, label, argv)
                index += 1
                if row['guard_stop'] is not None:
                    overall_error = f'{label} stopped by resource guard'
                    break
        failures = [row['label'] for row in record['commands']
                    if row['exit_code'] != 0 or row['guard_stop'] is not None
                    or (row.get('test_observation_check') and
                        (not row['test_observation_check']['has_summary']
                         or not row['test_observation_check']['all_summaries_ok']
                         or not row['test_observation_check']['exact_selected_test_once_ok']
                         or not row['test_observation_check']['at_least_one_test_ran']
                         or not row['test_observation_check']['no_ignored_tests_left_unrun']))]
        record['observed_failures'] = failures
        if overall_error:
            record['error'] = overall_error
        record['status'] = 'pending_independent_acceptance'
    except BaseException as e:
        overall_error = f'{type(e).__name__}: {e}'
        record['status'] = 'pending_independent_acceptance'
        record['error'] = overall_error
    finally:
        if out.exists():
            try:
                guard.FREE_LIMIT = 0
                guard.TARGET_LIMIT = sys.maxsize
                cleanup_index = len(record['commands']) + 1
                clean = guard.run_command(cleanup_index, ['cargo', 'clean'], env)
                clean['label'] = 'finally-exact-cargo-clean'
                clean['cleanup_only'] = {'exact_argv': ['cargo', 'clean']}
                record['commands'].append(clean)
                record['target_absent'] = not (ROOT / 'target').exists()
                record['final_cleanup']['row'] = clean
                if clean['exit_code'] != 0 or clean['guard_stop'] is not None or not record['target_absent']:
                    record['error'] = record.get('error', 'final cargo clean failed or target remains')
                    record['final_cleanup']['status'] = 'failed'
                else:
                    record['final_cleanup']['status'] = 'passed'
            except BaseException as e:
                record['final_cleanup']['status'] = 'failed-before-completion'
                record['final_cleanup']['error'] = f'{type(e).__name__}: {e}'
                record['status'] = 'pending_independent_acceptance'
            try:
                record['source_manifest_after'] = {
                    str(path.relative_to(ROOT)): sha256(path) for path in sorted(closure.source_paths())
                }
                record['source_manifest_unchanged'] = record['source_manifest_after'] == record['source_manifest_before']
            except BaseException as e:
                record['source_manifest_after_error'] = f'{type(e).__name__}: {e}'
                record['source_manifest_unchanged'] = False
            try:
                record['helper_pins_after'] = {str(path): file_pin(path) for path in
                                               (GUARD_PATH, SCAN_PATH, CLOSURE_PATH, CI_PATH, JDK_MANIFEST)}
                record['helper_pins_unchanged'] = record['helper_pins_after'] == record['helper_pins_before']
                record['tool_pins_after'] = collect_tool_pins()
                record['tool_pins_unchanged'] = record['tool_pins_after'] == record['tool_pins_before']
                record['runner_after'] = file_pin(Path(__file__).resolve())
                record['runner_unchanged'] = record['runner_after']['sha256'] == record['runner']['sha256']
            except BaseException as e:
                record['final_pin_error'] = f'{type(e).__name__}: {e}'
            record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
            save()
    print(json.dumps({'status': record['status'], 'commands': len(record['commands']),
                      'observed_failures': record.get('observed_failures'),
                      'cleanup': record.get('final_cleanup', {}).get('status'),
                      'target_absent': record.get('target_absent')}))
    return 0 if (not record.get('error')
                  and len(record['commands']) == len(CI_TEST_COMMANDS) + len(CI_EXAMPLE_COMMANDS) + 1
                  and record.get('final_cleanup', {}).get('status') == 'passed'
                  and not record.get('observed_failures')
                  and record.get('source_manifest_unchanged') is True
                  and record.get('helper_pins_unchanged') is True
                  and record.get('tool_pins_unchanged') is True
                  and record.get('runner_unchanged') is True) else 1


def collect_tool_pins() -> dict:
    manifest = json.loads(JDK_MANIFEST.read_text(encoding='utf-8'))
    javac23 = next(row for row in manifest['legs'] if row.get('leg') == 'javac23')
    expected_paths = {
        'java_launcher': JAVA_TOOL_PREFIX / 'java',
        'javac_launcher': JAVA_TOOL_PREFIX / 'javac',
        'jdk23_java': Path(javac23['jdk_tools']['java']['path']),
        'jdk23_javac': Path(javac23['jdk_tools']['javac']['path']),
        'jdk23_javap': Path(javac23['jdk_tools']['javap']['path']),
    }
    pins = {name: file_pin(path) for name, path in expected_paths.items()}
    for name in ('java', 'javac', 'javap'):
        expected = javac23['jdk_tools'][name]
        actual = pins[f'jdk23_{name}']
        if (actual['bytes'] != expected['bytes'] or actual['sha256'] != expected['sha256']
                or actual['path'] != expected['path']):
            raise RuntimeError(f'pinned JDK 23 {name} differs from the recorded manifest')
    pins['jdk_manifest'] = file_pin(JDK_MANIFEST)
    return pins


if __name__ == '__main__':
    raise SystemExit(main())
