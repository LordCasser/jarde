#!/usr/bin/env python3
"""Package the final forward-carry evidence after all named captures exist."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

BASE = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
PROJECT = Path('/home/lordcasser/workspace/projects/jarde')

# Each successful capture and its launch receipt are preserved independently.
CAPTURE_DIRS = (
    'focused-v12',
    'final-matrix-v3',
    'forward-order-v3',
    'workspace-forward-v6',
    'ci-extra-forward-v2',
    'ci-tree-forward-v1',
    'workspace-forward-v1-launch',
    'workspace-forward-v2', 'workspace-forward-v2-launch',
    'workspace-forward-v3', 'workspace-forward-v3-launch',
    'workspace-forward-v4', 'workspace-forward-v4-launch',
    'workspace-forward-v5', 'workspace-forward-v5-launch',
    'icn-current-control-v1',
)

# The frozen comparison fixture consists of three baseline and five admission
# files. Preserve their current repository bytes, plus the forward-order probe.
FIXTURE_PATHS = (
    'tests/fixtures/cf11-ordinary-try-list-generic/baseline/Runner.java',
    'tests/fixtures/cf11-ordinary-try-list-generic/baseline/UpstreamNestedLoops.java',
    'tests/fixtures/cf11-ordinary-try-list-generic/baseline/manifest.json',
    'tests/fixtures/cf11-ordinary-try-list-generic/admission/OrdinaryTryListFixture.class',
    'tests/fixtures/cf11-ordinary-try-list-generic/admission/OrdinaryTryListFixture.java',
    'tests/fixtures/cf11-ordinary-try-list-generic/admission/README.md',
    'tests/fixtures/cf11-ordinary-try-list-generic/admission/Runner.java',
    'tests/fixtures/cf11-ordinary-try-list-generic/admission/manifest.json',
    'tests/fixtures/forward-conditional-stack-carry/ForwardCarryProbe.java',
    'tests/fixtures/forward-conditional-stack-carry/Runner.java',
    'tests/fixtures/forward-conditional-stack-carry/README.md',
    'tests/fixtures/forward-conditional-stack-carry/pins.json',
    'tests/fixtures/forward-conditional-stack-carry/javac8/ForwardCarryProbe.class',
    'tests/fixtures/forward-conditional-stack-carry/javac23/ForwardCarryProbe.class',
)

SETUP_DIRS = ('java25-javac23-setup-v1', 'javac25-bridge-setup-v1')
PIN_FILES = (
    'baseline45/tool-references/external-tool-pins.json',
    'tools/jdk-manifest.json',
)
TOOL_SUFFIXES = {'.py', '.json', '.md', '.sh'}
FORBIDDEN_COMPONENTS = {
    'target', 'node_modules', 'jdk8', 'jdk23', 'jdk25-bin', 'jadx',
    'javac25-bridge', 'classes-install',
}
FORBIDDEN_SUFFIXES = {'.tar', '.gz', '.zip', '.exe', '.so', '.dll', '.dylib'}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def regular_bytes(path: Path) -> bytes:
    if path.is_symlink() or not path.is_file():
        raise ValueError(f'refusing non-regular evidence path: {path}')
    return path.read_bytes()


def safe_tree_files(root: Path):
    if root.is_symlink() or not root.is_dir():
        raise ValueError(f'refusing non-directory evidence path: {root}')
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if path.is_symlink():
            raise ValueError(f'refusing symlink in evidence tree: {path}')
        if any(part in FORBIDDEN_COMPONENTS or part.startswith('candidate-cli-')
               for part in rel.parts):
            continue
        if path.is_dir():
            continue
        if not path.is_file():
            raise ValueError(f'refusing non-regular evidence entry: {path}')
        if path.suffix.lower() in FORBIDDEN_SUFFIXES:
            continue
        yield path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', required=True, type=Path,
                        help='fresh destination directory; it must not exist')
    args = parser.parse_args()

    # Validate every required input before creating output or reading payloads.
    required = [BASE / name for name in CAPTURE_DIRS]
    required.append(BASE / 'final-matrix-v3/root-audit/audit.json')
    required.extend(PROJECT / name for name in FIXTURE_PATHS)
    required.extend(BASE / name for name in PIN_FILES)
    required.extend(BASE / name for name in SETUP_DIRS)
    missing = [str(path) for path in required
               if path.is_symlink() or not path.exists()]
    if missing:
        raise FileNotFoundError('archive inputs are incomplete:\n  ' + '\n  '.join(missing))

    out = args.out.expanduser().absolute()
    if out.exists():
        raise ValueError(f'refusing existing output directory: {out}')
    if any(part in FORBIDDEN_COMPONENTS for part in out.parts):
        raise ValueError(f'output path is inside an excluded installation area: {out}')

    members: dict[str, bytes] = {}
    origins: dict[str, str] = {}

    def add(name: str, source: Path) -> None:
        if name in members:
            raise ValueError(f'duplicate archive member: {name}')
        data = regular_bytes(source)
        members[name] = data
        origins[name] = str(source)

    for name in CAPTURE_DIRS:
        root = BASE / name
        for source in safe_tree_files(root):
            rel = source.relative_to(root).as_posix()
            add(f'evidence/{name}/{rel}', source)

    for rel in FIXTURE_PATHS:
        add(f'project/{rel}', PROJECT / rel)

    # Preserve setup receipts and small source artifacts, excluding installed
    # class trees and all JDK/JADX/CLI payloads.
    for name in SETUP_DIRS:
        root = BASE / name
        for source in safe_tree_files(root):
            if source.suffix.lower() == '.class':
                continue
            rel = source.relative_to(root).as_posix()
            add(f'setup/{name}/{rel}', source)
    for rel in PIN_FILES:
        add(f'tool-pins/{Path(rel).name}', BASE / rel)

    # CLI receipt fields are pins only; no candidate executable is read/copied.
    cli_refs: dict[str, object] = {}
    for capture in ('focused-v12', 'workspace-forward-v6'):
        receipt = members.get(f'evidence/{capture}/execution.json')
        if receipt is None:
            raise ValueError(f'missing execution receipt in {capture}')
        doc = json.loads(receipt)
        for key in ('candidate_cli', 'cli', 'cli_pin', 'cli_reference'):
            value = doc.get(key)
            if isinstance(value, dict) and value:
                cli_refs[capture + ':' + key] = value
        for mode, detail in doc.get('runtime_matrix_cli_references', {}).items():
            if isinstance(detail, dict) and isinstance(detail.get('cli'), dict):
                cli_refs[capture + ':runtime:' + mode] = detail['cli']
    if not cli_refs:
        raise ValueError('focused/workspace receipts contain no CLI pin fields')

    cli_pin_bytes = (json.dumps({'schema': 'jarde-final-forward-cli-pins-v1',
                                 'receipts': cli_refs}, ensure_ascii=False,
                                indent=2) + '\n').encode()
    members['tool-pins/cli-receipt-pins.json'] = cli_pin_bytes
    origins['tool-pins/cli-receipt-pins.json'] = 'derived from focused-v12/workspace-forward-v6 receipts'

    manifest = {
        'schema': 'jarde-final-forward-v3-archive-manifest-v1',
        'status': 'archived_pending_independent_acceptance',
        'evidence_sets': list(CAPTURE_DIRS),
        'source_fixture_paths': list(FIXTURE_PATHS),
        'excluded_payloads': ['JDK installations', 'JADX installation', 'CLI binaries',
                              'target directories', 'node_modules'],
        'members': [{'path': name, 'bytes': len(data), 'sha256': digest(data),
                     'source': origins[name]}
                    for name, data in sorted(members.items())],
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    archive_members = dict(members)
    archive_members['archive-manifest.json'] = manifest_bytes

    out.parent.mkdir(parents=True, exist_ok=True)
    out.mkdir()
    archive = out / 'capture.tar.gz'
    with archive.open('xb') as fileobj:
        with gzip.GzipFile(fileobj=fileobj, mode='wb', filename='', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as tar:
                for name, data in sorted(archive_members.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    tar.addfile(info, io.BytesIO(data))

    # Reopen and verify every payload byte, including the embedded manifest.
    with tarfile.open(archive, 'r:gz') as tar:
        entries = {entry.name: entry for entry in tar.getmembers() if entry.isfile()}
        if set(entries) != set(archive_members):
            raise ValueError('reopened archive member inventory differs')
        for name, expected in archive_members.items():
            stream = tar.extractfile(entries[name])
            actual = stream.read() if stream is not None else None
            if actual != expected:
                raise ValueError(f'reopened member differs: {name}')
            if name != 'archive-manifest.json':
                row = next(item for item in manifest['members'] if item['path'] == name)
                if len(actual) != row['bytes'] or digest(actual) != row['sha256']:
                    raise ValueError(f'reopened member pin differs: {name}')

    pins = {
        'schema': 'jarde-final-forward-v3-archive-pins-v1',
        'status': 'archived_pending_independent_acceptance',
        'archive': {'path': str(archive), 'bytes': archive.stat().st_size,
                    'sha256': digest(archive.read_bytes())},
        'manifest': {'member': 'archive-manifest.json', 'bytes': len(manifest_bytes),
                     'sha256': digest(manifest_bytes)},
        'member_count_excluding_manifest': len(members),
    }
    (out / 'archive-pins.json').write_text(
        json.dumps(pins, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(pins, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
