#!/usr/bin/env python3
"""Independent read-only acceptance for the six ignored-test/two-example local CI legs.

No toolchain or producer main is executed. Every ignored test selected by a whole-target
--ignored command is discovered from current pinned Rust source and required exactly once.
Only a new --out JSON file is written. This is local environment acceptance, not GitHub CI.
"""
from __future__ import annotations
import argparse, ast, datetime, hashlib, importlib.util, json, os, re, shlex, stat, sys, tomllib
from pathlib import Path
sys.dont_write_bytecode = True
BASE = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
ROOT = Path('/home/lordcasser/workspace/projects/jarde').resolve()
PREP = BASE / 'tools-prep'
RUNNER = PREP / 'ci-extra-forward-v2.py'
GUARD = PREP / 'guard.py'
SCANNER = PREP / 'target_scan.py'
CLOSURE = PREP / 'workspace_runner_forward_v3.py'
CI = ROOT / '.github/workflows/ci.yml'
MANIFEST = BASE / 'tools/jdk-manifest.json'
JAVA_PREFIX = BASE / 'tools/java25-javac23-bin'
JDK23_BIN = BASE / 'tools/jdk23/jdk-23.0.1/bin'
GUARD_SHA = 'a312c70cd7e4f15851d26dd27f51127d441ba5f886bc54c1118e6f533b5fdb39'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
CLOSURE_SHA = '8878f16875bdfbf32470a67890f68796f4ad085582e6841a88add8ab58199141'
FREE_LIMIT, TARGET_LIMIT = 5 * 1024**3, 1024**3
BASE_ENV = {'CARGO_BUILD_JOBS':'1', 'CARGO_INCREMENTAL':'0', 'CARGO_PROFILE_DEV_DEBUG':'0',
            'CARGO_PROFILE_TEST_DEBUG':'0', 'RUST_TEST_THREADS':'1', 'CARGO_TERM_COLOR':'always'}
STRIPPED = {'JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','JAVA_HOME','RUST_MIN_STACK','CARGO_TARGET_DIR'}
TESTS = [
 ('ignored-jdk25-instruction-oracle','jvm_bytecode_oracle',None,
  'jdk25_instruction_boundaries_match_public_bytecode_inspection','tests/jvm_bytecode_oracle.rs'),
 ('ignored-p3-execution-comparison','p3_execution_comparison',None,None,'tests/p3_execution_comparison.rs'),
 ('ignored-functional-constructor-full-class','json_cli','jarde-cli',
  'functional_constructor_arguments_replay_the_complete_class_on_both_jdks','crates/jarde-cli/tests/json_cli.rs'),
 ('ignored-p3-bigdecimal-number-comparison','p3_bigdecimal_number_widening',None,None,'tests/p3_bigdecimal_number_widening.rs'),
 ('ignored-nested-int-array-oracle','p3_nested_int_array_compound_updates',None,
  'nested_int_array_updates_match_the_frozen_runner_oracle','tests/p3_nested_int_array_compound_updates.rs'),
 ('ignored-returned-int-array-full-class','p3_nested_int_array_compound_updates',None,
  'returned_int_array_updates_compile_and_execute_as_a_complete_class','tests/p3_nested_int_array_compound_updates.rs'),
]
EXAMPLES = [('example-inspect-class-header','inspect_class_header'),
            ('example-resolve-and-analyze','resolve_and_analyze')]
EXAMPLE_INPUT = 'tests/fixtures/historical/ecj-4.6.1/v52/HistoricalControlFlow.class'
SHELL_LEGS = ['cargo tree --workspace --all-features --locked -e features plus exact grep/deny checks',
              'cargo tree --workspace --all-features --locked -e normal plus forbidden dependency grep',
              'CI layered crate dependency closure function over normal/all edges and all-features variants']
ANSI = re.compile(r'\x1b\[[0-9;]*m')
SUMMARY = re.compile(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',re.M)
NAMED = re.compile(r'^test ([^\n]+?) \.\.\. (?:(?!^test ).)*?\b(ok|ignored|FAILED)(?:, [^\n]*)?$',re.M|re.S)
RUNNING = re.compile(r'^\s*Running\b[^\n]*\(([^()\s]+)\)\s*$',re.M)
COUNT = re.compile(r'^running (\d+) tests?$',re.M)


def need(condition, message):
 if not condition: raise ValueError(message)


def sha(data): return hashlib.sha256(data).hexdigest()


def file_pin(path):
 path=Path(path); info=path.lstat(); resolved=path.resolve(strict=True)
 need(resolved.is_file(),'pin is not a regular file: '+str(path))
 return {'path':str(path),'bytes':resolved.stat().st_size,'sha256':sha(resolved.read_bytes()),
         'symlink':path.is_symlink(),'link_target':os.readlink(path) if path.is_symlink() else None,
         'resolved_path':str(resolved),'mode':stat.S_IMODE(info.st_mode)}


def check_live_pin(meta):
 need(isinstance(meta,dict) and isinstance(meta.get('path'),str),'malformed live file pin')
 need(meta==file_pin(meta['path']),'live full file/link/mode pin differs: '+meta['path'])


def command_spec():
 tests=[]
 for label,target,package,selector,_source in TESTS:
  base=['cargo','test']+(['-p',package] if package else [])+['--test',target,'--locked']
  tail=['--','--ignored']+(['--exact',selector] if selector else [])
  tests.append({'label':label,'ci_argv':base+tail,'argv':base+['--message-format=json']+tail,'selector':selector})
 examples=[{'label':label,'argv':['cargo','run','--example',name,'--locked','--',EXAMPLE_INPUT]}
           for label,name in EXAMPLES]
 return tests,examples


def rust_mask(text):
 """Mask strings/comments while preserving Rust attribute/header positions and line breaks."""
 out=list(text); i=0; n=len(text)
 def blank(a,b):
  for k in range(a,b):
   if out[k]!='\n':out[k]=' '
 while i<n:
  if text.startswith('//',i):
   end=text.find('\n',i+2); end=n if end<0 else end; blank(i,end);i=end;continue
  if text.startswith('/*',i):
   start=i;i+=2;depth=1
   while i<n and depth:
    if text.startswith('/*',i):depth+=1;i+=2
    elif text.startswith('*/',i):depth-=1;i+=2
    else:i+=1
   need(depth==0,'unterminated Rust block comment');blank(start,i);continue
  raw=re.match(r'(?:b)?r(#+)?"',text[i:]) if i==0 or not (text[i-1].isalnum() or text[i-1]=='_') else None
  if raw:
   start=i; hashes=raw.group(1) or '';i+=raw.end();ending='"'+hashes;end=text.find(ending,i)
   need(end>=0,'unterminated Rust raw string');i=end+len(ending);blank(start,i);continue
  if text[i]=='"':
   start=i;i+=1
   while i<n:
    if text[i]=='\\':i+=2
    elif text[i]=='"':i+=1;break
    else:i+=1
   need(i<=n and text[i-1]=='"','unterminated Rust quoted string');blank(start,i);continue
  char=re.match(r"'(?:\\(?:u\{[^}]+\}|x[0-9a-fA-F]{2}|.)|[^'\n])'",text[i:])
  if char:blank(i,i+char.end());i+=char.end();continue
  i+=1
 return ''.join(out)


def ignored_tests_from_source(path):
 masked=rust_mask(Path(path).read_text(encoding='utf-8'))
 headers=re.compile(r'((?:#\s*\[[^\]]*\]\s*)+)\s*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?fn\s+(\w+)\s*\(')
 names=[];covered=[]
 for match in headers.finditer(masked):
  attrs=match.group(1)
  if not re.search(r'#\s*\[\s*ignore\b',attrs):continue
  need(re.search(r'#\s*\[\s*test\s*\]',attrs) is not None,'ignore attribute is not paired with a #[test]')
  need(not re.search(r'#\s*\[\s*cfg(?:_attr)?\b',attrs),'conditional ignored-test attributes require explicit review')
  # Current CI files define these functions at file scope. Refuse a newly nested module
  # rather than silently mis-spelling its libtest-qualified name.
  prefix=masked[:match.start()]
  need(prefix.count('{')==prefix.count('}'),'nested ignored test needs explicit qualified-name review')
  names.append(match.group(2));covered.append((match.start(),match.end()))
 occurrences=list(re.finditer(r'#\s*\[\s*ignore\b',masked))
 need(len(occurrences)==len(names) and all(any(a<=m.start()<b for a,b in covered) for m in occurrences),
      'not every ignored-test attribute was accounted for by the source parser')
 need(names and len(names)==len(set(names)),'empty or duplicated ignored-test source set')
 return sorted(names)


def check_raw_tests(stdout, stderr, expected_names, expected_target, source_path):
 text=ANSI.sub('',stdout.decode('utf-8','replace'));err=ANSI.sub('',stderr.decode('utf-8','replace'))
 summaries=list(SUMMARY.finditer(text)); outcomes=list(NAMED.finditer(text));counts=list(COUNT.finditer(text))
 need(len(summaries)==len(counts)==1,'ignored-test command must have one complete target suite')
 summary=summaries[0];status,ps,fail,ign=summary.groups();ps,fail,ign=map(int,(ps,fail,ign))
 need(status=='ok' and fail==ign==0 and ps==len(expected_names),'ignored-test raw totals are not exact all-pass/no-ignored')
 actual=[{'name':m.group(1),'status':m.group(2)} for m in outcomes]
 need(len(actual)==len(expected_names)==int(counts[0].group(1)) and len({x['name'] for x in actual})==len(actual),
      'ignored-test named/count cardinality differs')
 need({x['name'] for x in actual}==set(expected_names) and all(x['status']=='ok' for x in actual),
      'whole ignored-test set was not executed exactly once and passing')
 need(all(counts[0].end()<=m.start()<summary.start() for m in outcomes),'named test lies outside its suite boundaries')
 artifacts=[]
 for line in stdout.decode('utf-8','replace').splitlines():
  if not line.startswith('{'):continue
  event=json.loads(line)
  if event.get('reason')=='compiler-artifact' and event.get('profile',{}).get('test') is True and event.get('executable'):
   target=event.get('target',{})
   need(target.get('name')==expected_target and target.get('kind')==['test'] and Path(target.get('src_path','')).resolve()==source_path.resolve(),
        'Cargo test artifact target/source identity differs')
   executable=Path(event['executable']);executable=executable if executable.is_absolute() else ROOT/executable
   need(executable.parent.resolve()==(ROOT/'target/debug/deps').resolve(),'Cargo test artifact executable escaped deps')
   owner=source_path.parent
   while owner.is_relative_to(ROOT) and not (owner/'Cargo.toml').is_file():owner=owner.parent
   need(owner.is_relative_to(ROOT) and (owner/'Cargo.toml').is_file(),'test artifact has no repository Cargo owner')
   package=tomllib.loads((owner/'Cargo.toml').read_text())['package']
   ids={'path+'+owner.as_uri()+'#'+package['version'],
        'path+'+owner.as_uri()+'#'+package['name']+'@'+package['version']}
   need(event.get('package_id') in ids,'physical Cargo package identity differs from repository manifest')
   artifacts.append({'package_id':event.get('package_id'),'target_name':target.get('name'),
                     'target_kind':target.get('kind'),'executable':event['executable']})
 need(len(artifacts)==1,'ignored command must have exactly one physical Cargo test artifact')
 running=list(RUNNING.finditer(err));need(len(running)==1,'test stderr lacks one Running executable')
 ran=Path(running[0].group(1));ran=ran if ran.is_absolute() else ROOT/ran
 expected=Path(artifacts[0]['executable']);expected=expected if expected.is_absolute() else ROOT/expected
 need(ran.resolve()==expected.resolve(),'stderr Running target differs from physical compiler-artifact')
 return {'summary':{'status':status,'passed':ps,'failed':fail,'ignored':ign},'named':actual,'artifacts':artifacts}


def check_sources(execution):
 need(execution.get('source_manifest_unchanged') is True and execution.get('source_manifest_before')==execution.get('source_manifest_after'),
      'source closure changed during CI-extra run')
 # Load only the fixed, hashed full-closure helper; its main is never called.
 spec=importlib.util.spec_from_file_location('ci_accept_pure_closure',CLOSURE)
 need(spec and spec.loader,'cannot load source closure helper')
 mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);mod.ROOT=ROOT
 paths=mod.source_paths();live={str(path.relative_to(ROOT)):sha(path.read_bytes()) for path in sorted(paths)}
 need(live==execution['source_manifest_before'],'live source closure differs from CI-extra receipt')
 return live


def check_inputs_and_environment(execution, runner_sha):
 need(execution.get('runner_unchanged') is True and execution.get('runner')==execution.get('runner_after'),
      'CI-extra runner changed during execution')
 need(execution['runner']==file_pin(RUNNER) and sha(RUNNER.read_bytes())==runner_sha,'producer runner live pin differs')
 helpers=execution.get('helper_pins_before')
 expected=[GUARD,SCANNER,CLOSURE,CI,MANIFEST]
 need(isinstance(helpers,dict) and set(helpers)=={str(p) for p in expected}
      and helpers==execution.get('helper_pins_after') and execution.get('helper_pins_unchanged') is True,
      'complete helper pin set absent, changed, or extra')
 for meta in helpers.values():check_live_pin(meta)
 need(sha(GUARD.read_bytes())==GUARD_SHA and sha(SCANNER.read_bytes())==SCANNER_SHA and sha(CLOSURE.read_bytes())==CLOSURE_SHA,
      'independent guard/scanner/closure pins differ')
 tool_pins=execution.get('tool_pins_before')
 need(isinstance(tool_pins,dict) and tool_pins==execution.get('tool_pins_after') and execution.get('tool_pins_unchanged') is True,
      'tool pins changed or absent')
 manifest=json.loads(MANIFEST.read_text());legs=[x for x in manifest['legs'] if x.get('leg')=='javac23']
 need(len(legs)==1,'JDK23 manifest leg not unique');jdk=legs[0]['jdk_tools']
 expected_paths={'java_launcher':JAVA_PREFIX/'java','javac_launcher':JAVA_PREFIX/'javac',
                 'jdk23_java':Path(jdk['java']['path']),'jdk23_javac':Path(jdk['javac']['path']),
                 'jdk23_javap':Path(jdk['javap']['path']),'jdk_manifest':MANIFEST}
 need(set(tool_pins)==set(expected_paths),'complete local Java tool pin set differs')
 for name,path in expected_paths.items():
  need(tool_pins[name].get('path')==str(path),'Java tool pin path differs '+name);check_live_pin(tool_pins[name])
 for name in ('java','javac','javap'):
  meta=tool_pins['jdk23_'+name];need(meta['path']==jdk[name]['path'] and meta['bytes']==jdk[name]['bytes'] and meta['sha256']==jdk[name]['sha256'],
                                 'native JDK23 tool differs from independent manifest '+name)
 env=execution.get('environment',{});prefix=[str(JAVA_PREFIX),str(JDK23_BIN)]
 need(env.get('overrides')=={**BASE_ENV,'RUSTUP_TOOLCHAIN':'stable','PATH_prefix':prefix},'declared stable/Java PATH environment differs')
 need(env.get('RUST_MIN_STACK') is None and isinstance(env.get('PATH'),str)
      and env['PATH'].split(os.pathsep)[:2]==prefix,'default stack or actual Java PATH prefix differs')
 stripped=env.get('stripped_keys')
 need(isinstance(stripped,list) and len(stripped)==len(set(stripped)) and set(stripped)<=STRIPPED,'stripped environment record differs')
 need(isinstance(env.get('not_exact_CI_toolchain'),str) and env['not_exact_CI_toolchain'],
      'local Java toolchain distinction from exact CI is not stated')
 return tool_pins


def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--execution',type=Path,default=BASE/'ci-extra-forward-v2/execution.json')
 ap.add_argument('--execution-sha256',required=True)
 ap.add_argument('--runner-sha256',required=True)
 ap.add_argument('--out',type=Path,required=True)
 a=ap.parse_args();ep=a.execution.resolve(strict=True);out=a.out.resolve()
 need(not out.exists() and not out.is_relative_to(ROOT),'acceptance output must be a new private JSON file')
 need(not ep.is_relative_to(ROOT),'CI-extra capture must stay outside shared repository')
 raw=ep.read_bytes();need(sha(raw)==a.execution_sha256,'CI-extra receipt hash differs');e=json.loads(raw)
 need(e.get('schema')=='ci-extra-forward-local-validation-v1' and e.get('status')=='pending_independent_acceptance',
      'CI-extra schema/status incomplete')
 need('error' not in e and e.get('observed_failures')==[],'CI-extra recorded failures/errors forbid acceptance')
 for key in ('source_manifest_after_error','source_change_detected_at','final_pin_error'):
  need(key not in e,'CI-extra recorded error field: '+key)
 need(Path(e.get('workspace_root','')).resolve()==ROOT and Path(e.get('output_root','')).resolve()==ep.parent,
      'CI-extra ROOT/output binding differs')
 need(e.get('guards')=={'minimum_free_bytes':FREE_LIMIT,'maximum_target_bytes':TARGET_LIMIT,
                       'poll_seconds':1,'process_group_termination':True,'default_stack':True},'CI-extra guard/default-stack protocol differs')
 tools=check_inputs_and_environment(e,a.runner_sha256);live=check_sources(e)
 test_specs,example_specs=command_spec()
 need(e.get('ci_reference_tests')==[{'label':x['label'],'argv':x['ci_argv'],'test_filter':x['selector']} for x in test_specs],
      'six exact original CI test references differ')
 need(e.get('ci_reference_examples')==example_specs,'two exact original CI example references differ')
 ci_text=CI.read_text()
 for spec in test_specs+example_specs:
  argv=spec.get('ci_argv',spec['argv']);need(shlex.join(argv) in ci_text,'exact command no longer occurs in pinned CI YAML')
 need(e.get('ci_shell_checks_not_run')==SHELL_LEGS,'separate CI shell leg boundary differs')
 commands=e.get('commands');need(isinstance(commands,list) and len(commands)==9,'six tests + two examples + clean not complete')
 raw_paths=set();observations=[];named_total=0
 ignored_by_source={source:ignored_tests_from_source(ROOT/source) for _,_,_,_,source in TESTS}
 for index,row in enumerate(commands,1):
  need(row.get('index')==index and row.get('exit_code')==0 and row.get('guard_stop') is None,
       'CI-extra command failed/guard stopped/index gap at '+str(index))
  need(Path(row.get('cwd','')).resolve()==ROOT and row.get('env_overrides')==BASE_ENV,
       'CI-extra command cwd/required Cargo environment differs')
  need(set(row.get('streams',{}))=={'stdout','stderr'},'CI-extra command requires exact dual raw streams')
  streams={}
  for name,meta in row['streams'].items():
   path=Path(meta['path']);need(not path.is_symlink() and path.is_file() and path.resolve().parent==ep.parent,
                              'raw stream missing/linked/outside capture')
   need(path.name==str(index)+'.'+name+'.raw','raw stream command/index binding differs')
   data=path.read_bytes();need(len(data)==meta['bytes'] and sha(data)==meta['sha256'],'raw stream byte/hash differs')
   need(path.resolve() not in raw_paths,'raw stream reused across commands');raw_paths.add(path.resolve());streams[name]=data
  if index<=8:
   need(type(row.get('peak_target_bytes')) is int and 0<=row['peak_target_bytes']<=TARGET_LIMIT
        and type(row.get('free_bytes_after')) is int and row['free_bytes_after']>=FREE_LIMIT,
        'guarded CI-extra command exceeded resource limits')
  if index<=6:
   spec=test_specs[index-1];label,target,package,selector,source=TESTS[index-1]
   need(row.get('label')==label and row.get('argv')==spec['argv'] and row.get('ci_reference_argv')==spec['ci_argv']
        and row.get('expected_exact_test_name')==selector and row.get('test_target') is True
        and row.get('cargo_json_message_format_added') is True,'CI test execution/reference argv/filter differs')
   all_names=ignored_by_source[source]
   need(selector is None or selector in all_names,'exact filter is not an actual ignored repository test')
   expected=[selector] if selector else all_names
   observed=check_raw_tests(streams['stdout'],streams['stderr'],expected,target,ROOT/source)
   stored=[{k:x.get(k) for k in ('status','passed','failed','ignored')} for x in row.get('actual_test_summaries',[])]
   need(stored==[observed['summary']],'producer test summary differs from independently parsed raw stdout')
   named=[{k:x.get(k) for k in ('name','status')} for x in row.get('named_test_outcomes',[])]
   need(named==observed['named'],'producer named test outcomes differ from raw stdout')
   need(row.get('completed_test_artifacts')==observed['artifacts'],'completed test artifact differs from raw compiler JSON')
   check=row.get('test_observation_check');want={'has_summary':True,'all_summaries_ok':True,'exact_selected_test_once_ok':True,
         'passed_total':len(expected),'failed_total':0,'ignored_total':0,'at_least_one_test_ran':True,'no_ignored_tests_left_unrun':True}
   need(check==want,'producer test-observation check differs from exact independently required set')
   named_total+=len(expected);observations.append({'label':label,'argv':spec['argv'],'ignored_names_from_source':all_names,
                                                'required_names':expected,**observed})
  elif index<=8:
   spec=example_specs[index-7]
   need(row.get('label')==spec['label'] and row.get('argv')==spec['argv'] and row.get('ci_reference_argv') is None
        and row.get('expected_exact_test_name') is None and row.get('test_target') is False,
        'CI public example execution argv/identity differs')
   need(row.get('actual_test_summaries')==[] and row.get('named_test_outcomes')==[],
        'example unexpectedly carries a libtest suite')
   observations.append({'label':spec['label'],'argv':spec['argv'],'exit_code':0})
  else:
   cleanup=e.get('final_cleanup',{})
   need(row.get('label')=='finally-exact-cargo-clean' and row.get('argv')==['cargo','clean']
        and row.get('cleanup_only')=={'exact_argv':['cargo','clean']},'final command is not exact cleanup')
   need(cleanup.get('armed') is True and cleanup.get('argv')==['cargo','clean'] and cleanup.get('status')=='passed'
        and cleanup.get('row')==row and 'error' not in cleanup,'nested final cleanup does not match actual successful row')
 need(len(raw_paths)==18 and {p.resolve() for p in ep.parent.glob('*.raw')}==raw_paths,'raw dual-stream inventory missing/unreferenced')
 need(e.get('target_absent') is True and not (ROOT/'target').exists(),'finally cleanup left workspace target present')
 removed=e.get('removed_completed_test_executables')
 need(isinstance(removed,list) and len(removed)==6,'test executable removal record incomplete')
 for i,item in enumerate(removed,1):
  physical=observations[i-1]['artifacts'][0]
  need(all(item.get(key)==value for key,value in physical.items()),'removed executable does not match independently parsed artifact')
  expected=Path(physical['executable']);expected=expected if expected.is_absolute() else ROOT/expected
  need(Path(item.get('path','')).resolve()==expected.resolve(),'removed executable path differs from raw artifact')
  need(item.get('completed_command_index')==i and item.get('target_name')==TESTS[i-1][1]
       and item.get('target_kind')==['test'] and Path(item.get('path','')).parent.resolve()==(ROOT/'target/debug/deps').resolve()
       and type(item.get('bytes')) is int and item['bytes']>0 and re.fullmatch('[0-9a-f]{64}',item.get('sha256_before_unlink','')),
       'completed physical test removal provenance differs')
 result={'schema':'ci-extra-forward-independent-acceptance-v1','status':'accepted_local_ci_extra_legs_only',
         'not_exact_GitHub_CI_or_release_acceptance':True,'execution_sha256':a.execution_sha256,
         'runner_sha256':a.runner_sha256,'acceptor_sha256':sha(Path(__file__).read_bytes()),
         'accepted_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_closure_count':len(live),
         'command_count':9,'raw_stream_count':18,'selected_ignored_tests_passed':named_total,
         'test_and_example_observations':observations,'tool_pins':tools,
         'environment':e['environment'],'native_Rust_execution_identity_verified':False,
         'native_Rust_identity_scope':'runner declares stable; native Cargo/rustc executable resolution is not recorded',
         'target_absent':True,'CI_shell_legs_not_replaced':SHELL_LEGS}
 out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2));return 0


if __name__=='__main__':
 try:raise SystemExit(main())
 except Exception as exc:print('acceptance failed: '+type(exc).__name__+': '+str(exc),file=sys.stderr);raise SystemExit(1)
