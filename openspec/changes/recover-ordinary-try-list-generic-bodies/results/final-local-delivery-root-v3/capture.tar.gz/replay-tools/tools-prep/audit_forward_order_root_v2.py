#!/usr/bin/env python3
"""Independent read-only audit for the forward-order-v3 full-class capture.

This verifier consumes the saved execution receipt, its 32 raw streams, the four
render documents/sources, the six compiled class trees, and the accepted original
class files. It never launches javac, java, Jarde, or another workflow. Physical
class decoding, the BCI decoder, and method source-map checks are reused from the
maintained ordinary-try-list candidate auditor; this file does not implement a
classfile parser, instruction decoder, or hash algorithm.
"""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
import pathlib
import sys

sys.dont_write_bytecode = True

BASE = pathlib.Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
REPO = pathlib.Path('/home/lordcasser/workspace/projects/jarde')
REFERENCE = BASE / 'baseline45'
AUDITOR = BASE / 'review' / 'audit_candidate.py'
BLAKE3_PATH = BASE / 'tools' / 'pythonlib'
JDK_MANIFEST = BASE / 'tools' / 'jdk-manifest.json'
CLASS_NAME = 'cf11.ForwardCarryProbe'
RUNNER_NAME = 'cf11.Runner'
EXPECTED_LABELS = [
    f'{jdk}-{phase}'
    for jdk in ('javac8', 'javac23')
    for phase in ('original-compile', 'original-run', 'default-render',
                  'default-compile', 'default-run', 'all-render',
                  'all-compile', 'all-run')
]


def load_candidate_auditor():
    if not AUDITOR.is_file():
        raise FileNotFoundError(AUDITOR)
    sys.path.insert(0, str(BLAKE3_PATH))
    spec = importlib.util.spec_from_file_location('maintained_audit_candidate', AUDITOR)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_json(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8'))


def require(condition, message, errors):
    if not condition:
        errors.append(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    path = pathlib.Path(path)
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': sha(data)}


def verify_pin(meta, label, errors, expected_path=None):
    path = pathlib.Path(meta['path'] if expected_path is None else expected_path)
    actual = pin(path)
    require(actual['bytes'] == meta.get('bytes') and actual['sha256'] == meta.get('sha256'),
            f'{label}: bytes/SHA-256 pin differs ({path})', errors)
    if expected_path is not None:
        require(path.resolve() == pathlib.Path(meta['path']).resolve(),
                f'{label}: recorded path differs ({path})', errors)
    return path


def safe_capture_path(capture, path, label, errors):
    path = pathlib.Path(path).resolve()
    require(path.is_relative_to(capture.resolve()), f'{label}: path escapes capture ({path})', errors)
    return path


def audit(capture, errors):
    capture = capture.resolve()
    receipt_path = capture / 'execution.json'
    receipt = read_json(receipt_path)
    require(receipt.get('status') == 'whole_probe_compile_runtime_matches_original',
            'execution receipt did not finish the complete probe', errors)
    require(receipt.get('target_absent') is True and not (REPO / 'target').exists(),
            'workspace target is present; capture did not preserve the target-absent condition', errors)
    require(len(receipt.get('commands', [])) == 16, 'receipt must record exactly 16 commands', errors)

    commands = receipt.get('commands', [])
    labels = [row.get('label') for row in commands]
    require(labels == EXPECTED_LABELS, 'command labels/order differ from the 16-cell matrix', errors)
    require([row.get('index') for row in commands] == list(range(1, 17)),
            'command indices are not the complete 1..16 sequence', errors)
    by_label = {row.get('label'): row for row in commands}
    require(len(by_label) == len(commands), 'command labels are duplicated', errors)

    raw_bytes = {}
    for row in commands:
        label = row.get('label', '<unknown>')
        require(row.get('exit_code') == 0 and row.get('guard_stop') is None,
                f'{label}: command failed or guard stopped it', errors)
        streams = row.get('streams', {})
        for stream in ('stdout', 'stderr'):
            meta = streams.get(stream)
            if not isinstance(meta, dict):
                errors.append(f'{label}: {stream} raw pin absent')
                continue
            path = safe_capture_path(capture, meta['path'], f'{label}/{stream}', errors)
            verify_pin(meta, f'{label}/{stream}', errors, path)
            raw_bytes[(label, stream)] = path.read_bytes()
        if label.endswith('-compile') and label.startswith('javac23-'):
            known_warnings = (
                b'warning: [options] bootstrap class path is not set in conjunction with -source 8\n'
                b'  not setting the bootstrap class path may lead to class files that cannot run on JDK 8\n'
                b'    --release 8 is recommended instead of -source 8 -target 8 because it sets the bootstrap class path automatically\n'
                b'warning: [options] source value 8 is obsolete and will be removed in a future release\n'
                b'warning: [options] target value 8 is obsolete and will be removed in a future release\n'
                b'warning: [options] To suppress warnings about obsolete options, use -Xlint:-options.\n'
                b'4 warnings\n'
            )
            require(raw_bytes.get((label, 'stderr')) == known_warnings,
                    f'{label}: compiler stderr differs from the pinned source/target-8 options warnings', errors)
        else:
            require(not raw_bytes.get((label, 'stderr'), b''), f'{label}: stderr is not empty', errors)

    # The captured sources must remain exactly the immutable inputs, before and after.
    before = receipt.get('inputs')
    after = receipt.get('inputs_after')
    require(isinstance(before, list) and len(before) == 2 and before == after,
            'input pins changed or are not the exact two source files', errors)
    source_inputs = {}
    for meta in before or []:
        path = verify_pin(meta, 'input source', errors)
        source_inputs[path.name] = path.read_bytes()
    require(set(source_inputs) == {'ForwardCarryProbe.java', 'Runner.java'},
            'input inventory is not exactly the probe and Runner source', errors)

    runner_meta = receipt.get('runner')
    if isinstance(runner_meta, dict):
        verify_pin(runner_meta, 'forward-order runner', errors,
                   BASE / 'tools' / 'run_forward_order.py')
    else:
        errors.append('forward-order runner pin absent')
    cli_meta = receipt.get('cli')
    if isinstance(cli_meta, dict):
        cli = verify_pin(cli_meta, 'frozen CLI', errors)
        require(os.access(cli, os.X_OK), 'recorded CLI is not executable', errors)
    else:
        errors.append('frozen CLI pin absent')

    # Bind each observed javac/java executable to the maintained manifest and exact argv.
    manifest_pin = pin(JDK_MANIFEST)
    manifest = read_json(JDK_MANIFEST)
    legs = {entry['leg']: entry for entry in manifest.get('legs', [])}
    require(set(legs) == {'javac8', 'javac23'}, 'JDK manifest does not contain exactly javac8/javac23', errors)
    tool_audit = {'manifest': manifest_pin, 'legs': {}}
    for jdk in ('javac8', 'javac23'):
        entry = legs.get(jdk)
        if not entry:
            continue
        tool_audit['legs'][jdk] = {}
        for tool in ('javac', 'java'):
            meta = entry['jdk_tools'][tool]
            path = verify_pin(meta, f'{jdk} {tool} manifest tool', errors)
            tool_audit['legs'][jdk][tool] = pin(path)

    # Check the receipt's argv against the bound JDK and CLI paths, not just its exit codes.
    for jdk in ('javac8', 'javac23'):
        if jdk not in tool_audit['legs']:
            continue
        home = pathlib.Path(tool_audit['legs'][jdk]['java']['path']).resolve().parent.parent
        javac = tool_audit['legs'][jdk]['javac']['path']
        java = tool_audit['legs'][jdk]['java']['path']
        leg_root = capture / jdk
        original_root = leg_root / 'original'
        empty = leg_root / 'empty'
        for phase in ('original-compile', 'original-run', 'default-render',
                      'default-compile', 'default-run', 'all-render',
                      'all-compile', 'all-run'):
            label = jdk + '-' + phase
            row = by_label.get(label)
            if not row:
                continue
            argv = row.get('argv', [])
            if phase == 'original-compile':
                expected = [javac, '-g', '-source', '8', '-target', '8', '-encoding', 'UTF-8',
                            '-classpath', str(empty), '-sourcepath', str(empty), '-d', str(original_root),
                            str(pathlib.Path(next(m['path'] for m in before if pathlib.Path(m['path']).name == 'ForwardCarryProbe.java')).resolve()),
                            str(pathlib.Path(next(m['path'] for m in before if pathlib.Path(m['path']).name == 'Runner.java')).resolve())]
            elif phase == 'original-run':
                expected = [java, '-Xverify:all', '-cp', str(original_root), RUNNER_NAME]
            elif phase.endswith('-render'):
                mode = phase.split('-', 1)[0]
                expected = [str(pathlib.Path(cli_meta['path']).resolve()), 'class-source', '--input',
                            str(original_root / 'cf11' / 'ForwardCarryProbe.class'), '--class', CLASS_NAME,
                            '--policy', 'single-class', '--release', '8', '--format', 'json']
                if mode == 'all':
                    expected += ['--evidence', 'all']
            elif phase.endswith('-compile'):
                mode = phase.split('-', 1)[0]
                mode_root = leg_root / mode
                output = mode_root / 'classes'
                expected = [javac, '-g', '-source', '8', '-target', '8', '-encoding', 'UTF-8',
                            '-classpath', str(empty), '-sourcepath', str(empty), '-d', str(output),
                            str(mode_root / 'ForwardCarryProbe.java'), str(mode_root / 'Runner.java')]
            else:
                mode = phase.split('-', 1)[0]
                expected = [java, '-Xverify:all', '-cp', str(leg_root / mode / 'classes'), RUNNER_NAME]
            require(argv == expected, label + ': argv differs from exact JDK/CLI/source binding', errors)
            require(pathlib.Path(row.get('cwd', '')).resolve() == REPO.resolve(),
                    label + ': command working directory differs from repository root', errors)
            if phase.endswith('-render'):
                require(cli_meta and pathlib.Path(argv[0]).resolve() == pathlib.Path(cli_meta['path']).resolve(),
                        label + ': render does not use the receipt-pinned CLI', errors)
            elif phase.endswith('-compile') or phase == 'original-compile':
                require(pathlib.Path(argv[0]).resolve() == pathlib.Path(javac).resolve(),
                        label + ': compiler executable differs from JDK manifest', errors)
            else:
                require(pathlib.Path(argv[0]).resolve() == pathlib.Path(java).resolve(),
                        label + ': runtime executable differs from JDK manifest', errors)

    # Each saved generated Java source is exactly the corresponding document.text.
    generated = receipt.get('generated', [])
    generated_by_name = {entry.get('name'): entry for entry in generated}
    expected_generated = {f'{jdk}-{mode}' for jdk in ('javac8', 'javac23') for mode in ('default', 'all')}
    require(len(generated_by_name) == 4 and set(generated_by_name) == expected_generated,
            'rendered source/document inventory is not exactly four JDK/mode cells', errors)
    documents = {}
    for jdk in ('javac8', 'javac23'):
        for mode in ('default', 'all'):
            name = f'{jdk}-{mode}'
            entry = generated_by_name.get(name)
            if not entry:
                continue
            source_path = safe_capture_path(capture, entry['source']['path'], name + ' source', errors)
            doc_path = safe_capture_path(capture, entry['report']['path'], name + ' document', errors)
            verify_pin(entry['source'], name + ' source', errors, source_path)
            verify_pin(entry['report'], name + ' document', errors, doc_path)
            source_bytes = source_path.read_bytes()
            render_bytes = raw_bytes.get((f'{jdk}-{mode}-render', 'stdout'))
            doc = read_json(doc_path)
            documents[(jdk, mode)] = doc
            require(source_bytes == doc.get('text', '').encode('utf-8'),
                    name + ': generated source is not byte-identical to document.text', errors)
            require(doc_path.read_bytes() == render_bytes,
                    name + ': saved document differs from the CLI render stdout bytes', errors)
            require(not raw_bytes.get((f'{jdk}-{mode}-render', 'stderr'), b''),
                    name + ': render stderr is not empty', errors)
            require(source_inputs['Runner.java'] == (capture / jdk / mode / 'Runner.java').read_bytes(),
                    name + ': compiled Runner differs from immutable input', errors)

    # Default/all should change evidence only: full class text, method render text, and maps agree.
    mode_equal = {}
    for jdk in ('javac8', 'javac23'):
        default = documents.get((jdk, 'default'))
        all_mode = documents.get((jdk, 'all'))
        if not default or not all_mode:
            continue
        require(default.get('text') == all_mode.get('text'), jdk + ': default/all class text differs', errors)
        left = {audit_mod.method_identity(row)[0]: row for row in default.get('methods', [])}
        right = {audit_mod.method_identity(row)[0]: row for row in all_mode.get('methods', [])}
        require(set(left) == set(right), jdk + ': default/all method inventories differ', errors)
        for key in sorted(set(left) & set(right)):
            lreport = left[key].get('outcome', {}).get('report', {})
            rreport = right[key].get('outcome', {}).get('report', {})
            require(lreport.get('text') == rreport.get('text'), jdk + '/' + key + ': method text differs by mode', errors)
            require(lreport.get('source_map') == rreport.get('source_map'), jdk + '/' + key + ': source map differs by mode', errors)
        mode_equal[jdk] = len(left)

    # Original and output classfiles are parsed by the maintained parser, then checked for full
    # method/class inventory parity. No parser or bytecode decoder is implemented here.
    decode = audit_mod.load_decoder(REFERENCE)
    class_audits = {}
    runtime_stdout = []
    for jdk in ('javac8', 'javac23'):
        original_root = capture / jdk / 'original'
        original_probe_path = original_root / 'cf11' / 'ForwardCarryProbe.class'
        original_runner_path = original_root / 'cf11' / 'Runner.class'
        original_probe = audit_mod.class_file(original_probe_path)
        original_runner = audit_mod.class_file(original_runner_path)
        require(original_probe['owner'] == 'cf11/ForwardCarryProbe' and original_probe['major'] == 52,
                jdk + ': original probe class identity/version differs', errors)
        require(original_runner['owner'] == 'cf11/Runner' and original_runner['major'] == 52,
                jdk + ': original Runner class identity/version differs', errors)
        require(len(original_probe['methods']) == 16, jdk + ': original probe must have 16 physical methods', errors)
        original_keys = set(original_probe['methods'])
        digest = audit_mod.class_digest(original_probe_path.read_bytes())
        class_audits[jdk] = {'original_probe': pin(original_probe_path), 'original_runner': pin(original_runner_path),
                             'blake3': digest, 'modes': {}}
        for mode in ('default', 'all'):
            output_root = capture / jdk / mode / 'classes'
            files = sorted(path.relative_to(output_root).as_posix() for path in output_root.rglob('*.class'))
            require(files == ['cf11/ForwardCarryProbe.class', 'cf11/Runner.class'],
                    jdk + '/' + mode + ': compiled complete class inventory differs', errors)
            probe_path = output_root / 'cf11' / 'ForwardCarryProbe.class'
            runner_path = output_root / 'cf11' / 'Runner.class'
            compiled_probe = audit_mod.class_file(probe_path)
            compiled_runner = audit_mod.class_file(runner_path)
            require(set(compiled_probe['methods']) == original_keys,
                    jdk + '/' + mode + ': compiled probe method inventory differs from original', errors)
            require(set(compiled_runner['methods']) == set(original_runner['methods']),
                    jdk + '/' + mode + ': compiled Runner method inventory differs from original', errors)
            doc = documents.get((jdk, mode))
            rows = doc.get('methods', []) if doc else []
            keys = [audit_mod.method_identity(row)[0] for row in rows]
            require(len(rows) == 16 and set(keys) == original_keys,
                    jdk + '/' + mode + ': render does not inventory all 16 physical methods', errors)
            maps = {}
            for row in rows:
                key, _identity = audit_mod.method_identity(row)
                maps[key] = audit_mod.map_audit(row, original_probe, decode, digest,
                                                jdk + '/' + mode + '/' + key)
                require(not maps[key]['coverage_extra'],
                        jdk + '/' + mode + '/' + key + ': map cites nonphysical instructions', errors)
            class_audits[jdk]['modes'][mode] = {
                'compiled_probe': pin(probe_path), 'compiled_runner': pin(runner_path),
                'probe_method_count': len(compiled_probe['methods']),
                'runner_method_count': len(compiled_runner['methods']),
                'maps': maps,
            }
        # The three runtime outputs for this JDK (original/default/all) must match bytewise;
        # the final cross-JDK comparison below makes all six cells share one 12-row oracle.
        runtime_stdout.append(raw_bytes[(jdk + '-original-run', 'stdout')])
        runtime_stdout.append(raw_bytes[(jdk + '-default-run', 'stdout')])
        runtime_stdout.append(raw_bytes[(jdk + '-all-run', 'stdout')])

    require(len(runtime_stdout) == 6 and all(data == runtime_stdout[0] for data in runtime_stdout),
            'six original/default/all Runner stdout streams are not byte-identical', errors)
    if runtime_stdout:
        require(len(runtime_stdout[0].splitlines()) == 12,
                'original Runner oracle does not contain exactly 12 rows', errors)

    require(not audit_mod.errors, 'maintained candidate map auditor reported errors: ' + repr(audit_mod.errors), errors)
    return {
        'receipt': pin(receipt_path),
        'status': receipt.get('status'),
        'cli': cli_meta,
        'input_pins_before_after_equal': before == after,
        'runner': runner_meta,
        'jdk_tools': tool_audit,
        'commands': [{'index': row['index'], 'label': row['label'],
                      'stdout': row['streams']['stdout'], 'stderr': row['streams']['stderr']}
                     for row in commands],
        'runtime_rows': 12,
        'runtime_stdout_sha256': sha(runtime_stdout[0]) if runtime_stdout else None,
        'default_all_method_text_map_equal': mode_equal,
        'classes': class_audits,
        'maintained_auditor': pin(AUDITOR),
        'decoder_reference': str(REFERENCE.resolve()),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture', type=pathlib.Path,
                        default=BASE / 'forward-order-v3')
    parser.add_argument('--out', type=pathlib.Path,
                        default=BASE / 'forward-order-v3' / 'root-audit-v1.json')
    args = parser.parse_args()
    out = args.out.resolve()
    if out.exists():
        raise SystemExit('refuse overwrite: ' + str(out))

    global audit_mod
    errors = []
    dependency_before = None
    result = None
    try:
        audit_mod = load_candidate_auditor()
        dependency_before = audit_mod.blake3_dependency()
        result = audit(args.capture, errors)
    except Exception as exc:
        errors.append(f'audit preparation failed: {type(exc).__name__}: {exc}')
    if dependency_before is not None:
        try:
            if dependency_before != audit_mod.blake3_dependency():
                errors.append('maintained BLAKE3 dependency changed during audit')
        except Exception as exc:
            errors.append(f'BLAKE3 dependency recheck failed: {type(exc).__name__}: {exc}')

    report = {
        'schema': 'forward-order-independent-root-audit-v1',
        'status': 'accepted' if not errors else 'rejected',
        'audited_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'auditor': pin(__file__),
        'hash_dependency': dependency_before,
        'scope': {'commands': 16, 'raw_streams': 32, 'physical_methods_per_class': 16,
                  'render_cells': 4, 'runner_rows_per_cell': 12},
        'errors': errors,
        'capture': result,
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'error_count': len(errors), 'report': str(out)},
                     ensure_ascii=False))
    return 0 if not errors else 1


if __name__ == '__main__':
    raise SystemExit(main())
