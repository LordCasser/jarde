#!/usr/bin/env python3
"""Run guarded two-seed full-workspace validation with forward-carry proof gates.

CI ignored runtime commands remain unchanged and root-owned: the JDK 25 instruction-boundary
oracle, P3 execution comparison, functional-constructor replay, BigDecimal comparison, and both
nested-int-array comparisons remain separate acceptance legs. JDK 25 source-launch and pinned
JDK 8/23 javac full-class matrix environment setup is supplied by root.
"""

from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import runpy
import signal
import stat
import subprocess
import sys
import time
import tomllib

sys.dont_write_bytecode = True
ROOT = Path('/home/lordcasser/workspace/projects/jarde')
OUT = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/workspace-run-forward-v1')
TEMPLATE = Path(__file__).resolve().with_name('guard.py')
SCAN_PATH = Path(__file__).resolve().with_name('target_scan.py')
TEMPLATE_SHA256 = 'a312c70cd7e4f15851d26dd27f51127d441ba5f886bc54c1118e6f533b5fdb39'
SCAN_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3
FOCUSED_STATUS = 'commands_passed_pending_independent_acceptance'
SEEDS = ('5350648285461741569', '5350648285461741570')
STRIPPED_ENV_KEYS = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')
DOCELLIPSIS_EXCEPTIONS = {
    ('../tests/fixtures/…', 'crates/jarde-jvm/src/test_fixtures.rs'),
    ('../tests/fixtures/…', 'crates/jarde-reader/src/test_fixtures.rs'),
}
INCLUDE_RE = re.compile(r'(?:include_bytes|include_str)!\s*\(\s*"([^"]+)"')
SUMMARY_RE = re.compile(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;')
OUTCOME_RE = re.compile(r'^test ([^\n]+?) \.\.\. (?:(?!^test ).)*?\b(ok|ignored|FAILED)(?:, [^\n]*)?$', re.M | re.S)
ANSI_RE = re.compile(r'\x1b\[[0-9;]*m')
REQUIRED_NAMED_TESTS = {
    'ordinary_try_list_projection_covers_exact_types_catch_uses_and_topology_controls',
    'ordinary_try_late_cancellation_keeps_raw_source_and_installs_no_partial_projection',
    'ordinary_try_late_budget_stop_keeps_raw_source_and_installs_no_partial_projection',
    'report::generic_void_parameter_census_tests::ordinary_try_list_scope_is_reached_by_the_real_method_recovery',
    'report::generic_void_parameter_census_tests::ordinary_try_list_scope_refuses_owner_and_physical_row_mutations',
    'build::tests::protected_iterator_phi_gate_accepts_only_terminal_dead_mixed_local_phi',
    'conditional_constructor_public_reports_agree_across_evidence_selections',
    'conditional_constructor_positive_all_evidence_reports_four_exact_methods',
    'conditional_constructor_range_excluding_all_new_bcis_keeps_summary_and_text',
    'conditional_constructor_public_late_stop_and_precancel_publish_atomically',
    'conditional_sites_are_not_presented_when_the_final_body_is_explanation_only',
    'field::tests::conditional_new_receipt_counts_only_one_method_local_direct_new',
    'field::tests::conditional_new_receipt_rejects_derived_primary_and_derived_only_candidate_anchors',
    'init::tests::conditional_constructor_output_has_one_live_stack_phi_and_one_join_consumer',
    'init::tests::actual_local_conditional_new_has_its_local_store_as_the_single_consumer',
    'init::tests::actual_shared_field_return_keeps_dup_outside_the_new_expression',
    'init::tests::actual_nested_conditional_constructor_arms_do_not_become_one_two_way_site',
    'init::tests::actual_independent_branch_effect_stays_on_the_existing_statement_path',
    'nested_iterators_project_and_preserve_the_outer_assignment_and_cast',
    'outer_assignment_foreach_public_api_and_real_controls_stay_conservative',
    'nested_foreach_late_stop_and_precancel_leave_no_partial_method_artifact',
    'build::tests::iterator_declaration_gate_uses_real_local_owner_and_refuses_incomplete_facts',
    'build::tests::iterator_declaration_gate_rejects_real_split_slot_identity_changes',
    'build::tests::iterator_phi_gate_counts_real_duplicate_inputs_and_ignores_unrelated_phi',
    'build::tests::mixed_iterator_real_phi_is_live_and_fails_the_production_use_gate',
    'build::tests::alias_branch_phi_does_not_expand_the_exact_value_reader_allowlist',
    'nearby_list_controls_refuse_only_unproved_generic_projections',
    'inner_list_option_actual_uses_the_receiver_element_type',
    'fixed_nested_string_body_projects_source_and_preserves_physical_origins',
    'differently_named_string_and_integer_classes_follow_their_list_element_type',
    'exact_list_null_add_removes_only_the_synthetic_object_wrapper',
    'pre_cancel_does_not_install_a_partial_generic_declaration_or_method_projection',
    'budget_stop_during_list_proof_keeps_raw_body_and_installs_no_projection',
}
FOCUSED_EXPECTED_OUTCOMES = {
    'build::tests::reference_load_rejects_caught_parameter_alias_from_real_handler_ssa': 'ok',
    'build::tests::same_block_reference_load_is_presented_outside_try_for_fixed_dv_variants': 'ok',
    'concat::ordered_field_budget_tests::a_physical_handler_row_split_across_the_field_chain_keeps_the_refusal': 'ok',
    'concat::ordered_field_budget_tests::an_unclaimed_field_read_cannot_complete_the_concat_refusal': 'ok',
    'concat::ordered_field_budget_tests::short_budget_and_precancel_stop_inside_field_certificate_before_owner_commit': 'ok',
    'a_field_backed_object_append_pins_the_conversion_and_keeps_origins': 'ok',
    'retry_v2_exc_same_payload_proves_field_append_tail_error_value_flow_on_all_lanes': 'ok',
    'ordered_field_candidate_rejects_static_receiver_call_and_duplicated_result': 'ok',
    'v3_instance_field_concats_are_recovered_in_all_four_compiler_lanes': 'ok',
    'ordered_field_concat_pre_cancel_publishes_no_partial_owner': 'ok',
    'ordered_field_concat_short_ir_budget_stops_without_partial_owner': 'ok',
    'a_verified_chain_is_written_once_with_its_operands_in_the_order_it_read_them': 'ok',
    'region::finite_loop_catch_tests::retry_proof_budget_used_minus_one_and_precancel_stop_inside_the_proof': 'ok',
    'region::finite_loop_catch_tests::retry_proof_rejects_mutated_physical_and_transfer_evidence': 'ok',
    'same_name_lvt_sources_split_into_exact_typed_independent_names': 'ok',
}
REQUIRED_IGNORED_TESTS = {name for name, state in FOCUSED_EXPECTED_OUTCOMES.items() if state == 'ignored'}
REQUIRED_NAMED_TESTS = {name for name, state in FOCUSED_EXPECTED_OUTCOMES.items() if state == 'ok'} | {
    'report::generic_void_parameter_census_tests::complete_fixed_void_census_keeps_phi_and_every_formal_read',
    'report::generic_void_parameter_census_tests::fixed_census_refuses_physical_inventory_and_operation_disagreements',
    'report::generic_void_parameter_census_tests::fixed_read_is_not_unread_when_the_invoke_target_is_unknown',
    'report::generic_void_parameter_census_tests::real_parameter_reassignment_and_handler_facts_refuse_the_list_census',
    'classfile::tests::repository_class_fixtures_validate_without_false_target_rejections',
    'corpus_files_match_the_recorded_fingerprint',
    'the_manifest_matches_its_rendered_classification',
    'every_dimension_is_carried_by_existing_corpus',
    'every_acceptance_row_is_indexed_against_existing_corpus',
    'the_indexed_rows_are_the_rows_the_acceptance_table_names',
}
REQUIRED_IGNORED_TESTS = REQUIRED_IGNORED_TESTS | {'regenerate_corpus_fingerprint'}
REQUIRED_NAMED_TEST_GROUPS = {
    'raw_alias_lvt': {
        'build::tests::raw_alias_escape_full_reuse_plan_stops_atomically_during_lvt_matching',
        'build::tests::raw_alias_escape_reference_lifetimes_keep_types_names_and_local_owners',
        'build::tests::raw_alias_escape_rejects_ambiguous_or_incomplete_lvt_rows_atomically',
        'build::tests::raw_alias_escape_without_lvt_keeps_the_existing_unnamed_split',
    },
    'protected_prefix_loop': {
        'region::protected_prefix_loop_tests::candidate_named_row_scope_is_bound_to_the_current_real_sites_and_range',
        'region::protected_prefix_loop_tests::candidate_row_binding_stops_without_publishing_a_partial_scope',
        'region::protected_prefix_loop_tests::handled_keeps_its_prefix_loop_catch_bridge_and_join_owned_once',
        'region::protected_prefix_loop_tests::late_prefix_loop_child_stop_restores_all_walker_state',
        'region::protected_prefix_loop_tests::real_resource_guard_region_is_rejected_by_candidate_collector',
        'region::protected_prefix_loop_tests::effect_suffix_inside_try_refuses_prefix_loop_and_restores_full_state',
    },
    'ordinary_try_list_public_controls': {
        'ordinary_try_list_projection_covers_exact_types_catch_uses_and_topology_controls',
        'ordinary_try_late_cancellation_keeps_raw_source_and_installs_no_partial_projection',
        'ordinary_try_late_budget_stop_keeps_raw_source_and_installs_no_partial_projection',
    },
    'ordinary_try_scope_proof': {
        'report::generic_void_parameter_census_tests::ordinary_try_list_scope_is_reached_by_the_real_method_recovery',
        'report::generic_void_parameter_census_tests::ordinary_try_list_scope_refuses_owner_and_physical_row_mutations',
        'build::tests::protected_iterator_phi_gate_accepts_only_terminal_dead_mixed_local_phi',
    },
    'inline_conditional_concat_refusal_control': {
        'the_negatives_keep_their_split_refusals_on_both_legs',
    },
    'forward_conditional_stack_carry': {
        'build::tests::forward_conditional_carry_proves_real_retired_stack_phi_and_rejects_wrong_values',
        'build::tests::forward_conditional_carry_rejects_physical_mixed_and_extra_reader_controls',
        'build::tests::forward_conditional_carry_late_budget_and_ledger_cancellation_return_no_certificate',
        'ordinary_try_admission_helper_preserves_the_field_read_before_its_conditional',
        'forward_conditional_carry_frozen_order_probes_keep_saved_producers_before_the_test',
    },
    'ordinary_try_prefix_loop': {
        'cancellation_during_the_selected_recovery_commits_no_partial_region_or_source_map',
        'ordinary_try_prefix_loop_keeps_default_all_output_and_every_physical_origin',
    },
    'structured_list_fullclass': {
        'raw_alias_escape_reference_lifetimes_match_default_all_and_source_origins',
    },
}
REQUIRED_NAMED_TESTS |= set(FOCUSED_EXPECTED_OUTCOMES)
REQUIRED_NAMED_TESTS |= set().union(*REQUIRED_NAMED_TEST_GROUPS.values())
REQUIRED_FOCUSED_NAMED_TESTS = set().union(*REQUIRED_NAMED_TEST_GROUPS.values()) | {'same_name_lvt_sources_split_into_exact_typed_independent_names'}
REQUIRED_DYNAMIC_SOURCE_PATHS = {
    'tests/p3_reference_slot_lifetimes.rs',
    'tests/p3_local_reference_write_compatibility.rs',
    'crates/jarde-java/tests/ordinary_try_prefix_loop.rs',
    'tests/structured_list_generic_bodies.rs',
    'crates/jarde-java/src/report.rs',
    'crates/jarde-reader/src/classfile.rs',
    'tests/p5_corpus_fingerprint.rs',
    'tests/fixtures/corpus-fingerprint.json',
    'tests/fixtures/cf11-structured-list-api/UpstreamNestedLoops.class',
    'tests/fixtures/cf11-structured-list-api/DistinctStringFixture.class',
    'tests/fixtures/cf11-structured-list-api/DistinctIntegerFixture.class',
    'tests/fixtures/cf11-structured-list-controls/UpstreamNestedLoops.class',
    'tests/fixtures/cf11-structured-list-inner-option/DistinctIntegerFixture.class',
    'tests/fixtures/cf11-structured-list-null-api/NullStringListFixture.class',
    'tests/fixtures/cf11-structured-list-null-api/NullIntegerListFixture.class',
    'tests/recover_proved_conditional_constructor_values.rs',
    'tests/fixtures/java8/cf11-conditional-constructor-values/UpstreamSequentialLoops2.class',
    'tests/fixtures/java8/cf11-conditional-constructor-values/UpstreamSequentialLoops2.java',
    'tests/fixtures/java8/cf11-conditional-constructor-values/ConditionalConstructionPositive.class',
    'tests/fixtures/java8/cf11-conditional-constructor-values/ConditionalConstructionPositive.java',
    'tests/fixtures/java8/cf11-conditional-constructor-values/ConditionalConstructionRefusals.class',
    'tests/fixtures/java8/cf11-conditional-constructor-values/ConditionalConstructionRefusals.java',
    'tests/fixtures/java8/cf11-conditional-constructor-values/README.md',
    'tests/fixtures/java8/cf11-conditional-constructor-values/pins.json',
    'tests/p3_hoisted_iterator_foreach.rs',
    'tests/fixtures/p3-hoisted-iterator/HoistedIteratorPhiControls.java',
    'tests/fixtures/p3-hoisted-iterator/HoistedIteratorPhiControls.class',
    'tests/fixtures/p3-hoisted-iterator/README.md',
    'tests/p3_hoisted_iterator_foreach.rs',
    'tests/fixtures/p3-iterator-assignment/CF11OuterAssignmentTarget.class',
    'tests/fixtures/p3-iterator-assignment/CF11OuterAssignmentTarget.java',
    'tests/fixtures/p3-iterator-assignment/Runner.java',
    'tests/fixtures/p3-iterator-assignment/README.md',
    'tests/fixtures/p3-iterator-assignment/pins.json',
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def static_target_inventory() -> list[tuple[str, str, str]]:
    """Discover current Cargo targets from workspace manifests and conventional source paths."""
    workspace = tomllib.loads((ROOT / 'Cargo.toml').read_text(encoding='utf-8'))
    members = workspace.get('workspace', {}).get('members', [])
    if not members:
        raise RuntimeError('workspace member list is empty')
    rows: set[tuple[str, str, str]] = set()

    def add(package: str, kind: str, name: str, path: Path) -> None:
        if path.is_file():
            rows.add((package, name, kind))

    for member in members:
        manifest = ROOT / member / 'Cargo.toml' if member != '.' else ROOT / 'Cargo.toml'
        if not manifest.is_file():
            raise FileNotFoundError(f'workspace member manifest missing: {manifest}')
        data = tomllib.loads(manifest.read_text(encoding='utf-8'))
        package = data['package']['name']
        package_data = data['package']
        directory = manifest.parent
        lib = data.get('lib')
        if package_data.get('autolib', True):
            if lib is not None:
                lib_path = directory / lib.get('path', 'src/lib.rs')
                lib_name = lib.get('name', package.replace('-', '_'))
                add(package, 'lib', lib_name, lib_path)
            else:
                add(package, 'lib', package.replace('-', '_'), directory / 'src/lib.rs')

        explicit_bins = data.get('bin', [])
        for spec in explicit_bins:
            path = directory / spec.get('path', f"src/bin/{spec.get('name', package)}/main.rs")
            name = spec.get('name', package if path == directory / 'src/main.rs' else path.stem)
            add(package, 'bin', name, path)
        if package_data.get('autobins', True):
            if not explicit_bins:
                add(package, 'bin', package, directory / 'src/main.rs')
            bindir = directory / 'src/bin'
            if bindir.is_dir():
                for path in bindir.glob('*.rs'):
                    add(package, 'bin', path.stem, path)
                for path in bindir.glob('*/main.rs'):
                    add(package, 'bin', path.parent.name, path)

        for kind, folder, auto_key in (
            ('example', 'examples', 'autoexamples'),
            ('test', 'tests', 'autotests'),
            ('bench', 'benches', 'autobenches'),
        ):
            for spec in data.get(kind, []):
                path = directory / spec['path']
                add(package, kind, spec.get('name', path.stem), path)
            if package_data.get(auto_key, True):
                base = directory / folder
                if base.is_dir():
                    for path in base.glob('*.rs'):
                        add(package, kind, path.stem, path)
                    for path in base.glob('*/main.rs'):
                        add(package, kind, path.parent.name, path)

        build_path = package_data.get('build', 'build.rs')
        if build_path and (directory / build_path).is_file():
            rows.add((package, 'build-script-build', 'custom-build'))

    return sorted(rows)


def source_paths() -> set[Path]:
    paths = {ROOT / 'Cargo.toml', ROOT / 'Cargo.lock', ROOT / '.github/workflows/ci.yml',
             ROOT / 'tests/fixtures/corpus-fingerprint.json'}
    for base_name in ('src', 'crates', 'tests', 'examples'):
        base = ROOT / base_name
        if not base.is_dir() or base.is_symlink():
            if base_name == 'examples' and not base.exists():
                continue
            raise FileNotFoundError(f'required source directory is absent or linked: {base}')
        def fail_walk(error: OSError) -> None:
            raise error
        for directory, dirnames, filenames in os.walk(base, topdown=True, followlinks=False, onerror=fail_walk):
            parent = Path(directory)
            for dirname in list(dirnames):
                child = parent / dirname
                if child.is_symlink():
                    raise RuntimeError(f'source closure contains a linked directory: {child}')
            for filename in filenames:
                child = parent / filename
                if child.is_symlink() or not child.is_file():
                    raise RuntimeError(f'source closure contains a linked or non-file path: {child}')
                paths.add(child)
    paths.update((ROOT / 'crates').glob('*/Cargo.toml'))
    cargo_config = ROOT / '.cargo'
    if cargo_config.exists():
        if cargo_config.is_symlink() or not cargo_config.is_dir():
            raise RuntimeError(f'source closure contains a linked or non-directory Cargo config: {cargo_config}')
        for directory, dirnames, filenames in os.walk(cargo_config, topdown=True, followlinks=False):
            parent = Path(directory)
            for dirname in list(dirnames):
                if (parent / dirname).is_symlink():
                    raise RuntimeError(f'source closure contains a linked Cargo config directory: {parent / dirname}')
            for filename in filenames:
                child = parent / filename
                if child.is_symlink() or not child.is_file():
                    raise RuntimeError(f'source closure contains a linked or non-file Cargo config: {child}')
                paths.add(child)
    for base in (ROOT / 'tests/fixtures',
                 ROOT / 'openspec/changes/recover-class-scope-constructor-parameters/evidence/frozen'):
        paths.update(path for path in base.rglob('*') if path.is_file())
    for path in list(paths):
        if path.suffix != '.rs':
            continue
        relative_source = str(path.relative_to(ROOT))
        for relative_include in INCLUDE_RE.findall(path.read_text(encoding='utf-8')):
            included = (path.parent / relative_include).resolve()
            if not included.is_relative_to(ROOT):
                raise RuntimeError(f'include escapes workspace: {path}: {relative_include}')
            if not included.is_file():
                if (relative_include, relative_source) in DOCELLIPSIS_EXCEPTIONS:
                    continue
                raise FileNotFoundError(f'missing include: {path}: {relative_include}')
            paths.add(included)
    for path in paths:
        if path.is_symlink() or not path.is_file():
            raise FileNotFoundError(f'missing source pin: {path}')
    return paths


def pin_sources(paths: set[Path]) -> dict[str, str]:
    return {str(path.relative_to(ROOT)): sha256(path) for path in sorted(paths)}


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load guard module: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_focused_receipt(focused: dict, focused_path: Path) -> tuple[list[list[str]], dict]:
    if focused.get('status') != FOCUSED_STATUS:
        raise RuntimeError('focused final-check receipt has not completed successfully')
    if focused.get('default_stack') is not True or focused.get('target_absent') is not True:
        raise RuntimeError('focused receipt did not preserve default stack and target-absent cleanup')
    if focused.get('source_manifest_before') != focused.get('source_manifest_after'):
        raise RuntimeError('focused source manifest changed during final check')
    guard = focused.get('guard', {})
    if (guard.get('minimum_free_bytes') != FREE_LIMIT or guard.get('maximum_target_bytes') != TARGET_LIMIT
            or guard.get('interval_seconds') != 1):
        raise RuntimeError('focused receipt guard limits differ from the workspace protocol')
    runner_pin = focused.get('runner')
    if not isinstance(runner_pin, dict):
        raise RuntimeError('focused receipt lacks its runner pin')
    runner_path = Path(runner_pin.get('path', ''))
    if runner_path.is_symlink() or not runner_path.is_file() or runner_path.stat().st_size != runner_pin.get('bytes') or sha256(runner_path) != runner_pin.get('sha256'):
        raise RuntimeError('focused runner path/byte/hash pin differs')
    spec_pin = focused.get('command_spec')
    if not isinstance(spec_pin, dict) or not isinstance(spec_pin.get('path'), str):
        raise RuntimeError('focused receipt lacks pinned command_spec')
    spec_path = Path(spec_pin['path'])
    if spec_path.is_symlink() or not spec_path.is_file():
        raise RuntimeError('focused command_spec path is missing or linked')
    spec_raw = spec_path.read_bytes()
    if len(spec_raw) != spec_pin.get('bytes') or hashlib.sha256(spec_raw).hexdigest() != spec_pin.get('sha256'):
        raise RuntimeError('focused command_spec byte/hash pin differs')
    expected = json.loads(spec_raw)
    if not isinstance(expected, list) or not expected or any(not isinstance(argv, list) for argv in expected):
        raise RuntimeError('focused command_spec must be a nonempty ordered command list')
    rows = focused.get('commands')
    if not isinstance(rows, list) or len(rows) != len(expected) + 1:
        raise RuntimeError('focused receipt command rows do not match command_spec plus final cleanup')
    test_count = 0
    build_positions = []
    clippy_count = 0
    strict_count = 0
    focused_outcomes = []
    for index, (row, argv) in enumerate(zip(rows[:-1], expected), 1):
        if (row.get('index') != index or row.get('argv') != argv or row.get('exit_code') != 0
                or row.get('guard_stop') is not None):
            raise RuntimeError(f'focused command failed or differs from pinned command_spec at index {index}')
        if row.get('peak_target_bytes', TARGET_LIMIT + 1) > TARGET_LIMIT or row.get('free_bytes_after', 0) < FREE_LIMIT:
            raise RuntimeError(f'focused command exceeded workspace resource limits at index {index}')
        if set(row.get('streams', {})) != {'stdout', 'stderr'}:
            raise RuntimeError(f'focused command lacks raw stdout/stderr at index {index}')
        for ref in row['streams'].values():
            path = Path(ref.get('path', ''))
            if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(focused_path.parent):
                raise RuntimeError(f'focused raw stream missing, linked, or outside receipt root: {index}')
            raw = path.read_bytes()
            if len(raw) != ref.get('bytes') or hashlib.sha256(raw).hexdigest() != ref.get('sha256'):
                raise RuntimeError(f'focused raw stream pin differs: {index}')
        if argv[:2] == ['cargo', 'test']:
            test_count += 1
            raw_text = ANSI_RE.sub('', Path(row['streams']['stdout']['path']).read_text(encoding='utf-8', errors='replace'))
            summaries = [list(item) for item in SUMMARY_RE.findall(raw_text)]
            if not summaries or any(item[0] != 'ok' or item[2] != '0' for item in summaries):
                raise RuntimeError(f'focused test command did not produce only passing summaries: {index}')
            if row.get('actual_test_summaries') != summaries:
                raise RuntimeError(f'focused test command summary differs from raw stdout: {index}')
            outcomes = OUTCOME_RE.findall(raw_text)
            if len(outcomes) != sum(sum(int(x) for x in item[1:]) for item in summaries):
                raise RuntimeError(f'focused named outcomes do not account for summaries: {index}')
            focused_outcomes.extend(outcomes)
            states = {state: sum(outcome == state for _name, outcome in outcomes) for state in ('ok', 'FAILED', 'ignored')}
            expected_states = {state: sum(int(summary[1 + offset]) for summary in summaries)
                               for offset, state in enumerate(('ok', 'FAILED', 'ignored'))}
            if states != expected_states:
                raise RuntimeError(f'focused named outcome states differ from summaries: {index}')
        if argv == ['cargo', 'build', '-p', 'jarde-cli', '--locked']:
            build_positions.append(index)
        if argv[:5] == ['cargo', 'clippy', '--workspace', '--all-targets', '--all-features']:
            clippy_count += 1
        if argv == ['openspec', 'validate', '--all', '--strict', '--no-interactive']:
            strict_count += 1
    clean = rows[-1]
    if clean.get('argv') != ['cargo', 'clean'] or clean.get('exit_code') != 0 or clean.get('guard_stop') is not None:
        raise RuntimeError('focused final cleanup is not successful exact cargo clean')
    if set(clean.get('streams', {})) != {'stdout', 'stderr'}:
        raise RuntimeError('focused cleanup lacks raw stdout/stderr')
    for ref in clean['streams'].values():
        path = Path(ref.get('path', ''))
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(focused_path.parent):
            raise RuntimeError('focused cleanup raw stream missing or outside receipt root')
        raw = path.read_bytes()
        if len(raw) != ref.get('bytes') or hashlib.sha256(raw).hexdigest() != ref.get('sha256'):
            raise RuntimeError('focused cleanup raw stream pin differs')
    if test_count == 0 or len(build_positions) != 1 or clippy_count != 1 or strict_count != 1:
        raise RuntimeError('focused receipt must include tests, one CLI build, workspace clippy, and strict OpenSpec validation')
    focused_rows = [(name, state) for name, state in focused_outcomes if name in REQUIRED_FOCUSED_NAMED_TESTS]
    focused_counts = {name: sum(actual == name for actual, _state in focused_rows)
                      for name in REQUIRED_FOCUSED_NAMED_TESTS}
    if (any(count != 1 for count in focused_counts.values())
            or any(state != 'ok' for _name, state in focused_rows)):
        raise RuntimeError(f'focused raw-alias/protected-prefix/ordinary/structured named gates differ: {focused_counts}')
    cli = focused.get('cli')
    if not isinstance(cli, dict) or not isinstance(cli.get('path'), str):
        raise RuntimeError('focused final-check receipt lacks its freshly built CLI pin')
    cli_path = Path(cli['path'])
    if cli_path.is_symlink() or not cli_path.is_file() or cli_path.stat().st_size != cli.get('bytes') or sha256(cli_path) != cli.get('sha256'):
        raise RuntimeError('focused CLI bytes/hash pin differs')
    builds = [row for row in rows[:-1] if row.get('argv') == ['cargo', 'build', '-p', 'jarde-cli', '--locked']]
    if len(builds) != 1 or builds[0].get('exit_code') != 0:
        raise RuntimeError('focused receipt lacks its successful fresh CLI build')
    return expected, spec_pin


def validate_runtime_matrix_cli(path: Path, expected_sha: str, expected_mode: str) -> dict:
    path = path.resolve(strict=True)
    if path.is_symlink() or sha256(path) != expected_sha:
        raise RuntimeError(f'runtime matrix receipt path/hash mismatch: {path}')
    execution = json.loads(path.read_text(encoding='utf-8'))
    if execution.get('status') != 'observed':
        raise RuntimeError(f'runtime matrix receipt is not observed: {path}')
    config = execution.get('collector_config', {})
    guard = execution.get('resource_guard', {})
    if config.get('javac_debug') != expected_mode:
        raise RuntimeError(f'runtime matrix javac mode differs from {expected_mode}: {path}')
    if (guard.get('minimum_free_bytes') != FREE_LIMIT or guard.get('maximum_target_bytes') != TARGET_LIMIT
            or guard.get('poll_seconds') != 1 or guard.get('peak_target_sampled') is not True):
        raise RuntimeError(f'runtime matrix resource guard differs: {path}')
    commands = execution.get('commands')
    if not isinstance(commands, list) or execution.get('actual_command_count') != len(commands) or not commands:
        raise RuntimeError(f'runtime matrix command inventory is incomplete: {path}')
    if execution.get('source_tool_inputs_unchanged') is not True or execution.get('source_tool_pins_before') != execution.get('source_tool_pins_after'):
        raise RuntimeError(f'runtime matrix source/tool pins changed: {path}')
    tool_pins = execution.get('source_tool_pins_before')
    if not isinstance(tool_pins, list) or not tool_pins:
        raise RuntimeError(f'runtime matrix source/tool pin inventory is absent: {path}')
    tool_pin_paths = set()
    for pin in tool_pins:
        if (not isinstance(pin, dict) or not isinstance(pin.get('path'), str)
                or not isinstance(pin.get('bytes'), int) or not isinstance(pin.get('sha256'), str)
                or pin['path'] in tool_pin_paths):
            raise RuntimeError(f'runtime matrix source/tool pin row is malformed or duplicated: {path}')
        tool_pin_paths.add(pin['path'])
        pinned_path = Path(pin['path'])
        if (pinned_path.is_symlink() or not pinned_path.is_file()
                or pinned_path.stat().st_size != pin['bytes'] or sha256(pinned_path) != pin['sha256']):
            raise RuntimeError(f'runtime matrix source/tool input pin differs: {pinned_path}')
    for row in commands:
        if row.get('state') != 'observed' or row.get('guard_stop') is not None:
            raise RuntimeError(f'runtime matrix command was not fully observed: {path}/{row.get("label")}')
        if row.get('index') < 1 or row.get('exit_code') is None:
            raise RuntimeError(f'runtime matrix command identity is incomplete: {path}')
        if set(row.get('streams', {})) != {'stdout', 'stderr'}:
            raise RuntimeError(f'runtime matrix command lacks raw stdout/stderr: {path}/{row.get("label")}')
        if row.get('peak_target_bytes', TARGET_LIMIT + 1) > TARGET_LIMIT or row.get('free_bytes_after', 0) < FREE_LIMIT:
            raise RuntimeError(f'runtime matrix resource limit differs: {path}/{row.get("label")}')
        for ref in row.get('streams', {}).values():
            stream = Path(ref.get('path', ''))
            if stream.is_symlink() or not stream.is_file() or not stream.resolve().is_relative_to(path.parent):
                raise RuntimeError(f'runtime matrix raw stream missing or escaped: {stream}')
            raw = stream.read_bytes()
            if len(raw) != ref.get('bytes') or hashlib.sha256(raw).hexdigest() != ref.get('sha256'):
                raise RuntimeError(f'runtime matrix raw stream pin differs: {stream}')
    if [row.get('index') for row in commands] != list(range(1, len(commands) + 1)):
        raise RuntimeError(f'runtime matrix command indices are not contiguous: {path}')
    jarde_rows = execution.get('jarde_compile_rows')
    profiles = execution.get('jarde_profiles')
    if (not isinstance(jarde_rows, list) or len(jarde_rows) != 4 or not isinstance(profiles, list) or len(profiles) != 4
            or any(row.get('compile_exit') != 0 or row.get('run_exit') != 0 or row.get('class_set_exact') is not True
                   or row.get('runtime_comparison', {}).get('same_jdk_original') is not True for row in jarde_rows)):
        raise RuntimeError(f'runtime matrix lacks four successful full-class Jarde runs: {path}')
    cli = execution.get('cli')
    if not isinstance(cli, dict) or not isinstance(cli.get('path'), str):
        raise RuntimeError(f'runtime matrix CLI pin is absent: {path}')
    binary = Path(cli['path'])
    if binary.is_symlink() or not binary.is_file() or binary.stat().st_size != cli.get('bytes') or sha256(binary) != cli.get('sha256'):
        raise RuntimeError(f'runtime matrix CLI binary pin differs: {path}')
    return {'receipt': {'path': str(path), 'sha256': expected_sha}, 'cli': cli}


def main() -> int:
    global record, guard, env, source_file_set, clean_armed, OUT
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--focused-receipt', type=Path, required=True)
    ap.add_argument('--focused-receipt-sha256', required=True)
    ap.add_argument('--runtime-debug-receipt', type=Path, required=True)
    ap.add_argument('--runtime-debug-receipt-sha256', required=True)
    ap.add_argument('--runtime-none-receipt', type=Path, required=True)
    ap.add_argument('--runtime-none-receipt-sha256', required=True)
    ap.add_argument('--out', type=Path, default=OUT)
    args = ap.parse_args()
    OUT = args.out.resolve()
    if OUT.exists():
        raise SystemExit(f'refusing to overwrite prior run output: {OUT}')
    if not TEMPLATE.is_file() or sha256(TEMPLATE) != TEMPLATE_SHA256:
        raise SystemExit('guard template SHA-256 mismatch')
    if not SCAN_PATH.is_file() or sha256(SCAN_PATH) != SCAN_SHA256:
        raise SystemExit('target-size scanner SHA-256 mismatch')
    if (ROOT / 'target').exists():
        raise SystemExit('fresh-target preflight failed: workspace target already exists')
    free_before = __import__('shutil').disk_usage(ROOT).free
    if free_before < FREE_LIMIT:
        raise SystemExit(f'5 GiB free-space preflight failed: {free_before}')

    source_file_set = source_paths()
    source_pins_before = pin_sources(source_file_set)
    focused_path = args.focused_receipt.resolve(strict=True)
    if focused_path.is_symlink() or sha256(focused_path) != args.focused_receipt_sha256:
        raise SystemExit('focused receipt path/hash mismatch')
    focused = json.loads(focused_path.read_text(encoding='utf-8'))
    if focused.get('status') != FOCUSED_STATUS:
        raise SystemExit('focused receipt status is not the completed final-check state')
    focused_manifest = focused.get('source_manifest_before')
    if not isinstance(focused_manifest, list) or focused_manifest != focused.get('source_manifest_after'):
        raise SystemExit('focused source manifests are incomplete or changed')
    focused_source_pins = {row.get('path'): row.get('sha256') for row in focused_manifest if isinstance(row, dict)}
    if len(focused_source_pins) != len(focused_manifest) or focused_source_pins != source_pins_before:
        raise SystemExit('focused receipt source closure does not match the complete current workspace closure')
    if focused.get('target_absent') is not True:
        raise SystemExit('focused receipt did not finish with target absent')
    focused_commands, focused_command_spec = validate_focused_receipt(focused, focused_path)
    cli_record = focused['cli']
    candidate_cli = Path(cli_record['path']).resolve(strict=True)
    cli_pin = {'path': str(candidate_cli), 'bytes': candidate_cli.stat().st_size,
               'sha256': sha256(candidate_cli)}
    if cli_record != cli_pin:
        raise SystemExit('focused receipt CLI metadata differs from actual binary')
    runtime_debug = validate_runtime_matrix_cli(args.runtime_debug_receipt, args.runtime_debug_receipt_sha256, 'debug')
    runtime_none = validate_runtime_matrix_cli(args.runtime_none_receipt, args.runtime_none_receipt_sha256, 'none')
    focused_cli_identity = (cli_pin['bytes'], cli_pin['sha256'])
    debug_cli_identity = (runtime_debug['cli']['bytes'], runtime_debug['cli']['sha256'])
    none_cli_identity = (runtime_none['cli']['bytes'], runtime_none['cli']['sha256'])
    if debug_cli_identity != none_cli_identity or focused_cli_identity != debug_cli_identity:
        raise SystemExit('fresh focused CLI bytes/SHA differ from the actual debug/none runtime matrix; rerun that matrix before workspace validation')
    runtime_cli_references = {'debug': runtime_debug, 'none': runtime_none}
    relative_sources = set(source_pins_before)
    missing_required_sources = REQUIRED_DYNAMIC_SOURCE_PATHS - relative_sources
    if missing_required_sources:
        raise SystemExit(f'required regression and ordered-field evidence inputs are outside source closure: {sorted(missing_required_sources)}')
    OUT.mkdir()
    clean_armed = True

    guard = load_module('for_condition_guard_v1', TEMPLATE)
    scan = runpy.run_path(str(SCAN_PATH), run_name='for_condition_target_scan')
    guard.ROOT = ROOT
    guard.OUT = OUT
    guard.expected_test_summaries = lambda index, raw: None
    guard.command_stream = lambda path: {
        'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha256(path)
    }
    guard.target_bytes = lambda: scan['target_bytes'](ROOT)
    guard.FREE_LIMIT = FREE_LIMIT
    guard.TARGET_LIMIT = TARGET_LIMIT
    env = os.environ.copy()
    stripped = []
    for key in STRIPPED_ENV_KEYS:
        if key in env:
            env.pop(key)
            stripped.append(key)
    env.pop('RUST_MIN_STACK', None)
    env.update(guard.ENV_VALUES)
    env['RUSTUP_TOOLCHAIN'] = 'stable'
    env['PROPTEST_RNG_SEED'] = SEEDS[0]
    env['CARGO_PROFILE_TEST_STRIP'] = 'symbols'
    guard.ENV_VALUES = {**guard.ENV_VALUES,
                        'PROPTEST_RNG_SEED': SEEDS[0],
                        'CARGO_PROFILE_TEST_STRIP': 'symbols'}
    if 'RUST_MIN_STACK' in env:
        raise RuntimeError('RUST_MIN_STACK must not be set')

    record = {
        'schema': 'ordered-field-full-workspace-run-v2',
        'status': 'running',
        'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'seeds': list(SEEDS),
        'no_carried_execution': True,
        'focused_input_receipt': {'path': str(focused_path), 'sha256': args.focused_receipt_sha256, 'status': focused['status'], 'command_spec_sha256': focused_command_spec['sha256']},
        'runtime_matrix_cli_references': runtime_cli_references,
        'candidate_cli': cli_pin,
        'source_closure_count_at_start': len(source_pins_before),
        'required_dynamic_source_paths': sorted(REQUIRED_DYNAMIC_SOURCE_PATHS),
        'source_pins_before': source_pins_before,
        'source_pins_after': None,
        'stripped_environment_keys': stripped,
        'rust_min_stack': env.get('RUST_MIN_STACK'),
        'rustup_toolchain': env.get('RUSTUP_TOOLCHAIN'),
        'environment_overrides': guard.ENV_VALUES,
        'fresh_target_preflight': {'target_absent': True, 'free_bytes': free_before},
        'guard_limits': {'minimum_free_bytes': FREE_LIMIT, 'maximum_target_bytes': TARGET_LIMIT,
                         'poll_interval_seconds': 1},
        'references': [
            {'path': focused.get('runner', {}).get('path'), 'sha256': focused.get('runner', {}).get('sha256')},
            {'path': focused_command_spec['path'], 'sha256': focused_command_spec['sha256']},
            {'path': str(Path(__file__).resolve()),
             'sha256': sha256(Path(__file__).resolve())},
            {'path': str(TEMPLATE), 'sha256': TEMPLATE_SHA256},
            {'path': str(SCAN_PATH), 'sha256': SCAN_SHA256},
            {'path': str(focused_path),
             'sha256': args.focused_receipt_sha256},
            {'path': runtime_debug['receipt']['path'], 'sha256': runtime_debug['receipt']['sha256']},
            {'path': runtime_none['receipt']['path'], 'sha256': runtime_none['receipt']['sha256']},
            {'path': str(candidate_cli), 'sha256': cli_pin['sha256']},
        ],
        'docellipsis_exceptions': [
            {'include': include, 'source': source}
            for include, source in sorted(DOCELLIPSIS_EXCEPTIONS)
        ],
        'commands': [],
        'removed_completed_test_executables': [],
        'cleanup': {'armed_after_fresh_target_preflight': True},
        'runner': None,
    }
    runner_path = Path(__file__).resolve()
    record['runner'] = {'path': str(runner_path), 'sha256_before': sha256(runner_path)}

    def save() -> None:
        temporary = OUT / 'execution.json.tmp'
        temporary.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        temporary.replace(OUT / 'execution.json')

    def assert_sources_unchanged(stage: str) -> None:
        current = pin_sources(source_paths())
        if current != source_pins_before:
            record['source_change_detected_at'] = stage
            record['source_pins_after'] = current
            raise RuntimeError(f'workspace source closure changed at {stage}')

    def command(index: int, argv: list[str], *, allow_nonzero: bool = False) -> dict:
        assert_sources_unchanged(f'before-command-{index}')
        row = guard.run_command(index, argv, env)
        record['commands'].append(row)
        save()
        if row['guard_stop'] is not None or (row['exit_code'] != 0 and not allow_nonzero):
            raise RuntimeError(f'command {index} failed or hit a guard')
        assert_sources_unchanged(f'after-command-{index}')
        return row

    def cleanup_only_command(index: int) -> dict:
        argv = ['cargo', 'clean']
        if argv != ['cargo', 'clean']:
            raise RuntimeError('cleanup-only path accepts exactly cargo clean')
        before = {'target_bytes': guard.target_bytes(), 'free_bytes': __import__('shutil').disk_usage(ROOT).free}
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        began = time.monotonic()
        stdout_path, stderr_path = OUT / f'{index}.stdout.raw', OUT / f'{index}.stderr.raw'
        with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr,
                                     start_new_session=True)
            exit_code = child.wait()
        after = {'target_bytes': guard.target_bytes(), 'free_bytes': __import__('shutil').disk_usage(ROOT).free}
        return {
            'index': index, 'argv': argv, 'cwd': str(ROOT), 'started_at': started,
            'duration_seconds': time.monotonic() - began, 'exit_code': exit_code,
            'guard_stop': None, 'peak_target_bytes': max(before['target_bytes'], after['target_bytes']),
            'free_bytes_after': after['free_bytes'], 'env_overrides': guard.ENV_VALUES,
            'test_summary_check': None,
            'streams': {'stdout': guard.command_stream(stdout_path), 'stderr': guard.command_stream(stderr_path)},
            'cleanup_only': {'exact_argv': ['cargo', 'clean'], 'space_precheck_bypassed': True,
                             'space_monitor_abort_bypassed': True, 'observed_before': before,
                             'observed_after': after},
        }

    def make_batches(metadata: dict) -> tuple[list[list[str]], list[tuple[str, str, str]]]:
        members = set(metadata['workspace_members'])
        commands: list[list[str]] = []
        coverage: list[tuple[str, str, str]] = []
        for package in metadata['packages']:
            if package['id'] not in members:
                continue
            base = ['cargo', 'test', '-p', package['name'], '--all-features', '--locked',
                    '--message-format', 'json']
            unit_targets = [target for target in package['targets']
                            if target['kind'][0] in ('lib', 'bin', 'example', 'bench')]
            if unit_targets:
                flags = []
                for kind, flag in (('lib', '--lib'), ('bin', '--bins'),
                                   ('example', '--examples'), ('bench', '--benches')):
                    if any(target['kind'][0] == kind for target in unit_targets):
                        flags.append(flag)
                commands.append(base + flags)
                coverage.extend((package['name'], target['name'], target['kind'][0])
                                for target in unit_targets)
            test_targets = [target for target in package['targets']
                            if target['kind'][0] == 'test']
            for start in range(0, len(test_targets), 4):
                batch = test_targets[start:start + 4]
                commands.append(base + sum((['--test', target['name']] for target in batch), []))
                coverage.extend((package['name'], target['name'], 'test') for target in batch)
        expected = [(package['name'], target['name'], target['kind'][0])
                    for package in metadata['packages'] if package['id'] in members
                    for target in package['targets']]
        if sorted(coverage) != sorted(expected) or len(coverage) != len(set(coverage)):
            raise RuntimeError('metadata target coverage is not exact and unique')
        return commands, expected

    try:
        record['runner']['sha256_after'] = sha256(runner_path)
        if record['runner']['sha256_after'] != record['runner']['sha256_before']:
            raise RuntimeError('runner source changed before execution')
        save()
        fmt = command(0, ['cargo', 'fmt', '--all', '--', '--check'])
        record['format_check'] = {'exit_code': fmt['exit_code'], 'guard_stop': fmt['guard_stop']}
        metadata_row = command(1, ['cargo', 'metadata', '--no-deps', '--format-version', '1', '--locked'])
        metadata_bytes = (OUT / '1.stdout.raw').read_bytes()
        (OUT / 'metadata.json').write_bytes(metadata_bytes)
        metadata = json.loads(metadata_bytes)
        batches, expected_targets = make_batches(metadata)
        static_targets = static_target_inventory()
        if sorted(expected_targets) != static_targets:
            missing = sorted(set(static_targets) - set(expected_targets))
            unexpected = sorted(set(expected_targets) - set(static_targets))
            raise RuntimeError(f'Cargo metadata target inventory differs from manifests/files; missing={missing}, unexpected={unexpected}')
        expected_batches_from_inventory = sum(
            1 for package in metadata['packages'] if package['id'] in set(metadata['workspace_members'])
            and any(target['kind'][0] in ('lib', 'bin', 'example', 'bench') for target in package['targets'])
        ) + sum(
            (sum(1 for target in package['targets'] if target['kind'][0] == 'test') + 3) // 4
            for package in metadata['packages'] if package['id'] in set(metadata['workspace_members'])
        )
        if len(batches) != expected_batches_from_inventory:
            raise RuntimeError(f'computed batch count mismatch: {len(batches)} != {expected_batches_from_inventory}')
        members = set(metadata['workspace_members'])
        expected_ids = [(package['id'], target['name'], target['kind'][0])
                        for package in metadata['packages'] if package['id'] in members
                        for target in package['targets']]
        record['metadata'] = {'command_index': metadata_row['index'],
                              'workspace_member_count': len(members),
                              'target_count': len(expected_targets),
                              'batch_count': len(batches)}
        record['target_inventory'] = expected_targets
        record['expected_batch_count'] = len(batches)
        record['expected_target_count'] = len(expected_targets)
        record['expected_command_count_including_clean'] = 2 + len(batches) * len(SEEDS) + 1
        record['static_manifest_target_inventory'] = static_targets
        save()

        all_summaries = []
        all_actual_targets = []
        focused_outcomes_by_seed = {seed: [] for seed in SEEDS}
        for seed_index, seed in enumerate(SEEDS):
          env['PROPTEST_RNG_SEED'] = seed
          guard.ENV_VALUES = {**guard.ENV_VALUES, 'PROPTEST_RNG_SEED': seed}
          for batch_offset, argv in enumerate(batches):
            batch_index = 2 + seed_index * len(batches) + batch_offset
            row = command(batch_index, argv, allow_nonzero=True)
            row['proptest_seed'] = seed
            raw = (OUT / f'{batch_index}.stdout.raw').read_text(encoding='utf-8', errors='replace')
            summary_rows = [{'status': match.group(1), 'passed': int(match.group(2)),
                             'failed': int(match.group(3)), 'ignored': int(match.group(4)),
                             'raw_line': raw[match.start():].splitlines()[0]}
                            for match in SUMMARY_RE.finditer(raw)]
            summaries = [(row['passed'], row['failed'], row['ignored']) for row in summary_rows]
            outcomes = [{'name': match.group(1), 'status': match.group(2), 'raw_line': match.group(0)}
                        for match in OUTCOME_RE.finditer(raw)]
            expected_outcome_count = sum(passed + failed + ignored for passed, failed, ignored in summaries)
            row['observed_summaries'] = summary_rows
            row['actual_test_summaries'] = summary_rows
            row['named_test_outcomes'] = outcomes
            row['named_test_outcome_count'] = len(outcomes)
            row['summary_test_totals'] = [sum(item[index] for item in summaries) for index in range(3)]
            save()
            failed_summary_rows = [item for item in summary_rows
                                   if item['status'] != 'ok' or item['failed'] != 0]
            failed_named_outcomes = [item for item in outcomes if item['status'] == 'FAILED']
            if (row['exit_code'] != 0 or row['guard_stop'] is not None
                    or not summary_rows or failed_summary_rows or failed_named_outcomes):
                failure = {
                    'batch': batch_index,
                    'seed': seed,
                    'exit_code': row['exit_code'],
                    'guard_stop': row['guard_stop'],
                    'summaries': summary_rows,
                    'failed_outcomes': failed_named_outcomes,
                    'raw_streams': row.get('streams'),
                }
                raise RuntimeError('workspace product test command failed before artifact parsing: '
                                   + json.dumps(failure, ensure_ascii=False, separators=(',', ':')))
            if len(outcomes) != expected_outcome_count:
                raise RuntimeError(f'batch {batch_index} named outcome/summary mismatch: '
                                   f'{len(outcomes)} outcomes != {expected_outcome_count}')
            actual_targets = []
            executables = []
            for line in raw.splitlines():
                if not line.startswith('{'):
                    continue
                artifact = json.loads(line)
                if artifact.get('reason') != 'compiler-artifact':
                    continue
                profile = artifact.get('profile', {})
                executable = artifact.get('executable')
                if profile.get('test') and executable:
                    target = artifact['target']
                    actual_targets.append((artifact['package_id'], target['name'], target['kind'][0]))
                    executable_path = Path(executable)
                    if not executable_path.is_absolute():
                        executable_path = ROOT / executable_path
                    if executable_path.is_symlink():
                        raise RuntimeError(f'refusing to remove symlink test executable: {executable_path}')
                    executables.append((target['kind'][0], executable_path.resolve(strict=True)))
            if len(actual_targets) != len(set(actual_targets)) or len(actual_targets) != len(summaries):
                raise RuntimeError(f'batch {batch_index} summary/artifact cardinality mismatch')
            if len(executables) != len(set(executables)):
                raise RuntimeError(f'batch {batch_index} reported duplicate test executables')
            row['observed_counts'] = [list(item) for item in summaries]
            row['executed_targets'] = [list(item) for item in actual_targets]
            all_summaries.extend(summaries)
            all_actual_targets.extend((seed, *item) for item in actual_targets)
            for outcome in outcomes:
                if outcome['name'] in FOCUSED_EXPECTED_OUTCOMES:
                    focused_outcomes_by_seed[seed].append((outcome['name'], outcome['status']))
            for kind, executable in executables:
                deps = (ROOT / 'target/debug/deps').resolve(strict=True)
                expected_parent = (ROOT / 'target/debug/examples').resolve(strict=True) if kind == 'example' else deps
                if executable.parent != expected_parent or executable.is_symlink():
                    raise RuntimeError(f'refusing to remove out-of-scope test executable: {executable}')
                info = executable.lstat()
                if not stat.S_ISREG(info.st_mode) or not info.st_mode & 0o111:
                    raise RuntimeError(f'refusing to remove non-executable/non-regular artifact: {executable}')
                removed = {'path': str(executable), 'bytes': info.st_size,
                           'sha256': sha256(executable), 'completed_batch': batch_index}
                executable.unlink()
                record['removed_completed_test_executables'].append(removed)
            save()
            print(json.dumps({'seed': seed, 'completed_batch': batch_offset + 1,
                              'total_batches': len(batches),
                              'test_totals': row['summary_test_totals']}), flush=True)

        expected_seed_targets = [(seed, *target) for seed in SEEDS for target in expected_ids]
        if sorted(all_actual_targets) != sorted(expected_seed_targets) or len(all_actual_targets) != len(set(all_actual_targets)):
            raise RuntimeError('actual executed target set is not exact and unique for both CI seeds')
        if sum(item[0] for item in all_summaries) <= 0:
            raise RuntimeError('workspace had no passing tests')
        for seed in SEEDS:
            actual = focused_outcomes_by_seed[seed]
            if len(actual) != len(FOCUSED_EXPECTED_OUTCOMES) or dict(actual) != FOCUSED_EXPECTED_OUTCOMES:
                raise RuntimeError(f'focused named outcomes differ for seed {seed}: {actual}')
        passing_names = {item['name'] for row in record['commands']
                         for item in row.get('named_test_outcomes', []) if item['status'] == 'ok'}
        missing_required_tests = REQUIRED_NAMED_TESTS - passing_names
        observed_ignored = {item['name'] for row in record['commands'] for item in row.get('named_test_outcomes', []) if item['status'] == 'ignored'}
        missing_required_ignored = REQUIRED_IGNORED_TESTS - observed_ignored
        required_by_seed = {}
        for seed in SEEDS:
            rows = [item for row in record['commands'] if row.get('proptest_seed') == seed
                    for item in row.get('named_test_outcomes', []) if item['name'] in REQUIRED_NAMED_TESTS]
            counts = {name: sum(item['name'] == name for item in rows) for name in REQUIRED_NAMED_TESTS}
            bad = {item['name']: item['status'] for item in rows if item['status'] != 'ok'}
            if any(count != 1 for count in counts.values()) or bad:
                raise RuntimeError(f'required named test outcomes are not exactly once and passing for seed {seed}: counts={counts}, bad={bad}')
            required_by_seed[seed] = {item['name']: item['status'] for item in rows}
        if missing_required_tests or missing_required_ignored:
            raise RuntimeError(f'required workspace test outcomes differ: missing passing={sorted(missing_required_tests)}, missing ignored={sorted(missing_required_ignored)}')
        record['required_named_tests'] = sorted(REQUIRED_NAMED_TESTS)
        record['required_named_tests_passed'] = sorted(REQUIRED_NAMED_TESTS & passing_names)
        record['required_named_test_outcomes_by_seed'] = required_by_seed
        record['required_named_test_groups'] = {name: sorted(names) for name, names in REQUIRED_NAMED_TEST_GROUPS.items()}
        record['focused_named_outcomes'] = {seed: [{'name': name, 'status': state} for name, state in focused_outcomes_by_seed[seed]] for seed in SEEDS}
        record['required_ignored_tests'] = sorted(REQUIRED_IGNORED_TESTS)
        record['workspace_summary_count'] = len(all_summaries)
        record['workspace_totals'] = [sum(item[index] for item in all_summaries) for index in range(3)]
        record['status'] = 'passed'
    except BaseException as error:
        record['status'] = 'failed'
        record['error'] = f'{type(error).__name__}: {error}'
    finally:
        if clean_armed:
            cleanup = {'attempted': True, 'argv': ['cargo', 'clean'], 'guarded': False, 'cleanup_only': True}
            try:
                clean_row = cleanup_only_command(len(record['commands']))
                record['commands'].append(clean_row)
                cleanup['command'] = clean_row
                cleanup['status'] = ('passed' if clean_row['exit_code'] == 0
                                     and clean_row['guard_stop'] is None and clean_row.get('cleanup_only', {}).get('exact_argv') == ['cargo', 'clean'] else 'failed')
                if cleanup['status'] != 'passed':
                    record['status'] = 'failed'
                    record.setdefault('error', 'cleanup-only cargo clean failed')
            except BaseException as error:
                cleanup['status'] = 'failed-before-completion'
                cleanup['error'] = f'{type(error).__name__}: {error}'
                record['status'] = 'failed'
                record.setdefault('error', f'cleanup-only cargo clean: {type(error).__name__}: {error}')
            cleanup['target_absent_after'] = not (ROOT / 'target').exists()
            cleanup['source_pins_after'] = pin_sources(source_paths())
            cleanup['pins_unchanged'] = cleanup['source_pins_after'] == source_pins_before
            if not cleanup['target_absent_after'] or not cleanup['pins_unchanged']:
                record['status'] = 'failed'
                record.setdefault('error', 'cleanup postcondition failed')
            record['cleanup'] = cleanup
        record['observed_command_count_including_clean'] = len(record['commands'])
        if (record.get('status') == 'passed'
                and record.get('observed_command_count_including_clean')
                != record.get('expected_command_count_including_clean')):
            record['status'] = 'failed'
            record.setdefault('error', 'observed command count differs from computed format/metadata/batch/clean plan')
        record['source_pins_after'] = pin_sources(source_paths())
        if record['source_pins_after'] != source_pins_before:
            record['status'] = 'failed'
            record.setdefault('error', 'workspace source pins changed')
        record['runner']['sha256_after'] = sha256(runner_path)
        if record['runner']['sha256_after'] != record['runner']['sha256_before']:
            record['status'] = 'failed'
            record.setdefault('error', 'runner source changed during execution')
        record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        temporary = OUT / 'execution.json.tmp'
        temporary.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        temporary.replace(OUT / 'execution.json')
    print(json.dumps({**{key: record.get(key) for key in ('status', 'error', 'expected_batch_count', 'expected_target_count', 'workspace_summary_count', 'workspace_totals')}, 'cleanup_status': record.get('cleanup', {}).get('status'), 'target_absent': record.get('cleanup', {}).get('target_absent_after')}))
    return 0 if record['status'] == 'passed' and record.get('cleanup', {}).get('status') == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
