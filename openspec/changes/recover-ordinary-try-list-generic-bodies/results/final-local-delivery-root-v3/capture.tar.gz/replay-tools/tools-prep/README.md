# Ordinary try List validation runners

These scripts prepare fresh, guarded validation runs for the current Jarde workspace. Start only after confirming `/home/lordcasser/workspace/projects/jarde/target` is absent. They require 5 GiB free space and stop a process group if the workspace target exceeds 1 GiB or free space falls below the limit. Both runners finish with the exact `cargo clean` command and verify the target is absent.

`focused_runner.py` runs the seven focused checks and writes its immutable CLI (mode `0555`) and execution receipt. Example invocation, with fresh output names:

```sh
python3 /home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/focused_runner.py \
  --out /home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/focused-run \
  --frozen-cli /home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/candidate-cli \
  --receipt /home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/focused-receipt.json
```

`workspace_runner.py` is based on archived `workspace-previous/tools/001-workspace_runner.py`. It preserves its full-source closure, frozen CLI/runtime debug-none receipts, metadata target census, two fixed seeds, completed-test-artifact cleanup, and cleanup receipt checks. Supply the focused receipt and both runtime-matrix receipts with their independently computed SHA-256 values; `--out` must name a fresh persistent directory. It executes current CI workspace test targets over both seeds.

No JDK/JADX/Cargo/rustfmt command was run while preparing these scripts. Only Python AST syntax parsing was used for static validation.
