#!/usr/bin/env bash
set -euo pipefail
: "${RUNNER_TEMP:?required evidence directory}"
export RUSTUP_TOOLCHAIN=stable
cargo tree --workspace --all-features --locked -e features > "$RUNNER_TEMP/feature-tree.txt"
grep -F 'blake3 feature "pure"' "$RUNNER_TEMP/feature-tree.txt"
grep -F 'flate2 feature "rust_backend"' "$RUNNER_TEMP/feature-tree.txt"
# petgraph is admitted with `default-features = false, features = ["std"]` only
# (design 3.1). Assert both directions: `std` must be resolved, and no other
# petgraph feature may reappear, because the default set adds
# graphmap/stable_graph/matrix_graph, `rayon` pulls a thread pool, `serde-1` the
# serde family and `all` a dot parser — none of which the slice uses, and the
# normal-tree grep only catches `rayon` by name.
grep -F 'petgraph feature "std"' "$RUNNER_TEMP/feature-tree.txt"
if grep -E 'petgraph feature "(graphmap|stable_graph|matrix_graph|rayon|serde-1|serde|serde_derive|all|quickcheck|dot_parser|unstable|generate)"' "$RUNNER_TEMP/feature-tree.txt"; then
  echo 'petgraph resolved features outside the admitted std-only set' >&2
  exit 1
fi
cargo tree --workspace --all-features --locked -e normal > "$RUNNER_TEMP/normal-tree.txt"
if grep -E '(^|[[:space:]├└─])(tokio([^[:alnum:]_]|$)|async-std([^[:alnum:]_]|$)|rayon([^[:alnum:]_]|$)|sqlx([^[:alnum:]_]|$)|rusqlite([^[:alnum:]_]|$)|tree-sitter([^[:alnum:]_]|$)|reverse-engine-backend-api([^[:alnum:]_]|$)|ristretto_vm([^[:alnum:]_]|$)|jni([^[:alnum:]_]|$)|jvm([^[:alnum:]_]|$)|reqwest([^[:alnum:]_]|$)|hyper([^[:alnum:]_]|$)|ureq([^[:alnum:]_]|$)|surf([^[:alnum:]_]|$)|diesel([^[:alnum:]_]|$)|sea-orm([^[:alnum:]_]|$)|mongodb([^[:alnum:]_]|$)|redis([^[:alnum:]_]|$))' "$RUNNER_TEMP/normal-tree.txt"; then
  echo 'unexpected production dependency crossed the P0 boundary' >&2
  exit 1
fi
# The teeth of this step are `errexit`: every check reports a violation by returning
# non-zero from a function called in a loop, and only `-e` turns that into a failed
# step. GitHub's default shell for a `run` block does include it, but relying on that
# is relying on an undocumented detail of the runner: with a plain interpreter the
# violation is printed and the step still succeeds. State the requirement here instead.
set -euo pipefail
# `--format '{p}'` prints "name version" per line and `--prefix none` drops the tree
# drawing, so the `sed` reduces every line to a package name. (With the default prefix
# each line would start with `├──`, which the `sed` would then read as the name — the
# gate would compare four box-drawing tokens and pass on anything.) The default format
# also prints the checkout path, where `…/jarde/crates/…` holds the facade's name as a
# path segment; exact whole-line matching (`-x` with `-F`) is what keeps `jarde` from
# matching `jarde-reader` and vice versa.
closure_violation() {
  local edges="$1"
  local features="$2"
  local package="$3"
  shift 3
  # The feature flag has to be part of the file name: the same package is checked
  # under both feature configurations and the second run would otherwise overwrite
  # the first one's evidence.
  local tag="$package-$edges${features:+-all-features}"
  local raw="$RUNNER_TEMP/closure-$tag.raw"
  local names="$RUNNER_TEMP/closure-$tag.txt"
  if ! cargo tree -p "$package" --edges "$edges" $features --locked --prefix none \
    --format '{p}' > "$raw"; then
    echo "cargo tree could not read the $edges closure of $package ($tag)" >&2
    cat "$raw" >&2
    return 1
  fi
  sed -E 's/ .*$//' "$raw" | sort -u > "$names"
  if ! grep -qxF "$package" "$names"; then
    echo "$package is missing from its own $edges closure ($tag); no tree was read" >&2
    return 1
  fi
  for forbidden in "$@"; do
    if grep -qxF "$forbidden" "$names"; then
      echo "$package reaches $forbidden across the layering ($tag):" >&2
      cat "$names" >&2
      return 1
    fi
  done
  echo "$tag closure: $(wc -l < "$names" | tr -d ' ') packages, none of [$*]"
}
# Four configurations per layer. `normal` and `all` cover the production, dev and
# build edges; `--all-features` covers a dependency that is only reachable with a
# feature that is not enabled by default - without it, a layer could pull a forbidden
# package behind such a feature and this step would still read a clean tree. The
# feature flags are the only thing that varies here: a dependency being optional
# widens the reachable set, so the union is what has to be checked.
# `jarde-java` does not exist yet and is named anyway: the recovery layer the design
# puts above the analysis layer has to stay above it, and a forbidden name costs
# nothing today while catching the mistake on the day that package appears.
for edges in normal all; do
  for features in "" "--all-features"; do
    closure_violation "$edges" "$features" jarde-reader jarde jarde-query jarde-jvm jarde-java petgraph
    closure_violation "$edges" "$features" jarde-query jarde jarde-jvm jarde-java petgraph
    closure_violation "$edges" "$features" jarde-jvm jarde jarde-java
  done
done
