#!/usr/bin/env python3
"""Pure helper observation, not audit_candidate.main and not candidate acceptance."""
import argparse,datetime,json,pathlib,runpy,sys,time
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--captures-root',type=pathlib.Path,required=True)
p.add_argument('--out',type=pathlib.Path,required=True)
a=p.parse_args();a.out.mkdir(exist_ok=False,parents=True)
review=pathlib.Path(__file__).resolve().parent
ns=runpy.run_path(str(review/'audit_candidate.py'),run_name='pure_helpers')
decode=ns['load_decoder'](ns['DEFAULT_REFERENCE']);before=ns['pin'](review/'audit_candidate.py')
observations=[];started=datetime.datetime.now(datetime.timezone.utc).isoformat();tic=time.monotonic()
for family in ('baseline','admission'):
 for debug in ('debug','none'):
  start=len(ns['errors'])
  try:
   result=ns['audit_capture'](family,debug,a.captures_root/family/debug,ns['DEFAULT_ROOT'],ns['DEFAULT_REFERENCE'],decode)
   result.pop('_oracles',None)
   observations.append({'family':family,'debug':debug,'finished_helper':True,'new_errors':ns['errors'][start:],'observations':result})
  except Exception as exc:
   observations.append({'family':family,'debug':debug,'finished_helper':False,'new_errors':ns['errors'][start:],'exception':type(exc).__name__+': '+str(exc)})
summary=[]
for row in observations:
 r=row.get('observations',{})
 summary.append({'family':row['family'],'debug':row['debug'],'finished_helper':row['finished_helper'],'error_count':len(row['new_errors']),'exception':row.get('exception'),'Jarde':[(x['jdk'],x['mode'],x['compile_run']['compile_exit'],x['compile_run']['runtime_state']) for x in r.get('jarde',[])],'JADX':r.get('jadx',[])})
report={'schema':'ordinary-try-candidate-auditor-matrix-helper-probe-v1','scope':'pure helper self-inspection of retained captures; NOT candidate main/acceptance','argv':sys.argv,'started_at':started,'duration_seconds':time.monotonic()-tic,'python':ns['pin'](sys.executable),'python_version':sys.version,'auditor_before':before,'auditor_after':ns['pin'](review/'audit_candidate.py'),'helper':ns['pin'](__file__),'hash_dependency':ns['blake3_dependency'](),'summary':summary,'observations':observations}
(a.out/'observations.json').write_text(json.dumps(report,indent=2)+'\n')
(a.out/'stdout.raw').write_text(json.dumps(summary,indent=2)+'\n');(a.out/'stderr.raw').write_bytes(b'')
print(json.dumps(summary,indent=2));print('observationpath',a.out/'observations.json')
