#!/usr/bin/env python3
"""Pure parser/audit helper selfcheck; never invokes candidate main or toolchains."""
import ast, copy, hashlib, json, pathlib, runpy
HERE = pathlib.Path(__file__).resolve().parent
ns = runpy.run_path(str(HERE / 'audit_candidate.py'), run_name='pure_helpers')
ast.parse((HERE / 'audit_candidate.py').read_text())
ref = ns['DEFAULT_REFERENCE']; decode = ns['load_decoder'](ref); results = []
assert ns['class_digest'](b'') == 'af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262'
assert ns['class_digest'](b'abc') == '6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85'
hash_dependency = ns['blake3_dependency'](); assert hash_dependency['version'] == '1.0.11'
v4tree = ast.parse((ref / 'auditor-v4/audit.py').read_text())
fn = next(n for n in v4tree.body if isinstance(n, ast.FunctionDef) and n.name == 'physical_methods')
v4 = {'pathlib': pathlib}
exec(compile(ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[])), 'v4pure', 'exec'), v4)
for debug in ('debug', 'none'):
    for jdk in ns['JDKS']:
        path = ref / 'captures' / debug / 'legs' / (jdk + '-original/classes/cf11/UpstreamNestedLoops.class')
        physical = ns['class_file'](path); digest = ns['class_digest'](path.read_bytes())
        assert {k: m['code'] for k, m in physical['methods'].items()} == v4['physical_methods'](path)
        assert len(physical['methods']) == 17
        oracle = ns['baseline_oracle'](ref, debug, jdk); assert len(oracle[1].splitlines()) == 45
        paired = {}
        for mode in ns['MODES']:
            doc = json.loads((ref / 'captures' / debug / 'jarde' / (jdk + '-jarde-' + mode + '-UpstreamNestedLoops/report.json')).read_text())
            assert digest == doc['class']['class_bytes']['digest']
            paired[mode] = {'text': doc['text'], 'methods': [(r['declaration'], r['outcome']['report']['text'], r['outcome']['report']['source_map'], r['outcome']['report']['artifact']['binding']['method']) for r in doc['methods']]}
            for row in doc['methods']:
                key, _ = ns['method_identity'](row)
                ns['map_audit'](row, physical, decode, digest, 'accepted-helper', physical['methods'][key]['name'] in ns['BASE_POS'])
        assert paired['default'] == paired['all']
        results.append(debug + '/' + jdk + ': original45, physical17, BLAKE3, 34methodmaps, default/all passed')
assert not ns['errors'], ns['errors']
# Matrix negatives derive from the accepted receipt, retaining its exact labels/keys.
receipt = json.loads((ref / 'captures/debug/execution.json').read_text())
complete = copy.deepcopy(receipt)
for profile in complete['jarde_profiles']:
    profile['render_exit'] = 0
for row in complete['jarde_compile_rows']:
    row.update(compile_exit=0, run_exit=0, runtime_state='ran', class_set_exact=True)
ns['required_jarde_cells'](complete, 'cf11.UpstreamNestedLoops', 'synthetic-complete-matrix')
assert not ns['errors'], ns['errors']
missing = copy.deepcopy(complete); missing['jarde_profiles'].pop()
ns['required_jarde_cells'](missing, 'cf11.UpstreamNestedLoops', 'missing-render')
assert any('render cells missing' in e for e in ns['errors']); ns['errors'].clear()
missing = copy.deepcopy(complete); missing['jarde_compile_rows'].pop()
ns['required_jarde_cells'](missing, 'cf11.UpstreamNestedLoops', 'missing-compile')
assert any('compile cells missing' in e for e in ns['errors']); ns['errors'].clear()
failed = copy.deepcopy(complete)
failed['jarde_compile_rows'][0].update(compile_exit=1, run_exit=None, runtime_state='no-runtime', class_set_exact=None)
ns['required_jarde_cells'](failed, 'cf11.UpstreamNestedLoops', 'failed-compile')
assert any('compile/runtime failure cannot be accepted' in e for e in ns['errors']); ns['errors'].clear()
results.append('missing render, missing compile, and failed Jarde compile/no-runtime rejected')
# Demonstrate rejection of counterfeit method identity and nonphysical BCI.
row = copy.deepcopy(doc['methods'][0]); row['outcome']['report']['artifact']['binding']['method'] = {}
ns['map_audit'](row, physical, decode, digest, 'tampered-binding')
assert any('artifact method binding differs' in e for e in ns['errors']); ns['errors'].clear()
row = copy.deepcopy(doc['methods'][0]); row['outcome']['report']['source_map']['segments'][0]['origin']['primary']['bci'] = 999999
ns['map_audit'](row, physical, decode, digest, 'tampered-bci')
assert any('nonphysical BCI' in e for e in ns['errors']); ns['errors'].clear()
# Adapt only the helper inputs to represent the five expected projection declarations.
fake = copy.deepcopy(doc); compiled = dict(physical); compiled['methods'] = copy.deepcopy(physical['methods'])
for row in fake['methods']:
    key, _ = ns['method_identity'](row); name = physical['methods'][key]['name']
    if name in ns['BASE_POS']:
        element, count = ns['BASE_POS'][name]
        formals = ['java.util.List<java.lang.' + element + '> p' + str(i) for i in range(count)]
        if name == 'tryStringRemovePrefix': formals.append('java.lang.Object key')
        row['declaration'] = 'public void ' + name + '(' + ', '.join(formals) + ')'
        row['markers'] = ['generic Signature projected after finite physical proof']
        row['text'] = row['text'].replace('.add((java.lang.Object)', '.add(')
    elif name in ns['BASE_NEG']:
        compiled['methods'][key]['signature'] = None
ns['projection_audit'](fake, physical, compiled, 'baseline', 'synthetic-good-projection', decode)
assert not ns['errors'], ns['errors']
obs = ns['projection_audit'](fake, physical, None, 'baseline', 'failed-compiled-class', decode)
assert any('compiled target class unavailable' in e for e in ns['errors'])
assert all(x['compiled_signature_state'] == 'unavailable-compile-failed' for x in obs)
assert not any('compiled positive Signature differs' in e for e in ns['errors'])
ns['errors'].clear()
key = next(k for k in compiled['methods'] if k.startswith('handled('))
compiled['methods'][key]['signature'] = None
ns['projection_audit'](fake, physical, compiled, 'baseline', 'tampered-signature', decode)
assert any('compiled positive Signature differs' in e for e in ns['errors']); ns['errors'].clear()
# Admission fixture pins and exact thirteen-method class table remain independently fixed.
fixture = ns['DEFAULT_ROOT'] / 'tests/fixtures/cf11-ordinary-try-list-generic/admission'
manifest = json.loads((fixture / 'manifest.json').read_text())
for key, entry in [('ADMISSION_SOURCE', manifest['target_classes'][0]), ('ADMISSION_RUNNER', manifest['runner'])]:
    data = (fixture / entry['source']).read_bytes()
    assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256'] == ns[key]
admission = ns['class_file'](fixture / 'OrdinaryTryListFixture.class'); assert len(admission['methods']) == 13
assert set(manifest['target_classes'][0]['candidate_methods']) == set(ns['ADM_POS']) | set(ns['ADM_NEG'])
key = next(k for k in admission['methods'] if k.startswith('catchVisibleIteratorGap('))
digest = ns['class_digest']((fixture / 'OrdinaryTryListFixture.class').read_bytes())
identity = {'name': list(b'catchVisibleIteratorGap'), 'descriptor': list(b'(Ljava/util/List;Ljava/util/List;)V'), 'owner': {'class_bytes': {'digest': digest}}}
text = 'java.util.Iterator cursor = input.iterator();\nmarker = 1;\nwhile (cursor.hasNext()) {}\n'
first = text.index('\n') + 1; second = text.index('\n', first) + 1
raw = {'method': key, 'outcome': 'produced', 'content': 'contains_statements', 'text': text, 'execution': {'status': 'complete'}, 'artifact': {'binding': {'method': identity}},
       'evidence': {'categories': [{'kind': 'source_map', 'state': {'state': 'complete'}}]},
       'source_map': {'segments': [{'start': 0, 'end': first, 'origin': {'primary': {'method': identity, 'bci': 3}, 'derived': []}},
                                    {'start': first, 'end': second, 'origin': {'primary': {'method': identity, 'bci': 11}, 'derived': []}}]}}
row = {'item': {'identity': identity}, 'outcome': {'kind': 'recovered', 'analysis': {'execution': {'status': 'complete'}}, 'report': raw}}
ns['map_audit'](row, admission, decode, digest, 'synthetic-gap'); assert not ns['errors'], ns['errors']
row['outcome']['report']['text'] = text.replace('while (', 'for (')
ns['map_audit'](row, admission, decode, digest, 'tampered-gap')
assert any('converted to foreach' in e for e in ns['errors']); ns['errors'].clear()
results += ['tampered binding, nonphysical BCI, positive compiled Signature, and gap foreach rejected',
            'admission exact source/Runner pins, thirteen physical methods, five positives/six controls passed']
report = {'status': 'passed', 'auditor': ns['pin'](HERE / 'audit_candidate.py'), 'hash_dependency': hash_dependency, 'checks': results,
          'scope': 'pure helper checks only; no candidate capture acceptance or toolchain execution'}
(HERE / 'selfcheck.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
