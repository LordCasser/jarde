class Release8Probe { public static int value() { return 1; } }
