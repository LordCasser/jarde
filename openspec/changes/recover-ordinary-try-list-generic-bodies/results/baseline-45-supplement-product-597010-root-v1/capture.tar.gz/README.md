# Ordinary try/List baseline 45-row supplement

Root v4 acceptance is `audited` with no errors. Both debug and none captures contain 27 commands and 54 receipt-bound raw streams; each original JDK run has 45 rows and an exact same-mode 44-row prefix. The added row is `try-catch-handler-mutable-output`.

Jarde has four successful compile/runtime comparison legs per mode, matching the original. JADX has four compile-failed/no-runtime legs per mode. These are baseline observations; this archive does not claim an implementation change. Final exact-clean receipt is included and records target absent before and after.

The complete captures retain source/input jars, class files, generated sources, reports, render output, receipts, and raw streams. Large CLI/JDK/JADX executables and Cargo target output are excluded; their pinned paths, sizes, and hashes remain in `tool-references/external-tool-pins.json`. The manifest records every member byte length/SHA-256 and receipt binding.
