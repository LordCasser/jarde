# Ordinary try-list baseline prep v4 (source only)

This is a fresh private copy of the v3 full-class collector and wrapper. Both scripts are byte-identical to v3. The sole candidate change is one `Runner` invocation of the existing `handled` method with a mutable output list, placed after all existing row-producing calls. `UpstreamNestedLoops.java` is byte-identical to v3; none of its methods were edited.

All previous 44 runtime-row calls remain in their original order and unchanged source bytes. That includes the existing 17-row original oracle prefix and all previous calls. The new row is named `try-catch-handler-mutable-output` and uses input `one,two` with an empty mutable output. This is only a test input; no resulting output or pass/fail verdict is prefilled. Prior baseline receipts/auditor records still describe their original 44 rows and are not changed.

`inputs/manifest.json` carries the full target class and Runner relative paths, byte counts, and SHA-256 values. The wrapper supplies that manifest and input directory to the unchanged collector. Candidate CLI and exact build receipt remain explicit runtime arguments through environment variables; use the actual reviewed CLI and matching real receipt when root runs it.

The unchanged collector requires a fresh `BASELINE_OUT` and refuses to overwrite an existing output. Its existing source closure and matrix remain: full target plus Runner; JDK 8 and 23; `-g` and `-g:none` selected per serial run; original, per-JDK JADX default/rename-none, and Jarde default/all. A compiler failure is retained as no-runtime with raw diagnostics; generated Java is never manually edited. CLI mode/receipt bindings, source/tool before/after pins, default JVM stack, 5 GiB free-space floor, 1 GiB shared `target/` cap, one-second guard polling, and process-group guard are retained.

When the collector is eventually executed, the appended Runner call is intended to add one row after the previous 44 in each full-class Runner execution, while the original baseline remains 44. This has not been observed. Future execution should use actual reviewed CLI/receipt pins and fresh output directories. For example, run debug and none serially:

```sh
CURRENT_CLI_PATH=/path/to/actual-candidate-cli \
CURRENT_CLI_SHA256=<actual-cli-sha256> \
CURRENT_BUILD_RECEIPT=/path/to/actual-build-receipt.json \
CURRENT_BUILD_RECEIPT_SHA256=<actual-receipt-sha256> \
RECEIPT_ACCEPTED_VALUE=commands_passed_pending_independent_acceptance \
BASELINE_DEBUG_INFO=debug \
BASELINE_OUT=/private/tmp/jarde-ordinary-try-list-mvp-debug-root-v4 \
sh /private/tmp/jarde-ordinary-try-list-mvp-baseline-prep-luna-v4/run-current.sh
```

Repeat with `BASELINE_DEBUG_INFO=none` and a different new `BASELINE_OUT`. If the real receipt uses another object/key layout, pass the exact selectors supported by the unchanged collector; do not infer those fields.

Static-only checks completed: Python AST parse of the collector; removing the one inserted call block reproduces the previous Runner file byte-for-byte; target source is unchanged; manifest bytes/SHA match both sources; wrapper is byte-identical to v3; collector retains fresh-output refusal and guard limits. No CLI, collector, Java toolchain, or baseline command was run.
