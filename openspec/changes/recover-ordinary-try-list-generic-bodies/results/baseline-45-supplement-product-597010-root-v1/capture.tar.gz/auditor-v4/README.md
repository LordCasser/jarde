# Ordinary try/List baseline auditor v4 (prepared, not run)

This is a new private copy of the root-reviewed v2 auditor with only the row-count and input bindings needed for the v4 Runner candidate, plus a same-mode/same-JDK old-output prefix check. The physical class method parser, classfile Code extraction, pinned CF07 instruction decoder, source-map identity/boundary checks, report-vs-render-stdout equality, default/all method/map comparisons, exact argv/source/class-set checks, resource guard checks, CLI/build receipt checks, and 17-row historical oracle checks remain in place. No existing v2 auditor, receipt, raw stream, or acceptance record was changed.

The current source manifest is pinned to `/private/tmp/jarde-ordinary-try-list-mvp-baseline-prep-luna-v4/inputs/manifest.json` (SHA-256 `354c207b0c45c9c17b1c1fe404396fa094ed2928d0666fdb6dc07e1c6a29aede`). The expected target source and Runner bytes/SHA are checked directly; the collector path and SHA are also required in the source/tool pins.

For each mode, the auditor validates the previously accepted 44-row capture receipt SHA and raw run output for both JDKs, then compares the new output’s first 44 rows byte-for-byte to that same-mode, same-JDK raw stdout. It requires exactly 45 output rows and checks the final row byte-for-byte: `try-catch-handler-mutable-output|exception=none|left=[one, two]|right=[one, two]|effects=2`. The existing 17-row prefix check against the legacy oracle remains separate. The verifier makes no generic-projection success or failure judgment.

Root may invoke this after supplying the actual final-clean receipt for the current toolchain session. The auditor refuses to overwrite its output path. This preparation did not execute the auditor, collector, CLI, Cargo, JDK, or JADX. Static source and raw-file comparisons confirmed both new captures have 45 rows, each prior 44-row output is an exact byte prefix for its matching debug mode/JDK, and the added line matches the exact value/effects above.

```sh
python3 -B /private/tmp/jarde-ordinary-try-list-mvp-baseline-audit-luna-v4/audit.py \
  --debug-capture /private/tmp/jarde-ordinary-try-list-45-debug-baseline-root-v1 \
  --none-capture /private/tmp/jarde-ordinary-try-list-45-none-baseline-root-v1 \
  --previous-debug-capture /private/tmp/jarde-ordinary-try-list-debug-baseline-root-v2 \
  --previous-none-capture /private/tmp/jarde-ordinary-try-list-none-baseline-root-v1 \
  --final-clean-receipt /private/tmp/jarde-ordinary-try-list-45-baseline-final-clean-root-v1/execution.json \
  --out /private/tmp/jarde-ordinary-try-list-mvp-baseline-audit-luna-v4/audit.json
```


V4 serialization fix: the 44-row stdout/stderr `bytes` objects remain in memory for exact-prefix comparison. Before JSON output, the previous-oracle section is converted to capture/mode/receipt/row metadata plus each stream’s byte length and SHA-256. Raw bytes are not coerced to strings or included in JSON. This avoids `json.dumps` failing on bytes while leaving the comparison and all acceptance gates intact. The v4 auditor has not been executed.
