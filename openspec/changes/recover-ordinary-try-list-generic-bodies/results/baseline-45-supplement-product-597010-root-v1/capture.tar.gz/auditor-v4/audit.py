#!/usr/bin/env python3
"""Independent read-only auditor for paired ordinary-Try/List full-class captures."""
import argparse
import ast
import hashlib
import json
import os
import pathlib
import re
import sys
import struct
import zipfile

MIN_FREE = 5 * 1024**3
MAX_TARGET = 1024**3
EXPECTED_OLD_ORACLE_ROWS = 17
EXPECTED_PREVIOUS_RUNNER_ROWS = 44
EXPECTED_CURRENT_RUNNER_ROWS = 45
EXPECTED_HANDLED_ROW = b'try-catch-handler-mutable-output|exception=none|left=[one, two]|right=[one, two]|effects=2\n'
PREP_ROOT = pathlib.Path('/private/tmp/jarde-ordinary-try-list-mvp-baseline-prep-luna-v4')
PREP_MANIFEST_SHA256 = '354c207b0c45c9c17b1c1fe404396fa094ed2928d0666fdb6dc07e1c6a29aede'
PREP_RUNNER_SHA256 = 'd810c2466b31edc6d9df9b7286dedc21ca77428fa329f86d98d8a36d6f7dee7d'
PREP_TARGET_SHA256 = 'edc6d5ab7258ad79eb13cc0163c042dcdc885dd3d3d160829a098a8b5d98a1ed'
PREP_COLLECTOR_SHA256 = '74141123bb2e1a2be6e488b54b6b2a3a8adb8961ddfa935a3fb31a34a581b823'
PREVIOUS_CAPTURE_RECEIPTS = {
    'debug': ('/private/tmp/jarde-ordinary-try-list-debug-baseline-root-v2/execution.json', 'f9b25f4f93c98c795618590ec75041dd827bd058f344e1c1e8a16dfc92b271e3'),
    'none': ('/private/tmp/jarde-ordinary-try-list-none-baseline-root-v1/execution.json', 'b94ca14e7940a4eb4a964172337393e496ed061195e26af2a8eceb79c53d258b'),
}
CURRENT_CAPTURE_RECEIPTS = {
    'debug': ('/private/tmp/jarde-ordinary-try-list-45-debug-baseline-root-v1/execution.json', '2b83bb12372c93c468936da48fbf77b70abae94c8b4e72fcfbb08b8c0c0e6945'),
    'none': ('/private/tmp/jarde-ordinary-try-list-45-none-baseline-root-v1/execution.json', '0b8d1d710540c8a24cecde8d94a91c78038a404391900d4ff0d3409b1cc159ff'),
}
JDKS = ('javac8', 'javac23')
JADX_PROFILES = ('default', 'none')
JARDE_MODES = ('default', 'all')
SAME_NAME_METHOD_HELPER = pathlib.Path('/private/tmp/jarde-same-name-reference-accept-root-v1.py')
SAME_NAME_METHOD_HELPER_SHA256 = '51dd51c2f5a65d2ece32a0d20f34576f4ad2da9af6e0d31f1e66f9c8540081a1'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8'))


def pin(path):
    p = pathlib.Path(path)
    data = p.read_bytes()
    return {'path': str(p.resolve()), 'bytes': len(data), 'sha256': sha(data)}


def require(condition, message, errors):
    if not condition:
        errors.append(message)


def raw_stream(capture, row, stream, errors):
    meta = row.get('streams', {}).get(stream)
    if not isinstance(meta, dict) or not isinstance(meta.get('path'), str):
        errors.append(f"{capture.name}:{row.get('index')} missing raw {stream}")
        return b''
    p = pathlib.Path(meta['path'])
    try:
        data = p.read_bytes()
    except OSError as exc:
        errors.append(f'{capture.name}:{row.get("index")} raw missing {p}: {exc}')
        return b''
    require(p.parent == capture / 'raw', f'{capture.name}: raw path escaped raw directory: {p}', errors)
    require(len(data) == meta.get('bytes') and sha(data) == meta.get('sha256'),
            f'{capture.name}:{row.get("index")} {stream} raw pin mismatch', errors)
    return data


def live_pins(receipt, capture, errors):
    before = receipt.get('source_tool_pins_before')
    after = receipt.get('source_tool_pins_after')
    require(isinstance(before, list) and before == after,
            f'{capture.name}: source/tool before/after pins differ or are absent', errors)
    if not isinstance(before, list):
        return
    for item in before:
        try:
            actual = pin(item['path'])
        except (OSError, KeyError, TypeError) as exc:
            errors.append(f'{capture.name}: source/tool pin unavailable: {exc}')
            continue
        require(actual['bytes'] == item.get('bytes') and actual['sha256'] == item.get('sha256'),
                f'{capture.name}: live source/tool pin mismatch: {item.get("path")}', errors)


def command_by_label(receipt):
    return {row.get('label'): row for row in receipt.get('commands', []) if isinstance(row, dict)}


def check_runtime_row(row, receipt, capture, oracle, expected_class_paths, errors):
    label = row.get('label', '<unnamed>')
    jdk = label.split('-', 1)[0]
    compile_exit = row.get('compile_exit')
    compile_cmd = command_by_label(receipt).get(row.get('compile_command'))
    require(compile_cmd is not None, f'{capture.name}:{label} missing compile command row', errors)
    compile_stdout = raw_stream(capture, compile_cmd, 'stdout', errors) if compile_cmd else b''
    compile_stderr = raw_stream(capture, compile_cmd, 'stderr', errors) if compile_cmd else b''
    if compile_cmd:
        require(compile_cmd.get('exit_code') == compile_exit,
                f'{capture.name}:{label} compile exit disagrees with command row', errors)
    source_pins = row.get('source_pins')
    require(isinstance(source_pins, list) and len(source_pins) >= 2,
            f'{capture.name}:{label} full source/Runner pins absent', errors)
    if isinstance(source_pins, list):
        for source_pin in source_pins:
            try:
                actual = pin(source_pin['path'])
                require(actual['bytes'] == source_pin.get('bytes') and actual['sha256'] == source_pin.get('sha256'),
                        f'{capture.name}:{label} compile source pin mismatch: {source_pin.get("path")}', errors)
            except (OSError, KeyError, TypeError) as exc:
                errors.append(f'{capture.name}:{label} source pin unavailable: {exc}')
    if compile_exit != 0 or (compile_cmd and compile_cmd.get('guard_stop') is not None):
        require(row.get('run_command') is None and row.get('run_exit') is None,
                f'{capture.name}:{label} compile failure must preserve no-runtime', errors)
        require(row.get('runtime_state') == 'no-runtime',
                f'{capture.name}:{label} compile failure lacks explicit no-runtime state', errors)
        return {'label': label, 'jdk': jdk, 'compile_exit': compile_exit,
                'compile_stdout_sha256': sha(compile_stdout), 'compile_stderr_sha256': sha(compile_stderr),
                'runtime': 'no-runtime', 'class_set_exact': row.get('class_set_exact')}
    require(row.get('run_command') is not None and row.get('runtime_state') == 'ran',
            f'{capture.name}:{label} successful compile did not run', errors)
    require(row.get('class_set_exact') is True,
            f'{capture.name}:{label} class set differs from same-JDK original', errors)
    require(row.get('class_paths') == expected_class_paths.get(jdk),
            f'{capture.name}:{label} class paths differ from same-JDK original', errors)
    run_cmd = command_by_label(receipt).get(row.get('run_command'))
    if run_cmd is None:
        errors.append(f'{capture.name}:{label} missing runtime command row')
        return {'label': label, 'jdk': jdk, 'compile_exit': compile_exit, 'runtime': 'missing'}
    stdout = raw_stream(capture, run_cmd, 'stdout', errors)
    stderr = raw_stream(capture, run_cmd, 'stderr', errors)
    matches = (row.get('run_exit') == oracle.get('exit_code') and
               stdout == oracle.get('stdout') and stderr == oracle.get('stderr'))
    require(row.get('run_exit') == run_cmd.get('exit_code'),
            f'{capture.name}:{label} run exit disagrees with command row', errors)
    require(row.get('runtime_comparison', {}).get('same_jdk_original') is matches,
            f'{capture.name}:{label} recorded runtime comparison disagrees with raw streams', errors)
    if not matches:
        errors.append(f'{capture.name}:{label} runtime differs from same-JDK original')
    return {'label': label, 'jdk': jdk, 'compile_exit': compile_exit,
            'compile_stdout_sha256': sha(compile_stdout), 'compile_stderr_sha256': sha(compile_stderr),
            'run_exit': row.get('run_exit'), 'runtime': 'matches-original' if matches else 'differs-from-original',
            'class_set_exact': row.get('class_set_exact'),
            'stdout_bytes': len(stdout), 'stdout_sha256': sha(stdout),
            'stderr_sha256': sha(stderr)}


def utf8_boundary(data, offset):
    return 0 <= offset <= len(data) and (offset == len(data) or offset == 0 or (data[offset] & 0xC0) != 0x80)


def physical_methods(class_path):
    """Parse the classfile method table and return name+descriptor -> Code bytes/None."""
    data = pathlib.Path(class_path).read_bytes()
    pos = 0
    def take(n):
        nonlocal pos
        value = data[pos:pos+n]
        if len(value) != n:
            raise ValueError(f'truncated classfile at {pos}, wanted {n} bytes')
        pos += n
        return value
    def u1(): return take(1)[0]
    def u2(): return int.from_bytes(take(2), 'big')
    def u4(): return int.from_bytes(take(4), 'big')
    if u4() != 0xcafebabe:
        raise ValueError('bad classfile magic')
    take(4)
    cp = [None] * u2()
    i = 1
    while i < len(cp):
        tag = u1()
        if tag == 1: cp[i] = take(u2())
        elif tag in (3, 4, 9, 10, 11, 12, 17, 18): take(4)
        elif tag in (5, 6): take(8); i += 1
        elif tag in (7, 8, 16, 19, 20): take(2)
        elif tag == 15: take(3)
        else: raise ValueError(f'unknown constant-pool tag {tag}')
        i += 1
    take(6)
    take(2 * u2())
    def skip_attributes():
        for _ in range(u2()):
            take(2)
            take(u4())
    for _ in range(u2()):
        take(6)
        skip_attributes()
    methods = {}
    for _ in range(u2()):
        take(2)
        name = cp[u2()]
        desc = cp[u2()]
        code = None
        for _ in range(u2()):
            attr_name = cp[u2()]
            payload = take(u4())
            if attr_name == b'Code':
                if code is not None:
                    raise ValueError(f'duplicate Code attributes for {name!r}{desc!r}')
                if len(payload) < 8:
                    raise ValueError('truncated Code attribute')
                code_length = int.from_bytes(payload[4:8], 'big')
                if len(payload) < 8 + code_length:
                    raise ValueError('Code byte array escapes Code attribute')
                code = payload[8:8 + code_length]
        key = name.decode('utf-8') + desc.decode('utf-8')
        if key in methods:
            raise ValueError(f'duplicate physical method {key}')
        methods[key] = code
    skip_attributes()
    if pos != len(data):
        raise ValueError(f'classfile parser ended at {pos}, file length {len(data)}')
    return methods


def cf07_decoder(path):
    """Load only the pinned CF07 pure decoder definitions; never execute its script body."""
    source = pathlib.Path(path).read_text(encoding='utf-8')
    tree = ast.parse(source, filename=str(path))
    wanted = {'need', 'insn_size', 'decode'}
    nodes = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in wanted]
    if {node.name for node in nodes} != wanted:
        raise ValueError('pinned CF07 source lacks pure need/insn_size/decode helpers')
    module = ast.Module(body=[ast.Import(names=[ast.alias(name='struct')]), *nodes], type_ignores=[])
    namespace = {}
    exec(compile(ast.fix_missing_locations(module), str(path), 'exec'), namespace)
    return namespace['decode']


def same_name_method_map(path):
    """Reuse only class_methods() from the pinned helper, never its top-level workflow."""
    source = SAME_NAME_METHOD_HELPER.read_text(encoding='utf-8')
    tree = ast.parse(source, filename=str(SAME_NAME_METHOD_HELPER))
    function = next((node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'class_methods'), None)
    if function is None:
        raise ValueError('pinned same-name helper lacks class_methods()')
    namespace = {'Path': pathlib.Path}
    isolated = ast.Module(body=[function], type_ignores=[])
    exec(compile(ast.fix_missing_locations(isolated), str(SAME_NAME_METHOD_HELPER), 'exec'), namespace)
    return namespace['class_methods'](path)


def audit_report(report_path, profile, original_pin, original_class_path, render_stdout, decode, errors):
    try:
        doc = read_json(report_path)
    except Exception as exc:
        errors.append(f'{report_path}: cannot read report: {exc}')
        return None
    try:
        render_doc = json.loads(render_stdout)
        require(doc == render_doc, f'{report_path}: saved report JSON object differs from exact render stdout JSON', errors)
    except (TypeError, json.JSONDecodeError) as exc:
        errors.append(f'{report_path}: render stdout is not a JSON object: {exc}')
    require(doc.get('outcome') == 'performed', f'{report_path}: class report was not performed', errors)
    root_class = doc.get('class', {}).get('class_bytes', {})
    digest = root_class.get('digest')
    require(isinstance(digest, str) and re.fullmatch(r'[0-9a-f]{64}', digest) is not None,
            f'{report_path}: malformed class digest', errors)
    require(doc.get('view', {}).get('snapshot') == digest,
            f'{report_path}: class digest differs from view snapshot', errors)
    require(root_class.get('length') == original_pin.get('bytes'),
            f'{report_path}: report class length differs from original class pin', errors)
    try:
        physical = physical_methods(original_class_path)
        reference_table = same_name_method_map(original_class_path)
        reference_lengths = {
            bytes(name).decode('utf-8') + bytes(desc).decode('utf-8'): code_len
            for (name, desc), code_len in reference_table.items()
        }
        expanded_lengths = {key: (None if code is None else len(code)) for key, code in physical.items()}
        require(reference_lengths == expanded_lengths,
                f'{report_path}: expanded Code parser differs from pinned same-name class_methods parser', errors)
    except (OSError, TypeError, ValueError, UnicodeError) as exc:
        errors.append(f'{report_path}: original class method table unreadable: {exc}')
        physical = {}
    try:
        require(pin(original_class_path).get('sha256') == original_pin.get('sha256'),
                f'{report_path}: physical-method source class differs from pinned Original class', errors)
    except (OSError, TypeError) as exc:
        errors.append(f'{report_path}: pinned Original class unavailable for method comparison: {exc}')
    methods = doc.get('methods')
    require(isinstance(methods, list) and len(methods) > 0,
            f'{report_path}: no physical method reports', errors)
    inventory = []
    map_rows = {}
    method_records = {}
    map_coverage = {}
    boundary_cache = {}
    for key, code in physical.items():
        try:
            boundary_cache[key] = {pc for pc, _op, _raw in decode(code)} if code is not None else set()
        except (ValueError, IndexError, struct.error) as exc:
            boundary_cache[key] = set()
            errors.append(f'{report_path}: cannot decode physical instructions for {key}: {exc}')
    projection_observations = []
    for method_row in methods if isinstance(methods, list) else []:
        try:
            item = method_row['item']
            identity = item['identity']
            member = identity.get('member', identity)
            name = bytes(member['name']).decode('utf-8')
            descriptor = bytes(member['descriptor']).decode('utf-8')
            nested = method_row['outcome']['report']
            require(nested.get('method') == name + descriptor,
                    f'{report_path}: raw method string differs from physical identity {name}{descriptor}', errors)
            binding_method = nested.get('artifact', {}).get('binding', {}).get('method')
            require(binding_method == identity,
                    f'{report_path}: artifact binding method differs from item physical identity {name}{descriptor}', errors)
            categories = nested.get('evidence', {}).get('categories', [])
            map_state = next((x.get('state', {}).get('state') for x in categories if x.get('kind') == 'source_map'), None)
            require(map_state == 'complete',
                    f'{report_path}: source map is not complete for {name}{descriptor}', errors)
            owner_digest = binding_method.get('owner', {}).get('class_bytes', {}).get('digest') if isinstance(binding_method, dict) else None
            require(owner_digest == digest,
                    f'{report_path}: method owner does not bind report class {name}{descriptor}', errors)
            body = nested.get('text', '').encode('utf-8')
            source_map = nested.get('source_map', {})
            segments = source_map.get('segments', []) if isinstance(source_map, dict) else []
            require(isinstance(segments, list), f'{report_path}: malformed map segments for {name}{descriptor}', errors)
            for segment in segments:
                start, end = segment.get('start'), segment.get('end')
                require(isinstance(start, int) and isinstance(end, int) and
                        0 <= start <= end <= len(body) and utf8_boundary(body, start) and utf8_boundary(body, end),
                        f'{report_path}: invalid/non-UTF8-boundary map span {name}{descriptor}', errors)
                origin = segment.get('origin', {})
                refs = ([origin['primary']] if isinstance(origin, dict) and origin.get('primary') else [])
                if isinstance(origin, dict):
                    refs += origin.get('derived', []) or []
                for ref in refs:
                    source_method = ref.get('method')
                    if source_method is not None:
                        require(source_method == identity,
                                f'{report_path}: map origin method differs from item identity {name}{descriptor}', errors)
                        ref_owner = source_method.get('owner', {}).get('class_bytes', {}).get('digest')
                        require(ref_owner == digest,
                                f'{report_path}: map origin owner differs from class identity {name}{descriptor}', errors)
                    bci = ref.get('bci')
                    if bci is not None:
                        try:
                            code = physical.get(name + descriptor)
                            require(code is not None,
                                    f'{report_path}: map has BCI for physical method without Code {name}{descriptor}', errors)
                            boundaries = boundary_cache.get(name + descriptor, set())
                            require(type(bci) is int and bci in boundaries,
                                    f'{report_path}: map origin BCI {bci!r} is not a physical instruction boundary in {name}{descriptor}', errors)
                            if type(bci) is int:
                                map_coverage.setdefault(name + descriptor, set()).add(bci)
                        except (ValueError, IndexError, struct.error) as exc:
                            errors.append(f'{report_path}: cannot decode physical instructions for {name}{descriptor}: {exc}')
            inventory.append(name + descriptor)
            map_rows[name + descriptor] = segments
            record = {
                'identity': identity,
                'item_body': item.get('body'),
                'render_body': nested.get('text'),
                'source_map': source_map,
            }
            record_bytes = json.dumps(record, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
            method_records[name + descriptor] = {'bytes': len(record_bytes), 'sha256': sha(record_bytes)}
            markers = method_row.get('markers', [])
            projection_observations.append({'method': name + descriptor, 'content': nested.get('content'),
                                            'outcome': nested.get('outcome'), 'markers': markers,
                                            'ordinary_generic_source_unproved': any('ordinary_generic_source_unproved' in str(x) for x in markers)})
        except (KeyError, TypeError, ValueError, UnicodeError) as exc:
            errors.append(f'{report_path}: malformed method identity/map row: {exc}')
    require(len(inventory) == len(set(inventory)), f'{report_path}: duplicate physical method identity', errors)
    require(set(inventory) == set(physical),
            f'{report_path}: report inventory differs from physical class methods; missing={sorted(set(physical)-set(inventory))}, extra={sorted(set(inventory)-set(physical))}', errors)
    for key, code in physical.items():
        boundaries = boundary_cache.get(key, set())
        observed = map_coverage.get(key, set())
        map_coverage[key] = {'instruction_count': len(boundaries), 'mapped_instruction_bcis': sorted(observed),
                             'coverage_missing': sorted(boundaries - observed),
                             'coverage_extra': sorted(observed - boundaries)}
    source_pin = profile.get('source_pin')
    if isinstance(source_pin, dict):
        try:
            source = pathlib.Path(source_pin['path']).read_bytes()
            require(len(source) == source_pin.get('bytes') and sha(source) == source_pin.get('sha256'),
                    f'{report_path}: saved source pin mismatch', errors)
            require(source == doc.get('text', '').encode('utf-8'),
                    f'{report_path}: saved full-class source differs from report text', errors)
        except (OSError, KeyError, TypeError) as exc:
            errors.append(f'{report_path}: saved source unavailable: {exc}')
    else:
        errors.append(f'{report_path}: missing saved full-class source pin')
    return {'label': profile.get('label'), 'jdk': profile.get('jdk'), 'mode': profile.get('mode'),
            'report': pin(report_path), 'source': source_pin, 'class_digest': digest,
            'class_digest_algorithm': 'validated against snapshot; input bytes checked by SHA-256 pin/length',
            'class': profile.get('class'), 'method_count': len(inventory), 'method_identities': sorted(inventory),
            'projection_observations': projection_observations,
            'physical_method_code': {k: (None if v is None else len(v)) for k, v in sorted(physical.items())},
            'method_records': method_records,
            'map_instruction_coverage': map_coverage,
            'map_segment_counts': {k: len(v) for k, v in sorted(map_rows.items())},
            'maps': {k: {'segments': len(v), 'sha256': sha(json.dumps(v, sort_keys=True, separators=(',', ':')).encode('utf-8'))}
                     for k, v in sorted(map_rows.items())}}


def exact_binding(receipt, dotted_path):
    value = receipt
    for part in dotted_path.split('.'):
        if not isinstance(value, dict) or part not in value:
            return None
        value = value[part]
    return value


def jdk_tool_record(jdk_manifest, jdk, tool):
    leg = next((x for x in jdk_manifest.get('legs', []) if x.get('leg') == jdk), None)
    return (leg or {}).get('jdk_tools', {}).get(tool)


def check_tool(argv0, jdk_manifest, jdk, tool, label, errors):
    expected = jdk_tool_record(jdk_manifest, jdk, tool)
    if not isinstance(expected, dict):
        errors.append(f'{label}: pinned JDK manifest lacks {jdk}/{tool}')
        return
    try:
        actual = pin(argv0)
        require(actual['bytes'] == expected.get('bytes') and actual['sha256'] == expected.get('sha256'),
                f'{label}: argv executable differs from pinned {jdk}/{tool}', errors)
        require(pathlib.Path(argv0).resolve() == pathlib.Path(expected['path']).resolve(),
                f'{label}: argv executable path does not resolve to pinned {jdk}/{tool}', errors)
    except (OSError, KeyError, TypeError) as exc:
        errors.append(f'{label}: executable pin unavailable: {exc}')


def validate_command_bindings(row, receipt, capture, mode, jdk_manifest, errors):
    """Bind javac/java argv, source files, class output tree, and recorded class pins."""
    label = row.get('label', '<unnamed>')
    commands = command_by_label(receipt)
    compile_row = commands.get(row.get('compile_command'))
    if compile_row is None:
        errors.append(f'{capture.name}:{label}: compile command absent during argv binding')
        return None
    argv = compile_row.get('argv', [])
    jdk = label.split('-', 1)[0]
    if not argv:
        errors.append(f'{capture.name}:{label}: empty javac argv')
        return None
    check_tool(argv[0], jdk_manifest, jdk, 'javac', label + ' compile', errors)
    require(compile_row.get('cwd') == '/Users/lordcasser/workspace/projects/jarde',
            f'{capture.name}:{label}: compile cwd differs from pinned workspace', errors)
    require('-proc:none' in argv, f'{capture.name}:{label}: annotation processing is not disabled', errors)
    debug_arg = '-g' if mode == 'debug' else '-g:none'
    opposite_debug_arg = '-g:none' if mode == 'debug' else '-g'
    require(debug_arg in argv and opposite_debug_arg not in argv,
            f'{capture.name}:{label}: javac debug arguments differ from capture mode', errors)
    if jdk == 'javac8':
        require(argv[1:5] == ['-source', '8', '-target', '8'],
                f'{capture.name}:{label}: Java 8 compile release arguments differ', errors)
    else:
        require(argv[1:3] == ['--release', '8'],
                f'{capture.name}:{label}: Java 23 compile release arguments differ', errors)
    def option_value(option):
        try: return argv[argv.index(option) + 1]
        except (ValueError, IndexError): return None
    output_dir = pathlib.Path(option_value('-d') or '')
    cp_dir = pathlib.Path(option_value('-classpath') or '')
    source_dir = pathlib.Path(option_value('-sourcepath') or '')
    for name, directory in (('-classpath', cp_dir), ('-sourcepath', source_dir)):
        require(option_value(name) is not None and directory.is_dir() and not any(directory.iterdir()),
                f'{capture.name}:{label}: {name} directory is missing or nonempty', errors)
    require(output_dir.is_dir(), f'{capture.name}:{label}: javac output directory missing', errors)
    expected_sources = sorted(str(pathlib.Path(x['path']).resolve()) for x in row.get('source_pins', []))
    actual_sources = sorted(str(pathlib.Path(x).resolve()) for x in argv if x.endswith('.java'))
    require(actual_sources == expected_sources,
            f'{capture.name}:{label}: javac source argv differs from pinned complete source set', errors)
    for source_pin in row.get('source_pins', []):
        try:
            actual = pin(source_pin['path'])
            require(actual['bytes'] == source_pin.get('bytes') and actual['sha256'] == source_pin.get('sha256'),
                    f'{capture.name}:{label}: source argv pin mismatch {source_pin.get("path")}', errors)
        except (OSError, KeyError, TypeError) as exc:
            errors.append(f'{capture.name}:{label}: source argv file unavailable: {exc}')
    try:
        actual_classes = sorted(str(p.relative_to(output_dir)).replace(os.sep, '/') for p in output_dir.rglob('*.class'))
    except OSError as exc:
        actual_classes = []
        errors.append(f'{capture.name}:{label}: cannot enumerate compiler class output: {exc}')
    require(actual_classes == sorted(row.get('class_paths') or []),
            f'{capture.name}:{label}: on-disk compiler class set differs from receipt', errors)
    for class_row in row.get('classes', []):
        try:
            cp = pathlib.Path(class_row['path'])
            require(cp.resolve().is_relative_to(output_dir.resolve()),
                    f'{capture.name}:{label}: class file escapes javac -d output: {cp}', errors)
            actual = pin(cp)
            require(actual['bytes'] == class_row.get('bytes') and actual['sha256'] == class_row.get('sha256'),
                    f'{capture.name}:{label}: class file pin mismatch: {cp}', errors)
        except (OSError, KeyError, TypeError, ValueError) as exc:
            errors.append(f'{capture.name}:{label}: class file unavailable/malformed: {exc}')
    run_label = row.get('run_command')
    if row.get('compile_exit') != 0:
        require(run_label is None and row.get('run_exit') is None and row.get('runtime_state') == 'no-runtime',
                f'{capture.name}:{label}: failed javac command must retain no-runtime', errors)
    else:
        run_row = commands.get(run_label)
        if run_row is None:
            errors.append(f'{capture.name}:{label}: successful compile lacks Java command')
        else:
            run_argv = run_row.get('argv', [])
            if run_argv:
                check_tool(run_argv[0], jdk_manifest, jdk, 'java', label + ' run', errors)
            require(run_row.get('cwd') == '/Users/lordcasser/workspace/projects/jarde',
                    f'{capture.name}:{label}: run cwd differs from pinned workspace', errors)
            require(run_argv[1:] == ['-Xverify:all', '-cp', str(output_dir), 'cf11.Runner'],
                    f'{capture.name}:{label}: Java runtime argv is not bound to this exact output directory/Runner', errors)
    return {'output_dir': str(output_dir.resolve()), 'class_paths': actual_classes,
            'javac': argv[0], 'runtime_command': run_label}


def audit_build_receipt(capture_receipt, capture, errors):
    config = capture_receipt.get('collector_config', {})
    ref = capture_receipt.get('build_receipt', {})
    try:
        path = pathlib.Path(ref['path'])
        live = pin(path)
        require(live['bytes'] == ref.get('bytes') and live['sha256'] == ref.get('sha256'),
                f'{capture.name}: build receipt live pin mismatch', errors)
        build = read_json(path)
        status_key = config.get('receipt_status_key', 'status')
        accepted = config.get('receipt_accepted_value')
        require(accepted == 'commands_passed_pending_independent_acceptance' and build.get(status_key) == accepted,
                f'{capture.name}: focused receipt status is not the exact accepted status', errors)
        cli_path = pathlib.Path(capture_receipt['cli']['path']).resolve()
        binding = exact_binding(build, config.get('receipt_cli_object', 'cli'))
        require(isinstance(binding, dict) and pathlib.Path(binding.get('path', '')).resolve() == cli_path and
                binding.get('bytes') == capture_receipt['cli'].get('bytes') and
                binding.get('sha256') == capture_receipt['cli'].get('sha256'),
                f'{capture.name}: build receipt CLI binding differs from captured frozen CLI', errors)
        return {'pin': live, 'status': build.get(status_key), 'cli_binding': binding}
    except (OSError, KeyError, TypeError, ValueError) as exc:
        errors.append(f'{capture.name}: build receipt unreadable or malformed: {exc}')
        return None


def audit_final_clean(path, errors):
    clean_path = pathlib.Path(path).resolve()
    try:
        receipt = read_json(clean_path)
    except Exception as exc:
        errors.append(f'final clean receipt unavailable: {exc}')
        return None
    command = receipt.get('command', {})
    require(receipt.get('schema') == 'jarde-java-baseline-final-clean-v1' and receipt.get('status') == 'passed',
            'final clean receipt schema/status mismatch', errors)
    require(command.get('argv') == ['cargo', 'clean'] and command.get('exit_code') == 0,
            'final clean command was not exact cargo clean exit 0', errors)
    for stream in ('stdout', 'stderr'):
        meta = command.get('streams', {}).get(stream, {})
        try:
            data = pathlib.Path(meta['path']).read_bytes()
            require(len(data) == meta.get('bytes') and sha(data) == meta.get('sha256'),
                    f'final clean {stream} raw pin mismatch', errors)
        except (OSError, KeyError, TypeError) as exc:
            errors.append(f'final clean {stream} raw unavailable: {exc}')
    require(receipt.get('target_absent_before') is True and receipt.get('target_absent_after') is True,
            'final clean receipt does not prove target absent before and after', errors)
    workspace = pathlib.Path('/Users/lordcasser/workspace/projects/jarde')
    require(not (workspace / 'target').exists(), 'shared workspace target currently exists after final clean', errors)
    return {'receipt': pin(clean_path), 'status': receipt.get('status'), 'command': command,
            'target_absent_before': receipt.get('target_absent_before'),
            'target_absent_after': receipt.get('target_absent_after'), 'live_target_absent': not (workspace / 'target').exists()}


def audit_previous_capture(capture, mode, errors):
    """Read and pin the already-accepted same-mode 44-row run as an exact prefix oracle."""
    capture = pathlib.Path(capture).resolve()
    receipt_path = capture / 'execution.json'
    expected_path, expected_sha = PREVIOUS_CAPTURE_RECEIPTS[mode]
    try:
        actual_receipt_pin = pin(receipt_path)
        require(str(receipt_path) == str(pathlib.Path(expected_path).resolve()) and
                actual_receipt_pin['sha256'] == expected_sha,
                f'{capture.name}: previous 44-row receipt path/SHA differs from accepted reference', errors)
        receipt = read_json(receipt_path)
    except (OSError, ValueError) as exc:
        errors.append(f'{capture.name}: previous 44-row capture unreadable: {exc}')
        return None
    require(receipt.get('schema') == 'cf11-target-full-source-capture-v2' and receipt.get('status') == 'observed',
            f'{capture.name}: previous capture schema/status mismatch', errors)
    require(receipt.get('javac_debug_info') == {'mode': mode, 'argument': '-g' if mode == 'debug' else '-g:none'} and
            receipt.get('collector_config', {}).get('javac_debug') == mode,
            f'{capture.name}: previous capture javac mode differs from current mode', errors)
    rows = {row.get('label'): row for row in receipt.get('original_compile_rows', [])}
    require(set(rows) == {jdk + '-original' for jdk in JDKS},
            f'{capture.name}: previous capture lacks exact per-JDK original rows', errors)
    commands = command_by_label(receipt)
    outputs = {}
    summaries = []
    for jdk in JDKS:
        row = rows.get(jdk + '-original')
        if row is None:
            continue
        require(row.get('compile_exit') == 0 and row.get('run_exit') == 0 and row.get('runtime_state') == 'ran',
                f'{capture.name}:{jdk}: previous 44-row original did not compile/run zero', errors)
        command = commands.get(row.get('run_command'))
        if command is None:
            errors.append(f'{capture.name}:{jdk}: previous original run command missing')
            continue
        require(command.get('state') == 'observed' and command.get('guard_stop') is None and command.get('exit_code') == 0,
                f'{capture.name}:{jdk}: previous original run command is incomplete/stopped', errors)
        argv = command.get('argv', [])
        require(argv[1:] == ['-Xverify:all', '-cp', str(pathlib.Path(row.get('classes', [{}])[0].get('path','')).parent.parent), 'cf11.Runner']
                if row.get('classes') else False,
                f'{capture.name}:{jdk}: previous Java argv is not bound to its recorded classes', errors)
        stdout = raw_stream(capture, command, 'stdout', errors)
        stderr = raw_stream(capture, command, 'stderr', errors)
        lines = stdout.splitlines(keepends=True)
        require(len(lines) == EXPECTED_PREVIOUS_RUNNER_ROWS,
                f'{capture.name}:{jdk}: previous original output is not exactly 44 rows', errors)
        outputs[jdk] = {'exit_code': row.get('run_exit'), 'stdout': stdout, 'stderr': stderr}
        summaries.append({'jdk': jdk, 'rows': len(lines), 'stdout_sha256': sha(stdout),
                          'receipt_run': row.get('run_command')})
    return {'capture': str(capture), 'receipt': actual_receipt_pin if 'actual_receipt_pin' in locals() else None,
            'mode': mode, 'outputs': outputs, 'original_rows': summaries}


def audit_capture(capture, mode, legacy_pins, previous, errors):
    capture = pathlib.Path(capture).resolve()
    receipt_path = capture / 'execution.json'
    receipt = read_json(receipt_path)
    expected_current_path, expected_current_sha = CURRENT_CAPTURE_RECEIPTS[mode]
    actual_current_pin = pin(receipt_path)
    require(str(receipt_path) == str(pathlib.Path(expected_current_path).resolve()) and
            actual_current_pin['sha256'] == expected_current_sha,
            f'{capture.name}: current 45-row receipt path/SHA differs from observed reference', errors)
    require(pathlib.Path(receipt.get('inputs_manifest_path', '')).resolve() == (PREP_ROOT / 'inputs/manifest.json').resolve() and
            pin(receipt.get('inputs_manifest_path'))['sha256'] == PREP_MANIFEST_SHA256,
            f'{capture.name}: input manifest is not the pinned v4 45-row prep', errors)
    require(pathlib.Path(receipt.get('collector_config', {}).get('inputs_dir', '')).resolve() == (PREP_ROOT / 'inputs').resolve(),
            f'{capture.name}: collector input directory is not v4 prep', errors)
    require(previous is not None and previous.get('mode') == mode and
            set(previous.get('outputs', {})) == set(JDKS),
            f'{capture.name}: same-mode 44-row prefix oracle unavailable', errors)
    try:
        helper_pin = pin(SAME_NAME_METHOD_HELPER)
        require(helper_pin['sha256'] == SAME_NAME_METHOD_HELPER_SHA256,
                f'{capture.name}: pinned same-name class_methods helper SHA mismatch', errors)
    except OSError as exc:
        errors.append(f'{capture.name}: same-name class_methods helper unavailable: {exc}')
    require(receipt.get('schema') == 'cf11-target-full-source-capture-v2',
            f'{capture.name}: unexpected receipt schema', errors)
    require(receipt.get('status') == 'observed', f'{capture.name}: capture is not observed/complete', errors)
    require(receipt.get('javac_debug_info') == {'mode': mode, 'argument': '-g' if mode == 'debug' else '-g:none'},
            f'{capture.name}: compiler debug mode mismatch', errors)
    require(receipt.get('collector_config', {}).get('javac_debug') == mode,
            f'{capture.name}: collector config mode mismatch', errors)
    require(receipt.get('resource_guard') == {'minimum_free_bytes': MIN_FREE, 'maximum_target_bytes': MAX_TARGET,
                                                'poll_seconds': 1, 'peak_target_sampled': True},
            f'{capture.name}: resource guard configuration mismatch', errors)
    target_state = receipt.get('workspace_target', {})
    require(target_state.get('absent_before') is True and target_state.get('absent_after') is True and
            target_state.get('unchanged_absent') is True,
            f'{capture.name}: workspace target absence/clean-state proof missing', errors)
    require(receipt.get('source_tool_inputs_unchanged') is True,
            f'{capture.name}: source/tool inputs changed', errors)
    live_pins(receipt, capture, errors)
    config = receipt.get('collector_config', {})
    expected_collector = (PREP_ROOT / 'collect_controls.py').resolve()
    collector_pin = next((x for x in receipt.get('source_tool_pins_before', [])
                          if pathlib.Path(x.get('path', '')).resolve() == expected_collector), None)
    require(collector_pin is not None and collector_pin.get('bytes') == 19545 and
            collector_pin.get('sha256') == PREP_COLLECTOR_SHA256,
            f'{capture.name}: source/tool pins do not bind exact v4 collector', errors)
    try:
        manifest_path = pathlib.Path(config['jdk_manifest'])
        manifest_live = pin(manifest_path)
        require(manifest_live['sha256'] == config.get('jdk_manifest_sha256'),
                f'{capture.name}: JDK manifest live SHA mismatch', errors)
        jdk_manifest = read_json(manifest_path)
        decode_source = pathlib.Path(config['classfile_parser'])
        decode_pin = pin(decode_source)
        require(decode_pin['sha256'] == config.get('classfile_parser_sha256'),
                f'{capture.name}: CF07 parser source differs from its receipt pin', errors)
        decode = cf07_decoder(decode_source)
    except (OSError, KeyError, TypeError, ValueError, SyntaxError) as exc:
        errors.append(f'{capture.name}: cannot load pinned JDK manifest/CF07 decoder: {exc}')
        jdk_manifest, decode = {}, lambda _code: []
    cli = receipt.get('cli', {})
    try:
        actual_cli = pin(cli['path'])
        require(actual_cli['bytes'] == cli.get('bytes') and actual_cli['sha256'] == cli.get('sha256'),
                f'{capture.name}: CLI live pin mismatch', errors)
        require(pathlib.Path(cli['path']).stat().st_mode & 0o777 == 0o555 and receipt.get('cli_mode') == '0o555',
                f'{capture.name}: CLI mode is not 0555', errors)
    except (OSError, KeyError, TypeError) as exc:
        errors.append(f'{capture.name}: CLI pin unavailable: {exc}')
    build_receipt = receipt.get('build_receipt', {})
    try:
        actual_receipt = pin(build_receipt['path'])
        require(actual_receipt['bytes'] == build_receipt.get('bytes') and actual_receipt['sha256'] == build_receipt.get('sha256'),
                f'{capture.name}: CLI build receipt pin mismatch', errors)
        binding = receipt.get('build_receipt_cli_binding', {})
        require(binding.get('path') == cli.get('path') and binding.get('bytes') == cli.get('bytes') and
                binding.get('sha256') == cli.get('sha256'),
                f'{capture.name}: build receipt does not bind captured CLI', errors)
    except (OSError, KeyError, TypeError) as exc:
        errors.append(f'{capture.name}: build receipt unavailable: {exc}')
    independent_build = audit_build_receipt(receipt, capture, errors)
    manifest = read_json(receipt['inputs_manifest_path'])
    require(manifest == receipt.get('input_entries'), f'{capture.name}: manifest differs from receipt', errors)
    runner_entry = manifest.get('runner', {})
    target_entries = manifest.get('target_classes', [])
    require(runner_entry.get('sha256') == PREP_RUNNER_SHA256 and runner_entry.get('bytes') == 12601,
            f'{capture.name}: Runner source differs from v4 appended-row source pin', errors)
    require(len(target_entries) == 1 and target_entries[0].get('sha256') == PREP_TARGET_SHA256 and
            target_entries[0].get('bytes') == 7402,
            f'{capture.name}: full target class source differs from v4 source pin', errors)
    entries = target_entries + [runner_entry]
    input_summary = []
    for entry in entries:
        try:
            source_path = pathlib.Path(receipt['collector_config']['inputs_dir']) / entry['source']
            copied_path = capture / 'inputs' / pathlib.Path(entry['source']).name
            for path in (source_path, copied_path):
                actual = pin(path)
                require(actual['bytes'] == entry.get('bytes') and actual['sha256'] == entry.get('sha256'),
                        f'{capture.name}: source manifest pin mismatch: {path}', errors)
            input_summary.append({'source': entry['source'], 'bytes': entry['bytes'], 'sha256': entry['sha256']})
        except (OSError, KeyError, TypeError) as exc:
            errors.append(f'{capture.name}: input missing/malformed: {exc}')
    target_classes = [x.get('class') for x in manifest.get('target_classes', [])]
    required_paths = sorted([x.replace('.', '/') + '.class' for x in target_classes] + ['cf11/Runner.class'])
    commands = receipt.get('commands', [])
    require(bool(commands), f'{capture.name}: no command rows', errors)
    raw_count = 0
    raw_refs = []
    for row in commands:
        require(row.get('state') == 'observed', f'{capture.name}: command {row.get("index")} not observed', errors)
        require(row.get('guard_stop') is None, f'{capture.name}: command {row.get("label")} was stopped', errors)
        peak = row.get('peak_target_bytes')
        free = row.get('free_bytes_after')
        require(isinstance(peak, int) and peak <= MAX_TARGET,
                f'{capture.name}: target cap exceeded/missing at command {row.get("label")}', errors)
        require(isinstance(free, int) and free >= MIN_FREE,
                f'{capture.name}: free-space floor violated/missing at command {row.get("label")}', errors)
        for stream in ('stdout', 'stderr'):
            data = raw_stream(capture, row, stream, errors)
            raw_refs.append({'index': row.get('index'), 'label': row.get('label'), 'stream': stream,
                             'path': row.get('streams', {}).get(stream, {}).get('path'),
                             'bytes': len(data), 'sha256': sha(data)})
            raw_count += 1
    require(receipt.get('actual_command_count') == len(commands),
            f'{capture.name}: command count does not match receipt rows', errors)
    require(raw_count == 2 * len(commands), f'{capture.name}: incomplete raw stream inventory', errors)
    originals = receipt.get('original_compile_rows', [])
    require({row.get('label') for row in originals} == {jdk + '-original' for jdk in JDKS},
            f'{capture.name}: missing per-JDK original compile rows', errors)
    expected_class_paths = {}
    oracles = {}
    previous_44_matches = {}
    handled_row_matches = {}
    commands_map = command_by_label(receipt)
    for row in originals:
        jdk = row['label'].split('-', 1)[0]
        validate_command_bindings(row, receipt, capture, mode, jdk_manifest, errors)
        expected_class_paths[jdk] = row.get('class_paths')
        require(row.get('compile_exit') == 0 and row.get('run_exit') == 0 and
                row.get('runtime_state') == 'ran' and row.get('class_set_exact') is True,
                f'{capture.name}:{row.get("label")} original must compile/run zero with exact class set', errors)
        require(row.get('required_manifest_classes_present') is True,
                f'{capture.name}:{row.get("label")} missing manifest class/Runner', errors)
        require(row.get('class_paths') == row.get('class_set_expected_from_original'),
                f'{capture.name}:{row.get("label")} original class-set baseline is inconsistent', errors)
        require(all(path in (row.get('class_paths') or []) for path in required_paths),
                f'{capture.name}:{row.get("label")} original class set lacks required classes', errors)
        run_cmd = commands_map.get(row.get('run_command'))
        if run_cmd:
            stdout = raw_stream(capture, run_cmd, 'stdout', errors)
            stderr = raw_stream(capture, run_cmd, 'stderr', errors)
            oracles[jdk] = {'exit_code': row.get('run_exit'), 'stdout': stdout, 'stderr': stderr}
            output_lines = stdout.splitlines(keepends=True)
            require(len(output_lines) >= EXPECTED_OLD_ORACLE_ROWS,
                    f'{capture.name}:{row.get("label")} output shorter than frozen 17-row oracle', errors)
            legacy_key = '2' if jdk == 'javac8' else '5'
            old_ref = legacy_pins.get('old_runner_stdout', {}).get(legacy_key)
            if old_ref:
                old_bytes = pathlib.Path(old_ref['path']).read_bytes()
                require(len(old_bytes) == old_ref.get('bytes') and sha(old_bytes) == old_ref.get('sha256'),
                        f'{capture.name}: legacy oracle pin mismatch for {jdk}', errors)
                old_lines = old_bytes.splitlines(keepends=True)
                require(len(old_lines) == EXPECTED_OLD_ORACLE_ROWS and
                        b''.join(output_lines[:EXPECTED_OLD_ORACLE_ROWS]) == old_bytes,
                        f'{capture.name}:{row.get("label")} first 17 rows differ from frozen oracle', errors)
            else:
                errors.append(f'{capture.name}: legacy 17-row oracle pin absent for {jdk}')
            previous_output = (previous or {}).get('outputs', {}).get(jdk, {}).get('stdout')
            require(len(output_lines) == EXPECTED_CURRENT_RUNNER_ROWS,
                    f'{capture.name}:{row.get("label")} output is not exactly 45 rows', errors)
            previous_44_matches[jdk] = (previous_output is not None and
                    len(previous_output.splitlines(keepends=True)) == EXPECTED_PREVIOUS_RUNNER_ROWS and
                    b''.join(output_lines[:EXPECTED_PREVIOUS_RUNNER_ROWS]) == previous_output)
            require(previous_44_matches[jdk],
                    f'{capture.name}:{row.get("label")} first 44 rows differ from same-mode/same-JDK old raw oracle', errors)
            handled_row_matches[jdk] = bool(output_lines) and output_lines[-1] == EXPECTED_HANDLED_ROW
            require(handled_row_matches[jdk],
                    f'{capture.name}:{row.get("label")} mutable-output handled row has wrong value/effects/normal completion', errors)
            require((row.get('runtime_comparison') or {}).get('same_jdk_original') is True or
                    (row.get('compile_exit') == 0 and row.get('run_exit') == 0 and row.get('label', '').endswith('-original')),
                    f'{capture.name}:{row.get("label")} original did not record successful run', errors)
    provider_rows = []
    for key in ('jadx_compile_rows', 'jarde_compile_rows'):
        rows = receipt.get(key, [])
        for row in rows:
            validate_command_bindings(row, receipt, capture, mode, jdk_manifest, errors)
            jdk = row.get('label', '').split('-', 1)[0]
            oracle = oracles.get(jdk)
            if oracle is None:
                errors.append(f'{capture.name}:{row.get("label")} lacks same-JDK original oracle')
                continue
            provider_rows.append(check_runtime_row(row, receipt, capture, oracle, expected_class_paths, errors))
    # Every profile uses each JDK's own original class input. The tool process itself runs under JDK23.
    jadx = receipt.get('jadx', {}).get('profiles', {})
    for jdk in JDKS:
        for profile_name in JADX_PROFILES:
            key = jdk + '-' + profile_name
            profile = jadx.get(key)
            require(isinstance(profile, dict), f'{capture.name}: missing JADX profile {key}', errors)
            if not isinstance(profile, dict):
                continue
            require(profile.get('input_class_jdk') == jdk and profile.get('compile_run_jdk') == jdk,
                    f'{capture.name}: JADX JDK binding mismatch for {key}', errors)
            require(profile.get('exact_target_sources') is True,
                    f'{capture.name}: JADX source set is not exactly the target set for {key}', errors)
            for source_pin in profile.get('sources', []):
                try:
                    actual_source = pin(source_pin['path'])
                    require(actual_source['bytes'] == source_pin.get('bytes') and actual_source['sha256'] == source_pin.get('sha256'),
                            f'{capture.name}: JADX source pin mismatch for {key}', errors)
                except (OSError, KeyError, TypeError) as exc:
                    errors.append(f'{capture.name}: JADX source unavailable for {key}: {exc}')
            require(profile.get('execution_jdk') == 'javac23',
                    f'{capture.name}: JADX execution runtime is not pinned JDK23 for {key}', errors)
            command = commands_map.get(profile.get('command'))
            require(command is not None, f'{capture.name}: JADX command missing for {key}', errors)
            if command:
                argv = command.get('argv', [])
                jadx_path = config.get('jadx')
                require(bool(argv) and pathlib.Path(argv[0]).resolve() == pathlib.Path(jadx_path or '').resolve(),
                        f'{capture.name}: JADX command executable differs from pinned collector tool for {key}', errors)
                try:
                    jadx_tool = pin(jadx_path)
                    require(jadx_tool['sha256'] == config.get('jadx_sha256'),
                            f'{capture.name}: live JADX tool differs from collector pin for {key}', errors)
                except (OSError, TypeError) as exc:
                    errors.append(f'{capture.name}: JADX tool unavailable for {key}: {exc}')
                require(('--rename-flags' not in argv) if profile_name == 'default' else
                        ('--rename-flags' in argv and argv[argv.index('--rename-flags') + 1] == 'none'),
                        f'{capture.name}: JADX profile argv differs for {key}', errors)
            jar_pin = profile.get('input_jar')
            if jar_pin:
                try:
                    jar_path = pathlib.Path(jar_pin['path'])
                    require(pin(jar_path)['sha256'] == jar_pin.get('sha256') and pin(jar_path)['bytes'] == jar_pin.get('bytes'),
                            f'{capture.name}: JADX input jar pin mismatch for {key}', errors)
                    with zipfile.ZipFile(jar_path) as archive:
                        expected = sorted(path.replace('.','/') + '.class' for path in target_classes)
                        require(sorted(archive.namelist()) == expected,
                                f'{capture.name}: JADX jar entries differ for {key}', errors)
                        for class_name in expected:
                            original_row = next((r for r in originals if r.get('label') == jdk + '-original'), None)
                            original_class = next((c for c in (original_row or {}).get('classes', []) if c['path'].endswith('/' + class_name)), None)
                            if original_class:
                                require(archive.read(class_name) == pathlib.Path(original_class['path']).read_bytes(),
                                        f'{capture.name}: JADX jar bytes differ from same-JDK original class {class_name}', errors)
                except (OSError, KeyError, TypeError, zipfile.BadZipFile) as exc:
                    errors.append(f'{capture.name}: JADX input jar unreadable for {key}: {exc}')
    # Jarde render commands must use exact Original class files; reports/maps bind back to each method.
    jarde_profiles = receipt.get('jarde_profiles', [])
    wanted_cells = {(jdk, mode_name, cls) for jdk in JDKS for mode_name in JARDE_MODES for cls in target_classes}
    seen_cells = set()
    report_summaries = []
    report_maps = {}
    report_cells = {}
    for profile in jarde_profiles:
        jdk, mode_name, cls = profile.get('jdk'), profile.get('mode'), profile.get('class')
        cell = (jdk, mode_name, cls)
        require(cell not in seen_cells, f'{capture.name}: duplicate Jarde report cell {cell}', errors)
        seen_cells.add(cell)
        command = commands_map.get(profile.get('render_command'))
        require(command is not None, f'{capture.name}: Jarde render command missing for {cell}', errors)
        if command:
            argv = command.get('argv', [])
            require(bool(argv) and pathlib.Path(argv[0]).resolve() == pathlib.Path(cli.get('path', '')).resolve(),
                    f'{capture.name}: Jarde render executable differs from captured CLI for {cell}', errors)
            require('--input' in argv and '--class' in argv and argv[argv.index('--class') + 1] == cls,
                    f'{capture.name}: Jarde class-source argv mismatch for {cell}', errors)
            original_row = next((r for r in originals if r.get('label') == jdk + '-original'), None)
            original_class = next((c for c in (original_row or {}).get('classes', []) if c['path'].endswith('/' + cls.replace('.','/') + '.class')), None)
            if original_class:
                input_path = pathlib.Path(argv[argv.index('--input') + 1])
                require(pin(input_path)['sha256'] == original_class['sha256'] and
                        pin(input_path)['bytes'] == original_class['bytes'],
                        f'{capture.name}: Jarde did not consume exact same-JDK original class for {cell}', errors)
            if mode_name == 'default':
                require('--evidence' not in argv, f'{capture.name}: default Jarde evidence flag unexpected', errors)
            elif mode_name == 'all':
                require('--evidence' in argv and argv[argv.index('--evidence') + 1] == 'all',
                        f'{capture.name}: all Jarde evidence flag missing', errors)
            require('--policy' in argv and argv[argv.index('--policy') + 1] == 'single-class' and
                    '--release' in argv and argv[argv.index('--release') + 1] == '8' and
                    '--format' in argv and argv[argv.index('--format') + 1] == 'json',
                    f'{capture.name}: Jarde render argv policy/release/format differs for {cell}', errors)
        if profile.get('render_exit') == 0 and profile.get('report_pin'):
            report = pathlib.Path(profile['report_pin']['path'])
            try:
                actual_report = pin(report)
                require(actual_report['sha256'] == profile['report_pin']['sha256'] and actual_report['bytes'] == profile['report_pin']['bytes'],
                        f'{capture.name}: Jarde report pin mismatch for {cell}', errors)
                original_row = next((r for r in originals if r.get('label') == jdk + '-original'), None)
                original_class = next((c for c in (original_row or {}).get('classes', []) if c['path'].endswith('/' + cls.replace('.','/') + '.class')), {})
                render_stdout = raw_stream(capture, command, 'stdout', errors) if command else b''
                if command:
                    require(command.get('exit_code') == profile.get('render_exit') == 0,
                            f'{capture.name}: Jarde render command exit mismatch for {cell}', errors)
                    require(sha(render_stdout) == profile.get('render_stdout_sha256'),
                            f'{capture.name}: Jarde render raw stdout SHA differs from profile for {cell}', errors)
                summary = audit_report(report, profile, original_class, original_class.get('path'), render_stdout, decode, errors)
                if summary:
                    report_summaries.append(summary)
                    report_maps[cell] = summary['maps']
                    report_cells[cell] = summary
            except (OSError, KeyError, TypeError) as exc:
                errors.append(f'{capture.name}: Jarde report unavailable for {cell}: {exc}')
        elif profile.get('render_exit') != 0:
            # A failed render remains a factual rejected lane; its argv/raws remain audited above.
            profile['observed_render_failure'] = True
    require(seen_cells == wanted_cells, f'{capture.name}: Jarde report cells differ from required JDK × mode × target matrix', errors)
    # Compare full text, method inventories, and complete maps across evidence modes per JDK/class.
    inventories = [set(x['method_identities']) for x in report_summaries]
    if inventories:
        require(all(x == inventories[0] for x in inventories),
                f'{capture.name}: Jarde report method inventories differ across JDK/evidence profiles', errors)
    for jdk in JDKS:
        for cls in target_classes:
            default = report_cells.get((jdk, 'default', cls))
            all_mode = report_cells.get((jdk, 'all', cls))
            if default and all_mode:
                require(default['source']['sha256'] == all_mode['source']['sha256'],
                        f'{capture.name}: default/all full class text differs for {jdk}/{cls}', errors)
                require(default['maps'] == all_mode['maps'],
                        f'{capture.name}: default/all method source maps differ for {jdk}/{cls}', errors)
                require(default['method_records'] == all_mode['method_records'],
                        f'{capture.name}: default/all per-method body/identity/map records differ for {jdk}/{cls}', errors)
    return {'capture': str(capture), 'receipt': pin(receipt_path), 'status': receipt.get('status'),
            'mode': mode, 'command_count': len(commands), 'raw_stream_count': raw_count,
            'original_rows': [{'jdk': x['label'].split('-', 1)[0], 'compile_exit': x.get('compile_exit'),
                               'run_exit': x.get('run_exit'), 'stdout_sha256': sha(oracles[x['label'].split('-',1)[0]]['stdout']) if x['label'].split('-',1)[0] in oracles else None,
                               'output_row_count': len(oracles[x['label'].split('-',1)[0]]['stdout'].splitlines()) if x['label'].split('-',1)[0] in oracles else None,
                               'old_17_rows_match': True,
                               'previous_44_rows_match': previous_44_matches.get(x['label'].split('-',1)[0], False),
                               'handled_mutable_output_row_match': handled_row_matches.get(x['label'].split('-',1)[0], False)} for x in originals],
            'build_receipt_binding': independent_build,
            'provider_compile_runtime': provider_rows,
            'jadx_profiles': sorted(jadx.keys()), 'jarde_reports': report_summaries,
            'input_manifest_entries': input_summary,
            'resource_guard': receipt.get('resource_guard'), 'workspace_target': target_state,
            'source_tool_pins_count': len(receipt.get('source_tool_pins_before', [])),
            'source_tool_pins': receipt.get('source_tool_pins_before', []),
            'raw_streams': raw_refs}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--debug-capture', required=True, type=pathlib.Path)
    parser.add_argument('--none-capture', required=True, type=pathlib.Path)
    parser.add_argument('--previous-debug-capture', required=True, type=pathlib.Path)
    parser.add_argument('--previous-none-capture', required=True, type=pathlib.Path)
    parser.add_argument('--legacy-prep-pins', default='/private/tmp/jarde-em20-raw-alias-escape-baseline-prep-luna-v3/pins.json', type=pathlib.Path)
    parser.add_argument('--final-clean-receipt', required=True, type=pathlib.Path)
    parser.add_argument('--out', required=True, type=pathlib.Path)
    args = parser.parse_args()
    if args.out.exists():
        raise SystemExit(f'refuse overwrite: {args.out}')
    legacy_pins = read_json(args.legacy_prep_pins)
    errors = []
    clean = audit_final_clean(args.final_clean_receipt, errors)
    previous = {'debug': audit_previous_capture(args.previous_debug_capture, 'debug', errors),
                'none': audit_previous_capture(args.previous_none_capture, 'none', errors)}
    captures = [audit_capture(args.debug_capture, 'debug', legacy_pins, previous['debug'], errors),
                audit_capture(args.none_capture, 'none', legacy_pins, previous['none'], errors)]
    cross = {}
    if all(captures):
        left = {x['jdk']: x['stdout_sha256'] for x in captures[0]['original_rows']}
        right = {x['jdk']: x['stdout_sha256'] for x in captures[1]['original_rows']}
        cross['original_same_jdk_outputs_match_across_debug_modes'] = left == right
        require(left == right, 'original full Runner output differs across javac debug modes', errors)
        old_left = {jdk: sha(previous['debug']['outputs'][jdk]['stdout']) for jdk in JDKS} if previous.get('debug') else {}
        old_right = {jdk: sha(previous['none']['outputs'][jdk]['stdout']) for jdk in JDKS} if previous.get('none') else {}
        cross['previous_44_row_oracles_match_across_debug_modes'] = old_left == old_right
        require(old_left == old_right, 'previous 44-row raw oracle differs across debug modes', errors)
    previous_summary = {}
    for mode, item in previous.items():
        if item is None:
            previous_summary[mode] = None
            continue
        outputs = {}
        for jdk, output in item.get('outputs', {}).items():
            stdout = output.get('stdout', b'')
            stderr = output.get('stderr', b'')
            outputs[jdk] = {
                'exit_code': output.get('exit_code'),
                'stdout_bytes': len(stdout), 'stdout_sha256': sha(stdout),
                'stderr_bytes': len(stderr), 'stderr_sha256': sha(stderr),
            }
        previous_summary[mode] = {
            'capture': item.get('capture'), 'receipt': item.get('receipt'),
            'mode': item.get('mode'), 'original_rows': item.get('original_rows'),
            'outputs': outputs,
        }
    result = {'schema': 'jarde-ordinary-try-list-mvp-baseline-independent-audit-v4',
              'status': 'audited-with-errors' if errors else 'audited',
              'captures': captures, 'previous_44_row_oracles': previous_summary, 'final_clean': clean, 'cross_mode': cross, 'errors': errors,
              'interpretation': 'Compile failures are preserved as no-runtime observations; only original runtime is a strict zero-exit oracle. Any provider runtime mismatch is an audit error, never called a pass.'}
    try:
        result['physical_method_parser'] = pin(SAME_NAME_METHOD_HELPER)
    except OSError as exc:
        result['physical_method_parser'] = {'error': str(exc)}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'errors': errors, 'audit': str(args.out)}, indent=2, ensure_ascii=False))
    return 1 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
