This directory contains the rebuilt independent candidate auditor. It reads retained collector captures and writes only a new `--out` directory. It never invokes Cargo, a JDK, Jarde, JADX, a shell, or a network operation. `baseline45/auditor-v4/audit.py` is pinned as the parser/raw-stream provenance; its physical parser is expanded here to retain CP invocation targets and method Signature attributes. The accepted CF07 instruction decoder is pinned and only its three pure definitions are loaded by AST extraction.

The auditor requires the maintained Python `blake3` package. Root installed `blake3==1.0.11` into the persistent `tools/pythonlib` directory. Its cp312 native module requires the provided Python 3.12 runtime; add that directory to `PYTHONPATH`. The system Python 3.14 is incompatible. The runtime report records its actual distribution version, upstream repository, and all Python/native module code pins and checks they remain unchanged. No custom cryptographic implementation is present. File receipts use SHA-256; Jarde class/view/owner bindings use BLAKE3. The pure selfcheck includes the published BLAKE3 empty-input test vector `af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262` and the exact four accepted class identity digests.

Example invocation after all four candidate captures finish (replace every placeholder with an existing retained capture directory):

```sh
PYTHONPATH=/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/pythonlib \
/home/lordcasser/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/review/audit_candidate.py \
  --capture baseline:debug:<baseline-debug-capture> \
  --capture baseline:none:<baseline-none-capture> \
  --capture admission:debug:<admission-debug-capture> \
  --capture admission:none:<admission-none-capture> \
  --out <fresh-independent-audit-output-directory>
```

All 16 Jarde render cells and 16 complete-class compile/run cells must succeed. Missing cells and compile failures cannot be accepted. Every generated target source and complete Runner must be exactly the source pinned by its corresponding compile command. Every render uses its own JDK's original class. The baseline original runtime must match the archived accepted 45-row stdout/stderr bytes; admission must match all 33 fixed rows (3822 stdout bytes, SHA-256 `599122bdd1c6fa460a074f2a6e1117a7211772492a932a73ab980afdbc68de6d`, empty stderr).

The five target declarations require exact String/Integer List parameter elements, projection markers, and a compiled Signature equal to their physical original. The six admission refusals require raw declarations, refusal markers, and absent compiled Signature. The catch-visible iterator-gap control additionally requires iterator() before marker=1, absence of foreach, and physical CP-derived iterator/marker BCI source-map bindings. Prefix remove uses the actual Object formal and exact unique compiled remove(Object) descriptor; no redundant source cast is required. All map origins must identify the same physical method and legal instruction boundary. Positive next/checkcast/remove(Object) semantic anchors must remain. Missing pure-goto source-map coverage is reported and does not itself mean an invalid map.

Default/all sources, declarations, raw bodies, maps, and physical bindings must agree within each JDK. JADX input jars must contain only that JDK's original target class. Its rendered sources are immutable and recompiled with the same JDK and complete Runner. A failed JADX compile is allowed only as explicit no-runtime. Successful JADX output must match the same-JDK oracle.

`selfcheck.py` is an auditor-internal pure parser/helper check. It is not candidate acceptance. Run it with the same `PYTHONPATH` once the maintained package is installed; it creates only `selfcheck.json` here. No candidate auditor main has been run by the review agent. The current helper validation passed under Python 3.12 with maintained blake3 1.0.11. `helper-smoke-v1/execution.json` records the exact argv, executable/package/source pins, exit status, and raw output. The checks include both empty-input and abc public hash vectors, all four accepted physical class tables and BLAKE3 identities, 136 method/map checks, default/all agreement, missing render/compile rejection, failed Jarde compile/no-runtime rejection, and map/Signature/gap mutation refusals. An earlier temporary custom-hash smoke result was removed and does not certify this version.
