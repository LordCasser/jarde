import javax.tools.ToolProvider;
public class JavacBridge {
    public static void main(String[] args) {
        var compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) throw new IllegalStateException("system Java compiler unavailable");
        System.exit(compiler.run(null, System.out, System.err, args));
    }
}
