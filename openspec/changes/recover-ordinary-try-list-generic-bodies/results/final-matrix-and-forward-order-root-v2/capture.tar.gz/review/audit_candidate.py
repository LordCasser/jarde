#!/usr/bin/env python3
"""Independent, read-only candidate auditor for ordinary Try/List full-class captures.

Only --out is written; no compiler, product, shell, network, or imported workflow runs.
Four --capture FAMILY:DEBUG:DIRECTORY arguments are mandatory. Each input must retain
its absolute recorded files; only the frozen accepted baseline reference is relocated.
The pure instruction decoder is isolated from the accepted archive by AST extraction.
Missing/failed Jarde render, compile, or runtime cells are acceptance failures.
"""
import argparse
import ast
import datetime
import hashlib
import json
import os
import pathlib
import re
import struct
import sys
import zipfile
sys.dont_write_bytecode = True
JDKS = ('javac8', 'javac23')
MODES = ('default', 'all')
JADX_MODES = ('default', 'none')
MIN_FREE, MAX_TARGET = 5 * 1024**3, 1024**3
BASE_RECEIPTS = {
    'debug': '2b83bb12372c93c468936da48fbf77b70abae94c8b4e72fcfbb08b8c0c0e6945',
    'none': '0b8d1d710540c8a24cecde8d94a91c78038a404391900d4ff0d3409b1cc159ff',
}
BASE_SOURCE = 'edc6d5ab7258ad79eb13cc0163c042dcdc885dd3d3d160829a098a8b5d98a1ed'
BASE_RUNNER = 'd810c2466b31edc6d9df9b7286dedc21ca77428fa329f86d98d8a36d6f7dee7d'
BASE_STDOUT = '1f814066ddff6b56b7036679b268c0f576f52fc307fe03e063fe13780e39f908'
ADMISSION_SOURCE = '4b548725ec08c31bcbb09b31a22a3e54c74481b3e7773eb8c9fe2c66c5b155f2'
ADMISSION_RUNNER = 'dee1e694ee91c71806bfeea4609876d11d3331304e469300c2247ea6c2e1fd98'
ADMISSION_STDOUT = '599122bdd1c6fa460a074f2a6e1117a7211772492a932a73ab980afdbc68de6d'
DECODER_SHA = 'f30754e1e52403713a671ce38f274b772f188583df6c4a1bc6b4400937233469'
V4_SHA = '630010fac573d190442d2f568475072b7d66d622c3e19b541e6ef7a9060715e6'
BASE_POS = {'handled': ('String', 2), 'tryStringBranch': ('String', 2),
            'tryIntegerBranch': ('Integer', 2), 'tryStringRemovePrefix': ('String', 2),
            'tryStringNested': ('String', 3)}
ADM_POS = {'renamedTry': ('String', 2), 'stringBranch': ('String', 2),
           'integerTry': ('Integer', 2), 'nestedTry': ('String', 3),
           'stringRemovePrefix': ('String', 2)}
BASE_NEG = ('castBoundary', 'rawAliasEscape', 'reassigned', 'wildcardNull',
            'indexOverload', 'tryStringUnknownCall')
ADM_NEG = ('catchVisibleIteratorGap', 'unknownCatchUse', 'reassignedInCatch',
           'rawAliasInCatch', 'multiCatch', 'indexOverload')
DEFAULT_ROOT = pathlib.Path('/home/lordcasser/workspace/projects/jarde')
DEFAULT_REFERENCE = pathlib.Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/baseline45')
errors = []


def need(condition, message):
    if not condition:
        errors.append(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8'))


def pin(path):
    path = pathlib.Path(path)
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': sha(data)}


def checked_pin(meta, label, path=None):
    path = pathlib.Path(meta['path'] if path is None else path)
    actual = pin(path)
    need(actual['bytes'] == meta.get('bytes') and actual['sha256'] == meta.get('sha256'),
         label + ': live pin mismatch ' + str(path))
    return path


def option(argv, name):
    if argv.count(name) != 1:
        raise ValueError('option absent/duplicated: ' + name)
    index = argv.index(name)
    if index + 1 >= len(argv):
        raise ValueError('option missing value: ' + name)
    return argv[index + 1]


def raw_stream(capture, row, name, relocated=False):
    # Derived from accepted auditor-v4 raw_stream; relocation is only for accepted archives.
    meta = row['streams'][name]
    path = pathlib.Path(meta['path'])
    if relocated:
        path = capture / 'raw' / path.name
    else:
        need(path.resolve().parent == (capture / 'raw').resolve(),
             str(capture) + ': raw stream escapes capture')
    checked_pin(meta, row['label'] + '/' + name, path)
    return path.read_bytes()


def blake3_dependency():
    """Record the maintained PyPI blake3 package version and every live code file pin.

    Root supplies the installed package using PYTHONPATH; this auditor never installs it.
    Fail closed when absent. No locally implemented cryptographic algorithm is used.
    """
    import blake3
    import importlib.metadata
    package = pathlib.Path(blake3.__file__).resolve().parent
    files = sorted(p for p in package.rglob('*') if p.is_file() and
                   '__pycache__' not in p.parts and p.suffix in ('.py', '.so', '.pyd', '.dll'))
    return {'name': 'blake3', 'version': importlib.metadata.version('blake3'),
            'upstream': 'https://github.com/oconnor663/blake3-py',
            'package_path': str(package), 'files': [pin(p) for p in files]}


def class_digest(data):
    """Jarde uses BLAKE3-256 for physical bindings; SHA-256 remains the file pin hash."""
    from blake3 import blake3
    return blake3(data).hexdigest()


def class_file(path):
    """Bounded physical class parser, expanding v4 to retain CP targets and Signature."""
    data = pathlib.Path(path).read_bytes()
    pos = 0
    def take(n):
        nonlocal pos
        if n < 0 or pos + n > len(data):
            raise ValueError('truncated classfile at ' + str(pos))
        result = data[pos:pos+n]
        pos += n
        return result
    def u1(): return take(1)[0]
    def u2(): return int.from_bytes(take(2), 'big')
    def u4(): return int.from_bytes(take(4), 'big')
    if u4() != 0xcafebabe:
        raise ValueError('bad classfile magic')
    minor, major = u2(), u2()
    cp = [None] * u2()
    i = 1
    while i < len(cp):
        tag = u1()
        if tag == 1: cp[i] = (tag, take(u2()))
        elif tag in (3, 4): cp[i] = (tag, take(4))
        elif tag in (5, 6): cp[i] = (tag, take(8)); i += 1
        elif tag in (7, 8, 16, 19, 20): cp[i] = (tag, u2())
        elif tag in (9, 10, 11, 12, 17, 18): cp[i] = (tag, u2(), u2())
        elif tag == 15: cp[i] = (tag, u1(), u2())
        else: raise ValueError('unknown CP tag ' + str(tag))
        i += 1
    def utf(index):
        if not 0 < index < len(cp) or cp[index] is None or cp[index][0] != 1:
            raise ValueError('CP UTF8 expected')
        return cp[index][1].decode('utf-8')
    def class_name(index):
        if not 0 < index < len(cp) or cp[index] is None or cp[index][0] != 7:
            raise ValueError('CP Class expected')
        return utf(cp[index][1])
    def target(index):
        entry = cp[index]
        if entry[0] not in (9, 10, 11): raise ValueError('CP member ref expected')
        nt = cp[entry[2]]
        if nt[0] != 12: raise ValueError('CP NameAndType expected')
        return class_name(entry[1]), utf(nt[1]), utf(nt[2])
    flags = u2(); owner = class_name(u2()); take(2); take(2 * u2())
    def attributes():
        result = {}
        for _ in range(u2()):
            name = utf(u2()); payload = take(u4())
            if name in result: raise ValueError('duplicate attribute ' + name)
            result[name] = payload
        return result
    for _ in range(u2()): take(6); attributes()
    methods = {}
    for index in range(u2()):
        method_flags = u2(); name = utf(u2()); descriptor = utf(u2()); attrs = attributes()
        key = name + descriptor
        if key in methods: raise ValueError('duplicate physical method ' + key)
        payload = attrs.get('Code'); code = None; exception_rows = []
        if payload is not None:
            if len(payload) < 8: raise ValueError('truncated Code')
            n = int.from_bytes(payload[4:8], 'big'); code = payload[8:8+n]
            if len(code) != n or len(payload) < 10+n: raise ValueError('truncated Code bytes')
            ec = int.from_bytes(payload[8+n:10+n], 'big'); at = 10+n
            if len(payload) < at+8*ec: raise ValueError('truncated exception rows')
            for off in range(at, at+8*ec, 8):
                exception_rows.append(tuple(int.from_bytes(payload[off+j:off+j+2], 'big') for j in (0, 2, 4, 6)))
        signature = attrs.get('Signature')
        if signature is not None and len(signature) != 2: raise ValueError('bad Signature size')
        methods[key] = {'index': index, 'name': name, 'descriptor': descriptor,
                        'flags': method_flags, 'code': code, 'exceptions': exception_rows,
                        'signature': utf(int.from_bytes(signature, 'big')) if signature is not None else None}
    attributes()
    if pos != len(data): raise ValueError('trailing classfile bytes')
    return {'owner': owner, 'flags': flags, 'major': major, 'minor': minor,
            'methods': methods, 'target': target, 'class_name': class_name}


def load_decoder(reference):
    # Exactly the v4 technique: isolate three pure definitions, never execute script top level.
    need(pin(reference / 'auditor-v4' / 'audit.py')['sha256'] == V4_SHA,
         'accepted auditor-v4 archive differs')
    candidates = list((reference / 'pinned-tools').glob('*cf07*.py'))
    paths = [p for p in candidates if pin(p)['sha256'] == DECODER_SHA]
    if len(paths) != 1: raise ValueError('accepted pinned physical instruction decoder not unique')
    tree = ast.parse(paths[0].read_text(encoding='utf-8'))
    wanted = {'need', 'insn_size', 'decode'}
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in wanted]
    if {n.name for n in nodes} != wanted: raise ValueError('decoder pure definitions absent')
    namespace = {'struct': struct}
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), str(paths[0]), 'exec'), namespace)
    return namespace['decode']


def baseline_oracle(reference, debug, jdk):
    capture = reference / 'captures' / debug
    receipt_path = capture / 'execution.json'
    need(pin(receipt_path)['sha256'] == BASE_RECEIPTS[debug], 'accepted45 receipt pin differs')
    receipt = read_json(receipt_path)
    rows = [r for r in receipt['commands'] if r['label'] == jdk + '-original-run']
    if len(rows) != 1: raise ValueError('accepted original runtime row not unique')
    need(rows[0]['exit_code'] == 0 and rows[0].get('guard_stop') is None,
         'accepted original runtime did not succeed')
    out = raw_stream(capture, rows[0], 'stdout', True)
    err = raw_stream(capture, rows[0], 'stderr', True)
    need(len(out.splitlines()) == 45 and sha(out) == BASE_STDOUT and not err,
         'accepted45 oracle differs')
    return 0, out, err


def method_identity(row):
    identity = row['item']['identity']; member = identity.get('member', identity)
    key = bytes(member['name']).decode() + bytes(member['descriptor']).decode()
    return key, identity


def physical_calls(classfile, key, decode):
    result = []
    code = classfile['methods'][key]['code']
    for bci, opcode, operand in decode(code) if code is not None else []:
        if opcode in (0xb6, 0xb7, 0xb8, 0xb9):
            result.append({'bci': bci, 'opcode': opcode,
                           'target': classfile['target'](int.from_bytes(operand[1:3], 'big'))})
    return result


def map_audit(row, original, decode, digest, label, semantic_required=False):
    key, identity = method_identity(row)
    raw = row['outcome']['report']; method = original['methods'][key]
    need(row['outcome'].get('kind') == 'recovered', label + ': method not recovered ' + key)
    need(raw.get('method') == key, label + ': raw method identity differs ' + key)
    need(raw.get('artifact', {}).get('binding', {}).get('method') == identity,
         label + ': artifact method binding differs ' + key)
    need(identity.get('owner', {}).get('class_bytes', {}).get('digest') == digest,
         label + ': physical owner digest differs ' + key)
    need(raw.get('outcome') == 'produced' and raw.get('content') == 'contains_statements',
         label + ': raw body not produced ' + key)
    need(raw.get('execution', {}).get('status') == 'complete', label + ': raw body stopped ' + key)
    need(row.get('outcome', {}).get('analysis', {}).get('execution', {}).get('status') == 'complete',
         label + ': method analysis stopped ' + key)
    body = raw['text'].encode('utf-8'); covered = set(); texts = {}; spans = {}
    insns = decode(method['code']) if method['code'] is not None else []
    boundaries = {b for b, _, _ in insns}
    segments = raw['source_map']['segments']
    need(isinstance(segments, list) and bool(segments), label + ': source map absent ' + key)
    for seg in segments:
        a, b = seg['start'], seg['end']
        valid = type(a) is int and type(b) is int and 0 <= a <= b <= len(body)
        if valid:
            valid = all(x in (0, len(body)) or (body[x] & 0xc0) != 0x80 for x in (a, b))
        need(valid, label + ': invalid UTF8 map span ' + key)
        if not valid: continue
        origin = seg['origin']
        refs = ([origin['primary']] if origin.get('primary') else []) + (origin.get('derived') or [])
        need(bool(refs), label + ': map span has no physical origin ' + key)
        for ref in refs:
            need(ref.get('method') == identity, label + ': map physical method differs ' + key)
            bci = ref.get('bci')
            if bci is not None:
                need(type(bci) is int and bci in boundaries, label + ': nonphysical BCI ' + key + '/' + str(bci))
                if type(bci) is int:
                    covered.add(bci); texts.setdefault(bci, []).append(body[a:b].decode())
                    spans.setdefault(bci, []).append((a, b))
    categories = raw.get('evidence', {}).get('categories', [])
    need(any(c.get('kind') == 'source_map' and c.get('state', {}).get('state') == 'complete' for c in categories),
         label + ': complete map evidence missing ' + key)
    semantic = []
    for index, (bci, opcode, operand) in enumerate(insns):
        if opcode not in (0xb6, 0xb7, 0xb8, 0xb9): continue
        target = original['target'](int.from_bytes(operand[1:3], 'big'))
        if target == ('java/util/Iterator', 'next', '()Ljava/lang/Object;'):
            if semantic_required:
                need(bci in covered and any('next()' in s or 'iteratorElement' + str(bci) in s for s in texts.get(bci, [])),
                     label + ': physical next invoke origin absent ' + key + '/' + str(bci))
            if index + 1 < len(insns) and insns[index+1][1] == 0xc0:
                cbci, _, cast = insns[index+1]
                ty = original['class_name'](int.from_bytes(cast[1:3], 'big')).replace('/', '.')
                if semantic_required:
                    need(cbci in covered and any('(' + ty + ')' in s for s in texts.get(cbci, [])),
                         label + ': physical next checkcast origin absent ' + key + '/' + str(cbci))
                semantic.append({'kind': 'next-checkcast', 'next_bci': bci, 'cast_bci': cbci, 'type': ty})
        if target == ('java/util/List', 'remove', '(Ljava/lang/Object;)Z'):
            if semantic_required:
                need(bci in covered and any('.remove(' in s for s in texts.get(bci, [])),
                     label + ': remove(Object) invoke origin absent ' + key + '/' + str(bci))
            semantic.append({'kind': 'removeObject', 'invoke_bci': bci})
    if method['name'] == 'catchVisibleIteratorGap':
        # This negative control must retain iterator() before its catch-visible marker=1.
        calls = physical_calls(original, key, decode)
        init = [c for c in calls if c['target'] == ('java/util/List', 'iterator', '()Ljava/util/Iterator;')]
        test = [c for c in calls if c['target'] == ('java/util/Iterator', 'hasNext', '()Z')]
        need(len(init) == len(test) == 1, label + ': gap physical iterator/test not unique ' + key)
        need(not re.search(r'\bfor\s*\(', raw['text']), label + ': catch-visible gap converted to foreach ' + key)
        if len(init) == len(test) == 1:
            ibci, tbci = init[0]['bci'], test[0]['bci']
            stores = [(b, o, r) for b, o, r in insns if ibci < b < tbci and o in (0x36, 0x3b, 0x3c, 0x3d, 0x3e)]
            itokens = list(re.finditer(rb'\.iterator\s*\(\s*\)', body))
            mtokens = list(re.finditer(rb'\b([A-Za-z_$][A-Za-z0-9_$]*)\s*=\s*1\s*;', body))
            need(len(stores) == len(itokens) == len(mtokens) == 1,
                 label + ': gap physical/source marker not unique ' + key)
            if len(stores) == len(itokens) == len(mtokens) == 1:
                mbci = stores[0][0]; it, mt = itokens[0], mtokens[0]
                need(ibci < mbci < tbci and it.end() <= mt.start(), label + ': gap iterator/marker reordered ' + key)
                def mapped_token(bci, token):
                    return any(a <= token.start() and token.end() <= b for a, b in spans.get(bci, []))
                need(mapped_token(ibci, it), label + ': gap iterator physical origin absent ' + key)
                need(mapped_token(mbci, mt), label + ': gap marker store physical origin absent ' + key)
                semantic.append({'kind': 'catch-visible-iterator-gap', 'iterator_bci': ibci,
                                 'marker_store_bci': mbci, 'hasNext_bci': tbci, 'marker_name': mt.group(1).decode()})
    record = {'identity': identity, 'item_body': row['item'].get('body'),
              'render_body': raw['text'], 'source_map': raw['source_map']}
    return {'coverage_missing': sorted(boundaries-covered), 'coverage_extra': sorted(covered-boundaries),
            'semantic_origins': semantic, 'raw_text_sha256': sha(body),
            'raw_map_sha256': sha(json.dumps(raw['source_map'], sort_keys=True).encode()),
            'method_record_sha256': sha(json.dumps(record, sort_keys=True, ensure_ascii=False).encode())}


def projection_audit(doc, original, compiled, family, label, decode):
    compiled_available = compiled is not None
    need(compiled_available, label + ': REQUIRED compiled target class unavailable; Signature proof cannot be accepted')
    if not compiled_available:
        compiled = {'methods': {}}
    positives = BASE_POS if family == 'baseline' else ADM_POS
    negatives = BASE_NEG if family == 'baseline' else ADM_NEG
    byname = {}
    for row in doc['methods']:
        key, _ = method_identity(row)
        byname.setdefault(original['methods'][key]['name'], []).append(row)
    observations = []
    for name, (element, count) in positives.items():
        rows = byname.get(name, [])
        need(len(rows) == 1, label + ': positive target not unique ' + name)
        if len(rows) != 1: continue
        row = rows[0]; key, _ = method_identity(row); declaration = row.get('declaration') or ''
        actual = re.findall(r'java\.util\.List<([^>]+)>', declaration)
        need(actual == ['java.lang.' + element] * count, label + ': exact List parameter elements differ ' + name + ' ' + repr(actual))
        need(not re.search(r'java\.util\.List\s+[A-Za-z_$]', declaration), label + ': positive raw List remains ' + name)
        markers = str(row.get('markers', []))
        need('ordinary_generic_source_unproved' not in markers, label + ': positive refusal marker ' + name)
        need('generic Signature' in markers and 'projected after' in markers, label + ': positive projection marker absent ' + name)
        need(original['methods'][key]['signature'] is not None, label + ': positive original Signature absent ' + key)
        if compiled_available:
            need(compiled['methods'].get(key, {}).get('signature') == original['methods'][key]['signature'],
                 label + ': compiled positive Signature differs from physical original ' + key)
        need('.add((java.lang.Object)' not in row['text'], label + ': positive add(E) wrapper retained ' + name)
        remove_evidence = None
        if name in ('tryStringRemovePrefix', 'stringRemovePrefix'):
            descriptor = '(Ljava/util/List;Ljava/util/List;Ljava/lang/Object;)V'
            need(original['methods'][key]['descriptor'] == descriptor,
                 label + ': prefix original Object formal descriptor differs ' + name)
            if compiled_available:
                need(compiled['methods'].get(key, {}).get('descriptor') == descriptor,
                     label + ': prefix compiled Object formal descriptor changed ' + name)
            formals = re.findall(r'java\.lang\.Object\s+[A-Za-z_$][A-Za-z0-9_$]*', declaration)
            need(len(formals) == 1, label + ': prefix source Object key missing/duplicated ' + name)
            orig = [c for c in physical_calls(original, key, decode) if c['target'][1] == 'remove']
            recomp = [c for c in physical_calls(compiled, key, decode) if c['target'][1] == 'remove'] if compiled_available else []
            expected = ('java/util/List', 'remove', '(Ljava/lang/Object;)Z')
            need(len(orig) == 1 and all(c['opcode'] == 0xb9 and c['target'] == expected for c in orig),
                 label + ': prefix original remove(Object) not unique ' + name)
            if compiled_available:
                need(len(recomp) == 1 and all(c['opcode'] == 0xb9 and c['target'] == expected for c in recomp),
                     label + ': prefix compiled remove(Object) not unique or changed to remove(int) ' + name)
            remove_evidence = {'original': orig, 'compiled': recomp, 'Object_formals': formals}
        observations.append({'method': key, 'list_elements': actual,
                             'compiled_signature': compiled['methods'].get(key, {}).get('signature'),
                             'compiled_signature_state': 'checked' if compiled_available else 'unavailable-compile-failed',
                             'remove_prefix': remove_evidence})
    for name in negatives:
        rows = byname.get(name, [])
        need(len(rows) == 1, label + ': refusal control absent/not unique ' + name)
        if len(rows) != 1: continue
        row = rows[0]; key, _ = method_identity(row)
        need('ordinary_generic_source_unproved' in str(row.get('markers', [])), label + ': control refusal marker absent ' + name)
        need('java.util.List<' not in (row.get('declaration') or ''), label + ': control generic declaration installed ' + name)
        if compiled_available:
            need(compiled['methods'].get(key, {}).get('signature') is None, label + ': control compiled Signature installed ' + key)
    return observations


def check_tool(path, manifest, jdk, name, label):
    legs = [x for x in manifest['legs'] if x['leg'] == jdk]
    if len(legs) != 1: raise ValueError('JDK manifest leg missing/duplicate ' + jdk)
    meta = legs[0]['jdk_tools'][name]
    checked_pin(meta, label + ' ' + name, path)
    need(pathlib.Path(path).resolve() == pathlib.Path(meta['path']).resolve(), label + ': JDK executable binding differs')
    return pathlib.Path(meta['path']).resolve().parent.parent


def required_jarde_cells(receipt, expected_class, label):
    """Fail closed on the full collector matrix before inspecting any live cell files."""
    expected_renders = {(j, m, expected_class) for j in JDKS for m in MODES}
    profiles = receipt.get('jarde_profiles')
    if not isinstance(profiles, list):
        need(False, label + ': REQUIRED Jarde render matrix absent')
        profiles = []
    renders = [(p.get('jdk'), p.get('mode'), p.get('class')) for p in profiles]
    need(len(renders) == len(expected_renders) and set(renders) == expected_renders,
         label + ': REQUIRED Jarde render cells missing/duplicate/extra')
    for profile in profiles:
        need(profile.get('render_exit') == 0 and not profile.get('parse_error') and
             isinstance(profile.get('report_pin'), dict) and isinstance(profile.get('source_pin'), dict),
             label + ': REQUIRED Jarde render failed or lacks saved complete output')
    expected_compiles = {j + '-jarde-' + m + '-combined' for j in JDKS for m in MODES}
    rows = receipt.get('jarde_compile_rows')
    if not isinstance(rows, list):
        need(False, label + ': REQUIRED Jarde compile matrix absent')
        rows = []
    names = [row.get('label') for row in rows]
    need(len(names) == len(expected_compiles) and set(names) == expected_compiles,
         label + ': REQUIRED Jarde compile cells missing/duplicate/extra')
    for row in rows:
        need(row.get('compile_exit') == 0 and row.get('run_exit') == 0 and
             row.get('runtime_state') == 'ran' and row.get('class_set_exact') is True,
             label + ': REQUIRED Jarde compile/runtime failure cannot be accepted')


def audit_capture(family, debug, capture, repo, reference, decode):
    capture = capture.resolve(); label = family + '/' + debug
    r = read_json(capture / 'execution.json'); config = r['collector_config']
    expected_class = 'cf11.UpstreamNestedLoops' if family == 'baseline' else 'cf11.OrdinaryTryListFixture'
    expected_file = expected_class.rsplit('.', 1)[1] + '.java'
    required_jarde_cells(r, expected_class, label)
    need(r.get('schema') == 'cf11-target-full-source-capture-v2' and r.get('status') == 'observed', label + ': receipt incomplete/schema differs')
    need(r.get('package') == 'cf11' and r.get('classes') == [expected_class] and r.get('runner_class') == 'cf11.Runner', label + ': capture class scope differs')
    need(r.get('javac_debug_info') == {'mode': debug, 'argument': '-g' if debug == 'debug' else '-g:none'} and config.get('javac_debug') == debug,
         label + ': compiler debug mode differs')
    need(pathlib.Path(config['out']).resolve() == capture, label + ': collector output binding differs')
    manifest_path = checked_pin(r['inputs_manifest'], label + ' inputs manifest')
    need(manifest_path.resolve() == pathlib.Path(r['inputs_manifest_path']).resolve(), label + ': manifest path binding differs')
    manifest = read_json(manifest_path)
    need(manifest == r['input_entries'], label + ': receipt manifest differs from pinned file')
    repo_manifest = read_json(repo / 'tests/fixtures/cf11-ordinary-try-list-generic' / family / 'manifest.json')
    need(manifest == repo_manifest, label + ': capture manifest differs from independent repository input manifest')
    need([x['class'] for x in manifest['target_classes']] == [expected_class] and manifest['runner']['class'] == 'cf11.Runner', label + ': manifest target set differs')
    source, runner = manifest['target_classes'][0], manifest['runner']
    need(source['sha256'] == (BASE_SOURCE if family == 'baseline' else ADMISSION_SOURCE) and
         source['bytes'] == (7402 if family == 'baseline' else 5432), label + ': fixed target source pin differs')
    need(runner['sha256'] == (BASE_RUNNER if family == 'baseline' else ADMISSION_RUNNER) and
         runner['bytes'] == (12601 if family == 'baseline' else 10678), label + ': fixed Runner source pin differs')
    need(source['source'] == expected_file and runner['source'] == 'Runner.java', label + ': input filename differs')
    if family == 'admission':
        need(set(source['candidate_methods']) == set(ADM_POS) | set(ADM_NEG) and len(source['candidate_methods']) == 11,
             label + ': admission positive/control method manifest differs')
    for item in (source, runner):
        path = (pathlib.Path(config['inputs_dir']) / item['source']).resolve()
        need(path.is_relative_to(pathlib.Path(config['inputs_dir']).resolve()), label + ': input escapes source directory')
        checked_pin(item, label + ' input source', path)
        checked_pin(item, label + ' copied source', capture / 'inputs' / item['source'])
    before, after = r.get('source_tool_pins_before'), r.get('source_tool_pins_after')
    need(isinstance(before, list) and before == after and r.get('source_tool_inputs_unchanged') is True,
         label + ': source/tools changed during capture')
    for meta in before: checked_pin(meta, label + ' source/tool')
    need(r.get('cli_mode') == '0o555', label + ': CLI not frozen mode0555')
    cli = checked_pin(r['cli'], label + ' CLI')
    need((cli.stat().st_mode & 0o777) == 0o555 and os.access(cli, os.X_OK), label + ': live CLI not frozen executable')
    need(cli.resolve() == pathlib.Path(config['cli']).resolve() and pin(cli)['sha256'] == config['cli_sha256'], label + ': CLI configuration differs')
    build_path = checked_pin(r['build_receipt'], label + ' build receipt')
    need(build_path.resolve() == pathlib.Path(config['build_receipt']).resolve() and pin(build_path)['sha256'] == config['build_receipt_sha256'], label + ': build receipt configuration differs')
    build = read_json(build_path); binding = build
    for part in config['receipt_cli_object'].split('.'): binding = binding[part]
    need(config['receipt_accepted_value'] == 'commands_passed_pending_independent_acceptance' and
         build.get(config['receipt_status_key']) == config['receipt_accepted_value'], label + ': build receipt not successful')
    need(binding == r['build_receipt_cli_binding'] and all(binding.get(k) == r['cli'].get(k) for k in ('path', 'bytes', 'sha256')),
         label + ': build receipt does not bind CLI bytes')
    if config['receipt_mode_key']: need(binding.get(config['receipt_mode_key']) == '0o555', label + ': receipt CLI mode differs')
    for name in ('jdk_manifest', 'jadx', 'jadx_jar', 'guard', 'scanner', 'classfile_parser'):
        need(pin(config[name])['sha256'] == config[name + '_sha256'], label + ': configured tool pin differs ' + name)
    jm = read_json(config['jdk_manifest'])
    need(sorted(x['leg'] for x in jm['legs']) == sorted(JDKS), label + ': exact JDK8/23 manifest legs required')
    guard = r['resource_guard']
    need(guard.get('minimum_free_bytes') == MIN_FREE and guard.get('maximum_target_bytes') == MAX_TARGET and
         guard.get('poll_seconds') == 1 and guard.get('peak_target_sampled') is True, label + ': resource guard missing/weakened')
    target = r['workspace_target']
    need(target.get('absent_before') is True and target.get('absent_after') is True and target.get('unchanged_absent') is True,
         label + ': workspace target was not kept absent')
    need(pathlib.Path(target['path']).resolve() == (repo / 'target').resolve(), label + ': workspace target binding differs')
    commands = r['commands']; cmap = {c['label']: c for c in commands}
    need(len(cmap) == len(commands) == r['actual_command_count'], label + ': command labels/count disagree')
    need([c['index'] for c in commands] == list(range(1, len(commands)+1)), label + ': command index sequence differs')
    raws = {}
    for cmd in commands:
        need(cmd.get('state') == 'observed' and cmd.get('guard_stop') is None and type(cmd.get('exit_code')) is int,
             label + ': command did not finish or guard stopped ' + cmd['label'])
        need(type(cmd.get('peak_target_bytes')) is int and 0 <= cmd['peak_target_bytes'] <= MAX_TARGET and
             type(cmd.get('free_bytes_after')) is int and cmd['free_bytes_after'] >= MIN_FREE,
             label + ': command resource threshold missing/exceeded ' + cmd['label'])
        need(pathlib.Path(cmd['cwd']).resolve() == repo.resolve(), label + ': command workspace differs ' + cmd['label'])
        raws[cmd['label']] = tuple(raw_stream(capture, cmd, s) for s in ('stdout', 'stderr'))
    used = set()
    def get_command(name):
        used.add(name)
        return cmap[name]
    def compile_row(row, oracle=None, strict=True):
        name = row['label']; jdk = name.split('-', 1)[0]
        need(jdk in JDKS, label + ': compile JDK unknown ' + name)
        comp = get_command(row['compile_command']); argv = comp['argv']
        home = check_tool(argv[0], jm, jdk, 'javac', label + '/' + name)
        need(pathlib.Path(comp['java_home']).resolve() == home, label + ': compile JAVA_HOME differs ' + name)
        need(comp['exit_code'] == row['compile_exit'], label + ': compile status mismatch ' + name)
        output = pathlib.Path(option(argv, '-d')).resolve()
        need(output.is_relative_to(capture / 'legs'), label + ': compiler output escapes capture ' + name)
        sources = row['source_pins']
        for meta in sources: checked_pin(meta, label + ' compiler source ' + name)
        need(len(sources) == 2 and sorted(pathlib.Path(x['path']).name for x in sources) == sorted(['Runner.java', expected_file]),
             label + ': complete target+Runner compiler source set differs ' + name)
        need(len({pathlib.Path(x['path']).resolve() for x in sources}) == 2, label + ': duplicate compiler source ' + name)
        runner_pins = [x for x in sources if pathlib.Path(x['path']).name == 'Runner.java']
        need(len(runner_pins) == 1 and runner_pins[0]['sha256'] == runner['sha256'] and runner_pins[0]['bytes'] == runner['bytes'],
             label + ': compiler consumed a different Runner ' + name)
        empty = pathlib.Path(option(argv, '-classpath')).resolve()
        need(option(argv, '-sourcepath') == str(empty) and empty.is_relative_to(capture / 'legs') and empty.is_dir() and not any(empty.iterdir()),
             label + ': compiler class/source paths not exact empty directory ' + name)
        flags = ['-source', '8', '-target', '8', '-Xlint:-options'] if jdk == 'javac8' else ['--release', '8']
        expected_argv = [argv[0], *flags, '-proc:none', '-g' if debug == 'debug' else '-g:none',
                         '-classpath', str(empty), '-sourcepath', str(empty), '-d', str(output), *[x['path'] for x in sources]]
        need(argv == expected_argv, label + ': exact compiler argv differs ' + name)
        files = sorted(p.relative_to(output).as_posix() for p in output.rglob('*.class'))
        need(files == row['class_paths'], label + ': compiler physical class inventory differs ' + name)
        class_pins = row['classes']
        need(sorted(pathlib.Path(x['path']).resolve().relative_to(output).as_posix() for x in class_pins) == files,
             label + ': compiler class pin inventory differs ' + name)
        for meta in class_pins: checked_pin(meta, label + ' compiler class ' + name)
        if strict:
            need(row['compile_exit'] == 0 and row.get('run_exit') == 0 and row.get('runtime_state') == 'ran' and row.get('class_set_exact') is True,
                 label + ': REQUIRED compile/runtime cell failed ' + name)
        if row['compile_exit'] != 0:
            need(row.get('run_command') is None and row.get('run_exit') is None and row.get('runtime_state') == 'no-runtime' and
                 row.get('no_runtime_reason') == 'compile-failed', label + ': compile failure must remain explicit no-runtime ' + name)
            return None, output
        need(row.get('runtime_state') == 'ran' and row.get('run_command') is not None, label + ': successful compile lacks run ' + name)
        run = get_command(row['run_command'])
        run_home = check_tool(run['argv'][0], jm, jdk, 'java', label + '/' + name + ' runtime')
        need(run['argv'][1:] == ['-Xverify:all', '-cp', str(output), 'cf11.Runner'] and pathlib.Path(run['java_home']).resolve() == run_home,
             label + ': runtime classes/JAVA_HOME binding differs ' + name)
        need(run['exit_code'] == row['run_exit'] == 0, label + ': runtime failed/status mismatch ' + name)
        actual = row['run_exit'], *raws[run['label']]
        if oracle is not None:
            need(actual == oracle and row.get('runtime_comparison', {}).get('same_jdk_original') is True,
                 label + ': runtime bytes differ from same-JDK original ' + name)
        return actual, output
    original_rows = r['original_compile_rows']
    need(sorted(x['label'] for x in original_rows) == sorted(j + '-original' for j in JDKS), label + ': exact original compile cells absent/duplicate')
    oracles, originals, original_paths, class_sets, runtime = {}, {}, {}, {}, {}
    for row in original_rows:
        jdk = row['label'].split('-', 1)[0]
        oracle, output = compile_row(row); oracles[jdk] = oracle
        for meta in row['source_pins']:
            entry = runner if pathlib.Path(meta['path']).name == 'Runner.java' else source
            need(meta['sha256'] == entry['sha256'] and meta['bytes'] == entry['bytes'], label + ': original compiler consumed different source ' + jdk)
        path = output / (expected_class.replace('.', '/') + '.class')
        original_paths[jdk] = path; originals[jdk] = class_file(path); class_sets[jdk] = row['class_paths']
        need(originals[jdk]['owner'] == expected_class.replace('.', '/') and originals[jdk]['major'] == 52,
             label + ': original physical class owner/version differs ' + jdk)
        need(expected_class.replace('.', '/') + '.class' in row['class_paths'] and 'cf11/Runner.class' in row['class_paths'], label + ': original target/Runner missing')
        if family == 'baseline':
            need(oracle == baseline_oracle(reference, debug, jdk), label + ': original45 bytes differ from accepted baseline ' + jdk)
            need(len(originals[jdk]['methods']) == 17, label + ': original17 physical methods changed')
        else:
            need(oracle is not None and oracle[0] == 0 and len(oracle[1].splitlines()) == 33 and len(oracle[1]) == 3822 and
                 sha(oracle[1]) == ADMISSION_STDOUT and not oracle[2], label + ': admission fixed33 byte oracle differs ' + jdk)
            need(len(originals[jdk]['methods']) == 13, label + ': admission original13 physical methods changed')
        runtime[jdk] = {'stdout_sha256': sha(oracle[1]), 'stderr_sha256': sha(oracle[2]),
                        'stdout_bytes': len(oracle[1]), 'row_count': len(oracle[1].splitlines()),
                        'first17_sha256': sha(b''.join(oracle[1].splitlines(keepends=True)[:17])) if family == 'baseline' else None}
    need(oracles.get('javac8') == oracles.get('javac23'), label + ': original runtime differs across JDK8/23')
    compile_rows = r['jarde_compile_rows']
    need(sorted(x['label'] for x in compile_rows) == sorted(j + '-jarde-' + m + '-combined' for j in JDKS for m in MODES),
         label + ': exact four REQUIRED Jarde compile cells missing/duplicate/extra')
    compiled, compiled_inputs, compile_observations = {}, {}, {}
    for row in compile_rows:
        jdk, _, mode, _ = row['label'].split('-')
        _, output = compile_row(row, oracles[jdk])
        if row['compile_exit'] == 0:
            need(row['class_paths'] == class_sets[jdk], label + ': Jarde full class inventory differs')
        compiled_path = output / (expected_class.replace('.', '/') + '.class')
        compiled_inputs[(jdk, mode)] = row['source_pins']
        available = row['compile_exit'] == 0 and compiled_path.is_file()
        compiled[(jdk, mode)] = class_file(compiled_path) if available else None
        need(available, label + ': REQUIRED Jarde compiled target unavailable ' + row['label'])
        if available:
            need(set(compiled[(jdk, mode)]['methods']) == set(originals[jdk]['methods']) and compiled[(jdk, mode)]['owner'] == originals[jdk]['owner'],
                 label + ': compiled Jarde physical method/owner inventory differs')
        comp = cmap[row['compile_command']]
        compile_observations[(jdk, mode)] = {
            'label': row['label'], 'compile_exit': row['compile_exit'], 'run_exit': row.get('run_exit'),
            'runtime_state': row.get('runtime_state'), 'no_runtime_reason': row.get('no_runtime_reason'),
            'compiled_target_available': available,
            'stdout': comp['streams']['stdout'], 'stderr': comp['streams']['stderr'],
            'stderr_text': raws[comp['label']][1].decode('utf-8', errors='replace')}

    wanted = {(j, m, expected_class) for j in JDKS for m in MODES}
    cells, details = {}, []
    positive_names = set(BASE_POS if family == 'baseline' else ADM_POS)
    for profile in r['jarde_profiles']:
        cell = profile['jdk'], profile['mode'], profile['class']
        need(cell in wanted and cell not in cells, label + ': Jarde render duplicate/extra ' + str(cell))
        jdk, mode, cls = cell; command = get_command(profile['render_command']); argv = command['argv']
        need(command['exit_code'] == profile['render_exit'] == 0 and not profile.get('parse_error'),
             label + ': REQUIRED Jarde render failed/parse-error ' + str(cell))
        report_path = checked_pin(profile['report_pin'], label + ' report'); doc = read_json(report_path)
        out, err = raws[command['label']]
        need(doc == json.loads(out) and sha(out) == profile['render_stdout_sha256'] and sha(err) == profile['render_stderr_sha256'],
             label + ': saved report differs from exact render stdout ' + str(cell))
        source_path = checked_pin(profile['source_pin'], label + ' generated source')
        need(source_path.read_bytes() == doc['text'].encode(), label + ': generated source differs from report ' + str(cell))
        target_inputs = [x for x in compiled_inputs[(jdk, mode)] if pathlib.Path(x['path']).name == expected_file]
        need(len(target_inputs) == 1 and target_inputs[0] == profile['source_pin'], label + ': compiler did not consume exact rendered source ' + str(cell))
        own_class = original_paths[jdk]
        expected_argv = [str(cli), 'class-source', '--input', str(own_class), '--class', cls,
                         '--policy', 'single-class', '--release', '8', '--format', 'json']
        if mode == 'all': expected_argv += ['--evidence', 'all']
        need(argv == expected_argv, label + ': renderer arguments/own-JDK class input differ ' + str(cell))
        need(doc.get('outcome') == 'performed' and doc.get('execution', {}).get('status') == 'complete', label + ': REQUIRED class source not complete')
        need(profile.get('report_execution') == doc.get('execution'), label + ': receipt class execution differs')
        digest = class_digest(own_class.read_bytes()); root_class = doc['class']['class_bytes']
        need(root_class.get('digest') == digest and root_class.get('length') == own_class.stat().st_size and doc['view']['snapshot'] == digest,
             label + ': class/view binding does not match own-JDK physical class')
        keys = [method_identity(row)[0] for row in doc['methods']]
        need(len(keys) == len(set(keys)) and set(keys) == set(originals[jdk]['methods']), label + ': rendered physical method inventory differs')
        maps = {}
        for row in doc['methods']:
            key, _ = method_identity(row)
            need(row['item']['index'] == originals[jdk]['methods'][key]['index'], label + ': physical member ordinal differs ' + key)
            maps[key] = map_audit(row, originals[jdk], decode, digest, label + '/' + jdk + '/' + mode,
                                  originals[jdk]['methods'][key]['name'] in positive_names)
        obs = projection_audit(doc, originals[jdk], compiled[(jdk, mode)], family, label + '/' + jdk + '/' + mode, decode)
        record = {'text': doc['text'], 'declaration': doc.get('declaration'),
                  'methods': [{k: row.get(k) for k in ('declaration', 'markers', 'item')} |
                              {'raw_text': row['outcome']['report']['text'], 'source_map': row['outcome']['report']['source_map'],
                               'method_binding': row['outcome']['report']['artifact']['binding']['method']}
                              for row in doc['methods']]}
        cells[cell] = record
        details.append({'jdk': jdk, 'mode': mode, 'source_sha256': sha(source_path.read_bytes()),
                        'compile_run': compile_observations[(jdk, mode)], 'physical_maps': maps, 'projection': obs})
    need(set(cells) == wanted, label + ': REQUIRED render matrix incomplete')
    for jdk in JDKS:
        need(cells.get((jdk, 'default', expected_class)) == cells.get((jdk, 'all', expected_class)),
             label + ': default/all class source, declarations, raw bodies, maps, or physical bindings differ ' + jdk)
    # JADX is an independent comparison, permitted to fail compilation only with no runtime.
    # Its input jar and generated source are always inspected; never reuse the other JDK's class.
    jadx = r['jadx']; profiles = jadx['profiles']
    wanted_jadx = {j + '-' + m for j in JDKS for m in JADX_MODES}
    need(set(profiles) == wanted_jadx, label + ': exact JADX own-JDK profile matrix missing/extra')
    version = get_command(jadx['version_command'])
    need(version['argv'] == [config['jadx'], '--version'] and version['exit_code'] == jadx['version_exit'] == 0,
         label + ': JADX version command differs/failed')
    need(sha(raws[version['label']][0]) == jadx['version_stdout_sha256'] and sha(raws[version['label']][1]) == jadx['version_stderr_sha256'],
         label + ': JADX version stream pins differ')
    jadx_rows = {x['label']: x for x in r['jadx_compile_rows']}
    need(len(jadx_rows) == len(r['jadx_compile_rows']), label + ': duplicate JADX compile cells')
    expected_jadx_rows = set(); comparisons = []
    for key, profile in profiles.items():
        jdk, mode = key.split('-')
        need(profile.get('input_class_jdk') == jdk and profile.get('compile_run_jdk') == jdk and profile.get('execution_jdk') == 'javac23' and profile.get('profile') == mode,
             label + ': JADX input/execution/compiler JDK binding differs ' + key)
        command = get_command(profile['command']); jar = checked_pin(profile['input_jar'], label + ' JADX input jar ' + key)
        with zipfile.ZipFile(jar) as archive:
            need(archive.namelist() == [expected_class.replace('.', '/') + '.class'], label + ': JADX jar class inventory differs ' + key)
            need(archive.read(expected_class.replace('.', '/') + '.class') == original_paths[jdk].read_bytes(), label + ': JADX jar is not own-JDK original class ' + key)
        argv = [config['jadx'], '--no-res', '--config', 'none', '--threads-count', '1']
        if mode == 'none': argv += ['--rename-flags', 'none']
        dest = capture / 'jadx' / jdk / mode
        argv += ['-d', str(dest), str(jar)]
        need(command['argv'] == argv and command['exit_code'] == profile['exit_code'], label + ': JADX renderer argv/exit differs ' + key)
        source_files = sorted(dest.rglob('*.java'))
        metas = profile['sources']
        need([str(x.resolve()) for x in source_files] == [str(pathlib.Path(x['path']).resolve()) for x in metas], label + ': JADX source inventory differs ' + key)
        for meta in metas: checked_pin(meta, label + ' JADX source ' + key)
        names = [x.name for x in source_files]
        packages = []
        for path in source_files:
            match = re.search(r'(?m)^\s*package\s+([\w.]+)\s*;', path.read_text())
            packages.append(match.group(1) if match else None)
        exact = names == [expected_file] and packages == ['cf11']
        need(profile['names'] == names and profile['packages'] == packages and profile['exact_target_sources'] is exact,
             label + ': JADX source scope record differs ' + key)
        name = jdk + '-jadx-' + mode
        if exact:
            expected_jadx_rows.add(name)
            row = jadx_rows[name]
            for meta in row['source_pins']:
                if pathlib.Path(meta['path']).name != 'Runner.java':
                    need(len(metas) == 1 and meta['sha256'] == metas[0]['sha256'] and meta['bytes'] == metas[0]['bytes'],
                         label + ': JADX compiler source modified ' + key)
            oracle, _ = compile_row(row, oracles[jdk], strict=False)
            if row['compile_exit'] == 0:
                need(row['class_paths'] == class_sets[jdk] and row['class_set_exact'] is True, label + ': JADX full class set differs ' + key)
            comparisons.append({'cell': key, 'compile_exit': row['compile_exit'], 'runtime': 'matches-original' if oracle is not None else 'no-runtime'})
        else:
            need(name not in jadx_rows and not any(c['label'].startswith(name + '-run') for c in commands),
                 label + ': missing/incorrect JADX source must have no-runtime ' + key)
            comparisons.append({'cell': key, 'render_exit': profile['exit_code'], 'runtime': 'no-runtime', 'reason': 'no-exact-target-source-set'})
    need(set(jadx_rows) == expected_jadx_rows, label + ': JADX compile matrix missing/extra')
    # Validate javap streams and their exact corresponding own-JDK original input.
    need(sorted((x['jdk'], x['class']) for x in r['javap']) == sorted((j, expected_class) for j in JDKS), label + ': original javap matrix differs')
    for entry in r['javap']:
        jdk = entry['jdk']; command = get_command(entry['command']); argv = command['argv']
        check_tool(argv[0], jm, jdk, 'javap', label + ' javap')
        need(argv[1:] == ['-p', '-c', '-s', '-v', '-classpath', str(original_paths[jdk].parent.parent), expected_class] and command['exit_code'] == 0,
             label + ': javap own-JDK arguments/status differs')
        path = checked_pin(entry['stdout_pin'], label + ' javap stdout')
        need(path.read_bytes() == raws[command['label']][0] and sha(raws[command['label']][1]) == entry['stderr_sha256'], label + ': javap raw stream differs')
    need(set(cmap) == used, label + ': unaccounted/missing commands ' + repr(sorted(set(cmap)-used)))
    return {'family': family, 'debug': debug, 'capture': str(capture), 'receipt': pin(capture / 'execution.json'),
            'cli_sha256': r['cli']['sha256'], 'build_receipt_sha256': r['build_receipt']['sha256'],
            'source_tool_pins': before, 'original_runtime': runtime, 'jarde': details, 'jadx': comparisons,
            '_oracles': oracles}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture', action='append', required=True, metavar='FAMILY:DEBUG:DIRECTORY')
    parser.add_argument('--out', type=pathlib.Path, required=True)
    parser.add_argument('--repo-root', type=pathlib.Path, default=DEFAULT_ROOT)
    parser.add_argument('--baseline-reference', type=pathlib.Path, default=DEFAULT_REFERENCE)
    args = parser.parse_args(); out = args.out.resolve()
    if out.exists(): raise SystemExit('refuse overwrite: ' + str(out))
    captures = {}
    for value in args.capture:
        family, debug, directory = value.split(':', 2)
        if family not in ('baseline', 'admission') or debug not in ('debug', 'none'):
            raise SystemExit('invalid capture family/debug: ' + value)
        if (family, debug) in captures: raise SystemExit('duplicate capture: ' + value)
        captures[(family, debug)] = pathlib.Path(directory)
    if set(captures) != {(f, d) for f in ('baseline', 'admission') for d in ('debug', 'none')}:
        # Debug compiler modes are independent of Jarde evidence modes.
        raise SystemExit('exact baseline/admission x debug/none captures required')
    results = []; hash_dependency = None
    try:
        hash_dependency = blake3_dependency()
        decode = load_decoder(args.baseline_reference.resolve())
        for (family, debug), capture in sorted(captures.items()):
            try:
                results.append(audit_capture(family, debug, capture, args.repo_root.resolve(), args.baseline_reference.resolve(), decode))
            except Exception as exc:
                errors.append(f'{family}/{debug}: unreadable/incomplete capture: {type(exc).__name__}: {exc}')
        need(len(results) == 4, 'four complete captures did not finish independent audit')
        if len(results) == 4:
            need(len({r['cli_sha256'] for r in results}) == 1 and len({r['build_receipt_sha256'] for r in results}) == 1,
                 'four captures do not share one frozen candidate CLI/build receipt')
            for family in ('baseline', 'admission'):
                rows = [r for r in results if r['family'] == family]
                need(rows[0]['_oracles'] == rows[1]['_oracles'], family + ': debug/none original runtime bytes differ')
            for result in results: result.pop('_oracles')
    except Exception as exc:
        errors.append('audit preparation failed: ' + type(exc).__name__ + ': ' + str(exc))
    if hash_dependency is not None:
        need(hash_dependency == blake3_dependency(), 'BLAKE3 dependency code changed during audit')
    for result in results: result.pop('_oracles', None)
    report = {'schema': 'ordinary-try-list-independent-candidate-audit-v1',
              'status': 'accepted' if not errors else 'rejected',
              'audited_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'auditor': pin(__file__), 'hash_dependency': hash_dependency, 'accepted_baseline_reference': str(args.baseline_reference.resolve()),
              'scope': {'required_captures': 4, 'required_Jarde_render_cells': 16,
                        'required_Jarde_compile_run_cells': 16, 'original_baseline_rows': 45,
                        'original_admission_rows': 33, 'JADX_compile_failure': 'no-runtime only'},
              'errors': errors, 'captures': results}
    out.mkdir(parents=True)
    (out / 'audit.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({'status': report['status'], 'error_count': len(errors), 'report': str(out / 'audit.json')}, ensure_ascii=False))
    return 0 if not errors else 1


if __name__ == '__main__':
    raise SystemExit(main())
