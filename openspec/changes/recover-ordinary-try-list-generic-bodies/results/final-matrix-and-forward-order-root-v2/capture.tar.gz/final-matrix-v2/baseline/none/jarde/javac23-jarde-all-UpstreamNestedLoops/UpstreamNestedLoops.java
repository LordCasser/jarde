// jarde: presentation of `cf11/UpstreamNestedLoops` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf11;

public class UpstreamNestedLoops extends java.lang.Object {
    public static int effects;

    public UpstreamNestedLoops() {
        // @method <init>()V
        // @declaration a constructor of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public void test(java.util.List<java.lang.String> arg1, java.util.List<java.lang.String> arg2) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method test(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    java.lang.String local4;
                    java.util.Iterator local5;
                    for (java.lang.Object iteratorElement17 : arg1) {
                        local4 = (java.lang.String) iteratorElement17;
                        for (java.lang.Object iteratorElement47 : arg2) {
                            java.lang.String local6 = (java.lang.String) iteratorElement47;
                            if (local4.equals((java.lang.Object) local6)) {
                                if (local4.length() == 5) {
                                    arg2.add(local4);
                                } else {
                                    arg1.remove((java.lang.Object) local6);
                                }
                            }
                        }
                    }
                    if (arg2.size() > 0) {
                        arg1.clear();
                    }
                    return;
    }

    public void renamed(java.util.List<java.lang.String> arg1, java.util.List<java.lang.String> arg2) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method renamed(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    java.lang.String local4;
                    java.util.Iterator local5;
                    for (java.lang.Object iteratorElement17 : arg1) {
                        local4 = (java.lang.String) iteratorElement17;
                        for (java.lang.Object iteratorElement47 : arg2) {
                            java.lang.String local6 = (java.lang.String) iteratorElement47;
                            if (local4.equals((java.lang.Object) local6)) {
                                if (local4.length() == 5) {
                                    arg2.add(local4);
                                } else {
                                    arg1.remove((java.lang.Object) local6);
                                }
                            }
                        }
                    }
                    if (arg2.size() > 0) {
                        arg1.clear();
                    }
                    return;
    }

    public void numbers(java.util.List<java.lang.Integer> arg1, java.util.List<java.lang.Integer> arg2) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/Integer;>;Ljava/util/List<Ljava/lang/Integer;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method numbers(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    java.lang.Integer local4;
                    java.util.Iterator local5;
                    for (java.lang.Object iteratorElement17 : arg1) {
                        local4 = (java.lang.Integer) iteratorElement17;
                        for (java.lang.Object iteratorElement47 : arg2) {
                            java.lang.Integer local6 = (java.lang.Integer) iteratorElement47;
                            if (local4.equals((java.lang.Object) local6)) {
                                if (local4.intValue() == 5) {
                                    arg2.add(local4);
                                } else {
                                    arg1.remove((java.lang.Object) local6);
                                }
                            }
                        }
                    }
                    if (arg2.size() > 0) {
                        arg1.clear();
                    }
                    return;
    }

    // jarde: generic Signature projection refused for `castBoundary(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    public void castBoundary(java.util.List arg1, java.util.List arg2) {
        // @method castBoundary(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        java.util.Iterator local3;
        local3 = arg1.iterator();
        java.lang.String local5;
        java.util.Iterator local6;
        while (local3.hasNext()) {
            java.lang.Object local4 = local3.next();
            local5 = (java.lang.String) local4;
            local6 = arg2.iterator();
            while (local6.hasNext()) {
                java.lang.Object local7 = local6.next();
                java.lang.String local8 = (java.lang.String) local7;
                if (local5.equals((java.lang.Object) local8)) {
                    arg2.add((java.lang.Object) local5);
                    cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
                }
            }
        }
        return;
    }

    public void rawLists(java.util.List arg1, java.util.List arg2) {
        // @method rawLists(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        java.util.Iterator local3;
        local3 = arg1.iterator();
        java.lang.Object local4;
        java.util.Iterator local5;
        while (local3.hasNext()) {
            local4 = local3.next();
            local5 = arg2.iterator();
            while (local5.hasNext()) {
                java.lang.Object local6 = local5.next();
                if (local4.equals(local6)) {
                    arg2.add(local4);
                    arg1.remove(local6);
                    arg1.remove(0);
                    cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
                }
            }
        }
        return;
    }

    // jarde: generic Signature projection refused for `rawAliasEscape(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    public void rawAliasEscape(java.util.List arg1, java.util.List arg2) {
        // @method rawAliasEscape(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        java.util.List local3;
        java.util.Iterator local4;
        local3 = arg1;
        local4 = arg2.iterator();
        while (local4.hasNext()) {
            java.lang.Integer local5 = (java.lang.Integer) local4.next();
            local3.add((java.lang.Object) local5);
        }
        local4 = arg1.iterator();
        while (local4.hasNext()) {
            java.lang.String local5_2 = (java.lang.String) local4.next();
            cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
        }
        return;
    }

    // jarde: generic Signature projection refused for `reassigned(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public void reassigned(java.util.List arg1, java.util.List arg2) {
        // @method reassigned(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        arg1 = arg2;
        for (java.lang.Object iteratorElement19 : arg1) {
            java.lang.String local4 = (java.lang.String) iteratorElement19;
            arg2.add((java.lang.Object) local4);
            cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
        }
        return;
    }

    // jarde: generic Signature projection refused for `wildcardNull(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    public void wildcardNull(java.util.List arg1, java.util.List arg2) {
        // @method wildcardNull(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        for (java.lang.Object iteratorElement17 : arg1) {
            java.lang.Number local4 = (java.lang.Number) iteratorElement17;
            arg1.add((java.lang.Object) null);
            arg2.add((java.lang.Object) local4);
            cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
        }
        return;
    }

    public void handled(java.util.List<java.lang.String> arg1, java.util.List<java.lang.String> arg2) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method handled(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        for (java.lang.Object iteratorElement17 : arg1) {
                            java.lang.String local4 = (java.lang.String) iteratorElement17;
                            arg2.add(local4);
                            cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
                        }
                    } catch (java.lang.RuntimeException local3) {
                        cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
                    }
                    return;
    }

    // jarde: generic Signature projection refused for `indexOverload(Ljava/util/List;Ljava/util/List;Ljava/lang/Integer;I)V`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    public void indexOverload(java.util.List arg1, java.util.List arg2, java.lang.Integer arg3, int arg4) {
        // @method indexOverload(Ljava/util/List;Ljava/util/List;Ljava/lang/Integer;I)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        arg1.remove((java.lang.Object) arg3);
        arg1.remove(arg4);
        arg2.add((java.lang.Object) arg3);
        cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
        return;
    }

    public void tryStringBranch(java.util.List<java.lang.String> arg1, java.util.List<java.lang.String> arg2) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method tryStringBranch(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        for (java.lang.Object iteratorElement17 : arg1) {
                            java.lang.String local4 = (java.lang.String) iteratorElement17;
                            if (local4 == null) {
                                arg2.add(null);
                            } else if (local4.length() == 0) {
                                arg2.add(local4);
    } else {
                                arg2.add(null);
    }
                            cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
                        }
                    } catch (java.lang.RuntimeException local3) {
                        cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
                    }
                    return;
    }

    public void tryIntegerBranch(java.util.List<java.lang.Integer> arg1, java.util.List<java.lang.Integer> arg2) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/Integer;>;Ljava/util/List<Ljava/lang/Integer;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method tryIntegerBranch(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        for (java.lang.Object iteratorElement17 : arg1) {
                            java.lang.Integer local4 = (java.lang.Integer) iteratorElement17;
                            if (local4 == null) {
                                arg2.add(null);
                            } else if (local4.intValue() > 0) {
                                arg2.add(local4);
    } else {
                                arg2.add(null);
    }
                            cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
                        }
                    } catch (java.lang.RuntimeException local3) {
                        cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
                    }
                    return;
    }

    public void tryStringRemovePrefix(java.util.List<java.lang.String> arg1, java.util.List<java.lang.String> arg2, java.lang.Object arg3) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method tryStringRemovePrefix(Ljava/util/List;Ljava/util/List;Ljava/lang/Object;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        arg2.remove(arg3);
                        for (java.lang.Object iteratorElement28 : arg1) {
                            java.lang.String local5 = (java.lang.String) iteratorElement28;
                            arg2.add(local5);
                            cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
                        }
                    } catch (java.lang.RuntimeException local4) {
                        cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
                    }
                    return;
    }

    public void tryStringNested(java.util.List<java.lang.String> arg1, java.util.List<java.lang.String> arg2, java.util.List<java.lang.String> arg3) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method tryStringNested(Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    try {
                        java.lang.String local5;
                        java.util.Iterator local6;
                        for (java.lang.Object iteratorElement20 : arg1) {
                            local5 = (java.lang.String) iteratorElement20;
                            for (java.lang.Object iteratorElement50 : arg2) {
                                java.lang.String local7 = (java.lang.String) iteratorElement50;
                                if (local5.equals((java.lang.Object) local7)) {
                                    arg3.add(local5);
                                }
                            }
                            cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
                        }
                    } catch (java.lang.RuntimeException local4) {
                        cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
                    }
                    return;
    }

    // jarde: generic Signature projection refused for `tryStringUnknownCall(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    public void tryStringUnknownCall(java.util.List arg1, java.util.List arg2) {
        // @method tryStringUnknownCall(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.UpstreamNestedLoops`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        try {
            for (java.lang.Object iteratorElement17 : arg1) {
                java.lang.String local4 = (java.lang.String) iteratorElement17;
                arg2.add((java.lang.Object) local4);
                observeUnknown((java.lang.Object) arg2);
            }
        } catch (java.lang.RuntimeException local3) {
            cf11.UpstreamNestedLoops.effects = cf11.UpstreamNestedLoops.effects + 1;
        }
        return;
    }

    private static void observeUnknown(java.lang.Object arg0) {
        // @method observeUnknown(Ljava/lang/Object;)V
        // @declaration a static method of `cf11.UpstreamNestedLoops`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        java.lang.System.identityHashCode(arg0);
        return;
    }
}
