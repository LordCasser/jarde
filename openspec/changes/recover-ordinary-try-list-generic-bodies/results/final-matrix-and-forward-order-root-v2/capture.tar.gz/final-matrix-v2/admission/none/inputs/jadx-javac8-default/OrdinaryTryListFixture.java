package cf11;

import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: for-condition-controls-javac8.jar:cf11/OrdinaryTryListFixture.class */
public class OrdinaryTryListFixture {
    public static int effects;

    public void renamedTry(List<String> list, List<String> list2) {
        try {
            for (String str : list) {
                if (str == null) {
                    list2.add(null);
                } else if (str.length() == 0) {
                    list2.add(str);
                } else {
                    list2.add(null);
                }
                effects++;
            }
        } catch (RuntimeException e) {
            effects++;
        }
    }

    public void stringBranch(List<String> list, List<String> list2) {
        try {
            for (String str : list) {
                if (str == null) {
                    list2.add(null);
                } else if (str.length() == 0) {
                    list2.add(str);
                } else {
                    list2.add(null);
                }
                effects++;
            }
        } catch (RuntimeException e) {
            list2.add(null);
            effects++;
        }
    }

    public void integerTry(List<Integer> list, List<Integer> list2) {
        try {
            for (Integer num : list) {
                if (num == null) {
                    list2.add(null);
                } else if (num.intValue() > 0) {
                    list2.add(num);
                } else {
                    list2.add(null);
                }
                effects++;
            }
        } catch (RuntimeException e) {
            effects++;
        }
    }

    public void nestedTry(List<String> list, List<String> list2, List<String> list3) {
        try {
            for (String str : list) {
                Iterator<String> it = list2.iterator();
                while (it.hasNext()) {
                    if (str.equals(it.next())) {
                        list3.add(str);
                    }
                }
                effects++;
            }
        } catch (RuntimeException e) {
            effects++;
        }
    }

    public void stringRemovePrefix(List<String> list, List<String> list2, Object obj) {
        try {
            list2.remove(obj);
            Iterator<String> it = list.iterator();
            while (it.hasNext()) {
                list2.add(it.next());
                effects++;
            }
        } catch (RuntimeException e) {
            effects++;
        }
    }

    public void catchVisibleIteratorGap(List<String> list, List<String> list2) {
        int i = 0;
        try {
            Iterator<String> it = list.iterator();
            i = 1;
            while (it.hasNext()) {
                list2.add(it.next());
                effects++;
            }
        } catch (RuntimeException e) {
            effects = i;
        }
    }

    public void unknownCatchUse(List<String> list, List<String> list2) {
        try {
            Iterator<String> it = list.iterator();
            while (it.hasNext()) {
                list2.add(it.next());
            }
        } catch (RuntimeException e) {
            consume(list2);
        }
    }

    private static void consume(Object obj) {
        effects += obj == null ? 0 : 1;
    }

    public void reassignedInCatch(List<String> list, List<String> list2) {
        try {
            Iterator<String> it = list.iterator();
            while (it.hasNext()) {
                list2.add(it.next());
            }
        } catch (RuntimeException e) {
            list2.add(null);
        }
    }

    public void rawAliasInCatch(List<String> list, List<String> list2) {
        try {
            Iterator<String> it = list.iterator();
            while (it.hasNext()) {
                list2.add(it.next());
            }
        } catch (RuntimeException e) {
            list2.add("polluted");
        }
    }

    public void multiCatch(List<String> list, List<String> list2) {
        try {
            Iterator<String> it = list.iterator();
            while (it.hasNext()) {
                list2.add(it.next());
            }
        } catch (IllegalArgumentException | IllegalStateException e) {
            list2.add(null);
        }
    }

    public void indexOverload(List<Integer> list, List<Integer> list2, Integer num, int i) {
        try {
            for (Integer num2 : list) {
                list.remove(num);
                list2.add(num2);
                list.remove(i);
            }
        } catch (RuntimeException e) {
            list2.add(null);
        }
    }
}
