package cf11;

import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: for-condition-controls-javac8.jar:cf11/OrdinaryTryListFixture.class */
public class OrdinaryTryListFixture {
    public static int effects;

    public void renamedTry(List<String> source, List<String> sink) {
        try {
            for (String element : source) {
                if (element == null) {
                    sink.add(null);
                } else if (element.length() == 0) {
                    sink.add(element);
                } else {
                    sink.add(null);
                }
                effects++;
            }
        } catch (RuntimeException e) {
            effects++;
        }
    }

    public void stringBranch(List<String> input, List<String> output) {
        try {
            for (String value : input) {
                if (value == null) {
                    output.add(null);
                } else if (value.length() == 0) {
                    output.add(value);
                } else {
                    output.add(null);
                }
                effects++;
            }
        } catch (RuntimeException e) {
            output.add(null);
            effects++;
        }
    }

    public void integerTry(List<Integer> selected, List<Integer> available) {
        try {
            for (Integer value : selected) {
                if (value == null) {
                    available.add(null);
                } else if (value.intValue() > 0) {
                    available.add(value);
                } else {
                    available.add(null);
                }
                effects++;
            }
        } catch (RuntimeException e) {
            effects++;
        }
    }

    public void nestedTry(List<String> source, List<String> witness, List<String> destination) {
        try {
            for (String outer : source) {
                for (String inner : witness) {
                    if (outer.equals(inner)) {
                        destination.add(outer);
                    }
                }
                effects++;
            }
        } catch (RuntimeException e) {
            effects++;
        }
    }

    public void stringRemovePrefix(List<String> input, List<String> output, Object key) {
        try {
            output.remove(key);
            for (String value : input) {
                output.add(value);
                effects++;
            }
        } catch (RuntimeException e) {
            effects++;
        }
    }

    public void catchVisibleIteratorGap(List<String> input, List<String> output) {
        int marker = 0;
        try {
            Iterator<String> cursor = input.iterator();
            marker = 1;
            while (cursor.hasNext()) {
                output.add(cursor.next());
                effects++;
            }
        } catch (RuntimeException e) {
            effects = marker;
        }
    }

    public void unknownCatchUse(List<String> input, List<String> output) {
        try {
            for (String value : input) {
                output.add(value);
            }
        } catch (RuntimeException e) {
            consume(output);
        }
    }

    private static void consume(Object value) {
        effects += value == null ? 0 : 1;
    }

    public void reassignedInCatch(List<String> input, List<String> replacement) {
        try {
            for (String value : input) {
                replacement.add(value);
            }
        } catch (RuntimeException e) {
            replacement.add(null);
        }
    }

    public void rawAliasInCatch(List<String> input, List<String> output) {
        try {
            for (String value : input) {
                output.add(value);
            }
        } catch (RuntimeException e) {
            output.add("polluted");
        }
    }

    public void multiCatch(List<String> input, List<String> output) {
        try {
            for (String value : input) {
                output.add(value);
            }
        } catch (IllegalArgumentException | IllegalStateException e) {
            output.add(null);
        }
    }

    public void indexOverload(List<Integer> values, List<Integer> witness, Integer key, int position) {
        try {
            for (Integer value : values) {
                values.remove(key);
                witness.add(value);
                values.remove(position);
            }
        } catch (RuntimeException e) {
            witness.add(null);
        }
    }
}
