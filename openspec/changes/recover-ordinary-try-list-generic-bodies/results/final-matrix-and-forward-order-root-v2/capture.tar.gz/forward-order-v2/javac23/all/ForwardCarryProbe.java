// jarde: presentation of `cf11/ForwardCarryProbe` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf11;

public final class ForwardCarryProbe extends java.lang.Object {
    public static int effects;

    public static int mutationCalls;

    public static int producerCalls;

    public static int armCalls;

    public static int otherCalls;

    public static int conditionCalls;

    public static java.lang.String trace;

    private ForwardCarryProbe() {
        // @method <init>()V
        // @declaration a constructor of `cf11.ForwardCarryProbe`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static void reset() {
        // @method reset()V
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        cf11.ForwardCarryProbe.effects = 0;
        cf11.ForwardCarryProbe.mutationCalls = 0;
        cf11.ForwardCarryProbe.producerCalls = 0;
        cf11.ForwardCarryProbe.armCalls = 0;
        cf11.ForwardCarryProbe.otherCalls = 0;
        cf11.ForwardCarryProbe.conditionCalls = 0;
        cf11.ForwardCarryProbe.trace = "";
        return;
    }

    public static int mutate() {
        // @method mutate()I
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        cf11.ForwardCarryProbe.mutationCalls = cf11.ForwardCarryProbe.mutationCalls + 1;
        cf11.ForwardCarryProbe.trace = new java.lang.StringBuilder().append(cf11.ForwardCarryProbe.trace).append("M").toString();
        cf11.ForwardCarryProbe.effects = 100;
        return 1;
    }

    public static void compoundCarry(boolean flag) {
        // @method compoundCarry(Z)V
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int saved0 = cf11.ForwardCarryProbe.effects;
        cf11.ForwardCarryProbe.effects = saved0 + (flag ? mutate() : 1);
        return;
    }

    public static int lengthArm() {
        // @method lengthArm()I
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        cf11.ForwardCarryProbe.armCalls = cf11.ForwardCarryProbe.armCalls + 1;
        cf11.ForwardCarryProbe.trace = new java.lang.StringBuilder().append(cf11.ForwardCarryProbe.trace).append("A").toString();
        return 1;
    }

    public static int lengthBeforeConditional(int[] values, boolean flag) {
        // @method lengthBeforeConditional([IZ)I
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int saved0 = values.length;
        return saved0 + (flag ? lengthArm() : 1);
    }

    public static int get() {
        // @method get()I
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        cf11.ForwardCarryProbe.producerCalls = cf11.ForwardCarryProbe.producerCalls + 1;
        cf11.ForwardCarryProbe.trace = new java.lang.StringBuilder().append(cf11.ForwardCarryProbe.trace).append("G").toString();
        return 5;
    }

    public static int armEffect() {
        // @method armEffect()I
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        cf11.ForwardCarryProbe.armCalls = cf11.ForwardCarryProbe.armCalls + 1;
        cf11.ForwardCarryProbe.trace = new java.lang.StringBuilder().append(cf11.ForwardCarryProbe.trace).append("A").toString();
        return 2;
    }

    public static int plainOther() {
        // @method plainOther()I
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        cf11.ForwardCarryProbe.otherCalls = cf11.ForwardCarryProbe.otherCalls + 1;
        cf11.ForwardCarryProbe.trace = new java.lang.StringBuilder().append(cf11.ForwardCarryProbe.trace).append("B").toString();
        return 3;
    }

    public static int producerPlusFlag(boolean flag) {
        // @method producerPlusFlag(Z)I
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int saved0 = get();
        return saved0 + (flag ? armEffect() : plainOther());
    }

    public static boolean testFlag(boolean flag) {
        // @method testFlag(Z)Z
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        cf11.ForwardCarryProbe.conditionCalls = cf11.ForwardCarryProbe.conditionCalls + 1;
        cf11.ForwardCarryProbe.trace = new java.lang.StringBuilder().append(cf11.ForwardCarryProbe.trace).append("T").toString();
        return flag;
    }

    public static int producerPlusObservedTest(boolean flag) {
        // @method producerPlusObservedTest(Z)I
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int saved0 = get();
        return saved0 + (testFlag(flag) ? armEffect() : plainOther());
    }

    public static int mutateThenThrowRuntime() {
        // @method mutateThenThrowRuntime()I
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        cf11.ForwardCarryProbe.mutationCalls = cf11.ForwardCarryProbe.mutationCalls + 1;
        cf11.ForwardCarryProbe.trace = new java.lang.StringBuilder().append(cf11.ForwardCarryProbe.trace).append("R").toString();
        cf11.ForwardCarryProbe.effects = 100;
        throw new java.lang.IllegalStateException("runtime-probe");
    }

    public static int mutateThenThrowError() {
        // @method mutateThenThrowError()I
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        cf11.ForwardCarryProbe.mutationCalls = cf11.ForwardCarryProbe.mutationCalls + 1;
        cf11.ForwardCarryProbe.trace = new java.lang.StringBuilder().append(cf11.ForwardCarryProbe.trace).append("E").toString();
        cf11.ForwardCarryProbe.effects = 200;
        throw new java.lang.AssertionError((java.lang.Object) "error-probe");
    }

    public static void compoundRuntimeRhs(boolean flag) {
        // @method compoundRuntimeRhs(Z)V
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int saved0 = cf11.ForwardCarryProbe.effects;
        cf11.ForwardCarryProbe.effects = saved0 + (flag ? mutateThenThrowRuntime() : 1);
        return;
    }

    public static void compoundErrorRhs(boolean flag) {
        // @method compoundErrorRhs(Z)V
        // @declaration a static method of `cf11.ForwardCarryProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int saved0 = cf11.ForwardCarryProbe.effects;
        cf11.ForwardCarryProbe.effects = saved0 + (flag ? mutateThenThrowError() : 1);
        return;
    }
}
