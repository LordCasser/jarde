from pathlib import Path
import json,importlib.util,hashlib,os
B=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');ROOT=Path('/home/lordcasser/workspace/projects/jarde');O=B/'carry-billing-remeasure-v1';O.mkdir()
def pin(p):return {'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
s=importlib.util.spec_from_file_location('guard',B/'tools-prep/guard.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g);g.OUT=O;g.command_stream=pin;g.expected_test_summaries=lambda *a:None
env=os.environ.copy()
for k in [*g.STRIPPED_ENV_KEYS,'RUST_MIN_STACK','CARGO_TARGET_DIR']:env.pop(k,None)
env.update(g.ENV_VALUES);env['RUSTUP_TOOLCHAIN']='stable';rows=[];rec={'status':'running','commands':rows,'before_test_source':pin(ROOT/'tests/p5_bulk_corpus.rs'),'runner':pin(Path(__file__))}
def save():(O/'execution.json').write_text(json.dumps(rec,indent=2)+'\n')
try:
 row=g.run_command(1,['cargo','test','-p','jarde','--test','p5_bulk_corpus','--all-features','--locked','--','--ignored','--exact','record_the_billing_table','--nocapture'],env);rows.append(row);save();assert row['exit_code']==0 and row['guard_stop'] is None;rec['status']='remeasured_pending_independent_review'
except BaseException as e:rec['status']='failed';rec['error']=repr(e);raise
finally:
 g.FREE_LIMIT=0;g.TARGET_LIMIT=2**63-1;row=g.run_command(len(rows)+1,['cargo','clean'],env);rows.append(row);rec['target_absent']=not (ROOT/'target').exists();rec['after_test_source']=pin(ROOT/'tests/p5_bulk_corpus.rs');save()
