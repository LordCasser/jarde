from pathlib import Path
import importlib.util,json,os,hashlib
B=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');ROOT=Path('/home/lordcasser/workspace/projects/jarde');O=B/'carry-final-controls-v1';O.mkdir()
def pin(p):return {'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
f=json.loads((B/'focused-v17/execution.json').read_text());cli=Path(f['cli']['path']);assert pin(cli)==f['cli']
s=importlib.util.spec_from_file_location('guard',B/'tools-prep/guard.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g);g.OUT=O;g.command_stream=pin;g.expected_test_summaries=lambda *a:None
env=os.environ.copy()
for k in [*g.STRIPPED_ENV_KEYS,'RUST_MIN_STACK','CARGO_TARGET_DIR']:env.pop(k,None)
rows=[];pairs=[];record={'status':'running','commands':rows,'pairs':pairs,'final_cli':f['cli'],'runner':pin(Path(__file__))}
def save():(O/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
try:
 for kind,paths in [('ICN',[ROOT/'tests/fixtures/recover-inline-conditional-concat-operands/v8/ICN.class',ROOT/'tests/fixtures/recover-inline-conditional-concat-operands/v8-javac8/ICN.class']),('BI',[ROOT/'tests/fixtures/recover-conditional-rhs-field-compound/v8/BI.class',ROOT/'tests/fixtures/recover-conditional-rhs-field-compound/v8-javac8/BI.class',B/'bi-original-jar-input-v1/BI.class'])]:
  for p in paths:
   for mode in ['default','all']:
    docs=[]
    for binary in [B/'candidate-cli-v6',cli]:
     argv=[str(binary),'class-source','--input',str(p),'--class',kind,'--policy','single-class','--release','8','--format','json']
     if mode=='all':argv+=['--evidence','all']
     row=g.run_command(len(rows)+1,argv,env);row['input']=pin(p);row['binary']=pin(binary);rows.append(row);save();assert row['exit_code']==0 and row['guard_stop'] is None
     assert Path(row['streams']['stderr']['path']).read_bytes()==b''
     docs.append(json.loads(Path(row['streams']['stdout']['path']).read_text()))
    def signature(d):return [(m['item']['identity'],m['outcome']['report']['representation'],m['outcome']['report']['quality'],m['outcome']['report']['text'],m['outcome']['report']['source_map']) for m in d['methods']]
    assert docs[0]['text']==docs[1]['text'] and signature(docs[0])==signature(docs[1]) and docs[0]['class']['class_bytes']==docs[1]['class']['class_bytes']
    pairs.append({'kind':kind,'input':pin(p),'evidence':mode,'text_maps_quality_identity':'equal'});save()
 record['status']='accepted_current_controls_only'
except BaseException as e:record['status']='failed';record['error']=repr(e);raise
finally:record['target_absent']=not (ROOT/'target').exists();save()
print(record['status'],len(rows))
