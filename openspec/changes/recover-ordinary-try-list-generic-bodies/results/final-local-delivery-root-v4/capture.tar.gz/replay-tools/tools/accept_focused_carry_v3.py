import argparse,json,hashlib,re,os
from pathlib import Path
ROOT=Path('/home/lordcasser/workspace/projects/jarde')
def pin(p):
 p=Path(p);return {'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
a=argparse.ArgumentParser();a.add_argument('--capture',type=Path,required=True);args=a.parse_args();out=args.capture/'protocol-review.json';assert not out.exists()
d=json.loads((args.capture/'execution.json').read_text());errors=[];checks=[]
def check(v,s):
 checks.append(s)
 if not v:errors.append(s)
def verify(v,s,source=False):
 p=ROOT/v['path'] if source else Path(v['path']);actual=pin(p)
 check(actual['bytes']==v['bytes'] and actual['sha256']==v['sha256'],s)
check(d['status']=='commands_passed_pending_independent_acceptance','finished status')
check(d['default_stack'] and d['environment']['RUST_MIN_STACK'] is None,'default stack')
check(d['source_manifest_before']==d['source_manifest_after'],'source closure before/after')
for v in d['source_manifest_before']:verify(v,'source/'+v['path'],True)
for k,v in d['dependencies'].items():verify(v,'dependency/'+k)
verify(d['runner'],'runner');check(d['runner']==d['runner_after'],'runner unchanged');verify(d['cli'],'frozen CLI')
check(os.stat(d['cli']['path']).st_mode&0o777==0o555,'immutable CLI mode')
check(d['target_absent'] and not (ROOT/'target').exists(),'finally target absent')
spec=json.loads(Path(d['command_spec']['path']).read_text());verify(d['command_spec'],'command spec')
check([r['argv'] for r in d['commands']]==spec+[['cargo','clean']],'all exact argv and finally clean')
summaries=[]
for row in d['commands']:
 check(row['exit_code']==0 and row['guard_stop'] is None,row['label']+'/exit guard')
 check(row['peak_target_bytes']<=1024**3,row['label']+'/target cap')
 for k,v in row['streams'].items():verify(v,row['label']+'/'+k)
 raw=Path(row['streams']['stdout']['path']).read_text(errors='replace')
 actual=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)
 if 'actual_test_summaries' in row:
  check([list(x) for x in actual]==row['actual_test_summaries'],row['label']+'/actual summaries')
  check(all(x[0]=='ok' and int(x[2])==0 for x in actual),row['label']+'/no failed tests')
  named=re.findall(r'^test (.+) \.\.\. (ok|ignored|FAILED)(?:, .*)?$',raw,re.M)
  check(sum(s=='ok' for _,s in named)==sum(int(x[1]) for x in actual),row['label']+'/named passes')
  check(sum(s=='ignored' for _,s in named)==sum(int(x[3]) for x in actual),row['label']+'/named ignored')
  summaries+=actual
java=next(r for r in d['commands'] if r['label']=='jarde-java-lib');public=next(r for r in d['commands'] if r['label']=='public-list-and-reference-regressions')
check('failed_forward_carry_declarations_restore_the_original_whole_value_refusal ... ok' in Path(java['streams']['stdout']['path']).read_text(),'actual three bind failure and preparation stop controls')
check('forward_carry_saves_reference_dependencies_before_the_condition ... ok' in Path(public['streams']['stdout']['path']).read_text(),'actual both physical compiler classes public regression')
check('failed_carry_receiver_assignment_keeps_the_primary_and_quotes_the_whole_method ... ok' in Path(public['streams']['stdout']['path']).read_text(),'actual physical rejected dependency primary/whole map/ExplanationOnly control')
bulk=next(r for r in d['commands'] if r['label']=='bulk-corpus-billing')
check('the_fixed_shape_bills_the_counts_the_corpus_pins ... ok' in Path(bulk['streams']['stdout']['path']).read_text(),'actual fixed bulk billing gate')
check('the_old_per_method_arms_keep_their_ledger_and_the_same_text ... ok' in Path(bulk['streams']['stdout']['path']).read_text(),'actual direct/shared billing and text gate')
report={'status':'accepted' if not errors else 'rejected','auditor':pin(__file__),'receipt':pin(args.capture/'execution.json'),'errors':errors,'checks':len(checks),'source_files':len(d['source_manifest_before']),'commands':len(d['commands']),'raw_streams':2*len(d['commands']),'totals':{'passed':sum(int(x[1]) for x in summaries),'failed':sum(int(x[2]) for x in summaries),'ignored':sum(int(x[3]) for x in summaries)},'scope':'local focused source/raw/CLI protocol only; no claim of exact online CI toolchain'}
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));raise SystemExit(bool(errors))
