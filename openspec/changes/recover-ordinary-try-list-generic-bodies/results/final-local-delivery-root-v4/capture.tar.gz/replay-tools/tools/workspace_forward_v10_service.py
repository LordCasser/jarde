from pathlib import Path
import os,subprocess,json,hashlib
B=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
ROOT=Path('/home/lordcasser/workspace/projects/jarde')
assert not (ROOT/'target').exists()
for p in [B/'focused-v19/protocol-review.json',B/'carry-dependency-restoration-v1/root-audit.json',B/'carry-dependency-refusal-v1/root-audit-v2.json',B/'forward-order-v4/root-audit.json',B/'final-matrix-v4/root-audit-v2/audit.json']:
 assert json.loads(p.read_text())['status']=='accepted',str(p)
f17=json.loads((B/'focused-v17/execution.json').read_text());f18=json.loads((B/'focused-v19/execution.json').read_text());assert (f17['cli']['bytes'],f17['cli']['sha256'])==(f18['cli']['bytes'],f18['cli']['sha256'])
e=os.environ.copy()
e=os.environ.copy();e["PATH"]='/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/java25-javac23-bin:/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jdk23/jdk-23.0.1/bin:/home/lordcasser/.local/bin:/home/lordcasser/bin:/home/lordcasser/.cargo/bin:/home/lordcasser/.nix-profile/bin:/nix/var/nix/profiles/default/bin:/usr/local/bin:/usr/bin:/home/lordcasser/.codex/tmp/arg0/codex-arg0z2vfe5:/home/lordcasser/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override:/home/lordcasser/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback:/usr/lib/chatgpt/resources'
a=['python3',str(B/'tools-prep/workspace_runner_forward_v5.py')]
for key,p in [('focused-receipt',B/'focused-v19/execution.json'),('runtime-debug-receipt',B/'final-matrix-v4/baseline/debug/execution.json'),('runtime-none-receipt',B/'final-matrix-v4/baseline/none/execution.json')]:a+=['--'+key,str(p),'--'+key+'-sha256',hashlib.sha256(p.read_bytes()).hexdigest()]
a+=['--out',str(B/'workspace-forward-v10')]
launch=B/'workspace-forward-v10-launch';launch.mkdir()
(launch/'process.json').write_text(json.dumps({'pid':os.getpid(),'argv':a,'PATH':e['PATH'],'manager':'systemd user service'},indent=2)+'\n')
r=subprocess.run(a,env=e,cwd=ROOT)
if r.returncode:raise SystemExit(r.returncode)
r=subprocess.run(['python3',str(B/'tools/post_workspace_forward_v6.py')],env=e,cwd=ROOT)
raise SystemExit(r.returncode)
