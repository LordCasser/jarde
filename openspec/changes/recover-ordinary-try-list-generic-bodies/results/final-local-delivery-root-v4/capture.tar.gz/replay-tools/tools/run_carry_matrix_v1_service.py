from pathlib import Path
import subprocess,json,os,datetime,hashlib
B=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');ROOT=Path('/home/lordcasser/workspace/projects/jarde');O=B/'carry-matrix-v1-service';O.mkdir()
py=Path('/home/lordcasser/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3')
args=[
 ['python3',str(B/'tools/run_carry_final_controls_v1.py')],
 ['python3',str(B/'tools/run_forward_order.py'),'--version','v17','--out',str(B/'forward-order-v4')],
 [str(py),str(B/'tools-prep/audit_forward_order_root_v2.py'),'--capture',str(B/'forward-order-v4'),'--out',str(B/'forward-order-v4/root-audit.json')],
 ['python3',str(B/'tools/run_matrix_v5.py')],
 [str(py),str(B/'review/audit_candidate.py'),*sum((['--capture',f'{f}:{d}:{B/"final-matrix-v4"/f/d}'] for f in ['baseline','admission'] for d in ['debug','none']),[]),'--out',str(B/'final-matrix-v4/root-audit')],
]
rows=[];record={'status':'running','pid':os.getpid(),'manager':'systemd user service','commands':rows}
def save():(O/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
try:
 for n,argv in enumerate(args,1):
  before=datetime.datetime.now(datetime.timezone.utc).isoformat();stdout=O/f'{n}.stdout.raw';stderr=O/f'{n}.stderr.raw';save()
  with stdout.open('xb') as so,stderr.open('xb') as se:r=subprocess.run(argv,cwd=ROOT,stdout=so,stderr=se)
  rows.append({'argv':argv,'started_at':before,'exit_code':r.returncode,'streams':{'stdout':pin(stdout),'stderr':pin(stderr)}});save()
  if r.returncode:raise RuntimeError(f'command {n} failed: {r.returncode}')
 record['status']='commands_complete_pending_root_review'
except BaseException as e:record['status']='failed';record['error']=repr(e);raise
finally:record['target_absent']=not (ROOT/'target').exists();save()
