from pathlib import Path
import json,subprocess,time,hashlib
B=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');O=B/'own-ci-f014-root-v1';O.mkdir(exist_ok=False)
GH='/home/lordcasser/.local/bin/gh';RUN=38528929839;SHA='f01402867ffa20085e421a680a6ebbe878e63338'
rows=[]
def get(endpoint,name):
 c=subprocess.run([GH,'api',endpoint],capture_output=True)
 (O/(name+'.stdout.raw')).write_bytes(c.stdout);(O/(name+'.stderr.raw')).write_bytes(c.stderr)
 rows.append({'endpoint':endpoint,'exit_code':c.returncode,'streams':{k:{'path':str(O/(name+'.'+k+'.raw')),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()} for k,z in [('stdout',c.stdout),('stderr',c.stderr)]}})
 assert c.returncode==0,(name,c.stderr.decode())
 return c.stdout
idx=0
while True:
 run=json.loads(get(f'repos/LordCasser/jarde/actions/runs/{RUN}',f'{idx}-run'))
 jobs=json.loads(get(f'repos/LordCasser/jarde/actions/runs/{RUN}/jobs?per_page=100',f'{idx}-jobs'))
 assert run['head_sha']==SHA and run['head_branch']=='main' and run['event']=='push'
 doc={'status':'waiting','run_id':RUN,'product_sha':SHA,'run_status':run['status'],'conclusion':run.get('conclusion'),'observations':rows,'jobs':jobs['jobs']}
 (O/'execution.json').write_text(json.dumps(doc,indent=2)+'\n')
 if run['status']=='completed':break
 idx+=1;time.sleep(30)
logs=get(f'repos/LordCasser/jarde/actions/runs/{RUN}/logs','completed-log-zip')
(O/'logs.zip').write_bytes(logs)
doc.update({'status':'captured_pending_root_acceptance','logs':{'path':str(O/'logs.zip'),'bytes':len(logs),'sha256':hashlib.sha256(logs).hexdigest()}})
(O/'execution.json').write_text(json.dumps(doc,indent=2)+'\n')
assert run['conclusion']=='success', run['conclusion']
print(json.dumps({'run':RUN,'head':SHA,'conclusion':run['conclusion'],'job_count':len(jobs['jobs'])}))
