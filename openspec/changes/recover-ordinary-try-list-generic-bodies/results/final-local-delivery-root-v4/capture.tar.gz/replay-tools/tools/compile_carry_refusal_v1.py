from pathlib import Path
import json,importlib.util,hashlib,os
B=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');ROOT=Path('/home/lordcasser/workspace/projects/jarde');O=B/'carry-dependency-refusal-compile-v1';O.mkdir()
def pin(p):return {'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
s=importlib.util.spec_from_file_location('guard',B/'tools-prep/guard.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g);g.OUT=O;g.command_stream=pin;g.expected_test_summaries=lambda *a:None
env=os.environ.copy()
for k in [*g.STRIPPED_ENV_KEYS,'RUST_MIN_STACK','CARGO_TARGET_DIR']:env.pop(k,None)
rows=[];inputs=[];rec={'status':'running','commands':rows,'inputs':inputs,'runner':pin(Path(__file__))}
def save():(O/'execution.json').write_text(json.dumps(rec,indent=2)+'\n')
try:
 manifest=json.loads((B/'tools/jdk-manifest.json').read_text())
 for leg in manifest['legs']:
  name=leg['leg'];javac=leg['jdk_tools']['javac']['path'];original=B/'carry-dependency-refusal-v1'/name/'original'
  for mode in ['default','all']:
   source=B/'carry-dependency-refusal-v1'/name/mode/'CarryDependencyRefusalProbe.java';inputs.append(pin(source));classes=O/f'{name}-{mode}';classes.mkdir();empty=O/f'{name}-{mode}-empty';empty.mkdir()
   argv=[javac,'-g','-source','8','-target','8','-encoding','UTF-8','-classpath',str(original),'-sourcepath',str(empty),'-d',str(classes),str(source)]
   row=g.run_command(len(rows)+1,argv,env);row['jdk_javac']=leg['jdk_tools']['javac'];rows.append(row);save();assert row['exit_code']==1 and row['guard_stop'] is None
   text=Path(row['streams']['stderr']['path']).read_text();assert 'symbol:   method jarde_refused_body()' in text and '1 error' in text
 rec['status']='observed_expected_compile_refusals_no_runtime'
except BaseException as e:rec['status']='failed';rec['error']=repr(e);raise
finally:rec['target_absent']=not (ROOT/'target').exists();save()
