from pathlib import Path
import subprocess,hashlib,json,os,time
B=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');ROOT=Path('/home/lordcasser/workspace/projects/jarde')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(a,folder,env=None):
 folder.mkdir(exist_ok=False); c=subprocess.run(a,cwd=ROOT,env=env,stdout=open(folder/'stdout.raw','wb'),stderr=open(folder/'stderr.raw','wb'))
 (folder/'execution.json').write_text(json.dumps({'argv':a,'exit_code':c.returncode,'cwd':str(ROOT),'streams':{k:{'path':str(folder/f'{k}.raw'),'bytes':(folder/f'{k}.raw').stat().st_size,'sha256':sha(folder/f'{k}.raw')} for k in ('stdout','stderr')}},indent=2)+'\n')
 if c.returncode:raise SystemExit(c.returncode)
p=B/'workspace-forward-v9/execution.json'
while True:
 if not p.exists():
  time.sleep(20)
  continue
 d=json.loads(p.read_text())
 if d['status']!='running':break
 time.sleep(20)
assert d['status']=='passed', d.get('error')
a=['python3',str(B/'tools-prep/accept_workspace_forward_v3.py')]
for key,path in [('execution',p),('focused-receipt',B/'focused-v18/execution.json'),('runtime-debug-receipt',B/'final-matrix-v4/baseline/debug/execution.json'),('runtime-none-receipt',B/'final-matrix-v4/baseline/none/execution.json'),('tool-environment-receipt',B/'tool-environment-final-v1/execution.json')]:a+=['--'+key,str(path),'--'+key+'-sha256',sha(path)]
a+=['--metadata',str(B/'workspace-forward-v9/metadata.json'),'--out',str(B/'workspace-forward-v9/root-acceptance.json')]
run(a,B/'workspace-forward-v9-root-review');print('workspace independently accepted',flush=True)
assert not (ROOT/'target').exists()
run(['python3',str(B/'tools-prep/ci-extra-forward-v2.py'),'--out',str(B/'ci-extra-forward-v3')],B/'ci-extra-forward-v3-launch');print('CI extra observed',flush=True)
p=B/'ci-extra-forward-v3/execution.json'
run(['python3',str(B/'tools-prep/accept_ci_extra_forward_v1.py'),'--execution',str(p),'--execution-sha256',sha(p),'--runner-sha256',sha(B/'tools-prep/ci-extra-forward-v2.py'),'--out',str(B/'ci-extra-forward-v3/root-acceptance.json')],B/'ci-extra-forward-v3-root-review');print('CI extra independently accepted',flush=True)
assert not (ROOT/'target').exists()
e=os.environ.copy();o=B/'ci-tree-forward-v2';o.mkdir(exist_ok=False);e['RUNNER_TEMP']=str(o)
a=['bash',str(B/'tools-prep/ci-tree-forward-v1.sh')];c=subprocess.run(a,cwd=ROOT,env=e,stdout=open(o/'stdout.raw','wb'),stderr=open(o/'stderr.raw','wb'))
(o/'execution.json').write_text(json.dumps({'argv':a,'exit_code':c.returncode,'cwd':str(ROOT),'workflow_sha256':sha(ROOT/'.github/workflows/ci.yml'),'script_sha256':sha(B/'tools-prep/ci-tree-forward-v1.sh'),'files':{str(q.relative_to(o)):{'bytes':q.stat().st_size,'sha256':sha(q)} for q in o.iterdir() if q.is_file() and q.name!='execution.json'},'target_absent':not (ROOT/'target').exists()},indent=2)+'\n')
assert c.returncode==0 and not (ROOT/'target').exists();print('CI tree checks passed',flush=True)
