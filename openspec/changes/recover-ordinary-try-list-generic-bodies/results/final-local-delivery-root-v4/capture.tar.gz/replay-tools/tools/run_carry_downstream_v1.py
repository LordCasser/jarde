from pathlib import Path
import argparse,importlib.util,hashlib,json,os,shutil
ROOT=Path('/home/lordcasser/workspace/projects/jarde');B=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
def pin(p):return {'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
a=argparse.ArgumentParser();a.add_argument('--version',required=True);a.add_argument('--out',type=Path,required=True);args=a.parse_args();out=args.out.resolve();assert not out.exists() and not (ROOT/'target').exists();out.mkdir()
r=json.loads((B/('focused-'+args.version)/'execution.json').read_text());assert r['status']=='commands_passed_pending_independent_acceptance';cli=Path(r['cli']['path']);assert pin(cli)==r['cli']
s=importlib.util.spec_from_file_location('guard',B/'tools-prep/guard.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g);g.OUT=out;g.expected_test_summaries=lambda *a:None;g.command_stream=pin
inputs=Path('/home/lordcasser/.cache/jarde-review/20261014/carry-unproved-consumer-input-v2');sources=[inputs/'CarryUnprovedConsumerProbe.java',inputs/'Runner.java'];before=[pin(p) for p in sources];rows=[];record={'status':'running','inputs':before,'cli':pin(cli),'commands':rows,'runner':pin(Path(__file__))}
def save(): (out/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,argv,home):
 env=os.environ.copy();[env.pop(k,None) for k in (*g.STRIPPED_ENV_KEYS,'RUST_MIN_STACK','CARGO_TARGET_DIR')];env['JAVA_HOME']=str(home);env['PATH']=str(home/'bin')+os.pathsep+env.get('PATH','');row=g.run_command(len(rows)+1,list(map(str,argv)),env);row['label']=label;rows.append(row);save();assert row['exit_code']==0 and row['guard_stop'] is None,label;return Path(row['streams']['stdout']['path']).read_bytes()
try:
 manifest=json.loads((B/'tools/jdk-manifest.json').read_text())
 for leg in manifest['legs']:
  name=leg['leg'];java=leg['jdk_tools']['java']['path'];javac=leg['jdk_tools']['javac']['path'];home=Path(java).parent.parent;ld=out/name;ld.mkdir();empty=ld/'empty';empty.mkdir();original=ld/'original';original.mkdir()
  compile_args=[javac,'-g','-source','8','-target','8','-encoding','UTF-8','-classpath',empty,'-sourcepath',empty,'-d',original]
  run(name+'-original-compile',compile_args+sources,home);oracle=run(name+'-original-run',[java,'-Xverify:all','-cp',original,'Runner'],home);assert len(oracle.splitlines())==2
  for mode in ['default','all']:
   md=ld/mode;md.mkdir();argv=[cli,'class-source','--input',original/'CarryUnprovedConsumerProbe.class','--class','CarryUnprovedConsumerProbe','--policy','single-class','--release','8','--format','json'];argv+=['--evidence','all'] if mode=='all' else []
   raw=run(name+'-'+mode+'-render',argv,home);doc=json.loads(raw);target=md/'CarryUnprovedConsumerProbe.java';target.write_bytes(doc['text'].encode());(md/'document.json').write_bytes(raw);runner=md/'Runner.java';shutil.copyfile(sources[1],runner);compiled=md/'classes';compiled.mkdir();record.setdefault('generated',[]).append({'name':name+'-'+mode,'source':pin(target),'report':pin(md/'document.json')});save()
   args2=compile_args[:-1]+[compiled,target,runner];run(name+'-'+mode+'-compile',args2,home);actual=run(name+'-'+mode+'-run',[java,'-Xverify:all','-cp',compiled,'Runner'],home);assert actual==oracle,name+' '+mode
 record['status']='whole_probe_compile_runtime_matches_original'
except BaseException as e:record['status']='failed';record['error']=repr(e);raise
finally:record['inputs_after']=[pin(p) for p in sources];record['target_absent']=not (ROOT/'target').exists();save()
