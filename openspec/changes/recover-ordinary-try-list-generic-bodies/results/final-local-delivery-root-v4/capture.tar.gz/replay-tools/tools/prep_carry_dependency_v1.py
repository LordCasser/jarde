from pathlib import Path
import importlib.util,os,json,hashlib
BASE=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
ROOT=Path('/home/lordcasser/workspace/projects/jarde')
OUT=BASE/'carry-dependency-fixture-prep-v1'
OUT.mkdir()
spec=importlib.util.spec_from_file_location('guard',BASE/'tools-prep/guard.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
g.ROOT=ROOT;g.OUT=OUT;g.expected_test_summaries=lambda i,d:None
fixture=ROOT/'tests/fixtures/carry-dependency'; empty=OUT/'empty';empty.mkdir()
env=os.environ.copy()
for k in ['JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','RUST_MIN_STACK','CARGO_TARGET_DIR']:env.pop(k,None)
rows=[];oracles=[]
def run(argv):
 r=g.run_command(len(rows)+1,[str(a) for a in argv],env);rows.append(r)
 (OUT/'execution.json').write_text(json.dumps({'commands':rows},indent=2)+'\n')
 if r['exit_code'] or r['guard_stop']:raise RuntimeError(r)
 return Path(r['streams']['stdout']['path']).read_bytes()
for leg,jdk in [('javac8',BASE/'tools/jdk8/amazon-corretto-8.504.04.1-linux-x64/bin'),('javac23',BASE/'tools/jdk23/jdk-23.0.1/bin')]:
 dest=OUT/leg;dest.mkdir()
 run([jdk/'javac','-g','-source','8','-target','8','-encoding','UTF-8','-classpath',empty,'-sourcepath',empty,'-d',dest,fixture/'CarryDependencyProbe.java'])
 run([jdk/'javac','-g','-source','8','-target','8','-encoding','UTF-8','-classpath',dest,'-sourcepath',empty,'-d',dest,fixture/'Runner.java'])
 stdout=run([jdk/'java','-cp',dest,'Runner']);oracles.append(stdout)
 run([jdk/'javap','-p','-c','-v',dest/'CarryDependencyProbe.class'])
 (fixture/leg).mkdir();(fixture/leg/'CarryDependencyProbe.class').write_bytes((dest/'CarryDependencyProbe.class').read_bytes())
assert oracles[0]==oracles[1]
assert oracles[0]==b'false|8|MVT\nthis|false|8|VT\nparameter|false|8|VT\ntrue|7|MVTA\nthis|true|7|VTA\nparameter|true|7|VTA\n'
files=[]
for p in sorted(fixture.rglob('*')):
 if p.is_file() and p.suffix in ['.java','.class']:
  data=p.read_bytes();files.append({'path':p.relative_to(fixture).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(fixture/'pins.json').write_text(json.dumps({'source_level':'Java 8','compiler_flags':['-g','-source','8','-target','8','-encoding','UTF-8','-classpath','EMPTY','-sourcepath','EMPTY'],'files':files,'oracle_rows':6,'oracle_sha256':hashlib.sha256(oracles[0]).hexdigest()},indent=2)+'\n')
print(oracles[0].decode(),end='')
