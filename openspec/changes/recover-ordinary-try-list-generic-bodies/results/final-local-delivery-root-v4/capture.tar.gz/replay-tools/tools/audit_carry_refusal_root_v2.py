from pathlib import Path
import json,importlib.util,hashlib,sys
B=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');O=B/'carry-dependency-refusal-v1';sys.path.insert(0,str(B/'tools/pythonlib'))
s=importlib.util.spec_from_file_location('audit',B/'review/audit_candidate.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a);decode=a.load_decoder(B/'baseline45');d=json.loads((O/'execution.json').read_text());errors=[];checks=0

def check(v,label):
 global checks
 checks+=1
 if not v:errors.append(label)
def pin(p):return {'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for r in d['commands']:
 check(r['exit_code']==0 and r['guard_stop'] is None,'original/render exit')
 for k,v in r['streams'].items():check(pin(Path(v['path']))==v,'raw/'+r['label']+'/'+k)
check(len(d['commands'])==8,'8 original/render commands');check(d['inputs']==d['inputs_after'],'source before after')
for v in d['inputs']:check(pin(Path(v['path']))==v,'source pin')
pairs=[]
for leg in ['javac8','javac23']:
 original=a.class_file(O/leg/'original/CarryDependencyRefusalProbe.class');key='rejectedDependency(Z)V';code=original['methods'][key]['code'];physical={x[0] for x in decode(code)};docs=[]
 for mode in ['default','all']:
  doc=json.loads((O/leg/mode/'document.json').read_text());docs.append(doc);check(len(doc['methods'])==2,'complete physical class')
  member=next(m for m in doc['methods'] if a.method_identity(m)[0]==key);report=member['outcome']['report'];check(report['outcome']=='produced' and report['content']=='explanation_only','produced ExplanationOnly');check('saved producer at BCI 7 has 3 consumers' in report['text'],'primary cause retained');check('return;' not in member['text'] and 'jarde_refused_body();' in member['text'],'whole refusal marker no survivor')
  m=a.map_audit(member,original,decode,a.class_digest((O/leg/'original/CarryDependencyRefusalProbe.class').read_bytes()),leg+'/'+mode)
  check(not m['coverage_missing'] and not m['coverage_extra'],'whole physical BCI closure')
 check(docs[0]['text']==docs[1]['text'] and [(m['item']['identity'],m['outcome']['report']['text'],m['outcome']['report']['source_map'],m['outcome']['report']['content']) for m in docs[0]['methods']]==[(m['item']['identity'],m['outcome']['report']['text'],m['outcome']['report']['source_map'],m['outcome']['report']['content']) for m in docs[1]['methods']],'default/all method identity text maps')
 rows=[Path(r['streams']['stdout']['path']).read_bytes() for r in d['commands'] if r['label'].endswith('-original-run')];check(rows==[b'false|8|MVT|true\ntrue|7|MVTA|true\n']*2,'original 2 rows cross JDK')
expected_content_mismatches=[leg+'/'+mode+': raw body not produced rejectedDependency(Z)V' for leg in ['javac8','javac23'] for mode in ['default','all']]
check(a.errors==expected_content_mismatches,'only expected positive-auditor contains_statements mismatch on negative content')
c=json.loads((B/'carry-dependency-refusal-compile-v1/execution.json').read_text());check(c['status']=='observed_expected_compile_refusals_no_runtime','expected actual compile refusal')
for r in c['commands']:
 check(r['exit_code']==1 and r['guard_stop'] is None,'expected compile1')
 for k,v in r['streams'].items():check(pin(Path(v['path']))==v,'compile raw/'+k)
report={'status':'accepted' if not errors else 'rejected','errors':errors,'checks':checks,'commands':12,'raw_streams':24,'original_runtime_rows':2,'generated_runtime':'not attempted: whole method explicitly refused','auditor':pin(Path(__file__)),'positive_auditor_expected_content_mismatches':a.errors}
(O/'root-audit-v2.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));raise SystemExit(bool(errors))
