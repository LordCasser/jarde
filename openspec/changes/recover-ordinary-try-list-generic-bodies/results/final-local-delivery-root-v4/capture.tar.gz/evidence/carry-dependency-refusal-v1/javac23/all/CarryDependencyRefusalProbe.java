// jarde: presentation of `CarryDependencyRefusalProbe` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class CarryDependencyRefusalProbe extends java.lang.Object {
    public static CarryDependencyProbe receiver;

    public CarryDependencyRefusalProbe() {
        // @method <init>()V
        // @declaration a constructor of `CarryDependencyRefusalProbe`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static void rejectedDependency(boolean flag) {
        // jarde: not recovered: the recovery run for `rejectedDependency(Z)V` produced no statement (explanation only); the artifact's own comment lines are below
        // @method rejectedDependency(Z)V
        // @declaration a static method of `CarryDependencyRefusalProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 3
        // the instruction at BCI 3 belongs to no shape this run verified: an allocation, a copy or a cast is presented only where a rule proved what it builds
        // @bytecode 4 0 3 7 10 11 14 17 20 23 24 25 28
        // the copy at BCI 3 has no proved local assignment
        // @bytecode 7
        // the saved producer at BCI 7 has 3 consumers, so one local binding cannot prove its execution count
        // @bytecode 25 7
        // the value at BCI 25 was produced by a saved declaration this run could not commit
        jarde_refused_body();
    }
}
