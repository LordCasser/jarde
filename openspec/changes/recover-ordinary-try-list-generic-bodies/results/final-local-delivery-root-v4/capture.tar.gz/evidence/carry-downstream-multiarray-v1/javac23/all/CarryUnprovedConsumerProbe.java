// jarde: presentation of `CarryUnprovedConsumerProbe` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class CarryUnprovedConsumerProbe extends java.lang.Object {
    public static java.lang.String trace;

    public static int effects;

    public CarryUnprovedConsumerProbe() {
        // @method <init>()V
        // @declaration a constructor of `CarryUnprovedConsumerProbe`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static int dimension() {
        // @method dimension()I
        // @declaration a static method of `CarryUnprovedConsumerProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        CarryUnprovedConsumerProbe.trace = new java.lang.StringBuilder().append(CarryUnprovedConsumerProbe.trace).append("D").toString();
        return 1;
    }

    public static boolean test(boolean f) {
        // @method test(Z)Z
        // @declaration a static method of `CarryUnprovedConsumerProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        CarryUnprovedConsumerProbe.trace = new java.lang.StringBuilder().append(CarryUnprovedConsumerProbe.trace).append("T").toString();
        return f;
    }

    public static int arm() {
        // @method arm()I
        // @declaration a static method of `CarryUnprovedConsumerProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        CarryUnprovedConsumerProbe.trace = new java.lang.StringBuilder().append(CarryUnprovedConsumerProbe.trace).append("A").toString();
        return 2;
    }

    public static void consume(int[][] a) {
        // @method consume([[I)V
        // @declaration a static method of `CarryUnprovedConsumerProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        CarryUnprovedConsumerProbe.trace = new java.lang.StringBuilder().append(CarryUnprovedConsumerProbe.trace).append("C").toString();
        CarryUnprovedConsumerProbe.effects = a.length * 100 + a[0].length;
        return;
    }

    public static void candidate(boolean f) {
        // @method candidate(Z)V
        // @declaration a static method of `CarryUnprovedConsumerProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int saved0 = dimension();
        consume(new int[saved0][test(f) ? arm() : 3]);
        return;
    }

    static {
        // @method <clinit>()V
        // @declaration a static initializer of `CarryUnprovedConsumerProbe`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        CarryUnprovedConsumerProbe.trace = "";
    }
}
