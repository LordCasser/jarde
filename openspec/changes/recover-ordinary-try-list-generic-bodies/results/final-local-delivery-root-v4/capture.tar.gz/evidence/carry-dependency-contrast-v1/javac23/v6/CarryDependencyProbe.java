// jarde: presentation of `CarryDependencyProbe` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class CarryDependencyProbe extends java.lang.Object {
    public static int effects;

    public static java.lang.String trace;

    public CarryDependencyProbe() {
        // @method <init>()V
        // @declaration a constructor of `CarryDependencyProbe`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static CarryDependencyProbe make() {
        // @method make()LCarryDependencyProbe;
        // @declaration a static method of `CarryDependencyProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        CarryDependencyProbe.trace = new java.lang.StringBuilder().append(CarryDependencyProbe.trace).append("M").toString();
        return new CarryDependencyProbe();
    }

    public int value() {
        // @method value()I
        // @declaration an instance method of `CarryDependencyProbe`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        CarryDependencyProbe.trace = new java.lang.StringBuilder().append(CarryDependencyProbe.trace).append("V").toString();
        return 5;
    }

    public static int arm() {
        // @method arm()I
        // @declaration a static method of `CarryDependencyProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        CarryDependencyProbe.trace = new java.lang.StringBuilder().append(CarryDependencyProbe.trace).append("A").toString();
        return 2;
    }

    public static boolean test(boolean flag) {
        // @method test(Z)Z
        // @declaration a static method of `CarryDependencyProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        CarryDependencyProbe.trace = new java.lang.StringBuilder().append(CarryDependencyProbe.trace).append("T").toString();
        return flag;
    }

    public static void consume(int value) {
        // @method consume(I)V
        // @declaration a static method of `CarryDependencyProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        CarryDependencyProbe.effects = value;
        return;
    }

    public static void referenceConsumer(boolean flag) {
        // jarde: not recovered: the recovery run for `referenceConsumer(Z)V` produced no statement (explanation only); the artifact's own comment lines are below
        // @method referenceConsumer(Z)V
        // @declaration a static method of `CarryDependencyProbe`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0
        // the saved producer at BCI 0 has no bounded final expression consumer
        // @bytecode 0 3 6 7 10 13 16 19 20 21 24
        // the saved producer at BCI 3 has 3 consumers, so one local binding cannot prove its execution count
        // @bytecode 21 3 0
        // the value at BCI 21 was produced by a saved declaration this run could not commit
        jarde_refused_body();
    }

    static {
        // @method <clinit>()V
        // @declaration a static initializer of `CarryDependencyProbe`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        CarryDependencyProbe.trace = "";
    }
}
