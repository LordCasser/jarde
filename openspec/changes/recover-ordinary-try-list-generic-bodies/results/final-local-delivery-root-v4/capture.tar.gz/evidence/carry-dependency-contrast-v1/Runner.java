public final class Runner {
    public static void main(String[] args) {
        for (boolean flag : new boolean[] {false, true}) {
            CarryDependencyProbe.effects = 0;
            CarryDependencyProbe.trace = "";
            CarryDependencyProbe.referenceConsumer(flag);
            System.out.println(flag + "|" + CarryDependencyProbe.effects + "|" + CarryDependencyProbe.trace);
        }
    }
}
