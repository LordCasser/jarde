# Ordinary Try + List MVP full-class baseline collector prep

This fresh private prep binds the uncompiled v2 candidate as a complete Java 8 source set: all existing `UpstreamNestedLoops` methods and all 17 original Runner oracle rows remain, followed by the new typed traces. It adapts the previously used full-class collector pattern and does not execute it.

Each invocation selects one javac metadata mode (`debug` => `-g`, or `none` => `-g:none`) and runs the complete provider/JDK matrix: JDK 8 and 23; original, JADX default, JADX rename-none, Jarde default, and Jarde `--evidence all`. For each JDK, the collector packages that JDK’s own original class, runs both JADX profiles against that jar, then compiles and runs those generated sources with the same JDK. Every provider is compiled with the full target class and full Runner. A runtime command is launched only after successful, unstopped compilation; failed compile rows explicitly say `runtime_state: no-runtime` and retain the raw diagnostics. Generated Java is never patched.

The collector stores complete JSON class-source reports (including maps) and emitted full-class text, full compiler/JADX/Jarde argv, raw stdout/stderr, generated classes, source/tool pins before and after, and per-JDK original stdout/stderr oracle comparisons. Class-set comparison is anchored to the class set actually emitted by that JDK's full original compile, so the Runner's nested `TraceList`/iterator helper classes are included and must match in provider compiles. The manifest target class and Runner class are still required.

The CLI receipt preflight requires the exact `commands_passed_pending_independent_acceptance` status, the supplied receipt SHA, and the receipt’s exact CLI path/bytes/hash binding. The collector has the existing 5 GiB free-space preflight, 1 GiB shared-target cap, one-second guard polling, pinned JDK/JADX/scanner/parser/guard inputs, default JVM stack, fresh-output refusal, and raw-stream recorder. It refuses to start if the shared workspace `target/` exists and records that it remains absent after collection. It invokes no Cargo command; the target-absence gate is the applicable clean-state proof for this Java-only capture. The root should still follow its own final-clean procedure around the overall toolchain session.

## Serial invocations

Set CLI and receipt values from the actual final focused build receipt; no CLI path/hash is frozen here. `RECEIPT_CLI_OBJECT`, status key/value, and optional mode key must match that receipt exactly. Run debug and none serially, each with a new output path:

```sh
CURRENT_CLI_PATH=/path/to/frozen-candidate-cli \
CURRENT_CLI_SHA256=<actual-cli-sha256> \
CURRENT_BUILD_RECEIPT=/path/to/actual-build-receipt.json \
CURRENT_BUILD_RECEIPT_SHA256=<actual-receipt-sha256> \
RECEIPT_CLI_OBJECT=cli \
RECEIPT_STATUS_KEY=status \
RECEIPT_ACCEPTED_VALUE=<exact-status-in-that-receipt> \
BASELINE_DEBUG_INFO=debug \
BASELINE_OUT=/private/tmp/jarde-ordinary-try-list-debug-root-v2 \
sh /private/tmp/jarde-ordinary-try-list-mvp-baseline-prep-luna-v2/run-current.sh
```

```sh
CURRENT_CLI_PATH=/path/to/frozen-candidate-cli \
CURRENT_CLI_SHA256=<actual-cli-sha256> \
CURRENT_BUILD_RECEIPT=/path/to/actual-build-receipt.json \
CURRENT_BUILD_RECEIPT_SHA256=<actual-receipt-sha256> \
RECEIPT_CLI_OBJECT=cli \
RECEIPT_STATUS_KEY=status \
RECEIPT_ACCEPTED_VALUE=<exact-status-in-that-receipt> \
BASELINE_DEBUG_INFO=none \
BASELINE_OUT=/private/tmp/jarde-ordinary-try-list-nodebug-root-v2 \
sh /private/tmp/jarde-ordinary-try-list-mvp-baseline-prep-luna-v2/run-current.sh
```

If the actual receipt stores its CLI binding under another object path, set `RECEIPT_CLI_OBJECT` to that dotted path. Set `RECEIPT_MODE_KEY` only when the pinned receipt has an explicit mode field. The collector itself verifies the supplied CLI and receipt SHA, CLI mode 0555, and exact path/bytes/hash binding.

`inputs/manifest.json` and `pins.json` are the fixed source inputs for these invocations. This prep has not been executed and contains no observed compile or runtime outcome. `collect_controls-v1-v2.diff` shows the small changes from the previously used full-class collector.
