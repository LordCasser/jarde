#!/bin/sh
set -eu
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
: "${CURRENT_CLI_PATH:?Set the actual frozen current Jarde CLI path}"
: "${CURRENT_CLI_SHA256:?Set the actual frozen current Jarde CLI SHA-256}"
: "${CURRENT_BUILD_RECEIPT:?Set the actual CLI build receipt path}"
: "${CURRENT_BUILD_RECEIPT_SHA256:?Set the exact build receipt SHA-256}"
: "${RECEIPT_ACCEPTED_VALUE:?Set the exact accepted receipt status from that pinned receipt}"
: "${BASELINE_OUT:?Set a fresh output directory that does not exist}"
BASELINE_DEBUG_INFO=${BASELINE_DEBUG_INFO:-debug}
RECEIPT_CLI_OBJECT=${RECEIPT_CLI_OBJECT:-cli}
RECEIPT_STATUS_KEY=${RECEIPT_STATUS_KEY:-status}
RECEIPT_MODE_KEY=${RECEIPT_MODE_KEY:-}
exec python3 -B "$DIR/collect_controls.py" \
  --inputs-dir "$DIR/inputs" \
  --inputs-manifest "$DIR/inputs/manifest.json" \
  --out "$BASELINE_OUT" \
  --javac-debug "$BASELINE_DEBUG_INFO" \
  --cli "$CURRENT_CLI_PATH" \
  --cli-sha256 "$CURRENT_CLI_SHA256" \
  --build-receipt "$CURRENT_BUILD_RECEIPT" \
  --build-receipt-sha256 "$CURRENT_BUILD_RECEIPT_SHA256" \
  --receipt-cli-object "$RECEIPT_CLI_OBJECT" \
  --receipt-status-key "$RECEIPT_STATUS_KEY" \
  --receipt-accepted-value "$RECEIPT_ACCEPTED_VALUE" \
  --receipt-mode-key "$RECEIPT_MODE_KEY" \
  --jdk-manifest "/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json" \
  --jdk-manifest-sha256 "ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec" \
  --jadx "/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx" \
  --jadx-sha256 "64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7" \
  --jadx-jar "/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar" \
  --jadx-jar-sha256 "966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65" \
  --guard "/Users/lordcasser/workspace/projects/jarde/openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py" \
  --guard-sha256 "51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33" \
  --scanner "/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py" \
  --scanner-sha256 "d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7" \
  --classfile-parser "/private/tmp/jarde-computed-for-cf07-final-replay-verifier-root-v4.py" \
  --classfile-parser-sha256 "f30754e1e52403713a671ce38f274b772f188583df6c4a1bc6b4400937233469"
