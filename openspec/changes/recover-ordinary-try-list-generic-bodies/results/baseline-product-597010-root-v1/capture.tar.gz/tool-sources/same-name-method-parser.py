import hashlib, json, struct
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASE = Path('/private/tmp')
def pin(path):
    path = Path(path); data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
def checked(row):
    assert pin(row['path']) == row, row['path']
    return Path(row['path']).read_bytes()
def receipt(name, count):
    path = BASE / name / 'execution.json'; data = json.loads(path.read_text())
    assert data['status'] == 'commands_passed_pending_independent_acceptance'
    assert data['default_stack'] and data['target_absent']
    assert data['source_manifest_before'] == data['source_manifest_after']
    for row in data['source_manifest_before']:
        assert pin(ROOT / row['path']) | {'path': row['path']} == row
    checked(data['runner']); spec = json.loads(checked(data['command_spec']))
    assert len(spec) == count and len(data['commands']) == count + 1
    assert [c['argv'] for c in data['commands'][:-1]] == spec
    assert data['commands'][-1]['argv'] == ['cargo', 'clean']
    assert data['guard'] == {'minimum_free_bytes': 5 * 1024**3, 'maximum_target_bytes': 1024**3, 'interval_seconds': 1}
    for i, c in enumerate(data['commands'], 1):
        assert c['index'] == i and c['exit_code'] == 0 and c.get('guard_stop') is None
        for row in c['streams'].values(): checked(row)
    return data, pin(path)
def class_methods(path):
    data = Path(path).read_bytes(); pos = 0
    def take(n):
        nonlocal pos
        value = data[pos:pos+n]; assert len(value) == n; pos += n; return value
    def u1(): return take(1)[0]
    def u2(): return int.from_bytes(take(2), 'big')
    def u4(): return int.from_bytes(take(4), 'big')
    assert u4() == 0xcafebabe; take(4); cp = [None] * u2(); i = 1
    while i < len(cp):
        tag = u1()
        if tag == 1: cp[i] = take(u2())
        elif tag in (3,4,9,10,11,12,17,18): take(4)
        elif tag in (5,6): take(8); i += 1
        elif tag in (7,8,16,19,20): take(2)
        elif tag == 15: take(3)
        else: raise AssertionError(tag)
        i += 1
    take(6); take(u2()*2)
    def attrs():
        result = {}
        for _ in range(u2()):
            name = cp[u2()]; result[name] = take(u4())
        return result
    for _ in range(u2()): take(6); attrs()
    methods = {}
    for _ in range(u2()):
        take(2); name = cp[u2()]; desc = cp[u2()]; a = attrs()
        code = a[b'Code']; length = int.from_bytes(code[4:8], 'big')
        assert len(code) >= length + 8
        methods[(tuple(name), tuple(desc))] = length
    attrs(); assert pos == len(data)
    return methods

probe, pp = receipt('jarde-same-name-reference-debug-probe-run-root-v1', 16)
runtime, rp = receipt('jarde-same-name-reference-debug-runtime-run-root-v1', 18)
assert probe['source_manifest_before'] == runtime['source_manifest_before']
inputs_path = BASE / 'jarde-same-name-reference-debug-runtime-prep-root-v1/inputs.json'
inputs = json.loads(inputs_path.read_text()); assert len(inputs) == 8
cli = pin(probe['commands'][0]['argv'][0])
assert cli['bytes'] == 62562992 and cli['sha256'] == 'fe00fa7f0edc587a4e85bcc1136bd4397738c2a9df632432a2e79a8221c8bdd6'
results = []; tool_pins = {}
for i, inp in enumerate(inputs):
    original = Path(inp['original_class']); generated = Path(inp['generated_source'])
    assert pin(original)['sha256'] == inp['original_sha256']
    assert pin(generated)['sha256'] == inp['generated_source_sha256']
    checked(inp['report_raw'])
    default_cmd, all_cmd = probe['commands'][i*2:i*2+2]
    assert default_cmd['argv'][0] == all_cmd['argv'][0] == cli['path']
    expected_cli = [cli['path'], 'class-source', '--input', str(original), '--class', inp['name'], '--policy', 'single-class', '--release', '8', '--format', 'json']
    assert default_cmd['argv'] == expected_cli and all_cmd['argv'] == expected_cli + ['--evidence', 'all']
    default = json.loads(checked(default_cmd['streams']['stdout']))
    all_report = json.loads(checked(all_cmd['streams']['stdout']))
    assert default['outcome'] == all_report['outcome'] == 'performed'
    assert default['execution']['status'] == all_report['execution']['status'] == 'complete'
    assert default['text'] == all_report['text'] and generated.read_bytes() == all_report['text'].encode()
    assert '@bytecode' not in all_report['text'] and 'v_2' in all_report['text']
    methods = class_methods(original); assert len(methods) == len(default['methods']) == len(all_report['methods']) == 3
    observed = set(); origins = 0
    for left, right in zip(default['methods'], all_report['methods']):
        assert left['item'] == right['item'] and not right['markers']
        assert left['outcome']['kind'] == right['outcome']['kind'] == 'recovered'
        l, r = left['outcome']['report'], right['outcome']['report']; identity = right['item']['identity']
        key = tuple(identity['name']), tuple(identity['descriptor']); observed.add(key)
        assert l['text'] == r['text'] and r['execution']['status'] == 'complete' and not r['fallbacks']
        assert identity['owner'] == all_report['class'] and all_report['class']['class_bytes']['length'] == original.stat().st_size
        segments = r['source_map']['segments']; assert segments
        for seg in segments:
            assert 0 <= seg['start'] < seg['end'] <= len(r['text'].encode())
            for origin in [seg['origin']['primary']] + seg['origin']['derived']:
                assert origin['method'] == identity
                assert origin['bci'] is None or 0 <= origin['bci'] < methods[key]
                origins += 1
    assert observed == set(methods)
    offset = 0 if i < 4 else 9; j = i % 4
    original_cmd = runtime['commands'][offset+j]; compile_cmd = runtime['commands'][offset+4]; generated_cmd = runtime['commands'][offset+5+j]
    assert original_cmd['argv'][1:] == ['-Xverify:all', '-cp', str(original.parent), inp['name']]
    assert generated_cmd['argv'][0] == original_cmd['argv'][0]
    assert generated_cmd['argv'][1:] == ['-Xverify:all', '-cp', str(generated.parent.parent/'classes'), inp['name']]
    assert str(generated) in compile_cmd['argv'] and '-proc:none' in compile_cmd['argv']
    for flag in ('-classpath', '-sourcepath'):
        empty = Path(compile_cmd['argv'][compile_cmd['argv'].index(flag)+1]); assert empty.is_dir() and not list(empty.iterdir())
    for command in (original_cmd, compile_cmd): tool_pins[command['argv'][0]] = pin(command['argv'][0])
    actual = checked(original_cmd['streams']['stdout']); reconstructed = checked(generated_cmd['streams']['stdout'])
    assert actual == reconstructed and actual
    assert not checked(original_cmd['streams']['stderr']) and not checked(generated_cmd['streams']['stderr'])
    results.append({'jdk': inp['jdk'], 'class': inp['name'], 'original': pin(original), 'generated_source': pin(generated), 'physical_origins_checked': origins, 'oracle_utf8': actual.decode(), 'original_runtime': original_cmd['streams'], 'generated_runtime': generated_cmd['streams']})
for jdk in ('javac8', 'javac23'):
    classes = BASE / 'jarde-same-name-reference-debug-runtime-prep-root-v1' / jdk / 'classes'
    assert sorted(p.name for p in classes.rglob('*.class')) == sorted(x['name']+'.class' for x in inputs if x['jdk'] == jdk)
assert not (ROOT/'target').exists()
out = BASE/'jarde-same-name-reference-acceptance-root-v1.json'; assert not out.exists()
out.write_text(json.dumps({'status': 'accepted_eight_whole_classes_two_jdks', 'verifier': pin(__file__), 'cli': cli, 'probe_receipt': pp, 'runtime_receipt': rp, 'inputs': pin(inputs_path), 'source_closure_count': len(probe['source_manifest_before']), 'tool_pins': list(tool_pins.values()), 'results': results, 'scope': '16 actual CLI commands; 2 isolated unedited whole-class compile batches; 8 original and 8 generated executions byte-equal; 3 methods each; 17/10 larger runtime matrices remain separately recorded; no new JADX runtime claim'}, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'acceptance': pin(out), 'oracles': [(x['jdk'],x['class'],x['oracle_utf8']) for x in results]}))
