# 普通 try/List baseline 独立审计器 v2

这是一个私有只读审计器准备目录。它在 v1 之外补强物理 classfile、BCI、render 输出和编译运行命令绑定。v1 的脚本、报告、audit JSON 与 pins 均未覆盖；此目录没有运行 v2 审计器或任何工具链，也没有改共享仓库/既有 capture。

交付后 root 可审读并运行：

```sh
python3 -B /private/tmp/jarde-ordinary-try-list-mvp-baseline-audit-luna-v2/audit.py \
  --debug-capture /private/tmp/jarde-ordinary-try-list-debug-baseline-root-v2 \
  --none-capture /private/tmp/jarde-ordinary-try-list-none-baseline-root-v1 \
  --final-clean-receipt /private/tmp/jarde-ordinary-try-list-baseline-final-clean-root-v1/execution.json \
  --out /private/tmp/jarde-ordinary-try-list-mvp-baseline-audit-luna-v2/audit.json
```

v2 AST 提取 `/private/tmp/jarde-same-name-reference-accept-root-v1.py` 中 pin 过的纯 `class_methods()`，不 import 该脚本、不执行其 top-level。另从 capture receipt pin 的 CF07 parser AST 中只提取 `need`、`insn_size`、`decode` 三个 decoder 定义。扩展 classfile parser 读取每个物理方法的 Code bytes，并要求两套物理 method table 的身份与 Code 长度吻合。每份 Jarde report 的物理方法身份集合必须与对应 JDK 的 Original class 完全相等；每个非空 source-map BCI 必须落在真实 JVM instruction boundary。报告记录每方法映射覆盖与缺失 BCI；缺口原样披露，越界则审计失败。

每份落盘 report JSON 对象与 render 命令 stdout JSON 对象比较。default/all 会按物理方法比较 identity、item body、decompiled body、source map 的规范 JSON digest。Original、JADX、Jarde 编译和运行 argv 必须绑定到 pinned JDK/JADX/CLI、receipt 中的源码文件和实际 classesDir；所有实际生成的 `.class` 文件 inventory 与 bytes/SHA 必须等于 receipt。失败的编译必须保持 `no-runtime`，不产生虚构的运行结论。

V2 尚未在真实 captures 上运行，因此没有新 acceptance 结论。`diff-v1.patch` 和 `pins.json` 用于 root 独立审阅变更边界与输入完整性。
