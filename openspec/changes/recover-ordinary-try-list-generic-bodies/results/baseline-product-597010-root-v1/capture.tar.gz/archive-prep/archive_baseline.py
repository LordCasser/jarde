#!/usr/bin/env python3
"""Package the two accepted ordinary-Try/List captures without installed tool binaries."""
import argparse
import gzip
import hashlib
import json
import pathlib
import stat
import tarfile

DEBUG = pathlib.Path('/private/tmp/jarde-ordinary-try-list-debug-baseline-root-v2')
NONE = pathlib.Path('/private/tmp/jarde-ordinary-try-list-none-baseline-root-v1')
ACCEPT = pathlib.Path('/private/tmp/jarde-ordinary-try-list-baseline-acceptance-root-v2.json')
CLEAN = pathlib.Path('/private/tmp/jarde-ordinary-try-list-baseline-final-clean-root-v1/execution.json')
PREP = pathlib.Path('/private/tmp/jarde-ordinary-try-list-mvp-baseline-prep-root-v3')
AUDIT = pathlib.Path('/private/tmp/jarde-ordinary-try-list-mvp-baseline-audit-luna-v2')
FOCUSED = pathlib.Path('/private/tmp/jarde-reference-prefix-final-focused-run-root-v11/execution.json')
CF07_PARSER = pathlib.Path('/private/tmp/jarde-computed-for-cf07-final-replay-verifier-root-v4.py')
SAME_NAME_HELPER = pathlib.Path('/private/tmp/jarde-same-name-reference-accept-root-v1.py')
GUARD = pathlib.Path('/Users/lordcasser/workspace/projects/jarde/openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py')
SCANNER = pathlib.Path('/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py')
ORIGINAL_FIXTURE = pathlib.Path('/Users/lordcasser/workspace/projects/jarde/tests/fixtures/cf11-structured-list-controls')
JDK_MANIFEST = pathlib.Path('/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json')
ARCHIVE_PREP = pathlib.Path(__file__).resolve().parent
EXPECTED = {
    DEBUG / 'execution.json': 'f9b25f4f93c98c795618590ec75041dd827bd058f344e1c1e8a16dfc92b271e3',
    NONE / 'execution.json': 'b94ca14e7940a4eb4a964172337393e496ed061195e26af2a8eceb79c53d258b',
    ACCEPT: '6cf0567b6d31cf3b63d95c0d8ad7b03c7d85a4db29fec5bb72a60db87d211048',
    CLEAN: 'f58d128bdb6ab593bff76e33d1df6380aa2e63b658a4bd98306c32524252cf31',
    AUDIT / 'audit.py': 'abcaf58323817ad8bcf707a0d2968e42f13d7d2970b3554b3f2c499683a9ef1a',
    FOCUSED: '88804a94660ddbbbd2186247044f4c4af3e3535c69680617963324a2b6c2cd26',
    PREP / 'collect_controls.py': '74141123bb2e1a2be6e488b54b6b2a3a8adb8961ddfa935a3fb31a34a581b823',
    JDK_MANIFEST: 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec',
    PREP / 'inputs' / 'manifest.json': 'd057ce3c6316f6f370f824abe683e89aec4b418186b35bd2c1261c964751bbe6',
    CF07_PARSER: 'f30754e1e52403713a671ce38f274b772f188583df6c4a1bc6b4400937233469',
    SAME_NAME_HELPER: '51dd51c2f5a65d2ece32a0d20f34576f4ad2da9af6e0d31f1e66f9c8540081a1',
    GUARD: '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33',
    SCANNER: 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7',
}
WORKSPACE = pathlib.Path('/Users/lordcasser/workspace/projects/jarde').resolve()
CLI = pathlib.Path('/private/tmp/jarde-reference-prefix-final-focused-run-root-v11/candidate-cli').resolve()
JADX_JAR = pathlib.Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar').resolve()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8'))


def pin(path):
    data = pathlib.Path(path).read_bytes()
    return {'path': str(pathlib.Path(path).resolve()), 'bytes': len(data), 'sha256': sha(data)}


def add(members, source, name, role):
    source = pathlib.Path(source)
    data = source.read_bytes()
    name = pathlib.PurePosixPath(name).as_posix()
    if name.startswith('/') or '..' in pathlib.PurePosixPath(name).parts:
        raise ValueError(f'unsafe archive member path: {name}')
    if name in members:
        if members[name]['sha256'] != sha(data):
            raise ValueError(f'duplicate archive path has different bytes: {name}')
        return members[name]
    record = {'member': name, 'bytes': len(data), 'sha256': sha(data),
              'origin_path': str(source.resolve()), 'role': role,
              'mode': stat.S_IMODE(source.stat().st_mode)}
    members[name] = {'data': data, **record}
    return record


def add_tree(members, root, prefix):
    root = pathlib.Path(root).resolve()
    if not root.is_dir():
        raise ValueError(f'missing capture directory: {root}')
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError(f'symlink is not allowed in captured tree: {path}')
        if not path.is_file():
            continue
        resolved = path.resolve()
        if resolved == CLI or resolved == JADX_JAR or WORKSPACE / 'target' in resolved.parents:
            raise ValueError(f'forbidden external binary/build output inside capture: {path}')
        rel = path.relative_to(root).as_posix()
        add(members, path, f'{prefix}/{rel}', f'{prefix} complete captured file')


def raw_bindings(receipt, members, archive_prefix, capture_root):
    found = []
    for command in receipt.get('commands', []):
        for stream, meta in command.get('streams', {}).items():
            raw_path = pathlib.Path(meta['path']).resolve()
            data = raw_path.read_bytes()
            if len(data) != meta.get('bytes') or sha(data) != meta.get('sha256'):
                raise ValueError(f"receipt raw stream pin mismatch: {meta.get('path')}")
            try:
                relative = raw_path.relative_to(capture_root.resolve()).as_posix()
            except ValueError:
                relative = None
            member = f'{archive_prefix}/{relative}' if relative is not None else None
            if member is not None:
                archived = members.get(member)
                if archived is None or archived['sha256'] != sha(data) or archived['bytes'] != len(data):
                    raise ValueError(f'captured raw stream is not bound to archive member: {member}')
            else:
                raise ValueError(f'raw stream lies outside expected capture tree: {raw_path}')
            found.append({'command_index': command.get('index'), 'command_label': command.get('label'),
                          'stream': stream, 'member': member, 'bytes': len(data), 'sha256': sha(data)})
    return found


def add_receipt_raws(members, receipt, root_name, role):
    found = []
    commands = receipt.get('commands', [])
    if not commands and isinstance(receipt.get('command'), dict):
        commands = [receipt['command']]
    for ci, command in enumerate(commands, 1):
        for stream, meta in command.get('streams', {}).items():
            record = add(members, meta['path'], f'{root_name}/raw/{ci}.{stream}.raw', role + ' raw stream')
            if record['bytes'] != meta.get('bytes') or record['sha256'] != meta.get('sha256'):
                raise ValueError(f'{role} raw stream receipt mismatch: {meta.get("path")}')
            found.append({'command_index': command.get('index', ci), 'argv': command.get('argv'),
                          'stream': stream, 'member': record['member'], 'bytes': record['bytes'],
                          'sha256': record['sha256']})
    return found


def add_pin_reference(members, pin_row, member, role):
    record = add(members, pin_row['path'], member, role)
    if record['bytes'] != pin_row.get('bytes') or record['sha256'] != pin_row.get('sha256'):
        raise ValueError(f"source/tool pin mismatch: {pin_row.get('path')}")
    return record


def require_ledger_pin(source, ledger_path):
    actual = pin(source)
    rows = read_json(ledger_path).get('sources', [])
    matches = [x for x in rows if pathlib.Path(x.get('path', '')).name == pathlib.Path(source).name and
               x.get('bytes') == actual['bytes'] and x.get('sha256') == actual['sha256']]
    if not matches:
        raise ValueError(f'file is not covered by source pin ledger {ledger_path}: {source}')
    return actual


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', required=True, type=pathlib.Path, help='new .tar.gz path; overwrite is refused')
    args = ap.parse_args()
    out = args.out.resolve()
    sidecar = pathlib.Path(str(out) + '.manifest.json')
    if out.exists() or sidecar.exists():
        raise SystemExit(f'refuse overwrite: {out} or {sidecar}')

    members = {}
    raw_index = {}
    debug_receipt_path = DEBUG / 'execution.json'
    none_receipt_path = NONE / 'execution.json'
    for path, digest in EXPECTED.items():
        actual = pin(path)
        if actual['sha256'] != digest:
            raise ValueError(f'input changed since accepted capture: {path}')

    acceptance = read_json(ACCEPT)
    if acceptance.get('status') != 'audited' or acceptance.get('errors') != []:
        raise ValueError('independent acceptance is not audited/error-free')
    accepted_by_mode = {row.get('mode'): row for row in acceptance.get('captures', [])}
    for mode in ('debug', 'none'):
        accepted = accepted_by_mode.get(mode)
        if not accepted or accepted.get('command_count') != 27 or accepted.get('raw_stream_count') != 54:
            raise ValueError(f'{mode}: v2 independent acceptance command/raw inventory differs')
        if {x.get('output_row_count') for x in accepted.get('original_rows', [])} != {44}:
            raise ValueError(f'{mode}: expected two 44-row Original runtime observations')
        if {x.get('method_count') for x in accepted.get('jarde_reports', [])} != {17} or len(accepted.get('jarde_reports', [])) != 4:
            raise ValueError(f'{mode}: expected four 17-physical-method Jarde whole-class reports')
        providers = accepted.get('provider_compile_runtime', [])
        jadx_rows = [x for x in providers if '-jadx-' in x.get('label', '')]
        jarde_rows = [x for x in providers if '-jarde-' in x.get('label', '')]
        if len(jadx_rows) != 4 or any(x.get('compile_exit') != 1 or x.get('runtime') != 'no-runtime' for x in jadx_rows):
            raise ValueError(f'{mode}: JADX compile-failure/no-runtime evidence differs')
        if len(jarde_rows) != 4 or any(x.get('compile_exit') != 0 or x.get('runtime') != 'matches-original' for x in jarde_rows):
            raise ValueError(f'{mode}: Jarde runtime comparison evidence differs')
    clean = read_json(CLEAN)
    if clean.get('status') != 'passed' or clean.get('target_absent_before') is not True or clean.get('target_absent_after') is not True:
        raise ValueError('final clean receipt is not the pinned successful clean')
    if acceptance.get('final_clean', {}).get('receipt', {}).get('sha256') != pin(CLEAN)['sha256']:
        raise ValueError('independent acceptance does not bind the supplied final clean receipt')
    debug = read_json(DEBUG / 'execution.json')
    captures = [('debug', DEBUG, debug_receipt_path), ('none', NONE, none_receipt_path)]
    for mode, root, receipt_path in captures:
        receipt = read_json(receipt_path)
        accepted_receipt = accepted_by_mode[mode].get('receipt', {})
        receipt_pin = pin(receipt_path)
        if accepted_receipt.get('sha256') != receipt_pin['sha256'] or accepted_receipt.get('bytes') != receipt_pin['bytes']:
            raise ValueError(f'{mode}: acceptance does not bind supplied capture receipt')
        if receipt.get('schema') != 'cf11-target-full-source-capture-v2' or receipt.get('status') != 'observed':
            raise ValueError(f'{mode}: capture receipt schema/status mismatch')
        if len(receipt.get('commands', [])) != receipt.get('actual_command_count'):
            raise ValueError(f'{mode}: command count receipt mismatch')
        if receipt.get('source_tool_pins_before') != receipt.get('source_tool_pins_after') or receipt.get('source_tool_inputs_unchanged') is not True:
            raise ValueError(f'{mode}: source/tool pin ledger changed')
        profiles = receipt.get('jadx', {}).get('profiles', {})
        if set(profiles) != {'javac8-default', 'javac8-none', 'javac23-default', 'javac23-none'}:
            raise ValueError(f'{mode}: expected per-JDK default/none JADX profiles')
        for key, profile in profiles.items():
            jdk = key.split('-', 1)[0]
            if profile.get('input_class_jdk') != jdk or profile.get('compile_run_jdk') != jdk:
                raise ValueError(f'{mode}: JADX profile does not use same-JDK input/runtime: {key}')
        add_tree(members, root, f'captures/{mode}')
        raw_index[mode] = raw_bindings(receipt, members, f'captures/{mode}', root)
        if len(raw_index[mode]) != 54:
            raise ValueError(f'{mode}: expected 54 source-bound capture raw streams')

    # Include accepted results and the auditor, not its frozen CLI binary.
    add(members, ACCEPT, 'acceptance/audit-v2.json', 'independent acceptance receipt')
    for name in ('audit.py', 'README.md', 'pins.json', 'static-check.json', 'root-review.json'):
        if name not in ('root-review.json', 'pins.json'):
            require_ledger_pin(AUDIT / name, AUDIT / 'pins.json')
        add(members, AUDIT / name, f'auditor-v2/{name}', 'independent audit source/provenance')
    add(members, CLEAN, 'final-clean/execution.json', 'final clean receipt')
    clean_raw = add_receipt_raws(members, clean, 'final-clean', 'final clean')

    # Source-only baseline preparation, including original fixture/Runner and exact manifest.
    for name in ('collect_controls.py', 'run-current.sh', 'README.md', 'pins.json', 'static-check.json'):
        if name != 'pins.json':
            require_ledger_pin(PREP / name, PREP / 'pins.json')
        add(members, PREP / name, f'prep-v3/{name}', 'baseline collector provenance')
    for name in ('manifest.json', 'UpstreamNestedLoops.java', 'Runner.java'):
        if name != 'manifest.json':
            require_ledger_pin(PREP / 'inputs' / name, PREP / 'pins.json')
        add(members, PREP / 'inputs' / name, f'prep-v3/inputs/{name}', 'source-only baseline input closure')
    if pathlib.Path(debug['collector_config']['jdk_manifest']).resolve() != JDK_MANIFEST.resolve():
        raise ValueError('capture JDK manifest path differs from expected pinned manifest')
    add(members, JDK_MANIFEST,
        'tool-references/jdk-manifest.json', 'pinned JDK 8/23 executable manifest')
    original_pins = {pathlib.Path(x['path']): x for x in read_json(PREP / 'pins.json').get('sources', [])}
    for name in ('UpstreamNestedLoops.java', 'Runner.java', 'manifest.json'):
        source = ORIGINAL_FIXTURE / name
        pin_row = original_pins.get(source)
        if not pin_row:
            raise ValueError(f'original source closure pin absent from prep ledger: {source}')
        record = add(members, source, f'original-controls/{name}', 'original full-class control/17-row oracle source')
        if record['bytes'] != pin_row['bytes'] or record['sha256'] != pin_row['sha256']:
            raise ValueError(f'original source closure differs from prep pin: {source}')

    # Focused CLI build receipt, raw outputs, runner/spec and complete product source-pin list.
    focused = read_json(FOCUSED)
    for name, ref in (('execution.json', FOCUSED), ('runner.py', pathlib.Path(focused['runner']['path'])),
                      ('command-spec.json', pathlib.Path(focused['command_spec']['path']))):
        add(members, ref, f'focused-build/{name}', 'focused CLI build receipt/runner/spec')
    for field in ('runner', 'command_spec'):
        pin_ref = focused[field]
        record = members[f"focused-build/{'runner.py' if field == 'runner' else 'command-spec.json'}"]
        if record['bytes'] != pin_ref['bytes'] or record['sha256'] != pin_ref['sha256']:
            raise ValueError(f'focused build {field} pin mismatch')
    focused_raw = add_receipt_raws(members, focused, 'focused-build', 'focused CLI build')
    closure = {'schema': 'focused-cli-source-closure-references-v1',
               'source_manifest_before': focused.get('source_manifest_before'),
               'source_manifest_after': focused.get('source_manifest_after'),
               'source_manifest_equal': focused.get('source_manifest_before') == focused.get('source_manifest_after'),
               'source_members': len(focused.get('source_manifest_before', [])),
               'source_bytes_total': sum(x.get('bytes', 0) for x in focused.get('source_manifest_before', [])),
               'source_bodies_included': False,
               'omission_reason': 'Pinned source closure metadata is retained; source bodies are not copied as a repository tree.'}
    if closure['source_manifest_equal'] is not True:
        raise ValueError('focused CLI source closure changed during build')
    closure_bytes = json.dumps(closure, ensure_ascii=False, sort_keys=True, indent=2).encode() + b'\n'
    members['provenance/focused-cli-source-closure.json'] = {
        'data': closure_bytes, 'member': 'provenance/focused-cli-source-closure.json',
        'bytes': len(closure_bytes), 'sha256': sha(closure_bytes), 'origin_path': str(FOCUSED),
        'role': 'pinned product source closure references; bodies omitted', 'mode':0o644}

    # Copy only source/tool scripts; the CLI, JDK and JADX installed binaries remain references.
    tool_scripts = [
        (CF07_PARSER, 'tool-sources/cf07-classfile-parser.py', 'pinned pure parser source'),
        (SAME_NAME_HELPER, 'tool-sources/same-name-method-parser.py', 'pinned pure class_methods helper'),
        (GUARD, 'tool-sources/resource-guard.py', 'pinned guard script'),
        (SCANNER, 'tool-sources/target-size-scanner.py', 'pinned target scanner script'),
    ]
    for source, member, role in tool_scripts:
        add(members, source, member, role)
    for row in read_json(AUDIT / 'pins.json').get('sources', []):
        if row.get('role') == 'legacy 17-row oracle raw':
            name = pathlib.Path(row['path']).parent.name + '-' + pathlib.Path(row['path']).name
            add_pin_reference(members, row, f'legacy-oracle/{name}', 'frozen 17-row oracle raw')
    for name in ('archive_baseline.py', 'README.md', 'static-check.json', 'pins.json'):
        add(members, ARCHIVE_PREP / name, f'archive-prep/{name}', 'archive preparation source/provenance')

    # Every original external binary is named and SHA-pinned, but deliberately not embedded.
    external_paths = {pathlib.Path(debug['cli']['path']).resolve(),
                      pathlib.Path(debug['collector_config']['jadx']).resolve(),
                      pathlib.Path(debug['collector_config']['jadx_jar']).resolve()}
    for leg in ('javac8', 'javac23'):
        tool = next(x for x in read_json(debug['collector_config']['jdk_manifest'])['legs'] if x['leg'] == leg)
        external_paths.add(pathlib.Path(tool['jdk_tools']['javac']['path']).resolve())
        external_paths.add(pathlib.Path(tool['jdk_tools']['java']['path']).resolve())
        external_paths.add(pathlib.Path(tool['jdk_tools']['javap']['path']).resolve())
    external_refs = {}
    for mode, root, receipt_path in captures:
        receipt = read_json(receipt_path)
        for row in receipt.get('source_tool_pins_before', []):
            source = pathlib.Path(row['path']).resolve()
            if source in external_paths:
                live = pin(source)
                if live['bytes'] != row.get('bytes') or live['sha256'] != row.get('sha256'):
                    raise ValueError(f'external binary reference changed since capture: {source}')
                key = str(source)
                ref = external_refs.setdefault(key, {'path':key,'bytes':row['bytes'],'sha256':row['sha256'],
                                                     'role':'external executable/archive reference; binary intentionally omitted',
                                                     'capture_modes':[]})
                if ref['bytes'] != row['bytes'] or ref['sha256'] != row['sha256']:
                    raise ValueError(f'external binary pin differs across capture modes: {source}')
                ref['capture_modes'].append(mode)
    for ref in external_refs.values():
        if sorted(ref['capture_modes']) != ['debug', 'none']:
            raise ValueError(f"external binary is not pinned by both captures: {ref['path']}")
    external_refs = sorted(external_refs.values(), key=lambda x: x['path'])
    ext_bytes = json.dumps({'schema':'external-tool-reference-pins-v1','items':external_refs},indent=2).encode()+b'\n'
    members['provenance/external-tool-references.json'] = {
        'data':ext_bytes,'member':'provenance/external-tool-references.json','bytes':len(ext_bytes),
        'sha256':sha(ext_bytes),'origin_path':'capture receipts','role':'omitted binary path/hash references','mode':0o644}

    # Explicitly preserve the known source-map coverage gaps as observations, not failures or full coverage.
    expected_gaps = {'handled': [44], 'tryStringBranch': [40, 60, 79], 'tryIntegerBranch': [40, 60, 79],
                     'tryStringRemovePrefix': [55], 'tryStringNested': [90], 'tryStringUnknownCall': [40]}
    actual_gaps = {}
    for accepted in acceptance.get('captures', []):
        for report in accepted.get('jarde_reports', []):
            for method, coverage in report.get('map_instruction_coverage', {}).items():
                missing = coverage.get('coverage_missing', [])
                if missing:
                    short = method.split('(', 1)[0]
                    if short in actual_gaps and actual_gaps[short] != missing:
                        raise ValueError(f'known source-map gap changes across reports: {short}')
                    actual_gaps[short] = missing
    if actual_gaps != expected_gaps:
        raise ValueError(f'acceptance source-map coverage gaps differ from reviewed set: {actual_gaps}')
    gaps = {'coverage_missing': actual_gaps,
            'interpretation': 'These are audited valid instruction boundaries missing from source maps; archive does not claim full instruction coverage.'}
    gaps_data = json.dumps(gaps, ensure_ascii=False, indent=2).encode() + b'\n'
    members['provenance/source-map-coverage-gaps.json'] = {
        'data':gaps_data,'member':'provenance/source-map-coverage-gaps.json','bytes':len(gaps_data),
        'sha256':sha(gaps_data),'origin_path':str(ACCEPT),'role':'known valid map coverage gaps','mode':0o644}

    payload_rows = [{k: v for k, v in row.items() if k != 'data'} for row in sorted(members.values(), key=lambda x:x['member'])]
    archive_manifest = {'schema':'jarde-ordinary-try-list-baseline-archive-v1',
                        'acceptance':pin(ACCEPT), 'debug_receipt':pin(debug_receipt_path),
                        'none_receipt':pin(none_receipt_path), 'final_clean_receipt':pin(CLEAN),
                        'capture_raw_bindings':raw_index,'focused_build_raw_bindings':focused_raw,
                        'final_clean_raw_bindings':clean_raw,'members':payload_rows,
                        'external_binary_refs_member':'provenance/external-tool-references.json',
                        'product_source_closure_member':'provenance/focused-cli-source-closure.json',
                        'coverage_gaps_member':'provenance/source-map-coverage-gaps.json'}
    manifest_data = json.dumps(archive_manifest, ensure_ascii=False, sort_keys=True, indent=2).encode() + b'\n'
    members['MANIFEST.json'] = {'data':manifest_data,'member':'MANIFEST.json','bytes':len(manifest_data),
                                'sha256':sha(manifest_data),'origin_path':'generated by archive_baseline.py',
                                'role':'archive payload member manifest','mode':0o644}

    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('wb') as stream:
        with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode='w') as tar:
                for member in sorted(members):
                    data = members[member]['data']
                    info = tarfile.TarInfo(member)
                    info.size = len(data); info.mtime = 0; info.uid = 0; info.gid = 0; info.uname = ''; info.gname = ''; info.mode = members[member].get('mode', 0o644)
                    import io
                    tar.addfile(info, io.BytesIO(data))

    # Reopen the archive and validate every byte against the generated manifest.
    with tarfile.open(out, 'r:gz') as tar:
        actual_names = sorted(tar.getnames())
        if actual_names != sorted(members):
            raise ValueError('archive member inventory differs after reopen')
        for member in actual_names:
            data = tar.extractfile(member).read()
            expected = members[member]
            if len(data) != expected['bytes'] or sha(data) != expected['sha256']:
                raise ValueError(f'archive member failed reopen hash: {member}')
        embedded = json.loads(tar.extractfile('MANIFEST.json').read())
        for row in embedded['members']:
            data = tar.extractfile(row['member']).read()
            if len(data) != row['bytes'] or sha(data) != row['sha256']:
                raise ValueError(f'MANIFEST member failed independent reopen check: {row["member"]}')
    archive_data = out.read_bytes()
    sidecar_doc = {'schema':'jarde-ordinary-try-list-baseline-archive-sidecar-v1',
                   'archive':{'path':str(out),'bytes':len(archive_data),'sha256':sha(archive_data)},
                   'members':[{'member':name,'bytes':members[name]['bytes'],'sha256':members[name]['sha256'],'mode':members[name].get('mode',0o644)}
                              for name in sorted(members)]}
    sidecar.write_text(json.dumps(sidecar_doc,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'archived-and-reopened','archive':str(out),'archive_bytes':len(archive_data),
                      'archive_sha256':sha(archive_data),'member_count':len(members),
                      'sidecar':str(sidecar),'raw_bindings':sum(map(len,raw_index.values()))+len(focused_raw)+len(clean_raw)},indent=2))


if __name__ == '__main__':
    main()
