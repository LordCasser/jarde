# 普通 try/List 双模式基线归档准备

本目录只准备归档脚本，没有执行归档器、Git、Cargo、JDK、JADX 或 CLI，也没有写共享仓库。脚本输入固定为已接受的 debug 与 none captures、root v2 acceptance、final-clean receipt、source-only collector prep、v2 auditor，以及它们 pin 的纯脚本依赖。

root 审读后可用新输出路径执行：

```sh
python3 -B /private/tmp/jarde-ordinary-try-list-baseline-archive-prep-luna-v1/archive_baseline.py \
  --out /private/tmp/jarde-ordinary-try-list-baseline-capture-root-v1.tar.gz
```

脚本拒绝覆盖已有输出，按 capture receipt 的真实 `commands[].streams` 路径逐条绑定 54 条 raw stream/模式；并收录完整 capture tree（Original/Runner 与编译 class、JADX/Jarde source、JSON reports、maps、raw、receipt）。另收录 root v2 acceptance、final-clean receipt/raw、prep v3 collector/inputs/manifest、baseline 原始完整 source 与 17 行 Runner oracle、审计器 v2、CF07 parser/same-name method helper、resource guard 和 target scanner。也会保存 focused build receipt/runner/spec/raw，并记录其完整 source manifest 前后 pin。

工具可执行文件本体不进包：冻结 candidate CLI、JDK java/javac/javap 和已安装 JADX/JADX jar 仅作为路径/大小/SHA 外部引用保存。Focused build receipt 的 4860 项产品源码 closure 以完整 path/size/SHA manifest 记录，源码文件本身不复制，避免把整个仓库打进包。包内 `MANIFEST.json` 逐成员列 bytes/SHA；旁边 sidecar 额外覆盖包含 `MANIFEST.json` 在内的所有成员，并含压缩包 SHA。脚本写完会重新打开 tar.gz，核对成员集合和每个成员 bytes/SHA。

包内会如实保留当前 source-map 覆盖缺口：`handled` BCI 44；`tryStringBranch` / `tryIntegerBranch` BCI 40、60、79；`tryStringRemovePrefix` BCI 55；`tryStringNested` BCI 90；`tryStringUnknownCall` BCI 40。它们是有效指令边界但没有 source-map 覆盖，归档不声称完整指令覆盖。现有 accepted runtime/compile 结果来自独立 receipt；归档过程只验证和保存证据，不重跑、不改写观察结果。
