# Prepared observational EM11 quota trace

UNEXECUTED. Root alone runs GDB/CLI/JDK. This preparation read existing saved DT29 trace/strict elapsed audit and actual EM11 screen evidence, wrote only cache files, and parsed Python syntax without importing/executing the prepared runner.

Run cap1 first, then optionally cap2 in a fresh directory:

```sh
python3 /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/reference-overload-quota-trace-candidate-v1/run.py --cap 1 --out /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/reference-overload-quota-trace-candidate-v1/cap1-run-v1
python3 /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/reference-overload-quota-trace-candidate-v1/run.py --cap 2 --out /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/reference-overload-quota-trace-candidate-v1/cap2-run-v1
```

Preflight binds actual frozen CLI/build receipt, the exact screen receipt, derived JAR, actual original class bytes, ordinary cap JSON/stderr, original source/history, actual javap raw, GDB and support scripts to preparation-pins.json. It then checks current product source against all4905 actual build receipt entries and verifies exact CLI bytes/hash/0555 mode, stable source/clean receipt and absence of target. It records actual free-space and the existing guard envelope (5GiB minimum free/1GiB maximum target), default stack and per-command guard state/peak measurements.

The exact inferior argv is copied from the existing ordinary case, including all evidence/policy/release/budget options. GDB gets one Budget::exceeded breakpoint, silent marker, bt40 and continue. It never assigns a target variable, invokes a target function, fabricates an Error or changes a return. The inferior JSON/stdout and stderr are explicitly redirected to separate raw files. GDB stdout/stderr are separate guard streams. Inferior exit4 is checked independently from GDB exit0.

Each actual refusal yields an ordered raw stack block and booleans for observed reference-overload proof, selected typed dependency reader and snapshot proof frames. The candidate hypothesis (first refusal in reference-overload then later typed snapshot) is recorded as an observation, not hard-coded as a successful result. Missing frames or a different order must be independently analyzed; the full raw is retained. Capturing stacks successfully does not itself establish that hypothesis or classify a defect.

Strict comparison preserves the complete JSON and every limits field, ignoring only the ten actual usage.elapsed_millis leaf paths measured independently from each pinned ordinary EM11 cap report. It requires exactly those same leaf paths in the inferior JSON and exact ordinary/inferior stderr equality. It does not remove arbitrary elapsed_millis fields or weaken public result comparison. All before/after input/source pins and target absence are checked; failures remain saved.

Actual Code interpretation belongs to the saved javap raw: NEW HLeaf at BCI0, dup3, invokespecial constructor4 and invokestatic take(HMid)7. The old external NEW4 index is not used. The scope remains the seven original EM11 class byte checks and original Runner's five-line oracle; no whole Jarde generated-source compilation is claimed.
