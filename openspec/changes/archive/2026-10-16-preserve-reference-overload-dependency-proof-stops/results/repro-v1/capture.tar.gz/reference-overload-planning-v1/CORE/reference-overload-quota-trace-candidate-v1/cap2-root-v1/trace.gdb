set auto-load off
set debuginfod enabled off
set pagination off
set confirm off
set breakpoint pending off
set print thread-events off
set disable-randomization off
break '<jarde_reader::budget::Budget>::exceeded'
commands
silent
printf "EM11_QUOTA_REFUSAL\n"
bt 40
continue
end
run class-source --input /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/reference-overload-initial-screen-v1/run-v1/input.jar --class em11/InputHierarchyCalls --policy plain-jar --release 8 --format json --evidence all --budget elapsed_millis=10000 --budget class_headers=2 > /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/reference-overload-quota-trace-candidate-v1/cap2-root-v1/inferior.stdout.raw 2> /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/reference-overload-quota-trace-candidate-v1/cap2-root-v1/inferior.stderr.raw
printf "EM11_INFERIOR_EXIT=%d\n", $_exitcode
