from pathlib import Path
import argparse,hashlib,json,os,importlib.util,sys,zipfile
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
W=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde')
S=W/'openspec/evidence/java-syntax-2026-09-27/em11-overload-binding'
OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
CLI=B/'jarde-cli-direct-parent-proof-v1'; REC=B/'direct-parent-focused-root-v1/execution.json'
def pin(p):
 p=Path(p).resolve();z=p.read_bytes();return {'path':str(p),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();O=a.out.resolve();assert not O.exists() and O.parent==Path(__file__).resolve().parent
assert not (W/'target').exists();r=json.loads(REC.read_text());assert r['source_manifest_before']==r['source_manifest_after'] and len(r['source_manifest_before'])==4905 and r['target_absent'];q=pin(CLI);assert q['bytes']==r['frozen_cli']['bytes'] and q['sha256']==r['frozen_cli']['sha256'] and CLI.stat().st_mode&0o777==0o555
for x in r['source_manifest_before']:assert pin(W/x['path'])['sha256']==x['sha256']
history=S/'observed-after/results.json';hist=json.loads(history.read_text());sources=[S/'input/em11'/n for n in hist['input_source_sha256']]
assert len(sources)==7
for p in sources:assert pin(p)['sha256']==hist['input_source_sha256'][p.name]
jm=OLD/'tools/jdk-manifest.json';jd=json.loads(jm.read_text());tools=next(x for x in jd['legs'] if x['leg']=='javac23')['jdk_tools'];java=Path(tools['java']['path']).resolve();javac=Path(tools['javac']['path']).resolve();javap=javac.with_name('javap')
for k,p in [('java',java),('javac',javac)]:assert pin(p)['sha256']==tools[k]['sha256'] and pin(p)['bytes']==tools[k]['bytes']
gp=OLD/'tools-prep/guard.py';sp=OLD/'tools-prep/target_scan.py';g=load('em11_screen_guard',gp);sc=load('em11_screen_scan',sp)
inputs=[Path(__file__).resolve(),CLI,REC,history,jm,gp,sp,java,javac,javap,*sources];before=[pin(p) for p in inputs];O.mkdir();classes=O/'original-classes';classes.mkdir();g.ROOT=W;g.OUT=O;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.target_bytes=lambda:sc.target_bytes(W);g.expected_test_summaries=lambda i,z:None;g.command_stream=lambda p:pin(p);g.ENV_VALUES={}
env={k:v for k,v in os.environ.items() if k in ['HOME','LANG','LC_ALL','TMPDIR']};env['PATH']='/usr/bin:/bin';rows=[];doc={'schema':'reference-overload-initial-screen-v1','status':'running','scope':'Rebuild original seven EM11 Java inputs, compare actual classes to historical SHA, observe actual Code and original complete five-line Runner oracle; capture final aadf-source CLI wide and caps. No fix or stop-origin/tail claim.','cli_binding':{'receipt':pin(REC),'cli':q,'source_count':4905},'input_manifest_before':before,'commands':rows}
def save():
 p=O/'execution.json.tmp';p.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n');p.replace(O/'execution.json')
def run(label,argv,exits):
 row=g.run_command(len(rows)+1,[str(z) for z in argv],env);row['label']=label;rows.append(row);save();assert row['guard_stop'] is None and row['exit_code'] in exits,(label,row['exit_code']);return row
save()
try:
 run('javac23-original-seven-unchanged-sources',[javac,'--release','8','-g:none','-Xlint:-options','-d',classes,*sources],{0})
 measured={p.stem:pin(p) for p in sorted(classes.rglob('*.class'))};doc['actual_original_classes']=measured;doc['historical_class_match']={n:measured[n]['sha256']==sha for n,sha in hist['original_class_sha256'].items()};doc['all_seven_historical_class_bytes_match']=all(doc['historical_class_match'].values());save()
 row=run('java23-original-complete-Runner',[java,'-Xverify:all','-cp',classes,'em11.Runner'],{0});raw=Path(row['streams']['stdout']['path']).read_bytes();assert raw==hist['original']['stdout'].encode() and not Path(row['streams']['stderr']['path']).read_bytes();doc['original_runner_exact_five_line_oracle']=True
 run('javap-actual-InputHierarchyCalls-Code',[javap,'-p','-c','-s',classes/'em11/InputHierarchyCalls.class'],{0})
 jar=O/'input.jar'
 with zipfile.ZipFile(jar,'w',compression=zipfile.ZIP_STORED) as z:
  for p in sorted(classes.rglob('*.class')):
   i=zipfile.ZipInfo(p.relative_to(classes).as_posix(),date_time=(1980,1,1,0,0,0));i.compress_type=zipfile.ZIP_STORED;z.writestr(i,p.read_bytes())
 doc['new_container_with_actual_class_bytes']=pin(jar);matrix=[];doc['matrix']=matrix
 for cap in [4096,1,2,3,4]:
  row=run('InputHierarchyCalls-class-source-header-cap-'+str(cap),[CLI,'class-source','--input',jar,'--class','em11/InputHierarchyCalls','--policy','plain-jar','--release','8','--format','json','--evidence','all','--budget','elapsed_millis=10000','--budget','class_headers='+str(cap)],{0,4});obj=json.loads(Path(row['streams']['stdout']['path']).read_bytes());methods=[x for x in obj.get('methods',[]) if x.get('item',{}).get('name',{}).get('escaped')=='run'];one=methods[0] if len(methods)==1 else None
  matrix.append({'cap':cap,'exit':row['exit_code'],'class_execution':obj.get('execution'),'run':one,'report_pin':row['streams']['stdout']});save()
  if cap==4096:assert row['exit_code']==0 and obj['execution']['status']=='complete' and one is not None and 'take((em11.HMid) new em11.HLeaf())' in one['text']
 doc['input_manifest_after']=[pin(p) for p in inputs];assert before==doc['input_manifest_after'];assert all(pin(W/x['path'])['sha256']==x['sha256'] for x in r['source_manifest_before']);doc.update({'status':'captured_initial_screen_pending_independent_review_no_stop_origin_claim','inputs_identical':True,'source_count_after':4905,'target_absent':not (W/'target').exists()});save();print(json.dumps({'status':doc['status'],'class_match':doc['all_seven_historical_class_bytes_match'],'matrix':[(x['cap'],x['exit'],x['class_execution']['status']) for x in matrix]}))
except BaseException as error:
 doc['status']='failed_raw_preserved';doc['error']=str(error);save();raise
