#!/usr/bin/env python3
"""Cache-only EM11 planning evidence package; no captured command is executed."""
from pathlib import Path, PurePosixPath
import hashlib, io, json, tarfile
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015'); O=Path(__file__).resolve().parent
S=B/'CORE/reference-overload-initial-screen-v1'; T=B/'CORE/reference-overload-quota-trace-candidate-v1'; R=B/'CORE/reference-overload-next-slice-review-v1/recommendation.json'
def pin(p):
 p=Path(p).resolve(); z=p.read_bytes(); return {'path':str(p),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
def load(p): return json.loads(Path(p).read_text())
def check(q): assert pin(q['path'])=={k:q[k] for k in ('path','bytes','sha256')},q['path']
def norm(v,path='',removed=None):
 if isinstance(v,dict):
  result={}
  for k,x in v.items():
   if k=='elapsed_millis' and path.endswith('/usage') and isinstance(x,int): removed.append(path+'/'+k)
   else: result[k]=norm(x,path+'/'+k,removed)
  return result
 if isinstance(v,list): return [norm(x,path+'/'+str(i),removed) for i,x in enumerate(v)]
 return v
files=sorted({p.resolve() for folder in (S,T) for p in folder.rglob('*') if p.is_file()}|{R.resolve(),Path(__file__).resolve()})
assert pin(R)['sha256']=='9d997c9133cf0259488df11473878a5b92cda6f4e2a952a067c4ba7433ed299f'
screen=load(S/'run-v1/execution.json'); screen_audit=load(S/'run-v1/independent-audit-v1.json'); trace_audit=load(T/'independent-trace-audit-v1.json')
assert screen['status']=='captured_initial_screen_pending_independent_review_no_stop_origin_claim' and screen['inputs_identical'] and screen['target_absent']
assert screen['all_seven_historical_class_bytes_match'] and screen['original_runner_exact_five_line_oracle'] and len(screen['actual_original_classes'])==7
assert screen_audit['status']=='accepted_initial_screen_scope_only' and trace_audit['status']=='accepted_observation_scope_only' and trace_audit['errors']==[]
check(screen['new_container_with_actual_class_bytes'])
for q in screen['actual_original_classes'].values(): check(q)
receipts=[(S/'run-v1/execution.json',screen)]; traces=[]
for cap in (1,2):
 p=T/f'cap{cap}-root-v1/execution.json'; d=load(p); receipts.append((p,d)); traces.append(d)
 assert d['status']=='captured_actual_quota_stacks_and_strict_public_equivalence_pending_independent_review'
 assert d['inputs_identical'] and d['sources_identical'] and d['target_absent'] and d['source_count']==4905
 assert d['input_pins_before']==d['input_pins_after'] and d['source_manifest_before']==d['source_manifest_after']
 assert d['actual_inferior_exit_markers']==['4'] and d['limits_exactly_equal'] and d['normalized_whole_json_equals_ordinary']
 actual=load(d['inferior_streams']['stdout']['path']); ordinary=load(d['ordinary_case']['streams']['stdout']['path']); a=[]; b=[]
 assert norm(actual,removed=a)==norm(ordinary,removed=b) and a==b==d['ignored_only_actual_usage_elapsed_paths'] and len(a)==10
 assert actual['limits']==ordinary['limits'] and Path(d['inferior_streams']['stderr']['path']).read_bytes()==Path(d['ordinary_case']['streams']['stderr']['path']).read_bytes()
assert traces[0]['quota_refusal_markers']==2 and traces[0]['observed_first_reference_overload_then_later_typed_snapshot'] and traces[1]['quota_refusal_markers']==1
bound={}; external=[]
for rp,d in receipts:
 for command in d['commands']:
  assert set(command['streams'])=={'stdout','stderr'}
  for q in command['streams'].values(): check(q); assert q['path'] not in bound; bound[q['path']]=q
 for q in d.get('inferior_streams',{}).values(): check(q); assert q['path'] not in bound; bound[q['path']]=q
 for q in d.get('input_manifest_before',d.get('input_pins_before',[])):
  if Path(q['path']).resolve() in files: check(q)
  else: external.append(q)
assert {str(p) for p in files if p.suffix=='.raw'}==set(bound)
for q in load(R)['evidence']['pins']: check(q)
rows=[]; payload={}
for p in files:
 assert p.is_file() and not p.is_symlink() and p.is_relative_to(B)
 arc='reference-overload-planning-v1/'+str(p.relative_to(B)); assert not PurePosixPath(arc).is_absolute() and '..' not in PurePosixPath(arc).parts
 data=p.read_bytes(); assert not data.startswith((b'\x7fELF',b'MZ')) and arc not in payload
 rows.append({**pin(p),'archive_path':arc}); payload[arc]=data
manifest={'schema':'reference-overload-planning-evidence-v1','status':'packaged_and_reopened_verified','items':rows,'receipt_bound_raw_files':len(bound),'historical_receipts':[{'pin':pin(p),'status':d['status']} for p,d in receipts],'external_historical_input_pins':external,'cli_binding':screen['cli_binding'],'scope':'EM11 dynamic refused-charge stack order only: cap1 reference-overload then typed snapshot; cap2 typed snapshot. Error/Report catch path not dynamically verified; no fix, future implementation or CI evidence; no fresh compilation of complete Jarde generated source. Original seven class/Code and five-line Runner observations retain their limited historical scope. CLI/JDK/GDB/runtime/native executables and full workspace remain external.'}
mbytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode(); payload['reference-overload-planning-manifest.json']=mbytes
archive=O/'reference-overload-planning-evidence-v1.tar.gz'; assert not archive.exists()
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tar:
 for name,data in sorted(payload.items()):
  m=tarfile.TarInfo(name); m.size=len(data); m.mode=0o444; m.mtime=0; tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers(); assert len(members)==len(payload) and len({m.name for m in members})==len(members)
 assert all(m.isfile() for m in members) and {m.name for m in members}==set(payload)
 for m in members: assert tar.extractfile(m).read()==payload[m.name]
for row in rows: assert Path(row['path']).read_bytes()==payload[row['archive_path']]
(O/'manifest.json').write_bytes(mbytes)
execution={'status':'packaged_and_reopened_verified','archive':pin(archive),'manifest':pin(O/'manifest.json'),'packager':pin(Path(__file__)),'payload_files':len(rows),'tar_members':len(payload),'receipt_bound_raw_files':len(bound),'external_historical_pin_records':len(external),'scope':manifest['scope']}
(O/'execution.json').write_text(json.dumps(execution,ensure_ascii=False,indent=2)+'\n'); print(json.dumps(execution,ensure_ascii=False,indent=2))
