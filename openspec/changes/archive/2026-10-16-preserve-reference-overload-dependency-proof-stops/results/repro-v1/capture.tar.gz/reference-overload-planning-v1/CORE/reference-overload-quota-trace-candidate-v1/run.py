#!/usr/bin/env python3
"""Prepared observer-only EM11 quota trace; root alone may execute this runner."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, re, shlex, shutil, sys, zipfile
BASE = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
ROOT = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde')
HERE = Path(__file__).resolve().parent
PREPARATION = HERE / 'preparation-pins.json'
SCREEN = BASE / 'CORE/reference-overload-initial-screen-v1/run-v1/execution.json'
BUILD = BASE / 'direct-parent-focused-root-v1/execution.json'
CLI = BASE / 'jarde-cli-direct-parent-proof-v1'
GDB = Path('/usr/bin/gdb')
HELPER = BASE / 'interface-full-source-harness-v4/run_interface_full_source_harness.py'
GUARD = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/guard.py')
SCAN = GUARD.with_name('target_scan.py')
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3

def pin(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def normalize_actual_usage_elapsed(value, path='', removed=None):
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            child_path = path + '/' + key
            if key == 'elapsed_millis' and path.endswith('/usage') and isinstance(item, int):
                removed.append(child_path)
            else:
                result[key] = normalize_actual_usage_elapsed(item, child_path, removed)
        return result
    if isinstance(value, list):
        return [normalize_actual_usage_elapsed(item, path + '/' + str(i), removed)
                for i, item in enumerate(value)]
    return value

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cap', type=int, choices=(1, 2), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    if out.exists() or out.parent != HERE or (ROOT / 'target').exists():
        raise SystemExit('out must be a fresh direct child and repository target must be absent')
    free_before = shutil.disk_usage(ROOT).free
    if free_before < FREE_LIMIT:
        raise SystemExit('5 GiB free-space preflight failed')
    prepared = json.loads(PREPARATION.read_text())
    for expected in prepared['fixed_input_pins']:
        if pin(expected['path']) != expected:
            raise SystemExit(f'prepared input changed: {expected["path"]}')
    helper = load('em11_trace_binding_helper', HELPER)
    cli_binding = helper.verify_cli(CLI, BUILD)
    build = json.loads(BUILD.read_text())
    source = build['source_manifest_before']
    if len(source) != 4905 or source != build['source_manifest_after'] or not build['target_absent']:
        raise SystemExit('actual frozen CLI source binding/clean receipt differs')
    def source_pins():
        return [{'path': row['path'], 'bytes': pin(ROOT / row['path'])['bytes'],
                 'sha256': pin(ROOT / row['path'])['sha256']} for row in source]
    if source_pins() != source:
        raise SystemExit('current product source differs from the frozen CLI receipt')
    screen = json.loads(SCREEN.read_text())
    if (screen['status'] != 'captured_initial_screen_pending_independent_review_no_stop_origin_claim'
            or not screen['inputs_identical'] or not screen['target_absent']
            or not screen['all_seven_historical_class_bytes_match']
            or not screen['original_runner_exact_five_line_oracle']):
        raise SystemExit('actual EM11 screen preconditions differ')
    case = next(row for row in screen['commands']
                if row['label'] == f'InputHierarchyCalls-class-source-header-cap-{args.cap}')
    request = case['argv']
    if request[0] != str(CLI) or request[-1] != f'class_headers={args.cap}' or case['exit_code'] != 4:
        raise SystemExit('ordinary case does not bind the expected exact cap request and exit4')
    for expected in case['streams'].values():
        if pin(expected['path']) != expected:
            raise SystemExit('ordinary baseline raw differs from its actual screen receipt')
    jar_pin = screen['new_container_with_actual_class_bytes']
    if pin(jar_pin['path']) != jar_pin:
        raise SystemExit('actual seven-class derived JAR changed')
    with zipfile.ZipFile(jar_pin['path']) as jar:
        expected_entries = {'em11/' + name + '.class' for name in screen['actual_original_classes']}
        if set(jar.namelist()) != expected_entries:
            raise SystemExit('actual derived JAR class inventory changed')
        for name, expected in screen['actual_original_classes'].items():
            data = jar.read('em11/' + name + '.class')
            if len(data) != expected['bytes'] or hashlib.sha256(data).hexdigest() != expected['sha256']:
                raise SystemExit(f'actual original class bytes differ: {name}')
    out.mkdir()
    inferior_stdout, inferior_stderr = out / 'inferior.stdout.raw', out / 'inferior.stderr.raw'
    trace = out / 'trace.gdb'
    trace.write_text("set auto-load off\nset debuginfod enabled off\nset pagination off\nset confirm off\n"
                     "set breakpoint pending off\nset print thread-events off\nset disable-randomization off\n"
                     "break '<jarde_reader::budget::Budget>::exceeded'\ncommands\nsilent\n"
                     'printf "EM11_QUOTA_REFUSAL\\n"\nbt 40\ncontinue\nend\nrun '
                     + shlex.join(request[1:]) + ' > ' + shlex.quote(str(inferior_stdout))
                     + ' 2> ' + shlex.quote(str(inferior_stderr))
                     + '\nprintf "EM11_INFERIOR_EXIT=%d\\n", $_exitcode\n')
    inputs = [Path(row['path']) for row in prepared['fixed_input_pins']] + [PREPARATION, trace]
    before = [pin(path) for path in inputs]
    guard = load('em11_trace_guard', GUARD)
    scanner = load('em11_trace_scan', SCAN)
    guard.ROOT, guard.OUT = ROOT, out
    guard.FREE_LIMIT, guard.TARGET_LIMIT = FREE_LIMIT, TARGET_LIMIT
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.command_stream = lambda path: pin(Path(path))
    guard.expected_test_summaries = lambda _i, _data: None
    guard.ENV_VALUES = {}
    env = {key: value for key, value in os.environ.items() if key in ('HOME', 'LANG', 'LC_ALL', 'TMPDIR')}
    env['PATH'] = '/usr/bin:/bin'
    rows = []
    record = {'schema': 'reference-overload-observational-quota-trace-v1', 'status': 'running',
              'scope': 'Actual EM11 InputHierarchyCalls.run source-pinned input only; observation-only quota backtrace/continue. No variable assignment, return, fabricated error, Java modification, whole-Jarde-source compilation or defect classification.',
              'cap': args.cap, 'cli_binding': cli_binding, 'ordinary_case': case,
              'exact_inferior_argv': request, 'expected_inferior_exit': 4,
              'default_stack': True, 'RUST_MIN_STACK_in_inferior_environment': 'RUST_MIN_STACK' in env,
              'guards': {'minimum_free_bytes': FREE_LIMIT, 'maximum_target_bytes': TARGET_LIMIT},
              'preflight': {'free_bytes': free_before, 'target_absent': True},
              'input_pins_before': before, 'source_count': len(source),
              'source_manifest_before': source, 'commands': rows}
    def save():
        temp = out / 'execution.json.tmp'
        temp.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
        temp.replace(out / 'execution.json')
    save()
    try:
        for index, argv in enumerate(([str(GDB), '--version'],
                                     [str(GDB), '--batch', '--nx', '-x', str(trace), '--args', *request]), 1):
            row = guard.run_command(index, argv, env)
            row['argv_exact'] = argv
            row['guard_status'] = 'clear' if row.get('guard_stop') is None else 'stopped'
            rows.append(row); save()
            if row['exit_code'] != 0 or row['guard_stop'] is not None:
                raise RuntimeError('GDB command failed or guard stopped; raw retained')
        output = Path(rows[-1]['streams']['stdout']['path']).read_text()
        blocks = output.split('EM11_QUOTA_REFUSAL\n')[1:]
        stacks = []
        for index, block in enumerate(blocks, 1):
            stack = block.split('EM11_INFERIOR_EXIT=', 1)[0]
            stacks.append({'ordinal': index, 'raw_stack_block': stack,
                           'contains_reference_overload_proof': 'prove_reference_overload_calls' in stack,
                           'contains_typed_dependency_reader': 'selected_dependency_proof_header' in stack,
                           'contains_snapshot_proof': 'prove_snapshot_hierarchy_widenings' in stack})
        exits = re.findall(r'EM11_INFERIOR_EXIT=(\d+)', output)
        record.update({'quota_refusal_markers': len(stacks), 'ordered_quota_stacks': stacks,
                       'actual_inferior_exit_markers': exits,
                       'inferior_streams': {name: pin(path) for name, path in
                                            [('stdout', inferior_stdout), ('stderr', inferior_stderr)]}})
        if not stacks or exits != ['4']:
            raise RuntimeError('actual quota stack or exact inferior exit4 not established')
        actual = json.loads(inferior_stdout.read_bytes())
        baseline = json.loads(Path(case['streams']['stdout']['path']).read_bytes())
        actual_removed, baseline_removed = [], []
        same = (normalize_actual_usage_elapsed(actual, removed=actual_removed)
                == normalize_actual_usage_elapsed(baseline, removed=baseline_removed))
        expected_paths = prepared['ordinary_actual_usage_elapsed_paths'][str(args.cap)]
        record.update({'limits_exactly_equal': actual.get('limits') == baseline.get('limits'),
                       'ignored_only_actual_usage_elapsed_paths': actual_removed,
                       'normalized_whole_json_equals_ordinary': same,
                       'inferior_stderr_exactly_equals_ordinary': inferior_stderr.read_bytes() == Path(case['streams']['stderr']['path']).read_bytes(),
                       'actual_class_execution': actual.get('execution')})
        if (not same or actual_removed != baseline_removed or actual_removed != expected_paths
                or not record['limits_exactly_equal'] or not record['inferior_stderr_exactly_equals_ordinary']):
            raise RuntimeError('strict ordinary/trace JSON or stderr equivalence failed')
        first_reference = stacks[0]['contains_reference_overload_proof']
        later_snapshot = any(stack['contains_snapshot_proof'] and stack['contains_typed_dependency_reader']
                             for stack in stacks[1:])
        record['observed_first_reference_overload_then_later_typed_snapshot'] = first_reference and later_snapshot
        record['status'] = 'captured_actual_quota_stacks_and_strict_public_equivalence_pending_independent_review'
    except BaseException as error:
        record['status'] = 'failed_preserved_observation'
        record['error'] = f'{type(error).__name__}: {error}'
    finally:
        record['input_pins_after'] = [pin(path) for path in inputs]
        record['source_manifest_after'] = source_pins()
        record['inputs_identical'] = record['input_pins_after'] == before
        record['sources_identical'] = record['source_manifest_after'] == source
        record['target_absent'] = not (ROOT / 'target').exists()
        record['free_bytes_after'] = shutil.disk_usage(ROOT).free
        if not record['inputs_identical'] or not record['sources_identical'] or not record['target_absent']:
            record['status'] = 'failed_preserved_integrity_or_target'
        save()
    if record['status'] != 'captured_actual_quota_stacks_and_strict_public_equivalence_pending_independent_review':
        raise SystemExit(1)
    print(json.dumps({'status': record['status'], 'cap': args.cap,
                      'quota_hits': record['quota_refusal_markers'],
                      'actual_inferior_exit': record['actual_inferior_exit_markers'],
                      'observed_first_reference_overload_then_later_typed_snapshot': record['observed_first_reference_overload_then_later_typed_snapshot']}))

if __name__ == '__main__':
    main()
