from pathlib import Path
import os,sys,json,hashlib,shutil,importlib.util,re,datetime
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');H=Path(__file__).resolve().parent;W=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');O=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep');OUT=H/'run-v1';OUT.mkdir(exist_ok=False);FP=W/'tests/fixtures/corpus-fingerprint.json';CLI=B/'jarde-cli-reference-overload-fingerprint-v2'
def pin(p):
 p=Path(p);z=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
assert not(W/'target').exists() and not CLI.exists() and shutil.disk_usage(W).free>=5*1024**3
build=json.loads((B/'reference-overload-final-focused-v1/execution.json').read_text());oldsrc=build['source_manifest_before'];assert oldsrc==build['source_manifest_after'] and len(oldsrc)==4907
paths=[W/q['path'] for q in oldsrc]
def sources():return [{'path':str(p.relative_to(W)),'bytes':pin(p)['bytes'],'sha256':pin(p)['sha256']} for p in paths]
assert sources()==oldsrc
shutil.copyfile(FP,H/'corpus-fingerprint-before.json');old=json.loads(FP.read_text());assert len(old['files'])==2219
jar=W/'tests/fixtures/em11-reference-overload.jar';assert pin(jar)['sha256']=='7f424cfedc412c210679cf2d36377bc94b1fb599217b41e8dd4e6fbf0129b9e2'
g=load('fingerprint_guard',O/'guard.py');sc=load('fingerprint_scan',O/'target_scan.py');g.ROOT=W;g.OUT=OUT;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.target_bytes=lambda:sc.target_bytes(W);g.expected_test_summaries=lambda i,z:None;g.command_stream=pin
env=os.environ.copy()
for k in ['JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','RUST_MIN_STACK','CARGO_TARGET_DIR']:env.pop(k,None)
env.update(g.ENV_VALUES);env['RUSTUP_TOOLCHAIN']='stable';env['PATH']='/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jdk23/jdk-23.0.1/bin:/home/lordcasser/.cargo/bin:/usr/bin:/bin';env['JAVA_HOME']='/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jdk23/jdk-23.0.1'
r={'schema':'intentional-fixture-fingerprint-maintenance-v1','status':'running','default_stack':True,'maintenance_source_manifest_before':oldsrc,'maintenance_manifest_before':pin(FP),'runner':pin(H/'run.py'),'guard':{'minimum_free_bytes':5*1024**3,'maximum_target_bytes':1024**3},'dependencies':{'guard':pin(O/'guard.py'),'target_scan':pin(O/'target_scan.py')},'environment':g.ENV_VALUES,'commands':[],'frozen_cli':None,'scope':'Explicit intended fixture regenerator, exact one-entry semantic diff, normal fingerprint suite and fresh CLI. Original failed ba3f CI retained. Final source_manifest_before/after binds only post-regeneration tests/build; intentional maintenance-before is separate.'}
def save():(OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,a,summary=None):
 q=g.run_command(len(r['commands'])+1,a,env);q['label']=label;q['expected_exit_code']=0;r['commands'].append(q);save();assert q['exit_code']==0 and q['guard_stop'] is None,label
 if summary is not None:
  t=Path(q['streams']['stdout']['path']).read_text();s=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t);q['actual_test_summaries']=[list(v) for v in s];assert len(s)==1 and [int(x) for x in s[0][1:]]==summary and s[0][0]=='ok';save()
 return q
save()
try:
 run('explicit-intended-corpus-regenerator',['cargo','test','--test','p5_corpus_fingerprint','--locked','--','--ignored','--exact','regenerate_corpus_fingerprint','--nocapture'],[1,0,0])
 new=json.loads(FP.read_text());assert {k:v for k,v in new.items() if k!='files'}=={k:v for k,v in old.items() if k!='files'}
 om={q['path']:q for q in old['files']};nm={q['path']:q for q in new['files']};assert len(nm)==len(new['files'])==2220 and len(om)==2219;assert set(nm)-set(om)=={'tests/fixtures/em11-reference-overload.jar'} and set(om)<=set(nm) and all(nm[k]==v for k,v in om.items())
 expected={'path':'tests/fixtures/em11-reference-overload.jar','bytes':5001,'blake3':'c839f8988b1ed46a757b89bb6188550761011e77a7f7789f3412d4f0f81fee97'};assert nm[expected['path']]==expected
 changed=[q['path'] for q,o in zip(sources(),oldsrc) if q!=o];assert changed==['tests/fixtures/corpus-fingerprint.json']
 r['intentional_semantic_diff']={'added':[expected],'removed':[],'changed_existing':[],'all_nonfiles_fields_identical':True,'old_count':2219,'new_count':2220};r['maintenance_manifest_after']=pin(FP);r['source_manifest_before']=sources();shutil.copyfile(FP,H/'corpus-fingerprint-after.json');save()
 run('normal-corpus-fingerprint-suite',['cargo','test','--test','p5_corpus_fingerprint','--locked'],[5,0,1]);assert sources()==r['source_manifest_before']
 q=run('build-cli',['cargo','build','-p','jarde-cli','--bin','jarde-cli','--locked','--message-format=json-render-diagnostics']);events=[json.loads(x) for x in Path(q['streams']['stdout']['path']).read_text().splitlines() if x.startswith('{')];arts=[x for x in events if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='jarde-cli' and x.get('executable')];assert len(arts)==1;r['native_cli_compiler_artifact']=arts[0];built=W/'target/debug/jarde-cli';assert Path(arts[0]['executable']).resolve()==built.resolve();shutil.copyfile(built,CLI);CLI.chmod(0o555);r['cli']=pin(CLI);r['frozen_cli']={**pin(CLI),'mode':'0555','built_from':'target/debug/jarde-cli'};assert sources()==r['source_manifest_before'];r['status']='expected_command_outcomes_observed_pending_independent_acceptance'
except BaseException as e:r['status']='failed';r['error']=repr(e)
finally:
 g.FREE_LIMIT=0;g.TARGET_LIMIT=sys.maxsize;q=g.run_command(len(r['commands'])+1,['cargo','clean'],env);q['label']='finally-exact-cargo-clean';q['cleanup_only']={'exact_argv':['cargo','clean']};r['commands'].append(q);r['source_manifest_after']=sources();r['target_absent']=not(W/'target').exists();r['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 if q['exit_code']!=0 or q['guard_stop'] is not None or not r['target_absent'] or ('source_manifest_before' in r and r['source_manifest_before']!=r['source_manifest_after']):r['status']='failed';r['finalization_error']='clean/final-source integrity failed'
 save()
print(r['status'],len(r['commands']),r.get('frozen_cli'));raise SystemExit(0 if r['status']=='expected_command_outcomes_observed_pending_independent_acceptance' else 1)
