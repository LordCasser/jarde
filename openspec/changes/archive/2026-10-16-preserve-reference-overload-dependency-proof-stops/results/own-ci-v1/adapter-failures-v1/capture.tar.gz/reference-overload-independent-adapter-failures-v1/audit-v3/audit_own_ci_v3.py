#!/usr/bin/env python3
"""Independent offline audit of the fingerprint-successor reference-overload own-CI capture; reads capture/logs only."""
from __future__ import annotations
import hashlib, json, re, sys, zipfile
from pathlib import Path, PurePosixPath

BASE = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
CAP = BASE / 'own-ci-reference-overload-fingerprint-root-v3'
ACCEPT = BASE / 'reference-overload-fingerprint-own-ci-root-acceptance-v4.json'
SOURCE_BINDING = BASE / 'reference-overload-fingerprint-product-commit-source-binding-v2.json'
GATES = BASE / 'reference-overload-future-own-ci-gates-v2.json'
OLD55 = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/workspace-forward-v10/root-acceptance.json')
AUDIT_ARGV = BASE / 'reference-overload-fingerprint-own-ci-audit-argv-v4.json'
EXTRA = None  # prior121 and new11 are pinned in GATES
BASE_GATES = None  # prior121 is pinned in GATES
WORKFLOW = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde/.github/workflows/ci.yml')
OUT = Path(__file__).with_name('audit-result-v3.json')
PRIOR_ATTEMPT = BASE / 'CORE/reference-overload-fingerprint-ci-capture-recovery-v1/preserved-partial-v2.json'
HEAD = '82611166fc0b8a2e3a8d925e7a3e9f12738c0f87'
assert len(HEAD) == 40
BRANCH = 'codex/reference-overload-proof-stops'
RUN = 38721617088
SEEDS = ['5350648285461741569', '5350648285461741570']


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_pin(p: Path) -> dict:
    if p.is_symlink() or not p.is_file():
        raise ValueError(f'not a regular non-symlink file: {p}')
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': sha(data)}


def read_json(p: Path):
    return json.loads(p.read_text(encoding='utf-8'))


def require(ok: bool, msg: str, checks: list[str], errors: list[str]):
    checks.append(msg)
    if not ok:
        errors.append(msg)


def main() -> int:
    if OUT.exists():
        raise SystemExit(f'refusing overwrite: {OUT}')
    if not ACCEPT.is_file():
        raise SystemExit('root acceptance is not present yet; audit is intentionally not run')
    checks: list[str] = []
    errors: list[str] = []
    acceptance = read_json(ACCEPT)
    capture_path = CAP / 'execution.json'
    cap = read_json(capture_path)
    predecessor_failed = read_json(BASE / 'own-ci-reference-overload-ba3f-root-v1/execution.json')
    prior_attempt = read_json(PRIOR_ATTEMPT)
    prior_attempt_raw = [file_pin(Path(row['path'])) for row in prior_attempt.get('old_files', [])]
    prior_attempt_ok = len(prior_attempt_raw) == len(prior_attempt.get('old_files', [])) and all((pin['bytes'], pin['sha256']) == (row.get('bytes'), row.get('sha256')) for pin, row in zip(prior_attempt_raw, prior_attempt.get('old_files', [])))
    require(prior_attempt_ok and 'network error' in prior_attempt.get('reason', ''), 'preserved v2 partial capture pins verify as a separate failed capture attempt', checks, errors)
    require(predecessor_failed.get('product_sha') == 'ba3fa76af4241304ce06fdf2722355826c80402b' and predecessor_failed.get('run_id') == 38717487054 and predecessor_failed.get('conclusion') == 'failure', 'the prior ba3f CI failure remains a separate historical run', checks, errors)
    future_gates = read_json(GATES)
    workflow_bytes = WORKFLOW.read_bytes()
    workflow = workflow_bytes.decode('utf-8')
    binding = read_json(SOURCE_BINDING)

    require(acceptance.get('status') == 'accepted_exact_product_ci' and acceptance.get('errors') == [], 'root auditor accepted exact product CI without errors', checks, errors)
    require(acceptance.get('product_sha') == HEAD and acceptance.get('branch') == BRANCH and acceptance.get('run_id') == RUN, 'root acceptance head/branch/run binding', checks, errors)
    require(cap.get('status') == 'captured_pending_root_acceptance' and cap.get('product_sha') == HEAD and cap.get('run_id') == RUN and cap.get('run_status') == 'completed' and cap.get('conclusion') == 'success', 'capture terminal status and exact product identity', checks, errors)
    require(binding.get('own_ci_run') == RUN and binding.get('own_ci_accepted') is False, 'product source binding identifies this exact own-CI run after root updates the pending source receipt', checks, errors)
    require(binding.get('status') == 'accepted_clean_committed_product_exact_frozen_source' and binding.get('head') == HEAD and binding.get('branch') == BRANCH and binding.get('source_count') == 4907 and binding.get('target_absent') is True and binding.get('all_source_bytes_and_git_blobs_match') is True, 'source receipt binds frozen 4907-file fingerprint successor tree', checks, errors)
    source_execution = read_json(BASE / 'CORE/reference-overload-fingerprint-maintenance-v1/run-v1/execution.json')
    prior_manifest = source_execution.get('maintenance_source_manifest_before', [])
    current_before = source_execution.get('source_manifest_before', [])
    current_after = source_execution.get('source_manifest_after', [])
    prior_by_path = {x.get('path'): (x.get('bytes'), x.get('sha256')) for x in prior_manifest}
    current_by_path = {x.get('path'): (x.get('bytes'), x.get('sha256')) for x in current_before}
    changed_paths = sorted(k for k in set(prior_by_path) | set(current_by_path) if prior_by_path.get(k) != current_by_path.get(k))
    require(len(prior_manifest) == 4907 and len(current_before) == 4907 and len(current_after) == 4907, 'fingerprint maintenance and committed source receipts each cover 4907 files', checks, errors)
    require(current_before == current_after, 'post-regeneration source closure is byte-identical before/after the frozen build', checks, errors)
    require(len(prior_by_path) == 4907 and len(current_by_path) == 4907, 'prior/current source manifests have unique paths', checks, errors)
    require(changed_paths == ['tests/fixtures/corpus-fingerprint.json'], 'the fixture fingerprint is the sole source change from the failed ba3f tree', checks, errors)
    old_fp = source_execution.get('maintenance_manifest_before', {})
    new_fp = source_execution.get('maintenance_manifest_after', {})
    require(prior_by_path.get('tests/fixtures/corpus-fingerprint.json') == (old_fp.get('bytes'), old_fp.get('sha256')) and current_by_path.get('tests/fixtures/corpus-fingerprint.json') == (new_fp.get('bytes'), new_fp.get('sha256')), 'source diff agrees with the exact old/new corpus fingerprint pins', checks, errors)
    require((old_fp.get('bytes'), old_fp.get('sha256')) == (487684, '04e819424f8771b2272f4b089586a79afbdb1bb2779ebd2da757c69cfe62f6bc') and (new_fp.get('bytes'), new_fp.get('sha256')) == (487861, 'ef257554d3ad1f61b62a955fd11c3dde240daa321111252fd6b45cff116c5b46'), 'fingerprint refresh pins the sole expected 177-byte manifest change', checks, errors)
    old_binding = read_json(BASE / 'reference-overload-product-commit-source-binding-v1.json')
    old_cli = old_binding.get('frozen_cli', {})
    new_cli = binding.get('frozen_cli', {})
    require(old_cli.get('bytes') == new_cli.get('bytes') == 59657968 and old_cli.get('sha256') == new_cli.get('sha256') == 'c44bde2cdbbf32f70a29bef345c19f11b86229b2e399a0936ed90c1a264fa396', 'successor frozen CLI is byte-identical to the failed-product CLI pin', checks, errors)
    actual_cli = file_pin(Path(new_cli.get('path', '')))
    require(actual_cli.get('bytes') == new_cli.get('bytes') and actual_cli.get('sha256') == new_cli.get('sha256'), 'successor frozen CLI file matches its committed source binding pin', checks, errors)
    require(binding.get('build_receipt') == str(BASE / 'CORE/reference-overload-fingerprint-maintenance-v1/run-v1/execution.json'), 'source binding references the exact post-regeneration frozen build receipt', checks, errors)
    wfrow = next((x for x in source_execution.get('source_manifest_before', []) if x.get('path') == '.github/workflows/ci.yml'), {})
    wfafter = next((x for x in source_execution.get('source_manifest_after', []) if x.get('path') == '.github/workflows/ci.yml'), {})
    require(wfrow == wfafter and wfrow.get('bytes') == 17361 and wfrow.get('sha256') == 'b545890a55cc4fda31d70b332889c111d789afbf0949581e96bf2b94ea6cd18a', 'workflow pin is stable across the frozen focused build source manifest', checks, errors)
    require(len(workflow_bytes) == wfrow.get('bytes') and sha(workflow_bytes) == wfrow.get('sha256'), 'captured workflow bytes match the frozen product source pin', checks, errors)
    require(source_execution.get('target_absent') is True, 'focused build receipt records target absent after frozen build', checks, errors)
    for rel, pin in future_gates.get('current_source_pins', {}).items():
        actual = file_pin(Path(pin.get('path', '')))
        require(actual.get('bytes') == pin.get('bytes') and actual.get('sha256') == pin.get('sha256'), f'committed product source matches inventory pin: {rel}', checks, errors)
    require(future_gates.get('planned_strict_openspec_only', {}).get('items') == 365, 'inventory records the expected 365 strict OpenSpec item count', checks, errors)

    observations = cap.get('observations', [])
    require(bool(observations), 'capture has positive actual API observation count', checks, errors)
    raw_paths: set[str] = set()
    raw_pins = []
    for i, obs in enumerate(observations):
        require(obs.get('exit_code') == 0, f'API observation {i} exited zero', checks, errors)
        streams = obs.get('streams', {})
        require(set(streams) == {'stdout', 'stderr'}, f'API observation {i} has exactly stdout/stderr pins', checks, errors)
        for kind, pin in streams.items():
            p = Path(pin.get('path', '')).resolve()
            inside = p.is_relative_to(CAP.resolve())
            require(inside and str(p) not in raw_paths, f'API observation {i} {kind} raw is unique and inside capture', checks, errors)
            if inside and str(p) not in raw_paths:
                raw_paths.add(str(p))
            try:
                actual = file_pin(p)
                matched = actual['bytes'] == pin.get('bytes') and actual['sha256'] == pin.get('sha256')
            except Exception:
                actual, matched = {}, False
            require(matched, f'API observation {i} {kind} raw bytes/SHA match', checks, errors)
            if matched:
                raw_pins.append(actual)
    require(len(raw_paths) == 2 * len(observations), 'raw stream count derives as two unique streams per actual API observation', checks, errors)
    run_ep = f'repos/LordCasser/jarde/actions/runs/{RUN}'
    jobs_ep = run_ep + '/jobs?per_page=100'
    logs_ep = f'repos/LordCasser/jarde/actions/runs/{RUN}/logs'
    require(len(observations) >= 3 and len(observations) % 2 == 1, 'capture has one or more poll pairs plus terminal logs API observation', checks, errors)
    for i in range(0, max(0, len(observations) - 1), 2):
        pair = observations[i:i+2]
        require(len(pair) == 2 and pair[0].get('endpoint') == run_ep and pair[1].get('endpoint') == jobs_ep, f'API poll pair {i//2} is run then jobs', checks, errors)
        if len(pair) == 2:
            try:
                poll_run = read_json(Path(pair[0]['streams']['stdout']['path']))
                poll_jobs = read_json(Path(pair[1]['streams']['stdout']['path']))
                good_run = poll_run.get('id') == RUN and poll_run.get('head_sha') == HEAD and poll_run.get('head_branch') == BRANCH and poll_run.get('event') == 'push'
                good_jobs = isinstance(poll_jobs.get('jobs'), list)
            except Exception:
                good_run = good_jobs = False
            require(good_run, f'API poll {i//2} is bound to exact fingerprint-successor push run', checks, errors)
            require(good_jobs, f'API poll {i//2} has a parseable jobs response', checks, errors)
    terminal = observations[-3:] if len(observations) >= 3 else []
    require([x.get('endpoint') for x in terminal] == [run_ep, jobs_ep, logs_ep], 'terminal API responses are final run/jobs/logs in order', checks, errors)
    final_run = read_json(Path(terminal[0]['streams']['stdout']['path'])) if terminal else {}
    final_jobs = read_json(Path(terminal[1]['streams']['stdout']['path'])) if terminal else {}
    require(final_run.get('id') == RUN and final_run.get('head_sha') == HEAD and final_run.get('head_branch') == BRANCH and final_run.get('event') == 'push' and final_run.get('status') == 'completed' and final_run.get('conclusion') == 'success', 'terminal run API says exact successful push commit', checks, errors)
    require(final_jobs.get('jobs') == cap.get('jobs') and len(final_jobs.get('jobs', [])) == 4, 'terminal jobs API equals captured four-job receipt', checks, errors)

    jobs = final_jobs.get('jobs', [])
    require(len(jobs) == 4 and {x.get('name') for x in jobs} == {'stable / test and specification', 'MSRV 1.88.0', 'supply chain', 'fuzz smoke'}, 'four workflow jobs are present by exact workflow job names', checks, errors)
    step_total = sum(len(x.get('steps', [])) for x in jobs)
    require(step_total == 52, 'terminal jobs contain exactly 52 steps', checks, errors)
    for job in jobs:
        require(job.get('status') == 'completed' and job.get('conclusion') == 'success', f'job passed: {job.get("name")}', checks, errors)
        for step in job.get('steps', []):
            require(step.get('status') == 'completed' and step.get('conclusion') in ('success', 'skipped'), f'step completed successfully or skipped: {job.get("name")} / {step.get("name")}', checks, errors)

    log_pin = cap.get('logs', {})
    zip_path = CAP / 'logs.zip'
    zpin = file_pin(zip_path)
    require(log_pin.get('path') == str(zip_path) and log_pin.get('bytes') == zpin['bytes'] and log_pin.get('sha256') == zpin['sha256'], 'downloaded logs ZIP matches terminal capture pin', checks, errors)
    try:
        with zipfile.ZipFile(zip_path) as zf:
            infos = zf.infolist()
            names = [x.filename for x in infos]
            require(len(names) == len(set(names)), 'CI log ZIP member names are unique', checks, errors)
            member_pins = []
            for info in infos:
                pp = PurePosixPath(info.filename)
                mode = (info.external_attr >> 16) & 0o170000
                safe = not info.is_dir() and not pp.is_absolute() and '..' not in pp.parts and mode in (0, 0o100000)
                require(safe, f'CI log ZIP member is a safe regular file: {info.filename}', checks, errors)
                data = zf.read(info)
                member_pins.append({'path': info.filename, 'bytes': len(data), 'sha256': sha(data)})
            ansi = re.compile(r'\x1b\[[0-9;]*m')
            api_jobs = {x.get('name'): x for x in jobs}
            job_for_prefix = {
                'stable _ test and specification/': 'stable / test and specification',
                'MSRV 1.88.0/': 'MSRV 1.88.0',
                'supply chain/': 'supply chain',
                'fuzz smoke/': 'fuzz smoke',
            }
            command_by_title = {
                'Install stable Rust with lint': 'dtolnay/rust-toolchain@master',
                'Install Temurin 25.0.4+7': 'actions/setup-java@v6.0.1',
                'Install Node.js 22': 'actions/setup-node@v7.0.0',
                'Check formatting': 'cargo fmt --all -- --check',
                'Run Clippy': 'cargo clippy --workspace --all-targets --all-features --locked',
                'Validate OpenSpec strictly': 'openspec validate --all --strict --no-interactive',
                'Ensure tracked files remain unchanged': 'git diff --exit-code',
                'Install Rust 1.88.0': 'dtolnay/rust-toolchain@master',
                'Check workspace on MSRV': 'cargo check --workspace --all-targets --locked',
                'Check root workspace advisories, licenses, bans, and sources': 'cargo deny --all-features --workspace --locked --config ./deny.toml --manifest-path ./Cargo.toml check',
                'Check fuzz workspace advisories, licenses, bans, and sources': 'cargo deny --all-features --workspace --locked --config ./deny.toml --manifest-path ./fuzz/Cargo.toml check',
                'Install cargo-fuzz 0.13.2': 'cargo install cargo-fuzz --version 0.13.2 --locked',
                'Install nightly-2026-07-20': 'dtolnay/rust-toolchain@master',
                'Run the bounded query smoke': 'cargo +nightly-2026-07-20 fuzz run query',
                'Run the bounded artifact-tree smoke': 'cargo +nightly-2026-07-20 fuzz run artifact_tree',
                'Run the bounded method-analysis smoke': 'cargo +nightly-2026-07-20 fuzz run method_analysis',
                'Run ignored JDK 25 instruction-boundary oracle': 'cargo test --test jvm_bytecode_oracle --locked -- --ignored --exact jdk25_instruction_boundaries_match_public_bytecode_inspection',
                'Run the ignored P3 Java 8 compile-and-execute comparison': 'cargo test --test p3_execution_comparison --locked -- --ignored',
                'Run the functional-constructor full-class comparison': 'cargo test -p jarde-cli --test json_cli --locked -- --ignored --exact functional_constructor_arguments_replay_the_complete_class_on_both_jdks',
                'Run the BigDecimal Number full-class comparisons': 'cargo test --test p3_bigdecimal_number_widening --locked -- --ignored',
                'Run the nested int array full-class comparisons': 'cargo test --test p3_nested_int_array_compound_updates --locked -- --ignored --exact nested_int_array_updates_match_the_frozen_runner_oracle',
                'Run the returned int array full-class comparison': 'cargo test --test p3_nested_int_array_compound_updates --locked -- --ignored --exact returned_int_array_updates_compile_and_execute_as_a_complete_class',
                'Run public API example': 'cargo run --example inspect_class_header --locked',
                'Check resolved feature tree': 'cargo tree --workspace --all-features --locked -e features',
                'Check normal dependency tree boundary': 'cargo tree --workspace --all-features --locked -e normal',
                'Run workspace tests with two fixed independent seeds (pass 1)': 'cargo test --workspace --all-targets --all-features --locked',
                'Run workspace tests with two fixed independent seeds (pass 2)': 'cargo test --workspace --all-targets --all-features --locked',
            }
            selected_log_cache = {}
            log_segments = []
            def step_text(prefix: str, title: str) -> str:
                job_name = job_for_prefix.get(prefix)
                api_job = api_jobs.get(job_name)
                require(api_job is not None, f'API job exists for {prefix}', checks, errors)
                if api_job is None: return ''
                member_candidates = []
                for n in names:
                    if not n.endswith('.txt') or n.endswith('/system.txt'): continue
                    raw = zf.read(n).decode('utf-8-sig', errors='replace')
                    completions = re.findall(r'^.*?Complete job name: (.+)$', raw, re.M)
                    if completions == [job_name]: member_candidates.append((n, ansi.sub('', raw)))
                require(len(member_candidates) == 1, f'unique combined job log for {job_name}', checks, errors)
                if len(member_candidates) != 1: return ''
                member, text = member_candidates[0]
                api_matches = [x for x in api_job.get('steps', []) if x.get('name') == title]
                if not api_matches: api_matches = [x for x in api_job.get('steps', []) if title in x.get('name', '')]
                require(len(api_matches) == 1, f'unique API step for {title}', checks, errors)
                if len(api_matches) != 1: return ''
                api_step = api_matches[0]
                require(api_step.get('status') == 'completed' and api_step.get('conclusion') == 'success', f'API step succeeded: {title}', checks, errors)
                command = command_by_title.get(title)
                if command is None:
                    require(False, f'no frozen command selector for {title}', checks, errors); return ''
                group_re = re.compile(r'^(\d{4}-\d{2}-\d{2}T[^ ]+Z) ##\[group\]Run (.*)$', re.M)
                candidates = []
                start_sec, end_sec = api_step['started_at'][:19], api_step['completed_at'][:19]
                for match in group_re.finditer(text):
                    if match.group(2) == command or (title == 'Run Clippy' and match.group(2).startswith(command)):
                        if start_sec <= match.group(1)[:19] <= end_sec: candidates.append(match)
                require(len(candidates) == 1, f'unique exact Run command boundary inside API step: {title}', checks, errors)
                if len(candidates) != 1: return ''
                match = candidates[0]
                # Match the balanced GitHub group, including nested groups, instead of trusting root's segment offsets.
                group_token = re.compile(r'^\d{4}-\d{2}-\d{2}T[^ ]+Z (##\[(?:group|endgroup)\])', re.M)
                depth = 0; end = None; seen_start = False
                for tok in group_token.finditer(text, match.start()):
                    if tok.start() == match.start(): seen_start = True
                    if not seen_start: continue
                    if tok.group(1) == '##[group]': depth += 1
                    else:
                        depth -= 1
                        if depth == 0: end = tok.end(); break
                require(end is not None, f'balanced endgroup for command boundary: {title}', checks, errors)
                if end is None: return ''
                segment = text[match.start():end]
                stamps = re.findall(r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})[^ ]* ', segment, re.M)
                require(bool(stamps) and min(stamps) >= start_sec and max(stamps) <= end_sec, f'command segment timestamps fit API second bounds: {title}', checks, errors)
                log_segments.append({'api_job':job_name,'api_step':title,'member':member,'decoded_char_start':match.start(),'decoded_char_end':end,'command_header':match.group(2),'sha256':sha(segment.encode())})
                return segment
            def contains(text: str, needle: str, label: str):
                require(needle in text, label, checks, errors)
            stable_prefix = 'stable _ test and specification/'
            stable_rust = step_text(stable_prefix, 'Install stable Rust with lint')
            contains(stable_rust, 'rustc 1.99.0 (b940084d7', 'native stable Rust toolchain is 1.99.0')
            java = step_text(stable_prefix, 'Install Temurin 25.0.4+7')
            contains(java, 'Version: 25.0.4+7.0.LTS', 'native Temurin version is 25.0.4+7.0.LTS')
            node = step_text(stable_prefix, 'Install Node.js 22')
            contains(node, 'node: v22.', 'native Node.js major version is 22')
            msrv = step_text('MSRV 1.88.0/', 'Install Rust 1.88.0')
            contains(msrv, 'rustc 1.88.0 (6b00bc388', 'MSRV toolchain is Rust 1.88.0')

            strict = step_text(stable_prefix, 'Validate OpenSpec strictly')
            contains(strict, 'openspec validate --all --strict --no-interactive', 'strict validation command is present')
            contains(strict, 'Totals: 365 passed, 0 failed (365 items)', 'fingerprint successor strict CI snapshot is exactly 365/0')
            clean = step_text(stable_prefix, 'Ensure tracked files remain unchanged')
            contains(clean, 'git diff --exit-code', 'tracked-tree cleanliness command ran')
            fmt = step_text(stable_prefix, 'Check formatting')
            contains(fmt, 'cargo fmt --all -- --check', 'workspace formatting command ran')
            clippy = step_text(stable_prefix, 'Run Clippy')
            contains(clippy, 'cargo clippy --workspace --all-targets --all-features --locked', 'workspace clippy command ran')

            required_names = list(future_gates.get('prior121', [])) + list(future_gates.get('new11', []))
            require(future_gates.get('schema') == 'reference-overload-future-own-ci-gates-v2' and future_gates.get('status') == 'prepared_gate_inventory_not_execution_evidence', 'gate inventory is the pinned future-own-CI source, not execution evidence', checks, errors)
            gate_source = Path(future_gates.get('prior_gate_source', ''))
            gate_source_pin = file_pin(gate_source) if gate_source.is_file() else {}
            require(gate_source_pin.get('bytes') == future_gates.get('prior_gate_source_bytes') and gate_source_pin.get('sha256') == future_gates.get('prior_gate_source_sha256'), 'historical 105-gate source pin matches gate inventory', checks, errors)
            historical = read_json(gate_source) if gate_source_pin else {}
            hist_names = list(historical.get('baseline55', [])) + list(historical.get('extra50', []))
            require(len(future_gates.get('prior105', [])) == 105 and len(set(future_gates.get('prior105', []))) == 105 and future_gates.get('prior105') == hist_names and future_gates.get('prior16') == list(read_json(BASE / 'direct-parent-future-own-ci-gates-v1.json').get('new16', [])) and len(future_gates.get('prior16', [])) == 16 and len(future_gates.get('prior121', [])) == 121 and future_gates.get('prior121') == future_gates.get('prior105', []) + future_gates.get('prior16', []), 'prior105 and prior16 preserve the historical 121-gate inventory', checks, errors)
            require(len(future_gates.get('new11', [])) == 11 and len(set(future_gates.get('new11', []))) == 11 and len(required_names) == 132 and len(set(required_names)) == 132 and future_gates.get('unique_total') == 132, 'future gate inventory is prior121 plus 11 new unique gates = 132', checks, errors)
            acceptance_gate_source = acceptance.get('required_gate_source', {})
            old55_pin = file_pin(OLD55)
            require(acceptance_gate_source.get('bytes') == old55_pin['bytes'] and acceptance_gate_source.get('sha256') == old55_pin['sha256'], 'root acceptance pins the required historical baseline55 source', checks, errors)
            old55 = read_json(OLD55)
            baseline_names = list(old55['required_named_test_outcomes_by_seed'][SEEDS[0]])
            require(len(baseline_names) == 55 and future_gates.get('prior121', [])[:55] == baseline_names, 'prior121 begins with exact historical baseline55 source', checks, errors)
            argv = read_json(AUDIT_ARGV)
            passed_gates = [argv[i + 1] for i, arg in enumerate(argv[:-1]) if arg == '--gate']
            expected_additional = list(historical.get('extra50', [])) + list(future_gates.get('prior16', [])) + list(future_gates.get('new11', []))
            require(len(passed_gates) == 77 and passed_gates == expected_additional and len(set(passed_gates)) == 77, 'frozen root auditor argv passes exact additional extra50+prior16+new11 gate list', checks, errors)
            require(len(set(baseline_names + passed_gates)) == 132 and set(baseline_names + passed_gates) == set(required_names), 'root argv baseline55 plus additional77 equals exact 132-gate inventory', checks, errors)

            seeds_out = []
            for n, seed in enumerate(SEEDS, 1):
                text = step_text(stable_prefix, f'Run workspace tests with two fixed independent seeds (pass {n})')
                contains(text, f'PROPTEST_RNG_SEED: {seed}', f'workspace run uses required seed {seed}')
                contains(text, 'cargo test --workspace --all-targets --all-features --locked', f'workspace run {seed} uses exact all-targets/all-features command')
                summaries = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
                totals = {'passed': sum(int(x[1]) for x in summaries), 'failed': sum(int(x[2]) for x in summaries), 'ignored': sum(int(x[3]) for x in summaries)}
                require(len(summaries) == 369 and all(x[0] == 'ok' for x in summaries), f'{seed} has 369 successful test-suite summaries', checks, errors)
                require(totals == {'passed': 3642, 'failed': 0, 'ignored': 98}, f'{seed} totals are exactly 3642/0/98', checks, errors)
                named = re.findall(r'test (.+) \.\.\. (ok|ignored|FAILED)(?:, [^\n]*)?\s*$', text, re.M)
                require(sum(v == 'ok' for _, v in named) == 3642 and sum(v == 'ignored' for _, v in named) == 98 and not any(v == 'FAILED' for _, v in named), f'{seed} named outcomes are 3642 pass and 98 ignored', checks, errors)
                for name in required_names:
                    require(sum(x == name and y == 'ok' for x, y in named) == 1, f'{seed} required CI gate passed exactly once: {name}', checks, errors)
                seeds_out.append({'seed': seed, 'suites': len(summaries), **totals, 'named_passes': sum(v == 'ok' for _, v in named), 'named_ignored': sum(v == 'ignored' for _, v in named)})

            # The six workflow commands below contain seven selected JDK/full-class tests;
            # the functional-constructor test itself asserts the complete class under both JDKs.
            jdk_specs = [
                ('Run ignored JDK 25 instruction-boundary oracle', 'cargo test --test jvm_bytecode_oracle --locked -- --ignored --exact jdk25_instruction_boundaries_match_public_bytecode_inspection', ['jdk25_instruction_boundaries_match_public_bytecode_inspection'], 1),
                ('Run the ignored P3 Java 8 compile-and-execute comparison', 'cargo test --test p3_execution_comparison --locked -- --ignored', ['the_bulk_entrys_bodies_are_the_same_text_and_the_same_behaviour', 'the_corpus_is_read_the_same_way_by_every_legal_flag_set', 'the_p3_findings_are_replayed_by_compiling_and_executing_the_bodies'], 3),
                ('Run the functional-constructor full-class comparison', 'cargo test -p jarde-cli --test json_cli --locked -- --ignored --exact functional_constructor_arguments_replay_the_complete_class_on_both_jdks', ['functional_constructor_arguments_replay_the_complete_class_on_both_jdks'], 1),
                ('Run the BigDecimal Number full-class comparisons', 'cargo test --test p3_bigdecimal_number_widening --locked -- --ignored', ['bigdecimal_number_argument_generated_source_matches_frozen_runtime', 'main_only_bigdecimal_generated_source_matches_frozen_original_runtime'], 2),
                ('Run the nested int array full-class comparisons', 'cargo test --test p3_nested_int_array_compound_updates --locked -- --ignored --exact nested_int_array_updates_match_the_frozen_runner_oracle', ['nested_int_array_updates_match_the_frozen_runner_oracle'], 1),
                ('Run the returned int array full-class comparison', 'cargo test --test p3_nested_int_array_compound_updates --locked -- --ignored --exact returned_int_array_updates_compile_and_execute_as_a_complete_class', ['returned_int_array_updates_compile_and_execute_as_a_complete_class'], 1),
            ]
            jdk_evidence = []
            for title, command, tests, expected_count in jdk_specs:
                text = step_text(stable_prefix, title)
                contains(text, command, f'JDK/full-class step launched exact command: {title}')
                for test in tests:
                    contains(text, f'test {test} ... ok', f'JDK/full-class test passed: {test}')
                result = re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;', text)
                require(result is not None and int(result.group(1)) == expected_count, f'JDK/full-class command has {expected_count} actual passing test(s): {title}', checks, errors)
                jdk_evidence.append({'step': title, 'expected_passing_tests': expected_count, 'command_observed': True})
            full_class_gate_tests = ['jdk25_instruction_boundaries_match_public_bytecode_inspection', 'the_p3_findings_are_replayed_by_compiling_and_executing_the_bodies', 'functional_constructor_arguments_replay_the_complete_class_on_both_jdks', 'bigdecimal_number_argument_generated_source_matches_frozen_runtime', 'main_only_bigdecimal_generated_source_matches_frozen_original_runtime', 'nested_int_array_updates_match_the_frozen_runner_oracle', 'returned_int_array_updates_compile_and_execute_as_a_complete_class']
            require(len(full_class_gate_tests) == 7 and len(set(full_class_gate_tests)) == 7, 'seven named JDK/full-class gates enumerated uniquely', checks, errors)
            require(len(jdk_evidence) == 6, 'all six explicit JDK/full-class workflow command steps audited', checks, errors)

            # Remaining workflow job command evidence; API job/step conclusions above establish success.
            msrv_check = step_text('MSRV 1.88.0/', 'Check workspace on MSRV')
            contains(msrv_check, 'cargo check --workspace --all-targets --locked', 'MSRV all-target workspace check ran')
            supply_root = step_text('supply chain/', 'Check root workspace advisories, licenses, bans, and sources')
            contains(supply_root, 'cargo deny --all-features --workspace --locked --config ./deny.toml --manifest-path ./Cargo.toml check', 'root supply-chain check ran')
            supply_fuzz = step_text('supply chain/', 'Check fuzz workspace advisories, licenses, bans, and sources')
            contains(supply_fuzz, 'cargo deny --all-features --workspace --locked --config ./deny.toml --manifest-path ./fuzz/Cargo.toml check', 'fuzz supply-chain check ran')
            fuzz_install = step_text('fuzz smoke/', 'Install cargo-fuzz 0.13.2')
            contains(fuzz_install, 'cargo install cargo-fuzz --version 0.13.2 --locked', 'cargo-fuzz 0.13.2 installed in CI')
            fuzz_nightly = step_text('fuzz smoke/', 'Install nightly-2026-07-20')
            contains(fuzz_nightly, 'toolchain: nightly-2026-07-20', 'fuzz job uses pinned nightly')
            fuzz_steps = []
            for title, target in [('Run the bounded query smoke', 'query'), ('Run the bounded artifact-tree smoke', 'artifact_tree'), ('Run the bounded method-analysis smoke', 'method_analysis')]:
                text = step_text('fuzz smoke/', title)
                contains(text, f'cargo +nightly-2026-07-20 fuzz run {target}', f'fuzz target ran: {target}')
                contains(text, '-max_total_time=20', f'fuzz target uses bounded 20-second limit: {target}')
                fuzz_steps.append(target)
            require(len(fuzz_steps) == 3, 'all three configured fuzz smoke targets were present', checks, errors)
    except Exception as exc:
        errors.append(f'audit parsing error: {type(exc).__name__}: {exc}')
        member_pins = []
        seeds_out = []
        jdk_evidence = []

    expected_acceptance = acceptance.get('seeds', [])
    require(len(expected_acceptance) == 2 and all(x.get('suites') == 369 and x.get('passed') == 3642 and x.get('failed') == 0 and x.get('ignored') == 98 for x in expected_acceptance), 'root acceptance summarizes two exact 369/3642/0/98 seeds', checks, errors)
    report = {
        'status': 'accepted_independent_exact_product_ci_review' if not errors else 'rejected_independent_exact_product_ci_review',
        'scope': 'read-only independent review of the fingerprint-successor CI API capture and combined job logs; independently locates exact Run-command groups and checks API step time bounds; does not rerun CI or toolchains',
        'product_sha': HEAD, 'product_sha_length': len(HEAD), 'branch': BRANCH, 'run_id': RUN,
        'predecessor_failed_ci': {'product_sha': predecessor_failed.get('product_sha'), 'branch': 'codex/reference-overload-proof-stops', 'run_id': predecessor_failed.get('run_id'), 'conclusion': predecessor_failed.get('conclusion'), 'reinterpreted_as_success': False},
        'capture': file_pin(capture_path), 'logs_zip': zpin,
        'root_acceptance': file_pin(ACCEPT), 'workflow': file_pin(WORKFLOW),
        'prior_audit_attempt': {'receipt': file_pin(PRIOR_ATTEMPT), 'reason': prior_attempt.get('reason'), 'raw_file_count': len(prior_attempt_raw), 'raw_files': prior_attempt_raw, 'capture_succeeded': False, 'ci_run_reinterpreted': False},
        'source_binding': file_pin(SOURCE_BINDING), 'required_gates': file_pin(GATES),
        'api_observations': len(observations), 'api_raw_stream_count': len(raw_paths),
        'jobs': len(jobs), 'steps': step_total,
        'seeds': seeds_out, 'jdk_full_class_commands': jdk_evidence,
        'jdk_full_class_gate_tests': full_class_gate_tests if 'full_class_gate_tests' in locals() else [],
        'jdk_full_class_gate_count': len(full_class_gate_tests) if 'full_class_gate_tests' in locals() else 0,
        'checks': len(checks), 'errors': errors, 'check_labels': checks,
        'log_member_pins': member_pins, 'log_segments': log_segments if 'log_segments' in locals() else [], 'log_layout':'github_combined_job_logs_independently_segmented',
        'limits': {'ci_strict_items': 365, 'ci_suites_per_seed': 369, 'passes_per_seed': 3642, 'ignored_per_seed': 98, 'gate_names': 132},
    }
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'checks': report['checks'], 'errors': errors, 'output': str(OUT)}, ensure_ascii=False))
    return 0 if not errors else 1

if __name__ == '__main__':
    raise SystemExit(main())
