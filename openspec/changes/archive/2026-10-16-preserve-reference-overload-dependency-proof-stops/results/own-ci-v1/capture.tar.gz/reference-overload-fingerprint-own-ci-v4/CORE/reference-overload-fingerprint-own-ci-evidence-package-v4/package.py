#!/usr/bin/env python3
"""Package accepted fingerprint-successor own-CI evidence; requires terminal root and independent acceptance."""
from pathlib import Path, PurePosixPath
import gzip, hashlib, io, json, re, tarfile, zipfile
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
O=Path(__file__).resolve().parent
C=B/'own-ci-reference-overload-fingerprint-root-v3'
I=B/'CORE/own-ci-reference-overload-fingerprint-independent-audit-v1'
CAPTURE=C/'execution.json'
ROOT=B/'reference-overload-fingerprint-own-ci-root-acceptance-v4.json'
INDIE=I/'audit-result-v6.json'
GATEFILE=B/'reference-overload-future-own-ci-gates-v2.json'
BINDING=B/'reference-overload-fingerprint-product-commit-source-binding-v2.json'
FOCUSED=B/'CORE/reference-overload-fingerprint-maintenance-v1/run-v1/execution.json'
ROOT_EXEC=B/'reference-overload-fingerprint-own-ci-root-auditor-execution-v4.json'
INDIE_EXEC=B/'reference-overload-fingerprint-own-ci-independent-auditor-execution-v6.json'
HEAD='82611166fc0b8a2e3a8d925e7a3e9f12738c0f87'
assert len(HEAD)==40
BRANCH='codex/reference-overload-proof-stops'
RUN=38721617088
SEEDS=['5350648285461741569','5350648285461741570']
LOCAL_EXEC=B/'CORE/reference-overload-final-local-evidence-package-v1/run-v1/execution.json'
FAILURE_PACKAGE=B/'CORE/reference-overload-own-ci-failure-package-v1/reference-overload-own-ci-failure-v1.tar.gz'
FAILURE_EXEC=B/'CORE/reference-overload-own-ci-failure-package-v1/execution.json'
PARTIAL_V2=B/'CORE/reference-overload-fingerprint-ci-capture-recovery-v1/preserved-partial-v2.json'
RECOVERY=B/'CORE/reference-overload-fingerprint-ci-capture-recovery-v1/accepted-root-and-preserved-failures.json'
OLD_ROOT_V3=B/'reference-overload-fingerprint-own-ci-root-auditor-execution-v3.json'
OLD_ROOT_V3_STDOUT=B/'reference-overload-fingerprint-own-ci-root-auditor-execution-v3.stdout.raw'
OLD_ROOT_V3_STDERR=B/'reference-overload-fingerprint-own-ci-root-auditor-execution-v3.stderr.raw'
MAINTENANCE=FOCUSED
WORKSPACE=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde')
ARCHIVE=O/'reference-overload-fingerprint-own-ci-evidence-v4.tar.gz'

def sha(data): return hashlib.sha256(data).hexdigest()
def pin(p):
 p=Path(p).resolve()
 assert not p.is_symlink() and p.is_file(),f'not regular file: {p}'
 z=p.read_bytes();return {'path':str(p),'bytes':len(z),'sha256':sha(z)}
def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def check(q):
 actual=pin(q['path'])
 assert actual=={k:q[k] for k in ('path','bytes','sha256')},q['path']
 return actual
assert not ARCHIVE.exists(),f'refusing overwrite: {ARCHIVE}'
cap=load(CAPTURE); root=load(ROOT); indie=load(INDIE); gates=load(GATEFILE); binding=load(BINDING); focused=load(FOCUSED)
assert cap['status']=='captured_pending_root_acceptance' and cap['run_status']=='completed' and cap['conclusion']=='success'
assert root['status']=='accepted_exact_product_ci' and root['errors']==[]
assert indie['status']=='accepted_independent_exact_product_ci_review' and indie['errors']==[]
assert cap['product_sha']==root['product_sha']==indie['product_sha']==binding['head']==HEAD and len(HEAD)==40
assert cap['run_id']==root['run_id']==indie['run_id']==binding['own_ci_run']==RUN
assert root['branch']==indie['branch']==binding['branch']==BRANCH and binding['own_ci_accepted'] is False
assert binding['source_count']==4907 and binding['target_absent'] is True and binding['all_source_bytes_and_git_blobs_match'] is True
assert binding.get('build_receipt')==str(FOCUSED)
assert focused['source_manifest_before']==focused['source_manifest_after'] and len(focused['source_manifest_before'])==4907 and focused['target_absent'] is True
assert len(focused['maintenance_source_manifest_before'])==4907 and focused['maintenance_source_manifest_before'] != focused['source_manifest_before']
old_map={r['path']:(r['bytes'],r['sha256']) for r in focused['maintenance_source_manifest_before']}
new_map={r['path']:(r['bytes'],r['sha256']) for r in focused['source_manifest_before']}
assert len(old_map)==len(new_map)==4907 and [p for p in sorted(old_map) if old_map[p]!=new_map[p]]==['tests/fixtures/corpus-fingerprint.json']
assert root['jobs']==indie['jobs']==len(cap['jobs'])==4
assert root['steps']==indie['steps']==sum(len(j['steps']) for j in cap['jobs'])==52
assert all(j['status']=='completed' and j['conclusion']=='success' for j in cap['jobs'])
for report in (root,indie):
 assert len(report['seeds'])==2
 for seed in report['seeds']:
  assert (seed['suites'],seed['passed'],seed['failed'],seed['ignored'])==(369,3642,0,98)
assert indie['limits']=={'ci_strict_items':365,'ci_suites_per_seed':369,'passes_per_seed':3642,'ignored_per_seed':98,'gate_names':132}
assert root['checks']>0 and indie['checks']>0 and isinstance(root['checks'],int) and isinstance(indie['checks'],int)
assert isinstance(indie['api_observations'],int) and indie['api_observations']>0
assert isinstance(indie['api_raw_stream_count'],int)
for key in ('capture','logs_zip','root_acceptance','source_binding','required_gates','workflow'): check(indie[key])
check(cap['logs']); check(root['log_zip']); check(root['required_gate_source']); check(root['auditor'])
assert gates['schema']=='reference-overload-future-own-ci-gates-v2' and gates['status']=='prepared_gate_inventory_not_execution_evidence'
assert gates['planned_strict_openspec_only']['items']==365
assert gates['unique_total']==132 and len(gates['prior121'])==121 and len(gates['new11'])==11
names=gates['prior121']+gates['new11']; assert len(set(names))==132
check({'path':gates['prior_gate_source'],'bytes':gates['prior_gate_source_bytes'],'sha256':gates['prior_gate_source_sha256']})
assert gates['workflow']['current_pin']['bytes']==17361 and gates['workflow']['current_pin']['sha256']=='b545890a55cc4fda31d70b332889c111d789afbf0949581e96bf2b94ea6cd18a'
assert indie['workflow']['sha256']==gates['workflow']['current_pin']['sha256']

# Derive all captured API and auditor raw files from the terminal receipt, without fixed counts.
bound={}; files={}
def add(p,arc=None):
 p=Path(p).resolve(); assert not p.is_symlink() and p.is_file(),p
 rel=arc if arc is not None else str(p.relative_to(B))
 pp=PurePosixPath(rel); assert not pp.is_absolute() and '..' not in pp.parts
 if p in files:
  assert files[p]==rel, f'conflicting archive path for {p}'
  return
 files[p]=rel

def bind_receipt(row,label,inside=None):
 assert row.get('exit_code')==0, label
 streams=row.get('streams',{}); assert set(streams)=={'stdout','stderr'},label
 for kind,q in streams.items():
  check(q); p=Path(q['path']).resolve()
  if inside is not None: assert p.is_relative_to(inside.resolve()),p
  assert p not in bound,label
  bound[p]={'label':label,'stream':kind,'pin':q}; add(p)
for obs in cap['observations']:
 assert obs.get('exit_code')==0
 bind_receipt(obs,'captured GitHub API observation',C)
for p in (ROOT_EXEC,INDIE_EXEC): bind_receipt(load(p),p.name,B)
assert len(bound)==indie['api_raw_stream_count']+4
assert indie['api_raw_stream_count']==2*indie['api_observations']
# Capture-owned files are archived under their original relative names.
for p in C.rglob('*'):
 if p.is_symlink(): raise AssertionError(f'symlink in capture: {p}')
 if p.is_file(): add(p)
for p in (CAPTURE,ROOT,INDIE,ROOT_EXEC,INDIE_EXEC,GATEFILE,BINDING,FOCUSED,
          B/'reference-overload-fingerprint-own-ci-audit-argv-v4.json',
          B/'reference-overload-future-own-ci-gates-v1.json',
          MAINTENANCE,
          B/'combined-proof-all-ci-gates-root-v1.json',
          B/'direct-parent-future-own-ci-gates-v1.json',
          B/'direct-parent-own-ci-root-acceptance-v1.json',
          B/'capture_product_ci_v3.py',B/'accept_product_ci_v3.py',B/'accept_product_ci_v4.py',B/'reference-overload-fingerprint-own-ci-audit-argv-v4.json',B/'CORE/reference-overload-fingerprint-ci-capture-recovery-v1/accepted-root-and-preserved-failures.json',
          B/'accept_product_ci_v4.py',
          I/'audit_own_ci_v6.py',I/'audit-result-v6.json',I/'audit-own-ci-v6.argv.json',
          Path(gates['prior_gate_source'])):
 add(p)
add(Path(indie['workflow']['path']),'metadata/frozen-workflow-ci.yml')
add(Path(root['required_gate_source']['path']),'metadata/old55-root-acceptance.json')
add(Path(__file__).resolve())
# Include exact product source bytes pinned by the committed-source inventory.
for rel,q in gates['current_source_pins'].items():
 check(q); add(q['path'],'metadata/product-source/'+rel)
fp_row=next(r for r in focused['source_manifest_after'] if r.get('path')=='tests/fixtures/corpus-fingerprint.json')
fp_path=WORKSPACE/'tests/fixtures/corpus-fingerprint.json'; fp_actual=pin(fp_path)
assert fp_actual['bytes']==fp_row['bytes'] and fp_actual['sha256']==fp_row['sha256']
add(fp_path,'metadata/product-source/tests/fixtures/corpus-fingerprint.json')
# The partial v2 capture and root-auditor v3 failure are preserved as external failures,
# separate from the successful product CI capture and never copied as product success.
partial_v2=load(PARTIAL_V2)
partial_raw_pins=[]
for row in partial_v2['old_files']:
 q=pin(row['path']); assert (q['bytes'],q['sha256'])==(row['bytes'],row['sha256']); partial_raw_pins.append(q)
assert 'network error' in partial_v2['reason'] and partial_raw_pins
partial_pin=pin(PARTIAL_V2)
recovery=load(RECOVERY); recovery_pin=pin(RECOVERY)
assert recovery['head']==HEAD and recovery['run']==RUN and recovery['same_remote_run_not_rerun'] is True
assert recovery['original_capture_failure']['sha256']==partial_pin['sha256']
root_v3_failure=load(OLD_ROOT_V3); root_v3_out=pin(OLD_ROOT_V3_STDOUT); root_v3_err=pin(OLD_ROOT_V3_STDERR)
assert root_v3_failure['exit_code']==1 and root_v3_failure['streams']['stdout']['sha256']==root_v3_out['sha256'] and root_v3_failure['streams']['stderr']['sha256']==root_v3_err['sha256']
assert b'IndexError' in OLD_ROOT_V3_STDERR.read_bytes() and b'list index out of range' in OLD_ROOT_V3_STDERR.read_bytes()
assert recovery['prior_auditor_execution_failure']['sha256']==pin(OLD_ROOT_V3)['sha256']
local=load(LOCAL_EXEC)['archive']; check(local); assert local['sha256']=='1ebca2ca959c5c81663d75e4bad7cfdb5531da8498d35ac04a9ab07114f0b961'
new_cli=binding['frozen_cli']; check(new_cli)
failure_exec=load(FAILURE_EXEC); failure_pin=failure_exec['archive']; check(failure_pin); assert failure_pin['sha256']=='d35b42e42c60bb975f4652a5d3df00e3c50749233748fff961d178b3488fa496'
assert failure_exec['status']=='packaged_failed_ci_evidence_not_success'
old_failure=load(B/'own-ci-reference-overload-ba3f-root-v1/execution.json')
assert old_failure['product_sha']=='ba3fa76af4241304ce06fdf2722355826c80402b' and old_failure['run_id']==38717487054 and old_failure['conclusion']=='failure'
old_binding=load(B/'reference-overload-product-commit-source-binding-v1.json')
assert old_binding['frozen_cli']['bytes']==binding['frozen_cli']['bytes']==59657968 and old_binding['frozen_cli']['sha256']==binding['frozen_cli']['sha256']=='c44bde2cdbbf32f70a29bef345c19f11b86229b2e399a0936ed90c1a264fa396'
check(binding['frozen_cli'])
# Ensure every actual raw stream is represented exactly once; no hidden or unbound .raw files.
assert set(bound)<=set(files)
raw_payload={p for p in files if p.suffix=='.raw'}
assert raw_payload==set(bound)
# Confirm capture ZIP is intact and member pins match both independent reports.
zip_path=C/'logs.zip'; zpin=pin(zip_path)
assert cap['logs']['path']==zpin['path'] and cap['logs']['bytes']==zpin['bytes'] and cap['logs']['sha256']==zpin['sha256']
assert root['log_zip']['path']==zpin['path'] and root['log_zip']['bytes']==zpin['bytes'] and root['log_zip']['sha256']==zpin['sha256']
with zipfile.ZipFile(zip_path) as z:
 infos=z.infolist(); z_names=[x.filename for x in infos]
 assert len(z_names)==len(set(z_names))==len(root['log_member_pins'])==len(indie['log_member_pins'])
 actual_members=[]
 for info in infos:
  pp=PurePosixPath(info.filename); mode=(info.external_attr>>16)&0o170000
  assert not info.is_dir() and not pp.is_absolute() and '..' not in pp.parts and mode in (0,0o100000)
  data=z.read(info); actual_members.append({'path':info.filename,'bytes':len(data),'sha256':sha(data)})
 assert actual_members==root['log_member_pins']==indie['log_member_pins']
 ansi=re.compile(r'\x1b\[[0-9;]*m')
 stable_members=[x for x in z_names if x.endswith('.txt') and not x.endswith('/system.txt') and re.search(r'^.*?Complete job name: stable / test and specification$',ansi.sub('',z.read(x).decode('utf-8-sig',errors='replace')),re.M)]
 assert len(stable_members)==1
 stable_member=stable_members[0]
 stable_text=ansi.sub('',z.read(stable_member).decode('utf-8-sig',errors='replace'))
 def audited_segment(step_name):
  rows=[x for x in indie['log_segments'] if x['api_job']=='stable / test and specification' and x['api_step']==step_name]
  assert len(rows)==1
  row=rows[0]; assert row['member']==stable_member
  piece=stable_text[row['decoded_char_start']:row['decoded_char_end']]
  assert sha(piece.encode())==row['sha256']
  return piece
 for n,seed in enumerate(SEEDS,1):
  text=audited_segment(f'Run workspace tests with two fixed independent seeds (pass {n})')
  sums=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
  assert len(sums)==369 and [sum(int(x[k]) for x in sums) for k in (1,2,3)]==[3642,0,98]
  named=re.findall(r'\btest (\S+) \.\.\. (ok|ignored|FAILED)',text)
  assert all(sum(a==gate and status=='ok' for a,status in named)==1 for gate in names)
 strict=audited_segment('Validate OpenSpec strictly')
 assert 'Totals: 365 passed, 0 failed (365 items)' in strict
# Source binding identity rows, including frozen workflow and exact inventory source, are in package.
assert binding['own_ci_accepted'] is False and binding['own_ci_run']==RUN
assert root['checks']>0 and indie['checks']>0 and indie['errors']==[]
assert indie['product_sha_length']==40 and indie['predecessor_failed_ci']['reinterpreted_as_success'] is False
rows=[]; payload={}
for p,rel in sorted(files.items(),key=lambda x:x[1]):
 assert p.is_file() and not p.is_symlink()
 data=p.read_bytes(); assert not data.startswith((b'\x7fELF',b'MZ'))
 name='reference-overload-fingerprint-own-ci-v4/'+rel
 assert name not in payload
 payload[name]=data; rows.append({**pin(p),'archive_path':name})
allow={'status':'explicit_allowlist_validated','items':rows,'raw_receipt_bound_count':len(bound),'checks_count_derived':True}
(O/'allowlist.json').write_text(json.dumps(allow,indent=2,ensure_ascii=False)+'\n')
manifest={'status':'packaged_and_reopened_verified_after_success_acceptance','product_sha':HEAD,'branch':BRANCH,'run_id':RUN,'items':rows,'predecessor_failed_ci':{'head':old_failure['product_sha'],'run_id':old_failure['run_id'],'conclusion':old_failure['conclusion'],'reinterpreted_as_success':False},
 'raw_receipt_bound_count':len(bound),'api_observations':indie['api_observations'],'root_checks':root['checks'],'independent_checks':indie['checks'],
 'jobs':len(cap['jobs']),'steps':sum(len(j['steps']) for j in cap['jobs']),'seeds':root['seeds'],'gates':len(names),'strict_items':365,
 'external_local_evidence_archive':local,'external_frozen_cli':new_cli,'external_predecessor_failed_ci_package':failure_pin,'external_v2_partial_capture_attempt':{'receipt':partial_pin,'recovery_receipt':recovery_pin,'reason':partial_v2['reason'],'raw_files':partial_raw_pins,'capture_succeeded':False,'same_ci_run_rerun':False},'external_v3_root_auditor_format_failure':{'execution':pin(OLD_ROOT_V3),'stdout':root_v3_out,'stderr':root_v3_err,'exit_code':1,'classification':'root auditor ZIP layout assumption failed on combined job logs; this is not a product CI failure','reinterpreted_as_product_ci_failure':False},
 'scope':'This package is only for the accepted fingerprint-successor product own-CI run. It contains that run’s capture, raw API responses, logs, root acceptance, independent acceptance, source binding, maintenance receipt and exact source pins. The earlier ba3f failed run is retained as a separate external lineage pin and is not reinterpreted as successful. The v2 partial capture attempt and v3 root-auditor format failure are explicit external recovery pins; neither changes the successful product CI result. The prior local evidence archive and frozen CLI are external pins, not copied binaries; skipped or local native/JDK work is not represented as this CI result.'}
mbytes=(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode(); payload['reference-overload-own-ci-manifest.json']=mbytes
tar_buffer=io.BytesIO()
with gzip.GzipFile(filename='',mode='wb',fileobj=tar_buffer,mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
  for name,data in sorted(payload.items()):
   t=tarfile.TarInfo(name); t.size=len(data); t.mode=0o444; t.mtime=0; tar.addfile(t,io.BytesIO(data))
ARCHIVE.write_bytes(tar_buffer.getvalue())
with tarfile.open(ARCHIVE,'r:gz') as tar:
 members=tar.getmembers(); assert len(members)==len(payload) and len({m.name for m in members})==len(members)
 assert all(m.isfile() for m in members) and {m.name for m in members}==set(payload)
 for m in members: assert tar.extractfile(m).read()==payload[m.name]
for row in rows: assert Path(row['path']).read_bytes()==payload[row['archive_path']]
(O/'manifest.json').write_bytes(mbytes)
execution={'status':'packaged_and_reopened_verified_after_success_acceptance','archive':pin(ARCHIVE),'manifest':pin(O/'manifest.json'),'allowlist':pin(O/'allowlist.json'),'packager':pin(Path(__file__)),
 'payload_files':len(rows),'tar_members':len(payload),'raw_files':len(bound),'api_observations':indie['api_observations'],'zip_members':len(root['log_member_pins']),
 'root_checks':root['checks'],'independent_checks':indie['checks'],'external_local_evidence_archive':local,'external_frozen_cli':new_cli,'external_predecessor_failed_ci_package':failure_pin,'external_v2_partial_capture_attempt':partial_pin,'external_recovery_receipt':recovery_pin,'external_v3_root_auditor_format_failure':pin(OLD_ROOT_V3)}
(O/'execution.json').write_text(json.dumps(execution,indent=2,ensure_ascii=False)+'\n'); print(json.dumps(execution,indent=2,ensure_ascii=False))
