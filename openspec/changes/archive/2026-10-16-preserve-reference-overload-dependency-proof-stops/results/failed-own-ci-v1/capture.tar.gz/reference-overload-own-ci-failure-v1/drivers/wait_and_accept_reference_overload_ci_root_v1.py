from pathlib import Path
import json,subprocess,time,hashlib
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
C=B/'own-ci-reference-overload-ba3f-root-v1/execution.json'
D=B/'reference-overload-apply-root-v1'
I=B/'CORE/own-ci-reference-overload-ba3f-independent-audit-prepared-v1/audit_own_ci_v2.py'
def pin(p):
 z=p.read_bytes();return {'path':str(p),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
def run(argv,name):
 out=B/(name+'.stdout.raw');err=B/(name+'.stderr.raw');receipt=B/(name+'.json')
 assert not out.exists() and not err.exists() and not receipt.exists()
 r=subprocess.run(argv,capture_output=True)
 out.write_bytes(r.stdout);err.write_bytes(r.stderr)
 receipt.write_text(json.dumps({'argv':argv,'exit_code':r.returncode,'streams':{'stdout':pin(out),'stderr':pin(err)}},indent=2)+'\n')
 assert r.returncode==0,(name,r.returncode,r.stderr.decode(errors='replace')[-1200:])
while True:
 if C.is_file():
  try:r=json.loads(C.read_text())
  except (OSError,json.JSONDecodeError):r={}
  if r.get('status')=='captured_pending_root_acceptance':break
  if r.get('run_status')=='completed' and r.get('conclusion') not in (None,'success'):
   raise RuntimeError('CI failed; preserve capture and inspect actual logs')
 time.sleep(20)
assert r['product_sha']=='ba3fa76af4241304ce06fdf2722355826c80402b' and r['run_id']==38717487054 and r['conclusion']=='success'
argv=json.loads((B/'reference-overload-own-ci-audit-argv-v1.json').read_text())
run(argv,'reference-overload-own-ci-root-auditor-execution-v1')
assert I.is_file()
run(['python3',str(I)],'reference-overload-own-ci-independent-auditor-execution-v2')
print('exact product root and independent own-CI acceptance completed')
