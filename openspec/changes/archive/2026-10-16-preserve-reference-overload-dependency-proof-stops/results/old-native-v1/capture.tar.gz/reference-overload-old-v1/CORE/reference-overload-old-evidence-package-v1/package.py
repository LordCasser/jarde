#!/usr/bin/env python3
"""Package actual old-production EM11 reds only; no native command is executed."""
from pathlib import Path, PurePosixPath
import hashlib, io, json, tarfile
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015'); O=Path(__file__).resolve().parent
A=B/'reference-overload-apply-root-v1'; N=B/'reference-overload-old-native-v1'
FIXTURE=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde/tests/fixtures/em11-reference-overload.jar')
def pin(p):
 p=Path(p).resolve(); z=p.read_bytes(); return {'path':str(p),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
def load(p): return json.loads(Path(p).read_text())
def check(q): assert pin(q['path'])=={k:q[k] for k in ('path','bytes','sha256')},q['path']
r=load(N/'execution.json'); root=load(A/'old-native-root-acceptance-v1.json'); dispatch=load(A/'old-native-dispatch.json')
assert r['status']=='expected_command_outcomes_observed_pending_independent_acceptance' and r['finished_at']
assert r['source_manifest_before']==r['source_manifest_after'] and len(r['source_manifest_before'])==4907 and r['target_absent']
assert [c['exit_code'] for c in r['commands']]==[101,101,101,0]
assert r['commands'][-1]['argv']==['cargo','clean'] and root['status']=='accepted_root_actual_old_behavior_reds'
assert root['summary']=={'passed':15,'failed':6,'ignored':0} and root['source_count']==4907 and root['all8rawpins_match']
assert [c.get('actual_test_summaries') for c in r['commands'][:3]]==[[['FAILED','12','3','0']],[['FAILED','2','2','0']],[['FAILED','1','1','0']]]
files={}; bound={}
for name in ['execution.json','command_spec.json']: files[(N/name).resolve()]=str((N/name).relative_to(B))
check(r['command_spec'])
for c in r['commands']:
 assert set(c['streams'])=={'stdout','stderr'}
 for q in c['streams'].values():
  check(q); p=Path(q['path']).resolve(); assert p not in bound; bound[p]=q; files[p]=str(p.relative_to(B))
assert len(bound)==8 and set(N.glob('*.raw'))==set(bound)
selected=['facade-before.rs','facade-old-observed-v1.rs','old-public-tests.rs','old-cli-tests.rs','old-native-commands-v1.json','old-native-dispatch.json','old-native-dispatch.stdout.raw','old-native-dispatch.stderr.raw','old-native-root-acceptance-v1.json','old-observer-static-review-v1.json']
independent=A/'old-native-independent-audit-v1.json'
if independent.is_file():
 assert load(independent)['status']=='accepted_old_production_red_audit'; selected.append(independent.name)
for name in selected: files[(A/name).resolve()]=str((A/name).relative_to(B))
source={q['path']:q for q in r['source_manifest_before']}
overlays={'src/facade.rs':A/'facade-old-observed-v1.rs','tests/reference_overload_dependency_proof_stops.rs':A/'old-public-tests.rs','crates/jarde-cli/tests/class_source_cli.rs':A/'old-cli-tests.rs','tests/fixtures/em11-reference-overload.jar':FIXTURE}
mapping=[]
for relative,p in overlays.items():
 actual=pin(p); expected=source[relative]
 assert actual['bytes']==expected['bytes'] and actual['sha256']==expected['sha256']
 mapping.append({'compiled_old_path':relative,'saved_original_pin':actual,'receipt_source_pin':expected})
assert pin(A/'facade-old-observed-v1.rs')['sha256']==dispatch['old_facade_sha256']=='0debb1aa5d1c52cd20eedb7f955b09332ab4630c07f70e407a33d0ebd2831612'
assert pin(FIXTURE)['sha256']=='7f424cfedc412c210679cf2d36377bc94b1fb599217b41e8dd4e6fbf0129b9e2'
files[FIXTURE.resolve()]='compiled-old-overlays/tests/fixtures/em11-reference-overload.jar'; files[Path(__file__).resolve()]=str(Path(__file__).resolve().relative_to(B))
rows=[]; payload={}
for p,relative in sorted(files.items(),key=lambda x:x[1]):
 assert p.is_file() and not p.is_symlink(); arc='reference-overload-old-v1/'+relative
 assert not PurePosixPath(arc).is_absolute() and '..' not in PurePosixPath(arc).parts and arc not in payload
 z=p.read_bytes(); assert not z.startswith((b'\x7fELF',b'MZ')); rows.append({**pin(p),'archive_path':arc}); payload[arc]=z
aux=[{'dispatch_record':pin(A/'old-native-dispatch.json'),'stream':name,'pin':pin(A/f'old-native-dispatch.{name}.raw'),'binding_scope':'Explicit saved dispatch stream pair. Historical dispatch JSON has argv/exit/old-facade pin but no stream pins; these bytes are pinned here without rewriting that record.'} for name in ('stdout','stderr')]
manifest={'schema':'reference-overload-old-production-evidence-v1','status':'packaged_and_reopened_verified','items':rows,'receipt_bound_raw_count':8,'dispatch_raw_bindings':aux,'baseline_git_commit':'7532d618800287aa147a878ef509201ded80b004','compiled_old_source_count':4907,'compiled_old_overlay_mapping':mapping,'independent_audit_included':independent.is_file(),'old_test_outcomes':root['summary'],'historical_receipt_status':r['status'],'scope':'Actual old-production behavior reds only: 21 tests,15pass6fail;3cargo test101 and exact cargo clean0. Full original4907 before/after manifests remain in receipt. Reconstruct other source files from baseline7532d618800287aa147a878ef509201ded80b004 and overlay these four exact old source paths. Current fixed workspace facade/public/CLI files and new production candidate are not read or included. Assertions after each first failing behavior check were not executed and are not claimed; this is not fix acceptance. Native executables/toolchains and future CI excluded.'}
mbytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode(); payload['reference-overload-old-manifest.json']=mbytes
archive=O/'reference-overload-old-evidence-v1.tar.gz'; assert not archive.exists()
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as t:
 for name,z in sorted(payload.items()):
  m=tarfile.TarInfo(name); m.size=len(z); m.mode=0o444; m.mtime=0; t.addfile(m,io.BytesIO(z))
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers(); assert len(members)==len(payload) and len({m.name for m in members})==len(members)
 assert all(m.isfile() for m in members) and {m.name for m in members}==set(payload)
 for m in members: assert t.extractfile(m).read()==payload[m.name]
for row in rows: assert Path(row['path']).read_bytes()==payload[row['archive_path']]
(O/'manifest.json').write_bytes(mbytes)
execution={'status':'packaged_and_reopened_verified','archive':pin(archive),'manifest':pin(O/'manifest.json'),'packager':pin(Path(__file__)),'payload_files':len(rows),'tar_members':len(payload),'receipt_bound_raws':8,'explicit_dispatch_raws':2,'compiled_old_source_count':4907,'old_test_outcomes':root['summary'],'independent_audit_included':independent.is_file()}
(O/'execution.json').write_text(json.dumps(execution,indent=2)+'\n'); print(json.dumps(execution,indent=2))
