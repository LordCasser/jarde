#!/usr/bin/env python3
"""Narrow cache evidence collection/package only; never runs any captured tool."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, io, json, tarfile
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015'); D=B/'reference-overload-apply-root-v1'; HERE=Path(__file__).resolve().parent
ROOT=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde'); PREFIX='reference-overload-final-local-v1/'
STAGES=['reference-overload-old-native-v1','reference-overload-old-ordinary-controls-v1','reference-overload-fixed-initial-v1','reference-overload-fixed-jdk23-v2','reference-overload-final-focused-v1']
def pin(path):
 p=Path(path).resolve(); z=p.read_bytes(); return {'path':str(p),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
def load(path): return json.loads(Path(path).read_text())
def verify(q): assert pin(q['path'])=={k:q[k] for k in ('path','bytes','sha256')},q['path']
def totals(r):
 rows=[x for c in r['commands'] for x in c.get('actual_test_summaries',[])]; return [sum(int(x[i]) for x in rows) for i in (1,2,3)]
def prepare(args):
 replay_path=args.replay.resolve(); replay=load(replay_path); audit_path=args.audit.resolve(); audit=load(audit_path)
 assert replay['status']=='captured_21_command_em11_final_cli_source_runtime_budget_replay_pending_independent_review' and len(replay['commands'])==21
 assert replay['inputs_identical'] and replay['current_source_matches_frozen_receipt_after'] and replay['target_absent_after']
 assert replay['input_manifest_before']==replay['input_manifest_after'] and replay['source_manifest_count']==replay['source_manifest_count_after']==4907
 assert audit['status'].startswith('accepted') and audit.get('errors',[]) in ([],0)
 assert len([c for c in replay['commands'] if c.get('oracle_stdout_equal')])==6 and replay['oracle_utf8_bytes']==219
 assert [c['exit_code'] for c in replay['commands'][-4:]]==[4,4,0,0]
 items={}; bindings=[]; receipts=[]; overlays=[]
 def add(p,arc=None):
  p=Path(p).resolve(); q=pin(p); name=arc or (str(p.relative_to(B)) if p.is_relative_to(B) else 'external-source-support/'+p.name)
  items[str(p)]={**q,'archive_path':PREFIX+name}; return p
 def bind(p,q,receipt):
  actual=pin(p); assert (actual['bytes'],actual['sha256'])==(q['bytes'],q['sha256'])
  bindings.append({'included_path':str(Path(p).resolve()),'receipt':str(receipt),'recorded_pin':q})
 raw={}
 def streams(receipt,r):
  for c in r['commands']:
   assert set(c['streams'])=={'stdout','stderr'}
   for q in c['streams'].values():
    verify(q); p=add(q['path']); assert str(p) not in raw; raw[str(p)]=q; bind(p,q,receipt)
 saved={'src/facade.rs':['facade-old-observed-v1.rs','facade-fixed-initial-v1.rs','facade-final-focused-v1.rs'],
        'tests/reference_overload_dependency_proof_stops.rs':['old-public-tests.rs','old-public-with-ordinary-controls-v1.rs','final-public-tests-v1.rs'],
        'crates/jarde-cli/tests/class_source_cli.rs':['old-cli-tests.rs'],
        'tests/fixtures/em11-reference-overload.jar':[]}
 for n in STAGES:
  rp=B/n/'execution.json'; r=load(rp); add(rp); spec=add(B/n/'command_spec.json'); bind(spec,r['command_spec'],rp)
  assert r['finished_at'] and r['source_manifest_before']==r['source_manifest_after'] and len(r['source_manifest_before'])==4907 and r['target_absent']
  assert r['commands'][-1]['argv']==['cargo','clean'] and r['commands'][-1]['exit_code']==0
  if n==STAGES[2]: assert r['status']=='failed' and r['commands'][0]['exit_code']==101
  else:
   assert r['status']=='expected_command_outcomes_observed_pending_independent_acceptance'
   assert totals(r)=={STAGES[0]:[15,6,0],STAGES[1]:[4,0,0],STAGES[3]:[272,0,0],STAGES[4]:[325,0,1]}[n]
  streams(rp,r); assert {str(p.resolve()) for p in rp.parent.glob('*.raw')}=={p for p in raw if Path(p).parent==rp.parent}
  source={q['path']:q for q in r['source_manifest_before']}
  for rel,names in saved.items():
   q=source[rel]; candidates=[D/name for name in names] if names else [ROOT/rel]
   matches=[p for p in candidates if p.is_file() and (pin(p)['bytes'],pin(p)['sha256'])==(q['bytes'],q['sha256'])]
   assert matches,(n,rel,'missing historical source overlay')
   p=add(matches[0],None if names else 'source-inputs/'+rel); bind(p,q,rp); overlays.append({'stage':n,'restore_path':rel,'included_path':str(p),'receipt_source_pin':q})
  receipts.append({'path':str(rp),'status':r['status'],'test_totals_from_receipt':None if n==STAGES[2] else totals(r),'failed_initial_count_scope':'Failure raw retained; absent receipt summary is not zero executed tests' if n==STAGES[2] else None,'source_count':4907})
 final=load(B/STAGES[-1]/'execution.json'); frozen=final['frozen_cli']; verify(frozen)
 assert replay['cli_binding']['cli']=={k:frozen[k] for k in ('path','bytes','sha256')} and replay['cli_binding']['receipt']['sha256']==pin(B/STAGES[-1]/'execution.json')['sha256']
 for q in replay['jdk_tool_pins'].values(): verify(q)
 add(replay_path); add(audit_path); streams(replay_path,replay)
 receipts.append({'path':str(replay_path),'status':replay['status'],'command_count':21})
 assert {str(p.resolve()) for p in replay_path.parent.glob('*.raw')}=={p for p in raw if Path(p).parent==replay_path.parent}
 for data in replay['original_class_byte_parity'].values():
  p=add(data['compiled']['path']); bind(p,data['compiled'],replay_path)
 for q in replay['rebuilt_class_files']+[replay['original_runner_crosscheck']['class_pin']]:
  p=add(q['path']); bind(p,q,replay_path)
 assert len(replay['original_class_byte_parity'])==len(replay['rebuilt_class_files'])==len(replay['wide_reports'])==7
 for data in replay['wide_reports'].values():
  q=data['generated_java_exact_text_pin']; p=add(q['path']); bind(p,q,replay_path)
  report=data['saved_json']; f=add(report['path']); bind(f,report,replay_path); assert p.read_bytes()==load(f)['text'].encode('utf-8')
 for q in replay['fixture_pins']:
  p=add(q['path'],None if Path(q['path']).is_relative_to(B) else 'source-inputs/'+str(Path(q['path']).relative_to(ROOT))); bind(p,q,replay_path)
 # Include actual runner/support source scripts, never native CLI/JDK/Python executables.
 support=[final['runner'],*(final['dependencies'][k] for k in ('guard','target_scan','source_closure_runner'))]
 support.extend(q for q in replay['input_manifest_before'] if q['path'].endswith('.py') and not Path(q['path']).is_relative_to(ROOT) and 'pythonlib' not in q['path'])
 for q in support:
  p=add(q['path']); bind(p,q,replay_path if q in replay['input_manifest_before'] else B/STAGES[-1]/'execution.json')
 selected=['facade-before.rs','production-applied-v1.diff','identity-wrapper-removal-v3.diff','old-native-root-acceptance-v1.json','old-ordinary-root-acceptance-v1.json','fixed-jdk23-v2-independent-audit.json','final-focused-independent-audit-v1.json','final-focused-root-acceptance-v1.json','old-observer-static-review-v1.json','candidate-static-review-v1.json']
 selected.extend(['old-native-commands-v1.json','old-ordinary-commands-v1.json','fixed-initial-commands-v1.json','fixed-jdk23-commands-v2.json','final-focused-commands-v1.json'])
 for name in selected: add(D/name)
 harness=replay_path.parent.parent
 for name in ['harness-static-review-v1.json','harness-independent-review-v2.json','harness-static-review-v3.json','preparation-pins-v3.json','README-v3.md']:
  if (harness/name).is_file(): add(harness/name)
 add(Path(__file__)); add(HERE/'README.md')
 assert {p for p in items if p.endswith('.raw')}==set(raw)
 external={q['path']:q for q in replay['input_manifest_before'] if q['path'] not in items}
 old_package=B/'CORE/reference-overload-old-evidence-package-v1/reference-overload-old-evidence-v1.tar.gz'
 plan={'schema':'reference-overload-final-local-allowlist-v1','status':'prepared_not_packaged','items':sorted(items.values(),key=lambda q:q['archive_path']),'receipts':receipts,'raw_pins':list(raw.values()),'receipt_file_bindings':bindings,'compiled_source_overlays':overlays,'baseline_commit_for_other_source_files':'7532d618800287aa147a878ef509201ded80b004','external_replay_input_pins':list(external.values()),'external_frozen_cli':frozen,'external_jdk_tool_pins':replay['jdk_tool_pins'],'external_old_package':pin(old_package),'replay_independent_audit':pin(audit_path),'scope':'Local evidence only. Preserve old15pass6fail, ordinary4pass, initial JDK-environment failure, intermediate272pass and final325pass/0fail/1ignored distinctly. Only final frozen CLI and actual21-command replay bind final runtime evidence. Historical pending flags/failed records stay unchanged; no own-CI or future implementation claim. Native binaries and duplicate old tar excluded.'}
 out=args.out.resolve(); assert out.is_relative_to(HERE) and not out.exists(); out.mkdir(); (out/'allowlist.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'status':plan['status'],'allowlist':pin(out/'allowlist.json'),'items':len(items),'raw_files':len(raw)},indent=2))
def package(args):
 allow=args.allowlist.resolve(); plan=load(allow); assert plan['status']=='prepared_not_packaged'; payload={}
 for q in plan['items']:
  verify(q); p=Path(q['path']); arc=q['archive_path']; assert p.is_file() and not p.is_symlink() and arc.startswith(PREFIX) and '..' not in PurePosixPath(arc).parts and not PurePosixPath(arc).is_absolute() and arc not in payload
  data=p.read_bytes(); assert not data.startswith((b'\x7fELF',b'MZ')); payload[arc]=data
 assert {q['path'] for q in plan['items'] if q['path'].endswith('.raw')}=={q['path'] for q in plan['raw_pins']}
 for q in plan['raw_pins']: verify(q)
 for q in [plan['external_frozen_cli'],*plan['external_jdk_tool_pins'].values(),plan['replay_independent_audit']]: verify(q)
 manifest={**plan,'status':'packaged_and_reopened_verified','allowlist':pin(allow)}; data=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode(); payload['reference-overload-final-local-manifest.json']=data
 out=args.out.resolve(); assert out.is_relative_to(HERE) and not out.exists() and out.parent.exists()
 with tarfile.open(out,'w:gz',format=tarfile.PAX_FORMAT) as t:
  for name,z in sorted(payload.items()):
   m=tarfile.TarInfo(name); m.size=len(z); m.mode=0o444; m.mtime=0; t.addfile(m,io.BytesIO(z))
 with tarfile.open(out,'r:gz') as t:
  members=t.getmembers(); assert len(members)==len(payload) and len({m.name for m in members})==len(members) and all(m.isfile() for m in members) and {m.name for m in members}==set(payload)
  for m in members: assert t.extractfile(m).read()==payload[m.name]
 for q in plan['items']: assert Path(q['path']).read_bytes()==payload[q['archive_path']]
 (out.parent/'manifest.json').write_bytes(data); execution={'status':'packaged_and_reopened_verified','archive':pin(out),'manifest':pin(out.parent/'manifest.json'),'allowlist':pin(allow),'packager':pin(Path(__file__)),'payload_files':len(plan['items']),'tar_members':len(payload),'raw_files':len(plan['raw_pins'])}; (out.parent/'execution.json').write_text(json.dumps(execution,indent=2)+'\n'); print(json.dumps(execution,indent=2))
if __name__=='__main__':
 parser=argparse.ArgumentParser(); sub=parser.add_subparsers(dest='mode',required=True)
 p=sub.add_parser('prepare'); p.add_argument('--replay',type=Path,required=True); p.add_argument('--audit',type=Path,required=True); p.add_argument('--out',type=Path,required=True)
 p=sub.add_parser('package'); p.add_argument('--allowlist',type=Path,required=True); p.add_argument('--out',type=Path,required=True)
 args=parser.parse_args(); prepare(args) if args.mode=='prepare' else package(args)
