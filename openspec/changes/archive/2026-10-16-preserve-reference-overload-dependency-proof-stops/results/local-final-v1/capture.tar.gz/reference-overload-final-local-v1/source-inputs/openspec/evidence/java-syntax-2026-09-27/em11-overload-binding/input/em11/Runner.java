package em11;

public class Runner {
    public static void main(String[] args) {
        System.out.println(OverloadCalls.run("text"));
        System.out.println(OverloadCalls.run(new Object()));
        System.out.println(HierarchyCalls.run());
        System.out.println(InputHierarchyCalls.run());
        System.out.println("created=" + HLeaf.created);
    }
}
