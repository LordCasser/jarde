#!/usr/bin/env python3
"""Prepared v3, fixed-scope EM11 final-CLI source/rebuild/runtime and quota replay.

Prepared only. Do not execute until the root agent accepts the frozen CLI and
build receipt. When run, this performs 21 guarded JDK/CLI commands and keeps all
raw streams and intermediate artifacts on success or failure.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, re, shutil, sys, zipfile
from pathlib import Path

PYTHON = Path('/home/lordcasser/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3')
PYTHONLIB = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/pythonlib')
if tuple(sys.version_info[:2]) != (3, 12) or Path(sys.executable).resolve() != PYTHON.resolve():
    raise SystemExit('use pinned bundled Python 3.12 for BLAKE3 class identity checks')
sys.path.insert(0, str(PYTHONLIB))
import blake3

BASE = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015').resolve()
ROOT = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde').resolve()
EVIDENCE = ROOT / 'openspec/evidence/java-syntax-2026-09-27/em11-overload-binding'
SOURCE_DIR = EVIDENCE / 'input/em11'
HISTORY = EVIDENCE / 'observed-after/results.json'
JAR = ROOT / 'tests/fixtures/em11-reference-overload.jar'
GUARD_PATH = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/guard.py')
SCAN_PATH = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/target_scan.py')
SOURCE_CLOSURE = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/workspace_runner.py')
JDK_MANIFEST = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jdk-manifest.json')
CLI_BINDING_HELPER = BASE / 'interface-full-source-harness-v4/run_interface_full_source_harness.py'
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3
PINNED_TOOL_HELPERS = {
    str(GUARD_PATH): 'a312c70cd7e4f15851d26dd27f51127d441ba5f886bc54c1118e6f533b5fdb39',
    str(SCAN_PATH): 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7',
    str(SOURCE_CLOSURE): '1321734497436389470a12452b29101656d64c7f94eb5526358ffc9822b8e467',
    str(JDK_MANIFEST): '5daeb9b6e864c3f28f62acc0b4c32bf61679546f6d7db077bd4171a6eafad6d6',
}
JAVA_NAMES = ['OverloadCalls', 'HBase', 'HMid', 'HLeaf', 'HierarchyCalls', 'InputHierarchyCalls', 'Runner']
CLASS_NAMES = ['em11/' + name for name in JAVA_NAMES]
EXPECTED_INPUTS = {
    'em11-reference-overload.jar': {'bytes': 5001, 'sha256': '7f424cfedc412c210679cf2d36377bc94b1fb599217b41e8dd4e6fbf0129b9e2'},
    'results.json': {'bytes': 9663, 'sha256': '80b8e22d971e528b2fb9eb60f4105d9d1151c9d842e897a8c012139c4a52d9ee'},
}
EXPECTED_SOURCE_SHA256 = {
    'OverloadCalls.java': '70e770c0ad6d8d7603424aad2f3ade770ca9a9dc088b20c743bd1d72c111f039',
    'HBase.java': '7afd52333324334eab3fd0081c5886ec70e5719c41dea45fa979835ff5313c61',
    'HMid.java': '7ccca56a237ba487007d840396175e1965298c6df5d38f0dc0b14b46c19e8242',
    'HLeaf.java': '7e2d7510ea267a477d846a0462958e0000daf144e9c035c47ba7439eaac0f865',
    'HierarchyCalls.java': '645cb3ac7f814c00df0843f9062640b3945a10297edd27a852593c4a49b71036',
    'InputHierarchyCalls.java': '7ed377093f91aa83f12140314388fec0d98bff823ea3a61674bf80766036860d',
    'Runner.java': '7e4ef28ad861e965b445aca8810e277c186417b45573cd0ccec8738377347d79',
}
EXPECTED_CLASS_SHA256 = {
    'OverloadCalls': '64baa8dcfdf1bd01ee1d6cb077c7fed7362a0c374d6f195c45fd1c6393c2a92f',
    'HBase': 'd8cd1a76c2c8735bd6ab570ec4bf548a41897153cd3889324b02099f7f0dd509',
    'HMid': '0e3fe0ddb9374f632c0be7a1d34091ad53ee5bdd69b5ba957fa23fe6373b9737',
    'HLeaf': 'a022590ccfe8189cb732762f193aac7cf67730e98b0f202f3b351fdeee5e67c7',
    'HierarchyCalls': '2f8553ab161dd522ec4e25b4edead504c0e78fb2626476104317c54c6c4b0794',
    'InputHierarchyCalls': 'bb50ace457448dfbc1dd2a42a1a8a2413250b097d03e5bf5c235230cccb925b4',
    'Runner': 'bd0fed29f45a505a3ac6851371f61b28119e14a94a811d0ac807a29995fa08d2',
}
ORACLE = (b'ArrayList/List/String/List/ArrayList/String/Object[][]/int[][]\n'
          b'ArrayList/List/String/List/ArrayList/none/Object[][]/int[][]\n'
          b'leaf-ArrayList/mid-List/base-String/mid-List/leaf-ArrayList/base-String/mid-List\n'
          b'mid\ncreated=2\n')


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def pin(path: Path) -> dict:
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def write_record(out: Path, record: dict) -> None:
    temp = out / 'execution.json.tmp'
    temp.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temp.replace(out / 'execution.json')

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--cli', type=Path, required=True, help='frozen CLI named by --build-receipt')
    ap.add_argument('--build-receipt', type=Path, required=True, help='actual accepted final focused-build execution.json')
    ap.add_argument('--out', type=Path, required=True, help='fresh output directory under this harness directory')
    args = ap.parse_args()
    script_dir = Path(__file__).resolve().parent
    out = args.out.resolve()
    if not out.is_relative_to(script_dir) or out.exists():
        raise SystemExit('output must be a fresh child of this harness directory')
    out.mkdir(parents=True, exist_ok=False)
    record = {'schema': 'reference-overload-final-cli-replay-harness-v3', 'status': 'preflight',
              'scope': 'Final accepted CLI bound to actual build receipt; original seven Java sources compile unchanged and match all seven input-JAR class bytes; javap pins physical InputHierarchyCalls run NEW/constructor/call BCIs; seven all-evidence wide JSON class reports saved verbatim and all seven generated Java files compiled without filtering; original JAR and rebuilt classes run on Java 8/23 against the exact five-line oracle; original Runner separately compiled against rebuilt output and run first on Java 8/23; InputHierarchyCalls all-evidence class_headers 1/2/3/4 reports compare complete member prefix and result planes while retaining all usage/diagnostics. Cap1/2 serialization is only a public stop/prefix control and does not independently establish the first dependency stop; that claim requires the native red/green origin and fee comparison. No old-JADX substitution or claim based only on original source success.',
              'first_dependency_stop_claimed_by_cli_matrix': False,
              'expected_command_count': 21, 'cli_argument': str(args.cli.resolve()), 'build_receipt_argument': str(args.build_receipt.resolve()),
              'guards': {'minimum_free_bytes': FREE_LIMIT, 'maximum_target_bytes': TARGET_LIMIT, 'default_stack': True}, 'commands': []}
    write_record(out, record)

    source_files = [SOURCE_DIR / (name + '.java') for name in JAVA_NAMES]
    required = [args.cli, args.build_receipt, JAR, HISTORY, *source_files, GUARD_PATH, SCAN_PATH, SOURCE_CLOSURE,
                JDK_MANIFEST, CLI_BINDING_HELPER, PYTHON, PYTHONLIB / 'blake3/__init__.py',
                PYTHONLIB / 'blake3/blake3.cpython-312-x86_64-linux-gnu.so']
    missing = [str(p) for p in required if not p.is_file()]
    if missing:
        record.update({'status': 'preflight_inputs_missing', 'missing_inputs': missing})
        write_record(out, record)
        return 2
    try:
        for pinned_path, expected_sha in PINNED_TOOL_HELPERS.items():
            if sha(Path(pinned_path)) != expected_sha:
                raise RuntimeError(f'pinned execution helper changed: {pinned_path}')
        if (ROOT / 'target').exists():
            raise RuntimeError('fresh-target preflight failed: workspace target must be absent')
        if shutil.disk_usage(ROOT).free < FREE_LIMIT:
            raise RuntimeError('5 GiB free-space preflight failed')
        fixture_pins = [pin(JAR), pin(HISTORY), *[pin(p) for p in source_files]]
        if pin(JAR)['bytes'] != EXPECTED_INPUTS['em11-reference-overload.jar']['bytes'] or pin(JAR)['sha256'] != EXPECTED_INPUTS['em11-reference-overload.jar']['sha256']:
            raise RuntimeError('fixed 5001-byte EM11 input JAR pin mismatch')
        if pin(HISTORY)['bytes'] != EXPECTED_INPUTS['results.json']['bytes'] or pin(HISTORY)['sha256'] != EXPECTED_INPUTS['results.json']['sha256']:
            raise RuntimeError('historical EM11 results pin mismatch')
        for p in source_files:
            if sha(p) != EXPECTED_SOURCE_SHA256[p.name]:
                raise RuntimeError(f'original Java input changed: {p.name}')
        history = json.loads(HISTORY.read_text(encoding='utf-8'))
        if history.get('original', {}).get('stdout', '').encode('utf-8') != ORACLE or len(ORACLE) != 219 or ORACLE.count(b'\n') != 5:
            raise RuntimeError('fixed original Runner five-line/219-byte oracle mismatch')
        if history.get('input_source_sha256') != EXPECTED_SOURCE_SHA256 or history.get('original_class_sha256') != EXPECTED_CLASS_SHA256:
            raise RuntimeError('historical source/class maps differ from pinned EM11 inputs')
        jdk_doc = json.loads(JDK_MANIFEST.read_text(encoding='utf-8'))
        javac23_row = next(row for row in jdk_doc['legs'] if row.get('leg') == 'javac23')['jdk_tools']
        java8_row = next(row for row in jdk_doc['legs'] if row.get('leg') == 'javac8')['jdk_tools']
        tool_paths = {'javac23': Path(javac23_row['javac']['path']).resolve(),
                      'java23': Path(javac23_row['java']['path']).resolve(),
                      'javap23': Path(javac23_row['javap']['path']).resolve(),
                      'java8': Path(java8_row['java']['path']).resolve()}
        for tool_name, tool_path in tool_paths.items():
            if not tool_path.is_file():
                missing.append(str(tool_path))
        if missing:
            record.update({'status': 'preflight_inputs_missing', 'missing_inputs': missing})
            write_record(out, record)
            return 2
        receipt = json.loads(args.build_receipt.read_text(encoding='utf-8'))
        frozen = receipt.get('frozen_cli')
        cli_pin = pin(args.cli)
        if not isinstance(frozen, dict):
            raise RuntimeError('build receipt lacks frozen_cli record')
        if (Path(frozen.get('path', '')).resolve() != args.cli.resolve() or frozen.get('bytes') != cli_pin['bytes']
                or frozen.get('sha256') != cli_pin['sha256'] or frozen.get('mode') != '0555'
                or (args.cli.stat().st_mode & 0o777) != 0o555):
            raise RuntimeError('supplied final CLI does not exactly match its build receipt path/bytes/SHA/mode')
        source_manifest = receipt.get('source_manifest_before')
        if not isinstance(source_manifest, list) or source_manifest != receipt.get('source_manifest_after') or receipt.get('target_absent') is not True:
            raise RuntimeError('build receipt lacks identical source manifests and target_absent=true')
        current_sources = []
        for row in source_manifest:
            actual = pin(ROOT / row['path'])
            if actual['bytes'] != row['bytes'] or actual['sha256'] != row['sha256']:
                raise RuntimeError(f'workspace source differs from frozen build receipt: {row["path"]}')
            current_sources.append(actual)

        cli_helper = load('em11_final_cli_binding', CLI_BINDING_HELPER)
        cli_binding = cli_helper.verify_cli(args.cli.resolve(), args.build_receipt.resolve())
        # Independently bind the full workspace source closure and every execution input.
        closure_rows = source_manifest
        closure_digest = hashlib.sha256(json.dumps(closure_rows, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        jdk_tool_pins = {name: pin(path) for name, path in tool_paths.items()}
        for name, row in [('javac23', javac23_row['javac']), ('java23', javac23_row['java']),
                          ('javap23', javac23_row['javap']), ('java8', java8_row['java'])]:
            if jdk_tool_pins[name]['bytes'] != row['bytes'] or jdk_tool_pins[name]['sha256'] != row['sha256']:
                raise RuntimeError(f'JDK tool pin mismatch: {name}')
        py_module = PYTHONLIB / 'blake3/__init__.py'
        py_native = PYTHONLIB / 'blake3/blake3.cpython-312-x86_64-linux-gnu.so'
        input_paths = sorted(set([Path(__file__).resolve(), args.cli.resolve(), args.build_receipt.resolve(), JAR.resolve(), HISTORY.resolve(),
                                  *[p.resolve() for p in source_files], GUARD_PATH.resolve(), SCAN_PATH.resolve(), SOURCE_CLOSURE.resolve(),
                                  JDK_MANIFEST.resolve(), CLI_BINDING_HELPER.resolve(), PYTHON.resolve(), py_module.resolve(), py_native.resolve(),
                                  *tool_paths.values(), *(ROOT / row['path'] for row in source_manifest)]))
        before = [pin(p) for p in input_paths]
        record.update({'status': 'running', 'cli_binding': cli_binding, 'frozen_cli': frozen,
                       'source_manifest_count': len(source_manifest), 'source_manifest_sha256': closure_digest,
                       'fixture_pins': fixture_pins, 'oracle_utf8_bytes': len(ORACLE), 'oracle_sha256': hashlib.sha256(ORACLE).hexdigest(),
                       'jdk_manifest': pin(JDK_MANIFEST), 'jdk_tool_pins': jdk_tool_pins,
                       'guard': pin(GUARD_PATH), 'target_scan': pin(SCAN_PATH), 'source_closure_runner': pin(SOURCE_CLOSURE),
                       'python_blake3': {'python': pin(PYTHON), 'module': pin(py_module), 'native_extension': pin(py_native), 'version': getattr(blake3, '__version__', 'unknown')},
                       'input_manifest_before': before, 'commands': []})
        write_record(out, record)

        original_dir = out / 'original-seven-classes'
        reports_dir = out / 'wide-json-reports'
        generated_dir = out / 'generated-java'
        rebuilt_dir = out / 'rebuilt-classes'
        cross_runner_dir = out / 'original-runner-crosscheck-classes'
        for folder in (original_dir, reports_dir, generated_dir / 'em11', rebuilt_dir, cross_runner_dir):
            folder.mkdir(parents=True, exist_ok=False)
        guard = load('em11_final_cli_guard', GUARD_PATH)
        scanner = load('em11_final_cli_target_scan', SCAN_PATH)
        guard.ROOT = ROOT
        guard.OUT = out
        guard.FREE_LIMIT = FREE_LIMIT
        guard.TARGET_LIMIT = TARGET_LIMIT
        guard.target_bytes = lambda: scanner.target_bytes(ROOT)
        guard.expected_test_summaries = lambda _index, _data: None
        guard.command_stream = lambda path: pin(Path(path))
        guard.ENV_VALUES = {}
        env = {k: v for k, v in os.environ.items() if k in ('HOME', 'TMPDIR', 'LANG', 'LC_ALL')}
        for key in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'RUST_MIN_STACK', 'CARGO_TARGET_DIR'):
            env.pop(key, None)
        env['PATH'] = '/usr/bin:/bin'
        rows = record['commands']

        def save():
            write_record(out, record)

        def run(label: str, argv: list[Path | str], expected_exit: int = 0) -> dict:
            cmd = [str(value) for value in argv]
            row = guard.run_command(len(rows) + 1, cmd, env)
            row.update({'label': label, 'argv_exact': cmd, 'cwd': str(ROOT), 'expected_exit': expected_exit,
                        'guard_status': 'stopped' if row.get('guard_stop') is not None else 'clear'})
            rows.append(row)
            save()
            if row.get('guard_stop') is not None:
                raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}; raw streams retained')
            if row.get('exit_code') != expected_exit:
                raise RuntimeError(f'{label} exit {row.get("exit_code")}, expected {expected_exit}; raw streams retained')
            return row

        # 1. Rebuild all seven unchanged Java inputs and verify every physical class byte.
        run('javac23-release8-g-none-original-seven-unchanged-sources', [tool_paths['javac23'], '--release', '8', '-g:none', '-Xlint:-options', '-d', original_dir, *source_files])
        generated_original_classes = sorted(original_dir.rglob('*.class'))
        original_by_name = {p.relative_to(original_dir).as_posix(): p for p in generated_original_classes}
        if set(original_by_name) != {name + '.class' for name in CLASS_NAMES}:
            raise RuntimeError(f'original Java compilation produced unexpected class inventory: {sorted(original_by_name)}')
        with zipfile.ZipFile(JAR) as jar:
            jar_class_names = sorted(info.filename for info in jar.infolist() if info.filename.endswith('.class'))
            if jar_class_names != sorted(name + '.class' for name in CLASS_NAMES):
                raise RuntimeError(f'input JAR physical class inventory changed: {jar_class_names}')
            original_class_checks = {}
            for short_name, internal_name in zip(JAVA_NAMES, CLASS_NAMES):
                jar_bytes = jar.read(internal_name + '.class')
                compiled_bytes = original_by_name[internal_name + '.class'].read_bytes()
                if hashlib.sha256(jar_bytes).hexdigest() != EXPECTED_CLASS_SHA256[short_name]:
                    raise RuntimeError(f'JAR class hash differs from historical pin: {internal_name}')
                if compiled_bytes != jar_bytes:
                    raise RuntimeError(f'JDK23 original source class bytes differ from input JAR: {internal_name}')
                original_class_checks[internal_name] = {'jar': {'bytes': len(jar_bytes), 'sha256': hashlib.sha256(jar_bytes).hexdigest()},
                                                        'compiled': pin(original_by_name[internal_name + '.class']), 'byte_identical': True}
        record['original_class_byte_parity'] = original_class_checks
        save()

        # 2. Pin the complete physical instruction path: NEW 0, dup 3, HLeaf constructor 4, static overload call 7, areturn 10.
        javap_row = run('javap-original-InputHierarchyCalls-physical-Code', [tool_paths['javap23'], '-classpath', original_dir, '-p', '-c', '-s', 'em11.InputHierarchyCalls'])
        javap_text = Path(javap_row['streams']['stdout']['path']).read_text(encoding='utf-8', errors='strict')
        method_match = re.search(r'public static java\.lang\.String run\(\);(?P<body>.*?)(?=\n\s*public |\Z)', javap_text, re.S)
        if not method_match:
            raise RuntimeError('javap output lacks InputHierarchyCalls.run() body')
        code = method_match.group('body')
        physical_sites = {'new_hleaf_at_0': bool(re.search(r'^\s*0:\s+new\s+#[0-9]+\s+// class em11/HLeaf\s*$', code, re.M)),
                          'dup_at_3': bool(re.search(r'^\s*3:\s+dup\s*$', code, re.M)),
                          'constructor_hleaf_at_4': bool(re.search(r'^\s*4:\s+invokespecial\s+#[0-9]+\s+// Method em11/HLeaf\."<init>":\(\)V\s*$', code, re.M)),
                          'overload_call_at_7': bool(re.search(r'^\s*7:\s+invokestatic\s+#[0-9]+\s+// Method take:\(Lem11/HMid;\)Ljava/lang/String;\s*$', code, re.M)),
                          'areturn_at_10': bool(re.search(r'^\s*10:\s+areturn\s*$', code, re.M))}
        if not all(physical_sites.values()):
            raise RuntimeError(f'javap physical BCI assertions failed: {physical_sites}; output retained')
        record['javap_physical_callsite'] = {'raw_output': javap_row['streams']['stdout'], 'checks': physical_sites, 'run_method_block': code,
                  'complete_instruction_offsets': [0, 3, 4, 7, 10],
                  'producer_consumer_note': 'BCI0 NEW is the physical producer; BCI4 is the HLeaf constructor call and SourceMap primary anchor.'}
        save()

        # 3-9. Save the exact JSON and exact Java text from all seven wide CLI reports.
        wide_reports = {}
        generated_sources = {}
        for idx, internal_name in enumerate(CLASS_NAMES, start=3):
            argv = [args.cli, 'class-source', '--input', JAR, '--class', internal_name, '--policy', 'plain-jar', '--release', '8',
                    '--format', 'json', '--evidence', 'all', '--budget', 'class_headers=4096', '--budget', 'elapsed_millis=10000']
            row = run(f'final-cli-wide-{internal_name}', argv)
            document = json.loads(Path(row['streams']['stdout']['path']).read_text(encoding='utf-8'))
            class_info = document.get('class', {})
            entry = class_info.get('location', {}).get('entry', {})
            selected_entry = bytes(entry.get('raw_name', [])).decode('utf-8')
            if selected_entry != internal_name + '.class':
                raise RuntimeError(f'{internal_name}: report selected {selected_entry!r}')
            raw_class = zipfile.ZipFile(JAR).read(selected_entry)
            measured_blake3 = blake3.blake3(raw_class).hexdigest()
            if (class_info.get('class_bytes', {}).get('length') != len(raw_class)
                    or class_info.get('class_bytes', {}).get('digest') != measured_blake3
                    or document.get('execution', {}).get('status') != 'complete'):
                raise RuntimeError(f'{internal_name}: wide CLI class identity or complete status mismatch')
            source_text = document.get('text')
            if not isinstance(source_text, str) or not source_text:
                raise RuntimeError(f'{internal_name}: wide CLI JSON has no nonempty text')
            report_copy = reports_dir / (internal_name.replace('/', '_') + '.json')
            report_copy.write_bytes(Path(row['streams']['stdout']['path']).read_bytes())
            source_path = generated_dir / (internal_name + '.java')
            source_path.parent.mkdir(parents=True, exist_ok=True)
            source_path.write_bytes(source_text.encode('utf-8'))
            wide_reports[internal_name] = {'command_index': idx, 'json_raw': pin(Path(row['streams']['stdout']['path'])),
                                           'saved_json': pin(report_copy), 'selected_entry': selected_entry,
                                           'class_sha256_in_input_jar': hashlib.sha256(raw_class).hexdigest(),
                                           'class_blake3_in_report': measured_blake3, 'text_utf8_bytes': len(source_text.encode('utf-8')),
                                           'generated_java_exact_text_pin': pin(source_path), 'execution': document.get('execution')}
            generated_sources[internal_name] = source_path
            row.update({'selected_entry': selected_entry, 'class_sha256_in_input_jar': hashlib.sha256(raw_class).hexdigest(),
                        'class_blake3_verified': measured_blake3, 'saved_report': pin(report_copy), 'generated_java': pin(source_path)})
            if internal_name == 'em11/InputHierarchyCalls':
                wide_input_document = document
            save()
        record['wide_reports'] = wide_reports
        save()

        # 10. Compile every generated Java file exactly as emitted, including Runner.
        run('javac23-release8-g-none-all-seven-generated-java-unmodified', [tool_paths['javac23'], '--release', '8', '-g:none', '-Xlint:-options',
             '-d', rebuilt_dir, *[generated_sources[name] for name in CLASS_NAMES]])
        if {p.relative_to(rebuilt_dir).as_posix() for p in rebuilt_dir.rglob('*.class')} != {name + '.class' for name in CLASS_NAMES}:
            raise RuntimeError('generated-source compilation did not produce exactly all seven class files')
        record['rebuilt_class_files'] = [pin(p) for p in sorted(rebuilt_dir.rglob('*.class'))]
        save()

        # 11-14. Run original JAR and the rebuilt output on Java 8 and Java 23.
        for label, java, cp in [('java8-original-jar', tool_paths['java8'], JAR), ('java23-original-jar', tool_paths['java23'], JAR),
                                ('java8-all-seven-rebuilt', tool_paths['java8'], rebuilt_dir), ('java23-all-seven-rebuilt', tool_paths['java23'], rebuilt_dir)]:
            row = run(label, [java, '-Xverify:all', '-cp', cp, 'em11.Runner'])
            actual = Path(row['streams']['stdout']['path']).read_bytes()
            if actual != ORACLE:
                raise RuntimeError(f'{label} stdout differs from exact original five-line oracle')
            if Path(row['streams']['stderr']['path']).read_bytes():
                raise RuntimeError(f'{label} emitted stderr')
            row['oracle_stdout_equal'] = True
            row['oracle_stdout_bytes'] = len(actual)
            row['oracle_stdout_sha256'] = hashlib.sha256(actual).hexdigest()
            row['stderr_empty'] = True
            save()

        # 15-16. Compile the untouched original Runner alone against rebuilt classes;
        # run it first on the classpath so no original JAR or original classes leak in.
        runner_source = source_files[JAVA_NAMES.index('Runner')]
        run('javac23-release8-g-none-original-Runner-only-classpath-rebuilt', [tool_paths['javac23'], '--release', '8', '-g:none', '-Xlint:-options',
             '-classpath', rebuilt_dir, '-d', cross_runner_dir, runner_source])
        runner_class = cross_runner_dir / 'em11/Runner.class'
        if not runner_class.is_file():
            raise RuntimeError('separately compiled original Runner class is missing')
        record['original_runner_crosscheck'] = {'source_pin': pin(runner_source), 'class_pin': pin(runner_class),
                                                'compile_classpath_only_rebuilt': True, 'runtime_classpath_order': 'original-runner-crosscheck-classes:rebuilt-classes'}
        save()
        cross_cp = str(cross_runner_dir) + os.pathsep + str(rebuilt_dir)
        for label, java in [('java8-original-Runner-first-rebuilt', tool_paths['java8']), ('java23-original-Runner-first-rebuilt', tool_paths['java23'])]:
            row = run(label, [java, '-Xverify:all', '-cp', cross_cp, 'em11.Runner'])
            actual = Path(row['streams']['stdout']['path']).read_bytes()
            if actual != ORACLE or Path(row['streams']['stderr']['path']).read_bytes():
                raise RuntimeError(f'{label} differs from exact oracle or emitted stderr')
            row['oracle_stdout_equal'] = True
            row['oracle_stdout_bytes'] = len(actual)
            row['oracle_stdout_sha256'] = hashlib.sha256(actual).hexdigest()
            row['stderr_empty'] = True
            row['classpath_order'] = ['original-runner-crosscheck-classes', 'rebuilt-classes']
            row['original_input_jar_on_classpath'] = False
            save()

        # 18-21. Full JSON all-evidence budget matrix. Cap1/2 prove only stopped
        # serialization/prefix retention; first dependency-stop acceptance comes
        # from the native red/green origin and fee comparison, not this CLI output.
        budget_rows = []
        record['budget_matrix'] = budget_rows
        target_descriptor = '()Ljava/lang/String;'
        def method_for(document, cap):
            hits = [m for m in document.get('methods', [])
                    if m.get('item', {}).get('name', {}).get('escaped') == 'run'
                    and m.get('item', {}).get('descriptor', {}).get('escaped') == target_descriptor]
            if len(hits) != 1:
                raise RuntimeError(f'cap{cap}: expected exactly one physical run()Ljava/lang/String; record')
            return hits[0]
        def normalize_usage_elapsed(value, in_usage=False):
            if isinstance(value, dict):
                result = {}
                for key, child in value.items():
                    if in_usage and key == 'elapsed_millis':
                        continue
                    result[key] = normalize_usage_elapsed(child, key == 'usage')
                return result
            if isinstance(value, list):
                return [normalize_usage_elapsed(child, in_usage) for child in value]
            return value
        def key_paths(value, target, path='$'):
            found = []
            if isinstance(value, dict):
                for key, child in value.items():
                    child_path = f'{path}.{key}'
                    if key == target:
                        found.append((child_path, child))
                    found.extend(key_paths(child, target, child_path))
            elif isinstance(value, list):
                for index, child in enumerate(value):
                    found.extend(key_paths(child, target, f'{path}[{index}]'))
            return found
        wide_methods = wide_input_document.get('methods', [])
        wide_method = method_for(wide_input_document, 4096)
        wide_body = wide_method.get('outcome', {}).get('report', {})
        wide_source_map = wide_body.get('source_map', {})
        if (wide_body.get('execution', {}).get('status') != 'complete' or wide_body.get('content') != 'contains_statements'
                or not wide_source_map.get('segments') or '(em11.HMid) new em11.HLeaf()' not in wide_method.get('text', '')):
            raise RuntimeError('wide InputHierarchyCalls report lacks the cast/new overload source and SourceMap segments')
        wide_identity = wide_method.get('item', {}).get('identity')
        cast_span = b'(em11.HMid) new em11.HLeaf()'
        wide_text_bytes = wide_body.get('text', '').encode('utf-8')
        cast_segments = []
        for segment_index, segment in enumerate(wide_source_map.get('segments', [])):
            start, end = segment.get('start'), segment.get('end')
            if not isinstance(start, int) or not isinstance(end, int) or not (0 <= start <= end <= len(wide_text_bytes)):
                raise RuntimeError(f'wide SourceMap segment{segment_index} has invalid UTF-8 byte offsets: {segment}')
            actual_span = wide_text_bytes[start:end]
            if actual_span == cast_span:
                origin = segment.get('origin', {})
                primary = origin.get('primary', {})
                derived = origin.get('derived', [])
                derived_bcis = [item.get('bci') for item in derived]
                if (primary.get('bci') != 4 or derived_bcis != [0, 3, 7]
                        or primary.get('method') != wide_identity
                        or any(item.get('method') != wide_identity for item in derived)):
                    raise RuntimeError(f'cast SourceMap origin differs from exact method/BCI anchors: {origin}')
                cast_segments.append({'segment_index': segment_index, 'start_utf8_byte': start, 'end_utf8_byte': end,
                                      'actual_span_utf8': actual_span.decode('utf-8'), 'actual_span_hex': actual_span.hex(),
                                      'origin': origin})
        if len(cast_segments) != 1:
            raise RuntimeError(f'wide SourceMap requires exactly one exact cast span, got {len(cast_segments)}')
        record['source_map_cast_anchor'] = {'span_utf8': cast_span.decode('utf-8'),
                  'segment': cast_segments[0], 'primary_bci_role': 'constructor anchor, not NEW producer',
                  'derived_bcis': [0, 3, 7], 'method_identity_equal_for_primary_and_all_derived': True}
        if len(wide_methods) != 4:
            raise RuntimeError(f'wide InputHierarchyCalls report has {len(wide_methods)} methods, expected four physical members')
        wide_methods_by_index = {m.get('item', {}).get('index'): m for m in wide_methods}
        expected_prefix = [(0, '<init>', '()V'), (1, 'take', '(Lem11/HMid;)Ljava/lang/String;'),
                           (2, 'take', '(Lem11/HLeaf;)Ljava/lang/String;')]
        for method_index, method_name, descriptor in expected_prefix:
            member = wide_methods_by_index.get(method_index)
            if (member is None or member.get('item', {}).get('name', {}).get('escaped') != method_name
                    or member.get('item', {}).get('descriptor', {}).get('escaped') != descriptor
                    or member.get('outcome', {}).get('analysis', {}).get('execution', {}).get('status') != 'complete'
                    or member.get('outcome', {}).get('report', {}).get('execution', {}).get('status') != 'complete'
                    or member.get('outcome', {}).get('report', {}).get('content') != 'contains_statements'
                    or not member.get('outcome', {}).get('report', {}).get('source_map', {}).get('segments')):
                raise RuntimeError(f'wide report lacks complete physical prefix member {method_index}:{method_name}{descriptor}')
        wide_run = wide_methods_by_index.get(3)
        if wide_run is None or wide_run is not wide_method:
            raise RuntimeError('wide run member is not the physical fourth member')
        wide_limits_paths = key_paths(wide_input_document, 'limits')
        if [path for path, _ in wide_limits_paths] != ['$.limits'] or not isinstance(wide_input_document.get('limits'), dict):
            raise RuntimeError(f'wide document has unexpected limits paths: {[path for path, _ in wide_limits_paths]}')
        wide_limits = wide_input_document['limits']
        if wide_limits.get('class_headers') != 4096 or wide_limits.get('elapsed_millis') != 10000:
            raise RuntimeError(f'wide request limits do not reflect headers=4096 and elapsed=10000: {wide_limits}')
        record['limits_paths_verified'] = {'wide_document_paths': [path for path, _ in wide_limits_paths],
                                           'low_cap_paths_expected': ['$.limits'],
                                           'other_limit_fields_equal_wide': True,
                                           'elapsed_millis_limit': 10000}
        save()

        def compare_full_json_except_allowed(doc, cap):
            paths = key_paths(doc, 'limits')
            path_names = [path for path, _ in paths]
            if path_names != ['$.limits'] or not isinstance(doc.get('limits'), dict):
                raise RuntimeError(f'cap{cap}: unexpected limits object paths {path_names}')
            actual_limits = doc['limits']
            if set(actual_limits) != set(wide_limits):
                raise RuntimeError(f'cap{cap}: limits keys differ from wide')
            expected_limits = dict(wide_limits)
            expected_limits['class_headers'] = cap
            if actual_limits != expected_limits or actual_limits.get('elapsed_millis') != 10000:
                raise RuntimeError(f'cap{cap}: request limits do not differ from wide only at class_headers: {actual_limits}')
            actual_copy = json.loads(json.dumps(doc))
            wide_copy = json.loads(json.dumps(wide_input_document))
            # The only allowed full-document difference is the explicitly verified
            # top-level request limit; leave raw JSON and all result planes untouched.
            actual_copy['limits']['class_headers'] = wide_copy['limits']['class_headers']
            return normalize_usage_elapsed(actual_copy) == normalize_usage_elapsed(wide_copy), path_names, actual_limits

        for index, cap in enumerate((1, 2, 3, 4), start=18):
            row = run(f'final-cli-InputHierarchyCalls-all-class_headers-{cap}', [args.cli, 'class-source', '--input', JAR,
                       '--class', 'em11/InputHierarchyCalls', '--policy', 'plain-jar', '--release', '8', '--format', 'json', '--evidence', 'all',
                       '--budget', f'class_headers={cap}', '--budget', 'elapsed_millis=10000'], 0 if cap >= 3 else 4)
            doc = json.loads(Path(row['streams']['stdout']['path']).read_text(encoding='utf-8'))
            entry = doc.get('class', {}).get('location', {}).get('entry', {})
            if bytes(entry.get('raw_name', [])).decode('utf-8') != 'em11/InputHierarchyCalls.class':
                raise RuntimeError(f'cap{cap}: selected a different physical class')
            with zipfile.ZipFile(JAR) as jar:
                target_class = jar.read('em11/InputHierarchyCalls.class')
            ci = doc.get('class', {}).get('class_bytes', {})
            if ci.get('length') != len(target_class) or ci.get('digest') != blake3.blake3(target_class).hexdigest():
                raise RuntimeError(f'cap{cap}: physical InputHierarchyCalls identity mismatch')
            doc_methods = doc.get('methods', [])
            if len(doc_methods) != 4 or [m.get('item', {}).get('index') for m in doc_methods] != [0, 1, 2, 3]:
                raise RuntimeError(f'cap{cap}: expected the three paid prefix members and admitted run record')
            method = method_for(doc, cap)
            outcome = method.get('outcome', {})
            analysis = outcome.get('analysis', {})
            recovery = outcome.get('report', {})
            analysis_exec = analysis.get('execution', {})
            recovery_exec = recovery.get('execution', {})
            if method.get('item', {}).get('identity') != wide_method.get('item', {}).get('identity'):
                raise RuntimeError(f'cap{cap}: run method physical identity changed')
            if analysis_exec.get('status') != 'complete' or normalize_usage_elapsed(analysis) != normalize_usage_elapsed(wide_method.get('outcome', {}).get('analysis', {})):
                raise RuntimeError(f'cap{cap}: run analysis/prefix changed relative to wide report')
            prefix_evidence = []
            for method_index, method_name, descriptor in expected_prefix:
                prefix_member = next((m for m in doc_methods if m.get('item', {}).get('index') == method_index), None)
                wide_member = wide_methods_by_index[method_index]
                if (prefix_member is None or prefix_member.get('item', {}).get('name', {}).get('escaped') != method_name
                        or prefix_member.get('item', {}).get('descriptor', {}).get('escaped') != descriptor
                        or prefix_member.get('outcome', {}).get('analysis', {}).get('execution', {}).get('status') != 'complete'
                        or prefix_member.get('outcome', {}).get('report', {}).get('execution', {}).get('status') != 'complete'
                        or prefix_member.get('outcome', {}).get('report', {}).get('content') != 'contains_statements'
                        or not prefix_member.get('outcome', {}).get('report', {}).get('source_map', {}).get('segments')
                        or normalize_usage_elapsed(prefix_member) != normalize_usage_elapsed(wide_member)):
                    raise RuntimeError(f'cap{cap}: paid complete prefix member {method_index}:{method_name}{descriptor} differs from wide')
                prefix_evidence.append({'index': method_index, 'name': method_name, 'descriptor': descriptor,
                                        'identity': prefix_member.get('item', {}).get('identity'),
                                        'text_utf8_bytes': len(prefix_member.get('text', '').encode('utf-8')),
                                        'body_content': prefix_member.get('outcome', {}).get('report', {}).get('content'),
                                        'source_map_segment_count': len(prefix_member.get('outcome', {}).get('report', {}).get('source_map', {}).get('segments', [])),
                                        'full_member_equal_to_wide_except_usage_elapsed': True})
            limits_match, limit_paths, actual_limits = compare_full_json_except_allowed(doc, cap)
            row['verified_limits'] = {'paths': limit_paths, 'actual': actual_limits,
                                      'class_headers_equals_requested_cap': True, 'elapsed_millis_equals_10000': True,
                                      'all_other_fields_equal_wide': True}
            if cap <= 2:
                class_exec = doc.get('execution', {})
                reason = class_exec.get('reason', {})
                usage = class_exec.get('usage', {})
                diagnostics = doc.get('diagnostics', []) + recovery.get('diagnostics', [])
                has_header_refusal_diag = any(d.get('code') == 'budget_exceeded_class_headers'
                                              and f'limit={cap}, consumed={cap}, requested=1' in d.get('message', '')
                                              for d in diagnostics)
                if (class_exec.get('status') != 'partial' or reason.get('dimension') != 'class_headers'
                        or usage.get('class_headers') != cap or recovery_exec.get('status') != 'partial'
                        or recovery_exec.get('reason', {}).get('dimension') != 'class_headers'
                        or recovery.get('content') != 'not_produced' or recovery.get('text') != ''
                        or recovery.get('source_map', {}).get('segments') != [] or not has_header_refusal_diag):
                    raise RuntimeError(f'cap{cap}: stopped serialization lost ClassHeaders refusal/diagnostic or produced a later body/source')
                row['asserted_stop_serialization_only'] = {'status': 'partial', 'dimension': 'class_headers',
                        'header_refusal_diagnostic': True, 'three_complete_paid_prefix_members_equal_wide': True,
                        'fourth_admitted_run_identity_and_analysis_equal_wide': True,
                        'stopped_run_body_unproduced_text_empty_sourcemap_empty': True,
                        'independent_first_dependency_stop_proof': False}
            else:
                equal_full, _, _ = compare_full_json_except_allowed(doc, cap)
                if not equal_full:
                    raise RuntimeError(f'cap{cap}: full JSON differs from wide outside usage.elapsed_millis and requested limits.class_headers')
                if (doc.get('execution', {}).get('status') != 'complete' or recovery_exec.get('status') != 'complete'
                        or recovery.get('content') != 'contains_statements'):
                    raise RuntimeError(f'cap{cap}: expected complete wide-equivalent recovery')
                row['asserted_complete'] = {'class_status': 'complete', 'recovery_status': 'complete',
                                            'full_json_equal_except_usage_elapsed_and_limits_class_headers': True}
            budget_rows.append({'cap': cap, 'command_index': index, 'actual_exit': row['exit_code'],
                                'class_execution': doc.get('execution'), 'usage': doc.get('usage'),
                                'limits': actual_limits, 'limits_paths': limit_paths,
                                'method_identity': method.get('item', {}).get('identity'),
                                'three_member_prefix': prefix_evidence,
                                'analysis_execution': analysis_exec, 'recovery_execution': recovery_exec,
                                'recovery_content': recovery.get('content'), 'report_json_raw': row['streams']['stdout'],
                                'checks': row.get('asserted_stop_serialization_only', row.get('asserted_complete'))})
            save()

        record['status'] = 'captured_21_command_em11_final_cli_source_runtime_budget_replay_pending_independent_review'
    except BaseException as exc:
        record['status'] = 'capture_failed_raw_artifacts_retained'
        record['error'] = f'{type(exc).__name__}: {exc}'
    finally:
        try:
            after = [pin(p) for p in input_paths] if 'input_paths' in locals() else []
            source_current_after = all((ROOT / row['path']).is_file() and pin(ROOT / row['path'])['bytes'] == row['bytes']
                                       and pin(ROOT / row['path'])['sha256'] == row['sha256'] for row in source_manifest) if 'source_manifest' in locals() else False
            record['input_manifest_after'] = after
            record['inputs_identical'] = bool(after) and before == after if 'before' in locals() else False
            record['current_source_matches_frozen_receipt_after'] = source_current_after
            record['source_manifest_count_after'] = len(source_manifest) if 'source_manifest' in locals() else None
            record['target_absent_after'] = not (ROOT / 'target').exists()
            record['target_bytes_after'] = scanner.target_bytes(ROOT) if 'scanner' in locals() else None
            record['free_bytes_after'] = shutil.disk_usage(ROOT).free
            if ('before' in locals() and (not record['inputs_identical'] or not source_current_after
                    or not record['target_absent_after'] or record['target_bytes_after'] > TARGET_LIMIT)):
                record['status'] = 'capture_failed_integrity_or_target_cleanup'
            if record.get('status') == 'captured_21_command_em11_final_cli_source_runtime_budget_replay_pending_independent_review' and len(record.get('commands', [])) != 21:
                record['status'] = 'capture_failed_wrong_command_count'
            write_record(out, record)
        except BaseException as final_error:
            record['status'] = 'capture_failed_finalization_or_integrity_read'
            record['finalization_error'] = f'{type(final_error).__name__}: {final_error}'
            try:
                write_record(out, record)
            except BaseException:
                pass
    return 0 if record.get('status') == 'captured_21_command_em11_final_cli_source_runtime_budget_replay_pending_independent_review' else 1

if __name__ == '__main__':
    raise SystemExit(main())
