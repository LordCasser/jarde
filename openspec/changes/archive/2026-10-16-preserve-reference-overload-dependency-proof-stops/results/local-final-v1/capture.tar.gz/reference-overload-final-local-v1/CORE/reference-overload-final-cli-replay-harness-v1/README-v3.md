# EM11 final CLI replay harness v3

`run-v3.py` preserves v1 and v2. It carries forward v2's finalization, full paid-prefix, limits, and full-document comparison corrections. It also checks the exact UTF-8 byte span `(em11.HMid) new em11.HLeaf()` in the wide run `SourceMap`: primary BCI 4 anchors the constructor call, derived BCIs are 0, 3, and 7, and all origin method identities equal the wide physical run member. The existing javap command checks NEW 0, dup 3, constructor 4, invokestatic 7, and areturn 10. No producer NEW4 claim is made, and the command total remains 21.

Prepared-only: Python syntax and AST checked; no native/toolchain execution.
