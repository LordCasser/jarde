# Prepared final local reference-overload evidence collector

PREPARED ONLY. No collection script execution, native command, Git, Cargo, OpenSpec, CLI, JDK or GDB was performed. No archive has been created. Only source/schema inspection and Python AST parsing were used; no repository files were changed.

After root reviews this script and the actual independent replay audit is sealed, prepare the explicit allowlist:

```sh
python3 /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/reference-overload-final-local-evidence-package-v1/collect.py prepare \
  --replay /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/reference-overload-final-cli-replay-harness-v1/run-v3-out-v1/execution.json \
  --audit /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/reference-overload-apply-root-v1/final-replay-independent-audit-v1.json \
  --out /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/reference-overload-final-local-evidence-package-v1/stage-v1
```

Review stage-v1/allowlist.json, then root may package it without refreshing or reselecting input files:

```sh
python3 /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/reference-overload-final-local-evidence-package-v1/collect.py package \
  --allowlist /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/reference-overload-final-local-evidence-package-v1/stage-v1/allowlist.json \
  --out /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/reference-overload-final-local-evidence-package-v1/stage-v1/reference-overload-final-local-evidence-v1.tar.gz
```

prepare only writes one new allowlist into a fresh cache stage. package verifies every frozen item pin, creates the tar, reopens every safe unique regular member and compares every byte to the frozen input, then rechecks originals and writes manifest.json/execution.json. It never executes any captured command or audit. Changed pins fail rather than silently refresh.

Payload scope:

- Five actual native runs: old-native15pass6fail; old ordinary4pass; failed initial JDK environment run; intermediate JDK23-v2=272pass; actual final focused325pass/0fail/1ignored. Each original receipt retains both complete4907 source manifests, all raw streams and exact command spec. Failure receipts and ignored counts remain unchanged. Missing receipt summary on the failed initial run is not represented as zero executed tests.
- The actual final21-command replay receipt/all42 raw streams, all seven exact generated Java texts/saved JSON reports, seven freshly compiled original classes, seven rebuilt classes and separately compiled original Runner. Require the actual sealed independent replay audit. Original7Java+historical results/JAR are included as source inputs with actual pins; no original source or class is substituted for generated-source output.
- Source overlays for every stage bind each saved facade/public-test/CLI-test/JAR byte sequence to that stage's own source manifest. The final facade/public snapshots are taken from D/facade-final-focused-v1.rs and D/final-public-tests-v1.rs; current workspace facade is never used as a historical snapshot. Other source files can be reconstructed from baseline7532d618800287aa147a878ef509201ded80b004 and checked against each original manifest.
- A narrow set of actual command specs, applied diffs, frozen source snapshots, relevant focused/root/compatibility audits and replay-harness source/review metadata. Existing old package is pinned externally, not nested. No recursive workspace, proposal-history or unrelated CI/EM11 planning bundle is included.
- Exact reader/guard/scanner/source-closure/harness source scripts are included; CLI/JDK/Python/native binaries are external actual receipt pins. Final CLI must match both final-focused and replay binding, and JDK tool pins must match actual replay receipt.

The expected receipt-bound raw count is94 (five native captures52 plus replay42), with no unbound raw payload. Dispatch/launcher streams are intentionally outside this narrow payload; command argv/environment/timing/exit and actual test streams remain in original receipts. This package does not convert intermediate v2 green into final evidence, alter historical pending flags or make any own-CI/completed-change claim. Root remains responsible for independent archive acceptance and repository delivery.
