# 私有隔离验证：populate-canonical-block-protection-ranges

验证仅在 `/home/lordcasser/.codex/worktrees/review-core-fixes/jarde`，HEAD `5f18b2a94e1b8eab8296dc38768463657f436d50`。保留此前 cache 四文件与 method 三文件候选，未写共享 checkout、index、commit 或 push。OpenSpec apply 为 spec-driven、0/4；上下文已按 CLI contextFiles 读取且任务保持未勾选。

原输入 patch SHA-256 `9138610ca92755bfba301b5aba05bde755c69084189e34b42ecb03fb19b47414`。实际应用固定 patch 后仅 fmt 调整，两文件交付 patch SHA-256 `26d1aba520caade2e1fb1e6e3b226badc9a76bda40751b39a5cdf8c42688e49f`。`before/`、`after/`、`repro-sources/` 保存原始源码；manifest 仅两目标文件。reverse apply check 与 diff whitespace check 均退出 0。

旧 production + 新 tests 的真实编译复现：`repro-old-internal` 1 项实际失败，block `protected=[]` 而 oracle 为 `[0]`；`repro-old-public` 1 项实际失败于非空保护范围断言。所有原始 stdout/stderr 保留。最初 `repro-internal`、`repro-internal-features` 误按首个 cfg(test) seam 装配，不能作为旧实现复现；保留原日志并在 `invalid-repro-notice.json` 明确标为无效证据。真正复现按精确 `#[cfg(test)]\nmod tests {` 边界，完整生产前缀相等，raw 对应源码 pins 稳定。

实际候选测试均退出 0，共 144 项，无零测试计成功：

- `cargo test -p jarde-jvm --lib --locked canonical::tests`：32。
- `cargo test --test p3_method_ir --locked`：5。
- `cargo test --locked --all-features --test p2_canonical --test p2_return_address --test p2_frame --test p2_ssa`：8 + 16 + 11 + 5（按执行顺序 canonical/frame/return-address/ssa）。
- `cargo test -p jarde-jvm --lib --locked --all-features frame::tests`：48。
- `cargo test -p jarde-jvm --lib --locked --all-features ssa::tests`：19。
- `cargo fmt --all`：退出 0，只两候选文件发生变化。

新增七个 canonical 回归均逐名通过：physical_ranges_include_nonthrowing_members_and_keep_edge_owners_separate、half_open_midblock_overlaps_catchall_and_repeated_handler_rows_are_physical、fusion_uses_real_members_and_excludes_a_skipped_protected_gap、protected_shared_nested_and_dead_clones_keep_their_call_paths、range_scans_and_ordinals_are_charged_before_create_growth、ordered_union_moves_paid_storage_and_bounds_comparisons_and_shifts、cancelling_after_range_storage_at_fusion_publishes_no_complete_graph。union 27 AnalysisSteps、limit26/consumed26/requested1、limit4/consumed4/requested2 以及 no-handler 5 Steps/0 Items 控制保持；create 三范围 5 Items/3 Steps 和 no-handler 2 Items/0 Steps 保持。旧 clone 预算/取消、handlerclone/origin/path/unreachable 与真实成员 oracle 均实际通过。公开精确限额及少一项停止保留既有 Partial Error、最后有效 LegacyNormalization、Code/CP/declaration，并无 Canonical/Frame/SSA 完整发布。没有放宽原预算断言，没有生产语义修复。

Cargo 全部串行；每秒 5 GiB free / 1 GiB target guard，jobs1、incremental0、dev/test debug0、test threads1、stable、offline，清除 target-dir、min-stack、Java opts。原全树源码/fixture闭包与后两 unit 的较窄编译输入/fixture闭包均保留，最终全树差异仅两候选文件，七既有文件逐项 pins 未变。早期 guard 未保存 finished_at，原日志不改；自公开真正复现起保存 contemporaneous UTC start/end 和 monotonic duration，audit 核验误差小于 0.01 秒。

finally 严格 `argv=["cargo","clean"]`、cwd 私有 checkout，未传 manifest 或 target-dir，退出 0；raw、前后源码 pins 与 `target-absent.json` 证明 target 不存在。最终 clean 的源码闭包完全相等。

尚待主线集成：独立 review/提交，Clippy、OpenSpec strict、workspace、Try/List 费用相关产品门与该提交 CI。未运行完整 workspace、JDK、产品 CLI；这些私有候选测试不代表主线 change 完成。
