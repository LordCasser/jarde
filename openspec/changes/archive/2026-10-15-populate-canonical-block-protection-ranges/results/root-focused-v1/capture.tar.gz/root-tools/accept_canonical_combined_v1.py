from pathlib import Path
import hashlib,json,re
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');R=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');O=B/'canonical-combined-root-v1.json';assert not O.exists();errors=[];checks=[]
def ck(v,n):
 checks.append(n)
 if not v:errors.append(n)
def pin(p):
 p=Path(p);z=p.read_bytes();return {'path':str(p),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
def raw(r,k):
 v=r['streams'][k];q=pin(v['path']);ck(q['bytes']==v['bytes'] and q['sha256']==v['sha256'],v['path']);return Path(v['path']).read_text(errors='replace')
d1=json.loads((B/'canonical-focused-v1/execution.json').read_text());d2=json.loads((B/'canonical-focused-v2/execution.json').read_text());cal=json.loads((B/'canonical-billing-v1/execution.json').read_text());delta=json.loads((B/'canonical-billing-delta-v1.json').read_text());p2=json.loads((B/'canonical-focused-v2/protocol-review.json').read_text());ck(p2['status']=='accepted','v2 accepted')
ck(d1['status']=='failed','v1 preserved as failed');ck(d1['source_manifest_before']==d1['source_manifest_after'],'v1 source stable');ck(cal['source_manifest_before']==cal['source_manifest_after']==d1['source_manifest_before'],'calibration source stable and same as v1')
a={v['path']:v for v in d1['source_manifest_before']};b={v['path']:v for v in d2['source_manifest_before']};ck(set(a)==set(b) and len(a)==4887,'complete 4887 source sets');changed=[n for n in a if a[n]!=b[n]];ck(changed==['tests/p5_bulk_corpus.rs'],'only measured test pins change between validation scopes');ck(pin(B/'canonical-billing-test-before.rs')['sha256']==a['tests/p5_bulk_corpus.rs']['sha256']==delta['before_sha256'],'old test exact snapshot');ck(b['tests/p5_bulk_corpus.rs']['sha256']==delta['after_sha256'],'new test exact snapshot')
old=(B/'canonical-billing-test-before.rs').read_text();new=(R/'tests/p5_bulk_corpus.rs').read_text();note='    // 2026-10-15 canonical physical protection: real range ordinals and their scans/union\n    // bill +68 IrItems and +335 AnalysisSteps for MANY_METHOD_CLASS and each whole-corpus\n    // arm. The unchanged recorder measures all six cases; the arms measure their own requests.\n    // No fixture, output, comparison or other dimension changes.\n';restored=new.replace(note,'')
for name,changes in [('MANY_METHOD_CLASS',{'ir_items':(21390,21458),'analysis_steps':(12104,12439)}),('DIRECT_ARM',{'ir_items':(35586,35654),'analysis_steps':(19955,20290)}),('SHARED_ARM',{'ir_items':(35586,35654),'analysis_steps':(19955,20290)})]:
 m=re.search(r'const '+name+r': Self = Self \{.*?\n    \};',restored,re.S);assert m;block=m.group()
 for k,(x,y) in changes.items():block=block.replace(f'{k}: {y},',f'{k}: {x},')
 restored=restored[:m.start()]+block+restored[m.end():]
ck(restored==old,'six numeric pins and comment only; no assertion changes')
summaries=[];text=''
for i,row in enumerate(d1['commands']):
 ck(row['guard_stop'] is None and row['exit_code']==(101 if row['label']=='p5-billing' else 0),'v1 exact outcome/'+row['label']);t=raw(row,'stdout');raw(row,'stderr')
 if row['label'] in ['canonical-unit','canonical-public','legacy-public','frame-unit','ssa-unit']:
  ss=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t);ck(all(v[0]=='ok' and int(v[2])==0 for v in ss),'successful required suite/'+row['label']);summaries+=ss;text+=t
ck(sum(int(v[1]) for v in summaries)==144 and len(summaries)==8,'144 functional tests / 8 actual suites')
for name in ['physical_ranges_include_nonthrowing_members_and_keep_edge_owners_separate','half_open_midblock_overlaps_catchall_and_repeated_handler_rows_are_physical','fusion_uses_real_members_and_excludes_a_skipped_protected_gap','protected_shared_nested_and_dead_clones_keep_their_call_paths','range_scans_and_ordinals_are_charged_before_create_growth','ordered_union_moves_paid_storage_and_bounds_comparisons_and_shifts','cancelling_after_range_storage_at_fusion_publishes_no_complete_graph','physical_protection_publication_fits_exact_canonical_budgets_and_stops_one_less']:
 ck(text.count(name+' ... ok')==1,'new required name/'+name)
ck(cal['status']=='commands_passed_pending_independent_acceptance' and len(cal['commands'])==2,'actual recorder complete')
for row in cal['commands']:
 ck(row['exit_code']==0 and row['guard_stop'] is None,'recorder/'+row['label']);t=raw(row,'stdout');raw(row,'stderr')
 if row['label']=='p5-record-actual-billing':ck('test result: ok. 1 passed; 0 failed; 0 ignored;' in t and t.count('Billing { ')==6,'original recorder executed all six rows')
ck(d1['target_absent'] and cal['target_absent'] and d2['target_absent'] and not (R/'target').exists(),'every scope strict finally cleanup')
report={'status':'accepted_local_combined_scopes_only' if not errors else 'rejected','errors':errors,'checks':len(checks),'source_files':4887,'functional_tests':144,'updated_billing_tests':5,'distinct_accepted_tests':149,'recorder_additional_executions':1,'still_ignored_in_normal_suite':1,'v1_overall_failed_preserved':True,'only_intervening_source_delta':changed,'auditor':pin(__file__),'receipts':{n:pin(B/n/'execution.json') for n in ['canonical-focused-v1','canonical-billing-v1','canonical-focused-v2']},'no_own_ci_or_workspace_claim':True}
O.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report));raise SystemExit(bool(errors))
