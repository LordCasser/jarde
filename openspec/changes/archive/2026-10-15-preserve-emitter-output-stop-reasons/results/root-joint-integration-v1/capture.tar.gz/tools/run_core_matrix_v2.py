from pathlib import Path
import subprocess,json,hashlib,os
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');R=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');PRIMARY=Path('/home/lordcasser/workspace/projects/jarde');O=B/'final-matrix-core-v2';assert not O.exists();assert not (R/'target').exists() and not (PRIMARY/'target').exists();O.mkdir()
focused=B/'emitter-focused-v2/execution.json';d=json.loads(focused.read_text());assert d['status']=='commands_passed_pending_independent_acceptance';assert json.loads((B/'emitter-focused-v2/protocol-review.json').read_text())['status']=='accepted';cli=Path(d['cli']['path']);assert hashlib.sha256(cli.read_bytes()).hexdigest()==d['cli']['sha256']
collector=PRIMARY/'openspec/changes/recover-ordinary-try-list-generic-bodies/tools/collect_full_class.py';e=os.environ.copy();e['PYTHONPATH']=str(OLD/'tools/pythonlib');python='/home/lordcasser/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';rows=[]
for family in ['baseline','admission']:
 for mode in ['debug','none']:
  old=json.loads((OLD/'final-matrix-v4'/family/mode/'execution.json').read_text());config=old['collector_config'].copy();config.update(out=str(O/family/mode),cli=str(cli),cli_sha256=d['cli']['sha256'],build_receipt=str(focused),build_receipt_sha256=hashlib.sha256(focused.read_bytes()).hexdigest());args=[python,str(collector)]
  for k,v in config.items():args.extend(['--'+k.replace('_','-'),str(v)])
  label=family+'-'+mode;(O/(label+'.argv.json')).write_text(json.dumps(args,indent=2)+'\n')
  with (O/(label+'.stdout.raw')).open('wb') as out,(O/(label+'.stderr.raw')).open('wb') as err:c=subprocess.run(args,cwd=R,env=e,stdout=out,stderr=err)
  rows.append({'label':label,'exit_code':c.returncode,'receipt':str(O/family/mode/'execution.json')});(O/'execution-index.json').write_text(json.dumps({'status':'running' if c.returncode==0 else 'failed','legs':rows,'cli':d['cli'],'source_receipt':str(focused),'main_and_aux_targets_absent_before':True},indent=2)+'\n');assert c.returncode==0,label
assert not (R/'target').exists() and not (PRIMARY/'target').exists();index=json.loads((O/'execution-index.json').read_text());index['status']='collected_pending_root_acceptance';index['main_and_aux_targets_absent_after']=True;(O/'execution-index.json').write_text(json.dumps(index,indent=2)+'\n');print('four full-class matrix legs collected')
