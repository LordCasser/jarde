from pathlib import Path
import json,subprocess,os,hashlib,time
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');R=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');M=B/'final-matrix-core-v2';launch=B/'core-joint-pipeline-v3';launch.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(args,label,env=None):
 with (launch/(label+'.stdout.raw')).open('wb') as out,(launch/(label+'.stderr.raw')).open('wb') as err:c=subprocess.run(args,cwd=R,env=env,stdout=out,stderr=err)
 (launch/(label+'.json')).write_text(json.dumps({'argv':args,'exit_code':c.returncode,'streams':{k:{'path':str(launch/(label+'.'+k+'.raw')),'bytes':(launch/(label+'.'+k+'.raw')).stat().st_size,'sha256':sha(launch/(label+'.'+k+'.raw'))} for k in ['stdout','stderr']}},indent=2)+'\n');assert c.returncode==0,label
while True:
 p=M/'execution-index.json'
 if p.exists():
  d=json.loads(p.read_text())
  if d['status']=='collected_pending_root_acceptance':break
  assert d['status']!='failed',d
 time.sleep(20)
e=os.environ.copy();e['PYTHONPATH']=str(OLD/'tools/pythonlib');py='/home/lordcasser/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';args=[py,str(OLD/'review/audit_candidate.py')]
for family in ['baseline','admission']:
 for mode in ['debug','none']:args+=['--capture',family+':'+mode+':'+str(M/family/mode)]
args+=['--out',str(M/'root-audit'),'--baseline-reference',str(OLD/'baseline45'),'--repo-root','/home/lordcasser/workspace/projects/jarde'];assert json.loads((M/'root-audit/audit.json').read_text())['status']=='accepted';assert json.loads((M/'root-audit/audit.json').read_text())['status']=='accepted';assert not (R/'target').exists();print('full class matrix accepted',flush=True)
e=os.environ.copy();e['PATH']=str(OLD/'tools/java25-javac23-bin')+':'+str(OLD/'tools/jdk23/jdk-23.0.1/bin')+':'+e['PATH'];args=['python3',str(B/'workspace_runner_core_v1.py')]
for key,p in [('focused-receipt',B/'emitter-focused-v3/execution.json'),('runtime-debug-receipt',M/'baseline/debug/execution.json'),('runtime-none-receipt',M/'baseline/none/execution.json')]:args+=['--'+key,str(p),'--'+key+'-sha256',sha(p)]
args+=['--out',str(B/'workspace-core-v3')];run(args,'workspace-run',e);print('workspace completed',flush=True)
args=['python3',str(B/'accept_workspace_core_v1.py')]
for key,p in [('execution',B/'workspace-core-v3/execution.json'),('focused-receipt',B/'emitter-focused-v3/execution.json'),('runtime-debug-receipt',M/'baseline/debug/execution.json'),('runtime-none-receipt',M/'baseline/none/execution.json'),('tool-environment-receipt',OLD/'tool-environment-final-v1/execution.json')]:args+=['--'+key,str(p),'--'+key+'-sha256',sha(p)]
args+=['--metadata',str(B/'workspace-core-v3/metadata.json'),'--out',str(B/'workspace-core-v3/root-acceptance.json')];run(args,'workspace-root-audit',e);print('joint workspace accepted',flush=True)
