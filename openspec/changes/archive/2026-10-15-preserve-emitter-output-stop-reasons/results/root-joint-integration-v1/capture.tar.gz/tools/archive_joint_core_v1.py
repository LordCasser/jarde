from pathlib import Path
import io,hashlib,json,tarfile,subprocess
R=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde'); B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015'); OLD=B.parent/'ordinary-try-list-20261014'
O=R/'openspec/changes/preserve-emitter-output-stop-reasons/results/root-joint-integration-v1'; O.mkdir(parents=True,exist_ok=False)
files={}
def add(p,n):
 assert p.is_file(),p
 assert n not in files,n
 files[n]=p.read_bytes()
def tree(p,n):
 assert p.is_dir(),p
 for q in sorted(p.rglob('*')):
  if q.is_file(): add(q,n+'/'+q.relative_to(p).as_posix())
for n in ['emitter-focused-v3','workspace-core-v3','final-matrix-core-v2','own-ci-core-d3e2-root-v1','p2-golden-observation-v1','p2-golden-observation-v2','corpus-fingerprint-regeneration-v1','workspace-core-v1','workspace-core-v2','own-ci-canonical-d6fb-root-v1','own-ci-emitter-ad8e-root-v1','own-ci-core-c814-root-v1','core-completion-openspec-v1']:
 tree(B/n,n)
for n in ['core-d3e2-source-and-matrix-binding-root-v1.json','fuzz-walk-inputs-audit-time-root-v1.json','core-final-local-source-review-v1.json','core-required-groups-v1.json','corpus-fingerprint-regeneration-independent-review-v1.json','core-correction-independent-review-v1.json']:
 add(B/n,'root/'+n)
for n in ['emitter_focused_v3.py','accept_emitter_focus_v3.py','workspace_runner_core_v1.py','accept_workspace_core_v1.py','run_core_matrix_v2.py','core_matrix_workspace_pipeline_v3.py','capture_own_ci_core_v2.py','accept_product_ci_v1.py','p2_golden_observation_v1.py','p2_golden_observation_v2.py','corpus_fingerprint_regeneration_v1.py','archive_joint_core_v1.py']:
 add(B/n,'tools/'+n)
for n in ['tools-prep/guard.py','tools-prep/target_scan.py','tools-prep/workspace_runner.py','tools/jdk-manifest.json','review/audit_candidate.py','workspace-forward-v10/root-acceptance.json']:
 add(OLD/n,'prior-tools/'+n)
add(R/'openspec/changes/recover-ordinary-try-list-generic-bodies/tools/collect_full_class.py','tools/collect_full_class.py')
review=Path('/home/lordcasser/.cache/jarde-review/20261015')
for n in ['core-workspace-v3-independent-audit-v1/independent-audit.json','core-d3e2-own-ci-independent-audit-v1/audit.json','core-d3e2-own-ci-independent-audit-v1/final-manifest.json','engineering-review-followup-v8.json']:
 add(review/n,'independent/'+n)
changed=subprocess.check_output(['git','diff','--name-only','644882d6db69f7d5b0bc1165c035a12b4f7cd8aa','d3e2b2457338b61660b842f5705b225bba08a73a','--','src','crates','tests','build.rs'],cwd=R,text=True).splitlines()
for n in changed: add(R/n,'source/'+n)
manifest={'schema':'joint-core-evidence-v1','product_sha':'d3e2b2457338b61660b842f5705b225bba08a73a','scope':'terminal local and exact product CI; final documentation/main head separately audited','historical_source_pins':4887,'audit_time_additional_fuzz_inputs':13,'matrix_run_commit':'c814267719ebc6d8fe14535ebee1b85e41d444db','matrix_reused_by_cli_sha256':'cdf06694fafcb4e8cef5a4b9452676489e8cf02495c0254ce38a21e44ee4c7d5','payloads':[{'path':n,'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()} for n,z in sorted(files.items())]}
files['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
a=O/'capture.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for n,z in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(z);m.mode=0o644;m.mtime=0;t.addfile(m,io.BytesIO(z))
with tarfile.open(a,'r:gz') as t:
 assert len(t.getmembers())==len(files)
 for m in t:
  assert m.isfile() and t.extractfile(m).read()==files[m.name],m.name
report={'status':'accepted_archive_byte_integrity','archive':{'path':'capture.tar.gz','bytes':a.stat().st_size,'sha256':hashlib.sha256(a.read_bytes()).hexdigest()},'payloads':len(files)-1,'all_members_reopened':len(files),'workspace':{'passed':7174,'failed':0,'ignored':196},'focused':{'passed':462,'failed':0,'ignored':2},'own_ci':38673548915,'matrix_jarde_cells':16,'source_snapshot_count':len(changed)}
(O/'archive-review.json').write_text(json.dumps(report,indent=2)+'\n')
(O/'README.md').write_text('''# 四工程联合交付证据

本归档以 `d3e2b2457338b61660b842f5705b225bba08a73a` 为产品；最终文档/main HEAD 单独审计。`manifest.json` 逐项记录唯一相对路径、字节数与 SHA-256，根已重新打开全部成员逐字比较。保留执行回执里的原始绝对路径，并以归档前缀映射缓存目录；不修改历史回执。

- focused-v3：10命令/20raw，462通过/0失败/2忽略，fmt、当前CI Clippy、两版本strict367/0、实际CLI build和finally exact clean成功。
- workspace-v3：195命令/390raw，默认stack，两seed各365 suites、3587/0/98，共7174/0/196；每seed77具名门一次通过，最后target absent。本地Java25/javac23组合不冒称CI Temurin。
- 产品自身CI 38673548915：4 jobs/52 steps成功，native Rust1.99/Temurin25.0.4+7/Node22；两seed各3587/0/98，strict367/0。完整API捕获与logs.zip、根654checks及独立1173checks保留。
- matrix-v2：实际运行于c814 CLI，双JDK/debug-none/default-all共16 Jarde完整类单元，baseline45/admission33行逐字同原；JADX八baseline编译失败/no-runtime、八admission成功。d3重建CLI同59602720字节及SHA cdf06694fafcb4e8cef5a4b9452676489e8cf02495c0254ce38a21e44ee4c7d5，因此按二进制恒同复用，不声称d3重跑16单元。原Java/Runner未修补。

historical compiled-source closure为4887项；额外13个fuzz目录遍历输入仅audit-time sidecar，不倒填为运行开始指纹。实际P5测试核全2219 corpus项，根也重哈希全部2219。原canonical/emitter/c814 CI、workspace-v1/v2失败及真实P2计费观察和corpus标准再生成全部按原scope保留。canonical新增计费用真实recorder更新四边界常数/三golden共74叶；corpus仅三BLAKE3语义值改变（标准生成器另排序九对象），未降低任何断言。

四项更改共16任务完成，规格同步/归档与主线整合的最终状态见上级verification-root及handoff；后三项新计划仍0/27，不扩展为CF11/CF18/71/612总体完成。
''')
print(json.dumps(report))
