from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io,gzip,datetime
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=B/'CORE';S=C/'call-return-finally-war-full-source-v1';O=S/'run-v1';D=Path(__file__).parent;R=Path('/home/lordcasser/.codex/worktrees/call-return-finally/jarde');F=R/'tests/fixtures/recover-call-return-loop-finally';T=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');OUT=D/'capture.tar.gz';MAN=D/'manifest.json';EX=D/'execution.json'
assert not OUT.exists() and not MAN.exists() and not EX.exists()
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p):return json.loads(Path(p).read_text())
r=read(O/'execution.json');a=read(S/'independent-audit-v1.json');assert a['status']=='accepted_independent_WAR_full_source_replay' and a['errors']==[] and a['receipt']==pin(O/'execution.json')
entries={}
def add(name,path):
 pp=PurePosixPath(name);assert name and not pp.is_absolute() and '..' not in pp.parts and '.' not in pp.parts and '\\' not in name and name not in entries;entries[name]=Path(path)
for f in sorted(O.rglob('*')):
 if f.is_file():add('run/'+str(f.relative_to(O)),f)
for f in sorted(F.rglob('*')):
 if f.is_file():add('fixture/'+str(f.relative_to(F)),f)
add('harness/run.py',B/'replay_call_return_war_full_source_v1.py');add('audit/independent-audit.json',S/'independent-audit-v1.json');add('audit/audit.py',C/'audit_call_return_war_full_source_v1.py');add('package.py',Path(__file__))
for name in ['guard.py','target_scan.py','workspace_runner.py']:add('tools/'+name,T/'tools-prep'/name)
add('tools/jdk-manifest.json',T/'tools/jdk-manifest.json')
for name in ['final-source-cli-head-binding.json','source-head-tree.raw']:add('source-binding/'+name,C/'call-return-finally-final-product-source-binding-v1'/name)
refs=[]
for row in a['JAR_reference_bindings']:
 q=row['command'];raw=q['streams']['stdout'];assert pin(raw['path'])==raw;name='jar-reference/'+row['leg']+'.stdout.raw';add(name,raw['path']);refs.append(dict(leg=row['leg'],external_full_receipt_pin=row['source_receipt'],selected_actual_command=q,payload_stdout=name,scope='Selected JAR report raw only, bound to external full receipt pin; not a second complete replay capture in this WAR package.'))
ref=D/'jar-reference-binding-v2.json';assert not ref.exists();ref.write_text(json.dumps(refs,indent=2)+'\n');add('jar-reference/binding.json',ref)
rows=[dict(path=name,source_path=str(p),bytes=pin(p)['bytes'],sha256=pin(p)['sha256']) for name,p in sorted(entries.items())];paths={str(p):name for name,p in entries.items()}
rawbindings=[]
for q in r['commands']:
 for stream,row in q['streams'].items():
  assert pin(row['path'])==row and str(row['path']) in paths;rawbindings.append(dict(command=q['index'],stream=stream,payload=paths[row['path']],pin=row))
assert len(rawbindings)==24 and len({x['payload'] for x in rawbindings})==24
payloadraw={name for name in entries if name.endswith('.raw')};reference_raw={x['payload_stdout'] for x in refs};assert payloadraw=={x['payload'] for x in rawbindings}|reference_raw|{'source-binding/source-head-tree.raw'}
externals=[]
for row in r['inputs_before']:
 assert pin(row['path'])==row
 if row['path'] not in paths:externals.append(row)
manifest=dict(schema='call-return-finally-portable-WAR-evidence-v1',scope='Independent accepted actual12command WAR comparison with24 bound WARraw;2 selected JARreport reference raws separately bound. No nativeCLI/JDK/timeout binaries, no ownCI evidence. Historical source snapshots remain frozen; final exacthead ownCI is a separate gate.',product_head=a['product_head'],compiled_source_count=4936,audit_status=a['status'],payload_count=len(rows),rows=rows,actual_WAR_commands=12,actual_WAR_raw_bindings=rawbindings,JAR_selected_report_reference_bindings=refs,noncommand_raw_metadata=['source-binding/source-head-tree.raw'],external_pinned_inputs_not_embedded=externals)
mb=(json.dumps(manifest,indent=2)+'\n').encode();MAN.write_bytes(mb)
with OUT.open('xb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,p in sorted(entries.items()):
    data=p.read_bytes();row=next(x for x in rows if x['path']==name);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
   info=tarfile.TarInfo('manifest.json');info.size=len(mb);info.mode=0o644;tar.addfile(info,io.BytesIO(mb))
with tarfile.open(OUT,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1 and len({m.name for m in members})==len(members)
 for m in members:
  p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts and '.' not in p.parts and '\\' not in m.name;data=tar.extractfile(m).read()
  if m.name=='manifest.json':assert data==MAN.read_bytes()
  else:
   original=entries[m.name].read_bytes();row=next(x for x in rows if x['path']==m.name);assert data==original and len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
assert all(pin(Path(x['source_path']))['sha256']==x['sha256'] for x in rows)
ex=dict(status='created_and_all_tar_payload_bytes_reopened_equal_to_originals',archive=pin(OUT),manifest=pin(MAN),packager=pin(Path(__file__)),payload_count=len(rows),safe_unique_regular_members=len(rows)+1,actual_WAR_commands=12,actual_WAR_raw_count=24,selected_JAR_reference_raw_count=2,ownCI='not_included_or_executed',native_binaries='excluded_external_pins_only',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());EX.write_text(json.dumps(ex,indent=2)+'\n');print(json.dumps(ex))
