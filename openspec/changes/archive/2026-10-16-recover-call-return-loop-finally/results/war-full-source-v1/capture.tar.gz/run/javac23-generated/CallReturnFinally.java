// jarde: presentation of `CallReturnFinally` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class CallReturnFinally extends java.lang.Object {
    public CallReturnFinally() {
        // @method <init>()V
        // @declaration a constructor of `CallReturnFinally`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int finReturn(int[] arg0) {
        // @method finReturn([I)I
        // @declaration a static method of `CallReturnFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int[] local1;
        int local2;
        int local3;
        local1 = arg0;
        local2 = local1.length;
        local3 = 0;
        while (local3 < local2) {
            int local4;
            local4 = local1[local3];
            try {
                if (local4 == 3) {
                    int local5 = c0(local4);
                    return local5;
                }
            } finally {
                java.lang.System.out.println("fin:" + local4);
            }
            local3 = local3 + 1;
        }
        return -1;
    }

    static int c0(int arg0) {
        // @method c0(I)I
        // @declaration a static method of `CallReturnFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        return arg0 * 1000;
    }
}
