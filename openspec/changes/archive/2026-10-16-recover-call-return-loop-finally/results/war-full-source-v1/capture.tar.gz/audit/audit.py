from pathlib import Path
import json,hashlib,zipfile,stat,datetime
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');D=B/'CORE/call-return-finally-war-full-source-v1';O=D/'run-v1';R=Path('/home/lordcasser/.codex/worktrees/call-return-finally/jarde');F=R/'tests/fixtures/recover-call-return-loop-finally';C=B/'CORE';P=O/'execution.json';OUT=D/'independent-audit-v1.json'
assert not OUT.exists()
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p):return json.loads(Path(p).read_text())
checks=[];errors=[]
def ck(v,label):
 checks.append(label)
 if not v:errors.append(label)
def bound(row,label):ck(pin(row['path'])=={k:row[k] for k in ['path','bytes','sha256']},label)
r=read(P);native=read(r['native_receipt']['path']);binding=read(C/'call-return-finally-final-product-source-binding-v1/final-source-cli-head-binding.json');jar=read(C/'call-return-finally-final-full-source-v1/run-v1/execution.json')
ck(r['status']=='captured_twelve_command_war_complete_generated_source_and_rebuilt_oracle_success','terminal WAR capture success');bound(r['native_receipt'],'native receipt bytes');ck(binding['product_head']=='464543594b6fad00c67be016ffa5e21d18bc1591' and binding['source_count']==4936 and binding['frozen_cli']==r['frozen_cli']==native['frozen_cli'],'exact final head/source4936/CLI native binding');bound(r['frozen_cli'],'external CLI actual bytes');ck(r['frozen_cli']['sha256']=='b4a6b2ce2911165da5bb38f7a56a7d8c14d286936c97b4181e647cff7fc9c851' and r['frozen_cli']['bytes']==60261992 and stat.S_IMODE(Path(r['frozen_cli']['path']).stat().st_mode)==0o555,'CLI exact SHA/size0555')
ck(r['source_manifest_before']==r['source_manifest_after']==native['source_manifest_before']==native['source_manifest_after'] and len(r['source_manifest_before'])==4936,'native/WAR before-after4936 manifest closure');ck(r['inputs_before']==r['inputs_after'] and r['sources_identical'] and r['inputs_identical'],'historical before/after inputs identical');ck(r['default_stack'] and r['guards']==dict(free_bytes=5*1024**3,target_bytes=1024**3),'default stack explicit5GiB/1GiB guards');ck(r['target_absent'] and not(R/'target').exists(),'saved and current target absent')
for row in r['source_manifest_before']:
 p=R/row['path'];v=pin(p);ck((v['bytes'],v['sha256'])==(row['bytes'],row['sha256']),'current source bytes '+row['path'])
for row in r['inputs_before']:bound(row,'input unchanged '+row['path'])
commands=r['commands'];ck(len(commands)==12 and [q['index'] for q in commands]==list(range(1,13)),'12actual indexed commands');raw=set()
for q in commands:
 ck(q['exit_code']==q['expected_exit']==0 and q['guard_stop'] is None and q['peak_target_bytes']<1024**3 and q['free_bytes_after']>=5*1024**3,'command exit/guards '+str(q['index']));ck(q['env_overrides']=={} and q['duration_seconds']>0,'default command environment/actual duration '+str(q['index']))
 for kind,row in q['streams'].items():bound(row,'command raw '+str(q['index'])+' '+kind);ck(row['path'] not in raw and Path(row['path']).parent==O,'unique raw in actual output');raw.add(row['path'])
ck(len(raw)==24 and set(raw)=={str(p) for p in O.glob('*.raw')},'all24 raw bound exactly')
summary={};reference=[]
for index,(leg,sub) in enumerate([('javac23','v8'),('javac8','v8-javac8')]):
 qs=commands[index*6:index*6+6];lr=r['legs'][leg];cls=F/sub/'CallReturnFinally.class';ck(pin(cls)==lr['original_class'] and cls.stat().st_size==781,'original781B '+leg)
 wp=Path(lr['frozen_war']['path']);bound(lr['frozen_war'],'WAR archive '+leg)
 with zipfile.ZipFile(wp) as z:
  names=z.namelist();ck(names==['WEB-INF/classes/CallReturnFinally.class','META-INF/MANIFEST.MF','WEB-INF/web.xml'],'exact3 WAR entries '+leg);ck(z.read(names[0])==cls.read_bytes(),'WAR class original bytes '+leg);ck(all(x.compress_type==zipfile.ZIP_STORED for x in z.infolist()),'WAR STORE entries '+leg)
 tree=read(qs[0]['streams']['stdout']['path']);tr=tree['result']['report'];ck(tree['status']=='ok' and tr['execution']['status']=='complete' and len(tr['containers'])==1,'actual complete artifact tree '+leg);container=tr['containers'][0];origin=container['origin'];root=read(qs[0]['root_document']['path']);request=read(qs[0]['request_document']['path']);bound(qs[0]['root_document'],'root json '+leg);bound(qs[0]['request_document'],'tree request '+leg)
 ck(len(container['entries'])==3 and origin['steps']==[] and root==lr['declared_root']==dict(kind='container',origin=origin,prefix=list(b'WEB-INF/classes/')),'actual enumerated origin -> exact LoadRoot prefix '+leg);ck(request['input_path']==str(wp) and request['operation']==dict(kind='enumerate_artifact_tree'),'tree request actual WAR '+leg);ck(any(n['kind']=='war_classes' and n['source']['container']==origin and n['source']['prefix']==root['prefix'] for n in tr['layout_nodes']),'actual war_classes layout '+leg)
 doc=read(qs[1]['streams']['stdout']['path']);a=qs[1]['argv'];ck(a[0]==r['frozen_cli']['path'] and a[a.index('--policy')+1]=='explicit-classpath' and a[a.index('--layout')+1]=='war' and a[a.index('--root')+1]=='@'+qs[0]['root_document']['path'] and a[a.index('--input')+1]==str(wp),'class-source explicitroot WAR exact actual argv '+leg)
 ck(doc['outcome']=='performed' and doc['execution']['status']=='complete' and doc['class']==lr['class_identity'] and doc['class']['location']['entry']['origin']==origin and doc['class']['location']['entry']['raw_name']==list(b'WEB-INF/classes/CallReturnFinally.class'),'class owner actual tree provenance '+leg)
 keys=[(m['item']['name']['escaped'],m['item']['descriptor']['escaped']) for m in doc['methods']];ck(keys==[('<init>','()V'),('finReturn','([I)I'),('c0','(I)I')],'all3 exact method identities '+leg)
 for m in doc['methods']:
  o=m['outcome'];ck(o['kind']=='recovered' and o['report']['quality']=='structured' and o['report']['representation']=='java' and o['report']['fallbacks']==[],'structured method '+leg+' '+m['item']['name']['escaped'])
 jq=next(x for x in jar['commands'] if x['label']==leg+'-whole-class-json');bound(jq['streams']['stdout'],'original JAR JSON reference '+leg);jd=read(jq['streams']['stdout']['path']);source=Path(lr['generated_source']['path']);bound(lr['generated_source'],'generated source '+leg);ck(doc['text']==jd['text'] and source.read_bytes()==doc['text'].encode() and len(source.read_bytes())==1706 and '@bytecode' not in doc['text'],'unaltered entire1706B Java equal JAR '+leg);reference.append(dict(leg=leg,source_receipt=pin(C/'call-return-finally-final-full-source-v1/run-v1/execution.json'),command=jq))
 dest=source.parent;classes=dest/'classes';driver=dest/'driver';empty=dest/'empty-sourcepath'
 for q in qs[2:4]:
  a=q['argv'];ck(a[a.index('-classpath')+1]==str(classes) and a[a.index('-sourcepath')+1]==str(empty),'javac source/classpath isolated '+leg);ck(('--release' in a and a[a.index('--release')+1]=='8') if leg=='javac23' else ('--release' not in a and a[a.index('-source')+1]=='8' and a[a.index('-target')+1]=='8'),'true compiler flags '+leg)
 ck('jdk23' in qs[2]['argv'][0] if leg=='javac23' else 'jdk8' in qs[2]['argv'][0],'actual compiler binary leg '+leg);ck(qs[2]['argv'][-1]==str(source) and qs[3]['argv'][-1]==str(F/'CallReturnFinallyProbe.java'),'whole exact source and original immutable driver inputs '+leg)
 for rt,q in zip(['jdk8','jdk23'],qs[4:]):
  a=q['argv'];ck(a[:3]==['/usr/bin/timeout','--kill-after=5s','30s'] and rt in a[3] and a[a.index('-cp')+1]==str(driver)+':'+str(classes),'timeout dual JVM rebuilt-only classpath '+leg+rt);ck(Path(q['streams']['stdout']['path']).read_bytes()==(F/'probe.stdout').read_bytes() and q['streams']['stdout']['bytes']==217 and q['streams']['stderr']['bytes']==0,'exact217B oracle '+leg+rt)
 for label,rows in [('rebuilt_classes',lr['rebuilt_classes']),('driver_classes',lr['driver_classes'])]:
  for row in rows:bound(row,leg+' '+label)
 ck({x['path'] for x in lr['rebuilt_classes']}=={str(p) for p in classes.glob('*.class')} and {x['path'] for x in lr['driver_classes']}=={str(p) for p in driver.glob('*.class')},'all generated classes exact inventory '+leg)
 ck(len(lr['rebuilt_classes'])==1 and len(lr['driver_classes'])==3,'one rebuilt class and all3 driver classes '+leg);summary[leg]=dict(methods=keys,generated_source=pin(source),WAR=pin(wp),runtime_oracle_bytes=217,runtime_commands=2)
report=dict(schema='call-return-finally-war-independent-audit-v1',status='accepted_independent_WAR_full_source_replay' if not errors else 'rejected_independent_WAR_full_source_replay',checks=len(checks),errors=errors,receipt=pin(P),auditor=pin(Path(__file__)),product_head=binding['product_head'],source_count=4936,commands=12,bound_actual_raw=24,legs=summary,JAR_reference_bindings=reference,scope='Actual WAR12commands only; complete immutable class under both true compilers and four rebuilt-only JVM driver runs. Not final ownCI acceptance, no parent blanket recovery or new native execution.',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
OUT.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(report=pin(OUT),status=report['status'],checks=len(checks),errors=errors)));raise SystemExit(bool(errors))
