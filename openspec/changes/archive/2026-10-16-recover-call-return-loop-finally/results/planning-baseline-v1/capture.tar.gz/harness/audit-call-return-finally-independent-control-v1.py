from pathlib import Path
import struct,hashlib,json,re,zipfile
C=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/call-return-finally-independent-control-v1')
RUN=C/'run-v1'

def parse_class(data):
    pos=0
    def u1():
        nonlocal pos; v=data[pos]; pos+=1; return v
    def u2():
        nonlocal pos; v=struct.unpack_from('>H',data,pos)[0]; pos+=2; return v
    def u4():
        nonlocal pos; v=struct.unpack_from('>I',data,pos)[0]; pos+=4; return v
    if u4()!=0xCAFEBABE: raise ValueError('bad classfile')
    minor,major=u2(),u2(); count=u2(); cp=[None]*count; i=1
    while i<count:
        tag=u1()
        if tag==1:
            n=u2(); cp[i]=('utf8',data[pos:pos+n].decode('utf8','replace')); pos+=n
        elif tag in (3,4): cp[i]=(tag,data[pos:pos+4]); pos+=4
        elif tag in (5,6): cp[i]=(tag,data[pos:pos+8]); pos+=8; i+=1
        elif tag in (7,8,16,19,20): cp[i]=(tag,u2())
        elif tag in (9,10,11,12,17,18): cp[i]=(tag,u2(),u2())
        elif tag==15: cp[i]=(tag,u1(),u2())
        else: raise ValueError(('constant pool tag',tag))
        i+=1
    def utf(idx): return cp[idx][1]
    def cls(idx): return utf(cp[idx][1]) if idx and cp[idx][0]==7 else None
    def nt(idx): return utf(cp[idx][1]),utf(cp[idx][2])
    def ref(idx):
        x=cp[idx]
        if x and x[0] in (9,10,11):
            name,desc=nt(x[2]); return {'tag':x[0],'owner':cls(x[1]),'name':name,'descriptor':desc}
        return None
    class_access=u2(); class_name=cls(u2()); super_name=cls(u2()); ninterfaces=u2()
    for _ in range(ninterfaces): u2()
    def skipattrs(n):
        nonlocal pos
        for _ in range(n): u2(); size=u4(); pos+=size
    nfields=u2()
    for _ in range(nfields): u2();u2();u2();skipattrs(u2())
    nmethods=u2(); methods={}
    for _ in range(nmethods):
        access=u2(); name=utf(u2()); desc=utf(u2()); nattrs=u2(); row={'access':access,'name':name,'descriptor':desc}
        for __ in range(nattrs):
            aname=utf(u2()); size=u4(); end=pos+size
            if aname=='Code':
                ms=u2(); ml=u2(); ncode=u4(); code=data[pos:pos+ncode]; pos+=ncode; ne=u2(); table=[]
                for ___ in range(ne):
                    a,b,h,c=u2(),u2(),u2(),u2(); table.append({'start':a,'end':b,'handler':h,'catch_type':cls(c) if c else None})
                nsub=u2(); sub=[]
                for ___ in range(nsub): sn=utf(u2()); sl=u4(); pos+=sl; sub.append(sn)
                inv=[]
                # Match actual invokestatic opcodes only when their pool entries resolve as method refs.
                for bci,op in enumerate(code[:-2]):
                    if op==0xb8:
                        idx=int.from_bytes(code[bci+1:bci+3],'big'); resolved=ref(idx)
                        if resolved: inv.append({'bci':bci,'cp_index':idx,'resolved':resolved})
                row.update(max_stack=ms,max_locals=ml,code=code,exception_table=table,nested_attributes=sub,invokestatic=inv)
            else: pos=end
        methods[name+desc]=row
    return {'minor':minor,'major':major,'class':class_name,'methods':methods}

def extract_method(source,name):
    m=re.search(r'\bstatic\s+int\s+'+re.escape(name)+r'\s*\([^)]*\)\s*\{',source)
    if not m: raise ValueError('method missing '+name)
    i=m.start(); j=m.end(); depth=1
    while depth:
        if source[j]=='{': depth+=1
        elif source[j]=='}': depth-=1
        j+=1
    return source[i:j]

receipt=json.loads((RUN/'execution.json').read_text())
commands=receipt['commands']; raw_checks=[]
for cmd in commands:
    for stream, pin in cmd['streams'].items():
        raw=Path(pin['path']).read_bytes()
        raw_checks.append({'command':cmd['index'],'stream':stream,'bytes_match':len(raw)==pin['bytes'],'sha_match':hashlib.sha256(raw).hexdigest()==pin['sha256']})
fixture_oracle=(C/'fixture/probe.stdout').read_bytes(); actual=[]
for cmd in commands:
    if 'java-original-probe' in cmd['label']:
        stdout=Path(cmd['streams']['stdout']['path']).read_bytes()
        actual.append({'command':cmd['index'],'label':cmd['label'],'bytes':len(stdout),'sha256':hashlib.sha256(stdout).hexdigest(),'exact_oracle':stdout==fixture_oracle})
classes={};jar_same={}
for leg in ('javac23','javac8'):
    cp=RUN/f'{leg}-original/CallReturnFinally.class'; data=cp.read_bytes(); classes[leg]=parse_class(data)
    with zipfile.ZipFile(RUN/f'{leg}-original.jar') as z: jar_same[leg]=z.read('CallReturnFinally.class')==data
original_fx=Path('/home/lordcasser/.codex/worktrees/local-increment-finally/jarde/openspec/evidence/java-syntax-2026-10-05/return-effectful-finally-patrol/fixture/FX.java').read_text()
new_source=(C/'fixture/CallReturnFinally.java').read_text()
slice_same={n:extract_method(original_fx,n)==extract_method(new_source,n) for n in ('finReturn','c0')}
method_summary={}
for key in ('finReturn([I)I','c0(I)I'):
    pair=[]
    for leg,clsdata in classes.items():
        m=clsdata['methods'][key]
        pair.append({'compiler':leg,'class':clsdata['class'],'code_bytes':len(m['code']),'code_sha256':hashlib.sha256(m['code']).hexdigest(),'code_hex':m['code'].hex(),'max_stack':m['max_stack'],'max_locals':m['max_locals'],'exception_table':m['exception_table'],'nested_attributes':m['nested_attributes'],'invokestatic':m['invokestatic']})
    method_summary[key]={'legs':pair,'code_array_equal':pair[0]['code_hex']==pair[1]['code_hex'],'stack_and_locals_equal':(pair[0]['max_stack'],pair[0]['max_locals'])==(pair[1]['max_stack'],pair[1]['max_locals']),'exception_table_equal':pair[0]['exception_table']==pair[1]['exception_table']}
codegen=[]
for idx,leg in [(5,'javac23'),(11,'javac8')]:
    cmd=commands[idx]
    source=RUN/f'{leg}-generated/CallReturnFinally.java'; stderr=Path(cmd['streams']['stderr']['path']).read_text()
    codegen.append({'leg':leg,'generated_java_bytes':source.stat().st_size,'generated_java_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'compile_exit':cmd['exit_code'],'diagnostic':stderr})
assert len(commands)==12
assert [c['exit_code'] for c in commands].count(0)==10 and [c['exit_code'] for c in commands].count(1)==2
assert len(raw_checks)==24 and all(x['bytes_match'] and x['sha_match'] for x in raw_checks)
assert len(actual)==4 and all(x['exact_oracle'] for x in actual)
assert all(slice_same.values()) and all(jar_same.values())
assert all(x['compile_exit']==1 and 'error:' in x['diagnostic'] for x in codegen)
assert all(classes[k]['methods']['finReturn([I)I']['exception_table']==classes['javac23']['methods']['finReturn([I)I']['exception_table'] for k in classes)
report={'schema':'call-return-finally-independent-control-audit-v1','status':'pass','receipt':str(RUN/'execution.json'),'commands':12,'exit_counts':{'0':10,'1':2},'raw_stream_count':24,'raw_pins_all_match':True,'fixture':{'source':str(C/'fixture/CallReturnFinally.java'),'source_bytes':(C/'fixture/CallReturnFinally.java').stat().st_size,'source_sha256':hashlib.sha256(new_source.encode()).hexdigest(),'derivation':json.loads((C/'derivation.json').read_text()),'finReturn_and_c0_source_slices_exact_vs_FX':slice_same},'original_classfiles':{'jar_contains_exact_class':jar_same,'methods':method_summary},'original_runtime':{'oracle_bytes':len(fixture_oracle),'oracle_sha256':hashlib.sha256(fixture_oracle).hexdigest(),'four_runs':actual},'generated_source':{'legs':codegen,'rebuilt_runtime_count':0},'scope_limits':['The fixture changes only the outer class name and contains the exact finReturn/c0 method source slices; class constant-pool owner references adapt to CallReturnFinally.','finReturn Code arrays are compared as byte arrays and show compiler-specific differences; report separately compares max_stack/max_locals and exception-table rows. This does not assert that the entire Code attribute is byte-identical.','c0 is pure in the fixture, so the driver does not independently observe c0 invocation count or exact evaluation instant.','Both complete generated sources fail compilation; no rebuilt runtime or recovery claim is made.']}
out=C/'independent-audit-v1.json'
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
summary={'audit':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'methods':{},'runtime_exact':all(x['exact_oracle'] for x in actual),'source_slices_exact':slice_same}
for k,v in method_summary.items():
    summary['methods'][k]={'code_array_equal':v['code_array_equal'],'legs':[{'compiler':x['compiler'],'code_sha256':x['code_sha256'],'invokestatic':x['invokestatic'],'exception_table':x['exception_table']} for x in v['legs']]}
print(json.dumps(summary,ensure_ascii=False,indent=2))
