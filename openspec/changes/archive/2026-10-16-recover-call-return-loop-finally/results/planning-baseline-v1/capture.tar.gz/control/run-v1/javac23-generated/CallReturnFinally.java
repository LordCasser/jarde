// jarde: presentation of `CallReturnFinally` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class CallReturnFinally extends java.lang.Object {
    public CallReturnFinally() {
        // @method <init>()V
        // @declaration a constructor of `CallReturnFinally`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int finReturn(int[] arg0) {
        // jarde: not recovered: the recovery run for `finReturn([I)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method finReturn([I)I
        // @declaration a static method of `CallReturnFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 7 12 23 59 88 119 125
        // local 4 crosses a quoted fallback region; its assignments and consumers cannot be presented as one lexically bound definition-use slice
    }

    static int c0(int arg0) {
        // @method c0(I)I
        // @declaration a static method of `CallReturnFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        return arg0 * 1000;
    }
}
