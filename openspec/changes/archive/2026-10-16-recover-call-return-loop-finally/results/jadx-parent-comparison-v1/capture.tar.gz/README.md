# JADX 对照证据包

这是针对 FX.finContinue/finBreak fallback 的只读观察对照，父级 CallReturn 范围保持未完成/未证明状态。

- v3 实际 21 命令：JADX 1.5.6；六次整类反编译均 exit 0；FY、FO 两 compiler legs 的完整生成源码编译 exit 0，共 8 个 Java 8/23 重建类运行，均匹配原输出；FX 两 compiler legs 编译均 exit 1（诊断指出 `th` 未定义），所以没有 FX 重建运行。
- JADX 输出原样保留在 `defpackage`；没有改写源码来满足默认包。
- v1 保留 GUI jar/headless harness 失败；v2 保留正确 CLI 但未限定包名导致 FY main 运行失败；二者均为历史失败，不并入 v3 成功计数。
- 包含执行原始流、报告/生成源、原始 fixture/JAR/oracle、Jarde 对照 JSON 和 parent/native 收据。JDK、JADX、冻结 CLI 仅记录路径、版本/哈希，不分发二进制。
- 21 条 v3 命令/42 条原始流是本次实际执行；源码闭包 before/after 一致，guard 为 5 GiB free / 1 GiB target，默认栈，target absent。
- 这项观察不证明 catch-all handler 已恢复，也不代表父任务 3.1 的全部 anchors 已验收。
