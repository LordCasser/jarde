from pathlib import Path
import json,hashlib,importlib.util,os,shutil,zipfile,datetime
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=B/'CORE';W=Path('/home/lordcasser/.codex/worktrees/call-return-finally/jarde');D=C/'effectful-finally-jadx-final-call-return-comparison-v2';D.mkdir(exist_ok=False);O=D/'run-v1';O.mkdir();OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');CLI=B/'jarde-cli-call-return-finally-final-test-assertions-native-v1'
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();v=p.read_bytes();return dict(path=str(p),bytes=len(v),sha256=hashlib.sha256(v).hexdigest())
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
assert not (W/'target').exists() and shutil.disk_usage(W).free>=5*1024**3
native=C/'call-return-finally-final-test-assertions-native-v1/execution.json';n=json.loads(native.read_text());assert n['source_manifest_before']==n['source_manifest_after'] and n['target_absent'];assert pin(CLI)=={k:n['frozen_cli'][k] for k in ['path','bytes','sha256']}
oldp=C/'effectful-finally-current-screen-v1/run-v1/execution.json';old=json.loads(oldp.read_text());assert old['inputs_identical'] and old['sources_identical']
tools={k:Path(v['path']) for k,v in old['tools'].items()}
for k,p in tools.items():assert pin(p)==old['tools'][k]
closure=load('no_call_parent_closure',OLD/'tools-prep/workspace_runner.py');closure.ROOT=W;paths=set(closure.source_paths())|{W/x['path'] for x in json.loads((W/'tests/fixtures/corpus-fingerprint.json').read_text())['files']}
def sources():return [dict(path=str(p.relative_to(W)),bytes=p.stat().st_size,sha256=pin(p)['sha256']) for p in sorted(paths)]
before=sources();assert before==n['source_manifest_before'];inputs={Path("/usr/bin/timeout"),CLI,native,oldp,Path(__file__).resolve(),OLD/'tools-prep/guard.py',OLD/'tools-prep/target_scan.py',OLD/'tools-prep/workspace_runner.py',*tools.values()};jars=[]
for leg in ['javac23','javac8']:
 for name in ['FY','FX','FO']:
  p=Path(old['original_compiles'][leg]['jar_classes'][name]['path']);assert pin(p)==old['original_compiles'][leg]['jar_classes'][name]
  cp=next(row for row in old['original_compiles'][leg]['class_pins'] if Path(row['path']).name==name+'.class')
  with zipfile.ZipFile(p) as z:
   assert z.namelist()==[name+'.class'];data=z.read(name+'.class')
  assert len(data)==cp['bytes'] and hashlib.sha256(data).hexdigest()==cp['sha256'];jars.append((leg,name,p));inputs.add(p)
  f=W/'openspec/evidence/java-syntax-2026-10-05/return-effectful-finally-patrol/fixture'/(name+'.java');original=next(x for x in old['original_compiles'][leg]['source_pins'] if Path(x['path']).name==name+'.java');assert {k:pin(f)[k] for k in ['bytes','sha256']}=={k:original[k] for k in ['bytes','sha256']};inputs.add(f)
  for rt in ['java8','java23']:
   q=next(x for x in old['commands'] if x['label']==f'{leg}-{rt}-original-{name}');assert q['exit_code']==0;raw=Path(q['streams']['stdout']['path']);assert pin(raw)==q['streams']['stdout'];assert raw.read_bytes()==bytes.fromhex(old['oracle_hex'][name]);inputs.add(raw)
jadx=OLD/'tools/jadx/lib/jadx-1.5.6-all.jar';assert jadx.is_file();inputs.add(jadx);ip=[pin(p) for p in sorted(inputs)];g=load('no_call_parent_guard',OLD/'tools-prep/guard.py');scan=load('no_call_parent_scan',OLD/'tools-prep/target_scan.py');g.ROOT=W;g.OUT=O;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.target_bytes=lambda:scan.target_bytes(W);g.expected_test_summaries=lambda _i,_d:None;g.command_stream=pin;g.ENV_VALUES={}
r=dict(schema='effectful-finally-jadx-final-call-return-comparison-v2',status='running',scope='All FY/FX/FO methods retained; paired real javac8 and javac23 release8 whole-source compilation. Each whole generated source is compiled as an observation; all compiled classes replay main against saved original oracle, including FX. Mismatches remain explicit failures of parent behavior, never accepted as full recovery. Pinned JADX1.5.6 observation compared with final Jarde parent screen; no blanket acceptance.',native_receipt=pin(native),frozen_cli=n['frozen_cli'],prior_screen=pin(oldp),source_manifest_before=before,inputs_before=ip,default_stack=True,guards=dict(free_bytes=5*1024**3,target_bytes=1024**3),commands=[],cases={})
def save():(O/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
def run(label,args,expected):
 args=[str(x) for x in args];env={'HOME':'/home/lordcasser','PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}
 tool=next((Path(arg) for arg in args if Path(arg) in tools.values()),None)
 if tool is not None:env.update(JAVA_HOME=str(tool.parent.parent),PATH=str(tool.parent)+':/usr/bin:/bin')
 q=g.run_command(len(r['commands'])+1,args,env);q.update(label=label,expected_exit=expected);r['commands'].append(q);save();assert q['exit_code'] in (expected if isinstance(expected,list) else [expected]) and q['guard_stop'] is None;return q
save()
try:
 q=run('pinned-jadx-version',['/usr/bin/timeout','--kill-after=5s','120s',tools['java23'],'-cp',jadx,'jadx.cli.JadxCLI','--version'],0);assert Path(q['streams']['stdout']['path']).read_text().strip()=='1.5.6'
 r['jadx_tool']=pin(jadx);r['jarde_comparison_receipt']=pin(C/'effectful-finally-final-call-return-screen-v1/run-v1/execution.json');save()
 for leg,name,jar in jars:
  dest=O/f'{leg}-{name}';dest.mkdir();decompiled=dest/'decompiled';classes=dest/'classes';classes.mkdir();empty=dest/'empty-sourcepath';empty.mkdir()
  q=run(f'{leg}-jadx-whole-source-{name}',['/usr/bin/timeout','--kill-after=5s','120s',tools['java23'],'-cp',jadx,'jadx.cli.JadxCLI','--no-res','-j','1','--output-dir',decompiled,jar],0)
  generated=list(decompiled.rglob(name+'.java'));assert len(generated)==1;source=generated[0];saved=source.read_bytes();javac=tools[leg];flags=['--release','8','-Xlint:-options'] if leg=='javac23' else ['-source','8','-target','8']
  c=run(f'{leg}-compile-exact-jadx-generated-{name}',[javac,*flags,'-g:none','-classpath',classes,'-sourcepath',empty,'-d',classes,source],[0,1]);assert source.read_bytes()==saved;runs=[]
  if c['exit_code']==0:
   for rt in ['java8','java23']:
    q=run(f'{leg}-{rt}-jadx-rebuilt-main-{name}',['/usr/bin/timeout','--kill-after=5s','30s',tools[rt],'-Xverify:all','-cp',classes,name],0);observed=Path(q['streams']['stdout']['path']).read_bytes();oracle=bytes.fromhex(old['oracle_hex'][name]);q['oracle_exact']=observed==oracle;q['observed_hex']=observed.hex();q['expected_hex']=oracle.hex();q['stderr_empty']=not Path(q['streams']['stderr']['path']).read_bytes();runs.append(len(r['commands']));save()
  r['cases'][leg+'/'+name]=dict(input_jar=pin(jar),generated_source=pin(source),source_unchanged=True,compile_exit=c['exit_code'],generated_runtime_commands=len(runs),runtime_command_indices=runs,rebuilt_classes=[pin(p) for p in sorted(classes.glob('*.class'))]);save()
 r['rebuilt_runtime_oracle_mismatches']=[q['label'] for q in r['commands'] if q.get('oracle_exact') is False];r['status']='captured_pinned_jadx_parent_comparison_observations_not_blanket_acceptance'
except BaseException as e:r['status']='failed_raw_preserved';r['error']=repr(e)
finally:
 r.update(source_manifest_after=sources(),inputs_after=[pin(p) for p in sorted(inputs)],target_absent=not (W/'target').exists(),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());r['sources_identical']=r['source_manifest_after']==before;r['inputs_identical']=r['inputs_after']==ip
 if not r['sources_identical'] or not r['inputs_identical'] or not r['target_absent']:r['status']='failed_integrity'
 save()
print(r['status'],len(r['commands']));raise SystemExit(0 if r['status']=='captured_pinned_jadx_parent_comparison_observations_not_blanket_acceptance' else 1)
