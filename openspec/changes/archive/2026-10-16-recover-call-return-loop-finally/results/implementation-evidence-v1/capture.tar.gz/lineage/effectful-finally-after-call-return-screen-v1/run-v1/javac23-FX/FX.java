// jarde: presentation of `FX` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class FX extends java.lang.Object {
    public FX() {
        // @method <init>()V
        // @declaration a constructor of `FX`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int finContinue(int[] arg0) {
        // @method finContinue([I)I
        // @declaration a static method of `FX`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int local1;
        int[] local2;
        int local3;
        int local4;
        local1 = 0;
        local2 = arg0;
        local3 = local2.length;
        for (local4 = 0; local4 < local3; local4 = local4 + 1) {
            int local5 = local2[local4];
            if (local5 == 3) {
                local1 = local1 + 100;
            } else {
                local1 = local1 + local5;
                local1 = local1 + 100;
            }
        }
        return local1;
        // @bytecode 45 47 50 52
        // 1 live block(s) are reachable only through edges the normal-flow view leaves out: [45]
    }

    static int finReturn(int[] arg0) {
        // @method finReturn([I)I
        // @declaration a static method of `FX`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int[] local1;
        int local2;
        int local3;
        local1 = arg0;
        local2 = local1.length;
        local3 = 0;
        while (local3 < local2) {
            int local4;
            local4 = local1[local3];
            try {
                if (local4 == 3) {
                    int local5 = c0(local4);
                    return local5;
                }
            } finally {
                java.lang.System.out.println("fin:" + local4);
            }
            local3 = local3 + 1;
        }
        return -1;
    }

    static int c0(int arg0) {
        // @method c0(I)I
        // @declaration a static method of `FX`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        return arg0 * 1000;
    }

    static int finBreak(int[] arg0) {
        // @method finBreak([I)I
        // @declaration a static method of `FX`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int local1;
        int[] local2;
        int local3;
        int local4;
        local1 = 0;
        local2 = arg0;
        local3 = local2.length;
        for (local4 = 0; local4 < local3; local4 = local4 + 1) {
            int local5 = local2[local4];
            if (local5 == 3) {
                local1 = local1 + 100;
                break;
            } else {
                local1 = local1 + local5;
                local1 = local1 + 100;
            }
        }
        return local1;
        // @bytecode 45 47 50 52
        // 1 live block(s) are reachable only through edges the normal-flow view leaves out: [45]
    }

    public static void main(java.lang.String[] arg0) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `FX`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.io.PrintStream saved0 = java.lang.System.out;
        java.lang.StringBuilder saved1 = new java.lang.StringBuilder().append("");
        java.lang.StringBuilder saved2 = saved1.append(finContinue(new int[]{3, 4})).append("/");
        java.lang.StringBuilder saved3 = saved2.append(finReturn(new int[]{1, 3, 5})).append("/");
        saved0.println((java.lang.String) saved3.append(finBreak(new int[]{3, 4})).toString());
        return;
    }
}
