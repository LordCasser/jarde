from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io,gzip,zipfile,datetime
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=B/'CORE';D=Path(__file__).parent;CAP=B/'own-ci-call-return-finally-root-v1';I=C/'own-ci-call-return-finally-independent-audit-prepared-v1';ROOT=C/'call-return-finally-own-ci-root-audit-plan-v1';DIS=B/'call-return-finally-own-ci-dispatch-v1';SB=C/'call-return-finally-final-product-source-binding-v1';N=C/'call-return-finally-final-test-assertions-native-v1';W=Path('/home/lordcasser/.codex/worktrees/call-return-finally/jarde');HEAD='464543594b6fad00c67be016ffa5e21d18bc1591';RUN=38913819742
assert not(D/'capture.tar.gz').exists()
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
entries={};roles={};bindings=[]
def add(name,p,role):
 q=PurePosixPath(name);assert not q.is_absolute() and '..' not in q.parts and '.' not in q.parts and '\\' not in name and name not in entries;entries[name]=Path(p);roles[name]=role;pin(p)
def directory(prefix,p,role):
 for f in sorted(p.iterdir()):
  assert f.is_file() and not f.is_symlink();add(prefix+'/'+f.name,f,role)
def streams(rec,label):
 for stream,row in rec['streams'].items():
  assert pin(row['path'])=={k:row[k] for k in ['path','bytes','sha256']};bindings.append(dict(label=label,stream=stream,pin=row))
cap=read(CAP/'execution.json');root=read(B/'call-return-finally-464-own-ci-root-acceptance-v1.json');indie=read(I/'audit-result-v2.json');seal=read(I/'preexecution-pins-v2.json');inventory=read(I/'source-target-inventory-v2.json');native=read(N/'execution.json');binding=read(SB/'final-source-cli-head-binding.json')
assert cap['run_id']==root['run_id']==indie['run_id']==RUN and cap['product_sha']==root['product_sha']==indie['product_sha']==HEAD and cap['run_status']=='completed' and cap['conclusion']=='success';assert cap['transport_failures']==[] and len(cap['observations'])==149 and len(cap['jobs'])==4 and sum(len(x['steps']) for x in cap['jobs'])==52
assert root['status']=='accepted_exact_product_ci' and root['checks']==953 and root['errors']==[] and indie['status']=='accepted_independent_exact_product_ci_review' and indie['checks']==2863 and indie['errors']==[]
for s in indie['seeds']:assert(s['suites'],s['passed'],s['failed'],s['ignored'],len(s['target_fqn_bindings']))==(373,3670,0,98,160)
assert len(indie['support_target_fqn_bindings'])==7 and len(indie['jdk_full_class_commands'])==6 and sum(s['passing_tests'] for s in indie['jdk_full_class_commands'])==9
for row in seal['pinned_inputs']:assert pin(row['path'])==row
assert pin(I/'audit_own_ci_call_return_finally_v2.py')==seal['auditor'];directory('ci-capture',CAP,'actual current product capture')
for q in cap['observations']:assert q['exit_code']==0;streams(q,'API '+q['endpoint'])
assert len(bindings)==298 and {x['pin']['path'] for x in bindings}=={str(p) for p in CAP.glob('*.raw')};assert pin(CAP/'logs.zip')==cap['logs']==root['log_zip']==indie['logs_zip']
with zipfile.ZipFile(CAP/'logs.zip') as z:
 members=z.infolist();assert len(members)==60 and len({x.filename for x in members})==60
 for x in members:
  q=PurePosixPath(x.filename);assert not x.is_dir() and not q.is_absolute() and '..' not in q.parts and '\\' not in x.filename;data=z.read(x);row=next(y for y in indie['log_member_pins'] if y['path']==x.filename);assert(len(data),hashlib.sha256(data).hexdigest())==(row['bytes'],row['sha256'])
add('root-acceptance.json',B/'call-return-finally-464-own-ci-root-acceptance-v1.json','current exact-head root953checks');directory('root-audit',ROOT,'actual root auditor plan+execution');streams(read(ROOT/'actual-execution.json'),'root auditor')
add('root-audit/auditor.py',B/'accept_product_ci_v6.py','root independent execution script');add('reference-only/root-default-gate-source.json',Path(root['required_gate_source']['path']),'historical55 default gate names only, not current CI proof')
directory('independent-audit',I,'sealed v1 unexecuted history plus v2 actual acceptance');streams(read(I/'audit-v2-actual-execution.json'),'independent v2 auditor');assert read(I/'audit-v2-actual-execution.json')['exit_code']==0
for p in ['plan.json','source-target-inventory.json','primary-gate-names.json']:add('prepared-gate-plan/'+p,C/'call-return-finally-own-ci-gate-plan-v1'/p,'historical prepared-only forecast/source plan')
directory('source-binding',SB,'actual exact-head Git/source/native/CLI binding');source_exec=read(SB/'execution.json')
for q in source_exec['commands']:assert q['exit_code']==0;streams(q,'captured source Git '+q['label'])
add('native-final/execution.json',N/'execution.json','actual final9native commands; earlier27 retained externally');add('native-final/run.py',N/'run.py','actual native runner source')
for p in ['commands.json','intended-source-delta.json']:add('native-final/'+p,N/p,'actual source assertion delta/argv')
add('native-final/command_spec.json',N/'run-v1/command_spec.json','actual native command spec')
for q in native['commands']:
 assert q['exit_code']==0;streams(q,'native final '+str(q['index']))
 for stream,row in q['streams'].items():add('native-final/raw/'+Path(row['path']).name,Path(row['path']),'actual final native command stream')
add('native-final/merged-independent-audit.json',C/'call-return-finally-complete-final-independent-audit-v1.json','actual composite36native acceptance, earlier27 external');assert len(native['commands'])==9 and len(native['source_manifest_before'])==4936 and native['source_manifest_before']==native['source_manifest_after'] and binding['source_receipt']==pin(N/'execution.json') and binding['product_head']==HEAD
for rel,row in inventory['files'].items():
 p=W/rel;assert pin(p)==row;add('product-source/'+rel,p,'exact final named-gate source snapshot')
add('product-source/.github/workflows/ci.yml',W/'.github/workflows/ci.yml','exact final workflow snapshot')
directory('push-discovery-dispatch',DIS,'actual push/discovery/collector dispatch+logs');streams(read(DIS/'push-execution.json'),'actual feature push')
aux=[];dispatch=read(DIS/'dispatch.json')
for stem,kind in [('discover-run','saved successful GitHub discovery command'),('systemd-dispatch','saved systemd dispatch command'),('launcher','collector launcher actual output')]:
 for stream in ['stdout','stderr']:
  row=pin(DIS/(stem+'.'+stream+'.raw'));aux.append(dict(label=kind,stream=stream,pin=row,original_dispatch=pin(DIS/'dispatch.json')))
assert read(DIS/'discover-run.stdout.raw')['workflow_runs'][0]['id']==RUN and read(DIS/'launcher.stdout.raw')['run']==RUN
add('tools/capture_product_ci_v4.py',B/'capture_product_ci_v4.py','actual collector runner source');add('package.py',Path(__file__),'cache-only packager source')
paths={str(p):name for name,p in entries.items()};all_bound={x['pin']['path'] for x in bindings}|{x['pin']['path'] for x in aux};metadata_raw={str(SB/'source-head-tree.raw')};actual_raw={str(p) for name,p in entries.items() if name.endswith('.raw')};assert actual_raw==all_bound|metadata_raw
for row in bindings+aux:assert row['pin']['path'] in paths;row['payload']=paths[row['pin']['path']]
external=[]
for p in [C/'call-return-finally-complete-local-native-v1/execution.json',C/'own-ci-no-call-finally-independent-audit-prepared-v1/audit_own_ci_no_call_finally_v2.py',C/'own-ci-no-call-finally-independent-audit-prepared-v1/audit-result-v2.json',C/'own-ci-no-call-finally-independent-audit-prepared-v1/source-target-inventory-v1.json']:
 external.append(dict(role='reference-only historical baseline or prior27native; not new current acceptance',pin=pin(p)))
cli=binding['frozen_cli'];assert pin(cli['path'])=={k:cli[k] for k in ['path','bytes','sha256']};external.append(dict(role='native CLI excluded',pin=cli))
for row in native['dependencies'].values():
 if isinstance(row,dict) and 'path' in row and Path(row['path']).is_file():external.append(dict(role='native/tool dependency external, not embedded',pin=pin(row['path'])))
rows=[dict(path=name,source_path=str(p),bytes=pin(p)['bytes'],sha256=pin(p)['sha256'],role=roles[name]) for name,p in sorted(entries.items())]
manifest=dict(schema='portable-own-ci-evidence-v1',package='call-return-finally-own-ci-evidence-v1',payload_count=len(rows),payload=rows,product_head=HEAD,run_id=RUN,current_acceptance=dict(root_checks=953,independent_checks=2863,API_observations=149,API_raw=298,transport_failures=0,jobs=4,steps=52,suites_per_seed=373,passed_per_seed=3670,failed_per_seed=0,ignored_per_seed=98,primary_per_seed=160,support_explicit_JDK=7,strict_single_actual_step=364,JDK_commands=6,JDK_passes=9),command_stream_bindings=bindings,auxiliary_dispatch_stream_bindings=aux,noncommand_raw_metadata=[dict(payload='source-binding/source-head-tree.raw',reason='Explicit root saved Git tree copy; receipt stdout has distinct historical path but same actual bytes')],external_reference_pins=external,historical_boundary='Sealed v1 inventory runner metadata was wrong and v1 auditor was never executed; retained unchanged. v2 fixes five runner labels and is actual accepted independent audit. Prepared-only status fields remain historic. Old NoCall is reference only. Earlier27native not replayed here; merged native audit and external receipt pin preserve that scope. No CLI/JDK runtime binaries or target contents.')
mb=(json.dumps(manifest,indent=2)+'\n').encode();(D/'manifest.json').write_bytes(mb);(D/'allowlist.json').write_text(json.dumps(dict(status='explicit_payload_paths_and_actual_hashes',payload=rows),indent=2)+'\n')
archive=D/'capture.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,p in sorted(entries.items()):
    data=p.read_bytes();row=next(x for x in rows if x['path']==name);assert(len(data),hashlib.sha256(data).hexdigest())==(row['bytes'],row['sha256']);t=tarfile.TarInfo(name);t.size=len(data);t.mode=0o644;tar.addfile(t,io.BytesIO(data))
   t=tarfile.TarInfo('manifest.json');t.size=len(mb);t.mode=0o644;tar.addfile(t,io.BytesIO(mb))
with tarfile.open(archive,'r:gz') as tar:
 ms=tar.getmembers();assert len(ms)==len(rows)+1 and len({x.name for x in ms})==len(ms)
 for m in ms:
  q=PurePosixPath(m.name);assert m.isfile() and not q.is_absolute() and '..' not in q.parts and '\\' not in m.name;data=tar.extractfile(m).read()
  if m.name=='manifest.json':assert data==mb
  else:
   row=next(x for x in rows if x['path']==m.name);assert data==entries[m.name].read_bytes() and(len(data),hashlib.sha256(data).hexdigest())==(row['bytes'],row['sha256'])
summary=dict(status='created_safe_unique_regular_archive_all_payload_bytes_reopened',archive=pin(archive),manifest=pin(D/'manifest.json'),allowlist=pin(D/'allowlist.json'),packager=pin(Path(__file__)),payload_count=len(rows),member_count=len(rows)+1,bound_command_raw=len(bindings),bound_auxiliary_raw=len(aux),noncommand_metadata_raw=1,API_observations=149,API_raw=298,root_checks=953,independent_checks=2863,excluded='CLI/JDK/native runtime binaries, targets, unrelated old baseline payload',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());(D/'pack-summary.json').write_text(json.dumps(summary,indent=2)+'\n');(D/'execution.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
