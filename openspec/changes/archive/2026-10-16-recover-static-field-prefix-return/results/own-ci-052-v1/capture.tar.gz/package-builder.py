from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,zipfile
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=B/'CORE';CAP=B/'own-ci-static-prefix-census-root-v1';O=C/'static-prefix-052-own-ci-evidence-v1';O.mkdir(exist_ok=False)
def sha(v):return hashlib.sha256(v).hexdigest()
d=json.loads((CAP/'execution.json').read_text());assert d['product_sha']=='052c82484bb20ca8b7e22ffe9943503c961280f9' and d['run_id']==38859590941 and d['run_status']=='completed' and d['conclusion']=='success';payload={};rows=[]
def add(name,p,group):
 p=Path(p);assert p.is_file() and not p.is_symlink();v=p.read_bytes();assert name not in payload and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts;payload[name]=v;rows.append(dict(path=name,bytes=len(v),sha256=sha(v),source_path=str(p),group=group))
for p in sorted(CAP.rglob('*')):
 if p.is_file():add('capture/'+p.relative_to(CAP).as_posix(),p,'original_terminal_capture')
for i,obs in enumerate(d['observations']):
 assert obs['exit_code']==0
 for q in obs['streams'].values():
  v=Path(q['path']).read_bytes();assert len(v)==q['bytes'] and sha(v)==q['sha256'];assert str(Path(q['path'])) in {r['source_path'] for r in rows}
assert len(d['observations'])==133
for p in sorted((B/'own-ci-static-prefix-census-root-launch-v1').iterdir()):
 if p.is_file():add('capture-launch/'+p.name,p,'actual_capture_dispatch')
add('root-ci-acceptance.json',B/'static-prefix-052-own-ci-root-acceptance-v1.json','actual_exact_head_ci_acceptance')
add('root-ci-auditor.py',B/'accept_product_ci_v4.py','executed_root_auditor')
for p in sorted((C/'static-prefix-census-own-ci-root-audit-plan-v1').iterdir()):
 if p.is_file():add('root-audit/'+p.name,p,'prepared_and_actual_root_audit')
for p in sorted((C/'own-ci-static-prefix-census-independent-audit-v1').iterdir()):
 if p.is_file():add('independent-audit/'+p.name,p,'independent_ci_audit')
add('capture-runner.py',B/'capture_product_ci_v3.py','executed_capture_runner')
for n in ['source-head-binding.json','source-head-tree.raw','source-head-tree.argv.json']:add('source-lineage/'+n,C/'static-prefix-census-full-source-replay-v1'/n,'actual_source_binding')
add('source-lineage/native-execution.json',C/'static-prefix-reader-census-native-v1/execution.json','prior_build_reference_not_this_ci_execution')
add('package-builder.py',Path(__file__).resolve(),'package_builder')
with zipfile.ZipFile(CAP/'logs.zip') as z:
 names=z.namelist();assert len(names)==len(set(names)) and len(names)>0 and z.testzip() is None
 for n in names:assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
m=dict(schema='static-prefix-052-own-ci-evidence-v1',status='packaged_actual_successful_exact_head_ci',product_head=d['product_sha'],run_id=d['run_id'],conclusion='success',api_observations=len(d['observations']),api_raw_streams=2*len(d['observations']),jobs=4,successful_jobs=4,workspace_seeds=[dict(seed=seed,summaries=370,passed=3649,failed=0,ignored=98) for seed in ['5350648285461741569','5350648285461741570']],strict_items=364,required_named_gates=139,zip_members=len(names),original_zip=d['logs'],scope='Only product052 ownCI; docs/archive/main tracked separately. Prior failed c075/a89 retained separately.',payload_count=len(rows),members=sorted(rows,key=lambda r:r['path']))
v=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode();(O/'manifest.json').write_bytes(v)
with (O/'capture.tar.gz').open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,data in sorted({**payload,'manifest.json':v}.items()):
    i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data))
with tarfile.open(O/'capture.tar.gz') as t:
 assert len(t.getmembers())==len(payload)+1
 for i in t.getmembers():assert i.isfile() and t.extractfile(i).read()=={**payload,'manifest.json':v}[i.name]
a=(O/'capture.tar.gz').read_bytes();e=dict(status='reopened_and_verified_successful_ci_every_member',archive=str(O/'capture.tar.gz'),bytes=len(a),sha256=sha(a),payload_count=len(rows),member_count=len(rows)+1,manifest_sha256=sha(v));(O/'execution.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e))
