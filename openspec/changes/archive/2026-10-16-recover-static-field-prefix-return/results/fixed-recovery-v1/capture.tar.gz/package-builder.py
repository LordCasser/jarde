from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015'); C=B/'CORE';W=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');O=C/'static-prefix-fixed-recovery-evidence-v1';O.mkdir(exist_ok=False)
def sha(v):return hashlib.sha256(v).hexdigest()
payload={};rows=[]
def add(name,p,group):
 p=Path(p);v=p.read_bytes();assert p.is_file() and not p.is_symlink();assert name not in payload and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
 payload[name]=v;rows.append(dict(path=name,bytes=len(v),sha256=sha(v),source_path=str(p),group=group))
for prefix,dirname in [('failed-native-v1','static-prefix-fixed-native-v1'),('failed-native-v2','static-prefix-fixed-native-v2'),('accepted-focused-v3','static-prefix-fixed-native-v3'),('generated-source-replay-v2','static-prefix-full-source-replay-v2')]:
 base=C/dirname
 for p in sorted(base.rglob('*')):
  if p.is_file() and not p.name.endswith('.tmp'):add(prefix+'/'+p.relative_to(base).as_posix(),p,prefix)
for name in ['static-prefix-full-generated-source-independent-audit-v1.json','static-prefix-implemented-ast-review-v1.json','static-prefix-preimplementation-review-cache-lineage-v1.json','static-prefix-accurate-proof-api-review-v1.json','static-prefix-signature-owner-scope-review-v1.json']:
 add('reviews/'+name,C/name,'static_or_independent_review')
for p in sorted((C/'static-prefix-full-source-replay-v1').iterdir()):
 if p.is_file():add('unexecuted-preparation-v1/'+p.name,p,'prepared_only_not_executed')
for p in sorted((W/'tests/fixtures/recover-static-field-prefix-return').rglob('*')):
 if p.is_file():add('fixture/'+p.relative_to(W/'tests/fixtures/recover-static-field-prefix-return').as_posix(),p,'unchanged_fixture')
add('package-builder.py',Path(__file__).resolve(),'package_builder')
command_groups=[]
for label,rel in [('failed-native-v1','static-prefix-fixed-native-v1/run-v1/execution.json'),('failed-native-v2','static-prefix-fixed-native-v2/run-v1/execution.json'),('accepted-focused-v3','static-prefix-fixed-native-v3/run-v1/execution.json'),('generated-source-replay-v2','static-prefix-full-source-replay-v2/run-v1/execution.json')]:
 p=C/rel;d=json.loads(p.read_text());raw=[]
 for command in d['commands']:
  for stream in command['streams'].values():
   v=Path(stream['path']).read_bytes();assert len(v)==stream['bytes'] and sha(v)==stream['sha256'];assert str(Path(stream['path'])) in {row['source_path'] for row in rows};raw.append(stream)
 command_groups.append(dict(group=label,status=d['status'],commands=len(d['commands']),raw_streams=len(raw)))
assert sum(g['commands'] for g in command_groups)==29 and sum(g['raw_streams'] for g in command_groups)==58
m=dict(schema='static-prefix-fixed-recovery-evidence-v1',scope='Focused actual implementation and complete generated-source runtime proof only; product-checks and own CI remain separate gates.',product_head='c075d1a15ab9e29482ee2eb006bc152e5c57980c',frozen_cli=dict(path=str(B/'jarde-cli-static-prefix-fixed-v3'),bytes=59699272,sha256='3596a781705c46e51a182d45cd7a54ea8f448cf6951e1f4ce3f07cf5a00af821',mode='0555',inside_archive=False),source_count=4915,actual_command_groups=command_groups,command_count=29,command_raw_count=58,focused_totals=dict(passed=29,failed=0,ignored=4),full_replay=dict(commands=14,generated_source_compiles=2,unchanged_driver_compiles=2,rebuilt_only_runtime_oracles=8,main_bytes=6,driver_bytes=60,generated_source_sha256='eabbf22187e0b3c24bb984d9496a4785acc479fe05ca9e07acf8952337e25811',generated_source_bytes=1617),limits=['The four default ignored compatibility runtime tests were not run in the focused command set.','No claim of dynamic deadline testing or new broad Java semantic equivalence.','Signature/InnerClasses/EnclosingMethod source-owner contexts remain conservatively refused in this leaf.','Two failed implementation runs are preserved; their source manifests describe WIP bytes, not the final c075 Git tree.','Prepared replay-v1 never executed and incorrectly targeted original source; corrected replay-v2 actually compiles unchanged generated report.text.','A preimplementation static-review cache draft was accidentally overwritten, with its original hash and unavailability disclosed; no execution/raw/original/generated source was lost.'],payload_count=len(rows),members=sorted(rows,key=lambda row:row['path']))
v=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode();(O/'manifest.json').write_bytes(v)
with (O/'capture.tar.gz').open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,data in sorted({**payload,'manifest.json':v}.items()):
    i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data))
with tarfile.open(O/'capture.tar.gz') as t:
 assert len(t.getmembers())==len(payload)+1
 for i in t.getmembers():assert i.isfile() and t.extractfile(i).read()=={**payload,'manifest.json':v}[i.name]
a=(O/'capture.tar.gz').read_bytes();e=dict(status='reopened_and_verified_every_member',archive=str(O/'capture.tar.gz'),bytes=len(a),sha256=sha(a),payload_count=len(rows),member_count=len(rows)+1,commands=29,command_raw_streams=58,manifest_sha256=sha(v));(O/'execution.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e))
