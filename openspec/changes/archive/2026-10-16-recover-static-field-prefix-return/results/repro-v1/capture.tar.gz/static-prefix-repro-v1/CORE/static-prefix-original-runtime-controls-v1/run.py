from pathlib import Path
import os,json,hashlib,importlib.util,sys,shutil
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');H=Path(__file__).resolve().parent;W=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
PREV=B/'CORE/effectful-finally-current-screen-v1/run-v1';OUT=H/'run-v1';OUT.mkdir(exist_ok=False)
def pin(p):
 p=Path(p).resolve();z=p.read_bytes();return {'path':str(p),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
build=json.loads((B/'reference-overload-final-focused-v1/execution.json').read_text());sources=build['source_manifest_before'];assert sources==build['source_manifest_after'] and len(sources)==4907
for q in sources:
 p=pin(W/q['path']);assert p['bytes']==q['bytes'] and p['sha256']==q['sha256']
assert not(W/'target').exists() and shutil.disk_usage(W).free>=5*1024**3
jd=json.loads((OLD/'tools/jdk-manifest.json').read_text());tools={x['leg']:x['jdk_tools'] for x in jd['legs']}
inputs=[H/'StaticPrefixProbe.java',H/'run.py',PREV/'execution.json',*(PREV/(leg+'-original-classes/FO.class') for leg in ['javac23','javac8']),OLD/'tools/jdk-manifest.json',OLD/'tools-prep/guard.py',OLD/'tools-prep/target_scan.py']
for leg in ['javac23','javac8']:
 for n in ['java','javac']:
  q=tools[leg][n];assert pin(q['path'])=={k:q[k] for k in ['path','bytes','sha256']};inputs.append(Path(q['path']))
before=[pin(x) for x in inputs];g=load('prefix_runtime_guard',OLD/'tools-prep/guard.py');sc=load('prefix_runtime_scan',OLD/'tools-prep/target_scan.py');g.ROOT=W;g.OUT=OUT;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.target_bytes=lambda:sc.target_bytes(W);g.expected_test_summaries=lambda i,z:None;g.command_stream=pin;g.ENV_VALUES={}
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','LANG','LC_ALL']};env['PATH']='/usr/bin:/bin'
oracle=b'0/0\n8/8\n-2147483648/-2147483648\n8/100\n-2147483648/100\n1/100\n'
r={'status':'running','scope':'Original unchanged FO classes only, independent additive driver: returned NEW sum, nonzero, overflow and saved return before finally. No rebuilt Jarde runtime or new product acceptance.','source_count':4907,'input_before':before,'commands':[],'oracle_hex':oracle.hex()}
def save():(OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,a):
 q=g.run_command(len(r['commands'])+1,[str(x) for x in a],env);q['label']=label;r['commands'].append(q);save();assert q['guard_stop'] is None and q['exit_code']==0,label;return q
save()
try:
 for leg in ['javac23','javac8']:
  d=OUT/leg;original=d/'original';driver=d/'driver';original.mkdir(parents=True);driver.mkdir();shutil.copyfile(PREV/(leg+'-original-classes/FO.class'),original/'FO.class');assert (original/'FO.class').read_bytes()==(PREV/(leg+'-original-classes/FO.class')).read_bytes()
  a=[tools[leg]['javac']['path']]+(['--release','8','-Xlint:-options'] if leg=='javac23' else ['-source','8','-target','8'])+['-g:none','-classpath',original,'-d',driver,H/'StaticPrefixProbe.java'];run(leg+'-compile-independent-driver',a)
  for runtime in ['javac8','javac23']:
   q=run(leg+'-'+runtime+'-original-prefix-controls',[tools[runtime]['java']['path'],'-Xverify:all','-cp',str(driver)+':'+str(original),'StaticPrefixProbe']);z=Path(q['streams']['stdout']['path']).read_bytes();e=Path(q['streams']['stderr']['path']).read_bytes();q['oracle_exact']=z==oracle and not e;save();assert q['oracle_exact']
 r['status']='captured_original_prefix_runtime_controls_pending_review'
except BaseException as e:r['status']='failed_raw_preserved';r['error']=repr(e)
finally:
 r['input_after']=[pin(x) for x in inputs];r['inputs_identical']=r['input_after']==before;r['source_after_matches']=all(pin(W/q['path'])['sha256']==q['sha256'] for q in sources);r['target_absent']=not(W/'target').exists();r['generated_classes']=[pin(x) for x in sorted(OUT.rglob('*.class'))];save()
 if not r['inputs_identical'] or not r['source_after_matches'] or not r['target_absent']:r['status']='failed_integrity';save()
print(r['status'],len(r['commands']));raise SystemExit(0 if r['status']=='captured_original_prefix_runtime_controls_pending_review' else 1)
