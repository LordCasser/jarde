#!/usr/bin/env python3
"""Prepared current frozen-CLI FO/FY/FX dual-compiler screen; root executes it."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, shutil, sys, zipfile
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
W=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde'); HERE=Path(__file__).resolve().parent
FIX=W/'openspec/evidence/java-syntax-2026-10-05/return-effectful-finally-patrol/fixture'
CLI=B/'jarde-cli-reference-overload-proof-v1'; BUILD=B/'reference-overload-final-focused-v1/execution.json'
OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
GUARD=OLD/'tools-prep/guard.py'; SCAN=OLD/'tools-prep/target_scan.py'; JDK=OLD/'tools/jdk-manifest.json'
FREE=5*1024**3; TARGET=1024**3
NAMES=['FO','FY','FX']
ORACLE={'FO':b'1/100\n','FY':b'f\n3000/107/3000\n','FX':b'fin:1\nfin:3\n204/3000/100\n'}
def pin(path):
 p=Path(path).resolve(); h=hashlib.sha256(p.read_bytes()).hexdigest(); return {'path':str(p),'bytes':p.stat().st_size,'sha256':h}
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); sys.modules[name]=m; spec.loader.exec_module(m); return m
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args(); out=a.out.resolve()
 if out.parent!=HERE or out.exists(): raise SystemExit('output must be a fresh child of this harness directory')
 if (W/'target').exists() or shutil.disk_usage(W).free<FREE: raise SystemExit('target must be absent and >=5 GiB free')
 build=json.loads(BUILD.read_text()); src=build.get('source_manifest_before'); frozen=build.get('frozen_cli')
 if build.get('status')!='expected_command_outcomes_observed_pending_independent_acceptance' or src!=build.get('source_manifest_after') or len(src or [])!=4907 or build.get('target_absent') is not True: raise SystemExit('focused build receipt is not the expected frozen 4907-source receipt')
 if pin(CLI)!={k:frozen.get(k) for k in ('path','bytes','sha256')} or frozen.get('mode')!='0555' or CLI.stat().st_mode&0o777!=0o555: raise SystemExit('frozen CLI does not match the accepted build receipt')
 def source_pins(): return [{'path':q['path'],'bytes':pin(W/q['path'])['bytes'],'sha256':pin(W/q['path'])['sha256']} for q in src]
 if source_pins()!=src: raise SystemExit('current source closure differs from frozen build receipt')
 jd=json.loads(JDK.read_text()); legs={x['leg']:x['jdk_tools'] for x in jd['legs'] if x.get('leg') in ('javac23','javac8')}
 tools={'javac23':Path(legs['javac23']['javac']['path']),'java23':Path(legs['javac23']['java']['path']),
        'javac8':Path(legs['javac8']['javac']['path']),'java8':Path(legs['javac8']['java']['path'])}
 for key,path in tools.items():
  row=legs['javac23' if key.endswith('23') else 'javac8']['javac' if key.startswith('javac') else 'java']
  if pin(path)!={k:row[k] for k in ('path','bytes','sha256')}: raise SystemExit('JDK tool pin mismatch: '+key)
 sources=[FIX/(n+'.java') for n in NAMES]
 if any(not p.is_file() for p in sources): raise SystemExit('fixture source missing')
 inputs=sorted(set([Path(__file__).resolve(),CLI.resolve(),BUILD.resolve(),GUARD.resolve(),SCAN.resolve(),JDK.resolve(),*sources,*tools.values(),*(W/q['path'] for q in src)]))
 before=[pin(p) for p in inputs]; out.mkdir(parents=True)
 g=load('effectful_finally_guard',GUARD); sc=load('effectful_finally_scan',SCAN)
 g.ROOT=W; g.OUT=out; g.FREE_LIMIT=FREE; g.TARGET_LIMIT=TARGET; g.target_bytes=lambda:sc.target_bytes(W); g.expected_test_summaries=lambda i,z:None; g.command_stream=lambda p:pin(p); g.ENV_VALUES={}
 env={k:v for k,v in os.environ.items() if k in ('HOME','TMPDIR','LANG','LC_ALL')}; env['PATH']='/usr/bin:/bin'
 for k in ('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','RUST_MIN_STACK','CARGO_TARGET_DIR'): env.pop(k,None)
 rec={'schema':'effectful-finally-current-screen-v1','status':'running','scope':'Capture current frozen CLI behavior for FO/FY/FX using source-identical JDK23 --release 8 and real javac8 builds; whole-class JSON reports, exact report.text compilation and Java8/23 behavior. Collection success is not recovery acceptance.','cli_binding':{'cli':pin(CLI),'receipt':pin(BUILD),'frozen_cli':frozen,'source_count':4907},'source_manifest_before':src,'inputs_before':before,'guards':{'minimum_free_bytes':FREE,'maximum_target_bytes':TARGET,'default_stack':True},'tools':{k:pin(v) for k,v in tools.items()},'oracle_hex':{k:v.hex() for k,v in ORACLE.items()},'commands':[],'cases':{}}
 def save():
  q=out/'execution.json.tmp'; q.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n'); q.replace(out/'execution.json')
 def run(label,argv,expected=None):
  cmd=[str(x) for x in argv]; row=g.run_command(len(rec['commands'])+1,cmd,env); row.update({'label':label,'argv_exact':cmd,'cwd':str(W),'guard_status':'stopped' if row.get('guard_stop') is not None else 'clear','expected_exit':expected}); rec['commands'].append(row); save()
  if row.get('guard_stop') is not None: raise RuntimeError('guard stopped '+label+'; raw streams retained')
  return row
 def runtime(label,java,cp,name):
  r=run(label,[java,'-Xverify:all','-cp',cp,name],0); o=Path(r['streams']['stdout']['path']).read_bytes(); e=Path(r['streams']['stderr']['path']).read_bytes(); r.update({'oracle_equal':o==ORACLE[name],'stdout_hex':o.hex(),'stderr_empty':not e,'runtime_matches_oracle':r.get('exit_code')==0 and o==ORACLE[name] and not e}); save(); return r
 save()
 try:
  for leg in ('javac23','javac8'):
   dest=out/(leg+'-original-classes'); dest.mkdir(); args=[tools[leg],'-g:none','-d',dest,*sources]
   if leg=='javac23': args[1:1]=['--release','8','-Xlint:-options']
   else: args[1:1]=['-source','8','-target','8']
   r=run(leg+'-compile-all-three-original-sources',args,0)
   if r.get('exit_code')!=0: raise RuntimeError(leg+' original source compile failed')
   classes=sorted(dest.glob('*.class'))
   if {p.name for p in classes}!={n+'.class' for n in NAMES}: raise RuntimeError(leg+' unexpected original class inventory')
   jars=out/(leg+'-original-jars'); jars.mkdir(); rec.setdefault('original_compiles',{})[leg]={'command':r['index'],'source_pins':[pin(p) for p in sources],'class_pins':[pin(p) for p in classes],'jar_classes':{}}
   for name in NAMES:
    jar=jars/(name+'.jar')
    with zipfile.ZipFile(jar,'w',compression=zipfile.ZIP_STORED) as z:
     info=zipfile.ZipInfo(name+'.class',(1980,1,1,0,0,0)); info.compress_type=zipfile.ZIP_STORED; z.writestr(info,(dest/(name+'.class')).read_bytes())
    rec['original_compiles'][leg]['jar_classes'][name]=pin(jar); c={'oracle_hex':ORACLE[name].hex(),'original_runtime':[],'cli':{},'generated_runtime':[]}; rec['cases'].setdefault(leg,{})[name]=c
    for runtime_leg in ('java8','java23'):
     q=runtime(leg+'-'+runtime_leg+'-original-'+name,tools[runtime_leg],jar,name); c['original_runtime'].append({'command':q['index'],'matches_oracle':q.get('runtime_matches_oracle'),'exit_code':q.get('exit_code')})
   save()
  for leg in ('javac23','javac8'):
   for name in NAMES:
    jar=out/(leg+'-original-jars')/(name+'.jar'); c=rec['cases'][leg][name]; srcout=out/(leg+'-'+name+'-generated'); srcout.mkdir(); clsout=srcout/'classes'; clsout.mkdir()
    q=run(leg+'-whole-class-json-'+name,[CLI,'class-source','--input',jar,'--class',name,'--policy','plain-jar','--release','8','--format','json','--evidence','all','--budget','elapsed_millis=10000'],0)
    c['cli']={'command':q['index'],'exit_code':q.get('exit_code'),'json_raw':q['streams']['stdout']};
    try:
     doc=json.loads(Path(q['streams']['stdout']['path']).read_bytes()); text=doc['text']; java=srcout/(name+'.java'); java.write_bytes(text.encode('utf-8'))
     if java.read_bytes()!=text.encode('utf-8'): raise ValueError('report text write mismatch')
     c['report']={'text_source':pin(java),'method_count':len(doc.get('methods',[])),'execution':doc.get('execution'),'report_class':doc.get('class')}
    except Exception as e: c['report_error']=repr(e); save(); continue
    compileq=run(leg+'-javac23-compile-exact-report-text-'+name,[tools['javac23'],'--release','8','-g:none','-Xlint:-options','-classpath',clsout,'-d',clsout,java],0)
    c['generated_compile']={'command':compileq['index'],'exit_code':compileq.get('exit_code'),'exact_report_text':True,'original_jar_on_classpath':False,'class_files':[pin(p) for p in sorted(clsout.rglob('*.class'))]}
    if compileq.get('exit_code')==0:
     for runtime_leg in ('java8','java23'):
      rr=runtime(leg+'-'+runtime_leg+'-generated-'+name,tools[runtime_leg],clsout,name); c['generated_runtime'].append({'command':rr['index'],'matches_oracle':rr.get('runtime_matches_oracle'),'exit_code':rr.get('exit_code')})
    save()
  rec['summary']={leg:{n:{'original_all_match':all(x['matches_oracle'] for x in c['original_runtime']),'cli_exit':c.get('cli',{}).get('exit_code'),'generated_compile_exit':c.get('generated_compile',{}).get('exit_code'),'generated_all_match':len(c.get('generated_runtime',[]))==2 and all(x['matches_oracle'] for x in c['generated_runtime']),'report_error':c.get('report_error')} for n,c in rows.items()} for leg,rows in rec['cases'].items()}
  rec['status']='captured_current_finally_screen_pending_independent_review'
 except BaseException as e: rec['status']='capture_failed_raw_preserved'; rec['error']=f'{type(e).__name__}: {e}'
 finally:
  try:
   rec['inputs_after']=[pin(p) for p in inputs]; rec['inputs_identical']=rec['inputs_after']==before; rec['source_manifest_after']=source_pins(); rec['sources_identical']=rec['source_manifest_after']==src; rec['target_absent']=not (W/'target').exists(); rec['target_bytes_after']=sc.target_bytes(W); rec['free_bytes_after']=shutil.disk_usage(W).free; rec['command_count']=len(rec['commands'])
   if not rec['inputs_identical'] or not rec['sources_identical'] or not rec['target_absent']: rec['status']='capture_failed_input_or_target_integrity'
   save()
  except BaseException as e: rec['status']='capture_failed_finalization'; rec['finalization_error']=repr(e); save()
 print(json.dumps({'status':rec['status'],'command_count':rec.get('command_count'),'summary':rec.get('summary')},ensure_ascii=False))
 return 0 if rec['status']=='captured_current_finally_screen_pending_independent_review' else 1
if __name__=='__main__': raise SystemExit(main())
