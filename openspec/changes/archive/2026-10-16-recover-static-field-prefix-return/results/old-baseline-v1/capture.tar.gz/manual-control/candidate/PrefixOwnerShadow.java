class PrefixOwnerShadow {
    static int PrefixOwnerShadow;
    static int i;
    static int bump() { return ++PrefixOwnerShadow.i; }
}
