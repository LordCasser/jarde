#!/usr/bin/env python3
"""Capture the old-production static-field-prefix regression, then freeze its CLI artifact."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, re, shutil, sys, tomllib

B = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
H = Path(__file__).resolve().parent
W = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde')
TOOLS = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep')
JDK_ROOT = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jdk23/jdk-23.0.1')
JDK_MANIFEST = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jdk-manifest.json')
GUARD_PATH = TOOLS / 'guard.py'
SCAN_PATH = TOOLS / 'target_scan.py'
CLOSURE_PATH = TOOLS / 'workspace_runner.py'
FP = W / 'tests/fixtures/corpus-fingerprint.json'
FIX = W / 'tests/fixtures/recover-static-field-prefix-return'
CLI = B / 'jarde-cli-static-prefix-old-native-v2'
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3
EXPECTED_FIXTURE_ADDITIONS = {
    'tests/fixtures/recover-static-field-prefix-return/FO.java',
    'tests/fixtures/recover-static-field-prefix-return/StaticPrefixProbe.java',
    'tests/fixtures/recover-static-field-prefix-return/main.stdout',
    'tests/fixtures/recover-static-field-prefix-return/probe.stdout',
    'tests/fixtures/recover-static-field-prefix-return/v8/FO.class',
    'tests/fixtures/recover-static-field-prefix-return/v8-javac8/FO.class',
}
UNIT_TESTS = {
    'static_prefix_returns_the_new_value_on_both_compiler_legs',
    'static_prefix_keeps_read_write_and_return_origins',
    'saved_return_still_precedes_the_finally_write',
}
CLI_TEST = 'static_prefix_json_keeps_the_new_sum_and_the_complete_class'
SUMMARY_RE = re.compile(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;')
OUTCOME_RE = re.compile(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?:, [^\n]*)?$', re.M)
ANSI_RE = re.compile(r'\x1b\[[0-9;]*m')


def pin(path: Path) -> dict:
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError(f'not a regular file: {path}')
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load module: {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def source_pins(paths: set[Path]) -> list[dict]:
    rows = []
    for path in sorted(paths):
        if path.is_symlink() or not path.is_file():
            raise ValueError(f'source closure contains a linked or missing file: {path}')
        rows.append({'path': str(path.relative_to(W)), 'bytes': path.stat().st_size,
                     'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    return rows


def parse_test_outcome(raw: bytes, expected_names: set[str], expected: tuple[int, int, int], label: str) -> dict:
    text = ANSI_RE.sub('', raw.decode('utf-8', errors='replace'))
    sums = SUMMARY_RE.findall(text)
    outcomes = OUTCOME_RE.findall(text)
    if len(sums) != 1:
        raise RuntimeError(f'{label}: expected one actual libtest summary, found {len(sums)}; this is not accepted as a regression result')
    status, passed, failed, ignored = sums[0]
    counts = (int(passed), int(failed), int(ignored))
    observed_names = {name for name, _ in outcomes}
    if counts != expected or observed_names != expected_names:
        raise RuntimeError(f'{label}: unexpected actual test summary/names: summary={sums[0]!r}, names={sorted(observed_names)!r}')
    should_fail = expected[1] > 0
    if (status == 'FAILED') != should_fail:
        raise RuntimeError(f'{label}: summary status {status} disagrees with actual failure count {failed}')
    failed_names = [name for name, result in outcomes if result == 'FAILED']
    passed_names = [name for name, result in outcomes if result == 'ok']
    if len(failed_names) != expected[1] or len(passed_names) != expected[0]:
        raise RuntimeError(f'{label}: named outcomes do not match summary: {outcomes!r}')
    # Keep compact failure context alongside the full original stdout raw.
    failure_context = {}
    for name in failed_names:
        starts = [m.start() for m in re.finditer(r'^---- ' + re.escape(name) + r' stdout ----\s*$', text, re.M)]
        if starts:
            start = starts[0]
            next_part = re.search(r'^---- |^failures:', text[start + 1:], re.M)
            end = start + 1 + next_part.start() if next_part else min(len(text), start + 1600)
            failure_context[name] = text[start:end][:1600]
        else:
            failure_context[name] = ''
    return {'summary': {'status': status, 'passed': counts[0], 'failed': counts[1], 'ignored': counts[2]},
            'named_outcomes': [{'name': n, 'outcome': s} for n, s in outcomes],
            'failure_names': failed_names, 'passing_names': passed_names,
            'failure_context': failure_context, 'summary_is_actual_libtest_output': True}


def main() -> int:
    out = H / 'run-v1'
    if out.exists():
        raise SystemExit(f'refusing to overwrite existing output: {out}')
    if (W / 'target').exists() or CLI.exists():
        raise SystemExit('preflight requires absent target and absent frozen CLI')
    if shutil.disk_usage(W).free < FREE_LIMIT:
        raise SystemExit('preflight requires at least 5 GiB free')
    if not FIX.is_dir() or not FP.is_file():
        raise SystemExit('frozen fixture directory or corpus fingerprint missing')

    guard = load_module('static_prefix_old_guard', GUARD_PATH)
    scan = load_module('static_prefix_old_scan', SCAN_PATH)
    closure = load_module('static_prefix_old_workspace_closure', CLOSURE_PATH)
    guard.ROOT = W
    guard.OUT = out
    guard.FREE_LIMIT = FREE_LIMIT
    guard.TARGET_LIMIT = TARGET_LIMIT
    guard.target_bytes = lambda: scan.target_bytes(W)
    guard.expected_test_summaries = lambda _index, _data: None
    guard.command_stream = pin
    closure.ROOT = W
    paths = closure.source_paths()
    if not any(p == FP for p in paths):
        paths.add(FP)
    if not paths.issuperset({W / 'tests/recover_static_field_prefix_return.rs',
                             W / 'crates/jarde-cli/tests/class_source_cli.rs'}):
        raise RuntimeError('dynamic source closure omitted new native regression tests')

    initial_sources = source_pins(paths)
    initial_fp_raw = FP.read_bytes()
    old_manifest = json.loads(initial_fp_raw)
    if len(old_manifest.get('files', [])) != 2226:
        raise RuntimeError('continued fingerprint is not the expected already-regenerated 2226-entry source snapshot')
    fixture_files = {str(p.relative_to(W)) for p in FIX.rglob('*') if p.is_file() and p.suffix.lower() != '.md'}
    if fixture_files != EXPECTED_FIXTURE_ADDITIONS:
        raise RuntimeError(f'fixture addition set differs from the six frozen binary/source paths: {sorted(fixture_files)}')

    jdk = json.loads(JDK_MANIFEST.read_text())
    leg = next(x for x in jdk.get('legs', []) if x.get('leg') == 'javac23')
    tools = {'javac23': Path(leg['jdk_tools']['javac']['path']),
             'java23': Path(leg['jdk_tools']['java']['path'])}
    for key, path in tools.items():
        row = leg['jdk_tools']['javac' if key == 'javac23' else 'java']
        if pin(path) != {k: row[k] for k in ('path', 'bytes', 'sha256')}:
            raise RuntimeError(f'JDK 23 manifest pin mismatch: {key}')

    env = os.environ.copy()
    for key in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH',
                'RUST_MIN_STACK', 'CARGO_TARGET_DIR'):
        env.pop(key, None)
    env.update(guard.ENV_VALUES)
    env['RUSTUP_TOOLCHAIN'] = 'stable'
    env['PATH'] = f'{JDK_ROOT}/bin:/home/lordcasser/.cargo/bin:/usr/bin:/bin'
    env['JAVA_HOME'] = str(JDK_ROOT)

    out.mkdir(parents=True)
    rec = {
        'schema': 'static-prefix-old-native-regression-v2', 'status': 'running',
        'scope': 'Old-production native test failures plus frozen CLI build. This runner does not change production source. A failure is accepted only when actual libtest summaries and named assertions prove it; compile errors are not regression evidence.',
        'product_base_head': 'fc195175d2a162a2ac8caa286a7cd5c69796d3e2',
        'branch': 'codex/static-field-prefix-return', 'default_stack': True,
        'guard': {'minimum_free_bytes': FREE_LIMIT, 'maximum_target_bytes': TARGET_LIMIT,
                  'target_absent_before': True, 'default_stack_environment_removed': True},
        'runner': pin(Path(__file__)), 'guard_module': pin(GUARD_PATH),
        'target_scan_module': pin(SCAN_PATH), 'source_closure_module': pin(CLOSURE_PATH),
        'jdk_manifest': pin(JDK_MANIFEST), 'jdk23': {k: pin(v) for k, v in tools.items()},
        'environment_overrides': guard.ENV_VALUES,
        'source_manifest_initial': initial_sources, 'source_manifest_before': None,
        'source_manifest_after': None, 'source_file_count_initial': len(initial_sources),
        'fingerprint_before': {'pin': pin(FP), 'entries': len(old_manifest['files'])},
        'fingerprint_after': None, 'fixture_addition_paths': sorted(EXPECTED_FIXTURE_ADDITIONS),
        'commands': [], 'frozen_cli': None, 'final_target_absent': None,
    }

    def save() -> None:
        tmp = out / 'execution.json.tmp'
        tmp.write_text(json.dumps(rec, ensure_ascii=False, indent=2) + '\n')
        tmp.replace(out / 'execution.json')

    def run(label: str, argv: list[str], expected_exit: int) -> dict:
        index = len(rec['commands']) + 1
        row = guard.run_command(index, argv, env)
        row.update({'label': label, 'argv_exact': argv, 'cwd': str(W),
                    'expected_exit': expected_exit, 'expected_exit_observed': row.get('exit_code') == expected_exit,
                    'guard_status': 'stopped' if row.get('guard_stop') is not None else 'clear'})
        rec['commands'].append(row)
        save()
        if row.get('guard_stop') is not None:
            raise RuntimeError(f'{label}: guard stopped the command; original streams retained')
        if row.get('exit_code') != expected_exit:
            raise RuntimeError(f'{label}: expected exit {expected_exit}, observed {row.get("exit_code")}; original streams retained')
        return row

    save()
    try:
        # The prior real regenerator succeeded; only its interleaved name parser failed.
        prior=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/static-prefix-old-native-v1')
        acceptance=json.loads((prior/'actual-regeneration-root-acceptance-v1.json').read_text())
        prior_execution=json.loads((prior/'run-v1/execution.json').read_text())
        if acceptance['status']!='accepted_explicit_regeneration_only_parser_failure_preserved' or prior_execution['commands'][0]['exit_code']!=0:
            raise RuntimeError('prior actual regenerator has not been accepted')
        recorded=(prior/'corpus-fingerprint-after.json').read_bytes()
        if FP.read_bytes()!=recorded: raise RuntimeError('current fingerprint is not prior explicit regeneration output')
        before_manifest=json.loads((prior/'corpus-fingerprint-before.json').read_text())
        before_rows={x['path']:x for x in before_manifest['files']}; after_rows={x['path']:x for x in old_manifest['files']}
        if set(after_rows)-set(before_rows)!=EXPECTED_FIXTURE_ADDITIONS or not all(after_rows.get(k)==v for k,v in before_rows.items()):
            raise RuntimeError('continued fingerprint changed old rows or expected additions')
        rec['prior_regenerator']={'acceptance':pin(prior/'actual-regeneration-root-acceptance-v1.json'),'execution':pin(prior/'run-v1/execution.json'),'status':'one actual successful explicit regeneration, no rerun','new_entries':2226}
        rec['source_manifest_before']=initial_sources
        rec['fingerprint_after']={'pin':pin(FP),'entries':2226,'added':[after_rows[k] for k in sorted(EXPECTED_FIXTURE_ADDITIONS)],'changed_existing':[],'removed':[],'non_files_fields_unchanged':True,'source':'prior successful real regenerator, independently rechecked'}
        save()

        # 2. Normal corpus checks, now against the regenerated 2226-entry fingerprint.
        row = run('normal-corpus-fingerprint-suite', ['cargo', 'test', '--test', 'p5_corpus_fingerprint', '--locked'], 0)
        row['actual_tests'] = parse_test_outcome(Path(row['streams']['stdout']['path']).read_bytes(),
                                                 {'corpus_files_match_the_recorded_fingerprint',
                                                  'every_acceptance_row_is_indexed_against_existing_corpus',
                                                  'every_dimension_is_carried_by_existing_corpus',
                                                  'the_indexed_rows_are_the_rows_the_acceptance_table_names',
                                                  'the_manifest_matches_its_rendered_classification',
                                                  'regenerate_corpus_fingerprint'},
                                                 (5, 0, 1), 'normal fingerprint suite')
        if source_pins(paths) != rec['source_manifest_before']:
            raise RuntimeError('source closure changed during normal fingerprint suite')
        save()

        # 3. Real old-production tests: require three named tests in one summary, 1 green / 2 red.
        unit_argv = ['cargo', 'test', '--test', 'recover_static_field_prefix_return', '--locked']
        row = run('old-production-static-prefix-unit-regression', unit_argv, 101)
        row['actual_tests'] = parse_test_outcome(Path(row['streams']['stdout']['path']).read_bytes(),
                                                 UNIT_TESTS, (1, 2, 0), 'static-prefix native regression')
        if set(row['actual_tests']['failure_names']) != {
            'static_prefix_returns_the_new_value_on_both_compiler_legs',
            'static_prefix_keeps_read_write_and_return_origins',
        } or row['actual_tests']['passing_names'] != ['saved_return_still_precedes_the_finally_write']:
            raise RuntimeError('native red/green names differ from the intended behavior regressions')
        if 'panicked at' not in Path(row['streams']['stdout']['path']).read_text(errors='replace'):
            raise RuntimeError('native failures do not contain actual assertion panic evidence')
        row['failure_semantics'] = 'actual assertion failures with named text/origin tests; full assertion output remains in stdout.raw'
        save()
        if source_pins(paths) != rec['source_manifest_before']:
            raise RuntimeError('source closure changed during static-prefix regression tests')

        # 4. Confirm the new public JSON CLI assertion itself fails against old production.
        cli_argv = ['cargo', 'test', '-p', 'jarde-cli', '--test', 'class_source_cli', '--locked',
                    CLI_TEST, '--', '--exact']
        row = run('old-production-static-prefix-json-cli-regression', cli_argv, 101)
        row['actual_tests'] = parse_test_outcome(Path(row['streams']['stdout']['path']).read_bytes(),
                                                 {CLI_TEST}, (0, 1, 0), 'static-prefix public CLI regression')
        text = ANSI_RE.sub('', Path(row['streams']['stdout']['path']).read_text(errors='replace'))
        if CLI_TEST not in text or 'FAILED' not in text or 'panicked at' not in text:
            raise RuntimeError('CLI command did not produce a named assertion failure; compile errors are not accepted')
        row['failure_semantics'] = 'exact filtered public JSON CLI test ran and failed its assertion; full output retained in stdout.raw'
        save()
        if source_pins(paths) != rec['source_manifest_before']:
            raise RuntimeError('source closure changed during public CLI regression test')

        # 5. Build/freeze the same old production CLI; record Cargo's actual fresh flag.
        row = run('build-old-production-cli',
                  ['cargo', 'build', '-p', 'jarde-cli', '--bin', 'jarde-cli', '--locked', '--message-format=json-render-diagnostics'], 0)
        events = [json.loads(line) for line in Path(row['streams']['stdout']['path']).read_text().splitlines() if line.startswith('{')]
        artifacts = [e for e in events if e.get('reason') == 'compiler-artifact'
                     and e.get('target', {}).get('name') == 'jarde-cli'
                     and 'bin' in e.get('target', {}).get('kind', []) and e.get('executable')]
        if len(artifacts) != 1:
            raise RuntimeError(f'expected exactly one CLI binary compiler-artifact record, got {len(artifacts)}')
        artifact = artifacts[0]
        actual_binary = W / 'target/debug/jarde-cli'
        if Path(artifact['executable']).resolve() != actual_binary.resolve() or not actual_binary.is_file():
            raise RuntimeError('Cargo compiler artifact does not resolve to target/debug/jarde-cli')
        row['compiler_artifact'] = artifact
        row['artifact_fresh'] = artifact.get('fresh')
        if CLI.exists():
            raise RuntimeError('refusing to overwrite frozen CLI')
        shutil.copyfile(actual_binary, CLI)
        CLI.chmod(0o555)
        rec['frozen_cli'] = {**pin(CLI), 'mode': '0555', 'built_from': 'target/debug/jarde-cli',
                             'cargo_artifact_fresh': artifact.get('fresh')}
        if source_pins(paths) != rec['source_manifest_before']:
            raise RuntimeError('source closure changed during CLI build')
        save()
        rec['status'] = 'old_production_reds_and_cli_observed_pending_independent_acceptance'

    except BaseException as exc:
        rec['status'] = 'capture_failed_or_expected_outcome_mismatch_raw_preserved'
        rec['error'] = f'{type(exc).__name__}: {exc}'

    finally:
        # Always issue only this exact cleanup command, even after an unexpected compile failure.
        try:
            guard.FREE_LIMIT = 0
            guard.TARGET_LIMIT = sys.maxsize
            clean = guard.run_command(len(rec['commands']) + 1, ['cargo', 'clean'], env)
            clean.update({'label': 'finally-exact-cargo-clean', 'argv_exact': ['cargo', 'clean'],
                          'cwd': str(W), 'expected_exit': 0,
                          'cleanup_only': {'exact_argv': ['cargo', 'clean']}})
            rec['commands'].append(clean)
            rec['source_manifest_after'] = source_pins(paths)
            rec['source_manifest_after_count'] = len(rec['source_manifest_after'])
            rec['source_closure_equal_after_clean'] = rec.get('source_manifest_before') == rec['source_manifest_after']
            rec['source_closure_changed_paths_initial_to_after'] = [a['path'] for a, b in zip(rec['source_manifest_initial'], rec['source_manifest_after']) if a != b]
            rec['target_absent_after_clean'] = not (W / 'target').exists()
            rec['target_bytes_after_clean'] = scan.target_bytes(W)
            rec['free_bytes_after_clean'] = shutil.disk_usage(W).free
            rec['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
            if clean.get('exit_code') != 0 or clean.get('guard_stop') is not None or not rec['target_absent_after_clean']:
                rec['status'] = 'capture_failed_cleanup_or_target_integrity'
            elif rec.get('source_manifest_before') is not None and not rec.get('source_closure_equal_after_clean'):
                rec['status'] = 'capture_failed_source_closure_changed'
            save()
        except BaseException as exc:
            rec['status'] = 'capture_failed_finalization_raw_preserved'
            rec['finalization_error'] = f'{type(exc).__name__}: {exc}'
            rec['target_absent_after_clean'] = not (W / 'target').exists()
            save()

    print(json.dumps({'status': rec['status'], 'command_count': len(rec['commands']),
                      'unit_reds_observed': bool(len(rec['commands']) >= 2 and rec['commands'][1].get('actual_tests', {}).get('summary') == {'status':'FAILED','passed':1,'failed':2,'ignored':0}),
                      'cli_red_observed': bool(len(rec['commands']) >= 3 and rec['commands'][2].get('actual_tests', {}).get('summary') == {'status':'FAILED','passed':0,'failed':1,'ignored':0}),
                      'frozen_cli': rec.get('frozen_cli')}, ensure_ascii=False))
    return 0 if rec['status'] == 'old_production_reds_and_cli_observed_pending_independent_acceptance' and len(rec['commands']) == 5 else 1


if __name__ == '__main__':
    raise SystemExit(main())
