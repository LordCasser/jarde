#!/usr/bin/env python3
"""Two-command javac name-shadowing control; preparation only until root executes."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, shutil, sys
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
W=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde'); HERE=Path(__file__).resolve().parent
OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
GUARD=OLD/'tools-prep/guard.py'; SCAN=OLD/'tools-prep/target_scan.py'; JDK=OLD/'tools/jdk-manifest.json'
JAVAC=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jdk23/jdk-23.0.1/bin/javac')
FREE=5*1024**3; TARGET=1024**3
ORIGINAL=b'class PrefixOwnerShadow {\n    static int PrefixOwnerShadow;\n    static int i;\n    static int bump() { return ++i; }\n}\n'
CANDIDATE=b'class PrefixOwnerShadow {\n    static int PrefixOwnerShadow;\n    static int i;\n    static int bump() { return ++PrefixOwnerShadow.i; }\n}\n'
def pin(p):
 p=Path(p).resolve(); d=p.read_bytes(); return {'path':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); sys.modules[name]=m; spec.loader.exec_module(m); return m
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--binding',type=Path,required=True); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args(); out=a.out.resolve(); bindpath=a.binding.resolve()
 if out.parent!=HERE or out.exists(): raise SystemExit('out must be fresh child of harness directory')
 if (W/'target').exists() or shutil.disk_usage(W).free<FREE: raise SystemExit('target must be absent and >=5 GiB free')
 binding=json.loads(bindpath.read_text()); receipt_path=Path(binding['source_receipt']['path']); receipt=json.loads(receipt_path.read_text()); src=receipt.get('source_manifest_before')
 if not src or src!=receipt.get('source_manifest_after') or not (receipt.get('target_absent') is True or receipt.get('target_absent_after_clean') is True): raise SystemExit('root receipt must bind its actual unchanged clean source list')
 if not binding.get('product_head') or not binding.get('branch'): raise SystemExit('root product head/branch binding missing')
 if not JAVAC.is_file(): raise SystemExit('pinned Java 23 compiler missing')
 jd=json.loads(JDK.read_text()); leg=next(x for x in jd['legs'] if x.get('leg')=='javac23'); jpin=leg['jdk_tools']['javac']
 if pin(JAVAC)!={k:jpin[k] for k in ('path','bytes','sha256')}: raise SystemExit('Java 23 compiler differs from manifest')
 files={'original':HERE/'original/PrefixOwnerShadow.java','candidate':HERE/'candidate/PrefixOwnerShadow.java'}
 if files['original'].read_bytes()!=ORIGINAL or files['candidate'].read_bytes()!=CANDIDATE: raise SystemExit('control source bytes changed')
 def source_pins(): return [{'path':q['path'],'bytes':pin(W/q['path'])['bytes'],'sha256':pin(W/q['path'])['sha256']} for q in src]
 if source_pins()!=src: raise SystemExit('current product source closure differs from root receipt')
 inputs=sorted({Path(__file__).resolve(),bindpath,receipt_path,GUARD,SCAN,JDK,JAVAC,*files.values(),*(W/q['path'] for q in src)})
 before=[pin(x) for x in inputs]; out.mkdir(parents=True)
 guard=load('prefix_owner_shadow_guard',GUARD); scan=load('prefix_owner_shadow_scan',SCAN)
 guard.ROOT=W; guard.OUT=out; guard.FREE_LIMIT=FREE; guard.TARGET_LIMIT=TARGET; guard.target_bytes=lambda:scan.target_bytes(W); guard.expected_test_summaries=lambda i,z:None; guard.command_stream=lambda p:pin(p); guard.ENV_VALUES={}
 env={k:v for k,v in os.environ.items() if k in ('HOME','TMPDIR','LANG','LC_ALL')}; env['PATH']='/usr/bin:/bin'
 for k in ('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','RUST_MIN_STACK','CARGO_TARGET_DIR'): env.pop(k,None)
 rec={'schema':'static-prefix-owner-shadow-control-v1','status':'running','source_count':len(src),'source_scope':'actual4902-row native source receipt; this manual javac control does not read corpus/fuzz inputs','scope':'Independent manual Java name-shadowing control only; neither original FO nor Jarde-generated source is changed or represented.','binding':binding,'source_receipt_pin':pin(receipt_path),'source_manifest_before':src,'jdk_manifest_pin':pin(JDK),'javac23_pin':pin(JAVAC),'sources':{k:pin(v) for k,v in files.items()},'inputs_before':before,'guards':{'minimum_free_bytes':FREE,'maximum_target_bytes':TARGET,'default_stack':True},'commands':[],'interpretation':'A recovered emitted owner identifier equal to an in-scope field name must not be used as the owner token; compiler rejects the hand-written ++PrefixOwnerShadow.i candidate as int cannot be dereferenced. This control does not justify global name-resolution changes or fallback to bare i.'}
 def save():
  tmp=out/'execution.json.tmp'; tmp.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n'); tmp.replace(out/'execution.json')
 save()
 try:
  for i,key in enumerate(('original','candidate'),1):
   dest=out/(key+'-classes'); dest.mkdir(); argv=[JAVAC,'--release','8','-g:none','-Xlint:-options','-d',dest,files[key]]; cmd=[str(x) for x in argv]
   row=guard.run_command(i,cmd,env); row.update({'label':'javac23-'+key,'argv_exact':cmd,'cwd':str(W),'guard_status':'stopped' if row.get('guard_stop') is not None else 'clear','expected_exit':0 if key=='original' else 1,'expected_exit_observed':row.get('exit_code')==(0 if key=='original' else 1)}); rec['commands'].append(row); save()
   if row.get('guard_stop') is not None: raise RuntimeError('guard stopped; raw streams retained')
   if not row['expected_exit_observed']: raise RuntimeError('unexpected compiler exit; raw retained')
   if key=='candidate':
    err=Path(row['streams']['stderr']['path']).read_bytes(); outbytes=Path(row['streams']['stdout']['path']).read_bytes(); row['diagnostics']={'stderr_hex':err.hex(),'stdout_hex':outbytes.hex(),'mentions_int_cannot_be_dereferenced':b'int cannot be dereferenced' in err.lower() or b'int cannot be dereferenced' in outbytes.lower()}; save()
  rec['status']='captured_manual_owner_shadow_control'
 except BaseException as e: rec['status']='capture_failed_raw_preserved'; rec['error']=f'{type(e).__name__}: {e}'
 finally:
  try:
   rec['inputs_after']=[pin(p) for p in inputs]; rec['inputs_identical']=rec['inputs_after']==before; rec['source_manifest_after']=source_pins(); rec['sources_identical']=rec['source_manifest_after']==src; rec['target_absent']=not (W/'target').exists(); rec['target_bytes_after']=scan.target_bytes(W); rec['free_bytes_after']=shutil.disk_usage(W).free; rec['command_count']=len(rec['commands'])
   if not rec['inputs_identical'] or not rec['sources_identical'] or not rec['target_absent']: rec['status']='capture_failed_input_or_target_integrity'
   save()
  except BaseException as e: rec['status']='capture_failed_finalization'; rec['finalization_error']=repr(e); save()
 print(json.dumps({'status':rec['status'],'command_count':len(rec['commands'])},ensure_ascii=False))
 return 0 if rec['status']=='captured_manual_owner_shadow_control' and all(x.get('expected_exit_observed') for x in rec['commands']) else 1
if __name__=='__main__': raise SystemExit(main())
