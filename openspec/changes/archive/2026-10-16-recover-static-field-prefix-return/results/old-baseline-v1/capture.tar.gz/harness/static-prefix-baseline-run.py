#!/usr/bin/env python3
"""Prepared 16-command static-prefix baseline replay. Root runs after binding review."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, shutil, sys, zipfile
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
W=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde'); HERE=Path(__file__).resolve().parent
FIX=W/'tests/fixtures/recover-static-field-prefix-return'
CLI=B/'jarde-cli-reference-overload-fingerprint-v2'
OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014')
GUARD=OLD/'tools-prep/guard.py'; SCAN=OLD/'tools-prep/target_scan.py'; JDK=OLD/'tools/jdk-manifest.json'
FREE=5*1024**3; TARGET=1024**3

def pin(path):
 p=Path(path).resolve(); h=hashlib.sha256(p.read_bytes()).hexdigest(); return {'path':str(p),'bytes':p.stat().st_size,'sha256':h}
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); sys.modules[name]=m; spec.loader.exec_module(m); return m
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--binding',type=Path,required=True); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args(); out=a.out.resolve(); binding_path=a.binding.resolve()
 if out.parent!=HERE or out.exists(): raise SystemExit('out must be a fresh child of harness directory')
 if (W/'target').exists() or shutil.disk_usage(W).free<FREE: raise SystemExit('target must be absent and >=5 GiB free')
 binding=json.loads(binding_path.read_text()); receipt_path=Path(binding['source_receipt']['path']); receipt=json.loads(receipt_path.read_text())
 src=receipt.get('source_manifest_before'); frozen=receipt.get('frozen_cli')
 if src!=receipt.get('source_manifest_after') or len(src or [])!=4907 or receipt.get('target_absent') is not True: raise SystemExit('source receipt is not clean/equal 4907-source binding')
 if binding.get('product_head') is None or binding.get('branch') is None: raise SystemExit('root product head/branch binding missing')
 if binding.get('frozen_cli',{}).get('sha256')!=frozen.get('sha256') or pin(CLI)!={k:frozen.get(k) for k in ('path','bytes','sha256')} or frozen.get('mode')!='0555' or CLI.stat().st_mode&0o777!=0o555: raise SystemExit('frozen CLI does not match receipt/binding')
 def frozen_source_pins(): return [{'path':q['path'],'bytes':pin(W/q['path'])['bytes'],'sha256':pin(W/q['path'])['sha256']} for q in src]
 if frozen_source_pins()!=src: raise SystemExit('current product source closure differs from frozen source receipt')
 closure=load('static_prefix_baseline_source_closure',OLD/'tools-prep/workspace_runner.py'); closure.ROOT=W
 current_paths=sorted(closure.source_paths() | {W/q['path'] for q in json.loads((W/'tests/fixtures/corpus-fingerprint.json').read_text())['files']})
 def source_pins(): return [{'path':str(p.relative_to(W)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in current_paths]
 current_before=source_pins()
 if {q['path'] for q in current_before}-{q['path'] for q in src}!={str(p.relative_to(W)) for p in FIX.rglob('*') if p.is_file()}: raise SystemExit('current closure changes exceed additive frozen fixture set')
 jd=json.loads(JDK.read_text()); legs={x['leg']:x['jdk_tools'] for x in jd['legs'] if x.get('leg') in ('javac23','javac8')}
 tools={'javac23':Path(legs['javac23']['javac']['path']),'java23':Path(legs['javac23']['java']['path']),'javac8':Path(legs['javac8']['javac']['path']),'java8':Path(legs['javac8']['java']['path'])}
 for key,path in tools.items():
  row=legs['javac23' if key.endswith('23') else 'javac8']['javac' if key.startswith('javac') else 'java']
  if pin(path)!={k:row[k] for k in ('path','bytes','sha256')}: raise SystemExit('JDK manifest pin mismatch: '+key)
 sources={'FO':FIX/'FO.java','probe':FIX/'StaticPrefixProbe.java'}
 stored={'v8':FIX/'v8/FO.class','v8_javac8':FIX/'v8-javac8/FO.class'}
 oracles={'main':FIX/'main.stdout','probe':FIX/'probe.stdout'}
 if any(not p.is_file() for p in [*sources.values(),*stored.values(),*oracles.values()]): raise SystemExit('root frozen fixture set incomplete')
 input_files=sorted(set([Path(__file__).resolve(),binding_path,receipt_path,CLI.resolve(),GUARD.resolve(),SCAN.resolve(),JDK.resolve(),*sources.values(),*stored.values(),*oracles.values(),*tools.values(),*current_paths,OLD/'tools-prep/workspace_runner.py']))
 before=[pin(p) for p in input_files]; oracle={k:p.read_bytes() for k,p in oracles.items()}; out.mkdir(parents=True)
 g=load('static_prefix_baseline_guard',GUARD); sc=load('static_prefix_baseline_scan',SCAN)
 g.ROOT=W; g.OUT=out; g.FREE_LIMIT=FREE; g.TARGET_LIMIT=TARGET; g.target_bytes=lambda:sc.target_bytes(W); g.expected_test_summaries=lambda i,z:None; g.command_stream=lambda p:pin(p); g.ENV_VALUES={}
 env={k:v for k,v in os.environ.items() if k in ('HOME','TMPDIR','LANG','LC_ALL')}; env['PATH']='/usr/bin:/bin'
 for k in ('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','RUST_MIN_STACK','CARGO_TARGET_DIR'): env.pop(k,None)
 rec={'schema':'static-prefix-apply-baseline-v1','status':'running','scope':'Frozen FO and StaticPrefixProbe baseline only; 16 commands; collection is not implementation acceptance. Exact complete report.text compilation is expected to reproduce the missing-return diagnostic.','binding':binding,'source_receipt_pin':pin(receipt_path),'frozen_cli_source_manifest_before':src,'source_manifest_before':current_before,'source_count':len(current_before),'fixture_pins':{str(k):pin(v) for k,v in {**sources,**stored,**oracles}.items()},'inputs_before':before,'guards':{'minimum_free_bytes':FREE,'maximum_target_bytes':TARGET,'default_stack':True},'tools':{k:pin(v) for k,v in tools.items()},'oracle_hex':{k:v.hex() for k,v in oracle.items()},'commands':[],'compiler_legs':{}}
 def save():
  q=out/'execution.json.tmp'; q.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n'); q.replace(out/'execution.json')
 def run(label,argv,expected):
  cmd=[str(x) for x in argv]; row=g.run_command(len(rec['commands'])+1,cmd,env); row.update({'label':label,'argv_exact':cmd,'cwd':str(W),'guard_status':'stopped' if row.get('guard_stop') is not None else 'clear','expected_exit':expected,'expected_exit_observed':row.get('exit_code')==expected}); rec['commands'].append(row); save()
  if row.get('guard_stop') is not None: raise RuntimeError('guard stopped '+label+'; raw streams retained')
  if row.get('exit_code')!=expected: raise RuntimeError('unexpected actual exit for '+label+'; raw streams retained')
  return row
 def runtime(label,java,cp,klass,oracle_key):
  r=run(label,[java,'-Xverify:all','-cp',cp,klass],0); stdout=Path(r['streams']['stdout']['path']).read_bytes(); stderr=Path(r['streams']['stderr']['path']).read_bytes(); r.update({'oracle_equal':stdout==oracle[oracle_key],'stdout_hex':stdout.hex(),'stderr_empty':not stderr,'runtime_matches_oracle':r.get('exit_code')==0 and stdout==oracle[oracle_key] and not stderr}); save(); return r
 save()
 try:
  # 2 source compiler runs; each must reproduce the pre-frozen class bytes.
  for leg in ('javac23','javac8'):
   dest=out/(leg+'-original'); dest.mkdir(); cmd=[tools[leg],'-g:none','-d',dest,sources['FO']]
   if leg=='javac23': cmd[1:1]=['--release','8','-Xlint:-options']
   else: cmd[1:1]=['-source','8','-target','8']
   row=run(leg+'-compile-original-FO',cmd,0); classfile=dest/'FO.class'
   if row.get('exit_code')==0 and (not classfile.is_file() or classfile.read_bytes()!=stored['v8' if leg=='javac23' else 'v8_javac8'].read_bytes()): raise RuntimeError(leg+' FO.class differs from frozen class')
   rec['compiler_legs'][leg]={'fo_compile':row['index'],'fo_class':pin(classfile) if classfile.exists() else None,'matches_frozen_class':classfile.exists() and classfile.read_bytes()==stored['v8' if leg=='javac23' else 'v8_javac8'].read_bytes()}
  # 2 driver builds, each against that leg's frozen-identical FO class.
  for leg in ('javac23','javac8'):
   dest=out/(leg+'-driver'); dest.mkdir(); classdir=out/(leg+'-original')
   cmd=[tools[leg],'-g:none','-classpath',classdir,'-d',dest,sources['probe']]
   if leg=='javac23': cmd[1:1]=['--release','8','-Xlint:-options']
   else: cmd[1:1]=['-source','8','-target','8']
   row=run(leg+'-compile-StaticPrefixProbe',cmd,0); rec['compiler_legs'][leg]['probe_compile']=row['index']; rec['compiler_legs'][leg]['probe_class']=pin(dest/'StaticPrefixProbe.class') if (dest/'StaticPrefixProbe.class').exists() else None
  # Build deterministic STORE jars from root-pinned classes and verify byte identity.
  for leg,key in [('javac23','v8'),('javac8','v8_javac8')]:
   jar=out/(leg+'-FO.jar')
   with zipfile.ZipFile(jar,'w',compression=zipfile.ZIP_STORED) as z:
    info=zipfile.ZipInfo('FO.class',(1980,1,1,0,0,0)); info.compress_type=zipfile.ZIP_STORED; z.writestr(info,stored[key].read_bytes())
   rec['compiler_legs'][leg]['jar']=pin(jar)
  # 8 original-class runtime checks: main and probe under both JVMs for both compiler legs.
  for leg in ('javac23','javac8'):
   jar=out/(leg+'-FO.jar'); driver=out/(leg+'-driver')
   for runtime_jdk in ('java8','java23'):
    runtime(f'{leg}-{runtime_jdk}-original-main',tools[runtime_jdk],jar,'FO','main')
    runtime(f'{leg}-{runtime_jdk}-original-probe',tools[runtime_jdk],str(driver)+os.pathsep+str(jar),'StaticPrefixProbe','probe')
  # 2 complete-class JSON CLI reports and unchanged report.text compiler attempts.
  for leg in ('javac23','javac8'):
   jar=out/(leg+'-FO.jar'); dest=out/(leg+'-report'); dest.mkdir(); classes=dest/'classes'; classes.mkdir()
   q=run(leg+'-whole-class-json-FO',[CLI,'class-source','--input',jar,'--class','FO','--policy','plain-jar','--release','8','--format','json','--evidence','all','--budget','elapsed_millis=10000'],0)
   rowinfo={'cli':q['index'],'cli_exit':q.get('exit_code')}
   try:
    doc=json.loads(Path(q['streams']['stdout']['path']).read_bytes()); text=doc['text']; generated=dest/'FO.java'; generated.write_bytes(text.encode('utf-8'))
    if generated.read_bytes()!=text.encode('utf-8'): raise ValueError('report text bytes differ after write')
    rowinfo['report_text']=pin(generated); rowinfo['method_count']=len(doc.get('methods',[]))
   except Exception as e:
    rec['compiler_legs'][leg]['report_error']=repr(e); save(); continue
   compileq=run(leg+'-javac23-exact-report-text-FO',[tools['javac23'],'--release','8','-g:none','-Xlint:-options','-classpath',classes,'-d',classes,generated],1)
   stderr=Path(compileq['streams']['stderr']['path']).read_bytes(); stdout=Path(compileq['streams']['stdout']['path']).read_bytes()
   rowinfo['report_compile']={'index':compileq['index'],'exit_code':compileq.get('exit_code'),'expected_missing_return_exit':compileq.get('exit_code')==1,'diagnostic_contains_missing_return':b'missing return' in stderr.lower() or b'missing return' in stdout.lower(),'diagnostic_hex':stderr.hex(),'classpath_excludes_original_jar':True,'class_files':[pin(x) for x in classes.rglob('*.class')]}
   rec['compiler_legs'][leg]['cli']=rowinfo; save()
  all_expected=all(r.get('expected_exit_observed') for r in rec['commands'])
  runtime_rows=[r for r in rec['commands'] if 'runtime_matches_oracle' in r]
  rec['baseline_checks']={'exact_16_commands':len(rec['commands'])==16,'all_expected_exits':all_expected,'eight_original_runtime_oracles_match':len(runtime_rows)==8 and all(r['runtime_matches_oracle'] for r in runtime_rows),'two_generated_report_compiles_show_missing_return':sum(1 for row in rec['compiler_legs'].values() if row.get('cli',{}).get('report_compile',{}).get('diagnostic_contains_missing_return'))==2,'both_compiler_classes_match_frozen':all(x.get('matches_frozen_class') is True for x in rec['compiler_legs'].values())}
  rec['status']='captured_16_command_baseline' if all(rec['baseline_checks'].values()) else 'captured_baseline_outcome_mismatch_raw_preserved'
 except BaseException as e:
  rec['status']='capture_failed_raw_preserved'; rec['error']=f'{type(e).__name__}: {e}'
 finally:
  try:
   rec['inputs_after']=[pin(p) for p in input_files]; rec['inputs_identical']=rec['inputs_after']==before; rec['source_manifest_after']=source_pins(); rec['sources_identical']=rec['source_manifest_after']==current_before; rec['frozen_cli_sources_still_identical']=frozen_source_pins()==src; rec['target_absent']=not (W/'target').exists(); rec['target_bytes_after']=sc.target_bytes(W); rec['free_bytes_after']=shutil.disk_usage(W).free; rec['command_count']=len(rec['commands'])
   if not rec['inputs_identical'] or not rec['sources_identical'] or not rec['target_absent']: rec['status']='capture_failed_input_or_target_integrity'
   save()
  except BaseException as e: rec['status']='capture_failed_finalization'; rec['finalization_error']=repr(e); save()
 print(json.dumps({'status':rec['status'],'command_count':rec.get('command_count'),'runtime_results':sum(bool(x.get('runtime_matches_oracle')) for x in rec['commands'])},ensure_ascii=False))
 return 0 if rec['status']=='captured_16_command_baseline' and rec.get('command_count')==16 else 1
if __name__=='__main__': raise SystemExit(main())
