from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=B/'CORE';W=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');O=C/'static-prefix-census-local-evidence-v1';O.mkdir(exist_ok=False)
def sha(v):return hashlib.sha256(v).hexdigest()
payload={};rows=[]
def add(name,p,group):
 p=Path(p);assert p.is_file() and not p.is_symlink();v=p.read_bytes();assert name not in payload and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
 payload[name]=v;rows.append(dict(path=name,bytes=len(v),sha256=sha(v),source_path=str(p),group=group))
groups=[('focused-native','static-prefix-reader-census-native-v1','execution.json',6),('full-generated-source','static-prefix-census-full-source-replay-v1','run-v1/execution.json',14)];cmdgroups=[];sources=[]
for label,dirname,receipt,count in groups:
 base=C/dirname;d=json.loads((base/receipt).read_text());assert len(d['commands'])==count;assert all(x['exit_code']==0 for x in d['commands']);before=d.get('source_manifest_before');after=d.get('source_manifest_after');assert before==after and len(before)==4915;sources.append(before)
 for p in sorted(base.rglob('*')):
  if p.is_file() and not p.name.endswith('.tmp'):add(label+'/'+p.relative_to(base).as_posix(),p,label)
 for command in d['commands']:
  for q in command['streams'].values():
   v=Path(q['path']).read_bytes();assert len(v)==q['bytes'] and sha(v)==q['sha256'];assert str(Path(q['path'])) in {r['source_path'] for r in rows}
 cmdgroups.append(dict(group=label,commands=count,raw_streams=2*count,all_exit_zero=True))
assert sources[0]==sources[1]
for label,rel in [('native-replay','static-prefix-reader-census-native-v1/independent-reader-census-native-replay-review-v1.json')]:
 d=json.loads((C/rel).read_text());assert not d['errors'];assert d['checks']>0
native=json.loads((C/groups[0][1]/groups[0][2]).read_text())
for label,q in native['dependencies'].items():
 p=Path(q['path']);v=p.read_bytes();assert len(v)==q['bytes'] and sha(v)==q['sha256'];add('dependencies/'+label+'/'+p.name,p,'executed_helper_or_package_metadata')
for p in sorted((W/'tests/fixtures/recover-static-field-prefix-return').rglob('*')):
 if p.is_file():add('fixture/'+p.relative_to(W/'tests/fixtures/recover-static-field-prefix-return').as_posix(),p,'unchanged_fixture')
cli=B/'jarde-cli-static-prefix-reader-census-v1';v=cli.read_bytes();assert len(v)==59699632 and sha(v)=='6e075292bf761f178858f5714b3dbbf51e57a9e711ca1d87d45e77312228db96' and cli.stat().st_mode&0o777==0o555
add('package-builder.py',Path(__file__).resolve(),'package_builder')
m=dict(schema='static-prefix-census-local-evidence-v1',scope='Accepted 052 fresh focused native and actual fresh complete generated-source replay. Ancestor a89 full local checks and 052 own CI are separate evidence.',product_head='052c82484bb20ca8b7e22ffe9943503c961280f9',frozen_cli=dict(path=str(cli),bytes=len(v),sha256=sha(v),mode='0555',inside_archive=False),source_count=4915,actual_command_groups=cmdgroups,command_count=20,command_raw_count=40,focused_totals=dict(passed=11,failed=0,ignored=2),ancestor_local_checks='See separately bound a89 local-product checks; not relabeled 052',strict='Not rerun in this focused set; own exact-head CI and ancestor local strict are separate gates',full_replay=dict(commands=14,generated_source_compiles=2,unchanged_driver_compiles=2,rebuilt_only_runtime_oracles=8,main_bytes=6,driver_bytes=60,generated_source_bytes=1617,generated_source_sha256='eabbf22187e0b3c24bb984d9496a4785acc479fe05ca9e07acf8952337e25811'),limits=['Own CI and two complete seeded workspace passes are not accepted by this local archive.','Default ignored tests were not executed by these focused/local commands.','No new dynamic deadline test; conservative source owner and pre-body commit boundaries remain as documented.','c075 and a89 ancestor local successes and failed own-CIs are preserved separately and are not relabeled 052.'],payload_count=len(rows),members=sorted(rows,key=lambda r:r['path']))
v=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode();(O/'manifest.json').write_bytes(v)
with (O/'capture.tar.gz').open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,data in sorted({**payload,'manifest.json':v}.items()):
    i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data))
with tarfile.open(O/'capture.tar.gz') as t:
 assert len(t.getmembers())==len(payload)+1
 for i in t.getmembers():assert i.isfile() and t.extractfile(i).read()=={**payload,'manifest.json':v}[i.name]
a=(O/'capture.tar.gz').read_bytes();e=dict(status='reopened_and_verified_every_member',archive=str(O/'capture.tar.gz'),bytes=len(a),sha256=sha(a),payload_count=len(rows),member_count=len(rows)+1,commands=20,command_raw_streams=40,manifest_sha256=sha(v));(O/'execution.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e))
