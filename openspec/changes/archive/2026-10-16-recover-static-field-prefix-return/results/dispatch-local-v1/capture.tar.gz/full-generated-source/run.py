#!/usr/bin/env python3
"""Replay frozen FO class reports, compile each complete generated source unchanged, then run rebuilt classes only."""
from pathlib import Path
import argparse, datetime, hashlib, importlib.util, json, os, shutil, sys, zipfile
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015'); W=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde'); H=Path(__file__).resolve().parent
OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014'); TOOLS=OLD/'tools-prep'; GUARD=TOOLS/'guard.py'; SCAN=TOOLS/'target_scan.py'; CLOSURE=TOOLS/'workspace_runner.py'; JDK=OLD/'tools/jdk-manifest.json'; FIX=W/'tests/fixtures/recover-static-field-prefix-return'
FREE=5*1024**3; TARGET=1024**3
EXPECTED_METHODS={('<init>','()V'),('bump','()I'),('evalThenFin','()I'),('main','([Ljava/lang/String;)V'),('<clinit>','()V')}
def pin(path):
 p=Path(path)
 if p.is_symlink() or not p.is_file(): raise ValueError(f'not a regular file: {p}')
 data=p.read_bytes(); return {'path':str(p.resolve()),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path)
 if s is None or s.loader is None: raise RuntimeError(f'cannot load {path}')
 m=importlib.util.module_from_spec(s); sys.modules[name]=m; s.loader.exec_module(m); return m
def source_rows(paths):
 rows=[]
 for p in sorted(paths):
  if p.is_symlink() or not p.is_file(): raise ValueError(f'missing/linked source input {p}')
  b=p.read_bytes(); rows.append({'path':str(p.relative_to(W)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 return rows
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--cli',type=Path,required=True); ap.add_argument('--source-receipt',type=Path,required=True); ap.add_argument('--product-head',required=True); ap.add_argument('--branch',required=True); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args()
 cli=a.cli.resolve(); rp=a.source_receipt.resolve(); out=a.out.resolve()
 if out.parent!=H or out.exists(): raise SystemExit('out must be a fresh direct child of harness directory')
 if (W/'target').exists(): raise SystemExit('target must be absent before replay')
 if shutil.disk_usage(W).free<FREE: raise SystemExit('requires at least 5 GiB free')
 receipt=json.loads(rp.read_text()); src0=receipt.get('source_manifest_before'); src1=receipt.get('source_manifest_after'); frozen=receipt.get('frozen_cli') or receipt.get('cli',{}).get('frozen_cli')
 if not isinstance(src0,list) or src0!=src1 or receipt.get('target_absent') is not True: raise SystemExit('source receipt must pin identical before/after source manifests and absent target')
 if not isinstance(frozen,dict) or pin(cli)!={k:frozen.get(k) for k in ('path','bytes','sha256')}: raise SystemExit('passed CLI differs from source-receipt artifact pin')
 if cli.stat().st_mode&0o777!=0o555 or frozen.get('mode')!='0555': raise SystemExit('passed CLI is not the receipt-pinned 0555 artifact')
 closure=load('static_prefix_full_replay_closure',CLOSURE); closure.ROOT=W; closure_paths=set(closure.source_paths()) | {W/x['path'] for x in json.loads((W/'tests/fixtures/corpus-fingerprint.json').read_text())['files']}; closure_rows=source_rows(closure_paths)
 if {x['path']:x for x in src0}!={x['path']:x for x in closure_rows}: raise SystemExit('current source closure differs byte-for-byte from source receipt')
 fp_path=W/'tests/fixtures/corpus-fingerprint.json'; fp=json.loads(fp_path.read_text()); corpus_paths={W/x['path'] for x in fp['files']}; union=closure_paths|corpus_paths|{fp_path}; full0=source_rows(union)
 jd=json.loads(JDK.read_text()); legs={x['leg']:x['jdk_tools'] for x in jd['legs'] if x.get('leg') in ('javac23','javac8')}
 if set(legs)!={'javac23','javac8'}: raise SystemExit('JDK manifest lacks required compiler legs')
 tools={}
 for leg,suffix in [('javac23','23'),('javac8','8')]:
  for kind in ('javac','java'):
   row=legs[leg][kind]; p=Path(row['path'])
   if pin(p)!={k:row[k] for k in ('path','bytes','sha256')}: raise SystemExit(f'JDK pin mismatch {leg}.{kind}')
   tools[kind+suffix]=p
 fixture=[FIX/'FO.java',FIX/'README.md',FIX/'StaticPrefixProbe.java',FIX/'main.stdout',FIX/'probe.stdout',FIX/'v8/FO.class',FIX/'v8-javac8/FO.class']
 if any(not p.is_file() for p in fixture): raise SystemExit('frozen fixture set incomplete')
 oracle={'main':(FIX/'main.stdout').read_bytes(),'probe':(FIX/'probe.stdout').read_bytes()}
 if oracle['main']!=b'1/100\n' or len(oracle['probe'])!=60: raise SystemExit('frozen oracle unexpected')
 input_paths=union|set(fixture)|{cli,rp,Path(__file__).resolve(),GUARD,SCAN,CLOSURE,JDK,*tools.values()}; inputs0=[pin(p) for p in sorted(input_paths)]
 out.mkdir(); g=load('static_prefix_full_replay_guard',GUARD); sc=load('static_prefix_full_replay_scan',SCAN); g.ROOT=W; g.OUT=out; g.FREE_LIMIT=FREE; g.TARGET_LIMIT=TARGET; g.target_bytes=lambda:sc.target_bytes(W); g.expected_test_summaries=lambda _i,_d:None; g.command_stream=pin; g.ENV_VALUES={}
 baseenv={'HOME':os.environ.get('HOME','/home/lordcasser'),'TMPDIR':os.environ.get('TMPDIR','/tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}
 rec={'schema':'static-prefix-full-source-replay-v1','status':'running','scope':'Two frozen class-to-CLI full-source reports; compile the complete generated FO.java from each report unchanged; compile unchanged driver against rebuilt classes only; eight rebuilt-only runtime checks. Not implementation acceptance and not a repeat of the earlier original-class runtime matrix.','binding':{'product_head':a.product_head,'branch':a.branch,'source_receipt':pin(rp),'source_receipt_cli':frozen,'passed_cli':pin(cli)},'default_stack':True,'guards':{'minimum_free_bytes':FREE,'maximum_target_bytes':TARGET,'target_absent_before':True,'default_stack_environment_removed':True},'source_receipt_manifest_count':len(src0),'source_manifest_before':full0,'source_manifest_after':None,'full_source_fingerprint_union_count':len(full0),'source_union_identical_after':None,'inputs_before':inputs0,'inputs_after':None,'inputs_identical_after':None,'fixture_pins':{str(p.relative_to(W)):pin(p) for p in fixture},'tool_pins':{k:pin(v) for k,v in tools.items()},'commands':[],'legs':{},'final_target_absent':None}
 def save():
  t=out/'execution.json.tmp'; t.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n'); t.replace(out/'execution.json')
 def run(label,argv,expected=0):
  argv=[str(x) for x in argv]; env=dict(baseenv); env.update({'PATH':'/usr/bin:/bin'}); env.pop('RUST_MIN_STACK',None); env.pop('CLASSPATH',None)
  for key,p in tools.items():
   if Path(argv[0])==p: env['JAVA_HOME']=str(p.parent.parent); env['PATH']=str(p.parent)+':/usr/bin:/bin'; break
  r=g.run_command(len(rec['commands'])+1,argv,env); r.update({'label':label,'argv_exact':argv,'cwd':str(W),'expected_exit':expected,'expected_exit_observed':r.get('exit_code')==expected,'guard_status':'stopped' if r.get('guard_stop') is not None else 'clear'}); rec['commands'].append(r); save()
  if r.get('guard_stop') is not None: raise RuntimeError(f'{label}: guard stopped; raw preserved')
  if r.get('exit_code')!=expected: raise RuntimeError(f'{label}: expected exit {expected}, observed {r.get("exit_code")}; raw preserved')
  return r
 def stream(r,k): return Path(r['streams'][k]['path']).read_bytes()
 def frozen_jar(leg):
  c=FIX/('v8/FO.class' if leg=='javac23' else 'v8-javac8/FO.class'); j=out/f'{leg}-frozen-FO.jar'
  with zipfile.ZipFile(j,'w',compression=zipfile.ZIP_STORED) as z:
   i=zipfile.ZipInfo('FO.class',(1980,1,1,0,0,0)); i.compress_type=zipfile.ZIP_STORED; z.writestr(i,c.read_bytes())
  return j
 save()
 try:
  # Commands 1–2: full source report for each pinned original class.
  for leg in ('javac23','javac8'):
   jar=frozen_jar(leg); r=run(f'{leg}-frozen-class-full-report-json',[cli,'class-source','--input',jar,'--class','FO','--policy','plain-jar','--release','8','--format','json','--evidence','all','--budget','elapsed_millis=10000'])
   doc=json.loads(stream(r,'stdout')); methods=doc.get('methods',[]); observed={(m.get('item',{}).get('name',{}).get('escaped'),m.get('item',{}).get('descriptor',{}).get('escaped')) for m in methods}; recovered=all(m.get('outcome',{}).get('kind')=='recovered' for m in methods)
   if len(methods)!=5 or observed!=EXPECTED_METHODS or not recovered: raise RuntimeError(f'{leg}: full report did not retain all five recovered methods: {sorted(observed)}')
   text=doc.get('text')
   if not isinstance(text,str): raise RuntimeError(f'{leg}: complete report.text absent')
   source_dir=out/f'{leg}-complete-source'; source_dir.mkdir(); tf=source_dir/'FO.java'; tf.write_bytes(text.encode('utf-8'))
   r['report_evidence']={'document_outcome':doc.get('outcome'),'method_count':len(methods),'methods':[{'name':n,'descriptor':d,'outcome':'recovered'} for n,d in sorted(observed)],'all_expected_methods_recovered':True,'report_text_file':pin(tf),'report_text_utf8_exact':tf.read_bytes()==text.encode('utf-8'),'full_json_stdout_pin':r['streams']['stdout']}; rec['legs'][leg]={'frozen_class':pin(FIX/('v8/FO.class' if leg=='javac23' else 'v8-javac8/FO.class')),'frozen_jar':pin(jar),'full_report':r['report_evidence']}; save()
  # Commands 3–4: compile the exact complete CLI report.text, without source repair.
  for leg in ('javac23','javac8'):
   dest=out/f'{leg}-rebuilt-FO'; dest.mkdir(); empty_source=out/f'{leg}-empty-sourcepath'; empty_source.mkdir()
   generated=Path(rec['legs'][leg]['full_report']['report_text_file']['path'])
   before=pin(generated)
   argv=([tools['javac23'],'--release','8','-Xlint:-options','-g:none','-classpath',dest,'-sourcepath',empty_source,'-d',dest,generated] if leg=='javac23' else [tools['javac8'],'-source','8','-target','8','-g:none','-classpath',dest,'-sourcepath',empty_source,'-d',dest,generated])
   r=run(f'{leg}-compile-exact-complete-generated-FO-source',argv); c=dest/'FO.class'
   if not c.is_file() or pin(generated)!=before: raise RuntimeError(f'{leg}: generated class missing or generated source changed')
   rec['legs'][leg]['rebuilt_class']=pin(c); rec['legs'][leg]['generated_source_before_compile']=before; rec['legs'][leg]['generated_source_after_compile']=pin(generated); rec['legs'][leg]['fo_compile_command']=r['index']; rec['legs'][leg]['compile_classpath']=[str(dest)]; rec['legs'][leg]['sourcepath']=[str(empty_source)]; save()
  # Commands 5–6: untouched driver, compiled against rebuilt FO only.
  for leg in ('javac23','javac8'):
   rebuilt=out/f'{leg}-rebuilt-FO'; dest=out/f'{leg}-rebuilt-driver'; dest.mkdir()
   argv=([tools['javac23'],'--release','8','-Xlint:-options','-g:none','-classpath',rebuilt,'-d',dest,FIX/'StaticPrefixProbe.java'] if leg=='javac23' else [tools['javac8'],'-source','8','-target','8','-g:none','-classpath',rebuilt,'-d',dest,FIX/'StaticPrefixProbe.java'])
   r=run(f'{leg}-compile-unmodified-driver-against-rebuilt-only',argv); c=dest/'StaticPrefixProbe.class'
   if not c.is_file(): raise RuntimeError(f'{leg}: driver class missing')
   rec['legs'][leg]['driver_command']=r['index']; rec['legs'][leg]['driver_class']=pin(c); rec['legs'][leg]['driver_compile_classpath']=[str(rebuilt)]; save()
  # Commands 7–14: both rebuilt compiler outputs on Java 8/23, rebuilt-only classpaths.
  for compiler in ('javac23','javac8'):
   rebuilt=out/f'{compiler}-rebuilt-FO'; driver=out/f'{compiler}-rebuilt-driver'
   for runtime in ('java8','java23'):
    cp=str(rebuilt); r=run(f'{compiler}-{runtime}-rebuilt-main',[tools[runtime],'-Xverify:all','-cp',cp,'FO']); actual=stream(r,'stdout'); err=stream(r,'stderr'); r['runtime_check']={'classpath':[cp],'uses_rebuilt_only':True,'expected_stdout_hex':oracle['main'].hex(),'actual_stdout_hex':actual.hex(),'stdout_matches_frozen_oracle':actual==oracle['main'],'stderr_empty':err==b''}
    if actual!=oracle['main'] or err: raise RuntimeError(f'{compiler}-{runtime}: main differs from frozen oracle')
    save(); cp2=os.pathsep.join((str(driver),str(rebuilt))); r=run(f'{compiler}-{runtime}-rebuilt-unmodified-probe',[tools[runtime],'-Xverify:all','-cp',cp2,'StaticPrefixProbe']); actual=stream(r,'stdout'); err=stream(r,'stderr'); r['runtime_check']={'classpath':[str(driver),str(rebuilt)],'uses_rebuilt_only':True,'expected_stdout_hex':oracle['probe'].hex(),'actual_stdout_hex':actual.hex(),'stdout_matches_frozen_oracle':actual==oracle['probe'],'stderr_empty':err==b''}
    if actual!=oracle['probe'] or err: raise RuntimeError(f'{compiler}-{runtime}: driver differs from frozen oracle')
    save()
  if len(rec['commands'])!=14: raise RuntimeError(f'expected 14 commands, observed {len(rec["commands"])}')
  rec['status']='captured_14_command_full_source_replay'; rec['checks']={'frozen_class_cli_reports':2,'all_five_methods_recovered_each_report':True,'exact_report_text_preserved_each_leg':True,'complete_generated_fo_source_compiles':2,'driver_compiles_against_rebuilt_only':2,'rebuilt_only_runtime_commands':8,'runtime_oracles_exact':True}
 except BaseException as e: rec['status']='capture_failed_or_behavior_mismatch_raw_preserved'; rec['error']=f'{type(e).__name__}: {e}'
 finally:
  try:
   rec['generated_sources_after']={leg:pin(Path(data['full_report']['report_text_file']['path'])) for leg,data in rec['legs'].items() if 'full_report' in data}; rec['generated_sources_unchanged']=all(row==rec['legs'][leg]['full_report']['report_text_file'] for leg,row in rec['generated_sources_after'].items()); rec['source_manifest_after']=source_rows(union); rec['source_union_identical_after']=rec['source_manifest_after']==full0; rec['inputs_after']=[pin(p) for p in sorted(input_paths)]; rec['inputs_identical_after']=rec['inputs_after']==inputs0; rec['final_target_absent']=not (W/'target').exists(); rec['target_bytes_after']=sc.target_bytes(W); rec['free_bytes_after']=shutil.disk_usage(W).free
   if not rec['source_union_identical_after'] or not rec['inputs_identical_after'] or not rec['final_target_absent'] or not rec['generated_sources_unchanged']: rec['status']='capture_failed_input_or_target_integrity'
   rec['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat(); save()
  except BaseException as e: rec['status']='capture_failed_finalization_raw_preserved'; rec['finalization_error']=repr(e); save()
 print(json.dumps({'status':rec['status'],'command_count':len(rec['commands']),'checks':rec.get('checks'),'error':rec.get('error')},ensure_ascii=False)); return 0 if rec['status']=='captured_14_command_full_source_replay' and len(rec['commands'])==14 else 1
if __name__=='__main__': raise SystemExit(main())
