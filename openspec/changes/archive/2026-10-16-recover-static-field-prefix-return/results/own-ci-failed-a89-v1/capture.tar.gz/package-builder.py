from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,zipfile
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=B/'CORE';CAP=B/'own-ci-static-prefix-dispatch-root-v1';O=C/'static-prefix-failed-own-ci-a89-evidence-v1';O.mkdir(exist_ok=False)
def sha(v):return hashlib.sha256(v).hexdigest()
d=json.loads((CAP/'execution.json').read_text());assert d['product_sha']=='a89d423c9a6e5d62ceb3f8185a818ebe3d67a17b' and d['run_id']==38841427486 and d['run_status']=='completed' and d['conclusion']=='failure';payload={};rows=[]
def add(name,p,group):
 p=Path(p);assert p.is_file() and not p.is_symlink();v=p.read_bytes();assert name not in payload and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts;payload[name]=v;rows.append(dict(path=name,bytes=len(v),sha256=sha(v),source_path=str(p),group=group))
for p in sorted(CAP.rglob('*')):
 if p.is_file():add('capture/'+p.relative_to(CAP).as_posix(),p,'original_terminal_capture')
for i,obs in enumerate(d['observations']):
 assert obs['exit_code']==0
 for q in obs['streams'].values():
  v=Path(q['path']).read_bytes();assert len(v)==q['bytes'] and sha(v)==q['sha256'];assert str(Path(q['path'])) in {r['source_path'] for r in rows}
assert len(d['observations'])==91
for p in sorted((B/'own-ci-static-prefix-dispatch-root-launch-v1').iterdir()):
 if p.is_file():add('capture-launch/'+p.name,p,'actual_capture_dispatch')
add('independent-failure-audit.json',C/'own-ci-static-prefix-dispatch-failure-audit-v1.json','failure_audit_not_acceptance')
add('capture-runner.py',B/'capture_product_ci_v3.py','executed_capture_runner')
for n in ['source-head-binding.json','source-head-tree.raw','source-head-tree.argv.json']:add('source-lineage/'+n,C/'static-prefix-dispatch-fixed-source-replay-v1'/n,'actual_source_binding')
add('source-lineage/native-execution.json',C/'static-prefix-candidate-dispatch-fix-v1/execution.json','prior_build_reference_not_this_ci_execution')
add('package-builder.py',Path(__file__).resolve(),'package_builder')
with zipfile.ZipFile(CAP/'logs.zip') as z:
 names=z.namelist();assert len(names)==len(set(names))==45 and z.testzip() is None
 for n in names:assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
m=dict(schema='static-prefix-failed-own-ci-a89-evidence-v1',status='packaged_actual_failed_ci_not_success',product_head=d['product_sha'],run_id=d['run_id'],conclusion='failure',api_observations=91,api_raw_streams=182,jobs=4,successful_jobs=3,failed_job='stable / test and specification',failed_step='Run workspace tests with two fixed independent seeds (pass 1)',failed_test='classfile::tests::repository_class_fixtures_validate_without_false_target_rejections',actual_population=[1175,5259,523,3445,10],pinned_population=[1173,5249,521,3445,10],actual_first_seed=dict(all_summaries=366,passed=3627,failed=1,ignored=98),new_prefix_named_gates='all seven reached and explicitly ok on first seed only',skipped='Second seed and subsequent stable JDK/examples/tree/OpenSpec steps skipped; no global CI success claim.',zip_members=45,original_zip=d['logs'],payload_count=len(rows),members=sorted(rows,key=lambda r:r['path']))
v=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode();(O/'manifest.json').write_bytes(v)
with (O/'capture.tar.gz').open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,data in sorted({**payload,'manifest.json':v}.items()):
    i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data))
with tarfile.open(O/'capture.tar.gz') as t:
 assert len(t.getmembers())==len(payload)+1
 for i in t.getmembers():assert i.isfile() and t.extractfile(i).read()=={**payload,'manifest.json':v}[i.name]
a=(O/'capture.tar.gz').read_bytes();e=dict(status='reopened_and_verified_failed_ci_every_member',archive=str(O/'capture.tar.gz'),bytes=len(a),sha256=sha(a),payload_count=len(rows),member_count=len(rows)+1,manifest_sha256=sha(v));(O/'execution.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e))
