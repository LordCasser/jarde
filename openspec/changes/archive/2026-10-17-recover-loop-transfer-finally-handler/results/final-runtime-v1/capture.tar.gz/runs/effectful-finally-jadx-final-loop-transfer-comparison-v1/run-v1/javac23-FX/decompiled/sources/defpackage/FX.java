package defpackage;

/* JADX INFO: loaded from: FX.jar:FX.class */
public class FX {
    static int finContinue(int[] iArr) {
        int i = 0;
        for (int i2 : iArr) {
            if (i2 != 3) {
                i += i2;
            }
            try {
                i += 100;
            } catch (Throwable th) {
                int i3 = i + 100;
                throw th;
            }
        }
        return i;
    }

    static int finReturn(int[] iArr) {
        int length = iArr.length;
        for (int i = 0; i < length; i++) {
            int i2 = iArr[i];
            if (i2 == 3) {
                try {
                    int iC0 = c0(i2);
                    return iC0;
                } finally {
                    System.out.println("fin:" + i2);
                }
            }
            System.out.println("fin:" + i2);
        }
        return -1;
    }

    static int c0(int i) {
        return i * 1000;
    }

    static int finBreak(int[] iArr) {
        int i = 0;
        for (int i2 : iArr) {
            if (i2 == 3) {
                i += 100;
                break;
            }
            try {
                i = i + i2 + 100;
            } catch (Throwable th) {
                int i3 = i + 100;
                throw th;
            }
            int i4 = i + 100;
            throw th;
        }
        return i;
    }

    public static void main(String[] strArr) {
        System.out.println("" + finContinue(new int[]{3, 4}) + "/" + finReturn(new int[]{1, 3, 5}) + "/" + finBreak(new int[]{3, 4}));
    }
}
