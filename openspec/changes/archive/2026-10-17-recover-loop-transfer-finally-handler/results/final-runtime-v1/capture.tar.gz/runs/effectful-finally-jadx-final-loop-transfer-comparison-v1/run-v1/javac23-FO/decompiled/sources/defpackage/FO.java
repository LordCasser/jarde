package defpackage;

/* JADX INFO: loaded from: FO.jar:FO.class */
public class FO {
    static int i = 0;

    static int bump() {
        int i2 = i + 1;
        i = i2;
        return i2;
    }

    static int evalThenFin() {
        try {
            int i2 = 100;
            return bump();
        } finally {
            i = 100;
        }
    }

    public static void main(String[] strArr) {
        System.out.println(evalThenFin() + "/" + i);
    }
}
