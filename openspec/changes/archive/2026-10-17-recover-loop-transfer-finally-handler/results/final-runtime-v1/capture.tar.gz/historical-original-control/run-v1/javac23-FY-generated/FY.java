// jarde: presentation of `FY` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class FY extends java.lang.Object {
    public FY() {
        // @method <init>()V
        // @declaration a constructor of `FY`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int emptyFin(int[] arg0) {
        // @method emptyFin([I)I
        // @declaration a static method of `FY`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int[] local1;
        local1 = arg0;
        for (int local4 : local1) {
            if (local4 == 3) {
                return local4 * 1000;
            }
        }
        return -1;
    }

    static int noCall(int[] arg0) {
        // jarde: not recovered: the recovery run for `noCall([I)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method noCall([I)I
        // @declaration a static method of `FY`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 10 16 28 40 46 54 60
        // local 1 crosses a quoted fallback region; its assignments and consumers cannot be presented as one lexically bound definition-use slice
    }

    static int loopless(int[] arg0) {
        // jarde: not recovered: the recovery run for `loopless([I)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method loopless([I)I
        // @declaration a static method of `FY`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 2
        // BCI 37: the exceptional path repeats code the normal path also runs — the `finally` copy javac emits for a `finally` clause; this candidate lacks the complete straight-body, copy, range, and ownership proof needed to merge them into one `finally`
        // @bytecode 5 6 7 8 9 12 15 16 19 21 24 25 26 29 31 34 37 38 41 43 46 47 48 49
        // 4 live block(s) are reachable only through edges the normal-flow view leaves out: [5, 26, 37, 12]
    }

    public static void main(java.lang.String[] arg0) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `FY`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.io.PrintStream saved0 = java.lang.System.out;
        java.lang.StringBuilder saved1 = new java.lang.StringBuilder().append("");
        java.lang.StringBuilder saved2 = saved1.append(emptyFin(new int[]{1, 3})).append("/");
        java.lang.StringBuilder saved3 = saved2.append(noCall(new int[]{1, 3})).append("/");
        saved0.println((java.lang.String) saved3.append(loopless(new int[]{3})).toString());
        return;
    }
}
