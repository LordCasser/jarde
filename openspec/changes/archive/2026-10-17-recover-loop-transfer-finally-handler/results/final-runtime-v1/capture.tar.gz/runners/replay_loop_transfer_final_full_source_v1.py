from pathlib import Path
import json,hashlib,importlib.util,os,shutil,zipfile,datetime
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');W=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');D=B/'CORE/loop-transfer-finally-final-full-source-v1';D.mkdir(exist_ok=False);O=D/'run-v1';OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');F=W/'tests/fixtures/recover-loop-transfer-finally-handler';CLI=B/'jarde-cli-loop-transfer-complete-local-native-v1'
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();v=p.read_bytes();return dict(path=str(p),bytes=len(v),sha256=hashlib.sha256(v).hexdigest())
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
assert not O.exists() and not (W/'target').exists() and shutil.disk_usage(W).free>=5*1024**3
native=B/'CORE/loop-transfer-finally-complete-local-native-v1/execution.json';n=json.loads(native.read_text());assert n['source_manifest_before']==n['source_manifest_after'] and n['target_absent'];assert pin(CLI)=={k:n['frozen_cli'][k] for k in ['path','bytes','sha256']}
closure=load('loopless_control_closure',OLD/'tools-prep/workspace_runner.py');closure.ROOT=W;paths=set(closure.source_paths())|{W/x['path'] for x in json.loads((W/'tests/fixtures/corpus-fingerprint.json').read_text())['files']}
def sources():return [dict(path=str(p.relative_to(W)),bytes=p.stat().st_size,sha256=pin(p)['sha256']) for p in sorted(paths)]
before=sources();assert before==n['source_manifest_before'];jd=json.loads((OLD/'tools/jdk-manifest.json').read_text());tools={}
for leg in jd['legs']:
 if leg.get('leg') in ['javac23','javac8']:
  for key,row in leg['jdk_tools'].items():
   if key in ['javac','java']:
    assert pin(row['path'])=={k:row[k] for k in ['path','bytes','sha256']};tools[leg['leg']+'/'+key]=Path(row['path'])
assert len(tools)==4
inputs={Path("/usr/bin/timeout"),CLI,native,Path(__file__).resolve(),OLD/'tools/jdk-manifest.json',OLD/'tools-prep/guard.py',OLD/'tools-prep/target_scan.py',OLD/'tools-prep/workspace_runner.py',*[p for p in F.rglob('*') if p.is_file()],*tools.values()};ip=[pin(p) for p in sorted(inputs)];O.mkdir();g=load('loopless_control_guard',OLD/'tools-prep/guard.py');scan=load('loopless_control_scan',OLD/'tools-prep/target_scan.py');g.ROOT=W;g.OUT=O;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.target_bytes=lambda:scan.target_bytes(W);g.expected_test_summaries=lambda _i,_d:None;g.command_stream=pin;g.ENV_VALUES={}
r=dict(schema='loop-transfer-finally-final-full-source-v1',status='running',scope='Complete unchanged generated class recompiled on real javac8 and javac23 release8, unchanged driver compiled against rebuilt classes only, two runtimes; final full-source replay of the locally validated product; exact product-head own CI remains separately required.',native_receipt=pin(native),frozen_cli=n['frozen_cli'],source_manifest_before=before,inputs_before=ip,default_stack=True,guards=dict(free_bytes=5*1024**3,target_bytes=1024**3),commands=[],legs={})
def save():(O/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
def run(label,args,expected=0):
 args=[str(x) for x in args];env={'HOME':'/home/lordcasser','PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}
 tool=next((Path(arg) for arg in args if Path(arg) in tools.values()),None)
 if tool is not None:env.update(JAVA_HOME=str(tool.parent.parent),PATH=str(tool.parent)+':/usr/bin:/bin')
 q=g.run_command(len(r['commands'])+1,args,env);q.update(label=label,expected_exit=expected);r['commands'].append(q);save();assert q['exit_code']==expected and q['guard_stop'] is None;return q
save()
try:
 for leg,sub in [('javac23','v8'),('javac8','v8-javac8')]:
  c=F/sub/'LoopTransferFinally.class';jar=O/(leg+'-frozen.jar')
  with zipfile.ZipFile(jar,'w',compression=zipfile.ZIP_STORED) as z:
   i=zipfile.ZipInfo('LoopTransferFinally.class',(1980,1,1,0,0,0));z.writestr(i,c.read_bytes())
  q=run(leg+'-whole-class-json',[CLI,'class-source','--input',jar,'--class','LoopTransferFinally','--policy','plain-jar','--release','8','--format','json','--evidence','all','--budget','elapsed_millis=10000'])
  doc=json.loads(Path(q['streams']['stdout']['path']).read_text());assert len(doc['methods'])==3
  methods={m['item']['name']['escaped']:m for m in doc['methods']};assert set(methods)=={'<init>','finContinue','finBreak'}
  for name in ['finContinue','finBreak']:
   report=methods[name]['outcome']['report'];assert report['representation']=='java' and report['quality']=='structured' and not report['fallbacks'];assert ('break;' in report['text'])==(name=='finBreak')
   segments=report['source_map']['segments'];actual={o['bci'] for segment in segments for o in [segment['origin']['primary'],*segment['origin']['derived']]};assert set([0,1,2,3,4,5,6,7,8,10,12,13,16,17,19,20,22,24,25,28,31,34,35,37,38,39,42,45,47,50,52,53,56,59,60])<=actual
   assert all(o['method']==methods[name]['item']['identity'] for segment in segments for o in [segment['origin']['primary'],*segment['origin']['derived']])
  dest=O/(leg+'-generated');dest.mkdir();source=dest/'LoopTransferFinally.java';source.write_bytes(doc['text'].encode());assert '@bytecode' not in doc['text']
  rebuilt=dest/'classes';rebuilt.mkdir();empty=dest/'empty-sourcepath';empty.mkdir();driver=dest/'driver';driver.mkdir()
  flags=['--release','8','-Xlint:-options'] if leg=='javac23' else ['-source','8','-target','8'];javac=tools[leg+'/javac']
  run(leg+'-compile-exact-complete-generated',[javac,*flags,'-g:none','-classpath',rebuilt,'-sourcepath',empty,'-d',rebuilt,source])
  run(leg+'-compile-frozen-driver-rebuilt-only',[javac,*flags,'-g:none','-classpath',rebuilt,'-sourcepath',empty,'-d',driver,F/'LoopTransferFinallyProbe.java'])
  for rt in ['javac8/java','javac23/java']:
   q=run(leg+'-'+rt.replace('/','-')+'-rebuilt-probe',['/usr/bin/timeout','--kill-after=5s','30s',tools[rt],'-Xverify:all','-cp',os.pathsep.join([str(driver),str(rebuilt)]),'LoopTransferFinallyProbe']);assert Path(q['streams']['stdout']['path']).read_bytes()==(F/'probe.stdout').read_bytes();assert not Path(q['streams']['stderr']['path']).read_bytes();q['oracle_exact']=True;save()
  assert source.read_bytes()==doc['text'].encode()
  r['legs'][leg]=dict(original_class=pin(c),frozen_jar=pin(jar),generated_source=pin(source),rebuilt_classes=[pin(p) for p in sorted(rebuilt.glob('*.class'))],driver_classes=[pin(p) for p in sorted(driver.glob('*.class'))],method_count=3,methods=[dict(item=m['item'],outcome=m['outcome']) for m in doc['methods']],generated_compile_exit=0,rebuilt_runtime_commands=2);save()
 assert len(r['commands'])==10;r['status']='captured_ten_command_complete_generated_source_and_rebuilt_oracle_success'
except BaseException as e:r['status']='failed_raw_preserved';r['error']=repr(e)
finally:
 r.update(source_manifest_after=sources(),inputs_after=[pin(p) for p in sorted(inputs)],target_absent=not (W/'target').exists(),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());r['sources_identical']=r['source_manifest_after']==before;r['inputs_identical']=r['inputs_after']==ip
 if not r['sources_identical'] or not r['inputs_identical'] or not r['target_absent']:r['status']='failed_integrity'
 save()
print(r['status'],len(r['commands']));raise SystemExit(0 if r['status']=='captured_ten_command_complete_generated_source_and_rebuilt_oracle_success' else 1)
