from pathlib import Path
import json,hashlib,importlib.util,os,shutil,zipfile,datetime,subprocess,time,signal
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');W=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');D=B/'CORE/loop-transfer-finally-independent-control-v1';O=D/'run-v1';OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');F=D/'fixture';DER=D/'derivation-prepared-only.json';CLI=B/'jarde-cli-call-return-finally-final-test-assertions-native-v1';NATIVE=B/'CORE/call-return-finally-final-test-assertions-native-v1/execution.json';TIMEOUT=Path('/usr/bin/timeout')
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();v=p.read_bytes();return dict(path=str(p),bytes=len(v),sha256=hashlib.sha256(v).hexdigest())
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
assert not O.exists() and not (W/'target').exists() and shutil.disk_usage(W).free>=5*1024**3
native=json.loads(NATIVE.read_text());der=json.loads(DER.read_text());assert native['source_manifest_before']==native['source_manifest_after'] and native['target_absent'] and len(native['source_manifest_before'])==4936
assert der['status']=='prepared_only_no_native_commands_yet'
assert pin(CLI)=={k:native['frozen_cli'][k] for k in ['path','bytes','sha256']}
original=Path(der['original_source']['path']);assert pin(original)=={k:der['original_source'][k] for k in ['path','bytes','sha256']}
assert pin(F/'LoopTransferFinally.java')=={k:der['derived_source'][k] for k in ['path','bytes','sha256']}
assert pin(F/'LoopTransferFinallyProbe.java')=={k:der['driver'][k] for k in ['path','bytes','sha256']}
assert pin(F/'probe.stdout')=={k:der['oracle'][k] for k in ['path','bytes','sha256']}
derived=(F/'LoopTransferFinally.java').read_text();assert all(row['exact_original_text'] in derived for row in der['method_slices'])
closure=load('loop_control_closure',OLD/'tools-prep/workspace_runner.py');closure.ROOT=W;paths=set(closure.source_paths())|{W/x['path'] for x in json.loads((W/'tests/fixtures/corpus-fingerprint.json').read_text())['files']}
def sources():return [dict(path=str(p.relative_to(W)),bytes=p.stat().st_size,sha256=pin(p)['sha256']) for p in sorted(paths)]
before=sources();assert before==native['source_manifest_before']
jd=json.loads((OLD/'tools/jdk-manifest.json').read_text());tools={}
for leg in jd['legs']:
 if leg.get('leg') in ['javac23','javac8']:
  for key,row in leg['jdk_tools'].items():
   if key in ['javac','java']:
    assert pin(row['path'])=={k:row[k] for k in ['path','bytes','sha256']};tools[leg['leg']+'/'+key]=Path(row['path'])
assert len(tools)==4
inputs={CLI,NATIVE,Path(__file__).resolve(),DER,original,OLD/'tools/jdk-manifest.json',OLD/'tools-prep/guard.py',OLD/'tools-prep/target_scan.py',OLD/'tools-prep/workspace_runner.py',TIMEOUT,*F.iterdir(),*tools.values()};ip=[pin(p) for p in sorted(inputs)]
O.mkdir();g=load('loop_control_guard',OLD/'tools-prep/guard.py');scan=load('loop_control_scan',OLD/'tools-prep/target_scan.py');g.ROOT=W;g.OUT=O;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.target_bytes=lambda:scan.target_bytes(W);g.expected_test_summaries=lambda _i,_d:None;g.command_stream=pin;g.ENV_VALUES={}
r=dict(schema='loop-transfer-finally-independent-control-v1',status='running',scope='Original-class compile and 11-observation runtime oracle across JDK 8/23; whole-class JSON CLI on both original classfiles; complete generated source is expected to compile while retaining method-quality fallback and uncovered BCI 45. This is a control, not a recovered-source runtime or recovery claim.',product_head='02de294f7af2d0798e33d52ce5474e60efe17b03',native_receipt=pin(NATIVE),frozen_cli=native['frozen_cli'],source_manifest_before=before,inputs_before=ip,default_stack=True,guards=dict(free_bytes=5*1024**3,target_bytes=1024**3),runtime_timeout=dict(wrapper=str(TIMEOUT),seconds=30,kill_grace_seconds=5),commands=[],legs={})
def save():(O/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
def run(label,args,expected=0,runtime=False):
 args=[str(x) for x in args];env={'HOME':'/home/lordcasser','PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}
 actual_jdk=next((p for p in tools.values() if str(p) in args),None)
 if actual_jdk is not None:env.update(JAVA_HOME=str(actual_jdk.parent.parent),PATH=str(actual_jdk.parent)+':/usr/bin:/bin')
 argv=([TIMEOUT,'--signal=TERM','--kill-after=5s','30s',*args] if runtime else args)
 q=g.run_command(len(r['commands'])+1,argv,env);q.update(label=label,expected_exit=expected,timeout_policy={'seconds':30,'kill_grace_seconds':5,'applies':runtime});r['commands'].append(q);save();assert q['exit_code']==expected and q['guard_stop'] is None;return q
save()
try:
 for leg in ['javac23','javac8']:
  orig=O/(leg+'-original');orig.mkdir();driver=O/(leg+'-driver');driver.mkdir();empty=O/(leg+'-empty-sourcepath');empty.mkdir();flags=['--release','8','-Xlint:-options'] if leg=='javac23' else ['-source','8','-target','8'];javac=tools[leg+'/javac']
  run(leg+'-compile-whole-original',[javac,*flags,'-g:none','-classpath',orig,'-sourcepath',empty,'-d',orig,F/'LoopTransferFinally.java'])
  run(leg+'-compile-frozen-driver',[javac,*flags,'-g:none','-classpath',orig,'-sourcepath',empty,'-d',driver,F/'LoopTransferFinallyProbe.java'])
  for rt in ['javac8/java','javac23/java']:
   q=run(leg+'-'+rt.replace('/','-')+'-original-probe',[tools[rt],'-Xverify:all','-cp',os.pathsep.join([str(driver),str(orig)]),'LoopTransferFinallyProbe'],runtime=True);assert Path(q['streams']['stdout']['path']).read_bytes()==(F/'probe.stdout').read_bytes();assert not Path(q['streams']['stderr']['path']).read_bytes();q['oracle_exact']=True;save()
  jar=O/(leg+'-original.jar')
  with zipfile.ZipFile(jar,'w',compression=zipfile.ZIP_STORED) as z:
   i=zipfile.ZipInfo('LoopTransferFinally.class',(1980,1,1,0,0,0));z.writestr(i,(orig/'LoopTransferFinally.class').read_bytes())
  q=run(leg+'-whole-class-json',[CLI,'class-source','--input',jar,'--class','LoopTransferFinally','--policy','plain-jar','--release','8','--format','json','--evidence','all','--budget','elapsed_millis=10000']);doc=json.loads(Path(q['streams']['stdout']['path']).read_text());assert len(doc['methods'])==3
  methods={m['item']['name']['escaped']:m for m in doc['methods']};assert set(methods)=={'<init>','finContinue','finBreak'}
  for name in ['finContinue','finBreak']:
   text=methods[name]['text'];assert '@bytecode 45' in text and 'presentation is not claimed to compile' in text
  dest=O/(leg+'-generated');dest.mkdir();source=dest/'LoopTransferFinally.java';source.write_bytes(doc['text'].encode());rebuilt=dest/'classes';rebuilt.mkdir();q=run(leg+'-compile-complete-generated-source',[javac,*flags,'-g:none','-classpath',rebuilt,'-sourcepath',empty,'-d',rebuilt,source],0);assert source.read_bytes()==doc['text'].encode()
  r['legs'][leg]=dict(original_class=pin(orig/'LoopTransferFinally.class'),original_jar=pin(jar),original_driver_classes=[pin(p) for p in sorted(driver.glob('*.class'))],generated_source=pin(source),method_count=len(doc['methods']),methods=[dict(name=m['item']['name']['escaped'],outcome=m.get('outcome'),has_bci45='@bytecode 45' in m.get('text','')) for m in doc['methods']],generated_compile_exit=q['exit_code'],rebuilt_runtime_commands=0,interpretation='Successful javac only establishes source acceptance; bytecode-only BCI 45 remains uncovered in both loop methods.');save()
 assert len(r['commands'])==12;r['status']='captured_12_command_original_oracle_and_quality_control'
except BaseException as e:r['status']='failed_raw_preserved';r['error']=repr(e)
finally:
 r.update(source_manifest_after=sources(),inputs_after=[pin(p) for p in sorted(inputs)],target_absent=not (W/'target').exists(),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());r['sources_identical']=r['source_manifest_after']==before;r['inputs_identical']=r['inputs_after']==ip
 if not r['sources_identical'] or not r['inputs_identical'] or not r['target_absent']:r['status']='failed_integrity'
 save()
print(r['status'],len(r['commands']));raise SystemExit(0 if r['status']=='captured_12_command_original_oracle_and_quality_control' else 1)
