// jarde: presentation of `LoopTransferFinally` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class LoopTransferFinally extends java.lang.Object {
    public LoopTransferFinally() {
        // @method <init>()V
        // @declaration a constructor of `LoopTransferFinally`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int finContinue(int[] arg0) {
        // @method finContinue([I)I
        // @declaration a static method of `LoopTransferFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int local1;
        int[] local2;
        int local3;
        int local4;
        local1 = 0;
        local2 = arg0;
        local3 = local2.length;
        for (local4 = 0; local4 < local3; local4 = local4 + 1) {
            int local5 = local2[local4];
            if (local5 == 3) {
                local1 = local1 + 100;
            } else {
                local1 = local1 + local5;
                local1 = local1 + 100;
            }
        }
        return local1;
        // @bytecode 45 47 50 52
        // 1 live block(s) are reachable only through edges the normal-flow view leaves out: [45]
    }

    static int finBreak(int[] arg0) {
        // @method finBreak([I)I
        // @declaration a static method of `LoopTransferFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int local1;
        int[] local2;
        int local3;
        int local4;
        local1 = 0;
        local2 = arg0;
        local3 = local2.length;
        for (local4 = 0; local4 < local3; local4 = local4 + 1) {
            int local5 = local2[local4];
            if (local5 == 3) {
                local1 = local1 + 100;
                break;
            } else {
                local1 = local1 + local5;
                local1 = local1 + 100;
            }
        }
        return local1;
        // @bytecode 45 47 50 52
        // 1 live block(s) are reachable only through edges the normal-flow view leaves out: [45]
    }
}
