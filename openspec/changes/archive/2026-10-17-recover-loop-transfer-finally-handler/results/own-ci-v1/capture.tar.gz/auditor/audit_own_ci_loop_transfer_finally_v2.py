#!/usr/bin/env python3
"""Prepared independent OFFLINE 30afa7c successor own-CI audit. Require terminal capture. No root acceptance dependency."""
from __future__ import annotations
import hashlib, json, re, sys, zipfile, shlex
from pathlib import Path, PurePosixPath
BASE=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
CAP=BASE/'own-ci-loop-transfer-finally-root-v1'
SOURCE_BINDING=BASE/'CORE/loop-transfer-finally-30afa-source-native-CLI-binding-v1.json'
SOURCE_TREE=BASE/'CORE/loop-transfer-finally-30afa-git-tree-capture-v1/stdout.raw'
NATIVE=BASE/'CORE/loop-transfer-finally-atomic-projection-native-v2/execution.json'
GATES=BASE/'CORE/own-ci-loop-transfer-finally-independent-audit-prepared-v1/gate-names.json'
CAPTURE_RUNNER=BASE/'capture_product_ci_v4.py'
CAPTURE_DISPATCH=BASE/'loop-transfer-finally-own-ci-dispatch-v1/dispatch.json'
WORKFLOW=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde/.github/workflows/ci.yml')
OUT=Path(__file__).with_name('audit-result-v2.json')
HEAD='30afa7c9ab2818f41959f9ea6a8ca6f896714dc1'
BRANCH='codex/loop-transfer-finally-handler'
RUN_BINDING=Path(__file__).with_name('run-binding.json')
SEEDS=['5350648285461741569','5350648285461741570']

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_pin(p: Path) -> dict:
    if p.is_symlink() or not p.is_file():
        raise ValueError(f'not a regular non-symlink file: {p}')
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': sha(data)}


def read_json(p: Path):
    return json.loads(p.read_text(encoding='utf-8'))


def require(ok: bool, msg: str, checks: list[str], errors: list[str]):
    checks.append(msg)
    if not ok:
        errors.append(msg)


def main() -> int:
    if OUT.exists():
        raise SystemExit(f'refusing overwrite: {OUT}')
    run_binding=read_json(RUN_BINDING)
    RUN=run_binding.get('run_id')
    if not isinstance(RUN,int) or isinstance(RUN,bool) or RUN<=0 or run_binding.get('head')!=HEAD or run_binding.get('branch')!=BRANCH or run_binding.get('capture')!=str(CAP):
        raise SystemExit('actual run binding absent or inconsistent; run must never be guessed')
    capture_path=CAP/'execution.json'
    cap=read_json(capture_path)
    if cap.get('run_status')!='completed' or not (CAP/'logs.zip').is_file():
        raise SystemExit('terminal capture/ZIP absent; preparation is not an executed audit')
    checks=[];errors=[]
    require(len(HEAD)==40 and cap.get('product_sha')==HEAD,'product head is the exact full 40-character commit id',checks,errors)
    seal=read_json(Path(__file__).with_name('preexecution-pins-v2.json'))
    require(seal.get('head')==HEAD and seal.get('branch')==BRANCH and seal.get('run_id')==RUN and seal.get('capture')==str(CAP),'preexecution seal binds exact actual run/head/branch/capture',checks,errors)
    require(file_pin(RUN_BINDING) in seal['pinned_inputs'] and file_pin(CAPTURE_DISPATCH) in seal['pinned_inputs'],'run binding and actual collector dispatch are sealed',checks,errors)
    for row in seal['pinned_inputs']:
        actual=file_pin(Path(row['path']))
        require(actual==row,'preexecution static pin unchanged: '+row['path'],checks,errors)
    require(file_pin(Path(__file__))==seal['auditor'],'auditor matches preexecution SHA',checks,errors)
    inventory=read_json(Path(__file__).with_name('source-target-inventory-v1.json'))
    for row in inventory['files'].values():
        require(file_pin(Path(row['path']))==row,'target source bytes unchanged: '+row['path'],checks,errors)
    require(inventory['head']==HEAD and inventory['primary_count']==170 and inventory['support_count']==7,'exact30afa7c primary/support inventory',checks,errors)
    require(inventory['primary_sourcefile_count']==34 and inventory['all_sourcefile_count']==39,'actual source inventory34primary/39all',checks,errors)
    future_gates=read_json(GATES)
    binding=read_json(SOURCE_BINDING)
    source_execution=read_json(NATIVE)
    workflow_bytes=WORKFLOW.read_bytes();workflow=workflow_bytes.decode('utf-8')
    collector_bytes=CAPTURE_RUNNER.read_bytes();collector_text=collector_bytes.decode('utf-8')
    collector_dispatch=read_json(CAPTURE_DISPATCH)
    require(cap.get('status')=='captured_pending_root_acceptance' and cap.get('product_sha')==HEAD and cap.get('run_id')==RUN and cap.get('conclusion')=='success','terminal capture exact 30afa7c successor successful run',checks,errors)
    require(isinstance(cap.get('transport_failures'),list),'recovery-aware capture has a separate transport_failures list',checks,errors)
    require(str(CAPTURE_RUNNER) in collector_dispatch.get('argv',[]) and '--out' in collector_dispatch.get('argv',[]) and str(CAP) in collector_dispatch.get('argv',[]),'launch dispatch binds the v4 collector to exact v2 CAP',checks,errors)
    require('for attempt in range(5):' in collector_text and 'if attempt<4:time.sleep(15)' in collector_text,'pinned collector code bounds retries to five attempts with 15-second waits between attempts',checks,errors)
    tree_receipt=read_json(SOURCE_TREE.parent/'execution.json')
    require(binding.get('head')==HEAD and binding.get('status')=='accepted_actual_git_tree_blobs_modes_equal_native_and_CLI_source' and len(binding.get('sources',[]))==4945,'actual30afa source binding schema/status4945',checks,errors)
    require(binding.get('native_receipt')==file_pin(NATIVE) and source_execution.get('source_manifest_before')==source_execution.get('source_manifest_after') and len(source_execution.get('source_manifest_before',[]))==4945,'native full4945 source before/after closure',checks,errors)
    require({x['path']:(x['bytes'],x['sha256']) for x in binding['sources']}=={x['path']:(x['bytes'],x['sha256']) for x in source_execution['source_manifest_before']},'actual binding sources equal native compiled closure',checks,errors)
    require(tree_receipt['argv']==binding['ls_tree_argv']==['git','ls-tree','-r','-z',HEAD] and tree_receipt['cwd']=='/home/lordcasser/.codex/worktrees/core-integrity/jarde' and tree_receipt['exit_code']==0,'actual full-root ls-tree argv/cwd/exit0 retained without clipping',checks,errors)
    require(file_pin(SOURCE_TREE)==tree_receipt['streams']['stdout'] and file_pin(Path(tree_receipt['streams']['stderr']['path']))==tree_receipt['streams']['stderr'] and file_pin(SOURCE_TREE)['bytes']==binding['ls_tree_bytes']==37689610 and file_pin(SOURCE_TREE)['sha256']==binding['ls_tree_sha256']=='f0349ccc716b73579494fce5ce004e03186e230227b773388812fc5eae74f61e','actual37689610byte full-tree raw pin matches original binding',checks,errors)
    tree={}
    for line in SOURCE_TREE.read_bytes().split(b'\0'):
        if not line:continue
        info,rel=line.split(b'\t',1);mode,kind,oid=info.split();tree[rel.decode()]=(mode.decode(),kind.decode(),oid.decode())
    require(all(tree.get(x['path'])==(x['git_mode'],'blob',x['git_blob_sha1']) for x in binding['sources']),'all4945 native source blobs/modes represented by actual full30afa tree',checks,errors)
    cli=binding['CLI'];actual=file_pin(Path(cli['path']))
    require(actual['bytes']==cli['bytes'] and actual['sha256']==cli['sha256'] and Path(cli['path']).stat().st_mode & 0o777 == 0o555 and cli.get('mode')=='0555' and source_execution.get('frozen_cli')==cli,'actual CLI matches native/source binding and0555mode',checks,errors)
    require(actual['sha256']=='05e0272eb8cbc65acb87418cecda6d15571ddaea84c041d30436c1238e60b89d' and actual['bytes']==60514880,'fixed30afa CLI05e027/60514880',checks,errors)
    wfrow=next(x for x in source_execution['source_manifest_before'] if x['path']=='.github/workflows/ci.yml')
    require(len(workflow_bytes)==wfrow['bytes'] and sha(workflow_bytes)==wfrow['sha256'],'actual workflow bytes match compiled product source',checks,errors)
    require(isinstance(future_gates,list) and len(future_gates)==170 and len(set(future_gates))==170,'forecast gate-name file contains exactly170 unique names',checks,errors)
    require(set(future_gates)=={x['fqn'] for x in inventory['gates'] if x['classification']=='primary'},'primary names exactly match source-target inventory',checks,errors)
    observations = cap.get('observations', [])
    require(bool(observations), 'capture has positive actual API observation count', checks, errors)
    raw_paths: set[str] = set()
    raw_pins = []
    for i, obs in enumerate(observations):
        require(obs.get('exit_code') == 0, f'API observation {i} exited zero', checks, errors)
        streams = obs.get('streams', {})
        require(set(streams) == {'stdout', 'stderr'}, f'API observation {i} has exactly stdout/stderr pins', checks, errors)
        for kind, pin in streams.items():
            p = Path(pin.get('path', '')).resolve()
            inside = p.is_relative_to(CAP.resolve())
            require(inside and str(p) not in raw_paths, f'API observation {i} {kind} raw is unique and inside capture', checks, errors)
            if inside and str(p) not in raw_paths:
                raw_paths.add(str(p))
            try:
                actual = file_pin(p)
                matched = actual['bytes'] == pin.get('bytes') and actual['sha256'] == pin.get('sha256')
            except Exception:
                actual, matched = {}, False
            require(matched, f'API observation {i} {kind} raw bytes/SHA match', checks, errors)
            if matched:
                raw_pins.append(actual)
    run_ep = f'repos/LordCasser/jarde/actions/runs/{RUN}'
    jobs_ep = run_ep + '/jobs?per_page=100'
    logs_ep = f'repos/LordCasser/jarde/actions/runs/{RUN}/logs'
    transport_failures=cap.get('transport_failures',[])
    attempt_groups={}
    def attempt_key(row, is_failure):
        streams=row.get('streams',{})
        paths=[Path(x.get('path','')).name for x in streams.values()]
        parsed=[]
        for name in paths:
            mm=re.fullmatch(r'(\d+-run|\d+-jobs|completed-log-zip)(?:-retry(\d+))?\.(?:stdout|stderr)\.raw',name)
            if not mm: continue
            prefix=mm.group(1); retry=mm.group(2)
            parsed.append((prefix,1 if retry is None else int(retry)+1))
        require(len(parsed)==2 and parsed[0]==parsed[1],f'API attempt has a consistent numbered stdout/stderr filename: {row.get("endpoint")}',checks,errors)
        if len(parsed)!=2:return None
        prefix,filename_attempt=parsed[0]
        actual_attempt=row.get('attempt',filename_attempt)
        require(actual_attempt==filename_attempt and 1<=actual_attempt<=5,f'API attempt number matches collector filename and 1..5 bound: {prefix}',checks,errors)
        expected_endpoint=run_ep if prefix.endswith('-run') else jobs_ep if prefix.endswith('-jobs') else logs_ep
        require(row.get('endpoint')==expected_endpoint,f'API attempt filename corresponds to expected endpoint: {prefix}',checks,errors)
        key=(prefix,expected_endpoint)
        attempt_groups.setdefault(key,[]).append({'attempt':actual_attempt,'failure':is_failure,'exit_code':row.get('exit_code')})
        return key
    for i,row in enumerate(observations):
        attempt_key(row,False)
    for i,row in enumerate(transport_failures):
        require(row.get('exit_code') not in (None,0),f'transport failure {i} is a nonzero API attempt',checks,errors)
        streams=row.get('streams',{})
        require(set(streams)=={'stdout','stderr'},f'transport failure {i} has stdout/stderr pins',checks,errors)
        attempt_key(row,True)
        for kind,pin in streams.items():
            p=Path(pin.get('path','')).resolve(); inside=p.is_relative_to(CAP.resolve())
            require(inside and str(p) not in raw_paths,f'transport failure {i} {kind} raw is unique and inside v2 capture',checks,errors)
            if inside and str(p) not in raw_paths:raw_paths.add(str(p))
            try:
                actual=file_pin(p);matched=actual['bytes']==pin.get('bytes') and actual['sha256']==pin.get('sha256')
            except Exception:actual,matched={},False
            require(matched,f'transport failure {i} {kind} bytes/SHA match',checks,errors)
            if matched:raw_pins.append(actual)
    for key,attempts in attempt_groups.items():
        seq=sorted(x['attempt'] for x in attempts); success=[x for x in attempts if not x['failure']]; fail=[x for x in attempts if x['failure']]
        require(len(success)==1 and seq==list(range(1,len(seq)+1)) and len(seq)<=5 and success[0]['attempt']==len(seq) and all(x['attempt']<success[0]['attempt'] for x in fail),'transport attempts are contiguous, <=5, and terminate in one successful observation',checks,errors)
    expected_fail_raw=BASE/'own-ci-loop-transfer-finally-root-v1/transport-failures.json'
    if transport_failures:
        require(expected_fail_raw.is_file() and read_json(expected_fail_raw)==transport_failures,'transport-failures.json matches captured failure ledger',checks,errors)
    else:
        require(not expected_fail_raw.exists(),'no transport-failure ledger exists when no retry errors were captured',checks,errors)
    require(len(raw_paths) == 2 * (len(observations)+len(transport_failures)), 'API raw stream count derives from successful observations plus transport failures', checks, errors)
    require(len(observations) >= 3 and len(observations) % 2 == 1, 'capture has one or more poll pairs plus terminal logs API observation', checks, errors)
    for i in range(0, max(0, len(observations) - 1), 2):
        pair = observations[i:i+2]
        require(len(pair) == 2 and pair[0].get('endpoint') == run_ep and pair[1].get('endpoint') == jobs_ep, f'API poll pair {i//2} is run then jobs', checks, errors)
        if len(pair) == 2:
            try:
                poll_run = read_json(Path(pair[0]['streams']['stdout']['path']))
                poll_jobs = read_json(Path(pair[1]['streams']['stdout']['path']))
                good_run = poll_run.get('id') == RUN and poll_run.get('head_sha') == HEAD and poll_run.get('head_branch') == BRANCH and poll_run.get('event') == 'push'
                good_jobs = isinstance(poll_jobs.get('jobs'), list)
            except Exception:
                good_run = good_jobs = False
            require(good_run, f'API poll {i//2} is bound to exact static-prefix 30afa7c successor push run', checks, errors)
            require(good_jobs, f'API poll {i//2} has a parseable jobs response', checks, errors)
    terminal = observations[-3:] if len(observations) >= 3 else []
    require([x.get('endpoint') for x in terminal] == [run_ep, jobs_ep, logs_ep], 'terminal API responses are final run/jobs/logs in order', checks, errors)
    final_run = read_json(Path(terminal[0]['streams']['stdout']['path'])) if terminal else {}
    final_jobs = read_json(Path(terminal[1]['streams']['stdout']['path'])) if terminal else {}
    require(final_run.get('id') == RUN and final_run.get('head_sha') == HEAD and final_run.get('head_branch') == BRANCH and final_run.get('event') == 'push' and final_run.get('status') == 'completed' and final_run.get('conclusion') == 'success', 'terminal run API says exact successful successor push commit', checks, errors)
    require(final_jobs.get('jobs') == cap.get('jobs') and len(final_jobs.get('jobs', [])) == 4, 'terminal jobs API equals captured four-job receipt', checks, errors)

    jobs = final_jobs.get('jobs', [])
    require(len(jobs) == 4 and {x.get('name') for x in jobs} == {'stable / test and specification', 'MSRV 1.88.0', 'supply chain', 'fuzz smoke'}, 'four workflow jobs are present by exact workflow job names', checks, errors)
    step_total = sum(len(x.get('steps', [])) for x in jobs)
    require(step_total == 52, 'terminal jobs contain exactly 52 steps', checks, errors)
    for job in jobs:
        require(job.get('status') == 'completed' and job.get('conclusion') == 'success', f'job passed: {job.get("name")}', checks, errors)
        for step in job.get('steps', []):
            require(step.get('status') == 'completed' and step.get('conclusion') in ('success', 'skipped'), f'step completed successfully or skipped: {job.get("name")} / {step.get("name")}', checks, errors)

    log_pin = cap.get('logs', {})
    zip_path = CAP / 'logs.zip'
    zpin = file_pin(zip_path)
    require(log_pin.get('path') == str(zip_path) and log_pin.get('bytes') == zpin['bytes'] and log_pin.get('sha256') == zpin['sha256'], 'downloaded logs ZIP matches terminal capture pin', checks, errors)
    try:
        with zipfile.ZipFile(zip_path) as zf:
            infos = zf.infolist()
            names = [x.filename for x in infos]
            require(len(names) > 0 and len(names) == len(set(names)), 'CI log ZIP has a nonempty dynamic safe unique member list', checks, errors)
            member_pins = []
            for info in infos:
                pp = PurePosixPath(info.filename)
                mode = (info.external_attr >> 16) & 0o170000
                safe = (not info.is_dir() and bool(info.filename) and not info.filename.startswith('/') and not pp.is_absolute() and '..' not in pp.parts and '.' not in pp.parts and '\\' not in info.filename and '\x00' not in info.filename and mode in (0, 0o100000))
                require(safe, f'CI log ZIP member is a safe regular file: {info.filename}', checks, errors)
                data = zf.read(info)
                member_pins.append({'path': info.filename, 'bytes': len(data), 'sha256': sha(data), 'crc32': info.CRC})
            ansi = re.compile(r'\x1b\[[0-9;]*m')
            api_jobs = {x.get('name'): x for x in jobs}
            expected_job_names = {'stable / test and specification', 'MSRV 1.88.0', 'supply chain', 'fuzz smoke'}
            aggregate_members = {}
            # Official ZIP layouts vary. Bind each original aggregate job log to its API
            # job. If an exact official per-step file is absent, derive the command view
            # from that original aggregate; never call a derived view an official member.
            aggregate_titles = {
                'stable / test and specification': 'stable _ test and specification',
                'MSRV 1.88.0': 'MSRV 1.88.0',
                'supply chain': 'supply chain',
                'fuzz smoke': 'fuzz smoke',
            }
            for job_name in expected_job_names:
                title = aggregate_titles[job_name]
                matches=[member_name for member_name in names if re.fullmatch(r'\d+_'+re.escape(title)+r'\.txt', member_name)]
                require(len(matches)==1, f'unique actual aggregate ZIP member for job {job_name}', checks, errors)
                if len(matches)==1:
                    aggregate_members[job_name]=matches[0]
            require(set(aggregate_members)==expected_job_names, 'four actual aggregate job logs map to the four API jobs', checks, errors)
            api_step_outcomes = []
            for api_job in jobs:
                for api_step in api_job.get('steps', []):
                    api_step_outcomes.append({'job':api_job.get('name'),'name':api_step.get('name'),'status':api_step.get('status'),'conclusion':api_step.get('conclusion'),'started_at':api_step.get('started_at'),'completed_at':api_step.get('completed_at')})
                    require(api_step.get('status')=='completed' and api_step.get('conclusion') in ('success','skipped'), f'complete native API step outcome preserved: {api_job.get("name")} / {api_step.get("name")}', checks, errors)
            job_for_prefix = {
                'stable _ test and specification/': 'stable / test and specification',
                'MSRV 1.88.0/': 'MSRV 1.88.0',
                'supply chain/': 'supply chain',
                'fuzz smoke/': 'fuzz smoke',
            }
            command_by_title = {
                'Install stable Rust with lint': 'dtolnay/rust-toolchain@stable',
                'Install Temurin 25.0.4+7': 'actions/setup-java@v6.0.1',
                'Install Node.js 22': 'actions/setup-node@v7.0.0',
                'Check formatting': 'cargo fmt --all -- --check',
                'Run Clippy': 'cargo clippy --workspace --all-targets --all-features --locked',
                'Validate OpenSpec strictly': 'openspec validate --all --strict --no-interactive',
                'Ensure tracked files remain unchanged': 'git diff --exit-code',
                'Ensure the smoke runs left the tracked tree unchanged': 'git diff --exit-code',
                'Install Rust 1.88.0': 'dtolnay/rust-toolchain@master',
                'Check workspace on MSRV': 'cargo check --workspace --all-targets --locked',
                'Check root workspace advisories, licenses, bans, and sources': 'cargo deny --all-features --workspace --locked --config ./deny.toml --manifest-path ./Cargo.toml check',
                'Check fuzz workspace advisories, licenses, bans, and sources': 'cargo deny --all-features --workspace --locked --config ./deny.toml --manifest-path ./fuzz/Cargo.toml check',
                'Install cargo-fuzz 0.13.2': 'cargo install cargo-fuzz --version 0.13.2 --locked',
                'Install nightly-2026-07-20': 'dtolnay/rust-toolchain@master',
                'Run the bounded query smoke': '# New corpus entries and crash artifacts must not land in the tracked tree:',
                'Run the bounded artifact-tree smoke': 'mkdir -p "$RUNNER_TEMP/corpus/artifact_tree"',
                'Run the bounded method-analysis smoke': 'mkdir -p "$RUNNER_TEMP/corpus/method_analysis"',
                'Run ignored JDK 25 instruction-boundary oracle': 'cargo test --test jvm_bytecode_oracle --locked -- --ignored --exact jdk25_instruction_boundaries_match_public_bytecode_inspection',
                'Run the ignored P3 Java 8 compile-and-execute comparison': 'cargo test --test p3_execution_comparison --locked -- --ignored',
                'Run the functional-constructor full-class comparison': 'cargo test -p jarde-cli --test json_cli --locked -- --ignored --exact functional_constructor_arguments_replay_the_complete_class_on_both_jdks',
                'Run the BigDecimal Number full-class comparisons': 'cargo test --test p3_bigdecimal_number_widening --locked -- --ignored',
                'Run the nested int array full-class comparisons': 'cargo test --test p3_nested_int_array_compound_updates --locked -- --ignored --exact nested_int_array_updates_match_the_frozen_runner_oracle',
                'Run the returned int array full-class comparison': 'cargo test --test p3_nested_int_array_compound_updates --locked -- --ignored --exact returned_int_array_updates_compile_and_execute_as_a_complete_class',
                'Run public API example': 'cargo run --example inspect_class_header --locked -- tests/fixtures/historical/ecj-4.6.1/v52/HistoricalControlFlow.class',
                'Check resolved feature tree': 'cargo tree --workspace --all-features --locked -e features > "$RUNNER_TEMP/feature-tree.txt"',
                'Check normal dependency tree boundary': 'cargo tree --workspace --all-features --locked -e normal > "$RUNNER_TEMP/normal-tree.txt"',
                'Run workspace tests with two fixed independent seeds (pass 1)': 'cargo test --workspace --all-targets --all-features --locked',
                'Run workspace tests with two fixed independent seeds (pass 2)': 'cargo test --workspace --all-targets --all-features --locked',
            }
            api_aliases = {
                'Install stable Rust with lint components':'dtolnay/rust-toolchain@stable',
                'Install Temurin 25.0.4+7':'actions/setup-java@v6.0.1',
                'Install Node.js 22':'actions/setup-node@v7.0.0',
                'Check formatting':'cargo fmt --all -- --check',
                'Run Clippy':'cargo clippy --workspace --all-targets --all-features --locked',
                'Run workspace tests with two fixed independent seeds (pass 1)':'cargo test --workspace --all-targets --all-features --locked',
                'Run workspace tests with two fixed independent seeds (pass 2)':'cargo test --workspace --all-targets --all-features --locked',
                'Run ignored JDK 25 instruction-boundary oracle':'cargo test --test jvm_bytecode_oracle --locked -- --ignored --exact jdk25_instruction_boundaries_match_public_bytecode_inspection',
                'Run the ignored P3 Java 8 compile-and-execute comparison':'cargo test --test p3_execution_comparison --locked -- --ignored',
                'Run the functional-constructor full-class comparison':'cargo test -p jarde-cli --test json_cli --locked -- --ignored --exact functional_constructor_arguments_replay_the_complete_class_on_both_jdks',
                'Run the BigDecimal Number full-class comparisons':'cargo test --test p3_bigdecimal_number_widening --locked -- --ignored',
                'Run the nested int array full-class comparisons':'cargo test --test p3_nested_int_array_compound_updates --locked -- --ignored --exact nested_int_array_updates_match_the_frozen_runner_oracle',
                'Run the returned int array full-class comparison':'cargo test --test p3_nested_int_array_compound_updates --locked -- --ignored --exact returned_int_array_updates_compile_and_execute_as_a_complete_class',
                'Run public API example':'cargo run --example inspect_class_header --locked -- tests/fixtures/historical/ecj-4.6.1/v52/HistoricalControlFlow.class',
                'Check resolved feature tree':'cargo tree --workspace --all-features --locked -e features > "$RUNNER_TEMP/feature-tree.txt"',
                'Check normal dependency tree boundary':'cargo tree --workspace --all-features --locked -e normal > "$RUNNER_TEMP/normal-tree.txt"',
                'Install Rust 1.88.0':'dtolnay/rust-toolchain@master',
                'Check workspace on MSRV':'cargo check --workspace --all-targets --locked',
                'Check root workspace advisories, licenses, bans, and sources':'cargo deny --all-features --workspace --locked --config ./deny.toml --manifest-path ./Cargo.toml check',
                'Check fuzz workspace advisories, licenses, bans, and sources':'cargo deny --all-features --workspace --locked --config ./deny.toml --manifest-path ./fuzz/Cargo.toml check',
                'Install nightly-2026-07-20':'dtolnay/rust-toolchain@master',
                'Install cargo-fuzz 0.13.2':'cargo install cargo-fuzz --version 0.13.2 --locked',
                'Prepare the C++ and sanitizer toolchain':'# The ubuntu-24.04 image already ships clang/llvm and gcc, and the nightly',
                'Check the committed corpus against the targets':'cargo +nightly-2026-07-20 test --manifest-path fuzz/Cargo.toml --locked',
                'Run the bounded query smoke':'# New corpus entries and crash artifacts must not land in the tracked tree:',
                'Run the bounded artifact-tree smoke':'mkdir -p "$RUNNER_TEMP/corpus/artifact_tree"',
                'Run the bounded method-analysis smoke':'mkdir -p "$RUNNER_TEMP/corpus/method_analysis"',
                'Ensure the smoke runs left the tracked tree unchanged':'git diff --exit-code',
                'Install cargo-fuzz 0.13.2':'cargo install cargo-fuzz --version 0.13.2 --locked',
                'Check the layered crate dependency closure':'# The teeth of this step are `errexit`',
                'Install OpenSpec 1.11.0':'npm install --global @fission-ai/openspec@1.11.0',
                'Validate OpenSpec strictly':'openspec validate --all --strict --no-interactive',
                'Ensure tracked files remain unchanged':'git diff --exit-code',
            }
            selected_log_cache = {}
            log_segments = []
            def step_text(prefix: str, title: str) -> str:
                job_name = job_for_prefix.get(prefix)
                api_job = api_jobs.get(job_name)
                require(api_job is not None, f'API job exists for {prefix}', checks, errors)
                if api_job is None: return ''
                api_matches = [x for x in api_job.get('steps', []) if x.get('name') == title]
                if not api_matches: api_matches = [x for x in api_job.get('steps', []) if title in x.get('name', '')]
                require(len(api_matches) == 1, f'unique API step for {title}', checks, errors)
                if len(api_matches) != 1: return ''
                api_step = api_matches[0]
                member_candidates=[n for n in names if n == f"{prefix}{api_step.get('number')}_{api_step.get('name')}.txt"]
                require(len(member_candidates)<=1, f'no duplicate exact official per-step log member for {job_name} / {api_step.get("name")}', checks, errors)
                if len(member_candidates)>1: return ''
                source_kind='official_per_step_member' if member_candidates else 'derived_view_from_official_aggregate'
                member=member_candidates[0] if member_candidates else aggregate_members.get(job_name)
                require(member in names, f'original official log source exists for {job_name} / {api_step.get("name")}', checks, errors)
                if member not in names: return ''
                text=ansi.sub('',zf.read(member).decode('utf-8-sig',errors='replace'))
                require(api_step.get('status') == 'completed' and api_step.get('conclusion') == 'success', f'API step succeeded: {title}', checks, errors)
                command = command_by_title.get(title)
                if command is None:
                    require(False, f'no frozen command selector for {title}', checks, errors); return ''
                group_re = re.compile(r'^(\d{4}-\d{2}-\d{2}T[^ ]+Z) ##\[group\]Run (.*)$', re.M)
                candidates = []
                start_sec, end_sec = api_step['started_at'][:19], api_step['completed_at'][:19]
                for match in group_re.finditer(text):
                    if match.group(2) == command or (title == 'Run Clippy' and match.group(2).startswith(command)):
                        # API timestamps have second precision: an actual command may
                        # start during the reported completed_at second (Node here).
                        # Keep both endpoint seconds, then require exact command/seed
                        # uniqueness rather than borrowing a neighboring command.
                        if start_sec <= match.group(1)[:19] <= end_sec: candidates.append(match)
                if api_step.get('name') in ('Run workspace tests with two fixed independent seeds (pass 1)','Run workspace tests with two fixed independent seeds (pass 2)'):
                    seed='5350648285461741569' if 'pass 1' in api_step['name'] else '5350648285461741570'
                    candidates=[candidate for candidate in candidates if seed in text[candidate.start():text.find('##[endgroup]',candidate.start())]]
                require(len(candidates) == 1, f'unique exact Run command boundary inside API step: {title}', checks, errors)
                if len(candidates) != 1: return ''
                match = candidates[0]
                # Independently select the next workflow API step's actual Run boundary.
                # This retains command output after its env endgroup and prevents the
                # intermediate sub-actions of composite actions from truncating evidence.
                step_idx = api_job['steps'].index(api_step)
                next_boundary = None
                for next_step in api_job['steps'][step_idx+1:]:
                    next_cmd = api_aliases.get(next_step.get('name'))
                    if next_cmd is None: continue
                    ns, ne = next_step.get('started_at','')[:19], next_step.get('completed_at','')[:19]
                    matches_next=[]
                    for candidate in group_re.finditer(text, match.end()):
                        h=candidate.group(2)
                        same = h == next_cmd or h.startswith(next_cmd)
                        in_window = ns <= candidate.group(1)[:19] <= ne
                        if same and in_window: matches_next.append(candidate)
                    if next_step.get('name') in ('Run workspace tests with two fixed independent seeds (pass 1)','Run workspace tests with two fixed independent seeds (pass 2)'):
                        seed='5350648285461741569' if 'pass 1' in next_step['name'] else '5350648285461741570'
                        matches_next=[candidate for candidate in matches_next if seed in text[candidate.start():text.find('##[endgroup]',candidate.start())]]
                    if len(matches_next)==1:
                        next_boundary=matches_next[0]; break
                    if matches_next:
                        require(False, f'ambiguous next API step Run boundary after {title}: {next_step["name"]}', checks, errors); break
                if next_boundary is not None:
                    end=next_boundary.start()
                else:
                    # The selected command is the last relevant Run in this job. Bound
                    # by API completion time and stop at the first later timestamped line.
                    end=len(text)
                    for lm in re.finditer(r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})[^ ]* ',text[match.end():],re.M):
                        if lm.group(1)>end_sec:
                            end=match.end()+lm.start();break
                segment = text[match.start():end]
                stamps = re.findall(r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})[^ ]* ', segment, re.M)
                require(bool(stamps) and min(stamps) >= start_sec and max(stamps) <= end_sec, f'command segment timestamps fit API second bounds: {title}', checks, errors)
                log_segments.append({'source_kind':source_kind,'api_job':job_name,'api_step':title,'api_step_number':api_step['number'],'api_step_name':api_step['name'],'api_started_at':api_step['started_at'],'api_completed_at':api_step['completed_at'],'member':member,'official_member_sha256':sha(zf.read(member)),'decoded_char_start':match.start(),'decoded_char_end':end,'command_header':match.group(2),'sha256':sha(segment.encode())})
                return segment
            def contains(text: str, needle: str, label: str):
                require(needle in text, label, checks, errors)
            stable_prefix = 'stable _ test and specification/'
            stable_rust = step_text(stable_prefix, 'Install stable Rust with lint')
            contains(stable_rust, '##[group]Run dtolnay/rust-toolchain@stable', 'native toolchain action follows frozen workflow stable channel')
            contains(stable_rust, 'rustc 1.99.1 (58cf8f9c3 2026-10-13)', 'actual native stable Rust identity is 1.99.1/58cf8f9c3/2026-10-13')
            java = step_text(stable_prefix, 'Install Temurin 25.0.4+7')
            contains(java, 'Version: 25.0.4+7.0.LTS', 'native Temurin version is 25.0.4+7.0.LTS')
            node = step_text(stable_prefix, 'Install Node.js 22')
            contains(node, 'node: v22.', 'native Node.js major version is 22')
            msrv = step_text('MSRV 1.88.0/', 'Install Rust 1.88.0')
            contains(msrv, 'rustc 1.88.0 (6b00bc388', 'MSRV toolchain is Rust 1.88.0')

            strict = step_text(stable_prefix, 'Validate OpenSpec strictly')
            contains(strict, 'openspec validate --all --strict --no-interactive', 'strict validation command is present')
            contains(strict, 'Totals: 364 passed, 0 failed (364 items)', 'static-prefix strict CI snapshot actually364/0')
            clean = step_text(stable_prefix, 'Ensure tracked files remain unchanged')
            contains(clean, 'git diff --exit-code', 'tracked-tree cleanliness command ran')
            fmt = step_text(stable_prefix, 'Check formatting')
            contains(fmt, 'cargo fmt --all -- --check', 'workspace formatting command ran')
            clippy = step_text(stable_prefix, 'Run Clippy')
            contains(clippy, 'cargo clippy --workspace --all-targets --all-features --locked', 'workspace clippy command ran')

            # Compare the entire folded workflow Clippy argv, not just its prefix.
            wf_lines=workflow.splitlines();wi=next(i for i,x in enumerate(wf_lines) if x.strip()=='- name: Run Clippy');wr=next(i for i in range(wi+1,len(wf_lines)) if wf_lines[i].strip()=='run: >-');parts=[]
            for line in wf_lines[wr+1:]:
                if line.strip() and len(line)-len(line.lstrip())<10:break
                parts.append(line.strip())
            require(shlex.split(log_segments[-1]['command_header'])==shlex.split(' '.join(parts)),'actual complete Clippy argv equals frozen workflow',checks,errors)
            example=step_text(stable_prefix,'Run public API example')
            contains(example,'cargo run --example inspect_class_header --locked','public API example actual command ran')
            feature_tree=step_text(stable_prefix,'Check resolved feature tree')
            contains(feature_tree,'cargo tree --workspace --all-features --locked -e features','resolved feature tree actual command ran')
            normal_tree=step_text(stable_prefix,'Check normal dependency tree boundary')
            contains(normal_tree,'cargo tree --workspace --all-features --locked -e normal','normal dependency boundary actual command ran')
            required_names=list(future_gates)
            support_names=[x['fqn'] for x in inventory['gates'] if x['classification']=='support']
            require(len(support_names)==len(set(support_names))==7 and not(set(support_names)&set(required_names)),'seven support gates are unique and disjoint from primary170',checks,errors)
            require(len(required_names)==len(set(required_names))==170,'forecast gate-name file has170 unique required names',checks,errors)
            seeds_out = []
            for n, seed in enumerate(SEEDS, 1):
                text = step_text(stable_prefix, f'Run workspace tests with two fixed independent seeds (pass {n})')
                contains(text, f'PROPTEST_RNG_SEED: {seed}', f'workspace run uses required seed {seed}')
                contains(text, 'cargo test --workspace --all-targets --all-features --locked', f'workspace run {seed} uses exact all-targets/all-features command')
                summaries = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
                totals = {'passed': sum(int(x[1]) for x in summaries), 'failed': sum(int(x[2]) for x in summaries), 'ignored': sum(int(x[3]) for x in summaries)}
                require(len(summaries) == 374 and all(x[0] == 'ok' for x in summaries), f'{seed} has 374 successful test-suite summaries', checks, errors)
                require(totals == {'passed': 3680, 'failed': 0, 'ignored': 98}, f'{seed} totals are exactly 3680/0/98', checks, errors)
                named = re.findall(r'test (.+) \.\.\. (ok|ignored|FAILED)(?:, [^\n]*)?\s*$', text, re.M)
                require(sum(v == 'ok' for _, v in named) == 3680 and sum(v == 'ignored' for _, v in named) == 98 and not any(v == 'FAILED' for _, v in named), f'{seed} named outcomes are 3680 pass and 98 ignored', checks, errors)
                for name in required_names:
                    require(sum(x == name and y == 'ok' for x, y in named) == 1, f'{seed} required CI gate passed exactly once: {name}', checks, errors)
                # Cargo target boundaries bind each FQN to its independently inventoried source target.
                running=list(re.finditer(r'\bRunning\s+(.+?)\s+\(([^)]+)\)',text))
                target_evidence=[]
                for gate in (x for x in inventory['gates'] if x['classification']=='primary'):
                    matches=[]
                    for k,run in enumerate(running):
                        end=running[k+1].start() if k+1<len(running) else len(text)
                        exe=Path(run.group(2)).name.rsplit('-',1)[0]
                        if exe!=gate['cargo_target_name'] or run.group(1)!=gate['cargo_runner_label']:continue
                        named_target=re.findall(r'test (.+) \.\.\. (ok|ignored|FAILED)(?:, [^\n]*)?\s*$',text[run.end():end],re.M)
                        if sum(n==gate['fqn'] and outcome=='ok' for n,outcome in named_target)==1:
                            matches.append({'runner':run.group(1),'executable':run.group(2),'segment_sha256':sha(text[run.start():end].encode())})
                    require(len(matches)==1,f'{seed} exact source/target/FQN unique: '+gate['fqn'],checks,errors)
                    target_evidence.append({'classification':gate['classification'],'fqn':gate['fqn'],'sourcefile':gate['sourcefile'],'package':gate['package'],'target':gate['cargo_target_name'],'matches':matches})
                seeds_out.append({'target_fqn_bindings':[x for x in target_evidence if x['classification']=='primary'],'seed': seed, 'suites': len(summaries), **totals, 'named_passes': sum(v == 'ok' for _, v in named), 'named_ignored': sum(v == 'ignored' for _, v in named)})

            # The six workflow commands below contain nine actual selected tests;
            # the functional-constructor test itself asserts the complete class under both JDKs.
            jdk_specs = [
                ('Run ignored JDK 25 instruction-boundary oracle', 'cargo test --test jvm_bytecode_oracle --locked -- --ignored --exact jdk25_instruction_boundaries_match_public_bytecode_inspection', ['jdk25_instruction_boundaries_match_public_bytecode_inspection'], 1),
                ('Run the ignored P3 Java 8 compile-and-execute comparison', 'cargo test --test p3_execution_comparison --locked -- --ignored', ['the_bulk_entrys_bodies_are_the_same_text_and_the_same_behaviour', 'the_corpus_is_read_the_same_way_by_every_legal_flag_set', 'the_p3_findings_are_replayed_by_compiling_and_executing_the_bodies'], 3),
                ('Run the functional-constructor full-class comparison', 'cargo test -p jarde-cli --test json_cli --locked -- --ignored --exact functional_constructor_arguments_replay_the_complete_class_on_both_jdks', ['functional_constructor_arguments_replay_the_complete_class_on_both_jdks'], 1),
                ('Run the BigDecimal Number full-class comparisons', 'cargo test --test p3_bigdecimal_number_widening --locked -- --ignored', ['bigdecimal_number_argument_generated_source_matches_frozen_runtime', 'main_only_bigdecimal_generated_source_matches_frozen_original_runtime'], 2),
                ('Run the nested int array full-class comparisons', 'cargo test --test p3_nested_int_array_compound_updates --locked -- --ignored --exact nested_int_array_updates_match_the_frozen_runner_oracle', ['nested_int_array_updates_match_the_frozen_runner_oracle'], 1),
                ('Run the returned int array full-class comparison', 'cargo test --test p3_nested_int_array_compound_updates --locked -- --ignored --exact returned_int_array_updates_compile_and_execute_as_a_complete_class', ['returned_int_array_updates_compile_and_execute_as_a_complete_class'], 1),
            ]
            jdk_evidence = []
            for title, command, tests, expected_count in jdk_specs:
                text = step_text(stable_prefix, title)
                contains(text, command, f'JDK/full-class step launched exact command: {title}')
                for test in tests:
                    contains(text, f'test {test} ... ok', f'JDK/full-class test passed: {test}')
                result = re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;', text)
                require(result is not None and int(result.group(1)) == expected_count, f'JDK/full-class command has {expected_count} actual passing test(s): {title}', checks, errors)
                named_jdk=re.findall(r'test (.+) \.\.\. (ok|ignored|FAILED)(?:, [^\n]*)?\s*$',text,re.M)
                require(sorted(named_jdk)==sorted((test,'ok') for test in tests),f'JDK command exact unique selected FQNs and outcomes: {title}',checks,errors)
                command_words=shlex.split(command)
                expected_target=command_words[command_words.index('--test')+1]
                actual_runners=list(re.finditer(r'\bRunning\s+(.+?)\s+\(([^)]+)\)',text))
                target_runners=[run for run in actual_runners if run.group(1)=='tests/'+expected_target+'.rs' and Path(run.group(2)).name.rsplit('-',1)[0]==expected_target]
                require(len(target_runners)==1,f'JDK command exact Cargo source target: {title}',checks,errors)
                jdk_evidence.append({'step':title,'command':command,'target':expected_target,'selected_FQNs':tests,'passing_tests':int(result.group(1)) if result else None,'expected_passing_tests':expected_count,'command_observed':command in text})
            full_class_gate_tests = ['jdk25_instruction_boundaries_match_public_bytecode_inspection', 'the_p3_findings_are_replayed_by_compiling_and_executing_the_bodies', 'functional_constructor_arguments_replay_the_complete_class_on_both_jdks', 'bigdecimal_number_argument_generated_source_matches_frozen_runtime', 'main_only_bigdecimal_generated_source_matches_frozen_original_runtime', 'nested_int_array_updates_match_the_frozen_runner_oracle', 'returned_int_array_updates_compile_and_execute_as_a_complete_class']
            require(len(full_class_gate_tests) == 7 and len(set(full_class_gate_tests)) == 7, 'seven named JDK/full-class gates enumerated uniquely', checks, errors)
            require(len(jdk_evidence) == 6 and sum((x['passing_tests'] or 0) for x in jdk_evidence)==9, 'all six JDK command steps have nine actual passing tests', checks, errors)

            require(set(support_names)==set(full_class_gate_tests),'support7 is exactly the inherited independently inventoried JDK/full-class set, not a substitute set',checks,errors)
            support_evidence=[]
            for gate in (x for x in inventory['gates'] if x['classification']=='support'):
                matches=[x for x in jdk_evidence if gate['fqn'] in x['selected_FQNs'] and x['target']==gate['cargo_target_name']]
                require(len(matches)==1,'support FQN has exactly one matching actual explicit JDK command/target: '+gate['fqn'],checks,errors)
                support_evidence.append({'fqn':gate['fqn'],'sourcefile':gate['sourcefile'],'package':gate['package'],'target':gate['cargo_target_name'],'matching_commands':matches})

            # Remaining workflow job command evidence; API job/step conclusions above establish success.
            msrv_check = step_text('MSRV 1.88.0/', 'Check workspace on MSRV')
            contains(msrv_check, 'cargo check --workspace --all-targets --locked', 'MSRV all-target workspace check ran')
            supply_root = step_text('supply chain/', 'Check root workspace advisories, licenses, bans, and sources')
            contains(supply_root, 'cargo deny --all-features --workspace --locked --config ./deny.toml --manifest-path ./Cargo.toml check', 'root supply-chain check ran')
            supply_fuzz = step_text('supply chain/', 'Check fuzz workspace advisories, licenses, bans, and sources')
            contains(supply_fuzz, 'cargo deny --all-features --workspace --locked --config ./deny.toml --manifest-path ./fuzz/Cargo.toml check', 'fuzz supply-chain check ran')
            fuzz_install = step_text('fuzz smoke/', 'Install cargo-fuzz 0.13.2')
            contains(fuzz_install, 'cargo install cargo-fuzz --version 0.13.2 --locked', 'cargo-fuzz 0.13.2 installed in CI')
            fuzz_nightly = step_text('fuzz smoke/', 'Install nightly-2026-07-20')
            contains(fuzz_nightly, 'toolchain: nightly-2026-07-20', 'fuzz job uses pinned nightly')
            fuzz_steps = []
            for title, target in [('Run the bounded query smoke', 'query'), ('Run the bounded artifact-tree smoke', 'artifact_tree'), ('Run the bounded method-analysis smoke', 'method_analysis')]:
                text = step_text('fuzz smoke/', title)
                contains(text, f'cargo +nightly-2026-07-20 fuzz run {target}', f'fuzz target ran: {target}')
                contains(text, '-max_total_time=20', f'fuzz target uses bounded 20-second limit: {target}')
                fuzz_steps.append(target)
            fuzz_clean=step_text('fuzz smoke/','Ensure the smoke runs left the tracked tree unchanged')
            contains(fuzz_clean,'git diff --exit-code','fuzz tracked-tree cleanliness command ran')
            require(len(fuzz_steps) == 3, 'all three configured fuzz smoke targets were present', checks, errors)
    except Exception as exc:
        errors.append(f'audit parsing error: {type(exc).__name__}: {exc}')
        member_pins = locals().get('member_pins',[])
        seeds_out = locals().get('seeds_out',[])
        jdk_evidence = locals().get('jdk_evidence',[])

    report={
        'status':'accepted_independent_exact_product_ci_review' if not errors else 'rejected_independent_exact_product_ci_review',
        'audit_lineage':read_json(Path(__file__).with_name('adaptation-lineage-v2.json')),
        'scope':'Independent offline original API+ZIP audit of exact30afa7c LoopTransfer v2 recovery-aware capture only. No root acceptance dependency; the supplied test/gate counts are forecasts until parsed from actual command/API-time ranges. No network/Git/native, no CI rerun; skipped steps stay skipped.',
        'product_sha':HEAD,'product_sha_length':len(HEAD),'branch':BRANCH,'run_id':RUN,
        'capture':file_pin(capture_path),'logs_zip':zpin,'workflow':file_pin(WORKFLOW),'auditor':file_pin(Path(__file__)),
        'preexecution_seal':file_pin(Path(__file__).with_name('preexecution-pins-v2.json')),'source_target_inventory':file_pin(Path(__file__).with_name('source-target-inventory-v1.json')),'source_binding':file_pin(SOURCE_BINDING),'source_tree':file_pin(SOURCE_TREE),'native_build_receipt':file_pin(NATIVE),'required_gate_plan':file_pin(GATES),'capture_collector':file_pin(CAPTURE_RUNNER),'capture_dispatch':file_pin(CAPTURE_DISPATCH),
        'api_observations':len(observations),'transport_failures':len(transport_failures),'transport_failure_ledger':file_pin(expected_fail_raw) if expected_fail_raw.is_file() else None,'api_raw_stream_count':len(raw_paths),'api_raw_pins':raw_pins,'jobs':len(jobs),'steps':step_total,'api_step_outcomes':api_step_outcomes if 'api_step_outcomes' in locals() else [],'aggregate_job_log_members':aggregate_members if 'aggregate_members' in locals() else {},
        'seeds':seeds_out,'jdk_full_class_commands':jdk_evidence,'support_target_fqn_bindings':support_evidence if 'support_evidence' in locals() else [],'jdk_full_class_gate_tests':full_class_gate_tests if 'full_class_gate_tests' in locals() else [],
        'checks':len(checks),'errors':errors,'check_labels':checks,'log_member_pins':member_pins,'log_segments':log_segments if 'log_segments' in locals() else [],
        'log_layout':'official_original_members_with_explicit_API_command_derived_views','aggregate_log_member_count':len(aggregate_members) if 'aggregate_members' in locals() else 0,'zip_member_count_dynamic':len(member_pins) if 'member_pins' in locals() else 0,
        'forecast_constraints_not_results':{'suites_per_seed':374,'passed_per_seed':3680,'failed_per_seed':0,'ignored_per_seed':98,'required_names':170,'support_names':7,'strict_items':364,'JDK_explicit_commands':6,'JDK_explicit_passing_tests':9}}
    OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'checks':len(checks),'errors':errors,'output':str(OUT)},ensure_ascii=False))
    return 0 if not errors else 1
if __name__=='__main__':
    raise SystemExit(main())
