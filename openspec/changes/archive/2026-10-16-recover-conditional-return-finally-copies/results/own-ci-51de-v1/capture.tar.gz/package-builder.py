from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,zipfile
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=B/'CORE';CAP=B/'own-ci-conditional-return-finally-root-v2';O=C/'conditional-return-finally-51de-own-ci-evidence-v1';O.mkdir(exist_ok=False)
def sha(v):return hashlib.sha256(v).hexdigest()
d=json.loads((CAP/'execution.json').read_text());assert d['product_sha']=='51de58710291cd3a3587f7040eec6f972cb26229' and d['run_id']==38863891656 and d['run_status']=='completed' and d['conclusion']=='success';payload={};rows=[]
def add(name,p,group):
 p=Path(p);assert p.is_file() and not p.is_symlink();v=p.read_bytes();assert name not in payload and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts;payload[name]=v;rows.append(dict(path=name,bytes=len(v),sha256=sha(v),source_path=str(p),group=group))
for p in sorted(CAP.rglob('*')):
 if p.is_file():add('capture/'+p.relative_to(CAP).as_posix(),p,'original_terminal_capture')
for i,obs in enumerate(d['observations']):
 assert obs['exit_code']==0
 for q in obs['streams'].values():
  v=Path(q['path']).read_bytes();assert len(v)==q['bytes'] and sha(v)==q['sha256'];assert str(Path(q['path'])) in {r['source_path'] for r in rows}
assert len(d['observations'])==105 and d.get('transport_failures',[])==[]
for p in sorted((B/'own-ci-conditional-return-finally-root-launch-v2').iterdir()):
 if p.is_file():add('capture-launch/'+p.name,p,'actual_capture_dispatch')
add('root-ci-acceptance.json',B/'conditional-return-finally-51de-own-ci-root-acceptance-v3.json','actual_exact_head_ci_acceptance')
add('root-ci-auditor.py',B/'accept_product_ci_v6.py','executed_root_auditor')
for p in sorted((C/'conditional-return-finally-own-ci-root-audit-plan-v3').iterdir()):
 if p.is_file():add('root-audit/'+p.name,p,'prepared_and_actual_root_audit')
for p in sorted((C/'own-ci-conditional-return-finally-independent-audit-v2').iterdir()):
 if p.is_file():add('independent-audit/'+p.name,p,'independent_ci_audit')
add('capture-runner.py',B/'capture_product_ci_v4.py','executed_capture_runner')
for n in ['final-source-cli-head-binding.json','source-head-tree.raw','source-head-tree.argv.json']:add('source-lineage/'+n,C/'conditional-return-finally-final-product-source-binding-v1'/n,'actual_source_binding')
add('source-lineage/native-execution.json',C/'conditional-return-finally-final-product-native-v1/execution.json','prior_build_reference_not_this_ci_execution')
add('package-builder.py',Path(__file__).resolve(),'package_builder')
with zipfile.ZipFile(CAP/'logs.zip') as z:
 names=z.namelist();assert len(names)==len(set(names)) and len(names)>0 and z.testzip() is None
 for n in names:assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
# Retain failed transports and prior audit-parser attempts as their own phases.
for rel,group in [('own-ci-conditional-return-finally-root-v1','earlier_transport_failure_not_ci_failure'),('own-ci-conditional-return-finally-root-launch-v1','earlier_transport_dispatch')]:
 for p in sorted((B/rel).rglob('*')):
  if p.is_file():add('history/'+rel+'/'+p.relative_to(B/rel).as_posix(),p,group)
for version in [1,2]:
 folder=C/f'conditional-return-finally-own-ci-root-audit-plan-v{version}'
 for p in sorted(folder.iterdir()):
  if p.is_file():add('history/root-audit-v'+str(version)+'/'+p.name,p,'earlier_auditor_rejection_not_product_failure')
 add('history/root-audit-result-v'+str(version)+'.json',B/f'conditional-return-finally-51de-own-ci-root-acceptance-v{version}.json','earlier_auditor_rejection_not_product_failure')
for version in [4,5]:add('history/root-auditor-v'+str(version)+'.py',B/f'accept_product_ci_v{version}.py','earlier_executed_auditor')
add('history/old-capture-runner.py',B/'capture_product_ci_v3.py','executed_transport_failure_runner')
assert json.loads((B/'conditional-return-finally-51de-own-ci-root-acceptance-v3.json').read_text())['status']=='accepted_exact_product_ci'
assert json.loads((C/'own-ci-conditional-return-finally-independent-audit-v2/audit-result-v3.json').read_text())['status']=='accepted_independent_exact_product_ci_review'
m=dict(schema='conditional-return-finally-51de-own-ci-evidence-v1',status='packaged_actual_successful_exact_head_ci',product_head=d['product_sha'],run_id=d['run_id'],conclusion='success',api_observations=len(d['observations']),api_raw_streams=2*len(d['observations']),transport_failures_in_terminal_capture=0,jobs=4,successful_jobs=4,workspace_seeds=[dict(seed=seed,summaries=371,passed=3656,failed=0,ignored=98) for seed in ['5350648285461741569','5350648285461741570']],strict_items=364,required_named_gates=146,zip_members=len(names),original_zip=d['logs'],scope='Only exact51de ownCI. First collector network failure and root/independent parser failures preserved separately. Final archive/main docs do not claim their own51de CI.',payload_count=len(rows),members=sorted(rows,key=lambda r:r['path']))
v=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode();(O/'manifest.json').write_bytes(v)
with (O/'capture.tar.gz').open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,data in sorted({**payload,'manifest.json':v}.items()):
    i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data))
with tarfile.open(O/'capture.tar.gz') as t:
 assert len(t.getmembers())==len(payload)+1
 for i in t.getmembers():assert i.isfile() and t.extractfile(i).read()=={**payload,'manifest.json':v}[i.name]
a=(O/'capture.tar.gz').read_bytes();e=dict(status='reopened_and_verified_successful_ci_every_member',archive=str(O/'capture.tar.gz'),bytes=len(a),sha256=sha(a),payload_count=len(rows),member_count=len(rows)+1,manifest_sha256=sha(v));(O/'execution.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e))
