from pathlib import Path
import json,subprocess,time,hashlib,argparse
ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--run',type=int,required=True);ap.add_argument('--head',required=True);ap.add_argument('--branch',required=True);a=ap.parse_args()
O=a.out;O.mkdir(exist_ok=False)
GH='/home/lordcasser/.local/bin/gh';RUN=a.run;SHA=a.head
rows=[]
transport_failures=[]
def get(endpoint,name):
 for attempt in range(5):
  suffix=name if attempt==0 else name+f'-retry{attempt}'
  c=subprocess.run([GH,'api',endpoint],capture_output=True)
  (O/(suffix+'.stdout.raw')).write_bytes(c.stdout);(O/(suffix+'.stderr.raw')).write_bytes(c.stderr)
  item={'endpoint':endpoint,'exit_code':c.returncode,'attempt':attempt+1,'streams':{k:{'path':str(O/(suffix+'.'+k+'.raw')),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()} for k,z in [('stdout',c.stdout),('stderr',c.stderr)]}}
  if c.returncode==0:
   rows.append(item)
   return c.stdout
  transport_failures.append(item)
  (O/'transport-failures.json').write_text(json.dumps(transport_failures,indent=2)+'\n')
  if attempt<4:time.sleep(15)
 raise RuntimeError('GitHub API transport failed after five attempts: '+endpoint)
idx=0
while True:
 run=json.loads(get(f'repos/LordCasser/jarde/actions/runs/{RUN}',f'{idx}-run'))
 jobs=json.loads(get(f'repos/LordCasser/jarde/actions/runs/{RUN}/jobs?per_page=100',f'{idx}-jobs'))
 assert run['head_sha']==SHA and run['head_branch']==a.branch and run['event']=='push'
 doc={'status':'waiting','run_id':RUN,'product_sha':SHA,'run_status':run['status'],'conclusion':run.get('conclusion'),'observations':rows,'transport_failures':transport_failures,'jobs':jobs['jobs']}
 (O/'execution.json').write_text(json.dumps(doc,indent=2)+'\n')
 if run['status']=='completed':break
 idx+=1;time.sleep(30)
logs=get(f'repos/LordCasser/jarde/actions/runs/{RUN}/logs','completed-log-zip')
(O/'logs.zip').write_bytes(logs)
doc.update({'status':'captured_pending_root_acceptance','logs':{'path':str(O/'logs.zip'),'bytes':len(logs),'sha256':hashlib.sha256(logs).hexdigest()}})
(O/'execution.json').write_text(json.dumps(doc,indent=2)+'\n')
assert run['conclusion']=='success', run['conclusion']
print(json.dumps({'run':RUN,'head':SHA,'conclusion':run['conclusion'],'job_count':len(jobs['jobs'])}))
