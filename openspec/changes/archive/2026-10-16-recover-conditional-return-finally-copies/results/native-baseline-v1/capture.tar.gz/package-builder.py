from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=B/'CORE';W=Path('/home/lordcasser/.codex/worktrees/conditional-return-finally/jarde');O=C/'conditional-return-finally-native-baseline-evidence-v1';O.mkdir(exist_ok=False)
def sha(v):return hashlib.sha256(v).hexdigest()
payload={};rows=[]
def add(name,p,group):
 p=Path(p);assert p.is_file() and not p.is_symlink();v=p.read_bytes();assert name not in payload and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts;payload[name]=v;rows.append(dict(path=name,bytes=len(v),sha256=sha(v),source_path=str(p),group=group))
groups=[('old-behavior-red','conditional-return-finally-old-native-v1','execution.json',6),('actual-Facts-probe','conditional-return-finally-old-proof-probe-v1','execution.json',3),('new-abab-cli-red','conditional-return-finally-old-probe-cli-red-v1','run-v1/execution.json',4)];sources=[];summary=[]
for label,dirname,receipt,count in groups:
 base=C/dirname;d=json.loads((base/receipt).read_text());assert len(d['commands'])==count;assert d['source_manifest_before']==d['source_manifest_after'] and len(d['source_manifest_before'])==4922;sources.append(d['source_manifest_before'])
 for p in sorted(base.rglob('*')):
  if p.is_file() and not p.name.endswith('.tmp'):add(label+'/'+p.relative_to(base).as_posix(),p,label)
 for cmd in d['commands']:
  assert cmd['exit_code']==cmd.get('expected_exit',cmd.get('expected_exit_code',0))
  for q in cmd['streams'].values():
   v=Path(q['path']).read_bytes();assert len(v)==q['bytes'] and sha(v)==q['sha256'];assert str(Path(q['path'])) in {r['source_path'] for r in rows}
 summary.append(dict(group=label,commands=count,raw_streams=count*2,actual_exit_codes=[q['exit_code'] for q in d['commands']]))
assert sources[1]==sources[2];a={r['path']:r for r in sources[0]};b={r['path']:r for r in sources[1]};assert a.keys()==b.keys();assert [k for k in a if a[k]!=b[k]]==['crates/jarde-java/src/guard.rs']
for n in ['guard.py','target_scan.py','workspace_runner.py']:add('helpers/'+n,Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep')/n,'executed_helper')
add('helpers/new-abab-cli-red-harness.py',B/'replay_loopless_old_probe_cli_v1.py','executed_harness')
for p in sorted((C/'conditional-return-finally-old-probe-cli-red-launch-v1').iterdir()):
 if p.is_file():add('new-abab-cli-red-launch/'+p.name,p,'actual_dispatch_metadata')
for p in sorted((W/'tests/fixtures/recover-conditional-return-finally-copies').rglob('*')):
 if p.is_file():add('fixture/'+p.relative_to(W/'tests/fixtures/recover-conditional-return-finally-copies').as_posix(),p,'unchanged_frozen_fixture')
add('instrumentation.md',W/'openspec/changes/recover-conditional-return-finally-copies/instrumentation.md','actual_Facts_scope_record')
add('package-builder.py',Path(__file__).resolve(),'package_builder')
m=dict(schema='conditional-return-finally-native-baseline-evidence-v1',scope='Old-production behavior reds, intentional five-file corpus fingerprint update, actual Facts/SSA first-refusal probe, and real fresh abab complete-source reds. No new production proof or rebuilt runtime.',baseline_commit='e00c3cbe363a01dadb8d3d47d153f1998c992d18',source_count=4922,source_binding='actual-Facts-probe/source-head-binding-e00.json',frozen_cli_phase1=dict(path=str(B/'jarde-cli-conditional-return-finally-old-v1'),bytes=59699632,mode='0555',sha256='6e075292bf761f178858f5714b3dbbf51e57a9e711ca1d87d45e77312228db96',inside_archive=False),frozen_cli_phase2=dict(path=str(B/'jarde-cli-conditional-return-finally-old-v2'),bytes=59699632,mode='0555',sha256='abab495171f4f1a56ca9d4ccaddf77678a15349dfd52416e6485a037651816e4',inside_archive=False),actual_command_groups=summary,command_count=13,command_raw_count=26,intentional_fingerprint=dict(old=2226,new=2231,added_nonmd_files=5,removed=0,changed_existing=0,nonfiles_fields_unchanged=True),old_behavior=dict(public='0 passed,2 actual assertion failures,0ignored',cli='0 passed,1 actual assertion failure,0ignored',exit_code=101),actual_probe=dict(passed=1,failed=0,first_mismatch='row.end16 != inferred cleanup start25',inferred_cleanup_bcis=[25,26,29],actual_fused_block26_bcis=[26,29,31,34,48,49]),new_abab_replay=dict(commands=4,cli_exit_codes=[0,0],full_generated_compile_exit_codes=[1,1],text_bytes=1560,text_sha256='57926d1ddc3ad60342c853a185ff5fa3d8e8ae5c79288da0cffe65f5ad76a8c1',rebuilt_runtime_commands=0),limits=['Phase1 native source records intentional fingerprint maintenance separately; only fingerprint changed during that stage.','Between native phases only guard.rs cfg(test) probe helper changed; frozen CLI bytes changed too, so the four abab CLI reds were actually rerun, not relabeled.','The successful private probe tests old refusal and graph/SSA facts; no new certificate is implemented.','Original four 134B driver oracles and complete FY/FX current reds are in the separate planning-baseline bundle.','Unreached source-map assertions from the first behavioral failure are not claimed executed.','Current old reader census is intentionally not accepted as final integration; the new two Loopless fixtures need their own measured population maintenance before product CI.'],payload_count=len(rows),members=sorted(rows,key=lambda r:r['path']))
v=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode();(O/'manifest.json').write_bytes(v)
with (O/'capture.tar.gz').open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,data in sorted({**payload,'manifest.json':v}.items()):
    i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data))
with tarfile.open(O/'capture.tar.gz') as t:
 assert len(t.getmembers())==len(payload)+1
 for i in t.getmembers():assert i.isfile() and t.extractfile(i).read()=={**payload,'manifest.json':v}[i.name]
z=(O/'capture.tar.gz').read_bytes();e=dict(status='reopened_and_verified_every_baseline_member_not_implementation',archive=str(O/'capture.tar.gz'),bytes=len(z),sha256=sha(z),payload_count=len(rows),member_count=len(rows)+1,commands=13,command_raw_streams=26,manifest_sha256=sha(v));(O/'execution.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e))
