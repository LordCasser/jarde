// jarde: presentation of `LooplessFinally` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class LooplessFinally extends java.lang.Object {
    static int value;

    public LooplessFinally() {
        // @method <init>()V
        // @declaration a constructor of `LooplessFinally`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int loopless(int[] arg0) {
        // jarde: not recovered: the recovery run for `loopless([I)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method loopless([I)I
        // @declaration a static method of `LooplessFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 2
        // BCI 37: the exceptional path repeats code the normal path also runs — the `finally` copy javac emits for a `finally` clause; this candidate lacks the complete straight-body, copy, range, and ownership proof needed to merge them into one `finally`
        // @bytecode 5 6 7 8 9 12 15 16 19 21 24 25 26 29 31 34 37 38 41 43 46 47 48 49
        // 4 live block(s) are reachable only through edges the normal-flow view leaves out: [5, 26, 37, 12]
    }
}
