from pathlib import Path
import json,hashlib,importlib.util,os,shutil,zipfile,datetime
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');W=Path('/home/lordcasser/.codex/worktrees/conditional-return-finally/jarde');D=B/'CORE/conditional-return-finally-old-probe-cli-red-v1';D.mkdir(exist_ok=False);O=D/'run-v1';O.mkdir();OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');FIX=W/'tests/fixtures/recover-conditional-return-finally-copies';CLI=B/'jarde-cli-conditional-return-finally-old-v2';RP=B/'CORE/conditional-return-finally-old-proof-probe-v1/execution.json'
def pin(p):
 p=Path(p);v=p.read_bytes();assert p.is_file() and not p.is_symlink();return dict(path=str(p),bytes=len(v),sha256=hashlib.sha256(v).hexdigest())
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
assert not(W/'target').exists() and shutil.disk_usage(W).free>=5*1024**3
native=json.loads(RP.read_text());assert native['source_manifest_before']==native['source_manifest_after'] and native['target_absent'];assert pin(CLI)=={k:native['frozen_cli'][k] for k in ['path','bytes','sha256']}
closure=load('loopless_old_probe_source_closure',OLD/'tools-prep/workspace_runner.py');closure.ROOT=W;paths=set(closure.source_paths())|{W/x['path'] for x in json.loads((W/'tests/fixtures/corpus-fingerprint.json').read_text())['files']}
def sources():return [dict(path=str(p.relative_to(W)),bytes=p.stat().st_size,sha256=pin(p)['sha256']) for p in sorted(paths)]
before=sources();assert before==native['source_manifest_before'];jd=json.loads((OLD/'tools/jdk-manifest.json').read_text());tools={}
for leg in jd['legs']:
 if leg.get('leg') in ['javac23','javac8']:
  q=leg['jdk_tools']['javac'];assert pin(q['path'])=={k:q[k] for k in ['path','bytes','sha256']};tools[leg['leg']]=Path(q['path'])
inputs={CLI,RP,Path(__file__).resolve(),*tools.values(),*FIX.rglob('*')};inputs={p for p in inputs if p.is_file()};ip=[pin(p) for p in sorted(inputs)];g=load('loopless_old_probe_red_guard',OLD/'tools-prep/guard.py');sc=load('loopless_old_probe_red_scan',OLD/'tools-prep/target_scan.py');g.ROOT=W;g.OUT=O;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.target_bytes=lambda:sc.target_bytes(W);g.expected_test_summaries=lambda _i,_d:None;g.command_stream=pin;g.ENV_VALUES={}
r=dict(schema='conditional-return-finally-old-probe-cli-red-v1',status='running',scope='New abab CLI after cfg(test) probe changes has different bytes; actual fresh complete generated-source refusal. No implementation or rebuilt runtime. Original driver oracle retained separately.',native_receipt=pin(RP),frozen_cli=native['frozen_cli'],source_manifest_before=before,inputs_before=ip,default_stack=True,guards=dict(free_bytes=5*1024**3,target_bytes=1024**3),commands=[],legs={})
def save():(O/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
def run(label,args,expected):
 args=[str(x) for x in args];env={'HOME':'/home/lordcasser','PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}
 if Path(args[0]) in tools.values():env.update(JAVA_HOME=str(Path(args[0]).parent.parent),PATH=str(Path(args[0]).parent)+':/usr/bin:/bin')
 q=g.run_command(len(r['commands'])+1,args,env);q.update(label=label,expected_exit=expected);r['commands'].append(q);save();assert q['exit_code']==expected and q['guard_stop'] is None;return q
save()
try:
 for leg,sub in [('javac23','v8'),('javac8','v8-javac8')]:
  c=FIX/sub/'LooplessFinally.class';jar=O/(leg+'-frozen.jar')
  with zipfile.ZipFile(jar,'w',compression=zipfile.ZIP_STORED) as z:
   i=zipfile.ZipInfo('LooplessFinally.class',(1980,1,1,0,0,0));z.writestr(i,c.read_bytes())
  q=run(leg+'-full-json-current-probe-cli',[CLI,'class-source','--input',jar,'--class','LooplessFinally','--policy','plain-jar','--release','8','--format','json','--evidence','all','--budget','elapsed_millis=10000'],0);doc=json.loads(Path(q['streams']['stdout']['path']).read_text());dest=O/(leg+'-generated');dest.mkdir();source=dest/'LooplessFinally.java';source.write_bytes(doc['text'].encode());assert pin(source)['sha256']=='57926d1ddc3ad60342c853a185ff5fa3d8e8ae5c79288da0cffe65f5ad76a8c1';assert len(doc['methods'])==2;classes=dest/'classes';classes.mkdir();empty=dest/'empty-sourcepath';empty.mkdir();flags=['--release','8','-Xlint:-options'] if leg=='javac23' else ['-source','8','-target','8'];q=run(leg+'-compile-exact-complete-generated',[tools[leg],*flags,'-g:none','-classpath',classes,'-sourcepath',empty,'-d',classes,source],1);assert b'missing return' in Path(q['streams']['stderr']['path']).read_bytes().lower();assert source.read_bytes()==doc['text'].encode();r['legs'][leg]=dict(class_input=pin(c),jar=pin(jar),generated_source=pin(source),method_count=2,generated_compile_exit=1,rebuilt_runtime_commands=0);save()
 assert len(r['commands'])==4;r['status']='captured_four_command_actual_new_cli_complete_source_red'
except BaseException as e:r['status']='failed_raw_preserved';r['error']=repr(e)
finally:
 r.update(source_manifest_after=sources(),inputs_after=[pin(p) for p in sorted(inputs)],target_absent=not(W/'target').exists(),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());r['sources_identical']=r['source_manifest_after']==before;r['inputs_identical']=r['inputs_after']==ip
 if not r['sources_identical'] or not r['inputs_identical'] or not r['target_absent']:r['status']='failed_integrity'
 save()
print(r['status'],len(r['commands']));raise SystemExit(0 if r['status']=='captured_four_command_actual_new_cli_complete_source_red' else 1)
