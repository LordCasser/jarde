// jarde: presentation of `NoCallFinally` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class NoCallFinally extends java.lang.Object {
    public NoCallFinally() {
        // @method <init>()V
        // @declaration a constructor of `NoCallFinally`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int noCall(int[] arg0) {
        // jarde: not recovered: the recovery run for `noCall([I)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method noCall([I)I
        // @declaration a static method of `NoCallFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 10 16 28 40 46 54 60
        // local 1 crosses a quoted fallback region; its assignments and consumers cannot be presented as one lexically bound definition-use slice
    }
}
