#!/usr/bin/env python3
"""Independent offline audit of the exact c871 CI capture; reads capture/logs only."""
from __future__ import annotations
import hashlib, json, re, sys, zipfile
from pathlib import Path, PurePosixPath

BASE = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
CAP = BASE / 'own-ci-combined-c871-root-v1'
ACCEPT = BASE / 'own-ci-combined-root-acceptance-v1.json'
SOURCE_BINDING = BASE / 'combined-proof-product-source-git-binding-v1.json'
GATES = BASE / 'combined-proof-all-ci-gates-root-v1.json'
EXTRA = BASE / 'combined-proof-extra-ci-gates-root-v2.json'
BASE_GATES = BASE.parent / 'ordinary-try-list-20261014/workspace-forward-v10/root-acceptance.json'
WORKFLOW = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde/.github/workflows/ci.yml')
OUT = BASE / 'CORE/own-ci-combined-independent-review-v1.json'
PRIOR_ATTEMPT = BASE / 'CORE/own-ci-combined-independent-review-initial-rejected-v1.json'
HEAD = 'c8718aeff6cc08b686c7b3c3495bfd0bb9efa2b1'
BRANCH = 'codex/interface-super-proof-stops'
RUN = 38692921405
SEEDS = ['5350648285461741569', '5350648285461741570']


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_pin(p: Path) -> dict:
    if p.is_symlink() or not p.is_file():
        raise ValueError(f'not a regular non-symlink file: {p}')
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': sha(data)}


def read_json(p: Path):
    return json.loads(p.read_text(encoding='utf-8'))


def require(ok: bool, msg: str, checks: list[str], errors: list[str]):
    checks.append(msg)
    if not ok:
        errors.append(msg)


def main() -> int:
    if OUT.exists():
        raise SystemExit(f'refusing overwrite: {OUT}')
    if not ACCEPT.is_file():
        raise SystemExit('root acceptance is not present yet; audit is intentionally not run')
    checks: list[str] = []
    errors: list[str] = []
    acceptance = read_json(ACCEPT)
    capture_path = CAP / 'execution.json'
    cap = read_json(capture_path)
    gates = read_json(GATES)
    extra = read_json(EXTRA)
    base_gate = read_json(BASE_GATES)
    workflow_bytes = WORKFLOW.read_bytes()
    workflow = workflow_bytes.decode('utf-8')
    binding = read_json(SOURCE_BINDING)

    require(acceptance.get('status') == 'accepted_exact_product_ci' and acceptance.get('errors') == [], 'root auditor accepted exact product CI without errors', checks, errors)
    require(acceptance.get('product_sha') == HEAD and acceptance.get('branch') == BRANCH and acceptance.get('run_id') == RUN, 'root acceptance head/branch/run binding', checks, errors)
    require(cap.get('status') == 'captured_pending_root_acceptance' and cap.get('product_sha') == HEAD and cap.get('run_id') == RUN and cap.get('run_status') == 'completed' and cap.get('conclusion') == 'success', 'capture terminal status and exact product identity', checks, errors)
    require(binding.get('status') == 'accepted_exact_clean_product_source_binding' and binding.get('head') == HEAD and binding.get('branch') == BRANCH and binding.get('source_count') == 4902 and binding.get('target_absent') is True, 'source receipt binds frozen 4902-file c871 tree', checks, errors)
    wfrow = next((x for x in binding.get('checks', []) if x.get('path') == '.github/workflows/ci.yml'), {})
    require(wfrow.get('source_pin_matches') is True and wfrow.get('git_blob_matches') is True, 'workflow file is in accepted product source/Git binding', checks, errors)

    observations = cap.get('observations', [])
    require(bool(observations), 'capture has positive actual API observation count', checks, errors)
    raw_paths: set[str] = set()
    raw_pins = []
    for i, obs in enumerate(observations):
        require(obs.get('exit_code') == 0, f'API observation {i} exited zero', checks, errors)
        streams = obs.get('streams', {})
        require(set(streams) == {'stdout', 'stderr'}, f'API observation {i} has exactly stdout/stderr pins', checks, errors)
        for kind, pin in streams.items():
            p = Path(pin.get('path', '')).resolve()
            inside = p.is_relative_to(CAP.resolve())
            require(inside and str(p) not in raw_paths, f'API observation {i} {kind} raw is unique and inside capture', checks, errors)
            if inside and str(p) not in raw_paths:
                raw_paths.add(str(p))
            try:
                actual = file_pin(p)
                matched = actual['bytes'] == pin.get('bytes') and actual['sha256'] == pin.get('sha256')
            except Exception:
                actual, matched = {}, False
            require(matched, f'API observation {i} {kind} raw bytes/SHA match', checks, errors)
            if matched:
                raw_pins.append(actual)
    require(len(raw_paths) == 2 * len(observations), 'raw stream count derives as two unique streams per actual API observation', checks, errors)
    run_ep = f'repos/LordCasser/jarde/actions/runs/{RUN}'
    jobs_ep = run_ep + '/jobs?per_page=100'
    logs_ep = f'repos/LordCasser/jarde/actions/runs/{RUN}/logs'
    require(len(observations) >= 3 and len(observations) % 2 == 1, 'capture has one or more poll pairs plus terminal logs API observation', checks, errors)
    for i in range(0, max(0, len(observations) - 1), 2):
        pair = observations[i:i+2]
        require(len(pair) == 2 and pair[0].get('endpoint') == run_ep and pair[1].get('endpoint') == jobs_ep, f'API poll pair {i//2} is run then jobs', checks, errors)
        if len(pair) == 2:
            try:
                poll_run = read_json(Path(pair[0]['streams']['stdout']['path']))
                poll_jobs = read_json(Path(pair[1]['streams']['stdout']['path']))
                good_run = poll_run.get('id') == RUN and poll_run.get('head_sha') == HEAD and poll_run.get('head_branch') == BRANCH and poll_run.get('event') == 'push'
                good_jobs = isinstance(poll_jobs.get('jobs'), list)
            except Exception:
                good_run = good_jobs = False
            require(good_run, f'API poll {i//2} is bound to exact c871 push run', checks, errors)
            require(good_jobs, f'API poll {i//2} has a parseable jobs response', checks, errors)
    terminal = observations[-3:] if len(observations) >= 3 else []
    require([x.get('endpoint') for x in terminal] == [run_ep, jobs_ep, logs_ep], 'terminal API responses are final run/jobs/logs in order', checks, errors)
    final_run = read_json(Path(terminal[0]['streams']['stdout']['path'])) if terminal else {}
    final_jobs = read_json(Path(terminal[1]['streams']['stdout']['path'])) if terminal else {}
    require(final_run.get('id') == RUN and final_run.get('head_sha') == HEAD and final_run.get('head_branch') == BRANCH and final_run.get('event') == 'push' and final_run.get('status') == 'completed' and final_run.get('conclusion') == 'success', 'terminal run API says exact successful push commit', checks, errors)
    require(final_jobs.get('jobs') == cap.get('jobs') and len(final_jobs.get('jobs', [])) == 4, 'terminal jobs API equals captured four-job receipt', checks, errors)

    jobs = final_jobs.get('jobs', [])
    require(len(jobs) == 4 and {x.get('name') for x in jobs} == {'stable / test and specification', 'MSRV 1.88.0', 'supply chain', 'fuzz smoke'}, 'four workflow jobs are present by exact workflow job names', checks, errors)
    step_total = sum(len(x.get('steps', [])) for x in jobs)
    require(step_total == 52, 'terminal jobs contain exactly 52 steps', checks, errors)
    for job in jobs:
        require(job.get('status') == 'completed' and job.get('conclusion') == 'success', f'job passed: {job.get("name")}', checks, errors)
        for step in job.get('steps', []):
            require(step.get('status') == 'completed' and step.get('conclusion') in ('success', 'skipped'), f'step completed successfully or skipped: {job.get("name")} / {step.get("name")}', checks, errors)

    log_pin = cap.get('logs', {})
    zip_path = CAP / 'logs.zip'
    zpin = file_pin(zip_path)
    require(log_pin.get('path') == str(zip_path) and log_pin.get('bytes') == zpin['bytes'] and log_pin.get('sha256') == zpin['sha256'], 'downloaded logs ZIP matches terminal capture pin', checks, errors)
    try:
        with zipfile.ZipFile(zip_path) as zf:
            infos = zf.infolist()
            names = [x.filename for x in infos]
            require(len(names) == len(set(names)), 'CI log ZIP member names are unique', checks, errors)
            member_pins = []
            for info in infos:
                pp = PurePosixPath(info.filename)
                mode = (info.external_attr >> 16) & 0o170000
                safe = not info.is_dir() and not pp.is_absolute() and '..' not in pp.parts and mode in (0, 0o100000)
                require(safe, f'CI log ZIP member is a safe regular file: {info.filename}', checks, errors)
                data = zf.read(info)
                member_pins.append({'path': info.filename, 'bytes': len(data), 'sha256': sha(data)})
            ansi = re.compile(r'\x1b\[[0-9;]*m')
            def step_text(prefix: str, title: str) -> str:
                found = [x for x in names if x.startswith(prefix) and title in x and '_Post ' not in PurePosixPath(x).name]
                require(len(found) == 1, f'unique job log for step {title}', checks, errors)
                return ansi.sub('', zf.read(found[0]).decode('utf-8-sig', errors='replace')) if len(found) == 1 else ''
            def contains(text: str, needle: str, label: str):
                require(needle in text, label, checks, errors)
            stable_prefix = 'stable _ test and specification/'
            stable_rust = step_text(stable_prefix, 'Install stable Rust with lint')
            contains(stable_rust, 'rustc 1.99.0 (b940084d7', 'native stable Rust toolchain is 1.99.0')
            java = step_text(stable_prefix, 'Install Temurin 25.0.4+7')
            contains(java, 'Version: 25.0.4+7.0.LTS', 'native Temurin version is 25.0.4+7.0.LTS')
            node = step_text(stable_prefix, 'Install Node.js 22')
            contains(node, 'node: v22.', 'native Node.js major version is 22')
            msrv = step_text('MSRV 1.88.0/', 'Install Rust 1.88.0')
            contains(msrv, 'rustc 1.88.0 (6b00bc388', 'MSRV toolchain is Rust 1.88.0')

            strict = step_text(stable_prefix, 'Validate OpenSpec strictly')
            contains(strict, 'openspec validate --all --strict --no-interactive', 'strict validation command is present')
            contains(strict, 'Totals: 365 passed, 0 failed (365 items)', 'c871 strict CI snapshot is exactly 365/0')
            clean = step_text(stable_prefix, 'Ensure tracked files remain unchanged')
            contains(clean, 'git diff --exit-code', 'tracked-tree cleanliness command ran')
            fmt = step_text(stable_prefix, 'Check formatting')
            contains(fmt, 'cargo fmt --all -- --check', 'workspace formatting command ran')
            clippy = step_text(stable_prefix, 'Run Clippy')
            contains(clippy, 'cargo clippy --workspace --all-targets --all-features --locked', 'workspace clippy command ran')

            named_gate_source = list(base_gate['required_named_test_outcomes_by_seed'][SEEDS[0]])
            required_names = named_gate_source + gates.get('extra50', [])
            require(gates.get('unique_total') == 105 and len(gates.get('baseline55', [])) == 55 and len(gates.get('extra50', [])) == 50 and len(set(required_names)) == 105, 'required gate list is 55 baseline plus 50 unique additions', checks, errors)
            require(gates.get('baseline55') == named_gate_source and extra == gates.get('extra50'), 'full gate manifest matches source baseline and exact extra-50 list', checks, errors)
            acceptance_gate_source = acceptance.get('required_gate_source', {})
            actual_base_pin = file_pin(BASE_GATES)
            require(acceptance_gate_source.get('bytes') == actual_base_pin['bytes'] and acceptance_gate_source.get('sha256') == actual_base_pin['sha256'], 'root acceptance pins baseline required-gate source', checks, errors)

            seeds_out = []
            for n, seed in enumerate(SEEDS, 1):
                text = step_text(stable_prefix, f'Run workspace tests with two fixed independent seeds (pass {n})')
                contains(text, f'PROPTEST_RNG_SEED: {seed}', f'workspace run uses required seed {seed}')
                contains(text, 'cargo test --workspace --all-targets --all-features --locked', f'workspace run {seed} uses exact all-targets/all-features command')
                summaries = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
                totals = {'passed': sum(int(x[1]) for x in summaries), 'failed': sum(int(x[2]) for x in summaries), 'ignored': sum(int(x[3]) for x in summaries)}
                require(len(summaries) == 367 and all(x[0] == 'ok' for x in summaries), f'{seed} has 367 successful test-suite summaries', checks, errors)
                require(totals == {'passed': 3615, 'failed': 0, 'ignored': 98}, f'{seed} totals are exactly 3615/0/98', checks, errors)
                named = re.findall(r'test (.+) \.\.\. (ok|ignored|FAILED)(?:, [^\n]*)?\s*$', text, re.M)
                require(sum(v == 'ok' for _, v in named) == 3615 and sum(v == 'ignored' for _, v in named) == 98 and not any(v == 'FAILED' for _, v in named), f'{seed} named outcomes are 3615 pass and 98 ignored', checks, errors)
                for name in required_names:
                    require(sum(x == name and y == 'ok' for x, y in named) == 1, f'{seed} required CI gate passed exactly once: {name}', checks, errors)
                seeds_out.append({'seed': seed, 'suites': len(summaries), **totals, 'named_passes': sum(v == 'ok' for _, v in named), 'named_ignored': sum(v == 'ignored' for _, v in named)})

            # The six workflow commands below contain seven selected JDK/full-class tests;
            # the functional-constructor test itself asserts the complete class under both JDKs.
            jdk_specs = [
                ('Run ignored JDK 25 instruction-boundary oracle', 'cargo test --test jvm_bytecode_oracle --locked -- --ignored --exact jdk25_instruction_boundaries_match_public_bytecode_inspection', ['jdk25_instruction_boundaries_match_public_bytecode_inspection'], 1),
                ('Run the ignored P3 Java 8 compile-and-execute comparison', 'cargo test --test p3_execution_comparison --locked -- --ignored', ['the_bulk_entrys_bodies_are_the_same_text_and_the_same_behaviour', 'the_corpus_is_read_the_same_way_by_every_legal_flag_set', 'the_p3_findings_are_replayed_by_compiling_and_executing_the_bodies'], 3),
                ('Run the functional-constructor full-class comparison', 'cargo test -p jarde-cli --test json_cli --locked -- --ignored --exact functional_constructor_arguments_replay_the_complete_class_on_both_jdks', ['functional_constructor_arguments_replay_the_complete_class_on_both_jdks'], 1),
                ('Run the BigDecimal Number full-class comparisons', 'cargo test --test p3_bigdecimal_number_widening --locked -- --ignored', ['bigdecimal_number_argument_generated_source_matches_frozen_runtime', 'main_only_bigdecimal_generated_source_matches_frozen_original_runtime'], 2),
                ('Run the nested int array full-class comparisons', 'cargo test --test p3_nested_int_array_compound_updates --locked -- --ignored --exact nested_int_array_updates_match_the_frozen_runner_oracle', ['nested_int_array_updates_match_the_frozen_runner_oracle'], 1),
                ('Run the returned int array full-class comparison', 'cargo test --test p3_nested_int_array_compound_updates --locked -- --ignored --exact returned_int_array_updates_compile_and_execute_as_a_complete_class', ['returned_int_array_updates_compile_and_execute_as_a_complete_class'], 1),
            ]
            jdk_evidence = []
            for title, command, tests, expected_count in jdk_specs:
                text = step_text(stable_prefix, title)
                contains(text, command, f'JDK/full-class step launched exact command: {title}')
                for test in tests:
                    contains(text, f'test {test} ... ok', f'JDK/full-class test passed: {test}')
                result = re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;', text)
                require(result is not None and int(result.group(1)) == expected_count, f'JDK/full-class command has {expected_count} actual passing test(s): {title}', checks, errors)
                jdk_evidence.append({'step': title, 'expected_passing_tests': expected_count, 'command_observed': True})
            full_class_gate_tests = ['jdk25_instruction_boundaries_match_public_bytecode_inspection', 'the_p3_findings_are_replayed_by_compiling_and_executing_the_bodies', 'functional_constructor_arguments_replay_the_complete_class_on_both_jdks', 'bigdecimal_number_argument_generated_source_matches_frozen_runtime', 'main_only_bigdecimal_generated_source_matches_frozen_original_runtime', 'nested_int_array_updates_match_the_frozen_runner_oracle', 'returned_int_array_updates_compile_and_execute_as_a_complete_class']
            require(len(full_class_gate_tests) == 7 and len(set(full_class_gate_tests)) == 7, 'seven named JDK/full-class gates enumerated uniquely', checks, errors)
            require(len(jdk_evidence) == 6, 'all six explicit JDK/full-class workflow command steps audited', checks, errors)

            # Remaining workflow job command evidence; API job/step conclusions above establish success.
            msrv_check = step_text('MSRV 1.88.0/', 'Check workspace on MSRV')
            contains(msrv_check, 'cargo check --workspace --all-targets --locked', 'MSRV all-target workspace check ran')
            supply_root = step_text('supply chain/', 'Check root workspace advisories, licenses, bans, and sources')
            contains(supply_root, 'cargo deny --all-features --workspace --locked --config ./deny.toml --manifest-path ./Cargo.toml check', 'root supply-chain check ran')
            supply_fuzz = step_text('supply chain/', 'Check fuzz workspace advisories, licenses, bans, and sources')
            contains(supply_fuzz, 'cargo deny --all-features --workspace --locked --config ./deny.toml --manifest-path ./fuzz/Cargo.toml check', 'fuzz supply-chain check ran')
            fuzz_install = step_text('fuzz smoke/', 'Install cargo-fuzz 0.13.2')
            contains(fuzz_install, 'cargo install cargo-fuzz --version 0.13.2 --locked', 'cargo-fuzz 0.13.2 installed in CI')
            fuzz_nightly = step_text('fuzz smoke/', 'Install nightly-2026-07-20')
            contains(fuzz_nightly, 'toolchain: nightly-2026-07-20', 'fuzz job uses pinned nightly')
            fuzz_steps = []
            for title, target in [('Run the bounded query smoke', 'query'), ('Run the bounded artifact-tree smoke', 'artifact_tree'), ('Run the bounded method-analysis smoke', 'method_analysis')]:
                text = step_text('fuzz smoke/', title)
                contains(text, f'cargo +nightly-2026-07-20 fuzz run {target}', f'fuzz target ran: {target}')
                contains(text, '-max_total_time=20', f'fuzz target uses bounded 20-second limit: {target}')
                fuzz_steps.append(target)
            require(len(fuzz_steps) == 3, 'all three configured fuzz smoke targets were present', checks, errors)
    except Exception as exc:
        errors.append(f'audit parsing error: {type(exc).__name__}: {exc}')
        member_pins = []
        seeds_out = []
        jdk_evidence = []

    expected_acceptance = acceptance.get('seeds', [])
    require(len(expected_acceptance) == 2 and all(x.get('suites') == 367 and x.get('passed') == 3615 and x.get('failed') == 0 and x.get('ignored') == 98 for x in expected_acceptance), 'root acceptance summarizes two exact 367/3615/0/98 seeds', checks, errors)
    report = {
        'status': 'accepted_independent_exact_product_ci_review' if not errors else 'rejected_independent_exact_product_ci_review',
        'scope': 'read-only independent review of captured c871 CI API responses and logs ZIP; does not rerun CI or toolchains',
        'product_sha': HEAD, 'branch': BRANCH, 'run_id': RUN,
        'capture': file_pin(capture_path), 'logs_zip': zpin,
        'root_acceptance': file_pin(ACCEPT), 'workflow': file_pin(WORKFLOW),
        'prior_audit_attempt': file_pin(PRIOR_ATTEMPT) if PRIOR_ATTEMPT.is_file() else None,
        'source_binding': file_pin(SOURCE_BINDING), 'required_gates': file_pin(GATES), 'extra50': file_pin(EXTRA),
        'api_observations': len(observations), 'api_raw_stream_count': len(raw_paths),
        'jobs': len(jobs), 'steps': step_total,
        'seeds': seeds_out, 'jdk_full_class_commands': jdk_evidence,
        'jdk_full_class_gate_tests': full_class_gate_tests if 'full_class_gate_tests' in locals() else [],
        'jdk_full_class_gate_count': len(full_class_gate_tests) if 'full_class_gate_tests' in locals() else 0,
        'checks': len(checks), 'errors': errors, 'check_labels': checks,
        'log_member_pins': member_pins,
        'limits': {'ci_strict_items': 365, 'ci_suites_per_seed': 367, 'passes_per_seed': 3615, 'ignored_per_seed': 98, 'gate_names': 105},
    }
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'checks': report['checks'], 'errors': errors, 'output': str(OUT)}, ensure_ascii=False))
    return 0 if not errors else 1

if __name__ == '__main__':
    raise SystemExit(main())
