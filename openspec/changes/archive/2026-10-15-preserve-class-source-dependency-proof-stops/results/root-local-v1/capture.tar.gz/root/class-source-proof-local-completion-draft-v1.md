# Local implementation completion draft

本稿只总结当前实现与待验收项，不作为最终通过报告；最终运行/CI以实际receipt为准。

- 基线a5e7d3已带cc305接口stopped工厂及boxed Error/report carrier；本片只接snapshot prebody与double-brace postbody，三个legacy邻居wrapper及全局Budget/merge优先级逐字未改。
- 前置直接Error与resolver发布的request-ending report及时交回原execution/完整diagnostics，复用stopped_before_recovery，无正文/AST/emitter及后继类投影；本次analysis/callee tuple保留。
- 后置保留已提交main/所有兄弟完整outcomes、正文及非空maps，只汇总原class stop和诊断，跳过anonymous等后继。
- 发布边界先使用原stops的Cancelled/Elapsed分类及已有token/ledger状态判断，不能checkpoint则只移动原诊断而不付费发布record。clear token的本地ClassHeaders/DependencyDepth仍可按原permit发布停止record。no-ledger local deadline分类修正目前仅静态覆盖，不冒称真实运行期到达；真实ledger deadline/cancel/header refusal分别有确定性测试。
- 5个真实proof控制：snapshot独立ledger token的收费内取消、elapsed0真实checkpoint及ClassHeaders0真实charge；postDB共享token收费内取消/真实deadline。初始tokens clear，at_stop保留实际已准入费用，first refusal之后ledger tail空、15 counted全部不增加；不注入Error、不预取消、不sleep。
- ordinary实验v4错误地删/重复终点Greet。既有算法到终点按命名即证明，不读终点，完整main是正确观察；错误拒绝断言保留为历史。修订只删/重复必须读取的中间Mid，保留原拒绝断言；原始fixture完全未动。
- focused v1 E0433、v2 E0716均零native，v3 first7真实234/0后14目标触1GiB guard且零integration，v4 class_source102/0 + 新target6/2后停止；所有raw/source/clean保留。v5完整12命令拆两个七目标，等待真实终态，不能从历史拼成通过。
- 需最终冻结CLI六档与整族H1源码保留/原8行oracle验证；interface8完整源/16refusal也须绑定同一最终CLI。最终自身workspace/MSRV/CI尚待产品commit，未勾选。
