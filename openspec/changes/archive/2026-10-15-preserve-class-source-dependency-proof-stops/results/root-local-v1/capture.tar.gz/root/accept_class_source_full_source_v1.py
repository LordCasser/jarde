from pathlib import Path
import json,hashlib
C=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');O=C/'class-source-proof-full-source-root-v1';P=O/'execution.json';D=json.loads(P.read_text());checks=[]
def pin(p):
 p=Path(p);return {'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def ck(v,s):
 checks.append({'check':s,'ok':bool(v)})
ck(D['status']=='expected_command_outcomes_observed_pending_independent_acceptance','complete run');ck(len(D['commands'])==16,'16 commands');ck(len(D['java_sources'])==11,'11 complete generated source files');ck(D['helper_noncomplete_requires_root_review']==[],'all eleven actual reports complete');ck(D['fixed_inputs_unchanged'] and D['source_closure_unchanged'] and D['target_absent'] and D['exact_emitted_java_unchanged'],'stable inputs/source/Java and absent target')
for x in D['fixed_inputs_before']+D['retained_inputs']+D['retained_classes']+D['java_sources']:
 ck(pin(x['path'])==x,'pin '+x['path'])
for n,row in enumerate(D['commands'],1):
 ck(row['exit_code']==0 and row['guard_stop'] is None,'exit/guard '+row['label'])
 for stream in row['streams'].values():ck(pin(stream['path'])==stream,'raw '+stream['path'])
 if n<=11:
  report=json.loads(Path(row['streams']['stdout']['path']).read_bytes());java=Path(D['java_sources'][n-1]['path']);ck(java.read_bytes()==report['text'].encode(),'exact generated text '+D['family'][n-1]);ck(report['execution']['status']=='complete','complete report '+D['family'][n-1])
 if n>=13:ck(Path(row['streams']['stdout']['path']).read_bytes()==(O/'expected.stdout.raw').read_bytes(),'original oracle '+row['label'])
ck(set(D['commands'][11]['argv'][-11:])=={x['path'] for x in D['java_sources']},'javac whole eleven-file family');ck(D['commands'][11]['argv'][1:3]==['--release','8'],'javac release8');ck(all('-Xverify:all' in x['argv'] for x in D['commands'][12:]),'four JVM verification runs')
source=json.loads((O/'source-manifest-before.json').read_text());ck(len(source)==4902 and source==json.loads((O/'source-manifest-after.json').read_text()),'4902 exact source closure');R=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde')
for x in source:
 p=R/x['path'];ck(p.stat().st_size==x['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'],'source '+x['path'])
out=C/'class-source-proof-full-source-root-acceptance-v1.json';assert not out.exists();errors=[x['check'] for x in checks if not x['ok']];out.write_text(json.dumps({'status':'accepted_complete_h1_source_recompile_and_runtime' if not errors else 'rejected','receipt':pin(P),'auditor':pin(__file__),'source_files':11,'actual_commands':16,'oracle_rows':8,'original_and_recompiled_jvms':['JDK23','Corretto8'],'checks':len(checks),'errors':errors,'scope':'One complete H1 family compiled with javac23 --release8 and compared byte-for-byte with its original oracle on Java23 and actual Java8; no broader CF count increase.'},indent=2)+'\n');print(out);print('checks',len(checks),'errors',errors);raise SystemExit(bool(errors))
