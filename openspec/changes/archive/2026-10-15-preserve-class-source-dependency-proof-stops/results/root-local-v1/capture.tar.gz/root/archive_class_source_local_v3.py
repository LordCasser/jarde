#!/usr/bin/env python3
"""Prepare a deterministic, explicit-allowlist evidence archive (not run for the draft)."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path, PurePosixPath

CACHE = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
AUX = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde')
SCHEMA = 'class-source-proof-local-evidence-v1'

# Only these named evidence trees are eligible. This deliberately avoids a cache-wide glob.
REQUIRED_TREES = ('class-source-proof-apply-context-v1', 'class-source-proof-old-source-v1', 'class-source-proof-old-root-v1', 'class-source-proof-initial-source-v1', 'class-source-proof-initial-source-v2', 'class-source-proof-initial-source-v3', 'class-source-proof-initial-source-v4', 'class-source-proof-initial-root-v1', 'class-source-proof-initial-root-v2', 'class-source-proof-initial-root-v3', 'class-source-proof-initial-root-v4', 'class-source-proof-initial-root-v5', 'class-source-proof-current-repro-harness-v1', 'class-source-proof-ordinary-controls-v1', 'class-source-proof-ordinary-controls-v2', 'class-source-proof-inflight-controls-v1', 'class-source-proof-inflight-controls-v2', 'class-source-proof-inflight-controls-v3', 'class-source-proof-member-stop-handoff-candidate-v1', 'class-source-proof-actual-production-static-review-v1', 'class-source-proof-focused-root-v1', 'class-source-proof-focused-failure-source-v1', 'class-source-proof-public-tests-v1', 'class-source-proof-public-tests-v2', 'class-source-six-cap-cli-harness-v1', 'CORE/class-source-proof-counted-ledger-control-candidate-v1', 'class-source-proof-focused-root-v2', 'class-source-proof-focused-root-v3', 'class-source-proof-focused-root-v4', 'class-source-proof-focused-root-v5', 'class-source-proof-focused-failure-source-v2', 'class-source-proof-focused-failure-source-v4', 'class-source-proof-final-static-review-v1', 'class-source-proof-full-source-replay-plan-v1', 'CORE/class-source-six-cap-cli-audit-v2', 'class-source-proof-final-focus-auditor-v1', 'class-source-proof-full-source-runner-v1')

# Root-level acceptance/review/command records not already in the trees above.
REQUIRED_FILES = ('class-source-proof-baseline-root-v1.json', 'class-source-proof-old-command-spec-v1.json', 'class-source-proof-old-root-acceptance-v1.json', 'class-source-proof-initial-command-spec-v1.json', 'class-source-proof-initial-command-spec-v2.json', 'class-source-proof-initial-failure-review-v1.json', 'class-source-proof-initial-failure-review-v2.json', 'class-source-proof-initial-failure-review-v3.json', 'class-source-proof-initial-failure-review-v4.json', 'class-source-proof-initial-v5-root-acceptance-v1.json', 'class-source-proof-initial-v5-root-independent-review-v1.json', 'class-source-proof-current-repro-root-acceptance-v1.json', 'class-source-proof-focused-command-spec-v1.json', 'class-source-proof-focused-failure-review-v1.json', 'class-source-proof-token-boundary-root-v1.json', 'new-class-source-stop-planning-root-input-review-v1.json', 'new-class-source-stop-root-static-review-v1.json', 'class-source-proof-focused-failure-review-v2.json', 'class-source-proof-focused-failure-review-v3.json', 'class-source-proof-focused-failure-review-v4.json', 'class-source-proof-focused-command-spec-v2.json', 'class-source-proof-focused-remaining-split-spec-v1.json', 'combined-proof-extra-ci-gates-root-v2.json', 'accept_product_ci_v3.py', 'class_view_runner_v1.py', 'class-source-proof-final-focus-root-acceptance-v1.json', 'class-source-proof-final-focus-independent-review-v1.json', 'class-source-proof-full-source-root-acceptance-v1.json', 'class-source-proof-full-source-independent-review-v1.json', 'CORE/class-source-six-cap-cli-independent-review-v1.json', 'class-source-six-cap-cli-prebody-execution-root-supplement-v1.json', 'class-source-six-cap-cli-auditor-v2-failure-review-v1.json', 'class-source-six-cap-cli-auditor-v3-failure-review-v1.json', 'audit_class_source_six_cap_cli_v3.py', 'audit_class_source_six_cap_cli_v4.py', 'accept_class_source_full_source_v1.py', 'archive_class_source_local_v3.py', 'class-source-proof-local-completion-draft-v1.md')

# Audit/acceptance scripts and exact current source needed to interpret this evidence.
AUX_FILES = ('src/facade.rs', 'tests/class_source_dependency_proof.rs', 'tests/p3_snapshot_hierarchy_widening.rs', 'crates/jarde-java/src/report.rs', 'crates/jarde-cli/tests/class_source_cli.rs')
TOOL_FILES = ('tools-prep/guard.py', 'tools-prep/target_scan.py', 'tools-prep/workspace_runner.py')


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_relative(name: str) -> str:
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or not path.parts:
        raise ValueError(f'unsafe archive name: {name}')
    return path.as_posix()


def add_file(files: dict[str, bytes], path: Path, archive_name: str) -> None:
    archive_name = safe_relative(archive_name)
    if path.is_symlink() or not path.is_file():
        raise ValueError(f'allowlisted input is not a regular non-symlink file: {path}')
    if 'target' in path.parts:
        raise ValueError(f'target artifacts are excluded: {path}')
    # No CLI executable is admitted; source files and frozen evidence inputs may be included.
    if path.name == 'jarde-cli' or re.fullmatch(r'jarde-cli(?:-[^.]*)?', path.name):
        raise ValueError(f'CLI binary is excluded: {path}')
    prefix = path.read_bytes()[:4]
    if (prefix.startswith(b'\x7fELF') or prefix.startswith(b'MZ')
            or prefix in (b'\xfe\xed\xfa\xce', b'\xce\xfa\xed\xfe',
                          b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe')):
        raise ValueError(f'native executable image is excluded: {path}')
    if archive_name in files:
        raise ValueError(f'duplicate archive path: {archive_name}')
    files[archive_name] = path.read_bytes()


def add_tree(files: dict[str, bytes], source: Path, archive_prefix: str) -> int:
    if source.is_symlink() or not source.is_dir():
        raise FileNotFoundError(f'required allowlisted evidence directory missing: {source}')
    count = 0
    for path in sorted(source.rglob('*')):
        if path.is_symlink():
            raise ValueError(f'symlink in allowlisted tree: {path}')
        if path.is_dir():
            continue
        if not path.is_file():
            raise ValueError(f'non-regular input in allowlisted tree: {path}')
        if '__pycache__' in path.parts:
            continue
        add_file(files, path, f'{archive_prefix}/{path.relative_to(source).as_posix()}')
        count += 1
    if not count:
        raise ValueError(f'allowlisted evidence directory is empty: {source}')
    return count


def optional_tree(files: dict[str, bytes], label: str, value: str | None) -> dict[str, object]:
    if value is None:
        return {'state': 'not_requested', 'path': None, 'files_included': 0}
    source = Path(value).expanduser()
    if not source.is_absolute():
        raise ValueError(f'optional evidence path must be absolute: {value}')
    if not source.exists():
        # The absence is explicit; it is never turned into an acceptance or a synthetic receipt.
        return {'state': 'expected_output_not_yet_present', 'path': str(source), 'files_included': 0}
    resolved = source.resolve(strict=True)
    if not resolved.is_relative_to(CACHE.resolve()):
        raise ValueError(f'optional outputs must remain under the validation cache: {source}')
    count = add_tree(files, resolved, f'optional/{label}')
    statuses = []
    for p in sorted(resolved.rglob('*.json')):
        try:
            value = json.loads(p.read_text())
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        if isinstance(value, dict) and isinstance(value.get('status'), str):
            statuses.append({'path': p.relative_to(resolved).as_posix(), 'status': value['status']})
    return {
        'state': 'present_raw_state_preserved',
        'path': str(resolved),
        'files_included': count,
        'recorded_statuses': statuses,
        'note': '原样保留现有状态；本打包器不推断或制造 accepted/terminal 状态。',
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', required=True, help='新输出目录；必须不存在，由调用者选择，避免覆盖原始证据。')
    parser.add_argument('--future-focused-out', help='可选 future focused 终态目录绝对路径；可尚不存在。')
    parser.add_argument('--six-cap-cli-out', help='可选 six-cap CLI 运行目录绝对路径；可尚不存在。')
    parser.add_argument('--full-source-out')
    parser.add_argument('--interface-full-source-out')
    args = parser.parse_args()

    output = Path(args.out).expanduser()
    if not output.is_absolute():
        raise ValueError('--out must be absolute')
    if output.exists():
        raise FileExistsError(f'output already exists; refusing to overwrite: {output}')
    if output.resolve().is_relative_to(AUX.resolve()):
        raise ValueError('refusing repository output; root must explicitly choose a cache/result destination')

    files: dict[str, bytes] = {}
    tree_counts = {}
    for relative in REQUIRED_TREES:
        source = CACHE / relative
        tree_counts[relative] = add_tree(files, source, f'evidence/{relative}')
    for relative in REQUIRED_FILES:
        add_file(files, CACHE / relative, f'root/{relative}')
    for relative in AUX_FILES:
        add_file(files, AUX / relative, f'aux-source/{relative}')
    for relative in TOOL_FILES:
        add_file(files, CACHE.parent / 'ordinary-try-list-20261014' / relative,
                 f'tools/{Path(relative).name}')

    optional = {
        'future_focused_terminal': optional_tree(files, 'future-focused', args.future_focused_out),
        'h1_full_source': optional_tree(files, 'h1-full-source', args.full_source_out),
        'interface_final_replay': optional_tree(files, 'interface-final-replay', args.interface_full_source_out),
        'six_cap_cli_terminal': optional_tree(files, 'six-cap-cli', args.six_cap_cli_out),
    }
    payloads = [
        {'path': name, 'bytes': len(data), 'sha256': sha256(data)}
        for name, data in sorted(files.items())
    ]
    manifest = {
        'schema': SCHEMA,
        'status': 'prepared_archive_inputs_only',
        'product_parent': 'a5e7d345611429215676d5650404532b7e41428b',
        'scope': 'class-source local evidence only; not product-own-CI or whole-workspace acceptance',
        'source_roots': {'aux': str(AUX), 'cache': str(CACHE)},
        'input_allowlist': {
            'required_trees': list(REQUIRED_TREES),
            'required_root_files': list(REQUIRED_FILES),
            'aux_source_files': list(AUX_FILES),
            'tool_files': list(TOOL_FILES),
            'optional_future_outputs': optional,
        },
        'included_tree_file_counts': tree_counts,
        'payload_count': len(payloads),
        'payloads': payloads,
        'exclusions': [
            '任何路径分量为 target 的文件',
            'jarde-cli/native image 可执行文件；允许作为文本证据的脚本',
            '符号链接和非普通文件',
            '未列入的 workspace/cache 路径及 __pycache__',
        ],
        'preservation': '源文件与已有 manifest 均只读复制；输出必须为新目录，不覆盖任何原始manifest或raw。',
    }
    files['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    output.mkdir(parents=True)
    archive = output / 'capture.tar.gz'
    with tarfile.open(archive, 'w:gz') as tar:
        for name, data in sorted(files.items()):
            info = tarfile.TarInfo(safe_relative(name))
            info.size = len(data)
            info.mode = 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            tar.addfile(info, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers()
        if len(members) != len(files) or any(not m.isfile() for m in members):
            raise AssertionError('archive member inventory is not exact regular files')
        for member in members:
            actual = tar.extractfile(member).read()
            if actual != files[member.name]:
                raise AssertionError(f'archive byte verification failed: {member.name}')
    review = {
        'status': 'accepted_local_archive_byte_integrity',
        'payloads': len(files) - 1,
        'members_reopened': len(files),
        'archive': {
            'path': archive.name,
            'bytes': archive.stat().st_size,
            'sha256': sha256(archive.read_bytes()),
        },
        'future_outputs': optional,
        'own_ci_accepted': False,
    }
    (output / 'archive-review.json').write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(review, ensure_ascii=False))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
