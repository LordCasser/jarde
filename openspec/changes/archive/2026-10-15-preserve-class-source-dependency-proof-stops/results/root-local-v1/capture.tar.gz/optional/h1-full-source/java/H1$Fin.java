// jarde: presentation of `H1$Fin` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
final class H1$Fin extends java.lang.Object {
    H1$Fin() {
        // @method <init>()V
        // @declaration a constructor of `H1$Fin`, member flags 0x0000
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public java.lang.String name() {
        // @method name()Ljava/lang/String;
        // @declaration an instance method of `H1$Fin`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        return "fin";
    }
}
