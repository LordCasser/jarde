// jarde: presentation of `H1$Greet` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
interface H1$Greet {
    public default java.lang.String hello(java.lang.String arg1) {
        // @method hello(Ljava/lang/String;)Ljava/lang/String;
        // @declaration an interface's default method of `H1$Greet`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        return "hi:" + arg1;
    }

    // jarde: no body: the member `name()Ljava/lang/String;` is declared abstract and its declaration carries no Code attribute
    public abstract java.lang.String name();
}
