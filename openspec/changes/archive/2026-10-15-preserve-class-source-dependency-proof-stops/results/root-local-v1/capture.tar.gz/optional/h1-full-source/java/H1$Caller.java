// jarde: presentation of `H1$Caller` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
class H1$Caller extends java.lang.Object {
    H1$Caller() {
        // @method <init>()V
        // @declaration a constructor of `H1$Caller`, member flags 0x0000
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    java.lang.String call(H1$Greet arg1) {
        // @method call(LH1$Greet;)Ljava/lang/String;
        // @declaration an instance method of `H1$Caller`, member flags 0x0000
        // recovered from bytecode; presentation is not claimed to compile
        return "call:" + arg1.name();
    }
}
