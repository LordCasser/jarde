// jarde: presentation of `H1$Multi` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
class H1$Multi extends java.lang.Object implements H1$Greet, H1$Other {
    H1$Multi() {
        // @method <init>()V
        // @declaration a constructor of `H1$Multi`, member flags 0x0000
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public java.lang.String name() {
        // @method name()Ljava/lang/String;
        // @declaration an instance method of `H1$Multi`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        return "multi";
    }

    public java.lang.String tag() {
        // @method tag()Ljava/lang/String;
        // @declaration an instance method of `H1$Multi`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        return "mtag";
    }
}
