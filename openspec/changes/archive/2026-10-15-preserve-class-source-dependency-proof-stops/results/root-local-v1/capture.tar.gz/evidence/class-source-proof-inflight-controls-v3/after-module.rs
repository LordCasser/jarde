#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum ClassProofStage { SnapshotPrebody, DoubleBracePostbody }

#[cfg(test)]
mod class_source_proof_inflight_tests {
    use super::*;
    use jarde_reader::budget::{BudgetDimension, CancellationToken};
    use jarde_reader::ledger::{LedgerEntryTiming, LedgerObserver, LedgerSite, OperationLedger, UsageOwner};
    use std::cell::RefCell;
    use std::sync::{Arc, Mutex, atomic::{AtomicUsize, Ordering}};

    #[derive(Clone, Copy, Debug)]
    pub(super) enum InFlightControl { CancelAfterRealCharge, ExpiredLedgerCheckpoint }

    #[derive(Debug)]
    pub(super) struct Observation {
        pub token: CancellationToken,
        pub usage_at_entry: UsageSnapshot,
        pub entries: Mutex<Vec<LedgerSite>>,
        pub refusals: Mutex<Vec<Option<BudgetDimension>>>,
        pub first_refusal_index: Mutex<Option<usize>>,
        charge_count: AtomicUsize,
        control: InFlightControl,
    }

    impl LedgerObserver for Observation {
        fn entry(&self, site: LedgerSite, _timing: Option<LedgerEntryTiming>) {
            self.entries.lock().unwrap().push(site);
            if matches!(site, LedgerSite::Charge(_)) {
                let prior = self.charge_count.fetch_add(1, Ordering::SeqCst);
                if matches!(self.control, InFlightControl::CancelAfterRealCharge) && prior == 0 {
                    self.token.cancel();
                }
            }
        }
        fn refusal(&self, _site: LedgerSite, dimension: Option<BudgetDimension>) {
            let mut refusals = self.refusals.lock().unwrap();
            if refusals.is_empty() {
                *self.first_refusal_index.lock().unwrap() =
                    Some(self.entries.lock().unwrap().len().saturating_sub(1));
            }
            refusals.push(dimension);
        }
    }

    #[derive(Clone, Copy)]
    struct Armed { stage: ClassProofStage, control: InFlightControl }
    thread_local! {
        static ARMED: RefCell<Option<Armed>> = const { RefCell::new(None) };
        static OBSERVED: RefCell<Option<Arc<Observation>>> = const { RefCell::new(None) };
    }

    pub(super) struct Guard;
    impl Drop for Guard {
        fn drop(&mut self) {
            ARMED.with(|slot| { slot.replace(None); });
            OBSERVED.with(|slot| { slot.replace(None); });
        }
    }

    pub(super) fn arm(stage: ClassProofStage, control: InFlightControl) -> Guard {
        ARMED.with(|slot| {
            assert!(slot.borrow().is_none(), "class-source proof controls do not nest");
            slot.replace(Some(Armed { stage, control }));
        });
        Guard
    }

    /// Called at the real proof boundary. The new operation ledger uses the current limits and
    /// shared token; only elapsed=0 is changed for the deadline mode. No stop is injected.
    pub(super) fn at(stage: ClassProofStage, method: &PhysicalMethodId, budget: &mut Budget) {
        if method.name.0 != b"main" || method.descriptor.0 != b"([Ljava/lang/String;)V" { return; }
        let armed = ARMED.with(|slot| {
            if slot.borrow().is_some_and(|armed| armed.stage == stage) {
                slot.borrow_mut().take()
            } else { None }
        });
        let Some(armed) = armed else { return; };
        let usage_at_entry = budget.usage();
        let token = budget.cancellation_token();
        assert!(!token.is_cancelled(), "control starts with a clear token");
        let mut limits = budget.limits().clone();
        if matches!(armed.control, InFlightControl::ExpiredLedgerCheckpoint) {
            limits.elapsed_millis = 0;
        }
        let entry = Budget::with_cancellation_token(limits, token.clone());
        let observer = Arc::new(Observation {
            token,
            usage_at_entry,
            entries: Mutex::new(Vec::new()),
            refusals: Mutex::new(Vec::new()),
            first_refusal_index: Mutex::new(None),
            charge_count: AtomicUsize::new(0),
            control: armed.control,
        });
        let ledger = OperationLedger::new(&entry).with_observer(observer.clone());
        budget.with_ledger(ledger, UsageOwner::Methods);
        OBSERVED.with(|slot| {
            assert!(slot.borrow().is_none(), "one proof-control observer is active");
            slot.replace(Some(observer));
        });
    }

    pub(super) fn observation() -> Arc<Observation> {
        OBSERVED.with(|slot| slot.borrow().as_ref().expect("proof boundary was reached").clone())
    }


    const H1_JAR: &[u8] = include_bytes!(
        "../openspec/evidence/java-syntax-2026-10-02/user-hierarchy-widening-patrol/fixture/hier/hier-fam.jar"
    );

    fn open_h1() -> (ArtifactSnapshot, ClassSourceRequest) {
        let mut limits = crate::task_budget(&[]).unwrap().limits().clone();
        limits.elapsed_millis = u64::MAX;
        let snapshot = Engine::new().open(
            ArtifactInput::bytes(H1_JAR.to_vec()), &mut Budget::new(limits),
        ).unwrap();
        let request = ClassSourceRequest {
            class: ClassRef::Name { class: ClassNameQuery::internal("H1") },
            environment: EnvironmentRequest {
                snapshot: snapshot.id().clone(),
                scope: PhysicalScope::SnapshotAll,
                policy: EnvironmentPolicy::PlainJar,
                profile: RuntimeProfile {
                    java_release: 8,
                    multi_release: jarde_reader::view::MultiReleasePolicy::Disabled,
                    layout: LayoutMode::Generic,
                },
                loader: LoaderId("app".to_owned()),
            },
        };
        (snapshot, request)
    }

    fn run_h1(snapshot: &ArtifactSnapshot, request: &ClassSourceRequest) -> ClassSourceReport {
        let mut limits = crate::task_budget(&[]).unwrap().limits().clone();
        limits.elapsed_millis = u64::MAX;
        limits.class_headers = u64::MAX;
        let crate::OperationOutcome::Performed(report) = Engine::new().class_source_with_evidence(
            slice::from_ref(snapshot), request, &RecoveryEvidenceRequest::all(),
            &mut Budget::new(limits),
        ).unwrap() else { panic!("H1 public class-source request is selected"); };
        report
    }

    fn main_position(report: &ClassSourceReport) -> usize {
        report.methods.iter().position(|member| {
            member.item.identity.name.0 == b"main"
                && member.item.identity.descriptor.0 == b"([Ljava/lang/String;)V"
        }).expect("H1.main([Ljava/lang/String;)V is in the physical class method table")
    }

    fn assert_execution_stop(report: &ClassSourceReport, control: InFlightControl) {
        match control {
            InFlightControl::CancelAfterRealCharge => assert!(
                matches!(report.execution, ExecutionReport::Cancelled { .. }),
                "{:?}", report.execution),
            InFlightControl::ExpiredLedgerCheckpoint => assert!(
                matches!(report.execution, ExecutionReport::Partial {
                    reason: TerminationReason::BudgetExceeded { dimension: BudgetDimension::ElapsedMillis }, ..
                }), "{:?}", report.execution),
        }
    }

    fn assert_observer_stopped(observer: &Observation, control: InFlightControl) {
        let entries = observer.entries.lock().unwrap();
        let refusals = observer.refusals.lock().unwrap();
        let first = *observer.first_refusal_index.lock().unwrap()
            .expect("the attached ledger observed a real refusal");
        assert!(!entries.is_empty());
        assert!(first < entries.len());
        match control {
            InFlightControl::CancelAfterRealCharge => {
                assert!(entries[..=first].iter().any(|site| matches!(site, LedgerSite::Charge(_))),
                    "cancellation is triggered only after an accepted real charge");
                assert!(observer.token.is_cancelled());
                assert_eq!(refusals.first(), Some(&None), "first stop is cancellation");
            }
            InFlightControl::ExpiredLedgerCheckpoint => {
                assert_eq!(entries[first], LedgerSite::Checkpoint, "deadline is checked at a real checkpoint");
                assert_eq!(refusals.first(), Some(&Some(BudgetDimension::ElapsedMillis)));
                assert!(observer.token.is_cancelled(), "recording the first ledger stop cancels its shared token");
            }
        }
        let tail = &entries[first + 1..];
        assert!(tail.iter().all(|site| matches!(site, LedgerSite::Charge(_))),
            "there is no later proof poll/charge path beyond at most result publication: {tail:?}");
        assert!(tail.len() <= 1, "at most one existing result-item publication charge may follow: {tail:?}");
    }

    fn assert_no_post_stop_body_work(report: &ClassSourceReport, observer: &Observation) {
        for dimension in CountedBudgetDimension::ALL {
            if matches!(dimension, CountedBudgetDimension::AnalysisSteps | CountedBudgetDimension::ClassHeaders) {
                continue; // The proof itself can perform admitted work before its first refusal.
            }
            let before = observer.usage_at_entry.counted_usage(dimension);
            let after = report.usage.counted_usage(dimension);
            if dimension == CountedBudgetDimension::ResultItems {
                assert!(after <= before + 1, "only an existing one-record publication may follow the stop: {before} -> {after}");
            } else {
                assert_eq!(after, before, "no body/evidence/output work after proof entry for {dimension:?}");
            }
        }
    }

    fn exercise_h1_stage(stage: ClassProofStage, control: InFlightControl) {
        let (snapshot, request) = open_h1();
        let wide = run_h1(&snapshot, &request);
        assert!(matches!(wide.execution, ExecutionReport::Complete { .. }));
        let main_at = main_position(&wide);
        let wide_main = &wide.methods[main_at];
        let guard = arm(stage, control);
        let mut limits = crate::task_budget(&[]).unwrap().limits().clone();
        limits.elapsed_millis = u64::MAX;
        limits.class_headers = u64::MAX;
        let crate::OperationOutcome::Performed(stopped) = Engine::new().class_source_with_evidence(
            slice::from_ref(&snapshot), &request, &RecoveryEvidenceRequest::all(),
            &mut Budget::new(limits),
        ).unwrap() else { panic!("the public class-source request preserves its report"); };
        let observer = observation();
        drop(guard);
        assert_observer_stopped(&observer, control);
        assert_execution_stop(&stopped, control);
        assert_no_post_stop_body_work(&stopped, &observer);
        assert!(!stopped.diagnostics.is_empty(), "the proof stop remains diagnosed");
        match stage {
            ClassProofStage::SnapshotPrebody => {
                // Snapshot proof stops before recovery of H1.main. Physical records before it are
                // reliable; cancellation may refuse publication of main's own stopped record.
                assert!(stopped.methods.iter().all(|member| member.item.index <= wide_main.item.index));
                let expected_prefix: Vec<_> = wide.methods.iter()
                    .filter(|member| member.item.index < wide_main.item.index).collect();
                let actual_prefix: Vec<_> = stopped.methods.iter()
                    .filter(|member| member.item.index < wide_main.item.index).collect();
                assert!(!expected_prefix.is_empty(), "the pinned H1 fixture has five reliable siblings before main");
                assert_eq!(actual_prefix.len(), expected_prefix.len(),
                    "all five earlier physical methods remain in the reliable prefix");
                for (actual, expected) in actual_prefix.iter().zip(expected_prefix.iter()) {
                    assert_eq!(actual.item.identity, expected.item.identity);
                    assert_eq!(actual.text, expected.text);
                }
                let stop_record = stopped.methods.iter().find(|member| member.item.identity.name.0 == b"main");
                if let Some(member) = stop_record {
                    let class_source::ClassSourceOutcome::Recovered { report: body, .. } = &member.outcome else {
                        panic!("an emitted main stop record retains its typed outcome");
                    };
                    assert_eq!(body.content, RecoveryContent::NotProduced);
                    assert!(body.text.is_empty() && body.source_map.segments().is_empty());
                }
                assert!(stopped.coverage.artifact_structural.scanned.iter().any(|range|
                    range.label == "class_source_bodies" && range.end > wide_main.item.index));
                let expected_suffix: Vec<_> = wide.methods.iter()
                    .filter(|member| member.item.index > wide_main.item.index).collect();
                let skipped_suffix: Vec<_> = stopped.coverage.artifact_structural.skipped.iter()
                    .filter(|range| range.label == "class_source_bodies"
                        && range.start > wide_main.item.index).collect();
                if expected_suffix.is_empty() {
                    assert!(skipped_suffix.is_empty(),
                        "the pinned H1.main is the last physical method; do not invent skipped suffix coverage");
                } else {
                    assert!(skipped_suffix.iter().any(|range|
                        range.start == wide_main.item.index + 1
                            && range.end == expected_suffix.last().unwrap().item.index + 1),
                        "a real physical suffix after main must be represented as skipped");
                }
            }
            ClassProofStage::DoubleBracePostbody => {
                // The stage runs after recovery has committed. Preserve every method identity and
                // raw body/source map, including H1.main; only aggregate execution is stopped.
                assert_eq!(stopped.methods.len(), wide.methods.len());
                for (actual, expected) in stopped.methods.iter().zip(&wide.methods) {
                    assert_eq!(actual.item.identity, expected.item.identity);
                    assert_eq!(actual.text, expected.text);
                }
                let class_source::ClassSourceOutcome::Recovered { report: body, .. } = &stopped.methods[main_at].outcome else {
                    panic!("H1.main's completed raw recovery remains committed");
                };
                let class_source::ClassSourceOutcome::Recovered { report: wide_body, .. } = &wide_main.outcome else {
                    panic!("wide H1.main has its raw recovery report");
                };
                assert!(body.produced());
                assert_eq!(body.text, wide_body.text);
                assert_eq!(body.source_map.segments(), wide_body.source_map.segments());
                assert!(stopped.text.contains("public static void main"));
            }
        }
    }

    #[test]
    fn public_h1_snapshot_proof_cancel_after_charge_retains_only_reliable_prefix() {
        exercise_h1_stage(ClassProofStage::SnapshotPrebody, InFlightControl::CancelAfterRealCharge);
    }

    #[test]
    fn public_h1_snapshot_proof_expired_checkpoint_stops_before_body_recovery() {
        exercise_h1_stage(ClassProofStage::SnapshotPrebody, InFlightControl::ExpiredLedgerCheckpoint);
    }

    #[test]
    fn public_h1_double_brace_cancel_after_charge_keeps_committed_main_and_siblings() {
        exercise_h1_stage(ClassProofStage::DoubleBracePostbody, InFlightControl::CancelAfterRealCharge);
    }

    #[test]
    fn public_h1_double_brace_expired_checkpoint_keeps_committed_main_and_siblings() {
        exercise_h1_stage(ClassProofStage::DoubleBracePostbody, InFlightControl::ExpiredLedgerCheckpoint);
    }
}

