

    const H1_JAR: &[u8] = include_bytes!(
        "../openspec/evidence/java-syntax-2026-10-02/user-hierarchy-widening-patrol/fixture/hier/hier-fam.jar"
    );

    fn open_h1() -> (ArtifactSnapshot, ClassSourceRequest) {
        let mut limits = crate::task_budget(&[]).unwrap().limits().clone();
        limits.elapsed_millis = u64::MAX;
        let snapshot = Engine::new().open(
            ArtifactInput::bytes(H1_JAR.to_vec()), &mut Budget::new(limits),
        ).unwrap();
        let request = ClassSourceRequest {
            class: ClassRef::Name { class: ClassNameQuery::internal("H1") },
            environment: EnvironmentRequest {
                snapshot: snapshot.id().clone(),
                scope: PhysicalScope::SnapshotAll,
                policy: EnvironmentPolicy::PlainJar,
                profile: RuntimeProfile {
                    java_release: 8,
                    multi_release: jarde_reader::view::MultiReleasePolicy::Disabled,
                    layout: LayoutMode::Generic,
                },
                loader: LoaderId("app".to_owned()),
            },
        };
        (snapshot, request)
    }

    fn run_h1(snapshot: &ArtifactSnapshot, request: &ClassSourceRequest) -> ClassSourceReport {
        let mut limits = crate::task_budget(&[]).unwrap().limits().clone();
        limits.elapsed_millis = u64::MAX;
        limits.class_headers = u64::MAX;
        let crate::OperationOutcome::Performed(report) = Engine::new().class_source_with_evidence(
            slice::from_ref(snapshot), request, &RecoveryEvidenceRequest::all(),
            &mut Budget::new(limits),
        ).unwrap() else { panic!("H1 public class-source request is selected"); };
        report
    }

    fn main_position(report: &ClassSourceReport) -> usize {
        report.methods.iter().position(|member| member.item.identity.name.0 == b"main")
            .expect("H1.main is in the physical class method table")
    }

    fn assert_execution_stop(report: &ClassSourceReport, control: InFlightControl) {
        match control {
            InFlightControl::CancelAfterRealCharge => assert!(
                matches!(report.execution, ExecutionReport::Cancelled { .. }),
                "{:?}", report.execution),
            InFlightControl::ExpiredLedgerCheckpoint => assert!(
                matches!(report.execution, ExecutionReport::Partial {
                    reason: TerminationReason::BudgetExceeded { dimension: BudgetDimension::ElapsedMillis }, ..
                }), "{:?}", report.execution),
        }
    }

    fn assert_observer_stopped(observer: &Observation, control: InFlightControl) {
        let entries = observer.entries.lock().unwrap();
        let refusals = observer.refusals.lock().unwrap();
        let first = *observer.first_refusal_index.lock().unwrap()
            .expect("the attached ledger observed a real refusal");
        assert!(!entries.is_empty());
        assert!(first < entries.len());
        match control {
            InFlightControl::CancelAfterRealCharge => {
                assert!(entries[..=first].iter().any(|site| matches!(site, LedgerSite::Charge(_))),
                    "cancellation is triggered only after an accepted real charge");
                assert!(observer.token.is_cancelled());
                assert_eq!(refusals.first(), Some(&None), "first stop is cancellation");
            }
            InFlightControl::ExpiredLedgerCheckpoint => {
                assert_eq!(entries[first], LedgerSite::Checkpoint, "deadline is checked at a real checkpoint");
                assert_eq!(refusals.first(), Some(&Some(BudgetDimension::ElapsedMillis)));
                assert!(observer.token.is_cancelled(), "recording the first ledger stop cancels its shared token");
            }
        }
        let tail = &entries[first + 1..];
        assert!(tail.iter().all(|site| matches!(site, LedgerSite::Charge(_))),
            "there is no later proof poll/charge path beyond at most result publication: {tail:?}");
        assert!(tail.len() <= 1, "at most one existing result-item publication charge may follow: {tail:?}");
    }

    fn assert_no_post_stop_body_work(report: &ClassSourceReport, observer: &Observation) {
        for dimension in CountedBudgetDimension::ALL {
            if matches!(dimension, CountedBudgetDimension::AnalysisSteps | CountedBudgetDimension::ClassHeaders) {
                continue; // The proof itself can perform admitted work before its first refusal.
            }
            let before = observer.usage_at_entry.counted_usage(dimension);
            let after = report.usage.counted_usage(dimension);
            if dimension == CountedBudgetDimension::ResultItems {
                assert!(after <= before + 1, "only an existing one-record publication may follow the stop: {before} -> {after}");
            } else {
                assert_eq!(after, before, "no body/evidence/output work after proof entry for {dimension:?}");
            }
        }
    }

    fn exercise_h1_stage(stage: ClassProofStage, control: InFlightControl) {
        let (snapshot, request) = open_h1();
        let wide = run_h1(&snapshot, &request);
        assert!(matches!(wide.execution, ExecutionReport::Complete { .. }));
        let main_at = main_position(&wide);
        let wide_main = &wide.methods[main_at];
        let guard = arm(stage, control);
        let mut limits = crate::task_budget(&[]).unwrap().limits().clone();
        limits.elapsed_millis = u64::MAX;
        limits.class_headers = u64::MAX;
        let crate::OperationOutcome::Performed(stopped) = Engine::new().class_source_with_evidence(
            slice::from_ref(&snapshot), &request, &RecoveryEvidenceRequest::all(),
            &mut Budget::new(limits),
        ).unwrap() else { panic!("the public class-source request preserves its report"); };
        let observer = observation();
        drop(guard);
        assert_observer_stopped(&observer, control);
        assert_execution_stop(&stopped, control);
        assert_no_post_stop_body_work(&stopped, &observer);
        assert!(!stopped.diagnostics.is_empty(), "the proof stop remains diagnosed");
        match stage {
            ClassProofStage::SnapshotPrebody => {
                // Snapshot proof stops before recovery of H1.main. Physical records before it are
                // reliable; cancellation may refuse publication of main's own stopped record.
                assert!(stopped.methods.iter().all(|member| member.item.index <= wide_main.item.index));
                for (actual, expected) in stopped.methods.iter()
                    .filter(|member| member.item.index < wide_main.item.index)
                    .zip(wide.methods.iter().filter(|member| member.item.index < wide_main.item.index)) {
                    assert_eq!(actual.item.identity, expected.item.identity);
                    assert_eq!(actual.text, expected.text);
                }
                let stop_record = stopped.methods.iter().find(|member| member.item.identity.name.0 == b"main");
                if let Some(member) = stop_record {
                    let class_source::ClassSourceOutcome::Recovered { report: body, .. } = &member.outcome else {
                        panic!("an emitted main stop record retains its typed outcome");
                    };
                    assert_eq!(body.content, RecoveryContent::NotProduced);
                    assert!(body.text.is_empty() && body.source_map.segments().is_empty());
                }
                assert!(stopped.coverage.artifact_structural.scanned.iter().any(|range|
                    range.label == "class_source_bodies" && range.end > wide_main.item.index));
                assert!(stopped.coverage.artifact_structural.skipped.iter().any(|range|
                    range.label == "class_source_bodies" && range.start > wide_main.item.index));
            }
            ClassProofStage::DoubleBracePostbody => {
                // The stage runs after recovery has committed. Preserve every method identity and
                // raw body/source map, including H1.main; only aggregate execution is stopped.
                assert_eq!(stopped.methods.len(), wide.methods.len());
                for (actual, expected) in stopped.methods.iter().zip(&wide.methods) {
                    assert_eq!(actual.item.identity, expected.item.identity);
                    assert_eq!(actual.text, expected.text);
                }
                let class_source::ClassSourceOutcome::Recovered { report: body, .. } = &stopped.methods[main_at].outcome else {
                    panic!("H1.main's completed raw recovery remains committed");
                };
                let class_source::ClassSourceOutcome::Recovered { report: wide_body, .. } = &wide_main.outcome else {
                    panic!("wide H1.main has its raw recovery report");
                };
                assert!(body.produced());
                assert_eq!(body.text, wide_body.text);
                assert_eq!(body.source_map.segments(), wide_body.source_map.segments());
                assert!(stopped.text.contains("public static void main"));
            }
        }
    }

    #[test]
    fn public_h1_snapshot_proof_cancel_after_charge_retains_only_reliable_prefix() {
        exercise_h1_stage(ClassProofStage::SnapshotPrebody, InFlightControl::CancelAfterRealCharge);
    }

    #[test]
    fn public_h1_snapshot_proof_expired_checkpoint_stops_before_body_recovery() {
        exercise_h1_stage(ClassProofStage::SnapshotPrebody, InFlightControl::ExpiredLedgerCheckpoint);
    }

    #[test]
    fn public_h1_double_brace_cancel_after_charge_keeps_committed_main_and_siblings() {
        exercise_h1_stage(ClassProofStage::DoubleBracePostbody, InFlightControl::CancelAfterRealCharge);
    }

    #[test]
    fn public_h1_double_brace_expired_checkpoint_keeps_committed_main_and_siblings() {
        exercise_h1_stage(ClassProofStage::DoubleBracePostbody, InFlightControl::ExpiredLedgerCheckpoint);
    }
