//! Ordinary dependency refusal controls for the public class-source proof-stop matrix.
//! This target supplements the six cap controls with missing and ambiguous H1 hierarchy inputs.
use jarde::*;
use rawzip::{CompressionMethod, ZipArchive, ZipArchiveWriter, path::EntryPath};
use std::io::{Cursor, Read, Write};

const H1_JAR: &[u8] = include_bytes!(
    "../openspec/evidence/java-syntax-2026-10-02/user-hierarchy-widening-patrol/fixture/hier/hier-fam.jar"
);
const GREET: &[u8] = b"H1$Greet.class";

#[derive(Clone, Copy)]
enum DependencyVariant { MissingGreet, DuplicateGreet }

fn repackage_h1(variant: DependencyVariant) -> Vec<u8> {
    let archive = ZipArchive::from_slice(H1_JAR).expect("pinned H1 fixture is a ZIP archive");
    let mut entries = archive.entries();
    let mut classes = Vec::<(Vec<u8>, Vec<u8>)>::new();
    while let Some(header) = entries.next_entry().expect("H1 central-directory entry reads") {
        let name = header.file_path().as_ref().to_vec();
        if !name.ends_with(b".class") { continue; }
        if matches!(variant, DependencyVariant::MissingGreet) && name == GREET { continue; }
        let entry = archive.get_entry(header.wayfinder()).expect("entry is addressable");
        let decoder = flate2::bufread::DeflateDecoder::new(entry.data());
        let mut reader = entry.verifying_reader(decoder);
        let mut bytes = Vec::new();
        reader.read_to_end(&mut bytes).expect("class entry verifies and inflates");
        classes.push((name, bytes));
    }
    assert_eq!(classes.iter().filter(|(name, _)| name == b"H1.class").count(), 1,
        "the requested target class is retained exactly once");
    let greet_count = classes.iter().filter(|(name, _)| name == GREET).count();
    match variant {
        DependencyVariant::MissingGreet => assert_eq!(greet_count, 0),
        DependencyVariant::DuplicateGreet => assert_eq!(greet_count, 1),
    }

    let mut output = Cursor::new(Vec::new());
    {
        let mut writer = ZipArchiveWriter::new(&mut output);
        for (name, bytes) in &classes {
            let (mut entry, config) = writer.new_file(EntryPath::verbatim(name.clone()))
                .compression_method(CompressionMethod::new(0)).start().unwrap();
            let mut data = config.wrap(&mut entry);
            data.write_all(bytes).unwrap();
            let (_, descriptor) = data.finish().unwrap();
            entry.finish(descriptor).unwrap();
            if matches!(variant, DependencyVariant::DuplicateGreet) && name.as_slice() == GREET {
                let (mut duplicate, config) = writer.new_file(EntryPath::verbatim(name.clone()))
                    .compression_method(CompressionMethod::new(0)).start().unwrap();
                let mut data = config.wrap(&mut duplicate);
                data.write_all(bytes).unwrap();
                let (_, descriptor) = data.finish().unwrap();
                duplicate.finish(descriptor).unwrap();
            }
        }
        writer.finish().unwrap();
    }
    let bytes = output.into_inner();
    let check = ZipArchive::from_slice(&bytes).expect("derived class-only archive is readable");
    let mut check_entries = check.entries();
    let mut target_count = 0;
    let mut greet_count = 0;
    while let Some(header) = check_entries.next_entry().expect("derived directory reads") {
        let name = header.file_path().as_ref();
        if name == b"H1.class" { target_count += 1; }
        if name == GREET { greet_count += 1; }
    }
    assert_eq!(target_count, 1, "derivation keeps the H1 target unique");
    match variant {
        DependencyVariant::MissingGreet => assert_eq!(greet_count, 0),
        DependencyVariant::DuplicateGreet => assert_eq!(greet_count, 2),
    }
    bytes
}

fn wide_budget() -> Budget {
    let mut limits = task_budget(&[]).expect("task defaults are available").limits().clone();
    limits.class_headers = u64::MAX;
    limits.elapsed_millis = u64::MAX;
    Budget::new(limits)
}

fn public_h1_report(jar: Vec<u8>) -> ClassSourceReport {
    let mut budget = wide_budget();
    let snapshot = Engine::new().open(ArtifactInput::bytes(jar), &mut budget)
        .expect("derived fixture opens");
    let request = ClassSourceRequest {
        class: ClassRef::Name { class: ClassNameQuery::internal("H1") },
        environment: EnvironmentRequest {
            snapshot: snapshot.id().clone(),
            scope: PhysicalScope::SnapshotAll,
            policy: EnvironmentPolicy::PlainJar,
            profile: RuntimeProfile {
                java_release: 8,
                multi_release: MultiReleasePolicy::Disabled,
                layout: LayoutMode::Generic,
            },
            loader: LoaderId("app".to_owned()),
        },
    };
    let OperationOutcome::Performed(report) = Engine::new().class_source_with_evidence(
        std::slice::from_ref(&snapshot), &request, &RecoveryEvidenceRequest::all(), &mut budget,
    ).expect("the unique requested H1 class is still selected") else {
        panic!("the target class remains a unique performed public class-source request");
    };
    report
}

fn assert_ordinary_greet_refusal(report: &ClassSourceReport) {
    assert!(report.declaration.is_some(), "the selected physical H1 declaration remains present");
    assert!(matches!(report.execution, ExecutionReport::Complete { .. }), "{:?}", report.execution);
    let main = report.methods.iter().find(|method|
        method.item.identity.name.0 == b"main"
            && method.item.identity.descriptor.0 == b"([Ljava/lang/String;)V")
        .expect("H1.main remains a physical method");
    let ClassSourceOutcome::Recovered { report: body, analysis } = &main.outcome else {
        panic!("missing/ambiguous dependency is an ordinary value-level refusal, not a stopped main");
    };
    assert!(matches!(analysis.execution, ExecutionReport::Complete { .. }));
    assert!(matches!(body.execution, ExecutionReport::Complete { .. }));
    assert!(body.text.contains("no safe reference conversion evidence"),
        "the original source-level refusal remains visible:\n{}", body.text);
    assert!(body.text.contains("H1$Greet") || body.text.contains("H1.Greet"),
        "the physical hierarchy spelling remains visible:\n{}", body.text);
}

#[test]
fn missing_h1_greet_is_an_ordinary_public_class_source_refusal() {
    let report = public_h1_report(repackage_h1(DependencyVariant::MissingGreet));
    assert_ordinary_greet_refusal(&report);
}

#[test]
fn duplicate_h1_greet_is_an_ordinary_public_class_source_refusal() {
    let report = public_h1_report(repackage_h1(DependencyVariant::DuplicateGreet));
    assert_ordinary_greet_refusal(&report);
}
