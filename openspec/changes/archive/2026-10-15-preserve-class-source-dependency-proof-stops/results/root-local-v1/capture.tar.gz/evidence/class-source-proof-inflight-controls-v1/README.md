# Class-source in-flight proof controls — cache candidate

`candidate.patch` adds narrow `cfg(test)` hooks at the snapshot prebody proof and double-brace postbody allocation proof, plus a scoped ledger observer that can cancel only after a real accepted charge or create a fresh elapsed-zero ledger checked at a real checkpoint. It leaves the existing interface callback module untouched.

Static source review locates the snapshot entry before class-source body recovery and the double-brace entry after the main/member report has been delivered. The latter error returns through the existing projection handler; the class-source request tail guard returns before anonymous-interface projection when aggregate execution stops. See `test-protocol.md` for the public H1 stage/control matrix and expected observations.

This is only a deterministic hook candidate. It does not yet add the public H1 test bodies required by OpenSpec tasks 2.3/3.2 and is uncompiled, unformatted, and unrun. It is not acceptance evidence. Apply only after owner integration/review of the boxed interface and third production patches.
