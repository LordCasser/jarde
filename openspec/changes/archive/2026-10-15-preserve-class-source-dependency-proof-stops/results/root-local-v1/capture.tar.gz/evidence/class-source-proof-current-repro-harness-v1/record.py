#!/usr/bin/env python3
"""Record three historical H1 requests with the frozen interface-proof CLI."""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
CORE = HERE.parent
ROOT = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde')
CLI = CORE / 'jarde-cli-interface-proof-v4'
BUILD_RECEIPT = CORE / 'interface-proof-focused-root-v4/execution.json'
TOOLS = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep')
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3
MAIN_NAME = list(b'main')
MAIN_DESCRIPTOR = list(b'([Ljava/lang/String;)V')


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def pin(path: Path) -> dict:
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f'required regular, unlinked input missing: {path}')
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot import {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write(path: Path, value) -> None:
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def selected_main(report: dict) -> list[dict]:
    # Match the physical method identity; do not select an overloaded method by display text.
    return [method for method in report.get('methods', [])
            if method.get('item', {}).get('identity', {}).get('name') == MAIN_NAME
            and method.get('item', {}).get('identity', {}).get('descriptor') == MAIN_DESCRIPTOR]


def observations(report: dict) -> dict:
    mains = selected_main(report)
    result = {'class_execution': report.get('execution'), 'class_outcome': report.get('outcome'),
              'class_usage': report.get('usage'), 'class_limits': report.get('limits'),
              'class_diagnostics': report.get('diagnostics'), 'main_match_count': len(mains),
              'class_text_sha256': hashlib.sha256(report.get('text', '').encode()).hexdigest(),
              'methods': []}
    for method in mains:
        outcome = method.get('outcome', {})
        recovery = outcome.get('report', {})
        result['methods'].append({
            'identity': method['item']['identity'], 'outcome_kind': outcome.get('kind'),
            'analysis': outcome.get('analysis'), 'execution': recovery.get('execution'),
            'outcome': recovery.get('outcome'), 'content': recovery.get('content'),
            'diagnostics': recovery.get('diagnostics'),
            'text_sha256': hashlib.sha256(method.get('text', '').encode()).hexdigest(),
            'recovery_text_sha256': hashlib.sha256(recovery.get('text', '').encode()).hexdigest(),
        })
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=HERE / 'run-v1')
    args = parser.parse_args()
    out = args.out.resolve()
    if out.exists() or out.is_symlink() or out.is_relative_to(ROOT):
        raise SystemExit('output must be a fresh directory outside the repository')
    if (ROOT / 'target').exists():
        raise SystemExit('wait for the guarded build receipt and its clean target before recording')
    preparation = json.loads((HERE / 'preparation-inputs.json').read_text())
    for expected in preparation['inputs']:
        if pin(Path(expected['path'])) != expected:
            raise SystemExit(f'preparation input changed: {expected["path"]}')
    receipt = json.loads(BUILD_RECEIPT.read_text())
    if receipt.get('status') != 'expected_command_outcomes_observed_pending_independent_acceptance':
        raise SystemExit('the interface-proof v4 build receipt has not completed successfully')
    if not receipt.get('target_absent') or receipt.get('workspace_root') != str(ROOT):
        raise SystemExit('build receipt source/clean-target identity does not match')
    cli_pin = pin(CLI)
    recorded_cli = receipt.get('frozen_cli') or {}
    if any(recorded_cli.get(key) != cli_pin[key] for key in ('path', 'bytes', 'sha256')):
        raise SystemExit('frozen CLI bytes do not match the completed v4 build receipt')
    source_before = receipt.get('source_manifest_before')
    if not source_before or source_before != receipt.get('source_manifest_after'):
        raise SystemExit('completed build receipt lacks an unchanged source closure')
    if any(row.get('guard_stop') for row in receipt.get('commands', [])):
        raise SystemExit('build receipt contains a guard stop')
    commands = json.loads((HERE / 'commands.json').read_text())
    if len(commands) != 3 or any(row['argv'][0] != str(CLI) for row in commands):
        raise SystemExit('the pinned three-command specification changed')
    jar = Path(commands[0]['argv'][3])
    inputs = [CLI, BUILD_RECEIPT, jar, HERE / 'commands.json', HERE / 'preparation-inputs.json',
              Path(__file__).resolve(), TOOLS / 'guard.py', TOOLS / 'target_scan.py']
    inputs_before = [pin(path) for path in inputs]

    def sources() -> list[dict]:
        rows = []
        for item in source_before:
            path = ROOT / item['path']
            current = pin(path)
            rows.append({'path': item['path'], 'bytes': current['bytes'], 'sha256': current['sha256']})
        return rows

    def ensure_unchanged(label: str) -> None:
        if [pin(path) for path in inputs] != inputs_before or sources() != source_before:
            raise RuntimeError(f'input or receipt-bound source closure changed: {label}')

    ensure_unchanged('preflight')
    if shutil.disk_usage(ROOT).free < FREE_LIMIT:
        raise SystemExit('5 GiB free-space preflight failed')
    scanner = load('class_source_repro_target_scan', TOOLS / 'target_scan.py')
    guard = load('class_source_repro_guard', TOOLS / 'guard.py')
    guard.ROOT, guard.OUT = ROOT, out
    guard.FREE_LIMIT, guard.TARGET_LIMIT = FREE_LIMIT, TARGET_LIMIT
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.expected_test_summaries = lambda _index, _data: None
    guard.command_stream = lambda path: pin(Path(path))
    environment = os.environ.copy()
    stripped = [key for key in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS',
                               'CLASSPATH', 'RUST_MIN_STACK', 'CARGO_TARGET_DIR') if key in environment]
    for key in stripped:
        environment.pop(key)
    environment.update(guard.ENV_VALUES)
    out.mkdir(parents=True, exist_ok=False)
    record = {
        'schema': 'class-source-proof-current-repro-v1', 'status': 'running',
        'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'workspace_root': str(ROOT), 'output_root': str(out),
        'correction': preparation['correction'], 'build_receipt': pin(BUILD_RECEIPT),
        'cli': cli_pin, 'inputs_before': inputs_before, 'source_manifest_before': source_before,
        'guard': {'minimum_free_bytes': FREE_LIMIT, 'maximum_target_bytes': TARGET_LIMIT,
                  'interval_seconds': 1, 'process_group_termination': True},
        'environment': {'overrides': guard.ENV_VALUES, 'stripped_keys': stripped},
        'commands': [], 'observations': [],
        'semantic_expectations': 'none; raw reports and actual exit codes require root review',
    }
    try:
        write(out / 'execution.json', record)
        for index, command in enumerate(commands, 1):
            ensure_unchanged(f'before {command["label"]}')
            row = guard.run_command(index, command['argv'], environment)
            row['label'] = command['label']
            record['commands'].append(row)
            write(out / 'execution.json', record)
            if row['guard_stop'] is not None:
                raise RuntimeError(f'guard stopped {command["label"]}')
            raw = Path(row['streams']['stdout']['path']).read_bytes()
            try:
                report = json.loads(raw)
                write(out / f'{index}.report.json', report)
                observation = observations(report)
                mains = selected_main(report)
                if len(mains) == 1:
                    (out / f'{index}.main.txt').write_text(mains[0].get('text', ''))
                    write(out / f'{index}.main.json', mains[0])
                (out / f'{index}.class.txt').write_text(report.get('text', ''))
                observation.update({'label': command['label'], 'exit_code': row['exit_code']})
                record['observations'].append(observation)
            except (ValueError, TypeError, AttributeError, KeyError) as error:
                record['observations'].append({'label': command['label'],
                                               'parse_error': f'{type(error).__name__}: {error}'})
            ensure_unchanged(f'after {command["label"]}')
            write(out / 'execution.json', record)
        record['status'] = 'recorded_pending_semantic_review'
    except BaseException as error:
        record['status'] = 'failed_recording'
        record['error'] = f'{type(error).__name__}: {error}'
    finally:
        record['inputs_after'] = [pin(path) for path in inputs]
        record['source_manifest_after'] = sources()
        record['inputs_unchanged_after'] = record['inputs_after'] == inputs_before
        record['sources_unchanged_after'] = record['source_manifest_after'] == source_before
        record['target_absent_after'] = not (ROOT / 'target').exists()
        if (not record['inputs_unchanged_after'] or not record['sources_unchanged_after']
                or not record['target_absent_after']):
            record['status'] = 'failed_recording'
        record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write(out / 'execution.json', record)
    print(json.dumps({'status': record['status'], 'command_count': len(record['commands']),
                      'output': str(out)}))
    return 0 if record['status'] == 'recorded_pending_semantic_review' else 1


if __name__ == '__main__':
    raise SystemExit(main())
