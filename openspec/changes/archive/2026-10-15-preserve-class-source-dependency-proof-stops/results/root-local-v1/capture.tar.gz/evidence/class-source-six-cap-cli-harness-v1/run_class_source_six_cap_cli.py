#!/usr/bin/env python3
"""Guarded six-cap class-source CLI capture. Prepared only; it does not build or mutate source."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, sys
from pathlib import Path

ROOT = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde').resolve()
FIXTURE = ROOT / 'openspec/evidence/java-syntax-2026-10-02/user-hierarchy-widening-patrol/fixture/hier/hier-fam.jar'
FIXTURE_SHA256 = '1ee63f3836a5e514cea57b7349dd515ca3f98550154beff187fdca4d019105b0'
BASE = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
HARNESS = BASE / 'interface-full-source-harness-v4/run_interface_full_source_harness.py'
GUARD = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/guard.py')
SCAN = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/target_scan.py')
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3
CAPS = (4096, 1, 2, 8, 14, 15)
EXPECTED_EXITS = (0, 4, 4, 4, 4, 4)

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def pin(path: Path) -> dict:
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--cli', type=Path, required=True)
    ap.add_argument('--receipt', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    cli, receipt, out = args.cli.resolve(), args.receipt.resolve(), args.out.resolve()
    if out.exists() or out.is_relative_to(ROOT):
        raise SystemExit('output must be fresh and outside the source workspace')
    if (ROOT / 'target').exists():
        raise SystemExit('workspace target must be absent before the frozen-CLI replay')
    if not FIXTURE.is_file() or sha(FIXTURE) != FIXTURE_SHA256:
        raise SystemExit('pinned H1 fixture missing or digest changed')
    if not all(p.is_file() for p in (cli, receipt, HARNESS, GUARD, SCAN)):
        raise SystemExit('CLI, build receipt, or pinned runner dependency is missing')

    h = load('class_source_build_receipt_verifier', HARNESS)
    cli_binding = h.verify_cli(cli, receipt)
    guard = load('class_source_six_cap_guard', GUARD)
    scanner = load('class_source_six_cap_target_scan', SCAN)
    guard.ROOT = ROOT
    guard.OUT = out
    guard.FREE_LIMIT = FREE_LIMIT
    guard.TARGET_LIMIT = TARGET_LIMIT
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.expected_test_summaries = lambda _i, _d: None
    guard.command_stream = lambda path: pin(Path(path))
    env = {k: v for k, v in os.environ.items() if k in ('HOME', 'LANG', 'LC_ALL')}
    env['PATH'] = '/usr/bin:/bin'
    auditor_path = Path(__file__).with_name('audit_class_source_six_cap_json.py').resolve()
    inputs = (Path(__file__).resolve(), auditor_path, cli, receipt, HARNESS, GUARD, SCAN, FIXTURE)
    before = [pin(p) for p in inputs]
    receipt_data = json.loads(receipt.read_text(encoding='utf-8'))
    source_before = receipt_data['source_manifest_before']
    if source_before != receipt_data.get('source_manifest_after'):
        raise SystemExit('build receipt source manifest before/after differ')
    def current_source_manifest():
        actual = []
        for item in source_before:
            source_path = ROOT / item['path']
            actual.append({'path': item['path'], 'bytes': source_path.stat().st_size, 'sha256': sha(source_path)})
        return actual
    source_current_before = current_source_manifest()
    if source_current_before != source_before:
        raise SystemExit('current source tree does not match the frozen CLI build receipt')
    out.mkdir(parents=True, exist_ok=False)
    rows = []
    record = {
        'schema': 'class-source-six-cap-cli-harness-v1',
        'status': 'running',
        'cli_binding': cli_binding,
        'fixture': {**pin(FIXTURE), 'expected_sha256': FIXTURE_SHA256},
        'source_manifest_from_build_receipt': {'count': len(source_before), 'sha256': hashlib.sha256(json.dumps(source_before, sort_keys=True, separators=(',', ':')).encode()).hexdigest()},
        'source_manifest_current_before': source_current_before,
        'input_pins_before': before,
        'caps_and_expected_exits': [{'class_headers': c, 'exit_code': e} for c, e in zip(CAPS, EXPECTED_EXITS)],
        'commands': rows,
        'target_absent_before': True,
        'scope': 'frozen CLI only; six JSON class-source requests over pinned H1 hierarchy fixture',
    }
    def save():
        tmp = out / 'execution.json.tmp'
        tmp.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        tmp.replace(out / 'execution.json')
    save()
    try:
        for index, (cap, expected) in enumerate(zip(CAPS, EXPECTED_EXITS), 1):
            argv = [str(cli), 'class-source', '--input', str(FIXTURE), '--class', 'H1',
                    '--evidence', 'all', '--format', 'json', '--budget', f'elapsed_millis=10000',
                    '--budget', f'class_headers={cap}']
            row = guard.run_command(index, argv, env)
            row['label'] = f'class-headers-{cap}'
            row['expected_exit_code'] = expected
            rows.append(row)
            save()
            if row.get('exit_code') != expected or row.get('guard_stop') is not None:
                raise RuntimeError(f'{row["label"]}: exit={row.get("exit_code")} guard={row.get("guard_stop")}')
            raw_path = Path(row['streams']['stdout']['path'])
            document = json.loads(raw_path.read_text(encoding='utf-8'))
            (out / f'class-headers-{cap}.parsed.json').write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            row['stdout_json'] = pin(out / f'class-headers-{cap}.parsed.json')
            save()
        record['status'] = 'six_expected_exits_and_json_documents_captured_pending_semantic_audit'
    except BaseException as e:
        record['status'] = 'failed'
        record['error'] = f'{type(e).__name__}: {e}'
    finally:
        record['input_pins_after'] = [pin(p) for p in inputs]
        record['inputs_identical'] = before == record['input_pins_after']
        source_after = json.loads(receipt.read_text(encoding='utf-8'))['source_manifest_after']
        source_current_after = current_source_manifest()
        record['source_manifest_current_after'] = source_current_after
        record['build_source_manifest_identical'] = source_before == source_after
        record['current_source_matches_build_before_after'] = source_current_before == source_current_after == source_before
        record['target_absent_after'] = not (ROOT / 'target').exists()
        record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        record['runner_after'] = pin(Path(__file__).resolve())
        if not record['inputs_identical'] or not record['build_source_manifest_identical'] or not record.get('current_source_matches_build_before_after') or not record['target_absent_after']:
            record['status'] = 'failed'
            record['error'] = record.get('error', 'input/source binding changed or target appeared')
        save()
    print(json.dumps({'status': record['status'], 'commands': len(rows), 'target_absent': record.get('target_absent_after')}))
    return 0 if record['status'] == 'six_expected_exits_and_json_documents_captured_pending_semantic_audit' else 1

if __name__ == '__main__':
    raise SystemExit(main())
