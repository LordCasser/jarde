# 六档 ClassHeaders CLI 独立审计 v2（未运行）

此目录只准备独立审计脚本；没有运行 CLI、JDK、Cargo，也没有写入仓库。输入形状来自 `class-source-proof-current-repro-harness-v1/run-v1/{1,2,3}.report.json` 和 `interface-cli-stops-root-v4/2.parsed.json`；脚本未伪造或运行 mock JSON。

相较准备态 v1，v2 要求 `item.identity` 是实际非空物理身份，main 同时按 JVM name/descriptor byte identity 定位（`main` / `([Ljava/lang/String;)V`）；验证每个 cap 的原始 stdout pin、parsed 文件 pin 和 JSON 语义相等；逐条核对六条真实 argv、执行序号、退出码及 guard 状态；绑定原 H1 fixture、runner、旧 auditor、guard、scanner、CLI verifier、CLI build receipt 与 source manifest；核对 frozen CLI 路径/长度/SHA/mode。所有 cap 的 `limits`、顶层 `usage` 和 `execution.usage` 都逐维核对。

预算行为要求 cap 1/2 是 ClassHeaders budget refusal；cap 8/14 要求 class request partial、物理 main 的分析 complete、recovery stopped、空正文/空 source map，并保留 `budget_exceeded_class_headers` 原诊断；wide 与 cap 15 要求 main 有 `contains_statements`、非空文本及非空 source-map。cap 15 必须有六个物理方法，逐行比较真实 identity/index/text/full outcome；仅 `analysis.execution.usage.elapsed_millis` 与 `report.execution.usage.elapsed_millis` 两个结构化叶节点被归一化。

原 v1 audit、runner 都保持原样。本审计脚本没有执行，因此不构成终态接受或任何测试通过声明。
