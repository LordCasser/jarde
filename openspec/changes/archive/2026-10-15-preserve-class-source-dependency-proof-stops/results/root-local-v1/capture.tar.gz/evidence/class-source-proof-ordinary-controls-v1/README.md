# Ordinary dependency refusal controls — public H1 candidate

`patch/new-public-controls.patch` adds two public Engine class-source controls derived from the pinned H1 fixture bytes: omit the physical `H1$Greet.class` dependency, or duplicate that same-name physical class entry with identical bytes. Both retain exactly one `H1.class` target. The test helper uses rawzip's existing archive reader (`entries`, `get_entry`, `wayfinder`, `verifying_reader`) and writer (`ZipArchiveWriter`) patterns already used in this repository; no hand-written ZIP parser or new dependency is introduced. All original class bytes are decompressed and copied unchanged; only physical entry presence/multiplicity and compression/manifest packaging differ.

The public assertions require the requested class to perform normally, class execution and H1.main analysis/body to stay Complete, and the existing source-preserving conservative refusal to remain visible. No Java method is invoked. The six cap tests are untouched.

`patch/existing-ordinary-refusal-assertions.patch` adds the narrow `Complete` aggregate assertion to the existing H2 missing-intermediate and H3 fixed algorithmic-depth negative tests. It intentionally does not alter the ReadArg case in `double_brace_capture`: that fixture already exercises a value-level IR-frame refusal, and this proposal does not require its enclosing class report to be Complete.

The original JAR SHA-256 is `1ee63f3836a5e514cea57b7349dd515ca3f98550154beff187fdca4d019105b0`; the manifest records the verified class-entry names, byte counts, and hashes. The derived archives are created by the Rust test helper at runtime and have not been executed here. No repository files, Git, Cargo, JDK, or CLI were touched.
