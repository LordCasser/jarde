# Current H1 class-source CLI recorder — PREPARED, NOT RUN

Root authorized exactly three CLI observations after its interface-proof v4 validation finishes. No CLI, Cargo, Git, JDK or debugger was run in preparing this harness. No repository or task checkbox was changed. There is no third production implementation here.

## Command provenance and correction

Parent initially wrote analysis_steps=4096/8/15, then explicitly corrected that to historical class_headers. This harness performs no new dimension sweep. commands.json was copied from the saved ordinary CLI argv (only frozen CLI path changed): wide from results/probe-v1/execution.json, cap8 from execution-extra.json, cap15 from class-headers-15/execution.json. The historical wide argv has no explicit ClassHeaders override: wide.stdout.raw confirms default limits.class_headers=4096 and limits.analysis_steps=4194304. Cap8/15 append only --budget class_headers=8 or =15. All three use class-source --class H1 --evidence essential --format json, elapsed_millis=10000, output_bytes=1048576. No help/version/probe command is added.

Canonical input is the original AUX evidence fixture hier-fam.jar, 4469 bytes, SHA256 1ee63f3836a5e514cea57b7349dd515ca3f98550154beff187fdca4d019105b0. The exported planning copy is independently pinned to the same bytes. Main extraction uses physical identity name bytes main and descriptor bytes ([Ljava/lang/String;)V, not display text or a name-only match. Historical inputs and guard dependencies are pinned in preparation-inputs.json.

## Execute later (root only)

    python3 /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/class-source-proof-current-repro-harness-v1/record.py

Default output is a fresh run-v1 directory under this harness. Optional --out must point to a fresh directory outside the repository. The recorder refuses to overwrite evidence. It waits for no process: it refuses unless the final interface-proof-focused-root-v4/execution.json status is expected_command_outcomes_observed_pending_independent_acceptance, source before/after agree, target is absent, and CORE/jarde-cli-interface-proof-v4 matches that receipt's frozen_cli bytes/SHA/path. At preparation time the v4 build was still running and the CLI did not yet exist; no provisional receipt hash or old binary is substituted.

It uses the existing pinned guard.run_command and target_scan implementation, with 5 GiB minimum free space, 1 GiB maximum target, 1-second checks and process-group termination. It invokes only the three commands in commands.json. No Cargo cleanup/build or JDK call occurs. It rechecks CLI, completed receipt, fixture, harness/guard inputs and the receipt's full source closure before/after each request; records exact raw stdout/stderr, actual argv/cwd/exit/duration/guard state, plus input/source before/after pins.

## Evidence without a predetermined direction

The recorder never asserts that cap8/15 must Complete, Partial, fail, or exit a given code. It records actual results after interface changes. Parsed full class reports, physical main records, main/class text and execution/content/outcome/diagnostic/usage observations are retained alongside raw streams. A missing main or non-JSON output is recorded for semantic review, not transformed into a proof stop. Status recorded_pending_semantic_review says only that the observations were recorded with guard/input integrity; it is not a regression pass or proof of either original defect.

Root should review cap8 and cap15 class/main execution, content, diagnostics, actual ClassHeaders limit/usage, and text versus wide before deciding whether the third bug remains. Saved historical outcomes are reference evidence, not current expected-output assertions. No GDB tracing or hidden fourth command is present.

Static preparation checks: Python AST parsing succeeded; exactly three argv arrays match historical wide+cap suffixes; no analysis_steps override exists. The recorder itself has not run and its runtime checks/JSON parsing have not been dynamically validated.
