# Public in-flight stop controls: application protocol (not yet implemented/run)

Base: `dependency-proof-boxed-interface-rebase-v2/after/src/facade.rs`. The cache candidate adds only `cfg(test)` entry hooks at the narrow proof boundaries and a scoped observer helper; it intentionally does not alter the existing interface proof observer or any production behavior.

## Stage locations confirmed statically

- Prebody snapshot proof: `prove_snapshot_hierarchy_widenings`, reached from `recover_prepared_member` before `jarde_java::recover_for_class_source_with_anonymous_ast`. This is the narrow point to install the ledger for the H1 cap8 public class-source request. A stop returned here is upstream of body recovery.
- Postbody double-brace proof: `prove_double_brace_allocation`, called by `project_class_source_double_brace` after the class-source report/main/member bodies already exist. Its error is returned to the double-brace projection wrapper and merged into class execution. The class-source tail guard immediately after that projection checks `ends_the_request(&report.execution)` and returns before the anonymous-interface successor projection.

Both stages are therefore directly targetable through the public `Engine::class_source_with_evidence` H1 fixture, without synthetic errors or a CLI-only helper. The H1 cap8/cap15 controls provide the original stage-specific baseline; compare with wide-budget public baseline.

## Deterministic runs to add in the owner test module

For each stage, make two fresh public requests with the pinned H1 JAR and clear initial caller token:

1. `CancelAfterRealCharge`: at the selected proof boundary, attach an observer-backed new `OperationLedger` sharing the caller token and limits. Cancel only from the observer after the first accepted real `LedgerSite::Charge`. Assert a real following checkpoint refusal, final class `ExecutionReport::Cancelled`, clear token at arm and cancelled after the charge, no proof charge/poll after the refusal, and stage-specific public prefix. Prebody must have no body text/artifact (`Stopped`/`NotProduced` member where result publication permits); postbody must retain committed main/member text and source maps.
2. `ExpiredLedgerCheckpoint`: at the same boundary, start the new ledger with `elapsed_millis=0` while leaving the caller budget alone. Assert a real `LedgerSite::Checkpoint` refusal with `ElapsedMillis`, no synthetic `Error`, class execution retaining elapsed semantics (the recovery outcome may use existing `Interrupted` vocabulary), no proof work after that refusal, and the same respective prefix rules.

For every run, inspect actual public `execution`, member/body state, diagnostics, and final usage; inspect observer entries after its first refusal to prove no later proof activity. A permit cancellation is asynchronous with respect to the currently admitted charge: that first charge is real and may remain in usage. Do not assert it is rolled back. Ordinary stage-specific no-stop/wide baseline and original cap8/cap15 behavior must remain separate controls. Preserve report-publication truncation as its own outcome if cancellation prevents a member record; do not force a missing stopped member into the report.

The current hook candidate exposes the observer for these assertions but does not contain these H1 test bodies. Exact H1 fixture loading/environment helpers and assertion types must be copied from the existing public tests after the owner applies the third change. No tests have been compiled or executed here.
