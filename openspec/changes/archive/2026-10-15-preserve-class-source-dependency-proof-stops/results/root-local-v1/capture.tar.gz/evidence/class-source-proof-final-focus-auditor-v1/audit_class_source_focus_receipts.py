#!/usr/bin/env python3
"""Independent static receipt/raw auditor for the split class-source focused run.

Consumes receipts and their saved raw streams only. It does not execute tests, CLI, JDK, or tools.
"""
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path

ROOT=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde').resolve()
SUMMARY_RE=re.compile(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;')
ANSI_RE=re.compile(r'\x1b\[[0-9;]*m')
EXPECTED_SOURCE_COUNT=4902
EXPECTED_TOTAL=(441,0,1)
PUBLIC8={
 'h1_wide_budget_remains_complete_with_main_body',
 'h1_cap_one_keeps_ordinary_class_header_budget_refusal',
 'h1_cap_two_keeps_ordinary_class_header_budget_refusal',
 'h1_cap_eight_stops_snapshot_proof_before_main_body',
 'h1_cap_fourteen_stops_snapshot_proof_before_main_body',
 'h1_cap_fifteen_keeps_main_body_but_stops_class_projection',
 'missing_physical_greet_refuses_only_the_call_without_stopping_class_source',
 'duplicate_physical_greet_refuses_ambiguous_evidence_without_stopping_class_source',
}
CLI2={
 'h1_cap_eight_cli_exits_incomplete_before_main_body',
 'h1_cap_fifteen_cli_exits_incomplete_and_keeps_main_body',
}
UNIT5={
 'public_h1_snapshot_proof_cancel_after_charge_retains_only_reliable_prefix',
 'public_h1_snapshot_proof_expired_checkpoint_stops_before_body_recovery',
 'public_h1_snapshot_proof_class_header_charge_refusal_keeps_partial_and_five_siblings',
 'public_h1_double_brace_cancel_after_charge_keeps_committed_main_and_siblings',
 'public_h1_double_brace_expired_checkpoint_keeps_committed_main_and_siblings',
}
def sha(path:Path)->str:
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def pin_matches(record):
 p=Path(record['path'])
 return p.is_file() and p.stat().st_size==record['bytes'] and sha(p)==record['sha256']
def stream_text(command,stream):
 row=command['streams'][stream];p=Path(row['path'])
 if not pin_matches(row):raise RuntimeError(f"raw pin mismatch: {p}")
 return p.read_text(encoding='utf-8',errors='replace')
def require(condition,message):
 if not condition:raise RuntimeError(message)
def test_names(command):
 text=ANSI_RE.sub('',stream_text(command,'stdout'))
 return {name:status for name,status in re.findall(r'^test (.+?) \.\.\. (ok|ignored|FAILED)(?:,.*)?$',text,re.M)}
def summaries(command):
 text=ANSI_RE.sub('',stream_text(command,'stdout'))
 return [tuple(map(int,row)) for row in SUMMARY_RE.findall(text)]
def argv_has(command,part):return part in command.get('argv',[])
def named_passes(command,names,where):
 actual=test_names(command)
 missing=sorted(n for n in names if actual.get(n)!='ok')
 require(not missing,f'{where} named tests missing or not passing: {missing}')
 return sorted(names)
def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--focus-v3',type=Path,required=True,help='first-seven receipt with the documented target-guard interruption')
 ap.add_argument('--focus-v4',type=Path,required=True,help='final split-target focus receipt, expected complete')
 ap.add_argument('--build-receipt',type=Path,required=True,help='receipt that froze the final CLI')
 ap.add_argument('--cli',type=Path,required=True)
 ap.add_argument('--out',type=Path,required=True,help='new cache-only auditor report path')
 args=ap.parse_args();p3=Path(args.focus_v3).resolve();p4=Path(args.focus_v4).resolve();bp=Path(args.build_receipt).resolve();cli=Path(args.cli).resolve();out=Path(args.out).resolve()
 require(not out.exists() and not out.is_relative_to(ROOT),'out must be a fresh path outside the repository')
 r3=json.loads(p3.read_text());r4=json.loads(p4.read_text());br=json.loads(bp.read_text())
 require(r3.get('workspace_root')==str(ROOT) and r4.get('workspace_root')==str(ROOT),'receipt workspace root mismatch')
 # v3's first seven commands are the accepted prefix. Its eighth was stopped by the target-size
 # guard and its ninth exact clean is cleanup only, so never count command eight as a test run.
 c3=r3.get('commands',[])
 require(len(c3)==9,'v3 must retain first seven, guard-stopped eighth, and final clean')
 for i,c in enumerate(c3[:7],1):
  require(c.get('index')==i and c.get('exit_code')==0 and c.get('guard_stop') is None,f'v3 prefix command {i} failed/stopped')
  stream_text(c,'stdout');stream_text(c,'stderr')
 require(c3[7].get('exit_code')==-15 and isinstance(c3[7].get('guard_stop'),dict),'v3 eighth command must remain a recorded target-guard interruption')
 require(c3[7].get('guard_stop',{}).get('target_bytes',0)>r3.get('guards',{}).get('maximum_target_bytes',0),'v3 eighth is not proven to have crossed its target limit')
 require(c3[8].get('label')=='finally-exact-cargo-clean' and c3[8].get('exit_code')==0 and c3[8].get('guard_stop') is None,'v3 exact cleanup did not pass')
 require(r3.get('target_absent') is True,'v3 did not finish target-free')
 require(r3.get('source_manifest_before')==r3.get('source_manifest_after'),'v3 source manifest changed')
 sm=r3['source_manifest_before'];require(len(sm)==EXPECTED_SOURCE_COUNT,f'v3 source manifest count {len(sm)} != {EXPECTED_SOURCE_COUNT}')
 # Check the two strict validators report the same canonical count from their raw output.
 for i in (2,3):
  text=ANSI_RE.sub('',stream_text(c3[i],'stdout')+'\n'+stream_text(c3[i],'stderr'))
  require(re.search(r'\b365\s+(?:change|changes|spec|specs)',text,re.I) or '365' in text,f'v3 strict validator {i+1} did not expose 365 in raw output')
 # Pin controlled Java/Javac version raw receipts.
 java_text=stream_text(c3[4],'stderr')+'\n'+stream_text(c3[4],'stdout')
 javac_text=stream_text(c3[5],'stderr')+'\n'+stream_text(c3[5],'stdout')
 require('23.0.1' in java_text and '23.0.1' in javac_text,'v3 controlled JDK is not 23.0.1')
 lib=c3[6];lib_summ=summaries(lib)
 require(lib_summ==[(234,0,0)],f'v3 library summary mismatch: {lib_summ}')
 unit_pass=named_passes(lib,UNIT5,'v3 facade library target')
 # A failed overall v3 status is expected solely because target guard interrupted command eight.
 require(r3.get('status')=='failed' and r3.get('error','').find('guard')>=0,'v3 receipt status/error does not match the known guard-only interruption')
 # v4 must represent the successful rerun of split public targets, CLI, ignored control, build, clean.
 require(r4.get('status')=='expected_command_outcomes_observed_pending_independent_acceptance',f'v4 is not complete: {r4.get("status")} {r4.get("error")}')
 require(r4.get('target_absent') is True,'v4 exact clean did not leave target absent')
 require(r4.get('source_manifest_before')==r4.get('source_manifest_after'),'v4 source manifest changed')
 require(r4.get('source_manifest_before')==sm,'v3 and v4 source manifests differ')
 require(len(r4['source_manifest_before'])==EXPECTED_SOURCE_COUNT,'v4 source manifest count differs from expected 4902')
 c4=r4.get('commands',[])
 require(len(c4)>=6,'v4 lacks the two target batches, CLI suite, ignored runtime, CLI build and cleanup')
 for i,c in enumerate(c4,1):
  stream_text(c,'stdout');stream_text(c,'stderr')
 require(c4[-1].get('label')=='finally-exact-cargo-clean' and c4[-1].get('exit_code')==0 and c4[-1].get('guard_stop') is None,'v4 final exact clean failed')
 runnable=[c for c in c4 if c.get('label')!='finally-exact-cargo-clean']
 require(all(c.get('exit_code')==0 and c.get('guard_stop') is None for c in runnable),'a v4 command failed or was guard-stopped')
 # Exactly two integration batches of seven distinct test targets.
 batches=[]
 for c in runnable:
  argv=c.get('argv',[])
  if 'test' in argv and '-p' in argv and argv[argv.index('-p')+1]=='jarde':
   targets=[argv[i+1] for i,x in enumerate(argv[:-1]) if x=='--test']
   if targets:batches.append((c,targets))
 require(len(batches)==2 and all(len(ts)==7 for _,ts in batches),'v4 needs exactly two seven-target core batches')
 core_targets=[t for _,ts in batches for t in ts]
 require(len(set(core_targets))==14,'split core test targets are not fourteen unique targets')
 public_batch=next((c for c,ts in batches if 'class_source_dependency_proof' in ts),None)
 require(public_batch is not None,'v4 core batches omit class_source_dependency_proof')
 public_pass=named_passes(public_batch,PUBLIC8,'public class-source proof target')
 cli_cmd=next((c for c in runnable if '-p' in c.get('argv',[]) and c['argv'][c['argv'].index('-p')+1]=='jarde-cli' and 'class_source_cli' in c.get('argv',[])),None)
 require(cli_cmd is not None,'v4 CLI class_source_cli target missing')
 cli_pass=named_passes(cli_cmd,CLI2,'CLI H1 cap controls')
 ignored_cmd=next((c for c in runnable if '--ignored' in c.get('argv',[])),None)
 require(ignored_cmd is not None,'v4 ignored runtime command missing')
 ignored_pass=named_passes(ignored_cmd,{'generated_special_dispatch_matches_original_runtime'},'ignored runtime control')
 # Use actual Cargo summaries from the 17 target invocations, excluding the guard-stopped v3 cmd8.
 all_summaries=[]
 for c in [lib,*[x for x,_ in batches],cli_cmd,ignored_cmd]: all_summaries.extend(summaries(c))
 require(len(all_summaries)==17,f'expected 17 native target summaries, observed {len(all_summaries)}')
 totals=tuple(sum(row[i] for row in all_summaries) for i in range(3))
 require(totals==EXPECTED_TOTAL,f'aggregate native counts {totals} != {EXPECTED_TOTAL}')
 # Bind the final frozen CLI to its build receipt: exact path, SHA, byte length and 0555 mode.
 cli_bytes=cli.stat().st_size;cli_sha=sha(cli);mode=cli.stat().st_mode & 0o777
 frozen=br.get('frozen_cli')
 require(isinstance(frozen,dict),'build receipt has no frozen_cli record')
 require(Path(frozen.get('path','')).resolve()==cli and frozen.get('bytes')==cli_bytes and frozen.get('sha256')==cli_sha and frozen.get('mode')=='0555' and mode==0o555,'frozen CLI path/hash/size/mode does not match receipt')
 require(br.get('target_absent') is True and br.get('source_manifest_before')==br.get('source_manifest_after')==sm,'CLI build receipt source/clean binding differs')
 report={
  'status':'accepted_static_receipt_audit',
  'not_a_workspace_acceptance':True,
  'v3':{'accepted_prefix_commands':7,'guard_stopped_command_8_excluded':True,'exact_clean_passed':True,'source_count':len(sm),'source_manifest_sha256':hashlib.sha256(json.dumps(sm,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'strict_raw_mentions_365':True,'jdk23_version_pins':True,'facade_library':[234,0,0],'required_unit_tests':unit_pass},
  'v4':{'commands':len(c4),'core_targets':sorted(set(core_targets)),'public_8':public_pass,'cli_2':cli_pass,'ignored_runtime':ignored_pass,'target_absent':True},
  'native_summaries':{'suites':len(all_summaries),'passed':totals[0],'failed':totals[1],'ignored':totals[2]},
  'frozen_cli':{'path':str(cli),'bytes':cli_bytes,'sha256':cli_sha,'mode':f'{mode:04o}'},
  'source_manifest_count':len(sm),
  'source_manifest_equal_across_v3_v4_build_receipt':True,
  'scope_limit':'Does not claim full workspace/CI; only the listed focused commands and frozen CLI replay are audited.'
 }
 out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False));return 0
if __name__=='__main__':raise SystemExit(main())
