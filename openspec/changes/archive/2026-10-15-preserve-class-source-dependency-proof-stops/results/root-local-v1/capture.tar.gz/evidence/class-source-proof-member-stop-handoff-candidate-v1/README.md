# Member-stop handoff candidate — UNCOMPILED

This is a separate three-hunk production candidate against the actual current AUX facade snapshot. It has not been applied, formatted, compiled or tested. No repository, Git, Cargo, JDK, CLI or GDB operation occurred. Root is running initial-v2 and will decide after actual results. Before/after files are inspection snapshots; apply reviewed hunks, never overwrite a changing checkout with a full snapshot.

## Narrow changes

1. At the existing class-source member publishing boundary, after merging that member's real stops, check the already computed ends flag plus the existing read-only cancellation token. When both are true, move original stop diagnostics from that discarded record into aggregate diagnostics and break before charge_item. A token cancelled by the original ledger refusal cannot cause a synthetic ResultItems re-charge to replace ClassHeaders/ElapsedMillis with Cancelled. The stopped member is not published: there is no bypass or fabricated ResultItems permit. Existing attempted-body and coverage bookkeeping remain where they were, and previously published methods/text remain untouched.
2. A token-clear local/nonsticky request-ending stop still takes the exact existing ResultItems admission and may publish its stopped record; the earlier interface depth0 control should remain unchanged. Ordinary value-level Unsupported/decode has ends=false and follows existing isolation. Ordinary independent cancellation with no prior record stop does not enter the new guard.
3. In the actual post-doublebrace prepared-child stop arm, collect only original diagnostic vectors from request-ending Recovered.report or Refused records before discarding child.methods, then pass the original child execution and those available diagnostics into the existing typed failure. Existing child aggregate diagnostics remain first. The scan is over this child's already admitted, bounded member vector and inspects only outcomes; no metadata reads, proof, analysis, budget poll/charge, or arbitrary successful/value-level diagnostic collection occurs. Previously unadmitted stop diagnostics arrive through change 1's aggregate promotion, so they cannot be recovered twice by the child-method loop.

Both consumers share one private 20-line helper that consumes ClassSourceOutcome and moves only existing vectors. It introduces no carrier, report initializer, numeric quota reconstruction, protocol or public API. It does not aggregate diagnostics from Complete or ordinary value-level member reports. The actual global strongest merge and legacy neighbor wrappers remain unchanged.

## Static checks

The patch has exactly three hunks and changes only src/facade.rs: prepared-child stop arm; member publication guard; private diagnostic mover. global merge/priority/ends_the_request, member_inner_resolution_stop, reference-overload/direct-parent accessor/field proofs are byte-identical. The new in-flight test module is byte-identical; root owns its four-case tail changes. ResultItems helper itself is unchanged. No source text, main/sibling method report, source map or derived mapping sidecar is cleared or rewritten by this patch.

## Pending real verification

No passing build claim. Root should run its four real ledger-stop cases with an empty observer tail after the first stop (LedgerSite::Charge carries UsageOwner, not budget dimension), require original execution dimension and firstLedgerStop, and require promoted original diagnostics. Retain the token-clear interface depth0 case with its one genuinely admitted publication. Prepared-child member report diagnostics and wide maps need actual nonempty-map controls, as root described. All-family controls should preserve ordinary refusals and admitted sibling prefixes.

The token check is a read-only stop-consumer boundary. A new independent caller cancellation racing after an already observed request-ending stop is not separately polled here; this scope intentionally starts no new work after that prior stop. Global priority remains available wherever distinct execution reports were actually observed.

## Compile receipt clarification

Parent's actual initial-v1 compile failure was the new test expression dereferencing an already returned usize (E0614). Root preserved raw/source and removed the extra *. The earlier missing-import suspicion was not the actual failure and required no import edits. This candidate does not alter test imports or classify that test compile error as a production failure.
