#!/usr/bin/env python3
"""Read-only independent audit of one complete class-source focus receipt and its raw streams."""
from __future__ import annotations
import argparse, hashlib, json, re, stat
from pathlib import Path

ROOT=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde').resolve()
EXPECTED_SOURCE_COUNT=4902
EXPECTED_TOTAL=(441,0,1)
SUMMARY_RE=re.compile(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;')
ANSI_RE=re.compile(r'\x1b\[[0-9;]*m')
PUBLIC8={
 'h1_wide_budget_remains_complete_with_main_body',
 'h1_cap_one_keeps_ordinary_class_header_budget_refusal',
 'h1_cap_two_keeps_ordinary_class_header_budget_refusal',
 'h1_cap_eight_stops_snapshot_proof_before_main_body',
 'h1_cap_fourteen_stops_snapshot_proof_before_main_body',
 'h1_cap_fifteen_keeps_main_body_but_stops_class_projection',
 'missing_physical_mid_refuses_only_the_call_without_stopping_class_source',
 'duplicate_physical_mid_refuses_ambiguous_evidence_without_stopping_class_source',
}
CLI2={'h1_cap_eight_cli_exits_incomplete_before_main_body','h1_cap_fifteen_cli_exits_incomplete_and_keeps_main_body'}
UNIT5={
 'public_h1_snapshot_proof_cancel_after_charge_retains_only_reliable_prefix',
 'public_h1_snapshot_proof_expired_checkpoint_stops_before_body_recovery',
 'public_h1_snapshot_proof_class_header_charge_refusal_keeps_partial_and_five_siblings',
 'public_h1_double_brace_cancel_after_charge_keeps_committed_main_and_siblings',
 'public_h1_double_brace_expired_checkpoint_keeps_committed_main_and_siblings',
}
def sha(path:Path)->str:
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def pin(path:Path)->dict:return {'path':str(path.resolve()),'bytes':path.stat().st_size,'sha256':sha(path)}
def matches(row:dict)->bool:
 p=Path(row['path']);return p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
def require(ok:bool,msg:str):
 if not ok:raise RuntimeError(msg)
def raw(command:dict,which:str)->str:
 row=command['streams'][which];require(matches(row),f'raw stream pin mismatch: {row.get("path")}')
 return Path(row['path']).read_text(encoding='utf-8',errors='replace')
def summaries(command:dict):
 text=ANSI_RE.sub('',raw(command,'stdout'))
 return [tuple(map(int,m)) for m in SUMMARY_RE.findall(text)]
def named(command:dict):
 rows=command.get('named_test_outcomes')
 if isinstance(rows,list):return {r['name'].split('::')[-1]:r['status'] for r in rows}
 text=ANSI_RE.sub('',raw(command,'stdout'))
 return {n.split('::')[-1]:s for n,s in re.findall(r'^test (.+?) \.\.\. (ok|ignored|FAILED)(?:,.*)?$',text,re.M)}
def require_named(command,names,label):
 found=named(command);missing=sorted(n for n in names if found.get(n)!='ok')
 require(not missing,f'{label}: missing or nonpassing named tests {missing}')
 return sorted(names)
def manifest_hash(rows):return hashlib.sha256(json.dumps(rows,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def actual_manifest(rows):
 actual=[]
 for r in rows:
  p=ROOT/r['path']
  actual.append({'path':r['path'],'bytes':p.stat().st_size,'sha256':sha(p)})
 return actual
def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--receipt',type=Path,required=True,help='complete class-source-proof-focused-root-v5 execution.json')
 ap.add_argument('--cli',type=Path,required=True,help='final frozen combined-source-proof-v5 CLI')
 ap.add_argument('--out',type=Path,required=True,help='fresh report path outside source workspace')
 a=ap.parse_args();rp=a.receipt.resolve();cli=a.cli.resolve();out=Path(a.out).resolve()
 require(not out.exists() and not out.is_relative_to(ROOT),'out must be a fresh path outside repository')
 r=json.loads(rp.read_text(encoding='utf-8'))
 require(r.get('workspace_root')==str(ROOT),'receipt workspace root mismatch')
 require(r.get('status')=='expected_command_outcomes_observed_pending_independent_acceptance',f'focus receipt not successful: {r.get("status")} {r.get("error")}')
 commands=r.get('commands',[])
 require(len(commands)==13,'expected 12 declared commands plus finally-exact-cargo-clean')
 require(r.get('target_absent') is True,'finally cleanup did not prove target absent')
 require(r.get('default_stack') is True,'receipt does not state the default test-thread stack')
 require(r.get('source_manifest_before')==r.get('source_manifest_after'),'receipt source manifests differ')
 source=r['source_manifest_before'];require(len(source)==EXPECTED_SOURCE_COUNT,f'source count {len(source)} != {EXPECTED_SOURCE_COUNT}')
 # Recheck current source bytes against both captured manifests.
 current=actual_manifest(source)
 require(current==source,'current source tree differs from the v5 source manifest')
 # Receipt runner and command specification are immutable inputs whose before/after pins must agree.
 for key in ('runner','command_spec'):
  record=r.get(key);require(isinstance(record,dict) and matches(record),f'{key} pin mismatch')
 if r.get('runner_after') is not None:require(r['runner']==r['runner_after'],'runner changed during the run')
 # Every actual command and both raw streams are verified below. No result from the earlier guard-hit v3 or failed v4 is consumed.
 for i,c in enumerate(commands,1):
  require(c.get('index')==i and c.get('exit_code')==0 and c.get('guard_stop') is None,f'command {i} failed/stopped: {c.get("label")}')
  raw(c,'stdout');raw(c,'stderr')
 require(commands[-1].get('label')=='finally-exact-cargo-clean','last command is not exact cleanup')
 declared=json.loads(Path(r['command_spec']['path']).read_text(encoding='utf-8'))
 require(len(declared)==12,'command specification is not the 12-command planned run')
 require([c.get('argv') for c in commands[:-1]]==declared,'actual command argv differs from pinned command specification')
 # Exact gate order: format, clippy, strict validators, JDK versions, unit, two seven-target test batches, CLI target, ignored runtime, build, cleanup.
 require(commands[0]['argv'][:4]==['cargo','fmt','--all','--'],'fmt command mismatch')
 require(commands[1]['argv'][:3]==['cargo','clippy','--workspace'],'workspace clippy command mismatch')
 for i in (2,3):
  text=ANSI_RE.sub('',raw(commands[i],'stdout')+'\n'+raw(commands[i],'stderr'))
  require('365' in text,f'strict validator command {i+1} raw output does not report 365')
 java=raw(commands[4],'stderr')+'\n'+raw(commands[4],'stdout')
 javac=raw(commands[5],'stderr')+'\n'+raw(commands[5],'stdout')
 require('23.0.1' in java and '23.0.1' in javac,'controlled JDK/Javac is not version 23.0.1')
 lib=commands[6];lib_s=summaries(lib);require(lib_s==[(234,0,0)],f'library target summary mismatch: {lib_s}')
 unit_pass=require_named(lib,UNIT5,'five public H1 unit controls')
 batches=[]
 for c in commands[7:9]:
  argv=c['argv'];require('-p' in argv and argv[argv.index('-p')+1]=='jarde','core batch package mismatch')
  targets=[argv[j+1] for j,x in enumerate(argv[:-1]) if x=='--test']
  require(len(targets)==7 and len(set(targets))==7,f'core batch needs seven unique targets: {targets}')
  batches.append((c,targets))
 all_targets=[x for _,xs in batches for x in xs]
 require(len(set(all_targets))==14,'the two batches do not cover 14 unique core targets')
 pub=next((c for c,ts in batches if 'class_source_dependency_proof' in ts),None)
 require(pub is not None,'public 8-test dependency target absent')
 public_pass=require_named(pub,PUBLIC8,'public dependency proof target')
 cli_test=commands[9];require('-p' in cli_test['argv'] and cli_test['argv'][cli_test['argv'].index('-p')+1]=='jarde-cli' and 'class_source_cli' in cli_test['argv'],'CLI target mismatch')
 cli_pass=require_named(cli_test,CLI2,'two public CLI cap controls')
 ignored=commands[10];require('--ignored' in ignored['argv'],'dedicated ignored run is absent')
 ignored_name=require_named(ignored,{'generated_special_dispatch_matches_original_runtime'},'ignored runtime gate')
 build=commands[11];require(build['argv'][:3]==['cargo','build','-p'] and 'jarde-cli' in build['argv'],'CLI build command mismatch')
 all_s=[]
 for c in [lib,commands[7],commands[8],cli_test,ignored]:all_s.extend(summaries(c))
 require(len(all_s)==17,f'expected 17 summaries, got {len(all_s)}')
 totals=tuple(sum(s[i] for s in all_s) for i in range(3))
 require(totals==EXPECTED_TOTAL,f'native test totals {totals} != {EXPECTED_TOTAL}')
 frozen=r.get('frozen_cli');require(isinstance(frozen,dict),'focus receipt has no frozen CLI record')
 mode=cli.stat().st_mode & 0o777;cli_pin=pin(cli)
 require(Path(frozen.get('path','')).resolve()==cli and frozen.get('bytes')==cli_pin['bytes'] and frozen.get('sha256')==cli_pin['sha256'] and frozen.get('mode')=='0555' and mode==0o555,'frozen CLI path/hash/size/mode mismatch')
 report={
  'status':'accepted_static_receipt_audit',
  'not_workspace_acceptance':True,
  'receipt':pin(rp),
  'focus_commands':{'declared':12,'including_finally_clean':len(commands),'all_exit_zero':True,'all_raw_stream_hashes_verified':True},
  'gates':{'fmt':True,'workspace_clippy':True,'strict_validator_counts':[365,365],'controlled_jdk23':True,'library_unit':[234,0,0],'unit5':unit_pass,'core_target_batches':[sorted(batches[0][1]),sorted(batches[1][1])],'public8':public_pass,'cli2':cli_pass,'ignored_runtime':ignored_name},
  'aggregate_native_summaries':{'suites':len(all_s),'passed':totals[0],'failed':totals[1],'ignored':totals[2]},
  'source_binding':{'count':len(source),'sha256':manifest_hash(source),'before_after_equal':True,'current_tree_matches':True,'target_absent':True,'default_stack':True},
  'frozen_cli':{**cli_pin,'mode':f'{mode:04o}'},
  'scope_limit':'Only the 12 declared focused commands and their exact cleanup are audited. This report does not claim full workspace, product-owned CI, or broader integration acceptance.'
 }
 out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False));return 0
if __name__=='__main__':raise SystemExit(main())
