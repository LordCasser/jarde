
#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum ClassProofStage { SnapshotPrebody, DoubleBracePostbody }

#[cfg(test)]
mod class_source_proof_inflight_tests {
    use super::*;
    use jarde_reader::budget::CancellationToken;
    use jarde_reader::ledger::{LedgerEntryTiming, LedgerObserver, LedgerSite, OperationLedger, UsageOwner};
    use std::cell::RefCell;
    use std::sync::{Arc, Mutex, atomic::{AtomicUsize, Ordering}};

    #[derive(Clone, Copy, Debug)]
    pub(super) enum InFlightControl { CancelAfterRealCharge, ExpiredLedgerCheckpoint }

    #[derive(Debug)]
    pub(super) struct Observation {
        pub token: CancellationToken,
        pub entries: Mutex<Vec<LedgerSite>>,
        pub refusals: Mutex<Vec<Option<BudgetDimension>>>,
        pub first_refusal_index: Mutex<Option<usize>>,
        charge_count: AtomicUsize,
        control: InFlightControl,
    }

    impl LedgerObserver for Observation {
        fn entry(&self, site: LedgerSite, _timing: Option<LedgerEntryTiming>) {
            self.entries.lock().unwrap().push(site);
            if matches!(site, LedgerSite::Charge(_)) {
                let prior = self.charge_count.fetch_add(1, Ordering::SeqCst);
                if matches!(self.control, InFlightControl::CancelAfterRealCharge) && prior == 0 {
                    self.token.cancel();
                }
            }
        }
        fn refusal(&self, _site: LedgerSite, dimension: Option<BudgetDimension>) {
            let mut refusals = self.refusals.lock().unwrap();
            if refusals.is_empty() {
                *self.first_refusal_index.lock().unwrap() =
                    Some(self.entries.lock().unwrap().len().saturating_sub(1));
            }
            refusals.push(dimension);
        }
    }

    #[derive(Clone, Copy)]
    struct Armed { stage: ClassProofStage, control: InFlightControl }
    thread_local! {
        static ARMED: RefCell<Option<Armed>> = const { RefCell::new(None) };
        static OBSERVED: RefCell<Option<Arc<Observation>>> = const { RefCell::new(None) };
    }

    pub(super) struct Guard;
    impl Drop for Guard {
        fn drop(&mut self) {
            ARMED.with(|slot| { slot.replace(None); });
            OBSERVED.with(|slot| { slot.replace(None); });
        }
    }

    pub(super) fn arm(stage: ClassProofStage, control: InFlightControl) -> Guard {
        ARMED.with(|slot| {
            assert!(slot.borrow().is_none(), "class-source proof controls do not nest");
            slot.replace(Some(Armed { stage, control }));
        });
        Guard
    }

    /// Called at the real proof boundary. The new operation ledger uses the current limits and
    /// shared token; only elapsed=0 is changed for the deadline mode. No stop is injected.
    pub(super) fn at(stage: ClassProofStage, budget: &mut Budget) {
        let armed = ARMED.with(|slot| {
            if slot.borrow().is_some_and(|armed| armed.stage == stage) {
                slot.borrow_mut().take()
            } else { None }
        });
        let Some(armed) = armed else { return; };
        let token = budget.cancellation_token();
        assert!(!token.is_cancelled(), "control starts with a clear token");
        let mut limits = budget.limits().clone();
        if matches!(armed.control, InFlightControl::ExpiredLedgerCheckpoint) {
            limits.elapsed_millis = 0;
        }
        let entry = Budget::with_cancellation_token(limits, token.clone());
        let observer = Arc::new(Observation {
            token,
            entries: Mutex::new(Vec::new()),
            refusals: Mutex::new(Vec::new()),
            first_refusal_index: Mutex::new(None),
            charge_count: AtomicUsize::new(0),
            control: armed.control,
        });
        let ledger = OperationLedger::new(&entry).with_observer(observer.clone());
        budget.with_ledger(ledger, UsageOwner::Methods);
        OBSERVED.with(|slot| {
            assert!(slot.borrow().is_none(), "one proof-control observer is active");
            slot.replace(Some(observer));
        });
    }

    pub(super) fn observation() -> Arc<Observation> {
        OBSERVED.with(|slot| slot.borrow().as_ref().expect("proof boundary was reached").clone())
    }
}
