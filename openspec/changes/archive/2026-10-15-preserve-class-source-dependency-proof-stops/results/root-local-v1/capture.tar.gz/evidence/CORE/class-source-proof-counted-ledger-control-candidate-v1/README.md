# Class-source proof counted-ledger control 候选

此目录只保存缓存候选，不触碰 AUX 或 primary 仓库。`candidate.patch` 在既有 `class_source_proof_inflight_tests` 中增加一个 `SnapshotPrebody` 的真实 `ClassHeaders` 计费拒绝控制，复用 `exercise_h1_stage`、独立 ledger/local token、first-refusal observer、停后 15 个 counted 维度恒定和可靠兄弟 prefix 断言。

预期首个拒绝发生于 proof 内真实类头读取：ledger 的 `class_headers=0`，拒绝 `Charge(UsageOwner::Methods)`，observer dimension 为 `ClassHeaders`，报告保留 Partial 与原诊断，拒绝后的 ledger tail 为空；五个 main 之前的兄弟逐项维持原 identity 与 text。候选未应用、未编译或运行；不要将其记为已验证。指纹及后续验证要求见 `manifest.json`。
