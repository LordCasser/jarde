#!/usr/bin/env python3
"""Independent semantic and provenance audit for a completed six-cap capture.

Read-only: consumes execution.json, saved raw streams, and parsed JSON documents.
It intentionally does not launch the CLI or invoke build/JDK tools.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import stat
from pathlib import Path

BASE = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
ROOT = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde')
FIXTURE = ROOT / 'openspec/evidence/java-syntax-2026-10-02/user-hierarchy-widening-patrol/fixture/hier/hier-fam.jar'
FIXTURE_SHA = '1ee63f3836a5e514cea57b7349dd515ca3f98550154beff187fdca4d019105b0'
HARNESS = BASE / 'interface-full-source-harness-v4/run_interface_full_source_harness.py'
GUARD = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/guard.py')
SCAN = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/target_scan.py')
RUNNER_SHA = '4f1848a6b3e42b6d27839382918dc1e5aeeb55265c671bfb41bea7a18c421c46'
OLD_AUDITOR_SHA = 'c721ed3c5dbd3c7d2e08ed82737c64b84bcfd06aa43347addb6077048353e37b'
CAPS = (4096, 1, 2, 8, 14, 15)
EXITS = (0, 4, 4, 4, 4, 4)
MAIN_NAME = [109, 97, 105, 110]
MAIN_DESC = [40, 91, 76, 106, 97, 118, 97, 47, 108, 97, 110, 103, 47, 83, 116, 114, 105, 110, 103, 59, 41, 86]


def fail(message: str) -> None:
    raise SystemExit('audit failed: ' + message)


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def pin_matches(pin: object, path: Path) -> bool:
    return (isinstance(pin, dict) and pin.get('path') == str(path.resolve())
            and path.is_file() and pin.get('bytes') == path.stat().st_size
            and pin.get('sha256') == sha(path))


def load_json(path: Path):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        fail(f'{path}: invalid JSON ({exc})')


def method_identity(row: object, label: str, require_main: bool = False) -> tuple[dict, int]:
    if not isinstance(row, dict):
        fail(f'{label}: method row is not an object')
    item = row.get('item')
    if not isinstance(item, dict):
        fail(f'{label}: missing item object')
    ident = item.get('identity')
    index = item.get('index')
    if not isinstance(ident, dict) or not isinstance(index, int) or isinstance(index, bool):
        fail(f'{label}: identity/index missing or null')
    if require_main and (ident.get('name') != MAIN_NAME or ident.get('descriptor') != MAIN_DESC):
        fail(f'{label}: physical identity is not main([Ljava/lang/String;)V')
    if not isinstance(ident.get('name'), list) or not isinstance(ident.get('descriptor'), list):
        fail(f'{label}: physical method name/descriptor identity incomplete')
    owner = ident.get('owner')
    if not isinstance(owner, dict) or not isinstance(owner.get('class_bytes'), dict):
        fail(f'{label}: physical owner/class bytes identity incomplete')
    if not isinstance(owner['class_bytes'].get('digest'), str) or not isinstance(owner['class_bytes'].get('length'), int):
        fail(f'{label}: physical owner pin incomplete')
    if item.get('name', {}).get('raw') != ident['name'] or item.get('descriptor', {}).get('raw') != ident['descriptor']:
        fail(f'{label}: display name/descriptor disagree with physical identity')
    return ident, index


def only_elapsed_normalized(value: object) -> object:
    """Copy exact report shape, replacing only known execution usage elapsed leaves."""
    out = copy.deepcopy(value)
    if not isinstance(out, dict):
        fail('method outcome is not an object')
    # Method-row outcome is {kind, analysis, report}; normalize known elapsed leaves
    # only, never arbitrary nested fields that happen to share the same key name.
    analysis = out.get('analysis')
    if not isinstance(analysis, dict) or not isinstance(analysis.get('execution'), dict):
        fail('method outcome analysis execution shape is missing')
    report = out.get('report')
    if not isinstance(report, dict) or not isinstance(report.get('execution'), dict):
        fail('method outcome report execution shape is missing')
    for execution in (analysis['execution'], report['execution']):
        usage = execution.get('usage')
        if not isinstance(usage, dict) or not isinstance(usage.get('elapsed_millis'), int):
            fail('known execution usage elapsed_millis is missing or not integer')
        usage['elapsed_millis'] = '<elapsed-millis>'
    return out


def check_usage(doc: dict, cap: int, label: str) -> None:
    limits, usage, execution = doc.get('limits'), doc.get('usage'), doc.get('execution')
    if not all(isinstance(x, dict) for x in (limits, usage, execution)):
        fail(f'{label}: missing limits/usage/execution objects')
    eusage = execution.get('usage')
    if not isinstance(eusage, dict):
        fail(f'{label}: execution.usage missing')
    if limits.get('class_headers') != cap:
        fail(f'{label}: requested class_headers limit does not equal {cap}')
    if usage.get('class_headers') != cap or eusage.get('class_headers') != cap:
        fail(f'{label}: actual top-level and execution class_headers usage must equal cap {cap}')
    if usage != eusage:
        fail(f'{label}: top-level usage differs from execution.usage')
    for key, limit in limits.items():
        value = usage.get(key)
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            fail(f'{label}: usage.{key} is not a nonnegative integer')
        if isinstance(limit, int) and value > limit:
            fail(f'{label}: usage.{key} exceeds its effective limit')


def check_report_stream(root: Path, row: dict, cap: int) -> dict:
    label = f'class-headers-{cap}'
    streams = row.get('streams')
    if not isinstance(streams, dict):
        fail(f'{label}: missing raw stream records')
    rawpin = streams.get('stdout')
    stderrpin = streams.get('stderr')
    if not isinstance(rawpin, dict):
        fail(f'{label}: missing stdout raw pin')
    if not isinstance(stderrpin, dict) or not pin_matches(stderrpin, Path(stderrpin.get('path', ''))):
        fail(f'{label}: stderr raw bytes/SHA pin mismatch')
    rawpath = Path(rawpin.get('path', '')).resolve()
    if not pin_matches(rawpin, rawpath):
        fail(f'{label}: raw stdout bytes/SHA pin mismatch')
    parsedpin = row.get('stdout_json')
    parsedpath = root / f'{label}.parsed.json'
    if not pin_matches(parsedpin, parsedpath):
        fail(f'{label}: parsed JSON bytes/SHA pin mismatch')
    raw_bytes = rawpath.read_bytes()
    parsed_bytes = parsedpath.read_bytes()
    try:
        raw_doc = json.loads(raw_bytes)
        parsed_doc = json.loads(parsed_bytes)
    except Exception as exc:
        fail(f'{label}: raw or parsed stream is invalid JSON ({exc})')
    if raw_doc != parsed_doc:
        fail(f'{label}: saved parsed document is not semantically byte-bound to raw stdout JSON')
    return parsed_doc


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    out = args.out.resolve()
    receipt = load_json(out / 'execution.json')
    if receipt.get('schema') != 'class-source-six-cap-cli-harness-v1':
        fail('unexpected capture schema')
    if receipt.get('status') != 'six_expected_exits_and_json_documents_captured_pending_semantic_audit':
        fail('capture is not complete/pending semantic audit')
    if not all(receipt.get(k) is True for k in ('inputs_identical', 'build_source_manifest_identical', 'current_source_matches_build_before_after', 'target_absent_before', 'target_absent_after')):
        fail('capture input/source/target stability fields are not all true')
    if (ROOT / 'target').exists():
        fail('workspace target is present after capture')
    rows = receipt.get('commands')
    if not isinstance(rows, list) or len(rows) != 6:
        fail('expected six command records')
    runner = Path(__file__).with_name('run_class_source_six_cap_cli.py')
    # Auditing a copy is allowed, but provenance requires the original harness pins.
    runner_pin = next((p for p in receipt.get('input_pins_before', []) if isinstance(p, dict) and p.get('path') == str(runner.resolve())), None)
    if not pin_matches(runner_pin, runner) or runner_pin.get('sha256') != RUNNER_SHA:
        fail('runner pin differs from approved v1 runner')
    old_auditor = runner.with_name('audit_class_source_six_cap_json.py')
    old_pin = next((p for p in receipt.get('input_pins_before', []) if isinstance(p, dict) and p.get('path') == str(old_auditor.resolve())), None)
    if not pin_matches(old_pin, old_auditor) or old_pin.get('sha256') != OLD_AUDITOR_SHA:
        fail('v1 auditor input pin differs from approved prepared candidate')
    fixture_pin = next((p for p in receipt.get('input_pins_before', []) if isinstance(p, dict) and p.get('path') == str(FIXTURE.resolve())), None)
    if not pin_matches(fixture_pin, FIXTURE) or fixture_pin.get('sha256') != FIXTURE_SHA:
        fail('H1 fixture binding differs')
    harness_pin = next((p for p in receipt.get('input_pins_before', []) if isinstance(p, dict) and p.get('path') == str(HARNESS.resolve())), None)
    guard_pin = next((p for p in receipt.get('input_pins_before', []) if isinstance(p, dict) and p.get('path') == str(GUARD.resolve())), None)
    scan_pin = next((p for p in receipt.get('input_pins_before', []) if isinstance(p, dict) and p.get('path') == str(SCAN.resolve())), None)
    for label, pin, path in (('CLI verifier', harness_pin, HARNESS), ('guard', guard_pin, GUARD), ('target scanner', scan_pin, SCAN)):
        if not pin_matches(pin, path):
            fail(f'{label} input pin mismatch')
    before = receipt.get('input_pins_before')
    after = receipt.get('input_pins_after')
    if not isinstance(before, list) or before != after:
        fail('full before/after input pin arrays differ')
    if not all(isinstance(pin, dict) and pin_matches(pin, Path(pin.get('path', ''))) for pin in before):
        fail('one or more recorded input pins no longer match their files')
    build_receipt = load_json(Path(next(p['path'] for p in before if p.get('path', '').endswith('/execution.json'))))
    if build_receipt.get('status') != 'expected_command_outcomes_observed_pending_independent_acceptance':
        fail('frozen CLI build receipt status is not the expected pending-acceptance state')
    frozen = build_receipt.get('frozen_cli')
    cli_path = Path(receipt.get('cli_binding', {}).get('path', ''))
    if not isinstance(frozen, dict) or not cli_path.is_file():
        fail('missing exact frozen CLI binding')
    st = cli_path.stat()
    if (frozen.get('path') != str(cli_path.resolve()) or frozen.get('bytes') != st.st_size
            or frozen.get('sha256') != sha(cli_path) or frozen.get('mode') != '0555'
            or f'{stat.S_IMODE(st.st_mode):04o}' != '0555'):
        fail('frozen CLI path/size/SHA/mode does not match build receipt')
    if receipt.get('fixture', {}).get('sha256') != FIXTURE_SHA:
        fail('capture fixture digest mismatch')
    build_manifest = build_receipt.get('source_manifest_before')
    if not isinstance(build_manifest, list) or build_manifest != build_receipt.get('source_manifest_after'):
        fail('build source closure before/after differs')
    manifest_hash = hashlib.sha256(json.dumps(build_manifest, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    if receipt.get('source_manifest_from_build_receipt', {}).get('sha256') != manifest_hash:
        fail('capture manifest digest is not bound to build receipt')
    if receipt.get('source_manifest_current_before') != build_manifest or receipt.get('source_manifest_current_after') != build_manifest:
        fail('source closure snapshots differ from build source closure')

    docs = {}
    observed = []
    for i, (cap, expected_exit, row) in enumerate(zip(CAPS, EXITS, rows), 1):
        label = f'class-headers-{cap}'
        argv = row.get('argv')
        expected_argv = [str(cli_path.resolve()), 'class-source', '--input', str(FIXTURE.resolve()), '--class', 'H1', '--evidence', 'all', '--format', 'json', '--budget', 'elapsed_millis=10000', '--budget', f'class_headers={cap}']
        if argv != expected_argv:
            fail(f'{label}: actual argv differs from exact requested argv')
        if row.get('index') != i or row.get('label') != label or row.get('exit_code') != expected_exit or row.get('expected_exit_code') != expected_exit:
            fail(f'{label}: actual command index/label/exit mismatch')
        if row.get('guard_stop') is not None:
            fail(f'{label}: command was interrupted by guard')
        if row.get('cwd') != str(ROOT) or row.get('env_overrides') != {}:
            fail(f'{label}: actual cwd/environment differs from isolated capture contract')
        doc = check_report_stream(out, row, cap)
        check_usage(doc, cap, label)
        docs[cap] = doc
        observed.append({'cap': cap, 'argv': argv, 'exit_code': row['exit_code'], 'stdout_raw_bytes': row['streams']['stdout']['bytes'], 'stdout_raw_sha256': row['streams']['stdout']['sha256']})

    wide = docs[4096]
    if wide.get('execution', {}).get('status') != 'complete':
        fail('wide cap is not analysis-complete')
    wide_rows = wide.get('methods')
    if not isinstance(wide_rows, list) or len(wide_rows) != 6:
        fail('wide H1 physical method census is not six')
    wide_main = [m for m in wide_rows if isinstance(m, dict) and isinstance(m.get('item'), dict) and isinstance(m['item'].get('identity'), dict) and m['item']['identity'].get('name') == MAIN_NAME and m['item']['identity'].get('descriptor') == MAIN_DESC]
    if len(wide_main) != 1:
        fail('wide report has no unique physical main identity')
    wm = wide_main[0]
    wide_identity, wide_index = method_identity(wm, 'wide main', require_main=True)
    wide_body = wm.get('outcome', {}).get('report', {})
    if (wide_body.get('content') != 'contains_statements' or not isinstance(wide_body.get('text'), str)
            or not wide_body['text'].strip() or not isinstance(wide_body.get('source_map'), dict)
            or not isinstance(wide_body['source_map'].get('segments'), list) or not wide_body['source_map']['segments']):
        fail('wide main lacks statement content, text, or source-map segments')

    refused = []
    for cap in (1, 2):
        doc = docs[cap]
        if doc.get('execution', {}).get('status') != 'partial' or doc.get('execution', {}).get('reason') != {'dimension': 'class_headers', 'kind': 'budget_exceeded'}:
            fail(f'cap {cap} did not produce the exact ClassHeaders budget refusal')
        refused.append(cap)

    stopped = []
    for cap in (8, 14):
        doc = docs[cap]
        if doc.get('execution', {}).get('status') != 'partial' or doc.get('execution', {}).get('reason') != {'dimension': 'class_headers', 'kind': 'budget_exceeded'}:
            fail(f'cap {cap}: class-level ClassHeaders stop missing')
        candidates = [m for m in doc.get('methods', []) if isinstance(m, dict) and isinstance(m.get('item'), dict) and isinstance(m['item'].get('identity'), dict) and m['item']['identity'].get('name') == MAIN_NAME and m['item']['identity'].get('descriptor') == MAIN_DESC]
        if len(candidates) != 1:
            fail(f'cap {cap}: no unique physical main method')
        main = candidates[0]
        identity, index = method_identity(main, f'cap {cap} main', require_main=True)
        outcome = main.get('outcome')
        if not isinstance(outcome, dict) or outcome.get('kind') != 'recovered':
            fail(f'cap {cap}: main member recovery record missing')
        analysis = outcome.get('analysis')
        body = outcome.get('report')
        if not isinstance(analysis, dict) or analysis.get('execution', {}).get('status') != 'complete':
            fail(f'cap {cap}: main analysis is not complete')
        if not isinstance(body, dict) or body.get('outcome') != 'stopped' or body.get('content') != 'not_produced' or body.get('text') != '':
            fail(f'cap {cap}: recovery was not stopped with an empty, not-produced body')
        segments = body.get('source_map', {}).get('segments') if isinstance(body.get('source_map'), dict) else None
        if segments != []:
            fail(f'cap {cap}: stopped main source map is not empty')
        diagnostics = body.get('diagnostics')
        if not isinstance(diagnostics, list) or not any(isinstance(d, dict) and d.get('code') == 'budget_exceeded_class_headers' and 'budget exceeded for ClassHeaders:' in str(d.get('message', '')) for d in diagnostics):
            fail(f'cap {cap}: original ClassHeaders refusal diagnostic missing')
        stopped.append({'cap': cap, 'physical_identity': identity, 'index': index, 'analysis_status': 'complete', 'recovery': 'stopped', 'empty_text_and_source_map': True})

    cap15 = docs[15]
    if cap15.get('execution', {}).get('status') != 'partial' or cap15.get('execution', {}).get('reason') != {'dimension': 'class_headers', 'kind': 'budget_exceeded'}:
        fail('cap 15 does not retain the request-level ClassHeaders stop')
    rows15 = cap15.get('methods')
    if not isinstance(rows15, list) or len(rows15) != 6:
        fail('cap 15 physical method census is not six')
    compared = []
    for n, (actual, expected) in enumerate(zip(rows15, wide_rows)):
        ai, ax = method_identity(actual, f'cap 15 method {n}')
        ei, ex = method_identity(expected, f'wide method {n}')
        if ai != ei or ax != ex or actual.get('text') != expected.get('text'):
            fail(f'cap 15 method {n}: physical identity/index/text differs from wide')
        if only_elapsed_normalized(actual.get('outcome')) != only_elapsed_normalized(expected.get('outcome')):
            fail(f'cap 15 method {n}: full outcome/analysis differs beyond elapsed usage fields')
        if not isinstance(actual.get('text'), str) or not actual['text']:
            fail(f'cap 15 method {n}: empty row text')
        compared.append({'position': n, 'index': ax, 'physical_identity': ai, 'text_bytes': len(actual['text'].encode('utf-8')), 'full_outcome_match_except_elapsed': True})
    main15 = next(m for m in rows15 if m['item']['identity']['name'] == MAIN_NAME and m['item']['identity']['descriptor'] == MAIN_DESC)
    body15 = main15['outcome']['report']
    if body15.get('content') != 'contains_statements' or not isinstance(body15.get('text'), str) or not body15['text'].strip():
        fail('cap 15 main body is not produced with statements')
    if not isinstance(body15.get('source_map'), dict) or body15['source_map'].get('segments') != wide_body['source_map']['segments']:
        fail('cap 15 produced source-map differs from wide')
    if not body15['source_map']['segments']:
        fail('cap 15 main source-map is empty')

    result = {
        'schema': 'class-source-six-cap-cli-semantic-audit-v2',
        'status': 'semantic_and_provenance_checks_passed',
        'raw_parsed_json_equivalence': 'each raw stdout byte stream and parsed JSON file is independently pinned; json.loads(raw_bytes) equals json.loads(parsed_bytes)',
        'build_cli_binding': {'status': build_receipt['status'], 'frozen_cli': frozen, 'source_manifest_entries': len(build_manifest), 'source_manifest_sha256': manifest_hash},
        'six_actual_commands': observed,
        'per_cap_usage': {str(c): {'limit': docs[c]['limits']['class_headers'], 'charged': docs[c]['usage']['class_headers'], 'execution_charged': docs[c]['execution']['usage']['class_headers']} for c in CAPS},
        'budget_refused_caps': refused,
        'prebody_stops': stopped,
        'wide_main': {'identity': wide_identity, 'index': wide_index, 'content': 'contains_statements', 'source_map_segments': len(wide_body['source_map']['segments'])},
        'cap15_methods': compared,
        'cap15_main': {'content': body15['content'], 'source_map_segments': len(body15['source_map']['segments'])},
    }
    (out / 'semantic-audit-v2.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'methods': len(compared), 'caps': len(observed)}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
