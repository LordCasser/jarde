#!/usr/bin/env python3
"""Semantic audit for a completed six-cap capture; consumes only saved JSON outputs."""
from __future__ import annotations
import argparse, json
from pathlib import Path

CAPS=(4096,1,2,8,14,15)
def strip_elapsed(value):
    if isinstance(value, dict):
        return {k: strip_elapsed(v) for k,v in value.items() if k != 'elapsed_millis'}
    if isinstance(value, list):
        return [strip_elapsed(v) for v in value]
    return value
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args();root=args.out.resolve()
    receipt=json.loads((root/'execution.json').read_text(encoding='utf-8'))
    if receipt.get('status')!='six_expected_exits_and_json_documents_captured_pending_semantic_audit':
        raise SystemExit('capture did not finish with all six expected exits')
    if not (receipt.get('inputs_identical') and receipt.get('build_source_manifest_identical') and receipt.get('current_source_matches_build_before_after') and receipt.get('target_absent_after')):
        raise SystemExit('input, source, or target binding did not remain stable')
    docs={c:json.loads((root/f'class-headers-{c}.parsed.json').read_text(encoding='utf-8')) for c in CAPS}
    wide=docs[4096]
    if wide.get('execution',{}).get('status')!='complete': raise SystemExit('wide H1 request is not complete')
    def main_method(doc):
        rows=doc.get('methods')
        if not isinstance(rows,list): raise SystemExit('class-source document has no method array')
        found=[m for m in rows if m.get('item',{}).get('name',{}).get('escaped')=='main']
        if len(found)!=1: raise SystemExit(f'expected one H1.main; got {len(found)}')
        return found[0]
    wide_main=main_method(wide)
    wide_body=wide_main.get('outcome',{}).get('report',{})
    wide_segments=wide_body.get('source_map',{}).get('segments')
    if not isinstance(wide_segments,list) or not wide_segments: raise SystemExit('wide H1.main has no nonempty requested source map')
    results=[]
    for cap in (8,14):
        doc=docs[cap]
        if doc.get('execution',{}).get('status')!='partial' or doc.get('execution',{}).get('reason',{}).get('dimension')!='class_headers':
            raise SystemExit(f'cap {cap} lacks a ClassHeaders partial request stop')
        main=main_method(doc); body=main.get('outcome',{}).get('report',{})
        if main.get('outcome',{}).get('kind')!='recovered' or body.get('content')!='not_produced' or 'stopped' not in body.get('outcome',{}):
            raise SystemExit(f'cap {cap} did not preserve the prebody stopped/not-produced main record')
        results.append({'class_headers':cap,'prebody_stop':'verified'})
    cap15=docs[15]
    if cap15.get('execution',{}).get('status')!='partial' or cap15.get('execution',{}).get('reason',{}).get('dimension')!='class_headers':
        raise SystemExit('cap 15 lacks its ClassHeaders partial request stop')
    main15=main_method(cap15); body15=main15.get('outcome',{}).get('report',{})
    seg15=body15.get('source_map',{}).get('segments')
    if body15.get('content')!='contains_statements' or not isinstance(seg15,list) or not seg15:
        raise SystemExit('cap 15 did not retain a produced main body with a nonempty source map')
    if len(cap15.get('methods',[]))!=len(wide.get('methods',[])):
        raise SystemExit('cap 15 physical method list length differs from wide H1')
    for idx,(actual,expected) in enumerate(zip(cap15['methods'],wide['methods'])):
        if (actual.get('item',{}).get('identity') != expected.get('item',{}).get('identity')
                or actual.get('item',{}).get('index') != expected.get('item',{}).get('index')
                or actual.get('text') != expected.get('text')
                or strip_elapsed(actual.get('outcome')) != strip_elapsed(expected.get('outcome'))):
            raise SystemExit(f'cap 15 method {idx} identity/text/outcome differs from wide aside from elapsed_millis')
    result={'status':'semantic_checks_passed','wide_complete':True,'prebody_caps':results,'cap15':'body-and-full-method-outcomes-match-wide-except-elapsed','wide_main_source_map_segments':len(wide_segments),'cap15_main_source_map_segments':len(seg15),'limits':list(CAPS)}
    (root/'semantic-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False));return 0
if __name__=='__main__': raise SystemExit(main())
