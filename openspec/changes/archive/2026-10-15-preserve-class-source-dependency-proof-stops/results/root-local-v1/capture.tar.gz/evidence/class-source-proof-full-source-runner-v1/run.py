#!/usr/bin/env python3
"""Retain exact H1 CLI sources and replay their whole-family Java 8 behavior."""
from __future__ import annotations

import argparse
import datetime
import json
import os
from pathlib import Path
import shutil
import importlib.util
import sys

HERE = Path(__file__).resolve().parent
CORE = HERE.parent
ROOT = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde').resolve()
EXISTING = CORE / 'interface-full-source-harness-v4/run_interface_full_source_harness.py'
FIXED = {
    'commands-template.json': 'dea775b183460a54c9b716c17522b49fa6cba642c709d0cf6493348ae8157b6b',
    'inputs.json': '27725a6b66899d86d0e7e47873bae3cd807a09f14a519f1ce2402956d90588f0',
    'expected.stdout.raw': 'f4bdad2c35ae4f3bc6f02934f340a5923235f8f659395a5a04a6a55b58922c70',
}


def load_existing():
    spec = importlib.util.spec_from_file_location('h1_existing_full_source_recorder', EXISTING)
    if spec is None or spec.loader is None:
        raise RuntimeError('existing recorder unavailable')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def write_json(path: Path, value) -> None:
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cli', type=Path, required=True)
    parser.add_argument('--receipt', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    cli, receipt, out = args.cli.resolve(), args.receipt.resolve(), args.out.resolve()
    if out.exists() or out.is_relative_to(ROOT):
        raise SystemExit('output must be fresh and outside the repository')
    if args.cli.is_symlink() or not cli.is_file() or not os.access(cli, os.X_OK):
        raise SystemExit('a regular executable frozen CLI is required')
    if (ROOT / 'target').exists():
        raise SystemExit('target must be absent; run only after exclusive validation completes')
    h = load_existing()
    for name, expected in FIXED.items():
        if h.sha(HERE / name) != expected:
            raise SystemExit(f'fixed replay input changed: {name}')
    config = json.loads((HERE / 'inputs.json').read_text())
    for expected in config['pins']:
        if h.pin(Path(expected['path'])) != expected:
            raise SystemExit(f'pinned original input/tool changed: {expected["path"]}')
    binding = h.verify_cli(cli, receipt)
    build = json.loads(receipt.read_text())
    if build.get('workspace_root') != str(ROOT):
        raise SystemExit('build receipt workspace differs from this source closure')
    source_before = build['source_manifest_before']
    if len(source_before) != 4902:
        raise SystemExit('the final receipt must bind the expected 4902-source closure')
    family = config['family']
    templates = json.loads((HERE / 'commands-template.json').read_text())
    if len(family) != 11 or len(templates) != 16:
        raise SystemExit('expected the fixed eleven-class, sixteen-command replay')
    oracle = (HERE / 'expected.stdout.raw').read_bytes()
    if oracle.count(b'\n') != 8 or not oracle.endswith(b'\n'):
        raise SystemExit('the fixed eight-line oracle lost its trailing newline')
    original_jar = next(Path(row['path']) for row in config['pins']
                        if row['path'].endswith('/hier-fam.jar'))
    inputs = sorted(set([Path(row['path']) for row in config['pins']]
                        + [HERE / name for name in FIXED]
                        + [Path(__file__).resolve(), cli, receipt]))
    inputs_before = [h.pin(path) for path in inputs]

    def source_pins():
        return [{'path': row['path'], 'bytes': (ROOT / row['path']).stat().st_size,
                 'sha256': h.sha(ROOT / row['path'])} for row in source_before]

    def unchanged(label):
        if [h.pin(path) for path in inputs] != inputs_before:
            raise RuntimeError(f'fixed input/tool/CLI/receipt changed: {label}')
        if source_pins() != source_before:
            raise RuntimeError(f'receipt-bound 4902-source closure changed: {label}')
        if (ROOT / 'target').exists():
            raise RuntimeError(f'unexpected concurrent target directory: {label}')

    unchanged('preflight')
    if shutil.disk_usage(ROOT).free < h.FREE_LIMIT:
        raise SystemExit('5GiB free-space preflight failed')
    out.mkdir(parents=True, exist_ok=False)
    for folder in ('inputs', 'java', 'classes', 'reports'):
        (out / folder).mkdir()
    jar_copy = out / 'inputs/hier-fam.jar'
    shutil.copyfile(original_jar, jar_copy)
    if h.sha(jar_copy) != h.sha(original_jar):
        raise RuntimeError('original JAR copy differs')
    write_json(out / 'build-receipt.json', build)
    write_json(out / 'source-manifest-before.json', source_before)
    write_json(out / 'input-manifest-before.json', inputs_before)
    (out / 'expected.stdout.raw').write_bytes(oracle)
    retained_fixed = [h.pin(path) for path in (jar_copy, out / 'expected.stdout.raw',
                                              out / 'build-receipt.json')]
    guard = h.load_module('h1_source_replay_guard', h.GUARD_PATH)
    scanner = h.load_module('h1_source_replay_scan', h.SCAN_PATH)
    guard.ROOT, guard.OUT = ROOT, out
    guard.FREE_LIMIT, guard.TARGET_LIMIT = h.FREE_LIMIT, h.TARGET_LIMIT
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.expected_test_summaries = lambda _index, _raw: None
    guard.command_stream = lambda path: h.pin(Path(path))
    guard.ENV_VALUES = {}
    tools = config['jdk_tools']
    java23_home = Path(tools['java23']['path']).parent.parent
    environment = {key: value for key, value in os.environ.items()
                   if key in ('HOME', 'TMPDIR', 'LANG', 'LC_ALL')}
    environment.update({'JAVA_HOME': str(java23_home),
                        'PATH': str(java23_home / 'bin') + os.pathsep + '/usr/bin:/bin'})
    environment.setdefault('LANG', 'C.UTF-8')
    record = {'schema': 'h1-full-source-cli-replay-v1', 'status': 'running',
              'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'cli_build_binding': binding, 'source_count': len(source_before),
              'fixed_inputs_before': inputs_before, 'retained_inputs': retained_fixed,
              'jdk_tools': tools, 'environment': environment,
              'guard': {'minimum_free_bytes': h.FREE_LIMIT,
                        'maximum_target_bytes': h.TARGET_LIMIT, 'poll_seconds': 1,
                        'process_group_termination': True},
              'family': family, 'commands': [], 'java_sources': [], 'oracle_checks': [],
              'class_report_observations': [], 'helper_noncomplete_requires_root_review': []}

    def save():
        write_json(out / 'execution.json', record)

    def stable_generated():
        for expected in retained_fixed + record['java_sources']:
            if h.pin(Path(expected['path'])) != expected:
                raise RuntimeError(f'retained input or exact emitted Java changed: {expected["path"]}')

    try:
        save()
        for index, template in enumerate(templates, 1):
            unchanged(f'before {index}')
            stable_generated()
            argv = [value.replace('{FINAL_CLI}', str(cli)).replace('{OUT}', str(out))
                    for value in template['argv']]
            row = guard.run_command(index, argv, environment)
            row['label'] = template['label']
            record['commands'].append(row)
            save()
            allowed_exits = (0, 4) if 2 <= index <= 11 else (0,)
            if row['guard_stop'] is not None or row['exit_code'] not in allowed_exits:
                raise RuntimeError(f'{template["label"]}: exit={row["exit_code"]}, guard={row["guard_stop"]}')
            stdout = Path(row['streams']['stdout']['path']).read_bytes()
            if index <= 11:
                report = json.loads(stdout.decode('utf-8', errors='strict'))
                if not isinstance(report, dict):
                    raise RuntimeError('the CLI JSON document is not a class report object')
                execution = report.get('execution', {})
                record['class_report_observations'].append({
                    'binary_name': family[index - 1], 'exit_code': row['exit_code'],
                    'execution': execution,
                })
                write_json(out / 'reports' / f'{family[index - 1]}.json', report)
                if index == 1 and execution.get('status') != 'complete':
                    raise RuntimeError('the H1 root must report Complete and exit0')
                for value in h.recursive_dicts(report):
                    if (value.get('status') == 'cancelled'
                            or (value.get('status') in ('partial', 'failed')
                                and isinstance(value.get('reason'), dict)
                                and value['reason'].get('kind') == 'budget_exceeded')):
                        raise RuntimeError('budget/cancellation execution is not an acceptable family source')
                if index > 1 and execution.get('status') != 'complete':
                    record['helper_noncomplete_requires_root_review'].append({
                        'binary_name': family[index - 1], 'exit_code': row['exit_code'],
                        'execution': execution,
                        'note': 'Preserved for root classification as ordinary value-level Unsupported/decode; no expected helper status invented.',
                    })
                if not isinstance(report.get('text'), str):
                    raise RuntimeError('the class report lacks its exact text string')
                declaration = report.get('declaration') or {}
                actual_name = declaration.get('item', {}).get('declaration', {}).get('this_class', {}).get('raw')
                if (index == 1 or actual_name is not None) and actual_name != list(family[index - 1].encode('utf-8')):
                    raise RuntimeError('the CLI report physical binary name differs from its requested class')
                write_json(out / 'reports' / f'{family[index - 1]}.json', report)
                java = out / 'java' / f'{family[index - 1]}.java'
                java.write_bytes(report['text'].encode('utf-8'))
                record['java_sources'].append(h.pin(java))
            elif index >= 13:
                matched = stdout == oracle
                record['oracle_checks'].append({'label': template['label'],
                                                 'raw_stdout_equals_fixed_oracle': matched})
                save()
                if not matched:
                    raise RuntimeError(f'{template["label"]}: raw stdout differs from the fixed eight-line oracle')
            stable_generated()
            unchanged(f'after {index}')
            save()
        if len(record['java_sources']) != 11 or len(record['oracle_checks']) != 4:
            raise RuntimeError('the whole-family compile/four-runtime replay was incomplete')
        record['status'] = 'expected_command_outcomes_observed_pending_independent_acceptance'
    except BaseException as error:
        record['status'] = 'failed_preserved_all_generated_evidence'
        record['error'] = f'{type(error).__name__}: {error}'
    finally:
        record['fixed_inputs_after'] = [h.pin(path) for path in inputs]
        after = source_pins()
        write_json(out / 'source-manifest-after.json', after)
        record['fixed_inputs_unchanged'] = record['fixed_inputs_after'] == inputs_before
        record['source_closure_unchanged'] = after == source_before
        record['target_absent'] = not (ROOT / 'target').exists()
        record['retained_classes'] = [h.pin(path) for path in sorted((out / 'classes').rglob('*'))
                                      if path.is_file()]
        record['retained_java_after'] = [h.pin(Path(row['path'])) for row in record['java_sources']]
        record['exact_emitted_java_unchanged'] = record['retained_java_after'] == record['java_sources']
        if not (record['fixed_inputs_unchanged'] and record['source_closure_unchanged']
                and record['target_absent'] and record['exact_emitted_java_unchanged']):
            record['status'] = 'failed_preserved_all_generated_evidence'
        record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
    print(json.dumps({'status': record['status'], 'commands': len(record['commands']),
                      'sources': len(record['java_sources']), 'out': str(out)}))
    return 0 if record['status'] == 'expected_command_outcomes_observed_pending_independent_acceptance' else 1


if __name__ == '__main__':
    raise SystemExit(main())
