# Class-source proof in-flight controls — v2 public H1 draft

This cache-only increment upgrades v1's hooks into four unit-test bodies that call the public `Engine::class_source_with_evidence` request on the pinned H1 hierarchy JAR: snapshot-prebody cancellation after a real accepted charge, snapshot-prebody elapsed-zero checkpoint, double-brace-postbody cancellation after a real accepted charge, and double-brace-postbody elapsed-zero checkpoint. Both seams filter to `H1.main([Ljava/lang/String;)V`.

The tests compare against a wide public baseline, check actual aggregate stop and observer refusal, preserve the prebody reliable physical prefix (allowing cancellation to prevent publication of main's stop record), preserve postbody method records and main recovery text/source map, and inspect usage for additional body/IR/output/evidence work, allowing at most one existing result-item charge.

This is still only a source draft. It has not been compiled, formatted, or run. Fixture/stage reachability, Rust API typing, exact coverage ranges, observer tail behavior, and source-map assertions all require the root's focused run. Existing report-only/error-channel tests and the cap8/cap15 historical matrix are separate evidence. No repository file was changed.
