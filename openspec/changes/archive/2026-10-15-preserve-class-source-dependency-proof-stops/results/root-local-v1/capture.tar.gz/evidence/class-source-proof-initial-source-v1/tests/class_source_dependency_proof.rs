//! Public regression for request stops while proving class-source dependencies.
use jarde::*;
use std::slice;

const H1: &[u8] = include_bytes!(
    "../openspec/evidence/java-syntax-2026-10-02/user-hierarchy-widening-patrol/fixture/hier/hier-fam.jar"
);

fn limits(class_headers: u64) -> Limits {
    let mut limits = task_budget(&[])
        .expect("default budget is valid")
        .limits()
        .clone();
    limits.elapsed_millis = u64::MAX;
    limits.class_headers = class_headers;
    limits
}

fn class_source(class_headers: u64) -> ClassSourceReport {
    let engine = Engine::new();
    let mut open_budget = Budget::new(limits(4096));
    let snapshot = engine
        .open(ArtifactInput::bytes(H1.to_vec()), &mut open_budget)
        .expect("frozen H1 archive opens");
    let request = ClassSourceRequest {
        class: ClassRef::Name {
            class: ClassNameQuery::internal("H1"),
        },
        environment: EnvironmentRequest {
            snapshot: snapshot.id().clone(),
            scope: PhysicalScope::SnapshotAll,
            policy: EnvironmentPolicy::PlainJar,
            profile: RuntimeProfile {
                java_release: 8,
                multi_release: MultiReleasePolicy::Disabled,
                layout: LayoutMode::Generic,
            },
            loader: LoaderId("app".to_owned()),
        },
    };
    let mut budget = Budget::new(limits(class_headers));
    let OperationOutcome::Performed(report) = engine
        .class_source_with_evidence(
            slice::from_ref(&snapshot),
            &request,
            &RecoveryEvidenceRequest::essential(),
            &mut budget,
        )
        .expect("selected H1 produces a public class-source report")
    else {
        panic!("H1 must resolve to one physical class");
    };
    report
}

fn stopped_for_class_headers(report: &ExecutionReport) -> bool {
    matches!(
        report,
        ExecutionReport::Partial {
            reason: TerminationReason::BudgetExceeded {
                dimension: BudgetDimension::ClassHeaders
            },
            ..
        }
    )
}

#[test]
fn h1_wide_budget_remains_complete_with_main_body() {
    let report = class_source(4096);
    assert!(matches!(
        &report.execution,
        ExecutionReport::Complete { .. }
    ));
    let main = report
        .methods
        .iter()
        .find(|method| method.item.identity.name.0 == b"main")
        .unwrap();
    assert!(
        matches!(&main.outcome, ClassSourceOutcome::Recovered { report, .. } if report.produced() && report.content == RecoveryContent::ContainsStatements)
    );
    assert!(report.text.contains("public static void main("));
}

#[test]
fn h1_cap_one_keeps_ordinary_class_header_budget_refusal() {
    let report = class_source(1);
    assert!(stopped_for_class_headers(&report.execution));
    assert!(report.methods.iter().any(|method| matches!(&method.outcome,
        ClassSourceOutcome::Refused { execution, .. } if stopped_for_class_headers(execution))));
}

#[test]
fn h1_cap_two_keeps_ordinary_class_header_budget_refusal() {
    let report = class_source(2);
    assert!(stopped_for_class_headers(&report.execution));
    assert!(report.methods.iter().any(|method| matches!(&method.outcome,
        ClassSourceOutcome::Refused { execution, .. } if stopped_for_class_headers(execution))));
}

fn assert_prebody_stop(cap: u64) {
    let report = class_source(cap);
    assert!(
        stopped_for_class_headers(&report.execution),
        "{:?}",
        report.execution
    );
    let main = report
        .methods
        .iter()
        .find(|method| method.item.identity.name.0 == b"main")
        .unwrap();
    let ClassSourceOutcome::Recovered {
        report: body,
        analysis,
    } = &main.outcome
    else {
        panic!("main retains the analysis and recovery result");
    };
    assert!(matches!(
        &analysis.execution,
        ExecutionReport::Complete { .. }
    ));
    assert!(
        stopped_for_class_headers(&body.execution),
        "{:?}",
        body.execution
    );
    assert!(matches!(&body.outcome, RecoveryOutcome::Stopped(_)));
    assert_eq!(body.content, RecoveryContent::NotProduced);
    assert!(body.text.is_empty());
    assert!(body.source_map.is_empty());
    assert!(body.declaration.is_none());
    assert!(body.artifact.binding().is_none());
    assert!(!report.text.contains("public static void main("));
}

#[test]
fn h1_cap_eight_stops_snapshot_proof_before_main_body() {
    assert_prebody_stop(8);
}

#[test]
fn h1_cap_fourteen_stops_snapshot_proof_before_main_body() {
    assert_prebody_stop(14);
}

#[test]
fn h1_cap_fifteen_keeps_main_body_but_stops_class_projection() {
    let report = class_source(15);
    assert!(
        stopped_for_class_headers(&report.execution),
        "{:?}",
        report.execution
    );
    let main = report
        .methods
        .iter()
        .find(|method| method.item.identity.name.0 == b"main")
        .unwrap();
    let ClassSourceOutcome::Recovered { report: body, .. } = &main.outcome else {
        panic!("main body remains committed");
    };
    assert!(body.produced());
    assert_eq!(body.content, RecoveryContent::ContainsStatements);
    assert!(report.text.contains("public static void main("));
    assert!(report.text.contains("System.out"));
    let wide = class_source(4096);
    assert_eq!(report.methods.len(), wide.methods.len());
    for (actual, expected) in report.methods.iter().zip(&wide.methods) {
        assert_eq!(actual.item.identity, expected.item.identity);
        assert_eq!(actual.item.index, expected.item.index);
        assert_eq!(actual.text, expected.text);
        assert_eq!(
            without_elapsed(serde_json::to_value(&actual.outcome).unwrap()),
            without_elapsed(serde_json::to_value(&expected.outcome).unwrap())
        );
    }
}

fn without_elapsed(value: serde_json::Value) -> serde_json::Value {
    match value {
        serde_json::Value::Object(fields) => serde_json::Value::Object(
            fields
                .into_iter()
                .filter(|(key, _)| key != "elapsed_millis")
                .map(|(key, value)| (key, without_elapsed(value)))
                .collect(),
        ),
        serde_json::Value::Array(values) => {
            serde_json::Value::Array(values.into_iter().map(without_elapsed).collect())
        }
        other => other,
    }
}
