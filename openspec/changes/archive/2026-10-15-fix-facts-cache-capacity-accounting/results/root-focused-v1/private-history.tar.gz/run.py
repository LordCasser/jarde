import os,sys,json,importlib.util,subprocess,hashlib
from pathlib import Path
O=Path(__file__).parent
spec=importlib.util.spec_from_file_location('guard',O/'isolated_guard.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
g.OUT=O;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.expected_test_summaries=lambda *args:None
g.command_stream=lambda p:{'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':g.sha_file(p)}
env=os.environ.copy()
for k in (*g.STRIPPED_ENV_KEYS,'CARGO_TARGET_DIR','RUST_MIN_STACK'):env.pop(k,None)
env.update(g.ENV_VALUES);env.update(RUSTUP_TOOLCHAIN='stable',CARGO_NET_OFFLINE='true')
idx=int(sys.argv[1]);args=sys.argv[2:]
paths=subprocess.check_output(['rg','--files','--hidden','src','crates','tests','examples','.github','Cargo.toml','Cargo.lock'],cwd=g.ROOT,text=True).splitlines()
paths=[p for p in paths if '/target/' not in p]
def pins():return {p:g.sha_file(g.ROOT/p) for p in paths}
before=pins();g.write_json(O/f'{idx}.source-before.json',before)
try:
 row=g.run_command(idx,args,env);row['source_before']=str(O/f'{idx}.source-before.json');row['environment']= {k:env.get(k) for k in [*g.ENV_VALUES,'RUSTUP_TOOLCHAIN','CARGO_NET_OFFLINE','CARGO_TARGET_DIR','RUST_MIN_STACK']}
 after=pins();g.write_json(O/f'{idx}.source-after.json',after);row['source_unchanged']=before==after
 if args[:2]==['cargo','test'] and row['exit_code']==0 and row['guard_stop'] is None:
  removed=[];g.clean_successful_test_binary(idx,removed);row['cleanup']=removed
 g.write_json(O/f'{idx}.command.json',row);print(json.dumps(row),flush=True)
 sys.exit(0 if row['exit_code']==0 and row['guard_stop'] is None else 1)
finally:
 if args[:2]==['cargo','clean'] or ('row' not in locals()) or row['exit_code']!=0 or row['guard_stop'] is not None:
  result=subprocess.run(['cargo','clean','--manifest-path',str(g.ROOT/'Cargo.toml')],cwd=g.ROOT,env=env,capture_output=True)
  (O/f'{idx}.cleanup.stdout.raw').write_bytes(result.stdout);(O/f'{idx}.cleanup.stderr.raw').write_bytes(result.stderr)
  g.write_json(O/f'{idx}.cleanup.json',{'argv':['cargo','clean','--manifest-path',str(g.ROOT/'Cargo.toml')],'cwd':str(g.ROOT),'exit_code':result.returncode,'target_absent':not(g.ROOT/'target').exists()})
