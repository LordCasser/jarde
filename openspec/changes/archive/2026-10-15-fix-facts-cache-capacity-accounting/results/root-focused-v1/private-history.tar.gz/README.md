# FactsCache 隔离验证 cache-v1

唯一构建目录为 `/home/lordcasser/.codex/worktrees/review-core-fixes/jarde`，HEAD `5f18b2a94e1b8eab8296dc38768463657f436d50`。共享工作区未写入。

原逻辑成功编译，新增三项 capacity 单元测试均真实失败：总条目 3 > 2、失效残留185字节、混合权重1849 > 1664。command 1 保留失败日志，并在 finally 清理 target，真实 target_absent=true。随后恢复完整候选，仅格式化，没有放宽断言或修测试错误。

修复后实际通过：reader lib 181；P5 facts 15（包含两项新增 public 回归）；shared payload 6；container lookup 29，默认忽略1项计时；精确 P5 source construction guard 1；definition read reuse 11（启用 all-features）。command 5 默认 feature 的 definition target 运行0项，保留历史，不作验收依据；command10补跑真实 feature 测试。fmt check通过。

每段 Cargo 使用隔离 ROOT 的原 guard.run_command，最低5GiB空闲、target最高1GiB、offline/stable/jobs1/incremental0/debug0/test_threads1，清除外部 target/Rust stack/Java options。所有 guard_stop 为 null，最大target峰值约438MB。成功test executable逐段清理，最终运行 `cargo clean --manifest-path /home/lordcasser/.codex/worktrees/review-core-fixes/jarde/Cargo.toml`，并记录真实 target_absent=true；这是带 manifest 参数的清理，不属于严格的 `cargo clean` 无参数执行。

`execution.json` 包含所有命令、原始输出SHA、源码全量pins、失败历史与清理记录。`manifest.json` 绑定四文件格式化源码与 `validated-candidate.patch`。before/after 为隔离HEAD和最终源码快照。未运行 workspace/Clippy/OpenSpec strict/CI，未改 tasks、未commit/push。
