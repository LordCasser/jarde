//! A bounded in-memory store of the facts a request reads and another request may reuse.
//!
//! P5 2.1 measured the direct path and 2.2 decided what a cache would have to bind; this module is
//! that record built, under the boundary the change documents fix: **in memory only** (no file, no
//! format on disk, no migration), **no third-party dependency**, **disabled unless a caller
//! attaches one**, and **no concurrency**: the engine is one sequential scan and nothing here
//! spawns work.
//!
//! It holds three layers, keyed and verified separately because they answer different questions:
//!
//! * the **CP/Header layer** — a class's parsed structure, keyed by the class bytes' content and
//!   the parse policy;
//! * the **container layer** (bound-container-lookup) — a container's **verified facts**: the
//!   immutable backing its entries live in, its complete central directory, and the multi-value
//!   raw-name locator over that directory;
//! * the **definition-read layer** (reuse-selected-class-read) — the **bytes one verified read of
//!   one selected physical definition produced**, keyed by that definition's own identity (the
//!   snapshot, the complete physical location, the content digest, the declared length and the
//!   variant) and by [`DEFINITION_READ_SCHEMA`]. It holds no parse, no `PreparedClass` and no
//!   method-level product: what a hit hands back is the bytes and the identity the read that
//!   produced them established.
//!
//! All three are immutable once written, all three are written only by a read that ran to the end,
//! all three are bounded by the same two limits, and all three are refused rather than evicted when
//! they do not fit. Nothing here is a session, a global, or a second injection path: a
//! [`FactsCache`] is an explicit handle on [`Budget`], and the engine constructs none.
//!
//! ## What the CP/Header layer holds, and what it deliberately does not
//!
//! The entry is a [`ClassFacts`] (constant pool and declaration structure) or a
//! [`HeaderInspection`] (the same structure plus the version gate). Both are **pure functions of
//! the class bytes and the parse policy**, which is why this is the layer the `facts-cache` spec
//! calls CP/Header and why its key is the one the spec names:
//!
//! | key dimension | carrier |
//! | --- | --- |
//! | class content digest (and length) | the bytes the entry was parsed from — hashed here, or the
//!   [`ClassBytesId`] a verified read already published |
//! | parser / registry version | [`FactsIdentity::registry`], which is [`HIGHEST_REGISTERED_MAJOR`] |
//! | parse policy | [`ParsePolicy`]: the structural facts, or the header under `InspectionMode` |
//! | budget (completeness) | an entry is written **only** by a parse that ran to the end |
//!
//! The dimensions the upper layers need are **not** in this key and must not be: a `ClassFacts` is
//! the same value whatever runtime profile, output level, dependency set or recovery pass asked for
//! it, so binding any of those here would be an invalidation for a change that cannot change the
//! answer. The resolution layer adds symbol/source context, view/domain/platform and the provider
//! snapshot; the IR and source layers add the method content, the analysis/recovery identities, the
//! output level and the naming configuration — those layers own that record (`tests/p5_benchmark.rs`
//! holds the per-layer dimension list, and its IR and recovery entries still have no carrier in the
//! code at all).
//!
//! ## What the container layer holds, and why its key is physical
//!
//! A container product is what the reader proved about one container in one snapshot: its
//! **backing** (the bytes its central directory and entries live in — the snapshot's own bytes for
//! the root container, the verified materialization of a nested entry otherwise), its **complete**
//! central directory, and the **locator** from a raw name to every record that carries it, in
//! central-directory order. It is keyed by the snapshot's content identity, the full
//! [`ContainerOrigin`] and [`CONTAINER_FACTS_SCHEMA`]:
//!
//! * `RuntimeProfile`, loader order and any prefix are **not** dimensions: a container's physical
//!   facts are the same whatever order searched it, and those are applied by the resolver per
//!   request. Two requests that name the same origin share one product.
//! * Only a directory that parsed **completely** is offered. A stopped parse — budget,
//!   cancellation, damage — is refused with the reason, never published as a prefix, so "this
//!   container holds no such name" can never be read out of an incomplete directory.
//! * A retained locator is only ever used against the backing it was built from, and the selected
//!   entry's own local header, CRC and sizes are re-verified on every read, so a hit changes what
//!   the request pays for and never what it proves.
//!
//! ## What the definition-read layer holds, and why its key is the definition
//!
//! A definition read is the read one identity-addressed request performs for the definition it
//! **selected**: the snapshot's entry at the definition's own coordinates, read through the
//! verifying reader (CRC and size re-established from the bytes) and digested. This layer keeps the
//! two things that read produced — its bytes and their content digest — under
//! [`DefinitionReadKey`], whose dimensions are the definition's own:
//!
//! | key dimension | carrier |
//! | --- | --- |
//! | immutable snapshot | the snapshot id inside the physical location (a snapshot derives it from
//!   its own bytes), so two snapshots that hold the same class bytes at the same coordinates are
//!   two keys |
//! | complete physical location | the container chain, the entry's ordinal and its raw name |
//! | content digest and declared length | the [`ClassBytesId`] the definition states — and the
//!   identity the read that produced the bytes really established |
//! | variant (multi-release selection result) | the [`crate::model::PhysicalVariant`] the location's
//!   raw name derives |
//! | read schema | [`DEFINITION_READ_SCHEMA`] |
//!
//! Any one of them differing is **another key**, never a near miss: "the same name in another
//! snapshot", "the same bytes at another origin", "another entry of the same content" and "another
//! variant of the same coordinates" all answer nothing and fall back to the direct read. Nothing
//! about *which request* asked is part of the key — a definition read is a property of one physical
//! definition of one snapshot, which is what an identity-addressed request selects.
//!
//! A retained read is a read that **happened**: only a read that ran to the end, whose bytes were
//! checked against the entry and digested, is offered here, and
//! [`FactsCache::remember_definition_read`] refuses to keep bytes that are not the identity the
//! definition declares. A read the budget stopped, a cancelled one and a damaged one are therefore
//! all *absent*, never a partial answer: nothing negative, incomplete or refused can be published,
//! exactly as at the two layers above.
//!
//! ## What a hit is, and what it can never be
//!
//! ## The store is not the only answer, and not a second lifetime
//!
//! A read asks this store **first**, exactly as it always has, and a hit changes nothing about what
//! the read proves. What the store cannot answer is a container product some *live handle* still
//! holds: a scope cursor inside its container, a prepared class read, or any other handle a consumer
//! is keeping. That answer is the snapshot's own record of what is in use
//! ([`crate::artifact::ContainerFactsHandle`]) and it is deliberately not part of this type — a
//! store retains facts nothing is using any more, capacity-bounded and reportable, while a handle is
//! a lifetime the consumer owns. The two are complementary, and neither can be reached from the
//! other: clearing this store, filling it or refusing an insertion never makes a request re-parse a
//! directory whose product it is still holding, and a released handle never makes this store answer
//! something it does not hold.
//!
//! * **The read still happens.** The CP/Header cache sits *above* the bounded read and *below*
//!   every consumer: the bytes are materialized, charged, CRC-checked and digested exactly as the
//!   direct path does, and only the parse is skipped. Coverage, origins, read evidence and the
//!   entry's identity are therefore produced by the same code on both paths, and a hit cannot claim
//!   a range nobody read. The container layer is the same rule one level down: a hit skips the
//!   directory parse and the parent's re-materialization, and the class read that follows is still
//!   charged and still verified.
//! * **A hit charges no counted dimension it did not perform.** It reads, decodes and derives
//!   nothing beyond the read the request still owes; the dimensions that measure those steps stay
//!   where they are, and the saving is what the comparison reports. A hit still calls
//!   [`Budget::poll`] and still applies the **current** request's structural limits — a container
//!   retained under a wider `NestedDepth` is not served to a request that may not reach it — so a
//!   cancelled, expired or already-stopped request terminates through the cache exactly as it does
//!   without one.
//! * **Nothing negative, partial or refused is ever stored.** A parse that stops (budget,
//!   cancellation, a strict version refusal) writes nothing, so an incomplete answer can never stand
//!   in for a complete one and a negative verdict can never be replayed after the reason for it
//!   changed. The products here are refused-or-absent, never "no such class" and never "no such
//!   name".
//! * **Content is shared, origins are not.** Two entries, two snapshots or two loaders that hold the
//!   same bytes share one entry; what comes back is a value that carries no origin, and the caller
//!   binds the physical origin it read from. A cache cannot merge two origins because it never held
//!   one. A container product is the other way round: it *is* one origin, and a lookup that names
//!   another one cannot reach it.
//!
//! ## The shared handle, and the trusted digest
//!
//! An answer is immutable once written, so it is handed out as the handle the store holds
//! (`Arc<ClassFacts>` / `Arc<HeaderInspection>`) instead of being copied: one class prepared once
//! and consumed by every method of it is one payload, and the lock that answers a hit performs an
//! `Arc::clone` and nothing else. A hold is separate from retention — clearing the store, a store
//! that has room for nothing, or a later read rewriting the same key releases the store's own
//! reference and leaves a live handle exactly as it was, which is what "a request that is already
//! consuming these facts keeps consuming them" means.
//!
//! Each product has two entry shapes and they are the same consultation: [`FactsCache::structure_shared`]
//! and [`FactsCache::header_shared`] hash the bytes, while [`FactsCache::trusted_structure`] and
//! [`FactsCache::trusted_header`] take the content identity a verified read already published
//! ([`ClassBytesId`]), so consuming one prepared class does not re-hash its backing per method. One
//! content is one key either way, which is why a trusted lookup cannot be answered with another
//! class's facts and why a digest or a length that does not match the bytes finds nothing.
//!
//! ## Capacity, weight and release
//!
//! Both layers share one budget and two bounds ([`FactsCapacity`]): a number of answers and a
//! retained weight in bytes. The weight is a **proxy for residency, never RSS**: a container
//! contributes its backing bytes, a per-record estimate for its directory and the names its locator
//! holds; a CP/Header entry contributes the length of the class bytes it was parsed from. A backing
//! referenced by one product is counted once; nothing is ever charged twice for the same memory.
//! An insertion that would cross either bound is refused and counted ([`FactsReport::refused_capacity`],
//! [`FactsReport::refused_capacity_bytes`]) — there is no eviction and no replacement policy — and
//! the request that was refused keeps using the facts it already read, so a refusal never makes it
//! read anything again. [`FactsCache::clear`] and dropping every handle release what the store held.
//!
//! ## Versions, damage and the fallback
//!
//! Every entry records the [`FactsIdentity`] it was written under. A lookup that finds an entry
//! written under another **entry format** or another **registry version** discards it, counts the
//! discard and returns "not answered by the cache" — the caller then runs the direct path under the
//! budget it already holds. There is no second attempt, no re-run and no budget reset: the fallback
//! is the same bounded read the cache would have replaced.

use crate::artifact::ContainerFacts;
use crate::budget::Budget;
use crate::classfile::{ClassFacts, HeaderInspection, InspectionMode};
use crate::error::{Error, Result};
use crate::model::{ClassBytesId, ContainerOrigin, Digest};
use crate::release_registry::HIGHEST_REGISTERED_MAJOR;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::sync::{Arc, Mutex, MutexGuard};

/// The entry format this build writes.
///
/// An entry carries the format it was written in, and a lookup discards one written in another: a
/// store that outlived a change to what an entry holds is read as "this entry is not answerable"
/// rather than as the answer. The number is this build's declaration, not a compatibility promise.
pub const FACTS_FORMAT: u16 = 1;

/// The container-directory schema this build writes.
///
/// A container product is keyed by it as well as by the physical origin, so a build that changes
/// what a directory holds or how it is verified cannot serve an old directory as the new answer:
/// the schema is part of the key and a changed schema simply misses. Like [`FACTS_FORMAT`] this is
/// this build's declaration, not a compatibility promise.
pub const CONTAINER_FACTS_SCHEMA: u16 = 1;

/// The schema this build keys a retained **definition read** under.
///
/// A retained definition read is the bytes one verified read of one *selected* physical definition
/// produced, together with the content identity that read established, keyed by that definition's
/// own identity — see [`DefinitionReadKey`]. A build that changes what such a read holds, or how it
/// is verified, cannot serve an old one as the answer: the schema is part of the key and a changed
/// schema simply misses. Like [`FACTS_FORMAT`] and [`CONTAINER_FACTS_SCHEMA`] this is this build's
/// declaration, not a compatibility promise.
pub const DEFINITION_READ_SCHEMA: u16 = 1;

/// How much one store may retain, in two independent bounds.
///
/// The store refuses an insertion that would cross either bound; nothing here evicts, so an
/// insertion that fits stays until the store is cleared or dropped. Both bounds are needed
/// because they bound different things: the entry limit bounds the *number* of retained answers
/// (each one a map slot, an identity and a payload header) while the retained-byte limit bounds
/// the bytes those answers hold — a nested container's backing, its directory and name table, or
/// a class's CP/Header payload.
///
/// The byte figure is a **residency proxy**, never RSS: it is the sum of the weights this module
/// computes (see [`FactsReport::retained_bytes`]), with no allocator overhead, no fragmentation
/// and no copy an upper layer made of a fact it read here.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct FactsCapacity {
    /// Retained answers: CP/Header entries, container products and definition reads.
    pub entries: usize,
    /// Retained weight, in bytes, across every entry, container product and definition read.
    pub retained_bytes: u64,
}

impl FactsCapacity {
    pub const fn new(entries: usize, retained_bytes: u64) -> Self {
        Self {
            entries,
            retained_bytes,
        }
    }

    /// A capacity that retains nothing. A store with it is a **counter**: every look-up misses,
    /// every insertion is refused, and no request changes what it does, so a measurement can
    /// observe how many directories a path parsed and how many nested containers it
    /// materialized without retaining any of them.
    pub const fn none() -> Self {
        Self::new(0, 0)
    }

    /// A stable one-line description, with no counter in it.
    pub fn describe(&self) -> String {
        format!(
            "{} entries / {} retained bytes",
            self.entries, self.retained_bytes
        )
    }
}

/// The declaration a store's entries are read under: the parser/registry version and the entry
/// format.
///
/// It is a *declaration* — the same shape `ResolutionEnvironment` has — and [`Self::current`] is the
/// value of this build. A caller holding a store that another build filled declares that other
/// identity when it reads it, which is how an incompatible entry is *detected* instead of served.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash, Serialize, Deserialize)]
pub struct FactsIdentity {
    /// The release registry's version the facts were parsed under (the reader's parser, as the
    /// registry states the dialect it validates).
    pub registry: u16,
    /// The entry format the entries were written in.
    pub format: u16,
}

impl FactsIdentity {
    /// The identity of this build's parser.
    pub const fn current() -> Self {
        Self {
            registry: HIGHEST_REGISTERED_MAJOR,
            format: FACTS_FORMAT,
        }
    }

    pub const fn new(registry: u16, format: u16) -> Self {
        Self { registry, format }
    }

    /// A stable one-line description of the declaration, with no counter in it: this is what a
    /// measurement context records as the cache state, so it may not move between two runs of one
    /// configuration.
    pub fn describe(&self) -> String {
        format!("registry {} entry format {}", self.registry, self.format)
    }
}

/// The parse policy an entry was produced under.
///
/// A header inspection is *not* policy-free: `Strict` refuses a release the registry does not
/// validate while `Forensic` reads its structure and reports the dialect instead. The two answers
/// are different products of the same bytes, so the policy is a key dimension and one policy's
/// entry is never served to another — which is what keeps a strict request from being answered
/// with a forensic read that a strict read would have refused.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub(crate) enum ParsePolicy {
    /// The constant pool and the declaration structure: `class_facts`, which applies no version
    /// gate and refuses no version.
    Structure,
    /// The header inspection under `InspectionMode::Strict`.
    Strict,
    /// The header inspection under `InspectionMode::Forensic`.
    Forensic,
}

impl ParsePolicy {
    pub(crate) const fn of(mode: InspectionMode) -> Self {
        match mode {
            InspectionMode::Strict => Self::Strict,
            InspectionMode::Forensic => Self::Forensic,
        }
    }

    /// Whether a payload of this kind answers this policy.
    const fn holds(self, payload: &FactsPayload) -> bool {
        match (self, payload) {
            (Self::Structure, FactsPayload::Structure(_)) => true,
            (Self::Strict | Self::Forensic, FactsPayload::Header(_)) => true,
            (Self::Structure, FactsPayload::Header(_))
            | (Self::Strict | Self::Forensic, FactsPayload::Structure(_)) => false,
        }
    }
}

/// What one class's bytes are cached under: their content, and the policy that was asked of them.
///
/// The digest is the *content* identity, so two entries of one archive, two snapshots and two
/// loaders that hold the same bytes share one entry. Nothing about where the bytes were read is
/// part of the key, and that is deliberate: an entry describes bytes, and the caller that returns a
/// fact binds the origin it read the bytes from.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct FactsKey {
    pub(crate) digest: Digest,
    pub(crate) length: u64,
    pub(crate) policy: ParsePolicy,
}

impl FactsKey {
    /// The key for class bytes whose content identity a **verified read already computed**.
    ///
    /// A read that materialized the bytes already digested them for the entry it was read from, and
    /// hashing the same backing again per lookup is work the cache is supposed to remove rather than
    /// add. The digest and the length this takes are the ones such a read published
    /// ([`ClassBytesId`]); a caller that has no such evidence keeps using [`Self::of`], which
    /// hashes the bytes here.
    ///
    /// Both produce the **same key** for the same content: [`Self::of`] is this function applied to
    /// the digest it computes, so a trusted lookup and a byte lookup of one class answer one entry.
    pub(crate) fn from_trusted(digest: Digest, length: u64, policy: ParsePolicy) -> Self {
        Self {
            digest,
            length,
            policy,
        }
    }

    /// The class bytes' identity, hashed only when a cache is really consulted: the direct path
    /// computes no digest it does not already need, so attaching no cache costs no hashing.
    fn of(bytes: &[u8], policy: ParsePolicy) -> Self {
        Self::from_trusted(
            Digest(blake3::hash(bytes).to_hex().to_string()),
            bytes.len() as u64,
            policy,
        )
    }
}

impl Ord for FactsKey {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        self.digest
            .0
            .cmp(&other.digest.0)
            .then_with(|| self.length.cmp(&other.length))
            .then_with(|| self.policy.cmp(&other.policy))
    }
}

impl PartialOrd for FactsKey {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

/// What one container's facts are cached under: the snapshot's content identity, the complete
/// physical origin of the container, and the directory/verification schema.
///
/// The origin carries the snapshot identity, and the snapshot is named again here so the key
/// states its two content dimensions — the bytes the container lives in and the chain that
/// reaches it — without a reader having to know that the origin embeds the first one.
///
/// `RuntimeProfile`, loader order and prefix are **not** dimensions: they are applied by the
/// resolver to the facts it gets back and cannot change what a container physically is. Two
/// requests that name the same origin share one directory whatever order they searched in.
#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub(crate) struct ContainerKey {
    pub(crate) snapshot: crate::model::SnapshotId,
    pub(crate) origin: ContainerOrigin,
    pub(crate) schema: u16,
}

/// One retained container product: the verified facts plus the declaration they were read under.
#[derive(Clone, Debug)]
struct ContainerEntry {
    identity: FactsIdentity,
    facts: Arc<ContainerFacts>,
    /// The weight this product contributes to the store's retained bytes. Recomputed at insertion
    /// and stored beside the product so a rewrite can subtract exactly what it added.
    weight: u64,
}

/// What one definition read is retained under: the definition's own identity, once and complete.
///
/// Every dimension of the definition is a dimension of this key: the snapshot id (which a snapshot
/// derives from its own bytes), the complete physical location (the container chain, the entry's
/// ordinal and its raw name), the content digest and the declared length, and the variant the
/// location's raw name derives. A lookup that differs in **any** one of them is another key rather
/// than a near miss, so no definition can be answered with another one's bytes — not by name, not by
/// coordinate, not by "the content looks the same".
///
/// Nothing about *which request* asked is a dimension: a definition read is a property of one
/// physical definition of one snapshot, which is exactly what an identity-addressed request selects.
/// The map over these keys is a `HashMap` because nothing ever iterates it — keys are looked up,
/// rewritten, discarded and counted, and no order is ever read out of it.
#[derive(Clone, Debug, Eq, PartialEq, Hash)]
pub(crate) struct DefinitionReadKey {
    pub(crate) definition: crate::model::PhysicalDefinitionId,
    pub(crate) schema: u16,
}

/// One retained definition read: the bytes a verified read produced, and the identity they answer
/// under.
///
/// The bytes are immutable once written and shared as one handle, so a hit copies no allocation of
/// its own before the caller asks for owned bytes. `class_bytes` is the identity **the read
/// established** — the digest computed over exactly these bytes, and their length — and it is the
/// same value the key was built from: [`FactsCache::remember_definition_read`] keeps a read only
/// when it is the definition's own, so an entry can never answer under an identity its bytes did not
/// establish.
#[derive(Clone, Debug)]
struct DefinitionRead {
    identity: FactsIdentity,
    class_bytes: ClassBytesId,
    bytes: Arc<Vec<u8>>,
    /// The weight this read contributes to the store's retained bytes: the length of the bytes it
    /// holds, stored beside them so a rewrite can subtract exactly what it added.
    weight: u64,
}

/// One cached answer, held as the shared handle its consumers read.
///
/// The payload is an `Arc` because an answer is **immutable once written** and several consumers may
/// hold it at once: a hit hands out `Arc::clone` inside the lock and copies nothing, so a class
/// prepared once is not copied per method, and the handle a consumer holds stays valid after
/// [`FactsCache::clear`], after the store has room for nothing else, and after a later read rewrites
/// the same key. Sharing the handle never shares an origin: an answer carries none, and the caller
/// that read the bytes binds the origin it read them from.
#[derive(Clone, Debug, Eq, PartialEq)]
enum FactsPayload {
    Structure(Arc<ClassFacts>),
    Header(Arc<HeaderInspection>),
}

/// One entry: the payload plus the declaration it was written under.
#[derive(Clone, Debug, Eq, PartialEq)]
struct Entry {
    identity: FactsIdentity,
    payload: FactsPayload,
    /// The weight this payload contributes to the store's retained bytes: the length of the class
    /// bytes it was parsed from, stored beside it so a rewrite can subtract exactly what it added.
    weight: u64,
}

/// Why an entry found under a key could not be used.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Unusable {
    /// Written in another entry format.
    Format,
    /// Parsed under another registry version.
    Registry,
    /// Holds the other product: the store's invariant, not a policy a caller can reach.
    Product,
}

/// What one store has answered, in one place.
///
/// The CP/Header counters keep their meaning; the container counters are separate because the two
/// products answer different questions and a measurement has to be able to say which one moved.
/// `directory_parses` and `nested_materializations` count **work the store's callers did**, not
/// work the store did: they are how a request reports that it built a directory or expanded a
/// nested container while holding this handle, and a reuse saves them by never being counted.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
struct Counters {
    consultations: u64,
    hits: u64,
    misses: u64,
    stored: u64,
    refused_capacity: u64,
    refused_capacity_bytes: u64,
    discarded_format: u64,
    discarded_registry: u64,
    discarded_product: u64,
    /// Container-products looked up, answered from retention, and not found.
    container_consultations: u64,
    container_hits: u64,
    container_misses: u64,
    /// Container products written by a request that had already read them completely.
    container_stored: u64,
    /// Container directories parsed by a request holding this handle (a hit never parses one).
    directory_parses: u64,
    /// Nested containers materialized by a request holding this handle, and the bytes produced.
    nested_materializations: u64,
    nested_materialized_bytes: u64,
    /// Definition reads looked up in retention, answered from it, and not found.
    definition_read_consultations: u64,
    definition_read_hits: u64,
    definition_read_misses: u64,
    /// Definition reads this store accepted: the reads whose bytes it now keeps.
    definition_read_stored: u64,
}

/// The entries and their counters, shared by every handle that reads them.
#[derive(Debug)]
struct Shared {
    capacity: FactsCapacity,
    /// CP/Header entries, keyed by class content and parse policy.
    entries: BTreeMap<FactsKey, Entry>,
    /// Container products, keyed by snapshot, physical origin and schema.
    containers: BTreeMap<ContainerKey, ContainerEntry>,
    /// Definition reads, keyed by the definition's own identity and this build's schema.
    definition_reads: std::collections::HashMap<DefinitionReadKey, DefinitionRead>,
    /// The weight every retained entry, container product and definition read contributes, summed.
    retained_bytes: u64,
    counters: Counters,
}

impl Shared {
    fn total_entries(&self) -> usize {
        self.entries.len() + self.containers.len() + self.definition_reads.len()
    }
}

/// The state of one store, as the caller that holds a handle can report it.
///
/// The whole point of reporting it *outside* the result is that the cache is transparent: a
/// fallback, a discard or a capacity refusal changes no evidence, coverage, representation or
/// diagnostic, so it may not appear in the published report as if it had. `performance-gates`'
/// `Cold and warm results` compares those planes for equality, and a cache state tucked into them
/// would make every warm run disagree with its cold one for a reason that is not a result.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct FactsReport {
    pub identity: FactsIdentity,
    pub capacity: FactsCapacity,
    /// How many CP/Header entries this store holds now.
    pub entries: usize,
    /// How many container products this store holds now.
    pub containers: usize,
    /// The weight of everything the store holds now, in the units [`FactsCapacity`] bounds. A
    /// **residency proxy**, not RSS: see that type's documentation.
    pub retained_bytes: u64,
    /// How many definition reads this store holds now.
    pub definition_reads: usize,
    /// The weight those reads contribute to [`FactsReport::retained_bytes`], as the sum of the
    /// lengths of the bytes they hold. Reported beside the total so a measurement can say what the
    /// definition-read layer costs on its own instead of reading it out of a difference.
    pub definition_read_bytes: u64,
    /// Lookups asked of the store. `hits + misses`; a discarded entry counts as a miss.
    pub consultations: u64,
    pub hits: u64,
    pub misses: u64,
    /// Entries written by a parse that ran to the end. A parse that stopped writes nothing, which
    /// is why no counter here can say "an incomplete answer was stored".
    pub stored: u64,
    /// Stores refused because the store already held `capacity.entries` answers: the facts stayed
    /// uncached and the request was served by its own read.
    pub refused_capacity: u64,
    /// Stores refused because the answer, or the answer beside what the store already held, would
    /// cross `capacity.retained_bytes`. Separate from [`FactsReport::refused_capacity`] so a
    /// measurement can say which bound the retention hit.
    pub refused_capacity_bytes: u64,
    /// Entries *discarded* because they were written in another entry format.
    pub discarded_format: u64,
    /// Entries discarded because they were parsed under another registry version.
    pub discarded_registry: u64,
    /// Entries discarded because they did not hold the product their policy names.
    pub discarded_product: u64,
    /// Container lookups asked of the store, answered from it, and not found.
    pub container_consultations: u64,
    pub container_hits: u64,
    pub container_misses: u64,
    /// Complete container products this store accepted.
    pub container_stored: u64,
    /// Container directories the requests holding this handle parsed. A hit never parses one, so
    /// this is the count a reuse makes stop moving.
    pub directory_parses: u64,
    /// Nested containers those requests materialized, and the bytes that produced. A hit never
    /// materializes one, for the same reason.
    pub nested_materializations: u64,
    pub nested_materialized_bytes: u64,
    /// Definition reads looked up in retention, answered from it, and not found. One lookup is one
    /// definition read a request asked for by the definition's own identity.
    pub definition_read_consultations: u64,
    pub definition_read_hits: u64,
    pub definition_read_misses: u64,
    /// Definition reads this store accepted: a read that ran to the end and whose bytes are the
    /// identity they were offered under. A read a budget stopped, a cancelled one and a damaged one
    /// never reach a store, so no counter here can say an incomplete read was retained.
    pub definition_read_stored: u64,
}

impl FactsReport {
    /// Whether the store answered nothing it was asked.
    ///
    /// The definition-read layer counts here as the CP/Header layer does: a store that answered one
    /// of those reads answered something, and a caller that reads the container counters beside this
    /// one sees the layer whose hits are not counted here.
    pub fn answered_nothing(&self) -> bool {
        self.hits == 0 && self.definition_read_hits == 0
    }

    /// The discards, as a one-line reading.
    pub fn discards(&self) -> String {
        format!(
            "format {} registry {} product {}",
            self.discarded_format, self.discarded_registry, self.discarded_product
        )
    }

    /// The reuse evidence, as a one-line reading: how many container lookups and how many definition
    /// reads were answered from retention, and how much work the requests did anyway.
    pub fn reuse(&self) -> String {
        format!(
            "container {}/{} hits, directories parsed {}, nested materialized {} ({} bytes); \
             definition reads {}/{} hits ({} stored)",
            self.container_hits,
            self.container_consultations,
            self.directory_parses,
            self.nested_materializations,
            self.nested_materialized_bytes,
            self.definition_read_hits,
            self.definition_read_consultations,
            self.definition_read_stored
        )
    }

    /// The residency figure and the refusals, as a one-line reading.
    ///
    /// The three layers are stated beside each other because they share the two limits: `entries`
    /// count CP/Header entries, `containers` container products and `definition_reads` retained
    /// definition reads, and `definition_read_bytes` is the part of `retained_bytes` the last of
    /// them contributes. This is the weight model's own unit, never RSS.
    pub fn residency(&self) -> String {
        format!(
            "{} entries / {} containers / {} definition reads ({} bytes), {} retained bytes of {} \
             allowed; refused {} by entry limit, {} by byte limit",
            self.entries,
            self.containers,
            self.definition_reads,
            self.definition_read_bytes,
            self.retained_bytes,
            self.capacity.describe(),
            self.refused_capacity,
            self.refused_capacity_bytes
        )
    }
}

/// One store's handle: the entries, plus the declaration this handle reads them under.
///
/// A handle is cheap to clone (the entries are behind one `Arc`) and every clone shares one store,
/// which is the whole point: a cache that could not outlive one request would save nothing. The
/// `Mutex` is not a concurrency feature — nothing in this engine spawns work — it is what keeps
/// [`FactsCache`] and [`Budget`] `Send + Sync` while one store is held by several requests.
#[derive(Clone, Debug)]
pub struct FactsCache {
    shared: Arc<Mutex<Shared>>,
    identity: FactsIdentity,
}

impl FactsCache {
    /// A fresh store, read under `identity`, holding at most `capacity`.
    ///
    /// Both bounds are enforced together: an answer is inserted only when its key is already
    /// present (a rewrite) or when it fits in the entry limit *and* in the retained-byte limit
    /// beside everything the store already holds. Nothing is ever evicted: the store is a
    /// retention decision, not a replacement policy, and a caller that wants room takes it back by
    /// dropping handles or calling [`FactsCache::clear`].
    pub fn new(identity: FactsIdentity, capacity: FactsCapacity) -> Self {
        Self {
            shared: Arc::new(Mutex::new(Shared {
                capacity,
                entries: BTreeMap::new(),
                containers: BTreeMap::new(),
                definition_reads: std::collections::HashMap::new(),
                retained_bytes: 0,
                counters: Counters::default(),
            })),
            identity,
        }
    }

    /// A fresh store read under this build's identity.
    pub fn current(capacity: FactsCapacity) -> Self {
        Self::new(FactsIdentity::current(), capacity)
    }

    /// A handle over **the same entries**, read under another declaration.
    ///
    /// This is how an incompatible entry is reachable at all: a store's entries were written by one
    /// build and are read by a caller that declares what it expects to find. Nothing here rewrites
    /// an entry, and a mismatch discards rather than converts — see [`Self::unusable`].
    pub fn over(&self, identity: FactsIdentity) -> Self {
        Self {
            shared: Arc::clone(&self.shared),
            identity,
        }
    }

    pub fn identity(&self) -> FactsIdentity {
        self.identity
    }

    pub fn capacity(&self) -> FactsCapacity {
        self.shared().capacity
    }

    /// A stable one-line label for this handle's declaration. Part of the measurement context, so it
    /// carries no counter: two runs of one configuration describe their cache the same way.
    pub fn describe(&self) -> String {
        format!(
            "facts cache ({}), capacity {}",
            self.identity.describe(),
            self.capacity().describe()
        )
    }

    /// Releases everything the store holds, leaving its counters and its declaration in place.
    ///
    /// The store's *retention* is the only thing this touches: a request that still holds an `Arc`
    /// to a container product keeps using it, and the next request simply finds nothing retained.
    /// A handle is a view of one store, so clearing any handle clears the store every clone sees.
    pub fn clear(&self) {
        let mut guard = self.shared();
        let shared = &mut *guard;
        shared.entries.clear();
        shared.containers.clear();
        shared.definition_reads.clear();
        shared.retained_bytes = 0;
    }

    pub fn report(&self) -> FactsReport {
        let guard = self.shared();
        let shared = &*guard;
        let counters = shared.counters;
        FactsReport {
            identity: self.identity,
            capacity: shared.capacity,
            entries: shared.entries.len(),
            containers: shared.containers.len(),
            retained_bytes: shared.retained_bytes,
            definition_reads: shared.definition_reads.len(),
            definition_read_bytes: shared
                .definition_reads
                .values()
                .fold(0_u64, |bytes, read| bytes.saturating_add(read.weight)),
            consultations: counters.consultations,
            hits: counters.hits,
            misses: counters.misses,
            stored: counters.stored,
            refused_capacity: counters.refused_capacity,
            refused_capacity_bytes: counters.refused_capacity_bytes,
            discarded_format: counters.discarded_format,
            discarded_registry: counters.discarded_registry,
            discarded_product: counters.discarded_product,
            container_consultations: counters.container_consultations,
            container_hits: counters.container_hits,
            container_misses: counters.container_misses,
            container_stored: counters.container_stored,
            directory_parses: counters.directory_parses,
            nested_materializations: counters.nested_materializations,
            nested_materialized_bytes: counters.nested_materialized_bytes,
            definition_read_consultations: counters.definition_read_consultations,
            definition_read_hits: counters.definition_read_hits,
            definition_read_misses: counters.definition_read_misses,
            definition_read_stored: counters.definition_read_stored,
        }
    }

    /// The structural facts of `bytes`, when this store already holds them under this handle's
    /// declaration.
    ///
    /// The hit is answered with the store's **shared handle** and copied only where this signature
    /// demands an owned value: the store's lock does an `Arc::clone`, and the one copy a caller that
    /// needs a `ClassFacts` of its own pays happens outside it
    /// ([`FactsCache::structure_shared`] is the entry point that avoids that copy entirely).
    pub(crate) fn structure(
        &self,
        bytes: &[u8],
        budget: &mut Budget,
    ) -> Result<Option<ClassFacts>> {
        Ok(self
            .take_structure(FactsKey::of(bytes, ParsePolicy::Structure), budget)?
            .map(Arc::unwrap_or_clone))
    }

    /// The structural facts of `bytes`, as the shared handle the store holds.
    ///
    /// The handle is the same allocation for every lookup of the same content: consuming one
    /// prepared class from several methods does not copy the payload per method, and a handle a
    /// caller already holds stays readable — with the content it was parsed from — after
    /// [`FactsCache::clear`], after the store refuses what does not fit, and after a later read
    /// rewrites the same key.
    pub fn structure_shared(
        &self,
        bytes: &[u8],
        budget: &mut Budget,
    ) -> Result<Option<Arc<ClassFacts>>> {
        self.take_structure(FactsKey::of(bytes, ParsePolicy::Structure), budget)
    }

    /// The structural facts of class bytes whose content identity a verified read already published.
    ///
    /// Same answer as [`FactsCache::structure_shared`] for the same bytes — the two keys are one key
    /// — without hashing the backing again: `class_bytes` is the identity such a read computed once
    /// ([`ClassBytesId`]). A digest that does not belong to the bytes the entry was parsed from is
    /// not a near miss but another key: it finds nothing rather than answering something else.
    pub fn trusted_structure(
        &self,
        class_bytes: &ClassBytesId,
        budget: &mut Budget,
    ) -> Result<Option<Arc<ClassFacts>>> {
        self.take_structure(
            FactsKey::from_trusted(
                class_bytes.digest.clone(),
                class_bytes.length,
                ParsePolicy::Structure,
            ),
            budget,
        )
    }

    /// Writes the structural facts of `bytes`. Only a parse that ran to the end reaches this.
    pub(crate) fn remember_structure(&self, bytes: &[u8], facts: &ClassFacts) {
        self.keep(
            FactsKey::of(bytes, ParsePolicy::Structure),
            FactsPayload::Structure(Arc::new(facts.clone())),
        );
    }

    /// The header inspection of `bytes` under `mode`, when this store holds one.
    ///
    /// The owned-value shape of [`FactsCache::header_shared`], for the same reason its structural
    /// twin has one: the copy this signature asks for happens outside the lock.
    pub(crate) fn header(
        &self,
        bytes: &[u8],
        mode: InspectionMode,
        budget: &mut Budget,
    ) -> Result<Option<HeaderInspection>> {
        Ok(self
            .take_header(FactsKey::of(bytes, ParsePolicy::of(mode)), budget)?
            .map(Arc::unwrap_or_clone))
    }

    /// The header inspection of `bytes` under `mode`, as the shared handle the store holds.
    pub fn header_shared(
        &self,
        bytes: &[u8],
        mode: InspectionMode,
        budget: &mut Budget,
    ) -> Result<Option<Arc<HeaderInspection>>> {
        self.take_header(FactsKey::of(bytes, ParsePolicy::of(mode)), budget)
    }

    /// The header inspection of class bytes whose content identity a verified read already published.
    ///
    /// The header twin of [`FactsCache::trusted_structure`], keyed the same way: the content digest
    /// and the parse policy, so a `Strict` request is never answered with a `Forensic` read.
    pub fn trusted_header(
        &self,
        class_bytes: &ClassBytesId,
        mode: InspectionMode,
        budget: &mut Budget,
    ) -> Result<Option<Arc<HeaderInspection>>> {
        self.take_header(
            FactsKey::from_trusted(
                class_bytes.digest.clone(),
                class_bytes.length,
                ParsePolicy::of(mode),
            ),
            budget,
        )
    }

    /// Writes the header inspection of `bytes` under `mode`. The version gate has already accepted
    /// it, so a refusal is never written.
    pub(crate) fn remember_header(
        &self,
        bytes: &[u8],
        mode: InspectionMode,
        inspection: &HeaderInspection,
    ) {
        self.keep(
            FactsKey::of(bytes, ParsePolicy::of(mode)),
            FactsPayload::Header(Arc::new(inspection.clone())),
        );
    }

    /// The retained facts of one container, when this store holds them under this handle's
    /// declaration.
    ///
    /// The **current request** decides first: the budget is polled, so a cancelled or expired
    /// request is refused before anything is served, and the container's own depth is checked
    /// against this request's `NestedDepth` limit, so facts built under a wider allowance are
    /// never handed to a request that is not allowed to reach that depth. Nothing here resets,
    /// borrows or re-creates budget state: a hit is a read of memory the request may use, not a
    /// new allowance.
    pub(crate) fn container(
        &self,
        origin: &ContainerOrigin,
        budget: &mut Budget,
    ) -> Result<Option<Arc<ContainerFacts>>> {
        budget.poll()?;
        let depth = u64::try_from(origin.steps.len()).map_err(|_| {
            Error::invalid_input(
                "nested_depth_overflow",
                "container origin is too deep to address",
            )
        })?;
        budget.check_nested_depth(depth)?;
        let key = ContainerKey {
            snapshot: origin.snapshot.clone(),
            origin: origin.clone(),
            schema: CONTAINER_FACTS_SCHEMA,
        };
        let mut guard = self.shared();
        let shared = &mut *guard;
        shared.counters.container_consultations += 1;
        let Some(entry) = shared.containers.get(&key) else {
            shared.counters.container_misses += 1;
            return Ok(None);
        };
        if let Some(reason) = self.unusable_container(entry) {
            let weight = entry.weight;
            shared.containers.remove(&key);
            shared.retained_bytes = shared.retained_bytes.saturating_sub(weight);
            shared.counters.container_misses += 1;
            match reason {
                Unusable::Format => shared.counters.discarded_format += 1,
                Unusable::Registry => shared.counters.discarded_registry += 1,
                Unusable::Product => shared.counters.discarded_product += 1,
            }
            return Ok(None);
        }
        let facts = Arc::clone(&entry.facts);
        shared.counters.container_hits += 1;
        Ok(Some(facts))
    }

    /// Offers one **complete** container product for retention.
    ///
    /// The product was read completely by the request that calls this, and the request keeps using
    /// it whether or not this store accepts it: a refusal is a retention decision and never a
    /// reason to read the container again. A product that does not fit in the entry limit or in
    /// the retained-byte limit is refused and counted; nothing is evicted to make room.
    pub(crate) fn remember_container(&self, facts: &Arc<ContainerFacts>) {
        let origin = facts.origin();
        let key = ContainerKey {
            snapshot: origin.snapshot.clone(),
            origin: origin.clone(),
            schema: CONTAINER_FACTS_SCHEMA,
        };
        let weight = facts.weight();
        let entry = ContainerEntry {
            identity: self.identity,
            facts: Arc::clone(facts),
            weight,
        };
        let mut guard = self.shared();
        let shared = &mut *guard;
        let occupied_weight = shared.containers.get(&key).map(|existing| existing.weight);
        match occupied_weight {
            Some(previous) => {
                // A key the store already holds may always be rewritten — the product that
                // reached here was read completely — so only a *new* key can be refused.
                shared.retained_bytes = shared.retained_bytes.saturating_sub(previous);
                shared.retained_bytes = shared.retained_bytes.saturating_add(weight);
                shared.containers.insert(key, entry);
                shared.counters.container_stored += 1;
            }
            None => {
                let items = shared.total_entries();
                if items >= shared.capacity.entries {
                    shared.counters.refused_capacity += 1;
                    return;
                }
                if weight > shared.capacity.retained_bytes
                    || shared
                        .retained_bytes
                        .saturating_add(weight)
                        .gt(&shared.capacity.retained_bytes)
                {
                    shared.counters.refused_capacity_bytes += 1;
                    return;
                }
                shared.retained_bytes += weight;
                shared.containers.insert(key, entry);
                shared.counters.container_stored += 1;
            }
        }
    }

    /// Records that the request holding this handle parsed one container's directory.
    ///
    /// Called by the reader while it builds a container's facts, so the count includes a build
    /// whose product the store then refused. A hit never calls it, which is exactly the evidence a
    /// reuse is judged by.
    pub(crate) fn note_directory_parse(&self) {
        self.shared().counters.directory_parses += 1;
    }

    /// Records that the request holding this handle materialized one nested container, of
    /// `bytes` produced.
    pub(crate) fn note_nested_materialization(&self, bytes: u64) {
        let mut guard = self.shared();
        let counters = &mut guard.counters;
        counters.nested_materializations += 1;
        counters.nested_materialized_bytes =
            counters.nested_materialized_bytes.saturating_add(bytes);
    }

    /// A lock this cache never leaves poisoned behind it.
    ///
    /// `std::sync::Mutex` poisons on a panic in a critical section, and the sections here are a map
    /// lookup, a map write and counter increments — no user code, no allocation that can fail
    /// without aborting. If one were poisoned anyway, a cache is not a reason to fail every later
    /// request: the store is read as it stands, which is at worst a miss.
    fn shared(&self) -> MutexGuard<'_, Shared> {
        self.shared
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    /// One definition read this store holds, as the bytes the read produced and the identity it
    /// established.
    ///
    /// `None` is "this store has no read of *this* definition": the lookup charges nothing, reads
    /// nothing and is counted as one consultation. A hit hands out the bytes' own handle and copies
    /// nothing at all — a caller that needs owned bytes copies them where it asks for them — and the
    /// identity that travels with them is the one their read established, never the caller's claim.
    ///
    /// The current request decides first: the budget is polled, so a cancelled, expired or already
    /// stopped request is refused before anything is served and this layer is not a way around
    /// either. Nothing here resets, borrows or re-creates budget state: a hit is memory the request
    /// may use, not a new allowance, and the caller still owes every check it performs on the answer
    /// — the location, the variant and the identity it declared.
    pub fn definition_read(
        &self,
        definition: &crate::model::PhysicalDefinitionId,
        budget: &mut Budget,
    ) -> Result<Option<(Arc<Vec<u8>>, ClassBytesId)>> {
        budget.poll()?;
        let key = DefinitionReadKey {
            definition: definition.clone(),
            schema: DEFINITION_READ_SCHEMA,
        };
        let mut guard = self.shared();
        let shared = &mut *guard;
        shared.counters.definition_read_consultations += 1;
        let Some(read) = shared.definition_reads.get(&key) else {
            shared.counters.definition_read_misses += 1;
            return Ok(None);
        };
        if read.identity != self.identity {
            // Written by another build's parser or entry format: discarded rather than converted,
            // exactly like a CP/Header entry of another declaration.
            let format_mismatch = read.identity.format != self.identity.format;
            let weight = read.weight;
            shared.definition_reads.remove(&key);
            shared.retained_bytes = shared.retained_bytes.saturating_sub(weight);
            shared.counters.definition_read_misses += 1;
            if format_mismatch {
                shared.counters.discarded_format += 1;
            } else {
                shared.counters.discarded_registry += 1;
            }
            return Ok(None);
        }
        let bytes = Arc::clone(&read.bytes);
        let class_bytes = read.class_bytes.clone();
        shared.counters.definition_read_hits += 1;
        Ok(Some((bytes, class_bytes)))
    }

    /// Offers one definition's verified read for retention.
    ///
    /// The read was performed completely by the request that calls this, and that request keeps
    /// using its own bytes whether or not the store accepts them: a refusal is a retention decision,
    /// never a reason to read the definition again.
    ///
    /// Only a read whose bytes **are** the definition's own is kept. `content_digest` is the digest
    /// the read computed over exactly `bytes`, and a digest or a length that disagrees with the
    /// definition's declaration is refused here and counted nowhere: the caller's own identity check
    /// is what refuses such a read, so the state this store declines to hold is one no lookup could
    /// ever be answered from. That rule is what makes "the bytes are the identity they are keyed
    /// under" a property of the store rather than a promise of its callers.
    ///
    /// A read that does not fit in the entry limit or in the retained-byte limit is refused and
    /// counted; nothing is evicted to make room.
    pub(crate) fn remember_definition_read(
        &self,
        definition: &crate::model::PhysicalDefinitionId,
        bytes: &[u8],
        content_digest: &Digest,
    ) {
        let Ok(length) = u64::try_from(bytes.len()) else {
            return;
        };
        if definition.class_bytes.digest != *content_digest
            || definition.class_bytes.length != length
        {
            return;
        }
        let key = DefinitionReadKey {
            definition: definition.clone(),
            schema: DEFINITION_READ_SCHEMA,
        };
        let read = DefinitionRead {
            identity: self.identity,
            class_bytes: ClassBytesId {
                digest: content_digest.clone(),
                length,
            },
            bytes: Arc::new(bytes.to_vec()),
            weight: length,
        };
        let mut guard = self.shared();
        let shared = &mut *guard;
        let occupied_weight = shared
            .definition_reads
            .get(&key)
            .map(|existing| existing.weight);
        match occupied_weight {
            Some(previous) => {
                // A key the store already holds may always be rewritten — the read that reached
                // here ran to the end — so only a *new* key can be refused.
                shared.retained_bytes = shared.retained_bytes.saturating_sub(previous);
                shared.retained_bytes = shared.retained_bytes.saturating_add(length);
                shared.definition_reads.insert(key, read);
                shared.counters.definition_read_stored += 1;
            }
            None => {
                let items = shared.total_entries();
                if items >= shared.capacity.entries {
                    shared.counters.refused_capacity += 1;
                    return;
                }
                if length > shared.capacity.retained_bytes
                    || shared.retained_bytes.saturating_add(length) > shared.capacity.retained_bytes
                {
                    shared.counters.refused_capacity_bytes += 1;
                    return;
                }
                shared.retained_bytes += length;
                shared.definition_reads.insert(key, read);
                shared.counters.definition_read_stored += 1;
            }
        }
    }

    /// The entry under `key`, when it is answerable under this handle's declaration.
    ///
    /// A hit polls the budget first: serving a fact from memory is not a way past a cancellation or
    /// an expired clock, and the request that asked for it still has to terminate.
    ///
    /// A hit hands out the payload's **handle**, not a copy of it: cloning the payload clones one
    /// `Arc`, so this critical section is a map lookup and a pointer copy — never a deep copy of a
    /// prepared class, and never anything held across a parse, a decompression or a sink call.
    fn take(&self, key: FactsKey, budget: &mut Budget) -> Result<Option<FactsPayload>> {
        budget.poll()?;
        let mut guard = self.shared();
        let shared = &mut *guard;
        shared.counters.consultations += 1;
        let Some(entry) = shared.entries.get(&key) else {
            shared.counters.misses += 1;
            return Ok(None);
        };
        if let Some(reason) = self.unusable(&key, entry) {
            // The entry is *discarded*, not left for the next lookup: a version it was written
            // under is not a state a later request could find it answerable in.
            if let Some(removed) = shared.entries.remove(&key) {
                shared.retained_bytes = shared.retained_bytes.saturating_sub(removed.weight);
            }
            shared.counters.misses += 1;
            match reason {
                Unusable::Format => shared.counters.discarded_format += 1,
                Unusable::Registry => shared.counters.discarded_registry += 1,
                Unusable::Product => shared.counters.discarded_product += 1,
            }
            return Ok(None);
        }
        let payload = entry.payload.clone();
        shared.counters.hits += 1;
        Ok(Some(payload))
    }

    /// The structural answer under `key`, as the shared handle, or `None` when this store has none.
    ///
    /// A payload of the other product answers nothing here — the policy check inside [`Self::take`]
    /// discards it as unusable before this matches, so the arm below returns `None` instead of
    /// panicking: a store is not a place to abort a request.
    fn take_structure(
        &self,
        key: FactsKey,
        budget: &mut Budget,
    ) -> Result<Option<Arc<ClassFacts>>> {
        Ok(match self.take(key, budget)? {
            Some(FactsPayload::Structure(facts)) => Some(facts),
            Some(FactsPayload::Header(_)) | None => None,
        })
    }

    /// The header answer under `key`, as the shared handle, or `None` when this store has none.
    fn take_header(
        &self,
        key: FactsKey,
        budget: &mut Budget,
    ) -> Result<Option<Arc<HeaderInspection>>> {
        Ok(match self.take(key, budget)? {
            Some(FactsPayload::Header(inspection)) => Some(inspection),
            Some(FactsPayload::Structure(_)) | None => None,
        })
    }

    /// Why an entry found under `key` is not answerable under this handle's declaration.
    ///
    /// The content identity is the key, so there is no second copy of it to compare: a lookup for
    /// other content cannot find this entry at all. What is checked here is the entry's
    /// **declaration** (the format and registry version it was written under) and its **product**
    /// (the payload kind its policy says it holds).
    fn unusable(&self, key: &FactsKey, entry: &Entry) -> Option<Unusable> {
        if entry.identity.format != self.identity.format {
            return Some(Unusable::Format);
        }
        if entry.identity.registry != self.identity.registry {
            return Some(Unusable::Registry);
        }
        if !key.policy.holds(&entry.payload) {
            return Some(Unusable::Product);
        }
        None
    }

    /// Why a container product is not answerable under this handle's declaration.
    ///
    /// The schema is part of the key, so it cannot disagree; what can is the entry format and the
    /// registry version the directory was validated under.
    fn unusable_container(&self, entry: &ContainerEntry) -> Option<Unusable> {
        if entry.identity.format != self.identity.format {
            return Some(Unusable::Format);
        }
        if entry.identity.registry != self.identity.registry {
            return Some(Unusable::Registry);
        }
        None
    }

    /// Whether one more answer of `weight` fits in the store, counting `items` answers already
    /// retained. The two bounds are independent: an answer has to fit in both.
    fn fits(shared: &Shared, weight: u64) -> bool {
        let items = shared.total_entries();
        items < shared.capacity.entries
            && weight <= shared.capacity.retained_bytes
            && shared.retained_bytes.saturating_add(weight) <= shared.capacity.retained_bytes
    }

    /// Writes one complete CP/Header answer, or refuses because the store is full.
    ///
    /// The weight of a CP/Header payload is the length of the class bytes it was parsed from: the
    /// payload is a function of those bytes and is not held anywhere else, so that length is the
    /// honest proxy for the residency it adds. It is not an allocation measurement.
    fn keep(&self, key: FactsKey, payload: FactsPayload) {
        let weight = key.length;
        let entry = Entry {
            identity: self.identity,
            payload,
            weight,
        };
        let mut guard = self.shared();
        let shared = &mut *guard;
        match shared.entries.get(&key).map(|existing| existing.weight) {
            Some(previous) => {
                // A key the store already holds may always be rewritten — the parse that reached
                // here ran to the end — and only a *new* key can be refused.
                shared.retained_bytes = shared.retained_bytes.saturating_sub(previous);
                shared.retained_bytes = shared.retained_bytes.saturating_add(weight);
                shared.entries.insert(key, entry);
                shared.counters.stored += 1;
            }
            None => {
                if !Self::fits(shared, weight) {
                    if shared.total_entries() >= shared.capacity.entries {
                        shared.counters.refused_capacity += 1;
                    } else {
                        shared.counters.refused_capacity_bytes += 1;
                    }
                    return;
                }
                shared.retained_bytes += weight;
                shared.entries.insert(key, entry);
                shared.counters.stored += 1;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A trusted digest and the bytes it was computed from are **one key**, and nothing else is.
    ///
    /// This is the whole of the "a caller with a trusted digest does not hash the backing again"
    /// promise: a lookup that skips the hash has to land on the entry a byte lookup of the same
    /// content wrote, and it must not land on anything else — a length that does not belong to the
    /// content, or another parse policy's answer, is another key rather than a near miss.
    #[test]
    fn a_trusted_digest_and_the_bytes_it_came_from_are_one_key() {
        let bytes = b"the bytes of one class";
        let digest = Digest(blake3::hash(bytes).to_hex().to_string());
        let length = bytes.len() as u64;
        for policy in [
            ParsePolicy::Structure,
            ParsePolicy::Strict,
            ParsePolicy::Forensic,
        ] {
            let hashed = FactsKey::of(bytes, policy);
            assert_eq!(hashed.digest, digest, "{policy:?}");
            assert_eq!(hashed.length, length, "{policy:?}");
            assert_eq!(
                hashed,
                FactsKey::from_trusted(digest.clone(), length, policy),
                "{policy:?}: a trusted digest and the bytes are two keys for one content"
            );
        }
        assert_ne!(
            FactsKey::of(bytes, ParsePolicy::Structure),
            FactsKey::from_trusted(digest.clone(), length + 1, ParsePolicy::Structure),
            "a length that does not belong to the content is another key"
        );
        assert_ne!(
            FactsKey::from_trusted(digest.clone(), length, ParsePolicy::Strict),
            FactsKey::from_trusted(digest, length, ParsePolicy::Forensic),
            "two parse policies of one content are two answers"
        );
    }

}

#[cfg(test)]
#[path = "facts_capacity_tests.rs"]
mod capacity_tests;
