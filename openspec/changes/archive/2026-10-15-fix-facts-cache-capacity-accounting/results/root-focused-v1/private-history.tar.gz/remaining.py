import subprocess,sys
from pathlib import Path
p=Path(__file__).parent/'run.py'
commands=[
(5,['cargo','test','--test','p5_definition_read_reuse','--locked']),
(6,['cargo','test','--test','p5_shared_payload','--locked']),
(7,['cargo','test','--test','p5_container_lookup','--locked']),
(8,['cargo','test','--test','p5_benchmark','the_engine_has_one_disabled_facts_cache_and_no_index_or_scheduler','--locked','--','--exact']),
(9,['cargo','fmt','--all','--','--check']),
]
for i,args in commands:
 r=subprocess.run([sys.executable,str(p),str(i),*args])
 if r.returncode:sys.exit(r.returncode)
