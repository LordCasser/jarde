# Prepared final-CLI DT29 replay

UNEXECUTED. Cache-only preparation; no CLI/JDK/Cargo/GDB/Git command and no repository mutation was performed by the preparer. Python AST parsing was used only as a syntax check, without importing or executing this runner.

Root may run this only after the future focused build receipt is final, all product source is frozen, the shared toolchain lane is clear and repository target is absent:

```sh
PYTHONPATH=/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/pythonlib \
  /home/lordcasser/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/direct-parent-final-cli-replay-harness-v1/run.py \
  --out /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/direct-parent-final-cli-replay-harness-v1/run-v1
```

The runner uses exactly the requested future CLI `jarde-cli-direct-parent-proof-v1` and receipt `direct-parent-focused-root-v1/execution.json`. It reads their actual bytes/hashes at runtime, checks receipt status, identical before/after 4905 source entries, exact frozen CLI path/bytes/hash/0555 mode and clean target, then verifies every current product source file against that actual receipt. No future executable or receipt hash is guessed or embedded. The existing verify_cli helper and process/disk/target guard are reused and pinned as runtime inputs.

Commands 1–9 are byte-for-byte the existing v3 execution block, verified during preparation: three exact all-evidence physical class-source captures, two javac23 --release8 builds, then Java23/Java8 original/rebuilt runs. The rebuild compiles only the exact whole-root emitted source containing nested A/B plus the unchanged original Runner. Standalone A/B outputs are observations, never additional compile units. The original JAR is absent from the rebuilt classpath. Java text, Runner and `true:true:false:false\n` oracle are never rewritten. All original immutable fixture, class SHA/BLAKE3, JDK and BLAKE3 runtime checks remain.

Commands 10–12 append explicit public JSON/all B requests with `class_headers=4096`, `1`, `2`. Raw stdout/stderr and real exit codes are retained. Wide requires Complete, completed analysis, three parent owner casts and the physical access$002 call. Low caps require exit4, class/recovery Partial/ClassHeaders, the original diagnostic, complete analysis, an admitted NotProduced/stopped setter with empty body/map, unchanged constructor identity/text/map and truthful scanned-through-set coverage. These are plain-budget publication controls. They do not replace the independent sticky-ledger unit controls or claim to identify Error/Report channel or first source/owner boundary. Low-budget output is not compiled.

Success requires all twelve actual commands and all checks, unchanged runtime input manifests/current-source binding, target absent and all four exact oracle matches. Existing old v3 success and its prior v2 assembly failure remain separate evidence; this new script has no execution or acceptance claim.
