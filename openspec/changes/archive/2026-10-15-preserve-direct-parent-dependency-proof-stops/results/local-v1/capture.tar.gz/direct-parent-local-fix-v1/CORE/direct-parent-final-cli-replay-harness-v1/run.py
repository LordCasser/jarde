#!/usr/bin/env python3
"""Prepared, fixed-scope DT29 direct-parent final-CLI source/runtime and budget replay.

This script is not executed by its preparer. It records three public CLI reports,
two javac builds, four Java runtime comparisons, and three all-evidence budget reports under the shared process guard.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, shutil, sys, zipfile
from pathlib import Path

PYTHON = Path('/home/lordcasser/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3')
PYTHONLIB = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/pythonlib')
if tuple(sys.version_info[:2]) != (3, 12) or Path(sys.executable).resolve() != PYTHON.resolve():
    raise SystemExit('use the pinned bundled Python 3.12 runtime for BLAKE3 class identity checks')
sys.path.insert(0, str(PYTHONLIB))
import blake3

BASE = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015').resolve()
ROOT = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde').resolve()
SCOPE = ROOT / 'openspec/evidence/java-syntax-2026-09-27/dt29-same-package-parent-field-writes'
JAR = SCOPE / 'outputs/input.jar'
FAMILY_SOURCE = SCOPE / 'fixtures/SamePackageParentFamily.java'
RUNNER_SOURCE = SCOPE / 'fixtures/SamePackageParentRunner.java'
RESULTS = SCOPE / 'outputs/results.json'
CLASS_ID_PINS = Path(__file__).resolve().parent / 'class-id-pins.json'
CLI = BASE / 'jarde-cli-direct-parent-proof-v1'
CLI_RECEIPT = BASE / 'direct-parent-focused-root-v1/execution.json'
HARNESS = BASE / 'interface-full-source-harness-v4/run_interface_full_source_harness.py'
GUARD_PATH = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/guard.py')
SCAN_PATH = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/target_scan.py')
JDK_MANIFEST = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jdk-manifest.json')
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3
EXPECTED_CLASS_IDENTITIES = {
    'dt29/SamePackageParentFamily': {'bytes': 262, 'sha256': '85c8f1a8ad10dd94501b281e60cbf15d25cf0fc1e745ed5b48954866689aa565', 'blake3': '76d888e07bb1b38a2253478b85fd50de4abb8546b30fa64226b9735d3daede5e'},
    'dt29/SamePackageParentFamily$A': {'bytes': 467, 'sha256': '5505a0e839775d7874668a7cccd4b2c19de42946ad393222f862076764e9c9fd', 'blake3': '1fe1977fa7055d486c2699bdda24294a32c200e33a6c81dd1ee3d9f99b588f20'},
    'dt29/SamePackageParentFamily$B': {'bytes': 467, 'sha256': '8b072630eb205ea7df76925bfce86d900087b23cf4e63e5a453b2ce52ddc34e2', 'blake3': '457daef0e946b36568e2cd608488b7f66a4bb9dc8773dc050c8a66a2ecd0def7'},
}


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def pin(path: Path) -> dict:
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def require_pin(path: Path, expected: dict) -> dict:
    actual = pin(path)
    if actual['bytes'] != expected.get('bytes') or actual['sha256'] != expected.get('sha256'):
        raise RuntimeError(f'input identity mismatch: {path}')
    return actual

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path, required=True, help='fresh output directory under this harness directory')
    args = ap.parse_args()
    out = args.out.resolve()
    if not out.is_relative_to(Path(__file__).resolve().parent) or out.exists():
        raise SystemExit('output must be a fresh child of this harness directory')
    if (ROOT / 'target').exists():
        raise SystemExit('fresh-target preflight failed: target must be absent')
    if shutil.disk_usage(ROOT).free < FREE_LIMIT:
        raise SystemExit('5 GiB free-space preflight failed')
    for p in (JAR, FAMILY_SOURCE, RUNNER_SOURCE, RESULTS, CLI, CLI_RECEIPT, HARNESS, GUARD_PATH, SCAN_PATH, JDK_MANIFEST, CLASS_ID_PINS):
        if not p.is_file():
            raise FileNotFoundError(p)

    class_id_pins = json.loads(CLASS_ID_PINS.read_text(encoding='utf-8'))
    if class_id_pins.get('classes') != [{'entry': name + '.class', **EXPECTED_CLASS_IDENTITIES[name]} for name in EXPECTED_CLASS_IDENTITIES]:
        raise RuntimeError('saved original class identity map differs from the reviewed pins')
    python_pin = pin(PYTHON)
    module_path = PYTHONLIB / 'blake3/__init__.py'
    native_path = PYTHONLIB / 'blake3/blake3.cpython-312-x86_64-linux-gnu.so'
    if pin(module_path)['sha256'] != class_id_pins['measurement']['blake3_module']['sha256'] or pin(native_path)['sha256'] != class_id_pins['measurement']['blake3_native_extension']['sha256']:
        raise RuntimeError('BLAKE3 module/native-extension pin mismatch')
    if python_pin['sha256'] != class_id_pins['measurement']['python']['sha256']:
        raise RuntimeError('bundled Python executable pin mismatch')
    results = json.loads(RESULTS.read_text(encoding='utf-8'))
    expected_stdout = results.get('expected_stdout')
    if expected_stdout != 'true:true:false:false\n':
        raise RuntimeError('pinned DT29 oracle does not contain the approved exact stdout')
    oracle = expected_stdout.encode('utf-8')
    harness_mod = load('dt29_full_source_binding', HARNESS)
    cli_binding = harness_mod.verify_cli(CLI, CLI_RECEIPT)
    receipt = json.loads(CLI_RECEIPT.read_text(encoding='utf-8'))
    source_manifest = receipt.get('source_manifest_before')
    if not isinstance(source_manifest, list) or source_manifest != receipt.get('source_manifest_after') or receipt.get('target_absent') is not True:
        raise RuntimeError('final CLI receipt lacks stable 4905 source pins and clean target')
    if len(source_manifest) != 4905:
        raise RuntimeError(f'final CLI receipt source count changed: {len(source_manifest)}')
    source_current = []
    for row in source_manifest:
        actual = pin(ROOT / row['path'])
        if actual['bytes'] != row['bytes'] or actual['sha256'] != row['sha256']:
            raise RuntimeError(f'current product source differs from frozen CLI receipt: {row["path"]}')
        source_current.append(actual)

    expected_inputs = {
        JAR: {'bytes': 1253, 'sha256': '31ec2e5d6b4fdac4fc4c910904c3b84dc92f64d54e83a1a81b41e57b41dad5c3'},
        FAMILY_SOURCE: {'bytes': 602, 'sha256': '93e484846a1db3077c8f89d71fd36be8eab367a7fa649c793b6d1e8284eaf59d'},
        RUNNER_SOURCE: {'bytes': 1453, 'sha256': '89fceed01e4dd24ff31fb676cf272bfbe86c6a2be0a5f0f91615211f0ab2cf7a'},
        RESULTS: {'bytes': 2165, 'sha256': '9e6fc588870e3a882ad515db15842e99f2228a890be5101c1520129447aeb024'},
    }
    fixture_pins = [require_pin(p, e) for p, e in expected_inputs.items()]
    manifest_pin = pin(JDK_MANIFEST)
    if manifest_pin['sha256'] != '5daeb9b6e864c3f28f62acc0b4c32bf61679546f6d7db077bd4171a6eafad6d6':
        raise RuntimeError('JDK tools manifest differs from the reviewed immutable pin')
    with zipfile.ZipFile(JAR) as jar_zip:
        physical_classes = sorted(info.filename for info in jar_zip.infolist() if info.filename.endswith('.class'))
    if physical_classes != sorted(name + '.class' for name in EXPECTED_CLASS_IDENTITIES):
        raise RuntimeError(f'DT29 input JAR physical class inventory changed: {physical_classes}')
    with zipfile.ZipFile(JAR) as jar_zip:
        for class_name, identity in EXPECTED_CLASS_IDENTITIES.items():
            class_bytes = jar_zip.read(class_name + '.class')
            measured = {'bytes': len(class_bytes), 'sha256': hashlib.sha256(class_bytes).hexdigest(), 'blake3': blake3.blake3(class_bytes).hexdigest()}
            if measured != identity:
                raise RuntimeError(f'original class byte identity mismatch for {class_name}: {measured}')
    jdk_doc = json.loads(JDK_MANIFEST.read_text(encoding='utf-8'))
    javac23 = next(row for row in jdk_doc['legs'] if row.get('leg') == 'javac23')['jdk_tools']
    jdk8 = next(row for row in jdk_doc['legs'] if row.get('leg') == 'javac8')['jdk_tools']
    tool_paths = {name: Path(javac23[name]['path']).resolve() for name in ('java', 'javac')}
    tool_paths['java8'] = Path(jdk8['java']['path']).resolve()
    tool_pins = {}
    for name, path in tool_paths.items():
        expected = javac23[name] if name in ('java', 'javac') else jdk8['java']
        tool_pins[name] = require_pin(path, expected)
    source_path = Path(__file__).resolve()
    inputs = sorted(set([source_path, JAR.resolve(), FAMILY_SOURCE.resolve(), RUNNER_SOURCE.resolve(), RESULTS.resolve(), CLASS_ID_PINS.resolve(), PYTHON.resolve(), module_path.resolve(), native_path.resolve(),
                         CLI.resolve(), CLI_RECEIPT.resolve(), HARNESS.resolve(), GUARD_PATH.resolve(), SCAN_PATH.resolve(), JDK_MANIFEST.resolve(),
                         *tool_paths.values(), *(ROOT / row['path'] for row in source_manifest)]))
    before = [pin(p) for p in inputs]

    out.mkdir(parents=True, exist_ok=False)
    src_dir = out / 'generated-java'
    original_runner_source = out / 'original-runner-source'
    original_runner_dir = out / 'original-runner-classes'
    rebuilt_dir = out / 'rebuilt-classes'
    for p in (src_dir, original_runner_source, original_runner_dir, rebuilt_dir):
        p.mkdir()
    runner_copy = original_runner_source / 'SamePackageParentRunner.java'
    shutil.copyfile(RUNNER_SOURCE, runner_copy)
    runner_copy_pin = pin(runner_copy)
    runner_original_pin = pin(RUNNER_SOURCE)
    if runner_copy_pin['bytes'] != runner_original_pin['bytes'] or runner_copy_pin['sha256'] != runner_original_pin['sha256']:
        raise RuntimeError('runner fixture copy is not byte-identical')

    guard = load('dt29_full_source_guard', GUARD_PATH)
    scanner = load('dt29_full_source_scan', SCAN_PATH)
    guard.ROOT = ROOT
    guard.OUT = out
    guard.FREE_LIMIT = FREE_LIMIT
    guard.TARGET_LIMIT = TARGET_LIMIT
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.expected_test_summaries = lambda _index, _data: None
    guard.command_stream = lambda path: pin(Path(path))
    guard.ENV_VALUES = {}
    base_env = {k: v for k, v in os.environ.items() if k in ('HOME', 'TMPDIR', 'LANG', 'LC_ALL')}
    for key in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'RUST_MIN_STACK', 'CARGO_TARGET_DIR'):
        base_env.pop(key, None)
    base_env['PATH'] = '/usr/bin:/bin'
    rows = []
    record = {
        'schema': 'direct-parent-final-cli-replay-harness-v1',
        'status': 'running',
        'scope': 'DT29 final CLI: preserve the nine-command whole-root dual-JVM proof and append explicit all-evidence B class_headers=4096/1/2 matrix; low caps validate reports only and are not compiled: original three physical classes, three exact class-source reports, compile original Runner against original JAR, compile the complete root report embedding nested A/B plus the identical Runner without original JAR on classpath; standalone A/B reports remain observational, run Java 23 and Java 8 on both outputs against the pinned oracle',
        'cli_binding': cli_binding, 'source_manifest_count': len(source_manifest),
        'source_manifest_sha256': hashlib.sha256(json.dumps(source_manifest, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        'fixture_pins': fixture_pins, 'class_identity_pins': pin(CLASS_ID_PINS), 'blake3_runtime': {'python': python_pin, 'module': pin(module_path), 'native_extension': pin(native_path), 'version': getattr(blake3, '__version__', 'unknown')}, 'original_physical_classes': physical_classes, 'oracle_stdout_utf8_hex': oracle.hex(),
        'jdk_manifest': manifest_pin, 'jdk_tool_pins': tool_pins,
        'guards': {'minimum_free_bytes': FREE_LIMIT, 'maximum_target_bytes': TARGET_LIMIT},
        'commands': rows,
    }
    def save():
        temp = out / 'execution.json.tmp'
        temp.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        temp.replace(out / 'execution.json')
    save()

    def run(index: int, label: str, argv: list[str], env: dict[str, str], expected_exit: int = 0) -> dict:
        row = guard.run_command(index, argv, env)
        row.update({'label': label, 'argv_exact': argv, 'cwd': str(ROOT), 'expected_exit': expected_exit,
                    'guard_status': 'stopped' if row.get('guard_stop') is not None else 'clear'})
        rows.append(row); save()
        if row.get('guard_stop') is not None:
            raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        if row.get('exit_code') != expected_exit:
            raise RuntimeError(f'{label} exit {row.get("exit_code")}, expected {expected_exit}; raw streams retained')
        return row

    try:
        class_names = list(EXPECTED_CLASS_IDENTITIES)
        report_objects = {}
        source_paths = {}
        for idx, class_name in enumerate(class_names, 1):
            argv = [str(CLI), 'class-source', '--input', str(JAR), '--class', class_name, '--format', 'json', '--evidence', 'all']
            row = run(idx, f'class-source-{class_name}', argv, base_env)
            stdout_path = Path(row['streams']['stdout']['path'])
            report_json = json.loads(stdout_path.read_text(encoding='utf-8'))
            if report_json.get('execution', {}).get('status') != 'complete':
                raise RuntimeError(f'{class_name} wide class-source is not complete')
            class_info = report_json.get('class', {})
            entry = class_info.get('location', {}).get('entry', {})
            raw_name = bytes(entry.get('raw_name', [])).decode('utf-8')
            digest = class_info.get('class_bytes', {}).get('digest')
            expected_entry = class_name + '.class'
            if raw_name != expected_entry or class_info.get('class_bytes', {}).get('length') != EXPECTED_CLASS_IDENTITIES[class_name]['bytes'] or digest != EXPECTED_CLASS_IDENTITIES[class_name]['blake3']:
                raise RuntimeError(f'{class_name} did not select the expected original physical class: {raw_name} / {digest}')
            source_text = report_json.get('text')
            if not isinstance(source_text, str):
                raise RuntimeError(f'{class_name} JSON report has no text string')
            source_path_out = src_dir / (class_name.rsplit('/', 1)[-1] + '.java')
            source_path_out.write_bytes(source_text.encode('utf-8'))
            source_paths[class_name] = source_path_out
            report_objects[class_name] = report_json
            row['report_status'] = report_json.get('outcome')
            row['selected_entry'] = raw_name
            row['selected_class_blake3'] = digest
            row['selected_class_length'] = class_info['class_bytes']['length']
            row['expected_class_sha256_verified_from_original_jar'] = EXPECTED_CLASS_IDENTITIES[class_name]['sha256']
            row['text_utf8_bytes'] = len(source_text.encode('utf-8'))
            row['saved_source_pin'] = pin(source_path_out)
            save()

        root_report = report_objects['dt29/SamePackageParentFamily']
        root_text = root_report['text']
        if '@bytecode' in root_text:
            raise RuntimeError('whole-root source contains a bytecode refusal marker; cannot use as complete nested positive source')
        nested_children = root_report.get('member_family', {}).get('members', [])
        nested_seen = {}
        for member in nested_children:
            child = member.get('child', {})
            child_name = child.get('declaration', {}).get('name')
            if child_name in ('SamePackageParentFamily$A', 'SamePackageParentFamily$B'):
                child_entry = child.get('class', {}).get('location', {}).get('entry', {})
                child_raw = bytes(child_entry.get('raw_name', [])).decode('utf-8')
                child_identity = EXPECTED_CLASS_IDENTITIES['dt29/' + child_name]
                if (child.get('execution', {}).get('status') != 'complete'
                        or child.get('coverage', {}).get('artifact_structural', {}).get('state') != 'complete_within_schema'
                        or child_raw != 'dt29/' + child_name + '.class'
                        or child.get('class', {}).get('class_bytes', {}).get('length') != child_identity['bytes']
                        or child.get('class', {}).get('class_bytes', {}).get('digest') != child_identity['blake3']):
                    raise RuntimeError(f'root report nested child is not complete/identity-pinned: {child_name}')
                nested_seen[child_name] = child
        if set(nested_seen) != {'SamePackageParentFamily$A', 'SamePackageParentFamily$B'}:
            raise RuntimeError(f'whole-root report does not contain both complete nested A/B reports: {sorted(nested_seen)}')
        if 'public static class A extends java.lang.Object' not in root_text or 'public static class B extends A' not in root_text:
            raise RuntimeError('whole-root source does not embed nested A and B declarations')
        root_source = source_paths['dt29/SamePackageParentFamily']
        observational_sources = [source_paths['dt29/SamePackageParentFamily$A'], source_paths['dt29/SamePackageParentFamily$B']]
        record['compile_assembly'] = {'compiled_java_source': str(root_source), 'runner_source': str(RUNNER_SOURCE), 'original_jar_on_rebuilt_classpath': False, 'standalone_A_B_reports': [str(p) for p in observational_sources], 'standalone_A_B_are_compile_units': False, 'root_contains_complete_nested_A_B': True}
        save()
        javac = tool_paths['javac']
        java23 = tool_paths['java']
        java8 = tool_paths['java8']
        row = run(4, 'javac23-release8-original-runner', [str(javac), '--release', '8', '-cp', str(JAR), '-d', str(original_runner_dir), str(runner_copy)], base_env)
        row['runner_copy_pin'] = runner_copy_pin; save()
        rebuilt_argv = [str(javac), '--release', '8', '-d', str(rebuilt_dir), str(root_source), str(RUNNER_SOURCE)]
        run(5, 'javac23-release8-whole-root-with-nested-A-B-and-runner-no-original-classpath', rebuilt_argv, base_env)
        # Runtime classpaths make the original-vs-rebuilt distinction explicit.
        original_cp = str(original_runner_dir) + os.pathsep + str(JAR)
        rebuilt_cp = str(rebuilt_dir)
        for idx, (label, java, cp) in enumerate((('java23-original', java23, original_cp), ('java23-rebuilt', java23, rebuilt_cp),
                                                  ('java8-original', java8, original_cp), ('java8-rebuilt', java8, rebuilt_cp)), 6):
            row = run(idx, label, [str(java), '-Xverify:all', '-cp', cp, 'dt29.SamePackageParentRunner'], base_env)
            stdout = Path(row['streams']['stdout']['path']).read_bytes()
            row['oracle_stdout_equal'] = stdout == oracle
            row['oracle_stdout_hex'] = stdout.hex()
            if stdout != oracle:
                raise RuntimeError(f'{label} stdout differs from pinned results.json oracle')
            if Path(row['streams']['stderr']['path']).stat().st_size != 0:
                row['stderr_empty'] = False
            else:
                row['stderr_empty'] = True
            save()
        # Keep the original nine-command positive proof intact, then capture the explicit
        # all-evidence public budget matrix. No low-budget output is used as Java source.
        matrix = []
        record['budget_matrix'] = matrix
        wide_constructor = None
        for index, cap in enumerate((4096, 1, 2), 10):
            expected_exit = 0 if cap == 4096 else 4
            argv = [str(CLI), 'class-source', '--input', str(JAR), '--class',
                    'dt29/SamePackageParentFamily$B', '--format', 'json', '--evidence',
                    'all', '--budget', f'class_headers={cap}']
            row = run(index, f'dt29-B-all-class_headers-{cap}', argv, base_env, expected_exit)
            document = json.loads(Path(row['streams']['stdout']['path']).read_text(encoding='utf-8'))
            entry = document.get('class', {}).get('location', {}).get('entry', {})
            if bytes(entry.get('raw_name', [])).decode('utf-8') != 'dt29/SamePackageParentFamily$B.class':
                raise RuntimeError(f'budget matrix cap{cap} selected another physical class')
            selected_bytes = document.get('class', {}).get('class_bytes', {})
            target_id = EXPECTED_CLASS_IDENTITIES['dt29/SamePackageParentFamily$B']
            if selected_bytes.get('length') != target_id['bytes'] or selected_bytes.get('digest') != target_id['blake3']:
                raise RuntimeError(f'budget matrix cap{cap} physical class identity differs')
            methods = document.get('methods', [])
            def exact_method(name, descriptor, method_index):
                found = [member for member in methods
                         if member.get('item', {}).get('name', {}).get('escaped') == name
                         and member.get('item', {}).get('descriptor', {}).get('escaped') == descriptor
                         and member.get('item', {}).get('index') == method_index]
                if len(found) != 1:
                    raise RuntimeError(f'cap{cap} lacks the exact physical {name}{descriptor} index{method_index}')
                return found[0]
            constructor = exact_method('<init>', '()V', 0)
            setter = exact_method('set', '(ZZ)V', 1)
            ctor_outcome = constructor.get('outcome', {})
            ctor_body = ctor_outcome.get('report', {})
            outcome = setter.get('outcome', {})
            body = outcome.get('report', {})
            if (ctor_outcome.get('analysis', {}).get('execution', {}).get('status') != 'complete'
                    or ctor_body.get('execution', {}).get('status') != 'complete'
                    or 'super();' not in constructor.get('text', '')
                    or not ctor_body.get('source_map', {}).get('segments')):
                raise RuntimeError(f'cap{cap} loses the reliable constructor text/analysis/source map')
            if outcome.get('kind') != 'recovered' or outcome.get('analysis', {}).get('execution', {}).get('status') != 'complete':
                raise RuntimeError(f'cap{cap} loses the original completed setter analysis')
            if cap == 4096:
                if document.get('execution', {}).get('status') != 'complete' or body.get('execution', {}).get('status') != 'complete' or body.get('content') != 'contains_statements':
                    raise RuntimeError('wide budget matrix is not a complete produced setter')
                text = setter.get('text', '')
                for field in ('publicField', 'protectedField', 'packagePrivateField'):
                    if f'((dt29.SamePackageParentFamily$A) this).{field} = arg1;' not in text:
                        raise RuntimeError(f'wide matrix loses the actual parent owner cast for {field}')
                if 'dt29.SamePackageParentFamily$A.access$002((dt29.SamePackageParentFamily$A) this, arg2);' not in text:
                    raise RuntimeError('wide matrix loses the physical helper call')
                wide_constructor = constructor
            else:
                for label, execution in (('class', document.get('execution', {})), ('setter', body.get('execution', {}))):
                    if execution.get('status') != 'partial' or execution.get('reason', {}).get('dimension') != 'class_headers':
                        raise RuntimeError(f'cap{cap} {label} loses the original ClassHeaders stop')
                if (body.get('content') != 'not_produced' or body.get('text') != ''
                        or body.get('source_map', {}).get('segments') != []
                        or not isinstance(body.get('outcome'), dict) or 'stopped' not in body['outcome']):
                    raise RuntimeError(f'cap{cap} falsely commits the interrupted setter body')
                diagnostics = document.get('diagnostics', []) + body.get('diagnostics', [])
                if not any('ClassHeaders' in diagnostic.get('message', '') for diagnostic in diagnostics):
                    raise RuntimeError(f'cap{cap} loses the original header-stop diagnostic')
                if (constructor['item']['identity'] != wide_constructor['item']['identity']
                        or constructor['text'] != wide_constructor['text']
                        or ctor_body['source_map'] != wide_constructor['outcome']['report']['source_map']):
                    raise RuntimeError(f'cap{cap} changes the reliable constructor prefix')
                structural = document.get('coverage', {}).get('artifact_structural', {})
                if not any(r.get('label') == 'class_source_bodies' and r.get('end', 0) > 1 for r in structural.get('scanned', [])):
                    raise RuntimeError(f'cap{cap} loses scanned-through-set coverage')
                if any(r.get('label') == 'class_source_bodies' and r.get('start', 0) > 1 for r in structural.get('skipped', [])):
                    raise RuntimeError(f'cap{cap} invents a suffix after the last physical setter')
            matrix.append({'cap': cap, 'command_index': index, 'actual_exit': row['exit_code'],
                           'class_execution': document.get('execution'), 'usage': document.get('usage'),
                           'setter_analysis_execution': outcome.get('analysis', {}).get('execution'),
                           'setter_recovery_execution': body.get('execution'),
                           'setter_content': body.get('content'), 'actual_json': row['streams']['stdout'],
                           'checks': 'physical identity; completed analysis; reliable constructor and map; wide casts/helper or original ClassHeaders stopped body'})
            save()
        record['status'] = 'captured_nine_command_positive_and_three_budget_reports_pending_independent_review'
    except BaseException as exc:
        record['status'] = 'capture_failed'
        record['error'] = f'{type(exc).__name__}: {exc}'
    finally:
        after = [pin(p) for p in inputs]
        record['input_manifest_before'] = before
        record['input_manifest_after'] = after
        record['inputs_identical'] = before == after
        record['current_source_matches_frozen_receipt'] = all(
            pin(ROOT / row['path'])['bytes'] == row['bytes'] and pin(ROOT / row['path'])['sha256'] == row['sha256']
            for row in source_manifest)
        record['source_manifest_current_count'] = len(source_current)
        record['generated_runner_copy'] = runner_copy_pin
        record['generated_source_files'] = [pin(p) for p in sorted(src_dir.glob('*.java'))]
        class_outputs = []
        for folder in (original_runner_dir, rebuilt_dir):
            class_outputs.extend(pin(p) for p in sorted(folder.rglob('*.class')))
        record['generated_class_files'] = class_outputs
        record['target_absent'] = not (ROOT / 'target').exists()
        record['free_bytes_after'] = shutil.disk_usage(ROOT).free
        if not record['inputs_identical'] or not record['target_absent'] or not record['current_source_matches_frozen_receipt']:
            record['status'] = 'capture_failed_integrity_or_cleanup'
        save()
    return 0 if record['status'] == 'captured_nine_command_positive_and_three_budget_reports_pending_independent_review' and len(rows) == 12 else 1

if __name__ == '__main__':
    raise SystemExit(main())
