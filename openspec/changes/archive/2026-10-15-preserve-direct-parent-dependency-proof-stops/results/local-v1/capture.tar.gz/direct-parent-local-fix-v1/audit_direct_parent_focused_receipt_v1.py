#!/usr/bin/env python3
"""Cache-only verifier for the terminal direct-parent focused receipt.

This script reads only cached JSON/raw files and the workspace source manifest pins.
It refuses to run before execution.json is terminal. It never runs a toolchain.
"""
from pathlib import Path
import argparse, hashlib, json, re, stat, sys

B = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
ROOT = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde')
DEFAULT_RECEIPT = B/'direct-parent-focused-root-v1/execution.json'
GATE_SOURCE = B/'combined-proof-all-ci-gates-root-v1.json'
OWN16 = [
 'facade::class_source_proof_inflight_tests::public_dt29_accessor_header_report_stop_preserves_first_dimension',
 'facade::class_source_proof_inflight_tests::public_dt29_accessor_real_charge_cancellation_stops_before_field_proof',
 'facade::class_source_proof_inflight_tests::public_dt29_accessor_real_deadline_stops_before_field_proof',
 'facade::class_source_proof_inflight_tests::public_dt29_field_header_report_stop_preserves_first_dimension',
 'facade::class_source_proof_inflight_tests::public_dt29_field_real_charge_cancellation_keeps_constructor_prefix',
 'facade::class_source_proof_inflight_tests::public_dt29_field_real_deadline_keeps_constructor_prefix',
 'facade::class_source_proof_inflight_tests::public_external_source_header_report_stop_precedes_owner_and_field_work',
 'ambiguous_direct_parent_is_an_ordinary_refusal_with_physical_anchors',
 'dt29_header_cap1_stops_at_the_first_direct_parent_dependency',
 'dt29_header_cap2_preserves_the_direct_parent_field_header_stop',
 'dt29_wide_preserves_parent_owner_casts_and_physical_accessor_call',
 'external_receiver_source_header_stop_is_not_treated_as_an_absent_relation',
 'missing_direct_parent_is_an_ordinary_refusal_with_physical_anchors',
 'dt29_header_cap_one_cli_exits_incomplete_at_accessor_proof',
 'dt29_header_cap_two_cli_exits_incomplete_at_field_proof',
 'dt29_wide_cli_keeps_parent_field_casts_and_physical_accessor',
]
AFFECTED_WORDS = ('class_source','interface','h1_','dependency')

def pin(path):
 p=Path(path); data=p.read_bytes()
 return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def gate_equal(actual, expected):
 return actual == expected or actual.endswith('::'+expected)
def fail(errors, condition, detail):
 if not condition: errors.append(detail)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--receipt',type=Path,default=DEFAULT_RECEIPT);ap.add_argument('--out',type=Path);args=ap.parse_args()
 receipt_path=args.receipt.resolve(); e=json.loads(receipt_path.read_text()); errors=[]; checks=[]
 def ck(cond, detail): checks.append(detail); fail(errors,cond,detail)
 terminal=(e.get('status') not in (None,'running') and bool(e.get('finished_at')))
 ck(terminal,'terminal receipt required (no partial/live execution accepted)')
 if not terminal:
  print(json.dumps({'status':'not_run_receipt_not_terminal','receipt':str(receipt_path),'checks':checks},indent=2));return 3
 gate=json.loads(GATE_SOURCE.read_text()); prior=list(gate['baseline55'])+list(gate['extra50'])
 gate_pin=pin(GATE_SOURCE)
 ck(len(prior)==105 and len(set(prior))==105 and gate['unique_total']==105,'prior105 gate source has 105 unique gates')
 ck(len(OWN16)==16 and len(set(OWN16))==16 and not set(prior)&set(OWN16),'new16 names are disjoint and unique')
 ck(e.get('status')=='expected_command_outcomes_observed_pending_independent_acceptance','runner completed expected outcomes pending independent acceptance')
 ck(e.get('default_stack') is True,'default stack receipt')
 ck(e.get('source_manifest_before')==e.get('source_manifest_after'),'source manifest before/after exact equality')
 manifest=e.get('source_manifest_before',[]); by_path={x['path']:x for x in manifest}
 ck(len(manifest)==4905 and len(by_path)==4905,'4905 unique source manifest entries')
 current_source=[]
 for rel in ['src/facade.rs','tests/direct_parent_dependency_proof_stops.rs','crates/jarde-cli/tests/class_source_cli.rs']:
  expected=by_path.get(rel)
  try: actual=pin(ROOT/rel)
  except OSError: actual=None
  ok=expected is not None and actual is not None and actual['bytes']==expected['bytes'] and actual['sha256']==expected['sha256']
  ck(ok,'frozen source pin '+rel)
  current_source.append({'expected':expected,'actual':actual,'matches':ok})
 # Receipt metadata must pin the exact saved runner/command list and frozen CLI, including mode 0555.
 for field in ('runner','command_spec'):
  value=e.get(field)
  try: actual=pin(value['path']) if value else None
  except OSError: actual=None
  ck(value is not None and actual is not None and all(actual[k]==value[k] for k in ('bytes','sha256')),'pinned '+field)
 frozen=e.get('frozen_cli') or {}; cli_actual=None; cli_mode=None
 try:
  cli_actual=pin(frozen['path']); cli_mode=stat.S_IMODE(Path(frozen['path']).stat().st_mode)
 except (OSError,KeyError,TypeError): pass
 cli_ok=bool(frozen and cli_actual and frozen.get('mode')=='0555' and cli_mode==0o555 and cli_actual['bytes']==frozen.get('bytes') and cli_actual['sha256']==frozen.get('sha256'))
 ck(cli_ok,'frozen CLI actual bytes/hash and immutable 0555 mode')
 # Check every captured raw stream against both the execution pin and stdout's native cargo summary.
 outcomes=[]; raw_pins=[]; test_summaries=[]
 for row in e.get('commands',[]):
  ck(row.get('exit_code')==0 and row.get('guard_stop') is None,'exit and no guard stop '+str(row.get('label')))
  ck(row.get('peak_target_bytes',0)<=e.get('guard',{}).get('maximum_target_bytes',1024**3),'target guard '+str(row.get('label')))
  ck(row.get('free_bytes_after',0)>=e.get('guard',{}).get('minimum_free_bytes',5*1024**3),'free-space guard '+str(row.get('label')))
  stdout=''
  for stream, value in row.get('streams',{}).items():
   try: actual=pin(value['path']); data=Path(value['path']).read_bytes()
   except OSError: actual=None; data=b''
   ok=actual is not None and actual['bytes']==value.get('bytes') and actual['sha256']==value.get('sha256')
   ck(ok,'raw pin '+str(row.get('label'))+'/'+stream)
   raw_pins.append({'label':row.get('label'),'stream':stream,'expected':value,'actual':actual,'matches':ok})
   if stream=='stdout': stdout=data.decode(errors='replace')
  summaries=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout)
  if 'actual_test_summaries' in row:
   expected=[tuple(x) for x in row['actual_test_summaries']]
   ck(summaries==expected,'native test summaries agree with receipt '+str(row.get('label')))
   ck(all(x[0]=='ok' and int(x[2])==0 for x in summaries),'native tests have no failures '+str(row.get('label')))
   named=re.findall(r'^test (.+) \.\.\. (ok|ignored|FAILED)(?:, .*)?$',stdout,re.M)
   recorded=[(x['name'],x['status']) for x in row.get('named_test_outcomes',[])]
   ck(sorted(named)==sorted(recorded),'native named outcomes agree with raw '+str(row.get('label')))
   outcomes.extend(named);test_summaries.extend({'command':row.get('label'),'status':x[0],'passed':int(x[1]),'failed':int(x[2]),'ignored':int(x[3])} for x in summaries)
 # Every new direct-parent gate must be explicitly present once and native green.
 own_results={}
 for gate_name in OWN16:
  found=[(n,s) for n,s in outcomes if gate_equal(n,gate_name)]
  ok=len(found)==1 and found[0][1]=='ok'
  ck(ok,'new16 native test '+gate_name)
  own_results[gate_name]=[{'name':n,'status':s} for n,s in found]
 # The 105 set remains a future own-CI source. Report only matching affected focus gates; do not require all 105 in this focused receipt.
 affected=[n for n in prior if any(word in n.lower() for word in AFFECTED_WORDS)]
 affected_results={}
 for gate_name in affected:
  found=[(n,s) for n,s in outcomes if gate_equal(n,gate_name)]
  if found: ck(all(s=='ok' for _,s in found),'available affected prior gate '+gate_name)
  affected_results[gate_name]=[{'name':n,'status':s} for n,s in found]
 # Exact cleanup and actual frozen CLI / source-closure status.
 clean_rows=[r for r in e.get('commands',[]) if r.get('argv')==['cargo','clean']]
 ck(len(clean_rows)==1 and clean_rows[0].get('exit_code')==0 and e.get('commands',[])[-1] is clean_rows[0],'one exact successful final cargo clean')
 ck(e.get('target_absent') is True and not (ROOT/'target').exists(),'target absent by receipt and current filesystem')
 # Optional captured snapshot subset is checked if present; absence is disclosed rather than misrepresented.
 snap_dir=receipt_path.parent/'input-snapshot'; snapshots=[]
 if snap_dir.is_dir():
  for rel in ['src/facade.rs','tests/direct_parent_dependency_proof_stops.rs','crates/jarde-cli/tests/class_source_cli.rs']:
   p=snap_dir/rel
   if p.is_file():
    actual=pin(p); expected=by_path.get(rel); ok=expected is not None and actual['bytes']==expected['bytes'] and actual['sha256']==expected['sha256'];ck(ok,'captured source snapshot '+rel);snapshots.append({'path':rel,'actual':actual,'matches_manifest':ok})
 gate_out=B/'direct-parent-future-own-ci-gates-v1.json'
 future=json.loads(gate_out.read_text()) if gate_out.exists() else None
 report={'schema':'direct-parent-focused-independent-audit-v1','status':'accepted_focused_affected_scopes_only' if not errors else 'rejected_or_incomplete','receipt':pin(receipt_path),'gate_source':gate_pin,'prior105_gate_count':len(prior),'prior105_all_required_in_focus':False,'new16_gate_count':len(OWN16),'future121_inventory':str(gate_out) if future else None,'checks':len(checks),'errors':errors,'commands':test_summaries,'test_totals':{'passed':sum(x['passed'] for x in test_summaries),'failed':sum(x['failed'] for x in test_summaries),'ignored':sum(x['ignored'] for x in test_summaries)},'new16_results':own_results,'affected_prior105_available_in_focus':affected_results,'raw_streams':raw_pins,'source_count':len(manifest),'source_before_after_equal':e.get('source_manifest_before')==e.get('source_manifest_after'),'frozen_source_pins':current_source,'frozen_cli':{'receipt':frozen,'actual':cli_actual,'actual_mode_octal':format(cli_mode,'04o') if cli_mode is not None else None,'matches':cli_ok},'guard':e.get('guard'),'guard_observed':{'peak_target_bytes_max':max((r.get('peak_target_bytes',0) for r in e.get('commands',[])),default=0),'free_bytes_after_min':min((r.get('free_bytes_after',0) for r in e.get('commands',[])),default=0)},'target_absent':e.get('target_absent'),'input_snapshot_directory_present':snap_dir.is_dir(),'input_snapshots_checked':snapshots,'scope':'Focused affected source/test/CLI evidence only. The prior 105 gates remain required for future own-CI acceptance and are not falsely required to appear in these focused logs.'}
 out=args.out.resolve() if args.out else B/'direct-parent-focused-independent-audit-v1.json'
 out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'status':report['status'],'out':str(out),'checks':len(checks),'errors':errors,'prior_affected_available':sum(bool(v) for v in affected_results.values()),'new16_passed':sum(v and v[0]['status']=='ok' for v in own_results.values()),'test_totals':report['test_totals'],'source_count':len(manifest),'raw_streams':len(raw_pins),'frozen_cli':report['frozen_cli']},indent=2))
 return 0 if not errors else 1
if __name__=='__main__': sys.exit(main())
