#!/usr/bin/env python3
"""Enumerate only this local fix's explicit evidence; creates no archive."""
from pathlib import Path
import ast, hashlib, json, shutil
BASE = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015').resolve()
HERE = Path(__file__).resolve().parent
PREFIX = 'direct-parent-local-fix-v1/'
ROOT_NAMES = ['direct-parent-old-public-root-v1', 'direct-parent-old-cli-root-v1',
              'direct-parent-old-inflight-root-v1', 'direct-parent-initial-fix-root-v1',
              'direct-parent-focused-root-v1', 'direct-parent-compatibility-root-v1']
FULL = BASE / 'CORE/direct-parent-final-cli-replay-harness-v1'

def pin(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def main():
    items, receipts, bindings, snapshots, origins = {}, [], [], [], []
    pending = []
    pending_audits = []
    def add(path, kind):
        path = Path(path).resolve()
        if not path.is_relative_to(BASE):
            raise RuntimeError(f'included path outside capture base: {path}')
        row = pin(path)
        items[str(path)] = {'original_path': str(path), 'archive_path': PREFIX + str(path.relative_to(BASE)),
                            'bytes': row['bytes'], 'sha256': row['sha256'], 'kind': kind}
        return path
    def bind(path, receipt, expected):
        actual = pin(path)
        if any(actual[k] != expected[k] for k in ('bytes', 'sha256')):
            raise RuntimeError(f'receipt-bound file differs: {path}')
        bindings.append({'included_path': str(Path(path).resolve()), 'receipt_path': str(receipt),
                         'recorded_pin': {k: expected[k] for k in ('path', 'bytes', 'sha256')}})
    def support(origin, label, expected=None, receipt=None):
        origin = Path(origin)
        target = HERE / 'support' / ('direct-parent-' + label)
        shutil.copyfile(origin, target)
        add(target, 'source-support-copy')
        origins.append({'included_path': str(target), 'original': pin(origin)})
        if expected is not None:
            bind(target, receipt, expected)
        return target
    raw_count = 0
    for name in ROOT_NAMES:
        folder = BASE / name
        rp = folder / 'execution.json'
        if name == ROOT_NAMES[-1] and (not rp.is_file() or not json.loads(rp.read_text()).get('finished_at')):
            pending.append(str(rp))
            continue
        obj = json.loads(rp.read_text())
        if not obj.get('finished_at'):
            raise RuntimeError(f'nonterminal historical receipt: {rp}')
        add(rp, 'historical-receipt')
        receipts.append({'path': str(rp), 'archive_path': items[str(rp)]['archive_path'],
                         'status': obj['status'], 'commands': len(obj['commands'])})
        command_spec = folder / 'command_spec.json'
        add(command_spec, 'command-spec')
        bind(command_spec, rp, obj['command_spec'])
        for command in obj['commands']:
            for stream in command['streams'].values():
                add(stream['path'], 'receipt-bound-raw');bind(stream['path'], rp, stream);raw_count += 1
        snapshot = folder / 'input-snapshot'
        source_pins = {r['path']: r for r in obj['source_manifest_before']}
        files = sorted(path for path in snapshot.rglob('*') if path.is_file())
        snapshots.append({'directory': str(snapshot), 'files': [str(path.resolve()) for path in files]})
        for path in files:
            add(path, 'historical-source-snapshot')
            bind(path, rp, source_pins[str(path.relative_to(snapshot))])
        if name == 'direct-parent-focused-root-v1':
            support(obj['runner']['path'], 'class-view-runner-v1.py', obj['runner'], rp)
            for key in ('guard', 'target_scan', 'source_closure_runner'):
                expected = obj['dependencies'][key]
                support(expected['path'], key.replace('_', '-') + '.py', expected, rp)
    rp = FULL / 'run-v1/execution.json'
    obj = json.loads(rp.read_text())
    if obj['status'] != 'captured_nine_command_positive_and_three_budget_reports_pending_independent_review':
        raise RuntimeError('full CLI receipt is not the actual completed capture')
    add(rp, 'final-cli-receipt')
    receipts.append({'path': str(rp), 'archive_path': items[str(rp)]['archive_path'],
                     'status': obj['status'], 'commands': len(obj['commands'])})
    inputs = {r['path']: r for r in obj['input_manifest_before']}
    for name in ['run.py', 'class-id-pins.json', 'README.md', 'static-preparation-review.json',
                 'preparation-pins.json', 'independent-review-v1.json', 'run-v1/independent-runtime-review-v1.json']:
        path = FULL / name
        add(path, 'final-cli-harness-or-review')
        if str(path) in inputs:
            bind(path, rp, inputs[str(path)])
    for command in obj['commands']:
        for stream in command['streams'].values():
            add(stream['path'], 'receipt-bound-raw');bind(stream['path'], rp, stream);raw_count += 1
    for row in obj['generated_source_files'] + obj['generated_class_files'] + [obj['generated_runner_copy']]:
        add(row['path'], 'receipt-bound-generated-Java-or-class');bind(row['path'], rp, row)
    source_helper = BASE / 'interface-full-source-harness-v4/run_interface_full_source_harness.py'
    support(source_helper, 'interface-full-source-binding.py', inputs[str(source_helper)], rp)
    support(obj['jdk_manifest']['path'], 'jdk-manifest.json', obj['jdk_manifest'], rp)
    for name in ['direct-parent-old-public-independent-review-v1.json',
                 'direct-parent-old-reproduction-independent-audit-v1.json',
                 'direct-parent-initial-fix-independent-audit-v1.json',
                 'direct-parent-focused-independent-audit-v1.json',
                 'direct-parent-final-cli-replay-root-acceptance-v1.json',
                 'direct-parent-future-own-ci-gates-v1.json',
                 'audit_direct_parent_focused_receipt_v1.py']:
        add(BASE / name, 'direct-parent-independent-audit-or-source')
    compatibility_audit = BASE / 'direct-parent-compatibility-independent-audit-v1.json'
    if compatibility_audit.is_file():
        add(compatibility_audit, 'direct-parent-independent-audit-or-source')
    else:
        pending_audits.append(str(compatibility_audit))
    static = Path('/home/lordcasser/.cache/jarde-review/20261015/direct-parent-production-applied-static-review-v1')
    for name in ['REVIEW.md', 'observed-facade.diff', 'review-pins.json']:
        support(static / name, 'production-static-' + name)
    for name in ['package.py', 'prepare_allowlist.py', 'README.md']:
        add(HERE / name, 'packager-source-or-scope')
    data = {'schema': 'direct-parent-local-fix-allowlist-v1', 'status': 'prepared_only_package_not_created',
            'scope': 'Local direct-parent fix historical failures, initial/focused controls and final full-source/CLI replay; preserves original receipt statuses; no own-CI completion or baseline repro replacement.',
            'external_exclusions': ['native Jarde CLI executables', 'JDK and bundled runtime binaries',
                                    'unrelated recursive artifacts', 'baseline repository results/repro-v1', 'future own-CI evidence'],
            'required_receipt_paths': [str(BASE / name / 'execution.json') for name in ROOT_NAMES] + [str(rp)],
            'pending_terminal_receipts': pending, 'pending_required_audits': pending_audits,
            'receipts': receipts, 'raw_file_count': raw_count,
            'receipt_file_bindings': bindings, 'snapshot_contracts': snapshots,
            'support_copy_origins': origins,
            'items': sorted(items.values(), key=lambda r: r['archive_path'])}
    for name in ('package.py', 'prepare_allowlist.py'):
        ast.parse((HERE / name).read_text())
    (HERE / 'allowlist.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': data['status'], 'items': len(items), 'receipt_count': len(receipts),
                      'raw_file_count': raw_count, 'pending': pending, 'pending_audits': pending_audits, 'allowlist': pin(HERE / 'allowlist.json')}, indent=2))

if __name__ == '__main__':
    main()
