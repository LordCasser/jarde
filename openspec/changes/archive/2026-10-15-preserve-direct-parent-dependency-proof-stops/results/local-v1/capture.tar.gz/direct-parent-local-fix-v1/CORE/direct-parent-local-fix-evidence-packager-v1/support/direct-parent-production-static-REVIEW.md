# Applied production patch independent static review

Result: no static blocker found. This is a read-only source/evidence review; no Git, Cargo, rustfmt, JDK/JADX/Jarde/GDB command or repository mutation was performed by this reviewer. All new files here are cache artifacts. Initial-fix runtime results are pending root and are not claimed by this report.

## Exact compared inputs

Old in-flight run frozen input-snapshot/src/facade.rs SHA256 `13d75c1c26392a29530e784778e152cbd1f58218bf474e0bf0f98dbe00066b6d`.

Current frozen repository src/facade.rs SHA256 `3f74329c3d6feea0a51434f33f60f5e84a3b3bf4d5c63f55a94bc66a153e0880`.

The complete diff is observed-facade.diff. It has precisely six production hunks plus one cfg(test) assertion-message correction from “was read” to “was attempted”; that wording correction changes no condition or expected value.

## Production scope

1. Two direct-parent proof consumers now return existing DependencyProofResult rather than legacy Result.
2. Each consumer's owner-member-table lookup uses existing selected_dependency_proof_header instead of selected_reference_header.
3. Only their shared selected_direct_parent helper changes to the same typed return/reader. The existing predicate is unchanged: non-interface and exact direct superclass identity. This helper has no other consumers.
4. The existing proof closure propagates accessor and field failures with `?` rather than swallowing BudgetExceeded/Cancelled and continuing. Accessor remains first; failure returns before field proof, snapshot proof, recovery or optional body evidence.

The original typed Error or Report reaches the already existing proofs match, recovery_reason, into_execution and stopped_before_recovery factory with its original completed analysis, facts and callees. The existing fourteen-item tuple remains unchanged. No new Budget, poll, charge, refunded accounting, diagnostic parsing, execution reconstruction from current totals, generic adapter or framework is introduced by the production diff. The existing Error::from conversion and genuine request-ending predicate keep ordinary/value-level error isolation intact.

Reference-overload call proof and selected_reference_header remain byte-identical in this complete facade diff. Global merge and publication gate are unchanged. Separate global reader Budget and OperationLedger files match the old frozen source manifest byte-for-byte (pins in review-pins.json). Plain-budget public/CLI stopped-record admission and sticky-ledger unit admission remain distinct test expectations; this review does not rewrite the original admission policy.

## Old failure evidence read independently

The old execution manifest has 4905 source entries and identical before/after arrays. Its named root library run actually reports five original H1 passes and seven new DT29/source failures, exit 101. Raw stderr shows five new header/deadline cases observing Cancelled instead of the demanded original budget reason; both cancellation cases observe post-stop Checkpoint tails. These are behavior assertions after successful compilation, not fixture/path failures. Two missing/ambiguous ordinary-refusal public controls pass. The exact final `cargo clean` exits zero and old target_absent is true.

The old external public budget control's earlier pass is not evidence of the first source header boundary. The exact scoped external unit still requires attempted headers [B], stages [Accessor], original Report/ClassHeaders and no field/owner/tail fees. Its initial-fix result must come from root's actual new run; no runtime channel/order is inferred here from the old public pass.

## Boundaries

This source review supports the minimal typed handoff and unchanged algorithms; it does not certify the initial fix tests, broader compatibility, rebuilt Java behavior, workspace/MSRV/Clippy/OpenSpec gates, or the eventual fix commit's own CI. Root will bind those executions separately to the frozen candidate.
