#!/usr/bin/env python3
"""Package only the prepared direct-parent allowlist; never execute captured tools."""
from __future__ import annotations
import argparse, hashlib, io, json, tarfile
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
BASE = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015').resolve()
ALLOW = HERE / 'allowlist.json'
PREFIX = 'direct-parent-local-fix-v1/'
MANIFEST = 'direct-parent-package-manifest.json'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def pinned_dicts(value):
    if isinstance(value, dict):
        if all(key in value for key in ('path', 'bytes', 'sha256')):
            yield {key: value[key] for key in ('path', 'bytes', 'sha256')}
        for child in value.values():
            yield from pinned_dicts(child)
    elif isinstance(value, list):
        for child in value:
            yield from pinned_dicts(child)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    allow = json.loads(ALLOW.read_text())
    if allow.get('status') != 'prepared_only_package_not_created':
        raise SystemExit('allowlist is not in its prepared state')
    if allow.get('pending_required_audits'):
        raise SystemExit('mandatory compatibility audit not yet included; refresh allowlist')
    rows = allow['items']
    by_path = {row['original_path']: row for row in rows}
    if len(rows) != len(by_path) or len({row['archive_path'] for row in rows}) != len(rows):
        raise SystemExit('duplicate original/archive allowlist path')
    payload = {}
    for row in rows:
        src = Path(row['original_path'])
        arc = PurePosixPath(row['archive_path'])
        if (not src.resolve().is_relative_to(BASE) or src.is_symlink() or not src.is_file()
                or not str(arc).startswith(PREFIX) or arc.is_absolute() or '..' in arc.parts):
            raise SystemExit(f'unsafe or out-of-scope allowlist item: {src}')
        data = src.read_bytes()
        if len(data) != row['bytes'] or sha(data) != row['sha256']:
            raise SystemExit(f'changed allowlist pin: {src}')
        if data.startswith(b'\x7fELF') or data.startswith(b'MZ'):
            raise SystemExit(f'native executable excluded from this package: {src}')
        payload[row['archive_path']] = data
    receipts = {}
    if set(allow['required_receipt_paths']) - {r['path'] for r in allow['receipts']}:
        raise SystemExit('mandatory terminal compatibility receipt is not yet included; refresh allowlist')
    bound_raw = {}
    for reference in allow['receipts']:
        rp = reference['path']
        if rp not in by_path:
            raise SystemExit(f'receipt omitted from allowlist: {rp}')
        obj = json.loads(payload[by_path[rp]['archive_path']])
        receipts[rp] = obj
        if obj.get('status') != reference['status'] or len(obj.get('commands', [])) != reference['commands']:
            raise SystemExit(f'historical receipt status/command contract changed: {rp}')
        for command in obj['commands']:
            streams = command.get('streams', {})
            if set(streams) != {'stdout', 'stderr'}:
                raise SystemExit(f'command lacks both raw streams: {rp}')
            for stream in streams.values():
                path = str(Path(stream['path']).resolve())
                if path in bound_raw or path not in by_path:
                    raise SystemExit(f'raw duplicated or omitted from allowlist: {path}')
                row = by_path[path]
                if row['bytes'] != stream['bytes'] or row['sha256'] != stream['sha256']:
                    raise SystemExit(f'raw no longer bound to receipt bytes: {path}')
                bound_raw[path] = stream
    if {path for path in by_path if path.endswith('.raw')} != set(bound_raw):
        raise SystemExit('raw subset missing or an included raw is unbound')
    if len(bound_raw) != allow['raw_file_count']:
        raise SystemExit('receipt-bound raw count changed')
    # Bind source snapshots, support copies, scripts and generated files to actual receipt pins.
    receipt_pins = {path: list(pinned_dicts(obj)) for path, obj in receipts.items()}
    for binding in allow['receipt_file_bindings']:
        row = by_path.get(binding['included_path'])
        expected = binding['recorded_pin']
        if row is None or expected not in receipt_pins[binding['receipt_path']]:
            raise SystemExit(f'included evidence lacks its recorded receipt pin: {binding}')
        if row['bytes'] != expected['bytes'] or row['sha256'] != expected['sha256']:
            raise SystemExit(f'included evidence differs from recorded receipt bytes: {binding}')
    # The captured source snapshot inventories are explicit, not recursive archive input.
    for contract in allow['snapshot_contracts']:
        folder = Path(contract['directory'])
        actual = sorted(str(path.resolve()) for path in folder.rglob('*') if path.is_file())
        if actual != contract['files'] or any(path not in by_path for path in actual):
            raise SystemExit(f'source snapshot subset missing/unlisted: {folder}')
    out = args.out.expanduser().resolve()
    if (out.exists() or not out.parent.is_dir() or not out.parent.is_relative_to(HERE)
            or any(out.parent.iterdir())):
        raise SystemExit('out must be a new file in an existing empty child directory of this packager')
    manifest = {'schema': 'direct-parent-local-fix-evidence-v1',
                'status': 'packaged_and_reopened_verified',
                'allowlist_sha256': sha(ALLOW.read_bytes()), 'items': rows,
                'raw_receipt_bound_count': len(bound_raw),
                'historical_receipts': allow['receipts'],
                'scope': allow['scope'], 'external_exclusions': allow['external_exclusions']}
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    with tarfile.open(out, 'w:gz', format=tarfile.PAX_FORMAT) as archive:
        for arc, data in sorted({**payload, MANIFEST: manifest_bytes}.items()):
            member = tarfile.TarInfo(arc)
            member.size, member.mode, member.mtime = len(data), 0o444, 0
            member.uid = member.gid = 0
            member.uname = member.gname = ''
            archive.addfile(member, io.BytesIO(data))
    with tarfile.open(out, 'r:gz') as archive:
        members = archive.getmembers()
        expected = {**payload, MANIFEST: manifest_bytes}
        if (len(members) != len(expected) or len({m.name for m in members}) != len(members)
                or any(not m.isfile() for m in members) or {m.name for m in members} != set(expected)):
            raise SystemExit('reopened tar member set/type/count mismatch')
        for member in members:
            if archive.extractfile(member).read() != expected[member.name]:
                raise SystemExit(f'reopened tar byte mismatch: {member.name}')
    for row in rows:
        if Path(row['original_path']).read_bytes() != payload[row['archive_path']]:
            raise SystemExit(f'input changed during packaging: {row["original_path"]}')
    print(json.dumps({'status': 'packaged_and_reopened_verified', 'archive': str(out),
                      'sha256': sha(out.read_bytes()), 'bytes': out.stat().st_size,
                      'items': len(rows), 'receipt_bound_raw_files': len(bound_raw)}, indent=2))

if __name__ == '__main__':
    main()
