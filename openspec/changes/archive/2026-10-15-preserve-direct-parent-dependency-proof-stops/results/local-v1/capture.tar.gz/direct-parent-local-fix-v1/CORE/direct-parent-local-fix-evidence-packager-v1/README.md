# Local direct-parent fix evidence package preparation

Prepared only. The packager has not been run and no archive is claimed. Both source scripts are syntax-checked using AST parsing only. Preparation enumerates a narrow explicit allowlist and copies selected exact source support files into this cache directory; it does not execute captured tools or mutate the repository.

The intended payload includes six root runs (old public, old CLI, old in-flight, initial fix, focused, additional compatibility), their execution/command-spec/raw/input-snapshot files, and final CLI harness source/metadata/audits plus its execution, all 24 raw streams, exact generated Java/Runner and JVM class files. It includes selected source runner/guard/scanner/closure/helper scripts, JDK metadata, direct-parent independent audit JSONs, root replay acceptance, existing future own-CI gate instructions as planning metadata, and the independent production static review. Native CLI/JDK/runtime binaries remain external and retain their actual receipt pins. Existing baseline repository results/repro-v1 stays separate.

Compatibility and its independent audit are mandatory. If that receipt is not terminal during preparation, allowlist.json records it pending and package.py refuses to package. After root completes the lane and the actual independent compatibility audit arrives, rerun only prepare_allowlist.py to bind the actual compatibility receipt/status/commands/raw/source snapshots. Refreshing the allowlist must remain an explicit root action, because previously pinned input changes intentionally make packaging fail. The preparer never invents future pins.

Root invocation after all required receipts and audits are terminal:

```sh
python3 /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/direct-parent-local-fix-evidence-packager-v1/prepare_allowlist.py
mkdir /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/direct-parent-local-fix-evidence-packager-v1/run-v1
python3 /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/direct-parent-local-fix-evidence-packager-v1/package.py --out /home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE/direct-parent-local-fix-evidence-packager-v1/run-v1/direct-parent-local-fix-evidence-v1.tar.gz
```

The explicit allowlist pins every included byte. The packager rejects changed pins, duplicate/out-of-scope paths, native executable payloads, nonterminal missing compatibility, missing/unbound raw subsets, source snapshots missing from the explicit inventory, and receipt-bound source/generated files that differ from their recorded pins. Historical receipt statuses remain unchanged. It reopens the tar, verifies the complete unique regular-file member set and every payload byte plus embedded manifest, then rechecks input bytes for changes during packaging. It never extracts files or runs tools. No own-CI or completed-change claim follows from a successful local evidence package.
