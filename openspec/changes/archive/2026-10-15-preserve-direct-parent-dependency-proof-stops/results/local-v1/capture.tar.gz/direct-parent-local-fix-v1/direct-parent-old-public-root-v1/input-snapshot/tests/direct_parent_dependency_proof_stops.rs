//! Public DT-29 regressions for request stops in direct-parent dependency proofs.
use jarde::*;
use std::slice;

const DT29: &[u8] = include_bytes!(
    "../openspec/evidence/java-syntax-2026-09-27/dt29-same-package-parent-field-writes/outputs/input.jar"
);

fn limits(headers: u64) -> Limits {
    let mut limits = task_budget(&[]).unwrap().limits().clone();
    limits.elapsed_millis = u64::MAX;
    limits.class_headers = headers;
    limits
}

const EXTERNAL_SOURCE: &[u8] = include_bytes!(
    "../openspec/evidence/java-syntax-2026-09-27/dt29-same-package-parent-field-writes/outputs/combined-input.jar"
);

fn present(headers: u64) -> ClassSourceReport {
    present_class(DT29, "dt29/SamePackageParentFamily$B", headers)
}

fn present_class(bytes: &[u8], name: &str, headers: u64) -> ClassSourceReport {
    let engine = Engine::new();
    let snapshot = engine
        .open(
            ArtifactInput::bytes(bytes.to_vec()),
            &mut Budget::new(limits(4096)),
        )
        .expect("original DT-29 opens");
    let request = ClassSourceRequest {
        class: ClassRef::Name {
            class: ClassNameQuery::internal(name),
        },
        environment: EnvironmentRequest {
            snapshot: snapshot.id().clone(),
            scope: PhysicalScope::SnapshotAll,
            policy: EnvironmentPolicy::PlainJar,
            profile: RuntimeProfile {
                java_release: 8,
                multi_release: MultiReleasePolicy::Disabled,
                layout: LayoutMode::Generic,
            },
            loader: LoaderId("app".to_owned()),
        },
    };
    let OperationOutcome::Performed(report) = engine
        .class_source_with_evidence(
            slice::from_ref(&snapshot),
            &request,
            &RecoveryEvidenceRequest::all(),
            &mut Budget::new(limits(headers)),
        )
        .expect("selected DT-29 returns its public report")
    else {
        panic!("the selected original class is unique");
    };
    report
}

fn physical_set(report: &ClassSourceReport) -> Option<&ClassSourceMethod> {
    physical_set_with_descriptor(report, b"(ZZ)V")
}

fn physical_set_with_descriptor<'a>(
    report: &'a ClassSourceReport,
    descriptor: &[u8],
) -> Option<&'a ClassSourceMethod> {
    report.methods.iter().find(|method| {
        method.item.identity.name.0 == b"set" && method.item.identity.descriptor.0 == descriptor
    })
}

#[test]
fn dt29_wide_preserves_parent_owner_casts_and_physical_accessor_call() {
    let report = present(4096);
    assert!(matches!(report.execution, ExecutionReport::Complete { .. }));
    assert_eq!(report.methods.len(), 2);
    let member = physical_set(&report).expect("set(ZZ)V is the actual physical method");
    assert_eq!(member.item.index, 1);
    let ClassSourceOutcome::Recovered {
        report: body,
        analysis,
    } = &member.outcome
    else {
        panic!("the wide set body is recovered");
    };
    assert!(matches!(
        analysis.execution,
        ExecutionReport::Complete { .. }
    ));
    assert!(matches!(body.execution, ExecutionReport::Complete { .. }));
    assert_eq!(body.content, RecoveryContent::ContainsStatements);
    assert!(body.fallbacks.is_empty());
    for field in ["publicField", "protectedField", "packagePrivateField"] {
        assert!(member.text.contains(&format!(
            "((dt29.SamePackageParentFamily$A) this).{field} = arg1;"
        )));
    }
    assert!(member.text.contains(
        "dt29.SamePackageParentFamily$A.access$002((dt29.SamePackageParentFamily$A) this, arg2);"
    ));
}

fn assert_header_stop(cap: u64) {
    let wide = present(4096);
    let report = present(cap);
    assert_header_stop_reports(&wide, &report, b"(ZZ)V");
}

fn assert_header_stop_reports(
    wide: &ClassSourceReport,
    report: &ClassSourceReport,
    descriptor: &[u8],
) {
    assert!(
        matches!(
            report.execution,
            ExecutionReport::Partial {
                reason: TerminationReason::BudgetExceeded {
                    dimension: jarde_reader::budget::BudgetDimension::ClassHeaders,
                },
                ..
            }
        ),
        "actual class execution: {:?}",
        report.execution
    );
    let constructor = report
        .methods
        .first()
        .expect("the admitted constructor prefix remains");
    assert_eq!(constructor.item.index, 0);
    assert_eq!(constructor.item.identity.name.0, b"<init>");
    assert_eq!(constructor.item.identity.descriptor.0, b"()V");
    assert_eq!(constructor.text, wide.methods[0].text);
    let ClassSourceOutcome::Recovered {
        report: ctor,
        analysis,
    } = &constructor.outcome
    else {
        panic!("the prefix keeps its actual completed run");
    };
    let ClassSourceOutcome::Recovered {
        report: wide_ctor, ..
    } = &wide.methods[0].outcome
    else {
        panic!("wide constructor is recovered");
    };
    assert!(matches!(
        analysis.execution,
        ExecutionReport::Complete { .. }
    ));
    assert!(matches!(ctor.execution, ExecutionReport::Complete { .. }));
    assert_eq!(ctor.source_map.segments(), wide_ctor.source_map.segments());
    // Local ClassHeaders does not necessarily cancel the token: publishing a stopped member
    // still requires its real ResultItems permit. Do not demand an unadmitted member.
    let body_diagnostics = if let Some(member) = physical_set_with_descriptor(report, descriptor) {
        assert_eq!(member.item.index, 1);
        let ClassSourceOutcome::Recovered {
            report: body,
            analysis,
        } = &member.outcome
        else {
            panic!("a published stop member retains its typed recovery outcome");
        };
        assert!(matches!(
            analysis.execution,
            ExecutionReport::Complete { .. }
        ));
        assert!(matches!(
            body.execution,
            ExecutionReport::Partial {
                reason: TerminationReason::BudgetExceeded {
                    dimension: jarde_reader::budget::BudgetDimension::ClassHeaders,
                },
                ..
            }
        ));
        assert!(matches!(
            body.outcome,
            jarde::RecoveryOutcome::Stopped(jarde::StopReason::Interrupted {
                code: "jre_budget_interrupted",
                at: None
            })
        ));
        assert_eq!(body.content, RecoveryContent::NotProduced);
        assert!(body.text.is_empty());
        assert!(body.source_map.segments().is_empty());
        assert!(body.artifact.binding().is_none());
        body.diagnostics.as_slice()
    } else {
        &[]
    };
    assert!(
        report
            .diagnostics
            .iter()
            .chain(body_diagnostics)
            .any(|diagnostic| { diagnostic.message.contains("ClassHeaders") }),
        "the original stop diagnostic survives in aggregate or admitted member"
    );
    assert!(
        report
            .coverage
            .artifact_structural
            .scanned
            .iter()
            .any(|range| { range.label == "class_source_bodies" && range.end > 1 })
    );
    assert!(
        !report
            .coverage
            .artifact_structural
            .skipped
            .iter()
            .any(|range| { range.label == "class_source_bodies" && range.start > 1 }),
        "set is last; do not invent a physical skipped suffix"
    );
}

#[test]
fn dt29_header_cap1_stops_at_the_first_direct_parent_dependency() {
    assert_header_stop(1);
}

#[test]
fn dt29_header_cap2_preserves_the_direct_parent_field_header_stop() {
    assert_header_stop(2);
}

#[test]
fn external_receiver_source_header_stop_is_not_treated_as_an_absent_relation() {
    // The committed family has C.set(B,Z)V: current IR declares C, the receiver is B,
    // and the physical accessor owner is A. B's header must be read from the snapshot.
    let class = "dt29/FieldCast$C";
    let descriptor = b"(Ldt29/FieldCast$B;Z)V";
    let wide = present_class(EXTERNAL_SOURCE, class, 4096);
    assert!(matches!(wide.execution, ExecutionReport::Complete { .. }));
    let member = physical_set_with_descriptor(&wide, descriptor)
        .expect("the committed external-source setter is selected");
    let ClassSourceOutcome::Recovered { analysis, .. } = &member.outcome else {
        panic!("wide source control retains the actual completed analysis");
    };
    let ExecutionReport::Complete { usage } = &analysis.execution else {
        panic!("source control reaches a completed method analysis");
    };
    // Use the real public analysis prefix price, not an invented fixture header total.
    // This method contains no `new`: the legacy reference-overload proof does no reads.
    // The scoped source-read observation described with this candidate must additionally
    // verify that the first refused read is B, inside accessor proof, before field proof.
    let cap = usage.class_headers;
    assert!(cap > 0);
    let report = present_class(EXTERNAL_SOURCE, class, cap);
    assert_header_stop_reports(&wide, &report, descriptor);
}
