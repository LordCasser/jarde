#!/usr/bin/env python3
"""Narrow cache-only CI packaging; no captured tool or audit is executed."""
from pathlib import Path, PurePosixPath
import hashlib, io, json, re, tarfile, zipfile
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015'); O=Path(__file__).resolve().parent
C=B/'own-ci-direct-parent-aadf-root-v1'; I=B/'CORE/own-ci-direct-parent-aadf-independent-audit-prepared-v2'
def pin(p):
 p=Path(p).resolve(); z=p.read_bytes(); return {'path':str(p),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
def load(p): return json.loads(Path(p).read_text())
def check(q): assert pin(q['path'])=={k:q[k] for k in ('path','bytes','sha256')},q['path']
cap=load(C/'execution.json'); root=load(B/'direct-parent-own-ci-root-acceptance-v1.json'); indie=load(I/'audit-result-v1.json')
assert cap['status']=='captured_pending_root_acceptance' and cap['run_status']=='completed' and cap['conclusion']=='success'
assert root['status']=='accepted_exact_product_ci' and root['checks']==826 and root['errors']==[]
assert indie['status']=='accepted_independent_exact_product_ci_review' and indie['checks']==1549 and indie['errors']==[]
assert cap['product_sha']==root['product_sha']==indie['product_sha']=='aadf71f3b4f5658485196edb63fb553f8c107380'
assert cap['run_id']==root['run_id']==indie['run_id']==38703952159 and root['branch']==indie['branch']=='codex/direct-parent-proof-stops'
assert root['jobs']==indie['jobs']==len(cap['jobs'])==4 and root['steps']==indie['steps']==sum(len(j['steps']) for j in cap['jobs'])==52
assert all(j['status']=='completed' and j['conclusion']=='success' for j in cap['jobs'])
for report in (root,indie):
 assert len(report['seeds'])==2
 for seed in report['seeds']: assert (seed['suites'],seed['passed'],seed['failed'],seed['ignored'])==(368,3631,0,98)
assert indie['limits']=={'ci_strict_items':364,'ci_suites_per_seed':368,'passes_per_seed':3631,'ignored_per_seed':98,'gate_names':121}
for key in ('capture','logs_zip','root_acceptance','source_binding','required_gates','workflow'): check(indie[key])
check(cap['logs']); check(root['log_zip']); check(root['required_gate_source']); check(root['auditor'])
gates=load(B/'direct-parent-future-own-ci-gates-v1.json'); names=gates['prior105']+gates['new16']
assert len(gates['prior105'])==105 and len(gates['new16'])==16 and len(set(names))==gates['unique_total']==121
check({'path':gates['prior_gate_source'],'bytes':gates['prior_gate_source_bytes'],'sha256':gates['prior_gate_source_sha256']})
with zipfile.ZipFile(C/'logs.zip') as z:
 assert len(z.namelist())==len(set(z.namelist())) and len(z.namelist())==len(root['log_member_pins'])==len(indie['log_member_pins'])
 for q in root['log_member_pins']:
  data=z.read(q['path']); assert len(data)==q['bytes'] and hashlib.sha256(data).hexdigest()==q['sha256']
 assert root['log_member_pins']==indie['log_member_pins']
 for n in (1,2):
  text=z.read(next(p for p in z.namelist() if f'(pass {n}).txt' in p)).decode()
  sums=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
  assert len(sums)==368 and [sum(int(x[k]) for x in sums) for k in (1,2,3)]==[3631,0,98]
  named=re.findall(r'\btest (\S+) \.\.\. (ok|ignored|FAILED)',text)
  assert all(sum(a==gate and status=='ok' for a,status in named)==1 for gate in names)
 assert 'Totals: 364 passed, 0 failed (364 items)' in z.read(next(p for p in z.namelist() if 'Validate OpenSpec strictly.txt' in p)).decode()
bound={}; files={p.resolve():str(p.relative_to(B)) for p in C.iterdir() if p.is_file()}
wrappers=[B/'direct-parent-own-ci-root-auditor-execution-v1.json',B/'direct-parent-own-ci-independent-auditor-execution-v2.json']
for row in cap['observations']+[load(p) for p in wrappers]:
 assert row['exit_code']==0 and set(row['streams'])=={'stdout','stderr'}
 for q in row['streams'].values():
  check(q); p=Path(q['path']).resolve(); assert p not in bound; bound[p]=q; files[p]=str(p.relative_to(B))
assert len(cap['observations'])==indie['api_observations']==145 and indie['api_raw_stream_count']==290
assert {p for p in C.iterdir() if p.suffix=='.raw'}=={p for p in bound if p.parent==C}
fixed=['direct-parent-own-ci-root-acceptance-v1.json','direct-parent-own-ci-audit-argv-v1.json','direct-parent-future-own-ci-gates-v1.json','direct-parent-product-commit-source-binding-v1.json','direct-parent-focused-root-v1/execution.json','capture_product_ci_v3.py','accept_product_ci_v3.py','wait_and_accept_direct_parent_ci_root_v1.py','wait_and_accept_direct_parent_ci_independent_v2.py','combined-proof-all-ci-gates-root-v1.json']
for p in [*(B/n for n in fixed),*wrappers,*(I/n for n in ['audit_own_ci.py','preparation-pins.json','audit-result-v1.json']),Path(__file__).resolve()]: files[p.resolve()]=str(p.relative_to(B))
files[Path(root['required_gate_source']['path'])]='metadata/old55-root-acceptance.json'; files[Path(indie['workflow']['path'])]='metadata/frozen-workflow-ci.yml'
build=load(B/'direct-parent-focused-root-v1/execution.json'); binding=load(B/'direct-parent-product-commit-source-binding-v1.json')
assert build['source_manifest_before']==build['source_manifest_after'] and len(build['source_manifest_before'])==4905 and build['target_absent']
assert binding['source_count']==4905 and binding['all_source_bytes_and_git_blobs_match'] and binding['own_ci_accepted'] is False
local=pin(B/'CORE/direct-parent-local-fix-evidence-packager-v1/run-v1/direct-parent-local-fix-evidence-v1.tar.gz')
assert local['sha256']=='ac025d0974ff090d038948e25d4e972a2ecd567a3a3cfd7bedc66ab441a055b0'
assert {p for p in files if p.suffix=='.raw'}==set(bound)
rows=[]; payload={}
for p,arc in sorted(files.items(),key=lambda x:x[1]):
 assert p.is_file() and not p.is_symlink() and not PurePosixPath(arc).is_absolute() and '..' not in PurePosixPath(arc).parts
 data=p.read_bytes(); assert not data.startswith((b'\x7fELF',b'MZ')); name='direct-parent-own-ci-v1/'+arc
 assert name not in payload; payload[name]=data; rows.append({**pin(p),'archive_path':name})
allow={'status':'explicit_allowlist_validated','items':rows,'raw_receipt_bound_count':len(bound)}
(O/'allowlist.json').write_text(json.dumps(allow,indent=2)+'\n')
manifest={'status':'packaged_and_reopened_verified','product_sha':root['product_sha'],'run_id':root['run_id'],'items':rows,'raw_receipt_bound_count':len(bound),'external_local_evidence_archive':local,'metrics':{'root_checks':826,'independent_checks':1549,'jobs':4,'steps':52,'seeds':root['seeds'],'gates':121,'strict_items':364},'scope':'CI belongs to aadf product only. Preserve historical captured_pending_root_acceptance and source_binding own_ci_accepted=false snapshots; terminal acceptances are separate records. Later documentation source parity does not create new own-CI evidence. Native CLI/JDK/runtime, EM11 and duplicate local archive excluded.'}
mbytes=(json.dumps(manifest,indent=2)+'\n').encode(); payload['direct-parent-own-ci-manifest.json']=mbytes
archive=O/'direct-parent-own-ci-evidence-v1.tar.gz'; assert not archive.exists()
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tar:
 for name,data in sorted(payload.items()):
  t=tarfile.TarInfo(name); t.size=len(data); t.mode=0o444; t.mtime=0; tar.addfile(t,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers(); assert len(members)==len(payload) and len({m.name for m in members})==len(members)
 assert all(m.isfile() for m in members) and {m.name for m in members}==set(payload)
 for m in members: assert tar.extractfile(m).read()==payload[m.name]
for row in rows: assert Path(row['path']).read_bytes()==payload[row['archive_path']]
(O/'manifest.json').write_bytes(mbytes)
execution={'status':'packaged_and_reopened_verified','archive':pin(archive),'manifest':pin(O/'manifest.json'),'allowlist':pin(O/'allowlist.json'),'packager':pin(Path(__file__)),'payload_files':len(rows),'tar_members':len(payload),'raw_files':len(bound),'zip_members':len(root['log_member_pins']),'external_local_evidence_archive':local}
(O/'execution.json').write_text(json.dumps(execution,indent=2)+'\n'); print(json.dumps(execution,indent=2))
