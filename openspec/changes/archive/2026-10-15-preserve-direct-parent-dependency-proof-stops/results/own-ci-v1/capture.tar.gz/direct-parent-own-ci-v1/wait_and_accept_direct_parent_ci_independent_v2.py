from pathlib import Path
import json,subprocess,time,hashlib
b=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');accept=b/'direct-parent-own-ci-root-acceptance-v1.json';out=b/'direct-parent-own-ci-independent-auditor-execution-v2.json';assert not out.exists()
while True:
 try:d=json.loads(accept.read_text())
 except (ValueError,FileNotFoundError):time.sleep(10);continue
 break
assert d['status']=='accepted_exact_product_ci' and not d['errors']
argv=['python3',str(b/'CORE/own-ci-direct-parent-aadf-independent-audit-prepared-v2/audit_own_ci.py')];r=subprocess.run(argv,capture_output=True);streams={}
for name,z in [('stdout',r.stdout),('stderr',r.stderr)]:
 p=b/('direct-parent-own-ci-independent-auditor-v2.'+name+'.raw');assert not p.exists();p.write_bytes(z);streams[name]={'path':str(p),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
out.write_text(json.dumps({'argv':argv,'exit_code':r.returncode,'streams':streams},indent=2)+'\n');print(r.stdout.decode());print(r.stderr.decode());raise SystemExit(r.returncode)
