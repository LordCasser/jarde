from pathlib import Path
import json,subprocess,time,hashlib
base=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015')
cap=base/'own-ci-direct-parent-aadf-root-v1/execution.json'
out=base/'direct-parent-own-ci-root-auditor-execution-v1.json'
assert not out.exists()
while True:
 try:d=json.loads(cap.read_text())
 except (ValueError,FileNotFoundError):time.sleep(5);continue
 if d['status']=='captured_pending_root_acceptance':break
 if d.get('run_status')=='completed' and d.get('conclusion') not in [None,'success']:raise SystemExit('CI did not succeed')
 time.sleep(10)
assert d['conclusion']=='success'
argv=json.loads((base/'direct-parent-own-ci-audit-argv-v1.json').read_text())
r=subprocess.run(argv,capture_output=True)
streams={}
for name,data in [('stdout',r.stdout),('stderr',r.stderr)]:
 p=base/('direct-parent-own-ci-root-auditor-v1.'+name+'.raw');assert not p.exists();p.write_bytes(data);streams[name]={'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
out.write_text(json.dumps({'argv':argv,'exit_code':r.returncode,'streams':streams},indent=2)+'\n')
print(r.stdout.decode());print(r.stderr.decode());raise SystemExit(r.returncode)
