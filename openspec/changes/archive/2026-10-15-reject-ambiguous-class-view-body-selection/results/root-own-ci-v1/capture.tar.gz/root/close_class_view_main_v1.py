from pathlib import Path
import io,json,hashlib,tarfile,shutil
R=Path('/home/lordcasser/workspace/projects/jarde');B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');C=R/'openspec/changes/reject-ambiguous-class-view-body-selection';S=json.loads((B/'class-view-main-closure-v1/status.json').read_text());I=json.loads((B/'class-view-main-closure-v1/spec-instructions.json').read_text());assert all(x['status']=='done' for x in S['artifacts']);assert S['planningHome']['root']==str(R) and I['artifactId']=='specs';paths=S['artifactPaths']['specs']['existingOutputPaths'];assert paths==[str(C/'specs/analysis-contracts/spec.md')]
j=json.loads((B/'own-ci-class-view-root-acceptance-v1.json').read_text());assert j['status']=='accepted_exact_product_ci' and j['product_sha']=='e8c749252a71a857838d0cb854f5a6d80a5c2704';f=json.loads((B/'class-view-focused-root-v1/execution.json').read_text())
for p in f['source_manifest_after']:
 z=(R/p['path']).read_bytes();assert len(z)==p['bytes'] and hashlib.sha256(z).hexdigest()==p['sha256'],p['path']
O=C/'results/root-own-ci-v1';assert not O.exists();files={}
def add(p,n):assert p.is_file() and not p.is_symlink() and n not in files;files[n]=p.read_bytes()
for p in sorted((B/'own-ci-class-view-e8c-root-v1').rglob('*')):
 if p.is_file():add(p,'capture/'+p.relative_to(B/'own-ci-class-view-e8c-root-v1').as_posix())
for n in ['own-ci-class-view-root-acceptance-v1.json','accept_product_ci_v2.py','capture_product_ci_v3.py','class-view-own-ci-audit-argv-v1.json','class-view-own-ci-audit-v1.stdout.raw','class-view-own-ci-audit-v1.stderr.raw','close_class_view_main_v1.py']:add(B/n,'root/'+n)
for p in sorted((B/'class-view-main-closure-v1').iterdir()):add(p,'context/'+p.name)
add(Path('/home/lordcasser/.cache/jarde-review/20261015/class-view-e8c-own-ci-independent-audit-v1/audit.json'),'independent/audit.json')
m={'schema':'class-view-exact-own-ci-v1','product_sha':j['product_sha'],'run_id':j['run_id'],'payloads':[{'path':n,'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()} for n,z in sorted(files.items())]};files['manifest.json']=(json.dumps(m,indent=2)+'\n').encode();O.mkdir();p=O/'capture.tar.gz'
with tarfile.open(p,'w:gz') as t:
 for n,z in sorted(files.items()):
  x=tarfile.TarInfo(n);x.size=len(z);x.mode=0o644;x.mtime=0;t.addfile(x,io.BytesIO(z))
with tarfile.open(p,'r:gz') as t:
 assert len(t.getmembers())==len(files)
 for x in t:assert x.isfile() and t.extractfile(x).read()==files[x.name]
a={'status':'accepted_exact_product_ci_archive','payloads':len(files)-1,'members_reopened':len(files),'archive':{'path':'capture.tar.gz','bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},'primary_source_equals_4900_test_inputs':True};(O/'archive-review.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text('''# class-view 产品自身CI与主线交付\n\n修复产品e8c749252a71a857838d0cb854f5a6d80a5c2704的自身CI38679565191成功；4jobs/52steps，两seed各365suites、3589通过/0失败/98忽略，79具名门均一次通过。native Rust1.99.0、Temurin25.0.4+7和strict366/0，既有九额外JDK测试、两examples/12层级配置及P5/corpus/fuzz门按实际workflow通过。根802项核查及独立1462项核查接受。\n\n本tar保存完整API/raw/ZIP和来源上下文；manifest逐项列bytes/SHA，根已重新打开全部成员核验。既有local focused76/0/2和九组合27库请求/三CLI请求保留各自范围。primary主线已快进到exact e8c；4900原始测试输入与primary当前字节逐项相同。随后只同步本片4个新增scenario、归档及文档收尾，收尾HEAD单独检查，不把产品CI说成未来文档HEAD自身CI。\n\n接口及snapshot/double-brace停止修复继续独立实现；本片不增加CF11/CF18/71/612整体完成数。\n''')
p=C/'tasks.md';s=p.read_text();assert s.count('- [ ]')==1;s=s.replace('- [ ] 2.2','- [x] 2.2');s+='\n## 终态验收\n\n- 产品e8c自身CI38679565191双seed7178/0/196、79具名门接受；root802/independent1462checks，完整证据见results/root-own-ci-v1。4/4已完成，primary4900编译来源逐项恒同；后续同步归档只修改规格与交付文档。\n';p.write_text(s)
delta=Path(paths[0]).read_text();head='### Requirement: Task-oriented target selection binds real physical identity';new=delta[delta.index(head):].strip();p=R/'openspec/specs/analysis-contracts/spec.md';s=p.read_text();i=s.index(head);e=s.index('\n### Requirement:',i+1);old=s[i:e].strip();assert new.startswith(old+'\n');assert new.count('#### Scenario:')==old.count('#### Scenario:')+4;s=s[:i]+new+'\n'+s[e:];p.write_text(s);assert new in p.read_text()
A=R/'openspec/changes/archive/2026-10-15-reject-ambiguous-class-view-body-selection';assert not A.exists();assert '- [ ]' not in (C/'tasks.md').read_text();shutil.move(C,A);assert (A/'.openspec.yaml').is_file()
for fn in ['handoff.md','openspec/completion-review.md']:
 p=R/fn;s=p.read_text();a=s.find('## 2026-10-15 class-view');b=s.find('\n## ',a+1);assert a>=0 and b>a
 prefix='' if fn=='handoff.md' else '../openspec/'
 # Completion-review links are relative to openspec/.
 base='openspec/changes/archive/' if fn=='handoff.md' else 'changes/archive/'
 text='''## 2026-10-15 class-view 歧义修复已交付并归档\n\n产品e8c749252a71a857838d0cb854f5a6d80a5c2704已进入main，自身[CI38679565191](https://github.com/LordCasser/jarde/actions/runs/38679565191)由根802项/独立1462项核查接受：4jobs52steps，两seed各365suites、3589/0/98，79具名门及既有额外JDK/examples/层级/fuzz门通过。修复保留foreign-owner优先级，重复Name及listed identity都在body准入前按完整候选返回歧义。既有76/0/2本地门、九组27库请求及三CLI请求保持原范围。\n\n[自身CI与交付证据](BASE2026-10-15-reject-ambiguous-class-view-body-selection/results/root-own-ci-v1/README.md)逐成员复开；4900测试来源同primary字节。4/4完成，analysis-contracts新增四scenario并归档。产品CI头与后续文档头区分；不增加CF11/CF18/71/612总数。\n\n接口停止修复在独立AUX已有cc305fe6a本地检查点，813/0/1及八组完整源对照通过，尚待最终组合产品workspace/自身CI；snapshot/double-brace保持独立规划，当前冻结接口CLI已复现原H1 ClassHeaders8/15仍Complete，未冒称修复通过。\n'''.replace('BASE',base)
 p.write_text(s[:a]+text+s[b:])
print(json.dumps(a if False else {'archive':str(A),'evidence':a if isinstance(a,dict) else 'written','tar':str(O/'capture.tar.gz')}))
