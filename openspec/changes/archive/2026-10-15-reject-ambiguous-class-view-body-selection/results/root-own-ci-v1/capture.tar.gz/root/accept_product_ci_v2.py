from pathlib import Path,PurePosixPath
import argparse,hashlib,json,re,zipfile
ap=argparse.ArgumentParser();ap.add_argument('--strict-items',type=int,default=367);ap.add_argument('--gate',action='append',default=[]);ap.add_argument('--capture',type=Path,required=True);ap.add_argument('--head',required=True);ap.add_argument('--branch',required=True);ap.add_argument('--run',type=int,required=True);ap.add_argument('--passed',type=int,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();assert not a.out.exists()
def pin(p):
 p=Path(p);z=p.read_bytes();return {'path':str(p),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
checks=[];errors=[]
def ck(v,s):
 checks.append(s)
 if not v:errors.append(s)
d=json.loads((a.capture/'execution.json').read_text());ck(d['status']=='captured_pending_root_acceptance','capture complete');ck(d['product_sha']==a.head and d['run_id']==a.run,'requested product and run');ck(d['conclusion']=='success','capture conclusion')
for row in d['observations']:
 ck(row['exit_code']==0,'API exit/'+row['endpoint'])
 for k,v in row['streams'].items():
  q=pin(v['path']);ck(q['bytes']==v['bytes'] and q['sha256']==v['sha256'],'raw API '+v['path'])
r=json.loads(Path(d['observations'][-3]['streams']['stdout']['path']).read_text());j=json.loads(Path(d['observations'][-2]['streams']['stdout']['path']).read_text())
ck(r['id']==a.run and r['head_sha']==a.head and r['head_branch']==a.branch and r['event']=='push' and r['status']=='completed' and r['conclusion']=='success','final actual run identity')
ck(j['jobs']==d['jobs'],'actual final jobs');ck(len(j['jobs'])==4,'four jobs');steps=[s for v in j['jobs'] for s in v['steps']];ck(len(steps)==52,'52 steps')
for job in j['jobs']:
 ck(job['status']=='completed' and job['conclusion']=='success','job/'+job['name'])
 for step in job['steps']:ck(step['status']=='completed' and step['conclusion'] in ['success','skipped'],'step/'+job['name']+'/'+step['name'])
q=pin(a.capture/'logs.zip');ck(q['sha256']==d['logs']['sha256'] and q['bytes']==d['logs']['bytes'],'downloaded logs zip')
gatefile=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/workspace-forward-v10/root-acceptance.json');g=json.loads(gatefile.read_text());names=list(g['required_named_test_outcomes_by_seed']['5350648285461741569'])+a.gate;members=[];seeds=[]
ansi=re.compile(r'\x1b\[[0-9;]*m')
with zipfile.ZipFile(a.capture/'logs.zip') as z:
 ck(len(z.namelist())==len(set(z.namelist())),'unique log members')
 for info in z.infolist():
  ck(not info.is_dir() and not PurePosixPath(info.filename).is_absolute() and '..' not in PurePosixPath(info.filename).parts,'safe regular log/'+info.filename)
  data=z.read(info);members.append({'path':info.filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 def read(term):
  matches=[n for n in z.namelist() if n.startswith('stable _ test and specification/') and term in n];ck(len(matches)==1,'unique step log/'+term);return ansi.sub('',z.read(matches[0]).decode(errors='replace'))
 ck('rustc 1.99.0 (b940084d7' in read('Install stable Rust with lint'),'native stable version')
 ck('Version: 25.0.4+7.0.LTS' in read('4_Install Temurin'),'native Temurin version')
 ck(f'Totals: {a.strict_items} passed, 0 failed ({a.strict_items} items)' in read('Validate OpenSpec strictly'),f'strict {a.strict_items}/0')
 ck('git diff --exit-code' in read('Ensure tracked files remain unchanged'),'tracked clean command')
 for n,seed in [(1,'5350648285461741569'),(2,'5350648285461741570')]:
  t=read('pass '+str(n)+')');ck('PROPTEST_RNG_SEED: '+seed in t,'independent seed/'+seed);ck('cargo test --workspace --all-targets --all-features --locked' in t,'exact workspace argv/'+seed)
  summaries=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t);ck(len(summaries)==365,'365 suites/'+seed)
  totals={'passed':sum(int(v[1]) for v in summaries),'failed':sum(int(v[2]) for v in summaries),'ignored':sum(int(v[3]) for v in summaries)}
  ck(totals=={'passed':a.passed,'failed':0,'ignored':98},'suite totals/'+seed);ck(all(v[0]=='ok' for v in summaries),'all suite results ok/'+seed)
  named=re.findall(r'test (.+) \.\.\. (ok|ignored|FAILED)(?:, [^\n]*)?\s*$',t,re.M);ck(sum(v=='ok' for _,v in named)==a.passed,'actual named passes/'+seed);ck(sum(v=='ignored' for _,v in named)==98,'actual named ignored/'+seed)
  for name in names:ck(sum(x==name and y=='ok' for x,y in named)==1,'required named gate/'+seed+'/'+name)
  seeds.append({'seed':seed,'suites':len(summaries),**totals})
report={'status':'accepted_exact_product_ci' if not errors else 'rejected','product_sha':a.head,'run_id':a.run,'branch':a.branch,'checks':len(checks),'errors':errors,'jobs':len(j['jobs']),'steps':len(steps),'seeds':seeds,'log_zip':q,'log_member_pins':members,'required_gate_source':pin(gatefile),'auditor':pin(__file__),'scope':'exact product CI only; final main integration and docs tracked separately'}
a.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['log_member_pins']}));raise SystemExit(bool(errors))
