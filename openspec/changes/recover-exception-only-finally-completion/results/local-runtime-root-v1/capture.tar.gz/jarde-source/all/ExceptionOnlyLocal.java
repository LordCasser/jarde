// jarde: presentation of `ExceptionOnlyLocal` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class ExceptionOnlyLocal extends java.lang.Object {
    public static int trace;

    public ExceptionOnlyLocal() {
        // @method <init>()V
        // @declaration a constructor of `ExceptionOnlyLocal`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    private static void mark(int arg0) {
        // @method mark(I)V
        // @declaration a static method of `ExceptionOnlyLocal`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        ExceptionOnlyLocal.trace = ExceptionOnlyLocal.trace * 10 + arg0;
        return;
    }

    public static int run(java.lang.RuntimeException arg0) {
        // @method run(Ljava/lang/RuntimeException;)I
        // @declaration a static method of `ExceptionOnlyLocal`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        try {
            mark(7);
            throw arg0;
        } finally {
            mark(8);
        }
    }
}
