// default package

/* JADX INFO: loaded from: ExceptionOnlyLocal.class */
public class ExceptionOnlyLocal {
    public static int trace;

    private static void mark(int i) {
        trace = (trace * 10) + i;
    }

    public static int run(RuntimeException runtimeException) {
        try {
            int i = 7;
            throw runtimeException;
        } finally {
            mark(8);
        }
    }
}
