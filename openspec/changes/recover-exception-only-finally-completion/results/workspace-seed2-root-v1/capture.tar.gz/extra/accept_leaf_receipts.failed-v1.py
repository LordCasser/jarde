#!/usr/bin/env python3
"""Add per-test and per-target parity checks to the reviewed workspace acceptance."""
from __future__ import annotations

import argparse
import importlib.util
import json
import re
import sys
from pathlib import Path

ROOT = Path("/Users/lordcasser/workspace/projects/jarde")
ACCEPTOR_PATH = ROOT / "openspec/changes/recover-branch-throw-return-finally/tools/workspace_acceptor.py"
OWN_CI_PATH = Path("/private/tmp/jarde-exception-only-tests-prep-20261017/verify-own-ci.py")
SEED1 = "5350648285461741569"
SEED2 = "5350648285461741570"
DEFAULT_OUT1 = Path("/private/tmp/jarde-exception-only-workspace-seed1-root-v1-20261018")
DEFAULT_OUT2 = Path("/private/tmp/jarde-exception-only-workspace-seed2-root-v1-20261018")

ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
SUMMARY = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
    r"(\d+) measured; (\d+) filtered out(?:; finished in .*)?$"
)


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"cannot load verifier module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def read_seed(out: Path, expected_seed: str, acceptor, own_ci):
    out = out.resolve(strict=True)
    execution = json.loads((out / "execution.json").read_text(encoding="utf-8"))
    metadata = json.loads((out / "metadata.json").read_text(encoding="utf-8"))
    # Run the full previously reviewed evidence gate before deriving additional receipts.
    accepted = acceptor.verify(execution, metadata, out, expected_seed)

    target_counts: dict[tuple[str, str, str], tuple[int, ...]] = {}
    outcomes: list[tuple[str, str]] = []
    for row in execution["commands"]:
        stdout = acceptor.verify_stream(out, row["streams"]["stdout"])
        stderr = acceptor.verify_stream(out, row["streams"]["stderr"])
        text = ANSI.sub("", stdout.decode("utf-8", errors="replace"))
        err_text = ANSI.sub("", stderr.decode("utf-8", errors="replace"))

        for line in text.splitlines():
            match = own_ci.OUTCOME.fullmatch(line)
            if match:
                state = match.group(2)
                outcomes.append((match.group(1), "ignored" if state.startswith("ignored") else state))

        artifacts = acceptor.artifacts(stdout)
        by_executable = {str(Path(item["executable"]).resolve()): item for item in artifacts}
        summary_rows = SUMMARY.findall(text)
        acceptor.need(
            all(status == "ok"
                and int(failed) == 0
                and int(measured) == 0
                and int(filtered) == 0
                for status, _passed, failed, _ignored, measured, filtered in summary_rows),
            f"raw test summary is not fully passing in seed {expected_seed}, batch {row['index']}",
        )
        counts = [tuple(map(int, match[1:])) for match in summary_rows]
        running = re.findall(r"^\s*Running[^\n]*\(([^()\n]+)\)\s*$", err_text, re.MULTILINE)
        executed = [str((acceptor.ROOT / path).resolve()) for path in running]
        acceptor.need(
            len(counts) == len(executed) == len(artifacts)
            and len(set(executed)) == len(executed)
            and set(executed) == set(by_executable),
            f"raw stdout summaries and stderr Running order do not bind target identities in seed {expected_seed}, batch {row['index']}",
        )
        for executable, count in zip(executed, counts):
            item = by_executable[executable]
            identity = (item["package_id"], item["name"], item["kind"])
            acceptor.need(identity not in target_counts, f"duplicate target count record in seed {expected_seed}: {identity}")
            target_counts[identity] = count

    critical = {}
    for label, name in own_ci.CRITICAL_TESTS.items():
        matches = [(seen, state) for seen, state in outcomes if seen.rsplit("::", 1)[-1] == name]
        acceptor.need(
            len(matches) == 1 and matches[0][1] == "ok",
            f"critical test missing, duplicated, or not ok in seed {expected_seed}: {label} ({name})",
        )
        critical[label] = {"name": name, "outcome": "ok", "occurrences": 1}

    inventory = {tuple(row) for row in execution["target_inventory"]}
    acceptor.need(set(target_counts) == inventory,
                  f"per-target raw summary inventory differs in seed {expected_seed}")
    return {
        "seed": expected_seed,
        "workspace_acceptor": accepted,
        "raw_test_outcomes": len(outcomes),
        "critical_tests": critical,
        "target_count": len(target_counts),
        "per_target_counts": {"|".join(key): list(value) for key, value in sorted(target_counts.items())},
        "_counts": target_counts,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed1", type=Path, default=DEFAULT_OUT1)
    parser.add_argument("--seed2", type=Path, default=DEFAULT_OUT2)
    args = parser.parse_args()

    acceptor = load_module("reviewed_workspace_acceptor", ACCEPTOR_PATH)
    own_ci = load_module("exception_only_own_ci", OWN_CI_PATH)
    first = read_seed(args.seed1, SEED1, acceptor, own_ci)
    second = read_seed(args.seed2, SEED2, acceptor, own_ci)
    acceptor.need(first["_counts"] == second["_counts"],
                  "per-target test counts differ between the two complete workspace seeds")
    first.pop("_counts")
    second.pop("_counts")
    print(json.dumps({
        "status": "accepted_read_only",
        "per_target_counts_match": True,
        "seeds": [first, second],
    }, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
