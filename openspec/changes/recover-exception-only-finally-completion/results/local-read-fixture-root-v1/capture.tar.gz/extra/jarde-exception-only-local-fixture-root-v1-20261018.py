from pathlib import Path
import json,hashlib,importlib.util,os,shutil
r=Path('/Users/lordcasser/workspace/projects/jarde');o=Path('/private/tmp/jarde-exception-only-local-fixture-root-v1-20261018');assert not o.exists() and not(r/'target').exists();o.mkdir();(o/'raw').mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(r/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','cmp');g=load(r/c.GUARD_REL,'guard');sc=load(r/c.SCANNER_REL,'scan');g.ROOT=r;g.OUT=o/'raw';g.target_bytes=lambda:sc.target_bytes(r);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None;jdks,pins=c.configured_jdks(r/c.DEFAULT_JDK_MANIFEST_REL,c.DEFAULT_JDK_MANIFEST_SHA256);classes=o/'classes';classes.mkdir();source=o/'ExceptionOnlyLocal.java';source.write_bytes(Path('/private/tmp/jarde-exception-only-impl-prep-20261017/fixtures/ExceptionOnlyLocal.java').read_bytes());verifier=o/'VerifyLocal.java';verifier.write_text('public class VerifyLocal { public static void main(String[] args) throws Exception { Class<?> c = Class.forName("ExceptionOnlyLocal", false, VerifyLocal.class.getClassLoader()); if(c.getDeclaredMethods().length != 2 || c.getDeclaredConstructors().length != 1) throw new AssertionError(); System.out.println("VERIFIED ExceptionOnlyLocal: 2 methods and 1 constructor; no target invocation"); } }\n');x={'status':'running','source':c.pin(source),'verifier':c.pin(verifier),'JDKs':pins,'commands':[]}
def save(): (o/'execution.json').write_text(json.dumps(x,indent=2)+'\n')
def cmd(argv,jdk):
 row=g.run_command(len(x['commands'])+1,argv,c.clean_env(dict(os.environ),jdk));x['commands'].append(row);save();assert row['guard_stop'] is None and row['exit_code']==0,row['exit_code']
cmd([str(jdks['javac23']['tools']['javac']),'--release','8','-g:none','-d',str(classes),str(source),str(verifier)],jdks['javac23'])
cmd([str(jdks['javac23']['tools']['javap']),'-v','-p','-c',str(classes/'ExceptionOnlyLocal.class')],jdks['javac23'])
for jdk in jdks.values():cmd([str(jdk['tools']['java']),'-Xverify:all','-cp',str(classes),'VerifyLocal'],jdk)
x.update(status='passed_pending_root_review',classfile=c.pin(classes/'ExceptionOnlyLocal.class'),target_absent=not(r/'target').exists());save();print(json.dumps({k:x[k] for k in ['status','classfile','target_absent']}))
