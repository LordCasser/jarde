// default package

/* JADX INFO: loaded from: ExceptionOnlyFinally.class */
public class ExceptionOnlyFinally {
    public static int trace = 0;
    public static final RuntimeException TRY_FAILURE = new IllegalArgumentException("try");

    private static int mark(int i) {
        trace = (trace * 10) + i;
        System.out.print(i);
        return i;
    }

    public static int tryThrowsFinallyRuns() {
        try {
            int i = 7;
            throw TRY_FAILURE;
        } finally {
            mark(8);
        }
    }
}
