import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path('/Users/lordcasser/workspace/projects/jarde')
out, runid, product = Path(sys.argv[1]), sys.argv[2], sys.argv[3]
assert len(product) == 40 and not out.exists()
out.mkdir()
record = {'product_sha': product, 'run_id': runid, 'commands': []}

def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def command(argv, name):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    stdout, stderr = out / name, out / (name + '.stderr.raw')
    stdout.parent.mkdir(parents=True, exist_ok=True)
    with stdout.open('xb') as so, stderr.open('xb') as se:
        result = subprocess.run(argv, cwd=root, stdout=so, stderr=se)
    row = {'argv': argv, 'exit_code': result.returncode, 'started_at': start,
           'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'streams': {'stdout': pin(stdout), 'stderr': pin(stderr)}}
    assert result.returncode == 0, row
    return row

record['commands'].append(command(['gh', 'run', 'view', runid, '--repo', 'LordCasser/jarde',
    '--json', 'jobs,headSha,status,conclusion,url,databaseId,workflowName'], 'run.json'))
run = json.loads((out / 'run.json').read_text())
assert run['headSha'] == product and run['status'] == 'completed' and run['conclusion'] == 'success'
jobs = {'stable / test and specification': 'stable', 'MSRV 1.88.0': 'msrv',
        'supply chain': 'supply-chain', 'fuzz smoke': 'fuzz-smoke'}
assert {job['name'] for job in run['jobs']} == set(jobs)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    futures = [pool.submit(command, ['gh', 'run', 'view', runid, '--repo', 'LordCasser/jarde',
        '--job', str(job['databaseId']), '--log'], jobs[job['name']] + '.log') for job in run['jobs']]
    record['commands'].extend(f.result() for f in futures)

paths = ('.github/workflows/ci.yml', 'crates/jarde-java/src/guard.rs',
    'crates/jarde-java/src/build.rs', 'tests/recover_exception_only_finally_completion.rs',
    'tests/recover_exception_only_finally_stops.rs')
pins = {'product_sha': product, 'files': {}}
for rel in paths:
    row = command(['git', 'show', product + ':' + rel], 'product-source/' + rel)
    record['commands'].append(row)
    data = (out / 'product-source' / rel).read_bytes()
    assert data == (root / rel).read_bytes(), rel
    pins['files'][rel] = {'git_show': 'git show ' + product + ':' + rel,
        'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
(out / 'source-pins.json').write_text(json.dumps(pins, indent=2) + '\n')
(out / 'workflow.sha256').write_text(pins['files'][paths[0]]['sha256'] + '\n')
record['status'] = 'raw collection complete; independent acceptance pending'
(out / 'collection.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'status': record['status'], 'commands': len(record['commands'])}))
