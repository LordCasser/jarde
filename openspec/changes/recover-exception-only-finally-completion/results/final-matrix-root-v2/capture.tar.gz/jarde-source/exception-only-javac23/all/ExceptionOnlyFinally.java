// jarde: presentation of `ExceptionOnlyFinally` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class ExceptionOnlyFinally extends java.lang.Object {
    public static int trace;

    public static final java.lang.RuntimeException TRY_FAILURE;

    public ExceptionOnlyFinally() {
        // @method <init>()V
        // @declaration a constructor of `ExceptionOnlyFinally`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    private static int mark(int arg0) {
        // @method mark(I)I
        // @declaration a static method of `ExceptionOnlyFinally`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        ExceptionOnlyFinally.trace = ExceptionOnlyFinally.trace * 10 + arg0;
        java.lang.System.out.print(arg0);
        return arg0;
    }

    public static int tryThrowsFinallyRuns() {
        // @method tryThrowsFinallyRuns()I
        // @declaration a static method of `ExceptionOnlyFinally`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        try {
            mark(7);
            throw ExceptionOnlyFinally.TRY_FAILURE;
        } finally {
            mark(8);
        }
    }

    static {
        // @method <clinit>()V
        // @declaration a static initializer of `ExceptionOnlyFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        ExceptionOnlyFinally.trace = 0;
        TRY_FAILURE = new java.lang.IllegalArgumentException("try");
    }
}
