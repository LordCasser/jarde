import importlib.util,json,os,shutil,hashlib,tarfile
from pathlib import Path
r=Path('/Users/lordcasser/workspace/projects/jarde');o=Path('/private/tmp/jarde-exception-only-freeze-inputs-root-v1-20261017');o.mkdir();base=r/'tests/fixtures/recover-exception-only-finally-completion';(base/'source').mkdir(parents=True);(base/'sealed/source').mkdir(parents=True)
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(r/'openspec/changes/recover-return-through-nested-finally-cleanup/tools/compare.py','cmp');g=load(c.GUARD_PATH,'guard');sc=load(c.SCANNER_PATH,'scan');assert c.sha_file(c.GUARD_PATH)==c.GUARD_SHA256 and c.sha_file(c.SCANNER_PATH)==c.SCANNER_SHA256
g.ROOT=r;g.OUT=o/'raw';g.OUT.mkdir();g.target_bytes=lambda:sc.target_bytes(r);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
for n in ('ExceptionOnlyFinally.java','ExceptionOnlyFinallyDriver.java'):shutil.copyfile(Path('/private/tmp/jarde-exception-only-jadx-analysis-20261017/fixture')/n,base/'source'/n)
for n in ('FinallyCompletion.java','FinallyCompletionRunner.java'):shutil.copyfile(r/'openspec/evidence/java-syntax-2026-09-22/finally-completion'/n,base/'sealed/source'/n)
jdks,pins=c.configured_jdks(c.DEFAULT_JDK_MANIFEST,c.DEFAULT_JDK_MANIFEST_SHA256);x={'status':'running','jdks':pins,'commands':[],'classes':{},'source_pins':{str(p.relative_to(r)):c.pin(p) for p in base.rglob('*.java')}}
def save():(o/'execution.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def cmd(argv,label,jdk):
 row=g.run_command(len(x['commands'])+1,argv,c.environment(dict(os.environ),jdk));row['label']=label;x['commands'].append(row);save();assert row['exit_code']==0 and row['guard_stop'] is None;return row
for compiler,jdk in jdks.items():
 flags=['-source','8','-target','8','-g:none','-Xlint:-options','-proc:none'] if compiler=='javac8' else ['--release','8','-g:none','-proc:none']
 for sealed in (False,True):
  folder=o/compiler/('sealed' if sealed else 'independent');classes=folder/'classes';classes.mkdir(parents=True);cp=folder/'empty';cp.mkdir()
  files=[base/'sealed/source/FinallyCompletion.java',base/'sealed/source/FinallyCompletionRunner.java'] if sealed else [base/'source/ExceptionOnlyFinally.java',base/'source/ExceptionOnlyFinallyDriver.java']
  cls='FinallyCompletion' if sealed else 'ExceptionOnlyFinally'
  cmd([str(jdk['tools']['javac']),*flags,'-classpath',str(cp),'-sourcepath',str(cp),'-d',str(classes),*map(str,files)],f'{compiler}-{cls}-compile',jdk)
  row=cmd([str(jdk['tools']['javap']),'-classpath',str(classes),'-c','-p','-s',cls],f'{compiler}-{cls}-javap',jdk)
  p=classes/(cls+'.class');facts=c.classfile_method_facts(p,'tryThrowsFinallyRuns','()I');assert facts['code_length_bytes']==19 and facts['instruction_bcis']==[0,2,5,6,9,10,11,13,16,17,18] and facts['rows']==[(0,11,10,0)],facts
  if sealed:
   old=Path('/private/tmp/jarde-finallycompletion-reject-control-20261017')/compiler/'FinallyCompletion.class';assert p.read_bytes()==old.read_bytes(),f'{compiler} original source no longer creates sealed bytes';dest=base/'sealed'/compiler/p.name
  else:dest=base/('v8-javac8' if compiler=='javac8' else 'v8')/p.name
  dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);x['classes'][f'{compiler}-{cls}']={'pin':c.pin(dest),'facts':facts}
x['status']='compiled and frozen actual inputs';x['target_absent']=not(r/'target').exists();save();shutil.copyfile('/private/tmp/jarde-exception-only-freeze-inputs-root-v1-20261017.py',o/'collector.py')
print(json.dumps({'status':x['status'],'commands':len(x['commands']),'classes':{k:v['pin'] for k,v in x['classes'].items()}},ensure_ascii=False))
