import pathlib,importlib.util,json,hashlib,os,shutil,datetime
R=pathlib.Path('/Users/lordcasser/workspace/projects/jarde');O=pathlib.Path('/private/tmp/jarde-exception-only-existing-finally-public-root-v1-20261018');assert not O.exists() and not (R/'target').exists();O.mkdir();(O/'raw').mkdir()
def module(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def pin(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
c=module(R/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','cmp');w=module(R/'openspec/changes/recover-branch-throw-return-finally/tools/workspace_runner.py','ws');g=module(R/c.GUARD_REL,'guard');s=module(R/c.SCANNER_REL,'scanner');assert pin(R/c.GUARD_REL)['sha256']==c.GUARD_SHA256 and pin(R/c.SCANNER_REL)['sha256']==c.SCANNER_SHA256;g.ROOT=R;g.OUT=O/'raw';g.target_bytes=lambda:s.target_bytes(R);g.command_stream=pin;g.expected_test_summaries=lambda i,b:None
cli=pathlib.Path('/private/tmp/jarde-exception-only-focused-root-v3-20261018/candidate-cli');assert pin(cli)['sha256']=='342d8aec2a309cb9e031977fbba0168bb8407fa5841ad48093e5dfcc90ff7a7d';assert pin(c.BASELINE_CLI)['sha256']==c.BASELINE_CLI_SHA256
env={k:v for k,v in os.environ.items() if k not in ['RUST_MIN_STACK','CARGO_TARGET_DIR','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH']};x={'status':'running','runner':pin(__file__),'source_before':w.source_pins(),'commands':[],'comparisons':[],'cli':pin(cli),'baseline_cli':pin(c.BASELINE_CLI)}
def save(): (O/'execution.json').write_text(json.dumps(x,indent=2)+'\n')
save()
try:
 inputs=[]
 for old in ['jarde-nested-final-matrix-root-v1-20261017','jarde-nested-finthrow-regression-matrix-root-v1-20261017']:
  prior=json.loads((pathlib.Path('/private/tmp')/old/'execution.json').read_text())
  inputs.extend(pathlib.Path(row['argv'][row['argv'].index('--input')+1]) for row in prior['commands'] if 'class-source' in row['argv'])
 prior=json.loads(pathlib.Path('/private/tmp/jarde-nested-parent-fixed-matrix-root-v1-20261017/execution.json').read_text())
 inputs.extend(pathlib.Path(pin['path']) for leg in prior['fixed_inputs']['target_classes'].values() for pin in leg.values())
 inputs.extend(R/rel for rel in ['tests/fixtures/p3-concat-saved-finally/exceptional/FinallyOnce.class','tests/fixtures/p3-concat-saved-finally/v8/FinallyOnce.class','tests/fixtures/p3-exception-only-catchall/v8/IdentityOnce.class','tests/fixtures/p3-exception-only-catchall/v8/FinallyOnce.class'])
 for p in sorted(set(inputs)):
  name=str(p);facts=c.parse_class(p);class_name=facts['class_name'];prior=None
  for profile in ['default','all']:
   for label,exe in [('before',c.BASELINE_CLI),('after',cli)]:
    argv=[str(exe),'class-source','--input',str(p),'--class',class_name,'--policy','single-class','--release','8','--format','json'];argv+=['--evidence','all'] if profile=='all' else []
    row=g.run_command(len(x['commands'])+1,argv,env);x['commands'].append(row);save();assert row['exit_code']==0 and row['guard_stop'] is None
    doc=json.loads(c.command_artifact(row,'stdout'));assert len(doc['methods'])==len(facts['methods']);reports=[]
    for physical,method in zip(facts['methods'],doc['methods']):
     assert (method['item']['name']['escaped'],method['item']['descriptor']['escaped'])==(physical['name'],physical['descriptor']);report=method['outcome']['report'];covered=set();text=report['text'].encode()
     for seg in report['source_map']['segments']:
      lo,hi=seg['start'],seg['end'];assert 0<=lo<hi<=len(text);text[:lo].decode();text[:hi].decode()
      for origin in [seg['origin']['primary'],*seg['origin']['derived']]:
       if origin.get('bci') is not None:assert origin['method']==method['item']['identity'];covered.add(origin['bci'])
     assert covered==set(physical['code']['bcis']);reports.append({k:report[k] for k in ['text','source_map','quality','representation','content','fallbacks']})
    evidence={'text':doc['text'],'reports':reports}
    if prior is None:prior=evidence
    else:assert evidence==prior,(name,profile,label,'semantic neighbor changed')
    x['comparisons'].append({'input':pin(p),'class_name':class_name,'profile':profile,'product':label,'command':row['index'],'whole_source_sha256':hashlib.sha256(doc['text'].encode()).hexdigest(),'methods':len(facts['methods']),'physical_bcis_UTF8_identity':True});save()
 x['status']='passed_pending_root_acceptance'
except BaseException as e:x.update(status='failed',error=repr(e));raise
finally:
 x['source_after']=w.source_pins();x['source_unchanged']=x['source_before']==x['source_after'];x['target_absent']=not (R/'target').exists();x['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({k:x.get(k) for k in ['status','error','source_unchanged','target_absent']}))
