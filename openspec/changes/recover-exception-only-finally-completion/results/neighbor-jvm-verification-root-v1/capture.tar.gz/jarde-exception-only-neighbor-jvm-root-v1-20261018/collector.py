from pathlib import Path
import json,hashlib,importlib.util,struct,shutil
r=Path('/Users/lordcasser/workspace/projects/jarde');o=Path('/private/tmp/jarde-exception-only-neighbor-jvm-root-v1-20261018');o.mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
prep=Path('/private/tmp/jarde-exception-only-tests-prep-20261017/generate_finallycompletion_neighbors.py');shutil.copyfile(prep,o/'generator-draft.py');m=load(o/'generator-draft.py','gen');b=(r/'tests/fixtures/recover-exception-only-finally-completion/sealed/javac8/FinallyCompletion.class').read_bytes();layout=m.target_code(b);variants=m.variants(b);changed=bytearray(variants['row-shrunk.class']);struct.pack_into('>H',changed,layout['exception_start']+2,9);variants['row-shrunk.class']=bytes(changed);positive=bytearray(b);struct.pack_into('>H',positive,layout['exception_start']+2,10);variants['binding-unprotected.class']=bytes(positive)
# Keep only the declared seven controls even if an agent later extends its private generator.
names=['row-shrunk.class','cleanup-protected.class','competing-row.class','wrong-rethrow-value.class','extra-normal-handler-entry.class','finally-explicit-return.class','binding-unprotected.class'];assert all(n in variants for n in names)
vpins={}
for n in names:
 p=o/'variants'/('variant-'+n[:-6])/'FinallyCompletion.class';p.parent.mkdir(parents=True);p.write_bytes(variants[n]);vpins[n]={'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
s=Path('/private/tmp/jarde-nested-fin-neighbor-verification-prep-20261017/VerifyNeighbors.java').read_text().replace('15','7').replace('EX.class','FinallyCompletion.class').replace('Class.forName("EX"','Class.forName("FinallyCompletion"').replace('"nestedFin", Integer.TYPE','"tryThrowsFinallyRuns"').replace('nestedFin','tryThrowsFinallyRuns').replace('tryThrowsFinallyRuns(I)I','tryThrowsFinallyRuns()I')
p=o/'VerifyNeighbors.java';p.write_text(s)
c=load(r/'openspec/changes/recover-return-through-nested-finally-cleanup/tools/compare.py','cmp');g=load(c.GUARD_PATH,'guard');sc=load(c.SCANNER_PATH,'scan');g.ROOT=r;g.OUT=o/'raw';g.OUT.mkdir();g.target_bytes=lambda:sc.target_bytes(r);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None;jdks,pins=c.configured_jdks(c.DEFAULT_JDK_MANIFEST,c.DEFAULT_JDK_MANIFEST_SHA256);classes=o/'verifier-classes';classes.mkdir()
x={'status':'running','variants':vpins,'input_sha256':hashlib.sha256(b).hexdigest(),'verifier':c.pin(p),'JDKs':pins,'commands':[]}
def cmd(argv,jdk):
 import os
 row=g.run_command(len(x['commands'])+1,argv,c.environment(dict(os.environ),jdk));x['commands'].append(row);(o/'execution.json').write_text(json.dumps(x,indent=2)+'\n');assert row['guard_stop'] is None and row['exit_code']==0,row
cmd([str(jdks['javac8']['tools']['javac']),'-source','8','-target','8','-g:none','-Xlint:-options','-d',str(classes),str(p)],jdks['javac8'])
for name,jdk in jdks.items():
 cmd([str(jdk['tools']['java']),'-Xverify:all','-cp',str(classes),'VerifyNeighbors',str(o/'variants')],jdk)
 text=Path(x['commands'][-1]['streams']['stdout']['path']).read_text();assert text.count('PASS variant-')==7 and 'VERIFIED 7 variants' in text
x['status']='14 strict JVM class verifications passed; targets not invoked';x['target_absent']=not(r/'target').exists();(o/'execution.json').write_text(json.dumps(x,indent=2)+'\n');shutil.copyfile('/private/tmp/jarde-exception-only-neighbor-jvm-root-v1-20261018.py',o/'collector.py');print(x['status'])
