import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Load, link, and reflect over each mutated EX without invoking tryThrowsFinallyRuns. */
public final class VerifyNeighbors {
    private VerifyNeighbors() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            throw new IllegalArgumentException("usage: VerifyNeighbors <variants-directory>");
        }
        Path root = Paths.get(args[0]).toAbsolutePath();
        List<Path> directories = new ArrayList<Path>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(root, "variant-*")) {
            for (Path path : stream) {
                if (Files.isDirectory(path)) {
                    directories.add(path);
                }
            }
        }
        Collections.sort(directories, new Comparator<Path>() {
            @Override
            public int compare(Path left, Path right) {
                return left.getFileName().toString().compareTo(right.getFileName().toString());
            }
        });
        if (directories.size() != 7) {
            throw new AssertionError("expected 7 variant directories, found " + directories.size());
        }

        System.out.println("java.version=" + System.getProperty("java.version"));
        int verified = 0;
        for (Path directory : directories) {
            Path classFile = directory.resolve("FinallyCompletion.class");
            byte[] bytes = Files.readAllBytes(classFile);
            URL[] urls = new URL[] { directory.toUri().toURL() };
            try (URLClassLoader loader = new URLClassLoader(urls, null)) {
                Class<?> type = Class.forName("FinallyCompletion", false, loader);
                Method target = type.getDeclaredMethod("tryThrowsFinallyRuns");
                if (target.getReturnType() != Integer.TYPE) {
                    throw new AssertionError(directory + ": tryThrowsFinallyRuns return type is not int");
                }
                // Resolving all declared methods and constructors forces class metadata and
                // verification/linking work while the method itself remains unexecuted.
                int methods = type.getDeclaredMethods().length;
                int constructors = type.getDeclaredConstructors().length;
                System.out.println("PASS " + directory.getFileName()
                        + " sha256=" + hex(sha256(bytes))
                        + " methods=" + methods
                        + " constructors=" + constructors
                        + " target=tryThrowsFinallyRuns()I not-invoked");
                verified++;
            }
        }
        if (verified != 7) {
            throw new AssertionError("verified " + verified + " of 7 variants");
        }
        System.out.println("VERIFIED " + verified + " variants");
    }

    private static byte[] sha256(byte[] bytes) throws NoSuchAlgorithmException {
        return MessageDigest.getInstance("SHA-256").digest(bytes);
    }

    private static String hex(byte[] bytes) {
        StringBuilder result = new StringBuilder(bytes.length * 2);
        for (byte value : bytes) {
            result.append(String.format("%02x", value & 0xff));
        }
        return result.toString();
    }
}
