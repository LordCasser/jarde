# Exception-only FinallyCompletion probe preparation

No shared workspace source remains changed. The patch is a temporary `#[cfg(test)]` diagnostic for `crates/jarde-java/src/guard.rs`: it inserts one test into `finally_copy_tests` and adds one `#[cfg(test)] eprintln!` at the `prove_finally_copy` split/save decision.

The test uses the existing `probe_descriptor` helper, which opens the sealed bytes and runs `analyze_method_ir`. It prints canonical completeness, blocks, edges, handler rows and throw sites; SSA phis/values plus per-instruction Operations, effect, reads and writes; generic `finally_copy_shape`; ordinary `exception_only_catch` plus its cleanup grammar result; `resources`; and the full `guard::examine` verdict with usage. The helper return records actual `prove_finally_copy`. The added print exposes the actual slices and lengths that derive `cleanup_start` and the save index, so the first refusal can be verified. All print additions to the proof function compile only under `cfg(test)` and do not change the recognizer.

Input pins verified with `shasum -a 256` and `wc -c`:

- javac8: 907 bytes, `49e649478c3d45ba6486029778a8415239caafdd93234a1d5956f5ccf3031393`
- javac23: 907 bytes, `2b8902d998065d2d1747abaeba386e006cdf5ff7f1311abb28506e8d8dc0cc94`

Original `crates/jarde-java/src/guard.rs` SHA-256 before preparation and after removing the transient insertion: `65c845697752e07e2857583e332fac88fa84397bc0986cbdd7f27bc5c30937c2`.

The test was not compiled or run, per task scope. The patch uses the repository's `apply_patch` format; apply its contents from the repository root, let the owning root task run the targeted test, then remove both temporary insertions. No Cargo/JDK/JADX/CLI/Git command was run.
