import pathlib,importlib.util,json,os,shutil,hashlib
R=pathlib.Path('/Users/lordcasser/workspace/projects/jarde');P=pathlib.Path('/private/tmp/jarde-seq1-field-copy-controls-prep-luna-v2-20261018');O=pathlib.Path('/private/tmp/jarde-field-copy-oracle-root-v2-20261018')
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(R/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','cmp');g=load(R/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py','guard');sc=load(R/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py','scanner')
j,pin=c.configured_jdks(R/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json','ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
assert not O.exists() and not (R/'target').exists();O.mkdir();(O/'raw').mkdir();(O/'empty').mkdir();(O/'driver').mkdir();(O/'inputs').mkdir()
for n,h in [('FieldWriteCopies.java','e809436b1e1cdc0232c4a2573641290f3b50f7d05a1d7cf1ea84fe95a13efd85'),('FieldWriteCopiesDriver.java','2e8311f2ec27aaecbabee73ab23a8056024fcbb4a1668ab8838ebffde8851d9b'),('FieldWriteCopyRefusals.java','b79a8fa7186f9286c5e65937b673946fd7b8fbcd9d29899757e99f3877f90287')]:
 assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h;shutil.copyfile(P/n,O/'inputs'/n)
g.ROOT=R;g.OUT=O/'raw';g.target_bytes=lambda:sc.target_bytes(R);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
r={'status':'running','collector':c.pin(pathlib.Path(__file__)),'jdk':pin,'commands':[],'profiles':[],'runtime':[],'input_pins':[c.pin(p) for p in sorted((O/'inputs').glob('*'))],'source_before':c.source_closure(R),'default_stack':True}
def save(): (O/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
def cmd(a,label,leg='javac23',expect=0):
 assert not (R/'target').exists() and shutil.disk_usage(R).free>=5*1024**3
 e=c.clean_env(dict(os.environ),j[leg]);e.update(g.ENV_VALUES);e.pop('RUST_MIN_STACK',None);row=g.run_command(len(r['commands'])+1,list(map(str,a)),e);row['label']=label;row['leg']=leg;r['commands'].append(row);save();assert row['exit_code']==expect and row['guard_stop'] is None;return row
try:
 for leg in ('javac8','javac23'):
  for debug in ('debug','no-debug'):
   root=O/(leg+'-'+debug);root.mkdir();flags=['-source','8','-target','8'] if leg=='javac8' else ['--release','8']
   cmd([j[leg]['tools']['javac'],*flags,'-g' if debug=='debug' else '-g:none','-encoding','UTF-8','-proc:none','-classpath',O/'empty','-sourcepath',O/'empty','-d',root,O/'inputs/FieldWriteCopies.java',O/'inputs/FieldWriteCopyRefusals.java'],'compile-'+root.name,leg)
   r['profiles'].append({'label':root.name,'root':str(root),'classes':[c.pin(p) for p in sorted(root.glob('*.class'))]})
 cmd([j['javac8']['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-classpath',O/'empty','-sourcepath',O/'empty','-d',O/'driver',O/'inputs/FieldWriteCopiesDriver.java'],'compile-driver','javac8')
 for profile in r['profiles']:
  for leg in ('javac8','javac23'):
   row=cmd(['python3','-B','/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py','30',j[leg]['tools']['java'],'-Xverify:all','-cp',O/'driver','FieldWriteCopiesDriver','FieldWriteCopies',profile['root']],'runtime-'+profile['label']+'-'+leg,leg)
   stdout=c.command_artifact(row,'stdout');r['runtime'].append({'profile':profile['label'],'leg':leg,'command':row['index'],'stdout_sha256':hashlib.sha256(stdout).hexdigest()})
   if 'oracle' not in r:(O/'oracle.stdout').write_bytes(stdout);r['oracle']=c.pin(O/'oracle.stdout')
   assert stdout==(O/'oracle.stdout').read_bytes();save()
 r['status']='original_oracle_captured_pending_review'
except BaseException as error:
 r['status']='failed';r['error']=str(error);raise
finally:
 r['source_after']=c.source_closure(R);r['source_unchanged']=r['source_before']==r['source_after'];r['target_absent']=not (R/'target').exists();assert r['source_unchanged'] and r['target_absent'];save()
print(json.dumps({k:r[k] for k in ('status','oracle','source_unchanged','target_absent')}))
