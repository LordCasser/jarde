#!/usr/bin/env python3
"""Independent read-only review for the FieldWriteCopies original JVM oracle capture."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
OUT_DEFAULT = Path('/private/tmp/jarde-field-copy-oracle-root-v2-20261018')
INPUT_DIR = Path('/private/tmp/jarde-seq1-field-copy-controls-prep-luna-v2-20261018')
PARSER_PATH = Path('/private/tmp/jarde-testnestedloops5-parameterized-review-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA256 = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
COLLECTOR_PATH = Path('/private/tmp/jarde-field-copy-oracle-prep-root-v3-20261018/collect.py')
COLLECTOR_SHA256 = '9b7a4c912dae1714f8e1668d6006e02d845755987d240ba95e5fcc47e6acd4f8'
RUNTIME_PATH = Path('/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
RUNTIME_SHA256 = '73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
JDK_MANIFEST = ROOT / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
COMPARE = ROOT / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
GUARD = ROOT / 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
INPUT_SHA256 = {
    'FieldWriteCopies.java': 'e809436b1e1cdc0232c4a2573641290f3b50f7d05a1d7cf1ea84fe95a13efd85',
    'FieldWriteCopiesDriver.java': '2e8311f2ec27aaecbabee73ab23a8056024fcbb4a1668ab8838ebffde8851d9b',
    'FieldWriteCopyRefusals.java': 'b79a8fa7186f9286c5e65937b673946fd7b8fbcd9d29899757e99f3877f90287',
}
PROFILES = ('javac8-debug', 'javac8-no-debug', 'javac23-debug', 'javac23-no-debug')
LEGS = ('javac8', 'javac23')
PRIMARY_FIELDS = {
    ('z', 'I', 0x41), ('calls', 'I', 0x01), ('ledger', 'J', 0x01),
    ('throwAt', 'I', 0x01), ('marker', 'Ljava/lang/RuntimeException;', 0x11),
    ('lastValue', 'I', 0x01),
}
PRIMARY_METHODS = {
    ('<init>', '()V', 0x01), ('next', '(I)I', 0x02),
    ('assignAndCompare', '(I)Z', 0x01), ('statefulWhile', '(I)I', 0x01),
}
REFUSAL_FIELDS = {
    ('z', 'I', 0x41), ('flag', 'Z', 0x01), ('calls', 'I', 0x01),
    ('throwAt', 'I', 0x01), ('marker', 'Ljava/lang/RuntimeException;', 0x11),
}
REFUSAL_METHODS = {
    ('<init>', '()V', 0x01), ('next', '(I)I', 0x02),
    ('differentReceiver', '(LFieldWriteCopyRefusals;I)Z', 0x01),
    ('nonIntField', '(ZZ)Z', 0x01), ('handledAssignment', '(I)Z', 0x01),
}
EXPECTED_OUTPUT_PREFIXES = (
    'direct-first result=', 'direct-first-state ',
    'direct-same-instance result=', 'direct-same-instance-state ',
    'direct-throw sameMarker=', 'direct-throw-state ',
    'while-complete result=', 'while-complete-state ',
    'while-throw sameMarker=', 'while-throw-state ',
)


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha_bytes(data)}


def verify_pin(record: dict, label: str) -> bytes:
    path = Path(record.get('path', ''))
    need(path.is_absolute() and path.is_file(), f'{label}: missing absolute path {path}')
    data = path.read_bytes()
    need(len(data) == record.get('bytes') and sha_bytes(data) == record.get('sha256'),
         f'{label}: bytes/SHA-256 differ from recorded pin')
    return data


def load_helper(path: Path):
    spec = importlib.util.spec_from_file_location('field_copy_classfile_helper', path)
    need(spec is not None and spec.loader is not None, f'cannot load classfile helper at {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def fresh_source_closure(root: Path) -> dict:
    candidates = [root / 'Cargo.toml', root / 'Cargo.lock']
    for name in ('src', 'crates', 'tests', 'openspec/changes/recover-exception-only-finally-completion'):
        directory = root / name
        if directory.exists():
            for current, dirs, files in os.walk(directory):
                dirs[:] = sorted(d for d in dirs if d not in {'.git', 'target', '__pycache__'})
                for filename in sorted(files):
                    path = Path(current) / filename
                    if path.is_file() and not path.is_symlink():
                        candidates.append(path)
    result = {}
    for path in sorted(set(candidates)):
        if path.is_file() and not path.is_symlink():
            result[path.relative_to(root).as_posix()] = pin(path)
    return result


def parse_constant_pool(data: bytes) -> list:
    need(len(data) >= 10 and data[:4] == b'\xca\xfe\xba\xbe', 'bad/truncated classfile')
    pos = 8

    def take(size: int) -> bytes:
        nonlocal pos
        value = data[pos:pos + size]
        need(len(value) == size, 'truncated classfile constant pool')
        pos += size
        return value

    count = int.from_bytes(take(2), 'big')
    cp = [None] * count
    index = 1
    while index < count:
        tag = take(1)[0]
        if tag == 1:
            cp[index] = ('utf8', take(int.from_bytes(take(2), 'big')).decode('utf-8', errors='strict'))
        elif tag in (3, 4):
            take(4)
        elif tag in (5, 6):
            take(8); index += 1
        elif tag in (7, 8, 16, 19, 20):
            cp[index] = (tag, int.from_bytes(take(2), 'big'))
        elif tag in (9, 10, 11, 12, 17, 18):
            cp[index] = (tag, int.from_bytes(take(2), 'big'), int.from_bytes(take(2), 'big'))
        elif tag == 15:
            cp[index] = (tag, take(1)[0], int.from_bytes(take(2), 'big'))
        else:
            raise ValueError(f'unknown constant-pool tag {tag}')
        index += 1
    return cp


def cp_utf(cp: list, index: int) -> str:
    entry = cp[index]
    need(entry is not None and entry[0] == 'utf8', f'constant pool index {index} is not UTF8')
    return entry[1]


def cp_class(cp: list, index: int) -> str:
    entry = cp[index]
    need(entry is not None and entry[0] == 7, f'constant pool index {index} is not Class')
    return cp_utf(cp, entry[1])


def cp_name_type(cp: list, index: int) -> tuple[str, str]:
    entry = cp[index]
    need(entry is not None and entry[0] == 12, f'constant pool index {index} is not NameAndType')
    return cp_utf(cp, entry[1]), cp_utf(cp, entry[2])


def cp_member(cp: list, index: int) -> tuple[str, str, str, int]:
    entry = cp[index]
    need(entry is not None and entry[0] in (9, 10, 11), f'constant pool index {index} is not a member reference')
    name, descriptor = cp_name_type(cp, entry[2])
    return cp_class(cp, entry[1]), name, descriptor, entry[0]


def instructions(method: dict) -> tuple[bytes, list[int], dict[int, int]]:
    code = method.get('code')
    need(isinstance(code, dict), f'{method.get("name")}{method.get("descriptor")}: missing Code attribute')
    raw = bytes.fromhex(code['code_hex'])
    need(len(raw) == code['code_length'], f'{method["name"]}: Code length mismatch')
    bcis = code['bcis']
    need(bcis and bcis == sorted(set(bcis)) and bcis[0] == 0, f'{method["name"]}: malformed BCI census')
    need(bcis == decode_bcis(raw), f'{method["name"]}: BCI census differs from encoded code')
    return raw, bcis, {bci: i for i, bci in enumerate(bcis)}


def decode_bcis(code: bytes) -> list[int]:
    fixed = {0x10: 2, 0x11: 3, 0x12: 2, 0x13: 3, 0x14: 3, 0x15: 2, 0x16: 2, 0x17: 2,
             0x18: 2, 0x19: 2, 0x36: 2, 0x37: 2, 0x38: 2, 0x39: 2, 0x3a: 2, 0x84: 3,
             0xa9: 2, 0xbc: 2, 0xc5: 4, 0xb2: 3, 0xb3: 3, 0xb4: 3, 0xb5: 3, 0xb6: 3,
             0xb7: 3, 0xb8: 3, 0xbb: 3, 0xbd: 3, 0xc0: 3, 0xc1: 3, 0xb9: 5, 0xba: 5,
             0xc8: 5, 0xc9: 5}
    fixed.update({op: 3 for op in range(0x99, 0xa9)})
    fixed.update({0xc6: 3, 0xc7: 3})
    bcis, pc = [], 0
    while pc < len(code):
        bcis.append(pc)
        opcode = code[pc]
        if opcode == 0xaa:
            aligned = (pc + 4) & ~3
            need(aligned + 12 <= len(code), f'truncated tableswitch at {pc}')
            low = int.from_bytes(code[aligned + 4:aligned + 8], 'big', signed=True)
            high = int.from_bytes(code[aligned + 8:aligned + 12], 'big', signed=True)
            need(high >= low, f'invalid tableswitch at {pc}')
            size = aligned - pc + 12 + 4 * (high - low + 1)
        elif opcode == 0xab:
            aligned = (pc + 4) & ~3
            need(aligned + 8 <= len(code), f'truncated lookupswitch at {pc}')
            pairs = int.from_bytes(code[aligned + 4:aligned + 8], 'big', signed=True)
            need(pairs >= 0, f'invalid lookupswitch at {pc}')
            size = aligned - pc + 8 + 8 * pairs
        elif opcode == 0xc4:
            need(pc + 1 < len(code), f'truncated wide at {pc}')
            size = 6 if code[pc + 1] == 0x84 else 4
        else:
            size = fixed.get(opcode, 1)
        need(pc + size <= len(code), f'instruction at {pc} exceeds Code')
        pc += size
    return bcis


def method_map(facts: dict) -> dict[tuple[str, str], dict]:
    return {(m['name'], m['descriptor']): m for m in facts['methods']}


def field_rows(facts: dict) -> set[tuple[str, str, int]]:
    return {(f['name'], f['descriptor'], f['access']) for f in facts['fields']}


def method_rows(facts: dict) -> set[tuple[str, str, int]]:
    return {(m['name'], m['descriptor'], m['access']) for m in facts['methods']}


def target_class_record(profile: dict, simple_name: str, parser) -> tuple[dict, dict]:
    records = [row for row in profile['classes'] if Path(row['path']).name == simple_name + '.class']
    need(len(records) == 1, f'{profile["label"]}: expected exactly one {simple_name}.class pin')
    record = records[0]
    data = verify_pin(record, f'{profile["label"]}/{simple_name}')
    facts = parser.parse_class_file(data)
    need(facts['major'] == 52 and facts['minor'] == 0, f'{profile["label"]}/{simple_name}: expected Java 8 class version 52.0')
    need(Path(record['path']).resolve() == (Path(profile['root']) / (simple_name + '.class')).resolve(),
         f'{profile["label"]}/{simple_name}: class path is outside profile output root')
    need(all(m['code'] is not None for m in facts['methods']), f'{profile["label"]}/{simple_name}: method without Code')
    for method in facts['methods']:
        _, bcis, _ = instructions(method)
        code = method['code']
        for start, end, handler, catch_index in code['rows']:
            need(0 <= start < end <= code['code_length'] and handler in bcis,
                 f'{profile["label"]}/{simple_name}/{method["name"]}: malformed exception table row')
            need(catch_index >= 0, 'negative exception catch index')
    return record, facts


def operation_records(method: dict, cp: list) -> list[dict]:
    code, bcis, _ = instructions(method)
    result = []
    for bci in bcis:
        opcode = code[bci]
        row = {'bci': bci, 'opcode': opcode}
        if opcode in (0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba):
            cp_index = int.from_bytes(code[bci + 1:bci + 3], 'big')
            row['member'] = cp_member(cp, cp_index)
        if 0x99 <= opcode <= 0xa8 or opcode in (0xc6, 0xc7):
            offset = int.from_bytes(code[bci + 1:bci + 3], 'big', signed=True)
            row['branch_target'] = bci + offset
        elif opcode in (0xc8, 0xc9):
            offset = int.from_bytes(code[bci + 1:bci + 5], 'big', signed=True)
            row['branch_target'] = bci + offset
        result.append(row)
    return result


def verify_copy_shape(facts: dict, expected: dict, profile: str, parser) -> dict:
    class_path = Path(expected['path'])
    data = class_path.read_bytes()
    cp = parse_constant_pool(data)
    methods = method_map(facts)
    findings = {}
    for method_name, literal in (('assignAndCompare', 5), ('statefulWhile', 3)):
        method = methods[(method_name, '(I)Z' if method_name == 'assignAndCompare' else '(I)I')]
        code, bcis, index_of = instructions(method)
        ops = operation_records(method, cp)
        next_calls = [op for op in ops if op['opcode'] in (0xb6, 0xb7, 0xb8)
                      and op.get('member', (None, None, None, None))[:3]
                      == ('FieldWriteCopies', 'next', '(I)I')]
        need(len(next_calls) == 1, f'{profile}/{method_name}: expected one physical call to next(I)I')
        call = next_calls[0]
        call_pos = index_of[call['bci']]
        need(call_pos + 4 < len(bcis), f'{profile}/{method_name}: copy/compare sequence is truncated')
        copy_bci, put_bci, const_bci, compare_bci = bcis[call_pos + 1:call_pos + 5]
        need(code[copy_bci] == 0x5a, f'{profile}/{method_name}: next result is not followed by dup_x1 at {copy_bci}')
        need(code[put_bci] == 0xb5, f'{profile}/{method_name}: dup_x1 is not followed by putfield at {put_bci}')
        put_index = int.from_bytes(code[put_bci + 1:put_bci + 3], 'big')
        field_ref = cp_member(cp, put_index)
        need(field_ref == ('FieldWriteCopies', 'z', 'I', 9),
             f'{profile}/{method_name}: copy writes an unexpected field reference {field_ref}')
        expected_iconst = 0x03 + literal  # ICONST_0 is 0x03, so 3->0x06 and 5->0x08.
        need(code[const_bci] == expected_iconst,
             f'{profile}/{method_name}: expected literal {literal} directly after field write')
        need(code[compare_bci] == 0xa2, f'{profile}/{method_name}: literal does not feed if_icmpge comparison')
        compare_op = next(op for op in ops if op['bci'] == compare_bci)
        need(compare_op['branch_target'] in set(bcis), f'{profile}/{method_name}: comparison target is not an instruction boundary')
        z_accesses = [op for op in ops if op.get('member', (None, None, None, None))[:3]
                      == ('FieldWriteCopies', 'z', 'I')]
        need(len(z_accesses) == 1 and z_accesses[0]['opcode'] == 0xb5,
             f'{profile}/{method_name}: target field is read or written more than once in the expression')
        record = {'invoke_bci': call['bci'], 'invoke_opcode': call['opcode'], 'dup_x1_bci': copy_bci,
                  'putfield_bci': put_bci, 'putfield': {'owner': field_ref[0], 'name': field_ref[1],
                                                       'descriptor': field_ref[2]},
                  'literal_bci': const_bci, 'literal': literal, 'compare_bci': compare_bci,
                  'compare_opcode': 'if_icmpge', 'branch_target': compare_op['branch_target'],
                  'z_field_accesses': len(z_accesses)}
        if method_name == 'statefulWhile':
            backwards = [op for op in ops if op['opcode'] in (0xa7, 0xa8, 0xc8, 0xc9)
                         and op.get('branch_target', op['bci']) < op['bci']]
            need(any(op['branch_target'] <= call['bci'] for op in backwards),
                 f'{profile}/statefulWhile: no backward transfer closes around condition')
            record['back_edges'] = [{'bci': op['bci'], 'target': op['branch_target']} for op in backwards]
        else:
            need(not method['code']['rows'], f'{profile}/assignAndCompare: unexpected exception handler')
        findings[method_name] = record
    return findings


def verify_refusal_shapes(facts: dict, class_path: Path, profile: str) -> dict:
    cp = parse_constant_pool(class_path.read_bytes())
    methods = method_map(facts)
    findings = {}
    diff = methods[('differentReceiver', '(LFieldWriteCopyRefusals;I)Z')]
    diff_ops = operation_records(diff, cp)
    next_calls = [op for op in diff_ops if op['opcode'] in (0xb6, 0xb7, 0xb8)
                  and op.get('member', (None, None, None, None))[:3] == ('FieldWriteCopyRefusals', 'next', '(I)I')]
    stores = [op for op in diff_ops if op['opcode'] == 0xb5 and op.get('member', (None, None, None, None))[:3]
              == ('FieldWriteCopyRefusals', 'z', 'I')]
    need(len(next_calls) == 1 and len(stores) == 1 and diff['code']['rows'] == [],
         f'{profile}: different-receiver control lacks its complete non-handler copy/store shape')
    findings['differentReceiver'] = {'next_calls': [op['bci'] for op in next_calls],
                                     'z_putfield': [op['bci'] for op in stores],
                                     'method_descriptor': diff['descriptor']}

    non_int = methods[('nonIntField', '(ZZ)Z')]
    non_int_ops = operation_records(non_int, cp)
    bool_stores = [op for op in non_int_ops if op['opcode'] == 0xb5
                   and op.get('member', (None, None, None, None))[:3] == ('FieldWriteCopyRefusals', 'flag', 'Z')]
    bool_compares = [op for op in non_int_ops if op['opcode'] in (0xa0, 0xa1)]
    need(len(bool_stores) == 1 and len(bool_compares) == 1,
         f'{profile}: non-int control does not assign boolean field then compare')
    findings['nonIntField'] = {'flag_putfield_bci': bool_stores[0]['bci'],
                               'compare_bci': bool_compares[0]['bci'],
                               'compare_opcode': bool_compares[0]['opcode']}

    handled = methods[('handledAssignment', '(I)Z')]
    handled_ops = operation_records(handled, cp)
    handled_calls = [op for op in handled_ops if op['opcode'] in (0xb6, 0xb7, 0xb8)
                     and op.get('member', (None, None, None, None))[:3]
                     == ('FieldWriteCopyRefusals', 'next', '(I)I')]
    rows = handled['code']['rows']
    need(len(handled_calls) == 1 and len(rows) == 1, f'{profile}: handler control lacks one protected call/handler row')
    start, end, handler_bci, catch_index = rows[0]
    need(start <= handled_calls[0]['bci'] < end and handler_bci in handled['code']['bcis'],
         f'{profile}: exception range does not cover next call or handler is not a BCI')
    catch_class = cp_class(cp, catch_index) if catch_index else None
    need(catch_class == 'java/lang/RuntimeException', f'{profile}: handler catch type differs: {catch_class}')
    findings['handledAssignment'] = {'next_bci': handled_calls[0]['bci'], 'exception_row': rows[0],
                                     'catch_type': catch_class}
    return findings


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--execution', type=Path, default=OUT_DEFAULT / 'execution.json')
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    execution_path = args.execution.resolve(strict=True)
    out = execution_path.parent
    root = args.root.resolve(strict=True)
    output = args.out.resolve()
    need(not output.exists(), f'review output already exists: {output}')
    execution = json.loads(execution_path.read_text(encoding='utf-8'))
    need(execution.get('status') == 'original_oracle_captured_pending_review',
         f'capture is not at reviewable terminal status: {execution.get("status")}')
    need(execution.get('default_stack') is True, 'collector did not confirm the default RUST_MIN_STACK configuration')
    need(execution.get('source_unchanged') is True, 'collector source closure changed during run')
    need(execution.get('target_absent') is True, 'collector did not confirm target absent at capture end')
    target_exists_now = (root / 'target').exists()

    collector_pin = pin(COLLECTOR_PATH)
    need(collector_pin['sha256'] == COLLECTOR_SHA256 and execution.get('collector') == collector_pin,
         'receipt is not bound to the inspected root collector v3')
    parser_pin = pin(PARSER_PATH)
    need(parser_pin['sha256'] == PARSER_SHA256, 'accepted full classfile helper pin differs')
    parser = load_helper(PARSER_PATH)
    runtime_pin = pin(RUNTIME_PATH)
    need(runtime_pin['sha256'] == RUNTIME_SHA256, '30-second runtime guard pin differs')
    need(pin(JDK_MANIFEST)['sha256'] == JDK_MANIFEST_SHA256, 'JDK manifest pin differs')
    manifest = json.loads(JDK_MANIFEST.read_text(encoding='utf-8'))
    jdk_tools = {}
    for leg in LEGS:
        manifest_leg = next((row for row in manifest['legs'] if row['leg'] == leg), None)
        need(manifest_leg is not None, f'JDK manifest is missing {leg}')
        jdk_tools[leg] = {}
        for tool in ('java', 'javac', 'javap'):
            item = execution['jdk']['tools'][leg][tool]
            expected = manifest_leg['jdk_tools'][tool]
            need(Path(item['path']).resolve() == Path(expected['path']).resolve()
                 and item['sha256'] == expected['sha256'], f'{leg}/{tool}: receipt differs from JDK manifest')
            need(pin(Path(item['path'])) == item, f'{leg}/{tool}: installed executable differs from recorded pin')
            jdk_tools[leg][tool] = str(Path(item['path']).resolve())

    compare_source = ROOT / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
    guard_source = ROOT / 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
    scanner_source = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
    need(sha_bytes(compare_source.read_bytes()) == execution['source_before']['openspec/changes/recover-exception-only-finally-completion/tools/compare.py']['sha256'],
         'compare helper is not covered by source closure pin')
    need(sha_bytes(guard_source.read_bytes()) == GUARD_SHA256 and sha_bytes(scanner_source.read_bytes()) == SCANNER_SHA256,
         'guard/scanner source pin differs')
    source_before = execution.get('source_before')
    source_after = execution.get('source_after')
    current_source = fresh_source_closure(root)
    need(isinstance(source_before, dict) and source_before == source_after,
         'workspace source closure changed during the captured original oracle run')
    added_since_capture = sorted(set(current_source) - set(source_after))
    removed_since_capture = sorted(set(source_after) - set(current_source))
    changed_since_capture = sorted(key for key in set(source_after) & set(current_source)
                                   if source_after[key] != current_source[key])

    source_pins = {}
    expected_input_paths = {
        name: INPUT_DIR / name for name in INPUT_SHA256
    }
    for name, path in expected_input_paths.items():
        need(sha_bytes(path.read_bytes()) == INPUT_SHA256[name], f'frozen source pin differs: {name}')
        source_pins[name] = pin(path)
    captured_inputs = {Path(row['path']).name: row for row in execution.get('input_pins', [])}
    need(set(captured_inputs) == set(INPUT_SHA256), 'capture does not contain all three complete source inputs')
    for name, path in expected_input_paths.items():
        captured_pin = pin(out / 'inputs' / name)
        source_pin = pin(path)
        need(captured_inputs[name] == captured_pin and captured_pin['bytes'] == source_pin['bytes']
             and captured_pin['sha256'] == source_pin['sha256'], f'{name}: copied input bytes differ')

    commands = execution.get('commands')
    need(isinstance(commands, list) and len(commands) == 13, 'capture must contain exactly 13 commands')
    by_index, by_label, raw_count = {}, {}, 0
    expected_env = {
        'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
        'CARGO_PROFILE_TEST_DEBUG': '0', 'RUST_TEST_THREADS': '1', 'CARGO_TERM_COLOR': 'always',
    }
    for index, row in enumerate(commands, 1):
        label = row.get('label')
        need(row.get('index') == index and label not in by_label, f'command index/label is duplicate or out of sequence: {index}/{label}')
        need(Path(row['cwd']).resolve() == root and row.get('guard_stop') is None,
             f'{label}: unexpected cwd or guard stop')
        need(row.get('peak_target_bytes') == 0 and row.get('free_bytes_after', 0) >= 5 * 1024**3,
             f'{label}: target size/free space guard differs')
        need(row.get('env_overrides') == expected_env and 'RUST_MIN_STACK' not in row['env_overrides'],
             f'{label}: default-stack build environment differs')
        streams = row.get('streams', {})
        need(set(streams) == {'stdout', 'stderr'}, f'{label}: stdout/stderr raw pins missing')
        for stream_name, record in streams.items():
            data = verify_pin(record, f'{label}/{stream_name}')
            need(Path(record['path']) == out / 'raw' / f'{index}.{stream_name}.raw',
                 f'{label}/{stream_name}: raw path differs from collector naming')
            raw_count += 1
        by_index[index] = row
        by_label[label] = row
    expected_labels = {f'compile-{profile}' for profile in PROFILES} | {'compile-driver'}
    expected_labels |= {f'runtime-{profile}-{leg}' for profile in PROFILES for leg in LEGS}
    need(set(by_label) == expected_labels and raw_count == 26,
         f'command matrix/raw count mismatch: labels={len(by_label)} raw={raw_count}')

    empty = out / 'empty'
    need(empty.is_dir() and not any(empty.iterdir()), 'compile empty classpath/sourcepath directory is not empty')
    profile_rows = execution.get('profiles', [])
    need(len(profile_rows) == 4 and {p['label'] for p in profile_rows} == set(PROFILES),
         'compiler profiles are not the four expected javac/debug combinations')
    facts_by_profile = {}
    class_files_by_profile = {}
    profile_reports = {}
    for profile in profile_rows:
        label = profile['label']
        root_dir = Path(profile['root']).resolve()
        expected_root = (out / label).resolve()
        need(root_dir == expected_root, f'{label}: output root differs from isolated capture directory')
        compile = by_label[f'compile-{label}']
        leg = 'javac8' if label.startswith('javac8-') else 'javac23'
        debug_flag = '-g:none' if label.endswith('-no-debug') else '-g'
        flags = ['-source', '8', '-target', '8'] if leg == 'javac8' else ['--release', '8']
        expected_argv = [jdk_tools[leg]['javac'], *flags, debug_flag, '-encoding', 'UTF-8', '-proc:none',
                         '-classpath', str(out / 'empty'), '-sourcepath', str(out / 'empty'), '-d', str(root_dir),
                         str(out / 'inputs/FieldWriteCopies.java'), str(out / 'inputs/FieldWriteCopyRefusals.java')]
        need(compile['argv'] == expected_argv and compile['leg'] == leg and compile['exit_code'] == 0,
             f'{label}: whole-source compiler argv/status mismatch')
        files = sorted(root_dir.rglob('*.class'))
        need([p.relative_to(root_dir).as_posix() for p in files]
             == ['FieldWriteCopies.class', 'FieldWriteCopyRefusals.class'],
             f'{label}: output is not exactly the complete positive/refusal class pair')
        need(len(profile['classes']) == 2, f'{label}: receipt class pins do not cover both complete classes')
        pair = {}
        for name, expected_fields, expected_methods in (
            ('FieldWriteCopies', PRIMARY_FIELDS, PRIMARY_METHODS),
            ('FieldWriteCopyRefusals', REFUSAL_FIELDS, REFUSAL_METHODS),
        ):
            matches = [x for x in profile['classes'] if Path(x['path']).name == name + '.class']
            need(len(matches) == 1, f'{label}: missing/duplicate class pin for {name}')
            record = matches[0]
            need(pin(Path(record['path'])) == record and Path(record['path']).resolve() == (root_dir / (name + '.class')).resolve(),
                 f'{label}/{name}: class pin/path differs')
            class_facts = parser.parse_class_file(Path(record['path']).read_bytes())
            need(class_facts['class_name'] == name and class_facts['major'] == 52 and class_facts['minor'] == 0,
                 f'{label}/{name}: class identity/version differs')
            need(class_facts['access'] == 0x31, f'{label}/{name}: class flags differ')
            need(field_rows(class_facts) == expected_fields, f'{label}/{name}: complete field identity/descriptor/flags differ')
            need(method_rows(class_facts) == expected_methods, f'{label}/{name}: complete method identity/descriptor/flags differ')
            need(all(m['code'] is not None for m in class_facts['methods']), f'{label}/{name}: not all methods contain Code')
            for method in class_facts['methods']:
                instructions(method)
                code = method['code']
                for start, end, handler, catch_type in code['rows']:
                    need(0 <= start < end <= code['code_length'] and handler in code['bcis'],
                         f'{label}/{name}/{method["name"]}: invalid exception table boundary')
            pair[name] = {'record': record, 'facts': class_facts}
        primary = pair['FieldWriteCopies']['facts']
        primary_sites = verify_copy_shape(primary, pair['FieldWriteCopies']['record'], label, parser)
        refusal_sites = verify_refusal_shapes(pair['FieldWriteCopyRefusals']['facts'],
                                              Path(pair['FieldWriteCopyRefusals']['record']['path']), label)
        facts_by_profile[label] = pair
        class_files_by_profile[label] = files
        profile_reports[label] = {'class_inventory': {
            name: {'fields': len(item['facts']['fields']), 'methods': len(item['facts']['methods']),
                   'method_code': {m['name'] + m['descriptor']: {
                       'code_length': m['code']['code_length'], 'instruction_count': len(m['code']['bcis']),
                       'bcis': m['code']['bcis'], 'exception_rows': m['code']['rows']}
                       for m in item['facts']['methods']}}
            for name, item in pair.items()},
            'positive_dup_x1_comparisons': primary_sites,
            'refusal_control_shapes': refusal_sites}

    # Check that debug metadata does not alter Code bytes/BCIs within one compiler profile.
    layout_checks = {}
    for compiler in ('javac8', 'javac23'):
        debug_facts = facts_by_profile[compiler + '-debug']
        no_debug_facts = facts_by_profile[compiler + '-no-debug']
        for class_name in ('FieldWriteCopies', 'FieldWriteCopyRefusals'):
            d_methods = method_map(debug_facts[class_name]['facts'])
            n_methods = method_map(no_debug_facts[class_name]['facts'])
            need(set(d_methods) == set(n_methods), f'{compiler}/{class_name}: debug method inventory differs')
            for key in d_methods:
                d_code, n_code = d_methods[key]['code'], n_methods[key]['code']
                need(d_code['code_hex'] == n_code['code_hex'] and d_code['bcis'] == n_code['bcis']
                     and d_code['rows'] == n_code['rows'],
                     f'{compiler}/{class_name}/{key}: debug/no-debug Code differs')
        layout_checks[compiler] = True
    cross_compiler_layout = {}
    reference = facts_by_profile['javac8-debug']
    for label, pair in facts_by_profile.items():
        for class_name in ('FieldWriteCopies', 'FieldWriteCopyRefusals'):
            ref_methods = method_map(reference[class_name]['facts'])
            current_methods = method_map(pair[class_name]['facts'])
            for key, ref_method in ref_methods.items():
                method = current_methods[key]
                ref_code, code = ref_method['code'], method['code']
                need(ref_code['code_length'] == code['code_length'] and ref_code['bcis'] == code['bcis'],
                     f'{label}/{class_name}/{key}: compiler profile changes physical instruction/BCI layout')
                cross_compiler_layout[f'{label}/{class_name}/{key[0]}{key[1]}'] = len(code['bcis'])

    driver_compile = by_label['compile-driver']
    driver_root = out / 'driver'
    expected_driver_argv = [jdk_tools['javac8']['javac'], '-source', '8', '-target', '8', '-g', '-encoding', 'UTF-8',
                            '-proc:none', '-classpath', str(empty), '-sourcepath', str(empty), '-d', str(driver_root),
                            str(out / 'inputs/FieldWriteCopiesDriver.java')]
    need(driver_compile['argv'] == expected_driver_argv and driver_compile['exit_code'] == 0
         and driver_compile['leg'] == 'javac8', 'driver is not separately compiled with an empty classpath/sourcepath')
    driver_class = driver_root / 'FieldWriteCopiesDriver.class'
    driver_facts = parser.parse_class_file(driver_class.read_bytes())
    need(driver_facts['class_name'] == 'FieldWriteCopiesDriver' and driver_facts['major'] == 52,
         'driver class identity/Java 8 version differs')
    need([p.relative_to(driver_root).as_posix() for p in driver_root.rglob('*.class')]
         == ['FieldWriteCopiesDriver.class'],
         'driver output root contains unexpected classes')

    # Confirm that the pinned Java driver itself enforces target CodeSource and exact thrown-object identity.
    driver_text = (out / 'inputs/FieldWriteCopiesDriver.java').read_text(encoding='utf-8')
    for fragment in ('new URLClassLoader(new URL[] { targetUrl }, null)', 'target CodeSource mismatch',
                     'failure == expectedMarker', 'failure == loopMarker',
                     'failed RHS must leave the prior field value intact',
                     'second loop RHS failure must retain first completed write'):
        need(fragment in driver_text, f'driver source lost required isolation/assertion fragment: {fragment}')

    oracle_record = execution.get('oracle')
    need(isinstance(oracle_record, dict), 'capture has no original oracle pin')
    oracle = verify_pin(oracle_record, 'captured original JVM oracle')
    need(Path(oracle_record['path']).resolve() == (out / 'oracle.stdout').resolve(), 'oracle path differs from capture output')
    oracle_text = oracle.decode('utf-8', errors='strict')
    oracle_lines = oracle_text.splitlines()
    need(len(oracle_lines) == len(EXPECTED_OUTPUT_PREFIXES), 'oracle line count differs from the standalone driver case set')
    need(all(line.startswith(prefix) for line, prefix in zip(oracle_lines, EXPECTED_OUTPUT_PREFIXES)),
         'oracle case labels/order differ from the standalone driver')
    direct_throw = next(line for line in oracle_lines if line.startswith('direct-throw sameMarker='))
    direct_match = re.search(r'\bsameMarker=true\s+oldZ=(-?\d+)\s+actualZ=(-?\d+)$', direct_throw)
    need(direct_match is not None and direct_match.group(1) == direct_match.group(2),
         'oracle lacks exact direct marker assertion / unchanged old field value')
    while_throw = next(line for line in oracle_lines if line.startswith('while-throw sameMarker='))
    need('sameMarker=true' in while_throw and re.search(r'\bz=1$', while_throw) is not None,
         'oracle lacks exact loop marker assertion / preserved first completed write')
    runtimes = execution.get('runtime', [])
    need(len(runtimes) == 8, f'expected 8 original JVM observations, got {len(runtimes)}')
    seen = set()
    for cell in runtimes:
        key = (cell['profile'], cell['leg'])
        need(key not in seen and key[0] in PROFILES and key[1] in LEGS, f'duplicate/unexpected runtime cell {key}')
        seen.add(key)
        row = by_label[f'runtime-{key[0]}-{key[1]}']
        need(cell['command'] == row['index'] and row['exit_code'] == 0 and row['leg'] == key[1],
             f'{key}: runtime command/status mismatch')
        argv = row['argv']
        target_root = str((out / key[0]).resolve())
        cp = str(driver_root.resolve())
        need(argv == ['python3', '-B', str(RUNTIME_PATH), '30', jdk_tools[key[1]]['java'],
                      '-Xverify:all', '-cp', cp, 'FieldWriteCopiesDriver', 'FieldWriteCopies', target_root],
             f'{key}: runtime argv is not the pinned isolated 30-second JVM invocation')
        need('--' not in argv, f'{key}: unexpected option terminator in runtime command')
        stdout = verify_pin(row['streams']['stdout'], f'{key} runtime stdout')
        stderr = verify_pin(row['streams']['stderr'], f'{key} runtime stderr')
        need(stdout == oracle and not stderr and cell['stdout_sha256'] == sha_bytes(stdout),
             f'{key}: raw runtime output differs from the captured oracle or stderr is nonempty')
        need(all(line.startswith(prefix) for line, prefix in zip(
            stdout.decode('utf-8', errors='strict').splitlines(), EXPECTED_OUTPUT_PREFIXES)),
             f'{key}: output case labels/order differ from driver')
    need(seen == {(p, leg) for p in PROFILES for leg in LEGS}, 'JVM profile matrix incomplete')
    need(execution.get('default_stack') is True and all('RUST_MIN_STACK' not in row['env_overrides'] for row in commands),
         'default Rust stack was not preserved')

    result = {
        'schema': 'field-write-copy-original-oracle-independent-review-v1',
        'execution': pin(execution_path),
        'status': 'reviewed',
        'checks': {
            'commands': {'count': 13, 'raw_streams': raw_count, 'labels_complete': True,
                         'all_guard_stops_clear': True, 'target_absent_at_capture': True,
                         'target_exists_at_review_time': target_exists_now, 'default_stack': True},
            'inputs': {'three_frozen_sources': source_pins, 'source_closure_equal_before_after_capture': True,
                       'current_workspace_delta_after_capture': {'added': added_since_capture,
                                                                  'removed': removed_since_capture,
                                                                  'changed': changed_since_capture}},
            'jdk_tools_pinned': True,
            'class_profiles': profile_reports,
            'debug_metadata_code_parity': layout_checks,
            'cross_compiler_physical_bci_parity': cross_compiler_layout,
            'driver': {'separate_class_root': str(driver_root.resolve()), 'class_name': driver_facts['class_name'],
                       'major': driver_facts['major'], 'parentless_target_loader_and_exact_marker_assertions': True},
            'original_oracle': {'sha256': sha_bytes(oracle), 'bytes': len(oracle), 'line_count': len(oracle_lines),
                                'runtime_cells': len(runtimes), 'all_runtime_outputs_equal': True,
                                'observed_stdout': oracle_text},
        },
    }
    output.mkdir(parents=True)
    report = output / 'review.json'
    report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': 'reviewed', 'review': str(report), 'commands': 13,
                      'raw_streams': raw_count, 'profiles': len(profile_rows), 'runtime_cells': len(runtimes),
                      'oracle_lines': len(oracle_lines), 'dup_x1_profiles_checked': len(profile_rows)}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
