#!/usr/bin/env python3
"""Unexecuted guarded capture for the FieldWriteCopies dup neighbor."""
from __future__ import annotations
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
PREP = Path('/private/tmp/jarde-field-copy-extra-stack-copy-prep-root-v2-20261018')
INPUT = ROOT / 'tests/fixtures/recover-field-write-test-copies/javac8-debug/classes/FieldWriteCopies.class'
INPUT_SHA = '378fdbe1e8bcc06b163feb34d364e7a49358f70fb645e3b37a80620e89555a1a'
GENERATOR = PREP / 'generate.py'
DRIVER = PREP / 'ExtraStackCopyDriver.java'
PARSER = Path('/private/tmp/jarde-seq1-supplement-collector-prep-luna-v1-20261018/helpers/accepted-classfile-parser.py')
PARSER_SHA = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
COMPARE_REL = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
RUNTIME = Path('/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
RUNTIME_SHA = '73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
LEGS = ('javac8', 'javac23')


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def write_json(path: Path, value) -> None:
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temp.replace(path)


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module


def tree_pins(directory: Path) -> dict:
    return {p.relative_to(directory).as_posix(): pin(p)
            for p in sorted(directory.rglob('*')) if p.is_file()}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    root = args.root.resolve(strict=True); out = args.out.resolve()
    if root != ROOT.resolve(): raise SystemExit(f'unexpected workspace root: {root}')
    if out.exists(): raise SystemExit(f'refusing existing output: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink(): raise SystemExit('workspace target must be absent')

    generator_sha = sha(GENERATOR); driver_sha = sha(DRIVER)
    if sha(INPUT) != INPUT_SHA: raise SystemExit('frozen class input changed')
    if sha(PARSER) != PARSER_SHA or sha(RUNTIME) != RUNTIME_SHA: raise SystemExit('parser/runtime pin mismatch')
    manifest = root / JDK_MANIFEST_REL
    if sha(manifest) != JDK_MANIFEST_SHA: raise SystemExit('JDK manifest pin mismatch')
    compare_path = root / COMPARE_REL; guard_path = root / GUARD_REL; scanner_path = root / SCANNER_REL
    if sha(guard_path) != GUARD_SHA or sha(scanner_path) != SCANNER_SHA: raise SystemExit('guard/scanner pin mismatch')
    compare = load(compare_path, 'field_neighbor_compare')
    guard = load(guard_path, 'field_neighbor_guard')
    scanner = load(scanner_path, 'field_neighbor_scanner')
    class_parser = load(PARSER, 'field_neighbor_class_parser')
    jdks, jdk_pin = compare.configured_jdks(manifest, JDK_MANIFEST_SHA)
    if shutil.disk_usage(root).free < 5 * 1024**3: raise SystemExit('5 GiB free-space guard failed')

    out.mkdir(parents=True); raw_dir = out / 'raw'; raw_dir.mkdir()
    guard.ROOT = root; guard.OUT = raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, stdout: None
    inputs = out / 'inputs'; inputs.mkdir()
    original_copy = inputs / INPUT.name; shutil.copy2(INPUT, original_copy)
    generator_copy = inputs / GENERATOR.name; shutil.copy2(GENERATOR, generator_copy)
    driver_copy = inputs / DRIVER.name; shutil.copy2(DRIVER, driver_copy)
    parser_copy = inputs / PARSER.name; shutil.copy2(PARSER, parser_copy)
    runtime_copy = out / RUNTIME.name; shutil.copy2(RUNTIME, runtime_copy)
    empty_cp = out / 'empty-classpath'; empty_cp.mkdir()
    empty_sp = out / 'empty-sourcepath'; empty_sp.mkdir()
    source_before = compare.source_closure(root)

    def external_pins():
        paths = {'input_class': INPUT, 'input_class_copy': original_copy,
                 'generator': GENERATOR, 'generator_copy': generator_copy,
                 'driver': DRIVER, 'driver_copy': driver_copy,
                 'parser': PARSER, 'parser_copy': parser_copy,
                 'runtime': RUNTIME, 'runtime_copy': runtime_copy,
                 'compare': compare_path, 'guard': guard_path, 'scanner': scanner_path,
                 'jdk_manifest': manifest}
        result = {name: pin(path) for name, path in paths.items()}
        result['python'] = pin(Path(sys.executable))
        for leg in LEGS:
            for name, path in jdks[leg]['tools'].items(): result[f'{leg}_{name}'] = pin(path)
        return result

    pins_before = external_pins(); commands = []
    report = {'schema': 'field-copy-extra-stack-copy-capture-v1', 'status': 'running',
              'input_class': pin(INPUT), 'input_class_copy': pin(original_copy),
              'generator': {'path': str(GENERATOR.resolve()), 'bytes': GENERATOR.stat().st_size, 'sha256': generator_sha},
              'driver': {'path': str(DRIVER.resolve()), 'bytes': DRIVER.stat().st_size, 'sha256': driver_sha},
              'parser': pin(PARSER), 'runtime_guard': pin(RUNTIME), 'jdk_manifest': jdk_pin,
              'external_pins_before': pins_before, 'source_closure_before': source_before,
              'commands': commands, 'generated_class': None, 'driver_classes': [], 'runtime': [],
              'note': 'One byte at assignAndCompare BCI 10 is changed from iconst_5 to dup. This is an extra stack-copy neighbor, not a synthetic SSA-use mutation; JVM validity remains pending root execution.'}
    write_json(out / 'execution.json', report)

    def command(argv, label, leg):
        if (root / 'target').exists() or (root / 'target').is_symlink(): raise RuntimeError('target appeared')
        if shutil.disk_usage(root).free < 5 * 1024**3: raise RuntimeError('5 GiB guard stopped collection')
        env = compare.clean_env(dict(os.environ), jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(commands) + 1, [str(x) for x in argv], env)
        row['label'] = label; row['tool_leg'] = leg; commands.append(row)
        write_json(out / 'execution.json', report)
        if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        return row

    def raw(row, channel='stdout'): return compare.command_artifact(row, channel)
    def class_facts(path: Path) -> dict:
        data = path.read_bytes(); facts = class_parser.parse_class_file(data)
        facts.update({'path': str(path.resolve()), 'bytes': len(data), 'sha256': sha_bytes(data)})
        return facts

    try:
        target_root = out / 'mutated-target'; target_root.mkdir()
        generated = target_root / 'FieldWriteCopies.class'
        gen_row = command([sys.executable, '-B', generator_copy, original_copy, generated],
                          'rewrite-one-byte-dup-neighbor', 'javac8')
        if gen_row['exit_code'] != 0 or not generated.is_file(): raise RuntimeError('neighbor generator failed')
        facts = class_facts(generated)
        if facts['class_name'] != 'FieldWriteCopies' or facts['major'] != 52: raise RuntimeError('neighbor class identity/major mismatch')
        report['generated_class'] = {'command': gen_row['index'], 'facts': facts,
                                     'input_sha256': sha(original_copy), 'changed_offset_bci': 10,
                                     'changed_bytes': 1}

        driver_root = out / 'driver-classes'; driver_root.mkdir()
        compile_row = command([jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
                               '-encoding', 'UTF-8', '-proc:none', '-classpath', empty_cp,
                               '-sourcepath', empty_sp, '-d', driver_root, driver_copy],
                              'compile-independent-driver-javac8-debug', 'javac8')
        driver_paths = sorted(driver_root.rglob('*.class'))
        if compile_row['exit_code'] != 0 or [p.relative_to(driver_root).as_posix() for p in driver_paths] != ['ExtraStackCopyDriver.class']:
            raise RuntimeError('driver compile/output inventory mismatch')
        report['driver_classes'] = [class_facts(p) for p in driver_paths]

        for vm in LEGS:
            target_before = tree_pins(target_root); driver_before = tree_pins(driver_root)
            run = command([sys.executable, '-B', runtime_copy, '30', jdks[vm]['tools']['java'],
                           '-Xverify:all', '-cp', driver_root, 'ExtraStackCopyDriver', target_root],
                          f'neighbor-load-{vm}', vm)
            target_after = tree_pins(target_root); driver_after = tree_pins(driver_root)
            if target_before != target_after or driver_before != driver_after: raise RuntimeError('class tree changed during JVM run')
            report['runtime'].append({'command': run['index'], 'jvm': vm, 'exit_code': run['exit_code'],
                                      'classpath': [str(driver_root)], 'target_root': str(target_root),
                                      'target_tree_before': target_before, 'target_tree_after': target_after,
                                      'driver_tree_before': driver_before, 'driver_tree_after': driver_after,
                                      'stdout': raw(run).decode('utf-8', errors='replace'),
                                      'stderr_sha256': sha_bytes(raw(run, 'stderr'))})
            write_json(out / 'execution.json', report)

        if len(commands)!=4 or len(report['runtime'])!=2 or any(c['exit_code']!=0 for c in commands):
            raise RuntimeError('neighbor generator/compiler/JVM validation failed; raw retained')
        report['external_pins_after'] = external_pins()
        report['source_closure_after'] = compare.source_closure(root)
        report['source_unchanged'] = report['source_closure_after'] == source_before
        report['target_absent'] = not (root / 'target').exists()
        if report['external_pins_after'] != pins_before or not report['source_unchanged'] or not report['target_absent']:
            raise RuntimeError('input/source/tool closure or target guard mismatch')
        report['status'] = 'captured-pending-independent-review'
        return 0
    except BaseException as exc:
        report['status'] = 'failed'; report['error'] = str(exc); raise
    finally:
        try:
            report['external_pins_after'] = external_pins()
            report['source_closure_after'] = compare.source_closure(root)
            report['source_unchanged'] = report['source_closure_after'] == source_before
            report['target_absent'] = not (root / 'target').exists()
            if report['external_pins_after'] != pins_before or not report['source_unchanged'] or not report['target_absent']:
                report['final_guard_error'] = 'input/tool/source changed or workspace target exists'
                if report['status'] == 'captured-pending-independent-review': report['status'] = 'failed'
        except BaseException as exc:
            report['final_guard_error'] = str(exc)
            if report['status'] == 'captured-pending-independent-review': report['status'] = 'failed'
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write_json(out / 'execution.json', report)
        shutil.copy2(__file__, out / 'collector.py')
        shutil.copy2(PARSER, out / 'accepted-classfile-parser.py')
        print(json.dumps({'status': report['status'], 'output': str(out), 'commands': len(commands),
                          'runtime': len(report['runtime']), 'error': report.get('error')}))

if __name__ == '__main__':
    raise SystemExit(main())
