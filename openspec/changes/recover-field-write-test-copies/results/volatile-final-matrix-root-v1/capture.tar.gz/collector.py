#!/usr/bin/env python3
"""Prepare the complete FieldWriteCopies three-way source/runtime matrix; run only by the root operator.

This script was not executed while being prepared. Use `python -B collect.py`.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode = True
import zipfile

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
PREP = Path('/private/tmp/jarde-field-copy-matrix-prep-luna-v1-20261018')
SOURCE = Path('/private/tmp/jarde-seq1-field-copy-controls-prep-luna-v2-20261018/FieldWriteCopies.java')
REFUSALS = Path('/private/tmp/jarde-seq1-field-copy-controls-prep-luna-v2-20261018/FieldWriteCopyRefusals.java')
DRIVER = Path('/private/tmp/jarde-seq1-field-copy-controls-prep-luna-v2-20261018/FieldWriteCopiesDriver.java')
SOURCE_SHA256 = 'e809436b1e1cdc0232c4a2573641290f3b50f7d05a1d7cf1ea84fe95a13efd85'
REFUSALS_SHA256 = 'b79a8fa7186f9286c5e65937b673946fd7b8fbcd9d29899757e99f3877f90287'
DRIVER_SHA256 = '2e8311f2ec27aaecbabee73ab23a8056024fcbb4a1668ab8838ebffde8851d9b'
PARSER = Path('/private/tmp/jarde-seq1-supplement-collector-prep-luna-v1-20261018/helpers/accepted-classfile-parser.py')
PARSER_SHA256 = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
DEFAULT_CLI = None
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA256 = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA256 = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
RUNTIME_BOUND = Path('/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
RUNTIME_BOUND_SHA256 = '73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
JDK_LEGS = ('javac8', 'javac23')
EVIDENCE = ('default', 'all')
CLASS_NAME = 'FieldWriteCopies'
REFUSAL_CLASS_NAME = 'FieldWriteCopyRefusals'
METHODS = {('<init>', '()V'), ('next', '(I)I'), ('assignAndCompare', '(I)Z'), ('statefulWhile', '(I)I')}
FIELDS = {('z', 'I'), ('calls', 'I'), ('ledger', 'J'), ('throwAt', 'I'), ('marker', 'Ljava/lang/RuntimeException;'), ('lastValue', 'I')}
FIELD_ACCESS = {'z': 0x41, 'calls': 0x01, 'ledger': 0x01, 'throwAt': 0x01, 'marker': 0x11, 'lastValue': 0x01}
METHOD_ACCESS = {('<init>', '()V'): 0x01, ('next', '(I)I'): 0x02, ('assignAndCompare', '(I)Z'): 0x01, ('statefulWhile', '(I)I'): 0x01}


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    tmp.replace(path)


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def jarde_methods(doc: dict) -> list[dict]:
    rows = []
    for method in doc.get('methods', []):
        identity = method.get('item', {}).get('identity', {})
        try:
            name = bytes(identity['name']).decode('utf-8', errors='strict')
            desc = bytes(identity['descriptor']).decode('utf-8', errors='strict')
        except (KeyError, TypeError, ValueError):
            name, desc = None, None
        outcome = method.get('outcome', {})
        rows.append({'name': name, 'descriptor': desc, 'outcome': outcome.get('kind'),
                     'report': outcome.get('report')})
    return rows


def constant_pool_utf8(data: bytes, parser_module) -> list[dict]:
    """Expose UTF8 constant-pool entries; structural validation is done first by the accepted parser."""
    pos = 8

    def take(size: int) -> bytes:
        nonlocal pos
        chunk = data[pos:pos + size]
        if len(chunk) != size:
            raise ValueError('truncated constant pool while recording UTF8 entries')
        pos += size
        return chunk

    count = int.from_bytes(take(2), 'big')
    entries = []
    index = 1
    while index < count:
        tag = take(1)[0]
        if tag == 1:
            raw = take(int.from_bytes(take(2), 'big'))
            decoded = raw.decode('utf-8', errors='strict')
            entries.append({'index': index, 'text': decoded, 'bytes_hex': raw.hex(),
                            'byte_boundaries': sorted(parser_module.byte_boundaries(raw))})
        elif tag in (3, 4):
            take(4)
        elif tag in (5, 6):
            take(8)
            index += 1
        elif tag in (7, 8, 16, 19, 20):
            take(2)
        elif tag in (9, 10, 11, 12, 17, 18):
            take(4)
        elif tag == 15:
            take(3)
        else:
            raise ValueError(f'unknown constant-pool tag {tag} while recording UTF8 entries')
        index += 1
    return entries


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--cli', type=Path, required=True)
    parser.add_argument('--cli-sha256', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    out = args.out.resolve()
    cli = args.cli.resolve(strict=True)
    if out.exists():
        raise SystemExit(f'refusing existing output: {out}')
    if root != ROOT.resolve():
        raise SystemExit(f'workspace differs from pinned root: {root}')
    if sha(cli) != args.cli_sha256.lower():
        raise SystemExit('CLI differs from explicit SHA-256 argument')
    for path, expected, label in ((SOURCE, SOURCE_SHA256, 'target source'),
                                  (REFUSALS, REFUSALS_SHA256, 'refusal control source'),
                                  (DRIVER, DRIVER_SHA256, 'driver source'),
                                  (PARSER, PARSER_SHA256, 'accepted classfile parser'),
                                  (JADX, JADX_SHA256, 'JADX executable'),
                                  (JADX_JAR, JADX_JAR_SHA256, 'JADX jar'),
                                  (RUNTIME_BOUND, RUNTIME_BOUND_SHA256, 'runtime bound wrapper')):
        if sha(path) != expected:
            raise SystemExit(f'{label} pin mismatch: {path}')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('workspace target must be absent before collection')

    compare_path = root / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
    guard_path = root / GUARD_REL
    scanner_path = root / SCANNER_REL
    if sha(guard_path) != GUARD_SHA256 or sha(scanner_path) != SCANNER_SHA256:
        raise SystemExit('guard/scanner source pin mismatch')
    compare = load(compare_path, 'seq1_compare')
    guard = load(guard_path, 'seq1_guard')
    scanner = load(scanner_path, 'seq1_scanner')
    classfile = load(PARSER, 'seq1_accepted_classfile_parser')
    jdks, jdk_pin = compare.configured_jdks(root / JDK_MANIFEST_REL, JDK_MANIFEST_SHA256)

    out.mkdir(parents=True)
    raw = out / 'raw'; raw.mkdir()
    guard.ROOT = root
    guard.OUT = raw
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, stdout_bytes: None
    if shutil.disk_usage(root).free < 5 * 1024**3:
        raise SystemExit('5 GiB free-space guard failed')

    source_copy = out / 'inputs/FieldWriteCopies.java'
    source_copy.parent.mkdir(parents=True)
    refusals_copy = out / 'inputs/FieldWriteCopyRefusals.java'
    refusals_copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(REFUSALS, refusals_copy)
    driver_copy = out / 'driver-source/FieldWriteCopiesDriver.java'
    driver_copy.parent.mkdir(parents=True)
    shutil.copy2(SOURCE, source_copy)
    shutil.copy2(DRIVER, driver_copy)
    parser_copy = out / 'helpers/accepted-classfile-parser.py'
    parser_copy.parent.mkdir(parents=True)
    shutil.copy2(PARSER, parser_copy)
    runtime_wrapper = out / 'runtime-bound.py'
    shutil.copy2(RUNTIME_BOUND, runtime_wrapper)
    empty_sourcepath = out / 'empty-sourcepath'; empty_sourcepath.mkdir()
    classpath_text = str(empty_sourcepath)
    source_before = compare.source_closure(root)

    def external_pins():
        pins = {
            'cli': compare.pin(cli), 'target_source': compare.pin(SOURCE), 'refusal_source': compare.pin(REFUSALS),
            'driver_source': compare.pin(DRIVER), 'parser': compare.pin(PARSER),
            'runtime_wrapper': compare.pin(RUNTIME_BOUND), 'jadx': compare.pin(JADX),
            'jadx_jar': compare.pin(JADX_JAR),
            'jdk_manifest': compare.pin(root / JDK_MANIFEST_REL),
            'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path),
            'scanner': compare.pin(scanner_path),
        }
        for key, path in [('target_source_copy', source_copy), ('refusal_source_copy', refusals_copy), ('driver_source_copy', driver_copy),
                          ('parser_copy', parser_copy), ('runtime_wrapper_copy', runtime_wrapper)]:
            pins[key] = compare.pin(path)
        for leg in JDK_LEGS:
            for name, path in jdks[leg]['tools'].items():
                pins[f'{leg}_{name}'] = compare.pin(path)
        return pins

    inputs_before = external_pins()
    rows = []
    report = {
        'schema': 'field-write-copies-full-class-three-way-matrix-v1',
        'status': 'running', 'cli': compare.pin(cli), 'cli_sha256_argument': args.cli_sha256.lower(),
        'target_source': compare.pin(SOURCE), 'refusal_source': compare.pin(REFUSALS), 'driver_source': compare.pin(DRIVER),
        'accepted_parser': compare.pin(PARSER), 'jdk_manifest': jdk_pin,
        'jadx': compare.pin(JADX), 'jadx_jar': compare.pin(JADX_JAR),
        'guard': compare.pin(guard_path), 'scanner': compare.pin(scanner_path),
        'runtime_wrapper': compare.pin(runtime_wrapper), 'source_pins_before': source_before,
        'external_input_pins_before': inputs_before, 'commands': rows,
        'original_profiles': [], 'original_runtime': [], 'original_oracle': None,
        'wrong_root_control': None, 'jarde_cells': [], 'jadx_cells': [],
        'generated_compiles': [], 'generated_runtime': [],
        'notes': [
            'The complete positive and refusal source inputs and the separate reflection driver are frozen private inputs; this collector never edits them.',
            'Every emitted whole-source file is compiled unchanged with both pinned compiler legs; original input roots cover both debug settings.',
            'Runtime is attempted only for successful full-source compiles; the JVM classpath contains only the separate driver root and the parentless target loader receives exactly one target root.',
            'The driver emits fixed rows after checking field-write state and exception identity; original JVM stdout establishes the oracle.',
            'CLI reports, JADX source trees, complete classfile fields/methods/Code/BCI inventories, UTF-8 constants, raw streams, and failures are retained without deleting methods.',
        ],
    }
    write_json(out / 'execution.json', report)

    def command(argv, label, leg='javac23'):
        if (root / 'target').exists() or (root / 'target').is_symlink():
            raise RuntimeError('workspace target appeared during collection')
        if shutil.disk_usage(root).free < 5 * 1024**3:
            raise RuntimeError('5 GiB free-space guard failed during collection')
        env = compare.clean_env(dict(os.environ), jdks[leg])
        env.update(guard.ENV_VALUES)
        env.pop('RUST_MIN_STACK', None)
        result = guard.run_command(len(rows) + 1, [str(x) for x in argv], env)
        result['label'] = label
        result['tool_leg'] = leg
        rows.append(result)
        write_json(out / 'execution.json', report)
        if result.get('guard_stop') is not None:
            raise RuntimeError(f'guard stopped {label}: {result["guard_stop"]}')
        return result

    def stream(row, name='stdout') -> bytes:
        return compare.command_artifact(row, name)

    def parse_class(path: Path) -> dict:
        data = path.read_bytes()
        facts = classfile.parse_class_file(data)
        facts.update({'path': str(path.resolve()), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        facts['constant_pool_utf8'] = constant_pool_utf8(data, classfile)
        return facts

    def tree_pins(directory: Path) -> dict[str, dict]:
        return {path.relative_to(directory).as_posix(): compare.pin(path)
                for path in sorted(directory.rglob('*')) if path.is_file()}

    def validate_original(path: Path) -> dict:
        facts = parse_class(path)
        if facts['major'] != 52 or facts['class_name'] != CLASS_NAME:
            raise RuntimeError(f'original class identity/major mismatch: {path}')
        method_keys = {(row['name'], row['descriptor']) for row in facts['methods']}
        field_keys = {(row['name'], row['descriptor']) for row in facts['fields']}
        if method_keys != METHODS or field_keys != FIELDS:
            raise RuntimeError(f'complete fixture inventory mismatch in {path}: {method_keys=} {field_keys=}')
        if facts['access'] != 0x31:
            raise RuntimeError(f'fixture class access flags changed in {path}: {facts["access"]:#x}')
        if any(row['access'] != METHOD_ACCESS[(row['name'], row['descriptor'])]
               for row in facts['methods']):
            raise RuntimeError(f'fixture method access flags changed in {path}')
        if any(row['access'] != FIELD_ACCESS[row['name']] for row in facts['fields']):
            raise RuntimeError(f'fixture field access flags changed in {path}')
        if any(row['code'] is None for row in facts['methods']):
            raise RuntimeError(f'expected Code for every target method: {path}')
        return facts

    def runtime(profile: dict, vm_leg: str, label: str, root_arg: Path):
        class_root = Path(profile['class_root'])
        driver_root = out / 'driver-classes'
        target_before = tree_pins(class_root)
        driver_before = tree_pins(driver_root)
        cp = str(driver_root)
        result = command([
            sys.executable, '-B', runtime_wrapper, '30', jdks[vm_leg]['tools']['java'],
            '-Xverify:all', '-cp', cp, 'FieldWriteCopiesDriver', CLASS_NAME, root_arg,
        ], label, vm_leg)
        target_after = tree_pins(class_root)
        driver_after = tree_pins(driver_root)
        if target_after != target_before or driver_after != driver_before:
            raise RuntimeError(f'{label}: class files changed during runtime')
        return {'label': label, 'command': result['index'], 'exit_code': result['exit_code'],
                'profile': profile['label'], 'runtime': vm_leg, 'classpath': [str(driver_root)],
                'target_tree_before': target_before, 'target_tree_after': target_after,
                'driver_tree_before': driver_before, 'driver_tree_after': driver_after,
                'stdout': stream(result).decode('utf-8', errors='replace'),
                'stderr_sha256': hashlib.sha256(stream(result, 'stderr')).hexdigest()}

    try:
        # Compile the driver into its own root before any target runtime.
        driver_root = out / 'driver-classes'; driver_root.mkdir()
        drv = command([jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
                       '-encoding', 'UTF-8', '-proc:none', '-classpath', classpath_text,
                       '-sourcepath', empty_sourcepath, '-d', driver_root, driver_copy],
                      'compile-reflection-driver', 'javac8')
        if drv['exit_code'] != 0:
            raise RuntimeError('independent driver compilation failed; raw retained')
        driver_fact_paths = sorted(driver_root.rglob('*.class'))
        report['driver_classes'] = [parse_class(p) for p in driver_fact_paths]
        if len(driver_fact_paths) != 1 or report['driver_classes'][0]['major'] != 52:
            raise RuntimeError('driver did not produce exactly one Java 8 class')

        # Build four complete original input roots (positive + refusal classes): compiler × debug profile.
        original_sources = []
        for leg in JDK_LEGS:
            for debug_name, debug_arg in (('debug', '-g'), ('no-debug', '-g:none')):
                label = f'{leg}-{debug_name}'
                class_root = out / 'original' / label / 'classes'; class_root.mkdir(parents=True)
                compiler = jdks[leg]['tools']['javac']
                flags = ['-source', '8', '-target', '8'] if leg == 'javac8' else ['--release', '8']
                compiled = command([compiler, *flags, debug_arg, '-encoding', 'UTF-8', '-proc:none',
                                   '-classpath', classpath_text, '-sourcepath', empty_sourcepath,
                                   '-d', class_root, source_copy, refusals_copy], 'original-' + label, leg)
                produced = sorted(class_root.rglob('*.class'))
                cell = {'label': label, 'compiler': leg, 'debug': debug_name, 'compile_command': compiled['index'],
                        'exit_code': compiled['exit_code'], 'class_outputs': [parse_class(p) for p in produced],
                        'class_root': str(class_root)}
                if compiled['exit_code'] == 0:
                    if [p.relative_to(class_root).as_posix() for p in produced] != ['FieldWriteCopies.class', 'FieldWriteCopyRefusals.class']:
                        raise RuntimeError(f'{label}: unexpected complete-source output inventory')
                    cell['target'] = validate_original(class_root / 'FieldWriteCopies.class')
                report['original_profiles'].append(cell)
                write_json(out / 'execution.json', report)
                original_sources.append(cell)

        original_observations = []
        for profile in original_sources:
            if profile['exit_code'] != 0:
                continue
            for vm_leg in JDK_LEGS:
                observed = runtime(profile, vm_leg, f'original-{profile["label"]}-{vm_leg}', Path(profile['class_root']))
                report['original_runtime'].append(observed)
                if observed['exit_code'] == 0:
                    original_observations.append(observed['stdout'])
                write_json(out / 'execution.json', report)
        if len(original_observations) == 8 and len(set(original_observations)) == 1:
            oracle = original_observations[0].encode('utf-8')
            oracle_path = out / 'original-oracle.stdout'
            oracle_path.write_bytes(oracle)
            report['original_oracle'] = compare.pin(oracle_path)
            report['original_runtime_agreement'] = True
        else:
            report['original_runtime_agreement'] = False
            report['original_runtime_note'] = 'Oracle requires all four original profile roots on both JVM legs to exit zero with identical stdout.'

        wrong = command([sys.executable, '-B', runtime_wrapper, '30', jdks['javac23']['tools']['java'],
                         '-Xverify:all', '-cp', str(driver_root),
                         'FieldWriteCopiesDriver', CLASS_NAME, empty_sourcepath], 'wrong-root-control', 'javac23')
        wrong_stderr = stream(wrong, 'stderr')
        report['wrong_root_control'] = {'command': wrong['index'], 'exit_code': wrong['exit_code'],
                                        'stderr': wrong_stderr.decode('utf-8', errors='replace'),
                                        'rejected': wrong['exit_code'] != 0 and b'ClassNotFoundException' in wrong_stderr}
        if not report['wrong_root_control']['rejected']:
            raise RuntimeError('driver wrong-root control did not fail with ClassNotFoundException')

        version = command([JADX, '--version'], 'jadx-version')
        version_text = (stream(version) + stream(version, 'stderr')).decode('utf-8', errors='replace')
        if version['exit_code'] != 0 or '1.5.6' not in version_text:
            raise RuntimeError('JADX executable version check failed')

        generated_sources = []
        jadx_roots = []
        for profile in original_sources:
            if profile['exit_code'] != 0:
                continue
            class_root = Path(profile['class_root'])
            target = class_root / 'FieldWriteCopies.class'
            bundle = out / 'inputs' / f'{profile["label"]}.jar'
            with zipfile.ZipFile(bundle, 'w') as jar:
                info = zipfile.ZipInfo('FieldWriteCopies.class', (1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_STORED
                jar.writestr(info, target.read_bytes())

            for form, input_path, policy in (('child', target, 'single-class'), ('bundle-child', bundle, 'plain-jar')):
                for evidence in EVIDENCE:
                    argv = [cli, 'class-source', '--input', input_path, '--class', CLASS_NAME,
                            '--policy', policy, '--release', '8', '--format', 'json']
                    if evidence == 'all':
                        argv.extend(['--evidence', 'all'])
                    row = command(argv, f'jarde-{profile["label"]}-{form}-{evidence}')
                    raw_json = stream(row)
                    dest = out / 'jarde' / profile['label'] / form / evidence
                    dest.mkdir(parents=True)
                    report_path = dest / 'report.json'; report_path.write_bytes(raw_json)
                    cell = {'profile': profile['label'], 'form': form, 'evidence': evidence,
                            'command': row['index'], 'exit_code': row['exit_code'],
                            'input': compare.pin(input_path), 'report': compare.pin(report_path)}
                    try:
                        doc = json.loads(raw_json)
                        text = doc.get('text')
                        if isinstance(text, str) and text:
                            whole = dest / 'FieldWriteCopies.java'; whole.write_text(text, encoding='utf-8')
                            cell['whole_source'] = compare.pin(whole)
                            cell['methods'] = jarde_methods(doc)
                            if row['exit_code'] == 0:
                                generated_sources.append({'origin': 'jarde', 'label': dest.relative_to(out).as_posix(),
                                                          'source_files': [str(whole)],
                                                          'source_pins': [compare.pin(whole)], 'source_cell': cell})
                    except (ValueError, TypeError) as error:
                        cell['json_error'] = str(error)
                    report['jarde_cells'].append(cell)
                    write_json(out / 'execution.json', report)

            for form, input_path in (('child', target), ('bundle', bundle)):
                dest = out / 'jadx' / profile['label'] / form
                row = command([JADX, '--config', 'none', '--threads-count', '1', '--no-res',
                               '--rename-flags', 'none', '-d', dest, input_path],
                              f'jadx-{profile["label"]}-{form}')
                files = sorted(dest.rglob('*.java')) if dest.exists() else []
                cell = {'profile': profile['label'], 'form': form, 'command': row['index'],
                        'exit_code': row['exit_code'], 'sources': [compare.pin(p) for p in files]}
                report['jadx_cells'].append(cell)
                write_json(out / 'execution.json', report)
                if row['exit_code'] == 0 and files:
                    generated_sources.append({'origin': 'jadx', 'label': dest.relative_to(out).as_posix(),
                                              'source_files': [str(p) for p in files],
                                              'source_pins': [compare.pin(p) for p in files], 'source_cell': cell})

        # Recompile every full extracted source unchanged with both compilers; original input roots already cover debug/none.
        for source_record in generated_sources:
            src_paths = [Path(p) for p in source_record['source_files']]
            source_id = source_record['label']
            if [compare.pin(p) for p in src_paths] != source_record['source_pins']:
                raise RuntimeError(f'{source_id}: generated source changed before recompilation')
            for leg in JDK_LEGS:
                for debug_name, debug_arg in (('debug', '-g'),):
                    label = f'{source_record["origin"]}-{source_id}-{leg}-{debug_name}'
                    dest = out / 'generated' / source_record['origin'] / source_id / leg / debug_name / 'classes'
                    dest.mkdir(parents=True)
                    flags = ['-source', '8', '-target', '8'] if leg == 'javac8' else ['--release', '8']
                    compiled = command([jdks[leg]['tools']['javac'], *flags, debug_arg, '-encoding', 'UTF-8',
                                        '-proc:none', '-classpath', classpath_text, '-sourcepath', empty_sourcepath,
                                        '-d', dest, *src_paths], 'recompile-' + label, leg)
                    produced = sorted(dest.rglob('*.class'))
                    compile_cell = {'label': label, 'origin': source_record['origin'], 'source_cell': source_id,
                                    'compiler': leg, 'debug': debug_name, 'command': compiled['index'],
                                    'exit_code': compiled['exit_code'], 'class_outputs': [parse_class(p) for p in produced],
                                    'class_root': str(dest), 'source_pins_before': source_record['source_pins'],
                                    'source_pins_after': [compare.pin(p) for p in src_paths]}
                    if compile_cell['source_pins_after'] != compile_cell['source_pins_before']:
                        raise RuntimeError(f'{source_id}: compiler changed generated source input')
                    report['generated_compiles'].append(compile_cell)
                    if compiled['exit_code'] == 0:
                        target_class = dest / 'FieldWriteCopies.class'
                        if target_class.is_file() and report.get('original_oracle') is not None:
                            compile_cell['target'] = validate_original(target_class)
                            for vm_leg in JDK_LEGS:
                                run = runtime(compile_cell, vm_leg,
                                              f'generated-{source_record["origin"]}-{source_id}-{leg}-{debug_name}-{vm_leg}',
                                              dest)
                                equal = (report.get('original_oracle') is not None
                                         and run['stdout'].encode('utf-8') == (out / 'original-oracle.stdout').read_bytes())
                                run['matches_original_oracle'] = equal
                                report['generated_runtime'].append(run)
                        elif not target_class.is_file():
                            compile_cell['runtime_status'] = 'no-runtime: expected target class absent'
                        else:
                            compile_cell['runtime_status'] = 'no-runtime: original oracle unavailable'
                    else:
                        compile_cell['runtime_status'] = 'no-runtime: full-source compile failed'
                    write_json(out / 'execution.json', report)

        if len(report['original_profiles']) != 4:
            raise RuntimeError(f"expected four original profiles, got {len(report['original_profiles'])}")
        if len(report['jarde_cells']) != 16 or len(report['jadx_cells']) != 8:
            raise RuntimeError(f"incomplete extraction matrix: Jarde={len(report['jarde_cells'])}, JADX={len(report['jadx_cells'])}")
        if len(report['generated_compiles']) != 48:
            raise RuntimeError(f"expected 48 full-source compiles, got {len(report['generated_compiles'])}")
        if len(report['original_runtime']) != 8:
            raise RuntimeError(f"expected eight original JVM runs, got {len(report['original_runtime'])}")
        report['matrix_counts'] = {'original_profiles': len(report['original_profiles']),
                                   'original_runtime': len(report['original_runtime']),
                                   'jarde_cells': len(report['jarde_cells']),
                                   'jadx_cells': len(report['jadx_cells']),
                                   'generated_compiles': len(report['generated_compiles']),
                                   'generated_runtime': len(report['generated_runtime'])}
        report['external_input_pins_after'] = external_pins()
        report['source_pins_after'] = compare.source_closure(root)
        report['source_unchanged'] = report['source_pins_after'] == source_before
        report['target_absent'] = not (root / 'target').exists()
        if report['external_input_pins_after'] != inputs_before or not report['source_unchanged'] or not report['target_absent']:
            raise RuntimeError('input/source pin or target-absence guard failed')
        report['status'] = 'captured-pending-independent-review'
        return 0
    except BaseException as error:
        report['status'] = 'failed'
        report['error'] = str(error)
        raise
    finally:
        try:
            report['external_input_pins_after'] = external_pins()
            report['source_pins_after'] = compare.source_closure(root)
            report['source_unchanged'] = report['source_pins_after'] == source_before
            report['target_absent'] = not (root / 'target').exists()
            if (report['external_input_pins_after'] != inputs_before or not report['source_unchanged']
                    or not report['target_absent']):
                report['final_guard_error'] = 'external source/tool pins changed or workspace target exists'
                if report['status'] == 'captured-pending-independent-review':
                    report['status'] = 'failed'
        except BaseException as error:
            report['final_guard_error'] = str(error)
            if report['status'] == 'captured-pending-independent-review':
                report['status'] = 'failed'
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write_json(out / 'execution.json', report)
        shutil.copy2(__file__, out / 'collector.py')
        shutil.copy2(PARSER, out / 'accepted-classfile-parser.py')
        print(json.dumps({'status': report['status'], 'output': str(out),
                          'commands': len(rows), 'generated_compiles': len(report['generated_compiles']),
                          'error': report.get('error')}))


if __name__ == '__main__':
    raise SystemExit(main())
