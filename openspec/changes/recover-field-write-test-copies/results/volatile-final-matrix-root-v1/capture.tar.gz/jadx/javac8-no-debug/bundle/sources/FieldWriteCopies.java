// default package

/* JADX INFO: loaded from: javac8-no-debug.jar:FieldWriteCopies.class */
public final class FieldWriteCopies {
    public volatile int z;
    public int calls;
    public long ledger;
    public int throwAt = -1;
    public final RuntimeException marker = new RuntimeException("field-copy-marker");
    public int lastValue;

    private int next(int i) {
        this.calls++;
        this.lastValue = i;
        this.ledger = (this.ledger * 37) + ((long) i);
        if (this.calls == this.throwAt) {
            throw this.marker;
        }
        return i + 1;
    }

    public boolean assignAndCompare(int i) {
        int next = next(i);
        this.z = next;
        return next < 5;
    }

    public int statefulWhile(int i) {
        int i2 = 0;
        while (true) {
            int next = next(i + i2);
            this.z = next;
            if (next >= 3) {
                return i2;
            }
            i2++;
        }
    }
}
