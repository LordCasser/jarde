// default package

/* JADX INFO: loaded from: javac23-debug.jar:FieldWriteCopies.class */
public final class FieldWriteCopies {
    public volatile int z;
    public int calls;
    public long ledger;
    public int throwAt = -1;
    public final RuntimeException marker = new RuntimeException("field-copy-marker");
    public int lastValue;

    private int next(int value) {
        this.calls++;
        this.lastValue = value;
        this.ledger = (this.ledger * 37) + ((long) value);
        if (this.calls == this.throwAt) {
            throw this.marker;
        }
        return value + 1;
    }

    public boolean assignAndCompare(int value) {
        int next = next(value);
        this.z = next;
        return next < 5;
    }

    public int statefulWhile(int start) {
        int iterations = 0;
        while (true) {
            int next = next(start + iterations);
            this.z = next;
            if (next < 3) {
                iterations++;
            } else {
                return iterations;
            }
        }
    }
}
