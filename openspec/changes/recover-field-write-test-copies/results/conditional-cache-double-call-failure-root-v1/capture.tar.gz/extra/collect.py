from pathlib import Path
import importlib.util,json,os,hashlib
R=Path('/Users/lordcasser/workspace/projects/jarde');O=Path('/private/tmp/jarde-field-copy-double-call-root-v1-20261018');A=Path('/private/tmp/jarde-field-copy-diagnostic-api-root-v1-20261018');B=Path('/private/tmp/jarde-field-copy-oracle-root-v2-20261018')
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load(R/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','c');g=load(R/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py','g');sc=load(R/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py','s');jdks,jpin=c.configured_jdks(R/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json','ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
assert not O.exists() and not (R/'target').exists();O.mkdir();(O/'raw').mkdir();(O/'source').mkdir();(O/'empty').mkdir();source=O/'source/FieldWriteCopies.java';source.write_bytes(json.loads((A/'stdout.raw').read_bytes())['text'].encode());g.ROOT=R;g.OUT=O/'raw';g.target_bytes=lambda:sc.target_bytes(R);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
r={'status':'running','collector':c.pin(Path(__file__)),'diagnostic_api':c.pin(A/'execution.json'),'source':c.pin(source),'oracle':c.pin(B/'oracle.stdout'),'driver':c.pin(B/'driver/FieldWriteCopiesDriver.class'),'commands':[],'runtimes':[],'source_before':c.source_closure(R),'jdk':jpin}
def save():(O/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
def cmd(argv,label,leg):
 env=c.clean_env(dict(os.environ),jdks[leg]);env.update(g.ENV_VALUES);env.pop('RUST_MIN_STACK',None);row=g.run_command(len(r['commands'])+1,list(map(str,argv)),env);row['label']=label;r['commands'].append(row);save();assert row['exit_code']==0 and row['guard_stop'] is None;return row
try:
 for leg in ('javac8','javac23'):
  target=O/leg;target.mkdir();flags=['-source','8','-target','8'] if leg=='javac8' else ['--release','8'];cmd([jdks[leg]['tools']['javac'],*flags,'-g','-proc:none','-encoding','UTF-8','-classpath',O/'empty','-sourcepath',O/'empty','-d',target,source],'compile-'+leg,leg)
  for vm in ('javac8','javac23'):
   row=cmd(['python3','-B','/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py','30',jdks[vm]['tools']['java'],'-Xverify:all','-cp',B/'driver','FieldWriteCopiesDriver','FieldWriteCopies',target],'run-'+leg+'-'+vm,vm);raw=c.command_artifact(row,'stdout');r['runtimes'].append({'compiler':leg,'vm':vm,'command':row['index'],'matches_original':raw==(B/'oracle.stdout').read_bytes(),'target':c.pin(target/'FieldWriteCopies.class')});save()
 assert len(r['commands'])==6 and len(r['runtimes'])==4 and all(not x['matches_original'] for x in r['runtimes']);assert c.pin(source)==r['source'];r['status']='reproduced_semantic_mismatch'
except BaseException as e:r['status']='failed';r['error']=str(e);raise
finally:
 r['source_after']=c.source_closure(R);r['source_unchanged']=r['source_before']==r['source_after'];r['target_absent']=not (R/'target').exists();save()
print(json.dumps({'status':r['status'],'commands':len(r['commands']),'runtimes':len(r['runtimes']),'source_unchanged':r['source_unchanged'],'target_absent':r['target_absent']}))
