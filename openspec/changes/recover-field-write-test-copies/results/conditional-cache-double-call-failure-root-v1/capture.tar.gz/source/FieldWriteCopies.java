// jarde: presentation of `FieldWriteCopies` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class FieldWriteCopies extends java.lang.Object {
    public volatile int z;

    public int calls;

    public long ledger;

    public int throwAt;

    public final java.lang.RuntimeException marker;

    public int lastValue;

    public FieldWriteCopies() {
        // @method <init>()V
        // @declaration a constructor of `FieldWriteCopies`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        this.throwAt = -1;
        this.marker = new java.lang.RuntimeException("field-copy-marker");
        return;
    }

    private int next(int value) {
        // @method next(I)I
        // @declaration an instance method of `FieldWriteCopies`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        this.calls += 1;
        this.lastValue = value;
        this.ledger = this.ledger * 37L + (long) value;
        if (this.calls == this.throwAt) {
            throw this.marker;
        } else {
            return value + 1;
        }
    }

    public boolean assignAndCompare(int value) {
        // @method assignAndCompare(I)Z
        // @declaration an instance method of `FieldWriteCopies`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int saved0 = this.next(value);
        this.z = saved0;
        return this.next(value) < 5;
    }

    public int statefulWhile(int start) {
        // @method statefulWhile(I)I
        // @declaration an instance method of `FieldWriteCopies`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int iterations;
        iterations = 0;
        while (true) {
            int saved0 = this.next(start + iterations);
            this.z = saved0;
            if (saved0 < 3) {
            } else {
                break;
            }
            iterations = iterations + 1;
        }
        return iterations;
    }
}
