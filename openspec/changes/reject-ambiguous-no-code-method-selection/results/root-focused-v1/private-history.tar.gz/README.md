# 私有隔离验证：reject-ambiguous-no-code-method-selection

- checkout：`/home/lordcasser/.codex/worktrees/review-core-fixes/jarde`
- HEAD：`5f18b2a94e1b8eab8296dc38768463657f436d50`
- 基线包括既有 cache-v4 四文件候选，不代表 pristine HEAD 的完整产品验证。
- 原始 OpenSpec 状态：spec-driven，0/4；任务文件保持未勾选。
- 只改本 change 的三个候选文件；完整 before/after closure 按相对路径+SHA-256 保存为 gzip manifests。除三文件外没有源文件变化。

既有 cache-v4 文件 pins：
- `crates/jarde-reader/src/facts_cache.rs` `74038dbb60a2f2888e4c8e535a3f1487552edeeb60477d31b8cc14fdd45aa800`
- `tests/p5_benchmark.rs` `818472fcc684063e4415a389dae5e90e863f3ae73dd4603090051e79b3bb3d17`
- `tests/p5_facts_cache.rs` `5fbb01eaf6d180b4b7dac91ab278c34bc4ee569862189b1b78749cd6f5943801`
- `crates/jarde-reader/src/facts_capacity_tests.rs` `19185d8f095286545f1690a9c0e5f4df938e295f6d96a7fca5110024be72e3a6`

候选验证：
- 原始候选补丁 SHA-256：`6d5de9567cfeae8fe6919f0c2aaa60e295c6466bafefedaad45418e9c8eb6a4a`。
- 旧 production + 新公共测试复现：`cargo test --test p3_prepared_input duplicate_ --locked -- --nocapture`。编译成功，两项测试均在行为断言失败：旧 driver 返回 `Complete`；旧 callee 返回首条无 Code 成员，而非歧义错误。随后精确 `cargo clean` 成功，target 不存在。
- `cargo fmt --all` 退出 0。
- 原样指定的四 target 命令退出 0，但 `d3_artifact_binding` 由于缺少 `test-support` 实际为 0 tests，因此不计其通过。
- 增补 `--all-features` 后四 target 均实际执行并通过，计数为 13 + 12 + 12 + 12。`p3_prepared_input` 六项新增测试 `duplicate_driver...`、`duplicate_callee...`、`unique_and_missing...`、`prepared_definition_mismatch...`、`incomplete_member_table...`、`loader_binding_refusal...` 均逐项显示通过。
- 每条 Cargo 命令均串行，guard cwd/root 为上述隔离 checkout；`CARGO_BUILD_JOBS=1`、incremental/debug=0、`RUST_TEST_THREADS=1`、stable、offline、清除 `CARGO_TARGET_DIR`/`RUST_MIN_STACK`/Java opts。guard 每秒执行 5 GiB free / 1 GiB target 进程组检查。

导出 `validated-candidate.patch` 只含三目标文件、相对候选前源文件；已通过 reverse-apply check 和 diff whitespace check。测试与格式通过不代表 Clippy、OpenSpec strict、workspace 集成或 CI 完成；这些仍需 coding chat 的主线集成后验证。验证完成后已要求精确 `cargo clean` 并确认 target 缺失。
