from pathlib import Path
import json,hashlib,collections
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');D=B/'interface-full-source-harness-v4/run-interface-v1';O=B/'interface-full-source-root-acceptance-v1.json';assert not O.exists();d=json.loads((D/'harness-receipt.json').read_text());assert d['status']=='expected_command_outcomes_observed_pending_independent_acceptance' and d['source_and_tool_inputs_unchanged'] and d['target_absent'];rows=d['commands'];assert len(rows)==178
def verify(pin):
 z=Path(pin['path']).read_bytes();assert len(z)==pin['bytes'] and hashlib.sha256(z).hexdigest()==pin['sha256']
for p in d['source_input_manifest_before']:verify(p)
assert d['source_input_manifest_before']==d['source_input_manifest_after']
for r in rows:
 assert r['guard_stop'] is None
 for p in r['streams'].values():verify(p)
 if r['exit_code']==1:assert r['argv'][0]=='java' and 'AbstractMethodError' in Path(r['streams']['stderr']['path']).read_text()
 if r['exit_code']==4:
  j=json.loads(Path(r['streams']['stdout']['path']).read_text());assert r['argv'][1]=='class-source' and j['execution']['reason']['code']=='jre_evidence_range_invalid'
assert collections.Counter(r['exit_code'] for r in rows)=={0:172,1:4,4:2}
pp=d['retained_payload_manifest'];verify(pp);pm=json.loads(Path(pp['path']).read_text());assert len(pm['files'])==144
for p in pm['files']:
 z=(Path(d['retained_temp_root'])/p['path']).read_bytes();assert len(z)==p['bytes'] and hashlib.sha256(z).hexdigest()==p['sha256']
legal=[]
for row in rows:
 a=row['argv']
 if a[0]!='javac' or Path(a[-1]).parent.name!='source':continue
 src=Path(a[-1]);work=src.parent.parent;classes=a[a.index('-cp')+1];rebuilt=str(work/'rebuilt')+':'+classes
 actual=[r for r in rows if r['argv'][0]=='java' and '-cp' in r['argv'] and r['argv'][r['argv'].index('-cp')+1]==rebuilt];assert len(actual)==1;actual=actual[0]
 original=[r for r in rows if r['argv'][0]=='java' and '-cp' in r['argv'] and r['argv'][r['argv'].index('-cp')+1]==classes and r['argv'][-1]==actual['argv'][-1]];assert len(original)==1;original=original[0]
 out=Path(actual['streams']['stdout']['path']).read_bytes();assert out==Path(original['streams']['stdout']['path']).read_bytes();assert row['exit_code']==actual['exit_code']==original['exit_code']==0
 reports=[r for r in rows if len(r['argv'])>1 and r['argv'][1]=='class-source' and '--input' in r['argv'] and Path(r['argv'][r['argv'].index('--input')+1]).parent==work and '--evidence' in r['argv'] and r['argv'][r['argv'].index('--evidence')+1]=='all'];assert len(reports)==1
 j=json.loads(Path(reports[0]['streams']['stdout']['path']).read_text());assert src.read_text()==j['text']
 legal.append({'case':work.name,'debug_group':work.parent.name,'generated_source':str(src),'generated_source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'original_and_rebuilt_stdout':out.decode(),'oracle_rows':len(out.decode().splitlines()),'javac_exit':0,'original_exit':0,'rebuilt_exit':0})
assert len(legal)==8 and len(set(x['case'] for x in legal))==4
j={'status':'accepted_original_full_source_interface_contract','commands':178,'raw_streams':356,'input_count':40,'retained_files':144,'legal_full_class_cells':legal,'legal_oracle_rows':sum(x['oracle_rows'] for x in legal),'refusal_control_cases':8,'refusal_cells_across_debug_modes':16,'negative_controls':'4 actual AbstractMethodError exits1; 2 actual evidence-range exits4; all original script assertions retained and completed','inputs_unchanged':True,'target_absent':True,'scope':'frozen interface CLI 958a... own local full-source/behavior contract only; whole-workspace and final product CI pending','auditor_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};O.write_text(json.dumps(j,indent=2)+'\n');print(json.dumps({k:v for k,v in j.items() if k!='legal_full_class_cells'}))
