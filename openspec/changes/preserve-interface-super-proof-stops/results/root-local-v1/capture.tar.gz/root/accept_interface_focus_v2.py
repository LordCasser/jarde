from pathlib import Path
import hashlib,json,re,sys
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');R=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');D=B/'interface-proof-focused-root-v4';O=B/'interface-focused-root-acceptance-v4.json';assert not O.exists()
d=json.loads((D/'execution.json').read_text());assert d['status']=='expected_command_outcomes_observed_pending_independent_acceptance';assert d['source_manifest_before']==d['source_manifest_after'];assert len(d['source_manifest_before'])==4901 and d['target_absent'] and not(R/'target').exists();checks=0
def verify(pin):
 global checks
 p=Path(pin['path']);z=p.read_bytes();assert len(z)==pin['bytes'] and hashlib.sha256(z).hexdigest()==pin['sha256'],p;checks+=1
for p in d['source_manifest_after']:
 z=(R/p['path']).read_bytes();assert len(z)==p['bytes'] and hashlib.sha256(z).hexdigest()==p['sha256'];checks+=1
prior=json.loads((B/'interface-proof-focused-root-v3/execution.json').read_text())
assert prior['status']=='failed' and prior['source_manifest_before']==prior['source_manifest_after']==d['source_manifest_before']
assert prior['target_absent']
accepted_prior=prior['commands'][:5]
assert [x['label'] for x in accepted_prior]==['fmt-check','ci-exact-clippy','openspec-ci-strict','openspec-local-strict','java-library-stop-controls']
suites=[];named=[]
for row in accepted_prior+d['commands']:
 assert row['exit_code']==0 and row['guard_stop'] is None
 for p in row['streams'].values():verify(p)
 t=re.sub(r'\x1b\[[0-9;]*m','',Path(row['streams']['stdout']['path']).read_text())
 if row['label'].startswith('openspec-'):assert 'Totals: 366 passed, 0 failed (366 items)' in t
 ss=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t)
 if row['label']=='java-library-stop-controls':assert ss==[('ok','424','0','0')]
 if row['label']=='facade-library-proof-controls':assert ss==[('ok','229','0','0')]
 if row['label']=='controlled-jdk23-full-special-dispatch':assert ss==[('ok','1','0','0')]
 for state,p,f,i in ss:assert state=='ok' and int(f)==0;suites.append({'label':row['label'],'passed':int(p),'failed':int(f),'ignored':int(i)})
 named+=re.findall(r'^test (.+) \.\.\. (ok|ignored|FAILED)(?:, .*)?$',t,re.M)
assert len(suites)==12,len(suites)
public=[m.group(1) for m in re.finditer(r'#\[test\]\s*fn (\w+)',(R/'tests/interface_proof_stops.rs').read_text())]
unit=['facade::interface_super_proof_stop_tests::'+n for n in ['public_proof_charge_cancellation_keeps_analysis_and_no_artifact','public_proof_counted_limits_preserve_analysis_and_metadata_dimensions','public_proof_first_poll_observes_the_actual_expired_ledger_deadline','class_source_public_proof_cancellation_retains_the_reliable_prefix','class_source_local_dependency_depth_stop_is_nonsticky_and_publishes_only_the_stop_record']]
assert len(public)==6
for n in public+unit:assert named.count((n,'ok'))==1,n
assert named.count(('generated_special_dispatch_matches_original_runtime','ok'))==1
for key in ['runner','command_spec','frozen_cli']:verify(d[key])
assert d['frozen_cli']['mode']=='0555' and Path(d['frozen_cli']['path']).stat().st_mode&0o777==0o555
j={'status':'accepted_affected_focus_and_controlled_special_dispatch','source_count':4901,'source_before_after_current_identical':True,'commands':len(d['commands'])+len(accepted_prior),'raw_streams':sum(len(x['streams']) for x in accepted_prior+d['commands']),'checks':checks,'suites':suites,'totals':{k:sum(x[k] for x in suites) for k in ['passed','failed','ignored']},'required_interface_tests':public+unit,'frozen_cli':d['frozen_cli'],'target_absent':True,'prior_failed_run_scope':'Only first five actual successful commands from v3 reused on byte-identical source; v3 root library143/86 compiler-launch failure excluded, remaining commands rerun under controlled JDK23 in v4',
'scope':'local affected focus and original full-special-dispatch runtime test only; interface standalone full-source matrix and exact own CI pending','auditor_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};O.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in j.items() if k not in ['suites','required_interface_tests']},ensure_ascii=False))
