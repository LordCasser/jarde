from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');O=R/'openspec/changes/preserve-interface-super-proof-stops/results/root-local-v1';assert not O.exists();files={}
def add(p,n):
 assert p.is_file() and not p.is_symlink() and n not in files,(p,n)
 files[n]=p.read_bytes()
for n in ['interface-proof-repro-root-v1','interface-proof-repro-source-v1','interface-proof-initial-root-v1','interface-proof-initial-root-v2','interface-proof-unit-root-v3','interface-proof-unit-root-v4','interface-initial-source-v1','interface-initial-source-v2','interface-initial-source-v3','interface-clippy-source-v2','interface-proof-focused-root-v1','interface-proof-focused-root-v2','interface-proof-focused-root-v3','interface-proof-focused-root-v4','interface-full-source-harness-v3','interface-full-source-harness-v4','interface-cli-stops-root-v3','interface-cli-stops-root-v4','interface-proof-actual-independent-review-v2']:
 for p in sorted((B/n).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:add(p,n+'/'+p.relative_to(B/n).as_posix())
for n in ['class_view_runner_v1.py','accept_interface_focus_v2.py','run_interface_cli_stops_v4.py','accept_interface_matrix_v1.py','accept_interface_cli_and_next_repro_v1.py','interface-cli-v3-invalid-depth-override.json','archive_interface_local_v1.py','interface-baseline-input-review-root-v1.json','interface-proof-old-root-acceptance-v1.json','interface-proof-unit-root-acceptance-v4.json','interface-focused-root-acceptance-v4.json','interface-proof-initial-failure-review-v1.json','interface-proof-initial-failure-review-v2.json','interface-proof-initial-failure-review-v3.json','interface-focused-v1-harness-failure.json','interface-focused-v2-clippy-failure.json','interface-focused-v3-jdk-environment-failure.json','interface-full-source-v3-recorder-failure.json','interface-full-source-root-acceptance-v1.json','interface-cli-stops-root-acceptance-v4.json','interface-focused-independent-review-v1.json']:
 add(B/n,'root/'+n)
for n in ['guard.py','target_scan.py','workspace_runner.py']:add(B.parent/'ordinary-try-list-20261014/tools-prep'/n,'tools/'+n)
for n in ['src/facade.rs','crates/jarde-java/src/report.rs','tests/interface_proof_stops.rs']:add(R/n,'source/'+n)
m={'schema':'interface-proof-local-evidence-v1','product_parent':'e8c749252a71a857838d0cb854f5a6d80a5c2704','scope':'local evidence only; product own CI/full workspace pending; all historical failed attempts preserved','payloads':[{'path':n,'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()} for n,z in sorted(files.items())]};files['manifest.json']=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode();O.mkdir(parents=True);p=O/'capture.tar.gz'
with tarfile.open(p,'w:gz') as t:
 for n,z in sorted(files.items()):
  x=tarfile.TarInfo(n);x.size=len(z);x.mode=0o644;x.mtime=0;t.addfile(x,io.BytesIO(z))
with tarfile.open(p,'r:gz') as t:
 assert len(t.getmembers())==len(files)
 for x in t:assert x.isfile() and t.extractfile(x).read()==files[x.name]
a={'status':'accepted_local_archive_integrity','payloads':len(files)-1,'members_reopened':len(files),'archive':{'path':'capture.tar.gz','bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},'own_ci_accepted':False};(O/'archive-review.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a))
