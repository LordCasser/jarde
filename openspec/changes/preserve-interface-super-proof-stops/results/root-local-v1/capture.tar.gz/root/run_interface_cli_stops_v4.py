from pathlib import Path
import importlib.util,json,os,hashlib
B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');R=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');H=B/'interface-full-source-harness-v4/run-interface-v1';O=B/'interface-cli-stops-root-v4';assert not O.exists();assert not(R/'target').exists()
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
h=load('interface_harness',B/'interface-full-source-harness-v4/run_interface_full_source_harness.py');cli=B/'jarde-cli-interface-proof-v4';receipt=B/'interface-proof-focused-root-v4/execution.json';binding=h.verify_cli(cli,receipt)
hj=json.loads((H/'harness-receipt.json').read_text());assert hj['status']=='expected_command_outcomes_observed_pending_independent_acceptance' and hj['source_and_tool_inputs_unchanged'] and hj['target_absent']
jars=sorted(p for p in (H/'retained-temporary').rglob('Probe.jar') if p.parent.name=='inherited-case');assert len(jars)==2
jar=jars[0];inputs=[Path(__file__),cli,receipt,H/'harness-receipt.json',jar];before=[h.pin(p) for p in inputs];O.mkdir();g=load('interface_cli_guard',h.GUARD_PATH);s=load('interface_cli_scan',h.SCAN_PATH);g.ROOT=R;g.OUT=O;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.target_bytes=lambda:s.target_bytes(R);g.expected_test_summaries=lambda i,d:None;g.ENV_VALUES={};g.command_stream=lambda path:h.pin(Path(path));env={k:v for k,v in os.environ.items() if k in ['HOME','LANG','LC_ALL']};env['PATH']='/usr/bin:/bin';rows=[]
commands=[['recover','--input',str(jar),'--class-name','Probe','--method-name','value','--descriptor','()I','--budget','class_headers=2','--format','json','--evidence','all'],['class-source','--input',str(jar),'--class','Probe','--budget','class_headers=2','--format','json','--evidence','all']]
record={'status':'running','cli_binding':binding,'source_input_manifest_before':before,'commands':rows,'scope':'public counted ClassHeaders proof stop consumption; unchanged retained inherited fixture'}
def save(): (O/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
save()
try:
 for i,args in enumerate(commands,1):
  row=g.run_command(i,[str(cli)]+args,env);rows.append(row);save();assert row['exit_code']==4 and row['guard_stop'] is None
  data=json.loads(Path(row['streams']['stdout']['path']).read_text());(O/f'{i}.parsed.json').write_text(json.dumps(data,indent=2)+'\n')
 record['status']='observed_expected_cli_exits_pending_semantic_acceptance'
except BaseException as e:record['status']='failed';record['error']=str(e)
finally:
 record['source_input_manifest_after']=[h.pin(p) for p in inputs];record['inputs_identical']=before==record['source_input_manifest_after'];record['target_absent']=not(R/'target').exists();save()
assert record['status']=='observed_expected_cli_exits_pending_semantic_acceptance' and record['inputs_identical'] and record['target_absent']
