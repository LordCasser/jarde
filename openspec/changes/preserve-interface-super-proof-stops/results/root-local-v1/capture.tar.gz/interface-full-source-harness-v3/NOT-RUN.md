# 尚未运行：interface full-source harness v3

v3独立缓存保留v1、v2文件不变。只在原始 `accept-jarde.py` 执行前新增两条工具版本探针：`java -version` 和 `javac -version`。探针通过同一5 GiB/1 GiB/1秒守卫recording器执行，保存原始流、argv、cwd、有效环境及退出状态，且要求两项均为exit 0；guard停止或非零立即记失败并跳过原测试，避免误计作负例通过。探针先运行在固定JDK23.0.1优先PATH/JAVA_HOME下。它们不改变原验收脚本argv。

静态核对确认原脚本不变：四个合法完整源码编译运行正例（`InterfaceSuperProbe`、abstract fixture 的default与inherited `Probe`、`DefaultChild`）均在 `-g` 与 `-g:none` 两种debug模式运行；并保留缺失默认实现、同名重载、冗余直接接口、effectful参数、abstract owner、中间abstract owner、superclass直接接口及祖先接口八种拒绝控制。原Java/Runner/oracle及每项断言和预期输出未删改。

此前v2的递归fixture pins、strict frozen CLI/build receipt验证、guard-stop fail-closed语义、source/tool/CLI/receipt前后pin以及完整持久化输出逐文件manifest均保留。运行时必须使用新鲜 `--out`，CLI build receipt须精确匹配并证明 `expected_command_outcomes_observed_pending_independent_acceptance`、source before/after相同、target absent、`frozen_cli`路径/bytes/SHA及0555。

本目录尚未运行；未调用Git/Cargo/JDK/产品CLI。
