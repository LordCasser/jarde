#!/usr/bin/env python3
"""Run the unchanged full-source interface-super acceptance under guarded recording.

This harness is prepared but intentionally not run by the review agent.
"""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, locale, os, runpy, shutil, subprocess, sys, tempfile
from pathlib import Path

ROOT = Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde').resolve()
CHANGE = ROOT / 'openspec/changes/prove-interface-super-source-legality'
SCRIPT = CHANGE / 'accept-jarde.py'
EVIDENCE = ROOT / 'openspec/evidence/java-syntax-2026-09-25'
OLD = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools')
JDK_MANIFEST = OLD / 'jdk-manifest.json'
JDK23 = OLD / 'jdk23/jdk-23.0.1'
GUARD_PATH = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/guard.py')
SCAN_PATH = Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools-prep/target_scan.py')
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3
OUTPUT_BASE = Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015/interface-full-source-harness-v3').resolve()


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def pin(path: Path) -> dict:
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load recorder module {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def recursive_dicts(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from recursive_dicts(child)
    elif isinstance(value, list):
        for child in value:
            yield from recursive_dicts(child)


def verify_cli(cli: Path, receipt_path: Path) -> dict:
    receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
    actual = pin(cli)
    if receipt.get('status') != 'expected_command_outcomes_observed_pending_independent_acceptance':
        raise RuntimeError('build receipt does not have the required accepted command-outcome status')
    before = receipt.get('source_manifest_before')
    after = receipt.get('source_manifest_after')
    if not isinstance(before, list) or before != after:
        raise RuntimeError('build receipt source_manifest_before/after are missing or differ')
    if receipt.get('target_absent') is not True:
        raise RuntimeError('build receipt does not prove target_absent=true')
    frozen = receipt.get('frozen_cli')
    if not isinstance(frozen, dict):
        raise RuntimeError('build receipt lacks its exact frozen_cli record')
    expected_path = Path(frozen.get('path', '')).resolve()
    if (expected_path != cli.resolve() or frozen.get('bytes') != actual['bytes']
            or frozen.get('sha256') != actual['sha256'] or frozen.get('mode') != '0555'):
        raise RuntimeError('frozen_cli path/bytes/SHA256/mode does not exactly match the supplied CLI')
    mode = cli.stat().st_mode & 0o777
    if mode != 0o555:
        raise RuntimeError(f'frozen CLI filesystem mode is {mode:04o}, expected 0555')
    return {'receipt': pin(receipt_path), 'cli': actual, 'receipt_status': receipt['status'],
            'source_manifest_count': len(before), 'source_manifest_identical': True,
            'target_absent': True, 'frozen_cli_record': frozen, 'filesystem_mode': f'{mode:04o}'}


def input_paths() -> list[Path]:
    paths = [SCRIPT, Path(__file__).resolve()]
    for group in ('redundant-interface-super', 'abstract-interface-super', 'superclass-redundant-interface-super'):
        folder = EVIDENCE / group
        paths.extend(sorted(p for p in folder.rglob('*') if p.is_file() and (p.suffix == '.java' or p.name == 'replay.py')))
    paths.extend([JDK_MANIFEST, GUARD_PATH, SCAN_PATH])
    manifest = json.loads(JDK_MANIFEST.read_text(encoding='utf-8'))
    leg = next(row for row in manifest['legs'] if row['leg'] == 'javac23')
    for tool in ('java', 'javac', 'javap'):
        paths.append(Path(leg['jdk_tools'][tool]['path']))
    return sorted(set(p.resolve() for p in paths))


class PersistentTemporaryDirectory:
    """TemporaryDirectory-compatible context manager that keeps produced evidence."""
    def __init__(self, prefix='tmp-', dir=None, **kwargs):
        if kwargs:
            raise TypeError(f'unsupported TemporaryDirectory kwargs: {sorted(kwargs)}')
        self.path = Path(tempfile.mkdtemp(prefix=prefix, dir=dir))
    def __enter__(self):
        return str(self.path)
    def __exit__(self, exc_type, exc, tb):
        return False


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--cli', type=Path, required=True, help='frozen final Jarde CLI')
    ap.add_argument('--receipt', type=Path, required=True, help='build receipt pinning that CLI')
    ap.add_argument('--out', type=Path, required=True, help='new, persistent output directory')
    args = ap.parse_args()
    cli, receipt, out = args.cli.resolve(), args.receipt.resolve(), args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing to overwrite output: {out}')
    if not out.is_relative_to(OUTPUT_BASE):
        raise SystemExit(f'output must remain under {OUTPUT_BASE}')
    if not cli.is_file() or cli.is_symlink() or not os.access(cli, os.X_OK) or not receipt.is_file():
        raise SystemExit('CLI/build receipt missing, CLI not executable, or CLI is a symlink')
    if (ROOT / 'target').exists():
        raise SystemExit('fresh-target preflight failed: target must be absent')
    if shutil.disk_usage(ROOT).free < FREE_LIMIT:
        raise SystemExit('5 GiB free-space preflight failed')
    if not SCRIPT.is_file() or not JDK_MANIFEST.is_file() or not GUARD_PATH.is_file() or not SCAN_PATH.is_file():
        raise SystemExit('required script/manifest/guard inputs missing')
    manifest = json.loads(JDK_MANIFEST.read_text(encoding='utf-8'))
    leg = next(row for row in manifest['legs'] if row['leg'] == 'javac23')
    tool_pins = {}
    for tool in ('java', 'javac', 'javap'):
        expected = leg['jdk_tools'][tool]
        path = Path(expected['path']).resolve()
        actual = pin(path)
        if actual['bytes'] != expected['bytes'] or actual['sha256'] != expected['sha256']:
            raise RuntimeError(f'JDK 23 manifest mismatch for {tool}')
        tool_pins[tool] = actual
    cli_binding = verify_cli(cli, receipt)
    inputs = sorted(set(input_paths() + [cli, receipt]))
    before = [pin(p) for p in inputs]
    out.mkdir(parents=True, exist_ok=False)
    retained = out / 'retained-temporary'
    retained.mkdir()
    (out / 'input-manifest-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')
    guard = load_module('interface_full_source_guard', GUARD_PATH)
    scanner = load_module('interface_full_source_target_scan', SCAN_PATH)
    guard.ROOT = ROOT
    guard.OUT = out
    guard.FREE_LIMIT = FREE_LIMIT
    guard.TARGET_LIMIT = TARGET_LIMIT
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.expected_test_summaries = lambda _index, _data: None
    guard.ENV_VALUES = {}
    env = {k:v for k,v in os.environ.items() if k in ('HOME','TMPDIR','LANG','LC_ALL')}
    for key in ('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','RUST_MIN_STACK','CARGO_TARGET_DIR'):
        env.pop(key, None)
    env['JAVA_HOME'] = str(JDK23.resolve())
    env['PATH'] = str((JDK23/'bin').resolve()) + os.pathsep + '/usr/bin:/bin'
    env.setdefault('LANG','C.UTF-8')
    record = {'schema':'interface-full-source-harness-v3','status':'running','scope':'unchanged accept-jarde.py; all original assertions, Java sources, Runner/oracle, command args and expected statuses retained','workspace_root':str(ROOT),'acceptance_script':pin(SCRIPT),'cli_build_binding':cli_binding,'jdk_manifest':pin(JDK_MANIFEST),'jdk23_tools':tool_pins,'recorder_dependencies':{'guard':pin(GUARD_PATH),'target_scan':pin(SCAN_PATH)},'source_input_manifest_before':before,'environment':env,'stripped_foreign_environment':['JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','RUST_MIN_STACK','CARGO_TARGET_DIR'],'guard':{'minimum_free_bytes':FREE_LIMIT,'maximum_target_bytes':TARGET_LIMIT,'poll_seconds':1,'process_group_termination':True},'command_count':0,'commands':[],'retained_temp_root':str(retained),'note':'prepared harness; this run receipt is written only when root invokes it'}
    def save():
        tmp=out/'harness-receipt.json.tmp';tmp.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');tmp.replace(out/'harness-receipt.json')
    index = 0
    def recorded_command(*args):
        nonlocal index
        argv=[str(x) for x in args];index+=1
        row=guard.run_command(index,argv,env)
        row['argv_exact']=argv
        row['cwd']=str(ROOT)
        row['environment']=dict(env)
        row['guard_status']='stopped' if row['guard_stop'] is not None else 'clear'
        record['commands'].append(row);record['command_count']=len(record['commands']);save()
        if row['guard_stop'] is not None:
            raise RuntimeError(f'guard stopped child command {index}: {row["guard_stop"]}')
        enc=locale.getpreferredencoding(False) or 'utf-8'
        stdout=Path(row['streams']['stdout']['path']).read_bytes().decode(enc,errors='strict')
        stderr=Path(row['streams']['stderr']['path']).read_bytes().decode(enc,errors='strict')
        return subprocess.CompletedProcess(argv,row['exit_code'],stdout,stderr)
    ns=runpy.run_path(str(SCRIPT),run_name='interface_acceptance_unmodified')
    # runpy returns a mapping; patch the function's actual globals, not that copy.
    script_globals=ns['main'].__globals__
    script_globals['command']=recorded_command
    script_globals['TemporaryDirectory']=lambda prefix='tmp-', **kw: PersistentTemporaryDirectory(prefix=prefix,dir=retained,**kw)
    def recorded_version_probe(label: str, argv: list[str]):
        index=len(record['commands'])+1
        row=guard.run_command(index,argv,env)
        row['label']=label
        row['expected_exit_code']=0
        row['argv_exact']=argv
        row['cwd']=str(ROOT)
        row['environment']=dict(env)
        row['guard_status']='stopped' if row['guard_stop'] is not None else 'clear'
        row['version_probe']=True
        record['commands'].append(row);record['command_count']=len(record['commands']);save()
        if row['guard_stop'] is not None:
            raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        if row['exit_code'] != 0:
            raise RuntimeError(f'{label} returned {row["exit_code"]}; expected 0; raw streams retained')
        return row
    old_argv=sys.argv
    try:
        sys.argv=[str(SCRIPT),'--jarde-cli',str(cli)]
        save()
        try:
            recorded_version_probe('jdk23-java-version', ['java','-version'])
            recorded_version_probe('jdk23-javac-version', ['javac','-version'])
            record['version_probes']={'java':'exit 0; see command raw streams','javac':'exit 0; see command raw streams'}
            save()
            ns['main']()
            record['status']='expected_command_outcomes_observed_pending_independent_acceptance'
        except BaseException as exc:
            record['status']='failed_original_assertion_or_recorder'
            record['error']=f'{type(exc).__name__}: {exc}'
    finally:
        sys.argv=old_argv
        after=[pin(p) for p in inputs]
        record['source_input_manifest_after']=after
        record['source_and_tool_inputs_unchanged']=before==after
        record['target_absent']=not (ROOT/'target').exists()
        payloads=[]
        for item in sorted(retained.rglob('*')):
            if item.is_symlink():
                payloads.append({'path':item.relative_to(retained).as_posix(),'type':'symlink','target':os.readlink(item)})
            elif item.is_file():
                payloads.append({'path':item.relative_to(retained).as_posix(),'bytes':item.stat().st_size,'sha256':sha(item)})
        payload_manifest={'schema':'interface-full-source-retained-payloads-v1','files':payloads}
        payload_path=out/'retained-payload-manifest.json'
        payload_path.write_text(json.dumps(payload_manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        record['retained_payload_manifest']={'path':str(payload_path),'bytes':payload_path.stat().st_size,'sha256':sha(payload_path),'file_count':sum('bytes' in x for x in payloads),'symlink_count':sum(x.get('type')=='symlink' for x in payloads)}
        record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        if not record['source_and_tool_inputs_unchanged'] or not record['target_absent']:
            record['status']='failed_integrity_or_cleanup'
        save()
    return 0 if record['status']=='expected_command_outcomes_observed_pending_independent_acceptance' and record['target_absent'] and record['source_and_tool_inputs_unchanged'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
