interface Middle extends Ancestral { int value(); }
