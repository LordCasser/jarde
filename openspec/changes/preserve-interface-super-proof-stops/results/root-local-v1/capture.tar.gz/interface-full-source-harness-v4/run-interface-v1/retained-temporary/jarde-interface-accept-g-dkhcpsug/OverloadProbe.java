interface Overloaded {
  default int value(int n) { return n + 9; }
  default int value(long n) { return (int) n + 19; }
}
public final class OverloadProbe implements Overloaded {
  public int value() { return Overloaded.super.value(1); }
  public static void main(String[] args) {
    System.out.println(new OverloadProbe().value());
  }
}
