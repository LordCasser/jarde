// jarde: presentation of `DefaultChild` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
interface DefaultChild extends DefaultParent {
    public default int value() {
        // @method value()I
        // @declaration an interface's default method of `DefaultChild`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        return DefaultParent.super.value() + 1;
    }
}
