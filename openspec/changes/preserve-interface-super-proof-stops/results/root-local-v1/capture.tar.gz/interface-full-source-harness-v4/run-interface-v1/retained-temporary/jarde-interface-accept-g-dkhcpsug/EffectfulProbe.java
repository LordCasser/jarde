interface EffectParent { default int value(int x) { return x + 3; } }
interface EffectChild extends EffectParent {}
public final class EffectfulProbe implements EffectParent, EffectChild {
  static int count;
  static int tick() { count++; return 2; }
  public int value() { return EffectChild.super.value(tick()); }
  public static void main(String[] args) {
    System.out.println(new EffectfulProbe().value() + ":" + count);
  }
}
