interface Ancestral { default int value() { return 3; } }
interface Middle extends Ancestral {}
interface Leaf extends Middle {}
public final class IntermediateProbe implements Leaf {
  public int value() { return Leaf.super.value(); }
  public static void main(String[] args) {
    System.out.println(new IntermediateProbe().value());
  }
}
