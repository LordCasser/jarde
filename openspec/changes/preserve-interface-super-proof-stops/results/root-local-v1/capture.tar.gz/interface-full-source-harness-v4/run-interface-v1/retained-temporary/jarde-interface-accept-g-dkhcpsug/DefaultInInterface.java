interface DefaultParent { default int value() { return 3; } }
interface DefaultChild extends DefaultParent {
  default int value() { return DefaultParent.super.value() + 1; }
}
class DefaultRunner implements DefaultChild {
  public static void main(String[] args) {
    System.out.println(new DefaultRunner().value());
  }
}
