# CF-11 fixed-test next-baseline audit (read-only)

## Finding

Do **not** collect a new original baseline for `TestNestedLoops3`: the 2026-10-18 ledger README predates a completed, accepted full-class comparison. The exact source SHA recorded there (`7152231b…`) is in `recover-prefixed-exceptional-retry-loops/results/README.md`; that evidence reports original full source, dual profiles, original oracle, complete Jarde/JADX request matrices and complete-source rebuild/runtime matrices. Its final section says 7/7 and product CI accepted. Treat the older `cf11-next-baseline-root-v1/README.md` “not found” statement as superseded, not as a remaining failure.

The fixed CF-11 inventory contains seven tests (control-flow.md:96). Durable evidence already covers all seven with a full source/class comparison or a full original/generated source matrix:

| Fixed source | Upstream source SHA-256 | Durable evidence / current disposition |
|---|---|---|
| TestNestedLoops | `4897fd18…` | `cf11-testnestedloops-baseline-root-v1/README.md`; later typed-foreach complete original matrix in `recover-typed-list-foreach-elements/results/README.md`; current exact golden delta is the separate Object-argument wrapper work. |
| TestNestedLoops2 | `795ea73a…` | `cf11-testnestedloops2-baseline-root-v1/README.md`; full original/JADX/Jarde class and runtime matrix. |
| TestNestedLoops3 | `7152231b…` | `recover-prefixed-exceptional-retry-loops/results/README.md`; full accepted original and generated matrices. |
| TestNestedLoops4 | `b84dbf99…` | `recover-proved-nested-loop-side-exits/verification.md`; full three-way baseline and accepted narrow product comparison. |
| TestNestedLoops5 | `0be29d14…` | `recover-proved-loop-arm-returns/results/README.md`; full original/generated matrices and accepted product. |
| TestSequentialLoops | `7b9826d7…` | `cf11-sequential-loops-baseline-root-v1/capture.tar.gz` (84-member full source/JADX/Jarde capture) and `cf11-sequential-loops-current-api-root-v1/capture.tar.gz` (8 API captures). The archived execution receipts still say `captured-pending-independent-review`; this is a review/acceptance gap, not evidence that no baseline was collected. Do not recollect until those receipts are reconciled. |
| TestSequentialLoops2 | `adb34f80…` | `cf11-sequential-loops2-baseline-root-v1/README.md` plus `cf11-sequential-loops2-generated-matrix-root-v2/README.md`; full original/generated source matrix accepted. |

Source hashes are truncated here for readability; full digests are in `source-pins.json`. Fixed test inventory and names are from `openspec/evidence/jadx-feature-inventory-2026-09-27/control-flow.md`.

## Next action

There is no remaining fixed CF-11 original with a missing capture to prioritize. The only unelevated item in the table is `TestSequentialLoops` review status; first independently review its frozen captures if that test becomes relevant. The current accepted high-level support includes the nested/side-exit, conditional-value, hoisted/typed foreach, local binding and ancestor-iterator narrow recoveries; the next exact `TestNestedLoops` equals/remove(Object) cast-presentation delta is separately in flight. CF-11 remains partially complete; this memo changes no ledger or completion count.

## Boundaries and evidence handling

I did not execute a collector, Jarde/JADX/JDK/Cargo/Git or network command and made no repository edits. “Full baseline exists” means a pinned full-source/class capture and/or source rebuild matrix exists; it does not imply every golden assertion is textually matched or every receipt has current independent acceptance. In particular, TestNestedLoops has known remaining presentation deltas; do not confuse them with a missing baseline. Historical failures remain historical and are not reclassified here.
