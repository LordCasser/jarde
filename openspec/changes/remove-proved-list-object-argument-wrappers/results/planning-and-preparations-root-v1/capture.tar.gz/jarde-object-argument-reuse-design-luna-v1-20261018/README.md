# Object argument wrapper reuse design

Read-only design review for the fixed `TestNestedLoops` shape. Atlas was opened on the current repository and scoped searches were run for the facade proof and the AST projector. Atlas found `GenericCallProjectionState::project_generic_call_arguments` (source line 729) and `project_class_source_invoke_argument_edits` (report line 3042), but did not return the exact facade proof symbol despite the file being indexed. I treated that as an index coverage limitation and checked the live source directly; the scoped source search found the proof at line 13865.

Source SHA-256 pins:

- `src/facade.rs`: `cdbdb4d2ed652055c501072bb06dfad45493589b2ef7710cf799d4f77a430fc6`
- `src/class_source.rs`: `ad8e176f5ebfef4a68d563f7d22699449982d4fa0c0ad9c09a5ecacd75a4780f`
- `crates/jarde-java/src/report.rs`: `7f95ecec71e05b6a167d721bbe657660d55c646966e3638764c042b3b66272fb`
- `tests/structured_list_generic_bodies.rs`: `2aa41c5c61addd03a65264703031c18be7c5dfd9e51786968627f84cd13c421b`

## Existing proof boundary

`src/facade.rs:12943` recognizes `List.remove(Object)` as contract kind 2, explicitly distinguishing it from `remove(int)`. The generic List body proof starts at `:13865`. For `add(Object)` (kind 1), lines `:14164-14321` require a direct local argument, unique declaration/assignment, a physical `checkcast`, a unique `Iterator.next()` value feeding that cast, the cast output stored once, closure of local writes, and a call-site local load whose SSA value reaches the invocation argument. The source declaration's reference type is collected into `type_uses` at `:14315-18`; this is the evidence that may contribute to `List<E>` inference. The `remove(Object)` kind 2 currently passes receiver/contract checks but does not enter that argument proof branch, so it does not infer E from its argument. Keep that distinction.

The typed foreach proof at `src/facade.rs:13549` already has a narrower next→physical-cast→store chain and ties it to a `List<E>` parsed from the method Signature. It is useful as corroborating E evidence, but does not by itself prove the local argument value used at an equals/remove call. `generic_list_foreach_binding_slot_closed` at `:13056` closes the loop target local's physical loads/writes, not arbitrary invocation arguments.

## Smallest reuse

Factor the add argument's physical local-cast/store/load validation into a private helper returning the actual local declaration type only after the exact BCI/SSA chain closes. Keep call-contract policy outside that helper:

- `add(Object)` remains required evidence for `List<E>`: the helper's returned type can feed `type_uses` as today.
- `String.equals(Object)` and `List.remove(Object)` are optional presentation cleanup candidates. Require an exact descriptor/target and argument index, the same direct local/cast/store/load chain, and a type fact consistent with the already parsed `List<String>` element type. Do not append either call's argument type to `type_uses`; `remove(Object)` is non-generic and cannot prove E.
- For `remove(Object)`, retain the wrapper whenever the local type could select `remove(int)` by unboxing (the existing Integer controls demonstrate this). The fixed String case is safe because String cannot unbox. For equals, limit to the exact `String.equals(Object)` target; its overload contract has no primitive-index analogue.

If an equals/remove call lacks a unique local, declaration, physical cast, or exact SSA chain, emit no optional removal and retain the otherwise valid List/foreach projection. Do not return `None` from the required List proof merely because this optional helper cannot prove a cleanup. Keep raw `RecoveryReport.text` and its source map untouched.

A descriptor-only Builder-side edit is insufficient: it cannot establish the exact AST wrapper or its origin. A new global pass would duplicate the retained AST, same-run invoke census, and staging/final closure. The narrow helper reuses the existing physical proof in the current transaction, while making the type-inference vs. cleanup policy explicit.

## Transaction and tests

The existing staging path (`src/facade.rs:17249-17289`) collects List proofs/removals and typed foreach edits; it invokes `project_class_source_generic_edits` at `:17605-17625` when any edit exists. Final revalidation recomputes List proofs and typed edits at `:17776-17824`, compares the staged List proof at `:17835`, then compares the final presentation-removal set against the staged set at `:18087-18088`. Any new optional removals must be recomputed and compared there too. The exact wrapper predicate in `report.rs:5612-5671` verifies call BCI/opcode/target, descriptor's erased Object parameter, wrapper cast type, source origins, and wrapper provenance. The edit transaction at `:3042-3059` applies removals with other edits on a cloned AST; `:3340-3366` unwraps only the selected argument after the exact predicate, and `:3829-3836` requires each requested removal to match once.

That transaction's all-or-nothing behavior means optional proof misses must be represented as *no edit*. If a supposedly proved optional edit fails exact application, do not let it invalidate the core generic/typed projection: either prevalidate/filter optional removals against the same retained AST before mutation, or apply optional cleanup as a second speculative projection whose failure falls back to the already successful core projection. Stop/budget errors still propagate; do not publish partial state.

Permanent public coverage belongs in the existing fixed fixture tests in `tests/structured_list_generic_bodies.rs`: the current String method assertions around `:1060-1110` explicitly require `l1.remove((Object)s2)` to remain; change that expectation only for the proven String case and add an explicit equals(Object) absence assertion. Preserve Integer overload controls at `:998-1011`, `:1168-1180`, and `:1235-1245`, which require remove(Object) wrappers to remain and reject accidental `remove(int)` selection. Add a null/unknown or mismatched local control if that shape is already in the existing matrix; it must retain the wrapper while still preserving the List/foreach result. Test raw method/report text and source-map equality as those tests already do. Internal AST tests in `report.rs` should separately verify exact target/argument matching and no mutation on stale edits; they are not JVM evidence.

## Limits

This review did not run Cargo, JDK, CLI, or reproduce the fixture. Atlas symbol search omitted the exact facade proof, so live-source lines and hashes are the authority for these findings. The existing removal transaction is globally atomic; satisfying optional fallback requires explicit behavior at the call-site or projector boundary, not merely a best-effort proof returning an empty edit list.
