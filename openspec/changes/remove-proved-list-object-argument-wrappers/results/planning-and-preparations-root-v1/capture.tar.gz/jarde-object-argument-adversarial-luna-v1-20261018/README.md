# Adversarial architecture note: exact equals/remove Object presentation wrappers

Read-only snapshot: Jarde `src/facade.rs`, `src/class_source.rs`, and `crates/jarde-java/src/report.rs` (hashes in `pins.json`). No source was changed and no Cargo/JDK/CLI/Git/network operation was run. The root's Java compiler controls remain pending; this note makes no compile/runtime claim.

## Current trust boundary

`generic_list_parameter_types` parses the method's real `Signature`, checks it against the descriptor slots, and selects only exact `List<ConcreteReference>` parameters (`src/facade.rs:12957–13054`). `generic_list_member_contract` admits only the exact `List` erased methods; `remove(int)` is absent (`12943–12954`). Keep the element type sourced from that Signature gate. Never infer `List<E>` from the argument passed to `remove(Object)`.

The existing `prove_generic_list_parameter_body` closes every selected parameter read and List receiver use against physical invoke facts and retained AST sites (`13865–14086`). For `add(Object)` it has a detailed direct-local proof (`14087–14323`): exact AST wrapper/child, unique declaration and assignment, expected cast type, loop-scope anchor, physical `CHECKCAST`, unique `Iterator.next()` result flowing into that cast, one store to the local slot, and the local load flowing to exactly that invocation argument. It adds a `ClassSourceInvokeArgumentPresentationCast` only after these checks. The accumulated actual add types are separately compared with the `List<E>` signature in `ordinary_parameterized_declaration` (`src/class_source.rs:7424–7544`). Do not let new remove-argument evidence populate those actual types.

## Smallest safe extension

Add a separate optional evidence pass for only these exact physical targets and argument zero:

- `java/lang/String.equals(Ljava/lang/Object;)Z` on `invokevirtual` (`0xb6`); require the receiver source to be the exact String local, and prove the argument local's static String type by the existing `next → CHECKCAST String → store → load → argument` chain.
- `java/util/List.remove(Ljava/lang/Object;)Z` on `invokeinterface` (`0xb9`); require a uniquely associated receiver parameter whose parsed Signature is exactly `List<String>`, plus the same physical String-local argument proof. The `(Object)` cast is only a presentation wrapper; do not derive the List element type from `s2`. With a String argument, removing the upcast still selects `remove(Object)`, not `remove(int)`.

Reuse/factor the current narrow local-cast/store/load proof rather than adding generic cast stripping. A receiver mismatch, unknown type, declaration ambiguity, extra write, stale SSA fact, missing `next` link, non-exact target/descriptor, or AST shape uncertainty means “no optional edit for this call”; retain the wrapper and still allow the independently valid generic `List<E>` and typed-foreach projections. The fixture's `String` receiver is exact; do not generalize to arbitrary `equals` receivers, where a subtype can overload `equals(String)` alongside `equals(Object)`.

## Exact-once projection and fallback behavior

The existing AST projection accepts precise removal keys `{call_bci, opcode, target, argument_index}` (`report.rs:1461–1469`). Before mutation it rejects duplicate `(call_bci, argument_index)` keys and conflicting call identities at one BCI; it validates the AST call inventory. A wrapper is removable only when its descriptor parameter is the exact reference type and its AST presentation/origin chain agrees with the physical call site (`report.rs:3242–3281, 3315–3367, 5612–5667`). Each requested removal must match exactly one AST argument (`removed[] == 1`, `3829–3831`); zero or multiple matches make the projection return `None`. Thus the projector guarantees exact-once for requested keys, but does not treat an absent/missed optional key as a successful no-op.

Consequently, prevalidate optional evidence and enqueue only fully proven keys. A normal proof miss omits that key; it must not return `None` for the required list-body proof. If a queued key fails projector validation or stage/final revalidation differs, preserve the current fail-closed behavior: reject/rollback the generic-call component rather than publish a partial transaction. Stage and final independently recompute the same removal vector and require equality (`facade.rs:17102–17111, 17622–17677, 17776–17837, 18085–18092`). AST edits share one clone/re-emission with existing list removals, overload casts, and typed foreach edits (`facade.rs:17604–17670; report.rs:3052–3083`). The projection state checks the original recovered artifact/emission before replacing the staged text (`class_source.rs:730–790`).

## Budget and Stop obligations

Bound and charge the optional scan before allocating candidate lists, then poll/charge while walking invocation rows, argument facts, local declarations/assignments, body sites, scope anchors, and origin rows. Charge `IrItems` for owned keys/collections and copied identities/types, and `OutputBytes` for any copied or emitted type/text bytes; the existing AST projector already charges edit counts, AST traversal/cloning, and emission. Use the same Stop propagation path as the existing required proof. Ordinary absence/ambiguity is a local optional miss; cancellation or budget exhaustion is an operation Stop and must propagate, never be swallowed as “keep wrapper.” Staged-state rollback already restores unpublished members on Stop (`facade.rs:18232–18313`).
