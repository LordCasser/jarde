# v2 static correction record

- Driver identity was order-sensitive in v1. The actual explicit-cast line is `CASE class=controls.ExplicitCastCases method=equalsExplicitCast input=valid-string descriptor=...`; the parser now reads named tokens after the `CASE` prefix.
- Compare the full method dictionaries directly after reading frozen class bytes. This passed for the original controls class and four driver classes; v2 keeps that strict check. The two parsers encode fields differently, so v2 compares their field triples.
- The expected identities/order and the valid-string, wrong-integer (`ClassCastException`), and null cast observations were exercised with eight synthetic output lines. This validates parser shape only, not Java behavior.
- No collector/toolchain run occurred.
