# Object-argument controls baseline collector v2 (prepared, not executed)

This is a schema/identity correction to v1; v1 remains intact. The collector still captures three isolated complete target families across four javac8/23 release-8 debug/none profiles, original 8-row driver runs on both VMs, per-target wrong-CodeSource controls, Jarde `default`/`all` reports, complete-closure JADX output, and byte-exact generated-source compilation with both JDKs. Generated VM replay remains deferred and is not claimed. It records all command arguments/environment/raw streams, source/external/output pins, resource guards, class/member inventories, and independently parsed physical Code/BCI facts.

The driver identity parser now tokenizes actual output fields instead of assuming field order. In particular, explicit-cast rows put `input=...` between `method=...` and `descriptor=...`; v2 accepts and validates that actual shape, exact class/method order, descriptors, and the valid/wrong/null cast observations. `facts()` retains the stronger direct method-record equality after static comparison showed both parsers return the same method dictionaries on frozen class bytes; fields are compared as normalized `(name, descriptor, access)` triples because the parser schemas differ there. Full independent Code facts remain recorded unchanged.

Static-only checks performed for this correction:

- Both parsers read the frozen original `IteratorAncestorCases.class` and all four frozen driver `.class` files; class identity/version and complete method dictionaries agreed without loosening the existing equality check.
- `collect_baseline.py`'s `parse_driver()` accepted eight synthetic rows in the exact current driver output field order, including all three explicit-cast labels and the `ClassCastException` row.
- Python `ast.parse` succeeded. No CLI/JDK/Cargo/network or shared-repository write was performed, and this collector was not executed.

The historical TestNestedLoops positive source/driver/debug class remain pinned as reused evidence only, not a new fixture or rerun. Generated VM replay is deferred so root can select complete successful source/compiler cells and use mixed roots while checking each target CodeSource independently.

Invocation after root review:

```sh
python3 -B collect_baseline.py \
  --cli /private/tmp/jarde-ancestor-iterator-broad-root-v3-20261018/candidate-cli \
  --cli-sha256 26eb321d0810a54328f7880483c6c5a5c2033c2ad747f7b177a51e723e96af52 \
  --out /private/tmp/jarde-object-argument-controls-baseline-root-v2-20261018/capture
```
