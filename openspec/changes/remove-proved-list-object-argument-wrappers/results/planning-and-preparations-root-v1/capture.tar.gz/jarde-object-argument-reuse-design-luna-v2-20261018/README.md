# Object argument wrapper reuse design (v2 correction)

This v2 preserves the scope and source findings of v1 while correcting its unsupported `remove(int)` claim. Java method-invocation applicability considers strict invocation contexts before loose contexts: a reference `Integer` argument can widen to `Object` in the strict phase, while selecting `remove(int)` requires unboxing in a loose phase. The current evidence does not demonstrate that removing `(Object)` from an `Integer` reference selects `remove(int)`. A primitive `int` is a distinct input type and is not the class-source local proved by the existing cast→store→load chain. Any assertion that a reference wrapper must remain to prevent `remove(int)` is withdrawn. JDK 8/23 compile controls remain pending; do not report them as run or passed.

Source SHA-256 pins (same live source snapshot as v1):

- `src/facade.rs`: `cdbdb4d2ed652055c501072bb06dfad45493589b2ef7710cf799d4f77a430fc6`
- `src/class_source.rs`: `ad8e176f5ebfef4a68d563f7d22699449982d4fa0c0ad9c09a5ecacd75a4780f`
- `crates/jarde-java/src/report.rs`: `7f95ecec71e05b6a167d721bbe657660d55c646966e3638764c042b3b66272fb`
- `tests/structured_list_generic_bodies.rs`: `2aa41c5c61addd03a65264703031c18be7c5dfd9e51786968627f84cd13c421b`

## Existing proof boundary

`src/facade.rs:12943` recognizes the exact erased `List.remove(Object)` contract as kind 2 and deliberately distinguishes it from `remove(int)`. The generic List body proof begins at `:13865`. For `add(Object)` (kind 1), lines `:14164-14321` require a direct local argument, unique declaration/assignment, physical `checkcast`, a unique `Iterator.next()` result feeding the cast, the cast output stored once, local-write closure, and a call-site local load whose SSA value reaches the invocation argument. The declaration's reference type is collected into `type_uses` at `:14315-18`; this is evidence that can contribute to `List<E>` inference. `remove(Object)` passes its List receiver/contract checks but does not enter that argument proof branch, so it currently does not infer E from its argument. Keep that distinction.

The typed foreach proof at `src/facade.rs:13549` ties the parsed concrete `List<E>` Signature to the retained header and same-run next/cast/store facts. It does not by itself prove that an arbitrary equals/remove argument is the same local value. `generic_list_foreach_binding_slot_closed` at `:13056` closes the foreach target's physical loads/writes, not every invocation argument.

## Minimal reuse and optionality

Factor the add argument's physical local-cast/store/load validation into a private helper returning an actual source local type only after the exact BCI/SSA chain closes. Keep its policies separate:

- `add(Object)` remains required evidence for `List<E>` inference and may add the helper's type to `type_uses` as it does now.
- `String.equals(Object)` and `List.remove(Object)` cleanup are optional. Require an exact physical call target/descriptor and argument index, the wrapper AST site, and the same direct local plus physical cast→store→load chain. Do not append either argument type to `type_uses`; `remove(Object)` is non-generic and cannot prove E.
- For `remove(Object)`, an already-proved reference argument can be widened to Object in strict applicability. The exact List receiver type and erased target must still be verified, and primitive `int` controls should remain separate. The prior v1 claim that an `Integer` reference could select `remove(int)` via unboxing was unsupported and is withdrawn.
- For equals cleanup, limit the initial scope to the exact `java/lang/String.equals(Object)Z` target from the fixed fixture. The direct local physical proof establishes the argument source; the exact target prevents widening the transformation to unrelated methods.

If the optional helper cannot establish a unique local/declaration/cast/value chain, create no cleanup edit and retain the valid generic/typed projection. Do not reject the required List proof for that reason. Keep raw recovery text and its source map unchanged.

A descriptor-only Builder entry cannot establish the exact retained AST wrapper and origins. A global pass would duplicate the retained AST, same-run invoke census, and staging/final proof. Reusing the physical proof inside the existing List proof boundary, with separate required-inference and optional-cleanup policies, is the smallest fit.

## Transaction and tests

Staging at `src/facade.rs:17249-17289` gathers List removals and typed foreach edits, then calls `project_class_source_generic_edits` at `:17605-17625`. Final revalidation recomputes List proofs at `:17776-17824`, compares them at `:17835`, and checks presentation-removal equality at `:18087-18088`. Any new optional removals must be recomputed and included in that equality check. `report.rs:5612-5671` validates the exact erased-reference wrapper, target/call identity, origin structure, and wrapper provenance. The combined transaction at `:3042-3059` applies removals and other edits on a cloned AST; `:3340-3366` unwraps only the selected argument, while `:3829-3836` requires every requested removal to match exactly once.

Because the projector is all-or-nothing, an optional proof miss must mean no edit. If an optional plan unexpectedly fails exact application, it must not invalidate core generic/typed recovery: prevalidate optional removals before mutation or try them as a second speculative projection and fall back to the successful core projection. Budget/Stop errors still propagate, and no partial AST is published.

Permanent fixture coverage belongs in `tests/structured_list_generic_bodies.rs`, around the current String assertions at `:1060-1110`; they currently require `l1.remove((Object)s2)` to remain and should be updated only after compiler controls confirm behavior. Add a specific equals wrapper assertion there. Existing Integer/reference and primitive overload controls around `:998-1011`, `:1168-1180`, and `:1235-1245` should be reinterpreted with correct overload phases; do not preserve an assertion solely because it predicts reference unboxing. Add actual javac 8 and 23 source-compilation controls for reference `Integer`, `String`, and primitive `int` forms before freezing those expected outputs. Keep raw method/report text and source-map checks, which existing tests already exercise. Internal AST tests should separately reject wrong target/index, mismatched cast chain, and duplicate wrapper matches; they do not establish Java compiler overload behavior.

## Evidence status

Atlas was opened and scoped searches run. It found `GenericCallProjectionState::project_generic_call_arguments` in `src/class_source.rs:729` and `project_class_source_invoke_argument_edits` in report.rs around `:3042`, but omitted the exact facade proof symbol even though live source contains it. Direct source inspection and the SHA pins above are authoritative here. No Cargo, JDK, CLI, or fixture compilation was run for this review; both JDK compiler controls are pending.
