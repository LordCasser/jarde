package controls;

/** A source-level cast on the invocation argument, independent of the loop positive. */
public final class ExplicitCastCases {
    private ExplicitCastCases() { }

    public static final class Receiver {
        public boolean equals(String value) { return "needle".equals(value); }
    }

    public static boolean equalsExplicitCast(Receiver receiver, Object value) {
        return receiver.equals((String) value);
    }
}
