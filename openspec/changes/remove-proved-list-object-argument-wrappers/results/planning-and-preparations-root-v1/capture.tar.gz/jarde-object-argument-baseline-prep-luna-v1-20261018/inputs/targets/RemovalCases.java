package controls;

import java.util.List;

/** Same runtime argument, with source overload selection as the sole varying factor. */
public final class RemovalCases {
    private RemovalCases() { }

    public static boolean removeObject(List<Integer> values, int value) {
        return values.remove((Object) value);
    }

    public static Integer removeInt(List<Integer> values, int value) {
        return values.remove(value);
    }

    /** The selected overload is deliberately left for javac/classfile inspection. */
    public static boolean removeInteger(List<Integer> values, Integer value) {
        return values.remove(value);
    }
}
