#!/usr/bin/env python3
"""Capture isolated Object-argument controls. Preparation only; review before execution."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, re, shutil, sys, zipfile
from pathlib import Path
sys.dont_write_bytecode = True

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
HERE = Path(__file__).resolve().parent
INPUT = HERE / 'inputs'
TARGETS = {
    'RemovalCases': INPUT / 'targets/RemovalCases.java',
    'EqualityCases': INPUT / 'targets/EqualityCases.java',
    'ExplicitCastCases': INPUT / 'targets/ExplicitCastCases.java',
}
DRIVER = INPUT / 'driver/ObjectArgumentDriver.java'
INTERNAL = {name: 'controls/' + name for name in TARGETS}
DRIVER_NAME = 'ObjectArgumentDriver'
PROFILES = ('javac8-debug', 'javac8-no-debug', 'javac23-debug', 'javac23-no-debug')
LEGS = ('javac8', 'javac23')
EVIDENCE = ('default', 'all')
EXPECTED_TARGET_CLASSES = {
 'RemovalCases': {'controls/RemovalCases.class'},
 'EqualityCases': {'controls/EqualityCases.class', 'controls/EqualityCases$Receiver.class'},
 'ExplicitCastCases': {'controls/ExplicitCastCases.class', 'controls/ExplicitCastCases$Receiver.class'},
}
EXPECTED_METHODS = {
 'controls/RemovalCases.class': {('<init>', '()V'), ('removeObject', '(Ljava/util/List;I)Z'),
   ('removeInt', '(Ljava/util/List;I)Ljava/lang/Integer;'), ('removeInteger', '(Ljava/util/List;Ljava/lang/Integer;)Z')},
 'controls/EqualityCases.class': {('<init>', '()V'), ('equalsObject', '(Lcontrols/EqualityCases$Receiver;Ljava/lang/String;)Z'),
   ('equalsString', '(Lcontrols/EqualityCases$Receiver;Ljava/lang/String;)Z')},
 'controls/EqualityCases$Receiver.class': {('<init>', '()V'), ('equals', '(Ljava/lang/Object;)Z'),
   ('equals', '(Ljava/lang/String;)Z'), ('selected', '()Ljava/lang/String;')},
 'controls/ExplicitCastCases.class': {('<init>', '()V'),
   ('equalsExplicitCast', '(Lcontrols/ExplicitCastCases$Receiver;Ljava/lang/Object;)Z')},
 'controls/ExplicitCastCases$Receiver.class': {('<init>', '()V'), ('equals', '(Ljava/lang/String;)Z')},
}
COMPARE = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
MANIFEST = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
MANIFEST_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
PHYSICAL = Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PHYSICAL_SHA = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
REFERENCE = Path('/private/tmp/jarde-ancestor-iterator-controls-baseline-root-v1-20261018/execution.json')
REFERENCE_SHA = '843cbc2aaa79becb6dca8e0da05141532c5c9bff88bbaeefd048c7615b532392'
REFERENCE_ORIGINAL = Path('/private/tmp/jarde-typed-foreach-original-final-root-v1-20261018/execution.json')
REFERENCE_ORIGINAL_SHA = '433b6a723137adb4aed904b2c7935079821def5b1b91f1593630c224bc73f439'
POSITIVE_SOURCE = Path('/private/tmp/jarde-typed-foreach-original-final-root-v1-20261018/source/jadx/tests/integration/loops/TestNestedLoops.java')
POSITIVE_SOURCE_SHA = '4897fd18a15fce6e0abb40dc8afc6c7a3fa9f16e617f3c7e5e88072f6a37309e'
POSITIVE_DRIVER = Path('/private/tmp/jarde-typed-foreach-original-final-root-v1-20261018/driver-source/TestNestedLoopsDriver.java')
POSITIVE_DRIVER_SHA = '4534f142ad673595898a581ebb474a0d2783cbd974b403f8c658e74792e59df0'
POSITIVE_CLASS = Path('/private/tmp/jarde-typed-foreach-original-final-root-v1-20261018/debug/classes/jadx/tests/integration/loops/TestNestedLoops$TestCls.class')
POSITIVE_CLASS_SHA = '4741538cc0ef1ba378cca4fccc8505007956a6b14520a1808c3874d7ea167e2c'
BASELINE_CLI_SHA = '26eb321d0810a54328f7880483c6c5a5c2033c2ad747f7b177a51e723e96af52'
MAX_TARGET = 1 << 30
MIN_FREE = 5 * 1024**3


def sha(path: Path) -> str:
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def load(path: Path, name: str):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot load helper {path}')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def require_pin(path: Path, expected: str, label: str):
    if not path.is_file() or sha(path)!=expected: raise SystemExit(f'{label} pin mismatch: {path}')

def facts(compare, physical, root: Path) -> dict:
    result={}
    for p in sorted(root.rglob('*.class')):
        data=p.read_bytes(); a=compare.parse_class(p); b=physical.parse_class_file(data)
        if a['class_name']!=b['class_name'] or a['major']!=b['major'] or a['methods']!=b['methods']:
            raise ValueError(f'independent class parser disagreement: {p}')
        if sorted(tuple(x) for x in a['fields'])!=sorted((x['name'],x['descriptor'],x['access']) for x in b['fields']):
            raise ValueError(f'field inventory parser disagreement: {p}')
        if a['major']!=52: raise ValueError(f'non-Java-8 classfile: {p}')
        methods=[]
        for m in b['methods']:
            c=m.get('code')
            if c is None: raise ValueError(f'missing Code: {p}::{m["name"]}{m["descriptor"]}')
            raw=bytes.fromhex(c['code_hex'])
            if physical.decode_bcis(raw)!=c['bcis']: raise ValueError(f'physical BCI disagreement: {p}::{m["name"]}')
            methods.append({'name':m['name'],'descriptor':m['descriptor'],'access':m['access'],
                'max_stack':c['max_stack'],'max_locals':c['max_locals'],'code_length':c['code_length'],
                'code_sha256':hashlib.sha256(raw).hexdigest(),'bcis':c['bcis'],'exception_rows':c['rows']})
        a['physical_access']=b['access']; a['physical_methods']=methods
        result[p.relative_to(root).as_posix()]=a
    return result

def inventory(tree: dict) -> dict:
    return {p:(x['class_name'],x['major'],x['physical_access'],
      tuple(sorted((f[0],f[1],f[2]) for f in x['fields'])),
      tuple(sorted((m['name'],m['descriptor'],m['access']) for m in x['methods']))) for p,x in tree.items()}

def source_class_inventory(tree: dict, name: str) -> bool:
    if set(tree)!=EXPECTED_TARGET_CLASSES[name]: return False
    for rel, methods in EXPECTED_METHODS.items():
        if rel in tree and {(m['name'],m['descriptor']) for m in tree[rel]['methods']}!=methods: return False
    return True

def parse_driver(raw: bytes) -> list[str]:
    lines=raw.decode('utf-8','strict').splitlines()
    expected=[('controls.RemovalCases','removeObject'),('controls.RemovalCases','removeInt'),
      ('controls.RemovalCases','removeInteger'),('controls.EqualityCases','equalsObject'),
      ('controls.EqualityCases','equalsString'),('controls.ExplicitCastCases','equalsExplicitCast'),
      ('controls.ExplicitCastCases','equalsExplicitCast'),('controls.ExplicitCastCases','equalsExplicitCast')]
    if len(lines)!=8: raise ValueError(f'driver expected 8 rows, got {len(lines)}')
    for line,(klass,method) in zip(lines,expected):
        if not line.startswith(f'CASE class={klass} method={method} descriptor='):
            raise ValueError(f'driver case order/identity mismatch: {line!r}')
    if 'input=valid-string' not in lines[5] or 'input=wrong-integer' not in lines[6] or 'input=null' not in lines[7]:
        raise ValueError('explicit-cast case labels/order differ')
    return lines

def parse_source(data: bytes, kind: str, original_name: str):
    data.decode('utf-8','strict')
    package=re.search(rb'^\s*package\s+([A-Za-z_$][A-Za-z0-9_$.]*)\s*;',data,re.M)
    pkg=package.group(1).decode('ascii').replace('.','/') if package else ''
    if kind=='jarde':
        public=re.search(rb'\bpublic\s+(?:(?:final|abstract)\s+)*class\s+([A-Za-z_$][A-Za-z0-9_$]*)\b',data)
        if not public: raise ValueError('whole Jarde text lacks public class declaration')
        filename=public.group(1).decode('ascii')+'.java'
    else:
        if re.fullmatch(r'[A-Za-z_$][A-Za-z0-9_$]*\.java',original_name) is None:
            raise ValueError(f'illegal decompiler Java filename: {original_name}')
        filename=original_name
    return pkg,filename

def class_tree(root: Path, compare) -> dict:
    return {p.relative_to(root).as_posix():compare.pin(p) for p in sorted(root.rglob('*.class'))}

def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--cli',type=Path,required=True); ap.add_argument('--cli-sha256',required=True)
    ap.add_argument('--out',type=Path,required=True); args=ap.parse_args()
    root=ROOT.resolve(strict=True); out=args.out.resolve(); cli=args.cli.resolve(strict=True)
    if out.exists(): raise SystemExit('refusing existing output '+str(out))
    if out==root or root in out.parents: raise SystemExit('output must be private and outside repository')
    if re.fullmatch('[0-9a-f]{64}',args.cli_sha256) is None or sha(cli)!=args.cli_sha256: raise SystemExit('CLI differs from supplied SHA-256')
    if args.cli_sha256!=BASELINE_CLI_SHA: raise SystemExit('baseline requires the pinned current final CLI')
    if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('repository target must be absent before capture')
    if shutil.disk_usage(root).free<MIN_FREE: raise SystemExit('less than 5 GiB free before capture')
    cp,gp,sp,mp=(root/COMPARE,root/GUARD,root/SCANNER,root/MANIFEST)
    for p,h,label in ((cp,COMPARE_SHA,'compare'),(gp,GUARD_SHA,'guard'),(sp,SCANNER_SHA,'scanner'),
        (mp,MANIFEST_SHA,'JDK manifest'),(PHYSICAL,PHYSICAL_SHA,'physical parser'),
        (REFERENCE,REFERENCE_SHA,'ancestor tool reference'),(REFERENCE_ORIGINAL,REFERENCE_ORIGINAL_SHA,'accepted original matrix'),
        (POSITIVE_SOURCE,POSITIVE_SOURCE_SHA,'positive Java source'),(POSITIVE_DRIVER,POSITIVE_DRIVER_SHA,'positive driver'),
        (POSITIVE_CLASS,POSITIVE_CLASS_SHA,'positive class'),(DRIVER, 'd7a095fbe01469af3b9451246fc4bde825ebe2a64fd15945a51b72d5262e277e','controls driver')):
        require_pin(p,h,label)
    for name,path in TARGETS.items(): require_pin(path, {'RemovalCases':'f3c56d28ec29497e97c77a179896520a42ccd07d64fbe803d891df4a1558f599','EqualityCases':'80f854ac9c264ec876d2ab877b3a34b8f08bbe82af7e5aac20ce72ee743068a4','ExplicitCastCases':'aa9d46041a312340687402d98b7199d9fb5b36b00a2146536ba2fe039b4a42b6'}[name],name+' source')
    compare=load(cp,'objectarg_compare'); guard=load(gp,'objectarg_guard'); scanner=load(sp,'objectarg_scanner'); physical=load(PHYSICAL,'objectarg_physical')
    jdks,jdk_record=compare.configured_jdks(mp,MANIFEST_SHA)
    ref=json.loads(REFERENCE.read_text()); old=json.loads(REFERENCE_ORIGINAL.read_text())
    if ref.get('status') not in ('captured-pending-review','captured-pending-independent-review'):
        raise SystemExit('tool reference receipt is not a captured matrix')
    jadx=Path(ref['tool_reference_jadx']['path']); jadx_jar=Path(ref['tool_reference_jadx_jar']['path'])
    runtime=Path(json.loads(Path(ref['tool_reference_receipt']['path']).read_text())['runtime_wrapper']['path'])
    for p,h,label in ((jadx,ref['tool_reference_jadx']['sha256'],'JADX launcher'),(jadx_jar,ref['tool_reference_jadx_jar']['sha256'],'JADX jar'),(runtime,'73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca','runtime timeout wrapper')): require_pin(p,h,label)
    for spec in jdks.values():
        for tool in spec['tools'].values():
            if not Path(tool).is_file(): raise SystemExit('configured JDK tool missing: '+str(tool))
    source_before=compare.source_closure(root)
    out.mkdir(parents=True); rawdir=out/'raw'; rawdir.mkdir(); empty=out/'empty-classpath'; empty.mkdir()
    guard.ROOT=root; guard.OUT=rawdir; guard.target_bytes=lambda:scanner.target_bytes(root); guard.command_stream=compare.pin; guard.expected_test_summaries=lambda i,d:None
    local_inputs=out/'input'; local_inputs.mkdir()
    copied_driver=local_inputs/DRIVER.name; shutil.copyfile(DRIVER,copied_driver)
    copied_targets={n:local_inputs/p.name for n,p in TARGETS.items()}
    for n,p in TARGETS.items(): shutil.copyfile(p,copied_targets[n])
    runtime_copy=out/runtime.name; shutil.copyfile(runtime,runtime_copy)
    for src,dst in [(DRIVER,copied_driver),*[(TARGETS[n],copied_targets[n]) for n in TARGETS],(runtime,runtime_copy)]:
        if src.read_bytes()!=dst.read_bytes(): raise RuntimeError('frozen input copy differs')
    external=[cp,gp,sp,mp,PHYSICAL,REFERENCE,REFERENCE_ORIGINAL,POSITIVE_SOURCE,POSITIVE_DRIVER,POSITIVE_CLASS,
      cli,jadx,jadx_jar,runtime,Path(__file__),DRIVER,*TARGETS.values(),*[Path(t) for spec in jdks.values() for t in spec['tools'].values()]]
    external_before=[compare.pin(p) for p in external]
    local_before={str(p):compare.pin(p) for p in [copied_driver,*copied_targets.values(),runtime_copy]}
    protected={str(p):compare.pin(p) for p in [copied_driver,*copied_targets.values(),runtime_copy]}
    report={'schema':'object-argument-controls-baseline-v1','status':'running','phase':'baseline','root':str(root),'output':str(out),
      'cli':compare.pin(cli),'expected_cli_sha256':args.cli_sha256,'jdk_manifest':jdk_record,
      'jadx':compare.pin(jadx),'jadx_jar':compare.pin(jadx_jar),'runtime_wrapper':compare.pin(runtime),
      'compare':compare.pin(cp),'guard':compare.pin(gp),'scanner':compare.pin(sp),'physical_parser':compare.pin(PHYSICAL),
      'source_pins_before':source_before,'external_pins_before':external_before,'local_copies_before':local_before,
      'positive_reused_only':{'execution':compare.pin(REFERENCE_ORIGINAL),'source':compare.pin(POSITIVE_SOURCE),
        'driver':compare.pin(POSITIVE_DRIVER),'raw_class':compare.pin(POSITIVE_CLASS),'matrix_rerun':False},
      'driver_source':compare.pin(DRIVER),'target_sources':{n:compare.pin(p) for n,p in TARGETS.items()},
      'guard_limits':{'free_bytes':MIN_FREE,'target_bytes':MAX_TARGET},'default_stack_required':True,'commands':[],
      'driver_compile':None,'source_profiles':[],'original_runs':[],'original_wrong_root':[],
      'jarde_cells':[],'jadx_cells':[],'generated_compiles':[],'generated_runs':[],
      'notes':['Each target is compiled into an independent complete root, including every nested class emitted by javac. No class is borrowed from another profile or producer.',
       'Original runtime rows run the 8-row driver against three same-profile original roots; generated runtime is deferred in this preparation and not claimed.',
       'For generated full-source compiles, every emitted Java source is copied byte-for-byte with its package path and legal filename; no source is cropped, repaired, or supplemented.',
       'Every original/generated classfile is parsed by compare.py and the independent physical parser; all Code BCIs, bytes hash, stack/locals, and exception rows are recorded.',
       'The existing TestNestedLoops positive matrix is reused as historical evidence only; it is not rerun or counted as a new cell.']}
    compare.write_json(out/'execution.json',report); commands=report['commands']
    def register(p: Path):
        if p.is_file(): protected[str(p)]=compare.pin(p)
    def command(argv,label,leg):
        if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError('repository target appeared')
        env=compare.clean_env(dict(os.environ),jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK',None)
        row=guard.run_command(len(commands)+1,[str(x) for x in argv],env); row['label']=label; row['tool_leg']=leg; row['default_stack']='RUST_MIN_STACK' not in env
        commands.append(row)
        for ch in ('stdout','stderr'):
            p=Path(row['streams'][ch]['path']); compare.command_artifact(row,ch); register(p)
        compare.write_json(out/'execution.json',report)
        if row.get('guard_stop') is not None or row.get('free_bytes_after',0)<MIN_FREE or row.get('peak_target_bytes',0)>MAX_TARGET:
            raise RuntimeError('resource guard stopped/failed '+label)
        return row
    def streams(row): return {ch:compare.pin(Path(row['streams'][ch]['path'])) for ch in ('stdout','stderr')}
    def artifact(row,ch): return compare.command_artifact(row,ch)
    def roots_args(roots,expected=None):
        expected=expected or roots
        order=('RemovalCases','EqualityCases','ExplicitCastCases')
        return [v for n in order for v in (Path(roots[n]).resolve(),Path(expected[n]).resolve())]
    def run_driver(roots,label,vm='javac23',wrong=None):
        expected={n:Path(roots[n]) for n in roots}
        if wrong: expected[wrong]=empty
        return command([sys.executable,'-B',runtime_copy,'30',jdks[vm]['tools']['java'],'-Xverify:all','-cp',driver_classes,DRIVER_NAME,*roots_args(roots,expected)],label,vm)
    driver_classes=out/'driver-classes'; driver_classes.mkdir()
    try:
        dr=command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',driver_classes,copied_driver],'compile-driver','javac8')
        driver_tree=facts(compare,physical,driver_classes) if dr['exit_code']==0 else None
        report['driver_compile']={'command':dr['index'],'exit_code':dr['exit_code'],'streams':streams(dr),'class_tree':class_tree(driver_classes,compare),'class_facts':driver_tree}
        for p in driver_classes.rglob('*.class'): register(p)
        if dr['exit_code']!=0: raise RuntimeError('separate reflection driver compilation failed')
        profile_roots={}; oracle={}
        for profile in PROFILES:
            leg='javac8' if profile.startswith('javac8') else 'javac23'; debug='-g:none' if profile.endswith('no-debug') else '-g'
            roots={}
            for name,source in copied_targets.items():
                dest=out/'original'/name/profile/'classes'; dest.mkdir(parents=True)
                flags=['-source','8','-target','8'] if leg=='javac8' else ['--release','8']
                cr=command([jdks[leg]['tools']['javac'],*flags,debug,'-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',dest,copied_targets[name]],'compile-original-'+name+'-'+profile,leg)
                tree=None; error=None
                if cr['exit_code']==0:
                    try: tree=facts(compare,physical,dest)
                    except Exception as e: error=repr(e)
                expected_ok=tree is not None and source_class_inventory(tree,name)
                rootrec={'target':name,'profile':profile,'command':cr['index'],'exit_code':cr['exit_code'],'streams':streams(cr),
                  'class_root':str(dest),'class_tree':class_tree(dest,compare),'class_facts':tree,'class_facts_error':error,
                  'class_inventory_matches_source':expected_ok,'expected_class_paths':sorted(EXPECTED_TARGET_CLASSES[name])}
                report['source_profiles'].append(rootrec); roots[name]=dest
                for p in dest.rglob('*'):
                    if p.is_file(): register(p)
            profile_roots[profile]=roots
            if not all(x['exit_code']==0 and x['class_inventory_matches_source'] for x in report['source_profiles'][-3:]):
                raise RuntimeError('original sources did not compile to expected complete class inventories for '+profile)
            for vm in LEGS:
                rr=run_driver(roots,'original-'+profile+'-'+vm,vm)
                rows=parse_driver(artifact(rr,'stdout')) if rr['exit_code']==0 else []
                runrec={'profile':profile,'vm':vm,'command':rr['index'],'exit_code':rr['exit_code'],'streams':streams(rr),'rows':rows,
                  'case_subsets':{n:[line for line in rows if line.startswith('CASE class=controls.'+n+' ')] for n in TARGETS},
                  'actual_roots':{n:str(p.resolve()) for n,p in roots.items()},'expected_roots':{n:str(p.resolve()) for n,p in roots.items()},
                  'application_classpath':[str(driver_classes.resolve())]}
                report['original_runs'].append(runrec)
                if rr['exit_code']!=0: raise RuntimeError('original 8-row VM run failed '+profile+'/'+vm)
                oracle[(profile,vm)]=rows
            for wrong_target in TARGETS:
                wr=run_driver(roots,'original-wrong-root-'+wrong_target+'-'+profile,'javac23',wrong_target)
                rejected=wr['exit_code']==1 and b'wrong CodeSource:' in artifact(wr,'stderr')
                report['original_wrong_root'].append({'target':wrong_target,'profile':profile,'command':wr['index'],
                  'exit_code':wr['exit_code'],'rejected':rejected,'streams':streams(wr),
                  'actual_roots':{n:str(p.resolve()) for n,p in roots.items()},
                  'expected_roots':{n:(str(empty.resolve()) if n==wrong_target else str(p.resolve())) for n,p in roots.items()},
                  'application_classpath':[str(driver_classes.resolve())]})
                if not rejected: raise RuntimeError('wrong-CodeSource control not rejected '+wrong_target+'/'+profile)
        report['original_oracles']={f'{p}/{vm}':rows for (p,vm),rows in oracle.items()}
        report['jarde_cells']=[]
        for profile,roots in profile_roots.items():
            leg='javac8' if profile.startswith('javac8') else 'javac23'
            for name in TARGETS:
                target_class=roots[name]/(INTERNAL[name]+'.class')
                for evidence in EVIDENCE:
                    dest=out/'jarde'/name/profile/evidence; dest.mkdir(parents=True)
                    argv=[cli,'class-source','--input',target_class,'--class',INTERNAL[name],'--policy','single-class','--release','8','--format','json']
                    if evidence!='default': argv += ['--evidence',evidence]
                    api=command(argv,'jarde-'+name+'-'+profile+'-'+evidence,leg)
                    raw=artifact(api,'stdout'); rp=dest/'report.json'; rp.write_bytes(raw); register(rp)
                    cell={'target':name,'profile':profile,'evidence':evidence,'command':api['index'],'exit_code':api['exit_code'],
                      'streams':streams(api),'report':compare.pin(rp),'source_ready':False}
                    try:
                        doc=json.loads(raw.decode('utf-8','strict')); cell['api_status']=doc.get('execution',{}).get('status')
                        cell['method_identities']=[[bytes(m['item']['identity']['name']).decode('utf-8'),bytes(m['item']['identity']['descriptor']).decode('utf-8')] for m in doc.get('methods',[])]
                        cell['method_inventory_matches_source']=set(map(tuple,cell['method_identities']))=={(m['name'],m['descriptor']) for m in facts(compare,physical,roots[name])[INTERNAL[name]+'.class']['methods']}
                        cell['method_texts']=[m.get('outcome',{}).get('report',{}).get('text') for m in doc.get('methods',[])]
                        cell['method_qualities']=[m.get('outcome',{}).get('report',{}).get('quality') for m in doc.get('methods',[])]
                        cell['method_source_maps']=[m.get('outcome',{}).get('report',{}).get('source_map') for m in doc.get('methods',[])]
                        text=doc.get('text')
                        if isinstance(text,str) and text.strip():
                            whole=dest/(name+'.java'); whole.write_bytes(text.encode('utf-8')); register(whole); cell['whole_source']=compare.pin(whole); cell['source_ready']=True
                        else: cell['source_error']='whole source text missing/empty'
                    except Exception as e: cell['parse_error']=repr(e)
                    report['jarde_cells'].append(cell); compare.write_json(out/'execution.json',report)
                bundle=out/'bundles'/'original'/name/profile/'classes.jar'; bundle.parent.mkdir(parents=True)
                with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
                    for p in sorted(roots[name].rglob('*.class')): z.write(p,p.relative_to(roots[name]).as_posix())
                with zipfile.ZipFile(bundle) as z:
                    members=sorted(n for n in z.namelist() if n.endswith('.class'))
                    if members!=sorted(class_tree(roots[name],compare)): raise RuntimeError('JADX archive closure differs from full original target tree')
                    for m in members:
                        if z.read(m)!=(roots[name]/m).read_bytes(): raise RuntimeError('JADX archive bytes differ '+m)
                register(bundle); jd=out/'jadx'/name/profile
                jr=command([jadx,'--threads-count','1','--no-res','--config','none','-d',jd,bundle],'jadx-'+name+'-'+profile,'javac23')
                sources=sorted(jd.rglob('*.java'))
                for p in sources: register(p)
                report['jadx_cells'].append({'target':name,'profile':profile,'command':jr['index'],'exit_code':jr['exit_code'],
                  'input_bundle':compare.pin(bundle),'streams':streams(jr),'source_count':len(sources),
                  'sources':[compare.pin(p) for p in sources],'complete_source_closure':bool(sources)})
                compare.write_json(out/'execution.json',report)
        generated=[]
        for cell in report['jarde_cells']:
            if cell.get('source_ready'): generated.append(('jarde',cell['target'],cell['profile'],cell['evidence'],[Path(cell['whole_source']['path'])],cell))
        for cell in report['jadx_cells']:
            paths=[Path(p['path']) for p in cell['sources']]
            if paths: generated.append(('jadx',cell['target'],cell['profile'],'source',paths,cell))
        for producer,target,profile,variant,sources,cell in generated:
            if len({p.name for p in sources})!=len(sources): raise RuntimeError(f'duplicate complete-source basename {producer}/{target}/{profile}/{variant}')
            debug='-g:none' if profile.endswith('no-debug') else '-g'
            for compiler in LEGS:
                key=f'{producer}-{target}-{profile}-{variant}-{compiler}-{debug[1:]}'
                srcroot=out/'generated-sources'/key; srcroot.mkdir(parents=True); copied=[]
                for source in sources:
                    data=source.read_bytes(); pkg,filename=parse_source(data,producer,source.name)
                    dest=srcroot/pkg/filename if pkg else srcroot/filename
                    dest.parent.mkdir(parents=True,exist_ok=True)
                    if dest.exists(): raise RuntimeError('generated source destination collision '+str(dest))
                    dest.write_bytes(data)
                    if dest.read_bytes()!=data: raise RuntimeError('generated source copy changed bytes')
                    register(dest); copied.append({'source':compare.pin(source),'copy':compare.pin(dest)})
                outcls=out/'generated-classes'/key; outcls.mkdir(parents=True)
                flags=['-source','8','-target','8'] if compiler=='javac8' else ['--release','8']
                cr=command([jdks[compiler]['tools']['javac'],*flags,debug,'-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',outcls,*sorted(srcroot.rglob('*.java'))],'compile-'+key,compiler)
                tree=None; error=None; matches=None
                if cr['exit_code']==0:
                    try:
                        tree=facts(compare,physical,outcls)
                        original=profile_roots[profile][target]; originalfacts=facts(compare,physical,original)
                        matches=inventory(tree)==inventory(originalfacts)
                    except Exception as e: error=repr(e); matches=False
                for p in outcls.rglob('*'):
                    if p.is_file(): register(p)
                report['generated_compiles'].append({'producer':producer,'target':target,'profile':profile,'evidence':variant,
                    'compiler':compiler,'debug':debug,'source_copies':copied,'command':cr['index'],'exit_code':cr['exit_code'],
                    'streams':streams(cr),'class_root':str(outcls),'class_tree':class_tree(outcls,compare),
                    'class_facts':tree,'class_facts_error':error,'class_inventory_matches_original':matches,
                    'runtime_status':'deferred_no_generated_VM_in_this_baseline_preparation'})
                compare.write_json(out/'execution.json',report)
        from collections import Counter
        report['counts_derived_from_commands']={
          'commands_total':len(commands),'original_target_profile_compiles':len(report['source_profiles']),
          'original_vm_runs':len(report['original_runs']),'original_wrong_root_runs':len(report['original_wrong_root']),
          'jarde_api_cells':len(report['jarde_cells']),'jadx_cells':len(report['jadx_cells']),
          'generated_source_compiles':len(report['generated_compiles']),'generated_vm_runs':len(report['generated_runs']),
          'generated_compiles_by_producer_target_profile':dict(sorted(Counter(
            f"{x['producer']}/{x['target']}/{x['profile']}" for x in report['generated_compiles']).items())),
          'original_vm_case_counts_by_target_profile':{
            f"{x['profile']}/{x['vm']}/{name}":len(rows)
            for x in report['original_runs'] for name,rows in x['case_subsets'].items()}}
        report['failed_cells']=(
          [{'kind':'api','target':c['target'],'profile':c['profile'],'evidence':c['evidence'],'exit_code':c['exit_code'],'source_ready':c.get('source_ready')} for c in report['jarde_cells'] if c['exit_code']!=0 or not c.get('source_ready')]
          +[{'kind':'jadx','target':c['target'],'profile':c['profile'],'exit_code':c['exit_code'],'complete_source_closure':c.get('complete_source_closure')} for c in report['jadx_cells'] if c['exit_code']!=0 or not c.get('complete_source_closure')]
          +[{'kind':'generated-compile','producer':c['producer'],'target':c['target'],'profile':c['profile'],'evidence':c['evidence'],'compiler':c['compiler'],'exit_code':c['exit_code'],'class_inventory_matches_original':c.get('class_inventory_matches_original')} for c in report['generated_compiles'] if c['exit_code']!=0 or c.get('class_inventory_matches_original') is not True]
          +[{'kind':'wrong-root','target':c['target'],'profile':c['profile'],'exit_code':c['exit_code']} for c in report['original_wrong_root'] if not c.get('rejected')])
        report['protected_products_before_final']=dict(protected)
        report['protected_products_after']={k:compare.pin(Path(k)) for k in protected}
        report['products_unchanged']=report['protected_products_before_final']==report['protected_products_after']
        report['source_pins_after']=compare.source_closure(root); report['external_pins_after']=[compare.pin(p) for p in external]
        report['local_copies_after']={str(p):compare.pin(p) for p in [copied_driver,*copied_targets.values(),runtime_copy]}
        report['source_unchanged']=report['source_pins_before']==report['source_pins_after']
        report['external_inputs_unchanged']=report['external_pins_before']==report['external_pins_after']
        report['local_copies_unchanged']=report['local_copies_before']==report['local_copies_after']
        report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
        report['target_absent_after_clean']=report['target_absent']
        report['default_stack']=all(c.get('default_stack') is True for c in commands if c.get('label','').startswith('jarde-'))
        if not all((report['products_unchanged'],report['source_unchanged'],report['external_inputs_unchanged'],report['local_copies_unchanged'],report['target_absent'],report['default_stack'])):
            raise RuntimeError('source/external/artifact/target closure changed')
        report['status']='captured-pending-independent-review'
    except BaseException as e:
        report['status']='failed'; report['error']=repr(e); raise
    finally:
        try:
            report['protected_products_after_finally']={k:compare.pin(Path(k)) for k in protected}
            report['products_unchanged_finally']=report['protected_products_after_finally']==report.get('protected_products_before_final',protected)
            report['source_pins_after_finally']=compare.source_closure(root); report['external_pins_after_finally']=[compare.pin(p) for p in external]
            report['local_copies_after_finally']={str(p):compare.pin(p) for p in [copied_driver,*copied_targets.values(),runtime_copy]}
            report['source_unchanged_finally']=report['source_pins_after_finally']==source_before
            report['external_inputs_unchanged_finally']=report['external_pins_after_finally']==external_before
            report['local_copies_unchanged_finally']=report['local_copies_after_finally']==local_before
            report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
            if not all((report['products_unchanged_finally'],report['source_unchanged_finally'],report['external_inputs_unchanged_finally'],report['local_copies_unchanged_finally'],report['target_absent_finally'])):
                report['status']='failed'; report['final_guard_error']='final source/artifact/target guard changed'
        except BaseException as e: report['status']='failed'; report['final_guard_error']=repr(e)
        report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out/'execution.json',report); shutil.copy2(__file__,out/'collector.py')
    return 0

if __name__=='__main__': raise SystemExit(main())
