# Object-argument controls baseline collector (prepared, not executed)

This collector captures a bounded baseline for a possible follow-up leaf. It does not create a new loop fixture. The accepted `TestNestedLoops$TestCls` source/driver/debug class and full original matrix are pinned as historical positive evidence only; their exact paths and hashes are in the receipt constants and `execution.json` references. They are not recompiled or included in the new cell counts.

The three isolated control sources are copied from the reviewed v2 bundle. Each target is compiled into its own complete class root under four profiles: javac 8 or javac 23, release 8, with debug and without debug. Nested `Receiver` class files remain in their owning target root. The independently compiled driver runs all eight original rows on both VMs for each profile. Three wrong-CodeSource runs per profile mismatch one target root at a time; each must fail at that target's parentless CodeSource check. Runtime observations are parsed by exact row count/order and retained as raw stdout plus per-target case subsets.

The collector then requests Jarde `default` and `all` API evidence for every target/profile (24 API commands) and decompiles each complete target class closure with JADX (12 commands). It saves unmodified reports, full source text, complete decompiler source closures, and byte-identical copies for javac 8/23 generated-source compilation. Every generated class is recorded with complete class/member/field inventories and independent physical Code facts: max stack/locals, Code byte length/hash, every instruction BCI, and exception rows. Compiler/API/decompiler failures remain command cells and do not become successful outcomes.

Generated VM replay is intentionally deferred. Each target source can be compiled separately, but a correct runtime comparison needs mixed roots: the rebuilt target alongside the other two same-profile original target roots, with all three CodeSources checked. This capture records no generated runtime pass and makes no claim about the observed `Integer` overload selection. Root can select common successful producer/profile cells for a later runtime pass.

The runner records each command's argv, environment overrides, cwd, exit code, raw stream pins, disk usage and guard outcome. It checks a 5 GiB free-space floor, a 1 GiB repository target ceiling, default stack environment, absent `target` before and after, and source/external/local/artifact pins. It does not call Cargo or clean. Output must be a fresh private path outside the repository; no target output directory may exist beforehand.

Invocation after root review:

```sh
python3 -B collect_baseline.py \
  --cli /private/tmp/jarde-ancestor-iterator-broad-root-v3-20261018/candidate-cli \
  --cli-sha256 26eb321d0810a54328f7880483c6c5a5c2033c2ad747f7b177a51e723e96af52 \
  --out /private/tmp/jarde-object-argument-controls-baseline-root-v1-20261018/capture
```

Only Python AST parsing was performed on this collector. No CLI, javac, Java, JADX, Cargo, network, or shared-repository write was performed. All generated matrix counts and success/failure counts must be derived from the eventual receipt, not assumed from this plan.
