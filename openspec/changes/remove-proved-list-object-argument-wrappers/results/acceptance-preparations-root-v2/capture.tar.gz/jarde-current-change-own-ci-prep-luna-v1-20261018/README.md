# Current facade/structured API own-CI acceptance preparation

Prepared only; this directory contains no CI collection or acceptance result. No Cargo, JDK, CLI, Git, or network command was run here.

Reuse is intentionally limited to the previously accepted own-CI workflow collector and verifier in `/private/tmp/jarde-ancestor-iterator-ci-prep-luna-v1-20261018`. The official workflow/API/ZIP checks, raw job logs, per-step completeness, both CI workspace seeds, complete Cargo target summaries, source/fixture Git-blob capture, source stability, and `target`-absent checks remain intact. I did not copy the prior native two-local-seed wrapper: this task needs one eventual native workspace run (if separately required) and the own-CI workflow already provides its two workflow seeds.

`collect-own-ci.py` takes `OUT_DIR RUN_ID PRODUCT_SHA CLI_SHA256`. The product SHA is checked against GitHub's run head and source Git blobs. CLI SHA256 is explicit provenance from the final accepted broad gate; collection records it in both `collection.json` and `source-pins.json`. The verifier requires that exact same caller-supplied hash and emits it in its report. The operator must cross-check it against the final broad-gate receipt; these scripts do not build or independently locate the CLI.

`verify-own-ci.py` retains all 63 existing exact critical test identities. Once the optional proof/metamorphic test name is finalized, pass one exact `--extra-critical TARGET=FULL_TEST_NAME` argument; the verifier then requires that identity exactly once and `ok` in each CI seed, making 64 total. Accepted target names are `jarde`, `jarde_java`, or `structured_list_generic_bodies`. With no known proof test, it strictly checks the inherited 63. This option does not alter the prior gate sets.

Suggested eventual invocations (root supplies real values after final product commit/run):

```sh
python3 collect-own-ci.py /private/tmp/<fresh-evidence-dir> <run-id> <full-product-sha> <final-cli-sha256>
python3 verify-own-ci.py /private/tmp/<fresh-evidence-dir> --product-sha <full-product-sha> --cli-sha256 <final-cli-sha256> [--extra-critical 'jarde=<exact-test-identity>']
```

The old strict source and fixture inventories are preserved. They already pin `src/facade.rs` and `tests/structured_list_generic_bodies.rs`; if the final change adds another source or fixture path, update the inventory narrowly before collection rather than treating this bundle as accepted unchanged.

Base verifier SHA256: `89d9878e3e067c2329072b9faeb885f075209632e7243f44297ae7e9f9170c38`.
Base collector SHA256: `b3b512d9da7857752c7d376e8b9ab21831fb86bbcd3d27e5614d000e750b1494`.
Unchanged official-step proof helper SHA256: `2e9746322dacb2a0993d73820c685a81a5f341a98a6c1c28bcad0d9082ff0607`.

`*.base.py` preserves the originals byte-for-byte; the two `*.diff` files show only the private adaptations. Python AST parsing and static contract assertions passed. No runtime or CI acceptance is claimed.
