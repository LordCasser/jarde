# One-seed native acceptance preparation

This private bundle adapts the accepted ancestor-iterator workspace acceptance to the current one-seed leaf. It is preparation only; neither script has been run against the new leaf.

`verify_one_native.py` imports the frozen `verify_workspace.py` used by the prior acceptance and calls its full `validate_one` path. That path independently checks the raw workspace receipt, metadata-derived target inventory, Cargo `Running`/harness binding, resource and cleanup guards, live source pins, and existing exact critical gates. The wrapper appends exactly these two new `jarde` library identities:

- `facade::generic_list_foreach_binding_slot_closed_tests::optional_remove_argument_break_leaves_required_list_proof_and_equals_edit`
- `facade::generic_list_foreach_binding_slot_closed_tests::unmatched_optional_equals_key_does_not_hide_valid_calls`

It requires seed `5350648285461741569`, derives the complete gate count from the inherited checker list plus those two gates, and verifies both new identities appear in the checked critical-gate records. It does not compare against a second seed or hardcode workspace target/test totals.

After native acceptance, run `bind_product_one.py --product <actual-final-HEAD> --build <final-broad-execution.json> --native <native-execution.json> --acceptance <native-review.json> --out <new-private-output.json>`. The binder verifies that the acceptance report names and hashes the exact supplied native receipt, that its seed, canonical source-pin digest, dynamic target count, and totals match that receipt, and that the broad receipt's source-before/source-after maps match. It then merges those paths with the single native source-pin map, validates actual live bytes and executable modes against Git blobs at the supplied product revision, confirms the CLI bytes/hash match the broad receipt, and requires the build/native cleanup invariants. It invokes only read-only `git ls-tree` and `git cat-file --batch` commands when the root runs it.

The earlier two-seed workspace acceptor and product binder remain the historical reference. The two-seed named-status comparison is not applicable to this one-seed design; the reused `validate_one` reconstructs and validates every target summary and checks the exact required gates in the raw named outcomes.

No native/Cargo/CLI/Git command was executed here. Scripts received Python AST syntax validation only. Root must execute the acceptance after final product HEAD and broad receipt are fixed.
