#!/usr/bin/env python3
"""Single-seed wrapper around the accepted workspace checker plus two exact proof gates."""
import argparse, hashlib, importlib.util, json, sys
from pathlib import Path
sys.dont_write_bytecode = True
BASE = Path('/private/tmp/jarde-foreach-local-bindings-own-ci-prep-luna-v3-20261018/verify_workspace.py')
BASE_SHA = '87b8f2151aa1c47eaf0233835430480945c8d8c2a9be7a7b0c089d9cbfcdbb39'
EXTRA = [
 ('jarde', 'facade::generic_list_foreach_binding_slot_closed_tests::optional_remove_argument_break_leaves_required_list_proof_and_equals_edit'),
 ('jarde', 'facade::generic_list_foreach_binding_slot_closed_tests::unmatched_optional_equals_key_does_not_hide_valid_calls'),
]
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('receipt',type=Path)
 ap.add_argument('--out',type=Path,required=True)
 a=ap.parse_args()
 if a.out.exists(): raise FileExistsError(f'refusing to overwrite {a.out}')
 if hashlib.sha256(BASE.read_bytes()).hexdigest()!=BASE_SHA: raise RuntimeError('frozen accepted workspace checker changed')
 spec=importlib.util.spec_from_file_location('frozen_workspace_checker',BASE)
 c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
 gates=list(c.GATES)+EXTRA
 if len(set(gates))!=len(gates): raise RuntimeError('duplicate exact target/test gate identity')
 c.GATES=gates
 rpath=a.receipt/'execution.json' if a.receipt.is_dir() else a.receipt
 x=c.validate_one(rpath)
 if x['seed']!='5350648285461741569': raise RuntimeError('unexpected fixed workspace seed')
 if x['critical_gate_count']!=len(gates): raise RuntimeError('exact gate inventory was not fully checked')
 need={(target,name) for target,name in EXTRA}
 got={(tuple(g['target'])[1],g['test']) for g in x['critical_gates']}
 if not need <= got: raise RuntimeError('one or more new exact gates absent from checked receipts')
 report={'schema':'single-seed-current-change-workspace-review-v1','status':'passed',
  'seed':x['seed'],'target_count':x['target_count'],'batch_count':x['batch_count'],
  'workspace_totals':x['workspace_totals'],'source_pin_count':x['source_pin_count'],
  'critical_gate_count':len(gates),'new_exact_gates':[{'target':t,'test':n} for t,n in EXTRA],
  'critical_gates_each_occur_once_and_pass':True,'workspace':x,
  'checker':{'path':str(BASE),'sha256':BASE_SHA},'reviewer':str(Path(__file__).resolve())}
 dest=a.out.resolve();dest.parent.mkdir(parents=True,exist_ok=True)
 dest.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'status':'passed','seed':x['seed'],'targets':x['target_count'],'gates':len(gates),'output':str(dest)}))
if __name__=='__main__': main()
