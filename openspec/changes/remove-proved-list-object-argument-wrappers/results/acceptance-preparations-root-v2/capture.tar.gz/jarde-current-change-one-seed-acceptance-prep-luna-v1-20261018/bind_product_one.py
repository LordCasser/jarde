#!/usr/bin/env python3
"""Bind one accepted native source pin map and broad build/CLI to a product Git tree."""
import argparse,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
def pin(path):
 p=Path(path).resolve(strict=True);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(path):return json.loads(Path(path).read_bytes())
def main():
 a=argparse.ArgumentParser();a.add_argument('--product',required=True);a.add_argument('--build',required=True);a.add_argument('--native',required=True);a.add_argument('--acceptance',required=True);a.add_argument('--out',required=True);z=a.parse_args()
 out=Path(z.out);assert not out.exists() and not (ROOT/'target').exists() and not (ROOT/'target').is_symlink()
 b=load(z.build);n=load(z.native);ac=load(z.acceptance)
 assert ac['status']=='passed' and ac['seed']=='5350648285461741569'
 assert b['status']=='commands_passed_pending_independent_acceptance' and b['source_changes_accepted'] and b['target_absent']
 assert b['allowed_source_changes']==b['source_changes']==[]
 before={str(Path(r['path']).relative_to(ROOT)):r for r in b['source_before']}
 after={str(Path(r['path']).relative_to(ROOT)):r for r in b['source_after']}
 assert before==after and before
 assert n['status']=='passed' and n['pins_unchanged'] and n['target_absent_after_clean']
 assert n['source_pins_before_format']==n['source_pins']==n['source_pins_after_format']
 expected=dict(n['source_pins'])
 for rel,row in before.items():
  assert expected.get(rel,row['sha256'])==row['sha256'];expected[rel]=row['sha256']
 tree_raw=subprocess.check_output(['git','ls-tree','-rz','--full-tree',z.product],cwd=ROOT);tree={}
 for row in tree_raw.split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);mode,kind,oid=meta.split();tree[path.decode()]={'mode':mode.decode(),'kind':kind.decode(),'oid':oid.decode()}
 keys=sorted(expected);assert all(k in tree and tree[k]['kind']=='blob' for k in keys)
 raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,input=('\n'.join(tree[k]['oid'] for k in keys)+'\n').encode());pos=0;bindings=[]
 for key in keys:
  end=raw.index(b'\n',pos);header=raw[pos:end].split();entry=tree[key]
  assert header[0].decode()==entry['oid'] and header[1]==b'blob'
  size=int(header[2]);pos=end+1;data=raw[pos:pos+size];pos+=size;assert raw[pos:pos+1]==b'\n';pos+=1
  live=ROOT/key;assert live.is_file() and not live.is_symlink() and data==live.read_bytes()
  assert hashlib.sha256(data).hexdigest()==expected[key]
  mode='100755' if live.stat().st_mode & 0o111 else '100644';assert entry['mode']==mode
  bindings.append({'path':key,'git_blob':entry['oid'],'mode':mode,'bytes':size,'sha256':expected[key]})
 assert pos==len(raw) and pin(b['cli']['path'])==b['cli']
 result={'status':'accepted_single_native_and_build_bound_to_product','product_revision':z.product,
  'cli':b['cli'],'build':pin(z.build),'native':pin(z.native),'acceptance':pin(z.acceptance),
  'counts':{'build_source_paths':len(before),'native_source_paths':len(n['source_pins']),'bound_union':len(keys)},
  'bindings':bindings,'binder':pin(__file__),
  'scope':'Build source_before/source_after equality, native raw source pin map, live file bytes/modes, product Git blobs, and actual broad CLI pin.'}
 out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'status':result['status'],'counts':result['counts'],'cli':b['cli']['sha256']}))
if __name__=='__main__':main()
