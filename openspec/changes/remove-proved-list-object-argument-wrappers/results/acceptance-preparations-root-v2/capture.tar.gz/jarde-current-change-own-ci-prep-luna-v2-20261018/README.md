# Current facade/structured API own-CI acceptance preparation v2

Prepared only; no CI collection or acceptance result exists here. No Cargo, formatter, JDK, CLI, Git mutation, or network command was run.

This v2 preserves the v1 collector and proof helper byte-for-byte and changes only the private own-CI verifier. All prior 63 exact critical gates and the accepted workflow/API/official-ZIP per-step, raw log, two CI seed, complete Cargo target, source/fixture Git-blob, source-stability, and target-absent checks remain in place.

`collect-own-ci.py` retains v1's `OUT_DIR RUN_ID PRODUCT_SHA CLI_SHA256` interface. The CLI SHA is caller-supplied provenance from the final broad-gate receipt and is required to match in `collection.json` and `source-pins.json`; the operator must cross-check that receipt. No local CLI build or lookup is performed.

`verify-own-ci.py` accepts repeated `--extra-critical TARGET=FULL_TEST_NAME`. It rejects duplicate `(target, full test name)` identities, including collisions with inherited gates, and stores every supplied target/name in the output report. Each named gate must occur exactly once and pass under that exact target in both CI workspace seeds. Total gate count is derived as 63 plus the supplied number; there is no hardcoded expected count for the forthcoming new tests.

Known proof test:

`jarde=facade::generic_list_foreach_binding_slot_closed_tests::optional_remove_argument_break_leaves_required_list_proof_and_equals_edit`

Pass the second proof test the same way after its exact name is settled. Example eventual invocation:

```sh
python3 verify-own-ci.py /private/tmp/<fresh-evidence-dir> \
  --product-sha <full-product-sha> --cli-sha256 <final-cli-sha256> \
  --extra-critical 'jarde=facade::generic_list_foreach_binding_slot_closed_tests::optional_remove_argument_break_leaves_required_list_proof_and_equals_edit' \
  --extra-critical 'jarde=<second-exact-test-name>'
```

The existing strict source and fixture inventories are unchanged from v1. They already pin `src/facade.rs` and `tests/structured_list_generic_bodies.rs`; if final changes add another path, adjust the inventory narrowly before collection.

V1 verifier base SHA256: `96b741b69d11aad2828b380559b7e527b1829ff80f829d2055996ea509b46d39`.
Unchanged collector SHA256: `61163ae2e85c8b7b6641c8e47a04bf44a27f0549dfb7fbc4e94e83bbc3c5a5d3`.
Unchanged official-step proof helper SHA256: `2e9746322dacb2a0993d73820c685a81a5f341a98a6c1c28bcad0d9082ff0607`.

`verify-own-ci.v1.py` preserves the prior verifier. `verify-own-ci-v2.diff` contains the only code change. AST parsing and static contract assertions passed. No CI or product acceptance is claimed.
