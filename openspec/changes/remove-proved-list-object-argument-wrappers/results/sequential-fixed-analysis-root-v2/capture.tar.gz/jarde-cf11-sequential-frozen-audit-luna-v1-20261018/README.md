# TestSequentialLoops receipt-scope audit (read-only)

This memo reads the existing frozen baseline and current-API replay; it does not rerun a tool or classify a product feature as accepted.

## Pinned archives

- Frozen full baseline receipt: `/private/tmp/jarde-testsequentialloops-baseline-run-root-v1-20261018/execution.json`, 2,600,269 bytes, SHA-256 `615f5f0e7f7734be42cc190592e75315a4091da4715087cf89bc7adffc044911`. It has 24 raw commands and 48 raw stream files; capture status is `captured-pending-independent-review`.
- Its independent receipt review: `/private/tmp/jarde-testsequentialloops-baseline-run-root-v1-20261018/independent-review/root-review.json`, SHA-256 `badaef35b036bf7f6ae7febd3d96c7b24abc1257f4b5500b212121426f0d5e97`. Review status is `read_only_baseline_review_complete`; it checked the command streams, both class profiles, four original runtime cells, eight Jarde API cells, four JADX extractions, pins and source/target closure. Thus the historical capture label is not the final review status.
- Current API replay: `/private/tmp/jarde-sequential-loops-current-api-root-v1-20261018/execution.json`, 1,059,585 bytes, SHA-256 `bfefd03b55210553c8c17996c3d4885f292df1c8c2d2005bf12e0a2e7d1c1777`. It contains 8 cells / 16 raw streams, all commands exited 0; candidate CLI is `/private/tmp/jarde-loop-arm-gates-root-v4-20261018/candidate-cli`, SHA-256 `09dda40069dc362bc59f141a7d82c8cdcaee8b64072d304ec1ba848bdc14da25`, with product revision argument `e70b350ee33307294a3d383ffdea5874caf9f5b8`.
- Current replay's independent review: `/private/tmp/jarde-sequential-loops-current-api-root-v1-20261018/root-review.json`, SHA-256 `4f3f2b28027b5c1c426dd6f0fd87c2e5ddff1ec410bafb00d8778b882824ef78`. It reports `reviewed_equal`, 8/8 equal, zero differences/nonzero exits/guard stops, unchanged source and input pins, unchanged CLI, target absent.

## What the frozen baseline actually contains

The complete original upstream file was copied unchanged to `source/TestSequentialLoops.java`; SHA-256 `7b9826d70fcd7444773250dbcacbc2a35e41e75c32b002fc8091322132006913`. Its nested `TestCls.test(int a, int b)` golden assertions are: exactly two `while (` occurrences, one `break;`, and one `return c;`. These are static JADX-output assertions, not runtime expected values. The original source is also at `/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestSequentialLoops.java`.

The baseline compiler made two release-8 class profiles on JDK 23: debug target class 686 bytes, SHA `78e4f26968bbdc48f5928572d9ab6ef4d6002ff72dffb4ae5c58bcef029a7107`; no-debug 383 bytes, SHA `df9f42bd8cdac4bd4124342b93ca3ee5a27093fb54788b377ec7c617f69ad6a1`. The paired outer classes were also captured and pinned (1296 and 1069 bytes). Both target profiles have the same two Code methods, `<init>()V` and `test(II)I`; `test` Code is 42 bytes with 25 instruction BCIs and no handlers. The JDK 8 full-source compile was attempted and failed at the pinned harness boundary: `IntegrationTest.class` is major 55 while javac 8 accepts 52. The baseline review confirms this diagnostic, not a failed target compile.

The original reflection driver was separately compiled with JDK 8 and invoked only the target class from each profile under both JDK 8 and JDK 23 VMs (`-Xverify:all`); all four runs produced identical six observed rows. Oracle stdout: `original-oracle.stdout`, 211 bytes, SHA `e4392748e0ac7e8e8ab2c45f86ec2b745ab7ed03585222930e766b0f58f23ef4`. The wrong-CodeSource control exited 1 and was reviewed as rejected. This is runtime evidence for original classfiles, not generated Jarde/JADX Java.

Tool pins in the receipt: JDK manifest SHA `ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec`; JADX 1.5.6 launcher SHA `64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7` and jar SHA `966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65`; baseline Jarde CLI SHA `25adeaf312a7644c7d4c73191ef1264af0378cf78139d35a890377e3c86371ce`.

## Outputs vs the golden test

JADX emitted four complete source files (debug/no-debug × nested child/bundle), all extraction commands exit 0. For example, the child projection in `jadx/debug/child/sources/jadx/tests/integration/loops/TestSequentialLoops$TestCls.java` contains the two loop constructs, one break, and one `return c`; the bundle projection includes the outer integration-test wrapper and same nested method. Full paths and SHA pins are in `execution.json` and the independent review.

The eight original Jarde reports (debug/no-debug × child/bundle-child × default/all) all ran successfully. `<init>()V` is structured. `test(II)I` is `fallback` in every cell, with `jre_region_unmet_precondition` and `jre_region_uncovered_blocks`; default/all parity and child-vs-bundle owner identity were checked. The report's fallback explanation identifies BCI 5 as an effectful instruction in the test block and says structuring it as a loop would move that effect; blocks at BCIs 14, 17, 23, 34 and 40 remain uncovered. Jarde's saved whole-class text therefore has only the explanatory method body, not the golden two loops/break/return. JADX output was not compiled or run by this baseline collector, and Jarde has no recovered executable body here.

The current-API archive is a replay of the same eight input/profile/evidence combinations. Its independently reviewed comparator removed only recursive `usage` and `elapsed_millis` keys; every other JSON value matched baseline (8/8, zero diff). That proves parity with this fallback baseline, not advancement toward the golden assertions. It does not compile generated Jarde text, rerun the original VM matrix, recapture JADX, nor establish a before/after golden-source acceptance. This is why these records alone leave feature acceptance open, even though baseline and replay capture review is complete.

## Reproducible references

Baseline copied collector: `/private/tmp/jarde-testsequentialloops-baseline-run-root-v1-20261018/collector.py`, SHA-256 `8b3e5b9585d3172c8ebb4b6a47ab702da8e5d3a15b8ec6d8911ce6e0e16dbbba`. The original preparation/readme is `/private/tmp/jarde-testsequentialloops-baseline-prep-luna-v1-20261018/README.md`. No source or receipt was changed during this audit.
