package controls;

/* JADX INFO: loaded from: classes.jar:controls/EqualityCases.class */
public final class EqualityCases {

    /* JADX INFO: loaded from: classes.jar:controls/EqualityCases$Receiver.class */
    public static final class Receiver {
        private String selected = "unset";

        public boolean equals(Object obj) {
            this.selected = "Object";
            return (obj instanceof String) && "needle".equals(obj);
        }

        public boolean equals(String str) {
            this.selected = "String";
            return "needle".equals(str);
        }

        public String selected() {
            return this.selected;
        }
    }

    private EqualityCases() {
    }

    public static boolean equalsObject(Receiver receiver, String str) {
        return receiver.equals((Object) str);
    }

    public static boolean equalsString(Receiver receiver, String str) {
        return receiver.equals(str);
    }
}
