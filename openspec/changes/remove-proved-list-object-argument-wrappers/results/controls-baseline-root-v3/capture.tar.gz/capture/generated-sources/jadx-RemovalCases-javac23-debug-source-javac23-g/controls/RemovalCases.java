package controls;

import java.util.List;

/* JADX INFO: loaded from: classes.jar:controls/RemovalCases.class */
public final class RemovalCases {
    private RemovalCases() {
    }

    public static boolean removeObject(List<Integer> values, int value) {
        return values.remove(Integer.valueOf(value));
    }

    public static Integer removeInt(List<Integer> values, int value) {
        return values.remove(value);
    }

    public static boolean removeInteger(List<Integer> values, Integer value) {
        return values.remove(value);
    }
}
