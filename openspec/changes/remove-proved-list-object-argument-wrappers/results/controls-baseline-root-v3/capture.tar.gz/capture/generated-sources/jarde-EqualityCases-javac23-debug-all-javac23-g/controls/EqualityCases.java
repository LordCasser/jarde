// jarde: presentation of `controls/EqualityCases` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package controls;

public final class EqualityCases extends java.lang.Object {
    private EqualityCases() {
        // @method <init>()V
        // @declaration a constructor of `controls.EqualityCases`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static boolean equalsObject(controls.EqualityCases$Receiver receiver, java.lang.String value) {
        // @method equalsObject(Lcontrols/EqualityCases$Receiver;Ljava/lang/String;)Z
        // @declaration a static method of `controls.EqualityCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return receiver.equals((java.lang.Object) value);
    }

    public static boolean equalsString(controls.EqualityCases$Receiver receiver, java.lang.String value) {
        // @method equalsString(Lcontrols/EqualityCases$Receiver;Ljava/lang/String;)Z
        // @declaration a static method of `controls.EqualityCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return receiver.equals(value);
    }
}
