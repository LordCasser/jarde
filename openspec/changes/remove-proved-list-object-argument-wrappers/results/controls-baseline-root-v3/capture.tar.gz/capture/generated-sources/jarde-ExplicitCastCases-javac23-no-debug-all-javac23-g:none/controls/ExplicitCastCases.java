// jarde: presentation of `controls/ExplicitCastCases` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package controls;

public final class ExplicitCastCases extends java.lang.Object {
    private ExplicitCastCases() {
        // @method <init>()V
        // @declaration a constructor of `controls.ExplicitCastCases`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static boolean equalsExplicitCast(controls.ExplicitCastCases$Receiver arg0, java.lang.Object arg1) {
        // @method equalsExplicitCast(Lcontrols/ExplicitCastCases$Receiver;Ljava/lang/Object;)Z
        // @declaration a static method of `controls.ExplicitCastCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return arg0.equals((java.lang.String) arg1);
    }
}
