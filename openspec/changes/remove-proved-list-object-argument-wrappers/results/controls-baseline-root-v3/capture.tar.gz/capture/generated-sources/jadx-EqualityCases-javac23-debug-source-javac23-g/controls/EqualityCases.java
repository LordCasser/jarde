package controls;

/* JADX INFO: loaded from: classes.jar:controls/EqualityCases.class */
public final class EqualityCases {
    private EqualityCases() {
    }

    /* JADX INFO: loaded from: classes.jar:controls/EqualityCases$Receiver.class */
    public static final class Receiver {
        private String selected = "unset";

        public boolean equals(Object value) {
            this.selected = "Object";
            return (value instanceof String) && "needle".equals(value);
        }

        public boolean equals(String value) {
            this.selected = "String";
            return "needle".equals(value);
        }

        public String selected() {
            return this.selected;
        }
    }

    public static boolean equalsObject(Receiver receiver, String value) {
        return receiver.equals((Object) value);
    }

    public static boolean equalsString(Receiver receiver, String value) {
        return receiver.equals(value);
    }
}
