package controls;

import java.util.List;

/* JADX INFO: loaded from: classes.jar:controls/RemovalCases.class */
public final class RemovalCases {
    private RemovalCases() {
    }

    public static boolean removeObject(List<Integer> list, int i) {
        return list.remove(Integer.valueOf(i));
    }

    public static Integer removeInt(List<Integer> list, int i) {
        return list.remove(i);
    }

    public static boolean removeInteger(List<Integer> list, Integer num) {
        return list.remove(num);
    }
}
