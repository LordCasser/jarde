package controls;

/* JADX INFO: loaded from: classes.jar:controls/ExplicitCastCases.class */
public final class ExplicitCastCases {

    /* JADX INFO: loaded from: classes.jar:controls/ExplicitCastCases$Receiver.class */
    public static final class Receiver {
        public boolean equals(String str) {
            return "needle".equals(str);
        }
    }

    private ExplicitCastCases() {
    }

    public static boolean equalsExplicitCast(Receiver receiver, Object obj) {
        return receiver.equals((String) obj);
    }
}
