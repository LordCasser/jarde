package controls;

/* JADX INFO: loaded from: classes.jar:controls/ExplicitCastCases.class */
public final class ExplicitCastCases {
    private ExplicitCastCases() {
    }

    /* JADX INFO: loaded from: classes.jar:controls/ExplicitCastCases$Receiver.class */
    public static final class Receiver {
        public boolean equals(String value) {
            return "needle".equals(value);
        }
    }

    public static boolean equalsExplicitCast(Receiver receiver, Object value) {
        return receiver.equals((String) value);
    }
}
