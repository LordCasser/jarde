// jarde: presentation of `controls/RemovalCases` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package controls;

public final class RemovalCases extends java.lang.Object {
    private RemovalCases() {
        // @method <init>()V
        // @declaration a constructor of `controls.RemovalCases`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    // jarde: generic Signature projection refused for `removeObject(Ljava/util/List;I)Z`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static boolean removeObject(java.util.List arg0, int arg1) {
        // @method removeObject(Ljava/util/List;I)Z
        // @declaration a static method of `controls.RemovalCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return arg0.remove((java.lang.Object) java.lang.Integer.valueOf(arg1));
    }

    // jarde: generic Signature projection refused for `removeInt(Ljava/util/List;I)Ljava/lang/Integer;`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static java.lang.Integer removeInt(java.util.List arg0, int arg1) {
        // @method removeInt(Ljava/util/List;I)Ljava/lang/Integer;
        // @declaration a static method of `controls.RemovalCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return (java.lang.Integer) arg0.remove(arg1);
    }

    // jarde: generic Signature projection refused for `removeInteger(Ljava/util/List;Ljava/lang/Integer;)Z`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static boolean removeInteger(java.util.List arg0, java.lang.Integer arg1) {
        // @method removeInteger(Ljava/util/List;Ljava/lang/Integer;)Z
        // @declaration a static method of `controls.RemovalCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return arg0.remove((java.lang.Object) arg1);
    }
}
