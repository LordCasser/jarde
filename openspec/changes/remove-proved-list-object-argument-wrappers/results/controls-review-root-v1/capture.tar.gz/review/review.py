from pathlib import Path
import json,hashlib,importlib.util,collections,struct
BASE=Path('/private/tmp/jarde-object-argument-controls-baseline-root-v3-20261018/capture')
OUT=Path(__file__).resolve().parent
x=json.loads((BASE/'execution.json').read_text())
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def ck(p):assert pin(p['path'])==p,p['path']
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
compare=load(x['compare']['path'],'review_compare');physical=load(x['physical_parser']['path'],'review_physical')
assert x['status']=='captured-pending-independent-review' and len(x['commands'])==141
assert x['source_pins_before']==x['source_pins_after']==x['source_pins_after_finally']
assert x['external_pins_before']==x['external_pins_after']==x['external_pins_after_finally']
assert x['protected_products_before_final']==x['protected_products_after']==x['protected_products_after_finally']
for group in (x['source_pins_after_finally'].values(),x['external_pins_after_finally'],x['protected_products_after_finally'].values()):
 for p in group:ck(p)
for c in x['commands']:
 assert c['exit_code'] in (0,1) and c['guard_stop'] is None and c['peak_target_bytes']==0 and c['free_bytes_after']>=5*1024**3 and c['default_stack']
 for p in c['streams'].values():ck(p)
assert not Path('target').exists()
assert len(x['source_profiles'])==12 and len(x['original_runs'])==8 and len(x['original_wrong_root'])==12
oracle=x['original_runs'][0]['rows'];assert len(oracle)==8
for r in x['original_runs']:
 assert r['exit_code']==0 and r['rows']==oracle
 c=x['commands'][r['command']-1];assert Path(c['streams']['stdout']['path']).read_text().splitlines()==oracle
assert 'events=remove-object:1' in oracle[0] and 'state=WzJd' in oracle[0]
assert 'events=remove-int:1' in oracle[1] and 'return=2' in oracle[1] and 'state=WzFd' in oracle[1]
assert 'events=remove-object:1' in oracle[2] and 'return=true' in oracle[2]
assert 'detail=Object' in oracle[3] and 'detail=String' in oracle[4]
assert 'exception=java.lang.ClassCastException' in oracle[6] and 'return=false' in oracle[7]
for r in x['original_wrong_root']:
 c=x['commands'][r['command']-1];assert c['exit_code']==1 and r['rejected'] and 'wrong CodeSource:' in Path(c['streams']['stderr']['path']).read_text()
# Independent constant-pool projection, joined to the complete physical instruction census.
def cp_refs(path):
 b=Path(path).read_bytes();pos=8
 def take(n):
  nonlocal pos
  v=b[pos:pos+n];pos+=n;assert len(v)==n;return v
 def u2():return int.from_bytes(take(2),'big')
 cp=[None]*u2();i=1
 while i<len(cp):
  t=take(1)[0]
  if t==1:cp[i]=('u',take(u2()).decode('utf8'))
  elif t in (3,4):take(4)
  elif t in (5,6):take(8);i+=1
  elif t in (7,8,16,19,20):cp[i]=(t,u2())
  elif t in (9,10,11,12,17,18):cp[i]=(t,u2(),u2())
  elif t==15:take(3)
  else:raise AssertionError(t)
  i+=1
 def utf(i):assert cp[i][0]=='u';return cp[i][1]
 rows={}
 for m in physical.parse_class_file(b)['methods']:
  ops=[];code=m['code'];raw=bytes.fromhex(code['code_hex']) if code else b''
  for pc in code['bcis'] if code else []:
   op=raw[pc]
   if op in (0xb6,0xb7,0xb8,0xb9):
    ref=cp[int.from_bytes(raw[pc+1:pc+3],'big')];nt=cp[ref[2]]
    ops.append(dict(bci=pc,opcode=op,owner=utf(cp[ref[1]][1]),name=utf(nt[1]),descriptor=utf(nt[2])))
   elif op==0xc0:ops.append(dict(bci=pc,opcode=op,cast=utf(cp[int.from_bytes(raw[pc+1:pc+3],'big')][1])))
  rows[m['name']+m['descriptor']]=ops
 return rows
bindings=[];physical_count=0
for r in [x['driver_compile'],*x['source_profiles'],*x['generated_compiles']]:
 for rel,p in r['class_tree'].items():
  ck(p);a=compare.parse_class(Path(p['path']));b=physical.parse_class_file(Path(p['path']).read_bytes());assert a['methods']==b['methods'];physical_count+=1
 if r.get('target') and r in x['source_profiles']:
  top=r['class_tree']['controls/'+r['target']+'.class']['path'];calls=cp_refs(top)
  if r['target']=='RemovalCases':
   for name,desc in [('removeObject','(Ljava/lang/Object;)Z'),('removeInteger','(Ljava/lang/Object;)Z'),('removeInt','(I)Ljava/lang/Object;')]:
    found=[q for k,v in calls.items() if k.startswith(name+'(') for q in v if q.get('owner')=='java/util/List' and q.get('name')=='remove'];assert len(found)==1 and found[0]['descriptor']==desc
  elif r['target']=='EqualityCases':
   for name,desc in [('equalsObject','(Ljava/lang/Object;)Z'),('equalsString','(Ljava/lang/String;)Z')]:
    found=[q for k,v in calls.items() if k.startswith(name+'(') for q in v if q.get('name')=='equals'];assert len(found)==1 and found[0]['descriptor']==desc
  else:assert any(q.get('cast')=='java/lang/String' for v in calls.values() for q in v)
  bindings.append(dict(target=r['target'],profile=r['profile'],calls=calls))
for target in ('RemovalCases','EqualityCases','ExplicitCastCases'):
 for profile in ('javac8-debug','javac8-no-debug','javac23-debug','javac23-no-debug'):
  cells=[c for c in x['jarde_cells'] if c['target']==target and c['profile']==profile];assert len(cells)==2
  docs=[json.loads(Path(c['report']['path']).read_text()) for c in cells]
  assert docs[0]['text']==docs[1]['text']
  assert all(c['exit_code']==0 and c['source_ready'] and c['method_inventory_matches_source'] for c in cells)
for r in x['generated_compiles']:
 for s in r['source_copies']:assert Path(s['source']['path']).read_bytes()==Path(s['copy']['path']).read_bytes()
 if r['exit_code']==0:assert r['class_inventory_matches_original'] and not r['class_facts_error']
 else:assert r['producer']=='jarde' and r['target'] in ('EqualityCases','ExplicitCastCases') and 'Receiver' in Path(r['streams']['stderr']['path']).read_text()
assert len(x['generated_runs'])==0
counts=collections.Counter((r['producer'],r['target'],r['exit_code']) for r in x['generated_compiles'])
review=dict(status='accepted_baseline_with_recorded_compile_boundaries',receipt=pin(BASE/'execution.json'),commands=141,raw_streams=282,original_compiles=12,original_VM_runs=8,original_VM_cases=64,wrong_CodeSource=12,api=24,jadx=12,generated_compiles=72,generated_success=40,generated_failure=32,generated_VM_runs=0,physical_classfiles_reparsed=physical_count,source_pins_verified=len(x['source_pins_after_finally']),oracle=oracle,physical_bindings=bindings,compile_counts=[dict(producer=k[0],target=k[1],exit_code=k[2],count=v) for k,v in sorted(counts.items())],limitation='32 Jarde single-class full-source compiles cannot find nested Receiver; do not borrow original inner classes or count any as runtime pass. Generated replay not yet executed.',target_absent=True)
(OUT/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in review.items() if k not in ('oracle','physical_bindings','compile_counts','receipt')})
