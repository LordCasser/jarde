# Static adversarial review: proved List Object argument wrappers

Read-only review of the current shared implementation and test plus private v1/v2 patch artifacts. No Rust, formatter, JDK, CLI, Git mutation, or network command was run. This is static review only; it makes no runtime-acceptance claim.

## Blocking finding

The optional `List.remove(Object)` argument cleanup is not fully isolated from failure to obtain its AST call site. In shared `src/facade.rs`, `prove_generic_list_parameter_body` builds `call_keys` from every selected List parameter receiver call, including `remove(Object)` (currently around lines 14485–14504). It requests all those keys in one `class_source_invoke_ast_sites` call (around 14513–14521), and returns `Ok(None)` if that batch returns `None`. The report helper explicitly returns `None` when any requested call is missing, duplicated, or mismatched (`crates/jarde-java/src/report.rs`, around 2106–2180). Since `None` here rejects the List-body candidate, an absent/non-unique remove AST site can discard otherwise established generic/typed output instead of merely retaining the wrapper. This is within the OpenSpec “Unknown optional proof” condition (“精确调用或唯一 AST 包装证据” missing).

The new metamorphic test `optional_remove_argument_break_leaves_required_list_proof_and_equals_edit` mutates only the remove argument SSA fact while keeping the AST call site intact. It proves argument-proof refusal is harmless, but does not cover call-site lookup refusal. Suggested narrow repair: acquire required call sites separately from the optional remove cleanup site, and treat a missing optional remove site as “no edit”; retain the already closed physical List receiver-use proof. Do not swallow budget/cancel/deadline errors, which correctly propagate through `?`.

## Checks without additional confirmed blockers

- Required `add(Object)` still fails the body proof when its wrapper/local/SSA evidence is absent; only that branch appends its element type to `type_uses`.
- `remove` is admitted only for the exact `List.remove:(Object)Z` interface call; `remove(int)` is absent from the contract. Its argument proof is optional and does not feed element inference.
- `String.equals` is restricted to `java/lang/String.equals:(Object)Z` virtual invokes. The receiver must be a String-presented local whose physical receiver fact closes through the local proof; its sole argument fact is exact and independently checked. Missing equals-site/argument evidence skips only that cleanup.
- Optional helper refusals return `None` and continue; budget/cancellation stops propagate as errors. Staged and final optional edit vectors are recomputed and compared. The staged opaque projector receives the same-transaction presentation, overload, and typed-foreach edit sets.
- The v2 nested scope/name and equals-site cross-product charges conservatively cover the reviewed comparisons; no definite budget undercharge was identified.

## Pins

Shared `src/facade.rs`: `80b9575c538774c385a2932396e94e5f67334ec62363eea3b04fad900dfe91ef`.
Shared `tests/structured_list_generic_bodies.rs`: `8fd1d4d9e237294e87c2ddf9e7f5d7af2649de135e50b5cc511d0fff8fbba676`.
Private v1 patch: `e71f3a171b3318e46db11be058f001b56dc2ee3bf61fe00b8ba32f883fa55cd9`.
Private v2 incremental patch: `9fa9c71712810220af09dd9857668d1bc4cfc6c5887e151d8e6410d9d08e4ca4`.
Private v2 rebased patch: `a5e0310f139f786d4130bee9c114281c470d41801275b2643f9e9f297714db62`.
Private v2 facade snapshot: `b66c769375a8c3d145c7644430798ea82df44891d145f5c2ea5fa86a3c587ae2`.
OpenSpec design: `5f7607f66ee2a2df140316aa07bf7c8ecac286ba0ea609beec287404ba66f4d8`; tasks: `6ddebca78c66d6a0fa0c12c1e3fc480c58bd9e2871f2090b62a19c4c6bfba2f9`; delta spec: `f7307542b6c8c582626f69f10c38fbec8474e477d594c36aadd25e6a3f3f121c`.
