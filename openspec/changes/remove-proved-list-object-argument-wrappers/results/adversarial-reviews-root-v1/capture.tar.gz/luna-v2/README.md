# Re-adjudication: optional List Object argument wrapper proof

This v2 memo supersedes the blocker conclusion in `...final-adversarial-luna-v1-20261018/README.md`; v1 is preserved unchanged. Read-only static review only. No Rust, formatter, JDK, CLI, Git mutation, or network command was run. No runtime acceptance is claimed.

## Retraction

The prior finding conflated a required List receiver-use proof with the newly optional removal of an argument wrapper. In the baseline `prove_generic_list_parameter_body`, the `call_keys`/`call_sites` pass already requested and validated the AST sites for all recognized List receiver calls, including `remove(Object)`; these are unchanged context in the v1 patch, not a new optional-path requirement. If that mandatory call site is absent/ambiguous, the baseline could not prove the List parameter's source receiver identity/use closure either, so there is no previously reliable core result to preserve. Do not weaken that receiver closure to implement optional cleanup.

For a valid mandatory remove call site, the new optional argument branch checks for an Object presentation wrapper, local child, caller identity and one SSA argument fact. Missing any of these, or failing the local physical proof, executes `continue` without adding a removal or element type. The new metamorphic test breaks the remove argument's `replaced_by` fact while retaining the call site, then asserts the required List proof and add removals remain, the equals edit remains, and the remove edit is omitted. This is directly the optional-proof failure class.

The String.equals path is separately inventoried. Missing or ambiguous optional equals AST sites leave `equals_sites` as `None`, and the code skips its cleanup loop without changing the List proof. Stop errors remain propagated via `?`.

I found no reachable counterexample where the new optional cleanup withdraws a baseline-valid core candidate. The shared projector still stages presentation removals together with required call casts and typed-foreach edits, then the final pass recomputes and compares the same removal vector. Every optional removal is created from a uniquely resolved site in that same retained AST and a wrapper-child/local/SSA proof; the edit targets a distinct external List/String call and does not overlap typed-foreach header edits. Ordinary proof misses therefore do not enter the transaction. A true budget/cancel/deadline stop is propagated and intentionally aborts publication under the spec.

The v1 refactor extracts the previous required add(E) physical proof into a shared helper and adds consistency checks for the exact load/definition/use identity. Those checks are stricter than the old inline spelling in a few places; from static code they align with the same-run SSA invariants and I found no concrete valid scanner state that the prior proof accepted and the helper rejects. Root's focused/runtime tests remain the necessary non-regression evidence.

## Pins

Shared current `src/facade.rs` read-only SHA256: `80b9575c538774c385a2932396e94e5f67334ec62363eea3b04fad900dfe91ef`.
Shared current `tests/structured_list_generic_bodies.rs` read-only SHA256: `8fd1d4d9e237294e87c2ddf9e7f5d7af2649de135e50b5cc511d0fff8fbba676`.
Private v1 patch SHA256: `e71f3a171b3318e46db11be058f001b56dc2ee3bf61fe00b8ba32f883fa55cd9`.
Private v2 incremental patch SHA256: `9fa9c71712810220af09dd9857668d1bc4cfc6c5887e151d8e6410d9d08e4ca4`.
Private v2 rebased patch SHA256: `a5e0310f139f786d4130bee9c114281c470d41801275b2643f9e9f297714db62`.
OpenSpec design SHA256: `5f7607f66ee2a2df140316aa07bf7c8ecac286ba0ea609beec287404ba66f4d8`; tasks: `6ddebca78c66d6a0fa0c12c1e3fc480c58bd9e2871f2090b62a19c4c6bfba2f9`; delta spec: `f7307542b6c8c582626f69f10c38fbec8474e477d594c36aadd25e6a3f3f121c`.
