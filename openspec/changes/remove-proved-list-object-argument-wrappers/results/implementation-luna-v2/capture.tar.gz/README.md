# Private v2 handoff: proved List Object argument wrappers

This fresh v2 preserves v1 and adds the requested budget bounds and an internal optional-proof refusal test. It is based on `/private/tmp/jarde-object-argument-implementation-luna-v1-20261018`; no shared source was edited and no Cargo, formatter, JDK, Jarde CLI, Git mutation, or network command was run.

## V2 changes

- The nested foreach ownership check now precharges its actual upper bound: selected reads × (formal and foreach candidate scans, foreach-site × assignment-anchor identity comparisons, and compared names). The assignment/declaration name and reference-type comparisons are charged before they run, as are nested scope paths and method identity work.
- The optional String equals AST-site match now precharges the invokes × equals-sites cross-product, including method identity comparison work, before filtering the pairs.
- The `prove_generic_list_parameter_body` comment now describes both required add edits and optional removals.
- A new `generic_list_*` unit test uses the frozen fixed class, same-run physical invoke/body-value facts, and a retained AST plus generic candidate. It mutates only the List.remove argument's `replaced_by` fact, then asserts the List candidate, required types, add removals, and independent equals removal still succeed while the remove edit is omitted. This is an internal malformed-fact metamorphism, not legal-JVM evidence.

## Artifacts and pins

`changes.patch` is the v1-to-v2 incremental diff. `changes-from-current.patch` is the same change rebased onto the currently applied/formatted v1 shared source snapshot for root review. The full edited source is in `src/facade.rs`.

- V1 private base facade SHA-256: `990f1ee5d64958e5d4bd9bf6cee9f29ef2cee2ca2d9fb7bc145e90c449abc619`
- Current shared v1 facade SHA-256 read-only pin: `470d9c62790d3c80041a3f70a54ffb3eb94d9491334770a547c8a27ec16ea407`
- Private v2 facade SHA-256: `b66c769375a8c3d145c7644430798ea82df44891d145f5c2ea5fa86a3c587ae2`
- Incremental patch SHA-256: `9fa9c71712810220af09dd9857668d1bc4cfc6c5887e151d8e6410d9d08e4ca4`
- Rebased patch SHA-256: `a5e0310f139f786d4130bee9c114281c470d41801275b2643f9e9f297714db62`

No tests or formatting were run. Root's v1 focused test/CLI success is not evidence for v2; the v2 unit test and budget impact remain unverified until root runs them.
