# Static review: one-seed acceptance prep v2

No acceptance, workspace, Git, network, or toolchain command was run. Python AST parsing and static gate-count assertions only.

## Findings

The v2 native wrapper preserves the accepted ancestor wrapper's exact 18 gate identities by importing its pinned `verify-native.py` module data without invoking its two-seed `main()`. It appends the two requested `jarde` tests and statically checks the total is 20 unique `(target, test)` pairs. The imported frozen `verify_workspace.py` is then given this exact list before its full `validate_one` path; this retains its metadata identity, raw Cargo `Running`/harness, guard, live source-pin, cleanup, default stack, and exact-occurrence checks. The wrapper fixes seed `5350648285461741569` and checks the two new test identities in the returned gate records.

The one-seed binder now ties the acceptance report to the exact supplied native receipt by path/size/SHA, seed, canonical source-pin digest, dynamic target inventory size, workspace totals, and source-pin count. It requires broad source-before/source-after equality and empty accepted source changes, merges source hashes, checks the live files against Git blobs and modes at the supplied revision, checks the CLI bytes/SHA against the broad receipt, and requires the target directory absent.

One assurance limitation remains: `bind_product_one.py` uses `--product` as the Git revision but does not itself compare that value to the checkout's current `HEAD`. Therefore it proves binding to the supplied revision, not that the supplied revision is the actual HEAD. When root invokes it, derive `PRODUCT` from `git rev-parse HEAD` immediately before binding (or add a private checker assertion before execution). Example sequence:

```sh
PRODUCT_HEAD="$(git rev-parse HEAD)"
python3 -B /private/tmp/jarde-current-change-one-seed-acceptance-prep-luna-v2-20261018/bind_product_one.py \
  --product "$PRODUCT_HEAD" \
  --build /path/to/final-broad/execution.json \
  --native /path/to/one-seed/execution.json \
  --acceptance /path/to/one-seed/native-review.json \
  --out /private/tmp/<fresh-output>/product-binding.json
```

The working tree's expected source files must still match the supplied commit's blobs/modes; the binder will reject divergence. `verify_one_native.py` can run first with the one native receipt and a fresh output path. `verify-own-ci.py` accepts repeated `--extra-critical TARGET=FULL_TEST_NAME`, rejects duplicate target/name pairs (including inherited gates), keeps the 63 inherited-gate invariant, derives the total from the supplied list, and serializes all additions. For this leaf pass both exact test names with `jarde=`.

## Static evidence and pins

- Frozen ancestor gate wrapper: 18 identities, all unique; SHA256 `6ed9fda0ab467c191747365bbe4cea6e084e1053be9bc2eddc28ab3c4fc231c9`.
- New one-seed wrapper: SHA256 `fd93c639fff5dbb3da0489de5194779ba776e5553b99a883a3bb0f69dad18c9d`.
- New one-seed binder: SHA256 `59ef3f1b42e713ca334e8ae9dc1e87ccdf4aef829e3a2c0a041d722463bbdcc0`.
- Own-CI v2 verifier: SHA256 `bb9f37d7fa64f8e85180d30233849e0a8bb100a352797df3316822aa1e84dc9c`.
- AST parsing passed for all three new/updated scripts; static counts: 18 inherited + 2 new = 20 unique native gates.
