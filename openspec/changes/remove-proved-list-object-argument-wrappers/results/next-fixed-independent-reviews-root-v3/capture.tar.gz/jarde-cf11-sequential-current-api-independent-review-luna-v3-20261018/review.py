#!/usr/bin/env python3
"""Read-only independent review of the eight-cell Seq1 API receipt."""
import argparse, hashlib, json, zipfile
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde').resolve()
RECEIPT=Path('/private/tmp/jarde-cf11-sequential-current-api-root-v2-20261018/execution.json')
BASE_REVIEW=Path('/private/tmp/jarde-testsequentialloops-baseline-run-root-v1-20261018/independent-review/root-review.json')
BASE_RECEIPT=Path('/private/tmp/jarde-testsequentialloops-baseline-run-root-v1-20261018/execution.json')
PAIRS=Path('/private/tmp/jarde-cf11-sequential-current-api-prep-root-v2-20261018/pairs.json')
PREVIOUS=Path('/private/tmp/jarde-sequential-loops-current-api-root-v1-20261018/execution.json')
BROAD=Path('/private/tmp/jarde-object-argument-broad-root-v2-20261018/execution.json')
IGNORED={'usage','elapsed_millis'}
METHOD_BCIS={0,1,2,3,4,5,7,9,11,14,17,19,20,23,24,25,26,27,29,31,34,36,37,40,41}
TARGET='jadx/tests/integration/loops/TestSequentialLoops$TestCls'

def need(ok,msg):
    if not ok: raise ValueError(msg)
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(path):
    path=Path(path).resolve(strict=True); b=path.read_bytes()
    return {'path':str(path),'bytes':len(b),'sha256':sha(b)}
def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def clean(x):
    if isinstance(x,dict): return {k:clean(v) for k,v in x.items() if k not in IGNORED}
    if isinstance(x,list): return [clean(v) for v in x]
    return x
def raw(rec, base):
    p=Path(rec['path']).resolve(strict=True)
    need(p.is_relative_to(base.resolve(strict=True)),f'raw escapes receipt: {p}')
    b=p.read_bytes(); need(len(b)==rec['bytes'] and sha(b)==rec['sha256'],f'raw pin mismatch: {p}')
    return b
def text_for(doc): return doc.get('text','')
def identity(m): return (tuple(m['item']['identity']['name']),tuple(m['item']['identity']['descriptor']))
def validate(receipt_path,pairs_path):
    receipt_path=receipt_path.resolve(strict=True); pairs_path=pairs_path.resolve(strict=True)
    rec=read(receipt_path); pairs=read(pairs_path); base=receipt_path.parent
    previous=read(PREVIOUS); broad=read(BROAD)
    need(previous.get('status')=='captured-pending-independent-review', 'unexpected previous API receipt state')
    need(broad.get('status')=='commands_passed_pending_independent_acceptance', 'unexpected final broad receipt state')
    need(len(rec.get('commands',[]))==9 and [c.get('index') for c in rec['commands']]==list(range(1,10)), 'current receipt command inventory/indexes changed')
    need(rec['commands'][0]['argv'][0]==broad['cli']['path'] and pin(broad['cli']['path'])==broad['cli'], 'current API CLI is not the pinned final broad CLI')
    need(len(broad.get('commands',[]))==18 and broad['commands'][-1].get('cleanup_only') is True, 'final broad receipt command inventory changed')
    prev_commands={c['index']:c for c in previous['commands']}
    prev_cells={(c['profile'],c['input_form'],c['evidence']):c for c in previous['cells']}
    need(len(previous.get('commands',[]))==8 and len(prev_cells)==8, 'previous API matrix inventory changed')
    base_review=read(BASE_REVIEW); need(pin(BASE_RECEIPT)==base_review.get('input'), 'frozen baseline receipt pin differs from its accepted review')
    base_receipt=read(BASE_RECEIPT); need(base_receipt.get('source_unchanged') is True and base_receipt.get('target_absent') is True, 'frozen baseline source/target status invalid')
    profile_rows={x['profile']:x for x in base_receipt['profiles']}
    need(set(profile_rows)=={'debug','no-debug'}, 'frozen baseline profiles missing')
    for pn,pr in profile_rows.items():
        target_pin=pr['target']; outer_pin=pr['outer']
        need(pin(target_pin['path'])=={k:target_pin[k] for k in ('path','bytes','sha256')}, f'{pn}: original target class pin mismatch')
        need(pin(outer_pin['path'])=={k:outer_pin[k] for k in ('path','bytes','sha256')}, f'{pn}: original outer class pin mismatch')
    debugfacts=base_review['compiled_profiles']['profiles']['debug']['method_code']; expected=next(x['bcis'] for x in debugfacts if x['name']=='test' and x['descriptor']=='(II)I')
    need(set(expected)==METHOD_BCIS and base_review['compiled_profiles']['debug_no_debug_all_two_Code_methods_identical'] is True, 'physical BCI inventory differs from frozen original review')
    need(rec.get('status')=='commands_passed_pending_independent_acceptance','unexpected receipt state')
    need(len(rec.get('commands',[]))==9 and len(pairs)==8,'unexpected command/pair count')
    need(rec.get('source_unchanged') is True and rec.get('target_absent') is True,'collector source/target guard failed')
    need(rec.get('source_before')==rec.get('source_after'),'source closure changed between snapshots')
    cli=Path(rec['commands'][0]['argv'][0]); cli_pin=pin(cli)
    rows=[]; whole_by_profile={}; owner_digests={}; method_texts={}
    input_forms={'child','bundle-child'}; evidences={'default','all'}; profiles={'debug','no-debug'}
    seen=set()
    for pair in pairs:
        i=pair['index']; key=(pair['profile'],pair['input_form'],pair['evidence'])
        need(key not in seen and key[0] in profiles and key[1] in input_forms and key[2] in evidences,f'duplicate/bad cell {key}'); seen.add(key)
        cmd=rec['commands'][i-1]; argv=pair['new_argv']; need(cmd['index']==i and cmd['argv']==argv,f'{key}: argv/index mismatch')
        pcell=prev_cells.get(key); need(pcell is not None,f'{key}: prior API cell missing')
        need(pcell.get('input')==pair['input'] and pcell.get('candidate_report')==pair['old_report'],f'{key}: prior cell input/report binding mismatch')
        pindex=pcell.get('command'); pcmd=prev_commands.get(pindex)
        need(type(pindex) is int and pcmd is not None and pcmd.get('index')==pindex,f'{key}: prior command index not bound')
        old_argv=pcell.get('argv'); need(old_argv==pair['old_argv'] and pcmd.get('argv')==old_argv,f'{key}: prior cell/command argv mismatch')
        need(argv[1:]==old_argv[1:],f'{key}: current argv differs beyond executable path')
        need(old_argv[0]==previous['cli']['path'] and pin(old_argv[0])==previous['cli'],f'{key}: prior CLI pin mismatch')
        need(pcmd.get('exit_code')==0 and pcmd.get('guard_stop') is None,f'{key}: prior command failed or hit guard')
        oldout=raw(pcmd['streams']['stdout'],PREVIOUS.parent); olderr=raw(pcmd['streams']['stderr'],PREVIOUS.parent)
        old_path=Path(pair['old_report']['path']).resolve(strict=True)
        need(oldout==old_path.read_bytes() and not olderr,f'{key}: prior raw stdout/stderr differs from saved report')
        need(Path(argv[0]).resolve()==cli.resolve(),f'{key}: candidate CLI differs')
        need(cmd['exit_code']==0 and cmd.get('guard_stop') is None,f'{key}: command did not complete')
        need(type(cmd.get('peak_target_bytes')) is int and cmd['peak_target_bytes']<=1024**3,f'{key}: target bound missing/exceeded')
        need(type(cmd.get('free_bytes_after')) is int and cmd['free_bytes_after']>=5*1024**3,f'{key}: free-space bound missing')
        need(cmd['cwd']==str(ROOT),f'{key}: cwd mismatch')
        inp=Path(pair['input']['path']).resolve(strict=True); data=inp.read_bytes()
        need({'path':str(inp),'bytes':len(data),'sha256':sha(data)}==pair['input'],f'{key}: input pin mismatch')
        need(argv[argv.index('--input')+1]==str(inp),f'{key}: argv input mismatch')
        need(argv[argv.index('--class')+1]==TARGET,f'{key}: class argument mismatch')
        if pair['input_form']=='child': class_bytes=data
        else:
            with zipfile.ZipFile(inp) as z: class_bytes=z.read(TARGET+'.class')
            standalone=inp.parent / inp.stem / 'classes' / (TARGET+'.class') if inp.suffix=='.jar' else inp
            need(standalone.is_file() and standalone.read_bytes()==class_bytes,f'{key}: bundled class differs from paired standalone class')
        need(len(class_bytes)>0,f'{key}: empty class payload')
        out=raw(cmd['streams']['stdout'],base); err=raw(cmd['streams']['stderr'],base)
        need(not err,f'{key}: unexpected stderr')
        doc=json.loads(out.decode('utf-8')); need(doc.get('execution',{}).get('status')=='complete',f'{key}: report incomplete')
        old_pin=pair['old_report']; old_path=Path(old_pin['path']).resolve(strict=True)
        need(pin(old_path)==old_pin,f'{key}: prior report pin mismatch')
        need(old_path==Path(pcell['candidate_report']['path']).resolve(strict=True),f'{key}: report path differs from prior cell')
        old=read(old_path)
        old_methods=old.get('methods',[]); need(len(old_methods)==2,f'{key}: previous report method inventory changed')
        old_test=next((m for m in old_methods if identity(m)==(tuple(map(ord,'test')),tuple(map(ord,'(II)I')))),None)
        need(old_test is not None and old_test.get('outcome',{}).get('report',{}).get('quality')=='fallback',f'{key}: paired previous report is not the expected old fallback')
        need(doc.get('class',{}).get('class_bytes',{}).get('length')==len(class_bytes),f'{key}: report owner length mismatch')
        methods=doc.get('methods',[]); need(len(methods)==2,f'{key}: method inventory changed')
        byid={identity(m):m for m in methods}; need(len(byid)==2,f'{key}: duplicate method identity')
        test=byid.get((tuple(map(ord,'test')),tuple(map(ord,'(II)I')))); need(test is not None,f'{key}: test(II)I missing')
        report=test.get('outcome',{}).get('report'); need(report is not None,f'{key}: test has no report')
        need(report.get('quality')=='structured' and report.get('fallbacks')==[],f'{key}: test not structured/no-fallback')
        need(report.get('semantic_validation')=='unproven' and report.get('compile_status')=='not_attempted',f'{key}: validation scope changed')
        segments=report.get('source_map',{}).get('segments',[]); need(len(segments)>0,f'{key}: source map empty')
        mapped=set(); owner_digest=doc['class']['class_bytes']['digest']
        for seg in segments:
            raw_text=report['text'].encode('utf-8')
            need(0<=seg['start']<seg['end']<=len(raw_text),f'{key}: map span out of report text')
            try: raw_text[:seg['start']].decode('utf-8'); raw_text[:seg['end']].decode('utf-8')
            except UnicodeDecodeError: need(False,f'{key}: map span splits a UTF-8 scalar')
            origin=seg['origin']; origins=[origin['primary'],*origin.get('derived',[])]
            for o in origins:
                mm=o['method']; need(mm['owner']['class_bytes']['digest']==owner_digest and mm['name']==list(map(ord,'test')) and mm['descriptor']==list(map(ord,'(II)I')),f'{key}: foreign map origin')
                need(o['bci'] in METHOD_BCIS,f'{key}: map BCI outside Code instruction set')
                mapped.add(o['bci'])
        need(mapped==METHOD_BCIS,f'{key}: BCI coverage mismatch: {sorted(METHOD_BCIS-mapped)}')
        owner_digests.setdefault(key[0],set()).add(owner_digest)
        method_texts.setdefault(key[0],set()).add(report['text'])
        whole=text_for(doc); need(whole and whole.startswith('// jarde:') and 'not a compilable project' in whole,f'{key}: unexpected whole-class text')
        need(whole.count('while (')==2 and whole.count('break;')==1 and whole.count('return c;')+whole.count('return local3;')==1,f'{key}: golden loop shape mismatch')
        need('while (true)' in whole and '>= 7)' in whole and 'return local3;' in whole if key[0]=='no-debug' else 'while (true)' in whole and 'while ((z = c + a) >= 7)' in whole,f'{key}: expected sequential loop forms missing')
        whole_by_profile.setdefault(pair['profile'],set()).add(whole)
        rows.append({'index':i,'profile':key[0],'input_form':key[1],'evidence':key[2],'exit_code':0,'paired_previous_test_quality':'fallback','current_test_quality':'structured','recovery_transition':'fallback_to_structured','test_bcis_mapped':len(mapped),'source_map_segments':len(segments),'golden_shape':{'while':2,'break':1,'return':1}})
    need(seen=={(p,f,e) for p in profiles for f in input_forms for e in evidences},'grid incomplete')
    cleanup=rec['commands'][8]
    need(cleanup.get('index')==9 and cleanup.get('cleanup_only') is True and cleanup.get('argv')==['cargo','clean'] and cleanup.get('exit_code')==0 and cleanup.get('guard_stop') is None,f'cleanup command record malformed')
    cleanup_out=raw(cleanup['streams']['stdout'],base); cleanup_err=raw(cleanup['streams']['stderr'],base)
    need(len(cleanup_out)==cleanup['streams']['stdout']['bytes'] and len(cleanup_err)==cleanup['streams']['stderr']['bytes'], 'cleanup stream verification failed')
    need(all(len(v)==1 for v in whole_by_profile.values()),'same-profile whole-class output differs across input/evidence variants')
    need(all(len(v)==1 for v in method_texts.values()),'same-profile test method text differs across input/evidence variants')
    need(all(len(v)==1 for v in owner_digests.values()),'same-profile class owner digest differs across input forms')
    return {'status':'reviewed_api_recovered_from_previous_fallback','receipt':pin(receipt_path),'pairs':pin(pairs_path),'baseline_review':pin(BASE_REVIEW),'baseline_receipt':pin(BASE_RECEIPT),'baseline_classes':{k:{'target':v['target'],'outer':v['outer']} for k,v in profile_rows.items()},'previous_api_receipt':pin(PREVIOUS),'final_broad_receipt':pin(BROAD),'cli':cli_pin,'cell_count':len(rows),'cells':rows,'same_profile_whole_text':{k:next(iter(v)) for k,v in whole_by_profile.items()},'method_bci_set':sorted(METHOD_BCIS),'owner_digests_by_profile':{k:next(iter(v)) for k,v in owner_digests.items()},'interpretation':'All eight current API reports are complete and structured; every paired previous report recorded a fallback for test(II)I. Current outputs agree within each debug profile across child/bundle and default/all inputs. The recovered test body has two while loops, one break and one return, with source-map origins covering the full physical instruction set. This is API/source-map evidence only: compile_status is not_attempted and semantic_validation is unproven; no JDK runtime acceptance is implied.'}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--receipt',type=Path,default=RECEIPT); ap.add_argument('--pairs',type=Path,default=PAIRS); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args()
    result=validate(a.receipt,a.pairs); a.out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8'); print(json.dumps({'status':result['status'],'cells':result['cell_count'],'out':str(a.out)}))
if __name__=='__main__': main()
