#!/usr/bin/env python3
"""Independent read-only verifier for a captured 32-call CF11 class-source API matrix."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, pathlib, sys, zipfile

ROOT = pathlib.Path('/Users/lordcasser/workspace/projects/jarde')
PREP = pathlib.Path('/private/tmp/jarde-cf11-current-fixed-api-prep-root-v1-20261018')
CLI = pathlib.Path('/private/tmp/jarde-object-argument-broad-root-v2-20261018/candidate-cli')
CLI_SHA = '56a589ef9a170a1bb2911ed5597c20b2b4e06abf78da845f8fd3946099b2fa51'
PAIRS_SHA = '4a30c3d33924f00222d6d6e5f256f256b06b8b021bb2dac45f0b6d1ed0d723ba'
PARSER = pathlib.Path('/private/tmp/jarde-seq2-baseline-prep-root-v5-20261018/classfile_helpers.py')


def need(ok, msg):
    if not ok: raise ValueError(msg)
def sha(data): return hashlib.sha256(data).hexdigest()
def pin(path):
    p=pathlib.Path(path).resolve(strict=True); b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def verify_pin(p, label):
    path=pathlib.Path(p['path']); data=path.read_bytes()
    need(len(data)==p['bytes'] and sha(data)==p['sha256'], f'{label}: pin mismatch')
    return data
def decode_ascii(raw): return bytes(raw).decode('ascii')
def method_key(m):
    i=m['item']['identity']; return (tuple(i['name']),tuple(i['descriptor']))
def pair_key(argv):
    a=list(argv)
    if '--evidence' in a:
        i=a.index('--evidence'); del a[i:i+2]
    return tuple(a)
def target_bytes(input_path, internal_name):
    p=pathlib.Path(input_path); data=p.read_bytes()
    if data[:4] == b'\xca\xfe\xba\xbe': return data
    with zipfile.ZipFile(p) as z: return z.read(internal_name + '.class')
def boundaries(data):
    return {0,len(data),*(i for i,b in enumerate(data) if b & 0xc0 != 0x80)}
def origin_method_matches(origin, identity, owner):
    m=origin['method']
    return (m['name']==identity['name'] and m['descriptor']==identity['descriptor']
            and m['owner']['class_bytes']==owner)
def load_parser():
    spec=importlib.util.spec_from_file_location('cf11_physical_classfile', PARSER)
    module=importlib.util.module_from_spec(spec); sys.modules[spec.name]=module; spec.loader.exec_module(module)
    return module

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('receipt',type=pathlib.Path); ap.add_argument('output',type=pathlib.Path)
    args=ap.parse_args(); need(not args.output.exists(),'refusing to overwrite output')
    receipt_path=args.receipt.resolve(strict=True); receipt_raw=receipt_path.read_bytes(); receipt=json.loads(receipt_raw)
    prep_commands=json.loads((PREP/'commands.json').read_text())
    pairs_path=PREP/'luna-frozen'/'pairs.json'; pairs_raw=pairs_path.read_bytes()
    need(sha(pairs_raw)==PAIRS_SHA,'frozen historical pair inventory changed')
    frozen=json.loads(pairs_raw)['pairs']
    need(len(prep_commands)==len(frozen)==32,'prep inventory is not exactly 32')
    need(receipt.get('status')=='commands_passed_pending_independent_acceptance','receipt is not a terminal pending-review capture')
    need(len(receipt['commands'])==33,'expected 32 API calls and one recorded cleanup command')
    cli_pin=pin(CLI); need(cli_pin['sha256']==CLI_SHA,'final CLI differs from frozen pin')
    spec_pin=pin(PREP/'commands.json')
    need(receipt['spec']==spec_pin,'receipt does not bind the frozen argv file')
    parser=load_parser(); cells=[]; old_deltas=[]; by_default={}; owner_by_class={}
    for idx,(argv, pair, command) in enumerate(zip(prep_commands,frozen,receipt['commands'][:32]),1):
        need(command['index']==idx and command['argv']==argv==pair['final56_replay_argv'],f'command {idx}: argv/index does not bind prep and pair')
        need(command['exit_code']==0 and command['guard_stop'] is None and command['peak_target_bytes']<=1073741824 and command['free_bytes_after']>=5*1024**3,
             f'command {idx}: failed/guarded or outside resource bounds')
        outpin=command['streams']['stdout']; raw=verify_pin(outpin,f'command {idx} stdout')
        err=verify_pin(command['streams']['stderr'],f'command {idx} stderr'); need(not err,f'command {idx}: unexpected stderr')
        doc=json.loads(raw); need(doc['outcome']=='performed' and doc['execution']['status']=='complete',f'command {idx}: class result incomplete')
        input_path=pathlib.Path(argv[argv.index('--input')+1]); input_raw=input_path.read_bytes()
        need(len(input_raw)==pair['input']['bytes'] and sha(input_raw)==pair['input']['sha256'],f'command {idx}: input bytes differ from frozen pair')
        physical=target_bytes(input_path,argv[argv.index('--class')+1].replace('.','/'))
        facts=parser.parse_class_file(physical)
        need(facts['class_name']==argv[argv.index('--class')+1].replace('.','/'),f'command {idx}: physical class identity mismatch')
        owner=doc['class']['class_bytes']; need(owner['length']==len(physical),f'command {idx}: reported class size differs from physical class')
        class_sha=sha(physical); old_owner=owner_by_class.setdefault(class_sha,owner)
        need(old_owner==owner,f'command {idx}: identical physical class bytes have inconsistent owner pins')
        pmethods={(m['name'],m['descriptor']):m for m in facts['methods']}
        got_methods={method_key(m):m for m in doc['methods']}
        expected_methods={(tuple(map(ord,m['name'])),tuple(map(ord,m['descriptor']))):m for m in facts['methods']}
        need(set(got_methods)==set(expected_methods),f'command {idx}: method inventory differs from classfile')
        need(len(doc['fields'])==len(facts['fields']),f'command {idx}: field inventory count differs')
        for m in doc['methods']:
            ident=m['item']['identity']; k=method_key(m); name=decode_ascii(ident['name']); desc=decode_ascii(ident['descriptor']); fact=pmethods[(name,desc)]
            need(m['item']['index']==fact['index'] and m['item']['access_flags']==fact['access'],f'command {idx}: method index/access mismatch {name}{desc}')
            need(m['outcome']['kind']=='recovered' and m['outcome']['report']['quality']=='structured' and not m['outcome']['report']['fallbacks'],f'command {idx}: method not structured or used fallback {name}{desc}')
            report=m['outcome']['report']; code=fact['code']; need(code is not None,f'command {idx}: structured method has no Code')
            need(code['bcis']==parser.decode_bcis(bytes.fromhex(code['code_hex'])),f'command {idx}: physical Code BCI parse mismatch')
            rr=report['text'].encode('utf-8'); bounds=boundaries(rr); mapped=set()
            for seg in report['source_map']['segments']:
                start,end=seg['start'],seg['end']
                need(0<=start<end<=len(rr) and start in bounds and end in bounds,f'command {idx}: raw map span is not valid UTF-8 byte range')
                origin=seg['origin']
                for row in [origin['primary']]+origin['derived']:
                    need(origin_method_matches(row,ident,owner),f'command {idx}: map origin is not this physical method/owner')
                    need(row['bci'] in code['bcis'],f'command {idx}: origin BCI is outside physical Code')
                    mapped.add(row['bci'])
            need(mapped==set(code['bcis']),f'command {idx}: raw map does not cover every physical instruction BCI')
            need(m['item']['identity']['owner']==owner or m['item']['identity']['owner']['class_bytes']==owner,
                 f'command {idx}: item owner differs from class bytes')
        for fld,fact in zip(doc['fields'],facts['fields']):
            item=fld['item']; ident=item['identity']['member']
            need(item['index']==fact['index'] and item['access_flags']==fact['access'] and ident['name']==list(map(ord,fact['name'])) and ident['descriptor']==list(map(ord,fact['descriptor'])),f'command {idx}: field identity/access mismatch')
            need(item['identity']['owner']['class_bytes']==owner,f'command {idx}: field owner differs')
        need(doc['class']['class_bytes']['length']==len(physical),f'command {idx}: class facts length mismatch')
        # Bind historical comparison to its original receipt command and raw stdout, without treating it as current acceptance.
        src=pathlib.Path(pair['source_receipt']); srcraw=src.read_bytes(); need(sha(srcraw)==pair['source_receipt_sha256'],f'command {idx}: historical receipt pin mismatch')
        oldexec=json.loads(srcraw); oldmatch=[c for c in oldexec['commands'] if c['argv']==pair['old_class_source_argv']]
        need(len(oldmatch)==1,f'command {idx}: historical argv is not unique in its receipt')
        oc=oldmatch[0]; need(oc['exit_code']==0,f'command {idx}: historical class-source command did not exit zero'); archived_old=verify_pin(pair['old_report_stdout_raw'],f'command {idx} archived old stdout')
        old_pin=oc['streams']['stdout']
        need(old_pin['bytes']==len(archived_old) and old_pin['sha256']==sha(archived_old),f'command {idx}: historical receipt stdout pin differs from archived raw')
        oldstdout=archived_old
        olddoc=json.loads(oldstdout)
        if pair.get('old_report_json') is not None:
            old_report_raw=verify_pin(pair['old_report_json'],f'command {idx} old report JSON')
            need(json.loads(old_report_raw)==olddoc,f'command {idx}: historical saved report differs semantically from raw stdout'); need(olddoc['class']['class_bytes']==owner,f'command {idx}: historical owner pin differs for identical class bytes')
        oldmap={(method_key(m)):m for m in olddoc['methods']}; changes=[]
        for key,m in got_methods.items():
            om=oldmap.get(key); need(om is not None,f'command {idx}: method absent from historical report')
            nr=m['outcome']['report']; orr=om['outcome']['report']
            changed=[name for name,yes in [('raw_text',nr['text']!=orr['text']),('projected_text',m['text']!=om['text']),('quality',nr['quality']!=orr['quality']),('fallbacks',nr['fallbacks']!=orr['fallbacks']),('source_map',nr['source_map']!=orr['source_map'])] if yes]
            if changed:
                changes.append({'method':decode_ascii(key[0])+decode_ascii(key[1]),'changed_facts':changed})
        if doc['text']!=olddoc['text'] or changes:
            old_deltas.append({'command':idx,'sample':pair['sample'],'label':pair['label'],'whole_class_text_changed':doc['text']!=olddoc['text'],'methods':changes})
        key=pair_key(argv); mode='all' if '--evidence' in argv else 'default'; by_default.setdefault(key,{})[mode]=(doc,idx)
        cells.append({'command':idx,'label':pair['label'],'sample':pair['sample'],'input':pin(input_path),'input_class_bytes':len(physical),'class_name':facts['class_name'],'methods':len(facts['methods']),'fields':len(facts['fields']),'raw_stdout':{'bytes':len(raw),'sha256':sha(raw)},'historical_source_receipt':{'path':pair['source_receipt'],'sha256':pair['source_receipt_sha256']},'historical_stdout_pin':pair['old_report_stdout_raw'],'historical_saved_report_pin':pair.get('old_report_json'),'all_methods_structured_no_fallback':True})
    parity=[]
    need(len(by_default)==16,'default/all matrix did not form 16 paired inputs')
    for key,modes in by_default.items():
        need(set(modes)=={'default','all'},'input does not have one default and one all evidence call')
        a,ai=modes['default']; b,bi=modes['all']
        need(a['text']==b['text'],'default/all whole class text differs')
        need([(m['text'],m['outcome']['report']['text']) for m in a['methods']]==[(m['text'],m['outcome']['report']['text']) for m in b['methods']], 'default/all projected or raw method text differs')
        need([m['outcome']['report']['source_map'] for m in a['methods']]==[m['outcome']['report']['source_map'] for m in b['methods']], 'default/all raw method maps differ')
        parity.append({'default_command':ai,'all_command':bi,'whole_and_method_text_equal':True,'raw_maps_equal':True})
    clean=receipt['commands'][32]
    need(clean['index']==33 and clean['argv']==['cargo','clean'],'unexpected recorded cleanup command')
    need(clean['exit_code']==0,'recorded cleanup command failed')
    need(receipt.get('source_unchanged') is True and receipt.get('source_changes_accepted') is True and receipt.get('target_absent') is True,'receipt terminal source/target guards failed')
    need(receipt['source_before']==receipt['source_after'] and not receipt['source_changes'],'source tree before/after inventory differs')
    summary={'status':'independent_32_call_api_review_passed','receipt':{'path':str(receipt_path),'bytes':len(receipt_raw),'sha256':sha(receipt_raw)},'cli':cli_pin,'prep_commands':spec_pin,'frozen_pairs':{'path':str(pairs_path),'bytes':len(pairs_raw),'sha256':sha(pairs_raw)},'api_calls':len(cells),'cells':cells,'default_all_pairs':parity,'historical_differences':old_deltas,'historical_comparison_limit':'old reports are input/reference evidence only, not the final accepted product snapshot; no VM, JADX, or runtime claim is made','cleanup_command_recorded':True,'source_unchanged':True,'target_absent':True,'physical_parser':pin(PARSER)}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('x') as f: json.dump(summary,f,ensure_ascii=False,indent=2,sort_keys=True); f.write('\n')
    print(json.dumps({'status':summary['status'],'api_calls':len(cells),'parity_pairs':len(parity),'historical_deltas':len(old_deltas),'output':str(args.output)}))
if __name__=='__main__':
    try: main()
    except (OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile,json.JSONDecodeError) as e: raise SystemExit(f'API review failed: {e}')
