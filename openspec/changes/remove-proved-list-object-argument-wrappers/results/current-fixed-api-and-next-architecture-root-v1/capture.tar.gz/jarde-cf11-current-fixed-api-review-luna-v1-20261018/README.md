# CF11 current fixed API review

Read-only review of `/private/tmp/jarde-cf11-current-fixed-api-root-v1-20261018/execution.json` against the frozen 32 argv/pair records in `/private/tmp/jarde-cf11-current-fixed-api-prep-root-v1-20261018/`.

`review.py` binds each live receipt command index and exact argv to the frozen pair; checks raw stdout/stderr byte pins, the final broad CLI pin, archived input byte pins, historical receipt command argv/exit/stdout pins, and optional saved report JSON; parses each class (including selected class entries from jars) with the already-pinned physical classfile parser; compares full method/field inventories and access/index identities; validates Code BCI decoding; and validates each raw report source-map's UTF-8 byte ranges, physical owner/method identity, and full instruction BCI coverage. It verifies all method reports are structured without fallback and pairs default/all for whole class text, projected method text, raw method text, and raw maps.

Review result: 32/32 API calls passed; 16/16 default/all pairs match. The historical reports differ only for `NestedLoops3.test(I)I` and `NestedLoops5.testFor()I`: both move from fallback to structured output (with raw/projected text, quality, fallback list, and source map changes). Other methods and the other three sample groups do not show historical method-text/map changes. These older reports are reference evidence, not a claim that they represent the final accepted product snapshot.

No VM, JADX, runtime, compilation, CLI execution, or whole-CF11 completion claim is made. The only cleanup row was read from the receipt; no cleanup was run here.

Run command used for the independent reviewer:

```sh
python3 /private/tmp/jarde-cf11-current-fixed-api-review-luna-v1-20261018/review.py \
  /private/tmp/jarde-cf11-current-fixed-api-root-v1-20261018/execution.json \
  /private/tmp/jarde-cf11-current-fixed-api-review-luna-v1-20261018/review-final-v2.json
```

Review script SHA-256: `f84f4891a2fdbf97a94cd07593804b1843e74be51f15f453ea6979dd4aac75f0`  
Review JSON SHA-256: `41063905aea7fa341467ab1cfd839cae4452b4d9f16530971fbdd557a22065b6`
