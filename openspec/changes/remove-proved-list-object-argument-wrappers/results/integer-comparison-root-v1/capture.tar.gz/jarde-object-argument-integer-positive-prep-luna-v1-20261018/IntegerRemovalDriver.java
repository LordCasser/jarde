import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Driver-only class path; loads the target afresh with no application parent. */
public final class IntegerRemovalDriver {
    @SuppressWarnings("rawtypes")
    private static final class TraceList extends ArrayList {
        int removeObject, removeInt, adds, clears;
        final List<String> events = new ArrayList<String>();
        TraceList(Integer... values) { super(Arrays.asList(values)); }
        @Override public boolean remove(Object value) {
            removeObject++; events.add("remove-object:" + String.valueOf(value));
            return super.remove(value);
        }
        @Override public Object remove(int index) {
            removeInt++; events.add("remove-int:" + index);
            return super.remove(index);
        }
        @Override public boolean add(Object value) {
            adds++; events.add("add:" + String.valueOf(value));
            return super.add(value);
        }
        @Override public void clear() {
            clears++; events.add("clear");
            super.clear();
        }
        void resetTrace() {
            removeObject = removeInt = adds = clears = 0;
            events.clear();
        }
    }

    private static String state(Object value) {
        return value == null ? "<null>" : String.valueOf(value);
    }

    private static URL checkCodeSource(String actualRoot, String expectedRoot,
                                       URLClassLoader loader) throws Exception {
        Class<?> target = Class.forName("cf11.DistinctIntegerFixture", false, loader);
        URL actual = target.getProtectionDomain().getCodeSource().getLocation();
        URL expected = Paths.get(expectedRoot).toRealPath().toUri().toURL();
        if (target.getClassLoader() != loader
                || !actual.toURI().normalize().equals(expected.toURI().normalize())) {
            throw new IllegalStateException("wrong CodeSource: " + actual + " expected " + expected);
        }
        return actual;
    }

    private static void one(String actualRoot, String expectedRoot, String name,
                            TraceList selected, TraceList available) throws Exception {
        URL actual = Paths.get(actualRoot).toRealPath().toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(new URL[] { actual }, null)) {
            checkCodeSource(actualRoot, expectedRoot, loader);
            Class<?> type = Class.forName("cf11.DistinctIntegerFixture", true, loader);
            Object receiver = type.getConstructor().newInstance();
            type.getField("effects").setInt(null, 0);
            if (selected != null) selected.resetTrace();
            if (available != null) available.resetTrace();
            Method method = type.getMethod("numbers", List.class, List.class);
            String thrown = "none";
            try {
                method.invoke(receiver, selected, available);
            } catch (InvocationTargetException error) {
                Throwable cause = error.getCause();
                thrown = cause == null ? "unknown" : cause.getClass().getName();
            }
            int effects = type.getField("effects").getInt(null);
            int selectedRemoveObject = selected == null ? 0 : selected.removeObject;
            int selectedRemoveInt = selected == null ? 0 : selected.removeInt;
            int selectedAdds = selected == null ? 0 : selected.adds;
            int selectedClears = selected == null ? 0 : selected.clears;
            int availableRemoveObject = available == null ? 0 : available.removeObject;
            int availableRemoveInt = available == null ? 0 : available.removeInt;
            int availableAdds = available == null ? 0 : available.adds;
            int availableClears = available == null ? 0 : available.clears;
            System.out.println("CASE|" + name
                    + "|exception=" + thrown
                    + "|selected=" + state(selected)
                    + "|available=" + state(available)
                    + "|effects=" + effects
                    + "|selectedRemoveObject=" + selectedRemoveObject
                    + "|selectedRemoveInt=" + selectedRemoveInt
                    + "|selectedAdd=" + selectedAdds
                    + "|selectedClear=" + selectedClears
                    + "|availableRemoveObject=" + availableRemoveObject
                    + "|availableRemoveInt=" + availableRemoveInt
                    + "|availableAdd=" + availableAdds
                    + "|availableClear=" + availableClears
                    + "|selectedEvents=" + (selected == null ? "-" : String.join(",", selected.events))
                    + "|availableEvents=" + (available == null ? "-" : String.join(",", available.events)));
        }
    }

    private static TraceList ints(Integer... values) { return new TraceList(values); }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("actualRoot expectedRoot");
        String actual = args[0], expected = args[1];
        one(actual, expected, "integer-isolated-empty", ints(), ints());
        one(actual, expected, "integer-isolated-add-cme", ints(5, 8), ints(5, 9));
        one(actual, expected, "integer-isolated-remove-object-cme", ints(4, 7, 8), ints(4));
        TraceList nullElement = ints((Integer) null);
        one(actual, expected, "integer-isolated-null-element", nullElement, ints(1));
        one(actual, expected, "integer-isolated-null-list", null, ints(1));
        TraceList polluted = ints(1, 2);
        ((List) polluted).add("not-an-integer");
        one(actual, expected, "integer-isolated-heap-pollution", polluted, ints(9));
    }
}
