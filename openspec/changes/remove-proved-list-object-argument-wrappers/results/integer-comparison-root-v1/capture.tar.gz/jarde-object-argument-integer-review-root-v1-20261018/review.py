from pathlib import Path
import ast,json,hashlib,importlib.util,zipfile
BASE=Path('/private/tmp/jarde-object-argument-integer-positive-root-v1-20261018');x=json.loads((BASE/'execution.json').read_text())
def ck(p):
 b=Path(p['path']).read_bytes();assert len(b)==p['bytes'] and hashlib.sha256(b).hexdigest()==p['sha256'],p['path']
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
assert x['status']=='captured-pending-review' and x['final_integrity_ok'] and len(x['commands'])==50
assert x['source_pins_before']==x['source_pins_after']==x['source_pins_after_finally'] and x['external_pins_before']==x['external_pins_after_finally'] and x['output_pins_before_final']==x['output_pins_after_finally']
for group in (x['source_pins_after_finally'].values(),x['external_pins_after_finally'],x['output_pins_after_finally'].values(),x['local_copies_after_finally'].values()):
 for p in group:ck(p)
for c in x['commands']:
 assert c['guard_stop'] is None and c['peak_target_bytes']==0 and c['free_bytes_after']>=5*1024**3 and c['default_stack']
 for p in c['streams'].values():ck(p)
assert x['target_absent_finally'] and not Path('target').exists()
assert len(x['original_runs'])==2 and x['original_runs'][0]['stdout']==x['original_runs'][1]['stdout'];oracle=x['original_runs'][0]['stdout']
assert len(oracle.splitlines())==6 and 'selectedRemoveObject=1|selectedRemoveInt=0' in oracle
assert len(x['generated_compiles'])==10 and len(x['generated_runs'])==20 and len(x['generated_wrong_roots'])==10
for r in x['original_source_compiles']:assert r['exit_code']==0 and r['matches_frozen_inventory'] and r['runtime_claim'].endswith('not executed')
for r in x['generated_compiles']:
 assert r['exit_code']==0 and r['matches_frozen_inventory'] and Path(r['source']['path']).read_bytes()==Path(r['source_copy']['path']).read_bytes()
for r in x['generated_runs']:
 c=x['commands'][r['command']-1];args=c['argv'];ci=args.index('-cp');assert args[ci+2]=='IntegerRemovalDriver' and len(args[ci+3:])==2 and args[-1]==args[-2]
 assert r['exit_code']==0 and r['matches_original_oracle'] and r['stdout']==oracle and Path(c['streams']['stdout']['path']).read_text()==oracle
for r in x['generated_wrong_roots']:
 c=x['commands'][r['command']-1];assert c['exit_code']==1 and r['rejected'] and 'wrong CodeSource:' in Path(c['streams']['stderr']['path']).read_text() and c['argv'][-1]!=c['argv'][-2]
compare=load(x['compare']['path'],'integer_review_compare');physical=load(x['physical_parser']['path'],'integer_review_physical')
tree=ast.parse(Path('/private/tmp/jarde-object-argument-controls-review-root-v1-20261018/review.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='cp_refs');ns={'Path':Path,'physical':physical};exec(compile(ast.Module(body=[fn],type_ignores=[]),'cp_refs_reused','exec'),ns)
paths=[]
for d in (x['frozen_original_class_tree'],*[r['class_tree'] for r in x['original_source_compiles']],*[r['class_tree'] for r in x['generated_compiles']]):
 for p in d.values():
  a=compare.parse_class(Path(p['path']));b=physical.parse_class_file(Path(p['path']).read_bytes());assert a['methods']==b['methods']
  refs=ns['cp_refs'](p['path']);remove=[q for k,v in refs.items() if k.startswith('numbers(') for q in v if q.get('owner')=='java/util/List' and q.get('name')=='remove'];assert len(remove)==1 and remove[0]['descriptor']=='(Ljava/lang/Object;)Z';paths.append({'class':p,'remove':remove})
with zipfile.ZipFile(BASE/'original-classes.jar') as z:
 assert z.namelist()==['cf11/DistinctIntegerFixture.class'] and z.read(z.namelist()[0])==Path(x['fixture_class']['path']).read_bytes()
def clean(v):
 if isinstance(v,dict):return {k:clean(w) for k,w in v.items() if k!='usage'}
 if isinstance(v,list):return [clean(w) for w in v]
 return v
for evidence in ('default','all'):
 a=clean(json.loads(Path(next(c for c in x['api_cells'] if c['producer']=='baseline' and c['evidence']==evidence)['report']['path']).read_text()));b=clean(json.loads(Path(next(c for c in x['api_cells'] if c['producer']=='candidate' and c['evidence']==evidence)['report']['path']).read_text()))
 old='selected.remove((java.lang.Object) option)';new='selected.remove(option)'
 assert a['text'].count(old)==1 and b['text']==a['text'].replace(old,new);a['text']=b['text']
 methods=[m for m in a['methods'] if bytes(m['item']['identity']['name'])==b'numbers'];assert len(methods)==1 and methods[0]['text'].count(old)==1;methods[0]['text']=methods[0]['text'].replace(old,new)
 assert a==b,'non-usage API differences beyond exact whole/method source replacement'
classes_equal=[]
for c in x['generated_compiles']:
 if c['producer']=='candidate':
  a=next(r for r in x['generated_compiles'] if r['producer']=='baseline' and r['compiler']==c['compiler'] and r['evidence']==c['evidence']);rel='cf11/DistinctIntegerFixture.class';assert a['class_facts'][rel]['methods']==c['class_facts'][rel]['methods'];classes_equal.append((c['compiler'],c['evidence']))
result={'status':'accepted_integer_v2_product_source_matrix','candidate_cli':x['candidate_cli'],'commands':50,'raw_streams':100,'original_VM_runs':2,'original_cases':12,'original_source_compiles':2,'original_source_compile_runtime_claim':False,'generated_compiles':10,'generated_VM_runs':20,'generated_cases':120,'wrong_CodeSource':10,'CP_remove_bindings':paths,'raw_and_all_nonusage_API_unchanged_except':{'whole_text':old+' -> '+new,'numbers_method_text':old+' -> '+new},'generated_baseline_candidate_method_Code_identical':classes_equal,'source_pins_verified':len(x['source_pins_after_finally']),'target_absent':True,'limitation':'V2 CLI e22 actual run; upcoming v3 must independently bind identical full Java/API before reuse, no claim v3 JVM has run'}
(Path(__file__).parent/'review.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k not in ('CP_remove_bindings','candidate_cli','raw_and_all_nonusage_API_unchanged_except')})
