// jarde: presentation of `cf11/DistinctIntegerFixture` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf11;

public class DistinctIntegerFixture extends java.lang.Object {
    public static int effects;

    public DistinctIntegerFixture() {
        // @method <init>()V
        // @declaration a constructor of `cf11.DistinctIntegerFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public void numbers(java.util.List<java.lang.Integer> selected, java.util.List<java.lang.Integer> available) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/Integer;>;Ljava/util/List<Ljava/lang/Integer;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method numbers(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.DistinctIntegerFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    for (java.lang.Integer value : selected) {
                        for (java.lang.Integer option : available) {
                            if (value.equals((java.lang.Object) option)) {
                                if (value.intValue() == 5) {
                                    available.add(option);
                                    cf11.DistinctIntegerFixture.effects = cf11.DistinctIntegerFixture.effects + 1;
                                } else {
                                    selected.remove(option);
                                    cf11.DistinctIntegerFixture.effects = cf11.DistinctIntegerFixture.effects + 1;
                                }
                            }
                        }
                    }
                    if (available.size() > 0) {
                        selected.clear();
                        cf11.DistinctIntegerFixture.effects = cf11.DistinctIntegerFixture.effects + 1;
                    }
                    return;
    }
}
