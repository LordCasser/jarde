# Integer remove(Object) positive replay (preparation only)

This private bundle prepares an acceptance run for the existing `cf11.DistinctIntegerFixture.numbers(List<Integer>, List<Integer>)` input. It reuses the full pinned Java source and exact class already checked into `tests/fixtures/cf11-structured-list-inner-option`; it creates no target fixture or product change. `provenance.json` is pinned and checked against both source/class hashes. The six labels and input shapes come from the existing `cf11-structured-list-api/DistinctIntegerFixture/Runner.java`.

`IntegerRemovalDriver.java` loads each target from a fresh parentless loader and validates its CodeSource before reflection. Its two `TraceList`s record calls to `remove(Object)`, `remove(int)`, add, and clear, as well as final contents and `effects`. The removal control must actually hit `remove(Object)` and never the index overload. This directly observes the Java overload-resolution consequence for `Integer`; it is not inferred from output text.

The unexecuted `collect_integer.py` accepts the two CLI paths and SHA-256 pins, plus a fresh `--out`. It captures default/all raw API JSON and complete source for the frozen baseline CLI `26eb…` and the root-supplied candidate; gets one full JADX source from the exact input class; compiles original and generated complete sources with javac 8 and 23; runs successful generated outputs on both VMs with `-Xverify:all`; and performs wrong-CodeSource checks. Runtime rows are compared byte-for-byte to the frozen original class per VM, without hardcoded expected case outcomes. The two original-source compiler runs are inventory comparisons only; the frozen original classfile is the runtime oracle. Commands use the existing compare/guard/scanner/JDK manifest/runtime wrapper; the receipt records command streams, class facts, pins, and final source/resource checks. A failed cell is left explicit in the capture.

Suggested invocation after root supplies the candidate path/hash:

```sh
python3 -B collect_integer.py \
  --baseline-cli /private/tmp/jarde-ancestor-iterator-broad-root-v3-20261018/candidate-cli \
  --baseline-sha256 26eb321d0810a54328f7880483c6c5a5c2033c2ad747f7b177a51e723e96af52 \
  --candidate-cli CANDIDATE_CLI --candidate-sha256 CANDIDATE_SHA256 \
  --out NEW_PRIVATE_CAPTURE_DIRECTORY
```

This is preparation, not evidence of compilation, execution, source improvement, or acceptance. Before running, root should statically review the collector; afterward, independently compare both raw reports, require the target method to be structured with no fallback in either profile, compare full-source texts and method-local maps, runtime rows, compiler results, and wrong-root exits. The collector stores the unmodified full report JSON for this review; it intentionally does not infer fallback schema fields. The source retains `(Object) option`; whether the candidate drops that wrapper is observed from its actual whole source. No CLI, Java tool, Cargo, or collector was executed for this preparation, and the shared repository was not edited.
