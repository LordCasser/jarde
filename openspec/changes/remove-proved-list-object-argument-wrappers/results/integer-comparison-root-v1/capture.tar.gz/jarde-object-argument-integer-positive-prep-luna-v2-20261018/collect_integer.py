#!/usr/bin/env python3
"""Prepared, not executed: compare old/candidate Object-argument output and runtime."""
from __future__ import annotations
import argparse, atexit, hashlib, importlib.util, json, os, re, shutil, sys, zipfile
from pathlib import Path
sys.dont_write_bytecode = True

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
SOURCE = ROOT / 'tests/fixtures/cf11-structured-list-inner-option/DistinctIntegerFixture.java'
CLASS = ROOT / 'tests/fixtures/cf11-structured-list-inner-option/DistinctIntegerFixture.class'
CASES = ROOT / 'tests/fixtures/cf11-structured-list-api/DistinctIntegerFixture/Runner.java'
PROVENANCE = ROOT / 'tests/fixtures/cf11-structured-list-inner-option/provenance.json'
DRIVER = Path(__file__).resolve().parent / 'IntegerRemovalDriver.java'
COMPARE = ROOT / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD = ROOT / 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
MANIFEST = ROOT / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
MANIFEST_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
PHYSICAL = Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PHYSICAL_SHA = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
FACTS_HELPER = Path('/private/tmp/jarde-object-argument-baseline-prep-luna-v2-20261018/collect_baseline.py')
FACTS_HELPER_SHA = '102186e11c687a63b2e54fb77acb262ba83146e9e116647b98d02c5d8ce9578b'
TOOL_REF = Path('/private/tmp/jarde-ancestor-iterator-controls-baseline-root-v1-20261018/execution.json')
TOOL_REF_SHA = '843cbc2aaa79becb6dca8e0da05141532c5c9bff88bbaeefd048c7615b532392'
RUNTIME = Path('/private/tmp/jarde-object-argument-controls-baseline-root-v3-20261018/capture/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
RUNTIME_SHA = '73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
BASELINE_SHA = '26eb321d0810a54328f7880483c6c5a5c2033c2ad747f7b177a51e723e96af52'
SOURCE_SHA = '067ae158526955a9d04830bd019f54da00699238a184c35b31590c5e4c611191'
CLASS_SHA = '935d0c2aed93723ee59b0c407dec4e999c4bc11a8593b07765f122f5f9761d2d'
CASES_SHA = '7344b21e1a6a39d53c9ef3dca5ab43da7fb90a7c4d8c607f3bb0085d736667a3'
PROVENANCE_SHA = '3096545a198cdc6c5485650bafac8bb68ae5eb46e130269d4766c8669a1f3cd2'
DRIVER_SHA = '4274faefbf8483b0864860a8bd0a0ca1e6316b8f2488c51250819358c0536aca'
MIN_FREE = 5 * 1024**3
MAX_TARGET = 1024**3
IDENTITY = 'cf11.DistinctIntegerFixture'

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def require(path, expected, label):
    if not path.is_file() or sha(path) != expected: raise RuntimeError(f'{label} pin mismatch: {path}')

def write_json(path, value): path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')

CASE_NAMES={'integer-isolated-empty','integer-isolated-add-cme','integer-isolated-remove-object-cme',
  'integer-isolated-null-element','integer-isolated-null-list','integer-isolated-heap-pollution'}

def parse_cases(text):
    rows=[]
    for line in text.splitlines():
        parts=line.split('|')
        if not parts or parts[0]!='CASE' or len(parts)<3: raise RuntimeError('malformed driver case row')
        row={'name':parts[1]}
        for part in parts[2:]:
            key,sep,value=part.partition('=')
            if not sep or key in row: raise RuntimeError('malformed/duplicate driver field')
            row[key]=value
        rows.append(row)
    if len(rows)!=6 or {r['name'] for r in rows}!=CASE_NAMES: raise RuntimeError('driver cases differ from six pinned controls')
    removed=next(r for r in rows if r['name']=='integer-isolated-remove-object-cme')
    if int(removed['selectedRemoveObject'])<1 or int(removed['selectedRemoveInt'])!=0:
        raise RuntimeError('Integer removal did not dispatch through remove(Object)')
    return rows

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--baseline-cli', type=Path, required=True)
    ap.add_argument('--baseline-sha256', required=True)
    ap.add_argument('--candidate-cli', type=Path, required=True)
    ap.add_argument('--candidate-sha256', required=True)
    ap.add_argument('--out', type=Path, required=True)
    cli_args = ap.parse_args()
    root = ROOT.resolve(strict=True); out = cli_args.out.resolve();
    if out.exists() or out == root or root in out.parents: raise RuntimeError('output must be new and private')
    if (root / 'target').exists() or (root / 'target').is_symlink(): raise RuntimeError('target must be absent')
    if shutil.disk_usage(root).free < MIN_FREE: raise RuntimeError('less than 5 GiB free')
    baseline = cli_args.baseline_cli.resolve(strict=True); candidate = cli_args.candidate_cli.resolve(strict=True)
    if cli_args.baseline_sha256 != BASELINE_SHA or sha(baseline) != cli_args.baseline_sha256: raise RuntimeError('baseline CLI pin mismatch')
    if re.fullmatch('[0-9a-f]{64}', cli_args.candidate_sha256) is None or sha(candidate) != cli_args.candidate_sha256: raise RuntimeError('candidate CLI pin mismatch')
    for p, h, label in ((SOURCE,SOURCE_SHA,'fixture source'),(CLASS,CLASS_SHA,'fixture class'),
            (CASES,CASES_SHA,'six-case source'),(PROVENANCE,PROVENANCE_SHA,'class/source provenance'),
            (COMPARE,COMPARE_SHA,'compare'),(GUARD,GUARD_SHA,'guard'),
            (SCANNER,SCANNER_SHA,'scanner'),(MANIFEST,MANIFEST_SHA,'JDK manifest'),
            (PHYSICAL,PHYSICAL_SHA,'physical parser'),(FACTS_HELPER,FACTS_HELPER_SHA,'facts helper'),
            (TOOL_REF,TOOL_REF_SHA,'JADX tool reference'),(RUNTIME,RUNTIME_SHA,'runtime wrapper')):
        require(p,h,label)
    provenance=json.loads(PROVENANCE.read_text(encoding='utf-8'))
    rows={Path(x['destination']).name:x for x in provenance.get('inputs',[])}
    if rows.get(CLASS.name,{}).get('sha256')!=CLASS_SHA or rows.get(SOURCE.name,{}).get('sha256')!=SOURCE_SHA:
        raise RuntimeError('fixture provenance does not bind source and class pins')
    if DRIVER_SHA == 'PENDING': raise RuntimeError('reviewer must freeze and fill driver SHA before running')
    require(DRIVER,DRIVER_SHA,'driver')
    compare=load(COMPARE,'integer_compare'); guard=load(GUARD,'integer_guard')
    scanner=load(SCANNER,'integer_scanner'); physical=load(PHYSICAL,'integer_physical')
    helper=load(FACTS_HELPER,'integer_facts')
    jdks,jdk_record=compare.configured_jdks(MANIFEST,MANIFEST_SHA)
    ref=json.loads(TOOL_REF.read_text());
    jadx=Path(ref['tool_reference_jadx']['path']).resolve(strict=True)
    jadx_jar=Path(ref['tool_reference_jadx_jar']['path']).resolve(strict=True)
    require(jadx,ref['tool_reference_jadx']['sha256'],'JADX launcher')
    require(jadx_jar,ref['tool_reference_jadx_jar']['sha256'],'JADX jar')
    source_before=compare.source_closure(root)
    out.mkdir(parents=True); rawdir=out/'raw'; rawdir.mkdir(); empty=out/'empty-classpath'; empty.mkdir()
    guard.ROOT=root; guard.OUT=rawdir; guard.target_bytes=lambda:scanner.target_bytes(root)
    guard.command_stream=compare.pin; guard.expected_test_summaries=lambda i,d:None
    copied={}
    for label,src in [('source',SOURCE),('class',CLASS),('six_case_source',CASES),('provenance',PROVENANCE),('driver',DRIVER),('runtime',RUNTIME)]:
        dst=out/'inputs'/src.name; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dst)
        if dst.read_bytes()!=src.read_bytes(): raise RuntimeError('frozen input copy mismatch '+label)
        copied[label]=dst
    runtime_copy=copied['runtime']; driver=copied['driver']
    external=[COMPARE,GUARD,SCANNER,MANIFEST,PHYSICAL,FACTS_HELPER,TOOL_REF,RUNTIME,jadx,jadx_jar,
              SOURCE,CLASS,CASES,PROVENANCE,DRIVER,Path(__file__),baseline,candidate,*[Path(x) for j in jdks.values() for x in j['tools'].values()]]
    external_before=[compare.pin(p) for p in external]
    report={'schema':'cf11-integer-object-removal-positive-v1','status':'running','root':str(root),'output':str(out),
      'baseline_cli':compare.pin(baseline),'baseline_expected_sha256':cli_args.baseline_sha256,
      'candidate_cli':compare.pin(candidate),'candidate_expected_sha256':cli_args.candidate_sha256,
      'jdk_manifest':jdk_record,'fixture_source':compare.pin(SOURCE),'fixture_class':compare.pin(CLASS),
      'fixture_provenance':compare.pin(PROVENANCE),'case_reference':compare.pin(CASES),
      'driver':compare.pin(DRIVER),'compare':compare.pin(COMPARE),
      'guard':compare.pin(GUARD),'scanner':compare.pin(SCANNER),'physical_parser':compare.pin(PHYSICAL),
      'facts_helper':compare.pin(FACTS_HELPER),'jadx':compare.pin(jadx),'jadx_jar':compare.pin(jadx_jar),
      'runtime':compare.pin(RUNTIME),'source_pins_before':source_before,'external_pins_before':external_before,
      'local_copies_before':{k:compare.pin(v) for k,v in copied.items()},
      'guard_limits':{'free_bytes_min':MIN_FREE,'target_bytes_max':MAX_TARGET},'commands':[],
      'original_source_compiles':[],'original_runs':[],'api_cells':[],'jadx_cell':None,
      'generated_compiles':[],'generated_runs':[],'generated_wrong_roots':[]}
    write_json(out/'execution.json',report)
    def output_pins():
        roots={
          'driver-classes':out/'driver-classes',
          'original-frozen':out/'original-frozen',
          'original-source':out/'original-source',
          'api':out/'api', 'jadx':out/'jadx',
          'generated-sources':out/'generated-sources',
          'generated-classes':out/'generated-classes'}
        pins={}
        for label,base in roots.items():
            if not base.exists(): continue
            for path in sorted(base.rglob('*')):
                if not path.is_file(): continue
                suffix=path.suffix
                if suffix in ('.class','.java') or (label=='api' and path.name=='report.json'):
                    pins[path.relative_to(out).as_posix()]=compare.pin(path)
        return pins
    def finalize():
        try:
            report['source_pins_after_finally']=compare.source_closure(root)
            report['external_pins_after_finally']=[compare.pin(p) for p in external]
            report['local_copies_after_finally']={k:compare.pin(v) for k,v in copied.items()}
            report['source_unchanged_finally']=report['source_pins_after_finally']==source_before
            report['external_unchanged_finally']=report['external_pins_after_finally']==external_before
            report['local_copies_unchanged_finally']=report['local_copies_after_finally']==report['local_copies_before']
            report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
            report['output_pins_after_finally']=output_pins()
            before=report.get('output_pins_before_final')
            report['output_pins_unchanged_finally']=(
              before==report['output_pins_after_finally'] if before is not None else None)
            final_checks=[report['source_unchanged_finally'],report['external_unchanged_finally'],
              report['local_copies_unchanged_finally'],report['target_absent_finally']]
            if before is not None: final_checks.append(report['output_pins_unchanged_finally'])
            report['final_integrity_ok']=all(final_checks)
            if not report['final_integrity_ok']:
                report['status_before_integrity_failure']=report.get('status')
                report['status']='failed-final-integrity'
            if report.get('status')=='running': report['status']='incomplete-capture'
            write_json(out/'execution.json',report)
        except Exception as error:
            (out/'finalization-error.txt').write_text(repr(error)+'\n',encoding='utf-8')
    atexit.register(finalize)
    def command(argv,label,leg):
        env=compare.clean_env(dict(os.environ),jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK',None)
        row=guard.run_command(len(report['commands'])+1,[str(x) for x in argv],env)
        row['label']=label; row['tool_leg']=leg; row['default_stack']='RUST_MIN_STACK' not in env
        for ch in ('stdout','stderr'): compare.command_artifact(row,ch)
        report['commands'].append(row); write_json(out/'execution.json',report)
        violation=[]
        if row.get('guard_stop') is not None: violation.append('guard_stop')
        if row.get('free_bytes_after',0)<MIN_FREE: violation.append('free_bytes_after_below_5GiB')
        if row.get('peak_target_bytes',MAX_TARGET+1)>MAX_TARGET: violation.append('peak_target_over_1GiB')
        if (root/'target').exists() or (root/'target').is_symlink(): violation.append('target_appeared')
        if violation:
            report['status']='failed-command-guard'; report['command_guard_failure']={'command':row['index'],'reasons':violation}
            write_json(out/'execution.json',report)
            raise RuntimeError('command/resource guard failed: '+','.join(violation))
        return row
    def raw(row,ch): return compare.command_artifact(row,ch)
    def profile_root(label):
        p=out/label/'classes'; (p/'cf11').mkdir(parents=True,exist_ok=True)
        (p/'cf11/DistinctIntegerFixture.class').write_bytes(copied['class'].read_bytes()); return p
    original=profile_root('original-frozen')
    frozen_facts=helper.facts(compare,physical,original)
    report['frozen_original_class_facts']=frozen_facts
    report['frozen_original_class_tree']=helper.class_tree(original,compare)
    write_json(out/'execution.json',report)
    driver_classes=out/'driver-classes'; driver_classes.mkdir()
    d=command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8',
      '-proc:none','-classpath',empty,'-sourcepath',empty,'-d',driver_classes,driver],'compile-driver','javac8')
    if d['exit_code'] != 0: raise RuntimeError('driver compilation failed')
    report['driver_class_tree']=helper.class_tree(driver_classes,compare)
    write_json(out/'execution.json',report)
    def run(root_classes,expected_root,label,vm):
        row=command([sys.executable,'-B',runtime_copy,'30',jdks[vm]['tools']['java'],'-Xverify:all','-cp',driver_classes,
            'IntegerRemovalDriver',root_classes,expected_root],label,vm)
        result={'command':row['index'],'exit_code':row['exit_code'],'stdout':raw(row,'stdout').decode('utf-8','strict'),
                'stderr':raw(row,'stderr').decode('utf-8','replace'),'raw_streams':row['streams']}
        if row['exit_code']==0: result['cases']=parse_cases(result['stdout'])
        return result
    oracle={}
    for vm in ('javac8','javac23'):
        r=run(original,original,'original-'+vm,vm)
        if r['exit_code']!=0: raise RuntimeError('frozen original runtime failed')
        oracle[vm]=r['stdout']; report['original_runs'].append({'vm':vm,**r})
    report['oracle_by_vm']=oracle
    original_source_builds={}
    for leg in ('javac8','javac23'):
        dest=out/'original-source'/leg/'classes'; dest.mkdir(parents=True)
        flags=['-source','8','-target','8'] if leg=='javac8' else ['--release','8']
        cr=command([jdks[leg]['tools']['javac'],*flags,'-g','-encoding','UTF-8','-proc:none','-classpath',empty,
          '-sourcepath',empty,'-d',dest,copied['source']],'compile-original-source-'+leg,leg)
        facts=helper.facts(compare,physical,dest) if cr['exit_code']==0 else None
        match=(facts is not None and helper.inventory(facts)==helper.inventory(frozen_facts))
        original_source_builds[leg]=str(dest)
        report['original_source_compiles'].append({'compiler':leg,'command':cr['index'],'exit_code':cr['exit_code'],
             'class_facts':facts,'class_tree':helper.class_tree(dest,compare) if cr['exit_code']==0 else {},
             'matches_frozen_inventory':match,'runtime_claim':'inventory comparison only; not executed'})
    def api(producer,cli,cli_sha,evidence):
        dest=out/'api'/producer/evidence; dest.mkdir(parents=True)
        argv=[cli,'class-source','--input',copied['class'],'--class',IDENTITY,'--policy','single-class','--release','8','--format','json']
        if evidence=='all': argv+=['--evidence','all']
        row=command(argv,'api-'+producer+'-'+evidence,'javac23')
        data=raw(row,'stdout'); rp=dest/'report.json'; rp.write_bytes(data)
        doc=json.loads(data.decode('utf-8','strict'))
        if row['exit_code']!=0: raise RuntimeError('class-source failed')
        methods=doc.get('methods',[]); identities=[helper_identity(m) for m in methods]
        wanted=('numbers','(Ljava/util/List;Ljava/util/List;)V')
        if identities.count(wanted)!=1 or len(set(identities))!=len(identities):
            raise RuntimeError('numbers method absent/duplicated or API method identities duplicate '+repr(identities))
        if doc.get('execution',{}).get('status')!='complete': raise RuntimeError('API execution not complete')
        text=doc.get('text')
        if not isinstance(text,str) or not text.strip(): raise RuntimeError('whole source missing')
        whole=dest/'whole-source.java'; whole.write_text(text,encoding='utf-8')
        cell={'producer':producer,'cli_sha256':cli_sha,'evidence':evidence,'command':row['index'],
              'exit_code':row['exit_code'],'report':compare.pin(rp),'whole_source':compare.pin(whole),
              'method_identities':identities,'class_status':doc.get('execution',{}).get('status'),
              'method_outcome_keys':[sorted(m.get('outcome',{}).keys()) for m in methods],
              'raw_stdout_sha256':hashlib.sha256(data).hexdigest()}
        report['api_cells'].append(cell); write_json(out/'execution.json',report)
        return whole
    generated_sources=[]
    for producer,cli,cli_sha in [('baseline',baseline,cli_args.baseline_sha256),('candidate',candidate,cli_args.candidate_sha256)]:
        for evidence in ('default','all'):
            generated_sources.append((producer,evidence,api(producer,cli,cli_sha,evidence)))
    # One full JADX source from the frozen original class; it is a reference producer, not edited text.
    bundle=out/'original-classes.jar'
    with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z: z.write(copied['class'],'cf11/DistinctIntegerFixture.class')
    jdir=out/'jadx'; jdir.mkdir()
    jr=command([jadx,'--threads-count','1','--no-res','--config','none','-d',jdir,bundle],'jadx-original-complete-class','javac23')
    javas=sorted(jdir.rglob('*.java'))
    if jr['exit_code']==0 and len(javas)!=1: raise RuntimeError('expected one full source for one-class input')
    report['jadx_cell']={'command':jr['index'],'exit_code':jr['exit_code'],'source_count':len(javas),
      'sources':[compare.pin(p) for p in javas]}; write_json(out/'execution.json',report)
    if jr['exit_code']==0: generated_sources.append(('jadx','source',javas[0]))
    for producer,evidence,source in generated_sources:
        source_bytes=source.read_bytes()
        if re.search(rb'\bpublic\s+class\s+DistinctIntegerFixture\b',source_bytes) is None:
            raise RuntimeError('whole source does not declare the expected public class')
        for compiler in ('javac8','javac23'):
            sroot=out/'generated-sources'/producer/evidence/compiler/'cf11'; sroot.mkdir(parents=True)
            copied_source=sroot/'DistinctIntegerFixture.java'; copied_source.write_bytes(source_bytes)
            if copied_source.read_bytes()!=source.read_bytes(): raise RuntimeError('generated source copy differs')
            dest=out/'generated-classes'/producer/evidence/compiler; dest.mkdir(parents=True)
            flags=['-source','8','-target','8'] if compiler=='javac8' else ['--release','8']
            cr=command([jdks[compiler]['tools']['javac'],*flags,'-g','-encoding','UTF-8','-proc:none','-classpath',empty,
                '-sourcepath',empty,'-d',dest,copied_source],'compile-'+producer+'-'+evidence+'-'+compiler,compiler)
            tree=helper.facts(compare,physical,dest) if cr['exit_code']==0 else None
            matches=tree is not None and helper.inventory(tree)==helper.inventory(helper.facts(compare,physical,original))
            cell={'producer':producer,'evidence':evidence,'compiler':compiler,'command':cr['index'],
                  'exit_code':cr['exit_code'],'class_facts':tree,'matches_frozen_inventory':matches,
                  'class_tree':helper.class_tree(dest,compare) if cr['exit_code']==0 else {},
                  'source':compare.pin(source),'source_copy':compare.pin(copied_source),
                  'runs':[],'wrong_root':None}
            report['generated_compiles'].append(cell); write_json(out/'execution.json',report)
            if cr['exit_code']==0:
                for vm in ('javac8','javac23'):
                    rr=run(dest,dest,'run-'+producer+'-'+evidence+'-'+compiler+'-'+vm,vm)
                    rr['matches_original_oracle']=rr['exit_code']==0 and rr['stdout']==oracle[vm]
                    cell['runs'].append({'vm':vm,**rr}); report['generated_runs'].append({'producer':producer,
                      'evidence':evidence,'compiler':compiler,'vm':vm,**rr})
                wr=run(dest,original,'wrong-root-'+producer+'-'+evidence+'-'+compiler,'javac8')
                cell['wrong_root']={'command':wr['command'],'raw_streams':wr['raw_streams'],
                   'exit_code':wr['exit_code'],'stderr':wr['stderr'],
                   'rejected':wr['exit_code']==1 and 'wrong CodeSource:' in wr['stderr']}
                report['generated_wrong_roots'].append({'producer':producer,'evidence':evidence,
                   'compiler':compiler,**cell['wrong_root']})
                write_json(out/'execution.json',report)
                if not cell['wrong_root']['rejected']:
                    report['status']='failed-wrong-CodeSource-control'
                    report['wrong_root_failure']={'producer':producer,'evidence':evidence,'compiler':compiler,
                      'command':wr['command'],'exit_code':wr['exit_code'],'stderr':wr['stderr']}
                    write_json(out/'execution.json',report)
                    raise RuntimeError('wrong-CodeSource control lacked expected exit/stderr')
            write_json(out/'execution.json',report)
    report['counts']={'commands':len(report['commands']),'api_cells':len(report['api_cells']),
      'generated_compiles':len(report['generated_compiles']),'generated_runs':len(report['generated_runs']),
      'wrong_root_controls':len(report['generated_wrong_roots'])}
    report['source_pins_after']=compare.source_closure(root)
    report['external_pins_after']=[compare.pin(p) for p in external]
    report['source_unchanged']=report['source_pins_after']==source_before
    report['external_unchanged']=report['external_pins_after']==external_before
    report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
    report['output_pins_before_final']=output_pins()
    report['status']='captured-pending-review'
    write_json(out/'execution.json',report)
    shutil.copy2(__file__,out/'collect_integer.py')
    return 0

def helper_identity(method):
    ident=method['item']['identity']
    return (bytes(ident['name']).decode('utf-8'),bytes(ident['descriptor']).decode('utf-8'))

if __name__=='__main__':
    raise SystemExit(main())
