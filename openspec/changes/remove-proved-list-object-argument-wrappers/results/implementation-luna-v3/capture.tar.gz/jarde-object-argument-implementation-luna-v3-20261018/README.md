# Private v3 handoff: per-call optional String.equals proof

V3 is an additive patch against the current formatted shared v2 facade snapshot. Shared source remains untouched. No Cargo, formatter, JDK, CLI, Git mutation, or network command was run.

The prior v2 optional `String.equals` inventory batched all keys into one `class_source_invoke_ast_sites` request. If any key missed the AST, the batch returned no result and prevented unrelated proven equals sites from being edited. V3 sorts `(key, invoke-index)` pairs once, refuses every duplicate call BCI, then queries each unique key independently through the existing AST helper. A missing site skips that one edit; a Stop still propagates. The same helper charges each AST walk. Site matching is separately charged for the returned site's length and method identity comparison. The old invokes-by-sites cross-product scan is removed.

The added `unmatched_optional_equals_key_does_not_hide_valid_calls` test starts from the frozen `TestNestedLoops$TestCls` method's same-run physical facts, retained AST, and generic candidate, then appends one malformed internal equals census row at a unique BCI with no AST node. It asserts required List types and every existing add/remove/equals edit remain, while the fake BCI gains no edit. This is internal metamorphic evidence, not legal-JVM evidence.

## Source pins

- Shared v2 base `src/facade.rs`: `80b9575c538774c385a2932396e94e5f67334ec62363eea3b04fad900dfe91ef`
- Private v3 `src/facade.rs`: `68725f828a292505da8242fa2a31b54e366314f63ecb602fb22a58c2ed6caaf1`
- `changes.patch`: `a5286280d036ae154a9e941d91411bb3e18f6df44b95825a3e4a1e6bdaa4e8b6`

The complete edited source is `src/facade.rs`; `changes.patch` is the diff from the pinned shared v2 source. No test or formatting result is claimed. Root's v2 focused success does not cover v3.
