#!/usr/bin/env python3
"""Prepared full-source rebuild/runtime matrix for TestSequentialLoops outputs.

Use python -B after review. This collector consumes the read-only baseline and
compiles saved source artifacts only; it never edits the Jarde workspace.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASELINE = Path('/private/tmp/jarde-testsequentialloops-baseline-run-root-v1-20261018')
BASELINE_REVIEW = Path('/private/tmp/jarde-testsequentialloops-baseline-review-root-v1-20261018/root-review.json')
CURRENT_API = Path('/private/tmp/jarde-cf11-sequential-current-api-root-v2-20261018')
CURRENT_API_SPEC = Path('/private/tmp/jarde-cf11-sequential-current-api-prep-root-v2-20261018/commands.json')
CURRENT_API_RECEIPT_SHA256 = 'da6c0519ed07edd37117ae3807911fd2827135047a127b5794a194df0ac9e674'
CURRENT_API_SPEC_SHA256 = 'd500abe0d489c1d6254b0b3111e0599256fac9e98a40b83dd56bb81ee4c8568c'
CURRENT_API_RUNNER_SHA256 = '814fa8c6610eb5aa5fbaa74afe2d6443237ccf28115b18080638a94025d332ac'
COMPARE_REL = Path('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
COMPARE_SHA256 = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
EXPECTED_SCHEMA = 'cf11-original-testsequentialloops-baseline-v1'
EXPECTED_STATUS = 'captured-pending-independent-review'
TARGET_REL = Path('jadx/tests/integration/loops/TestSequentialLoops$TestCls.class')
OWNER_REL = Path('jadx/tests/integration/loops/TestSequentialLoops.class')
INTERNAL_CLASS = 'jadx/tests/integration/loops/TestSequentialLoops$TestCls'
EXPECTED_METHODS = {('<init>', '()V'), ('test', '(II)I')}
PROFILES = ('debug', 'no-debug')
FORMS = {'jarde': ('child', 'bundle-child'), 'jadx': ('child', 'bundle')}
EVIDENCE = ('default', 'all')
JDK_LEGS = ('javac8', 'javac23')
RUNTIMES = ('javac8', 'javac23')
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def file_tree_pin(root: Path, compare) -> dict:
    return {path.relative_to(root).as_posix(): compare.pin(path)
            for path in sorted(root.rglob('*')) if path.is_file()}


def class_method_set(facts: dict) -> set[tuple[str, str]]:
    return {(row['name'], row['descriptor']) for row in facts['methods']}


def expected_source_name(kind: str, form: str) -> str:
    if kind == 'jadx' and form == 'bundle':
        return 'TestSequentialLoops.java'
    if form in ('child', 'bundle-child') or (kind == 'jadx' and form == 'child'):
        return 'TestSequentialLoops$TestCls.java'
    raise RuntimeError(f'unexpected source selector: {kind}/{form}')


def pin_is_current(compare, pin: dict, label: str) -> None:
    if compare.pin(Path(pin['path'])) != pin:
        raise RuntimeError(f'{label} pin changed: {pin.get("path")}')


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=ROOT)
    ap.add_argument('--baseline', type=Path, default=BASELINE)
    ap.add_argument('--baseline-review', type=Path, default=BASELINE_REVIEW)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    root, baseline, baseline_review = (args.root.resolve(strict=True), args.baseline.resolve(strict=True),
                                       args.baseline_review.resolve(strict=True))
    out = args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing existing output directory: {out}')
    if root != ROOT.resolve() or baseline != BASELINE.resolve() or baseline_review != BASELINE_REVIEW.resolve():
        raise SystemExit('workspace, baseline, or baseline-review path differs from the pinned Seq1 inputs')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('repository target exists before source-rebuild matrix')
    if shutil.disk_usage(root).free < 5 * 1024**3:
        raise SystemExit('root free-space guard below 5 GiB')

    compare_path = root / COMPARE_REL
    if hashlib.sha256(compare_path.read_bytes()).hexdigest() != COMPARE_SHA256:
        raise SystemExit('compare.py pin mismatch')
    compare = load_module(compare_path, 'seq1_rebuild_compare')
    guard_path, scanner_path = root / compare.GUARD_REL, root / compare.SCANNER_REL
    if compare.sha(guard_path) != compare.GUARD_SHA256 or compare.sha(scanner_path) != compare.SCANNER_SHA256:
        raise SystemExit('run guard/scanner source pin mismatch')
    guard = load_module(guard_path, 'seq1_rebuild_guard')
    scanner = load_module(scanner_path, 'seq1_rebuild_scanner')
    jdk_manifest_path = root / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
    jdks, jdk_record = compare.configured_jdks(jdk_manifest_path,
        'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
    helper_pins = {'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path),
                   'scanner': compare.pin(scanner_path), 'jdk_manifest': compare.pin(jdk_manifest_path)}

    baseline_path = baseline / 'execution.json'
    baseline_doc = json.loads(baseline_path.read_text(encoding='utf-8'))
    baseline_review_doc = json.loads(baseline_review.read_text(encoding='utf-8'))
    current_api_path = CURRENT_API / 'execution.json'
    current_api_doc = json.loads(current_api_path.read_text(encoding='utf-8'))
    current_api_spec_doc = json.loads(CURRENT_API_SPEC.read_text(encoding='utf-8'))
    if compare.sha(current_api_path) != CURRENT_API_RECEIPT_SHA256 or current_api_doc.get('status') != 'commands_passed_pending_independent_acceptance':
        raise SystemExit('pinned current-API receipt is absent, changed, or nonterminal')
    if compare.sha(CURRENT_API_SPEC) != CURRENT_API_SPEC_SHA256 or current_api_doc.get('spec') != compare.pin(CURRENT_API_SPEC):
        raise SystemExit('current-API command specification pin mismatch')
    runner_path = Path(current_api_doc.get('runner', {}).get('path', ''))
    if current_api_doc.get('runner', {}).get('sha256') != CURRENT_API_RUNNER_SHA256 or compare.pin(runner_path) != current_api_doc['runner']:
        raise SystemExit('current-API runner source pin mismatch')
    if (current_api_doc.get('source_unchanged') is not True or current_api_doc.get('target_absent') is not True
            or current_api_doc.get('source_before') != current_api_doc.get('source_after')
            or current_api_doc.get('source_changes') or current_api_doc.get('allowed_source_changes')
            or current_api_doc.get('default_stack') is not True
            or current_api_doc.get('guard') != compare.pin(guard_path)
            or current_api_doc.get('scanner') != compare.pin(scanner_path)):
        raise SystemExit('current-API receipt source/cleanup claims are incomplete or changed')
    if len(current_api_doc.get('commands', [])) != 9 or len(current_api_spec_doc) != 8:
        raise SystemExit('current-API capture must contain eight API commands and one cleanup')
    current_api_pin = compare.pin(current_api_path)
    current_api_spec_pin = compare.pin(CURRENT_API_SPEC)
    current_api_cli_argv0 = current_api_spec_doc[0][0]
    if not Path(current_api_cli_argv0).is_file():
        raise SystemExit('current-API CLI path is missing')
    current_api_cli_pin = compare.pin(Path(current_api_cli_argv0))
    current_api_streams = []
    for api_command in current_api_doc['commands']:
        for stream_name in ('stdout','stderr'):
            stream_pin = api_command['streams'][stream_name]
            expected_stream_path = CURRENT_API / 'raw' / f"{api_command['index']}.{stream_name}.raw"
            if Path(stream_pin['path']) != expected_stream_path or compare.pin(expected_stream_path) != stream_pin:
                raise SystemExit(f"current API raw stream pin mismatch: command {api_command['index']} {stream_name}")
            current_api_streams.append({'command':api_command['index'],'stream':stream_name,'pin':stream_pin})
    current_api_source_map = {Path(row['path']).resolve().relative_to(root).as_posix(): row for row in current_api_doc['source_after']}
    if baseline_doc.get('schema') != EXPECTED_SCHEMA or baseline_doc.get('status') != EXPECTED_STATUS:
        raise SystemExit('Seq1 baseline receipt schema/status differs from the reviewed capture')
    if baseline_review_doc.get('status') != 'read_only_baseline_review_complete':
        raise SystemExit('Seq1 baseline review is not accepted by its independent read-only checker')
    if baseline_review_doc.get('input', {}).get('path') != str(baseline_path):
        raise SystemExit('baseline review is bound to another execution receipt')
    if compare.sha(baseline_path) != baseline_review_doc.get('input', {}).get('sha256'):
        raise SystemExit('baseline receipt SHA differs from its independent review')
    if baseline_doc.get('source_unchanged') is not True or baseline_doc.get('target_absent') is not True:
        raise SystemExit('baseline does not attest unchanged source and absent target')
    if len(baseline_doc.get('commands', [])) != 24:
        raise SystemExit('Seq1 baseline must contain its 24 original/API/extraction commands')
    baseline_commands = {row['index']: row for row in baseline_doc['commands']}
    if len(baseline_commands) != 24:
        raise SystemExit('duplicate baseline command ids')
    for row in baseline_commands.values():
        if row.get('guard_stop') is not None:
            raise SystemExit(f'baseline command {row["index"]} has a guard stop')
        compare.command_artifact(row, 'stdout')
        compare.command_artifact(row, 'stderr')

    baseline_pin = compare.pin(baseline_path)
    review_pin = compare.pin(baseline_review)
    source_pin, driver_pin = baseline_doc['source'], baseline_doc['driver']
    source_path, driver_source_path = Path(source_pin['path']), Path(driver_pin['path'])
    runtime_bound_pin = baseline_doc['runtime_bound']
    runtime_bound = Path(runtime_bound_pin['path'])
    pin_is_current(compare, source_pin, 'original upstream source')
    pin_is_current(compare, driver_pin, 'baseline reflection driver')
    pin_is_current(compare, runtime_bound_pin, 'baseline timeout wrapper')
    source_copy_pin = baseline_doc['source_copy']
    pin_is_current(compare, source_copy_pin, 'baseline full source copy')
    if source_path.read_bytes() != Path(source_copy_pin['path']).read_bytes():
        raise SystemExit('baseline source copy differs from complete upstream source')

    oracle_pin = baseline_doc['original_oracle']
    oracle_path = Path(oracle_pin['path'])
    pin_is_current(compare, oracle_pin, 'original six-case JVM oracle')
    oracle_bytes = oracle_path.read_bytes()
    if len(oracle_bytes.decode('utf-8', errors='strict').splitlines()) != 6:
        raise SystemExit('original observed oracle does not contain six rows')
    runtime_rows = baseline_doc.get('original_runtime', [])
    expected_runtime_keys = {(profile, runtime) for profile in PROFILES for runtime in RUNTIMES}
    if len(runtime_rows) != 4 or {(r.get('profile'), r.get('runtime')) for r in runtime_rows} != expected_runtime_keys:
        raise SystemExit('baseline original oracle does not cover four profile/JVM pairs')
    for item in runtime_rows:
        command_row = baseline_commands.get(item.get('command'))
        if command_row is None or item.get('exit_code') != 0 or command_row.get('exit_code') != 0:
            raise SystemExit('an original target/JVM run did not succeed')
        if compare.command_artifact(command_row, 'stdout') != oracle_bytes:
            raise SystemExit('original JVM rows differ from the actual recorded oracle')
    boundary = baseline_doc.get('javac8_boundary') or {}
    boundary_row = next((r for r in baseline_doc['commands'] if r['label'] == 'original-javac8-harness-boundary'), None)
    if (boundary_row is None or boundary_row.get('exit_code') == 0 or not boundary.get('observed_major_55_diagnostic')
            or b'55.0' not in compare.command_artifact(boundary_row, 'stderr')):
        raise SystemExit('original javac8 major-55 framework boundary is absent or unverified')
    wrong = baseline_doc.get('wrong_root_control') or {}
    wrong_row = baseline_commands.get(wrong.get('command'))
    if wrong_row is None or wrong_row.get('exit_code') == 0 or b'target loaded from' not in compare.command_artifact(wrong_row, 'stderr'):
        raise SystemExit('original wrong-CodeSource-root negative control is absent or did not reject')

    profiles = {row['profile']: row for row in baseline_doc.get('profiles', [])}
    if set(profiles) != set(PROFILES):
        raise SystemExit('baseline lacks debug/no-debug original class profiles')
    original_class_pins = []
    for profile in profiles.values():
        target = profile['target']
        if target.get('major') != 52 or class_method_set(target) != EXPECTED_METHODS:
            raise SystemExit('original target class is not the two-method Java 8 profile')
        for pin in profile['class_files']:
            pin_is_current(compare, pin, 'original compiled class')
            original_class_pins.append(pin)

    dep_ref = baseline_doc['dependency_reference']
    pin_is_current(compare, dep_ref, 'baseline dependency receipt')
    dep_doc = json.loads(Path(dep_ref['path']).read_text(encoding='utf-8'))
    if baseline_doc['classpath'] != dep_doc['classpath'] or baseline_doc['jar_pins'] != dep_doc['jar_pins']:
        raise SystemExit('classpath/dependency pins differ from the bound source receipt')
    classpath_full = list(baseline_doc['classpath'])
    for pin in [baseline_doc['harness_jar'], *baseline_doc['jar_pins']]:
        pin_is_current(compare, pin, 'compile dependency')
    directory_pins = baseline_doc.get('directory_pins', {})
    if not directory_pins:
        raise SystemExit('baseline lacks dependency class-directory pins')
    for folder, expected in directory_pins.items():
        actual = {p.relative_to(folder).as_posix(): compare.pin(p) for p in sorted(Path(folder).rglob('*.class'))}
        if actual != expected:
            raise SystemExit(f'compile dependency class tree changed: {folder}')
    with zipfile.ZipFile(baseline_doc['harness_jar']['path']) as jar:
        if any('TestSequentialLoops' in name for name in jar.namelist()):
            raise SystemExit('compile harness contains the Seq1 target/outer class')
    for folder in directory_pins:
        if (Path(folder) / TARGET_REL).exists() or (Path(folder) / OWNER_REL).exists():
            raise SystemExit(f'compile dependency class tree contains original Seq1 target/outer: {folder}')

    cli_pin, jadx_pin, jadx_jar_pin = baseline_doc['cli'], baseline_doc['jadx'], baseline_doc['jadx_jar']
    for label, pin in (('frozen CLI', cli_pin), ('JADX executable', jadx_pin), ('JADX JAR', jadx_jar_pin)):
        pin_is_current(compare, pin, label)
    source_before = compare.source_closure(root)
    historical_source_matches_current = source_before == baseline_doc['source_pins_before']

    # Bind Jarde compiler inputs to the eight latest raw API reports; keep historical JADX source inputs.
    source_inputs = []
    jarde_cells, jadx_cells = baseline_doc.get('jarde_cells', []), baseline_doc.get('jadx_cells', [])
    expected_jarde = {(p, f, e) for p in PROFILES for f in FORMS['jarde'] for e in EVIDENCE}
    expected_jadx = {(p, f) for p in PROFILES for f in FORMS['jadx']}
    if ({(r.get('profile'), r.get('input_form'), r.get('evidence')) for r in jarde_cells} != expected_jarde
            or len(jarde_cells) != len(expected_jarde)):
        raise SystemExit('baseline Jarde input grid is not the complete 2×2×2 matrix')
    if ({(r.get('profile'), r.get('input_form')) for r in jadx_cells} != expected_jadx
            or len(jadx_cells) != len(expected_jadx)):
        raise SystemExit('baseline JADX extraction grid is not the complete 2×2 matrix')
    base_jarde = {(r['profile'], r['input_form'], r['evidence']): r for r in jarde_cells}
    api_command_rows = current_api_doc['commands'][:8]
    api_keys = set()
    for idx, (spec_argv, api_row) in enumerate(zip(current_api_spec_doc, api_command_rows), start=1):
        if api_row.get('index') != idx or api_row.get('argv') != spec_argv or api_row.get('exit_code') != 0 or api_row.get('guard_stop') is not None:
            raise SystemExit(f'current-API command {idx} differs from its pinned argv or failed')
        if api_row.get('cwd') != str(root):
            raise SystemExit(f'current-API command {idx} ran from an unexpected directory')
        if (type(api_row.get('peak_target_bytes')) is not int or api_row['peak_target_bytes'] > 1024**3
                or type(api_row.get('free_bytes_after')) is not int or api_row['free_bytes_after'] < 5*1024**3
                or any(k in api_row.get('env_overrides', {}) for k in ('RUST_MIN_STACK','CARGO_TARGET_DIR'))):
            raise SystemExit(f'current-API command {idx} resource/default-stack guard facts differ')
        for stream_name in ('stdout', 'stderr'):
            expected_raw = CURRENT_API / 'raw' / f'{idx}.{stream_name}.raw'
            if Path(api_row.get('streams', {}).get(stream_name, {}).get('path', '')) != expected_raw:
                raise SystemExit(f'current-API command {idx} has an unexpected {stream_name} path')
        raw_stdout = compare.command_artifact(api_row, 'stdout')
        compare.command_artifact(api_row, 'stderr')
        doc = json.loads(raw_stdout.decode('utf-8', errors='strict'))
        argv = api_row['argv']
        if not argv or argv[0] != current_api_cli_argv0 or len(argv) < 2 or argv[1] != 'class-source':
            raise SystemExit(f'current-API command {idx} is not from the pinned CLI')
        evidence = 'all' if '--evidence' in argv and argv[argv.index('--evidence') + 1] == 'all' else 'default'
        if (argv[argv.index('--class') + 1] != INTERNAL_CLASS or argv[argv.index('--release') + 1] != '8'
                or argv[argv.index('--format') + 1] != 'json' or ('--evidence' in argv) != (evidence == 'all')):
            raise SystemExit(f'current-API command {idx} has unexpected class/release/format/evidence arguments')
        input_path = Path(argv[argv.index('--input') + 1]).resolve(strict=True)
        policy = argv[argv.index('--policy') + 1]
        form = {'single-class': 'child', 'plain-jar': 'bundle-child'}.get(policy)
        profile = 'debug' if '/debug/' in input_path.as_posix() or input_path.name == 'debug.jar' else 'no-debug'
        key = (profile, form, evidence)
        if form is None or key not in expected_jarde or key in api_keys:
            raise SystemExit(f'current-API command {idx} has a duplicate/unknown profile-form-evidence selector {key}')
        api_keys.add(key)
        base = base_jarde[key]
        input_pin = compare.pin(input_path)
        if input_pin != base['input']:
            raise SystemExit(f'{key}: current API input differs from frozen original class/archive input')
        if doc.get('outcome') != 'performed' or doc.get('declaration', {}).get('name') != 'TestSequentialLoops$TestCls':
            raise SystemExit(f'{key}: API class was not presented as the expected physical target')
        expected_location = 'standalone_root' if form == 'child' else 'archive_entry'
        if doc.get('class', {}).get('location', {}).get('kind') != expected_location:
            raise SystemExit(f'{key}: API class location kind does not match the selected class/archive input')
        decl = doc.get('declaration', {}).get('item', {}).get('declaration', {}).get('this_class', {})
        if decl.get('escaped') != INTERNAL_CLASS:
            raise SystemExit(f'{key}: API report class identity differs from the original input')
        methods = doc.get('methods') or []
        method_ids = {(m.get('item', {}).get('name', {}).get('escaped'), m.get('item', {}).get('descriptor', {}).get('escaped')) for m in methods}
        if method_ids != EXPECTED_METHODS or len(methods) != 2:
            raise SystemExit(f'{key}: API report method identity inventory differs from the frozen class')
        if any(m.get('outcome', {}).get('kind') != 'recovered' or m.get('outcome', {}).get('analysis', {}).get('diagnostics') != 0 for m in methods):
            raise SystemExit(f'{key}: API method outcome is not complete structured recovery')
        text = doc.get('text')
        if not isinstance(text, str) or not text:
            raise SystemExit(f'{key}: API report has no whole-class text')
        source_inputs.append({'kind': 'jarde', 'profile': profile, 'form': form, 'evidence': evidence,
                              'input_pin': input_pin, 'original_source': None,
                              'original_report': api_row['streams']['stdout'],
                              'current_api_command': idx, 'current_api_report': api_row['streams']['stdout'],
                              'source_path': None, 'source_bytes': text.encode('utf-8'),
                              'api_outcome': doc.get('outcome'), 'api_method_ids': sorted([list(x) for x in method_ids])})
    if api_keys != expected_jarde:
        raise SystemExit('current API commands do not cover exactly the 8 debug/no-debug × child/bundle × default/all cells')
    clean_row = current_api_doc['commands'][8]
    if clean_row.get('exit_code') != 0 or clean_row.get('guard_stop') is not None or clean_row.get('cleanup_only') is not True or clean_row.get('argv') != ['cargo','clean']:
        raise SystemExit('current-API cleanup command is absent or failed')
    compare.command_artifact(clean_row, 'stdout'); compare.command_artifact(clean_row, 'stderr')
    for row in jadx_cells:
        if row.get('exit_code') != 0 or len(row.get('sources') or []) != 1:
            raise SystemExit('a JADX baseline cell lacks exactly one emitted Java source')
        source_file = Path(row['sources'][0]['path'])
        pin_is_current(compare, row['sources'][0], 'baseline JADX source')
        command_row = baseline_commands.get(row.get('command'))
        if command_row is None:
            raise SystemExit('JADX cell references an unknown original command')
        input_path = Path(command_row['argv'][-1])
        input_pin = compare.pin(input_path)
        source_inputs.append({'kind': 'jadx', 'profile': row['profile'], 'form': row['input_form'],
                              'evidence': 'source', 'input_pin': input_pin,
                              'original_source': row['sources'][0], 'original_report': None,
                              'source_path': source_file, 'source_bytes': None})
    if len(source_inputs) != 12:
        raise SystemExit('expected 12 complete current Jarde + historical JADX source artifacts')

    out.mkdir(parents=True)
    raw = out / 'raw'
    raw.mkdir()
    guard.ROOT, guard.OUT = root, raw
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda _index, _stdout: None
    runtime_bound_copy = out / runtime_bound.name
    shutil.copy2(runtime_bound, runtime_bound_copy)
    runtime_bound_copy_pin = compare.pin(runtime_bound_copy)
    if runtime_bound_copy.read_bytes() != runtime_bound.read_bytes():
        raise RuntimeError('private timeout-wrapper copy differs from baseline bytes')
    driver_copy = out / 'driver-source/TestSequentialLoopsDriver.java'
    driver_copy.parent.mkdir(parents=True)
    shutil.copy2(driver_source_path, driver_copy)
    if driver_copy.read_bytes() != driver_source_path.read_bytes():
        raise RuntimeError('private matrix driver copy differs from baseline driver bytes')
    driver_copy_pin = compare.pin(driver_copy)
    driver_empty = out / 'empty-sourcepath-driver'
    driver_empty.mkdir()
    driver_classes = out / 'driver-classes'
    driver_classes.mkdir()
    for item in source_inputs:
        path = out / 'input-sources' / item['kind'] / item['profile'] / item['form'] / str(item['evidence']) / 'jadx/tests/integration/loops' / expected_source_name(item['kind'], item['form'])
        path.parent.mkdir(parents=True, exist_ok=True)
        source_bytes = item.get('source_bytes')
        path.write_bytes(source_bytes if source_bytes is not None else item['source_path'].read_bytes())
        item['source_copy'] = compare.pin(path)
        item['source_filename'] = path.name
        item['compile_source'] = path

    rows = []
    report = {
        'schema': 'cf11-testsequentialloops-current-api-full-source-rebuild-matrix-v1', 'status': 'running',
        'root': str(root), 'baseline_receipt': baseline_pin, 'baseline_review': review_pin,
        'current_api_receipt': current_api_pin, 'current_api_spec': current_api_spec_pin,
        'current_api_runner': current_api_doc['runner'], 'current_api_cli': current_api_cli_pin,
        'current_api_streams': current_api_streams,
        'baseline_review_input_sha256': baseline_review_doc['input']['sha256'],
        'baseline_source_closure_matches_current': historical_source_matches_current,
        'current_api_source_closure_matches_current': source_before == current_api_source_map,
        'baseline_original_oracle': oracle_pin, 'original_oracle_sha256': hashlib.sha256(oracle_bytes).hexdigest(),
        'original_runtime': runtime_rows, 'original_javac8_framework_boundary': {
            'command': boundary_row['index'], 'exit_code': boundary_row['exit_code'],
            'major_55_observed': True, 'stdout': boundary_row['streams']['stdout'], 'stderr': boundary_row['streams']['stderr']},
        'historical_baseline_cli': cli_pin, 'jadx': jadx_pin, 'jadx_jar': jadx_jar_pin,
        'upstream_source': source_pin, 'baseline_driver': driver_pin,
        'runtime_timeout_wrapper': runtime_bound_pin, 'jdk_manifest': jdk_record,
        'source_pins': helper_pins, 'dependency_reference': dep_ref, 'dependency_reference_after': None,
        'classpath_full_compile': classpath_full,
        'runtime_classpath_policy': 'rebuilt target/owner output root plus independent reflection driver only',
        'source_before': source_before, 'original_class_pins': original_class_pins,
        'source_inputs': [{k: item.get(k) for k in ('kind','profile','form','evidence','input_pin','original_source','original_report','current_api_command','current_api_report','source_copy','source_filename','api_outcome','api_method_ids')}
                          for item in source_inputs],
        'source_inputs_after': None, 'commands': rows, 'driver_compile': None, 'driver_copy_pin': driver_copy_pin, 'timeout_wrapper_copy_pin': runtime_bound_copy_pin,
        'compilation_cells': [], 'runtime_rows': [], 'wrong_root_controls': [],
        'notes': [
            'Eight whole-class Jarde texts are copied byte-for-byte from the current API raw stdout JSON, and four historical full JADX Java sources are copied byte-for-byte; no Java source is edited or method removed.',
            'Every one of the 8 latest current-API Jarde texts and 4 historical complete JADX sources is copied byte-for-byte and attempted with javac8 source/target 8 and JDK23 --release 8, for 24 compile attempts.',
            'Compile errors, missing/invalid targets, runtime failures, and oracle mismatches are distinct outcomes; failed compiles never receive runtime rows.',
            'The full pinned harness/dependency classpath is used only for compilation. Every generated-target JVM run uses only its rebuilt class output root plus the independent driver.',
            'The original javac8 major-55 harness boundary is separately bound from the reviewed baseline; generated bundle compiler errors are classified from their own raw logs.',
            'No generated output is repaired. This matrix does not re-run Jarde/JADX or make an SSA claim; Jarde text is pinned to the eight structured/no-fallback current API raw reports.',
            'The baseline CLI and its source closure are historical evidence; current source closure is frozen and compared only with this matrix end state.',
        ],
    }

    def save():
        compare.write_json(out / 'execution.json', report)

    def run_cmd(label: str, argv: list, leg: str) -> dict:
        if (root / 'target').exists():
            raise RuntimeError('repository target appeared before external command')
        env = {key: value for key, value in os.environ.items() if key not in ENV_STRIP}
        env = compare.clean_env(env, jdks[leg])
        env.update(guard.ENV_VALUES)
        env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(rows) + 1, [str(arg) for arg in argv], env)
        row['label'], row['tool_leg'] = label, leg
        rows.append(row)
        save()
        if row.get('guard_stop') is not None:
            raise RuntimeError(f'root command guard stopped {label}: {row["guard_stop"]}')
        return row

    def tree(root_dir: Path) -> dict:
        return file_tree_pin(root_dir, compare)

    def run_target(label: str, classes: Path, runtime: str) -> dict:
        before_target, before_driver = tree(classes), tree(driver_classes)
        if before_driver != report['driver_compile']['classes_tree']:
            raise RuntimeError('independent driver class tree changed before runtime')
        if before_target != current_cell['target_classes_tree']:
            raise RuntimeError('generated target class tree changed before runtime')
        cp = [str(classes), str(driver_classes)]
        row = run_cmd(label, [sys.executable, '-B', runtime_bound_copy, '30', jdks[runtime]['tools']['java'],
                              '-Xverify:all', '-cp', os.pathsep.join(cp), 'TestSequentialLoopsDriver', classes], runtime)
        after_target, after_driver = tree(classes), tree(driver_classes)
        row['matrix_classpath'] = cp
        row['expected_target_root'] = str(classes)
        row['target_class_tree_before'], row['target_class_tree_after'] = before_target, after_target
        row['driver_class_tree_before'], row['driver_class_tree_after'] = before_driver, after_driver
        if after_target != before_target or after_driver != before_driver:
            raise RuntimeError(f'runtime modified an input class tree: {label}')
        return row

    try:
        driver_compile = run_cmd('compile-independent-driver-javac8', [
            jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g:none', '-Xlint:-options',
            '-encoding', 'UTF-8', '-proc:none', '-classpath', driver_empty, '-sourcepath', driver_empty,
            '-d', driver_classes, driver_copy,
        ], 'javac8')
        driver_files = sorted(driver_classes.rglob('*.class'))
        report['driver_compile'] = {'command': driver_compile['index'], 'exit_code': driver_compile['exit_code'],
                                    'source': compare.pin(driver_copy),
                                    'classes': [compare.pin(path) for path in driver_files]}
        if driver_compile['exit_code'] != 0 or len(driver_files) != 1:
            raise RuntimeError('independent reflection driver did not compile to exactly one class')
        report['driver_compile']['classes_tree'] = tree(driver_classes)
        save()

        compile_cells = []
        wrong_root_done = False
        oracle_sha = hashlib.sha256(oracle_bytes).hexdigest()
        for item in source_inputs:
            for compiler in JDK_LEGS:
                classes = out / 'compiled' / item['kind'] / item['profile'] / item['form'] / str(item['evidence']) / compiler / 'classes'
                classes.mkdir(parents=True)
                empty = classes.parent / 'empty-sourcepath'
                empty.mkdir()
                options = (['-source', '8', '-target', '8', '-g:none', '-Xlint:-options', '-proc:none']
                           if compiler == 'javac8' else ['--release', '8', '-g:none', '-proc:none'])
                label = f'compile-{item["kind"]}-{item["profile"]}-{item["form"]}-{item["evidence"]}-{compiler}'
                compile_cp = os.pathsep.join(classpath_full)
                compiled = run_cmd(label, [jdks[compiler]['tools']['javac'], *options, '-encoding', 'UTF-8',
                                           '-classpath', compile_cp, '-sourcepath', empty, '-d', classes,
                                           item['compile_source']], compiler)
                target_path = classes / TARGET_REL
                cell = {'kind': item['kind'], 'profile': item['profile'], 'form': item['form'],
                        'evidence': item['evidence'], 'compiler': compiler, 'source': item['source_copy'],
                        'original_source': item['original_source'], 'original_report': item['original_report'],
                        'source_filename': item['source_filename'], 'compile_classpath': classpath_full,
                        'compile_command': compiled['index'], 'compile_exit_code': compiled['exit_code'],
                        'target_class_expected': str(target_path), 'target_class': None, 'target_facts': None,
                        'owner_class': None, 'runtime': []}
                if compiled['exit_code'] != 0:
                    stderr = compare.command_artifact(compiled, 'stderr')
                    cell['status'] = ('compile_failed_javac8_major55_no_runtime'
                                      if compiler == 'javac8' and (b'55.0' in stderr or b'version 55' in stderr)
                                      else 'compile_failed_no_runtime')
                    cell['stderr_sha256'] = hashlib.sha256(stderr).hexdigest()
                elif not target_path.is_file():
                    cell['status'] = 'compile_succeeded_target_missing_no_runtime'
                else:
                    cell['target_class'] = compare.pin(target_path)
                    cell['target_classes_root'] = str(classes)
                    cell['target_classes_tree'] = tree(classes)
                    owner_path = classes / OWNER_REL
                    cell['owner_class'] = compare.pin(owner_path) if owner_path.is_file() else None
                    try:
                        facts = compare.parse_class(target_path)
                        cell['target_facts'] = facts
                        cell['declared_methods_match_expected'] = facts['class_name'] == INTERNAL_CLASS and class_method_set(facts) == EXPECTED_METHODS
                        cell['all_methods_have_code'] = all(method.get('code') is not None for method in facts['methods'])
                        cell['classfile_major_is_java8'] = facts['major'] == 52
                        if (cell['declared_methods_match_expected'] and cell['all_methods_have_code']
                                and cell['classfile_major_is_java8']):
                            cell['status'] = 'compiled_target_java8_two_methods'
                            current_cell = cell
                            if not wrong_root_done:
                                wrong = out / 'empty-wrong-root'
                                wrong.mkdir()
                                wrong_run = run_cmd('matrix-wrong-root-code-source-rejection', [
                                    sys.executable, '-B', runtime_bound_copy, '30', jdks['javac23']['tools']['java'],
                                    '-Xverify:all', '-cp', os.pathsep.join([str(classes), str(driver_classes)]),
                                    'TestSequentialLoopsDriver', wrong,
                                ], 'javac23')
                                wrong_stderr = compare.command_artifact(wrong_run, 'stderr')
                                wrong_ok = wrong_run['exit_code'] != 0 and b'target loaded from' in wrong_stderr
                                report['wrong_root_controls'].append({'command': wrong_run['index'],
                                    'exit_code': wrong_run['exit_code'], 'expected_root': str(wrong),
                                    'stderr_sha256': hashlib.sha256(wrong_stderr).hexdigest(), 'rejected': wrong_ok})
                                if not wrong_ok:
                                    raise RuntimeError('matrix wrong-root CodeSource control did not reject')
                                wrong_root_done = True
                            for runtime in RUNTIMES:
                                run = run_target(f'runtime-{item["kind"]}-{item["profile"]}-{item["form"]}-{item["evidence"]}-{compiler}-on-{runtime}', classes, runtime)
                                stdout = compare.command_artifact(run, 'stdout')
                                stderr = compare.command_artifact(run, 'stderr')
                                same = run['exit_code'] == 0 and stdout == oracle_bytes
                                runtime_cell = {'runtime': runtime, 'command': run['index'],
                                    'exit_code': run['exit_code'], 'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
                                    'stderr_sha256': hashlib.sha256(stderr).hexdigest(),
                                    'oracle_equal_byte_for_byte': same,
                                    'status': 'matches_original_jvm_oracle' if same else ('runtime_failed' if run['exit_code'] != 0 else 'runtime_oracle_mismatch'),
                                    'classpath': run['matrix_classpath'], 'stdout_bytes': len(stdout)}
                                cell['runtime'].append(runtime_cell)
                                report['runtime_rows'].append({**{k: cell[k] for k in ('kind','profile','form','evidence','compiler')}, **runtime_cell})
                                save()
                    except (ValueError, IndexError, KeyError) as parse_error:
                        cell['status'] = 'compiled_target_classfile_invalid_no_runtime'
                        cell['target_parse_error'] = str(parse_error)
                    else:
                        if cell['status'] != 'compiled_target_java8_two_methods':
                            cell['status'] = 'compiled_target_identity_or_major_mismatch_no_runtime'
                compile_cells.append(cell)
                report['compilation_cells'] = compile_cells
                save()

        # Recheck all baseline/source/tool inputs after every compile/runtime attempt.
        after_sources = []
        for item in source_inputs:
            for role, pin in (('source_copy', item['source_copy']), ('original_source', item['original_source']),
                              ('original_report', item['original_report']), ('current_api_report', item.get('current_api_report')),
                              ('input_class_or_archive', item['input_pin'])):
                if pin:
                    pin_is_current(compare, pin, role)
                    after_sources.append({'selector': [item['kind'], item['profile'], item['form'], item['evidence']],
                                          'role': role, 'pin': pin})
        report['source_inputs_after'] = after_sources
        report['source_after'] = compare.source_closure(root)
        report['baseline_receipt_after'] = compare.pin(baseline_path)
        report['dependency_reference_after'] = compare.pin(Path(dep_ref['path']))
        report['baseline_review_after'] = compare.pin(baseline_review)
        report['current_api_receipt_after'] = compare.pin(current_api_path)
        report['current_api_spec_after'] = compare.pin(CURRENT_API_SPEC)
        report['current_api_cli_after'] = compare.pin(Path(current_api_cli_argv0))
        report['current_api_runner_after'] = compare.pin(runner_path)
        report['current_api_streams_after'] = []
        for api_command in current_api_doc['commands']:
            for stream_name in ('stdout','stderr'):
                stream_pin = api_command['streams'][stream_name]
                actual_stream_pin = compare.pin(Path(stream_pin['path']))
                report['current_api_streams_after'].append({'command':api_command['index'],'stream':stream_name,'pin':actual_stream_pin})
        report['driver_source_after'] = compare.pin(driver_copy)
        report['driver_classes_tree_after'] = tree(driver_classes)
        report['timeout_wrapper_after'] = compare.pin(runtime_bound_copy)
        report['original_classes_after'] = [compare.pin(Path(pin['path'])) for pin in original_class_pins]
        report['helper_pins_after'] = {'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path),
                                       'scanner': compare.pin(scanner_path), 'jdk_manifest': compare.pin(jdk_manifest_path)}
        report['dependencies_after'] = {'harness': compare.pin(Path(baseline_doc['harness_jar']['path'])),
            'jars': [compare.pin(Path(pin['path'])) for pin in baseline_doc['jar_pins']],
            'classes': {folder: {p.relative_to(folder).as_posix(): compare.pin(p)
                                 for p in sorted(Path(folder).rglob('*.class'))} for folder in directory_pins}}
        if report['source_after'] != source_before or report['baseline_receipt_after'] != baseline_pin:
            raise RuntimeError('current shared source or historical baseline receipt changed during matrix')
        if report['dependency_reference_after'] != dep_ref:
            raise RuntimeError('baseline dependency reference changed during matrix')
        if (report['current_api_receipt_after'] != current_api_pin or report['current_api_spec_after'] != current_api_spec_pin
                or report['current_api_cli_after'] != current_api_cli_pin or report['current_api_runner_after'] != current_api_doc['runner']
                or report['current_api_streams_after'] != current_api_streams):
            raise RuntimeError('current API receipt/spec/CLI changed during matrix')
        if report['baseline_review_after'] != review_pin or report['driver_source_after'] != driver_copy_pin:
            raise RuntimeError('baseline review or copied independent driver changed during matrix')
        if report['timeout_wrapper_after'] != runtime_bound_copy_pin:
            raise RuntimeError('copied timeout wrapper changed during matrix')
        if report['helper_pins_after'] != helper_pins:
            raise RuntimeError('matrix helper/JDK pins changed during collection')
        if report['original_classes_after'] != original_class_pins:
            raise RuntimeError('original class profiles changed during matrix')
        if (root / 'target').exists():
            raise RuntimeError('workspace target appeared by end of matrix')
        report['source_unchanged'] = True
        report['baseline_unchanged'] = True
        report['target_absent'] = True
        report['status'] = 'captured-pending-independent-review'
    except BaseException as error:
        report['status'] = 'failed'
        report['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out / 'execution.json', report)
        shutil.copy2(__file__, out / 'collector.py')
        print(json.dumps({'status': report['status'], 'compile_cells': len(report['compilation_cells']),
                          'runtime_rows': len(report['runtime_rows']), 'output': str(out)}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
