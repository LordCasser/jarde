#!/usr/bin/env python3
"""Minimal independent classfile decoder and workspace source pin helper."""
from __future__ import annotations
import hashlib
import os
from pathlib import Path

def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def file_pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def decode_bcis(code: bytes) -> list[int]:
    fixed = {0x10: 2, 0x11: 3, 0x12: 2, 0x13: 3, 0x14: 3, 0x15: 2, 0x16: 2, 0x17: 2,
             0x18: 2, 0x19: 2, 0x36: 2, 0x37: 2, 0x38: 2, 0x39: 2, 0x3a: 2, 0x84: 3,
             0xa9: 2, 0xbc: 2, 0xc5: 4, 0xb2: 3, 0xb3: 3, 0xb4: 3, 0xb5: 3, 0xb6: 3,
             0xb7: 3, 0xb8: 3, 0xbb: 3, 0xbd: 3, 0xc0: 3, 0xc1: 3, 0xb9: 5, 0xba: 5,
             0xc8: 5, 0xc9: 5}
    fixed.update({op: 3 for op in range(0x99, 0xa9)})
    fixed.update({0xc6: 3, 0xc7: 3})
    bcis, pc = [], 0
    while pc < len(code):
        bcis.append(pc)
        op = code[pc]
        if op == 0xaa:
            aligned = (pc + 4) & ~3
            if aligned + 12 > len(code):
                raise ValueError(f'truncated tableswitch at {pc}')
            low = int.from_bytes(code[aligned + 4:aligned + 8], 'big', signed=True)
            high = int.from_bytes(code[aligned + 8:aligned + 12], 'big', signed=True)
            if high < low:
                raise ValueError(f'invalid tableswitch at {pc}')
            size = aligned - pc + 12 + 4 * (high - low + 1)
        elif op == 0xab:
            aligned = (pc + 4) & ~3
            if aligned + 8 > len(code):
                raise ValueError(f'truncated lookupswitch at {pc}')
            pairs = int.from_bytes(code[aligned + 4:aligned + 8], 'big', signed=True)
            if pairs < 0:
                raise ValueError(f'invalid lookupswitch at {pc}')
            size = aligned - pc + 8 + 8 * pairs
        elif op == 0xc4:
            if pc + 1 >= len(code):
                raise ValueError(f'truncated wide at {pc}')
            size = 6 if code[pc + 1] == 0x84 else 4
        else:
            size = fixed.get(op, 1)
        if pc + size > len(code):
            raise ValueError(f'instruction overruns Code at {pc}')
        pc += size
    return bcis

def parse_class_file(data: bytes) -> dict:
    """Small independent class-header/Code reader used to bind BCI facts to class bytes."""
    pos = 0

    def take(size: int) -> bytes:
        nonlocal pos
        value = data[pos:pos + size]
        if len(value) != size:
            raise ValueError('truncated class file')
        pos += size
        return value

    def u1() -> int:
        return take(1)[0]

    def u2() -> int:
        return int.from_bytes(take(2), 'big')

    def u4() -> int:
        return int.from_bytes(take(4), 'big')

    need(u4() == 0xCAFEBABE, 'bad classfile magic')
    minor, major = u2(), u2()
    cp_count = u2()
    cp = [None] * cp_count
    i = 1
    while i < cp_count:
        tag = u1()
        if tag == 1:
            cp[i] = ('utf8', take(u2()).decode('utf-8', errors='strict'))
        elif tag in (3, 4):
            take(4)
        elif tag in (5, 6):
            take(8)
            i += 1
        elif tag in (7, 8, 16, 19, 20):
            cp[i] = (tag, u2())
        elif tag in (9, 10, 11, 12, 17, 18):
            cp[i] = (tag, u2(), u2())
        elif tag == 15:
            take(3)
        else:
            raise ValueError(f'unknown constant-pool tag {tag}')
        i += 1

    def utf(index: int) -> str:
        entry = cp[index]
        need(entry is not None and entry[0] == 'utf8', f'bad UTF8 constant pool index {index}')
        return entry[1]

    def skip_attributes() -> list[tuple[str, bytes]]:
        attrs = []
        for _ in range(u2()):
            name, size = utf(u2()), u4()
            attrs.append((name, take(size)))
        return attrs

    access, this_class = u2(), u2()
    u2()  # super_class
    class_name = utf(cp[this_class][1])
    for _ in range(u2()):
        u2()
    for _ in range(u2()):
        u2(); u2(); u2(); skip_attributes()
    methods = []
    for index in range(u2()):
        flags, name, descriptor = u2(), utf(u2()), utf(u2())
        attrs = skip_attributes()
        code = None
        for attr_name, blob in attrs:
            if attr_name != 'Code':
                continue
            cursor = 0

            def read2() -> int:
                nonlocal cursor
                value = int.from_bytes(blob[cursor:cursor + 2], 'big')
                if len(blob[cursor:cursor + 2]) != 2:
                    raise ValueError('truncated Code attribute')
                cursor += 2
                return value

            def read4() -> int:
                nonlocal cursor
                chunk = blob[cursor:cursor + 4]
                if len(chunk) != 4:
                    raise ValueError('truncated Code attribute')
                cursor += 4
                return int.from_bytes(chunk, 'big')

            max_stack, max_locals, length = read2(), read2(), read4()
            code_bytes = blob[cursor:cursor + length]
            need(len(code_bytes) == length, 'truncated method Code bytes')
            cursor += length
            rows = []
            for _ in range(read2()):
                rows.append([read2(), read2(), read2(), read2()])
            for _ in range(read2()):
                read2(); size = read4(); cursor += size
                need(cursor <= len(blob), 'truncated nested Code attribute')
            need(cursor == len(blob), 'trailing Code attribute bytes')
            code = {'max_stack': max_stack, 'max_locals': max_locals, 'code_length': length,
                    'code_hex': code_bytes.hex(), 'rows': rows, 'bcis': decode_bcis(code_bytes)}
        methods.append({'index': index, 'name': name, 'descriptor': descriptor, 'access': flags, 'code': code})
    skip_attributes()
    need(pos == len(data), 'trailing classfile bytes')
    return {'minor': minor, 'major': major, 'access': access, 'class_name': class_name, 'methods': methods}

def source_closure(root: Path) -> dict[str, dict]:
    candidates = [root / 'Cargo.toml', root / 'Cargo.lock']
    for name in ('src', 'crates', 'tests', 'openspec/changes/recover-exception-only-finally-completion'):
        directory = root / name
        if directory.exists():
            for current, dirs, files in os.walk(directory):
                dirs[:] = sorted(d for d in dirs if d not in {'.git', 'target', '__pycache__'})
                for filename in sorted(files):
                    path = Path(current) / filename
                    if path.is_file() and not path.is_symlink():
                        candidates.append(path)
    result = {}
    for path in sorted(set(candidates)):
        if path.is_file() and not path.is_symlink():
            result[path.relative_to(root).as_posix()] = file_pin(path)
    return result
