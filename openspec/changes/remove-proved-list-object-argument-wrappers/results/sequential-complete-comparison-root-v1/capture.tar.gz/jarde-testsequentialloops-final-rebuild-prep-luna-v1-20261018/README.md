# TestSequentialLoops full-source rebuild preparation

This private bundle reuses the already reviewed full-source rebuild/runtime matrix mechanism for the frozen `TestSequentialLoops$TestCls`. Preparation only: no JDK, JADX, Jarde CLI, Cargo, network, or shared-workspace command was run in this task.

Inputs are fixed to:

- Original baseline receipt: `/private/tmp/jarde-testsequentialloops-baseline-run-root-v1-20261018/execution.json` (SHA256 `615f5f0e7f7734be42cc190592e75315a4091da4715087cf89bc7adffc044911`), independently reviewed at `/private/tmp/jarde-testsequentialloops-baseline-review-root-v1-20261018/root-review.json`.
- Latest structured 8-cell API receipt: `/private/tmp/jarde-cf11-sequential-current-api-root-v2-20261018/execution.json` (SHA256 `da6c0519ed07edd37117ae3807911fd2827135047a127b5794a194df0ac9e674`), its fixed command spec, runner, raw streams, and CLI SHA256 `56a589ef9a170a1bb2911ed5597c20b2b4e06abf78da845f8fd3946099b2fa51`.
- The original complete Java source and reflection driver are pinned by the baseline. The original runtime oracle is six observed output lines shared by four original debug/no-debug × Java 8/23 runs.

The collector compiles 12 whole source inputs (eight exact Jarde API report texts and four exact saved JADX source files) with both Java 8 javac and JDK 23 `--release 8`: 24 compile cells. A produced target is run on both JVMs only when it parses as Java 8 major 52 and has the expected two physical methods with Code. Each eligible runtime uses `-Xverify:all`, target output root plus the independently compiled driver, and validates the loaded class CodeSource. A wrong-root rejection control is required. The 6-row observed oracle is compared byte-for-byte; compile/runtime failures and mismatches stay failures. The original Java 8 compilation boundary for the outer JUnit source is preserved as historical evidence: javac 8 rejected the major-55 `IntegrationTest` harness class. It is not counted as a generated target compile or runtime result.

Entrypoints after root review:

```sh
python3 -B collect_current_api_rebuild.py --out /private/tmp/<fresh-output>
python3 -B review_current_api_rebuild.py /private/tmp/<fresh-output>/execution.json /private/tmp/<fresh-review.json>
```

The independent reviewer reconstructs selectors from raw API argv/JSON, verifies all copied source bytes and classfile identities, pins all raw inputs/tools/dependencies, checks the 5 GiB free-space and 1 GiB target guards, default stack, cleanup/target absence, baseline oracle/boundary, and preserves each actual failure category. No generated-matrix execution or acceptance is claimed here.
