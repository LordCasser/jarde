# Static checks only

- Frozen baseline receipt SHA-256: `352a1efd10cd31727e07b6ab333ffe4a93e84aece4f0c4e9203f730558c75ff4`.
- Imported the v2 baseline helper without invoking its main; its `parse_driver` accepted each of the 8 stored original VM stdout artifacts and matched the recorded row list and per-target subsets (64 lines total).
- Derived 40 inventory-matching generated target trees from the receipt. Every class tree path set matched its directory, all class pins verified, and all generated Java source/copy byte pairs matched.
- Verified all 3,838 recursive path/bytes/SHA pins found in the receipt, and confirmed the live source closure matched the pinned post-baseline closure.
- Parsed this runner with Python `ast.parse`.
- No generated target JVM run, javac, JADX, CLI, Cargo, network, Git, or repository write was performed.
