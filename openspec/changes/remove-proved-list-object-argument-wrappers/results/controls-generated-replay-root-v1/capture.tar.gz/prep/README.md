# Mixed-root generated runtime replay (prepared, not executed)

This private runner consumes the completed v3 baseline receipt at `/private/tmp/jarde-object-argument-controls-baseline-root-v3-20261018/capture/execution.json` (SHA-256 `352a1efd10cd31727e07b6ab333ffe4a93e84aece4f0c4e9203f730558c75ff4`). It does not invoke javac, JADX, the Jarde CLI, Cargo, or a network service. It reuses the receipt's separately compiled parentless driver, runtime timeout wrapper, JDK manifest, same-profile original target roots, and byte-pinned successful generated class/source trees.

For each generated compile row whose exit succeeded and whose complete class/member inventory matched the original target, the runner substitutes that one rebuilt target root into the matching profile's three-root tuple. The other two target roots remain that profile's original compilations. The driver receives actual and expected CodeSource roots independently for all three targets and is launched with only its driver class root on the application classpath. Each tree gets two VM runs. It compares only the rebuilt target's exact 3/2/3 case subset against the matching profile/VM original rows; all eight output rows remain recorded, with the six/five companion rows explicitly marked as not counted for the rebuilt target. Each tree also gets one wrong-root invocation that mismatches only its rebuilt target.

The selected baseline rows preserve producer/profile/evidence/compiler distinctions. Jarde default/all cells are not collapsed if they emit duplicate bytes. Complete class trees and exact generated-source copies are re-pinned before replay. The receipt itself is recursively re-pinned, including the original matrix, API/JADX output, source closure, raw command streams, and class facts. Every replay command records argv, environment, raw stdout/stderr, exit, disk guards, and default `RUST_MIN_STACK` state. The script requires the original source closure unchanged, at least 5 GiB free, a 1 GiB repository target ceiling, and no live repository `target` before or after replay.

The target-class success set is derived from the baseline receipt, not hardcoded. The current pinned receipt reports 40 inventory-matching generated target trees (16 Jarde RemovalCases and 24 JADX trees across all three targets); this is preparation context, not a runtime result. A generated Java class does not count as a runtime pass until its target subset matches the actual oracle. Any failed/mismatched rows remain in `failed_cells`; the final status is pending independent review, not product acceptance.

Invocation after root review:

```sh
python3 -B replay_generated.py \
  --baseline-execution /private/tmp/jarde-object-argument-controls-baseline-root-v3-20261018/capture/execution.json \
  --out /private/tmp/jarde-object-argument-controls-generated-replay-root-v1-20261018/capture
```

Python-only static checks performed: the v2 baseline driver's parser accepted all eight stored original stdout receipts (64 total raw case rows); each of the 40 selected class trees, every class pin, and each generated-source source/copy byte pair was verified; all 3,838 recursively referenced receipt pins were verified; the live repository source closure matched the receipt's pinned closure. `ast.parse` succeeded. No generated target was executed by these checks.
