from pathlib import Path
import json,hashlib,collections
BASE=Path('/private/tmp/jarde-object-argument-controls-generated-replay-root-v1-20261018/capture');x=json.loads((BASE/'execution.json').read_text());b=json.loads(Path(x['baseline_receipt']['path']).read_text())
def ck(p):
 raw=Path(p['path']).read_bytes();assert len(raw)==p['bytes'] and hashlib.sha256(raw).hexdigest()==p['sha256'],p['path']
assert x['status']=='captured-pending-independent-review' and not x['failed_cells']
assert x['source_pins_before']==x['source_pins_after']==x['source_pins_after_finally']
for group in (x['source_pins_after_finally'].values(),x['baseline_referenced_artifact_pins'],x['external_pins_after_finally'],x['protected_products_after_finally'].values()):
 for p in group:ck(p)
assert x['external_pins_before']==x['external_pins_after_finally'] and x['protected_products_before_final']==x['protected_products_after_finally']
assert x['target_absent_finally'] and not Path('target').exists()
assert len(x['commands'])==120 and len(x['runtime_cells'])==80 and len(x['wrong_root_cells'])==40
commands={r['index']:r for r in x['commands']};targets=('RemovalCases','EqualityCases','ExplicitCastCases')
for r in commands.values():
 assert r['guard_stop'] is None and r['peak_target_bytes']==0 and r['free_bytes_after']>=5*1024**3 and r['default_stack']
 for p in r['streams'].values():ck(p)
selected={(r['producer'],r['target'],r['profile'],r['evidence'],r['compiler']):r for r in b['generated_compiles'] if r['exit_code']==0}
original={(r['target'],r['profile']):r['class_root'] for r in b['source_profiles']}
oracles={(r['profile'],r['vm']):r['rows'] for r in b['original_runs']}
assert len(selected)==40 and len(x['selected_trees'])==40
counts=collections.Counter();cases=collections.Counter()
for r in x['runtime_cells']:
 key=tuple(r[k] for k in ('producer','target','profile','evidence','compiler'));src=selected[key];c=commands[r['command']]
 assert c['exit_code']==0 and r['matches_target_original'] and not r['parse_error']
 rows=Path(c['streams']['stdout']['path']).read_text().splitlines();assert rows==r['all_driver_rows']==oracles[(r['profile'],r['vm'])]
 rebuilt=[s for s in rows if s.startswith('CASE class=controls.'+r['target']+' ')]
 assert rebuilt==r['target_case_rows_observed'] and len(rebuilt)==r['target_case_count_expected']
 assert r['actual_roots']==r['expected_roots']
 for target in targets:
  expected=src['class_root'] if target==r['target'] else original[(target,r['profile'])];assert r['actual_roots'][target]==expected
 args=c['argv'];ci=args.index('-cp');assert args[ci+1:ci+3]==r['application_classpath']+['ObjectArgumentDriver']
 assert args[ci+3:]==[r['actual_roots'][t] for t in targets for _ in range(2)]
 counts[r['producer']]+=1;cases[r['producer']]+=len(rebuilt)
for r in x['wrong_root_cells']:
 c=commands[r['command']];assert c['exit_code']==1 and r['rejected'];stderr=Path(c['streams']['stderr']['path']).read_text();assert 'wrong CodeSource:' in stderr and r['expected_roots'][r['target']] in stderr
 for t in targets:
  assert (r['actual_roots'][t]!=r['expected_roots'][t])==(t==r['target'])
result={'status':'accepted_generated_target_subsets','commands':120,'raw_streams':240,'trees':40,'VM_runs':80,'target_cases':sum(cases.values()),'VM_by_producer':dict(counts),'target_cases_by_producer':dict(cases),'wrong_CodeSource_rejections':40,'companion_rows_counted':False,'source_pins_verified':len(x['source_pins_after_finally']),'baseline_pins_verified':len(x['baseline_referenced_artifact_pins']),'target_absent':True,'limitation':'Jarde EqualityCases/ExplicitCastCases 32 compile failures remain unexecuted; these successful baseline runtimes do not validate the pending new product.'}
(Path(__file__).parent/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
