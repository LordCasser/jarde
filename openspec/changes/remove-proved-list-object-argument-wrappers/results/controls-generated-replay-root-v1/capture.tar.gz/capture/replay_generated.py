#!/usr/bin/env python3
"""Run successful target-only rebuilt classes against same-profile original companion roots."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, shutil, sys
from pathlib import Path
sys.dont_write_bytecode=True

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
BASE=Path('/private/tmp/jarde-object-argument-controls-baseline-root-v3-20261018/capture/execution.json')
BASE_SHA='352a1efd10cd31727e07b6ab333ffe4a93e84aece4f0c4e9203f730558c75ff4'
BASE_DRIVER_SHA='2b52abbfa9c5ee7457259364a00012ba1b105d2db4bdb0d19ff79410d3e0b3e7'
HELPER=Path('/private/tmp/jarde-object-argument-baseline-prep-luna-v2-20261018/collect_baseline.py')
HELPER_SHA='102186e11c687a63b2e54fb77acb262ba83146e9e116647b98d02c5d8ce9578b'
COMPARE='openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD='openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER='openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
PHYSICAL=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PHYSICAL_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
MANIFEST='openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
MANIFEST_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
MIN_FREE=5*1024**3; MAX_TARGET=1<<30; VMS=('javac8','javac23')
TARGETS=('RemovalCases','EqualityCases','ExplicitCastCases')


def sha_bytes(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def sha_path(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()
def pin(path: Path) -> dict:
    path=path.resolve(strict=True); return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha_path(path)}
def verify_pin(rec: dict,label: str) -> bytes:
    if not isinstance(rec,dict) or not {'path','bytes','sha256'}<=set(rec): raise ValueError(f'{label}: malformed pin')
    p=Path(rec['path']); data=p.read_bytes()
    if len(data)!=rec['bytes'] or sha_bytes(data)!=rec['sha256']: raise ValueError(f'{label}: pin mismatch {p}')
    return data
def load(path: Path,name: str):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def walk_pins(value,found: dict):
    if isinstance(value,dict):
        if {'path','bytes','sha256'}<=set(value) and isinstance(value.get('path'),str):
            p=Path(value['path'])
            if p.is_absolute():
                key=str(p.resolve())
                prior=found.get(key)
                if prior is not None and prior!={'path':key,'bytes':value['bytes'],'sha256':value['sha256']}:
                    raise ValueError(f'baseline has conflicting pins for {key}')
                found[key]={'path':key,'bytes':value['bytes'],'sha256':value['sha256']}
        for v in value.values(): walk_pins(v,found)
    elif isinstance(value,list):
        for v in value: walk_pins(v,found)
def check_case_lines(helper,raw: bytes,receipt_rows: list,label: str) -> list[dict]:
    parsed=helper.parse_driver(raw)
    strings=[x['raw'] for x in parsed]
    if strings!=receipt_rows: raise ValueError(f'{label}: pinned original stdout differs from stored rows')
    return parsed
def field_tokens(line: str) -> dict:
    parts=line.split()
    if not parts or parts[0]!='CASE': raise ValueError(f'malformed driver output {line!r}')
    result={}
    for part in parts[1:]:
        if '=' not in part: raise ValueError(f'malformed driver field {part!r}')
        k,v=part.split('=',1)
        if k in result: raise ValueError(f'duplicate driver field {k!r}')
        result[k]=v
    if not {'class','method','descriptor','exception','return'}<=set(result):
        raise ValueError(f'driver row lacks identity/result: {line!r}')
    return result
def parse_generated(raw: bytes,baseline_order: list[str]) -> list[dict]:
    lines=raw.decode('utf-8','strict').splitlines()
    if len(lines)!=len(baseline_order): raise ValueError(f'expected {len(baseline_order)} driver rows, got {len(lines)}')
    rows=[]
    for i,line in enumerate(lines):
        fields=field_tokens(line)
        expected=field_tokens(baseline_order[i])
        if (fields.get('class'),fields.get('method'))!=(expected.get('class'),expected.get('method')):
            raise ValueError(f'driver row {i} identity differs from original order')
        if fields.get('descriptor')!=expected.get('descriptor'):
            raise ValueError(f'driver row {i} JVM descriptor differs')
        rows.append({'index':i,'raw':line,'fields':fields})
    return rows

def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--baseline-execution',type=Path,default=BASE); ap.add_argument('--repo-root',type=Path,default=ROOT)
    args=ap.parse_args(); root=args.repo_root.resolve(strict=True); out=args.out.resolve()
    if out.exists(): raise SystemExit(f'refusing existing output {out}')
    if out==root or root in out.parents: raise SystemExit('output must be private and outside repository')
    if not args.baseline_execution.is_file() or sha_path(args.baseline_execution)!=BASE_SHA: raise SystemExit('frozen v3 baseline receipt SHA mismatch')
    if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('repository target must be absent before replay')
    if shutil.disk_usage(root).free<MIN_FREE: raise SystemExit('less than 5 GiB free before replay')
    compare_path=root/COMPARE; guard_path=root/GUARD; scanner_path=root/SCANNER; manifest_path=root/MANIFEST
    for p,h,label in ((HELPER,HELPER_SHA,'v2 baseline helper'),(compare_path,COMPARE_SHA,'compare'),(guard_path,GUARD_SHA,'guard'),
      (scanner_path,SCANNER_SHA,'scanner'),(PHYSICAL,PHYSICAL_SHA,'physical parser'),(manifest_path,MANIFEST_SHA,'JDK manifest')):
        if not p.is_file() or sha_path(p)!=h: raise SystemExit(f'{label} pin mismatch: {p}')
    receipt=json.loads(args.baseline_execution.read_text(encoding='utf-8'))
    if receipt.get('schema')!='object-argument-controls-baseline-v1' or receipt.get('status')!='captured-pending-independent-review':
        raise SystemExit('baseline receipt is incomplete or unexpected schema')
    if receipt.get('target_absent_finally') is not True or receipt.get('source_unchanged_finally') is not True:
        raise SystemExit('baseline final target/source guard did not pass')
    if receipt.get('source_pins_before')!=receipt.get('source_pins_after') or receipt.get('source_pins_after_finally')!=receipt.get('source_pins_before'):
        raise SystemExit('baseline source closure changed during capture')
    baseline_driver=receipt.get('driver_source')
    if not baseline_driver or baseline_driver.get('sha256')!=BASE_DRIVER_SHA: raise SystemExit('baseline v3 Base64 driver pin differs')
    helper=load(HELPER,'objectarg_baseline_helper'); compare=load(compare_path,'objectarg_replay_compare')
    guard=load(guard_path,'objectarg_replay_guard'); scanner=load(scanner_path,'objectarg_replay_scanner')
    physical=load(PHYSICAL,'objectarg_replay_physical')
    jdks,jdk_record=compare.configured_jdks(manifest_path,MANIFEST_SHA)
    if receipt.get('jdk_manifest',{}).get('sha256')!=MANIFEST_SHA: raise SystemExit('baseline JDK manifest pin differs')
    driver_rec=receipt['driver_compile']; driver_classes=Path(next(iter(driver_rec['class_tree'].values()))['path']).parent
    if driver_rec.get('exit_code')!=0 or not driver_rec.get('class_facts'): raise SystemExit('baseline standalone driver compile missing')
    original_roots={}
    for row in receipt.get('source_profiles',[]):
        if row.get('exit_code')!=0 or row.get('class_inventory_matches_source') is not True: raise SystemExit('baseline original target closure incomplete')
        key=(row['target'],row['profile'])
        if key in original_roots: raise SystemExit(f'duplicate original root {key}')
        original_roots[key]=Path(row['class_root']).resolve(strict=True)
    original_runs={(r['profile'],r['vm']):r for r in receipt.get('original_runs',[])}
    if len(original_runs)!=len(receipt.get('original_runs',[])): raise SystemExit('duplicate original runtime selector')
    for profile in ('javac8-debug','javac8-no-debug','javac23-debug','javac23-no-debug'):
        for vm in VMS:
            rec=original_runs.get((profile,vm))
            if not rec or rec.get('exit_code')!=0: raise SystemExit(f'missing successful original runtime {profile}/{vm}')
            stream=rec['streams']['stdout']; raw=verify_pin(stream,f'original oracle {profile}/{vm}')
            check_case_lines(helper,raw,rec['rows'],f'original oracle {profile}/{vm}')
            for target in TARGETS:
                subset=rec.get('case_subsets',{}).get(target)
                if not isinstance(subset,list) or not subset: raise SystemExit(f'missing original case subset {target}/{profile}/{vm}')
                expected=[line for line in rec['rows'] if field_tokens(line).get('class')=='controls.'+target]
                if subset!=expected: raise SystemExit(f'original case subset mismatch {target}/{profile}/{vm}')
    wrong={(r['target'],r['profile']):r for r in receipt.get('original_wrong_root',[])}
    expected_wrong={(target,profile) for target in TARGETS for profile in
      ('javac8-debug','javac8-no-debug','javac23-debug','javac23-no-debug')}
    if set(wrong)!=expected_wrong or len(wrong)!=len(receipt.get('original_wrong_root',[])) or any(r.get('rejected') is not True for r in wrong.values()):
        raise SystemExit('baseline per-target wrong-root inventory is incomplete')
    current_source=compare.source_closure(root)
    if current_source!=receipt['source_pins_after']: raise SystemExit('live source closure differs from frozen baseline closure')
    if receipt.get('default_stack') is not True or receipt.get('guard_limits',{}).get('free_bytes')!=MIN_FREE or receipt.get('guard_limits',{}).get('target_bytes')!=MAX_TARGET:
        raise SystemExit('baseline guard/default-stack contract differs')
    baseline_pins={}; walk_pins(receipt,baseline_pins)
    if len(baseline_pins)<len(receipt.get('external_pins_before',[])): raise SystemExit('incomplete baseline pin inventory')
    for item in baseline_pins.values(): verify_pin(item,'baseline referenced artifact')
    baseline_bytes=args.baseline_execution.read_bytes()
    out.mkdir(parents=True); rawdir=out/'raw'; rawdir.mkdir(); empty=out/'empty-classpath'; empty.mkdir()
    guard.ROOT=root; guard.OUT=rawdir; guard.target_bytes=lambda:scanner.target_bytes(root); guard.command_stream=compare.pin; guard.expected_test_summaries=lambda i,d:None
    runtime_rec=receipt.get('runtime_wrapper')
    runtime=Path(runtime_rec['path']); verify_pin(runtime_rec,'baseline runtime wrapper')
    runtime_copy=out/runtime.name; shutil.copyfile(runtime,runtime_copy)
    if runtime_copy.read_bytes()!=runtime.read_bytes(): raise RuntimeError('copied timeout wrapper differs')
    local_before={str(runtime_copy):compare.pin(runtime_copy)}
    protected={str(runtime_copy):compare.pin(runtime_copy)}
    external=[args.baseline_execution,HELPER,compare_path,guard_path,scanner_path,PHYSICAL,manifest_path,runtime,
      *[Path(t) for spec in jdks.values() for t in spec['tools'].values()],Path(sys.executable)]
    external_before=[compare.pin(p) for p in external]
    report={'schema':'object-argument-mixed-root-generated-runtime-v1','status':'running','root':str(root),'output':str(out),
      'baseline_receipt':compare.pin(args.baseline_execution),'baseline_sha256':BASE_SHA,'baseline_command_count':len(receipt['commands']),
      'baseline_driver':baseline_driver,'baseline_generated_compile_count':len(receipt['generated_compiles']),
      'jdk_manifest':jdk_record,'runtime_wrapper':compare.pin(runtime),'source_pins_before':current_source,
      'baseline_referenced_artifact_pin_count':len(baseline_pins),'baseline_referenced_artifact_pins':list(baseline_pins.values()),
      'external_pins_before':external_before,'local_copies_before':local_before,'guard_limits':{'free_bytes':MIN_FREE,'target_bytes':MAX_TARGET},
      'default_stack_required':True,'commands':[],'selected_trees':[],'runtime_cells':[],'wrong_root_cells':[],
      'notes':['Each generated class root supplies exactly one rebuilt target; the other two classes come from same-profile original roots.',
       'Only the rebuilt target case subset is compared with its same-profile, same-VM original rows. Companion-root driver rows are retained but are not counted as rebuilt cases.',
       'Each of the three actual/expected root pairs is independently checked by the parentless driver. One wrong-root command per generated tree mismatches only the rebuilt target.',
       'No javac/JADX/CLI is invoked in this replay; generated class trees and source copies are pinned to the completed baseline.']}
    commands=report['commands']
    try:
        def register(path: Path):
            if path.is_file(): protected[str(path)]=compare.pin(path)
        def command(argv,label,leg):
            if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError('repository target appeared')
            env=compare.clean_env(dict(os.environ),jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK',None)
            row=guard.run_command(len(commands)+1,[str(a) for a in argv],env); row['label']=label; row['tool_leg']=leg
            row['default_stack']='RUST_MIN_STACK' not in env; commands.append(row)
            for channel in ('stdout','stderr'):
                compare.command_artifact(row,channel); register(Path(row['streams'][channel]['path']))
            compare.write_json(out/'execution.json',report)
            if row.get('guard_stop') is not None or row.get('free_bytes_after',0)<MIN_FREE or row.get('peak_target_bytes',0)>MAX_TARGET:
                raise RuntimeError('resource guard stopped/failed '+label)
            return row
        def stream_pins(row): return {c:compare.pin(Path(row['streams'][c]['path'])) for c in ('stdout','stderr')}
        def artifact(row,channel): return compare.command_artifact(row,channel)
        def all_roots(profile,rebuilt_target,rebuilt_root):
            roots={n:original_roots[(n,profile)] for n in TARGETS}; roots[rebuilt_target]=rebuilt_root.resolve(strict=True); return roots
        def argv_roots(roots,expected):
            return [v for name in TARGETS for v in (roots[name].resolve(),expected[name].resolve())]
        def run_driver(roots,expected,label,vm):
            return command([sys.executable,'-B',runtime_copy,'30',jdks[vm]['tools']['java'],'-Xverify:all',
              '-cp',driver_classes,receipt['driver_compile'].get('main_class','ObjectArgumentDriver'),*argv_roots(roots,expected)],label,vm)
        selected=[]
        seen=set()
        for row in receipt.get('generated_compiles',[]):
            if row.get('exit_code')!=0 or row.get('class_inventory_matches_original') is not True: continue
            selector=(row.get('producer'),row.get('target'),row.get('profile'),row.get('evidence'),row.get('compiler'))
            if selector in seen: raise SystemExit(f'duplicate successful generated compile selector {selector}')
            seen.add(selector)
            rootcls=Path(row['class_root']).resolve(strict=True)
            if not row.get('class_tree') or not row.get('class_facts'): raise SystemExit(f'successful compile lacks full class facts {selector}')
            expected_paths=set(row['class_tree']); actual_paths={p.relative_to(rootcls).as_posix() for p in rootcls.rglob('*.class')}
            if actual_paths!=expected_paths: raise SystemExit(f'generated class closure changed {selector}')
            for rel,pinrec in row['class_tree'].items():
                if Path(pinrec['path']).resolve()!= (rootcls/rel).resolve(): raise SystemExit(f'class tree path mismatch {selector}/{rel}')
                verify_pin(pinrec,f'generated class {selector}/{rel}')
            for copy in row['source_copies']:
                src=verify_pin(copy['source'],f'generated source {selector}')
                dst=verify_pin(copy['copy'],f'generated source copy {selector}')
                if src!=dst: raise SystemExit(f'generated source copy is not byte exact {selector}')
            if (row['target'],row['profile']) not in original_roots: raise SystemExit(f'no same-profile original companions {selector}')
            selected.append(row)
        original_rows=[]
        for row in receipt['source_profiles']:
            original_rows.append((row['target'],row['profile'],str(original_roots[(row['target'],row['profile'])])))
        for item in selected:
            target=item['target']; profile=item['profile']; producer=item['producer']; evidence=item.get('evidence')
            rebuilt=Path(item['class_root']).resolve(strict=True); roots=all_roots(profile,target,rebuilt)
            companion_map={n:('rebuilt' if n==target else 'original') for n in TARGETS}
            for vm in VMS:
                expected_original=original_runs[(profile,vm)]['case_subsets'][target]
                if not expected_original: raise SystemExit(f'empty target oracle {target}/{profile}/{vm}')
                rr=run_driver(roots,roots,f'{producer}-{target}-{profile}-{evidence}-{item["compiler"]}-{vm}',vm)
                raw=artifact(rr,'stdout'); parse_error=None; rows=[]; observed=[]
                if rr['exit_code']==0:
                    try:
                        rows=parse_generated(raw,original_runs[(profile,vm)]['rows'])
                        observed=[r['raw'] for r in rows if r['fields']['class']=='controls.'+target]
                    except Exception as exc: parse_error=repr(exc)
                matches=rr['exit_code']==0 and parse_error is None and observed==expected_original
                report['runtime_cells'].append({'producer':producer,'target':target,'profile':profile,'evidence':evidence,
                  'compiler':item['compiler'],'vm':vm,'command':rr['index'],'exit_code':rr['exit_code'],'streams':stream_pins(rr),
                  'all_driver_rows':[x['raw'] for x in rows],'target_case_count_expected':len(expected_original),
                  'target_case_rows_observed':observed,'matches_target_original':matches,'parse_error':parse_error,
                  'target_root':str(rebuilt),'companion_roots':{n:str(roots[n]) for n in TARGETS if n!=target},
                  'root_roles':companion_map,'actual_roots':{n:str(roots[n]) for n in TARGETS},
                  'expected_roots':{n:str(roots[n]) for n in TARGETS},'application_classpath':[str(driver_classes.resolve())],
                  'full_driver_rows_included_but_not_counted_as_rebuilt':True})
                compare.write_json(out/'execution.json',report)
            expected={n:roots[n] for n in TARGETS}; expected[target]=empty
            wr=run_driver(roots,expected,f'wrong-root-{producer}-{target}-{profile}-{evidence}-{item["compiler"]}','javac23')
            rejected=wr['exit_code']==1 and b'wrong CodeSource:' in artifact(wr,'stderr')
            report['wrong_root_cells'].append({'producer':producer,'target':target,'profile':profile,'evidence':evidence,
              'compiler':item['compiler'],'command':wr['index'],'exit_code':wr['exit_code'],'rejected':rejected,
              'streams':stream_pins(wr),'actual_roots':{n:str(roots[n]) for n in TARGETS},
              'expected_roots':{n:(str(empty.resolve()) if n==target else str(roots[n])) for n in TARGETS},
              'application_classpath':[str(driver_classes.resolve())]})
            compare.write_json(out/'execution.json',report)
            report['selected_trees'].append({'producer':producer,'target':target,'profile':profile,'evidence':evidence,
              'compiler':item['compiler'],'class_root':str(rebuilt),'class_tree':item['class_tree'],
              'class_inventory_matches_original':item['class_inventory_matches_original'],'source_copies':item['source_copies'],
              'other_roots_are_same_profile_original':True,'runtime_vms':list(VMS),'wrong_root_count':1})
        from collections import Counter
        by_cell=Counter(f"{x['producer']}/{x['target']}/{x['profile']}" for x in report['runtime_cells'])
        case_counts={f"{x['producer']}/{x['target']}/{x['profile']}/{x['evidence']}/{x['compiler']}/{x['vm']}":x['target_case_count_expected']
                     for x in report['runtime_cells']}
        report['counts_derived_from_commands']={
          'successful_generated_trees_selected':len(selected),'commands_total':len(commands),
          'runtime_vm_cells':len(report['runtime_cells']),'wrong_root_cells':len(report['wrong_root_cells']),
          'runtime_cells_by_producer_target_profile':dict(sorted(by_cell.items())),
          'runtime_cells_by_full_selector':dict(sorted(Counter(
            f"{x['producer']}/{x['target']}/{x['profile']}/{x['evidence']}/{x['compiler']}/{x['vm']}"
            for x in report['runtime_cells']).items())),
          'target_case_counts_by_runtime_cell':case_counts,
          'target_case_rows_observed_total':sum(len(x['target_case_rows_observed']) for x in report['runtime_cells'])}
        report['failed_cells']=[
          {'kind':'runtime','producer':x['producer'],'target':x['target'],'profile':x['profile'],
           'evidence':x['evidence'],'compiler':x['compiler'],'vm':x['vm'],'exit_code':x['exit_code'],
           'matches_target_original':x['matches_target_original'],'parse_error':x['parse_error']}
          for x in report['runtime_cells'] if x['exit_code']!=0 or x['matches_target_original'] is not True]
        report['failed_cells'] += [
          {'kind':'wrong-root','producer':x['producer'],'target':x['target'],'profile':x['profile'],
           'evidence':x['evidence'],'compiler':x['compiler'],'exit_code':x['exit_code'],'rejected':x['rejected']}
          for x in report['wrong_root_cells'] if x['rejected'] is not True]
        report['source_pins_after']=compare.source_closure(root)
        report['source_unchanged']=report['source_pins_after']==current_source
        report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
        report['target_absent_after_replay']=report['target_absent']
        report['baseline_referenced_artifacts_unchanged']=all(
          verify_pin(x,'baseline final pin check') is not None for x in baseline_pins.values())
        report['external_pins_after']=[compare.pin(p) for p in external]
        report['external_inputs_unchanged']=report['external_pins_after']==external_before
        report['local_copies_after']={str(runtime_copy):compare.pin(runtime_copy)}
        report['local_copies_unchanged']=report['local_copies_after']==local_before
        report['protected_products_before_final']=dict(protected)
        report['protected_products_after']={k:compare.pin(Path(k)) for k in protected}
        report['products_unchanged']=report['protected_products_after']==report['protected_products_before_final']
        report['default_stack']=all(c.get('default_stack') is True for c in commands)
        if not selected: raise RuntimeError('no successful generated target trees to replay')
        if not all((report['source_unchanged'],report['target_absent'],report['baseline_referenced_artifacts_unchanged'],
          report['external_inputs_unchanged'],report['local_copies_unchanged'],report['products_unchanged'],report['default_stack'])):
            raise RuntimeError('source, baseline pins, artifacts, target, or stack guard changed')
        report['status']='captured-pending-independent-review'
        report['acceptance']='pending; runtime target-subset observations are not product acceptance'
    except BaseException as exc:
        report['status']='failed'
        report['error']=repr(exc)
        raise
    finally:
        try:
            report['source_pins_after_finally']=compare.source_closure(root)
            report['source_unchanged_finally']=report['source_pins_after_finally']==current_source
            report['baseline_artifacts_unchanged_finally']=all(
                verify_pin(x,'baseline final pin check') is not None for x in baseline_pins.values())
            report['external_pins_after_finally']=[compare.pin(p) for p in external]
            report['external_inputs_unchanged_finally']=report['external_pins_after_finally']==external_before
            report['local_copies_after_finally']={str(runtime_copy):compare.pin(runtime_copy)}
            report['local_copies_unchanged_finally']=report['local_copies_after_finally']==local_before
            report['protected_products_after_finally']={k:compare.pin(Path(k)) for k in protected}
            report['products_unchanged_finally']=report['protected_products_after_finally']==report.get('protected_products_before_final',protected)
            report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
            if not all((report['source_unchanged_finally'],report['baseline_artifacts_unchanged_finally'],
              report['external_inputs_unchanged_finally'],report['local_copies_unchanged_finally'],
              report['products_unchanged_finally'],report['target_absent_finally'])):
                report['status']='failed'; report['final_guard_error']='final source/input/product/target guard changed'
        except BaseException as final_exc:
            report['status']='failed'; report['final_guard_error']=repr(final_exc)
        report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out/'execution.json',report)
        shutil.copy2(__file__,out/'replay_generated.py')
    return 0

if __name__=='__main__': raise SystemExit(main())
