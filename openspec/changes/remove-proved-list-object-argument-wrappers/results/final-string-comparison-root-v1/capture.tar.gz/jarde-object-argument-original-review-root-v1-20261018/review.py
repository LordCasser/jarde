from pathlib import Path
import json,hashlib,importlib.util,re
BASE=Path('/private/tmp/jarde-object-argument-original-final-root-v1-20261018');x=json.loads((BASE/'execution.json').read_text());old=json.loads(Path('/private/tmp/jarde-ancestor-iterator-original-root-v1-20261018/execution.json').read_text())
def ck(p):
 b=Path(p['path']).read_bytes();assert len(b)==p['bytes'] and hashlib.sha256(b).hexdigest()==p['sha256'],p['path']
def scan(v,pins):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys() and isinstance(v['path'],str) and Path(v['path']).is_absolute():pins[v['path']]={k:v[k] for k in ('path','bytes','sha256')}
  for w in v.values():scan(w,pins)
 elif isinstance(v,list):
  for w in v:scan(w,pins)
def clean(v):
 if isinstance(v,dict):return {k:clean(w) for k,w in v.items() if k!='usage'}
 if isinstance(v,list):return [clean(w) for w in v]
 return v
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
assert x['status']=='captured-pending-independent-review' and len(x['commands'])==20
assert x['source_pins_before']==x['source_pins_after']==x['source_pins_after_finally'] and x['external_input_pins_before']==x['external_input_pins_after']==x['external_input_pins_after_finally'] and x['target_absent_finally'] and not Path('target').exists()
pins={};scan(x,pins)
for p in pins.values():ck(p)
for c in x['commands']:
 assert c['guard_stop'] is None and c['peak_target_bytes']==0 and c['free_bytes_after']>=5*1024**3
 for p in c['streams'].values():ck(p)
assert x['cli']['sha256']=='56a589ef9a170a1bb2911ed5597c20b2b4e06abf78da845f8fd3946099b2fa51'
assert x['javac8_full_source_boundary']['exit_code']==1 and x['javac8_full_source_boundary']['major_55_diagnostic_observed']
assert len(x['original_runtime'])==4 and x['runtime_semantic_agreement']
oracle=x['original_runtime'][0]['stdout']['sha256']
for r in x['original_runtime']:
 c=x['commands'][r['command']-1];a=c['argv'];idx=a.index('-cp');assert a[idx+1:idx+3]==r['application_classpath']+['TestNestedLoopsDriver'] and a[-1]==a[-2]==r['target_root']
 assert r['exit_code']==0 and len(r['rows'])==8 and r['stdout']['sha256']==oracle
 assert [v['raw'] for v in r['rows']]==Path(r['stdout']['path']).read_text().splitlines()
r=x['wrong_root_control'];assert r['exit_code']==1 and r['rejected'] and 'CodeSource' in Path(r['stderr']['path']).read_text()
compare=load(x['compare']['path'],'positive_compare');physical=load(x['physical_parser']['path'],'positive_physical')
for p in x['source_profiles']:
 assert p['exit_code']==0
 for r in p['class_tree'].values():
  a=compare.parse_class(Path(r['path']));b=physical.parse_class_file(Path(r['path']).read_bytes());assert a['methods']==b['methods']
 assert p['target_facts']['methods']==physical.parse_class_file(Path(p['target_facts']['path']).read_bytes())['methods']
for c in x['jarde_cells']:
 assert c['exit_code']==0 and all(m['quality']=='structured' and not m['fallbacks'] for m in c['methods'])
 previous=next(o for o in old['jarde_cells'] if all(o[k]==c[k] for k in ('profile','input_form','evidence')))
 assert c['input']['sha256']==previous['input']['sha256']
 a=clean(json.loads(Path(previous['report']['path']).read_text()));b=clean(json.loads(Path(c['report']['path']).read_text()))
 assert a['text'].count('(java.lang.Object) ')==2 and b['text']==a['text'].replace('(java.lang.Object) ','');a['text']=b['text']
 oldmethods=[m for m in a['methods'] if bytes(m['item']['identity']['name'])==b'test'];assert len(oldmethods)==1 and oldmethods[0]['text'].count('(java.lang.Object) ')==2;oldmethods[0]['text']=oldmethods[0]['text'].replace('(java.lang.Object) ','')
 assert a==b,'non-usage API differs beyond the two exact whole/method argument wrappers'
 doc=json.loads(Path(c['report']['path']).read_text());assert doc['text'].encode()==Path(c['whole_source']['path']).read_bytes()
 if c['profile']=='debug':assert 's1.equals(s2)' in doc['text'] and 'l1.remove(s2)' in doc['text'] and 'l2.add(s1)' in doc['text']
for c in x['jadx_outputs']:assert c['exit_code']==0
result={'status':'accepted_final_original_and_API','cli':x['cli'],'commands':20,'raw_streams':40,'original_VM_runs':4,'original_VM_cases':32,'original_wrong_CodeSource':1,'Jarde_API':8,'JADX_extracts':2,'sources_verified':len(x['source_pins_after_finally']),'all_pins_verified':len(pins),'raw_and_all_nonusage_API_unchanged_except':'exactly two Object presentation wrappers in whole class + test method; raw/maps/quality/identity unchanged','limit':'javac8 full outer harness major55 boundary failed as expected; generated Java compile/VM matrix next, not yet accepted','target_absent':True}
(Path(__file__).parent/'review.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='cli'})
