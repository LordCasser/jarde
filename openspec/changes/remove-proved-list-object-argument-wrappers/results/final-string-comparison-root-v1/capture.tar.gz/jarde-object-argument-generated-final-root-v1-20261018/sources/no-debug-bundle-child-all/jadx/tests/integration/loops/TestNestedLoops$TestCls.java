// jarde: presentation of `jadx/tests/integration/loops/TestNestedLoops$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestNestedLoops$TestCls extends java.lang.Object {
    public TestNestedLoops$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestNestedLoops$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public void test(java.util.List<java.lang.String> arg1, java.util.List<java.lang.String> arg2) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method test(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `jadx.tests.integration.loops.TestNestedLoops$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    for (java.lang.String local4 : arg1) {
                        for (java.lang.String local6 : arg2) {
                            if (local4.equals(local6)) {
                                if (local4.length() == 5) {
                                    arg2.add(local4);
                                } else {
                                    arg1.remove(local6);
                                }
                            }
                        }
                    }
                    if (arg2.size() > 0) {
                        arg1.clear();
                    }
                    return;
    }
}
