# Private implementation handoff: proved List Object argument wrappers

This is a private patch for OpenSpec task 2.1. It is based on the shared main snapshot read before editing; shared files were not changed and no Rust/JDK/Jarde toolchain was run.

## Change

`src/facade.rs` extracts the current `add(Object)` physical element-local proof into a private helper. The existing add path still requires that proof and still contributes the proved reference type to `type_uses`. Exact `List.remove(Object)` sites use the same helper only to add an optional presentation-wrapper removal; their types never enter `type_uses`. A separate optional scan handles only `invokevirtual java/lang/String.equals(Object):boolean`, requires the retained receiver presentation type and physical receiver proof to be exactly String, and requires the argument to pass the same local proof. Optional AST keys stay separate from the mandatory List receiver query. A missing optional proof leaves the call unchanged, while charged work and Stops return through the existing `Result` path.

The existing generic projection staging and final pass both recompute this proof and the removal list. Both use the retained-AST transaction already used for wrapper removal, so raw RecoveryReport text and maps are untouched. The tests update the String and Integer reference cases to expect `remove(option)`/`equals(s2)` while retaining existing real-cast, raw-map, and primitive-index checks.

## Files and source pins

Base copies were taken from the shared project before private edits:

- `src/facade.rs`: `cdbdb4d2ed652055c501072bb06dfad45493589b2ef7710cf799d4f77a430fc6`
- `crates/jarde-java/src/report.rs` (unchanged): `7f95ecec71e05b6a167d721bbe657660d55c646966e3638764c042b3b66272fb`
- `tests/structured_list_generic_bodies.rs`: `2aa41c5c61addd03a65264703031c18be7c5dfd9e51786968627f84cd13c421b`
- `tests/p3_hoisted_iterator_foreach.rs` (unchanged): `8a86063889dbff8a1b486e528bd6bde966bdcd37e935ed76dc6dcb092ae118c8`

Private edited SHA-256:

- `src/facade.rs`: `990f1ee5d64958e5d4bd9bf6cee9f29ef2cee2ca2d9fb7bc145e90c449abc619`
- `tests/structured_list_generic_bodies.rs`: `8bd6d51573c4ddad86f2ee8c6888813abb0f86f34582c3bf4a90a0c25f1cad8f`
- `changes.patch`: `e71f3a171b3318e46db11be058f001b56dc2ee3bf61fe00b8ba32f883fa55cd9`

Patch: `changes.patch` in this directory. The changed files are only facade.rs and the structured-list regression file; report.rs is an unchanged base copy.

## Static review and validation limits

The optional remove path matches the exact `java/util/List.remove:(Ljava/lang/Object;)Z` member contract already selected by the List body proof; primitive `remove(int)` is not selected. Integer references therefore follow reference widening to Object and do not provide List element inference. The equals path is exact to `java/lang/String.equals:(Ljava/lang/Object;)Z`; no custom equals descriptor is inventoried. Missing local proof skips the edit.

No tests, formatting, compilation, CLI, JDK, or runtime checks were run, by task instruction. Existing controls cover primitive remove overload refusal, real physical casts, and raw/source-map preservation, but this patch does not add a dedicated internal metamorphic test for an optional wrapper whose proof is deliberately broken while the generic candidate remains valid. Root can decide whether to request that before integration.
