from __future__ import annotations
import argparse, collections, hashlib, importlib.util, json, pathlib, re, sys, zipfile
from pathlib import Path

PREP = Path('/private/tmp/jarde-loop2-retry-native-ci-prep-luna-v2-20261019')
VERIFY = PREP / 'verify-own-ci.py'
ARGV = PREP / 'acceptance-argv.json'
EXPECTED_PRODUCT = '618b5e20f27f94ba28ea2f9e4310648718475f82'
EXPECTED_TOTALS = {'passed': 3823, 'failed': 0, 'ignored': 98}
EXPECTED_TARGETS = 393
EXPECTED_RESULTS = 3921
EXPECTED_STEPS = 52

def load_json(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p):
    h=hashlib.sha256(); n=0
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b); n+=len(b)
    return n,h.hexdigest()
def need(ok,msg):
    if not ok: raise ValueError(msg)
def import_verify():
    spec=importlib.util.spec_from_file_location('loop2_ci_verify',VERIFY)
    mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)
    return mod

def named_group(group, seed, v):
    lines=[v.clean_line(x) for x in group.splitlines()]
    env=[re.fullmatch(r"""PROPTEST_RNG_SEED:\s*["\']?(\d+)["\']?""",line) for line in lines if "PROPTEST_RNG_SEED:" in line]
    need(len(env)==1 and env[0] is not None and env[0].group(1)==seed, f'wrong/multiple seed marker for {seed}')
    headers=[line for line in lines if line.startswith('Running ')]
    rows=[]; outcomes=[]; counter=collections.Counter(); hidx=0; i=0
    while i<len(lines):
        running=v.RUNNING.fullmatch(lines[i])
        if not running:
            need(not lines[i].startswith('test result:'), f'summary without named block: {lines[i]}')
            i+=1; continue
        need(hidx<len(headers), f'no Running header for target block {hidx+1}')
        header=headers[hidx]; hidx+=1; declared=int(running.group(1)); named=[]; j=i+1
        while j<len(lines):
            summary=v.SUMMARY.fullmatch(lines[j])
            if summary:
                counts=tuple(int(summary.group(k)) for k in range(2,5)); measured=int(summary.group(5)); filtered=int(summary.group(6))
                need(declared==len(named), f'running count differs from named results for {header}')
                seen=(sum(s=='ok' for _,s,_ in named),sum(s=='FAILED' for _,s,_ in named),sum(s=='ignored' for _,s,_ in named))
                need(seen==counts, f'named results fail summary reconstruction for {header}: {seen} != {counts}')
                need((summary.group(1)=='ok')==(counts[1]==0), f'summary status/count mismatch: {lines[j]}')
                need(counts[1]==0 and filtered==0, f'failed or filtered workspace tests: {header}')
                target_match=v.RUN_TARGET.fullmatch(header); need(target_match is not None, f'unparsed target header: {header}')
                executable=target_match.group('path').rsplit('/',1)[-1]; binary=v.HASHED_EXE.fullmatch(executable)
                need(binary is not None, f'unrecognized test executable: {executable}')
                target=binary.group('target')
                for name,status,raw_status in named:
                    counter[(header,name,status)]+=1
                    outcomes.append((name,status,target,raw_status,header))
                rows.append({'target_header':header,'target_name':target,'named_tests':declared,'passed':counts[0],'failed':counts[1],'ignored':counts[2],'measured':measured,'filtered':filtered})
                i=j+1; break
            result=v.OUTCOME.fullmatch(lines[j])
            if result:
                raw=result.group(2); status='ignored' if raw.startswith('ignored') else raw
                named.append((result.group(1),status,raw))
            elif lines[j].startswith('test result:') or lines[j].startswith('test '):
                raise ValueError(f'unparsed test output: {lines[j]}')
            j+=1
        else: raise ValueError(f'target summary missing: {header}')
    need(hidx==len(headers) and rows and len(headers)==len(rows), 'target headers and result blocks differ')
    headers_list=[r['target_header'] for r in rows]
    need(len(headers_list)==len(set(headers_list)), 'duplicate target header in one seed')
    totals={k:sum(r[k] for r in rows) for k in ('passed','failed','ignored','measured','filtered')}
    need(sum(r['named_tests'] for r in rows)==len(outcomes), 'not every parsed outcome is counted')
    identity_counts=collections.Counter((header,name) for name,_,_,_,header in outcomes)
    duplicate_identities=sum(n-1 for n in identity_counts.values() if n>1)
    need(duplicate_identities==0, f'duplicate target-header/test-name identity: {duplicate_identities}')
    need(len(counter)==len(outcomes) and all(n==1 for n in counter.values()), 'named target/test/status Counter contains duplicate identities')
    return {'seed':seed,'targets':rows,'target_count':len(rows),'outcome_count':len(outcomes),'totals':totals,'outcome_counter':counter,'identity_count':len(identity_counts),'duplicate_identity_count':duplicate_identities,'counter_all_counts_one':all(n==1 for n in counter.values()),'outcomes':outcomes}

def collector_raw_closure(evidence, receipt):
    rows=receipt.get('commands'); need(isinstance(rows,list) and rows, 'collector commands absent')
    seen=set(); checked=0; mismatches=[]
    for row in rows:
        need(row.get('exit_code')==0, f'collector command failed: {row.get("argv")}')
        for channel in ('stdout','stderr'):
            pin=row.get('streams',{}).get(channel,{}); p=Path(pin.get('path',''))
            need(p.is_absolute() and p.is_file(), f'missing raw {channel}: {p}')
            resolved=p.resolve(); need(resolved.is_relative_to(evidence.resolve()), f'raw stream escapes evidence: {resolved}')
            need(str(resolved) not in seen, f'duplicate raw stream path: {resolved}'); seen.add(str(resolved))
            n,h=sha_file(resolved); checked+=1
            if n!=pin.get('bytes') or h!=pin.get('sha256'): mismatches.append({'path':str(resolved),'bytes':n,'sha256':h})
    need(not mismatches, f'raw stream hash/byte mismatches: {mismatches[:5]}')
    return {'collector_commands':len(rows),'raw_streams_checked':checked,'raw_stream_mismatches':mismatches}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--evidence-dir',required=True,type=Path)
    ap.add_argument('--acceptance',required=True,type=Path)
    ap.add_argument('--out-dir',required=True,type=Path)
    ap.add_argument('--product-sha',default=EXPECTED_PRODUCT)
    ap.add_argument('--cli-sha256',required=True)
    ap.add_argument('--cli-path',type=Path)
    args=ap.parse_args(); evidence=args.evidence_dir.resolve(strict=True); out=args.out_dir.resolve()
    need(args.product_sha==EXPECTED_PRODUCT, 'unexpected product SHA for this review')
    need(re.fullmatch(r'[0-9a-f]{64}',args.cli_sha256) is not None,'invalid CLI SHA256')
    acceptance=load_json(args.acceptance); collection=load_json(evidence/'collection.json'); pins=load_json(evidence/'source-pins.json')
    run=load_json(evidence/'run.json'); jobs=load_json(evidence/'jobs-api.json'); supplement=load_json(evidence/'step-log-supplement.json')
    need(acceptance.get('status')=='accepted','official acceptance has not completed successfully')
    need(collection.get('status')=='raw collection complete; independent acceptance pending','collection receipt is not final/closed')
    need(collection.get('product_sha')==args.product_sha and run.get('headSha')==args.product_sha and acceptance.get('product',{}).get('head_sha')==args.product_sha and acceptance.get('product',{}).get('expected_sha')==args.product_sha,'product SHA does not bind all receipts')
    need(str(collection.get('run_id'))==str(run.get('databaseId')) and str(acceptance.get('collection',{}).get('run_id'))==str(collection.get('run_id')),'CI run ID differs across receipts')
    need(run.get('workflowName')=='CI' and run.get('status')=='completed' and run.get('conclusion')=='success','workflow run is not successful')
    need(acceptance.get('product',{}).get('cli_sha256')==args.cli_sha256 and collection.get('cli_sha256')==args.cli_sha256 and pins.get('cli_sha256')==args.cli_sha256,'CLI SHA identity mismatch')
    if args.cli_path:
        n,h=sha_file(args.cli_path); need(h==args.cli_sha256,'CLI artifact bytes do not match pinned SHA')
    raw=collector_raw_closure(evidence,collection)
    csum=acceptance.get('collection',{})
    need(csum.get('command_count')==len(collection.get('commands',[])) and csum.get('source_file_count')==collection.get('source_file_count') and csum.get('fixture_file_count')==collection.get('fixture_file_count'),'acceptance collection counts differ from raw receipt')
    raw_job_hashes=acceptance.get('raw_job_log_sha256',{})
    for slug in ('stable','msrv','supply-chain','fuzz-smoke'):
        n,h=sha_file(evidence/(slug+'.log')); need(raw_job_hashes.get(slug+'.log')==h,f'acceptance raw log digest differs: {slug}.log')
    need(jobs.get('total_count')==4 and len(jobs.get('jobs',[]))==4 and len(run.get('jobs',[]))==4,'CI job inventory is not four')
    api_by_id={j.get('id'):j for j in jobs['jobs']}; run_by_name={j.get('name'):j for j in run['jobs']}
    expected_jobs={'stable':'stable / test and specification','msrv':'MSRV 1.88.0','supply-chain':'supply chain','fuzz-smoke':'fuzz smoke'}
    need(set(run_by_name)==set(expected_jobs.values()),'CI job names differ')
    job_results={}; step_count=0
    for slug,name in expected_jobs.items():
        rj=run_by_name[name]; aj=api_by_id.get(rj.get('databaseId'))
        need(aj is not None and aj.get('name')==name,'run/API job identities differ')
        need(rj.get('status')=='completed' and rj.get('conclusion')=='success' and aj.get('status')=='completed' and aj.get('conclusion')=='success',f'job not successful: {name}')
        steps=aj.get('steps',[]); need(steps and all(s.get('status')=='completed' and s.get('conclusion')=='success' for s in steps),f'job step not successful: {name}')
        job_results[slug]={'display_name':name,'steps':len(steps),'all_success':True}; step_count+=len(steps)
    v=import_verify(); verifier_argv=load_json(ARGV); extra=[]; va=verifier_argv['verify_ci']
    for i,arg in enumerate(va[:-1]):
        if arg=='--extra-critical': extra.append(va[i+1])
    gates=dict(v.CRITICAL_TESTS); seen=set(gates.values())
    for spec in extra:
        target,sep,name=spec.partition('='); need(sep=='=' and (name,target) not in seen,'bad/duplicate exact gate in pinned argv')
        seen.add((name,target)); gates[f'prep extra {len(seen)}']=(name,target)
    expected_gate_count=load_json(ARGV).get('expected_ci_exact_gate_count')
    need(len(gates)==expected_gate_count==123,'pinned exact gate inventory is not 123')
    official=v.official_step_logs(evidence)
    stable_name=expected_jobs['stable']; groups=v.workspace_groups(official[stable_name]); workflow,_,seeds=v.workflow_contract(Path('/Users/lordcasser/workspace/projects/jarde/.github/workflows/ci.yml'))
    parsed=[named_group(group,seed,v) for group,seed in zip(groups,seeds)]
    need(len(parsed)==2,'expected exactly two fixed-seed official workspace runs')
    a,b=parsed
    need(a['outcome_counter']==b['outcome_counter'],'per-target/test-name/status Counter differs across seeds')
    need([x['target_header'] for x in a['targets']]==[x['target_header'] for x in b['targets']],'target header inventory differs across seeds')
    per_seed=[]
    for pr in parsed:
        need(pr['target_count']==EXPECTED_TARGETS,'target count differs from expected measurement')
        need(pr['outcome_count']==EXPECTED_RESULTS,'named outcome total differs from expected measurement')
        need({k:pr['totals'][k] for k in EXPECTED_TOTALS}==EXPECTED_TOTALS,'workspace totals differ from expected measurement')
        seen_out=collections.Counter((name,target,status) for name,status,target,_,_ in pr['outcomes'])
        for name,target in gates.values(): need(seen_out[(name,target,'ok')]==1 and sum(seen_out[(name,target,s)] for s in ('ok','FAILED','ignored'))==1, f'exact gate missing/duplicated/not passing: {target}::{name}')
        per_seed.append({'seed':pr['seed'],'target_count':pr['target_count'],'named_outcome_count':pr['outcome_count'],'totals':pr['totals'],'named_counter_entries':len(pr['outcome_counter']),'duplicate_identity_count':pr['duplicate_identity_count'],'counter_all_counts_one':pr['counter_all_counts_one'],'exact_gate_count':len(gates)})
    need(step_count==EXPECTED_STEPS and acceptance.get('ci',{}).get('expanded_api_step_count')==EXPECTED_STEPS,'official CI step count is not 52')
    api_step_count=sum(len(j.get('steps',[])) for j in jobs['jobs'])
    need(api_step_count==step_count,'API step count calculation inconsistent')
    zip_path=evidence/'run-logs.zip'; zip_pin=supplement.get('streams',{}).get('stdout',{})
    n,h=sha_file(zip_path); need(zip_pin.get('path')==str(zip_path) and n==zip_pin.get('bytes') and h==zip_pin.get('sha256'),'official ZIP pin mismatch')
    need(supplement.get('run_id')==collection.get('run_id') and supplement.get('product_sha')==args.product_sha,'ZIP receipt is not bound to final run/product')
    need(acceptance.get('critical_gate_count')==123,'acceptance report does not record 123 gates')
    report={'schema':'jarde-loop2-ci-independent-named-outcome-review-v1','status':'passed_ci_named_outcomes_and_receipt_closure','product_sha':args.product_sha,'cli_sha256':args.cli_sha256,'run_id':collection['run_id'],'checks':{'seed_runs':per_seed,'all_named_counters_equal_across_seeds':True,'expected_result_observations_per_seed':EXPECTED_RESULTS,'expected_targets_per_seed':EXPECTED_TARGETS,'expected_totals_per_seed':EXPECTED_TOTALS,'exact_gates_per_seed':len(gates),'official_api_steps':step_count,'jobs':job_results,'raw_closure':raw,'raw_job_log_hashes_reopened':True,'official_zip':{'bytes':n,'sha256':h,'member_count':len(zipfile.ZipFile(zip_path).namelist())},'cli_artifact_rehashed':bool(args.cli_path)},'limitations':['This supplement independently compares all named outcomes across the two official seeds and closes collector raw pins. It does not replace the accepted product/CI verifier or claim additional product behavior.']}
    out.mkdir(parents=True,exist_ok=True); (out/'audit.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    manifest={'schema':'jarde-loop2-ci-independent-review-manifest-v1','status':'audit_written_after_closed_receipt','evidence_dir':str(evidence),'acceptance':str(args.acceptance),'audit':str(out/'audit.json'),'product_sha':args.product_sha,'cli_sha256':args.cli_sha256,'verifier_sha256':sha_bytes(VERIFY.read_bytes()),'acceptance_argv_sha256':sha_bytes(ARGV.read_bytes()),'audit_sha256':sha_file(out/'audit.json')[1]}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps({'status':report['status'],'audit':str(out/'audit.json'),'manifest':str(out/'manifest.json'),'seed_runs':per_seed,'raw_streams_checked':raw['raw_streams_checked'],'official_steps':step_count},sort_keys=True))
if __name__=='__main__':
    try: main()
    except (OSError,ValueError,KeyError,TypeError,json.JSONDecodeError,zipfile.BadZipFile) as e:
        print(f'independent CI review failed: {e}',file=sys.stderr); raise SystemExit(1)
