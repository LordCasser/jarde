import hashlib,io,json,stat,tarfile
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
CLOSEOUT_DIR=Path('/private/tmp/jarde-loop2-retry-closeout-root-v1-20261019')
TMP=Path('/private/tmp')
DEST=ROOT/'openspec/changes/recover-branching-named-catch-retry-loops/results/native-and-own-ci-root-v1'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert json.loads((CLOSEOUT_DIR/'ci-finish-v2-execution.json').read_text())['status']=='accepted'
assert json.loads((CLOSEOUT_DIR/'root-final-review.json').read_text())['status']=='accepted_scoped_loop2_product'
assert not (ROOT/'target').exists()
assert not DEST.exists();DEST.mkdir()
groups={
 'native':TMP/'jarde-loop2-retry-native-root-v1-20261019',
 'native-independent-review':TMP/'jarde-loop2-native-independent-review-luna-v1-20261019',
 'acceptance-tools':TMP/'jarde-loop2-retry-native-ci-prep-luna-v2-20261019',
 'product-binding':TMP/'jarde-loop2-retry-product-binding-root-v1-20261019',
 'own-ci':TMP/'jarde-loop2-retry-own-ci-root-v1-20261019',
 'ci-launch':TMP/'jarde-loop2-retry-own-ci-launch-root-v1-20261019',
 'ci-independent-review':TMP/'jarde-loop2-ci-independent-review-luna-v1-20261019',
 'spec-independent-review':TMP/'jarde-loop2-spec-sync-independent-review-luna-v1-20261019',
 'closeout':CLOSEOUT_DIR,
}
files={}
for label,base in groups.items():
 assert base.is_dir()
 for f in sorted(base.rglob('*')):
  assert not f.is_symlink(),f
  if f.is_file():files[label+'/'+f.relative_to(base).as_posix()]=f
native=json.loads((groups['native']/'execution.json').read_text())
for key in ['runner','guard_template','target_size_scan_adapter']:
 p=Path(native[key]['path']);assert sha(p.read_bytes())==native[key]['sha256'];files['native-tools/'+p.name]=p
inventory=[]
archive=DEST/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as out:
 for name,f in sorted(files.items()):
  b=f.read_bytes();mode=stat.S_IMODE(f.stat().st_mode);info=tarfile.TarInfo(name);info.size=len(b);info.mode=mode;info.mtime=0
  out.addfile(info,io.BytesIO(b));inventory.append({'path':name,'bytes':len(b),'mode':mode,'sha256':sha(b)})
(DEST/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as stored:
 members=stored.getmembers();assert len(members)==len(inventory)
 for m,row in zip(members,inventory):
  assert m.isfile() and m.name==row['path'] and m.size==row['bytes'] and m.mode==row['mode']
  assert sha(stored.extractfile(m).read())==row['sha256']
report={'status':'root_reopened_closed_native_own_ci_and_source_binding','product':'618b5e20f27f94ba28ea2f9e4310648718475f82','payload_count':len(inventory),'payload_bytes':sum(x['bytes'] for x in inventory),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'source_directories':{k:str(v) for k,v in groups.items()},'scope':'captured only after native, collectors, verifiers and independent audits completed; no CLI binary or target; all payload bytes/modes/digests reopened'}
(DEST/'capture.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
