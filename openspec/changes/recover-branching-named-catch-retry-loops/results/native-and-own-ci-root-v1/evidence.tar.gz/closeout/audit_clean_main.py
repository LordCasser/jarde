import datetime,hashlib,json,os,stat,subprocess
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path('/private/tmp/jarde-loop2-retry-final-clean-main-root-v1-20261019');OUT.mkdir(exist_ok=False)
PRODUCT='618b5e20f27f94ba28ea2f9e4310648718475f82';CLI=Path('/private/tmp/jarde-loop2-retry-final-focused-root-v2-20261019/candidate-cli')
record={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
def run(argv,cwd=ROOT):
 r=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE);i=len(record['commands']);so=OUT/f'{i}.stdout.raw';se=OUT/f'{i}.stderr.raw';so.write_bytes(r.stdout);se.write_bytes(r.stderr);record['commands'].append({'argv':argv,'cwd':str(cwd),'exit_code':r.returncode,'stdout':str(so),'stderr':str(se)});r.check_returncode();return r.stdout.decode().strip()
try:
 run(['git','fetch','origin']);head=run(['git','rev-parse','HEAD']);origin=run(['git','rev-parse','origin/main']);assert head==origin
 assert run(['git','branch','--show-current'])=='main';assert run(['git','status','--porcelain=v1'])==''
 assert run(['git','branch','--format=%(refname:short)']).splitlines()==['main']
 run(['git','merge-base','--is-ancestor',PRODUCT,head]);wt=run(['git','worktree','list','--porcelain']);trees=[]
 for block in wt.split('\n\n'):
  d={line.partition(' ')[0]:line.partition(' ')[2] for line in block.splitlines()};p=Path(d['worktree']);assert run(['git','status','--porcelain=v1'],p)=='';run(['git','merge-base','--is-ancestor',d['HEAD'],head]);assert p==ROOT or 'detached' in d;trees.append({'path':str(p),'head':d['HEAD'],'detached':'detached' in d,'clean':True,'ancestor_of_main':True})
 assert not (ROOT/'target').exists() and not (ROOT/'target').is_symlink();assert not (ROOT/'fuzz/target').exists()
 data=CLI.read_bytes();assert len(data)==64347312 and stat.S_IMODE(CLI.stat().st_mode)==0o555;digest=hashlib.sha256(data).hexdigest();assert digest=='7e321a7f4fd6a029540ab169f79572c6ad83e74119900ac6d695290c9c055318'
 ps=subprocess.run(['ps','-axo','pid=,comm='],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,text=True);active=[]
 names={'cargo','rustc','rustdoc','clippy-driver','java','javac'}
 for line in ps.stdout.splitlines():
  parts=line.strip().split(None,1)
  if len(parts)!=2 or Path(parts[1]).name not in names:continue
  pid=int(parts[0]);r=subprocess.run(['lsof','-a','-p',str(pid),'-d','cwd','-Fn'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  for v in r.stdout.splitlines():
   if v.startswith('n') and any(Path(v[1:])==Path(x['path']) or Path(x['path']) in Path(v[1:]).parents for x in trees):active.append({'pid':pid,'name':Path(parts[1]).name,'cwd':v[1:]})
 assert not active,active
 fs=os.statvfs(ROOT);record.update(status='clean_pushed_main_product_ancestor',head=head,origin_main=origin,product=PRODUCT,branches=['main'],worktrees=trees,target_absent=True,fuzz_target_absent=True,active_project_toolchains=active,cli={'path':str(CLI),'bytes':len(data),'mode':'0555','sha256':digest},free_bytes=fs.f_bavail*fs.f_frsize,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(OUT/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'status':record['status'],'head':head,'worktrees':len(trees),'target_absent':True}))
except BaseException as e:
 record.update(status='failed_no_clean_claim',error=repr(e));(OUT/'execution.json').write_text(json.dumps(record,indent=2)+'\n');raise
