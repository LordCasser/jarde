import datetime,json,subprocess,time
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
HOME=Path('/private/tmp/jarde-loop2-retry-closeout-root-v1-20261019')
PREP=Path('/private/tmp/jarde-loop2-retry-native-ci-prep-luna-v2-20261019')
OUT=Path('/private/tmp/jarde-loop2-retry-own-ci-root-v1-20261019')
PRODUCT='618b5e20f27f94ba28ea2f9e4310648718475f82'
CLI='7e321a7f4fd6a029540ab169f79572c6ad83e74119900ac6d695290c9c055318'
RUN='39227711617'
receipt={'product':PRODUCT,'run_id':RUN,'cli_sha256':CLI,'commands':[],'status':'waiting'}
def call(label,argv,stdout,stderr):
    assert not stdout.exists() and not stderr.exists()
    row={'label':label,'argv':argv,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with stdout.open('xb') as so,stderr.open('xb') as se:
        r=subprocess.run(argv,cwd=ROOT,stdout=so,stderr=se)
    row.update(exit_code=r.returncode,stdout=str(stdout),stderr=str(stderr),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    receipt['commands'].append(row)
    (HOME/'ci-finish-execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
    r.check_returncode()
    return stdout
try:
    for i in range(120):
        f=call('poll-'+str(i),['gh','run','view',RUN,'--json','headSha,status,conclusion,jobs,url'],HOME/f'ci-poll-{i}.stdout.raw',HOME/f'ci-poll-{i}.stderr.raw')
        d=json.loads(f.read_text());assert d['headSha']==PRODUCT
        print(json.dumps({'poll':i,'status':d['status'],'jobs':[(x['name'],x['status'],x['conclusion']) for x in d['jobs']]}),flush=True)
        if d['status']=='completed':
            assert d['conclusion']=='success' and len(d['jobs'])==4 and all(x['conclusion']=='success' for x in d['jobs'])
            break
        time.sleep(45)
    else:raise RuntimeError('CI wait limit reached; no acceptance')
    receipt['status']='collecting'
    call('collect-own-ci',['python3','-B',str(PREP/'collect-own-ci.py'),str(OUT),RUN,PRODUCT,CLI],HOME/'ci-collection.stdout.raw',HOME/'ci-collection.stderr.raw')
    print('own CI raw collection complete',flush=True)
    call('official-step-zip',['python3','-B',str(PREP/'collect-official-logs.py'),str(OUT)],HOME/'official-step-zip.stdout.raw',HOME/'official-step-zip.stderr.raw')
    print('official per-step ZIP collected',flush=True)
    template=json.loads((PREP/'acceptance-argv.json').read_text())['verify_ci']
    args=['python3','-B',str(PREP/'verify-own-ci.py'),str(OUT),'--product-sha',PRODUCT,'--cli-sha256',CLI]+template[template.index('--extra-critical'):]
    call('verify-own-ci',args,OUT/'acceptance.json',HOME/'ci-verification.stderr.raw')
    d=json.loads((OUT/'acceptance.json').read_text());assert d['status']=='accepted'
    receipt['status']='accepted';(HOME/'ci-finish-execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'status':'accepted','collection':d['collection'],'critical_gate_count':d['critical_gate_count'],'extras':len(d['additional_proof_gates'])}),flush=True)
except BaseException as e:
    receipt['status']='failed_no_acceptance';receipt['error']=repr(e);(HOME/'ci-finish-execution.json').write_text(json.dumps(receipt,indent=2)+'\n');raise
