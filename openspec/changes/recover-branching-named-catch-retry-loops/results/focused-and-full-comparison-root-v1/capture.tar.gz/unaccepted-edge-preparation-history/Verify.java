public class Verify { public static void main(String[] args) throws Exception { Class.forName("jadx.tests.integration.loops.TestBreakInLoop2$TestCls"); } }
