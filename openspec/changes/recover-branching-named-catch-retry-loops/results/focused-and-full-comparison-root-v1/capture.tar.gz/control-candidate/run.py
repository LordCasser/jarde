import hashlib,json,os,subprocess,sys,importlib.util
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path(__file__).resolve().parent;ORIG=Path('/private/tmp/jarde-loop2-retry-control-original-root-v1-20261019');CLI=Path('/private/tmp/jarde-loop2-retry-focused-root-v1-20261019/candidate-cli')
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p,name):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
assert pin(CLI)['sha256']=='7e321a7f4fd6a029540ab169f79572c6ad83e74119900ac6d695290c9c055318'
old=load('/private/tmp/jarde-testbreakinloop2-baseline-prep-luna-v1-20261019/collect_baseline.py','old');assert old.sha(ROOT/old.COMPARE_REL)==old.COMPARE_SHA256 and old.sha(old.PARSER)==old.PARSER_SHA256
compare=load(ROOT/old.COMPARE_REL,'compare');physical=load(old.PARSER,'physical')
original=json.loads((ORIG/'execution.json').read_text());tools=original['jdk_tools'];oracle=original['legs'][0]['runtime'][0]['cases'];driver=ORIG/'driver-classes';empty=OUT/'empty';empty.mkdir()
r={'status':'running','cli':pin(CLI),'script':pin(__file__),'original_receipt':pin(ORIG/'execution.json'),'commands':[],'cells':[],'runtime':[]}
def save(): (OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
def command(argv,label,expected=0):
 i=len(r['commands'])+1;row={'argv':[str(x) for x in argv],'label':label};r['commands'].append(row);save()
 env={k:v for k,v in os.environ.items() if k not in ('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH')}
 cp=subprocess.run(row['argv'],cwd=OUT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
 so=OUT/f'{i}.stdout.raw';se=OUT/f'{i}.stderr.raw';so.write_bytes(cp.stdout);se.write_bytes(cp.stderr);row.update(exit_code=cp.returncode,stdout=pin(so),stderr=pin(se));save();assert cp.returncode==expected,(label,cp.returncode,cp.stderr.decode(errors='replace')[:1200]);return cp.stdout
try:
 for orig in original['legs']:
  classfile=Path(orig['class']['path']);assert pin(classfile)==orig['class'];facts=old.full_class_facts(compare,physical,classfile,'original-control');previous=None
  for evidence in ('default','all'):
   label=orig['compiler']+'-'+orig['debug']+'-'+evidence;dest=OUT/label;dest.mkdir()
   argv=[CLI,'class-source','--input',classfile,'--class','recover/loop2/RetryCatchControl','--policy','single-class','--release','8','--format','json']
   if evidence=='all':argv+=['--evidence','all']
   raw=command(argv,'api-'+label);report=json.loads(raw);(dest/'report.json').write_bytes(raw);source=report['text'];assert source
   if previous is not None:assert source==previous
   previous=source;src=dest/'RetryCatchControl.java';src.write_text(source)
   methods=[]
   for m in report['methods']:
    assert m['outcome']['kind']=='recovered';body=m['outcome']['report'];methods.append({'name':m['item']['name']['escaped'],'quality':body['quality']})
   assert all(x['quality']=='structured' for x in methods),methods
   cell={'label':label,'source':pin(src),'report':pin(dest/'report.json'),'methods':methods,'compiles':[]};r['cells'].append(cell);save()
   for compiler in ('javac8','javac23'):
    target=dest/compiler;target.mkdir();flags=['-g'] if compiler=='javac8' else ['--release','8','-g']
    command([tools[compiler]['javac']['path'],*flags,'-d',target,src],'compile-'+label+'-'+compiler)
    outputs=list(target.rglob('*.class'));assert len(outputs)==1 and outputs[0].relative_to(target).as_posix()=='recover/loop2/RetryCatchControl.class'
    actual=old.full_class_facts(compare,physical,outputs[0],'generated-control');assert actual['access']==facts['access'];assert old.inventory_metadata_differences(facts,actual,'recover/loop2/RetryCatchControl')==[]
    cell['compiles'].append({'compiler':compiler,'class':pin(outputs[0]),'metadata_equal':True})
    for vm in ('javac8','javac23'):
     text=command([tools[vm]['java']['path'],'-Xverify:all','-cp',str(target)+os.pathsep+str(driver),'recover.loop2.RetryCatchControlRunner',target],'vm-'+label+'-'+compiler+'-'+vm).decode()
     rows=[x for x in text.splitlines() if x.startswith('CASE ')];assert rows==oracle
     r['runtime'].append({'label':label,'compiler':compiler,'vm':vm,'cases':rows,'original_equal':True});save()
    text=command([tools['javac23']['java']['path'],'-Xverify:all','-cp',str(target)+os.pathsep+str(driver),'recover.loop2.RetryCatchControlRunner',empty],'wrong-root-'+label+'-'+compiler,1).decode();assert 'CASE ' not in text
 r['status']='candidate_controls_passed_pending_independent_review'
except BaseException as e:r.update(status='failed',error=repr(e))
finally:r['target_absent']=not (ROOT/'target').exists();save();print(json.dumps({k:r.get(k) for k in ('status','error','target_absent')}))
sys.exit(0 if r['status']=='candidate_controls_passed_pending_independent_review' else 1)
