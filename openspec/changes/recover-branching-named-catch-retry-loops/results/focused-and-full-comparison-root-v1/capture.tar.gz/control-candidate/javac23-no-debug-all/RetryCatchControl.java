// jarde: presentation of `recover/loop2/RetryCatchControl` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package recover.loop2;

public final class RetryCatchControl extends java.lang.Object {
    // jarde: field Signature projection refused for `eventsLjava/util/List;`: unsupported (field_generic_body_unproved): a same-class Fieldref names this field and descriptor; same-class uses at reset(ZZZ)V@0, trace(Ljava/lang/String;)V@0, <clinit>()V@7
    static final java.util.List events;

    static int attempts;

    static int catches;

    static boolean failFirst;

    static boolean predicateValue;

    static boolean failRetryEffect;

    static java.lang.Exception saved;

    private RetryCatchControl() {
        // @method <init>()V
        // @declaration a constructor of `recover.loop2.RetryCatchControl`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static void reset(boolean arg0, boolean arg1, boolean arg2) {
        // @method reset(ZZZ)V
        // @declaration a static method of `recover.loop2.RetryCatchControl`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        recover.loop2.RetryCatchControl.events.clear();
        recover.loop2.RetryCatchControl.attempts = 0;
        recover.loop2.RetryCatchControl.catches = 0;
        recover.loop2.RetryCatchControl.failFirst = arg0;
        recover.loop2.RetryCatchControl.predicateValue = arg1;
        recover.loop2.RetryCatchControl.failRetryEffect = arg2;
        recover.loop2.RetryCatchControl.saved = null;
        return;
    }

    static void trace(java.lang.String arg0) {
        // @method trace(Ljava/lang/String;)V
        // @declaration a static method of `recover.loop2.RetryCatchControl`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        recover.loop2.RetryCatchControl.events.add((java.lang.Object) arg0);
        return;
    }

    public static void run() throws java.lang.Exception {
        // @method run()V
        // @declaration a static method of `recover.loop2.RetryCatchControl`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        while (true) {
            try {
                funcB();
                break;
            } catch (java.lang.Exception local0) {
                if (funcC(local0)) {
                    throw local0;
                } else {
                    retryEffect();
                    continue;
                }
            }
        }
        trace("return");
        return;
    }

    public static void runInverted() throws java.lang.Exception {
        // @method runInverted()V
        // @declaration a static method of `recover.loop2.RetryCatchControl`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        while (true) {
            try {
                funcB();
                break;
            } catch (java.lang.Exception local0) {
                if (!funcC(local0)) {
                    throw local0;
                } else {
                    retryEffect();
                    continue;
                }
            }
        }
        trace("return");
        return;
    }

    private static void funcB() throws java.lang.Exception {
        // @method funcB()V
        // @declaration a static method of `recover.loop2.RetryCatchControl`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        recover.loop2.RetryCatchControl.attempts = recover.loop2.RetryCatchControl.attempts + 1;
        trace((java.lang.String) new java.lang.StringBuilder().append("funcB:").append(recover.loop2.RetryCatchControl.attempts).toString());
        if (recover.loop2.RetryCatchControl.failFirst) {
            if (recover.loop2.RetryCatchControl.attempts == 1) {
                recover.loop2.RetryCatchControl.saved = new java.lang.Exception("B-once");
                throw recover.loop2.RetryCatchControl.saved;
            }
        }
        return;
    }

    private static boolean funcC(java.lang.Exception arg0) {
        // @method funcC(Ljava/lang/Exception;)Z
        // @declaration a static method of `recover.loop2.RetryCatchControl`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        recover.loop2.RetryCatchControl.catches = recover.loop2.RetryCatchControl.catches + 1;
        trace((java.lang.String) new java.lang.StringBuilder().append("funcC:").append((java.lang.String) arg0.getMessage()).append(":").append(recover.loop2.RetryCatchControl.predicateValue).toString());
        return recover.loop2.RetryCatchControl.predicateValue;
    }

    private static void retryEffect() {
        // @method retryEffect()V
        // @declaration a static method of `recover.loop2.RetryCatchControl`, member flags 0x000a
        // recovered from bytecode; presentation is not claimed to compile
        trace("clear");
        trace("retry-effect");
        if (recover.loop2.RetryCatchControl.failRetryEffect) {
            throw new java.lang.IllegalStateException("retry-effect-failed");
        } else {
            return;
        }
    }

    static {
        // @method <clinit>()V
        // @declaration a static initializer of `recover.loop2.RetryCatchControl`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        events = new java.util.ArrayList();
    }
}
