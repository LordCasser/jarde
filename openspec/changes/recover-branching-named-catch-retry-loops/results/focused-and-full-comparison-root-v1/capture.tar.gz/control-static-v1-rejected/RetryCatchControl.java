package recover.loop2;

import java.util.ArrayList;
import java.util.List;

/** Reachable, no-sleep control for the named-catch retry semantics. */
public final class RetryCatchControl {
    private RetryCatchControl() {}

    public static final class Control {
        public final List<String> events = new ArrayList<>();
        public final boolean failBOnce;
        public final boolean rethrowWhenPredicate;
        public final boolean predicateValue;
        public final boolean failRetryEffect;
        public int attempts;
        public int catches;
        public ControlledFailure originalFailure;

        public Control(boolean failBOnce, boolean rethrowWhenPredicate,
                boolean predicateValue, boolean failRetryEffect) {
            this.failBOnce = failBOnce;
            this.rethrowWhenPredicate = rethrowWhenPredicate;
            this.predicateValue = predicateValue;
            this.failRetryEffect = failRetryEffect;
        }
    }

    public static final class ControlledFailure extends Exception {
        public ControlledFailure(String message) { super(message); }
    }

    /** Normal polarity: a true predicate takes the terminal throw leaf. */
    public static void runTrueThrows(Control c) throws Exception {
        while (true) {
            try {
                funcB(c);
                c.events.add("protected-normal");
                break;
            } catch (Exception ex) {
                c.catches++;
                c.events.add("catch:" + ex.getClass().getSimpleName() + ":" + ex.getMessage());
                if (funcC(c, ex)) {
                    c.events.add("rethrow:" + ex.getMessage());
                    throw ex;
                }
                retryEffect(c);
            }
        }
        c.events.add("return");
    }

    /** Opposite polarity control: the same two catch leaves with the branch test reversed. */
    public static void runFalseThrows(Control c) throws Exception {
        while (true) {
            try {
                funcB(c);
                c.events.add("protected-normal");
                break;
            } catch (Exception ex) {
                c.catches++;
                c.events.add("catch:" + ex.getClass().getSimpleName() + ":" + ex.getMessage());
                if (!funcC(c, ex)) {
                    c.events.add("rethrow:" + ex.getMessage());
                    throw ex;
                }
                retryEffect(c);
            }
        }
        c.events.add("return");
    }

    private static void funcB(Control c) throws ControlledFailure {
        c.attempts++;
        c.events.add("funcB:" + c.attempts);
        if (c.failBOnce && c.attempts == 1) {
            c.originalFailure = new ControlledFailure("B-once");
            throw c.originalFailure;
        }
    }

    private static boolean funcC(Control c, Exception ex) {
        c.events.add("funcC:" + ex.getMessage() + ":" + c.predicateValue);
        return c.predicateValue;
    }

    /** This stands for clear plus the retry delay; the event is the delay, never a real sleep. */
    private static void retryEffect(Control c) {
        c.events.add("clear");
        c.events.add("retry-effect");
        if (c.failRetryEffect) {
            throw new IllegalStateException("retry-effect-failed");
        }
    }
}
