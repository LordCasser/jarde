package recover.loop2;

import java.util.Arrays;
import java.util.List;

/** Small deterministic runner; no real sleeps or external test framework. */
public final class RetryCatchControlRunner {
    private RetryCatchControlRunner() {}

    public static void main(String[] args) throws Exception {
        directNormalCompletion();
        retryThenSuccess();
        terminalRethrow();
        retryEffectFailureEscapesCatch();
        oppositeConditionPolarity();
    }

    private static void directNormalCompletion() throws Exception {
        RetryCatchControl.Control c = new RetryCatchControl.Control(false, true, false, false);
        RetryCatchControl.runTrueThrows(c);
        eq(c.events, "funcB:1", "protected-normal", "return");
        eq(c.attempts, 1);
        eq(c.catches, 0);
    }

    private static void retryThenSuccess() throws Exception {
        RetryCatchControl.Control c = new RetryCatchControl.Control(true, false, false, false);
        RetryCatchControl.runTrueThrows(c);
        eq(c.events, "funcB:1", "catch:ControlledFailure:B-once", "funcC:B-once:false",
                "clear", "retry-effect", "funcB:2", "protected-normal", "return");
        eq(c.attempts, 2);
        eq(c.catches, 1);
        if (c.originalFailure == null || !"B-once".equals(c.originalFailure.getMessage())) {
            throw new AssertionError("funcB failure value was not retained");
        }
    }

    private static void terminalRethrow() throws Exception {
        RetryCatchControl.Control c = new RetryCatchControl.Control(true, true, true, false);
        try {
            RetryCatchControl.runTrueThrows(c);
            throw new AssertionError("expected the original controlled failure");
        } catch (RetryCatchControl.ControlledFailure ex) {
            if (ex != c.originalFailure) throw new AssertionError("rethrow must preserve the caught value");
        }
        eq(c.events, "funcB:1", "catch:ControlledFailure:B-once", "funcC:B-once:true",
                "rethrow:B-once");
        eq(c.attempts, 1);
        eq(c.catches, 1);
    }

    private static void retryEffectFailureEscapesCatch() throws Exception {
        RetryCatchControl.Control c = new RetryCatchControl.Control(true, false, false, true);
        try {
            RetryCatchControl.runTrueThrows(c);
            throw new AssertionError("expected retry effect failure");
        } catch (IllegalStateException ex) {
            if (!"retry-effect-failed".equals(ex.getMessage())) throw ex;
        }
        eq(c.events, "funcB:1", "catch:ControlledFailure:B-once", "funcC:B-once:false",
                "clear", "retry-effect");
        eq(c.attempts, 1);
        eq(c.catches, 1);
    }

    private static void oppositeConditionPolarity() throws Exception {
        RetryCatchControl.Control c = new RetryCatchControl.Control(true, false, false, false);
        RetryCatchControl.runFalseThrows(c);
        eq(c.events, "funcB:1", "catch:ControlledFailure:B-once", "funcC:B-once:false",
                "rethrow:B-once");
        eq(c.attempts, 1);
        eq(c.catches, 1);
        if (c.originalFailure == null) throw new AssertionError("missing original failure");
    }

    private static void eq(List<String> actual, String... expected) {
        if (!actual.equals(Arrays.asList(expected))) {
            throw new AssertionError("events: expected " + Arrays.asList(expected) + " but got " + actual);
        }
    }

    private static void eq(int actual, int expected) {
        if (actual != expected) throw new AssertionError("expected " + expected + " but got " + actual);
    }
}
