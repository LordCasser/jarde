# Loop2 retry 控制例 v2（私有准备）

状态：只准备源码与确定性 case，不编译、不运行。v1 保留原状；本目录不是原件覆盖，也不替代原件/JADX/Jarde 基线。原件的 catch 动态不可达，控制例只验证可达的控制流语义。

`control/RetryCatchControl.java` 只有一个顶级目标类；`RetryCatchControlRunner.java` 是独立顶级 runner。目标的 `run`/`runInverted` 只在 while 内执行 `funcB(); break;`，catch 中先计数、随后立即按条件 throw 或进入 retry helper，没有条件前日志。`funcC` 记录谓词事件；`retryEffect` 记录 clear/effect，并可抛出不被原 try 捕获的 `IllegalStateException`。原始 `Exception` 实例通过 `saved` 保存并在 runner 中做对象身份断言。

五个 case 的事件、attempts、catches 和异常身份期望，以及完整来源 pin 在 `pins-and-cases.json`。runner 要求传入 target class output root，并检查 `RetryCatchControl` 的实际 `CodeSource`。计划将 target 与 runner 编译到分开的输出目录；original class 输入不加入 classpath。

原件 debug/no-debug class 的 pin 从 v1 `pins-and-cases.json` 复核；本准备过程没有读取、修改或覆盖原件 fixture。候选 Java 与 v1 输入的 bytes/SHA/mode 记在 pins-and-cases.json。
