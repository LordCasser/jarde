# Task 2.1 private candidate notes

This candidate is based on the pinned workspace `region.rs` and changes no shared file. It adds one accepted extension beside the existing RetryLoopFacts proof: an exact conditional handler block with two distinct normal successors, one terminal `athrow` block, and one single canonical retry block whose terminal physical `goto` targets the exact protected header.

The proof retains the prior one-row, one-protected-block, one-named-catch, join, protected throw-site, and exception-edge checks. It independently checks classfile control-flow targets against decoded Comparison/Transfer facts, requires exact canonical incoming/outgoing edge closure for the handler triple and header retry edge, and excludes handler/leaf clones or extra exception rows. The emitted shape reuses `Region::If`, terminal `Straight`/Throw statement decoding, and `LoopContinue`.

Only this new branch-proof frame enables the own-header transfer exception. Its source BCI, header ID, and target are checked at the edge classification point. The prefixed retry initializer explicitly leaves that permission disabled. The legacy single-block handler still uses the prior post-handler continue append; the conditional handler must contain the continue inside its retry arm and is matched against the exact two-arm Region shape. Completion compares occurrence counts as well as owner sets and visited delta.

Static review only. Rust/toolchain commands and tests were not run, per task constraints; the parent agent owns controlled execution and type/build validation. No task checkbox was changed.
