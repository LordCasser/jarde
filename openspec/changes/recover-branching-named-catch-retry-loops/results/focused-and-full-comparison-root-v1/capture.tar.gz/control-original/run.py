import hashlib,json,os,subprocess,sys,shutil,datetime
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path(__file__).resolve().parent
PREP=Path('/private/tmp/jarde-loop2-retry-control-luna-v3-20261019');SRC=PREP/'control/RetryCatchControl.java';DRIVER=PREP/'control/RetryCatchControlRunner.java'
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert not (ROOT/'target').exists()
assert pin(SRC)['sha256']=='a2ef2d67b45f6090b09f518dc3d877b05d8ea09267473b8729978a424c66e43e'
assert pin(DRIVER)['sha256']=='016b7627b7dd3d6c1f968fa88d08e1e727ad5f599fe68540d94904f2201e3aca'
base=Path('/private/tmp/jarde-testbreakinloop2-baseline-root-v1-20261019/execution.json');jdks=json.loads(base.read_text())['jdk_manifest']['tools']
for tools in jdks.values():
 for expected in tools.values():assert pin(expected['path'])==expected
r={'status':'running','source':pin(SRC),'driver_source':pin(DRIVER),'launcher':pin(__file__),'jdk_tools':jdks,'commands':[],'cases_per_vm':5}
def save(): (OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
def command(argv,label,expected=0):
 idx=len(r['commands'])+1;row={'argv':[str(x) for x in argv],'label':label};r['commands'].append(row);save()
 env={k:v for k,v in os.environ.items() if k not in ('CLASSPATH','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS')}
 for k in ('RUST_MIN_STACK','CARGO_TARGET_DIR'):env.pop(k,None)
 with (OUT/f'{idx}.stdout.raw').open('xb') as so,(OUT/f'{idx}.stderr.raw').open('xb') as se:
  row['exit_code']=subprocess.run(row['argv'],cwd=OUT,env=env,stdout=so,stderr=se,timeout=30).returncode
 row['stdout']=pin(OUT/f'{idx}.stdout.raw');row['stderr']=pin(OUT/f'{idx}.stderr.raw');save();assert row['exit_code']==expected,(label,row['exit_code'])
 return (OUT/f'{idx}.stdout.raw').read_text()
try:
 empty=OUT/'empty';empty.mkdir();driver_out=OUT/'driver-classes';driver_out.mkdir();oracle=None;r['legs']=[]
 for compiler in ('javac8','javac23'):
  for debug in ('debug','no-debug'):
   dest=OUT/compiler/debug;dest.mkdir(parents=True)
   flags=['-g' if debug=='debug' else '-g:none']
   if compiler=='javac23':flags=['--release','8']+flags
   command([jdks[compiler]['javac']['path'],*flags,'-d',dest,SRC],f'compile-target-{compiler}-{debug}')
   target=dest/'recover/loop2/RetryCatchControl.class';assert len(list(dest.rglob('*.class')))==1
   if oracle is None:
    command([jdks['javac8']['javac']['path'],'-cp',dest,'-d',driver_out,DRIVER],'compile-driver')
    assert [p.name for p in driver_out.rglob('*.class')]==['RetryCatchControlRunner.class']
   jp=command([jdks[compiler]['javap']['path'],'-p','-c','-v',target],f'javap-{compiler}-{debug}')
   case_rows=[]
   for runtime in ('javac8','javac23'):
    text=command([jdks[runtime]['java']['path'],'-Xverify:all','-cp',str(dest)+os.pathsep+str(driver_out),'recover.loop2.RetryCatchControlRunner',dest],f'run-{compiler}-{debug}-{runtime}')
    cases=[x for x in text.splitlines() if x.startswith('CASE ')];assert len(cases)==5
    if oracle is None:oracle=cases
    assert cases==oracle
    case_rows.append({'runtime':runtime,'cases':cases})
   text=command([jdks['javac23']['java']['path'],'-Xverify:all','-cp',str(dest)+os.pathsep+str(driver_out),'recover.loop2.RetryCatchControlRunner',empty],f'wrong-root-{compiler}-{debug}',1)
   assert 'CASE ' not in text
   r['legs'].append({'compiler':compiler,'debug':debug,'class':pin(target),'runtime':case_rows});save()
 r['status']='original_controls_passed_pending_candidate_and_ir_review'
except BaseException as e:r.update(status='failed',error=repr(e))
finally:
 r['inputs_unchanged']=r['source']==pin(SRC) and r['driver_source']==pin(DRIVER);r['target_absent']=not (ROOT/'target').exists();save();print(json.dumps({k:r.get(k) for k in ('status','error','inputs_unchanged','target_absent')}))
sys.exit(0 if r['status']=='original_controls_passed_pending_candidate_and_ir_review' else 1)
