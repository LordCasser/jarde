package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import java.util.List;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop2.class */
public class TestBreakInLoop2 extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop2$TestCls.class */
    public static class TestCls {
        public void test(List<Integer> list) throws Exception {
            while (true) {
                try {
                    funcB(list);
                    return;
                } catch (Exception e) {
                    if (funcC()) {
                        throw e;
                    }
                    list.clear();
                    Thread.sleep(100L);
                }
            }
        }

        private boolean funcB(List<Integer> list) {
            return false;
        }

        private boolean funcC() {
            return true;
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("while (true) {").containsOneOf(new String[]{"break;", "return;"}).containsOne("throw ex;").containsOne("data.clear();").containsOne("Thread.sleep(100L);");
    }
}
