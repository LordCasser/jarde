package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import java.util.List;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop2.class */
public class TestBreakInLoop2 extends IntegrationTest {

    /* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/TestBreakInLoop2$TestCls.class */
    public static class TestCls {
        public void test(List<Integer> data) throws Exception {
            while (true) {
                try {
                    funcB(data);
                    return;
                } catch (Exception ex) {
                    if (funcC()) {
                        throw ex;
                    }
                    data.clear();
                    Thread.sleep(100L);
                }
            }
        }

        private boolean funcB(List<Integer> data) {
            return false;
        }

        private boolean funcC() {
            return true;
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("while (true) {").containsOneOf(new String[]{"break;", "return;"}).containsOne("throw ex;").containsOne("data.clear();").containsOne("Thread.sleep(100L);");
    }
}
