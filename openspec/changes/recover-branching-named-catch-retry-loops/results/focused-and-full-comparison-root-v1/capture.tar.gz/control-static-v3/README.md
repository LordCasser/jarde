# Loop2 retry 控制例 v3（私有准备）

状态：仅准备源码与确定性 case，未编译、未运行。v2 原样保留，静态审回拒绝原因是 Runner 从错误的 `java.net.CodeSource` 导入类型；该类属于 `java.security`。v3 只修正此 import，并把 `catches++` 从 target catch body 移至 `funcC` 开头；其它源码结构、case、输入、命令计划不变。

目标源码 `control/RetryCatchControl.java` 只有顶级 `RetryCatchControl`；两个 catch body 都只有条件 throw 与 `retryEffect()` 调用。`funcC` 负责计 catch 并记录谓词事件。Runner 是独立顶级类，检查 target `CodeSource`，逐例输出并断言五个确定场景的事件、attempts、catches 与异常对象身份。

完整 case/来源 pins 在 `pins-and-cases.json`。计划将 target 与 runner 编译进分离目录；original class fixture 不加入 classpath。原件的 catch 动态不可达，控制例不替代原件基线。准备过程不改共享工作区，也未编译或运行。
