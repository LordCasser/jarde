#!/usr/bin/env python3
"""Make same-code-length Loop2 classfile neighbors for actual CFG tests.

No dependencies. The class name/member are found through the constant pool and member
attributes; bytecode edits are scoped to method test(List)V. Run with python3 -B.
"""
from __future__ import annotations
import struct
import sys
from pathlib import Path


def u2(b, p): return struct.unpack_from('>H', b, p)[0]
def u4(b, p): return struct.unpack_from('>I', b, p)[0]
def p2(b, p, n): struct.pack_into('>H', b, p, n)
def p4(b, p, n): struct.pack_into('>I', b, p, n)


def method_code(data: bytes):
    b = bytearray(data)
    if b[:4] != b'\xca\xfe\xba\xbe': raise ValueError('not a classfile')
    cp_count = u2(b, 8)
    cp, i = {}, 10
    index = 1
    while index < cp_count:
        tag = b[i]; i += 1
        if tag == 1:
            n = u2(b, i); i += 2
            cp[index] = b[i:i+n].decode('utf-8', 'replace'); i += n
        elif tag in (3, 4): i += 4
        elif tag in (5, 6): i += 8; index += 1
        elif tag in (7, 8, 16, 19, 20): cp[index] = ('idx', u2(b, i)); i += 2
        elif tag in (9, 10, 11, 12, 17, 18): i += 4
        elif tag == 15: i += 3
        else: raise ValueError(f'unknown constant-pool tag {tag} at {i-1}')
        index += 1
    cp_end = i
    def utf(ix):
        val = cp[ix]
        if isinstance(val, tuple): return cp[val[1]]
        return val
    access, this_cls, super_cls = struct.unpack_from('>HHH', b, i); i += 6
    interfaces = u2(b, i); i += 2 + interfaces*2
    fields = u2(b, i); i += 2
    def skip_members(i, count):
        for _ in range(count):
            i += 6
            attrs = u2(b, i); i += 2
            for _ in range(attrs):
                n = u4(b, i+2); i += 6+n
        return i
    i = skip_members(i, fields)
    methods = u2(b, i); i += 2
    for _ in range(methods):
        flags, name_ix, desc_ix = struct.unpack_from('>HHH', b, i); i += 6
        attr_count = u2(b, i); i += 2
        name, desc = utf(name_ix), utf(desc_ix)
        for _ in range(attr_count):
            attr_name = utf(u2(b, i)); length = u4(b, i+2); payload = i+6
            if name == 'test' and desc == '(Ljava/util/List;)V' and attr_name == 'Code':
                max_stack, max_locals = struct.unpack_from('>HH', b, payload)
                code_len = u4(b, payload+4); code_start = payload+8
                code_end = code_start+code_len
                ex_count_at = code_end
                ex_count = u2(b, ex_count_at)
                ex_start = ex_count_at+2
                ex_end = ex_start + ex_count*8
                nested_count = u2(b, ex_end); nested = ex_end+2; stackmap = None
                for _ in range(nested_count):
                    nested_name = utf(u2(b, nested)); nested_len = u4(b, nested+2)
                    if nested_name == 'StackMapTable': stackmap = (nested, nested+6, nested_len)
                    nested += 6+nested_len
                return b, payload, i+2, length, code_start, code_len, ex_count_at, ex_start, ex_end, stackmap
            i += 6+length
    raise ValueError('test(List)V Code attribute not found')


def short_branch(b, code, bci, target):
    off = code+bci
    if b[off] not in (0xa7, 0xc8): raise ValueError(f'expected goto at bci {bci}, got {b[off]:02x}')
    if b[off] == 0xa7:
        delta = target-bci
        if not -32768 <= delta <= 32767: raise ValueError('short branch out of range')
        struct.pack_into('>h', b, off+1, delta)
    else:
        struct.pack_into('>i', b, off+1, target-bci)


def make(data, case):
    b, payload, attr_len_at, attr_len, code, code_len, ex_count_at, ex_start, ex_end, stackmap = method_code(data)
    if code_len != 35: raise ValueError(f'expected frozen test code length 35, got {code_len}')
    if bytes(b[code:code+35]) != bytes.fromhex(
        '2a2bb7000757a7002203'
    )[:0]:
        pass  # Details are checked at each mutation below, to keep this helper version-tolerant.
    if case == 'wrong-retry-target':
        # retry leaf bci 19 -> return join bci 34, preserving instruction widths.
        short_branch(b, code, 31, 34)
    elif case == 'external-normal-entry-to-retry-leaf':
        # protected header bci 0 -> retry leaf bci 19. Actual normal edge 0->19
        # is now an external predecessor alongside handler edge 9->19.
        short_branch(b, code, 6, 19)
        # The normal header path does not define local 2. Remove the handler-only
        # Exception local from the bci19 frame, and keep bci34's incoming locals.
        if stackmap is None: raise ValueError('StackMapTable is required for this fixture')
        stackmap_attr, stackmap_data, stackmap_len = stackmap
        old = bytes(b[stackmap_data:stackmap_data+stackmap_len])
        expected = bytes.fromhex('00040048fc000907000dfa000e')
        if old != expected:
            raise ValueError(f'unexpected frozen StackMapTable payload {old.hex()}')
        b[stackmap_data:stackmap_data+stackmap_len] = bytes.fromhex('00040048fb0009fb000e')
        p4(b, stackmap_attr+2, stackmap_len-3)
        p4(b, attr_len_at, attr_len-3)
    elif case == 'retry-throw-leaf-returns':
        # Replace `aload_2; athrow` at 17..18 with `nop; return` at the same BCIs.
        if b[code+17] != 0x2c or b[code+18] != 0xbf:
            raise ValueError('expected aload_2; athrow at bci 17..18')
        b[code+17], b[code+18] = 0x00, 0xb1
    elif case == 'duplicate-physical-handler-row':
        # Add a second identical exception_table row, retaining bytecode length and
        # Code subattributes. The row is valid and points at the existing handler 9.
        count = u2(b, ex_count_at)
        if count != 1: raise ValueError(f'expected one original exception row, found {count}')
        original_row = bytes(b[ex_start:ex_end])
        b[ex_end:ex_end] = original_row
        p2(b, ex_count_at, count+1)
        p4(b, attr_len_at, attr_len+8)
    else:
        raise ValueError(f'unknown case {case}')
    return bytes(b), code, code_len


def main():
    if len(sys.argv) != 3: raise SystemExit('usage: patch_loop2_class.py INPUT.class OUTPUT_DIR')
    source, outdir = Path(sys.argv[1]), Path(sys.argv[2])
    outdir.mkdir(parents=True, exist_ok=True)
    data = source.read_bytes()
    for case in ('wrong-retry-target', 'external-normal-entry-to-retry-leaf',
                 'retry-throw-leaf-returns', 'duplicate-physical-handler-row'):
        result, code, length = make(data, case)
        target = outdir / (case + '.class')
        target.write_bytes(result)
        print(f'{case}: {target} class_bytes={len(result)} code_bci0={code} code_length={length}')

if __name__ == '__main__': main()
