import hashlib,json,os,shutil,subprocess,sys,datetime,traceback
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
PREP=Path('/private/tmp/jarde-testbreakinloop2-ir-probe-prep-luna-v2-20261019')
OUT=Path(__file__).resolve().parent
RUN=Path('/private/tmp/jarde-testbreakinloop2-ir-probe-run-root-v1-20261019')
REGION=ROOT/'crates/jarde-java/src/region.rs'
MODULE=ROOT/'crates/jarde-java/src/region/testbreakinloop2_ir_probe_tests.rs'
def pin(path):
 p=Path(path);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':p.stat().st_mode&0o777}
manifest=PREP/'pins.json'
assert pin(manifest)['sha256']=='005e85931c9c734f67308fd1fb4e55eead01903e90920c9183c375bcc6435ee1'
config=json.loads(manifest.read_text());expected={}
def collect(value):
 if isinstance(value,dict):
  if 'path' in value and 'sha256' in value:expected[value['path']]=value
  for v in value.values():collect(v)
 elif isinstance(value,list):
  for v in value:collect(v)
collect(config)
expected[str(manifest)]={'path':str(manifest),'sha256':pin(manifest)['sha256']}
for rel,sha in [('openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py','51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'),('openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py','d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7')]:expected[str(ROOT/rel)]={'sha256':sha}
def verify():
 result=[]
 for path,want in sorted(expected.items()):
  row=pin(path);assert row['sha256']==want['sha256'],path
  if 'bytes' in want:assert row['bytes']==want['bytes'],path
  result.append(row)
 return result
r={'status':'preflight','launcher':pin(__file__),'environment_override':{'JRE_LOOP2_IR_PROBE':'1'},'environment_scope':'guarded runner subprocess and inherited child processes; parent session environment unchanged','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save(): (OUT/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
original=None;applied=False;rc=1
try:
 r['pins_before']=verify();assert not RUN.exists() and not MODULE.exists() and not (ROOT/'target').exists()
 r['free_bytes_before']=shutil.disk_usage(ROOT).free;assert r['free_bytes_before']>=5*1024**3
 original=REGION.read_bytes();original_mode=REGION.stat().st_mode&0o777
 candidate=PREP/'candidate-region.rs';module=PREP/'testbreakinloop2_ir_probe_tests.rs'
 assert (PREP/'original-region.rs').read_bytes()==original
 applied=True;REGION.write_bytes(candidate.read_bytes());MODULE.write_bytes(module.read_bytes())
 r['temporary_sources']=[pin(REGION),pin(MODULE)];r['status']='running';save()
 env=dict(os.environ);env['JRE_LOOP2_IR_PROBE']='1'
 argv=['python3','-B',str(ROOT/'openspec/changes/recover-branch-throw-return-finally/tools/run_validation.py'),str(RUN),str(PREP/'commands.json')];r['argv']=argv;save()
 with (OUT/'stdout.raw').open('xb') as so,(OUT/'stderr.raw').open('xb') as se:
  rc=subprocess.run(argv,cwd=ROOT,env=env,stdout=so,stderr=se).returncode
 r['runner_exit_code']=rc
 if (RUN/'execution.json').exists():
  actual=json.loads((RUN/'execution.json').read_text());r['runner_receipt']=pin(RUN/'execution.json');r['runner_status']=actual['status']
  assert actual['status']=='commands_passed_pending_independent_acceptance'
  assert actual['source_unchanged'] and actual['target_absent']
 assert rc==0
 r['status']='probe_executed_pending_trace_review'
except BaseException as e:
 r.update(status='failed',error=str(e),traceback=traceback.format_exc())
finally:
 if applied:
  REGION.write_bytes(original);REGION.chmod(original_mode)
  if MODULE.exists():MODULE.unlink()
 try:
  r['pins_after']=verify();r['inputs_and_sources_restored']=r.get('pins_before')==r['pins_after']
  r['temporary_module_absent']=not MODULE.exists();r['target_absent']=not (ROOT/'target').exists()
  assert r['inputs_and_sources_restored'] and r['temporary_module_absent'] and r['target_absent']
 except BaseException as e:r.update(status='failed',finally_error=str(e))
 r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 print(json.dumps({k:r.get(k) for k in ('status','error','finally_error','runner_exit_code','target_absent','inputs_and_sources_restored')}))
sys.exit(0 if r['status']=='probe_executed_pending_trace_review' else 1)
