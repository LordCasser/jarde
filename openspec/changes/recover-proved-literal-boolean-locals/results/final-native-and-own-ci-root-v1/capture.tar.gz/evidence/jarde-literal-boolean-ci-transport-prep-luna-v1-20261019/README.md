# Literal-boolean own-CI transport retry preparation

This private preparation applies only the already accepted bounded transport policy to the literal-boolean own-CI collector and official-log ZIP helper. It does not run GitHub commands or any collector and does not change the acceptance checker.

`collect-own-ci.py` keeps the existing run/job/source checks and exact inventories. Its `SOURCE_PATHS` remains 24 entries and `EXPECTED_FIXTURE_FILES` remains 63 entries, verified equal to the source collector constants. Each `gh` call is attempted serially up to three times, with five seconds between failed attempts. Every attempt retains its own actual stdout/stderr streams. The canonical stream files are exact byte copies of the last attempt (which is the successful attempt whenever one succeeds); non-`gh` commands, including `git show`, remain single-attempt. The four job-log requests use `ThreadPoolExecutor(max_workers=1)`.

`collect-official-logs.py` is copied byte-for-byte from the already accepted transport helper, SHA-256 `99e6fc29ad9b00ed348631aa49b880651a42edcba890195b5b1a33d4f9ae60ef`. It retains each ZIP request attempt, stops on success, and byte-copies the final attempt to the canonical ZIP/error paths. The official ZIP tool has no literal-boolean-specific inputs.

The acceptance checker is untouched. Run nothing from this preparation until the root operator chooses to execute the CI collection.
