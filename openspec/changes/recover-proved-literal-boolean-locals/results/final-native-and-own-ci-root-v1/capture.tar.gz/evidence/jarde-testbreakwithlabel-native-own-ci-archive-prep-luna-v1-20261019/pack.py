#!/usr/bin/env python3
"""Pack explicitly accepted native/own-CI evidence without running project tools."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import tarfile
import zipfile

HERE = Path(__file__).resolve().parent
TMP = Path('/private/tmp').resolve()
FORBIDDEN_PARTS = {
    'target', '__pycache__', '.cache', 'cache', 'Caches', '.pytest_cache',
    '.mypy_cache', '.ruff_cache', 'incremental', '.fingerprint', '.cargo', 'node_modules',
}
FORBIDDEN_NAMES = {'candidate-cli'}
FORBIDDEN_SUFFIXES = {'.rlib', '.rmeta', '.dylib', '.so', '.o', '.a', '.dll', '.exe', '.pyc'}
REQUIRED_ACCEPTANCE_ROLES = {'native', 'own_ci', 'product_binding', 'named_outcomes'}
REQUIRED_PAYLOAD_ROLES = REQUIRED_ACCEPTANCE_ROLES | {'history', 'tooling'}
MAX_BYTES = 1024 * 1024 * 1024


def fail(message: str) -> None:
    raise SystemExit(f'archive refused: {message}')


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_path(path: Path) -> Path:
    absolute = path.absolute()
    for component in (absolute, *absolute.parents):
        if component.is_symlink():
            fail(f'symlink path component: {component}')
    return absolute


def read_stable(path: Path) -> tuple[bytes, int]:
    source = safe_path(path)
    if not source.exists() or not source.is_file():
        fail(f'missing or non-regular file: {source}')
    before = source.stat()
    data = source.read_bytes()
    after = source.stat()
    if (before.st_size, before.st_mtime_ns, before.st_mode) != (after.st_size, after.st_mtime_ns, after.st_mode):
        fail(f'file changed while reading: {source}')
    if len(data) != after.st_size:
        fail(f'file size changed while reading: {source}')
    return data, stat.S_IMODE(after.st_mode)


def native_binary(data: bytes, source: Path) -> bool:
    if source.suffix.lower() == '.class':
        return False
    return data.startswith((
        b'\x7fELF', b'MZ', b'\xfe\xed\xfa\xce', b'\xce\xfa\xed\xfe',
        b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe',
        b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca',
    ))


def json_field(value, dotted: str):
    current = value
    for segment in dotted.split('.'):
        if isinstance(current, list):
            current = current[int(segment)]
        else:
            current = current[segment]
    return current


def relative_inside(path: Path, root: Path) -> str | None:
    try:
        return path.resolve(strict=True).relative_to(root.resolve(strict=True)).as_posix()
    except (ValueError, FileNotFoundError):
        return None


def load_manifest(manifest_path: Path, accepted_root_sha: str) -> tuple[dict, Path, str]:
    manifest_path = safe_path(manifest_path)
    if not manifest_path.is_file():
        fail(f'manifest missing or non-regular: {manifest_path}')
    if not manifest_path.resolve(strict=True).is_relative_to(TMP):
        fail('manifest must be a root-supplied file under /private/tmp')
    try:
        manifest_bytes = manifest_path.read_bytes()
        manifest = json.loads(manifest_bytes.decode('utf-8'))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        fail(f'manifest is invalid JSON: {exc}')
    if manifest.get('schema') != 'jarde-native-own-ci-archive-inputs-v1':
        fail('unsupported manifest schema')
    if manifest.get('manifest_kind') != 'accepted-inputs':
        fail('manifest_kind must be accepted-inputs')
    if len(accepted_root_sha) != 64 or any(c not in '0123456789abcdef' for c in accepted_root_sha):
        fail('--accepted-root-review-sha256 must be 64 lowercase hex characters')
    root_marker = manifest.get('accepted_root_review')
    if not isinstance(root_marker, dict) or root_marker.get('sha256') != accepted_root_sha:
        fail('root must pass the exact accepted root-review pin also recorded in the manifest')
    if not manifest.get('directories') or not manifest.get('markers'):
        fail('manifest must explicitly list evidence directories and acceptance markers')
    return manifest, manifest_path, sha(manifest_bytes)


def collect(manifest: dict, manifest_path: Path) -> tuple[dict, dict[str, tuple[Path, bytes, int]]]:
    entries = manifest['directories']
    if not isinstance(entries, list):
        fail('directories must be a list')
    by_id = {}
    roles = set()
    items: dict[str, tuple[Path, bytes, int]] = {}
    seen_sources: set[str] = set()
    root_map: dict[str, Path] = {}

    def add(archive_path: str, source: Path, data: bytes, mode: int) -> None:
        rel = PurePosixPath(archive_path)
        if rel.is_absolute() or '..' in rel.parts or not rel.parts:
            fail(f'unsafe archive path: {archive_path}')
        name = rel.as_posix()
        if name in items or name == 'ARCHIVE_INVENTORY.json':
            fail(f'duplicate/reserved archive path: {name}')
        source = safe_path(source)
        resolved = str(source.resolve(strict=True))
        if resolved in seen_sources:
            fail(f'duplicate source path in manifest: {resolved}')
        if any(part in FORBIDDEN_PARTS for part in source.parts) or source.name in FORBIDDEN_NAMES:
            fail(f'cache/build/CLI path is not archivable: {source}')
        if source.suffix.lower() in FORBIDDEN_SUFFIXES or native_binary(data, source):
            fail(f'native executable/build artifact is not archivable: {source}')
        seen_sources.add(resolved)
        items[name] = (source, data, mode)

    for entry in entries:
        if not isinstance(entry, dict) or set(entry) != {'id', 'role', 'path', 'archive_prefix'}:
            fail('each directory needs exactly id, role, path, archive_prefix')
        ident, role = entry['id'], entry['role']
        if not isinstance(ident, str) or not ident or ident in by_id:
            fail(f'duplicate/invalid directory id: {ident}')
        if role not in {'native', 'own_ci', 'product_binding', 'named_outcomes', 'history', 'tooling'}:
            fail(f'unknown evidence role: {role}')
        root = safe_path(Path(entry['path']))
        if not root.resolve(strict=True).is_relative_to(TMP):
            fail(f'evidence directory must be under /private/tmp: {root}')
        if not root.exists() or not root.is_dir():
            fail(f'required evidence directory missing/non-directory: {root}')
        prefix = PurePosixPath(entry['archive_prefix'])
        if prefix.is_absolute() or '..' in prefix.parts or not prefix.parts:
            fail(f'unsafe archive prefix: {prefix}')
        by_id[ident] = entry
        roles.add(role)
        root_map[ident] = root
        paths = sorted(root.rglob('*'), key=lambda p: p.as_posix())
        if not paths:
            fail(f'required evidence directory is empty: {root}')
        count_before = len(items)
        for path in paths:
            if path.is_symlink():
                fail(f'symlink in evidence tree: {path}')
            if path.is_dir():
                if path.name in FORBIDDEN_PARTS:
                    fail(f'cache/build directory in evidence tree: {path}')
                continue
            if not path.is_file():
                fail(f'non-regular evidence entry: {path}')
            if any(part in FORBIDDEN_PARTS for part in path.parts) or path.name in FORBIDDEN_NAMES:
                fail(f'cache/build/CLI input present in evidence tree: {path}')
            data, mode = read_stable(path)
            add((prefix / path.relative_to(root).as_posix()).as_posix(), path, data, mode)
        if len(items) == count_before:
            fail(f'evidence directory yielded no payload: {root}')
    if not REQUIRED_PAYLOAD_ROLES <= roles:
        fail(f'missing required evidence roles: {sorted(REQUIRED_PAYLOAD_ROLES-roles)}')
    if sum(entry['role'] == 'tooling' for entry in entries) < 2:
        fail('manifest must separately include own-CI preparation and root static-review tooling directories')

    markers = manifest['markers']
    if not isinstance(markers, list) or not markers:
        fail('markers must be a non-empty list')
    marker_ids = set()
    marker_receipts = {}
    for marker in markers:
        required = {'id', 'role', 'path', 'sha256', 'status_field', 'accepted_status'}
        if not isinstance(marker, dict) or set(marker) != required | ({'bindings'} if 'bindings' in marker else set()):
            fail('acceptance marker shape is invalid')
        if marker['id'] in marker_ids:
            fail(f'duplicate marker id: {marker["id"]}')
        marker_ids.add(marker['id'])
        if marker['role'] not in REQUIRED_ACCEPTANCE_ROLES | {'root'}:
            fail(f'unknown acceptance-marker role: {marker["role"]}')
        marker_path = safe_path(Path(marker['path']))
        if len(marker['sha256']) != 64:
            fail(f'invalid marker SHA-256: {marker_path}')
        data, _ = read_stable(marker_path)
        if sha(data) != marker['sha256']:
            fail(f'acceptance marker pin mismatch: {marker_path}')
        try:
            value = json.loads(data.decode('utf-8'))
            status = json_field(value, marker['status_field'])
        except (UnicodeDecodeError, json.JSONDecodeError, KeyError, IndexError, TypeError, ValueError) as exc:
            fail(f'cannot read status field for marker {marker["id"]}: {exc}')
        if status != marker['accepted_status']:
            fail(f'marker {marker["id"]} status is not its explicitly expected accepted value')
        if not marker.get('bindings'):
            fail(f'marker {marker["id"]} must bind at least one exact receipt or artifact SHA-256')
        containing = [root for root in root_map.values() if relative_inside(marker_path, root) is not None]
        if not containing:
            fail(f'acceptance marker is outside every included evidence directory: {marker_path}')
        for binding in marker.get('bindings', []):
            if set(binding) != {'field', 'value'}:
                fail(f'invalid binding shape in marker {marker["id"]}')
            try:
                actual = json_field(value, binding['field'])
            except (KeyError, IndexError, TypeError, ValueError) as exc:
                fail(f'missing binding field in marker {marker["id"]}: {exc}')
            if actual != binding['value']:
                fail(f'marker {marker["id"]} binding mismatch at {binding["field"]}')
        marker_receipts[marker['id']] = {'path': str(marker_path), 'sha256': sha(data), 'status': status,
                                         'role': marker['role']}
    root_markers = [marker for marker in markers if marker['role'] == 'root']
    if len(root_markers) != 1:
        fail('manifest must include exactly one accepted root-review marker')
    declared_root = manifest['accepted_root_review']
    if root_markers[0]['path'] != declared_root.get('path') or root_markers[0]['sha256'] != declared_root.get('sha256'):
        fail('accepted_root_review and root marker entries must identify the same pinned file')
    for role in REQUIRED_ACCEPTANCE_ROLES:
        if not any(marker['role'] == role for marker in markers):
            fail(f'missing accepted marker for required role: {role}')

    official_zips = manifest.get('official_zip_files')
    if not isinstance(official_zips, list) or not official_zips:
        fail('manifest must list the independently captured official CI ZIP files')
    for item in official_zips:
        if set(item) != {'path', 'sha256'}:
            fail('official ZIP entry requires exactly path and sha256')
        path = safe_path(Path(item['path']))
        data, _ = read_stable(path)
        if sha(data) != item['sha256']:
            fail(f'official ZIP pin mismatch: {path}')
        if not zipfile.is_zipfile(path):
            fail(f'official CI artifact is not a ZIP: {path}')
        with zipfile.ZipFile(path) as archive:
            bad = archive.testzip()
            if bad is not None:
                fail(f'official CI ZIP has a corrupt member: {path}: {bad}')
        if str(path.resolve()) not in seen_sources:
            fail(f'official ZIP is not included through an evidence directory: {path}')

    # Ensure every manifest marker/zip input is also represented in the payload tree.
    for entry_path in [Path(m['path']).resolve(strict=True) for m in markers]:
        if str(entry_path) not in seen_sources:
            fail(f'acceptance marker missing from payload tree: {entry_path}')
    for item in official_zips:
        if str(Path(item['path']).resolve(strict=True)) not in seen_sources:
            fail(f'official ZIP missing from payload tree: {item["path"]}')

    # Include the exact manifest and packer for reproducibility.
    manifest_bytes, manifest_mode = read_stable(manifest_path)
    add('archive-preparation/accepted-inputs.json', manifest_path, manifest_bytes, manifest_mode)
    for tool in (HERE / 'pack.py', HERE / 'README.md', HERE / 'adaptation.md', HERE / 'manifest.template.json', HERE / 'pins.json'):
        data, mode = read_stable(tool)
        add('archive-preparation/' + tool.name, tool, data, mode)

    total = sum(len(data) for _, data, _ in items.values())
    if total > MAX_BYTES:
        fail(f'archive input exceeds {MAX_BYTES} bytes: {total}')
    rows = [{'archive_path': name, 'source_path': str(path.resolve()), 'bytes': len(data),
             'sha256': sha(data), 'mode': mode}
            for name, (path, data, mode) in sorted(items.items())]
    inventory = {'schema': 'jarde-native-own-ci-evidence-inventory-v1',
                 'payload_member_count': len(rows), 'members': rows,
                 'accepted_markers': marker_receipts,
                 'official_zip_files': official_zips,
                 'roles_present': sorted(roles),
                 'notes': ['All supplied failure receipts, raw streams, independent official ZIPs, and named-outcome files are preserved as payload.',
                           'No CLI executable, Cargo target/cache, or Rust build artifact is allowed in the payload.']}
    return inventory, items


def pack(manifest_path: Path, out: Path, accepted_root_sha: str) -> dict:
    manifest, manifest_path, manifest_sha = load_manifest(manifest_path, accepted_root_sha)
    output = safe_path(out.absolute()).resolve(strict=False)
    evidence_roots = [Path(entry['path']).resolve(strict=True) for entry in manifest['directories']]
    if any(output == root or output.is_relative_to(root) for root in evidence_roots):
        fail('output must be outside all evidence input directories')
    if output.exists():
        fail(f'refusing existing output: {output}')
    inventory, items = collect(manifest, manifest_path)
    if sha(items['archive-preparation/accepted-inputs.json'][1]) != manifest_sha:
        fail('root-supplied manifest changed after loading')
    if output.is_relative_to(HERE):
        fail('output cannot be inside preparation directory')
    output.parent.mkdir(parents=True, exist_ok=True)
    inventory_bytes = (json.dumps(inventory, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    with output.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as zipped:
            with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for name, (source, data, mode) in sorted(items.items()):
                    member = tarfile.TarInfo(name)
                    member.size = len(data); member.mode = mode; member.mtime = 0
                    member.uid = member.gid = 0; member.uname = member.gname = ''
                    archive.addfile(member, io.BytesIO(data))
                member = tarfile.TarInfo('ARCHIVE_INVENTORY.json')
                member.size = len(inventory_bytes); member.mode = 0o644; member.mtime = 0
                member.uid = member.gid = 0; member.uname = member.gname = ''
                archive.addfile(member, io.BytesIO(inventory_bytes))
    verify(output, inventory, items, inventory_bytes)
    sidecar = output.with_suffix(output.suffix + '.inventory.json')
    with sidecar.open('xb') as stream:
        stream.write(inventory_bytes)
    return {'status': 'packed-and-reopened', 'archive': str(output), 'archive_sha256': sha(output.read_bytes()),
            'inventory': str(sidecar), 'inventory_sha256': sha(inventory_bytes), 'payload_members': len(items)}


def verify(output: Path, inventory: dict, items: dict[str, tuple[Path, bytes, int]], inventory_bytes: bytes) -> None:
    with tarfile.open(output, 'r:gz') as archive:
        members = archive.getmembers()
        by_name = {member.name: member for member in members}
        expected = set(items) | {'ARCHIVE_INVENTORY.json'}
        if len(by_name) != len(members) or set(by_name) != expected:
            fail('archive member set contains duplicates, omissions, or unexpected entries')
        for name, (source, expected_bytes, expected_mode) in items.items():
            member = by_name[name]
            if not member.isfile() or member.mode != expected_mode:
                fail(f'archive type/mode mismatch: {name}')
            data = archive.extractfile(member).read()
            if data != expected_bytes or len(data) != len(expected_bytes) or sha(data) != sha(expected_bytes):
                fail(f'archive bytes/SHA mismatch: {name}')
            current, current_mode = read_stable(source)
            if current != expected_bytes or current_mode != expected_mode:
                fail(f'source changed while packing: {source}')
        raw_inventory = archive.extractfile(by_name['ARCHIVE_INVENTORY.json']).read()
        if raw_inventory != inventory_bytes or json.loads(raw_inventory) != inventory:
            fail('archive inventory bytes/schema mismatch')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True, help='root-supplied frozen manifest with every accepted directory and marker pin')
    parser.add_argument('--accepted-root-review-sha256', required=True, help='explicit SHA-256 for the manifest root acceptance marker')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(pack(args.manifest, args.out, args.accepted_root_review_sha256), indent=2))


if __name__ == '__main__':
    main()
