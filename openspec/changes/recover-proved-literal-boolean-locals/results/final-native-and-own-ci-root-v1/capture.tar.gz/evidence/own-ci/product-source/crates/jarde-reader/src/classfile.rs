//! Owned, bounded header inspection backed exclusively by noak 0.7.0.

use crate::budget::{Budget, CountedBudgetDimension};
use crate::error::{Error, Result};
use crate::model::{
    ByteSpan, Coverage, CoverageDimension, CoverageRange, CoverageState, Diagnostic,
    DiagnosticSeverity, ExecutionReport, JvmBytes, JvmString, TerminationReason,
};
use crate::release_registry::{
    HIGHEST_REGISTERED_MAJOR, MINIMUM_MAJOR, PREVIEW_MARKER, ReleaseLookup, ReleaseRegistration,
    feature_registry,
};
use noak::reader::attributes::{ArrayType, Code, RawInstruction};
use noak::reader::{Attribute, Class, Method};
use serde::{Deserialize, Serialize};

const ATTRIBUTE_HEADER_LENGTH: usize = 6;

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct AttributeShell {
    pub name: JvmString,
    pub span: ByteSpan,
    pub content_span: ByteSpan,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct MemberHeader {
    pub name: JvmString,
    pub descriptor: JvmString,
    pub access_flags: u16,
    pub attributes: Vec<AttributeShell>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub(crate) struct MinimalHeaderFacts {
    pub major_version: u16,
    pub minor_version: u16,
    pub access_flags: u16,
    pub this_class: JvmString,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct ClassHeader {
    pub major_version: u16,
    pub minor_version: u16,
    pub access_flags: u16,
    pub this_class: JvmString,
    pub super_class: Option<JvmString>,
    pub interfaces: Vec<JvmString>,
    pub fields: Vec<MemberHeader>,
    pub methods: Vec<MemberHeader>,
    pub attributes: Vec<AttributeShell>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum InspectionMode {
    Strict,
    Forensic,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct ClassfileVersion {
    pub major: u16,
    pub minor: u16,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum VersionRuleStatus {
    Valid,
    InvalidMajor,
    InvalidModernMinor,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum VersionDialectSupport {
    Supported,
    StructuralProbeOnly,
    UnsupportedPreview,
    FutureRelease,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum DialectValidationScope {
    VersionOnly,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Java8RuntimeCompatibility {
    Accepted,
    Rejected,
}

/// Whether a declared verification of this artifact really ran, and what it concluded.
///
/// `NotPerformed` is the only variant P0, P1 and P2 produce, and it stays the honest state of
/// every header, bytecode and multi-release report they assemble: a structural read, a dialect
/// validation or an IR phase is not a verification, so the plane MUST NOT be read as "the
/// artifact is legal" or "the input can be linked or run".
///
/// `Performed` and `Failed` are the vocabulary later phases state when they really run one: the
/// recovery layer's controlled check (P3 3.3's recompile and behavior comparison) verifies the
/// artifact it produced in a declared environment, and either that check accepted it or it did
/// not. Both variants are evidence about the sample, compiler and environment they ran under,
/// never a general claim over other inputs.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum VerificationStatus {
    NotPerformed,
    Performed,
    Failed,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum HeaderStructuralRead {
    Complete,
}

/// Whether the version's `minor_version` carries the preview marker (JVMS 4.1).
///
/// The marker is a fact about the *format*: from major 56 on, minor 65535 marks a preview class
/// file. It says nothing about whether this build validates a preview dialect — that is
/// [`VersionCapability::version_dialect_support`], and the two stay separate statements so that a
/// marker this build does not support can never read as support.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PreviewMarker {
    Absent,
    Present,
}

/// The output level an artifact's modern facts are asked to be consumed at.
///
/// A level is a *request*, not a property of the artifact: a class compiled at major 61 is asked to
/// be consumed by a Java 8 toolchain, and the answer is stated over the facts that class really
/// carries — never over the compiler that produced it and never over its own `major_version`.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OutputLevel {
    /// Java 8: the level the recovery layer this reader feeds targets.
    Java8,
}

/// One modern construct a target output level either represents or cannot.
///
/// The three are exactly the constructs P4 design decision 5 names for the Java 8 question: record
/// components, sealed permitted subclasses and a `StringConcatFactory` `invokedynamic` site. Module,
/// nestmate and constant-dynamic facts are Java 9+ structures too, and this vocabulary deliberately
/// makes no claim about them: a feature is listed here only because the pass that reports it decides
/// the output-level answer for it, and inventing a conflict for a construct no pass evaluates would
/// report a verdict nobody produced.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ModernFeature {
    /// The `Record` attribute and its components (JVMS 4.7.30).
    RecordComponents,
    /// The `PermittedSubclasses` attribute of a sealed class (JVMS 4.7.31).
    PermittedSubclasses,
    /// A `java.lang.invoke.StringConcatFactory` `invokedynamic` site.
    StringConcat,
}

/// Where one modern fact was read from, kept so the fact's **modern origin** survives an
/// output-level conflict (P4 design decision 5): the fallback answer names the bytes the fact came
/// from, and those bytes are never replaced by an equivalent-looking Java 8 construct.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum ModernOrigin {
    /// A class-level `attribute_info`: the raw name, the `attribute_name_index` that spells it, the
    /// class-file range of the whole entry and the range of its content.
    ClassAttribute {
        name: JvmBytes,
        name_index: u16,
        span: ByteSpan,
        content_span: ByteSpan,
    },
    /// The constant-pool entry the construct lives in, by 1-based index, with its own span.
    ConstantPoolEntry { index: u16, span: ByteSpan },
}

/// One modern fact a target output level cannot represent.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct OutputLevelConflict {
    pub feature: ModernFeature,
    pub level: OutputLevel,
    /// The lowest `major_version` whose release defines the construct, taken from the release-bound
    /// registry rule the fact was read under.
    pub since: u16,
    /// The JVMS section that rule was read from.
    pub source: String,
    /// The bytes the fact came from. The fact itself is still published by the pass that read it:
    /// the conflict is reported, not resolved by rewriting the construct.
    pub origin: ModernOrigin,
}

/// Whether an output-level evaluation ran over this artifact, and what it concluded.
///
/// `NotEvaluated` is the only variant the **header** plane produces: classifying a version and
/// reading a structure is not a statement about what an output level can represent. `Representable`
/// and `Conflict` are produced by the pass that really evaluates the questions over the modern
/// facts ([`crate::modern::modern_facts`], P4 1.2), and `Conflict` is the shape design decision 5
/// asks for: the Java 8 output level returns the conflict **and** keeps each conflicting fact as a
/// fallback that still names its modern origin, instead of hiding a syntax transformation behind an
/// equivalent-looking downgrade.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OutputLevelStatus {
    NotEvaluated,
    /// The evaluation ran over the artifact's modern facts and every one of them has an equivalent
    /// at this level.
    Representable {
        level: OutputLevel,
    },
    /// The evaluation ran and at least one modern fact has no equivalent at this level. Each
    /// conflict names the fact's origin, the release that requires the construct and the JVMS
    /// section that release rule was read from.
    Conflict {
        level: OutputLevel,
        conflicts: Vec<OutputLevelConflict>,
    },
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct VersionCapability {
    pub version: ClassfileVersion,
    pub version_rule: VersionRuleStatus,
    /// The dialect support this build declares, read from the release-bound registry: `Supported`
    /// only where the registry validates the dialect, `StructuralProbeOnly` where the structure is
    /// read without dialect validation, and the preview/future states where the registry holds no
    /// validating record. The registry's tag, attribute, flag and opcode constraints are stated by
    /// [`crate::release_registry`] and are not applied here yet, which is what
    /// `dialect_validation_scope` records.
    pub version_dialect_support: VersionDialectSupport,
    pub dialect_validation_scope: DialectValidationScope,
    pub java8_runtime: Java8RuntimeCompatibility,
    /// Whether the input carries the release's preview marker.
    pub preview_marker: PreviewMarker,
    /// Whether the registry holds a record for the input's major.
    ///
    /// `UnregisteredFutureRelease` and `UnregisteredBelowMinimum` are the conservative path: the
    /// registry claims nothing about such a version's constraints, so no capability of a registered
    /// release may be read into it.
    pub release_registration: ReleaseRegistration,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct HeaderInspection {
    pub header: ClassHeader,
    /// Parse plane: how much of the structure this read established. `Complete` says the header was
    /// read to the end of its schema — nothing about the dialect, and nothing about verification.
    pub structural_read: HeaderStructuralRead,
    /// Dialect-validation plane: the version rule, and the dialect support the registry declares for
    /// the release.
    pub version_capability: VersionCapability,
    /// Verification plane: whether a verifier really ran, and what it concluded. This layer never
    /// runs one, so it states `NotPerformed` whatever the dialect plane says.
    pub verification: VerificationStatus,
    /// Output-level plane: whether an output-level evaluation ran. This layer never runs one.
    pub output_level: OutputLevelStatus,
    pub diagnostics: Vec<Diagnostic>,
}

#[derive(Clone, Debug, Eq, PartialEq, Hash, Serialize, Deserialize)]
pub struct MethodSelector {
    pub name: JvmBytes,
    pub descriptor: JvmBytes,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct InstructionFact {
    pub bci: u32,
    pub opcode: u8,
    pub width: u32,
    pub span: ByteSpan,
    pub operands_span: ByteSpan,
    pub constant_pool_index: Option<u16>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct ExceptionHandlerFact {
    pub ordinal: u32,
    pub start_bci: u32,
    pub end_bci: u32,
    pub handler_bci: u32,
    pub catch_type_index: Option<u16>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum BytecodeStopPhase {
    ExceptionHandlers,
    Instructions,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(tag = "phase", rename_all = "snake_case")]
pub enum BytecodeStop {
    ExceptionHandlers {
        ordinal: u32,
        class_offset: u64,
        code: String,
    },
    Instructions {
        bci: u32,
        class_offset: u64,
        code: String,
    },
}

impl BytecodeStop {
    pub const fn phase(&self) -> BytecodeStopPhase {
        match self {
            Self::ExceptionHandlers { .. } => BytecodeStopPhase::ExceptionHandlers,
            Self::Instructions { .. } => BytecodeStopPhase::Instructions,
        }
    }
}

/// Coverage of one body decode, in the reader's own BCI and handler-ordinal coordinates.
///
/// One body has one coverage plane, whichever reader path produced it: the public
/// [`BytecodeInspection`] and the crate-private [`MethodCodeFacts`] call this same mapping, so
/// an analysis caller and a bytecode caller cannot publish two different ranges for the same
/// `Code` attribute. The scanned ranges are the decoded instruction prefix
/// (`method_code_bci`) and the handler records that were read
/// (`exception_handler_ordinal`), the skipped ranges are the rest of each, and the state is
/// `CompleteWithinSchema` exactly when the decode ran to the end of the body.
///
/// Handlers are decoded before instructions, so a handler-phase stop leaves
/// `handlers_returned < handlers_total` while the instruction prefix is empty, and an
/// instruction-phase stop leaves the handler list complete.
pub fn method_code_coverage(
    code_length: u64,
    instructions: &[InstructionFact],
    handlers_returned: usize,
    handlers_total: u32,
    execution: &ExecutionReport,
    stopped_at: Option<&BytecodeStop>,
) -> Result<Coverage> {
    let prefix_end = instructions.last().map_or(Ok(0), |fact| {
        u64::from(fact.bci)
            .checked_add(u64::from(fact.width))
            .ok_or_else(|| {
                Error::invalid_input("classfile_coverage_overflow", "instruction prefix overflow")
            })
    })?;
    if prefix_end > code_length {
        return Err(Error::invalid_input(
            "classfile_coverage_out_of_bounds",
            "instruction prefix exceeds code length",
        ));
    }
    let handlers_returned = u64::try_from(handlers_returned).map_err(|_| {
        Error::invalid_input(
            "classfile_coverage_overflow",
            "handler count does not fit u64",
        )
    })?;
    let handlers_total = u64::from(handlers_total);
    if handlers_returned > handlers_total {
        return Err(Error::invalid_input(
            "classfile_coverage_out_of_bounds",
            "returned handler count exceeds declared count",
        ));
    }
    let complete = matches!(execution, ExecutionReport::Complete { .. });
    let handlers_complete = complete
        || !matches!(
            stopped_at.map(BytecodeStop::phase),
            Some(BytecodeStopPhase::ExceptionHandlers)
        );
    let mut scanned = vec![CoverageRange {
        label: "method_code_bci".into(),
        start: 0,
        end: prefix_end,
    }];
    scanned.push(CoverageRange {
        label: "exception_handler_ordinal".into(),
        start: 0,
        end: handlers_returned,
    });
    let mut skipped = Vec::new();
    if prefix_end < code_length {
        skipped.push(CoverageRange {
            label: "method_code_bci".into(),
            start: prefix_end,
            end: code_length,
        });
    }
    if !handlers_complete && handlers_returned < handlers_total {
        skipped.push(CoverageRange {
            label: "exception_handler_ordinal".into(),
            start: handlers_returned,
            end: handlers_total,
        });
    }
    Ok(Coverage {
        artifact_structural: CoverageDimension {
            state: if complete {
                CoverageState::CompleteWithinSchema
            } else {
                CoverageState::Partial
            },
            scanned,
            skipped,
            uninterpreted_extensions: Vec::new(),
        },
        runtime_resolution: CoverageDimension::not_requested(),
        dynamic_analysis: CoverageDimension::not_requested(),
    })
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct BytecodeInspection {
    pub selector: MethodSelector,
    pub max_stack: u16,
    pub max_locals: u16,
    pub code_span: ByteSpan,
    pub instructions: Vec<InstructionFact>,
    pub exception_handlers: Vec<ExceptionHandlerFact>,
    pub exception_handler_count: u32,
    pub execution: ExecutionReport,
    pub diagnostics: Vec<Diagnostic>,
    pub verification: VerificationStatus,
    pub stopped_at: Option<BytecodeStop>,
}

pub(crate) fn probe_minimal_header(
    bytes: &[u8],
    budget: &mut Budget,
) -> Result<MinimalHeaderFacts> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::ClassBytes, to_u64(bytes.len())?)?;
    validate_constant_pool_slots(bytes, budget)?;
    let class = Class::new(bytes).map_err(map_decode_error)?;
    if class.buffer_size() != bytes.len() {
        return Err(Error::invalid_input(
            "classfile_trailing_bytes",
            "class structure has trailing bytes",
        ));
    }
    let pool = class.pool();
    let this_class = jvm_string_mstr(
        pool.retrieve(class.this_class())
            .map_err(map_decode_error)?
            .name,
    )?;
    Ok(MinimalHeaderFacts {
        major_version: class.version().major,
        minor_version: class.version().minor,
        access_flags: class.access_flags().bits(),
        this_class,
    })
}

/// Reads declaration-level structure and applies the version rule of the release-bound registry.
/// Attribute content, attribute and flag legality, instructions, and JVM verification are never
/// performed here: the registry states those constraints, and the passes that read the facts apply
/// them.
///
/// # The facts cache (P5 2.3)
///
/// Under a budget that carries one, this entry consults the cache under the class content digest and
/// the **parse policy** — `mode` is part of the key, because a `Strict` read refuses a release the
/// registry does not validate while a `Forensic` read of the same bytes answers with the dialect. A
/// strict request is therefore never served a forensic entry that a strict read would have refused,
/// and vice versa. A hit bills the diagnostics it publishes exactly as the direct read bills them
/// ([`CountedBudgetDimension::ResultItems`]), and a refusal writes nothing: the gate is applied by
/// the direct read, so a version this build refuses is never stored as an answer.
pub fn inspect_header(
    bytes: &[u8],
    budget: &mut Budget,
    mode: InspectionMode,
) -> Result<HeaderInspection> {
    let Some(cache) = budget.facts_cache().cloned() else {
        return read_header_inspection(bytes, budget, mode);
    };
    if let Some(inspection) = cache.header(bytes, mode, budget)? {
        // The published diagnostics are the same diagnostics, and publishing them is billed
        // wherever they come from.
        budget.charge(
            CountedBudgetDimension::ResultItems,
            to_u64(inspection.diagnostics.len())?,
        )?;
        return Ok(inspection);
    }
    let inspection = read_header_inspection(bytes, budget, mode)?;
    cache.remember_header(bytes, mode, &inspection);
    Ok(inspection)
}

/// The direct read of [`inspect_header`]: the structure, the version gate under `mode`, and the
/// diagnostics the gate's classification produces.
fn read_header_inspection(
    bytes: &[u8],
    budget: &mut Budget,
    mode: InspectionMode,
) -> Result<HeaderInspection> {
    let header = inspect_header_structure(bytes, budget)?;
    let version_capability = classify_version(header.major_version, header.minor_version);
    if mode == InspectionMode::Strict {
        enforce_strict_version_gate(&version_capability)?;
    }
    let diagnostics = version_diagnostics(&version_capability);
    budget.charge(
        CountedBudgetDimension::ResultItems,
        to_u64(diagnostics.len())?,
    )?;
    Ok(HeaderInspection {
        header,
        structural_read: HeaderStructuralRead::Complete,
        version_capability,
        verification: VerificationStatus::NotPerformed,
        output_level: OutputLevelStatus::NotEvaluated,
        diagnostics,
    })
}

/// Which member table a stopped read stopped in.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MemberTablePhase {
    Fields,
    Methods,
}

/// Where a member-table read stopped, and what stopped it.
///
/// The record is a *fact about the read*, not a verdict on the class: `index` is the position of
/// the first record the read could not finish, counted from 0 inside its own table, and it is
/// exactly the point from which nothing after it is stated. `class_offset` is the class-file
/// position the failing read was attempted at, so the stop is locatable in the bytes; `code` is
/// the reader's own failure code for it and `message` its message.
///
/// A stop does not say the member is illegal, that the class is unusable or that the rest of the
/// table is damaged: it says this read ended here, and the prefix before it is what the read did
/// establish.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct MemberTableStop {
    pub phase: MemberTablePhase,
    pub index: u64,
    pub class_offset: u64,
    pub code: String,
    pub message: String,
}

/// One class's own declaration and the member tables read under it, as far as they could be read.
///
/// The read covers the class's fixed structure up to the end of the method table: its
/// `this_class`, access flags, superclass and interfaces, then every field and method record before
/// the stop, each with the attribute **shells** its declaration carries. It deliberately does not
/// read the class attribute table that follows the member tables, decode any attribute content
/// (a `Code` attribute is a shell here, never a body), run the version gate or build any analysis
/// fact — [`class_facts`] and [`inspect_header`] are the whole-structure reads, and this one says
/// only what its own doc states.
///
/// This is the one read that survives a damaged member table: noak's decoder establishes the whole
/// class structure at `Class::new`, so a single undecodable member record currently fails every
/// header read of that class; this walk reads the declaration and the records one by one, publishes
/// the prefix before the first record it cannot finish and records that stop in
/// [`ClassMemberFacts::stopped_at`]. Damage outside the member tables — a structure that does not
/// begin with the class-file magic, a constant pool that cannot be measured, a truncated fixed
/// part — is still an `Err`, exactly as in the whole-structure reads, because a class whose own
/// declaration cannot be established has no prefix to publish.
///
/// What it does **not** prove: that the class is legal, loadable, linkable or verified; that its
/// version is one this build validates; that the member records after a stop are readable; or that
/// a `Code` shell's content decodes. A refusal of the request itself — an exceeded budget, a
/// cancellation — is an `Err` and never a stop, because that is the request ending rather than the
/// class ending.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ClassMemberFacts {
    pub access_flags: u16,
    pub this_class: JvmString,
    pub super_class: Option<JvmString>,
    pub interfaces: Vec<JvmString>,
    /// How many field records the class file's own `fields_count` declares.
    ///
    /// It is the table's declared length, not the number of records [`ClassMemberFacts::fields`]
    /// holds: when the read stopped, the two differ by exactly the records it never reached.
    pub field_count: u64,
    pub fields: Vec<MemberHeader>,
    /// How many method records the class file's own `methods_count` declares; see
    /// [`ClassMemberFacts::field_count`].
    pub method_count: u64,
    pub methods: Vec<MemberHeader>,
    /// Class-level attribute shells, in physical order, when both member tables were reached.
    /// Content remains lazy; an empty vector after a member-table stop means the class tail was not
    /// reached, not that the class declares no attributes.
    pub attributes: Vec<AttributeShell>,
    /// `None` exactly when both member tables were read to their declared end.
    pub stopped_at: Option<MemberTableStop>,
}

/// The class-file magic every class structure begins with.
const CLASS_FILE_MAGIC: [u8; 4] = 0xcafebabe_u32.to_be_bytes();

/// Reads one class's declaration and member tables, stopping where a member record stops.
///
/// See [`ClassMemberFacts`] for what the read establishes, what it deliberately leaves out and what
/// a stop means. The member listing is the consumer: it needs one bounded read that yields a class
/// declaration and its members without reading a body and without failing the whole class when one
/// member record does not decode.
pub fn class_member_facts(bytes: &[u8], budget: &mut Budget) -> Result<ClassMemberFacts> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::ClassBytes, to_u64(bytes.len())?)?;
    validate_constant_pool_slots(bytes, budget)?;
    if bytes.len() < 10 || !bytes.starts_with(&CLASS_FILE_MAGIC) {
        return Err(Error::invalid_input(
            "classfile_decode",
            "class structure does not begin with the class-file magic, so no declaration or member table can be read",
        ));
    }
    let layout = measure_constant_pool(bytes, budget)?;
    if layout.is_empty() {
        return Err(Error::invalid_input(
            "classfile_decode",
            "class structure declares no constant-pool slot, so no declaration or member table can be read",
        ));
    }
    let mut offset = usize::try_from(span_end(&layout[layout.len() - 1].span)?)
        .map_err(|_| class_member_structure_overflow())?;

    let access_flags = read_u16(bytes, offset).map_err(class_member_structure_error)?;
    offset = offset_plus(offset, 2)?;
    let this_class_index = read_u16(bytes, offset).map_err(class_member_structure_error)?;
    offset = offset_plus(offset, 2)?;
    let this_class = jvm_string_from_raw(&class_name(bytes, &layout, this_class_index)?.0)?;
    let super_class_index = read_u16(bytes, offset).map_err(class_member_structure_error)?;
    offset = offset_plus(offset, 2)?;
    let super_class = if super_class_index == 0 {
        None
    } else {
        Some(jvm_string_from_raw(
            &class_name(bytes, &layout, super_class_index)?.0,
        )?)
    };

    let interface_count = read_u16(bytes, offset).map_err(class_member_structure_error)?;
    offset = offset_plus(offset, 2)?;
    let mut interfaces = Vec::new();
    for _ in 0..interface_count {
        budget.poll()?;
        let index = read_u16(bytes, offset).map_err(class_member_structure_error)?;
        offset = offset_plus(offset, 2)?;
        let name = class_name(bytes, &layout, index)?;
        charge_item(budget)?;
        interfaces.push(jvm_string_from_raw(&name.0)?);
    }

    let field_count = read_u16(bytes, offset).map_err(class_member_structure_error)?;
    offset = offset_plus(offset, 2)?;
    let mut fields = Vec::new();
    let fields_stop = read_member_records(
        bytes,
        &layout,
        field_count,
        MemberTablePhase::Fields,
        budget,
        &mut offset,
        &mut fields,
    )?;
    let method_count = if fields_stop.is_some() {
        // The walk stopped before the method table's own count: the count is unread, so the table
        // declares nothing this read can state and nothing is skipped on its behalf.
        0
    } else {
        let declared = read_u16(bytes, offset).map_err(class_member_structure_error)?;
        offset = offset_plus(offset, 2)?;
        declared
    };
    let mut methods = Vec::new();
    let stopped_at = match fields_stop {
        Some(stop) => Some(stop),
        None => read_member_records(
            bytes,
            &layout,
            method_count,
            MemberTablePhase::Methods,
            budget,
            &mut offset,
            &mut methods,
        )?,
    };
    let attributes = if stopped_at.is_some() {
        Vec::new()
    } else {
        read_attribute_shell_records(bytes, &layout, budget, &mut offset)?
    };

    Ok(ClassMemberFacts {
        access_flags,
        this_class,
        super_class,
        interfaces,
        field_count: u64::from(field_count),
        fields,
        method_count: u64::from(method_count),
        methods,
        attributes,
        stopped_at,
    })
}

/// Reads one member table record by record, stopping at the first record that does not read.
///
/// `Ok(None)` is a table read to its declared end; `Ok(Some(stop))` names the record that ended the
/// read, with the records before it left in `out`. A refusal of the request itself — an exceeded
/// budget, a cancellation — is an `Err`: it is the request ending, not damage in the class file,
/// and the caller's own stop handling owns it.
fn read_member_records(
    bytes: &[u8],
    layout: &[CpSlotLayout],
    count: u16,
    phase: MemberTablePhase,
    budget: &mut Budget,
    offset: &mut usize,
    out: &mut Vec<MemberHeader>,
) -> Result<Option<MemberTableStop>> {
    for index in 0..u64::from(count) {
        budget.poll()?;
        // The position this record's read starts at: a failure inside it is located here, which is
        // the last position this walk can prove.
        let start = to_u64(*offset)?;
        match read_member_record(bytes, layout, budget, offset) {
            Ok(header) => {
                charge_item(budget)?;
                out.push(header);
            }
            Err(error) if is_class_structure_damage(&error) => {
                return Ok(Some(MemberTableStop {
                    phase,
                    index,
                    class_offset: start,
                    code: error_code(&error),
                    message: error.to_string(),
                }));
            }
            Err(error) => return Err(error),
        }
    }
    Ok(None)
}

/// Reads one member record: its flags, its raw name and descriptor, and the shells of its attributes.
///
/// The attribute shells are what [`inspect_header_structure`] publishes for a member — name, shell
/// span and content span, charged as `AttributeBytes` and one result item each — and no attribute
/// content is decoded, so a `Code` attribute costs its declaration and never its body.
fn read_member_record(
    bytes: &[u8],
    layout: &[CpSlotLayout],
    budget: &mut Budget,
    offset: &mut usize,
) -> Result<MemberHeader> {
    let access_flags = read_u16(bytes, *offset)?;
    *offset = offset_plus(*offset, 2)?;
    let name_index = read_u16(bytes, *offset)?;
    *offset = offset_plus(*offset, 2)?;
    let descriptor_index = read_u16(bytes, *offset)?;
    *offset = offset_plus(*offset, 2)?;
    let name = jvm_string_from_raw(&utf8_index(bytes, layout, name_index)?.0)?;
    let descriptor = jvm_string_from_raw(&utf8_index(bytes, layout, descriptor_index)?.0)?;
    let attributes = read_attribute_shell_records(bytes, layout, budget, offset)?;

    Ok(MemberHeader {
        name,
        descriptor,
        access_flags,
        attributes,
    })
}

fn read_attribute_shell_records(
    bytes: &[u8],
    layout: &[CpSlotLayout],
    budget: &mut Budget,
    offset: &mut usize,
) -> Result<Vec<AttributeShell>> {
    let attribute_count = read_u16(bytes, *offset)?;
    *offset = offset_plus(*offset, 2)?;
    let mut attributes = Vec::with_capacity(usize::from(attribute_count));
    for _ in 0..attribute_count {
        budget.poll()?;
        let attribute_name_index = read_u16(bytes, *offset)?;
        let length = read_u32(bytes, offset_plus(*offset, 2)?)?;
        let shell_start = *offset;
        let content_start = offset_plus(*offset, ATTRIBUTE_HEADER_LENGTH)?;
        let content_length =
            usize::try_from(length).map_err(|_| class_member_structure_overflow())?;
        let content_span = checked_span(bytes, to_u64(content_start)?, to_u64(content_length)?)?;
        let span_length = u64::from(ATTRIBUTE_HEADER_LENGTH as u16)
            .checked_add(content_span.length)
            .ok_or_else(|| span_overflow("class attribute shell"))?;
        let span = checked_span(bytes, to_u64(shell_start)?, span_length)?;
        *offset = offset_plus(content_start, content_length)?;
        budget.charge(CountedBudgetDimension::AttributeBytes, span_length)?;
        charge_item(budget)?;
        attributes.push(AttributeShell {
            name: jvm_string_from_raw(&utf8_index(bytes, layout, attribute_name_index)?.0)?,
            span,
            content_span,
        });
    }
    Ok(attributes)
}

/// Whether one failure is damage in the class structure rather than the request ending.
///
/// A damaged record is what a member-table read publishes as a prefix plus a stop; an exceeded
/// budget, a cancellation and an I/O failure are the request ending and travel on as errors.
///
/// The predicate is crate-visible because the prepared read ([`crate::prepared::PreparedClass`])
/// decides with it whether a failed structure read may be answered by the tolerant member walk at
/// all: a request-ending failure must end the read instead of starting a second walk after a stop.
pub(crate) fn is_class_structure_damage(error: &Error) -> bool {
    match error {
        Error::InvalidInput { .. } | Error::Unsupported { .. } => true,
        Error::BudgetExceeded { .. } | Error::Cancelled { .. } | Error::Io { .. } => false,
    }
}

/// The stable code of one failure, using the code the error already carries.
///
/// The same mapping the artifact tree, the query scan and the resolver use, so one failure has one
/// code wherever this engine reports it. Only the two damaged-structure arms are reachable from a
/// member-table stop — a refused charge, a cancellation and an I/O failure travel on as errors — but
/// the mapping is the engine's whole one so a stop added later cannot pick a different code.
fn error_code(error: &Error) -> String {
    match error {
        Error::InvalidInput { code, .. } | Error::Unsupported { code, .. } => code.clone(),
        Error::BudgetExceeded { dimension, .. } => {
            format!(
                "budget_exceeded_{}",
                crate::artifact::budget_dimension_code(*dimension)
            )
        }
        Error::Cancelled { .. } => "cancelled".to_owned(),
        Error::Io { operation, .. } => operation.clone(),
    }
}

/// One Modified-UTF-8 payload as this layer spells JVM strings, without a validated wrapper.
///
/// The walk is byte-for-byte the one [`jvm_string_mstr`] performs on noak's own validated value:
/// every sequence takes the width its first byte states, each sequence becomes one UTF-16 code
/// unit in order, and a surrogate pair therefore arrives as the two units it was written as. The
/// difference is only that these bytes come from the raw member walk rather than from a decoder
/// that already checked them, so a sequence that leaves the payload is a structured error instead
/// of a panic. The value is a **spelling** of the bytes, not a claim that they are legal
/// Modified UTF-8; the raw bytes stay the identity.
fn jvm_string_from_raw(raw: &[u8]) -> Result<JvmString> {
    let mut utf16 = Vec::new();
    let mut offset = 0usize;
    while offset < raw.len() {
        let first = raw[offset];
        let width = if first < 0x80 {
            1usize
        } else if first & 0xe0 == 0xc0 {
            2usize
        } else {
            3usize
        };
        let unit = match width {
            1 => u16::from(first),
            2 => {
                let second = *raw
                    .get(offset + 1)
                    .ok_or_else(class_member_utf8_truncated)?;
                (u16::from(first & 0x1f) << 6) | u16::from(second & 0x3f)
            }
            _ => {
                let second = *raw
                    .get(offset + 1)
                    .ok_or_else(class_member_utf8_truncated)?;
                let third = *raw
                    .get(offset + 2)
                    .ok_or_else(class_member_utf8_truncated)?;
                (u16::from(first & 0x0f) << 12)
                    | (u16::from(second & 0x3f) << 6)
                    | u16::from(third & 0x3f)
            }
        };
        utf16.push(unit);
        offset = offset
            .checked_add(width)
            .ok_or_else(class_member_utf8_truncated)?;
    }
    Ok(JvmString::from_parts(raw.to_vec(), utf16))
}

fn class_member_utf8_truncated() -> Error {
    Error::invalid_input(
        "classfile_modified_utf8_truncated",
        "a Modified UTF-8 sequence ends after the payload that holds it",
    )
}

fn class_member_structure_error(error: Error) -> Error {
    match error {
        Error::InvalidInput { code, message } => Error::invalid_input(
            code,
            format!("class-member walk stopped while reading the class structure: {message}"),
        ),
        other => other,
    }
}

fn class_member_structure_overflow() -> Error {
    Error::invalid_input(
        "classfile_span_overflow",
        "class-member walk position or attribute length exceeds this address space",
    )
}

/// Inspects one exact method body using noak's Java 8 instruction cursor.
pub fn inspect_method_bytecode(
    bytes: &[u8],
    selector: MethodSelector,
    budget: &mut Budget,
) -> Result<BytecodeInspection> {
    inspect_method_bytecode_with(bytes, selector, budget, |_| {}, |_| {})
}

/// Every instruction opcode of every method body in one class, one entry per method in declaration
/// order, decoded by the same cursor the bytecode read path uses.
///
/// The fact pass needs the *opcodes* a release gates (`invokedynamic`, `jsr`, `ret` and the reserved
/// opcodes) without publishing a second body report: an instruction fact, its span and the BCI a
/// stop happened at belong to [`inspect_method_bytecode`], which charges the body it reads and says
/// where it stopped. This probe states opcodes and nothing else, so no instruction fact is published
/// twice.
///
/// # Failure and charging
///
/// A body whose structure does not decode states **no** opcode instead of failing the probe — the
/// convention `local_debug_table` already follows — because a body this probe cannot read is no
/// evidence that the release's opcode rules hold in it, and it must not turn a class whose
/// declaration structure read completely into an error. The probe charges `CodeBytes` for every code
/// array it reads, the dimension the read path charges for the same bytes; the class structure and
/// its constant pool are the structure the caller already holds and are charged no second time.
pub(crate) fn method_body_opcodes(bytes: &[u8], budget: &mut Budget) -> Result<Vec<Vec<u8>>> {
    budget.poll()?;
    let Ok(class) = Class::new(bytes) else {
        return Ok(Vec::new());
    };
    let pool = class.pool();
    let mut bodies = Vec::new();
    for method in class.methods() {
        budget.poll()?;
        let Ok(method) = method else { break };
        let mut opcodes = Vec::new();
        'attributes: for attribute in method.attributes() {
            budget.poll()?;
            let Ok(attribute) = attribute else { break };
            let Ok(name) = pool.get(attribute.name()) else {
                break;
            };
            if name.content.as_bytes() != b"Code" {
                continue;
            }
            // The code array is the `Code` content's own slice (JVMS 4.7.3), bounded exactly as the
            // read path bounds it before it decodes the same bytes.
            let content = attribute.content();
            let Ok(code_length) = read_u32(content, 4) else {
                break;
            };
            let Ok(code_length) = usize::try_from(code_length) else {
                break;
            };
            let Some(code) = content.get(8..).and_then(|rest| rest.get(..code_length)) else {
                break;
            };
            let Ok(noak::reader::AttributeContent::Code(decoded)) = attribute.read_content(pool)
            else {
                break;
            };
            budget.charge(CountedBudgetDimension::CodeBytes, to_u64(code.len())?)?;
            for item in decoded.raw_instructions() {
                budget.poll()?;
                let Ok((index, _instruction)) = item else {
                    break 'attributes;
                };
                let Ok(at) = usize::try_from(index.as_u32()) else {
                    break 'attributes;
                };
                let Some(opcode) = code.get(at) else {
                    break 'attributes;
                };
                opcodes.push(*opcode);
            }
        }
        bodies.push(opcodes);
    }
    Ok(bodies)
}

fn inspect_method_bytecode_with(
    bytes: &[u8],
    selector: MethodSelector,
    budget: &mut Budget,
    before_handler: impl FnMut(u32),
    before_instruction: impl FnMut(u32),
) -> Result<BytecodeInspection> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::ClassBytes, to_u64(bytes.len())?)?;
    validate_constant_pool_slots(bytes, budget)?;
    let class = Class::new(bytes).map_err(map_decode_error)?;
    if class.buffer_size() != bytes.len() {
        return Err(Error::invalid_input(
            "classfile_trailing_bytes",
            "class structure has trailing bytes",
        ));
    }
    let capability = classify_version(class.version().major, class.version().minor);
    enforce_strict_version_gate(&capability)?;
    let pool = class.pool();
    let mut matches = Vec::new();
    for method in class.methods() {
        budget.poll()?;
        let method = method.map_err(map_decode_error)?;
        let name = pool
            .get(method.name())
            .map_err(map_decode_error)?
            .content
            .as_bytes();
        let descriptor = pool
            .get(method.descriptor())
            .map_err(map_decode_error)?
            .content
            .as_bytes();
        if name == selector.name.0 && descriptor == selector.descriptor.0 {
            matches.push(method);
        }
    }
    let method = match matches.len() {
        0 => {
            return Err(Error::invalid_input(
                "classfile_method_not_found",
                "no method exactly matched the raw name and descriptor",
            ));
        }
        1 => matches.pop().expect("length checked"),
        _ => {
            return Err(Error::invalid_input(
                "classfile_method_ambiguous",
                "multiple methods exactly matched the raw name and descriptor",
            ));
        }
    };

    let mut code_attributes = Vec::new();
    for attribute in method.attributes() {
        budget.poll()?;
        let attribute = attribute.map_err(map_decode_error)?;
        let name = pool
            .get(attribute.name())
            .map_err(map_decode_error)?
            .content
            .as_bytes();
        if name == b"Code" {
            code_attributes.push(attribute);
        }
    }
    let attribute = match code_attributes.len() {
        0 => {
            return Err(Error::unsupported(
                "classfile_method_has_no_code",
                "selected method has no Code attribute",
            ));
        }
        1 => code_attributes.pop().expect("length checked"),
        _ => {
            return Err(Error::invalid_input(
                "classfile_duplicate_code_attribute",
                "selected method has multiple Code attributes",
            ));
        }
    };
    let content = attribute.content();
    let content_span = span_for_slice(bytes, content)?;
    let shell_length = content_span
        .length
        .checked_add(ATTRIBUTE_HEADER_LENGTH as u64)
        .ok_or_else(|| {
            Error::invalid_input("classfile_span_overflow", "Code shell length overflow")
        })?;
    let shell_start = content_span
        .start
        .checked_sub(ATTRIBUTE_HEADER_LENGTH as u64)
        .ok_or_else(|| {
            Error::invalid_input(
                "classfile_invalid_attribute_span",
                "Code content begins before its shell",
            )
        })?;
    checked_span(bytes, shell_start, shell_length)?;
    budget.charge(CountedBudgetDimension::AttributeBytes, shell_length)?;
    let code_length = read_u32(content, 4)?;
    let code_length_usize = usize::try_from(code_length).map_err(|_| {
        Error::invalid_input(
            "classfile_code_span_overflow",
            "code length does not fit usize",
        )
    })?;
    let code_start_in_content = 8usize;
    let code_end = code_start_in_content
        .checked_add(code_length_usize)
        .ok_or_else(|| {
            Error::invalid_input("classfile_code_span_overflow", "code span overflow")
        })?;
    let code_bytes = content
        .get(code_start_in_content..code_end)
        .ok_or_else(|| {
            Error::invalid_input(
                "classfile_code_out_of_bounds",
                "code array exceeds Code attribute content",
            )
        })?;
    let code_start = content_span
        .start
        .checked_add(code_start_in_content as u64)
        .ok_or_else(|| {
            Error::invalid_input("classfile_code_span_overflow", "code start overflow")
        })?;
    let code_span = checked_span(bytes, code_start, u64::from(code_length))?;
    let decoded = attribute.read_content(pool).map_err(map_decode_error)?;
    let code = match decoded {
        noak::reader::AttributeContent::Code(code) => code,
        _ => unreachable!("raw Code name selected"),
    };
    budget.charge(CountedBudgetDimension::ResultItems, 1)?;
    decode_code(
        selector,
        code,
        code_bytes,
        code_span,
        budget,
        before_handler,
        before_instruction,
    )
}

fn decode_code(
    selector: MethodSelector,
    code: Code<'_>,
    code_bytes: &[u8],
    code_span: ByteSpan,
    budget: &mut Budget,
    mut before_handler: impl FnMut(u32),
    mut before_instruction: impl FnMut(u32),
) -> Result<BytecodeInspection> {
    let exception_handler_count =
        u32::try_from(code.exception_handlers().count()).map_err(|_| {
            Error::invalid_input(
                "classfile_result_overflow",
                "handler count does not fit u32",
            )
        })?;
    let mut handlers = Vec::new();
    for (ordinal, handler) in code.exception_handlers().enumerate() {
        let ordinal = u32::try_from(ordinal).map_err(|_| {
            Error::invalid_input("classfile_result_overflow", "handler ordinal overflow")
        })?;
        before_handler(ordinal);
        if let Err(error) = budget.poll() {
            return terminated_bytecode(
                selector,
                &code,
                code_span,
                Vec::new(),
                handlers,
                BytecodeStopPosition::ExceptionHandler(ordinal),
                error,
                budget,
            );
        }
        if let Err(error) = budget.charge(CountedBudgetDimension::ResultItems, 1) {
            return terminated_bytecode(
                selector,
                &code,
                code_span,
                Vec::new(),
                handlers,
                BytecodeStopPosition::ExceptionHandler(ordinal),
                error,
                budget,
            );
        }
        handlers.push(ExceptionHandlerFact {
            ordinal,
            start_bci: handler.start().as_u32(),
            end_bci: handler.end().as_u32(),
            handler_bci: handler.handler().as_u32(),
            catch_type_index: handler.catch_type().map(|index| index.as_u16()),
        });
    }

    let mut instructions = Vec::new();
    let mut cursor_bci = 0u32;
    let raw = code.raw_instructions();
    for item in raw {
        before_instruction(cursor_bci);
        if let Err(error) = budget.poll() {
            return terminated_bytecode(
                selector,
                &code,
                code_span,
                instructions,
                handlers,
                BytecodeStopPosition::Instruction(cursor_bci),
                error,
                budget,
            );
        }
        let (index, instruction) = match item {
            Ok(value) => value,
            Err(error) => {
                return decode_failed_bytecode(
                    selector,
                    &code,
                    code_span,
                    instructions,
                    handlers,
                    cursor_bci,
                    error,
                    budget,
                );
            }
        };
        if index.as_u32() != cursor_bci {
            return Err(Error::invalid_input(
                "classfile_instruction_cursor_mismatch",
                format!(
                    "noak returned BCI {} but expected {cursor_bci}",
                    index.as_u32()
                ),
            ));
        }
        let start = usize::try_from(cursor_bci).map_err(|_| {
            Error::invalid_input("classfile_code_span_overflow", "BCI does not fit usize")
        })?;
        let opcode = *code_bytes.get(start).ok_or_else(|| {
            Error::invalid_input(
                "classfile_instruction_out_of_bounds",
                "instruction opcode is outside code array",
            )
        })?;
        let width = match instruction_width(opcode, cursor_bci, &instruction) {
            Ok(width) => width,
            Err(error @ Error::InvalidInput { .. }) => {
                return adapter_failed_bytecode(
                    selector,
                    &code,
                    code_span,
                    instructions,
                    handlers,
                    cursor_bci,
                    error,
                    budget,
                );
            }
            Err(error) => return Err(error),
        };
        let end = match cursor_bci.checked_add(width) {
            Some(end) => end,
            None => {
                return adapter_failed_bytecode(
                    selector,
                    &code,
                    code_span,
                    instructions,
                    handlers,
                    cursor_bci,
                    Error::invalid_input(
                        "classfile_instruction_width_overflow",
                        "instruction end overflow",
                    ),
                    budget,
                );
            }
        };
        if end
            > u32::try_from(code_bytes.len()).map_err(|_| {
                Error::invalid_input(
                    "classfile_code_span_overflow",
                    "code length does not fit u32",
                )
            })?
        {
            return Err(Error::invalid_input(
                "classfile_instruction_out_of_bounds",
                "instruction exceeds code array",
            ));
        }
        if let Err(error) = budget.check(CountedBudgetDimension::CodeBytes, u64::from(width)) {
            return terminated_bytecode(
                selector,
                &code,
                code_span,
                instructions,
                handlers,
                BytecodeStopPosition::Instruction(cursor_bci),
                error,
                budget,
            );
        }
        if let Err(error) = budget.check(CountedBudgetDimension::ResultItems, 1) {
            return terminated_bytecode(
                selector,
                &code,
                code_span,
                instructions,
                handlers,
                BytecodeStopPosition::Instruction(cursor_bci),
                error,
                budget,
            );
        }
        if let Err(error) = budget.charge(CountedBudgetDimension::CodeBytes, u64::from(width)) {
            return terminated_bytecode(
                selector,
                &code,
                code_span,
                instructions,
                handlers,
                BytecodeStopPosition::Instruction(cursor_bci),
                error,
                budget,
            );
        }
        if let Err(error) = budget.charge(CountedBudgetDimension::ResultItems, 1) {
            return terminated_bytecode(
                selector,
                &code,
                code_span,
                instructions,
                handlers,
                BytecodeStopPosition::Instruction(cursor_bci),
                error,
                budget,
            );
        }
        let span_start = code_span
            .start
            .checked_add(u64::from(cursor_bci))
            .ok_or_else(|| {
                Error::invalid_input("classfile_code_span_overflow", "instruction span overflow")
            })?;
        let end_usize = usize::try_from(end).map_err(|_| {
            Error::invalid_input(
                "classfile_code_span_overflow",
                "instruction end does not fit usize",
            )
        })?;
        let instruction_bytes = code_bytes.get(start..end_usize).ok_or_else(|| {
            Error::invalid_input(
                "classfile_instruction_out_of_bounds",
                "instruction slice exceeds code array",
            )
        })?;
        instructions.push(InstructionFact {
            bci: cursor_bci,
            opcode,
            width,
            span: ByteSpan::new(span_start, u64::from(width)),
            operands_span: ByteSpan::new(span_start + 1, u64::from(width - 1)),
            constant_pool_index: constant_pool_index(opcode, instruction_bytes),
        });
        cursor_bci = end;
    }
    if cursor_bci != code_bytes.len() as u32 {
        return Err(Error::invalid_input(
            "classfile_instruction_cursor_mismatch",
            "instruction cursor did not consume the code array",
        ));
    }

    Ok(BytecodeInspection {
        selector,
        max_stack: code.max_stack(),
        max_locals: code.max_locals(),
        code_span,
        instructions,
        exception_handlers: handlers,
        exception_handler_count,
        execution: ExecutionReport::Complete {
            usage: budget.usage(),
        },
        diagnostics: Vec::new(),
        verification: VerificationStatus::NotPerformed,
        stopped_at: None,
    })
}

fn inspect_header_structure(bytes: &[u8], budget: &mut Budget) -> Result<ClassHeader> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::ClassBytes, to_u64(bytes.len())?)?;
    validate_constant_pool_slots(bytes, budget)?;

    let class = Class::new(bytes).map_err(map_decode_error)?;
    if class.buffer_size() != bytes.len() {
        return Err(Error::invalid_input(
            "classfile_trailing_bytes",
            format!(
                "class structure ended at position {}, but input length is {}",
                class.buffer_size(),
                bytes.len()
            ),
        ));
    }

    let pool = class.pool();
    let this_class = jvm_string_mstr(
        pool.retrieve(class.this_class())
            .map_err(map_decode_error)?
            .name,
    )?;
    let super_class = class
        .super_class()
        .map(|index| {
            let name = pool.retrieve(index).map_err(map_decode_error)?.name;
            jvm_string_mstr(name)
        })
        .transpose()?;

    let mut interfaces = Vec::new();
    for interface in class.interfaces() {
        budget.poll()?;
        let name = pool
            .retrieve(interface.map_err(map_decode_error)?)
            .map_err(map_decode_error)?
            .name;
        charge_item(budget)?;
        interfaces.push(jvm_string_mstr(name)?);
    }

    let mut fields = Vec::new();
    for field in class.fields() {
        budget.poll()?;
        let field = field.map_err(map_decode_error)?;
        let attributes = collect_attributes(bytes, pool, field.attributes(), budget)?;
        charge_item(budget)?;
        fields.push(MemberHeader {
            name: jvm_string(field.name(), pool)?,
            descriptor: jvm_string(field.descriptor(), pool)?,
            access_flags: field.access_flags().bits(),
            attributes,
        });
    }

    let mut methods = Vec::new();
    for method in class.methods() {
        budget.poll()?;
        let method = method.map_err(map_decode_error)?;
        let attributes = collect_attributes(bytes, pool, method.attributes(), budget)?;
        charge_item(budget)?;
        methods.push(MemberHeader {
            name: jvm_string(method.name(), pool)?,
            descriptor: jvm_string(method.descriptor(), pool)?,
            access_flags: method.access_flags().bits(),
            attributes,
        });
    }

    let attributes = collect_attributes(bytes, pool, class.attributes(), budget)?;
    charge_item(budget)?;
    Ok(ClassHeader {
        major_version: class.version().major,
        minor_version: class.version().minor,
        access_flags: class.access_flags().bits(),
        this_class,
        super_class,
        interfaces,
        fields,
        methods,
        attributes,
    })
}

/// Classifies one class-file version from the release-bound registry.
///
/// P0 compared `major` and `minor` against literal ranges here. The rules are the same rules, but
/// they are now read from the registry record of the release the version names, so the version rule,
/// the dialect band, the preview marker and the Java 8 profile all follow the release table instead
/// of a second copy of it:
///
/// - the major floor, the minor rule of modern releases and the preview marker are the registry's
///   own constants and rules (JVMS 4.1), and the minor rule deliberately reaches *above* the
///   registry ceiling — it is a rule of the format, not a capability of a recorded release;
/// - the dialect support and the Java 8 profile verdict are the record's, and a major the registry
///   does not hold makes no claim: a later release states [`VersionDialectSupport::FutureRelease`],
///   a major below the format's minimum keeps the structural-probe band it always had;
/// - preview support is decided by the record's preview rule, never by the marker alone, so a
///   preview class file this build does not validate reports `UnsupportedPreview` while its
///   `preview_marker` stays `Present`.
fn classify_version(major: u16, minor: u16) -> VersionCapability {
    let registry = feature_registry();
    let release = registry.release(major);
    let version_rule = if major < MINIMUM_MAJOR {
        VersionRuleStatus::InvalidMajor
    } else if major >= registry.modern_minor_since() && minor != 0 && minor != PREVIEW_MARKER {
        VersionRuleStatus::InvalidModernMinor
    } else {
        VersionRuleStatus::Valid
    };
    let preview_marker = if major >= registry.modern_minor_since() && minor == PREVIEW_MARKER {
        PreviewMarker::Present
    } else {
        PreviewMarker::Absent
    };
    let version_dialect_support = match release {
        ReleaseLookup::Registered(record) => match (preview_marker, record.preview()) {
            (PreviewMarker::Present, Some(preview)) => preview.dialect_support,
            _ => record.dialect_support(),
        },
        ReleaseLookup::UnregisteredFutureRelease => VersionDialectSupport::FutureRelease,
        ReleaseLookup::UnregisteredBelowMinimum => VersionDialectSupport::StructuralProbeOnly,
    };
    let java8_runtime = match release {
        ReleaseLookup::Registered(record) => record.java8_runtime(minor),
        ReleaseLookup::UnregisteredFutureRelease | ReleaseLookup::UnregisteredBelowMinimum => {
            Java8RuntimeCompatibility::Rejected
        }
    };
    VersionCapability {
        version: ClassfileVersion { major, minor },
        version_rule,
        version_dialect_support,
        dialect_validation_scope: DialectValidationScope::VersionOnly,
        java8_runtime,
        preview_marker,
        release_registration: release.registration(),
    }
}

/// The version rule of one class-file version, as this reader classifies it, from the two fields
/// alone and without reading the bytes they came from.
///
/// [`inspect_header`] applies the rule to the header it read; a caller that already holds the
/// version fields — a method-analysis request reads the header by identity instead of through
/// 1.2's inspection — asks this function instead of restating the rule, so the two plans cannot
/// drift apart. `major` below 45 is below the minimum the format defines, and a `minor` that is
/// neither `0` nor `65535` contradicts a major of 56 or above (JVMS 4.1). Both numbers and the
/// dialect bands they select are read from [`crate::release_registry`]; the constraints that table
/// holds for tags, attributes, flags and opcodes are queried there rather than restated here.
pub fn version_capability(major: u16, minor: u16) -> VersionCapability {
    classify_version(major, minor)
}

/// The refusal the format's own version rule states for one version, if the version violates it.
///
/// The diagnostic is the very one [`inspect_header`] publishes for the same version — the reader's
/// own code, message and `Error` severity — so a caller that refuses an illegal version states the
/// fact the header plan states instead of inventing a second wording. `None` for a version the rule
/// accepts, whatever dialect support this build has for it: what a version *is* and what this build
/// supports of it are two different statements, and only the first one is a refusal.
pub fn version_rule_diagnostic(capability: &VersionCapability) -> Option<Diagnostic> {
    match capability.version_rule {
        VersionRuleStatus::Valid => None,
        VersionRuleStatus::InvalidMajor => Some(version_diagnostic(
            "classfile_invalid_major_version",
            DiagnosticSeverity::Error,
            format!(
                "classfile major version {} is below the minimum valid major 45",
                capability.version.major
            ),
        )),
        VersionRuleStatus::InvalidModernMinor => Some(version_diagnostic(
            "classfile_invalid_modern_minor_version",
            DiagnosticSeverity::Error,
            format!(
                "classfile version {}.{} requires minor 0 or 65535 for major >= 56",
                capability.version.major, capability.version.minor
            ),
        )),
    }
}

fn version_diagnostics(capability: &VersionCapability) -> Vec<Diagnostic> {
    let mut diagnostics: Vec<Diagnostic> =
        version_rule_diagnostic(capability).into_iter().collect();
    match capability.version_dialect_support {
        VersionDialectSupport::Supported => {}
        VersionDialectSupport::StructuralProbeOnly => diagnostics.push(version_diagnostic(
            "classfile_version_structural_probe_only",
            DiagnosticSeverity::Warning,
            format!(
                "classfile version {}.{} is only structurally inspected; the release registry validates the dialect up to major {}",
                capability.version.major,
                capability.version.minor,
                feature_registry().dialect_validated_ceiling()
            ),
        )),
        VersionDialectSupport::UnsupportedPreview => diagnostics.push(version_diagnostic(
            "classfile_preview_unsupported",
            DiagnosticSeverity::Warning,
            format!(
                "preview classfile version {}.{} is not supported: the registry records the preview marker and this build validates no preview dialect",
                capability.version.major, capability.version.minor
            ),
        )),
        VersionDialectSupport::FutureRelease => diagnostics.push(version_diagnostic(
            "classfile_future_release",
            DiagnosticSeverity::Warning,
            format!(
                "classfile version {}.{} is above the highest release the registry holds (major {})",
                capability.version.major, capability.version.minor, HIGHEST_REGISTERED_MAJOR
            ),
        )),
    }
    if capability.java8_runtime == Java8RuntimeCompatibility::Rejected {
        diagnostics.push(version_diagnostic(
            "classfile_java8_runtime_rejected",
            DiagnosticSeverity::Warning,
            format!(
                "classfile version {}.{} is not accepted by the Java 8 runtime profile",
                capability.version.major, capability.version.minor
            ),
        ));
    }
    diagnostics
}

fn version_diagnostic(code: &str, severity: DiagnosticSeverity, message: String) -> Diagnostic {
    Diagnostic {
        code: code.to_owned(),
        severity,
        message,
        provenance: None,
    }
}

fn enforce_strict_version_gate(capability: &VersionCapability) -> Result<()> {
    match capability.version_rule {
        VersionRuleStatus::InvalidMajor => {
            return Err(Error::invalid_input(
                "classfile_invalid_major_version",
                format!(
                    "classfile major version {} is below the minimum valid major 45",
                    capability.version.major
                ),
            ));
        }
        VersionRuleStatus::InvalidModernMinor => {
            return Err(Error::invalid_input(
                "classfile_invalid_modern_minor_version",
                format!(
                    "classfile version {}.{} requires minor 0 or 65535 for major >= 56",
                    capability.version.major, capability.version.minor
                ),
            ));
        }
        VersionRuleStatus::Valid => {}
    }
    match capability.version_dialect_support {
        VersionDialectSupport::Supported => {}
        VersionDialectSupport::StructuralProbeOnly => {
            return Err(Error::unsupported(
                "classfile_version_structural_probe_only",
                format!(
                    "strict header inspection requires a dialect-validated release; the registry validates the dialect up to major {}",
                    feature_registry().dialect_validated_ceiling()
                ),
            ));
        }
        VersionDialectSupport::UnsupportedPreview => {
            return Err(Error::unsupported(
                "classfile_preview_unsupported",
                "strict header inspection validates no preview dialect",
            ));
        }
        VersionDialectSupport::FutureRelease => {
            return Err(Error::unsupported(
                "classfile_future_release",
                format!(
                    "strict header inspection does not support releases above the registry's highest registered release (major {})",
                    HIGHEST_REGISTERED_MAJOR
                ),
            ));
        }
    }
    if capability.java8_runtime == Java8RuntimeCompatibility::Rejected {
        return Err(Error::unsupported(
            "classfile_java8_runtime_rejected",
            "strict header inspection requires Java 8 runtime profile acceptance",
        ));
    }
    Ok(())
}

fn instruction_width(opcode: u8, bci: u32, instruction: &RawInstruction<'_>) -> Result<u32> {
    let width = match opcode {
        0xaa => {
            let RawInstruction::TableSwitch(table) = instruction else {
                return Err(Error::invalid_input(
                    "classfile_instruction_shape_mismatch",
                    "tableswitch shape mismatch",
                ));
            };
            let padding = switch_padding(bci);
            let count = i64::from(table.high())
                .checked_sub(i64::from(table.low()))
                .and_then(|value| value.checked_add(1))
                .filter(|count| *count > 0)
                .ok_or_else(|| {
                    Error::invalid_input(
                        "classfile_instruction_invalid_range",
                        "tableswitch high is less than low",
                    )
                })?;
            let entries = u32::try_from(count).map_err(|_| {
                Error::invalid_input(
                    "classfile_instruction_width_overflow",
                    "tableswitch entry count overflow",
                )
            })?;
            1u32.checked_add(padding)
                .and_then(|v| v.checked_add(12))
                .and_then(|v| entries.checked_mul(4).and_then(|n| v.checked_add(n)))
                .ok_or_else(|| {
                    Error::invalid_input(
                        "classfile_instruction_width_overflow",
                        "tableswitch width overflow",
                    )
                })?
        }
        0xab => {
            let RawInstruction::LookupSwitch(lookup) = instruction else {
                return Err(Error::invalid_input(
                    "classfile_instruction_shape_mismatch",
                    "lookupswitch shape mismatch",
                ));
            };
            let padding = switch_padding(bci);
            let pairs = u32::try_from(lookup.pairs().count()).map_err(|_| {
                Error::invalid_input(
                    "classfile_instruction_width_overflow",
                    "lookupswitch pair count overflow",
                )
            })?;
            1u32.checked_add(padding)
                .and_then(|v| v.checked_add(8))
                .and_then(|v| pairs.checked_mul(8).and_then(|n| v.checked_add(n)))
                .ok_or_else(|| {
                    Error::invalid_input(
                        "classfile_instruction_width_overflow",
                        "lookupswitch width overflow",
                    )
                })?
        }
        0xc4 => match instruction {
            RawInstruction::IIncW { .. } => 6,
            _ => 4,
        },
        0xb9 | 0xba => 5,
        0xc5 => 4,
        0xc8 | 0xc9 => 5,
        0x11
        | 0x13
        | 0x14
        | 0x84
        | 0x99..=0xa8
        | 0xb2..=0xb8
        | 0xbb
        | 0xbd
        | 0xc0
        | 0xc1
        | 0xc6
        | 0xc7 => 3,
        0x10 | 0x12 | 0x15..=0x19 | 0x36..=0x3a | 0xa9 | 0xbc => 2,
        _ => 1,
    };
    Ok(width)
}

fn constant_pool_index(opcode: u8, instruction: &[u8]) -> Option<u16> {
    match opcode {
        0x12 => instruction.get(1).copied().map(u16::from),
        0x13 | 0x14 | 0xb2..=0xb9 | 0xba | 0xbb | 0xbd | 0xc0 | 0xc1 | 0xc5 => {
            Some(u16::from_be_bytes([
                *instruction.get(1)?,
                *instruction.get(2)?,
            ]))
        }
        _ => None,
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum BytecodeStopPosition {
    ExceptionHandler(u32),
    Instruction(u32),
}

fn bytecode_stop(
    code_span: &ByteSpan,
    position: BytecodeStopPosition,
    code: &str,
) -> Result<BytecodeStop> {
    match position {
        BytecodeStopPosition::ExceptionHandler(ordinal) => {
            let table_count_offset =
                code_span
                    .start
                    .checked_add(code_span.length)
                    .ok_or_else(|| {
                        Error::invalid_input(
                            "classfile_code_span_overflow",
                            "exception table count offset overflow",
                        )
                    })?;
            let table_start = table_count_offset.checked_add(2).ok_or_else(|| {
                Error::invalid_input(
                    "classfile_code_span_overflow",
                    "exception table start overflow",
                )
            })?;
            let record_offset = u64::from(ordinal).checked_mul(8).ok_or_else(|| {
                Error::invalid_input(
                    "classfile_code_span_overflow",
                    "exception table record offset overflow",
                )
            })?;
            let class_offset = table_start.checked_add(record_offset).ok_or_else(|| {
                Error::invalid_input(
                    "classfile_code_span_overflow",
                    "exception table record start overflow",
                )
            })?;
            Ok(BytecodeStop::ExceptionHandlers {
                ordinal,
                class_offset,
                code: code.to_owned(),
            })
        }
        BytecodeStopPosition::Instruction(bci) => {
            let class_offset = code_span.start.checked_add(u64::from(bci)).ok_or_else(|| {
                Error::invalid_input(
                    "classfile_code_span_overflow",
                    "instruction stop offset overflow",
                )
            })?;
            Ok(BytecodeStop::Instructions {
                bci,
                class_offset,
                code: code.to_owned(),
            })
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn decode_failed_bytecode(
    selector: MethodSelector,
    code: &Code<'_>,
    code_span: ByteSpan,
    instructions: Vec<InstructionFact>,
    handlers: Vec<ExceptionHandlerFact>,
    bci: u32,
    error: noak::error::DecodeError,
    budget: &Budget,
) -> Result<BytecodeInspection> {
    let stable_code = "classfile_instruction_decode";
    let stopped_at = bytecode_stop(
        &code_span,
        BytecodeStopPosition::Instruction(bci),
        stable_code,
    )?;
    Ok(BytecodeInspection {
        selector,
        max_stack: code.max_stack(),
        max_locals: code.max_locals(),
        code_span,
        instructions,
        exception_handlers: handlers,
        exception_handler_count: u32::try_from(code.exception_handlers().count())
            .expect("Code exception count is bounded by u16"),
        execution: ExecutionReport::Partial {
            reason: TerminationReason::Error {
                code: stable_code.to_owned(),
            },
            usage: budget.usage(),
        },
        diagnostics: vec![version_diagnostic(
            stable_code,
            DiagnosticSeverity::Error,
            format!(
                "noak instruction decode failed: kind={}, context={}, position={}",
                error.kind(),
                error.context(),
                error
                    .position()
                    .map_or_else(|| "unknown".to_owned(), |v| v.to_string())
            ),
        )],
        verification: VerificationStatus::NotPerformed,
        stopped_at: Some(stopped_at),
    })
}

#[allow(clippy::too_many_arguments)]
fn adapter_failed_bytecode(
    selector: MethodSelector,
    code: &Code<'_>,
    code_span: ByteSpan,
    instructions: Vec<InstructionFact>,
    handlers: Vec<ExceptionHandlerFact>,
    bci: u32,
    error: Error,
    budget: &Budget,
) -> Result<BytecodeInspection> {
    let Error::InvalidInput {
        code: stable_code,
        message,
    } = error
    else {
        return Err(error);
    };
    let stopped_at = bytecode_stop(
        &code_span,
        BytecodeStopPosition::Instruction(bci),
        &stable_code,
    )?;
    Ok(BytecodeInspection {
        selector,
        max_stack: code.max_stack(),
        max_locals: code.max_locals(),
        code_span,
        instructions,
        exception_handlers: handlers,
        exception_handler_count: u32::try_from(code.exception_handlers().count())
            .expect("Code exception count is bounded by u16"),
        execution: ExecutionReport::Partial {
            reason: TerminationReason::Error {
                code: stable_code.clone(),
            },
            usage: budget.usage(),
        },
        diagnostics: vec![version_diagnostic(
            &stable_code,
            DiagnosticSeverity::Error,
            message,
        )],
        verification: VerificationStatus::NotPerformed,
        stopped_at: Some(stopped_at),
    })
}

#[allow(clippy::too_many_arguments)]
fn terminated_bytecode(
    selector: MethodSelector,
    code: &Code<'_>,
    code_span: ByteSpan,
    instructions: Vec<InstructionFact>,
    handlers: Vec<ExceptionHandlerFact>,
    position: BytecodeStopPosition,
    error: Error,
    budget: &Budget,
) -> Result<BytecodeInspection> {
    // Termination diagnostics and stopped_at explain an exhausted request and, like artifact
    // enumeration termination metadata, are intentionally not additional result items.
    let (execution, stable_code, severity) = match error {
        Error::Cancelled { .. } => (
            ExecutionReport::Cancelled {
                usage: budget.usage(),
            },
            "classfile_bytecode_cancelled",
            DiagnosticSeverity::Warning,
        ),
        Error::BudgetExceeded { dimension, .. } => (
            ExecutionReport::Partial {
                reason: TerminationReason::BudgetExceeded { dimension },
                usage: budget.usage(),
            },
            "classfile_bytecode_budget_exceeded",
            DiagnosticSeverity::Warning,
        ),
        _ => (
            ExecutionReport::Partial {
                reason: TerminationReason::Error {
                    code: "classfile_bytecode_failed".to_owned(),
                },
                usage: budget.usage(),
            },
            "classfile_bytecode_failed",
            DiagnosticSeverity::Error,
        ),
    };
    let stopped_at = bytecode_stop(&code_span, position, stable_code)?;
    Ok(BytecodeInspection {
        selector,
        max_stack: code.max_stack(),
        max_locals: code.max_locals(),
        code_span,
        instructions,
        exception_handlers: handlers,
        exception_handler_count: u32::try_from(code.exception_handlers().count())
            .expect("Code exception count is bounded by u16"),
        execution,
        diagnostics: vec![version_diagnostic(
            stable_code,
            severity,
            "bytecode inspection stopped before completion".to_owned(),
        )],
        verification: VerificationStatus::NotPerformed,
        stopped_at: Some(stopped_at),
    })
}

/// Whether enumerating attribute shells also bills one `ResultItems` per shell.
///
/// `inspect_header` returns the shells themselves, so they are result items
/// there. The crate-private fact layer returns shells as intermediate facts, so
/// it bills only the bytes it reads.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum AttributeItemBilling {
    PerShell,
    NoResultItems,
}

fn collect_attributes<'a>(
    bytes: &'a [u8],
    pool: &noak::reader::cpool::ConstantPool<'a>,
    attributes: impl IntoIterator<Item = std::result::Result<Attribute<'a>, noak::error::DecodeError>>,
    budget: &mut Budget,
) -> Result<Vec<AttributeShell>> {
    collect_attribute_shells(
        bytes,
        pool,
        attributes,
        budget,
        AttributeItemBilling::PerShell,
    )
}

fn collect_attribute_shells<'a>(
    bytes: &'a [u8],
    pool: &noak::reader::cpool::ConstantPool<'a>,
    attributes: impl IntoIterator<Item = std::result::Result<Attribute<'a>, noak::error::DecodeError>>,
    budget: &mut Budget,
    billing: AttributeItemBilling,
) -> Result<Vec<AttributeShell>> {
    let mut shells = Vec::new();
    for attribute in attributes {
        budget.poll()?;
        let attribute = attribute.map_err(map_decode_error)?;
        let content_span = span_for_slice(bytes, attribute.content())?;
        let shell_start = content_span
            .start
            .checked_sub(ATTRIBUTE_HEADER_LENGTH as u64)
            .ok_or_else(|| {
                Error::invalid_input(
                    "classfile_invalid_attribute_span",
                    "attribute content begins before its header",
                )
            })?;
        let shell_length = content_span
            .length
            .checked_add(ATTRIBUTE_HEADER_LENGTH as u64)
            .ok_or_else(|| {
                Error::invalid_input("classfile_span_overflow", "attribute shell length overflow")
            })?;
        let span = checked_span(bytes, shell_start, shell_length)?;
        budget.charge(CountedBudgetDimension::AttributeBytes, shell_length)?;
        if billing == AttributeItemBilling::PerShell {
            charge_item(budget)?;
        }
        shells.push(AttributeShell {
            name: jvm_string(attribute.name(), pool)?,
            span,
            content_span,
        });
    }
    Ok(shells)
}

fn jvm_string<'a>(
    index: noak::reader::cpool::Index<noak::reader::cpool::Utf8<'a>>,
    pool: &noak::reader::cpool::ConstantPool<'a>,
) -> Result<JvmString> {
    jvm_string_mstr(pool.get(index).map_err(map_decode_error)?.content)
}

fn jvm_string_mstr(value: &noak::MStr) -> Result<JvmString> {
    let raw = value.as_bytes();
    let mut utf16 = Vec::new();
    let mut offset = 0usize;
    while offset < raw.len() {
        let first = raw[offset];
        let (unit, width) = if first < 0x80 {
            (u16::from(first), 1usize)
        } else if first & 0xe0 == 0xc0 {
            let second = raw[offset + 1];
            ((u16::from(first & 0x1f) << 6) | u16::from(second & 0x3f), 2)
        } else {
            let second = raw[offset + 1];
            let third = raw[offset + 2];
            (
                (u16::from(first & 0x0f) << 12)
                    | (u16::from(second & 0x3f) << 6)
                    | u16::from(third & 0x3f),
                3,
            )
        };
        utf16.push(unit);
        offset = offset.checked_add(width).ok_or_else(|| {
            Error::invalid_input("classfile_span_overflow", "Modified UTF-8 offset overflow")
        })?;
    }
    Ok(JvmString::from_parts(raw.to_vec(), utf16))
}

fn span_for_slice(container: &[u8], slice: &[u8]) -> Result<ByteSpan> {
    let start = (slice.as_ptr() as usize)
        .checked_sub(container.as_ptr() as usize)
        .ok_or_else(|| {
            Error::invalid_input(
                "classfile_invalid_attribute_span",
                "attribute content is outside class bytes",
            )
        })?;
    let end = start.checked_add(slice.len()).ok_or_else(|| {
        Error::invalid_input("classfile_span_overflow", "attribute content span overflow")
    })?;
    if end > container.len() {
        return Err(Error::invalid_input(
            "classfile_invalid_attribute_span",
            "attribute content is outside class bytes",
        ));
    }
    Ok(ByteSpan::new(to_u64(start)?, to_u64(slice.len())?))
}

fn checked_span(bytes: &[u8], start: u64, length: u64) -> Result<ByteSpan> {
    let end = start.checked_add(length).ok_or_else(|| {
        Error::invalid_input("classfile_span_overflow", "class-local span overflow")
    })?;
    if end > to_u64(bytes.len())? {
        return Err(Error::invalid_input(
            "classfile_invalid_attribute_span",
            "attribute shell is outside class bytes",
        ));
    }
    Ok(ByteSpan::new(start, length))
}

pub(crate) fn charge_item(budget: &mut Budget) -> Result<()> {
    budget.charge(CountedBudgetDimension::ResultItems, 1)
}

pub(crate) fn to_u64(value: usize) -> Result<u64> {
    u64::try_from(value).map_err(|_| {
        Error::invalid_input("classfile_size_overflow", "classfile size does not fit u64")
    })
}

fn map_decode_error(error: noak::error::DecodeError) -> Error {
    Error::invalid_input(
        "classfile_decode",
        format!(
            "noak decode failed: kind={}, context={}, position={}",
            error.kind(),
            error.context(),
            error
                .position()
                .map_or_else(|| "unknown".to_owned(), |position| position.to_string())
        ),
    )
}

/// noak 0.7.0 accepts a Long/Double in the final declared constant-pool slot.
/// Reject that malformed two-slot entry before relying on noak's pool representation.
fn validate_constant_pool_slots(bytes: &[u8], budget: &Budget) -> Result<()> {
    validate_constant_pool_slots_with(bytes, budget, |_| {})
}

fn validate_constant_pool_slots_with(
    bytes: &[u8],
    budget: &Budget,
    mut before_entry: impl FnMut(u16),
) -> Result<()> {
    if bytes.len() < 10 || !bytes.starts_with(&0xcafebabe_u32.to_be_bytes()) {
        return Ok(()); // noak owns fixed-header diagnostics.
    }
    let count = read_u16(bytes, 8)?;
    if count == 0 {
        return Ok(()); // noak supplies the canonical InvalidLength diagnostic.
    }
    let mut slot = 1u16;
    let mut offset = 10usize;
    while slot < count {
        before_entry(slot);
        budget.poll()?;
        let tag = *bytes.get(offset).ok_or_else(|| cp_guard_eoi(offset))?;
        offset = offset.checked_add(1).ok_or_else(cp_guard_overflow)?;
        let payload = match tag {
            1 => {
                let length = usize::from(read_u16(bytes, offset)?);
                offset = offset.checked_add(2).ok_or_else(cp_guard_overflow)?;
                length
            }
            3 | 4 => 4,
            5 | 6 => {
                if slot.checked_add(1).is_none_or(|reserved| reserved >= count) {
                    return Err(Error::invalid_input(
                        "classfile_invalid_constant_pool_slots",
                        format!(
                            "constant-pool tag {tag} at slot {slot} has no reserved following slot"
                        ),
                    ));
                }
                slot = slot.checked_add(1).ok_or_else(cp_guard_overflow)?;
                8
            }
            7 | 8 | 16 | 19 | 20 => 2,
            9 | 10 | 11 | 12 | 17 | 18 => 4,
            15 => 3,
            _ => return Ok(()), // noak owns tag diagnostics.
        };
        offset = offset.checked_add(payload).ok_or_else(cp_guard_overflow)?;
        if offset > bytes.len() {
            return Ok(()); // noak owns truncation diagnostics and position/context.
        }
        slot = slot.checked_add(1).ok_or_else(cp_guard_overflow)?;
    }
    Ok(())
}

fn read_u32(bytes: &[u8], offset: usize) -> Result<u32> {
    let end = offset.checked_add(4).ok_or_else(cp_guard_overflow)?;
    let value: [u8; 4] = bytes
        .get(offset..end)
        .ok_or_else(|| cp_guard_eoi(offset))?
        .try_into()
        .expect("slice length was checked");
    Ok(u32::from_be_bytes(value))
}

pub(crate) fn read_u16(bytes: &[u8], offset: usize) -> Result<u16> {
    let end = offset.checked_add(2).ok_or_else(cp_guard_overflow)?;
    let pair: [u8; 2] = bytes
        .get(offset..end)
        .ok_or_else(|| cp_guard_eoi(offset))?
        .try_into()
        .expect("slice length was checked");
    Ok(u16::from_be_bytes(pair))
}

fn cp_guard_eoi(position: usize) -> Error {
    Error::invalid_input(
        "classfile_decode",
        format!(
            "noak decode failed: kind=unexpected end of input, context=constant pool, position={position}"
        ),
    )
}

fn cp_guard_overflow() -> Error {
    Error::invalid_input("classfile_span_overflow", "constant-pool offset overflow")
}

// ---------------------------------------------------------------------------
// P1 crate-private reader facts
// ---------------------------------------------------------------------------
//
// The items below are the reader fact layer consumed by the structural XRef
// consumer streams (`xref::code`, `xref::metadata`, `xref::bootstrap`). They stay
// crate-private by design: the P0 public contract (`inspect_header`,
// `inspect_method_bytecode`, `HeaderInspection`, `BytecodeInspection`) is
// unchanged and no public caller ever sees a constant-pool table.
//
// Billing convention, using the same vocabulary as the existing `inspect_*`
// owners:
//
// * `ClassBytes` — the whole class length, charged once per `class_facts` call.
// * `AttributeBytes` — one attribute entry, `6 + content length`, charged when a
//   shell is enumerated and again when `attribute_content` reads that shell,
//   exactly like the existing `Code` read in `inspect_method_bytecode`: every
//   pass over an attribute entry is billed as the bytes that pass reads. A nested
//   attribute inside a `Code` attribute is covered by the one charge on the entry
//   that contains it: `code_nested_attributes` bills that entry once, walks the
//   body without decoding an instruction, and never bills its nested content again
//   (`attribute_slice` is the non-billing slice for exactly that content).
// * `ResultItems` — never charged here. `ResultItems` counts items returned by a
//   public result; the query layer charges it per emitted item. Billing
//   intermediate facts would let facts that are never returned exhaust a page
//   budget.
//
// This layer has no partial-prefix shape: cancellation and budget exhaustion
// return structured errors, so a truncated fact set can never be mistaken for a
// complete one.
//
// Every crate-private item below carries `#[allow(dead_code)]` because the layer
// lands before its in-crate consumers; the allowance is scope, not a permanent
// property, and it goes away as the consumers start using the item. The private
// helpers and tag constants are reachable from those annotated items, so rustc
// keeps them alive.
//
// Two rules decide whether a fact is stored raw or resolved:
//
// * A field whose declared type is a resolved value (a name, a descriptor) is
//   resolved here, so a broken index or tag becomes a structured error instead
//   of a fact the consumer cannot use.
// * A field whose declared type is an index (`constant_value`, `enclosing_method`,
//   `MethodHandle::reference_index`, `Dynamic::bootstrap_method_attr_index`) stays
//   raw; the consumer resolves it through `cp_entry`, which owns that error
//   contract.

/// A recorded constant-pool index whose entry is resolved by the consumer.
#[allow(dead_code)]
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
pub struct CpIndexOf(pub u16);

/// Payload of one constant-pool entry.
///
/// Field names follow the JVMS constant-pool layouts. `owner`, `name`,
/// `descriptor` and every other resolved value are the raw Modified UTF-8 bytes
/// held by the class file: they are never text-decoded and never normalised, so
/// a `.` is not rewritten into `/` and an array owner differs from its element
/// owner.
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CpEntryKind {
    Utf8 {
        bytes: JvmBytes,
    },
    Integer {
        value: i32,
    },
    Float {
        bits: u32,
    },
    Long {
        value: i64,
    },
    Double {
        bits: u64,
    },
    Class {
        name_index: u16,
        name: JvmBytes,
    },
    String {
        utf8_index: u16,
        value: JvmBytes,
    },
    FieldRef {
        class_index: u16,
        name_and_type_index: u16,
        owner: JvmBytes,
        name: JvmBytes,
        descriptor: JvmBytes,
    },
    MethodRef {
        class_index: u16,
        name_and_type_index: u16,
        owner: JvmBytes,
        name: JvmBytes,
        descriptor: JvmBytes,
    },
    InterfaceMethodRef {
        class_index: u16,
        name_and_type_index: u16,
        owner: JvmBytes,
        name: JvmBytes,
        descriptor: JvmBytes,
    },
    NameAndType {
        name_index: u16,
        descriptor_index: u16,
        name: JvmBytes,
        descriptor: JvmBytes,
    },
    MethodHandle {
        reference_kind: u8,
        reference_index: u16,
    },
    MethodType {
        descriptor_index: u16,
        descriptor: JvmBytes,
    },
    Dynamic {
        bootstrap_method_attr_index: u16,
        name_and_type_index: u16,
        name: JvmBytes,
        descriptor: JvmBytes,
    },
    InvokeDynamic {
        bootstrap_method_attr_index: u16,
        name_and_type_index: u16,
        name: JvmBytes,
        descriptor: JvmBytes,
    },
    Module {
        name_index: u16,
        name: JvmBytes,
    },
    Package {
        name_index: u16,
        name: JvmBytes,
    },
}

/// One constant-pool entry with its class-file byte range.
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CpEntryFacts {
    /// 1-based constant-pool index, as used by instructions and attributes.
    pub index: u16,
    /// Byte range of the whole entry, tag byte plus payload, in class-file
    /// coordinates. Slots reserved by a preceding `Long`/`Double` have no entry
    /// and therefore no span.
    pub span: ByteSpan,
    pub kind: CpEntryKind,
}

/// Declaration-level facts plus the constant pool they refer to.
///
/// Field values are produced by the same noak-backed reads as `ClassHeader`,
/// but `class_facts` never runs the version gate and never rejects a version, so
/// forensic and strict callers both keep the structural view.
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ClassFacts {
    pub major_version: u16,
    pub minor_version: u16,
    pub access_flags: u16,
    pub this_class: JvmString,
    pub super_class: Option<JvmString>,
    pub interfaces: Vec<JvmString>,
    pub fields: Vec<MemberHeader>,
    pub methods: Vec<MemberHeader>,
    pub attributes: Vec<AttributeShell>,
    pub constant_pool: Vec<CpEntryFacts>,
}

/// One `InnerClasses` entry.
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct InnerClassFacts {
    /// Index of the inner class; resolve it with `cp_class_name`.
    pub class_index: u16,
    /// Index of the enclosing class, or 0 when the class is not a member.
    pub outer_class_index: u16,
    /// Simple name from `inner_name_index`; `None` when that index is 0, which is
    /// the anonymous-class case and not a missing fact.
    pub inner_name: Option<JvmBytes>,
    pub access_flags: u16,
}

/// One `EnclosingMethod` attribute.
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EnclosingMethodFacts {
    /// Index of the immediately enclosing class; resolve it with `cp_class_name`.
    pub class_index: u16,
    /// Index of the enclosing `NameAndType`, or 0 when the class is not
    /// immediately enclosed by a method or constructor.
    pub method_index: u16,
}

/// One `Module` `provides` entry.
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProvidesFacts {
    /// Service interface internal name, expanded from `CONSTANT_Class`.
    pub service: JvmBytes,
    /// Provider internal names, in declaration order.
    pub implementations: Vec<JvmBytes>,
}

/// `Module` uses/provides facts. Requires, exports and opens are skipped as byte
/// ranges because no P1 consumer reads them.
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ModuleFacts {
    /// Service interfaces declared with `uses`, in declaration order.
    pub uses: Vec<JvmBytes>,
    pub provides: Vec<ProvidesFacts>,
}

/// Typed facts of the simple class-level and member-level attributes.
///
/// `None`/empty means the attribute was absent, never "unknown": a recognised
/// single-valued attribute that appears twice, and attribute content that does
/// not match its declared structure, are structured errors.
///
/// `Signature` strings are deliberately not parsed here; generic signature
/// syntax belongs to the metadata consumer that owns those rules.
#[allow(dead_code)]
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct AttributeFacts {
    /// `Signature` (class, field, method): raw signature bytes.
    pub signature: Option<JvmBytes>,
    /// `Exceptions` (method): internal names, expanded from `CONSTANT_Class`.
    pub exceptions: Vec<JvmBytes>,
    /// `MethodParameters` (method): entries in descriptor order, when present.
    pub method_parameters: Option<Vec<MethodParameterFacts>>,
    /// `InnerClasses` (class).
    pub inner_classes: Vec<InnerClassFacts>,
    /// `EnclosingMethod` (class).
    pub enclosing_method: Option<EnclosingMethodFacts>,
    /// `NestHost` (class): internal name.
    pub nest_host: Option<JvmBytes>,
    /// `NestMembers` (class): internal names.
    pub nest_members: Vec<JvmBytes>,
    /// `PermittedSubclasses` (class): internal names.
    pub permitted_subclasses: Vec<JvmBytes>,
    /// `ConstantValue` (field): the raw index.
    pub constant_value: Option<CpIndexOf>,
    /// `AnnotationDefault` (method): the one `element_value` the attribute declares.
    pub annotation_default: Option<ElementValueFacts>,
    /// `RuntimeVisibleAnnotations`: annotation uses in class-file order.
    pub runtime_visible_annotations: Vec<ElementValueFacts>,
    /// `RuntimeInvisibleAnnotations`: annotation uses in class-file order.
    pub runtime_invisible_annotations: Vec<ElementValueFacts>,
    /// `RuntimeVisibleParameterAnnotations`: one ordered group per attribute-declared parameter.
    pub runtime_visible_parameter_annotations: Option<ParameterAnnotationFacts>,
    /// `RuntimeInvisibleParameterAnnotations`: one ordered group per attribute-declared parameter.
    pub runtime_invisible_parameter_annotations: Option<ParameterAnnotationFacts>,
    /// `RuntimeVisibleTypeAnnotations`: target, path and complete annotation in attribute order.
    pub runtime_visible_type_annotations: Vec<TypeAnnotationFacts>,
    /// `RuntimeInvisibleTypeAnnotations`: target, path and complete annotation in attribute order.
    pub runtime_invisible_type_annotations: Vec<TypeAnnotationFacts>,
    /// `Module` (class).
    pub module: Option<ModuleFacts>,
}

/// One raw member-level `MethodParameters` entry (JVMS 4.7.24).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MethodParameterFacts {
    pub name_index: u16,
    pub name: Option<JvmBytes>,
    pub access_flags: u16,
}

/// One type annotation exactly as an annotation attribute declares it (JVMS 4.7.20).
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
pub struct TypeAnnotationFacts {
    /// The `target_type` byte.
    pub target_type: u8,
    /// The complete target_info bytes, excluding `target_type`.
    pub target_info: Vec<u8>,
    /// Ordered `(kind, index)` entries from `type_path`.
    pub type_path: Vec<TypePathEntry>,
    /// The shared complete annotation value tree.
    pub annotation: ElementValueFacts,
}

/// One validated `type_path` entry (JVMS 4.7.20.2).
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize)]
pub struct TypePathEntry {
    pub kind: u8,
    pub index: u8,
}

/// The tag of one `element_value` whose payload is a constant (JVMS 4.7.22.1).
///
/// The eight constant tags share one shape — a single `const_value_index` — and the tag is the only
/// thing that says which constant it is: `B`, `C`, `I`, `S` and `Z` all name a `CONSTANT_Integer`,
/// `J` a `CONSTANT_Long`, `F` a `CONSTANT_Float` and `D` a `CONSTANT_Double`. The tag is kept
/// instead of being folded into the value, because the same integer is `1`, `true` or `'A'`
/// depending on the one the attribute wrote, and no consumer can tell those apart from the number.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize)]
pub enum ElementConstantTag {
    /// `B`: a `byte`, held in a `CONSTANT_Integer`.
    Byte,
    /// `C`: a `char`, held in a `CONSTANT_Integer`.
    Char,
    /// `D`: a `double`, held in a `CONSTANT_Double`.
    Double,
    /// `F`: a `float`, held in a `CONSTANT_Float`.
    Float,
    /// `I`: an `int`, held in a `CONSTANT_Integer`.
    Integer,
    /// `J`: a `long`, held in a `CONSTANT_Long`.
    Long,
    /// `S`: a `short`, held in a `CONSTANT_Integer`.
    Short,
    /// `Z`: a `boolean`, held in a `CONSTANT_Integer`.
    Boolean,
}

impl ElementConstantTag {
    /// The tag one attribute's own byte is, or `None` when that byte is no constant tag.
    fn of(tag: u8) -> Option<Self> {
        Some(match tag {
            b'B' => Self::Byte,
            b'C' => Self::Char,
            b'D' => Self::Double,
            b'F' => Self::Float,
            b'I' => Self::Integer,
            b'J' => Self::Long,
            b'S' => Self::Short,
            b'Z' => Self::Boolean,
            _ => return None,
        })
    }
}

/// One `element_value` (JVMS 4.7.22.1), as the attribute's own bytes state it.
///
/// Every tag of the production is here, including the ones no consumer writes into a declaration. The
/// walk has to read a value whole to find the attribute's own end, and a fact type that held only the
/// tags some consumer spells would state the same thing about two different class files: one whose
/// member declares no `AnnotationDefault` at all, and one whose value is a `double`. "The attribute is
/// absent" and "the attribute's value is one this engine has no literal for" are two facts, and the
/// consumer that writes the declaration has to be able to tell them apart to decide between writing a
/// `default` and writing none.
///
/// What this type never carries is a spelling. The constant tags publish the pool index they write,
/// the same rule [`AttributeFacts::constant_value`] follows; the tags that name a `CONSTANT_Utf8`
/// publish those bytes resolved. Which of these values a consumer can write as source is the
/// consumer's decision, and a value it cannot write stays the structure the class file states.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
pub enum ElementValueFacts {
    /// `B`, `C`, `D`, `F`, `I`, `J`, `S`, `Z`: one constant, by the tag that says which it is and
    /// the constant-pool index the attribute writes for it.
    Constant {
        tag: ElementConstantTag,
        index: CpIndexOf,
    },
    /// `s`: the text of the `CONSTANT_Utf8` the attribute names.
    Utf8(JvmBytes),
    /// `e`: an enum constant: the field descriptor the type index names, and the simple name the
    /// constant-name index names.
    Enum {
        type_descriptor: JvmBytes,
        constant_name: JvmBytes,
    },
    /// `c`: a class literal's return descriptor (JVMS 4.3.2/4.3.3).
    Class(JvmBytes),
    /// `@`: a nested annotation: the descriptor of the annotation type, and the pairs it declares in
    /// the order it declares them.
    Annotation {
        type_descriptor: JvmBytes,
        elements: Vec<ElementValuePairFacts>,
    },
    /// `[`: the elements the array declares, in order. An empty list is an array the attribute
    /// itself declares empty, never an array this reader failed to read.
    Array(Vec<ElementValueFacts>),
}

/// One `element_value_pair` of a nested annotation (JVMS 4.7.22.1): the element's own simple name
/// and the value the pair gives it.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
pub struct ElementValuePairFacts {
    /// The element's simple name, from the pair's `element_name_index`.
    pub name: JvmBytes,
    /// The value the pair gives that element.
    pub value: ElementValueFacts,
}

/// The parameter groups one `Runtime*ParameterAnnotations` attribute declares (JVMS 4.7.18/19).
///
/// `parameter_count` is the attribute's leading `u1`, not a count inferred from a method descriptor.
/// Each group is the annotations for that descriptor position when the count agrees; callers must
/// refuse to align the groups when it does not.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
pub struct ParameterAnnotationFacts {
    pub parameter_count: u8,
    pub parameters: Vec<Vec<ElementValueFacts>>,
}

/// One `BootstrapMethods` entry.
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BootstrapMethodFacts {
    /// Index of the bootstrap method handle; resolve it with `cp_entry`.
    pub method_ref: u16,
    /// Argument indexes in declaration order; each one is a loadable constant.
    pub arguments: Vec<u16>,
}

/// Reads declaration structure and the constant pool as reusable facts.
///
/// The class-shaped pre-checks (`validate_constant_pool_slots`, noak decode,
/// trailing-byte rejection) are the same ones the `inspect_*` owners run, so a
/// class accepted here is accepted there. Attribute content and instructions are
/// not decoded: callers ask for those per attribute or per method.
///
/// # The facts cache (P5 2.3)
///
/// When the request's budget carries a cache ([`Budget::with_facts_cache`]), this entry consults it
/// under the class content digest and the structural parse policy, and a hit returns the facts an
/// earlier read of **these bytes** produced. Everything else is unchanged: the read that produced
/// the bytes happened and was charged by the caller, a hit charges nothing because this read decodes
/// nothing, the budget is polled first so a cancelled request still terminates, and any failure —
/// budget, cancellation, an undecodable structure — propagates without writing anything, so an
/// incomplete read can never become the answer a later request receives. With no cache attached the
/// body below is the whole function, as it was before this layer existed.
#[allow(dead_code)]
pub fn class_facts(bytes: &[u8], budget: &mut Budget) -> Result<ClassFacts> {
    let Some(cache) = budget.facts_cache().cloned() else {
        return read_class_facts(bytes, budget);
    };
    if let Some(facts) = cache.structure(bytes, budget)? {
        return Ok(facts);
    }
    let facts = read_class_facts(bytes, budget)?;
    cache.remember_structure(bytes, &facts);
    Ok(facts)
}

/// One class's declaration, constant pool and member records, together with the parser view every
/// later body read of that class goes through.
///
/// The three parts come from one read of the class: the facts are the answer `class_facts`
/// publishes, `class` is the parser that produced them (its pool resolves an attribute's own
/// content), and `methods` are the method records of [`ClassFacts::methods`] in the same order, so a
/// body decode resolves its member without walking the member table again. Together they are what a
/// prepared class holds for the lifetime of one class task
/// ([`crate::prepared::PreparedClass`]), which is why they are handed over as one value rather than
/// three separate reads.
pub(crate) struct ClassStructure<'a> {
    pub(crate) facts: ClassFacts,
    pub(crate) class: Class<'a>,
    /// The parser's method records, parallel to [`ClassFacts::methods`].
    pub(crate) methods: Vec<Method<'a>>,
}

/// The direct read of [`class_facts`]: what the engine did before a cache could answer it, and what
/// it still does whenever no cache answers.
fn read_class_facts(bytes: &[u8], budget: &mut Budget) -> Result<ClassFacts> {
    Ok(read_class_structure(bytes, budget)?.facts)
}

/// Reads one class's structure once and keeps the parser view next to the facts.
///
/// This is the read [`class_facts`] publishes the facts of, and the read
/// [`crate::prepared::PreparedClass::prepare`] does once per class task. It performs exactly the
/// checks that read always performed (the constant-pool guard, noak's decode, the trailing-byte
/// rejection, the layout cross-check against noak's pool) and charges exactly what it charged:
/// `ClassBytes` once, plus one `AttributeBytes` charge per attribute shell it reads.
///
/// The member records are materialized in the same pass that builds the facts and the parser that
/// read them, so what this read costs does not depend on how many methods are later decoded: no
/// body read rebuilds a parser, and none walks the member table again.
pub(crate) fn read_class_structure<'a>(
    bytes: &'a [u8],
    budget: &mut Budget,
) -> Result<ClassStructure<'a>> {
    budget.poll()?;
    budget.charge(CountedBudgetDimension::ClassBytes, to_u64(bytes.len())?)?;
    validate_constant_pool_slots(bytes, budget)?;
    let class = Class::new(bytes).map_err(map_decode_error)?;
    if class.buffer_size() != bytes.len() {
        return Err(Error::invalid_input(
            "classfile_trailing_bytes",
            "class structure has trailing bytes",
        ));
    }
    let layout = measure_constant_pool(bytes, budget)?;
    verify_constant_pool_layout(bytes, &layout, &class)?;
    let constant_pool = resolve_constant_pool(bytes, &layout, budget)?;

    let pool = class.pool();
    let this_class = jvm_string_mstr(
        pool.retrieve(class.this_class())
            .map_err(map_decode_error)?
            .name,
    )?;
    let super_class = class
        .super_class()
        .map(|index| {
            let name = pool.retrieve(index).map_err(map_decode_error)?.name;
            jvm_string_mstr(name)
        })
        .transpose()?;

    let mut interfaces = Vec::new();
    for interface in class.interfaces() {
        budget.poll()?;
        let name = pool
            .retrieve(interface.map_err(map_decode_error)?)
            .map_err(map_decode_error)?
            .name;
        interfaces.push(jvm_string_mstr(name)?);
    }

    let mut fields = Vec::new();
    for field in class.fields() {
        budget.poll()?;
        let field = field.map_err(map_decode_error)?;
        let attributes = collect_attribute_shells(
            bytes,
            pool,
            field.attributes(),
            budget,
            AttributeItemBilling::NoResultItems,
        )?;
        fields.push(MemberHeader {
            name: jvm_string(field.name(), pool)?,
            descriptor: jvm_string(field.descriptor(), pool)?,
            access_flags: field.access_flags().bits(),
            attributes,
        });
    }

    let mut methods = Vec::new();
    // The parser's own method records are kept beside the headers: a later body decode resolves
    // its member through one of these, so the walk below happens exactly once per class.
    let mut method_records = Vec::new();
    for method in class.methods() {
        budget.poll()?;
        let method = method.map_err(map_decode_error)?;
        let attributes = collect_attribute_shells(
            bytes,
            pool,
            method.attributes(),
            budget,
            AttributeItemBilling::NoResultItems,
        )?;
        method_records.push(method.clone());
        methods.push(MemberHeader {
            name: jvm_string(method.name(), pool)?,
            descriptor: jvm_string(method.descriptor(), pool)?,
            access_flags: method.access_flags().bits(),
            attributes,
        });
    }

    let attributes = collect_attribute_shells(
        bytes,
        pool,
        class.attributes(),
        budget,
        AttributeItemBilling::NoResultItems,
    )?;

    Ok(ClassStructure {
        facts: ClassFacts {
            major_version: class.version().major,
            minor_version: class.version().minor,
            access_flags: class.access_flags().bits(),
            this_class,
            super_class,
            interfaces,
            fields,
            methods,
            attributes,
            constant_pool,
        },
        class,
        methods: method_records,
    })
}

/// The constant pool of one class, measured and resolved the way the tolerant member walk measures
/// it.
///
/// This is the pool a caller resolves an **attribute's content** through when the member records of
/// [`class_member_facts`] are the only facts it holds: a member record carries its attribute shells,
/// and a shell's own indexes resolve against the class's pool. Publishing it on its own is what lets
/// such a caller read one member attribute without reading the class's declaration or structure a
/// second time ([`crate::prepared::PreparedClass`] hands its own pool out instead, through
/// [`ClassFacts::constant_pool`]).
///
/// Nothing is charged: the bytes the pool lives in are the ones the caller's own read of that class
/// already paid `ClassBytes` for, and this is a second **view** of them rather than a second read —
/// the same rule [`read_class_member_prefix`] follows when it resolves the pool of a class whose
/// member table stopped.
pub fn class_constant_pool(bytes: &[u8], budget: &Budget) -> Result<Vec<CpEntryFacts>> {
    let layout = measure_constant_pool(bytes, budget)?;
    resolve_constant_pool(bytes, &layout, budget)
}

/// The structure facts of a class whose member table did not read to its declared end.
///
/// A member record that does not decode fails noak's whole structure read, so the facts
/// [`class_facts`] publishes do not exist for such a class — that is exactly why the prepared read
/// has a second, tolerant walk. This is that walk's answer: the declaration, the constant pool and
/// the member records the walk did read (the reliable prefix [`class_member_facts`] publishes),
/// plus the [`MemberTableStop`] that ended it.
///
/// `Ok(None)` is "the member tables read to their declared end", which means the failure the caller
/// saw was not member-table damage and it has to propagate its own error. A damaged declaration —
/// no class-file magic, an unmeasurable constant pool, a truncated fixed part — is an `Err`, exactly
/// as in every other structural read, because a class whose own declaration cannot be established
/// has no prefix to publish.
///
/// # What the facts do and do not state
///
/// [`ClassFacts::attributes`] is empty because the class attribute table follows the member tables,
/// so a walk that stopped inside them never reached it: nothing is stated about that region, and the
/// stop this returns is the only complete statement about it. [`ClassMemberPrefix::field_count`] and
/// [`ClassMemberPrefix::method_count`] are the counts the class file itself declares, so a caller
/// can see that `facts.fields`/`facts.methods` hold a prefix rather than the whole table.
pub(crate) fn read_class_member_prefix(
    bytes: &[u8],
    budget: &mut Budget,
) -> Result<Option<ClassMemberPrefix>> {
    let members = class_member_facts(bytes, budget)?;
    let Some(stop) = members.stopped_at.clone() else {
        return Ok(None);
    };
    // The constant pool is measured and resolved with the layout walk the raw path owns; noak's
    // cross-check is not available here, because the structure that would provide it did not
    // decode. The pool sits before the member tables, so a stop inside them never truncated it.
    let layout = measure_constant_pool(bytes, budget)?;
    let constant_pool = resolve_constant_pool(bytes, &layout, budget)?;
    Ok(Some(ClassMemberPrefix {
        facts: ClassFacts {
            major_version: read_u16(bytes, 6)?,
            minor_version: read_u16(bytes, 4)?,
            access_flags: members.access_flags,
            this_class: members.this_class,
            super_class: members.super_class,
            interfaces: members.interfaces,
            fields: members.fields,
            methods: members.methods,
            attributes: Vec::new(),
            constant_pool,
        },
        field_count: members.field_count,
        method_count: members.method_count,
        stop,
    }))
}

/// The prefix facts [`read_class_member_prefix`] publishes, with the counts the class declares and
/// the stop that ended the walk.
pub(crate) struct ClassMemberPrefix {
    pub(crate) facts: ClassFacts,
    /// How many field records the class file declares (the whole table, not the prefix).
    pub(crate) field_count: u64,
    /// How many method records the class file declares (the whole table, not the prefix).
    pub(crate) method_count: u64,
    /// Where the member-table read stopped, with the code and message of the failure.
    pub(crate) stop: MemberTableStop,
}

/// Slices one attribute content out of the class bytes and bills that entry.
///
/// The shell is taken from `ClassFacts`; a shell whose span does not match its
/// content span, or whose content leaves the class bytes, is a structured error
/// instead of a silently wrong slice. No semantic decoding happens here.
///
/// Nested attribute content that is already covered by the charge of the attribute
/// containing it is sliced with [`attribute_slice`] instead: it is the same
/// consistency check without a second charge.
#[allow(dead_code)]
pub fn attribute_content<'a>(
    bytes: &'a [u8],
    shell: &AttributeShell,
    budget: &mut Budget,
) -> Result<&'a [u8]> {
    budget.poll()?;
    let shell_length = attribute_shell_length(&shell.content_span)?;
    let content = attribute_slice(bytes, &shell.span, &shell.content_span)?;
    budget.charge(CountedBudgetDimension::AttributeBytes, shell_length)?;
    Ok(content)
}

/// Slices one attribute content out of the class bytes without billing it.
///
/// The header span and the content span must describe one `attribute_info`: the header
/// span covers the two indexes and the length, and the content span starts right after
/// them and is inside the class bytes. A shell that disagrees with itself or points
/// outside the class is a structured error instead of a silently wrong slice.
///
/// This is the non-billing entry point for content the caller already paid for — a
/// nested attribute inside a `Code` attribute, whose bytes are charged once as part of
/// the entry that contains it (see [`code_nested_attributes`]).
#[allow(dead_code)]
pub fn attribute_slice<'a>(
    bytes: &'a [u8],
    span: &ByteSpan,
    content_span: &ByteSpan,
) -> Result<&'a [u8]> {
    let shell_length = attribute_shell_length(content_span)?;
    if span.length != shell_length
        || span.start.checked_add(ATTRIBUTE_HEADER_LENGTH as u64) != Some(content_span.start)
    {
        return Err(Error::invalid_input(
            "classfile_invalid_attribute_span",
            "attribute shell span does not match its content span",
        ));
    }
    span_slice(bytes, content_span, "attribute content")
}

/// `6 + content length` of one attribute entry: the unit one pass over an
/// `attribute_info` is billed in.
pub(crate) fn attribute_shell_length(content_span: &ByteSpan) -> Result<u64> {
    content_span
        .length
        .checked_add(ATTRIBUTE_HEADER_LENGTH as u64)
        .ok_or_else(|| {
            Error::invalid_input("classfile_span_overflow", "attribute shell length overflow")
        })
}

/// Reads the simple class-level or member-level attributes of one shell list.
///
/// Only the recognised attributes below are read; every other attribute,
/// including `Code` and its nested `LineNumberTable`/`LocalVariableTable`/
/// `StackMapTable`, is left untouched. `MemberHeader::attributes` from
/// `class_facts` is the intended input for the member-level call.
#[allow(dead_code)]
pub fn attribute_facts(
    bytes: &[u8],
    shells: &[AttributeShell],
    pool: &[CpEntryFacts],
    budget: &mut Budget,
) -> Result<AttributeFacts> {
    let mut facts = AttributeFacts::default();
    let mut seen: Vec<&str> = Vec::new();
    for shell in shells {
        budget.poll()?;
        match shell.name.raw().0.as_slice() {
            b"Signature" => {
                ensure_unique(&mut seen, "Signature")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                let signature_index = reader.u16()?;
                reader.expect_end()?;
                facts.signature = Some(cp_utf8(pool, signature_index)?);
            }
            b"Exceptions" => {
                ensure_unique(&mut seen, "Exceptions")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                facts.exceptions = read_class_name_list(&mut reader, pool, budget)?;
                reader.expect_end()?;
            }
            b"MethodParameters" => {
                ensure_unique(&mut seen, "MethodParameters")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                let count = reader.u8()?;
                let mut parameters = Vec::with_capacity(usize::from(count));
                for _ in 0..count {
                    budget.poll()?;
                    let name_index = reader.u16()?;
                    let access_flags = reader.u16()?;
                    if access_flags & !(0x0010 | 0x1000 | 0x8000) != 0 {
                        return Err(Error::invalid_input(
                            "classfile_invalid_attribute_content",
                            "MethodParameters entry has invalid access flags",
                        ));
                    }
                    parameters.push(MethodParameterFacts {
                        name_index,
                        name: (name_index != 0)
                            .then(|| cp_utf8(pool, name_index))
                            .transpose()?,
                        access_flags,
                    });
                }
                reader.expect_end()?;
                facts.method_parameters = Some(parameters);
            }
            b"InnerClasses" => {
                ensure_unique(&mut seen, "InnerClasses")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                let count = reader.u16()?;
                let mut inner_classes = Vec::new();
                for _ in 0..count {
                    budget.poll()?;
                    let class_index = reader.u16()?;
                    let outer_class_index = reader.u16()?;
                    let inner_name_index = reader.u16()?;
                    let access_flags = reader.u16()?;
                    let inner_name = if inner_name_index == 0 {
                        None
                    } else {
                        Some(cp_utf8(pool, inner_name_index)?)
                    };
                    inner_classes.push(InnerClassFacts {
                        class_index,
                        outer_class_index,
                        inner_name,
                        access_flags,
                    });
                }
                reader.expect_end()?;
                facts.inner_classes = inner_classes;
            }
            b"EnclosingMethod" => {
                ensure_unique(&mut seen, "EnclosingMethod")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                let class_index = reader.u16()?;
                let method_index = reader.u16()?;
                reader.expect_end()?;
                facts.enclosing_method = Some(EnclosingMethodFacts {
                    class_index,
                    method_index,
                });
            }
            b"NestHost" => {
                ensure_unique(&mut seen, "NestHost")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                let host_class_index = reader.u16()?;
                reader.expect_end()?;
                facts.nest_host = Some(cp_class_name(pool, host_class_index)?);
            }
            b"NestMembers" => {
                ensure_unique(&mut seen, "NestMembers")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                facts.nest_members = read_class_name_list(&mut reader, pool, budget)?;
                reader.expect_end()?;
            }
            b"PermittedSubclasses" => {
                ensure_unique(&mut seen, "PermittedSubclasses")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                facts.permitted_subclasses = read_class_name_list(&mut reader, pool, budget)?;
                reader.expect_end()?;
            }
            b"ConstantValue" => {
                ensure_unique(&mut seen, "ConstantValue")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                let constant_value_index = reader.u16()?;
                reader.expect_end()?;
                facts.constant_value = Some(CpIndexOf(constant_value_index));
            }
            b"AnnotationDefault" => {
                ensure_unique(&mut seen, "AnnotationDefault")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                let value = read_element_value(&mut reader, pool, budget, 0)?;
                reader.expect_end()?;
                facts.annotation_default = Some(value);
            }
            b"RuntimeVisibleAnnotations" => {
                ensure_unique(&mut seen, "RuntimeVisibleAnnotations")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                facts.runtime_visible_annotations = read_annotations(&mut reader, pool, budget)?;
                reader.expect_end()?;
            }
            b"RuntimeInvisibleAnnotations" => {
                ensure_unique(&mut seen, "RuntimeInvisibleAnnotations")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                facts.runtime_invisible_annotations = read_annotations(&mut reader, pool, budget)?;
                reader.expect_end()?;
            }
            b"RuntimeVisibleParameterAnnotations" => {
                ensure_unique(&mut seen, "RuntimeVisibleParameterAnnotations")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                let parameters = read_parameter_annotations(&mut reader, pool, budget)?;
                reader.expect_end()?;
                facts.runtime_visible_parameter_annotations = Some(parameters);
            }
            b"RuntimeInvisibleParameterAnnotations" => {
                ensure_unique(&mut seen, "RuntimeInvisibleParameterAnnotations")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                let parameters = read_parameter_annotations(&mut reader, pool, budget)?;
                reader.expect_end()?;
                facts.runtime_invisible_parameter_annotations = Some(parameters);
            }
            b"RuntimeVisibleTypeAnnotations" => {
                ensure_unique(&mut seen, "RuntimeVisibleTypeAnnotations")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                facts.runtime_visible_type_annotations =
                    read_type_annotations(&mut reader, pool, budget)?;
                reader.expect_end()?;
            }
            b"RuntimeInvisibleTypeAnnotations" => {
                ensure_unique(&mut seen, "RuntimeInvisibleTypeAnnotations")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                facts.runtime_invisible_type_annotations =
                    read_type_annotations(&mut reader, pool, budget)?;
                reader.expect_end()?;
            }
            b"Module" => {
                ensure_unique(&mut seen, "Module")?;
                let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
                facts.module = Some(read_module_facts(&mut reader, pool, budget)?);
                reader.expect_end()?;
            }
            _ => {}
        }
    }
    Ok(facts)
}

/// Reads the shared `annotation` production used by both annotation element values and the
/// class-level Runtime*Annotations attributes.
fn read_annotation(
    reader: &mut AttributeReader<'_>,
    pool: &[CpEntryFacts],
    budget: &mut Budget,
    depth: usize,
) -> Result<ElementValueFacts> {
    let type_descriptor = cp_utf8(pool, reader.u16()?)?;
    let count = reader.u16()?;
    let mut elements = Vec::new();
    for _ in 0..count {
        budget.poll()?;
        let name = cp_utf8(pool, reader.u16()?)?;
        let value = read_element_value(reader, pool, budget, depth + 1)?;
        elements.push(ElementValuePairFacts { name, value });
    }
    Ok(ElementValueFacts::Annotation {
        type_descriptor,
        elements,
    })
}

fn read_annotations(
    reader: &mut AttributeReader<'_>,
    pool: &[CpEntryFacts],
    budget: &mut Budget,
) -> Result<Vec<ElementValueFacts>> {
    let count = reader.u16()?;
    let mut annotations = Vec::new();
    for _ in 0..count {
        budget.poll()?;
        annotations.push(read_annotation(reader, pool, budget, 0)?);
    }
    Ok(annotations)
}

/// Reads the `u1 num_parameters` groups of a Runtime*ParameterAnnotations attribute.
fn read_parameter_annotations(
    reader: &mut AttributeReader<'_>,
    pool: &[CpEntryFacts],
    budget: &mut Budget,
) -> Result<ParameterAnnotationFacts> {
    let parameter_count = reader.u8()?;
    let mut parameters = Vec::with_capacity(usize::from(parameter_count));
    for _ in 0..parameter_count {
        budget.poll()?;
        parameters.push(read_annotations(reader, pool, budget)?);
    }
    Ok(ParameterAnnotationFacts {
        parameter_count,
        parameters,
    })
}

fn read_type_annotations(
    reader: &mut AttributeReader<'_>,
    pool: &[CpEntryFacts],
    budget: &mut Budget,
) -> Result<Vec<TypeAnnotationFacts>> {
    let count = reader.u16()?;
    let mut annotations = Vec::new();
    for _ in 0..count {
        budget.poll()?;
        let target_type = reader.u8()?;
        let target_info = read_type_target_info(reader, target_type, budget)?;
        let path_length = reader.u8()?;
        let mut type_path = Vec::new();
        for _ in 0..path_length {
            budget.poll()?;
            let kind = reader.u8()?;
            let index = reader.u8()?;
            if kind > 3 || (kind != 3 && index != 0) {
                return Err(Error::invalid_input(
                    "classfile_invalid_attribute_content",
                    format!("invalid type_path entry kind={kind} index={index}"),
                ));
            }
            type_path.push(TypePathEntry { kind, index });
        }
        let annotation = read_annotation(reader, pool, budget, 0)?;
        annotations.push(TypeAnnotationFacts {
            target_type,
            target_info,
            type_path,
            annotation,
        });
    }
    Ok(annotations)
}

/// Consumes every JVMS 4.7.20 target_info shape while preserving its exact bytes.
fn read_type_target_info(
    reader: &mut AttributeReader<'_>,
    target_type: u8,
    budget: &mut Budget,
) -> Result<Vec<u8>> {
    let length = match target_type {
        0x00 | 0x01 | 0x16 => 1,
        0x10 | 0x17 | 0x42 | 0x43..=0x46 => 2,
        0x11 | 0x12 => 2,
        0x13..=0x15 => 0,
        0x47..=0x4b => 3,
        0x40 | 0x41 => {
            let count = reader.u16()?;
            let mut bytes = vec![(count >> 8) as u8, count as u8];
            for _ in 0..count {
                budget.poll()?;
                budget.charge(CountedBudgetDimension::ResultItems, 1)?;
                bytes.extend_from_slice(&[
                    reader.u8()?,
                    reader.u8()?,
                    reader.u8()?,
                    reader.u8()?,
                    reader.u8()?,
                    reader.u8()?,
                ]);
            }
            return Ok(bytes);
        }
        _ => {
            return Err(Error::invalid_input(
                "classfile_invalid_attribute_content",
                format!("unknown type_annotation target_type 0x{target_type:02x}"),
            ));
        }
    };
    (0..length).map(|_| reader.u8()).collect()
}

/// The deepest `element_value` this reader walks (JVMS 4.7.22.1).
///
/// The production nests without a bound of its own — an array of arrays of …, or an annotation whose
/// element is another annotation, is one level per production, and the class bytes are input — so
/// the walk is bounded here rather than by the call stack. The bound is far above anything a
/// compiler writes (an annotation inside an array inside an annotation is depth 3), and a value
/// that nests deeper is a structured error rather than a fact read only in part.
const MAX_ELEMENT_VALUE_DEPTH: usize = 32;

/// Reads one `element_value` (JVMS 4.7.22.1) and every value nested inside it.
///
/// Every tag of the production is walked, so the bytes an attribute declares are consumed exactly
/// as JVMS 4.7.22.1 states them and the attribute's own end is found wherever it is; what the walk
/// publishes is [`ElementValueFacts`]. `depth` is how many `[`/`@` productions already enclose this
/// value; see [`MAX_ELEMENT_VALUE_DEPTH`].
fn read_element_value(
    reader: &mut AttributeReader<'_>,
    pool: &[CpEntryFacts],
    budget: &mut Budget,
    depth: usize,
) -> Result<ElementValueFacts> {
    if depth > MAX_ELEMENT_VALUE_DEPTH {
        return Err(Error::invalid_input(
            "classfile_element_value_depth",
            format!("annotation element value nests deeper than {MAX_ELEMENT_VALUE_DEPTH} levels"),
        ));
    }
    budget.poll()?;
    let tag = reader.u8()?;
    Ok(match tag {
        b's' => ElementValueFacts::Utf8(cp_utf8(pool, reader.u16()?)?),
        b'e' => {
            let type_index = reader.u16()?;
            let constant_index = reader.u16()?;
            ElementValueFacts::Enum {
                type_descriptor: cp_utf8(pool, type_index)?,
                constant_name: cp_utf8(pool, constant_index)?,
            }
        }
        b'c' => ElementValueFacts::Class(cp_utf8(pool, reader.u16()?)?),
        b'@' => read_annotation(reader, pool, budget, depth)?,
        b'[' => {
            let count = reader.u16()?;
            let mut elements = Vec::new();
            for _ in 0..count {
                elements.push(read_element_value(reader, pool, budget, depth + 1)?);
            }
            ElementValueFacts::Array(elements)
        }
        _ => {
            let Some(tag) = ElementConstantTag::of(tag) else {
                return Err(Error::invalid_input(
                    "classfile_invalid_attribute_content",
                    format!("annotation element value tag 0x{tag:02x} is unknown"),
                ));
            };
            ElementValueFacts::Constant {
                tag,
                index: CpIndexOf(reader.u16()?),
            }
        }
    })
}

/// Reads one `BootstrapMethods` attribute.
///
/// The attribute is read on its own so the caller can decide when a deferred
/// bootstrap graph needs it; the class-level enumeration never reads it. Both
/// the bootstrap handle and every argument are validated as loadable constant
/// shapes, because a dynamic site that cannot reach a loadable constant is not a
/// fact a consumer may act on.
#[allow(dead_code)]
pub fn bootstrap_methods(
    bytes: &[u8],
    shell: &AttributeShell,
    pool: &[CpEntryFacts],
    budget: &mut Budget,
) -> Result<Vec<BootstrapMethodFacts>> {
    let mut reader = AttributeReader::new(attribute_content(bytes, shell, budget)?);
    let count = reader.u16()?;
    let mut methods = Vec::new();
    for _ in 0..count {
        budget.poll()?;
        let method_ref = reader.u16()?;
        match &cp_entry(pool, method_ref)?.kind {
            CpEntryKind::MethodHandle { .. } => {}
            _ => {
                return Err(cp_fact_tag_mismatch("CONSTANT_MethodHandle", method_ref));
            }
        }
        let argument_count = reader.u16()?;
        let mut arguments = Vec::new();
        for _ in 0..argument_count {
            let index = reader.u16()?;
            if !matches!(
                cp_entry(pool, index)?.kind,
                CpEntryKind::String { .. }
                    | CpEntryKind::Class { .. }
                    | CpEntryKind::Integer { .. }
                    | CpEntryKind::Long { .. }
                    | CpEntryKind::Float { .. }
                    | CpEntryKind::Double { .. }
                    | CpEntryKind::MethodHandle { .. }
                    | CpEntryKind::MethodType { .. }
                    | CpEntryKind::Dynamic { .. }
            ) {
                return Err(cp_fact_tag_mismatch("loadable constant", index));
            }
            arguments.push(index);
        }
        methods.push(BootstrapMethodFacts {
            method_ref,
            arguments,
        });
    }
    reader.expect_end()?;
    Ok(methods)
}

// ---------------------------------------------------------------------------
// Descriptor facts
// ---------------------------------------------------------------------------

/// Stable code of a descriptor that does not parse as its own production.
const DESCRIPTOR_CODE: &str = "query_descriptor_malformed";

/// Which descriptor production to accept (JVMS 4.3).
#[allow(dead_code)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DescriptorKind {
    /// `FieldDescriptor`.
    Field,
    /// `MethodDescriptor`: parameters and result, `V` allowed.
    Method,
    /// `ReturnDescriptor`: a field type or `V` (annotation class literals).
    Return,
}

/// A descriptor one constant-pool entry carries, with the production it belongs to.
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EntryDescriptor {
    /// Raw descriptor bytes exactly as the class file holds them.
    pub descriptor: JvmBytes,
    pub kind: DescriptorKind,
}

/// The descriptor one constant-pool entry carries, when it carries one at all.
///
/// JVMS 4.4.9/4.4.10: a `MethodType` holds a **method** descriptor, a `Dynamic` holds a
/// **field** descriptor, an `InvokeDynamic` holds a method descriptor, and a member
/// reference holds the descriptor of the member it names. A `MethodHandle` carries none
/// of its own — the entry its `reference_index` names does, and the caller resolves that
/// hop. Every other kind carries no descriptor, including a `Class` entry, whose type is
/// the entry itself rather than a descriptor's contents.
#[allow(dead_code)]
pub fn entry_descriptor(kind: &CpEntryKind) -> Option<EntryDescriptor> {
    let (descriptor, kind) = match kind {
        CpEntryKind::FieldRef { descriptor, .. } => (descriptor, DescriptorKind::Field),
        CpEntryKind::MethodRef { descriptor, .. }
        | CpEntryKind::InterfaceMethodRef { descriptor, .. } => {
            (descriptor, DescriptorKind::Method)
        }
        CpEntryKind::MethodType { descriptor, .. } => (descriptor, DescriptorKind::Method),
        CpEntryKind::Dynamic { descriptor, .. } => (descriptor, DescriptorKind::Field),
        CpEntryKind::InvokeDynamic { descriptor, .. } => (descriptor, DescriptorKind::Method),
        _ => return None,
    };
    Some(EntryDescriptor {
        descriptor: descriptor.clone(),
        kind,
    })
}

/// A base type of the descriptor grammar (JVMS 4.3.2).
///
/// The eight primitives are named as the format names them and not as a value's slot class: this
/// is the descriptor production's own vocabulary, so it keeps the four int-shaped primitives
/// (`boolean`, `byte`, `char`, `short`) apart, which a *frame* cannot.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum BaseType {
    /// `B`.
    Byte,
    /// `C`.
    Char,
    /// `D`.
    Double,
    /// `F`.
    Float,
    /// `I`.
    Int,
    /// `J`.
    Long,
    /// `S`.
    Short,
    /// `Z`.
    Boolean,
}

impl BaseType {
    /// Whether a value of this type fills two local slots (JVMS 2.6.1).
    ///
    /// Only `long` and `double` do, and only when the component names the primitive itself: an
    /// **array** of either is a reference like every other array ([`DescriptorComponent::slots`]).
    pub const fn is_category_two(self) -> bool {
        matches!(self, Self::Long | Self::Double)
    }
}

/// What one descriptor component names at its base (JVMS 4.3.2).
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Base {
    /// One of the eight primitives.
    Primitive(BaseType),
    /// `L<internal name>;`: the bytes exactly as they stand between the two delimiters, and never
    /// text-decoded here.
    ///
    /// The bytes are kept as written, empty included: whether an empty interior is a **class
    /// reference** is JVMS 4.2's rule (a binary name is not empty) and is stated by whoever
    /// publishes a type — [`DescriptorComponent::object_name`], [`descriptor_types`] and the layers
    /// that spell a type each refuse it — while a consumer that only carries the descriptor
    /// spelling, like a frame's named reference, keeps the bytes it read.
    Object(JvmBytes),
}

/// One component of a descriptor: what it names, how many array dimensions it has, and the bytes
/// it was read from (JVMS 4.3.2).
///
/// A component is the whole of what one parameter, one field type or one return type states, so a
/// caller never reads a descriptor itself. The two facts a consumer above needs and the bytes alone
/// do not give are [`Self::slots`] — the local slots a value of this type fills — and
/// [`Self::object_name`], the class an array's element or a reference names.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DescriptorComponent {
    base: Base,
    dimensions: u32,
    span: ByteSpan,
}

impl DescriptorComponent {
    /// The primitive or object type this component's base is.
    pub fn base(&self) -> &Base {
        &self.base
    }

    /// The component's array dimensions: `0` for a base type written on its own, and one per `[`.
    pub fn dimensions(&self) -> u32 {
        self.dimensions
    }

    /// Whether the component is an array (`[`-prefixed).
    pub fn is_array(&self) -> bool {
        self.dimensions > 0
    }

    /// The byte range of this component inside the descriptor [`descriptor_facts`] read.
    pub fn span(&self) -> ByteSpan {
        self.span.clone()
    }

    /// This component's own bytes, inside the descriptor they were read from.
    ///
    /// The span is stated relative to the descriptor the facts were read from, so this is the one
    /// way a consumer cuts a component out of it: `None` exactly when `descriptor` is another
    /// buffer than that one.
    pub fn bytes<'a>(&self, descriptor: &'a [u8]) -> Option<&'a [u8]> {
        let start = usize::try_from(self.span.start).ok()?;
        let end = start.checked_add(usize::try_from(self.span.length).ok()?)?;
        descriptor.get(start..end)
    }

    /// The object type this component names, whatever its dimensions: `[[Ljava/lang/String;` names
    /// `java/lang/String`, and a primitive component names no class at all.
    ///
    /// An empty name is published as the empty bytes it is: `L;` states a reference component whose
    /// interior is not a binary name (JVMS 4.2), and the component states the bytes rather than
    /// deciding what a type position may write. [`DescriptorFacts`] keeps it and the consumers that
    /// publish a *type* refuse it.
    pub fn object_name(&self) -> Option<&JvmBytes> {
        match &self.base {
            Base::Object(name) => Some(name),
            Base::Primitive(_) => None,
        }
    }

    /// The local slots one value of this type fills (JVMS 2.6.1).
    ///
    /// A `long` or a `double` fills two slots, and **every other component fills one** — an array
    /// is a reference whatever its element type, so `[J` and `[[D` each fill one slot just as `[I`
    /// does. Slot occupancy is a fact of the type and not of its bytes: the next parameter starts
    /// after this many slots, which is the rule every consumer of this type must use.
    pub fn slots(&self) -> u16 {
        if self.dimensions > 0 {
            return 1;
        }
        match self.base {
            Base::Primitive(base) if base.is_category_two() => 2,
            _ => 1,
        }
    }
}

/// One descriptor read once, as the facts its production states (JVMS 4.3.2/4.3.3).
///
/// A `Field` or `Return` descriptor is one [`Self::single`] component (`None` for a return
/// descriptor's `V`); a `Method` descriptor is its [`Self::parameters`] in declaration order plus
/// its [`Self::result`]. Which of the two shapes a value is comes from [`DescriptorKind`], and the
/// components are the same in either case, so a consumer of one descriptor kind never walks bytes.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DescriptorFacts {
    kind: DescriptorKind,
    single: Option<DescriptorComponent>,
    parameters: Vec<DescriptorComponent>,
    result: Option<DescriptorComponent>,
}

impl DescriptorFacts {
    /// The production this descriptor was read as.
    pub fn kind(&self) -> DescriptorKind {
        self.kind
    }

    /// A `Field` descriptor's one field type, or a `Return` descriptor's one type.
    pub fn single(&self) -> Option<&DescriptorComponent> {
        self.single.as_ref()
    }

    /// A `Method` descriptor's parameters, in declaration order: the position of a parameter in
    /// this list is its position in the descriptor.
    pub fn parameters(&self) -> &[DescriptorComponent] {
        &self.parameters
    }

    /// A `Method` descriptor's result type, or `None` for `V`.
    pub fn result(&self) -> Option<&DescriptorComponent> {
        self.result.as_ref()
    }

    /// Every component this descriptor names, in the order the bytes write them: the parameters and
    /// then the result of a method descriptor, and the one component of a field or return
    /// descriptor.
    pub fn components(&self) -> impl Iterator<Item = &DescriptorComponent> {
        self.single
            .iter()
            .chain(self.parameters.iter())
            .chain(self.result.iter())
    }

    /// How many local slots the parameters occupy together (JVMS 2.6.1), or `None` when they do
    /// not fit the `u16` a local index is.
    ///
    /// This is the parameters' own occupancy and **excludes a receiver**: `this` is a fact of the
    /// member's flags and not of its descriptor, so the layer that states the member's slots is the
    /// one that adds it.
    pub fn parameter_slots(&self) -> Option<u16> {
        self.parameters.iter().try_fold(0u16, |slots, component| {
            slots.checked_add(component.slots())
        })
    }
}

/// One field, method or return descriptor read whole (JVMS 4.3).
///
/// A descriptor that does not parse exactly is a structured error instead of a partial set of
/// components, so a caller can never publish a fact about a descriptor it did not read completely —
/// and there is only one reader of the production, so two consumers of the same descriptor cannot
/// read its slots or its names differently.
pub fn descriptor_facts(descriptor: &[u8], kind: DescriptorKind) -> Result<DescriptorFacts> {
    let mut cursor = DescriptorCursor::new(descriptor);
    let mut facts = DescriptorFacts {
        kind,
        single: None,
        parameters: Vec::new(),
        result: None,
    };
    match kind {
        DescriptorKind::Field => facts.single = Some(cursor.field_type()?),
        DescriptorKind::Return => facts.single = cursor.return_type()?,
        DescriptorKind::Method => {
            cursor.expect_byte(b'(')?;
            while cursor.peek() != Some(b')') {
                facts.parameters.push(cursor.field_type()?);
            }
            cursor.expect_byte(b')')?;
            facts.result = cursor.return_type()?;
        }
    }
    cursor.expect_end()?;
    Ok(facts)
}

/// Object types a field, method or return descriptor names, in first-appearance order and
/// once per descriptor.
///
/// JVMS 4.3: a descriptor is built from base types, `L<internal name>;` and `[` arrays.
/// Only the object types are class references, and an array names its element type, so
/// `[[Ljava/lang/String;` mentions `java/lang/String`. A descriptor that does not parse
/// exactly is a structured error instead of a partial type set, so a caller can never
/// publish the types of a descriptor it did not read completely.
///
/// One shape the production parses does not name a type: `L;` — and every array of it — states a
/// reference component whose interior is empty, and JVMS 4.2 says a binary name is not empty. A
/// descriptor carrying one is a structured error here, where a *type* would be published, and the
/// same bytes stay readable as a component through [`descriptor_facts`].
///
/// This is [`descriptor_facts`] projected onto the names: one reader of the production, so the
/// object types a consumer publishes and the slots a consumer derives can never come from two
/// different readings of the same bytes.
#[allow(dead_code)]
pub fn descriptor_types(descriptor: &[u8], kind: DescriptorKind) -> Result<Vec<JvmBytes>> {
    let facts = descriptor_facts(descriptor, kind)?;
    let mut types = Vec::new();
    for component in facts.components() {
        let Some(name) = component.object_name() else {
            continue;
        };
        if name.0.is_empty() {
            return Err(Error::invalid_input(
                DESCRIPTOR_CODE,
                format!(
                    "object type name is empty (at byte {} of the region)",
                    component.span().start
                ),
            ));
        }
        push_unique(&mut types, name.0.clone());
    }
    Ok(types)
}

/// Adds an object type once per descriptor.
///
/// Descriptor productions and generic signatures both name a type once, in the order the
/// bytes write it, so they share this rule.
#[allow(dead_code)]
pub fn push_unique(types: &mut Vec<JvmBytes>, name: Vec<u8>) {
    if !types.iter().any(|existing| existing.0 == name) {
        types.push(JvmBytes(name));
    }
}

/// Bounded cursor over one descriptor.
///
/// The reader owns the same guarantees as the metadata consumer's region reader: every
/// read is bounds-checked, and a caller must reach [`DescriptorCursor::expect_end`], so a
/// descriptor that does not end exactly at its end is an error instead of a truncated
/// type set.
///
/// The whole-descriptor entry point is [`descriptor_facts`]; this cursor is for the two callers
/// that read one component of a longer buffer — a descriptor read at an offset — and it is the
/// same reader, so a component read through it is the component [`descriptor_facts`] would state.
pub struct DescriptorCursor<'a> {
    bytes: &'a [u8],
    at: usize,
}

impl<'a> DescriptorCursor<'a> {
    /// A cursor at the start of one descriptor.
    pub const fn new(bytes: &'a [u8]) -> Self {
        Self { bytes, at: 0 }
    }

    /// A cursor at one offset of a buffer, for a caller that already knows where a component
    /// starts (the position [`Self::position`] answered for the component before it).
    pub const fn at_offset(bytes: &'a [u8], at: usize) -> Self {
        Self { bytes, at }
    }

    /// How many bytes this cursor has read.
    pub const fn position(&self) -> usize {
        self.at
    }

    /// One field type, read whole (JVMS 4.3.2).
    pub fn field_type(&mut self) -> Result<DescriptorComponent> {
        let start = self.at;
        let mut dimensions = 0u32;
        while self.peek() == Some(b'[') {
            self.skip(1)?;
            dimensions = dimensions
                .checked_add(1)
                .ok_or_else(|| self.malformed("descriptor component has too many dimensions"))?;
        }
        let base = match self.peek() {
            Some(b'B') => Base::Primitive(BaseType::Byte),
            Some(b'C') => Base::Primitive(BaseType::Char),
            Some(b'D') => Base::Primitive(BaseType::Double),
            Some(b'F') => Base::Primitive(BaseType::Float),
            Some(b'I') => Base::Primitive(BaseType::Int),
            Some(b'J') => Base::Primitive(BaseType::Long),
            Some(b'S') => Base::Primitive(BaseType::Short),
            Some(b'Z') => Base::Primitive(BaseType::Boolean),
            Some(b'L') => Base::Object(JvmBytes(self.object_name()?)),
            _ => return Err(self.malformed("descriptor component is not a field type")),
        };
        if matches!(base, Base::Primitive(_)) {
            self.skip(1)?;
        }
        Ok(DescriptorComponent {
            base,
            dimensions,
            span: ByteSpan::new(
                u64::try_from(start).map_err(|_| self.malformed("descriptor is too long"))?,
                u64::try_from(self.at - start)
                    .map_err(|_| self.malformed("descriptor is too long"))?,
            ),
        })
    }

    /// A `ReturnDescriptor`: `V` or a field type.
    pub fn return_type(&mut self) -> Result<Option<DescriptorComponent>> {
        if self.peek() == Some(b'V') {
            self.skip(1)?;
            return Ok(None);
        }
        self.field_type().map(Some)
    }

    /// Whether this cursor reached the end of its bytes.
    pub fn expect_end(&self) -> Result<()> {
        if self.at == self.bytes.len() {
            Ok(())
        } else {
            Err(self.malformed("structure does not end at the region end"))
        }
    }

    fn peek(&self) -> Option<u8> {
        self.bytes.get(self.at).copied()
    }

    fn skip(&mut self, count: usize) -> Result<()> {
        let end = self
            .at
            .checked_add(count)
            .ok_or_else(|| self.malformed("region length overflow"))?;
        self.bytes
            .get(self.at..end)
            .ok_or_else(|| self.malformed("region ends before the structure does"))?;
        self.at = end;
        Ok(())
    }

    fn expect_byte(&mut self, expected: u8) -> Result<()> {
        let found = self
            .peek()
            .ok_or_else(|| self.malformed("region ends before the structure does"))?;
        if found == expected {
            self.at += 1;
            Ok(())
        } else {
            Err(self.malformed(&format!(
                "expected byte {:?} but found {:?}",
                char::from(expected),
                char::from(found)
            )))
        }
    }

    /// One descriptor object type's interior: `L <bytes> ;`.
    ///
    /// The bytes are returned as written, empty included: the production says where the name ends,
    /// and what an empty interior *is* — no binary name at all, JVMS 4.2 — is the publisher's rule
    /// and not this reader's ([`Base::Object`]).
    fn object_name(&mut self) -> Result<Vec<u8>> {
        self.expect_byte(b'L')?;
        let start = self.at;
        while let Some(byte) = self.peek() {
            if byte == b';' {
                break;
            }
            self.at += 1;
        }
        let name = self.bytes[start..self.at].to_vec();
        self.expect_byte(b';')?;
        Ok(name)
    }

    fn malformed(&self, message: &str) -> Error {
        Error::invalid_input(
            DESCRIPTOR_CODE,
            format!("{message} (at byte {} of the region)", self.at),
        )
    }
}

// ---------------------------------------------------------------------------
// Nested attributes
// ---------------------------------------------------------------------------

/// One nested `attribute_info`: inside a `Code` attribute or inside one `record_component_info`
/// (JVMS 4.7.30).
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NestedAttributeFact {
    /// `attribute_name_index` exactly as the declaration records it.
    pub name_index: u16,
    /// Raw name bytes of that index; a name is never text-decoded here.
    pub name: JvmBytes,
    /// Byte range of the whole nested `attribute_info`, header included.
    pub span: ByteSpan,
    /// Byte range of the nested attribute content.
    pub content_span: ByteSpan,
}

/// Reads the nested `attribute_info` list of one method's `Code` attribute (JVMS 4.7.3).
///
/// # Scope
///
/// A method body holds metadata of its own — `LineNumberTable`, `LocalVariableTable`,
/// `StackMapTable` and the type annotations a compiler moves inside the body — and a
/// consumer that answers for a standard position there cannot invent that structure from
/// the member header's shells. This is the reader fact that walks it:
/// `max_stack`, `max_locals`, `code_length` and the code array are **measured, never
/// decoded** (no instruction is interpreted, no `CodeBytes` is charged, and no graph is
/// built), then the exception table, the attribute count and each nested declaration.
/// The nested attributes are read only because this function is called at all: no other
/// reader fact touches them.
///
/// `shells` is the `MemberHeader::attributes` of the method, the same input
/// [`attribute_facts`] takes. A member that declares no `Code` yields an empty list: no
/// body is a normal declaration shape, not a failure. Two `Code` attributes are refused
/// with `classfile_duplicate_code_attribute`, because no single body is meant then.
///
/// # Billing
///
/// One `AttributeBytes` charge for the `Code` entry, `6 + content length`, exactly like
/// [`attribute_content`] and [`method_code_facts`] bill the same entry. The nested
/// content is inside that charge and is read through [`attribute_slice`], which bills
/// nothing, so walking a body's metadata costs one pass over the `Code` entry.
///
/// # Errors
///
/// * `classfile_duplicate_code_attribute` — the member declares more than one `Code`.
/// * `classfile_code_out_of_bounds` — the declared code array does not fit the content.
/// * `classfile_invalid_attribute_content` — the declared structure ends before the
///   content does (an exception table, an attribute count or a nested declaration that
///   the remaining bytes cannot hold), or the content has trailing bytes no declaration
///   covers.
///
/// Every nested `attribute_info` is reported by its own `attribute_name_index`, raw name
/// bytes and class-file spans, so a caller can slice both the content and the entry out
/// of the class bytes and check its own reading of them.
#[allow(dead_code)]
pub fn code_nested_attributes(
    bytes: &[u8],
    shells: &[AttributeShell],
    pool: &[CpEntryFacts],
    budget: &mut Budget,
) -> Result<Vec<NestedAttributeFact>> {
    let mut code_shells = shells
        .iter()
        .filter(|shell| shell.name.raw().0.as_slice() == b"Code");
    let shell = match (code_shells.next(), code_shells.next()) {
        // An abstract or native member has no body at all: nothing to read, and nothing
        // to report as damage.
        (None, _) => return Ok(Vec::new()),
        (Some(_), Some(_)) => {
            return Err(Error::invalid_input(
                "classfile_duplicate_code_attribute",
                "selected method has multiple Code attributes",
            ));
        }
        (Some(shell), None) => shell,
    };
    budget.poll()?;
    let content = attribute_slice(bytes, &shell.span, &shell.content_span)?;
    budget.charge(
        CountedBudgetDimension::AttributeBytes,
        attribute_shell_length(&shell.content_span)?,
    )?;
    let mut reader = AttributeReader::new(content);
    reader.skip(4)?; // max_stack, max_locals
    let code_length = usize::try_from(reader.u32()?).map_err(|_| {
        Error::invalid_input(
            "classfile_code_out_of_bounds",
            "code length does not fit a byte range",
        )
    })?;
    let code_end = reader.position.checked_add(code_length).ok_or_else(|| {
        Error::invalid_input("classfile_span_overflow", "code array end overflow")
    })?;
    if code_end > content.len() {
        return Err(Error::invalid_input(
            "classfile_code_out_of_bounds",
            "code array exceeds Code attribute content",
        ));
    }
    reader.skip(code_length)?;
    let handlers = usize::from(reader.u16()?);
    reader.skip(
        handlers
            .checked_mul(8)
            .ok_or_else(|| span_overflow("exception table length"))?,
    )?;
    let attributes = usize::from(reader.u16()?);
    let mut nested = Vec::new();
    for _ in 0..attributes {
        budget.poll()?;
        let start = entry_offset(&shell.content_span, reader.position)?;
        let name_index = reader.u16()?;
        let length = u64::from(reader.u32()?);
        let length_usize = usize::try_from(length).map_err(|_| {
            Error::invalid_input(
                "classfile_invalid_attribute_content",
                "nested attribute length does not fit a byte range",
            )
        })?;
        let content_start = entry_offset(&shell.content_span, reader.position)?;
        reader.skip(length_usize)?;
        let end = entry_offset(&shell.content_span, reader.position)?;
        nested.push(NestedAttributeFact {
            name_index,
            name: cp_utf8(pool, name_index)?,
            span: ByteSpan::new(start, end - start),
            content_span: ByteSpan::new(content_start, length),
        });
    }
    reader.expect_end()?;
    Ok(nested)
}

/// Class-file offset of one position inside an attribute content.
pub(crate) fn entry_offset(content_span: &ByteSpan, position: usize) -> Result<u64> {
    let position = u64::try_from(position).map_err(|_| {
        Error::invalid_input(
            "classfile_span_overflow",
            "attribute content position does not fit u64",
        )
    })?;
    content_span
        .start
        .checked_add(position)
        .ok_or_else(|| span_overflow("nested attribute offset"))
}

/// One method body decoded as reusable facts.
///
/// The instructions are the same facts `inspect_method_bytecode` returns for the same
/// method — same noak-backed cursor, same width, span and constant-pool index
/// derivation — because both go through the same internal decode path. What differs is
/// the contract around them: the caller already billed `ClassBytes` through
/// `class_facts`, `ResultItems` is never charged here, and a body that stopped before
/// the end of its `Code` attribute returns its reliable prefix together with
/// `execution` and `stopped_at` instead of a [`BytecodeInspection`].
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MethodCodeFacts {
    pub max_stack: u16,
    pub max_locals: u16,
    /// Class-file range of the instruction array: `code_length` bytes starting at the
    /// first opcode, so a BCI becomes a class offset by adding `code_span.start`.
    pub code_span: ByteSpan,
    pub instructions: Vec<InstructionFact>,
    /// Typed operands of [`Self::instructions`], in lockstep: `operands[i]` describes
    /// `instructions[i]`, and any stop returns the same reliable prefix of both.
    operands: Vec<InstructionOperands>,
    /// The whole exception table. Handlers are decoded before instructions, exactly
    /// like `inspect_method_bytecode`, so these are complete even when the instruction
    /// stream is the phase that stopped.
    pub exception_handlers: Vec<ExceptionHandlerFact>,
    /// Exception-table size the `Code` attribute declares.
    ///
    /// The same fact [`BytecodeInspection::exception_handler_count`] carries: with
    /// [`Self::stopped_at`] in [`BytecodeStopPhase::ExceptionHandlers`] the list above is a
    /// prefix of this count, and a consumer that publishes a coverage plane needs the total
    /// to name the range it did not read.
    pub exception_handler_count: u32,
    pub execution: ExecutionReport,
    pub stopped_at: Option<BytecodeStop>,
    /// The body's own debug names, read from the `LocalVariableTable` this `Code` attribute may
    /// declare (P3 3.1).
    ///
    /// The table is **inside** the `Code` entry this read already decoded and charged for, so reading
    /// it here is the same read: one slice of the bytes, one `AttributeBytes` charge, no second truth
    /// about one body. `MethodParameters` is deliberately not read: it is a *method-level* attribute
    /// whose content lies outside the `Code` entry, so decoding it here would charge bytes this read
    /// has not billed — that is a reader-contract decision with its own accounting, not something to
    /// slip in beside a body read.
    debug: LocalDebugTable,
    /// Generic local signatures from the same `Code` attribute (DT-20).
    generic_debug: LocalDebugTypeTable,
}

/// The debug names one method body's `Code` attribute states (P3 3.1).
///
/// Three states, because "no name" and "no table" are different facts: a body compiled without debug
/// metadata declares nothing, and a read that did not produce a table (its content does not decode,
/// or the body stopped before the walk) states none. Neither is a failure of the body — the
/// instructions decoded — and the presentation names the slots by their ordinals in both cases (A10).
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum LocalDebugTable {
    /// The `Code` attribute declares no `LocalVariableTable`: the walk completed and found none.
    Absent,
    /// The table as the one read decoded it, in declaration order.
    Read(Vec<LocalDebugName>),
    /// The walk produced no table: a declared table whose content the bytes cannot hold, or a body
    /// read that stopped before it walked the nested attributes. No name is stated for either.
    Unstated,
}

/// One record of a `LocalVariableTable` (JVMS 4.7.13).
///
/// The record names one slot **over a range of bytecode**: a compiler that reuses a slot for two
/// variables in disjoint scopes states two records for it, which is why the range is kept — it is
/// what tells one reused slot from one variable named twice.
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LocalDebugName {
    /// The local slot the record names.
    pub slot: u16,
    /// The first bytecode index the record covers.
    pub start_bci: u32,
    /// One past the last bytecode index the record covers.
    pub end_bci: u32,
    /// The name, exactly as the class file's own constant spells it (JVM bytes, never text-decoded
    /// here).
    pub name: JvmBytes,
    /// The erased field descriptor stated beside the name.
    pub descriptor: JvmBytes,
}

/// Generic local signatures a method body's `Code` attribute states.
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum LocalDebugTypeTable {
    /// No `LocalVariableTypeTable` was declared.
    Absent,
    /// Records from the one decoded table, in declaration order.
    Read(Vec<LocalDebugType>),
    /// The table was duplicated, malformed, or could not be resolved completely.
    Unstated,
}

/// One raw `LocalVariableTypeTable` entry (JVMS 4.7.14).
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LocalDebugType {
    /// The local slot this record describes.
    pub slot: u16,
    /// The first bytecode index the record covers.
    pub start_bci: u32,
    /// One past the last bytecode index the record covers.
    pub end_bci: u32,
    /// The local name as raw JVM bytes.
    pub name: JvmBytes,
    /// The Signature payload as raw JVM bytes.
    pub signature: JvmBytes,
}

impl LocalDebugName {
    /// The name, as the text a presentation would write when it is one.
    ///
    /// A name that is not UTF-8 is not text this layer can spell: the caller decides what to do with
    /// it (a name no Java identifier grammar accepts is aliased, never dropped — see
    /// `jarde-java`'s naming rules).
    pub fn name_lossy(&self) -> String {
        String::from_utf8_lossy(&self.name.0).into_owned()
    }
}

impl MethodCodeFacts {
    /// Typed operands of [`Self::instructions`], in lockstep with them.
    ///
    /// `operands()[i]` describes `instructions[i]`; the two lists are decoded together and a
    /// stop returns the same reliable prefix of both. The field itself stays private so that no
    /// caller can build the two lists apart: the length agreement is the invariant the decode
    /// path asserts after every body it reads, and a public field would let a consumer assemble
    /// facts the reader never produced.
    pub fn operands(&self) -> &[InstructionOperands] {
        &self.operands
    }

    /// The body's own debug names, as the same read decoded them (P3 3.1).
    ///
    /// The `LocalVariableTable` sits inside the `Code` entry this read already charged for, so this
    /// is not a second read: the bytes are the ones [`Self::code_span`] and the instruction array
    /// came from, and no additional dimension is billed for them.
    pub fn debug(&self) -> &LocalDebugTable {
        &self.debug
    }

    /// The body's generic local signatures, read from the same `Code` attribute.
    pub fn generic_debug(&self) -> &LocalDebugTypeTable {
        &self.generic_debug
    }

    /// Assembles a body from parts a test names, without a decode; test support only.
    ///
    /// This is the one way to build facts the decode path did not produce, and it exists for the
    /// same reason [`Self::operands`] is an accessor instead of a field: the fixtures of a
    /// dependent crate's analysis tests (CFG, call contexts) need a body, and their `cfg(test)`
    /// cannot see this crate. The instruction/operand pair list is the parameter, not two
    /// separate lists, so the lockstep survives even on this path.
    ///
    /// It is compiled only under `test-support`, which no normal dependency enables: a
    /// production build cannot fabricate a `MethodCodeFacts`, and `--all-features` builds (CI)
    /// are the only ones that see it at all.
    #[cfg(any(test, feature = "test-support"))]
    #[expect(
        clippy::too_many_arguments,
        reason = "a test-only assembler mirrors the fields of the facts it builds; bundling \
                  them into a second public struct would grow the test-support API for no gain"
    )]
    pub fn from_parts(
        max_stack: u16,
        max_locals: u16,
        code_span: ByteSpan,
        code: Vec<(InstructionFact, InstructionOperands)>,
        exception_handlers: Vec<ExceptionHandlerFact>,
        exception_handler_count: u32,
        execution: ExecutionReport,
        stopped_at: Option<BytecodeStop>,
        // The debug names the assembled body stands for, if the fixture states any.
        debug: LocalDebugTable,
    ) -> Self {
        let (instructions, operands) = code.into_iter().unzip();
        Self {
            max_stack,
            max_locals,
            code_span,
            instructions,
            operands,
            exception_handlers,
            exception_handler_count,
            execution,
            stopped_at,
            debug,
            generic_debug: LocalDebugTypeTable::Unstated,
        }
    }
}

/// Typed operands of one instruction, taken from the same noak event and the same
/// instruction byte range that produced the matching [`InstructionFact`].
///
/// The mapping is total: a field is `None` exactly when the instruction has no operand
/// of that kind, so an instruction without operands (`pop`, `return`, `dup`, …) is
/// all-`None` rather than absent. Implicit operands are facts too — the `_0`..`_3`
/// load/store forms name their local, the `iconst`/`lconst`/`fconst`/`dconst` forms
/// name their constant, and `wide` marks the widened form — so 3.x never has to
/// re-derive them from the raw opcode or from rendered text.
///
/// [`InstructionOperands::default`] is that all-`None` shape, and its
/// [`Self::effective_opcode`] is `0x00`: a fixture that builds operands from `Default`
/// must set the effective opcode it stands for, while the reader always fills it from the
/// event it decoded.
///
/// [`Self::atype`], [`Self::dimensions`] and [`Self::interface_count`] are payload facts of
/// three specific opcodes, deliberately not folded into [`Self::immediate`]: an element
/// type code is not a value an instruction pushes, a dimension count is not a constant pool
/// entry, and an `invokeinterface` count is a claim the verifier has to reconcile with the
/// descriptor instead of trusting.
///
/// This is crate-private reader data: it does not appear in [`BytecodeInspection`] and
/// it is covered by the `CodeBytes` charge of the instruction it belongs to, with no
/// extra dimension and no second charge.
#[allow(dead_code)]
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct InstructionOperands {
    /// `bipush`/`sipush`, the `ldc` family, and the constant forms encoded in the opcode.
    pub immediate: Option<ImmediateValue>,
    /// The local of a load, store, `iinc` or `ret`, including the implicit forms.
    pub local: Option<LocalOperand>,
    /// Signed increment of `iinc` and `wide iinc`; `None` for every other opcode.
    pub increment: Option<i32>,
    /// Same value as [`InstructionFact::constant_pool_index`] of the same instruction.
    pub constant_pool_index: Option<u16>,
    /// Relative offset exactly as encoded by a branch, `goto_w`, `jsr` or `jsr_w`:
    /// relative to the BCI of the instruction itself.
    pub branch_offset: Option<i32>,
    /// Payload of `tableswitch`/`lookupswitch`; `None` for every other opcode.
    pub switch: Option<SwitchOperands>,
    /// The opcode this instruction *is*: the opcode a `wide` form wraps (`wide iload` is
    /// `0x15`, `wide iinc` is `0x84`), and the raw opcode for every other instruction.
    ///
    /// This is the opcode classifications read — block ends, transfers, `may_throw`, local
    /// read/write direction, stack deltas and the legacy dialect — because `0xc4` is a prefix
    /// (JVMS 6.5), not an instruction: it decides none of them on its own. The raw opcode stays
    /// what it always was in [`InstructionFact::opcode`], together with the width and the span.
    pub effective_opcode: u8,
    /// `newarray`'s element type code (JVMS `atype`, 4..=11); `None` for every other opcode.
    /// The reader records it as encoded: an out-of-range code never reaches here, because the
    /// instruction does not decode at all.
    pub atype: Option<u8>,
    /// `multianewarray`'s dimension count exactly as encoded; `None` for every other opcode.
    /// Whether the count is a legal dimension is the verifier's question (4.x), not a reason
    /// for the reader to drop the fact or to fail the instruction.
    pub dimensions: Option<u8>,
    /// `invokeinterface`'s encoded `count`; `None` for every other opcode.
    ///
    /// A validation *fact*, not a trust source: the count is kept as encoded — including a
    /// count that disagrees with the descriptor's argument slots — so 5.1 can reconcile it
    /// against this project's own descriptor derivation.
    pub interface_count: Option<u8>,
}

/// The literal one instruction pushes directly.
///
/// Floating point keeps its bit pattern, so a NaN payload or a negative zero survives
/// the fact. Reference constants are not literals here: `ldc` of a `String`, `Class`,
/// `MethodHandle`, `MethodType` or dynamic constant keeps its
/// [`InstructionOperands::constant_pool_index`] for the resolver instead.
#[allow(dead_code)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ImmediateValue {
    Int(i32),
    Long(i64),
    Float(u32),
    Double(u64),
}

/// One local variable slot named by an instruction.
#[allow(dead_code)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct LocalOperand {
    /// Local slot index in the method's frame.
    pub index: u16,
    /// `true` for the `wide` prefixed form, `false` for the short form and for the
    /// `_0`..`_3` forms, whose index is encoded in the opcode.
    pub wide: bool,
}

/// Payload of one `tableswitch`/`lookupswitch`.
///
/// The per-entry offsets are read from the instruction's own byte range instead of
/// iterating noak's pair iterators: `TablePairs` walks an `i32` key toward a hostile
/// `high`, which is the upper-bound risk the reader adapter deliberately keeps out.
#[allow(dead_code)]
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SwitchOperands {
    Table {
        default_offset: i32,
        low: i32,
        high: i32,
        /// One relative offset per key, in payload order (`low` first).
        offsets: Vec<i32>,
    },
    Lookup {
        default_offset: i32,
        /// `(match, offset)` in payload order.
        pairs: Vec<(i32, i32)>,
    },
}

/// One control-flow target of one method, validated but not yet a graph edge.
#[allow(dead_code)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ControlFlowTarget {
    /// The instruction this row belongs to: the branch or switch instruction that
    /// encodes the offset, and the handler entry for [`ControlFlowTargetKind::Handler`]
    /// — an exception table record is not an instruction, and its `ordinal` in the
    /// kind identifies the record.
    pub instruction_bci: u32,
    pub kind: ControlFlowTargetKind,
    /// Absolute BCI the target must land on: an instruction start inside the code array.
    pub target_bci: u32,
}

#[allow(dead_code)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ControlFlowTargetKind {
    /// A relative branch offset, kept exactly as encoded.
    Branch {
        offset: i32,
    },
    SwitchDefault,
    /// `index` is the position in the switch payload; `key` is `low + index` for
    /// `tableswitch` and the encoded `match` for `lookupswitch`.
    SwitchCase {
        index: u32,
        key: i32,
    },
    /// Exception table record `ordinal`.
    Handler {
        ordinal: u32,
    },
}

impl MethodCodeFacts {
    /// Every control-flow target of this method, validated against the instruction
    /// starts of the same facts. No CFG is built: these are the evidenced targets 3.x
    /// consumes when it builds one.
    ///
    /// Rows come out in instruction order — a switch emits its default before its
    /// cases — followed by the exception table in ordinal order. Validation is per row
    /// and stops at the first failure, so the error always carries the original BCI:
    ///
    /// * a relative offset that leaves the code address space is
    ///   `classfile_code_span_overflow`, and one that lands before BCI 0 is
    ///   `classfile_instruction_target_out_of_bounds`;
    /// * a target at or past `code_length` is `classfile_instruction_target_out_of_bounds`;
    /// * a target that is not an instruction start is `classfile_instruction_invalid_target`;
    /// * a protected range that ends past `code_length`, is inverted, or is empty is
    ///   `classfile_exception_range_invalid`, while a range endpoint that is not an
    ///   instruction start is `classfile_instruction_invalid_target`; `end == code_length`
    ///   is the legal half-open end of the code array and needs no instruction start.
    ///
    /// A body whose instruction stream stopped early is validated on the facts it has:
    /// this is a **reliable but incomplete** view. It never accepts an illegal target,
    /// but a legal target inside the unread suffix reads as invalid. A caller MUST check
    /// `execution`/`stopped_at` before reporting this `Err` as a corrupt method; 3.x
    /// tightens the type-level guarantee only if it needs one.
    #[allow(dead_code)]
    pub fn control_flow_targets(&self) -> Result<Vec<ControlFlowTarget>> {
        debug_assert_eq!(
            self.instructions.len(),
            self.operands.len(),
            "operand facts are produced in lockstep with instructions"
        );
        let code_length = u32::try_from(self.code_span.length).map_err(|_| {
            Error::invalid_input(
                "classfile_code_span_overflow",
                "code length does not fit u32",
            )
        })?;
        let starts = InstructionStarts::new(&self.instructions);
        let mut targets = Vec::new();
        for (fact, operands) in self.instructions.iter().zip(self.operands.iter()) {
            if let Some(offset) = operands.branch_offset {
                let target = relative_target_bci(fact.bci, offset)?;
                check_target(
                    &starts,
                    code_length,
                    target,
                    &format!("branch from BCI {} with offset {offset}", fact.bci),
                )?;
                targets.push(ControlFlowTarget {
                    instruction_bci: fact.bci,
                    kind: ControlFlowTargetKind::Branch { offset },
                    target_bci: target,
                });
            }
            match &operands.switch {
                None => {}
                Some(SwitchOperands::Table {
                    default_offset,
                    low,
                    offsets,
                    ..
                }) => {
                    let default = relative_target_bci(fact.bci, *default_offset)?;
                    check_target(
                        &starts,
                        code_length,
                        default,
                        &format!("switch default from BCI {}", fact.bci),
                    )?;
                    targets.push(ControlFlowTarget {
                        instruction_bci: fact.bci,
                        kind: ControlFlowTargetKind::SwitchDefault,
                        target_bci: default,
                    });
                    for (index, offset) in (0u32..).zip(offsets.iter().copied()) {
                        let key = table_key(*low, index)?;
                        let target = relative_target_bci(fact.bci, offset)?;
                        check_target(
                            &starts,
                            code_length,
                            target,
                            &format!("switch case {index} from BCI {}", fact.bci),
                        )?;
                        targets.push(ControlFlowTarget {
                            instruction_bci: fact.bci,
                            kind: ControlFlowTargetKind::SwitchCase { index, key },
                            target_bci: target,
                        });
                    }
                }
                Some(SwitchOperands::Lookup {
                    default_offset,
                    pairs,
                }) => {
                    let default = relative_target_bci(fact.bci, *default_offset)?;
                    check_target(
                        &starts,
                        code_length,
                        default,
                        &format!("switch default from BCI {}", fact.bci),
                    )?;
                    targets.push(ControlFlowTarget {
                        instruction_bci: fact.bci,
                        kind: ControlFlowTargetKind::SwitchDefault,
                        target_bci: default,
                    });
                    for (index, (key, offset)) in (0u32..).zip(pairs.iter().copied()) {
                        let target = relative_target_bci(fact.bci, offset)?;
                        check_target(
                            &starts,
                            code_length,
                            target,
                            &format!("switch case {index} from BCI {}", fact.bci),
                        )?;
                        targets.push(ControlFlowTarget {
                            instruction_bci: fact.bci,
                            kind: ControlFlowTargetKind::SwitchCase { index, key },
                            target_bci: target,
                        });
                    }
                }
            }
        }
        for handler in &self.exception_handlers {
            check_protected_range(&starts, code_length, handler)?;
            targets.push(ControlFlowTarget {
                instruction_bci: handler.handler_bci,
                kind: ControlFlowTargetKind::Handler {
                    ordinal: handler.ordinal,
                },
                target_bci: handler.handler_bci,
            });
        }
        Ok(targets)
    }
}

/// Validates one exception table record: a non-empty half-open protected range of
/// instruction boundaries, and an entry that is a target like any other.
///
/// JVMS 4.7.3 requires `start_pc < end_pc <= code_length`; the endpoints are also
/// instruction boundaries, because an exception region covers instructions and not
/// bytes inside operands. A range that ends after the code or is inverted or empty is
/// a range-relation error (`classfile_exception_range_invalid`); an endpoint that is
/// not a boundary is a target error (`classfile_instruction_invalid_target`), so a
/// caller can tell "this record contradicts the code array" from "this record does not
/// line up with the instruction starts". Only `end_pc == code_length` is legal without
/// being an instruction start: it is the half-open end of the code array.
fn check_protected_range(
    starts: &InstructionStarts<'_>,
    code_length: u32,
    handler: &ExceptionHandlerFact,
) -> Result<()> {
    let ordinal = handler.ordinal;
    if handler.end_bci > code_length {
        return Err(Error::invalid_input(
            "classfile_exception_range_invalid",
            format!(
                "exception handler {ordinal} protected range {}..{} ends past code_length {code_length}",
                handler.start_bci, handler.end_bci
            ),
        ));
    }
    if handler.start_bci > handler.end_bci {
        return Err(Error::invalid_input(
            "classfile_exception_range_invalid",
            format!(
                "exception handler {ordinal} protected range {}..{} starts after its end",
                handler.start_bci, handler.end_bci
            ),
        ));
    }
    if handler.start_bci == handler.end_bci {
        return Err(Error::invalid_input(
            "classfile_exception_range_invalid",
            format!(
                "exception handler {ordinal} protected range at BCI {} is empty",
                handler.start_bci
            ),
        ));
    }
    // `start < end <= code_length` holds here, so both endpoints are inside the code
    // array and can be compared against the instruction starts.
    if !starts.contains(handler.start_bci) {
        return Err(Error::invalid_input(
            "classfile_instruction_invalid_target",
            format!(
                "exception handler {ordinal} protected range start {} is not an instruction start",
                handler.start_bci
            ),
        ));
    }
    if handler.end_bci != code_length && !starts.contains(handler.end_bci) {
        return Err(Error::invalid_input(
            "classfile_instruction_invalid_target",
            format!(
                "exception handler {ordinal} protected range end {} is neither an instruction start nor code_length {code_length}",
                handler.end_bci
            ),
        ));
    }
    check_target(
        starts,
        code_length,
        handler.handler_bci,
        &format!("exception handler {ordinal} entry"),
    )
}

/// The instruction-start set of one method body.
///
/// The facts are ordered by BCI and non-overlapping, so one binary search decides
/// whether a target is an instruction boundary or lands inside an operand.
struct InstructionStarts<'a> {
    instructions: &'a [InstructionFact],
}

impl<'a> InstructionStarts<'a> {
    const fn new(instructions: &'a [InstructionFact]) -> Self {
        Self { instructions }
    }

    fn contains(&self, bci: u32) -> bool {
        self.instructions
            .binary_search_by_key(&bci, |fact| fact.bci)
            .is_ok()
    }
}

/// Validates one absolute target against the code array and the start set.
fn check_target(
    starts: &InstructionStarts<'_>,
    code_length: u32,
    target: u32,
    label: &str,
) -> Result<()> {
    if target >= code_length {
        return Err(Error::invalid_input(
            "classfile_instruction_target_out_of_bounds",
            format!("{label} target {target} is outside 0..{code_length}"),
        ));
    }
    if !starts.contains(target) {
        return Err(Error::invalid_input(
            "classfile_instruction_invalid_target",
            format!("{label} target {target} is not an instruction start"),
        ));
    }
    Ok(())
}

/// Absolute BCI of one encoded relative offset, checked against the unsigned address
/// space in both directions.
fn relative_target_bci(instruction_bci: u32, offset: i32) -> Result<u32> {
    if offset >= 0 {
        instruction_bci
            .checked_add(offset.unsigned_abs())
            .ok_or_else(|| {
                Error::invalid_input(
                    "classfile_code_span_overflow",
                    format!(
                        "relative offset {offset} at BCI {instruction_bci} overflows the code address space"
                    ),
                )
            })
    } else {
        instruction_bci
            .checked_sub(offset.unsigned_abs())
            .ok_or_else(|| {
                Error::invalid_input(
                    "classfile_instruction_target_out_of_bounds",
                    format!(
                        "relative offset {offset} at BCI {instruction_bci} targets a BCI before 0"
                    ),
                )
            })
    }
}

/// `tableswitch` key of one payload position: `low + index`, checked.
fn table_key(low: i32, index: u32) -> Result<i32> {
    let key = i64::from(low) + i64::from(index);
    i32::try_from(key).map_err(|_| {
        Error::invalid_input(
            "classfile_instruction_invalid_range",
            format!("tableswitch key {key} at index {index} does not fit i32"),
        )
    })
}

/// Padding before the first operand field of a `tableswitch`/`lookupswitch`, relative
/// to the instruction's own BCI: its four-byte fields start at the next four-byte
/// boundary after the opcode byte.
fn switch_padding(bci: u32) -> u32 {
    (4 - ((bci + 1) & 3)) & 3
}

/// The `wide` prefix (JVMS 6.5): a modifier of the instruction that follows it, not an
/// instruction of its own.
const OPCODE_WIDE: u8 = 0xc4;

/// The `atype` byte of a `newarray`, from noak's own element type.
///
/// The enum's declaration order is not the encoded one, so the code is mapped explicitly
/// instead of cast: `boolean` is `4`, `long` is `11` (JVMS 6.5 `newarray`).
fn array_type_code(atype: ArrayType) -> u8 {
    match atype {
        ArrayType::Boolean => 4,
        ArrayType::Char => 5,
        ArrayType::Float => 6,
        ArrayType::Double => 7,
        ArrayType::Byte => 8,
        ArrayType::Short => 9,
        ArrayType::Int => 10,
        ArrayType::Long => 11,
    }
}

/// The opcode a decoded instruction really is: the opcode a `wide` form wraps, and the raw
/// opcode of the instruction itself for every other event.
///
/// JVMS 6.5 lets `wide` wrap exactly twelve opcodes, all of which noak decodes into their own
/// event variants, so the mapping is total over the events that carry the prefix; the debug
/// assertion pins that totality if a future noak adds a wrapping this build does not know.
fn effective_opcode(opcode: u8, instruction: &RawInstruction<'_>) -> u8 {
    let effective = match instruction {
        RawInstruction::ILoadW { .. } => 0x15,
        RawInstruction::LLoadW { .. } => 0x16,
        RawInstruction::FLoadW { .. } => 0x17,
        RawInstruction::DLoadW { .. } => 0x18,
        RawInstruction::ALoadW { .. } => 0x19,
        RawInstruction::IStoreW { .. } => 0x36,
        RawInstruction::LStoreW { .. } => 0x37,
        RawInstruction::FStoreW { .. } => 0x38,
        RawInstruction::DStoreW { .. } => 0x39,
        RawInstruction::AStoreW { .. } => 0x3a,
        RawInstruction::IIncW { .. } => 0x84,
        RawInstruction::RetW { .. } => 0xa9,
        _ => opcode,
    };
    debug_assert!(
        opcode != OPCODE_WIDE || effective != opcode,
        "every `wide` event must name the opcode it wraps"
    );
    effective
}

/// Typed operands of one instruction, from the same noak event that produced the
/// matching [`InstructionFact`] (`instruction`) and from the same instruction byte
/// range (`bytes`, exactly the fact's `width`).
///
/// Nothing here walks the code array again or recovers meaning from rendered text: the
/// scalars come from the decoded event and only the switch entry lists, which noak
/// exposes through iterators this adapter does not use, are read from the recorded
/// bytes with checked offsets. Either way the operand region is the region the width
/// already charged as `CodeBytes`.
fn instruction_operands(
    opcode: u8,
    bci: u32,
    instruction: &RawInstruction<'_>,
    bytes: &[u8],
    pool: &noak::reader::cpool::ConstantPool<'_>,
) -> Result<InstructionOperands> {
    let mut operands = InstructionOperands {
        immediate: None,
        local: None,
        increment: None,
        // The same helper and the same slice `InstructionFact` uses, so the two facts
        // cannot disagree.
        constant_pool_index: constant_pool_index(opcode, bytes),
        branch_offset: None,
        switch: None,
        effective_opcode: effective_opcode(opcode, instruction),
        atype: None,
        dimensions: None,
        interface_count: None,
    };
    match instruction {
        // Constants encoded in the opcode itself.
        RawInstruction::IConstM1 => operands.immediate = Some(ImmediateValue::Int(-1)),
        RawInstruction::IConst0 => operands.immediate = Some(ImmediateValue::Int(0)),
        RawInstruction::IConst1 => operands.immediate = Some(ImmediateValue::Int(1)),
        RawInstruction::IConst2 => operands.immediate = Some(ImmediateValue::Int(2)),
        RawInstruction::IConst3 => operands.immediate = Some(ImmediateValue::Int(3)),
        RawInstruction::IConst4 => operands.immediate = Some(ImmediateValue::Int(4)),
        RawInstruction::IConst5 => operands.immediate = Some(ImmediateValue::Int(5)),
        RawInstruction::LConst0 => operands.immediate = Some(ImmediateValue::Long(0)),
        RawInstruction::LConst1 => operands.immediate = Some(ImmediateValue::Long(1)),
        RawInstruction::FConst0 => operands.immediate = Some(ImmediateValue::Float(0f32.to_bits())),
        RawInstruction::FConst1 => operands.immediate = Some(ImmediateValue::Float(1f32.to_bits())),
        RawInstruction::FConst2 => operands.immediate = Some(ImmediateValue::Float(2f32.to_bits())),
        RawInstruction::DConst0 => {
            operands.immediate = Some(ImmediateValue::Double(0f64.to_bits()))
        }
        RawInstruction::DConst1 => {
            operands.immediate = Some(ImmediateValue::Double(1f64.to_bits()))
        }
        // Constants encoded as an operand byte or as a constant-pool index.
        RawInstruction::BIPush { value } => {
            operands.immediate = Some(ImmediateValue::Int(i32::from(*value)));
        }
        RawInstruction::SIPush { value } => {
            operands.immediate = Some(ImmediateValue::Int(i32::from(*value)));
        }
        RawInstruction::LdC { .. } | RawInstruction::LdCW { .. } | RawInstruction::LdC2W { .. } => {
            operands.immediate = operands
                .constant_pool_index
                .and_then(|index| pool_literal(pool, index));
        }
        // Local variable operands named by an operand byte.
        RawInstruction::ALoad { index } => operands.local = Some(short_local(*index)),
        RawInstruction::ALoadW { index } => operands.local = Some(wide_local(*index)),
        RawInstruction::AStore { index } => operands.local = Some(short_local(*index)),
        RawInstruction::AStoreW { index } => operands.local = Some(wide_local(*index)),
        RawInstruction::ILoad { index } => operands.local = Some(short_local(*index)),
        RawInstruction::ILoadW { index } => operands.local = Some(wide_local(*index)),
        RawInstruction::IStore { index } => operands.local = Some(short_local(*index)),
        RawInstruction::IStoreW { index } => operands.local = Some(wide_local(*index)),
        RawInstruction::LLoad { index } => operands.local = Some(short_local(*index)),
        RawInstruction::LLoadW { index } => operands.local = Some(wide_local(*index)),
        RawInstruction::LStore { index } => operands.local = Some(short_local(*index)),
        RawInstruction::LStoreW { index } => operands.local = Some(wide_local(*index)),
        RawInstruction::FLoad { index } => operands.local = Some(short_local(*index)),
        RawInstruction::FLoadW { index } => operands.local = Some(wide_local(*index)),
        RawInstruction::FStore { index } => operands.local = Some(short_local(*index)),
        RawInstruction::FStoreW { index } => operands.local = Some(wide_local(*index)),
        RawInstruction::DLoad { index } => operands.local = Some(short_local(*index)),
        RawInstruction::DLoadW { index } => operands.local = Some(wide_local(*index)),
        RawInstruction::DStore { index } => operands.local = Some(short_local(*index)),
        RawInstruction::DStoreW { index } => operands.local = Some(wide_local(*index)),
        // `iinc` names a local and carries a signed increment.
        RawInstruction::IInc { index, value } => {
            operands.local = Some(short_local(*index));
            operands.increment = Some(i32::from(*value));
        }
        RawInstruction::IIncW { index, value } => {
            operands.local = Some(wide_local(*index));
            operands.increment = Some(i32::from(*value));
        }
        // `ret` names the local holding the return address.
        RawInstruction::Ret { index } => operands.local = Some(short_local(*index)),
        RawInstruction::RetW { index } => operands.local = Some(wide_local(*index)),
        // Array creation: the element type code and the dimension count are payloads of their
        // own kind, taken from the event. Neither is an immediate, and neither is validated
        // here: an element type code outside `4..=11` never reaches this adapter (the
        // instruction does not decode), and a dimension count of zero is a fact 4.x judges.
        RawInstruction::NewArray { atype } => operands.atype = Some(array_type_code(*atype)),
        RawInstruction::MultiANewArray { dimensions, .. } => {
            operands.dimensions = Some(*dimensions);
        }
        // The encoded `count` of an interface call: the third payload byte the event carries.
        RawInstruction::InvokeInterface { count, .. } => {
            operands.interface_count = Some(*count);
        }
        // Relative branch offsets, in the width the opcode encodes.
        RawInstruction::Goto { offset }
        | RawInstruction::JSr { offset }
        | RawInstruction::IfACmpEq { offset }
        | RawInstruction::IfACmpNe { offset }
        | RawInstruction::IfICmpEq { offset }
        | RawInstruction::IfICmpNe { offset }
        | RawInstruction::IfICmpLt { offset }
        | RawInstruction::IfICmpGe { offset }
        | RawInstruction::IfICmpGt { offset }
        | RawInstruction::IfICmpLe { offset }
        | RawInstruction::IfEq { offset }
        | RawInstruction::IfNe { offset }
        | RawInstruction::IfLt { offset }
        | RawInstruction::IfGe { offset }
        | RawInstruction::IfGt { offset }
        | RawInstruction::IfLe { offset }
        | RawInstruction::IfNull { offset }
        | RawInstruction::IfNonNull { offset } => {
            operands.branch_offset = Some(i32::from(*offset));
        }
        RawInstruction::GotoW { offset } | RawInstruction::JSrW { offset } => {
            operands.branch_offset = Some(*offset);
        }
        // Switch payloads: scalars from the event, entry lists from the bytes.
        RawInstruction::TableSwitch(table) => {
            operands.switch = Some(table_switch_operands(
                bci,
                bytes,
                table.default_offset(),
                table.low(),
                table.high(),
            )?);
        }
        RawInstruction::LookupSwitch(lookup) => {
            let pairs = u32::try_from(lookup.pairs().count()).map_err(|_| {
                Error::invalid_input(
                    "classfile_instruction_width_overflow",
                    "lookupswitch pair count overflow",
                )
            })?;
            operands.switch = Some(lookup_switch_operands(
                bci,
                bytes,
                lookup.default_offset(),
                pairs,
            )?);
        }
        _ => {}
    }
    // `xload_0`..`xstore_3` name their local in the opcode: each of the ten families is
    // a block of four opcodes (JVMS 6.2/6.4), so the index is the offset in the block.
    match opcode {
        0x1a..=0x2d => {
            operands.local = Some(LocalOperand {
                index: u16::from((opcode - 0x1a) % 4),
                wide: false,
            })
        }
        0x3b..=0x4e => {
            operands.local = Some(LocalOperand {
                index: u16::from((opcode - 0x3b) % 4),
                wide: false,
            })
        }
        _ => {}
    }
    Ok(operands)
}

/// A short-form local operand: the index fits the byte the opcode encodes.
fn short_local(index: u8) -> LocalOperand {
    LocalOperand {
        index: u16::from(index),
        wide: false,
    }
}

/// A `wide` local operand.
fn wide_local(index: u16) -> LocalOperand {
    LocalOperand { index, wide: true }
}

/// The literal one `ldc`-family index names, when the pool entry is one of the four
/// literal kinds.
///
/// An index the pool does not hold, an entry of another tag, and the reserved slot of a
/// long or double all mean "no literal here": the index itself is the recorded fact,
/// and rejecting the instruction would fail classes the public reader accepts. Resolving
/// those constants is the resolver's job.
fn pool_literal(
    pool: &noak::reader::cpool::ConstantPool<'_>,
    index: u16,
) -> Option<ImmediateValue> {
    use noak::reader::cpool::{Index, Item};
    let at = Index::<Item<'_>>::new(index).ok()?;
    match pool.get(at).ok()? {
        Item::Integer(value) => Some(ImmediateValue::Int(value.value)),
        Item::Long(value) => Some(ImmediateValue::Long(value.value)),
        Item::Float(value) => Some(ImmediateValue::Float(value.value.to_bits())),
        Item::Double(value) => Some(ImmediateValue::Double(value.value.to_bits())),
        _ => None,
    }
}

/// `tableswitch` operands: `default_offset`, `low` and `high` come from the event that
/// also produced the width, and the entry offsets are read from the recorded bytes.
fn table_switch_operands(
    bci: u32,
    bytes: &[u8],
    default_offset: i32,
    low: i32,
    high: i32,
) -> Result<SwitchOperands> {
    let count = i64::from(high)
        .checked_sub(i64::from(low))
        .and_then(|value| value.checked_add(1))
        .filter(|count| *count > 0)
        .ok_or_else(|| {
            Error::invalid_input(
                "classfile_instruction_invalid_range",
                format!("tableswitch at BCI {bci} has a high below its low"),
            )
        })?;
    let count = usize::try_from(count).map_err(|_| {
        Error::invalid_input(
            "classfile_instruction_width_overflow",
            format!("tableswitch entry count at BCI {bci} does not fit usize"),
        )
    })?;
    let entries = switch_entries_start(bci, bytes, 12, count, 4, "tableswitch")?;
    let mut offsets = Vec::with_capacity(count);
    for index in 0..count {
        offsets.push(switch_i32(bytes, bci, entries + index * 4)?);
    }
    Ok(SwitchOperands::Table {
        default_offset,
        low,
        high,
        offsets,
    })
}

/// `lookupswitch` operands: `default_offset` and the pair count come from the event
/// that also produced the width, and the pairs are read from the recorded bytes.
fn lookup_switch_operands(
    bci: u32,
    bytes: &[u8],
    default_offset: i32,
    pairs: u32,
) -> Result<SwitchOperands> {
    let count = usize::try_from(pairs).map_err(|_| {
        Error::invalid_input(
            "classfile_instruction_width_overflow",
            format!("lookupswitch pair count at BCI {bci} does not fit usize"),
        )
    })?;
    let entries = switch_entries_start(bci, bytes, 8, count, 8, "lookupswitch")?;
    let mut collected = Vec::with_capacity(count);
    for index in 0..count {
        let key = switch_i32(bytes, bci, entries + index * 8)?;
        let offset = switch_i32(bytes, bci, entries + index * 8 + 4)?;
        collected.push((key, offset));
    }
    Ok(SwitchOperands::Lookup {
        default_offset,
        pairs: collected,
    })
}

/// Start offset of a switch entry list inside the instruction bytes, after checking
/// that the recorded region is exactly the shape the decoded counts describe.
///
/// The width of the instruction came from the same counts, so a mismatch means the
/// bytes and the event disagree: no operand facts are published for that instruction.
fn switch_entries_start(
    bci: u32,
    bytes: &[u8],
    scalars: usize,
    count: usize,
    unit: usize,
    name: &str,
) -> Result<usize> {
    let start = 1usize
        .checked_add(usize::try_from(switch_padding(bci)).map_err(|_| {
            Error::invalid_input(
                "classfile_code_span_overflow",
                format!("switch padding at BCI {bci} does not fit usize"),
            )
        })?)
        .and_then(|start| start.checked_add(scalars))
        .ok_or_else(|| {
            Error::invalid_input(
                "classfile_code_span_overflow",
                format!("{name} operand offset at BCI {bci} overflows"),
            )
        })?;
    let entries_end = count
        .checked_mul(unit)
        .and_then(|length| start.checked_add(length))
        .ok_or_else(|| {
            Error::invalid_input(
                "classfile_instruction_width_overflow",
                format!("{name} operand region at BCI {bci} overflows"),
            )
        })?;
    if entries_end != bytes.len() {
        return Err(Error::invalid_input(
            "classfile_instruction_shape_mismatch",
            format!(
                "{name} at BCI {bci} has {} recorded bytes but {} entries need {entries_end}",
                bytes.len(),
                count
            ),
        ));
    }
    Ok(start)
}

/// One big-endian `i32` switch operand, checked against the instruction bytes.
fn switch_i32(bytes: &[u8], bci: u32, offset: usize) -> Result<i32> {
    let end = offset
        .checked_add(4)
        .ok_or_else(|| switch_operand_bounds(bytes, bci, offset))?;
    let value = bytes
        .get(offset..end)
        .ok_or_else(|| switch_operand_bounds(bytes, bci, offset))?;
    Ok(i32::from_be_bytes(
        value.try_into().expect("slice length was checked"),
    ))
}

/// Structured error for a switch operand that leaves the instruction bytes.
fn switch_operand_bounds(bytes: &[u8], bci: u32, offset: usize) -> Error {
    Error::invalid_input(
        "classfile_instruction_shape_mismatch",
        format!(
            "switch operand at byte {offset} of BCI {bci} leaves the {} recorded instruction bytes",
            bytes.len()
        ),
    )
}

/// Decodes one method's `Code` attribute as reusable facts.
///
/// # Billing
///
/// * `AttributeBytes` — one charge for the `Code` attribute entry, `6 + content
///   length`, the same entry charge `attribute_content` makes for the same shell.
/// * `CodeBytes` — one charge per decoded instruction width.
/// * `ClassBytes` — **not** charged: the caller already paid it by calling
///   `class_facts` on these same bytes, and this function only re-parses the class
///   structure to reach noak's instruction cursor.
/// * `ResultItems` — never charged. `ResultItems` counts items a public result
///   returns, and the query scan owns that budget.
///
/// # Identity and scope
///
/// `method` is the `class_facts` header of the body to decode. Its raw name and
/// descriptor select the method, and the located `Code` attribute must be the one the
/// header's shells describe, so a header from another class is a structured error
/// instead of a silently wrong body. Only that attribute content is read; instructions
/// are not turned into a graph and no other attribute is decoded.
///
/// A member that declares no `Code` attribute is `Unsupported
/// { classfile_method_has_no_code }`. That absence is a normal declaration shape, not a
/// decode failure, so the caller decides whether to skip the member; the structural
/// check costs no read (`MemberHeader::attributes` already carries the shells).
pub fn method_code_facts(
    bytes: &[u8],
    method: &MemberHeader,
    budget: &mut Budget,
) -> Result<MethodCodeFacts> {
    budget.poll()?;
    // `class_facts` already ran the class-shaped pre-checks on these bytes, so this
    // pass is the structural read only and charges nothing.
    let class = Class::new(bytes).map_err(map_decode_error)?;
    if class.buffer_size() != bytes.len() {
        return Err(Error::invalid_input(
            "classfile_trailing_bytes",
            "class structure has trailing bytes",
        ));
    }
    let pool = class.pool();
    let mut matches = Vec::new();
    for entry in class.methods() {
        budget.poll()?;
        let entry = entry.map_err(map_decode_error)?;
        let name = pool
            .get(entry.name())
            .map_err(map_decode_error)?
            .content
            .as_bytes();
        let descriptor = pool
            .get(entry.descriptor())
            .map_err(map_decode_error)?
            .content
            .as_bytes();
        if name == method.name.raw().0.as_slice()
            && descriptor == method.descriptor.raw().0.as_slice()
        {
            matches.push(entry);
        }
    }
    let candidate = match matches.len() {
        0 => {
            return Err(Error::invalid_input(
                "classfile_method_not_found",
                "no method exactly matched the raw name and descriptor",
            ));
        }
        1 => matches.pop().expect("length checked"),
        _ => {
            return Err(Error::invalid_input(
                "classfile_method_ambiguous",
                "multiple methods exactly matched the raw name and descriptor",
            ));
        }
    };
    let mut code_attributes = Vec::new();
    for attribute in candidate.attributes() {
        budget.poll()?;
        let attribute = attribute.map_err(map_decode_error)?;
        let name = pool
            .get(attribute.name())
            .map_err(map_decode_error)?
            .content
            .as_bytes();
        if name == b"Code" {
            code_attributes.push(attribute);
        }
    }
    let attribute = match code_attributes.len() {
        0 => {
            return Err(Error::unsupported(
                "classfile_method_has_no_code",
                "selected method has no Code attribute",
            ));
        }
        1 => code_attributes.pop().expect("length checked"),
        _ => {
            return Err(Error::invalid_input(
                "classfile_duplicate_code_attribute",
                "selected method has multiple Code attributes",
            ));
        }
    };
    // The one body decode. Everything from the located `Code` entry onwards is
    // [`decode_method_code`], which is also what a prepared class calls: this entry point owns
    // which member record the decode belongs to, never how a body is decoded.
    decode_method_code(bytes, pool, method, &attribute, budget)
}

/// Turns one located `Code` attribute into the facts this crate publishes for a method body.
///
/// This is the **only** body decode in the crate. [`method_code_facts`] reaches it after locating
/// a member by raw name and descriptor and the member's own `Code` entry through the parser;
/// [`crate::prepared::PreparedClass::method_code`] reaches it with the member record and the `Code`
/// entry its own preparation walk already located. Both then do exactly the same work, charge the
/// same dimensions and publish the same [`MethodCodeFacts`], so a body decoded through a prepared
/// class cannot drift from the same body decoded by the single-method entry point.
///
/// `bytes` is the class file every other argument was read from, `pool` is the parser's constant
/// pool (the `Code` entry resolves its own content and its nested debug table through it),
/// `method` is the member record the decode belongs to — the located attribute must be the one its
/// shells describe, so a record from another class is a structured error rather than a silently
/// wrong body — and `attribute` is that `Code` entry itself.
///
/// The charges are the ones the single-method entry point documents: one `AttributeBytes` charge
/// for the `Code` entry's own shell, one `CodeBytes` charge per decoded instruction width, no
/// `ClassBytes` (the class read paid it) and no `ResultItems`.
pub(crate) fn decode_method_code<'a>(
    bytes: &'a [u8],
    pool: &noak::reader::cpool::ConstantPool<'a>,
    method: &MemberHeader,
    attribute: &Attribute<'a>,
    budget: &mut Budget,
) -> Result<MethodCodeFacts> {
    let content = attribute.content();
    let content_span = span_for_slice(bytes, content)?;
    if !member_has_code_shell(method, &content_span) {
        return Err(Error::invalid_input(
            "classfile_method_header_mismatch",
            "the Code attribute of this method does not match the member header's shells",
        ));
    }
    let shell_length = content_span
        .length
        .checked_add(ATTRIBUTE_HEADER_LENGTH as u64)
        .ok_or_else(|| {
            Error::invalid_input("classfile_span_overflow", "Code shell length overflow")
        })?;
    budget.charge(CountedBudgetDimension::AttributeBytes, shell_length)?;

    // `Code` content: max_stack(2) max_locals(2) code_length(4) code[] ...
    let code_offset = 8usize;
    let code_length = read_u32(content, 4)?;
    let code_length_usize = usize::try_from(code_length).map_err(|_| {
        Error::invalid_input(
            "classfile_code_span_overflow",
            "code length does not fit usize",
        )
    })?;
    let code_end = code_offset.checked_add(code_length_usize).ok_or_else(|| {
        Error::invalid_input("classfile_code_span_overflow", "code span overflow")
    })?;
    let code_bytes = content.get(code_offset..code_end).ok_or_else(|| {
        Error::invalid_input(
            "classfile_code_out_of_bounds",
            "code array exceeds Code attribute content",
        )
    })?;
    let code_start = content_span
        .start
        .checked_add(code_offset as u64)
        .ok_or_else(|| {
            Error::invalid_input("classfile_code_span_overflow", "code start overflow")
        })?;
    let code_span = checked_span(bytes, code_start, u64::from(code_length))?;
    let decoded = attribute.read_content(pool).map_err(map_decode_error)?;
    let code = match decoded {
        noak::reader::AttributeContent::Code(code) => code,
        _ => unreachable!("raw Code name selected"),
    };
    // The body's own LVT and LVTT records come from this same `Code` entry. Malformed debug
    // metadata states no name or generic type; it does not change the instruction read's outcome.
    let (debug, generic_debug) = local_debug_tables(&code, pool);

    let exception_handler_count =
        u32::try_from(code.exception_handlers().count()).map_err(|_| {
            Error::invalid_input(
                "classfile_result_overflow",
                "handler count does not fit u32",
            )
        })?;
    let mut handlers = Vec::new();
    for (ordinal, handler) in code.exception_handlers().enumerate() {
        let ordinal = u32::try_from(ordinal).map_err(|_| {
            Error::invalid_input("classfile_result_overflow", "handler ordinal overflow")
        })?;
        if let Err(error) = budget.poll() {
            return stopped_code_facts(
                &code,
                code_span,
                Vec::new(),
                Vec::new(),
                handlers,
                BytecodeStopPosition::ExceptionHandler(ordinal),
                StopFailure::Budget(&error),
                budget,
            );
        }
        handlers.push(ExceptionHandlerFact {
            ordinal,
            start_bci: handler.start().as_u32(),
            end_bci: handler.end().as_u32(),
            handler_bci: handler.handler().as_u32(),
            catch_type_index: handler.catch_type().map(|index| index.as_u16()),
        });
    }

    let mut instructions = Vec::new();
    let mut operands = Vec::new();
    let mut cursor_bci = 0u32;
    for item in code.raw_instructions() {
        if let Err(error) = budget.poll() {
            return stopped_code_facts(
                &code,
                code_span,
                instructions,
                operands,
                handlers,
                BytecodeStopPosition::Instruction(cursor_bci),
                StopFailure::Budget(&error),
                budget,
            );
        }
        let (index, instruction) = match item {
            Ok(value) => value,
            // The noak decode detail is not carried into these facts: the stable code
            // and the stop position are what a consumer reports, and the public path
            // owns the diagnostic rendering of the adapter error.
            Err(_error) => {
                return stopped_code_facts(
                    &code,
                    code_span,
                    instructions,
                    operands,
                    handlers,
                    BytecodeStopPosition::Instruction(cursor_bci),
                    StopFailure::Decode("classfile_instruction_decode"),
                    budget,
                );
            }
        };
        if index.as_u32() != cursor_bci {
            return Err(Error::invalid_input(
                "classfile_instruction_cursor_mismatch",
                format!(
                    "noak returned BCI {} but expected {cursor_bci}",
                    index.as_u32()
                ),
            ));
        }
        let start = usize::try_from(cursor_bci).map_err(|_| {
            Error::invalid_input("classfile_code_span_overflow", "BCI does not fit usize")
        })?;
        let opcode = *code_bytes.get(start).ok_or_else(|| {
            Error::invalid_input(
                "classfile_instruction_out_of_bounds",
                "instruction opcode is outside code array",
            )
        })?;
        let width = match instruction_width(opcode, cursor_bci, &instruction) {
            Ok(width) => width,
            Err(error) => {
                let Error::InvalidInput {
                    code: adapter_code, ..
                } = &error
                else {
                    return Err(error);
                };
                return stopped_code_facts(
                    &code,
                    code_span,
                    instructions,
                    operands,
                    handlers,
                    BytecodeStopPosition::Instruction(cursor_bci),
                    StopFailure::Decode(adapter_code),
                    budget,
                );
            }
        };
        let end = match cursor_bci.checked_add(width) {
            Some(end) => end,
            None => {
                return Err(Error::invalid_input(
                    "classfile_instruction_width_overflow",
                    "instruction end overflow",
                ));
            }
        };
        let code_length_u32 = u32::try_from(code_bytes.len()).map_err(|_| {
            Error::invalid_input(
                "classfile_code_span_overflow",
                "code length does not fit u32",
            )
        })?;
        if end > code_length_u32 {
            return Err(Error::invalid_input(
                "classfile_instruction_out_of_bounds",
                "instruction exceeds code array",
            ));
        }
        if let Err(error) = budget.charge(CountedBudgetDimension::CodeBytes, u64::from(width)) {
            return stopped_code_facts(
                &code,
                code_span,
                instructions,
                operands,
                handlers,
                BytecodeStopPosition::Instruction(cursor_bci),
                StopFailure::Budget(&error),
                budget,
            );
        }
        let span_start = code_span
            .start
            .checked_add(u64::from(cursor_bci))
            .ok_or_else(|| {
                Error::invalid_input("classfile_code_span_overflow", "instruction span overflow")
            })?;
        let end_usize = usize::try_from(end).map_err(|_| {
            Error::invalid_input(
                "classfile_code_span_overflow",
                "instruction end does not fit usize",
            )
        })?;
        let instruction_bytes = code_bytes.get(start..end_usize).ok_or_else(|| {
            Error::invalid_input(
                "classfile_instruction_out_of_bounds",
                "instruction slice exceeds code array",
            )
        })?;
        // Operands come out of the same event and the same slice as the fact below, so
        // the two lists stay in lockstep and share the `CodeBytes` charge above.
        let operands_fact =
            match instruction_operands(opcode, cursor_bci, &instruction, instruction_bytes, pool) {
                Ok(fact) => fact,
                Err(error) => {
                    let Error::InvalidInput {
                        code: adapter_code, ..
                    } = &error
                    else {
                        return Err(error);
                    };
                    return stopped_code_facts(
                        &code,
                        code_span,
                        instructions,
                        operands,
                        handlers,
                        BytecodeStopPosition::Instruction(cursor_bci),
                        StopFailure::Decode(adapter_code),
                        budget,
                    );
                }
            };
        instructions.push(InstructionFact {
            bci: cursor_bci,
            opcode,
            width,
            span: ByteSpan::new(span_start, u64::from(width)),
            operands_span: ByteSpan::new(span_start + 1, u64::from(width - 1)),
            constant_pool_index: constant_pool_index(opcode, instruction_bytes),
        });
        operands.push(operands_fact);
        cursor_bci = end;
    }
    if cursor_bci != code_bytes.len() as u32 {
        return Err(Error::invalid_input(
            "classfile_instruction_cursor_mismatch",
            "instruction cursor did not consume the code array",
        ));
    }

    Ok(MethodCodeFacts {
        max_stack: code.max_stack(),
        max_locals: code.max_locals(),
        code_span,
        instructions,
        operands,
        exception_handlers: handlers,
        exception_handler_count,
        execution: ExecutionReport::Complete {
            usage: budget.usage(),
        },
        stopped_at: None,
        debug,
        generic_debug,
    })
}

/// Reads the LVT and LVTT nested inside one already-decoded `Code` attribute.
///
/// Both tables are read during one walk over bytes already charged with the `Code` entry. A bad
/// debug table only withholds its own evidence; it never changes whether the body's instructions
/// decoded. Multiple LVTT attributes are ambiguous and therefore state no generic types.
fn local_debug_tables(
    code: &Code<'_>,
    pool: &noak::reader::cpool::ConstantPool<'_>,
) -> (LocalDebugTable, LocalDebugTypeTable) {
    let mut names = Vec::new();
    let mut local_types = Vec::new();
    let mut local_type_tables = 0usize;
    let mut generic_unstated = false;
    for attribute in code.attributes() {
        let Ok(attribute) = attribute else {
            return (LocalDebugTable::Unstated, LocalDebugTypeTable::Unstated);
        };
        let Ok(name) = pool.get(attribute.name()) else {
            return (LocalDebugTable::Unstated, LocalDebugTypeTable::Unstated);
        };
        match name.content.as_bytes() {
            b"LocalVariableTable" => {
                let Ok(noak::reader::AttributeContent::LocalVariableTable(table)) =
                    attribute.read_content(pool)
                else {
                    return (LocalDebugTable::Unstated, LocalDebugTypeTable::Unstated);
                };
                for variable in table.locals() {
                    let Ok(variable) = variable else {
                        return (LocalDebugTable::Unstated, LocalDebugTypeTable::Unstated);
                    };
                    let (Ok(name), Ok(descriptor)) =
                        (pool.get(variable.name()), pool.get(variable.descriptor()))
                    else {
                        return (LocalDebugTable::Unstated, LocalDebugTypeTable::Unstated);
                    };
                    let range = variable.range();
                    names.push(LocalDebugName {
                        slot: variable.index(),
                        start_bci: range.start.as_u32(),
                        end_bci: range.end.as_u32(),
                        name: JvmBytes(name.content.as_bytes().to_vec()),
                        descriptor: JvmBytes(descriptor.content.as_bytes().to_vec()),
                    });
                }
            }
            b"LocalVariableTypeTable" => {
                local_type_tables += 1;
                if local_type_tables > 1 {
                    generic_unstated = true;
                    continue;
                }
                let Ok(noak::reader::AttributeContent::LocalVariableTypeTable(table)) =
                    attribute.read_content(pool)
                else {
                    generic_unstated = true;
                    continue;
                };
                for variable in table.locals() {
                    let Ok(variable) = variable else {
                        generic_unstated = true;
                        break;
                    };
                    let (Ok(name), Ok(signature)) =
                        (pool.get(variable.name()), pool.get(variable.signature()))
                    else {
                        generic_unstated = true;
                        break;
                    };
                    let range = variable.range();
                    local_types.push(LocalDebugType {
                        slot: variable.index(),
                        start_bci: range.start.as_u32(),
                        end_bci: range.end.as_u32(),
                        name: JvmBytes(name.content.as_bytes().to_vec()),
                        signature: JvmBytes(signature.content.as_bytes().to_vec()),
                    });
                }
            }
            _ => {}
        }
    }
    let names = if names.is_empty() {
        LocalDebugTable::Absent
    } else {
        LocalDebugTable::Read(names)
    };
    let generic = if generic_unstated {
        LocalDebugTypeTable::Unstated
    } else if local_type_tables == 0 {
        LocalDebugTypeTable::Absent
    } else {
        LocalDebugTypeTable::Read(local_types)
    };
    (names, generic)
}

/// Whether one of the header's shells describes the located `Code` content.
fn member_has_code_shell(method: &MemberHeader, content_span: &ByteSpan) -> bool {
    method.attributes.iter().any(|shell| {
        shell.name.raw().0.as_slice() == b"Code" && shell.content_span == *content_span
    })
}

/// Why a method body stopped before the end of its `Code` attribute.
enum StopFailure<'a> {
    /// A budget or cancellation condition raised by a `Budget` call.
    Budget(&'a Error),
    /// The adapter could not decode one instruction; the code names why.
    Decode(&'a str),
}

/// Reliable prefix of a method body that stopped early.
///
/// The stop is turned into the same terminal vocabulary the public
/// `inspect_method_bytecode` path uses, so a cancelled or exhausted decode never reads
/// as a complete body: a cancellation stays a cancellation, a budget stop keeps its
/// dimension, and a decode failure keeps its own code.
#[allow(clippy::too_many_arguments)]
fn stopped_code_facts(
    code: &Code<'_>,
    code_span: ByteSpan,
    instructions: Vec<InstructionFact>,
    operands: Vec<InstructionOperands>,
    handlers: Vec<ExceptionHandlerFact>,
    position: BytecodeStopPosition,
    failure: StopFailure<'_>,
    budget: &Budget,
) -> Result<MethodCodeFacts> {
    let (execution, stable_code) = match failure {
        StopFailure::Budget(error) => match error {
            Error::Cancelled { .. } => (
                ExecutionReport::Cancelled {
                    usage: budget.usage(),
                },
                "classfile_bytecode_cancelled",
            ),
            Error::BudgetExceeded { dimension, .. } => (
                ExecutionReport::Partial {
                    reason: TerminationReason::BudgetExceeded {
                        dimension: *dimension,
                    },
                    usage: budget.usage(),
                },
                "classfile_bytecode_budget_exceeded",
            ),
            _ => (
                ExecutionReport::Partial {
                    reason: TerminationReason::Error {
                        code: "classfile_bytecode_failed".to_owned(),
                    },
                    usage: budget.usage(),
                },
                "classfile_bytecode_failed",
            ),
        },
        StopFailure::Decode(code) => (
            ExecutionReport::Partial {
                reason: TerminationReason::Error {
                    code: code.to_owned(),
                },
                usage: budget.usage(),
            },
            code,
        ),
    };
    let stopped_at = bytecode_stop(&code_span, position, stable_code)?;
    Ok(MethodCodeFacts {
        max_stack: code.max_stack(),
        max_locals: code.max_locals(),
        code_span,
        instructions,
        operands,
        exception_handlers: handlers,
        exception_handler_count: u32::try_from(code.exception_handlers().count()).map_err(
            |_| {
                Error::invalid_input(
                    "classfile_result_overflow",
                    "handler count does not fit u32",
                )
            },
        )?,
        execution,
        stopped_at: Some(stopped_at),
        // The body stopped before the nested attributes were walked: this read states no debug name,
        // which is what "no name" means for a record that did not reach them (P3 3.1).
        debug: LocalDebugTable::Unstated,
        generic_debug: LocalDebugTypeTable::Unstated,
    })
}

/// Resolves one 1-based constant-pool index inside a fact table.
#[allow(dead_code)]
pub fn cp_entry(pool: &[CpEntryFacts], index: u16) -> Result<&CpEntryFacts> {
    if index == 0 {
        return Err(cp_index_error(index));
    }
    pool.binary_search_by_key(&index, |entry| entry.index)
        .map(|position| &pool[position])
        .map_err(|_| cp_index_error(index))
}

/// Resolves a `CONSTANT_Utf8` index to its raw Modified UTF-8 bytes.
#[allow(dead_code)]
pub fn cp_utf8(pool: &[CpEntryFacts], index: u16) -> Result<JvmBytes> {
    match &cp_entry(pool, index)?.kind {
        CpEntryKind::Utf8 { bytes } => Ok(bytes.clone()),
        _ => Err(cp_fact_tag_mismatch("CONSTANT_Utf8", index)),
    }
}

/// Resolves a `CONSTANT_Class` index to its internal-name bytes.
#[allow(dead_code)]
pub fn cp_class_name(pool: &[CpEntryFacts], index: u16) -> Result<JvmBytes> {
    match &cp_entry(pool, index)?.kind {
        CpEntryKind::Class { name, .. } => Ok(name.clone()),
        _ => Err(cp_fact_tag_mismatch("CONSTANT_Class", index)),
    }
}

const CP_TAG_UTF8: u8 = 1;
const CP_TAG_INTEGER: u8 = 3;
const CP_TAG_FLOAT: u8 = 4;
const CP_TAG_LONG: u8 = 5;
const CP_TAG_DOUBLE: u8 = 6;
const CP_TAG_CLASS: u8 = 7;
const CP_TAG_STRING: u8 = 8;
const CP_TAG_FIELD_REF: u8 = 9;
const CP_TAG_METHOD_REF: u8 = 10;
const CP_TAG_INTERFACE_METHOD_REF: u8 = 11;
const CP_TAG_NAME_AND_TYPE: u8 = 12;
const CP_TAG_METHOD_HANDLE: u8 = 15;
const CP_TAG_METHOD_TYPE: u8 = 16;
const CP_TAG_DYNAMIC: u8 = 17;
const CP_TAG_INVOKE_DYNAMIC: u8 = 18;
const CP_TAG_MODULE: u8 = 19;
const CP_TAG_PACKAGE: u8 = 20;

/// One measured constant-pool slot: enough to slice the entry and to read its
/// payload without re-deriving offsets from noak, whose decoder is private.
#[derive(Debug)]
struct CpSlotLayout {
    index: u16,
    span: ByteSpan,
    tag: u8,
    payload_start: usize,
}

/// Walks the constant pool with an explicit tag-length table.
///
/// A tag this table cannot measure stops the walk (`classfile_unknown_constant_pool_tag`)
/// instead of guessing a width: per the reader's unknown-tag policy, an
/// unmeasurable tag makes the rest of the class unreliable, so neither a partial
/// order nor invented spans are returned.
fn measure_constant_pool(bytes: &[u8], budget: &Budget) -> Result<Vec<CpSlotLayout>> {
    if bytes.len() < 10 || !bytes.starts_with(&0xcafebabe_u32.to_be_bytes()) {
        return Ok(Vec::new()); // noak owns fixed-header diagnostics.
    }
    let count = read_u16(bytes, 8)?;
    if count == 0 {
        return Ok(Vec::new()); // noak supplies the canonical InvalidLength diagnostic.
    }
    let mut slots = Vec::new();
    let mut slot = 1u16;
    let mut offset = 10usize;
    while slot < count {
        budget.poll()?;
        let entry_start = offset;
        let tag = *bytes.get(offset).ok_or_else(|| cp_guard_eoi(offset))?;
        let payload_start = offset_plus(offset, 1)?;
        let payload_length = match tag {
            CP_TAG_UTF8 => usize::from(read_u16(bytes, payload_start)?) + 2,
            CP_TAG_INTEGER | CP_TAG_FLOAT => 4,
            CP_TAG_LONG | CP_TAG_DOUBLE => 8,
            CP_TAG_CLASS | CP_TAG_STRING | CP_TAG_METHOD_TYPE | CP_TAG_MODULE | CP_TAG_PACKAGE => 2,
            CP_TAG_FIELD_REF
            | CP_TAG_METHOD_REF
            | CP_TAG_INTERFACE_METHOD_REF
            | CP_TAG_NAME_AND_TYPE
            | CP_TAG_DYNAMIC
            | CP_TAG_INVOKE_DYNAMIC => 4,
            CP_TAG_METHOD_HANDLE => 3,
            other => {
                return Err(Error::invalid_input(
                    "classfile_unknown_constant_pool_tag",
                    format!(
                        "constant-pool tag {other} at slot {slot} has no known width, so sequential parsing stops here"
                    ),
                ));
            }
        };
        let end = offset_plus(payload_start, payload_length)?;
        if end > bytes.len() {
            return Err(cp_guard_eoi(entry_start));
        }
        slots.push(CpSlotLayout {
            index: slot,
            span: ByteSpan::new(to_u64(entry_start)?, to_u64(end - entry_start)?),
            tag,
            payload_start,
        });
        offset = end;
        let slot_width = if matches!(tag, CP_TAG_LONG | CP_TAG_DOUBLE) {
            2u16
        } else {
            1u16
        };
        slot = slot.checked_add(slot_width).ok_or_else(cp_guard_overflow)?;
    }
    if slot != count {
        return Err(Error::invalid_input(
            "classfile_invalid_constant_pool_slots",
            format!("constant pool declares {count} slots but the walk consumed {slot}"),
        ));
    }
    Ok(slots)
}

/// Cross-checks the measured layout against noak's decode before any fact is built.
///
/// The tag sequence must match entry for entry, and the walk must end exactly
/// where the class-level structure begins; otherwise a wrong width would produce
/// spans and payload reads that look plausible but point at the wrong bytes.
fn verify_constant_pool_layout(
    bytes: &[u8],
    layout: &[CpSlotLayout],
    class: &Class<'_>,
) -> Result<()> {
    let mut seen = 0usize;
    for (index, item) in class.pool().iter_indices() {
        let slot = layout.get(seen).ok_or_else(constant_pool_layout_mismatch)?;
        if slot.index != index.as_u16() || slot.tag != noak_item_tag(item) {
            return Err(constant_pool_layout_mismatch());
        }
        seen += 1;
    }
    if seen != layout.len() {
        return Err(constant_pool_layout_mismatch());
    }
    let cp_end = match layout.last() {
        Some(slot) => span_end(&slot.span)?,
        None => 10,
    };
    let cp_end = usize::try_from(cp_end).map_err(|_| constant_pool_layout_mismatch())?;
    let access_flags = read_u16(bytes, cp_end).map_err(|_| constant_pool_layout_mismatch())?;
    if access_flags != class.access_flags().bits() {
        return Err(constant_pool_layout_mismatch());
    }
    Ok(())
}

fn noak_item_tag(item: &noak::reader::cpool::Item<'_>) -> u8 {
    use noak::reader::cpool::Item;
    match item {
        Item::Utf8(_) => CP_TAG_UTF8,
        Item::Integer(_) => CP_TAG_INTEGER,
        Item::Float(_) => CP_TAG_FLOAT,
        Item::Long(_) => CP_TAG_LONG,
        Item::Double(_) => CP_TAG_DOUBLE,
        Item::Class(_) => CP_TAG_CLASS,
        Item::String(_) => CP_TAG_STRING,
        Item::FieldRef(_) => CP_TAG_FIELD_REF,
        Item::MethodRef(_) => CP_TAG_METHOD_REF,
        Item::InterfaceMethodRef(_) => CP_TAG_INTERFACE_METHOD_REF,
        Item::NameAndType(_) => CP_TAG_NAME_AND_TYPE,
        Item::MethodHandle(_) => CP_TAG_METHOD_HANDLE,
        Item::MethodType(_) => CP_TAG_METHOD_TYPE,
        Item::Dynamic(_) => CP_TAG_DYNAMIC,
        Item::InvokeDynamic(_) => CP_TAG_INVOKE_DYNAMIC,
        Item::Module(_) => CP_TAG_MODULE,
        Item::Package(_) => CP_TAG_PACKAGE,
    }
}

/// Builds the resolved fact view from the measured layout.
fn resolve_constant_pool(
    bytes: &[u8],
    layout: &[CpSlotLayout],
    budget: &Budget,
) -> Result<Vec<CpEntryFacts>> {
    let mut entries = Vec::with_capacity(layout.len());
    for slot in layout {
        budget.poll()?;
        let kind = match slot.tag {
            CP_TAG_UTF8 => CpEntryKind::Utf8 {
                bytes: utf8_payload(bytes, slot)?,
            },
            CP_TAG_INTEGER => CpEntryKind::Integer {
                value: i32::from_be_bytes(read_array(bytes, slot.payload_start)?),
            },
            CP_TAG_FLOAT => CpEntryKind::Float {
                bits: read_u32(bytes, slot.payload_start)?,
            },
            CP_TAG_LONG => CpEntryKind::Long {
                value: i64::from_be_bytes(read_array(bytes, slot.payload_start)?),
            },
            CP_TAG_DOUBLE => CpEntryKind::Double {
                bits: u64::from_be_bytes(read_array(bytes, slot.payload_start)?),
            },
            CP_TAG_CLASS => {
                let name_index = read_u16(bytes, slot.payload_start)?;
                CpEntryKind::Class {
                    name_index,
                    name: utf8_index(bytes, layout, name_index)?,
                }
            }
            CP_TAG_STRING => {
                let index = read_u16(bytes, slot.payload_start)?;
                CpEntryKind::String {
                    utf8_index: index,
                    value: utf8_index(bytes, layout, index)?,
                }
            }
            CP_TAG_FIELD_REF | CP_TAG_METHOD_REF | CP_TAG_INTERFACE_METHOD_REF => {
                let class_index = read_u16(bytes, slot.payload_start)?;
                let name_and_type_index = read_u16(bytes, offset_plus(slot.payload_start, 2)?)?;
                let owner = class_name(bytes, layout, class_index)?;
                let (name, descriptor) = name_and_type(bytes, layout, name_and_type_index)?;
                match slot.tag {
                    CP_TAG_FIELD_REF => CpEntryKind::FieldRef {
                        class_index,
                        name_and_type_index,
                        owner,
                        name,
                        descriptor,
                    },
                    CP_TAG_METHOD_REF => CpEntryKind::MethodRef {
                        class_index,
                        name_and_type_index,
                        owner,
                        name,
                        descriptor,
                    },
                    _ => CpEntryKind::InterfaceMethodRef {
                        class_index,
                        name_and_type_index,
                        owner,
                        name,
                        descriptor,
                    },
                }
            }
            CP_TAG_NAME_AND_TYPE => {
                let name_index = read_u16(bytes, slot.payload_start)?;
                let descriptor_index = read_u16(bytes, offset_plus(slot.payload_start, 2)?)?;
                CpEntryKind::NameAndType {
                    name_index,
                    descriptor_index,
                    name: utf8_index(bytes, layout, name_index)?,
                    descriptor: utf8_index(bytes, layout, descriptor_index)?,
                }
            }
            CP_TAG_METHOD_HANDLE => CpEntryKind::MethodHandle {
                reference_kind: *bytes
                    .get(slot.payload_start)
                    .ok_or_else(|| cp_guard_eoi(slot.payload_start))?,
                reference_index: read_u16(bytes, offset_plus(slot.payload_start, 1)?)?,
            },
            CP_TAG_METHOD_TYPE => {
                let descriptor_index = read_u16(bytes, slot.payload_start)?;
                CpEntryKind::MethodType {
                    descriptor_index,
                    descriptor: utf8_index(bytes, layout, descriptor_index)?,
                }
            }
            CP_TAG_DYNAMIC | CP_TAG_INVOKE_DYNAMIC => {
                let bootstrap_method_attr_index = read_u16(bytes, slot.payload_start)?;
                let name_and_type_index = read_u16(bytes, offset_plus(slot.payload_start, 2)?)?;
                let (name, descriptor) = name_and_type(bytes, layout, name_and_type_index)?;
                if slot.tag == CP_TAG_DYNAMIC {
                    CpEntryKind::Dynamic {
                        bootstrap_method_attr_index,
                        name_and_type_index,
                        name,
                        descriptor,
                    }
                } else {
                    CpEntryKind::InvokeDynamic {
                        bootstrap_method_attr_index,
                        name_and_type_index,
                        name,
                        descriptor,
                    }
                }
            }
            CP_TAG_MODULE | CP_TAG_PACKAGE => {
                let name_index = read_u16(bytes, slot.payload_start)?;
                let name = utf8_index(bytes, layout, name_index)?;
                if slot.tag == CP_TAG_MODULE {
                    CpEntryKind::Module { name_index, name }
                } else {
                    CpEntryKind::Package { name_index, name }
                }
            }
            other => {
                return Err(Error::invalid_input(
                    "classfile_unknown_constant_pool_tag",
                    format!(
                        "constant-pool tag {other} at slot {} has no fact view, so parsing stops here",
                        slot.index
                    ),
                ));
            }
        };
        entries.push(CpEntryFacts {
            index: slot.index,
            span: slot.span.clone(),
            kind,
        });
    }
    Ok(entries)
}

/// Finds one measured slot by its 1-based index.
fn layout_entry(layout: &[CpSlotLayout], index: u16) -> Result<&CpSlotLayout> {
    if index == 0 {
        return Err(cp_index_error(index));
    }
    layout
        .binary_search_by_key(&index, |slot| slot.index)
        .map(|position| &layout[position])
        .map_err(|_| cp_index_error(index))
}

fn utf8_index(bytes: &[u8], layout: &[CpSlotLayout], index: u16) -> Result<JvmBytes> {
    let slot = layout_entry(layout, index)?;
    if slot.tag != CP_TAG_UTF8 {
        return Err(cp_tag_mismatch_error("CONSTANT_Utf8", index, slot.tag));
    }
    utf8_payload(bytes, slot)
}

fn utf8_payload(bytes: &[u8], slot: &CpSlotLayout) -> Result<JvmBytes> {
    let length = usize::from(read_u16(bytes, slot.payload_start)?);
    let payload_start = offset_plus(slot.payload_start, 2)?;
    Ok(JvmBytes(bytes_at(bytes, payload_start, length)?.to_vec()))
}

fn class_name(bytes: &[u8], layout: &[CpSlotLayout], index: u16) -> Result<JvmBytes> {
    let slot = layout_entry(layout, index)?;
    if slot.tag != CP_TAG_CLASS {
        return Err(cp_tag_mismatch_error("CONSTANT_Class", index, slot.tag));
    }
    let name_index = read_u16(bytes, slot.payload_start)?;
    utf8_index(bytes, layout, name_index)
}

fn name_and_type(
    bytes: &[u8],
    layout: &[CpSlotLayout],
    index: u16,
) -> Result<(JvmBytes, JvmBytes)> {
    let slot = layout_entry(layout, index)?;
    if slot.tag != CP_TAG_NAME_AND_TYPE {
        return Err(cp_tag_mismatch_error(
            "CONSTANT_NameAndType",
            index,
            slot.tag,
        ));
    }
    let name_index = read_u16(bytes, slot.payload_start)?;
    let descriptor_index = read_u16(bytes, offset_plus(slot.payload_start, 2)?)?;
    Ok((
        utf8_index(bytes, layout, name_index)?,
        utf8_index(bytes, layout, descriptor_index)?,
    ))
}

fn read_array<const N: usize>(bytes: &[u8], offset: usize) -> Result<[u8; N]> {
    Ok(bytes_at(bytes, offset, N)?
        .try_into()
        .expect("slice length was checked"))
}

fn bytes_at(bytes: &[u8], offset: usize, length: usize) -> Result<&[u8]> {
    let end = offset_plus(offset, length)?;
    bytes.get(offset..end).ok_or_else(|| cp_guard_eoi(offset))
}

fn span_end(span: &ByteSpan) -> Result<u64> {
    span.start
        .checked_add(span.length)
        .ok_or_else(|| span_overflow("class-file span"))
}

fn offset_plus(offset: usize, delta: usize) -> Result<usize> {
    offset
        .checked_add(delta)
        .ok_or_else(|| span_overflow("class-file offset"))
}

fn span_overflow(what: &str) -> Error {
    Error::invalid_input("classfile_span_overflow", format!("{what} overflow"))
}

fn span_slice<'a>(bytes: &'a [u8], span: &ByteSpan, what: &str) -> Result<&'a [u8]> {
    let start = usize::try_from(span.start).map_err(|_| span_outside(what))?;
    let length = usize::try_from(span.length).map_err(|_| span_outside(what))?;
    let end = start
        .checked_add(length)
        .ok_or_else(|| span_outside(what))?;
    bytes.get(start..end).ok_or_else(|| span_outside(what))
}

fn span_outside(what: &str) -> Error {
    Error::invalid_input(
        "classfile_invalid_attribute_span",
        format!("{what} is outside the class bytes"),
    )
}

fn cp_index_error(index: u16) -> Error {
    Error::invalid_input(
        "classfile_invalid_constant_pool_index",
        format!("constant-pool index {index} does not hold an entry"),
    )
}

fn cp_tag_mismatch_error(required: &str, index: u16, actual: u8) -> Error {
    Error::invalid_input(
        "classfile_constant_pool_tag_mismatch",
        format!("constant-pool index {index} holds tag {actual}, expected {required}"),
    )
}

fn cp_fact_tag_mismatch(required: &str, index: u16) -> Error {
    Error::invalid_input(
        "classfile_constant_pool_tag_mismatch",
        format!("constant-pool index {index} is not a {required} entry"),
    )
}

fn constant_pool_layout_mismatch() -> Error {
    Error::invalid_input(
        "classfile_constant_pool_layout_mismatch",
        "the measured constant-pool layout disagrees with the decoded class structure",
    )
}

/// Bounded cursor over one attribute content.
///
/// A read past the end and unread trailing bytes both stop with
/// `classfile_invalid_attribute_content`: an attribute whose declared structure
/// does not match its content is malformed, not partially usable.
/// A bounded cursor over one attribute's content: the same reader every attribute fact in this
/// module and the modern-fact pass in [`crate::modern`] reads its fields with.
pub(crate) struct AttributeReader<'a> {
    content: &'a [u8],
    position: usize,
}

impl<'a> AttributeReader<'a> {
    pub(crate) const fn new(content: &'a [u8]) -> Self {
        Self {
            content,
            position: 0,
        }
    }

    /// Bytes read so far, in attribute-content coordinates.
    pub(crate) const fn position(&self) -> usize {
        self.position
    }

    /// One byte of the content, or the end-of-content error when none is left.
    pub(crate) fn u8(&mut self) -> Result<u8> {
        let byte = *self
            .content
            .get(self.position)
            .ok_or_else(|| attribute_eoi(self.position))?;
        self.position += 1;
        Ok(byte)
    }

    pub(crate) fn u16(&mut self) -> Result<u16> {
        let start = self.position;
        let end = offset_plus(start, 2)?;
        let pair: [u8; 2] = self
            .content
            .get(start..end)
            .ok_or_else(|| attribute_eoi(start))?
            .try_into()
            .expect("slice length was checked");
        self.position = end;
        Ok(u16::from_be_bytes(pair))
    }

    pub(crate) fn u32(&mut self) -> Result<u32> {
        let start = self.position;
        let end = offset_plus(start, 4)?;
        let value: [u8; 4] = self
            .content
            .get(start..end)
            .ok_or_else(|| attribute_eoi(start))?
            .try_into()
            .expect("slice length was checked");
        self.position = end;
        Ok(u32::from_be_bytes(value))
    }

    pub(crate) fn skip(&mut self, length: usize) -> Result<()> {
        let end = offset_plus(self.position, length)?;
        if end > self.content.len() {
            return Err(attribute_eoi(self.position));
        }
        self.position = end;
        Ok(())
    }

    pub(crate) fn expect_end(&self) -> Result<()> {
        if self.position != self.content.len() {
            return Err(Error::invalid_input(
                "classfile_invalid_attribute_content",
                format!(
                    "attribute content has {} unread trailing byte(s)",
                    self.content.len() - self.position
                ),
            ));
        }
        Ok(())
    }
}

fn attribute_eoi(position: usize) -> Error {
    Error::invalid_input(
        "classfile_invalid_attribute_content",
        format!("attribute content ends before its declared structure at offset {position}"),
    )
}

pub(crate) fn ensure_unique(seen: &mut Vec<&'static str>, name: &'static str) -> Result<()> {
    if seen.contains(&name) {
        return Err(Error::invalid_input(
            "classfile_duplicate_attribute",
            format!("class or member declares more than one {name} attribute"),
        ));
    }
    seen.push(name);
    Ok(())
}

pub(crate) fn read_class_name_list(
    reader: &mut AttributeReader<'_>,
    pool: &[CpEntryFacts],
    budget: &Budget,
) -> Result<Vec<JvmBytes>> {
    let count = reader.u16()?;
    let mut names = Vec::new();
    for _ in 0..count {
        budget.poll()?;
        let index = reader.u16()?;
        names.push(cp_class_name(pool, index)?);
    }
    Ok(names)
}

/// Reads the `Module` attribute up to `uses`/`provides`.
///
/// Requires, exports and opens are only measured so that the cursor reaches the
/// sections P1 consumers read; their content is never retained.
fn read_module_facts(
    reader: &mut AttributeReader<'_>,
    pool: &[CpEntryFacts],
    budget: &Budget,
) -> Result<ModuleFacts> {
    reader.skip(6)?; // module_name_index, module_flags, module_version_index
    let requires_count = reader.u16()?;
    for _ in 0..requires_count {
        budget.poll()?;
        reader.skip(6)?; // requires_index, requires_flags, requires_version_index
    }
    skip_qualified_module_section(reader, budget)?; // exports
    skip_qualified_module_section(reader, budget)?; // opens
    let uses_count = reader.u16()?;
    let mut uses = Vec::new();
    for _ in 0..uses_count {
        budget.poll()?;
        let index = reader.u16()?;
        uses.push(cp_class_name(pool, index)?);
    }
    let provides_count = reader.u16()?;
    let mut provides = Vec::new();
    for _ in 0..provides_count {
        budget.poll()?;
        let service = cp_class_name(pool, reader.u16()?)?;
        let implementation_count = reader.u16()?;
        let mut implementations = Vec::new();
        for _ in 0..implementation_count {
            budget.poll()?;
            implementations.push(cp_class_name(pool, reader.u16()?)?);
        }
        provides.push(ProvidesFacts {
            service,
            implementations,
        });
    }
    Ok(ModuleFacts { uses, provides })
}

fn skip_qualified_module_section(reader: &mut AttributeReader<'_>, budget: &Budget) -> Result<()> {
    let count = reader.u16()?;
    for _ in 0..count {
        budget.poll()?;
        reader.skip(4)?; // section index, section flags
        let to_count = usize::from(reader.u16()?);
        reader.skip(
            to_count
                .checked_mul(2)
                .ok_or_else(|| span_overflow("module section length"))?,
        )?;
    }
    Ok(())
}

#[cfg(test)]
mod reader_facts_tests {
    use super::*;
    use crate::budget::{BudgetDimension, CancellationToken, Limits};

    const V52_FIXTURE: &[u8] =
        crate::test_fixtures::fixture!("historical/ecj-4.6.1/v52/HistoricalControlFlow.class");

    fn unlimited_limits() -> Limits {
        Limits {
            input_bytes: u64::MAX,
            archive_entries: u64::MAX,
            entry_bytes: u64::MAX,
            read_bytes: u64::MAX,
            class_bytes: u64::MAX,
            attribute_bytes: u64::MAX,
            code_bytes: u64::MAX,
            result_items: u64::MAX,
            output_bytes: u64::MAX,
            nested_depth: u64::MAX,
            elapsed_millis: u64::MAX,
            ..Limits::default()
        }
    }

    fn budget() -> Budget {
        Budget::new(unlimited_limits())
    }

    /// Same as [`budget`], for call sites where a local binding shadows the name.
    fn fresh_budget() -> Budget {
        budget()
    }

    fn buf_u16(out: &mut Vec<u8>, value: u16) {
        out.extend_from_slice(&value.to_be_bytes());
    }

    fn buf_u32(out: &mut Vec<u8>, value: u32) {
        out.extend_from_slice(&value.to_be_bytes());
    }

    fn attribute(out: &mut Vec<u8>, name_index: u16, content: &[u8]) {
        buf_u16(out, name_index);
        buf_u32(out, u32::try_from(content.len()).unwrap());
        out.extend_from_slice(content);
    }

    fn error_code(error: Error) -> String {
        match error {
            Error::InvalidInput { code, .. } | Error::Unsupported { code, .. } => code,
            other => panic!("expected a structured error code, got {other:?}"),
        }
    }

    /// One recorded constant-pool entry: index, true byte offset and width.
    #[derive(Clone, Copy)]
    struct CpRef {
        index: u16,
        offset: u64,
        width: u64,
    }

    /// Assembles a constant pool while remembering each entry's real position, so
    /// span assertions come from the writer instead of from the reader.
    struct CpBuilder {
        bytes: Vec<u8>,
        next_index: u16,
        entries: Vec<CpRef>,
    }

    impl CpBuilder {
        fn new() -> Self {
            let mut bytes = Vec::new();
            bytes.extend_from_slice(&0xcafebabe_u32.to_be_bytes());
            buf_u16(&mut bytes, 0); // minor version
            buf_u16(&mut bytes, 52); // major version
            buf_u16(&mut bytes, 0); // constant_pool_count placeholder
            Self {
                bytes,
                next_index: 1,
                entries: Vec::new(),
            }
        }

        fn start(&mut self, tag: u8, payload: impl FnOnce(&mut Vec<u8>)) -> CpRef {
            let offset = self.bytes.len() as u64;
            self.bytes.push(tag);
            payload(&mut self.bytes);
            let reference = CpRef {
                index: self.next_index,
                offset,
                width: self.bytes.len() as u64 - offset,
            };
            self.entries.push(reference);
            self.next_index += 1;
            reference
        }

        fn wide(&mut self, tag: u8, payload: impl FnOnce(&mut Vec<u8>)) -> CpRef {
            let reference = self.start(tag, payload);
            self.next_index += 1; // Long/Double reserve the following slot
            reference
        }

        fn utf8(&mut self, value: &[u8]) -> CpRef {
            self.start(1, |bytes| {
                buf_u16(bytes, u16::try_from(value.len()).unwrap());
                bytes.extend_from_slice(value);
            })
        }

        fn integer(&mut self, value: i32) -> CpRef {
            self.start(3, |bytes| bytes.extend_from_slice(&value.to_be_bytes()))
        }

        fn float(&mut self, bits: u32) -> CpRef {
            self.start(4, |bytes| buf_u32(bytes, bits))
        }

        fn long(&mut self, value: i64) -> CpRef {
            self.wide(5, |bytes| bytes.extend_from_slice(&value.to_be_bytes()))
        }

        fn double(&mut self, bits: u64) -> CpRef {
            self.wide(6, |bytes| bytes.extend_from_slice(&bits.to_be_bytes()))
        }

        fn class(&mut self, name_index: u16) -> CpRef {
            self.start(7, |bytes| buf_u16(bytes, name_index))
        }

        fn string(&mut self, utf8_index: u16) -> CpRef {
            self.start(8, |bytes| buf_u16(bytes, utf8_index))
        }

        fn member_ref(&mut self, tag: u8, class_index: u16, name_and_type_index: u16) -> CpRef {
            self.start(tag, |bytes| {
                buf_u16(bytes, class_index);
                buf_u16(bytes, name_and_type_index);
            })
        }

        fn name_and_type(&mut self, name_index: u16, descriptor_index: u16) -> CpRef {
            self.start(12, |bytes| {
                buf_u16(bytes, name_index);
                buf_u16(bytes, descriptor_index);
            })
        }

        fn method_handle(&mut self, reference_kind: u8, reference_index: u16) -> CpRef {
            self.start(15, |bytes| {
                bytes.push(reference_kind);
                buf_u16(bytes, reference_index);
            })
        }

        fn method_type(&mut self, descriptor_index: u16) -> CpRef {
            self.start(16, |bytes| buf_u16(bytes, descriptor_index))
        }

        fn dynamic(
            &mut self,
            tag: u8,
            bootstrap_method_attr_index: u16,
            name_and_type_index: u16,
        ) -> CpRef {
            self.start(tag, |bytes| {
                buf_u16(bytes, bootstrap_method_attr_index);
                buf_u16(bytes, name_and_type_index);
            })
        }

        fn module(&mut self, name_index: u16) -> CpRef {
            self.start(19, |bytes| buf_u16(bytes, name_index))
        }

        fn package(&mut self, name_index: u16) -> CpRef {
            self.start(20, |bytes| buf_u16(bytes, name_index))
        }

        fn finish(mut self) -> (Vec<u8>, Vec<CpRef>) {
            let count = self.next_index;
            self.bytes[8..10].copy_from_slice(&count.to_be_bytes());
            (self.bytes, self.entries)
        }
    }

    fn find_shell<'a>(shells: &'a [AttributeShell], name: &[u8]) -> &'a AttributeShell {
        shells
            .iter()
            .find(|shell| shell.name.raw().0 == name)
            .unwrap_or_else(|| panic!("no attribute shell named {name:?}"))
    }

    #[test]
    fn real_fixture_class_facts_match_the_decoded_class() {
        let mut budget = budget();
        let facts = class_facts(V52_FIXTURE, &mut budget).unwrap();
        assert_eq!((facts.major_version, facts.minor_version), (52, 0));
        assert_eq!(facts.access_flags, 0x0021);
        assert_eq!(facts.this_class.raw().0, b"HistoricalControlFlow");
        assert_eq!(
            facts.super_class.as_ref().unwrap().raw().0,
            b"java/lang/Object"
        );
        assert!(facts.interfaces.is_empty());
        assert!(facts.fields.is_empty());
        assert!(facts.attributes.is_empty());
        assert_eq!(budget.usage().class_bytes, V52_FIXTURE.len() as u64);
        // Intermediate facts are not result items; the query layer owns that charge.
        assert_eq!(budget.usage().result_items, 0);
        // The three `Code` shells are enumerated, so their entries are billed the
        // same way `inspect_header` bills them: 6 header bytes plus the content.
        assert_eq!(budget.usage().attribute_bytes, 23 + 22 + 53);

        // `javap -v` and an independent byte walk both report 17 declared slots,
        // holding 16 entries at 1..=16 with no reserved slot.
        assert_eq!(facts.constant_pool.len(), 16);
        assert_eq!(facts.constant_pool.first().unwrap().index, 1);
        assert_eq!(facts.constant_pool.last().unwrap().index, 16);

        assert_eq!(
            cp_class_name(&facts.constant_pool, 1).unwrap(),
            JvmBytes(b"HistoricalControlFlow".to_vec())
        );
        assert_eq!(
            cp_utf8(&facts.constant_pool, 2).unwrap(),
            JvmBytes(b"HistoricalControlFlow".to_vec())
        );
        assert_eq!(
            cp_class_name(&facts.constant_pool, 3).unwrap(),
            JvmBytes(b"java/lang/Object".to_vec())
        );
        assert_eq!(
            cp_utf8(&facts.constant_pool, 5).unwrap(),
            JvmBytes(b"<init>".to_vec())
        );
        assert_eq!(
            cp_entry(&facts.constant_pool, 8).unwrap().kind,
            CpEntryKind::MethodRef {
                class_index: 3,
                name_and_type_index: 9,
                owner: JvmBytes(b"java/lang/Object".to_vec()),
                name: JvmBytes(b"<init>".to_vec()),
                descriptor: JvmBytes(b"()V".to_vec()),
            }
        );
        assert_eq!(
            cp_entry(&facts.constant_pool, 9).unwrap().kind,
            CpEntryKind::NameAndType {
                name_index: 5,
                descriptor_index: 6,
                name: JvmBytes(b"<init>".to_vec()),
                descriptor: JvmBytes(b"()V".to_vec()),
            }
        );
        assert_eq!(
            cp_class_name(&facts.constant_pool, 15).unwrap(),
            JvmBytes(b"java/lang/Throwable".to_vec())
        );

        assert_eq!(facts.methods.len(), 3);
        assert_eq!(facts.methods[2].name.raw().0, b"finallyPath");
        assert_eq!(facts.methods[2].descriptor.raw().0, b"(I)I");
        assert_eq!(facts.methods[2].access_flags, 0x0001);
        assert_eq!(facts.methods[2].attributes.len(), 1);
        assert_eq!(facts.methods[2].attributes[0].name.raw().0, b"Code");
        assert_eq!(facts.methods[2].attributes[0].span, ByteSpan::new(248, 53));
        assert_eq!(
            facts.methods[2].attributes[0].content_span,
            ByteSpan::new(254, 47)
        );
    }

    #[test]
    fn real_fixture_spans_land_on_the_true_constant_pool_offsets() {
        let facts = class_facts(V52_FIXTURE, &mut budget()).unwrap();

        // Offsets come from an independent walk of the file, not from the reader.
        let expected = [
            (1u16, 10u64, 3u64),
            (2, 13, 24),
            (4, 40, 19),
            (8, 81, 5),
            (9, 86, 5),
            (14, 126, 16),
            (15, 142, 3),
            (16, 145, 22),
        ];
        for (index, start, length) in expected {
            let entry = cp_entry(&facts.constant_pool, index).unwrap();
            assert_eq!(
                (entry.span.start, entry.span.length),
                (start, length),
                "entry #{index}"
            );
        }

        // Cross-validate the payloads by re-parsing the recorded spans.
        let method_ref = cp_entry(&facts.constant_pool, 8).unwrap();
        assert_eq!(V52_FIXTURE[81], 10);
        assert_eq!(read_u16(V52_FIXTURE, 82).unwrap(), 3);
        assert_eq!(read_u16(V52_FIXTURE, 84).unwrap(), 9);
        assert_eq!(method_ref.span.length, 5);

        assert_eq!(V52_FIXTURE[142], 7);
        assert_eq!(read_u16(V52_FIXTURE, 143).unwrap(), 16);

        let throwable = cp_entry(&facts.constant_pool, 16).unwrap();
        assert_eq!(V52_FIXTURE[145], 1);
        assert_eq!(read_u16(V52_FIXTURE, 146).unwrap(), 19);
        assert_eq!(
            &V52_FIXTURE[148..167],
            b"java/lang/Throwable",
            "Utf8 payload inside the recorded span"
        );
        assert_eq!(throwable.span.length, 3 + 19);

        // Entries tile the constant pool without gaps, and the pool ends exactly
        // where the class-level structure begins.
        assert_eq!(facts.constant_pool[0].span.start, 10);
        for pair in facts.constant_pool.windows(2) {
            assert_eq!(
                pair[0].span.start + pair[0].span.length,
                pair[1].span.start,
                "entry #{} must end where #{} begins",
                pair[0].index,
                pair[1].index
            );
        }
        let cp_end = {
            let last = facts.constant_pool.last().unwrap();
            last.span.start + last.span.length
        };
        assert_eq!(cp_end, 167);
        let header = cp_end as usize;
        assert_eq!(read_u16(V52_FIXTURE, header).unwrap(), facts.access_flags);
        assert_eq!(read_u16(V52_FIXTURE, header + 2).unwrap(), 1); // this_class
        assert_eq!(read_u16(V52_FIXTURE, header + 4).unwrap(), 3); // super_class
        assert_eq!(read_u16(V52_FIXTURE, header + 6).unwrap(), 0); // interfaces
        assert_eq!(read_u16(V52_FIXTURE, header + 8).unwrap(), 0); // fields
        assert_eq!(read_u16(V52_FIXTURE, header + 10).unwrap(), 3); // methods
        // The class attribute count closes the file, after fields and methods.
        assert_eq!(read_u16(V52_FIXTURE, V52_FIXTURE.len() - 2).unwrap(), 0); // attributes
    }

    #[test]
    fn facts_and_public_inspections_agree_on_the_same_input() {
        let facts = class_facts(V52_FIXTURE, &mut budget()).unwrap();
        let header = inspect_header(V52_FIXTURE, &mut budget(), InspectionMode::Forensic)
            .unwrap()
            .header;
        assert_eq!(facts.major_version, header.major_version);
        assert_eq!(facts.minor_version, header.minor_version);
        assert_eq!(facts.access_flags, header.access_flags);
        assert_eq!(facts.this_class, header.this_class);
        assert_eq!(facts.super_class, header.super_class);
        assert_eq!(facts.interfaces, header.interfaces);
        assert_eq!(facts.fields, header.fields);
        assert_eq!(facts.methods, header.methods);
        assert_eq!(facts.attributes, header.attributes);

        // The Code shell of `finallyPath` and the instruction report describe the
        // same bytes: re-read the Code header from the shell's content span.
        let shell = find_shell(&facts.methods[2].attributes, b"Code");
        let selector = MethodSelector {
            name: JvmBytes(b"finallyPath".to_vec()),
            descriptor: JvmBytes(b"(I)I".to_vec()),
        };
        let report = inspect_method_bytecode(V52_FIXTURE, selector, &mut budget()).unwrap();
        let content = shell.content_span.start as usize;
        assert_eq!(read_u16(V52_FIXTURE, content).unwrap(), report.max_stack);
        assert_eq!(
            read_u16(V52_FIXTURE, content + 2).unwrap(),
            report.max_locals
        );
        assert_eq!(
            read_u32(V52_FIXTURE, content + 4).unwrap(),
            report.code_span.length as u32
        );
        assert_eq!(report.code_span.start, shell.content_span.start + 8);

        // The same constant-pool index resolves to the same symbol for both APIs.
        let init = MethodSelector {
            name: JvmBytes(b"<init>".to_vec()),
            descriptor: JvmBytes(b"()V".to_vec()),
        };
        let init_report = inspect_method_bytecode(V52_FIXTURE, init, &mut fresh_budget()).unwrap();
        let invoke = init_report
            .instructions
            .iter()
            .find(|instruction| instruction.opcode == 0xb7)
            .expect("constructor calls super");
        let index = invoke
            .constant_pool_index
            .expect("invokespecial carries an index");
        assert_eq!(index, 8);
        match cp_entry(&facts.constant_pool, index).unwrap().kind.clone() {
            CpEntryKind::MethodRef {
                owner,
                name,
                descriptor,
                ..
            } => {
                assert_eq!(owner, JvmBytes(b"java/lang/Object".to_vec()));
                assert_eq!(name, JvmBytes(b"<init>".to_vec()));
                assert_eq!(descriptor, JvmBytes(b"()V".to_vec()));
            }
            other => panic!("expected a MethodRef fact, got {other:?}"),
        }

        // Attributes this layer does not own stay unread.
        let code_only = attribute_facts(
            V52_FIXTURE,
            &facts.methods[0].attributes,
            &facts.constant_pool,
            &mut fresh_budget(),
        )
        .unwrap();
        assert_eq!(code_only, AttributeFacts::default());
    }

    #[test]
    fn budget_hits_and_cancellation_never_fabricate_facts() {
        let mut configured = unlimited_limits();
        configured.class_bytes = V52_FIXTURE.len() as u64 - 1;
        let mut budget = Budget::new(configured);
        assert!(matches!(
            class_facts(V52_FIXTURE, &mut budget).unwrap_err(),
            Error::BudgetExceeded {
                dimension: BudgetDimension::ClassBytes,
                ..
            }
        ));
        assert_eq!(budget.usage().class_bytes, 0);

        let facts = class_facts(V52_FIXTURE, &mut fresh_budget()).unwrap();
        let shell = find_shell(&facts.methods[0].attributes, b"Code").clone();
        let shell_bytes = 6 + shell.content_span.length;

        let mut configured = unlimited_limits();
        configured.attribute_bytes = shell_bytes - 1;
        let mut budget = Budget::new(configured);
        assert!(matches!(
            attribute_content(V52_FIXTURE, &shell, &mut budget).unwrap_err(),
            Error::BudgetExceeded {
                dimension: BudgetDimension::AttributeBytes,
                ..
            }
        ));
        assert_eq!(budget.usage().attribute_bytes, 0);

        // The exact shell length succeeds and is billed the same way the existing
        // attribute shell enumeration bills one entry, without a result item.
        let mut exact = unlimited_limits();
        exact.attribute_bytes = shell_bytes;
        exact.result_items = 0;
        let mut budget = Budget::new(exact);
        let content = attribute_content(V52_FIXTURE, &shell, &mut budget).unwrap();
        assert_eq!(content.len() as u64, shell.content_span.length);
        assert_eq!(budget.usage().attribute_bytes, shell_bytes);
        assert_eq!(budget.usage().result_items, 0);

        let token = CancellationToken::new();
        token.cancel();
        let mut budget = Budget::with_cancellation_token(unlimited_limits(), token);
        assert!(matches!(
            class_facts(V52_FIXTURE, &mut budget).unwrap_err(),
            Error::Cancelled { .. }
        ));
        assert_eq!(budget.usage().class_bytes, 0);

        let mut expired = unlimited_limits();
        expired.elapsed_millis = 0;
        let mut budget = Budget::new(expired);
        assert!(matches!(
            class_facts(V52_FIXTURE, &mut budget).unwrap_err(),
            Error::BudgetExceeded {
                dimension: BudgetDimension::ElapsedMillis,
                ..
            }
        ));
    }

    #[test]
    fn unknown_tag_truncation_and_broken_shells_stop_with_structured_errors() {
        // An unknown tag: noak owns the class-level diagnostic, and the measured
        // walk refuses to guess a width on its own.
        let mut unknown = V52_FIXTURE.to_vec();
        unknown[10] = 2;
        assert_eq!(
            error_code(class_facts(&unknown, &mut budget()).unwrap_err()),
            "classfile_decode"
        );
        assert_eq!(
            error_code(
                measure_constant_pool(&unknown, &Budget::new(unlimited_limits())).unwrap_err()
            ),
            "classfile_unknown_constant_pool_tag"
        );

        // A truncated entry: both the class path and the walk stop structured.
        let truncated = &V52_FIXTURE[..14];
        assert_eq!(
            error_code(class_facts(truncated, &mut budget()).unwrap_err()),
            "classfile_decode"
        );
        assert_eq!(
            error_code(
                measure_constant_pool(truncated, &Budget::new(unlimited_limits())).unwrap_err()
            ),
            "classfile_decode"
        );

        let facts = class_facts(V52_FIXTURE, &mut budget()).unwrap();
        let name = facts.methods[0].attributes[0].name.clone();
        let mut budget = budget();

        // Content that leaves the class bytes is refused instead of sliced.
        let outside = AttributeShell {
            name: name.clone(),
            span: ByteSpan::new(0, 6),
            content_span: ByteSpan::new(6, 4096),
        };
        assert_eq!(
            error_code(attribute_content(V52_FIXTURE, &outside, &mut budget).unwrap_err()),
            "classfile_invalid_attribute_span"
        );

        // A shell whose spans contradict each other is refused as well.
        let inconsistent = AttributeShell {
            name,
            span: ByteSpan::new(0, 99),
            content_span: ByteSpan::new(6, 0),
        };
        assert_eq!(
            error_code(attribute_content(V52_FIXTURE, &inconsistent, &mut budget).unwrap_err()),
            "classfile_invalid_attribute_span"
        );
        assert_eq!(budget.usage().attribute_bytes, 0);

        // Broken index and tag lookups do not produce facts.
        assert_eq!(
            error_code(cp_entry(&facts.constant_pool, 0).unwrap_err()),
            "classfile_invalid_constant_pool_index"
        );
        assert_eq!(
            error_code(cp_entry(&facts.constant_pool, 17).unwrap_err()),
            "classfile_invalid_constant_pool_index"
        );
        assert_eq!(
            error_code(cp_utf8(&facts.constant_pool, 8).unwrap_err()),
            "classfile_constant_pool_tag_mismatch"
        );
        assert_eq!(
            error_code(cp_class_name(&facts.constant_pool, 2).unwrap_err()),
            "classfile_constant_pool_tag_mismatch"
        );
    }

    /// Index of the single constant-pool entry whose kind satisfies the predicate.
    ///
    /// These lookups only produce a handle; index assignment and spans are
    /// asserted against the builder's recorded positions, not against the reader.
    fn only_of(facts: &ClassFacts, matches: impl Fn(&CpEntryKind) -> bool) -> u16 {
        facts
            .constant_pool
            .iter()
            .find(|entry| matches(&entry.kind))
            .map(|entry| entry.index)
            .expect("a constant-pool entry with the requested kind")
    }

    fn i_seven_index(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| matches!(kind, CpEntryKind::Integer { .. }))
    }

    fn float_index(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| matches!(kind, CpEntryKind::Float { .. }))
    }

    fn long_index(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| matches!(kind, CpEntryKind::Long { .. }))
    }

    fn double_index(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| matches!(kind, CpEntryKind::Double { .. }))
    }

    fn string_entry(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| matches!(kind, CpEntryKind::String { .. }))
    }

    fn field_ref_entry(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| matches!(kind, CpEntryKind::FieldRef { .. }))
    }

    fn method_ref_entry(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| matches!(kind, CpEntryKind::MethodRef { .. }))
    }

    fn interface_method_ref_entry(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| {
            matches!(kind, CpEntryKind::InterfaceMethodRef { .. })
        })
    }

    fn method_handle_entry(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| {
            matches!(kind, CpEntryKind::MethodHandle { .. })
        })
    }

    fn method_type_entry(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| matches!(kind, CpEntryKind::MethodType { .. }))
    }

    fn dynamic_entry(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| matches!(kind, CpEntryKind::Dynamic { .. }))
    }

    fn invoke_dynamic_entry(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| {
            matches!(kind, CpEntryKind::InvokeDynamic { .. })
        })
    }

    fn module_entry(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| matches!(kind, CpEntryKind::Module { .. }))
    }

    fn package_entry(facts: &ClassFacts) -> u16 {
        only_of(facts, |kind| matches!(kind, CpEntryKind::Package { .. }))
    }

    fn bootstrap_handle_index(facts: &ClassFacts) -> u16 {
        method_handle_entry(facts)
    }

    fn l_minus_two_slot(facts: &ClassFacts) -> u16 {
        long_index(facts) + 1
    }

    fn class_entry_for(facts: &ClassFacts, name: &[u8]) -> u16 {
        only_of(
            facts,
            |kind| matches!(kind, CpEntryKind::Class { name: value, .. } if value.0 == name),
        )
    }

    fn index_of_utf8(facts: &ClassFacts, value: &[u8]) -> u16 {
        only_of(
            facts,
            |kind| matches!(kind, CpEntryKind::Utf8 { bytes } if bytes.0 == value),
        )
    }

    fn index_of_nat(facts: &ClassFacts, name: &[u8], descriptor: &[u8]) -> u16 {
        only_of(facts, |kind| {
            matches!(
                kind,
                CpEntryKind::NameAndType { name: n, descriptor: d, .. }
                    if n.0 == name && d.0 == descriptor
            )
        })
    }

    fn nat_vf_index(facts: &ClassFacts) -> u16 {
        index_of_nat(facts, b"vf", b"I")
    }

    fn nat_run_index(facts: &ClassFacts) -> u16 {
        index_of_nat(facts, b"run", b"()V")
    }

    fn nat_indy_index(facts: &ClassFacts) -> u16 {
        index_of_nat(facts, b"indy", b"()Ljava/lang/Runnable;")
    }

    /// Constant-pool slot of the `MethodType` entry built by `bootstrap_class`.
    fn method_type_index() -> u16 {
        3
    }

    /// A minimal class whose only class attribute is `BootstrapMethods`, with the
    /// content the caller writes.
    ///
    /// Slots: 1 `Utf8 "BootstrapMethods"`, 2 `Utf8 "()V"`, 3 `MethodType #2`,
    /// 4 `MethodHandle #3`, 5 `Utf8 "condy"`, 6 `NameAndType #5:#2`,
    /// 7 `Utf8 "pkg/C"`, 8 `Class #7`, 9 `String #5`, 10 `Integer 1`,
    /// 11 `Dynamic #0.#6`.
    fn bootstrap_class(
        build: impl FnOnce(&mut Vec<u8>),
    ) -> (Vec<u8>, AttributeShell, Vec<CpEntryFacts>) {
        let mut cp = CpBuilder::new();
        let a_bootstrap = cp.utf8(b"BootstrapMethods");
        let u_void = cp.utf8(b"()V");
        cp.method_type(u_void.index);
        cp.method_handle(6, method_type_index());
        let u_condy = cp.utf8(b"condy");
        let nat = cp.name_and_type(u_condy.index, u_void.index);
        let u_class = cp.utf8(b"pkg/C");
        let c_class = cp.class(u_class.index);
        cp.string(u_condy.index);
        cp.integer(1);
        cp.dynamic(17, 0, nat.index);
        let (mut bytes, _) = cp.finish();
        buf_u16(&mut bytes, 0x0021);
        buf_u16(&mut bytes, c_class.index);
        buf_u16(&mut bytes, c_class.index);
        buf_u16(&mut bytes, 0); // interfaces
        buf_u16(&mut bytes, 0); // fields
        buf_u16(&mut bytes, 0); // methods
        buf_u16(&mut bytes, 1); // class attributes
        let mut content = Vec::new();
        build(&mut content);
        attribute(&mut bytes, a_bootstrap.index, &content);

        let mut budget = budget();
        let facts = class_facts(&bytes, &mut budget).expect("the bootstrap fixture is decodable");
        let shell = find_shell(&facts.attributes, b"BootstrapMethods").clone();
        (bytes, shell, facts.constant_pool)
    }

    /// A structural catalog, not a legal classfile: it carries every constant-pool
    /// tag plus the simple attributes this layer reads, including a `Module`
    /// attribute and bootstrap sites, which no real single class combines. The
    /// reader validates structure, never JVMS co-occurrence rules.
    fn catalog_class() -> (Vec<u8>, Vec<CpRef>) {
        let mut cp = CpBuilder::new();
        let u_catalog = cp.utf8(b"pkg/Catalog");
        let c_catalog = cp.class(u_catalog.index);
        let u_object = cp.utf8(b"java/lang/Object");
        let c_object = cp.class(u_object.index);
        let u_runnable = cp.utf8(b"java/lang/Runnable");
        let c_runnable = cp.class(u_runnable.index);
        let u_field = cp.utf8(b"field");
        let u_int = cp.utf8(b"I");
        let u_const = cp.utf8(b"CONST");
        let u_string = cp.utf8(b"Ljava/lang/String;");
        let s_value = cp.string(u_string.index);
        let i_seven = cp.integer(7);
        let _f_nan = cp.float(0x7fc0_0001);
        let _l_minus_two = cp.long(-2);
        let _d_nan = cp.double(0x7ff8_0000_0000_0001);
        let u_method = cp.utf8(b"method");
        let u_void = cp.utf8(b"()V");
        let u_indy = cp.utf8(b"indy");
        let u_indy_descriptor = cp.utf8(b"()Ljava/lang/Runnable;");
        let nat_indy = cp.name_and_type(u_indy.index, u_indy_descriptor.index);
        let _dyn_indy = cp.dynamic(18, 0, nat_indy.index);
        let u_run = cp.utf8(b"run");
        let nat_run = cp.name_and_type(u_run.index, u_void.index);
        let u_vf = cp.utf8(b"vf");
        let nat_vf = cp.name_and_type(u_vf.index, u_int.index);
        let _fr_vf = cp.member_ref(9, c_object.index, nat_vf.index);
        let mr_run = cp.member_ref(10, c_object.index, nat_run.index);
        let _imr_run = cp.member_ref(11, c_runnable.index, nat_run.index);
        let mh_bootstrap = cp.method_handle(6, mr_run.index);
        let mt_void = cp.method_type(u_void.index);
        let dyn_condy = cp.dynamic(17, 0, nat_run.index);
        let u_package = cp.utf8(b"pkg");
        let package = cp.package(u_package.index);
        let u_module = cp.utf8(b"pkg/module");
        let module = cp.module(u_module.index);
        let a_signature = cp.utf8(b"Signature");
        let u_signature = cp.utf8(b"<T:Ljava/lang/Object;>Ljava/lang/Object;");
        let a_exceptions = cp.utf8(b"Exceptions");
        let u_exception = cp.utf8(b"java/lang/Exception");
        let c_exception = cp.class(u_exception.index);
        let a_inner_classes = cp.utf8(b"InnerClasses");
        let u_inner = cp.utf8(b"pkg/Catalog$Inner");
        let c_inner = cp.class(u_inner.index);
        let u_inner_name = cp.utf8(b"Inner");
        let a_enclosing = cp.utf8(b"EnclosingMethod");
        let a_nest_host = cp.utf8(b"NestHost");
        let u_nest = cp.utf8(b"pkg/Nest");
        let c_nest = cp.class(u_nest.index);
        let a_nest_members = cp.utf8(b"NestMembers");
        let a_permitted = cp.utf8(b"PermittedSubclasses");
        let u_sub = cp.utf8(b"pkg/Sub");
        let c_sub = cp.class(u_sub.index);
        let a_constant_value = cp.utf8(b"ConstantValue");
        let a_module = cp.utf8(b"Module");
        let u_service = cp.utf8(b"pkg/Service");
        let c_service = cp.class(u_service.index);
        let u_provider = cp.utf8(b"pkg/Provider");
        let c_provider = cp.class(u_provider.index);
        let a_bootstrap = cp.utf8(b"BootstrapMethods");
        let (mut bytes, entries) = cp.finish();

        buf_u16(&mut bytes, 0x8021); // ACC_MODULE | ACC_PUBLIC | ACC_SUPER
        buf_u16(&mut bytes, c_catalog.index);
        buf_u16(&mut bytes, c_object.index);
        buf_u16(&mut bytes, 1);
        buf_u16(&mut bytes, c_runnable.index);

        buf_u16(&mut bytes, 2); // fields
        buf_u16(&mut bytes, 0x0002);
        buf_u16(&mut bytes, u_field.index);
        buf_u16(&mut bytes, u_int.index);
        buf_u16(&mut bytes, 0);
        buf_u16(&mut bytes, 0x0018);
        buf_u16(&mut bytes, u_const.index);
        buf_u16(&mut bytes, u_string.index);
        buf_u16(&mut bytes, 1);
        let mut constant_value = Vec::new();
        buf_u16(&mut constant_value, s_value.index);
        attribute(&mut bytes, a_constant_value.index, &constant_value);

        buf_u16(&mut bytes, 1); // methods
        buf_u16(&mut bytes, 0x0401);
        buf_u16(&mut bytes, u_method.index);
        buf_u16(&mut bytes, u_void.index);
        buf_u16(&mut bytes, 2);
        let mut exceptions = Vec::new();
        buf_u16(&mut exceptions, 1);
        buf_u16(&mut exceptions, c_exception.index);
        attribute(&mut bytes, a_exceptions.index, &exceptions);
        let mut signature = Vec::new();
        buf_u16(&mut signature, u_signature.index);
        attribute(&mut bytes, a_signature.index, &signature);

        buf_u16(&mut bytes, 8); // class attributes
        attribute(&mut bytes, a_signature.index, &signature);
        let mut inner_classes = Vec::new();
        buf_u16(&mut inner_classes, 2);
        buf_u16(&mut inner_classes, c_inner.index);
        buf_u16(&mut inner_classes, c_catalog.index);
        buf_u16(&mut inner_classes, u_inner_name.index);
        buf_u16(&mut inner_classes, 0x0009);
        buf_u16(&mut inner_classes, c_catalog.index);
        buf_u16(&mut inner_classes, 0);
        buf_u16(&mut inner_classes, 0);
        buf_u16(&mut inner_classes, 0x1000);
        attribute(&mut bytes, a_inner_classes.index, &inner_classes);
        let mut enclosing = Vec::new();
        buf_u16(&mut enclosing, c_object.index);
        buf_u16(&mut enclosing, nat_run.index);
        attribute(&mut bytes, a_enclosing.index, &enclosing);
        let mut nest_host = Vec::new();
        buf_u16(&mut nest_host, c_nest.index);
        attribute(&mut bytes, a_nest_host.index, &nest_host);
        let mut nest_members = Vec::new();
        buf_u16(&mut nest_members, 1);
        buf_u16(&mut nest_members, c_inner.index);
        attribute(&mut bytes, a_nest_members.index, &nest_members);
        let mut permitted = Vec::new();
        buf_u16(&mut permitted, 1);
        buf_u16(&mut permitted, c_sub.index);
        attribute(&mut bytes, a_permitted.index, &permitted);
        let mut module_content = Vec::new();
        buf_u16(&mut module_content, module.index);
        buf_u16(&mut module_content, 0x0020);
        buf_u16(&mut module_content, 0);
        buf_u16(&mut module_content, 1); // requires
        buf_u16(&mut module_content, module.index);
        buf_u16(&mut module_content, 0x0020);
        buf_u16(&mut module_content, 0);
        buf_u16(&mut module_content, 1); // exports
        buf_u16(&mut module_content, package.index);
        buf_u16(&mut module_content, 0);
        buf_u16(&mut module_content, 1);
        buf_u16(&mut module_content, module.index);
        buf_u16(&mut module_content, 0); // opens
        buf_u16(&mut module_content, 1); // uses
        buf_u16(&mut module_content, c_service.index);
        buf_u16(&mut module_content, 1); // provides
        buf_u16(&mut module_content, c_service.index);
        buf_u16(&mut module_content, 1);
        buf_u16(&mut module_content, c_provider.index);
        attribute(&mut bytes, a_module.index, &module_content);
        let mut bootstrap = Vec::new();
        buf_u16(&mut bootstrap, 1);
        buf_u16(&mut bootstrap, mh_bootstrap.index);
        buf_u16(&mut bootstrap, 4);
        buf_u16(&mut bootstrap, mt_void.index);
        buf_u16(&mut bootstrap, dyn_condy.index);
        buf_u16(&mut bootstrap, s_value.index);
        buf_u16(&mut bootstrap, i_seven.index);
        attribute(&mut bytes, a_bootstrap.index, &bootstrap);

        (bytes, entries)
    }

    #[test]
    fn synthetic_catalog_covers_every_constant_pool_tag_and_its_spans() {
        let (bytes, entries) = catalog_class();
        let mut budget = budget();
        let facts = class_facts(&bytes, &mut budget).unwrap();
        assert_eq!(budget.usage().class_bytes, bytes.len() as u64);
        assert_eq!(budget.usage().result_items, 0);

        // Two reserved slots for Long and Double, no gaps anywhere else.
        assert_eq!(entries.len(), 59);
        assert_eq!(facts.constant_pool.len(), entries.len());
        for (entry, reference) in facts.constant_pool.iter().zip(entries.iter()) {
            assert_eq!(entry.index, reference.index);
            assert_eq!(
                (entry.span.start, entry.span.length),
                (reference.offset, reference.width),
                "entry #{}",
                reference.index
            );
        }
        for pair in facts.constant_pool.windows(2) {
            assert_eq!(pair[0].span.start + pair[0].span.length, pair[1].span.start);
        }
        let lookup = |index: u16| cp_entry(&facts.constant_pool, index).unwrap();
        let utf8 = |index: u16| cp_utf8(&facts.constant_pool, index).unwrap();
        let class_name = |index: u16| cp_class_name(&facts.constant_pool, index).unwrap();
        let index_of = |name: &[u8]| {
            facts
                .constant_pool
                .iter()
                .find(|entry| match &entry.kind {
                    CpEntryKind::Utf8 { bytes } => bytes.0 == name,
                    _ => false,
                })
                .unwrap_or_else(|| panic!("no Utf8 entry for {name:?}"))
                .index
        };

        assert_eq!(facts.access_flags, 0x8021);
        assert_eq!(facts.this_class.raw().0, b"pkg/Catalog");
        assert_eq!(
            facts.super_class.as_ref().unwrap().raw().0,
            b"java/lang/Object"
        );
        assert_eq!(facts.interfaces[0].raw().0, b"java/lang/Runnable");

        let this_class = index_of(b"pkg/Catalog");
        let object = class_entry_for(&facts, b"java/lang/Object");
        let runnable = class_entry_for(&facts, b"java/lang/Runnable");
        let vf = index_of(b"vf");
        let int = index_of(b"I");
        let string = index_of(b"Ljava/lang/String;");
        let package = index_of(b"pkg");
        let module = index_of(b"pkg/module");

        assert_eq!(
            lookup(i_seven_index(&facts)).kind,
            CpEntryKind::Integer { value: 7 }
        );
        assert_eq!(
            lookup(float_index(&facts)).kind,
            CpEntryKind::Float { bits: 0x7fc0_0001 }
        );
        assert_eq!(
            lookup(long_index(&facts)).kind,
            CpEntryKind::Long { value: -2 }
        );
        assert_eq!(
            lookup(double_index(&facts)).kind,
            CpEntryKind::Double {
                bits: 0x7ff8_0000_0000_0001
            }
        );
        assert_eq!(
            lookup(string_entry(&facts)).kind,
            CpEntryKind::String {
                utf8_index: string,
                value: JvmBytes(b"Ljava/lang/String;".to_vec()),
            }
        );
        assert_eq!(
            lookup(class_entry_for(&facts, b"pkg/Catalog")).kind,
            CpEntryKind::Class {
                name_index: this_class,
                name: JvmBytes(b"pkg/Catalog".to_vec()),
            }
        );
        assert_eq!(
            lookup(field_ref_entry(&facts)).kind,
            CpEntryKind::FieldRef {
                class_index: object,
                name_and_type_index: nat_vf_index(&facts),
                owner: JvmBytes(b"java/lang/Object".to_vec()),
                name: JvmBytes(b"vf".to_vec()),
                descriptor: JvmBytes(b"I".to_vec()),
            }
        );
        assert_eq!(
            lookup(method_ref_entry(&facts)).kind,
            CpEntryKind::MethodRef {
                class_index: object,
                name_and_type_index: nat_run_index(&facts),
                owner: JvmBytes(b"java/lang/Object".to_vec()),
                name: JvmBytes(b"run".to_vec()),
                descriptor: JvmBytes(b"()V".to_vec()),
            }
        );
        assert_eq!(
            lookup(interface_method_ref_entry(&facts)).kind,
            CpEntryKind::InterfaceMethodRef {
                class_index: runnable,
                name_and_type_index: nat_run_index(&facts),
                owner: JvmBytes(b"java/lang/Runnable".to_vec()),
                name: JvmBytes(b"run".to_vec()),
                descriptor: JvmBytes(b"()V".to_vec()),
            }
        );
        assert_eq!(
            lookup(nat_vf_index(&facts)).kind,
            CpEntryKind::NameAndType {
                name_index: vf,
                descriptor_index: int,
                name: JvmBytes(b"vf".to_vec()),
                descriptor: JvmBytes(b"I".to_vec()),
            }
        );
        assert_eq!(
            lookup(method_handle_entry(&facts)).kind,
            CpEntryKind::MethodHandle {
                reference_kind: 6,
                reference_index: method_ref_entry(&facts),
            }
        );
        assert_eq!(
            lookup(method_type_entry(&facts)).kind,
            CpEntryKind::MethodType {
                descriptor_index: index_of_utf8(&facts, b"()V"),
                descriptor: JvmBytes(b"()V".to_vec()),
            }
        );
        assert_eq!(
            lookup(dynamic_entry(&facts)).kind,
            CpEntryKind::Dynamic {
                bootstrap_method_attr_index: 0,
                name_and_type_index: nat_run_index(&facts),
                name: JvmBytes(b"run".to_vec()),
                descriptor: JvmBytes(b"()V".to_vec()),
            }
        );
        assert_eq!(
            lookup(invoke_dynamic_entry(&facts)).kind,
            CpEntryKind::InvokeDynamic {
                bootstrap_method_attr_index: 0,
                name_and_type_index: nat_indy_index(&facts),
                name: JvmBytes(b"indy".to_vec()),
                descriptor: JvmBytes(b"()Ljava/lang/Runnable;".to_vec()),
            }
        );
        assert_eq!(
            lookup(module_entry(&facts)).kind,
            CpEntryKind::Module {
                name_index: module,
                name: JvmBytes(b"pkg/module".to_vec()),
            }
        );
        assert_eq!(
            lookup(package_entry(&facts)).kind,
            CpEntryKind::Package {
                name_index: package,
                name: JvmBytes(b"pkg".to_vec()),
            }
        );

        // Reserved slots hold no entry, so an index into one is not resolvable.
        assert_eq!(
            error_code(cp_entry(&facts.constant_pool, l_minus_two_slot(&facts)).unwrap_err()),
            "classfile_invalid_constant_pool_index"
        );

        // Class-index expansion goes through `CONSTANT_Class`, and the UTF-8 payload
        // is reachable by its own index; the two must agree on the same bytes.
        for name in [
            b"pkg/Catalog".as_slice(),
            b"java/lang/Object".as_slice(),
            b"java/lang/Runnable".as_slice(),
            b"pkg/Catalog$Inner".as_slice(),
            b"pkg/Nest".as_slice(),
            b"pkg/Sub".as_slice(),
            b"java/lang/Exception".as_slice(),
            b"pkg/Service".as_slice(),
            b"pkg/Provider".as_slice(),
        ] {
            assert_eq!(
                class_name(class_entry_for(&facts, name)),
                JvmBytes(name.to_vec()),
                "{name:?}"
            );
            assert_eq!(
                utf8(index_of_utf8(&facts, name)),
                JvmBytes(name.to_vec()),
                "{name:?}"
            );
        }
    }

    #[test]
    fn synthetic_catalog_member_and_class_attributes_are_typed() {
        let (bytes, _) = catalog_class();
        let mut budget = budget();
        let facts = class_facts(&bytes, &mut budget).unwrap();

        // A field without attributes yields no facts, and an unrelated attribute
        // (`Code`) is never read.
        assert_eq!(
            attribute_facts(
                &bytes,
                &facts.fields[0].attributes,
                &facts.constant_pool,
                &mut budget
            )
            .unwrap(),
            AttributeFacts::default()
        );

        let field = attribute_facts(
            &bytes,
            &facts.fields[1].attributes,
            &facts.constant_pool,
            &mut budget,
        )
        .unwrap();
        assert_eq!(field.constant_value, Some(CpIndexOf(string_entry(&facts))));
        assert_eq!(field.signature, None);
        assert!(field.exceptions.is_empty());
        assert!(field.module.is_none());

        let method = attribute_facts(
            &bytes,
            &facts.methods[0].attributes,
            &facts.constant_pool,
            &mut budget,
        )
        .unwrap();
        assert_eq!(
            method.exceptions,
            vec![JvmBytes(b"java/lang/Exception".to_vec())]
        );
        assert_eq!(
            method.signature,
            Some(JvmBytes(
                b"<T:Ljava/lang/Object;>Ljava/lang/Object;".to_vec()
            ))
        );
        assert_eq!(method.constant_value, None);

        let class =
            attribute_facts(&bytes, &facts.attributes, &facts.constant_pool, &mut budget).unwrap();
        assert_eq!(
            class.signature,
            Some(JvmBytes(
                b"<T:Ljava/lang/Object;>Ljava/lang/Object;".to_vec()
            ))
        );
        assert_eq!(class.nest_host, Some(JvmBytes(b"pkg/Nest".to_vec())));
        assert_eq!(
            class.nest_members,
            vec![JvmBytes(b"pkg/Catalog$Inner".to_vec())]
        );
        assert_eq!(
            class.permitted_subclasses,
            vec![JvmBytes(b"pkg/Sub".to_vec())]
        );
        assert!(class.exceptions.is_empty());
        assert_eq!(class.inner_classes.len(), 2);
        assert_eq!(
            class.inner_classes[0],
            InnerClassFacts {
                class_index: class_entry_for(&facts, b"pkg/Catalog$Inner"),
                outer_class_index: class_entry_for(&facts, b"pkg/Catalog"),
                inner_name: Some(JvmBytes(b"Inner".to_vec())),
                access_flags: 0x0009,
            }
        );
        // `inner_name_index` 0 is the anonymous case and not a missing fact.
        assert_eq!(
            class.inner_classes[1],
            InnerClassFacts {
                class_index: class_entry_for(&facts, b"pkg/Catalog"),
                outer_class_index: 0,
                inner_name: None,
                access_flags: 0x1000,
            }
        );
        assert_eq!(
            class.enclosing_method,
            Some(EnclosingMethodFacts {
                class_index: class_entry_for(&facts, b"java/lang/Object"),
                method_index: nat_run_index(&facts),
            })
        );
        assert_eq!(class.constant_value, None);
        let module = class.module.expect("module facts");
        assert_eq!(module.uses, vec![JvmBytes(b"pkg/Service".to_vec())]);
        assert_eq!(
            module.provides,
            vec![ProvidesFacts {
                service: JvmBytes(b"pkg/Service".to_vec()),
                implementations: vec![JvmBytes(b"pkg/Provider".to_vec())],
            }]
        );
    }

    /// The member table and class tail of one `AnnotationDefault` fixture: a class whose method table
    /// declares one member per element of `members`, each carrying one `AnnotationDefault` attribute
    /// per content of its own list — an empty list is a member that declares no attribute at all.
    fn annotation_default_tail(
        this_class: u16,
        super_class: u16,
        name: u16,
        descriptor: u16,
        attribute_name: u16,
        members: &[Vec<Vec<u8>>],
    ) -> Vec<u8> {
        let mut bytes = Vec::new();
        buf_u16(&mut bytes, 0x0021);
        buf_u16(&mut bytes, this_class);
        buf_u16(&mut bytes, super_class);
        buf_u16(&mut bytes, 0); // interfaces
        buf_u16(&mut bytes, 0); // fields
        buf_u16(&mut bytes, u16::try_from(members.len()).unwrap());
        for contents in members {
            buf_u16(&mut bytes, 0x0401); // public abstract
            buf_u16(&mut bytes, name);
            buf_u16(&mut bytes, descriptor);
            buf_u16(&mut bytes, u16::try_from(contents.len()).unwrap());
            for content in contents {
                attribute(&mut bytes, attribute_name, content);
            }
        }
        buf_u16(&mut bytes, 0); // class attributes
        bytes
    }

    /// One `element_value` content: the tag byte and the one index every one-index tag names.
    fn tag_with_index(tag: u8, index: u16) -> Vec<u8> {
        let mut content = vec![tag];
        buf_u16(&mut content, index);
        content
    }

    /// One `element_value` content of a tag that names two indexes (`e`, `@`).
    fn tag_with_indices(tag: u8, first: u16, second: u16) -> Vec<u8> {
        let mut content = vec![tag];
        buf_u16(&mut content, first);
        buf_u16(&mut content, second);
        content
    }

    /// Every member's own `AnnotationDefault`, in the fixture's method-table order, as the attribute
    /// read publishes it.
    fn annotation_defaults_of(bytes: &[u8]) -> Vec<Option<ElementValueFacts>> {
        let mut budget = budget();
        let facts = class_facts(bytes, &mut budget).expect("the default fixture is decodable");
        facts
            .methods
            .iter()
            .map(|method| {
                attribute_facts(bytes, &method.attributes, &facts.constant_pool, &mut budget)
                    .expect("the annotation defaults read")
                    .annotation_default
            })
            .collect()
    }

    /// How many `[` productions one value nests around whatever it holds, the outermost counted.
    fn array_depth(value: &ElementValueFacts) -> usize {
        match value {
            ElementValueFacts::Array(elements) if elements.len() == 1 => {
                1 + array_depth(&elements[0])
            }
            ElementValueFacts::Array(_) => 1,
            _ => 0,
        }
    }

    /// One `AnnotationDefault` content whose value nests `levels` arrays around one `I#index`.
    fn nested_array(levels: usize, index: u16) -> Vec<u8> {
        let mut value = tag_with_index(b'I', index);
        for _ in 0..levels {
            let mut wrapper = vec![b'['];
            buf_u16(&mut wrapper, 1);
            wrapper.extend_from_slice(&value);
            value = wrapper;
        }
        value
    }

    #[test]
    fn annotation_default_reads_every_element_value_tag() {
        let mut cp = CpBuilder::new();
        let u_test = cp.utf8(b"Test");
        let c_test = cp.class(u_test.index);
        let u_object = cp.utf8(b"java/lang/Object");
        let c_object = cp.class(u_object.index);
        let u_method = cp.utf8(b"value");
        let u_descriptor = cp.utf8(b"()V");
        let a_default = cp.utf8(b"AnnotationDefault");
        let integer = cp.integer(7);
        let letter = cp.integer(65);
        let flag = cp.integer(1);
        let long = cp.long(5);
        let float = cp.float(0x3f00_0000);
        let double = cp.double(0x3fe0_0000_0000_0000);
        let text = cp.utf8(b"x");
        let kind = cp.utf8(b"LKind;");
        let one = cp.utf8(b"ONE");
        let string = cp.utf8(b"Ljava/lang/String;");
        let count = cp.utf8(b"count");
        let (mut bytes, _) = cp.finish();
        bytes.extend_from_slice(&annotation_default_tail(
            c_test.index,
            c_object.index,
            u_method.index,
            u_descriptor.index,
            a_default.index,
            &[
                vec![tag_with_index(b'I', integer.index)],
                vec![tag_with_index(b'S', integer.index)],
                vec![tag_with_index(b'B', integer.index)],
                vec![tag_with_index(b'Z', flag.index)],
                vec![tag_with_index(b'C', letter.index)],
                vec![tag_with_index(b'J', long.index)],
                vec![tag_with_index(b'F', float.index)],
                vec![tag_with_index(b'D', double.index)],
                vec![tag_with_index(b's', text.index)],
                vec![tag_with_indices(b'e', kind.index, one.index)],
                vec![tag_with_index(b'c', string.index)],
                // One annotation with two pairs, the second of them an array: the `@` and `[`
                // productions nest, so a walk that consumed either one alone could not find the
                // attribute's own end.
                vec![{
                    let mut content = vec![b'@'];
                    buf_u16(&mut content, kind.index);
                    buf_u16(&mut content, 2); // element_value_pairs
                    buf_u16(&mut content, count.index);
                    content.extend_from_slice(&tag_with_index(b'I', integer.index));
                    buf_u16(&mut content, count.index);
                    content.extend_from_slice(&tag_with_index(b'[', 2));
                    content.extend_from_slice(&tag_with_index(b'Z', flag.index));
                    content.extend_from_slice(&tag_with_index(b'C', letter.index));
                    content
                }],
                vec![],
            ],
        ));

        let constant = |tag, index| {
            Some(ElementValueFacts::Constant {
                tag,
                index: CpIndexOf(index),
            })
        };
        let defaults = annotation_defaults_of(&bytes);
        assert_eq!(
            defaults[0],
            constant(ElementConstantTag::Integer, integer.index)
        );
        assert_eq!(
            defaults[1],
            constant(ElementConstantTag::Short, integer.index)
        );
        assert_eq!(
            defaults[2],
            constant(ElementConstantTag::Byte, integer.index)
        );
        assert_eq!(
            defaults[3],
            constant(ElementConstantTag::Boolean, flag.index)
        );
        assert_eq!(
            defaults[4],
            constant(ElementConstantTag::Char, letter.index)
        );
        assert_eq!(defaults[5], constant(ElementConstantTag::Long, long.index));
        assert_eq!(
            defaults[6],
            constant(ElementConstantTag::Float, float.index)
        );
        assert_eq!(
            defaults[7],
            constant(ElementConstantTag::Double, double.index)
        );
        assert_eq!(
            defaults[8],
            Some(ElementValueFacts::Utf8(JvmBytes(b"x".to_vec())))
        );
        assert_eq!(
            defaults[9],
            Some(ElementValueFacts::Enum {
                type_descriptor: JvmBytes(b"LKind;".to_vec()),
                constant_name: JvmBytes(b"ONE".to_vec()),
            })
        );
        assert_eq!(
            defaults[10],
            Some(ElementValueFacts::Class(JvmBytes(
                b"Ljava/lang/String;".to_vec()
            )))
        );
        assert_eq!(
            defaults[11],
            Some(ElementValueFacts::Annotation {
                type_descriptor: JvmBytes(b"LKind;".to_vec()),
                elements: vec![
                    ElementValuePairFacts {
                        name: JvmBytes(b"count".to_vec()),
                        value: ElementValueFacts::Constant {
                            tag: ElementConstantTag::Integer,
                            index: CpIndexOf(integer.index),
                        },
                    },
                    ElementValuePairFacts {
                        name: JvmBytes(b"count".to_vec()),
                        value: ElementValueFacts::Array(vec![
                            ElementValueFacts::Constant {
                                tag: ElementConstantTag::Boolean,
                                index: CpIndexOf(flag.index),
                            },
                            ElementValueFacts::Constant {
                                tag: ElementConstantTag::Char,
                                index: CpIndexOf(letter.index),
                            },
                        ]),
                    },
                ],
            })
        );
        // The last member declares no attribute: no `element_value` is invented for it, and the
        // `AnnotationDefault` of the members beside it is not leaked into it.
        assert_eq!(defaults[12], None);
    }

    #[test]
    fn a_damaged_annotation_default_is_a_structured_error() {
        let mut cp = CpBuilder::new();
        let u_test = cp.utf8(b"Test");
        let c_test = cp.class(u_test.index);
        let u_object = cp.utf8(b"java/lang/Object");
        let c_object = cp.class(u_object.index);
        let u_method = cp.utf8(b"value");
        let u_descriptor = cp.utf8(b"()V");
        let a_default = cp.utf8(b"AnnotationDefault");
        let integer = cp.integer(7);
        let text = cp.utf8(b"x");
        let (mut bytes, _) = cp.finish();
        // One class, one member per way an `AnnotationDefault` can be damaged: two attributes, an
        // unknown tag, content the attribute's own structure does not fill, nesting deeper than the
        // reader walks, and — the control — the deepest nesting it does walk.
        let single = tag_with_index(b's', text.index);
        bytes.extend_from_slice(&annotation_default_tail(
            c_test.index,
            c_object.index,
            u_method.index,
            u_descriptor.index,
            a_default.index,
            &[
                vec![single.clone(), single.clone()],
                vec![tag_with_index(b'Q', integer.index)],
                {
                    let mut trailing = single;
                    trailing.push(0xff);
                    vec![trailing]
                },
                vec![nested_array(MAX_ELEMENT_VALUE_DEPTH + 2, integer.index)],
                vec![nested_array(MAX_ELEMENT_VALUE_DEPTH, integer.index)],
            ],
        ));

        let mut budget = budget();
        let facts = class_facts(&bytes, &mut budget).expect("the default fixture is decodable");
        let mut error = |member: usize| {
            attribute_facts(
                &bytes,
                &facts.methods[member].attributes,
                &facts.constant_pool,
                &mut budget,
            )
            .expect_err("the attribute is damaged")
        };
        assert_eq!(error_code(error(0)), "classfile_duplicate_attribute");
        assert_eq!(error_code(error(1)), "classfile_invalid_attribute_content");
        assert_eq!(error_code(error(2)), "classfile_invalid_attribute_content");
        assert_eq!(error_code(error(3)), "classfile_element_value_depth");

        // The deepest value the reader walks is still a value it reads whole: the bound is a bound
        // on nesting, not a refusal of a deep declaration that is still inside it.
        let deepest = attribute_facts(
            &bytes,
            &facts.methods[4].attributes,
            &facts.constant_pool,
            &mut budget,
        )
        .expect("the deepest value inside the bound reads")
        .annotation_default
        .expect("the member declares an attribute");
        assert_eq!(array_depth(&deepest), MAX_ELEMENT_VALUE_DEPTH);
    }

    #[test]
    fn bootstrap_methods_need_a_handle_and_loadable_arguments() {
        let (bytes, _) = catalog_class();
        let mut budget = budget();
        let facts = class_facts(&bytes, &mut budget).unwrap();
        let shell = find_shell(&facts.attributes, b"BootstrapMethods").clone();
        let parsed = bootstrap_methods(&bytes, &shell, &facts.constant_pool, &mut budget).unwrap();
        assert_eq!(parsed.len(), 1);
        let handle = bootstrap_handle_index(&facts);
        assert_eq!(parsed[0].method_ref, handle);
        assert_eq!(
            parsed[0].arguments,
            vec![
                method_type_entry(&facts),
                dynamic_entry(&facts),
                string_entry(&facts),
                i_seven_index(&facts),
            ]
        );
        assert_eq!(
            cp_entry(&facts.constant_pool, handle).unwrap().kind,
            CpEntryKind::MethodHandle {
                reference_kind: 6,
                reference_index: method_ref_entry(&facts),
            }
        );

        // A bootstrap handle that is not a MethodHandle, and an argument that is
        // not a loadable constant, are structured errors.
        let bad_handle = bootstrap_class(|content| {
            buf_u16(content, 1);
            buf_u16(content, method_type_index());
            buf_u16(content, 0);
        });
        assert_eq!(
            error_code(
                bootstrap_methods(
                    &bad_handle.0,
                    &bad_handle.1,
                    &bad_handle.2,
                    &mut fresh_budget()
                )
                .unwrap_err()
            ),
            "classfile_constant_pool_tag_mismatch"
        );

        let bad_argument = bootstrap_class(|content| {
            buf_u16(content, 1);
            buf_u16(content, 4);
            buf_u16(content, 1);
            buf_u16(content, 6);
        });
        assert_eq!(
            error_code(
                bootstrap_methods(
                    &bad_argument.0,
                    &bad_argument.1,
                    &bad_argument.2,
                    &mut fresh_budget()
                )
                .unwrap_err()
            ),
            "classfile_constant_pool_tag_mismatch"
        );

        // Content that declares more arguments than it holds stops structured.
        let overrun = bootstrap_class(|content| {
            buf_u16(content, 1);
            buf_u16(content, 4);
            buf_u16(content, 2);
            buf_u16(content, 8);
        });
        assert_eq!(
            error_code(
                bootstrap_methods(&overrun.0, &overrun.1, &overrun.2, &mut fresh_budget())
                    .unwrap_err()
            ),
            "classfile_invalid_attribute_content"
        );

        // Trailing garbage behind a complete structure is refused as well.
        let trailing = bootstrap_class(|content| {
            buf_u16(content, 1);
            buf_u16(content, 4);
            buf_u16(content, 0);
            content.push(0);
        });
        assert_eq!(
            error_code(
                bootstrap_methods(&trailing.0, &trailing.1, &trailing.2, &mut fresh_budget())
                    .unwrap_err()
            ),
            "classfile_invalid_attribute_content"
        );
    }

    #[test]
    fn duplicate_attributes_and_attribute_structure_overruns_are_errors() {
        let (mut bytes, _) = catalog_class();
        let mut budget = budget();
        let facts = class_facts(&bytes, &mut budget).unwrap();
        let signature_shell = find_shell(&facts.attributes, b"Signature").clone();
        assert_eq!(
            error_code(
                attribute_facts(
                    &bytes,
                    &[signature_shell.clone(), signature_shell.clone()],
                    &facts.constant_pool,
                    &mut budget
                )
                .unwrap_err()
            ),
            "classfile_duplicate_attribute"
        );

        // An `Exceptions` attribute that declares more entries than it holds.
        let exceptions_name = index_of_utf8(&facts, b"Exceptions");
        let mut short_content = Vec::new();
        buf_u16(&mut short_content, 2);
        buf_u16(
            &mut short_content,
            class_entry_for(&facts, b"java/lang/Exception"),
        );
        let start = bytes.len();
        attribute(&mut bytes, exceptions_name, &short_content);
        let short_shell = AttributeShell {
            name: signature_shell.name.clone(),
            span: ByteSpan::new(start as u64, (6 + short_content.len()) as u64),
            content_span: ByteSpan::new((start + 6) as u64, short_content.len() as u64),
        };
        assert_eq!(
            error_code(
                attribute_facts(&bytes, &[short_shell], &facts.constant_pool, &mut budget)
                    .unwrap_err()
            ),
            "classfile_invalid_attribute_content"
        );
    }

    #[test]
    fn method_parameters_are_complete_unique_and_charged_once() {
        let (catalog, _) = catalog_class();
        let catalog_facts = class_facts(&catalog, &mut budget()).unwrap();
        let name = index_of_utf8(&catalog_facts, b"method");
        let pool = catalog_facts.constant_pool;
        let shell_for = |content: &[u8]| {
            let mut bytes = Vec::new();
            attribute(&mut bytes, name, content);
            let shell = AttributeShell {
                name: JvmString::from_parts(
                    b"MethodParameters".to_vec(),
                    "MethodParameters".encode_utf16().collect(),
                ),
                span: ByteSpan::new(0, bytes.len() as u64),
                content_span: ByteSpan::new(6, content.len() as u64),
            };
            (bytes, shell)
        };
        let mut content = vec![1];
        buf_u16(&mut content, name);
        buf_u16(&mut content, 0x0010);
        let (bytes, shell) = shell_for(&content);
        let mut limits = unlimited_limits();
        limits.attribute_bytes = bytes.len() as u64;
        let mut exact = Budget::new(limits);
        let parameters = attribute_facts(&bytes, &[shell.clone()], &pool, &mut exact)
            .unwrap()
            .method_parameters
            .unwrap();
        assert_eq!(parameters[0].name_index, name);
        assert_eq!(parameters[0].name.as_ref().unwrap().0, b"method");
        assert_eq!(parameters[0].access_flags, 0x0010);
        assert_eq!(exact.usage().attribute_bytes, bytes.len() as u64);
        assert_eq!(
            error_code(
                attribute_facts(&bytes, &[shell.clone(), shell], &pool, &mut budget()).unwrap_err()
            ),
            "classfile_duplicate_attribute"
        );
        for malformed in [
            vec![1, 0, 0],       // truncated entry
            vec![0, 0],          // trailing byte
            vec![1, 0, 0, 0, 1], // invalid flag
        ] {
            let (bytes, shell) = shell_for(&malformed);
            assert_eq!(
                error_code(attribute_facts(&bytes, &[shell], &pool, &mut budget()).unwrap_err()),
                "classfile_invalid_attribute_content"
            );
        }
        let (bytes, shell) = shell_for(&[1, 0xff, 0xff, 0, 0]);
        assert_eq!(
            error_code(attribute_facts(&bytes, &[shell], &pool, &mut budget()).unwrap_err()),
            "classfile_invalid_constant_pool_index"
        );
        let mut low = unlimited_limits();
        low.attribute_bytes = (content.len() + 5) as u64;
        let mut low = Budget::new(low);
        let (bytes, shell) = shell_for(&content);
        assert!(matches!(
            attribute_facts(&bytes, &[shell], &pool, &mut low),
            Err(Error::BudgetExceeded { .. })
        ));
        assert_eq!(low.usage().attribute_bytes, 0);
        let cancellation = crate::budget::CancellationToken::new();
        cancellation.cancel();
        let mut cancelled = Budget::with_cancellation_token(unlimited_limits(), cancellation);
        let (bytes, shell) = shell_for(&content);
        assert!(matches!(
            attribute_facts(&bytes, &[shell], &pool, &mut cancelled),
            Err(Error::Cancelled { .. })
        ));
    }

    #[test]
    fn layout_verification_rejects_a_mismatched_pool() {
        let (bytes, _) = catalog_class();
        let layout = measure_constant_pool(&bytes, &Budget::new(unlimited_limits())).unwrap();
        let class = Class::new(&bytes).unwrap();
        assert!(verify_constant_pool_layout(&bytes, &layout, &class).is_ok());

        // The same class must reproduce the same layout, so the check is not
        // vacuous.
        let (other, _) = catalog_class();
        let other_layout = measure_constant_pool(&other, &Budget::new(unlimited_limits())).unwrap();
        assert!(verify_constant_pool_layout(&bytes, &other_layout, &class).is_ok());

        // A layout measured from a different pool, and a pool whose bytes no longer
        // match the tags, both stop instead of producing spans that merely look
        // plausible.
        let small = bootstrap_class(|content| {
            buf_u16(content, 0);
        });
        let small_layout =
            measure_constant_pool(&small.0, &Budget::new(unlimited_limits())).unwrap();
        assert!(verify_constant_pool_layout(&bytes, &small_layout, &class).is_err());

        // Retagging an entry changes the width of the following entries: the walk
        // reports a structured error instead of slicing plausible-looking bytes.
        let mut retagged = bytes.clone();
        retagged[10] = 8; // slot 1 is a Utf8 entry; `CONSTANT_String` is narrower
        assert!(matches!(
            measure_constant_pool(&retagged, &Budget::new(unlimited_limits())),
            Err(Error::InvalidInput { .. })
        ));
        assert!(matches!(
            class_facts(&retagged, &mut budget()),
            Err(Error::InvalidInput { .. })
        ));
    }

    #[test]
    fn truncated_module_attribute_is_a_structured_error() {
        let (bytes, _) = catalog_class();
        let mut budget = budget();
        let facts = class_facts(&bytes, &mut budget).unwrap();

        // The cursor stops exactly at the end of a well-formed Module attribute, so
        // a truncated Module attribute is a structured error, not an empty one.
        let shell = find_shell(&facts.attributes, b"Module").clone();
        let truncated = AttributeShell {
            name: shell.name.clone(),
            span: ByteSpan::new(shell.span.start, shell.span.length - 1),
            content_span: ByteSpan::new(shell.content_span.start, shell.content_span.length - 1),
        };
        assert_eq!(
            error_code(
                attribute_facts(&bytes, &[truncated], &facts.constant_pool, &mut budget)
                    .unwrap_err()
            ),
            "classfile_invalid_attribute_content"
        );
    }
}

/// Test-only class-file builder shared by the reader, raw-CFG and call-context unit tests.
///
/// It builds the smallest class the real reader path accepts: `Test.method()V` at a chosen
/// class-file version whose `Code` attribute holds the caller's bytes verbatim. The constant
/// pool also carries the entries an array-creation, interface-call or initialization fixture
/// names — the class `[[I` at slot 9, the interface method `run(J)V` at slot 15, and the
/// constructor calls `Test.<init>()V` at slot 18 and `java/lang/Object.<init>()V` at slot 19 — so
/// a fixture can point at a real entry instead of a placeholder. Nothing here fabricates facts:
/// the tests that use it read these bytes through `class_facts`/`method_code_facts`.
///
/// The gate is a feature as well as `test` because this builder is shared across module
/// boundaries that become crate boundaries: the raw-CFG and call-context tests move to
/// `jarde-jvm`, whose `cfg(test)` cannot see anything here. Enabling `test-support` from a
/// dev-dependency keeps this builder reachable there without putting it in the production API —
/// the feature is never enabled by a normal dependency, and nothing in the module is `pub` in
/// the package sense. Note that `--all-features` (as CI runs) does enable it, so the module must
/// keep compiling with the warning set on.
#[cfg(any(test, feature = "test-support"))]
#[allow(
    dead_code,
    reason = "used by this crate's tests, or by a dependent crate's test build"
)]
pub mod test_class {
    /// Class file (minor 0, major `major`) with one `method()V` whose body is `code`.
    pub fn single_method(major: u16, max_stack: u16, max_locals: u16, code: &[u8]) -> Vec<u8> {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&0xcafebabe_u32.to_be_bytes());
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, major);
        u16_be(&mut bytes, 20);
        utf8(&mut bytes, b"Test"); // 1
        class(&mut bytes, 1); // 2
        utf8(&mut bytes, b"java/lang/Object"); // 3
        class(&mut bytes, 3); // 4
        utf8(&mut bytes, b"method"); // 5
        utf8(&mut bytes, b"()V"); // 6
        utf8(&mut bytes, b"Code"); // 7
        utf8(&mut bytes, b"[[I"); // 8
        class(&mut bytes, 8); // 9
        utf8(&mut bytes, b"java/lang/Runnable"); // 10
        class(&mut bytes, 10); // 11
        utf8(&mut bytes, b"run"); // 12
        utf8(&mut bytes, b"(J)V"); // 13
        bytes.push(12); // 14: NameAndType run:(J)V
        u16_be(&mut bytes, 12);
        u16_be(&mut bytes, 13);
        bytes.push(11); // 15: InterfaceMethodRef java/lang/Runnable.run:(J)V
        u16_be(&mut bytes, 11);
        u16_be(&mut bytes, 14);
        // 16..19: the constructor calls the frame pass's initialization cases name — the class's
        // own `Test.<init>()V` and the superclass's `java/lang/Object.<init>()V`, which share one
        // name-and-type. They are appended **after** every entry above, so the fixtures that point
        // at 2, 9, 11 or 15 keep pointing at what they name.
        utf8(&mut bytes, b"<init>"); // 16
        bytes.push(12); // 17: NameAndType <init>:()V
        u16_be(&mut bytes, 16);
        u16_be(&mut bytes, 6);
        bytes.push(10); // 18: MethodRef Test.<init>:()V
        u16_be(&mut bytes, 2);
        u16_be(&mut bytes, 17);
        bytes.push(10); // 19: MethodRef java/lang/Object.<init>:()V
        u16_be(&mut bytes, 4);
        u16_be(&mut bytes, 17);
        u16_be(&mut bytes, 0x0021);
        u16_be(&mut bytes, 2);
        u16_be(&mut bytes, 4);
        u16_be(&mut bytes, 0); // interfaces
        u16_be(&mut bytes, 0); // fields
        u16_be(&mut bytes, 1); // methods
        u16_be(&mut bytes, 0x0009);
        u16_be(&mut bytes, 5);
        u16_be(&mut bytes, 6);
        u16_be(&mut bytes, 1); // attributes
        let mut content = Vec::new();
        u16_be(&mut content, max_stack);
        u16_be(&mut content, max_locals);
        content.extend_from_slice(
            &u32::try_from(code.len())
                .expect("fixture code fits u32")
                .to_be_bytes(),
        );
        content.extend_from_slice(code);
        u16_be(&mut content, 0); // exception table
        u16_be(&mut content, 0); // Code attributes
        u16_be(&mut bytes, 7);
        bytes.extend_from_slice(
            &u32::try_from(content.len())
                .expect("fixture attribute fits u32")
                .to_be_bytes(),
        );
        bytes.extend_from_slice(&content);
        u16_be(&mut bytes, 0); // class attributes
        bytes
    }

    fn u16_be(bytes: &mut Vec<u8>, value: u16) {
        bytes.extend_from_slice(&value.to_be_bytes());
    }

    fn utf8(bytes: &mut Vec<u8>, value: &[u8]) {
        bytes.push(1);
        u16_be(
            bytes,
            u16::try_from(value.len()).expect("fixture name fits u16"),
        );
        bytes.extend_from_slice(value);
    }

    /// The same class with one wide floating pool constant at index 20 and one fresh descriptor
    /// UTF-8 entry at index 21 that the method header names, so a body can `ldc`/`ldc2_w` a
    /// floating constant this pool states without disturbing what the entries above name.
    ///
    /// `tag` is the pool tag of the constant (4 float, 6 double) and `payload` its big-endian
    /// bits; `descriptor` spells the method's own descriptor.
    pub fn single_method_floating(
        major: u16,
        max_stack: u16,
        max_locals: u16,
        tag: u8,
        payload: &[u8],
        descriptor: &[u8],
        code: &[u8],
    ) -> Vec<u8> {
        // A wide constant (a `long` or a `double`) takes **two** pool slots (JVMS 4.4.5), so the
        // descriptor entry and the declared pool count move up one for it.
        let wide = tag == 5 || tag == 6;
        let descriptor_index: u16 = if wide { 22 } else { 21 };
        let pool_count: u16 = if wide { 23 } else { 22 };
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&0xcafebabe_u32.to_be_bytes());
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, major);
        u16_be(&mut bytes, pool_count);
        utf8(&mut bytes, b"Test"); // 1
        class(&mut bytes, 1); // 2
        utf8(&mut bytes, b"java/lang/Object"); // 3
        class(&mut bytes, 3); // 4
        utf8(&mut bytes, b"method"); // 5
        utf8(&mut bytes, b"()V"); // 6
        utf8(&mut bytes, b"Code"); // 7
        utf8(&mut bytes, b"[[I"); // 8
        class(&mut bytes, 8); // 9
        utf8(&mut bytes, b"java/lang/Runnable"); // 10
        class(&mut bytes, 10); // 11
        utf8(&mut bytes, b"run"); // 12
        utf8(&mut bytes, b"(J)V"); // 13
        bytes.push(12); // 14: NameAndType run:(J)V
        u16_be(&mut bytes, 12);
        u16_be(&mut bytes, 13);
        bytes.push(11); // 15: InterfaceMethodRef java/lang/Runnable.run:(J)V
        u16_be(&mut bytes, 11);
        u16_be(&mut bytes, 14);
        utf8(&mut bytes, b"<init>"); // 16
        bytes.push(12); // 17: NameAndType <init>:()V
        u16_be(&mut bytes, 16);
        u16_be(&mut bytes, 6);
        bytes.push(10); // 18: MethodRef Test.<init>:()V
        u16_be(&mut bytes, 2);
        u16_be(&mut bytes, 17);
        bytes.push(10); // 19: MethodRef java/lang/Object.<init>:()V
        u16_be(&mut bytes, 4);
        u16_be(&mut bytes, 17);
        bytes.push(tag); // 20: the floating constant
        bytes.extend_from_slice(payload);
        utf8(&mut bytes, descriptor); // 21 (22 for a wide constant): the method's own descriptor
        u16_be(&mut bytes, 0x0021);
        u16_be(&mut bytes, 2);
        u16_be(&mut bytes, 4);
        u16_be(&mut bytes, 0); // interfaces
        u16_be(&mut bytes, 0); // fields
        u16_be(&mut bytes, 1); // methods
        u16_be(&mut bytes, 0x0009);
        u16_be(&mut bytes, 5);
        u16_be(&mut bytes, descriptor_index); // descriptor: the fresh entry this builder appended
        u16_be(&mut bytes, 1); // attributes
        let mut content = Vec::new();
        u16_be(&mut content, max_stack);
        u16_be(&mut content, max_locals);
        content.extend_from_slice(
            &u32::try_from(code.len())
                .expect("fixture code fits u32")
                .to_be_bytes(),
        );
        content.extend_from_slice(code);
        u16_be(&mut content, 0); // exception table
        u16_be(&mut content, 0); // Code attributes
        u16_be(&mut bytes, 7);
        bytes.extend_from_slice(
            &u32::try_from(content.len())
                .expect("fixture attribute fits u32")
                .to_be_bytes(),
        );
        bytes.extend_from_slice(&content);
        u16_be(&mut bytes, 0); // class attributes
        bytes
    }

    fn class(bytes: &mut Vec<u8>, name: u16) {
        bytes.push(7);
        u16_be(bytes, name);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::budget::{BudgetDimension, CancellationToken, Limits};
    use crate::release_registry::ClassfileLocation;
    use proptest::prelude::*;

    fn limits(value: u64) -> Limits {
        Limits {
            input_bytes: value,
            archive_entries: value,
            entry_bytes: value,
            read_bytes: value,
            class_bytes: value,
            attribute_bytes: value,
            code_bytes: value,
            result_items: value,
            output_bytes: value,
            nested_depth: value,
            elapsed_millis: u64::MAX,
            ..Limits::default()
        }
    }

    fn u16_be(output: &mut Vec<u8>, value: u16) {
        output.extend_from_slice(&value.to_be_bytes());
    }

    fn u32_be(output: &mut Vec<u8>, value: u32) {
        output.extend_from_slice(&value.to_be_bytes());
    }

    fn utf8(output: &mut Vec<u8>, value: &[u8]) {
        output.push(1);
        u16_be(output, u16::try_from(value.len()).unwrap());
        output.extend_from_slice(value);
    }

    fn class_entry(output: &mut Vec<u8>, name: u16) {
        output.push(7);
        u16_be(output, name);
    }

    fn attribute(output: &mut Vec<u8>, name: u16, content: &[u8]) -> (ByteSpan, ByteSpan) {
        attribute_with_length_offset(output, name, content).0
    }

    fn attribute_with_length_offset(
        output: &mut Vec<u8>,
        name: u16,
        content: &[u8],
    ) -> ((ByteSpan, ByteSpan), usize) {
        let start = output.len();
        u16_be(output, name);
        let length_offset = output.len();
        u32_be(output, u32::try_from(content.len()).unwrap());
        let content_start = output.len();
        output.extend_from_slice(content);
        (
            (
                ByteSpan::new(
                    start as u64,
                    (ATTRIBUTE_HEADER_LENGTH + content.len()) as u64,
                ),
                ByteSpan::new(content_start as u64, content.len() as u64),
            ),
            length_offset,
        )
    }

    struct Fixture {
        bytes: Vec<u8>,
        field_attribute: (ByteSpan, ByteSpan),
        method_attribute: (ByteSpan, ByteSpan),
        code_attribute: (ByteSpan, ByteSpan),
        class_attribute: (ByteSpan, ByteSpan),
        attribute_length_offsets: [usize; 5],
    }

    fn fixture() -> Fixture {
        let special_name = b"A\xc0\x80\xed\xa0\xbd\xed\xb8\x80\xed\xa0\x80\\\"\xe2\x80\xae";
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&0xcafebabe_u32.to_be_bytes());
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 52);
        u16_be(&mut bytes, 15);
        utf8(&mut bytes, special_name); // 1
        class_entry(&mut bytes, 1); // 2
        utf8(&mut bytes, b"java/lang/Object"); // 3
        class_entry(&mut bytes, 3); // 4
        utf8(&mut bytes, b"field"); // 5
        utf8(&mut bytes, b"I"); // 6
        utf8(&mut bytes, b"method"); // 7
        utf8(&mut bytes, b"()V"); // 8
        utf8(&mut bytes, b"ClassUnknown"); // 9
        utf8(&mut bytes, b"FieldUnknown"); // 10
        utf8(&mut bytes, b"Code"); // 11
        utf8(&mut bytes, b"pkg/Interface"); // 12
        class_entry(&mut bytes, 12); // 13
        utf8(&mut bytes, b"MethodUnknown"); // 14
        u16_be(&mut bytes, 0x0021);
        u16_be(&mut bytes, 2);
        u16_be(&mut bytes, 4);
        u16_be(&mut bytes, 1);
        u16_be(&mut bytes, 13);
        u16_be(&mut bytes, 1);
        u16_be(&mut bytes, 0x0001);
        u16_be(&mut bytes, 5);
        u16_be(&mut bytes, 6);
        u16_be(&mut bytes, 1);
        let (field_attribute, field_attribute_length_offset) =
            attribute_with_length_offset(&mut bytes, 10, &[0xde, 0xad]);
        u16_be(&mut bytes, 1);
        u16_be(&mut bytes, 0x0009);
        u16_be(&mut bytes, 7);
        u16_be(&mut bytes, 8);
        u16_be(&mut bytes, 2);
        let (method_attribute, method_attribute_length_offset) =
            attribute_with_length_offset(&mut bytes, 14, &[0xff]);
        let mut code_content = Vec::new();
        u16_be(&mut code_content, 1);
        u16_be(&mut code_content, 1);
        u32_be(&mut code_content, 1);
        code_content.push(0xb1);
        u16_be(&mut code_content, 0);
        u16_be(&mut code_content, 1);
        let (_, nested_attribute_length_offset_in_content) =
            attribute_with_length_offset(&mut code_content, 14, &[0xca, 0xfe]);
        let (code_attribute, code_attribute_length_offset) =
            attribute_with_length_offset(&mut bytes, 11, &code_content);
        let nested_attribute_length_offset = usize::try_from(code_attribute.1.start).unwrap()
            + nested_attribute_length_offset_in_content;
        u16_be(&mut bytes, 1);
        let (class_attribute, class_attribute_length_offset) =
            attribute_with_length_offset(&mut bytes, 9, &[1, 2, 3]);
        Fixture {
            bytes,
            field_attribute,
            method_attribute,
            code_attribute,
            class_attribute,
            attribute_length_offsets: [
                class_attribute_length_offset,
                field_attribute_length_offset,
                method_attribute_length_offset,
                code_attribute_length_offset,
                nested_attribute_length_offset,
            ],
        }
    }

    fn bytecode_fixture(
        major: u16,
        minor: u16,
        code: Option<&[u8]>,
        handlers: &[(u16, u16, u16, u16)],
        duplicate_method: bool,
        duplicate_code: bool,
    ) -> Vec<u8> {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&0xcafebabe_u32.to_be_bytes());
        u16_be(&mut bytes, minor);
        u16_be(&mut bytes, major);
        u16_be(&mut bytes, 9);
        utf8(&mut bytes, b"Test"); // 1
        class_entry(&mut bytes, 1); // 2
        utf8(&mut bytes, b"java/lang/Object"); // 3
        class_entry(&mut bytes, 3); // 4
        utf8(&mut bytes, b"method"); // 5
        utf8(&mut bytes, b"()V"); // 6
        utf8(&mut bytes, b"Code"); // 7
        utf8(&mut bytes, b"Noise"); // 8
        u16_be(&mut bytes, 0x0021);
        u16_be(&mut bytes, 2);
        u16_be(&mut bytes, 4);
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, if duplicate_method { 2 } else { 1 });
        for _ in 0..if duplicate_method { 2 } else { 1 } {
            u16_be(&mut bytes, 0x0009);
            u16_be(&mut bytes, 5);
            u16_be(&mut bytes, 6);
            let attributes = if code.is_none() {
                0
            } else if duplicate_code {
                2
            } else {
                1
            };
            u16_be(&mut bytes, attributes);
            for _ in 0..attributes {
                let mut content = Vec::new();
                u16_be(&mut content, 4);
                u16_be(&mut content, 3);
                u32_be(&mut content, code.unwrap().len() as u32);
                content.extend_from_slice(code.unwrap());
                u16_be(&mut content, handlers.len() as u16);
                for &(start, end, handler, catch) in handlers {
                    u16_be(&mut content, start);
                    u16_be(&mut content, end);
                    u16_be(&mut content, handler);
                    u16_be(&mut content, catch);
                }
                u16_be(&mut content, 0);
                attribute(&mut bytes, 7, &content);
            }
        }
        u16_be(&mut bytes, 1);
        attribute(&mut bytes, 8, &[0u8; 64]);
        bytes
    }

    fn selector() -> MethodSelector {
        MethodSelector {
            name: JvmBytes(b"method".to_vec()),
            descriptor: JvmBytes(b"()V".to_vec()),
        }
    }

    fn mutf8(units: &[u16]) -> Vec<u8> {
        let mut output = Vec::new();
        for &unit in units {
            match unit {
                0 => output.extend_from_slice(&[0xc0, 0x80]),
                1..=0x7f => output.push(unit as u8),
                0x80..=0x7ff => {
                    output.push(0xc0 | ((unit >> 6) as u8));
                    output.push(0x80 | ((unit & 0x3f) as u8));
                }
                _ => {
                    output.push(0xe0 | ((unit >> 12) as u8));
                    output.push(0x80 | (((unit >> 6) & 0x3f) as u8));
                    output.push(0x80 | ((unit & 0x3f) as u8));
                }
            }
        }
        output
    }

    fn descriptor_header_fixture(descriptor: &[u8]) -> Vec<u8> {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&0xcafebabe_u32.to_be_bytes());
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 52);
        u16_be(&mut bytes, 7);
        utf8(&mut bytes, b"Test"); // 1
        class_entry(&mut bytes, 1); // 2
        utf8(&mut bytes, b"java/lang/Object"); // 3
        class_entry(&mut bytes, 3); // 4
        utf8(&mut bytes, b"method"); // 5
        utf8(&mut bytes, descriptor); // 6
        u16_be(&mut bytes, 0x0021);
        u16_be(&mut bytes, 2);
        u16_be(&mut bytes, 4);
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 1);
        u16_be(&mut bytes, 0x0001);
        u16_be(&mut bytes, 5);
        u16_be(&mut bytes, 6);
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 0);
        bytes
    }

    fn fixture_version(major: u16, minor: u16) -> Fixture {
        let mut fixture = fixture();
        fixture.bytes[4..6].copy_from_slice(&minor.to_be_bytes());
        fixture.bytes[6..8].copy_from_slice(&major.to_be_bytes());
        fixture
    }

    fn slice<'a>(bytes: &'a [u8], span: &ByteSpan) -> &'a [u8] {
        let start = usize::try_from(span.start).unwrap();
        let end = start + usize::try_from(span.length).unwrap();
        &bytes[start..end]
    }

    fn header_attribute_shells(header: &ClassHeader) -> impl Iterator<Item = &AttributeShell> {
        header
            .attributes
            .iter()
            .chain(header.fields.iter().flat_map(|field| &field.attributes))
            .chain(header.methods.iter().flat_map(|method| &method.attributes))
    }

    fn assert_attribute_shells_within(header: &ClassHeader, input: &[u8]) {
        let input_len = u64::try_from(input.len()).unwrap();
        for shell in header_attribute_shells(header) {
            let span_end = shell.span.start.checked_add(shell.span.length).unwrap();
            let content_end = shell
                .content_span
                .start
                .checked_add(shell.content_span.length)
                .unwrap();
            assert!(span_end <= input_len);
            assert!(content_end <= input_len);
            assert_eq!(shell.content_span.start, shell.span.start + 6);
            assert_eq!(shell.span.length, shell.content_span.length + 6);
            assert_eq!(span_end, content_end);
            let length_offset = usize::try_from(shell.span.start).unwrap() + 2;
            assert_eq!(
                u64::from(read_u32(input, length_offset).unwrap()),
                shell.content_span.length
            );
        }
        let hosts = std::iter::once(&header.attributes)
            .chain(header.fields.iter().map(|field| &field.attributes))
            .chain(header.methods.iter().map(|method| &method.attributes));
        for shells in hosts {
            for pair in shells.windows(2) {
                assert!(pair[0].span.start + pair[0].span.length <= pair[1].span.start);
            }
        }
    }

    fn assert_structured_header_result(result: Result<HeaderInspection>, input: &[u8]) {
        match result {
            Ok(inspection) => assert_attribute_shells_within(&inspection.header, input),
            Err(Error::InvalidInput { .. }) => {}
            Err(other) => panic!("unexpected forensic header result: {other}"),
        }
    }

    /// Asserts a report's usage equals a fresh read of the budget, wall clock aside.
    ///
    /// `UsageSnapshot::elapsed_millis` is recomputed from the clock on every read, so two reads
    /// of an unchanged budget differ whenever a millisecond falls between them — which is what
    /// made a property run fail intermittently. Zeroing that one field is this repository's
    /// convention for comparing a snapshot read twice; every counted dimension still has to
    /// agree, so the assertion keeps its teeth.
    fn assert_usage_matches_budget(usage: &crate::budget::UsageSnapshot, budget: &Budget) {
        let mut reported = usage.clone();
        let mut live = budget.usage();
        reported.elapsed_millis = 0;
        live.elapsed_millis = 0;
        assert_eq!(
            reported, live,
            "the report's usage is a faithful read of the budget"
        );
    }

    fn assert_bytecode_report_invariants(
        report: &BytecodeInspection,
        bytes: &[u8],
        code: &[u8],
        budget: &Budget,
    ) {
        let code_length = u32::try_from(code.len()).unwrap();
        assert!(report.exception_handlers.is_empty());
        assert_eq!(report.exception_handler_count, 0);
        assert_eq!(report.verification, VerificationStatus::NotPerformed);
        assert_eq!(report.code_span.length, u64::from(code_length));

        let mut prefix_end = 0u32;
        for fact in &report.instructions {
            assert_eq!(fact.bci, prefix_end);
            assert!(fact.width > 0);
            assert_eq!(
                fact.span.start,
                report.code_span.start + u64::from(fact.bci)
            );
            assert_eq!(fact.span.length, u64::from(fact.width));
            assert_eq!(fact.operands_span.start, fact.span.start + 1);
            assert_eq!(fact.operands_span.length, u64::from(fact.width - 1));
            prefix_end = prefix_end.checked_add(fact.width).unwrap();
            assert!(prefix_end <= code_length);
            assert_eq!(fact.opcode, code[fact.bci as usize]);
            assert_eq!(
                slice(bytes, &fact.span),
                &code[fact.bci as usize..prefix_end as usize]
            );
        }

        match &report.execution {
            ExecutionReport::Complete { usage } => {
                assert_eq!(prefix_end, code_length);
                assert!(report.stopped_at.is_none());
                assert!(report.diagnostics.is_empty());
                assert_usage_matches_budget(usage, budget);
            }
            ExecutionReport::Partial { reason, usage } => {
                let TerminationReason::Error { code: reason_code } = reason else {
                    panic!("unlimited instruction failure must have an error reason");
                };
                let Some(BytecodeStop::Instructions {
                    bci,
                    class_offset,
                    code: stop_code,
                }) = report.stopped_at.as_ref()
                else {
                    panic!("partial instruction decode must report an instruction stop");
                };
                assert_eq!(*bci, prefix_end);
                assert_eq!(*class_offset, report.code_span.start + u64::from(*bci));
                assert_eq!(report.diagnostics.len(), 1);
                assert_eq!(reason_code, stop_code);
                assert_eq!(reason_code, &report.diagnostics[0].code);
                assert_eq!(report.diagnostics[0].severity, DiagnosticSeverity::Error);
                assert_usage_matches_budget(usage, budget);
            }
            ExecutionReport::Cancelled { .. } | ExecutionReport::Failed { .. } => {
                panic!("unlimited bytecode property must complete or stop on an instruction error")
            }
        }
        let usage = budget.usage();
        assert_eq!(usage.class_bytes, bytes.len() as u64);
        assert_eq!(usage.code_bytes, u64::from(prefix_end));
        assert_eq!(usage.result_items, 1 + report.instructions.len() as u64);
        let shell_start = usize::try_from(report.code_span.start).unwrap() - 14;
        let declared_length = u64::from(read_u32(bytes, shell_start + 2).unwrap());
        assert_eq!(
            usage.attribute_bytes,
            declared_length.checked_add(6).unwrap()
        );
    }

    fn instruction_stop(stop: &BytecodeStop) -> (u32, u64, &str) {
        match stop {
            BytecodeStop::Instructions {
                bci,
                class_offset,
                code,
            } => (*bci, *class_offset, code),
            BytecodeStop::ExceptionHandlers { .. } => panic!("expected instruction stop"),
        }
    }

    fn handler_stop(stop: &BytecodeStop) -> (u32, u64, &str) {
        match stop {
            BytecodeStop::ExceptionHandlers {
                ordinal,
                class_offset,
                code,
            } => (*ordinal, *class_offset, code),
            BytecodeStop::Instructions { .. } => panic!("expected exception-handler stop"),
        }
    }

    #[test]
    fn all_header_prefixes_are_panic_free_and_only_complete_input_succeeds() {
        let fixture = fixture();
        for prefix_len in 0..=fixture.bytes.len() {
            let prefix = &fixture.bytes[..prefix_len];
            let result = inspect_header(
                prefix,
                &mut Budget::new(limits(u64::MAX)),
                InspectionMode::Forensic,
            );
            assert_eq!(
                result.is_ok(),
                prefix_len == fixture.bytes.len(),
                "unexpected result for prefix {prefix_len}/{}",
                fixture.bytes.len()
            );
            assert_structured_header_result(result, prefix);
        }
    }

    #[test]
    fn oversized_attribute_length_is_rejected_at_the_owner_but_nested_code_stays_lazy() {
        let fixture = fixture();
        for (index, length_offset) in fixture.attribute_length_offsets.into_iter().enumerate() {
            let mut bytes = fixture.bytes.clone();
            bytes[length_offset..length_offset + 4].copy_from_slice(&u32::MAX.to_be_bytes());
            let header = inspect_header(
                &bytes,
                &mut Budget::new(limits(u64::MAX)),
                InspectionMode::Forensic,
            );
            if index == 4 {
                assert!(header.is_ok());
                assert!(matches!(
                    inspect_method_bytecode(&bytes, selector(), &mut Budget::new(limits(u64::MAX)),),
                    Err(Error::InvalidInput { .. })
                ));
            } else {
                assert!(matches!(header, Err(Error::InvalidInput { .. })));
            }
        }
    }

    #[test]
    fn oversized_and_truncated_switch_declarations_stop_without_expansion() {
        let mut table_negative = vec![0xaa, 0, 0, 0];
        table_negative.extend_from_slice(&0i32.to_be_bytes());
        table_negative.extend_from_slice(&1i32.to_be_bytes());
        table_negative.extend_from_slice(&0i32.to_be_bytes());

        let mut table_huge = vec![0xaa, 0, 0, 0];
        table_huge.extend_from_slice(&0i32.to_be_bytes());
        table_huge.extend_from_slice(&i32::MIN.to_be_bytes());
        table_huge.extend_from_slice(&i32::MAX.to_be_bytes());

        let mut lookup_negative = vec![0xab, 0, 0, 0];
        lookup_negative.extend_from_slice(&0i32.to_be_bytes());
        lookup_negative.extend_from_slice(&(-1i32).to_be_bytes());

        let mut lookup_huge = vec![0xab, 0, 0, 0];
        lookup_huge.extend_from_slice(&0i32.to_be_bytes());
        lookup_huge.extend_from_slice(&i32::MAX.to_be_bytes());

        let cases = [
            (table_negative, &[0usize, 1, 4, 8, 12][..]),
            (table_huge, &[0usize, 1, 4, 8, 12][..]),
            (lookup_negative, &[0usize, 1, 4, 8][..]),
            (lookup_huge, &[0usize, 1, 4, 8][..]),
        ];
        for (code, cut_points) in cases {
            for &code_len in cut_points.iter().chain(std::iter::once(&code.len())) {
                let bytes = bytecode_fixture(52, 0, Some(&code[..code_len]), &[], false, false);
                let mut budget = Budget::new(limits(u64::MAX));
                match inspect_method_bytecode(&bytes, selector(), &mut budget) {
                    Ok(report) => {
                        assert_bytecode_report_invariants(
                            &report,
                            &bytes,
                            &code[..code_len],
                            &budget,
                        );
                        if code_len == code.len() {
                            assert!(matches!(report.execution, ExecutionReport::Partial { .. }));
                        }
                    }
                    Err(Error::InvalidInput { .. } | Error::Unsupported { .. }) => {}
                    Err(other) => panic!("unexpected unlimited-budget error: {other}"),
                }
            }
        }
    }

    proptest! {
        #![proptest_config(ProptestConfig {
            cases: 256,
            failure_persistence: None,
            ..ProptestConfig::default()
        })]

        #[test]
        fn property_attribute_lengths_and_tail_truncation_are_bounded(
            attribute_index in 0usize..5,
            declared_length in any::<u32>(),
            trim_from_tail in 0usize..=64,
        ) {
            let fixture = fixture();
            let mut bytes = fixture.bytes;
            let length_offset = fixture.attribute_length_offsets[attribute_index];
            bytes[length_offset..length_offset + 4].copy_from_slice(&declared_length.to_be_bytes());
            let retained = bytes.len().saturating_sub(trim_from_tail);
            bytes.truncate(retained);

            let header_result = inspect_header(
                &bytes,
                &mut Budget::new(limits(u64::MAX)),
                InspectionMode::Forensic,
            );
            if attribute_index == 4 && trim_from_tail == 0 {
                assert!(header_result.is_ok(), "Header must lazily ignore nested Code content");
            }
            assert_structured_header_result(header_result, &bytes);

            let mut bytecode_budget = Budget::new(limits(u64::MAX));
            match inspect_method_bytecode(&bytes, selector(), &mut bytecode_budget) {
                Ok(report) => assert_bytecode_report_invariants(
                    &report,
                    &bytes,
                    &[0xb1],
                    &bytecode_budget,
                ),
                Err(Error::InvalidInput { .. }) => {}
                Err(other) => panic!("unexpected unlimited bytecode result: {other}"),
            }
        }
    }

    proptest! {
        #![proptest_config(ProptestConfig {
            cases: 256,
            failure_persistence: None,
            ..ProptestConfig::default()
        })]

        #[test]
        fn property_mutf8_utf16_round_trip_and_escaping_are_stable(
            units in prop::collection::vec(any::<u16>(), 0..=16),
        ) {
            let raw = mutf8(&units);
            let mstr = noak::MStr::from_mutf8(&raw).unwrap();
            let value = jvm_string_mstr(mstr).unwrap();
            prop_assert_eq!(value.raw().0.as_slice(), raw.as_slice());
            prop_assert_eq!(value.utf16(), units.as_slice());
            let repeated = jvm_string_mstr(noak::MStr::from_mutf8(value.raw().0.as_slice()).unwrap()).unwrap();
            prop_assert_eq!(value.escaped(), repeated.escaped());
        }
    }

    proptest! {
        #![proptest_config(ProptestConfig {
            cases: 512,
            failure_persistence: None,
            ..ProptestConfig::default()
        })]

        #[test]
        fn property_instruction_byte_vectors_preserve_reliable_prefix(
            code in prop::collection::vec(any::<u8>(), 0..=64),
        ) {
            let bytes = bytecode_fixture(52, 0, Some(&code), &[], false, false);
            let mut budget = Budget::new(limits(u64::MAX));
            let report = inspect_method_bytecode(&bytes, selector(), &mut budget)
                .expect("any instruction byte vector must produce a method-local report");
            assert_bytecode_report_invariants(&report, &bytes, &code, &budget);
        }
    }

    #[test]
    fn invalid_tableswitch_ranges_are_method_local_partial_reports() {
        let cases = [
            (
                vec![0xaa, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
                0,
                0,
            ),
            (
                vec![0x00, 0xaa, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
                1,
                1,
            ),
        ];
        for (code, expected_bci, expected_facts) in cases {
            let bytes = bytecode_fixture(52, 0, Some(&code), &[], false, false);
            let mut budget = Budget::new(limits(u64::MAX));
            let report = inspect_method_bytecode(&bytes, selector(), &mut budget).unwrap();
            assert_eq!(report.instructions.len(), expected_facts);
            assert_bytecode_report_invariants(&report, &bytes, &code, &budget);
            assert_eq!(
                instruction_stop(report.stopped_at.as_ref().unwrap()),
                (
                    expected_bci,
                    report.code_span.start + u64::from(expected_bci),
                    "classfile_instruction_invalid_range"
                )
            );
        }

        let valid = vec![
            0xaa, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0,
        ];
        let bytes = bytecode_fixture(52, 0, Some(&valid), &[], false, false);
        let report =
            inspect_method_bytecode(&bytes, selector(), &mut Budget::new(limits(u64::MAX)))
                .unwrap();
        assert!(matches!(report.execution, ExecutionReport::Complete { .. }));
        assert_eq!(report.instructions[0].width, 20);
    }

    #[test]
    fn malformed_wide_forms_stop_exactly_at_the_current_bci() {
        let cases: &[&[u8]] = &[
            &[0xc4],
            &[0xc4, 0x00, 0x00, 0x00],
            &[0xc4, 0x15, 0x00],
            &[0xc4, 0x84, 0x00, 0x01, 0x00],
        ];
        for &code in cases {
            let bytes = bytecode_fixture(52, 0, Some(code), &[], false, false);
            let mut budget = Budget::new(limits(u64::MAX));
            let report = inspect_method_bytecode(&bytes, selector(), &mut budget).unwrap();
            assert_bytecode_report_invariants(&report, &bytes, code, &budget);
            assert_eq!(report.instructions.len(), 0);
            assert_eq!(instruction_stop(report.stopped_at.as_ref().unwrap()).0, 0);
        }
    }

    #[test]
    fn synthetic_historical_jsr_jsr_w_and_ret_boundaries_are_preserved() {
        // Synthetic boundary coverage only; this is not a historical compiler corpus.
        let code = [
            0xa8, 0x00, 0x00, // jsr
            0xc9, 0x00, 0x00, 0x00, 0x00, // jsr_w
            0xa9, 0x01, // ret
        ];
        for major in [49, 52] {
            let bytes = bytecode_fixture(major, 0, Some(&code), &[], false, false);
            let report =
                inspect_method_bytecode(&bytes, selector(), &mut Budget::new(limits(u64::MAX)))
                    .unwrap();
            assert_eq!(
                report
                    .instructions
                    .iter()
                    .map(|fact| (fact.bci, fact.opcode, fact.width, fact.constant_pool_index))
                    .collect::<Vec<_>>(),
                vec![(0, 0xa8, 3, None), (3, 0xc9, 5, None), (8, 0xa9, 2, None)]
            );
            for fact in &report.instructions {
                assert_eq!(
                    slice(&bytes, &fact.span),
                    &code[fact.bci as usize..(fact.bci + fact.width) as usize]
                );
            }
        }
    }

    #[test]
    fn descriptor_mutf8_boundaries_survive_the_real_header_path() {
        let units = [
            b'(' as u16,
            0,
            0xd83d,
            0xde00,
            0xd800,
            b')' as u16,
            b'V' as u16,
        ];
        let raw = mutf8(&units);
        let bytes = descriptor_header_fixture(&raw);
        let header = inspect_header(
            &bytes,
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Strict,
        )
        .unwrap()
        .header;
        let descriptor = &header.methods[0].descriptor;
        assert_eq!(descriptor.raw().0, raw);
        assert_eq!(descriptor.utf16(), units);
        assert_eq!(descriptor.escaped(), "(\\u0000\\uD83D\\uDE00\\uD800)V");
    }

    #[test]
    fn inspects_fixed_wide_cp_and_exception_facts() {
        let code = [
            0x12, 0x01, // ldc
            0xb2, 0x00, 0x01, // getstatic
            0xc4, 0x15, 0x00, 0x02, // wide iload
            0xc4, 0x84, 0x00, 0x02, 0x00, 0x01, // wide iinc
            0xb1, // return
        ];
        let bytes = bytecode_fixture(
            52,
            0,
            Some(&code),
            &[(0, 5, 15, 0), (2, 9, 15, 2)],
            false,
            false,
        );
        let mut budget = Budget::new(limits(u64::MAX));
        let report = inspect_method_bytecode(&bytes, selector(), &mut budget).unwrap();
        assert_eq!((report.max_stack, report.max_locals), (4, 3));
        assert_eq!(
            report
                .instructions
                .iter()
                .map(|fact| (fact.bci, fact.opcode, fact.width, fact.constant_pool_index))
                .collect::<Vec<_>>(),
            vec![
                (0, 0x12, 2, Some(1)),
                (2, 0xb2, 3, Some(1)),
                (5, 0xc4, 4, None),
                (9, 0xc4, 6, None),
                (15, 0xb1, 1, None),
            ]
        );
        for fact in &report.instructions {
            assert_eq!(
                slice(&bytes, &fact.span),
                &code[fact.bci as usize..(fact.bci + fact.width) as usize]
            );
            assert_eq!(fact.operands_span.start, fact.span.start + 1);
            assert_eq!(fact.operands_span.length, u64::from(fact.width - 1));
        }
        assert_eq!(
            report.exception_handlers,
            vec![
                ExceptionHandlerFact {
                    ordinal: 0,
                    start_bci: 0,
                    end_bci: 5,
                    handler_bci: 15,
                    catch_type_index: None
                },
                ExceptionHandlerFact {
                    ordinal: 1,
                    start_bci: 2,
                    end_bci: 9,
                    handler_bci: 15,
                    catch_type_index: Some(2)
                },
            ]
        );
        assert!(matches!(report.execution, ExecutionReport::Complete { .. }));
        assert_eq!(report.verification, VerificationStatus::NotPerformed);
        assert_eq!(
            serde_json::from_str::<BytecodeInspection>(&serde_json::to_string(&report).unwrap())
                .unwrap(),
            report
        );
    }

    #[test]
    fn switch_widths_use_code_start_alignment_and_do_not_iterate_table_pairs() {
        let mut table = vec![0x00, 0xaa, 0, 0];
        table.extend_from_slice(&0i32.to_be_bytes());
        table.extend_from_slice(&i32::MAX.to_be_bytes());
        table.extend_from_slice(&i32::MAX.to_be_bytes());
        table.extend_from_slice(&0i32.to_be_bytes());
        table.push(0xb1);
        let bytes = bytecode_fixture(52, 0, Some(&table), &[], false, false);
        let report =
            inspect_method_bytecode(&bytes, selector(), &mut Budget::new(limits(u64::MAX)))
                .unwrap();
        assert_eq!(
            report
                .instructions
                .iter()
                .map(|fact| (fact.bci, fact.width))
                .collect::<Vec<_>>(),
            vec![(0, 1), (1, 19), (20, 1)]
        );

        let mut lookup = vec![0x00, 0xab, 0, 0];
        lookup.extend_from_slice(&0i32.to_be_bytes());
        lookup.extend_from_slice(&1i32.to_be_bytes());
        lookup.extend_from_slice(&7i32.to_be_bytes());
        lookup.extend_from_slice(&0i32.to_be_bytes());
        lookup.push(0xb1);
        let bytes = bytecode_fixture(52, 0, Some(&lookup), &[], false, false);
        let report =
            inspect_method_bytecode(&bytes, selector(), &mut Budget::new(limits(u64::MAX)))
                .unwrap();
        assert_eq!(
            report
                .instructions
                .iter()
                .map(|fact| (fact.bci, fact.width))
                .collect::<Vec<_>>(),
            vec![(0, 1), (1, 19), (20, 1)]
        );
    }

    #[test]
    fn instruction_failures_return_reliable_prefix_and_stop_location() {
        for code in [&[0x00, 0xcb, 0xb1][..], &[0x00, 0xb2, 0x00][..]] {
            let bytes = bytecode_fixture(52, 0, Some(code), &[], false, false);
            let report =
                inspect_method_bytecode(&bytes, selector(), &mut Budget::new(limits(u64::MAX)))
                    .unwrap();
            assert_eq!(report.instructions.len(), 1);
            assert_eq!(report.instructions[0].bci, 0);
            let stop = report.stopped_at.as_ref().unwrap();
            assert_eq!(
                instruction_stop(stop),
                (
                    1,
                    report.code_span.start.checked_add(1).unwrap(),
                    "classfile_instruction_decode"
                )
            );
            let json = serde_json::to_value(stop).unwrap();
            assert_eq!(json["phase"], "instructions");
            assert_eq!(json["bci"], 1);
            assert!(json.get("ordinal").is_none());
            assert!(matches!(report.execution, ExecutionReport::Partial { .. }));
        }
    }

    #[test]
    fn method_lookup_code_cardinality_and_version_gate_are_stable() {
        let bytes = bytecode_fixture(52, 0, Some(&[0xb1]), &[], false, false);
        let missing = MethodSelector {
            name: JvmBytes(b"missing".to_vec()),
            descriptor: JvmBytes(b"()V".to_vec()),
        };
        assert!(
            matches!(inspect_method_bytecode(&bytes, missing, &mut Budget::new(limits(u64::MAX))), Err(Error::InvalidInput { ref code, .. }) if code == "classfile_method_not_found")
        );
        let duplicate = bytecode_fixture(52, 0, Some(&[0xb1]), &[], true, false);
        assert!(
            matches!(inspect_method_bytecode(&duplicate, selector(), &mut Budget::new(limits(u64::MAX))), Err(Error::InvalidInput { ref code, .. }) if code == "classfile_method_ambiguous")
        );
        let no_code = bytecode_fixture(52, 0, None, &[], false, false);
        assert!(
            matches!(inspect_method_bytecode(&no_code, selector(), &mut Budget::new(limits(u64::MAX))), Err(Error::Unsupported { ref code, .. }) if code == "classfile_method_has_no_code")
        );
        let duplicate_code = bytecode_fixture(52, 0, Some(&[0xb1]), &[], false, true);
        assert!(
            matches!(inspect_method_bytecode(&duplicate_code, selector(), &mut Budget::new(limits(u64::MAX))), Err(Error::InvalidInput { ref code, .. }) if code == "classfile_duplicate_code_attribute")
        );

        for (major, minor, expected) in [
            (52, 1, "classfile_java8_runtime_rejected"),
            (53, 0, "classfile_version_structural_probe_only"),
            (56, u16::MAX, "classfile_preview_unsupported"),
            (72, 0, "classfile_future_release"),
        ] {
            let bytes = bytecode_fixture(major, minor, Some(&[0xb1]), &[], false, false);
            assert!(
                matches!(inspect_method_bytecode(&bytes, selector(), &mut Budget::new(limits(u64::MAX))), Err(Error::Unsupported { code, .. }) if code == expected)
            );
        }
    }

    #[test]
    fn bytecode_request_charges_only_local_code_shell_and_returned_facts() {
        let bytes = bytecode_fixture(52, 0, Some(&[0xb1]), &[], false, false);
        let mut configured = limits(u64::MAX);
        configured.attribute_bytes = 19;
        configured.result_items = 2;
        let mut budget = Budget::new(configured);
        let report = inspect_method_bytecode(&bytes, selector(), &mut budget).unwrap();
        assert!(matches!(report.execution, ExecutionReport::Complete { .. }));
        assert_eq!(budget.usage().class_bytes, bytes.len() as u64);
        assert_eq!(budget.usage().attribute_bytes, 19);
        assert_eq!(budget.usage().result_items, 2); // report root + one instruction
        assert_eq!(budget.usage().code_bytes, 1);
    }

    #[test]
    fn instruction_failure_preserves_precollected_handlers() {
        let bytes = bytecode_fixture(
            52,
            0,
            Some(&[0x00, 0xcb]),
            &[(0, 1, 1, 0), (0, 2, 1, 2)],
            false,
            false,
        );
        let report =
            inspect_method_bytecode(&bytes, selector(), &mut Budget::new(limits(u64::MAX)))
                .unwrap();
        assert_eq!(report.exception_handlers.len(), 2);
        assert_eq!(report.exception_handlers[0].ordinal, 0);
        assert_eq!(report.exception_handlers[1].ordinal, 1);
        assert_eq!(report.instructions.len(), 1);
        assert_eq!(instruction_stop(report.stopped_at.as_ref().unwrap()).0, 1);
    }

    #[test]
    fn handler_stage_budget_and_cancellation_preserve_handler_prefix() {
        let bytes = bytecode_fixture(
            52,
            0,
            Some(&[0xb1]),
            &[(0, 1, 0, 0), (0, 1, 0, 2)],
            false,
            false,
        );
        let mut configured = limits(u64::MAX);
        configured.result_items = 2; // root + first handler
        let report =
            inspect_method_bytecode(&bytes, selector(), &mut Budget::new(configured)).unwrap();
        assert_eq!(report.exception_handlers.len(), 1);
        assert!(report.instructions.is_empty());
        let expected_offset = report
            .code_span
            .start
            .checked_add(report.code_span.length)
            .and_then(|offset| offset.checked_add(2))
            .and_then(|offset| offset.checked_add(8))
            .unwrap();
        assert_eq!(
            handler_stop(report.stopped_at.as_ref().unwrap()),
            (1, expected_offset, "classfile_bytecode_budget_exceeded")
        );
        let json = serde_json::to_value(report.stopped_at.as_ref().unwrap()).unwrap();
        assert_eq!(json["phase"], "exception_handlers");
        assert_eq!(json["ordinal"], 1);
        assert!(json.get("bci").is_none());
        assert!(matches!(
            report.execution,
            ExecutionReport::Partial {
                reason: TerminationReason::BudgetExceeded {
                    dimension: BudgetDimension::ResultItems
                },
                ..
            }
        ));
        assert_eq!(report.diagnostics.len(), 1); // termination metadata is deliberately uncharged

        let token = CancellationToken::new();
        let mut budget = Budget::with_cancellation_token(limits(u64::MAX), token.clone());
        let report = inspect_method_bytecode_with(
            &bytes,
            selector(),
            &mut budget,
            |ordinal| {
                if ordinal == 1 {
                    token.cancel();
                }
            },
            |_| {},
        )
        .unwrap();
        assert_eq!(report.exception_handlers.len(), 1);
        assert!(report.instructions.is_empty());
        assert_eq!(
            handler_stop(report.stopped_at.as_ref().unwrap()),
            (1, expected_offset, "classfile_bytecode_cancelled")
        );
        assert!(matches!(
            report.execution,
            ExecutionReport::Cancelled { .. }
        ));
    }

    #[test]
    fn bytecode_cancellation_returns_deterministic_prefix() {
        let bytes = bytecode_fixture(52, 0, Some(&[0x00, 0x00, 0xb1]), &[], false, false);
        let token = CancellationToken::new();
        let mut budget = Budget::with_cancellation_token(limits(u64::MAX), token.clone());
        let report = inspect_method_bytecode_with(
            &bytes,
            selector(),
            &mut budget,
            |_| {},
            |bci| {
                if bci == 1 {
                    token.cancel();
                }
            },
        )
        .unwrap();
        assert_eq!(report.instructions.len(), 1);
        assert_eq!(instruction_stop(report.stopped_at.as_ref().unwrap()).0, 1);
        assert!(matches!(
            report.execution,
            ExecutionReport::Cancelled { .. }
        ));
    }

    #[test]
    fn bytecode_budgets_return_prefix_reports() {
        let bytes = bytecode_fixture(52, 0, Some(&[0x00, 0x00, 0xb1]), &[], false, false);
        let mut configured = limits(u64::MAX);
        configured.code_bytes = 1;
        let report =
            inspect_method_bytecode(&bytes, selector(), &mut Budget::new(configured)).unwrap();
        assert_eq!(report.instructions.len(), 1);
        assert_eq!(instruction_stop(report.stopped_at.as_ref().unwrap()).0, 1);
        assert!(matches!(
            report.execution,
            ExecutionReport::Partial {
                reason: TerminationReason::BudgetExceeded {
                    dimension: BudgetDimension::CodeBytes
                },
                ..
            }
        ));
    }

    #[test]
    fn width_adapter_covers_operand_bearing_opcode_categories() {
        let cases: &[(&[u8], u32)] = &[
            (&[0x10, 0], 2),
            (&[0x11, 0, 0], 3),
            (&[0x12, 1], 2),
            (&[0x13, 0, 1], 3),
            (&[0x84, 0, 0], 3),
            (&[0xa7, 0, 0], 3),
            (&[0xb9, 0, 1, 1, 0], 5),
            (&[0xba, 0, 1, 0, 0], 5),
            (&[0xc5, 0, 1, 1], 4),
            (&[0xc8, 0, 0, 0, 0], 5),
            (&[0xc4, 0x15, 0, 1], 4),
            (&[0xc4, 0x84, 0, 1, 0, 1], 6),
        ];
        for &(code, expected) in cases {
            let bytes = bytecode_fixture(52, 0, Some(code), &[], false, false);
            let report =
                inspect_method_bytecode(&bytes, selector(), &mut Budget::new(limits(u64::MAX)))
                    .unwrap();
            assert_eq!(
                report.instructions[0].width, expected,
                "opcode {:02x}",
                code[0]
            );
        }
    }

    #[test]
    fn version_matrix_keeps_rules_dialect_and_java8_profile_orthogonal() {
        let cases = [
            (
                45,
                3,
                VersionRuleStatus::Valid,
                VersionDialectSupport::Supported,
                Java8RuntimeCompatibility::Accepted,
                true,
            ),
            (
                45,
                u16::MAX,
                VersionRuleStatus::Valid,
                VersionDialectSupport::Supported,
                Java8RuntimeCompatibility::Accepted,
                true,
            ),
            (
                46,
                0,
                VersionRuleStatus::Valid,
                VersionDialectSupport::Supported,
                Java8RuntimeCompatibility::Accepted,
                true,
            ),
            (
                47,
                0,
                VersionRuleStatus::Valid,
                VersionDialectSupport::Supported,
                Java8RuntimeCompatibility::Accepted,
                true,
            ),
            (
                48,
                0,
                VersionRuleStatus::Valid,
                VersionDialectSupport::Supported,
                Java8RuntimeCompatibility::Accepted,
                true,
            ),
            (
                49,
                0,
                VersionRuleStatus::Valid,
                VersionDialectSupport::Supported,
                Java8RuntimeCompatibility::Accepted,
                true,
            ),
            (
                50,
                0,
                VersionRuleStatus::Valid,
                VersionDialectSupport::Supported,
                Java8RuntimeCompatibility::Accepted,
                true,
            ),
            (
                51,
                1,
                VersionRuleStatus::Valid,
                VersionDialectSupport::Supported,
                Java8RuntimeCompatibility::Accepted,
                true,
            ),
            (
                52,
                0,
                VersionRuleStatus::Valid,
                VersionDialectSupport::Supported,
                Java8RuntimeCompatibility::Accepted,
                true,
            ),
            (
                52,
                1,
                VersionRuleStatus::Valid,
                VersionDialectSupport::Supported,
                Java8RuntimeCompatibility::Rejected,
                false,
            ),
            (
                53,
                7,
                VersionRuleStatus::Valid,
                VersionDialectSupport::StructuralProbeOnly,
                Java8RuntimeCompatibility::Rejected,
                false,
            ),
            (
                55,
                1,
                VersionRuleStatus::Valid,
                VersionDialectSupport::StructuralProbeOnly,
                Java8RuntimeCompatibility::Rejected,
                false,
            ),
            (
                56,
                1,
                VersionRuleStatus::InvalidModernMinor,
                VersionDialectSupport::StructuralProbeOnly,
                Java8RuntimeCompatibility::Rejected,
                false,
            ),
            (
                56,
                u16::MAX,
                VersionRuleStatus::Valid,
                VersionDialectSupport::UnsupportedPreview,
                Java8RuntimeCompatibility::Rejected,
                false,
            ),
            (
                71,
                0,
                VersionRuleStatus::Valid,
                VersionDialectSupport::StructuralProbeOnly,
                Java8RuntimeCompatibility::Rejected,
                false,
            ),
            (
                72,
                0,
                VersionRuleStatus::Valid,
                VersionDialectSupport::FutureRelease,
                Java8RuntimeCompatibility::Rejected,
                false,
            ),
            (
                72,
                u16::MAX,
                VersionRuleStatus::Valid,
                VersionDialectSupport::FutureRelease,
                Java8RuntimeCompatibility::Rejected,
                false,
            ),
            (
                44,
                0,
                VersionRuleStatus::InvalidMajor,
                VersionDialectSupport::StructuralProbeOnly,
                Java8RuntimeCompatibility::Rejected,
                false,
            ),
        ];

        for (major, minor, rule, dialect, java8, strict_ok) in cases {
            let fixture = fixture_version(major, minor);
            let forensic = inspect_header(
                &fixture.bytes,
                &mut Budget::new(limits(u64::MAX)),
                InspectionMode::Forensic,
            )
            .unwrap();
            assert_eq!(forensic.structural_read, HeaderStructuralRead::Complete);
            assert_eq!(forensic.verification, VerificationStatus::NotPerformed);
            assert_eq!(
                forensic.version_capability.version,
                ClassfileVersion { major, minor }
            );
            assert_eq!(forensic.version_capability.version_rule, rule);
            assert_eq!(forensic.version_capability.version_dialect_support, dialect);
            assert_eq!(
                forensic.version_capability.dialect_validation_scope,
                DialectValidationScope::VersionOnly
            );
            assert_eq!(forensic.version_capability.java8_runtime, java8);
            assert_eq!(
                inspect_header(
                    &fixture.bytes,
                    &mut Budget::new(limits(u64::MAX)),
                    InspectionMode::Strict,
                )
                .is_ok(),
                strict_ok,
                "strict result for {major}.{minor}"
            );
        }
    }

    /// The preview and unregistered-release scenario, on the report the reader publishes.
    ///
    /// The three planes must stay separate in the answer: the structure was read, no verification
    /// ran, no output level was evaluated, and the dialect plane states non-support. A readable
    /// structure is never evidence of dialect or verifier success, and an unregistered release
    /// carries no registered capability with it.
    #[test]
    fn preview_and_unregistered_releases_stay_readable_and_are_never_reported_as_supported() {
        let registry = feature_registry();
        let cases = [
            (
                56,
                u16::MAX,
                VersionDialectSupport::UnsupportedPreview,
                ReleaseRegistration::Registered,
                PreviewMarker::Present,
                "classfile_preview_unsupported",
            ),
            (
                71,
                u16::MAX,
                VersionDialectSupport::UnsupportedPreview,
                ReleaseRegistration::Registered,
                PreviewMarker::Present,
                "classfile_preview_unsupported",
            ),
            (
                62,
                0,
                VersionDialectSupport::StructuralProbeOnly,
                ReleaseRegistration::Registered,
                PreviewMarker::Absent,
                "classfile_version_structural_probe_only",
            ),
            (
                72,
                0,
                VersionDialectSupport::FutureRelease,
                ReleaseRegistration::UnregisteredFutureRelease,
                PreviewMarker::Absent,
                "classfile_future_release",
            ),
            (
                72,
                u16::MAX,
                VersionDialectSupport::FutureRelease,
                ReleaseRegistration::UnregisteredFutureRelease,
                PreviewMarker::Present,
                "classfile_future_release",
            ),
            (
                99,
                3,
                VersionDialectSupport::FutureRelease,
                ReleaseRegistration::UnregisteredFutureRelease,
                PreviewMarker::Absent,
                "classfile_future_release",
            ),
        ];
        for (major, minor, dialect, registration, preview_marker, code) in cases {
            let fixture = fixture_version(major, minor);
            let forensic = inspect_header(
                &fixture.bytes,
                &mut Budget::new(limits(u64::MAX)),
                InspectionMode::Forensic,
            )
            .unwrap();
            // Parse: the structure was read, and this success belongs to that plane alone.
            assert_eq!(forensic.structural_read, HeaderStructuralRead::Complete);
            // Verification: this layer ran none, whatever the format claims.
            assert_eq!(forensic.verification, VerificationStatus::NotPerformed);
            // Output level: this layer evaluated none either.
            assert_eq!(forensic.output_level, OutputLevelStatus::NotEvaluated);
            // Dialect: explicit non-support, never a supported band.
            assert_eq!(forensic.version_capability.version_dialect_support, dialect);
            assert_eq!(forensic.version_capability.preview_marker, preview_marker);
            assert_eq!(
                forensic.version_capability.release_registration, registration,
                "{major}.{minor}"
            );
            assert!(
                forensic
                    .diagnostics
                    .iter()
                    .any(|diagnostic| diagnostic.code == code),
                "diagnostic {code} for {major}.{minor}"
            );
            if registration == ReleaseRegistration::UnregisteredFutureRelease {
                // The conservative path: no record, so no constraint of a registered release.
                assert!(registry.release_record(major).is_none());
                assert_eq!(registry.attributes(major).count(), 0);
                assert_eq!(registry.flags(major).count(), 0);
            }
            assert!(
                inspect_header(
                    &fixture.bytes,
                    &mut Budget::new(limits(u64::MAX)),
                    InspectionMode::Strict,
                )
                .is_err(),
                "strict refusal for {major}.{minor}"
            );
        }
    }

    /// The report's version facts are the registry record's, so the two cannot drift apart.
    #[test]
    fn header_capability_follows_the_release_registry() {
        let registry = feature_registry();
        for major in [45, 50, 52, 53, 55, 56, 60, 61, 71] {
            let record = registry.release_record(major).expect("registered release");
            let capability = version_capability(major, 0);
            assert_eq!(
                capability.release_registration,
                ReleaseRegistration::Registered,
                "{major}"
            );
            assert_eq!(capability.preview_marker, PreviewMarker::Absent, "{major}");
            assert_eq!(
                capability.version_dialect_support,
                record.dialect_support(),
                "{major}"
            );
            assert_eq!(capability.java8_runtime, record.java8_runtime(0), "{major}");
            let fixture = fixture_version(major, 0);
            let inspection = inspect_header(
                &fixture.bytes,
                &mut Budget::new(limits(u64::MAX)),
                InspectionMode::Forensic,
            )
            .unwrap();
            assert_eq!(inspection.version_capability, capability, "{major}");
        }

        assert_eq!(registry.dialect_validated_ceiling(), 52);
        // The minor rule of the format reaches above the ceiling, and below the format's minimum the
        // band stays the conservative structural probe it was.
        let unregistered_future = version_capability(72, 1);
        assert_eq!(
            unregistered_future.version_rule,
            VersionRuleStatus::InvalidModernMinor
        );
        assert_eq!(
            unregistered_future.release_registration,
            ReleaseRegistration::UnregisteredFutureRelease
        );
        let below_minimum = version_capability(44, 0);
        assert_eq!(below_minimum.version_rule, VersionRuleStatus::InvalidMajor);
        assert_eq!(
            below_minimum.release_registration,
            ReleaseRegistration::UnregisteredBelowMinimum
        );
        assert_eq!(
            below_minimum.version_dialect_support,
            VersionDialectSupport::StructuralProbeOnly
        );
        assert_eq!(below_minimum.preview_marker, PreviewMarker::Absent);
    }

    /// The boundary this slice draws: 1.1 states the release rules and answers them on demand; the
    /// passes that read an artifact's attributes and flags report them (1.2/1.3).
    #[test]
    fn header_inspection_leaves_attribute_and_flag_legality_to_the_fact_passes() {
        let fixture = fixture_version(55, 0);
        let inspection = inspect_header(
            &fixture.bytes,
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Forensic,
        )
        .unwrap();
        for diagnostic in &inspection.diagnostics {
            assert!(
                matches!(
                    diagnostic.code.as_str(),
                    "classfile_version_structural_probe_only"
                        | "classfile_preview_unsupported"
                        | "classfile_future_release"
                        | "classfile_invalid_major_version"
                        | "classfile_invalid_modern_minor_version"
                        | "classfile_java8_runtime_rejected"
                ),
                "the header plan states version facts only, not {}",
                diagnostic.code
            );
        }

        let registry = feature_registry();
        let version = registry
            .attribute_diagnostic("Record", ClassfileLocation::ClassFile, 55)
            .expect("the registry states the rule");
        assert_eq!(version.code, "classfile_attribute_version_not_applicable");
        assert_eq!(
            version.message,
            "attribute \"Record\" is registered from major 60 (JVMS 4.7.30); it is not valid at major 55"
        );
        assert!(version.provenance.is_none());
        assert_eq!(
            registry.attribute_diagnostic("Record", ClassfileLocation::ClassFile, 60),
            None
        );
        let location = registry
            .attribute_diagnostic("NestMembers", ClassfileLocation::MethodInfo, 55)
            .expect("the registry states the rule");
        assert_eq!(location.code, "classfile_attribute_location_not_applicable");
        assert_eq!(
            location.message,
            "attribute \"NestMembers\" is registered only for ClassFile (JVMS 4.7.29); it is not valid in a method_info structure"
        );
    }

    #[test]
    fn strict_errors_and_forensic_diagnostics_have_stable_version_codes() {
        let cases = [
            (44, 0, "classfile_invalid_major_version", true),
            (56, 1, "classfile_invalid_modern_minor_version", true),
            (52, 1, "classfile_java8_runtime_rejected", false),
            (56, u16::MAX, "classfile_preview_unsupported", false),
            (71, 0, "classfile_version_structural_probe_only", false),
            (72, 0, "classfile_future_release", false),
            (72, u16::MAX, "classfile_future_release", false),
        ];
        for (major, minor, code, invalid_input) in cases {
            let fixture = fixture_version(major, minor);
            let forensic = inspect_header(
                &fixture.bytes,
                &mut Budget::new(limits(u64::MAX)),
                InspectionMode::Forensic,
            )
            .unwrap();
            assert!(
                forensic.diagnostics.iter().any(|diagnostic| {
                    diagnostic.code == code && diagnostic.provenance.is_none()
                })
            );
            let error = inspect_header(
                &fixture.bytes,
                &mut Budget::new(limits(u64::MAX)),
                InspectionMode::Strict,
            )
            .unwrap_err();
            assert!(match error {
                Error::InvalidInput { code: actual, .. } if invalid_input => actual == code,
                Error::Unsupported { code: actual, .. } if !invalid_input => actual == code,
                _ => false,
            });
        }
    }

    #[test]
    fn future_major_takes_priority_over_preview_marker() {
        let fixture = fixture_version(72, u16::MAX);
        let forensic = inspect_header(
            &fixture.bytes,
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Forensic,
        )
        .unwrap();
        assert_eq!(
            forensic.version_capability.version_dialect_support,
            VersionDialectSupport::FutureRelease
        );
        assert!(
            forensic
                .diagnostics
                .iter()
                .any(|diagnostic| diagnostic.code == "classfile_future_release")
        );
        assert!(
            !forensic
                .diagnostics
                .iter()
                .any(|diagnostic| diagnostic.code == "classfile_preview_unsupported")
        );

        let error = inspect_header(
            &fixture.bytes,
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Strict,
        )
        .unwrap_err();
        assert!(matches!(
            error,
            Error::Unsupported { ref code, .. } if code == "classfile_future_release"
        ));
    }

    #[test]
    fn forensic_diagnostics_are_atomically_charged_as_result_items() {
        let fixture = fixture_version(55, 1);

        let mut exact_structure = limits(u64::MAX);
        exact_structure.result_items = 8;
        let mut budget = Budget::new(exact_structure);
        let error =
            inspect_header(&fixture.bytes, &mut budget, InspectionMode::Forensic).unwrap_err();
        assert_eq!(budget.usage().result_items, 8);
        assert!(matches!(
            error,
            Error::BudgetExceeded {
                dimension: BudgetDimension::ResultItems,
                consumed: 8,
                requested: 2,
                ..
            }
        ));

        let mut with_diagnostics = limits(u64::MAX);
        with_diagnostics.result_items = 10;
        let mut budget = Budget::new(with_diagnostics);
        let inspection =
            inspect_header(&fixture.bytes, &mut budget, InspectionMode::Forensic).unwrap();
        assert_eq!(inspection.diagnostics.len(), 2);
        assert_eq!(budget.usage().result_items, 10);

        let mut strict_limit = limits(u64::MAX);
        strict_limit.result_items = 8;
        let mut budget = Budget::new(strict_limit);
        let error =
            inspect_header(&fixture.bytes, &mut budget, InspectionMode::Strict).unwrap_err();
        assert!(matches!(
            error,
            Error::Unsupported { ref code, .. }
                if code == "classfile_version_structural_probe_only"
        ));
        assert_eq!(budget.usage().result_items, 8);
    }

    #[test]
    fn version_capability_and_header_inspection_round_trip_as_json() {
        let fixture = fixture_version(55, 1);
        let inspection = inspect_header(
            &fixture.bytes,
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Forensic,
        )
        .unwrap();
        let capability_json = serde_json::to_string(&inspection.version_capability).unwrap();
        assert!(capability_json.contains("\"version_dialect_support\":\"structural_probe_only\""));
        assert_eq!(
            serde_json::from_str::<VersionCapability>(&capability_json).unwrap(),
            inspection.version_capability
        );
        let json = serde_json::to_string(&inspection).unwrap();
        assert!(json.contains("\"verification\":\"not_performed\""));
        assert_eq!(
            serde_json::from_str::<HeaderInspection>(&json).unwrap(),
            inspection
        );
    }

    #[test]
    fn inspects_owned_lossless_header_and_exact_attribute_shells() {
        let fixture = fixture();
        let mut budget = Budget::new(limits(u64::MAX));
        let inspection =
            inspect_header(&fixture.bytes, &mut budget, InspectionMode::Strict).unwrap();
        assert_eq!(inspection.structural_read, HeaderStructuralRead::Complete);
        assert_eq!(inspection.verification, VerificationStatus::NotPerformed);
        let header = inspection.header;
        assert_eq!((header.major_version, header.minor_version), (52, 0));
        assert_eq!(header.access_flags, 0x0021);
        assert_eq!(
            header.this_class.raw().0,
            b"A\xc0\x80\xed\xa0\xbd\xed\xb8\x80\xed\xa0\x80\\\"\xe2\x80\xae"
        );
        assert_eq!(
            header.this_class.utf16(),
            &[0x41, 0, 0xd83d, 0xde00, 0xd800, 0x5c, 0x22, 0x202e]
        );
        assert_eq!(
            header.this_class.escaped(),
            "A\\u0000\\uD83D\\uDE00\\uD800\\\\\\\"\\u202E"
        );
        assert_eq!(
            header.super_class.as_ref().unwrap().escaped(),
            "java/lang/Object"
        );
        assert_eq!(header.interfaces[0].escaped(), "pkg/Interface");
        assert_eq!(header.fields[0].name.escaped(), "field");
        assert_eq!(header.fields[0].descriptor.escaped(), "I");
        assert_eq!(header.methods[0].name.escaped(), "method");
        assert_eq!(header.methods[0].descriptor.escaped(), "()V");

        assert_eq!(header_attribute_shells(&header).count(), 4);
        let nested_shell_start = fixture.attribute_length_offsets[4] - 2;
        assert!(
            header_attribute_shells(&header)
                .all(|shell| shell.span.start != nested_shell_start as u64)
        );
        let shells = [
            (&header.fields[0].attributes[0], &fixture.field_attribute),
            (&header.methods[0].attributes[0], &fixture.method_attribute),
            (&header.methods[0].attributes[1], &fixture.code_attribute),
            (&header.attributes[0], &fixture.class_attribute),
        ];
        for (actual, expected) in shells {
            assert_eq!(
                (&actual.span, &actual.content_span),
                (&expected.0, &expected.1)
            );
            assert_eq!(
                slice(&fixture.bytes, &actual.span),
                slice(&fixture.bytes, &expected.0)
            );
            assert_eq!(
                slice(&fixture.bytes, &actual.content_span),
                slice(&fixture.bytes, &expected.1)
            );
        }
        assert_eq!(
            slice(
                &fixture.bytes,
                &header.methods[0].attributes[0].content_span
            ),
            &[0xff]
        );
        assert_eq!(
            slice(
                &fixture.bytes,
                &header.methods[0].attributes[1].content_span
            ),
            &[
                0, 1, 0, 1, 0, 0, 0, 1, 0xb1, 0, 0, 0, 1, 0, 14, 0, 0, 0, 2, 0xca, 0xfe,
            ]
        );
        assert_eq!(budget.usage().class_bytes, fixture.bytes.len() as u64);
        assert_eq!(budget.usage().attribute_bytes, 51);
        assert_eq!(budget.usage().result_items, 8);
    }

    #[test]
    fn jvm_string_json_rejects_inconsistent_derived_state() {
        let fixture = fixture();
        let header = inspect_header(
            &fixture.bytes,
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Strict,
        )
        .unwrap()
        .header;
        let mut value = serde_json::to_value(&header.this_class).unwrap();
        assert_eq!(value["escaped"], header.this_class.escaped());
        value["utf16"] = serde_json::json!([65]);
        assert!(serde_json::from_value::<JvmString>(value).is_err());
    }

    #[test]
    fn rejects_trailing_bytes_and_decode_failures_with_stable_codes() {
        let mut trailing = fixture().bytes;
        trailing.push(0);
        let error = inspect_header(
            &trailing,
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Strict,
        )
        .unwrap_err();
        assert!(
            matches!(error, Error::InvalidInput { ref code, .. } if code == "classfile_trailing_bytes")
        );

        let mut invalid_mutf8 = fixture().bytes;
        let nul = invalid_mutf8.iter().position(|byte| *byte == 0xc0).unwrap();
        invalid_mutf8[nul + 1] = 0x41;
        let error = inspect_header(
            &invalid_mutf8,
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Strict,
        )
        .unwrap_err();
        assert!(
            matches!(error, Error::InvalidInput { ref code, ref message } if code == "classfile_decode" && message.contains("kind=invalid modified utf8") && message.contains("context=") && message.contains("position="))
        );

        let mut bad_index = fixture().bytes;
        let class_info = bad_index
            .windows(10)
            .position(|window| window == [0, 0x21, 0, 2, 0, 4, 0, 1, 0, 13])
            .unwrap();
        bad_index[class_info + 2..class_info + 4].copy_from_slice(&1u16.to_be_bytes());
        let error = inspect_header(
            &bad_index,
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Strict,
        )
        .unwrap_err();
        assert!(
            matches!(error, Error::InvalidInput { ref code, .. } if code == "classfile_decode")
        );

        let mut bad_tag = fixture().bytes;
        bad_tag[10] = 2;
        let error = inspect_header(
            &bad_tag,
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Strict,
        )
        .unwrap_err();
        assert!(
            matches!(error, Error::InvalidInput { ref code, .. } if code == "classfile_decode")
        );

        let truncated = &fixture().bytes[..12];
        let error = inspect_header(
            truncated,
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Strict,
        )
        .unwrap_err();
        assert!(
            matches!(error, Error::InvalidInput { ref code, .. } if code == "classfile_decode")
        );
    }

    #[test]
    fn enforces_class_attribute_result_and_cancellation_budgets() {
        let fixture = fixture();
        let mut class_limits = limits(u64::MAX);
        class_limits.class_bytes = fixture.bytes.len() as u64 - 1;
        assert!(matches!(
            inspect_header(
                &fixture.bytes,
                &mut Budget::new(class_limits),
                InspectionMode::Strict
            ),
            Err(Error::BudgetExceeded {
                dimension: BudgetDimension::ClassBytes,
                ..
            })
        ));

        let mut attribute_limits = limits(u64::MAX);
        attribute_limits.attribute_bytes = 7;
        assert!(matches!(
            inspect_header(
                &fixture.bytes,
                &mut Budget::new(attribute_limits),
                InspectionMode::Strict
            ),
            Err(Error::BudgetExceeded {
                dimension: BudgetDimension::AttributeBytes,
                ..
            })
        ));

        let mut result_limits = limits(u64::MAX);
        result_limits.result_items = 1;
        assert!(matches!(
            inspect_header(
                &fixture.bytes,
                &mut Budget::new(result_limits),
                InspectionMode::Strict
            ),
            Err(Error::BudgetExceeded {
                dimension: BudgetDimension::ResultItems,
                ..
            })
        ));

        let token = CancellationToken::new();
        token.cancel();
        let mut cancelled = Budget::with_cancellation_token(limits(u64::MAX), token);
        assert!(matches!(
            inspect_header(&fixture.bytes, &mut cancelled, InspectionMode::Strict),
            Err(Error::Cancelled { .. })
        ));
        assert_eq!(cancelled.usage().class_bytes, 0);
    }

    #[test]
    fn rejects_long_in_last_constant_pool_slot_that_noak_accepts() {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&0xcafebabe_u32.to_be_bytes());
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 52);
        u16_be(&mut bytes, 4);
        utf8(&mut bytes, b"A");
        class_entry(&mut bytes, 1);
        bytes.push(5);
        bytes.extend_from_slice(&0i64.to_be_bytes());
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 2);
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 0);
        assert!(
            Class::new(&bytes).is_ok(),
            "regression premise: noak 0.7.0 accepts the malformed pool boundary"
        );
        let error = inspect_header(
            &bytes,
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Strict,
        )
        .unwrap_err();
        assert!(
            matches!(error, Error::InvalidInput { ref code, .. } if code == "classfile_invalid_constant_pool_slots")
        );
    }

    #[test]
    fn preflight_cooperatively_stops_when_cancelled_during_pool_scan() {
        let fixture = fixture();
        let token = CancellationToken::new();
        let budget = Budget::with_cancellation_token(limits(u64::MAX), token.clone());
        let mut visited = Vec::new();
        let error = validate_constant_pool_slots_with(&fixture.bytes, &budget, |slot| {
            visited.push(slot);
            if slot == 3 {
                token.cancel();
            }
        })
        .unwrap_err();
        assert!(matches!(error, Error::Cancelled { .. }));
        assert_eq!(visited, [1, 2, 3]);
    }

    #[test]
    fn invalid_magic_keeps_noak_decode_diagnostic_even_if_pool_looks_like_final_long() {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&0xdeadbeef_u32.to_be_bytes());
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 52);
        u16_be(&mut bytes, 2);
        bytes.push(5);
        bytes.extend_from_slice(&0i64.to_be_bytes());
        let error = inspect_header(
            &bytes,
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Strict,
        )
        .unwrap_err();
        assert!(matches!(
            error,
            Error::InvalidInput { ref code, ref message }
                if code == "classfile_decode"
                    && message.contains("kind=invalid file prefix")
                    && !message.contains("constant-pool tag")
        ));

        let error = inspect_header(
            &[0xca, 0xfe, 0xba],
            &mut Budget::new(limits(u64::MAX)),
            InspectionMode::Strict,
        )
        .unwrap_err();
        assert!(matches!(
            error,
            Error::InvalidInput { ref code, .. } if code == "classfile_decode"
        ));
    }

    // -----------------------------------------------------------------------
    // Reader operand facts and control-flow target validation (P2 1.2)
    // -----------------------------------------------------------------------

    /// Class file with one `method()V` and a constant pool that holds the literal
    /// kinds the `ldc` family can name:
    ///
    /// | index | entry |
    /// | --- | --- |
    /// | 8 | `Integer` 7 |
    /// | 9 | `Float` 1.5 |
    /// | 10 | `Long` 0x1122334455667788 (11 is its reserved slot) |
    /// | 12 | `Double` 2.5 (13 is its reserved slot) |
    /// | 15 | `String` "hello" |
    fn operand_fixture(code: &[u8], handlers: &[(u16, u16, u16, u16)]) -> Vec<u8> {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&0xcafebabe_u32.to_be_bytes());
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 52);
        u16_be(&mut bytes, 16);
        utf8(&mut bytes, b"Test"); // 1
        class_entry(&mut bytes, 1); // 2
        utf8(&mut bytes, b"java/lang/Object"); // 3
        class_entry(&mut bytes, 3); // 4
        utf8(&mut bytes, b"method"); // 5
        utf8(&mut bytes, b"()V"); // 6
        utf8(&mut bytes, b"Code"); // 7
        bytes.push(3);
        bytes.extend_from_slice(&7i32.to_be_bytes()); // 8
        bytes.push(4);
        bytes.extend_from_slice(&1.5f32.to_bits().to_be_bytes()); // 9
        bytes.push(5);
        bytes.extend_from_slice(&0x1122_3344_5566_7788i64.to_be_bytes()); // 10 (+11)
        bytes.push(6);
        bytes.extend_from_slice(&2.5f64.to_bits().to_be_bytes()); // 12 (+13)
        utf8(&mut bytes, b"hello"); // 14
        bytes.push(8);
        u16_be(&mut bytes, 14); // 15
        u16_be(&mut bytes, 0x0021);
        u16_be(&mut bytes, 2);
        u16_be(&mut bytes, 4);
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 1);
        u16_be(&mut bytes, 0x0009);
        u16_be(&mut bytes, 5);
        u16_be(&mut bytes, 6);
        u16_be(&mut bytes, 1);
        let mut content = Vec::new();
        u16_be(&mut content, 4);
        u16_be(&mut content, 3);
        u32_be(&mut content, u32::try_from(code.len()).unwrap());
        content.extend_from_slice(code);
        u16_be(&mut content, u16::try_from(handlers.len()).unwrap());
        for &(start, end, handler, catch) in handlers {
            u16_be(&mut content, start);
            u16_be(&mut content, end);
            u16_be(&mut content, handler);
            u16_be(&mut content, catch);
        }
        u16_be(&mut content, 0);
        attribute(&mut bytes, 7, &content);
        u16_be(&mut bytes, 0);
        bytes
    }

    /// Code array of [`operand_fixture`], laying out one instruction of every operand
    /// class the 1.2 contract names and choosing every control-flow target so that it
    /// is a real instruction start:
    ///
    /// ```text
    ///  0..2    ldc #8 (Integer 7)        35..37  ldc #99 (index outside the pool)
    ///  2..5    ldc_w #9 (Float 1.5)      37..40  goto +3 -> 40
    ///  5..8    ldc2_w #10 (Long)         40..68  tableswitch default -> 100,
    ///  8..11   ldc2_w #12 (Double)                keys -1/0/1 -> 68/71/72
    /// 11..13   bipush 5                  68..71  ifne +3 -> 71
    /// 13..16   sipush 256                71      iload_0
    /// 16       pop                       72      istore_0
    /// 17..19   iload 2                   73..100 lookupswitch default -> 100,
    /// 19       istore_2                          pairs (-7 -> 0), (9 -> 68)
    /// 20..24   wide iload 2              100     return (code_length 101)
    /// 24..27   iinc 1, 3
    /// 27..33   wide iinc 1, 1
    /// 33..35   ldc #15 (String "hello")
    /// ```
    fn operand_code() -> Vec<u8> {
        let mut code = Vec::new();
        code.extend_from_slice(&[0x12, 0x08]);
        code.extend_from_slice(&[0x13, 0x00, 0x09]);
        code.extend_from_slice(&[0x14, 0x00, 0x0a]);
        code.extend_from_slice(&[0x14, 0x00, 0x0c]);
        code.extend_from_slice(&[0x10, 0x05]);
        code.extend_from_slice(&[0x11, 0x01, 0x00]);
        code.push(0x57);
        code.extend_from_slice(&[0x15, 0x02]);
        code.push(0x3d);
        code.extend_from_slice(&[0xc4, 0x15, 0x00, 0x02]);
        code.extend_from_slice(&[0x84, 0x01, 0x03]);
        code.extend_from_slice(&[0xc4, 0x84, 0x00, 0x01, 0x00, 0x01]);
        code.extend_from_slice(&[0x12, 0x0f]);
        code.extend_from_slice(&[0x12, 0x63]);
        code.extend_from_slice(&[0xa7, 0x00, 0x03]);
        assert_eq!(code.len(), 40, "tableswitch must start at BCI 40");
        code.push(0xaa);
        code.extend_from_slice(&[0, 0, 0]); // padding: BCI 40 is 4-byte aligned
        code.extend_from_slice(&(100i32 - 40).to_be_bytes());
        code.extend_from_slice(&(-1i32).to_be_bytes());
        code.extend_from_slice(&1i32.to_be_bytes());
        for target in [68i32, 71, 72] {
            code.extend_from_slice(&(target - 40).to_be_bytes());
        }
        assert_eq!(code.len(), 68, "ifne must start at BCI 68");
        code.extend_from_slice(&[0x9a, 0x00, 0x03]);
        code.push(0x1a);
        code.push(0x3b);
        assert_eq!(code.len(), 73, "lookupswitch must start at BCI 73");
        code.push(0xab);
        code.extend_from_slice(&[0, 0]); // padding: 1 + 73 needs two bytes to align
        code.extend_from_slice(&(100i32 - 73).to_be_bytes());
        code.extend_from_slice(&2i32.to_be_bytes());
        for (key, target) in [(-7i32, 0i32), (9, 68)] {
            code.extend_from_slice(&key.to_be_bytes());
            code.extend_from_slice(&(target - 73).to_be_bytes());
        }
        assert_eq!(code.len(), 100, "return must start at BCI 100");
        code.push(0xb1);
        code
    }

    /// `method_code_facts` for the single `method()V` of a fixture built by
    /// [`operand_fixture`].
    fn operand_facts(bytes: &[u8]) -> MethodCodeFacts {
        let mut budget = Budget::new(limits(u64::MAX));
        let header = class_facts(bytes, &mut budget).unwrap();
        let method = header
            .methods
            .first()
            .expect("fixture has one method")
            .clone();
        method_code_facts(bytes, &method, &mut budget).unwrap()
    }

    /// The public `inspect_method_bytecode` report of [`operand_code`] is pinned
    /// against the values recorded from the build **before** the crate-private 1.2
    /// operand facts existed (working tree at `6fc1674` plus this test module only).
    ///
    /// 1.2 adds crate-private facts and does not touch the public path, so every
    /// public field and every serialized key must stay exactly as recorded here. The
    /// only field left unasserted is `elapsed_millis`, which reports real elapsed
    /// time; the schema assertion covers its presence.
    ///
    /// An intentional public change must update this test and say why, instead of
    /// loosening it.
    #[test]
    fn public_bytecode_report_is_unchanged_by_reader_operand_facts() {
        let bytes = operand_fixture(&operand_code(), &[(0, 100, 100, 2), (40, 101, 71, 0)]);
        let mut budget = Budget::new(limits(u64::MAX));
        let report = inspect_method_bytecode(&bytes, selector(), &mut budget).unwrap();

        assert_eq!(report.selector, selector());
        assert_eq!((report.max_stack, report.max_locals), (4, 3));
        assert_eq!(report.code_span, ByteSpan::new(137, 101));
        assert_eq!(
            report
                .instructions
                .iter()
                .map(|fact| (
                    fact.bci,
                    fact.opcode,
                    fact.width,
                    fact.span.start,
                    fact.span.length,
                    fact.operands_span.start,
                    fact.operands_span.length,
                    fact.constant_pool_index,
                ))
                .collect::<Vec<_>>(),
            vec![
                (0, 0x12, 2, 137, 2, 138, 1, Some(8)),
                (2, 0x13, 3, 139, 3, 140, 2, Some(9)),
                (5, 0x14, 3, 142, 3, 143, 2, Some(10)),
                (8, 0x14, 3, 145, 3, 146, 2, Some(12)),
                (11, 0x10, 2, 148, 2, 149, 1, None),
                (13, 0x11, 3, 150, 3, 151, 2, None),
                (16, 0x57, 1, 153, 1, 154, 0, None),
                (17, 0x15, 2, 154, 2, 155, 1, None),
                (19, 0x3d, 1, 156, 1, 157, 0, None),
                (20, 0xc4, 4, 157, 4, 158, 3, None),
                (24, 0x84, 3, 161, 3, 162, 2, None),
                (27, 0xc4, 6, 164, 6, 165, 5, None),
                (33, 0x12, 2, 170, 2, 171, 1, Some(15)),
                (35, 0x12, 2, 172, 2, 173, 1, Some(99)),
                (37, 0xa7, 3, 174, 3, 175, 2, None),
                (40, 0xaa, 28, 177, 28, 178, 27, None),
                (68, 0x9a, 3, 205, 3, 206, 2, None),
                (71, 0x1a, 1, 208, 1, 209, 0, None),
                (72, 0x3b, 1, 209, 1, 210, 0, None),
                (73, 0xab, 27, 210, 27, 211, 26, None),
                (100, 0xb1, 1, 237, 1, 238, 0, None),
            ]
        );
        assert_eq!(report.exception_handler_count, 2);
        assert_eq!(
            report.exception_handlers,
            vec![
                ExceptionHandlerFact {
                    ordinal: 0,
                    start_bci: 0,
                    end_bci: 100,
                    handler_bci: 100,
                    catch_type_index: Some(2),
                },
                ExceptionHandlerFact {
                    ordinal: 1,
                    start_bci: 40,
                    end_bci: 101,
                    handler_bci: 71,
                    catch_type_index: None,
                },
            ]
        );
        let ExecutionReport::Complete { usage } = &report.execution else {
            panic!("the pinned fixture decodes completely");
        };
        assert_eq!(
            (
                usage.input_bytes,
                usage.archive_entries,
                usage.entry_bytes,
                usage.read_bytes,
                usage.class_bytes,
                usage.attribute_bytes,
                usage.code_bytes,
                usage.result_items,
                usage.output_bytes,
                usage.nested_depth,
            ),
            (0, 0, 0, 0, 260, 135, 101, 24, 0, 0)
        );
        assert!(report.diagnostics.is_empty());
        assert_eq!(report.verification, VerificationStatus::NotPerformed);
        assert!(report.stopped_at.is_none());

        // No new public field, and no crate-private fact type, reaches this output.
        let json = serde_json::to_value(&report).unwrap();
        assert_eq!(
            json_keys(&json),
            [
                "code_span",
                "diagnostics",
                "exception_handler_count",
                "exception_handlers",
                "execution",
                "instructions",
                "max_locals",
                "max_stack",
                "selector",
                "stopped_at",
                "verification",
            ]
        );
        for fact in json["instructions"].as_array().unwrap() {
            assert_eq!(
                json_keys(fact),
                [
                    "bci",
                    "constant_pool_index",
                    "opcode",
                    "operands_span",
                    "span",
                    "width",
                ]
            );
        }
        // The usage schema is additive: 1.3 added its six counted dimensions and the
        // `dependency_depth` high-water mark next to the P0/P1 eleven, and this list is
        // still compared exactly, so a rename or a dropped field fails here.
        assert_eq!(
            json_keys(&json["execution"]["usage"]),
            [
                "analysis_steps",
                "archive_entries",
                "attribute_bytes",
                "class_bytes",
                "class_headers",
                "code_bytes",
                "dependency_depth",
                "elapsed_millis",
                "entry_bytes",
                "input_bytes",
                "ir_edges",
                "ir_items",
                "method_bodies",
                "nested_depth",
                "normalization_clones",
                "output_bytes",
                "read_bytes",
                "result_items",
            ]
        );
        assert_eq!(json_keys(&json["selector"]), ["descriptor", "name"]);
    }

    /// Sorted serialized keys of one JSON object, so a schema change is visible.
    fn json_keys(value: &serde_json::Value) -> Vec<&str> {
        value
            .as_object()
            .expect("serialized reports are JSON objects")
            .keys()
            .map(String::as_str)
            .collect()
    }

    /// Stable code and message of the structured error `control_flow_targets` returns
    /// for one fixture; panics when the fixture validates.
    fn target_error(code: &[u8], handlers: &[(u16, u16, u16, u16)]) -> (String, String) {
        let bytes = operand_fixture(code, handlers);
        let facts = operand_facts(&bytes);
        let error = facts
            .control_flow_targets()
            .expect_err("fixture must be rejected");
        match error {
            Error::InvalidInput { code, message } => (code, message),
            other => panic!("expected a structured invalid-input error, got {other:?}"),
        }
    }

    /// Operand facts of the instruction starting at `bci`, with the lockstep check.
    fn operand_facts_at(facts: &MethodCodeFacts, bci: u32) -> InstructionOperands {
        let position = facts
            .instructions
            .binary_search_by_key(&bci, |fact| fact.bci)
            .unwrap_or_else(|_| panic!("no instruction starts at BCI {bci}"));
        assert_eq!(
            facts.operands.len(),
            facts.instructions.len(),
            "operand facts must stay in lockstep with instructions"
        );
        facts.operands[position].clone()
    }

    #[test]
    fn operand_facts_cover_immediates_locals_increments_and_cp_indices() {
        let facts = operand_facts(&operand_fixture(&operand_code(), &[]));
        assert_eq!(facts.instructions.len(), facts.operands.len());
        assert!(matches!(facts.execution, ExecutionReport::Complete { .. }));
        assert_eq!(facts.instructions.len(), 21);

        // Every operand fact repeats the constant-pool index of its instruction.
        for (fact, operands) in facts.instructions.iter().zip(facts.operands.iter()) {
            assert_eq!(operands.constant_pool_index, fact.constant_pool_index);
        }

        let expected = [
            // `ldc` family: literal kinds become immediates, the `String` entry and an
            // index outside the pool stay reference facts only. The effective opcode equals
            // the raw one for every entry except the two `wide` forms below.
            (
                0,
                InstructionOperands {
                    immediate: Some(ImmediateValue::Int(7)),
                    constant_pool_index: Some(8),
                    effective_opcode: 0x12,
                    ..InstructionOperands::default()
                },
            ),
            (
                2,
                InstructionOperands {
                    immediate: Some(ImmediateValue::Float(1.5f32.to_bits())),
                    constant_pool_index: Some(9),
                    effective_opcode: 0x13,
                    ..InstructionOperands::default()
                },
            ),
            (
                5,
                InstructionOperands {
                    immediate: Some(ImmediateValue::Long(0x1122_3344_5566_7788)),
                    constant_pool_index: Some(10),
                    effective_opcode: 0x14,
                    ..InstructionOperands::default()
                },
            ),
            (
                8,
                InstructionOperands {
                    immediate: Some(ImmediateValue::Double(2.5f64.to_bits())),
                    constant_pool_index: Some(12),
                    effective_opcode: 0x14,
                    ..InstructionOperands::default()
                },
            ),
            (
                11,
                InstructionOperands {
                    immediate: Some(ImmediateValue::Int(5)),
                    effective_opcode: 0x10,
                    ..InstructionOperands::default()
                },
            ),
            (
                13,
                InstructionOperands {
                    immediate: Some(ImmediateValue::Int(256)),
                    effective_opcode: 0x11,
                    ..InstructionOperands::default()
                },
            ),
            // `pop` has no operand at all, so its fact is all-`None` but for its opcode.
            (
                16,
                InstructionOperands {
                    effective_opcode: 0x57,
                    ..InstructionOperands::default()
                },
            ),
            (
                17,
                InstructionOperands {
                    local: Some(LocalOperand {
                        index: 2,
                        wide: false,
                    }),
                    effective_opcode: 0x15,
                    ..InstructionOperands::default()
                },
            ),
            (
                19,
                InstructionOperands {
                    local: Some(LocalOperand {
                        index: 2,
                        wide: false,
                    }),
                    effective_opcode: 0x3d,
                    ..InstructionOperands::default()
                },
            ),
            (
                20,
                InstructionOperands {
                    local: Some(LocalOperand {
                        index: 2,
                        wide: true,
                    }),
                    // The raw opcode of this instruction is the `wide` prefix; the opcode it
                    // wraps is what every classification reads.
                    effective_opcode: 0x15,
                    ..InstructionOperands::default()
                },
            ),
            (
                24,
                InstructionOperands {
                    local: Some(LocalOperand {
                        index: 1,
                        wide: false,
                    }),
                    increment: Some(3),
                    effective_opcode: 0x84,
                    ..InstructionOperands::default()
                },
            ),
            (
                27,
                InstructionOperands {
                    local: Some(LocalOperand {
                        index: 1,
                        wide: true,
                    }),
                    increment: Some(1),
                    effective_opcode: 0x84,
                    ..InstructionOperands::default()
                },
            ),
            (
                33,
                InstructionOperands {
                    constant_pool_index: Some(15),
                    effective_opcode: 0x12,
                    ..InstructionOperands::default()
                },
            ),
            (
                35,
                InstructionOperands {
                    constant_pool_index: Some(99),
                    effective_opcode: 0x12,
                    ..InstructionOperands::default()
                },
            ),
            (
                37,
                InstructionOperands {
                    branch_offset: Some(3),
                    effective_opcode: 0xa7,
                    ..InstructionOperands::default()
                },
            ),
            (
                40,
                InstructionOperands {
                    switch: Some(SwitchOperands::Table {
                        default_offset: 60,
                        low: -1,
                        high: 1,
                        offsets: vec![28, 31, 32],
                    }),
                    effective_opcode: 0xaa,
                    ..InstructionOperands::default()
                },
            ),
            (
                68,
                InstructionOperands {
                    branch_offset: Some(3),
                    effective_opcode: 0x9a,
                    ..InstructionOperands::default()
                },
            ),
            (
                71,
                InstructionOperands {
                    local: Some(LocalOperand {
                        index: 0,
                        wide: false,
                    }),
                    effective_opcode: 0x1a,
                    ..InstructionOperands::default()
                },
            ),
            (
                72,
                InstructionOperands {
                    local: Some(LocalOperand {
                        index: 0,
                        wide: false,
                    }),
                    effective_opcode: 0x3b,
                    ..InstructionOperands::default()
                },
            ),
            (
                73,
                InstructionOperands {
                    switch: Some(SwitchOperands::Lookup {
                        default_offset: 27,
                        pairs: vec![(-7, -73), (9, -5)],
                    }),
                    effective_opcode: 0xab,
                    ..InstructionOperands::default()
                },
            ),
            (
                100,
                InstructionOperands {
                    effective_opcode: 0xb1,
                    ..InstructionOperands::default()
                },
            ),
        ];
        for (bci, operands) in expected {
            assert_eq!(operand_facts_at(&facts, bci), operands, "BCI {bci}");
        }
        // The effective opcode of every other instruction of the fixture is its raw opcode:
        // the fixture's whole point is that only a `wide` form has two opcodes.
        for (fact, operands) in facts.instructions.iter().zip(facts.operands.iter()) {
            if !matches!(fact.bci, 20 | 27) {
                assert_eq!(
                    operands.effective_opcode, fact.opcode,
                    "BCI {} of a fixture whose only `wide` forms are at 20 and 27",
                    fact.bci
                );
            }
        }
        // The raw opcode of the two `wide` forms is untouched, exactly like their width and
        // their span: the public fact keeps the prefix.
        assert_eq!(
            facts
                .instructions
                .iter()
                .filter(|fact| fact.opcode == 0xc4)
                .map(|fact| fact.bci)
                .collect::<Vec<_>>(),
            vec![20, 27]
        );
    }

    #[test]
    fn control_flow_targets_convert_branches_switches_and_handlers() {
        let facts = operand_facts(&operand_fixture(
            &operand_code(),
            &[(0, 100, 100, 2), (40, 101, 71, 0)],
        ));
        let targets = facts.control_flow_targets().unwrap();
        assert_eq!(
            targets,
            vec![
                ControlFlowTarget {
                    instruction_bci: 37,
                    kind: ControlFlowTargetKind::Branch { offset: 3 },
                    target_bci: 40,
                },
                ControlFlowTarget {
                    instruction_bci: 40,
                    kind: ControlFlowTargetKind::SwitchDefault,
                    target_bci: 100,
                },
                ControlFlowTarget {
                    instruction_bci: 40,
                    kind: ControlFlowTargetKind::SwitchCase { index: 0, key: -1 },
                    target_bci: 68,
                },
                ControlFlowTarget {
                    instruction_bci: 40,
                    kind: ControlFlowTargetKind::SwitchCase { index: 1, key: 0 },
                    target_bci: 71,
                },
                ControlFlowTarget {
                    instruction_bci: 40,
                    kind: ControlFlowTargetKind::SwitchCase { index: 2, key: 1 },
                    target_bci: 72,
                },
                ControlFlowTarget {
                    instruction_bci: 68,
                    kind: ControlFlowTargetKind::Branch { offset: 3 },
                    target_bci: 71,
                },
                ControlFlowTarget {
                    instruction_bci: 73,
                    kind: ControlFlowTargetKind::SwitchDefault,
                    target_bci: 100,
                },
                ControlFlowTarget {
                    instruction_bci: 73,
                    kind: ControlFlowTargetKind::SwitchCase { index: 0, key: -7 },
                    target_bci: 0,
                },
                ControlFlowTarget {
                    instruction_bci: 73,
                    kind: ControlFlowTargetKind::SwitchCase { index: 1, key: 9 },
                    target_bci: 68,
                },
                // `end == code_length` is the legal half-open end of the code array.
                ControlFlowTarget {
                    instruction_bci: 100,
                    kind: ControlFlowTargetKind::Handler { ordinal: 0 },
                    target_bci: 100,
                },
                ControlFlowTarget {
                    instruction_bci: 71,
                    kind: ControlFlowTargetKind::Handler { ordinal: 1 },
                    target_bci: 71,
                },
            ]
        );
    }

    #[test]
    fn tableswitch_keys_hold_their_low_high_bounds() {
        // A key interval next to `i32::MAX`: the key of a case is `low + index`, and the
        // interval must not overflow the i32 key space.
        let mut code = vec![0xaa, 0, 0, 0];
        code.extend_from_slice(&28i32.to_be_bytes());
        code.extend_from_slice(&(i32::MAX - 2).to_be_bytes());
        code.extend_from_slice(&i32::MAX.to_be_bytes());
        for _ in 0..3 {
            code.extend_from_slice(&28i32.to_be_bytes());
        }
        code.push(0xb1);
        let facts = operand_facts(&operand_fixture(&code, &[]));
        assert_eq!(
            operand_facts_at(&facts, 0).switch,
            Some(SwitchOperands::Table {
                default_offset: 28,
                low: i32::MAX - 2,
                high: i32::MAX,
                offsets: vec![28, 28, 28],
            })
        );
        assert_eq!(
            facts.control_flow_targets().unwrap(),
            vec![
                ControlFlowTarget {
                    instruction_bci: 0,
                    kind: ControlFlowTargetKind::SwitchDefault,
                    target_bci: 28,
                },
                ControlFlowTarget {
                    instruction_bci: 0,
                    kind: ControlFlowTargetKind::SwitchCase {
                        index: 0,
                        key: i32::MAX - 2,
                    },
                    target_bci: 28,
                },
                ControlFlowTarget {
                    instruction_bci: 0,
                    kind: ControlFlowTargetKind::SwitchCase {
                        index: 1,
                        key: i32::MAX - 1,
                    },
                    target_bci: 28,
                },
                ControlFlowTarget {
                    instruction_bci: 0,
                    kind: ControlFlowTargetKind::SwitchCase {
                        index: 2,
                        key: i32::MAX,
                    },
                    target_bci: 28,
                },
            ]
        );
    }

    #[test]
    fn implicit_and_wide_locals_keep_their_index() {
        let code = [
            0x15, 0x07, // iload 7
            0x16, 0x08, // lload 8
            0x17, 0x09, // fload 9
            0x18, 0x0a, // dload 10
            0x19, 0x0b, // aload 11
            0x36, 0x0c, // istore 12
            0x37, 0x0d, // lstore 13
            0x38, 0x0e, // fstore 14
            0x39, 0x0f, // dstore 15
            0x3a, 0x10, // astore 16
            0x1d, // iload_3
            0x21, // lload_3
            0x25, // fload_3
            0x29, // dload_3
            0x2d, // aload_3
            0x3e, // istore_3
            0x42, // lstore_3
            0x46, // fstore_3
            0x4a, // dstore_3
            0x4e, // astore_3
            0xa9, 0x11, // ret 17
            0xc4, 0x15, 0x00, 0x12, // wide iload 18
            0xc4, 0x39, 0x00, 0x13, // wide dstore 19
            0xc4, 0xa9, 0x00, 0x14, // wide ret 20
            0xc4, 0x3a, 0x00, 0x15, // wide astore 21
            0xc4, 0x17, 0x00, 0x16, // wide fload 22
            0xb1, // return
        ];
        let facts = operand_facts(&operand_fixture(&code, &[]));
        let expected: Vec<(u32, Option<LocalOperand>)> = vec![
            (0, local(7, false)),
            (2, local(8, false)),
            (4, local(9, false)),
            (6, local(10, false)),
            (8, local(11, false)),
            (10, local(12, false)),
            (12, local(13, false)),
            (14, local(14, false)),
            (16, local(15, false)),
            (18, local(16, false)),
            (20, local(3, false)),
            (21, local(3, false)),
            (22, local(3, false)),
            (23, local(3, false)),
            (24, local(3, false)),
            (25, local(3, false)),
            (26, local(3, false)),
            (27, local(3, false)),
            (28, local(3, false)),
            (29, local(3, false)),
            (30, local(17, false)),
            (32, local(18, true)),
            (36, local(19, true)),
            (40, local(20, true)),
            (44, local(21, true)),
            (48, local(22, true)),
            (52, None),
        ];
        for (bci, operands) in expected {
            assert_eq!(operand_facts_at(&facts, bci).local, operands, "BCI {bci}");
        }
    }

    /// A local expectation, so the table above reads as one column.
    fn local(index: u16, wide: bool) -> Option<LocalOperand> {
        Some(LocalOperand { index, wide })
    }

    #[test]
    fn stopped_bodies_keep_instruction_and_operand_lockstep() {
        let bytes = operand_fixture(&operand_code(), &[]);
        let mut header_budget = Budget::new(limits(u64::MAX));
        let header = class_facts(&bytes, &mut header_budget).unwrap();
        let method = header.methods.first().unwrap().clone();
        let mut limited = limits(u64::MAX);
        limited.code_bytes = 5;
        let facts = method_code_facts(&bytes, &method, &mut Budget::new(limited)).unwrap();
        assert!(matches!(facts.execution, ExecutionReport::Partial { .. }));
        assert!(facts.stopped_at.is_some());
        assert_eq!(facts.instructions.len(), 2);
        assert_eq!(facts.operands.len(), 2);
        assert_eq!(
            facts.operands[1].immediate,
            Some(ImmediateValue::Float(1.5f32.to_bits()))
        );
    }

    #[test]
    fn branch_targets_inside_operands_are_rejected_with_the_sourcing_bci() {
        // `goto +1` at BCI 2 targets BCI 3, the first operand byte of the `goto` itself.
        let code = [0x10, 0x05, 0xa7, 0x00, 0x01, 0xb1];
        let bytes = operand_fixture(&code, &[]);
        // The body itself decodes: the rejection is target validation, not a decode stop.
        let facts = operand_facts(&bytes);
        assert!(matches!(facts.execution, ExecutionReport::Complete { .. }));
        let (error_code, message) = target_error(&code, &[]);
        assert_eq!(error_code, "classfile_instruction_invalid_target");
        assert!(
            message.contains("branch from BCI 2 with offset 1"),
            "{message}"
        );
        assert!(message.contains("target 3"), "{message}");
    }

    #[test]
    fn targets_outside_the_code_array_are_rejected() {
        // `goto +99` at BCI 2 reaches BCI 101 of a 6-byte code array.
        let (code, message) = target_error(&[0x10, 0x05, 0xa7, 0x00, 0x63, 0xb1], &[]);
        assert_eq!(code, "classfile_instruction_target_out_of_bounds");
        assert!(
            message.contains("branch from BCI 2 with offset 99"),
            "{message}"
        );
        assert!(message.contains("target 101 is outside 0..6"), "{message}");

        // A negative relative offset leaves the code array below BCI 0.
        let (code, message) = target_error(&[0xa7, 0xff, 0xfb], &[]);
        assert_eq!(code, "classfile_instruction_target_out_of_bounds");
        assert!(
            message.contains("relative offset -5 at BCI 0 targets a BCI before 0"),
            "{message}"
        );

        // A handler entry outside the code array.
        let (code, message) = target_error(&[0xb1], &[(0, 1, 9, 0)]);
        assert_eq!(code, "classfile_instruction_target_out_of_bounds");
        assert!(
            message.contains("exception handler 0 entry target 9 is outside 0..1"),
            "{message}"
        );
    }

    #[test]
    fn handler_entry_inside_operands_is_rejected() {
        // `bipush 5` at BCI 0, `return` at 2: BCI 1 is an operand byte, and the
        // protected range ends exactly at `code_length`.
        let (code, message) = target_error(&[0x10, 0x05, 0xb1], &[(0, 3, 1, 0)]);
        assert_eq!(code, "classfile_instruction_invalid_target");
        assert!(
            message.contains("exception handler 0 entry target 1 is not an instruction start"),
            "{message}"
        );
    }

    #[test]
    fn handler_ranges_must_start_before_they_end_and_stay_inside_the_code() {
        // `start > end` on a legal handler entry.
        let (code, message) = target_error(&[0x10, 0x05, 0xb1], &[(2, 1, 2, 0)]);
        assert_eq!(code, "classfile_exception_range_invalid");
        assert!(
            message.contains("exception handler 0 protected range 2..1 starts after its end"),
            "{message}"
        );

        // `end > code_length` on a legal handler entry.
        let (code, message) = target_error(&[0xb1], &[(0, 4, 0, 0)]);
        assert_eq!(code, "classfile_exception_range_invalid");
        assert!(
            message.contains("exception handler 0 protected range 0..4 ends past code_length 1"),
            "{message}"
        );

        // Half-open and legal: `end == code_length`, handler on the last instruction.
        let facts = operand_facts(&operand_fixture(&[0x10, 0x05, 0xb1], &[(0, 3, 2, 0)]));
        assert_eq!(
            facts.control_flow_targets().unwrap(),
            vec![ControlFlowTarget {
                instruction_bci: 2,
                kind: ControlFlowTargetKind::Handler { ordinal: 0 },
                target_bci: 2,
            }]
        );
    }

    #[test]
    fn switch_case_targets_are_validated_like_branches() {
        // `tableswitch` at BCI 0 with one case pointing past the 21-byte code array.
        let mut code = vec![0xaa, 0, 0, 0];
        code.extend_from_slice(&20i32.to_be_bytes());
        code.extend_from_slice(&0i32.to_be_bytes());
        code.extend_from_slice(&0i32.to_be_bytes());
        code.extend_from_slice(&100i32.to_be_bytes());
        code.push(0xb1);
        let (code, message) = target_error(&code, &[]);
        assert_eq!(code, "classfile_instruction_target_out_of_bounds");
        assert!(message.contains("switch case 0 from BCI 0"), "{message}");
        assert!(message.contains("target 100 is outside 0..21"), "{message}");

        // A case that lands inside the switch payload is not an instruction start.
        let mut code = vec![0xaa, 0, 0, 0];
        code.extend_from_slice(&20i32.to_be_bytes());
        code.extend_from_slice(&0i32.to_be_bytes());
        code.extend_from_slice(&0i32.to_be_bytes());
        code.extend_from_slice(&4i32.to_be_bytes());
        code.push(0xb1);
        let (code, message) = target_error(&code, &[]);
        assert_eq!(code, "classfile_instruction_invalid_target");
        assert!(message.contains("switch case 0 from BCI 0"), "{message}");
        assert!(
            message.contains("target 4 is not an instruction start"),
            "{message}"
        );
    }

    #[test]
    fn relative_target_arithmetic_is_checked_in_both_directions() {
        let error = relative_target_bci(u32::MAX, 1).unwrap_err();
        assert!(
            matches!(error, Error::InvalidInput { ref code, .. } if code == "classfile_code_span_overflow")
        );
        let error = relative_target_bci(u32::MAX, i32::MAX).unwrap_err();
        assert!(
            matches!(error, Error::InvalidInput { ref code, .. } if code == "classfile_code_span_overflow")
        );
        let error = relative_target_bci(0, -1).unwrap_err();
        assert!(
            matches!(error, Error::InvalidInput { ref code, .. } if code == "classfile_instruction_target_out_of_bounds")
        );
        let error = relative_target_bci(1, i32::MIN).unwrap_err();
        assert!(
            matches!(error, Error::InvalidInput { ref code, .. } if code == "classfile_instruction_target_out_of_bounds")
        );
        assert_eq!(relative_target_bci(10, -10).unwrap(), 0);
        assert_eq!(relative_target_bci(10, 5).unwrap(), 15);
    }

    #[test]
    fn switch_operands_reject_a_region_that_does_not_match_the_decoded_shape() {
        // Two entries need `1 + 3 + 12 + 8` bytes; the recorded region is one truncated
        // instruction, which is what a width/byte disagreement would look like.
        let error = table_switch_operands(0, &[0xaa, 0, 0, 0], 0, 0, 1).unwrap_err();
        assert!(
            matches!(error, Error::InvalidInput { ref code, ref message }
                if code == "classfile_instruction_shape_mismatch"
                    && message.contains("tableswitch at BCI 0 has 4 recorded bytes but 2 entries need 24")),
            "{error:?}"
        );

        // A pair list whose last pair is cut off.
        let bytes = [0xab_u8, 0, 0, 0];
        let error = lookup_switch_operands(0, &bytes, 0, 1).unwrap_err();
        assert!(matches!(error, Error::InvalidInput { ref code, .. }
                if code == "classfile_instruction_shape_mismatch"));

        // `high < low` is a range violation, not a shape violation.
        let error = table_switch_operands(0, &[], 0, 5, 4).unwrap_err();
        assert!(matches!(error, Error::InvalidInput { ref code, .. }
                if code == "classfile_instruction_invalid_range"));

        // A single operand that leaves the recorded bytes.
        let error = switch_i32(&[0, 0, 0], 7, 0).unwrap_err();
        assert!(
            matches!(error, Error::InvalidInput { ref code, ref message }
                if code == "classfile_instruction_shape_mismatch"
                    && message.contains("BCI 7")),
            "{error:?}"
        );
    }

    #[test]
    fn switch_defaults_are_validated_like_cases() {
        // `tableswitch` at BCI 0, one case on the trailing `return` at BCI 20; the
        // default points at BCI 1, inside the switch's own padding.
        let mut code = vec![0xaa, 0, 0, 0];
        code.extend_from_slice(&1i32.to_be_bytes());
        code.extend_from_slice(&0i32.to_be_bytes());
        code.extend_from_slice(&0i32.to_be_bytes());
        code.extend_from_slice(&20i32.to_be_bytes());
        code.push(0xb1);
        let (error_code, message) = target_error(&code, &[]);
        assert_eq!(error_code, "classfile_instruction_invalid_target");
        assert!(message.contains("switch default from BCI 0"), "{message}");
        assert!(
            message.contains("target 1 is not an instruction start"),
            "{message}"
        );

        // `lookupswitch` at BCI 0, one pair on the trailing `return`; the default is far
        // outside the code array.
        let mut code = vec![0xab, 0, 0, 0];
        code.extend_from_slice(&1000i32.to_be_bytes());
        code.extend_from_slice(&1i32.to_be_bytes());
        code.extend_from_slice(&0i32.to_be_bytes());
        code.extend_from_slice(&20i32.to_be_bytes());
        code.push(0xb1);
        let (error_code, message) = target_error(&code, &[]);
        assert_eq!(error_code, "classfile_instruction_target_out_of_bounds");
        assert!(message.contains("switch default from BCI 0"), "{message}");
        assert!(
            message.contains("target 1000 is outside 0..21"),
            "{message}"
        );

        // With a legal default, the same two shapes validate, so the cases above fail
        // for the default and not because the switch itself is malformed.
        let mut valid = vec![0xaa, 0, 0, 0];
        valid.extend_from_slice(&20i32.to_be_bytes());
        valid.extend_from_slice(&0i32.to_be_bytes());
        valid.extend_from_slice(&0i32.to_be_bytes());
        valid.extend_from_slice(&20i32.to_be_bytes());
        valid.push(0xb1);
        let facts = operand_facts(&operand_fixture(&valid, &[]));
        assert_eq!(
            facts.control_flow_targets().unwrap(),
            vec![
                ControlFlowTarget {
                    instruction_bci: 0,
                    kind: ControlFlowTargetKind::SwitchDefault,
                    target_bci: 20,
                },
                ControlFlowTarget {
                    instruction_bci: 0,
                    kind: ControlFlowTargetKind::SwitchCase { index: 0, key: 0 },
                    target_bci: 20,
                },
            ]
        );

        let mut valid = vec![0xab, 0, 0, 0];
        valid.extend_from_slice(&20i32.to_be_bytes());
        valid.extend_from_slice(&1i32.to_be_bytes());
        valid.extend_from_slice(&0i32.to_be_bytes());
        valid.extend_from_slice(&20i32.to_be_bytes());
        valid.push(0xb1);
        let facts = operand_facts(&operand_fixture(&valid, &[]));
        assert_eq!(
            facts.control_flow_targets().unwrap(),
            vec![
                ControlFlowTarget {
                    instruction_bci: 0,
                    kind: ControlFlowTargetKind::SwitchDefault,
                    target_bci: 20,
                },
                ControlFlowTarget {
                    instruction_bci: 0,
                    kind: ControlFlowTargetKind::SwitchCase { index: 0, key: 0 },
                    target_bci: 20,
                },
            ]
        );
    }

    #[test]
    fn jsr_operands_and_targets_use_the_same_validation() {
        let code = [
            0xa8, 0x00, 0x03, // 0: jsr +3 -> BCI 3
            0xc9, 0x00, 0x00, 0x00, 0x05, // 3: jsr_w +5 -> BCI 8
            0xb1, // 8: return
        ];
        let facts = operand_facts(&operand_fixture(&code, &[]));
        assert_eq!(operand_facts_at(&facts, 0).branch_offset, Some(3));
        assert_eq!(operand_facts_at(&facts, 3).branch_offset, Some(5));
        assert_eq!(
            facts.control_flow_targets().unwrap(),
            vec![
                ControlFlowTarget {
                    instruction_bci: 0,
                    kind: ControlFlowTargetKind::Branch { offset: 3 },
                    target_bci: 3,
                },
                ControlFlowTarget {
                    instruction_bci: 3,
                    kind: ControlFlowTargetKind::Branch { offset: 5 },
                    target_bci: 8,
                },
            ]
        );

        // Both subroutines go through the same target rules as any other branch.
        let (error_code, message) = target_error(&[0xa8, 0x00, 0x01, 0xb1], &[]);
        assert_eq!(error_code, "classfile_instruction_invalid_target");
        assert!(
            message.contains("branch from BCI 0 with offset 1"),
            "{message}"
        );
        let (error_code, message) = target_error(&[0xc9, 0x00, 0x00, 0x00, 0x63, 0xb1], &[]);
        assert_eq!(error_code, "classfile_instruction_target_out_of_bounds");
        assert!(
            message.contains("branch from BCI 0 with offset 99"),
            "{message}"
        );
        // A negative `jsr_w` offset leaves the code array below BCI 0.
        let (error_code, message) = target_error(&[0xc9, 0xff, 0xff, 0xff, 0xfb], &[]);
        assert_eq!(error_code, "classfile_instruction_target_out_of_bounds");
        assert!(
            message.contains("relative offset -5 at BCI 0 targets a BCI before 0"),
            "{message}"
        );
    }

    #[test]
    fn signed_operands_keep_their_sign() {
        let code = [
            0x10, 0xfb, // 0: bipush -5
            0x11, 0xfe, 0xd4, // 2: sipush -300
            0x84, 0x03, 0xfe, // 5: iinc 3, -2
            0xc4, 0x84, 0x00, 0x04, 0xff, 0xfb, // 8: wide iinc 4, -5
            0xb1, // 14: return
        ];
        let facts = operand_facts(&operand_fixture(&code, &[]));
        assert_eq!(
            operand_facts_at(&facts, 0).immediate,
            Some(ImmediateValue::Int(-5))
        );
        assert_eq!(
            operand_facts_at(&facts, 2).immediate,
            Some(ImmediateValue::Int(-300))
        );
        assert_eq!(
            operand_facts_at(&facts, 5),
            InstructionOperands {
                local: local(3, false),
                increment: Some(-2),
                effective_opcode: 0x84,
                ..InstructionOperands::default()
            }
        );
        assert_eq!(
            operand_facts_at(&facts, 8),
            InstructionOperands {
                local: local(4, true),
                increment: Some(-5),
                // The `wide iinc` of a local above 255: the prefix is the raw opcode, `iinc`
                // is the effective one.
                effective_opcode: 0x84,
                ..InstructionOperands::default()
            }
        );
        // The negative operands decode; nothing in this body is a control-flow target.
        assert_eq!(facts.control_flow_targets().unwrap(), Vec::new());
    }

    #[test]
    fn operand_facts_retain_the_opcode_each_wide_form_wraps() {
        // All twelve wrappings JVMS 6.5 allows, one instruction each, on real bytes: the raw
        // opcode of every one of them is the `wide` prefix, the width is the wide one, and the
        // effective opcode is the opcode the prefix wraps (`wide iinc` is the six-byte form).
        let cases: &[(u8, u32, u16)] = &[
            (0x15, 4, 2),   // wide iload
            (0x16, 4, 300), // wide lload
            (0x17, 4, 4),   // wide fload
            (0x18, 4, 5),   // wide dload
            (0x19, 4, 6),   // wide aload
            (0x36, 4, 7),   // wide istore
            (0x37, 4, 8),   // wide lstore
            (0x38, 4, 9),   // wide fstore
            (0x39, 4, 10),  // wide dstore
            (0x3a, 4, 11),  // wide astore
            (0xa9, 4, 12),  // wide ret
            (0x84, 6, 13),  // wide iinc
        ];
        let mut code = Vec::new();
        let mut expected: Vec<(u32, u8, u32, u16)> = Vec::new();
        for &(wrapped, width, index) in cases {
            expected.push((u32::try_from(code.len()).unwrap(), wrapped, width, index));
            code.push(0xc4);
            code.push(wrapped);
            code.extend_from_slice(&index.to_be_bytes());
            if wrapped == 0x84 {
                code.extend_from_slice(&0i16.to_be_bytes()); // the increment of `wide iinc 13, 0`
            }
        }
        let bytes = test_class::single_method(52, 8, 512, &code);
        let facts = operand_facts(&bytes);
        assert!(matches!(facts.execution, ExecutionReport::Complete { .. }));
        assert_eq!(facts.instructions.len(), cases.len());
        for (bci, wrapped, width, index) in expected {
            let fact = facts
                .instructions
                .iter()
                .find(|fact| fact.bci == bci)
                .unwrap_or_else(|| panic!("no instruction at BCI {bci}"));
            let operands = operand_facts_at(&facts, bci);
            assert_eq!(fact.opcode, 0xc4, "BCI {bci} keeps the raw prefix");
            assert_eq!(fact.width, width, "BCI {bci}");
            assert_eq!(
                operands.effective_opcode, wrapped,
                "BCI {bci} must classify as the opcode it wraps"
            );
            assert_eq!(
                operands.local,
                Some(LocalOperand { index, wide: true }),
                "BCI {bci} names the local the wrapped form names"
            );
        }
        // The two opcodes are separate facts: none of these twelve is malformed, so the body
        // decodes completely and every wrapped opcode is one of the twelve.
        assert_eq!(facts.stopped_at, None);
        assert!(
            cases.iter().all(|(wrapped, _, _)| *wrapped != 0xc4),
            "no wrapping is itself a prefix"
        );
    }

    #[test]
    fn operand_facts_retain_array_types_dimensions_and_interface_counts() {
        // Array creation and interface calls, on real bytes. `atype`, `dimensions` and `count`
        // are payloads of their own kind: they are never `immediate`, and the reader records
        // them exactly as encoded — `dimensions = 0` and a `count` that disagrees with the
        // descriptor are facts for the verifier (4.x/5.1) to judge, not reader errors.
        let array_types = [4u8, 5, 6, 7, 8, 9, 10, 11];
        let dimensions = [0u8, 2, 255];
        let counts = [3u8, 2, 0];
        let mut code = Vec::new();
        let mut new_arrays = Vec::new();
        for atype in array_types {
            new_arrays.push((u32::try_from(code.len()).unwrap(), atype));
            code.extend_from_slice(&[0xbc, atype]);
        }
        let mut multi_arrays = Vec::new();
        for dimension in dimensions {
            multi_arrays.push((u32::try_from(code.len()).unwrap(), dimension));
            code.push(0xc5);
            code.extend_from_slice(&9u16.to_be_bytes()); // the `[[I` class entry
            code.push(dimension);
        }
        let mut interface_calls = Vec::new();
        for count in counts {
            interface_calls.push((u32::try_from(code.len()).unwrap(), count));
            code.push(0xb9);
            code.extend_from_slice(&15u16.to_be_bytes()); // `run:(J)V` of the fixture pool
            code.push(count);
            code.push(0);
        }
        code.push(0xb1); // return

        let bytes = test_class::single_method(52, 8, 8, &code);
        let facts = operand_facts(&bytes);
        assert!(matches!(facts.execution, ExecutionReport::Complete { .. }));
        assert_eq!(facts.stopped_at, None);
        assert_eq!(
            facts.instructions.len(),
            array_types.len() + dimensions.len() + counts.len() + 1
        );

        for (bci, atype) in new_arrays {
            let operands = operand_facts_at(&facts, bci);
            assert_eq!(operands.effective_opcode, 0xbc, "BCI {bci}");
            assert_eq!(operands.atype, Some(atype), "BCI {bci}");
            assert_eq!(operands.immediate, None, "an element type is not a value");
            assert_eq!(operands.constant_pool_index, None, "BCI {bci}");
        }
        for (bci, dimension) in multi_arrays {
            let operands = operand_facts_at(&facts, bci);
            assert_eq!(operands.effective_opcode, 0xc5, "BCI {bci}");
            assert_eq!(operands.dimensions, Some(dimension), "BCI {bci}");
            assert_eq!(operands.immediate, None, "BCI {bci}");
            assert_eq!(operands.constant_pool_index, Some(9), "BCI {bci}");
        }
        for (bci, count) in interface_calls {
            let operands = operand_facts_at(&facts, bci);
            assert_eq!(operands.effective_opcode, 0xb9, "BCI {bci}");
            assert_eq!(operands.interface_count, Some(count), "BCI {bci}");
            assert_eq!(operands.immediate, None, "BCI {bci}");
            assert_eq!(operands.constant_pool_index, Some(15), "BCI {bci}");
        }

        // The three facts belong to three opcodes: none of them leaks onto any other
        // instruction of the same body.
        for (position, fact) in facts.instructions.iter().enumerate() {
            let operands = &facts.operands[position];
            match fact.opcode {
                0xbc => {
                    assert!(operands.dimensions.is_none() && operands.interface_count.is_none())
                }
                0xc5 => assert!(operands.atype.is_none() && operands.interface_count.is_none()),
                0xb9 => assert!(operands.atype.is_none() && operands.dimensions.is_none()),
                _ => assert!(
                    operands.atype.is_none()
                        && operands.dimensions.is_none()
                        && operands.interface_count.is_none(),
                    "BCI {} carries no array or invocation payload",
                    fact.bci
                ),
            }
        }
    }

    #[test]
    fn an_element_type_outside_the_encoded_range_stops_the_decode() {
        // `atype` is part of the instruction's encoding, so a code outside JVMS' `4..=11` is
        // not an operand fact at all: the instruction does not decode, the reader stops at its
        // BCI, and the reliable prefix keeps only what came before it. The adapter does not
        // guess a fact for an instruction noak refused, and it does not re-decode the bytes.
        for atype in [0u8, 3, 12, 255] {
            let code = [0x00, 0xbc, atype, 0xb1]; // nop; newarray <atype>; return
            let bytes = test_class::single_method(52, 8, 8, &code);
            let facts = operand_facts(&bytes);
            assert_eq!(facts.instructions.len(), 1, "atype {atype}");
            assert_eq!(facts.operands.len(), 1, "atype {atype}");
            assert_eq!(facts.operands[0].effective_opcode, 0x00, "atype {atype}");
            assert_eq!(facts.operands[0].atype, None, "atype {atype}");
            match &facts.stopped_at {
                Some(BytecodeStop::Instructions { bci, code, .. }) => {
                    assert_eq!(*bci, 1, "the stop is the undecodable instruction");
                    assert_eq!(code, "classfile_instruction_decode", "atype {atype}");
                }
                other => panic!("expected a decode stop at BCI 1, got {other:?}"),
            }
        }
    }

    #[test]
    fn targets_at_code_length_are_out_of_bounds_not_unstarted() {
        // `goto +3` in a 3-byte code array targets exactly `code_length`: one past the
        // last byte. That is a bounds error, not an "inside an operand" error.
        let (error_code, message) = target_error(&[0xa7, 0x00, 0x03], &[]);
        assert_eq!(error_code, "classfile_instruction_target_out_of_bounds");
        assert!(message.contains("target 3 is outside 0..3"), "{message}");

        // BCI `code_length - 1` is still a legal target: `goto +3` reaches the `return`.
        let facts = operand_facts(&operand_fixture(&[0xa7, 0x00, 0x03, 0xb1], &[]));
        assert_eq!(facts.control_flow_targets().unwrap()[0].target_bci, 3);

        // A handler entry exactly at `code_length` is not a target either, and the
        // range itself is legal (`end == code_length`).
        let (error_code, message) = target_error(&[0xb1], &[(0, 1, 1, 0)]);
        assert_eq!(error_code, "classfile_instruction_target_out_of_bounds");
        assert!(
            message.contains("exception handler 0 entry target 1 is outside 0..1"),
            "{message}"
        );
    }

    #[test]
    fn protected_range_endpoints_must_be_instruction_starts() {
        // `bipush 5` at BCI 0 (its operand is BCI 1), `return` at BCI 2.
        let code = [0x10, 0x05, 0xb1];

        // A range start inside an operand.
        let (error_code, message) = target_error(&code, &[(1, 3, 2, 0)]);
        assert_eq!(error_code, "classfile_instruction_invalid_target");
        assert!(
            message.contains(
                "exception handler 0 protected range start 1 is not an instruction start"
            ),
            "{message}"
        );

        // A range end inside an operand.
        let (error_code, message) = target_error(&code, &[(0, 1, 2, 0)]);
        assert_eq!(error_code, "classfile_instruction_invalid_target");
        assert!(
            message.contains(
                "protected range end 1 is neither an instruction start nor code_length 3"
            ),
            "{message}"
        );

        // An aligned range keeps validating, including the legal half-open end.
        let facts = operand_facts(&operand_fixture(&code, &[(0, 3, 2, 0)]));
        assert_eq!(
            facts.control_flow_targets().unwrap(),
            vec![ControlFlowTarget {
                instruction_bci: 2,
                kind: ControlFlowTargetKind::Handler { ordinal: 0 },
                target_bci: 2,
            }]
        );
    }

    #[test]
    fn protected_ranges_must_not_be_empty() {
        let code = [0x10, 0x05, 0xb1];

        // An empty range on an instruction start: JVMS 4.7.3 wants `start < end`.
        let (error_code, message) = target_error(&code, &[(2, 2, 2, 0)]);
        assert_eq!(error_code, "classfile_exception_range_invalid");
        assert!(
            message.contains("exception handler 0 protected range at BCI 2 is empty"),
            "{message}"
        );

        // An empty range inside an operand stays a range error: the relation is checked
        // before the endpoints, so the two failure kinds stay distinguishable.
        let (error_code, message) = target_error(&code, &[(1, 1, 2, 0)]);
        assert_eq!(error_code, "classfile_exception_range_invalid");
        assert!(message.contains("is empty"), "{message}");

        // An inverted range keeps its own message.
        let (error_code, message) = target_error(&code, &[(2, 1, 2, 0)]);
        assert_eq!(error_code, "classfile_exception_range_invalid");
        assert!(
            message.contains("protected range 2..1 starts after its end"),
            "{message}"
        );
    }

    /// Every class fixture in the repository still validates: the tightened handler
    /// rules must not reject real code, and real historical subroutines must go through
    /// the same target checks.
    ///
    /// The counts are the measured population — 50 classes, 236 bodies, 44 exception table
    /// records, 125 branch/switch targets, 8 `jsr`/`jsr_w` instructions (the ECJ 4.6.1 45–48
    /// `finally` codegen; neither the P3 samples nor the P4 modern samples contain a
    /// subroutine) — so a fixture that silently stops being visited, or a body that stops
    /// decoding, fails here instead of quietly shrinking the sweep. The P4 modern samples raise
    /// the first two counts by their own files and bodies and leave the last three where they
    /// were, which is also how the sweep states that a javac 23.0.1 class at major 60 or 61 is
    /// read by the same structural path as every earlier fixture. The 2026-09 P3 eval-context
    /// samples rise the first two the same way (`p3-nested-eval/v8/NestedEval.class` adds five
    /// bodies and `p3-refused-cast/v8`'s four classes add ten, none of them with an exception
    /// table, a branch or a subroutine), and the one count the P3 samples do
    /// not move is the last: `p3-local-rewrite`, `p3-scope`, `p3-handlers` and `p3-corpus` are
    /// javac 23.0.1 output, which has no subroutines at all, so every `jsr` in the sweep is the ECJ
    /// corpus's.
    ///
    /// The `p3-declaration` sample raises the first two by its own two classes and six bodies and
    /// leaves the last three exactly where they were: `Shape` declares an `abstract` member with no
    /// `Code` at all (which is a declaration, not a body), a `default` method and a `static` one, and
    /// `Holder` a constructor, an instance method, a static method and a `<clinit>` — bodies javac
    /// 23.0.1 compiles straight-line, with no exception table, no branch and, like every other P3
    /// sample, no subroutine.
    ///
    /// The `p3-nested-arithmetic` sample adds its own class and nine bodies (eight `static`
    /// methods and the default constructor) and moves neither of the last three: every body is
    /// straight-line arithmetic over parameters and one local, which javac compiles without a
    /// branch or a handler.
    ///
    /// The `p3-receiver-grouping` sample does the same with its own class and nine bodies (eight
    /// `static` methods and the explicit constructor): every body is straight-line string
    /// concatenation and one call, so the last three counts stay where they are.
    ///
    /// The `p3-int-comparisons` sample adds its own class and ten bodies (nine `static` methods and
    /// the default constructor) and raises the branch/switch targets by eight: the six comparisons
    /// and the two boolean controls each branch once, every one of them with an `int`-shaped operand
    /// and no exception table, so the first, second and fourth counts move together and the handler
    /// and subroutine counts stay where they are.
    ///
    /// The `p3-hoisted-boolean` sample adds its own class and nine bodies (eight `static` methods and
    /// the default constructor) and raises the branch/switch targets by twenty: eight of its members
    /// are `if`/`else` shapes over boolean locals, each of them a test plus the `goto` that joins the
    /// arms, and four of those test the local again after the join. One member (`copied`'s twin
    /// `swapped`) differs from another only in which arm runs first. No body declares an exception
    /// table and, like every other P3 sample, none is a subroutine, so the third and fifth counts stay
    /// where they are.
    ///
    /// The `p3-concat-conversion` sample adds its own class and fourteen bodies (thirteen `static`
    /// methods and the default constructor) and moves neither of the last three: every one of its
    /// members is a straight-line `StringBuilder` chain or a one-line helper, so no body declares an
    /// exception table, branches, or — like every other P3 sample — a subroutine.
    ///
    /// The `p3-parameter-slots` sample adds its own class and ten bodies (nine methods and the
    /// explicit constructor) and moves neither of the last three: every body is one local load
    /// (or, for the constructor, one field write) and its return, so no body declares an exception
    /// table, branches, or a subroutine.
    ///
    /// The `p3-required-conversions` sample adds its own class and thirteen bodies (twelve `static`
    /// methods and the default constructor) and moves neither of the last three: every member is one
    /// `StringBuilder` chain, one load-and-return, or one store, so no body declares an exception
    /// table, branches, or — like every other P3 sample — a subroutine. The increment is the whole
    /// of this sample's contribution: it is a class javac 23.0.1 compiled for Java 8 like the rest,
    /// read by the same structural path.
    ///
    /// The `p3-one-armed-if` sample adds its own class and four bodies (three `static` methods and
    /// the default constructor) and raises the branch/switch targets by five: `oneArmed` branches
    /// once and falls through into its join, so its arm needs no `goto`, while `elseOnly` and
    /// `bothArms` each branch once and `goto` over the arm the branch did not take. No body declares
    /// an exception table or — like every other P3 sample — a subroutine, so the third and fifth
    /// counts stay where they are.
    ///
    /// The `p3-typed-catch` sample adds its own class and five bodies (four `static` methods and the
    /// default constructor), moves the branch/switch targets by six and — the first P3 sample to do
    /// so — declares **six** exception-table records: `namedCatch`'s one row
    /// (`[0,13) → 14 IllegalArgumentException`), `twoCatches`' two (`[0,27)` to 28 and 31) and
    /// `multiCatch`'s two (`[0,27)` to 28 twice, the multi-catch the compiler writes as one row per
    /// class), each with the `ifge`/`if_icmple` its `if`s compile to, and `finallyIncrements`' one
    /// `any` row (`[2,4) → 11`) with the `goto` that jumps over the copy the compiler made. The
    /// subroutine count stays where it is: like every other P3 sample, javac 23.0.1 emits none.
    ///
    /// The `p3-typed-catch` sample's sixth member (`initialisedBeforeTry`, two assignments before a
    /// `try`) moves one of each of the three middle counts and nothing else: one body, one
    /// exception-table record (`[4,17) → 18 IllegalArgumentException`) and one branch target (the
    /// `ifge` its `if` compiles to, against the `return` of the arm the branch transfers to). So the
    /// sample moves the sweep's own counts to 269 bodies, 51 records and 137 branch/switch targets,
    /// and leaves the class and subroutine counts where they were.
    ///
    /// The `p3-chained-store` sample adds its own class and three bodies (`chain`, `fill3` and the
    /// default constructor) and moves neither of the last three: `chain` is a load, a copy and two
    /// stores with an add, and `fill3` an array initializer with three stores into the array — and
    /// no instruction of either is a branch, so no body declares an exception table, branches, or a
    /// subroutine. So the sample moves the class count to 55 and the body count to 272, and leaves
    /// the three structural counts where they were.
    ///
    /// The `p3-forward-join` sample adds one class and four bodies (`both`, `either`, `again` and
    /// the default constructor). None of them has an exception table or a subroutine. `both` and
    /// `either` are two forward branches each, and `again` is one branch plus the `goto` back to
    /// the header, so the branch/switch target count moves by six: 56 classes, 276 bodies, 143
    /// branch targets.
    ///
    /// Seven samples already on disk are counted once, together. `p3-concat-char` (`Letters`) is one
    /// class and three straight-line bodies. `p3-mutf8` (`Controls`) is one class and two bodies,
    /// and neither branches. `p3-field-increment` (`Bump`) is one class and three bodies (`post`,
    /// `pre` and the constructor); neither update is a branch. `p3-nested-try` (`Nest`) is one class
    /// and two bodies, two exception-table records, and two `goto`s. `p3-char-switch` (`Letters`)
    /// is one class and three bodies; `letter`'s `lookupswitch` names two keys and a default, and
    /// `number`'s names one key and a default. `p3-static-call` (`Calls`) is one class and four
    /// bodies (`own`, `boxed`, `local` and the constructor); none of them branches or declares an
    /// exception table. `p3-sync-return` (`Locked`) is one class and two bodies (the constructor and
    /// `locked`); `locked`'s monitor states two exception-table records and no branch. The historical
    /// paragraph above ended at 63 classes, 295 bodies, 55 handler records and 150 branch/switch
    /// targets. The committed population has since grown to 81 classes before the current additions.
    /// `p3-unary-negation` adds `UnaryNegation`, while `p3-special-dispatch` adds `BaseProbe`,
    /// `DefaultProbe` and `SpecialProbe`; its `SpecialRunner` remains source-only. The later
    /// `p3-reference-cast` fixture adds `ReferenceCastProbe`; numeric-comparison and invocation-
    /// arguments each add one class, with 35 and 14 bodies respectively. The repository sweep now
    /// measured 88 classes, 480 bodies, 74 handler records and 227 branch/switch targets. The
    /// `p3-throw`, `p3-final-static` and `p3-instanceof` fixtures add one class each, with 9, 5 and
    /// 15 bodies respectively; their runners and boundary variants remain source-only. The current
    /// sweep measured 91 classes, 509 bodies, 75 handler records and 231 branch/switch targets.
    /// Bitwise, deferred-value-order and floating-constant fixtures add three classes, 70 bodies
    /// and five branch targets, reaching 94 classes and 579 bodies. Lambda adaptation, type
    /// qualifiers, primitive conversions and narrow returns add four classes, 60 bodies and six
    /// monitor handler records. Partial array allocation and B/C/S field-store fixtures add two
    /// classes and 29 bodies. The current sweep measures 100 classes, 668 bodies, 81 handler
    /// records and 236 branch/switch targets, with the same eight historical subroutines. Four
    /// frozen Class-literal/type-name classes add 15 bodies without new handlers or targets:
    /// the current census is 104 classes and 683 bodies. The verifier-valid boolean-field-store
    /// fixture adds one class with 11 bodies and no new handlers or branch targets, reaching 105
    /// classes and 694 bodies. Six null-resource fixtures add 32 bodies, 13 handler records and
    /// 25 branch targets; that census was 111 classes, 726 bodies, 94 handler records and
    /// 261 branch targets. The permanent compound-lvalue fixture adds two source classes and their
    /// helpers/runners plus five verifier-valid patched boundary classes; the popped-static-
    /// qualifier fixture adds one class. Together these 12 classes add 170 bodies, four handler
    /// records and 79 branch/switch targets. The current census is 123 classes, 896 bodies,
    /// 98 handler records and 340 branch/switch targets.
    ///
    /// The 2026-09 syntax-recovery expansion re-measured the sweep over the corpus as committed:
    /// 316 classes, 1,674 bodies, 153 handler records, 902 branch/switch targets and the same
    /// eight subroutines — every `jsr`/`jsr_w` is still the ECJ corpus's, and no expansion
    /// fixture carries one. Relative to the 310/1,645/144/880 census frozen in `54e432ed`,
    /// `p3-conditional-values/field-writes` adds `ConditionalFieldWrites.class` and
    /// `ConditionalFieldWritesNon01.class` (five bodies and six branch targets each);
    /// `p3-precise-rethrow/v8` adds `PreciseRethrowProbe`
    /// (four bodies, one handler, two targets), `PreciseRethrowRunner` (three, one, one),
    /// `PreciseRethrowBoundaryProbe` (seven, four, four) and `PreciseRethrowBoundaryRunner`
    /// (five, three, three). Those six classes add the measured 29 bodies, nine handlers and 22
    /// branch targets. Their source commits are `965d8cf5` and `54c02b9a` respectively. The other
    /// families the expansion added measure: `proved-java-structure`
    /// 31 classes / 83 bodies / one handler record / 27 branch targets,
    /// `p3-carried-conditional-arguments` 7 / 25 / 0 / 32, `p3-typed-catch-boundary-return`
    /// 2 / 10 / 8 / 6, `recover-generic-enclosing-member-call-sites` 8 / 14 / 0 / 0 and
    /// `p3-nested-array-initializers` 4 / 12 / 0 / 1; inside the families this ledger already
    /// names, the conditional-values short-circuit matrix contributes 32 classes / 130 bodies /
    /// seven handler records / 182 branch targets and the compound-lvalue boundary classes
    /// 17 classes / 306 bodies / four handler records / 84 branch targets, with the rest of the
    /// growth spread over the remaining one-class probes. Every fixture directory the expansion
    /// brought in is named by a test or an OpenSpec record, and `corpus-fingerprint.json` was
    /// re-rendered for it.
    ///
    /// Since the census recorded in `9a0c2a11`, 14 permanent classes were added across the
    /// conditional-value, loop/transfer, intermediate-join, short-circuit-return and resource-tail
    /// fixtures. Each has Java source or a documented generated verifier-valid control and
    /// test/OpenSpec provenance. Four were already in the corpus fingerprint; the other ten are
    /// added there by this census update. They contribute 56 Code bodies, seven handlers and 98
    /// branch/switch targets. The measured census is now 330 classes, 1,730 bodies, 160 handler
    /// records, 1,000 branch/switch targets and the same eight subroutines.
    ///
    /// After that measurement, seven `proved-java-structure` families added 20 classes and 55
    /// bodies: `anonymous-inner-this` (2/5), `anonymous-interface-basic` (3/5), `package-info-basic`
    /// (2/2), `enum-arity` (4/17), `anonymous-super-args` (3/10, one target),
    /// `anonymous-super-direct` (3/9, two targets), and `static-member-basic` (3/7). Their frozen
    /// inputs and tests were added in `bf5d7282`/`62b7d9dc`, `cb53a197`, `3f5a1b3a`, `dca84d10`,
    /// `a7183f87`, `4da6a212`, and `36b57495` respectively. `proved-varargs-calls` adds one class,
    /// 19 bodies and one target (`863a40f3`). The later DT-22 nested-annotation fixture adds three
    /// classes and one body (`85117144`). These measured additions bring the census to 354 classes,
    /// 1,805 bodies, 160 handlers, 1,004 branch/switch targets and the same eight subroutines; the
    /// earlier 351/1,804 measurement predates DT-22's three classes and one body. EM-27's two
    /// `em27-inline-string` class files add 12 bodies and no handlers, branch/switch targets or
    /// subroutines, bringing the census to 356 classes and 1,817 bodies. Subsequent committed
    /// fixtures were re-measured at 431 classes, 2,079 bodies, 245 handlers and 1,633
    /// branch/switch targets; the eight historical subroutines remain unchanged.
    ///
    /// The 2026-10-05 recover-lambda-primitive-array-capture fixtures add the frozen dual legs of
    /// the DT-26 lambda array-capture anchor: `v8/P02_lambda.class` (real javac 8, six bodies) and
    /// `v23/P02_lambda.class` (`javac --release 8`, six bodies), plus the `int[][]` control of the
    /// same probe in both legs (`P02_multianewarray.class`, four bodies each). All eight members are
    /// straight-line or `invokedynamic` bodies with no branch and no handler, so the four classes
    /// add twenty Code bodies and nothing else. The measured census is 585 classes, 2,589 bodies,
    /// 252 handler records, 1,763 branch/switch targets and the same eight subroutines.
    ///
    /// The ledger below records every family added since, with the bodies and targets it moved.
    /// The historical census reached **828 classes, 3,596 bodies, 290 handler records, 2,211
    /// branch/switch targets and the same eight subroutines**; the last entry —
    /// `recover-postfix-condition-positions`, three classes on both compiler legs — is the one that
    /// reached it.
    /// Later additions continue in the assertion's ledger below, which pins the current totals.
    #[test]
    fn repository_class_fixtures_validate_without_false_target_rejections() {
        let fixtures = class_fixture_paths();
        let mut bodies = 0u32;
        let mut handler_records = 0u32;
        let mut branch_targets = 0u32;
        let mut subroutines = 0u32;
        for path in &fixtures {
            let bytes = std::fs::read(path).unwrap();
            let mut budget = Budget::new(limits(u64::MAX));
            let header = class_facts(&bytes, &mut budget)
                .unwrap_or_else(|error| panic!("{}: {error:?}", path.display()));
            // The member walk (the member listing's own read) states the same declaration, the same
            // fields and the same methods as the whole-structure read on every committed class, and
            // finds nothing to stop for. A repository fixture is a *readable* class, so the two
            // reads agreeing here is what makes the tolerant walk's prefix trustworthy on the
            // damaged inputs the listing tests build by hand.
            let walked = class_member_facts(&bytes, &mut budget)
                .unwrap_or_else(|error| panic!("{}: {error:?}", path.display()));
            assert_eq!(walked.stopped_at, None, "{}", path.display());
            assert_eq!(
                walked.access_flags,
                header.access_flags,
                "{}",
                path.display()
            );
            assert_eq!(walked.this_class, header.this_class, "{}", path.display());
            assert_eq!(walked.super_class, header.super_class, "{}", path.display());
            assert_eq!(walked.interfaces, header.interfaces, "{}", path.display());
            assert_eq!(walked.fields, header.fields, "{}", path.display());
            assert_eq!(walked.methods, header.methods, "{}", path.display());
            for method in &header.methods {
                let facts = match method_code_facts(&bytes, method, &mut budget) {
                    Ok(facts) => facts,
                    Err(Error::Unsupported { code, .. })
                        if code == "classfile_method_has_no_code" =>
                    {
                        continue;
                    }
                    Err(error) => panic!("{}: {error:?}", path.display()),
                };
                assert!(
                    matches!(facts.execution, ExecutionReport::Complete { .. }),
                    "{}: a fixture body must decode completely",
                    path.display()
                );
                let targets = facts
                    .control_flow_targets()
                    .unwrap_or_else(|error| panic!("{}: {error:?}", path.display()));
                bodies += 1;
                handler_records += facts.exception_handlers.len() as u32;
                branch_targets += targets
                    .iter()
                    .filter(|target| !matches!(target.kind, ControlFlowTargetKind::Handler { .. }))
                    .count() as u32;
                for fact in &facts.instructions {
                    if matches!(fact.opcode, 0xa8 | 0xc9) {
                        subroutines += 1;
                        assert!(
                            targets.iter().any(|target| {
                                target.instruction_bci == fact.bci
                                    && matches!(target.kind, ControlFlowTargetKind::Branch { .. })
                            }),
                            "{}: the subroutine at BCI {} lost its branch target",
                            path.display(),
                            fact.bci
                        );
                    }
                }
            }
        }
        assert_eq!(
            (
                fixtures.len(),
                bodies,
                handler_records,
                branch_targets,
                subroutines
            ),
            // The 2026-09-28 fixture additions moved the measured sweep; see the closing paragraph
            // of this test's documentation and the fixture index for the current corpus totals.
            // The 2026-10-01 caught-value typing fixture (one TWR class, seven bodies) moved it again.
            // The 2026-10-01 array-slot-retype fixtures (the patrol's A1/A2 plus four boundary
            // variants, twenty-three bodies) moved it again.
            // The 2026-10-01 scv-concat-consumers fixtures (two classes, nine bodies, the
            // concatenation-consumed short-circuit locals) moved it again.
            // The 2026-10-02 qualified-super-default fixtures (the nested diamond/single family
            // and the packaged qualifier, twelve classes, twenty-one bodies) moved it again.
            // The 2026-10-03 assert-sugar negatives (the hand-patched guard-extra-statement and
            // wrong-owner probes, two classes, twelve bodies) moved it again.
            // The 2026-10-04 bridge-admission-gates fixtures (the frozen BR patrol family six,
            // the BR2 multilevel covariant variant four, and the provided-Comparable stand-in,
            // eleven classes, twenty-one bodies) moved it again.
            // The 2026-10-04 bridge-superclass-precondition fixtures (the frozen misdispatch
            // family seven: the nested `Outer$Box`/`Spec`/`Drv` trio, the top-level
            // `Box`/`Specialized`/`Drv` control trio, and the second driver, twenty-one bodies)
            // moved it again.
            // The 2026-10-04 anonymous-super-mixed-direct fixture (the mixed super-argument and
            // capture-value anchor, three classes, twelve bodies) and the mixed-refusals
            // fixtures (two source families: two capture fields and two mixed sites, seven
            // classes, sixteen bodies) moved it again.
            // The 2026-10-04 recover-anonymous-local-decl-site fixtures (the declaration-site
            // anchor's `-g` control leg three, the interface-hold containment two, and the five
            // refusal families twenty-one, twenty-six classes) moved it again.
            // The 2026-10-04 recover-anonymous-parameterized-root fixtures (the `-g:none`
            // control leg three, and the five refusal families sixteen — the supertype-return
            // family freezes its `Renderer` interface beside `Base`, nineteen classes,
            // thirty-six bodies) moved it again.
            // The 2026-10-04 enum-string-field-name fixture (the non-`op` control probe for the
            // DT-12 String-argument slice, five classes: the enum, its two anonymous bodies, the
            // interface, and the behavior probe, thirteen bodies) moved it again.
            // The 2026-10-04 recover-anonymous-supertype-return fixtures (the refusal families
            // `indirect-supertype-return` and `nested-supertype-return` ten and the interface
            // census containment probe three, thirteen classes, twenty-two bodies) moved it
            // again.
            // The 2026-10-04 recover-javac8-getclass-null-check-idiom fixtures (the real-javac8
            // getClass-leg anchors: the `N1x` parameter-qualifier family three, the `Wrap`
            // local-variable qualifier two, and the explicit-statement negative `G` two, seven
            // classes, nineteen bodies) moved it again.
            // The 2026-10-04 shared-latch-nested-loops fixtures (the patrol anchors `S5` six
            // bodies and `S3` five bodies byte-identical to their patrol records, plus the
            // slice's `ThreeLevel`/`ExitDiverges`/`LabeledBreakOuter`/`Overlap` three bodies
            // each, six classes, twenty-three bodies) moved it again.
            // The 2026-10-04 recover-javac8-allocation-qualifier-null-check fixtures (the real
            // javac 8 allocation-qualifier anchors: the `N1` family three, the no-argument
            // control `Pod` two, the statement-preservation companion `D2` two, the
            // discarded-construction negative `D3` two, and the kept-result byte-patched probe
            // `E1` two, eleven classes, thirty bodies) moved it again.
            // The 2026-10-05 recover-write-accessor-field-types fixtures (the real javac 8
            // write-accessor anchors: the byte-identical `wa` pair, the `st` table control
            // pair, the eight byte-patched `probes` negatives — twelve classes, one hundred
            // sixteen bodies, one jar; the `wb` dual leg is source-only and compiles in-test)
            // moved it again.
            // The 2026-10-06 preserve-monitor-exit-evaluation-order fixtures (the sync-return
            // patrol's `NL`/`SR` sources on both compiler legs: `NL`, its `NL$Box` companion and
            // `SR`, six classes, twenty-six bodies) moved it again.
            // The 2026-10-06 recover-array-element-field-receiver fixtures (the patrol's own
            // `RG`…`RO` shapes plus the `RJ`/`EM`/`RP` controls, ten families on both compiler
            // legs: forty classes, one hundred twenty-three bodies) moved it again.
            // The 2026-10-06 recover-platform-interface-argument-widening fixtures (the two
            // patrols' `CP`/`AH`/`AC`/`AN` shapes plus this change's `AW` boundary and `IS`
            // isolated anchor, seventeen classes on both compiler legs: thirty-four classes, one
            // hundred bodies) moved it again.
            // The 2026-10-06 platform implementer table fixtures (the charsequence change's
            // `CS`/`CSX`, the comparable change's `CO`/`CO$Node`/`CO$IntNode`/`COX`, and the enum
            // change's `EN`/`ENN`/`ENN$Flag`/`ENT`/`ENX`, eleven classes on both compiler legs:
            // twenty-two classes, ninety-four bodies) moved it again.
            // The 2026-10-06 recover-unicode-identifiers fixtures (the real javac 8 anchor `UT`
            // with its `UT$内部类` companion, plus the `Loc` local-name pair: `Loc` and its
            // byte-patched `Loc.punct`, four classes, eleven bodies) moved it again.
            // The 2026-10-06 recover-temporal-argument-widening fixtures (the java-time-temporal
            // patrol's `JT`/`DT` and the completable-future patrol's `CF`, plus this change's
            // `TWX` negative, four classes on both compiler legs: eight classes, forty-six bodies)
            // moved it again.
            // The 2026-10-06 recover-parameterized-interface-headers fixtures (the interface
            // leg's `IfaceImpl`/`MultiIface`/`ErasedCall`/`Unresolved`/`Arity`/`ArityApi`/
            // `TypeUse`/`Mark` and the parent leg's `NB` family, `NestedExtends`, `BareBox`,
            // `NB$Twin`, `ArityExtends`, `MO`/`MO$Mid`/`Multiseg`, eighteen classes on both
            // compiler legs: thirty-six classes, seventy-two bodies) moved it again.
            // The 2026-10-06 recover-proved-nonnull-bound-receivers fixtures (the Optional patrol's
            // `OP` and this change's `BRN` with its three negatives, two classes on both compiler
            // legs: four classes, twenty-two bodies, two handler records and six branch targets —
            // `OP`'s `len` `ifeq` and its inlined `lambda$name$0` `ifne`/`goto` per leg)
            // moved it again.
            // The 2026-10-06 recover-loop-else-if-early-returns fixtures (the binary-search
            // patrol's `BS`/`CB`/`CB2` anchors, controls and exit-consuming twin, this change's
            // all-recovering anchor `LR2` and its `LB` negatives, five classes on both compiler
            // legs: ten classes, fifty-six bodies, two handler records — `LB.tryLadder`'s catch,
            // one per leg — and one hundred seventy-two branch targets) moved it again.
            // The 2026-10-06 recover-static-generic-field-init-text fixtures (the patrol's `MN`
            // and `RG` families plus this change's `SG` anchor and `P1` non-generic control, four
            // classes on both compiler legs: sixteen classes, forty bodies, four branch targets —
            // `RG.pick`'s `iflt`/`goto` pair per leg) moved it again.
            // The 2026-10-06 recover-postfix-old-value-snapshot fixtures (the postfix old-value
            // consumer positions: the patrols' own `CM`/`CM2`/`AD`/`GA` reused byte-identically,
            // plus this change's `PT` static-ternary arm, `SR` store right side, `IX` index
            // positions and `NG` negatives, eight classes on both compiler legs: eighteen classes,
            // ninety-six bodies, fourteen branch targets — `NG.condShape`'s loop `ifne`/`goto`
            // pair and `NG.compoundSelf`'s comparison pair per leg) moved it again.
            // The 2026-10-06 recover-dup-store-conditional fixtures (the dup-store dance's own
            // targets: `DS` int form, `REF` reference form and `NEG` the two refusals, three
            // classes on both compiler legs — six classes, thirty-six bodies, thirty-eight branch
            // targets: the dance's `ifle`/`goto` pair and `ifnull`/`goto` pair per leg, plus
            // `deadChain`'s two tests, `split`'s comparison, `splitLocal`'s comparison and
            // `NEG.shortChain`'s two tests) moved it again.
            // The 2026-10-07 recover-inline-conditional-concat-operands fixtures (the inline
            // conditional value as a `+` chain operand: the anchors `ICC` with its `ICC$Inner`
            // companion, `ICB` and `ICQ`, the no-branch control `ICM` and the four negatives
            // `ICN`, six classes on both compiler legs — twelve classes, fifty-two bodies, two
            // handler records — `ICN.guarded`'s `RuntimeException` catch, one per leg — and
            // thirty-four branch targets: the cut's `if_acmpne`/`goto` pair in `ICC`, `ICB`, `ICQ`
            // and `ICN.guarded`, `armCall`'s and `armStore`'s `ifeq`/`goto` pair, `nested`'s two
            // comparison pairs, and the catch's own `goto` per leg) moved it again.
            // The 2026-10-07 recover-chained-field-assignment fixtures (the copy family's third
            // shape: `CF` with the three-store chain, the two-store chain, the saved form, the
            // single-store and local-chain controls, the receiver copy of `|=`/`&=`, the `String`
            // `+=` receiver copy and the static control, and `NEG` with the four refusals, two
            // classes on both compiler legs — four classes, forty-two bodies) moved it again.
            // The 2026-10-07 recover-conditional-rhs-field-compound fixtures (the field compound
            // whose right-hand side is one proved conditional materialisation: `BI`, the patrol's
            // frozen anchor recompiled, `RC` with the loop anchor, the same statement with no loop
            // around it, the `|=` operator and the integral field, and `RCN` with the three
            // refusals — a calling arm, two materialisations in one right-hand side and one under
            // an exception table — three classes on both compiler legs: six classes, forty bodies,
            // two handler records — `RCN.inTry`'s `RuntimeException` catch, one per leg — and
            // fifty branch targets: `BI.earlyRet`'s five, `RC`'s eleven (the loop's five, and
            // `plain`'s, `orEq`'s and `mask`'s two each) and `RCN`'s nine (`armCall`'s two,
            // `inTry`'s three and `nested`'s four), per leg) moved it again.
            // The 2026-10-07 recover-array-initializer-value-positions fixtures (the initialization
            // dance's value at the consumption positions the six-position discriminator found
            // refusing: the patrol's own `MD` — the sawtooth field, the regular and partial
            // creations, the element-store anchor and the sawtooth literal — `MD2` — the local,
            // field, argument and immediate-subscript positions — `MD3` — the bare length, the
            // immediate-subscript anchor and the bare return — this change's `AV`, the same
            // positions one step further, and `AVT`, the same two positions with every other
            // element type, five classes on both compiler legs — ten classes, one hundred sixteen
            // bodies, sixteen branch targets: `MD.sumJag`'s two loops and `AV`'s `foreach` loop and
            // `condIdx` comparison, per leg — plus the hand-built `AVN` (three members, no branch),
            // eleven classes and one hundred nineteen bodies in all, and no handler record or
            // subroutine) moved it again.
            // The 2026-10-07 recover-postfix-condition-positions fixtures (the postfix old-value
            // condition positions: the patrol's own `CP7` trio reused byte-identically — the
            // do-while scan, the while compound and the if short-circuit — plus this change's `CN`
            // (the two negatives: a second variable's position in one condition and the middle of
            // a short-circuit chain, with the compound-chain control) and `CC` (the three
            // positions again, each answering the count its increment reached), three classes on
            // both compiler legs: six classes, thirty-two bodies, no handler record, and fifty
            // branch targets — seven in `CP7` (the scan's `ifeq`/`if_icmplt`, the find's
            // `if_icmpge`/`if_icmpeq`/`goto` and the cond's `ifle`/`if_icmpge`), nine in `CN` (the
            // two negatives' four `ifeq`s and two `goto`s, the chain's `ifle`/`ifgt`) and nine in
            // `CC` (the three positions' six and the find's `goto`, the chain's `ifle`/`ifgt`),
            // per leg) moved it again.
            // The 2026-10-07 recover-boolean-int-bitwise-operands fixtures (the int-ified boolean
            // operand of a bitwise expression: the patrol's own frozen `BW` — `mix`'s accumulate
            // counter and `andNot`'s materialised `!b` beside the healthy same-type shapes —
            // recompiled as the two legs' `BW`, this change's `BWR` with the four admitted shapes
            // (`accXor`, `andNotAnd`, `orNot`, `notOr`) and `BWN` with the five refusals
            // (`plusOne`, `andNotInt`, `compareRead`, `intSibling`, `passed`), three classes on
            // both compiler legs — six classes, forty-four bodies — plus the frozen `patrol-BW`
            // copy, seven classes and fifty-three bodies in all, no handler record or subroutine,
            // and sixty-two branch targets: `BW`'s six (`mix`'s `if_icmpge`/`goto`, `andNot`'s
            // `ifne`/`goto` and `bits`'s `ifeq`/`goto`), `BWR`'s eight (`accXor`'s, `andNotAnd`'s,
            // `orNot`'s and `notOr`'s pairs), `BWN`'s fourteen (`plusOne`'s and `intSibling`'s and
            // `passed`'s pairs, `andNotInt`'s four — the materialisation's and the ternary's — and
            // `compareRead`'s four — the loop's and the comparison's), and the frozen copy's six,
            // per leg) moved it again.
            // The 2026-10-07 recover-statement-position-news fixtures (the statement position of a
            // construction: `SP` with the five recovering shapes — `argless`, `withArg`, `fromArg`,
            // `nestedArgument` and `mixed` — beside its consumed controls, its `SP$Inner` static
            // nested companion, `SB` (the patrol's `B6` shapes without the registered `chained`
            // boundary) and `SPN` with the four refusals (`callArgument`, `fieldArgument`,
            // `arithmeticArgument`, `chained`) on both compiler legs — eight classes, fifty-two
            // bodies — plus the hand-built `SPC`, the statement-position twin of the frozen
            // counterexample, nine classes and fifty-three bodies in all, no handler record, no
            // branch target and no subroutine) moved it again.
            // The 2026-10-07 recover-capture-ctor-super-order fixtures (the double-brace capture
            // pair on both compiler legs — `DB`, its `DB$1` no-capture companion and its `DB$2`
            // capture companion, six classes, fourteen bodies — plus the two hand-made
            // super-argument probes, `ReadArg`'s family and `CallArg`'s family with its helper,
            // seven classes, seven bodies: thirteen classes, twenty-one bodies, no handler record,
            // no branch target and no subroutine) moved it again.
            // The 2026-10-07 recover-boxed-number-widening fixtures (the patrol's own `C8` — its
            // boxed ternary, its loop-carried builder with the `break`, and the `larger(3, 7)`
            // call site — beside `BN` with the six boxed argument positions and `BNX` with the two
            // out-of-row refusals, three classes on both compiler legs: six classes, thirty-four
            // bodies — seventeen per leg — eighteen branch targets per leg (`C8`'s ten: the
            // ternary pair, the loop pair, the `break` pair and the loop's back edge; `BN`'s four
            // and `BNX`'s four: the two ternary bodies each), no handler record and no subroutine)
            // moved it again.
            // The 2026-10-07 preserve-local-scope-plan fixtures (the declaration plan's three
            // answers, tasks 1.2/1.3 of that change: `ScopePlan` — the catch-only local, the
            // `try`/`catch` join, the `if` join and the two nested-`try` joins — and
            // `ScopePlanCrossing` with the two crossing refusals, two classes on both compiler
            // legs: four classes, twenty bodies — ten per leg, seven in `ScopePlan` and three in
            // `ScopePlanCrossing` — twenty-two handler records (`ScopePlan`'s six: `catchOnly`,
            // `assignedAcrossTry`, `nestedHandlerOnly`'s two and `nestedAcross`'s two;
            // `ScopePlanCrossing`'s five: `flatFinally`'s three and `resourceAcrossFinally`'s two:
            // eleven per leg) and twenty-four branch targets (twelve per leg: `catchOnly`'s,
            // `assignedAcrossTry`'s, `assignedAcrossIf`'s and `nestedHandlerOnly`'s `if` pairs,
            // `nestedAcross`'s two nested pairs, `main`'s four `print` statements' pairs and
            // `flatFinally`'s pair), no subroutine) moved it again.
            // The 2026-10-07 recover-lock-guard-loop-finally fixtures (the explicit-lock patrol's
            // `LK` recompiled on both compiler legs, the four negative shapes beside it and the
            // io-wrapping resource-across-finally probe: three classes on both legs — six classes,
            // twenty-four bodies — `LK`'s five per leg, `LockGuardNegatives`'s five and
            // `LockGuardProbe`'s two — twenty handler records (`LK`'s three: the two guards and the
            // `tryLock` guard; `LockGuardNegatives`'s five: one each for `lockMismatch`,
            // `localLockRewritten` and `throwingRelease` and two for `guardedRelease`, the release
            // javac protects; the probe's two: the protected range and its self-protection row;
            // ten per leg) and twenty-six branch targets (thirteen per leg: `LK`'s six — `put`'s
            // `if_icmplt` and its two `goto`s, `take`'s `ifgt` and `goto`, and `tryLockQuick`'s
            // `ifeq` — `LockGuardNegatives`'s five — `lockMismatch`'s, `localLockRewritten`'s and
            // `throwingRelease`'s `goto`s and `guardedRelease`'s `ifnull`/`goto` pair — and the
            // probe's `ifnull`/`goto` pair), no subroutine) moved it again.
            // The 2026-10-07 recover-short-circuit-local-branch-reads fixtures (the branch
            // condition position of a proved short-circuit boolean local: `BranchReads` with the
            // ternary, the `if` statement and the mid-chain read, `BranchReadNegatives` with the
            // loop condition and the catch-crossing boundaries, and the two hand-patched opcode
            // controls `NumericBranch`/`NotZeroBranch` — three classes on both compiler legs: six
            // classes, twenty-eight bodies — two handler records (`crossCatch`'s
            // `NullPointerException` catch, one per leg) and eighty-six branch targets (forty-three
            // per leg: `BranchReads`' and the controls' sixteen each — `ternaryRead`'s five (the
            // chain's two `ifle` and its `goto`, the condition's `ifeq` and the arms' `goto`),
            // `ifStatement`'s four (the same chain and `ifeq`, both arms returning) and
            // `midChain`'s seven (the first chain's three and the second chain's
            // `ifle`/`ifeq`/`if_icmpge`/`goto`) — and `BranchReadNegatives`' eleven:
            // `loopCondition`'s six (the chain's three and the loop's `ifeq`/`if_icmple`/`goto`)
            // and `crossCatch`'s five (the chain's three and the ternary's `ifeq`/`goto`)), no
            // subroutine) moved it again.
            // The 2026-10-07 recover-double-brace-allocation-site fixtures (the double-brace
            // allocation point's control and three negatives: the single-use control `DBS` with
            // its `DBS$1` companion, `DBM` with a companion that declares a method, `DBN` with its
            // `Carrier$Nested` unspellable superclass and `Carrier`, and `DBS2` — whose host is
            // **hand-made bytecode**, two methods each allocating the compiled `DBS2$1` once — five
            // classes on both compiler legs: ten classes, thirty-eight bodies — nineteen per leg,
            // three in `DBS`/`DBM`/`DBN`/`DBS2`, two in `DBM$1` (its constructor and `mark`), and
            // one in each of `DBS$1`, `DBN$1`, `Carrier`, `Carrier$Nested` and `DBS2$1` — no
            // handler record, no branch target and no subroutine) moved it again.
            // The 2026-10-07 recover-covariant-array-store-receiver fixtures (the patrol's own
            // `AS` — `storeWrong`, `storeRight`, `storeNumber` and their `main` — beside this
            // change's `SD` driver (the same-type read-back, the two proven-compatible controls,
            // the three caught covariant stores, the primitive-array negative and the same-type
            // element receiver), the `UB` unproven-receiver negative (the merged local and the
            // `checkcast` receiver) and the `SC` subtype-value probe, four classes on both
            // compiler legs — eight classes, forty-four bodies, twenty-two per leg — ten handler
            // records (`AS.main`'s two `ArrayStoreException` rows and `SD`'s three catches, one
            // each in `catchWrong`, `catchNumber` and `catchElement`, per leg) and eight branch
            // targets (`AS.main`'s two `goto`s and `UB.merged`'s `ifeq`/`goto` pair, four per
            // leg), no subroutine).
            // The 2026-10-07 recover-io-resource-finally fixtures (the io-wrapping patrol's `IO`
            // recompiled verbatim on both compiler legs — `countLines` the row-set resource
            // guard's anchor, `readAll` the registered copy-family boundary and `main` — beside
            // this change's `IOMidRead` (the same certificate over a caller-owned stream, the
            // mid-read driver's method), `IONegatives` (`twoNested`'s two handlers and
            // `closeReturns`' value-carrying copy, the two refusals) and `NestedDepth` (the
            // `new@1` depth boundary: `threeLayer` presents, `fourLayer` refuses) with its four
            // nested companions and `Returner`: nine classes on both compiler legs — eighteen
            // classes, forty bodies, twenty per leg (`IO`'s four, `IOMidRead`'s two,
            // `IONegatives`' three, `NestedDepth`'s four, `Returner`'s three and the four
            // companions' one each) — twenty-four handler records (`IO`'s four: `countLines`' and
            // `readAll`'s two rows each; `IOMidRead`'s two; `IONegatives`' six: `twoNested`'s four
            // — the two nested `finally`s' protected ranges and self-protection rows — and
            // `closeReturns`' two; twelve per leg) and twenty-two branch targets (eleven per leg:
            // `IO`'s five — `countLines`' `ifnull`/`goto`, `readAll`'s `if_icmpeq`/`goto` and
            // `main`'s one — `IOMidRead`'s two and `IONegatives`' four — the two loops'
            // `if_icmpne`/`goto` pairs) — plus this change's `WideningProbe` (the two `java.io`
            // rows' own argument positions, one class on both legs: two classes, six bodies — the
            // constructor and the two members per leg — no handler record, no branch target and no
            // subroutine).
            // The 2026-10-08 recover-instance-field-assignment-chains fixtures (the copy family's
            // chain shape as javac writes it for **instance** fields: `CP` with the three-store
            // chain, the two-store chain and the `main` that exercises both, `MX` with the three
            // mixed static/instance dances (a recorded boundary: those keep their refusals) and
            // `NEG` with the four refusals — a cross-object chain, a copy consumed by the
            // expression the stored value is part of, a source that would have to be saved and a
            // receiver a call produced, three classes on both compiler legs: six classes,
            // thirty-six bodies, eighteen per leg (`CP`'s four, `MX`'s five and `NEG`'s nine), no
            // handler record, no branch target and no subroutine) moved it again.
            // The 2026-10-08 recover-nested-lock-finally-bodies fixtures (the multi-lock patrol's
            // own `ML` — rendered first from its frozen jar and recompiled on both legs — with
            // `MLOrder` the same two guards over its own recording lock, `Order` the recorder,
            // `MLOrderDriver` the behavior driver, `MLNegatives` the three refusals and `MLProbe`
            // the three registered boundaries, six classes on both compiler legs: twelve classes,
            // sixty-four bodies, thirty-two handler records — the two guards' own rows, the
            // negatives' and the boundaries', sixteen per leg — forty-four branch targets
            // (twenty-two per leg: `ML`'s five, `MLNegatives`' three, `MLOrder`'s four,
            // `MLOrderDriver`'s three, `MLProbe`'s five and `Order`'s two) and no subroutine) moved
            // it again.
            // The 2026-10-08 preserve-local-scope-refusals fixtures (the local-scope change's
            // 2.1/2.2 refusal closure: `ScopeRefusals` — `savedAcrossFinally`, `handlerComputed`
            // and `nestedHandler`, one per refusal family, beside the independent `siblingKept`
            // and the quoted-slice boundary `quotedSliceKept` — and `ScopeRefusalsEscape` with the
            // shared multi-catch handler, both classes on both compiler legs — four classes,
            // fourteen bodies, seven per leg — plus the derived `escaped/ScopeRefusalsEscape`
            // control, five classes and twenty bodies in all: twelve handler records
            // (`ScopeRefusals`' six — one each for `savedAcrossFinally`, `handlerComputed`,
            // `siblingKept` and `quotedSliceKept` and two for `nestedHandler` — and the escape
            // class's two, six per leg) and twenty-one branch targets (nine per leg in
            // `ScopeRefusals` — `savedAcrossFinally`'s `goto`, `handlerComputed`'s
            // `goto`/`ifnonnull`/`goto`, `nestedHandler`'s two `goto`s, `siblingKept`'s `goto`
            // and `quotedSliceKept`'s `ifle`/`goto` — plus the escape class's `goto` once per
            // leg, and the derived control's own `goto` once more), no subroutine) moved it
            // again.
            // The 2026-10-08 recover-loop-test-copy-store fixtures (the io slice's registered
            // boundary closed: the anchor `Probe` — `readAll` the same-form loop outside any guard
            // body and `guardPlain` the guard-body control whose `if` presents — `ProbeControls`
            // with the two refusals (`parameterTarget`'s parameter-target loop test and
            // `guardIfFirst`'s if-position dance inside the protected range), and the byte-patched
            // `MultiCopy` — `Probe` with the loop test's `iconst_m1` replaced by a `dup`, the
            // copy's second consumer, three classes on both compiler legs: six classes,
            // twenty-four bodies, twelve per leg — four in each class — twelve handler records
            // (`guardPlain`'s two and `guardIfFirst`'s two per leg: the protected range's own row
            // and the handler's binding-store row) and thirty-six branch targets (eighteen per
            // leg: `Probe`'s six — `readAll`'s loop pair and `guardPlain`'s loop and `if` pairs —
            // `ProbeControls`' six — `parameterTarget`'s loop pair and `guardIfFirst`'s loop and
            // `if` pairs — and `MultiCopy`'s six — the patched loop's pair beside `guardPlain`'s
            // four), no subroutine) moved it again.
            // The 2026-10-08 recover-branching-guard-body fixtures (the nested-lock slice's third
            // measured boundary presented: the anchor `BG` with `singleIf` — the patrol's boundary
            // shape verbatim — and `ifElse`, the `BGOrder` order-and-exception leg with
            // `singleIf`/`ifElse`/`twoIfs` over the fixture's own recording `Order` lock,
            // `BGNegatives` with the two fused tails that are not the method's value-less return,
            // the branch that returns inside the range and the multi-way branch, and `BGProbe`
            // with the walk's branch shapes beyond the filing's MVP note — six classes on both
            // compiler legs: twelve classes, sixty bodies, thirty per leg (three in `BG`, six in
            // `BGOrder`, ten in `Order` — its seven `Lock` methods beside the constructor, `log`
            // and `reset` — five in `BGNegatives`, four in `BGProbe` and two in the driver, whose
            // `main` is compiled per leg and never recovered) — twenty-six handler records
            // (thirteen per leg: `BG`'s two — one per guarded member — `BGOrder`'s three,
            // `BGNegatives`' four — `bodyReturn`'s early-return arm carries a second row — and
            // `BGProbe`'s three, plus the driver's own catch in `main`) and eighty-four branch
            // targets (forty-two per leg: `BG`'s five, `BGOrder`'s eight, `BGNegatives`' ten —
            // `switchBody`'s `tableswitch` included — `BGProbe`'s nine, the driver's nine and the
            // lock's own `goto`), no subroutine) moved it again.
            // The 2026-10-09 raw-receiver-field-selection standalone accessor guard adds one
            // class and three straight-line Code bodies; the other inputs are frozen jars.
            // Forty-two reference-slot lifetime fixtures add 132 bodies, one handler and 33 branches.
            // EM-18 v3 factory/direct families add 24 classes, 172 Code bodies and eight
            // branch targets (the two complete observers per compiler), with no handlers.
            // The constructed-reference-array composition slice adds 20 classes, 64 Code
            // bodies, two handlers and ten branch targets: 14 complete-family classes,
            // four nested/boundary control classes and two handler control classes. It adds no
            // subroutine.
            // The constructor primitive-conversion slice adds eight canonical classes across
            // two complete positives and two handler-control versions on both compiler legs:
            // 84 Code bodies and four handlers, with no branch or subroutine records.
            // BigDecimal widening adds the Main and NumberArgument classfiles for both
            // compiler legs: four classes and ten straight-line bodies; no new control flow.
            // Nested int updates add four canonical classes: 22 straight-line control bodies
            // and six boundary bodies, including four branch records from the two row-Phi
            // methods. No handler or subroutine is introduced.
            // Returned int updates add 16 complete 11-member classes: two originals, eight
            // Java-typed controls and six consumer/return controls. The measured addition is
            // 176 Code bodies, with no handlers, branches or subroutines.
            // The conditional-switch boundary fixtures add six classes, 31 Code bodies, five
            // handlers, 167 branch/switch targets, and the legacy control's two jsr calls.
            // CF11 fixed/controls: two classes, five Code bodies, no handlers, thirty
            // branch targets (10 + 20), no jsr; independently counted from accepted javap.
            // For-condition originals: five Java 8 classes, twenty-four Code bodies, no handlers,
            // forty-one branch targets (12 + 12 + 5 + 6 + 6), and no jsr; accepted javap counts.
            // Conditional-constructor-values and fixed SequentialLoops2: three javac 23 --release 8
            // classfiles (3/8/10 Code bodies; 10/10/14 branch/switch targets), 21 bodies total,
            // one handler (`handlerAroundConditional`), 34 branch/switch targets and no jsr.
            // HoistedIteratorPhiControls: one canonical javac8 class, three Code bodies,
            // no handlers, five direct branch targets (mixed 3 + alias 2), no jsr;
            // independently confirmed against both compiler legs and parsed Code bytes.
            // CF11OuterAssignmentTarget: one canonical javac8 class, five Code bodies,
            // no handlers, eight direct branch targets (two per loop method), no jsr.
            // Structured List generic bodies add seven classes, twenty-three Code bodies,
            // one handler and ninety-three branch targets: six nested bodies with eight each,
            // plus forty-five in the combined controls; no subroutine is introduced.
            // Loop-body-catch patrol/load/retry fixtures add 15 classes, 63 Code bodies,
            // 27 handlers and 130 branch/switch targets. Ordered-field-concat fixtures add
            // eight classes, 76 Code bodies and eight targets. Neither adds a subroutine.
            // ReferenceAliasBoundary adds one javac 23 --release 8 class and three
            // straight-line Code bodies; independently counted from Code bytes and javap.
            // Protected-prefix-loop negative neighbors add one javac 23 --release 8
            // class, three Code bodies, two handlers and five direct branch targets; no jsr.
            // Independently measured from actual Code bytes and accepted javap.
            // The 2026-10-14 ordinary-Try List baseline/admission and two forward-carry
            // compiler legs add four classes, sixty-two bodies, eighteen handler records and
            // one hundred forty-five non-handler branch targets; no subroutine was added.
            // The reference-dependency carry counterexample adds two compiler classes,
            // twenty Code bodies and twelve direct branch targets, with no handler/subroutine.
            // Its two complete receiver-assignment refusal controls add four bodies and four
            // direct branch targets, with no handler/subroutine.
            // The 2026-10-16 static-prefix return fixture adds both frozen FO compiler legs:
            // two classes, ten Code bodies and two handler records (evalThenFin once per leg),
            // with no branch/switch target or subroutine. The same complete decoder/member-walk
            // assertions above still validate every body; only the intended population moves.
            // Conditional-return finally adds two independent LooplessFinally compiler legs:
            // four Code bodies, two handlers and six direct target records (26, 26, 48
            // in each method); repeated targets count per instruction, with no jsr.
            // NoCall loop-local finally adds two frozen classes, four Code bodies,
            // four handlers and eight direct target records (60, 40, 54, 10 per leg).
            // The complete independent methods retain all 62 Code bytes; no jsr.
            // Call-return loop finally adds two frozen independent classes, six Code bodies,
            // four handler rows and eight targets (125, 59, 119, 7 per compiler leg).
            // Both finReturn methods keep all 127 Code bytes; no jsr.
            // Branch-throw/return finally: two independent compiler classes, four bodies,
            // two handlers and two targets. Its javac23 extra-exit neighbor adds one class,
            // three bodies, two handlers and two targets; actual javap and Code facts agree.
            // Nested finally adds two complete compiler classes: four Code bodies,
            // eight catch-all rows and four goto targets (21/54 per leg); no jsr.
            // Exception-only finally adds eleven complete classes: 71 Code bodies, 39 handler
            // records and one goto target, with no jsr. Independently measured from all Code
            // arrays (including original seven-method neighbors), then checked by this walk.
            // The separate local-read rollback control adds one complete javac23 release8 class,
            // three Code bodies and one handler, with no branch target or subroutine.
            // A separately compiled parameter-reassignment refusal adds one class, four Code
            // bodies and one handler; its actual Code has no branch target or subroutine.
            // Direct-array constructor arguments add 26 complete frozen classes: 78 Code
            // bodies, four handler rows and six branch targets; no jsr. The new population
            // was measured by this full reader walk before updating the expected tuple.
            // Switch nonlocal exits add eight complete javac8/23 classes: 40 bodies and 120
            // targets. Boundary controls add two catch-bearing compiler classes and one v49
            // jsr class: nine bodies, four handlers, nineteen targets and two subroutine calls.
            // Raw Code counts independently match the measured positive-fixture delta.
            // Prefixed exceptional retry adds 20 complete original/supplement/neighbor classes:
            // 144 Code bodies, 18 handler rows and 206 targets; no jsr. Independent decoded
            // Code counts agree with this walk, including both original outer classes.
            // Proved loop-arm returns add 22 complete classes, 38 Code bodies, two catch rows
            // and 74 branch targets; independent physical Code parsing agrees with this walk.
            // Statementful sequential loops add eight complete classes, 20 Code bodies and
            // 50 targets. Field-copy controls add eight classes, 36 bodies, four catch rows
            // and 48 targets. Independent parsing counted every physical Code array; no jsr.
            // Statementful-loop boundaries: three classes, eight Code bodies, no handlers,
            // sixteen branch targets and two jsr instructions, independently parsed.
            // Extra stack-copy neighbor: one complete class, four Code bodies,
            // seventy instructions, no handlers, five branch targets and no jsr.
            // Typed List foreach adds one complete javac8 class, six Code bodies and
            // ten direct branch targets; independent raw-Code parsing counts 97 instructions,
            // no handlers and no jsr. The fixture is byte-identical to the runtime baseline.
            // Original nested foreach child debug/none add two exact runtime-baseline copies,
            // four Code bodies and sixteen direct targets; no handlers or jsr.
            // The complete Reader sweep and independent raw-Code decode measured this delta.
            // Indexed List parameter controls add the frozen debug and no-debug classes. Each
            // class has ten Code bodies, eighteen branch targets, no handler and no jsr; together
            // they add two classes, twenty bodies and thirty-six branch targets.
            // Assignment-condition widening adds six frozen classes: thirty Code bodies,
            // twelve direct branch targets, no handlers or subroutines (independent byte census).
            // Entry-split controls add five complete verified classes, nineteen Code bodies,
            // one handler, fifty-one direct targets and two legacy jsr calls; raw-Code census
            // agrees with both JVM verification legs and the frozen fixture manifest.
            // Independent slot-permutation/counter-up control adds one verified class,
            // three Code bodies and six direct targets, with no handler or jsr.
            // Original Raung and two explicit Code controls add three classes, three Code
            // bodies and twelve direct targets; no handler/jsr change.
            // Full original Boolean flag outer/child debug/no-debug and two literal-2
            // refusal controls add six classes, twenty Code bodies and twenty branch targets;
            // two independent physical decoders agree, with no handler/jsr change.
            (1326, 5850, 631, 4203, 16),
            "fixture population changed: re-measure these counts"
        );
    }

    /// Every `.class` under `tests/fixtures`, in a deterministic order.
    fn class_fixture_paths() -> Vec<std::path::PathBuf> {
        fn walk(directory: &std::path::Path, found: &mut Vec<std::path::PathBuf>) {
            let mut entries = std::fs::read_dir(directory)
                .unwrap_or_else(|error| panic!("{}: {error}", directory.display()))
                .map(|entry| entry.unwrap().path())
                .collect::<Vec<_>>();
            entries.sort();
            for entry in entries {
                if entry.is_dir() {
                    walk(&entry, found);
                } else if entry
                    .extension()
                    .is_some_and(|extension| extension == "class")
                {
                    found.push(entry);
                }
            }
        }
        let root = crate::test_fixtures::fixtures_root();
        let mut found = Vec::new();
        walk(&root, &mut found);
        found
    }

    /// One class with two methods, whose second method carries one attribute of the named length.
    ///
    /// The pool is `#1` the class name, `#2` its `Class`, `#3`/`#4` `java/lang/Object`, `#5`/`#6`
    /// the first method's text, `#7`/`#8` the second's and `#9` the attribute's name. The first
    /// method has no attribute at all, so the walk's own position arithmetic is what the tests
    /// below exercise: one shell-less record, then one record whose attribute is the damage.
    /// A zero class-attribute count closes the valid case after the member tables.
    fn two_method_fixture(second_attribute_length: u32) -> Vec<u8> {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&0xcafebabe_u32.to_be_bytes());
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 52);
        u16_be(&mut bytes, 10);
        utf8(&mut bytes, b"p/Two"); // 1
        class_entry(&mut bytes, 1); // 2
        utf8(&mut bytes, b"java/lang/Object"); // 3
        class_entry(&mut bytes, 3); // 4
        utf8(&mut bytes, b"first"); // 5
        utf8(&mut bytes, b"()V"); // 6
        utf8(&mut bytes, b"second"); // 7
        utf8(&mut bytes, b"()I"); // 8
        utf8(&mut bytes, b"Code"); // 9
        u16_be(&mut bytes, 0x0021);
        u16_be(&mut bytes, 2);
        u16_be(&mut bytes, 4);
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 0);
        u16_be(&mut bytes, 2);
        for (name, descriptor, attributes) in [(5_u16, 6_u16, 0_u16), (7, 8, 1)] {
            u16_be(&mut bytes, 0x0001);
            u16_be(&mut bytes, name);
            u16_be(&mut bytes, descriptor);
            u16_be(&mut bytes, attributes);
            if attributes == 1 {
                u16_be(&mut bytes, 9);
                u32_be(&mut bytes, second_attribute_length);
                bytes.push(0xb1);
            }
        }
        u16_be(&mut bytes, 0);
        bytes
    }

    /// The member walk establishes exactly what the header read does when nothing is damaged.
    #[test]
    fn member_walk_agrees_with_the_whole_structure_read() {
        let bytes = fixture().bytes;
        let mut walk_budget = Budget::new(limits(1 << 20));
        let walked = class_member_facts(&bytes, &mut walk_budget).unwrap();
        let mut header_budget = Budget::new(limits(1 << 20));
        let header = inspect_header_structure(&bytes, &mut header_budget).unwrap();

        assert_eq!(walked.access_flags, header.access_flags);
        assert_eq!(walked.this_class, header.this_class);
        assert_eq!(walked.super_class, header.super_class);
        assert_eq!(walked.interfaces, header.interfaces);
        assert_eq!(walked.fields, header.fields);
        assert_eq!(walked.methods, header.methods);
        assert_eq!(walked.attributes, header.attributes);
        assert_eq!(walked.stopped_at, None);
        // Both reads retain class attribute shells while leaving their content lazy.
        assert!(!header.attributes.is_empty());
        assert!(
            walked.methods[0]
                .attributes
                .iter()
                .any(|shell| shell.name.raw().0 == b"Code"),
            "the `Code` attribute is a shell in the member list, not a decoded body"
        );
        assert_eq!(
            walk_budget.usage().code_bytes,
            0,
            "no member read charges an instruction byte: the body is never decoded"
        );
    }

    /// A record that does not decode keeps the prefix read before it and names the stop.
    #[test]
    fn a_damaged_member_record_keeps_the_prefix_and_names_the_stop() {
        // The second method declares one attribute of length 4 while one content byte follows it,
        // so the attribute's content leaves the class bytes: the record is the damage.
        let bytes = two_method_fixture(4);
        let mut budget = Budget::new(limits(1 << 20));
        let walked = class_member_facts(&bytes, &mut budget).unwrap();
        assert_eq!(walked.this_class.raw().0, b"p/Two");
        assert!(walked.fields.is_empty());
        assert_eq!(walked.methods.len(), 1, "{:?}", walked.methods);
        assert_eq!(walked.methods[0].name.raw().0, b"first");
        let stop = walked
            .stopped_at
            .expect("the second method's attribute leaves the class bytes");
        assert_eq!(stop.phase, MemberTablePhase::Methods);
        assert_eq!(stop.index, 1);
        assert_eq!(stop.code, "classfile_invalid_attribute_span");
        assert!(
            stop.class_offset > 0 && stop.class_offset < bytes.len() as u64,
            "the stop is located inside the class bytes: {stop:?}"
        );

        // The same bytes fail the whole-structure reads, which is what makes the prefix above
        // something only this walk can establish.
        let mut header_budget = Budget::new(limits(1 << 20));
        assert!(inspect_header_structure(&bytes, &mut header_budget).is_err());
        let mut facts_budget = Budget::new(limits(1 << 20));
        assert!(class_facts(&bytes, &mut facts_budget).is_err());
    }

    /// Both tables read to their declared end leave no stop behind.
    #[test]
    fn a_complete_member_table_leaves_no_stop() {
        let bytes = two_method_fixture(1);
        let mut budget = Budget::new(limits(1 << 20));
        let walked = class_member_facts(&bytes, &mut budget).unwrap();
        assert_eq!(walked.stopped_at, None);
        assert_eq!(walked.methods.len(), 2);
        assert_eq!(walked.methods[1].name.raw().0, b"second");
        let shell = &walked.methods[1].attributes[0];
        assert_eq!(shell.name.raw().0, b"Code");
        assert_eq!(shell.content_span.length, 1);
        assert_eq!(budget.usage().code_bytes, 0);
    }

    /// A refusal of the request is an error, never a prefix with a stop.
    #[test]
    fn a_refused_member_read_is_an_error_not_a_stop() {
        let bytes = two_method_fixture(1);
        let mut budget = Budget::new(Limits {
            class_bytes: 1,
            ..limits(1 << 20)
        });
        assert!(matches!(
            class_member_facts(&bytes, &mut budget),
            Err(Error::BudgetExceeded {
                dimension: BudgetDimension::ClassBytes,
                ..
            })
        ));

        let cancellation = CancellationToken::new();
        cancellation.cancel();
        let mut budget = Budget::with_cancellation_token(limits(1 << 20), cancellation);
        assert!(matches!(
            class_member_facts(&bytes, &mut budget),
            Err(Error::Cancelled { .. })
        ));
    }

    /// JVMS 2.6.1: a component's slot occupancy is its own, and an **array** of a `long` or a
    /// `double` fills one slot like every other array.
    ///
    /// This is the one place the slot rule is stated, so this is where it is pinned: the primitive
    /// is two slots, the array of that same primitive is one, and a second dimension changes
    /// nothing.
    #[test]
    fn an_arrays_element_type_does_not_widen_the_array() {
        for (descriptor, expected, object_name) in [
            (&b"I"[..], 1u16, None),
            (b"J", 2, None),
            (b"D", 2, None),
            (b"[I", 1, None),
            (b"[J", 1, None),
            (b"[D", 1, None),
            (b"[[J", 1, None),
            (b"[[[D", 1, None),
            (b"Ljava/lang/String;", 1, Some(&b"java/lang/String"[..])),
            (b"[Ljava/lang/String;", 1, Some(b"java/lang/String")),
            (b"[[Ljava/lang/String;", 1, Some(b"java/lang/String")),
            (b"[Lp/Outer$Inner;", 1, Some(b"p/Outer$Inner")),
        ] {
            let facts = descriptor_facts(descriptor, DescriptorKind::Field).expect("a field type");
            let component = facts.single().expect("one component");
            assert_eq!(
                component.slots(),
                expected,
                "`{}` occupies {expected} slot(s)",
                String::from_utf8_lossy(descriptor)
            );
            assert_eq!(
                component.object_name().map(|name| name.0.clone()),
                object_name.map(<[u8]>::to_vec),
                "`{}` names its object type whatever its dimensions",
                String::from_utf8_lossy(descriptor)
            );
            assert_eq!(
                component.span(),
                crate::model::ByteSpan::new(0, u64::try_from(descriptor.len()).unwrap()),
                "one component is the whole descriptor"
            );
            assert_eq!(
                descriptor_types(descriptor, DescriptorKind::Field)
                    .expect("the projection reads the same bytes")
                    .len(),
                usize::from(object_name.is_some()),
                "the object types are the projection of the same read"
            );
        }

        // The parameter list states the positions and the occupancy together: `[J` is one slot, so
        // the `int` after it starts at slot 1 — the shape a wide-element array used to shift.
        let method = descriptor_facts(b"([JJI)V", DescriptorKind::Method).expect("a method");
        let widths: Vec<u16> = method
            .parameters()
            .iter()
            .map(DescriptorComponent::slots)
            .collect();
        assert_eq!(widths, vec![1, 2, 1]);
        assert_eq!(method.parameter_slots(), Some(4));
        assert_eq!(
            method
                .parameters()
                .iter()
                .map(|component| component.dimensions())
                .collect::<Vec<_>>(),
            vec![1, 0, 0]
        );
        assert!(method.result().is_none(), "`V` states no result");
        assert_eq!(method.kind(), DescriptorKind::Method);
    }

    /// A descriptor that is not its production is one structured error: a partial set of
    /// components is never published, and the components of an unread descriptor never reach a
    /// consumer that derives slots from them.
    ///
    /// One shape is readable as a component and still names no type: `L;` states a reference whose
    /// interior is empty, which JVMS 4.2 refuses as a binary name. The reader keeps the bytes, the
    /// slots rule reads them (an array of one is still one slot), and the publish-a-type entry
    /// point refuses them — which is the split the frame layer and the spelling layer each rely on.
    #[test]
    fn a_descriptor_that_does_not_parse_publishes_no_component() {
        for (descriptor, kind) in [
            (&b""[..], DescriptorKind::Field),
            (b"V", DescriptorKind::Field),
            (b"II", DescriptorKind::Field),
            (b"Ljava/lang/String", DescriptorKind::Field),
            (b"[Z]", DescriptorKind::Field),
            (b"", DescriptorKind::Method),
            (b"I", DescriptorKind::Method),
            (b"(J)", DescriptorKind::Method),
            (b"(J", DescriptorKind::Method),
            (b"(J)V)", DescriptorKind::Method),
            (b"(Q)V", DescriptorKind::Method),
            (b"([J)Q", DescriptorKind::Method),
        ] {
            let error = descriptor_facts(descriptor, kind).expect_err("not its production");
            assert!(
                matches!(
                    &error,
                    Error::InvalidInput { code, .. } if code == DESCRIPTOR_CODE
                ),
                "`{}` is refused with the reader's own code, got {error}",
                String::from_utf8_lossy(descriptor)
            );
            assert!(
                descriptor_types(descriptor, kind).is_err(),
                "the projection refuses what the one reader refuses"
            );
        }
        for (descriptor, kind) in [
            (&b"L;"[..], DescriptorKind::Field),
            (b"[L;", DescriptorKind::Field),
            (b"(L;)V", DescriptorKind::Method),
        ] {
            let facts = descriptor_facts(descriptor, kind).expect("the production parses");
            assert!(
                facts.components().all(|component| component
                    .object_name()
                    .is_some_and(|name| name.0.is_empty())),
                "`{}` states an object type with no name",
                String::from_utf8_lossy(descriptor)
            );
            assert_eq!(
                descriptor_facts(descriptor, kind)
                    .expect("the same reading")
                    .components()
                    .map(DescriptorComponent::slots)
                    .sum::<u16>(),
                facts
                    .components()
                    .map(DescriptorComponent::slots)
                    .sum::<u16>(),
                "the slots of a component are stated whether its name is writable or not"
            );
            assert!(
                matches!(
                    descriptor_types(descriptor, kind),
                    Err(Error::InvalidInput { code, .. }) if code == DESCRIPTOR_CODE
                ),
                "`{}` publishes no class reference",
                String::from_utf8_lossy(descriptor)
            );
        }
        // A return descriptor's `V` is a component set of none, not an error — and a bare array is
        // a field type whether the caller asked for one or for a return type.
        assert!(
            descriptor_facts(b"V", DescriptorKind::Return)
                .expect("`V` is a return descriptor")
                .single()
                .is_none()
        );
        assert_eq!(
            descriptor_facts(b"[J", DescriptorKind::Return)
                .expect("a return type is a field type")
                .single()
                .expect("one component")
                .slots(),
            1
        );
    }

    /// The cursor reads one component of a longer buffer at the position it states, which is the
    /// shape a caller reading a descriptor at an offset needs.
    #[test]
    fn the_cursor_reads_one_component_at_a_time() {
        let bytes = &b"[[JI)Lp/Q;"[..];
        let mut cursor = DescriptorCursor::new(bytes);
        let first = cursor.field_type().expect("one component");
        assert_eq!(first.slots(), 1);
        assert_eq!(first.dimensions(), 2);
        assert_eq!(cursor.position(), 3, "`[[J` is three bytes");
        let second = cursor.field_type().expect("the next component");
        assert_eq!(second.slots(), 1, "`I` is one slot");
        assert_eq!(second.dimensions(), 0);
        assert_eq!(second.object_name(), None);
        assert_eq!(cursor.position(), 4);
        assert!(cursor.expect_end().is_err(), "a `)` is left over");

        let mut at_offset = DescriptorCursor::at_offset(bytes, 5);
        let object = at_offset
            .field_type()
            .expect("the object type at its offset");
        assert_eq!(object.slots(), 1);
        assert_eq!(
            object.object_name().map(|name| name.0.clone()),
            Some(b"p/Q".to_vec())
        );
        assert_eq!(at_offset.position(), bytes.len());
        assert!(
            at_offset.expect_end().is_ok(),
            "the component ends the buffer"
        );

        let mut returns = DescriptorCursor::new(&b"V"[..]);
        assert!(returns.return_type().expect("`V`").is_none());
        assert!(returns.expect_end().is_ok());
    }
}
