

    #[test]
    fn test_break_with_label_slot3_boolean_ssa_probe() {
        for (profile, class) in [
            (
                "debug",
                include_bytes!("/private/tmp/jarde-testbreakwithlabel-baseline-root-v1-20261019/debug/classes/jadx/tests/integration/loops/TestBreakWithLabel$TestCls.class").as_slice(),
            ),
            (
                "no-debug",
                include_bytes!("/private/tmp/jarde-testbreakwithlabel-baseline-root-v1-20261019/no-debug/classes/jadx/tests/integration/loops/TestBreakWithLabel$TestCls.class").as_slice(),
            ),
        ] {
            fixture_value_attempts_with_tree_observing(
                class,
                "test",
                "([[II)Z",
                None,
                None,
                |recovered, canonical, ssa, operations, code, _, _, _, _, _, _, budget| {
                    let resources = resource_slots(&recovered.regions);
                    let debug_locals = iterator_test_debug_locals(code);
                    let reuse = reuse::plan(
                        ssa,
                        canonical,
                        operations,
                        &recovered.regions,
                        code.max_locals,
                        3,
                        &debug_locals,
                        &resources,
                        budget,
                    )
                    .expect("the actual method has a bounded reuse plan");
                    let owner = reuse
                        .variable_at(3, 1)
                        .expect("slot 3 has one local owner at its first store");
                    assert_eq!(owner, LocalVariable::whole(3), "{profile}: slot is not split");

                    let mut reads = Vec::new();
                    let mut writes = Vec::new();
                    for block in ssa.blocks() {
                        for instruction in block.instructions() {
                            for (slot, value) in instruction.reads() {
                                if *slot == Slot::Local(3) {
                                    assert_eq!(reuse.variable_at(3, instruction.bci()), Some(owner));
                                    reads.push((instruction.bci(), *value));
                                }
                            }
                            for (slot, value) in instruction.writes() {
                                if *slot == Slot::Local(3) {
                                    assert_eq!(reuse.variable_at(3, instruction.bci()), Some(owner));
                                    writes.push((instruction.bci(), *value));
                                }
                            }
                        }
                    }
                    reads.sort_by_key(|(bci, _)| *bci);
                    writes.sort_by_key(|(bci, _)| *bci);
                    assert_eq!(
                        reads.iter().map(|(bci, _)| *bci).collect::<Vec<_>>(),
                        [68, 78],
                        "{profile}: complete slot-3 read census"
                    );
                    assert_eq!(
                        writes.iter().map(|(bci, _)| *bci).collect::<Vec<_>>(),
                        [1, 37],
                        "{profile}: complete slot-3 write census"
                    );
                    println!("{profile}: slot3 owner={owner:?} writes={writes:?} reads={reads:?}");

                    let local_phis: Vec<_> = ssa
                        .phis()
                        .iter()
                        .filter(|phi| phi.slot() == Slot::Local(3))
                        .collect();
                    assert!(!local_phis.is_empty(), "{profile}: slot 3 must have a real SSA Phi");
                    let back_edges: Vec<_> = canonical
                        .edges()
                        .iter()
                        .filter(|edge| {
                            edge.kind() == CanonicalEdgeKind::Normal
                                && edge.to().bci() <= edge.from().bci()
                        })
                        .collect();
                    assert!(!back_edges.is_empty(), "{profile}: loop backedges are present");
                    assert!(
                        local_phis.iter().any(|phi| back_edges.iter().any(|edge| edge.to() == phi.block())),
                        "{profile}: a slot-3 Phi is owned by the actual loop-header block"
                    );
                    for phi in &local_phis {
                        assert_eq!(reuse.variable_at(3, phi.block().bci()), Some(owner));
                        assert!(matches!(
                            ssa.value(phi.value()).def(),
                            Definition::Phi { block, slot: Slot::Local(3) } if block == phi.block()
                        ));
                        for input in phi.inputs() {
                            match input {
                                PhiInput::Itself => {}
                                PhiInput::Value(value) => {
                                    assert!(
                                        ssa.value(*value).uses().iter().any(|usage| {
                                            usage.bci().is_none() && usage.block() == phi.block()
                                        }),
                                        "{profile}: Phi input use must name its real owner block"
                                    );
                                    match ssa.value(*value).def() {
                                        Definition::Instruction { bci, .. } => assert!(
                                            writes.iter().any(|(write_bci, write_value)| {
                                                write_bci == bci && write_value == value
                                            }),
                                            "{profile}: slot-3 Phi input is a physical slot-3 store"
                                        ),
                                        Definition::Phi { slot: Slot::Local(3), .. } => {}
                                        other => panic!("{profile}: unexpected slot-3 Phi input: {other:?}"),
                                    }
                                }
                            }
                        }
                        println!(
                            "{profile}: local-phi block={:?} value={:?} inputs={:?} users={:?} loop-edges={:?}",
                            phi.block(), phi.value(), phi.inputs(), ssa.value(phi.value()).uses(),
                            back_edges.iter().map(|edge| (edge.from(), edge.to(), edge.kind())).collect::<Vec<_>>()
                        );
                    }

                    let facts = crate::facts::MethodFacts::new("test", "([[II)Z", 3)
                        .with_access_flags(0x0001);
                    let parameter_types = facts.parameter_types();
                    let fields = field::Plan::empty();
                    let return_type = Type::Boolean;
                    for (load_bci, consumer_bci, expected) in [(68, 69, false), (78, 79, true)] {
                        let load = instruction_at(ssa, load_bci).expect("physical local load");
                        let [(Slot::Stack(_), value)] = load.writes() else {
                            panic!("{profile}: BCI {load_bci} writes one stack value");
                        };
                        assert!(
                            ssa.value(*value).uses().iter().any(|usage| usage.bci() == Some(consumer_bci)),
                            "{profile}: load must reach its exact physical consumer"
                        );
                        let mut consumption = BooleanConsumption {
                            ssa,
                            operations,
                            reuse: &reuse,
                            parameter_types: &parameter_types,
                            fields: &fields,
                            return_type: Some(&return_type),
                            is_boolean_variable: &|variable| variable == owner,
                            budget: None,
                        };
                        let proved = consumption
                            .consumed(*value, load_bci, 0, &mut BTreeSet::new())
                            .expect("the real consumer walk completes");
                        assert_eq!(proved, expected, "{profile}: BooleanConsumption at {load_bci}->{consumer_bci}");
                        println!("{profile}: BooleanConsumption load@{load_bci} -> consumer@{consumer_bci}: {proved}");
                    }
                },
            );
        }
    }
