# TestBreakWithLabel real-SSA probe (private, unexecuted)

This bundle is a temporary `build.rs` test patch only. It changes no production source and has not been compiled or run. The test uses the existing `fixture_value_attempts_with_tree_observing` path, then independently builds the same split-aware `reuse::Plan` from the recovered regions and the method's actual `MethodCodeFacts`.

The expected physical slot-3 census is two writes (BCIs 1, 37) and two reads (68, 78), with one unsplit `LocalVariable::whole(3)` owner in both class profiles. The probe enumerates local-slot-3 Phi inputs and uses, ties each concrete input either to a slot-3 store or another slot-3 Phi, and requires one actual normal backedge to a slot-3 Phi block. It then enters `BooleanConsumption::consumed` on the actual stack values produced by loads 68 and 78, asserting the existing boundary: the `append(Z)` call argument is not yet admitted while the `Z` return is. These are implementation facts to capture, not a claim that the new proof works.

Original class inputs, taken directly from the accepted baseline capture (not reconstructed from bytecode):

- debug: `/private/tmp/jarde-testbreakwithlabel-baseline-root-v1-20261019/debug/classes/jadx/tests/integration/loops/TestBreakWithLabel$TestCls.class` — 1518 bytes, SHA-256 `de061b8676da2c2c840335a526bc959b7f63f35e772af94f6d4cea3d6e794a74`
- no-debug: `/private/tmp/jarde-testbreakwithlabel-baseline-root-v1-20261019/no-debug/classes/jadx/tests/integration/loops/TestBreakWithLabel$TestCls.class` — 1115 bytes, SHA-256 `51a3e2e582eebbfb25689ee4d14c7171916f39dd669dbf46a43977802afad194`

Apply `probe.patch` to the exact live `crates/jarde-java/src/build.rs` source; it appends one test inside the existing `#[cfg(test)] mod tests`. The two `include_bytes!` paths above must remain available during compilation. The intended guarded invocation is:

```sh
cargo test -p jarde-java --lib build::tests::test_break_with_label_slot3_boolean_ssa_probe -- --exact --nocapture
```

Run under the caller's existing source/target guard, capture stdout/stderr and restore the source afterward. This package deliberately does not run that command.
