import datetime,hashlib,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
PREP=Path('/private/tmp/jarde-testbreakwithlabel-ir-probe-prep-luna-v1-20261019')
HERE=Path(__file__).parent
OUT=Path('/private/tmp/jarde-testbreakwithlabel-ir-probe-root-v1-20261019')
source=ROOT/'crates/jarde-java/src/build.rs'; original=source.read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
pins=json.loads((PREP/'pins.json').read_bytes())
for x in [pins['source'],pins['patch'],pins['probe'],pins['readme'],*pins['class_inputs'].values(),*pins['inputs'].values()]:
 b=Path(x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'],x['path']
assert sha(original)==pins['source']['sha256'] and not (ROOT/'target').exists() and not OUT.exists()
(HERE/'original-build.rs').write_bytes(original)
probe=(PREP/'probe.rs').read_bytes();assert original.endswith(b'\n}\n')
candidate=original[:-3]+b'\n'+probe+b'\n}\n'
# The reviewed one-test fragment is inserted only into the terminal tests module.
(HERE/'candidate-build.rs').write_bytes(candidate)
argv=['python3','-B',str(ROOT/'openspec/changes/recover-branch-throw-return-finally/tools/run_validation.py'),str(OUT),str(HERE/'commands.json')]
(HERE/'commands.json').write_text(json.dumps([['cargo','test','-p','jarde-java','--lib','build::tests::test_break_with_label_slot3_boolean_ssa_probe','--','--exact','--nocapture']],indent=2)+'\n')
r={'status':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'source_before_sha256':sha(original),'candidate_sha256':sha(candidate),'pins':pins}
try:
 source.write_bytes(candidate)
 with (HERE/'runner.stdout.raw').open('xb') as so,(HERE/'runner.stderr.raw').open('xb') as se:
  proc=subprocess.run(argv,cwd=ROOT,stdout=so,stderr=se)
 r['runner_exit_code']=proc.returncode
 assert proc.returncode==0
 receipt=json.loads((OUT/'execution.json').read_bytes());assert receipt['source_unchanged'] and receipt['target_absent'] and receipt['status']=='commands_passed_pending_independent_acceptance'
 row=receipt['commands'][0];raw=Path(row['streams']['stdout']['path']).read_text()
 assert raw.count('test build::tests::test_break_with_label_slot3_boolean_ssa_probe ...')==1 and '1 passed; 0 failed;' in raw,raw
 r['status']='root_executed_real_ir_probe_pending_architecture_review'
except BaseException as e:
 r.update(status='failed',error=repr(e));raise
finally:
 r['candidate_unchanged_until_restore']=source.read_bytes()==candidate
 source.write_bytes(original)
 r['source_restored_exact']=source.read_bytes()==original;r['target_absent']=not (ROOT/'target').exists()
 r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (HERE/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({k:r[k] for k in ('status','source_restored_exact','target_absent')}))
