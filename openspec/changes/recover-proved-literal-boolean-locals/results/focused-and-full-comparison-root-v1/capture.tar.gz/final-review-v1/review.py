#!/usr/bin/env python3
"""Read-only reviewer for the frozen TestBreakWithLabel final-candidate capture."""
from __future__ import annotations
import argparse, base64, hashlib, importlib.util, json, os, re, zipfile
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
BASE=Path('/private/tmp/jarde-testbreakwithlabel-baseline-root-v1-20261019')
BASE_SHA='e2ca55f13812454af5441bcb78a68690e6d9cdf6f114a5e631b014acb9c8f75d'
BASE_REVIEW=BASE/'root-review.json'
BASE_REVIEW_SHA='145948b4549989fd3207b306f7e0aa25d097447dd683e5ce96a8fbcb9aa4efb5'
BASE_COLLECTOR=Path('/private/tmp/jarde-testbreakwithlabel-baseline-prep-luna-v3-20261019/collect_baseline.py')
BASE_COLLECTOR_SHA='c1b10d2ce72d40d7d82f0afe80b0df7363b34b773a346c7a9c946eb6ce12c92f'
CANDIDATE_COLLECTOR=Path('/private/tmp/jarde-testbreakwithlabel-final-candidate-prep-luna-v2-20261019/collect_final.py')
CANDIDATE_COLLECTOR_SHA='5d3f5c7cff83feb025b22e6254ca6cb5e4c538ef057b948ae71de79f3b55a48f'
COMPARE_REL='openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
MANIFEST_REL='openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
MANIFEST_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL='openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL='openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
DEPENDENCY=Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018/execution.json')
DEPENDENCY_SHA='5a7d6572e600d19dc45d78030d0b12867bc742c4b014381fb5c7b059db171d35'
RUNTIME=Path('/private/tmp/jarde-testnotindexedloop-baseline-prep-luna-v2-20261019/runtime-bound-cwd.py')
RUNTIME_SHA='bc917ec08e07ed462c18958f9a0d3b064b7d5bba3adc5fa41d9db49ff6c3de46'
UPSTREAM_SOURCE_SHA='fa38d5b302c0bec8a8424312304b260cfb036e0144f147fad1666aaa358b3a69'
UPSTREAM_SOURCE_BYTES=962
DRIVER=BASE/'driver-source/TestBreakWithLabelDriver.java'
DRIVER_SHA='033e0efc033d18df1098daec498852f1d53db22d2bd8f5af83e5b1f892266b5c'
INTERNAL='jadx/tests/integration/loops/TestBreakWithLabel$TestCls'
DOT='jadx.tests.integration.loops.TestBreakWithLabel$TestCls'
PROFILES=('debug','no-debug'); FORMS=('child','bundle-child'); EVIDENCE=('default','all'); VMS=('javac8','javac23')
CASE_EXPECTED={
'early-hit':('[[7,2],[3,4]];b=7','true','none','found: true\n'),
'late-hit':('[[1,2],[3,4]];b=4','true','none','found: true\n'),
'miss':('[[1,2],[3,4]];b=5','false','none','found: false\n'),
'null-outer':('<null-outer>;b=3','','java.lang.NullPointerException',''),
'null-row':('[[1],<null-row>];b=5','','java.lang.NullPointerException',''),
'hit-before-null-row':('[[7],<null-row>];b=7','true','none','found: true\n')}
CASES=tuple(CASE_EXPECTED)

def require(ok,msg):
    if not ok: raise AssertionError(msg)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def norm(x):
    if isinstance(x,dict): return {k:norm(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [norm(v) for v in x]
    return x
def pin(row,label):
    require(isinstance(row,dict) and {'path','bytes','sha256'}<=row.keys(),f'{label}: malformed file pin')
    original=Path(row['path']); require(not original.is_symlink(),f'{label}: symlink pin refused')
    p=original.resolve(strict=True); b=p.read_bytes()
    require(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],f'{label}: pin changed')
    return p
def pins(x,label='receipt'):
    found=[]
    if isinstance(x,dict):
        if {'path','bytes','sha256'}<=x.keys(): found.append((x,label)); return found
        for k,v in x.items(): found += pins(v,f'{label}.{k}')
    elif isinstance(x,list):
        for i,v in enumerate(x): found += pins(v,f'{label}[{i}]')
    return found
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot import {path}')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def utf8bounds(s):
    out={0}; n=0
    for c in s: n+=len(c.encode('utf-8')); out.add(n)
    return out
def decode_bytes(xs): return bytes(xs).decode('utf-8','strict')
def parse_rows(raw):
    lines=raw.decode('utf-8','strict').splitlines(); require(len(lines)==6,f'expected six rows, got {len(lines)}')
    rx=re.compile(r'^CASE index=(\d+) name=([^ ]+) input_b64=([^ ]*) result_b64=([^ ]*) exception=([^ ]+) exception_message_b64=([^ ]*) exception_stack_b64=([^ ]*) target_stdout_b64=([^ ]*)$')
    dec=lambda s:base64.b64decode(s,validate=True).decode('utf-8','strict'); rows=[]
    for i,line in enumerate(lines):
        m=rx.fullmatch(line); require(m is not None,f'malformed CASE row: {line!r}')
        ix,name,inp,result,exc,msg,stack,out=m.groups(); require(int(ix)==i and name==CASES[i],f'case order mismatch at {i}')
        rows.append({'index':i,'name':name,'input':dec(inp),'result':dec(result),'exception_type':exc,'exception_message':dec(msg),'exception_stack':dec(stack),'target_stdout':dec(out),'raw':line})
    return rows
def proj(rows): return [{k:r[k] for k in ('index','name','input','result','exception_type','target_stdout')} for r in rows]
def parse_facts(compare,physical,path,label):
    a=compare.parse_class(path); b=physical.parse_class_file(Path(path).read_bytes())
    require(a['class_name']==b['class_name'] and a['major']==b['major'] and a['methods']==b['methods'],f'{label}: parser methods/Code disagree')
    require(sorted((f['name'],f['descriptor'],f['access']) for f in b['fields'])==sorted(a['fields']),f'{label}: parser fields disagree')
    a['access']=b['access']; require(len({(m['name'],m['descriptor']) for m in a['methods']})==len(a['methods']),f'{label}: duplicate methods')
    for m in a['methods']:
        c=m.get('code'); require(c is not None and c.get('bcis') and c['bcis'][0]==0 and c['bcis'][-1]<c['code_length'],f'{label}: invalid Code/BCIs')
    return a
def walk_commands(data):
    cmds=data.get('commands',[]); by={x.get('index'):x for x in cmds}
    require(len(by)==len(cmds) and set(by)==set(range(1,len(cmds)+1)),'command index gaps/duplicates')
    labels=[x.get('label') for x in cmds]; require(None not in labels and len(labels)==len(set(labels)),'command labels missing/duplicated')
    for c in cmds:
        require(c.get('guard_stop') is None,f"guard stopped {c.get('label')}")
        require(Path(c.get('cwd','')).resolve()==ROOT.resolve(),f"command cwd differs from guarded workspace: {c.get('label')}")
        require(isinstance(c.get('peak_target_bytes'),int) and c['peak_target_bytes']<=1024**3,f"target cap exceeded: {c.get('label')}")
        require(isinstance(c.get('free_bytes_after'),int) and c['free_bytes_after']>=5*1024**3,f"disk guard: {c.get('label')}")
        require(c.get('env_overrides')==guard.ENV_VALUES,f"guard environment overrides differ: {c.get('label')}")
        require(isinstance(c.get('argv'),list) and c['argv'],f"missing argv: {c.get('label')}")
        for ch in ('stdout','stderr'): pin(c['streams'][ch],f"{c.get('label')} {ch}")
    return by
def method_map_issues(method,physical_method):
    body=(method.get('outcome') or {}).get('report') or {}; text=body.get('text'); sm=body.get('source_map')
    issues=[]; mapped=set()
    if not isinstance(text,str): return ['raw method text missing'],mapped,set()
    if not isinstance(sm,dict) or not isinstance(sm.get('segments'),list): return ['map/segments missing'],mapped,set()
    bounds=utf8bounds(text); phys=set((physical_method.get('code') or {}).get('bcis',[])); identity=method['item']['identity']
    raw=text.encode('utf-8')
    for i,s in enumerate(sm['segments']):
        st,en=s.get('start'),s.get('end')
        if type(st)!=int or type(en)!=int or not 0<=st<=en<=len(raw) or st not in bounds or en not in bounds:
            issues.append(f'segment {i} invalid UTF-8 bounds'); continue
        try: raw[st:en].decode('utf-8','strict')
        except UnicodeDecodeError: issues.append(f'segment {i} splits UTF-8 character')
        origin=s.get('origin'); refs=[]
        if not isinstance(origin,dict) or not isinstance(origin.get('primary'),dict): issues.append(f'segment {i} lacks primary origin'); continue
        derived=origin.get('derived',[])
        if not isinstance(derived,list): issues.append(f'segment {i} malformed derived origins'); continue
        refs=[origin['primary'],*derived]
        for ref in refs:
            if not isinstance(ref,dict): issues.append(f'segment {i} malformed origin ref'); continue
            bci=ref.get('bci'); ident=ref.get('method')
            if type(bci)!=int or bci not in phys: issues.append(f'segment {i} nonphysical BCI {bci!r}')
            else: mapped.add(bci)
            if ident!=identity: issues.append(f'segment {i} origin method identity differs')
    return issues,mapped,phys
def strip_usage(x):
    if isinstance(x,dict): return {k:strip_usage(v) for k,v in x.items() if k!='usage'}
    if isinstance(x,list): return [strip_usage(v) for v in x]
    return x
def differing_paths(a,b,path=()):
    if type(a)!=type(b): return {path}
    if isinstance(a,dict):
        out=set()
        for k in set(a)|set(b):
            if k not in a or k not in b: out.add(path+(k,))
            else: out |= differing_paths(a[k],b[k],path+(k,))
        return out
    if isinstance(a,list):
        if len(a)!=len(b): return {path+('<length>',)}
        out=set()
        for i,(x,y) in enumerate(zip(a,b)): out |= differing_paths(x,y,path+(i,))
        return out
    return set() if a==b else {path}
def validate_receipt(path, expected_cli):
    receipt=json.loads(Path(path).read_text(encoding='utf-8'))
    require(receipt.get('schema')=='test-break-with-label-final-jarde-candidate-v1','candidate schema mismatch')
    require(receipt.get('status')=='captured-pending-independent-review','candidate receipt is not a successful terminal capture')
    require(Path(receipt['root']).resolve()==ROOT.resolve(),'workspace root mismatch')
    require(receipt.get('candidate_cli_sha256_required')==expected_cli,'collector CLI argument pin mismatch')
    require(receipt['candidate_cli']['sha256']==expected_cli and sha(receipt['candidate_cli']['path'])==expected_cli,'CLI pin mismatch')
    compare_path=pin(receipt['compare'],'compare helper'); parser=pin(receipt['physical_parser'],'physical parser')
    require(sha(compare_path)==COMPARE_SHA and compare_path==ROOT/COMPARE_REL,'compare helper pin/path mismatch')
    require(parser==PARSER.resolve() and sha(parser)==PARSER_SHA,'physical parser pin mismatch')
    require(receipt['jdk_manifest']['sha256']==MANIFEST_SHA and Path(receipt['jdk_manifest']['path']).resolve()==(ROOT/MANIFEST_REL).resolve(),'JDK manifest identity mismatch')
    require(sha(ROOT/MANIFEST_REL)==MANIFEST_SHA,'JDK manifest changed')
    require(sha(BASE/'execution.json')==BASE_SHA and sha(BASE_REVIEW)==BASE_REVIEW_SHA,'accepted baseline changed')
    require(sha(BASE_COLLECTOR)==BASE_COLLECTOR_SHA and sha(CANDIDATE_COLLECTOR)==CANDIDATE_COLLECTOR_SHA,'frozen collector source changed')
    compare=load(compare_path,'final_review_compare'); physical=load(parser,'final_review_physical')
    guard=load(ROOT/GUARD_REL,'final_review_guard')
    by=walk_commands(receipt)
    pin_records=pins(receipt)
    for row,label in pin_records: pin(row,label)
    require(receipt.get('source_unchanged') is True and receipt.get('source_unchanged_finally') is True,'workspace source closure guard failed')
    require(receipt.get('source_pins_before')==receipt.get('source_pins_after')==receipt.get('source_pins_after_finally'),'workspace source snapshots differ')
    require(receipt.get('external_inputs_unchanged') is True and receipt.get('external_inputs_unchanged_finally') is True,'external-input closure guard failed')
    require(receipt.get('external_input_pins_before')==receipt.get('external_input_pins_after')==receipt.get('external_input_pins_after_finally'),'external snapshots differ')
    require(receipt.get('target_absent') is True and receipt.get('target_absent_finally') is True,'workspace target appeared')
    require(receipt.get('generated_outputs_unchanged') is True,'generated outputs changed during capture')
    require(receipt.get('driver_classes_unchanged') is True and receipt.get('runtime_wrapper_copy_unchanged') is True,'driver/wrapper copy changed')
    require(receipt.get('generated_source_copy_pins_before')==receipt.get('generated_source_copy_pins_after'),'generated source snapshots differ')
    require(receipt.get('generated_class_trees_before')==receipt.get('generated_class_trees_after'),'generated class snapshots differ')
    # Verify the immutable accepted baseline and its exact six-case expected behavior.
    base=json.loads((BASE/'execution.json').read_text(encoding='utf-8')); marker=json.loads(BASE_REVIEW.read_text(encoding='utf-8'))
    require(receipt['source']['sha256']==UPSTREAM_SOURCE_SHA and receipt['source']['bytes']==UPSTREAM_SOURCE_BYTES,'candidate is not bound to the complete upstream source')
    require(pin(receipt['source'],'complete upstream source').read_bytes()==pin(receipt['source_copy'],'copied upstream source').read_bytes(),'upstream source copy differs')
    require(marker.get('status')=='root_accepted_complete_original_baseline_with_explicit_boolean_local_stdout_gap','baseline root marker changed')
    require(marker.get('execution',{}).get('sha256')==BASE_SHA,'baseline review does not bind baseline receipt')
    require(receipt['accepted_original_baseline']['sha256']==BASE_SHA and receipt['accepted_original_review']['sha256']==BASE_REVIEW_SHA,'candidate does not bind accepted baseline/review')
    base_profiles={x['profile']:x for x in base['source_profiles']}; base_runs={(x['profile'],x['runtime']):x for x in base['original_runtime']}
    require(set(base_profiles)==set(PROFILES) and set(base_runs)=={(p,v) for p in PROFILES for v in VMS},'accepted baseline grid incomplete')
    for run in base_runs.values():
        rows=run['rows']; require(len(rows)==6 and [x['name'] for x in rows]==list(CASES),'baseline original case grid/order changed')
        require([(r['input'],r['result'],r['exception_type'],r['target_stdout']) for r in rows]==[CASE_EXPECTED[n] for n in CASES],'accepted original oracle differs from six expected cases')
    require(receipt['original_oracles_reused']=={f'{p}/{v}':base_runs[(p,v)] for p in PROFILES for v in VMS},'reused original oracle records differ from accepted receipt')
    require(receipt['accepted_jadx_evidence_reused']['jarde_cells']==base['jarde_cells'] and receipt['accepted_jadx_evidence_reused']['jadx_outputs']==base['jadx_outputs'],'Jarde/JADX evidence is not exact baseline reuse')
    # Driver and dependency isolation pins.
    require(receipt['driver_source']['sha256']==DRIVER_SHA and Path(receipt['driver_source']['path']).resolve()==DRIVER.resolve(),'driver source identity changed')
    driver_path=pin(receipt['driver_source'],'driver source'); require(driver_path.read_text(encoding='utf-8').find('hit-before-null-row')>=0,'driver lacks six-case distinguishing control')
    require(receipt['runtime_wrapper']['sha256']==RUNTIME_SHA and Path(receipt['runtime_wrapper']['path']).resolve()==RUNTIME.resolve(),'runtime wrapper changed')
    dep=json.loads(DEPENDENCY.read_text(encoding='utf-8')); require(sha(DEPENDENCY)==DEPENDENCY_SHA,'runtime dependency reference changed')
    for row in receipt['dependency_artifacts']: pin(row,'driver dependency artifact')
    require(receipt['dependency_classpath']==dep['classpath'],'dependency classpath differs from accepted parentless driver baseline')
    expected_deps=[dep['harness_jar'],*dep.get('jar_pins',[])]
    require([(x['bytes'],x['sha256']) for x in receipt['dependency_artifacts']]==[(x['bytes'],x['sha256']) for x in expected_deps],'dependency artifact set differs from accepted driver closure')
    driver_root=BASE/'driver-classes'
    expected_driver={p.relative_to(driver_root).as_posix():sha(p) for p in sorted(driver_root.rglob('*.class'))}
    actual_driver={Path(x['path']).relative_to(driver_root).as_posix():x['sha256'] for x in receipt['driver_classes']}
    require(actual_driver==expected_driver,'reused parentless driver class inventory/content differs')
    copy_before=receipt['driver_class_copies_before']; copy_root=Path(receipt['output']).resolve()/'driver-classes'
    require({k:v['sha256'] for k,v in copy_before.items()}==expected_driver,'copied parentless driver classes differ from pinned baseline classes')
    for rel,row in copy_before.items(): require(pin(row,'copied driver class')==copy_root/rel,'driver class copy escaped its private output root')
    wrapper_source=pin(receipt['runtime_wrapper'],'runtime wrapper source')
    wrapper_copy=pin(receipt['runtime_wrapper_copy'],'runtime wrapper copy')
    require(wrapper_source==RUNTIME.resolve() and wrapper_source.read_bytes()==wrapper_copy.read_bytes(),'runtime wrapper copy differs from pinned helper')
    require(wrapper_copy==Path(receipt['output']).resolve()/'runtime-bound-cwd.py','runtime wrapper copy escaped output root')
    # JDK tools are required to match the frozen manifest, not merely collector labels.
    jdks,manifest_tools=compare.configured_jdks(ROOT/MANIFEST_REL,MANIFEST_SHA)
    for leg in VMS:
        for tool in ('java','javac','javap'):
            got=receipt['jdk_manifest']['tools'][leg][tool]; p=pin(got,f'{leg} {tool}')
            require(p==Path(jdks[leg]['tools'][tool]).resolve() and got['sha256']==manifest_tools['tools'][leg][tool]['sha256'],f'{leg} {tool} differs from manifest')
    require(len(receipt['commands'])==72,'expected final collector command count 72')
    counts=receipt.get('counts_derived_from_commands',{})
    require(counts=={'commands':72,'raw_streams':144,'final_jarde_api_calls':8,'generated_source_compiles':16,'generated_vm_runs':32,'generated_wrong_root_runs':16},'collector command summary disagrees with actual ledger')
    labels={c['label']:c for c in receipt['commands']}
    require(len(receipt['jarde_cells'])==8 and len(receipt['generated_source_cells'])==8 and len(receipt['generated_source_compilations'])==16 and len(receipt['generated_runtime'])==32 and len(receipt['generated_wrong_root_controls'])==16,'candidate work grid incomplete')
    api_keys=set(); api_docs={}; original_facts={}
    for profile,pr in base_profiles.items():
        root=Path(pr['class_root']).resolve(strict=True); recorded=pr['class_tree']
        actual={x.relative_to(root).as_posix():x for x in sorted(root.rglob('*.class'))}
        require(set(actual)==set(recorded),f'baseline {profile} complete class tree paths differ')
        for rel,path in actual.items(): require(path.stat().st_size==recorded[rel]['bytes'] and sha(path)==recorded[rel]['sha256'],f'baseline {profile} class changed: {rel}')
        target=root/(INTERNAL+'.class'); facts=parse_facts(compare,physical,target,f'baseline {profile} target')
        require(facts['class_name']==INTERNAL and facts['major']==52 and norm(facts)==norm(pr['target_facts']),'baseline target facts differ from accepted receipt')
        bundle=pin(pr['bundle'],f'baseline {profile} class bundle')
        with zipfile.ZipFile(bundle) as z:
            names=sorted(n for n in z.namelist() if not n.endswith('/'))
            require(names==sorted(recorded),f'baseline {profile} bundle inventory differs')
            for rel in names: require(z.read(rel)==actual[rel].read_bytes(),f'baseline {profile} bundle bytes differ: {rel}')
        original_facts[profile]={(m['name'],m['descriptor']):m for m in facts['methods']}
    # Verify each API request, original raw API JSON, full text and its summaries/maps.
    for cell in receipt['jarde_cells']:
        key=(cell['profile'],cell['input_form'],cell['evidence']); require(key not in api_keys,'duplicate API cell'); api_keys.add(key)
        require(key[0] in PROFILES and key[1] in FORMS and key[2] in EVIDENCE,'unknown API key')
        cmd=by[cell['command']]; wantlabel=f'final-jarde-{key[0]}-{key[1]}-{key[2]}'
        require(cmd['label']==wantlabel and cmd['exit_code']==0==cell['exit_code'],'API command failed/mismatched')
        expected_input=(Path(base_profiles[key[0]]['class_root'])/(INTERNAL+'.class')) if key[1]=='child' else Path(base_profiles[key[0]]['bundle']['path'])
        expected_input=expected_input.resolve(strict=True); require(pin(cell['input'],'API input')==expected_input,'API input is not accepted original class/JAR')
        a=cmd['argv']; require(Path(a[0]).resolve()==Path(receipt['candidate_cli']['path']).resolve() and a[1:3]==['class-source','--input'] and Path(a[3]).resolve()==expected_input,'API argv input mismatch')
        require(a[a.index('--class')+1]==INTERNAL and a[a.index('--policy')+1]==('single-class' if key[1]=='child' else 'plain-jar') and a[a.index('--release')+1]=='8' and a[a.index('--format')+1]=='json','API selector argv mismatch')
        require(('--evidence' not in a) if key[2]=='default' else a[a.index('--evidence')+1]=='all','API evidence argv mismatch')
        report_path=pin(cell['report'],'raw API report'); raw=report_path.read_bytes(); require(raw==pin(cmd['streams']['stdout'],'API raw stdout').read_bytes(),'API report not exact raw stdout')
        doc=json.loads(raw.decode('utf-8','strict')); whole=pin(cell['whole_source'],'whole class source').read_bytes(); require(doc['text'].encode('utf-8')==whole,'whole source differs from API JSON')
        target_bytes=(expected_input.read_bytes() if key[1]=='child' else zipfile.ZipFile(expected_input).read(INTERNAL+'.class'))
        require(len(doc['methods'])==3 and len(cell['methods'])==3,'API physical inventory must include all three methods')
        rawmethods={(m['item']['name']['escaped'],m['item']['descriptor']['escaped']):m for m in doc['methods']}
        summaries={(m['name'],m['descriptor']):m for m in cell['methods']}; require(set(rawmethods)==set(summaries)==set(original_facts[key[0]]),'API method identity inventory mismatch')
        for ident,m in rawmethods.items():
            s=summaries[ident]; identity=m['item']['identity']; owner=identity['owner']; body=(m.get('outcome') or {}).get('report') or {}
            require(s['identity']==identity and identity.get('owner')==owner and owner.get('location') is not None and owner.get('variant') is not None,'API summary physical identity differs')
            require(owner==doc['class'] and owner['class_bytes']['length']==len(target_bytes),'method owner/class bytes do not match input')
            require(decode_bytes(identity['name'])==ident[0] and decode_bytes(identity['descriptor'])==ident[1],'method raw identity encoding mismatch')
            require(s['outcome_kind']==m['outcome']['kind'] and s['quality']==body.get('quality') and s['raw_text']==body.get('text') and s['source_map']==body.get('source_map') and s['fallbacks']==body.get('fallbacks') and s['regions']==body.get('regions'),'raw method summary differs from report')
            issues,mapped,physical_bcis=method_map_issues(m,original_facts[key[0]][ident]); require(not issues,f'{key}/{ident} invalid map: {issues}')
            ma=s['map_audit']; require(ma['map_present'] is True and ma.get('issues')==[] and set(ma['mapped_bcis'])==mapped and set(ma['physical_bcis'])==physical_bcis and ma['unmapped_physical_bcis']==sorted(physical_bcis-mapped) and ma['covers_all_physical_bcis']==(mapped==physical_bcis),'stored map audit differs from raw map')
            if physical_bcis-mapped: pass # retained as a real gap; never require total BCI coverage
        targ=rawmethods[('test','([[II)Z')]; require(targ['outcome']['kind']=='recovered' and targ['outcome']['report']['quality']=='structured','target test is not structured')
        inventory=sorted(rawmethods); expected_inventory=sorted(original_facts[key[0]])
        require(cell['physical_method_inventory']==[list(x) for x in inventory] and cell['expected_physical_method_inventory']==[list(x) for x in expected_inventory],'stored physical method inventory differs from raw report')
        tsum=summaries[('test','([[II)Z')]
        require(cell['target_test_quality']==tsum['quality'] and cell['target_test_outcome']==tsum['outcome_kind'] and cell['target_test_map_audit']==tsum['map_audit'],'stored target summary differs from method summary')
        require(cell['method_inventory_matches'] is True and cell['all_method_maps_valid'] is True,'collector API gate is false')
        api_docs[key]=doc
    require(api_keys=={(p,f,e) for p in PROFILES for f in FORMS for e in EVIDENCE},'API selector grid incomplete')
    # Default/all differences must stay inside evidence-dependent paths already observed in the accepted baseline.
    base_api={(x['profile'],x['input_form'],x['evidence']):json.loads(Path(x['report']['path']).read_text()) for x in base['jarde_cells']}
    allowed_by=(lambda p,f: differing_paths(strip_usage(base_api[(p,f,'default')]),strip_usage(base_api[(p,f,'all')])))
    for p in PROFILES:
        for f in FORMS:
            d,a=api_docs[(p,f,'default')],api_docs[(p,f,'all')]
            require(d['text']==a['text'],'default/all whole class text differs')
            for md,ma in zip(d['methods'],a['methods']):
                require(md['item']['identity']==ma['item']['identity'] and md['outcome']['kind']==ma['outcome']['kind'],'default/all method identity/outcome differs')
                bd=md['outcome'].get('report') or {}; ba=ma['outcome'].get('report') or {}
                require(bd.get('quality')==ba.get('quality') and bd.get('text')==ba.get('text') and bd.get('source_map')==ba.get('source_map'),'default/all raw method text/map/quality differs')
            actual=differing_paths(strip_usage(d),strip_usage(a)); allowed=allowed_by(p,f)
            require(actual<=allowed,f'{p}/{f}: non-usage report differences extend beyond accepted evidence-dependent paths: {actual-allowed}')
    # Verify every whole source is copied byte-for-byte and every successful compile is a complete inventory.
    sourcecells={(x['profile'],x['form'],x['evidence']):x for x in receipt['generated_source_cells']}
    require(len(sourcecells)==8 and set(sourcecells)==api_keys,'generated source-cell grid incomplete')
    for key,sc in sourcecells.items():
        require(sc['source_available'] is True,'generated full-source output missing')
        src=pin(sc['source_pin'],'generated API whole source'); cp=pin(sc['source_copy'],'copied generated source')
        expected_source=(Path(receipt['output'])/'jarde'/key[0]/key[1]/key[2]/'whole-source.java').resolve()
        require(Path(sc['source_path']).resolve()==expected_source and src==expected_source,'generated source path is not the complete API artifact')
        require(src.read_bytes()==cp.read_bytes()==Path(sc['source_path']).read_bytes(),'generated Java was changed')
        require(Path(sc['source_path']).read_bytes()==src.read_bytes(),'source path bytes differ from API output')
        require(len(sc['java_files'])==1 and Path(sc['java_files'][0]).resolve()==cp,'generated source file inventory mismatch')
    compkeys=set(); comp_by={}
    for cr in receipt['generated_source_compilations']:
        key=(cr['profile'],cr['form'],cr['evidence'],cr['compiler']); require(key not in compkeys,'duplicate compile cell'); compkeys.add(key); comp_by[key]=cr
        require(cr['exit_code']==0 and cr['runtime_eligible'] is True and cr['class_facts_error'] is None,'generated compile failed or ineligible')
        cmd=by[cr['command']]; require(cmd['label']==f"rebuild-jarde-{key[0]}-{key[1]}-{key[2]}-{key[3]}" and cmd['exit_code']==0,'compile command linkage failed')
        a=cmd['argv']; leg=key[3]; javac=receipt['jdk_manifest']['tools'][leg]['javac']['path']; require(Path(a[0]).resolve()==Path(javac).resolve(),'compile used wrong compiler')
        src=sourcecells[key[:3]]['java_files'][0]; require(Path(src).resolve() in [Path(x).resolve() for x in a],'compile omitted complete API source')
        require('-proc:none' in a and '-encoding' in a and a[a.index('-encoding')+1]=='UTF-8' and '-classpath' in a and a[a.index('-classpath')+1]==os.pathsep.join(receipt['dependency_classpath']),'compile classpath/encoding/processor options differ')
        require('-sourcepath' in a and Path(a[a.index('-sourcepath')+1]).is_dir() and not list(Path(a[a.index('-sourcepath')+1]).iterdir()),'compile sourcepath not isolated')
        require(('-g' if key[0]=='debug' else '-g:none') in a,'compile debug profile differs')
        require(('--release' in a and a[a.index('--release')+1]=='8') if leg=='javac23' else ('-source' in a and a[a.index('-source')+1]=='8' and '-target' in a and a[a.index('-target')+1]=='8'),'compile release/source level differs')
        root=Path(cr['class_root']).resolve(strict=True); expected_root=(Path(receipt['output'])/'generated-classes'/key[0]/key[1]/key[2]/key[3]).resolve()
        require(root==expected_root and '-d' in a and Path(a[a.index('-d')+1]).resolve()==root,'generated classes escaped their cell output root')
        tree={p.relative_to(root).as_posix():{'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(root.rglob('*.class'))}
        require(set(tree)==set(cr['class_tree']),'complete generated class tree inventory differs')
        for rel,row in cr['class_tree'].items():
            p=pin(row,f'generated class {rel}'); require(p==root/rel and tree[rel]['sha256']==row['sha256'],'generated class bytes/root differ')
            facts=parse_facts(compare,physical,p,f'generated {key} {rel}')
            require(facts['major']==52,'generated class is not Java 8 bytecode')
            require(rel in cr['class_facts'] and norm(facts)==norm(cr['class_facts'][rel]),f'generated parser facts differ from receipt: {rel}')
        tf=cr['target_facts']; require(tf['class_name']==INTERNAL and tf['major']==52,'generated target facts identity/version mismatch')
        require(norm(tf)==norm(cr['class_facts'][INTERNAL+'.class']),'target_facts differ from complete class-facts inventory')
        orig=original_facts[key[0]]; require({(m['name'],m['descriptor'],m['access']) for m in tf['methods']}=={(m['name'],m['descriptor'],m['access']) for m in orig.values()},'generated target method/access inventory differs')
        require({tuple(x) for x in tf['fields']}=={tuple(x) for x in base_profiles[key[0]]['target_facts']['fields']},'generated target field inventory differs')
    require(compkeys=={(p,f,e,v) for p in PROFILES for f in FORMS for e in EVIDENCE for v in VMS},'generated compile grid incomplete')
    expected_labels={f'final-jarde-{p}-{f}-{e}' for p in PROFILES for f in FORMS for e in EVIDENCE}
    expected_labels|={f'rebuild-jarde-{p}-{f}-{e}-{v}' for p in PROFILES for f in FORMS for e in EVIDENCE for v in VMS}
    expected_labels|={f'wrong-root-jarde-{p}-{f}-{e}-{v}' for p in PROFILES for f in FORMS for e in EVIDENCE for v in VMS}
    expected_labels|={f'runtime-jarde-{p}-{f}-{e}-{c}-{v}' for p in PROFILES for f in FORMS for e in EVIDENCE for c in VMS for v in VMS}
    require(set(labels)==expected_labels,'actual command labels do not exactly cover the 72-cell matrix')
    # Every eligible compiled root has one wrong-CodeSource rejection and both positive VM legs.
    wrongkeys=set()
    for w in receipt['generated_wrong_root_controls']:
        key=(w['profile'],w['form'],w['evidence'],w['compiler']); require(key not in wrongkeys,'duplicate generated wrong-root cell'); wrongkeys.add(key)
        cr=comp_by[key]; actual=Path(cr['class_root']).resolve(strict=True); wrong=Path(w['expected_wrong_root']).resolve(strict=True)
        cmd=by[w['command']]; a=cmd['argv']; require(cmd['label']==f"wrong-root-jarde-{key[0]}-{key[1]}-{key[2]}-{key[3]}" and cmd['exit_code']==1 and w['exit_code']==1 and w['rejected_before_target_case_output'] is True,'wrong-root control failed to reject')
        require(len(a)==13 and a[1]=='-B' and Path(a[2]).resolve()==Path(receipt['output']).resolve()/'runtime-bound-cwd.py' and a[3]=='30' and Path(a[5]).resolve()==Path(receipt['jdk_manifest']['tools']['javac23']['java']['path']).resolve() and a[6]=='-Xverify:all' and a[7]=='-cp','wrong-root runtime wrapper/JVM argv mismatch')
        driver=Path(a[8]).resolve(); require(driver==Path(receipt['output']).resolve()/'driver-classes' and a[9]=='TestBreakWithLabelDriver','wrong-root driver-only classpath mismatch')
        require(Path(a[10]).resolve()==actual and Path(a[10]).resolve()==Path(w['actual_target_root']).resolve() and Path(a[11]).resolve()==wrong and Path(a[12]).resolve()==Path(a[4]).resolve(),'wrong-root target/expected/cwd mapping mismatch')
        require(Path(a[4]).resolve()==(Path(receipt['output'])/'wrong-root-cwd'/key[0]/key[1]/key[2]/key[3]).resolve(),'wrong-root cwd not bound to its exact cell')
        require(wrong==Path(receipt['output']).resolve()/'empty-wrong-root' and not list(wrong.iterdir()),'wrong-root expected root is not the isolated empty root')
        require(b'wrong CodeSource:' in pin(w['stderr'],'wrong-root stderr').read_bytes() and b'CASE ' not in pin(w['stdout'],'wrong-root stdout').read_bytes(),'wrong-root was not rejected before observations')
        cwd=Path(a[4]).resolve(strict=True); require(not list(cwd.iterdir()),'wrong-root cwd not empty')
    require(wrongkeys==compkeys,'one wrong-root control is required per successful compiled root')
    runtimes={}
    for run in receipt['generated_runtime']:
        key=(run['profile'],run['form'],run['evidence'],run['compiler'],run['runtime']); require(key not in runtimes,'duplicate runtime cell'); runtimes[key]=run
        ck=key[:4]; cr=comp_by[ck]; cmd=by[run['command']]; a=cmd['argv']; target=Path(cr['class_root']).resolve(strict=True)
        require(cmd['label']==f"runtime-jarde-{key[0]}-{key[1]}-{key[2]}-{key[3]}-{key[4]}" and cmd['exit_code']==0 and run['exit_code']==0,'positive runtime command failed')
        require(len(a)==13 and a[1]=='-B' and Path(a[2]).resolve()==Path(receipt['output']).resolve()/'runtime-bound-cwd.py' and a[3]=='30' and Path(a[5]).resolve()==Path(receipt['jdk_manifest']['tools'][key[4]]['java']['path']).resolve() and a[6]=='-Xverify:all' and a[7]=='-cp','positive runtime argv/JDK mismatch')
        require(Path(a[8]).resolve()==Path(receipt['output']).resolve()/'driver-classes' and a[9]=='TestBreakWithLabelDriver' and Path(a[10]).resolve()==target==Path(a[11]).resolve() and Path(a[12]).resolve()==Path(a[4]).resolve(),'positive target root/driver isolation mismatch')
        require(Path(run['class_root']).resolve()==target,'runtime record target root differs from compile row')
        require(Path(a[4]).resolve()==(Path(receipt['output'])/'runtime-cwd'/key[0]/key[1]/key[2]/key[3]/key[4]).resolve(),'positive runtime cwd not bound to exact cell')
        require(len(run['rows'])==6 and parse_rows(pin(run['stdout'],'runtime stdout').read_bytes())==run['rows'],'runtime stdout rows do not match receipt')
        expected=base_runs[(key[0],key[4])]['rows']; require(proj(run['rows'])==proj(expected) and run['matches_original_oracle'] is True,'generated runtime differs from accepted original oracle')
        cwd=Path(a[4]).resolve(strict=True); require(not list(cwd.iterdir()),'positive runtime cwd not empty')
    require(len(runtimes)==32 and set(runtimes)=={(p,f,e,c,v) for p in PROFILES for f in FORMS for e in EVIDENCE for c in VMS for v in VMS},'generated positive VM grid incomplete')
    # Verify receipt-internal artifact tree snapshots, plus current target absence (do not compare evolved source to old baseline).
    findings=[]
    for cell in receipt['jarde_cells']:
        target=next(m for m in cell['methods'] if (m['name'],m['descriptor'])==('test','([[II)Z'))
        gaps=target['map_audit'].get('unmapped_physical_bcis',[])
        if gaps: findings.append({'cell':(cell['profile'],cell['input_form'],cell['evidence']),'unmapped_test_bcis':gaps})
    return {'status':'reviewed_capture_integrity_and_semantics','receipt_sha256':sha(path),'command_count':len(receipt['commands']),'api_cells':len(api_keys),'compile_cells':len(compkeys),'positive_vm_cells':len(runtimes),'wrong_root_cells':len(wrongkeys),'runtime_observations':sum(len(x['rows']) for x in runtimes.values()),'findings':findings}

def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--receipt',type=Path,required=True); ap.add_argument('--expected-cli-sha256',required=True); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args()
    require(len(a.expected_cli_sha256)==64 and re.fullmatch('[0-9a-f]{64}',a.expected_cli_sha256) is not None,'expected CLI SHA must be lowercase 64-hex')
    require(not a.out.exists(),'refusing existing review output')
    result=validate_receipt(a.receipt.resolve(strict=True),a.expected_cli_sha256)
    a.out.parent.mkdir(parents=True,exist_ok=True); a.out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(result,sort_keys=True)); return 0
if __name__=='__main__': raise SystemExit(main())
