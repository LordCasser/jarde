# TestBreakWithLabel final-candidate independent review preparation

This private, read-only reviewer is prepared for the v2 final-candidate collector. It has not been run against a final-candidate receipt; no CLI, Java compiler/runtime, Cargo, or target method was executed here. Root must supply the final candidate CLI SHA when running the reviewer.

`review.py` accepts a completed collector receipt, a required CLI SHA-256, and a new output path. It validates the actual 72-command ledger (8 API calls, 16 full-source Java 8 compile attempts, 32 positive VM runs, and 16 per-compiled-root wrong-CodeSource controls), while deriving and checking every selector key and command label. It reopens receipt file pins and raw streams, checks the accepted baseline and its root marker, validates the six ordered cases including `hit-before-null-row`, and binds the reused original/JADX evidence to the accepted baseline without calling those old rows new runs.

The reviewer checks the full Jarde class-source reports and complete copied source, independent class parsers and method/field inventories, UTF-8-safe source-map spans and physical method/BCI identities, compiler arguments, full generated class trees, parentless runtime arguments, empty cwd and pre-invocation wrong-root rejection. Each successful generated VM row is matched against the corresponding accepted original profile/runtime observation. It requires source, external input, tool, wrapper, driver, and generated-output snapshots to remain stable and checks the recorded target absence. The source-map audit records unmapped BCIs; it does not require every physical BCI to have a rendered segment.

Default/all report comparison is intentionally scoped: whole-class text and each method's identity, outcome, quality, raw text, and map must agree. Other non-usage JSON differences may occur only at paths already observed to vary between default/all in the accepted baseline; this avoids masking new evidence-dependent output changes with a blanket JSON ignore.

The reviewer is intentionally separate from the collector and cannot establish product or CI acceptance. An assertion failure is preserved as a review finding to resolve against the receipt; it must not be handled by weakening the fixed grids or semantic checks.

Run after root has a terminal v2 receipt and provides the exact CLI pin:

```sh
python3 -B /private/tmp/jarde-testbreakwithlabel-final-review-luna-v1-20261019/review.py \
  --receipt /path/to/final/execution.json \
  --expected-cli-sha256 ROOT_SUPPLIED_64_HEX_SHA \
  --out /private/tmp/jarde-testbreakwithlabel-final-review-luna-v1-20261019/review.json
```

## Frozen inputs

- Candidate collector: `/private/tmp/jarde-testbreakwithlabel-final-candidate-prep-luna-v2-20261019/collect_final.py`, SHA-256 `5d3f5c7cff83feb025b22e6254ca6cb5e4c538ef057b948ae71de79f3b55a48f`.
- Accepted original baseline receipt: `/private/tmp/jarde-testbreakwithlabel-baseline-root-v1-20261019/execution.json`, SHA-256 `e2ca55f13812454af5441bcb78a68690e6d9cdf6f114a5e631b014acb9c8f75d`.
- Accepted baseline marker: `/private/tmp/jarde-testbreakwithlabel-baseline-root-v1-20261019/root-review.json`, SHA-256 `145948b4549989fd3207b306f7e0aa25d097447dd683e5ce96a8fbcb9aa4efb5`.
- Baseline audit used for historical contract reference: `/private/tmp/jarde-testbreakwithlabel-baseline-review-luna-v4-20261019/audit.py`, SHA-256 `2c1b2b3a9f0b8abcecb238a0d0c68428ea197020d846058d9f6ef546dc5d9ea3`.
- Pinned case driver SHA-256: `033e0efc033d18df1098daec498852f1d53db22d2bd8f5af83e5b1f892266b5c`.

This preparation was syntax-checked with Python AST parsing only. No final-candidate capture or product acceptance is claimed.
