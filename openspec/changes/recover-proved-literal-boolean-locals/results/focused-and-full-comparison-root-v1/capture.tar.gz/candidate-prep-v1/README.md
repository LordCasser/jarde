# TestBreakWithLabel final Jarde candidate collector

This is an unexecuted private collector for the final Boolean-recovery candidate. It reuses the root-accepted original/JADX baseline, its six-case original runtime oracle, precompiled parentless reflection driver, complete upstream source, and JDK guard helpers. It does not rerun the upstream source, JADX, or any original/JADX VM rows. The candidate CLI path and exact SHA are mandatory command-line arguments; no future binary pin is guessed or embedded.

The planned capture consists of exactly eight final Jarde `class-source` requests: debug/no-debug original class input and its plain JAR form, each with default/all evidence. It then copies each API's complete class-source body and performs both JDK 8 and JDK 23 Java-8 compilations for all eight cells (16 attempts). Every successful target is invoked in both VMs for the six original cases (32 invocations / 192 case observations). Each row is compared with the matching profile/runtime oracle from the accepted original receipt, including return value, exception class and exact target stdout. It retains full command streams and generated class inventories.

The root acceptance marker binds the original receipt and its independent review. The original execution receipt deliberately remains `captured-pending-independent-review`; the separate accepted review records its Boolean-local stdout limitation. The candidate capture records that provenance without relabeling the historical receipt. Original/JADX source/API artifacts and all six-case oracle streams are reopened against their original pins before candidate work begins.

For each final API cell, the collector requires the exact physical method inventory and a structured `test([[II)Z` body. The SourceMap audit checks UTF-8 byte bounds, valid physical BCIs and method identity. Unmapped physical BCIs are listed independently; total SourceMap coverage is not required. The collector does not treat map presence as proof that every BCI has a segment.

Run only after root supplies the final CLI path and SHA:

```sh
python3 -B /private/tmp/jarde-testbreakwithlabel-final-candidate-prep-luna-v1-20261019/collect_final.py \
  --root /Users/lordcasser/workspace/projects/jarde \
  --cli /absolute/path/to/root-supplied-candidate-cli \
  --cli-sha256 ROOT_SUPPLIED_64_HEX_SHA \
  --out /private/tmp/jarde-testbreakwithlabel-final-candidate-root-v1-20261019
```

The collector preserves a failure receipt if any cell is incomplete or differs. It binds source closure, CLI, JDK tools, runtime helper, dependency artifacts, and the reused baseline artifacts before/after the candidate capture. It refuses an existing output or workspace `target/`.

## Independent audit adaptation

The accepted baseline audit should not be run against this receipt unchanged. The schema is `test-break-with-label-final-jarde-candidate-v1`; only final Jarde API cells and Jarde-source compiler/runtime rows are newly collected. Original and JADX results are references to the separately accepted baseline receipt. Rebind the audit's expected schema and result locations, require eight candidate API cells, 16 Jarde compile attempts, 32 six-case runtime rows and 192 observations, then compare each runtime row against the pinned original oracle. Preserve the old source/JADX baseline audit and its documented gap as a separate accepted layer.

The SourceMap check should require no invalid-anchor issues and should publish `unmapped_physical_bcis` per method without requiring `covers_all_physical_bcis`. The method-quality gate applies specifically to target `test([[II)Z`; constructors and `check()V` retain their own reported outcomes. Do not rerun original/JADX compilers or target VMs as part of this candidate collector.

No CLI, JDK, compiler, Jarde command, or target method was run while preparing this collector.
