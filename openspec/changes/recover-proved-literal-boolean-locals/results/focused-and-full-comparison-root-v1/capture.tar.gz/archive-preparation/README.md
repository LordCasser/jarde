# TestBreakWithLabel evidence archive preparation

This private standard-library packer is prepared but unexecuted. It does not build, invoke Jarde/JADX, run Java, or contact the network. The requested archive destination is `openspec/changes/recover-proved-literal-boolean/results/focused-and-full-comparison-root-v1/capture.tar.gz`; root must review this tool and supply the accepted final-matrix root-review SHA before running it.

The packer refuses to run unless the final matrix root (passed explicitly) contains `execution.json` and `root-review.json`, the review has an accepted status, the supplied SHA exactly matches that review file, and the review binds the exact matrix execution receipt SHA. This keeps archival gated on the corrected v3 receipt review. The current visible final-review-execution-v2 directory exists, but the independently corrected matrix root review is still a future required input; the packer does not infer or invent its pin.

It requires every named evidence directory to exist, including final-review-execution-v2. Missing inputs fail the run. It preserves all files from the named controls, implementation, public tests, formatting, focused, JADX-reference, final-candidate, and reviewer/execution roots. The SI probe is omitted because it is already durably archived elsewhere. The only payload exclusion is the exact `focused-root-v4/candidate-cli` file; the inventory records its path, byte count, SHA-256, mode, and reason as an excluded external input. Other cache files, symlinks, non-regular files, or native executables fail closed.

The tool creates a deterministic gzip-compressed tar and sidecar inventory. Before returning it reopens the archive, verifies the exact member set, every payload byte/hash/mode, the inventory bytes, and that the source files stayed unchanged during packing. It includes real failed captures and static-review revisions as recorded; it does not make the precancellation case a mid-proof cancellation test.

After review and once root has the corrected accepted review file, the intended invocation is:

```sh
python3 -B /private/tmp/jarde-testbreakwithlabel-evidence-archive-prep-luna-v1-20261019/pack.py \
  --matrix-root /private/tmp/jarde-testbreakwithlabel-final-candidate-root-v1-20261019 \
  --accepted-root-review-sha256 89765493f08b5ab2d7cd0fd2d339b7993b4b2525405318b0487becc4e99cf125 \
  --out /Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-proved-literal-boolean-locals/results/focused-and-full-comparison-root-v1/capture.tar.gz
```

The final matrix directory is also included among the required roots; passing that same directory avoids duplicating its payload. The exact matrix-review filename is `root-review.json` inside the explicitly supplied matrix root. The accepted root review currently pins the completed matrix receipt (0c9a305a49d0c04a13f401da4598e8aa224062904478ca406cdeae3304d61b09); the invocation supplies its exact root-review SHA explicitly.
