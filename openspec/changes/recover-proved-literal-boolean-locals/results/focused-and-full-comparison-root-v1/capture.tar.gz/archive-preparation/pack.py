#!/usr/bin/env python3
"""Prepare a byte-verified archive of TestBreakWithLabel evidence; never runs evidence tools."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tarfile

TMP = Path('/private/tmp').resolve()
HERE = Path(__file__).resolve().parent
MAX_BYTES = 512 * 1024 * 1024

# All evidence roots are explicit and required. A missing future root is a hard failure.
FIXED_ROOTS = (
    ('controls', 'jarde-literal-boolean-controls-root-v1-20261019'),
    ('integration-review', 'jarde-literal-boolean-integration-review-root-v1-20261019'),
    ('implementation-v1', 'jarde-literal-boolean-impl-luna-v1-20261019'),
    ('implementation-v2', 'jarde-literal-boolean-impl-luna-v2-20261019'),
    ('public-tests-v3', 'jarde-proved-literal-boolean-public-tests-luna-v3-20261019'),
    ('public-tests-v4', 'jarde-proved-literal-boolean-public-tests-luna-v4-20261019'),
    ('format-prep-v1', 'jarde-literal-boolean-format-root-prep-v1-20261019'),
    ('format-prep-v2', 'jarde-literal-boolean-format-root-prep-v2-20261019'),
    ('format-root-v1', 'jarde-literal-boolean-format-root-v1-20261019'),
    ('format-root-v2', 'jarde-literal-boolean-format-root-v2-20261019'),
    ('focused-prep-v1', 'jarde-literal-boolean-focused-prep-root-v1-20261019'),
    ('focused-prep-v2', 'jarde-literal-boolean-focused-prep-root-v2-20261019'),
    ('focused-prep-v3', 'jarde-literal-boolean-focused-prep-root-v3-20261019'),
    ('focused-prep-v4', 'jarde-literal-boolean-focused-prep-root-v4-20261019'),
    ('focused-v1', 'jarde-literal-boolean-focused-root-v1-20261019'),
    ('focused-v2', 'jarde-literal-boolean-focused-root-v2-20261019'),
    ('focused-v3', 'jarde-literal-boolean-focused-root-v3-20261019'),
    ('focused-v4', 'jarde-literal-boolean-focused-root-v4-20261019'),
    ('jadx-reference', 'jarde-literal-boolean-jadx-reference-root-v1-20261019'),
    ('candidate-prep-v1', 'jarde-testbreakwithlabel-final-candidate-prep-luna-v1-20261019'),
    ('candidate-prep-v2', 'jarde-testbreakwithlabel-final-candidate-prep-luna-v2-20261019'),
    ('candidate-matrix', 'jarde-testbreakwithlabel-final-candidate-root-v1-20261019'),
    ('final-review-v1', 'jarde-testbreakwithlabel-final-review-luna-v1-20261019'),
    ('final-review-v2', 'jarde-testbreakwithlabel-final-review-luna-v2-20261019'),
    ('final-review-v3', 'jarde-testbreakwithlabel-final-review-luna-v3-20261019'),
    ('final-review-execution-v1', 'jarde-testbreakwithlabel-final-review-execution-root-v1-20261019'),
    ('final-review-execution-v2', 'jarde-testbreakwithlabel-final-review-execution-root-v2-20261019'),
)
EXCLUDED_RELATIVE = PurePosixPath('candidate-cli')


def fail(message: str) -> None:
    raise SystemExit(f'archive refused: {message}')


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def path_without_symlinks(path: Path) -> Path:
    absolute = path.absolute()
    for component in (absolute, *absolute.parents):
        if component.is_symlink():
            fail(f'symlink path component: {component}')
    return absolute


def file_record(path: Path) -> tuple[bytes, int]:
    source = path_without_symlinks(path)
    if not source.exists() or not source.is_file():
        fail(f'missing or non-regular input: {source}')
    before = source.stat()
    data = source.read_bytes()
    after = source.stat()
    mode = stat.S_IMODE(after.st_mode)
    if (before.st_size, before.st_mtime_ns, before.st_mode) != (after.st_size, after.st_mtime_ns, after.st_mode):
        fail(f'input changed while reading: {source}')
    if len(data) != after.st_size:
        fail(f'input size changed while reading: {source}')
    return data, mode


def native_executable(data: bytes, path: Path) -> bool:
    if path.suffix.lower() == '.class':
        return False
    return data.startswith((
        b'\x7fELF', b'MZ', b'\xfe\xed\xfa\xce', b'\xce\xfa\xed\xfe',
        b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe',
        b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca',
    ))


def accepted_review_gate(matrix: Path, expected_sha: str) -> dict:
    if len(expected_sha) != 64 or any(c not in '0123456789abcdef' for c in expected_sha):
        fail('--accepted-root-review-sha256 must be 64 lowercase hex characters')
    review_path = path_without_symlinks(matrix / 'root-review.json')
    if not review_path.is_file():
        fail(f'accepted matrix root-review is missing: {review_path}')
    data, mode = file_record(review_path)
    if sha(data) != expected_sha:
        fail('accepted matrix root-review SHA-256 does not match the explicitly supplied pin')
    try:
        review = json.loads(data.decode('utf-8'))
        receipt_path = path_without_symlinks(matrix / 'execution.json')
        receipt_data, _ = file_record(receipt_path)
        receipt = json.loads(receipt_data.decode('utf-8'))
    except (UnicodeDecodeError, json.JSONDecodeError, OSError) as exc:
        fail(f'matrix receipt/review is unreadable: {exc}')
    receipt_sha = sha(receipt_data)
    statuses = []
    bound_values = []

    def walk(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if key == 'status' and isinstance(item, str):
                    statuses.append(item.lower())
                walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)
        elif isinstance(value, str):
            bound_values.append(value)

    walk(review)
    if not any('accept' in value for value in statuses):
        fail('root-review does not contain an accepted status')
    if receipt_sha not in bound_values:
        fail('root-review does not bind the exact candidate execution receipt SHA-256')
    candidate_cli = receipt.get('candidate_cli')
    if not isinstance(candidate_cli, dict):
        fail('candidate receipt does not contain its exact CLI pin')
    return {'path': str(review_path), 'bytes': len(data), 'sha256': sha(data), 'mode': mode,
            'receipt_path': str(matrix / 'execution.json'), 'receipt_sha256': receipt_sha,
            'candidate_cli': candidate_cli, 'status_values': statuses}


def collect(matrix_arg: Path, root_review_sha: str) -> tuple[dict, dict[str, tuple[Path, bytes, int]]]:
    matrix = path_without_symlinks(matrix_arg.absolute())
    if not matrix.exists() or not matrix.is_dir() or not matrix.is_relative_to(TMP):
        fail('matrix root must be a directory under /private/tmp')
    review_pin = accepted_review_gate(matrix, root_review_sha)
    items: dict[str, tuple[Path, bytes, int]] = {}
    excluded: list[dict] = []
    seen_sources: set[str] = set()

    def add(archive_path: str, source: Path, data: bytes, mode: int) -> None:
        rel = PurePosixPath(archive_path)
        if rel.is_absolute() or '..' in rel.parts or not rel.parts:
            fail(f'unsafe archive path: {archive_path}')
        name = rel.as_posix()
        if name in items or name == 'ARCHIVE_INVENTORY.json':
            fail(f'duplicate/reserved archive path: {name}')
        resolved = str(source.resolve(strict=True))
        if resolved in seen_sources:
            fail(f'duplicate source input: {resolved}')
        if native_executable(data, source):
            fail(f'native executable is not an allowed payload: {source}')
        seen_sources.add(resolved)
        items[name] = (source, data, mode)

    roots: list[tuple[str, Path]] = []
    for label, directory_name in FIXED_ROOTS:
        roots.append((label, path_without_symlinks(TMP / directory_name)))
    fixed_paths = {path.resolve(strict=False): label for label, path in roots}
    if matrix.resolve(strict=False) not in fixed_paths:
        roots.append(('candidate-matrix-root-review', matrix))

    for label, root in roots:
        if not root.exists() or not root.is_dir():
            fail(f'required evidence root is missing/not a directory: {root}')
        paths = sorted(root.rglob('*'), key=lambda p: p.as_posix())
        if not paths:
            fail(f'required evidence root is empty: {root}')
        for path in paths:
            if path.is_symlink():
                fail(f'symlink in evidence tree: {path}')
            if path.is_dir():
                continue
            if not path.is_file():
                fail(f'non-regular evidence entry: {path}')
            relative = path.relative_to(root)
            if label == 'focused-v4' and relative == EXCLUDED_RELATIVE:
                data, mode = file_record(path)
                expected_cli = review_pin['candidate_cli']
                if (expected_cli.get('path') != str(path.resolve()) or expected_cli.get('bytes') != len(data)
                        or expected_cli.get('sha256') != sha(data)):
                    fail('focused-v4 candidate-cli does not match the exact matrix receipt CLI pin')
                excluded.append({'source_path': str(path.resolve()), 'relative_path': relative.as_posix(),
                                 'bytes': len(data), 'sha256': sha(data), 'mode': mode,
                                 'reason': 'Candidate CLI binary is externally pinned in the accepted focused receipt; preserve its pin, not the executable payload.'})
                continue
            if '__pycache__' in path.parts or path.name.endswith('.pyc'):
                fail(f'cache artifact is not an allowed implicit omission: {path}')
            data, mode = file_record(path)
            add(f'{label}/{relative.as_posix()}', path, data, mode)
    expected_exclusion = str((TMP / 'jarde-literal-boolean-focused-root-v4-20261019' / EXCLUDED_RELATIVE).resolve())
    if [row['source_path'] for row in excluded] != [expected_exclusion]:
        fail('the exact focused-v4 candidate-cli exclusion was not found once')

    # Include the packer and README; do not include any generated archive or inventory.
    for path in (HERE / 'pack.py', HERE / 'README.md'):
        data, mode = file_record(path)
        add('archive-preparation/' + path.name, path, data, mode)
    if sum(len(data) for _, data, _ in items.values()) + sum(row['bytes'] for row in excluded) > MAX_BYTES:
        fail(f'evidence exceeds {MAX_BYTES} bytes')

    rows = [{'archive_path': name, 'source_path': str(path.resolve()), 'bytes': len(data),
             'sha256': sha(data), 'mode': mode}
            for name, (path, data, mode) in sorted(items.items())]
    inventory = {'schema': 'test-break-with-label-evidence-archive-v1',
                 'payload_member_count': len(rows), 'members': rows,
                 'excluded_external_inputs': sorted(excluded, key=lambda row: row['source_path']),
                 'accepted_matrix_root_review': review_pin,
                 'notes': [
                     'The SI probe is already archived separately and is not included.',
                     'The focused-v4 candidate-cli is recorded as an excluded external input with bytes and SHA-256.',
                     'All failed/static-rejected preparation and review artifacts in the required roots are preserved verbatim.',
                     'Original/JADX baseline artifacts and raw streams are included through the explicit controls root.',
                 ]}
    return inventory, items


def pack(out: Path, matrix: Path, root_review_sha: str) -> dict:
    output = out.absolute()
    path_without_symlinks(output)
    source_roots = [TMP / name for _, name in FIXED_ROOTS] + [matrix.absolute()]
    if any(output == root or output.is_relative_to(root) for root in source_roots):
        fail('output must be outside all evidence input roots')
    sidecar = output.with_suffix(output.suffix + '.inventory.json')
    if output.exists() or sidecar.exists():
        fail(f'refusing existing archive or sidecar: {output}')
    if output.is_relative_to(HERE):
        fail('output cannot be inside archive preparation directory')
    inventory, items = collect(matrix, root_review_sha)
    output.parent.mkdir(parents=True, exist_ok=True)
    blob = (json.dumps(inventory, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    with output.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as zipped:
            with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as tar:
                for name, (source, data, mode) in sorted(items.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data); info.mode = mode; info.mtime = 0
                    info.uid = info.gid = 0; info.uname = info.gname = ''
                    tar.addfile(info, io.BytesIO(data))
                info = tarfile.TarInfo('ARCHIVE_INVENTORY.json')
                info.size = len(blob); info.mode = 0o644; info.mtime = 0
                info.uid = info.gid = 0; info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(blob))
    verify(output, inventory, items, blob)
    with sidecar.open('xb') as handle:
        handle.write(blob)
    return {'status': 'packed-and-reopened', 'archive': str(output),
            'archive_sha256': sha(output.read_bytes()), 'inventory': str(sidecar),
            'inventory_sha256': sha(blob), 'payload_members': len(items)}


def verify(output: Path, inventory: dict, items: dict[str, tuple[Path, bytes, int]], blob: bytes) -> None:
    with tarfile.open(output, 'r:gz') as tar:
        members = tar.getmembers()
        byname = {item.name: item for item in members}
        expected = set(items) | {'ARCHIVE_INVENTORY.json'}
        if len(byname) != len(members) or set(byname) != expected:
            fail('archive has duplicate, missing or unexpected members')
        for name, (source, expected_bytes, expected_mode) in items.items():
            info = byname[name]
            if not info.isfile() or info.mode != expected_mode:
                fail(f'archive member type/mode mismatch: {name}')
            actual = tar.extractfile(info).read()
            if actual != expected_bytes or len(actual) != len(expected_bytes) or sha(actual) != sha(expected_bytes):
                fail(f'archive member byte/hash mismatch: {name}')
            current, mode = file_record(source)
            if current != expected_bytes or mode != expected_mode:
                fail(f'source changed before archive verification completed: {source}')
        got_inventory = tar.extractfile(byname['ARCHIVE_INVENTORY.json']).read()
        if got_inventory != blob or json.loads(got_inventory) != inventory:
            fail('archive inventory failed exact reopen verification')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--matrix-root', type=Path, required=True,
                        help='accepted final-candidate matrix directory containing execution.json and root-review.json')
    parser.add_argument('--accepted-root-review-sha256', required=True,
                        help='explicit root-review pin; receipt must be bound by that accepted review')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(pack(args.out, args.matrix_root, args.accepted_root_review_sha256), indent=2))


if __name__ == '__main__':
    main()
