// jarde: presentation of `jadx/tests/integration/loops/TestBreakWithLabel$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestBreakWithLabel$TestCls extends java.lang.Object {
    public TestBreakWithLabel$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestBreakWithLabel$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public boolean test(int[][] arr, int b) {
        // @method test([[II)Z
        // @declaration an instance method of `jadx.tests.integration.loops.TestBreakWithLabel$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        boolean found;
        int i;
        found = false;
        int j;
        loop: for (i = 0; i < arr.length; i = i + 1) {
            for (j = 0; j < arr[i].length; j = j + 1) {
                if (arr[i][j] == b) {
                    found = true;
                    break loop;
                }
            }
        }
        java.lang.System.out.println("found: " + found);
        return found;
    }

    public void check() {
        // @method check()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestBreakWithLabel$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int[][] testArray = new int[][]{new int[]{1, 2}, new int[]{3, 4}};
        org.assertj.core.api.Assertions.assertThat(this.test(testArray, 3)).isTrue();
        org.assertj.core.api.Assertions.assertThat(this.test(testArray, 5)).isFalse();
        return;
    }
}
