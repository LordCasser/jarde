import datetime,hashlib,importlib.util,json,os,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path(__file__).parent
assert not (ROOT/'target').exists() and shutil.disk_usage(ROOT).free>=5*1024**3
CP=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
assert hashlib.sha256(CP.read_bytes()).hexdigest()=='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
spec=importlib.util.spec_from_file_location('cmp',CP);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
jdks,jdk_record=c.configured_jdks(ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json','ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
source=ROOT/'tests/fixtures/cf09-literal-boolean-locals/controls-src/BooleanLocalRefusals.java'
mutator=ROOT/'tests/fixtures/cf09-literal-boolean-locals/prepare_controls.py'
assert c.sha(source)=='610f1eaff2db3b8c9e2e64427e87a04898e759f90e9a97ae3a96bb47a533fc08'
assert c.sha(mutator)=='e8828422c9e390d2db6da3ffdbf15a0fcfe10b19d904791f8ed8cf436e93df6b'
r={'status':'running','commands':[],'jdk_manifest':jdk_record,'source':c.pin(source),'mutator':c.pin(mutator)}
def save():c.write_json(OUT/'execution.json',r)
def run(argv,env):
 n=len(r['commands'])+1;so=OUT/f'{n}.stdout.raw';se=OUT/f'{n}.stderr.raw';started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with so.open('xb') as a,se.open('xb') as b:result=subprocess.run(argv,cwd=ROOT,env=env,stdout=a,stderr=b,timeout=60)
 row={'argv':argv,'exit_code':result.returncode,'started':started,'stdout':c.pin(so),'stderr':c.pin(se)};r['commands'].append(row);save();assert result.returncode==0,se.read_text()
try:
 inputs=[]
 for tag,jdk in jdks.items():
  classes=OUT/tag/'compiled';classes.mkdir(parents=True);argv=[str(jdk['tools']['javac']),'-g','-encoding','UTF-8']
  if tag=='javac23':argv+=['--release','8']
  argv+=['-d',str(classes),str(source)];run(argv,c.clean_env(os.environ,jdk));inputs.append(classes/'cf09/literalboolean/BooleanLocalRefusals.class')
 assert len(inputs)==2
 run([sys.executable,'-B',str(mutator),'--javac8-class',str(inputs[0]),'--javac23-class',str(inputs[1]),'--out',str(OUT/'mutated')],c.clean_env(os.environ))
 module=importlib.util.spec_from_file_location('mutator',mutator);m=importlib.util.module_from_spec(module);module.loader.exec_module(m)
 fixture=ROOT/'tests/fixtures/cf09-literal-boolean-locals';rows=[];total=[0,0,0,0,0]
 for p in sorted(list((fixture/'original').rglob('*.class'))+list((OUT/'mutated').rglob('*.class'))):
  a=m.parse_class(p.read_bytes());b=c.parse_class(p);assert a['internal_name']==b['class_name'] and a['major']==b['major']==52
  row={'class':c.pin(p),'name':b['class_name'],'code_bodies':0,'handlers':0,'branch_targets':0,'jsr':0,'methods':[]}
  for am,bm in zip(a['methods'],b['methods']):
   assert (am['name'],am['descriptor'])==(bm['name'],bm['descriptor'])
   if am['code'] is None:assert bm['code'] is None;continue
   ac,bc=am['code'],bm['code'];ins=m.instructions(ac['bytes']);assert ac['bytes'].hex()==bc['code_hex'] and [x['bci'] for x in ins]==bc['bcis'] and ac['exceptions']==bc['rows']
   valid={x['bci'] for x in ins};assert all(t in valid for x in ins for t in x['targets']);row['code_bodies']+=1;row['handlers']+=len(ac['exceptions']);row['branch_targets']+=sum(len(x['targets']) for x in ins);row['jsr']+=sum(x['opcode'] in (0xa8,0xc9) for x in ins);row['methods'].append({'name':am['name'],'descriptor':am['descriptor'],'instructions':ins})
  total=[total[0]+1,total[1]+row['code_bodies'],total[2]+row['handlers'],total[3]+row['branch_targets'],total[4]+row['jsr']];rows.append(row)
 r['physical_classes']=rows;r['reader_delta']=total;r['status']='root_compiled_mutated_and_independently_censused_no_target_method_run'
 assert c.sha(source)==r['source']['sha256'] and c.sha(mutator)==r['mutator']['sha256'] and not (ROOT/'target').exists()
except BaseException as e:r.update(status='failed',error=repr(e));raise
finally:save();print(json.dumps({'status':r['status'],'reader_delta':r.get('reader_delta')}))
