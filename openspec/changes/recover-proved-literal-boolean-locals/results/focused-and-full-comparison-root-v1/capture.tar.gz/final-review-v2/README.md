# TestBreakWithLabel final-candidate reviewer v2

This is a private, read-only reviewer for the current v2 final-candidate collector. It was only syntax-checked with Python AST parsing and has not been run on a candidate receipt. It does not run the collector, JDK/Javac/JADX, Cargo, Git, or network operations.

The reviewer requires a root-supplied exact CLI SHA and a terminal successful capture. It checks the actual 72-command matrix: 8 API requests, 16 Java 8 full-source compile attempts, 32 positive VM runs, and 16 per-compiled-root wrong-CodeSource controls, covering 192 six-case runtime observations. It checks command labels/indexes, raw stream path and row bindings, actual argv, guard limits/environment, all pin records, and source/tool/external/generated snapshots. It binds original/JADX evidence only to the already accepted baseline; those rows are not presented as fresh runs.

For API output it reopens the raw JSON, full class text, source and class/JAR inputs, checks every method identity against the physical class and the accepted baseline report for that same input, verifies UTF-8 boundaries and physical BCI anchors, and records any unmapped BCIs without requiring total coverage. Default/all must retain identical whole text, method identity/outcome/quality/text/maps. Other non-usage JSON differences are allowed only at paths already differing between default/all in the accepted baseline.

For each generated source cell it checks byte-for-byte source copies, both compiler invocations, complete per-compiler output inventories and facts, Java 8 class version, one wrong-root rejection and both runtime legs. Runtime observations are checked against the accepted original oracle for the matching profile and VM. The capture's copied collector must match the frozen v2 collector. No comparison requires the current live workspace to remain target-free after the capture; the recorded before/finally absence gates are checked instead.

Run after the final collector receipt exists and the root supplies the candidate CLI hash:

```sh
python3 -B /private/tmp/jarde-testbreakwithlabel-final-review-luna-v2-20261019/review.py \
  --receipt /path/to/final/execution.json \
  --expected-cli-sha256 ROOT_SUPPLIED_64_HEX_SHA \
  --out /private/tmp/jarde-testbreakwithlabel-final-review-luna-v2-20261019/review.json
```

## Frozen inputs

- Candidate collector v2: `/private/tmp/jarde-testbreakwithlabel-final-candidate-prep-luna-v2-20261019/collect_final.py`, SHA-256 `5d3f5c7cff83feb025b22e6254ca6cb5e4c538ef057b948ae71de79f3b55a48f`.
- Accepted original baseline: `/private/tmp/jarde-testbreakwithlabel-baseline-root-v1-20261019/execution.json`, SHA-256 `e2ca55f13812454af5441bcb78a68690e6d9cdf6f114a5e631b014acb9c8f75d`.
- Accepted baseline root marker: `/private/tmp/jarde-testbreakwithlabel-baseline-root-v1-20261019/root-review.json`, SHA-256 `145948b4549989fd3207b306f7e0aa25d097447dd683e5ce96a8fbcb9aa4efb5`.
- Parentless driver SHA-256: `033e0efc033d18df1098daec498852f1d53db22d2bd8f5af83e5b1f892266b5c`.

## v1 to v2 corrections

The review-only v2 fixes the six execution blockers called out in review: passes expected guard environment into command validation; binds the runtime wrapper to the accepted baseline's actual copied path; checks the recorded guard/scanner pins; requires non-empty exact 8-source/16-class snapshot keysets and compares each entry to its per-cell record; binds every compiler/runtime/wrong-root stream pin to that command's raw streams; and compares each API owner with the accepted baseline report's exact class identity for the matching profile/input/evidence cell. V1 is preserved unchanged.
