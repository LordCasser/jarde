# TestBreakWithLabel final-candidate reviewer v3

V3 is a one-line-scope reviewer correction to v2. V2 completed its independent checks, but its result incorrectly reported the SHA of the last parsed class file because the receipt-path parameter was shadowed in a class-tree loop. V3 resolves and hashes the execution receipt at function entry, keeps that digest in `receipt_digest`, and returns that frozen value. The remaining `path` loop variable is local and no longer shadows the receipt path. All v2 gates are retained unchanged.

This reviewer is read-only. It was only syntax-checked with Python AST parsing; no candidate receipt was re-evaluated and no CLI, JDK/Javac/JADX, Cargo, Git, network, or target method was run. Use a distinct review output so the v2 result remains intact:

```sh
python3 -B /private/tmp/jarde-testbreakwithlabel-final-review-luna-v3-20261019/review.py \
  --receipt /private/tmp/jarde-testbreakwithlabel-final-candidate-root-v1-20261019/execution.json \
  --expected-cli-sha256 ROOT_SUPPLIED_64_HEX_SHA \
  --out /private/tmp/jarde-testbreakwithlabel-final-candidate-root-v1-20261019/independent-review-v2.json
```

V2 and its pins are preserved in `/private/tmp/jarde-testbreakwithlabel-final-review-luna-v2-20261019/` and `pins-v2.json` here. The v2 result remains at `independent-review.json`; root should verify the receipt hash in the new v3 result against the execution JSON before accepting the review marker.
