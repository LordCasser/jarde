# Narrow historical golden adjustment for `sum(List)` diagnostic

This private test-only patch is based on `tests/recover_lambda_primitive_array_capture.rs` SHA-256 `0e0135f8fecb6530db36ad26aff4a5b72b08ae83f9dd4b18fe0a7250c600cec5`.

The patch adds a helper that requires the historic `sum(Ljava/util/List;)I` refusal line to occur exactly once, then replaces only that entire line with the current refusal line. It is used only when comparing current output with frozen `fixed` records in the two affected comparisons: the full P02_lambda rendering and the selected members of P02_multianewarray. The historical `baseline == fixed` assertion, every other member/body assertion, and compile/runtime comparisons remain unchanged.

This records the intentional proof-marker change while preserving byte-for-byte checks everywhere else. No Cargo, JDK, CLI, Git mutation, or network command was run.

Edited file SHA-256: `f652e0ea4ae2760afdda265851ce11fe5156aee09a3af18bc852298a69db54d9`.
Patch SHA-256: `0956c9e27fdd1333d96aff0655521db26400498150150c6e940f10f22a5297dd`.
