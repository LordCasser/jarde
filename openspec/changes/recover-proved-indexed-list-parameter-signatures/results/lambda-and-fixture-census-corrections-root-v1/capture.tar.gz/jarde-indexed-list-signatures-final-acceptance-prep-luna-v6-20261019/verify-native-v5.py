--- v3/verify-native.py
+++ v4/verify-native.py
@@ -17,6 +17,7 @@
  ('jarde', 'class_source::tests::complete_body_primitive_result_requires_exact_signature_and_descriptor_type'),
  ('jarde_java', 'report::exact_cast_call_batch_tests::iterative_batch_propagates_budget_and_cancellation_stops'),
  ('jarde_java', 'report::generic_void_parameter_census_tests::invoke_receiver_census_uses_consumed_stack_depth_not_stack_zero'),
+ ('p3_iterable_foreach', 'subtype_owners_project_and_extra_next_or_iterator_escape_refuse'),
  ('p3_nested_loop_side_exits', 'indexed_list_parameter_signatures_require_exact_direct_get_cast_evidence'),
  ('p3_nested_loop_side_exits', 'indexed_list_parameter_primitive_result_must_match_signature_exactly'),
 ]
