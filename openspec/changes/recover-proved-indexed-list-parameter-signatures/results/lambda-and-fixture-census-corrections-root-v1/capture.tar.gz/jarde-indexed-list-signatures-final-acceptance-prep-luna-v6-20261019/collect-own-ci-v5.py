--- v3/collect-own-ci.py
+++ v4/collect-own-ci.py
@@ -46,6 +46,8 @@
     'crates/jarde-reader/src/classfile.rs',
     'tests/structured_list_generic_bodies.rs',
     'tests/p3_hoisted_iterator_foreach.rs',
+    'tests/p3_iterable_foreach.rs',
+    'tests/fixtures/p3-iterable-foreach/IterableBoundaryRunner.java',
     'tests/p3_nested_loop_side_exits.rs',
     'tests/fixtures/corpus-fingerprint.json',
     'tests/fixtures/foreach-local-bindings/source/TestNestedLoops.java',
