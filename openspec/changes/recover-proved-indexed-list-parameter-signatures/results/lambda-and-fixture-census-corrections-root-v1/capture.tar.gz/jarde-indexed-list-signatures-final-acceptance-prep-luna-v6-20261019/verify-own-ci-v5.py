--- v4/verify-own-ci.py
+++ v5/verify-own-ci.py
@@ -140,7 +140,6 @@
 ANCESTOR_ITERATOR_CLEANUP_TESTS = {
     'ancestor iterator physical local closure': ('build::tests::ancestor_iterator_cleanup_closes_the_complete_physical_local_variable', 'jarde_java'),
     'ancestor iterator unique visible row boundary': ('build::tests::ancestor_iterator_cleanup_requires_unique_direct_visible_iterator_row', 'jarde_java'),
-    'iterable foreach subtype owner escape refusal': ('subtype_owners_project_and_extra_next_or_iterator_escape_refuse', 'p3_iterable_foreach'),
 }
 ANCESTOR_ITERATOR_CLEANUP_CRITICAL_COUNT = 2
 CRITICAL_TESTS.update(ANCESTOR_ITERATOR_CLEANUP_TESTS)
