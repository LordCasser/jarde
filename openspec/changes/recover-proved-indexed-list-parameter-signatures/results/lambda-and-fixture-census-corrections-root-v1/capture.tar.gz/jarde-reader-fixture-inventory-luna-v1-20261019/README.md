# Indexed List fixture inventory delta

Base source: `crates/jarde-reader/src/classfile.rs` SHA-256 `5ee53c4384eb981dce3862a19c7e29b2ded82de4f7a56d38d1f7c18603691df2`.

The private patch changes only the fixture census expectation and its adjacent ledger entry:

- expected tuple: `(1303, 5755, 630, 4066, 14)` → `(1305, 5775, 630, 4102, 14)`;
- ledger: records each added debug/no-debug class as 10 Code bodies, 18 branch targets, 0 handlers and 0 jsr; total delta 2 classes, 20 bodies, 36 targets.

I independently parsed both classfile headers, constant pools, method attributes, Code arrays and exception tables from the actual pinned bytes. Instruction widths and branch/switch target counting follow `classfile.rs`'s `instruction_width` and `MethodCodeFacts::control_flow_targets` rules. Both are major version 52. Per-method branch target rows:

| Method | debug | no-debug |
| --- | ---: | ---: |
| `<init>` | 0 | 0 |
| `voidGetCastString` | 2 | 2 |
| `fixedBoundBoolean` | 4 | 4 |
| `primitiveInt` | 2 | 2 |
| `primitiveLong` | 2 | 2 |
| `legalWrongCast` | 2 | 2 |
| `reassignAndEscape` | 2 | 2 |
| `rawList` | 2 | 2 |
| `wildcardList` | 2 | 2 |
| `referenceResult` | 0 | 0 |
| **Totals** | **10 bodies / 18 targets / 0 handlers / 0 jsr** | **10 / 18 / 0 / 0** |

Pinned class SHA-256 values:

- debug: `d71671a2f7f73edf3aada8420c3bdda73e638d3f92b7c6489f0d2da25dfdb2cb`
- no-debug: `860d037a221b4444d8024d46475b4f7ec3c77d941800998b15fa58b96385c09a`

The reproducible byte-only counter is `count_class.py` (SHA-256 `aaf6a28e7ca888535b631ee880d3f7f558783b1fca8cb7fa50cd356ee95feacb`). It reads raw classfile bytes and does not execute the classes. No Cargo, JDK, CLI, Git mutation, or network command was run; the Reader library test still needs root's actual run.

Edited source SHA-256: `df460ea0a6167fb0a54252a3cc520770d8cc22126c1361b1926da5f066df1604`.
Patch SHA-256: `a9a78ef37005ba8b6ef94d6459ac119492bb3d7142a01fc8137d3a9a5adc1e26`.
