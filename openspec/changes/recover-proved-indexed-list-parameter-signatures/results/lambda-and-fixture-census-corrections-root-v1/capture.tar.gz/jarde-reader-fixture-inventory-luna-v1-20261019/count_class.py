from pathlib import Path
import struct, sys

class Reader:
    def __init__(self, data): self.data=data; self.p=0
    def u1(self): v=self.data[self.p]; self.p+=1; return v
    def u2(self): v=struct.unpack_from('>H',self.data,self.p)[0]; self.p+=2; return v
    def u4(self): v=struct.unpack_from('>I',self.data,self.p)[0]; self.p+=4; return v
    def take(self,n): v=self.data[self.p:self.p+n]; assert len(v)==n; self.p+=n; return v

def parse(path):
    r=Reader(Path(path).read_bytes())
    assert r.u4()==0xcafebabe
    minor,major=r.u2(),r.u2()
    cp_count=r.u2(); cp=[None]*cp_count; i=1
    while i<cp_count:
        tag=r.u1()
        if tag==1:
            n=r.u2(); cp[i]=r.take(n).decode('utf-8','replace')
        elif tag in (3,4): r.take(4)
        elif tag in (5,6): r.take(8); i+=1
        elif tag in (7,8,16,19,20): r.take(2)
        elif tag in (9,10,11,12,17,18): r.take(4)
        elif tag==15: r.take(3)
        else: raise ValueError(('cp tag',tag,i))
        i+=1
    def attrs():
        count=r.u2(); found=[]
        for _ in range(count):
            name=cp[r.u2()]; n=r.u4(); payload=r.take(n); found.append((name,payload))
        return found
    r.take(6)
    for _ in range(r.u2()): r.take(2)
    for _ in range(r.u2()): r.take(6); attrs()
    body_count=handlers=branches=jsrs=0; methods=[]
    for _ in range(r.u2()):
        access=r.u2(); name=cp[r.u2()]; desc=cp[r.u2()]
        for aname,payload in attrs():
            if aname!='Code': continue
            q=Reader(payload); q.u2(); q.u2(); n=q.u4(); code=q.take(n); handler_count=q.u2(); q.take(8*handler_count); nested=q.u2()
            for __ in range(nested): q.u2(); q.take(q.u4())
            assert q.p==len(payload)
            body_count+=1; handlers+=handler_count; method_branches=method_jsrs=0
            bci=0
            while bci<len(code):
                op=code[bci]
                if 0x99<=op<=0xa8 or op in (0xc6,0xc7,0xc8,0xc9):
                    method_branches+=1
                    if op in (0xa8,0xc9): method_jsrs+=1
                if op==0xaa:
                    pad=(4-((bci+1)%4))%4; p=bci+1+pad
                    default,low,high=struct.unpack_from('>iii',code,p); count=high-low+1
                    method_branches+=1+count
                    width=1+pad+12+4*count
                elif op==0xab:
                    pad=(4-((bci+1)%4))%4; p=bci+1+pad
                    default,npairs=struct.unpack_from('>ii',code,p)
                    method_branches+=1+npairs
                    width=1+pad+8+8*npairs
                elif op==0xc4:
                    width=6 if code[bci+1]==0x84 else 4
                elif op in (0xb9,0xba,0xc8,0xc9): width=5
                elif op==0xc5: width=4
                elif op in (0x11,0x13,0x14,0x84) or 0x99<=op<=0xa8 or 0xb2<=op<=0xb8 or op in (0xbb,0xbd,0xc0,0xc1,0xc6,0xc7): width=3
                elif op in (0x10,0x12,0x15,0x16,0x17,0x18,0x19,0x36,0x37,0x38,0x39,0x3a,0xa9,0xbc): width=2
                else: width=1
                bci+=width
            assert bci==len(code),(name,desc,bci,len(code))
            branches+=method_branches; jsrs+=method_jsrs; methods.append((name,desc,n,handler_count,method_branches,method_jsrs))
    return minor,major,body_count,handlers,branches,jsrs,methods

for p in sys.argv[1:]:
    print(p, parse(p)[:6])
    for method in parse(p)[6]: print(' ',method)
