# Indexed-list-signatures final acceptance preparation v4

Prepared privately from the frozen accepted own-CI verifier and one-seed native acceptance. No Cargo, JDK, Jarde/JADX CLI, Git mutation, or network action was run. This bundle is not a test result or product acceptance.

The v3 bundle had 14 pinned source paths and nine fixture files. V4 preserves those checks and adds tests/p3_iterable_foreach.rs plus tests/fixtures/p3-iterable-foreach/IterableBoundaryRunner.java as source paths, for 16 total. The corpus fingerprint is already included once in the source inventory. The recursive fixture roots and their nine-file inventory remain unchanged. The verifier derives the expected target inventory from the actual CI receipt and compares both official workspace seeds; the historical 385-target receipt is only a cross-check, never a hardcoded future pass total.

The verifier's inherited 63 gates remain unchanged. Supply the two previously accepted object-argument gates plus these eight exact current identities through repeated `--extra-critical` arguments; the verifier derives its gate total from that list:

- `jarde_java=report::exact_cast_call_batch_tests::iterative_batch_proves_multiple_get_cast_children_and_rejects_mutations`
- `jarde=facade::generic_list_foreach_binding_slot_closed_tests::generic_list_indexed_get_keeps_its_exact_single_cast_use_and_ast_child`
- `jarde=class_source::tests::complete_body_primitive_result_requires_exact_signature_and_descriptor_type`
- `jarde_java=report::exact_cast_call_batch_tests::iterative_batch_propagates_budget_and_cancellation_stops`
- `jarde_java=report::generic_void_parameter_census_tests::invoke_receiver_census_uses_consumed_stack_depth_not_stack_zero`
- `p3_nested_loop_side_exits=indexed_list_parameter_signatures_require_exact_direct_get_cast_evidence`
- `p3_nested_loop_side_exits=indexed_list_parameter_primitive_result_must_match_signature_exactly`
- `p3_iterable_foreach=subtype_owners_project_and_extra_next_or_iterator_escape_refuse`

The official log ZIP is captured after collection by `collect-official-logs.py`. Its `step-log-supplement.json` records the exact `gh api repos/LordCasser/jarde/actions/runs/<run-id>/logs` argv, raw stdout/stderr paths, byte counts, and SHA256 values, plus pins for `collection.json` and `run.json`; the verifier checks those bindings. The verifier requires every independent per-step ZIP member. If one is absent, it rejects the archive rather than reconstructing it from the aggregate member.

The native wrapper inherits the accepted 18 exact gates, retains the two historical object-argument gates, and adds those eight identities. The Iterable test is supplied only through `--extra-critical`; it is not duplicated in the ancestor-cleanup dictionary. It derives the checked gate total from the arrays, rejects collisions, pins seed `5350648285461741569`, and delegates complete target/Running/harness/resource/source validation to the frozen workspace checker. It does not hardcode target count or workspace pass count.

## Prepared command forms

Collection requires actual values only after the final product and broad CLI receipt exist:

```sh
python3 collect-own-ci.py <fresh-evidence-dir> <CI-run-id> <full-product-sha> <final-cli-sha256>
python3 collect-official-logs.py <fresh-evidence-dir>
python3 verify-own-ci.py <fresh-evidence-dir> --product-sha <full-product-sha> --cli-sha256 <final-cli-sha256> \
  --extra-critical 'jarde=facade::generic_list_foreach_binding_slot_closed_tests::optional_remove_argument_break_leaves_required_list_proof_and_equals_edit' \
  --extra-critical 'jarde=facade::generic_list_foreach_binding_slot_closed_tests::unmatched_optional_equals_key_does_not_hide_valid_calls' \
  --extra-critical 'jarde_java=report::exact_cast_call_batch_tests::iterative_batch_proves_multiple_get_cast_children_and_rejects_mutations' \
  --extra-critical 'jarde=facade::generic_list_foreach_binding_slot_closed_tests::generic_list_indexed_get_keeps_its_exact_single_cast_use_and_ast_child' \
  --extra-critical 'jarde=class_source::tests::complete_body_primitive_result_requires_exact_signature_and_descriptor_type' \
  --extra-critical 'jarde_java=report::exact_cast_call_batch_tests::iterative_batch_propagates_budget_and_cancellation_stops' \
  --extra-critical 'p3_nested_loop_side_exits=indexed_list_parameter_signatures_require_exact_direct_get_cast_evidence' \
  --extra-critical 'p3_nested_loop_side_exits=indexed_list_parameter_primitive_result_must_match_signature_exactly' \
  --extra-critical 'p3_iterable_foreach=subtype_owners_project_and_extra_next_or_iterator_escape_refuse'
python3 verify-native.py <native-execution.json> --out <native-review.json>
python3 bind_product_one.py --product <actual-final-HEAD> --build <final-broad-execution.json> --native <native-execution.json> --acceptance <native-review.json> --out <product-binding.json>
```

Run the binder only with the final committed HEAD and matching broad/native receipts. `bind_product_one.py` is copied byte-for-byte from the accepted v2 binder; its own final HEAD, CLI, native receipt, and source pin checks remain active. Historical object-argument receipt/review and old CI acceptance are reference provenance only, not evidence for the new product.

`acceptance-argv.json` and `gates.json` record the exact command templates and gate identities. `verify-own-ci-v3.py.diff` preserves the v3 strict archive binding and no-aggregate fallback; `verify-own-ci.py.diff` contains only the v4 delta. The v2 source and fixture inventory changes are preserved in this bundle. `verify-native.py` is a narrow extension of the previously accepted one-seed wrapper. The 385 target baseline is a cross-check against actual future evidence, not an expected pass count.


V2 adds only the new indexed-list controls fixture root to both collector and verifier inventories; the test and gate inventories are unchanged from v1. `collect-own-ci.py.diff` and `verify-own-ci.py.diff` show those narrow inventory additions. No collection or acceptance command was run.


V3 adds the consumed-stack-depth census gate and requires an independently captured, run-bound official per-step log ZIP. It removes the aggregate fallback from this verifier. Scripts are prepared only; run them only after current native, product, and CI evidence is available.


V4 adds exactly two source paths to both collector/verifier inventories (14 to 16), with no fixture-root or expected-fixture change (nine fixtures remain). It adds subtype_owners_project_and_extra_next_or_iterator_escape_refuse under target p3_iterable_foreach to CI extras and current native gates. CI totals derive as 63 inherited plus 10 extra-critical identities (73); native totals derive as 18 inherited plus 2 historical plus 8 current identities (28). Product binding and official independent-step ZIP checks remain in place. No collection, test, or acceptance command was run.


V5 fixes the CI gate inventory: the Iterable subtype-owner test is supplied only by the documented `--extra-critical` argument, so the inherited ancestor-cleanup dictionary remains exactly two gates. Static AST inventory checks confirm 63 inherited CI gates, 10 unique extra identities (73 total), 18 inherited native gates plus 2 historical and 8 current gates (28 total), 16 source paths, and nine fixture files. The exact AST-derived identities are recorded in `v5-static-audit.json`; its SHA256 is pinned in `pins.json`. This preparation was not executed against a receipt. The v4 verifier delta is retained as `verify-own-ci-v4.py.diff`; `verify-own-ci.py.diff` is the one-row v5 correction.
