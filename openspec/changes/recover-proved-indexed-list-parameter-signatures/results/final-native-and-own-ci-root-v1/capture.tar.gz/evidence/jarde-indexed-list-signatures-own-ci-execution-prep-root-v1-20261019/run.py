import json,subprocess,pathlib,hashlib,datetime,sys
prep=pathlib.Path(__file__).parent
out=pathlib.Path(sys.argv[1]); out.mkdir(exist_ok=False)
record={"status":"running","commands":[]}
def pin(p):
 d=p.read_bytes(); return {"path":str(p),"bytes":len(d),"sha256":hashlib.sha256(d).hexdigest()}
try:
 for i,argv in enumerate(json.loads((prep/"commands.json").read_text()),1):
  so=out/f"{i}.stdout.raw"; se=out/f"{i}.stderr.raw"
  started=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with so.open("xb") as o,se.open("xb") as e: p=subprocess.run(argv,cwd="/Users/lordcasser/workspace/projects/jarde",stdout=o,stderr=e)
  record["commands"].append({"argv":argv,"exit_code":p.returncode,"started_at":started,"stdout":pin(so),"stderr":pin(se)})
  (out/"execution.json").write_text(json.dumps(record,indent=2)+"\n")
  print(json.dumps({"command":i,"exit_code":p.returncode}),flush=True)
  if p.returncode: raise RuntimeError(f"command {i} failed")
 report=json.loads((out/"3.stdout.raw").read_text()); assert report["status"]=="accepted"
 ci=pathlib.Path(json.loads((prep/"commands.json").read_text())[0][3]); (ci/"review.json").write_bytes((out/"3.stdout.raw").read_bytes())
 record["status"]="commands_passed_independent_root_review_pending"
except BaseException as exc:
 record["status"]="failed"; record["failure"]=repr(exc); raise
finally:
 (out/"execution.json").write_text(json.dumps(record,indent=2)+"\n")
