#!/usr/bin/env python3
"""Check one native workspace receipt against inherited and current leaf gates."""
import argparse, hashlib, importlib.util, json, sys
from pathlib import Path
sys.dont_write_bytecode = True
BASE = Path('/private/tmp/jarde-indexed-list-signatures-final-acceptance-prep-luna-v8-20261019/verify_workspace.py')
BASE_SHA = '8321198c09133aad60d8591b1d3e8f4c849420c4b3a37c1bc4c4aa12129d9830'
INHERITED_WRAPPER = Path('/private/tmp/jarde-ancestor-iterator-ci-prep-luna-v1-20261018/verify-native.py')
INHERITED_WRAPPER_SHA = '6ed9fda0ab467c191747365bbe4cea6e084e1053be9bc2eddc28ab3c4fc231c9'
HISTORICAL_OBJECT_ARGUMENT_GATES = [
 ('jarde', 'facade::generic_list_foreach_binding_slot_closed_tests::optional_remove_argument_break_leaves_required_list_proof_and_equals_edit'),
 ('jarde', 'facade::generic_list_foreach_binding_slot_closed_tests::unmatched_optional_equals_key_does_not_hide_valid_calls'),
]
CURRENT_GATES = [
 ('jarde_java', 'report::exact_cast_call_batch_tests::iterative_batch_proves_multiple_get_cast_children_and_rejects_mutations'),
 ('jarde', 'facade::generic_list_foreach_binding_slot_closed_tests::generic_list_indexed_get_keeps_its_exact_single_cast_use_and_ast_child'),
 ('jarde', 'class_source::tests::complete_body_primitive_result_requires_exact_signature_and_descriptor_type'),
 ('jarde_java', 'report::exact_cast_call_batch_tests::iterative_batch_propagates_budget_and_cancellation_stops'),
 ('jarde_java', 'report::generic_void_parameter_census_tests::invoke_receiver_census_uses_consumed_stack_depth_not_stack_zero'),
 ('p3_iterable_foreach', 'subtype_owners_project_and_extra_next_or_iterator_escape_refuse'),
 ('p3_nested_loop_side_exits', 'indexed_list_parameter_signatures_require_exact_direct_get_cast_evidence'),
 ('p3_nested_loop_side_exits', 'indexed_list_parameter_primitive_result_must_match_signature_exactly'),
 ('recover_lambda_primitive_array_capture', 'the_primitive_array_capture_recovers_in_both_javac_legs'),
 ('recover_lambda_primitive_array_capture', 'the_multianewarray_capture_preserves_its_members_while_the_nested_helper_recovers'),
 ('jarde_reader', 'classfile::tests::repository_class_fixtures_validate_without_false_target_rejections'),
]
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('receipt',type=Path)
 ap.add_argument('--out',type=Path,required=True)
 a=ap.parse_args()
 if a.out.exists(): raise FileExistsError(f'refusing to overwrite {a.out}')
 if hashlib.sha256(BASE.read_bytes()).hexdigest()!=BASE_SHA: raise RuntimeError('frozen accepted workspace checker changed')
 if hashlib.sha256(INHERITED_WRAPPER.read_bytes()).hexdigest()!=INHERITED_WRAPPER_SHA: raise RuntimeError('frozen accepted ancestor gate wrapper changed')
 spec=importlib.util.spec_from_file_location('frozen_workspace_checker',BASE)
 c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
 ws=importlib.util.spec_from_file_location('frozen_ancestor_gate_wrapper',INHERITED_WRAPPER)
 inherited=importlib.util.module_from_spec(ws);ws.loader.exec_module(inherited)
 gates=list(inherited.GATES)+HISTORICAL_OBJECT_ARGUMENT_GATES+CURRENT_GATES
 if len(inherited.GATES)!=18 or len(set(gates))!=len(gates): raise RuntimeError('inherited/new exact gate identities changed or collide')
 c.GATES=gates
 rpath=a.receipt/'execution.json' if a.receipt.is_dir() else a.receipt
 x=c.validate_one(rpath)
 if x['seed']!='5350648285461741569': raise RuntimeError('unexpected fixed workspace seed')
 if x['critical_gate_count']!=len(gates): raise RuntimeError('exact gate inventory was not fully checked')
 required=set(HISTORICAL_OBJECT_ARGUMENT_GATES+CURRENT_GATES)
 got={(tuple(g['target'])[1],g['test']) for g in x['critical_gates']}
 if not required <= got: raise RuntimeError('one or more exact gates absent from checked receipts')
 native_pin={'path':str(Path(rpath).resolve()),'bytes':Path(rpath).stat().st_size,'sha256':hashlib.sha256(Path(rpath).read_bytes()).hexdigest()}
 dest=a.out.resolve();dest.parent.mkdir(parents=True,exist_ok=True)
 report={'schema':'single-seed-indexed-list-signatures-workspace-review-v1','status':'passed',
  'native_receipt':native_pin,'source_pins_sha256':x['source_pins_sha256'],
  'seed':x['seed'],'target_count':x['target_count'],'batch_count':x['batch_count'],
  'workspace_totals':x['workspace_totals'],'source_pin_count':x['source_pin_count'],
  'critical_gate_count':len(gates),'inherited_gate_count':len(inherited.GATES),
  'historical_object_argument_gates':[{'target':t,'test':n} for t,n in HISTORICAL_OBJECT_ARGUMENT_GATES],
  'current_exact_gates':[{'target':t,'test':n} for t,n in CURRENT_GATES],
  'critical_gates_each_occur_once_and_pass':True,'workspace':x,
  'checker':{'path':str(BASE),'sha256':BASE_SHA},
  'inherited_gate_wrapper':{'path':str(INHERITED_WRAPPER),'sha256':INHERITED_WRAPPER_SHA},
  'reviewer':str(Path(__file__).resolve())}
 dest.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'status':'passed','seed':x['seed'],'targets':x['target_count'],'gates':len(gates),'output':str(dest)}))
if __name__=='__main__': main()
