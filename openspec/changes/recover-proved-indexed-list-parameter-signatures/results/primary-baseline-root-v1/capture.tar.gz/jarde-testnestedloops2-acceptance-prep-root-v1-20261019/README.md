# TestNestedLoops2 acceptance checker

`verify_nestedloops2.py` is an independent, read-only checker for the primary
TestNestedLoops2 baseline and complete generated-source matrix. It was prepared
for review and has **not been run**. It invokes no JDK, Jarde CLI, Cargo, Git,
JADX, or network operation; a future invocation only reopens receipts, raw
streams, pinned sources/classes, and helper parsers, then writes `review.json`
to a new `--out` directory.

Example invocation after review (supply the receipt hashes shown below):

```sh
python3 /private/tmp/jarde-testnestedloops2-acceptance-review-luna-v1-20261019/verify_nestedloops2.py \
  --baseline /private/tmp/jarde-testnestedloops2-full-baseline-root-v1-20261019/execution.json \
  --baseline-sha256 342dbc438f372f39d5b6dc1df7414ac6d0523e1e333e37cd92a805cd9b050543 \
  --matrix /private/tmp/jarde-testnestedloops2-generated-baseline-root-v1-20261019/execution.json \
  --matrix-sha256 a06dbf76e1dd80f2dfcf429e7675415a182f407e4aeb1cad2f8ebffd4ae5942e \
  --out /private/tmp/jarde-testnestedloops2-independent-review-result
```

The matrix is expected to preserve two no-debug JADX/JDK 23 event-order
mismatches caused by repeated `List.get` in its complete generated source.
The checker classifies those exact cells and still requires their results and
exceptions to match. It independently requires every Jarde runtime cell to
match. Thus a completed review must not be described as an all-green source
matrix. The separate JDK 8 full-source major-55 rejection is also retained as
an observed boundary, not treated as a successful compile.

No controls matrix is included in this checker.
