#!/usr/bin/env python3
"""Independent read-only verifier for TestNestedLoops2 baseline + full-source matrix receipts."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, re, zipfile
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
COMPARE=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
GUARD=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK=ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
BASE_SCHEMA='cf11-testnestedloops2-current-full-source-baseline-v1'
MATRIX_SCHEMA='cf11-testnestedloops-current-generated-source-matrix-v2'
INTERNAL='jadx/tests/integration/loops/TestNestedLoops2$TestCls'
OUTER='jadx/tests/integration/loops/TestNestedLoops2'
METHODS={('<init>','()V'),('test','(Ljava/util/List;)Z')}
PROFILES=('debug','no-debug'); FORMS=('child','bundle-child'); EVIDENCE=('default','all'); LEGS=('javac8','javac23'); RUNTIMES=LEGS
CASE_NAMES=('empty','short','long','short-after-long','null-list','null-element','heap-pollution','get-throws','size-throws','abstract-list-order')

def need(ok,msg):
    if not ok: raise ValueError(msg)
def sha(b): return hashlib.sha256(b).hexdigest()
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def pin(compare,rec,label):
    need(isinstance(rec,dict) and {'path','bytes','sha256'}<=rec.keys(),f'{label}: malformed pin')
    p=Path(rec['path']).resolve(strict=True); b=p.read_bytes()
    need(len(b)==rec['bytes'] and sha(b)==rec['sha256'],f'{label}: live bytes/SHA differ: {p}')
    return p,b
def walk_pins(compare,obj,label):
    if isinstance(obj,dict):
        if {'path','bytes','sha256'}<=obj.keys(): pin(compare,obj,label); return
        for k,v in obj.items(): walk_pins(compare,v,f'{label}.{k}')
    elif isinstance(obj,list):
        for i,v in enumerate(obj): walk_pins(compare,v,f'{label}[{i}]')
def parse_rows(raw):
    rx=re.compile(r'^CASE index=(\d+) name=([^ ]+) result=([^ ]+) exception=([^ ]+) events=(.*)$')
    out=[]
    for i,line in enumerate(raw.decode('utf-8','strict').splitlines()):
        m=rx.fullmatch(line); need(m is not None and i<len(CASE_NAMES),f'malformed case row: {line!r}')
        idx,name,result,exc,events=m.groups(); need(int(idx)==i and name==CASE_NAMES[i],f'case order/name mismatch: {line!r}')
        out.append({'index':i,'name':name,'result':result,'exception_type':exc,'events':events,'raw':line})
    need(len(out)==10,f'expected ten observed cases, got {len(out)}'); return out
def semantic(rows): return [{k:r[k] for k in ('index','name','result','exception_type','events')} for r in rows]
def boundaries(b): return {0,len(b),*(i for i,x in enumerate(b) if x&0xc0!=0x80)}
def physical(compare,parser,path):
    b=path.read_bytes(); a=compare.parse_class(path); p=parser.parse_class_file(b)
    need((a['class_name'],a['major'],a['methods'])==(p['class_name'],p['major'],p['methods']),f'parser disagreement: {path}')
    need(sorted(a['fields'])==sorted((x['name'],x['descriptor'],x['access']) for x in p['fields']),f'field parser disagreement: {path}')
    a['access']=p['access']; keys={(m['name'],m['descriptor']) for m in a['methods']}
    need(len(keys)==len(a['methods']),f'duplicate physical method: {path}')
    for m in a['methods']:
        c=m.get('code'); need(c is not None,f'missing Code: {path}:{m["name"]}{m["descriptor"]}')
        code=bytes.fromhex(c['code_hex']); need(len(code)==c['code_length'] and parser.decode_bcis(code)==c['bcis'],f'BCI decode mismatch: {path}:{m["name"]}')
        for row in c['rows']:
            s,e,h,t=row; need(0<=s<e<=len(code) and 0<=h<len(code) and t>=0,f'bad handler row: {path}:{row}')
    return a

# Minimal classfile reader for the exact target's method Signature and get/checkcast refs.
# It reads ASCII classfile names/signatures only; all instructions are independently BCI-decoded above.
def classfile_probe(data):
    pos=0
    def take(n):
        nonlocal pos
        need(n>=0 and pos+n<=len(data),'truncated target classfile')
        x=data[pos:pos+n]; pos+=n; return x
    def u1(): return take(1)[0]
    def u2(): return int.from_bytes(take(2),'big')
    def u4(): return int.from_bytes(take(4),'big')
    need(u4()==0xcafebabe,'target is not a classfile'); u2(); major=u2(); count=u2(); cp=[None]*count; i=1
    while i<count:
        tag=u1()
        if tag==1:
            n=u2(); raw=take(n); cp[i]=('utf8',raw.decode('latin1'))
        elif tag in (3,4): take(4)
        elif tag in (5,6): take(8); i+=1
        elif tag in (7,8,16,19,20): cp[i]=(tag,u2())
        elif tag in (9,10,11,12,17,18): cp[i]=(tag,u2(),u2())
        elif tag==15: cp[i]=(tag,u1(),u2())
        else: raise ValueError(f'unknown cp tag {tag}')
        i+=1
    def utf(ix):
        x=cp[ix]; need(x and x[0]=='utf8','bad UTF8 cp index'); return x[1]
    def cls(ix):
        x=cp[ix]; need(x and x[0]==7,'bad class cp index'); return utf(x[1])
    access=u2(); this=u2(); u2(); owner=cls(this)
    for _ in range(u2()): u2()
    def attrs():
        out=[]
        for _ in range(u2()):
            name=utf(u2()); n=u4(); out.append((name,take(n)))
        return out
    fields=[]
    for _ in range(u2()):
        f=(u2(),utf(u2()),utf(u2())); attrs(); fields.append(f)
    methods=[]
    for _ in range(u2()):
        flags=u2(); name=utf(u2()); desc=utf(u2()); sig=None; code=None
        for an,body in attrs():
            if an=='Signature': need(len(body)==2,'bad Signature attribute'); sig=utf(int.from_bytes(body,'big'))
            if an=='Code':
                q=0
                def rd(n):
                    nonlocal q
                    x=body[q:q+n]; need(len(x)==n,'truncated Code attr'); q+=n; return x
                maxstack=int.from_bytes(rd(2),'big'); maxlocals=int.from_bytes(rd(2),'big'); n=int.from_bytes(rd(4),'big'); bc=rd(n)
                code=bc
        methods.append({'access':flags,'name':name,'descriptor':desc,'signature':sig,'code':code})
    attrs(); need(pos==len(data),'trailing classfile bytes')
    return {'major':major,'owner':owner,'fields':fields,'methods':methods,'cp':cp,'utf':utf,'cls':cls}
def check_target_signature_and_get(parser,profile):
    target=Path(profile['target_facts']['path']).resolve(strict=True); data=target.read_bytes(); cf=classfile_probe(data)
    need(cf['owner']==INTERNAL and cf['major']==52 and not cf['fields'], 'original target owner/major/field inventory differs')
    m=next(x for x in cf['methods'] if (x['name'],x['descriptor'])==('test','(Ljava/util/List;)Z'))
    need(m['signature']=='(Ljava/util/List<Ljava/lang/String;>;)Z','original classfile method Signature is not List<String>')
    code=m['code']; need(code is not None,'target test lacks Code')
    bc=parser.decode_bcis(code); cp=cf['cp']; utf=cf['utf']; cls=cf['cls']; gets=[]; casts=[]
    for bci in bc:
        op=code[bci]
        if op==0xb9:
            ix=int.from_bytes(code[bci+1:bci+3],'big'); ref=cp[ix]; need(ref and ref[0]==11,'invokeinterface does not reference InterfaceMethodref')
            nt=cp[ref[2]]; need(nt and nt[0]==12,'bad get name/type')
            triple=(cls(ref[1]),utf(nt[1]),utf(nt[2]))
            if triple[1]=='get': gets.append((bci,triple))
        if op==0xc0:
            casts.append((bci,cls(int.from_bytes(code[bci+1:bci+3],'big'))))
    need(len(gets)==1 and gets[0][1]==('java/util/List','get','(I)Ljava/lang/Object;'),'physical get is not the exact erased List.get contract')
    need(len(casts)==1 and casts[0][1]=='java/lang/String','physical element checkcast is not exact String')
    get_bci,cast_bci=gets[0][0],casts[0][0]
    need(cast_bci==get_bci+5 and code[get_bci+3]==2 and code[get_bci+4]==0,
         'physical String checkcast is not immediately after the exact List.get interface instruction')
    return {'target_sha256':sha(data),'signature':m['signature'],'get_bci':get_bci,'cast_bci':cast_bci}
def check_map(method,fact,owner,label):
    body=method['outcome']['report']; text=body['text'].encode('utf-8'); bounds=boundaries(text)
    segments=body.get('source_map',{}).get('segments'); need(isinstance(segments,list),f'{label}: no source map segments')
    expected=set(fact['code']['bcis']); mapped=set(); identity=method['item']['identity']
    for seg in segments:
        s,e=seg.get('start'),seg.get('end'); need(type(s)==int and type(e)==int and 0<=s<=e<=len(text) and s in bounds and e in bounds,f'{label}: invalid UTF-8 map span')
        origin=seg.get('origin'); need(isinstance(origin,dict) and isinstance(origin.get('primary'),dict),f'{label}: missing origin')
        for o in [origin['primary'],*origin.get('derived',[])]:
            bci=o.get('bci'); need(type(bci)==int and bci in expected,f'{label}: origin BCI outside physical method')
            om=o.get('method'); need(isinstance(om,dict) and om.get('owner')==owner and om.get('name')==identity['name'] and om.get('descriptor')==identity['descriptor'],f'{label}: origin method/owner mismatch')
            mapped.add(bci)
    need(body.get('quality')=='structured' and not (body.get('fallbacks') or []),f'{label}: baseline method is not structured/no-fallback')
    need(mapped==expected,f'{label}: source map misses physical Code BCIs: {sorted(expected-mapped)}')
    return {'bcis':len(expected),'segments':len(segments),'text_bytes':len(text)}
def member_surface(f): return (f['class_name'],f['access'],tuple(sorted((x['name'],x['descriptor'],x['access']) for x in f['fields'])),tuple(sorted((x['name'],x['descriptor'],x['access']) for x in f['methods'])))
def command_map(doc,compare,expected_count):
    rows=doc.get('commands',[]); need(len(rows)==expected_count,f'expected {expected_count} commands, got {len(rows)}')
    out={}
    for r in rows:
        i=r.get('index'); need(type(i)==int and i not in out and i>=1,f'duplicate/malformed command index {i}')
        need(r.get('guard_stop') is None and r.get('free_bytes_after',0)>=5*1024**3 and r.get('peak_target_bytes',0)<=1024**3,f'command guard failed: {i}')
        need(set(r.get('streams',{}))=={'stdout','stderr'},f'command {i}: missing raw streams')
        for ch in ('stdout','stderr'): compare.command_artifact(r,ch)
        out[i]=r
    need(sorted(out)==list(range(1,expected_count+1)),'command indices not contiguous')
    return out

def check_baseline(path,receipt_sha,compare,parser):
    raw=path.read_bytes(); need(sha(raw)==receipt_sha,'baseline receipt SHA differs from argument'); d=json.loads(raw)
    need(d.get('schema')==BASE_SCHEMA and d.get('status')=='captured-pending-independent-review','baseline schema/status incomplete')
    for key in ('source_unchanged','local_copies_unchanged','local_copies_unchanged_finally','external_inputs_unchanged','source_unchanged_finally','target_absent','target_absent_finally'):
        need(d.get(key) is True,f'baseline closure gate false: {key}')
    need(d['source_pins_before']==d['source_pins_after']==d['source_pins_after_finally'],'source closure snapshots differ')
    need(d['source_pins_before']==compare.source_closure(ROOT),'live repository source closure differs from baseline capture')
    need(d['external_input_pins_before']==d['external_input_pins_after']==d['external_input_pins_after_finally'],'external input snapshots differ')
    need(d['local_copy_pins_before']==d['local_copy_pins_after']==d['local_copy_pins_after_finally'],'local copy snapshots differ')
    cmds=command_map(d,compare,20)
    walk_pins(compare,d['external_input_pins_before'],'baseline external'); walk_pins(compare,d['local_copy_pins_before'],'baseline copies')
    walk_pins(compare,d['source'],'source'); walk_pins(compare,d['source_copy'],'source copy'); walk_pins(compare,d['driver_source'],'driver source'); walk_pins(compare,d['driver_copy'],'driver copy'); walk_pins(compare,d['runtime_wrapper'],'wrapper')
    need(d['cli']['sha256']=='56a589ef9a170a1bb2911ed5597c20b2b4e06abf78da845f8fd3946099b2fa51' and d['source']['sha256']=='795ea73a0acfc5695f9e67c456746919f889d52026695f406d88f9693469b6db','baseline CLI/source pin is not frozen original')
    for key,expected in [('compare',COMPARE_SHA),('physical_parser',PARSER_SHA),('guard',GUARD_SHA),('scanner',SCANNER_SHA),('jadx_jar','966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'),('jadx','64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7')]:
        need(d[key]['sha256']==expected,f'baseline pinned tool differs: {key}')
    need(d['driver_source']['sha256']=='8c6cac9925421ef55358a3ab6fbe578ad1ad28c5364667befe279ae25c69afdd','standalone runtime driver differs from frozen parentless driver')
    need(d['dependency_reference']['sha256']=='5a7d6572e600d19dc45d78030d0b12867bc742c4b014381fb5c7b059db171d35','dependency reference differs from pinned original harness receipt')
    need(d['runtime_wrapper']['sha256']=='73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca','runtime guard wrapper differs from frozen helper')
    drv,db=pin(compare,d['driver_source'],'driver source'); need(drv.read_bytes()==Path(d['driver_copy']['path']).read_bytes(),'driver source copy differs')
    dc=cmds[d['driver_compile']['command']]; need(dc['exit_code']==0 and dc['label']=='compile-independent-reflection-driver' and dc['tool_leg']=='javac8','baseline standalone driver did not compile')
    need(dc['argv'][0]==d['jdk_manifest']['tools']['javac8']['javac']['path'] and str(Path(d['driver_copy']['path']).resolve()) in dc['argv'] and dc['argv'][dc['argv'].index('-classpath')+1]==str(Path(d['output'])/'empty-classpath'),'baseline driver is not compiled with isolated classpath')
    need(d['driver_compile']['stdout']==dc['streams']['stdout'] and d['driver_compile']['stderr']==dc['streams']['stderr'],'baseline driver compile raw pins differ')
    for marker in (b'new URLClassLoader(new URL[] {url}, null)',b'wrong CodeSource:',b'target.getClassLoader() != loader'):
        need(re.sub(rb'\s+',b'',marker) in re.sub(rb'\s+',b'',db),f'parentless driver lacks guard marker {marker!r}')
    driver_files=sorted((Path(d['output'])/'driver-classes').rglob('*.class'))
    need({p.name for p in driver_files}=={'TestNestedLoops2Driver.class','TestNestedLoops2Driver$Case.class','TestNestedLoops2Driver$Observation.class','TestNestedLoops2Driver$RecordingList.class'},'baseline driver class tree differs')
    walk_pins(compare,d['driver_classes'],'baseline driver classfiles')
    dep_path,_=pin(compare,d['dependency_reference'],'dependency reference'); dep=json.loads(dep_path.read_text(encoding='utf-8'))
    need(dep.get('schema')=='cf11-original-nestedloops3-baseline-v1' and dep.get('classpath')==d['dependency_classpath'] and dep.get('harness_jar')==d['dependency_harness_jar'] and dep.get('jar_pins')==d['dependency_jar_pins'],'baseline dependency receipt differs from original harness evidence')
    for rec in [dep['harness_jar'],*dep.get('jar_pins',[])]: pin(compare,rec,'harness dependency')
    class_names={INTERNAL+'.class',OUTER+'.class'}
    for rec in [dep['harness_jar'],*dep.get('jar_pins',[])]:
        if rec['path'].endswith('.jar'):
            with zipfile.ZipFile(rec['path']) as jar: need(not (class_names & set(jar.namelist())),'target class leaked into compile/runtime harness JAR')
    dep_dirs=dep.get('directory_pins',dep.get('directory_pins_before',{})); need(dep_dirs==d['dependency_directory_pins'],'dependency directory snapshot differs')
    for folder,expected_pins in dep_dirs.items():
        actual={p.relative_to(Path(folder)).as_posix():compare.pin(p) for p in sorted(Path(folder).rglob('*.class'))}
        need(actual==expected_pins and not any((Path(folder)/n).is_file() for n in class_names),f'harness class directory changed or contains target: {folder}')
    need(isinstance(d['dependency_classpath'],list) and d['dependency_classpath'],'empty harness classpath')
    labels=[r['label'] for r in cmds.values()]
    expected={'javac8-full-upstream-source-boundary','javac23-full-source-debug','javac23-full-source-no-debug','compile-independent-reflection-driver','driver-code-source-wrong-root-control','jadx-version'}
    expected |= {f'original-runtime-{p}-{r}' for p in PROFILES for r in RUNTIMES}
    expected |= {f'jarde-{p}-{f}-{e}' for p in PROFILES for f in FORMS for e in EVIDENCE}
    expected |= {f'jadx-full-bundle-{p}-default' for p in PROFILES}
    need(set(labels)==expected and len(labels)==len(set(labels)),'baseline command labels are not the exact 20-command inventory')
    # Full upstream Java 8 attempt is a preserved boundary failure, not a trimmed-source substitute.
    boundary=d['javac8_full_source_boundary']; br=cmds[boundary['command']]; err=compare.command_artifact(br,'stderr')
    need(boundary['exit_code']==br['exit_code']==1 and boundary['major_55_diagnostic_observed'] and (b'55.0' in err or b'version 55' in err),'JDK 8 full-source major-55 boundary not proven in raw stderr')
    bav=br['argv']; need(bav[0]==d['jdk_manifest']['tools']['javac8']['javac']['path'] and str(Path(d['source_copy']['path']).resolve()) in bav and '-source' in bav and '-target' in bav and bav[bav.index('-source')+1]=='8' and bav[bav.index('-target')+1]=='8','JDK8 boundary did not compile exact full upstream source')
    need(boundary['stdout']==br['streams']['stdout'] and boundary['stderr']==br['streams']['stderr'],'JDK8 boundary saved raw pins differ')
    # Reopen all source profiles, exact nested/outer trees, parser agreements and complete physical Code BCIs.
    profiles={r['profile']:r for r in d['source_profiles']}; need(set(profiles)==set(PROFILES),'source profile grid incomplete')
    surfaces={}; facts={}; raw_sig={}
    for p,row in profiles.items():
        cmd=cmds[row['command']]; need(row['exit_code']==0 and cmd['exit_code']==0,f'{p}: JDK23 source compile failed')
        need(cmd['label']==f'javac23-full-source-{p}' and cmd['tool_leg']=='javac23','wrong source-profile compiler command')
        av=cmd['argv']; need(av[0]==d['jdk_manifest']['tools']['javac23']['javac']['path'] and '--release' in av and av[av.index('--release')+1]=='8' and ('-g' if p=='debug' else '-g:none') in av,'profile javac23 flags differ')
        need('-classpath' in av and av[av.index('-classpath')+1]==os.pathsep.join(d['dependency_classpath']) and '-sourcepath' in av and av[av.index('-sourcepath')+1]==str(Path(d['output'])/'empty-classpath'),'profile compile class/source path differs')
        need(str(Path(d['source_copy']['path']).resolve()) in av and '-d' in av and Path(av[av.index('-d')+1]).resolve()==Path(row['class_root']).resolve(),'full source profile command/source destination binding differs')
        tree={k:v for k,v in row['class_tree'].items()}; need(set(tree)=={INTERNAL+'.class',OUTER+'.class'},f'{p}: full source did not produce exactly outer+child classes')
        walk_pins(compare,tree,'profile class tree')
        for rel,record in tree.items():
            q,_=pin(compare,record,f'{p} class tree {rel}'); need(q==Path(row['class_root']).resolve()/rel,'profile class tree pin path differs from class root')
        target=physical(compare,parser,Path(row['target_facts']['path'])); outer=physical(compare,parser,Path(row['outer_facts']['path']))
        need(target==row['target_facts'] and outer==row['outer_facts'],f'{p}: saved class facts differ from physical parser')
        need(Path(row['target_facts']['path']).resolve()==Path(row['class_root']).resolve()/(INTERNAL+'.class') and Path(row['outer_facts']['path']).resolve()==Path(row['class_root']).resolve()/(OUTER+'.class'),'profile class facts are detached from complete output tree')
        need(target['class_name']==INTERNAL and target['major']==52 and not target['fields'],'target class identity/fields/major mismatch')
        need([(m['name'],m['descriptor']) for m in target['methods']]==[('<init>','()V'),('test','(Ljava/util/List;)Z')],'target method order/inventory differs from exact ctor/test pair')
        need(outer['class_name']==OUTER and outer['major']==52,'outer class identity/major mismatch')
        facts[p]=target; surfaces[p]=member_surface(target); raw_sig[p]=check_target_signature_and_get(parser,row)
        for m in target['methods']+outer['methods']:
            c=m['code']; need(parser.decode_bcis(bytes.fromhex(c['code_hex']))==c['bcis'],f'{p}: full Code BCI mismatch')
    need(surfaces['debug']==surfaces['no-debug'],'debug/no-debug target member/access inventory differs')
    need((raw_sig['debug']['signature'],raw_sig['debug']['get_bci'],raw_sig['debug']['cast_bci'])==(raw_sig['no-debug']['signature'],raw_sig['no-debug']['get_bci'],raw_sig['no-debug']['cast_bci']),'debug/no-debug physical Signature/get/cast differ')
    src,srcbytes=pin(compare,d['source'],'complete upstream Java source'); scp,scpbytes=pin(compare,d['source_copy'],'copied complete source'); need(srcbytes==scpbytes and sha(srcbytes)=='795ea73a0acfc5695f9e67c456746919f889d52026695f406d88f9693469b6db','full upstream source copy differs from frozen source')
    # Every original VM output is parsed anew and matches saved rows exactly; four profile×VM oracle cells.
    oracle={}; rt=d.get('original_runtime',[]); need(len(rt)==4,'four original VM rows required')
    for row in rt:
        key=(row['profile'],row['runtime']); need(key not in oracle and row['exit_code']==0,'duplicate/failed original runtime')
        cmd=cmds[row['command']]; need(cmd['label']==f'original-runtime-{key[0]}-{key[1]}' and cmd['tool_leg']==key[1] and cmd['exit_code']==0,'runtime command binding mismatch')
        av=cmd['argv']; driver_root=str(Path(d['output'])/'driver-classes'); target_root=str(Path(profiles[key[0]]['class_root']).resolve())
        need(av[-3]=='TestNestedLoops2Driver' and av[-2:]==[target_root,target_root] and '-Xverify:all' in av and av[av.index('-cp')+1]==driver_root,'original runtime driver-only classpath/target binding mismatch')
        need(av[1:4]==['-B',d['runtime_wrapper']['path'],'30'] and av[4]==d['jdk_manifest']['tools'][key[1]]['java']['path'],'original runtime wrapper/JVM argument mismatch')
        got=parse_rows(compare.command_artifact(cmd,'stdout')); need(row['rows']==got and row['row_count']==10,'saved original cases differ from raw stdout')
        need(row['stdout']==cmd['streams']['stdout'],'runtime stream pin differs from command stream')
        oracle[key]=semantic(got)
    need(set(oracle)=={(p,r) for p in PROFILES for r in RUNTIMES} and d['runtime_semantic_agreement'] is True and len({json.dumps(v,sort_keys=True) for v in oracle.values()})==1,'original four VM oracles differ')
    # Wrong-root real guard must reject the actual target root with raw diagnostic.
    w=d['wrong_root_control']; wc=cmds[w['command']]; we=compare.command_artifact(wc,'stderr')
    need(wc['exit_code']==1 and b'wrong CodeSource:' in we and w['rejected'] is True,'wrong-root control did not prove rejection')
    need(wc['argv'][-2:]==[w['actual_target_root'],w['expected_wrong_root']],'wrong-root argv binding differs')
    need(wc['argv'][wc['argv'].index('-cp')+1]==str(Path(d['output'])/'driver-classes') and wc['argv'][-3]=='TestNestedLoops2Driver','wrong-root classpath/driver binding differs')
    need(w['stdout']==wc['streams']['stdout'] and w['stderr']==wc['streams']['stderr'],'wrong-root raw pin mismatch')
    # Exact eight Jarde requests; raw command output is the saved JSON and source bytes are exact API text.
    cells=d.get('jarde_cells',[]); need(len(cells)==8,'Jarde API count is not eight')
    api_docs={}; maps={}; digest_by_profile={p:set() for p in PROFILES}
    for cell in cells:
        key=(cell['profile'],cell['input_form'],cell['evidence']); need(cell['exit_code']==0,'Jarde API request failed')
        need(key[0] in PROFILES and key[1] in FORMS and key[2] in EVIDENCE,'unexpected API selector')
        cmd=cmds[cell['command']]; need(cmd['exit_code']==0 and cmd['label']==f'jarde-{key[0]}-{key[1]}-{key[2]}','API row/command mismatch')
        inp,b=pin(compare,cell['input'],'API input'); profile=profiles[key[0]]; target_path=Path(profile['target_facts']['path']).resolve()
        if key[1]=='child': need(inp==target_path and b==target_path.read_bytes(),'child input is not exact matching profile class')
        else:
            with zipfile.ZipFile(inp) as z:
                names=z.namelist(); need(len(names)==2 and set(names)=={INTERNAL+'.class',OUTER+'.class'},'bundle is not exact complete two-class archive')
                need(z.read(INTERNAL+'.class')==target_path.read_bytes(),'bundle child differs from same-profile original class')
        argv=cmd['argv']; policy='single-class' if key[1]=='child' else 'plain-jar'
        need(argv[0]==d['cli']['path'] and argv[1:]==['class-source','--input',str(inp),'--class',INTERNAL,'--policy',policy,'--release','8','--format','json']+(['--evidence','all'] if key[2]=='all' else []),'API argv selector/input mismatch')
        report_path,report_raw=pin(compare,cell['report'],'API saved report'); stdout=compare.command_artifact(cmd,'stdout')
        need(stdout==report_raw,'API command stdout differs from saved JSON report')
        doc=json.loads(report_raw.decode('utf-8','strict')); source_path,source=pin(compare,cell['whole_source'],'API full source')
        need(doc.get('text','').encode('utf-8')==source,'saved whole source is not exact report.text')
        owner=doc['class']; need(owner==doc['methods'][0]['item']['identity']['owner'],'class/method owner mismatch')
        need(owner['class_bytes']['length']==len(target_path.read_bytes()),'API owner class length differs from input')
        need(owner['class_bytes']['digest'] and len(owner['class_bytes']['digest'])==64,'API owner BLAKE3 identity missing')
        need(owner['location']['kind']==('standalone_root' if key[1]=='child' else 'archive_entry'),'API owner location kind mismatch')
        if key[1]=='child': need(owner['location']['snapshot']==owner['class_bytes']['digest'],'standalone owner digest/snapshot mismatch')
        else:
            rawname=bytes(owner['location']['entry']['raw_name']).decode('utf-8','strict'); need(rawname==INTERNAL+'.class','archive owner entry differs')
        digest_by_profile[key[0]].add(owner['class_bytes']['digest'])
        need(len(doc['methods'])==2,'API method inventory must contain exactly ctor/test')
        method_projection=[]
        for i,(m,fact) in enumerate(zip(doc['methods'],facts[key[0]]['methods'])):
            item=m['item']; name=item['name']['escaped']; desc=item['descriptor']['escaped']; ident=item['identity']
            expected=('<init>','()V') if i==0 else ('test','(Ljava/util/List;)Z')
            need((name,desc,item['access_flags'],item['index'])==(expected[0],expected[1],fact['access'],i),'API physical method identity/access/order mismatch')
            need(ident['name']==item['name']['raw'] and ident['descriptor']==item['descriptor']['raw'],'API identity byte vectors mismatch')
            need(ident['owner']==owner and (fact['name'],fact['descriptor'],fact['access'])==(name,desc,item['access_flags']),'API identity is not same physical method/input')
            body=m['outcome']['report']; need(body['artifact']['binding']['method']==ident and body.get('method')==name+desc,'body artifact method binding mismatch')
            maps[(key,name+desc)]=check_map(m,fact,owner,f'{key}/{name}{desc}')
            method_projection.append((m.get('declaration'),m['outcome'].get('kind'),body.get('quality'),body.get('fallbacks'),body.get('content'),body.get('text'),body.get('source_map')))
        api_docs[key]=(doc,source,method_projection)
    expected_api={(p,f,e) for p in PROFILES for f in FORMS for e in EVIDENCE}
    need(set(api_docs)==expected_api,'Jarde API grid is not exact 2×2×2')
    for p in PROFILES:
        need(len(digest_by_profile[p])==1,'child/bundle owner BLAKE3 differs within profile')
        for f in FORMS:
            low,full=api_docs[(p,f,'default')],api_docs[(p,f,'all')]
            need(low[0]['text']==full[0]['text'] and low[1]==full[1] and low[2]==full[2],f'{p}/{f}: default/all complete source/method map differs')
    # Complete JADX outer+child output is preserved once per source profile; do not mistake version probe for decode.
    jrows=d.get('jadx_outputs',[]); need(len(jrows)==2,'expected exactly two JADX full-bundle outputs')
    for jr in jrows:
        p=jr['compiler_profile']; need(p in PROFILES and jr['display_profile']=='default' and jr['exit_code']==0,'JADX decode failed')
        cmd=cmds[jr['command']]; need(cmd['exit_code']==0 and cmd['label']==f'jadx-full-bundle-{p}-default','JADX command binding mismatch')
        need(len(jr['sources'])>=1,'JADX full-source inventory empty')
        need(cmd['argv'][0]==d['jadx']['path'] and '-d' in cmd['argv'] and Path(cmd['argv'][cmd['argv'].index('-d')+1]).resolve().is_dir(),'JADX output directory/launcher mismatch')
        need(str(Path(profiles[p]['bundle']['path']).resolve()) in cmd['argv'],'JADX command did not consume full original bundle')
        dest=Path(cmd['argv'][cmd['argv'].index('-d')+1]).resolve(); need(all(Path(sr['path']).resolve().is_relative_to(dest) for sr in jr['sources']),'JADX output source escapes its decode root')
        actual_java={str(q.resolve()):compare.pin(q) for q in sorted(dest.rglob('*.java'))}
        need(actual_java=={str(Path(sr['path']).resolve()):sr for sr in jr['sources']},'JADX source list is not the complete output tree')
        texts=[]
        for sr in jr['sources']:
            sp,sb=pin(compare,sr,'JADX source'); texts.append((sp.name,sb.decode('utf-8','strict')))
        need(any(n=='TestNestedLoops2.java' for n,_ in texts),'JADX outer source absent')
        full='\n'.join(t for _,t in texts); need('TestNestedLoops2$TestCls' in full or 'class TestCls' in full,'JADX nested child source absent')
        if p=='no-debug': need('while (i < list.get(i2).length())' in full,'no-debug JADX full source does not contain the observed repeated get')
        else: need('String s = list.get(i);' in full and 'while (j < s.length())' in full,'debug JADX full source differs from one-get/local control')
    # Return profile facts used by matrix validation.
    return {'doc':d,'path':path.resolve(),'commands':cmds,'profiles':profiles,'facts':facts,'oracles':oracle,'api_docs':api_docs,'source_sha':receipt_sha,'raw_signature':raw_sig,'no_debug_jadx_inline_get':True}

def check_matrix(path,receipt_sha,base,compare,parser,jdks,jdk_record):
    raw=path.read_bytes(); need(sha(raw)==receipt_sha,'matrix receipt SHA differs from argument'); d=json.loads(raw)
    need(d.get('schema')==MATRIX_SCHEMA and d.get('status')=='captured-pending-independent-review','matrix schema/status incomplete')
    need(d.get('jdk_manifest')==jdk_record,'matrix JDK manifest binding differs from frozen manifest')
    bp=base['path']
    need(d.get('baseline_receipt')==compare.pin(bp) and d.get('baseline_sha256_argument')==base['source_sha'],'matrix is not bound to exact reviewed baseline receipt')
    for k in ('source_unchanged','source_unchanged_finally','external_inputs_unchanged','local_copies_unchanged','target_absent','target_absent_finally','generated_outputs_unchanged','generated_outputs_unchanged_finally'):
        need(d.get(k) is True,f'matrix closure gate false: {k}')
    need(d['source_pins_before']==d['source_pins_after']==d['source_pins_after_finally'],'matrix source closure snapshots differ')
    need(d['external_pins_before']==d['external_pins_after']==d['external_pins_after_finally'],'matrix external pin snapshots differ')
    need(d['dependency_directory_pins_before']==d['dependency_directory_pins_after']==d['dependency_directory_pins_after_finally'],'dependency directory snapshots differ')
    need(d['local_copies_before']==d['local_copies_after']==d['local_copies_after_finally'],'matrix local copies differ')
    need(d['generated_output_pins_before']==d['generated_output_pins_after']==d['generated_output_pins_after_finally'],'generated output pins differ')
    walk_pins(compare,d['external_pins_before'],'matrix external'); walk_pins(compare,d['local_copies_before'],'matrix local copies')
    walk_pins(compare,d['generated_output_pins_before'],'generated output')
    need(d['source_pins_before']==compare.source_closure(ROOT),'matrix live source closure differs')
    commands=command_map(d,compare,75)
    need(d['source_pins_before']==base['doc']['source_pins_before'],'matrix was not run against the unchanged source closure of baseline')
    # Exact ten full-source inputs, each copied byte-for-byte from the baseline's API/JADX outputs.
    base_jarde={(x['profile'],x['input_form'],x['evidence']):x for x in base['doc']['jarde_cells']}
    base_jadx={x['compiler_profile']:x for x in base['doc']['jadx_outputs']}
    cells=d.get('source_cells',[]); need(len(cells)==10,'matrix must have eight API plus two full JADX source cells')
    cell_by_key={}; source_inventory={}
    for c in cells:
        key=tuple(c['cell_key']); kind=c['kind']; need(key not in cell_by_key,'duplicate matrix source cell'); cell_by_key[key]=c
        if kind=='jarde':
            need(len(key)==3 and key in base_jarde,'unexpected Jarde source selector')
            old=base_jarde[key]
            copy_rows=c.get('source_copies',[]); need(len(copy_rows)==1,'Jarde source must be one full compilation unit')
            srcpin=old['whole_source']; src,_=pin(compare,srcpin,'baseline full Jarde source'); cp,cbytes=pin(compare,copy_rows[0]['copy'],'copied Jarde source')
            need(copy_rows[0]['source']==srcpin and cbytes==src.read_bytes(),'Jarde full source copy differs')
            need(Path(cp).name=='TestNestedLoops2$TestCls.java' and Path(cp).as_posix().endswith('/jadx/tests/integration/loops/TestNestedLoops2$TestCls.java'),'Jarde source copy path/package wrong')
            report_path,_=pin(compare,old['report'],'baseline API report'); doc=json.loads(report_path.read_bytes()); need(doc['text'].encode('utf-8')==src.read_bytes(),'whole source differs from report text')
            need(copy_rows[0]['source']==old['whole_source'],'Jarde compile source is not the exact saved full source')
            source_inventory[key]=[str(cp)]
        elif kind=='jadx':
            need(key in {('debug','bundle'),('no-debug','bundle')} and c['form']=='bundle' and c['evidence']=='source','unexpected JADX source selector')
            prof=key[0]; old=base_jadx[prof]; pin(compare,old['input'],'JADX original complete bundle')
            old_sources=old['sources']; copies=c.get('source_copies',[]); need(len(copies)==len(old_sources) and len(copies)>0,'JADX source inventory not complete')
            copied=[]
            for a,z in zip(old_sources,copies):
                need(z['source']==a,'JADX source pin reordered or substituted')
                a_path,a_bytes=pin(compare,a,'JADX whole-source artifact'); z_path,z_bytes=pin(compare,z['copy'],'JADX source copy')
                need(a_bytes==z_bytes,'JADX source bytes changed'); copied.append(str(z_path))
            need(any(Path(x).name=='TestNestedLoops2.java' for x in copied),'complete JADX outer source omitted')
            jcmd=base['commands'][old['command']]; jdest=Path(jcmd['argv'][jcmd['argv'].index('-d')+1]).resolve()
            need(all(Path(x).is_relative_to(jdest) for x in [str(Path(z['path']).resolve()) for z in old_sources]),'JADX sources escape the complete output directory')
            actual_sources={str(p.resolve()):compare.pin(p) for p in sorted(jdest.rglob('*.java'))}
            need(actual_sources=={str(Path(z['path']).resolve()):z for z in old_sources},'JADX source pin inventory is not complete')
            need([z['source'] for z in copies]==old_sources,'JADX source list differs from full decode output')
            source_inventory[key]=copied
        else: raise ValueError(f'unknown source kind {kind}')
    expected={('jarde',p,f,e) for p in PROFILES for f in FORMS for e in EVIDENCE}|{('jadx',p,'bundle') for p in PROFILES}
    observed={('jarde',*k) for k in cell_by_key if len(k)==3}|{('jadx',*k) for k in cell_by_key if len(k)==2}
    need(observed==expected,'matrix full source selector grid is incomplete')
    # Driver-only compilation/runtime harness. Never permit target classpath or target root substitution.
    driver_copy=Path(d['driver_copy']['path']).resolve(strict=True); driver_src=Path(d['driver_source']['path']).resolve(strict=True)
    pin(compare,d['driver_source'],'driver source'); pin(compare,d['driver_copy'],'driver copy')
    need(driver_src.read_bytes()==driver_copy.read_bytes() and sha(driver_src.read_bytes())=='8c6cac9925421ef55358a3ab6fbe578ad1ad28c5364667befe279ae25c69afdd','matrix driver source copy differs from frozen parentless driver')
    driver_compile=d['driver_compile']; dc=commands[driver_compile['command']]
    need(dc['exit_code']==driver_compile['exit_code']==0 and dc['tool_leg']=='javac8' and dc['label']=='compile-reflection-driver','matrix driver compile missing/failed')
    need(str(driver_copy) in dc['argv'] and '-source' in dc['argv'] and '-target' in dc['argv'] and dc['argv'][dc['argv'].index('-classpath')+1]==str(Path(d['output'])/'empty-classpath'),'driver compile not isolated/source-bound')
    driver_root=Path(d['output'])/'driver-classes'; driver_files=sorted(driver_root.rglob('*.class'))
    expect_driver={'TestNestedLoops2Driver.class','TestNestedLoops2Driver$Case.class','TestNestedLoops2Driver$Observation.class','TestNestedLoops2Driver$RecordingList.class'}
    need({x.name for x in driver_files}==expect_driver,'standalone driver class inventory differs')
    need({x['path']:x for x in d['driver_classes']}=={str(x.resolve()):compare.pin(x) for x in driver_files},'matrix driver class pins differ from live tree')
    for r in d['driver_classes']: pin(compare,r,'driver class')
    # Exact 20 compiler cells, only expected JDK8 outer/JADX major-55 boundary failures allowed.
    comps=d.get('compilations',[]); need(len(comps)==20,'expected 10×2 whole-source compile attempts')
    comp_by={}; source_cell_by={tuple(c['cell_key']):c for c in cells}
    for c in comps:
        key=tuple(c['cell_key']); leg=c['leg']; ck=(key,leg); need(ck not in comp_by and leg in LEGS,'duplicate/invalid compiler selector'); comp_by[ck]=c
        cmd=commands[c['command']]; need(cmd['exit_code']==c['exit_code'] and cmd['tool_leg']==leg and cmd['label']==f"compile-{'-'.join(map(str,key))}-{leg}",'compile command selector mismatch')
        av=cmd['argv']; need(av[0]==str(jdks[leg]['tools']['javac']),'wrong pinned javac binary')
        need(('-source' in av and '-target' in av and av[av.index('-source')+1]=='8' and av[av.index('-target')+1]=='8') if leg=='javac8' else '--release' in av and av[av.index('--release')+1]=='8','compiler release flags differ')
        need(('-g' if key[0]=='debug' else '-g:none') in av and '-proc:none' in av,'compiler debug/processor flags differ')
        need('-classpath' in av and av[av.index('-classpath')+1]==os.pathsep.join(base['doc']['dependency_classpath']),'compile dependency classpath changed')
        need('-d' in av and Path(av[av.index('-d')+1]).resolve()==Path(c['class_root']).resolve(),'compile destination mismatch')
        expected_src=source_inventory[key]; start=av.index('-d')+2
        need(len(expected_src)==len(set(expected_src)) and av[start:]==sorted(expected_src),'javac source arguments are not exactly the saved complete source list')
        need(c.get('stdout')==cmd['streams']['stdout'] and c.get('stderr')==cmd['streams']['stderr'],'compiler raw stream pins differ from command')
        tree={p.relative_to(Path(c['class_root'])).as_posix():compare.pin(p) for p in sorted(Path(c['class_root']).rglob('*')) if p.is_file()}
        need(tree==c['class_tree'] and all(k.endswith('.class') for k in tree),'compiler output tree pins differ or contain non-class artifacts')
        if c['exit_code']==0:
            need(c['class_facts'] is not None,'successful compile lacks class facts')
            actual={}
            for rel,pr in tree.items():
                pp,_=pin(compare,pr,'compiled class'); actual[rel]=physical(compare,parser,pp)
            need(actual==c['class_facts'],'compiled class dual-parser facts differ')
            need(all(x['major']==52 for x in actual.values()),'compiled output is not Java 8 classfiles')
            target=actual.get(INTERNAL+'.class'); need(target is not None and {(m['name'],m['descriptor']) for m in target['methods']}==METHODS,'successful target class/method inventory invalid')
            expected_tree={INTERNAL+'.class'} if key[1]!='bundle' else {INTERNAL+'.class',OUTER+'.class'}
            need(set(actual)==expected_tree,'successful full-source output contains a missing/extra class')
            profile=base['profiles'][key[0]]
            need(member_surface(target)==member_surface(profile['target_facts']),'successful target member/access/field inventory differs from original profile')
            if key[1]=='bundle':
                outer=actual.get(OUTER+'.class'); need(outer is not None and member_surface(outer)==member_surface(profile['outer_facts']),'successful outer member/access inventory differs')
        else:
            need(c.get('class_facts') is None,'failed compile falsely reports facts')
            err=compare.command_artifact(cmd,'stderr')
            need(leg=='javac8' and key[1]=='bundle' and b'55.0' in err and b'52.0' in err,'compile refusal is not the observed Java 55-to-52 full-source boundary')
    expected_comp={(tuple(c['cell_key']),leg) for c in cells for leg in LEGS}
    need(set(comp_by)==expected_comp,'compile grid incomplete')
    expected_fail={(('debug','bundle'),'javac8'),(('no-debug','bundle'),'javac8')}
    need({k for k,v in comp_by.items() if v['exit_code']!=0}==expected_fail,'compile refusal classification differs from observed full-source boundary')
    # Raw per-command runtime outputs are authoritative; retain the known complete JADX no-debug event divergence.
    runtime=d.get('runtime_rows',[]); wrong=d.get('wrong_root_rows',[]); need(len(runtime)==36 and len(wrong)==18,'runtime/wrong-root inventory does not match successful compile set')
    oracle=base['oracles']; need(d.get('original_oracles')=={f'{p}/{r}':oracle[(p,r)] for p in PROFILES for r in RUNTIMES},'matrix saved original oracle differs from re-parsed baseline raw oracle'); runtime_keys=set(); wrong_keys=set(); mismatches=[]; jarde_runs=0; jadx_runs=0
    for row in runtime:
        key=tuple(row['cell_key']); leg=row['compiler']; vm=row['runtime']; rk=(key,leg,vm)
        need(rk not in runtime_keys and vm in RUNTIMES and leg in LEGS,'duplicate runtime selector'); runtime_keys.add(rk)
        comp=comp_by[(key,leg)]; cmd=commands[row['command']]
        need(comp['exit_code']==0 and cmd['label']==f"runtime-{'-'.join(map(str,key))}-{leg}-{vm}" and cmd['tool_leg']==vm,'runtime not paired to successful compiled cell/JVM command')
        root=str(Path(comp['class_root']).resolve()); driver=str(driver_root.resolve())
        need(row['application_classpath']==[driver] and cmd['argv'][-3]=='TestNestedLoops2Driver' and cmd['argv'][-2:]==[root,root] and cmd['argv'][cmd['argv'].index('-cp')+1]==driver and '-Xverify:all' in cmd['argv'],'runtime classpath/actual expected root not isolated')
        need(cmd['argv'][1:4]==['-B',d['local_copies_before'][1]['path'],'30'] and cmd['argv'][4]==str(jdks[vm]['tools']['java']),'runtime wrapper/JVM argument binding differs')
        need(row['exit_code']==cmd['exit_code'],'runtime row exit differs from actual command')
        if row['exit_code']==0:
            rows=parse_rows(compare.command_artifact(cmd,'stdout')); need(row['rows']==rows and row['stdout']==cmd['streams']['stdout'] and row['stderr']==cmd['streams']['stderr'],'runtime saved rows/raw pins differ from command streams')
            want=oracle[(key[0],vm)]; matched=semantic(rows)==want
            need(row['matches_original_profile_runtime'] is matched,'saved runtime comparison flag is false/inaccurate')
            if not matched:
                diffs=[]
                for a,b in zip(semantic(rows),want):
                    if a!=b:
                        need(a['result']==b['result'] and a['exception_type']==b['exception_type'],'unexpected result/exception change in known JADX mismatch')
                        need(a['events']!=b['events'],'known mismatch is not event-only')
                        diffs.append({'case':a['name'],'expected_events':b['events'],'actual_events':a['events']})
                mismatches.append({'cell':list(key),'compiler':leg,'runtime':vm,'diffs':diffs})
            if cell_by_key[key]['kind']=='jarde':
                jarde_runs+=1; need(matched,'Jarde regenerated class differs from exact original profile/runtime oracle')
            else: jadx_runs+=1
        else:
            need(row.get('rows') in (None,[]) and row.get('matches_original_profile_runtime') is not True,'failed runtime must not be accepted')
    successes={(k,leg) for (k,leg),c in comp_by.items() if c['exit_code']==0}
    need(runtime_keys=={(k,leg,vm) for k,leg in successes for vm in RUNTIMES},'runtime coverage differs from exactly two VMs per successful compile')
    for row in wrong:
        key=tuple(row['cell_key']); leg=row['compiler']; wk=(key,leg); need(wk not in wrong_keys,'duplicate wrong-root row'); wrong_keys.add(wk)
        comp=comp_by[wk]; cmd=commands[row['command']]; err=compare.command_artifact(cmd,'stderr'); target=str(Path(comp['class_root']).resolve()); empty=row['expected_wrong_root']
        need(comp['exit_code']==0 and cmd['exit_code']!=0 and b'wrong CodeSource:' in err and row['rejected'] is True,'wrong-root did not prove actual CodeSource refusal')
        need(row['stdout']==cmd['streams']['stdout'] and row['stderr']==cmd['streams']['stderr'],'wrong-root raw pins differ from command streams')
        need(cmd['label']==f"wrong-root-{'-'.join(map(str,key))}-{leg}" and cmd['tool_leg']=='javac23' and cmd['argv'][-2:]==[target,empty] and row['actual_target_root']==target,'wrong-root command/location binding differs')
        need(cmd['argv'][cmd['argv'].index('-cp')+1]==str(driver_root.resolve()) and cmd['argv'][-3]=='TestNestedLoops2Driver','wrong-root driver cp not isolated')
    need(wrong_keys==successes,'wrong-root rows do not cover every successful compile exactly once')
    expected_mm={(('no-debug','bundle'),'javac23','javac8'),(('no-debug','bundle'),'javac23','javac23')}
    got_mm={(tuple(x['cell']),x['compiler'],x['runtime']) for x in mismatches}
    need(got_mm==expected_mm,'raw runtime mismatch set differs from the known no-debug JADX inline-get event regression')
    need(jarde_runs==32,'expected 32 passing Jarde JVM runs')
    used={d['driver_compile']['command']}|{x['command'] for x in comps}|{x['command'] for x in runtime}|{x['command'] for x in wrong}
    need(used==set(commands),'matrix has unclassified or reused command IDs')
    return {'source_cells':len(cells),'compile_attempts':len(comps),'compile_successes':len(successes),'compile_failures':len(expected_fail),'runtime_runs':len(runtime),'jarde_runtime_runs':jarde_runs,'jadx_runtime_runs':jadx_runs,'wrong_root_runs':len(wrong),'known_jadx_event_mismatches':mismatches,'jarde_all_match':True,'matrix_all_semantics_match':not mismatches}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--baseline',type=Path,required=True); ap.add_argument('--baseline-sha256',required=True)
    ap.add_argument('--matrix',type=Path,required=True); ap.add_argument('--matrix-sha256',required=True)
    ap.add_argument('--out',type=Path,required=True); ap.add_argument('--root',type=Path,default=ROOT)
    args=ap.parse_args(); root=args.root.resolve(strict=True); out=args.out.resolve()
    need(root==ROOT.resolve(),'workspace root differs from pinned checkout'); need(not out.exists(),f'refusing existing review output {out}')
    need(not (root/'target').exists() and not (root/'target').is_symlink(),'workspace target exists at review time')
    bp=args.baseline.resolve(strict=True); mp=args.matrix.resolve(strict=True)
    for p,h,label in ((COMPARE,COMPARE_SHA,'compare helper'),(PARSER,PARSER_SHA,'physical parser'),(GUARD,GUARD_SHA,'guard'),(SCANNER,SCANNER_SHA,'target scanner'),(JDK,JDK_SHA,'JDK manifest')):
        need(sha(p.read_bytes())==h,f'{label} pin changed: {p}')
    compare=load(COMPARE,'nestedloops2_review_compare'); parser=load(PARSER,'nestedloops2_review_physical')
    need(compare.pin(COMPARE)['sha256']==COMPARE_SHA and compare.pin(PARSER)['sha256']==PARSER_SHA,'helper pin mismatch')
    base=check_baseline(bp,args.baseline_sha256,compare,parser)
    msha=args.matrix_sha256; need(sha(mp.read_bytes())==msha,'matrix SHA differs from argument')
    manifest=json.loads(JDK.read_text(encoding='utf-8')); jdks,jdk_record=compare.configured_jdks(JDK,JDK_SHA)
    need(jdk_record['sha256']==JDK_SHA and base['doc']['jdk_manifest']==jdk_record,'configured JDK manifest differs from baseline receipt')
    matrix=check_matrix(mp,msha,base,compare,parser,jdks,jdk_record)
    if (root/'target').exists() or (root/'target').is_symlink(): raise ValueError('workspace target exists at review time')
    out.mkdir(parents=True)
    review={'schema':'cf11-testnestedloops2-independent-acceptance-review-v1','status':'review_complete',
      'baseline':{'path':str(bp),'sha256':args.baseline_sha256,'commands':20,'raw_streams':40,'original_runtime_cells':4,'cases_per_cell':10,'jarde_api_cells':8,'raw_map_bcIs_checked':True,'original_signature_and_get_cast_verified_from_classfile':True,'jadx_full_bundle_profiles':2,'javac8_full_source_major55_boundary':'observed in raw diagnostic'},
      'matrix':{'path':str(mp),'sha256':msha,**matrix},
      'caveat':'The original/generated evidence was re-opened and structurally checked. The complete matrix contains the preserved no-debug JADX javac23 event-order mismatch; it is not all-green. Jarde cells are checked separately against matching original profile/runtime oracles.',
      'checker':{'path':str(Path(__file__).resolve()),'sha256':sha(Path(__file__).read_bytes())}}
    (out/'review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':review['status'],'jarde_all_match':matrix['jarde_all_match'],'matrix_all_semantics_match':matrix['matrix_all_semantics_match'],'compile_successes':matrix['compile_successes'],'known_jadx_event_mismatches':len(matrix['known_jadx_event_mismatches'])}))
if __name__=='__main__': main()
