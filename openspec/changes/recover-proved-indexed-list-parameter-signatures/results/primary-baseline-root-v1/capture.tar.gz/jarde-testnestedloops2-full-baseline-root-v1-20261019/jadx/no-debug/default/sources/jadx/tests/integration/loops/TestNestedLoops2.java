package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import java.util.List;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestNestedLoops2.class */
public class TestNestedLoops2 extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/TestNestedLoops2$TestCls.class */
    public static class TestCls {
        public boolean test(List<String> list) {
            int i = 0;
            for (int i2 = 0; i2 < list.size(); i2++) {
                while (i < list.get(i2).length()) {
                    i++;
                }
            }
            return i > 10;
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().containsOne("for (int i = 0; i < list.size(); i++) {").containsOne("while (j < s.length()) {");
    }
}
