#!/usr/bin/env python3
"""Capture full-source TestNestedLoops2 original/JADX/Jarde observations; preparation only."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, shutil, sys, zipfile
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
SOURCE = Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestNestedLoops2.java')
SOURCE_SHA256 = '795ea73a0acfc5695f9e67c456746919f889d52026695f406d88f9693469b6db'
CLI = Path('/private/tmp/jarde-object-argument-broad-root-v2-20261018/candidate-cli')
CLI_SHA256 = '56a589ef9a170a1bb2911ed5597c20b2b4e06abf78da845f8fd3946099b2fa51'
DEPENDENCY_REFERENCE = Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018/execution.json')
DEPENDENCY_REFERENCE_SHA256 = '5a7d6572e600d19dc45d78030d0b12867bc742c4b014381fb5c7b059db171d35'
RUNTIME_BOUND = Path('/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
RUNTIME_BOUND_SHA256 = '73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA256 = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA256 = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
COMPARE_REL = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA256 = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
PARSER = Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA256 = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
DRIVER_SHA256 = '8c6cac9925421ef55358a3ab6fbe578ad1ad28c5364667befe279ae25c69afdd'
CONTROL_SOURCE_SHA256 = 'b39f610887e560eb8c7631727e9ea2cf2510518e182f608f9b1caab9a54a42b1'
INTERNAL = 'jadx/tests/integration/loops/TestNestedLoops2$TestCls'
OUTER_INTERNAL = 'jadx/tests/integration/loops/TestNestedLoops2'
TARGET_DOT = 'jadx.tests.integration.loops.TestNestedLoops2$TestCls'
RUNTIMES = ('javac8', 'javac23')
PROFILES = ('debug', 'no-debug')
EVIDENCE = ('default', 'all')
CASE_NAMES = ('empty', 'short', 'long', 'short-after-long', 'null-list', 'null-element',
              'heap-pollution', 'get-throws', 'size-throws', 'abstract-list-order')


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def same_content(compare, first: Path, second: Path) -> bool:
    left, right = compare.pin(first), compare.pin(second)
    return left.get('bytes') == right.get('bytes') and left.get('sha256') == right.get('sha256')


def full_class_facts(compare, physical, path: Path, role: str) -> dict:
    facts = compare.parse_class(path)
    actual = physical.parse_class_file(path.read_bytes())
    if actual['class_name'] != facts['class_name'] or actual['major'] != facts['major'] \
            or actual['methods'] != facts['methods']:
        raise RuntimeError(f'{role}: independent physical method/Code census differs')
    if sorted((x['name'], x['descriptor'], x['access']) for x in actual['fields']) != sorted(facts['fields']):
        raise RuntimeError(f'{role}: independent physical field census differs')
    facts['access'] = actual['access']
    if len({(m['name'], m['descriptor']) for m in facts['methods']}) != len(facts['methods']):
        raise RuntimeError(f'{role}: duplicate method identity')
    for method in facts['methods']:
        code = method.get('code')
        if code is None or not code.get('bcis') or code['bcis'][0] != 0 \
                or code['bcis'][-1] >= code['code_length']:
            raise RuntimeError(f'{role} {method["name"]}{method["descriptor"]}: invalid physical Code/BCIs')
    return facts


def class_tree(root: Path) -> dict:
    return {p.relative_to(root).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p)}
            for p in sorted(root.rglob('*.class'))}


def parse_oracle(stdout: bytes) -> list[dict]:
    import re
    lines = stdout.decode('utf-8', errors='strict').splitlines()
    if len(lines) != len(CASE_NAMES): raise ValueError(f'expected {len(CASE_NAMES)} rows, got {len(lines)}')
    rows = []
    pattern = re.compile(r'^CASE index=(\d+) name=([^ ]+) result=([^ ]+) exception=([^ ]+) events=(.*)$')
    for index, line in enumerate(lines):
        match = pattern.fullmatch(line)
        if match is None: raise ValueError(f'malformed oracle row: {line!r}')
        got_index, name, result, exception_type, events = match.groups()
        if int(got_index) != index or name != CASE_NAMES[index]:
            raise ValueError(f'case identity/order mismatch: {line!r}')
        rows.append({'index': index, 'name': name, 'result': result,
                     'exception_type': exception_type, 'events': events, 'raw': line})
    return rows


def oracle_projection(rows: list[dict]) -> list[dict]:
    return [{key: row[key] for key in ('index', 'name', 'result', 'exception_type', 'events')}
            for row in rows]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    root, out = args.root.resolve(strict=True), args.out.resolve()
    if root != ROOT.resolve(): raise SystemExit(f'workspace differs from pinned root: {root}')
    if out.exists(): raise SystemExit(f'refusing existing output: {out}')
    if (root / 'target').exists() or (root / 'target').is_symlink(): raise SystemExit('target must be absent')
    for path, expected, label in (
        (SOURCE, SOURCE_SHA256, 'complete upstream source'),
        (CLI, CLI_SHA256, 'current candidate CLI'),
        (DEPENDENCY_REFERENCE, DEPENDENCY_REFERENCE_SHA256, 'accepted harness dependency reference'),
        (RUNTIME_BOUND, RUNTIME_BOUND_SHA256, 'runtime guard'),
        (JADX, JADX_SHA256, 'JADX launcher'),
        (JADX_JAR, JADX_JAR_SHA256, 'JADX jar'),
        (PARSER, PARSER_SHA256, 'physical class parser'),
    ):
        if sha(path) != expected: raise SystemExit(f'{label} pin mismatch: {path}')

    compare_path = root / COMPARE_REL
    guard_path, scanner_path = root / GUARD_REL, root / SCANNER_REL
    manifest_path = root / JDK_MANIFEST_REL
    for path, expected, label in ((compare_path, COMPARE_SHA256, 'compare'),
                                  (guard_path, GUARD_SHA256, 'guard'),
                                  (scanner_path, SCANNER_SHA256, 'scanner'),
                                  (manifest_path, JDK_MANIFEST_SHA256, 'JDK manifest')):
        if sha(path) != expected: raise SystemExit(f'{label} source pin mismatch: {path}')
    compare = load(compare_path, 'nestedloops_compare')
    guard = load(guard_path, 'nestedloops_guard')
    scanner = load(scanner_path, 'nestedloops_scanner')
    physical = load(PARSER, 'nestedloops_physical_class_parser')
    jdks, jdk_record = compare.configured_jdks(manifest_path, JDK_MANIFEST_SHA256)
    dependency = json.loads(DEPENDENCY_REFERENCE.read_text(encoding='utf-8'))
    if dependency.get('schema') != 'cf11-original-nestedloops3-baseline-v1':
        raise SystemExit('dependency reference schema mismatch')
    if not dependency.get('classpath') or not dependency.get('harness_jar'):
        raise SystemExit('dependency reference lacks accepted test harness classpath')
    dep_dirs = dependency.get('directory_pins', dependency.get('directory_pins_before'))
    if not dep_dirs: raise SystemExit('dependency reference lacks class-directory pins')
    dep_rows = [dependency['harness_jar'], *dependency.get('jar_pins', [])]
    for row in dep_rows:
        if compare.pin(Path(row['path'])) != row: raise SystemExit(f'dependency artifact changed: {row["path"]}')
    def tree_pins(base: Path):
        return {p.relative_to(base).as_posix(): compare.pin(p) for p in sorted(base.rglob('*.class'))}
    for folder, expected in dep_dirs.items():
        if tree_pins(Path(folder)) != expected: raise SystemExit(f'dependency class directory changed: {folder}')
    class_names = {INTERNAL + '.class', OUTER_INTERNAL + '.class'}
    for row in dep_rows:
        if row['path'].endswith('.jar'):
            with zipfile.ZipFile(row['path']) as archive:
                if class_names.intersection(archive.namelist()): raise SystemExit('target leaked into dependency jar')
    for folder in dep_dirs:
        if any((Path(folder) / name).is_file() for name in class_names):
            raise SystemExit(f'target leaked into dependency directory: {folder}')

    driver_source = Path(__file__).parent / 'driver' / 'TestNestedLoops2Driver.java'
    control_source = Path(__file__).parent / 'controls/src/jadx/tests/integration/loops/NestedLoops2GenericControls.java'
    if sha(driver_source) != DRIVER_SHA256: raise SystemExit('standalone driver source pin mismatch')
    if sha(control_source) != CONTROL_SOURCE_SHA256: raise SystemExit('generic-control Java pin mismatch')
    out.mkdir(parents=True)
    raw_dir = out / 'raw'; raw_dir.mkdir()
    guard.ROOT = root; guard.OUT = raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, stdout_bytes: None
    if shutil.disk_usage(root).free < 5 * 1024**3: raise SystemExit('5 GiB free-space guard failed')

    source_copy = out / 'source/jadx/tests/integration/loops/TestNestedLoops2.java'
    source_copy.parent.mkdir(parents=True)
    shutil.copy2(SOURCE, source_copy)
    if not same_content(compare, source_copy, SOURCE): raise RuntimeError('upstream source copy differs')
    driver_copy = out / 'driver-source/TestNestedLoops2Driver.java'
    driver_copy.parent.mkdir(parents=True)
    shutil.copy2(driver_source, driver_copy)
    if not same_content(compare, driver_copy, driver_source): raise RuntimeError('driver source copy differs')
    runtime_copy = out / RUNTIME_BOUND.name; shutil.copy2(RUNTIME_BOUND, runtime_copy)
    if not same_content(compare, runtime_copy, RUNTIME_BOUND): raise RuntimeError('runtime wrapper copy differs')
    empty = out / 'empty-classpath'; empty.mkdir()
    driver_classes = out / 'driver-classes'; driver_classes.mkdir()
    classpath_text = os.pathsep.join(dependency['classpath'])
    source_before = compare.source_closure(root)
    tool_paths = [SOURCE, CLI, DEPENDENCY_REFERENCE, RUNTIME_BOUND, driver_source, control_source, JADX, JADX_JAR,
                  root / JDK_MANIFEST_REL, compare_path, guard_path, scanner_path, PARSER]
    def external_snapshot():
        return {
            'files': [compare.pin(p) for p in tool_paths],
            'dependency_artifacts': [compare.pin(Path(row['path'])) for row in dep_rows],
            'dependency_directories': {str(Path(folder).resolve()): tree_pins(Path(folder)) for folder in dep_dirs},
            'jdk_tools': {f'{leg}_{name}': compare.pin(path) for leg, spec in jdks.items()
                          for name, path in spec['tools'].items()},
        }
    external_before = external_snapshot()
    local_copies_before = {'source_copy': compare.pin(source_copy), 'driver_copy': compare.pin(driver_copy),
                           'runtime_copy': compare.pin(runtime_copy)}
    report = {
        'schema': 'cf11-testnestedloops2-current-full-source-baseline-v1', 'status': 'running',
        'root': str(root), 'output': str(out), 'source': compare.pin(SOURCE),
        'source_copy': compare.pin(source_copy), 'control_source': compare.pin(control_source),
        'cli': compare.pin(CLI), 'dependency_reference': compare.pin(DEPENDENCY_REFERENCE),
        'dependency_classpath': dependency['classpath'], 'dependency_harness_jar': dependency['harness_jar'],
        'dependency_jar_pins': dependency.get('jar_pins', []), 'dependency_directory_pins': dep_dirs,
        'driver_source': compare.pin(driver_source), 'driver_copy': compare.pin(driver_copy),
        'runtime_wrapper': compare.pin(runtime_copy), 'jadx': compare.pin(JADX), 'jadx_jar': compare.pin(JADX_JAR),
        'jdk_manifest': jdk_record, 'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path),
        'scanner': compare.pin(scanner_path), 'physical_parser': compare.pin(PARSER),
        'external_input_pins_before': external_before, 'source_pins_before': source_before,
        'local_copy_pins_before': local_copies_before,
        'commands': [], 'source_profiles': [], 'javac8_full_source_boundary': None,
        'driver_classes': [], 'original_runtime': [],
        'runtime_semantic_agreement': None, 'wrong_root_control': None,
        'jarde_cells': [], 'jadx_outputs': [],
        'notes': [
            'The exact full upstream TestNestedLoops2.java is compiled and preserved; the outer JUnit method is never stripped.',
            'The independent List observer derives its ten runtime rows from the newly compiled original class; no expected return, exception, or event sequence is hardcoded.',
            'Java 8 full-source compilation is recorded as a real harness-major boundary observation, not replaced by a trimmed source compile.',
            'Runtime classpath contains only the standalone reflection driver; each target class is loaded by a fresh parentless loader and checked against an independent expected CodeSource path.',
            'No recovery result is assumed. API source/quality/regions and complete physical method/BCI inventories are captured for root to inspect.',
        ],
    }
    compare.write_json(out / 'execution.json', report)
    rows = report['commands']
    def command(argv, label, leg='javac23'):
        if (root / 'target').exists() or (root / 'target').is_symlink():
            raise RuntimeError('workspace target appeared during baseline capture')
        env = compare.clean_env(dict(os.environ), jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(rows) + 1, [str(x) for x in argv], env)
        row['label'] = label; row['tool_leg'] = leg; rows.append(row)
        compare.write_json(out / 'execution.json', report)
        if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        return row
    def artifact(row, channel='stdout'):
        return compare.command_artifact(row, channel)
    def pin_class_tree(path: Path):
        return {p.relative_to(path).as_posix(): compare.pin(p) for p in sorted(path.rglob('*.class'))}

    try:
        # Compile the complete upstream JUnit source, then derive observations with the independent reflection driver.
        boundary = out / 'javac8-boundary/classes'; boundary.mkdir(parents=True)
        boundary_row = command([jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
                                '-encoding', 'UTF-8', '-proc:none', '-classpath', classpath_text,
                                '-sourcepath', empty, '-d', boundary, source_copy],
                               'javac8-full-upstream-source-boundary', 'javac8')
        boundary_err = artifact(boundary_row, 'stderr')
        report['javac8_full_source_boundary'] = {
            'command': boundary_row['index'], 'exit_code': boundary_row['exit_code'],
            'class_tree': pin_class_tree(boundary),
            'major_55_diagnostic_observed': b'55.0' in boundary_err or b'version 55' in boundary_err,
            'stdout': compare.pin(Path(boundary_row['streams']['stdout']['path'])),
            'stderr': compare.pin(Path(boundary_row['streams']['stderr']['path'])),
        }
        for profile, debug in (('debug', '-g'), ('no-debug', '-g:none')):
            dest = out / profile / 'classes'; dest.mkdir(parents=True)
            row = command([jdks['javac23']['tools']['javac'], '--release', '8', debug,
                           '-encoding', 'UTF-8', '-proc:none', '-classpath', classpath_text,
                           '-sourcepath', empty, '-d', dest, source_copy], 'javac23-full-source-' + profile)
            profile_row = {'profile': profile, 'command': row['index'], 'exit_code': row['exit_code'],
                           'class_root': str(dest), 'class_tree': pin_class_tree(dest)}
            if row['exit_code'] == 0:
                tree = sorted(profile_row['class_tree'])
                expected = [INTERNAL + '.class', OUTER_INTERNAL + '.class']
                if tree != expected: raise RuntimeError(f'{profile}: full class tree differs: {tree}')
                child = full_class_facts(compare, physical, dest / (INTERNAL + '.class'), profile + ' child')
                outer = full_class_facts(compare, physical, dest / (OUTER_INTERNAL + '.class'), profile + ' outer')
                if child['class_name'] != INTERNAL or child['major'] != 52:
                    raise RuntimeError(f'{profile}: target identity/major mismatch')
                if {(m['name'], m['descriptor']) for m in child['methods']} != {
                    ('<init>', '()V'), ('test', '(Ljava/util/List;)Z')
                }:
                    raise RuntimeError(f'{profile}: target method inventory differs')
                if outer['class_name'] != OUTER_INTERNAL or outer['major'] != 52:
                    raise RuntimeError(f'{profile}: outer identity/major mismatch')
                profile_row['target_facts'] = child; profile_row['outer_facts'] = outer
                jar = out / f'{profile}-full-classes.jar'
                with zipfile.ZipFile(jar, 'w') as archive:
                    for file in sorted(dest.rglob('*.class')):
                        entry = zipfile.ZipInfo(file.relative_to(dest).as_posix(), (1980, 1, 1, 0, 0, 0))
                        entry.compress_type = zipfile.ZIP_STORED
                        archive.writestr(entry, file.read_bytes())
                profile_row['bundle'] = compare.pin(jar)
            report['source_profiles'].append(profile_row)
            compare.write_json(out / 'execution.json', report)

        driver_row = command([jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
                              '-encoding', 'UTF-8', '-proc:none', '-classpath', empty,
                              '-sourcepath', empty, '-d', driver_classes, driver_copy],
                             'compile-independent-reflection-driver', 'javac8')
        report['driver_compile'] = {'command': driver_row['index'], 'exit_code': driver_row['exit_code'],
                                    'stdout': compare.pin(Path(driver_row['streams']['stdout']['path'])),
                                    'stderr': compare.pin(Path(driver_row['streams']['stderr']['path']))}
        if driver_row['exit_code'] != 0: raise RuntimeError('reflection driver compile failed')
        driver_files = sorted(driver_classes.rglob('*.class'))
        driver_tree = [file.relative_to(driver_classes).as_posix() for file in driver_files]
        expected_driver_tree = ['TestNestedLoops2Driver$Case.class',
                                'TestNestedLoops2Driver$Observation.class',
                                'TestNestedLoops2Driver$RecordingList.class',
                                'TestNestedLoops2Driver.class']
        if driver_tree != expected_driver_tree:
            raise RuntimeError(f'driver class tree differs: {driver_tree}')
        report['driver_classes'] = [compare.pin(file) for file in driver_files]
        # Driver classfiles may contain modified-UTF8 constants. Keep byte pins and the existing
        # narrow class/Code summary; do not pass these helper classes through the strict parser.
        report['driver_class_summaries'] = [compare.parse_class(file) for file in driver_files]

        semantic_rows = []
        for profile in report['source_profiles']:
            if profile['exit_code'] != 0: continue
            target_root = Path(profile['class_root']).resolve()
            for runtime in RUNTIMES:
                run = command([sys.executable, '-B', runtime_copy, '30', jdks[runtime]['tools']['java'],
                               '-Xverify:all', '-cp', driver_classes, 'TestNestedLoops2Driver',
                               target_root, target_root],
                              f'original-runtime-{profile["profile"]}-{runtime}', runtime)
                stdout, stderr = artifact(run), artifact(run, 'stderr')
                cell = {'profile': profile['profile'], 'runtime': runtime, 'command': run['index'],
                        'exit_code': run['exit_code'], 'target_root': str(target_root),
                        'application_classpath': [str(driver_classes)],
                        'stdout': compare.pin(Path(run['streams']['stdout']['path'])),
                        'stderr': compare.pin(Path(run['streams']['stderr']['path']))}
                if run['exit_code'] == 0:
                    try:
                        rows8 = parse_oracle(stdout)
                    except (ValueError, UnicodeDecodeError) as error:
                        raise RuntimeError(f'{profile["profile"]}/{runtime}: malformed original oracle: {error}')
                    cell['rows'] = rows8; cell['row_count'] = len(rows8)
                    semantic_rows.append(oracle_projection(rows8))
                report['original_runtime'].append(cell)
                compare.write_json(out / 'execution.json', report)
        report['runtime_semantic_agreement'] = len(semantic_rows) == 4 and all(x == semantic_rows[0] for x in semantic_rows)
        compare.write_json(out / 'execution.json', report)

        # A deliberately wrong expected CodeSource root proves that the driver checks the loaded origin.
        first_ok = next((x for x in report['source_profiles'] if x['exit_code'] == 0), None)
        if first_ok is not None:
            wrong = command([sys.executable, '-B', runtime_copy, '30', jdks['javac23']['tools']['java'],
                             '-Xverify:all', '-cp', driver_classes, 'TestNestedLoops2Driver',
                             Path(first_ok['class_root']).resolve(), empty],
                            'driver-code-source-wrong-root-control', 'javac23')
            wrong_err = artifact(wrong, 'stderr'); wrong_out = artifact(wrong, 'stdout')
            report['wrong_root_control'] = {
                'command': wrong['index'], 'exit_code': wrong['exit_code'],
                'rejected': wrong['exit_code'] != 0 and b'wrong CodeSource:' in wrong_err,
                'actual_target_root': first_ok['class_root'], 'expected_wrong_root': str(empty),
                'stdout': compare.pin(Path(wrong['streams']['stdout']['path'])),
                'stderr': compare.pin(Path(wrong['streams']['stderr']['path'])),
            }
            if not report['wrong_root_control']['rejected']:
                raise RuntimeError('wrong CodeSource negative control did not reject')

        version = command([JADX, '--version'], 'jadx-version')
        version_text = artifact(version) + artifact(version, 'stderr')
        if version['exit_code'] != 0 or b'1.5.6' not in version_text:
            raise RuntimeError('JADX version mismatch')
        for profile in report['source_profiles']:
            if profile['exit_code'] != 0: continue
            dest_class = Path(profile['class_root'])
            input_jar = Path(profile['bundle']['path'])
            target_file = dest_class / (INTERNAL + '.class')
            for form, input_path, policy in (('child', target_file, 'single-class'),
                                               ('bundle-child', input_jar, 'plain-jar')):
                for evidence in EVIDENCE:
                    argv = [CLI, 'class-source', '--input', input_path, '--class', INTERNAL,
                            '--policy', policy, '--release', '8', '--format', 'json']
                    if evidence == 'all': argv += ['--evidence', 'all']
                    row = command(argv, f'jarde-{profile["profile"]}-{form}-{evidence}')
                    raw = artifact(row)
                    dest = out / 'jarde' / profile['profile'] / form / evidence; dest.mkdir(parents=True)
                    report_path = dest / 'report.json'; report_path.write_bytes(raw)
                    cell = {'profile': profile['profile'], 'input_form': form, 'evidence': evidence,
                            'command': row['index'], 'exit_code': row['exit_code'],
                            'input': compare.pin(input_path), 'report': compare.pin(report_path)}
                    try:
                        api = json.loads(raw.decode('utf-8', errors='strict'))
                        whole = dest / 'whole-source.java'; whole.write_bytes(api.get('text', '').encode('utf-8'))
                        summaries = []
                        for method in api.get('methods', []):
                            item = method.get('item', {})
                            name = item.get('name', {}).get('escaped')
                            descriptor = item.get('descriptor', {}).get('escaped')
                            identity = item.get('identity', {})
                            identity_owner = identity.get('owner', {})
                            outcome = method.get('outcome', {}); body = outcome.get('report', {})
                            summaries.append({'name': name, 'descriptor': descriptor,
                                              'owner': identity_owner,
                                              'location': identity_owner.get('location'),
                                              'variant': identity_owner.get('variant'), 'outcome_kind': outcome.get('kind'),
                                              'quality': body.get('quality'), 'fallbacks': body.get('fallbacks'),
                                              'regions': body.get('regions'), 'source_map': body.get('source_map')})
                        cell.update({'whole_source': compare.pin(whole), 'methods': summaries,
                                     'physical_method_inventory': [(m['name'], m['descriptor']) for m in summaries]})
                    except (ValueError, TypeError, UnicodeDecodeError) as error:
                        cell['json_parse_error'] = str(error)
                    report['jarde_cells'].append(cell)
                    compare.write_json(out / 'execution.json', report)


        # Decode the complete outer+child bundle once per full-source compiler profile.
        for profile in report['source_profiles']:
            if profile['exit_code'] != 0: continue
            bundle = Path(profile['bundle']['path'])
            dest = out / 'jadx' / profile['profile'] / 'default'
            jadx_row = command([JADX, '--threads-count', '1', '--no-res', '--config', 'none',
                                '-d', dest, bundle],
                               'jadx-full-bundle-' + profile['profile'] + '-default')
            sources = [compare.pin(file) for file in sorted(dest.rglob('*.java'))] if dest.exists() else []
            report['jadx_outputs'].append({'compiler_profile': profile['profile'], 'display_profile': 'default',
                                           'input': compare.pin(bundle), 'command': jadx_row['index'],
                                           'exit_code': jadx_row['exit_code'], 'sources': sources})
            compare.write_json(out / 'execution.json', report)

        report['source_pins_after'] = compare.source_closure(root)
        report['source_unchanged'] = report['source_pins_after'] == source_before
        report['local_copy_pins_after'] = {'source_copy': compare.pin(source_copy),
                                           'driver_copy': compare.pin(driver_copy),
                                           'runtime_copy': compare.pin(runtime_copy)}
        report['local_copies_unchanged'] = all(
            report['local_copy_pins_after'][key].get('bytes') == local_copies_before[key].get('bytes')
            and report['local_copy_pins_after'][key].get('sha256') == local_copies_before[key].get('sha256')
            for key in local_copies_before)
        report['external_input_pins_after'] = external_snapshot()
        report['external_inputs_unchanged'] = report['external_input_pins_after'] == external_before
        report['target_absent'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
        if (not report['source_unchanged'] or not report['external_inputs_unchanged']
                or not report['local_copies_unchanged'] or not report['target_absent']):
            raise RuntimeError('source/tool inputs changed or target exists')
        report['counts_derived_from_commands'] = {
            'commands': len(rows), 'raw_streams': 2 * len(rows),
            'javac8_boundary': sum(r['label'] == 'javac8-full-upstream-source-boundary' for r in rows),
            'javac23_full_source_compiles': sum(r['label'].startswith('javac23-full-source-') for r in rows),
            'driver_compiles': sum(r['label'] == 'compile-independent-reflection-driver' for r in rows),
            'original_runtime_runs': sum(r['label'].startswith('original-runtime-') for r in rows),
            'wrong_root_runs': sum(r['label'] == 'driver-code-source-wrong-root-control' for r in rows),
            'jarde_calls': sum(r['label'].startswith('jarde-') for r in rows),
            'jadx_calls': sum(r['label'].startswith('jadx-') for r in rows),
        }
        report['status'] = 'captured-pending-independent-review'
    except BaseException as error:
        report['status'] = 'failed'; report['error'] = str(error)
        raise
    finally:
        try:
            report['external_input_pins_after_finally'] = external_snapshot()
            report['local_copy_pins_after_finally'] = {'source_copy': compare.pin(source_copy),
                                                       'driver_copy': compare.pin(driver_copy),
                                                       'runtime_copy': compare.pin(runtime_copy)}
            report['local_copies_unchanged_finally'] = all(
                report['local_copy_pins_after_finally'][key].get('bytes') == local_copies_before[key].get('bytes')
                and report['local_copy_pins_after_finally'][key].get('sha256') == local_copies_before[key].get('sha256')
                for key in local_copies_before)
            report['source_pins_after_finally'] = compare.source_closure(root)
            report['source_unchanged_finally'] = report['source_pins_after_finally'] == source_before
            report['target_absent_finally'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
            if (report['external_input_pins_after_finally'] != external_before
                    or not report['local_copies_unchanged_finally']
                    or not report['source_unchanged_finally'] or not report['target_absent_finally']):
                report['status'] = 'failed'; report['final_guard_error'] = 'source/tool pins changed or target exists'
        except BaseException as error:
            report['status'] = 'failed'; report['final_guard_error'] = repr(error)
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out / 'execution.json', report)
        shutil.copy2(__file__, out / 'collector.py')
        print(json.dumps({'status': report['status'], 'commands': len(rows),
                          'runtime_runs': len(report['original_runtime']), 'error': report.get('error')}))

if __name__ == '__main__':
    raise SystemExit(main())
