import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Isolated, deterministic runtime observer for TestNestedLoops2$TestCls.test(List). */
public final class TestNestedLoops2Driver {
    private static final String TARGET = "jadx.tests.integration.loops.TestNestedLoops2$TestCls";
    private static final int EVENT_LIMIT = 128;

    private static final class Case {
        final String name;
        final Object[] values;
        final boolean nullList;
        final boolean throwSize;
        final int throwGetAt;
        Case(String name, Object[] values, boolean nullList, boolean throwSize, int throwGetAt) {
            this.name=name; this.values=values; this.nullList=nullList;
            this.throwSize=throwSize; this.throwGetAt=throwGetAt;
        }
    }

    private static final class RecordingList extends AbstractList<Object> {
        final List<Object> values = new ArrayList<Object>();
        final List<String> events = new ArrayList<String>();
        boolean eventLimitExceeded;
        final boolean throwSize;
        final int throwGetAt;
        RecordingList(Case c) {
            values.addAll(Arrays.asList(c.values));
            throwSize=c.throwSize; throwGetAt=c.throwGetAt;
        }
        private void event(String value) {
            if (events.size() >= EVENT_LIMIT) {
                eventLimitExceeded = true;
                throw new AssertionError("list event limit");
            }
            events.add(value);
        }
        @Override public int size() {
            event("size");
            if (throwSize) throw new IllegalStateException("size probe");
            return values.size();
        }
        @Override public Object get(int index) {
            event("get(" + index + ")");
            if (index == throwGetAt) throw new IllegalStateException("get probe");
            return values.get(index);
        }
        String eventsText() { return String.join(",", events); }
    }

    private static final class Observation {
        final Object result;
        final Throwable failure;
        Observation(Object result, Throwable failure) { this.result=result; this.failure=failure; }
    }

    private static final Case[] CASES = {
        new Case("empty", new Object[] {}, false, false, -1),
        new Case("short", new Object[] {"a", "bc"}, false, false, -1),
        new Case("long", new Object[] {"abcdefghijkl"}, false, false, -1),
        new Case("short-after-long", new Object[] {"a", "bc"}, false, false, -1),
        new Case("null-list", new Object[] {}, true, false, -1),
        new Case("null-element", new Object[] {null}, false, false, -1),
        new Case("heap-pollution", new Object[] {Integer.valueOf(7)}, false, false, -1),
        new Case("get-throws", new Object[] {"a"}, false, false, 0),
        new Case("size-throws", new Object[] {"a"}, false, true, -1),
        new Case("abstract-list-order", new Object[] {"ab", "c"}, false, false, -1),
    };

    private static String codeSource(Class<?> target) throws Exception {
        CodeSource source=target.getProtectionDomain().getCodeSource();
        if (source==null || source.getLocation()==null) throw new IllegalStateException("target has no CodeSource");
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }

    private static Observation invoke(Method method, Object instance, List<?> input) throws Exception {
        try { return new Observation(method.invoke(instance, input), null); }
        catch (InvocationTargetException e) { return new Observation(null, e.getCause()); }
    }

    public static void main(String[] args) throws Exception {
        if (args.length!=2) throw new IllegalArgumentException("usage: TestNestedLoops2Driver actualRoot expectedRoot");
        String actual=Paths.get(args[0]).toRealPath().toString();
        String expected=Paths.get(args[1]).toRealPath().toString();
        URL url=Paths.get(actual).toRealPath().toUri().toURL();
        try (URLClassLoader loader=new URLClassLoader(new URL[] {url}, null)) {
            Class<?> target=Class.forName(TARGET, true, loader);
            if (target.getClassLoader()!=loader) throw new IllegalStateException("target did not load from parentless loader");
            String actualCodeSource=codeSource(target);
            if (!actualCodeSource.equals(expected)) throw new IllegalStateException("wrong CodeSource: expected="+expected+" actual="+actualCodeSource);
            Constructor<?> constructor=target.getDeclaredConstructor();
            Object instance=constructor.newInstance();
            Method method=target.getDeclaredMethod("test", List.class);
            for (int i=0;i<CASES.length;i++) {
                Case c=CASES[i]; RecordingList list=new RecordingList(c);
                List<?> input=c.nullList ? null : list;
                Observation o=invoke(method, instance, input);
                if (list.eventLimitExceeded) throw new AssertionError("observer event limit exceeded");
                String exception=o.failure==null ? "none" : o.failure.getClass().getName();
                String result=o.failure==null ? String.valueOf(o.result) : "<none>";
                System.out.println("CASE index="+i+" name="+c.name+" result="+result+" exception="+exception+" events="+list.eventsText());
            }
        }
    }
}
