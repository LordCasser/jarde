# TestNestedLoops2 full-source baseline and rebuild preparation

Private preparation only (v2). No javac/java/JADX/Jarde CLI/Cargo/Git/network command was executed. Root must review and run the collectors serially after the shared tree and CLI are fixed.

Primary source is the full upstream `TestNestedLoops2.java` (693 bytes, SHA-256 `795ea73a0acfc5695f9e67c456746919f889d52026695f406d88f9693469b6db`). `collect_baseline.py` validates all local source pins before creating its output directory, then compiles that exact outer-plus-child source as a real javac 8 boundary attempt and preserves any major-55 harness failure; it also builds debug/no-debug full sources with JDK 23 `--release 8`. It compiles an independent Java 8 reflection driver and observes ten rows from `TestNestedLoops2$TestCls.test(List)`: empty, short, long, short-after-long on the same target instance, null list, null element, heap pollution, throwing `get`, throwing `size`, and AbstractList size/get event ordering. Actual return values, events, and thrown exception names are derived at runtime; no expected behavior is hardcoded into the collector. Each target load uses a parentless class loader and an explicit expected CodeSource root; the wrong-root negative call must reject.

The baseline collector makes the exact eight Jarde class-source requests over the original JDK 23 target output: debug/no-debug × child/bundle-child × default/all, using the fixed old CLI SHA-256 `56a589ef9a170a1bb2911ed5597c20b2b4e06abf78da845f8fd3946099b2fa51`. It records complete raw reports, source text, method inventories, quality/fallback/region/source-map summaries, and complete outer+child JADX full-bundle source output for both compiler profiles. It does not assume a generic result or successful recovery.

`collect_generated_matrix.py` consumes that completed receipt and explicit receipt SHA. It copies each whole Jarde source text and every Java file from each complete JADX bundle without editing, then attempts javac 8 source/target 8 and JDK 23 `--release 8` compilation for 10 inputs × two compiler legs. Every compiler outcome is retained. Failed compiles get no runtime rows. Only successful complete class trees with Java 8 classfiles and the physical target method are run on each configured JVM; the same ten observed rows are compared with the matching original-profile/runtime oracle. A wrong-CodeSource root is checked per successful output. It does not turn compile/runtime failures or semantic mismatches into passes.

`controls/src/jadx/tests/integration/loops/NestedLoops2GenericControls.java` is a separately pinned, complete Java source probe set for void get/cast-to-String from `List<String>`, a fixed-bound boolean loop, int/long primitive results, legal List<String>-to-Integer wrong cast, parameter reassignment plus escaping alias, raw/wildcard lists, and reference result. It is intentionally not mixed into the primary outer/child source or its ten-row runtime oracle. The baseline records and rechecks its byte pin so root can decide whether a distinct control pass is warranted after seeing actual primary baseline results.

Both collectors reuse the accepted JDK manifest, source/dependency pinning, timeout/abort guard, default stack, 5 GiB free-space preflight, 1 GiB target cap, raw stdout/stderr, source closure checks, and final target absence. No source or output is truncated or repaired.

After review, run:

```sh
python3 -B collect_baseline.py --out /private/tmp/<fresh-baseline-output>
python3 -B collect_generated_matrix.py --baseline /private/tmp/<fresh-baseline-output>/execution.json --baseline-sha256 <sha256-of-that-receipt> --out /private/tmp/<fresh-generated-output>
```

These commands are guidance only; neither was executed in this preparation. The output is not a product acceptance result.

The Jarde API summary reads owner/location/variant from `item.identity.owner` (including its nested location and variant values); method names/descriptors come from the API item’s escaped fields. This bundle is frozen as preparation only and still requires independent review and execution.
