// jarde: presentation of `jadx/tests/integration/loops/TestNestedLoops2$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestNestedLoops2$TestCls extends java.lang.Object {
    public TestNestedLoops2$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestNestedLoops2$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public boolean test(java.util.List<java.lang.String> list) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)Z` projected after descriptor erasure and same-run AST/Code/SSA complete body proof; same-class call binding proved
        // @method test(Ljava/util/List;)Z
        // @declaration an instance method of `jadx.tests.integration.loops.TestNestedLoops2$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int j;
        int i;
        j = 0;
        java.lang.String s;
        for (i = 0; i < list.size(); i = i + 1) {
            s = (java.lang.String) list.get(i);
            while (j < s.length()) {
                j = j + 1;
            }
        }
        return j > 10;
    }
}
