# NestedLoops2 final CLI comparison preparation v3

This is a private, not-yet-executed preparation. It keeps both earlier bundles unchanged. No collector, CLI, Java compiler/runtime, Cargo, or network command has been run here.

The builder takes the final CLI path and SHA explicitly. Before creating a bundle it checks the CLI bytes, each frozen collector/checker/driver and receipt, and the exact recursive inventories of both Java source trees: the primary collector’s auxiliary `controls/src` input and the separate controls `src` input. It copies both trees into their corresponding collector workspaces and records every copied file hash. The controls checker is parameterized only for the selected CLI SHA and its four positive methods must retain exact `List<String>` Signature attributes and String checkcasts on the generated class plane. Negative/raw/wildcard methods keep their exact expected signatures.

The API delta reviewer compares eight existing selectors per family (debug/no-debug × child/bundle-child × default/all). It checks the primary `test(List)` and the four controls positives (`voidGetCastString`, `fixedBoundBoolean`, `primitiveInt`, `primitiveLong`) for the exact projected declaration and text change; all other methods must stay byte-for-byte equivalent after recursively removing `usage`. Raw outcomes/reports and source maps stay equal. Whole-class text is reconstructed from only those exact positive method replacements, and diagnostics must match. It also checks generated Jarde class Signature/checkcast facts for every successful generated compilation.

Collectors and reviewers still must be executed by root against the final CLI before any acceptance claim. The API delta reviewer expects the final report JSON to preserve the historical fields (`jarde_cells`, `methods`, `outcome.report`, `whole_source`) and the generated collectors’ existing compilation/class-tree schema. If the actual new receipt schema differs, treat that as a checker issue to resolve against the receipt; do not relax product expectations. This package does not assert an `essential` selector: the accepted source collectors provide exactly default/all.

After root reviews this package and has the final CLI artifact, prepare a separate fresh bundle:

```sh
python3 -B /private/tmp/jarde-testnestedloops2-final-cli-prep-luna-v3-20261019/prepare_final_cli_bundle.py \
  --cli <final-cli-path> --cli-sha256 <final-cli-sha256> \
  --out /private/tmp/jarde-testnestedloops2-final-cli-bundle-root-v1-20261019
```

Run its copied collectors serially using fresh output folders and bind each generated run to its newly captured baseline receipt. Use the copied primary verifier with the fresh primary baseline/matrix pair, then `controls/review_controls_final.py` with the copied final controls checker and fresh controls pair. Run `bind_final_to_original.py` to bind unchanged original source/class bytes and runtime observations. Finally run the new narrow API delta reviewer with the old accepted receipts, new final receipts, both generated matrices, and the exact final CLI pin:

```sh
python3 -B /private/tmp/jarde-testnestedloops2-final-cli-bundle-root-v1-20261019/verify_final_api_delta.py \
  --primary-old /private/tmp/jarde-testnestedloops2-full-baseline-root-v1-20261019/execution.json \
  --primary-new <fresh-primary-execution.json> \
  --controls-old /private/tmp/jarde-testnestedloops2-controls-baseline-root-v2-20261019/execution.json \
  --controls-new <fresh-controls-execution.json> \
  --primary-matrix <fresh-primary-generated-execution.json> \
  --controls-matrix <fresh-controls-generated-execution.json> \
  --cli <final-cli-path> --cli-sha256 <final-cli-sha256> \
  --out <new-api-delta-review.json>
```

The source-closure policy remains the one in the accepted baseline verifier: each new capture and its own generated matrix must have a stable matching before/after snapshot. Historical repository-source pins are not required to equal the current source.


## v4 correction

Static review of v3 found its copied controls-checker template still expected `List<?>` on the generated `wildcardList` class, despite the v3 API delta reviewer correctly expecting no generic Signature. v4 changes only that generated-plane template value to `None`; the original physical source plane continues to require `List<?>`. The embedded old/new function templates were parsed from the builder AST and checked directly, without running the builder or checker. See `V4_CORRECTION.md` and `v3-to-v4.diff`.
