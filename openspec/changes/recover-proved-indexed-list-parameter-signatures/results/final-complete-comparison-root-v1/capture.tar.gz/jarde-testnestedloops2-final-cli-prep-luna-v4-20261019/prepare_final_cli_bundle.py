#!/usr/bin/env python3
"""Prepare private copies of the frozen NestedLoops2 collectors for an explicitly pinned final CLI.

This only copies and rewrites two exact CLI path/hash literals. It never executes a collector or tool.
"""
from __future__ import annotations
import argparse, hashlib, json, shutil
from pathlib import Path

OLD_CLI='/private/tmp/jarde-object-argument-broad-root-v2-20261018/candidate-cli'
OLD_SHA='56a589ef9a170a1bb2911ed5597c20b2b4e06abf78da845f8fd3946099b2fa51'
SOURCES={
 'primary_collect':Path('/private/tmp/jarde-testnestedloops2-full-baseline-prep-luna-v2-20261019/collect_baseline.py'),
 'primary_matrix':Path('/private/tmp/jarde-testnestedloops2-full-baseline-prep-luna-v2-20261019/collect_generated_matrix.py'),
 'primary_verify':Path('/private/tmp/jarde-testnestedloops2-acceptance-prep-root-v1-20261019/verify_nestedloops2.py'),
 'controls_collect':Path('/private/tmp/jarde-testnestedloops2-controls-prep-luna-v3-20261019/collect_controls.py'),
 'controls_matrix':Path('/private/tmp/jarde-testnestedloops2-controls-prep-luna-v3-20261019/collect_controls_generated.py'),
 'controls_verify':Path('/private/tmp/jarde-testnestedloops2-controls-acceptance-prep-root-v3-20261019/review_controls.py'),
 'controls_final_checker':Path('/private/tmp/jarde-testnestedloops2-controls-acceptance-prep-root-v3-20261019/review_controls.py'),
 'controls_final_wrapper':Path('/private/tmp/jarde-testnestedloops2-final-cli-prep-luna-v1-20261019/review_controls_final.py'),
 'oracle_binder':Path('/private/tmp/jarde-testnestedloops2-final-cli-prep-luna-v1-20261019/bind_final_to_original.py'),
 'api_delta_reviewer':Path('/private/tmp/jarde-testnestedloops2-final-cli-prep-luna-v3-20261019/verify_final_api_delta.py'),
}
SOURCE_SHA={
 'primary_collect':'f972c43bed5cb4fd12d5e6b1db8804e0706a4387630a8ad935f2a2ff920af8bf',
 'primary_matrix':'6c693e1e129155004862b7e1279b024ce7c55b5b5ef7d1e99d9ac8afdb109b5c',
 'primary_verify':'8059435aacb8585f3bf4c7251dc9b6f127fc8bae23a12ae178a5572f4f55fd34',
 'controls_collect':'e255465cd7a761d63891a3f1dd7ee2cfe38156f79515d3d2928da79ca0de2f6c',
 'controls_matrix':'d7e93b4ab5a3b29ddc7b539156b2b63bc5eadf695ab308203edf73590c11b196',
 'controls_verify':'6d2a07963ee75d047b516bfddd93b099a8e64f5a042f39b879b0102d75ab14b4',
 'controls_final_checker':'6d2a07963ee75d047b516bfddd93b099a8e64f5a042f39b879b0102d75ab14b4',
 'controls_final_wrapper':'083448003c2940cfafac1a160a01aedeca4e14074b965a5ab8dc356aaa71af47',
 'oracle_binder':'b33a065bee0d84ae47c80875132f4b87b0d9e5632f09e43c127283980be28479',
 'api_delta_reviewer':'cdfa70b2db1d3ee6b53b559c5270333350fabbcea3587af67384c8842102190b',
}
TREE_FILES={
 'primary_aux_controls':('primary auxiliary controls source',Path('/private/tmp/jarde-testnestedloops2-full-baseline-prep-luna-v2-20261019/controls/src'),{'jadx/tests/integration/loops/NestedLoops2GenericControls.java':'b39f610887e560eb8c7631727e9ea2cf2510518e182f608f9b1caab9a54a42b1'}),
 'controls_source':('controls source',Path('/private/tmp/jarde-testnestedloops2-controls-prep-luna-v3-20261019/src'),{'jadx/tests/integration/loops/NestedLoops2GenericControls.java':'d27ec67a11e408edb4d1a19b7a9b9bc2f72bdb6528798425a107afd73d3f048c'}),
}
FIXED={
 'primary_baseline_receipt':('/private/tmp/jarde-testnestedloops2-full-baseline-root-v1-20261019/execution.json','342dbc438f372f39d5b6dc1df7414ac6d0523e1e333e37cd92a805cd9b050543'),
 'primary_generated_receipt':('/private/tmp/jarde-testnestedloops2-generated-baseline-root-v1-20261019/execution.json','a06dbf76e1dd80f2dfcf429e7675415a182f407e4aeb1cad2f8ebffd4ae5942e'),
 'controls_v2_baseline_receipt':('/private/tmp/jarde-testnestedloops2-controls-baseline-root-v2-20261019/execution.json','34f84fb1ed94754d0f1045720a19da1da0193fabc172a3d19f74793cbf7da36b'),
 'controls_v2_generated_receipt':('/private/tmp/jarde-testnestedloops2-controls-generated-baseline-root-v2-20261019/execution.json','14d913eadd0e01469707c75173ec3d1a67dd44fd45575992bb9f9ddc255fca75'),
}

def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def replace_once(data:bytes, old:bytes, new:bytes, label:str)->bytes:
 n=data.count(old)
 if n!=1: raise SystemExit(f'{label}: expected exactly one replacement anchor, found {n}')
 return data.replace(old,new,1)
def copy_tree(src:Path,dst:Path):
 if src.exists(): shutil.copytree(src,dst)
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--cli',required=True,type=Path); ap.add_argument('--cli-sha256',required=True)
 ap.add_argument('--out',required=True,type=Path)
 a=ap.parse_args(); cli=a.cli.resolve(strict=True); out=a.out.resolve()
 if len(a.cli_sha256)!=64 or any(c not in '0123456789abcdef' for c in a.cli_sha256): raise SystemExit('CLI SHA must be 64 lowercase hex characters')
 if sha(cli.read_bytes())!=a.cli_sha256: raise SystemExit('explicit final CLI SHA does not match bytes')
 if out.exists(): raise SystemExit(f'refusing existing output: {out}')
 for key,path in SOURCES.items():
  if not path.is_file(): raise SystemExit(f'missing frozen source {key}: {path}')
  if sha(path.read_bytes())!=SOURCE_SHA[key]: raise SystemExit(f'frozen source pin changed: {key}: {path}')
 for path,want,label in ((Path('/private/tmp/jarde-testnestedloops2-full-baseline-prep-luna-v2-20261019/driver/TestNestedLoops2Driver.java'),'8c6cac9925421ef55358a3ab6fbe578ad1ad28c5364667befe279ae25c69afdd','primary driver'),(Path('/private/tmp/jarde-testnestedloops2-controls-prep-luna-v3-20261019/driver/NestedLoops2ControlsDriver.java'),'61acdf0020856bc35d62e528f76c0a29faaa692f3e5097f4029e8b1ac7209534','controls driver')):
  if sha(path.read_bytes())!=want: raise SystemExit(f'{label} pin changed: {path}')
 for _,(label,root,files) in TREE_FILES.items():
  actual={str(p.relative_to(root)):sha(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file()}
  if actual!=files: raise SystemExit(f'{label} tree inventory/hash mismatch: {actual!r}')
 for key,(name,want) in FIXED.items():
  p=Path(name); b=p.read_bytes()
  if sha(b)!=want: raise SystemExit(f'{key} frozen receipt pin changed: {p}')
 out.mkdir(parents=True)
 primary=out/'primary'; controls=out/'controls'; primary.mkdir(); controls.mkdir()
 destinations={
  'primary_collect':primary/'collect_baseline.py',
  'primary_matrix':primary/'collect_generated_matrix.py',
  'primary_verify':primary/'verify_nestedloops2.py',
  'controls_collect':controls/'collect_controls.py',
  'controls_matrix':controls/'collect_controls_generated.py',
  'controls_verify':controls/'review_controls_historical.py',
  'controls_final_checker':controls/'review_controls_final_base.py',
  'controls_final_wrapper':controls/'review_controls_final.py',
  'oracle_binder':out/'bind_final_to_original.py',
  'api_delta_reviewer':out/'verify_final_api_delta.py',
 }
 cli_literal=cli.as_posix().encode(); sha_literal=a.cli_sha256.encode()
 for key,src in SOURCES.items():
  data=src.read_bytes()
  if key in ('primary_collect','controls_collect'):
   data=replace_once(data,OLD_CLI.encode(),cli_literal,key+' CLI path')
   data=replace_once(data,OLD_SHA.encode(),sha_literal,key+' CLI SHA')
  elif key=='primary_verify':
   data=replace_once(data,OLD_SHA.encode(),sha_literal,key+' expected CLI SHA')
  elif key=='controls_final_checker':
   marker=b"CLASS='jadx/tests/integration/loops/NestedLoops2GenericControls'\n"
   data=replace_once(data,marker,marker+b"EXPECTED_CLI_SHA='"+OLD_SHA.encode()+b"'\n",key+' dynamic CLI anchor')
   data=replace_once(data,b"d['cli']['sha256']=='"+OLD_SHA.encode()+b"'",b"d['cli']['sha256']==EXPECTED_CLI_SHA",key+' CLI check')
   old=(b"def signature_cast_facts(helper,parser,b,label,original=True):\n    cf=helper.classfile_probe(b)\n    need(cf['owner']==CLASS and cf['major']==52,f'{label}: classfile owner/major mismatch')\n    by={(m['name'],m['descriptor']):m for m in cf['methods']}\n    void=by[('voidGetCastString','(Ljava/util/List;)V')]\n    wrong=by[('legalWrongCast','(Ljava/util/List;)I')]\n    generic='(Ljava/util/List<Ljava/lang/String;>;)' \n    need(void['signature']==(generic+'V' if original else None),f'{label}: void Signature differs from its original/erased source plane')\n    need(wrong['signature']==(generic+'I' if original else None),f'{label}: wrong-cast Signature differs from its original/erased source plane')\n    def casts(m):\n        code=m['code']; bcis=parser.decode_bcis(code); out=[]\n        for at in bcis:\n            if code[at]==0xc0: out.append(cf['cls'](int.from_bytes(code[at+1:at+3],'big')))\n        return out\n    need(casts(void)==['java/lang/String'],f'{label}: void method lacks exact physical String checkcast')\n    need(casts(wrong)==['java/lang/Integer'],f'{label}: wrong-cast method lacks exact physical Integer checkcast')\n    for name,result in [('fixedBoundBoolean','Z'),('primitiveInt','I'),('primitiveLong','J')]:\n        m=by[(name,'(Ljava/util/List;)'+result)]\n        need(m['signature']==(generic+result if original else None) and casts(m)==['java/lang/String'],f'{label}:{name}: exact primitive Signature/cast evidence differs')\n    return {'void_signature':void['signature'],'void_checkcasts':casts(void),'wrong_signature':wrong['signature'],'wrong_checkcasts':casts(wrong)}\n\n")
   new=(b"def signature_cast_facts(helper,parser,b,label,original=True):\n    cf=helper.classfile_probe(b)\n    need(cf['owner']==CLASS and cf['major']==52,f'{label}: classfile owner/major mismatch')\n    by={(m['name'],m['descriptor']):m for m in cf['methods']}\n    generic='(Ljava/util/List<Ljava/lang/String;>;)'\n    positive={'voidGetCastString':'V','fixedBoundBoolean':'Z','primitiveInt':'I','primitiveLong':'J'}\n    for name,result in positive.items():\n        m=by[(name,'(Ljava/util/List;)'+result)]\n        need(m['signature']==generic+result,f'{label}:{name}: exact List<String> Signature is absent')\n    wrong=by[('legalWrongCast','(Ljava/util/List;)I')]\n    need(wrong['signature']==(generic+'I' if original else None),f'{label}: legalWrongCast must retain original Signature or remain raw in projected source')\n    def casts(m):\n        code=m['code']; bcis=parser.decode_bcis(code); out=[]\n        for at in bcis:\n            if code[at]==0xc0: out.append(cf['cls'](int.from_bytes(code[at+1:at+3],'big')))\n        return out\n    for name in positive:\n        m=by[(name,'(Ljava/util/List;)'+positive[name])]\n        need(casts(m)==['java/lang/String'],f'{label}:{name}: expected physical String checkcast retained')\n    need(casts(wrong)==['java/lang/Integer'],f'{label}: wrong-cast Integer checkcast changed')\n    if original:\n        expected={'reassignAndEscape':'(Ljava/util/List<Ljava/lang/String;>;)I','rawList':None,'wildcardList':'(Ljava/util/List<*>;)I','referenceResult':'(Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/Object;'}\n    else:\n        expected={'reassignAndEscape':None,'rawList':None,'wildcardList':None,'referenceResult':None}\n    for name,sig in expected.items():\n        m=next(m for m in cf['methods'] if m['name']==name)\n        need(m['signature']==sig,f'{label}:{name}: negative/raw source-plane Signature changed')\n    ctor=by[('<init>','()V')]\n    need(ctor['signature'] is None,f'{label}: constructor acquired a generic Signature')\n    return {'positive_list_string_signatures':{name:by[(name,'(Ljava/util/List;)'+result)]['signature'] for name,result in positive.items()},'negative_signatures':expected,'casts':{name:casts(by[(name,'(Ljava/util/List;)'+result)]) for name,result in positive.items()}|{'legalWrongCast':casts(wrong)}}\n\n")
   data=replace_once(data,old,new,key+' source-plane signature/cast check')
  destinations[key].write_bytes(data)
  shutil.copymode(src,destinations[key])
 copy_tree(Path('/private/tmp/jarde-testnestedloops2-full-baseline-prep-luna-v2-20261019/driver'),primary/'driver')
 copy_tree(Path('/private/tmp/jarde-testnestedloops2-full-baseline-prep-luna-v2-20261019/controls/src'),primary/'controls/src')
 copy_tree(Path('/private/tmp/jarde-testnestedloops2-controls-prep-luna-v3-20261019/driver'),controls/'driver')
 copy_tree(Path('/private/tmp/jarde-testnestedloops2-controls-prep-luna-v3-20261019/src'),controls/'src')
 files={str(p.relative_to(out)):sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()}
 record={'schema':'nestedloops2-final-cli-preparation-v2','status':'prepared-only','cli':{'path':str(cli),'bytes':cli.stat().st_size,'sha256':a.cli_sha256},
  'source_scripts':{k:{'path':str(v),'sha256':sha(v.read_bytes())} for k,v in SOURCES.items()},
  'source_trees':{key:{'root':str(root),'files':files} for key,(_,root,files) in TREE_FILES.items()},
  'historical_receipts':{k:{'path':name,'sha256':want} for k,(name,want) in FIXED.items()},
  'prepared_files':files,'execution_performed':False}
 (out/'prepared.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record,indent=2))
if __name__=='__main__':main()
