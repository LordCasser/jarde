# v4 correction memo

Root’s review found a real v3 omission: the final controls-checker template embedded in `prepare_final_cli_bundle.py` still expected a `List<?>` Signature for generated `wildcardList`. That disagreed with the v3 delta reviewer and with the accepted generated class files. v4 changes only the generated branch of the embedded function to require `None`; the `original=True` branch still requires the original physical `List<?>` Signature.

I parsed the builder AST and extracted the embedded `old` and `new` byte-string templates. The source plane branches are explicitly checked: original wildcard Signature is `(Ljava/util/List<*>;)I`; generated wildcard Signature is `None`. This was a static literal check only. I did not run the builder, checker, collector, CLI, JDK, Cargo, or network. v3 remains untouched.

Diff: `v3-to-v4.diff`.
