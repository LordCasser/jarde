# Final API delta reviewer v6

This standalone private reviewer updates v5 and leaves v1–v5 intact. It has not been executed; no CLI, collector, compiler, VM, Cargo command, or network was used.

It checks eight API selectors per family. For each positive it allows only the exact old refusal marker to become the exact success marker observed in the final reports, plus the `java.util.List` to `java.util.List<java.lang.String>` declaration change. Full class text is reconstructed from those method-level replacements. Raw outcomes/reports/maps, all non-positive methods except the two root-adjudicated diagnostic changes, and diagnostics remain strict after recursively omitting `usage`.

Exact positive markers are pinned for primary `test` and controls `voidGetCastString`, `fixedBoundBoolean`, `primitiveInt`, and `primitiveLong`. The controls final receipt has eight captured API cells (still pending independent review); those four markers are identical across all eight. The final primary receipt likewise has eight reports and one stable exact marker.

Root explicitly adjudicated two refusal-message-only changes: `legalWrongCast` and `wildcardList` now report `return source is not a proven parameter value or selected member creation` instead of `same-run Program/SSA cannot prove the body under parameterized types`. The checker permits only those exact old/new marker lines and requires the rest of each method to be equal, including declaration, raw outcome/report, and map. It also permits only the corresponding exact line replacement in whole-class source. Other negative methods remain exact: `reassignAndEscape`, `referenceResult`, and raw `rawList` are not relaxed.

Run after the final generated matrices are available and root has reviewed this preparation:

```sh
python3 -B /private/tmp/jarde-testnestedloops2-final-cli-prep-luna-v6-20261019/verify_final_api_delta.py \
  --primary-old /private/tmp/jarde-testnestedloops2-full-baseline-root-v1-20261019/execution.json \
  --primary-new /private/tmp/jarde-testnestedloops2-final-primary-root-v1-20261019/execution.json \
  --controls-old /private/tmp/jarde-testnestedloops2-controls-baseline-root-v2-20261019/execution.json \
  --controls-new /private/tmp/jarde-testnestedloops2-final-controls-v2-root-v1-20261019/execution.json \
  --primary-matrix <fresh-primary-generated-execution.json> \
  --controls-matrix <fresh-controls-generated-execution.json> \
  --cli <final-cli-path> --cli-sha256 <final-cli-sha256> \
  --out <new-api-delta-review.json>
```
