# v5 exact marker review

Production source `src/class_source.rs` formats a successful generic Signature marker as `// jarde: generic Signature `{signature}` projected after descriptor erasure and {proof}`; same-class proof appends `; same-class call binding proved`. The primary final report was opened read-only. All eight primary test reports have exactly this marker:

`// jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)Z` projected after descriptor erasure and same-run AST/Code/SSA complete body proof; same-class call binding proved`

The v5 checker replaces the old refusal line with that exact line and requires `markers` to equal the singleton list containing it. It does not delete or broadly ignore marker fields.

The controls receipt currently has `status=running` and zero committed API cells, so no controls success-marker strings are claimed. The checker leaves that mapping empty and fails closed for controls until the four positive markers are read from the complete final report and pinned. For every negative method, the existing strict full-method comparison already includes `markers`; changed negative markers fail rather than being normalized.

No collector/toolchain was executed.
