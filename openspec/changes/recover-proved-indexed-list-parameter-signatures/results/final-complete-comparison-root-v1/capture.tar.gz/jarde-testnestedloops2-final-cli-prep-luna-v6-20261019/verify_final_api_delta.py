#!/usr/bin/env python3
"""Strict final CLI API delta and generated class Signature/cast checker; preparation only."""
from __future__ import annotations
import argparse, copy, hashlib, importlib.util, json, zipfile
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
COMPARE=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
BASELINE={
 'primary':('/private/tmp/jarde-testnestedloops2-full-baseline-root-v1-20261019/execution.json','342dbc438f372f39d5b6dc1df7414ac6d0523e1e333e37cd92a805cd9b050543'),
 'controls':('/private/tmp/jarde-testnestedloops2-controls-baseline-root-v2-20261019/execution.json','34f84fb1ed94754d0f1045720a19da1da0193fabc172a3d19f74793cbf7da36b'),
}
POSITIVE={
 'primary':{('test','(Ljava/util/List;)Z')},
 'controls':{('voidGetCastString','(Ljava/util/List;)V'),('fixedBoundBoolean','(Ljava/util/List;)Z'),('primitiveInt','(Ljava/util/List;)I'),('primitiveLong','(Ljava/util/List;)J')},
}
SUCCESS_MARKERS={
 'primary':{('test','(Ljava/util/List;)Z'):'// jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)Z` projected after descriptor erasure and same-run AST/Code/SSA complete body proof; same-class call binding proved'},
 'controls':{
  ('voidGetCastString','(Ljava/util/List;)V'):'// jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete body proof; same-class call binding proved',
  ('fixedBoundBoolean','(Ljava/util/List;)Z'):'// jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)Z` projected after descriptor erasure and same-run AST/Code/SSA complete body proof; same-class call binding proved',
  ('primitiveInt','(Ljava/util/List;)I'):'// jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)I` projected after descriptor erasure and same-run AST/Code/SSA complete body proof; same-class call binding proved',
  ('primitiveLong','(Ljava/util/List;)J'):'// jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;)J` projected after descriptor erasure and same-run AST/Code/SSA complete body proof; same-class call binding proved'},
}
NEGATIVE_MARKER_CHANGES={
 ('controls',('legalWrongCast','(Ljava/util/List;)I')):(
  '// jarde: generic Signature projection refused for `legalWrongCast(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types',
  '// jarde: generic Signature projection refused for `legalWrongCast(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation'),
 ('controls',('wildcardList','(Ljava/util/List;)I')):(
  '// jarde: generic Signature projection refused for `wildcardList(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types',
  '// jarde: generic Signature projection refused for `wildcardList(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation'),
}
METHOD_SIGS={
 'controls':{
  'positive':{
   'voidGetCastString':'(Ljava/util/List<Ljava/lang/String;>;)V',
   'fixedBoundBoolean':'(Ljava/util/List<Ljava/lang/String;>;)Z',
   'primitiveInt':'(Ljava/util/List<Ljava/lang/String;>;)I',
   'primitiveLong':'(Ljava/util/List<Ljava/lang/String;>;)J'},
  'negative':{'legalWrongCast':None,'reassignAndEscape':None,'rawList':None,
              'wildcardList':None,'referenceResult':None}},
 'primary':{'positive':{'test':'(Ljava/util/List<Ljava/lang/String;>;)Z'}}}

def need(ok,msg):
 if not ok: raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(rec,label):
 p=Path(rec['path']).resolve(strict=True); b=p.read_bytes()
 need(rec.get('bytes')==len(b) and rec.get('sha256')==sha(b),f'{label}: pin mismatch')
 return p,b
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path)
 if spec is None or spec.loader is None:raise RuntimeError(f'cannot load {path}')
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def strip_usage(x):
 if isinstance(x,dict):return {k:strip_usage(v) for k,v in x.items() if k!='usage'}
 if isinstance(x,list):return [strip_usage(v) for v in x]
 return x
def cell_map(doc):
 return {(c['profile'],c['input_form'],c['evidence']):c for c in doc['jarde_cells']}
def method_map(doc):
 return {(m['item']['name']['escaped'],m['item']['descriptor']['escaped']):m for m in doc['methods']}
def method_id(m):return (m['item']['name']['escaped'],m['item']['descriptor']['escaped'])
def typed_decl(old,label):
 token='java.util.List'
 need(old.count(token)==1,f'{label}: expected one raw List token in method declaration')
 return old.replace(token,'java.util.List<java.lang.String>',1)
def replace_one_marker(text,old_marker,new_marker,label):
 lines=text.splitlines(keepends=True); hits=[i for i,line in enumerate(lines) if line.strip()==old_marker]
 need(len(hits)==1,f'{label}: expected one exact old refusal marker in projected text, got {len(hits)}')
 line=lines[hits[0]]; prefix=line[:len(line)-len(line.lstrip())]
 ending='\r\n' if line.endswith('\r\n') else ('\n' if line.endswith('\n') else '')
 lines[hits[0]]=prefix+new_marker+ending
 return ''.join(lines)
def expected_positive_text(oldm,label,success_marker):
 markers=oldm.get('markers')
 need(isinstance(markers,list) and len(markers)==1 and markers[0].startswith('// jarde: generic Signature projection refused for `'),f'{label}: historical positive refusal marker shape differs')
 text=replace_one_marker(oldm['text'],markers[0],success_marker,label)
 olddecl=oldm['declaration']; newdecl=typed_decl(olddecl,label)
 need(text.count(olddecl)==1,f'{label}: declaration is not uniquely embedded in method text')
 return newdecl,text.replace(olddecl,newdecl,1)
def inspect_family(family,old,new,cli,cli_sha,compare):
 need(old['schema']==new['schema'],f'{family}: source-baseline schema differs')
 need(new['cli']['path']==str(cli) and new['cli']['sha256']==cli_sha,f'{family}: final CLI pin mismatch')
 oldcells=cell_map(old);newcells=cell_map(new)
 need(set(oldcells)==set(newcells) and len(newcells)==8,f'{family}: exact default/all selector set differs')
 typed=POSITIVE[family]; changed=0; negative_marker_changes=0; method_count=None
 for key,oc in oldcells.items():
  nc=newcells[key]; need(oc['exit_code']==nc['exit_code']==0,f'{family}:{key}: API command failed')
  po,oldraw=pin(oc['report'],f'{family}:{key} old raw report');pn,newraw=pin(nc['report'],f'{family}:{key} final raw report')
  oldcmds={c['index']:c for c in old['commands']};newcmds={c['index']:c for c in new['commands']}
  need(oc['command'] in oldcmds and nc['command'] in newcmds,f'{family}:{key}: API command index is absent')
  oldcmd=oldcmds[oc['command']];newcmd=newcmds[nc['command']]
  need(compare.command_artifact(oldcmd,'stdout')==oldraw and compare.command_artifact(newcmd,'stdout')==newraw,f'{family}:{key}: CLI stdout/report byte binding failed')
  od=json.loads(oldraw);nd=json.loads(newraw)
  _,osource=pin(oc['whole_source'],f'{family}:{key} old source');_,nsource=pin(nc['whole_source'],f'{family}:{key} final source')
  need(od['text'].encode()==osource and nd['text'].encode()==nsource,f'{family}:{key}: whole-source/report text binding failed')
  om=method_map(od);nm=method_map(nd);need(set(om)==set(nm),f'{family}:{key}: method identities changed')
  if method_count is None: method_count=len(om)
  need(len(om)==method_count,f'{family}:{key}: physical method inventory count changed')
  need(strip_usage({k:v for k,v in od.items() if k not in ('text','methods')})==strip_usage({k:v for k,v in nd.items() if k not in ('text','methods')}),f'{family}:{key}: class/report diagnostics or metadata changed outside methods/text')
  expected_source=od['text']
  for ident,oldm in om.items():
   newm=nm[ident]; positive=ident in typed; label=f'{family}:{key}:{ident[0]}{ident[1]}'
   need(newm['item']==oldm['item'],f'{label}: physical item identity changed')
   need(strip_usage(oldm['outcome'])==strip_usage(newm['outcome']),f'{label}: raw outcome/report changed beyond usage')
   oldreport=oldm['outcome']['report'];newreport=newm['outcome']['report']
   need(strip_usage(oldreport.get('source_map'))==strip_usage(newreport.get('source_map')),f'{label}: raw method source map changed')
   if positive:
    success_marker=SUCCESS_MARKERS[family].get(ident)
    need(isinstance(success_marker,str) and success_marker.startswith('// jarde: generic Signature `') and ' projected after descriptor erasure and ' in success_marker,f'{label}: exact success marker is not pinned from final API evidence')
    expected_decl,expected_text=expected_positive_text(oldm,label,success_marker)
    need(newm['declaration']==expected_decl,f'{label}: projected declaration differs beyond List<String> header')
    need(newm['text']==expected_text,f'{label}: projected method text differs beyond exact refusal-to-success marker replacement and List<String> header')
    need(newm.get('markers')==[success_marker],f'{label}: exact projected success marker differs')
    allowed={'declaration','text','markers'}
    need(newm['declaration'].count('java.util.List<java.lang.String>')==1,f'{label}: exact List<String> declaration missing')
   elif (family,ident) in NEGATIVE_MARKER_CHANGES:
    old_marker,new_marker=NEGATIVE_MARKER_CHANGES[(family,ident)]
    need(oldm.get('markers')==[old_marker] and newm.get('markers')==[new_marker],f'{label}: exact adjudicated refusal-marker diagnostic change differs')
    expected_text=replace_one_marker(oldm['text'],old_marker,new_marker,label)
    need(newm['text']==expected_text,f'{label}: negative method changed beyond the exact refusal-marker message')
    allowed={'text','markers'}
    negative_marker_changes+=1
   else:
    need(strip_usage(newm)==strip_usage(oldm),f'{label}: negative/non-target projected method changed')
    allowed=set()
   need(expected_source.count(oldm['text'])==1,f'{label}: old method text is not unique in whole class')
   expected_source=expected_source.replace(oldm['text'],newm['text'],1)
   need(strip_usage({k:v for k,v in oldm.items() if k not in allowed})==strip_usage({k:v for k,v in newm.items() if k not in allowed}),f'{label}: non-approved projected method fields changed')
  need(expected_source==nd['text'],f'{family}:{key}: complete class text has unapproved changes')
  need(od.get('diagnostics',[])==nd.get('diagnostics',[]),f'{family}:{key}: top-level diagnostics changed')
 # For each profile/form, evidence levels must keep the same complete projection plane.
 for profile in ('debug','no-debug'):
  for form in ('child','bundle-child'):
   a=json.loads(Path(newcells[(profile,form,'default')]['report']['path']).read_bytes())
   b=json.loads(Path(newcells[(profile,form,'all')]['report']['path']).read_bytes())
   need(a['text']==b['text'],f'{family}:{profile}/{form}: default/all whole class text differs')
   def evidence_plane(doc):
    return [(m['item']['identity'],m['declaration'],m['text'],m['outcome']['kind'],m['outcome']['report']['text'],m['outcome']['report'].get('source_map'),m['outcome']['report'].get('quality'),m['outcome']['report'].get('fallbacks')) for m in doc['methods']]
   need(evidence_plane(a)==evidence_plane(b),f'{family}:{profile}/{form}: default/all projected/raw/map plane differs')
 return {'api_cells':8,'physical_methods_per_cell':method_count,'positive_method_cells':len(typed)*8,'negative_method_cells':(method_count-len(typed))*8,'precise_projected_method_changes':changed,'exact_negative_marker_change_cells':negative_marker_changes,'raw_reports_and_maps_unchanged':True,'whole_class_text_exact_delta':True}

def method_signatures(class_path,compare,helper,parser,label,family,generated):
 p,b=pin(class_path,label);cf=helper.classfile_probe(b);need(cf['major']==52,f'{label}: generated class is not Java 8')
 by={(m['name'],m['descriptor']):m for m in cf['methods']}
 expected=METHOD_SIGS[family]
 descriptors={'primary':{'test':'(Ljava/util/List;)Z'},'controls':{
  'voidGetCastString':'(Ljava/util/List;)V','fixedBoundBoolean':'(Ljava/util/List;)Z',
  'primitiveInt':'(Ljava/util/List;)I','primitiveLong':'(Ljava/util/List;)J',
  'legalWrongCast':'(Ljava/util/List;)I','reassignAndEscape':'(Ljava/util/List;)I',
  'rawList':'(Ljava/util/List;)I','wildcardList':'(Ljava/util/List;)I',
  'referenceResult':'(Ljava/util/List;)Ljava/lang/Object;'}}[family]
 for name,sig in expected['positive'].items():
  need((name,descriptors[name]) in by and by[(name,descriptors[name])]['signature']==sig,f'{label}:{name}: exact descriptor/typed Signature is missing')
 if family=='controls':
  for name,sig in expected['negative'].items():
   need((name,descriptors[name]) in by and by[(name,descriptors[name])]['signature']==sig,f'{label}:{name}: exact descriptor or negative/raw/wildcard Signature changed')
  def casts(m):
   code=m['code'];bcis=parser.decode_bcis(code)
   return [cf['cls'](int.from_bytes(code[i+1:i+3],'big')) for i in bcis if code[i]==0xc0]
  for name in ('voidGetCastString','fixedBoundBoolean','primitiveInt','primitiveLong'):
   need(casts(by[(name,descriptors[name])])==['java/lang/String'],f'{label}:{name}: physical String checkcast changed')
  need(casts(by[('legalWrongCast',descriptors['legalWrongCast'])])==['java/lang/Integer'],f'{label}: legalWrongCast Integer checkcast changed')
 if family=='primary':
  test=by[('test','(Ljava/util/List;)Z')];code=test['code'];bcis=parser.decode_bcis(code)
  casts=[cf['cls'](int.from_bytes(code[i+1:i+3],'big')) for i in bcis if code[i]==0xc0]
  need(casts==['java/lang/String'],f'{label}: test String checkcast not retained')
  need(by[('<init>','()V')]['signature'] is None,f'{label}: constructor acquired a generic Signature')
 return {'class':cf['owner'],'method_signatures':{name:sig for name,sig in expected['positive'].items()}}
def generated_signature_review(primary_matrix,controls_matrix,helper,parser):
 reports={}
 for family,path in [('primary',primary_matrix),('controls',controls_matrix)]:
  d=json.loads(path.read_text()); cells={tuple(x['cell_key']):x for x in d['source_cells']};checked=[]
  if family=='controls':
   compilation_rows=d['compilations']
  else:
   compilation_rows=[dict(z,cell_key=x['cell_key'],source_kind=x['kind']) for x in d['source_cells'] for z in x.get('compilations',[])]
  for c in compilation_rows:
   key=tuple(c['cell_key'])
   kind=c.get('source_kind',cells[key]['kind'])
   if kind!='jarde' or c['exit_code']!=0:continue
   target_name=('jadx/tests/integration/loops/TestNestedLoops2$TestCls.class' if family=='primary' else 'jadx/tests/integration/loops/NestedLoops2GenericControls.class')
   tree=c['class_tree'];need(target_name in tree,f'{family}:{key}: successful Jarde class tree misses target')
   checked.append(method_signatures(tree[target_name],None,helper,parser,f'{family}:{key}:{c["leg"]}',family,True))
  need(checked,f'{family}: no successful generated Jarde target classes checked')
  reports[family]={'successful_generated_jarde_classes':len(checked),'facts':checked}
 return reports

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--primary-old',type=Path,required=True);ap.add_argument('--primary-new',type=Path,required=True)
 ap.add_argument('--controls-old',type=Path,required=True);ap.add_argument('--controls-new',type=Path,required=True)
 ap.add_argument('--primary-matrix',type=Path,required=True);ap.add_argument('--controls-matrix',type=Path,required=True)
 ap.add_argument('--cli',type=Path,required=True);ap.add_argument('--cli-sha256',required=True);ap.add_argument('--out',type=Path,required=True)
 a=ap.parse_args();need(not a.out.exists(),'refusing existing output')
 cli=Path(a.cli).resolve(strict=True);need(sha(cli.read_bytes())==a.cli_sha256,'final CLI SHA mismatch')
 compare=load(COMPARE,'final_api_delta_compare');need(sha(COMPARE.read_bytes())==COMPARE_SHA,'compare helper SHA changed')
 # Use exact same pinned classfile parsers as the already reviewed primary verifier.
 helper=load(Path('/private/tmp/jarde-testnestedloops2-acceptance-prep-root-v1-20261019/verify_nestedloops2.py'),'final_primary_helper')
 parser=load(Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py'),'final_primary_parser')
 outputs={}
 for family,oldpin in BASELINE.items():
  oldp,want=oldpin;oldbytes=Path(oldp).read_bytes();need(sha(oldbytes)==want,f'{family}: historical receipt SHA changed')
  newp=getattr(a,f'{family}_new').resolve(strict=True);newdoc=json.loads(newp.read_text());need(newdoc['cli']['sha256']==a.cli_sha256 and newdoc['cli']['path']==str(cli),f'{family}: new receipt CLI identity mismatch')
  outputs[family]=inspect_family(family,json.loads(oldbytes),newdoc,cli,a.cli_sha256,compare)
 outputs['generated_signatures']=generated_signature_review(a.primary_matrix.resolve(strict=True),a.controls_matrix.resolve(strict=True),helper,parser)
 def receipt_pin(path):
  p=Path(path).resolve(strict=True);raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':sha(raw)}
 result={'schema':'nestedloops2-final-api-delta-review-v4','status':'review_complete','cli':{'path':str(cli),'bytes':cli.stat().st_size,'sha256':a.cli_sha256},
  'inputs':{'primary_old':receipt_pin(BASELINE['primary'][0]),'primary_new':receipt_pin(a.primary_new),'controls_old':receipt_pin(BASELINE['controls'][0]),'controls_new':receipt_pin(a.controls_new),'primary_matrix':receipt_pin(a.primary_matrix),'controls_matrix':receipt_pin(a.controls_matrix)},'families':outputs,
  'policy':'Only designated projected declarations, exact captured refusal-to-success markers, the two adjudicated negative refusal-message substitutions, and corresponding whole-class source block replacements are allowed; all other raw outcome/report/map content and diagnostics remain exact after recursively omitting usage.'}
 a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
