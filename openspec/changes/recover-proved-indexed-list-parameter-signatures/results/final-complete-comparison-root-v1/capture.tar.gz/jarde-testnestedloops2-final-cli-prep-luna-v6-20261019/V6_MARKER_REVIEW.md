# v6 adjudicated-marker review

The exact positive success markers were read from each of the eight fresh final API stdout reports. Primary `test` uses `same-run AST/Code/SSA complete body proof; same-class call binding proved`. All four controls positives use the same proof suffix with their exact erased descriptor signatures. The checker pins these strings verbatim and replaces the single old refusal line with the matching success marker.

The final controls API reports also show two negative refusal-message updates. Root read `src/class_source.rs` and adjudicated these as permitted diagnostic refinements for the existing `ordinary_generic_source_unproved` refusal category: only `legalWrongCast` and `wildcardList` may change from the exact old same-run Program/SSA message to the exact new return-source message. V6 does not normalize all refusal messages. It requires those exact method identities and exact marker pair, checks the whole projected method excluding only `text`/`markers` against the old method, separately requires exact marker-line replacement in the text, and synthesizes the class text from those replacements.

All other negative methods remain byte-for-byte equivalent after recursive removal of `usage`; a different cause/message still fails. Raw outcome/report/map equality is checked before these text-only exceptions, so the accepted negative diagnostics cannot mask body, declaration, raw-map, or quality changes.

The two receipts are captured but remain pending independent review; this preparation itself was not executed.
