import datetime,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
OUT=Path('/private/tmp/jarde-indexed-list-signatures-final-run-root-v1-20261019')
PREP=Path('/private/tmp/jarde-testnestedloops2-final-cli-prep-luna-v4-20261019')
BUNDLE=Path('/private/tmp/jarde-testnestedloops2-final-cli-bundle-root-v1-20261019')
PRIMARY=Path('/private/tmp/jarde-testnestedloops2-final-primary-root-v1-20261019')
PMATRIX=Path('/private/tmp/jarde-testnestedloops2-final-primary-generated-root-v1-20261019')
CONTROL=Path('/private/tmp/jarde-testnestedloops2-final-controls-v2-root-v1-20261019')
CMATRIX=Path('/private/tmp/jarde-testnestedloops2-final-controls-generated-v2-root-v1-20261019')
def pin(p):
 p=Path(p).resolve(strict=True);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def h(p):return pin(p)['sha256']
assert not OUT.exists() and not (ROOT/'target').exists()
broad=Path('/private/tmp/jarde-indexed-list-signatures-broad-root-v2-20261019/execution.json')
b=json.loads(broad.read_text());assert b['status']=='commands_passed_pending_independent_acceptance' and b['source_unchanged'] and b['target_absent'] and b['source_changes_accepted'];cli=b['cli'];assert pin(cli['path'])==cli
assert h(PREP/'prepare_final_cli_bundle.py')=='d3d6034a9c5139e80486802217e84c30fded9c7070a17fb58d6f4e97b719b87c'
OUT.mkdir();r={'status':'running','runner':pin(__file__),'broad':pin(broad),'cli':cli,'commands':[]}
def save():(OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args):
 assert not (ROOT/'target').exists()
 argv=['python3','-B',*[str(a) for a in args]];n=len(r['commands'])+1;so=OUT/f'{n}.stdout.raw';se=OUT/f'{n}.stderr.raw';row={'label':label,'argv':argv,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with so.open('xb') as out,se.open('xb') as err:done=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=err)
 row.update(exit_code=done.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),streams={'stdout':pin(so),'stderr':pin(se)});r['commands'].append(row);save();print(json.dumps({'label':label,'exit_code':done.returncode}),flush=True)
 assert done.returncode==0,label+' failed; raw evidence retained'
save()
try:
 run('prepare-final-cli-bundle',[PREP/'prepare_final_cli_bundle.py','--cli',cli['path'],'--cli-sha256',cli['sha256'],'--out',BUNDLE])
 run('capture-complete-primary',[BUNDLE/'primary/collect_baseline.py','--out',PRIMARY])
 run('capture-complete-primary-generated',[BUNDLE/'primary/collect_generated_matrix.py','--baseline',PRIMARY/'execution.json','--baseline-sha256',h(PRIMARY/'execution.json'),'--out',PMATRIX])
 run('capture-complete-controls-v2',[BUNDLE/'controls/collect_controls.py','--out',CONTROL])
 run('capture-complete-controls-generated-v2',[BUNDLE/'controls/collect_controls_generated.py','--baseline',CONTROL/'execution.json','--baseline-sha256',h(CONTROL/'execution.json'),'--out',CMATRIX])
 run('independent-primary-review',[BUNDLE/'primary/verify_nestedloops2.py','--baseline',PRIMARY/'execution.json','--baseline-sha256',h(PRIMARY/'execution.json'),'--matrix',PMATRIX/'execution.json','--matrix-sha256',h(PMATRIX/'execution.json'),'--out',OUT/'primary-review.json'])
 run('independent-controls-review',[BUNDLE/'controls/review_controls_final.py','--baseline',CONTROL/'execution.json','--baseline-sha256',h(CONTROL/'execution.json'),'--generated',CMATRIX/'execution.json','--generated-sha256',h(CMATRIX/'execution.json'),'--cli',cli['path'],'--cli-sha256',cli['sha256'],'--checker',BUNDLE/'controls/review_controls_final_base.py','--out',OUT/'controls-review.json'])
 run('bind-original-java-oracles',[BUNDLE/'bind_final_to_original.py','--primary-new',PRIMARY/'execution.json','--primary-new-sha256',h(PRIMARY/'execution.json'),'--controls-new',CONTROL/'execution.json','--controls-new-sha256',h(CONTROL/'execution.json'),'--cli',cli['path'],'--cli-sha256',cli['sha256'],'--out',OUT/'original-oracle-binding.json'])
 run('independent-exact-api-delta',[BUNDLE/'verify_final_api_delta.py','--primary-old','/private/tmp/jarde-testnestedloops2-full-baseline-root-v1-20261019/execution.json','--primary-new',PRIMARY/'execution.json','--controls-old','/private/tmp/jarde-testnestedloops2-controls-baseline-root-v2-20261019/execution.json','--controls-new',CONTROL/'execution.json','--primary-matrix',PMATRIX/'execution.json','--controls-matrix',CMATRIX/'execution.json','--cli',cli['path'],'--cli-sha256',cli['sha256'],'--out',OUT/'api-delta-review.json'])
 r['status']='captures_and_review_commands_passed_pending_root_acceptance'
except BaseException as e:r.update(status='failed',error=str(e))
finally:
 r['target_absent']=not (ROOT/'target').exists();r['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({'status':r['status'],'error':r.get('error'),'target_absent':r['target_absent']}),flush=True)
sys.exit(0 if r['status']=='captures_and_review_commands_passed_pending_root_acceptance' else 1)
