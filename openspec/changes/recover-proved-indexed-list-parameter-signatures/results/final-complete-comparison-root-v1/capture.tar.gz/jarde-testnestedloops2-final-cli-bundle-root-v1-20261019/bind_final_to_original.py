#!/usr/bin/env python3
"""Bind fresh final-CLI captures to the accepted original Java/class/runtime oracles only.

This is intentionally independent of repository source-closure snapshots: code changed for the
new CLI, so each fresh receipt is checked for its own before/after stability by its verifier.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, zipfile
from pathlib import Path

OLD={
 'primary':('/private/tmp/jarde-testnestedloops2-full-baseline-root-v1-20261019/execution.json','342dbc438f372f39d5b6dc1df7414ac6d0523e1e333e37cd92a805cd9b050543'),
 'controls':('/private/tmp/jarde-testnestedloops2-controls-baseline-root-v2-20261019/execution.json','34f84fb1ed94754d0f1045720a19da1da0193fabc172a3d19f74793cbf7da36b'),
}
COMPARE=Path('/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'

def need(ok,msg):
 if not ok: raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(rec,label):
 p=Path(rec['path']).resolve(strict=True); b=p.read_bytes()
 need(len(b)==rec['bytes'] and sha(b)==rec['sha256'],f'{label}: pin changed: {p}')
 return p,b
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path)
 if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
 m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
def read(dpath,want,label,compare):
 b=dpath.read_bytes(); need(sha(b)==want,f'{label}: receipt SHA mismatch'); d=json.loads(b)
 need(d.get('status')=='captured-pending-independent-review',f'{label}: receipt not complete/pending review')
 need(d.get('source_unchanged') is True and d.get('source_unchanged_finally') is True and d.get('target_absent') is True and d.get('target_absent_finally') is True,f'{label}: source or target cleanup gate failed')
 need(d['source_pins_before']==d['source_pins_after']==d['source_pins_after_finally'],f'{label}: own source snapshots changed')
 return d,{c['index']:c for c in d['commands']}
def class_tree(row):
 return {k:(v['bytes'],v['sha256']) for k,v in row['class_tree'].items()}
def raw(compare,cmd,ch):return compare.command_artifact(cmd,ch)
def profile_runtime(d,commands):
 return {(r['profile'],r['runtime']):r for r in d['original_runtime']},commands

def family(label,old_path,old_sha,new_path,new_sha,compare,cli,cli_sha):
 old,oc=read(Path(old_path),old_sha,label+' historical baseline',compare)
 new,nc=read(Path(new_path),new_sha,label+' final baseline',compare)
 need(old['schema']==new['schema'],f'{label}: baseline schema changed')
 need(new['cli']['path']==str(cli) and new['cli']['sha256']==cli_sha,f'{label}: final CLI pin mismatch')
 oldp={x['profile']:x for x in old['source_profiles']}; newp={x['profile']:x for x in new['source_profiles']}
 need(set(oldp)==set(newp)=={'debug','no-debug'},f'{label}: profile coverage differs')
 for profile in oldp:
  a,b=oldp[profile],newp[profile]
  need(class_tree(a)==class_tree(b),f'{label}:{profile}: original physical class tree bytes changed')
  for key in ('target_facts','outer_facts'):
   if key in a:
    need(key in b and {k:v for k,v in a[key].items() if k!='path'}=={k:v for k,v in b[key].items() if k!='path'},f'{label}:{profile}: {key} physical facts changed')
  ca=oc[a['command']]; cb=nc[b['command']]
  need(ca['exit_code']==cb['exit_code']==0,f'{label}:{profile}: original source compile failed')
  need(raw(compare,ca,'stdout')==raw(compare,cb,'stdout') and raw(compare,ca,'stderr')==raw(compare,cb,'stderr'),f'{label}:{profile}: original javac raw output differs')
 # The standalone observer, Java fixture bytes, JDK manifest, runtime wrapper and dependency classpath are fixed.
 for key in ('source','control_source','driver_source','runtime_wrapper'):
  if key in old or key in new:
   need(key in old and key in new,f'{label}: {key} inventory differs')
   _,ab=pin(old[key],label+' old '+key); _,bb=pin(new[key],label+' new '+key)
   need(ab==bb,f'{label}: {key} bytes changed')
 def driver_class_rows(doc):
  root=Path(doc['output']).resolve()/'driver-classes'
  rows={}
  for rec in doc['driver_classes']:
   pth,bts=pin(rec,label+' driver class')
   rows[pth.relative_to(root).as_posix()]=(len(bts),sha(bts))
  return rows
 need(driver_class_rows(old)==driver_class_rows(new),f'{label}: standalone driver class bytes changed')
 need(old['jdk_manifest']==new['jdk_manifest'],f'{label}: JDK manifest/tool pins changed')
 need(old.get('dependency_classpath')==new.get('dependency_classpath'),f'{label}: dependency classpath changed')
 # Four original runtime outputs are exact Java-behavior controls, including ordered event traces.
 ort={(r['profile'],r['runtime']):r for r in old['original_runtime']}; nrt={(r['profile'],r['runtime']):r for r in new['original_runtime']}
 need(set(ort)==set(nrt)=={(p,v) for p in ('debug','no-debug') for v in ('javac8','javac23')},f'{label}: original runtime grid differs')
 for k,a in ort.items():
  b=nrt[k]; ca=oc[a['command']]; cb=nc[b['command']]
  need(a['rows']==b['rows'] and raw(compare,ca,'stdout')==raw(compare,cb,'stdout') and raw(compare,ca,'stderr')==raw(compare,cb,'stderr'),f'{label}:{k}: Java case/event oracle changed')
 # Every class-source selector must still consume the exact old physical target bytes.
 oldcells={(x['profile'],x['input_form'],x['evidence']):x for x in old['jarde_cells']}
 newcells={(x['profile'],x['input_form'],x['evidence']):x for x in new['jarde_cells']}
 need(set(oldcells)==set(newcells) and len(newcells)==8,f'{label}: default/all API selector set differs')
 for k,a in oldcells.items():
  b=newcells[k]; pa,ba=pin(a['input'],label+' old API input'); pb,bb=pin(b['input'],label+' final API input')
  def selected_classes(path,data,form,identity):
   if form=='child' and path.suffix=='.class': return {identity+'.class':data}
   with zipfile.ZipFile(path) as z:
    names=[n for n in z.namelist() if n.endswith('.class')]
    want=identity+'.class'
    need(want in names and len(names)==len(set(names)),f'{label}:{k}: target absent/duplicate in API bundle')
    return {n:z.read(n) for n in names}
  identity=old['source_profiles'][0]['target_facts']['class_name']
  old_classes=selected_classes(pa,ba,k[1],identity); new_classes=selected_classes(pb,bb,k[1],identity)
  need(old_classes.keys()==new_classes.keys() and old_classes==new_classes,f'{label}:{k}: API physical class bundle bytes changed')
 return {'original_profiles':2,'physical_class_files':sum(len(class_tree(x)) for x in newp.values()),'original_runtime_cells':4,'runtime_case_rows':sum(len(x['rows']) for x in nrt.values()),'api_cells':8,'api_inputs_byte_bound':True}

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for fam in ('primary','controls'):
  ap.add_argument('--'+fam+'-new',required=True,type=Path); ap.add_argument('--'+fam+'-new-sha256',required=True)
 ap.add_argument('--cli',required=True,type=Path);ap.add_argument('--cli-sha256',required=True);ap.add_argument('--out',required=True,type=Path)
 a=ap.parse_args(); need(not a.out.exists(),'refusing existing output')
 cli=Path(a.cli).resolve(strict=True); need(sha(cli.read_bytes())==a.cli_sha256,'final CLI bytes/SHA mismatch')
 compare=load(COMPARE,'nestedloops2_final_oracle_compare'); need(sha(COMPARE.read_bytes())==COMPARE_SHA,'compare helper pin changed')
 result={'schema':'nestedloops2-final-cli-original-oracle-binding-v1','cli':{'path':str(cli),'sha256':a.cli_sha256},
  'families':{
   'primary':family('primary',*OLD['primary'],a.primary_new.resolve(strict=True),a.primary_new_sha256,compare,cli,a.cli_sha256),
   'controls':family('controls',*OLD['controls'],a.controls_new.resolve(strict=True),a.controls_new_sha256,compare,cli,a.cli_sha256)},
  'source_policy':'fresh capture source pins are checked for within-capture stability only; they are not compared to historical source closure pins.'}
 a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
