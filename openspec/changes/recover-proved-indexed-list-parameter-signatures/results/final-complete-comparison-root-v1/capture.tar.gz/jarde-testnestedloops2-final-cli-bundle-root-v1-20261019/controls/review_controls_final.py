#!/usr/bin/env python3
"""Review one fresh final-CLI controls-v2 baseline and generated matrix using the accepted checker logic.

Read-only: opens receipts, raw streams, classes and pins; runs no product/toolchain command.
"""
from __future__ import annotations
import argparse, importlib.util, json, sys
from pathlib import Path

def load(path):
 spec=importlib.util.spec_from_file_location('accepted_nestedloops2_controls_checker',path)
 if spec is None or spec.loader is None: raise RuntimeError(f'cannot load accepted checker: {path}')
 mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--baseline',required=True,type=Path); ap.add_argument('--baseline-sha256',required=True)
 ap.add_argument('--generated',required=True,type=Path); ap.add_argument('--generated-sha256',required=True)
 ap.add_argument('--cli',required=True,type=Path); ap.add_argument('--cli-sha256',required=True)
 ap.add_argument('--checker',required=True,type=Path,help='prepared v3 checker copy with only the CLI SHA check parameterized')
 ap.add_argument('--out',required=True,type=Path)
 a=ap.parse_args()
 if a.out.exists(): raise SystemExit(f'refusing existing report: {a.out}')
 mod=load(a.checker)
 mod.EXPECTED_CLI_SHA=a.cli_sha256
 cli=mod.pin({'path':str(a.cli),'sha256':a.cli_sha256},'final CLI')[0]
 mod.RECEIPT_SHA['base2']=a.baseline_sha256
 mod.RECEIPT_SHA['gen2']=a.generated_sha256
 compare_path=mod.ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
 compare=mod.load_module(compare_path,'nestedloops2_final_compare')
 parser=mod.load_module(mod.PARSER_SHA and Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py'),'nestedloops2_final_parser')
 helper=mod.load_module(mod.PREP/'verify_nestedloops2.py','nestedloops2_final_existing_helper')
 base,bc=mod.read_receipt(a.baseline,'base2',compare,parser)
 gen,gc=mod.read_receipt(a.generated,'gen2',compare,parser)
 mod.need(base['cli']['path']==str(cli) and base['cli']['sha256']==a.cli_sha256,'baseline CLI identity differs from explicit final CLI pin')
 mod.need(gen['baseline_receipt']['sha256']==a.baseline_sha256,'generated receipt is not bound to selected final baseline')
 mod.need(base['source_pins_before']==base['source_pins_after']==base['source_pins_after_finally'],'fresh baseline source closure changed during capture')
 mod.need(gen['source_pins_before']==gen['source_pins_after']==gen['source_pins_after_finally'],'generated source closure changed during capture')
 mod.need(gen['source_pins_before']==base['source_pins_before'],'generated matrix was not run against its fresh final baseline source snapshot')
 # No comparison is made to the old baseline's source closure; current receipts carry their own stable snapshots.
 b=mod.verify_base(base,bc,'v2',compare,parser,helper)
 g=mod.verify_generated(gen,gc,'v2',b,compare,parser,helper)
 out={'schema':'nestedloops2-final-cli-controls-v2-review-v1','status':'review_complete','cli':{'path':str(cli),'bytes':cli.stat().st_size,'sha256':a.cli_sha256},
      'baseline':{'path':str(a.baseline.resolve()),'sha256':a.baseline_sha256,'commands':len(base['commands']),'api_cells':8,'original_runtime_cells':4,'wrong_root':1},
      'generated':{'path':str(a.generated.resolve()),'sha256':a.generated_sha256,**g},
      'source_snapshot_policy':'fresh baseline and generated receipts must be stable and match each other; no equality to historical source_pins_before is asserted.'}
 a.out.parent.mkdir(parents=True,exist_ok=True); a.out.write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2))
if __name__=='__main__':main()
