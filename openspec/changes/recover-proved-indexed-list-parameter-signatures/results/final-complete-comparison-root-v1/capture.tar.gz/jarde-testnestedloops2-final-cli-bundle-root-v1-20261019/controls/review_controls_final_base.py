#!/usr/bin/env python3
"""Independent read-only integrity/runtime acceptance for NestedLoops2 controls receipts."""
from __future__ import annotations
import argparse, ast, hashlib, importlib.util, json, os, re, sys, zipfile
from pathlib import Path
sys.dont_write_bytecode = True

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
PREP = Path('/private/tmp/jarde-testnestedloops2-acceptance-prep-root-v1-20261019')
BASE = Path('/private/tmp/jarde-testnestedloops2-controls-baseline-root-{v}-20261019/execution.json')
GEN = Path('/private/tmp/jarde-testnestedloops2-controls-generated-baseline-root-{v}-20261019/execution.json')
SUP = Path('/private/tmp/jarde-testnestedloops2-controls-javac8-supplement-root-{v}-20261019/execution.json')
RECEIPT_SHA = {
    'base1':'af878134ce2644435d4abfab675670e81090557df27f58a33cc93285d3deabe6',
    'base2':'34f84fb1ed94754d0f1045720a19da1da0193fabc172a3d19f74793cbf7da36b',
    'gen1':'cfbdd71e9442a1896fc79c66d48d2dacbbc47d5794985bfec4a499c5ec080680',
    'gen2':'14d913eadd0e01469707c75173ec3d1a67dd44fd45575992bb9f9ddc255fca75',
    'sup1':'0dbef8e2d1f6726938e1a63a121c81ff94889eb59d96061b3477821ce0213fe6',
    'sup2':'5dc3a5f07061fa0a5a97320731c47e6a54559b3c676fd135f41aca9fa7f32793',
}
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
PARSER_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
CLASS='jadx/tests/integration/loops/NestedLoops2GenericControls'
EXPECTED_CLI_SHA='56a589ef9a170a1bb2911ed5597c20b2b4e06abf78da845f8fd3946099b2fa51'
METHODS={('<init>','()V'),('voidGetCastString','(Ljava/util/List;)V'),('fixedBoundBoolean','(Ljava/util/List;)Z'),('primitiveInt','(Ljava/util/List;)I'),('primitiveLong','(Ljava/util/List;)J'),('legalWrongCast','(Ljava/util/List;)I'),('reassignAndEscape','(Ljava/util/List;)I'),('rawList','(Ljava/util/List;)I'),('wildcardList','(Ljava/util/List;)I'),('referenceResult','(Ljava/util/List;)Ljava/lang/Object;')}
CASES=16
EXPECTED_WRAPPER = b"import subprocess,sys\nargv=sys.argv[2:];seconds=float(sys.argv[1]);p=subprocess.Popen(argv)\ntry:sys.exit(p.wait(timeout=seconds))\nexcept subprocess.TimeoutExpired:\n p.kill();p.wait();print('ROOT_RUNTIME_TIMEOUT_SECONDS='+str(seconds),file=sys.stderr);sys.exit(124)\n"
ENV={'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','RUST_TEST_THREADS':'1','CARGO_TERM_COLOR':'always'}

class AuditError(RuntimeError): pass
def need(ok, msg):
    if not ok: raise AuditError(msg)
def sha(b): return hashlib.sha256(b).hexdigest()
def load_module(path, name):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise AuditError(f'cannot load helper {path}')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
def pin(rec, label):
    need(isinstance(rec,dict) and 'path' in rec and 'sha256' in rec, f'{label}: malformed pin')
    p=Path(rec['path']).resolve(strict=True); b=p.read_bytes()
    if 'bytes' in rec: need(len(b)==rec['bytes'],f'{label}: length changed: {p}')
    need(sha(b)==rec['sha256'],f'{label}: SHA changed: {p}')
    return p,b
def walk_pins(x,label):
    if isinstance(x,dict):
        if {'path','sha256'}<=x.keys() and ('bytes' in x or len(x)==2):
            pin(x,label); return
        for k,v in x.items(): walk_pins(v,f'{label}.{k}')
    elif isinstance(x,list):
        for i,v in enumerate(x): walk_pins(v,f'{label}[{i}]')
def import_helpers():
    need(sha((PREP/'verify_nestedloops2.py').read_bytes())=='8059435aacb8585f3bf4c7251dc9b6f127fc8bae23a12ae178a5572f4f55fd34','root helper pin differs')
    verify=load_module(PREP/'verify_nestedloops2.py','nestedloops2_existing_verifier')
    compare_path=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
    parser_path=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
    need(sha(compare_path.read_bytes())==COMPARE_SHA,'compare.py pin changed')
    need(sha(parser_path.read_bytes())==PARSER_SHA,'physical parser pin changed')
    need(sha((ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py').read_bytes())==GUARD_SHA,'guard pin changed')
    need(sha((ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py').read_bytes())==SCANNER_SHA,'scanner pin changed')
    compare=load_module(compare_path,'nestedloops2_compare')
    parser=load_module(parser_path,'nestedloops2_classfile_helpers')
    return verify,compare,parser

def read_receipt(path,key,compare,parser,helper):
    p=Path(path).resolve(strict=True); raw=p.read_bytes()
    need(sha(raw)==RECEIPT_SHA[key],f'{key}: frozen receipt SHA changed')
    d=json.loads(raw); need(d.get('status')=='captured-pending-independent-review',f'{key}: unexpected/nonterminal status')
    walk_pins(d,key)
    need(d.get('target_absent') is True and d.get('target_absent_finally') is True,f'{key}: target not absent')
    need(d.get('source_unchanged') is True and d.get('source_unchanged_finally') is True,f'{key}: source closure changed')
    need(d['source_pins_before']==d['source_pins_after']==d['source_pins_after_finally'],f'{key}: source pin snapshots differ')
    need(d.get('external_inputs_unchanged') is True,f'{key}: external inputs changed')
    if 'external_inputs_unchanged_finally' in d: need(d['external_inputs_unchanged_finally'] is True,f'{key}: external inputs changed finally')
    if 'external_input_pins_before' in d:
        need(d['external_input_pins_before']==d['external_input_pins_after']==d['external_input_pins_after_finally'],f'{key}: external pin snapshots differ')
    if 'external_pins_before' in d:
        need(d['external_pins_before']==d['external_pins_after']==d['external_pins_after_finally'],f'{key}: external pin snapshots differ')
    if 'local_copy_pins_before' in d:
        need(d['local_copies_unchanged'] is True and d['local_copies_unchanged_finally'] is True and d['local_copy_pins_before']==d['local_copy_pins_after']==d['local_copy_pins_after_finally'],f'{key}: local copies changed')
    if 'local_copies_before' in d:
        need(d['local_copies_unchanged'] is True and d['local_copies_before']==d['local_copies_after']==d['local_copies_after_finally'],f'{key}: local copies changed')
    if 'generated_output_pins_before' in d:
        need(d['generated_outputs_unchanged'] is True and d['generated_outputs_unchanged_finally'] is True and d['generated_output_pins_before']==d['generated_output_pins_after']==d['generated_output_pins_after_finally'],f'{key}: saved generated outputs changed')
    need(d.get('counts_derived_from_commands',d.get('counts_derived') is not None),f'{key}: count provenance missing')
    commands=helper.command_map(d,compare,len(d.get('commands',[])))
    need(commands and len(commands)==len(d['commands']),f'{key}: command inventory empty')
    for c in commands.values():
        need(c.get('env_overrides')==ENV,f'{key}: command environment guard differs: {c["label"]}')
    for k,want in [('compare',COMPARE_SHA),('physical_parser',PARSER_SHA),('guard',GUARD_SHA),('scanner',SCANNER_SHA)]:
        need(d[k]['sha256']==want,f'{key}: tool pin mismatch: {k}')
    jdk=d['jdk_manifest']; jp,jb=pin(jdk,f'{key} JDK manifest')
    need(sha(jb)==JDK_SHA,f'{key}: JDK manifest SHA differs')
    j=json.loads(jb)
    manifest_legs={x['leg']:x for x in j['legs']}
    need(set(manifest_legs)=={'javac8','javac23'},f'{key}: manifest JDK leg inventory differs')
    for leg in ('javac8','javac23'):
        for tool in ('java','javac','javap'):
            manifest_tool=manifest_legs[leg]['jdk_tools'][tool]
            receipt_tool=jdk['tools'][leg][tool]
            need({'path':str(Path(manifest_tool['path']).resolve(strict=True)),'bytes':manifest_tool['bytes'],'sha256':manifest_tool['sha256']}=={k:receipt_tool[k] for k in ('path','bytes','sha256')},f'{key}: {leg}/{tool} manifest binding differs')
            pin(receipt_tool,f'{key} {leg} {tool}')
    return d,commands

def check_command_roots(cmd, java_path=None, driver=None, target=None, wrong=None, wrapper=None):
    av=cmd['argv']; need(isinstance(av,list) and av,f'empty argv: {cmd["label"]}')
    if java_path is not None:
        need(av[4]==java_path and '-Xverify:all' in av,f'{cmd["label"]}: wrong JVM/verification flags')
        need(av[1]=='-B' and av[3]=='30' and (wrapper is None or av[2]==wrapper),f'{cmd["label"]}: wrapper/timeout differs from pinned 30-second default-stack runner')
    if driver is not None: need(av[av.index('-cp')+1]==driver and av[av.index('-cp')+2]=='NestedLoops2ControlsDriver',f'{cmd["label"]}: non-driver classpath')
    if target is not None and wrong is None: need(av[-2:]==[target,target],f'{cmd["label"]}: actual/expected root mismatch')
    if wrong is not None: need(av[-2:]==[target,wrong],f'{cmd["label"]}: wrong-root paths mismatch')
    need(not any(a.startswith('-Xss') or a.startswith('-Xmx') for a in av),f'{cmd["label"]}: non-default stack/heap override')

def parse_case_lines(raw):
    rx=re.compile(r'^CASE index=(\d+) name=([^ ]+) method=([^ ]+) result=([^ ]+) exception=([^ ]+) events=(.*?) escapedInput=(true|false)$')
    lines=raw.decode('utf-8','strict').splitlines(); out=[]
    for i,line in enumerate(lines):
        m=rx.fullmatch(line); need(m is not None,f'malformed control case line: {line!r}')
        ix,name,method,result,exc,events,escaped=m.groups(); need(int(ix)==i,f'noncontiguous case index {line!r}')
        out.append({'index':i,'name':name,'method':method,'result':result,'exception_type':exc,'events':events,'escaped_input':escaped,'raw':line})
    need(len(out)==CASES,f'expected {CASES} cases; saw {len(out)}')
    need(len({r['name'] for r in out})==CASES,'duplicate case names')
    return out
def sem(rows): return [{k:r[k] for k in ('index','name','method','result','exception_type','events','escaped_input')} for r in rows]
def command_for(commands,index):
    need(type(index)==int and index in commands,f'bad command reference {index}')
    return commands[index]
def check_rows(rec,cmd,compare,label):
    raw=compare.command_artifact(cmd,'stdout'); err=compare.command_artifact(cmd,'stderr')
    need(cmd['exit_code']==rec['exit_code']==0 and err==b'',f'{label}: runtime did not complete cleanly')
    rows=parse_case_lines(raw); need(rec['stdout']==cmd['streams']['stdout'] and rec['stderr']==cmd['streams']['stderr'],f'{label}: runtime stream pins differ')
    need(rec['rows']==rows,f'{label}: parsed rows differ from actual stdout')
    return rows
def physical_target(compare,parser,rec,label,helper):
    p,b=pin(rec['path'] and rec or {'path':rec['path'],'bytes':rec['bytes'],'sha256':rec['sha256']},label)
    fact=compare.parse_class(p); parsed=parser.parse_class_file(b)
    both=compare.parse_class(p)
    # Existing independent verifier cross-checks the two parsers and raw opcode boundaries.
    got=helper.physical(compare,parser,p)
    ids={(m['name'],m['descriptor']) for m in got['methods']}
    need(got['class_name']==CLASS and ids==METHODS and len(got['methods'])==10,f'{label}: exact class/method inventory mismatch')
    need(len(got['fields'])==1 and got['fields']==[('escaped','Ljava/util/List;',10)],f'{label}: field inventory mismatch')
    need(got['major']==52,f'{label}: expected Java 8 classfile')
    need(all(m.get('code') is not None for m in got['methods']),f'{label}: missing Code array')
    if 'methods' in rec:
        need(all(k in got and json.dumps(got[k],sort_keys=True)==json.dumps(value,sort_keys=True) for k,value in rec.items()),f'{label}: saved full physical facts differ from reopened bytes')
    return got,b

def signature_cast_facts(helper,parser,b,label,original=True):
    cf=helper.classfile_probe(b)
    need(cf['owner']==CLASS and cf['major']==52,f'{label}: classfile owner/major mismatch')
    by={(m['name'],m['descriptor']):m for m in cf['methods']}
    generic='(Ljava/util/List<Ljava/lang/String;>;)'
    positive={'voidGetCastString':'V','fixedBoundBoolean':'Z','primitiveInt':'I','primitiveLong':'J'}
    for name,result in positive.items():
        m=by[(name,'(Ljava/util/List;)'+result)]
        need(m['signature']==generic+result,f'{label}:{name}: exact List<String> Signature is absent')
    wrong=by[('legalWrongCast','(Ljava/util/List;)I')]
    need(wrong['signature']==(generic+'I' if original else None),f'{label}: legalWrongCast must retain original Signature or remain raw in projected source')
    def casts(m):
        code=m['code']; bcis=parser.decode_bcis(code); out=[]
        for at in bcis:
            if code[at]==0xc0: out.append(cf['cls'](int.from_bytes(code[at+1:at+3],'big')))
        return out
    for name in positive:
        m=by[(name,'(Ljava/util/List;)'+positive[name])]
        need(casts(m)==['java/lang/String'],f'{label}:{name}: expected physical String checkcast retained')
    need(casts(wrong)==['java/lang/Integer'],f'{label}: wrong-cast Integer checkcast changed')
    if original:
        expected={'reassignAndEscape':'(Ljava/util/List<Ljava/lang/String;>;)I','rawList':None,'wildcardList':'(Ljava/util/List<*>;)I','referenceResult':'(Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/Object;'}
    else:
        expected={'reassignAndEscape':None,'rawList':None,'wildcardList':None,'referenceResult':None}
    for name,sig in expected.items():
        m=next(m for m in cf['methods'] if m['name']==name)
        need(m['signature']==sig,f'{label}:{name}: negative/raw source-plane Signature changed')
    ctor=by[('<init>','()V')]
    need(ctor['signature'] is None,f'{label}: constructor acquired a generic Signature')
    return {'positive_list_string_signatures':{name:by[(name,'(Ljava/util/List;)'+result)]['signature'] for name,result in positive.items()},'negative_signatures':expected,'casts':{name:casts(by[(name,'(Ljava/util/List;)'+result)]) for name,result in positive.items()}|{'legalWrongCast':casts(wrong)}}

def validate_api_maps(doc,facts,cell,label,helper):
    report_methods=doc.get('methods'); need(isinstance(report_methods,list) and len(report_methods)==10,f'{label}: report method inventory incomplete')
    fmap={(m['name'],m['descriptor']):m for m in facts['methods']}
    seen=set(); map_missing=[]; map_incomplete=[]
    for m in report_methods:
        item=m['item']; name=item['name']['escaped']; desc=item['descriptor']['escaped']; key=(name,desc)
        need(key in METHODS and key not in seen,f'{label}: unknown/duplicate API method {key}'); seen.add(key)
        identity=item['identity']; owner=identity['owner']
        need(identity['name']==list(name.encode()) and identity['descriptor']==list(desc.encode()),f'{label}:{key}: identity bytes mismatch')
        need(owner==doc['class'] and item['access_flags']==fmap[key]['access'] and item['index']==fmap[key]['index'] and owner['class_bytes']['length']==facts['bytes'],f'{label}:{key}: class identity length mismatch')
        outcome=m['outcome']; need(outcome['kind']=='recovered',f'{label}:{key}: API outcome is not recovered')
        body=outcome.get('report'); need(isinstance(body,dict),f'{label}:{key}: missing raw method report')
        need(body['artifact']['binding']['method']==identity and body['method']==name+desc,f'{label}:{key}: raw method artifact binding differs')
        quality=body.get('quality'); fallback=body.get('fallbacks',[])
        expected_v1_fallback=(cell['version']=='v1' and name=='voidGetCastString')
        need((quality=='fallback' and fallback==['jre_region_uncovered_blocks']) if expected_v1_fallback else (quality=='structured' and not fallback),f'{label}:{key}: unexpected recovery/quality classification')
        sm=body.get('source_map'); segs=sm.get('segments') if isinstance(sm,dict) else None
        if not isinstance(segs,list):
            need(expected_v1_fallback,f'{label}:{key}: missing source map outside preserved v1 fallback')
            map_missing.append(key); continue
        # Validate every recorded range and origin. Structured methods must map every physical BCI.
        text=body['text'].encode('utf-8'); bounds={0,len(text),*(i for i,b in enumerate(text) if b&0xc0!=0x80)}
        mapped=set(); bcis=set(fmap[key]['code']['bcis'])
        for s in segs:
            start,end=s.get('start'),s.get('end')
            need(type(start)==int and type(end)==int and 0<=start<=end<=len(text) and start in bounds and end in bounds,f'{label}:{key}: invalid UTF-8 source-map span')
            origin=s.get('origin'); need(isinstance(origin,dict) and isinstance(origin.get('primary'),dict),f'{label}:{key}: source-map origin missing')
            for o in [origin['primary'],*origin.get('derived',[])]:
                at=o.get('bci'); need(type(at)==int and at in bcis,f'{label}:{key}: source-map BCI outside physical Code')
                om=o.get('method'); need(isinstance(om,dict) and om.get('owner')==owner and om.get('name')==identity['name'] and om.get('descriptor')==identity['descriptor'],f'{label}:{key}: source-map method owner mismatch')
                mapped.add(at)
        if quality=='structured': need(mapped==bcis,f'{label}:{key}: source map misses physical BCIs {sorted(bcis-mapped)}')
        elif mapped!=bcis: map_incomplete.append({'method':key,'mapped_bcis':len(mapped),'physical_bcis':len(bcis)})
        summary=next(x for x in cell['methods'] if (x['name'],x['descriptor'])==key)
        need(summary['quality']==quality and summary['fallbacks']==fallback,f'{label}:{key}: receipt summary/raw quality mismatch')
    need(seen==METHODS,f'{label}: report does not cover every physical method')
    return {'missing_raw_maps':map_missing,'fallback_map_coverage':map_incomplete}

def member_surface(f): return (f['class_name'],f['access'],tuple(sorted(tuple(x) for x in f['fields'])),tuple(sorted((m['name'],m['descriptor'],m['access']) for m in f['methods'])))
def verify_base(d,commands,ver,compare,parser,helper):
    need(d['schema']=='private-testnestedloops2-generic-controls-baseline-v1',f'{ver}: baseline schema mismatch')
    need(len(d['commands'])==20 and len(d['source_profiles'])==2 and len(d['jarde_cells'])==8 and len(d['jadx_outputs'])==2,f'{ver}: incomplete baseline grid')
    cli_p,cli_b=pin(d['cli'],f'{ver} CLI'); need(cli_p.stat().st_size==d['cli']['bytes'],f'{ver}: CLI length mismatch')
    need(d['source_unchanged'] and d['source_unchanged_finally'] and d['local_copies_unchanged'] and d['local_copies_unchanged_finally'] and d['external_inputs_unchanged'],f'{ver}: closure flags false')
    source_path,source_bytes=pin(d['source'],f'{ver} source'); _,source_copy_bytes=pin(d['source_copy'],f'{ver} source copy'); _,control_bytes=pin(d['control_source'],f'{ver} control source')
    need(source_bytes==source_copy_bytes==control_bytes and source_path.name=='NestedLoops2GenericControls.java',f'{ver}: original source/copy/control pin differs')
    driver_src,driver_bytes=pin(d['driver_source'],f'{ver} driver source'); _,copy_bytes=pin(d['driver_copy'],f'{ver} driver copy'); need(driver_bytes==copy_bytes,f'{ver}: driver source copy differs')
    wrapper_path,wrapper_bytes=pin(d['runtime_wrapper'],f'{ver} runtime wrapper')
    need(wrapper_bytes==EXPECTED_WRAPPER,f'{ver}: timeout wrapper body differs')
    need(d['cli']['sha256']==EXPECTED_CLI_SHA,f'{ver}: CLI is not the frozen controls baseline CLI')
    for mark in (b'new URLClassLoader(new URL[] {url}, null)',b'wrong CodeSource:',b'target.getClassLoader() != loader'):
        need(re.sub(rb'\s+',b'',mark) in re.sub(rb'\s+',b'',driver_bytes),f'{ver}: missing parentless/CodeSource driver guard')
    dc=command_for(commands,d['driver_compile']['command']); driver_root=Path(d['output'])/'driver-classes'
    need(dc['exit_code']==d['driver_compile']['exit_code']==0 and dc['label']=='compile-independent-reflection-driver' and dc['argv'][0]==d['jdk_manifest']['tools']['javac8']['javac']['path'],f'{ver}: isolated driver compile failed/tool changed')
    dav=dc['argv']; need(str(Path(d['driver_copy']['path']).resolve()) in dav and '-classpath' in dav and dav[dav.index('-classpath')+1]==str(Path(d['output'])/'empty-classpath') and Path(dav[dav.index('-d')+1]).resolve()==driver_root.resolve(),f'{ver}: driver compile classpath/source/output binding differs')
    got_driver={str(x.resolve()):{'path':str(x.resolve()),'bytes':x.stat().st_size,'sha256':sha(x.read_bytes())} for x in sorted(driver_root.rglob('*.class'))}
    expected_driver={x['path']:x for x in d['driver_classes']}
    need(got_driver==expected_driver,f'{ver}: independent driver classfile pins differ')
    need(d['driver_compile']['stdout']==dc['streams']['stdout'] and d['driver_compile']['stderr']==dc['streams']['stderr'],f'{ver}: driver raw streams differ')
    profiles={x['profile']:x for x in d['source_profiles']}; need(set(profiles)=={'debug','no-debug'},f'{ver}: source profile set mismatch')
    facts={}
    for profile,row in profiles.items():
        need(row['exit_code']==0 and row['command'] in commands,f'{ver}:{profile}: original source compilation failed')
        cmd=command_for(commands,row['command']); need(cmd['exit_code']==0 and cmd['argv'][0]==d['jdk_manifest']['tools']['javac23']['javac']['path'] and '--release' in cmd['argv'] and cmd['argv'][cmd['argv'].index('--release')+1]=='8' and ('-g' if profile=='debug' else '-g:none') in cmd['argv'],f'{ver}:{profile}: source compile binary/release/profile mismatch')
        need(str(Path(d['source_copy']['path']).resolve()) in cmd['argv'] and Path(cmd['argv'][cmd['argv'].index('-d')+1]).resolve()==Path(row['class_root']).resolve(),f'{ver}:{profile}: full-source compile argv/output mismatch')
        need('-sourcepath' in cmd['argv'] and Path(cmd['argv'][cmd['argv'].index('-sourcepath')+1]).resolve()==(Path(d['output'])/'empty-classpath').resolve(),f'{ver}:{profile}: sourcepath not isolated')
        f,b=physical_target(compare,parser,row['target_facts'],f'{ver}:{profile} original class',helper)
        need(row['target_facts']['path']==row['class_tree'][CLASS+'.class']['path'],f'{ver}:{profile}: class tree target path mismatch')
        tree=row['class_tree']; need(set(tree)=={CLASS+'.class'} and {k:tree[CLASS+'.class'][k] for k in ('path','bytes','sha256')}=={k:row['target_facts'][k] for k in ('path','bytes','sha256')},f'{ver}:{profile}: original class tree pin mismatch')
        facts[profile]=f
        signature_cast_facts(helper,parser,b,f'{ver}:{profile} original')
        jv=helper.classfile_probe(b)
        by={(m['name'],m['descriptor']):m for m in jv['methods']}
        need(len(jv['fields'])==1 and jv['fields'][0][1]=='escaped' and jv['fields'][0][2]=='Ljava/util/List;',f'{ver}:{profile}: escaped field physical shape differs')
    need(member_surface(facts['debug'])==member_surface(facts['no-debug']),f'{ver}: debug/no-debug surface differs')
    boundary=d['javac8_full_source_boundary']; bcmd=commands[boundary['command']]
    need(boundary['exit_code']==bcmd['exit_code']==0 and boundary['major_55_diagnostic_observed'] is False,f'{ver}: javac8 whole-source boundary compile did not succeed')
    bav=bcmd['argv']; need(bav[0]==d['jdk_manifest']['tools']['javac8']['javac']['path'] and '-source' in bav and '-target' in bav and bav[bav.index('-source')+1]=='8' and bav[bav.index('-target')+1]=='8' and str(Path(d['source_copy']['path']).resolve()) in bav,f'{ver}: JDK8 boundary did not compile exact complete source at release 8')
    need(boundary['stdout']==bcmd['streams']['stdout'] and boundary['stderr']==bcmd['streams']['stderr'],f'{ver}: boundary raw streams differ')
    btree=boundary['class_tree']; need(set(btree)=={CLASS+'.class'},f'{ver}: JDK8 boundary class inventory incomplete')
    _,boundary_bytes=physical_target(compare,parser,btree[CLASS+'.class'],f'{ver}:JDK8 boundary class',helper); signature_cast_facts(helper,parser,boundary_bytes,f'{ver}:JDK8 boundary class')
    # The CLI saw exactly the physical class or a one-entry jar containing those same bytes.
    api={(x['profile'],x['input_form'],x['evidence']):x for x in d['jarde_cells']}
    need(set(api)=={(p,f,e) for p in ('debug','no-debug') for f in ('child','bundle-child') for e in ('default','all')},f'{ver}: API selector grid incomplete')
    # Fixed JADX output is checked as a full source closure, not by a hand-selected method.
    need(len(d['jadx_outputs'])==2,f'{ver}: full JADX output profile count differs')
    for jr in d['jadx_outputs']:
        profile=jr['compiler_profile']; need(profile in ('debug','no-debug') and jr['display_profile']=='default' and jr['exit_code']==0,f'{ver}:{profile}: JADX full decode failed')
        cmd=commands[jr['command']]; need(cmd['exit_code']==0 and cmd['label']==f'jadx-full-bundle-{profile}-default' and cmd['argv'][0]==d['jadx']['path'],f'{ver}:{profile}: wrong JADX invocation')
        inp,jar_bytes=pin(jr['input'],f'{ver}:{profile} JADX input jar'); original=Path(profiles[profile]['target_facts']['path']).read_bytes()
        with zipfile.ZipFile(inp) as jar:
            classes=[n for n in jar.namelist() if n.endswith('.class')]
            need(classes==[CLASS+'.class'] and jar.read(classes[0])==original,f'{ver}:{profile}: JADX bundle is not the complete original target class')
        dest=Path(cmd['argv'][cmd['argv'].index('-d')+1]).resolve(); sources=jr['sources']; actual={str(x.resolve()) for x in dest.rglob('*.java')}
        need(actual=={str(Path(x['path']).resolve()) for x in sources} and sources,f'{ver}:{profile}: JADX Java source closure incomplete')
        need(all(Path(x['path']).resolve().is_relative_to(dest) for x in sources),f'{ver}:{profile}: JADX source escaped output root')
    summaries={}
    for key,c in api.items():
        p,form,e=key; need(c['exit_code']==0 and c['command'] in commands,f'{ver}:{key}: API command failed')
        ip,ib=pin(c['input'],f'{ver}:{key} input class'); target=Path(profiles[p]['target_facts']['path']).resolve(); target_bytes=target.read_bytes()
        if form=='child': need(ip==target and ib==target_bytes,f'{ver}:{key}: child input not exact profile class')
        else:
            with zipfile.ZipFile(ip) as z:
                names=[n for n in z.namelist() if n.endswith('.class')]
                need(names==[CLASS+'.class'] and z.read(names[0])==target_bytes,f'{ver}:{key}: bundle target not exact original class')
        cmd=commands[c['command']]; need(cmd['argv'][0]==str(cli_p) and cmd['exit_code']==0 and '--release' in cmd['argv'] and cmd['argv'][cmd['argv'].index('--release')+1]=='8',f'{ver}:{key}: wrong CLI/release invocation')
        need(('--evidence' in cmd['argv']) == (e=='all') and ('all' in cmd['argv'] if e=='all' else True),f'{ver}:{key}: evidence selector mismatch')
        expected_argv=[str(cli_p),'class-source','--input',str(ip),'--class',CLASS,'--policy','single-class' if form=='child' else 'plain-jar','--release','8','--format','json']+(['--evidence','all'] if e=='all' else [])
        need(cmd['argv']==expected_argv and cmd['label']==f'jarde-{p}-{form}-{e}',f'{ver}:{key}: exact input/policy/API binding differs')
        rp,rb=pin(c['report'],f'{ver}:{key} report'); need(compare.command_artifact(cmd,'stdout')==rb,f'{ver}:{key}: report bytes differ from raw CLI stdout')
        doc=json.loads(rb); wp,wb=pin(c['whole_source'],f'{ver}:{key} whole source'); need(doc['text'].encode('utf-8')==wb,f'{ver}:{key}: whole source differs from API report')
        need(c['physical_method_inventory']==[list(x) for x in sorted(METHODS,key=lambda x:next(i for i,m in enumerate(profiles[p]['target_facts']['methods']) if (m['name'],m['descriptor'])==x))],f'{ver}:{key}: physical method inventory mismatch')
        map_audit=validate_api_maps(doc,facts[p],dict(c,version=ver),f'{ver}:{key}',helper)
        summaries['/'.join(key)]={'input_sha256':c['input']['sha256'],'whole_source_sha256':c['whole_source']['sha256'],'maps':map_audit}
        if ver=='v1':
            m=next(m for m in doc['methods'] if m['item']['name']['escaped']=='voidGetCastString')
            if m['outcome']['report']['quality']=='fallback':
                need('jarde_refused_body()' in m['outcome']['report']['text'] and 'ordinary_generic_source_unproved' in '\n'.join(doc['text'].splitlines()),f'{ver}:{key}: expected preserved whole-method quote absent')
    for profile in ('debug','no-debug'):
        for form in ('child','bundle-child'):
            a=json.loads(Path(api[(profile,form,'default')]['report']['path']).read_bytes()); z=json.loads(Path(api[(profile,form,'all')]['report']['path']).read_bytes())
            need(a['text']==z['text'],f'{ver}:{profile}/{form}: complete source changes by evidence')
            def plane(doc):
                return [(m['item']['identity'],m['declaration'],m['text'],m['outcome']['kind'],m['outcome']['report']['text'],m['outcome']['report']['source_map'],m['outcome']['report']['quality'],m['outcome']['report']['fallbacks']) for m in doc['methods']]
            need(plane(a)==plane(z),f'{ver}:{profile}/{form}: declaration/projected/raw/map planes change by evidence')
    # Original runtime: four profile×VM cells, each output parsed from pinned raw stdout.
    runtime={}
    need(len(d['original_runtime'])==4,f'{ver}: original runtime grid incomplete')
    for rec in d['original_runtime']:
        p,vm=rec['profile'],rec['runtime']; k=(p,vm); need(k not in runtime and p in profiles and vm in ('javac8','javac23'),f'{ver}: duplicate/bad original runtime selector')
        cmd=commands[rec['command']]; root=str(Path(profiles[p]['class_root']).resolve()); driver=str((Path(d['output'])/'driver-classes').resolve())
        check_command_roots(cmd,d['jdk_manifest']['tools'][vm]['java']['path'],driver,root,wrapper=str(wrapper_path))
        rows=check_rows(rec,cmd,compare,f'{ver}:original:{p}:{vm}'); runtime[k]=rows
        need(rec['target_root']==root and rec['application_classpath']==[driver],f'{ver}:{k}: runtime roots/classpath mismatch')
    for p in profiles:
        base_sem=sem(runtime[(p,'javac8')]); need(sem(runtime[(p,'javac23')])==base_sem,f'{ver}:{p}: original VM outputs diverge')
    need(d['runtime_semantic_agreement'] is True and all(sem(rows)==sem(next(iter(runtime.values()))) for rows in runtime.values()),f'{ver}: original semantic agreement does not follow from raw cases')
    wrong=d['wrong_root_control']; cmd=commands[wrong['command']]; actual=str(Path(profiles['debug']['class_root']).resolve()); empty=str((Path(d['output'])/'empty-classpath').resolve())
    check_command_roots(cmd,d['jdk_manifest']['tools']['javac23']['java']['path'],str((Path(d['output'])/'driver-classes').resolve()),actual,empty,wrapper=str(wrapper_path))
    err=compare.command_artifact(cmd,'stderr'); out=compare.command_artifact(cmd,'stdout'); need(cmd['exit_code']==wrong['exit_code']==1 and wrong['rejected'] is True and b'wrong CodeSource:' in err,f'{ver}: original wrong-root did not reject')
    need(wrong['stdout']==cmd['streams']['stdout'] and wrong['stderr']==cmd['streams']['stderr'],f'{ver}: wrong-root raw streams differ')
    return {'doc':d,'commands':commands,'profiles':profiles,'facts':facts,'runtime':runtime,'api':api,'api_summaries':summaries,'driver':str((Path(d['output'])/'driver-classes').resolve())}

def verify_generated(d,commands,ver,base,compare,parser,helper):
    need(d['schema']=='private-testnestedloops2-generic-controls-generated-source-matrix-v1',f'{ver}: generated schema mismatch')
    need(len(d['source_cells'])==10 and len(d['compilations'])==20,f'{ver}: generated full-source compile grid incomplete')
    need(d['baseline_sha256_argument']==RECEIPT_SHA['base1' if ver=='v1' else 'base2'],f'{ver}: baseline argument SHA mismatch')
    # Explicit binding to the selected baseline receipt (not a similarly shaped sibling).
    bp=Path(base['doc']['output'])/'execution.json'
    need(Path(d['baseline_receipt']['path']).resolve()==bp.resolve() and d['baseline_receipt']['sha256']==RECEIPT_SHA['base1' if ver=='v1' else 'base2'],f'{ver}: not bound to matching baseline receipt')
    need(d['source_pins_before']==base['doc']['source_pins_before'],f'{ver}: generated source closure differs from matching baseline')
    wrapper_rec=next(x for x in d['local_copies_before'] if x['path'].endswith('jarde-nestedloops3-runtime-bound-root-v1-20261018.py'))
    wrapper_path,_=pin(wrapper_rec,f'{ver} generated runtime wrapper')
    wrapper_bytes=wrapper_path.read_bytes(); need(wrapper_bytes==EXPECTED_WRAPPER,f'{ver}: generated timeout wrapper body differs')
    driver=str((Path(d['output'])/'driver-classes').resolve())
    need(Path(d['driver_copy']['path']).read_bytes()==Path(base['doc']['driver_source']['path']).read_bytes()==Path(d['driver_source']['path']).read_bytes(),f'{ver}: generated driver source differs from original observer')
    dc=commands[d['driver_compile']['command']]; av=dc['argv']
    need(dc['exit_code']==0 and av[0]==base['doc']['jdk_manifest']['tools']['javac8']['javac']['path'] and av[av.index('-classpath')+1]==str(Path(d['output'])/'empty-classpath') and Path(av[av.index('-d')+1]).resolve()==Path(driver) and av[-1]==d['driver_copy']['path'],f'{ver}: generated observer compile binding differs')
    source_by_key={}
    for c in d['source_cells']:
        key=tuple(c['cell_key']); need(len(c['source_copies'])>0,f'{ver}:{key}: empty source list')
        if c['kind']=='jarde':
            old=base['api'].get(key); need(old is not None and c['kind']=='jarde',f'{ver}:{key}: unknown API cell')
            need(len(c['source_copies'])==1 and c['source_copies'][0]['source']==old['whole_source'],f'{ver}:{key}: Jarde source not exact full API output')
            _,source_bytes=pin(c['source_copies'][0]['source'],f'{ver}:{key} API source'); _,copy_bytes=pin(c['source_copies'][0]['copy'],f'{ver}:{key} copied source')
            need(source_bytes==copy_bytes,f'{ver}:{key}: Jarde source copy edited')
            doc=json.loads(Path(old['report']['path']).read_bytes()); need(source_bytes==doc['text'].encode('utf-8'),f'{ver}:{key}: copied source not report whole text')
            need(Path(c['source_copies'][0]['copy']['path']).name=='NestedLoops2GenericControls.java',f'{ver}:{key}: compile unit filename illegal')
            source_by_key[key]=[str(Path(c['source_copies'][0]['copy']['path']).resolve())]
        elif c['kind']=='jadx':
            need(key in (('debug','bundle'),('no-debug','bundle')),f'{ver}:{key}: unexpected JADX selector')
            old=next(x for x in base['doc']['jadx_outputs'] if x['compiler_profile']==key[0])
            need(len(c['source_copies'])==len(old['sources']) and c['source_copies'],f'{ver}:{key}: JADX source closure incomplete')
            paths=[]
            for a,b in zip(old['sources'],c['source_copies']):
                need(a==b['source'],f'{ver}:{key}: JADX source order/source pin mismatch')
                _,ab=pin(a,f'{ver}:{key} JADX input source'); _,bb=pin(b['copy'],f'{ver}:{key} copied source')
                need(ab==bb,f'{ver}:{key}: copied JADX source edited'); paths.append(str(Path(b['copy']['path']).resolve()))
            source_by_key[key]=sorted(paths)
        else: raise AuditError(f'{ver}:{key}: unknown source kind')
    comp_by={}
    for c in d['compilations']:
        key=tuple(c['cell_key']); leg=c['leg']; ck=(key,leg); need(ck not in comp_by and leg in ('javac8','javac23'),f'{ver}: duplicate/invalid compile cell')
        comp_by[ck]=c; cmd=commands[c['command']]
        need(cmd['exit_code']==c['exit_code'] and cmd['label'].startswith('compile-') and cmd['label'].endswith('-'+leg),f'{ver}:{ck}: compile command linkage mismatch')
        av=cmd['argv']; want=base['doc']['jdk_manifest']['tools'][leg]['javac']['path']; need(av[0]==want,f'{ver}:{ck}: wrong javac binary')
        need(('-source' in av and '-target' in av and av[av.index('-source')+1]=='8' and av[av.index('-target')+1]=='8') if leg=='javac8' else '--release' in av and av[av.index('--release')+1]=='8',f'{ver}:{ck}: wrong release flags')
        need('-sourcepath' in av and Path(av[av.index('-sourcepath')+1]).resolve()==(Path(d['output'])/'empty-classpath').resolve(),f'{ver}:{ck}: generated compilation sourcepath not isolated')
        need(('-g' if key[0]=='debug' else '-g:none') in av and '-proc:none' in av,f'{ver}:{ck}: wrong debug/annotation processor flags')
        need('-classpath' in av and av[av.index('-classpath')+1]==os.pathsep.join(base['doc']['dependency_classpath']),f'{ver}:{ck}: compile classpath changed')
        expected=source_by_key[key]; args=av[av.index('-d')+2:]; need(args==expected,f'{ver}:{ck}: javac source closure/argv mismatch')
        need(Path(av[av.index('-d')+1]).resolve()==Path(c['class_root']).resolve(),f'{ver}:{ck}: compile output root mismatch')
        stdout=compare.command_artifact(cmd,'stdout'); stderr=compare.command_artifact(cmd,'stderr')
        need(c['stdout']==cmd['streams']['stdout'] and c['stderr']==cmd['streams']['stderr'],f'{ver}:{ck}: compiler raw stream pin mismatch')
        tree={p.relative_to(Path(c['class_root'])).as_posix():{'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(Path(c['class_root']).rglob('*')) if p.is_file()}
        need(tree==c['class_tree'],f'{ver}:{ck}: actual compiler output tree differs')
        if c['exit_code']==0:
            need(bool(tree) and c['class_facts'] is not None,f'{ver}:{ck}: successful compiler lacks class facts')
            actual={}
            for rel,record in tree.items():
                f,b=physical_target(compare,parser,record,f'{ver}:{ck}:{rel}',helper); actual[rel]=f
                signature_cast_facts(helper,parser,b,f'{ver}:{ck}:{rel}',original=False)
            need(json.dumps(actual,sort_keys=True)==json.dumps(c['class_facts'],sort_keys=True),f'{ver}:{ck}: class facts differ from dual parser/raw output')
            need(set(actual)=={CLASS+'.class'},f'{ver}:{ck}: output class closure contains missing/extra classes')
            need(member_surface(actual[CLASS+'.class'])==member_surface(base['facts'][key[0]]),f'{ver}:{ck}: ten-method/one-field member surface changed')
        else:
            need(not tree and c['class_facts'] is None,f'{ver}:{ck}: failed compile produced claimed class output')
            low=stderr.lower()
            if c['cell_key'][0]=='debug' and c['cell_key'][1] == 'bundle' and c['cell_key'][0]=='jadx':
                pass
    expected_comp={(tuple(c['cell_key']),leg) for c in d['source_cells'] for leg in ('javac8','javac23')}
    need(set(comp_by)==expected_comp,f'{ver}: 20-cell compiler grid mismatch')
    source_kind={tuple(c['cell_key']):c['kind'] for c in d['source_cells']}
    if ver=='v1':
        need(all(c['exit_code']!=0 for c in comp_by.values()) and len(d['runtime_rows'])==0 and len(d['wrong_root_rows'])==0,f'v1: failed compile incorrectly gained runtime rows')
        cats={'jarde_refused_body':0,'jadx_bad_cast':0}
        for (key,leg),c in comp_by.items():
            cmd=commands[c['command']]; err=compare.command_artifact(cmd,'stderr')
            if source_kind[key]=='jarde': need(b'jarde_refused_body' in err,f'v1:{key}:{leg}: refusal compiler error not preserved'); cats['jarde_refused_body']+=1
            else: need(b'Integer' in err and b'String' in err,f'v1:{key}:{leg}: JADX invalid cast compiler error not preserved'); cats['jadx_bad_cast']+=1
        need(cats=={'jarde_refused_body':16,'jadx_bad_cast':4},'v1 failure classes/counts differ')
        need(set(commands)=={d['driver_compile']['command'],*[c['command'] for c in d['compilations']]},'v1: generated commands unclassified or reused')
        return {'compile_attempts':20,'compile_successes':0,'compile_failures':20,'runtime_runs':0,'wrong_root_runs':0,'retained_failures':cats}
    # v2: Jarde full source succeeds for both compilers; JADX wrong-cast source remains invalid.
    failures={(tuple(k),leg) for (k,leg),c in comp_by.items() if c['exit_code']!=0}
    expected_fail={(('debug','bundle'),'javac8'),(('debug','bundle'),'javac23'),(('no-debug','bundle'),'javac8'),(('no-debug','bundle'),'javac23')}
    need(failures==expected_fail,f'v2: compile failure inventory differs from actual preserved JADX invalid-cast boundary: {failures}')
    for k in failures:
        err=compare.command_artifact(commands[comp_by[k]['command']],'stderr')
        need(b'Integer' in err and b'String' in err,f'v2:{k}: invalid String-to-Integer cast failure absent')
    successes={k for k,c in comp_by.items() if c['exit_code']==0}; need(len(successes)==16 and all(source_kind[k[0]]=='jarde' for k in successes), 'v2: expected 16 successful Jarde compile cells')
    oracle={}
    for (profile,vm),rows in base['runtime'].items(): oracle[f'{profile}/{vm}']=sem(rows)
    need(d['original_oracles']==oracle,f'v2: stored original oracles differ from independently parsed baseline stdout')
    runtimes={}; wrongs={}
    for row in d['runtime_rows']:
        key=tuple(row['cell_key']); ck=(key,row['compiler'],row['runtime']); need(ck not in runtimes,f'v2: duplicate runtime cell {ck}')
        comp=comp_by[(key,row['compiler'])]; cmd=commands[row['command']]; target=str(Path(comp['class_root']).resolve())
        check_command_roots(cmd,base['doc']['jdk_manifest']['tools'][row['runtime']]['java']['path'],driver,target,wrapper=str(wrapper_path))
        need(row['target_root']==target and row['application_classpath']==[driver],f'v2:{ck}: runtime target/classpath binding wrong')
        rows=check_rows(row,cmd,compare,f'v2:{ck}'); matches=sem(rows)==oracle[f'{key[0]}/{row["runtime"]}']
        need(matches and row.get('matches_original_profile_runtime') is True,f'v2:{ck}: successful generated source differs from exact original runtime oracle')
        runtimes[ck]=rows
    need(set(runtimes)=={(key,leg,vm) for key,leg in successes for vm in ('javac8','javac23')},'v2: runtime matrix does not exactly cover successful outputs on both VMs')
    for row in d['wrong_root_rows']:
        key=tuple(row['cell_key']); ck=(key,row['compiler']); need(ck not in wrongs and ck in successes,f'v2: duplicate/unexpected wrong-root cell')
        comp=comp_by[ck]; cmd=commands[row['command']]; target=str(Path(comp['class_root']).resolve()); empty=str((Path(d['output'])/'empty-classpath').resolve())
        check_command_roots(cmd,base['doc']['jdk_manifest']['tools']['javac23']['java']['path'],driver,target,empty,wrapper=str(wrapper_path))
        err=compare.command_artifact(cmd,'stderr'); out=compare.command_artifact(cmd,'stdout'); need(cmd['exit_code']==row['exit_code']==1 and row['rejected'] is True and b'wrong CodeSource:' in err,f'v2:{ck}: wrong CodeSource not rejected')
        need(row['stdout']==cmd['streams']['stdout'] and row['stderr']==cmd['streams']['stderr'],f'v2:{ck}: wrong-root raw pins differ')
        wrongs[ck]=row
    need(set(wrongs)==successes and len(runtimes)==32 and len(wrongs)==16,f'v2: expected 32 VM runs and 16 wrong-root checks')
    need(set(commands)=={1,*[c['command'] for c in d['compilations']],*[x['command'] for x in d['runtime_rows']],*[x['command'] for x in d['wrong_root_rows']]},'v2: unclassified/reused generated command')
    return {'compile_attempts':20,'compile_successes':16,'compile_failures':4,'runtime_runs':32,'runtime_cases':512,'wrong_root_runs':16,'retained_failures':{'jadx_invalid_string_to_integer_cast':4},'all_jarde_runtime_match':True}

def verify_supp(d,commands,ver,base,compare,parser,helper):
    need(d['schema']=='private-testnestedloops2-controls-javac8-boundary-supplement-v1' and len(d['commands'])==3,f'{ver}: supplement schema/grid mismatch')
    need(d['baseline_sha256_argument']==RECEIPT_SHA['base1' if ver=='v1' else 'base2'],f'{ver}: supplement baseline SHA mismatch')
    need(d['source_pins_before']==base['doc']['source_pins_before'],f'{ver}: supplement source closure differs from matching baseline')
    bp=Path(base['doc']['output'])/'execution.json'
    need(Path(d['baseline_receipt']['path']).resolve()==bp.resolve() and d['baseline_receipt']['sha256']==RECEIPT_SHA['base1' if ver=='v1' else 'base2'],f'{ver}: supplement not bound to baseline')
    fact,b=physical_target(compare,parser,d['physical_class_facts'],f'{ver}:javac8 boundary class',helper)
    signature_cast_facts(helper,parser,b,f'{ver}:javac8 boundary class')
    need(member_surface(fact)==member_surface(base['facts']['debug']),f'{ver}:supplement boundary member surface differs from original debug class')
    need(sorted((x['name'],x['descriptor'],x['access']) for x in d['physical_fields'])==sorted(tuple(x) for x in d['physical_class_facts']['fields']),f'{ver}: supplement field inventory mismatch')
    # Boundary compilation command is the actual recorded command 1 of its matching baseline.
    bc=d['boundary_command']; old=base['commands'][1]
    need(bc['argv']==old['argv'] and bc['exit_code']==old['exit_code']==0 and bc['label']==old['label'],f'{ver}: JDK8 boundary command is not the captured successful whole-source compile')
    need(Path(d['boundary_class_root']).resolve()==Path(base['doc']['output'])/'javac8-boundary/classes',f'{ver}: JDK8 boundary root differs from baseline capture')
    need(d['boundary_class']['path']==d['physical_class_facts']['path'] and d['boundary_class']['sha256']==d['physical_class_facts']['sha256'],f'{ver}: boundary class pins differ')
    oracles={vm:sem(base['runtime'][('debug',vm)]) for vm in ('javac8','javac23')}; need(d['baseline_debug_oracles']==oracles,f'{ver}: supplement oracles differ from original debug runtimes')
    need(len(d['runtime_rows'])==2,f'{ver}: supplement VM grid incomplete')
    wrapper_path,_=pin(base['doc']['runtime_wrapper'],f'{ver} supplement runtime wrapper')
    driver=str((Path(base['doc']['output'])/'driver-classes').resolve()); target=str(Path(d['boundary_class_root']).resolve()); runtime_seen=set()
    for row in d['runtime_rows']:
        vm=row['runtime']; need(vm in ('javac8','javac23') and vm not in runtime_seen,f'{ver}: duplicate/bad supplement VM'); runtime_seen.add(vm)
        cmd=commands[row['command']]; check_command_roots(cmd,base['doc']['jdk_manifest']['tools'][vm]['java']['path'],driver,target,wrapper=str(wrapper_path))
        rows=check_rows(row,cmd,compare,f'{ver}:supplement:{vm}')
        need(sem(rows)==oracles[vm] and row['matches_debug_oracle'] is True and row['target_root']==target and row['application_classpath']==[driver],f'{ver}:{vm}: javac8 boundary runtime differs from original debug oracle')
    need(runtime_seen=={'javac8','javac23'},f'{ver}: supplement missing runtime leg')
    wrong=d['wrong_root_control']; cmd=commands[wrong['command']]; empty=str((Path(d['output'])/'empty-classpath').resolve())
    check_command_roots(cmd,base['doc']['jdk_manifest']['tools']['javac23']['java']['path'],driver,target,empty,wrapper=str(wrapper_path))
    err=compare.command_artifact(cmd,'stderr'); need(cmd['exit_code']==wrong['exit_code']==1 and wrong['rejected'] is True and b'wrong CodeSource:' in err,f'{ver}: supplement wrong-root rejected incorrectly')
    need(wrong['stdout']==cmd['streams']['stdout'] and wrong['stderr']==cmd['streams']['stderr'],f'{ver}: supplement wrong-root raw pins differ')
    return {'runtime_runs':2,'runtime_cases':32,'wrong_root_runs':1,'physical_methods':len(fact['methods']),'physical_fields':len(fact['fields'])}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',required=True,type=Path)
    for opt in ('baseline-v1','baseline-v2','generated-v1','generated-v2','supplement-v1','supplement-v2'): ap.add_argument('--'+opt, type=Path)
    a=ap.parse_args()
    paths={
      'base1':a.baseline_v1 or BASE.as_posix().format(v='v1'), 'base2':a.baseline_v2 or BASE.as_posix().format(v='v2'),
      'gen1':a.generated_v1 or GEN.as_posix().format(v='v1'), 'gen2':a.generated_v2 or GEN.as_posix().format(v='v2'),
      'sup1':a.supplement_v1 or SUP.as_posix().format(v='v1'), 'sup2':a.supplement_v2 or SUP.as_posix().format(v='v2')}
    helper,compare,parser=import_helpers(); result={'status':'independent-controls-review','inputs':{},'baseline':{},'generated':{},'supplement':{},'limitations':[
      'v1 keeps the observed voidGetCastString whole-method quote; its missing/partial map is reported, never called successful.',
      'v1 generated full-source compile failures are retained: Jarde jarde_refused_body and JADX String-to-Integer cast.',
      'v2 JADX whole-source cast compile failures are retained; there are no JADX runtime claims.',
      'This checker does not execute JDK, CLI, Cargo, Git mutation, or network operations.']}
    docs={}
    for key,path in paths.items():
        d,commands=read_receipt(path,key,compare,parser,helper); docs[key]=(d,commands)
        result['inputs'][key]={'path':str(Path(path).resolve()),'sha256':RECEIPT_SHA[key],'commands':len(commands)}
    live=compare.source_closure(ROOT)
    need(not (ROOT/'target').exists() and all(d['source_pins_before']==live for d,_ in docs.values()),'live source closure/target differs from captures')
    for ver,key in [('v1','1'),('v2','2')]:
        base,bc=docs['base'+key]; gen,gc=docs['gen'+key]; supp,sc=docs['sup'+key]
        b=verify_base(base,bc,ver,compare,parser,helper); result['baseline'][ver]={'api_cells':8,'original_vm_cells':4,'original_cases':64,'wrong_root':1,'method_count':10,'field_count':1,'fallback_or_maps':b['api_summaries']}
        result['generated'][ver]=verify_generated(gen,gc,ver,b,compare,parser,helper)
        result['supplement'][ver]=verify_supp(supp,sc,ver,b,compare,parser,helper)
    a.out.parent.mkdir(parents=True,exist_ok=True); a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
