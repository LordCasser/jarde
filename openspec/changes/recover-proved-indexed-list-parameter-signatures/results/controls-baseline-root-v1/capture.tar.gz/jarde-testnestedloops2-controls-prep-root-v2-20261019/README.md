# NestedLoops2 generic controls v3 (private preparation)

This is a newly constructed control source variant based on controls prep v1, not a change to any Jarde or JADX generated output. The v3 collector uses a path relative to its own directory so the whole bundle can be copied without breaking the source pin. The only Java source edit replaces the void probe's explicit null-throw branch with `value.length()`. It keeps `List<String>`, the explicit `(String)` cast, and a dereference that still observes null and throws naturally. The driver and its sixteen case identities remain byte-identical, so runtime rows are still derived from execution.

The v1 source/collector and its actual generated-source compile failures remain frozen at `/private/tmp/jarde-testnestedloops2-controls-baseline-root-v1-20261019` and its paired generated receipt; do not overwrite them or describe them as passing. The prior v1 whole-method quoted fallback is an observed recovery boundary. This v3 source is a separate control to expose the other generic methods without altering generated source or repairing that unrelated recovery behavior. Its outcomes remain unknown until root executes the collectors.

`collect_controls.py` checks the new source pin before creating an output directory, captures original Java 8-target debug/no-debug class files, reflection observations on both VMs, Jarde API child/bundle default/all cells, and complete-source JADX output. `collect_controls_generated.py` copies full source cells unchanged, runs both compiler legs, and runs successful full outputs on both VMs with CodeSource controls. Failures and mismatches remain observations, not passes. No Java/JADX/Jarde/Cargo/Git/network command was executed while preparing this bundle.

Source SHA-256: `d27ec67a11e408edb4d1a19b7a9b9bc2f72bdb6528798425a107afd73d3f048c`. Driver SHA-256 (same as v1): `61acdf0020856bc35d62e528f76c0a29faaa692f3e5097f4029e8b1ac7209534`.

The collector source pin/path correction is the only v3 implementation change; v1 and v2 bundles are preserved. The source hash remains `d27ec67a11e408edb4d1a19b7a9b9bc2f72bdb6528798425a107afd73d3f048c`.
