# NestedLoops2 controls independent acceptance checker (prepared)

This bundle contains `review_controls.py`, a read-only checker for the two fixed controls baselines, their full-source generated matrices, and the JDK 8 boundary supplements. It has only been syntax-checked; it has not been run against any receipt. Root should review the schema assumptions and execute it.

Run from Python 3 with:

```sh
python3 -B /private/tmp/jarde-testnestedloops2-controls-acceptance-prep-luna-v1-20261019/review_controls.py \
  --baseline-v1 /private/tmp/jarde-testnestedloops2-controls-baseline-root-v1-20261019/execution.json \
  --baseline-v2 /private/tmp/jarde-testnestedloops2-controls-baseline-root-v2-20261019/execution.json \
  --generated-v1 /private/tmp/jarde-testnestedloops2-controls-generated-baseline-root-v1-20261019/execution.json \
  --generated-v2 /private/tmp/jarde-testnestedloops2-controls-generated-baseline-root-v2-20261019/execution.json \
  --supplement-v1 /private/tmp/jarde-testnestedloops2-controls-javac8-supplement-root-v1-20261019/execution.json \
  --supplement-v2 /private/tmp/jarde-testnestedloops2-controls-javac8-supplement-root-v2-20261019/execution.json \
  --out /private/tmp/jarde-testnestedloops2-controls-acceptance-prep-luna-v1-20261019/review.json
```

The checker pins every receipt and helper, reopens recorded streams and class bytes, compares the normalized JDK tool pins to each captured manifest's `legs[].jdk_tools`, verifies source/class closures and method/field surfaces, and reconstructs runtime cases from raw stdout. It preserves the actual failures: v1's quoted `voidGetCastString`, v1's Jarde refusal and invalid JADX cast, and v2's invalid JADX cast. It does not claim runtime results for failed compilations or treat a captured receipt as accepted before independent review.

Prepared checker SHA-256: `058d51f5ab542d9fd8d619399c3b253ff7474f8cb6621950a5407455b4b38605`.
