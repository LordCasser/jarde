# NestedLoops2 generic controls (private preparation)

This is a separate control family and does not add cases to the primary ten-row `TestNestedLoops2$TestCls` oracle. It uses the complete pinned control class `/private/tmp/jarde-testnestedloops2-controls-prep-luna-v1-20261019/src/jadx/tests/integration/loops/NestedLoops2GenericControls.java` and a reflection-only driver `/private/tmp/jarde-testnestedloops2-controls-prep-luna-v1-20261019/driver/NestedLoops2ControlsDriver.java`. Neither collector was executed; no javac/java, JADX, Jarde CLI, Cargo, Git, or network command ran for this bundle.

The driver invokes 16 ordered observations over the nine control methods: `voidGetCastString(List<String>)` with String, heap-polluted Integer, and null element; fixed-bound boolean normal/short inputs; primitive int/long loops; legal String-to-Integer cast normal and polluted values; parameter reassignment/alias escape; raw/wildcard mixed inputs; reference-result normal/empty; and null list. It records return, exception class, ordered size/get events, and whether the `escaped` field retained the original observed list. The 128-event cap is a driver-integrity guard checked after invocation, not an oracle outcome. Each target is loaded parentlessly and checked against its exact CodeSource root; wrong-root control is expected to exit nonzero, to be confirmed by actual execution.

`collect_controls.py` captures full source profiles, original runtime rows on both configured JVMs, Jarde default/all API cells for child and full class-bundle forms, and complete-source JADX output. `collect_controls_generated.py` consumes that receipt, byte-copies complete Jarde/JADX source cells, attempts both configured Java 8-target compiler legs for each cell, and runs only successful complete class trees on both JVMs with wrong-CodeSource controls. Compiler/runtime failures and semantic differences remain recorded; collectors use `captured-pending-independent-review`, never acceptance. They reuse the frozen source/JDK/CLI/JADX/guard/parser pins copied from the accepted primary prep.

Suggested invocation after root review, with fresh output directories and an explicit completed-receipt SHA:

```sh
python3 -B collect_controls.py --out /private/tmp/<fresh-controls-baseline>
python3 -B collect_controls_generated.py --baseline /private/tmp/<fresh-controls-baseline>/execution.json --baseline-sha256 <receipt-sha256> --out /private/tmp/<fresh-controls-generated>
```

Source/driver pins: control `b39f610887e560eb8c7631727e9ea2cf2510518e182f608f9b1caab9a54a42b1`, driver `61acdf0020856bc35d62e528f76c0a29faaa692f3e5097f4029e8b1ac7209534`. Collector pins: baseline `221f19930b750d9241e46181d8d4e4f054b23b5e51c507cb0739e2295fd3befa`, generated `d7e93b4ab5a3b29ddc7b539156b2b63bc5eadf695ab308203edf73590c11b196`. These are preparation commands, not actual test results.
