# javac 8 boundary runtime supplement (private preparation)

This script consumes the completed controls baseline at `/private/tmp/jarde-testnestedloops2-controls-baseline-root-v1-20261019/execution.json` (receipt SHA-256 `af878134ce2644435d4abfab675670e81090557df27f58a33cc93285d3deabe6`) and its recorded `javac8_full_source_boundary` output. It requires that compile to have succeeded, reopens the exact class bytes, validates the sole class, all ten physical method identities/Code arrays and sole private-static `escaped` List field, then runs the already compiled standalone driver against that existing class on both configured JVMs. Each 16-row output is compared with the baseline debug oracle for the same JVM. It also runs one wrong-CodeSource control.

It does not rebuild or alter the target, driver, source, or generated outputs. A boundary compile success is treated as success; the old major-55 harness failure belongs to the separate full upstream fixture and is not inferred here. Runtime mismatches and wrong-root failures remain visible in the pending receipt. The runner reuses the baseline-pinned default-stack guard and records raw streams, source closure, external artifact pins, and target absence.

This collector can also consume a later controls source variant because it derives the target byte pin from the supplied receipt while enforcing the same class/method/field contract. It was not executed; no Java or project toolchain ran.

```sh
python3 -B collect_boundary_supplement.py \
  --baseline /private/tmp/jarde-testnestedloops2-controls-baseline-root-v1-20261019/execution.json \
  --baseline-sha256 af878134ce2644435d4abfab675670e81090557df27f58a33cc93285d3deabe6 \
  --out /private/tmp/<fresh-boundary-supplement>
```

Collector SHA-256: `8bff0a7b737b67e181ed6d7bcebede5066fa9ad781c87c7427513766f8e3a317`.
