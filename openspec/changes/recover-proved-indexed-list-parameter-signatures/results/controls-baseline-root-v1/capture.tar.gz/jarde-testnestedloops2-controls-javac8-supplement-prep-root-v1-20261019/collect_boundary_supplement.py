#!/usr/bin/env python3
"""Observe the successful javac8 boundary class from a completed controls baseline; preparation only."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, shutil, sys
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASELINE_SCHEMA = 'private-testnestedloops2-generic-controls-baseline-v1'
INTERNAL = 'jadx/tests/integration/loops/NestedLoops2GenericControls'
DRIVER = 'NestedLoops2ControlsDriver'
METHODS = {('<init>','()V'),('voidGetCastString','(Ljava/util/List;)V'),
 ('fixedBoundBoolean','(Ljava/util/List;)Z'),('primitiveInt','(Ljava/util/List;)I'),
 ('primitiveLong','(Ljava/util/List;)J'),('legalWrongCast','(Ljava/util/List;)I'),
 ('reassignAndEscape','(Ljava/util/List;)I'),('rawList','(Ljava/util/List;)I'),
 ('wildcardList','(Ljava/util/List;)I'),('referenceResult','(Ljava/util/List;)Ljava/lang/Object;')}
EXPECTED_FIELD = ('escaped', 'Ljava/util/List;', 0x000a)
COMPARE_REL='openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD_REL='openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL='openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_REL='openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'


def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def load(path: Path, name: str):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot import {path}')
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def exact_pin(compare, record, label: str) -> Path:
    if not isinstance(record,dict) or not {'path','bytes','sha256'}<=record.keys(): raise RuntimeError(f'{label}: malformed pin')
    path=Path(record['path']).resolve(strict=True)
    if compare.pin(path)!=record: raise RuntimeError(f'{label}: pin changed: {path}')
    return path

def command_root(argv: list[str]) -> Path:
    try: return Path(argv[argv.index('-d')+1]).resolve(strict=True)
    except (ValueError,IndexError) as exc: raise RuntimeError('javac8 boundary command has no -d output') from exc

def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--baseline',type=Path,required=True)
    ap.add_argument('--baseline-sha256',required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--root',type=Path,default=ROOT)
    a=ap.parse_args()
    root=a.root.resolve(strict=True); bp=a.baseline.resolve(strict=True); out=a.out.resolve()
    if root!=ROOT.resolve(): raise SystemExit('workspace differs from pinned root')
    if not len(a.baseline_sha256)==64 or any(c not in '0123456789abcdef' for c in a.baseline_sha256): raise SystemExit('baseline SHA must be lowercase SHA-256')
    if sha(bp)!=a.baseline_sha256: raise SystemExit('baseline receipt SHA mismatch')
    if out.exists(): raise SystemExit(f'refusing existing output: {out}')
    if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('target must be absent')
    if shutil.disk_usage(root).free<5*1024**3: raise SystemExit('5 GiB free-space guard failed')
    compare_path=root/COMPARE_REL; guard_path=root/GUARD_REL; scanner_path=root/SCANNER_REL; jdk_path=root/JDK_REL
    for p,h,label in ((compare_path,COMPARE_SHA,'compare'),(guard_path,GUARD_SHA,'guard'),
                      (scanner_path,SCANNER_SHA,'scanner'),(jdk_path,JDK_SHA,'JDK manifest'),(PARSER,PARSER_SHA,'physical parser')):
        if sha(p)!=h: raise SystemExit(f'{label} source pin mismatch')
    compare=load(compare_path,'boundary_compare'); guard=load(guard_path,'boundary_guard')
    scanner=load(scanner_path,'boundary_scanner'); physical=load(PARSER,'boundary_physical_parser')
    jdks,jdk_record=compare.configured_jdks(jdk_path,JDK_SHA)
    baseline=json.loads(bp.read_text(encoding='utf-8'))
    if baseline.get('schema')!=BASELINE_SCHEMA or baseline.get('status')!='captured-pending-independent-review':
        raise SystemExit('controls baseline is not a completed pending-review receipt')
    if baseline.get('source_unchanged') is not True or baseline.get('target_absent') is not True:
        raise SystemExit('baseline source/target integrity gate failed')
    boundary=baseline.get('javac8_full_source_boundary')
    if not isinstance(boundary,dict) or boundary.get('exit_code')!=0:
        raise SystemExit('javac8 full-source boundary did not produce a successful class; no supplement grid is possible')
    commands={r['index']:r for r in baseline.get('commands',[])}
    bc=commands.get(boundary.get('command'))
    if bc is None or bc.get('exit_code')!=0 or bc.get('label')!='javac8-full-upstream-source-boundary':
        raise SystemExit('boundary receipt is not linked to a successful expected command')
    for row in commands.values():
        if row.get('guard_stop') is not None: raise SystemExit(f'baseline command stopped by guard: {row.get("label")}')
        compare.command_artifact(row,'stdout'); compare.command_artifact(row,'stderr')
    outroot=command_root(bc.get('argv',[]))
    expected_tree=boundary.get('class_tree')
    actual_tree={p.relative_to(outroot).as_posix():compare.pin(p) for p in sorted(outroot.rglob('*.class'))}
    if not isinstance(expected_tree,dict) or set(actual_tree)!={INTERNAL+'.class'}:
        raise SystemExit(f'javac8 boundary physical class tree differs: {sorted(actual_tree)}')
    expected_entry=expected_tree.get(INTERNAL+'.class')
    class_path=outroot/(INTERNAL+'.class')
    class_pin=compare.pin(class_path)
    if expected_entry is None or expected_entry.get('bytes')!=class_pin['bytes'] or expected_entry.get('sha256')!=class_pin['sha256']:
        raise SystemExit('javac8 boundary target class differs from saved class-tree pin')
    facts=compare.parse_class(class_path); raw_facts=physical.parse_class_file(class_path.read_bytes())
    if raw_facts['class_name']!=facts['class_name'] or raw_facts['major']!=facts['major'] or raw_facts['methods']!=facts['methods']:
        raise SystemExit('independent full method/Code parsers disagree')
    if facts['class_name']!=INTERNAL or facts['major']!=52: raise SystemExit('javac8 boundary class identity/major mismatch')
    if {(m['name'],m['descriptor']) for m in facts['methods']}!=METHODS: raise SystemExit('physical method inventory differs from the ten-method control contract')
    fields=raw_facts.get('fields',[])
    if [(f['name'],f['descriptor'],f['access']) for f in fields]!=[EXPECTED_FIELD]:
        raise SystemExit(f'physical field inventory differs: {[(f["name"],f["descriptor"],f["access"]) for f in fields]}')
    for m in facts['methods']:
        c=m.get('code')
        if c is None or c['code_length']<=0 or not c.get('bcis') or c['bcis'][0]!=0 or c['bcis'][-1]>=c['code_length']:
            raise SystemExit(f'invalid physical Code/BCI evidence: {m["name"]}{m["descriptor"]}')
    oracle_parser_path=Path('/private/tmp/jarde-testnestedloops2-controls-prep-luna-v1-20261019/collect_controls.py')
    if sha(oracle_parser_path)!='221f19930b750d9241e46181d8d4e4f054b23b5e51c507cb0739e2295fd3befa': raise SystemExit('oracle parser pin mismatch')
    base_mod=load(oracle_parser_path,'controls_oracle_parser')
    driver_records=baseline.get('driver_classes',[])
    driver_files=[exact_pin(compare,x,'pinned driver class') for x in driver_records]
    driver_root=driver_files[0].parent if driver_files else None
    expected_driver={'NestedLoops2ControlsDriver.class','NestedLoops2ControlsDriver$Probe.class',
                     'NestedLoops2ControlsDriver$RecordingList.class','NestedLoops2ControlsDriver$Observation.class'}
    if driver_root is None or {p.relative_to(driver_root).as_posix() for p in driver_root.rglob('*.class')}!=expected_driver:
        raise SystemExit('baseline standalone driver class tree differs')
    runtime_wrapper=exact_pin(compare,baseline.get('runtime_wrapper'),'copied runtime wrapper')
    expected_oracles={}
    for r in baseline.get('original_runtime',[]):
        if r.get('exit_code')!=0 or r.get('profile')!='debug' or r.get('runtime') not in ('javac8','javac23'):
            continue
        cmd=commands.get(r.get('command'))
        if cmd is None or cmd.get('exit_code')!=0: raise SystemExit('debug oracle command not successful')
        rows=base_mod.parse_oracle(compare.command_artifact(cmd,'stdout'))
        if rows!=r.get('rows'): raise SystemExit('debug oracle stored rows differ from raw stdout')
        expected_oracles[r['runtime']]=base_mod.oracle_projection(rows)
    if set(expected_oracles)!=set(('javac8','javac23')): raise SystemExit('debug original runtime oracle pair incomplete')
    source_before=compare.source_closure(root)
    if source_before!=baseline.get('source_pins_after'): raise SystemExit('repository source closure changed since baseline receipt')
    runtime_rows=baseline.get('original_runtime',[])
    used_raw=[Path(c['streams'][ch]['path']) for c in commands.values() for ch in ('stdout','stderr')]
    external_paths=[oracle_parser_path,bp,compare_path,guard_path,scanner_path,jdk_path,PARSER,class_path,runtime_wrapper,*driver_files,*used_raw] + [x for spec in jdks.values() for x in spec['tools'].values()]
    external_paths.extend(Path(x['path']) for x in (baseline.get('source'),baseline.get('source_copy'),baseline.get('control_source'),
        baseline.get('driver_source'),baseline.get('driver_copy'),baseline.get('cli'),baseline.get('jadx'),baseline.get('jadx_jar')) if isinstance(x,dict))
    external_paths=list(dict.fromkeys(Path(x).resolve(strict=True) for x in external_paths))
    external_before=[compare.pin(x) for x in external_paths]
    out.mkdir(parents=True); raw_dir=out/'raw'; raw_dir.mkdir(); empty=out/'empty-classpath'; empty.mkdir()
    guard.ROOT=root; guard.OUT=raw_dir; guard.target_bytes=lambda:scanner.target_bytes(root); guard.command_stream=compare.pin
    guard.expected_test_summaries=lambda index,data:None
    report={'schema':'private-testnestedloops2-controls-javac8-boundary-supplement-v1','status':'running',
            'root':str(root),'output':str(out),'baseline_receipt':compare.pin(bp),'baseline_sha256_argument':a.baseline_sha256,
            'boundary_command':bc,'boundary_class_root':str(outroot),'boundary_class':class_pin,
            'physical_class_facts':facts,'physical_fields':fields,'baseline_debug_oracles':expected_oracles,
            'source_pins_before':source_before,'external_pins_before':external_before,'commands':[],'runtime_rows':[],'wrong_root_control':None,
            'jdk_manifest':jdk_record,'compare':compare.pin(compare_path),'guard':compare.pin(guard_path),
            'scanner':compare.pin(scanner_path),'physical_parser':compare.pin(PARSER),
            'notes':['This supplement consumes, does not rebuild or modify, the already successful javac8 boundary class.',
                     'The original javac8 boundary result is recorded as a successful compile; it is not described as the old major-55 harness failure.',
                     'All sixteen runtime observations are compared with the original debug profile on the same JVM; mismatches remain visible.']}
    reportpath=out/'execution.json'; compare.write_json(reportpath,report); rows=report['commands']
    def run(argv,label,leg):
        if (root/'target').exists() or (root/'target').is_symlink(): raise RuntimeError('target appeared during supplement')
        env=compare.clean_env(dict(os.environ),jdks[leg]); env.update(guard.ENV_VALUES); env.pop('RUST_MIN_STACK',None)
        row=guard.run_command(len(rows)+1,[str(x) for x in argv],env); row['label']=label; row['tool_leg']=leg; rows.append(row)
        compare.write_json(reportpath,report)
        if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        return row
    def artifact(row,channel='stdout'): return compare.command_artifact(row,channel)
    try:
        for runtime in ('javac8','javac23'):
            rr=run([sys.executable,'-B',runtime_wrapper,'30',jdks[runtime]['tools']['java'],'-Xverify:all','-cp',driver_root,
                    DRIVER,str(outroot),str(outroot)],f'javac8-boundary-runtime-{runtime}',runtime)
            parsed=base_mod.parse_oracle(artifact(rr)) if rr.get('exit_code')==0 else []
            sem=base_mod.oracle_projection(parsed) if parsed else None
            report['runtime_rows'].append({'runtime':runtime,'command':rr['index'],'exit_code':rr['exit_code'],
                'target_root':str(outroot),'application_classpath':[str(driver_root)],
                'stdout':compare.pin(Path(rr['streams']['stdout']['path'])),'stderr':compare.pin(Path(rr['streams']['stderr']['path'])),
                'rows':parsed,'semantic_projection':sem,'matches_debug_oracle':rr.get('exit_code')==0 and sem==expected_oracles[runtime]})
            compare.write_json(reportpath,report)
        wrong=run([sys.executable,'-B',runtime_wrapper,'30',jdks['javac23']['tools']['java'],'-Xverify:all','-cp',driver_root,
                   DRIVER,str(outroot),str(empty)],'javac8-boundary-wrong-code-source','javac23')
        stderr=artifact(wrong,'stderr'); report['wrong_root_control']={'command':wrong['index'],'exit_code':wrong['exit_code'],
            'rejected':wrong.get('exit_code')!=0 and b'wrong CodeSource:' in stderr,'actual_target_root':str(outroot),
            'expected_wrong_root':str(empty),'stdout':compare.pin(Path(wrong['streams']['stdout']['path'])),
            'stderr':compare.pin(Path(wrong['streams']['stderr']['path']))}
        report['source_pins_after']=compare.source_closure(root)
        report['external_pins_after']=[compare.pin(x) for x in external_paths]
        report['source_unchanged']=report['source_pins_after']==source_before
        report['external_inputs_unchanged']=report['external_pins_after']==external_before
        report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
        report['counts_derived']={'commands':len(rows),'runtime_commands':len(report['runtime_rows']),
                                  'runtime_rows':sum(len(x['rows']) for x in report['runtime_rows']),
                                  'wrong_root_commands':1}
        if not report['source_unchanged'] or not report['external_inputs_unchanged'] or not report['target_absent']:
            raise RuntimeError('source/input/target integrity changed')
        report['status']='captured-pending-independent-review'
    except BaseException as exc:
        report['status']='failed'; report['error']=repr(exc); raise
    finally:
        report['source_pins_after_finally']=compare.source_closure(root)
        report['external_pins_after_finally']=[compare.pin(x) for x in external_paths]
        report['source_unchanged_finally']=report['source_pins_after_finally']==source_before
        report['external_inputs_unchanged_finally']=report['external_pins_after_finally']==external_before
        report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
        if not report['source_unchanged_finally'] or not report['external_inputs_unchanged_finally'] or not report['target_absent_finally']:
            report['status']='failed'; report['final_guard_error']='source/input closure or target state changed'
        report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(reportpath,report)
        shutil.copy2(__file__,out/'collector.py')
        print(json.dumps({'status':report['status'],'commands':len(rows),'runtime_rows':len(report['runtime_rows']),
                          'oracle_matches':sum(bool(x.get('matches_debug_oracle')) for x in report['runtime_rows']),
                          'wrong_root_rejected':bool((report.get('wrong_root_control') or {}).get('rejected'))}))
    return 0

if __name__=='__main__': raise SystemExit(main())
