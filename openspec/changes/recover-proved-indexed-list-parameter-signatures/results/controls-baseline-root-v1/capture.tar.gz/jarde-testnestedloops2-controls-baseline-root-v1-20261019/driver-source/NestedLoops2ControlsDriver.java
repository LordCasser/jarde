import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Parentless, reflection-only observations for NestedLoops2GenericControls. */
public final class NestedLoops2ControlsDriver {
    private static final String TARGET = "jadx.tests.integration.loops.NestedLoops2GenericControls";
    private static final int EVENT_LIMIT = 128;

    private static final class Probe {
        final String name, method;
        final Object[] values;
        final boolean nullList;
        Probe(String name, String method, Object[] values, boolean nullList) {
            this.name=name; this.method=method; this.values=values; this.nullList=nullList;
        }
    }

    private static final class RecordingList extends AbstractList<Object> {
        final List<Object> values = new ArrayList<Object>();
        final List<String> events = new ArrayList<String>();
        boolean eventLimitExceeded;
        RecordingList(Object[] initial) { values.addAll(Arrays.asList(initial)); }
        private void event(String value) {
            if (events.size() >= EVENT_LIMIT) {
                eventLimitExceeded = true;
                throw new AssertionError("observer event limit");
            }
            events.add(value);
        }
        @Override public int size() { event("size"); return values.size(); }
        @Override public Object get(int index) { event("get(" + index + ")"); return values.get(index); }
        String eventsText() { return String.join(",", events); }
    }

    private static final class Observation {
        final Object result;
        final Throwable failure;
        Observation(Object result, Throwable failure) { this.result=result; this.failure=failure; }
    }

    private static final Probe[] PROBES = {
        new Probe("void-string", "voidGetCastString", new Object[] {"a"}, false),
        new Probe("void-heap-pollution", "voidGetCastString", new Object[] {Integer.valueOf(7)}, false),
        new Probe("void-null-element", "voidGetCastString", new Object[] {null}, false),
        new Probe("fixed-bound", "fixedBoundBoolean", new Object[] {"a", "bc"}, false),
        new Probe("fixed-bound-short", "fixedBoundBoolean", new Object[] {"a"}, false),
        new Probe("primitive-int", "primitiveInt", new Object[] {"a", "bc"}, false),
        new Probe("primitive-int-pollution", "primitiveInt", new Object[] {Integer.valueOf(7)}, false),
        new Probe("primitive-long", "primitiveLong", new Object[] {"a", "bc"}, false),
        new Probe("wrong-cast-string", "legalWrongCast", new Object[] {"a"}, false),
        new Probe("wrong-cast-integer", "legalWrongCast", new Object[] {Integer.valueOf(7)}, false),
        new Probe("reassign-escape", "reassignAndEscape", new Object[] {"a", "bc"}, false),
        new Probe("raw-mixed", "rawList", new Object[] {"a", Integer.valueOf(7)}, false),
        new Probe("wildcard-mixed", "wildcardList", new Object[] {"a", Integer.valueOf(7)}, false),
        new Probe("reference-first", "referenceResult", new Object[] {"a"}, false),
        new Probe("reference-empty", "referenceResult", new Object[] {}, false),
        new Probe("null-list", "primitiveInt", new Object[] {}, true),
    };

    private static String codeSource(Class<?> target) throws Exception {
        CodeSource source=target.getProtectionDomain().getCodeSource();
        if (source==null || source.getLocation()==null) throw new IllegalStateException("target has no CodeSource");
        return Paths.get(source.getLocation().toURI()).toRealPath().toString();
    }

    private static Observation invoke(Method method, Object instance, List<?> input) throws Exception {
        try { return new Observation(method.invoke(instance, input), null); }
        catch (InvocationTargetException e) { return new Observation(null, e.getCause()); }
    }

    public static void main(String[] args) throws Exception {
        if (args.length!=2) throw new IllegalArgumentException("usage: NestedLoops2ControlsDriver actualRoot expectedRoot");
        String actual=Paths.get(args[0]).toRealPath().toString();
        String expected=Paths.get(args[1]).toRealPath().toString();
        URL url=Paths.get(actual).toRealPath().toUri().toURL();
        try (URLClassLoader loader=new URLClassLoader(new URL[] {url}, null)) {
            Class<?> target=Class.forName(TARGET, true, loader);
            if (target.getClassLoader()!=loader) throw new IllegalStateException("target did not load parentlessly");
            String loaded=codeSource(target);
            if (!loaded.equals(expected)) throw new IllegalStateException("wrong CodeSource: expected="+expected+" actual="+loaded);
            Field escapedField=target.getDeclaredField("escaped");
            escapedField.setAccessible(true);
            for (int i=0;i<PROBES.length;i++) {
                Probe probe=PROBES[i];
                RecordingList list=new RecordingList(probe.values);
                List<?> input=probe.nullList ? null : list;
                escapedField.set(null, null);
                Method method=target.getDeclaredMethod(probe.method, List.class);
                Observation observation=invoke(method, null, input);
                if (list.eventLimitExceeded) throw new AssertionError("observer event limit exceeded");
                boolean escapedInput=escapedField.get(null)==list;
                String exception=observation.failure==null ? "none" : observation.failure.getClass().getName();
                String result=observation.failure==null ? String.valueOf(observation.result) : "<none>";
                System.out.println("CASE index="+i+" name="+probe.name+" method="+probe.method+
                        " result="+result+" exception="+exception+" events="+list.eventsText()+
                        " escapedInput="+escapedInput);
            }
        }
    }
}
