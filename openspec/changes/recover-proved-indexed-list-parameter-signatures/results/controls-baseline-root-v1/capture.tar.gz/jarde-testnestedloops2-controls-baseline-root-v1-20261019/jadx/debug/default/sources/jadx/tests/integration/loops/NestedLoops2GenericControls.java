package jadx.tests.integration.loops;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: debug-full-classes.jar:jadx/tests/integration/loops/NestedLoops2GenericControls.class */
public final class NestedLoops2GenericControls {
    private static List<?> escaped;

    private NestedLoops2GenericControls() {
    }

    public static void voidGetCastString(List<String> values) {
        for (int i = 0; i < values.size(); i++) {
            String value = values.get(i);
            if (value == null) {
                throw new IllegalStateException("null value");
            }
        }
    }

    public static boolean fixedBoundBoolean(List<String> values) {
        boolean seen = false;
        for (int i = 0; i < 2; i++) {
            String value = values.get(i);
            seen |= value.length() > 0;
        }
        return seen;
    }

    public static int primitiveInt(List<String> values) {
        int result = 0;
        for (int i = 0; i < values.size(); i++) {
            result += values.get(i).length();
        }
        return result;
    }

    public static long primitiveLong(List<String> values) {
        long result = 0;
        for (int i = 0; i < values.size(); i++) {
            result += (long) values.get(i).length();
        }
        return result;
    }

    public static int legalWrongCast(List<String> values) {
        int result = 0;
        for (int i = 0; i < values.size(); i++) {
            Integer value = (Integer) values.get(i);
            result += value.intValue();
        }
        return result;
    }

    public static int reassignAndEscape(List<String> values) {
        escaped = values;
        List<String> values2 = new ArrayList<>(values);
        int result = 0;
        for (int i = 0; i < values2.size(); i++) {
            result += values2.get(i).length();
        }
        return result;
    }

    public static int rawList(List values) {
        int result = 0;
        for (int i = 0; i < values.size(); i++) {
            result += String.valueOf(values.get(i)).length();
        }
        return result;
    }

    public static int wildcardList(List<?> values) {
        int result = 0;
        for (int i = 0; i < values.size(); i++) {
            result += String.valueOf(values.get(i)).length();
        }
        return result;
    }

    public static Object referenceResult(List<String> values) {
        return values.get(0);
    }
}
