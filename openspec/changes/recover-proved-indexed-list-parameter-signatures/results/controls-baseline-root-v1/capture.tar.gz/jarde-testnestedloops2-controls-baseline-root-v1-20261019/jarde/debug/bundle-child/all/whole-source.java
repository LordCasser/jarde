// jarde: presentation of `jadx/tests/integration/loops/NestedLoops2GenericControls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public final class NestedLoops2GenericControls extends java.lang.Object {
    // jarde: field Signature projection refused for `escapedLjava/util/List;`: unsupported (field_generic_write_source_unproved): writer reassignAndEscape(Ljava/util/List;)I@3 has no closed SSA source
    private static java.util.List escaped;

    private NestedLoops2GenericControls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.NestedLoops2GenericControls`, member flags 0x0002
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    // jarde: generic Signature projection refused for `voidGetCastString(Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): method body or no-body declaration has no complete source proof
    public static void voidGetCastString(java.util.List values) {
        // jarde: not recovered: the recovery run for `voidGetCastString(Ljava/util/List;)V` produced no statement (explanation only); the artifact's own comment lines are below
        // @method voidGetCastString(Ljava/util/List;)V
        // @declaration a static method of `jadx.tests.integration.loops.NestedLoops2GenericControls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 2 12 27 37 43
        // the quoted block at BCI 27 ends in a control-flow exit at BCI 36 (a return, a throw, or a transfer whose destination the presented structure does not own), the presented structure reaches that quote, and the body without it would still compile and silently change what the method does; the whole method is quoted
        jarde_refused_body();
    }

    // jarde: generic Signature projection refused for `fixedBoundBoolean(Ljava/util/List;)Z`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static boolean fixedBoundBoolean(java.util.List values) {
        // @method fixedBoundBoolean(Ljava/util/List;)Z
        // @declaration a static method of `jadx.tests.integration.loops.NestedLoops2GenericControls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int seen;
        int i;
        seen = 0;
        i = 0;
        while (i < 2) {
            java.lang.String value = (java.lang.String) values.get(i);
            seen = seen | (value.length() > 0 ? 1 : 0);
            i = i + 1;
        }
        return seen % 2 != 0;
    }

    // jarde: generic Signature projection refused for `primitiveInt(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static int primitiveInt(java.util.List values) {
        // @method primitiveInt(Ljava/util/List;)I
        // @declaration a static method of `jadx.tests.integration.loops.NestedLoops2GenericControls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int result;
        int i;
        result = 0;
        for (i = 0; i < values.size(); i = i + 1) {
            result = result + ((java.lang.String) values.get(i)).length();
        }
        return result;
    }

    // jarde: generic Signature projection refused for `primitiveLong(Ljava/util/List;)J`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static long primitiveLong(java.util.List values) {
        // @method primitiveLong(Ljava/util/List;)J
        // @declaration a static method of `jadx.tests.integration.loops.NestedLoops2GenericControls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        long result;
        int i;
        result = 0L;
        for (i = 0; i < values.size(); i = i + 1) {
            result = result + (long) ((java.lang.String) values.get(i)).length();
        }
        return result;
    }

    // jarde: generic Signature projection refused for `legalWrongCast(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static int legalWrongCast(java.util.List values) {
        // @method legalWrongCast(Ljava/util/List;)I
        // @declaration a static method of `jadx.tests.integration.loops.NestedLoops2GenericControls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int result;
        int i;
        result = 0;
        for (i = 0; i < values.size(); i = i + 1) {
            java.lang.Integer value = (java.lang.Integer) values.get(i);
            result = result + value.intValue();
        }
        return result;
    }

    // jarde: generic Signature projection refused for `reassignAndEscape(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static int reassignAndEscape(java.util.List values) {
        // @method reassignAndEscape(Ljava/util/List;)I
        // @declaration a static method of `jadx.tests.integration.loops.NestedLoops2GenericControls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int result;
        int i;
        java.util.List alias = values;
        jadx.tests.integration.loops.NestedLoops2GenericControls.escaped = alias;
        values = new java.util.ArrayList((java.util.Collection) values);
        result = 0;
        for (i = 0; i < values.size(); i = i + 1) {
            result = result + ((java.lang.String) values.get(i)).length();
        }
        return result;
    }

    public static int rawList(java.util.List values) {
        // @method rawList(Ljava/util/List;)I
        // @declaration a static method of `jadx.tests.integration.loops.NestedLoops2GenericControls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int result;
        int i;
        result = 0;
        for (i = 0; i < values.size(); i = i + 1) {
            result = result + java.lang.String.valueOf((java.lang.Object) values.get(i)).length();
        }
        return result;
    }

    // jarde: generic Signature projection refused for `wildcardList(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static int wildcardList(java.util.List values) {
        // @method wildcardList(Ljava/util/List;)I
        // @declaration a static method of `jadx.tests.integration.loops.NestedLoops2GenericControls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        int result;
        int i;
        result = 0;
        for (i = 0; i < values.size(); i = i + 1) {
            result = result + java.lang.String.valueOf((java.lang.Object) values.get(i)).length();
        }
        return result;
    }

    // jarde: generic Signature projection refused for `referenceResult(Ljava/util/List;)Ljava/lang/Object;`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static java.lang.Object referenceResult(java.util.List values) {
        // @method referenceResult(Ljava/util/List;)Ljava/lang/Object;
        // @declaration a static method of `jadx.tests.integration.loops.NestedLoops2GenericControls`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        return values.get(0);
    }
}
