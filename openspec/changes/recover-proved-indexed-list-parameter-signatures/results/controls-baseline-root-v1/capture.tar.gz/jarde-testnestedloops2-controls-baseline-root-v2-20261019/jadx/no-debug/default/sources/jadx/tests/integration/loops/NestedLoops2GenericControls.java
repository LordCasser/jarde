package jadx.tests.integration.loops;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: no-debug-full-classes.jar:jadx/tests/integration/loops/NestedLoops2GenericControls.class */
public final class NestedLoops2GenericControls {
    private static List<?> escaped;

    private NestedLoops2GenericControls() {
    }

    public static void voidGetCastString(List<String> list) {
        for (int i = 0; i < list.size(); i++) {
            list.get(i).length();
        }
    }

    public static boolean fixedBoundBoolean(List<String> list) {
        boolean z = false;
        for (int i = 0; i < 2; i++) {
            z |= list.get(i).length() > 0;
        }
        return z;
    }

    public static int primitiveInt(List<String> list) {
        int length = 0;
        for (int i = 0; i < list.size(); i++) {
            length += list.get(i).length();
        }
        return length;
    }

    public static long primitiveLong(List<String> list) {
        long length = 0;
        for (int i = 0; i < list.size(); i++) {
            length += (long) list.get(i).length();
        }
        return length;
    }

    public static int legalWrongCast(List<String> list) {
        int iIntValue = 0;
        for (int i = 0; i < list.size(); i++) {
            iIntValue += ((Integer) list.get(i)).intValue();
        }
        return iIntValue;
    }

    public static int reassignAndEscape(List<String> list) {
        escaped = list;
        ArrayList arrayList = new ArrayList(list);
        int length = 0;
        for (int i = 0; i < arrayList.size(); i++) {
            length += ((String) arrayList.get(i)).length();
        }
        return length;
    }

    public static int rawList(List list) {
        int length = 0;
        for (int i = 0; i < list.size(); i++) {
            length += String.valueOf(list.get(i)).length();
        }
        return length;
    }

    public static int wildcardList(List<?> list) {
        int length = 0;
        for (int i = 0; i < list.size(); i++) {
            length += String.valueOf(list.get(i)).length();
        }
        return length;
    }

    public static Object referenceResult(List<String> list) {
        return list.get(0);
    }
}
