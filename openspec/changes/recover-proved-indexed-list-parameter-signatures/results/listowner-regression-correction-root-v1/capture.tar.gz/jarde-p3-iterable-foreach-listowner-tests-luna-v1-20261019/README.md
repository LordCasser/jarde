# listOwner assertion update

This private test-only patch is based on `tests/p3_iterable_foreach.rs` SHA-256 `edb0255845558529aac999d974614579f770eb134dad70f1461c90b729d92af3`.

The `listOwner` method now expects its recovered `List<String>` parameter and `int` result declaration to remain exact while the loop is presented as a typed `String` foreach. The assertions intentionally do not bind the foreach variable name, and ensure the explicit cast and iterator calls are gone. `collectionOwner` retains the Object foreach plus explicit String cast assertions. The `twoNext` and `iteratorEscapes` refusal checks and the complete recompilation/runtime comparison remain unchanged.

No Cargo, JDK, CLI, Git mutation, or network command was run.

Edited file SHA-256: `449e7efed76030cf8dcd6376b3c1c5f93e3a820fb2a5e5817cb1f41f5418f717`.
Patch SHA-256: `14b84798ad5ee5fec98cf243d1fd67d6128d21ec28294bb1519d10cfb1b49449`.
