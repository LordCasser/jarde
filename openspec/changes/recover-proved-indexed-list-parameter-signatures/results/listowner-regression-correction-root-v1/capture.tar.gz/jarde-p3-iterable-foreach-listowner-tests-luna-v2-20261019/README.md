# listOwner typed projection regression assertions

This private two-file test patch is based on:

- `tests/p3_iterable_foreach.rs` SHA-256 `edb0255845558529aac999d974614579f770eb134dad70f1461c90b729d92af3`
- `tests/fixtures/p3-iterable-foreach/IterableBoundaryRunner.java` SHA-256 `299c5b9cc7a78238c46531b5a539c5139ff73d31be55ed10a1649c18ad3444d1`

For `listOwner`, the test checks an `int listOwner(java.util.List<java.lang.String>...)` header and separately checks that the header closes with `)`. It does not bind the debug-dependent argument name. It also expects a typed `String` foreach with no explicit cast or iterator calls. `collectionOwner` keeps its Object foreach plus String cast assertions; `twoNext` and `iteratorEscapes` remain refusal controls.

The runner now calls `listOwner` with nonempty, empty, and null-containing lists. The test requires the original output to include `list=3`, `listEmpty=0`, and `listNull=NullPointerException`, then compares complete original and recovered execution output. Existing branches and compile/runtime comparisons remain.

No Cargo, JDK, CLI, Git mutation, or network command was run.

Result SHA-256 values:
- `tests/p3_iterable_foreach.rs`: `07f9cae195c6f3f2743832ba7f3bee69fb3d4aa4ec8c1481acde7c407493b9ed`
- `tests/fixtures/p3-iterable-foreach/IterableBoundaryRunner.java`: `0402ae6c2c4185933cbd3290645ddd5d02ef6896a77e81caa153892ed586a739`
- `changes.patch`: `5ad03a761be4a3e1d44bace3a4d5939857db6421b787c0c7cabddbdb0cfdf9f8`
