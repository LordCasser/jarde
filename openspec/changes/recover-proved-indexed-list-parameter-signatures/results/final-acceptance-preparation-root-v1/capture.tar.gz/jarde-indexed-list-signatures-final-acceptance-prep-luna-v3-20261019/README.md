# Indexed-list-signatures final acceptance preparation v3

Prepared privately from the frozen accepted own-CI verifier and one-seed native acceptance. No Cargo, JDK, Jarde/JADX CLI, Git mutation, or network action was run. This bundle is not a test result or product acceptance.

The CI collector and verifier preserve their prior checks and all five prior fixture files. They add `tests/p3_nested_loop_side_exits.rs` to the exact source pin inventory (14 source paths total). It also pins the new complete `tests/fixtures/java8/indexed-list-parameters` root (README, Java source, debug class, and no-debug class), preserving the prior five fixtures for a total of nine. The verifier still requires the complete 385-target inventory as derived from the actual CI receipt and compares both official workspace seeds. The historical accepted receipt had 385 targets, but this bundle does not hardcode a new run's target or passing-test totals.

The verifier's inherited 63 gates remain unchanged. Supply the two previously accepted object-argument gates plus these seven exact current identities through repeated `--extra-critical` arguments; the verifier derives its gate total from that list:

- `jarde_java=report::exact_cast_call_batch_tests::iterative_batch_proves_multiple_get_cast_children_and_rejects_mutations`
- `jarde=facade::generic_list_foreach_binding_slot_closed_tests::generic_list_indexed_get_keeps_its_exact_single_cast_use_and_ast_child`
- `jarde=class_source::tests::complete_body_primitive_result_requires_exact_signature_and_descriptor_type`
- `jarde_java=report::exact_cast_call_batch_tests::iterative_batch_propagates_budget_and_cancellation_stops`
- `jarde_java=report::generic_void_parameter_census_tests::invoke_receiver_census_uses_consumed_stack_depth_not_stack_zero`
- `p3_nested_loop_side_exits=indexed_list_parameter_signatures_require_exact_direct_get_cast_evidence`
- `p3_nested_loop_side_exits=indexed_list_parameter_primitive_result_must_match_signature_exactly`

The official log ZIP is captured after collection by `collect-official-logs.py`. Its `step-log-supplement.json` records the exact `gh api repos/LordCasser/jarde/actions/runs/<run-id>/logs` argv, raw stdout/stderr paths, byte counts, and SHA256 values, plus pins for `collection.json` and `run.json`; the verifier checks those bindings. The verifier requires every independent per-step ZIP member. If one is absent, it rejects the archive rather than reconstructing it from the aggregate member.

The native wrapper inherits the accepted 18 exact gates, retains the two historical object-argument gates, and adds those seven identities. It derives the checked gate total from the arrays, rejects collisions, pins seed `5350648285461741569`, and delegates complete target/Running/harness/resource/source validation to the frozen workspace checker. It does not hardcode target count or workspace pass count.

## Prepared command forms

Collection requires actual values only after the final product and broad CLI receipt exist:

```sh
python3 collect-own-ci.py <fresh-evidence-dir> <CI-run-id> <full-product-sha> <final-cli-sha256>
python3 collect-official-logs.py <fresh-evidence-dir>
python3 verify-own-ci.py <fresh-evidence-dir> --product-sha <full-product-sha> --cli-sha256 <final-cli-sha256> \
  --extra-critical 'jarde=facade::generic_list_foreach_binding_slot_closed_tests::optional_remove_argument_break_leaves_required_list_proof_and_equals_edit' \
  --extra-critical 'jarde=facade::generic_list_foreach_binding_slot_closed_tests::unmatched_optional_equals_key_does_not_hide_valid_calls' \
  --extra-critical 'jarde_java=report::exact_cast_call_batch_tests::iterative_batch_proves_multiple_get_cast_children_and_rejects_mutations' \
  --extra-critical 'jarde=facade::generic_list_foreach_binding_slot_closed_tests::generic_list_indexed_get_keeps_its_exact_single_cast_use_and_ast_child' \
  --extra-critical 'jarde=class_source::tests::complete_body_primitive_result_requires_exact_signature_and_descriptor_type' \
  --extra-critical 'jarde_java=report::exact_cast_call_batch_tests::iterative_batch_propagates_budget_and_cancellation_stops' \
  --extra-critical 'p3_nested_loop_side_exits=indexed_list_parameter_signatures_require_exact_direct_get_cast_evidence' \
  --extra-critical 'p3_nested_loop_side_exits=indexed_list_parameter_primitive_result_must_match_signature_exactly'
python3 verify-native.py <native-execution.json> --out <native-review.json>
python3 bind_product_one.py --product <actual-final-HEAD> --build <final-broad-execution.json> --native <native-execution.json> --acceptance <native-review.json> --out <product-binding.json>
```

Run the binder only with the final committed HEAD and matching broad/native receipts. `bind_product_one.py` is copied byte-for-byte from the accepted v2 binder; its own final HEAD, CLI, native receipt, and source pin checks remain active. Historical object-argument receipt/review and old CI acceptance are reference provenance only, not evidence for the new product.

`acceptance-argv.json` and `gates.json` record the exact command templates and gate identities. `verify-own-ci.py.diff` shows the v3 strict archive binding and no-aggregate fallback. The v2 source and fixture inventory changes are preserved in this bundle. `verify-native.py` is a narrow extension of the previously accepted one-seed wrapper. The 385 target baseline is a cross-check against actual future evidence, not an expected pass count.


V2 adds only the new indexed-list controls fixture root to both collector and verifier inventories; the test and gate inventories are unchanged from v1. `collect-own-ci.py.diff` and `verify-own-ci.py.diff` show those narrow inventory additions. No collection or acceptance command was run.


V3 adds the consumed-stack-depth census gate and requires an independently captured, run-bound official per-step log ZIP. It removes the aggregate fallback from this verifier. Scripts are prepared only; run them only after current native, product, and CI evidence is available.
