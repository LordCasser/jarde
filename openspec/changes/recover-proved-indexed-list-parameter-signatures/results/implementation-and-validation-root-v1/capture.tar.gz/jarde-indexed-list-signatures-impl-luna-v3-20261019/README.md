# Indexed-list parameter receiver census v3

This private incremental patch is based on the current shared `crates/jarde-java/src/report.rs` SHA-256 `5e693e0735b634307dcf751ac53d8e5d2683210899a069d283a98a28fe866eea`.

The census previously accepted a parameter load as an invoke receiver only when the invoke read that value from `Stack(0)`. `Slot::Stack` is measured from the bottom of the live operand stack. In `voidGetCastString`, the loop index remains below the `values.size()` operands, so `size()` consumes its List receiver from `Stack(1)` and was omitted. The patch uses the existing physical-opcode/`Operation::Invoke` kind check, parses the target method descriptor, requires exactly the consumed instance operands, and selects the unique lowest stack depth as receiver. This mirrors the existing `scan_member_uses` receiver ordering and rejects malformed/non-closed reads. A load that appears only in an invoke argument cannot equal the selected receiver.

The new report unit test uses the frozen debug fixture `tests/fixtures/java8/indexed-list-parameters/debug/NestedLoops2GenericControls.class`: it asserts the `size()` receiver is at nonzero depth and that a distinct `get()` argument is not selected as receiver. It tests the receiver-selection helper directly; it is not a separate legal-JVM acceptance run.

All new work is budgeted before traversal/allocation: poll and charge descriptor/read identity work, then charge the depth-set allocation. No compiler, Cargo, JDK, Jarde/JADX CLI, or runtime tests were run. Root should apply and run the focused gates.

Patch: `changes.patch` (SHA-256 `8a123bd73c7c28b732575b211bfe329817ddc63ca6a0c7651178f92681dbf9b3`). Private edited file SHA-256: `296d25887ee1cb156de242ac29068d120df3449f0ffa711253426243694d7eae`.
