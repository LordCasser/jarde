# Private implementation v2: proved indexed `List` parameter signatures

This is a review-only private patch for OpenSpec change `recover-proved-indexed-list-parameter-signatures`, tasks 2.1–2.2. It is diffed against the current shared source SHA pins in `pins.json`; no shared files were edited.

The patch changes the complete-body candidate to carry its physical return type, while keeping method-local type-variable declarations void-only. For ordinary parameterized declarations, primitive `Signature` results must match both the exact primitive `Type` variant and the already parsed physical descriptor spelling. List formals are selected from the parsed parameter types, not descriptor substring search.

For `List.get(I)Object`, the existing List proof now verifies the result’s unreplaced single-use SSA fact, requires the physical `checkcast` input to equal that full SSA fact, and batches all get/cast checks into one iterative retained-AST walk. The AST walk requires the exact direct `Cast(E, Call(get))` child, unique cast/call anchors, exact retained target and `0xc0` opcode, direct cast provenance, and no foreign primary or derived method identity. The cast remains in source. This remains a signature-use proof only; it does not infer `E` from the get call.

The report crate has focused AST mutation tests covering multiple sites, duplicate/missing cast and call nodes, wrong target/type/opcode/provenance, foreign primary and derived origins, and budget/cancellation stops. Facade tests mutate same-run facts and keep the pre-existing optional-miss and transaction stop coverage. Public tests use the frozen debug/no-debug controls and compare default, pure essential, mapped essential, and all evidence requests; pure essential does not request a source map.

Static review only. I did not run Cargo, rustfmt, JDK, Jarde/JADX CLI, Git mutation, or network commands. Root should run the focused `generic_list_` tests, `structured_list_generic_bodies`, the report query filter, and the existing CLI/broad gates before applying this patch. The private controls are byte-identical to the accepted shared fixtures listed in `pins.json`.

`changes.patch` is the unified patch. `repo/` contains the full edited copies. SHA-256 values are in `pins.json`.
