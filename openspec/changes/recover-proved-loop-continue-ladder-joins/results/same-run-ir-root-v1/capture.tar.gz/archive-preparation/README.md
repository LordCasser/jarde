# ContinueInLoop same-run IR probe archive preparation

This private preparation adapts the accepted EntrySplit same-run IR probe archive tool to the six explicitly requested ContinueInLoop evidence roots. It does not run the packer or any Cargo/JDK/CLI/network command and does not write to the shared repository.

The accepted probe root is `/private/tmp/jarde-continueinloop-ir-probe-root-v1-20261019`. Its `root-review.json` SHA-256 is `21ae81c575cd7b97ad7bf7baa84ce4626c58db50ac86397b39ed35630275eee2`; the marker binds `execution.json` SHA-256 `8e4f750d07a9823ab4fe525e80a5802f264ee088f7469ce9dd29792b6d348c4d`. The packer checks both pins and the accepted status `root_accepted_same_run_ir_and_first_internal_collision`. The raw receipt remains `commands_passed_pending_independent_acceptance`; the separate marker carries the accepted review.

The archive contains complete trees for the probe prep, root prep, accepted probe, existing-join probe, and both architecture-audit versions. File and directory entries are pinned by `pins.json`; symlinks, cache/build entries, unexpected source changes, and missing members fail closed. Empty directories and original modes are retained. The archive is not produced by this preparation.

The proposed destination is `/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-proved-loop-continue-ladder-joins/results/same-run-ir-root-v1/capture.tar.gz`. A future root invocation may use the default or pass that exact path with `--out`. The packer refuses an existing archive or inventory sidecar, writes deterministic gzip/tar, reopens each member, and checks bytes, SHA-256, mode, type, and the embedded inventory.

The adapted tool is based on `/private/tmp/jarde-entry-split-ir-probe-durable-pack-prep-luna-v2-20261019/pack.py`, SHA-256 `75dcdbb3156cef33f038e240e6d9647ae4e822ceff767ab83d2c23db7ba33cfa`. No CLI, compiler, JDK, or dependency payload is copied.
