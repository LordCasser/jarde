# ContinueInLoop real-IR probe (prepared only)

This is a private, temporary unit-test probe for the accepted original `TestContinueInLoop$TestCls` class. No shared source or fixture was changed, and the probe was not compiled or run.

The frozen baseline is `/private/tmp/jarde-testcontinueinloop-baseline-root-v1-20261019/execution.json` (SHA-256 `d33084ce268c7d3c49a056f120619d7e1786b5f438d5bcf8b30d66911ea2c0ec`), independently accepted by `root-review.json` (SHA-256 `3c53bac442e35918b04f30da789c26e06dfb3a2ab3f7d65ef24905f7214d62c1`). The Java source is the unchanged upstream `TestContinueInLoop.java`, 812 bytes, SHA-256 `9013fc2ce9ac89c4e8967ddef39ead5f66dfc8c692f6529583bb75d96c38d8ec`.

The copied inputs are the exact accepted target class bytes:

- debug: 752 bytes, SHA-256 `57adb18f7c6398e86daa90be1ffd2576ac47662e973ab8db02e164591aac7ed3`, report identity BLAKE3 `7e744fa8bc38b2017045b6c75d7edf803b8ff76ec146106b7a8d5b55dc2ff770`.
- no-debug: 438 bytes, SHA-256 `1f2dea241154efa5ad132904cff22ad1290890c189f443bbd528a98023ddaf85`, report identity BLAKE3 `a0ef636ae3e621a37ff8bd202592dad8baca63b9e74659229eb4c426dd1895fd`.

The probe analyzes physical method `test([II)V` from those exact class bytes with the existing `analyze_method_ir` path. It dumps canonical blocks and all edge kinds; each natural-loop header, members, latches, irreducibility and header post-dominator; branch successors and immediate post-dominators; the counter slot inferred only from a physical `iinc` inside a natural loop, with that slot's same-run SSA reads, writes, values and phis; and the full existing `recover` result including any `ForHeader` and fallback reason. It also prints the existing `prove_for_header` result for the real loop, using an empty terminal-return set as an explicitly isolated probe input; the complete `recover` result remains authoritative for the actual region walk. This keeps the disputed branch joins visible next to the real loop and SSA facts.

The separate accepted JRE join diagnostic receipt is `/private/tmp/jarde-testcontinueinloop-existing-join-probe-root-v1-20261019/execution.json` (SHA-256 `dd17d5da8dda04a185fabb159a99c9eae399aa35d3ff223eae0b7b234994de15`); its raw stdout SHA-256 is `24817cb913af98e240cdadbeea99d617bc4e8e8191450c3e43212fec6ae36bea`. It recorded branch 8 choosing join 56 for arms 19/29 with boundary 2; branch 42 choosing join 50 for arms 47/50 with boundary 56; and branch 29 choosing join 56 for arms 35/50 with boundary 56. Those are already observed diagnostic facts, not predictions of this new probe.

`module.patch` adds one `#[cfg(test)]` module declaration after `statementful_loop_header_tests` in `crates/jarde-java/src/region.rs`. The temporary test file refers to the private copied class files by absolute path so the exact input cannot be silently replaced by another checked-in fixture. Root can inspect or apply this patch for one guarded probe, then discard it. No production code, public interface, fixture inventory, or implementation is proposed here.

The test uses APIs confirmed in existing tests: `analyze_method_ir` / `MethodAnalysisRequest` (`loop_arm_return_tests.rs`), `NormalFlowView::build`, `loop_entered_at`, `latches`, `immediate_post_dominator`, `SsaTable::{block,phis,value}`, instruction `reads`/`writes`, and `recover` (`loop_arm_return_tests.rs` and `protected_prefix_loop_tests.rs`). This is static source inspection only; compiler acceptance remains unverified.
