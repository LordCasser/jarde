# TestContinueInLoop control-flow audit

**Scope.** Static architecture review only. No source or OpenSpec changes; no Rust, Java, Jarde CLI, Git, or network execution. The original-baseline receipt is root-accepted, but this memo does not claim a fix or a new generated-output result.

## Accepted evidence and exact fixture

The accepted baseline is `root-review.json` status `root_accepted_original_baseline_with_explicit_whole_method_refusal_gap`; it binds the receipt SHA below. It contains 46 commands, 32 original VM observations, 16 full Jarde-source compile refusals, zero Jarde target executions, 2 JADX JDK 23 full-source compile successes, 2 JDK 8 framework compile failures, and 32 JADX VM observations. JADX's 32 successful observations match the original. Jarde's eight API cells (debug/no-debug × child/bundle-child × default/all) report the constructor as structured and `test([II)V` as a whole-method fallback with `jre_region_arms_do_not_meet` and `jre_region_loop_shape`; its 16 whole-source compile attempts fail. Those are observed results, not a claim that any candidate patch fixes them.

The upstream source is the complete `TestContinueInLoop.java` (812 bytes, SHA in `pins.json`). Its inner `TestCls` has public `int f`, a public constructor, and `test(int[] a, int b)`; there is no `check()` method. The test mutates the selected array element by +1 when `v < b`, by -1 when `v > b`, and continues directly when equal. After either mutation it breaks when `i < b`; after the loop it increments `f`. The outer JUnit wrapper is part of the source but is not invoked by the baseline driver.

The accepted Java 8 target class is major 52 with exactly one field `f:I` and methods `<init>()V` and `test([II)V`. Debug and no-debug use the same physical method Code. The method is 67 bytes, max stack 4, max locals 5, and has 44 instruction BCIs. The complete Code bytes are recorded in the receipt; the decoded topology is:

| BCI | Instruction / edge |
| ---: | --- |
| 0–5 | initialize `i=0`; compare `i` with `a.length`; `if_icmpge` 5 → 56 (normal loop exit) |
| 8–16 | load `v=a[i]`; `if_icmpge` 16 → 29 |
| 19–26 | `< b` arm increments `a[i]`; `goto` 26 → 42 |
| 29–32 | compare `v` to `b`; `if_icmple` 32 → 50 (equal case's direct continue/update edge; `< b` was already excluded) |
| 35–41 | `> b` arm decrements `a[i]`; falls through to 42 |
| 42–47 | compare `i` with `b`; `if_icmpge` 44 → 50; otherwise `goto` 47 → 56 (`break`) |
| 50–53 | `iinc i,1`; `goto` 53 → 2 (loop backedge) |
| 56–66 | `f++`; return |

This is one reducible natural loop with header BCI 2 and a single update/latch route at 50/53. There are two exits to the same post-loop block: header condition 5 → 56 and explicit break 47 → 56. The equality path at 32 goes straight to the update at 50, bypassing the second break test; the `<` and `>` paths meet at 42 and then may break or update. This distinction is essential: collapsing all three cases into a common tail before the `i < b` test changes behavior.

## Current Jarde architecture

The current `region.rs` SHA is pinned. `recover` first refuses irreducible/crossing graph and exception-table shapes, then runs a bounded region walk and checks final physical coverage (around lines 3101–3158 and the remainder of `recover`). The reported reason pair is consistent with the two interacting layers below, but the receipt does not expose a precise failing branch BCI, so assigning the pair to a particular `if` would overstate the evidence.

`loop_region` (15239+) recognizes loop forms through ordered existing attempts, including header-tested and latch-tested loops. `header_tested_loop` (17376+) makes a body frame with loop exits and continue targets, walks the body with `loop_body_sequence`, and requires coverage of the natural-loop blocks before it can return the `Loop` region. `loop_body_sequence` (19776+) repeatedly delegates each next block to `region_at`; it does not independently prove nested branch semantics.

The `region_at_inner` if logic already handles proved loop transfers and continue joins. Around 6928–6960 it can re-elect a join at a continue target, and `continue_inner_join_arm` (8644+) permits a nested If to stop at a loop header/continue target or to carry a closed straight continuation through its own join. The later join check (around 6983–7040) accepts one arm that meets a join and the sibling that ends in a proved `LoopBreak`/`LoopContinue`, including the current loop's continue target. It rolls back visited ownership and reports `ArmsDoNotMeet` when either arm or its continuation cannot be certified. The loop later reports `LoopShape` when its expected natural-loop coverage is incomplete. These are sound refusal paths; removing either gate globally would risk dropped arms, changed break behavior, or double ownership.

## Smallest reuse candidate and required proof

If a fresh diagnostic localizes the refusal to the equality edge and BCI 50, first examine the existing nested-If/continue-target join logic rather than adding a second loop pass or relaxing natural-loop coverage. A minimal extension would be justified only if the current walker fails to represent the exact legal shape where one nested arm ends at this loop's update target while the other arm continues through a separately conditional break test. It must preserve that break test as a statement on only the increment/decrement paths; the equality edge must bypass it. The update node must remain owned once, the backedge must remain the loop's own latch, and both exits must be proved to the same post-loop successor. The outer `f++` must remain after the loop and be covered once.

Before changing code, obtain an exact diagnostic containing the first refusing BCI and the `Region`/next result for each of the nested branches. The accepted report only retains fallback reason names and quote origins (0, 2, 8, 19, 29, 35, 42, 47, 50, 56, 66); it cannot identify whether refusal occurs at BCI 16, 32, 44, or a subsequent coverage check. Do not hard-code those BCIs in production.

A targeted negative should vary the CFG so the equality edge incorrectly passes through the `i < b` break test, or so the update is reachable from a branch that should break. It must remain refused or render equivalent structure only if edge proof establishes source semantics. Also retain cases where one arm is an unknown/multiple-block transfer, there is a second continue target, or a branch has exception/call edges; no general “all arms that eventually reach the latch are continue” rule is safe. Positive/negative controls should compare the method’s full source and runtime side effects (`a` contents and `f`), not just completion.

## JADX reference (algorithm, not an implementation template)

In the pinned JADX `LoopRegionMaker`, `process` (61+) chooses the loop condition from exit blocks, builds the loop region, then inserts loop break annotations for additional exits (100–129); it separately inserts continues for eligible predecessors of the loop end (739–775). `makeLoopRegion` (187–245) validates candidate condition blocks against loop exits and rejects incompatible exits. `insertLoopBreak` (652+) searches a verified crossing edge and annotates it with the owning loop. `IfRegionMaker.process` (59–115) creates an if region, chooses an out block, and recursively regions each arm. `LoopRegionVisitor.processLoopRegion` (70–82) and `checkForIndexedLoop` (87–143) perform a later syntactic induction-variable check before hiding initialization/update instructions. These explain why JADX can present the source-level combination of conditional arms, continue, break, and loop update. They do not prove a Jarde change is needed or safe; Jarde's explicit canonical edges and ownership checks must remain the authority.

## Atlas freshness and pins

Atlas was opened for Jarde and JADX, then used only for scoped symbol discovery. Its Jarde structural result reported the old `loop_body_sequence` position 15616; the checked-in file currently places it at 19776, and the queried `recover` line was also stale. All line references above were re-opened from the current source and are pinned by SHA. Treat Atlas as a stale navigation hint for this review, not source evidence. See `pins.json` for exact bytes/SHA of the original, accepted receipt/review, current Jarde region walker, and JADX maker files.
