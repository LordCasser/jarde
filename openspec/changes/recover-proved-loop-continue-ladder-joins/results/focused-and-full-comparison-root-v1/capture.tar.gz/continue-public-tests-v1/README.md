# Continue ladder public-test preparation (private, not run)

This bundle prepares the public whole-class regression for `recover-proved-loop-continue-ladder-joins` task 2.2. It is not integrated or compiled.

`crates/jarde-java/tests/p3_continue_ladder_joins.rs` exercises the public facade on the accepted original debug/no-debug child class and the corresponding complete two-class plain JARs, with default and all-evidence requests. It checks the target’s structured body, direct `continue` before the later conditional `break`, array increment/decrement paths, post-loop `f++`, physical method identity, valid UTF-8 map spans, and that each emitted source-map anchor belongs to the target method and one of its real instruction BCIs. It also checks default/all text and map stability and public pre-cancellation. It deliberately does not demand complete BCI coverage: the accepted old baseline has 11 mapped anchors over 44 test instructions.

The copied original class files and both JARs are checked byte-for-byte against the accepted baseline receipt. Each JAR contains exactly the matching outer and child class bytes. The full upstream Java source, driver, `LICENSE`, and `NOTICE` are retained with their source pins. The manifest records all local file hashes and the baseline identity.

`TestContinueInLoopNormalJoin.java` is only a source candidate for a normal-flow boundary: its equality arm reaches the later condition rather than continuing. It has not been compiled. No outcome, class bytes, or Reader inventory delta is claimed for this control; root must compile and classify it before relying on it.

No JDK, javac, Jarde CLI, Cargo, or tests were run for this preparation. The public test is a draft and still needs root review, integration, formatting, actual focused execution, and Reader inventory/fingerprint update based on actual compiled control artifacts.
