package jadx.tests.integration.loops;

/**
 * Source-only boundary control: all three arms reach the later condition, so the equality arm is
 * not an abrupt continue and the new continue-ladder proof must not invent one.
 * Root must compile and inspect this source before assigning any expected recovery outcome.
 */
public class TestContinueInLoopNormalJoin {
    public static class TestCls {
        public int f;

        public void test(int[] a, int b) {
            for (int i = 0; i < a.length; i++) {
                int v = a[i];
                if (v < b) {
                    a[i]++;
                } else if (v > b) {
                    a[i]--;
                } else {
                    a[i] = v;
                }
                if (i < b) {
                    break;
                }
            }
            this.f++;
        }
    }
}
