# TestContinueInLoop final-candidate comparison preparation

This is a private, unexecuted adaptation of the accepted TestBreakWithLabel final collector and reviewer. It awaits a root-supplied final CLI path and SHA-256. No candidate CLI was guessed or invoked, and no JDK, Jarde, JADX, Cargo, Git, network, or shared-tree mutation was used.

The collector reuses the root-accepted original and JADX evidence from `/private/tmp/jarde-testcontinueinloop-baseline-root-v1-20261019`; it does not rerun those commands. The baseline has eight API calls, 46 captured commands, eight bounded original cases in each of four VM cells, Jarde/JADX source outputs, and the accepted root marker. The raw baseline receipt remains `captured-pending-independent-review`; the separate marker at SHA `3c53bac442e35918b04f30da789c26e06dfb3a2ab3f7d65ef24905f7214d62c1` binds receipt SHA `d33084ce268c7d3c49a056f120619d7e1786b5f438d5bcf8b30d66911ea2c0ec` and records acceptance with an explicit whole-method refusal gap.

The proposed collector runs exactly eight current CLI API cells (debug/no-debug × class/JAR × default/all), compiles each complete emitted class source with javac 8 and javac 23 (16 builds), runs one isolated wrong-CodeSource control for each successful build (16 controls), and runs each compiled class on both VMs (32 runs × eight observations = 256 observations). This yields 72 commands when all required cells complete. It keeps the complete upstream `TestContinueInLoop.java`, the two-method target inventory (`<init>()V`, `test([II)V`), field `f:I`, whole-class text, physical BCI map checks, isolated parentless CodeSource, empty working directories, and source/external-input guards. The driver records the initial input snapshot before invoking the target. The reviewer checks that ordering and does not rebind `receipt_path` in a loop.

Default/all output decisions and source maps are checked independently; unmapped physical BCIs are reported without requiring complete coverage. Original/JADX evidence is reopened through its exact accepted receipt pins and is not treated as new execution. The expected candidate CLI is mandatory at invocation and must be supplied with its exact SHA-256.

Static preflight imported the collector/reviewer definitions without invoking their entry points, compared their self-pins and helper pins, checked the accepted baseline's eight rows against the reviewer's explicit oracle, verified the two method descriptors and `f:I`, and checked driver input-snapshot order. `preflight.json` records those checks. No collector/reviewer capture was run.

## Prepared files

- `collect_final.py`: adapted command collector; requires `--out`, `--cli`, `--cli-sha256`.
- `review.py`: independent read-only receipt reviewer; requires `--receipt`, `--expected-cli-sha256`, `--out`.
- `adaptation.diff`: complete diffs against the accepted collector and reviewer templates.
- `pins.json`: template, source, baseline, helper, driver, and prepared-file pins.

The exact source and helper pins are in `pins.json`; accepted templates are TestBreakWithLabel collector SHA `5d3f5c7cff83feb025b22e6254ca6cb5e4c538ef057b948ae71de79f3b55a48f` and reviewer SHA `bdf0aa08c1c01883ee9a8b0c66ecbe3b4738b90b2c458d5784dc89b8ed6c2bfb`. No run result is asserted here.
