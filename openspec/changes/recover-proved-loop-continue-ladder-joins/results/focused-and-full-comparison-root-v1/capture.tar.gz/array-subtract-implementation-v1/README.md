# Private candidate: proved int-array subtraction updates

This is an uncompiled private task-1.2 candidate based on the pinned `build.rs` snapshot. It does not modify the shared workspace or OpenSpec task status.

The `CompoundUpdate::Array` plan now carries the already-proved `ArithmeticOp`. Its proof accepts only the exact `(0x60, Add)` pair as before, plus `(0x64, Subtract)` when `return_bci` is absent. Every existing duplication, array/index identity, unique-use, dependency, interval and ordering check remains after that operator gate. The Builder maps only Add and Subtract to the existing AST `AssignOp`; an unexpected planned operator refuses. The returned-array recognition still requires opcode `0x60`, and returned expression emission still uses `AssignOp::Add`.

The added `build::tests::proved_int_array_subtract_uses_real_ir_and_keeps_existing_boundaries` reads the existing frozen debug/no-debug `TestContinueInLoop$TestCls` classes, runs the real analysis, and checks the plan contains the method’s proved Add and Subtract updates. It changes the decoded subtraction opcode to equal-width `imul` in a byte copy, reruns analysis, and requires the subtraction store to be refused while the independent Add remains proved. It also cuts the full plan at one fewer `IrItems` than measured and uses a pre-cancelled budget; both must return the existing stop instead of a plan.

The operator-change copy is used only for reader/IR analysis; it is not claimed to be JVM-verified. No JDK, Cargo, rustfmt, CLI, Git or network command was run. Root review and focused verification remain necessary.
