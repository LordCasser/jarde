// jarde: presentation of `jadx/tests/integration/loops/TestContinueInLoop$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestContinueInLoop$TestCls extends java.lang.Object {
    public int f;

    public TestContinueInLoop$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestContinueInLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public void test(int[] a, int b) {
        // @method test([II)V
        // @declaration an instance method of `jadx.tests.integration.loops.TestContinueInLoop$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int i;
        for (i = 0; i < a.length; i = i + 1) {
            int v = a[i];
            if (v < b) {
                a[i] += 1;
            } else if (v > b) {
                a[i] -= 1;
    } else {
                continue;
    }
            if (i < b) {
                break;
            }
        }
        this.f++;
        return;
    }
}
