# Private v3 test-only correction: loop continue ladder edge control

This candidate copies the root-integrated, rustfmt-formatted `region.rs` as its base and changes only the new unit's parser/IR negative control. The production implementation is unchanged from that base.

The failed v2 control retargeted BCI 26 `goto 42` to BCI 35. Root's actual focused run showed the canonicalizer merged the old tail block at 42 into the block beginning at 35, so requiring a separate BCI 42 node was invalid. The v2 failure is retained at `/private/tmp/jarde-continue-ladder-focused-root-v1-20261019/raw/2.stdout.raw`.

The v3 control instead changes the decoded conditional at BCI 32 from offset +18 (target BCI 50, the update) to offset -30 (target BCI 2, the loop header). The test uses `MethodCodeFacts.code_span.start` to locate the encoded operand, reparses/reanalyzes the resulting bytes, and verifies the natural loop has backedges from BCI 32 and the original update block at BCI 50. It then asks the existing `prove_for_header` path for a certificate and requires refusal. This models a real conditional edge that bypasses the proved update. StackMapTable is unchanged; the altered class is a parser/IR control and is not claimed to be JVM-verifiable.

No Cargo, rustfmt, JDK, CLI, Git, or network command was run. Root should review and run the focused Rust tests before integrating this test-only correction.
