# Private candidate: proved loop continue ladder joins

This is an uncompiled, untested private candidate based on the recorded `region.rs` base. It is not integrated into the workspace.

The implementation keeps the new continue-ladder path local to the existing region walker. It reuses the current normal-flow routes and proved `ForHeader` update, while checking the canonical edges that enter and leave the bounded ladder routes. A successful local direct-continue join can replace an outside postdominator for this loop case; other ladder joins retain their prior selection. The recursive arm walk snapshots and restores both `visited` and `unclosed_tail_at` when the new proof refuses or stops.

The unit exercises both pinned original class profiles, their real canonical/SSA facts, the proved loop/header, the one direct continue, exact ownership, malformed frame refusals, analysis-step stops, and pre-cancellation. The added edge-control changes only the signed branch offset at BCI 26: the decoded original `goto` targets BCI 42 (offset +16), and the control retargets it to BCI 35 (offset +9). It then rebuilds canonical/SSA facts from those class bytes, confirms BCI 19 is an additional normal predecessor of BCI 35, and requires the exact sibling-chain proof to refuse. This is a reader/IR control only; its unchanged StackMapTable means it is not claimed to be JVM-verifiable.

No Cargo, rustfmt, JDK, CLI, Git, or network command was run. The candidate needs root review and the project’s normal focused verification before integration.
