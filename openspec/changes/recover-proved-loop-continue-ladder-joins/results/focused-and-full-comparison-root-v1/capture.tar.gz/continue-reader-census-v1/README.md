# Continue-ladder fixture Reader census (static, not executed)

This is a read-only physical inventory of the private fixture candidate at `/private/tmp/jarde-continue-ladder-public-tests-luna-v2-20261019/tests/fixtures/recover-proved-loop-continue-ladder-joins`. It does not modify that fixture or the shared checkout. I parsed the four loose `.class` files with the already accepted independent classfile reader and independently counted encoded branch/switch target edges from each Code byte array. This is a predicted Reader delta only; no Reader test or Cargo command was run.

## Count

The four loose class files add **4 classes, 8 Code bodies, 0 exception-handler records, 14 non-handler branch/switch targets, and 0 jsr/jsr_w subroutines**. The current pinned Reader assertion is `(1326, 5850, 631, 4203, 16)` at `crates/jarde-reader/src/classfile.rs:12328-12332`; the predicted tuple after adding these loose files is therefore **(1330, 5858, 631, 4217, 16)**.

The two sibling `.jar` files contain the same two class entries per jar, but they add **zero** to this Reader fixture census. `class_fixture_paths()` recursively collects filesystem entries whose extension is exactly `.class` (`classfile.rs:12336-12354`); it neither opens JARs nor counts ZIP entries. Do not add the four embedded entries a second time.

## Per-file facts

| Loose class | Bytes / SHA-256 | Major | Methods / Code | Handlers | Targets | jsr |
|---|---:|---:|---:|---:|---:|---:|
| `original/debug/classes/jadx/tests/integration/loops/TestContinueInLoop$TestCls.class` | 752 / `57adb18f7c6398e86daa90be1ffd2576ac47662e973ab8db02e164591aac7ed3` | 52 | 2 / 2 | 0 | 7 | 0 |
| `original/debug/classes/jadx/tests/integration/loops/TestContinueInLoop.class` | 1274 / `9bab678de2df9fbfceba32557ba20914aa65e00808b4628b328655623be530a6` | 52 | 2 / 2 | 0 | 0 | 0 |
| `original/no-debug/classes/jadx/tests/integration/loops/TestContinueInLoop$TestCls.class` | 438 / `1f2dea241154efa5ad132904cff22ad1290890c189f443bbd528a98023ddaf85` | 52 | 2 / 2 | 0 | 7 | 0 |
| `original/no-debug/classes/jadx/tests/integration/loops/TestContinueInLoop.class` | 1041 / `59068868746d3dc3a06ac7cedc96c25cb7758a7f7ebc27bceae36c293e6d8c47` | 52 | 2 / 2 | 0 | 0 | 0 |

In each child class, `<init>()V` has no target and `test([II)V` has seven: conditional branches at BCI 5, 16, 32, and 44, plus gotos at 26, 47, and 53. The outer `test()V` class has only `<init>()V` and `test()V`; both have no branch targets. The four classes have eight methods with Code total. Both JARs have the corresponding two entries; their content is not part of the filesystem `.class` walk.

## Counting rule and pins

The current test counts one body after `method_code_facts` succeeds, adds `exception_handlers.len()`, adds all `control_flow_targets()` except `Handler` targets, and increments subroutines for opcodes `0xa8`/`0xc9`; see `classfile.rs:11800-11866`. The fixture path walker is at `classfile.rs:12336-12354`. The source itself is not compiled or counted.

Pins used for this static calculation:

- Reader source: `cb33e7f738e05577b830161ff540e912d2daff66d6b315ed8b7e7edb63cf69e0` (`crates/jarde-reader/src/classfile.rs`).
- Accepted parser: `c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd` (`/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py`).
- `debug-plain.jar`: 2428 bytes, `03252bb2bba222dee9da5151250f23cbe7e518892c29999cc0890207f36f1ace`; two `.class` entries.
- `no-debug-plain.jar`: 1881 bytes, `f3a0afedeab612615082098ee310bd9a75e6831485120a5472b71a14bcc37dd9`; two `.class` entries.

No Reader run, compilation, JVM execution, CLI execution, or Git operation was performed.
