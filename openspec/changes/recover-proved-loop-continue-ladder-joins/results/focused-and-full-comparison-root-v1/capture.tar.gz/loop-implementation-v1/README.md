# Proved loop-continue ladder candidate v1

Private, uncompiled candidate for OpenSpec task 2.1. No shared source was changed, and no Rust/toolchain command was run. Root should review the full `production.patch` before any integration.

The base is the exact root-pinned `crates/jarde-java/src/region.rs` snapshot (SHA-256 `209de1ed354203b9f2289f19d74d7a5a453afd5a785a8abe12852a6e8983a242`). The candidate changes only that file. It reuses the existing `ladder_join`, `arm_forward_routes`, `Region::If`, `Region::LoopContinue`, and `Frame.shared_tail`; it adds no `Frame` field, `Region` variant, pass, or public API. The new path only considers a direct conditional edge to the loop frame's update target and a strictly straight sibling arm ending at the parent-elected shared tail. It checks exact canonical normal edges and charges/polls the examined routes.

The candidate includes one real-IR unit using both frozen debug/no-debug original classes. It dynamically finds the natural loop, ForHeader, parent ladder and child continue, checks the resulting full loop has one continue with unique ownership, and measures budget stops/cancellation at both proof helpers. It also checks refusals for missing or mismatched scope/tail and a loop-header target. It does not independently mutate canonical edges; an extra physical incoming-edge control is still pending a legitimate parser/IR fixture. This draft does not claim compilation or test success.

No integration or acceptance is implied. `region.rs` and `production.patch` are the complete review surface; `region.rs.base` is the byte-for-byte base snapshot.
