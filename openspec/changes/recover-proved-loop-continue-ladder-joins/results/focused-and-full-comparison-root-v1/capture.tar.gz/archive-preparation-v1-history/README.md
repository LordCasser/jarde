# Continue-ladder focused and full-comparison archive preparation

This is an unexecuted, standard-library-only preparation. It reuses the accepted TestBreakWithLabel packer’s byte/mode/SHA inventory, symlink and executable checks, deterministic tar creation, pre-existing-sidecar refusal, and exact archive reopen. It does not run a collector, test, CLI, compiler, or network command.

`pack.py` takes an explicit `--manifest`. The packer has no fixed evidence-root list: every root must be listed by the eventual root-supplied manifest and every listed root must exist. `manifest-template.json` records only the currently observed implementation, architecture review, public-test, fixture/census, focused preparation/capture, and own-CI preparation/review directories. Root must append the final accepted matrix directory and any later evidence roots explicitly; this preparation does not guess a future successful receipt or marker.

Before packing, the tool requires the manifest’s matrix binding to provide exact path/bytes/SHA pins for `execution.json`, the accepted root marker, and the current CLI. The matrix marker must have an accepted status, contain the exact execution receipt SHA, and bind the same CLI path/bytes/SHA object. The execution receipt must also bind that CLI pin. The matrix root itself must appear exactly once in the explicit input list. The current CLI must be named by exactly one explicit `role: current-cli` exclusion under one listed root; its bytes, mode, SHA, and reason are retained in the archive inventory as an excluded external input. All other files are payload, including failures and rejected reviews. Unlisted omissions, caches, symlinks, native binaries, missing roots, changed files, and pre-existing archive/sidecar paths fail closed.

The output inventory records each payload’s absolute source path, archive path, bytes, mode, and SHA-256; it also records the matrix binding, input roots, and excluded CLI pin. The deterministic gzip tar includes the supplied manifest and this preparation’s packer, README, schema, pins, and diff. It is reopened before the sidecar is written; every member, payload byte, mode, and inventory value is checked against the captured inputs. Empty directories are not tar members, matching the accepted packer; all regular files are preserved.

No final focused capture, full-comparison matrix, or accepted root marker exists in this preparation. Do not run with the template unchanged. After root has completed and independently reviewed the matrix, root fills a new explicit manifest with its actual receipt/marker/CLI pins and runs:

```sh
python3 -B /private/tmp/jarde-continue-ladder-evidence-archive-prep-luna-v1-20261019/pack.py \
  --manifest /private/tmp/<root-frozen-manifest>.json \
  --out /Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-proved-loop-continue-ladder-joins/results/focused-and-full-comparison-root-v1/capture.tar.gz
```

The candidate CLI is never included as a binary payload. Product candidate/source archives and actual native/CI outputs are included only when their directories are explicitly listed by root.
