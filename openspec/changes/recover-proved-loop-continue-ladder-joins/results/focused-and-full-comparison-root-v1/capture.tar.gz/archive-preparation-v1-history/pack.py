#!/usr/bin/env python3
"""Deterministically archive explicit Continue-ladder evidence roots; no evidence tools run."""
from __future__ import annotations
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile

sys.dont_write_bytecode = True
TMP = Path('/private/tmp').resolve()
HERE = Path(__file__).resolve().parent
MAX_BYTES = 512 * 1024 * 1024
MANIFEST_SCHEMA = 'continue-ladder-evidence-archive-input-v1'
INVENTORY_SCHEMA = 'continue-ladder-evidence-archive-v1'


def fail(message: str) -> None:
    raise SystemExit(f'archive refused: {message}')


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def path_without_symlinks(path: Path) -> Path:
    absolute = path.absolute()
    for component in (absolute, *absolute.parents):
        if component.is_symlink():
            fail(f'symlink path component: {component}')
    return absolute


def file_record(path: Path) -> tuple[bytes, int]:
    source = path_without_symlinks(path)
    if not source.exists() or not source.is_file():
        fail(f'missing or non-regular input: {source}')
    before = source.stat()
    data = source.read_bytes()
    after = source.stat()
    mode = stat.S_IMODE(after.st_mode)
    if (before.st_size, before.st_mtime_ns, before.st_mode) != (after.st_size, after.st_mtime_ns, after.st_mode):
        fail(f'input changed while reading: {source}')
    if len(data) != after.st_size:
        fail(f'input size changed while reading: {source}')
    return data, mode


def pin_matches(data: bytes, mode: int, record: dict, label: str) -> None:
    if not isinstance(record, dict):
        fail(f'{label}: missing explicit file pin')
    if record.get('bytes') != len(data) or record.get('sha256') != sha(data):
        fail(f'{label}: bytes/SHA-256 differ from explicit manifest pin')
    if 'mode' in record and record['mode'] != mode:
        fail(f'{label}: mode differs from explicit manifest pin')


def native_executable(data: bytes, path: Path) -> bool:
    if path.suffix.lower() == '.class':
        return False
    return data.startswith((
        b'\x7fELF', b'MZ', b'\xfe\xed\xfa\xce', b'\xce\xfa\xed\xfe',
        b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe',
        b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca',
    ))


def walk_values(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from walk_values(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk_values(child)


def accepted_matrix_binding(manifest: dict) -> dict:
    binding = manifest.get('matrix_binding')
    if not isinstance(binding, dict):
        fail('manifest must provide matrix_binding')
    roots = {row['label']: Path(row['root']).resolve(strict=True) for row in manifest['inputs']}
    label = binding.get('input_label')
    if label not in roots:
        fail('matrix_binding.input_label does not name an explicit input root')
    matrix = path_without_symlinks(roots[label])
    receipt_pin = binding.get('execution_receipt')
    marker_pin = binding.get('accepted_root_marker')
    cli_pin = binding.get('current_cli')
    if not all(isinstance(x, dict) for x in (receipt_pin, marker_pin, cli_pin)):
        fail('matrix receipt, accepted marker, and current CLI must each have explicit pins')
    pinned_bytes = {}
    for name, row in (('execution receipt', receipt_pin), ('accepted root marker', marker_pin), ('current CLI', cli_pin)):
        if (not isinstance(row.get('path'), str) or type(row.get('bytes')) is not int
                or row['bytes'] < 0 or not isinstance(row.get('sha256'), str)
                or len(row['sha256']) != 64 or any(ch not in '0123456789abcdef' for ch in row['sha256'])):
            fail(f'{name}: malformed explicit path/bytes/SHA-256 pin')
        if 'mode' in row and type(row['mode']) is not int:
            fail(f'{name}: mode pin must be an integer when present')
        path = Path(row['path'])
        if not path.is_absolute() or path_without_symlinks(path) != path:
            fail(f'{name}: path must be absolute and canonical')
        try:
            if path.resolve(strict=True) != path:
                fail(f'{name}: path contains a non-canonical component')
        except OSError as exc:
            fail(f'{name}: path cannot be resolved: {exc}')
        data, mode = file_record(path)
        pin_matches(data, mode, row, name)
        pinned_bytes[str(path)] = data
    receipt_path = Path(receipt_pin['path'])
    marker_path = Path(marker_pin['path'])
    if not receipt_path.is_relative_to(matrix) or not marker_path.is_relative_to(matrix):
        fail('matrix receipt and accepted marker must be files inside the named matrix root')
    try:
        receipt = json.loads(pinned_bytes[str(receipt_path)].decode('utf-8'))
        marker = json.loads(pinned_bytes[str(marker_path)].decode('utf-8'))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        fail(f'matrix receipt or marker is not readable JSON: {exc}')
    statuses = [str(value).lower() for row in walk_values(marker) for key, value in row.items()
                if key == 'status' and isinstance(value, str)]
    accepted = {'accepted', 'root_accepted'}
    if not any(value in accepted or value.startswith('accepted_') or value.startswith('root_accepted_')
               for value in statuses):
        fail('accepted root marker does not contain an accepted status')
    receipt_sha = receipt_pin['sha256']
    marker_values = {value for row in walk_values(marker) for value in row.values() if isinstance(value, str)}
    if receipt_sha not in marker_values:
        fail('accepted root marker does not bind the exact matrix execution.json SHA-256')
    cli = {key: cli_pin[key] for key in ('path', 'bytes', 'sha256')}
    if not any(all(row.get(key) == value for key, value in cli.items()) for row in walk_values(marker)):
        fail('accepted root marker does not bind the exact current CLI path/bytes/SHA-256')
    if not any(all(row.get(key) == value for key, value in cli.items()) for row in walk_values(receipt)):
        fail('matrix execution receipt does not bind the exact current CLI path/bytes/SHA-256')
    return {'input_label': label, 'execution_receipt': dict(receipt_pin),
            'accepted_root_marker': dict(marker_pin), 'current_cli': dict(cli_pin),
            'accepted_status_values': statuses}


def collect(manifest_path: Path) -> tuple[dict, dict[str, tuple[Path, bytes, int]]]:
    manifest_path = path_without_symlinks(manifest_path.absolute())
    if (not manifest_path.is_file() or not manifest_path.is_relative_to(TMP)
            or manifest_path.resolve(strict=True) != manifest_path):
        fail('input manifest must be a canonical regular file under /private/tmp')
    try:
        manifest_data, manifest_mode = file_record(manifest_path)
        manifest = json.loads(manifest_data.decode('utf-8'))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        fail(f'input manifest is invalid JSON: {exc}')
    if not isinstance(manifest, dict):
        fail('input manifest must be a JSON object')
    if manifest.get('schema') != MANIFEST_SCHEMA:
        fail(f'manifest schema must be {MANIFEST_SCHEMA}')
    rows = manifest.get('inputs')
    if not isinstance(rows, list) or not rows:
        fail('manifest inputs must explicitly enumerate every evidence root')
    labels, roots, seen_roots = set(), [], set()
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get('label'), str) or not row['label']:
            fail('each input root needs a unique nonempty label')
        if row['label'] in labels:
            fail(f'duplicate evidence label: {row["label"]}')
        labels.add(row['label'])
        root = path_without_symlinks(Path(row.get('root', '')).absolute())
        try:
            canonical_root = root.resolve(strict=True)
        except OSError as exc:
            fail(f'evidence root cannot be resolved: {exc}')
        if root != canonical_root or not root.is_relative_to(TMP) or not root.is_dir():
            fail(f'evidence root is missing, non-canonical, or outside /private/tmp: {root}')
        resolved = str(root)
        if resolved in seen_roots:
            fail(f'duplicate evidence root: {resolved}')
        seen_roots.add(resolved)
        exclusions = row.get('exclude', [])
        if not isinstance(exclusions, list):
            fail(f'{row["label"]}: exclude must be an explicit list')
        seen_exclusions = set()
        for exclusion in exclusions:
            if (not isinstance(exclusion, dict) or not isinstance(exclusion.get('relative_path'), str)
                    or not exclusion['relative_path'] or exclusion.get('role') != 'current-cli'
                    or not isinstance(exclusion.get('reason'), str) or not exclusion['reason']):
                fail(f'{row["label"]}: every exclusion must explicitly identify and explain the current CLI')
            relative = PurePosixPath(exclusion['relative_path'])
            if relative.is_absolute() or '..' in relative.parts or not relative.parts:
                fail(f'{row["label"]}: unsafe excluded relative path: {relative}')
            if relative.as_posix() in seen_exclusions:
                fail(f'{row["label"]}: duplicate exclusion: {relative}')
            seen_exclusions.add(relative.as_posix())
        roots.append((row['label'], root, exclusions))
    binding = accepted_matrix_binding(manifest)
    matrix_label = binding['input_label']
    if sum(label == matrix_label for label, _, _ in roots) != 1:
        fail('the matrix root must occur exactly once in the explicit input list')
    cli_pin = binding['current_cli']
    critical_pins = {str(Path(row['path'])): row for row in (binding['execution_receipt'], binding['accepted_root_marker'])}
    items: dict[str, tuple[Path, bytes, int]] = {}
    excluded: list[dict] = []
    seen_sources: set[str] = set()
    declared_exclusions: list[str] = []

    def add(archive_path: str, source: Path, data: bytes, mode: int) -> None:
        rel = PurePosixPath(archive_path)
        if rel.is_absolute() or '..' in rel.parts or not rel.parts:
            fail(f'unsafe archive path: {archive_path}')
        name = rel.as_posix()
        if name in items or name == 'ARCHIVE_INVENTORY.json':
            fail(f'duplicate/reserved archive path: {name}')
        resolved = str(source.resolve(strict=True))
        if resolved in seen_sources:
            fail(f'duplicate source input: {resolved}')
        if native_executable(data, source):
            fail(f'native executable is not an allowed payload: {source}')
        seen_sources.add(resolved)
        items[name] = (source, data, mode)

    for label, root, exclusions in roots:
        paths = sorted(root.rglob('*'), key=lambda path: path.as_posix())
        files_seen = set()
        for path in paths:
            if path.is_symlink():
                fail(f'symlink in evidence tree: {path}')
            if path.is_dir():
                continue
            if not path.is_file():
                fail(f'non-regular evidence entry: {path}')
            relative = path.relative_to(root).as_posix()
            files_seen.add(relative)
            matched = [row for row in exclusions if isinstance(row, dict) and row.get('relative_path') == relative]
            if len(matched) > 1:
                fail(f'duplicate exclusion for {label}/{relative}')
            data, mode = file_record(path)
            absolute_source = str(path.resolve(strict=True))
            if absolute_source in critical_pins:
                pin_matches(data, mode, critical_pins[absolute_source], 'matrix-bound file')
            if matched:
                rule = matched[0]
                if rule.get('role') != 'current-cli' or not isinstance(rule.get('reason'), str) or not rule['reason']:
                    fail(f'{label}/{relative}: only an explicitly explained current-cli exclusion is allowed')
                if path.resolve(strict=True) != Path(cli_pin['path']).resolve(strict=True):
                    fail('excluded current CLI path differs from the exact matrix pin')
                pin_matches(data, mode, cli_pin, 'excluded current CLI')
                excluded.append({'source_path': str(path.resolve()), 'input_label': label,
                                 'relative_path': relative, 'bytes': len(data),
                                 'sha256': sha(data), 'mode': mode, 'reason': rule['reason']})
                declared_exclusions.append(str(path.resolve()))
                continue
            if '__pycache__' in path.parts or path.name.endswith('.pyc'):
                fail(f'cache artifact is not an allowed implicit omission: {path}')
            add(f'{label}/{relative}', path, data, mode)
        if not files_seen:
            fail(f'evidence root has no regular files: {root}')
        extra_exclusions = {row.get('relative_path') for row in exclusions if isinstance(row, dict)} - files_seen
        if extra_exclusions:
            fail(f'{label}: declared exclusion(s) absent from source tree: {sorted(extra_exclusions)}')
    if len(declared_exclusions) != 1 or declared_exclusions[0] != str(Path(cli_pin['path']).resolve(strict=True)):
        fail('manifest must explicitly exclude exactly the one pinned current CLI binary')
    if str(Path(cli_pin['path']).resolve(strict=True)) in seen_sources:
        fail('current CLI binary was included as payload')

    add('archive-preparation/input-manifest.json', manifest_path, manifest_data, manifest_mode)
    for source, archive_name in ((HERE / 'pack.py', 'archive-preparation/pack.py'),
                                 (HERE / 'README.md', 'archive-preparation/README.md'),
                                 (HERE / 'schema.json', 'archive-preparation/schema.json'),
                                 (HERE / 'pins.json', 'archive-preparation/pins.json'),
                                 (HERE / 'pack.diff', 'archive-preparation/pack.diff')):
        data, mode = file_record(source)
        add(archive_name, source, data, mode)
    if sum(len(data) for _, data, _ in items.values()) + sum(row['bytes'] for row in excluded) > MAX_BYTES:
        fail(f'evidence exceeds {MAX_BYTES} bytes')
    excluded.sort(key=lambda row: row['source_path'])
    inventory = {'schema': INVENTORY_SCHEMA, 'payload_member_count': len(items),
                 'members': [{'archive_path': name, 'source_path': str(path.resolve()),
                              'bytes': len(data), 'sha256': sha(data), 'mode': mode}
                             for name, (path, data, mode) in sorted(items.items())],
                 'excluded_external_inputs': excluded, 'matrix_binding': binding,
                 'input_roots': [{'label': label, 'path': str(root.resolve())} for label, root, _ in roots],
                 'notes': ['Every explicit input root is required; a missing root or declared exclusion is a hard failure.',
                           'Only the exact current CLI path in the manifest is excluded, and its bytes/SHA/mode are preserved as an external pin.',
                           'All other files, including failed captures and review artifacts, are payload.']}
    return inventory, items


def verify(output: Path, inventory: dict, items: dict[str, tuple[Path, bytes, int]], blob: bytes) -> None:
    with tarfile.open(output, 'r:gz') as archive:
        members = archive.getmembers()
        byname = {item.name: item for item in members}
        expected = set(items) | {'ARCHIVE_INVENTORY.json'}
        if len(byname) != len(members) or set(byname) != expected:
            fail('archive has duplicate, missing, or unexpected members')
        for name, (source, expected_bytes, expected_mode) in items.items():
            info = byname[name]
            if not info.isfile() or info.mode != expected_mode:
                fail(f'archive member type/mode mismatch: {name}')
            actual = archive.extractfile(info).read()
            if actual != expected_bytes or len(actual) != len(expected_bytes) or sha(actual) != sha(expected_bytes):
                fail(f'archive member byte/hash mismatch: {name}')
            current, mode = file_record(source)
            if current != expected_bytes or mode != expected_mode:
                fail(f'source changed before archive verification completed: {source}')
        got = archive.extractfile(byname['ARCHIVE_INVENTORY.json']).read()
        if got != blob or json.loads(got) != inventory:
            fail('archive inventory failed exact reopen verification')


def pack(out: Path, manifest_path: Path) -> dict:
    output = path_without_symlinks(out.absolute()).resolve(strict=False)
    sidecar = path_without_symlinks(output.with_suffix(output.suffix + '.inventory.json'))
    if output.exists() or output.is_symlink() or sidecar.exists() or sidecar.is_symlink():
        fail(f'refusing existing archive or sidecar: {output}')
    if output.is_relative_to(HERE):
        fail('output cannot be inside archive preparation directory')
    manifest_path = path_without_symlinks(manifest_path.absolute())
    inventory, items = collect(manifest_path)
    roots = [Path(row['path']) for row in inventory['input_roots']]
    if any(output == root or output.is_relative_to(root) for root in roots):
        fail('output must be outside all evidence input roots')
    blob = (json.dumps(inventory, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as zipped:
            with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for name, (_, data, mode) in sorted(items.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data); info.mode = mode; info.mtime = 0
                    info.uid = info.gid = 0; info.uname = info.gname = ''
                    archive.addfile(info, io.BytesIO(data))
                info = tarfile.TarInfo('ARCHIVE_INVENTORY.json')
                info.size = len(blob); info.mode = 0o644; info.mtime = 0
                info.uid = info.gid = 0; info.uname = info.gname = ''
                archive.addfile(info, io.BytesIO(blob))
    verify(output, inventory, items, blob)
    with sidecar.open('xb') as handle:
        handle.write(blob)
    return {'status': 'packed-and-reopened', 'archive': str(output),
            'archive_sha256': sha(output.read_bytes()), 'inventory': str(sidecar),
            'inventory_sha256': sha(blob), 'payload_members': len(items)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True,
                        help='explicit JSON manifest listing all evidence roots and exact matrix/CLI pins')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(pack(args.out, args.manifest), indent=2))


if __name__ == '__main__':
    main()
