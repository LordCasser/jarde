# TestBreakWithLabel native and own-CI archive preparation

This v2 remains a private, unexecuted preparation tool. It closes the reviewed artifact-SHA binding and early sidecar-collision checks while preserving v1. It only packages already accepted evidence; it never runs Cargo, JDK, CLI, Git, or network operations. Root must first provide a frozen manifest naming every evidence directory for native capture, own CI, product binding, and named regressions, plus any histories, static reviews, official ZIPs, and root acceptance marker. Every directory is required and every marker is pinned by SHA-256 and an exact status value supplied by root. No success is inferred from an in-progress receipt.

The tool follows the byte-inventory, deterministic tar, and member-by-member reopen checks of the previously accepted TestBreakWithLabel archive. It records original source paths, archive paths, bytes, SHA-256, and mode. It refuses symlinks, missing/nonregular inputs, native executables, CLI files, Cargo caches/targets, build artifacts, duplicate inputs, and outputs within the preparation tree. Every supplied official CI ZIP is checked for a matching SHA and a readable archive and must also exist within a listed payload tree. All raw failure receipts, compiler/CI output streams, official ZIPs, and named-outcome data must be listed so they remain verbatim payload.

Root supplies the manifest only after its native capture, CI collection, product binding, and named-outcome review directories are final and accepted. The manifest must include one root marker and one accepted marker for each required role (`native`, `own_ci`, `product_binding`, `named_outcomes`); and payload roots for accepted failure history plus separate own-CI preparation and root static-review tooling; it also declares exact marker JSON status fields/accepted values and receipt-binding fields. Every acceptance marker must bind at least one exact payload receipt/artifact SHA, and the command independently requires the root marker SHA both inside the manifest and as an explicit argument. The root review marker and each role marker must be inside a listed directory so they are preserved in the archive.

No manifest with future CI pins is fabricated here. The template is intentionally non-runnable until root replaces every placeholder with real paths, hashes, accepted statuses, and official ZIP pins. The final archive output path is likewise supplied explicitly after the change results destination is confirmed.

Intended command after root review:

```sh
python3 -B /private/tmp/jarde-testbreakwithlabel-native-own-ci-archive-prep-luna-v2-20261019/pack.py \
  --manifest /private/tmp/ROOT_SUPPLIED_ACCEPTED_NATIVE_OWN_CI_MANIFEST.json \
  --accepted-root-review-sha256 ROOT_SUPPLIED_ACCEPTED_ROOT_REVIEW_SHA256 \
  --out /Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-proved-literal-boolean-locals/results/ROOT_CONFIRMED_ROOT_NAME/capture.tar.gz
```

The manifest template is only a schema guide and includes no speculative success receipt. The filled manifest, preparation template, pins, adaptation note, README, and packer are included as archive-preparation payload. The script has not been run against evidence or used to create an archive.
