# Adaptation delta from the accepted focused/full archive pattern

The packer keeps the same deterministic standard-library tar construction, exact source-byte/mode inventory, cache/symlink rejection, and full member-by-member reopen comparison used by the accepted focused/full archive. It changes the input and acceptance layer for the native/own-CI closeout:

- The earlier tool names its evidence roots in code. This tool reads an explicit root-supplied manifest, requires every listed directory, and requires native, own-CI, product-binding, named-outcomes, failure-history, and tooling roles.
- The earlier gate uses a fixed accepted matrix marker. This tool requires an explicit root-review SHA in both manifest and command line, exact accepted marker status strings supplied by root, and hash bindings from those markers to included receipts/artifacts.
- This tool additionally requires individually pinned, valid official CI ZIP files to be included in the payload, while keeping CLI executables, Cargo caches/targets, and Rust build artifacts out.
- The final output path is a command argument because root has not supplied the destination yet. The packer refuses to run on placeholder manifests or missing accepted evidence.

This is a private preparation note, not evidence that native or CI acceptance has completed.
