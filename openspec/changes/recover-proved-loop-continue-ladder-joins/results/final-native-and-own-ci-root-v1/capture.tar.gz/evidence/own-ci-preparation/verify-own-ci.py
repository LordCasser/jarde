#!/usr/bin/env python3
"""Independently verify a product receipt covering typed-list foreach leaf gates (read only)."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
REPO = 'LordCasser/jarde'
FIXTURE_ROOT = 'tests/fixtures'
FIXTURE_ROOTS = ('tests/fixtures/cf08-entry-split', 'tests/fixtures/cf08-if-loop-entry', 'tests/fixtures/cf09-literal-boolean-locals', 'tests/fixtures/foreach-local-bindings/debug', 'tests/fixtures/foreach-local-bindings/none', 'tests/fixtures/java8/assignment-condition-widening', 'tests/fixtures/java8/indexed-list-parameters', 'tests/fixtures/recover-proved-loop-continue-ladder-joins', 'tests/fixtures/typed-list-foreach')
EXPECTED_FIXTURE_FILES = ('tests/fixtures/cf08-entry-split/EntrySplitFixtureWriter.java', 'tests/fixtures/cf08-entry-split/EntrySplitOracleDriver.java', 'tests/fixtures/cf08-entry-split/EntrySplitSlotCounterCasesDriver.java', 'tests/fixtures/cf08-entry-split/EntrySplitSlotCounterCasesWriter.java', 'tests/fixtures/cf08-entry-split/README.md', 'tests/fixtures/cf08-entry-split/cf08/EntrySplitCases.class', 'tests/fixtures/cf08-entry-split/cf08/EntrySplitExceptionRefusal.class', 'tests/fixtures/cf08-entry-split/cf08/EntrySplitLegacyCases.class', 'tests/fixtures/cf08-entry-split/cf08/EntrySplitRefusals.class', 'tests/fixtures/cf08-entry-split/cf08/EntrySplitSlotCounterCases.class', 'tests/fixtures/cf08-entry-split/cf08/EntrySplitTopologyRefusals.class', 'tests/fixtures/cf08-entry-split/generalized-manifest.json', 'tests/fixtures/cf08-entry-split/manifest.json', 'tests/fixtures/cf08-if-loop-entry/README.md', 'tests/fixtures/cf08-if-loop-entry/TestLoopRestore2.raung', 'tests/fixtures/cf08-if-loop-entry/baseline/TestLoopRestore2.java', 'tests/fixtures/cf08-if-loop-entry/controls/LoopRestoreEffectPrefix.class', 'tests/fixtures/cf08-if-loop-entry/controls/LoopRestoreGotoW.class', 'tests/fixtures/cf08-if-loop-entry/licenses/JADX-LICENSE', 'tests/fixtures/cf08-if-loop-entry/licenses/JADX-NOTICE', 'tests/fixtures/cf08-if-loop-entry/licenses/RAUNG-MIT-LICENSE', 'tests/fixtures/cf08-if-loop-entry/make_controls.py', 'tests/fixtures/cf08-if-loop-entry/manifest.json', 'tests/fixtures/cf08-if-loop-entry/original.jar', 'tests/fixtures/cf08-if-loop-entry/original/loops/TestLoopRestore2.class', 'tests/fixtures/cf09-literal-boolean-locals/README.md', 'tests/fixtures/cf09-literal-boolean-locals/controls-src/BooleanLocalRefusals.java', 'tests/fixtures/cf09-literal-boolean-locals/controls/jdk23/BooleanLocalRefusals.class', 'tests/fixtures/cf09-literal-boolean-locals/controls/jdk8/BooleanLocalRefusals.class', 'tests/fixtures/cf09-literal-boolean-locals/manifest.json', 'tests/fixtures/cf09-literal-boolean-locals/original/debug-full-classes.jar', 'tests/fixtures/cf09-literal-boolean-locals/original/debug/classes/jadx/tests/integration/loops/TestBreakWithLabel$TestCls.class', 'tests/fixtures/cf09-literal-boolean-locals/original/debug/classes/jadx/tests/integration/loops/TestBreakWithLabel.class', 'tests/fixtures/cf09-literal-boolean-locals/original/no-debug-full-classes.jar', 'tests/fixtures/cf09-literal-boolean-locals/original/no-debug/classes/jadx/tests/integration/loops/TestBreakWithLabel$TestCls.class', 'tests/fixtures/cf09-literal-boolean-locals/original/no-debug/classes/jadx/tests/integration/loops/TestBreakWithLabel.class', 'tests/fixtures/cf09-literal-boolean-locals/prepare_controls.py', 'tests/fixtures/cf09-literal-boolean-locals/upstream/LICENSE', 'tests/fixtures/cf09-literal-boolean-locals/upstream/NOTICE', 'tests/fixtures/cf09-literal-boolean-locals/upstream/TestBreakWithLabel.java', 'tests/fixtures/foreach-local-bindings/debug/TestNestedLoops$TestCls.class', 'tests/fixtures/foreach-local-bindings/none/TestNestedLoops$TestCls.class', 'tests/fixtures/java8/assignment-condition-widening/JADX-LICENSE', 'tests/fixtures/java8/assignment-condition-widening/JADX-NOTICE', 'tests/fixtures/java8/assignment-condition-widening/README.md', 'tests/fixtures/java8/assignment-condition-widening/driver/LoopConditionInvokeControlDriver.java', 'tests/fixtures/java8/assignment-condition-widening/driver/TestLoopConditionInvokeDriver.java', 'tests/fixtures/java8/assignment-condition-widening/freeze-and-census.json', 'tests/fixtures/java8/assignment-condition-widening/javac23-debug/LoopConditionInvokeControl.class', 'tests/fixtures/java8/assignment-condition-widening/javac23-no-debug/LoopConditionInvokeControl.class', 'tests/fixtures/java8/assignment-condition-widening/javac8-debug/LoopConditionInvokeControl.class', 'tests/fixtures/java8/assignment-condition-widening/javac8-no-debug/LoopConditionInvokeControl.class', 'tests/fixtures/java8/assignment-condition-widening/source/LoopConditionInvokeControl.java', 'tests/fixtures/java8/assignment-condition-widening/source/TestLoopConditionInvoke.java', 'tests/fixtures/java8/assignment-condition-widening/upstream-debug/TestLoopConditionInvoke$TestCls.class', 'tests/fixtures/java8/assignment-condition-widening/upstream-no-debug/TestLoopConditionInvoke$TestCls.class', 'tests/fixtures/java8/indexed-list-parameters/NestedLoops2GenericControls.java', 'tests/fixtures/java8/indexed-list-parameters/README.md', 'tests/fixtures/java8/indexed-list-parameters/debug/NestedLoops2GenericControls.class', 'tests/fixtures/java8/indexed-list-parameters/no-debug/NestedLoops2GenericControls.class', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/README.md', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/manifest.json', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/LICENSE', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/NOTICE', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/TestContinueInLoop.java', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/TestContinueInLoopDriver.java', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/debug-plain.jar', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/debug/classes/jadx/tests/integration/loops/TestContinueInLoop$TestCls.class', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/debug/classes/jadx/tests/integration/loops/TestContinueInLoop.class', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/no-debug-plain.jar', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/no-debug/classes/jadx/tests/integration/loops/TestContinueInLoop$TestCls.class', 'tests/fixtures/recover-proved-loop-continue-ladder-joins/original/no-debug/classes/jadx/tests/integration/loops/TestContinueInLoop.class', 'tests/fixtures/typed-list-foreach/README.md', 'tests/fixtures/typed-list-foreach/TypedListForEachCases.class', 'tests/fixtures/typed-list-foreach/TypedListForEachCases.java')
SOURCE_PATHS = ('.github/workflows/ci.yml', 'Cargo.lock', 'Cargo.toml', 'crates/jarde-java/src/build.rs', 'crates/jarde-java/src/region.rs', 'crates/jarde-java/src/region/loop_arm_return_tests.rs', 'crates/jarde-java/src/report.rs', 'crates/jarde-reader/src/classfile.rs', 'src/bulk.rs', 'src/class_source.rs', 'src/facade.rs', 'tests/fixtures/corpus-fingerprint.json', 'tests/fixtures/foreach-local-bindings/source/TestNestedLoops.java', 'tests/fixtures/p3-iterable-foreach/IterableBoundaryRunner.java', 'tests/p3_assignment_condition_widening.rs', 'tests/p3_continue_ladder_joins.rs', 'tests/p3_entry_split_int_loops.rs', 'tests/p3_hoisted_boolean.rs', 'tests/p3_hoisted_iterator_foreach.rs', 'tests/p3_if_loop_entry_origins.rs', 'tests/p3_iterable_foreach.rs', 'tests/p3_nested_loop_side_exits.rs', 'tests/p3_proved_literal_boolean_locals.rs', 'tests/recover_lambda_primitive_array_capture.rs', 'tests/structured_list_generic_bodies.rs')
EXPECTED_JOBS = {
    'stable': 'stable / test and specification',
    'msrv': 'MSRV 1.88.0',
    'supply-chain': 'supply chain',
    'fuzz-smoke': 'fuzz smoke',
}
WORKSPACE_COMMAND = 'cargo test --workspace --all-targets --all-features --locked'
CRITICAL_TESTS = {
    'prefixed retry library proof': ('prefixed_exceptional_retry_uses_distinct_protected_and_handler_loop_edges', 'jarde_java'),
    'prefixed retry budget transaction': ('prefixed_exceptional_retry_late_budget_stop_restores_the_candidate_state', 'jarde_java'),
    'effectful bridge refusal': ('effectful_normal_join_bridge_is_refused_by_the_retry_certificate', 'jarde_java'),
    'outer-header catch refusal': ('catch_returning_to_the_outer_header_is_not_a_retry_continue', 'jarde_java'),
    'canonical row identity': ('retry_facts_require_the_physical_row_to_match_the_same_canonical_row', 'jarde_java'),
    'reader checkpoint stop': ('retry_facts_preserve_the_full_reader_checkpoint_on_cancel_and_deadline', 'jarde_java'),
    'owner edge closure': ('retry_owner_edge_closure_rejects_each_unowned_edge_class', 'jarde_java'),
    'original class-source matrix': ('prefixed_exceptional_retry_loop_is_structured_for_debug_and_no_debug_inputs', 'p3_prefixed_exceptional_retry_loops'),
    'public recovery late stop': ('prefixed_exceptional_retry_late_recovery_budget_publishes_no_source_or_map', 'p3_prefixed_exceptional_retry_loops'),
    'supplemental compiler/profile matrix': ('supplemental_pure_latch_bridges_keep_every_physical_source_origin', 'p3_prefixed_exceptional_retry_loops'),
}

CRITICAL_TESTS = {label: (('region::protected_prefix_loop_tests::' + name) if target == 'jarde_java' else name, target) for label, (name, target) in CRITICAL_TESTS.items()}
CRITICAL_TESTS.update({
    'loop arm return proof': ('region::loop_arm_return_tests::reader_loop_arm_return_leaf_and_latch_are_one_exact_owner_set', 'jarde_java'),
    'loop arm missing leaf and boundary rejection': ('region::loop_arm_return_tests::reader_loop_arm_return_proof_refuses_missing_leaf_scope_wrong_entry_and_latch', 'jarde_java'),
    'loop arm same BCI edge metamorphisms': ('region::loop_arm_return_tests::reader_branch_offset_metamorphisms_refuse_under_an_explicit_same_bci_proof_context', 'jarde_java'),
    'loop arm foreign clone context rejection': ('region::loop_arm_return_tests::real_jsr_clone_as_foreign_branch_context_is_refused_by_the_loop_consumer', 'jarde_java'),
    'loop arm compound tail certificate': ('region::loop_arm_return_tests::reader_compound_tail_requires_return_certificate_but_legacy_if_still_works', 'jarde_java'),
    'loop arm exception edge rejection': ('region::loop_arm_return_tests::real_exception_edge_incident_to_a_loop_refuses_the_arm_proof', 'jarde_java'),
    'loop arm stop publishes no partial claim': ('region::loop_arm_return_tests::reader_loop_arm_return_proof_publishes_no_partial_claim_on_budget_or_stop', 'jarde_java'),
    'original NL5 public recovery': ('original_nl5_loop_arm_returns_recover_all_three_physical_methods', 'p3_loop_arm_terminal_returns'),
    'parameterized loop arm public recovery': ('parameterized_a_and_b_loop_arm_returns_cover_all_javac_and_debug_inputs', 'p3_loop_arm_terminal_returns'),
    'loop arm public late stop': ('late_loop_arm_recovery_budget_stops_publish_no_partial_source_or_map', 'p3_loop_arm_terminal_returns'),
})
CURRENT_CRITICAL_TESTS = {
    'statementful original loop proof': ('region::statementful_loop_header_tests::original_debug_and_no_debug_keep_gateway_and_latch_sources', 'jarde_java'),
    'statementful supplemental profile proof': ('region::statementful_loop_header_tests::supplemental_profiles_keep_a_direct_exit_without_a_gateway', 'jarde_java'),
    'statementful unsupported-context boundary': ('region::statementful_loop_header_tests::unsupported_contexts_missing_facts_and_visited_gateway_refuse_without_claims', 'jarde_java'),
    'statementful stop transaction': ('region::statementful_loop_header_tests::canonical_edge_budget_cancel_and_deadline_stops_leave_owners_unclaimed', 'jarde_java'),
    'statementful effectful and multi-latch boundary': ('region::statementful_loop_header_tests::real_effectful_header_extra_body_exit_and_multiple_latches_refuse_directly', 'jarde_java'),
    'statementful dual-entry boundary': ('region::statementful_loop_header_tests::actual_dual_entry_view_is_recorded_and_any_natural_candidates_refuse', 'jarde_java'),
    'statementful JSR-clone boundary': ('region::statementful_loop_header_tests::actual_jsr_clone_bci23_can_be_used_only_as_a_cross_context_negative', 'jarde_java'),
    'legacy leading-tick loop remains structured': ('local_assignment_of_a_shared_condition_call_remains_a_structured_while', 'p3_for_latch'),
    'field-copy positive reader proof': ('build::tests::field_test_copy_tests::real_seq1_and_volatile_methods_have_one_saved_single_store_copy', 'jarde_java'),
    'field-copy owner and handler refusals': ('build::tests::field_test_copy_tests::real_other_receivers_non_int_fields_and_handler_rows_refuse_the_new_helper', 'jarde_java'),
    'field-copy cost stop proof': ('build::tests::field_test_copy_tests::exact_new_proof_cost_stop_and_pre_cancel_publish_no_copy_plan', 'jarde_java'),
    'statementful original public recovery': ('original_sequential_loops_keep_both_statementful_headers_and_full_classes', 'p3_statementful_loop_headers'),
    'statementful supplemental public recovery': ('effectful_sequential_loop_headers_preserve_complete_supplemental_methods', 'p3_statementful_loop_headers'),
    'volatile saved-copy public regression': ('saved_field_write_copies_cover_both_compilers_and_debug_profiles', 'p3_statementful_loop_headers'),
    'statementful public late stop': ('statementful_loop_late_budget_cancellation_and_deadline_publish_no_partial_result', 'p3_statementful_loop_headers'),
    'field-copy extra-stack boundary': ('build::tests::field_test_copy_tests::extra_stack_copy_after_store_is_rejected_by_the_actual_reader_helper_and_plan', 'jarde_java'),
    'field-copy missing-evidence boundary': ('build::tests::field_test_copy_tests::missing_field_evidence_context_refuses_an_otherwise_real_positive_reader_candidate', 'jarde_java'),
    'copy-control physical refusals': ('the_controls_keep_their_refusals_on_both_legs', 'recover_loop_test_copy_store'),
    'multi-consumer copy-control refusal': ('the_multi_consumer_control_keeps_its_refusal_on_both_legs', 'recover_loop_test_copy_store'),
    'loop-header parameter and multi-copy boundary': ('region::statementful_loop_header_tests::actual_parameter_and_multi_copy_loop_test_candidates_refuse_without_claims', 'jarde_java'),
    'sequential loop copy proof and stop transaction': ('region::statementful_loop_header_tests::real_sequential_loop_copy_candidate_accepts_and_stops_atomically', 'jarde_java'),
    'assignment-condition real widening proof': ('build::tests::proved_loop_assignment_consumes_real_char_and_only_known_widenings', 'jarde_java'),
    'assignment-condition public recovery controls': ('fixed_upstream_and_dynamic_controls_recover_the_widened_loop_condition', 'p3_assignment_condition_widening'),
    'assignment-condition public cancellation transaction': ('cancellation_does_not_publish_a_partial_condition_body', 'p3_assignment_condition_widening'),
}
CRITICAL_TESTS.update(CURRENT_CRITICAL_TESTS)
TYPED_FOREACH_CRITICAL_TESTS = {
    'typed foreach AST projection and origins': ('report::generic_call_ast_projection_tests::typed_foreach_projection_unwraps_only_the_binding_and_preserves_origins', 'jarde_java'),
    'typed foreach AST mismatch and foreign-plan refusal': ('report::generic_call_ast_projection_tests::typed_foreach_refuses_mismatched_or_foreign_site_plans_without_mutation', 'jarde_java'),
    'typed foreach AST nested traversal and atomic stop': ('report::generic_call_ast_projection_tests::typed_foreach_traversal_reaches_try_and_switch_bodies_and_stops_atomically', 'jarde_java'),
    'typed foreach public positive and typed-only projection': ('typed_list_foreach_element_heads_preserve_bindings_and_raw_origins', 'structured_list_generic_bodies'),
    'typed foreach public late deadline transaction': ('typed_foreach_late_deadline_keeps_raw_artifact_without_partial_projection', 'structured_list_generic_bodies'),
    'typed foreach neighboring public refusals': ('nearby_list_controls_refuse_only_unproved_generic_projections', 'structured_list_generic_bodies'),
    'nested iterator public positive regression': ('nested_iterators_project_and_preserve_the_outer_assignment_and_cast', 'p3_hoisted_iterator_foreach'),
    'nested iterator late budget and pre-cancel transaction': ('nested_foreach_late_stop_and_precancel_leave_no_partial_method_artifact', 'p3_hoisted_iterator_foreach'),
    'nested iterator adjacent public refusals': ('outer_assignment_foreach_public_api_and_real_controls_stay_conservative', 'p3_hoisted_iterator_foreach'),
}
TYPED_FOREACH_CRITICAL_COUNT = 9
CRITICAL_TESTS.update(TYPED_FOREACH_CRITICAL_TESTS)
BULK_RECOVERY_LIFECYCLE_TESTS = {
    'bulk class-task window overlap': ('at_most_the_window_of_class_tasks_runs_at_once_and_two_of_them_overlap', 'bulk_recovery_lifecycle'),
    'bulk worker panic joins before failure': ('a_worker_that_panics_fails_the_operation_and_leaves_no_thread_behind', 'bulk_recovery_lifecycle'),
    'bulk worker creation refusal precedes dispatch': ('a_worker_the_system_refuses_to_create_fails_the_operation_before_dispatching', 'bulk_recovery_lifecycle'),
    'bulk no-fault lifecycle result': ('a_run_without_faults_still_reports_its_own_lifecycle', 'bulk_recovery_lifecycle'),
}
BULK_RECOVERY_LIFECYCLE_CRITICAL_COUNT = 4
CRITICAL_TESTS.update(BULK_RECOVERY_LIFECYCLE_TESTS)
FOREACH_BINDING_FOLD_TESTS = {
    'foreach fold inner and visible outer bindings': ('report::generic_call_ast_projection_tests::typed_foreach_binding_fold_handles_inner_and_visible_outer_bindings', 'jarde_java'),
    'foreach fold direct first declaration': ('report::generic_call_ast_projection_tests::typed_foreach_binding_fold_promotes_direct_first_declaration', 'jarde_java'),
    'foreach fold refusal boundaries': ('report::generic_call_ast_projection_tests::typed_foreach_optional_fold_refuses_shadow_writes_captures_and_fallbacks', 'jarde_java'),
    'foreach fold stale-plan fallback': ('report::generic_call_ast_projection_tests::stale_optional_foreach_binding_plan_falls_back_to_typed_copy', 'jarde_java'),
    'foreach fold actual SSA closure': ('facade::generic_list_foreach_binding_slot_closed_tests::generic_list_foreach_binding_closes_actual_ssa_and_refuses_mutated_facts', 'jarde'),
    'nested foreach original class projection': ('original_nested_loops_folds_both_proven_local_bindings_without_changing_raw_sources', 'structured_list_generic_bodies'),
    'nested foreach atomic late stop': ('nested_foreach_late_cancel_budget_and_deadline_keep_raw_source_atomically', 'structured_list_generic_bodies'),
}
FOREACH_BINDING_FOLD_CRITICAL_COUNT = 7
CRITICAL_TESTS.update(FOREACH_BINDING_FOLD_TESTS)
ANCESTOR_ITERATOR_CLEANUP_TESTS = {
    'ancestor iterator physical local closure': ('build::tests::ancestor_iterator_cleanup_closes_the_complete_physical_local_variable', 'jarde_java'),
    'ancestor iterator unique visible row boundary': ('build::tests::ancestor_iterator_cleanup_requires_unique_direct_visible_iterator_row', 'jarde_java'),
}
ANCESTOR_ITERATOR_CLEANUP_CRITICAL_COUNT = 2
CRITICAL_TESTS.update(ANCESTOR_ITERATOR_CLEANUP_TESTS)
ENTRY_SPLIT_CRITICAL_TESTS = {
    'entry-split actual Region proof and stops': ('region::tests::entry_split_region_proof_uses_real_ir_and_stops_before_publication', 'jarde_java'),
    'entry-split original positive and slot variants': ('entry_split_integer_loop_accepts_signed_slot_and_polarity_variants', 'p3_entry_split_int_loops'),
    'entry-split unsupported proof controls': ('entry_split_controls_without_the_complete_int_proof_remain_quoted', 'p3_entry_split_int_loops'),
    'entry-split candidate atomic stop': ('entry_split_candidate_stops_do_not_publish_a_half_prefix', 'p3_entry_split_int_loops'),
    'entry-split topology and stack refusals': ('entry_split_topology_and_stack_controls_refuse_whole_methods', 'p3_entry_split_int_loops'),
    'entry-split legacy refusal': ('entry_split_legacy_subroutine_remains_outside_java8_proof', 'p3_entry_split_int_loops'),
    'entry-split exceptional refusal': ('entry_split_exceptional_prefix_remains_whole_method_refusal', 'p3_entry_split_int_loops'),
    'entry-split absent SSA stage': ('entry_split_analysis_request_can_omit_ssa_without_fabricating_that_stage', 'p3_entry_split_int_loops'),
    'entry-split nonzero value slot and counter-up controls': ('entry_split_accepts_nonzero_value_slot_and_counter_up', 'p3_entry_split_int_loops'),
    'entry-split output-byte stop transaction': ('entry_split_output_byte_stops_hit_each_prefix_copy_without_publishing_text', 'p3_entry_split_int_loops'),
    'entry-split source-map stop transaction': ('entry_split_sourcemap_stop_keeps_the_complete_body_and_only_a_reliable_prefix', 'p3_entry_split_int_loops'),
}
ENTRY_SPLIT_CRITICAL_COUNT = 11
CRITICAL_TESTS.update(ENTRY_SPLIT_CRITICAL_TESTS)
IF_LOOP_ENTRY_CRITICAL_TESTS = {
    'if-loop entry real proof': ('build::tests::if_arm_nested_loop_entry_origin_uses_real_transfer_and_edge_facts', 'jarde_java'),
    'if-loop entry public class and jar': ('if_loop_entry_origin_is_public_for_class_and_jar_inputs', 'p3_if_loop_entry_origins'),
    'if-loop entry public stop transaction': ('if_loop_entry_public_source_propagates_precancellation', 'p3_if_loop_entry_origins'),
}
IF_LOOP_ENTRY_CRITICAL_COUNT = 3
CRITICAL_TESTS.update(IF_LOOP_ENTRY_CRITICAL_TESTS)
LITERAL_BOOLEAN_CRITICAL_TESTS = {
    'literal boolean real SSA proof and complete access census': ('build::tests::literal_only_boolean_local_uses_the_real_read_phi_and_closes_the_full_access_census', 'jarde_java'),
    'literal boolean original class and JAR profiles': ('original_flag_is_boolean_through_class_and_plain_jar_default_and_all_profiles', 'p3_proved_literal_boolean_locals'),
    'literal boolean integer refusal controls': ('refusal_controls_keep_integer_consumers_and_reject_the_non_boolean_store', 'p3_proved_literal_boolean_locals'),
    'literal boolean public pre-cancellation': ('pre_cancelled_public_class_source_does_not_publish_a_class_artifact', 'p3_proved_literal_boolean_locals'),
    'literal boolean closed-return propagation regression': ('a_literal_local_with_a_closed_boolean_return_is_declared_boolean', 'p3_hoisted_boolean'),
}
LITERAL_BOOLEAN_CRITICAL_COUNT = 5
CRITICAL_TESTS.update(LITERAL_BOOLEAN_CRITICAL_TESTS)
CONTINUE_LADDER_CRITICAL_TESTS = {
    'continue ladder real region proof and budget stop': ('region::tests::continue_ladder_joins_close_the_real_loop_and_stop_on_budget', 'jarde_java'),
    'continue ladder original class and JAR source contract': ('original_debug_no_debug_class_and_plain_jar_share_the_public_source_contract', 'p3_continue_ladder_joins'),
    'continue ladder public pre-cancellation': ('original_public_class_source_propagates_precancellation', 'p3_continue_ladder_joins'),
}
CONTINUE_LADDER_CRITICAL_COUNT = 3
CRITICAL_TESTS.update(CONTINUE_LADDER_CRITICAL_TESTS)
ARRAY_SUBTRACT_CRITICAL_TESTS = {
    'proved integer array subtract real IR and boundary regressions': ('build::tests::proved_int_array_subtract_uses_real_ir_and_keeps_existing_boundaries', 'jarde_java'),
}
ARRAY_SUBTRACT_CRITICAL_COUNT = 1
CRITICAL_TESTS.update(ARRAY_SUBTRACT_CRITICAL_TESTS)

ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
SUMMARY = re.compile(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out(?:; finished in .*)?$')
NAME_FRAGMENT = r'(?:[A-Za-z0-9_]|(?<!\*)\*\*\*(?!\*))+'
OUTCOME = re.compile(rf'^test ((?:{NAME_FRAGMENT})(?:::(?:{NAME_FRAGMENT}))*)(?: - should panic)? \.\.\. (ok|FAILED|ignored(?:, .*)?)$')
RUNNING = re.compile(r'^running (\d+) tests?$', re.IGNORECASE)
RUN_TARGET = re.compile(r'^Running .+ \((?P<path>[^()]+)\)$')
HASHED_EXE = re.compile(r'(?P<target>[^/]+)-(?P<hash>[0-9a-f]{16})')


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def clean_line(line: str) -> str:
    line = ANSI.sub('', line).strip()
    line = re.sub(r'\^\[\[[0-?]*[ -/]*[@-~]', '', line)
    line = re.sub(r'^[^\t\n]+\t[^\t\n]+\t(?=\d{4}-\d\d-\d\dT)', '', line)
    line = re.sub(r'^\d{4}-\d\d-\d\d[T ][^ ]+Z\s+', '', line)
    return line.strip()


def workflow_contract(path: Path):
    text = path.read_text(encoding='utf-8')
    lines = text.splitlines()
    jobs = {}
    i = next((n for n, line in enumerate(lines) if line == 'jobs:'), None)
    need(i is not None, 'CI workflow has no jobs section')
    i += 1
    while i < len(lines):
        m = re.match(r'^  ([a-z][a-z0-9-]*):\s*$', lines[i])
        if m:
            job_id = m.group(1)
            block = []
            i += 1
            while i < len(lines) and not re.match(r'^  [a-z][a-z0-9-]*:\s*$', lines[i]) and not re.match(r'^[^ ]', lines[i]):
                block.append(lines[i])
                i += 1
            display_match = next((re.match(r'^    name:\s*(.*?)\s*$', row) for row in block if re.match(r'^    name:', row)), None)
            display = display_match.group(1).strip('\"\'') if display_match else None
            api_steps = []
            run_steps = []
            j = 0
            while j < len(block):
                step = re.match(r'^      - (name|uses):\s*(.*?)\s*$', block[j])
                if not step:
                    j += 1
                    continue
                kind, value = step.group(1), step.group(2).strip('\"\'')
                k = j + 1
                has_run = bool(re.match(r'^        run:', block[j]))
                while k < len(block) and not re.match(r'^      - (?:name|uses):', block[k]):
                    has_run |= bool(re.match(r'^        run:', block[k]))
                    k += 1
                if kind == 'name':
                    api_steps.append(value)
                    if has_run:
                        run_steps.append(value)
                else:
                    api_steps.append(f'Run {value}')
                j = k
            jobs[job_id] = {'display': display, 'api_steps': api_steps, 'run_steps': run_steps}
        else:
            i += 1
    need(set(jobs) == set(EXPECTED_JOBS), f'CI job IDs differ from reviewed contract: {sorted(jobs)}')
    for job_id, display in EXPECTED_JOBS.items():
        need(jobs[job_id]['display'] == display, f'CI job display name changed: {job_id}')
        need(jobs[job_id]['api_steps'] and jobs[job_id]['run_steps'], f'CI workflow has incomplete steps: {job_id}')
    required_run_steps = {
        'stable': {
            'Install stable Rust with lint components', 'Install Temurin 25.0.4+7', 'Run Clippy',
            'Run workspace tests with two fixed independent seeds (pass 1)',
            'Run workspace tests with two fixed independent seeds (pass 2)',
            'Run ignored JDK 25 instruction-boundary oracle',
            'Run the ignored P3 Java 8 compile-and-execute comparison',
            'Run the functional-constructor full-class comparison',
            'Run the BigDecimal Number full-class comparisons',
            'Run the nested int array full-class comparisons',
            'Run the returned int array full-class comparison',
        },
        'msrv': {'Install Rust 1.88.0', 'Check workspace on MSRV'},
        'supply-chain': {
            'Install cargo-deny 0.20.2',
            'Check root workspace advisories, licenses, bans, and sources',
            'Check fuzz workspace advisories, licenses, bans, and sources',
        },
        'fuzz-smoke': {
            'Install nightly-2026-07-20', 'Install cargo-fuzz 0.13.2',
            'Check the committed corpus against the targets', 'Run the bounded query smoke',
            'Run the bounded artifact-tree smoke', 'Run the bounded method-analysis smoke',
        },
    }
    for job_id, required in required_run_steps.items():
        need(required.issubset(set(jobs[job_id]['api_steps'])),
             f'required platform/JDK/MSRV/Clippy/extra gate missing in {job_id}: {sorted(required - set(jobs[job_id]["api_steps"]))}')

    seeds = []
    for name in ('Run workspace tests with two fixed independent seeds (pass 1)',
                 'Run workspace tests with two fixed independent seeds (pass 2)'):
        match = re.search(r'(?ms)^      - name: ' + re.escape(name) + r'\n(.*?)(?=^      - (?:name|uses):|^  [a-z][a-z0-9-]*:|\Z)', text)
        need(match is not None, f'CI workflow is missing workspace run step {name}')
        block = match.group(1)
        cmd = re.search(r'(?m)^        run:\s*(.*?)\s*$', block)
        seed = re.search(r'(?m)^          PROPTEST_RNG_SEED:\s*["\']?(\d+)', block)
        need(cmd and cmd.group(1).strip('\"\'') == WORKSPACE_COMMAND, f'workspace command changed: {name}')
        need(seed is not None, f'workspace seed is absent: {name}')
        seeds.append(seed.group(1))
    need(len(set(seeds)) == 2, f'workspace seeds must be distinct: {seeds}')
    return text, jobs, tuple(seeds)


def validate_collection(evidence: Path, product: str, repo: Path):
    receipt = read_json(evidence / 'collection.json')
    need(receipt.get('status') == 'raw collection complete; independent acceptance pending', 'collector did not finish raw collection')
    need(receipt.get('product_sha') == product, 'collector receipt product SHA mismatch')
    need(receipt.get('source_before_after_equal') is True and receipt.get('target_absent_after') is True,
         'collector did not confirm unchanged source and absent target')
    fixture_dirs = tuple(repo / rel for rel in FIXTURE_ROOTS)
    need(all(p.is_dir() and not p.is_symlink() for p in fixture_dirs), 'one or more fixture roots are missing or unsafe')
    fixture_paths = sorted(p.relative_to(repo).as_posix() for root in fixture_dirs for p in root.rglob('*') if p.is_file())
    need(len(fixture_paths) == len(set(fixture_paths)) and fixture_paths, 'fixture roots overlap or contain no files')
    need(tuple(fixture_paths) == EXPECTED_FIXTURE_FILES, f'complete fixture inventory differs: {fixture_paths}')
    need(receipt.get('fixture_roots') == list(FIXTURE_ROOTS) and receipt.get('fixture_files') == fixture_paths, 'collector fixture inventory differs from complete current inventory')
    sources = sorted(set(SOURCE_PATHS) | set(fixture_paths))
    need(receipt.get('source_paths') == list(SOURCE_PATHS), 'collector source path inventory changed')
    need(receipt.get('fixture_file_count') == len(fixture_paths) and receipt.get('source_file_count') == len(SOURCE_PATHS),
         'collector source counts are inconsistent')
    commands = receipt.get('commands')
    need(isinstance(commands, list) and commands, 'collector has no commands')
    for row in commands:
        need(row.get('exit_code') == 0, f'collector command failed: {row.get("argv")}')
        for channel in ('stdout', 'stderr'):
            pin = row.get('streams', {}).get(channel, {})
            path = Path(pin.get('path', ''))
            need(path.is_absolute() and path.is_file(), f'raw command {channel} is absent')
            data = path.read_bytes()
            need(pin.get('bytes') == len(data) and pin.get('sha256') == sha(data), f'raw command {channel} pin mismatch: {path}')
    pin_doc = read_json(evidence / 'source-pins.json')
    need(pin_doc.get('product_sha') == product and pin_doc.get('fixture_root') == FIXTURE_ROOT and pin_doc.get('fixture_roots') == list(FIXTURE_ROOTS), 'source-pins product/fixture roots mismatch')
    source_rows, fixture_rows = pin_doc.get('source_files'), pin_doc.get('fixture_files')
    need(isinstance(source_rows, dict) and set(source_rows) == set(SOURCE_PATHS), 'source pin inventory differs')
    need(isinstance(fixture_rows, dict) and set(fixture_rows) == set(fixture_paths), 'fixture pin inventory differs')
    for rel in sources:
        is_fixture = any(rel.startswith(root + '/') for root in FIXTURE_ROOTS)
        path = evidence / ('product-fixtures' if is_fixture else 'product-source') / rel
        pinned = path.read_bytes()
        current = (repo / rel).read_bytes()
        row = fixture_rows[rel] if is_fixture else source_rows[rel]
        need(pinned == current, f'product git-show differs from current file: {rel}')
        need(row.get('git_show') == f'git show {product}:{rel}' and row.get('bytes') == len(pinned) and row.get('sha256') == sha(pinned),
             f'product source pin mismatch: {rel}')
    workflow_pin = source_rows['.github/workflows/ci.yml']['sha256']
    need((evidence / 'workflow.sha256').read_text(encoding='ascii').strip() == workflow_pin, 'workflow pin file mismatch')
    expected_commands = 2 + len(EXPECTED_JOBS) + len(sources)
    need(len(commands) == expected_commands, f'collector command count mismatch: {len(commands)} != {expected_commands}')
    by_stdout = {}
    for row in commands:
        path = Path(row['streams']['stdout']['path']).resolve()
        need(path.is_relative_to(evidence), f'command output escapes evidence directory: {path}')
        rel = path.relative_to(evidence).as_posix()
        need(rel not in by_stdout, f'duplicate command output path: {rel}')
        by_stdout[rel] = row
        need(Path(row['streams']['stderr']['path']).resolve() == Path(str(path) + '.stderr.raw'),
             f'stderr path does not pair with stdout artifact: {rel}')
    run_id = str(receipt.get('run_id'))
    expected_args = {
        'run.json': ['gh', 'run', 'view', run_id, '--repo', REPO,
                     '--json', 'jobs,headSha,status,conclusion,url,databaseId,workflowName'],
        'jobs-api.json': ['gh', 'api', f'repos/{REPO}/actions/runs/{run_id}/jobs?per_page=100'],
    }
    run_doc = read_json(evidence / 'run.json')
    run_jobs = run_doc.get('jobs', [])
    jobs_by_name = {job.get('name'): job for job in run_jobs}
    need(set(jobs_by_name) == set(EXPECTED_JOBS.values()), 'run.json job names differ while verifying command arguments')
    for slug, display in EXPECTED_JOBS.items():
        expected_args[slug + '.log'] = ['gh', 'run', 'view', run_id, '--repo', REPO,
                                        '--job', str(jobs_by_name[display].get('databaseId')), '--log']
    for rel in sources:
        out_rel = ('product-fixtures/' if any(rel.startswith(root + '/') for root in FIXTURE_ROOTS) else 'product-source/') + rel
        expected_args[out_rel] = ['git', 'show', product + ':' + rel]
    need(set(by_stdout) == set(expected_args), 'raw command output inventory differs from expected gh/git-show requests')
    for rel, argv in expected_args.items():
        need(by_stdout[rel].get('argv') == argv and by_stdout[rel].get('exit_code') == 0,
             f'raw command arguments/result differ from requested evidence operation: {rel}')
    return receipt, pin_doc


DERIVED_STEP_PROOFS = []

def official_step_logs(evidence: Path):
    supplement = read_json(evidence / 'step-log-supplement.json')
    run_id = str(receipt_run_id(evidence))
    need(supplement['argv'] == ['gh', 'api', f'repos/{REPO}/actions/runs/{run_id}/logs'] and supplement['exit_code'] == 0, 'official step archive request mismatch')
    need(supplement.get('run_id') == run_id and supplement.get('product_sha') == read_json(evidence / 'collection.json').get('product_sha'), 'official archive is not bound to the collected run/product')
    need(supplement.get('collection_json_sha256') == sha((evidence / 'collection.json').read_bytes()) and supplement.get('run_json_sha256') == sha((evidence / 'run.json').read_bytes()), 'official archive collection/run binding digest mismatch')
    for channel in ('stdout', 'stderr'):
        pin = supplement['streams'][channel]
        path = Path(pin['path'])
        need(path.parent == evidence and path.is_file(), 'official archive stream path mismatch')
        data = path.read_bytes()
        need(len(data) == pin['bytes'] and sha(data) == pin['sha256'], 'official archive stream pin mismatch')
    need(Path(supplement['streams']['stdout']['path']) == evidence / 'run-logs.zip', 'official archive path mismatch')
    api = read_json(evidence / 'jobs-api.json')
    logs = {}
    with zipfile.ZipFile(evidence / 'run-logs.zip') as archive:
        names = archive.namelist()
        need(len(names) == len(set(names)), 'duplicate official archive entry')
        for job in api['jobs']:
            display = job['name']
            folder = display.replace('/', '_')
            lines = []
            for step in job['steps']:
                name = f"{folder}/{step['number']}_{step['name'].replace('/', '_')}.txt"
                need(name in names, f'official ZIP lacks independent per-step member: {name}')
                raw = archive.read(name)
                lines.extend(f"{display}\t{step['name']}\t{line}" for line in raw.decode('utf-8-sig').splitlines())
            logs[display] = '\n'.join(lines) + '\n'
    return logs


def validate_ci(evidence: Path, product: str, workflow_jobs: dict):
    run = read_json(evidence / 'run.json')
    api = read_json(evidence / 'jobs-api.json')
    need(run.get('headSha') == product and run.get('status') == 'completed' and run.get('conclusion') == 'success', 'CI run head/status/conclusion failed')
    need(run.get('workflowName') == 'CI', 'CI workflow identity mismatch')
    need(api.get('total_count') == 4 and isinstance(api.get('jobs'), list) and len(api['jobs']) == 4, 'GitHub jobs API is incomplete')
    run_jobs = run.get('jobs')
    need(isinstance(run_jobs, list) and len(run_jobs) == 4, 'gh run view job inventory incomplete')
    by_name = {row.get('name'): row for row in run_jobs}
    api_by_id = {row.get('id'): row for row in api['jobs']}
    need(len(by_name) == 4 and set(by_name) == set(EXPECTED_JOBS.values()) and len(api_by_id) == 4, 'CI job inventory differs')
    report, total_steps = {}, 0
    official = official_step_logs(evidence)
    for job_id, display in EXPECTED_JOBS.items():
        run_job = by_name[display]
        api_job = api_by_id.get(run_job.get('databaseId'))
        need(api_job is not None and api_job.get('name') == display, f'jobs API omitted or renamed {display}')
        need(run_job.get('status') == 'completed' and run_job.get('conclusion') == 'success'
             and api_job.get('status') == 'completed' and api_job.get('conclusion') == 'success', f'job failed or incomplete: {display}')
        run_steps, api_steps = run_job.get('steps'), api_job.get('steps')
        need(isinstance(run_steps, list) and isinstance(api_steps, list) and len(run_steps) == len(api_steps) and run_steps,
             f'job step inventory incomplete: {display}')
        for left, right in zip(run_steps, api_steps):
            need(left.get('name') == right.get('name'), f'run view and jobs API step order mismatch: {display}')
            need(left.get('status') == 'completed' and left.get('conclusion') == 'success'
                 and right.get('status') == 'completed' and right.get('conclusion') == 'success',
                 f'non-success workflow step in {display}: {left.get("name")}')
        names = [step.get('name') for step in api_steps]
        need(all(isinstance(name, str) and name for name in names), f'unnamed API step in {display}')
        expected = workflow_jobs[job_id]['api_steps']
        observed = [name for name in names if name not in ('Set up job', 'Complete job') and not name.startswith('Post ')]
        need(observed == expected, f'actual step sequence differs from workflow for {display}')
        posts = [name[5:] for name in names if name.startswith('Post ')]
        need(len(posts) == len(set(posts)) and all(name in expected for name in posts), f'unknown/duplicate post-action in {display}')
        need(names and names[0] == 'Set up job' and names[-1] == 'Complete job', f'job lifecycle steps invalid: {display}')
        need(len(names) == len(expected) + len(posts) + 2 and len(names) == len(set(names)), f'extra/duplicate API step in {display}')
        total_steps += len(names)
        report[job_id] = {'display_name': display, 'steps': len(names), 'successful_steps': len(names),
                          'workflow_steps': len(expected), 'run_steps': len(workflow_jobs[job_id]['run_steps'])}
        log = evidence / (job_id + '.log')
        need(log.is_file() and log.stat().st_size > 0, f'complete raw job log is absent: {job_id}')
        log_rows = [line.split('\t', 2) for line in official[display].splitlines()]
        labels = {row[1] for row in log_rows if len(row) == 3 and row[0] == display}
        need(labels, f'raw job log has no records for {display}')
        need({row[0] for row in log_rows if len(row) == 3} == {display}, f'raw log mixes job identities: {display}')
        need(set(workflow_jobs[job_id]['run_steps']).issubset(labels), f'raw job log omits named run-step output: {display}')
    need(str(receipt_run_id(evidence)) == str(run.get('databaseId')), 'run ID differs between receipt and captured CI run')
    return run, report, total_steps


def receipt_run_id(evidence: Path):
    return read_json(evidence / 'collection.json').get('run_id')


def workspace_groups(raw: str):
    lines = raw.splitlines()
    starts = [i for i, line in enumerate(lines) if '##[group]Run ' + WORKSPACE_COMMAND in clean_line(line)]
    need(len(starts) == 2, f'stable log must contain exactly two complete workspace runs, found {len(starts)}')
    groups = []
    for p, start in enumerate(starts):
        end = starts[p + 1] if p + 1 < len(starts) else len(lines)
        for n in range(start + 1, end):
            if '##[group]' in clean_line(lines[n]):
                end = n
                break
        groups.append('\n'.join(lines[start:end]))
    return groups


def parse_workspace_group(group: str, seed: str):
    lines = [clean_line(line) for line in group.splitlines()]
    env = [re.fullmatch(r'PROPTEST_RNG_SEED:\s*["\']?(\d+)["\']?', line) for line in lines if 'PROPTEST_RNG_SEED:' in line]
    need(len(env) == 1 and env[0] is not None and env[0].group(1) == seed, f'workspace log seed differs from workflow: {seed}')
    headers = [line for line in lines if line.startswith('Running ')]
    outcomes, rows = [], []
    i = 0
    while i < len(lines):
        m = RUNNING.fullmatch(lines[i])
        if not m:
            if lines[i].startswith('test result:'):
                raise ValueError(f'test summary without running block: {lines[i]}')
            i += 1
            continue
        declared, named = int(m.group(1)), []
        j = i + 1
        while j < len(lines):
            summary = SUMMARY.fullmatch(lines[j])
            if summary:
                counts = tuple(int(summary.group(n)) for n in range(2, 5))
                measured, filtered = int(summary.group(5)), int(summary.group(6))
                need((summary.group(1) == 'ok') == (counts[1] == 0), f'summary status/count mismatch: {lines[j]}')
                need(declared == len(named), f'running count differs from named outcomes: {declared} != {len(named)}')
                seen = (sum(state == 'ok' for _, state in named), sum(state == 'FAILED' for _, state in named), sum(state == 'ignored' for _, state in named))
                need(seen == counts, f'named test results do not reconstruct summary: {seen} != {counts}')
                need(counts[1] == 0 and filtered == 0, f'target failed or filtered tests: {lines[j]}')
                rows.append({'named_tests': declared, 'passed': counts[0], 'failed': counts[1], 'ignored': counts[2],
                             'measured': measured, 'filtered': filtered, '_named': named})
                i = j + 1
                break
            result = OUTCOME.fullmatch(lines[j])
            if result:
                raw_state = result.group(2)
                named.append((result.group(1), 'ignored' if raw_state.startswith('ignored') else raw_state))
            elif lines[j].startswith('test result:') or lines[j].startswith('test '):
                raise ValueError(f'unparsed cargo test output: {lines[j]}')
            j += 1
        else:
            raise ValueError(f'running block has no complete summary: {lines[i]}')
    need(rows and len(headers) == len(rows), 'workspace target headers and summaries are incomplete')
    for row, header in zip(rows, headers):
        match = RUN_TARGET.fullmatch(header)
        need(match is not None, f'unparsed Cargo Running header: {header!r}')
        executable = match.group('path').rsplit('/', 1)[-1]
        executable_match = HASHED_EXE.fullmatch(executable)
        need(executable_match is not None, f'unrecognized Cargo executable: {executable!r}')
        row['target_header'], row['target_executable'] = header, executable
        row['target_name'] = executable_match.group('target')
        outcomes.extend((name, state, row['target_name']) for name, state in row.pop('_named'))
    need(sum(row['named_tests'] for row in rows) == len(outcomes), 'not every observed test result is accounted for')
    inventory = [row['target_header'] for row in rows]
    need(len(inventory) == len(set(inventory)), 'duplicate cargo target header')
    checks = {}
    for label, (name, target) in CRITICAL_TESTS.items():
        matches = [(state, target_name) for seen, state, target_name in outcomes
                   if seen == name and target_name == target]
        need(len(matches) == 1 and matches[0][0] == 'ok', f'critical test missing/duplicated/failing under exact target: {label}')
        checks[label] = name
    totals = {key: sum(row[key] for row in rows) for key in ('passed', 'failed', 'ignored', 'measured', 'filtered')}
    need(totals['failed'] == 0 and totals['filtered'] == 0, 'workspace run has failed or filtered tests')
    return {'seed': seed, 'target_count': len(rows), 'target_inventory': inventory,
            'target_summaries': rows, 'named_test_outcomes': len(outcomes),
            'workspace_totals': totals, 'critical_tests_passed': checks}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence_dir', type=Path)
    parser.add_argument('--product-sha', required=True)
    parser.add_argument('--cli-sha256', required=True, help='CLI SHA256 independently pinned by the final broad gate')
    parser.add_argument('--extra-critical', action='append', default=[], metavar='TARGET=FULL_TEST_NAME',
                        help='additional exact proof gate; repeat for each unique target/name pair, e.g. jarde=module::test')
    parser.add_argument('--repo', type=Path, default=ROOT)
    args = parser.parse_args()
    need(re.fullmatch(r'[0-9a-f]{40}', args.product_sha) is not None, 'PRODUCT_SHA must be lowercase full SHA')
    need(re.fullmatch(r'[0-9a-f]{64}', args.cli_sha256) is not None, 'CLI_SHA256 must be lowercase SHA256')
    additional_proof_gates = []
    known_gate_pairs = set(CRITICAL_TESTS.values())
    for number, spec in enumerate(args.extra_critical, start=1):
        target, separator, name = spec.partition('=')
        need(separator == '=' and target in {'jarde', 'jarde_java', 'structured_list_generic_bodies', 'p3_nested_loop_side_exits', 'p3_iterable_foreach', 'recover_lambda_primitive_array_capture', 'jarde_reader', 'p3_if_loop_entry_origins', 'p3_continue_ladder_joins'} and name and not any(ch.isspace() for ch in name),
             'each additional gate must be TARGET=FULL_TEST_NAME with an exact known target')
        pair = (name, target)
        need(pair not in known_gate_pairs, f'duplicate critical target/name identity: {target}={name}')
        known_gate_pairs.add(pair)
        label = f'additional proof gate {number}: {target}::{name}'
        need(label not in CRITICAL_TESTS, f'duplicate critical gate label: {label}')
        CRITICAL_TESTS[label] = pair
        additional_proof_gates.append({'target': target, 'test_name': name})
    evidence, repo = args.evidence_dir.resolve(strict=True), args.repo.resolve(strict=True)
    receipt, pins = validate_collection(evidence, args.product_sha, repo)
    need(receipt.get('cli_sha256') == args.cli_sha256, 'collector receipt CLI SHA256 differs from independently supplied final CLI pin')
    need(pins.get('cli_sha256') == args.cli_sha256, 'source-pins CLI SHA256 differs from independently supplied final CLI pin')
    workflow, jobs_contract, seeds = workflow_contract(repo / '.github/workflows/ci.yml')
    need(pins['source_files']['.github/workflows/ci.yml']['sha256'] == sha(workflow.encode()), 'captured workflow differs from current source')
    run, jobs, total_steps = validate_ci(evidence, args.product_sha, jobs_contract)
    log = official_step_logs(evidence)[EXPECTED_JOBS['stable']]
    seed_runs = [parse_workspace_group(group, seed) for group, seed in zip(workspace_groups(log), seeds)]
    need(seed_runs[0]['seed'] == seeds[0] and seed_runs[1]['seed'] == seeds[1], 'seed order differs from current workflow')
    need(seed_runs[0]['target_summaries'] == seed_runs[1]['target_summaries'], 'complete per-target summaries differ across the two seeds')
    need(seed_runs[0]['target_inventory'] == seed_runs[1]['target_inventory'], 'target inventory differs across seeds')
    need(len(CRITICAL_TESTS) - len(TYPED_FOREACH_CRITICAL_TESTS) - len(BULK_RECOVERY_LIFECYCLE_TESTS) - len(FOREACH_BINDING_FOLD_TESTS) - len(ANCESTOR_ITERATOR_CLEANUP_TESTS) - len(ENTRY_SPLIT_CRITICAL_TESTS) - len(IF_LOOP_ENTRY_CRITICAL_TESTS) - len(LITERAL_BOOLEAN_CRITICAL_TESTS) - len(CONTINUE_LADDER_CRITICAL_TESTS) - len(ARRAY_SUBTRACT_CRITICAL_TESTS) - len(args.extra_critical) == 44 and len(LITERAL_BOOLEAN_CRITICAL_TESTS) == LITERAL_BOOLEAN_CRITICAL_COUNT and len(ENTRY_SPLIT_CRITICAL_TESTS) == ENTRY_SPLIT_CRITICAL_COUNT and len(IF_LOOP_ENTRY_CRITICAL_TESTS) == IF_LOOP_ENTRY_CRITICAL_COUNT and len(TYPED_FOREACH_CRITICAL_TESTS) == TYPED_FOREACH_CRITICAL_COUNT and len(BULK_RECOVERY_LIFECYCLE_TESTS) == BULK_RECOVERY_LIFECYCLE_CRITICAL_COUNT and len(FOREACH_BINDING_FOLD_TESTS) == FOREACH_BINDING_FOLD_CRITICAL_COUNT and len(ANCESTOR_ITERATOR_CLEANUP_TESTS) == ANCESTOR_ITERATOR_CLEANUP_CRITICAL_COUNT and len(CRITICAL_TESTS) == 89 + len(args.extra_critical), 'preserved inherited/leaf gates or entry-split gates changed')
    need(set(CURRENT_CRITICAL_TESTS).issubset(seed_runs[0]['critical_tests_passed']) and set(CURRENT_CRITICAL_TESTS).issubset(seed_runs[1]['critical_tests_passed']), 'inherited current-change gate outcomes are incomplete')
    need(set(TYPED_FOREACH_CRITICAL_TESTS).issubset(seed_runs[0]['critical_tests_passed']) and set(TYPED_FOREACH_CRITICAL_TESTS).issubset(seed_runs[1]['critical_tests_passed']), 'typed-foreach gate outcomes are incomplete')
    need(set(BULK_RECOVERY_LIFECYCLE_TESTS).issubset(seed_runs[0]['critical_tests_passed']) and set(BULK_RECOVERY_LIFECYCLE_TESTS).issubset(seed_runs[1]['critical_tests_passed']), 'bulk recovery lifecycle gate outcomes are incomplete')
    need(set(FOREACH_BINDING_FOLD_TESTS).issubset(seed_runs[0]['critical_tests_passed']) and set(FOREACH_BINDING_FOLD_TESTS).issubset(seed_runs[1]['critical_tests_passed']), 'foreach binding fold gate outcomes are incomplete')
    need(set(ANCESTOR_ITERATOR_CLEANUP_TESTS).issubset(seed_runs[0]['critical_tests_passed']) and set(ANCESTOR_ITERATOR_CLEANUP_TESTS).issubset(seed_runs[1]['critical_tests_passed']), 'ancestor iterator cleanup gate outcomes are incomplete')
    need(set(ENTRY_SPLIT_CRITICAL_TESTS).issubset(seed_runs[0]['critical_tests_passed']) and set(ENTRY_SPLIT_CRITICAL_TESTS).issubset(seed_runs[1]['critical_tests_passed']), 'entry-split gate outcomes are incomplete')
    need(set(IF_LOOP_ENTRY_CRITICAL_TESTS).issubset(seed_runs[0]['critical_tests_passed']) and set(IF_LOOP_ENTRY_CRITICAL_TESTS).issubset(seed_runs[1]['critical_tests_passed']), 'if-loop entry gate outcomes are incomplete')
    need(set(LITERAL_BOOLEAN_CRITICAL_TESTS).issubset(seed_runs[0]['critical_tests_passed']) and set(LITERAL_BOOLEAN_CRITICAL_TESTS).issubset(seed_runs[1]['critical_tests_passed']), 'literal boolean gate outcomes are incomplete')
    need(set(CONTINUE_LADDER_CRITICAL_TESTS).issubset(seed_runs[0]['critical_tests_passed']) and set(CONTINUE_LADDER_CRITICAL_TESTS).issubset(seed_runs[1]['critical_tests_passed']), 'continue-ladder gate outcomes are incomplete')
    need(set(ARRAY_SUBTRACT_CRITICAL_TESTS).issubset(seed_runs[0]['critical_tests_passed']) and set(ARRAY_SUBTRACT_CRITICAL_TESTS).issubset(seed_runs[1]['critical_tests_passed']), 'array-subtract gate outcomes are incomplete')
    api_step_count = sum(len(job.get('steps', [])) for job in read_json(evidence / 'jobs-api.json')['jobs'])
    derived_count = len(DERIVED_STEP_PROOFS)
    if derived_count:
        derived_names = ', '.join(proof['step']['name'] for proof in DERIVED_STEP_PROOFS)
        step_authority = (f'Official ZIP: {api_step_count - derived_count} per-step members plus '
                          f'{derived_count} uniquely bound aggregate step body/bodies ({derived_names}); '
                          f'all {api_step_count} API steps checked. Original gh logs and retries retained.')
    else:
        step_authority = (f'Official ZIP: all {api_step_count} per-step members present and checked; '
                          'no aggregate reconstruction was needed. Original gh logs and retries retained.')
    report = {
        'status': 'accepted', 'step_log_authority': step_authority, 'supplemental_log_command_count': 1, 'aggregate_step_proofs': DERIVED_STEP_PROOFS, 'product': {'head_sha': run['headSha'], 'expected_sha': args.product_sha, 'cli_sha256': args.cli_sha256},
        'collection': {'run_id': receipt['run_id'], 'command_count': len(receipt['commands']),
                       'source_file_count': receipt['source_file_count'], 'fixture_file_count': receipt['fixture_file_count']},
        'workflow': {'path': str(repo / '.github/workflows/ci.yml'), 'sha256': sha(workflow.encode()),
                     'job_api_steps': {key: len(value['api_steps']) for key, value in jobs_contract.items()},
                     'job_run_steps': {key: len(value['run_steps']) for key, value in jobs_contract.items()}},
        'ci': {'job_count': len(jobs), 'expanded_api_step_count': total_steps, 'jobs': jobs},
        'workspace_seed_runs': seed_runs,
        'critical_gate_count': len(CRITICAL_TESTS),
        'additional_proof_gates': additional_proof_gates,
        'raw_job_log_sha256': {slug + '.log': sha((evidence / (slug + '.log')).read_bytes()) for slug in EXPECTED_JOBS},
        'gates': {'workspace_tests': 'both fixed seeds; complete named outcomes and per-target summaries parsed',
                  'new_prefixed_retry_tests': '7 exact jarde_java tests and 3 exact integration-target tests passed once per seed',
                  'new_loop_arm_return_tests': '7 exact jarde_java tests and 3 exact p3_loop_arm_terminal_returns tests passed once per seed',
                  'new_statementful_loop_tests': '16 exact current target/test identities passed once per seed',
                  'typed_foreach_leaf_tests': f'{len(TYPED_FOREACH_CRITICAL_TESTS)} exact target/test identities passed once per seed',
                  'bulk_recovery_lifecycle_tests': f'{len(BULK_RECOVERY_LIFECYCLE_TESTS)} exact target/test identities passed once per seed',
                  'foreach_binding_fold_tests': f'{len(FOREACH_BINDING_FOLD_TESTS)} exact target/test identities passed once per seed',
                  'ancestor_iterator_cleanup_tests': f'{len(ANCESTOR_ITERATOR_CLEANUP_TESTS)} exact target/test identities passed once per seed',
                  'entry_split_tests': f'{len(ENTRY_SPLIT_CRITICAL_TESTS)} exact target/test identities passed once per seed',
                  'if_loop_entry_tests': f'{len(IF_LOOP_ENTRY_CRITICAL_TESTS)} exact target/test identities passed once per seed',
                  'literal_boolean_local_tests': f'{len(LITERAL_BOOLEAN_CRITICAL_TESTS)} exact target/test identities passed once per seed',
                  'continue_ladder_tests': f'{len(CONTINUE_LADDER_CRITICAL_TESTS)} exact target/test identities passed once per seed',
                  'array_subtract_tests': f'{len(ARRAY_SUBTRACT_CRITICAL_TESTS)} exact target/test identities passed once per seed',
                  'legacy statementful-loop regression': 'the exact p3_for_latch target/test identity passed once per seed',
                  'loop-test-copy controls and proof-context gates': 'two exact public refusal tests and two exact jarde_java proof tests passed once per seed',
                  'platform_jdk_msrv_clippy_ignored_extras': 'every declared CI API job step completed successfully'},
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print(f'CI verification failed: {exc}', file=sys.stderr)
        raise SystemExit(1)
