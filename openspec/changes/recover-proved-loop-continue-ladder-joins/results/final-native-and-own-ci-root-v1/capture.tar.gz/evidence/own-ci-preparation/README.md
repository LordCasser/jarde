# Continue-ladder native and own-CI preparation (not executed)

This private preparation adapts the accepted literal-boolean native/own-CI verifiers and the retry-enabled own-CI/official-log collectors. It contains no current product result and claims no pass.

The native verifier retains all prior exact identities and adds four: the Region proof/budget-stop test, the public debug/no-debug class and plain-JAR regression, the public pre-cancellation test, and the array subtract proof. Expected native count: 57 (56 from v1 plus one new). The own-CI verifier has 89 built-in identities (88 from v1 plus one new), retains all 13 inherited `--extra-critical` identities, and checks 102 identities total. The CI checker requires the same named identities once in each of its two fixed workspace seeds. Workspace targets and test summaries are read from live metadata and logs rather than fixed totals.

The collectors and verifier bind 25 source paths (the previous 24 plus `tests/p3_continue_ladder_joins.rs`) and an exact sorted fixture inventory across nine roots. The new root `tests/fixtures/recover-proved-loop-continue-ladder-joins` contains 12 files. Product commit, CLI digest, CI run, and fresh evidence paths remain explicit placeholders. The CI transport collector retains each failed request attempt and binds canonical streams to the successful attempt; the official per-step ZIP collection remains a separate explicit command.

The two public test identities are present in the current test file. The planned Region identity `region::tests::continue_ladder_joins_close_the_real_loop_and_stop_on_budget` is not present in current shared source at preparation time; the implementation owner must add it before native/CI verification. The Reader census source is already pinned in the inherited source list; no future fixture fingerprint digest is hardcoded here. No Cargo, Java, CLI, Git, GitHub, or network command was run.


V2 adds the planned native gate `jarde_java=build::tests::proved_int_array_subtract_uses_real_ir_and_keeps_existing_boundaries` to native and both-seed CI verification. This gate is not yet present in shared source at preparation time. The collectors, 13 inherited extra-critical arguments, 25 source paths, and 75-file fixture inventory are unchanged from v1.
