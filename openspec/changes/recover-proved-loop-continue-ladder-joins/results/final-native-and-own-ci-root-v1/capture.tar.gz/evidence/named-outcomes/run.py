import sys,json,hashlib,subprocess,datetime,shutil
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).parent;PREP=Path('/private/tmp/jarde-continue-ladder-own-ci-prep-luna-v2-20261019');CI=Path('/private/tmp/jarde-continue-ladder-own-ci-root-v1-20261019');ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
PRODUCT='050cedbd255ffaddf9e51acf8d2ad52fe573519b';CLI='6c83ec82cd4c6caee86c08e7fefddc2fea675952f936c0e4aa3f295ed9be7fc6'
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not CI.exists() and not (HERE/'execution.json').exists() and not (ROOT/'target').exists()
w=json.loads(Path('/private/tmp/jarde-continue-ladder-ci-wait-root-v1-20261019/execution.json').read_bytes());assert w['status']=='completed' and w['exit_code']==0
assert h(PREP/'verify-own-ci.py')=='8e8cf04947efee1ac057084e58df907e847900ec43c98a302753a63d492f7278'
a=json.loads((PREP/'acceptance-argv.json').read_bytes())['verify_ci'];a[0]=sys.executable;a[1]=str(PREP/'verify-own-ci.py');a[2]=str(CI);a[a.index('--product-sha')+1]=PRODUCT;a[a.index('--cli-sha256')+1]=CLI;a.insert(1,'-B');assert a.count('--extra-critical')==13
argvs=[[sys.executable,'-B',str(PREP/'collect-own-ci.py'),str(CI),'39193571868',PRODUCT,CLI],[sys.executable,'-B',str(PREP/'collect-official-logs.py'),str(CI)],a,[sys.executable,'-B','/private/tmp/jarde-continue-ladder-final-named-observer-root-v2-20261019/verify.py',str(CI),str(HERE/'named-review.json')]]
r={'status':'running','product':PRODUCT,'ci_run':'39193571868','cli_sha256':CLI,'commands':[]}
def save(): (HERE/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for i,argv in enumerate(argvs):
  out=HERE/f'{i}.stdout.raw';err=HERE/f'{i}.stderr.raw';row={'argv':argv,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  with out.open('xb') as so,err.open('xb') as se: x=subprocess.run(argv,cwd=ROOT,stdout=so,stderr=se)
  row.update(exit_code=x.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=h(out),stderr_sha256=h(err));r['commands'].append(row);save();assert x.returncode==0,(i,err.read_text()[-2000:])
  if i==2:
   accepted=json.loads(out.read_bytes());assert accepted['status']=='accepted' and accepted['critical_gate_count']==102 and accepted['aggregate_step_proofs']==[]
   with (CI/'review.json').open('xb') as dest:dest.write(out.read_bytes())
 r['status']='root_executed_collection_and_exact_reviewers_pending_architect_acceptance'
except BaseException as e:
 r.update(status='failed',error=repr(e));raise
finally:
 r['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({'status':r['status'],'command_exit_codes':[x['exit_code'] for x in r['commands']]}))
