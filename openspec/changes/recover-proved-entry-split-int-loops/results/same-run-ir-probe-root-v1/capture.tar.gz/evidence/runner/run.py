from pathlib import Path
import hashlib,json,subprocess,sys,shutil
R=Path('/Users/lordcasser/workspace/projects/jarde');PREP=Path('/private/tmp/jarde-entry-split-probe-prep-luna-v1-20261019');OUT=Path('/private/tmp/jarde-entry-split-same-run-ir-probe-root-v1-20261019');assert not OUT.exists() and not (R/'target').exists();OUT.mkdir();(OUT/'raw').mkdir()
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
region=R/'crates/jarde-java/src/region.rs';test=R/'crates/jarde-java/src/region/entry_split_loop_probe_tests.rs';fixture_dir=R/'tests/fixtures/recover-proved-entry-split-int-loops';fixture=fixture_dir/'MultiEntryCounter.class'
assert pin(region)['sha256']=='9e27c9bee263a9fa2d09c1860e6cfcb45605b16b92e524c92009d156f18b59ea'
assert pin(PREP/'entry_split_loop_probe_tests.rs')['sha256']=='0c170b4c590e2e3d28bc8eb717a8ec23b32e7fef8b0be5dae5a0b2c0d0cc1b50'
assert pin(PREP/'tests/fixtures/recover-proved-entry-split-int-loops/MultiEntryCounter.class')['sha256']=='fe1a87ea523c10649ea3141d89b9ce04a2c2cfb6e8c31e70479193794311e2fb'
assert not test.exists() and not fixture_dir.exists()
original=region.read_bytes();(OUT/'region.rs.original').write_bytes(original)
rec={'status':'running','runner':pin(__file__),'region_before':pin(region),'probe':pin(PREP/'entry_split_loop_probe_tests.rs'),'fixture':pin(PREP/'tests/fixtures/recover-proved-entry-split-int-loops/MultiEntryCounter.class'),'commands':[]}
def save():(OUT/'execution.json').write_text(json.dumps(rec,indent=2)+'\n')
def command(argv,label):
 so=OUT/'raw'/(label+'.stdout.raw');se=OUT/'raw'/(label+'.stderr.raw')
 with so.open('xb') as f,se.open('xb') as g:p=subprocess.run(argv,cwd=R,stdout=f,stderr=g)
 rec['commands'].append({'argv':argv,'label':label,'exit_code':p.returncode,'stdout':pin(so),'stderr':pin(se)});save();return p.returncode
try:
 assert command(['git','apply','--check',str(PREP/'changes.patch')],'patch-check')==0
 assert command(['git','apply',str(PREP/'changes.patch')],'patch-apply')==0
 shutil.copyfile(PREP/'entry_split_loop_probe_tests.rs',test);fixture_dir.mkdir();shutil.copyfile(PREP/'tests/fixtures/recover-proved-entry-split-int-loops/MultiEntryCounter.class',fixture)
 (OUT/'region.rs.with-probe').write_bytes(region.read_bytes());shutil.copyfile(test,OUT/test.name);shutil.copyfile(fixture,OUT/fixture.name)
 rec['source_at_build']=[pin(region),pin(test),pin(fixture)];save()
 spec=OUT/'commands.json';spec.write_text(json.dumps([['cargo','test','-p','jarde-java','--lib','region::entry_split_loop_probe_tests::entry_split_multientry_same_run_ir_probe','--','--exact','--nocapture']])+'\n')
 rc=command([sys.executable,'-B',str(R/'openspec/changes/recover-branch-throw-return-finally/tools/run_validation.py'),str(OUT/'build'),str(spec)],'guarded-probe')
 rec['guarded_exit_code']=rc;rec['status']='captured_pending_architect_review' if rc==0 else 'failed'
except BaseException as e:rec['status']='failed';rec['error']=repr(e);raise
finally:
 region.write_bytes(original)
 if test.exists():assert pin(test)['sha256']==rec['probe']['sha256'];test.unlink()
 if fixture.exists():assert pin(fixture)['sha256']==rec['fixture']['sha256'];fixture.unlink();fixture_dir.rmdir()
 rec['region_after']=pin(region);rec['source_restored']=region.read_bytes()==original and not test.exists() and not fixture_dir.exists();rec['target_absent']=not (R/'target').exists();save();print(json.dumps({k:rec.get(k) for k in ('status','guarded_exit_code','source_restored','target_absent','error')}),flush=True)
sys.exit(0 if rec['status']=='captured_pending_architect_review' and rec['source_restored'] and rec['target_absent'] else 1)
