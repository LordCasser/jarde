//! Same-run Reader/IR evidence probe for the CF08 entry-split int loop.
//! Run with --nocapture; this reports facts rather than assuming a recovery shape.
use super::*;
use jarde_jvm::engine::analyze_method_ir;
use jarde_jvm::environment::ResolutionEnvironment;
use jarde_jvm::ir::{AnalysisStage, MethodAnalysisRequest};
use jarde_reader::artifact::{ArtifactInput, ArtifactSnapshot};
use jarde_reader::budget::{Budget, Limits};
use jarde_reader::model::{ClassBytesId, Digest, JvmBytes, PhysicalClassLocation, PhysicalDefinitionId, PhysicalMethodId, PhysicalVariant};
use jarde_reader::view::{DelegationPolicy, LayoutMode, LoadDomain, LoadRoot, LoaderId, ModuleMode, MultiReleasePolicy, PhysicalScope, PhysicalView, RuntimeProfile, RuntimeUncertainty, RuntimeView};
use std::collections::{BTreeSet, HashSet};
const INPUT: &[u8] = include_bytes!("../../../../tests/fixtures/recover-proved-entry-split-int-loops/MultiEntryCounter.class");
fn budget() -> Budget {
    Budget::new(Limits { input_bytes: 1 << 20, archive_entries: 100, entry_bytes: 1 << 20, read_bytes: 1 << 20, class_bytes: 1 << 20, attribute_bytes: 1 << 20, code_bytes: 1 << 20, result_items: 1 << 20, output_bytes: 1 << 20, class_headers: 100, method_bodies: 100, ir_items: 1 << 20, ir_edges: 1 << 20, analysis_steps: 1 << 20, normalization_clones: 1 << 20, nested_depth: 32, dependency_depth: 32, elapsed_millis: u64::MAX })
}
fn visit(node: usize, view: &NormalFlowView, seen: &mut HashSet<usize>, order: &mut Vec<usize>) {
    if !seen.insert(node) { return; }
    for next in view.successors(node) { visit(next, view, seen, order); }
    order.push(node);
}
fn collect_reverse(node: usize, view: &NormalFlowView, seen: &mut HashSet<usize>, out: &mut Vec<usize>) {
    if !seen.insert(node) { return; }
    out.push(node);
    for prev in view.predecessors(node) { collect_reverse(prev, view, seen, out); }
}
fn normal_sccs(view: &NormalFlowView) -> Vec<Vec<usize>> {
    let mut seen = HashSet::new(); let mut order = Vec::new();
    for node in 0..view.len() { visit(node, view, &mut seen, &mut order); }
    seen.clear(); let mut components = Vec::new();
    while let Some(node) = order.pop() {
        if seen.contains(&node) { continue; }
        let mut component = Vec::new(); collect_reverse(node, view, &mut seen, &mut component);
        if component.len() > 1 || view.successors(node).contains(&node) { components.push(component); }
    }
    components
}
#[test]
fn entry_split_multientry_same_run_ir_probe() {
    let mut b = budget();
    let snapshot = ArtifactSnapshot::open(ArtifactInput::bytes(INPUT.to_vec()), &mut b).expect("pinned whole class parses");
    let definition = PhysicalDefinitionId { location: PhysicalClassLocation::StandaloneRoot { snapshot: snapshot.id().clone() }, class_bytes: ClassBytesId { digest: Digest(blake3::hash(INPUT).to_hex().to_string()), length: u64::try_from(INPUT.len()).expect("fixture size fits") }, variant: PhysicalVariant::Base };
    let domain = LoadDomain { loader: LoaderId("app".to_owned()), parent_loader: None, delegation: DelegationPolicy::ParentFirst, roots: vec![LoadRoot::StandaloneClass { snapshot: snapshot.id().clone() }], module_mode: ModuleMode::ClassPath, external_override: RuntimeUncertainty::None, runtime_transformation: RuntimeUncertainty::None };
    let method = PhysicalMethodId { owner: definition, name: JvmBytes(b"test".to_vec()), descriptor: JvmBytes(b"(IZI)I".to_vec()) };
    let analysis = analyze_method_ir(&[snapshot.clone()], &MethodAnalysisRequest { environment: ResolutionEnvironment { runtime: RuntimeView { physical: PhysicalView { snapshot: snapshot.id().clone(), scope: PhysicalScope::SnapshotAll }, profile: RuntimeProfile { java_release: 8, multi_release: MultiReleasePolicy::Disabled, layout: LayoutMode::Generic }, load_domain: domain.clone() }, domains: vec![domain], providers: Vec::new() }, method, stages: AnalysisStage::ALL.to_vec() }, &mut b).expect("same-run MethodAnalysis completes");
    let ir = analysis.ir(); let canonical = ir.canonical().expect("canonical facts published"); let frames = ir.frames().expect("frame facts published"); let ssa = ir.ssa().expect("SSA facts published"); let code = ir.code().expect("physical Code facts published");
    let operations = Operations::of(code, ir.constant_pool()); let mut vb = budget(); let view = NormalFlowView::build(canonical, &mut vb).expect("normal-flow view from this IR");
    eprintln!("PROBE class=cf08/MultiEntryCounter method=test(IZI)I bytes={} code_span={:?} max_stack={} max_locals={} completeness={:?}", INPUT.len(), code.code_span, code.max_stack, code.max_locals, canonical.completeness());
    eprintln!("PROBE physical_handlers={:?} local_debug={:?}", code.exception_handlers, code.debug());
    eprintln!("PROBE physical_instructions={:#?}", code.instructions);
    eprintln!("PROBE physical_operations={:#?}", operations.iter().collect::<Vec<_>>());
    eprintln!("PROBE canonical_blocks={:#?}", canonical.blocks()); eprintln!("PROBE canonical_edges={:#?}", canonical.edges());
    eprintln!("PROBE canonical_throw_sites={:#?} handler_rows={:#?} unreachable={:#?}", canonical.throw_sites(), canonical.handler_rows(), canonical.unreachable());
    for component in normal_sccs(&view) {
        let nodes: BTreeSet<_> = component.iter().copied().collect();
        let entries: Vec<_> = component.iter().copied().filter(|node| *node == 0 || view.predecessors(*node).iter().any(|pred| !nodes.contains(pred))).collect();
        let ids: Vec<_> = component.iter().filter_map(|node| view.id_of(*node)).collect(); let entry_ids: Vec<_> = entries.iter().filter_map(|node| view.id_of(*node)).collect();
        eprintln!("PROBE normal_scc nodes={ids:?} external_entries={entry_ids:?}");
    }
    for block in frames.blocks() { eprintln!("PROBE frame block={:?} locals={:?} stack={:?} logical_inputs={:?}", block.block(), block.locals(), block.stack(), block.inputs()); }
    for (id, value) in ssa.values_with_ids() { eprintln!("PROBE value id={id:?} type={:?} def={:?} origin={:?} uses={:?} replaced_by={:?}", value.ty(), value.def(), value.origin(), value.uses(), value.replaced_by()); }
    for phi in ssa.phis() { eprintln!("PROBE phi block={:?} slot={:?} value={:?} inputs={:?}", phi.block(), phi.slot(), phi.value(), phi.inputs()); }
    for block in ssa.blocks() { eprintln!("PROBE ssa_block={:#?}", block); }
    for effect in ssa.effects().instructions() { eprintln!("PROBE effect bci={} opcode=0x{:02x} locals_read={:?} locals_written={:?} stack_delta={} may_throw={} handlers={:?} origin={:?}", effect.bci(), effect.opcode(), effect.locals_read(), effect.locals_written(), effect.stack_delta(), effect.may_throw(), effect.handlers(), effect.origin()); }
    for insn in &code.instructions {
        if matches!(operations.get(insn.bci), Some(Operation::Increment { .. })) || insn.opcode == 0xac {
            let rows: Vec<_> = ssa.blocks().iter().flat_map(|block| block.instructions()).filter(|row| row.bci() == insn.bci).collect();
            eprintln!("PROBE update_or_return bci={} physical={:?} operation={:?} ssa={rows:#?}", insn.bci, insn, operations.get(insn.bci));
        }
    }
    assert_eq!(code.instructions.len(), 9, "pinned physical Code instruction inventory remains whole");
}
