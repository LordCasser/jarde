# Entry-split loop IR probe preparation

Private preparation only. Nothing was applied to the shared repository and no Cargo/JDK/CLI command was run.

Input is `/private/tmp/jarde-cf08-multientry-baseline-root-v1-20261019/original-classes/cf08/MultiEntryCounter.class` from the captured `original-classes/cf08/MultiEntryCounter.class` root. It is copied byte-for-byte to `tests/fixtures/recover-proved-entry-split-int-loops/MultiEntryCounter.class`.

- Input bytes: 271; SHA-256 `fe1a87ea523c10649ea3141d89b9ce04a2c2cfb6e8c31e70479193794311e2fb`
- Fixture SHA-256 `fe1a87ea523c10649ea3141d89b9ce04a2c2cfb6e8c31e70479193794311e2fb`
- Probe SHA-256 `0c170b4c590e2e3d28bc8eb717a8ec23b32e7fef8b0be5dae5a0b2c0d0cc1b50`
- Proposed shared-tree change: `changes.patch` adds only a `#[cfg(test)]` module declaration to `crates/jarde-java/src/region.rs`; copy the probe source and fixture to matching paths when integrating. Patch SHA-256 `7cfbb57b01ecdd06d86a521d905685230c34c361fa504a94b3bf0dc4f6e95057`; patch-base `region.rs` SHA-256 `9e27c9bee263a9fa2d09c1860e6cfcb45605b16b92e524c92009d156f18b59ea`

The probe requests `AnalysisStage::ALL` for `test(IZI)I` through `analyze_method_ir`; it uses that request's canonical CFG, frames, SSA, code facts, operation decode, and `NormalFlowView`. It emits physical instructions/effects, canonical blocks and every edge kind, normal SCCs and external-entry nodes, frame local types, SSA values/definitions/uses/replacements/phis, and update/return cross-links by BCI. The only assertion checks the pinned method's nine decoded instructions. It intentionally does not assert an unverified graph or SSA identity.

After copying the source and fixture and applying the module hunk, root can run:

```sh
cargo test -p jarde-java entry_split_multientry_same_run_ir_probe -- --nocapture
```

This is a facts probe for task 1.2, not implementation or acceptance. Hypothesis only: a reused integer local may have distinct SSA values at distinct entry paths, with a phi at a merge. Root should derive whether a phi exists and which exact increment/read/return values it relates from emitted facts.
