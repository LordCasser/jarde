#!/usr/bin/env python3
"""Pack and reopen the reviewed task-1.2 EntrySplit IR probe evidence."""
from __future__ import annotations
import argparse, hashlib, io, json, stat, tarfile
from pathlib import Path

PRIVATE = Path('/private/tmp').resolve()
PREP = Path(__file__).resolve().parent
RESULT = PRIVATE / 'jarde-entry-split-same-run-ir-probe-root-v1-20261019'
RUNNER = PRIVATE / 'jarde-entry-split-probe-runner-root-v1-20261019'
ORIGINAL_PREP = PREP / 'original-probe-prep-snapshot'
EXPECTED_RECEIPT_SHA = '998950251afc9f8bb4b758720da7ce6b0a9743437d92cd8758295abe255105f4'
EXPECTED_REGION_SHA = '9e27c9bee263a9fa2d09c1860e6cfcb45605b16b92e524c92009d156f18b59ea'
EXPECTED_FIXTURE_SHA = 'fe1a87ea523c10649ea3141d89b9ce04a2c2cfb6e8c31e70479193794311e2fb'
EXCLUDED = {'target', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache', '.cache', 'node_modules'}

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)
def load(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))
def pin(path: Path) -> dict:
    need(path.is_file() and not path.is_symlink(), f'missing/unsafe file: {path}')
    data = path.resolve(strict=True).read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': sha(data)}
def nested_values(value):
    if isinstance(value, dict):
        for key, item in value.items():
            yield key
            yield from nested_values(item)
    elif isinstance(value, list):
        for item in value:
            yield from nested_values(item)
    else:
        yield value

def verify(review_path: Path) -> dict:
    receipt_path = RESULT / 'execution.json'
    receipt_bytes = receipt_path.read_bytes()
    need(sha(receipt_bytes) == EXPECTED_RECEIPT_SHA, 'probe receipt SHA changed')
    receipt = json.loads(receipt_bytes)
    need(receipt.get('status') == 'captured_pending_architect_review', 'raw receipt status was rewritten')
    need(receipt.get('guarded_exit_code') == 0, 'guarded probe did not exit zero')
    need(receipt.get('source_restored') is True and receipt.get('target_absent') is True,
         'probe cleanup or source restoration failed')
    need(receipt.get('region_before', {}).get('sha256') == EXPECTED_REGION_SHA
         and receipt.get('region_after') == receipt.get('region_before'),
         'live region.rs was not restored to the pinned baseline')
    need(receipt.get('fixture', {}).get('sha256') == EXPECTED_FIXTURE_SHA,
         'receipt fixture pin mismatch')
    labels = {row.get('label'): row for row in receipt.get('commands', [])}
    need(set(labels) == {'patch-check', 'patch-apply', 'guarded-probe'}, 'probe command inventory changed')
    need(all(row.get('exit_code') == 0 for row in labels.values()), 'one of the three recorded commands failed')
    build_path = RESULT / 'build' / 'execution.json'
    build_bytes = build_path.read_bytes()
    build = json.loads(build_bytes)
    need(build.get('status') == 'commands_passed_pending_independent_acceptance', 'build receipt status changed')
    need(build.get('default_stack') is True and build.get('source_unchanged') is True
         and build.get('source_changes') == [] and build.get('source_changes_accepted') is True
         and build.get('target_absent') is True, 'build guard/cleanup facts changed')
    need(build.get('source_before') == build.get('source_after'), 'captured source closure changed during probe')
    commands = build.get('commands', [])
    need(len(commands) == 2 and all(row.get('exit_code') == 0 for row in commands),
         'expected one exact probe command plus cargo clean')
    expected_argv = ['cargo', 'test', '-p', 'jarde-java', '--lib',
                     'region::entry_split_loop_probe_tests::entry_split_multientry_same_run_ir_probe',
                     '--', '--exact', '--nocapture']
    need(commands[0].get('argv') == expected_argv, 'actual Cargo argv differs from the exact probe')
    need(commands[1].get('argv') == ['cargo', 'clean'], 'cargo clean command changed')
    output = (RESULT / 'build' / 'raw' / '1.stdout.raw').read_bytes() + (RESULT / 'build' / 'raw' / '1.stderr.raw').read_bytes()
    need(b'test result: ok. 1 passed; 0 failed;' in output, 'exact probe test result missing')
    need(output.count(b'PROBE phi ') == 6 and output.count(b'PROBE value id=') == 14
         and output.count(b'PROBE normal_scc ') == 1, 'reviewed IR fact census changed')
    need((RESULT / 'MultiEntryCounter.class').is_file()
         and sha((RESULT / 'MultiEntryCounter.class').read_bytes()) == EXPECTED_FIXTURE_SHA,
         'copied physical fixture changed')
    need((RESULT / 'region.rs.original').is_file()
         and sha((RESULT / 'region.rs.original').read_bytes()) == EXPECTED_REGION_SHA,
         'restored baseline source snapshot changed')
    need(review_path.is_file() and not review_path.is_symlink(), 'root architecture review is missing')
    review = load(review_path)
    need(EXPECTED_RECEIPT_SHA in {str(x) for x in nested_values(review)},
         'architecture review does not bind the exact execution receipt SHA')
    canonical = RESULT / 'root-review.json'
    if canonical.exists():
        marker = load(canonical)
        need(marker.get('status') == review.get('status')
             and marker.get('receipt_sha256') == EXPECTED_RECEIPT_SHA
             and marker.get('architecture_review') == str(review_path.resolve()),
             'root-review.json does not bind the accepted architecture review')
    return {'receipt_sha256': EXPECTED_RECEIPT_SHA, 'receipt_status': receipt['status'],
            'root_review_sha256': sha(review_path.read_bytes()),
            'build_receipt_sha256': sha(build_bytes), 'build_commands': len(commands),
            'probe_stdout_stderr_bytes': len(output), 'source_inventory_entries': len(build['source_before']),
            'source_restored': receipt['source_restored'], 'target_absent': receipt['target_absent']}

def gather(review_path: Path) -> dict[str, Path]:
    roots = [(RESULT, 'evidence/probe-result'), (RUNNER, 'evidence/runner'),
             (ORIGINAL_PREP, 'evidence/original-probe-prep'), (PREP, 'archive-preparation')]
    members: dict[str, Path] = {}
    def add(name: str, path: Path):
        need(name not in members, f'duplicate archive member: {name}')
        need(path.is_file() and not path.is_symlink(), f'missing/unsafe member: {path}')
        members[name] = path.resolve(strict=True)
    for root, prefix in roots:
        need(root.is_dir() and not root.is_symlink(), f'missing/unsafe evidence root: {root}')
        for path in sorted(root.rglob('*')):
            if any(part in EXCLUDED for part in path.parts):
                continue
            if root == PREP and (PREP / 'original-probe-prep-snapshot') in path.parents:
                continue
            need(not path.is_symlink(), f'refuse symlink in evidence tree: {path}')
            if path.is_file():
                add(prefix + '/' + path.relative_to(root).as_posix(), path)
    review_path = review_path.resolve(strict=True)
    need(review_path.parent == RESULT.resolve(), 'architecture review must be in the probe result directory')
    need('evidence/probe-result/' + review_path.name in members, 'architecture review was not gathered')
    return dict(sorted(members.items()))

def verify_frozen_pins(members: dict[str, Path]) -> None:
    pins_path = PREP / 'pins.json'
    pins = load(pins_path)
    expected = {row['path']: row for row in pins['archive_inputs']}
    actual = {name: path for name, path in members.items() if not name.startswith('archive-preparation/')}
    need(set(actual) == set(expected), 'archive evidence input set differs from frozen pins')
    for name, path in actual.items():
        row = expected[name]; data = path.read_bytes()
        need(len(data) == row['bytes'] and sha(data) == row['sha256'], f'frozen input changed: {name}')
    prep_expected = pins['preparation_files']
    prep_actual = {p.relative_to(PREP).as_posix(): p for p in PREP.rglob('*')
                   if p.is_file() and p.name != 'pins.json'
                   and not (PREP / 'original-probe-prep-snapshot') in p.parents
                   and not any(part in EXCLUDED for part in p.parts)}
    need(set(prep_actual) == set(prep_expected), 'archive preparation file set differs from frozen pins')
    for name, path in prep_actual.items():
        row = prep_expected[name]; data = path.read_bytes()
        need(len(data) == row['bytes'] and sha(data) == row['sha256'], f'preparation file changed: {name}')

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True, help='new .tar.gz destination; must not exist')
    parser.add_argument('--review', type=Path, default=RESULT / 'architecture-review.json',
                        help='root-authored architecture-review.json bound to execution.json')
    args = parser.parse_args()
    out = args.out.resolve()
    inventory_path = out.with_suffix(out.suffix + '.inventory.json')
    need(not out.exists() and not inventory_path.exists(), 'refuse to overwrite an archive or inventory')
    need(not out.is_relative_to(PREP), 'archive must be outside the preparation directory')
    review_summary = verify(args.review)
    members = gather(args.review)
    verify_frozen_pins(members)
    rows = []
    for arcname, path in members.items():
        data = path.read_bytes()
        rows.append({'path': arcname, 'bytes': len(data), 'sha256': sha(data),
                     'mode': stat.S_IMODE(path.stat().st_mode)})
    manifest = {
        'schema': 'recover-proved-entry-split-int-loop-ir-probe-archive-v1',
        'status': 'root-reviewed-probe-evidence',
        'scope': 'Task 1.2 same-run IR facts probe only; not implementation, behavioral loop execution, or feature acceptance.',
        'review_summary': review_summary,
        'member_count': len(rows), 'members': rows,
        'external_binary_policy': 'Cargo/Rust/JDK/CLI and dependency installations are not copied; command receipts retain tool paths and pins.',
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(out, 'x:gz') as archive:
        for arcname, path in members.items():
            archive.add(path, arcname=arcname, recursive=False)
        blob = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
        info = tarfile.TarInfo('ARCHIVE_INVENTORY.json'); info.size = len(blob); info.mode = 0o644
        archive.addfile(info, io.BytesIO(blob))
    with tarfile.open(out, 'r:gz') as archive:
        files = {row.name: row for row in archive.getmembers() if row.isfile()}
        need(set(files) == {row['path'] for row in rows} | {'ARCHIVE_INVENTORY.json'}, 'reopened archive member set differs')
        for row in rows:
            data = archive.extractfile(files[row['path']]).read()
            need(len(data) == row['bytes'] and sha(data) == row['sha256'], f'archive member mismatch: {row["path"]}')
        need(json.loads(archive.extractfile(files['ARCHIVE_INVENTORY.json']).read()) == manifest,
             'embedded archive inventory mismatch')
    inventory_bytes = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    with inventory_path.open('xb') as stream:
        stream.write(inventory_bytes)
    print(json.dumps({'status': 'packed-and-reopened', 'archive': str(out),
                      'archive_sha256': sha(out.read_bytes()), 'inventory': str(inventory_path),
                      'inventory_sha256': sha(inventory_bytes), 'member_count': len(rows)}, indent=2))

if __name__ == '__main__':
    main()
