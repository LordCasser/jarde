# EntrySplit IR 探针证据包准备

这是 OpenSpec `recover-proved-entry-split-int-loops` task 1.2 的单次、只读 IR 事实探针归档器。探针运行已由 root 单独执行；本目录仅准备持久化脚本与说明，不运行 Cargo/JDK/CLI，不修改共享工作树。

实际输入是完整的 `cf08/MultiEntryCounter.class`（271 字节，SHA-256 `fe1a87ea523c10649ea3141d89b9ce04a2c2cfb6e8c31e70479193794311e2fb`）。执行收据 SHA-256 为 `998950251afc9f8bb4b758720da7ce6b0a9743437d92cd8758295abe255105f4`。记录显示临时探针已清理、源码已恢复、`target` 不存在；cargo exact probe 为 1 passed、0 failed、506 filtered，可用磁盘空间至少 5 GiB 的启动门、1 GiB target 目录上限、默认 Rust 栈，构建 source closure 前后 3215 项相同。

实际报告了 6 条 canonical normal edge、一个含两个外部入口（block 4 与 7）的 SCC、6 个 phi、14 个 SSA value 和 9 个 effects；entry descriptor `(IZI)I` 对应参数来源类型 Int/Boolean/Int。证据把 `iinc`@4 的前缀链、`iinc`@11 的计数器链和 `ireturn`@18 的读取值分别锚定到 SSA phis/definitions。root 的架构审查结论是：必须使用逐边 phi/slot 关系，不可把不同 ValueId 当作不同 Java 局部家族；frame 中的 `Int` 形状也不能单独证明 Java `int`，需沿参数来源排除 boolean。该证据支持 1.2 的证明设计审查；它不表示生产实现已合入，也不表示循环已做行为运行或完整功能验收。临时测试文件只有九条物理指令库存断言，不能当永久回归门。

`pack.py` 会要求同目录 root 写入 `architecture-review.json`，并确认该 JSON 绑定上述 execution receipt SHA。若存在 `root-review.json`，脚本会核实它引用相同 receipt 和 architecture review。`pins.json` 冻结全部输入成员及 prep 文件；pack 时逐字节复核。调用示例（root review 已完成；此命令尚未执行）：

```sh
python3 -B /private/tmp/jarde-entry-split-ir-probe-durable-pack-prep-luna-v2-20261019/pack.py \
  --out /private/tmp/jarde-entry-split-ir-probe-durable-pack-root-v2-20261019/capture.tar.gz
```

归档包括完整 probe result（执行/构建收据、raw stdout/stderr、原始和带探针的 `region.rs` 快照、class 输入）、临时 probe runner、原探针 prep 的完整独立快照（包含原 prep README、patch、probe 源、class 副本和原 pins）、对应 OpenSpec 文件快照、以及 root architecture review。`pins.json` 冻结 25 个 result/runner/原 prep 快照成员；归档 prep 本身含 6 个逐项 pin 的文件和 `pins.json`，再加内嵌 inventory，因此归档成员数由 packer 实际派生，不写死。工具链/依赖安装本身不复制；收据中的实际命令路径与元数据保留。归档器会逐成员写入大小、SHA-256、mode，重新打开 tar 并核对全部成员和内嵌 inventory。
