from pathlib import Path
import json,hashlib,re,importlib.util
O=Path('/private/tmp/jarde-entry-split-generalized-gate-root-v1-20261019');R=Path('/Users/lordcasser/workspace/projects/jarde');V=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
d=json.loads((O/'execution.json').read_bytes());assert d['status']=='captured_pending_root_review' and d['source_unchanged'] and d['external_unchanged'] and d['target_absent'] and not(R/'target').exists()
seen={}
def walk(x):
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=set(x):
   p=Path(x['path']);b=p.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'],p;seen[str(p)]=x['sha256']
  for y in x.values():walk(y)
 elif isinstance(x,list):
  for y in x:walk(y)
walk(d);assert len(d['commands'])==11
for row in d['commands']:
 assert row['guard_stop'] is None and row['exit_code']==(1 if row['label'].startswith('wrong-root') else 0)
 assert row['cwd']==str(O/'empty')
row=next(iter(d['classes'].values()));f=row['facts'];assert f['class_name']=='cf08/EntrySplitSlotCounterCases' and f['major']==52 and f['fields']==[] and len(f['methods'])==3
methods={m['name']:m for m in f['methods']};assert set(methods)=={'<init>','permuted','countUp'}
assert methods['permuted']['descriptor']=='(ZII)I' and methods['permuted']['code']['code_hex']=='1a9a00068402071b9900098401ffa7fff61cac'
assert methods['countUp']['descriptor']=='(IZI)I' and methods['countUp']['code']['code_hex']=='1b9a00068400031c990009840201a7fff61aac'
helper=Path('/private/tmp/jarde-entry-split-fixture-gate-review-supplement-root-v1-20261019/classfile_helpers.py');assert sha(helper.read_bytes())=='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd';s=importlib.util.spec_from_file_location('generalized_physical',helper);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);physical=m.parse_class_file(Path(row['pin']['path']).read_bytes());assert physical['methods']==f['methods'] and physical['class_name']==f['class_name']
observed=[]
for run in d['original_runs']:
 lines=Path(run['stdout']['path']).read_text().splitlines();assert len(lines)==36;cases={}
 for line in lines:
  values=dict(x.split('=',1) for x in line.split()[1:]);name=values['method'];value=int(values['value']);counter=int(values['counter']);skip=values['skip'];assert name in {'permuted','countUp'} and value in {17,2147483646,-2147483647} and skip in {'true','false'}
  assert counter in ({0,1,2} if name=='permuted' else {0,-1,-2})
  amount=7 if name=='permuted' else 3;expected=value+amount*(abs(counter)+(skip=='false'));expected=((expected+2**31)%2**32)-2**31;assert int(values['actual'])==int(values['expected'])==expected
  key=(name,value,counter,skip);assert key not in cases;cases[key]=expected
 assert len(cases)==36;observed.append(cases)
assert len(observed)==2 and observed[0]==observed[1]
for name in d['wrong_roots']:
 c=next(x for x in d['commands'] if x['label']==name);assert b'wrong CodeSource' in Path(c['streams']['stderr']['path']).read_bytes()
# Verify candidate whole text/member text/map identity and physical BCI closure in both modes.
api={x['command']:x for x in d['baseline_api']};assert api['candidate-default']['methods']==api['candidate-all']['methods'] or [x['text'] for x in api['candidate-default']['methods']]==[x['text'] for x in api['candidate-all']['methods']]
assert Path(api['candidate-default']['source']['path']).read_bytes()==Path(api['candidate-all']['source']['path']).read_bytes()
for mode in ('candidate-default','candidate-all'):
 for member in api[mode]['methods']:
  name=member['item']['name']['escaped'];report=member['outcome']['report'];assert report['quality']=='structured' and report['representation']=='java' and report['execution']['status']=='complete'
  text=report['text'];physical_bcis=set(methods[name]['code']['bcis']);mapped=set();prefix_spans=[]
  for segment in report['source_map']['segments']:
   a,b=segment['start'],segment['end'];span=text.encode()[a:b].decode();assert 0<=a<=b<=len(text.encode())
   anchors=[segment['origin']['primary']]+segment['origin']['derived']
   for anchor in anchors:
    assert anchor['method']==member['item']['identity'] and anchor['bci'] in physical_bcis;mapped.add(anchor['bci'])
   if name!='<init>' and any(x['bci']==4 for x in anchors) and re.fullmatch(r'\s*\w+ = \w+ \+ (?:3|7);\s*',span):prefix_spans.append((a,b,span.strip()))
  assert mapped==physical_bcis,(mode,name,mapped,physical_bcis)
  if name!='<init>':assert any(x[2]==y[2] and x[1]<=y[0] for x in prefix_spans for y in prefix_spans)
for member in api['old-default']['methods']:
 if member['item']['name']['escaped']!='<init>':assert member['outcome']['report']['quality']=='fallback' and any(x['code']=='jre_region_irreducible' for x in member['outcome']['report']['diagnostics'])
review={'status':'root_accepted_generalized_original_gate_and_candidate_api','receipt_sha256':sha((O/'execution.json').read_bytes()),'reviewer_sha256':sha(Path(__file__).read_bytes()),'commands':11,'unique_pinned_paths_reopened':len(seen),'original_vm_runs':2,'original_case_rows':72,'wrong_root_rejections':2,'candidate_api_modes':['default','all'],'positive_methods':2,'both_source_maps_complete_with_two_disjoint_prefix_spans':True,'class_pin':row['pin'],'independent_physical_parser_sha256':sha(helper.read_bytes()),'notes':['Original and candidate API/source-map acceptance only. No generated Java compiled/run or JADX invocation yet.','Pre-execution v1 had swapped reflective argument positions and out-of-scope relational header opcodes;v2 fixed both before any execution.','No original five-class gate command rerun.']}
(V/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');(O/'root-review.json').write_text(json.dumps({'status':review['status'],'receipt_sha256':review['receipt_sha256'],'review':str(V/'review.json')},indent=2)+'\n');print(json.dumps(review,ensure_ascii=False))
