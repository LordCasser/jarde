// jarde: presentation of `cf08/EntrySplitSlotCounterCases` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf08;

public final class EntrySplitSlotCounterCases extends java.lang.Object {
    public EntrySplitSlotCounterCases() {
        // @method <init>()V
        // @declaration a constructor of `cf08.EntrySplitSlotCounterCases`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static int permuted(boolean arg0, int arg1, int arg2) {
        // jarde: not recovered: the recovery run for `permuted(ZII)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method permuted(ZII)I
        // @declaration a static method of `cf08.EntrySplitSlotCounterCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 7 8 11 14 17 18
        // the graph is not reducible over 3 block(s) [4, 7, 11]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }

    public static int countUp(int arg0, boolean arg1, int arg2) {
        // jarde: not recovered: the recovery run for `countUp(IZI)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method countUp(IZI)I
        // @declaration a static method of `cf08.EntrySplitSlotCounterCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 7 8 11 14 17 18
        // the graph is not reducible over 3 block(s) [4, 7, 11]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }
}
