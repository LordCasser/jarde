// jarde: presentation of `cf08/EntrySplitSlotCounterCases` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf08;

public final class EntrySplitSlotCounterCases extends java.lang.Object {
    public EntrySplitSlotCounterCases() {
        // @method <init>()V
        // @declaration a constructor of `cf08.EntrySplitSlotCounterCases`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static int permuted(boolean arg0, int arg1, int arg2) {
        // @method permuted(ZII)I
        // @declaration a static method of `cf08.EntrySplitSlotCounterCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        if (!arg0) {
            arg2 = arg2 + 7;
        }
        while (arg1 != 0) {
            arg1 = arg1 - 1;
            arg2 = arg2 + 7;
        }
        return arg2;
    }

    public static int countUp(int arg0, boolean arg1, int arg2) {
        // @method countUp(IZI)I
        // @declaration a static method of `cf08.EntrySplitSlotCounterCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        if (!arg1) {
            arg0 = arg0 + 3;
        }
        while (arg2 != 0) {
            arg2 = arg2 + 1;
            arg0 = arg0 + 3;
        }
        return arg0;
    }
}
