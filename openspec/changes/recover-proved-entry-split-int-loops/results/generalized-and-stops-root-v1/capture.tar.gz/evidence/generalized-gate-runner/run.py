from pathlib import Path
import importlib.util,json,os,shutil,sys,hashlib
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
PREP=Path('/private/tmp/jarde-entry-split-generalized-controls-luna-v2-20261019')
OUT=Path('/private/tmp/jarde-entry-split-generalized-gate-root-v1-20261019')
def load(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
compare_path=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
guard_path=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
scanner_path=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
for p,h in [(compare_path,'18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'),(guard_path,'51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'),(scanner_path,'d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7')]:
 assert hashlib.sha256(p.read_bytes()).hexdigest()==h
c=load(compare_path,'fixturegate_compare');g=load(guard_path,'fixturegate_guard');scan=load(scanner_path,'fixturegate_scanner')
jdks,jdkrec=c.configured_jdks(ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json','ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
cli=Path('/private/tmp/jarde-entry-split-focused-root-v4-20261019/candidate-cli');assert c.sha(cli)=='eb11645e741d944a349080fbd12f18e2e5c70bdc5809f4bdb51a6e3cdec6fb50'
assert not OUT.exists() and not (ROOT/'target').exists() and shutil.disk_usage(ROOT).free>=5*1024**3
OUT.mkdir();(OUT/'raw').mkdir();(OUT/'inputs').mkdir();(OUT/'empty').mkdir();(OUT/'writer').mkdir();(OUT/'driver').mkdir();(OUT/'original-classes').mkdir()
for rel in ['classwriter/EntrySplitSlotCounterCasesWriter.java','driver/EntrySplitSlotCounterCasesDriver.java']:
 shutil.copy2(PREP/rel,OUT/'inputs'/Path(rel).name)
external=[compare_path,guard_path,scanner_path,cli,Path(__file__),*sorted(p for p in PREP.rglob('*') if p.is_file()),*(p for spec in jdks.values() for p in spec['tools'].values())]
report={'schema':'entry-split-generalized-verifier-gate-root-v1','status':'running','commands':[],'jdk_manifest':jdkrec,'cli':c.pin(cli),'sources_before':c.source_closure(ROOT),'external_before':[c.pin(p) for p in external],'classes':{},'original_runs':[],'wrong_roots':[],'baseline_api':[]}
g.ROOT=OUT/'empty';g.OUT=OUT/'raw';g.target_bytes=lambda:scan.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
# Existing bounded runtime wrapper is pinned and executed by its Python interpreter, not as a shell.
bound=Path('/private/tmp/jarde-testendlessloop-baseline-root-v1-20261019/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
assert c.sha(bound)=='73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
report['runtime_wrapper']=c.pin(bound)
def save():c.write_json(OUT/'execution.json',report)
def command(argv,label,leg='javac8',require=True):
 assert not (ROOT/'target').exists()
 env=c.clean_env(dict(os.environ),jdks[leg]);env.update(g.ENV_VALUES);env.pop('RUST_MIN_STACK',None)
 row=g.run_command(len(report['commands'])+1,[str(a) for a in argv],env);row.update(label=label,tool_leg=leg);report['commands'].append(row);save()
 assert row.get('guard_stop') is None and row.get('exit_code') is not None
 if require:assert row['exit_code']==0,(label,row['exit_code'])
 return row
empty=OUT/'empty';classes=OUT/'original-classes';save()
try:
 command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g:none','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',OUT/'writer',OUT/'inputs/EntrySplitSlotCounterCasesWriter.java'],'compile-writer')
 command([jdks['javac8']['tools']['java'],'-Xverify:all','-cp',OUT/'writer','EntrySplitSlotCounterCasesWriter',classes],'run-writer')
 command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g:none','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',OUT/'driver',OUT/'inputs/EntrySplitSlotCounterCasesDriver.java'],'compile-driver')
 targets=sorted(classes.rglob('*.class'));assert len(targets)==1
 for p in targets:
  f=c.parse_class(p);assert f['class_name']=='cf08/EntrySplitSlotCounterCases' and f['major']==52 and len(f['methods'])==3 and f['fields']==[]
  report['classes'][p.relative_to(classes).as_posix()]={'pin':c.pin(p),'facts':f}
  command([jdks['javac8']['tools']['javap'],'-v','-c','-p',p],'javap-'+p.stem)
 for leg in jdks:
  row=command([sys.executable,'-B',bound,'30',jdks[leg]['tools']['java'],'-Xverify:all','-cp',OUT/'driver','EntrySplitSlotCounterCasesDriver',classes,classes],'original-'+leg,leg)
  lines=c.command_artifact(row,'stdout').decode().splitlines();assert len(lines)==36 and all(x.startswith('CASE ') for x in lines)
  for line in lines:
   vals=dict(x.split('=',1) for x in line.split()[1:]);value=int(vals['value']);counter=int(vals['counter']);amount=7 if vals['method']=='permuted' else 3
   expected=value+amount*((vals['skip']=='false')+abs(counter));expected=((expected+2**31)%2**32)-2**31
   assert int(vals['actual'])==int(vals['expected'])==expected
  report['original_runs'].append({'command':row['label'],'case_rows':36,'stdout':row['streams']['stdout']})
 for leg in jdks:
  row=command([sys.executable,'-B',bound,'30',jdks[leg]['tools']['java'],'-Xverify:all','-cp',OUT/'driver','EntrySplitSlotCounterCasesDriver',classes,empty],'wrong-root-'+leg,leg,False)
  assert row['exit_code']!=0 and b'wrong CodeSource' in c.command_artifact(row,'stderr');report['wrong_roots'].append(row['label'])
 oldcli=Path('/private/tmp/jarde-assignment-condition-widening-broad-resume-root-v1-20261019/candidate-cli');assert c.sha(oldcli)=='96e534b0000fe91c1d34a282919479a97eb4706063501d188cdff010c4640366';report['old_cli']=c.pin(oldcli)
 for label,binary,all_evidence in [('old-default',oldcli,False),('candidate-default',cli,False),('candidate-all',cli,True)]:
  argv=[binary,'class-source','--input',targets[0],'--class','cf08/EntrySplitSlotCounterCases','--policy','single-class','--release','8','--format','json']
  if all_evidence:argv+=['--evidence','all']
  row=command(argv,label,'javac23');data=json.loads(c.command_artifact(row,'stdout'));assert isinstance(data.get('text'),str)
  text=OUT/(label+'.java');text.write_text(data['text']);report['baseline_api'].append({'class':'EntrySplitSlotCounterCases','command':row['label'],'source':c.pin(text),'methods':data.get('methods')})
 report['status']='captured_pending_root_review'
except BaseException as e:report['status']='failed';report['error']=repr(e);raise
finally:
 report['sources_after']=c.source_closure(ROOT);report['source_unchanged']=report['sources_before']==report['sources_after'];report['external_after']=[c.pin(p) for p in external];report['external_unchanged']=report['external_before']==report['external_after'];report['target_absent']=not (ROOT/'target').exists();save()
print(json.dumps({'status':report['status'],'commands':len(report['commands']),'output':str(OUT)}))
