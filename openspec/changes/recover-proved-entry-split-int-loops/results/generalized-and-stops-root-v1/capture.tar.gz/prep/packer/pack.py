#!/usr/bin/env python3
"""Pack bounded EntrySplit gate and stop evidence; writes only the explicit --out archive."""
from __future__ import annotations
import argparse, hashlib, io, json, stat, tarfile
from pathlib import Path

TMP = Path('/private/tmp').resolve()
PREP = Path(__file__).resolve().parent
ROOTS = [(PREP, 'prep/packer'),
    (TMP / 'jarde-entry-split-generalized-gate-root-v1-20261019', 'evidence/generalized-gate'),
    (TMP / 'jarde-entry-split-generalized-gate-runner-root-v1-20261019', 'evidence/generalized-gate-runner'),
    (TMP / 'jarde-entry-split-generalized-review-root-v1-20261019', 'evidence/generalized-review'),
    (TMP / 'jarde-entry-split-generalized-controls-luna-v1-20261019', 'prep/generalized-controls-v1'),
    (TMP / 'jarde-entry-split-generalized-controls-luna-v2-20261019', 'prep/generalized-controls-v2'),
    (TMP / 'jarde-entry-split-stops-root-v1-20261019', 'evidence/stops-v1'),
    (TMP / 'jarde-entry-split-stops-root-v2-20261019', 'evidence/stops-v2'),
    (TMP / 'jarde-entry-split-stops-review-root-v1-20261019', 'evidence/stops-review-root-v1'),
    (TMP / 'jarde-entry-split-stops-commands-root-v1-20261019', 'prep/stops-commands-v1'),
    (TMP / 'jarde-entry-split-stops-commands-root-v2-20261019', 'prep/stops-commands-v2'),
    (TMP / 'jarde-entry-split-format-root-v5-20261019', 'evidence/format-v5'),
    (TMP / 'jarde-entry-split-format-runner-root-v5-20261019', 'evidence/format-runner-v5'),
    (TMP / 'jarde-entry-split-budget-tests-prep-luna-v1-20261019', 'prep/budget-tests-draft'),
    (TMP / 'jarde-entry-split-output-cut-fix-luna-v1-20261019', 'prep/output-cut-fix-v1'),
]
EXCLUDED_PARTS = {'target', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache', '.cache', 'node_modules'}
ALLOWED_SUFFIXES = {'.json', '.raw', '.py', '.md', '.patch', '.txt', '.java', '.before'}
MAX_FILE = 64 * 1024 * 1024
MAX_TOTAL = 256 * 1024 * 1024

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)
def read_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))
def safe_file(path: Path) -> bool:
    if path.suffix in ALLOWED_SUFFIXES:
        return True
    # Keep original classfile inputs, not compiled writer/driver outputs.
    return path.suffix == '.class' and 'original-classes' in path.parts

def gather() -> dict[str, Path]:
    members: dict[str, Path] = {}
    total = 0
    for root, prefix in ROOTS:
        need(root.is_dir() and not root.is_symlink(), f'missing/unsafe evidence root: {root}')
        for path in sorted(root.rglob('*')):
            if any(part in EXCLUDED_PARTS for part in path.parts):
                continue
            need(not path.is_symlink(), f'refuse symlink in evidence tree: {path}')
            if not path.is_file() or not safe_file(path) or path.name == 'candidate-cli':
                continue
            data = path.read_bytes()
            need(len(data) <= MAX_FILE, f'oversize evidence member: {path}')
            total += len(data)
            need(total <= MAX_TOTAL, 'evidence payload exceeds the bounded archive limit')
            name = prefix + '/' + path.relative_to(root).as_posix()
            need(name not in members, f'duplicate archive path: {name}')
            members[name] = path.resolve(strict=True)
    required = {
        'evidence/stops-v1/execution.json', 'evidence/stops-v1/raw/2.stderr.raw',
        'evidence/stops-v2/execution.json', 'evidence/stops-review-root-v1/review.json',
        'evidence/format-v5/execution.json',
        'evidence/format-runner-v5/run.py',
        'prep/stops-commands-v1/commands.json', 'prep/stops-commands-v2/commands.json',
        'prep/output-cut-fix-v1/minimal.patch',
    }
    need(required <= set(members), f'missing required files: {sorted(required - set(members))}')
    return dict(sorted(members.items()))

def validate_history(members: dict[str, Path]) -> dict:
    v1 = read_json(members['evidence/stops-v1/execution.json'])
    v2 = read_json(members['evidence/stops-v2/execution.json'])
    format_run = read_json(members['evidence/format-v5/execution.json'])
    stderr = members['evidence/stops-v1/raw/2.stderr.raw'].read_bytes()
    need(v1.get('status') == 'failed', 'stops-v1 historical failure status changed')
    need(b'IrTableMissing { table: "canonical" }' in stderr,
         'stops-v1 raw failure no longer records the canonical-table pre-emitter stop')
    need(v2.get('status') not in (None, 'running', 'failed'),
         f'stops-v2 is not a completed command capture: {v2.get("status")}')
    need(format_run.get('status') == 'format_passed_pending_root_diff_review',
         'format-v5 receipt status changed; preserve the actual receipt without relabeling')
    review = read_json(members['evidence/stops-review-root-v1/review.json'])
    need(review.get('status') == 'root_accepted_real_proof_output_and_map_stops_with_preserved_failure',
         'stops root review status changed')
    receipt_rows = {row.get('path'): row for row in review.get('receipts', [])}
    for version, receipt in [('v1', v1), ('v2', v2)]:
        archived_path = members[f'evidence/stops-{version}/execution.json']
        row = receipt_rows.get(str(archived_path))
        need(row is not None and row.get('sha256') == sha(archived_path.read_bytes())
             and row.get('status') == receipt.get('status'),
             f'stops-{version} receipt is not bound by the root review')
    return {
        'stops_v1_status': v1.get('status'),
        'stops_v1_preserved_failure': True,
        'stops_v2_status': v2.get('status'),
        'stops_v2_source_unchanged': v2.get('source_unchanged'),
        'format_v5_status': format_run.get('status'),
        'format_v5_target_absent': format_run.get('target_absent'),
        'stops_root_review_status': review.get('status'),
        'acceptance_claim': 'only the explicit root review status above; raw receipts remain unchanged',
    }

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True,
                        help='new archive path under /private/tmp; never overwritten')
    args = parser.parse_args()
    out = args.out.resolve()
    inv_path = out.with_suffix(out.suffix + '.inventory.json')
    need(out.is_relative_to(TMP), 'archive output must be under /private/tmp')
    need(not out.is_relative_to(PREP), 'archive output must be outside the prep directory')
    need(not out.exists() and not inv_path.exists(), 'refuse to overwrite archive or inventory')
    members = gather()
    summary = validate_history(members)
    rows = []
    for name, path in members.items():
        data = path.read_bytes()
        rows.append({'path': name, 'bytes': len(data), 'sha256': sha(data),
                     'mode': stat.S_IMODE(path.stat().st_mode)})
    manifest = {
        'schema': 'cf08-entry-split-gates-and-stops-archive-v1',
        'status': 'raw-evidence-packed-no-acceptance-claim',
        'scope': 'generalized fixture gate/review, entry-split stop and format captures, and bounded test drafts',
        'receipt_summary': summary,
        'member_count': len(rows), 'members': rows,
        'excluded': 'CLI/Rust executables, writer/driver class outputs, target/cache directories and external tool installations',
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(out, 'x:gz') as archive:
        for name, path in members.items():
            archive.add(path, arcname=name, recursive=False)
        blob = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
        info = tarfile.TarInfo('ARCHIVE_INVENTORY.json')
        info.size, info.mode = len(blob), 0o644
        archive.addfile(info, io.BytesIO(blob))
    with tarfile.open(out, 'r:gz') as archive:
        files = {item.name: item for item in archive.getmembers() if item.isfile()}
        need(set(files) == {row['path'] for row in rows} | {'ARCHIVE_INVENTORY.json'},
             'reopened archive member set differs')
        for row in rows:
            item = files[row['path']]
            data = archive.extractfile(item).read()
            need(len(data) == row['bytes'] and sha(data) == row['sha256'],
                 f'archive member bytes differ: {row["path"]}')
            need(stat.S_IMODE(item.mode) == row['mode'], f'archive member mode differs: {row["path"]}')
        embedded = archive.extractfile(files['ARCHIVE_INVENTORY.json']).read()
        need(json.loads(embedded) == manifest, 'embedded inventory differs')
    inv_bytes = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    with inv_path.open('xb') as stream:
        stream.write(inv_bytes)
    print(json.dumps({'status': 'packed-and-reopened', 'archive': str(out),
                      'archive_sha256': sha(out.read_bytes()), 'inventory': str(inv_path),
                      'inventory_sha256': sha(inv_bytes), 'member_count': len(rows),
                      'receipt_summary': summary}, indent=2))

if __name__ == '__main__':
    main()
