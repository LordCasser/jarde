# Entry-split generalized slot/counter controls (private v2 preparation)

This is a fresh correction of private v1. It emits one standalone class, `cf08/EntrySplitSlotCounterCases`, containing a public no-argument constructor and two public static methods. It does not alter or regenerate the accepted five-class fixture.

`permuted(ZII)I` has parameter/slot order skip=0, counter=1, value=2. The entry prefix increments value by 7; the loop tests counter against zero, decrements it by 1, and repeats until zero. The driver passes reflective arguments in the same descriptor order: `{skip, counter, value}`. Its counters are 0, 1, and 2.

`countUp(IZI)I` has value=0, skip=1, counter=2. Its entry prefix increments value by 3; the loop tests counter against zero, increments it by 1, and repeats until zero. Its counters are 0, -1, and -2. Both generated loops use `IFEQ` at the header and `IFNE` for the skip test, staying within the requested zero/nonzero branch forms.

Both methods are 19 bytes with instruction starts `0,1,4,7,8,11,14,17,18`; conditional targets are 7 and 17, and the backedge at 14 targets 4. The same-frame StackMapTable entries are at BCIs 4, 7, and 17. The driver checks parentless loader identity, exact CodeSource, field/method/constructor inventory, and descriptors, then executes 18 finite cases per method (36 rows total). It computes the expected integer result using Java `int` arithmetic, including overflow.

The writer is adapted from the accepted v3 `DataOutputStream` writer and emits classfile major version 52. These are source and byte-layout checks only. No writer, compiler, or JVM was run, so no generated-class or verifier result is claimed. Root should perform its own guarded generation and JVM gates before accepting this control.

The v1 draft used the wrong argument order for `permuted` and signed loop comparisons. This v2 copy corrects both; v1 remains unchanged for review history.
