# Entry-split budget-cut test preparation

Private test-only draft; no shared file changed and no Cargo/JVM/CLI command ran. The test addition is in `budget-cuts-append.rs.txt`; it is intended to append to the current `p3_entry_split_int_loops.rs` after the v4 public tests. It adds no production hook, no IR/facts mutator, and no thousand-case public sweep.

## Actual cut strategy

The draft builds one real `MethodAnalysisRequest` for the positive classfile's `test(IZI)I` and reuses its snapshot for each run. An all-evidence run supplies two disjoint source-map spans for the physical prefix assignment. A separate essential run must publish identical body bytes and state SourceMap as `NotRequested`.

For each of the two assignment spans, the test uses a bounded binary search (maximum 32 recovery calls) over `output_bytes`. It selects only a real `RecoveryOutcome::Stopped(StopReason::Budget { dimension: OutputBytes, written, at, .. })` whose `written` byte offset falls inside that span. The stopped artifact must be `NotProduced`, with empty output text/map, and the already charged output usage must remain nonzero and cover `written`. This uses `written` to distinguish the initial prefix write from the duplicated loop-tail write; the shared BCI alone is insufficient.

For SourceMap, the draft measures a complete essential run and a complete SourceMap-selected run, first tries `full_ir_items - 1`, then does a bounded binary search between the essential-body and complete-map usage if needed. A selected cut must preserve the exact completed body, report a produced outcome with `EvidenceState::Partial { delivered }`, retain a nonempty proper map prefix, make `delivered == source_map.len()`, and validate every returned UTF-8 span and origin against the exact physical method/BCI inventory. It intentionally does not demand an empty map or remove committed text: the established evidence contract keeps the completed artifact and reports only a completed-node SourceMap prefix.

The test chooses actual stops from report state and budgets, not numeric thresholds alone. Root must run it against the integrated code and retain the observed cut bounds, `written`, `at`, evidence delivered count, and budget usage. If either output span cannot be uniquely reached, or SourceMap does not produce the documented prefix under these bounded limits, the assertion fails and needs diagnosis; the test must not infer success from a generic low budget or pre-cancellation.

## Existing contract basis

`StopReason::Budget` exposes `written`, `limit`, and optional BCI; `emit_source_map` returns a `Materialized::Partial` span prefix when its evidence phase is budget-stopped and leaves the committed artifact untouched. The existing public examples are `tests/p3_patterns.rs`, `tests/p3_compound_lvalue_updates.rs`, and `tests/p3_bitwise.rs`; these demonstrate partial evidence delivery and distinct body/evidence behavior. This draft extends the actual entry-split fixture through the existing recovery API rather than mirroring Builder or emitter logic.
