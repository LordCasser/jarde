# Entry-split public test corrections (v4)

This is a private, test-only correction atop v3. It changes no product source and was not compiled or run. Root's completed JVM fixture gate is diagnostic evidence for shaping assertions; it is not an execution of these Rust tests.

Pinned root gate receipt: `/private/tmp/jarde-entry-split-fixture-gate-root-v1-20261019/execution.json`. It reports five classfiles, and root separately confirmed `javap` layout against the bytecode ledger, both JVMs with `-Xverify:all`, 72 positive rows per runtime, negative inventory-only constructor checks, and wrong-CodeSource rejection. The receipt itself is still under root's independent review.

## Test edits

- The legacy v49 test now matches the actual established behavior: `Quality::Fallback`, `Representation::Mixed`, exactly two `jre_region_subroutine_entry` fallback codes, `jre_region_uncovered_blocks`, the retained `if`/`else` and `return arg0;` regions, the two quoted spans, and complete method-specific BCI mapping. It does not incorrectly require an atomic whole-method quote.
- The repeated-prefix assertion now looks only at segments anchored to the prefix BCI whose complete text is a single arithmetic assignment statement. It excludes comments and enclosing `if`/`while` spans, then requires two identical, non-overlapping spans. `assert_full_map` independently checks exact physical method identity and BCI coverage.
- The omitted-SSA request now checks the actual `recover_method` result: the stage is absent, presentation stops with `IrTableMissing { table: "ssa" }`, content is `NotProduced`, and text/map are empty. This verifies missing evidence is not turned into a partial entry-split candidate.

The exceptional prefix candidate in v3's frozen fixture gate produced the existing whole-body irreducible refusal; its test already asserts fallback, handler row, and full mapping. No contract was loosened. The candidate bytes still rely on the root's verifier run, not on this test preparation.
