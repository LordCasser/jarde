# Entry-split generalized slot/counter controls (private preparation)

This directory contains one standalone classfile writer and one parentless finite oracle driver. The writer emits only `cf08/EntrySplitSlotCounterCases.class` (public no-argument constructor and two public static methods); it does not modify or regenerate the accepted five-class fixture.

`permuted(ZII)I` uses skip slot 0, counter slot 1, and returned prefix/value slot 2. Its prefix update is `+7` and its counter update is `-1`. `countUp(IZI)I` uses prefix/value slot 0, skip slot 1, and counter slot 2; its prefix update is `+3` and its counter update is `+1`, with the loop condition `counter < 0`. Both have 19-byte methods and the same five-block shape as the accepted positive fixture. Their same-frame StackMapTable entries are at BCIs 4, 7, and 17.

The driver verifies a parentless class loader and exact CodeSource path, checks the class's field/method/constructor inventory and both exact descriptors, invokes only these finite controls, and compares each result against a bounded integer oracle. Each method has 3 values × 2 skip values × 3 direction-specific counters = 18 cases; total output is 36 case rows. `permuted` counters are 0, 1, 2; `countUp` counters are 0, -1, -2. Java `int` overflow is used by the oracle for the selected boundary values.

Static byte-layout check (not class generation or JVM verification): both methods have instruction starts `0,1,4,7,8,11,14,17,18`; conditional targets are 7 and 17, and the backedge at 14 targets 4. The frame payload `{count=3, same_frame=4, same_frame=2, same_frame=9}` resolves to BCIs 4, 7, and 17. The source and writer were not compiled or executed; no runtime or verifier result is claimed. Root should run its own guarded writer/JVM gates before treating this as accepted evidence.

The writer is adapted from the existing v3 fixture writer pinned below. It uses the same `DataOutputStream` classfile layout, major version 52, and constructor encoding; the only generated methods are the two described above.
