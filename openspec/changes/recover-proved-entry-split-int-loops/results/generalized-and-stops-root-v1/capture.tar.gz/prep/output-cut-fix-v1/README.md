# Entry-split output-cut test adjustment (private, unexecuted)

The minimal patch raises only the output-byte bisection lower bound to `POSITIVE.len() + 1`. `ArtifactSnapshot::root_bytes` checks and charges the full standalone class length against `OutputBytes` before `raw_facts` can publish its canonical IR. A cap below that length can therefore make recovery report `IrTableMissing { table: "canonical" }`; that is a pre-emitter stop, not a source-output boundary.

Every probe now has enough capacity for this known pre-emitter class read. The existing test still accepts only `Stopped(Budget { dimension: OutputBytes, written, at })` whose `written` lies within the selected, complete source-map span for one of the two prefix assignment copies. It retains the not-produced/empty-text/map and no-refund assertions. Other outcomes remain failures. The source-map cut test is unchanged.

Evidence read statically: `root_bytes` in `crates/jarde-reader/src/artifact.rs`; raw-facts pass and its read-stop behavior in `crates/jarde-jvm/src/engine.rs`; `Engine::recover_own_read` in `src/facade.rs`; missing-canonical guard in `crates/jarde-java/src/report.rs`. Hashes and the original failure stream are in `pins.json`. No shared file was changed and no test/toolchain was run.
