from pathlib import Path
import importlib.util,subprocess,os,json,hashlib
R=Path('/Users/lordcasser/workspace/projects/jarde');O=Path('/private/tmp/jarde-entry-split-format-root-v1-20261019');assert not O.exists() and not (R/'target').exists();O.mkdir();(O/'raw').mkdir()
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
G=R/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py';S=R/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py';assert pin(G)['sha256']=='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33';assert pin(S)['sha256']=='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
g=load(G,'fmtguard');scan=load(S,'fmtscan');g.ROOT=R;g.OUT=O/'raw';g.target_bytes=lambda:scan.target_bytes(R);g.command_stream=pin;g.expected_test_summaries=lambda i,b:None
keys=('RUST_MIN_STACK','CARGO_TARGET_DIR','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH');env={k:v for k,v in os.environ.items() if k not in keys};env.update(g.ENV_VALUES)
def sources():
 raw=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','src','crates','tests','Cargo.toml','Cargo.lock'],cwd=R)
 return {os.fsdecode(p):pin(R/os.fsdecode(p)) for p in sorted(set(raw.split(b'\0'))-{b''}) if (R/os.fsdecode(p)).is_file()}
r={'status':'running','runner':pin(__file__),'default_stack':True,'source_before':sources(),'commands':[]};(O/'build.rs.before').write_bytes((R/'crates/jarde-java/src/build.rs').read_bytes());(O/'region.rs.before').write_bytes((R/'crates/jarde-java/src/region.rs').read_bytes());(O/'p3_entry_split_int_loops.rs.before').write_bytes((R/'tests/p3_entry_split_int_loops.rs').read_bytes())
def save():(O/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 row=g.run_command(1,['cargo','fmt','--all'],env);r['commands'].append(row);save();assert row['exit_code']==0 and row['guard_stop'] is None
 r['source_after']=sources();changed={k for k in r['source_before'].keys()|r['source_after'].keys() if r['source_before'].get(k)!=r['source_after'].get(k)};r['format_changed_paths']=sorted(changed);assert changed <= {'crates/jarde-java/src/build.rs','crates/jarde-java/src/region.rs','tests/p3_entry_split_int_loops.rs'}
 r['status']='format_passed_pending_root_diff_review'
except BaseException as e:r['status']='failed';r['error']=repr(e);raise
finally:
 row=g.run_command(len(r['commands'])+1,['cargo','clean'],env);r['commands'].append(row);r['target_absent']=not (R/'target').exists();assert row['exit_code']==0 and row['guard_stop'] is None and r['target_absent'];save();print(json.dumps({k:r.get(k) for k in ('status','error','target_absent','format_changed_paths')}))
