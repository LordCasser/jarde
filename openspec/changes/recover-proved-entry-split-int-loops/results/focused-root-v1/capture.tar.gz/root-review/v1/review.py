from pathlib import Path
import hashlib,json,re,stat
R=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def pincheck(p):
 b=Path(p['path']).read_bytes();assert len(b)==p['bytes'] and sha(b)==p['sha256'],p['path']
def loadrun(v):
 p=Path('/private/tmp/jarde-entry-split-focused-root-v'+str(v)+'-20261019');d=json.loads((p/'execution.json').read_bytes());return p,d
runs={v:loadrun(v) for v in (1,2,3,4)}
for v,(p,d) in runs.items():
 for k in ('runner','spec','guard','scanner'):pincheck(d[k])
 for cmd in d['commands']:
  for x in cmd['streams'].values():pincheck(x)
  if not cmd.get('cleanup_only'):
   assert cmd['guard_stop'] is None and cmd['peak_target_bytes']<=1024**3
  else:assert cmd['argv']==['cargo','clean'] and cmd['exit_code']==0
 assert d['default_stack'] and d['target_absent'] and d['source_changes_accepted']
 assert d['source_changes']==(['tests/fixtures/corpus-fingerprint.json'] if v==1 else [])
p,d=runs[4];assert d['status']=='commands_passed_pending_independent_acceptance' and d['source_before']==d['source_after'] and d['source_unchanged']
for x in d['source_after']:pincheck(x)
assert len(d['commands'])==6 and all(x['exit_code']==0 for x in d['commands'])
expected=[(507,0,0),(1,0,0),(5,0,1)]
named={}
for index,counts in enumerate(expected):
 row=d['commands'][index];text=Path(row['streams']['stdout']['path']).read_text();rows=re.findall(r'^test ([\w:]+) \.\.\. (ok|FAILED|ignored[^\n]*)$',text,re.M)
 assert len(rows)==sum(counts) and len(set(name for name,_ in rows))==len(rows)
 assert sum(result=='ok' for _,result in rows)==counts[0] and not any(result=='FAILED' for _,result in rows)
 named[str(index+1)]=rows
assert ('region::tests::entry_split_region_proof_uses_real_ir_and_stops_before_publication','ok') in named['1']
row=runs[3][1]['commands'][0];text=Path(row['streams']['stdout']['path']).read_text();public=re.findall(r'^test ([\w:]+) \.\.\. (ok|FAILED|ignored[^\n]*)$',text,re.M);assert len(public)==7 and all(r=='ok' for _,r in public)
cli=d['cli'];pincheck(cli);assert cli['sha256']=='eb11645e741d944a349080fbd12f18e2e5c70bdc5809f4bdb51a6e3cdec6fb50' and cli['bytes']==63955664 and stat.S_IMODE(Path(cli['path']).stat().st_mode)==0o555
assert not (R/'target').exists()
review={'status':'root_accepted_focused_candidate_with_preserved_failures','receipts':{str(v):{'path':str(p/'execution.json'),'sha256':sha((p/'execution.json').read_bytes()),'status':d['status']} for v,(p,d) in runs.items()},'v4_source_paths_reopened':len(d['source_after']),'named_outcomes':named,'public7_outcomes':public,'cli':cli,'peak_target_bytes':max(x.get('peak_target_bytes',0) for _,d in runs.values() for x in d['commands']),'target_absent':True,'default_stack':True,'notes':['v1 corpus regeneration1pass accepted; test compile E0308 preserved.','v2 actual5pass/2fail preserved; fixed phi predecessor order and test raw-zero elapsed budget.','v3 public7pass accepted; java lib test helper exhaustive-match compile failure preserved.','v4 continued missing commands only:507 java unit tests incl real-IR proof budget/cancel, Reader census1pass, fingerprint5pass/1 existing ignored,fmt check,CLI build; exact clean.','No final generated source/runtime matrix, fresh full workspace or own CI claimed.','Public7 passed against same product logic; only test helper/proof test additions and formatting followed.']}
(OUT/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');(p/'root-review.json').write_text(json.dumps({'status':review['status'],'receipt_sha256':review['receipts']['4']['sha256'],'review':str(OUT/'review.json')},indent=2)+'\n');print(json.dumps({k:v for k,v in review.items() if k not in ('named_outcomes','public7_outcomes')},ensure_ascii=False))
