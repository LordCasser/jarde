# Entry-split integer loop implementation candidate

This private patch implements the narrow five-role irreducible entry-split loop candidate and its Builder projection. It is based on the current shared product source, whose production files remain unchanged.

The region proof first checks cheap cardinality, synchronization, exception, and unreachable gates. Only an exact five-block/six-edge candidate pays the bounded topology and SSA work. It assigns entry/prefix/header/latch/exit by the edge roles, permits one optional transfer after the prefix increment, follows predecessor-ordered phis for only the three proven local roles, and allows unrelated pass-through local entries and phis. It does not require the JVM-shaped SSA `Int` values to distinguish source `int` from `boolean`; Builder rechecks source decisions and the method's `int` result before committing.

Recovery installs the region as the sole owner of its five canonical blocks. Existing uncovered, overlap, and unaccounted-instruction checks remain downstream. Builder emits the entry `if`, recurring `while`, and final return using the existing test/instruction rendering path; the original prefix assignment is cloned once for its second source occurrence, with the original increment BCI retained on both statements. The optional prefix goto is carried as a derived origin of the initial `if`; the latch transfer is carried by the `while`. A Builder refusal restores the checkpoint and emits the existing quoted fallback; a `StopReason` restores and propagates. The speculative checkpoint is taken only when every collection with nested/string-bearing contents is empty, so its clone has no unbounded AST or text payload; its bounded side-table clone and the output nodes/name copies are charged before cloning/emission.

`normal_flow.rs` is unchanged. This candidate has not been compiled or tested; root owns integration and validation.

## Files

- `changes.patch` is a unified patch from the pinned shared baseline.
- `crates/jarde-java/src/region.rs` and `crates/jarde-java/src/build.rs` are the complete private edited copies.
- `pins.json` records shared-base and private-result SHA-256 values.
