//! Public regression coverage for the proved entry-split integer-prefix loop.
use jarde::*;
use jarde_jvm::ir::{Quality, Representation};
use jarde_reader::budget::{Budget, CancellationToken};
use jarde_reader::classfile::{MethodSelector, inspect_method_bytecode};
use jarde_reader::model::ExecutionReport;
use std::collections::BTreeSet;
use std::slice;

const POSITIVE: &[u8] = include_bytes!("fixtures/cf08-entry-split/cf08/EntrySplitCases.class");
const REFUSALS: &[u8] = include_bytes!("fixtures/cf08-entry-split/cf08/EntrySplitRefusals.class");
const CLASS: &str = "cf08/EntrySplitCases";
const REFUSAL_CLASS: &str = "cf08/EntrySplitRefusals";

fn report(bytes: &[u8], class: &str, all: bool) -> ClassSourceReport {
    let mut budget = task_budget(&[]).expect("default task budget is valid");
    let engine = Engine::new();
    let snapshot = engine
        .open(ArtifactInput::bytes(bytes.to_vec()), &mut budget)
        .expect("fixture class opens");
    let request = ClassSourceRequest {
        class: ClassRef::Name {
            class: ClassNameQuery::internal(class),
        },
        environment: EnvironmentRequest {
            snapshot: snapshot.id().clone(),
            scope: PhysicalScope::SnapshotAll,
            policy: EnvironmentPolicy::SingleClass,
            profile: RuntimeProfile {
                java_release: 8,
                multi_release: MultiReleasePolicy::Disabled,
                layout: LayoutMode::Generic,
            },
            loader: LoaderId("app".to_owned()),
        },
    };
    let result = if all {
        engine.class_source_with_evidence(
            slice::from_ref(&snapshot),
            &request,
            &RecoveryEvidenceRequest::all(),
            &mut budget,
        )
    } else {
        engine.class_source(slice::from_ref(&snapshot), &request, &mut budget)
    }
    .expect("class-source request returns an outcome");
    match result {
        OperationOutcome::Performed(report) => report,
        other => panic!("fixture request completes: {other:?}"),
    }
}

fn member<'a>(report: &'a ClassSourceReport, name: &str, descriptor: &str) -> &'a ClassSourceMethod {
    report.methods.iter().find(|method| {
        method.item.name.raw().0 == name.as_bytes()
            && method.item.descriptor.raw().0 == descriptor.as_bytes()
    }).unwrap_or_else(|| panic!("missing {name}{descriptor}"))
}

fn body(method: &ClassSourceMethod) -> &RecoveryReport {
    match &method.outcome {
        ClassSourceOutcome::Recovered { report, .. } => report,
        other => panic!("method has its own recovery result: {other:?}"),
    }
}

fn physical_bcis(bytes: &[u8], name: &str, descriptor: &str) -> BTreeSet<u32> {
    let mut budget = task_budget(&[]).expect("reader budget is valid");
    let code = inspect_method_bytecode(bytes, MethodSelector {
        name: JvmBytes(name.as_bytes().to_vec()),
        descriptor: JvmBytes(descriptor.as_bytes().to_vec()),
    }, &mut budget).expect("complete physical Code is readable");
    assert!(code.stopped_at.is_none(), "Code scan is complete");
    code.instructions.into_iter().map(|instruction| instruction.bci).collect()
}

fn assert_full_map(bytes: &[u8], method: &ClassSourceMethod, name: &str, descriptor: &str) {
    let recovered = body(method);
    let physical = physical_bcis(bytes, name, descriptor);
    let mut mapped = BTreeSet::new();
    for segment in recovered.source_map.segments() {
        assert!(segment.start() <= segment.end());
        assert!(recovered.text.get(segment.start()..segment.end()).is_some(), "UTF-8 aligned span");
        for anchor in std::iter::once(segment.origin().primary()).chain(segment.origin().derived()) {
            assert_eq!(anchor.method(), Some(&method.item.identity), "source owner is exact method");
            assert!(physical.contains(&anchor.bci()), "anchor lies in physical Code");
            mapped.insert(anchor.bci());
        }
    }
    assert_eq!(mapped, physical, "all and only physical instruction BCIs are mapped");
}

fn assert_prefix_is_shown_twice(method: &ClassSourceMethod, prefix_bci: u32) {
    let recovered = body(method);
    let statements: Vec<(u32, u32, String)> = recovered.source_map.of_bci(prefix_bci)
        .into_iter()
        .filter_map(|segment| {
            let statement = segment.text(&recovered.text).trim();
            let assignment = statement.ends_with(';')
                && !statement.contains('\n')
                && !statement.starts_with("//")
                && !statement.contains("if (")
                && !statement.contains("while (")
                && (statement.contains(" += ") || statement.contains(" -= ")
                    || (statement.contains(" = ") && (statement.contains(" + ") || statement.contains(" - "))));
            assignment.then(|| (segment.start(), segment.end(), statement.to_owned()))
        })
        .collect();
    let mut pair = None;
    'outer: for left in 0..statements.len() {
        for right in left + 1..statements.len() {
            if statements[left].2 == statements[right].2
                && (statements[left].1 <= statements[right].0 || statements[right].1 <= statements[left].0)
            {
                pair = Some((&statements[left], &statements[right]));
                break 'outer;
            }
        }
    }
    assert!(pair.is_some(), "one physical prefix BCI has two disjoint identical assignment statements, excluding enclosing control spans: {}", recovered.text);
}

#[test]
fn entry_split_integer_loop_accepts_signed_slot_and_polarity_variants() {
    let default = report(POSITIVE, CLASS, false);
    let all = report(POSITIVE, CLASS, true);
    assert_eq!(default.text, all.text);
    assert_eq!(default.methods.len(), 5, "constructor plus four fixture methods");
    for (name, descriptor, prefix_bci) in [
        ("test", "(IZI)I", 4),
        ("signed", "(IZI)I", 4),
        ("shifted", "(IIIZI)I", 4),
        ("inverted", "(IZI)I", 14),
    ] {
        let ordinary = member(&default, name, descriptor);
        let evidenced = member(&all, name, descriptor);
        let recovered = body(ordinary);
        assert_eq!(ordinary.text, evidenced.text, "{name}: evidence mode preserves member text");
        assert_eq!(recovered.source_map, body(evidenced).source_map, "{name}: map is stable");
        assert_eq!(recovered.quality, Quality::Structured, "{name}: {}", recovered.text);
        assert_eq!(recovered.representation, Representation::Java);
        assert!(!recovered.text.contains("@bytecode"), "{name}: {}", recovered.text);
        assert!(recovered.text.contains("if ("), "initial path is explicit: {}", recovered.text);
        assert!(recovered.text.contains("while ("), "ordinary loop is explicit: {}", recovered.text);
        assert!(recovered.text.contains("return "), "actual exit value is retained: {}", recovered.text);
        assert_prefix_is_shown_twice(ordinary, prefix_bci);
        assert_full_map(POSITIVE, ordinary, name, descriptor);
    }
}

#[test]
fn entry_split_controls_without_the_complete_int_proof_remain_quoted() {
    let default = report(REFUSALS, REFUSAL_CLASS, false);
    let all = report(REFUSALS, REFUSAL_CLASS, true);
    assert_eq!(default.text, all.text);
    assert_eq!(default.methods.len(), 5, "constructor plus four verifier-valid controls");
    for (name, descriptor) in [
        ("booleanPrefix", "(ZZI)I"),
        ("bytePrefix", "(BZI)I"),
        ("alias", "(IZ)I"),
        ("callPrefix", "(IZI)I"),
    ] {
        let ordinary = member(&default, name, descriptor);
        let evidenced = member(&all, name, descriptor);
        let recovered = body(ordinary);
        assert_eq!(ordinary.text, evidenced.text, "{name}: evidence mode preserves refusal");
        assert_eq!(recovered.source_map, body(evidenced).source_map, "{name}: refusal map is stable");
        assert_eq!(recovered.quality, Quality::Fallback, "{name}: {}", recovered.text);
        assert!(recovered.text.contains("@bytecode"), "no partial structured prefix: {}", recovered.text);
        assert_full_map(REFUSALS, ordinary, name, descriptor);
    }
}

#[test]
fn entry_split_candidate_stops_do_not_publish_a_half_prefix() {
    let mut open_budget = task_budget(&[]).expect("valid open budget");
    let snapshot = Engine::new().open(ArtifactInput::bytes(POSITIVE.to_vec()), &mut open_budget)
        .expect("fixture opens");
    let request = ClassSourceRequest {
        class: ClassRef::Name { class: ClassNameQuery::internal(CLASS) },
        environment: EnvironmentRequest {
            snapshot: snapshot.id().clone(), scope: PhysicalScope::SnapshotAll,
            policy: EnvironmentPolicy::SingleClass,
            profile: RuntimeProfile { java_release: 8, multi_release: MultiReleasePolicy::Disabled, layout: LayoutMode::Generic },
            loader: LoaderId("app".to_owned()),
        },
    };
    for dimension in ["analysis_steps", "output_bytes"] {
        let mut budget = task_budget(&[BudgetOverride::new(dimension, 1).expect("valid bounded override")])
            .expect("budget override is legal");
        let stopped = Engine::new().class_source(slice::from_ref(&snapshot), &request, &mut budget)
            .expect("a budget stop is a report");
        assert!(matches!(stopped,
            OperationOutcome::Incomplete(_) | OperationOutcome::Performed(ClassSourceReport {
                execution: ExecutionReport::Partial { .. }, ..
            })), "{dimension}: {stopped:?}");
    }
    let token = CancellationToken::new();
    token.cancel();
    let mut cancelled = Budget::with_cancellation_token(Limits::default(), token);
    let stopped = Engine::new().class_source(slice::from_ref(&snapshot), &request, &mut cancelled)
        .expect("cancellation is a report");
    assert!(matches!(stopped, OperationOutcome::Incomplete(ClassSourceReport {
        execution: ExecutionReport::Cancelled { .. }, ..
    })), "pre-cancellation publishes no candidate");
}
