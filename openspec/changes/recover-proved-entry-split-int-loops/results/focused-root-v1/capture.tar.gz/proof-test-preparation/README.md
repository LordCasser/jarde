# Entry-split Region proof tests

Test-only candidate for the internal `proved_entry_split_loop` gate. It uses same-run `analyze_method_ir` with `AnalysisStage::ALL`, the checked-in original four-positive fixture and its real topology refusal fixture. The positives cover signed increment, nonzero parameter slots, and the optional prefix transfer. Topology controls assert the Region proof returns `None`. The separate existing public test covers an analysis request without SSA.

The test measures proof-only `AnalysisSteps` and `IrItems` on one completed candidate, then checks an actual low `AnalysisSteps` limit stops at the entry before any owner `IrItems` charge and a pre-cancelled token stops at the first poll. It does not execute the Builder or emit source.

No compiler or test command was run; root owns execution. `changes.patch` adds only this unit test to the pinned current `region.rs`. `pins.json` records source and fixture inputs/results.
