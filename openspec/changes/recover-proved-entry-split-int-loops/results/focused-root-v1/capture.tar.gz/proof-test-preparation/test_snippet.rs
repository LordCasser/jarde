    #[test]
    fn entry_split_region_proof_uses_real_ir_and_stops_before_publication() {
        use jarde_jvm::engine::analyze_method_ir;
        use jarde_jvm::environment::ResolutionEnvironment;
        use jarde_jvm::ir::{AnalysisStage, MethodAnalysisRequest};
        use jarde_reader::artifact::{ArtifactInput, ArtifactSnapshot};
        use jarde_reader::budget::{CancellationToken, Limits};
        use jarde_reader::classfile::MethodCodeFacts;
        use jarde_reader::model::{
            ClassBytesId, Digest, JvmBytes, PhysicalClassLocation, PhysicalDefinitionId,
            PhysicalMethodId, PhysicalVariant,
        };
        use jarde_reader::view::{
            DelegationPolicy, LayoutMode, LoadDomain, LoadRoot, LoaderId, ModuleMode,
            MultiReleasePolicy, PhysicalScope, PhysicalView, RuntimeProfile, RuntimeUncertainty,
            RuntimeView,
        };

        const POSITIVE: &[u8] = include_bytes!(
            "../../../tests/fixtures/cf08-entry-split/cf08/EntrySplitCases.class"
        );
        const TOPOLOGY: &[u8] = include_bytes!(
            "../../../tests/fixtures/cf08-entry-split/cf08/EntrySplitTopologyRefusals.class"
        );

        fn limits(analysis_steps: u64) -> Limits {
            Limits {
                input_bytes: 1 << 20,
                archive_entries: 100,
                entry_bytes: 1 << 20,
                read_bytes: 1 << 20,
                class_bytes: 1 << 20,
                attribute_bytes: 1 << 20,
                code_bytes: 1 << 20,
                result_items: 1 << 20,
                output_bytes: 1 << 20,
                class_headers: 100,
                method_bodies: 100,
                ir_items: 1 << 20,
                ir_edges: 1 << 20,
                analysis_steps,
                normalization_clones: 1 << 20,
                nested_depth: 32,
                dependency_depth: 32,
                elapsed_millis: u64::MAX,
            }
        }

        fn with_method_ir(
            bytes: &[u8],
            name: &str,
            descriptor: &str,
            inspect: impl FnOnce(
                &CanonicalCfg,
                &NormalFlowView,
                &SsaTable,
                &Operations,
                &MethodCodeFacts,
            ),
        ) {
            let mut analysis_budget = Budget::new(limits(1 << 20));
            let snapshot = ArtifactSnapshot::open(
                ArtifactInput::bytes(bytes.to_vec()),
                &mut analysis_budget,
            )
            .expect("fixture class opens");
            let definition = PhysicalDefinitionId {
                location: PhysicalClassLocation::StandaloneRoot {
                    snapshot: snapshot.id().clone(),
                },
                class_bytes: ClassBytesId {
                    digest: Digest(blake3::hash(bytes).to_hex().to_string()),
                    length: u64::try_from(bytes.len()).expect("fixture length fits"),
                },
                variant: PhysicalVariant::Base,
            };
            let domain = LoadDomain {
                loader: LoaderId("app".to_owned()),
                parent_loader: None,
                delegation: DelegationPolicy::ParentFirst,
                roots: vec![LoadRoot::StandaloneClass {
                    snapshot: snapshot.id().clone(),
                }],
                module_mode: ModuleMode::ClassPath,
                external_override: RuntimeUncertainty::None,
                runtime_transformation: RuntimeUncertainty::None,
            };
            let analysis = analyze_method_ir(
                &[snapshot.clone()],
                &MethodAnalysisRequest {
                    environment: ResolutionEnvironment {
                        runtime: RuntimeView {
                            physical: PhysicalView {
                                snapshot: snapshot.id().clone(),
                                scope: PhysicalScope::SnapshotAll,
                            },
                            profile: RuntimeProfile {
                                java_release: 8,
                                multi_release: MultiReleasePolicy::Disabled,
                                layout: LayoutMode::Generic,
                            },
                            load_domain: domain.clone(),
                        },
                        domains: vec![domain],
                        providers: Vec::new(),
                    },
                    method: PhysicalMethodId {
                        owner: definition,
                        name: JvmBytes(name.as_bytes().to_vec()),
                        descriptor: JvmBytes(descriptor.as_bytes().to_vec()),
                    },
                    stages: AnalysisStage::ALL.to_vec(),
                },
                &mut analysis_budget,
            )
            .expect("fixture method has all real IR stages");
            let ir = analysis.ir();
            let canonical = ir.canonical().expect("canonical CFG");
            let ssa = ir.ssa().expect("SSA table");
            let code = ir.code().expect("decoded method code");
            let operations = Operations::of(code, ir.constant_pool());
            let view = NormalFlowView::build(canonical, &mut analysis_budget)
                .expect("normal-flow view builds");
            inspect(canonical, &view, ssa, &operations, code);
        }

        let prove = |canonical: &CanonicalCfg,
                     view: &NormalFlowView,
                     ssa: &SsaTable,
                     operations: &Operations,
                     code: &MethodCodeFacts,
                     budget: &mut Budget| {
            let irreducible = view.irreducible_blocks(&BTreeSet::new());
            proved_entry_split_loop(
                canonical,
                view,
                ssa,
                operations,
                code,
                Some(false),
                &irreducible,
                budget,
            )
        };

        for (name, descriptor) in [
            ("test", "(IZI)I"),
            ("signed", "(IZI)I"),
            ("shifted", "(IIIZI)I"),
            ("inverted", "(IZI)I"),
        ] {
            with_method_ir(POSITIVE, name, descriptor, |canonical, view, ssa, operations, code| {
                let entry_bci = canonical.blocks().first().expect("entry block").id().bci();
                let mut proof_budget = Budget::new(limits(1 << 20));
                let region = prove(canonical, view, ssa, operations, code, &mut proof_budget)
                    .expect("ample budget completes proof");
                assert!(matches!(region, Some(Region::EntrySplitLoop { .. })), "{name}");
                let measured = proof_budget.usage();
                assert!(measured.analysis_steps > 1, "proof work was charged");
                assert_eq!(measured.ir_items, 11, "five owner records plus predecessor vectors");

                if name == "test" {
                    let mut short_budget = Budget::new(limits(1));
                    let stopped = prove(
                        canonical,
                        view,
                        ssa,
                        operations,
                        code,
                        &mut short_budget,
                    );
                    assert_eq!(
                        stopped,
                        Err(StopReason::Budget {
                            dimension: CountedBudgetDimension::AnalysisSteps,
                            written: 0,
                            limit: 1,
                            at: Some(entry_bci),
                        })
                    );
                    assert_eq!(short_budget.usage().analysis_steps, 1);
                    assert_eq!(short_budget.usage().ir_items, 0);

                    let token = CancellationToken::new();
                    token.cancel();
                    let mut cancelled = Budget::with_cancellation_token(limits(1 << 20), token);
                    assert_eq!(
                        prove(canonical, view, ssa, operations, code, &mut cancelled),
                        Err(StopReason::Cancelled { at: Some(entry_bci) })
                    );
                    assert_eq!(cancelled.usage().analysis_steps, 0);
                    assert_eq!(cancelled.usage().ir_items, 0);
                }
            });
        }

        for (name, descriptor) in [
            ("extraEntry", "(IZI)I"),
            ("extraExit", "(IZI)I"),
            ("extraLive", "(IZZI)I"),
            ("stackEscape", "(IZI)I"),
        ] {
            with_method_ir(TOPOLOGY, name, descriptor, |canonical, view, ssa, operations, code| {
                let mut proof_budget = Budget::new(limits(1 << 20));
                assert_eq!(
                    prove(canonical, view, ssa, operations, code, &mut proof_budget)
                        .expect("ample budget completes refusal"),
                    None,
                    "topology control {name} remains outside the exact proof"
                );
            });
        }
    }
