from pathlib import Path
import hashlib,json,re,importlib.util
OUT=Path('/private/tmp/jarde-entry-split-fixture-gate-root-v1-20261019');ROOT=Path('/Users/lordcasser/workspace/projects/jarde');REVIEW=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,msg):
 if not ok:raise ValueError(msg)
d=json.loads((OUT/'execution.json').read_bytes());need(d['status']=='captured_pending_root_review','receipt status');need(d['source_unchanged'] and d['sources_before']==d['sources_after'],'source changed');need(d['external_unchanged'] and d['external_before']==d['external_after'],'external changed');need(d['target_absent'] and not (ROOT/'target').exists(),'target')
seen={}
def walk(x):
 if isinstance(x,dict):
  if set(('path','bytes','sha256'))<=set(x):
   p=Path(x['path']);b=p.read_bytes();need(len(b)==x['bytes'] and sha(b)==x['sha256'],'pin '+str(p));seen[str(p)]=x['sha256']
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(d)
need(len(d['commands'])==17,'17 actual commands')
for row in d['commands']:
 need(row['guard_stop'] is None,'guard '+row['label']);need(row['exit_code']==(1 if row['label'].startswith('wrong-root-') else 0),'exit '+row['label'])
 need(Path(row['cwd'])==OUT/'empty','cwd');need('RUST_MIN_STACK' not in row['env_overrides'],'stack override')
classes=d['classes'];expected={'EntrySplitCases':(52,5),'EntrySplitRefusals':(52,5),'EntrySplitTopologyRefusals':(52,5),'EntrySplitExceptionRefusal':(52,2),'EntrySplitLegacyCases':(49,2)}
need(len(classes)==5,'class count')
for rel,x in classes.items():
 stem=Path(rel).stem;f=x['facts'];need((f['major'],len(f['methods']))==expected[stem],'inventory '+stem);need(f['class_name']=='cf08/'+stem,'internal name');need(f['fields']==[],'fields');need(any(m['name']=='<init>' and m['descriptor']=='()V' and m['access']==1 for m in f['methods']),'constructor')
# Independent physical parser runs against actual bytes, not the collector JSON facts.
spec=importlib.util.spec_from_file_location('gate_physical','/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py');physical=importlib.util.module_from_spec(spec);spec.loader.exec_module(physical)
for rel,x in classes.items():
 f=physical.parse_class_file(Path(x['pin']['path']).read_bytes());need(f['class_name']==x['facts']['class_name'] and f['major']==x['facts']['major'] and f['methods']==x['facts']['methods'],'independent physical parse '+rel)
parsed=[]
for run in d['original_runs']:
 row=next(x for x in d['commands'] if x['label']==run['command']);lines=Path(row['streams']['stdout']['path']).read_text().splitlines();cases=[x for x in lines if x.startswith('CASE ')];invs=[x for x in lines if x.startswith('INVENTORY ')];need(len(cases)==72 and len(invs)==4,'case census');got={}
 for line in cases:
  m=re.fullmatch(r'CASE name=(test|signed|shifted|inverted)-initial-(-?\d+)-skip-(true|false)-steps-([012]) actual=(-?\d+) expected=(-?\d+)',line);need(m is not None,'case syntax');method,initial,skip,steps,actual,stated=m.groups();amount={'test':3,'signed':-5,'shifted':5,'inverted':-2}[method];v=int(initial)+amount*(int(steps)+(skip=='false'));v=((v+2**31)%2**32)-2**31;need(int(actual)==v==int(stated),'independent wrapped formula');key=(method,int(initial),skip,int(steps));need(key not in got,'duplicate');got[key]=v
 need({k[1] for k in got}=={17,2**31-2,-2**31+1},'bounds');parsed.append(got)
need(len(parsed)==2 and parsed[0]==parsed[1],'two VMs same')
for name in d['wrong_roots']:
 row=next(x for x in d['commands'] if x['label']==name);need(b'wrong CodeSource' in Path(row['streams']['stderr']['path']).read_bytes(),'wrongroot reason')
api=[]
for cell in d['baseline_api']:
 row=next(x for x in d['commands'] if x['label']==cell['command']);raw=json.loads(Path(row['streams']['stdout']['path']).read_bytes());need(raw['text']==Path(cell['source']['path']).read_text(),'full text');need(raw['methods']==cell['methods'],'member facts')
 for m in cell['methods']:
  name=m['item']['name']['escaped'];r=m['outcome']['report'];need(r['execution']['status']=='complete','baseline complete')
  if name=='<init>':need(r['quality']=='structured','constructor structured');continue
  need(r['quality']=='fallback' and r['representation']=='mixed','prior fallback');codes=[x['code'] for x in r['diagnostics']]
  if cell['class']=='EntrySplitLegacyCases':need(codes.count('jre_region_subroutine_entry')==2 and codes.count('jre_region_uncovered_blocks')==1,'legacy unchanged refusal')
  else:need(codes.count('jre_region_irreducible')==1,'whole irreducible')
  api.append({'class':cell['class'],'name':name,'quality':r['quality'],'representation':r['representation'],'codes':codes})
review={'status':'root_accepted_verifier_valid_fixtures_and_old_cli_baseline','receipt_sha256':sha((OUT/'execution.json').read_bytes()),'reviewer_sha256':sha(Path(__file__).read_bytes()),'commands':17,'actual_classes':5,'positive_methods':4,'negative_methods_not_invoked':10,'original_vms':2,'original_observations':144,'negative_constructor_inventory_per_vm':4,'wrong_root_rejections':2,'unique_pinned_paths_reopened':len(seen),'independent_physical_parsers_agree':True,'original_wrapped_formula_independently_checked':True,'baseline_methods':api,'notes':['All five complete original classes accepted by both configured VMs with -Xverify:all. Negative methods never invoked.','Legacy remains existing mixed representation/fallback quality with two SubroutineEntry and one UncoveredBlocks diagnostics; it is not a new whole-method quote.','Temporary pre-execution writer/driver branch corrections in v1-v3 remain historical drafts. No runtime VerifyError occurred in this gate.','Final generated Java/JADX/Jarde comparison and production implementation are not yet accepted.']}
(REVIEW/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');(OUT/'root-review.json').write_text(json.dumps({'status':review['status'],'receipt_sha256':review['receipt_sha256'],'review':str(REVIEW/'review.json')},ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in review.items() if k!='baseline_methods'},ensure_ascii=False))
