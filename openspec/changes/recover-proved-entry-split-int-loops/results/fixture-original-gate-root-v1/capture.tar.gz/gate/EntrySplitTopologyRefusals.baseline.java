// jarde: presentation of `cf08/EntrySplitTopologyRefusals` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf08;

public final class EntrySplitTopologyRefusals extends java.lang.Object {
    public EntrySplitTopologyRefusals() {
        // @method <init>()V
        // @declaration a constructor of `cf08.EntrySplitTopologyRefusals`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static int extraEntry(int arg0, boolean arg1, int arg2) {
        // jarde: not recovered: the recovery run for `extraEntry(IZI)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method extraEntry(IZI)I
        // @declaration a static method of `cf08.EntrySplitTopologyRefusals`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 5 8 11 14 15 18 21 24 25
        // the graph is not reducible over 3 block(s) [11, 14, 18]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }

    public static int extraExit(int arg0, boolean arg1, int arg2) {
        // jarde: not recovered: the recovery run for `extraExit(IZI)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method extraExit(IZI)I
        // @declaration a static method of `cf08.EntrySplitTopologyRefusals`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 7 8 11 14 15 18 21 22 23 24
        // the graph is not reducible over 4 block(s) [4, 7, 11, 18]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }

    public static int extraLive(int arg0, boolean arg1, boolean arg2, int arg3) {
        // jarde: not recovered: the recovery run for `extraLive(IZZI)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method extraLive(IZZI)I
        // @declaration a static method of `cf08.EntrySplitTopologyRefusals`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 7 8 11 14 17 18 21 24 27 28
        // the graph is not reducible over 3 block(s) [4, 7, 11]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }

    public static int stackEscape(int arg0, boolean arg1, int arg2) {
        // jarde: not recovered: the recovery run for `stackEscape(IZI)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method stackEscape(IZI)I
        // @declaration a static method of `cf08.EntrySplitTopologyRefusals`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 2 5 6 7 8 11 14 17
        // the graph is not reducible over 3 block(s) [5, 7, 11]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }
}
