// jarde: presentation of `cf08/EntrySplitCases` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf08;

public final class EntrySplitCases extends java.lang.Object {
    public EntrySplitCases() {
        // @method <init>()V
        // @declaration a constructor of `cf08.EntrySplitCases`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static int test(int arg0, boolean arg1, int arg2) {
        // jarde: not recovered: the recovery run for `test(IZI)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method test(IZI)I
        // @declaration a static method of `cf08.EntrySplitCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 7 8 11 14 17 18
        // the graph is not reducible over 3 block(s) [4, 7, 11]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }

    public static int signed(int arg0, boolean arg1, int arg2) {
        // jarde: not recovered: the recovery run for `signed(IZI)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method signed(IZI)I
        // @declaration a static method of `cf08.EntrySplitCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 7 8 11 14 17 18
        // the graph is not reducible over 3 block(s) [4, 7, 11]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }

    public static int shifted(int arg0, int arg1, int arg2, boolean arg3, int arg4) {
        // jarde: not recovered: the recovery run for `shifted(IIIZI)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method shifted(IIIZI)I
        // @declaration a static method of `cf08.EntrySplitCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 7 9 12 15 18 19
        // the graph is not reducible over 3 block(s) [4, 7, 12]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }

    public static int inverted(int arg0, boolean arg1, int arg2) {
        // jarde: not recovered: the recovery run for `inverted(IZI)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method inverted(IZI)I
        // @declaration a static method of `cf08.EntrySplitCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 5 8 11 14 17 20 21
        // the graph is not reducible over 3 block(s) [4, 14, 8]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }
}
