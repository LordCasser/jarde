// jarde: presentation of `cf08/EntrySplitExceptionRefusal` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf08;

public final class EntrySplitExceptionRefusal extends java.lang.Object {
    public EntrySplitExceptionRefusal() {
        // @method <init>()V
        // @declaration a constructor of `cf08.EntrySplitExceptionRefusal`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static int exceptionPrefix(int arg0, boolean arg1, int arg2, int arg3) {
        // jarde: not recovered: the recovery run for `exceptionPrefix(IZII)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method exceptionPrefix(IZII)I
        // @declaration a static method of `cf08.EntrySplitExceptionRefusal`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 5 6 7 8 9 12 15 18 19 20 21 23
        // the graph is not reducible over 3 block(s) [4, 8, 12]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }
}
