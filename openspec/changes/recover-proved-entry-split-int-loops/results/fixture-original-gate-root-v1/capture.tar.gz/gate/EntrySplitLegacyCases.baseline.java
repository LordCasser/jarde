// jarde: presentation of `cf08/EntrySplitLegacyCases` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf08;

public final class EntrySplitLegacyCases extends java.lang.Object {
    public EntrySplitLegacyCases() {
        // @method <init>()V
        // @declaration a constructor of `cf08.EntrySplitLegacyCases`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static int legacy(int arg0, boolean arg1, int arg2) {
        // @method legacy(IZI)I
        // @declaration a static method of `cf08.EntrySplitLegacyCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        if (!arg1) {
            // @bytecode 4
            // block at BCI 4 is entered by the jsr at BCI 4: a subroutine body is not a Java statement
        } else if (arg2 != 0) {
            // @bytecode 14 17
            // block at BCI 14 is entered by the jsr at BCI 17: a subroutine body is not a Java statement
    } else {
            return arg0;
    }
        // @bytecode 7 20 25 26 29
        // 4 live block(s) are reachable only through edges the normal-flow view leaves out: [25, 7, 25, 20]
    }
}
