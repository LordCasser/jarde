# Entry-split 2.2 follow-up preparation (v3)

Private-only additions; no shared files changed and no Java/Cargo/toolchain command ran. v1 and v2 snapshots remain preserved under their own paths. All new class bytes are still **unverified candidates**, not accepted fixtures.

## Manually re-counted v2/v3 BCI and frame ledger

Offsets below are absolute instruction-start BCIs. Conditional and `goto` displacements are signed 16-bit offsets from the branch opcode BCI. For StackMapTable `same_frame`, `offset_delta = tag`; each next absolute BCI is prior BCI + delta + 1. The ledger checks instruction starts, branch destinations, frames, and class version by hand only.

| Method | Code layout / edges | Frames |
|---|---|---|
| `inverted(IZI)I` | `0 iload_1; 1 ifeq +13 ->14; 4 iload_2; 5 ifeq +15 ->20; 8 iinc_2,-1; 11 goto +3 ->14; 14 iinc_0,-2; 17 goto -13 ->4; 20 iload_0; 21 ireturn` (22 bytes) | BCI 4,14,20; deltas 4,9,5 |
| `callPrefix(IZI)I` | `0 iload_1; 1 ifne +8 ->9; 4 iload_0; 5 invokestatic Math.incrementExact; 8 istore_0; 9 iload_2; 10 ifeq +9 ->19; 13 iinc_2,-1; 16 goto -12 ->4; 19 iload_0; 20 ireturn` (21 bytes) | BCI 4,9,19; deltas 4,4,9 |
| `extraEntry(IZI)I` | `0 iload_1; 1 ifeq +10 ->11; 4 iload_2; 5 ifeq +9 ->14; 8 goto +10 ->18; 11 iinc_0,+3; 14 iload_2; 15 ifeq +9 ->24; 18 iinc_2,-1; 21 goto -10 ->11; 24 iload_0; 25 ireturn` (26 bytes) | BCI 11,14,18,24; deltas 11,2,3,5 |
| `extraExit(IZI)I` | `0 iload_1; 1 ifne +6 ->7; 4 iinc_0,+3; 7 iload_2; 8 ifeq +15 ->23; 11 iinc_2,-1; 14 iload_2; 15 ifeq +6 ->21; 18 goto -14 ->4; 21 iload_0; 22 ireturn; 23 iload_0; 24 ireturn` (25 bytes) | BCI 4,7,21,23; deltas 4,2,13,1 |
| `extraLive(IZZI)I` | `0 iload_1; 1 ifne +6 ->7; 4 iinc_0,+3; 7 iload_3; 8 ifeq +9 ->17; 11 iinc_3,-1; 14 goto -10 ->4; 17 iload_2; 18 ifne +9 ->27; 21 iinc_0,+1; 24 goto +3 ->27; 27 iload_0; 28 ireturn` (29 bytes) | BCI 4,7,17,27; deltas 4,2,9,9 |
| `stackEscape(IZI)I` | `0 iload_0; 1 iload_1; 2 ifne +5 ->7; 5 iconst_3; 6 iadd; 7 iload_2; 8 ifeq +9 ->17; 11 iinc_2,-1; 14 goto -9 ->5; 17 ireturn` (18 bytes). Value is on stack on both sides of the branch and loop. | `same_locals_1_stack_item_frame` at 5,7,17; deltas 5,1,9 and stack Integer |
| `exceptionPrefix(IZII)I` | `0 iload_1; 1 ifne +7 ->8; 4 iload_0; 5 iload_3; 6 idiv; 7 istore_0; 8 iload_2; 9 ifeq +9 ->18; 12 iinc_2,-1; 15 goto -11 ->4; 18 iload_0; 19 ireturn; 20 pop; 21 bipush 99; 23 ireturn` (24 bytes). Handler `[4,8) ->20`, catch `ArithmeticException`. | BCI 4,8,18 have same frames (deltas 4,3,9); full frame at 20 (delta 1), locals four Integer, stack one `java/lang/ArithmeticException` |
| `legacy(IZI)I` | class major 49 only: `0 iload_1; 1 ifne +9 ->10; 4 jsr +21 ->25; 7 goto +3 ->10; 10 iload_2; 11 ifeq +12 ->23; 14 iinc_2,-1; 17 jsr +8 ->25; 20 goto -10 ->10; 23 iload_0; 24 ireturn; 25 astore_3; 26 iinc_0,+3; 29 ret 3` (31 bytes) | No StackMapTable; legacy control, not a Java 8/version-52 claim |

The hand ledger corrects v2's `extraExit` target/frame and both `legacy` subroutine targets after a second independent recount. The v3 source includes the corrected displacements; the v2 snapshot retains the original unexecuted source and errors for audit history. Root must still decode each emitted class and verify actual frames/handlers before adopting any.

## Exception and missing-facts controls

The new `exceptionPrefix(IZII)I` is a version-52 candidate with a real `Code.exception_table` row and a full handler StackMap frame. Its handler is an extra exceptional exit from the arithmetic prefix. The Rust addition asserts the physical handler tuple `(start=4,end=8,handler=20)`, structured-vs-quoted quality, and complete BCI mapping. This is still a candidate; if the configured JVM or reader rejects it, do not weaken the assertions—repair the classfile bytes first.

The second added test makes a legal public `MethodAnalysisRequest` for the positive fixture that requests all analysis stages except SSA. It asserts the report's normalized request and actual stage list omit SSA; it does not mutate canonical IR or claim an omitted stage is a malformed classfile. This uses the existing `AnalysisStage` request contract as the missing-facts seam.

## Scope and remaining validation

The parentless driver checks class loader, exact CodeSource, fields, public no-argument constructor, and exact method descriptors for refusal classes; it constructs the constructor only and never invokes a negative method. `callPrefix` has an observable checked-overflow behavior and demonstrates a valid call/effect in the prefix. The generated topologies are intended to refuse as whole methods, but they are not `verifier-valid` until root runs the chosen JVM verifier.

Budget work remains for root after integration. `tests/p3_lambda_adaptation.rs` provides measured `Budget::usage()` plus legal-bound sweeps and exact `StopReason` assertions. Sweep the real integrated entry-split fixture and retain the limit, stop reason/location, and usage for every selected cut. The cuts must be shown independently for proof traversal, initial-prefix rendering, duplicated loop-tail rendering, and source-map work, with no partial candidate published. A limit number alone is not proof of a semantic phase. Do not add public mutable IR/facts construction APIs or invent stable phase labels to make a test pass.
