import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Emits verifier-valid version-52 control classes; no target source is synthesized or repaired. */
public final class EntrySplitFixtureWriter {
    private static final class MethodSpec {
        final String name, descriptor;
        final int access, maxStack, maxLocals;
        final byte[] code, frames;
        MethodSpec(String n, String d, int a, int s, int l, byte[] c, byte[] f) {
            name=n; descriptor=d; access=a; maxStack=s; maxLocals=l; code=c; frames=f;
        }
    }
    private static final class Pool {
        final List<byte[]> entries = new ArrayList<>();
        final Map<String,Integer> ids = new HashMap<>();
        int add(String key, byte[] bytes) { Integer old=ids.get(key); if(old!=null)return old; entries.add(bytes); int id=entries.size(); ids.put(key,id); return id; }
        int utf(String s) throws IOException { ByteArrayOutputStream b=new ByteArrayOutputStream(); DataOutputStream o=new DataOutputStream(b); o.writeByte(1); o.writeUTF(s); return add("U"+s,b.toByteArray()); }
        int clazz(String s) throws IOException { int u=utf(s); return add("C"+s,new byte[]{7,(byte)(u>>>8),(byte)u}); }
        int nat(String n,String d) throws IOException { int a=utf(n),b=utf(d); return add("N"+n+"\0"+d,new byte[]{12,(byte)(a>>>8),(byte)a,(byte)(b>>>8),(byte)b}); }
        int method(String c,String n,String d) throws IOException { int a=clazz(c),b=nat(n,d); return add("M"+c+"."+n+d,new byte[]{10,(byte)(a>>>8),(byte)a,(byte)(b>>>8),(byte)b}); }
        void write(DataOutputStream o) throws IOException { o.writeShort(entries.size()+1); for(byte[] e:entries)o.write(e); }
    }
    private static final int PUBLIC_STATIC=0x0009;
    private static final int[] SAME_FRAMES={4,2,9};

    public static void main(String[] args) throws Exception {
        if(args.length!=1) throw new IllegalArgumentException("usage: EntrySplitFixtureWriter <class-root>");
        Path root=Paths.get(args[0]);
        write(root,"cf08/EntrySplitCases.class","cf08/EntrySplitCases",positive());
        write(root,"cf08/EntrySplitRefusals.class","cf08/EntrySplitRefusals",refusals());
        write(root,"cf08/EntrySplitTopologyRefusals.class","cf08/EntrySplitTopologyRefusals",topologyRefusals());
        writeLegacy(root);
    }
    private static List<MethodSpec> positive() {
        List<MethodSpec> m=new ArrayList<>();
        m.add(new MethodSpec("test","(IZI)I",PUBLIC_STATIC,1,3,
            new byte[]{0x1b,(byte)0x9a,0,6,(byte)0x84,0,3,0x1c,(byte)0x99,0,9,(byte)0x84,2,(byte)0xff,(byte)0xa7,(byte)0xff,(byte)0xf6,0x1a,(byte)0xac},
            new byte[]{0,3,4,2,9}));
        m.add(new MethodSpec("signed","(IZI)I",PUBLIC_STATIC,1,3,
            new byte[]{0x1b,(byte)0x9a,0,6,(byte)0x84,0,(byte)0xfb,0x1c,(byte)0x99,0,9,(byte)0x84,2,(byte)0xff,(byte)0xa7,(byte)0xff,(byte)0xf6,0x1a,(byte)0xac},
            new byte[]{0,3,4,2,9}));
        m.add(new MethodSpec("shifted","(IIIZI)I",PUBLIC_STATIC,1,5,
            new byte[]{0x1d,(byte)0x9a,0,6,(byte)0x84,0,5,0x15,4,(byte)0x99,0,9,(byte)0x84,4,(byte)0xff,(byte)0xa7,(byte)0xff,(byte)0xf5,0x1a,(byte)0xac},
            new byte[]{0,3,4,2,10}));
        m.add(new MethodSpec("inverted","(IZI)I",PUBLIC_STATIC,1,3,
            new byte[]{0x1b,(byte)0x99,0,13,0x1c,(byte)0x99,0,15,(byte)0x84,2,(byte)0xff,(byte)0xa7,0,3,(byte)0x84,0,(byte)0xfe,(byte)0xa7,(byte)0xff,(byte)0xf3,0x1a,(byte)0xac},
            new byte[]{0,3,4,9,5}));
        return m;
    }
    private static List<MethodSpec> refusals() {
        List<MethodSpec> m=new ArrayList<>();
        m.add(new MethodSpec("booleanPrefix","(ZZI)I",PUBLIC_STATIC,1,3,
            new byte[]{0x1b,(byte)0x9a,0,6,(byte)0x84,0,1,0x1c,(byte)0x99,0,9,(byte)0x84,2,(byte)0xff,(byte)0xa7,(byte)0xff,(byte)0xf6,0x1a,(byte)0xac},new byte[]{0,3,4,2,9}));
        m.add(new MethodSpec("bytePrefix","(BZI)I",PUBLIC_STATIC,1,3,
            new byte[]{0x1b,(byte)0x9a,0,6,(byte)0x84,0,5,0x1c,(byte)0x99,0,9,(byte)0x84,2,(byte)0xff,(byte)0xa7,(byte)0xff,(byte)0xf6,0x1a,(byte)0xac},new byte[]{0,3,4,2,9}));
        m.add(new MethodSpec("alias","(IZ)I",PUBLIC_STATIC,1,2,
            new byte[]{0x1b,(byte)0x9a,0,6,(byte)0x84,0,1,0x1a,(byte)0x99,0,9,(byte)0x84,0,(byte)0xff,(byte)0xa7,(byte)0xff,(byte)0xf6,0x1a,(byte)0xac},new byte[]{0,3,4,2,9}));
        // Math.incrementExact is a valid call with observable overflow behavior; the first slice rejects calls in P.
        m.add(new MethodSpec("callPrefix","(IZI)I",PUBLIC_STATIC,1,3,
            new byte[]{0x1b,(byte)0x9a,0,8,0x1a,(byte)0xb8,0,0,(byte)0x3b,0x1c,(byte)0x99,0,9,(byte)0x84,2,(byte)0xff,(byte)0xa7,(byte)0xff,(byte)0xf4,0x1a,(byte)0xac},new byte[]{0,3,4,4,9}));
        return m;
    }
    private static List<MethodSpec> topologyRefusals() {
        List<MethodSpec> m=new ArrayList<>();
        // Three preheader successors enter the SCC at P(11), H(14), and L(18).
        m.add(new MethodSpec("extraEntry","(IZI)I",PUBLIC_STATIC,1,3,
            new byte[]{0x1b,(byte)0x99,0,10,0x1c,(byte)0x99,0,9,(byte)0xa7,0,10,(byte)0x84,0,3,0x1c,(byte)0x99,0,9,(byte)0x84,2,(byte)0xff,(byte)0xa7,(byte)0xff,(byte)0xf6,0x1a,(byte)0xac},
            new byte[]{0,4,11,2,3,5}));
        // The loop has two reachable exits and two return blocks.
        m.add(new MethodSpec("extraExit","(IZI)I",PUBLIC_STATIC,1,3,
            new byte[]{0x1b,(byte)0x9a,0,6,(byte)0x84,0,3,0x1c,(byte)0x99,0,14,(byte)0x84,2,(byte)0xff,0x1c,(byte)0x99,0,5,(byte)0xa7,(byte)0xff,(byte)0xf2,0x1a,(byte)0xac,0x1a,(byte)0xac},
            new byte[]{0,4,4,2,12,1}));
        // A live side node lies after the loop exit and before the returned value.
        m.add(new MethodSpec("extraLive","(IZZI)I",PUBLIC_STATIC,1,4,
            new byte[]{0x1b,(byte)0x9a,0,6,(byte)0x84,0,3,0x1d,(byte)0x99,0,9,(byte)0x84,3,(byte)0xff,(byte)0xa7,(byte)0xff,(byte)0xf6,0x1c,(byte)0x9a,0,9,(byte)0x84,0,1,(byte)0xa7,0,3,0x1a,(byte)0xac},
            new byte[]{0,4,4,2,9,9}));
        // Value remains on the operand stack from the entry test through exit.
        m.add(new MethodSpec("stackEscape","(IZI)I",PUBLIC_STATIC,2,3,
            new byte[]{0x1a,0x1b,(byte)0x9a,0,5,0x06,0x60,0x1c,(byte)0x99,0,9,(byte)0x84,2,(byte)0xff,(byte)0xa7,(byte)0xff,(byte)0xf7,(byte)0xac},
            new byte[]{0,3,69,1,65,1,73,1}));
        return m;
    }
    private static void writeLegacy(Path root) throws Exception {
        List<MethodSpec> m=new ArrayList<>();
        // Version 49 legacy subroutine control. This does not claim Java 8 support.
        m.add(new MethodSpec("legacy","(IZI)I",PUBLIC_STATIC,1,4,
            new byte[]{0x1b,(byte)0x9a,0,9,(byte)0xa8,0,20,(byte)0xa7,0,3,0x1c,(byte)0x99,0,11,(byte)0x84,2,(byte)0xff,(byte)0xa8,0,7,(byte)0xa7,(byte)0xff,(byte)0xf6,0x1a,(byte)0xac,0x4e,(byte)0x84,0,3,(byte)0xa9,3},null));
        writeVersion(root,"cf08/EntrySplitLegacyCases.class","cf08/EntrySplitLegacyCases",m,49);
    }
    private static void write(Path root,String path,String internal,List<MethodSpec> methods) throws Exception { writeVersion(root,path,internal,methods,52); }
    private static void writeVersion(Path root,String path,String internal,List<MethodSpec> methods,int major) throws Exception {
        Pool cp=new Pool();
        int thisClass=cp.clazz(internal), superClass=cp.clazz("java/lang/Object");
        int initName=cp.utf("<init>"), initDesc=cp.utf("()V"), initRef=cp.method("java/lang/Object","<init>","()V");
        int codeName=cp.utf("Code"), stackName=cp.utf("StackMapTable"), sourceName=cp.utf("SourceFile"), sourceFile=cp.utf("EntrySplitFixtureWriter.java");
        for(MethodSpec m:methods){cp.utf(m.name);cp.utf(m.descriptor);}
        int mathRef=cp.method("java/lang/Math","incrementExact","(I)I");
        // Patch the deliberately unresolved call operands with the constant-pool index.
        for(MethodSpec m:methods) if(m.name.equals("callPrefix")){m.code[6]=(byte)(mathRef>>>8);m.code[7]=(byte)mathRef;}
        ByteArrayOutputStream bytes=new ByteArrayOutputStream(); DataOutputStream out=new DataOutputStream(bytes);
        out.writeInt(0xcafebabe);out.writeShort(0);out.writeShort(major);cp.write(out);
        out.writeShort(0x0031);out.writeShort(thisClass);out.writeShort(superClass);out.writeShort(0);out.writeShort(0);
        out.writeShort(methods.size()+1);
        writeMethod(out,initName,initDesc,0x0001,1,1,new byte[]{0x2a,(byte)0xb7,(byte)(initRef>>>8),(byte)initRef,(byte)0xb1},null,codeName,stackName);
        for(MethodSpec m:methods)writeMethod(out,cp.utf(m.name),cp.utf(m.descriptor),m.access,m.maxStack,m.maxLocals,m.code,m.frames,codeName,stackName);
        out.writeShort(1);out.writeShort(sourceName);out.writeInt(2);out.writeShort(sourceFile);out.flush();
        Path target=root.resolve(path);Files.createDirectories(target.getParent());Files.write(target,bytes.toByteArray());
    }
    private static void writeMethod(DataOutputStream out,int name,int desc,int access,int maxStack,int maxLocals,byte[] code,byte[] frames,int codeName,int stackName)throws Exception{
        ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream c=new DataOutputStream(b);c.writeShort(maxStack);c.writeShort(maxLocals);c.writeInt(code.length);c.write(code);c.writeShort(0);c.writeShort(frames==null?0:1);
        if(frames!=null){c.writeShort(stackName);c.writeInt(frames.length);c.write(frames);}c.flush();out.writeShort(access);out.writeShort(name);out.writeShort(desc);out.writeShort(1);out.writeShort(codeName);out.writeInt(b.size());out.write(b.toByteArray());
    }
}
