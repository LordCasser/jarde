# Entry-split 2.2 additional private preparation (v2)

This directory preserves the unmodified first-slice files from v1 and adds bounded follow-up material. Nothing here was compiled, verifier-checked, or executed. In particular, every emitted `.class` is only a source-level candidate until the root runs its verifier gate. No shared file was changed.

## Corrections made to v1 source before any execution

- `inverted(IZI)I`: the initial branch at BCI 1 remains `ifeq 14` (prefix), and the loop test at BCI 5 now branches by `+15` to BCI 20 (the actual exit), rather than into the backedge instruction at BCI 17. Existing frames remain at BCIs 4, 14, and 20.
- `callPrefix(IZI)I`: `goto` at BCI 16 now has displacement `-12` to the prefix at BCI 4; the prior `-15` landed at BCI 1 with an invalid stack state.
- The driver now loads refusal classes parentlessly and checks loader, CodeSource, fields/constructor/method inventories without invoking negative methods. This prevents the alias control's loop from hanging the finite positive oracle.

These are corrections to unexecuted source, not runtime evidence.

## Added verifier candidates

`EntrySplitTopologyRefusals.class` contains four complete methods, each a candidate whole-method refusal:

- `extraEntry(IZI)I`: preheader reaches three distinct SCC nodes (prefix, header, latch).
- `extraExit(IZI)I`: loop has two return exits.
- `extraLive(IZZI)I`: an extra live side node and return path follows the loop exit.
- `stackEscape(IZI)I`: an integer remains on the operand stack across the loop and is consumed at the return.

The source byte arrays and StackMapTable entries are hand-authored. Their BCI layout was manually re-counted, but no verifier has accepted them yet. Root must run `javap`/the configured verifier and inspect actual decoded instructions, frames, handlers, and Code boundaries before adding fixtures. The append-only Rust candidate is in `p3_entry_split_v2_additions.rs.txt`.

`callPrefix(IZI)I` is the call/exception-effect control already present in the first refusal class, with its branch corrected above. An explicit exception-table prefix case remains pending: adding the handler creates a real exceptional CFG edge and requires exact handler frame/CP encoding; I did not present an unverified byte sequence as a valid fixture. If required by the design, add it only after the writer can encode and a real verifier accepts the handler table and stack map.

`EntrySplitLegacyCases.class` is classfile major 49 and contains one `jsr`/`ret` method. It is deliberately labelled legacy and is not a Java 8/version-52 proof case. The candidate test only asserts fallback/map closure; no method invocation is needed.

## Budget/cancellation test plan (not claimed as a passing test)

Use the existing measured-budget pattern in `tests/p3_lambda_adaptation.rs`: first perform an ample complete recovery and retain its `Budget::usage()`; then sweep each legal `analysis_steps`, `ir_items`, and `output_bytes` bound from 1 to the measured limit, selecting only actual `Stopped`/partial outcomes and checking empty or atomic publication as specified by the integrated implementation. Preserve exact `StopReason` location and usage for each observed stop. A generic `limit=1` assertion or pre-cancel alone does not prove the entry-split proof, first prefix rendering, duplicated loop-tail rendering, or source-map phase.

The design requires stopping at the proof scan, at each of the two prefix presentation points, and while source-map work is in progress, with no partial method/body published. Current public helpers expose request budgets and complete usage but no stated stable semantic phase labels. Root must derive actual cut points from the integrated implementation's charged operations and run the sweep; do not infer a phase from a numeric threshold alone. If one dimension cannot reach a unique cut, keep that boundary pending rather than adding a public mutator or test-only production seam. Cancellation should similarly be triggered at a measured observer boundary only if the existing public test harness can do so without changing production APIs.

## Still pending

- Explicit verifier-accepted exception-table prefix control and its exact catch/handler source-map refusal test.
- Actual classfile verification and corrected-driver execution.
- Real per-phase budget/cancellation cuts after implementation integration.
- Missing/incomplete/ambiguous IR facts: use the existing `AnalysisStage` request omission or existing internal test seam only. Do not add mutable public `CanonicalIr`/facts-builder APIs.
- Any alias, unknown, call, exception, or stack negative not represented by a verifier-accepted class remains a pending internal proof test, not a claimed JVM control.
