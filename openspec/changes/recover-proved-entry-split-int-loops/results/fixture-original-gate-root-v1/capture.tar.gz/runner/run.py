from pathlib import Path
import importlib.util,json,os,shutil,sys,hashlib
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
PREP=Path('/private/tmp/jarde-entry-split-tests-prep-luna-v3-20261019')
OUT=Path('/private/tmp/jarde-entry-split-fixture-gate-root-v1-20261019')
def load(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
compare_path=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
guard_path=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
scanner_path=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
for p,h in [(compare_path,'18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'),(guard_path,'51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'),(scanner_path,'d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7')]:
 assert hashlib.sha256(p.read_bytes()).hexdigest()==h
c=load(compare_path,'fixturegate_compare');g=load(guard_path,'fixturegate_guard');scan=load(scanner_path,'fixturegate_scanner')
jdks,jdkrec=c.configured_jdks(ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json','ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
cli=Path('/private/tmp/jarde-assignment-condition-widening-broad-resume-root-v1-20261019/candidate-cli');assert c.sha(cli)=='96e534b0000fe91c1d34a282919479a97eb4706063501d188cdff010c4640366'
assert not OUT.exists() and not (ROOT/'target').exists() and shutil.disk_usage(ROOT).free>=5*1024**3
OUT.mkdir();(OUT/'raw').mkdir();(OUT/'inputs').mkdir();(OUT/'empty').mkdir();(OUT/'writer').mkdir();(OUT/'driver').mkdir();(OUT/'original-classes').mkdir()
for rel in ['classwriter/EntrySplitFixtureWriter.java','driver/EntrySplitOracleDriver.java']:
 shutil.copy2(PREP/rel,OUT/'inputs'/Path(rel).name)
external=[compare_path,guard_path,scanner_path,cli,Path(__file__),*sorted(p for p in PREP.rglob('*') if p.is_file()),*(p for spec in jdks.values() for p in spec['tools'].values())]
report={'schema':'entry-split-fixture-verifier-gate-root-v1','status':'running','commands':[],'jdk_manifest':jdkrec,'cli':c.pin(cli),'sources_before':c.source_closure(ROOT),'external_before':[c.pin(p) for p in external],'classes':{},'original_runs':[],'wrong_roots':[],'baseline_api':[]}
g.ROOT=OUT/'empty';g.OUT=OUT/'raw';g.target_bytes=lambda:scan.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda i,b:None
# Existing bounded runtime wrapper is pinned and executed by its Python interpreter, not as a shell.
bound=Path('/private/tmp/jarde-testendlessloop-baseline-root-v1-20261019/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
assert c.sha(bound)=='73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
report['runtime_wrapper']=c.pin(bound)
def save():c.write_json(OUT/'execution.json',report)
def command(argv,label,leg='javac8',require=True):
 assert not (ROOT/'target').exists()
 env=c.clean_env(dict(os.environ),jdks[leg]);env.update(g.ENV_VALUES);env.pop('RUST_MIN_STACK',None)
 row=g.run_command(len(report['commands'])+1,[str(a) for a in argv],env);row.update(label=label,tool_leg=leg);report['commands'].append(row);save()
 assert row.get('guard_stop') is None and row.get('exit_code') is not None
 if require:assert row['exit_code']==0,(label,row['exit_code'])
 return row
empty=OUT/'empty';classes=OUT/'original-classes';save()
try:
 command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g:none','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',OUT/'writer',OUT/'inputs/EntrySplitFixtureWriter.java'],'compile-writer')
 command([jdks['javac8']['tools']['java'],'-Xverify:all','-cp',OUT/'writer','EntrySplitFixtureWriter',classes],'run-writer')
 command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g:none','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',OUT/'driver',OUT/'inputs/EntrySplitOracleDriver.java'],'compile-driver')
 for p in sorted(classes.rglob('*.class')):
  f=c.parse_class(p);report['classes'][p.relative_to(classes).as_posix()]={'pin':c.pin(p),'facts':f}
  command([jdks['javac8']['tools']['javap'],'-v','-c','-p',p],'javap-'+p.stem)
 assert len(report['classes'])==5
 for leg in jdks:
  row=command([sys.executable,'-B',bound,'30',jdks[leg]['tools']['java'],'-Xverify:all','-cp',OUT/'driver','EntrySplitOracleDriver',classes,classes],'original-'+leg,leg)
  lines=c.command_artifact(row,'stdout').decode().splitlines();cases=[x for x in lines if x.startswith('CASE ')];inventory=[x for x in lines if x.startswith('INVENTORY ')];assert len(cases)==72 and len(inventory)==4
  for line in cases:
   vals=dict(x.split('=',1) for x in line.split()[1:]);assert int(vals['actual'])==int(vals['expected'])
  report['original_runs'].append({'command':row['label'],'case_rows':72,'inventory_rows':4,'stdout':row['streams']['stdout']})
 for leg in jdks:
  row=command([sys.executable,'-B',bound,'30',jdks[leg]['tools']['java'],'-Xverify:all','-cp',OUT/'driver','EntrySplitOracleDriver',classes,empty],'wrong-root-'+leg,leg,False)
  assert row['exit_code']!=0 and b'wrong CodeSource' in c.command_artifact(row,'stderr');report['wrong_roots'].append(row['label'])
 for p in sorted(classes.rglob('*.class')):
  row=command([cli,'class-source','--input',p,'--class','cf08/'+p.stem,'--policy','single-class','--release','8','--format','json'],'baseline-api-'+p.stem,'javac23')
  data=json.loads(c.command_artifact(row,'stdout'));assert isinstance(data.get('text'),str)
  text=OUT/(p.stem+'.baseline.java');text.write_text(data['text']);report['baseline_api'].append({'class':p.stem,'command':row['label'],'source':c.pin(text),'methods':data.get('methods')})
 report['status']='captured_pending_root_review'
except BaseException as e:
 report['status']='failed';report['error']=repr(e);raise
finally:
 report['sources_after']=c.source_closure(ROOT);report['source_unchanged']=report['sources_before']==report['sources_after'];report['external_after']=[c.pin(p) for p in external];report['external_unchanged']=report['external_before']==report['external_after'];report['target_absent']=not (ROOT/'target').exists();save()
print(json.dumps({'status':report['status'],'commands':len(report['commands']),'output':str(OUT)}))
