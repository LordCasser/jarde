import hashlib,json,re,sys
from pathlib import Path
native=Path(sys.argv[1]); old=Path(sys.argv[2]); out=Path(sys.argv[3]);assert not out.exists()
n=json.loads(native.read_bytes());assert n['status']=='passed'
rows=[]
for x in json.loads(old.read_bytes())['tests']:
 name=x['test']; hits=[]
 for i,c in enumerate(n['commands']):
  for label,pin in c.get('streams',{}).items():
   if label!='stdout':continue
   p=Path(pin['path']);b=p.read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256']
   found=re.findall(r'^test (?:[^\n]*::)?'+re.escape(name)+r' \.\.\. (ok|FAILED|ignored)(?: \S.*)?$',b.decode(),re.M)
   for status in found:hits.append((c["index"],status,pin))
 assert len(hits)==1 and hits[0][1]=='ok',(name,hits)
 rows.append({'test':name,'command':hits[0][0],'stdout':hits[0][2]})
r={'status':'root_accepted_current_cf07_cf11_finthrow_nestedfin_regressions','native_sha256':hashlib.sha256(native.read_bytes()).hexdigest(),'tests':rows,'notes':['All nine exact named regressions passed exactly once in the final fresh workspace raw output. No standalone test was rerun.']}
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'tests':len(rows)}))
