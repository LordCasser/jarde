# Entry-split CI gate reconciliation (read-only)

The parent assignment-condition-widening `79` is not a documentation error. Its accepted verifier invocation adds 13 exact `--extra-critical TARGET=FULL_TEST_NAME` identities to the verifier's built-in 66, giving 79. The entry-split verifier already includes the same built-in 66 and its 11 new exact gates, so its default is 77; to retain all parent proof gates, pass the same 13 parent extras, yielding 90 exact identities. Do not drop them to make the count read 79.

Use the repeated CLI form shown below (append each `--extra-critical` pair to the entry-split `verify_ci` argv in `acceptance-argv.json`):

```text
--extra-critical 'jarde=facade::generic_list_foreach_binding_slot_closed_tests::optional_remove_argument_break_leaves_required_list_proof_and_equals_edit'
--extra-critical 'jarde=facade::generic_list_foreach_binding_slot_closed_tests::unmatched_optional_equals_key_does_not_hide_valid_calls'
--extra-critical 'jarde_java=report::exact_cast_call_batch_tests::iterative_batch_proves_multiple_get_cast_children_and_rejects_mutations'
--extra-critical 'jarde=facade::generic_list_foreach_binding_slot_closed_tests::generic_list_indexed_get_keeps_its_exact_single_cast_use_and_ast_child'
--extra-critical 'p3_nested_loop_side_exits=indexed_list_parameter_signatures_require_exact_direct_get_cast_evidence'
--extra-critical 'p3_nested_loop_side_exits=indexed_list_parameter_primitive_result_must_match_signature_exactly'
--extra-critical 'jarde=class_source::tests::complete_body_primitive_result_requires_exact_signature_and_descriptor_type'
--extra-critical 'jarde_java=report::exact_cast_call_batch_tests::iterative_batch_propagates_budget_and_cancellation_stops'
--extra-critical 'jarde_java=report::generic_void_parameter_census_tests::invoke_receiver_census_uses_consumed_stack_depth_not_stack_zero'
--extra-critical 'p3_iterable_foreach=subtype_owners_project_and_extra_next_or_iterator_escape_refuse'
--extra-critical 'recover_lambda_primitive_array_capture=the_primitive_array_capture_recovers_in_both_javac_legs'
--extra-critical 'recover_lambda_primitive_array_capture=the_multianewarray_capture_preserves_its_members_while_the_nested_helper_recovers'
--extra-critical 'jarde_reader=classfile::tests::repository_class_fixtures_validate_without_false_target_rejections'
```

The verifier accepts `--extra-critical` repeatedly and parses each as `TARGET=FULL_TEST_NAME`; it rejects duplicate target/name identities. This is a static reconciliation of the accepted parent argv and verifier constants, not a CI rerun or assertion that a new entry-split run has passed.

## Source pins

- Parent `acceptance-argv.json`: SHA-256 `734882480a62cb2b6a017c5752a207524b76110bd023fa960df488cb401371ab`
- Parent `verify-own-ci.py`: SHA-256 `2dc933b3b2aa530eed7057509b5bebc07799908d3b4a46c84f1fdab2a99ae824`
- Entry-split `acceptance-argv.json`: SHA-256 `602debb3f14bb4b0c153dadaf5e2dc3601f39a00dad5d5becb7029cf11558fa2`
- Entry-split `verify-own-ci.py`: SHA-256 `33daacf657867e7cd1a6e4c9c021147c01fdfc895c4b8752d512fe9644bf9b39`
