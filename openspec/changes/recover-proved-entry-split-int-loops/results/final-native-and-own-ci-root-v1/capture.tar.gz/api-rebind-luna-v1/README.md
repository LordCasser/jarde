# EntrySplit final API rebind (private, unexecuted)

`replay_api.py` is a small API-only replay collector for the root-accepted final matrix. It requires a caller-supplied final CLI path and SHA-256. It refuses to run if that SHA matches the accepted matrix CLI, since no rebind would be needed. Root must pass the actual newly built CLI SHA after reviewing the script.

The collector binds the old matrix receipt, its root acceptance marker, and canonical review by SHA. It reopens the accepted matrix's API inputs, reports, whole-source files, external inputs, helper scripts, and JDK tool pins. For each of the 24 API cells it takes the accepted command argv and changes only argv[0] to the supplied CLI. It records the complete new stdout/stderr and JSON response, preserving raw artifacts.

A cell matches only when the full parsed JSON is structurally equal after recursively removing keys named `usage`, and the whole-class text bytes, method inventory, method text, per-method raw maps, and method identities also compare exactly. All other fields remain in the full JSON comparison. Any nonzero CLI exit or difference is retained and marks the receipt failed.

The collector imports the accepted validation guard and runs with the original project's `target` scanner, an empty current working directory, default stack settings, the pinned clean environment, and the guard's 1 GiB target / 5 GiB free-space limits. It requires `target` absent before, between, and after commands and requires current source, external-input and JDK pins stable across the replay. It does not rerun compiler or VM commands; it labels prior compile/VM evidence as reused only after all 24 API comparisons match.

This package is prepared but has not been executed. It contains no root replay receipt and makes no new compiler, JVM, product, or CI acceptance claim.

The supplied executable must also match the pinned root-accepted final-build receipt and marker at `/private/tmp/jarde-entry-split-clippy-final-build-root-v1-20261019/`. This binds the rebind to the exact final CLI build instead of a caller-selected binary. The script’s default CLI is not hardcoded; root passes its current path and expected SHA.
