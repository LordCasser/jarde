#!/usr/bin/env python3
"""Replay only the 24 accepted EntrySplit API argv rows against a supplied final CLI."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, shutil, sys, time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
MATRIX=Path('/private/tmp/jarde-entry-split-final-matrix-root-v1-20261019/execution.json')
MATRIX_SHA='8ff19de0f61d7ff2bb9dad4e895354584c2180c7af8d9c6318de2db343eba978'
MATRIX_MARKER=Path('/private/tmp/jarde-entry-split-final-matrix-root-v1-20261019/root-review.json')
MATRIX_MARKER_SHA='7fedf50571381a97bfc0d5a4df832da04a7c69dde4d74d3388c3917153a9fe56'
FINAL_BUILD_DIR=Path('/private/tmp/jarde-entry-split-clippy-final-build-root-v1-20261019')
FINAL_BUILD_RECEIPT=FINAL_BUILD_DIR/'execution.json'
FINAL_BUILD_RECEIPT_SHA='eb4b2aac934be300998441d5d11d3db04126faeb0831dc3f05daee47112919bd'
FINAL_BUILD_MARKER=FINAL_BUILD_DIR/'root-review.json'
FINAL_BUILD_MARKER_SHA='2721a911c61c63ae6afa57867e8b075fddeaf378f49dee36e4aaca5e4c1a8f57'
REVIEWER=Path('/private/tmp/jarde-entry-split-final-reviewer-luna-v2-20261019/review_final_matrix.py')
REVIEWER_SHA='4438e847f5ba79bd07acdde6dcd938201e89658459baadfcd67eda16a8e1fc8c'
COMPARE_REL='openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD_REL='openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL='openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
JDK_REL='openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'


def sha(path: Path) -> str:
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def filepin(path: Path) -> dict:
    p=Path(path).resolve(strict=True);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def require_pin(rec: dict, label: str) -> Path:
    p=Path(rec['path']).resolve(strict=True)
    if p.stat().st_size!=rec['bytes'] or sha(p)!=rec['sha256']:
        raise RuntimeError(f'{label} pin mismatch: {p}')
    return p
def load(path: Path, name: str):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None:raise RuntimeError(f'cannot import {path}')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def without_usage(x):
    if isinstance(x,dict):return {k:without_usage(v) for k,v in x.items() if k!='usage'}
    if isinstance(x,list):return [without_usage(v) for v in x]
    return x
def write_json(path: Path, value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def check_target_absent(root: Path):
    t=root/'target'
    if t.exists() or t.is_symlink():raise RuntimeError(f'target must remain absent: {t}')
def external_pins(receipt):
    return [require_pin(x,'matrix external input') for x in receipt['external_pins_before']]


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--cli',type=Path,required=True)
    ap.add_argument('--expected-cli-sha256',required=True)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();runtime_argv=sys.argv[1:]
    root=ROOT.resolve(strict=True);out=args.out.resolve()
    if out.exists():raise SystemExit('output directory must not exist')
    cli=args.cli.resolve(strict=True)
    if len(args.expected_cli_sha256)!=64 or sha(cli)!=args.expected_cli_sha256:
        raise SystemExit('supplied CLI does not match --expected-cli-sha256')
    if sha(FINAL_BUILD_RECEIPT)!=FINAL_BUILD_RECEIPT_SHA or sha(FINAL_BUILD_MARKER)!=FINAL_BUILD_MARKER_SHA:
        raise SystemExit('root final-build receipt/marker pin changed')
    build_marker=json.loads(FINAL_BUILD_MARKER.read_text(encoding='utf-8'))
    if build_marker.get('status')!='root_accepted_exact_workflow_clippy_fmt_final_cli_and_one_line_equivalence':
        raise SystemExit('final CLI lacks root acceptance marker')
    if build_marker.get('receipt_sha256')!=FINAL_BUILD_RECEIPT_SHA or build_marker.get('cli',{}).get('sha256')!=args.expected_cli_sha256:
        raise SystemExit('root final-build marker does not bind supplied CLI')
    if Path(build_marker['cli']['path']).resolve(strict=True)!=cli or build_marker['cli']['bytes']!=cli.stat().st_size:
        raise SystemExit('supplied CLI path/size differs from root final-build marker')
    build_receipt=json.loads(FINAL_BUILD_RECEIPT.read_text(encoding='utf-8'))
    if build_receipt.get('status')!='commands_passed_pending_independent_acceptance' or build_receipt.get('cli',{}).get('sha256')!=args.expected_cli_sha256:
        raise SystemExit('final-build receipt does not bind supplied CLI')
    if build_receipt.get('source_unchanged') is not True or build_receipt.get('source_changes_accepted') is not True or build_receipt.get('source_changes')!=[] or build_receipt.get('allowed_source_changes')!=[] or build_receipt.get('target_absent') is not True:
        raise SystemExit('final-build source/target guard failed')
    if root!=Path(json.loads(MATRIX.read_text())['root']).resolve(strict=True):
        raise SystemExit('workspace root differs from accepted matrix')
    if sha(MATRIX)!=MATRIX_SHA:raise SystemExit('accepted matrix receipt SHA changed')
    if sha(MATRIX_MARKER)!=MATRIX_MARKER_SHA:raise SystemExit('accepted matrix root marker SHA changed')
    marker=json.loads(MATRIX_MARKER.read_text(encoding='utf-8'))
    if marker.get('status')!='root_accepted_complete_final_matrix_and_physical_sources':
        raise SystemExit('matrix has no matching root acceptance marker')
    if marker.get('receipt',{}).get('sha256')!=MATRIX_SHA or marker.get('receipt',{}).get('bytes')!=MATRIX.stat().st_size or Path(marker['receipt']['path']).resolve()!=MATRIX.resolve():
        raise SystemExit('root acceptance marker does not bind the matrix receipt')
    review_rec=marker['review'];review_path=require_pin(review_rec,'canonical root review')
    reviewer_rec=require_pin(marker['reviewer'],'accepted reviewer')
    if marker.get('reviewer',{}).get('sha256')!=REVIEWER_SHA or sha(REVIEWER)!=REVIEWER_SHA or reviewer_rec!=REVIEWER.resolve():
        raise SystemExit('accepted reviewer source pin differs')
    compare_path=root/COMPARE_REL;guard_path=root/GUARD_REL;scanner_path=root/SCANNER_REL;jdk_path=root/JDK_REL
    for p,h in ((compare_path,COMPARE_SHA),(guard_path,GUARD_SHA),(scanner_path,SCANNER_SHA),(jdk_path,JDK_SHA)):
        if sha(p)!=h:raise SystemExit(f'helper/tool manifest pin changed: {p}')
    receipt=json.loads(MATRIX.read_text(encoding='utf-8'))
    review=json.loads(review_path.read_text(encoding='utf-8'))
    if receipt['source_pins_before']!=receipt['source_pins_after'] or receipt['source_pins_after']!=receipt['source_pins_after_finally']:
        raise SystemExit('accepted matrix source snapshots do not match internally')
    if receipt['external_pins_before']!=receipt['external_pins_after'] or receipt['external_pins_after']!=receipt['external_pins_after_finally']:
        raise SystemExit('accepted matrix external snapshots do not match internally')
    if receipt['jdk_tool_pins_before']!=receipt['jdk_tool_pins_after']:
        raise SystemExit('accepted matrix JDK tool pins changed during collection')
    if receipt.get('target_absent') is not True or receipt.get('target_absent_finally') is not True:
        raise SystemExit('accepted matrix did not finish with target absent')
    if review.get('status')!='root_accepted_complete_final_matrix_and_physical_sources' or review.get('receipt',{}).get('sha256')!=MATRIX_SHA:
        raise SystemExit('canonical root review does not accept this receipt')
    if receipt.get('status')!='captured-pending-independent-review':
        raise SystemExit('unexpected matrix receipt status')
    cli_old=require_pin(receipt['final_cli'],'previous CLI')
    if args.expected_cli_sha256==receipt['final_cli']['sha256']:
        raise SystemExit('CLI hash matches accepted matrix; API replay is unnecessary')
    if cli_old==cli:raise SystemExit('CLI path is unchanged despite different hash')
    check_target_absent(root)
    compare=load(compare_path,'entrysplit_replay_compare');guard=load(guard_path,'entrysplit_replay_guard');scanner=load(scanner_path,'entrysplit_replay_scanner')
    if receipt.get('compare',{}).get('sha256')!=COMPARE_SHA or receipt.get('guard',{}).get('sha256')!=GUARD_SHA or receipt.get('scanner',{}).get('sha256')!=SCANNER_SHA or receipt.get('jdk_manifest',{}).get('sha256')!=JDK_SHA:
        raise SystemExit('accepted matrix tool pins differ from the rebind contract')
    jdks,jdk_record=compare.configured_jdks(jdk_path,JDK_SHA)
    source_before=compare.source_closure(root)
    if shutil.disk_usage(root).free<5*1024**3:raise SystemExit('5 GiB free-space guard failed before replay')
    # Reopen all pinned inputs from the accepted matrix, including raw streams and old whole-source files.
    old_ext=external_pins(receipt)
    for old_cmd in receipt['commands']:
        if old_cmd.get('guard_stop') is not None or old_cmd.get('peak_target_bytes',0)>1024**3 or old_cmd.get('free_bytes_after',0)<5*1024**3:
            raise SystemExit('accepted matrix command violated a preserved resource guard')
    for cell in receipt['jarde_api_cells']:
        require_pin(cell['input'],'accepted API input')
        require_pin(cell['report'],'accepted API raw report')
        require_pin(cell['whole_source'],'accepted whole source')
    by_command={r['index']:r for r in receipt['commands']}
    if len(by_command)!=148 or len(receipt['jarde_api_cells'])!=24:
        raise SystemExit('accepted matrix command/API shape changed')
    expected_cells={(k,f,e) for k in receipt['target_specs'] for f in ('child','bundle-child') for e in ('default','all')}
    actual_cells=[(c['class_key'],c['form'],c['evidence']) for c in receipt['jarde_api_cells']]
    if len(set(actual_cells))!=24 or set(actual_cells)!=expected_cells:
        raise SystemExit('accepted matrix API selector grid is not exactly the six-target 24-cell product')
    if len({c['command'] for c in receipt['jarde_api_cells']})!=24:
        raise SystemExit('accepted API command indexes are duplicated')
    out.mkdir(parents=True);rawdir=out/'raw';rawdir.mkdir();empty=out/'empty-cp';empty.mkdir()
    guard.OUT=rawdir;guard.ROOT=empty;guard.command_stream=compare.pin
    guard.target_bytes=lambda:scanner.target_bytes(root)
    guard.expected_test_summaries=lambda i,b:None
    new_cli_pin=compare.pin(cli)
    external=[cli,Path(__file__).resolve(),FINAL_BUILD_RECEIPT,FINAL_BUILD_MARKER,compare_path,guard_path,scanner_path,jdk_path,REVIEWER,MATRIX,MATRIX_MARKER,review_path,
              *old_ext,*[Path(x['path']) for leg in jdks.values() for x in leg['tools'].values()]]
    external_before=[compare.pin(p) for p in external]
    source_before=compare.source_closure(root)
    run_rows=[];cells=[];mismatches=[]
    report={'schema':'cf08-entry-split-final-api-rebind-v1','status':'running','root':str(root),'output':str(out),
      'runtime_argv':runtime_argv,'matrix':filepin(MATRIX),'matrix_marker':filepin(MATRIX_MARKER),'canonical_review':filepin(review_path),
      'final_build_receipt':filepin(FINAL_BUILD_RECEIPT),'final_build_root_marker':filepin(FINAL_BUILD_MARKER),
      'reviewer':filepin(REVIEWER),'collector':filepin(Path(__file__).resolve()),'previous_cli':receipt['final_cli'],'new_cli':new_cli_pin,'expected_cli_sha256':args.expected_cli_sha256,
      'compare':filepin(compare_path),'guard':filepin(guard_path),'scanner':filepin(scanner_path),'jdk_manifest':jdk_record,
      'source_pins_before':source_before,'external_pins_before':external_before,'jdk_tool_pins_before':{f'{leg}.{name}':compare.pin(p) for leg,spec in jdks.items() for name,p in spec['tools'].items()},
      'target_absent_before':True,'commands':run_rows,'cells':cells,'mismatches':mismatches,
      'reuse_statement':'No compiler or VM was rerun. Reuse of the accepted full matrix is permitted only when every API cell matches after recursive removal of usage keys.'}
    compare.write_json(out/'execution.json',report)
    try:
        for old_cell in receipt['jarde_api_cells']:
            old_row=by_command[old_cell['command']]
            expected_label=f"jarde-{old_cell['internal']}-{old_cell['form']}-{old_cell['evidence']}"
            if old_row['label']!=expected_label or old_cell['exit_code']!=0 or old_row['exit_code']!=0:raise RuntimeError('old API command label/exit does not match accepted cell')
            old_argv=old_row['argv']
            if old_argv[0]!=str(cli_old):raise RuntimeError('old API command did not use accepted prior CLI path')
            expected_tail=['class-source','--input',old_cell['input']['path'],'--class',old_cell['internal'],'--policy',old_cell['policy'],'--release','8','--format','json']+(['--evidence','all'] if old_cell['evidence']=='all' else [])
            if old_argv[1:]!=expected_tail:raise RuntimeError('accepted original API argv does not match its selector/input cell')
            if old_row['cwd']!=str(Path(receipt['output'])/'empty-cp') or any(str(x).startswith('-Xss') for x in old_argv):
                raise RuntimeError('accepted original API command cwd/default-stack contract changed')
            # Only argv[0] changes; inputs, selectors, release and JSON mode are byte-for-byte reused.
            new_argv=[str(cli),*old_argv[1:]]
            if new_argv[1:]!=old_argv[1:]:raise RuntimeError('API replay changed a non-CLI argv field')
            check_target_absent(root)
            env=compare.clean_env(dict(os.environ),jdks['javac23']);env.update(guard.ENV_VALUES);env.pop('RUST_MIN_STACK',None)
            if any(str(token).startswith('-Xss') for token in new_argv):raise RuntimeError('API replay must retain default stack settings')
            command=guard.run_command(len(run_rows)+1,new_argv,env)
            command['label']='api-rebind-'+old_cell['class_key'].replace('/','_')+'-'+old_cell['form']+'-'+old_cell['evidence']
            command['tool_leg']='javac23';command['previous_argv']=old_argv;run_rows.append(command)
            if command['argv'][0]!=str(cli) or command['argv'][1:]!=old_argv[1:]:
                mismatches.append({'cell':old_cell['class_key']+'/'+old_cell['form']+'/'+old_cell['evidence'],'reason':'actual argv differs beyond executable path'})
            if command.get('guard_stop') is not None or command.get('exit_code') is None:
                mismatches.append({'cell':old_cell['class_key']+'/'+old_cell['form']+'/'+old_cell['evidence'],'reason':'guard stop/no exit code','guard_stop':command.get('guard_stop'),'exit_code':command.get('exit_code')})
                compare.write_json(out/'execution.json',report);continue
            new_raw=Path(command['streams']['stdout']['path']).read_bytes()
            row={'class_key':old_cell['class_key'],'internal':old_cell['internal'],'form':old_cell['form'],'evidence':old_cell['evidence'],
                 'old_command':old_cell['command'],'command':command['index'],'old_cli_argv':old_argv,'new_cli_argv':new_argv,
                 'input':old_cell['input'],'exit_code':command['exit_code'],'old_report':old_cell['report']}
            try:
                new_api=json.loads(new_raw.decode('utf-8','strict'))
                new_report=out/'reports'/old_cell['class_key'].replace('/','_')/old_cell['form']/old_cell['evidence']/'report.json'
                new_report.parent.mkdir(parents=True,exist_ok=True);new_report.write_bytes(new_raw)
                row['new_report']=compare.pin(new_report);row['api']=new_api
                old_api=json.loads(Path(old_cell['report']['path']).read_text(encoding='utf-8'))
                if old_api!=old_cell['api']:raise ValueError('accepted stored API differs from its pinned raw report')
                old_clean=without_usage(old_api);new_clean=without_usage(new_api)
                row['json_without_usage_equal']=old_clean==new_clean
                row['whole_class_text_equal']=old_api.get('text')==new_api.get('text')
                row['class_identity_equal']=old_api.get('class')==new_api.get('class')
                old_methods={ (bytes(m['item']['identity']['name']),bytes(m['item']['identity']['descriptor'])):m for m in old_api.get('methods',[])}
                new_methods={ (bytes(m['item']['identity']['name']),bytes(m['item']['identity']['descriptor'])):m for m in new_api.get('methods',[])}
                row['method_inventory_equal']=set(old_methods)==set(new_methods)
                row['method_texts_equal']=row['method_inventory_equal'] and all(old_methods[k].get('text')==new_methods[k].get('text') for k in old_methods)
                row['method_maps_equal']=row['method_inventory_equal'] and all(old_methods[k].get('outcome',{}).get('report',{}).get('source_map')==new_methods[k].get('outcome',{}).get('report',{}).get('source_map') for k in old_methods)
                row['method_identities_equal']=row['method_inventory_equal'] and all(old_methods[k]['item']['identity']==new_methods[k]['item']['identity'] for k in old_methods)
                old_source=require_pin(old_cell['whole_source'],'old whole source').read_bytes()
                row['whole_source_bytes_equal']=new_api.get('text','').encode('utf-8')==old_source
                row['new_whole_source_bytes_sha256']=hashlib.sha256(new_api.get('text','').encode('utf-8')).hexdigest()
                row['old_whole_source_bytes_sha256']=old_cell['whole_source']['sha256']
                checks=('json_without_usage_equal','whole_class_text_equal','class_identity_equal','method_inventory_equal','method_texts_equal','method_maps_equal','method_identities_equal','whole_source_bytes_equal')
                failed=[x for x in checks if not row[x]]
                if command['exit_code']!=0:failed.append('cli_exit_code_zero')
                if failed:mismatches.append({'cell':old_cell['class_key']+'/'+old_cell['form']+'/'+old_cell['evidence'],'failed_checks':failed})
                row['failed_checks']=failed;cells.append(row)
            except Exception as e:
                row['parse_or_compare_error']=repr(e);cells.append(row)
                mismatches.append({'cell':old_cell['class_key']+'/'+old_cell['form']+'/'+old_cell['evidence'],'reason':repr(e)})
            compare.write_json(out/'execution.json',report)
        report['source_pins_after']=compare.source_closure(root)
        report['external_pins_after']=[compare.pin(p) for p in external]
        report['jdk_tool_pins_after']={f'{leg}.{name}':compare.pin(p) for leg,spec in jdks.items() for name,p in spec['tools'].items()}
        report['target_absent_after']=not (root/'target').exists() and not (root/'target').is_symlink()
        report['command_streams_unchanged']=all(compare.pin(Path(x['streams'][k]['path']))==x['streams'][k] for x in run_rows for k in ('stdout','stderr'))
        report['report_artifacts_unchanged']=all(require_pin(c['new_report'],'new raw API report').read_bytes()==Path(run_rows[c['command']-1]['streams']['stdout']['path']).read_bytes() for c in cells if 'new_report' in c)
        report['all_24_cells_compared']=len(cells)==24
        report['all_argv_changed_only_cli']=len(run_rows)==24 and all(x['argv'][0]==str(cli) and x['argv'][1:]==x['previous_argv'][1:] for x in run_rows)
        stable=(report['source_pins_after']==source_before and report['external_pins_after']==external_before and
                report['jdk_tool_pins_after']==report['jdk_tool_pins_before'] and report['target_absent_after'] and
                report['command_streams_unchanged'] and report['report_artifacts_unchanged'] and report['all_24_cells_compared'] and report['all_argv_changed_only_cli'] and
                len(run_rows)==24 and all(x['guard_stop'] is None and x['exit_code']==0 for x in run_rows))
        report['source_and_guard_stable']=stable
        report['status']='captured-pending-independent-review' if stable and not mismatches else 'failed'
    except BaseException as e:
        report['status']='failed';report['fatal_error']=repr(e)
    finally:
        try:
            report['source_pins_after_finally']=compare.source_closure(root)
            report['external_pins_after_finally']=[compare.pin(p) for p in external]
            report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
            report['target_bytes_finally']=scanner.target_bytes(root)
            report['guard_finally_stable']=(report['source_pins_after_finally']==report.get('source_pins_before') and
                report['external_pins_after_finally']==report.get('external_pins_before') and report['target_absent_finally'] and
                report['target_bytes_finally']==0)
            if not report['guard_finally_stable']:report['status']='failed'
        except BaseException as e:
            report['status']='failed';report['finally_error']=repr(e)
        compare.write_json(out/'execution.json',report)
    print(json.dumps({'status':report['status'],'api_cells':len(cells),'commands':len(run_rows),'mismatches':mismatches,'new_cli':new_cli_pin},ensure_ascii=False,indent=2))
    if report['status']=='failed':raise SystemExit(1)

if __name__=='__main__':main()
