# Private main-spec merge proposal

The proposed change is in `spec.patch`; `spec.after.md` is the full candidate for review. No OpenSpec command or shared-file edit was performed.

- Existing main spec SHA256: `ca3f5f39094e895129cd38abb5342548e904f278f7b21066adec56cd1857611f`
- Candidate SHA256: `4b66361070257c84ebb267662528e84e6f4f20bf2f5b1a818743290b57fd112f`
- Source delta SHA256: `5b13abd48fd4a326283161fc9c87ac35f51c526096738af7662a74a9c52d2e43`

Only the existing Semantics-preserving fallback paragraph, the WHEN of its Unstructured control-flow scenario, and the delta's one added requirement with six scenarios are changed/added. The Purpose, all other existing text, and both existing scenarios' THEN clauses (including TWR) are preserved verbatim. The added requirement is appended beneath the existing Requirements section without carrying the delta operation heading.
