# Clippy manual_contains fix (private, unexecuted)

The CI log reports `clippy::manual_contains` at `crates/jarde-java/src/region.rs:2523` and explicitly suggests `cycle.contains(&entry)`. The one-line patch applies that suggestion to the fixed three-element `[CanonicalBlockId; 3]` array. `contains` performs the same equality membership check and returns the same boolean as `iter().any(|id| *id == entry)`; the early-return behavior is unchanged.

Pins include the exact source before/after SHA-256 and the failed CI step log. This is a private patch only: shared source was not modified and no toolchain was run.
