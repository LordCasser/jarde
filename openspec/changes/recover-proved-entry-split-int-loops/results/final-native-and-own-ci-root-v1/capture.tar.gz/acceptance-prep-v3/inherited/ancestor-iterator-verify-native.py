#!/usr/bin/env python3
"""Independent two-receipt acceptance wrapper for typed foreach, bulk recovery lifecycle, local-binding fold, and ancestor iterator cleanup gates."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, sys
from pathlib import Path
sys.dont_write_bytecode = True
BASE = Path('/private/tmp/jarde-foreach-local-bindings-own-ci-prep-luna-v3-20261018/verify_workspace.py')
BASE_SHA = '87b8f2151aa1c47eaf0233835430480945c8d8c2a9be7a7b0c089d9cbfcdbb39'
RUNNER = {'path':'/Users/lordcasser/workspace/projects/jarde/openspec/changes/recover-branch-throw-return-finally/tools/workspace_runner.py','sha256':'416d9597704be082f3e1891999713fac6b0ce7e51c46c57bf47072e2c8aae953','derived_from':'/Users/lordcasser/workspace/projects/jarde/openspec/changes/bound-arithmetic-render-stack-frames/results/full-workspace-runner-root-v1.py','derived_from_sha256':'2ac64ccdf7ed6c8f90f37b8ae34693eb16206cba493ca4a3e261de993a08235b'}
BASELINE_TARGETS = 385
GATES = [
    ('jarde_java', 'report::generic_call_ast_projection_tests::typed_foreach_projection_unwraps_only_the_binding_and_preserves_origins'),
    ('jarde_java', 'report::generic_call_ast_projection_tests::typed_foreach_refuses_mismatched_or_foreign_site_plans_without_mutation'),
    ('jarde_java', 'report::generic_call_ast_projection_tests::typed_foreach_traversal_reaches_try_and_switch_bodies_and_stops_atomically'),
    ('structured_list_generic_bodies', 'typed_list_foreach_element_heads_preserve_bindings_and_raw_origins'),
    ('structured_list_generic_bodies', 'typed_foreach_late_deadline_keeps_raw_artifact_without_partial_projection'),
    ('bulk_recovery_lifecycle', 'at_most_the_window_of_class_tasks_runs_at_once_and_two_of_them_overlap'),
    ('bulk_recovery_lifecycle', 'a_worker_that_panics_fails_the_operation_and_leaves_no_thread_behind'),
    ('bulk_recovery_lifecycle', 'a_worker_the_system_refuses_to_create_fails_the_operation_before_dispatching'),
    ('bulk_recovery_lifecycle', 'a_run_without_faults_still_reports_its_own_lifecycle'),
    ('jarde_java', 'report::generic_call_ast_projection_tests::typed_foreach_binding_fold_handles_inner_and_visible_outer_bindings'),
    ('jarde_java', 'report::generic_call_ast_projection_tests::typed_foreach_binding_fold_promotes_direct_first_declaration'),
    ('jarde_java', 'report::generic_call_ast_projection_tests::typed_foreach_optional_fold_refuses_shadow_writes_captures_and_fallbacks'),
    ('jarde_java', 'report::generic_call_ast_projection_tests::stale_optional_foreach_binding_plan_falls_back_to_typed_copy'),
    ('jarde', 'facade::generic_list_foreach_binding_slot_closed_tests::generic_list_foreach_binding_closes_actual_ssa_and_refuses_mutated_facts'),
    ('structured_list_generic_bodies', 'original_nested_loops_folds_both_proven_local_bindings_without_changing_raw_sources'),
    ('structured_list_generic_bodies', 'nested_foreach_late_cancel_budget_and_deadline_keep_raw_source_atomically'),
    ('jarde_java', 'build::tests::ancestor_iterator_cleanup_closes_the_complete_physical_local_variable'),
    ('jarde_java', 'build::tests::ancestor_iterator_cleanup_requires_unique_direct_visible_iterator_row'),
]
EXPECTED_GATE_COUNT = 18
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('seed1',type=Path); ap.add_argument('seed2',type=Path)
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args()
    if a.output.exists(): raise FileExistsError(f'refusing to overwrite {a.output}')
    if hashlib.sha256(BASE.read_bytes()).hexdigest()!=BASE_SHA: raise RuntimeError('existing independent checker changed since preparation')
    spec=importlib.util.spec_from_file_location('native_workspace_checker',BASE)
    checker=importlib.util.module_from_spec(spec); spec.loader.exec_module(checker)
    checker.need(len(GATES)==EXPECTED_GATE_COUNT,'native critical gate inventory differs from eighteen exact identities')
    checker.GATES=GATES
    p1=a.seed1/'execution.json' if a.seed1.is_dir() else a.seed1
    p2=a.seed2/'execution.json' if a.seed2.is_dir() else a.seed2
    for p in (p1,p2):
        receipt=json.loads(p.read_text(encoding='utf-8'))
        checker.need(receipt.get('runner')==RUNNER,'receipt does not use the pinned existing workspace_runner')
    x,y=checker.validate_one(p1),checker.validate_one(p2)
    checker.need(x['seed']!=y['seed'],'seed receipts are not distinct')
    checker.need(x['source_pins_sha256']==y['source_pins_sha256'],'source pins differ across fresh receipts')
    checker.need(x['inventory_sha256']==y['inventory_sha256'] and x['target_count']==y['target_count'],'metadata-derived target inventories differ')
    checker.need(x['target_count']==BASELINE_TARGETS,'dynamic target count differs from 385-target prior native baseline')
    cx={tuple(r['target']):tuple(r['counts']) for r in x['target_counts']}
    cy={tuple(r['target']):tuple(r['counts']) for r in y['target_counts']}
    checker.need(cx==cy,'actual-Running-bound per-target counts differ across receipts')
    checker.need(x['critical_gate_count']==y['critical_gate_count']==len(GATES),'critical gate count differs')
    result={'schema':'ancestor-iterator-cleanup-native-workspace-acceptance-pending-v1','status':'passed',
      'baseline_target_count':BASELINE_TARGETS,'dynamic_target_count':len(cx),'dynamic_target_delta':len(cx)-BASELINE_TARGETS,
      'target_inventory_equal':True,'source_pins_equal':True,'running_bound_per_target_counts_equal':True,
      'critical_gates_per_receipt':len(GATES),'expected_critical_gate_count':EXPECTED_GATE_COUNT,'critical_gates_each_occur_once_and_pass':True,
      'seed1':x,'seed2':y,
      'count_authority':'Cargo metadata-derived target identities; each harness summary is bound to stderr Running order via compiler-artifact executable identity. Collector legacy table ordering is checked and differences remain reported separately.'}
    dest=a.output.resolve(); dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'passed','targets':len(cx),'gates_per_receipt':len(GATES),'output':str(dest)},ensure_ascii=False))
    return 0
if __name__=='__main__': raise SystemExit(main())
