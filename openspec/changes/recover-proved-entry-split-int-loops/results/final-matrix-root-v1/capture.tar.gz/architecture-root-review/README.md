# Root 架构验收补充（全工作区/自身CI尚在运行）

实际逐段复审 region.rs 的五角色/六正常边、9/10指令闭包、所有前驱和分支极性、真实SSA读写/定义/用途及按Frame logical input排序的phi。未放宽正常图分类，未改CanonicalBlockId.path；其它不可约图保留原拒绝。新证书仅在不可约分支进入，成功后仍跑既有ownership/uncovered/unaccounted门。

Builder要求源码返回Int、三不同local绑定、prefix/count严格Int及跨实际使用点同一binding，test为Boolean或Int。P只有iinc及可选transfer，H/L计数只有iinc，X实际load/ireturn。相同受证assignment复制到初始if与while尾，不重算初值；复用原test_expr、instruction、AST、checkpoint和名字决定，没有新CFG/pass/solver/public协议。复用已有大事务而未建立第三套状态；窄候选先拒绝非空深层状态，Stop恢复后原样上送、预算不退款。两个展示AST和名字存储分别计费，来源同物理BCI，owner仍唯一。

永久六class覆盖6正方法（signed/slots/entry polarity/counter up）和10负方法；9整体quote、legacy保留既有mixed块。库测试证明每个物理BCI和方法身份以及两个不重叠prefix语句span；真实proof阶段预算/取消、两次emitter停止、可选SourceMap完整节点prefix停止已实际接受。低output cap先耗尽class读取的真实测试失败保留，修的是测试搜索下界，不是扩展恢复机制。

完整矩阵148实际命令，24API、48Jarde整类编译，其中16成功/32VM1728case同原；32负类编译失败没有调用其方法。原始216观察复用独立接受gate，不能称本轮重新跑原始。JADX六输入中两次decompile exit3；四完整树合计八编译，四成功（SlotCounter两编译/4VM144case，legacy两编译/4VM仅构造库存）、四编译失败。EntrySplitCases.inverted输出未初始化i3并把值更新移出循环，是静态可见的问题；不修JADX文本或裁剪前三方法冒称完整源码可用，不声称失败源码有运行语义差异。

CF07、CF11、finThrow、nestedFin的旧源码、来源和stop具名门由当前fresh workspace验收，不重用旧CI作本产品通过。只有全部实际验收、产品自身官方CI与来源绑定完成后才同步主规范/勾最终交付。CF08/71/612仍partial，原Smali/DEX和Raung输入单列。
