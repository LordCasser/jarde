#!/usr/bin/env python3
"""Independent read-only review of the CF08 entry-split final matrix receipt."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, sys, zipfile
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
COLLECTOR=Path('/private/tmp/jarde-entry-split-final-collector-luna-v2-20261019/collect_final_matrix.py')
COLLECTOR_SHA='c11295bb283dfc65c20f0272dfb3c73ea27a8b12336d16cb77004b20456c3146'
COMPARE_REL='openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
PHYSICAL=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PHYSICAL_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
GATES=[
 (Path('/private/tmp/jarde-entry-split-fixture-gate-root-v1-20261019/execution.json'),'f6ebb66119875977e181d7e1d0aac126114024c9cae46d804bc310d47bc3bd2c','/private/tmp/jarde-entry-split-fixture-gate-root-v1-20261019/root-review.json','/private/tmp/jarde-entry-split-fixture-gate-review-root-v1-20261019/review.json','root_accepted_verifier_valid_fixtures_and_old_cli_baseline'),
 (Path('/private/tmp/jarde-entry-split-generalized-gate-root-v1-20261019/execution.json'),'284a270cfa0a40c51fa5d5e1aef427daa3f798e6843bfb1ac910934da6c3cb2d','/private/tmp/jarde-entry-split-generalized-gate-root-v1-20261019/root-review.json','/private/tmp/jarde-entry-split-generalized-review-root-v1-20261019/review.json','root_accepted_generalized_original_gate_and_candidate_api')]
CLI_SHA='eb11645e741d944a349080fbd12f18e2e5c70bdc5809f4bdb51a6e3cdec6fb50'
CLI_BYTES=63955664
TOOL_SHA={
 'guard':'51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33',
 'scanner':'d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7',
 'jadx':'64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7',
 'jadx_jar':'966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65',
 'runtime_wrapper':'73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca',
 'driver_source':'926f26e75c0ffadec244b81b705ba1855a51680f94f48a5a0f3a78151ae87f2d',
 'slot_driver_source':'38073411b841ccfdd6e6cd6c92bbc863ad87c59e822aaec09b63e568a7c3fa51'}
SOURCE_TEST_SNAPSHOT=Path('/private/tmp/jarde-entry-split-final-matrix-root-v1-20261019/source-test-before-budget-fix.rs')
SOURCE_TEST_SHA='0a06b66f03a433f579d49d23013ee215d1c555f1ef7f3d51fbdcfa3cc37d487c'
ROLES={
 'cf08/EntrySplitCases.class':'positive',
 'cf08/EntrySplitExceptionRefusal.class':'exception',
 'cf08/EntrySplitLegacyCases.class':'legacy',
 'cf08/EntrySplitRefusals.class':'refusal',
 'cf08/EntrySplitTopologyRefusals.class':'topology',
 'cf08/EntrySplitSlotCounterCases.class':'slot-counter'}


def need(ok,msg):
 if not ok: raise ValueError(msg)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
def load(path,name):
 s=importlib.util.spec_from_file_location(name,path)
 if s is None or s.loader is None: raise RuntimeError('cannot load '+str(path))
 m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def norm(x):
 if isinstance(x,dict): return {k:norm(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)): return [norm(v) for v in x]
 if isinstance(x,bytes): return list(x)
 return x
def pin(rec,label):
 need(isinstance(rec,dict) and {'path','bytes','sha256'}<=rec.keys(),label+': malformed pin')
 p=Path(rec['path']).resolve(strict=True);data=p.read_bytes()
 need(len(data)==rec['bytes'] and hashlib.sha256(data).hexdigest()==rec['sha256'],label+': pin mismatch '+str(p))
 return p
def filepin(p):
 p=Path(p).resolve(strict=True);d=p.read_bytes();return {'path':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
def verify_filetree(root,expected,label):
 root=Path(root).resolve(strict=True)
 actual={p.relative_to(root).as_posix():filepin(p) for p in sorted(root.rglob('*')) if p.is_file()}
 need(actual==expected,label+': tree differs');return actual
def command_rows(doc,compare):
 rows=doc.get('commands',[]);by={r.get('index'):r for r in rows}
 need(len(by)==len(rows) and set(by)==set(range(1,len(rows)+1)),'command indexes duplicate/missing')
 for r in rows:
  need(r.get('guard_stop') is None,'guard stop: '+str(r.get('label')))
  for ch in ('stdout','stderr'):
   art=compare.command_artifact(r,ch)
   rec=r.get('streams',{}).get(ch)
   need(rec is not None and filepin(rec['path'])==rec,'raw stream pin mismatch')
  need(r.get('exit_code') is not None,'command lacks actual exit code')
  need(r.get('cwd')==str(Path(doc['output'])/'empty-cp'),'command cwd is not isolated empty cp')
  need(r.get('peak_target_bytes',0)<=1024**3 and r.get('free_bytes_after',0)>=5*1024**3,'target/disk guard limits differ')
  need(not any(str(t).startswith('-Xss') for t in r.get('argv',[])),'non-default stack configured')
 return by
def verify_nested_pins(obj,label='receipt'):
 count=0
 def visit(x):
  nonlocal count
  if isinstance(x,dict):
   if {'path','bytes','sha256'}<=x.keys():
    # The task test changed after matrix capture; root supplied an exact inverse-change snapshot.
    if x['path']=='/Users/lordcasser/workspace/projects/jarde/tests/p3_entry_split_int_loops.rs':
     actual=Path(x['path']).resolve(strict=True).read_bytes()
     if hashlib.sha256(actual).hexdigest()!=x['sha256']:
      q=SOURCE_TEST_SNAPSHOT.resolve(strict=True);snap=filepin(q)
      need(snap['sha256']==SOURCE_TEST_SHA and snap['sha256']==x['sha256'] and snap['bytes']==x['bytes'],'historical p3 source snapshot does not match recorded source pin')
     else: pin(x,label)
    else: pin(x,label)
    count+=1
   else:
    for y in x.values():visit(y)
  elif isinstance(x,list):
   for y in x:visit(y)
 visit(obj)
 return count
def code_bcis(method):
 c=method.get('code')
 if c is None:return set()
 return set(c.get('bcis',[]))
def methodkey(m):return (m['name'],m['descriptor'],m['access'])
def method_identity(item):
 x=item['identity'];return (bytes(x['name']).decode(),bytes(x['descriptor']).decode(),x['owner'])
def check_facts(path,spec,compare,physical,major=None):
 raw=Path(path).read_bytes();a=compare.parse_class(Path(path));b=physical.parse_class_file(raw)
 need(norm(a['methods'])==norm(b['methods']),'independent method facts disagree: '+str(path))
 need(sorted(tuple(x) for x in a['fields'])==sorted((f['name'],f['descriptor'],f['access']) for f in b['fields']),'independent field inventory/access facts disagree: '+str(path))
 need(a['class_name']==spec['internal'] and b['class_name']==spec['internal'],'class internal name mismatch: '+str(path))
 expected_major=spec['facts']['major'] if major is None else major
 need(a['major']==expected_major and b['major']==expected_major,'class major mismatch: '+str(path))
 want_m=sorted((m['name'],m['descriptor'],m['access']) for m in spec['facts']['methods'])
 got_m=sorted(methodkey(m) for m in b['methods'])
 want_f=sorted((x['name'],x['descriptor'],x['access']) for x in spec['facts']['fields'])
 got_f=sorted((x['name'],x['descriptor'],x['access']) for x in b['fields'])
 need(got_m==want_m and got_f==want_f,'complete method/field access inventory mismatch: '+str(path))
 need(all(m.get('code') is not None for m in b['methods']),'physical Code missing from a target method: '+str(path))
 return a,b

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execution',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
 a=ap.parse_args();exe=a.execution.resolve(strict=True);out=a.out.resolve()
 need(not out.exists(),'review output path must be new')
 doc=json.loads(exe.read_text(encoding='utf-8'))
 need(doc.get('schema')=='cf08-entry-split-final-full-source-matrix-v1','wrong receipt schema')
 pins=[COLLECTOR_SHA,COMPARE_SHA,PHYSICAL_SHA,CLI_SHA,SOURCE_TEST_SHA,*[h for _,h,_,_,_ in GATES],*TOOL_SHA.values()]
 need(all(len(x)==64 and all(c in '0123456789abcdef' for c in x) for x in pins),'a frozen SHA-256 pin is malformed')
 need(doc.get('status')=='captured-pending-independent-review','receipt is not terminal/pending-review; status='+str(doc.get('status')))
 reopened_pin_records=verify_nested_pins(doc,'final matrix')
 need(filepin(SOURCE_TEST_SNAPSHOT)['sha256']==SOURCE_TEST_SHA,'post-capture test source snapshot pin mismatch')
 root=Path(doc['root']).resolve(strict=True);need(root==ROOT.resolve(),'workspace root mismatch')
 # Historical cleanup is checked from the receipt; another authorized build may currently use target.
 need(filepin(COLLECTOR)['sha256']==COLLECTOR_SHA and filepin(PHYSICAL)['sha256']==PHYSICAL_SHA,'reviewer tool pin mismatch')
 compare_path=root/COMPARE_REL;need(filepin(compare_path)['sha256']==COMPARE_SHA,'compare helper pin mismatch')
 compare=load(compare_path,'entrysplit_review_compare');physical=load(PHYSICAL,'entrysplit_review_physical')
 gate_docs=[];specs={}
 for gpath,gsha,markerpath,reviewpath,status in GATES:
  need(sha(gpath)==gsha,'accepted gate receipt SHA changed')
  gd=json.loads(gpath.read_text(encoding='utf-8'));mk=json.loads(Path(markerpath).read_text());rv=json.loads(Path(reviewpath).read_text())
  need(gd.get('status')=='captured_pending_root_review','gate receipt status changed')
  need(mk.get('status')==status and mk.get('receipt_sha256')==gsha,'root gate marker mismatch')
  need(rv.get('status')==status and rv.get('receipt_sha256')==gsha,'canonical gate review mismatch')
  need(mk.get('review')==str(Path(reviewpath).resolve()),'gate review binding mismatch')
  verify_nested_pins(gd,'accepted gate '+str(gpath))
  gate_docs.append((gpath,gd))
  for key,row in gd['classes'].items():
   need(key not in specs,'duplicate original class key')
   typ=ROLES[key]
   specs[key]={'class_key':key,'internal':key[:-6],'kind':('positive' if typ=='positive' else 'slot-counter' if typ=='slot-counter' else 'inventory'),'role':typ,'facts':row['facts'],'gate_pin':row['pin']}
 need(set(specs)==set(ROLES),'gate class inventory mismatch')
 for k,v in specs.items(): need(v['kind']==('positive' if ROLES[k]=='positive' else 'slot-counter' if ROLES[k]=='slot-counter' else 'inventory'),'gate class role mismatch '+k)
 need(set(doc.get('target_specs',{}))==set(specs),'receipt target spec keys mismatch')
 for key,spec in specs.items():
  rec=doc['target_specs'][key];need(rec['internal']==spec['internal'] and rec['kind']==spec['kind'],'target spec identity mismatch')
  need(rec['gate_pin']==spec['gate_pin'],'target spec gate pin mismatch');pin(rec['gate_pin'],'original target '+key)
  actual=Path(doc['original_class_trees']['class_root'])/key
  check_facts(actual,spec,compare,physical)
  need(actual.read_bytes()==Path(spec['gate_pin']['path']).read_bytes(),'copied original class bytes mismatch')
  need(doc['original_physical_facts'][key]['class_pin']==filepin(actual),'stored original class pin mismatch')
  need(norm(doc['original_physical_facts'][key]['compare_facts'])==norm(compare.parse_class(actual))==norm(spec['facts']),'stored/original full compare facts mismatch')
  need(norm(doc['original_physical_facts'][key]['physical_facts'])==norm(physical.parse_class_file(actual.read_bytes())),'stored original physical facts mismatch')
 orig_tree={p.relative_to(doc['original_class_trees']['class_root']).as_posix():filepin(p) for p in sorted(Path(doc['original_class_trees']['class_root']).rglob('*.class'))}
 need(orig_tree==doc['original_class_trees']['class_tree'] and set(orig_tree)==set(specs),'original class tree incomplete')
 bundle=pin(doc['bundles']['all_six'],'six-class bundle')
 with zipfile.ZipFile(bundle) as z:
  need(sorted(z.namelist())==sorted(specs),'six-class bundle inventory mismatch')
  for key in specs: need(z.read(key)==Path(specs[key]['gate_pin']['path']).read_bytes(),'bundle class bytes differ '+key)
 need(doc['protected_inputs_unchanged'] and doc['protected_inputs_unchanged_finally'],'protected original inputs changed')
 need(doc['protected_inputs_before']==doc['protected_inputs_after']==doc['protected_inputs_after_finally'],'protected snapshots differ')
 need(doc['local_driver_copies_unchanged'] and doc['local_driver_copies_unchanged_finally'],'driver copies changed')
 need(doc['local_driver_copies_before']==doc['local_driver_copies_after']==doc['local_driver_copies_after_finally'],'driver copy snapshots differ')
 need(doc['source_pins_before']==doc['source_pins_after']==doc['source_pins_after_finally'],'source closure changed during collection')
 changed_sources=[]
 for rel,rec in doc['source_pins_before'].items():
  live=Path(rec['path']).resolve(strict=True);current=filepin(live)
  if current['bytes']!=rec['bytes'] or current['sha256']!=rec['sha256']:
   changed_sources.append(rel)
   need(rel=='tests/p3_entry_split_int_loops.rs','unexpected current source change after collection: '+rel)
   snap=filepin(SOURCE_TEST_SNAPSHOT);need(snap['bytes']==rec['bytes'] and snap['sha256']==rec['sha256'],'test-only historical source snapshot mismatch')
   before=SOURCE_TEST_SNAPSHOT.read_text(encoding='utf-8');after=live.read_text(encoding='utf-8')
   old_comment='// Append-only proposed additions to p3_entry_split_int_loops.rs.\n'
   old_low='        let mut low = 1u64;'
   new_low='''        // Reading the standalone class charges the same output budget before IR publication.\n        // Start above that known cost; the accepted cut must still be inside the emitter span.\n        let mut low = POSITIVE.len() as u64 + 1;\n        assert!(\n            max_output > low,\n            "the completed run includes class-read and emitter bytes"\n        );'''
   need(before.count(old_comment)==1 and before.count(old_low)==1,'historical source correction anchors are not unique')
   expected=before.replace(old_comment,'').replace(old_low,new_low)
   need(after==expected,'post-capture source change exceeds exact test-only output-budget/comment correction')
 need(changed_sources in ([],['tests/p3_entry_split_int_loops.rs']),'unexpected source-closure delta after collection')
 need(doc['external_pins_before']==doc['external_pins_after']==doc['external_pins_after_finally'],'external inputs changed')
 for rec in doc['external_pins_before']: pin(rec,'external source/tool input')
 need(doc['jdk_tool_pins_before']==doc['jdk_tool_pins_after'],'JDK pins changed')
 manifest_pin=doc['jdk_manifest'];need(manifest_pin['sha256']=='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec','JDK manifest SHA differs');manifest=pin(manifest_pin,'JDK manifest');jtools=json.loads(manifest.read_text())['tools']
 for leg in ('javac8','javac23'):
  for tool in ('javac','java','javap'):
   pin(jtools[leg][tool],f'{leg} {tool}')
 need(doc['target_absent'] is True and doc['target_absent_finally'] is True,'target cleanup gate false')
 need(doc['generated_sources_unchanged'] and doc['generated_sources_unchanged_finally'],'generated source changed')
 need(doc['command_streams_unchanged'] and doc['command_streams_unchanged_finally'],'raw command streams changed')
 need(doc['generated_class_trees_unchanged'] and doc['generated_class_trees_unchanged_finally'],'generated class trees changed')
 need(doc['final_cli']['sha256']==CLI_SHA and doc['final_cli']['bytes']==CLI_BYTES and doc['expected_cli_sha256']==CLI_SHA,'CLI pin mismatch')
 cli=pin(doc['final_cli'],'final CLI')
 commands=command_rows(doc,compare)
 for name,key in [('compare',COMPARE_SHA),('physical_parser',PHYSICAL_SHA),*TOOL_SHA.items()]:
  rec=doc[name];need(rec['sha256']==key,'tool record SHA mismatch: '+name);pin(rec,name)
 need(doc['runtime_wrapper']==doc['external_pins_before'][[x['path'] for x in doc['external_pins_before']].index(doc['runtime_wrapper']['path'])],'runtime wrapper external pin mismatch')
 # Reopen accepted historical raw JVM observations; 144 + 72 rows are reused, not rerun here.
 oracle_by_kind={}
 for gatepath,gd in gate_docs:
  kind='slot-counter' if 'SlotCounter' in next(iter(gd['classes'])) else 'five-class'
  lines=None
  for run in gd['original_runs']:
   rp=pin(run['stdout'],'original JVM stdout');cur=[x for x in rp.read_text().splitlines() if x.startswith(('CASE ','SLOT '))]
   need(len(cur)==run['case_rows'],'historical oracle count mismatch')
   if lines is not None:need(cur==lines,'accepted original runtimes diverge')
   lines=cur
  oracle_by_kind[kind]=lines or []
  need(len(gd.get('original_runs',[]))==2,'accepted original gate runtime count mismatch')
  cmdmap={x['label']:x for x in gd['commands']}
  for wrong in gd.get('wrong_roots',[]):
   wr=cmdmap[wrong];need(wr['exit_code']==1 and b'wrong CodeSource' in Path(wr['streams']['stderr']['path']).read_bytes(),'accepted original wrong-root control mismatch')
 need(len(oracle_by_kind['five-class'])==72 and len(oracle_by_kind['slot-counter'])==36,'historical observation row counts differ')
 need(doc['historical_oracles']['five_class_case_rows']==oracle_by_kind['five-class'] and doc['historical_oracles']['slot_counter_case_rows']==oracle_by_kind['slot-counter'],'matrix historical oracle differs from accepted raw rows')
 need(sum(sum(1 for m in v['facts']['methods'] if m['name']!='<init>') for v in specs.values())==16,'target method inventory must contain exactly 16 non-constructor methods')
 need(sum(sum(1 for m in v['facts']['methods'] if m['name']!='<init>') for v in specs.values() if v['role'] in ('refusal','topology','exception'))==9,'expected nine whole-quote refusal methods')
 need(sum(sum(1 for m in v['facts']['methods'] if m['name']!='<init>') for v in specs.values() if v['role']=='legacy')==1,'expected one legacy mixed method')
 need(sum(sum(1 for m in v['facts']['methods'] if m['name']!='<init>') for v in specs.values() if v['role']=='positive')==4 and sum(sum(1 for m in v['facts']['methods'] if m['name']!='<init>') for v in specs.values() if v['role']=='slot-counter')==2,'positive method inventory differs')
 # API grid, complete raw/report/source binding, method identity and physical map anchors.
 cells=doc.get('jarde_api_cells',[]);need(len(cells)==24,'API cell count differs')
 bycell={}
 for c in cells:
  ident=(c['class_key'],c['form'],c['evidence']);need(ident not in bycell,'duplicate API cell')
  need(c['form'] in ('child','bundle-child') and c['evidence'] in ('default','all'),'unknown API selector')
  need(c['exit_code']==0 and commands[c['command']]['exit_code']==0,'API command failed')
  expected_label=f"jarde-{c['internal']}-{c['form']}-{c['evidence']}";need(commands[c['command']]['label']==expected_label,'API command label mismatch')
  expected_argv=[str(cli),'class-source','--input',c['input']['path'],'--class',c['internal'],'--policy',c['policy'],'--release','8','--format','json']
  if c['evidence']=='all':expected_argv+=['--evidence','all']
  need(commands[c['command']]['argv']==expected_argv,'API command argv mismatch')
  need(c['policy']==('single-class' if c['form']=='child' else 'plain-jar'),'input policy mismatch')
  spec=specs[c['class_key']];need(c['internal']==spec['internal'] and c['kind']==spec['kind'],'API target identity mismatch')
  inp=pin(c['input'],'API input');need(inp.read_bytes()==Path(spec['gate_pin']['path']).read_bytes() if c['form']=='child' else inp==bundle,'API physical input mismatch')
  rp=pin(c['report'],'API report');need(rp.read_bytes()==Path(commands[c['command']]['streams']['stdout']['path']).read_bytes(),'API report/raw stdout mismatch')
  api=json.loads(rp.read_text(encoding='utf-8'));need(api==c['api'],'stored API JSON differs from raw response')
  need(api.get('class',{}).get('class_bytes')=={'digest':spec['gate_pin']['sha256'],'length':spec['gate_pin']['bytes']},'API class identity is not bound to original input bytes')
  src=pin(c['whole_source'],'whole source');need(src.read_bytes()==api['text'].encode('utf-8'),'whole source != exact API text')
  need(src==Path(c['whole_source_path']).resolve(),'whole source path mismatch')
  need(filepin(src)==c['whole_source'],'API source pin changed')
  need(src.read_bytes()==api['text'].encode('utf-8'),'API source bytes were rewritten')
  methods={}
  for m in api.get('methods',[]):
   mapped=set()
   name,desc,owner=method_identity(m['item']);need((name,desc) not in methods,'duplicate API method')
   methods[(name,desc)]=m
   ident_owner=m['item']['identity']['owner'];need(ident_owner['class_bytes']=={'digest':spec['gate_pin']['sha256'],'length':spec['gate_pin']['bytes']},'method identity is not bound to original physical class bytes');code=next((x for x in spec['facts']['methods'] if (x['name'],x['descriptor'])==(name,desc)),None)
   need(code is not None,'API method absent from original class inventory')
   bcis=code_bcis(code)
   report=m.get('outcome',{}).get('report',{});smap=report.get('source_map')
   need(isinstance(smap,dict) and isinstance(smap.get('segments'),list),'method physical source map missing')
   need(report.get('execution',{}).get('status')=='complete','API method report execution incomplete')
   mt=m.get('text');need(isinstance(mt,str),'method source text missing');rawtext=report.get('text','').encode('utf-8');need(rawtext,'method report source text missing')
   for seg in smap['segments']:
    lo,hi=seg.get('start'),seg.get('end');need(isinstance(lo,int) and isinstance(hi,int) and 0<=lo<hi<=len(rawtext),'source-map UTF8 span invalid')
    rawtext[lo:hi].decode('utf-8','strict')
    origin=seg.get('origin',{})
    anchors=[]
    for typ in ('primary','derived'):
     anchor=origin.get(typ)
     if anchor is not None:anchors.append(anchor)
    need(anchors,'source map segment has no physical anchor')
    for anchor in anchors:
     need(anchor.get('method')==m['item']['identity'],'source-map owner/method differs from its API method')
     need(anchor.get('bci') in bcis,'source-map BCI outside original method Code');mapped.add(anchor['bci'])
  need(mapped==bcis,'source map does not cover complete physical Code BCIs: '+name)
  need(len(methods)==len(spec['facts']['methods']),'API full method inventory mismatch')
  for (nm,ds),method in methods.items():
   phys=next(x for x in spec['facts']['methods'] if (x['name'],x['descriptor'])==(nm,ds))
   need(method['item']['access_flags']==phys['access'],'API method access flags differ from physical class '+nm)
  expect=set((m['name'],m['descriptor']) for m in spec['facts']['methods'])
  need(set(methods)==expect,'API method identities differ from original class')
  need(api.get('fields')==[],'unexpected projected fields in no-field CF08 targets')
  for m in methods.values():
   if bytes(m['item']['identity']['name']).decode()=='<init>':
    crep=m['outcome']['report'];need(m['outcome']['kind']=='recovered' and crep.get('quality')=='structured' and crep.get('representation')=='java','constructor inventory/body representation changed')
  if spec['role'] in ('positive','slot-counter'):
   for name,desc,access in [(x['name'],x['descriptor'],x['access']) for x in spec['facts']['methods'] if x['name']!='<init>']:
    m=methods[(name,desc)];need(m['item']['access_flags']==access,'API method access mismatch '+name);rep=m['outcome']['report']
    need(m['outcome']['kind']=='recovered' and rep.get('quality')=='structured' and rep.get('syntax_status')=='unchecked' and rep.get('representation')=='java','positive method not structured: '+name)
  elif spec['role'] in ('refusal','topology','exception'):
   for name,desc,access in [(x['name'],x['descriptor'],x['access']) for x in spec['facts']['methods'] if x['name']!='<init>']:
    m=methods[(name,desc)];need(m['item']['access_flags']==access,'API method access mismatch '+name);rep=m['outcome']['report']
    need(m['outcome']['kind']=='fallback' and rep.get('quality')=='mixed' and rep.get('syntax_status')=='not_java','negative method refusal shape changed: '+name)
    need('not recovered:' in m['text'] and 'presentation is not claimed to compile' in m['text'],'negative whole-method refusal text absent: '+name)
  elif spec['role']=='legacy':
   name,desc,access=next((x['name'],x['descriptor'],x['access']) for x in spec['facts']['methods'] if x['name']!='<init>')
   m=methods[(name,desc)];need(m['item']['access_flags']==access,'legacy access flags differ');rep=m['outcome']['report']
   need(m['outcome']['kind']=='fallback' and rep.get('quality')=='mixed' and rep.get('syntax_status')=='not_java','legacy mixed fallback changed')
  bycell[ident]=(c,methods)
 need(set(bycell)=={(k,f,e) for k in specs for f in ('child','bundle-child') for e in ('default','all')},'API selector grid incomplete')
 # Same-input default/all presentation is exact, but source identities across child/bundle are intentionally distinct.
 for key in specs:
  for form in ('child','bundle-child'):
   d,dm=bycell[(key,form,'default')];a1,am=bycell[(key,form,'all')]
   need(d['api']['text']==a1['api']['text'],'default/all whole class text differs')
   for meth in dm:
    x,y=dm[meth],am[meth]
    need(x['text']==y['text'],'default/all method text differs '+str(meth))
    need(x['outcome']['report']['text']==y['outcome']['report']['text'],'default/all raw method report text differs '+str(meth))
    need(x['outcome']['kind']==y['outcome']['kind'] and x['outcome']['report']['quality']==y['outcome']['report']['quality'] and x['outcome']['report']['diagnostics']==y['outcome']['report']['diagnostics'],'default/all method outcome/quality/diagnostic differs '+str(meth))
    need(x['item']['identity']==y['item']['identity'],'default/all physical identity differs '+str(meth))
    need(x['outcome']['report']['source_map']==y['outcome']['report']['source_map'],'default/all physical map differs '+str(meth))
 # Slot-counter method prefix spans must be two separate physical source anchors, not an alias.
 slot=bycell[('cf08/EntrySplitSlotCounterCases.class','child','default')][0]['api']
 import re
 for name in ('permuted','countUp'):
  m=bycell[('cf08/EntrySplitSlotCounterCases.class','child','default')][1][(name,next(x['descriptor'] for x in specs['cf08/EntrySplitSlotCounterCases.class']['facts']['methods'] if x['name']==name))]
  rep=m['outcome']['report'];body=rep['text'].encode('utf-8');prefix=[]
  for seg in rep['source_map']['segments']:
   a0,b0=seg['start'],seg['end'];snippet=body[a0:b0].decode('utf-8','strict')
   anchors=[seg['origin']['primary'],*seg['origin']['derived']]
   if any(x['bci']==4 for x in anchors) and re.fullmatch(r'\s*\w+ = \w+ \+ (?:3|7);\s*',snippet):prefix.append((a0,b0,snippet.strip()))
  need(any(x[2]==y[2] and x[1]<=y[0] for x in prefix for y in prefix),name+': two disjoint proved prefix spans missing')
 # Verify all executed commands' argv, cwd, runtime topology, and full compile matrix.
 used=set()
 def take(idx,label):
  r=commands[idx];need(r['label']==label,'command label mismatch '+str(label));need(idx not in used,'command reused');used.add(idx);return r
 dr=doc['driver_compile'];drow=take(dr['command'],'compile-parentless-mode-drivers');need(drow['exit_code']==0,'driver compile failed')
 version=next(r for r in commands.values() if r['label']=='jadx-version');version=take(version['index'],'jadx-version')
 need(version['argv']==[doc['jadx']['path'],'--version'] and version['exit_code']==0 and b'1.5.6' in Path(version['streams']['stdout']['path']).read_bytes(),'JADX version command mismatch')
 need(filepin(Path(doc['output'])/'collector.py')['sha256']==COLLECTOR_SHA,'captured collector copy mismatch')
 dt=doc['driver_compile']['class_tree'];driverroot=Path(doc['output'])/'driver-classes'
 verify_filetree(driverroot,dt,'driver class tree')
 need(set(dt)=={'EntrySplitModeDriver.class','EntrySplitSlotCounterCasesDriver.class'},'driver class tree unexpected')
 driver_copy=Path(doc['output'])/'source-copies';empty=str(Path(doc['output'])/'empty-cp')
 expected_driver_argv=[jtools['javac8']['javac']['path'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',str(driverroot),str(driver_copy/'EntrySplitModeDriver.java'),str(driver_copy/'EntrySplitSlotCounterCasesDriver.java')]
 need(drow['argv']==expected_driver_argv,'driver javac argv mismatch')
 for key,sourcekey,copykey in (('EntrySplitModeDriver.java','driver_source','mode'),('EntrySplitSlotCounterCasesDriver.java','slot_driver_source','slot')):
  orig=pin(doc[sourcekey],'pinned driver source');copy=Path(doc['output'])/'source-copies'/key
  need(copy.read_bytes()==orig.read_bytes(),'driver copy bytes differ '+key)
  need(filepin(copy)==doc['local_driver_copies_before'][copykey],'driver copy pin mismatch '+key)
 # Bind each API command and all compile/runtime rows to their actual command and exact output artifacts.
 for c in cells:
  apirow=take(c['command'],f"jarde-{c['internal']}-{c['form']}-{c['evidence']}")
  need(apirow['argv'][0]==str(cli) and apirow['argv'][1:]==['class-source','--input',c['input']['path'],'--class',c['internal'],'--policy',c['policy'],'--release','8','--format','json']+(['--evidence','all'] if c['evidence']=='all' else []),'Jarde API argv mismatch')
 jr=doc['jarde_compile_runtime'];need(len(jr)==len(cells)*2,'Jarde full-source compiler grid incomplete')
 compilekeys=set()
 for row in jr:
  key=(row['class_key'],row['form'],row['evidence'],row['compiler']);need(key not in compilekeys,'duplicate Jarde compile cell');compilekeys.add(key)
  c=next(x for x in cells if (x['class_key'],x['form'],x['evidence'])==key[:3]);need(row['source']==c['whole_source'],'Jarde compile did not consume exact whole source')
  cr=take(row['command'],f"jarde-compile-{row['internal']}-{row['form']}-{row['evidence']}-{row['compiler']}");need(cr['exit_code']==row['exit_code'],'Jarde compile exit mismatch')
  need(cr['label']==f"jarde-compile-{row['internal']}-{row['form']}-{row['evidence']}-{row['compiler']}",'Jarde compile label mismatch')
  verify_filetree(row['class_root'],row['class_tree'],'Jarde class root')
  if row['exit_code']==0: need(set(row['class_tree'])=={row['internal']+'.class'},'Jarde successful class tree inventory mismatch')
  tool=jtools[row['compiler']]['javac']['path'];dest=str(Path(row['class_root']).resolve());source_path=str(Path(row['source']['path']).resolve())
  expected_argv=[tool,'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-cp',str(Path(doc['output'])/'empty-cp'),'-sourcepath',str(Path(doc['output'])/'empty-cp'),'-d',dest,source_path] if row['compiler']=='javac8' else [tool,'--release','8','-g','-encoding','UTF-8','-proc:none','-cp',str(Path(doc['output'])/'empty-cp'),'-sourcepath',str(Path(doc['output'])/'empty-cp'),'-d',dest,source_path]
  need(cr['argv']==expected_argv,'Jarde compiler argv/source mismatch')
  if row['exit_code']==0:
   need(row.get('runtime_eligible') is True and row.get('class_fact_issues')==[],'successful Jarde compile not physically eligible')
   target=Path(row['class_root'])/(row['internal']+'.class');fa,fb=check_facts(target,specs[row['class_key']],compare,physical,52)
   need(norm(row['target_facts']['compare_facts'])==norm(fa) and norm(row['target_facts']['physical_facts'])==norm(fb),'Jarde stored physical facts mismatch')
   need(row['class_tree'].get(row['internal']+'.class')==filepin(target),'Jarde class-tree target mismatch')
   need(len(row.get('runtime',[]))==2 and row.get('wrong_root',{}).get('rejected') is True,'successful Jarde compile lacks two VM/negative root rows')
   for rt in row['runtime']:
    rr=take(rt['command'],f"jarde-runtime-{row['internal']}-{row['form']}-{row['evidence']}-{row['compiler']}-{rt['runtime']}");need(rr['exit_code']==0 and rt['exit_code']==0,'generated Jarde VM failed')
    need(filepin(rt['stdout'])==rt['stdout'] and filepin(rt['stderr'])==rt['stderr'],'runtime stream pin mismatch')
    need(rt['runtime'] in ('javac8','javac23'),'unknown Jarde runtime leg')
    argv=rr['argv'];leg=rt['runtime'];java_path=jtools[leg]['java']['path'];runtime_path=doc['runtime_wrapper']['path']
    need(Path(argv[0]).is_file() and Path(argv[0]).name.startswith('python') and argv[1:4]==['-B',runtime_path,'30'] and argv[4]==java_path and argv[5:8]==['-Xverify:all','-cp',str(driverroot)],'Jarde VM wrapper/driver-only argv mismatch')
    need(not any(str(x).startswith('-Xss') for x in argv),'non-default Java stack')
    if row['kind']=='slot-counter': need(argv[8:]==['EntrySplitSlotCounterCasesDriver',row['class_root'],row['class_root']],'slot driver roots mismatch')
    else:
     expected_mode='positive' if row['kind']=='positive' else 'inventory'
     need(argv[8:]==['EntrySplitModeDriver',expected_mode,row['internal'].replace('/','.'),','.join(sorted(f"{m['name']}{m['descriptor']}" for m in specs[row['class_key']]['facts']['methods'] if m['name']!='<init>')),row['class_root'],row['class_root']],'mode driver arguments mismatch')
    output=Path(rr['streams']['stdout']['path']).read_text(encoding='utf-8').splitlines()
    if row['kind'] in ('positive','slot-counter'):
     hist=oracle_by_kind['slot-counter' if row['kind']=='slot-counter' else 'five-class'];actual_rows=[x for x in output if x.startswith('CASE ')]
     need(rt.get('rows')==actual_rows==hist and rt.get('matches_accepted_original_case_rows') is True,'generated Jarde observations differ from original')
    else:
     expected_line=f"INVENTORY class={row['internal'].replace('/', '.')} methods={len(specs[row['class_key']]['facts']['methods'])-1} methodsInvoked=false"
     need(rt.get('inventory_only') is True and output==[expected_line] and rt.get('inventory_stdout')==output,'negative target inventory check differs')
   wr=row['wrong_root'];wrow=take(wr['command'],f"jarde-wrong-root-{row['internal']}-{row['form']}-{row['evidence']}-{row['compiler']}");wargv=wrow['argv'];need(wrow['exit_code']==1 and wr['exit_code']==1 and wr['rejected'] is True,'Jarde wrong-root control failed')
   need(Path(wargv[0]).is_file() and Path(wargv[0]).name.startswith('python') and wargv[1:4]==['-B',doc['runtime_wrapper']['path'],'30'] and wargv[4:9]==[jtools['javac8']['java']['path'],'-Xverify:all','-cp',str(driverroot),'EntrySplitModeDriver'] and wargv[9:]==['inventory',row['internal'].replace('/','.'),','.join(sorted(f"{m['name']}{m['descriptor']}" for m in specs[row['class_key']]['facts']['methods'] if m['name']!='<init>')),row['class_root'],str(Path(doc['output'])/'empty-cp')],'wrong-root Java argv mismatch')
   need(b'wrong CodeSource:' in Path(wrow['streams']['stderr']['path']).read_bytes(),'wrong-root stderr lacks source rejection')
  else:
   need(not row.get('runtime') and not row.get('wrong_root'),'failed compile must not receive VM')
   need(row['class_tree']=={},'failed Jarde compile unexpectedly emitted class files')
 need(len(compilekeys)==len(jr),'Jarde compile cells missing')
 need(sum(x['exit_code']==0 for x in jr)==16 and sum(x['exit_code']!=0 for x in jr)==32,'Jarde full-source outcomes differ from six-target contract')
 need(all(x['kind'] in ('positive','slot-counter') for x in jr if x['exit_code']==0) and all(x['kind']=='inventory' for x in jr if x['exit_code']!=0),'Jarde compiler failures/successes do not match positives/refusals')
 # JADX complete trees/compile outputs may expose real baseline incompatibilities; do not rewrite them.
 jouts=doc.get('jadx_outputs',[]);need(len(jouts)==6,'JADX target grid incomplete')
 for jo in jouts:
  spec=specs[jo['class_key']];cmd=take(jo['command'],f"jadx-full-{jo['internal']}");need(cmd['exit_code']==jo['exit_code'],'JADX exit mismatch')
  need(cmd['label']==f"jadx-full-{jo['internal']}",'JADX target label mismatch')
  jadx_dest=Path(doc['output'])/'jadx'/jo['internal'].replace('/','_')
  expected_jadx_argv=[doc['jadx']['path'],'--threads-count','1','--no-res','--config','none','-d',str(jadx_dest),str(Path(doc['original_class_trees']['class_root'])/jo['class_key'])]
  need(cmd['argv']==expected_jadx_argv,'JADX command input/whole target mismatch')
  if jadx_dest.exists():
   verify_filetree(jadx_dest,jo['output_tree'],'full JADX source tree')
   java_files=sorted(p for p in jadx_dest.rglob('*.java'))
   need([filepin(p) for p in java_files]==jo['sources'],'JADX Java source inventory differs from full output tree')
  else: need(jo['output_tree']=={} and jo['sources']==[],'missing failed JADX output tree has recorded artifacts')
  for p in jo.get('sources',[]):pin(p,'JADX source')
  tree=jo.get('output_tree',{})
  if jo['exit_code']==0: need(tree and jo.get('sources'),'successful JADX output has no full source tree')
  for rel,p in tree.items():pin(p,'JADX output '+rel)
 jc=doc.get('jadx_compile_runtime',[])
 need(len(jc)==sum(2 for x in jouts if x['exit_code']==0),'JADX compiler grid incomplete')
 for row in jc:
  spec=specs[row['class_key']];cr=take(row['command'],f"jadx-compile-{row['internal']}-{row['compiler']}");need(cr['exit_code']==row['exit_code'],'JADX compiler exit mismatch')
  for p in row.get('sources',[]):pin(p,'JADX compiler source')
  source_rows=next(x for x in jouts if x['class_key']==row['class_key']);need(row['sources']==source_rows['sources'],'JADX compiler did not use complete original source closure')
  verify_filetree(row['class_root'],row['class_tree'],'JADX class root')
  if row['exit_code']==0: need(set(row['class_tree'])=={row['internal']+'.class'},'JADX successful class tree inventory mismatch')
  tool=jtools[row['compiler']]['javac']['path'];dest=str(Path(row['class_root']).resolve());sourcepaths=[x['path'] for x in row['sources']];empty=str(Path(doc['output'])/'empty-cp')
  expected_argv=[tool,'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',dest,*sourcepaths] if row['compiler']=='javac8' else [tool,'--release','8','-g','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',dest,*sourcepaths]
  need(cr['argv']==expected_argv,'JADX compiler argv/source mismatch')
  if row['exit_code']==0:
   need(row.get('runtime_eligible') is True and row.get('class_fact_issues')==[],'successful JADX compile not physically eligible')
   tgt=Path(row['class_root'])/(row['internal']+'.class');fa,fb=check_facts(tgt,spec,compare,physical,52)
   need(norm(row['target_facts']['compare_facts'])==norm(fa) and norm(row['target_facts']['physical_facts'])==norm(fb),'JADX stored physical facts mismatch')
   need(row['class_tree'].get(row['internal']+'.class')==filepin(tgt),'JADX class-tree target mismatch')
   need(len(row.get('runtime',[]))==2 and row.get('wrong_root',{}).get('rejected') is True,'successful JADX compile lacks VM/root controls')
   for rt in row['runtime']:
    rr=take(rt['command'],f"jadx-runtime-{row['internal']}-{row['compiler']}-{rt['runtime']}");need(rr['exit_code']==0 and rt['exit_code']==0,'JADX VM failed')
    argv=rr['argv'];leg=rt['runtime'];need(Path(argv[0]).name.startswith('python') and argv[1:4]==['-B',doc['runtime_wrapper']['path'],'30'] and argv[4:8]==[jtools[leg]['java']['path'],'-Xverify:all','-cp',str(driverroot)],'JADX VM wrapper/driver-only argv mismatch')
    if row['kind']=='slot-counter':need(argv[8:]==['EntrySplitSlotCounterCasesDriver',row['class_root'],row['class_root']],'JADX slot driver roots mismatch')
    else:
     mode='positive' if row['kind']=='positive' else 'inventory';sig=','.join(sorted(f"{m['name']}{m['descriptor']}" for m in specs[row['class_key']]['facts']['methods'] if m['name']!='<init>'))
     need(argv[8:]==['EntrySplitModeDriver',mode,row['internal'].replace('/','.'),sig,row['class_root'],row['class_root']],'JADX mode driver args mismatch')
    need(filepin(rt['stdout'])==rt['stdout'] and filepin(rt['stderr'])==rt['stderr'],'JADX runtime stream pin mismatch')
    if row['kind'] in ('positive','slot-counter'):
     hist=oracle_by_kind['slot-counter' if row['kind']=='slot-counter' else 'five-class'];actual_rows=[x for x in Path(rr['streams']['stdout']['path']).read_text(encoding='utf-8').splitlines() if x.startswith('CASE ')]
     need(rt.get('rows')==actual_rows==hist and rt.get('matches_accepted_original_case_rows') is True,'JADX observations differ from historical original')
    else:
     actual_output=Path(rr['streams']['stdout']['path']).read_text(encoding='utf-8').splitlines();expected_line=f"INVENTORY class={row['internal'].replace('/', '.')} methods={len(specs[row['class_key']]['facts']['methods'])-1} methodsInvoked=false"
     need(rt.get('inventory_only') is True and rt.get('inventory_stdout')==actual_output==[expected_line],'JADX negative target invoked')
   wr=row['wrong_root'];wrow=take(wr['command'],f"jadx-wrong-root-{row['internal']}-{row['compiler']}");need(wrow['exit_code']==1 and wr['rejected'] is True,'JADX wrong-root control failed')
   wa=wrow['argv'];need(Path(wa[0]).name.startswith('python') and wa[1:4]==['-B',doc['runtime_wrapper']['path'],'30'] and wa[4:9]==[jtools['javac8']['java']['path'],'-Xverify:all','-cp',str(driverroot),'EntrySplitModeDriver'] and wa[9:]==['inventory',row['internal'].replace('/','.'),','.join(sorted(f"{m['name']}{m['descriptor']}" for m in specs[row['class_key']]['facts']['methods'] if m['name']!='<init>')),row['class_root'],str(Path(doc['output'])/'empty-cp')],'JADX wrong-root argv mismatch')
   need(b'wrong CodeSource:' in Path(wrow['streams']['stderr']['path']).read_bytes(),'JADX wrong-root stderr lacks source rejection')
  else:
   need(not row.get('runtime') and not row.get('wrong_root'),'failed JADX source compile must not receive VM')
   need(row['class_tree']=={},'failed JADX compile unexpectedly emitted class files')
 need(used==set(commands),'unbound or unreviewed command rows: '+str(sorted(set(commands)-used)))
 counts=doc.get('counts',{})
 derived={'commands':len(commands),'api_cells':len(cells),'jarde_compiles':len(jr),'jarde_successful_compiles':sum(x['exit_code']==0 for x in jr),'jarde_vm_runs':sum(len(x.get('runtime',[])) for x in jr),'jarde_case_rows':sum(len(rt.get('rows',[])) for x in jr for rt in x.get('runtime',[])),'jarde_inventory_vm_runs':sum('inventory_stdout' in rt for x in jr for rt in x.get('runtime',[])),'jarde_wrong_root_rows':sum('wrong_root' in x for x in jr),'jadx_targets':len(jouts),'jadx_compiles':len(jc),'jadx_vm_runs':sum(len(x.get('runtime',[])) for x in jc),'jadx_case_rows':sum(len(rt.get('rows',[])) for x in jc for rt in x.get('runtime',[])),'jadx_inventory_vm_runs':sum('inventory_stdout' in rt for x in jc for rt in x.get('runtime',[])),'jadx_wrong_root_rows':sum('wrong_root' in x for x in jc),'historical_observations_reused':216}
 need(counts==derived,'receipt summary counts do not match independently derived rows')
 need(derived['commands']==148 and derived['api_cells']==24 and derived['jarde_compiles']==48 and derived['jadx_targets']==6,'matrix grid/command counts differ')
 need(derived['jarde_successful_compiles']==16 and derived['jarde_vm_runs']==32 and derived['jarde_case_rows']==1728,'positive Jarde runtime matrix incomplete')
 need(derived['jarde_wrong_root_rows']==16,'Jarde wrong-root grid incomplete')
 need(derived['jadx_targets']==6 and derived['jadx_compiles']==8,'JADX recorded source/compiler matrix incomplete')
 result={'status':'independent-review-passed','receipt':filepin(exe),'collector':filepin(COLLECTOR),'counts':doc.get('counts',{}),'targets':{k:{'kind':v['kind'],'methods':len(v['facts']['methods']),'fields':len(v['facts']['fields'])} for k,v in specs.items()},'historical_case_rows_reused':{k:len(v) for k,v in oracle_by_kind.items()},'reopened_pin_records':reopened_pin_records,'source_test_post_capture_exception':{'snapshot':filepin(SOURCE_TEST_SNAPSHOT),'current_changed_source_paths':changed_sources,'reason':'root supplied the exact pre-correction test snapshot because the live test received a post-capture output-budget/comment-only correction'},'jadx_outcomes':[{'class_key':x['class_key'],'exit_code':x['exit_code'],'source_count':len(x.get('sources',[])),'stderr':Path(commands[x['command']]['streams']['stderr']['path']).read_bytes()[:1200].decode('utf-8','replace')} for x in jouts],'jarde_compile_failures':[{'class_key':x['class_key'],'form':x['form'],'evidence':x['evidence'],'compiler':x['compiler'],'exit_code':x['exit_code'],'stderr':Path(commands[x['command']]['streams']['stderr']['path']).read_bytes()[:1200].decode('utf-8','replace')} for x in jr if x['exit_code']!=0],'jadx_compile_failures':[{'class_key':x['class_key'],'compiler':x['compiler'],'exit_code':x['exit_code'],'stderr':Path(commands[x['command']]['streams']['stderr']['path']).read_bytes()[:1200].decode('utf-8','replace')} for x in jc if x['exit_code']!=0],'notes':['Historical 216 original observations are reused and independently reopened; not rerun by this reviewer.','JADX/source/compiler differences remain actual captured results; no generated source is repaired.']}
 out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8');print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
