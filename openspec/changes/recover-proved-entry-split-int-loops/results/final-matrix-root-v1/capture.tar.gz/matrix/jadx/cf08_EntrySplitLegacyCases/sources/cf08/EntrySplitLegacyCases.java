package cf08;

/* JADX INFO: compiled from: EntrySplitFixtureWriter.java */
/* JADX INFO: loaded from: EntrySplitLegacyCases.class */
public final class EntrySplitLegacyCases {
    public static int legacy(int i, boolean z, int i2) {
        if (!z) {
            i += 3;
        }
        while (i2 != 0) {
            i2--;
            i += 3;
        }
        return i;
    }
}
