package cf08;

/* JADX INFO: compiled from: EntrySplitFixtureWriter.java */
/* JADX INFO: loaded from: EntrySplitExceptionRefusal.class */
public final class EntrySplitExceptionRefusal {
    /* JADX WARN: Code duplicated, block: B:7:0x000c  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:4:0x0004 -> B:5:0x0008). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public static int exceptionPrefix(int r3, boolean r4, int r5, int r6) {
        /*
            r0 = r4
            if (r0 != 0) goto L8
        L4:
            r0 = r3
            r1 = r6
            int r0 = r0 / r1
            r3 = r0
        L8:
            r0 = r5
            if (r0 == 0) goto L12
            int r5 = r5 + (-1)
            goto L4
        L12:
            r0 = r3
            return r0
        L14:
            r0 = 99
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: cf08.EntrySplitExceptionRefusal.exceptionPrefix(int, boolean, int, int):int");
    }
}
