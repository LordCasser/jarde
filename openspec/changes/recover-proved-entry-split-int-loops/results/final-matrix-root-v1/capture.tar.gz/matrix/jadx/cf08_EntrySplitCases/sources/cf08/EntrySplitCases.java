package cf08;

/* JADX INFO: compiled from: EntrySplitFixtureWriter.java */
/* JADX INFO: loaded from: EntrySplitCases.class */
public final class EntrySplitCases {
    public static int test(int i, boolean z, int i2) {
        if (!z) {
            i += 3;
        }
        while (i2 != 0) {
            i2--;
            i += 3;
        }
        return i;
    }

    public static int signed(int i, boolean z, int i2) {
        if (!z) {
            i -= 5;
        }
        while (i2 != 0) {
            i2--;
            i -= 5;
        }
        return i;
    }

    public static int shifted(int i, int i2, int i3, boolean z, int i4) {
        if (!z) {
            i += 5;
        }
        while (i4 != 0) {
            i4--;
            i += 5;
        }
        return i;
    }

    public static int inverted(int i, boolean z, int i2) {
        int i3 = z ? i - 2 : i3 - 2;
        while (i2 != 0) {
            i2--;
        }
        return i3;
    }
}
