package cf08;

/* JADX INFO: compiled from: EntrySplitSlotCounterCasesWriter.java */
/* JADX INFO: loaded from: EntrySplitSlotCounterCases.class */
public final class EntrySplitSlotCounterCases {
    public static int permuted(boolean z, int i, int i2) {
        if (!z) {
            i2 += 7;
        }
        while (i != 0) {
            i--;
            i2 += 7;
        }
        return i2;
    }

    public static int countUp(int i, boolean z, int i2) {
        if (!z) {
            i += 3;
        }
        while (i2 != 0) {
            i2++;
            i += 3;
        }
        return i;
    }
}
