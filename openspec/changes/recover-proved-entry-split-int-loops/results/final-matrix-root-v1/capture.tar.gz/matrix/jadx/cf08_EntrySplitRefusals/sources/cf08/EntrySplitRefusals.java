package cf08;

/* JADX INFO: compiled from: EntrySplitFixtureWriter.java */
/* JADX INFO: loaded from: EntrySplitRefusals.class */
public final class EntrySplitRefusals {
    /* JADX WARN: Multi-variable type inference failed */
    public static int booleanPrefix(boolean z, boolean z2, int i) {
        int i2 = z;
        if (!z2) {
            i2 = z + 1;
        }
        while (i != 0) {
            i--;
            i2++;
        }
        return i2 == true ? 1 : 0;
    }

    public static int bytePrefix(byte b, boolean z, int i) {
        int i2 = b;
        if (!z) {
            i2 = b + 5;
        }
        while (i != 0) {
            i--;
            i2 += 5;
        }
        return i2 == true ? 1 : 0;
    }

    public static int alias(int i, boolean z) {
        if (!z) {
            i++;
        }
        while (i != 0) {
            i = (i - 1) + 1;
        }
        return i;
    }

    public static int callPrefix(int i, boolean z, int i2) {
        if (!z) {
            i = Math.incrementExact(i);
        }
        while (i2 != 0) {
            i2--;
            i = Math.incrementExact(i);
        }
        return i;
    }
}
