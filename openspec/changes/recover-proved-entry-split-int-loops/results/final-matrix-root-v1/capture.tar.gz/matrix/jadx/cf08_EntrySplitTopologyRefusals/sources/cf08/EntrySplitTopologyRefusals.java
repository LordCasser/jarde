package cf08;

/* JADX INFO: compiled from: EntrySplitFixtureWriter.java */
/* JADX INFO: loaded from: EntrySplitTopologyRefusals.class */
public final class EntrySplitTopologyRefusals {
    /* JADX WARN: Code duplicated, block: B:11:0x0018  */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached at block B:0:?
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public static int extraEntry(int r2, boolean r3, int r4) {
        /*
            r0 = r3
            if (r0 == 0) goto Lb
            r0 = r4
            if (r0 == 0) goto Le
            goto L12
        Lb:
            int r2 = r2 + 3
        Le:
            r0 = r4
            if (r0 == 0) goto L18
        L12:
            int r4 = r4 + (-1)
            goto Lb
        L18:
            r0 = r2
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: cf08.EntrySplitTopologyRefusals.extraEntry(int, boolean, int):int");
    }

    public static int extraExit(int i, boolean z, int i2) {
        if (!z) {
            i += 3;
        }
        while (i2 != 0) {
            i2--;
            if (i2 == 0) {
                return i;
            }
            i += 3;
        }
        return i;
    }

    public static int extraLive(int i, boolean z, boolean z2, int i2) {
        if (!z) {
            i += 3;
        }
        while (i2 != 0) {
            i2--;
            i += 3;
        }
        if (!z2) {
            i++;
        }
        return i;
    }

    public static int stackEscape(int i, boolean z, int i2) {
        int i3 = i;
        if (!z) {
            i3 += 3;
        }
        while (i2 != 0) {
            i2--;
            i3 += 3;
        }
        return i3;
    }
}
