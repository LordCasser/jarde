// jarde: presentation of `cf08/EntrySplitRefusals` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf08;

public final class EntrySplitRefusals extends java.lang.Object {
    public EntrySplitRefusals() {
        // @method <init>()V
        // @declaration a constructor of `cf08.EntrySplitRefusals`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static int booleanPrefix(boolean arg0, boolean arg1, int arg2) {
        // jarde: not recovered: the recovery run for `booleanPrefix(ZZI)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method booleanPrefix(ZZI)I
        // @declaration a static method of `cf08.EntrySplitRefusals`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 7 8 11 14 17 18
        // the entry-split loop does not have three distinct source-proved local types
    }

    public static int bytePrefix(byte arg0, boolean arg1, int arg2) {
        // jarde: not recovered: the recovery run for `bytePrefix(BZI)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method bytePrefix(BZI)I
        // @declaration a static method of `cf08.EntrySplitRefusals`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 7 8 11 14 17 18
        // the entry-split loop does not have three distinct source-proved local types
    }

    public static int alias(int arg0, boolean arg1) {
        // jarde: not recovered: the recovery run for `alias(IZ)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method alias(IZ)I
        // @declaration a static method of `cf08.EntrySplitRefusals`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 7 8 11 14 17 18
        // the graph is not reducible over 3 block(s) [4, 7, 11]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }

    public static int callPrefix(int arg0, boolean arg1, int arg2) {
        // jarde: not recovered: the recovery run for `callPrefix(IZI)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method callPrefix(IZI)I
        // @declaration a static method of `cf08.EntrySplitRefusals`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 4 5 8 9 10 13 16 19 20
        // the graph is not reducible over 3 block(s) [4, 9, 13]: a loop is entered at more than its header or two loops cross, which no Java structure spells
    }
}
