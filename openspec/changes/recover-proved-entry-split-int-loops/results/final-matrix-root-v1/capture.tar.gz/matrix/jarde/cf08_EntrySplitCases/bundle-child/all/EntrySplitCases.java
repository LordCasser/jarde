// jarde: presentation of `cf08/EntrySplitCases` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf08;

public final class EntrySplitCases extends java.lang.Object {
    public EntrySplitCases() {
        // @method <init>()V
        // @declaration a constructor of `cf08.EntrySplitCases`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public static int test(int arg0, boolean arg1, int arg2) {
        // @method test(IZI)I
        // @declaration a static method of `cf08.EntrySplitCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        if (!arg1) {
            arg0 = arg0 + 3;
        }
        while (arg2 != 0) {
            arg2 = arg2 - 1;
            arg0 = arg0 + 3;
        }
        return arg0;
    }

    public static int signed(int arg0, boolean arg1, int arg2) {
        // @method signed(IZI)I
        // @declaration a static method of `cf08.EntrySplitCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        if (!arg1) {
            arg0 = arg0 - 5;
        }
        while (arg2 != 0) {
            arg2 = arg2 - 1;
            arg0 = arg0 - 5;
        }
        return arg0;
    }

    public static int shifted(int arg0, int arg1, int arg2, boolean arg3, int arg4) {
        // @method shifted(IIIZI)I
        // @declaration a static method of `cf08.EntrySplitCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        if (!arg3) {
            arg0 = arg0 + 5;
        }
        while (arg4 != 0) {
            arg4 = arg4 - 1;
            arg0 = arg0 + 5;
        }
        return arg0;
    }

    public static int inverted(int arg0, boolean arg1, int arg2) {
        // @method inverted(IZI)I
        // @declaration a static method of `cf08.EntrySplitCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        if (!arg1) {
            arg0 = arg0 - 2;
        }
        while (arg2 != 0) {
            arg2 = arg2 - 1;
            arg0 = arg0 - 2;
        }
        return arg0;
    }
}
