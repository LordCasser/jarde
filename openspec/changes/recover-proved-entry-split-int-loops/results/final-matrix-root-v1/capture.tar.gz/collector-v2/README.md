# CF08 entry-split final matrix collector draft — v2

This is a private, unexecuted correction of v1. V1 remains byte-for-byte preserved in its own directory. V2 makes only the four root-requested fixes:

1. Original class parsing now checks the major version pinned in each accepted original class fact, so `EntrySplitLegacyCases` remains version 49. Generated source compiles still require the expected Java 8 output version 52.
2. The driver-only compile inventory requires exactly the two actual top-level drivers, sorted: `EntrySplitModeDriver.class` and `EntrySplitSlotCounterCasesDriver.class`.
3. Inventory stdout expectations use the JVM binary class name with dots, matching the Java driver output; raw command output stays untouched.
4. The command guard's `ROOT` is the private empty classpath directory. The collector's target-size callback still explicitly scans the shared repository target, while command records now truthfully show an empty working directory. The free-space guard remains on the same filesystem and the outer collector independently checks the repository target absence.

The matrix and evidence scope are otherwise unchanged from v1. It binds accepted receipts `f6ebb661…` and `284a270c…`, uses the six pinned target classes, records 24 Jarde API cells, up to 48 whole-source Jarde compiles, six full-target JADX runs, and up to 12 whole-source JADX compiles. The 144 five-class original observations and 72 slot/counter original observations are reopened and reused, not rerun. Successful generated target roots receive two JVM runs and a wrong-CodeSource check; refusal targets receive constructor/method-inventory checks only. Full JSON, raw streams, source maps, complete source, class trees, both parser inventories, and Code/BCI facts are retained for independent review. Compiler and runtime failures remain visible.

The candidate CLI stays explicitly pinned to 63,955,664 bytes and SHA-256 `eb11645e741d944a349080fbd12f18e2e5c70bdc5809f4bdb51a6e3cdec6fb50`. The README command below is a template only; this bundle has not executed any JDK, JADX, CLI, or Cargo command.

```sh
python3 -B /private/tmp/jarde-entry-split-final-collector-luna-v2-20261019/collect_final_matrix.py \
  --cli /private/tmp/jarde-entry-split-focused-root-v4-20261019/candidate-cli \
  --cli-sha256 eb11645e741d944a349080fbd12f18e2e5c70bdc5809f4bdb51a6e3cdec6fb50 \
  --out /private/tmp/jarde-entry-split-final-matrix-root-v1-20261019
```

Python AST parsing and read-only historical receipt pin/row checks are the only validation planned here. Root review is required before execution; a future run is capture-only until independently reviewed.
