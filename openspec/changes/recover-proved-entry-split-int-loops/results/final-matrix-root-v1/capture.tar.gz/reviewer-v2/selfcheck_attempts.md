# Private reviewer dry-run notes

The first read-only Python `-B` attempt exposed reviewer assumptions, not matrix failures:

1. Historical gate source files such as `crates/jarde-java/src/build.rs` have since changed. The gate receipts still have identical historical `sources_before`/`sources_after` snapshots and accepted SHA-pinned review markers. The reviewer now verifies those internal snapshots and reopens gate artifacts/tools, without pretending old workspace sources are live-identical.
2. Parsed class facts differed only in the `path` field because the original-gate class and final-matrix copy are in different directories. The reviewer compares the complete normalized physical facts after excluding only that path, and separately verifies identical class bytes and SHA.
3. The JDK manifest record carries a path/SHA plus tool pins, not a generic `bytes` field. The reviewer hashes the manifest directly and independently reopens each listed `java`/`javac`/`javap` tool pin.
4. Runtime row stream fields are full pin objects. The reviewer now reopens `path` inside each pin rather than passing the object itself as a filesystem path.
5. The initially requested source-map fixes were applied: BLAKE3 identities bind through accepted raw old-CLI API JSON; derived anchors are expanded as lists; physical BCI coverage is checked per method; and prefix-span checks cover all six positive methods in all four API selector cells.

The resulting selfcheck JSON reports `independent-review-passed` for this Python checker run. Root must still execute/review the checker independently; the saved matrix receipt remains pending independent review.
