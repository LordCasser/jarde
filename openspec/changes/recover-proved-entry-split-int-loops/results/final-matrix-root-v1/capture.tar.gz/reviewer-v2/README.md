# CF08 EntrySplit final-matrix reviewer (private draft v2)

This is an independent, read-only Python reviewer for the terminal receipt at `/private/tmp/jarde-entry-split-final-matrix-root-v1-20261019/execution.json`. It does not execute Jarde, javac, java, JADX, Cargo, or Git. The reviewer reopens receipt artifacts and checks command binding, source and tool pins, full class inventories, all 24 API cells, every method's raw report/map against physical Code BCIs, complete-source compiler trees, successful generated runtime rows, and wrong-CodeSource controls. It retains the actual compile/launch failures as results; it does not treat failed targets as runtime passes.

`selfcheck/review-final.json` is a private Python `-B` dry-run result only. It is not the root's independent acceptance marker and does not establish product or CI acceptance. The receipt itself remains `captured-pending-independent-review`.

The two accepted original-gate receipts are SHA-pinned and their canonical root review markers are checked. The old-CLI BLAKE3 class identity is taken from each accepted gate's API JSON and matched to that raw stdout, exact original class input argv, and source text; it is never compared to the class file SHA-256. The gate's historical source closure is checked for internally identical before/after snapshots, while its old live Rust-source files are not required to still equal their historical pins. Current final-matrix source closure is checked against its own before/after/finally snapshots, including the one root-provided, exact pre-correction snapshot for the later test-only output-budget/comment edit.

The API checks cover all methods, including constructors. Each map span is checked against UTF-8 byte boundaries; primary anchors and every entry in the derived-anchor list must identify that method and land on its original Code BCIs. Default/all are compared within the same input form, while child and bundle-child physical identities remain distinct. Two disjoint, directly mapped prefix spans are required for each of the six positive methods in every selector cell. The nine whole-method refusal methods and one legacy mixed method have separate expected quality/content classifications.

The historical 216 JVM observations are reopened and reused, not rerun. Final generated Jarde successes are checked against the matching original observations. JADX outputs and compiler failures remain unmodified and are reported as captured, including the `inverted` source's self-reference and the actual whole-class failures. No source repair or crop is accepted.

Files:

- `review_final_matrix.py`: reviewer script.
- `pins.json`: SHA-256 pins for the reviewer, collector, helpers, CLI, gate receipts, and final receipt.
- `reviewer.diff`: exact v1-to-v2 script diff.
- `selfcheck/review-final.json`: private dry-run output.
- `selfcheck_attempts.md`: reviewer-schema errors found and corrected during private dry-run; these are not product failures.
