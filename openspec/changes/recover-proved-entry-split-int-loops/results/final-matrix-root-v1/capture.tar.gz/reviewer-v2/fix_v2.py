from pathlib import Path
p=Path('/private/tmp/jarde-entry-split-final-reviewer-luna-v2-20261019/review_final_matrix.py')
s=p.read_text()
s=s.replace("  specs[key]={'class_key':key,'internal':key[:-6],'kind':('positive' if typ=='positive' else 'slot-counter' if typ=='slot-counter' else 'inventory'),'role':typ,'facts':row['facts'],'gate_pin':row['pin']}\n", "  gate_api=next((x for x in gd['baseline_api'] if x['class']==Path(key).stem),None)\n   need(gate_api is not None and len(gate_api['methods'])==len(row['facts']['methods']),'accepted old-CLI API inventory missing '+key)\n   gate_cmd=next(x for x in gd['commands'] if x['label']==gate_api['command'])\n   need(gate_cmd['exit_code']==0 and gate_cmd['argv'][1:]==['class-source','--input',row['pin']['path'],'--class',key[:-6],'--policy','single-class','--release','8','--format','json'],'accepted old-CLI API argv does not bind exact class bytes '+key)\n   gate_owners=[m['item']['identity']['owner'] for m in gate_api['methods']]\n   need(gate_owners and all(o['class_bytes']==gate_owners[0]['class_bytes'] for o in gate_owners),'old API method owner class bytes disagree '+key)\n   old_identity=gate_owners[0]['class_bytes']\n   need(old_identity['length']==row['pin']['bytes'],'old CLI physical byte length differs from gate class pin '+key)\n   specs[key]={'class_key':key,'internal':key[:-6],'kind':('positive' if typ=='positive' else 'slot-counter' if typ=='slot-counter' else 'inventory'),'role':typ,'facts':row['facts'],'gate_pin':row['pin'],'old_class_identity':old_identity}\n")
s=s.replace("  need(api.get('class',{}).get('class_bytes')=={'digest':spec['gate_pin']['sha256'],'length':spec['gate_pin']['bytes']},'API class identity is not bound to original input bytes')\n", "  need(api.get('class',{}).get('class_bytes')==spec['old_class_identity'],'API class identity differs from accepted old-CLI class identity')\n")
s=s.replace("   ident_owner=m['item']['identity']['owner'];need(ident_owner['class_bytes']=={'digest':spec['gate_pin']['sha256'],'length':spec['gate_pin']['bytes']},'method identity is not bound to original physical class bytes');code=next((x for x in spec['facts']['methods'] if (x['name'],x['descriptor'])==(name,desc)),None)\n", "   ident_owner=m['item']['identity']['owner'];need(ident_owner['class_bytes']==spec['old_class_identity'],'method identity differs from accepted old-CLI class identity');code=next((x for x in spec['facts']['methods'] if (x['name'],x['descriptor'])==(name,desc)),None)\n")
s=s.replace("    anchors=[]\n    for typ in ('primary','derived'):\n     anchor=origin.get(typ)\n     if anchor is not None:anchors.append(anchor)\n", "    anchors=[]\n    primary=origin.get('primary')\n    if primary is not None:anchors.append(primary)\n    derived=origin.get('derived',[])\n    need(isinstance(derived,list),'source-map derived anchors are not a list')\n    anchors.extend(derived)\n")
s=s.replace("    for anchor in anchors:\n     need(anchor.get('method')==m['item']['identity'],'source-map owner/method differs from its API method')\n     need(anchor.get('bci') in bcis,'source-map BCI outside original method Code');mapped.add(anchor['bci'])\n  need(mapped==bcis,'source map does not cover complete physical Code BCIs: '+name)\n", "    for anchor in anchors:\n     need(anchor.get('method')==m['item']['identity'],'source-map owner/method differs from its API method')\n     need(anchor.get('bci') in bcis,'source-map BCI outside original method Code');mapped.add(anchor['bci'])\n   need(mapped==bcis,'source map does not cover complete physical Code BCIs: '+name)\n")
s=s.replace("    need(m['outcome']['kind']=='fallback' and rep.get('quality')=='mixed' and rep.get('syntax_status')=='not_java','negative method refusal shape changed: '+name)\n", "    need(m['outcome']['kind']=='recovered' and rep.get('quality')=='fallback' and rep.get('representation')=='mixed' and rep.get('content')=='explanation_only' and rep.get('syntax_status')=='not_java','negative method refusal shape changed: '+name)\n")
s=s.replace("   need(m['outcome']['kind']=='fallback' and rep.get('quality')=='mixed' and rep.get('syntax_status')=='not_java','legacy mixed fallback changed')\n", "   need(m['outcome']['kind']=='recovered' and rep.get('quality')=='fallback' and rep.get('representation')=='mixed' and rep.get('content')=='contains_statements' and rep.get('syntax_status')=='not_java','legacy mixed fallback changed')\n")
old=""" # Slot-counter method prefix spans must be two separate physical source anchors, not an alias.
 slot=bycell[('cf08/EntrySplitSlotCounterCases.class','child','default')][0]['api']
 import re
 for name in ('permuted','countUp'):
  m=bycell[('cf08/EntrySplitSlotCounterCases.class','child','default')][1][(name,next(x['descriptor'] for x in specs['cf08/EntrySplitSlotCounterCases.class']['facts']['methods'] if x['name']==name))]
  rep=m['outcome']['report'];body=rep['text'].encode('utf-8');prefix=[]
  for seg in rep['source_map']['segments']:
   a0,b0=seg['start'],seg['end'];snippet=body[a0:b0].decode('utf-8','strict')
   anchors=[seg['origin']['primary'],*seg['origin']['derived']]
   if any(x['bci']==4 for x in anchors) and re.fullmatch(r'\\s*\\w+ = \\w+ \\+ (?:3|7);\\s*',snippet):prefix.append((a0,b0,snippet.strip()))
  need(any(x[2]==y[2] and x[1]<=y[0] for x in prefix for y in prefix),name+': two disjoint proved prefix spans missing')
"""
new=""" # All six positive methods in all four API selectors must preserve two disjoint, direct prefix spans.
 import re
 positive_prefixes={
  ('cf08/EntrySplitCases.class','test'):(4,r'\\s*\\w+ = \\w+ \\+ 3;\\s*'),
  ('cf08/EntrySplitCases.class','signed'):(4,r'\\s*\\w+ = \\w+ - 5;\\s*'),
  ('cf08/EntrySplitCases.class','shifted'):(4,r'\\s*\\w+ = \\w+ \\+ 5;\\s*'),
  ('cf08/EntrySplitCases.class','inverted'):(14,r'\\s*\\w+ = \\w+ - 2;\\s*'),
  ('cf08/EntrySplitSlotCounterCases.class','permuted'):(4,r'\\s*\\w+ = \\w+ \\+ 7;\\s*'),
  ('cf08/EntrySplitSlotCounterCases.class','countUp'):(4,r'\\s*\\w+ = \\w+ \\+ 3;\\s*'),
 }
 for (key,name),(prefix_bci,pattern) in positive_prefixes.items():
  spec=specs[key];desc=next(x['descriptor'] for x in spec['facts']['methods'] if x['name']==name)
  for form in ('child','bundle-child'):
   for evidence in ('default','all'):
    method=bycell[(key,form,evidence)][1][(name,desc)]
    rep=method['outcome']['report'];body=rep['text'].encode('utf-8');prefix=[]
    for seg in rep['source_map']['segments']:
     lo,hi=seg['start'],seg['end'];snippet=body[lo:hi].decode('utf-8','strict')
     origin=seg['origin'];anchors=[origin['primary'],*origin.get('derived',[])]
     if any(x['bci']==prefix_bci for x in anchors) and re.fullmatch(pattern,snippet):prefix.append((lo,hi,snippet.strip()))
    unique={(x[0],x[1],x[2]) for x in prefix}
    need(len(unique)==2 and next(iter(unique))[0] < next(iter(unique))[1] if len(unique)==1 else any(x[2]==y[2] and x[1]<=y[0] for x in prefix for y in prefix),f'{name}/{form}/{evidence}: two disjoint proved prefix spans missing')
"""
if old not in s: raise SystemExit('prefix block missing')
s=s.replace(old,new)
p.write_text(s)
