from pathlib import Path
import json,tarfile,hashlib,stat,io
base=Path(__file__).parent
roots={
 'matrix':Path('/private/tmp/jarde-entry-split-final-matrix-root-v1-20261019'),
 'collector-v1':Path('/private/tmp/jarde-entry-split-final-collector-luna-v1-20261019'),
 'collector-v2':Path('/private/tmp/jarde-entry-split-final-collector-luna-v2-20261019'),
 'reviewer-v1':Path('/private/tmp/jarde-entry-split-final-reviewer-luna-v1-20261019'),
 'reviewer-v2':Path('/private/tmp/jarde-entry-split-final-reviewer-luna-v2-20261019'),
 'root-review':Path('/private/tmp/jarde-entry-split-final-matrix-review-root-v1-20261019'),
 'architecture-root-review':Path('/private/tmp/jarde-entry-split-final-architecture-review-root-v1-20261019')}
files={}
for prefix,root in roots.items():
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():
   assert '__pycache__' not in p.parts and p.name!='candidate-cli' and p.stat().st_size<64*1024**2
   files[prefix+'/'+p.relative_to(root).as_posix()]=p
files['packer.py']=Path(__file__)
for name in ['stdout','stderr']:files['root-review/'+name+'.raw']=Path('/private/tmp/jarde-entry-split-final-review-root-v1.'+name+'.raw')
assert sum(p.stat().st_size for p in files.values())<256*1024**2
rows=[{'path':n,'source':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':stat.S_IMODE(p.stat().st_mode)} for n,p in sorted(files.items())]
inv={'schema':'entry-split-final-matrix-evidence-v1','payload_members':len(rows),'members':rows}
assert json.loads((roots['matrix']/'root-review.json').read_text())['status']=='root_accepted_complete_final_matrix_and_physical_sources'
blob=(json.dumps(inv,ensure_ascii=False,indent=2)+'\n').encode();out=base/'capture.tar.gz'
with tarfile.open(out,'x:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
 item=tarfile.TarInfo('ARCHIVE_INVENTORY.json');item.mode=0o644;item.size=len(blob);t.addfile(item,io.BytesIO(blob))
with tarfile.open(out,'r:gz') as t:
 assert len(t.getmembers())==len(rows)+1
 for row in rows:
  item=t.getmember(row['path']);data=t.extractfile(item).read();assert data==Path(row['source']).read_bytes() and len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and item.mode==row['mode']
 assert json.loads(t.extractfile('ARCHIVE_INVENTORY.json').read())==inv
(base/'inventory.json').write_bytes(blob)
review={'status':'root_reopened_all_payload_bytes_and_modes','payload_members':len(rows),'archive_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'notes':['All complete source/class/raw trees preserved, including actual compiler/decompiler failures.','Private collector/reviewer static draft mistakes and read-only selfcheck corrections preserved; root performed final independent execution.','CLI/toolchains remain external pinned inputs, no Rust build artifacts in archive.']}
(base/'archive-root-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');print(json.dumps(review))
