#!/usr/bin/env python3
"""Capture final CF08 entry-split API and full-source matrix; never edits the workspace."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, shutil, sys, zipfile
sys.dont_write_bytecode=True
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
COMPARE_REL='openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD_REL='openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL='openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
PARSER=Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PARSER_SHA='c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
JDK_REL='openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_SHA='ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
JADX=Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA='64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR=Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA='966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
RUNTIME=Path('/private/tmp/jarde-testendlessloop-baseline-root-v1-20261019/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
RUNTIME_SHA='73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
GATE5=Path('/private/tmp/jarde-entry-split-fixture-gate-root-v1-20261019/execution.json')
GATE5_SHA='f6ebb66119875977e181d7e1d0aac126114024c9cae46d804bc310d47bc3bd2c'
REVIEW5=Path('/private/tmp/jarde-entry-split-fixture-gate-root-v1-20261019/root-review.json')
GATE6=Path('/private/tmp/jarde-entry-split-generalized-gate-root-v1-20261019/execution.json')
GATE6_SHA='284a270cfa0a40c51fa5d5e1aef427daa3f798e6843bfb1ac910934da6c3cb2d'
REVIEW6=Path('/private/tmp/jarde-entry-split-generalized-gate-root-v1-20261019/root-review.json')
DRIVER=Path(__file__).parent/'driver/EntrySplitModeDriver.java'
SLOT_DRIVER=Path(__file__).parent/'driver/EntrySplitSlotCounterCasesDriver.java'
DRIVER_SHA='926f26e75c0ffadec244b81b705ba1855a51680f94f48a5a0f3a78151ae87f2d'
SLOT_DRIVER_SHA='38073411b841ccfdd6e6cd6c92bbc863ad87c59e822aaec09b63e568a7c3fa51'
EXPECTED_CLI_SHA256='eb11645e741d944a349080fbd12f18e2e5c70bdc5809f4bdb51a6e3cdec6fb50'
EXPECTED_CLI_BYTES=63955664
CASE_POSITIVE='cf08/EntrySplitCases'
SLOT_INTERNAL='cf08/EntrySplitSlotCounterCases'

# Expected method identities come from the two independently accepted gate receipts.
def sha(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def load(p:Path,n:str):
    s=importlib.util.spec_from_file_location(n,p)
    if s is None or s.loader is None:raise RuntimeError(f'cannot load {p}')
    m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def read_json(p:Path):return json.loads(p.read_text(encoding='utf-8'))
def require_pin(p:Path,expected:str):
    if sha(p)!=expected:raise RuntimeError(f'pin mismatch: {p}')
def method_inventory(facts):return sorted((m['name'],m['descriptor'],m['access']) for m in facts['methods'])
def signatures(facts):return ','.join(n+d for n,d,a in method_inventory(facts) if n!='<init>')
def historical_rows(receipt, gate_root):
    rows=[]
    for run in receipt['original_runs']:
        pin=run['stdout'];p=Path(pin['path'])
        if sha(p)!=pin['sha256'] or p.stat().st_size!=pin['bytes']:raise RuntimeError('historical raw oracle pin mismatch '+str(p))
        lines=[line for line in p.read_text(encoding='utf-8').splitlines() if line.startswith('CASE ')]
        if len(lines)!=run['case_rows']:raise RuntimeError('historical CASE row count mismatch')
        if rows and rows!=lines:raise RuntimeError('historical runtimes disagree')
        rows=lines
    return rows

def historical_pins(receipt):
    paths={}
    for row in receipt.get('commands',[]):
        for stream in row.get('streams',{}).values():
            p=Path(stream['path'])
            if sha(p)!=stream['sha256'] or p.stat().st_size!=stream['bytes']:raise RuntimeError('historical command raw pin mismatch '+str(p))
            paths[str(p.resolve())]=p
        for token in row.get('argv',[]):
            try:p=Path(token)
            except TypeError:continue
            if p.is_file():paths[str(p.resolve())]=p
    for row in receipt.get('baseline_api',[]):
        pin=row['source'];p=Path(pin['path'])
        if sha(p)!=pin['sha256'] or p.stat().st_size!=pin['bytes']:raise RuntimeError('historical API source pin mismatch '+str(p))
        paths[str(p.resolve())]=p
    return list(paths.values())

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--cli',type=Path,required=True);ap.add_argument('--cli-sha256',required=True)
    ap.add_argument('--out',type=Path,required=True)
    a=ap.parse_args();runtime_argv=sys.argv[1:]
    root=ROOT.resolve(strict=True);cli=a.cli.resolve(strict=True);out=a.out.resolve()
    if out.exists():raise SystemExit('output path must be new')
    if a.cli_sha256!=EXPECTED_CLI_SHA256 or sha(cli)!=a.cli_sha256 or cli.stat().st_size!=EXPECTED_CLI_BYTES:raise SystemExit('final CLI size/SHA mismatch')
    if (root/'target').exists() or (root/'target').is_symlink():raise SystemExit('workspace target must be absent')
    cp=root/COMPARE_REL;gp=root/GUARD_REL;sp=root/SCANNER_REL;mp=root/JDK_REL
    for p,h in ((cp,COMPARE_SHA),(gp,GUARD_SHA),(sp,SCANNER_SHA),(PARSER,PARSER_SHA),(mp,JDK_SHA),(JADX,JADX_SHA),(JADX_JAR,JADX_JAR_SHA),(RUNTIME,RUNTIME_SHA),(GATE5,GATE5_SHA),(GATE6,GATE6_SHA)):
        require_pin(p,h)
    r5=read_json(GATE5);r6=read_json(GATE6)
    marker5=read_json(REVIEW5);marker6=read_json(REVIEW6)
    if marker5.get('status')!='root_accepted_verifier_valid_fixtures_and_old_cli_baseline' or marker5.get('receipt_sha256')!=GATE5_SHA:raise RuntimeError('five-class gate lacks matching accepted root marker')
    if marker6.get('status')!='root_accepted_generalized_original_gate_and_candidate_api' or marker6.get('receipt_sha256')!=GATE6_SHA:raise RuntimeError('slot-counter gate lacks matching accepted root marker')
    reviewer5=Path(marker5['review']).resolve(strict=True);reviewer6=Path(marker6['review']).resolve(strict=True)
    review5_data=read_json(reviewer5);review6_data=read_json(reviewer6)
    if review5_data.get('status')!='root_accepted_verifier_valid_fixtures_and_old_cli_baseline' or review5_data.get('receipt_sha256')!=GATE5_SHA:raise RuntimeError('five-class canonical review does not bind receipt')
    if review6_data.get('status')!='root_accepted_generalized_original_gate_and_candidate_api' or review6_data.get('receipt_sha256')!=GATE6_SHA:raise RuntimeError('slot-counter canonical review does not bind receipt')
    if r5.get('status')!='captured_pending_root_review' or r6.get('status')!='captured_pending_root_review':raise RuntimeError('unexpected gate receipt status')
    if sha(DRIVER)!=DRIVER_SHA:raise RuntimeError('mode driver pin not finalized')
    require_pin(SLOT_DRIVER,SLOT_DRIVER_SHA)
    compare=load(cp,'entrysplit_compare');guard=load(gp,'entrysplit_guard');scanner=load(sp,'entrysplit_scanner');physical=load(PARSER,'entrysplit_physical')
    jdks,jdk_record=compare.configured_jdks(mp,JDK_SHA)
    source_before=compare.source_closure(root)
    if shutil.disk_usage(root).free<5*1024**3:raise RuntimeError('5 GiB free-space guard failed')
    specs={}
    for key,record in r5['classes'].items():specs[key]={'class_key':key,'internal':key[:-6],'facts':record['facts'],'gate':'five-class','kind':'positive' if key=='cf08/EntrySplitCases.class' else 'inventory','gate_pin':record['pin']}
    key='cf08/EntrySplitSlotCounterCases.class';record=r6['classes'][key]
    specs[key]={'class_key':key,'internal':key[:-6],'facts':record['facts'],'gate':'slot-counter','kind':'slot-counter','gate_pin':record['pin']}
    if len(specs)!=6:raise RuntimeError('expected exactly six pinned target classes')
    for key,spec in specs.items():
        p=Path(spec['gate_pin']['path']);require_pin(p,spec['gate_pin']['sha256'])
        if p.stat().st_size!=spec['gate_pin']['bytes']:raise RuntimeError('gate target byte count mismatch '+key)
    out.mkdir(parents=True);rawdir=out/'raw';rawdir.mkdir();guard.ROOT=root;guard.OUT=rawdir;guard.target_bytes=lambda:scanner.target_bytes(root);guard.command_stream=compare.pin;guard.expected_test_summaries=lambda i,b:None
    empty=out/'empty-cp';empty.mkdir();driver_classes=out/'driver-classes';driver_classes.mkdir();source_copies=out/'source-copies';source_copies.mkdir()
    mode_copy=source_copies/DRIVER.name;slot_copy=source_copies/SLOT_DRIVER.name
    shutil.copy2(DRIVER,mode_copy);shutil.copy2(SLOT_DRIVER,slot_copy)
    if DRIVER.read_bytes()!=mode_copy.read_bytes() or SLOT_DRIVER.read_bytes()!=slot_copy.read_bytes():raise RuntimeError('driver copy bytes differ')
    gate_receipts=[GATE5,GATE6,REVIEW5,REVIEW6]
    historical_raws=historical_pins(r5)+historical_pins(r6)
    external=[cli,cp,gp,sp,mp,PARSER,JADX,JADX_JAR,RUNTIME,DRIVER,SLOT_DRIVER,Path(__file__).resolve(),*gate_receipts,*historical_raws,*[Path(x['gate_pin']['path']) for x in specs.values()],*[p for spec in jdks.values() for p in spec['tools'].values()]]
    external_before=[compare.pin(p) for p in external];jdk_pins_before={f'{leg}.{name}':compare.pin(p) for leg,spec in jdks.items() for name,p in spec['tools'].items()}
    report={'schema':'cf08-entry-split-final-full-source-matrix-v1','status':'running','root':str(root),'output':str(out),'runtime_argv':runtime_argv,
      'final_cli':compare.pin(cli),'expected_cli_sha256':a.cli_sha256,'accepted_gate_receipts':[compare.pin(GATE5),compare.pin(GATE6)],
      'accepted_gate_reviews':[compare.pin(REVIEW5),compare.pin(REVIEW6)],'jdk_manifest':jdk_record,'compare':compare.pin(cp),'guard':compare.pin(gp),'scanner':compare.pin(sp),'physical_parser':compare.pin(PARSER),
      'jadx':compare.pin(JADX),'jadx_jar':compare.pin(JADX_JAR),'runtime_wrapper':compare.pin(RUNTIME),'driver_source':compare.pin(DRIVER),'driver_copy':compare.pin(mode_copy),'slot_driver_source':compare.pin(SLOT_DRIVER),'slot_driver_copy':compare.pin(slot_copy),
      'source_pins_before':source_before,'external_pins_before':external_before,'jdk_tool_pins_before':jdk_pins_before,'target_specs':specs,
      'historical_oracles':{'five_class_case_rows':historical_rows(r5,GATE5.parent),'slot_counter_case_rows':historical_rows(r6,GATE6.parent)},
      'local_driver_copies_before':{'mode':compare.pin(mode_copy),'slot':compare.pin(slot_copy)},
      'original_class_trees':{},'bundles':{},'driver_compile':None,'jarde_api_cells':[],'jarde_compile_runtime':[],'jadx_outputs':[],'commands':[],
      'history_only':{'five_class_original':compare.pin(GATE5),'slot_counter_original':compare.pin(GATE6)},
      'notes':['Original five-class and slot-counter runtime observations are reused from the accepted gate receipts; this collector does not rerun those original JVM rows.',
       'The six-class matrix is one profile: complete SourceFile metadata, no local-variable table; no duplicate -g/-g:none target profile.',
       'Generated source is consumed whole. No source repair or text editing is performed; unsuccessful compiles receive no runtime invocation.',
       'Negative target methods are never invoked; successful generated targets receive only constructor/inventory checks.']}
    compare.write_json(out/'execution.json',report);rows=report['commands']
    def command(argv,label,leg='javac23'):
        if (root/'target').exists() or (root/'target').is_symlink():raise RuntimeError('workspace target appeared')
        env=compare.clean_env(dict(os.environ),jdks[leg]);env.update(guard.ENV_VALUES);env.pop('RUST_MIN_STACK',None)
        row=guard.run_command(len(rows)+1,[str(x) for x in argv],env);row['label']=label;row['tool_leg']=leg;rows.append(row);compare.write_json(out/'execution.json',report)
        if row.get('guard_stop') is not None:raise RuntimeError(f'guard stopped: {label}: {row["guard_stop"]}')
        if row.get('exit_code') is None:raise RuntimeError(f'no exit code: {label}')
        if shutil.disk_usage(root).free<5*1024**3:raise RuntimeError('5 GiB free-space floor crossed')
        return row
    def stream(row,ch='stdout'):return compare.command_artifact(row,ch)
    def tree(base):return {p.relative_to(base).as_posix():compare.pin(p) for p in sorted(base.rglob('*.class'))}
    def facts(path):
        raw=path.read_bytes();a1=compare.parse_class(path);b1=physical.parse_class_file(raw)
        if a1['class_name']!=b1['class_name'] or a1['major']!=b1['major'] or a1['methods']!=b1['methods']:
            raise RuntimeError('independent method/class parser disagreement: '+str(path))
        if sorted((f['name'],f['descriptor'],f['access']) for f in b1['fields'])!=sorted(a1['fields']):raise RuntimeError('field parser disagreement '+str(path))
        return {'class_pin':compare.pin(path),'compare_facts':a1,'physical_facts':b1}
    def inspect_class(path,spec):
        f=facts(path);p=f['physical_facts'];want=spec['facts'];issues=[]
        if p['class_name']!=spec['internal']:issues.append('class_name')
        if p['major']!=52:issues.append('major')
        if sorted((m['name'],m['descriptor'],m['access']) for m in p['methods'])!=method_inventory(want):issues.append('complete_method_access_inventory')
        if sorted((x['name'],x['descriptor'],x['access']) for x in p['fields'])!=sorted((x['name'],x['descriptor'],x['access']) for x in want['fields']):issues.append('complete_field_access_inventory')
        return f,issues
    def verify_class(path,spec,role):
        f,issues=inspect_class(path,spec)
        if issues:raise RuntimeError(role+': '+','.join(issues))
        return f
    try:
        # Preserve each full accepted class tree and build a deterministic all-six bundle.
        original_root=out/'original-classes';original_root.mkdir();original_facts={}
        for gate,receipt in ((GATE5,r5),(GATE6,r6)):
            oldroot=gate.parent/'original-classes'
            for key,spec in specs.items():
                if spec['gate_pin']['path'].startswith(str(gate.parent)):
                    src=oldroot/(key);dest=original_root/key;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
                    if src.read_bytes()!=dest.read_bytes():raise RuntimeError('original class copy mismatch '+key)
                    original_facts[key]=verify_class(dest,spec,'accepted original')
        class_tree=tree(original_root)
        if sorted(class_tree)!=sorted(specs):raise RuntimeError('six-class original class tree differs')
        report['original_class_trees']={'class_root':str(original_root),'class_tree':class_tree}
        report['original_physical_facts']=original_facts
        protected_inputs_before={'class_tree':tree(original_root)}
        bundle=out/'entry-split-six-class-bundle.jar';
        with zipfile.ZipFile(bundle,'w') as z:
            for key in sorted(specs):
                info=zipfile.ZipInfo(key,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_STORED;z.writestr(info,(original_root/key).read_bytes())
        report['bundles']={'all_six':compare.pin(bundle)}
        protected_inputs_before['bundle']=compare.pin(bundle)
        report['protected_inputs_before']=protected_inputs_before
        # Driver classes are isolated from every target root.
        dc=command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',driver_classes,mode_copy,slot_copy],'compile-parentless-mode-drivers','javac8')
        if dc['exit_code']!=0:raise RuntimeError('mode-driver compile failed')
        dt=tree(driver_classes);report['driver_compile']={'command':dc['index'],'class_tree':dt}
        if sorted(dt)!=['EntrySplitModeDriver.class','EntrySplitSlotCounterCasesDriver.class','EntrySplitModeDriver$FieldCheck.class']:raise RuntimeError('unexpected driver-only class inventory')
        for key,spec in specs.items():
            class_path=original_root/key
            for form,input_path,policy in (('child',class_path,'single-class'),('bundle-child',bundle,'plain-jar')):
                for evidence in ('default','all'):
                    argv=[cli,'class-source','--input',input_path,'--class',spec['internal'],'--policy',policy,'--release','8','--format','json']
                    if evidence=='all':argv+=['--evidence','all']
                    row=command(argv,f'jarde-{key[:-6]}-{form}-{evidence}')
                    raw=stream(row);dest=out/'jarde'/spec['internal'].replace('/','_')/form/evidence;dest.mkdir(parents=True)
                    report_path=dest/'report.json';report_path.write_bytes(raw)
                    cell={'class_key':key,'internal':spec['internal'],'kind':spec['kind'],'form':form,'evidence':evidence,'command':row['index'],'exit_code':row['exit_code'],'input':compare.pin(input_path),'policy':policy,'report':compare.pin(report_path)}
                    try:
                        api=json.loads(raw.decode('utf-8','strict'));cell['api']=api
                        if isinstance(api.get('text'),str):
                            source=dest/(spec['internal'].split('/')[-1]+'.java');source.write_text(api['text'],encoding='utf-8',newline='');cell['whole_source']=compare.pin(source);cell['whole_source_path']=str(source)
                        else:cell['source_error']='API JSON lacks complete string text'
                    except (ValueError,TypeError,UnicodeDecodeError) as e:cell['api_error']=repr(e)
                    report['jarde_api_cells'].append(cell);compare.write_json(out/'execution.json',report)
        # Compile every successful complete source under both pinned Java toolchains.
        for cell in list(report['jarde_api_cells']):
            if cell['exit_code']!=0 or 'whole_source_path' not in cell:continue
            spec=specs[cell['class_key']];source=Path(cell['whole_source_path'])
            for compiler in ('javac8','javac23'):
                dest=out/'jarde-compile'/spec['internal'].replace('/','_')/cell['form']/cell['evidence']/compiler;dest.mkdir(parents=True,exist_ok=True)
                argv=[jdks[compiler]['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',dest,source] if compiler=='javac8' else [jdks[compiler]['tools']['javac'],'--release','8','-g','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',dest,source]
                cr=command(argv,f'jarde-compile-{spec["internal"]}-{cell["form"]}-{cell["evidence"]}-{compiler}',compiler)
                if compare.pin(source)!=cell['whole_source']:raise RuntimeError('Jarde complete source changed during compile')
                item={'class_key':cell['class_key'],'internal':spec['internal'],'kind':spec['kind'],'form':cell['form'],'evidence':cell['evidence'],'compiler':compiler,'source':compare.pin(source),'command':cr['index'],'exit_code':cr['exit_code'],'class_root':str(dest),'class_tree':tree(dest)}
                if cr['exit_code']==0:
                    target=dest/(spec['internal']+'.class')
                    try:
                        item['target_facts'],issues=inspect_class(target,spec);item['class_fact_issues']=issues;item['runtime_eligible']=not issues
                    except BaseException as error:
                        item['class_facts_error']=repr(error);item['runtime_eligible']=False
                    item['runtime']=[]
                    if item['runtime_eligible']:
                        for runtime_leg in ('javac8','javac23'):
                            if spec['kind']=='positive':
                                drvargs=['EntrySplitModeDriver','positive',spec['internal'].replace('/','.'),signatures(spec['facts']),dest,dest]
                            elif spec['kind']=='slot-counter':
                                drvargs=['EntrySplitSlotCounterCasesDriver',dest,dest]
                            else:
                                drvargs=['EntrySplitModeDriver','inventory',spec['internal'].replace('/','.'),signatures(spec['facts']),dest,dest]
                            rr=command([sys.executable,'-B',RUNTIME,'30',jdks[runtime_leg]['tools']['java'],'-Xverify:all','-cp',driver_classes,*drvargs],f'jarde-runtime-{spec["internal"]}-{cell["form"]}-{cell["evidence"]}-{compiler}-{runtime_leg}',runtime_leg)
                            rt={'runtime':runtime_leg,'command':rr['index'],'exit_code':rr['exit_code'],'stdout':compare.pin(Path(rr['streams']['stdout']['path'])),'stderr':compare.pin(Path(rr['streams']['stderr']['path']))}
                            if spec['kind']!='inventory' and rr['exit_code']==0:
                                rt['rows']=[x for x in stream(rr).decode('utf-8','strict').splitlines() if x.startswith('CASE ')]
                                expected_rows=report['historical_oracles']['slot_counter_case_rows'] if spec['kind']=='slot-counter' else report['historical_oracles']['five_class_case_rows']
                                rt['matches_accepted_original_case_rows']=rt['rows']==expected_rows
                            elif spec['kind']=='inventory' and rr['exit_code']==0:
                                rt['inventory_stdout']=stream(rr).decode('utf-8','strict').splitlines()
                                rt['inventory_only']=rt['inventory_stdout']==[f'INVENTORY class={spec["internal"]} methods={len(spec["facts"]["methods"])-1} methodsInvoked=false']
                            item['runtime'].append(rt)
                        wr=command([sys.executable,'-B',RUNTIME,'30',jdks['javac8']['tools']['java'],'-Xverify:all','-cp',driver_classes,'EntrySplitModeDriver','inventory',spec['internal'].replace('/','.'),signatures(spec['facts']),dest,empty],f'jarde-wrong-root-{spec["internal"]}-{cell["form"]}-{cell["evidence"]}-{compiler}','javac8')
                        item['wrong_root']={'command':wr['index'],'exit_code':wr['exit_code'],'rejected':wr['exit_code']==1 and b'wrong CodeSource:' in stream(wr,'stderr')}
                report['jarde_compile_runtime'].append(item);compare.write_json(out/'execution.json',report)
        # Full JADX source closure per original class; never trim or rewrite its output.
        v=command([JADX,'--version'],'jadx-version')
        if v['exit_code']!=0 or b'1.5.6' not in stream(v)+stream(v,'stderr'):raise RuntimeError('JADX version mismatch')
        for key,spec in specs.items():
            target=original_root/key;dest=out/'jadx'/spec['internal'].replace('/','_')
            row=command([JADX,'--threads-count','1','--no-res','--config','none','-d',dest,target],f'jadx-full-{spec["internal"]}')
            java_files=sorted(dest.rglob('*.java')) if dest.exists() else []
            if row['exit_code']==0 and not java_files:raise RuntimeError('JADX successful output has no Java sources')
            output_tree={p.relative_to(dest).as_posix():compare.pin(p) for p in sorted(dest.rglob('*')) if p.is_file()} if dest.exists() else {}
            jout={'class_key':key,'internal':spec['internal'],'kind':spec['kind'],'command':row['index'],'exit_code':row['exit_code'],'input':compare.pin(target),'output_tree':output_tree,'sources':[compare.pin(p) for p in java_files]}
            report['jadx_outputs'].append(jout);compare.write_json(out/'execution.json',report)
            if row['exit_code']!=0:continue
            for compiler in ('javac8','javac23'):
                destc=out/'jadx-compile'/spec['internal'].replace('/','_')/compiler;destc.mkdir(parents=True,exist_ok=True)
                argv=[jdks[compiler]['tools']['javac'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',destc,*java_files] if compiler=='javac8' else [jdks[compiler]['tools']['javac'],'--release','8','-g','-encoding','UTF-8','-proc:none','-cp',empty,'-sourcepath',empty,'-d',destc,*java_files]
                cr=command(argv,f'jadx-compile-{spec["internal"]}-{compiler}',compiler)
                if [compare.pin(p) for p in java_files]!=jout['sources']:raise RuntimeError('JADX source closure changed during compile')
                item={'class_key':key,'internal':spec['internal'],'kind':spec['kind'],'compiler':compiler,'sources':[compare.pin(p) for p in java_files],'command':cr['index'],'exit_code':cr['exit_code'],'class_root':str(destc),'class_tree':tree(destc)}
                if cr['exit_code']==0:
                    targetc=destc/(spec['internal']+'.class');item['runtime']=[]
                    try:
                        item['target_facts'],issues=inspect_class(targetc,spec);item['class_fact_issues']=issues;item['runtime_eligible']=not issues
                    except BaseException as error:
                        item['class_facts_error']=repr(error);item['runtime_eligible']=False
                    if item['runtime_eligible']:
                        for runtime_leg in ('javac8','javac23'):
                            if spec['kind']=='positive':drvargs=['EntrySplitModeDriver','positive',spec['internal'].replace('/','.'),signatures(spec['facts']),destc,destc]
                            elif spec['kind']=='slot-counter':drvargs=['EntrySplitSlotCounterCasesDriver',destc,destc]
                            else:drvargs=['EntrySplitModeDriver','inventory',spec['internal'].replace('/','.'),signatures(spec['facts']),destc,destc]
                            rr=command([sys.executable,'-B',RUNTIME,'30',jdks[runtime_leg]['tools']['java'],'-Xverify:all','-cp',driver_classes,*drvargs],f'jadx-runtime-{spec["internal"]}-{compiler}-{runtime_leg}',runtime_leg)
                            rt={'runtime':runtime_leg,'command':rr['index'],'exit_code':rr['exit_code'],'stdout':compare.pin(Path(rr['streams']['stdout']['path'])),'stderr':compare.pin(Path(rr['streams']['stderr']['path']))}
                            if spec['kind']!='inventory' and rr['exit_code']==0:
                                rt['rows']=[x for x in stream(rr).decode('utf-8','strict').splitlines() if x.startswith('CASE ')]
                                expected_rows=report['historical_oracles']['slot_counter_case_rows'] if spec['kind']=='slot-counter' else report['historical_oracles']['five_class_case_rows']
                                rt['matches_accepted_original_case_rows']=rt['rows']==expected_rows
                            elif spec['kind']=='inventory' and rr['exit_code']==0:
                                rt['inventory_stdout']=stream(rr).decode('utf-8','strict').splitlines()
                                rt['inventory_only']=rt['inventory_stdout']==[f'INVENTORY class={spec["internal"]} methods={len(spec["facts"]["methods"])-1} methodsInvoked=false']
                            item['runtime'].append(rt)
                        wr=command([sys.executable,'-B',RUNTIME,'30',jdks['javac8']['tools']['java'],'-Xverify:all','-cp',driver_classes,'EntrySplitModeDriver','inventory',spec['internal'].replace('/','.'),signatures(spec['facts']),destc,empty],f'jadx-wrong-root-{spec["internal"]}-{compiler}','javac8')
                        item['wrong_root']={'command':wr['index'],'exit_code':wr['exit_code'],'rejected':wr['exit_code']==1 and b'wrong CodeSource:' in stream(wr,'stderr')}
                report.setdefault('jadx_compile_runtime',[]).append(item);compare.write_json(out/'execution.json',report)
        generated_sources_unchanged=True
        for cell in report['jarde_api_cells']:
            if 'whole_source_path' in cell and compare.pin(Path(cell['whole_source_path']))!=cell['whole_source']:generated_sources_unchanged=False
        for output in report['jadx_outputs']:
            for item in output['sources']:
                if compare.pin(Path(item['path']))!=item:generated_sources_unchanged=False
        command_streams_unchanged=True
        for row in rows:
            for name,pin in row['streams'].items():
                if compare.pin(Path(pin['path']))!=pin:command_streams_unchanged=False
        report['generated_sources_unchanged']=generated_sources_unchanged;report['command_streams_unchanged']=command_streams_unchanged
        generated_class_trees_unchanged=all(tree(Path(x['class_root']))==x['class_tree'] for x in report['jarde_compile_runtime']) and all(tree(Path(x['class_root']))==x['class_tree'] for x in report.get('jadx_compile_runtime',[]))
        report['generated_class_trees_unchanged']=generated_class_trees_unchanged
        report['protected_inputs_after']={'class_tree':tree(original_root),'bundle':compare.pin(bundle)}
        report['protected_inputs_unchanged']=report['protected_inputs_after']==report['protected_inputs_before']
        report['local_driver_copies_after']={'mode':compare.pin(mode_copy),'slot':compare.pin(slot_copy)}
        report['local_driver_copies_unchanged']=report['local_driver_copies_after']==report['local_driver_copies_before']
        report['source_pins_after']=compare.source_closure(root);report['external_pins_after']=[compare.pin(p) for p in external];report['jdk_tool_pins_after']={f'{leg}.{name}':compare.pin(p) for leg,spec in jdks.items() for name,p in spec['tools'].items()}
        report['target_absent']=not (root/'target').exists() and not (root/'target').is_symlink()
        if report['source_pins_after']!=source_before or report['external_pins_after']!=external_before or report['jdk_tool_pins_after']!=jdk_pins_before or not report['target_absent'] or not report['local_driver_copies_unchanged'] or not report['protected_inputs_unchanged'] or not report['generated_sources_unchanged'] or not report['command_streams_unchanged'] or not report['generated_class_trees_unchanged']:raise RuntimeError('final source/external/tool/target guard mismatch')
        jarde_runs=[r for x in report['jarde_compile_runtime'] for r in x.get('runtime',[])]
        jadx_runs=[r for x in report.get('jadx_compile_runtime',[]) for r in x.get('runtime',[])]
        report['counts']={'commands':len(rows),'api_cells':len(report['jarde_api_cells']),'jarde_compiles':len(report['jarde_compile_runtime']),'jarde_successful_compiles':sum(x['exit_code']==0 for x in report['jarde_compile_runtime']),'jarde_vm_runs':len(jarde_runs),'jarde_case_rows':sum(len(x.get('rows',[])) for x in jarde_runs),'jarde_inventory_vm_runs':sum('inventory_only' in x for x in jarde_runs),'jarde_wrong_root_rows':sum('wrong_root' in x for x in report['jarde_compile_runtime']),'jadx_targets':len(report['jadx_outputs']),'jadx_compiles':len(report.get('jadx_compile_runtime',[])),'jadx_vm_runs':len(jadx_runs),'jadx_case_rows':sum(len(x.get('rows',[])) for x in jadx_runs),'jadx_inventory_vm_runs':sum('inventory_only' in x for x in jadx_runs),'jadx_wrong_root_rows':sum('wrong_root' in x for x in report.get('jadx_compile_runtime',[])),'historical_observations_reused':sum(len(x['original_runs'])*len(report['historical_oracles']['slot_counter_case_rows' if x is r6 else 'five_class_case_rows']) for x in (r5,r6))}
        report['status']='captured-pending-independent-review'
    except BaseException as e:
        report['status']='failed';report['error']=repr(e);raise
    finally:
        try:
            report['local_driver_copies_after_finally']={'mode':compare.pin(mode_copy),'slot':compare.pin(slot_copy)};report['local_driver_copies_unchanged_finally']=report['local_driver_copies_after_finally']==report['local_driver_copies_before']
            if 'original_root' in locals() and 'bundle' in locals():
                report['protected_inputs_after_finally']={'class_tree':tree(original_root),'bundle':compare.pin(bundle)};report['protected_inputs_unchanged_finally']=report['protected_inputs_after_finally']==report['protected_inputs_before']
            else:report['protected_inputs_unchanged_finally']=False
            report['generated_sources_unchanged_finally']=all(compare.pin(Path(c['whole_source_path']))==c['whole_source'] for c in report['jarde_api_cells'] if 'whole_source_path' in c) and all(compare.pin(Path(x['path']))==x for o in report['jadx_outputs'] for x in o['sources'])
            report['command_streams_unchanged_finally']=all(compare.pin(Path(p['path']))==p for row in rows for p in row['streams'].values())
            report['generated_class_trees_unchanged_finally']=all(tree(Path(x['class_root']))==x['class_tree'] for x in report['jarde_compile_runtime']) and all(tree(Path(x['class_root']))==x['class_tree'] for x in report.get('jadx_compile_runtime',[]))
            report['source_pins_after_finally']=compare.source_closure(root);report['external_pins_after_finally']=[compare.pin(p) for p in external];report['target_absent_finally']=not (root/'target').exists() and not (root/'target').is_symlink()
            if report['source_pins_after_finally']!=source_before or report['external_pins_after_finally']!=external_before or not report['target_absent_finally'] or not report['local_driver_copies_unchanged_finally'] or not report['protected_inputs_unchanged_finally'] or not report['generated_sources_unchanged_finally'] or not report['command_streams_unchanged_finally'] or not report['generated_class_trees_unchanged_finally']:report['status']='failed';report['final_guard_error']='source/external/target changed'
        except BaseException as e:report['status']='failed';report['final_guard_error']=repr(e)
        report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out/'execution.json',report);shutil.copy2(__file__,out/'collector.py')
        print(json.dumps({'status':report['status'],'commands':len(rows),'error':report.get('error')}))
if __name__=='__main__':raise SystemExit(main())
