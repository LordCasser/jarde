# CF08 entry-split final matrix collector draft

This is a private, unexecuted collector and parentless Java mode driver. It does not modify the shared Jarde checkout and has not invoked JDK, JADX, or the CLI.

The collector binds the accepted five-class fixture gate (`f6ebb661…`) and the accepted slot/counter extension gate (`284a270c…`). It reopens the gate class bytes, stream artifacts, and original Java/API source pins. It copies those six complete target classes into a deterministic six-class JAR for `bundle-child`; `child` requests the individual class. The new API matrix is one fixed profile: six targets × two input forms × default/all evidence = 24 cells. Four cells belong to each positive class (eight positive source cells total); the remaining 16 cells are refusal/legacy inventory controls. The original five-class gate's two JVM runs already yielded 72 rows each (144 observations), and the slot/counter gate's two JVM runs yielded 36 rows each; these are retained as immutable historical oracles and are not rerun here.

For every successful Jarde response with whole source text, the collector writes those exact bytes and compiles the complete source under both pinned javac toolchains. It never edits or trims generated source. Each successful target compile is parsed with the shared compare parser and independent physical parser and must preserve the pinned class name, major 52, complete method/access inventory, and complete field/access inventory. Only `EntrySplitCases` receives its 72 finite behavior rows. `EntrySplitSlotCounterCases` uses its already accepted two-method driver and 36 rows. The four refusal/legacy classes receive only constructor and method-inventory checks; no refusal method is invoked. At the upper bound, eight positive Jarde source cells create 16 compiler roots and 32 VM rows (up to 1,728 case observations); two positive JADX trees create four compiler roots and eight VM rows (up to 432 observations). These are ceilings, not assumed outcomes. A wrong-CodeSource run accompanies each successful target root. Failed compiles are kept with no runtime attempt.

JADX is run once for each of six complete original target classes; each complete emitted Java tree is compiled as-is with both JDKs when JADX succeeds. The same positive-vs-inventory mode split applies. The matrix leaves compiler, JADX, API, and runtime failures visible; this collector does not classify a captured receipt as acceptance.

The runner uses the already audited command guard, source-closure snapshot, target-size scanner, Java timeout wrapper (30 seconds), default JVM stack, empty compile classpath/sourcepath, driver-only runtime classpath, `-Xverify:all`, 5 GiB free-space floor, 1 GiB workspace target cap, exact external pins, and final target-absent check. The candidate CLI path and digest are explicit arguments; the accepted final candidate is pinned to 63,955,664 bytes and SHA-256 `eb11645e741d944a349080fbd12f18e2e5c70bdc5809f4bdb51a6e3cdec6fb50`.

Expected matrix bounds: 24 API calls; 48 Jarde source compiles; six JADX calls and 12 JADX source compiles. Each successful, fact-matching generated target compile receives two JVM runs and one wrong-root attempt. The earlier original five-class and slot/counter observations are reused, not counted as new execution. Counts in any future receipt must be derived from the actual commands and rows.

## Mode driver

`EntrySplitModeDriver` supports `positive` for exactly the four `EntrySplitCases` methods and `inventory` for one supplied class/signature list. Both modes verify parentless loading, exact CodeSource, no fields, and one public no-argument constructor. Inventory mode never invokes target methods. `EntrySplitSlotCounterCasesDriver` is the exact accepted driver from the independent sixth-class gate.

## Validation performed

Only Python AST parsing and read-only receipt/pin checks were performed. The checker helpers reopened the accepted receipts' 53 and 36 unique command-stream, argv-file, and API-source artifacts, derived 72 and 36 historical CASE rows per VM family, and confirmed both driver source hashes. No Java compilation, CLI/JADX command, workspace mutation, or runtime claim was made. Root review is required before any execution.

For review, `child` and `bundle-child` are separate physical roots. A method owner/location/snapshot is expected to bind to the identity within its own cell; it must not be compared as the same physical identity across those two roots. Within one input form, default/all evidence output can be compared for stable class text and method source maps. The collector retains full reports rather than normalizing those fields.

Root-reviewed invocation template (not executed here):

```sh
python3 -B /private/tmp/jarde-entry-split-final-collector-luna-v1-20261019/collect_final_matrix.py \
  --cli /private/tmp/jarde-entry-split-focused-root-v4-20261019/candidate-cli \
  --cli-sha256 eb11645e741d944a349080fbd12f18e2e5c70bdc5809f4bdb51a6e3cdec6fb50 \
  --out /private/tmp/jarde-entry-split-final-matrix-root-v1-20261019
```

The output is a capture pending independent review, never self-acceptance. Before exit, it reopens every command stdout/stderr pin, every generated Jarde/JADX source pin, the protected original class tree and bundle, copied driver bytes, current workspace source closure, external/tool pins, and workspace `target` absence.

The final guard also reopens generated compiler output class trees (including failed-compile output directories) and verifies their recorded class-file pins did not change during VM/wrong-root checks.
