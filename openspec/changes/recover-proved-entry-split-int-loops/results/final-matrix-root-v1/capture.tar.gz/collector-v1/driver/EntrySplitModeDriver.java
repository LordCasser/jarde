import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

/** Parentless bounded driver: positive invokes only the proven positive target; inventory invokes none. */
public final class EntrySplitModeDriver {
    private EntrySplitModeDriver() {}
    public static void main(String[] args) throws Exception {
        if(args.length!=5) throw new IllegalArgumentException("usage: EntrySplitModeDriver <positive|inventory> <class> <signatures> <actual-root> <expected-root>");
        String mode=args[0], className=args[1], signatures=args[2];
        Path actual=Paths.get(args[3]).toRealPath(), expected=Paths.get(args[4]).toRealPath();
        if(!mode.equals("positive")&&!mode.equals("inventory")) throw new IllegalArgumentException("bad mode");
        try(URLClassLoader loader=new URLClassLoader(new URL[]{actual.toUri().toURL()},null)) {
            Class<?> type=Class.forName(className,true,loader);
            if(type.getClassLoader()!=loader) throw new AssertionError("target loader mismatch");
            Path source=Paths.get(type.getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath();
            if(!source.equals(expected)) throw new IllegalStateException("wrong CodeSource: "+source+" expected "+expected);
            String[] specs=signatures.isEmpty()?new String[0]:signatures.split(",");
            Constructor<?>[] constructors=type.getDeclaredConstructors();
            if(type.getDeclaredFields().length!=0||constructors.length!=1||!Modifier.isPublic(constructors[0].getModifiers())||constructors[0].getParameterTypes().length!=0) throw new AssertionError("expected no fields and one public no-arg constructor");
            if(type.getDeclaredMethods().length!=specs.length) throw new AssertionError("method inventory differs: "+type.getDeclaredMethods().length+" != "+specs.length);
            Constructor<?> constructor=constructors[0]; constructor.newInstance();
            for(String spec:specs) checkMethod(type,spec);
            if(mode.equals("inventory")) {
                System.out.println("INVENTORY class="+className+" methods="+specs.length+" methodsInvoked=false");
                return;
            }
            if(!className.equals("cf08.EntrySplitCases")||specs.length!=4) throw new AssertionError("positive mode only accepts the four EntrySplitCases methods");
            for(String methodName:new String[]{"test","signed","shifted","inverted"}) {
                String descriptor=methodName.equals("shifted")?"(III ZI)I".replace(" ",""):"(IZI)I";
                String spec=methodName+descriptor; if(!Arrays.asList(specs).contains(spec)) throw new AssertionError("positive signature missing "+spec);
                Method method=find(type,methodName);
                int amount=methodName.equals("signed")?-5:methodName.equals("inverted")?-2:methodName.equals("shifted")?5:3;
                for(int initial:new int[]{17,Integer.MAX_VALUE-1,Integer.MIN_VALUE+1}) for(boolean skip:new boolean[]{false,true}) for(int steps=0;steps<=2;steps++) {
                    Object[] argv=methodName.equals("shifted")?new Object[]{initial,0,0,skip,steps}:new Object[]{initial,skip,steps};
                    int actualValue;
                    try { actualValue=((Integer)method.invoke(null,argv)).intValue(); }
                    catch(InvocationTargetException e) { Throwable t=e.getCause(); if(t instanceof Exception)throw(Exception)t; if(t instanceof Error)throw(Error)t; throw new AssertionError(t); }
                    int expectedValue=initial; if(!skip)expectedValue+=amount; int remaining=steps; while(remaining!=0){remaining--;expectedValue+=amount;}
                    String label=methodName+"-initial-"+initial+"-skip-"+skip+"-steps-"+steps;
                    System.out.println("CASE name="+label+" actual="+actualValue+" expected="+expectedValue);
                    if(actualValue!=expectedValue)throw new AssertionError(label+" differs from finite source oracle");
                }
            }
        }
    }
    private static Method find(Class<?> c,String n) throws Exception { for(Method m:c.getDeclaredMethods())if(m.getName().equals(n))return m;throw new NoSuchMethodException(n); }
    private static void checkMethod(Class<?> c,String spec) throws Exception {
        int split=spec.indexOf('('); if(split<1)throw new IllegalArgumentException("bad method spec "+spec);
        String name=spec.substring(0,split), desc=spec.substring(split); Method found=null;
        for(Method m:c.getDeclaredMethods())if(m.getName().equals(name)&&descriptor(m).equals(desc))found=m;
        if(found==null||!Modifier.isPublic(found.getModifiers())||!Modifier.isStatic(found.getModifiers())||found.getReturnType()!=int.class)throw new AssertionError("missing public static int method "+spec);
    }
    private static String descriptor(Method m) { StringBuilder b=new StringBuilder("("); for(Class<?> t:m.getParameterTypes())b.append(type(t)); return b.append(')').append(type(m.getReturnType())).toString(); }
    private static String type(Class<?> t) { if(t==void.class)return "V";if(t==boolean.class)return "Z";if(t==byte.class)return "B";if(t==char.class)return "C";if(t==short.class)return "S";if(t==int.class)return "I";if(t==long.class)return "J";if(t==float.class)return "F";if(t==double.class)return "D";if(t.isArray())return t.getName().replace('.','/');return "L"+t.getName().replace('.','/')+";"; }
}
