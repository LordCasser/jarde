# 旧生产公开RED

root在复制20个完整class、5Java和2manifest后，以旧755fd生产region.rs（0729f113…）实际运行公开3tests。全部编译成功，3tests都在quality Structured断言处观察实际Fallback失败；并非Rust API编译失败或工具问题。late-budget测试的完整参考先失败，不冒称已验证预算停止。stdout/stderr完整保留，默认栈、5GiB/target1GiB每秒守卫、finally exact clean、target absent且运行来源前后相同。此后才集成Luna候选，不能将此失败来源等同候选。
