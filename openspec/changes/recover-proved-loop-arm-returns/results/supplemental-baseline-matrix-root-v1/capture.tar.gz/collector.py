#!/usr/bin/env python3
"""Prepared, unexecuted complete-source rebuild/runtime matrix for A/B receipts."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, shutil, sys
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASE = Path('/private/tmp/jarde-testnestedloops5-parameterized-baseline-run-root-v1-20261018')
COMPARE_REL = Path('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
COMPARE_SHA = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
JDK_REL = Path('openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json')
JDK_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = Path('openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py')
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = Path('openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py')
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
ACCEPT_SCHEMA = 'cf11-testnestedloops5-parameterized-baseline-acceptance-v1'
EXPECTED_METHODS = {('<init>', '()V'), ('run', '(IIIII)I')}
EXPECTED_FIELDS = {'innerVisits', 'tailVisits', 'tailSum', 'earlyReturns', 'rolling'}
VARIANTS, COMPILERS, PROFILES = ('A', 'B'), ('javac8', 'javac23'), ('debug', 'no-debug')
JARDEP = Path('/private/tmp/jarde-testnestedloops5-parameterized-baseline-prep-luna-v1-20261018')
CLASS_HELPER = Path('/private/tmp/jarde-testnestedloops5-parameterized-rebuild-prep-root-v2-20261018/classfile_helpers.py')


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--baseline', type=Path, default=BASE)
    ap.add_argument('--acceptance', type=Path, required=True, help='acceptance.json produced by accept_baseline.py')
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    root, baseline, acceptance, out = (args.root.resolve(strict=True), args.baseline.resolve(strict=True),
                                        args.acceptance.resolve(strict=True), args.out.resolve())
    if out.exists():
        raise SystemExit(f'refusing existing output: {out}')
    if root != ROOT.resolve() or baseline != BASE.resolve():
        raise SystemExit('workspace or baseline path differs from frozen pin')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('workspace target exists before rebuild matrix')
    if shutil.disk_usage(root).free < 5 * 1024**3:
        raise SystemExit('workspace free space is below 5 GiB')
    baseline_path = baseline / 'execution.json'
    baseline_doc = json.loads(baseline_path.read_text(encoding='utf-8'))
    acceptance_doc = json.loads(acceptance.read_text(encoding='utf-8'))
    if acceptance_doc.get('schema') != ACCEPT_SCHEMA or acceptance_doc.get('status') != 'accepted_static_baseline_with_mapping_gaps_reported':
        raise SystemExit('baseline does not have the expected independent acceptance receipt')
    if (acceptance_doc.get('baseline_receipt', {}).get('path') != str(baseline_path.resolve())
            or acceptance_doc.get('baseline_receipt', {}).get('bytes') != baseline_path.stat().st_size
            or acceptance_doc.get('baseline_receipt', {}).get('sha256') != sha(baseline_path.read_bytes())):
        raise SystemExit('acceptance receipt binds a different baseline')
    if baseline_doc.get('schema') != 'cf11-testnestedloops5-parameterized-baseline-v1' or baseline_doc.get('product_revision') != '755fd2c84ecbe204d03f0ff608d3a711a1bea494':
        raise SystemExit('baseline schema/product pin mismatch')
    if baseline_doc.get('source_unchanged') is not True or baseline_doc.get('target_absent') is not True:
        raise SystemExit('baseline does not assert source unchanged and target absent')

    compare_path = root / COMPARE_REL
    if sha(compare_path.read_bytes()) != COMPARE_SHA:
        raise SystemExit('compare helper pin mismatch')
    compare = load(compare_path, 'parameterized_matrix_compare')
    guard_path, scanner_path = root / GUARD_REL, root / SCANNER_REL
    if compare.sha(guard_path) != GUARD_SHA or compare.sha(scanner_path) != SCANNER_SHA:
        raise SystemExit('guard/scanner source pin mismatch')
    guard, scanner = load(guard_path, 'parameterized_matrix_guard'), load(scanner_path, 'parameterized_matrix_scanner')
    jdks, jdk_pin = compare.configured_jdks(root / JDK_REL, JDK_SHA)
    helper = load(CLASS_HELPER, 'parameterized_matrix_classfile')
    baseline_pin = compare.pin(baseline_path)
    acceptance_pin = compare.pin(acceptance)
    original_receipt_path = Path(baseline_doc['dependency_reference']['path'])
    original_receipt = json.loads(original_receipt_path.read_text(encoding='utf-8'))

    def verify_input_receipts() -> None:
        if compare.pin(baseline_path) != baseline_pin or compare.pin(acceptance) != acceptance_pin:
            raise RuntimeError('baseline or acceptance receipt changed')
        if compare.pin(original_receipt_path) != baseline_doc['dependency_reference']:
            raise RuntimeError('original NL5 dependency/raw reference receipt changed')
        if compare.pin(Path(baseline_doc['original_nl5_source']['path'])) != baseline_doc['original_nl5_source']:
            raise RuntimeError('upstream TestNestedLoops5 source changed')
        for command_row in baseline_doc['commands']:
            for channel in ('stdout', 'stderr'):
                compare.command_artifact(command_row, channel)
        for command_row in original_receipt['commands']:
            for channel, record in command_row['streams'].items():
                if compare.pin(Path(record['path'])) != record:
                    raise RuntimeError(f'original NL5 raw receipt changed: {record["path"]}')

    verify_input_receipts()
    driver_pin = baseline_doc['driver']
    driver_source = Path(driver_pin['path'])
    runtime_bound_pin = baseline_doc['runtime_bound']
    runtime_bound = Path(runtime_bound_pin['path'])
    cli_pin = baseline_doc['cli']
    jadx_pin, jadx_jar_pin = baseline_doc['jadx'], baseline_doc['jadx_jar']
    for record in (driver_pin, runtime_bound_pin, cli_pin, jadx_pin, jadx_jar_pin,
                   baseline_doc['dependency_reference'], baseline_doc['original_nl5_source']):
        if compare.pin(Path(record['path'])) != record:
            raise SystemExit(f'baseline-bound input changed: {record["path"]}')
    for label, path, expected in (
        ('compare', compare_path, COMPARE_SHA), ('guard', guard_path, GUARD_SHA), ('scanner', scanner_path, SCANNER_SHA),
    ):
        if compare.sha(path) != expected:
            raise SystemExit(f'{label} source changed')
    if compare.pin(CLASS_HELPER)['sha256'] != acceptance_doc['classfile_helper']['sha256']:
        raise SystemExit('classfile helper differs from accepted baseline review')
    dep = json.loads(Path(baseline_doc['dependency_reference']['path']).read_text(encoding='utf-8'))
    for record in [baseline_doc['harness_jar'], *baseline_doc['jar_pins']]:
        if compare.pin(Path(record['path'])) != record:
            raise SystemExit(f'baseline dependency changed: {record["path"]}')
    for folder, expected in baseline_doc['directory_pins'].items():
        actual = {p.relative_to(folder).as_posix(): compare.pin(p) for p in sorted(Path(folder).rglob('*.class'))}
        if actual != expected:
            raise SystemExit(f'baseline dependency class directory changed: {folder}')

    out.mkdir(parents=True)
    (out / 'raw').mkdir()
    empty = out / 'empty-classpath'; empty.mkdir()
    guard.ROOT, guard.OUT = root, out / 'raw'
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, stdout: None
    source_before = compare.source_closure(root)
    driver_copy = out / 'driver-source/ParameterizedNestedReturnDriver.java'
    driver_copy.parent.mkdir(parents=True)
    shutil.copyfile(driver_source, driver_copy)
    if compare.pin(driver_copy)['sha256'] != driver_pin['sha256']:
        raise SystemExit('independent driver copy differs from its original pin')
    driver_classes = out / 'driver-classes'; driver_classes.mkdir()
    rows: list[dict] = []
    report = {
        'schema': 'cf11-testnestedloops5-parameterized-rebuild-matrix-v1', 'status': 'running',
        'baseline_receipt': compare.pin(baseline_path), 'acceptance_receipt': compare.pin(acceptance),
        'product_revision': baseline_doc['product_revision'], 'cli': cli_pin, 'jadx': jadx_pin,
        'jadx_jar': jadx_jar_pin, 'driver_source': driver_pin, 'driver_copy': compare.pin(driver_copy),
        'runtime_timeout_wrapper': runtime_bound_pin, 'jdk_manifest': jdk_pin,
        'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path), 'scanner': compare.pin(scanner_path),
        'classfile_helper': compare.pin(CLASS_HELPER), 'source_closure_before': source_before,
        'tool_pins_before': {'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path),
            'scanner': compare.pin(scanner_path), 'jdk_manifest': compare.pin(root / JDK_REL),
            'jdk_tools': jdk_pin['tools'],
            'runtime_bound': compare.pin(runtime_bound), 'driver_source': compare.pin(driver_source),
            'classfile_helper': compare.pin(CLASS_HELPER), 'cli': compare.pin(Path(cli_pin['path'])),
            'jadx': compare.pin(Path(jadx_pin['path'])), 'jadx_jar': compare.pin(Path(jadx_jar_pin['path']))},
        'original_oracles': baseline_doc['observed_oracles'], 'source_inputs': [],
        'commands': rows, 'driver_compile': None, 'compile_cells': [], 'runtime_cells': [],
        'wrong_root_controls': [], 'notes': [
            'Each accepted Jarde default/all source and each JADX source is copied byte-for-byte and compiled independently with both Java 8 target toolchains.',
            'No emitted source is edited or repaired. Failed compilation is kept as compile_failed_no_runtime.',
            'A runtime is attempted only after actual class bytes parse as major 52 with exactly two methods, five private int fields, and Code for both methods.',
            'Runtime classpath is only the rebuilt target root plus the independent reflection driver root. Each source cell is run on both pinned JVMs and compared to the observed original A or B oracle.',
            'The timeout wrapper is invoked as Python -B under the run guard; class tree hashes are captured before and after each runtime.',
            'Baseline Jarde fallback rows remain preserved in the baseline receipt; this matrix reports actual recompilation and runtime outcomes only.',
        ],
    }

    def save() -> None:
        compare.write_json(out / 'execution.json', report)

    def command(argv, label, leg='javac23') -> dict:
        if (root / 'target').exists():
            raise RuntimeError('workspace target appeared during matrix execution')
        env = compare.clean_env(dict(os.environ), jdks[leg])
        env.update(guard.ENV_VALUES)
        env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(rows) + 1, [str(value) for value in argv], env)
        row['label'], row['tool_leg'] = label, leg
        rows.append(row); save()
        if row['guard_stop'] is not None:
            raise RuntimeError(f'guard stopped command {label}: {row["guard_stop"]}')
        return row

    def tree(root_dir: Path) -> dict:
        return {p.relative_to(root_dir).as_posix(): compare.pin(p) for p in sorted(root_dir.rglob('*')) if p.is_file()}

    def check_class(target: Path, variant: str) -> dict:
        raw = target.read_bytes()
        facts = helper.parse_class_file(raw)
        want = f'NestedReturn{variant}$TestCls'
        fields = {(f['name'], f['descriptor'], f['access']) for f in facts['fields']}
        expected_fields = {(name, 'I', 0x0002) for name in EXPECTED_FIELDS}
        methods = {(m['name'], m['descriptor']): m for m in facts['methods']}
        ok = (facts['major'] == 52 and facts['class_name'] == want and fields == expected_fields
              and set(methods) == EXPECTED_METHODS and all(m['code'] is not None for m in methods.values()))
        if not ok:
            raise ValueError(f'target class structure mismatch: {facts}')
        return {'path': str(target.resolve()), 'bytes': len(raw), 'sha256': sha(raw), 'major': facts['major'],
                'class_name': facts['class_name'], 'fields': facts['fields'],
                'methods': [{'name': m['name'], 'descriptor': m['descriptor'], 'code': m['code']} for m in facts['methods']]}

    def gather_inputs() -> list[dict]:
        inputs = []
        for row in baseline_doc['jarde_cells']:
            if row.get('exit_code') != 0 or row.get('source') is None:
                continue
            source = Path(row['source']['path'])
            if compare.pin(source) != row['source']:
                raise RuntimeError(f'Jarde source pin changed: {source}')
            report_path = Path(row['report']['path'])
            if compare.pin(report_path) != row['report']:
                raise RuntimeError(f'Jarde report pin changed: {report_path}')
            doc = json.loads(report_path.read_text(encoding='utf-8'))
            if doc['text'].encode('utf-8') != source.read_bytes():
                raise RuntimeError(f'Jarde source differs from report: {source}')
            inputs.append({'kind': 'jarde', 'variant': row['variant'], 'input_compiler': row['compiler'],
                'profile': row['profile'], 'evidence': row['evidence'], 'source': row['source'],
                'report': row['report'], 'source_path': source})
        for row in baseline_doc['jadx_cells']:
            if row.get('exit_code') != 0 or len(row.get('sources') or []) != 1:
                continue
            source_pin = row['sources'][0]; source = Path(source_pin['path'])
            if compare.pin(source) != source_pin:
                raise RuntimeError(f'JADX source pin changed: {source}')
            inputs.append({'kind': 'jadx', 'variant': row['variant'], 'input_compiler': row['compiler'],
                'profile': row['profile'], 'evidence': 'source', 'source': source_pin,
                'report': None, 'source_path': source})
        expected = 16 + 8
        if len(inputs) != expected:
            raise RuntimeError(f'expected 24 accepted full-source inputs, got {len(inputs)}')
        if len({(x['kind'], x['variant'], x['input_compiler'], x['profile'], x['evidence']) for x in inputs}) != expected:
            raise RuntimeError('duplicate source cell identities')
        return inputs

    save()
    try:
        inputs = gather_inputs()
        for item in inputs:
            variant, compiler, profile, evidence, kind = (item['variant'], item['input_compiler'], item['profile'], item['evidence'], item['kind'])
            filename = f'NestedReturn{variant}$TestCls.java'
            source_copy = out / 'input-sources' / kind / variant / compiler / profile / evidence / filename
            source_copy.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(item['source_path'], source_copy)
            source_copy_pin = compare.pin(source_copy)
            if source_copy_pin['bytes'] != item['source']['bytes'] or source_copy_pin['sha256'] != item['source']['sha256']:
                raise RuntimeError(f'byte-exact source copy mismatch: {item}')
            item['source_copy'] = source_copy_pin
            report['source_inputs'].append({k: item[k] for k in ('kind','variant','input_compiler','profile','evidence','source','report','source_copy')})

        driver_compile = command([
            jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g', '-encoding', 'UTF-8',
            '-proc:none', '-classpath', empty, '-sourcepath', empty, '-d', driver_classes, driver_copy,
        ], 'compile-independent-reflection-driver', 'javac8')
        report['driver_compile'] = {'command': driver_compile['index'], 'exit_code': driver_compile['exit_code'],
                                    'classes': tree(driver_classes)}
        if driver_compile['exit_code'] != 0:
            raise RuntimeError('driver compile failed; no runtime can be isolated')

        for item in inputs:
            v, profile = item['variant'], item['profile']
            source_copy = Path(item['source_copy']['path'])
            for compiler in COMPILERS:
                cell_id = (item['kind'], v, item['input_compiler'], profile, item['evidence'], compiler)
                class_root = out / 'classes' / item['kind'] / v / item['input_compiler'] / profile / item['evidence'] / compiler
                class_root.mkdir(parents=True)
                args8 = ['-source', '8', '-target', '8'] if compiler == 'javac8' else ['--release', '8']
                debug = '-g' if profile == 'debug' else '-g:none'
                compiled = command([jdks[compiler]['tools']['javac'], *args8, debug, '-encoding', 'UTF-8',
                    '-proc:none', '-classpath', empty, '-sourcepath', empty, '-d', class_root, source_copy],
                    f'compile-{"-".join(map(str, cell_id))}', compiler)
                cell = {'identity': list(cell_id), 'source': item['source'], 'source_copy': item['source_copy'],
                        'compile_command': compiled['index'], 'compile_exit_code': compiled['exit_code'],
                        'class_root': str(class_root), 'class_tree': tree(class_root),
                        'target_class': None, 'compile_status': 'compile_failed_no_runtime', 'runtime': []}
                report['compile_cells'].append(cell); save()
                if compiled['exit_code'] != 0:
                    continue
                target = class_root / f'NestedReturn{v}$TestCls.class'
                try:
                    cell['target_class'] = check_class(target, v)
                except (ValueError, OSError) as exc:
                    cell['compile_status'] = 'class_verification_failed_no_runtime'
                    cell['class_verification_error'] = str(exc)
                    cell['class_tree'] = tree(class_root)
                    save(); continue
                class_tree = tree(class_root)
                if sorted(class_tree) != [target.name]:
                    cell['compile_status'] = 'unexpected_class_tree_no_runtime'
                    cell['class_tree'] = class_tree
                    save(); continue
                cell['compile_status'] = 'compiled_target_verified'
                cell['class_tree'] = class_tree
                original_oracle = baseline_doc['observed_oracles'][v]
                oracle_path = Path(original_oracle['file']['path'])
                if compare.pin(oracle_path) != original_oracle['file']:
                    raise RuntimeError(f'original {v} oracle pin changed')
                oracle = oracle_path.read_bytes()
                cell['original_oracle'] = original_oracle['file']
                for runtime in COMPILERS:
                    before_target, before_driver = tree(class_root), tree(driver_classes)
                    row = command([sys.executable, '-B', runtime_bound, '30', jdks[runtime]['tools']['java'],
                        '-Xverify:all', '-cp', os.pathsep.join([str(class_root), str(driver_classes)]),
                        'ParameterizedNestedReturnDriver', f'NestedReturn{v}$TestCls', class_root],
                        f'runtime-{"-".join(map(str, cell_id))}-{runtime}', runtime)
                    stdout, stderr = compare.command_artifact(row, 'stdout'), compare.command_artifact(row, 'stderr')
                    after_target, after_driver = tree(class_root), tree(driver_classes)
                    run_record = {'runtime': runtime, 'command': row['index'], 'exit_code': row['exit_code'],
                        'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr), 'stdout': stdout.decode('utf-8', errors='replace'),
                        'matches_original_oracle': row['exit_code'] == 0 and stdout == oracle,
                        'target_class_tree_before': before_target, 'target_class_tree_after': after_target,
                        'driver_class_tree_before': before_driver, 'driver_class_tree_after': after_driver,
                        'class_trees_stable': before_target == after_target and before_driver == after_driver,
                        'isolated_classpath': [str(class_root), str(driver_classes)]}
                    cell['runtime'].append(run_record); report['runtime_cells'].append({'cell': list(cell_id), **run_record}); save()
                wrong = out / 'wrong-root' / '-'.join(map(str, cell_id)); wrong.mkdir(parents=True)
                wrong_row = command([sys.executable, '-B', runtime_bound, '30', jdks['javac23']['tools']['java'],
                    '-Xverify:all', '-cp', os.pathsep.join([str(class_root), str(driver_classes)]),
                    'ParameterizedNestedReturnDriver', f'NestedReturn{v}$TestCls', wrong],
                    f'wrong-root-{"-".join(map(str, cell_id))}', 'javac23')
                wrong_stderr = compare.command_artifact(wrong_row, 'stderr')
                control = {'identity': list(cell_id), 'command': wrong_row['index'], 'exit_code': wrong_row['exit_code'],
                    'target_loaded_from_rejection': wrong_row['exit_code'] != 0 and b'target loaded from' in wrong_stderr,
                    'stderr_sha256': sha(wrong_stderr), 'target_class_root': str(class_root),
                    'wrong_expected_root': str(wrong)}
                report['wrong_root_controls'].append(control); save()

        report['source_closure_after'] = compare.source_closure(root)
        if report['source_closure_after'] != report['source_closure_before']:
            raise RuntimeError('workspace source closure changed during rebuild matrix')
        report['baseline_receipt_after'] = compare.pin(baseline_path)
        if report['baseline_receipt_after'] != report['baseline_receipt']:
            raise RuntimeError('baseline receipt changed during rebuild matrix')
        verify_input_receipts()
        report['tool_pins_after'] = {
            'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path),
            'scanner': compare.pin(scanner_path), 'jdk_manifest': compare.pin(root / JDK_REL),
            'jdk_tools': {leg: {name: compare.pin(Path(item['path'])) for name, item in tool_rows.items()}
                          for leg, tool_rows in jdk_pin['tools'].items()},
            'runtime_bound': compare.pin(runtime_bound), 'driver_source': compare.pin(driver_source),
            'classfile_helper': compare.pin(CLASS_HELPER), 'cli': compare.pin(Path(cli_pin['path'])),
            'jadx': compare.pin(Path(jadx_pin['path'])), 'jadx_jar': compare.pin(Path(jadx_jar_pin['path'])),
        }
        if report['tool_pins_after'] != report['tool_pins_before']:
            raise RuntimeError('one or more pinned tools changed during rebuild matrix')
        report['source_unchanged'] = True
        for item in report['source_inputs']:
            for pin_record in (item['source'], item['source_copy']):
                if compare.pin(Path(pin_record['path'])) != pin_record:
                    raise RuntimeError(f'source input changed after compilation: {pin_record["path"]}')
            if item.get('report') and compare.pin(Path(item['report']['path'])) != item['report']:
                raise RuntimeError(f'baseline report changed after compilation: {item["report"]["path"]}')
        for variant, oracle in baseline_doc['observed_oracles'].items():
            if compare.pin(Path(oracle['file']['path'])) != oracle['file']:
                raise RuntimeError(f'original {variant} oracle changed during matrix')
        for cell in report['compile_cells']:
            if tree(Path(cell['class_root'])) != cell['class_tree']:
                raise RuntimeError('rebuilt class tree changed after all runtime/control invocations')
        if tree(driver_classes) != report['driver_compile']['classes']:
            raise RuntimeError('driver class tree changed after all runtime/control invocations')
        report['class_trees_final_stable'] = True
        report['target_absent'] = not (root / 'target').exists()
        if not report['target_absent']:
            raise RuntimeError('workspace target appeared during matrix')
        report['status'] = 'captured_pending_independent_matrix_acceptance'
    except BaseException as exc:
        report['status'], report['error'] = 'failed', str(exc)
        raise
    finally:
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
        shutil.copy2(__file__, out / 'collector.py')
        print(json.dumps({'status': report['status'], 'compile_cells': len(report['compile_cells']),
                          'runtime_cells': len(report['runtime_cells']), 'target_absent': report.get('target_absent'),
                          'error': report.get('error')}, separators=(',', ':')))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
