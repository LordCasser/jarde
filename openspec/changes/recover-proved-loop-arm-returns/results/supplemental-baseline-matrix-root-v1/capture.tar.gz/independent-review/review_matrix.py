from pathlib import Path
import hashlib,json,importlib.util,os
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
OUT=Path(__file__).resolve().parent
BASE=Path('/private/tmp/jarde-testnestedloops5-parameterized-rebuild-run-root-v1-20261018')
def pin(p):
 p=Path(p).resolve(strict=True);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def need(v,msg):
 if not v:raise ValueError(msg)
def verify(r):
 need(pin(r['path'])==r,'pin differs '+r['path']);return Path(r['path']).read_bytes()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','compare')
hp=Path('/private/tmp/jarde-testnestedloops5-parameterized-review-prep-root-v4-20261018/classfile_helpers.py');h=load(hp,'independent_class')
d=json.loads((BASE/'execution.json').read_text());receipt=pin(BASE/'execution.json')
need(d['status']=='captured_pending_independent_matrix_acceptance','unfinished matrix')
need(d['source_closure_before']==d['source_closure_after']==m.source_closure(ROOT),'source closure changed')
need(d['target_absent'] and not (ROOT/'target').exists(),'target exists')
need(d['tool_pins_before']==d['tool_pins_after'],'tool pins changed')
for k,r in d['tool_pins_before'].items():
 if k=='jdk_tools':
  for leg,tools in r.items():
   for q in tools.values():verify(q)
 else:verify(r)
b=json.loads(verify(d['baseline_receipt']));a=json.loads(verify(d['acceptance_receipt']))
need(a['baseline_receipt']==d['baseline_receipt'] and a['status'].startswith('accepted_'),'wrong acceptance')
for r in (d['driver_source'],d['driver_copy'],d['runtime_timeout_wrapper']):verify(r)
need(verify(d['driver_source'])==verify(d['driver_copy']),'driver source differs')
cmd={r['index']:r for r in d['commands']};used=set()
need(len(cmd)==len(d['commands']) and set(cmd)==set(range(1,len(cmd)+1)),'command census')
for r in cmd.values():
 need(r['guard_stop'] is None,'guard stopped');verify(r['streams']['stdout']);verify(r['streams']['stderr'])
def command(i,label):
 need(i not in used,'command reused');used.add(i);r=cmd[i];need(r['label']==label,'label binding');return r
def tree(p):return {q.relative_to(p).as_posix():pin(q) for q in sorted(Path(p).rglob('*')) if q.is_file()}
tools=d['tool_pins_before']['jdk_tools'];empty=str(BASE/'empty-classpath');driver=str(BASE/'driver-classes')
dr=d['driver_compile'];r=command(dr['command'],'compile-independent-reflection-driver')
need(r['exit_code']==dr['exit_code']==0 and r['argv']==[tools['javac8']['javac']['path'],'-source','8','-target','8','-g','-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',driver,d['driver_copy']['path']],'driver argv')
need(tree(Path(driver))==dr['classes'],'driver bytes')
inputs={}
for s in d['source_inputs']:
 key=tuple(s[k] for k in ('kind','variant','input_compiler','profile','evidence'));need(key not in inputs,'duplicate source')
 original=verify(s['source']);need(verify(s['source_copy'])==original,'modified generated source')
 if key[0]=='jarde':
  need(json.loads(verify(s['report']))['text'].encode()==original,'source/report differs')
  rows=[q for q in b['jarde_cells'] if (q['variant'],q['compiler'],q['profile'],q['evidence'])==key[1:]]
  need(len(rows)==1 and rows[0]['source']==s['source'] and rows[0]['report']==s['report'],'Jarde source cell binding')
 else:
  rows=[q for q in b['jadx_cells'] if (q['variant'],q['compiler'],q['profile'])==key[1:4]]
  need(key[4]=='source' and len(rows)==1 and rows[0]['sources']==[s['source']],'JADX source binding')
 inputs[key]=s
expected={(kind,v,c,p,e) for kind,ev in [('jarde',('default','all')),('jadx',('source',))] for v in ('A','B') for c in ('javac8','javac23') for p in ('debug','no-debug') for e in ev}
need(set(inputs)==expected,'24 source grid')
cells={tuple(c['identity']):c for c in d['compile_cells']};need(len(cells)==48 and set(cells)=={k+(c,) for k in expected for c in ('javac8','javac23')},'48 compile grid')
run_expected={};success=[];failures=[]
for key,c in cells.items():
 source=inputs[key[:5]];need(c['source']==source['source'] and c['source_copy']==source['source_copy'],'compile source binding')
 r=command(c['compile_command'],'compile-'+'-'.join(key));argv=[tools[key[5]]['javac']['path']]+(['-source','8','-target','8'] if key[5]=='javac8' else ['--release','8'])+['-g' if key[3]=='debug' else '-g:none','-encoding','UTF-8','-proc:none','-classpath',empty,'-sourcepath',empty,'-d',c['class_root'],c['source_copy']['path']]
 need(r['argv']==argv and r['exit_code']==c['compile_exit_code'],'actual compile argv/exit')
 need(tree(Path(c['class_root']))==c['class_tree'],'final class tree changed')
 if r['exit_code']:
  need(c['compile_status']=='compile_failed_no_runtime' and not c['runtime'],'failed compile claimed runtime')
  err=verify(r['streams']['stderr']);need(b'missing return' in err or '缺少返回语句'.encode() in err,'unexpected failure diagnostic')
  failures.append(list(key));continue
 need(c['compile_status']=='compiled_target_verified','successful class not verified')
 target=Path(c['class_root'])/('NestedReturn'+key[1]+'$TestCls.class');f=h.parse_class_file(target.read_bytes());decl=c['target_class']
 need(pin(target)=={k:decl[k] for k in ('path','bytes','sha256')} and f['major']==52,'rebuilt class bytes/major')
 need(f['class_name']=='NestedReturn'+key[1]+'$TestCls' and set(c['class_tree'])=={target.name},'rebuilt target identity/tree')
 need({(q['name'],q['descriptor'],q['access']) for q in f['fields']}=={(n,'I',2) for n in ('innerVisits','tailVisits','tailSum','earlyReturns','rolling')},'state fields changed')
 need({(q['name'],q['descriptor']) for q in f['methods']}=={('<init>','()V'),('run','(IIIII)I')},'method inventory')
 need([{'name':q['name'],'descriptor':q['descriptor'],'code':q['code']} for q in f['methods']]==decl['methods'] and all(q['code'] for q in f['methods']),'complete Code differs')
 need({q['runtime'] for q in c['runtime']}=={'javac8','javac23'} and len(c['runtime'])==2,'dual JVM omitted')
 for run in c['runtime']:
  leg=run['runtime'];r=command(run['command'],'runtime-'+'-'.join(key)+'-'+leg)
  av=r['argv'];need(av[1:]==['-B',d['runtime_timeout_wrapper']['path'],'30',tools[leg]['java']['path'],'-Xverify:all','-cp',os.pathsep.join([c['class_root'],driver]),'ParameterizedNestedReturnDriver','NestedReturn'+key[1]+'$TestCls',c['class_root']],'runtime argv/isolation')
  stdout=verify(r['streams']['stdout']);oracle=verify(b['observed_oracles'][key[1]]['file'])
  need(r['exit_code']==run['exit_code']==0 and stdout==oracle and run['matches_original_oracle'],'semantic mismatch')
  need(hashlib.sha256(stdout).hexdigest()==run['stdout_sha256'] and stdout.decode()==run['stdout'],'stdout summary differs')
  need(run['target_class_tree_before']==run['target_class_tree_after']==c['class_tree'] and run['driver_class_tree_before']==run['driver_class_tree_after']==dr['classes'],'runtime bytes changed')
  run_expected[(key,leg)]={'cell':list(key),**run}
 success.append(list(key))
need(len(d['runtime_cells'])==len(run_expected) and {(tuple(q['cell']),q['runtime']) for q in d['runtime_cells']}==set(run_expected),'runtime table keys')
for q in d['runtime_cells']:need(q==run_expected[(tuple(q['cell']),q['runtime'])],'runtime tables differ')
controls=set()
for q in d['wrong_root_controls']:
 key=tuple(q['identity']);need(list(key) in success and key not in controls,'invalid control binding');controls.add(key)
 r=command(q['command'],'wrong-root-'+'-'.join(key));c=cells[key]
 need(r['argv'][1:]==['-B',d['runtime_timeout_wrapper']['path'],'30',tools['javac23']['java']['path'],'-Xverify:all','-cp',os.pathsep.join([c['class_root'],driver]),'ParameterizedNestedReturnDriver','NestedReturn'+key[1]+'$TestCls',q['wrong_expected_root']],'control argv/isolation')
 need(q['wrong_expected_root']!=c['class_root'] and r['exit_code']==q['exit_code']!=0 and b'target loaded from' in verify(r['streams']['stderr']),'wrong root did not reject')
need(controls=={tuple(q) for q in success} and used==set(cmd),'control or raw command not bound')
need(pin(BASE/'execution.json')==receipt and m.source_closure(ROOT)==d['source_closure_before'],'receipt/source changed')
result={'status':'accepted','checker':pin(__file__),'receipt':receipt,'classfile_helper':pin(hp),'commands':len(cmd),'raw_streams':len(cmd)*2,'compile_attempts':48,'successful_compile_cells':success,'failed_missing_return_cells':failures,'runtime_commands':len(run_expected),'runtime_cases':sum(len(verify(b['observed_oracles'][k[0][1]]['file']).splitlines()) for k in run_expected),'wrong_root_controls':len(controls),'source_unchanged':True,'target_absent':True}
(OUT/'root-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ('status','commands','compile_attempts','runtime_commands','runtime_cases','wrong_root_controls')}))
