// jarde: presentation of `NestedReturnB$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class NestedReturnB$TestCls extends java.lang.Object {
    private int innerVisits;

    private int tailVisits;

    private int tailSum;

    private int earlyReturns;

    private int rolling;

    public NestedReturnB$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `NestedReturnB$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public int run(int arg1, int arg2, int arg3, int arg4, int arg5) {
        // jarde: not recovered: the recovery run for `run(IIIII)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method run(IIIII)I
        // @declaration an instance method of `NestedReturnB$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 3 5 7 9 12 14 15 18 20 21 22 24 25 27 29 31 33 34 37 39 41 42 44 45 46 49 50 51 54 55 56 59 61 62 64 65 68 70 71 74 76 78 81 82 83 86 87 88 91 92 93 96 99 100 101 104 105 106 109 110 111 114 116 117 120 122 124 125 127 128 129 132 134 135 137 138 141 144 147 149
        // the arms of the branch in block 12 do not meet at one join
    }
}
