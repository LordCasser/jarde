// jarde: presentation of `NestedReturnA$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class NestedReturnA$TestCls extends java.lang.Object {
    private int innerVisits;

    private int tailVisits;

    private int tailSum;

    private int earlyReturns;

    private int rolling;

    public NestedReturnA$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `NestedReturnA$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public int run(int arg1, int arg2, int arg3, int arg4, int arg5) {
        // jarde: not recovered: the recovery run for `run(IIIII)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method run(IIIII)I
        // @declaration an instance method of `NestedReturnA$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 3 4 6 8 11 13 14 17 19 20 21 23 24 26 28 30 32 33 36 38 40 41 43 44 45 48 49 50 53 54 55 58 60 61 63 64 67 69 71 74 76 78 81 82 83 86 87 88 91 92 93 96 99 100 101 104 105 106 109 110 111 114 116 117 120 122 124 125 127 128 129 132 134 135 137 138 141 144 147 149
        // the arms of the branch in block 11 do not meet at one join
    }
}
