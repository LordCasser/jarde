from pathlib import Path
import json,hashlib,importlib.util
BASE=Path('/private/tmp/jarde-testnestedloops5-parameterized-baseline-run-root-v1-20261018');OUT=Path(__file__).resolve().parent
PREP=Path('/private/tmp/jarde-testnestedloops5-parameterized-review-prep-root-v4-20261018')
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
a=load(PREP/'accept_baseline.py','old_auditor');h=load(PREP/'classfile_helpers.py','classhelper')
d=json.loads((BASE/'execution.json').read_text());profiles={(r['variant'],r['compiler'],r['profile']):r for r in d['class_profiles']};rows=[]
for r in d['jarde_cells']:
 raw=a.verify_pin(r['report'],'frozen method report');doc=json.loads(raw);profile=profiles[(r['variant'],r['compiler'],r['profile'])]
 parsed=h.parse_class_file(a.verify_pin(profile['target_pin'],'physical class'))
 for method in doc['methods']:
  identity=method['item']['identity'];key=(bytes(identity['name']).decode(),bytes(identity['descriptor']).decode());fact=next(q for q in parsed['methods'] if (q['name'],q['descriptor'])==key)
  report=method['outcome']['report'];summary={'identity':list(key),'source_map':report['source_map']}
  audit=a.map_audit(report['text'].encode('utf-8'),summary,fact,doc['class'],h)
  assert not audit['invalid'] and not audit['missing_physical_bcis'],audit
  rows.append({'key':[r['variant'],r['compiler'],r['profile'],r['evidence']],'method':list(key),'report':r['report'],'method_text_bytes':len(report['text'].encode()),**audit})
assert len(rows)==32
result={'status':'accepted_method_local_utf8_scope','baseline_receipt':a.pin(BASE/'execution.json'),'checker':a.pin(Path(__file__)),'method_configs':32,'rows':rows,'note':'Refines only source-map byte coordinates to method.outcome.report.text; the earlier whole-source upper bound was too broad. All actual frozen maps pass the precise method-local bound. No new current-source-closure assertion.'}
(OUT/'root-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'methods':len(rows)}))
