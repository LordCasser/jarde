#!/usr/bin/env python3
"""Prepared, serial CF-11 TestNestedLoops5 baseline collector. Invoke later with python -B."""
from __future__ import annotations

import argparse
import datetime
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
SOURCE = Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestNestedLoops5.java')
SOURCE_SHA256 = '0be29d145607e1be1d1426305739e6879d76defc8472dff7f6e82fcec0d83b6d'
DEPENDENCY_REFERENCE = Path('/private/tmp/jarde-nestedloops3-baseline-root-v1-20261018/execution.json')
CLI_PATH = Path('/private/tmp/jarde-prefixed-retry-final-focused-root-v5-20261018/candidate-cli')
CLI_SHA256 = '25adeaf312a7644c7d4c73191ef1264af0378cf78139d35a890377e3c86371ce'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA256 = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA256 = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
CLASS_NAME = 'jadx.tests.integration.loops.TestNestedLoops5$TestCls'
INTERNAL_CLASS = 'jadx/tests/integration/loops/TestNestedLoops5$TestCls'
EXPECTED_METHODS = {('<init>', '()V'), ('testFor', '()I'), ('check', '()V')}
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
RUNTIME_BOUND = Path('/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
JDK_LEGS = ('javac8', 'javac23')
EVIDENCE = ('default', 'all')


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def class_method_set(facts: dict) -> set[tuple[str, str]]:
    return {(row['name'], row['descriptor']) for row in facts['methods']}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--cli', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    out = args.out.resolve()
    cli = args.cli.resolve(strict=True)
    if out.exists():
        raise SystemExit(f'refusing existing output: {out}')
    if cli != CLI_PATH or sha256(cli) != CLI_SHA256:
        raise SystemExit('CLI must be the immutable TestNestedLoops5 baseline product 755fd2c84')
    if sha256(SOURCE) != SOURCE_SHA256:
        raise SystemExit('local TestNestedLoops5 source changed from its static pin')
    if root != ROOT.resolve():
        raise SystemExit(f'root differs from the pinned workspace: {root}')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('refusing to start while workspace target exists')
    if sha256(JADX) != JADX_SHA256 or sha256(JADX_JAR) != JADX_JAR_SHA256:
        raise SystemExit('JADX 1.5.6 executable/JAR pin mismatch')

    compare = load(root / 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py', 'nl5_compare')
    guard_path = root / GUARD_REL
    scanner_path = root / SCANNER_REL
    if compare.sha(guard_path) != GUARD_SHA256 or compare.sha(scanner_path) != SCANNER_SHA256:
        raise SystemExit('root guard/scanner source pin mismatch')
    guard = load(guard_path, 'nl5_guard')
    scanner = load(scanner_path, 'nl5_scanner')
    jdks, jdk_pin = compare.configured_jdks(root / JDK_MANIFEST_REL, JDK_MANIFEST_SHA256)

    reference = json.loads(DEPENDENCY_REFERENCE.read_text(encoding='utf-8'))
    classpath = reference['classpath']
    for row in [reference['harness_jar'], *reference['jar_pins']]:
        path = Path(row['path'])
        if compare.pin(path) != row:
            raise SystemExit(f'harness dependency pin mismatch: {path}')
    directory_pins = reference.get('directory_pins', reference.get('directory_pins_before'))
    if not directory_pins:
        raise SystemExit('dependency reference lacks pinned JADX build class trees')
    for folder, expected in directory_pins.items():
        actual = {p.relative_to(folder).as_posix(): compare.pin(p) for p in sorted(Path(folder).rglob('*.class'))}
        if actual != expected:
            raise SystemExit(f'JADX build classpath directory pin mismatch: {folder}')
    with zipfile.ZipFile(reference['harness_jar']['path']) as jar:
        if any('TestNestedLoops5' in name for name in jar.namelist()):
            raise SystemExit('pinned integration harness already contains the target class')

    out.mkdir(parents=True)
    raw = out / 'raw'
    raw.mkdir()
    guard.ROOT = root
    guard.OUT = raw
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, stdout_bytes: None
    if shutil.disk_usage(root).free < 5 * 1024**3:
        raise SystemExit('5 GiB free-space guard failed before collection')

    source_copy_dir = out / 'source'
    source_copy_dir.mkdir()
    source_copy = source_copy_dir / SOURCE.name
    shutil.copy2(SOURCE, source_copy)
    empty_sourcepath = out / 'empty-sourcepath'
    empty_sourcepath.mkdir()
    driver = out / 'driver-source/TestNestedLoops5Driver.java'
    driver.parent.mkdir(parents=True)
    shutil.copy2(Path(__file__).with_name('driver') / driver.name, driver)
    runtime_bound = out / RUNTIME_BOUND.name
    shutil.copy2(RUNTIME_BOUND, runtime_bound)
    classpath_text = os.pathsep.join(classpath)
    assertj = next(Path(row['path']) for row in reference['jar_pins'] if Path(row['path']).name.startswith('assertj-core-'))
    source_before = compare.source_closure(root)

    rows = []
    report = {
        'schema': 'cf11-original-testnestedloops5-baseline-v1', 'status': 'running',
        'source': compare.pin(SOURCE), 'source_copy': compare.pin(source_copy),
        'driver': compare.pin(driver), 'runtime_bound': compare.pin(runtime_bound),
        'dependency_reference': compare.pin(DEPENDENCY_REFERENCE), 'classpath': classpath,
        'harness_jar': reference['harness_jar'], 'jar_pins': reference['jar_pins'],
        'directory_pins': directory_pins, 'jdk_manifest': jdk_pin,
        'product_revision': '755fd2c84ecbe204d03f0ff608d3a711a1bea494',
        'cli': compare.pin(cli), 'jadx': compare.pin(JADX), 'jadx_jar': compare.pin(JADX_JAR),
        'guard': compare.pin(guard_path), 'scanner': compare.pin(scanner_path),
        'source_pins_before': source_before, 'commands': rows,
        'profiles': [], 'original_runtime': [], 'jarde_cells': [], 'jadx_cells': [],
        'method_inventory': {'expected': sorted([list(row) for row in EXPECTED_METHODS])},
        'ssa_note': 'The class-source CLI publishes method reports, region/fallback, and BCI source maps, not the private SSA table. If a first refusal is observed, capture its exact same-run SSA/canonical facts through the existing internal diagnostic/test seam; do not infer SSA from Code or source maps.',
        'notes': [
            'Complete upstream TestNestedLoops5.java is copied byte-for-byte; no method is removed.',
            'The javac8 outer-source attempt retains the previously observed major-55 integration-harness boundary as a separate command.',
            'Original oracle rows are observations from the target CodeSource-checked class under two JVM legs.',
            'No generated JADX/Jarde source is repaired or rewritten before it is saved.',
        ],
    }
    compare.write_json(out / 'execution.json', report)

    def command(argv, label, leg='javac23'):
        if (root / 'target').exists():
            raise RuntimeError('workspace target appeared during external-command collection')
        env = compare.clean_env(dict(os.environ), jdks[leg])
        env.update(guard.ENV_VALUES)
        env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(rows) + 1, [str(value) for value in argv], env)
        row['label'] = label
        row['tool_leg'] = leg
        rows.append(row)
        compare.write_json(out / 'execution.json', report)
        if row['guard_stop'] is not None:
            raise RuntimeError(f'guard stopped command {label}: {row["guard_stop"]}')
        return row

    def artifact(row, stream='stdout'):
        return compare.command_artifact(row, stream)

    def parse_target(target: Path, outer: Path, profile: str, compile_row: dict):
        facts = compare.parse_class(target)
        if (facts['major'] != 52 or class_method_set(facts) != EXPECTED_METHODS
                or any(method['code'] is None for method in facts['methods'])):
            raise RuntimeError(f'{profile}: target method inventory/class major mismatch: {facts}')
        outer_facts = compare.parse_class(outer)
        if outer_facts['major'] != 52 or outer_facts['class_name'] != 'jadx/tests/integration/loops/TestNestedLoops5':
            raise RuntimeError(f'{profile}: complete-source outer class identity/major mismatch: {outer_facts}')
        row = {'profile': profile, 'compile_command': compile_row['index'],
               'target': facts, 'outer': outer_facts, 'classes': str(target.parents[4])}
        report['profiles'].append(row)
        javap = command([jdks['javac23']['tools']['javap'], '-p', '-s', '-c', '-v', target],
                        'original-javap-' + profile)
        row['javap_command'] = javap['index']
        compare.write_json(out / 'execution.json', report)
        return row

    try:
        boundary_dir = out / 'javac8-boundary/classes'
        boundary_dir.mkdir(parents=True)
        boundary = command([
            jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
            '-encoding', 'UTF-8', '-proc:none', '-classpath', classpath_text,
            '-sourcepath', empty_sourcepath, '-d', boundary_dir, source_copy,
        ], 'original-javac8-harness-major-boundary', 'javac8')
        boundary_stderr = artifact(boundary, 'stderr')
        report['javac8_boundary'] = {
            'command': boundary['index'], 'exit_code': boundary['exit_code'],
            'class_outputs': [compare.pin(p) for p in sorted(boundary_dir.rglob('*.class'))],
            'observed_major_55_diagnostic': b'55.0' in boundary_stderr,
        }
        if boundary['exit_code'] == 0 or b'55.0' not in boundary_stderr:
            raise RuntimeError('javac8 harness-major boundary differed from the pinned TestNestedLoops3 precedent')

        for profile, debug in (('debug', '-g'), ('no-debug', '-g:none')):
            dest = out / profile / 'classes'
            dest.mkdir(parents=True)
            compiled = command([
                jdks['javac23']['tools']['javac'], '--release', '8', debug, '-encoding', 'UTF-8',
                '-proc:none', '-classpath', classpath_text, '-sourcepath', empty_sourcepath,
                '-d', dest, source_copy,
            ], 'original-compile-' + profile)
            if compiled['exit_code'] != 0:
                raise RuntimeError(f'javac23 source compile failed for {profile}; raw stderr retained')
            target = dest / 'jadx/tests/integration/loops/TestNestedLoops5$TestCls.class'
            outer = dest / 'jadx/tests/integration/loops/TestNestedLoops5.class'
            class_paths = sorted(p.relative_to(dest).as_posix() for p in dest.rglob('*.class'))
            if class_paths != [
                'jadx/tests/integration/loops/TestNestedLoops5$TestCls.class',
                'jadx/tests/integration/loops/TestNestedLoops5.class',
            ]:
                raise RuntimeError(f'{profile}: unexpected complete-source class outputs {class_paths}')
            record = parse_target(target, outer, profile, compiled)
            record['class_files'] = [compare.pin(target), compare.pin(outer)]
            record['method_code_facts'] = record['target']['methods']

        driver_classes = out / 'driver-classes'
        driver_classes.mkdir()
        driver_compile = command([
            jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
            '-encoding', 'UTF-8', '-proc:none', '-classpath', empty_sourcepath,
            '-sourcepath', empty_sourcepath, '-d', driver_classes, driver,
        ], 'compile-independent-reflection-driver', 'javac8')
        if driver_compile['exit_code'] != 0:
            raise RuntimeError('independent reflection driver did not compile; raw stderr retained')
        report['driver_classes'] = [compare.pin(p) for p in sorted(driver_classes.rglob('*.class'))]

        oracle_rows = []
        for profile in report['profiles']:
            for runtime in JDK_LEGS:
                roots = [profile['classes'], str(driver_classes), str(assertj)]
                run = command([
                    sys.executable, '-B', runtime_bound, '30', jdks[runtime]['tools']['java'],
                    '-Xverify:all', '-cp', os.pathsep.join(roots),
                    'TestNestedLoops5Driver', profile['classes'], 'core',
                ], f'original-runtime-{profile["profile"]}-{runtime}', runtime)
                stdout = artifact(run, 'stdout')
                if run['exit_code'] != 0:
                    raise RuntimeError(f'original JVM oracle failed: {profile["profile"]}/{runtime}')
                cell = {'profile': profile['profile'], 'runtime': runtime, 'command': run['index'],
                        'exit_code': run['exit_code'], 'classpath': roots,
                        'stdout_sha256': compare.sha(Path(run['streams']['stdout']['path']))}
                report['original_runtime'].append(cell)
                oracle_rows.append(stdout)
                compare.write_json(out / 'execution.json', report)
        if len(oracle_rows) != 4 or len(set(oracle_rows)) != 1:
            raise RuntimeError('four original double-JVM observations did not agree byte-for-byte')
        (out / 'original-oracle.stdout').write_bytes(oracle_rows[0])
        report['original_oracle'] = compare.pin(out / 'original-oracle.stdout')
        report['observed_oracle_stdout'] = oracle_rows[0].decode('utf-8', errors='replace')

        report['original_check_runtime'] = []
        check_oracles = []
        for profile in report['profiles']:
            for runtime in JDK_LEGS:
                roots = [profile['classes'], str(driver_classes), *classpath]
                run = command([
                    sys.executable, '-B', runtime_bound, '30', jdks[runtime]['tools']['java'],
                    '-Xverify:all', '-cp', os.pathsep.join(roots),
                    'TestNestedLoops5Driver', profile['classes'], 'check',
                ], f'original-check-runtime-{profile["profile"]}-{runtime}', runtime)
                stdout, stderr = artifact(run), artifact(run, 'stderr')
                cell = {'profile': profile['profile'], 'runtime': runtime, 'command': run['index'],
                        'exit_code': run['exit_code'], 'classpath': roots}
                if runtime == 'javac8':
                    if run['exit_code'] == 0 or b'UnsupportedClassVersionError' not in stderr or b'55.0' not in stderr:
                        raise RuntimeError('original check Java8 harness-major boundary differed')
                    cell['status'] = 'harness-major55-boundary-no-check-result'
                else:
                    if run['exit_code'] != 0:
                        raise RuntimeError('original check JVM23 failed')
                    check_oracles.append(stdout)
                    cell['status'] = 'observed-check-oracle'
                report['original_check_runtime'].append(cell)
                compare.write_json(out / 'execution.json', report)
        if len(check_oracles) != 2 or len(set(check_oracles)) != 1:
            raise RuntimeError('original check JVM23 observations differ')
        (out / 'original-check-oracle.stdout').write_bytes(check_oracles[0])
        report['original_check_oracle'] = compare.pin(out / 'original-check-oracle.stdout')

        wrong_root = command([
            sys.executable, '-B', runtime_bound, '30', jdks['javac23']['tools']['java'],
            '-Xverify:all', '-cp', os.pathsep.join([report['profiles'][0]['classes'], str(driver_classes), str(assertj)]),
            'TestNestedLoops5Driver', empty_sourcepath, 'core',
        ], 'driver-code-source-wrong-root-control')
        wrong_stderr = artifact(wrong_root, 'stderr')
        if wrong_root['exit_code'] == 0 or b'target loaded from' not in wrong_stderr:
            raise RuntimeError('CodeSource wrong-root guard did not reject the wrong expected root')
        report['wrong_root_control'] = {'command': wrong_root['index'], 'exit_code': wrong_root['exit_code']}

        version = command([JADX, '--version'], 'jadx-version')
        version_text = (artifact(version) + artifact(version, 'stderr')).decode('utf-8', errors='replace')
        if version['exit_code'] != 0 or '1.5.6' not in version_text:
            raise RuntimeError(f'JADX version does not match 1.5.6: {version_text!r}')
        for profile in report['profiles']:
            leg = profile['profile']
            classes = Path(profile['classes'])
            target = classes / 'jadx/tests/integration/loops/TestNestedLoops5$TestCls.class'
            bundle = out / (leg + '.jar')
            with zipfile.ZipFile(bundle, 'w') as jar:
                for path in sorted(classes.rglob('*.class')):
                    info = zipfile.ZipInfo(path.relative_to(classes).as_posix(), (1980, 1, 1, 0, 0, 0))
                    info.compress_type = zipfile.ZIP_STORED
                    jar.writestr(info, path.read_bytes())
            for form, inp, policy in (('child', target, 'single-class'), ('bundle-child', bundle, 'plain-jar')):
                for evidence in EVIDENCE:
                    argv = [CLI_PATH, 'class-source', '--input', inp, '--class', INTERNAL_CLASS,
                            '--policy', policy, '--release', '8', '--format', 'json']
                    if evidence == 'all':
                        argv += ['--evidence', 'all']
                    row = command(argv, f'jarde-{leg}-{form}-{evidence}')
                    raw_json = artifact(row)
                    dest = out / 'jarde' / leg / form / evidence
                    dest.mkdir(parents=True)
                    (dest / 'report.json').write_bytes(raw_json)
                    cell = {'profile': leg, 'input_form': form, 'evidence': evidence,
                            'command': row['index'], 'input': compare.pin(inp), 'exit_code': row['exit_code'],
                            'report': compare.pin(dest / 'report.json')}
                    try:
                        doc = json.loads(raw_json)
                        source_bytes = doc.get('text', '').encode('utf-8')
                        (dest / 'whole-source.java').write_bytes(source_bytes)
                        methods = []
                        for method in doc.get('methods', []):
                            identity = method.get('item', {}).get('identity', {})
                            key = (bytes(identity.get('name', [])).decode('utf-8'),
                                   bytes(identity.get('descriptor', [])).decode('utf-8'))
                            outcome = method.get('outcome', {})
                            rep = outcome.get('report', {})
                            methods.append({'identity': list(key), 'outcome_kind': outcome.get('kind'),
                                            'quality': rep.get('quality'), 'fallbacks': rep.get('fallbacks'),
                                            'regions': rep.get('regions'),
                                            'source_map': rep.get('source_map')})
                        cell.update({'methods': methods,
                                     'method_inventory_matches': {tuple(item['identity']) for item in methods} == EXPECTED_METHODS,
                                     'whole_source': compare.pin(dest / 'whole-source.java')})
                    except (ValueError, TypeError) as error:
                        cell['json_parse_error'] = str(error)
                    report['jarde_cells'].append(cell)
                    compare.write_json(out / 'execution.json', report)
            for form, inp in (('child', target), ('bundle', bundle)):
                dest = out / 'jadx' / leg / form
                row = command([JADX, '--config', 'none', '--threads-count', '1', '--no-res',
                               '--rename-flags', 'none', '-d', dest, inp], f'jadx-{leg}-{form}')
                sources = [compare.pin(path) for path in sorted(dest.rglob('*.java'))] if dest.exists() else []
                cell = {'profile': leg, 'input_form': form, 'command': row['index'],
                        'exit_code': row['exit_code'], 'sources': sources}
                report['jadx_cells'].append(cell)
                compare.write_json(out / 'execution.json', report)

        if compare.source_closure(root) != source_before:
            raise RuntimeError('workspace source changed while collecting; raw evidence retained')
        report['source_unchanged'] = True
        report['target_absent'] = not (root / 'target').exists()
        report['status'] = 'captured-pending-independent-review'
        return 0
    except BaseException as error:
        report['status'] = 'failed'
        report['error'] = str(error)
        raise
    finally:
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out / 'execution.json', report)
        shutil.copy2(__file__, out / 'collector.py')
        print(json.dumps({'status': report['status'], 'output': str(out),
                          'commands': len(rows), 'error': report.get('error')}))


def sha256(path: Path) -> str:
    import hashlib
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


if __name__ == '__main__':
    raise SystemExit(main())
