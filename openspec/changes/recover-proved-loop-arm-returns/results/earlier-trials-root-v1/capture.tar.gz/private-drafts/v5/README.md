# Private Reader test candidate v5

This directory is private preparation only. Nothing here has been compiled or applied to the shared workspace.

The test draft is based on the original proof candidate pinned in v3 `source-pin.txt` (region.rs SHA-256 `0729f1137d684a21db9c34253016188df664e81fe7b549c76bac9463bd07a68d`). The current workspace source was modified separately by root; this draft must not be overlaid onto it without reviewing the final delta.

`loop_arm_return_tests.rs` carries the focused-v4 corrections and a v5 positive candidate selector:

- Branch-offset variants use a Reader canonical CFG and normal-flow view even when Reader does not publish SSA for that rewritten class. The proof invocation explicitly reuses the original SSA and original region IDs at the same BCI/path as a proof-context metamorphism. It does not claim Complete SSA or JVM verification for the mutated class.
- The exception-boundary case uses the frozen complete `LoopTrySharedHandler.class`, selects a Reader-derived natural loop with an actual canonical exception edge, and checks unique normal entry/exit, scope, owner identities, path, and interval before invoking the consumer. Its manually assembled loop excludes the header from `Straight` body blocks, so the header is owned exactly once. The rejection is expected at the canonical edge census.
- Positive candidates now come from the full `recover(...)` region tree for each of the ten frozen original/A/B inputs. The selector accepts only a real Loop whose exact owners equal the natural-loop nodes plus the same-run certified terminal-return leaves, and whose recorded join matches. It does not reconstruct a child with `Frame::default()` and then infer the public AST.
- The positive test retains all ten source/compiler/debug inputs and prints the actual selected tail kind, gateway origins, and `ForHeader` presence for root's shape review. Root's focused-v4 public run passed all three integration tests, including A/B; its one earlier Reader-selector failure was from default-frame child-region reconstruction and has now been replaced with same-run full `recover(...)` tree selection.
- The exception control uses the complete frozen `LoopTrySharedHandler.loopTry(III)I` class. It finds a real natural loop incident to a real Exception edge and a corresponding actual recovered Loop. It flattens only the real normal-flow owner IDs into Straight while keeping the Loop's exact recovered tests, form, `ForHeader`, gateway origins, and exit; handler-only region owners are excluded from this proof context. This is explicitly a Region-context metamorphism: the classfile and canonical graph are unchanged, but it does not claim the flattened Region is the full source AST.

No output from the prior focused-v2/v4 failing tests is counted as validation for this private candidate. Root owns all Cargo/CLI checks and must resolve any compile/API findings.
