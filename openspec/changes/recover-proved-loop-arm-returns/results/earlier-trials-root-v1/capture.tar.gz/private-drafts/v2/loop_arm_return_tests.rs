//! Reader-backed test draft for crates/jarde-java/src/region/loop_arm_return_tests.rs.
//! Fixture paths are the final paths requested by root; this module has not been compiled.
use super::*;
use jarde_jvm::engine::analyze_method_ir;
use jarde_jvm::environment::ResolutionEnvironment;
use jarde_jvm::ir::{AnalysisStage, MethodAnalysisRequest};
use jarde_reader::artifact::{ArtifactInput, ArtifactSnapshot};
use jarde_reader::budget::{Budget, CancellationToken, Limits};
use jarde_reader::model::{
    ClassBytesId, Digest, JvmBytes, PhysicalClassLocation, PhysicalDefinitionId,
    PhysicalMethodId, PhysicalVariant,
};
use jarde_reader::view::{
    DelegationPolicy, LayoutMode, LoadDomain, LoadRoot, LoaderId, ModuleMode,
    MultiReleasePolicy, PhysicalScope, PhysicalView, RuntimeProfile, RuntimeUncertainty,
    RuntimeView,
};
use std::collections::BTreeSet;

const ORIGINAL_NESTED_EXCEPTION: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-prefixed-exceptional-retry-loops/original/debug/jadx/tests/integration/loops/TestNestedLoops3$TestCls.class"
);

const ORIGINAL_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-proved-loop-arm-returns/original/debug/classes/jadx/tests/integration/loops/TestNestedLoops5$TestCls.class"
);
const ORIGINAL_NO_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-proved-loop-arm-returns/original/no-debug/classes/jadx/tests/integration/loops/TestNestedLoops5$TestCls.class"
);
const A_JAVAC8_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-proved-loop-arm-returns/supplemental/A/javac8/debug/classes/NestedReturnA$TestCls.class"
);
const A_JAVAC8_NO_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-proved-loop-arm-returns/supplemental/A/javac8/no-debug/classes/NestedReturnA$TestCls.class"
);
const A_JAVAC23_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-proved-loop-arm-returns/supplemental/A/javac23/debug/classes/NestedReturnA$TestCls.class"
);
const A_JAVAC23_NO_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-proved-loop-arm-returns/supplemental/A/javac23/no-debug/classes/NestedReturnA$TestCls.class"
);
const B_JAVAC8_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-proved-loop-arm-returns/supplemental/B/javac8/debug/classes/NestedReturnB$TestCls.class"
);
const B_JAVAC8_NO_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-proved-loop-arm-returns/supplemental/B/javac8/no-debug/classes/NestedReturnB$TestCls.class"
);
const B_JAVAC23_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-proved-loop-arm-returns/supplemental/B/javac23/debug/classes/NestedReturnB$TestCls.class"
);
const B_JAVAC23_NO_DEBUG: &[u8] = include_bytes!(
    "../../../../tests/fixtures/recover-proved-loop-arm-returns/supplemental/B/javac23/no-debug/classes/NestedReturnB$TestCls.class"
);

fn reader_budget() -> Budget {
    Budget::new(Limits {
        input_bytes: 1 << 20,
        archive_entries: 100,
        entry_bytes: 1 << 20,
        read_bytes: 1 << 20,
        class_bytes: 1 << 20,
        attribute_bytes: 1 << 20,
        code_bytes: 1 << 20,
        result_items: 1 << 20,
        output_bytes: 1 << 20,
        class_headers: 100,
        method_bodies: 100,
        ir_items: 1 << 20,
        ir_edges: 1 << 20,
        analysis_steps: 1 << 20,
        normalization_clones: 1 << 20,
        nested_depth: 32,
        dependency_depth: 32,
        elapsed_millis: u64::MAX,
    })
}

fn proof_budget(steps: u64) -> Budget {
    Budget::new(Limits {
        analysis_steps: steps,
        elapsed_millis: u64::MAX,
        ..Limits::default()
    })
}

fn with_method<R>(
    bytes: &[u8],
    name: &[u8],
    descriptor: &[u8],
    f: impl FnOnce(
        &CanonicalCfg,
        &SsaTable,
        &MethodCodeFacts,
        &[CpEntryFacts],
        &NormalFlowView,
        &Operations,
    ) -> R,
) -> R {
    let mut budget = reader_budget();
    let snapshot = ArtifactSnapshot::open(ArtifactInput::bytes(bytes.to_vec()), &mut budget)
        .expect("whole frozen class parses");
    let definition = PhysicalDefinitionId {
        location: PhysicalClassLocation::StandaloneRoot {
            snapshot: snapshot.id().clone(),
        },
        class_bytes: ClassBytesId {
            digest: Digest(blake3::hash(bytes).to_hex().to_string()),
            length: u64::try_from(bytes.len()).expect("fixture length fits u64"),
        },
        variant: PhysicalVariant::Base,
    };
    let domain = LoadDomain {
        loader: LoaderId("app".into()),
        parent_loader: None,
        delegation: DelegationPolicy::ParentFirst,
        roots: vec![LoadRoot::StandaloneClass {
            snapshot: snapshot.id().clone(),
        }],
        module_mode: ModuleMode::ClassPath,
        external_override: RuntimeUncertainty::None,
        runtime_transformation: RuntimeUncertainty::None,
    };
    let analysis = analyze_method_ir(
        &[snapshot.clone()],
        &MethodAnalysisRequest {
            environment: ResolutionEnvironment {
                runtime: RuntimeView {
                    physical: PhysicalView {
                        snapshot: snapshot.id().clone(),
                        scope: PhysicalScope::SnapshotAll,
                    },
                    profile: RuntimeProfile {
                        java_release: 8,
                        multi_release: MultiReleasePolicy::Disabled,
                        layout: LayoutMode::Generic,
                    },
                    load_domain: domain.clone(),
                },
                domains: vec![domain],
                providers: Vec::new(),
            },
            method: PhysicalMethodId {
                owner: definition,
                name: JvmBytes(name.to_vec()),
                descriptor: JvmBytes(descriptor.to_vec()),
            },
            stages: AnalysisStage::ALL.to_vec(),
        },
        &mut budget,
    )
    .expect("Reader analyzes the exact original method");
    let ir = analysis.ir();
    let canonical = ir.canonical().expect("real canonical CFG");
    let ssa = ir.ssa().expect("real SSA");
    let code = ir.code().expect("real Code facts");
    let pool = ir.constant_pool();
    let operations = Operations::of(code, pool);
    let mut view_budget = reader_budget();
    let view = NormalFlowView::build(canonical, &mut view_budget)
        .expect("real normal-flow projection");
    f(canonical, ssa, code, pool, &view, &operations)
}

fn walker<'a>(
    canonical: &'a CanonicalCfg,
    view: &'a NormalFlowView,
    ssa: &'a SsaTable,
    code: &'a MethodCodeFacts,
    pool: &'a [CpEntryFacts],
    operations: &'a Operations,
    chains: &'a crate::concat::Plan,
    sites: &'a crate::init::Sites,
    budget: &'a mut Budget,
) -> Walker<'a> {
    Walker {
        canonical,
        view,
        ssa,
        operations,
        pool,
        chains,
        sites,
        code,
        method_synchronized: Some(false),
        has_reachable_explicit_monitor: false,
        return_is_boolean: false,
        handlers: &code.exception_handlers,
        profile: &crate::pass::JAVA_8,
        budget,
        catch_joins: BTreeSet::new(),
        loop_catch_terminal_owners: Vec::new(),
        fragmented: None,
        excluded_edge_nodes: BTreeSet::new(),
        visited: BTreeSet::new(),
        unclosed_tail_at: None,
        own_monitor: None,
        depth: 0,
    }
}

struct Candidate {
    arm: Region,
    branch: CanonicalBlockId,
    entry: CanonicalBlockId,
    join: CanonicalBlockId,
    header: CanonicalBlockId,
    owners: BTreeSet<usize>,
    return_nodes: BTreeSet<usize>,
}

fn loop_has_return_latch_tail(region: &Region) -> bool {
    let Region::Loop { body, .. } = region else { return false };
    matches!(
        body.last(),
        Some(Region::If { join: None, then_arm, else_arm, .. }
            | Region::CompoundIf { join: None, then_arm, else_arm, .. })
            if matches!(then_arm.as_ref(), Region::Straight { .. })
                && matches!(else_arm.as_ref(), Region::Straight { .. })
    )
}

fn real_candidate(
    canonical: &CanonicalCfg,
    ssa: &SsaTable,
    code: &MethodCodeFacts,
    pool: &[CpEntryFacts],
    view: &NormalFlowView,
    operations: &Operations,
    chains: &crate::concat::Plan,
    sites: &crate::init::Sites,
) -> Candidate {
    let mut choices = Vec::new();
    for block in canonical.blocks() {
        let header = block.id();
        let Some(header_node) = view.index_of(header) else { continue };
        let Some(natural) = view.loop_entered_at(header_node) else { continue };
        let Some(join_node) = view.successors(header_node).into_iter()
            .find(|successor| !natural.blocks().contains(successor)) else { continue };
        let Some(join) = view.id_of(join_node).cloned() else { continue };
        let mut budget = proof_budget(1 << 20);
        let mut w = walker(canonical, view, ssa, code, pool, operations, &chains, &sites, &mut budget);
        let frame = Frame::default();
        let returns = w.loop_terminal_returns(natural.blocks(), Some(join_node), &frame)
            .expect("real terminal-return census completes");
        if returns.is_empty() { continue }
        let (regions, _) = w.loop_region(header, header_node, &frame)
            .expect("real child loop region completes");
        let [arm @ Region::Loop { exit: Some(actual_join), .. }] = regions.as_slice() else { continue };
        if actual_join != &join || !loop_has_return_latch_tail(arm) { continue }
        let owners: BTreeSet<_> = arm.blocks().iter()
            .filter_map(|id| view.index_of(id)).collect();
        let incoming: Vec<_> = canonical.edges().iter()
            .filter(|edge| edge.to() == header && !owners.contains(&view.index_of(edge.from()).unwrap_or(usize::MAX)))
            .map(|edge| edge.from().clone()).collect();
        let [entry] = incoming.as_slice() else { continue };
        let entry_node = view.index_of(entry).expect("canonical entry identity");
        let branches: Vec<_> = view.predecessors(entry_node).into_iter()
            .filter_map(|node| view.id_of(node).cloned())
            .filter(|source| view.successors(view.index_of(source).expect("branch node"))
                .iter().any(|successor| view.id_of(*successor) == Some(&join)))
            .collect();
        let [branch] = branches.as_slice() else { continue };
        choices.push((owners.len(), Candidate {
            arm: (*arm).clone(), branch: branch.clone(), entry: entry.clone(), join,
            header: header.clone(), owners, return_nodes: returns,
        }));
    }
    choices.sort_by_key(|(count, _)| *count);
    choices.into_iter().next().expect("one exact child return/latch loop is present")
}

fn run_proof<'a>(
    candidate: &Candidate,
    canonical: &'a CanonicalCfg,
    view: &'a NormalFlowView,
    ssa: &'a SsaTable,
    code: &'a MethodCodeFacts,
    pool: &'a [CpEntryFacts],
    operations: &'a Operations,
    chains: &'a crate::concat::Plan,
    sites: &'a crate::init::Sites,
    budget: &'a mut Budget,
    frame: &Frame,
    arm: &Region,
    entry: &CanonicalBlockId,
    join: &CanonicalBlockId,
) -> Result<Option<CanonicalBlockId>, StopReason> {
    let mut w = walker(canonical, view, ssa, code, pool, operations, chains, sites, budget);
    w.visited = candidate.owners.clone();
    w.loop_arm_join_source(arm, &candidate.branch, entry, join, frame)
}

#[test]
fn reader_loop_arm_return_leaf_and_latch_are_one_exact_owner_set() {
    for (bytes, name, descriptor) in [
        (ORIGINAL_DEBUG, b"testFor".as_slice(), b"()I".as_slice()),
        (ORIGINAL_NO_DEBUG, b"testFor".as_slice(), b"()I".as_slice()),
        (A_JAVAC8_DEBUG, b"run".as_slice(), b"(IIIII)I".as_slice()),
        (A_JAVAC8_NO_DEBUG, b"run".as_slice(), b"(IIIII)I".as_slice()),
        (A_JAVAC23_DEBUG, b"run".as_slice(), b"(IIIII)I".as_slice()),
        (A_JAVAC23_NO_DEBUG, b"run".as_slice(), b"(IIIII)I".as_slice()),
        (B_JAVAC8_DEBUG, b"run".as_slice(), b"(IIIII)I".as_slice()),
        (B_JAVAC8_NO_DEBUG, b"run".as_slice(), b"(IIIII)I".as_slice()),
        (B_JAVAC23_DEBUG, b"run".as_slice(), b"(IIIII)I".as_slice()),
        (B_JAVAC23_NO_DEBUG, b"run".as_slice(), b"(IIIII)I".as_slice()),
    ] {
        with_method(bytes, name, descriptor, |canonical, ssa, code, pool, view, operations| {
            let chains = crate::concat::plan(ssa, operations, &crate::build::FieldCopies::default());
            let sites = crate::init::Sites::empty();
            let candidate = real_candidate(canonical, ssa, code, pool, view, operations, &chains, &sites);
            assert!(!candidate.return_nodes.is_empty());
            let header = view.index_of(&candidate.header).expect("real header");
            let natural = view.loop_entered_at(header).expect("same natural loop");
            assert!(candidate.owners.is_superset(natural.blocks()));
            assert_eq!(candidate.owners.difference(natural.blocks()).copied().collect::<BTreeSet<_>>(), candidate.return_nodes);
            assert!(candidate.return_nodes.iter().all(|node| view.successors(*node).is_empty()));
            let mut scope = candidate.owners.clone();
            scope.extend(candidate.return_nodes.iter().copied());
            let mut frame = Frame::default();
            frame.scope = Some(scope);
            let mut budget = proof_budget(1 << 20);
            let actual = run_proof(&candidate, canonical, view, ssa, code, pool, operations,
                &chains, &sites, &mut budget, &frame, &candidate.arm, &candidate.entry, &candidate.join)
                .expect("proof completes")
                .expect("exact return/latch child joins parent arm");
            assert_eq!(actual, candidate.header, "the decoded normal exit source is the loop test block");
            let Region::Loop { gateway_origins, for_header, .. } = &candidate.arm else { unreachable!() };
            assert!(!gateway_origins.is_empty(), "physical latch gateway remains represented");
            assert!(for_header.is_some(), "the original and supplemental children retain ForHeader evidence");
        });
    }
}

#[test]
fn reader_loop_arm_return_proof_refuses_missing_leaf_scope_wrong_entry_and_latch() {
    with_method(ORIGINAL_DEBUG, b"testFor", b"()I", |canonical, ssa, code, pool, view, operations| {
        let chains = crate::concat::plan(ssa, operations, &crate::build::FieldCopies::default());
        let sites = crate::init::Sites::empty();
        let candidate = real_candidate(canonical, ssa, code, pool, view, operations, &chains, &sites);
        let mut scope = candidate.owners.clone();
        scope.extend(candidate.return_nodes.iter().copied());
        let mut incomplete = Frame::default();
        let leaf = *candidate.return_nodes.iter().next().expect("certified terminal return");
        scope.remove(&leaf);
        incomplete.scope = Some(scope);
        let mut budget = proof_budget(1 << 20);
        assert!(run_proof(&candidate, canonical, view, ssa, code, pool, operations,
            &chains, &sites, &mut budget, &incomplete, &candidate.arm, &candidate.entry, &candidate.join)
            .expect("missing frame evidence is a refusal") .is_none());

        let mut frame = Frame::default();
        frame.scope = Some(candidate.owners.union(&candidate.return_nodes).copied().collect());
        let mut budget = proof_budget(1 << 20);
        assert!(run_proof(&candidate, canonical, view, ssa, code, pool, operations,
            &chains, &sites, &mut budget, &frame, &candidate.arm, &candidate.branch, &candidate.join)
            .expect("wrong actual entry is a refusal").is_none());

        let mut duplicate_owner = candidate.arm.clone();
        let Region::Loop { body, .. } = &mut duplicate_owner else { unreachable!() };
        let duplicate_added = match body.last_mut().expect("final return/latch branch") {
            Region::If { prefix, branch, join: None, .. } => {
                prefix.push(branch.clone());
                true
            }
            Region::CompoundIf { prefix, tests, join: None, .. } => {
                let Some(test) = tests.last() else { panic!("compound tail has a final test") };
                prefix.push(test.block.clone());
                true
            }
            _ => false,
        };
        assert!(duplicate_added, "the real tail branch permits a same-IR duplicate-owner mutation");
        let mut budget = proof_budget(1 << 20);
        assert!(run_proof(&candidate, canonical, view, ssa, code, pool, operations,
            &chains, &sites, &mut budget, &frame, &duplicate_owner, &candidate.entry, &candidate.join)
            .expect("duplicate physical owner is a refusal").is_none());

        let mut wrong_target = candidate.arm.clone();
        let Region::Loop { header, .. } = &mut wrong_target else { unreachable!() };
        *header = candidate.join.clone();
        let mut budget = proof_budget(1 << 20);
        assert!(run_proof(&candidate, canonical, view, ssa, code, pool, operations,
            &chains, &sites, &mut budget, &frame, &wrong_target, &candidate.entry, &candidate.join)
            .expect("wrong natural-loop target is a refusal").is_none());

        let mut wrong_gateway = candidate.arm.clone();
        let Region::Loop { gateway_origins, .. } = &mut wrong_gateway else { unreachable!() };
        assert_eq!(gateway_origins.len(), 1);
        gateway_origins[0] = gateway_origins[0].wrapping_add(1);
        let mut budget = proof_budget(1 << 20);
        assert!(run_proof(&candidate, canonical, view, ssa, code, pool, operations,
            &chains, &sites, &mut budget, &frame, &wrong_gateway, &candidate.entry, &candidate.join)
            .expect("wrong physical latch gateway is a refusal").is_none());
    });
}

#[test]
fn reader_compound_tail_requires_return_certificate_but_legacy_if_still_works() {
    with_method(ORIGINAL_DEBUG, b"testFor", b"()I", |canonical, ssa, code, pool, view, operations| {
        let chains = crate::concat::plan(ssa, operations, &crate::build::FieldCopies::default());
        let sites = crate::init::Sites::empty();
        let candidate = real_candidate(canonical, ssa, code, pool, view, operations, &chains, &sites);
        let header_node = view.index_of(&candidate.header).expect("real child header");
        let Region::Loop { body, gateway_origins, .. } = &candidate.arm else { unreachable!() };
        let tail = body.last().expect("final child tail");
        let [gateway] = gateway_origins.as_slice() else { panic!("one real gateway") };

        // If the actual Reader tail is an If, exercise its pre-existing no-ForHeader path with
        // the same block/SSA/normal-flow facts and no new terminal-return certificate.
        if matches!(tail, Region::If { .. }) {
            let mut budget = proof_budget(1 << 20);
            let mut w = walker(canonical, view, ssa, code, pool, operations, &chains, &sites, &mut budget);
            assert_eq!(
                w.implicit_tail_latch_origin(header_node, body, None, None)
                    .expect("legacy If proof completes without a return certificate"),
                Some(*gateway),
            );
        }

        // Exercise the CompoundIf variant gate over Reader-derived branch/arm identities. If
        // Reader already produced CompoundIf, retain it exactly. Otherwise re-express the same
        // one physical If test as a one-test CompoundIf solely as a private context mutation;
        // this is not a classfile or JVM-validity claim.
        let compound_body = match tail {
            Region::CompoundIf { .. } => vec![tail.clone()],
            Region::If { prefix, branch, branch_bci, then_arm, else_arm, .. } => {
                let successors = view.successor_ids(branch);
                assert_eq!(successors.len(), 2, "the original branch has two real successors");
                vec![Region::CompoundIf {
                    prefix: prefix.clone(),
                    tests: vec![CompoundTest {
                        block: branch.clone(),
                        branch_bci: *branch_bci,
                        then: successors[0].clone(),
                        otherwise: successors[1].clone(),
                    }],
                    condition: CompoundCondition::Test(0),
                    then_arm: then_arm.clone(),
                    else_arm: else_arm.clone(),
                    join: None,
                }]
            }
            _ => panic!("bounded return/latch candidate has an If tail"),
        };
        let mut mutated_body = body[..body.len() - 1].to_vec();
        mutated_body.extend(compound_body);
        let mut budget = proof_budget(1 << 20);
        let mut w = walker(canonical, view, ssa, code, pool, operations, &chains, &sites, &mut budget);
        assert_eq!(
            w.implicit_tail_latch_origin(header_node, &mutated_body, None, None)
                .expect("missing CompoundIf certificate is an ordinary refusal"),
            None,
            "CompoundIf must not inherit the legacy no-ForHeader allowance",
        );
    });
}

#[test]
fn real_exception_edge_incident_to_a_loop_refuses_the_arm_proof() {
    with_method(ORIGINAL_NESTED_EXCEPTION, b"test", b"(I)I", |canonical, ssa, code, pool, view, operations| {
        let chains = crate::concat::plan(ssa, operations, &crate::build::FieldCopies::default());
        let sites = crate::init::Sites::empty();
        let mut selected = None;
        for block in canonical.blocks() {
            let header = block.id();
            let Some(header_node) = view.index_of(header) else { continue };
            let Some(natural) = view.loop_entered_at(header_node) else { continue };
            let owner_ids: BTreeSet<_> = natural.blocks().iter()
                .filter_map(|node| view.id_of(*node).cloned()).collect();
            if owner_ids.len() != natural.blocks().len() { continue }
            let exceptional: Vec<_> = canonical.edges().iter().filter(|edge| {
                matches!(edge.kind(), CanonicalEdgeKind::Exception { .. })
                    && (owner_ids.contains(edge.from()) || owner_ids.contains(edge.to()))
            }).collect();
            if exceptional.is_empty() { continue }
            let entries: Vec<_> = canonical.edges().iter().filter(|edge| {
                edge.kind() == CanonicalEdgeKind::Normal
                    && !owner_ids.contains(edge.from()) && owner_ids.contains(edge.to())
            }).collect();
            let [entry] = entries.as_slice() else { continue };
            if entry.to() != header { continue }
            let exits: Vec<_> = canonical.edges().iter().filter(|edge| {
                edge.kind() == CanonicalEdgeKind::Normal
                    && owner_ids.contains(edge.from()) && !owner_ids.contains(edge.to())
            }).collect();
            let [exit] = exits.as_slice() else { continue };
            let entry_source = entry.from();
            let join = exit.to();
            if owner_ids.iter().any(|id| id.path() != entry_source.path())
                || join.path() != entry_source.path()
            { continue }
            let branches: Vec<_> = canonical.edges().iter().filter(|edge| {
                edge.kind() == CanonicalEdgeKind::Normal
                    && edge.to() == entry_source && !owner_ids.contains(edge.from())
            }).map(|edge| edge.from().clone()).collect();
            let branch = if let [branch] = branches.as_slice() {
                branch.clone()
            } else if owner_ids.iter().all(|id| id.bci() > entry_source.bci() && id.bci() < join.bci()) {
                entry_source.clone()
            } else { continue };
            if branch.path() != entry_source.path()
                || (&branch == entry_source
                    && !owner_ids.iter().all(|id| id.bci() > branch.bci() && id.bci() < join.bci()))
            { continue }
            selected = Some((header.clone(), (*entry_source).clone(), (*join).clone(), branch, owner_ids, exceptional.len()));
            break;
        }
        let (header, entry, join, branch, owners, exceptional_rows) =
            selected.expect("a Reader natural loop has one normal entry/exit and an incident exception row");
        assert!(exceptional_rows > 0);
        let owner_nodes: BTreeSet<_> = owners.iter().map(|id| view.index_of(id).expect("real owner node")).collect();
        let mut body_blocks: Vec<_> = owners.iter().cloned().collect();
        body_blocks.sort();
        let candidate = Region::Loop {
            header,
            tests: Vec::new(),
            test_operator: None,
            form: LoopForm::While,
            for_header: None,
            body: vec![Region::Straight { blocks: body_blocks }],
            exit: Some(join.clone()),
            gateway_origins: Vec::new(),
        };
        let mut frame = Frame::default();
        frame.scope = Some(owner_nodes.clone());
        let mut budget = proof_budget(1 << 20);
        let mut w = walker(canonical, view, ssa, code, pool, operations, &chains, &sites, &mut budget);
        w.visited = owner_nodes;
        assert!(w.loop_arm_join_source(&candidate, &branch, &entry, &join, &frame)
            .expect("real exceptional incidence is an ordinary refusal").is_none());
    });
}

#[test]
fn reader_loop_arm_return_proof_publishes_no_partial_claim_on_budget_or_stop() {
    with_method(ORIGINAL_DEBUG, b"testFor", b"()I", |canonical, ssa, code, pool, view, operations| {
        let chains = crate::concat::plan(ssa, operations, &crate::build::FieldCopies::default());
        let sites = crate::init::Sites::empty();
        let candidate = real_candidate(canonical, ssa, code, pool, view, operations, &chains, &sites);
        let mut frame = Frame::default();
        frame.scope = Some(candidate.owners.union(&candidate.return_nodes).copied().collect());
        let mut saw_late_budget = false;
        for limit in 0..512 {
            let mut budget = proof_budget(limit);
            let mut w = walker(canonical, view, ssa, code, pool, operations, &chains, &sites, &mut budget);
            w.visited = candidate.owners.clone();
            let initial = w.visited.clone();
            let result = w.loop_arm_join_source(&candidate.arm, &candidate.branch,
                &candidate.entry, &candidate.join, &frame);
            if matches!(result, Err(StopReason::Budget {
                dimension: CountedBudgetDimension::AnalysisSteps, ..
            })) && w.budget.usage().analysis_steps > 0 {
                assert_eq!(w.visited, initial);
                assert!(w.catch_joins.is_empty());
                assert!(w.loop_catch_terminal_owners.is_empty());
                assert!(w.fragmented.is_none());
                assert_eq!(w.unclosed_tail_at, None);
                saw_late_budget = true;
                break;
            }
            if result.is_ok_and(|value| value.is_some()) { break; }
        }
        assert!(saw_late_budget, "positive-charge proof scan has a budget stop");

        // These are explicitly proof-entry stop checks after Reader preparation. They are not
        // represented as mid-proof asynchronous cancellation/deadline evidence.
        let token = CancellationToken::new();
        let mut budget = Budget::with_cancellation_token(Limits {
            analysis_steps: u64::MAX, elapsed_millis: u64::MAX, ..Limits::default()
        }, token.clone());
        token.cancel();
        let mut w = walker(canonical, view, ssa, code, pool, operations, &chains, &sites, &mut budget);
        w.visited = candidate.owners.clone();
        assert!(matches!(w.loop_arm_join_source(&candidate.arm, &candidate.branch,
            &candidate.entry, &candidate.join, &frame),
            Err(StopReason::Cancelled { .. })));
        assert_eq!(w.visited, candidate.owners);

        let mut budget = Budget::new(Limits {
            analysis_steps: u64::MAX, elapsed_millis: 1, ..Limits::default()
        });
        std::thread::sleep(std::time::Duration::from_millis(3));
        let mut w = walker(canonical, view, ssa, code, pool, operations, &chains, &sites, &mut budget);
        w.visited = candidate.owners.clone();
        assert!(matches!(w.loop_arm_join_source(&candidate.arm, &candidate.branch,
            &candidate.entry, &candidate.join, &frame),
            Err(StopReason::Interrupted { .. })));
        assert_eq!(w.visited, candidate.owners);
    });
}
