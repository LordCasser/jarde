# Private NL5 loop-arm return candidate v3

Status: private, uncompiled test and patch preparation. No shared files were edited; no Cargo/JDK/CLI/Git/network command was run. v2 remains frozen and unchanged.

The production patch is based on `crates/jarde-java/src/region.rs` SHA-256 `0729f1137d684a21db9c34253016188df664e81fe7b549c76bac9463bd07a68d`. It carries forward v2's removal of the owner-set free helper, exact inline Reader-node owner checks only on the new certified path, charge/poll for those added scans, and the split If/CompoundIf eligibility gate. It also refuses a final no-join return/latch tail immediately when the same-run return census is empty. That check applies only to the newly opened final-return-tail path and leaves the old no-return path intact.

`loop_arm_return_tests.rs` adds three kinds of Reader-backed context controls:

- The existing frozen NL5 original/A/B positive fixtures continue to drive `loop_arm_join_source` with their real canonical/SSA/normal-flow facts.
- A private byte-variant test reads the original `testFor()I` Code span from Reader, changes only one existing short conditional's signed offset for each of `6→29`, `11→21`, and `26→37`, and reparses each entire class through Reader. Before calling the consumer it asserts that the rewritten normal canonical edge exists, and respectively checks shared return predecessor, external entry into an original owner, or an additional owner-to-join exit. The proof uses original region/physical IDs against the mutated same-method Reader graph and must refuse. These are same-physical-BCI proof metamorphisms, not claimed JVM-valid classes or Java runtime controls. The upstream root must confirm the exact offsets still name the intended physical blocks and that Reader reaches Complete.
- A foreign-clone-context test obtains a cloned switch `CanonicalBlockId` from the existing v49 JSR fixture and passes it as the branch context to the NL5 consumer while keeping the actual NL5 arm/entry/join. It asserts a nonempty clone path distinct from all NL5 owner paths and expects the consumer's actual path gate to refuse. This is explicitly a cross-fixture proof-context metamorphism, not a same-method JVM input or whole jsr-loop recovery.

The exception-row test now excludes the loop header from the body `Straight` blocks, since `Region::Loop.blocks()` contributes the header itself. It asserts the region block multiset equals the real natural-loop owner set with no duplicates, all path/scope/visited/BCI premises, one normal external entry, one normal exit, and no gateway origin before expecting refusal for the real incident Exception row. No canonical edge is fabricated.

The missing-certificate test checks a direct Reader-backed CompoundIf context refusal, and the existing If no-ForHeader path is retained where the source fixture supplies an If tail. Cancellation/deadline remain explicitly proof-entry checks; the AnalysisSteps sweep is the actual late positive-charge stop. No new public API/test seam is introduced.

Patch generation: run `python3 -B make_patch.py` only to read shared `region.rs` and refresh files in this private directory. Nothing here has been compiled or run, so every test and semantic expectation remains pending root validation.
