# 早期候选与测试准备失败

v1为测试helper tuple类型错误；v2内部7测4通过/3准备假设失败；v3公开late-budget通过、另2已Structured但误用库essential无map的契约；v4公开3通过/内部同4-3；v5仅fmt let-else分号失败（已交v5私有稿又被原agent修改，root发现后强制冻结/新版本）；v6库479中477通过，实际完整Loop证实原If/A-B Straight；v7删除Compound扩张后478通过，只剩异常样例选择器。v8才是完整focused通过，另归档。

每轮raw/来源pins/实际命令及finally exact clean均保留。试验期未为每次root格式化后的测试源做逐文件字节快照；private-drafts是对应交付目录当前冻结内容，不能自动当每轮root应用后完全相同的测试源。尤其v5最初声明的56e4b…被agent覆盖，归档只保留后续02a4…冻结稿，不伪造旧稿。每轮实际来源以其receipt.source_before pins为准。所有CLI二进制不入包，仅保留真实pin，不能作为产品验收CLI。

失败不是产品恢复均失败：真实public恢复质量和测试取证/格式/契约错误严格按各轮解释。原should_panic门的panic不是额外失败，数量取Rust实际test summary。
