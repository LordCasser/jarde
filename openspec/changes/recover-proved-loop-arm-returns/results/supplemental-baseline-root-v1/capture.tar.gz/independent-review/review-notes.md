# 补充基线独立复核

root-v4实际通过65命令/130raw、16原VM/48case、8错误CodeSource负控、16Jarde/8JADX、全部32方法来源。所有物理BCI均有来源；checker允许显式报告缺口但本次实际缺口为0。fullsource重编尚另验。

Luna未执行v1草稿把字段数组当dict、将BLAKE3等同SHA256，root静态审读纠正。root-v2第一次实际checker在fixture来源文件名/A-B键与复制路径不等处拒绝；root-v3第二次在运行argv错误使用[-2]而非实际末尾CodeSource root处拒绝。随后root也按实际JSON修正access_flags及artifact.binding.method。两次拒绝只属于审查器，不是Jarde产品执行失败。旧脚本保留，未声称它们通过；终态收据在acceptance.json。

Python独立SHA256绑定实际class字节；BLAKE3只核公开物理owner完整相等、位置/长度/表示，未由Python独立重算。后续Rust公共门重算BLAKE3。
