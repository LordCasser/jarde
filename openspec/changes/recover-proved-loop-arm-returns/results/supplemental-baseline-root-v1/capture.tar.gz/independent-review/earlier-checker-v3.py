#!/usr/bin/env python3
"""Independent read-only acceptance of the parameterized NL5 baseline receipt."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASE = Path('/private/tmp/jarde-testnestedloops5-parameterized-baseline-run-root-v1-20261018')
PREP = Path('/private/tmp/jarde-testnestedloops5-parameterized-baseline-prep-luna-v1-20261018')
CLASS_HELPER = Path('/private/tmp/jarde-testnestedloops5-parameterized-review-prep-root-v3-20261018/classfile_helpers.py')
COMPARE_REL = Path('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
COMPARE_SHA = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
NL5_SOURCE = Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestNestedLoops5.java')
NL5_SHA = '0be29d145607e1be1d1426305739e6879d76defc8472dff7f6e82fcec0d83b6d'
EXPECTED_METHODS = {('<init>', '()V'), ('run', '(IIIII)I')}
EXPECTED_FIELDS = {'innerVisits', 'tailVisits', 'tailSum', 'earlyReturns', 'rolling'}
VARIANTS = ('A', 'B')
COMPILERS = ('javac8', 'javac23')
PROFILES = ('debug', 'no-debug')


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def pin(path: Path) -> dict:
    path = path.resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def verify_pin(record: dict, label: str) -> bytes:
    path = Path(record['path'])
    need(path.is_absolute() and path.is_file(), f'{label}: missing {path}')
    data = path.read_bytes()
    need(record == {'path': str(path.resolve()), 'bytes': len(data), 'sha256': sha(data)},
         f'{label}: pin mismatch')
    return data


def command_bytes(row: dict, channel: str, compare) -> bytes:
    return compare.command_artifact(row, channel)


def identity(method: dict) -> tuple[str, str]:
    return method['name'], method['descriptor']


def facts_from_class(path: Path, class_pin: dict, receipt_facts: dict, helper) -> dict:
    raw = verify_pin(class_pin, f'class {path}')
    need(Path(class_pin['path']) == path.resolve(), 'class pin path differs from the class profile')
    parsed = helper.parse_class_file(raw)
    need(parsed['major'] == 52 and receipt_facts['major'] == 52, f'{path}: not Java 8 major 52')
    need(parsed['class_name'] == receipt_facts['class_name'], f'{path}: class name differs from receipt')
    need(parsed['class_name'] == path.stem.replace('$', '$'), f'{path}: internal name differs from class file path')
    receipt_fields = {tuple(f) for f in receipt_facts['fields']}
    parsed_fields = {(f['name'], f['descriptor'], f['access']) for f in parsed['fields']}
    need(parsed_fields == receipt_fields, f'{path}: field rows differ from parsed class bytes')
    receipt_methods = {(m['name'], m['descriptor']): m for m in receipt_facts['methods']}
    parsed_methods = {(m['name'], m['descriptor']): m for m in parsed['methods']}
    need(parsed_methods.keys() == receipt_methods.keys(), f'{path}: method inventory differs from class bytes')
    for key, parsed_method in parsed_methods.items():
        received = receipt_methods[key]
        need(parsed_method['access'] == received['access'], f'{path} {key}: access flags differ')
        code = parsed_method['code']
        need(code is not None and received['code'] is not None, f'{path} {key}: method has no Code')
        received_code = received['code']
        for attr in ('max_stack', 'max_locals', 'code_length', 'code_hex', 'rows', 'bcis'):
            need(code[attr] == received_code[attr], f'{path} {key}: Code {attr} differs from physical bytes')
        code_bytes = bytes.fromhex(code['code_hex'])
        need(len(code_bytes) == code['code_length'], f'{path} {key}: Code length mismatch')
        need(code['bcis'] == helper.decode_bcis(code_bytes), f'{path} {key}: BCI table is not physical')
    return parsed


def map_audit(source: bytes, method: dict, fact: dict, owner: dict, helper) -> dict:
    code = fact['code']
    physical = set(code['bcis'])
    mapped: set[int] = set()
    invalid: list[str] = []
    boundaries = helper.byte_boundaries(source)
    source_map = method.get('source_map') or {}
    segments = source_map.get('segments') or []
    for index, segment in enumerate(segments):
        start, end = segment.get('start'), segment.get('end')
        if not isinstance(start, int) or not isinstance(end, int) or not (0 <= start <= end <= len(source)):
            invalid.append(f'segment[{index}] range outside source bytes')
        elif start not in boundaries or end not in boundaries:
            invalid.append(f'segment[{index}] splits UTF-8 code point')
        origin = segment.get('origin') or {}
        origins = ([origin['primary']] if isinstance(origin.get('primary'), dict) else [])
        origins += origin.get('derived', []) if isinstance(origin.get('derived'), list) else []
        if not origins:
            invalid.append(f'segment[{index}] has no primary/derived attribution')
        for item in origins:
            bci = item.get('bci')
            method_origin = item.get('method') or {}
            owner = method_origin.get('owner') or {}
            class_bytes = owner.get('class_bytes') or {}
            try:
                name = bytes(method_origin.get('name', [])).decode('utf-8')
                descriptor = bytes(method_origin.get('descriptor', [])).decode('utf-8')
            except (TypeError, UnicodeDecodeError):
                invalid.append(f'segment[{index}] has malformed method identity')
                continue
            if (name, descriptor) != tuple(method['identity']):
                invalid.append(f'segment[{index}] attribution belongs to {name}{descriptor}')
            if method_origin.get('owner') != owner:
                invalid.append(f'segment[{index}] class owner pin differs from target bytes')
            if not isinstance(bci, int) or bci not in physical:
                invalid.append(f'segment[{index}] BCI {bci!r} is not a physical instruction start')
            else:
                mapped.add(bci)
    return {
        'physical_bcis': sorted(physical), 'mapped_bcis': sorted(mapped),
        'missing_physical_bcis': sorted(physical - mapped),
        'segments': len(segments), 'invalid': invalid,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--baseline', type=Path, default=BASE)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    baseline, root, out = args.baseline.resolve(strict=True), args.root.resolve(strict=True), args.out.resolve()
    need(baseline == BASE.resolve(), 'baseline path differs from the frozen receipt')
    need(root == ROOT.resolve(), 'workspace path differs from pin')
    need(not out.exists(), f'refusing existing output {out}')
    receipt_path = baseline / 'execution.json'
    receipt_pin = pin(receipt_path)
    receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
    need(receipt.get('schema') == 'cf11-testnestedloops5-parameterized-baseline-v1', 'wrong baseline schema')
    need(receipt.get('status') == 'captured; outcomes require independent review', 'baseline is not complete')
    need(receipt.get('product_revision') == '755fd2c84ecbe204d03f0ff608d3a711a1bea494', 'baseline product mismatch')
    need(receipt.get('source_unchanged') is True and receipt.get('target_absent') is True, 'collector source/target guard flags fail')
    need(not (root / 'target').exists(), 'workspace target exists at review time')
    compare_path = root / COMPARE_REL
    need(sha(compare_path.read_bytes()) == COMPARE_SHA, 'compare helper changed')
    compare = load(compare_path, 'parameterized_baseline_compare')
    helper_pin = pin(CLASS_HELPER)
    helper = load(CLASS_HELPER, 'parameterized_classfile_helpers')
    source_pins_path = PREP / 'source-pins.json'
    source_pins = json.loads(source_pins_path.read_text(encoding='utf-8'))

    commands = receipt.get('commands', [])
    need(len(commands) == 65, f'expected 65 commands, got {len(commands)}')
    by_id = {row['index']: row for row in commands}
    need(len(by_id) == len(commands) and set(by_id) == set(range(1, 66)), 'command ids are missing or duplicated')
    labels = set()
    for row in commands:
        need(row.get('label') not in labels, f'duplicate command label {row.get("label")}')
        labels.add(row['label'])
        need(row.get('guard_stop') is None, f'command {row["index"]} hit guard stop')
        for channel in ('stdout', 'stderr'):
            command_bytes(row, channel, compare)
    expected_labels = {
        f'{v}-{c}-{p}-full-source-compile' for v in VARIANTS for c in COMPILERS for p in PROFILES
    } | {f'{v}-{c}-{p}-javap' for v in VARIANTS for c in COMPILERS for p in PROFILES}
    expected_labels |= {'compile-independent-reflection-driver'}
    expected_labels |= {f'{v}-{c}-{p}-runtime-{r}' for v in VARIANTS for c in COMPILERS for p in PROFILES for r in COMPILERS}
    expected_labels |= {f'{v}-{c}-{p}-wrong-root' for v in VARIANTS for c in COMPILERS for p in PROFILES}
    expected_labels |= {f'jarde-{v}-{c}-{p}-{e}' for v in VARIANTS for c in COMPILERS for p in PROFILES for e in ('default', 'all')}
    expected_labels |= {f'jadx-{v}-{c}-{p}' for v in VARIANTS for c in COMPILERS for p in PROFILES}
    need(labels == expected_labels, 'command label grid is incomplete or contains extra commands')

    need(pin(NL5_SOURCE) == receipt['original_nl5_source'], 'original NL5 source pin mismatch')
    need(source_pins.get('upstream_original', {}).get('source') == receipt['original_nl5_source'],
         'static source pins do not bind the original NL5 source')
    need(pin(Path(receipt['dependency_reference']['path'])) == receipt['dependency_reference'],
         'pinned original NL5 baseline receipt changed')
    source_before = receipt.get('source_pins_before')
    need(source_before == receipt.get('source_pins_after') and isinstance(source_before, dict), 'workspace source closure before/after differs')
    need(source_before == compare.source_closure(root), 'workspace source closure differs from captured closure')
    need(receipt.get('tool_pins_before') == receipt.get('tool_pins_after'), 'tool pins differ before/after')
    for key, tool_pin in receipt['tool_pins_before'].items():
        if key == 'jdk_tools':
            for leg, tools in tool_pin.items():
                for name, record in tools.items():
                    need(pin(Path(record['path'])) == record, f'JDK {leg}/{name} pin mismatch')
        else:
            need(pin(Path(tool_pin['path'])) == tool_pin, f'tool pin mismatch: {key}')
    need(receipt['cli_after'] == receipt['cli'] and pin(Path(receipt['cli']['path'])) == receipt['cli'], 'frozen CLI changed')
    need(receipt['dependency_reference_after'] == receipt['dependency_reference'], 'dependency receipt changed')
    need(receipt['dependency_reference_role'].startswith('Pins available'), 'baseline dependency reference reused with another role')
    for class_dir, expected in receipt['directory_pins'].items():
        actual = {p.relative_to(class_dir).as_posix(): pin(p) for p in sorted(Path(class_dir).rglob('*.class'))}
        need(actual == expected, f'JADX class directory dependency changed: {class_dir}')
    for row in [receipt['harness_jar'], *receipt['jar_pins']]:
        need(pin(Path(row['path'])) == row, f'dependency jar changed: {row["path"]}')
    need(source_pins.get('collector') == pin(PREP / 'collect_parameterized.py'), 'collector source pin manifest mismatch')
    need(source_pins.get('upstream_original', {}).get('baseline_execution_receipt') == receipt['dependency_reference'],
         'static source pin manifest does not bind the exact original NL5 receipt')
    for name, row in source_pins.get('fixtures', {}).items():
        original = verify_pin(row, f'static fixture {name}')
        if name == 'ParameterizedNestedReturnDriver.java':
            need(verify_pin(receipt['driver'], 'actual collector driver') == original,
                 'actual driver bytes differ from prepared source')
            need(verify_pin(receipt['driver_copy'], 'copied collector driver') == original,
                 'copied driver bytes differ from prepared source')
        else:
            variant = name.removeprefix('NestedReturn').removesuffix('.java')
            need(verify_pin(receipt['fixtures'][variant], f'actual source {name}') == original,
                 f'actual collector source differs: {name}')
            need(verify_pin(receipt['fixture_copies'][variant], f'copied source {name}') == original,
                 f'copied collector source differs: {name}')
    for name, row in receipt['fixtures'].items():
        need(pin(Path(row['path'])) == row, f'fixture changed: {name}')
    need(pin(Path(receipt['driver']['path'])) == receipt['driver'], 'reflection driver changed')
    need(pin(Path(receipt['runtime_bound']['path'])) == receipt['runtime_bound'], 'runtime wrapper changed')
    original_receipt = json.loads(Path(receipt['dependency_reference']['path']).read_text(encoding='utf-8'))
    original_raw_count = 0
    for command_row in original_receipt['commands']:
        for stream in command_row['streams'].values():
            need(pin(Path(stream['path'])) == stream, 'original NL5 raw stream changed')
            original_raw_count += 1
    need(original_raw_count == 56, 'original NL5 receipt raw stream census changed')
    need(source_pins['upstream_original']['baseline_raw_streams'] == [
        stream for command_row in original_receipt['commands'] for stream in command_row['streams'].values()
    ], 'static source pins do not bind all original NL5 raw streams')

    profile_rows = receipt.get('class_profiles', [])
    expected_profiles = {(v, c, p) for v in VARIANTS for c in COMPILERS for p in PROFILES}
    need(len(profile_rows) == 8 and {(x['variant'], x['compiler'], x['profile']) for x in profile_rows} == expected_profiles,
         'original target class profile grid differs')
    profile_by_key = {}
    physical_classes = {}
    for row in profile_rows:
        key = (row['variant'], row['compiler'], row['profile'])
        need(row['exit_code'] == 0 and row['classes_match_expected'] and row['major_52'] and row['all_expected_methods_have_code'],
             f'full-source input compile incomplete: {key}')
        dest = Path(row['class_root']).resolve(strict=True)
        variant = row['variant']
        target = dest / f'NestedReturn{variant}$TestCls.class'
        outer = dest / f'NestedReturn{variant}.class'
        tree = sorted(p.relative_to(dest).as_posix() for p in dest.rglob('*.class'))
        need(tree == [f'NestedReturn{variant}$TestCls.class', f'NestedReturn{variant}.class'], f'original class tree differs: {key}')
        parsed_target = facts_from_class(target, row['target_pin'], row['target'], helper)
        parsed_outer = facts_from_class(outer, row['outer_pin'], row['outer'], helper)
        need(parsed_target['class_name'] == f'NestedReturn{variant}$TestCls', f'target class identity differs: {key}')
        need({(f['name'], f['descriptor']) for f in parsed_target['fields']} == {(name, 'I') for name in EXPECTED_FIELDS},
             f'target does not have the five expected int state fields: {key}')
        need(all(f['access'] & 0x0002 for f in parsed_target['fields']), f'target state field is not private: {key}')
        need(set((m['name'], m['descriptor']) for m in parsed_target['methods']) == EXPECTED_METHODS,
             f'target method inventory mismatch: {key}')
        physical_classes[key] = (parsed_target, row['target'])
        profile_by_key[key] = row
        compiled = by_id[row['compile_command']]
        argv = compiled['argv']
        need(compiled['exit_code'] == 0 and compiled['label'] == '-'.join(key) + '-full-source-compile'
             and argv[argv.index('-d')+1] == str(dest)
             and argv[-1] == receipt['fixture_copies'][variant]['path'],
             f'input compile binding differs: {key}')
        need(('-g' if row['profile'] == 'debug' else '-g:none') in argv
             and argv[argv.index('-sourcepath')+1] == argv[argv.index('-classpath')+1],
             f'input compile debug/source isolation differs: {key}')
        need((argv[argv.index('--release')+1] == '8') if row['compiler'] == 'javac23'
             else (argv[argv.index('-source')+1] == '8' and argv[argv.index('-target')+1] == '8'),
             f'input compile Java 8 mode differs: {key}')
        javap = by_id[row['javap_command']]
        need(javap['exit_code'] == 0 and '-v' in javap['argv'], f'javap observation missing: {key}')

    oracle_outputs = {}
    runtime_rows = receipt.get('original_runtime', [])
    need(len(runtime_rows) == 16, 'expected 16 actual original JVM observations')
    runtime_keys = set()
    oracle_report = receipt.get('observed_oracles', {})
    for row in runtime_rows:
        key = (row['variant'], row['compiler'], row['profile'], row['runtime'])
        need(key not in runtime_keys and key[:3] in profile_by_key, f'duplicate/unknown original runtime key: {key}')
        runtime_keys.add(key)
        cmd = by_id[row['command']]
        stdout = command_bytes(cmd, 'stdout', compare)
        need(cmd['exit_code'] == row['exit_code'] == 0, f'original JVM failed: {key}')
        need(sha(stdout) == row['stdout_sha256'], f'original JVM stdout hash differs from metadata: {key}')
        need(stdout == row['stdout'].encode('utf-8'), f'original JVM stdout differs from metadata: {key}')
        lines = stdout.decode('utf-8').splitlines()
        need(len(lines) == 3 and all(line.startswith(f'CASE NestedReturn{row["variant"]}$TestCls-{i} ') for i, line in enumerate(lines, 1)),
             f'actual original driver output lacks exactly its three cases: {key}')
        need('-Xverify:all' in cmd['argv'] and cmd['argv'][-2] == profile_by_key[key[:3]]['class_root'],
             f'JVM lacked verifier/CodeSource class root: {key}')
        argv = cmd['argv']
        need(argv[1] == '-B' and argv[2] == receipt['runtime_bound']['path'] and argv[3] == '30',
             f'JVM runtime bound differs: {key}')
        need(argv[4] == receipt['tool_pins_before']['jdk_tools'][row['runtime']]['java']['path'],
             f'JVM executable differs: {key}')
        need(argv[argv.index('-cp')+1].split(os.pathsep) == [profile_by_key[key[:3]]['class_root'], str(BASE/'driver-classes')],
             f'JVM minimal classpath differs: {key}')
        oracle_outputs.setdefault(row['variant'], []).append(stdout)
    need(runtime_keys == {(v, c, p, r) for v in VARIANTS for c in COMPILERS for p in PROFILES for r in COMPILERS},
         'original runtime matrix incomplete')
    for variant, observations in oracle_outputs.items():
        oracle = oracle_report[variant]
        need(oracle['all_runtime_commands_succeeded'] is True and oracle['stdout_identical'] is True,
             f'original {variant} observations do not form a common oracle')
        oracle_bytes = verify_pin(oracle['file'], f'{variant} observed oracle')
        need(len(observations) == 8 and all(data == oracle_bytes for data in observations),
             f'{variant} original oracle differs from one or more JVM outcomes')
        need(sha(oracle_bytes) == oracle['stdout_sha256'], f'{variant} oracle digest mismatch')

    wrong_rows = receipt.get('wrong_root_controls', [])
    need(len(wrong_rows) == 8, 'expected one CodeSource negative control per class root')
    for row in wrong_rows:
        key = (row['variant'], row['compiler'], row['profile'])
        cmd = by_id[row['command']]
        stderr = command_bytes(cmd, 'stderr', compare)
        need(cmd['exit_code'] != 0 and row['expected_code_source_rejection'] is True and b'target loaded from' in stderr,
             f'CodeSource wrong-root control did not reject: {key}')
        need(row['variant'] in 'AB' and cmd['argv'][-1] == str(BASE / 'wrong-class-root'), f'wrong-root target input mismatch: {key}')

    jarde_rows = receipt.get('jarde_cells', [])
    expected_jarde = {(v, c, p, e) for v in VARIANTS for c in COMPILERS for p in PROFILES for e in ('default', 'all')}
    need(len(jarde_rows) == 16 and {(x['variant'], x['compiler'], x['profile'], x['evidence']) for x in jarde_rows} == expected_jarde,
         'Jarde request grid is incomplete')
    jarde_map_audit, parity = [], []
    for row in jarde_rows:
        key = (row['variant'], row['compiler'], row['profile'], row['evidence'])
        cmd = by_id[row['command']]
        raw = command_bytes(cmd, 'stdout', compare)
        report_bytes = verify_pin(row['report'], f'Jarde report {key}')
        need(raw == report_bytes and cmd['exit_code'] == row['exit_code'] == 0,
             f'Jarde response does not byte-match saved raw report: {key}')
        doc = json.loads(report_bytes)
        source = verify_pin(row['source'], f'Jarde source {key}') if row.get('source') else None
        need(isinstance(source, bytes) and doc['text'].encode('utf-8') == source,
             f'Jarde saved source differs from report text: {key}')
        target_class = physical_classes[key[:3]][1]
        owner = doc['class']
        class_bytes = owner.get('class_bytes', {})
        need(class_bytes.get('length') == target_class['bytes']
             and isinstance(class_bytes.get('digest'), str) and len(class_bytes['digest']) == 64
             and all(c in '0123456789abcdef' for c in class_bytes['digest']), f'class identity/length differs: {key}')
        need(owner.get('location') == {'kind': 'standalone_root', 'snapshot': class_bytes['digest']}
             and owner.get('variant') == {'kind': 'base'}, f'owner location/variant differs: {key}')
        method_by_key = {(m['name'], m['descriptor']): m for m in target_class['methods']}
        summaries = {tuple(m['identity']): m for m in row.get('methods', [])}
        full_methods = {}
        for emitted in doc.get('methods', []):
            raw_identity = emitted.get('item', {}).get('identity', {})
            ident = (bytes(raw_identity.get('name', [])).decode('utf-8'), bytes(raw_identity.get('descriptor', [])).decode('utf-8'))
            need(ident not in full_methods, f'duplicate method in Jarde report: {key}/{ident}')
            fact = next(m for m in target_class['methods'] if (m['name'], m['descriptor']) == ident)
            item = emitted['item']
            need(raw_identity['owner'] == owner and item['index'] == fact['index']
                 and item['access_flags'] == fact['access'], f'physical method declaration differs: {key}/{ident}')
            need(emitted['outcome']['report']['artifact']['method'] == raw_identity,
                 f'artifact physical method differs: {key}/{ident}')
            full_methods[ident] = emitted
        need(set(full_methods) == EXPECTED_METHODS and set(summaries) == EXPECTED_METHODS,
             f'Jarde method inventory differs: {key}')
        for ident in EXPECTED_METHODS:
            outcome = full_methods[ident].get('outcome', {})
            method_report = outcome.get('report', {})
            summary = summaries[ident]
            need(summary['outcome_kind'] == outcome.get('kind') and summary['quality'] == method_report.get('quality')
                 and summary['fallbacks'] == method_report.get('fallbacks')
                 and summary['source_map'] == method_report.get('source_map'),
                 f'Jarde method summary differs from raw JSON: {key}/{ident}')
            need(summary['identity'] == list(ident), f'Jarde identity mismatch: {key}/{ident}')
            audit = map_audit(source, summary, method_by_key[ident], owner, helper)
            need(not audit['invalid'], f'Jarde invalid source map {key}/{ident}: {audit["invalid"][:4]}')
            jarde_map_audit.append({'key': list(key), 'method': list(ident), **audit})
        ctor = summaries[('<init>', '()V')]
        run_method = summaries[('run', '(IIIII)I')]
        need(ctor['outcome_kind'] == 'recovered' and ctor['quality'] == 'structured' and not ctor['fallbacks'],
             f'constructor recovery changed: {key}')
        need(run_method['outcome_kind'] == 'recovered' and run_method['quality'] == 'fallback'
             and 'jre_region_arms_do_not_meet' in run_method['fallbacks'], f'run outcome differs from observed baseline: {key}')
        need(cmd['argv'][cmd['argv'].index('--evidence') + 1] == 'all' if row['evidence'] == 'all' else '--evidence' not in cmd['argv'],
             f'Jarde evidence flag differs: {key}')
        argv = cmd['argv']
        target_path = profile_by_key[key[:3]]['target_pin']['path']
        need(argv[argv.index('--input') + 1] == target_path and argv[argv.index('--class') + 1] == f'NestedReturn{row["variant"]}$TestCls'
             and argv[argv.index('--policy') + 1] == 'single-class' and argv[argv.index('--release') + 1] == '8'
             and argv[argv.index('--format') + 1] == 'json', f'Jarde request input/policy mismatch: {key}')
    for variant in VARIANTS:
        for compiler in COMPILERS:
            for profile in PROFILES:
                default = next(r for r in jarde_rows if (r['variant'], r['compiler'], r['profile'], r['evidence']) == (variant, compiler, profile, 'default'))
                all_row = next(r for r in jarde_rows if (r['variant'], r['compiler'], r['profile'], r['evidence']) == (variant, compiler, profile, 'all'))
                need(default['source']['sha256'] == all_row['source']['sha256'], 'default/all emitted source differs')
                left = {tuple(m['identity']): (m['outcome_kind'], m['quality'], m['fallbacks'], m['source_map']) for m in default['methods']}
                right = {tuple(m['identity']): (m['outcome_kind'], m['quality'], m['fallbacks'], m['source_map']) for m in all_row['methods']}
                need(left == right, f'default/all method maps/outcomes differ: {variant}/{compiler}/{profile}')
                parity.append({'variant': variant, 'compiler': compiler, 'profile': profile, 'source_equal': True,
                               'method_maps_equal': True, 'full_report_equal': False,
                               'full_report_note': 'all evidence intentionally adds evidence/rules/regions; comparison is source and method-outcome/map parity.'})

    jadx_rows = receipt.get('jadx_cells', [])
    expected_jadx = {(v, c, p) for v in VARIANTS for c in COMPILERS for p in PROFILES}
    need(len(jadx_rows) == 8 and {(x['variant'], x['compiler'], x['profile']) for x in jadx_rows} == expected_jadx,
         'JADX extraction grid incomplete')
    for row in jadx_rows:
        key = (row['variant'], row['compiler'], row['profile'])
        cmd = by_id[row['command']]
        need(cmd['exit_code'] == row['exit_code'] == 0 and len(row['sources']) == 1, f'JADX extraction failed: {key}')
        source = verify_pin(row['sources'][0], f'JADX source {key}')
        need(cmd['argv'][1:8] == ['--config', 'none', '--threads-count', '1', '--no-res', '--rename-flags', 'none'], f'JADX flags differ: {key}')
        need(source and cmd['argv'][-1] == profile_by_key[key]['target_pin']['path'], f'JADX input differs from target class: {key}')

    need(pin(receipt_path) == receipt_pin, 'baseline receipt changed during independent review')
    need(not (root / 'target').exists(), 'workspace target appeared during review')
    out.mkdir(parents=True)
    result = {
        'schema': 'cf11-testnestedloops5-parameterized-baseline-acceptance-v1',
        'status': 'accepted_static_baseline_with_mapping_gaps_reported',
        'baseline_receipt': receipt_pin, 'checker': pin(Path(__file__)), 'classfile_helper': helper_pin,
        'command_count': len(commands), 'raw_stream_count': len(commands) * 2,
        'class_profile_count': len(profile_rows), 'original_runtime_count': len(runtime_rows),
        'parsed_original_classes': [{'key': list(key), 'class_name': facts[0]['class_name'], 'major': facts[0]['major'],
            'fields': facts[0]['fields'], 'methods': [{'name': m['name'], 'descriptor': m['descriptor'],
                'code_length': m['code']['code_length'], 'bcis': m['code']['bcis'], 'rows': m['code']['rows']}
                for m in facts[0]['methods']]} for key, facts in sorted(physical_classes.items())],
        'original_oracle_variants': {v: {'three_actual_cases': len(oracle_outputs[v][0].splitlines()),
            'all_eight_runtime_observations_equal': True,
            'oracle': receipt['observed_oracles'][v]['file']} for v in VARIANTS},
        'wrong_root_controls': [{'key': [r['variant'], r['compiler'], r['profile']], 'command': r['command'], 'rejected': True} for r in wrong_rows],
        'jarde_cell_count': len(jarde_rows), 'jadx_cell_count': len(jadx_rows),
        'jarde_method_map_audit': jarde_map_audit, 'default_all_parity': parity,
        'workspace_source_unchanged': True, 'target_absent': True,
        'source_pins_before_after_equal': True, 'tool_pins_before_after_equal': True,
        'original_receipt_raw_streams_verified': original_raw_count,
        'ssa': 'not observed in this public class-source receipt; no SSA conclusion is made',
        'digest_note': 'Class SHA256 independently binds actual input bytes; public BLAKE3 digest is checked for full same-owner identity and physical length, not independently recomputed by Python. Public Rust gates recompute BLAKE3.',
        'map_coverage_note': 'missing_physical_bcis is an explicit per-method list; this checker accepts valid partial maps without claiming complete BCI coverage.',
    }
    (out / 'acceptance.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'jarde_cells': 16, 'jadx_cells': 8,
                      'map_methods_checked': len(jarde_map_audit), 'target_absent': True}, separators=(',', ':')))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
