#!/usr/bin/env python3
"""Prepared, serial collector for two source-only CF-11 nested-return probes.

This file is intentionally unexecuted. Run only after root reviews the pin set.
"""
from __future__ import annotations

import argparse
import datetime
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
PREP = Path(__file__).resolve().parent
SOURCES = {
    'A': ('NestedReturnA.java', 'NestedReturnA$TestCls', 'NestedReturnA$TestCls'),
    'B': ('NestedReturnB.java', 'NestedReturnB$TestCls', 'NestedReturnB$TestCls'),
}
SOURCE_SHA256 = {
    'NestedReturnA.java': '83c188629524a04e6a43334ffd972cb9286aeb9cbf01831655a7bf5ab22b338a',
    'NestedReturnB.java': 'fd4ed17dacf148a9d8bee8c673055821375041a5923291ac65f6752ad121a540',
    'ParameterizedNestedReturnDriver.java': 'abf7e5557e63c3f8c2d78d9720c3c84a333bded91817aaa7d6125fed61e0ea60',
}
CLI = Path('/private/tmp/jarde-prefixed-retry-final-focused-root-v5-20261018/candidate-cli')
CLI_SHA256 = '25adeaf312a7644c7d4c73191ef1264af0378cf78139d35a890377e3c86371ce'
JADX = Path('/opt/homebrew/Cellar/jadx/1.5.6/bin/jadx')
JADX_SHA256 = '64a6ee6bcf7490ea682508db2a73d6cda8b671a5211af5ee3ff098441af038a7'
JADX_JAR = Path('/opt/homebrew/Cellar/jadx/1.5.6/libexec/lib/jadx-1.5.6-all.jar')
JADX_JAR_SHA256 = '966d314282d95ff7c72f597bb9c744999856666a3b856575e3c035a9c12a0b65'
JDK_MANIFEST_REL = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
COMPARE_REL = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
COMPARE_SHA256 = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
BOUND = Path('/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py')
BOUND_SHA256 = '73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
DEPENDENCY_REFERENCE = Path('/private/tmp/jarde-testnestedloops5-baseline-run-root-v3-20261018/execution.json')
ORIGINAL_NL5_SOURCE = Path('/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestNestedLoops5.java')
ORIGINAL_NL5_SHA256 = '0be29d145607e1be1d1426305739e6879d76defc8472dff7f6e82fcec0d83b6d'
JDK_LEGS = ('javac8', 'javac23')
DEBUG_PROFILES = (('debug', '-g'), ('no-debug', '-g:none'))
EVIDENCE = ('default', 'all')


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def method_set(facts: dict) -> set[tuple[str, str]]:
    return {(row['name'], row['descriptor']) for row in facts['methods']}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--cli', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    out = args.out.resolve()
    cli = args.cli.resolve(strict=True)
    if out.exists():
        raise SystemExit(f'refusing existing output: {out}')
    if root != ROOT.resolve():
        raise SystemExit(f'workspace root differs from frozen path: {root}')
    if cli != CLI or sha256(cli) != CLI_SHA256:
        raise SystemExit('CLI path/SHA does not match frozen product 755fd2c84')
    if sha256(JADX) != JADX_SHA256 or sha256(JADX_JAR) != JADX_JAR_SHA256:
        raise SystemExit('JADX 1.5.6 executable/JAR pin mismatch')
    if sha256(BOUND) != BOUND_SHA256:
        raise SystemExit('runtime-bound wrapper pin mismatch')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('workspace target exists; refusing external command collection')
    if shutil.disk_usage(root).free < 5 * 1024**3:
        raise SystemExit('5 GiB workspace free-space guard failed')

    compare_path = root / COMPARE_REL
    if sha256(compare_path) != COMPARE_SHA256:
        raise SystemExit('compare helper pin mismatch')
    compare = load(compare_path, 'parameterized_compare')
    guard_path, scanner_path = root / GUARD_REL, root / SCANNER_REL
    if compare.sha(guard_path) != GUARD_SHA256 or compare.sha(scanner_path) != SCANNER_SHA256:
        raise SystemExit('guard/scanner pin mismatch')
    guard, scanner = load(guard_path, 'parameterized_guard'), load(scanner_path, 'parameterized_scanner')
    jdks, jdk_pin = compare.configured_jdks(root / JDK_MANIFEST_REL, JDK_MANIFEST_SHA256)
    ref = json.loads(DEPENDENCY_REFERENCE.read_text(encoding='utf-8'))
    if ref.get('source', {}).get('path') != str(ORIGINAL_NL5_SOURCE) or ref['source']['sha256'] != ORIGINAL_NL5_SHA256:
        raise SystemExit('original NL5 baseline source identity/SHA mismatch')
    if sha256(ORIGINAL_NL5_SOURCE) != ORIGINAL_NL5_SHA256:
        raise SystemExit('original NL5 source changed from the frozen baseline')
    def verify_original_receipt() -> None:
        if compare.sha(DEPENDENCY_REFERENCE) != ref_pin['sha256']:
            raise RuntimeError('original NL5 baseline receipt changed')
        if compare.pin(ORIGINAL_NL5_SOURCE) != ref['source']:
            raise RuntimeError('original NL5 source changed during supplement collection')
        for command_row in ref['commands']:
            for stream in command_row['streams'].values():
                item = stream
                path = Path(item['path'])
                if compare.pin(path) != item:
                    raise RuntimeError(f'original NL5 raw receipt changed: {path}')
    ref_pin = compare.pin(DEPENDENCY_REFERENCE)

    def verify_dependency_inputs() -> None:
        for row in dependency_pins:
            if compare.pin(Path(row['path'])) != row:
                raise RuntimeError(f'NL5 baseline dependency pin mismatch: {row["path"]}')
        for folder, expected in ref.get('directory_pins_before', ref.get('directory_pins', {})).items():
            actual = {p.relative_to(folder).as_posix(): compare.pin(p)
                      for p in sorted(Path(folder).rglob('*.class'))}
            if actual != expected:
                raise RuntimeError(f'JADX class-directory dependency pin mismatch: {folder}')

    def current_tool_pins() -> dict:
        jdk_tools = {}
        for leg, tools in jdk_pin['tools'].items():
            jdk_tools[leg] = {name: compare.pin(Path(item['path'])) for name, item in tools.items()}
        return {
            'cli': compare.pin(cli), 'jadx': compare.pin(JADX), 'jadx_jar': compare.pin(JADX_JAR),
            'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path),
            'scanner': compare.pin(scanner_path), 'runtime_bound': compare.pin(BOUND),
            'jdk_manifest': compare.pin(root / JDK_MANIFEST_REL), 'jdk_tools': jdk_tools,
        }

    verify_original_receipt()
    dependency_pins = [ref['harness_jar'], *ref['jar_pins']]
    verify_dependency_inputs()
    for row in dependency_pins:
        if compare.pin(Path(row['path'])) != row:
            raise SystemExit(f'NL5 baseline dependency pin mismatch: {row["path"]}')
    for folder, expected in ref.get('directory_pins_before', ref.get('directory_pins', {})).items():
        actual = {p.relative_to(folder).as_posix(): compare.pin(p)
                  for p in sorted(Path(folder).rglob('*.class'))}
        if actual != expected:
            raise SystemExit(f'JADX class-directory dependency pin mismatch: {folder}')
    for name, digest in SOURCE_SHA256.items():
        if digest == 'TO_BE_PINNED' or sha256(PREP / name) != digest:
            raise SystemExit(f'fixture source pin missing/mismatch: {name}')

    out.mkdir(parents=True)
    raw = out / 'raw'
    raw.mkdir()
    guard.ROOT, guard.OUT = root, raw
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, stdout_bytes: None
    source_before = compare.source_closure(root)
    driver = PREP / 'ParameterizedNestedReturnDriver.java'
    report = {
        'schema': 'cf11-testnestedloops5-parameterized-baseline-v1', 'status': 'running',
        'scope': 'Source-only A/B supplements; the unchanged upstream TestNestedLoops5 class is a separate baseline.',
        'fixtures': {name: compare.pin(PREP / source) for name, (source, _, _) in SOURCES.items()},
        'driver': compare.pin(driver), 'runtime_bound': compare.pin(BOUND),
        'dependency_reference': compare.pin(DEPENDENCY_REFERENCE),
        'dependency_inputs_before': dependency_pins,
        'original_nl5_source': compare.pin(ORIGINAL_NL5_SOURCE),
        'original_nl5_source_role': 'Read-only origin; this supplemental collector never compiles or rewrites the upstream TestNestedLoops5 class.',
        'dependency_reference_role': 'Pins available harness/JADX dependencies; no target bytes or oracle borrowed.',
        'harness_jar': ref['harness_jar'], 'jar_pins': ref['jar_pins'],
        'directory_pins': ref.get('directory_pins_before', ref.get('directory_pins', {})),
        'jdk_manifest': jdk_pin, 'cli': compare.pin(cli), 'product_revision': '755fd2c84ecbe204d03f0ff608d3a711a1bea494',
        'jadx': compare.pin(JADX), 'jadx_jar': compare.pin(JADX_JAR),
        'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path), 'scanner': compare.pin(scanner_path),
        'tool_pins_before': current_tool_pins(),
        'source_pins_before': source_before, 'commands': [], 'class_profiles': [],
        'original_runtime': [], 'wrong_root_controls': [], 'observed_oracles': {},
        'jarde_cells': [], 'jadx_cells': [],
        'expected_class_methods': [['<init>', '()V'], ['run', '(IIIII)I']],
        'oracle_policy': 'All runtime stdout is observed. No numeric state/result is assumed; retain per-cell raw output and report equality/divergence.',
        'notes': [
            'Each fixture is a standalone complete outer+nested source; no source is derived by deleting methods from upstream TestNestedLoops5.',
            'Both javac8 and javac23 compile each complete source with Java 8 target and debug/no-debug options.',
            'Runtime classpath contains only that compiled fixture root and the independent driver output.',
            'Jarde/JADX results are recorded as observed; this collector does not assume success, fallback, or compilability.',
        ],
    }

    def save() -> None:
        compare.write_json(out / 'execution.json', report)

    def command(argv, label, leg='javac23'):
        if (root / 'target').exists():
            raise RuntimeError('workspace target appeared during collection')
        env = compare.clean_env(dict(os.environ), jdks[leg])
        env.update(guard.ENV_VALUES)
        env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(report['commands']) + 1, [str(x) for x in argv], env)
        row['label'], row['tool_leg'] = label, leg
        report['commands'].append(row)
        save()
        if row['guard_stop'] is not None:
            raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        return row

    def artifact(row, stream='stdout'):
        return compare.command_artifact(row, stream)

    save()
    try:
        empty_classpath = out / 'empty-classpath'
        empty_classpath.mkdir()
        copied = {}
        for key, (source_name, _, _) in SOURCES.items():
            dest = out / 'sources' / key / source_name
            dest.parent.mkdir(parents=True)
            shutil.copy2(PREP / source_name, dest)
            copied[key] = dest
        driver_copy = out / 'driver-source/ParameterizedNestedReturnDriver.java'
        driver_copy.parent.mkdir(parents=True)
        shutil.copy2(driver, driver_copy)
        source_before_copy = {key: compare.pin(path) for key, path in copied.items()}
        report['fixture_copies'] = source_before_copy
        report['driver_copy'] = compare.pin(driver_copy)

        for key, (_, binary_name, _) in SOURCES.items():
            for leg in JDK_LEGS:
                for profile, flag in DEBUG_PROFILES:
                    dest = out / 'classes' / key / leg / profile
                    dest.mkdir(parents=True)
                    javac = jdks[leg]['tools']['javac']
                    target_args = (['-source', '8', '-target', '8'] if leg == 'javac8' else ['--release', '8'])
                    compiled = command([
                        javac, *target_args, flag, '-encoding', 'UTF-8', '-proc:none',
                        '-classpath', empty_classpath, '-sourcepath', empty_classpath,
                        '-d', dest, copied[key],
                    ], f'{key}-{leg}-{profile}-full-source-compile', leg)
                    expected = sorted([f'{binary_name.split("$")[0]}.class', f'{binary_name}.class'])
                    actual = sorted(p.relative_to(dest).as_posix() for p in dest.rglob('*.class'))
                    record = {
                        'variant': key, 'compiler': leg, 'profile': profile,
                        'compile_command': compiled['index'], 'exit_code': compiled['exit_code'],
                        'classes': actual, 'classes_match_expected': actual == expected,
                        'class_root': str(dest),
                    }
                    if compiled['exit_code'] == 0:
                        target = dest / (binary_name.replace('.', '/') + '.class')
                        outer = dest / (binary_name.split('$')[0].replace('.', '/') + '.class')
                        facts, outer_facts = compare.parse_class(target), compare.parse_class(outer)
                        method_rows = {(m['name'], m['descriptor']): m for m in facts['methods']}
                        record.update({
                            'target': facts, 'outer': outer_facts,
                            'target_pin': compare.pin(target), 'outer_pin': compare.pin(outer),
                            'major_52': facts['major'] == 52 and outer_facts['major'] == 52,
                            'all_expected_methods_have_code': method_set(facts) == {('<init>', '()V'), ('run', '(IIIII)I')}
                            and all(method_rows[name]['code'] is not None for name in [('<init>', '()V'), ('run', '(IIIII)I')]),
                        })
                        if not record['classes_match_expected'] or not record['major_52'] or not record['all_expected_methods_have_code']:
                            raise RuntimeError(f'class inventory/major/Code mismatch: {key}/{leg}/{profile}')
                        javap = command([jdks[leg]['tools']['javap'], '-p', '-s', '-c', '-v', target],
                                        f'{key}-{leg}-{profile}-javap', leg)
                        record['javap_command'] = javap['index']
                    report['class_profiles'].append(record)
                    save()

        driver_classes = out / 'driver-classes'
        driver_classes.mkdir()
        driver_compile = command([
            jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
            '-encoding', 'UTF-8', '-proc:none', '-classpath', empty_classpath,
            '-sourcepath', empty_classpath, '-d', driver_classes, driver_copy,
        ], 'compile-independent-reflection-driver', 'javac8')
        if driver_compile['exit_code'] != 0:
            raise RuntimeError('independent driver compilation failed; raw stderr retained')
        report['driver_classes'] = [compare.pin(p) for p in sorted(driver_classes.rglob('*.class'))]

        oracle_bodies = {}
        for rec in report['class_profiles']:
            if rec['exit_code'] != 0:
                continue
            key, leg, profile = rec['variant'], rec['compiler'], rec['profile']
            for runtime in JDK_LEGS:
                argv = [
                    sys.executable, '-B', BOUND, '30', jdks[runtime]['tools']['java'], '-Xverify:all', '-cp',
                    os.pathsep.join([rec['class_root'], str(driver_classes)]),
                    'ParameterizedNestedReturnDriver', rec['target']['class_name'].replace('/', '.'), rec['class_root'],
                ]
                run = command(argv, f'{key}-{leg}-{profile}-runtime-{runtime}', runtime)
                observed = artifact(run)
                cell = {
                    'variant': key, 'compiler': leg, 'profile': profile, 'runtime': runtime,
                    'command': run['index'], 'exit_code': run['exit_code'],
                    'stdout_sha256': compare.sha(Path(run['streams']['stdout']['path'])),
                    'stderr_sha256': compare.sha(Path(run['streams']['stderr']['path'])),
                    'stdout': observed.decode('utf-8', errors='replace'),
                }
                report['original_runtime'].append(cell)
                oracle_bodies.setdefault(key, []).append((f'{leg}/{profile}/{runtime}', observed, run['exit_code']))
                save()
            wrong = out / 'wrong-class-root'
            wrong.mkdir(exist_ok=True)
            runtime = 'javac23'
            run = command([
                sys.executable, '-B', BOUND, '30', jdks[runtime]['tools']['java'], '-Xverify:all', '-cp',
                os.pathsep.join([rec['class_root'], str(driver_classes)]),
                'ParameterizedNestedReturnDriver', rec['target']['class_name'].replace('/', '.'), str(wrong),
            ], f'{key}-{leg}-{profile}-wrong-root', runtime)
            err = artifact(run, 'stderr')
            ok = run['exit_code'] != 0 and b'target loaded from' in err
            report['wrong_root_controls'].append({'variant': key, 'compiler': leg, 'profile': profile,
                'command': run['index'], 'exit_code': run['exit_code'], 'expected_code_source_rejection': ok,
                'stderr_sha256': compare.sha(Path(run['streams']['stderr']['path']))})
            if not ok:
                raise RuntimeError('wrong-root CodeSource control did not reject the loaded target')

        for key, observations in oracle_bodies.items():
            successful = [(label, body) for label, body, code in observations if code == 0]
            identical = bool(successful) and len({body for _, body in successful}) == 1
            complete = len(successful) == len(observations) == 8
            report['observed_oracles'][key] = {
                'observations': [label for label, _, _ in observations],
                'all_runtime_commands_succeeded': complete,
                'stdout_identical': identical,
                'stdout_sha256': __import__('hashlib').sha256(successful[0][1]).hexdigest() if complete and identical else None,
            }
            if complete and identical:
                oracle = out / f'observed-oracle-{key}.stdout'
                oracle.write_bytes(successful[0][1])
                report['observed_oracles'][key]['file'] = compare.pin(oracle)

        for rec in report['class_profiles']:
            if rec['exit_code'] != 0:
                continue
            key, profile = rec['variant'], rec['profile']
            target = Path(rec['target_pin']['path'])
            for evidence in EVIDENCE:
                argv = [CLI, 'class-source', '--input', target, '--class', rec['target']['class_name'],
                        '--policy', 'single-class', '--release', '8', '--format', 'json']
                if evidence == 'all':
                    argv += ['--evidence', 'all']
                row = command(argv, f'jarde-{key}-{rec["compiler"]}-{profile}-{evidence}', 'javac23')
                raw_bytes = artifact(row)
                dest = out / 'jarde' / key / rec['compiler'] / profile / evidence
                dest.mkdir(parents=True)
                (dest / 'report.json').write_bytes(raw_bytes)
                source_path, methods, inventory_matches = None, [], None
                try:
                    doc = json.loads(raw_bytes)
                    if isinstance(doc.get('text'), str):
                        source_path = dest / 'source.java'
                        source_path.write_text(doc['text'], encoding='utf-8')
                    for method in doc.get('methods', []):
                        identity = method.get('item', {}).get('identity', {})
                        name = bytes(identity.get('name', [])).decode('utf-8')
                        descriptor = bytes(identity.get('descriptor', [])).decode('utf-8')
                        outcome = method.get('outcome', {})
                        method_report = outcome.get('report', {})
                        methods.append({
                            'identity': [name, descriptor], 'outcome_kind': outcome.get('kind'),
                            'quality': method_report.get('quality'), 'fallbacks': method_report.get('fallbacks'),
                            'regions': method_report.get('regions'), 'source_map': method_report.get('source_map'),
                        })
                    inventory_matches = {tuple(item['identity']) for item in methods} == {
                        ('<init>', '()V'), ('run', '(IIIII)I')
                    }
                except (UnicodeDecodeError, json.JSONDecodeError, TypeError, AttributeError) as parse_error:
                    doc = None
                    report_parse_error = str(parse_error)
                else:
                    report_parse_error = None
                report['jarde_cells'].append({'variant': key, 'compiler': rec['compiler'], 'profile': profile,
                    'evidence': evidence, 'command': row['index'], 'exit_code': row['exit_code'],
                    'report': compare.pin(dest / 'report.json'),
                    'source': compare.pin(source_path) if source_path else None,
                    'json_parsed': doc is not None, 'methods': methods,
                    'method_inventory_matches': inventory_matches,
                    'parse_error': report_parse_error})
                save()

            jadx_dest = out / 'jadx' / key / rec['compiler'] / profile
            row = command([JADX, '--config', 'none', '--threads-count', '1', '--no-res',
                           '--rename-flags', 'none', '-d', jadx_dest, target],
                          f'jadx-{key}-{rec["compiler"]}-{profile}', 'javac23')
            sources = sorted(jadx_dest.rglob('*.java'))
            report['jadx_cells'].append({'variant': key, 'compiler': rec['compiler'], 'profile': profile,
                'command': row['index'], 'exit_code': row['exit_code'],
                'sources': [compare.pin(path) for path in sources]})
            save()

        report['source_pins_after'] = compare.source_closure(root)
        if report['source_pins_after'] != report['source_pins_before']:
            raise RuntimeError('shared source closure changed during collection')
        verify_original_receipt()
        verify_dependency_inputs()
        for key, path in copied.items():
            if compare.sha(path) != SOURCE_SHA256[path.name]:
                raise RuntimeError(f'source copy changed: {key}')
        if compare.sha(driver_copy) != SOURCE_SHA256[driver.name]:
            raise RuntimeError('independent driver source changed')
        for record in report['class_profiles']:
            if record['exit_code'] == 0:
                for role in ('target_pin', 'outer_pin'):
                    if compare.pin(Path(record[role]['path'])) != record[role]:
                        raise RuntimeError('original class input changed during collection')
        for pin in report['driver_classes']:
            if compare.pin(Path(pin['path'])) != pin:
                raise RuntimeError('driver class changed during collection')
        report['cli_after'] = compare.pin(cli)
        report['dependency_reference_after'] = compare.pin(DEPENDENCY_REFERENCE)
        report['tool_pins_after'] = current_tool_pins()
        if report['tool_pins_after'] != report['tool_pins_before']:
            raise RuntimeError('one or more pinned tools/helpers changed during collection')
        report['environment_after'] = {
            'tools': report['tool_pins_after'],
            'driver': compare.pin(driver_copy), 'fixtures': {key: compare.pin(path) for key, path in copied.items()},
        }
        report['source_unchanged'], report['target_absent'] = True, not (root / 'target').exists()
        if not report['target_absent'] or report['cli_after'] != report['cli']:
            raise RuntimeError('target appeared or frozen CLI changed')
        report['status'] = 'captured; outcomes require independent review'
    except BaseException as exc:
        report['status'], report['error'] = 'failed', str(exc)
        raise
    finally:
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
        shutil.copy2(__file__, out / 'collector.py')
        print(json.dumps({k: report.get(k) for k in ('status', 'error', 'target_absent', 'source_unchanged')},
                         separators=(',', ':')))
    return 0


def sha256(path: Path) -> str:
    import hashlib
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


if __name__ == '__main__':
    raise SystemExit(main())
