#!/usr/bin/env python3
"""Independent classfile, BCI, and workspace source-closure helpers."""
from __future__ import annotations
import hashlib
from pathlib import Path

def instruction_bcis(code: bytes) -> list[int]:
    fixed = {0x10:2,0x11:3,0x12:2,0x13:3,0x14:3,0x15:2,0x16:2,0x17:2,0x18:2,0x19:2,
             0x36:2,0x37:2,0x38:2,0x39:2,0x3a:2,0x84:3,0xa9:2,0xbc:2,0xc5:4,
             0xb2:3,0xb3:3,0xb4:3,0xb5:3,0xb6:3,0xb7:3,0xb8:3,0xbb:3,0xbd:3,0xc0:3,0xc1:3,
             0xb9:5,0xba:5,0xc8:5,0xc9:5}
    fixed.update({op:3 for op in range(0x99,0xa9)}); fixed.update({0xc6:3,0xc7:3})
    bcis=[]; pc=0
    while pc < len(code):
        bcis.append(pc); op=code[pc]
        if op == 0xaa:
            aligned=(pc+4)&~3; low=int.from_bytes(code[aligned+4:aligned+8],'big',signed=True); high=int.from_bytes(code[aligned+8:aligned+12],'big',signed=True)
            if high < low: raise ValueError(f'invalid tableswitch at {pc}')
            size=(aligned-pc)+12+4*(high-low+1)
        elif op == 0xab:
            aligned=(pc+4)&~3; pairs=int.from_bytes(code[aligned+4:aligned+8],'big',signed=True)
            if pairs < 0: raise ValueError(f'invalid lookupswitch at {pc}')
            size=(aligned-pc)+8+8*pairs
        elif op == 0xc4:
            if pc+1 >= len(code): raise ValueError('truncated wide')
            size=6 if code[pc+1] == 0x84 else 4
        else: size=fixed.get(op, 1)
        if pc+size > len(code): raise ValueError(f'instruction overruns Code at {pc}')
        pc += size
    return bcis

def parse_class_file(data: bytes) -> dict:
    path = Path("<class-bytes>"); pos = 0
    def take(n: int) -> bytes:
        nonlocal pos
        b = data[pos:pos+n]
        if len(b) != n: raise ValueError(f'truncated class file {path}')
        pos += n; return b
    def u1() -> int: return take(1)[0]
    def u2() -> int: return int.from_bytes(take(2), 'big')
    def u4() -> int: return int.from_bytes(take(4), 'big')
    if u4() != 0xCAFEBABE: raise ValueError(f'not a class file: {path}')
    minor, major = u2(), u2(); count = u2(); cp = [None] * count; i = 1
    while i < count:
        tag = u1()
        if tag == 1:
            n = u2(); cp[i] = ('utf8', take(n).decode('utf-8', errors='replace'))
        elif tag in (3, 4): take(4)
        elif tag in (5, 6): take(8); i += 1
        elif tag in (7, 8, 16, 19, 20): cp[i] = (tag, u2())
        elif tag in (9, 10, 11, 12, 17, 18): cp[i] = (tag, u2(), u2())
        elif tag == 15: take(3)
        else: raise ValueError(f'unknown CP tag {tag} in {path}')
        i += 1
    def utf(idx: int) -> str:
        entry = cp[idx]
        if not entry or entry[0] != 'utf8': raise ValueError(f'bad UTF8 CP index {idx}')
        return entry[1]
    def attrs() -> dict:
        out = {}
        for _ in range(u2()):
            name = utf(u2()); size = u4(); out[name] = take(size)
        return out
    access = u2(); this_idx = u2(); super_idx = u2()
    for _ in range(u2()): u2()
    fields = []
    for _ in range(u2()):
        flags = u2(); name = utf(u2()); desc = utf(u2()); attrs(); fields.append((name, desc, flags))
    methods = []
    for ordinal in range(u2()):
        flags = u2(); name = utf(u2()); desc = utf(u2()); at = attrs(); code = None
        if 'Code' in at:
            blob = at['Code']; q = 0
            def r2() -> int:
                nonlocal q
                v = int.from_bytes(blob[q:q+2], 'big'); q += 2; return v
            def r4() -> int:
                nonlocal q
                v = int.from_bytes(blob[q:q+4], 'big'); q += 4; return v
            max_stack = r2(); max_locals = r2(); ncode = r4(); bcode = blob[q:q+ncode]; q += ncode
            rows = []
            for _ in range(r2()): rows.append([r2(), r2(), r2(), r2()])
            code = {'max_stack': max_stack, 'max_locals': max_locals, 'code_length': ncode,
                    'code_hex': bcode.hex(), 'rows': rows, 'bcis': instruction_bcis(bcode)}
        methods.append({'index': ordinal, 'name': name, 'descriptor': desc, 'access': flags,
                        'code': code})
    class_attrs = attrs()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'minor': minor, 'major': major, 'class_name': cp[cp[this_idx][1]][1],
            'fields': fields, 'methods': methods, 'attributes': sorted(class_attrs)}

