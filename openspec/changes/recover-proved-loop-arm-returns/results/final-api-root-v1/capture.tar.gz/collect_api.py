#!/usr/bin/env python3
"""Capture current CLI API reports for frozen NL5 and A/B loop-arm fixtures."""
from __future__ import annotations
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
import tarfile
import zipfile

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
CHANGE = ROOT / 'openspec/changes/recover-proved-loop-arm-returns'
RESULTS = CHANGE / 'results'
FIXTURES = ROOT / 'tests/fixtures/recover-proved-loop-arm-returns'
ORIGINAL_ARCHIVE_DIR = RESULTS / 'original-baseline-root-v3'
SUPPLEMENTAL_ARCHIVE_DIR = RESULTS / 'supplemental-baseline-root-v1'
ARCHIVE_REVIEW = RESULTS / 'baseline-archive-review-root.json'
BASE_RUN_ROOT = Path('/private/tmp/jarde-testnestedloops5-baseline-run-root-v3-20261018')
SUPP_RUN_ROOT = Path('/private/tmp/jarde-testnestedloops5-parameterized-baseline-run-root-v1-20261018')
COMPARE_REL = Path('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
COMPARE_SHA256 = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
JDK_MANIFEST_REL = Path('openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json')
JDK_MANIFEST_SHA256 = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
EXPECTED_ORIGINAL_SCHEMA = 'cf11-original-testnestedloops5-baseline-v1'
EXPECTED_SUPP_SCHEMA = 'cf11-testnestedloops5-parameterized-baseline-v1'
PROFILES = ('debug', 'no-debug')
EVIDENCE = ('default', 'all')
SUPPILERS = ('javac8', 'javac23')
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load {path}')
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def pin_bytes(data: bytes, path: Path | None = None) -> dict:
    row = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    if path is not None: row['path'] = str(path.resolve())
    return row


def read_pin_from_tar(tf: tarfile.TarFile, old_root: Path, record: dict, label: str) -> tuple[str, bytes]:
    old_path = Path(record.get('path', ''))
    try: member_name = old_path.relative_to(old_root).as_posix()
    except ValueError as exc: raise RuntimeError(f'{label}: path escapes archived run root') from exc
    pp = PurePosixPath(member_name)
    if pp.is_absolute() or any(part in ('', '.', '..') for part in pp.parts):
        raise RuntimeError(f'{label}: unsafe archive member path {member_name!r}')
    try: member = tf.getmember(member_name)
    except KeyError as exc: raise RuntimeError(f'{label}: missing archived file {member_name}') from exc
    if not member.isfile(): raise RuntimeError(f'{label}: archive member is not a regular file')
    stream = tf.extractfile(member)
    if stream is None: raise RuntimeError(f'{label}: cannot read archived member')
    data = stream.read()
    if len(data) != record.get('bytes') or hashlib.sha256(data).hexdigest() != record.get('sha256'):
        raise RuntimeError(f'{label}: archive member differs from embedded receipt pin')
    return member_name, data


def archive_bundle(directory: Path, expected_archive_review: dict) -> dict:
    archive = directory / 'capture.tar.gz'; review_path = directory / 'capture-review.json'
    archive_pin = pin_bytes(archive.read_bytes(), archive); review_pin = pin_bytes(review_path.read_bytes(), review_path)
    review = json.loads(review_path.read_bytes())
    if review.get('archive_bytes') != archive_pin['bytes'] or review.get('archive_sha256') != archive_pin['sha256']:
        raise RuntimeError(f'{archive}: adjacent capture-review mismatch')
    if review.get('members_reopened') != expected_archive_review.get('capture_review_members_reopened'):
        raise RuntimeError(f'{archive}: accepted archive review member count mismatch')
    if expected_archive_review.get('bytes') != archive_pin['bytes'] or expected_archive_review.get('sha256') != archive_pin['sha256']:
        raise RuntimeError(f'{archive}: root archive review pin mismatch')
    return {'archive': archive, 'archive_pin': archive_pin, 'capture_review': review,
            'capture_review_pin': review_pin, 'old_run_root': Path(expected_archive_review['old_run_root'])}


def source_method_projection(method: dict) -> dict:
    item = method.get('item') or {}; ident = item.get('identity') or {}; outcome = method.get('outcome') or {}
    report = outcome.get('report') or {}
    try:
        name = bytes(ident.get('name', [])).decode('utf-8', errors='strict')
        descriptor = bytes(ident.get('descriptor', [])).decode('utf-8', errors='strict')
    except (TypeError, UnicodeDecodeError) as exc:
        raise ValueError(f'invalid method identity: {exc}') from exc
    return {'identity': [name, descriptor], 'owner': ident.get('owner'), 'index': item.get('index'),
            'access_flags': item.get('access_flags'), 'outcome_kind': outcome.get('kind'),
            'quality': report.get('quality'), 'fallbacks': report.get('fallbacks'),
            'regions': report.get('regions'), 'source_map': report.get('source_map'),
            'method_text': method.get('text'), 'report_text': report.get('text')}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--cli', type=Path, required=True)
    ap.add_argument('--cli-sha256', required=True)
    ap.add_argument('--product-revision', required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    root = args.root.resolve(strict=True); cli = args.cli.resolve(strict=True); out = args.out.resolve()
    if root != ROOT.resolve(): raise SystemExit(f'workspace root differs: {root}')
    if out.exists(): raise SystemExit(f'refusing existing output: {out}')
    if not out.is_relative_to(Path('/private/tmp')): raise SystemExit('output must be a fresh private /private/tmp path')
    if not args.product_revision.strip(): raise SystemExit('product revision must be supplied')
    cli_before = pin_bytes(cli.read_bytes(), cli)
    if cli_before['sha256'] != args.cli_sha256.lower(): raise SystemExit('CLI SHA-256 does not match --cli-sha256')
    if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('workspace target must be absent')

    compare_path = root / COMPARE_REL
    if hashlib.sha256(compare_path.read_bytes()).hexdigest() != COMPARE_SHA256: raise SystemExit('compare.py pin mismatch')
    compare = load(compare_path, 'loop_arm_api_compare')
    if compare.sha(compare_path) != COMPARE_SHA256: raise SystemExit('compare helper SHA mismatch')
    guard_path, scanner_path = root/compare.GUARD_REL, root/compare.SCANNER_REL
    if compare.sha(guard_path) != compare.GUARD_SHA256 or compare.sha(scanner_path) != compare.SCANNER_SHA256:
        raise SystemExit('run guard/scanner source pin mismatch')
    guard = load(guard_path,'loop_arm_api_guard'); scanner = load(scanner_path,'loop_arm_api_scanner')
    jdk_manifest = root/JDK_MANIFEST_REL
    jdks, jdk_record = compare.configured_jdks(jdk_manifest, JDK_MANIFEST_SHA256)
    helper_pins={'compare':compare.pin(compare_path),'guard':compare.pin(guard_path),
                 'scanner':compare.pin(scanner_path),'jdk_manifest':compare.pin(jdk_manifest)}
    helper = load(Path(__file__).with_name('classfile_helpers.py'),'loop_arm_api_classfile')
    source_before = compare.source_closure(root)

    archive_review_raw = ARCHIVE_REVIEW.read_bytes(); archive_review = json.loads(archive_review_raw)
    if archive_review.get('status') != 'accepted': raise SystemExit('root archive review is not accepted')
    archive_review_pin = compare.pin(ARCHIVE_REVIEW)
    archive_rows={row['archive']['path']:row for row in archive_review.get('archives',[])}
    old_inputs=[]
    for label,directory,oldroot,schema,valid_status in (
        ('original',ORIGINAL_ARCHIVE_DIR,BASE_RUN_ROOT,EXPECTED_ORIGINAL_SCHEMA,'captured-pending-independent-review'),
        ('supplemental',SUPPLEMENTAL_ARCHIVE_DIR,SUPP_RUN_ROOT,EXPECTED_SUPP_SCHEMA,'captured; outcomes require independent review')):
        archive_path=directory/'capture.tar.gz'; key=str(archive_path)
        if key not in archive_rows: raise SystemExit(f'{label} archive absent from accepted archive review')
        accepted=archive_rows[key]
        bundle=archive_bundle(directory,{'bytes':accepted['archive']['bytes'],'sha256':accepted['archive']['sha256'],
            'capture_review_members_reopened':accepted['archive']['capture_review_members_reopened'],'old_run_root':str(oldroot)})
        tf=tarfile.open(bundle['archive'],'r:gz')
        names=[m.name for m in tf.getmembers()]
        if len(names)!=len(set(names)) or len(names)!=bundle['capture_review']['members_reopened']:
            raise SystemExit(f'{label} archive member inventory differs from capture review')
        if any(not m.isfile() for m in tf.getmembers()): raise SystemExit(f'{label} archive contains non-regular member')
        receipt_stream=tf.extractfile('execution.json')
        if receipt_stream is None: raise SystemExit(f'{label} archive lacks execution.json')
        receipt_raw=receipt_stream.read(); receipt=json.loads(receipt_raw)
        if receipt.get('schema')!=schema or receipt.get('status')!=valid_status:
            raise SystemExit(f'{label} receipt schema/status differs from accepted baseline')
        bundle.update({'label':label,'tf':tf,'receipt':receipt,'receipt_raw':receipt_raw,
                       'receipt_pin':{'archive_member':'execution.json','bytes':len(receipt_raw),'sha256':hashlib.sha256(receipt_raw).hexdigest()}})
        old_inputs.append(bundle)
    original, supplemental = old_inputs
    original_doc, supplemental_doc = original['receipt'], supplemental['receipt']
    if len(original_doc.get('jarde_cells',[]))!=8 or len(supplemental_doc.get('jarde_cells',[]))!=16:
        raise SystemExit('old API receipts do not contain exactly the expected 8+16 source cells')

    # Check fixture manifests and exact fixture bytes against the captured baseline class pins.
    original_manifest_path=FIXTURES/'original/manifest.json'; supplemental_manifest_path=FIXTURES/'supplemental/manifest.json'
    original_manifest=json.loads(original_manifest_path.read_bytes()); supplemental_manifest=json.loads(supplemental_manifest_path.read_bytes())
    if original_manifest.get('baseline_product')!=original_doc.get('product_revision'):
        raise SystemExit('original fixture manifest/product differs from archived receipt')
    if supplemental_manifest.get('baseline_product')!=supplemental_doc.get('product_revision'):
        raise SystemExit('supplemental fixture manifest/product differs from archived receipt')
    manifest_pins={'original':compare.pin(original_manifest_path),'supplemental':compare.pin(supplemental_manifest_path)}
    file_manifests={
        'original':{x['path']:x for x in original_manifest['files']},
        'supplemental':{x['path']:x for x in supplemental_manifest['files']},
    }
    out.mkdir(parents=True)
    class_inputs=[]; input_by_key={}; output_classes=out/'inputs/classes'; output_jars=out/'inputs/bundles'
    output_classes.mkdir(parents=True); output_jars.mkdir(parents=True)

    def register_class(kind:str, variant:str, compiler:str|None, profile:str, fixture_rel:str, archived_pin:dict, oldroot:Path, tf:tarfile.TarFile):
        fixture_path=FIXTURES/fixture_rel; file_row=file_manifests[kind].get(fixture_rel)
        if file_row is None: raise RuntimeError(f'manifest lacks fixture {fixture_rel}')
        fixture_pin=compare.pin(fixture_path)
        if fixture_pin['bytes']!=file_row['bytes'] or fixture_pin['sha256']!=file_row['sha256']:
            raise RuntimeError(f'fixture differs from manifest: {fixture_rel}')
        _, archived_bytes=read_pin_from_tar(tf,oldroot,archived_pin,f'archived input class {fixture_rel}')
        if archived_bytes!=fixture_path.read_bytes(): raise RuntimeError(f'fixture differs from archived class bytes: {fixture_rel}')
        cf=helper.parse_class_file(archived_bytes)
        if cf['major']!=52 or any(m['code'] is None for m in cf['methods']):
            raise RuntimeError(f'fixture is not a complete Java 8 class: {fixture_rel}')
        key=(kind,variant,compiler,profile)
        if key in input_by_key: return input_by_key[key]
        name=(fixture_path.name if kind=='supplemental' else 'TestNestedLoops5$TestCls.class')
        dest=output_classes/('original' if kind=='original' else variant)/(compiler or 'javac23')/profile/name
        dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(archived_bytes)
        copy_pin=compare.pin(dest)
        row={'id':len(class_inputs)+1,'kind':kind,'variant':variant,'compiler':compiler,'profile':profile,
             'fixture':compare.pin(fixture_path),'fixture_manifest_row':file_row,'archived_class_pin':archived_pin,
             'input_copy':copy_pin,'class_name':cf['class_name'],
             'methods':[{'name':m['name'],'descriptor':m['descriptor'],'access':m['access'],'index':m['index'],
                         'code_length':m['code']['code_length'],'bcis':m['code']['bcis']} for m in cf['methods']]}
        class_inputs.append(row); input_by_key[key]=row; return row

    # Original classfiles and exact historic classpath archives.
    original_profiles={p['profile']:p for p in original_doc['profiles']}
    if set(original_profiles)!=set(PROFILES): raise SystemExit('original fixture profiles incomplete')
    original_class_rows={}
    for profile in PROFILES:
        profile_doc=original_profiles[profile]; target_pin=profile_doc['target']
        fixture_rel=f'original/{profile}/classes/jadx/tests/integration/loops/TestNestedLoops5$TestCls.class'
        original_class_rows[profile]=register_class('original','original',None,profile,fixture_rel,target_pin,original['old_run_root'],original['tf'])
    original_cells={(c['profile'],c['input_form'],c['evidence']):c for c in original_doc['jarde_cells']}
    if set(original_cells)!={(p,f,e) for p in PROFILES for f in ('child','bundle-child') for e in EVIDENCE}:
        raise SystemExit('old original API grid selector mismatch')
    input_sources=[]
    for profile in PROFILES:
        for form in ('child','bundle-child'):
            exemplar=original_cells[(profile,form,'default')]
            if form=='child':
                targetrow=original_class_rows[profile]; original_pin=exemplar['input']
                if original_pin['bytes']!=targetrow['input_copy']['bytes'] or original_pin['sha256']!=targetrow['input_copy']['sha256']:
                    raise SystemExit(f'old direct input differs from fixture class {profile}')
                input_path=Path(targetrow['input_copy']['path']); input_pin=targetrow['input_copy']
            else:
                old_member,jar_bytes=read_pin_from_tar(original['tf'],original['old_run_root'],exemplar['input'],f'baseline {profile} bundle jar')
                jar_source=output_jars/profile/'TestNestedLoops5.jar'; jar_source.parent.mkdir(parents=True,exist_ok=True); jar_source.write_bytes(jar_bytes)
                input_path=jar_source; input_pin=compare.pin(jar_source)
                target_entry='jadx/tests/integration/loops/TestNestedLoops5$TestCls.class'
                outer_entry='jadx/tests/integration/loops/TestNestedLoops5.class'
                with zipfile.ZipFile(jar_source) as jar:
                    if jar.read(target_entry)!=Path(original_class_rows[profile]['fixture']['path']).read_bytes():
                        raise RuntimeError(f'{profile} old archive target differs from frozen fixture')
                old_class_set={Path(p['path']).name:p for p in original_profiles[profile]['class_files']}
                outer_fixture=f'original/{profile}/classes/jadx/tests/integration/loops/TestNestedLoops5.class'
                outer_manifest=file_manifests['original'][outer_fixture]
                outer_path=FIXTURES/outer_fixture
                if compare.pin(outer_path)['sha256']!=outer_manifest['sha256'] or compare.pin(outer_path)['bytes']!=outer_manifest['bytes']:
                    raise RuntimeError(f'{profile} outer fixture differs from manifest')
                with zipfile.ZipFile(jar_source) as jar:
                    if jar.read(outer_entry)!=outer_path.read_bytes(): raise RuntimeError(f'{profile} old archive owner differs from fixture')
            bundle_id=f'original-{profile}-{form}'
            input_sources.append({'id':bundle_id,'kind':'original','profile':profile,'form':form,
                                  'path':str(input_path),'pin':input_pin,'original_input_pin':exemplar['input'],
                                  'target_class_input':original_class_rows[profile]['input_copy']})

    # Supplementary A/B classfiles are already frozen; the collector only reads/copies them.
    supp_profiles={(p['variant'],p['compiler'],p['profile']):p for p in supplemental_doc['class_profiles']}
    if set(supp_profiles)!={(v,c,p) for v in ('A','B') for c in SUPPILERS for p in PROFILES}:
        raise SystemExit('supplementary class profile grid is incomplete')
    supp_class_rows={}
    for (variant,compiler,profile), prof in supp_profiles.items():
        cname=f'NestedReturn{variant}$TestCls.class'
        fixture_rel=f'supplemental/{variant}/{compiler}/{profile}/classes/{cname}'
        supp_class_rows[(variant,compiler,profile)]=register_class('supplemental',variant,compiler,profile,
            fixture_rel,prof['target_pin'],supplemental['old_run_root'],supplemental['tf'])
        outer_rel=f'supplemental/{variant}/{compiler}/{profile}/classes/NestedReturn{variant}.class'
        outerrow=file_manifests['supplemental'].get(outer_rel)
        if outerrow is None: raise RuntimeError(f'supplemental manifest lacks outer class {outer_rel}')
        outer_path=FIXTURES/outer_rel
        if compare.pin(outer_path)['bytes']!=outerrow['bytes'] or compare.pin(outer_path)['sha256']!=outerrow['sha256']:
            raise RuntimeError(f'supplemental outer fixture mismatch {outer_rel}')
    supp_cells={(c['variant'],c['compiler'],c['profile'],c['evidence']):c for c in supplemental_doc['jarde_cells']}
    if set(supp_cells)!={(v,c,p,e) for v in ('A','B') for c in SUPPILERS for p in PROFILES for e in EVIDENCE}:
        raise SystemExit('supplementary API baseline grid selector mismatch')
    for variant in ('A','B'):
        for compiler in SUPPILERS:
            for profile in PROFILES:
                c0=supp_cells[(variant,compiler,profile,'default')]
                cprof=supp_profiles[(variant,compiler,profile)]
                if cprof['target_pin']['sha256']!=supp_class_rows[(variant,compiler,profile)]['input_copy']['sha256']:
                    raise SystemExit('supplementary target pin and copied class disagree')
                input_sources.append({'id':f'supp-{variant}-{compiler}-{profile}','kind':'supplemental','variant':variant,
                    'compiler':compiler,'profile':profile,'form':'child','path':supp_class_rows[(variant,compiler,profile)]['input_copy']['path'],
                    'pin':supp_class_rows[(variant,compiler,profile)]['input_copy'],'original_input_pin':cprof['target_pin'],
                    'target_class_input':supp_class_rows[(variant,compiler,profile)]['input_copy']})

    # Bind old API reports for exact controls; all report bytes come from the accepted baseline archives.
    old_report_refs={}
    for key,cell in original_cells.items():
        member,data=read_pin_from_tar(original['tf'],original['old_run_root'],cell['report'],f'old original report {key}')
        command=next(r for r in original_doc['commands'] if r['index']==cell['command'])
        raw_stdout=read_pin_from_tar(original['tf'],original['old_run_root'],command['streams']['stdout'],f'old original raw stdout {key}')[1]
        if raw_stdout!=data: raise SystemExit(f'old original report/stdout differ for {key}')
        old_report_refs['original/'+ '/'.join(key)]={'member':member,'pin':cell['report']}
    for key,cell in supp_cells.items():
        member,data=read_pin_from_tar(supplemental['tf'],supplemental['old_run_root'],cell['report'],f'old supplemental report {key}')
        command=next(r for r in supplemental_doc['commands'] if r['index']==cell['command'])
        raw_stdout=read_pin_from_tar(supplemental['tf'],supplemental['old_run_root'],command['streams']['stdout'],f'old supplemental raw stdout {key}')[1]
        if raw_stdout!=data: raise SystemExit(f'old supplemental report/stdout differ for {key}')
        old_report_refs['supplemental/'+'/'.join(key)]={'member':member,'pin':cell['report']}

    raw_dir=out/'raw'; raw_dir.mkdir()
    guard.ROOT,guard.OUT=root,raw_dir
    guard.target_bytes=lambda:scanner.target_bytes(root)
    guard.command_stream=compare.pin
    guard.expected_test_summaries=lambda _index,_stdout:None
    rows=[]; input_lookup={x['id']:x for x in input_sources}
    cli_record=compare.pin(cli)
    report={'schema':'cf11-nl5-ab-loop-arm-api-capture-v1','status':'running','root':str(root),
        'product_revision':args.product_revision,'cli':cli_record,'cli_sha256_argument':args.cli_sha256.lower(),
        'source_closure_before':source_before,'source_closure_after':None,'source_unchanged':False,
        'target_absent':False,'helper_pins':helper_pins,'jdk_manifest':jdk_record,
        'archive_review':{'path':str(ARCHIVE_REVIEW),'pin':archive_review_pin,'status':archive_review['status']},
        'old_receipts':{b['label']:{'archive':b['archive_pin'],'capture_review':b['capture_review_pin'],
             'receipt':b['receipt_pin'],'schema':b['receipt']['schema'],'status':b['receipt']['status'],
             'product_revision':b['receipt'].get('product_revision'),'old_cli':b['receipt'].get('cli'),
             'source_closure':b['receipt'].get('source_pins_before')} for b in old_inputs},
        'fixture_manifests':manifest_pins,'class_inputs':class_inputs,'cli_inputs':input_sources,
        'old_report_refs':old_report_refs,'commands':rows,'jarde_cells':[],'supplemental_cells':[],
        'notes':['Exactly 24 API calls are scheduled: 8 original NL5 and 16 A/B supplemental reports.',
                 'Inputs are frozen classfiles and the exact old bundle-JAR bytes; no class is recompiled or source modified.',
                 'This receipt records a runtime-supplied CLI pin and product revision plus the live source closure; it does not invoke Git or infer build provenance beyond those supplied identifiers.',
                 'Raw CLI outputs and all parse/quality/fallback/map outcomes are retained; this collection is not acceptance.']}
    compare.write_json(out/'execution.json',report)

    def save(): compare.write_json(out/'execution.json',report)
    def run(label,argv):
        if (root/'target').exists(): raise RuntimeError(f'target appeared before {label}')
        env=compare.clean_env(dict(os.environ),jdks['javac23']);env.update(guard.ENV_VALUES);env.pop('RUST_MIN_STACK',None)
        row=guard.run_command(len(rows)+1,[str(x) for x in argv],env);row['label']=label;row['tool_leg']='cli'
        rows.append(row);save()
        if row.get('guard_stop') is not None: raise RuntimeError(f'guard stopped {label}: {row["guard_stop"]}')
        return row

    def store_cell(kind, selectors, label, input_row, prior_cell, archive_bundle_row):
        evidence=selectors['evidence']; inp=Path(input_row['path']); before=compare.pin(inp)
        if before!=input_row['pin']: raise RuntimeError(f'CLI input changed before {label}')
        class_bytes=Path(input_row['target_class_input']['path']).read_bytes()
        if inp.suffix=='.jar':
            with zipfile.ZipFile(inp) as jar:
                target_entry='jadx/tests/integration/loops/TestNestedLoops5$TestCls.class'
                class_bytes=jar.read(target_entry)
        classfacts=helper.parse_class_file(class_bytes)
        internal=classfacts['class_name']
        policy='plain-jar' if inp.suffix=='.jar' else 'single-class'
        argv=[cli,'class-source','--input',inp,'--class',internal,'--policy',policy,'--release','8','--format','json']
        if evidence=='all': argv+=['--evidence','all']
        row=run(label,argv); stdout=compare.command_artifact(row,'stdout'); stderr=compare.command_artifact(row,'stderr')
        report_dir=out/'jarde'/(selectors['profile'] if kind=='original' else selectors['variant'])
        if kind=='supplemental': report_dir=report_dir/selectors['compiler']/selectors['profile']/evidence
        else: report_dir=report_dir/selectors['input_form']/evidence
        report_dir.mkdir(parents=True,exist_ok=True)
        report_path=report_dir/'report.json';report_path.write_bytes(stdout)
        cell={'kind':kind,**selectors,'command':row['index'],'input':before,'original_input_pin':input_row['original_input_pin'],
              'target_class_input':input_row['target_class_input'],'exit_code':row['exit_code'],'stdout_sha256':hashlib.sha256(stdout).hexdigest(),
              'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'report':compare.pin(report_path),'json_parsed':False,
              'methods':[],'method_inventory_matches':False,'parse_error':None,'whole_source':None,
              'prior_report':prior_cell['report'],'prior_report_member':archive_bundle_row['prior_member']}
        try:
            doc=json.loads(stdout.decode('utf-8','strict'))
            if not isinstance(doc,dict) or not isinstance(doc.get('text'),str) or not isinstance(doc.get('methods'),list):
                raise ValueError('report lacks text/methods')
            cell['json_parsed']=True;cell['method_inventory']=[source_method_projection(m) for m in doc['methods']]
            cell['methods']=[{k:m.get(k) for k in ('identity','outcome_kind','quality','fallbacks','regions','source_map')}
                             for m in cell['method_inventory']]
            source_bytes=doc['text'].encode('utf-8'); source_path=report_dir/'whole-source.java';source_path.write_bytes(source_bytes)
            cell['whole_source']=compare.pin(source_path);cell['report_text_sha256']=hashlib.sha256(source_bytes).hexdigest()
            cell['top_outcome']=doc.get('outcome');cell['usage']=doc.get('usage')
        except (UnicodeDecodeError,ValueError,TypeError,KeyError) as exc:
            cell['parse_error']=f'{type(exc).__name__}: {exc}'
            source_path=report_dir/'whole-source.java';source_path.write_bytes(b'')
            cell['whole_source']=compare.pin(source_path)
        after=compare.pin(inp)
        if after!=before: raise RuntimeError(f'CLI input changed during {label}')
        cell['input_after']=after
        if kind=='original': report['jarde_cells'].append(cell)
        else: report['supplemental_cells'].append(cell)
        save()

    try:
        # Original NL5: 2 profiles × (direct class, exact archived jar) × evidence levels.
        for profile in PROFILES:
            for form in ('child','bundle-child'):
                inputrow=next(x for x in input_sources if x['id']==f'original-{profile}-{form}')
                for evidence in EVIDENCE:
                    key=(profile,form,evidence); prior=original_cells[key]
                    prior_member=old_report_refs['original/'+ '/'.join(key)]['member']
                    store_cell('original',{'profile':profile,'input_form':form,'evidence':evidence},
                        f'jarde-original-{profile}-{form}-{evidence}',inputrow,prior,
                        {'prior_member':prior_member})
        # A/B: 2 variants × 2 exact compilers × 2 profiles × evidence levels.
        for variant in ('A','B'):
            for compiler in SUPPILERS:
                for profile in PROFILES:
                    inputrow=next(x for x in input_sources if x['id']==f'supp-{variant}-{compiler}-{profile}')
                    for evidence in EVIDENCE:
                        key=(variant,compiler,profile,evidence);prior=supp_cells[key]
                        prior_member=old_report_refs['supplemental/'+'/'.join(key)]['member']
                        store_cell('supplemental',{'variant':variant,'compiler':compiler,'profile':profile,'input_form':'child','evidence':evidence},
                            f'jarde-supplemental-{variant}-{compiler}-{profile}-{evidence}',inputrow,prior,
                            {'prior_member':prior_member})
        if len(rows)!=24: raise RuntimeError(f'expected 24 CLI calls, made {len(rows)}')
        report['source_closure_after']=compare.source_closure(root)
        report['cli_after']=compare.pin(cli)
        report['helper_pins_after']={'compare':compare.pin(compare_path),'guard':compare.pin(guard_path),
            'scanner':compare.pin(scanner_path),'jdk_manifest':compare.pin(jdk_manifest)}
        report['fixture_manifests_after']={'original':compare.pin(original_manifest_path),'supplemental':compare.pin(supplemental_manifest_path)}
        report['class_inputs_after']=[{**{k:r[k] for k in ('id','kind','variant','compiler','profile')},'fixture':compare.pin(Path(r['fixture']['path'])),
             'input_copy':compare.pin(Path(r['input_copy']['path']))} for r in class_inputs]
        report['cli_inputs_after']=[{**{k:r[k] for k in ('id','kind','profile','form','variant','compiler') if k in r},
             'pin':compare.pin(Path(r['path']))} for r in input_sources]
        report['archives_after']={b['label']:{'archive':compare.pin(b['archive']),'capture_review':compare.pin(Path(b['capture_review_pin']['path']))}
            for b in old_inputs}
        if report['source_closure_after']!=source_before: raise RuntimeError('workspace source closure changed during API capture')
        if report['cli_after']!=cli_record: raise RuntimeError('CLI binary changed during API capture')
        if report['helper_pins_after']!=helper_pins: raise RuntimeError('collector helper source changed during capture')
        if (root/'target').exists(): raise RuntimeError('workspace target appeared during API capture')
        report['source_unchanged']=True;report['target_absent']=True;report['status']='captured-pending-independent-review'
    except BaseException as exc:
        report['status']='failed';report['error']=f'{type(exc).__name__}: {exc}';raise
    finally:
        report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out/'execution.json',report);shutil.copy2(__file__,out/'collector.py')
        print(json.dumps({'status':report['status'],'calls':len(rows),'original_cells':len(report['jarde_cells']),
                          'supplemental_cells':len(report['supplemental_cells']),'out':str(out)}))
    return 0

if __name__=='__main__': raise SystemExit(main())
