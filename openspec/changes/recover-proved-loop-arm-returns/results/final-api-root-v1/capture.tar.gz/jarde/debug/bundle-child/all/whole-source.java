// jarde: presentation of `jadx/tests/integration/loops/TestNestedLoops5$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestNestedLoops5$TestCls extends java.lang.Object {
    public TestNestedLoops5$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestNestedLoops5$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public int testFor() {
        // @method testFor()I
        // @declaration an instance method of `jadx.tests.integration.loops.TestNestedLoops5$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int tmp;
        int i;
        tmp = 1;
        i = 5;
        while (i > -1) {
            if (i > tmp) {
                int j;
                for (j = 1; j < 5; j = j + 1) {
                    if (tmp > j * 100) {
                        return 0;
                    }
                }
            }
            tmp = tmp + 1;
            i = i - 1;
        }
        return tmp;
    }

    public void check() {
        // @method check()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestNestedLoops5$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat(this.testFor()).isEqualTo(7);
        return;
    }
}
