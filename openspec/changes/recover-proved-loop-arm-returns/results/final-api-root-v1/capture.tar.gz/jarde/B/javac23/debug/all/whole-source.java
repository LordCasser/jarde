// jarde: presentation of `NestedReturnB$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class NestedReturnB$TestCls extends java.lang.Object {
    private int innerVisits;

    private int tailVisits;

    private int tailSum;

    private int earlyReturns;

    private int rolling;

    public NestedReturnB$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `NestedReturnB$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public int run(int returnOuter, int innerLimit, int gate, int returnInner, int outerLimit) {
        // @method run(IIIII)I
        // @declaration an instance method of `NestedReturnB$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int localTail;
        int i;
        localTail = 0;
        i = outerLimit;
        while (i > 0) {
            if (i > gate) {
                int childSeed;
                int j;
                childSeed = i + 2;
                int firstJ = 0;
                for (j = firstJ; j < innerLimit; j = j + 1) {
                    int value = childSeed + j;
                    this.innerVisits += 1;
                    this.rolling = this.rolling * 29 + value;
                    if (i == returnOuter) {
                        if (j == returnInner) {
                            this.earlyReturns += 1;
                            return 0;
                        }
                    }
                }
            }
            this.tailVisits += 1;
            this.tailSum += i;
            localTail = localTail + i;
            this.rolling = this.rolling * 41 + i;
            i = i - 1;
        }
        return localTail;
    }
}
