// jarde: presentation of `NestedReturnB$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public final class NestedReturnB$TestCls extends java.lang.Object {
    private int innerVisits;

    private int tailVisits;

    private int tailSum;

    private int earlyReturns;

    private int rolling;

    public NestedReturnB$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `NestedReturnB$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public int run(int arg1, int arg2, int arg3, int arg4, int arg5) {
        // @method run(IIIII)I
        // @declaration an instance method of `NestedReturnB$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int local6;
        int local7;
        local6 = 0;
        local7 = arg5;
        while (local7 > 0) {
            if (local7 > arg3) {
                int local8;
                int local10;
                local8 = local7 + 2;
                int local9 = 0;
                for (local10 = local9; local10 < arg2; local10 = local10 + 1) {
                    int local11 = local8 + local10;
                    this.innerVisits += 1;
                    this.rolling = this.rolling * 29 + local11;
                    if (local7 == arg1) {
                        if (local10 == arg4) {
                            this.earlyReturns += 1;
                            return 0;
                        }
                    }
                }
            }
            this.tailVisits += 1;
            this.tailSum += local7;
            local6 = local6 + local7;
            this.rolling = this.rolling * 41 + local7;
            local7 = local7 - 1;
        }
        return local6;
    }
}
