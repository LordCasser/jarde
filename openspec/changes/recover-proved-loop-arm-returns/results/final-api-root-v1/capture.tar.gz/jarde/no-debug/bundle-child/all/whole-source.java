// jarde: presentation of `jadx/tests/integration/loops/TestNestedLoops5$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestNestedLoops5$TestCls extends java.lang.Object {
    public TestNestedLoops5$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestNestedLoops5$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public int testFor() {
        // @method testFor()I
        // @declaration an instance method of `jadx.tests.integration.loops.TestNestedLoops5$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        int local1;
        int local2;
        local1 = 1;
        local2 = 5;
        while (local2 > -1) {
            if (local2 > local1) {
                int local3;
                for (local3 = 1; local3 < 5; local3 = local3 + 1) {
                    if (local1 > local3 * 100) {
                        return 0;
                    }
                }
            }
            local1 = local1 + 1;
            local2 = local2 - 1;
        }
        return local1;
    }

    public void check() {
        // @method check()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestNestedLoops5$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat(this.testFor()).isEqualTo(7);
        return;
    }
}
