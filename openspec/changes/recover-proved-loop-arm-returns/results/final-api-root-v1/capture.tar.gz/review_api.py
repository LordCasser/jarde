#!/usr/bin/env python3
"""Independent read-only acceptance review for the final NL5/A-B API replay."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, re, tarfile
from contextlib import ExitStack
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
CHANGE=ROOT/'openspec/changes/recover-proved-loop-arm-returns'
FIXTURES=ROOT/'tests/fixtures/recover-proved-loop-arm-returns'
ARCHIVE_REVIEW=CHANGE/'results/baseline-archive-review-root.json'
ORIG_ARCHIVE=CHANGE/'results/original-baseline-root-v3/capture.tar.gz'
SUPP_ARCHIVE=CHANGE/'results/supplemental-baseline-root-v1/capture.tar.gz'
COMPARE=ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
HELPER=Path(__file__).with_name('classfile_helpers.py')
PROFILES=('debug','no-debug'); EVIDENCE=('default','all')


def need(ok,msg):
    if not ok: raise ValueError(msg)
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(path):
    path=Path(path).resolve(strict=True); b=path.read_bytes()
    return {'path':str(path),'bytes':len(b),'sha256':sha(b)}
def verify_pin(row,label):
    need(isinstance(row,dict),f'{label}: pin missing')
    path=Path(row.get('path',''))
    need(path.is_absolute() and path.is_file(),f'{label}: path missing {path}')
    actual=pin(path); need(actual==row,f'{label}: pin differs'); return path.read_bytes()
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    need(spec is not None and spec.loader is not None,f'cannot import {path}')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def method_projection(m):
    item=m.get('item') or {}; ident=item.get('identity') or {}; out=m.get('outcome') or {}; rep=out.get('report') or {}
    name=bytes(ident.get('name',[])).decode('utf-8','strict')
    desc=bytes(ident.get('descriptor',[])).decode('utf-8','strict')
    return {'identity':[name,desc],'owner':ident.get('owner'),'index':item.get('index'),
        'access_flags':item.get('access_flags'),'outcome_kind':out.get('kind'),
        'quality':rep.get('quality'),'fallbacks':rep.get('fallbacks'),'regions':rep.get('regions'),
        'source_map':rep.get('source_map'),'method_text':m.get('text'),'report_text':rep.get('text')}
def archive_receipt(path,label,stack):
    tf=stack.enter_context(tarfile.open(path,'r:gz'))
    stream=tf.extractfile('execution.json')
    need(stream is not None,f'{label}: archive lacks execution.json')
    return json.loads(stream.read()),tf

def old_report(tf,member):
    f=tf.extractfile(member); need(f is not None,f'missing old report member {member}')
    return json.loads(f.read())
def owner_for(method):
    return method['item']['identity']['owner']
def check_map(method, classfacts, expected_owner, label):
    report=method.get('outcome',{}).get('report') or {}
    sm=report.get('source_map') or {}; segments=sm.get('segments')
    need(isinstance(segments,list),f'{label}: source-map segments absent')
    text=report.get('text'); need(isinstance(text,str),f'{label}: mapped report text absent')
    raw=text.encode('utf-8'); bounds={0,len(raw)}|{i for i,b in enumerate(raw) if b&0xc0!=0x80}
    facts={(m['name'],m['descriptor']):set(m['code']['bcis']) for m in classfacts['methods'] if m.get('code')}
    current_item=method.get('item') or {}; current_ident=current_item.get('identity') or {}
    current=(bytes(current_ident.get('name',[])).decode('utf-8','strict'),bytes(current_ident.get('descriptor',[])).decode('utf-8','strict'))
    need(current in facts,f'{label}: method missing from physical class')
    seen=set()
    for i,s in enumerate(segments):
        start,end=s.get('start'),s.get('end')
        need(isinstance(start,int) and isinstance(end,int) and 0<=start<=end<=len(raw),f'{label}: invalid source-map interval #{i}')
        need(start in bounds and end in bounds,f'{label}: interval #{i} splits UTF-8')
        origin=s.get('origin') or {}
        for entry in [origin.get('primary'),*(origin.get('derived') or [])]:
            if entry is None: continue
            mi=entry.get('method') or {}; name=bytes(mi.get('name',[])).decode('utf-8','strict'); desc=bytes(mi.get('descriptor',[])).decode('utf-8','strict')
            need(mi.get('owner')==expected_owner,f'{label}: origin owner differs for {name}{desc}')
            need((name,desc) in facts,f'{label}: origin method missing from physical class {name}{desc}')
            bci=entry.get('bci'); need(isinstance(bci,int) and bci in facts[(name,desc)],f'{label}: origin BCI is not a physical instruction: {name}{desc}@{bci}')
            need((name,desc)==current,f'{label}: source map references another method {name}{desc}')
            seen.add(bci)
    need(seen==facts[current],f'{label}: source map BCI coverage differs: missing={sorted(facts[current]-seen)}, extra={sorted(seen-facts[current])}')
def expected_old_projection(kind,selectors,orig,supp):
    if kind=='original':
        cell=next(c for c in orig['jarde_cells'] if (c['profile'],c['input_form'],c['evidence'])==(selectors['profile'],selectors['input_form'],selectors['evidence']))
        return cell
    cell=next(c for c in supp['jarde_cells'] if (c['variant'],c['compiler'],c['profile'],c['evidence'])==(selectors['variant'],selectors['compiler'],selectors['profile'],selectors['evidence']))
    return cell

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('execution',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args()
    receipt_path=a.execution.resolve(strict=True); out=a.output.resolve()
    need(not out.exists(),'refusing to overwrite review output')
    need(out.is_relative_to(Path('/private/tmp')),'review output must be under /private/tmp')
    d=json.loads(receipt_path.read_bytes()); need(d.get('schema')=='cf11-nl5-ab-loop-arm-api-capture-v1','wrong API receipt schema')
    need(d.get('status')=='captured-pending-independent-review','API receipt not in captured state')
    root=Path(d['root']).resolve(strict=True); need(root==ROOT.resolve(),'workspace root mismatch')
    compare=load(COMPARE,'loop_arm_api_independent_compare'); helper=load(HELPER,'loop_arm_api_independent_class')
    need(d['source_unchanged'] and d['target_absent'],'capture did not prove source/target final state')
    need(d['source_closure_before']==d['source_closure_after']==compare.source_closure(root),'source closure changed')
    need(not (root/'target').exists(),'workspace target exists')
    cli=verify_pin(d['cli'],'CLI'); need(d['cli_after']==d['cli'],'CLI changed during capture')
    need(d['cli_sha256_argument']==d['cli']['sha256'],'CLI argument pin mismatch')
    need(isinstance(d.get('product_revision'),str) and d['product_revision'].strip(),'product revision absent')
    for key,p in d['helper_pins'].items(): verify_pin(p,f'helper {key}')
    for key,p in d['fixture_manifests'].items(): verify_pin(p,f'{key} fixture manifest')
    need(d.get('helper_pins_after')==d['helper_pins'],'helper pins changed')
    need(d['archive_review']['status']=='accepted','baseline archive review not accepted')
    need(verify_pin(d['archive_review']['pin'],'accepted archive review')==ARCHIVE_REVIEW.read_bytes(),'archive review source mismatch')
    ar=json.loads(ARCHIVE_REVIEW.read_bytes()); need(ar.get('status')=='accepted','accepted archive review status changed')
    review_map={r['archive']['path']:r for r in ar['archives']}
    origrow=review_map[str(ORIG_ARCHIVE)]; supprow=review_map[str(SUPP_ARCHIVE)]
    need(pin(ORIG_ARCHIVE)['bytes']==origrow['archive']['bytes'] and pin(ORIG_ARCHIVE)['sha256']==origrow['archive']['sha256'],'original archive differs from accepted pin')
    need(pin(SUPP_ARCHIVE)['bytes']==supprow['archive']['bytes'] and pin(SUPP_ARCHIVE)['sha256']==supprow['archive']['sha256'],'supplement archive differs from accepted pin')
    with ExitStack() as archive_stack:
        od,ot=archive_receipt(ORIG_ARCHIVE,'original',archive_stack); sd,st=archive_receipt(SUPP_ARCHIVE,'supplemental',archive_stack)
        need(d['old_receipts']['original']['archive']==pin(ORIG_ARCHIVE),'original receipt archive pin differs')
        need(d['old_receipts']['supplemental']['archive']==pin(SUPP_ARCHIVE),'supplemental receipt archive pin differs')
        need(d['old_receipts']['original']['receipt']['sha256']==sha(ot.extractfile('execution.json').read()),'original old receipt pin mismatch')
        need(d['old_receipts']['supplemental']['receipt']['sha256']==sha(st.extractfile('execution.json').read()),'supplemental old receipt pin mismatch')
        need(len(d['commands'])==24,'expected exactly 24 API command rows')
        commands={r['index']:r for r in d['commands']};need(len(commands)==24 and set(commands)==set(range(1,25)),'command index census invalid')
        for i,c in commands.items():
            need(c.get('guard_stop') is None,f'guard stopped command {i}')
            for stream in ('stdout','stderr'): verify_pin(c['streams'][stream],f'command {i} {stream}')
        original_manifest=json.loads(verify_pin(d['fixture_manifests']['original'],'original fixture manifest'))
        supplemental_manifest=json.loads(verify_pin(d['fixture_manifests']['supplemental'],'supplemental fixture manifest'))
        need(original_manifest.get('baseline_product')==d['old_receipts']['original'].get('product_revision'),'original fixture/baseline product mismatch')
        need(supplemental_manifest.get('baseline_product')==d['old_receipts']['supplemental'].get('product_revision'),'supplemental fixture/baseline product mismatch')
        need(d['old_receipts']['original'].get('schema')=='cf11-original-testnestedloops5-baseline-v1' and d['old_receipts']['original'].get('status')=='captured-pending-independent-review','original old receipt identity/status mismatch')
        need(d['old_receipts']['supplemental'].get('schema')=='cf11-testnestedloops5-parameterized-baseline-v1' and d['old_receipts']['supplemental'].get('status')=='captured; outcomes require independent review','supplemental old receipt identity/status mismatch')
        need(len(d['class_inputs'])==10 and len(d['cli_inputs'])==12,'class or CLI input inventory count differs')
        classfacts={}
        for row in d['class_inputs']:
            fbytes=verify_pin(row['fixture'],f"fixture {row['fixture']['path']}")
            need(row['fixture_manifest_row']['bytes']==len(fbytes) and row['fixture_manifest_row']['sha256']==sha(fbytes),'fixture manifest row mismatch')
            cbytes=verify_pin(row['input_copy'],f"class copy {row['input_copy']['path']}")
            need(cbytes==fbytes,'copied class differs from frozen fixture')
            cf=helper.parse_class_file(cbytes);need(cf['major']==52,'fixture class is not Java 8')
            classesig=[{'name':m['name'],'descriptor':m['descriptor'],'access':m['access'],'index':m['index'],
                        'code_length':m['code']['code_length'],'bcis':m['code']['bcis']} for m in cf['methods']]
            need(row['methods']==classesig,'class input method/Code inventory differs')
            classfacts[str(row['id'])]=cf
        need(len(d['jarde_cells'])==8 and len(d['supplemental_cells'])==16,'expected 8+16 API cells')
        cell_keys=set(); used_commands=set(); verified=0; control_count=0; target_count=0; pair_checks=0
        for kind,cells in (('original',d['jarde_cells']),('supplemental',d['supplemental_cells'])):
            for cell in cells:
                if kind=='original': key=(cell['profile'],cell['input_form'],cell['evidence']); expected={(p,f,e) for p in PROFILES for f in ('child','bundle-child') for e in EVIDENCE}
                else: key=(cell['variant'],cell['compiler'],cell['profile'],cell['evidence']); expected={(v,c,p,e) for v in ('A','B') for c in ('javac8','javac23') for p in PROFILES for e in EVIDENCE}
                prefix=kind+'/'+'/'.join(map(str,key));need(key not in cell_keys,f'duplicate cell {prefix}');cell_keys.add(key)
                need(cell['command'] not in used_commands,f'{prefix}: command reused');used_commands.add(cell['command'])
                cmd=commands[cell['command']];need(cmd['label']==(f"jarde-original-{cell['profile']}-{cell['input_form']}-{cell['evidence']}" if kind=='original' else f"jarde-supplemental-{cell['variant']}-{cell['compiler']}-{cell['profile']}-{cell['evidence']}"),f'{prefix}: command label differs')
                raw=verify_pin(cmd['streams']['stdout'],prefix+' stdout'); err=verify_pin(cmd['streams']['stderr'],prefix+' stderr')
                need(cmd['exit_code']==cell['exit_code']==0,f'{prefix}: CLI command did not exit successfully')
                need(sha(raw)==cell['stdout_sha256'] and sha(err)==cell['stderr_sha256'],f'{prefix}: raw output digest differs')
                report_bytes=verify_pin(cell['report'],prefix+' report');need(report_bytes==raw,f'{prefix}: report is not full stdout')
                need(cell['input']==cell['input_after'],f'{prefix}: input changed during command')
                inp=verify_pin(cell['input'],prefix+' input')
                source_id=(f"original-{cell['profile']}-{cell['input_form']}" if kind=='original' else f"supp-{cell['variant']}-{cell['compiler']}-{cell['profile']}")
                source_row=next((x for x in d['cli_inputs'] if x.get('id')==source_id),None)
                need(source_row is not None and cell['input']==source_row['pin'] and cell['input']['path']==source_row['path'],f'{prefix}: input not bound to frozen source row')
                need(cell['original_input_pin']==source_row['original_input_pin'] and cell['target_class_input']==source_row['target_class_input'],f'{prefix}: target class/original pin differs from source row')
                class_bytes=verify_pin(cell['target_class_input'],prefix+' target class input')
                if Path(cell['input']['path']).suffix=='.jar':
                    import zipfile
                    with zipfile.ZipFile(cell['input']['path']) as jar:
                        entry='jadx/tests/integration/loops/TestNestedLoops5$TestCls.class'
                        need(jar.read(entry)==class_bytes,f'{prefix}: CLI bundle class differs from registered target class')
                else: need(inp==class_bytes,f'{prefix}: direct CLI input differs from target class')
                need(cell['target_class_input']['path'] in {x['input_copy']['path'] for x in d['class_inputs']},f'{prefix}: target class input not registered')
                try: doc=json.loads(raw.decode('utf-8','strict'))
                except Exception as e: raise ValueError(f'{prefix}: CLI report is not strict JSON: {e}')
                need(cell['json_parsed'] and cell['parse_error'] is None,f'{prefix}: collector parse failed')
                source=doc.get('text');need(isinstance(source,str),f'{prefix}: whole source absent')
                source_bytes=source.encode('utf-8');need(verify_pin(cell['whole_source'],prefix+' whole source')==source_bytes,f'{prefix}: whole source artifact differs')
                need(cell['report_text_sha256']==sha(source_bytes),f'{prefix}: whole source digest differs')
                method_list=doc.get('methods'); need(isinstance(method_list,list),f'{prefix}: method list absent')
                clsrow=next(x for x in d['class_inputs'] if x['input_copy']['path']==cell['target_class_input']['path'])
                cf=classfacts[str(clsrow['id'])]; expected_methods=cf['methods']
                internal=cf['class_name']; policy='plain-jar' if Path(cell['input']['path']).suffix=='.jar' else 'single-class'
                argv=[d['cli']['path'],'class-source','--input',cell['input']['path'],'--class',internal,'--policy',policy,'--release','8','--format','json']
                if cell['evidence']=='all': argv+=['--evidence','all']
                need(cmd['argv']==argv,f'{prefix}: actual CLI argv differs from selectors/input')
                need(len(method_list)==len(expected_methods),f'{prefix}: method census count differs')
                projections=[]; expected_owner=None
                for n,(m,fact) in enumerate(zip(method_list,expected_methods)):
                    proj=method_projection(m);projections.append(proj)
                    need(proj['identity']==[fact['name'],fact['descriptor']] and proj['index']==fact['index'] and proj['access_flags']==fact['access'],f'{prefix}: method identity/order/access differs at #{n}')
                    own=owner_for(m);need(isinstance(own,dict) and own.get('class_bytes',{}).get('length')==len(class_bytes),f'{prefix}: owner class length differs from exact class bytes')
                    if expected_owner is None: expected_owner=own
                    need(own==expected_owner,f'{prefix}: method owners differ within report')
                    check_map(m,cf,own,f'{prefix} {fact["name"]}{fact["descriptor"]}')
                need(cell['method_inventory']==projections,f'{prefix}: saved method inventory differs from report')
                need(cell['methods']==[{k:m.get(k) for k in ('identity','outcome_kind','quality','fallbacks','regions','source_map')} for m in projections],f'{prefix}: method summary differs')
                target_name,target_desc=('testFor','()I') if kind=='original' else ('run','(IIIII)I')
                target=next((m for m in method_list if method_projection(m)['identity']==[target_name,target_desc]),None)
                need(target is not None,f'{prefix}: target method missing')
                tr=target.get('outcome',{}).get('report') or {}
                if tr.get('quality')=='structured' and not tr.get('fallbacks'):
                    body=target.get('text') or ''
                    returns=len(re.findall(r'(?m)^\s*return\b',body))
                    need(returns==2,f'{prefix}: target body has {returns} return statements, expected two')
                    need(re.search(r'\bcontinue\s*;',body) is None,f'{prefix}: target introduced continue')
                    target_count+=1
                else: raise ValueError(f'{prefix}: target is not fully structured: quality={tr.get("quality")!r}, fallbacks={tr.get("fallbacks")!r}')
                old_cell=expected_old_projection(kind,cell,od,sd); oldmember=cell['prior_report_member']
                old_archive=ot if kind=='original' else st
                old_stream=old_archive.extractfile(oldmember);need(old_stream is not None,f'{prefix}: prior report member absent')
                old_raw=old_stream.read();oldpin=old_cell['report']
                need(len(old_raw)==oldpin['bytes'] and sha(old_raw)==oldpin['sha256'],f'{prefix}: prior report bytes differ from baseline pin')
                olddoc=json.loads(old_raw)
                need(cell['prior_report']==oldpin,f'{prefix}: prior report pin differs from baseline receipt')
                oldmethods=olddoc.get('methods');need(isinstance(oldmethods,list),f'{prefix}: old report method list missing')
                oldproj=[method_projection(m) for m in oldmethods]
                non_target=[p for p in projections if p['identity'] not in ([target_name,target_desc],)]
                old_non_target=[p for p in oldproj if p['identity'] not in ([target_name,target_desc],)]
                need(non_target==old_non_target,f'{prefix}: non-target method projection changed')
                old_target=next((m for m in oldmethods if method_projection(m)['identity']==[target_name,target_desc]),None)
                need(old_target is not None and owner_for(target)==owner_for(old_target),f'{prefix}: target physical owner identity changed')
                control_count+=len(non_target);verified+=1
        need(cell_keys==({(p,f,e) for p in PROFILES for f in ('child','bundle-child') for e in EVIDENCE}|{(v,c,p,e) for v in ('A','B') for c in ('javac8','javac23') for p in PROFILES for e in EVIDENCE}),'cell selectors incomplete')
        need(used_commands==set(commands),'some CLI commands are unbound to a cell')
        # Compare default/all at both whole-class and per-method source/map level.
        def compare_pair(kind,basekey,selector):
            if kind=='original': rows=[c for c in d['jarde_cells'] if (c['profile'],c['input_form'])==basekey]
            else: rows=[c for c in d['supplemental_cells'] if (c['variant'],c['compiler'],c['profile'])==basekey]
            by={c['evidence']:c for c in rows};need(set(by)==set(EVIDENCE),f'{selector}: evidence pair missing')
            a=json.loads(verify_pin(by['default']['report'],selector+' default'));b=json.loads(verify_pin(by['all']['report'],selector+' all'))
            need(a['text']==b['text'],f'{selector}: default/all text differs')
            pa=[method_projection(m) for m in a['methods']];pb=[method_projection(m) for m in b['methods']]
            need(len(pa)==len(pb),f'{selector}: method counts differ')
            for x,y in zip(pa,pb):
                need(x['identity']==y['identity'] and x['method_text']==y['method_text'] and x['source_map']==y['source_map'],f'{selector}: method text/map differs')
            return 1
        for p in PROFILES:
            for f in ('child','bundle-child'): pair_checks+=compare_pair('original',(p,f),f'original/{p}/{f}')
        for v in ('A','B'):
            for c in ('javac8','javac23'):
                for p in PROFILES: pair_checks+=compare_pair('supplemental',(v,c,p),f'supplemental/{v}/{c}/{p}')
        need(d['fixture_manifests_after']==d['fixture_manifests'],'fixture manifest changed')
        for key,pinrow in d['fixture_manifests'].items(): need(verify_pin(pinrow,f'{key} fixture manifest after')==Path(pinrow['path']).read_bytes(),f'{key} fixture manifest changed')
        need(d['class_inputs_after']==[{**{k:r[k] for k in ('id','kind','variant','compiler','profile')},'fixture':pin(Path(r['fixture']['path'])),'input_copy':pin(Path(r['input_copy']['path']))} for r in d['class_inputs']],'class inputs changed after capture')
        need(len(d['cli_inputs_after'])==len(d['cli_inputs']),'CLI input after-snapshot length differs')
        for before in d['cli_inputs']:
            after=next((x for x in d['cli_inputs_after'] if x.get('id')==before.get('id')),None)
            need(after is not None and after.get('pin')==pin(Path(before['path']))==before['pin'],f"CLI input changed after capture: {before['id']}")
        need(d['archives_after']['original']['archive']==pin(ORIG_ARCHIVE) and d['archives_after']['supplemental']['archive']==pin(SUPP_ARCHIVE),'baseline archive changed during capture')
        for label in ('original','supplemental'):
            need(d['archives_after'][label]['capture_review']==d['old_receipts'][label]['capture_review'],f'{label} capture review changed')
        out.parent.mkdir(parents=True,exist_ok=True)
        result={'status':'accepted','reviewer':pin(__file__),'execution':pin(receipt_path),'cli':d['cli'],'product_revision':d['product_revision'],
          'api_commands':len(commands),'original_cells':len(d['jarde_cells']),'supplemental_cells':len(d['supplemental_cells']),
          'method_configurations':verified and sum(len(c['method_inventory']) for c in d['jarde_cells']+d['supplemental_cells']),
          'target_structured_cells':target_count,'non_target_projections_compared':control_count,'default_all_pairs':pair_checks,
          'source_map_method_checks':sum(len(c['method_inventory']) for c in d['jarde_cells']+d['supplemental_cells']),
          'source_unchanged':True,'target_absent':True,
          'limitations':['BLAKE3 owner digest is checked for consistency against exact archived baseline identity and exact class-byte length; this Python runtime has no BLAKE3 module for independent digest recomputation.','This review covers API capture evidence only; it is not a workspace acceptance or full matrix result.']}
        out.write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps({k:result[k] for k in ('status','api_commands','original_cells','supplemental_cells','method_configurations','target_structured_cells','non_target_projections_compared','default_all_pairs')}))
if __name__=='__main__': main()
