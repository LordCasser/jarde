import java.io.File;
import java.lang.reflect.Method;
public final class LoopArmExceptionDriver {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("expected class root");
        Class<?> type = Class.forName("LoopArmExceptionBoundary");
        File actual = new File(type.getProtectionDomain().getCodeSource().getLocation().toURI()).getCanonicalFile();
        if (!actual.equals(new File(args[0]).getCanonicalFile())) throw new AssertionError("target loaded from " + actual);
        Method method = type.getDeclaredMethod("run", int.class, int.class);
        int[][] cases = {{0, 5}, {3, 2}, {-2, 7}, {4, -1}};
        for (int i = 0; i < cases.length; i++) {
            System.out.println("CASE " + i + " result=" + method.invoke(null, cases[i][0], cases[i][1]));
        }
    }
}
