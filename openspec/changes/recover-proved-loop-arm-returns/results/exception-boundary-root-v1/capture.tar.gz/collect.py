from pathlib import Path
import json,importlib.util,os,sys,shutil
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');PREP=Path(__file__).resolve().parent
OUT=Path('/private/tmp/jarde-loop-arm-exception-boundary-run-root-v1-20261018')
def module(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=module(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','compare');g=module(ROOT/c.GUARD_REL,'guard');scan=module(ROOT/c.SCANNER_REL,'scanner')
assert not OUT.exists() and not (ROOT/'target').exists();OUT.mkdir();(OUT/'raw').mkdir();(OUT/'empty').mkdir()
g.ROOT=ROOT;g.OUT=OUT/'raw';g.target_bytes=lambda:scan.target_bytes(ROOT);g.command_stream=c.pin;g.expected_test_summaries=lambda *a:None
jdks,jdkpin=c.configured_jdks(ROOT/'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json','ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
source=PREP/'LoopArmExceptionBoundary.java';driver=PREP/'LoopArmExceptionDriver.java';wrapper=Path('/private/tmp/jarde-nestedloops3-runtime-bound-root-v1-20261018.py');rows=[];before=c.source_closure(ROOT);pins=[c.pin(p) for p in (source,driver,wrapper)]
r={'status':'running','commands':rows,'source_before':before,'input_pins':pins,'jdk_manifest':jdkpin,'classes':[],'runtime':[],'controls':[]}
def save():c.write_json(OUT/'execution.json',r)
def command(argv,label,leg):
 row=g.run_command(len(rows)+1,list(map(str,argv)),c.clean_env(dict(os.environ),jdks[leg]));row['label']=label;rows.append(row);save();assert row['guard_stop'] is None;return row
try:
 d=OUT/'driver-classes';d.mkdir();row=command([jdks['javac8']['tools']['javac'],'-source','8','-target','8','-proc:none','-classpath',OUT/'empty','-sourcepath',OUT/'empty','-d',d,driver],'driver','javac8');assert row['exit_code']==0
 observations=[]
 for leg in ('javac8','javac23'):
  classes=OUT/leg/'classes';classes.mkdir(parents=True);mode=['-source','8','-target','8'] if leg=='javac8' else ['--release','8']
  row=command([jdks[leg]['tools']['javac'],*mode,'-g:none','-encoding','UTF-8','-proc:none','-classpath',OUT/'empty','-sourcepath',OUT/'empty','-d',classes,source],'compile-'+leg,leg);assert row['exit_code']==0
  target=classes/'LoopArmExceptionBoundary.class';facts=c.parse_class(target);assert facts['major']==52 and {(m['name'],m['descriptor']) for m in facts['methods']}=={('<init>','()V'),('run','(II)I')};assert sum(len(m['code']['rows']) for m in facts['methods'])==1;r['classes'].append({'compiler':leg,'class':c.pin(target),'facts':facts})
  for runtime in ('javac8','javac23'):
   row=command([sys.executable,'-B',wrapper,'30',jdks[runtime]['tools']['java'],'-Xverify:all','-cp',os.pathsep.join([str(classes),str(d)]),'LoopArmExceptionDriver',classes],'runtime-'+leg+'-'+runtime,runtime);stdout=c.command_artifact(row,'stdout');assert row['exit_code']==0 and len(stdout.splitlines())==4;observations.append(stdout);r['runtime'].append({'compiler':leg,'runtime':runtime,'command':row['index'],'stdout':stdout.decode()})
  row=command([sys.executable,'-B',wrapper,'30',jdks['javac23']['tools']['java'],'-Xverify:all','-cp',os.pathsep.join([str(classes),str(d)]),'LoopArmExceptionDriver',OUT/'empty'],'wrong-root-'+leg,'javac23');assert row['exit_code']!=0 and b'target loaded from' in c.command_artifact(row,'stderr');r['controls'].append(row['index'])
 assert len(set(observations))==1;r['oracle']=observations[0].decode();r['driver_classes']=[c.pin(p) for p in sorted(d.rglob('*.class'))]
 assert [c.pin(Path(x['path'])) for x in pins]==pins and c.source_closure(ROOT)==before and not(ROOT/'target').exists()
 r['source_after']=c.source_closure(ROOT);r['target_absent']=True;r['status']='captured-pending-independent-class-boundary-review'
finally:save();print(json.dumps({'status':r['status'],'commands':len(rows)}))
