from pathlib import Path
import json,hashlib,importlib.util,os
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path(__file__).resolve().parent
PREP=Path('/private/tmp/jarde-loop-arm-exception-boundary-prep-root-v1-20261018')
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(r):assert pin(r['path'])==r,r['path'];return Path(r['path']).read_bytes()
c=load(ROOT/'openspec/changes/recover-exception-only-finally-completion/tools/compare.py','compare')
h=load(Path('/private/tmp/jarde-testnestedloops5-parameterized-review-prep-root-v4-20261018/classfile_helpers.py'),'classhelper')
d=json.loads((OUT/'execution.json').read_text());assert d['status']=='captured-pending-independent-class-boundary-review'
assert d['source_before']==d['source_after']==c.source_closure(ROOT) and d['target_absent'] and not(ROOT/'target').exists()
for r in d['input_pins']:verify(r)
tools=d['jdk_manifest']['tools']
for ts in tools.values():
 for r in ts.values():verify(r)
commands={r['index']:r for r in d['commands']};assert len(commands)==9 and set(commands)==set(range(1,10))
for r in commands.values():
 assert r['guard_stop'] is None;verify(r['streams']['stdout']);verify(r['streams']['stderr'])
source=PREP/'LoopArmExceptionBoundary.java';driver=PREP/'LoopArmExceptionDriver.java';empty=OUT/'empty';driver_root=OUT/'driver-classes'
av=[tools['javac8']['javac']['path'],'-source','8','-target','8','-proc:none','-classpath',str(empty),'-sourcepath',str(empty),'-d',str(driver_root),str(driver)]
assert commands[1]['argv']==av and commands[1]['exit_code']==0
for r in d['driver_classes']:verify(r)
used={1};class_rows=[];observed=[]
for leg in ('javac8','javac23'):
 row=next(q for q in d['classes'] if q['compiler']==leg);raw=verify(row['class']);facts=h.parse_class_file(raw);assert facts['major']==52 and facts['class_name']=='LoopArmExceptionBoundary'
 assert len(facts['methods'])==2 and {(q['name'],q['descriptor']) for q in facts['methods']}=={('<init>','()V'),('run','(II)I')}
 assert facts['fields']==[]
 for method in facts['methods']:
  old=next(q for q in row['facts']['methods'] if (q['name'],q['descriptor'])==(method['name'],method['descriptor']))
  assert method['access']==old['access']
  for key in ('max_stack','max_locals','code_length','code_hex','rows','bcis'):assert method['code'][key]==old['code'][key]
 assert sum(len(q['code']['rows']) for q in facts['methods'])==1
 cls=OUT/leg/'classes';cmd=next(r for r in commands.values() if r['label']=='compile-'+leg);used.add(cmd['index'])
 mode=['-source','8','-target','8'] if leg=='javac8' else ['--release','8']
 assert cmd['argv']==[tools[leg]['javac']['path'],*mode,'-g:none','-encoding','UTF-8','-proc:none','-classpath',str(empty),'-sourcepath',str(empty),'-d',str(cls),str(source)] and cmd['exit_code']==0
 assert [p.name for p in cls.rglob('*.class')]==['LoopArmExceptionBoundary.class']
 for runtime in ('javac8','javac23'):
  run=next(q for q in d['runtime'] if (q['compiler'],q['runtime'])==(leg,runtime));cmd=commands[run['command']];used.add(cmd['index']);av=cmd['argv']
  assert av[1:4]==['-B',d['input_pins'][2]['path'],'30']
  assert av[4:]==[tools[runtime]['java']['path'],'-Xverify:all','-cp',os.pathsep.join([str(cls),str(driver_root)]),'LoopArmExceptionDriver',str(cls)]
  stdout=verify(cmd['streams']['stdout']);assert cmd['exit_code']==0 and stdout.decode()==run['stdout']==d['oracle'];assert len(stdout.splitlines())==4;observed.append(stdout)
 ctrl=next(q for q in commands.values() if q['label']=='wrong-root-'+leg);used.add(ctrl['index']);assert ctrl['index'] in d['controls']
 assert ctrl['argv'][4:]==[tools['javac23']['java']['path'],'-Xverify:all','-cp',os.pathsep.join([str(cls),str(driver_root)]),'LoopArmExceptionDriver',str(empty)]
 assert ctrl['exit_code']!=0 and b'target loaded from' in verify(ctrl['streams']['stderr'])
 class_rows.append({'compiler':leg,'class':row['class'],'facts':facts})
assert used==set(commands) and len(observed)==4 and len(set(observed))==1
result={'status':'accepted_valid_class_boundary_only','checker':pin(__file__),'receipt':pin(OUT/'execution.json'),'commands':9,'raw_streams':18,'vm_runs':4,'vm_cases':16,'wrong_roots':2,'classes':class_rows,'limitation':'Only original fixture compilation/JVM validity and physical facts. No claim of decompiler semantic recovery or catch runtime execution.'}
(OUT/'root-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ('status','commands','vm_runs','vm_cases','wrong_roots')}))
