#!/usr/bin/env python3
"""Independent, read-only reviewer for the NL5 final-API rebuild matrix receipt."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, sys
from pathlib import Path

ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
ORIG_BASE=Path('/private/tmp/jarde-testnestedloops5-baseline-run-root-v3-20261018')
SUPP_BASE=Path('/private/tmp/jarde-testnestedloops5-parameterized-baseline-run-root-v1-20261018')
ORIG_REVIEW=Path('/private/tmp/jarde-testnestedloops5-baseline-review-root-v1-20261018/root-review.json')
SUPP_REVIEW=SUPP_BASE/'independent-review/acceptance.json'
COMPARE_REL=Path('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
COMPARE_SHA='18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
HELPER=Path('/private/tmp/jarde-testnestedloops5-parameterized-review-prep-root-v4-20261018/classfile_helpers.py')
ORIGINAL_TARGET='jadx/tests/integration/loops/TestNestedLoops5$TestCls.class'
ORIGINAL_OWNER='jadx/tests/integration/loops/TestNestedLoops5.class'
JDKS=('javac8','javac23')


def need(value,msg):
    if not value: raise ValueError(msg)
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot load parser/helper: {path}')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def pin(path):
    path=Path(path).resolve(strict=True);data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def verify_pin(record,label):
    need(isinstance(record,dict) and {'path','bytes','sha256'}<=record.keys(),f'{label}: malformed pin')
    expected_path=Path(record['path']).resolve(strict=True)
    actual=pin(expected_path)
    need(actual['path']==str(expected_path) and actual['bytes']==record['bytes'] and actual['sha256']==record['sha256'],f'{label}: pin mismatch {record.get("path")}')
    return expected_path
def parse_baseline_class_record(record,label,helper):
    """Verify the file identity fields of a richer baseline fact record, then reparse bytes."""
    need(isinstance(record,dict) and {'path','bytes','sha256'}<=record.keys(),f'{label}: baseline class pin missing')
    path=verify_pin({k:record[k] for k in ('path','bytes','sha256')},label)
    facts=helper.parse_class_file(path.read_bytes())
    need(facts['major']==52,'baseline class is not Java 8 major 52')
    return facts
def raw(command,channel,compare): return compare.command_artifact(command,channel)
def file_tree(path):
    path=Path(path)
    return {p.relative_to(path).as_posix():pin(p) for p in sorted(path.rglob('*')) if p.is_file()}
def class_id(facts): return facts['class_name']
def fields_id(facts): return {(x['name'],x['descriptor'],x['access']) for x in facts['fields']}
def methods_id(facts): return {(x['name'],x['descriptor'],x['access']) for x in facts['methods']}
def methods_key(facts): return {(x['name'],x['descriptor']) for x in facts['methods']}
def all_code(facts): return all(x.get('code') is not None for x in facts['methods'])
def source_pin(row): return row.get('whole_source') or row.get('source')
def get_input_cell_key(item): return (item['kind'],item['variant'],item['input_compiler'],item['profile'],item['form'],item['evidence'])


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--matrix',type=Path,required=True,help='final rebuild execution.json')
    ap.add_argument('--out',type=Path,required=True,help='new acceptance JSON path')
    a=ap.parse_args();matrix=a.matrix.resolve(strict=True);out=a.out.resolve()
    need(not out.exists(),f'refusing existing review output: {out}')
    doc=json.loads(matrix.read_text(encoding='utf-8'))
    need(doc.get('schema')=='cf11-testnestedloops5-final-rebuild-matrix-v1','wrong matrix schema')
    need(doc.get('status')=='captured_pending_independent_review','matrix is not complete')
    root=Path(doc['root']).resolve(strict=True);need(root==ROOT.resolve(),'workspace root differs from receipt')
    compare_path=root/COMPARE_REL;need(hashlib.sha256(compare_path.read_bytes()).hexdigest()==COMPARE_SHA,'compare helper pin differs')
    compare=load(compare_path,'final_matrix_compare'); helper=load(HELPER,'final_matrix_classparser')
    def verify_record(key,label):
        rec=doc[key];verify_pin(rec,label);return rec
    matrix_pin=pin(matrix); original_pin=verify_record('original_baseline','original baseline receipt')
    supp_pin=verify_record('supplement_baseline','supplement baseline receipt')
    api_pin=verify_record('api_receipt','final API receipt')
    need(api_pin['path']==doc['api_receipt']['path'],'API receipt binding mismatch')
    original=json.loads(Path(original_pin['path']).read_text(encoding='utf-8'))
    supplement=json.loads(Path(supp_pin['path']).read_text(encoding='utf-8'))
    api=json.loads(Path(api_pin['path']).read_text(encoding='utf-8'))
    orig_review=json.loads(ORIG_REVIEW.read_text(encoding='utf-8'))
    supp_review=json.loads(SUPP_REVIEW.read_text(encoding='utf-8'))
    need(orig_review.get('status')=='read_only_baseline_review_complete','original baseline review is not complete')
    need(supp_review.get('status')=='accepted_static_baseline_with_mapping_gaps_reported','supplement baseline review is not accepted')
    need(orig_review.get('input')==original_pin and supp_review.get('baseline_receipt')==supp_pin,'accepted baseline review does not bind matrix receipts')
    need(original.get('schema')=='cf11-original-testnestedloops5-baseline-v1' and len(original.get('jarde_cells',[]))==8 and len(original.get('jadx_cells',[]))==4,'original baseline grid differs')
    need(supplement.get('schema')=='cf11-testnestedloops5-parameterized-baseline-v1' and len(supplement.get('jarde_cells',[]))==16 and len(supplement.get('jadx_cells',[]))==8,'supplement baseline grid differs')
    need(api.get('schema')=='cf11-nl5-ab-loop-arm-api-capture-v1','final API schema differs')
    need(api.get('cli')==doc.get('cli') and api.get('product_revision')==doc.get('product_revision'),'final API CLI/revision changed')
    need(api.get('cli_sha256_argument')==api.get('cli',{}).get('sha256'),'final API CLI SHA argument mismatch')
    need(api.get('source_unchanged') is True and api.get('target_absent') is True,'API capture source/target gates not true')
    need(doc.get('compile_attempt_contract')=={'original_sources':12,'supplement_sources':24,'total_source_cells':36,'compilers':2,'attempts':72},'72-attempt plan changed')
    need(pin(HELPER)==supp_review.get('classfile_helper'),'classfile parser does not match accepted baseline reviewer')
    need(doc.get('cli')==api.get('cli') and doc.get('product_revision')==api.get('product_revision'),'matrix CLI is not final API CLI')

    # Pin the exact top-level API capture commands and every source selector.
    api_commands={r.get('index'):r for r in api.get('commands',[])}
    need(len(api_commands)==len(api.get('commands',[])) and None not in api_commands,'API command ids invalid')
    for r in api_commands.values():
        need(r.get('guard_stop') is None,'API command was stopped by guard')
        raw(r,'stdout',compare);raw(r,'stderr',compare)
    final_jarde={}
    for row in [*api.get('jarde_cells',[]),*api.get('supplemental_cells',[])]:
        key=tuple(row['selector']) if 'selector' in row else None
        command=api_commands.get(row.get('command'))
        need(command is not None and command.get('exit_code')==row.get('exit_code'),'API source cell is unbound from command outcome')
        need(row.get('exit_code')==0,'final API Jarde source cell did not succeed')
        sp=row.get('whole_source') or row.get('source');need(sp is not None,'API source pin missing')
        verify_pin(sp,'final API whole-source')
        rp=row.get('report');verify_pin(rp,'final API report')
        report=json.loads(Path(rp['path']).read_text(encoding='utf-8'))
        need(report.get('text','').encode('utf-8')==Path(sp['path']).read_bytes(),'API whole source differs from report text')
        if row.get('input'): verify_pin(row['input'],'API class input')
        if row.get('input_after') is not None: need(row['input_after']==row.get('input'),'API input changed')
        if row.get('target_class_input'): verify_pin(row['target_class_input'],'API target class input')
        if row.get('prior_report'): verify_pin(row['prior_report'],'API prior report')
        if row.get('target_class_input'):
            input_facts=helper.parse_class_file(Path(row['target_class_input']['path']).read_bytes())
            need(input_facts['major']==52,'API class input is not major 52')
            row['_input_facts']=input_facts
        selector=row.get('selector')
        if selector is None:
            if row in api.get('jarde_cells',[]): selector=[row['profile'],row['input_form'],row['evidence']]
            else: selector=[row['variant'],row['compiler'],row['profile'],row['input_form'],row['evidence']]
        final_jarde[(('original' if row in api.get('jarde_cells',[]) else 'supplement'),*selector)]=row

    # Validate accepted historical inputs, source artifacts, exact output copies.
    for row in original['commands']:
        need(row.get('guard_stop') is None,'original baseline command stopped');raw(row,'stdout',compare);raw(row,'stderr',compare)
    for row in supplement['commands']:
        need(row.get('guard_stop') is None,'supplement baseline command stopped');raw(row,'stdout',compare);raw(row,'stderr',compare)
    verify_pin(original['source'],'original source');verify_pin(supplement['original_nl5_source'],'supplement original source')
    verify_pin(original['original_oracle'],'original core oracle');verify_pin(original['original_check_oracle'],'original check oracle')
    core_oracle=Path(original['original_oracle']['path']).read_bytes();check_oracle=Path(original['original_check_oracle']['path']).read_bytes()
    need(len(core_oracle.splitlines())==3 and len(check_oracle.splitlines())==1,'original oracle row count mismatch')
    supp_oracles={v:Path(verify_pin(r['file'],f'{v} oracle')).read_bytes() for v,r in supplement['observed_oracles'].items()}
    need(set(supp_oracles)=={'A','B'} and all(len(x.splitlines())==3 for x in supp_oracles.values()),'A/B oracle contract mismatch')
    for row in original['original_runtime']:
        cmd=original['commands'][row['command']-1]
        need(cmd['exit_code']==row['exit_code']==0 and raw(cmd,'stdout',compare)==core_oracle,'original core oracle not supported by raw JVM receipt')
    for row in original['original_check_runtime']:
        cmd=original['commands'][row['command']-1];err=raw(cmd,'stderr',compare)
        if row['runtime']=='javac23':
            need(cmd['exit_code']==0 and raw(cmd,'stdout',compare)==check_oracle,'original check oracle not supported by Java23 raw run')
        else:
            need(row.get('status')=='harness-major55-boundary-no-check-result' and cmd['exit_code']!=0 and (b'55.0' in err or b'version 55' in err),'original Java8 check boundary differs')
    for row in supplement['original_runtime']:
        cmd=supplement['commands'][row['command']-1]
        need(cmd['exit_code']==row['exit_code']==0 and raw(cmd,'stdout',compare)==supp_oracles[row['variant']],'A/B actual oracle not supported by raw JVM receipt')
    for row in original.get('wrong_root_controls',[]):
        cmd=original['commands'][row['command']-1]
        need(cmd['exit_code']!=0 and b'target loaded from' in raw(cmd,'stderr',compare),'accepted original wrong-root control did not reject')
    for row in supplement.get('wrong_root_controls',[]):
        cmd=supplement['commands'][row['command']-1]
        need(cmd['exit_code']!=0 and b'target loaded from' in raw(cmd,'stderr',compare),'accepted supplement wrong-root control did not reject')
    expected_sources={}
    need(len(api.get('jarde_cells',[]))==8 and len(api.get('supplemental_cells',[]))==16,'final API selector counts differ')
    api_original_keys={(r['profile'],r['input_form'],r['evidence']) for r in api['jarde_cells']}
    need(len(api_original_keys)==8,'duplicate final API original selector')
    api_supp_keys={(r['variant'],r['compiler'],r['profile'],r['input_form'],r['evidence']) for r in api['supplemental_cells']}
    need(len(api_supp_keys)==16,'duplicate final API supplemental selector')
    for row in api['jarde_cells']:
        expected_sources[('jarde-original','NL5','original',row['profile'],row['input_form'],row['evidence'])]=row
    for row in api['supplemental_cells']:
        expected_sources[('jarde-supplement',row['variant'],row['compiler'],row['profile'],row['input_form'],row['evidence'])]=row
    for row in original['jadx_cells']:
        need(row.get('exit_code')==0 and len(row.get('sources') or [])==1,'original JADX source unavailable')
        sp=row['sources'][0];verify_pin(sp,'original JADX source')
        expected_sources[('jadx-original','NL5','original',row['profile'],row['input_form'],'source')]=row
    for row in supplement['jadx_cells']:
        need(row.get('exit_code')==0 and len(row.get('sources') or [])==1,'supplement JADX source unavailable')
        sp=row['sources'][0];verify_pin(sp,'supplement JADX source')
        expected_sources[('jadx-supplement',row['variant'],row['compiler'],row['profile'],'child','source')]=row
    need(len(expected_sources)==36,'duplicate/missing source selector identities')
    src_rows=doc.get('source_inputs',[])
    source_by_id={get_input_cell_key(x):x for x in src_rows}
    need(len(src_rows)==36 and len(source_by_id)==36,'source input cells are duplicate or incomplete')
    need(set(source_by_id)==set(expected_sources),'source cell identity grid differs')
    for ident,item in source_by_id.items():
        verify_pin(item['source'],'source input');verify_pin(item['source_copy'],'copied source')
        need(Path(item['source']['path']).read_bytes()==Path(item['source_copy']['path']).read_bytes(),'source copy changed bytes')
        if item.get('report'):
            verify_pin(item['report'],'source report')
            rep=json.loads(Path(item['report']['path']).read_text(encoding='utf-8'))
            need(rep.get('text','').encode('utf-8')==Path(item['source_copy']['path']).read_bytes(),'copied source/report text mismatch')
        if item.get('input'): verify_pin(item['input'],'API source input')
        if item.get('target_class_input'): verify_pin(item['target_class_input'],'API target class input')
        if item.get('prior_report'): verify_pin(item['prior_report'],'prior API report')
        apirow=expected_sources[ident]
        apisrc=apirow.get('whole_source') or apirow.get('source') if ident[0].startswith('jarde') else apirow['sources'][0]
        need(item['source']==apisrc,'matrix Jarde/JADX source not bound to the exact source artifact')

    # Baseline physical method/field inventories are the expected structural ABI.
    original_profiles={p['profile']:p for p in original['profiles']}
    supp_profiles={(p['variant'],p['compiler'],p['profile']):p for p in supplement['class_profiles']}
    for rec in (original['harness_jar'],*original['jar_pins']): verify_pin(rec,'original compile/check dependency')
    for folder,expected in original['directory_pins'].items():
        actual={p.relative_to(folder).as_posix():pin(p) for p in sorted(Path(folder).rglob('*.class'))}
        need(actual==expected,'original classpath directory pin changed')
    def expected_target(item):
        if item['variant']=='NL5': return original_profiles[item['profile']]['target']
        return supp_profiles[(item['variant'],item['input_compiler'],item['profile'])]['target']
    def expected_tree(item):
        target=ORIGINAL_TARGET if item['variant']=='NL5' else f'NestedReturn{item["variant"]}$TestCls.class'
        if item['kind']=='jadx-original' and item['form']=='bundle': return {target,ORIGINAL_OWNER}
        return {target}

    # Validate command inventory and raw streams before interpreting cells.
    commands={r.get('index'):r for r in doc.get('commands',[])}
    need(len(commands)==len(doc.get('commands',[])) and set(commands)==set(range(1,len(commands)+1)),'matrix command index census invalid')
    used=set()
    def command(index,label):
        need(index not in used,f'command reused: {index}');used.add(index)
        row=commands.get(index);need(row is not None and row.get('label')==label,f'command label/binding mismatch: {index}')
        need(row.get('guard_stop') is None,f'guard stopped command {label}')
        raw(row,'stdout',compare);raw(row,'stderr',compare);return row
    for row in commands.values():
        need(row.get('guard_stop') is None,'matrix command guard stop')
        raw(row,'stdout',compare);raw(row,'stderr',compare)
    tool_pins=doc['runtime_tool_pins_before']
    for name,record in tool_pins.items(): verify_pin(record,f'{name} runtime pin')
    cli=doc['cli'];wrapper=doc['runtime_wrapper']
    jdk_manifest=json.loads(Path(tool_pins['jdk_manifest']['path']).read_text(encoding='utf-8'))
    jdk_tools={leg:{name:str(Path(t['path']).resolve()) for name,t in row['jdk_tools'].items()}
                  for row in jdk_manifest['legs'] if (leg:=row['leg']) in JDKS}
    need(set(jdk_tools)==set(JDKS),'JDK manifest legs missing')
    compile_driver=doc['driver_compile'];dc=command(compile_driver['command'],'compile-independent-drivers')
    for driver in doc['drivers']: verify_pin(driver,'pinned driver source')
    outroot=matrix.parent
    driver_source=outroot/'driver-source';driver_classes=outroot/'driver-classes';driver_empty=outroot/'empty-driver-classpath'
    dcopy=driver_source/'TestNestedLoops5Driver.java';dcopy2=driver_source/'ParameterizedNestedReturnDriver.java'
    for copy,record in ((dcopy,doc['drivers'][0]),(dcopy2,doc['drivers'][1])):
        actual=pin(copy)
        need(actual['bytes']==record['bytes'] and actual['sha256']==record['sha256'],'driver copy content differs from pinned original')
        need(copy.read_bytes()==Path(record['path']).read_bytes(),'driver copy bytes differ from pinned original')
    expected_driver_argv=[jdk_tools['javac8']['javac'],'-source','8','-target','8','-g:none','-Xlint:-options','-encoding','UTF-8','-proc:none','-classpath',str(driver_empty),'-sourcepath',str(driver_empty),'-d',str(driver_classes),str(dcopy),str(dcopy2)]
    need(dc['exit_code']==0 and dc['argv']==expected_driver_argv and compile_driver.get('exit_code')==0,'independent driver compile argv/outcome mismatch')
    driver_tree=file_tree(driver_classes)
    need(driver_tree==compile_driver.get('classes'),'driver class tree differs from receipt')
    driver_facts={rel:helper.parse_class_file(Path(driver_classes/rel).read_bytes()) for rel in driver_tree}
    need(set(driver_facts)=={'TestNestedLoops5Driver.class','ParameterizedNestedReturnDriver.class'},'unexpected independent driver class output')
    need(all(f['major']==52 and all_code(f) for f in driver_facts.values()),'driver class major/Code mismatch')
    driver_pins=[pin(x) for x in (dcopy,dcopy2)]
    need(len(driver_pins)==2,'driver source pins missing')

    parsed_original_target={p:parse_baseline_class_record(row['target'],f'original {p} target class',helper) for p,row in original_profiles.items()}
    parsed_original_owner={p:parse_baseline_class_record(row['outer'],f'original {p} outer class',helper) for p,row in original_profiles.items()}
    parsed_supp_target={(v,c,p):parse_baseline_class_record(row['target'],f'{v}/{c}/{p} supplement target class',helper) for (v,c,p),row in supp_profiles.items()}
    def target_facts_for(item):
        if item['variant']=='NL5': return parsed_original_target[item['profile']]
        return parsed_supp_target[(item['variant'],item['input_compiler'],item['profile'])]
    def expected_method_ids(facts): return {(x['name'],x['descriptor'],x['access']) for x in facts['methods']}
    def expected_field_ids(facts):
        fs=facts['fields']
        return {(x['name'],x['descriptor'],x['access']) if isinstance(x,dict) else (x[0],x[1],x[2]) for x in fs}
    def row_identity(c): return tuple(c['identity'])
    expected_compile_ids=[]
    for item in source_by_id.values():
        for compiler in JDKS:
            expected_compile_ids.append((item['kind'],item['variant'],item['input_compiler'],item['profile'],item['form'],item['evidence'],compiler))
    cells=doc.get('compile_cells',[])
    ids=[row_identity(c) for c in cells]
    need(len(cells)==72 and len(set(ids))==72 and set(ids)==set(expected_compile_ids),'72 compile cell identity grid differs')
    need(doc['compile_attempt_contract']=={'original_sources':12,'supplement_sources':24,'total_source_cells':36,'compilers':2,'attempts':72},'attempt contract changed')
    rows_by_id={row_identity(c):c for c in cells}
    valid_ids=set()
    observations=[]
    for ident,cell in rows_by_id.items():
        kind,variant,input_compiler,profile,form,evidence,compiler=ident
        srcitem=source_by_id[(kind,variant,input_compiler,profile,form,evidence)]
        need(cell.get('source')==srcitem['source'] and cell.get('source_copy')==srcitem['source_copy'],'compile cell is not bound to exact whole-source copy')
        clsroot=Path(cell['class_root']).resolve(strict=True)
        expected_classroot=outroot/'classes'/kind/variant/input_compiler/profile/form/str(evidence)/compiler
        need(clsroot==expected_classroot.resolve(strict=True),'compile class output root differs')
        comp=command(cell['compile_command'],'compile-'+'-'.join(map(str,ident)))
        javac=jdk_tools[compiler]['javac']; args8=['-source','8','-target','8'] if compiler=='javac8' else ['--release','8']
        is_original=variant=='NL5'; classpath=original.get('classpath',[]) if is_original else []
        cp=os.pathsep.join(map(str,classpath)) if classpath else str(outroot/'empty-classpath')
        src_copy=Path(srcitem['source_copy']['path']).resolve(strict=True)
        expected_argv=[javac,*args8,'-g' if profile=='debug' else '-g:none','-encoding','UTF-8','-proc:none','-classpath',cp,'-sourcepath',str(outroot/'empty-classpath'),'-d',str(clsroot),str(src_copy)]
        need(comp['argv']==expected_argv and comp['exit_code']==cell['compile_exit_code'],'compiler argv or exit result mismatch')
        need(cell['class_tree']==file_tree(clsroot),'compile class tree/pins changed')
        if comp['exit_code']:
            need(cell['status'] in ('compile_failed_no_runtime','compile_failed_no_runtime_empty_diagnostic') and not cell.get('runtime'),'failed compile incorrectly has runtime')
            need(cell.get('target_class') is None,'failed compile has target class')
            continue
        parsed=[]
        for rec in cell.get('classfile_facts',[]):
            rel=rec['relative_path'];p=clsroot/rel
            need(rec['pin']==pin(p),'class fact pin mismatch')
            facts=helper.parse_class_file(p.read_bytes())
            need(facts==rec['facts'],'stored class facts do not match independently parsed bytes')
            parsed.append((rel,facts))
        need({rel for rel,_ in parsed}==expected_tree({'kind':kind,'variant':variant,'form':form}),'compiled class output tree has extra/missing classes')
        target_rel=ORIGINAL_TARGET if is_original else f'NestedReturn{variant}$TestCls.class'
        tf=dict(parsed)[target_rel];want=target_facts_for(srcitem)
        target_record=cell.get('target_class')
        need(target_record is not None and target_record['facts']==tf and target_record['path']==str((clsroot/target_rel).resolve()),'target facts/path do not bind parsed output')
        need(tf['major']==52 and tf['class_name']==want['class_name'] and tf['access']==want['access'],'target class identity/access or Java 8 major mismatch')
        need(methods_id(tf)==expected_method_ids(want) and all_code(tf),'target methods/access/Code differ from exact original class input')
        need(fields_id(tf)==expected_field_ids(want),'target fields/access differ from exact original class input')
        for rel,facts in parsed:
            need(facts['major']==52,'emitted class is not Java 8 major 52')
            if rel==ORIGINAL_OWNER:
                ow=parsed_original_owner[profile]
                need(facts['class_name']==ow['class_name'] and facts['access']==ow['access'] and methods_id(facts)==expected_method_ids(ow) and fields_id(facts)==expected_field_ids(ow) and all_code(facts),'full bundle outer class differs in identity/access/methods/fields/Code')
        need(cell['status'] in ('compiled_target_verified','compiled_target_ran'),'successful valid target has unexpected status')
        valid_ids.add(ident)

    # Re-evaluate each runtime against the exact oracle and the raw guarded command.
    wrapper=verify_pin(doc['runtime_wrapper'],'runtime wrapper')
    wrapper_path=str(wrapper)
    jdk_manifest_path=verify_pin(tool_pins['jdk_manifest'],'JDK manifest')
    manifest=json.loads(jdk_manifest_path.read_text(encoding='utf-8'))
    manifest_by_leg={x['leg']:x for x in manifest['legs']}
    for leg in JDKS:
        for name in ('java','javac','javap'):
            rec=manifest_by_leg[leg]['jdk_tools'][name];verify_pin(rec,f'{leg} {name}')
            need(jdk_tools[leg][name]==str(Path(rec['path']).resolve()),'JDK manifest/tool path mismatch')
    core_oracle=Path(original['original_oracle']['path']).read_bytes();check_oracle=Path(original['original_check_oracle']['path']).read_bytes()
    supp_oracle_bytes={v:Path(r['file']['path']).read_bytes() for v,r in supplement['observed_oracles'].items()}
    runtime_rows=[];wrong_rows=[]
    original_cp=list(map(str,original.get('classpath',[])))
    for ident in sorted(valid_ids):
        cell=rows_by_id[ident];kind,variant,input_compiler,profile,form,evidence,compiler=ident
        clsroot=Path(cell['class_root']).resolve(strict=True)
        modes=('core','check') if variant=='NL5' else ('core',)
        wrlabel='wrong-root-'+'-'.join(map(str,ident));wr=command(next(x['command'] for x in doc['wrong_root_controls'] if x['identity']==list(ident)),wrlabel)
        wrong=Path(outroot/'wrong-root'/'/'.join(map(str,ident))).resolve(strict=True)
        driver='TestNestedLoops5Driver' if variant=='NL5' else 'ParameterizedNestedReturnDriver'
        args=[str(wrong),'core'] if variant=='NL5' else [f'NestedReturn{variant}$TestCls',str(wrong)]
        cp=[str(clsroot),str(driver_classes)]
        expected_wrong=[sys.executable,'-B',wrapper_path,'30',jdk_tools['javac23']['java'],'-Xverify:all','-cp',os.pathsep.join(cp),driver,*args]
        need(wr['argv']==expected_wrong and wr['exit_code']!=0,'wrong-root control argv/result mismatch')
        werr=raw(wr,'stderr',compare);need(b'target loaded from' in werr,'wrong-root control lacks CodeSource rejection')
        wrong_rows.append({'identity':list(ident),'command':wr['index'],'exit_code':wr['exit_code'],'stderr_sha256':hashlib.sha256(werr).hexdigest()})
        expected_runtime_records=[]
        for leg in JDKS:
            for mode in modes:
                label=f'runtime-{mode}-'+'-'.join(map(str,ident))+'-'+leg
                candidate=[r for r in cell.get('runtime',[]) if r.get('runtime')==leg and r.get('mode')==mode]
                need(len(candidate)==1,f'runtime row cardinality differs: {ident}/{mode}/{leg}')
                result=candidate[0];rr=command(result['command'],label)
                cp=[str(clsroot),str(driver_classes)]
                if mode=='check': cp.extend(original_cp)
                args=[str(clsroot),mode] if variant=='NL5' else [f'NestedReturn{variant}$TestCls',str(clsroot)]
                expected=[sys.executable,'-B',wrapper_path,'30',jdk_tools[leg]['java'],'-Xverify:all','-cp',os.pathsep.join(cp),driver,*args]
                need(rr['argv']==expected and rr['exit_code']==result['exit_code'],'runtime argv/exit binding mismatch')
                need(result['classpath']==cp and rr['classpath']==cp,'runtime classpath mismatch')
                outbytes=raw(rr,'stdout',compare);errbytes=raw(rr,'stderr',compare)
                if variant!='NL5':
                    oracle=supp_oracle_bytes[variant];equal=rr['exit_code']==0 and outbytes==oracle;status='matches_variant_original_oracle' if equal else 'runtime_failed_or_oracle_mismatch'
                elif mode=='core':
                    equal=rr['exit_code']==0 and outbytes==core_oracle;status='matches_original_core_oracle' if equal else 'runtime_failed_or_oracle_mismatch'
                elif leg=='javac23':
                    equal=rr['exit_code']==0 and outbytes==check_oracle;status='matches_original_check_oracle' if equal else 'check_failed_or_oracle_mismatch'
                else:
                    equal=False;status='observed_harness_major55_boundary_no_check_result' if rr['exit_code'] and (b'55.0' in errbytes or b'version 55' in errbytes) else 'unexpected_javac8_check_result'
                need(result['oracle_equal']==equal and result['status']==status,'runtime oracle classification mismatch')
                for tree_name in ('target_tree_before','target_tree_after'):
                    need(rr[tree_name]==cell['class_tree'],'runtime mutated or misreported target classes')
                need(rr['driver_tree_before']==driver_tree and rr['driver_tree_after']==driver_tree,'runtime mutated or misreported driver classes')
                rec={'identity':list(ident),'mode':mode,'runtime':leg,'command':rr['index'],'exit_code':rr['exit_code'],'stdout_sha256':hashlib.sha256(outbytes).hexdigest(),'stderr_sha256':hashlib.sha256(errbytes).hexdigest(),'oracle_equal':equal,'status':status,'classpath':cp}
                expected_runtime_records.append(rec);runtime_rows.append(rec)
        need(cell.get('runtime')==[{k:v for k,v in rec.items() if k!='identity'} for rec in expected_runtime_records],'compile cell runtime records do not match independently derived rows')

    runtime_rows.sort(key=lambda r:r['command']);wrong_rows.sort(key=lambda r:r['command'])
    need(doc.get('runtime_rows')==runtime_rows,'top-level runtime rows do not match raw command observations')
    need(doc.get('wrong_root_controls')==wrong_rows,'wrong-root receipt rows differ from raw observations')
    need(len(used)==len(commands) and used==set(commands),'unreferenced or multiply referenced matrix commands')
    need(doc.get('source_after')==doc.get('source_before') and doc.get('target_absent') is True,'workspace closure/target gate failed')
    need(doc.get('source_before')==api.get('source_closure_before'),'matrix source closure differs from final API closure')
    need(doc.get('source_before')==api.get('source_closure_after'),'API source closure changed during capture')
    need(compare.source_closure(root)==doc.get('source_before'),'current source closure differs from matrix receipt')
    need(not (root/'target').exists(),'workspace target directory appeared')
    for name,record in doc['runtime_tool_pins_before'].items(): verify_pin(record,f'{name} final pin')
    need(doc['runtime_tool_pins_before'].get('classfile_helper')==supp_review.get('classfile_helper'),'helper pin no longer matches accepted baseline')
    for row in manifest['legs']:
        for name,record in row['jdk_tools'].items(): verify_pin(record,f'{row["leg"]} {name} final pin')
    for rec in (original['harness_jar'],*original['jar_pins']): verify_pin(rec,'original dependency final pin')
    for folder,expected in original['directory_pins'].items():
        actual={p.relative_to(folder).as_posix():pin(p) for p in sorted(Path(folder).rglob('*.class'))}
        need(actual==expected,'original classpath directory pin changed after matrix')
    for rec in (doc['api_receipt'],doc['original_baseline'],doc['supplement_baseline'],doc['original_review'],doc['supplement_review']): verify_pin(rec,'final receipt/source pin')
    for cell in cells: need(file_tree(cell['class_root'])==cell['class_tree'],'class tree changed after runtime')
    need(file_tree(driver_classes)==driver_tree,'driver tree changed after runtime')
    need(len(doc.get('commands',[]))==len(commands),'command inventory changed')
    statuses={c['status']:sum(x['status']==c['status'] for x in cells) for c in cells}
    runtime_mismatches=[r for r in runtime_rows if not r['oracle_equal'] and r['status']!='observed_harness_major55_boundary_no_check_result']
    check8=[r for r in runtime_rows if r['mode']=='check' and r['runtime']=='javac8']
    check23=[r for r in runtime_rows if r['mode']=='check' and r['runtime']=='javac23']
    result={'schema':'cf11-testnestedloops5-final-rebuild-independent-review-v1','status':'matrix_integrity_verified_observed_outcomes','matrix':matrix_pin,'reviewer':pin(Path(__file__)),
        'counts':{'commands':len(commands),'raw_stdout_stderr_verified':2*len(commands),'source_cells':len(source_by_id),'compile_attempts':len(cells),'verified_targets':len(valid_ids),'runtime_rows':len(runtime_rows),'wrong_root_controls':len(wrong_rows)},
        'compile_statuses':statuses,'compile_failures':[list(c['identity']) for c in cells if c['compile_exit_code']!=0],
        'runtime_mismatches':runtime_mismatches,'check8_outcomes':[r['status'] for r in check8],'check23_outcomes':[r['status'] for r in check23],
        'all_commands_consumed_once':True,'all_raw_streams_verified':True,'source_and_tool_pins_rechecked':True}
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(result['counts'],sort_keys=True))
    return 0

if __name__=='__main__': raise SystemExit(main())
