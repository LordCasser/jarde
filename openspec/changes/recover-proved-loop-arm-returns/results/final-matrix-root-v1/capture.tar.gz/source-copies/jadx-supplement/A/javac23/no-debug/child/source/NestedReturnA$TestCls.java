// default package

/* JADX INFO: loaded from: NestedReturnA$TestCls.class */
public final class NestedReturnA$TestCls {
    private int innerVisits;
    private int tailVisits;
    private int tailSum;
    private int earlyReturns;
    private int rolling;

    public int run(int i, int i2, int i3, int i4, int i5) {
        int i6 = 0;
        for (int i7 = i; i7 > 0; i7--) {
            if (i7 > i2) {
                int i8 = i7 + 1;
                for (int i9 = 1; i9 <= i3; i9++) {
                    this.innerVisits++;
                    this.rolling = (this.rolling * 31) + i8 + i9;
                    if (i7 == i4 && i9 == i5) {
                        this.earlyReturns++;
                        return 0;
                    }
                }
            }
            this.tailVisits++;
            this.tailSum += i7;
            i6 += i7;
            this.rolling = (this.rolling * 37) + i7;
        }
        return i6;
    }
}
