// default package

/* JADX INFO: loaded from: NestedReturnB$TestCls.class */
public final class NestedReturnB$TestCls {
    private int innerVisits;
    private int tailVisits;
    private int tailSum;
    private int earlyReturns;
    private int rolling;

    public int run(int returnOuter, int innerLimit, int gate, int returnInner, int outerLimit) {
        int localTail = 0;
        for (int i = outerLimit; i > 0; i--) {
            if (i > gate) {
                int childSeed = i + 2;
                for (int j = 0; j < innerLimit; j++) {
                    int value = childSeed + j;
                    this.innerVisits++;
                    this.rolling = (this.rolling * 29) + value;
                    if (i == returnOuter && j == returnInner) {
                        this.earlyReturns++;
                        return 0;
                    }
                }
            }
            this.tailVisits++;
            this.tailSum += i;
            localTail += i;
            this.rolling = (this.rolling * 41) + i;
        }
        return localTail;
    }
}
