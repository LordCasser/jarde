// default package

/* JADX INFO: loaded from: NestedReturnA$TestCls.class */
public final class NestedReturnA$TestCls {
    private int innerVisits;
    private int tailVisits;
    private int tailSum;
    private int earlyReturns;
    private int rolling;

    public int run(int outerLimit, int gate, int innerLimit, int returnOuter, int returnInner) {
        int localTail = 0;
        for (int i = outerLimit; i > 0; i--) {
            if (i > gate) {
                int childSeed = i + 1;
                for (int j = 1; j <= innerLimit; j++) {
                    int value = childSeed + j;
                    this.innerVisits++;
                    this.rolling = (this.rolling * 31) + value;
                    if (i == returnOuter && j == returnInner) {
                        this.earlyReturns++;
                        return 0;
                    }
                }
            }
            this.tailVisits++;
            this.tailSum += i;
            localTail += i;
            this.rolling = (this.rolling * 37) + i;
        }
        return localTail;
    }
}
