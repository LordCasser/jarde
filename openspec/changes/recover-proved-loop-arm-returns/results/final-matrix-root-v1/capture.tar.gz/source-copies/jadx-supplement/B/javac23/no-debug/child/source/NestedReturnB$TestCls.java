// default package

/* JADX INFO: loaded from: NestedReturnB$TestCls.class */
public final class NestedReturnB$TestCls {
    private int innerVisits;
    private int tailVisits;
    private int tailSum;
    private int earlyReturns;
    private int rolling;

    public int run(int i, int i2, int i3, int i4, int i5) {
        int i6 = 0;
        for (int i7 = i5; i7 > 0; i7--) {
            if (i7 > i3) {
                int i8 = i7 + 2;
                for (int i9 = 0; i9 < i2; i9++) {
                    this.innerVisits++;
                    this.rolling = (this.rolling * 29) + i8 + i9;
                    if (i7 == i && i9 == i4) {
                        this.earlyReturns++;
                        return 0;
                    }
                }
            }
            this.tailVisits++;
            this.tailSum += i7;
            i6 += i7;
            this.rolling = (this.rolling * 41) + i7;
        }
        return i6;
    }
}
