#!/usr/bin/env python3
"""Prepared NL5 final-API + supplement complete-source rebuild/runtime matrix.

This script is intentionally not executed here. It consumes final API output plus
previously accepted original/JADX and A/B baseline receipts, then compiles exact
whole-source artifacts with both pinned Java 8-target compilers.
"""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, shutil, sys
from pathlib import Path

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
ORIGINAL_BASE = Path('/private/tmp/jarde-testnestedloops5-baseline-run-root-v3-20261018')
SUPP_BASE = Path('/private/tmp/jarde-testnestedloops5-parameterized-baseline-run-root-v1-20261018')
ORIGINAL_REVIEW = Path('/private/tmp/jarde-testnestedloops5-baseline-review-root-v1-20261018/root-review.json')
SUPP_REVIEW = SUPP_BASE / 'independent-review' / 'acceptance.json'
COMPARE_REL = Path('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
COMPARE_SHA = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
JDK_REL = Path('openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json')
JDK_SHA = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
GUARD_REL = Path('openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py')
GUARD_SHA = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_REL = Path('openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py')
SCANNER_SHA = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
CLASS_HELPER = Path('/private/tmp/jarde-testnestedloops5-parameterized-review-prep-root-v4-20261018/classfile_helpers.py')
JDK_LEGS = ('javac8', 'javac23')
PROFILES = ('debug', 'no-debug')
ORIGINAL_TARGET = Path('jadx/tests/integration/loops/TestNestedLoops5$TestCls.class')
ORIGINAL_OWNER = Path('jadx/tests/integration/loops/TestNestedLoops5.class')
ORIGINAL_METHODS = {('<init>', '()V'), ('testFor', '()I'), ('check', '()V')}
SUPP_FIELDS = {'innerVisits', 'tailVisits', 'tailSum', 'earlyReturns', 'rolling'}
SUPP_METHODS = {('<init>', '()V'), ('run', '(IIIII)I')}
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def sha(b: bytes) -> str: return hashlib.sha256(b).hexdigest()
def method_set(facts): return {(m['name'], m['descriptor']) for m in facts['methods']}
def pin_path(p: Path, compare): return compare.pin(p.resolve(strict=True))
def ensure_pin(record, compare, label):
    if not isinstance(record, dict) or not {'path','bytes','sha256'} <= record.keys():
        raise RuntimeError(f'{label} is not a file pin')
    p=Path(record['path']).resolve(strict=True)
    if compare.pin(p) != record: raise RuntimeError(f'{label} changed: {p}')
    return p

def source_and_report(row, compare, label):
    src = row.get('whole_source') or row.get('source')
    if not isinstance(src, dict): raise RuntimeError(f'{label} has no complete source pin')
    sp=ensure_pin(src, compare, label+' source')
    report=row.get('report')
    if report:
        rp=ensure_pin(report, compare, label+' report')
        doc=json.loads(rp.read_text(encoding='utf-8'))
        if doc.get('text','').encode('utf-8') != sp.read_bytes():
            raise RuntimeError(f'{label} source does not exactly match report text')
    return src, report, sp

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--final-api', type=Path, required=True, help='completed final API execution.json')
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--root', type=Path, default=ROOT)
    ap.add_argument('--original-baseline', type=Path, default=ORIGINAL_BASE)
    ap.add_argument('--supplement-baseline', type=Path, default=SUPP_BASE)
    ap.add_argument('--original-review', type=Path, default=ORIGINAL_REVIEW)
    ap.add_argument('--supplement-review', type=Path, default=SUPP_REVIEW)
    a=ap.parse_args()
    root=a.root.resolve(strict=True); out=a.out.resolve(); api_path=a.final_api.resolve(strict=True)
    ob=a.original_baseline.resolve(strict=True); sb=a.supplement_baseline.resolve(strict=True)
    orev=a.original_review.resolve(strict=True); srev=a.supplement_review.resolve(strict=True)
    if root != ROOT.resolve(): raise SystemExit('workspace differs from pinned root')
    if ob != ORIGINAL_BASE.resolve() or sb != SUPP_BASE.resolve(): raise SystemExit('baseline paths differ from frozen receipts')
    if out.exists(): raise SystemExit(f'refusing existing output: {out}')
    if (root/'target').exists() or (root/'target').is_symlink(): raise SystemExit('workspace target exists')
    if shutil.disk_usage(root).free < 5*1024**3: raise SystemExit('workspace free space below 5 GiB')
    compare_path=root/COMPARE_REL
    if sha(compare_path.read_bytes()) != COMPARE_SHA: raise SystemExit('compare.py pin mismatch')
    compare=load(compare_path,'final_nl5_compare')

    original=json.loads((ob/'execution.json').read_text(encoding='utf-8'))
    supplement=json.loads((sb/'execution.json').read_text(encoding='utf-8'))
    api=json.loads(api_path.read_text(encoding='utf-8'))
    orig_accept=json.loads(orev.read_text(encoding='utf-8')); supp_accept=json.loads(srev.read_text(encoding='utf-8'))
    if original.get('schema') != 'cf11-original-testnestedloops5-baseline-v1' or original.get('status') != 'captured-pending-independent-review':
        raise SystemExit('original NL5 baseline schema/status mismatch')
    if supplement.get('schema') != 'cf11-testnestedloops5-parameterized-baseline-v1':
        raise SystemExit('A/B supplement baseline schema mismatch')
    if orig_accept.get('status') != 'read_only_baseline_review_complete' or supp_accept.get('status') != 'accepted_static_baseline_with_mapping_gaps_reported':
        raise SystemExit('baseline review receipts are not accepted')
    if orig_accept.get('input',{}).get('path') != str((ob/'execution.json').resolve()): raise SystemExit('original baseline review binds a different receipt')
    if compare.pin(ob/'execution.json') != orig_accept['input']: raise SystemExit('original review receipt pin differs')
    if supp_accept.get('baseline_receipt',{}).get('path') != str((sb/'execution.json').resolve()): raise SystemExit('supplement review binds a different receipt')
    if compare.pin(sb/'execution.json') != supp_accept['baseline_receipt']: raise SystemExit('supplement review receipt pin differs')
    if api.get('schema') != 'cf11-nl5-ab-loop-arm-api-capture-v1': raise SystemExit('final API schema mismatch')
    if api.get('status') not in ('captured_pending_independent_review','captured-pending-independent-review','complete_pending_independent_review','captured'):
        raise SystemExit(f'final API is not a completed capture: {api.get("status")!r}')
    if not api.get('cli') or not api.get('product_revision') or not api.get('commands'):
        raise SystemExit('final API lacks runtime-bound CLI/revision/command receipts')
    if api.get('source_unchanged') is not True or api.get('target_absent') is not True:
        raise SystemExit('final API capture does not preserve source/target gates')
    if api.get('cli_sha256_argument') != api['cli'].get('sha256'):
        raise SystemExit('final API CLI SHA argument differs from CLI pin')

    guard_path=root/GUARD_REL; scanner_path=root/SCANNER_REL
    if compare.sha(guard_path)!=GUARD_SHA or compare.sha(scanner_path)!=SCANNER_SHA: raise SystemExit('guard/scanner pin mismatch')
    guard=load(guard_path,'final_nl5_guard'); scanner=load(scanner_path,'final_nl5_scanner')
    jdks,jdk_record=compare.configured_jdks(root/JDK_REL,JDK_SHA)
    helper=load(CLASS_HELPER,'final_nl5_classfile')
    api_pin=compare.pin(api_path); original_pin=compare.pin(ob/'execution.json'); supp_pin=compare.pin(sb/'execution.json')
    orig_review_pin=compare.pin(orev); supp_review_pin=compare.pin(srev)
    driver_original=original['driver']; driver_supp=supplement['driver']
    wrapper=original['runtime_bound']; classpath=original['classpath']
    cli_pin=api['cli']; jadx=original['jadx']; jadx_jar=original['jadx_jar']
    for rec,label in ((driver_original,'original driver'),(driver_supp,'supplement driver'),(wrapper,'timeout wrapper'),(api['cli'],'final CLI'),(jadx,'JADX'),(jadx_jar,'JADX jar')):
        ensure_pin(rec,compare,label)
    # Bind the exact original harness/JAR and JADX build-class directories used by
    # the original baseline; classpath itself is a list of path strings, not pins.
    for rec in [original['harness_jar'], *original['jar_pins']]: ensure_pin(rec,compare,'original compile/check dependency')
    ensure_pin(original['source'],compare,'original upstream NL5 source')
    ensure_pin(supplement['original_nl5_source'],compare,'supplement upstream NL5 source')
    ensure_pin(original['dependency_reference'],compare,'original dependency/raw reference')
    ensure_pin(supplement['dependency_reference'],compare,'supplement dependency/raw reference')
    for folder, expected in original['directory_pins'].items():
        actual={p.relative_to(folder).as_posix():compare.pin(p) for p in sorted(Path(folder).rglob('*.class'))}
        if actual != expected: raise SystemExit(f'original dependency class tree changed: {folder}')
    api_commands={row.get('index'):row for row in api.get('commands',[])}
    if len(api_commands)!=len(api.get('commands',[])) or None in api_commands: raise SystemExit('final API command ids are missing or duplicated')
    for row in api_commands.values():
        if row.get('guard_stop') is not None: raise SystemExit('final API command has a guard stop')
        compare.command_artifact(row,'stdout'); compare.command_artifact(row,'stderr')
    for cell in [*api.get('jarde_cells',[]),*api.get('supplemental_cells',[])]:
        cmd=api_commands.get(cell.get('command'))
        if cmd is None or cmd.get('exit_code')!=cell.get('exit_code'):
            raise SystemExit('final API cell is not bound to its raw command outcome')
    for row in original['commands']:
        if row.get('guard_stop') is not None: raise SystemExit('original baseline guard stop')
        compare.command_artifact(row,'stdout'); compare.command_artifact(row,'stderr')
    for row in supplement['commands']:
        if row.get('guard_stop') is not None: raise SystemExit('supplement baseline guard stop')
        compare.command_artifact(row,'stdout'); compare.command_artifact(row,'stderr')
    if len(original.get('jarde_cells',[]))!=8 or len(original.get('jadx_cells',[]))!=4:
        raise SystemExit('original baseline must retain 8 Jarde selectors + 4 JADX source selectors')
    if len(supplement.get('jarde_cells',[]))!=16 or len(supplement.get('jadx_cells',[]))!=8:
        raise SystemExit('supplement baseline must retain 16 A/B Jarde + 8 JADX source selectors')
    if compare.pin(CLASS_HELPER) != supp_accept.get('classfile_helper'):
        raise SystemExit('classfile helper differs from accepted supplement baseline review')

    # Normalize the new API output. Jarde sources always come from the new final API;
    # only the already-frozen JADX extraction sources and original JVM oracles come
    # from the older accepted baselines.
    def exact_grid(rows, expected, label, keyfn):
        got=[keyfn(r) for r in rows]
        if len(got)!=len(expected) or set(got)!=set(expected): raise RuntimeError(f'{label} selector grid mismatch: {got}')
    old_original_jarde=original['jarde_cells']
    final_original=api.get('jarde_cells',[])
    oldkeys={(r['profile'],r['input_form'],r['evidence']) for r in old_original_jarde}
    exact_grid(final_original,oldkeys,'final original Jarde',lambda r:(r['profile'],r.get('input_form',r.get('form')),r['evidence']))
    supp_final=api.get('supplemental_cells',[])
    suppkeys={(r['variant'],r.get('compiler',r.get('input_compiler')),r['profile'],r['evidence']) for r in supplement['jarde_cells']}
    exact_grid(supp_final,suppkeys,'final supplement Jarde',lambda r:(r['variant'],r.get('compiler',r.get('input_compiler')),r['profile'],r['evidence']))

    sources=[]
    for r in final_original:
        if r.get('exit_code') != 0: raise RuntimeError('final API original Jarde cell did not produce a complete source')
        src,report,sp=source_and_report(r,compare,'final API original Jarde cell')
        if r.get('input'): ensure_pin(r['input'],compare,'final API original input class')
        if r.get('input_after') is not None and r.get('input_after') != r.get('input'): raise RuntimeError('original final API input changed')
        if r.get('target_class_input'): ensure_pin(r['target_class_input'],compare,'original target class input')
        if r.get('prior_report'): ensure_pin(r['prior_report'],compare,'original prior report')
        sources.append(dict(kind='jarde-original',profile=r['profile'],form=r.get('input_form',r.get('form')),
            evidence=r['evidence'],variant='NL5',input_compiler='original',source=src,report=report,source_path=sp,
            input=r.get('input'),cell_key=[r['profile'],r.get('input_form',r.get('form')),r['evidence']]))
    for r in original['jadx_cells']:
        if r.get('exit_code')!=0 or len(r.get('sources') or [])!=1: raise RuntimeError('incomplete original JADX source cell')
        src=r['sources'][0]; sp=ensure_pin(src,compare,'original JADX source')
        sources.append(dict(kind='jadx-original',profile=r['profile'],form=r['input_form'],evidence='source',variant='NL5',
            input_compiler='original',source=src,report=None,source_path=sp,cell_key=[r['profile'],r['input_form']]))
    for r in supp_final:
        if r.get('exit_code') != 0: raise RuntimeError('final API supplement Jarde cell did not produce a complete source')
        src,report,sp=source_and_report(r,compare,'final API supplement Jarde cell')
        if r.get('input'): ensure_pin(r['input'],compare,'final API supplement input class')
        if r.get('input_after') is not None and r.get('input_after') != r.get('input'): raise RuntimeError('supplement final API input changed')
        if r.get('target_class_input'): ensure_pin(r['target_class_input'],compare,'supplement target class input')
        if r.get('prior_report'): ensure_pin(r['prior_report'],compare,'supplement prior report')
        sources.append(dict(kind='jarde-supplement',profile=r['profile'],form='child',evidence=r['evidence'],
            variant=r['variant'],input_compiler=r.get('compiler',r.get('input_compiler')),source=src,report=report,
            source_path=sp,cell_key=[r['variant'],r.get('compiler',r.get('input_compiler')),r['profile'],r['evidence']],input=r.get('input')))
    for r in supplement['jadx_cells']:
        if r.get('exit_code')!=0 or len(r.get('sources') or [])!=1: raise RuntimeError('incomplete supplement JADX source cell')
        src=r['sources'][0]; sp=ensure_pin(src,compare,'supplement JADX source')
        sources.append(dict(kind='jadx-supplement',profile=r['profile'],form='child',evidence='source',variant=r['variant'],
            input_compiler=r['compiler'],source=src,report=None,source_path=sp,cell_key=[r['variant'],r['compiler'],r['profile']]))
    expected_counts={'jarde-original':8,'jadx-original':4,'jarde-supplement':16,'jadx-supplement':8}
    for k,n in expected_counts.items():
        if sum(x['kind']==k for x in sources)!=n: raise RuntimeError(f'{k} source-cell count mismatch')
    if len(sources)!=36: raise RuntimeError(f'expected 36 exact whole-source cells, got {len(sources)}')

    # Actual JDK oracles come only from original pinned JVM observations.
    oracle_original=ensure_pin(original['original_oracle'],compare,'original NL5 core oracle')
    oracle_check=ensure_pin(original['original_check_oracle'],compare,'original NL5 check oracle')
    core_bytes=oracle_original.read_bytes(); check_bytes=oracle_check.read_bytes()
    if len(core_bytes.splitlines())!=3 or len(check_bytes.splitlines())!=1: raise RuntimeError('original oracle row counts differ')
    oracles={}
    for variant,record in supplement['observed_oracles'].items():
        oracles[variant]=ensure_pin(record['file'],compare,f'{variant} observed oracle').read_bytes()
        if len(oracles[variant].splitlines())!=3: raise RuntimeError(f'{variant} oracle does not have 3 cases')

    out.mkdir(parents=True); rawdir=out/'raw'; rawdir.mkdir(); empty=out/'empty-classpath'; empty.mkdir()
    guard.ROOT=root; guard.OUT=rawdir; guard.target_bytes=lambda:scanner.target_bytes(root); guard.command_stream=compare.pin
    guard.expected_test_summaries=lambda index,data:None
    source_before=compare.source_closure(root)
    pinned_runtime_tools={
        'compare':compare.pin(compare_path),'guard':compare.pin(guard_path),'scanner':compare.pin(scanner_path),
        'classfile_helper':compare.pin(CLASS_HELPER),'jdk_manifest':compare.pin(root/JDK_REL),
        'timeout_wrapper':wrapper,'cli':cli_pin,'jadx':jadx,'jadx_jar':jadx_jar,
        'python':compare.pin(Path(sys.executable)),
    }
    api_source_before=api.get('source_closure_before')
    if api_source_before is not None and api_source_before != source_before:
        raise RuntimeError('workspace source closure differs from final API capture')
    if api.get('source_closure_after') is not None and api.get('source_closure_after') != api_source_before:
        raise RuntimeError('final API capture source closure changed during capture')
    original_driver_src=ensure_pin(driver_original,compare,'original driver source')
    supp_driver_src=ensure_pin(driver_supp,compare,'supplement driver source')
    driver_copy_dir=out/'driver-source';driver_copy_dir.mkdir()
    driver1=driver_copy_dir/'TestNestedLoops5Driver.java'; driver2=driver_copy_dir/'ParameterizedNestedReturnDriver.java'
    shutil.copyfile(original_driver_src,driver1); shutil.copyfile(supp_driver_src,driver2)
    if compare.pin(driver1)['sha256']!=driver_original['sha256'] or compare.pin(driver2)['sha256']!=driver_supp['sha256']:
        raise RuntimeError('driver copy mismatch')
    driver_classes=out/'driver-classes';driver_classes.mkdir();driver_empty=out/'empty-driver-classpath';driver_empty.mkdir()
    commands=[]; compile_cells=[]; runtime_rows=[]; wrong_roots=[]
    report={'schema':'cf11-testnestedloops5-final-rebuild-matrix-v1','status':'running','root':str(root),
        'api_receipt':api_pin,'api_command_count':len(api.get('commands',[])),'original_baseline':original_pin,'supplement_baseline':supp_pin,
        'original_review':orig_review_pin,'supplement_review':supp_review_pin,'product_revision':api['product_revision'],'cli':cli_pin,
        'jadx':jadx,'jadx_jar':jadx_jar,'original_oracle':original['original_oracle'],'check_oracle':original['original_check_oracle'],
        'supplement_oracles':supplement['observed_oracles'],'drivers':[driver_original,driver_supp],
        'final_api_old_receipts':api.get('old_receipts'),'final_api_class_inputs':api.get('class_inputs'),'final_api_fixture_manifests':api.get('fixture_manifests'),
        'runtime_wrapper':wrapper,'jdk_manifest':jdk_record,'compare':compare.pin(compare_path),'guard':compare.pin(guard_path),
        'scanner':compare.pin(scanner_path),'classfile_helper':compare.pin(CLASS_HELPER),'source_before':source_before,
        'runtime_tool_pins_before':pinned_runtime_tools,
        'original_dependency_jars':[original['harness_jar'],*original['jar_pins']],'original_dependency_class_trees':original['directory_pins'],
        'supplement_original_source':supplement['original_nl5_source'],'python':compare.pin(Path(sys.executable)),
        'source_inputs':[],'commands':commands,'driver_compile':None,'compile_cells':compile_cells,
        'runtime_rows':runtime_rows,'wrong_root_controls':wrong_roots,
        'compile_attempt_contract':{'original_sources':12,'supplement_sources':24,'total_source_cells':36,'compilers':2,'attempts':72},
        'notes':['Jarde cells are taken from the current final API receipt; older Jarde generation rows are preserved only in historical receipts.','Original and supplement JADX source inputs and all JVM oracles are taken from their accepted pinned baseline receipts.','No generated Java text is edited; failed compile has no runtime; successful target must be parsed as Java 8 major 52 with all expected methods and Code.','Original NL5 check() is run on both JVMs for every valid original class. A JDK8 major-55 harness failure is retained as a boundary, never a pass.','Supplement A/B core uses the same-instance 3-case driver and observed per-variant oracle.']}

    def save(): compare.write_json(out/'execution.json',report)
    def tree(p): return {x.relative_to(p).as_posix():compare.pin(x) for x in sorted(p.rglob('*')) if x.is_file()}
    def run(label,argv,leg):
        if (root/'target').exists(): raise RuntimeError('workspace target appeared')
        env={k:v for k,v in os.environ.items() if k not in ENV_STRIP};env=compare.clean_env(env,jdks[leg]);env.update(guard.ENV_VALUES);env.pop('RUST_MIN_STACK',None)
        row=guard.run_command(len(commands)+1,[str(x) for x in argv],env);row['label']=label;row['tool_leg']=leg;commands.append(row);save()
        if row.get('guard_stop') is not None: raise RuntimeError(f'guard stop: {label}: {row["guard_stop"]}')
        return row
    def runtime(label,classes,leg,mode,variant=None,wrong=None):
        cp=[str(classes),str(driver_classes)]
        driver='TestNestedLoops5Driver'; args=[str(classes),mode]
        if variant:
            driver='ParameterizedNestedReturnDriver';args=[f'NestedReturn{variant}$TestCls',str(classes)];cp=[str(classes),str(driver_classes)]
        if mode=='check': cp.extend(str(x) for x in classpath)
        before=tree(classes); driver_before=tree(driver_classes)
        if wrong is not None:
            args=[str(wrong),mode] if not variant else [f'NestedReturn{variant}$TestCls',str(wrong)]
        row=run(label,[sys.executable,'-B',str(wrapper['path']),'30',jdks[leg]['tools']['java'],'-Xverify:all','-cp',os.pathsep.join(cp),driver,*args],leg)
        row['classpath']=cp;row['expected_class_root']=str(classes);row['target_tree_before']=before;row['target_tree_after']=tree(classes);row['driver_tree_before']=driver_before;row['driver_tree_after']=tree(driver_classes)
        if row['target_tree_before']!=row['target_tree_after'] or row['driver_tree_before']!=row['driver_tree_after']:
            raise RuntimeError(f'class bytes changed during {label}')
        return row

    try:
        save()
        driver_compile=run('compile-independent-drivers', [jdks['javac8']['tools']['javac'],'-source','8','-target','8','-g:none','-Xlint:-options','-encoding','UTF-8','-proc:none','-classpath',str(driver_empty),'-sourcepath',str(driver_empty),'-d',driver_classes,driver1,driver2], 'javac8')
        if driver_compile['exit_code']!=0: raise RuntimeError('independent drivers did not compile')
        report['driver_compile']={'command':driver_compile['index'],'exit_code':0,'classes':tree(driver_classes)};save()
        for item in sources:
            if item['kind'].endswith('original'):
                filename='TestNestedLoops5.java' if item['form']=='bundle' else 'TestNestedLoops5$TestCls.java'
            else: filename=f'NestedReturn{item["variant"]}$TestCls.java'
            copy=out/'source-copies'/item['kind']/item['variant']/item['input_compiler']/item['profile']/item['form']/str(item['evidence'])/filename
            copy.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(item['source_path'],copy)
            item['source_copy']=compare.pin(copy)
            if item['source_copy']['sha256']!=item['source']['sha256'] or item['source_copy']['bytes']!=item['source']['bytes']:
                raise RuntimeError(f'whole-source copy differs: {item}')
            report['source_inputs'].append({k:item.get(k) for k in ('kind','variant','input_compiler','profile','form','evidence','cell_key','source','report','input','target_class_input','prior_report','source_copy')})
        for item in sources:
            for compiler in JDK_LEGS:
                is_original=item['variant']=='NL5'
                ident=[item['kind'],item['variant'],item['input_compiler'],item['profile'],item['form'],item['evidence'],compiler]
                cr=out/'classes'/item['kind']/item['variant']/item['input_compiler']/item['profile']/item['form']/str(item['evidence'])/compiler
                cr.mkdir(parents=True);sourcecopy=Path(item['source_copy']['path'])
                args8=['-source','8','-target','8'] if compiler=='javac8' else ['--release','8']
                cp=[] if not is_original else [str(x) for x in classpath]
                compilecp=os.pathsep.join(cp) if cp else str(empty)
                cargs=[jdks[compiler]['tools']['javac'],*args8,'-g' if item['profile']=='debug' else '-g:none','-encoding','UTF-8','-proc:none','-classpath',compilecp,'-sourcepath',str(empty),'-d',cr,sourcecopy]
                comp=run('compile-'+'-'.join(map(str,ident)),cargs,compiler)
                target=cr/(ORIGINAL_TARGET if is_original else Path(f'NestedReturn{item["variant"]}$TestCls.class'))
                cell={'identity':ident,'source':item['source'],'source_copy':item['source_copy'],'compile_command':comp['index'],'compile_exit_code':comp['exit_code'],'class_root':str(cr),'class_tree':tree(cr),'target_class':None,'status':'compile_failed_no_runtime' if comp['exit_code'] else 'compile_succeeded_unverified','runtime':[]}
                if comp['exit_code']:
                    stderr=compare.command_artifact(comp,'stderr')
                    cell['diagnostic_sha256']=sha(stderr)
                    if not stderr: cell['status']='compile_failed_no_runtime_empty_diagnostic'
                    compile_cells.append(cell);save();continue
                try:
                    all_facts=[]
                    for rel,pin in sorted(cell['class_tree'].items()):
                        cp=Path(cr)/rel; cf=helper.parse_class_file(cp.read_bytes())
                        all_facts.append({'relative_path':rel,'pin':pin,'facts':cf})
                    cell['classfile_facts']=all_facts
                    expected_tree={ORIGINAL_TARGET.as_posix()} if is_original else {f'NestedReturn{item["variant"]}$TestCls.class'}
                    if item['kind']=='jadx-original' and item['form']=='bundle':
                        expected_tree={ORIGINAL_TARGET.as_posix(),ORIGINAL_OWNER.as_posix()}
                    actual_tree=set(cell['class_tree'])
                    if actual_tree!=expected_tree: raise ValueError(f'class output tree mismatch: expected {sorted(expected_tree)}, got {sorted(actual_tree)}')
                    raw=target.read_bytes();facts=helper.parse_class_file(raw)
                    wantname='jadx/tests/integration/loops/TestNestedLoops5$TestCls' if is_original else f'NestedReturn{item["variant"]}$TestCls'
                    wantmethods=ORIGINAL_METHODS if is_original else SUPP_METHODS
                    valid=(facts['major']==52 and facts['class_name']==wantname and method_set(facts)==wantmethods and all(m['code'] is not None for m in facts['methods']))
                    if not valid: raise ValueError('target identity/major/method/Code mismatch')
                    if not is_original:
                        fields={(f['name'],f['descriptor'],f['access']) for f in facts['fields']}
                        if fields!={(name,'I',2) for name in SUPP_FIELDS}: raise ValueError('supplement state fields mismatch')
                    cell['classfile_facts']=all_facts
                    cell['target_class']={'path':str(target.resolve()),'bytes':len(raw),'sha256':sha(raw),'facts':facts};cell['status']='compiled_target_verified'
                except Exception as exc:
                    cell['status']='compiled_target_invalid_no_runtime';cell['validation_error']=str(exc);compile_cells.append(cell);save();continue
                compile_cells.append(cell);save()
                # Actual source origin and full compiled target are isolated for each JVM run.
                wrong=out/'wrong-root'/('/'.join(map(str,ident)));wrong.mkdir(parents=True)
                wrongrun=runtime('wrong-root-'+'-'.join(map(str,ident)),cr,'javac23','core',item['variant'] if not is_original else None,wrong)
                werr=compare.command_artifact(wrongrun,'stderr')
                if wrongrun['exit_code']==0 or b'target loaded from' not in werr: raise RuntimeError('wrong-root CodeSource control did not reject')
                wrong_roots.append({'identity':ident,'command':wrongrun['index'],'exit_code':wrongrun['exit_code'],'stderr_sha256':sha(werr)})
                legs=[]
                for leg in JDK_LEGS:
                    modes=('core','check') if is_original else ('core',)
                    for mode in modes:
                        rr=runtime(f'runtime-{mode}-'+'-'.join(map(str,ident))+'-'+leg,cr,leg,mode,item['variant'] if not is_original else None)
                        outbytes=compare.command_artifact(rr,'stdout'); errbytes=compare.command_artifact(rr,'stderr')
                        if is_original and mode=='core':
                            equal=rr['exit_code']==0 and outbytes==core_bytes
                            status='matches_original_core_oracle' if equal else 'runtime_failed_or_oracle_mismatch'
                        elif is_original and mode=='check' and leg=='javac23':
                            equal=rr['exit_code']==0 and outbytes==check_bytes
                            status='matches_original_check_oracle' if equal else 'check_failed_or_oracle_mismatch'
                        elif is_original and mode=='check' and leg=='javac8':
                            equal=False;status='observed_harness_major55_boundary_no_check_result' if rr['exit_code'] and (b'55.0' in errbytes or b'version 55' in errbytes) else 'unexpected_javac8_check_result'
                        else:
                            expected=oracles[item['variant']]
                            equal=rr['exit_code']==0 and outbytes==expected
                            status='matches_variant_original_oracle' if equal else 'runtime_failed_or_oracle_mismatch'
                        result={'mode':mode,'runtime':leg,'command':rr['index'],'exit_code':rr['exit_code'],'stdout_sha256':sha(outbytes),'stderr_sha256':sha(errbytes),'oracle_equal':equal,'status':status,'classpath':rr['classpath']}
                        cell['runtime'].append(result);runtime_rows.append({'identity':ident,**result});save()
                cell['status']='compiled_target_ran';save()
        # Re-verify all sources, reports, receipts, tools, and source closure after all commands.
        for item in sources:
            for role,record in (('source',item['source']),('report',item['report']),('source_copy',item.get('source_copy')),('input',item.get('input')),('target_class_input',item.get('target_class_input')),('prior_report',item.get('prior_report'))):
                if record: ensure_pin(record,compare,f'{role} after matrix')
        for p,r in ((api_path,api_pin),(ob/'execution.json',original_pin),(sb/'execution.json',supp_pin),(orev,orig_review_pin),(srev,supp_review_pin)):
            if compare.pin(p)!=r: raise RuntimeError(f'input receipt changed: {p}')
        for rec in (api['cli'],jadx,jadx_jar,wrapper,driver_original,driver_supp,original['original_oracle'],original['original_check_oracle']): ensure_pin(rec,compare,'pinned input after matrix')
        for cell in compile_cells:
            if tree(Path(cell['class_root'])) != cell['class_tree']:
                raise RuntimeError(f'compiled class tree changed after runs: {cell["identity"]}')
        if tree(driver_classes) != report['driver_compile']['classes']:
            raise RuntimeError('independent driver classes changed after runs')
        if compare.source_closure(root)!=source_before: raise RuntimeError('workspace source closure changed')
        if (root/'target').exists(): raise RuntimeError('workspace target appeared during matrix')
        if len(compile_cells)!=72: raise RuntimeError(f'expected 72 compile attempts, got {len(compile_cells)}')
        original_checks=[r for r in runtime_rows if r['identity'][1]=='NL5' and r['mode']=='check']
        report['observed_check_outcomes']={
            'javac23_oracle_matches':sum(r['runtime']=='javac23' and r['status']=='matches_original_check_oracle' for r in original_checks),
            'javac8_major55_boundaries':sum(r['runtime']=='javac8' and r['status']=='observed_harness_major55_boundary_no_check_result' for r in original_checks),
            'other_check_outcomes':[r for r in original_checks if r['status'] not in ('matches_original_check_oracle','observed_harness_major55_boundary_no_check_result')],
        }
        report['observed_compile_outcomes']={
            'attempts':len(compile_cells),
            'compile_failures':sum(c['compile_exit_code']!=0 for c in compile_cells),
            'verified_targets':sum(c['status']=='compiled_target_verified' or c['status']=='compiled_target_ran' for c in compile_cells),
            'other_no_runtime':[c['identity'] for c in compile_cells if c['status'] not in ('compile_failed_no_runtime','compiled_target_verified','compiled_target_ran')],
        }
        if not wrong_roots: raise RuntimeError('no successful target class was available for CodeSource wrong-root validation')
        for rec in [original['harness_jar'], *original['jar_pins']]: ensure_pin(rec,compare,'original dependency after matrix')
        for folder, expected in original['directory_pins'].items():
            actual={p.relative_to(folder).as_posix():compare.pin(p) for p in sorted(Path(folder).rglob('*.class'))}
            if actual != expected: raise RuntimeError(f'original dependency class tree changed: {folder}')
        for label,pin in pinned_runtime_tools.items():
            if compare.pin(Path(pin['path']))!=pin: raise RuntimeError(f'{label} tool/helper changed')
        for leg,tools in jdk_record['tools'].items():
            for toolpin in tools.values(): ensure_pin(toolpin,compare,f'{leg} tool after matrix')
        report['source_after']=source_before;report['target_absent']=True;report['status']='captured_pending_independent_review'
    except BaseException as exc:
        report['status']='failed';report['error']=f'{type(exc).__name__}: {exc}';raise
    finally:
        report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();shutil.copyfile(__file__,out/'collector.py')
    print(json.dumps({'status':report['status'],'source_cells':len(sources),'compile_attempts':len(compile_cells),'runtime_rows':len(runtime_rows),'wrong_root_controls':len(wrong_roots),'output':str(out)},sort_keys=True))
    return 0

if __name__=='__main__': raise SystemExit(main())
