from pathlib import Path
import json,hashlib,importlib.util,datetime,copy
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');RUN=Path('/private/tmp/jarde-loop-arm-final-matrix-root-v1-20261018')
def pin(p):
 p=Path(p).resolve(strict=True);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(r):
 assert pin(r['path'])=={k:r[k] for k in ('path','bytes','sha256')},r['path']
def tree(p):
 p=Path(p);return {x.relative_to(p).as_posix():pin(x) for x in sorted(p.rglob('*')) if x.is_file()}
p=RUN/'execution.json';before=p.read_bytes();d=json.loads(before)
assert d['status']=='failed' and d['error']=='RuntimeError: pinned input after matrix is not a file pin'
assert len(d['commands'])==277 and len(d['compile_cells'])==72 and len(d['runtime_rows'])==144
for row in d['commands']:
 assert row['guard_stop'] is None
 assert row['peak_target_bytes']<=1024**3 and row['free_bytes_after']>=5*1024**3
 for r in row['streams'].values():check(r)
for k in ('api_receipt','original_baseline','supplement_baseline','original_review','supplement_review'):check(d[k])
api=json.loads(Path(d['api_receipt']['path']).read_bytes());orig=json.loads(Path(d['original_baseline']['path']).read_bytes());supp=json.loads(Path(d['supplement_baseline']['path']).read_bytes())
for row in d['source_inputs']:
 for k in ('source','source_copy','report','input','target_class_input','prior_report'):
  if row.get(k):check(row[k])
 assert Path(row['source']['path']).read_bytes()==Path(row['source_copy']['path']).read_bytes()
for row in api['jarde_cells']+api['supplemental_cells']:
 for k in ('input','target_class_input','prior_report','report','whole_source'):check(row[k])
for r in [d['cli'],d['jadx'],d['jadx_jar'],d['runtime_wrapper'],*d['drivers'],orig['original_oracle'],orig['original_check_oracle']]:check(r)
for r in d['runtime_tool_pins_before'].values():check(r)
for leg in d['jdk_manifest']['tools'].values():
 for r in leg.values():check(r)
for r in [orig['harness_jar'],*orig['jar_pins']]:check(r)
for folder,expected in orig['directory_pins'].items():
 assert {p.relative_to(folder).as_posix():pin(p) for p in sorted(Path(folder).rglob('*.class'))}==expected
for r in supp['observed_oracles'].values():check(r['file'])
for cell in d['compile_cells']:assert tree(cell['class_root'])==cell['class_tree']
assert tree(RUN/'driver-classes')==d['driver_compile']['classes']
spec=importlib.util.spec_from_file_location('compare',d['compare']['path']);compare=importlib.util.module_from_spec(spec);spec.loader.exec_module(compare)
assert compare.source_closure(ROOT)==d['source_before']==api['source_closure_before']==api['source_closure_after']
assert not (ROOT/'target').exists()
# Preserve the failed producer record; this new receipt is explicitly an independent read-only finalization.
f=copy.deepcopy(d);f['collector_status']=f['status'];f['collector_error']=f.pop('error');f['collector_finished_utc']=f['finished_utc']
f['source_after']=d['source_before'];f['target_absent']=True
checks=[r for r in d['runtime_rows'] if r['identity'][1]=='NL5' and r['mode']=='check']
f['observed_check_outcomes']={'javac23_oracle_matches':sum(r['runtime']=='javac23' and r['status']=='matches_original_check_oracle' for r in checks),'javac8_major55_boundaries':sum(r['runtime']=='javac8' and r['status']=='observed_harness_major55_boundary_no_check_result' for r in checks),'other_check_outcomes':[r for r in checks if r['status'] not in ('matches_original_check_oracle','observed_harness_major55_boundary_no_check_result')]}
f['observed_compile_outcomes']={'attempts':72,'compile_failures':sum(c['compile_exit_code']!=0 for c in d['compile_cells']),'verified_targets':sum(c['status'] in ('compiled_target_verified','compiled_target_ran') for c in d['compile_cells']),'other_no_runtime':[c['identity'] for c in d['compile_cells'] if c['status'] not in ('compile_failed_no_runtime','compiled_target_verified','compiled_target_ran')]}
f['status']='captured_pending_independent_review';f['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();f['independent_finalization']={'original_failed_receipt':pin(p),'finalizer':pin(__file__),'scope':'All actual 277 commands are retained unchanged. Independently rechecked every skipped final source/receipt/tool/class-tree/JDK/dependency/closure check. No toolchain command rerun; original failed execution.json immutable. This does not claim the collector terminated successfully.'}
assert p.read_bytes()==before
out=RUN/'finalized-execution-root-v1.json';assert not out.exists();out.write_text(json.dumps(f,indent=2)+'\n');print(json.dumps({'finalized':pin(out),'original_status':d['status'],'compiles':f['observed_compile_outcomes'],'check':f['observed_check_outcomes']}))
