"""Bind both accepted native source sets and frozen CLI build to actual product Git blobs."""
from pathlib import Path
import json,hashlib,subprocess,argparse,stat
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
def pin(path):
 path=Path(path).resolve(strict=True);data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def load(path):return json.loads(Path(path).read_bytes())
a=argparse.ArgumentParser();a.add_argument('--product',required=True);a.add_argument('--build',required=True);a.add_argument('--seed1',required=True);a.add_argument('--seed2',required=True);a.add_argument('--out',required=True);args=a.parse_args()
out=Path(args.out);assert not out.exists() and not (ROOT/'target').exists()
b=load(args.build);x=load(args.seed1);y=load(args.seed2)
assert b['status']=='commands_passed_pending_independent_acceptance' and b['source_before']==b['source_after'] and b['target_absent']
assert all(d['status']=='passed' and d['pins_unchanged'] and d['target_absent_after_clean'] for d in (x,y))
assert x['seed']!=y['seed'] and x['source_pins']==y['source_pins']
expected=dict(x['source_pins'])
for row in b['source_after']:
 rel=str(Path(row['path']).relative_to(ROOT));assert expected.get(rel,row['sha256'])==row['sha256'];expected[rel]=row['sha256']
raw=subprocess.check_output(['git','ls-tree','-rz','--full-tree',args.product],cwd=ROOT);tree={}
for row in raw.split(b'\0'):
 if row:
  meta,path=row.split(b'\t',1);mode,kind,oid=meta.split();tree[path.decode()]={'mode':mode.decode(),'kind':kind.decode(),'oid':oid.decode()}
keys=sorted(expected);oids=[tree[k]['oid'] for k in keys]
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,input=('\n'.join(oids)+'\n').encode());pos=0;bindings=[]
for key,oid in zip(keys,oids):
 end=raw.index(b'\n',pos);header=raw[pos:end].split();assert header[0].decode()==oid and header[1]==b'blob';size=int(header[2]);pos=end+1;data=raw[pos:pos+size];pos+=size;assert raw[pos:pos+1]==b'\n';pos+=1
 path=ROOT/key;assert path.is_file() and not path.is_symlink();assert data==path.read_bytes() and hashlib.sha256(data).hexdigest()==expected[key]
 mode='100755' if path.stat().st_mode & 0o111 else '100644';assert tree[key]['mode']==mode
 bindings.append({'path':key,'git_blob':oid,'mode':mode,'bytes':size,'sha256':expected[key]})
assert pos==len(raw) and pin(b['cli']['path'])==b['cli']
report={'status':'accepted_build_and_two_native_sources_bound_to_product','product_revision':args.product,'cli':b['cli'],'build':pin(args.build),'seed1':pin(args.seed1),'seed2':pin(args.seed2),'counts':{'build':len(b['source_after']),'native_each':len(x['source_pins']),'union':len(keys)},'bindings':bindings,'binder':pin(__file__),'scope':'Product Git blobs and mode equal actual current source bytes; both native source maps equal; frozen CLI matches accepted build receipt. Documentation closure commit is a later descendant.'}
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'counts':report['counts'],'cli':b['cli']['sha256']}))
