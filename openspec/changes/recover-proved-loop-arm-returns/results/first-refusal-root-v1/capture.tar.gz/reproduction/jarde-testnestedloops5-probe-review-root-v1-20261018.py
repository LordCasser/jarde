import hashlib,json
from pathlib import Path
R=Path('/Users/lordcasser/workspace/projects/jarde'); O=Path('/private/tmp/jarde-testnestedloops5-first-refusal-root-v1-20261018');B=Path('/private/tmp/jarde-testnestedloops5-baseline-run-root-v3-20261018')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def verify(row): assert pin(row['path'])==row
j=json.loads((O/'execution.json').read_text()); b=json.loads((B/'execution.json').read_text()); build=json.loads((O/'build/execution.json').read_text())
assert j['status']=='probe_captured_pending_architect_review';assert j['source_restored'] and j['closure_restored'] and j['target_absent'];assert not (R/'target').exists()
for k in ('patch','runner','baseline','probe_cli'):verify(j[k])
for rel,row in j['source_after'].items():verify(row);assert (O/'original-source'/Path(rel).name).read_bytes()==(R/rel).read_bytes()
assert build['status']=='commands_passed_pending_independent_acceptance' and build['source_unchanged'] and build['target_absent']
assert len(build['commands'])==2 and build['commands'][0]['argv']==['cargo','build','-p','jarde-cli','--all-features'] and build['commands'][1]['argv']==['cargo','clean']
for row in build['commands']:
 assert row['exit_code']==0 and not row.get('guard_stop')
 for p in row['streams'].values():verify(p)
assert len(j['cells'])==8
api=[r for r in j['commands'] if 'streams' in r];assert len(api)==8
def norm(v):
 if isinstance(v,dict):return {k:norm(x) for k,x in v.items() if k!='usage'}
 if isinstance(v,list):return [norm(x) for x in v]
 return v
observations=[]
for c,r,old in zip(j['cells'],api,b['jarde_cells']):
 assert all(c[k]==old['input_form' if k=='form' else k] for k in ('profile','form','evidence'))
 assert r['exit_code']==0 and not r['guard_stop']
 for p in r['streams'].values():verify(p)
 verify(old['report']);assert norm(json.loads(Path(r['streams']['stdout']['path']).read_text()))==norm(json.loads(Path(old['report']['path']).read_text()))
 s=Path(r['streams']['stderr']['path']).read_text()
 for marker in ('NL5_PROBE code=', 'NL5_PROBE canonical=', 'NL5_PROBE normal_flow=', 'NL5_PROBE ssa=', 'NL5_PROBE effects=', 'forward_then=false forward_else=true', 'NL5_PROBE branch9 one_armed=Some(CanonicalBlockId { bci: 37, path: [] })', 'NL5_PROBE prefixed_arm prefix_closed=true', 'NL5_PROBE prefixed_arm refuse=loop_arm_join_source'):
  assert marker in s,marker
 canonical=s.split('NL5_PROBE canonical=',1)[1].split('NL5_PROBE normal_flow=',1)[0]
 assert canonical.count('kind: Normal')==12 and all('kind: Normal' in line for line in canonical.splitlines() if 'kind:' in line)
 view=s.split('NL5_PROBE normal_flow=',1)[1].split('    index:',1)[0]
 import re
 assert [int(n) for n in re.findall(r'bci: (\d+)',view)]==[0,4,9,46,14,37,16,21,29,31]
 assert 'blocks={1, 2, 4, 5, 6, 7, 9} latches={5}' in s and 'blocks={6, 7, 9} latches={9}' in s
 nested=s.split('NL5_PROBE prefixed_arm nested_walk',1)[1].split('NL5_PROBE prefixed_arm refuse=',1)[0]
 for marker in ('for_header: Some(', 'init_bci: 15', 'update_bci: 31', 'slot: 3', 'branch_bci: 26', 'bci: 29', 'bci: 31', 'join: None', 'gateway_origins: [\n            34,', 'loop_next=Some(CanonicalBlockId { bci: 37, path: [] })'):
  assert marker in nested,marker
 assert 'terminal_returns=[CanonicalBlockId { bci: 29, path: [] }]' in s
 observations.append({k:c[k] for k in ('profile','form','evidence','stderr')})
payload={'status':'accepted_first_refusal_observation_only','execution':pin(O/'execution.json'),'build':pin(O/'build/execution.json'),'checker':pin(__file__),'api_requests':8,'non_usage_json_unchanged':True,'source_restored':True,'target_absent':True,'first_refusal':'continue_prefixed_loop_arm successfully reads child loop16 but loop_arm_join_source returns None. Logged child AST has a no-join return/latch If, certified return29, ForHeader(init15/update31/slot3), gateway34 and ordinary exit37.','ids_bci_order':[0,4,9,46,14,37,16,21,29,31],'outer_natural_bcis':[4,9,14,16,21,31,37],'child_natural_bcis':[16,21,31],'return_leaf_bci':29,'normal_join_bci':37,'canonical_normal_edge_count':12,'observations':observations,'architect_inference_from_current_helper_source':'First closed_body predicate requires If.join Some; this logged child has join None. Natural-only owners, None passed to implicit_tail_latch_origin with a ForHeader, and rejection of every terminal block would also prevent the certified return leaf. Reuse existing leaf proof and latch helper; no new public AST/pass needed.','limits':['Diagnostic stderr only; no production fix applied.','Not a generated-source runtime acceptance.','The first helper predicate explanation is source-derived from the exact logged AST; the executed diagnostic explicitly proves the helper returned None.']}
(O/'root-review.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps({k:payload[k] for k in ('status','api_requests','first_refusal','source_restored','target_absent')}))
