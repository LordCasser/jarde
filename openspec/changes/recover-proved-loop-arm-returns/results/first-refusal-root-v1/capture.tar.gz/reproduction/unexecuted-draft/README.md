This draft was never applied/built/run. Root corrected the actual conditional BCI/offset to18/19 and five block9 log gates before executing root-v4. No failed fingerprint run is fabricated.
