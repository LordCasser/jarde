package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: no-debug.jar:jadx/tests/integration/loops/TestNestedLoops5.class */
public class TestNestedLoops5 extends IntegrationTest {

    /* JADX INFO: loaded from: no-debug.jar:jadx/tests/integration/loops/TestNestedLoops5$TestCls.class */
    public static class TestCls {
        public int testFor() {
            int i = 1;
            for (int i2 = 5; i2 > -1; i2--) {
                if (i2 > i) {
                    for (int i3 = 1; i3 < 5; i3++) {
                        if (i > i3 * 100) {
                            return 0;
                        }
                    }
                }
                i++;
            }
            return i;
        }

        public void check() {
            JadxAssertions.assertThat(testFor()).isEqualTo(7);
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().doesNotContain(new CharSequence[]{"continue;"});
    }
}
