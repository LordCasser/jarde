package jadx.tests.integration.loops;

import jadx.tests.api.utils.assertj.JadxAssertions;

/* JADX INFO: loaded from: TestNestedLoops5$TestCls.class */
public class TestNestedLoops5$TestCls {
    public int testFor() {
        int i = 1;
        for (int i2 = 5; i2 > -1; i2--) {
            if (i2 > i) {
                for (int i3 = 1; i3 < 5; i3++) {
                    if (i > i3 * 100) {
                        return 0;
                    }
                }
            }
            i++;
        }
        return i;
    }

    public void check() {
        JadxAssertions.assertThat(testFor()).isEqualTo(7);
    }
}
