package jadx.tests.integration.loops;

import jadx.tests.api.utils.assertj.JadxAssertions;

/* JADX INFO: loaded from: TestNestedLoops5$TestCls.class */
public class TestNestedLoops5$TestCls {
    public int testFor() {
        int tmp = 1;
        for (int i = 5; i > -1; i--) {
            if (i > tmp) {
                for (int j = 1; j < 5; j++) {
                    if (tmp > j * 100) {
                        return 0;
                    }
                }
            }
            tmp++;
        }
        return tmp;
    }

    public void check() {
        JadxAssertions.assertThat(testFor()).isEqualTo(7);
    }
}
