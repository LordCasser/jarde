package jadx.tests.integration.loops;

import jadx.tests.api.IntegrationTest;
import jadx.tests.api.utils.assertj.JadxAssertions;
import org.junit.jupiter.api.Test;

/* JADX INFO: loaded from: debug.jar:jadx/tests/integration/loops/TestNestedLoops5.class */
public class TestNestedLoops5 extends IntegrationTest {

    /* JADX INFO: loaded from: debug.jar:jadx/tests/integration/loops/TestNestedLoops5$TestCls.class */
    public static class TestCls {
        public int testFor() {
            int tmp = 1;
            for (int i = 5; i > -1; i--) {
                if (i > tmp) {
                    for (int j = 1; j < 5; j++) {
                        if (tmp > j * 100) {
                            return 0;
                        }
                    }
                }
                tmp++;
            }
            return tmp;
        }

        public void check() {
            JadxAssertions.assertThat(testFor()).isEqualTo(7);
        }
    }

    @Test
    public void test() {
        JadxAssertions.assertThat(getClassNode(TestCls.class)).code().doesNotContain(new CharSequence[]{"continue;"});
    }
}
