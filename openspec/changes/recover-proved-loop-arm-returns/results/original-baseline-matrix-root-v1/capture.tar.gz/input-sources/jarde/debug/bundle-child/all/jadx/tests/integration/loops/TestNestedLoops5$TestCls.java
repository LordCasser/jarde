// jarde: presentation of `jadx/tests/integration/loops/TestNestedLoops5$TestCls` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package jadx.tests.integration.loops;

public class TestNestedLoops5$TestCls extends java.lang.Object {
    public TestNestedLoops5$TestCls() {
        // @method <init>()V
        // @declaration a constructor of `jadx.tests.integration.loops.TestNestedLoops5$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public int testFor() {
        // jarde: not recovered: the recovery run for `testFor()I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method testFor()I
        // @declaration an instance method of `jadx.tests.integration.loops.TestNestedLoops5$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 1 2 3 4 5 6 9 10 11 14 15 16 17 18 21 22 23 25 26 29 30 31 34 37 40 43 46 47
        // the arms of the branch in block 9 do not meet at one join
    }

    public void check() {
        // @method check()V
        // @declaration an instance method of `jadx.tests.integration.loops.TestNestedLoops5$TestCls`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        jadx.tests.api.utils.assertj.JadxAssertions.assertThat(this.testFor()).isEqualTo(7);
        return;
    }
}
