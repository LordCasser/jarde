#!/usr/bin/env python3
"""Independent, read-only review of one TestNestedLoops5 complete-source rebuild receipt."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
BASELINE_DIR = Path('/private/tmp/jarde-testnestedloops5-baseline-run-root-v3-20261018').resolve()
BASELINE_REVIEW = Path('/private/tmp/jarde-testnestedloops5-baseline-review-root-v1-20261018/root-review.json')
PREP = Path('/private/tmp/jarde-testnestedloops5-rebuild-matrix-prep-root-v2-20261018')
COLLECTOR = PREP / 'collect_rebuild_matrix.py'
TARGET = 'jadx/tests/integration/loops/TestNestedLoops5$TestCls'
OWNER = 'jadx/tests/integration/loops/TestNestedLoops5'
METHODS = {('<init>', '()V'), ('testFor', '()I'), ('check', '()V')}
KINDS = ('jarde', 'jadx')
PROFILES = ('debug', 'no-debug')
FORMS = {'jarde': ('child', 'bundle-child'), 'jadx': ('child', 'bundle')}
EVIDENCE = ('default', 'all')
COMPILERS = ('javac8', 'javac23')
RUNTIMES = ('javac8', 'javac23')
EXPECTED_LABEL_PREFIX = ('compile-', 'runtime-core-', 'runtime-check-')


def load_helpers(path: Path):
    spec = importlib.util.spec_from_file_location('nl5_matrix_classfile_helpers', path)
    if spec is None or spec.loader is None:
        raise ValueError(f'cannot load pinned classfile helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin_bytes(data: bytes) -> dict:
    return {'bytes': len(data), 'sha256': sha(data)}


def verify_pin(record: dict, label: str) -> bytes:
    need(isinstance(record, dict), f'{label}: missing pin')
    path = Path(record.get('path', ''))
    need(path.is_absolute() and path.is_file(), f'{label}: missing pinned file {path}')
    data = path.read_bytes()
    need(len(data) == record.get('bytes') and sha(data) == record.get('sha256'),
         f'{label}: bytes/SHA-256 mismatch')
    return data


def method_set(parsed: dict) -> set[tuple[str, str]]:
    return {(row['name'], row['descriptor']) for row in parsed['methods']}


def code_signature(parsed: dict) -> dict:
    return { (row['name'], row['descriptor']): row['code'] for row in parsed['methods'] }


def source_inputs_grid(rows: list[dict]) -> dict[tuple, dict]:
    result = {}
    for row in rows:
        key = (row['kind'], row['profile'], row['form'], row.get('evidence'))
        need(key not in result, f'duplicate source input {key}')
        result[key] = row
    expected = set()
    for kind in KINDS:
        for profile in PROFILES:
            for form in FORMS[kind]:
                for evidence in (EVIDENCE if kind == 'jarde' else ('source',)):
                    expected.add((kind, profile, form, evidence))
    need(set(result) == expected, 'source-input inventory differs from 8 Jarde + 4 JADX cells')
    return result


def cmd_stream(row: dict, name: str, raw_dir: Path) -> bytes:
    stream = row.get('streams', {}).get(name)
    need(isinstance(stream, dict), f'{row.get("label")}: missing {name} receipt')
    path = Path(stream.get('path', ''))
    need(path == raw_dir / f'{row["index"]}.{name}.raw', f'{row.get("label")}: raw path mismatch')
    return verify_pin(stream, f'{row.get("label")} {name}')


def validate_source_inputs(doc: dict, baseline: dict, helpers) -> dict:
    grid = source_inputs_grid(doc.get('source_inputs', []))
    expected = {}
    for row in baseline.get('jarde_cells', []):
        key = ('jarde', row['profile'], row['input_form'], row['evidence'])
        expected[key] = (row['whole_source'], row['report'], row['input'])
    baseline_commands = {row['index']: row for row in baseline.get('commands', [])}
    for row in baseline.get('jadx_cells', []):
        key = ('jadx', row['profile'], row['input_form'], 'source')
        command = baseline_commands.get(row.get('command'))
        need(command is not None and command.get('argv'), f'{key}: baseline JADX command missing')
        input_path = Path(command['argv'][-1]).resolve(strict=True)
        expected[key] = (row['sources'][0], None, helpers.file_pin(input_path))
    need(set(expected) == set(grid), 'baseline source artifact inventory differs from matrix inputs')
    for key, item in grid.items():
        source, report, input_pin = expected[key]
        need(item.get('original_source') == source and item.get('original_report') == report
             and item.get('input_pin') == input_pin, f'{key}: matrix source does not bind exact baseline artifact')
        expected_name = ('TestNestedLoops5$TestCls.java' if key[2] in ('child', 'bundle-child')
                         else 'TestNestedLoops5.java')
        need(item.get('source_filename') == expected_name, f'{key}: copied source has wrong Java public-type filename')
    return {'source_inputs': len(grid), 'bound_to_exact_baseline_artifacts': True}


def validate_commands(doc: dict, out: Path) -> dict[str, dict]:
    rows = doc.get('commands')
    need(isinstance(rows, list) and rows, 'missing command list')
    raw_dir = out / 'raw'
    by_index, by_label = {}, {}
    for row in rows:
        index, label = row.get('index'), row.get('label')
        need(isinstance(index, int) and index not in by_index, f'invalid/duplicate command index {index}')
        need(isinstance(label, str) and label not in by_label, f'invalid/duplicate command label {label}')
        need(row.get('guard_stop') is None, f'guard stopped {label}: {row.get("guard_stop")}')
        need(Path(row.get('cwd', '')).resolve() == ROOT, f'{label}: cwd mismatch')
        need(isinstance(row.get('argv'), list) and row['argv'], f'{label}: argv missing')
        cmd_stream(row, 'stdout', raw_dir)
        cmd_stream(row, 'stderr', raw_dir)
        by_index[index], by_label[label] = row, row
    need(sorted(by_index) == list(range(1, len(rows) + 1)), 'command indices are not sequential 1-based')
    return by_label


def validate_matrix_commands(doc: dict, by_label: dict[str, dict], baseline: dict, helpers, out: Path) -> dict:
    compile_cells = doc.get('compilation_cells')
    need(isinstance(compile_cells, list) and len(compile_cells) == 24,
         f'expected 24 compilation cells, got {len(compile_cells) if isinstance(compile_cells, list) else "missing"}')
    source_grid = source_inputs_grid(doc.get('source_inputs', []))
    cell_keys = set()
    expected_compile = set()
    eligible = {}
    compile_failures = []
    no_runtime_outcomes = []
    for cell in compile_cells:
        kind, profile, form, evidence, compiler = (cell.get('kind'), cell.get('profile'), cell.get('form'),
                                                    cell.get('evidence'), cell.get('compiler'))
        key = (kind, profile, form, evidence, compiler)
        need(key not in cell_keys, f'duplicate compilation cell {key}')
        cell_keys.add(key)
        need(kind in KINDS and profile in PROFILES and form in FORMS[kind] and compiler in COMPILERS,
             f'invalid compilation-cell selector {key}')
        need((kind == 'jarde' and evidence in EVIDENCE) or (kind == 'jadx' and evidence == 'source'),
             f'invalid evidence selector {key}')
        expected_compile.add(key)
        label = f'compile-{kind}-{profile}-{form}-{evidence}-{compiler}'
        need(cell.get('compile_command') and label in by_label, f'{key}: compile command absent')
        cmd = by_label[label]
        need(cell['compile_command'] == cmd['index'] and cell.get('compile_exit_code') == cmd.get('exit_code'),
             f'{key}: compile receipt does not match its command')
        argv = cmd['argv']
        need(argv[0] == doc['jdk_manifest']['tools'][compiler]['javac']['path'], f'{label}: compiler argv mismatch')
        options = (['-source', '8', '-target', '8', '-g:none', '-Xlint:-options', '-proc:none']
                   if compiler == 'javac8' else ['--release', '8', '-g:none', '-proc:none'])
        item = source_grid[(kind, profile, form, evidence)]
        copied_source = Path(item['source_copy']['path'])
        # Use the actual -d and source operands as the authority for path shape.
        empty = Path(argv[argv.index('-sourcepath') + 1])
        classes = Path(argv[argv.index('-d') + 1])
        expected_argv = [doc['jdk_manifest']['tools'][compiler]['javac']['path'], *options, '-encoding', 'UTF-8',
                         '-classpath', os.pathsep.join(doc['classpath_full_bundle']), '-sourcepath', str(empty),
                         '-d', str(classes), str(copied_source)]
        need(argv == expected_argv, f'{label}: compiler argv differs from exact full-source rebuild contract')
        need(empty.is_dir() and not any(empty.iterdir()), f'{label}: sourcepath isolation directory is not empty')
        need(Path(cell['target_class_expected']) == classes / (TARGET + '.class'), f'{label}: expected target path mismatch')
        need(cell.get('source') == item.get('source_copy') and cell.get('original_source') == item.get('original_source'),
             f'{label}: copied source pins do not match source inventory')
        source_bytes = verify_pin(item['source_copy'], f'{label} source copy')
        original_bytes = verify_pin(item['original_source'], f'{label} original source')
        need(source_bytes == original_bytes, f'{label}: rebuild source is not an exact byte copy')
        if item.get('original_report'):
            report_bytes = verify_pin(item['original_report'], f'{label} report JSON')
            need(json.loads(report_bytes).get('text', '').encode('utf-8') == original_bytes,
                 f'{label}: Jarde report text differs from original source bytes')
        exit_code = cmd['exit_code']
        need(isinstance(exit_code, int), f'{label}: missing actual exit status')
        if exit_code != 0:
            need(cell['status'] == 'compile_failed_no_runtime' and cell.get('target_class') is None
                 and cell.get('target_facts') is None and cell.get('runtime') == [],
                 f'{label}: failure was not retained as compile-failed/no-runtime')
            compile_failures.append({'selector': list(key), 'exit_code': exit_code,
                                     'stderr_sha256': sha(cmd_stream(cmd, 'stderr', out / 'raw'))})
            no_runtime_outcomes.append({'selector': list(key), 'status': cell['status'], 'compile_exit_code': exit_code})
            continue
        target_path = Path(cell['target_class_expected'])
        if not target_path.is_file():
            need(cell['status'] == 'compile_succeeded_target_missing_no_runtime' and cell.get('runtime') == []
                 and cell.get('target_class') is None and cell.get('target_facts') is None,
                 f'{label}: successful but missing target not represented as no-runtime')
            no_runtime_outcomes.append({'selector': list(key), 'status': cell['status'], 'compile_exit_code': exit_code})
            continue
        target_pin = cell.get('target_class')
        class_bytes = verify_pin(target_pin, f'{label} target class')
        need(Path(target_pin['path']) == target_path, f'{label}: target class path differs')
        parsed = helpers.parse_class_file(class_bytes)
        facts = cell.get('target_facts') or {}
        need(facts.get('major') == parsed['major'] and facts.get('class_name') == parsed['class_name'],
             f'{label}: collector class header differs from independent parsing')
        fact_methods = {(row['name'], row['descriptor']): row for row in facts.get('methods', [])}
        actual_methods = {(row['name'], row['descriptor']): row for row in parsed['methods']}
        need(set(fact_methods) == set(actual_methods), f'{label}: receipt and class method inventories differ')
        for method_key, actual_row in actual_methods.items():
            recorded = fact_methods[method_key]
            actual_code = actual_row.get('code')
            recorded_code = recorded.get('code')
            need((recorded_code is None) == (actual_code is None), f'{label} {method_key}: Code presence differs')
            if actual_code is not None:
                need(recorded_code == actual_code and recorded['access'] == actual_row['access'] and recorded['index'] == actual_row['index'], f'{label} {method_key}: full Code/index/access differs from class bytes')
        identity_matches = parsed['class_name'] == TARGET and method_set(parsed) == METHODS
        all_code = all(row.get('code') is not None for row in parsed['methods'])
        major_matches = parsed['major'] == 52
        need(cell.get('declared_methods_match_expected') is identity_matches
             and cell.get('all_methods_have_code') is all_code
             and cell.get('classfile_major_is_java8') is major_matches,
             f'{label}: collector identity/Code/major summary disagrees with class bytes')
        tree = cell.get('target_classes_tree')
        need(isinstance(tree, dict) and tree, f'{label}: full output class tree was not pinned')
        current_tree = {}
        for path in sorted(classes.rglob('*.class')):
            current_tree[path.relative_to(classes).as_posix()] = helpers.file_pin(path)
        need(tree == current_tree, f'{label}: output class tree differs from receipt')
        owner_path = classes / (OWNER + '.class')
        if cell.get('owner_class') is not None:
            verify_pin(cell['owner_class'], f'{label} outer owner')
            need(Path(cell['owner_class']['path']) == owner_path, f'{label}: owner class path mismatch')
        else:
            need(not owner_path.exists(), f'{label}: emitted outer owner class omitted from receipt')
        need(cell.get('target_classes_root') == str(classes), f'{label}: target classes root differs')
        eligible_by_facts = identity_matches and all_code and major_matches
        expected_status = ('compiled_target_java8_three_methods' if eligible_by_facts
                           else 'compiled_target_identity_or_major_mismatch_no_runtime')
        need(cell['status'] == expected_status, f'{label}: status disagrees with actual class identity/Code/major')
        if eligible_by_facts:
            eligible[key] = {'cell': cell, 'classes': classes, 'parsed': parsed}
        else:
            need(cell.get('runtime') == [], f'{label}: identity/major mismatch must have no runtime')
            no_runtime_outcomes.append({'selector': list(key), 'status': cell['status'], 'compile_exit_code': exit_code,
                                        'class_name': parsed['class_name'], 'major': parsed['major'],
                                        'methods': sorted([list(pair) for pair in method_set(parsed)]),
                                        'all_methods_have_code': all_code})
    expected_keys = {(kind, profile, form, evidence, compiler)
                     for kind in KINDS for profile in PROFILES for form in FORMS[kind]
                     for evidence in (EVIDENCE if kind == 'jarde' else ('source',)) for compiler in COMPILERS}
    need(cell_keys == expected_keys and expected_compile == expected_keys, '24 compile-grid inventory mismatch')
    return {'eligible': eligible, 'compile_failures': compile_failures, 'no_runtime_outcomes': no_runtime_outcomes,
            'compile_cell_count': len(compile_cells), 'eligible_count': len(eligible)}


def validate_runtime(doc: dict, by_label: dict[str, dict], matrix: dict, baseline: dict, helpers, out: Path) -> dict:
    oracle = verify_pin(baseline['original_oracle'], 'original core oracle')
    check_oracle = verify_pin(baseline['original_check_oracle'], 'original check oracle')
    runtime_rows = doc.get('runtime_rows')
    need(isinstance(runtime_rows, list), 'runtime_rows missing')
    cell_runtime_rows = []
    expected_runtime_labels = set()
    core_equal = check23_equal = check8_boundary = 0
    observed_failures = []
    for key, eligible in matrix['eligible'].items():
        cell = eligible['cell']
        classes = eligible['classes']
        cell_rows = cell.get('runtime')
        need(isinstance(cell_rows, list) and len(cell_rows) == 4, f'{key}: eligible target requires four actual runtime observations')
        seen = set()
        for row in cell_rows:
            mode, runtime = row.get('mode'), row.get('runtime')
            need(mode in ('core', 'check') and runtime in RUNTIMES and (mode, runtime) not in seen,
                 f'{key}: invalid/duplicate runtime selector')
            seen.add((mode, runtime))
            label = f'runtime-{mode}-{key[0]}-{key[1]}-{key[2]}-{key[3]}-{key[4]}-on-{runtime}'
            need(label in by_label, f'{key}: missing command {label}')
            expected_runtime_labels.add(label)
            cmd = by_label[label]
            need(row.get('command') == cmd['index'] and row.get('exit_code') == cmd.get('exit_code'),
                 f'{label}: runtime row not bound to actual command')
            cp = [str(classes), str(Path(doc['driver_compile']['classes'][0]['path']).parent)]
            if mode == 'check':
                cp.extend(doc['classpath_full_bundle'])
            need(row.get('classpath') == cp, f'{label}: recorded runtime classpath differs')
            argv = cmd['argv']
            need(len(argv) >= 9 and argv[0] == sys.executable and argv[1] == '-B', f'{label}: Python runtime wrapper invocation differs')
            wrapper = str(Path(doc['runtime_timeout_wrapper']['path']))
            need(argv[2] == wrapper and argv[3] == '30', f'{label}: runtime timeout wrapper operands differ')
            need(argv[4] == doc['jdk_manifest']['tools'][runtime]['java']['path'], f'{label}: JVM path differs from pinned manifest')
            need(argv[5:8] == ['-Xverify:all', '-cp', os.pathsep.join(cp)], f'{label}: strict JVM flags/classpath differ')
            need(argv[8:] == ['TestNestedLoops5Driver', str(classes), mode], f'{label}: runtime driver operands differ')
            stdout = cmd_stream(cmd, 'stdout', out / 'raw')
            stderr = cmd_stream(cmd, 'stderr', out / 'raw')
            need(row.get('stdout_sha256') == sha(stdout) and row.get('stderr_sha256', sha(stderr)) == sha(stderr),
                 f'{label}: stored output digest differs from raw streams')
            expected_oracle = oracle if mode == 'core' else check_oracle
            need(row.get('oracle_equal_byte_for_byte') is (cmd['exit_code'] == 0 and stdout == expected_oracle),
                 f'{label}: oracle equality flag is not derived from raw bytes')
            if mode == 'core':
                if cmd['exit_code'] == 0 and stdout == oracle:
                    need(row.get('status') == 'matches_original_core_oracle', f'{label}: matching core status wrong')
                    core_equal += 1
                else:
                    expected_status = 'runtime_failed' if cmd['exit_code'] != 0 else 'core_oracle_mismatch'
                    need(row.get('status') == expected_status, f'{label}: core failure/mismatch mislabeled')
                    observed_failures.append({'label': label, 'exit_code': cmd['exit_code'], 'status': row.get('status'),
                                              'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr)})
            elif runtime == 'javac23':
                if cmd['exit_code'] == 0 and stdout == check_oracle:
                    need(row.get('status') == 'matches_original_check_oracle', f'{label}: matching check status wrong')
                    check23_equal += 1
                else:
                    status = 'runtime_failed' if cmd['exit_code'] != 0 else 'check_oracle_mismatch'
                    need(row.get('status') == status, f'{label}: JDK23 check mismatch/failure mislabeled')
                    observed_failures.append({'label': label, 'exit_code': cmd['exit_code'], 'status': row.get('status'),
                                              'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr)})
            else:
                if cmd['exit_code'] != 0 and (b'55.0' in stderr or b'version 55' in stderr):
                    need(row.get('status') == 'observed_harness_major55_boundary_no_check_result',
                         f'{label}: major-55 boundary mislabeled')
                    check8_boundary += 1
                elif cmd['exit_code'] == 0 and stdout == check_oracle:
                    need(row.get('status') == 'matches_original_check_oracle', f'{label}: JDK8 check oracle status wrong')
                else:
                    status = 'runtime_failed' if cmd['exit_code'] != 0 else 'check_oracle_mismatch'
                    need(row.get('status') == status, f'{label}: JDK8 check result mislabeled')
                    observed_failures.append({'label': label, 'exit_code': cmd['exit_code'], 'status': row.get('status'),
                                              'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr)})
            # CodeSource proof and no class-tree mutation are checked around each run.
            before, after = cmd.get('target_class_tree_before'), cmd.get('target_class_tree_after')
            need(before == after and before == cell['target_classes_tree'], f'{label}: target classes changed during execution')
            driver_before, driver_after = cmd.get('driver_class_tree_before'), cmd.get('driver_class_tree_after')
            expected_driver_tree = doc['driver_compile'].get('classes_tree')
            need(driver_before == driver_after == expected_driver_tree, f'{label}: independent driver classes changed or differ from their pin')
            need(Path(cmd.get('expected_target_root', '')).resolve() == classes.resolve(), f'{label}: CodeSource expected root differs')
        need(seen == {('core', runtime) for runtime in RUNTIMES} | {('check', runtime) for runtime in RUNTIMES},
             f'{key}: runtime matrix incomplete')
        cell_runtime_rows.extend(cell_rows)
    # Verify summary rows are a lossless, order-preserving projection from per-cell runtime rows.
    expected_projection = []
    for cell in doc['compilation_cells']:
        if cell.get('status') == 'compiled_target_java8_three_methods':
            for row in cell['runtime']:
                expected_projection.append({**{k: cell[k] for k in ('kind','profile','form','evidence','compiler')}, **row})
    need(runtime_rows == expected_projection, 'top-level runtime_rows differs from complete per-cell runtime records')
    command_runtime_labels = {label for label in by_label if label.startswith(('runtime-core-', 'runtime-check-'))}
    need(command_runtime_labels == expected_runtime_labels, 'runtime command inventory has missing or extra rows')
    return {'runtime_row_count': len(runtime_rows), 'expected_runtime_row_count': len(expected_projection),
            'core_oracle_matches': core_equal, 'check_javac23_oracle_matches': check23_equal,
            'check_javac8_major55_boundaries': check8_boundary, 'runtime_failures_or_mismatches': observed_failures}


def validate_driver_and_guards(doc: dict, by_label: dict[str, dict], baseline: dict, matrix: dict, helpers, out: Path) -> dict:
    driver_compile = doc.get('driver_compile')
    need(isinstance(driver_compile, dict), 'independent driver compile record missing')
    cmd = by_label.get('compile-independent-driver-javac8')
    need(cmd is not None and driver_compile.get('command') == cmd['index'] and cmd['exit_code'] == 0
         and driver_compile.get('exit_code') == 0, 'independent driver did not compile successfully')
    driver_classes_root = Path(driver_compile['classes'][0]['path']).parent
    driver_source_path = Path(driver_compile['source']['path'])
    driver_empty = out / 'empty-sourcepath-driver'
    driver_javac = doc['jdk_manifest']['tools']['javac8']['javac']['path']
    expected_driver_argv = [driver_javac, '-source', '8', '-target', '8', '-g:none', '-Xlint:-options', '-encoding', 'UTF-8',
                            '-proc:none', '-classpath', str(driver_empty), '-sourcepath', str(driver_empty),
                            '-d', str(driver_classes_root), str(driver_source_path)]
    need(cmd['argv'] == expected_driver_argv, 'independent driver compile argv differs from the reviewed contract')
    original_driver = verify_pin(baseline['driver'], 'frozen baseline driver source')
    driver_source = verify_pin(driver_compile['source'], 'copied matrix driver source')
    need(driver_source == original_driver, 'matrix driver source differs byte-for-byte from frozen baseline driver')
    need(Path(driver_compile['source']['path']) == out / 'driver-source' / 'TestNestedLoops5Driver.java',
         'driver source is not at expected matrix copy path')
    driver_classes = [verify_pin(pin, 'compiled driver class') for pin in driver_compile.get('classes', [])]
    need(len(driver_classes) == 1 and Path(driver_compile['classes'][0]['path']).name == 'TestNestedLoops5Driver.class',
         'independent driver class inventory differs')
    driver_tree = driver_compile.get('classes_tree')
    actual_tree = {}
    class_root = Path(driver_compile['classes'][0]['path']).parent
    for path in sorted(class_root.rglob('*.class')):
        actual_tree[path.relative_to(class_root).as_posix()] = helpers.file_pin(path)
    need(driver_tree == actual_tree and doc.get('driver_classes_tree_after') == driver_tree,
         'independent driver class tree changed or differs from its pin')
    need(doc.get('driver_copy_after') == driver_compile['source'], 'driver source final pin differs from original copy pin')
    wrong_rows = doc.get('wrong_root_controls')
    need(isinstance(wrong_rows, list) and len(wrong_rows) == 1, 'expected exactly one wrong-root CodeSource control')
    wrong = wrong_rows[0]
    wrong_command = by_label.get('matrix-wrong-root-code-source-rejection')
    need(wrong_command is not None and wrong.get('command') == wrong_command['index']
         and wrong_command.get('exit_code') != 0, 'wrong-root control did not fail')
    stderr = helpers.verify_pin(wrong_command['streams']['stderr'], 'wrong-root stderr')
    wrong_argv = wrong_command['argv']
    first = next(iter(matrix['eligible'].values()))
    wrong_target_root = first['classes']
    driver_root = Path(driver_compile['classes'][0]['path']).parent
    wrong_expected_root = Path(wrong['expected_root'])
    expected_wrong_argv = [sys.executable, '-B', str(Path(doc['runtime_timeout_wrapper']['path'])), '30',
                           doc['jdk_manifest']['tools']['javac23']['java']['path'], '-Xverify:all', '-cp',
                           os.pathsep.join([str(wrong_target_root), str(driver_root)]),
                           'TestNestedLoops5Driver', str(wrong_expected_root), 'core']
    need(wrong_argv == expected_wrong_argv, 'wrong-root JVM command differs from strict isolated contract')
    need(b'target loaded from' in stderr and wrong.get('stderr_sha256') == sha(stderr),
         'wrong-root control lacks the CodeSource mismatch evidence')
    need(Path(wrong.get('expected_root', '')).exists() and Path(wrong['expected_root']).name == 'empty-wrong-root',
         'wrong-root expected root was not isolated empty directory')
    return {'driver_source_byte_identical_to_baseline': True, 'driver_class_count': len(driver_classes),
            'wrong_root_rejected': True, 'wrong_root_stderr_sha256': sha(stderr)}


def validate_final_pins(doc: dict, baseline_path: Path, baseline: dict, helpers, root: Path) -> dict:
    need(doc.get('source_unchanged') is True and doc.get('baseline_unchanged') is True and doc.get('target_absent') is True,
         'collector did not certify final source/baseline/target guard state')
    need(not (root / 'target').exists() and not (root / 'target').is_symlink(), 'repository target is present at review time')
    need(doc.get('source_before') == doc.get('source_after'), 'workspace source closure differs before/after matrix')
    current = helpers.source_closure(root)
    need(current == doc['source_before'], 'current workspace source closure differs from matrix source guard')
    need(Path(doc['baseline_receipt']['path']) == baseline_path and helpers.file_pin(baseline_path) == doc['baseline_receipt'],
         'baseline receipt final pin differs')
    need(doc.get('baseline_original_oracle') == baseline['original_oracle']
         and doc.get('baseline_check_oracle') == baseline['original_check_oracle'],
         'matrix receipt oracle pins differ from baseline')
    for name, original in [('oracle_after', baseline['original_oracle']), ('check_oracle_after', baseline['original_check_oracle'])]:
        need(doc.get(name) == original and helpers.file_pin(Path(original['path'])) == original,
             f'{name} differs from frozen baseline oracle')
    need(doc.get('product_revision') == baseline.get('product_revision')
         and doc.get('cli') == baseline.get('cli') and doc.get('jadx') == baseline.get('jadx')
         and doc.get('jadx_jar') == baseline.get('jadx_jar'),
         'matrix product/JADX pins differ from frozen baseline')
    for item in ('cli', 'jadx', 'jadx_jar'):
        helpers.verify_pin(doc[item], f'final {item}')
    need(doc.get('runtime_timeout_wrapper') == baseline.get('runtime_bound'),
         'matrix runtime guard differs from the frozen baseline')
    helpers.verify_pin(doc['runtime_timeout_wrapper'], 'final runtime timeout wrapper')
    need(doc.get('inputs_after', {}).get('dependency_reference') == baseline.get('dependency_reference')
         and doc.get('classpath_full_bundle') == baseline.get('classpath'),
         'matrix dependency closure differs from baseline')
    need(doc.get('jdk_manifest') == baseline.get('jdk_manifest'), 'JDK manifest/tool pins differ from baseline')
    need(doc.get('runtime_core_classpath') == 'rebuilt-target-classes + independent-driver-classes only'
         and doc.get('runtime_check_classpath') == 'rebuilt-target-classes + independent-driver-classes + pinned original check-helper classpath',
         'runtime classpath mode contract differs')
    after = doc.get('inputs_after') or {}
    need(after.get('cli') == doc['cli'] and after.get('jadx') == doc['jadx']
         and after.get('jadx_jar') == doc['jadx_jar']
         and after.get('runtime_wrapper') == doc['runtime_timeout_wrapper']
         and after.get('dependency_reference') == baseline['dependency_reference'],
         'final executable/runtime/dependency pin record differs')
    need(after.get('harness_jar') == baseline.get('harness_jar')
         and after.get('jar_pins') == baseline.get('jar_pins')
         and after.get('directory_pins') == baseline.get('directory_pins'),
         'final dependency JAR or class-directory pins differ from baseline')
    for pin in [baseline['harness_jar'], *baseline['jar_pins']]:
        helpers.verify_pin(pin, 'final dependency jar')
    for folder, expected in baseline['directory_pins'].items():
        actual = {}
        base = Path(folder)
        for path in sorted(base.rglob('*.class')):
            actual[path.relative_to(base).as_posix()] = helpers.file_pin(path)
        need(actual == expected, f'final dependency class tree differs: {folder}')
    need(after.get('source_pins') == doc.get('source_pins'), 'final compare/guard/scanner/JDK source pins differ')
    for pin in doc['source_pins'].values():
        helpers.verify_pin(pin, 'final source/helper pin')
    expected_original_classes = [pin for profile in baseline['profiles'] for pin in profile['class_files']]
    need(doc.get('original_class_pins') == expected_original_classes,
         'matrix original class pin inventory differs from frozen baseline')
    for pin in expected_original_classes:
        helpers.verify_pin(pin, 'original baseline class input')
    for item in doc.get('source_inputs', []):
        helpers.verify_pin(item['input_pin'], 'source-extraction class/JAR input after matrix')
        copied = helpers.verify_pin(item['source_copy'], 'source copy after matrix')
        source = helpers.verify_pin(item['original_source'], 'original source after matrix')
        need(copied == source, 'final original/copy source bytes differ')
        if item.get('original_report'):
            report_bytes = helpers.verify_pin(item['original_report'], 'original Jarde report after matrix')
            need(json.loads(report_bytes).get('text', '').encode('utf-8') == source,
                 'final Jarde source/report bytes differ')
    return {'workspace_source_unchanged': True, 'baseline_and_oracles_unchanged': True,
            'target_absent': True, 'all_source_inputs_rechecked': len(doc['source_inputs']),
            'original_class_inputs_rechecked': len(expected_original_classes)}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('execution_json', type=Path)
    ap.add_argument('review_json', type=Path)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    execution_path = args.execution_json.resolve(strict=True)
    output = args.review_json.resolve()
    need(not output.exists(), f'refusing to overwrite reviewer output: {output}')
    root = args.root.resolve(strict=True)
    need(root == ROOT, f'unexpected workspace root {root}')
    need(execution_path.parent == Path('/private/tmp/jarde-testnestedloops5-rebuild-matrix-run-root-v1-20261018').resolve(),
         'matrix receipt is not from the pinned root-v1 output directory')
    out = execution_path.parent
    helpers_path = Path(__file__).with_name('classfile_helpers.py')
    helpers = load_helpers(helpers_path)
    raw = execution_path.read_bytes()
    doc = json.loads(raw)
    need(doc.get('schema') == 'cf11-nestedloops5-complete-source-rebuild-matrix-v1', 'unexpected matrix receipt schema')
    need(doc.get('status') == 'captured_pending_independent_review', 'matrix receipt is not terminal captured state')
    need(doc.get('finished_utc') and doc.get('error') is None, 'matrix receipt lacks successful terminal completion')
    baseline_path = BASELINE_DIR / 'execution.json'
    baseline_raw = baseline_path.read_bytes()
    baseline = json.loads(baseline_raw)
    need(baseline.get('status') == 'captured-pending-independent-review', 'pinned baseline receipt is not terminal')
    baseline_review_raw = BASELINE_REVIEW.read_bytes()
    baseline_review = json.loads(baseline_review_raw)
    need(baseline_review.get('status') == 'read_only_baseline_review_complete'
         and baseline_review.get('input', {}).get('sha256') == sha(baseline_raw),
         'root baseline review does not bind this exact baseline receipt')
    baseline_pin = helpers.file_pin(baseline_path)
    need(doc.get('baseline_receipt') == baseline_pin, 'matrix receipt does not bind exact baseline receipt')
    need(doc.get('product_revision') == baseline.get('product_revision'), 'product revision changed from baseline')
    source_summary = validate_source_inputs(doc, baseline, helpers)
    by_label = validate_commands(doc, out)
    expected_after_pins = sum(2 + (1 if item.get('original_report') else 0) for item in doc.get('source_inputs', []))
    need(doc.get('source_inputs_after') and len(doc['source_inputs_after']) == expected_after_pins,
         'matrix source after-pins are incomplete for the recorded source/report inputs')
    expected_after = []
    for item in doc['source_inputs']:
        for role in ('source_copy', 'original_source', 'original_report'):
            if item.get(role):
                expected_after.append({**{k:item[k] for k in ('kind','profile','form','evidence')}, 'role':role, 'pin':item[role]})
    need(doc['source_inputs_after'] == expected_after, 'source after-pin role/table mismatch')
    need((out / 'collector.py').read_bytes() == COLLECTOR.read_bytes(), 'collector copy differs from root-reviewed v2')
    matrix = validate_matrix_commands(doc, by_label, baseline, helpers, out)
    runtime = validate_runtime(doc, by_label, matrix, baseline, helpers, out)
    guards = validate_driver_and_guards(doc, by_label, baseline, matrix, helpers, out)
    final = validate_final_pins(doc, baseline_path, baseline, helpers, root)
    compile_labels = {label for label in by_label if label.startswith('compile-')}
    need(len(compile_labels) == 25, f'expected 24 source compiles plus 1 driver compile, found {len(compile_labels)}')
    expected_labels = compile_labels | {label for label in by_label if label.startswith(('runtime-core-', 'runtime-check-'))} | {'matrix-wrong-root-code-source-rejection'}
    need(set(by_label) == expected_labels and 'compile-independent-driver-javac8' in expected_labels,
         'command inventory contains unaccounted or missing operations')
    need(len(by_label) == len(doc['commands']), 'unaccounted command row')
    review = {
        'status': 'read_only_matrix_review_complete',
        'input': {'path': str(execution_path), 'bytes': len(raw), 'sha256': sha(raw)},
        'checker': {'path': str(Path(__file__).resolve()), 'bytes': Path(__file__).stat().st_size,
                    'sha256': sha(Path(__file__).read_bytes())},
        'baseline_review': {'path': str(BASELINE_REVIEW), 'bytes': len(baseline_review_raw),
                            'sha256': sha(baseline_review_raw)},
        'classfile_helper': {'path': str(helpers_path), 'bytes': helpers_path.stat().st_size,
                             'sha256': sha(helpers_path.read_bytes())},
        'command_raw': {'command_count': len(doc['commands']), 'raw_stream_count': 2 * len(doc['commands'])},
        'collector': {'path': str(out / 'collector.py'), 'bytes': (out / 'collector.py').stat().st_size,
                      'sha256': sha((out / 'collector.py').read_bytes()),
                      'matches_prepared_root_v2': (out / 'collector.py').read_bytes() == COLLECTOR.read_bytes()},
        'source_artifacts': source_summary,
        'compile': {'cells': matrix['compile_cell_count'], 'runtime_eligible': matrix['eligible_count'],
                    'failed_no_runtime': matrix['compile_failures'],
                    'all_no_runtime_outcomes': matrix['no_runtime_outcomes']},
        'runtime': runtime,
        'driver_and_negative_control': guards,
        'final_guards': final,
        'limitations': [
            'This reviews exact full-source compile/runtime evidence only; it does not validate Jarde source maps, API parity, or SSA.',
            'Compile failures and runtime failures/mismatches are retained as observed outcomes; the checker does not convert them into success.',
            'A JDK 8 major-55 check boundary is recorded as no check result, not as check success.',
            'Source extraction/API acceptance and full runtime semantics remain distinct evidence layers.',
        ],
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf-8') as stream:
        json.dump(review, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'status': review['status'], 'compile_cells': matrix['compile_cell_count'],
                      'eligible': matrix['eligible_count'], 'runtime_rows': runtime['runtime_row_count'],
                      'compile_failures': len(matrix['compile_failures']), 'review': str(output)}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
        raise SystemExit(f'TestNestedLoops5 rebuild matrix review failed: {error}')
