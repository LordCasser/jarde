# TestNestedLoops5 full-source rebuild matrix reviewer

`review_matrix.py` independently reviews the root-v2 matrix collector output. It accepts the terminal `execution.json` and a new review JSON path, refuses to overwrite an existing output, and is pinned to the root-v1 matrix output directory and the separately reviewed v3 baseline receipt.

It verifies all 24 source/compiler cells and exact source bytes from the baseline: eight Jarde default/all texts plus four JADX texts, each compiled with both javac 8 source/target 8 and JDK 23 `--release 8`. Each cell’s actual command, argv, raw stdout/stderr bytes and hashes are checked. Compiler errors remain compile-failed/no-runtime outcomes; a successful compile without a valid Java 8 target is also retained as no-runtime. The checker does not require every source to compile.

For each eligible output, it independently parses the target class bytes, requires major 52, the exact `<init>()V`, `testFor()I`, and `check()V` inventory with Code, and rechecks each method’s physical instruction BCIs against the receipt. It checks emitted class-tree pins, strict core/check classpaths, `-Xverify:all`, CodeSource guard execution, runtime raw streams, and byte-for-byte comparison against the original core/check JVM oracle. Runtime failures, mismatches, and the JDK 8 major-55 check boundary are reported as observed outcomes rather than converted to passes. It also checks the wrong-root rejection, driver/source inputs, baseline review binding, dependency pins, source closure before/after, and target absence.

This matrix covers full-source compilation and runtime only. It does not validate Jarde API/source-map acceptance or private SSA. A completed capture is not itself product acceptance.

Preparation status: both Python files passed `ast.parse` using `python3 -B`. The reviewer has not been run against the matrix receipt, which may still be in progress. No Git, network, Cargo, JDK, Jarde CLI, or JADX command was run for this preparation.

Root invocation after inspecting this checker and after the collector reaches terminal status:

```sh
python3 -B /private/tmp/jarde-testnestedloops5-rebuild-matrix-review-prep-root-v1-20261018/review_matrix.py \
  /private/tmp/jarde-testnestedloops5-rebuild-matrix-run-root-v1-20261018/execution.json \
  /private/tmp/jarde-testnestedloops5-rebuild-matrix-review-root-v1-20261018/root-review.json
```
