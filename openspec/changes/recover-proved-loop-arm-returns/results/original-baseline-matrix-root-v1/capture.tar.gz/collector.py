#!/usr/bin/env python3
"""Prepared, unexecuted full-source rebuild/runtime matrix for NL5 receipts."""
from __future__ import annotations
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASELINE = Path('/private/tmp/jarde-testnestedloops5-baseline-run-root-v3-20261018')
COMPARE_REL = Path('openspec/changes/recover-exception-only-finally-completion/tools/compare.py')
COMPARE_SHA256 = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
EXPECTED_SCHEMA = 'cf11-original-testnestedloops5-baseline-v1'
EXPECTED_STATUS = 'captured-pending-independent-review'
TARGET_REL = Path('jadx/tests/integration/loops/TestNestedLoops5$TestCls.class')
OWNER_REL = Path('jadx/tests/integration/loops/TestNestedLoops5.class')
EXPECTED_METHODS = {('<init>', '()V'), ('testFor', '()I'), ('check', '()V')}
JDK_LEGS = ('javac8', 'javac23')
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def file_tree_pin(root: Path, compare) -> dict:
    return {p.relative_to(root).as_posix(): compare.pin(p)
            for p in sorted(root.rglob('*')) if p.is_file()}


def directory_pin(root: Path, compare) -> dict:
    return {p.relative_to(root).as_posix(): compare.pin(p)
            for p in sorted(root.rglob('*.class')) if p.is_file()}


def method_set(facts: dict) -> set[tuple[str, str]]:
    return {(row['name'], row['descriptor']) for row in facts['methods']}


def expected_source_name(kind: str, form: str) -> str:
    if form in ('child', 'bundle-child'):
        return 'TestNestedLoops5$TestCls.java'
    if form == 'bundle' and kind == 'jadx':
        return 'TestNestedLoops5.java'
    raise RuntimeError(f'unexpected source form: {kind}/{form}')


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=ROOT)
    ap.add_argument('--baseline', type=Path, default=BASELINE)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    root = args.root.resolve(strict=True)
    baseline = args.baseline.resolve(strict=True)
    out = args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing existing output directory: {out}')
    if root != ROOT.resolve():
        raise SystemExit(f'root differs from pinned workspace: {root}')
    if baseline != BASELINE.resolve():
        raise SystemExit(f'baseline differs from pinned NL5 receipt path: {baseline}')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('repository target exists before source-rebuild matrix')
    if shutil.disk_usage(root).free < 5 * 1024**3:
        raise SystemExit('root free-space guard below 5 GiB')

    compare_path = root / COMPARE_REL
    if hashlib.sha256(compare_path.read_bytes()).hexdigest() != COMPARE_SHA256:
        raise SystemExit('compare.py pin mismatch')
    compare = load_module(compare_path, 'nl5_rebuild_compare')
    guard_path = root / compare.GUARD_REL
    scanner_path = root / compare.SCANNER_REL
    if compare.sha(guard_path) != compare.GUARD_SHA256 or compare.sha(scanner_path) != compare.SCANNER_SHA256:
        raise SystemExit('run guard/scanner source pin mismatch')
    guard = load_module(guard_path, 'nl5_rebuild_guard')
    scanner = load_module(scanner_path, 'nl5_rebuild_scanner')
    jdk_manifest_path = root / 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
    jdks, jdk_record = compare.configured_jdks(
        jdk_manifest_path,
        'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec')
    helper_pins = {'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path),
                   'scanner': compare.pin(scanner_path), 'jdk_manifest': compare.pin(jdk_manifest_path)}

    baseline_path = baseline / 'execution.json'
    baseline_doc = json.loads(baseline_path.read_text(encoding='utf-8'))
    if baseline_doc.get('schema') != EXPECTED_SCHEMA or baseline_doc.get('status') != EXPECTED_STATUS:
        raise SystemExit(f'unexpected baseline state: {baseline_doc.get("schema")!r}/{baseline_doc.get("status")!r}')
    if baseline_doc.get('product_revision') != '755fd2c84ecbe204d03f0ff608d3a711a1bea494':
        raise SystemExit('baseline does not identify frozen product 755fd2c84')
    if baseline_doc.get('target_absent') is not True or baseline_doc.get('source_unchanged') is not True:
        raise SystemExit('baseline does not confirm source unchanged and target absent')
    if len(baseline_doc.get('commands', [])) != 28:
        raise SystemExit('NL5 baseline must contain its 28 original/source/oracle commands')
    commands_by_id = {row['index']: row for row in baseline_doc['commands']}
    if len(commands_by_id) != 28:
        raise SystemExit('duplicate command ids in baseline')
    for row in commands_by_id.values():
        if row.get('guard_stop') is not None:
            raise SystemExit(f'baseline command {row["index"]} has a guard stop')
        compare.command_artifact(row, 'stdout')
        compare.command_artifact(row, 'stderr')

    baseline_pin = compare.pin(baseline_path)
    source_pin = baseline_doc['source']
    source_copy_pin = baseline_doc['source_copy']
    driver_pin = baseline_doc['driver']
    runtime_bound_pin = baseline_doc['runtime_bound']
    source_path = Path(source_pin['path'])
    source_copy_path = Path(source_copy_pin['path'])
    driver_source_path = Path(driver_pin['path'])
    runtime_bound = Path(runtime_bound_pin['path'])
    if compare.pin(source_path) != source_pin or compare.pin(source_copy_path) != source_copy_pin:
        raise SystemExit('original source or frozen copy differs from baseline pin')
    if compare.pin(driver_source_path) != driver_pin or compare.pin(runtime_bound) != runtime_bound_pin:
        raise SystemExit('baseline reflection driver or timeout wrapper changed')
    oracle_pin = baseline_doc['original_oracle']
    oracle_path = Path(oracle_pin['path'])
    check_oracle_pin = baseline_doc['original_check_oracle']
    check_oracle_path = Path(check_oracle_pin['path'])
    if compare.pin(oracle_path) != oracle_pin or compare.pin(check_oracle_path) != check_oracle_pin:
        raise SystemExit('baseline runtime oracle pins changed')
    core_oracle = oracle_path.read_bytes()
    check_oracle = check_oracle_path.read_bytes()
    if len(core_oracle.splitlines()) != 3 or len(check_oracle.splitlines()) != 1:
        raise SystemExit('NL5 core/check oracle row counts differ from the v3 driver contract')

    original_core_rows = baseline_doc.get('original_runtime', [])
    original_check_rows = baseline_doc.get('original_check_runtime', [])
    if len(original_core_rows) != 4 or len(original_check_rows) != 4:
        raise SystemExit('baseline must contain four core and four check observations')
    expected_runtime_keys = {(profile, runtime) for profile in ('debug', 'no-debug') for runtime in JDK_LEGS}
    if {(row.get('profile'), row.get('runtime')) for row in original_core_rows} != expected_runtime_keys:
        raise SystemExit('baseline core runtime rows do not cover both profiles and both JVMs exactly')
    if {(row.get('profile'), row.get('runtime')) for row in original_check_rows} != expected_runtime_keys:
        raise SystemExit('baseline check runtime rows do not cover both profiles and both JVMs exactly')
    for row in original_core_rows:
        cmd = commands_by_id.get(row.get('command'))
        if cmd is None or cmd.get('exit_code') != 0 or row.get('exit_code') != 0:
            raise SystemExit('an original core JVM observation failed')
        if compare.command_artifact(cmd, 'stdout') != core_oracle:
            raise SystemExit('original core JVM observations disagree with frozen core oracle')
    check23_count = 0
    check8_boundary_count = 0
    for row in original_check_rows:
        cmd = commands_by_id.get(row.get('command'))
        if cmd is None:
            raise SystemExit('original check row references an unknown command')
        if row.get('runtime') == 'javac23':
            if row.get('exit_code') != 0 or cmd.get('exit_code') != 0:
                raise SystemExit('an original JDK23 check observation failed')
            if compare.command_artifact(cmd, 'stdout') != check_oracle:
                raise SystemExit('original JDK23 check disagrees with its actual check oracle')
            check23_count += 1
        elif row.get('runtime') == 'javac8':
            stderr = compare.command_artifact(cmd, 'stderr')
            if row.get('status') != 'harness-major55-boundary-no-check-result' or cmd.get('exit_code') == 0:
                raise SystemExit('original JDK8 check row did not retain the observed harness boundary')
            if b'55.0' not in stderr and b'version 55' not in stderr:
                raise SystemExit('original JDK8 check stderr does not show major 55')
            check8_boundary_count += 1
        else:
            raise SystemExit(f'unexpected check runtime leg: {row.get("runtime")!r}')
    if check23_count != 2 or check8_boundary_count != 2:
        raise SystemExit('original check runtime legs are not 2 JDK23 plus 2 JDK8 boundary rows')

    wrong_root = baseline_doc.get('wrong_root_control') or {}
    wrong_root_cmd = commands_by_id.get(wrong_root.get('command'))
    if wrong_root_cmd is None or wrong_root_cmd.get('exit_code') == 0:
        raise SystemExit('baseline wrong-root control did not fail')
    if b'target loaded from' not in compare.command_artifact(wrong_root_cmd, 'stderr'):
        raise SystemExit('baseline wrong-root control did not report the CodeSource mismatch')

    original_profiles = baseline_doc.get('profiles', [])
    if len(original_profiles) != 2 or {row['profile'] for row in original_profiles} != {'debug', 'no-debug'}:
        raise SystemExit('baseline must contain complete debug and no-debug original class trees')
    original_class_pins = []
    for profile in original_profiles:
        target_facts = profile['target']
        if target_facts.get('major') != 52 or method_set(target_facts) != EXPECTED_METHODS:
            raise SystemExit(f'original {profile["profile"]} class lacks exact three-method Java 8 target')
        if any(method.get('code') is None for method in target_facts['methods']):
            raise SystemExit('original target has a method without a Code attribute')
        for pin in profile.get('class_files', []):
            if compare.pin(Path(pin['path'])) != pin:
                raise SystemExit(f'original class input changed: {pin["path"]}')
            original_class_pins.append(pin)

    dependency_ref = baseline_doc['dependency_reference']
    dependency_ref_path = Path(dependency_ref['path'])
    if compare.pin(dependency_ref_path) != dependency_ref:
        raise SystemExit('pinned dependency reference receipt changed')
    classpath_compile = list(baseline_doc['classpath'])
    for pin in [baseline_doc['harness_jar'], *baseline_doc['jar_pins']]:
        if compare.pin(Path(pin['path'])) != pin:
            raise SystemExit(f'classpath dependency pin changed: {pin["path"]}')
    directory_pins = baseline_doc['directory_pins']
    for folder, expected in directory_pins.items():
        if directory_pin(Path(folder), compare) != expected:
            raise SystemExit(f'JADX build classpath directory pin changed: {folder}')
    harness_jar = Path(baseline_doc['harness_jar']['path'])
    target_resource = TARGET_REL.as_posix()
    owner_resource = OWNER_REL.as_posix()
    import zipfile
    with zipfile.ZipFile(harness_jar) as jar:
        if target_resource in jar.namelist() or owner_resource in jar.namelist():
            raise SystemExit('pinned harness jar contains NL5 target/owner class')
    for folder in directory_pins:
        base = Path(folder)
        if (base / target_resource).exists() or (base / owner_resource).exists():
            raise SystemExit(f'pinned JADX classpath contains NL5 target/owner: {base}')

    cli_pin = baseline_doc['cli']
    jadx_pin = baseline_doc['jadx']
    jadx_jar_pin = baseline_doc['jadx_jar']
    for label, pin in (('CLI', cli_pin), ('JADX executable', jadx_pin), ('JADX jar', jadx_jar_pin)):
        if compare.pin(Path(pin['path'])) != pin:
            raise SystemExit(f'{label} differs from exact baseline pin')
    source_before = compare.source_closure(root)
    internal_wrapper = baseline / runtime_bound.name
    if not internal_wrapper.is_file() or compare.pin(internal_wrapper)['sha256'] != runtime_bound_pin['sha256']:
        raise SystemExit('baseline internal timeout-wrapper copy is missing or changed')

    # The baseline collector emits these exact eight Jarde and four JADX full-source cells.
    source_inputs = []
    jarde_cells = baseline_doc.get('jarde_cells', [])
    jadx_cells = baseline_doc.get('jadx_cells', [])
    if len(jarde_cells) != 8 or len(jadx_cells) != 4:
        raise SystemExit('baseline presentation matrix is not 8 Jarde + 4 JADX cells')
    expected_jarde_keys = {(profile, form, evidence)
                           for profile in ('debug', 'no-debug')
                           for form in ('child', 'bundle-child')
                           for evidence in ('default', 'all')}
    actual_jarde_keys = {(row.get('profile'), row.get('input_form'), row.get('evidence')) for row in jarde_cells}
    if actual_jarde_keys != expected_jarde_keys:
        raise SystemExit('Jarde sources are not the complete independent profile/form/evidence grid')
    expected_jadx_keys = {(profile, form) for profile in ('debug', 'no-debug') for form in ('child', 'bundle')}
    actual_jadx_keys = {(row.get('profile'), row.get('input_form')) for row in jadx_cells}
    if actual_jadx_keys != expected_jadx_keys:
        raise SystemExit('JADX sources are not the complete independent profile/form grid')
    for row in jarde_cells:
        if row.get('exit_code') != 0 or not row.get('whole_source') or not row.get('report'):
            raise SystemExit(f'incomplete Jarde source cell: {row.get("profile")}/{row.get("input_form")}/{row.get("evidence")}')
        source_pin_row = row['whole_source']
        source_file = Path(source_pin_row['path'])
        report_pin = row['report']
        report_file = Path(report_pin['path'])
        if compare.pin(source_file) != source_pin_row or compare.pin(report_file) != report_pin:
            raise SystemExit('Jarde source/report pin changed')
        document = json.loads(report_file.read_text(encoding='utf-8'))
        if document.get('text', '').encode('utf-8') != source_file.read_bytes():
            raise SystemExit('saved Jarde source does not byte-match its exact report text')
        input_pin = row['input']
        if compare.pin(Path(input_pin['path'])) != input_pin:
            raise SystemExit('Jarde source-extraction input class/JAR changed')
        source_inputs.append({'kind': 'jarde', 'profile': row['profile'], 'form': row['input_form'],
                              'evidence': row['evidence'], 'original_source': source_pin_row,
                              'original_report': report_pin, 'input_pin': input_pin, 'source_path': source_file})
    for row in jadx_cells:
        if row.get('exit_code') != 0 or len(row.get('sources') or []) != 1:
            raise SystemExit(f'incomplete JADX source cell: {row.get("profile")}/{row.get("input_form")}')
        source_pin_row = row['sources'][0]
        source_file = Path(source_pin_row['path'])
        if compare.pin(source_file) != source_pin_row:
            raise SystemExit('JADX source pin changed')
        extraction_command = commands_by_id.get(row.get('command'))
        if extraction_command is None or not extraction_command.get('argv'):
            raise SystemExit('JADX source cell lacks its original extraction command')
        extraction_input = Path(extraction_command['argv'][-1])
        input_pin = compare.pin(extraction_input)
        if compare.pin(Path(input_pin['path'])) != input_pin:
            raise SystemExit('JADX extraction input class/JAR changed')
        source_inputs.append({'kind': 'jadx', 'profile': row['profile'], 'form': row['input_form'],
                              'evidence': 'source', 'original_source': source_pin_row,
                              'original_report': None, 'input_pin': input_pin, 'source_path': source_file})
    if len(source_inputs) != 12:
        raise SystemExit('expected 12 independent full-source compilation inputs')

    out.mkdir(parents=True)
    (out / 'raw').mkdir()
    guard.ROOT = root
    guard.OUT = out / 'raw'
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, data: None

    for item in source_inputs:
        filename = expected_source_name(item['kind'], item['form'])
        copy_path = out / 'input-sources' / item['kind'] / item['profile'] / item['form'] / str(item['evidence']) / 'jadx/tests/integration/loops' / filename
        copy_path.parent.mkdir(parents=True, exist_ok=True)
        copy_path.write_bytes(item['source_path'].read_bytes())
        item['source_copy'] = compare.pin(copy_path)
        item['source_filename'] = filename
        item['compile_source'] = copy_path

    driver_copy = out / 'driver-source' / 'TestNestedLoops5Driver.java'
    driver_copy.parent.mkdir(parents=True)
    shutil.copyfile(driver_source_path, driver_copy)
    if compare.pin(driver_copy)['sha256'] != driver_pin['sha256']:
        raise SystemExit('matrix driver copy differs from baseline exact driver source')
    driver_classes = out / 'driver-classes'
    driver_classes.mkdir()
    driver_empty = out / 'empty-sourcepath-driver'
    driver_empty.mkdir()
    oracle_sha = hashlib.sha256(core_oracle).hexdigest()
    check_oracle_sha = hashlib.sha256(check_oracle).hexdigest()
    rows = []
    report = {
        'schema': 'cf11-nestedloops5-complete-source-rebuild-matrix-v1',
        'status': 'running', 'root': str(root), 'baseline_receipt': baseline_pin,
        'baseline_original_oracle': oracle_pin, 'baseline_check_oracle': check_oracle_pin,
        'baseline_oracle_sha256': oracle_sha, 'baseline_check_oracle_sha256': check_oracle_sha,
        'product_revision': baseline_doc['product_revision'], 'cli': cli_pin, 'jadx': jadx_pin,
        'jadx_jar': jadx_jar_pin, 'original_source': source_pin, 'driver_source': driver_pin,
        'runtime_timeout_wrapper': runtime_bound_pin, 'jdk_manifest': jdk_record,
        'compare_helper': helper_pins['compare'], 'guard': helper_pins['guard'],
        'scanner': helper_pins['scanner'], 'source_pins': helper_pins,
        'classpath_full_bundle': classpath_compile,
        'runtime_core_classpath': 'rebuilt-target-classes + independent-driver-classes only',
        'runtime_check_classpath': 'rebuilt-target-classes + independent-driver-classes + pinned original check-helper classpath',
        'source_before': source_before,
        'original_class_pins': original_class_pins,
        'source_inputs': [{key: item.get(key) for key in ('kind','profile','form','evidence','input_pin','original_source','original_report','source_copy','source_filename')}
                          for item in source_inputs],
        'source_inputs_after': None,
        'commands': rows, 'driver_compile': None, 'compilation_cells': [],
        'runtime_rows': [], 'wrong_root_controls': [], 'notes': [
            'All eight original Jarde source texts and four original JADX source files are copied byte-for-byte before compilation; default/all are compiled independently.',
            'Each copied source is attempted with both javac8 source/target 8 and JDK23 --release 8. A compile failure is retained as compile_failed_no_runtime; no runtime is fabricated.',
            'Successful compilations require a Java 8 major-52 nested target with exactly <init>()V, testFor()I, and check()V before semantic execution.',
            'Core mode runs the testFor sequence with a minimal target+driver classpath and byte-compares it with the three-row observed original core oracle on both JVMs.',
            'Check mode runs the original check method against the exact pinned helper dependency closure; JDK8 major-55 errors are retained as runtime outcomes, while JDK23 output is compared with the actual one-row check oracle.',
            'Full non-target/source-map comparisons and SSA capture are separate acceptance work; this matrix makes no such claim.'
        ]
    }

    def save():
        compare.write_json(out / 'execution.json', report)

    def run_cmd(label: str, argv: list, leg: str) -> dict:
        if (root / 'target').exists():
            raise RuntimeError('repository target appeared before external command')
        env = {key: value for key, value in os.environ.items() if key not in ENV_STRIP}
        env = compare.clean_env(env, jdks[leg])
        env.update(guard.ENV_VALUES)
        env.pop('RUST_MIN_STACK', None)
        row = guard.run_command(len(rows) + 1, [str(arg) for arg in argv], env)
        row['label'] = label
        row['tool_leg'] = leg
        rows.append(row)
        save()
        if row.get('guard_stop') is not None:
            raise RuntimeError(f'root guard stopped {label}: {row["guard_stop"]}')
        return row

    def run_mode(label: str, classes: Path, runtime: str, mode: str) -> dict:
        target_tree_before = file_tree_pin(classes, compare)
        driver_tree_before = file_tree_pin(driver_classes, compare)
        if driver_tree_before != driver_tree:
            raise RuntimeError('independent driver class tree changed before runtime')
        if mode == 'core':
            cp = [str(classes), str(driver_classes)]
        else:
            cp = [str(classes), str(driver_classes), *classpath_compile]
        row = run_cmd(label, [sys.executable, '-B', str(runtime_bound), '30',
                              jdks[runtime]['tools']['java'], '-Xverify:all', '-cp', os.pathsep.join(cp),
                              'TestNestedLoops5Driver', classes, mode], runtime)
        target_tree_after = file_tree_pin(classes, compare)
        driver_tree_after = file_tree_pin(driver_classes, compare)
        if target_tree_after != target_tree_before or driver_tree_after != driver_tree:
            raise RuntimeError(f'runtime modified input class tree: {label}')
        row['matrix_classpath'] = cp
        row['expected_target_root'] = str(classes)
        row['target_class_tree_before'] = target_tree_before
        row['target_class_tree_after'] = target_tree_after
        row['driver_class_tree_before'] = driver_tree_before
        row['driver_class_tree_after'] = driver_tree_after
        return row

    wrong_root_done = False

    try:
        save()
        driver_compile = run_cmd('compile-independent-driver-javac8', [
            jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g:none',
            '-Xlint:-options', '-encoding', 'UTF-8', '-proc:none', '-classpath', str(driver_empty),
            '-sourcepath', str(driver_empty), '-d', driver_classes, driver_copy
        ], 'javac8')
        report['driver_compile'] = {'command': driver_compile['index'], 'exit_code': driver_compile['exit_code'],
                                    'source': compare.pin(driver_copy),
                                    'classes': [compare.pin(path) for path in sorted(driver_classes.rglob('*.class'))]}
        if driver_compile['exit_code'] != 0:
            raise RuntimeError('independent reflection driver failed to compile')
        driver_tree = file_tree_pin(driver_classes, compare)
        report['driver_compile']['classes_tree'] = driver_tree
        save()

        compilation_cells = []
        for item in source_inputs:
            compile_cp = os.pathsep.join(str(path) for path in classpath_compile)
            for compiler in JDK_LEGS:
                classes = out / 'compiled' / item['kind'] / item['profile'] / item['form'] / str(item['evidence']) / compiler / 'classes'
                classes.mkdir(parents=True)
                empty = classes.parent / 'empty-sourcepath'
                empty.mkdir()
                options = (['-source', '8', '-target', '8', '-g:none', '-Xlint:-options', '-proc:none']
                           if compiler == 'javac8' else ['--release', '8', '-g:none', '-proc:none'])
                label = f'compile-{item["kind"]}-{item["profile"]}-{item["form"]}-{item["evidence"]}-{compiler}'
                compiled = run_cmd(label, [jdks[compiler]['tools']['javac'], *options, '-encoding', 'UTF-8',
                                           '-classpath', compile_cp, '-sourcepath', empty, '-d', classes,
                                           item['compile_source']], compiler)
                target = classes / TARGET_REL
                cell = {'kind': item['kind'], 'profile': item['profile'], 'form': item['form'],
                        'evidence': item['evidence'], 'compiler': compiler,
                        'source': item['source_copy'], 'original_source': item['original_source'],
                        'original_report': item['original_report'], 'source_filename': item['source_filename'],
                        'compile_classpath': classpath_compile, 'compile_command': compiled['index'],
                        'compile_exit_code': compiled['exit_code'],
                        'status': 'compile_failed_no_runtime' if compiled['exit_code'] != 0 else 'compile_succeeded',
                        'target_class_expected': str(target), 'target_class': None, 'target_facts': None,
                        'owner_class': None, 'runtime': []}
                if compiled['exit_code'] == 0:
                    if not target.is_file():
                        cell['status'] = 'compile_succeeded_target_missing_no_runtime'
                    else:
                        facts = compare.parse_class(target)
                        cell['target_class'] = compare.pin(target)
                        cell['target_facts'] = facts
                        cell['target_classes_root'] = str(classes)
                        cell['target_classes_tree'] = file_tree_pin(classes, compare)
                        cell['declared_methods_match_expected'] = facts['class_name'] == TARGET_REL.as_posix()[:-6] and method_set(facts) == EXPECTED_METHODS
                        cell['all_methods_have_code'] = all(row.get('code') is not None for row in facts['methods'])
                        cell['classfile_major_is_java8'] = facts['major'] == 52
                        owner = classes / OWNER_REL
                        cell['owner_class'] = compare.pin(owner) if owner.is_file() else None
                        if (cell['declared_methods_match_expected'] and cell['all_methods_have_code']
                                and cell['classfile_major_is_java8']):
                            cell['status'] = 'compiled_target_java8_three_methods'
                            if not wrong_root_done:
                                wrong = out / 'empty-wrong-root'
                                wrong.mkdir()
                                wrong_run = run_cmd('matrix-wrong-root-code-source-rejection', [
                                    sys.executable, '-B', str(runtime_bound), '30', jdks['javac23']['tools']['java'],
                                    '-Xverify:all', '-cp', os.pathsep.join([str(classes), str(driver_classes)]),
                                    'TestNestedLoops5Driver', wrong, 'core'
                                ], 'javac23')
                                wrong_stderr = compare.command_artifact(wrong_run, 'stderr')
                                if wrong_run['exit_code'] == 0 or b'target loaded from' not in wrong_stderr:
                                    raise RuntimeError('matrix wrong-root CodeSource control did not reject')
                                report['wrong_root_controls'].append({'command': wrong_run['index'],
                                    'exit_code': wrong_run['exit_code'], 'expected_root': str(wrong),
                                    'stderr_sha256': hashlib.sha256(wrong_stderr).hexdigest()})
                                wrong_root_done = True
                            for runtime in JDK_LEGS:
                                core_run = run_mode(f'runtime-core-{item["kind"]}-{item["profile"]}-{item["form"]}-{item["evidence"]}-{compiler}-on-{runtime}', classes, runtime, 'core')
                                core_bytes = compare.command_artifact(core_run, 'stdout')
                                core_equal = core_run['exit_code'] == 0 and core_bytes == core_oracle
                                cell['runtime'].append({'mode': 'core', 'runtime': runtime,
                                    'command': core_run['index'], 'exit_code': core_run['exit_code'],
                                    'stdout_sha256': hashlib.sha256(core_bytes).hexdigest(),
                                    'oracle_equal_byte_for_byte': core_equal,
                                    'status': 'matches_original_core_oracle' if core_equal else ('runtime_failed' if core_run['exit_code'] else 'core_oracle_mismatch'),
                                    'classpath': core_run['matrix_classpath']})
                                report['runtime_rows'].append({**{key: cell[key] for key in ('kind','profile','form','evidence','compiler')}, **cell['runtime'][-1]})
                                save()
                            for runtime in JDK_LEGS:
                                check_run = run_mode(f'runtime-check-{item["kind"]}-{item["profile"]}-{item["form"]}-{item["evidence"]}-{compiler}-on-{runtime}', classes, runtime, 'check')
                                check_bytes = compare.command_artifact(check_run, 'stdout')
                                check_stderr = compare.command_artifact(check_run, 'stderr')
                                if check_run['exit_code'] == 0:
                                    check_status = ('matches_original_check_oracle' if check_bytes == check_oracle
                                                    else 'check_oracle_mismatch')
                                elif check_run['exit_code'] != 0 and (b'55.0' in check_stderr or b'version 55' in check_stderr):
                                    check_status = 'observed_harness_major55_boundary_no_check_result'
                                else:
                                    check_status = 'runtime_failed'
                                runtime_cell = {'mode': 'check', 'runtime': runtime,
                                    'command': check_run['index'], 'exit_code': check_run['exit_code'],
                                    'stdout_sha256': hashlib.sha256(check_bytes).hexdigest(),
                                    'oracle_equal_byte_for_byte': check_run['exit_code'] == 0 and check_bytes == check_oracle,
                                    'status': check_status, 'classpath': check_run['matrix_classpath'],
                                    'stderr_sha256': hashlib.sha256(check_stderr).hexdigest()}
                                cell['runtime'].append(runtime_cell)
                                report['runtime_rows'].append({**{key: cell[key] for key in ('kind','profile','form','evidence','compiler')}, **runtime_cell})
                                save()
                        else:
                            cell['status'] = 'compiled_target_identity_or_major_mismatch_no_runtime'
                compilation_cells.append(cell)
                report['compilation_cells'] = compilation_cells
                save()

        # Recheck every copied source and report byte-for-byte after all compilers/runtimes.
        after_sources = []
        for item in source_inputs:
            for role, pin in (('source_copy', item['source_copy']), ('original_source', item['original_source']),
                              ('original_report', item['original_report'])):
                if pin:
                    actual = compare.pin(Path(pin['path']))
                    if actual != pin:
                        raise RuntimeError(f'{role} input changed: {pin["path"]}')
                    after_sources.append({'kind': item['kind'], 'profile': item['profile'], 'form': item['form'],
                                          'evidence': item['evidence'], 'role': role, 'pin': actual})
        report['source_inputs_after'] = after_sources
        for pin in original_class_pins:
            if compare.pin(Path(pin['path'])) != pin:
                raise RuntimeError(f'original class input changed during matrix: {pin["path"]}')
        for item in source_inputs:
            if item.get('input_pin') and compare.pin(Path(item['input_pin']['path'])) != item['input_pin']:
                raise RuntimeError(f'baseline class/JAR extraction input changed: {item["input_pin"]["path"]}')
        report['source_after'] = compare.source_closure(root)
        report['driver_copy_after'] = compare.pin(driver_copy)
        report['driver_classes_tree_after'] = file_tree_pin(driver_classes, compare)
        report['baseline_receipt_after'] = compare.pin(baseline_path)
        report['oracle_after'] = compare.pin(oracle_path)
        report['check_oracle_after'] = compare.pin(check_oracle_path)
        report['inputs_after'] = {'cli': compare.pin(Path(cli_pin['path'])),
                                  'jadx': compare.pin(Path(jadx_pin['path'])),
                                  'jadx_jar': compare.pin(Path(jadx_jar_pin['path'])),
                                  'harness_jar': compare.pin(harness_jar),
                                  'runtime_wrapper': compare.pin(runtime_bound),
                                  'dependency_reference': compare.pin(dependency_ref_path),
                                  'source_pins': {'compare': compare.pin(compare_path),
                                                  'guard': compare.pin(guard_path),
                                                  'scanner': compare.pin(scanner_path),
                                                  'jdk_manifest': compare.pin(jdk_manifest_path)},
                                  'jar_pins': [compare.pin(Path(pin['path'])) for pin in baseline_doc['jar_pins']],
                                  'directory_pins': {folder: directory_pin(Path(folder), compare) for folder in directory_pins}}
        if report['source_after'] != source_before:
            raise RuntimeError('shared workspace source closure changed during matrix')
        if report['driver_copy_after']['sha256'] != driver_pin['sha256'] or report['driver_copy_after']['bytes'] != driver_pin['bytes'] or report['driver_classes_tree_after'] != driver_tree:
            raise RuntimeError('driver source/classes changed during matrix')
        if report['baseline_receipt_after'] != baseline_pin or report['oracle_after'] != oracle_pin or report['check_oracle_after'] != check_oracle_pin:
            raise RuntimeError('baseline/oracle changed during matrix')
        if report['inputs_after']['cli'] != cli_pin or report['inputs_after']['jadx'] != jadx_pin or report['inputs_after']['jadx_jar'] != jadx_jar_pin:
            raise RuntimeError('frozen product/JADX input changed during matrix')
        if report['inputs_after']['runtime_wrapper'] != runtime_bound_pin or report['inputs_after']['dependency_reference'] != dependency_ref:
            raise RuntimeError('runtime wrapper or dependency reference changed during matrix')
        if report['inputs_after']['source_pins'] != helper_pins:
            raise RuntimeError('collector helper/JDK manifest pin changed during matrix')
        for pin in [baseline_doc['harness_jar'], *baseline_doc['jar_pins']]:
            if compare.pin(Path(pin['path'])) != pin:
                raise RuntimeError(f'dependency changed during matrix: {pin["path"]}')
        for folder, expected in directory_pins.items():
            if directory_pin(Path(folder), compare) != expected:
                raise RuntimeError(f'JADX build classpath tree changed during matrix: {folder}')
        if (root / 'target').exists():
            raise RuntimeError('workspace target appeared by end of matrix')
        report['source_unchanged'] = True
        report['baseline_unchanged'] = True
        report['target_absent'] = True
        report['status'] = 'captured_pending_independent_review'
    except BaseException as exc:
        report['status'] = 'failed'
        report['error'] = f'{type(exc).__name__}: {exc}'
        raise
    finally:
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out / 'execution.json', report)
        shutil.copyfile(__file__, out / 'collector.py')
    print(json.dumps({'status': report['status'], 'compile_cells': len(report['compilation_cells']),
                      'runtime_rows': len(report['runtime_rows']), 'output': str(out)}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
