import pathlib,subprocess,json,hashlib,re,shutil
ROOT=pathlib.Path('/Users/lordcasser/workspace/projects/jarde');out=pathlib.Path('/private/tmp/jarde-loop-arm-closing-strict-root-v1-20261018');out.mkdir()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
rows=[]
for i,argv in enumerate([['openspec','--version'],['openspec','instructions','apply','--change','recover-proved-loop-arm-returns','--json'],['openspec','validate','--all','--strict','--no-interactive']],1):
 so=out/f'{i}.stdout.raw';se=out/f'{i}.stderr.raw'
 with so.open('xb') as a,se.open('xb') as b:p=subprocess.run(argv,cwd=ROOT,stdout=a,stderr=b)
 rows.append({'argv':argv,'exit_code':p.returncode,'stdout':pin(so),'stderr':pin(se)});assert p.returncode==0,argv
version=(out/'1.stdout.raw').read_text().strip();assert version=='1.11.0'
apply=json.loads((out/'2.stdout.raw').read_text());assert apply['state']=='all_done' and apply['progress']=={'total':8,'complete':8,'remaining':0},apply.get('progress')
m=re.search(r'Totals: (\d+) passed, (\d+) failed \((\d+) items\)',(out/'3.stdout.raw').read_text());assert m and m.groups()==('369','0','369')
assert not (ROOT/'target').exists()
review={'status':'accepted','openspec_version':version,'progress':apply['progress'],'state':apply['state'],'strict_items_passed':int(m[1]),'strict_items_failed':int(m[2]),'commands':rows,'raw_streams':6,'target_absent':True,'task_file':pin(ROOT/'openspec/changes/recover-proved-loop-arm-returns/tasks.md'),'product_sha':'e70b350ee33307294a3d383ffdea5874caf9f5b8','scope':'Closing OpenSpec 8/8; product CI and native replays are separately accepted; final actual Git head audit follows documentation push.'}
(out/'root-review.json').write_text(json.dumps(review,indent=2)+'\n');shutil.copy2(__file__,out/'collector.py');print(json.dumps({k:review[k] for k in ['status','state','progress','strict_items_passed','strict_items_failed','target_absent']}))
