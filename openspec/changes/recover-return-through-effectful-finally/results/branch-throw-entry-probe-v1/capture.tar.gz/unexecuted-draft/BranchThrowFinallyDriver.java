import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public final class BranchThrowFinallyDriver {
    private static final class Marker extends RuntimeException {
        Marker() { super("cleanup"); }
    }

    private static final class Recording extends PrintStream {
        int calls;
        String value;
        final RuntimeException failure;
        Recording(RuntimeException failure) {
            super(new ByteArrayOutputStream());
            this.failure = failure;
        }
        @Override public void println(String value) {
            calls++;
            this.value = value;
            if (failure != null) throw failure;
        }
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static void run(int n, boolean cleanupFails) {
        PrintStream original = System.out;
        Marker marker = cleanupFails ? new Marker() : null;
        Recording recording = new Recording(marker);
        String value = null;
        RuntimeException failure = null;
        System.setOut(recording);
        try {
            value = BranchThrowFinally.finThrow(n);
        } catch (RuntimeException ex) {
            failure = ex;
        } finally {
            System.setOut(original);
        }
        check(recording.calls == 1 && "ft".equals(recording.value), "cleanup once");
        if (cleanupFails) {
            check(failure == marker, "same cleanup exception overrides return or try throw");
        } else if (n < 0) {
            check(failure != null && failure.getClass() == RuntimeException.class
                    && "neg".equals(failure.getMessage()), "try exception class and message");
        } else {
            check(failure == null && "ok".equals(value), "normal return survives cleanup");
        }
        original.println(n + ":" + cleanupFails + ":"
                + (failure == null ? "return:" + value : "throw:" + failure.getClass().getName()
                        + ":" + failure.getMessage())
                + ":ft=" + recording.calls + ":cleanupIdentity=" + (failure == marker && marker != null));
    }

    public static void main(String[] args) {
        run(Integer.MIN_VALUE, false);
        run(-1, false);
        run(0, false);
        run(Integer.MAX_VALUE, false);
        run(0, true);
        run(-1, true);
    }
}
