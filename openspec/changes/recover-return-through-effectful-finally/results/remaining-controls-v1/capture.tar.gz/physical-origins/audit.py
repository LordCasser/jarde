from pathlib import Path
import json,hashlib,struct,zipfile
C=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE')
P=Path(__file__).resolve().parent
receipt=C/'effectful-finally-final-loop-transfer-screen-v1/run-v1/execution.json'
r=json.loads(receipt.read_text())
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def methods(b):
 pos=8
 def u1():
  nonlocal pos
  v=b[pos];pos+=1;return v
 def u2():
  nonlocal pos
  v=int.from_bytes(b[pos:pos+2],'big');pos+=2;return v
 def u4():
  nonlocal pos
  v=int.from_bytes(b[pos:pos+4],'big');pos+=4;return v
 assert b[:4]==bytes.fromhex('cafebabe')
 count=u2();cp={};i=1
 while i<count:
  tag=u1()
  if tag==1:
   n=u2();cp[i]=b[pos:pos+n];pos+=n
  elif tag in (3,4):pos+=4
  elif tag in (5,6):pos+=8;i+=1
  elif tag in (7,8,16,19,20):pos+=2
  elif tag in (9,10,11,12,17,18):pos+=4
  elif tag==15:pos+=3
  else:raise AssertionError(tag)
  i+=1
 pos+=6
 for _ in range(u2()):pos+=2
 def attrs():
  nonlocal pos
  rows=[]
  for _ in range(u2()):
   name=cp[u2()];n=u4();start=pos;rows.append((name,b[start:start+n]));pos+=n
  return rows
 for _ in range(u2()):pos+=6;attrs()
 out={}
 for _ in range(u2()):
  flags=u2();name=cp[u2()].decode();descriptor=cp[u2()].decode();a=attrs()
  code=[v for k,v in a if k==b'Code'];assert len(code)<=1
  if code:
   v=code[0];n=int.from_bytes(v[4:8],'big');out[(name,descriptor)]=v[8:8+n]
 return out
def bcis(code):
 at=0;out=[]
 while at<len(code):
  out.append(at);op=code[at];w=1
  if op in [0x10,0x12,0xa9,0xbc,*range(0x15,0x1a),*range(0x36,0x3b)]:w=2
  elif op in [0x11,0x13,0x14,0x84,0xbb,0xbd,0xc0,0xc1,0xc6,0xc7,*range(0x99,0xa9),*range(0xb2,0xb9)]:w=3
  elif op==0xc5:w=4
  elif op in [0xb9,0xba,0xc8,0xc9]:w=5
  elif op==0xc4:w=6 if code[at+1]==0x84 else 4
  elif op in [0xaa,0xab]:
   start=at+1+(-(at+1)%4)
   if op==0xaa:
    low,high=struct.unpack('>ii',code[start+4:start+12]);assert high>=low;w=start-at+12+(high-low+1)*4
   else:
    count=int.from_bytes(code[start+4:start+8],'big');w=start-at+8+count*8
  assert w>0 and at+w<=len(code);at+=w
 assert at==len(code);return out
rows=[];inputs=[pin(receipt)]
for case,data in r['cases'].items():
 leg,name=case.split('/');jar=Path(data['input_jar']['path']);assert pin(jar)==data['input_jar'];inputs.append(pin(jar))
 with zipfile.ZipFile(jar) as z:
  assert z.namelist()==[name+'.class'];raw=z.read(name+'.class')
 declared=methods(raw);q=next(q for q in r['commands'] if q['label']==leg+'-current-whole-source-'+name);p=Path(q['streams']['stdout']['path']);assert pin(p)==q['streams']['stdout'];inputs.append(pin(p));doc=json.loads(p.read_text())
 assert len(declared)==len(doc['methods'])
 for method in doc['methods']:
  key=(method['item']['name']['escaped'],method['item']['descriptor']['escaped']);physical=bcis(declared[key]);report=method['outcome']['report'];actual=set();bound=True
  for segment in report['source_map']['segments']:
   for origin in [segment['origin']['primary'],*segment['origin']['derived']]:
    if origin['method']==method['item']['identity']:actual.add(origin['bci'])
    else:bound=False
  rows.append(dict(case=case,name=key[0],descriptor=key[1],code_bytes=len(declared[key]),physical_bcis=physical,missing=sorted(set(physical)-actual),extra=sorted(actual-set(physical)),all_origins_own_method=bound,quality=report['quality'],representation=report['representation']))
result=dict(status='observed_actual_parent_physical_origin_coverage_not_product_acceptance',runner=pin(__file__),inputs=inputs,methods=rows,boundary='Pure Python classfile/Code boundary audit against actual final CLI raw. Missing origins are observations, not permission to fabricate or change old proofs. No new native, behavioral or CI result.')
(P/'audit-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps([dict(case=x['case'],name=x['name'],missing=x['missing'],extra=x['extra'],bound=x['all_origins_own_method']) for x in rows if x['missing'] or x['extra'] or not x['all_origins_own_method']]))
